"""Model class — opinionated per-model sampling + chat-template knobs.

This is the rtxclaw-vs-OpenClaw differentiator: rtxclaw is prescriptive
about which sampling knobs work well for which model on which provider.
OpenClaw is provider-agnostic; we're not.

Composition with `providers.py`:

- `Provider` describes WIRE format (vLLM vs SGLang — `delta.reasoning`
  vs `delta.reasoning_content`, etc.).
- `Model` describes per-model sampling sweet spots and family-specific
  chat-template kwargs (Qwen3's `thinking_budget`, future Llama-style
  knobs, etc.).

Two orthogonal axes; both feed into the worker's HTTP request.

Each `Model` carries three `ModeSampling` records, one per permission
mode (`plan` / `ask` / `auto`). The runtime picks the right one based
on the session's active mode and forwards the non-None fields to the
upstream `chat/completions` request.

Add a new model: append a `Model(...)` to `KNOWN_MODELS` and tune its
mode-specific sampling. `for_name()` resolves an upstream model id
(exact name → family-prefix → fallback to `GENERIC` defaults).
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field, replace
from typing import Any, Optional, Union

from rtxclaw_core.tools.permissions import PermissionMode


@dataclass(frozen=True)
class ModeSampling:
    """Per-mode sampling knobs. `None` for any field = let upstream default.

    `enable_thinking` and `thinking_budget` ride inside
    `chat_template_kwargs`; the rest go on the top-level chat/completions
    body. `sampling_to_request_fields()` does the split.
    """
    temperature: float = 0.6
    top_p: Optional[float] = None
    top_k: Optional[int] = None
    min_p: Optional[float] = None
    repetition_penalty: Optional[float] = None
    presence_penalty: Optional[float] = None
    frequency_penalty: Optional[float] = None
    max_completion_tokens: Optional[int] = None
    seed: Optional[int] = None
    # Qwen3-family chat-template kwargs (None = unset, let server default).
    enable_thinking: Optional[bool] = None
    thinking_budget: Optional[Union[str, int]] = None


# Mode defaults baked in once and re-used across every Model that doesn't
# override. These match the Qwen team's OFFICIAL Qwen3 thinking-mode
# guidance from the Qwen3-32B / Qwen3-30B-A3B-Thinking-2507 /
# Qwen3-235B-A22B-Thinking-2507 model cards:
#
#   "We suggest using Temperature=0.6, TopP=0.95, TopK=20, and MinP=0."
#   "For supported frameworks, you can adjust the presence_penalty
#    parameter between 0 and 2 to reduce endless repetitions. However,
#    using a higher value may occasionally result in language mixing
#    and a slight decrease in model performance."
#
# So PP lives on a documented `[0, 2]` range, not at 0.0. We pick
# `presence_penalty = 1.5` — the canonical "Qwen3 with repetition
# reduction" value, also Qwen's own instruct-mode default — because:
#   1. It's the documented sweet spot for repetition reduction.
#   2. The runtime streaming loop detector + distill recovery
#      (`_detect_reasoning_loop`, `_distill_partial_reasoning`) cover
#      the language-mixing edge case Qwen warns about.
# `repetition_penalty=1.0` (off) per Qwen's earlier guidance that
# `repetition_penalty > 1.0` in thinking mode hurts CoT quality —
# `presence_penalty` is the right knob here, not repetition_penalty.
#
# Per-mode budgets:
# - `plan`: high thinking budget + big completion ceiling so architectural
#   answers don't truncate themselves. The "fix laziness" lever.
# - `ask` / `auto`: same sampling, smaller budgets for snappy turns.

# Per-mode completion ceilings. The runtime no longer compacts at a
# soft fraction of context — it only fires when the request would
# actually overflow `upstream_max_context` (or the upstream returns a
# context-length 400). So a generous max_tokens here doesn't push
# compaction earlier; it just gives the model room to write.
#
# - `plan`: 16k — exhaustive synthesis answers
# - `ask` / `auto`: 8k — tool-driven workflows; the length-continue
#   path picks up where it left off if a particular answer goes long.
_PLAN_DEFAULT = ModeSampling(
    temperature=0.6,
    top_p=0.95,
    top_k=20,
    min_p=0.0,
    presence_penalty=1.5,
    repetition_penalty=1.0,
    max_completion_tokens=16384,
    enable_thinking=True,
    # PLAN is the "deep thinking / fix laziness" lever — the
    # higher max_completion_tokens above pairs with a thinking
    # budget that matches the output ceiling so an architectural
    # synthesis answer can spend up to 16k on CoT before the
    # answer phase. ASK / AUTO stay at 4k for snappy interactive
    # use.
    thinking_budget=16384,
)

_ASK_DEFAULT = ModeSampling(
    temperature=0.6,
    top_p=0.95,
    top_k=20,
    min_p=0.0,
    presence_penalty=1.5,
    repetition_penalty=1.0,
    # 16k output ceiling so thinking-first models (Qwen3.6-27B et al.)
    # always have headroom to land a content reply after a long
    # reasoning phase. With 8k, the model exhausted the budget on
    # thinking and emitted `content: null`, which the bot rendered as
    # an empty reply.
    max_completion_tokens=16384,
    enable_thinking=True,
    thinking_budget=8192,
)

_AUTO_DEFAULT = ModeSampling(
    temperature=0.6,
    top_p=0.95,
    top_k=20,
    min_p=0.0,
    presence_penalty=1.5,
    repetition_penalty=1.0,
    # Same headroom story as ASK — see comment above. 16k output / 8k
    # thinking matches PLAN's safety margin for thinking models without
    # breaking compaction (compact_at_frac is a fraction of total
    # context, not output length).
    max_completion_tokens=16384,
    enable_thinking=True,
    thinking_budget=8192,
)


def _env_float(name: str) -> Optional[float]:
    raw = os.environ.get(name)
    if raw is None or raw == "":
        return None
    try:
        return float(raw)
    except ValueError:
        return None


# A/B knob for emergency tuning: set RTXCLAW_AUTO_PRESENCE_PENALTY
# (e.g. 0.5) to override on top of the auto profile without a code
# change. The Qwen team's documented range is `[0, 2]`; the default
# of 1.5 sits at the upper end. Drop this lower if you observe
# language mixing or CoT quality degradation that the runtime loop
# detector isn't already catching.
_AUTO_PP_OVERRIDE = _env_float("RTXCLAW_AUTO_PRESENCE_PENALTY")
if _AUTO_PP_OVERRIDE is not None:
    _AUTO_DEFAULT = replace(_AUTO_DEFAULT, presence_penalty=_AUTO_PP_OVERRIDE)


@dataclass(frozen=True)
class Model:
    """One model's per-mode sampling profile + family identity.

    `name` is matched (case-insensitive) against upstream model ids — exact
    match wins, falling back to substring match against the model name.
    `family` describes the chat-template family ("qwen3", "gemma4", …) for
    callers that want to dispatch on family rather than model.

    `thinking_tags` are the open/close markers the model emits around its
    chain-of-thought when no reasoning parser is active server-side.
    Qwen3 uses `<think>...</think>`; Gemma 4 uses `<thought>...</thought>`.
    Used by the worker's `ThinkSplitter` to route inline reasoning into
    the thinking channel.

    `prefill_thinking_open_tag=True` means the request builder should
    end the prompt with the open tag (e.g. `<thought>\n`) using vLLM's
    `continue_final_message=true` so generation begins inside a thought
    block. This is the documented Gemma 4 thinking pattern.
    """
    name: str
    family: str = ""
    plan: ModeSampling = field(default_factory=lambda: _PLAN_DEFAULT)
    ask: ModeSampling = field(default_factory=lambda: _ASK_DEFAULT)
    auto: ModeSampling = field(default_factory=lambda: _AUTO_DEFAULT)
    thinking_tags: tuple[str, str] = ("<think>", "</think>")
    prefill_thinking_open_tag: bool = False
    extra_sampling: dict[str, Any] = field(default_factory=dict)
    # Worker post-stream `chars_per_token < floor` ratio guard. Default
    # ``None`` falls back to ``$RTXCLAW_LOOP_CHARS_PER_TOKEN_MIN`` (1.5).
    # Quantization-fragile families (gemma-4 NVFP4) tighten this so a
    # round that emits text at less than the family's typical chars/
    # token rate trips the loop guard one round earlier.
    loop_chars_per_token_min: Optional[float] = None
    # Per-model absolute compaction trigger (in prompt tokens). When
    # set, the bridge's `_maybe_compact` squeezes old tool results
    # before the next round if `prompt_tokens >=
    # compact_at_max_prompt_tokens`, regardless of the agent-level
    # `compact_at_frac × upstream_max_context` threshold. Use this to
    # keep quantization-fragile models inside their reliable operating
    # range (FP8 / NVFP4 attention layers degrade past their
    # documented stable region — Qwen3.6-FP8 collapse-mode is
    # documented past long context per QwenLM/Qwen3.5#115). Default
    # ``None`` defers entirely to the agent-level config.
    compact_at_max_prompt_tokens: Optional[int] = None

    def sampling_for(self, mode: PermissionMode) -> ModeSampling:
        """Return the `ModeSampling` for the given permission mode."""
        return getattr(self, mode.value)


# Known models. Append here when a new local model joins your fleet.
#
# Qwen3 family. `presence_penalty=1.5` (in `_*_DEFAULT`) is the
# documented anti-repetition lever per Qwen's model cards — but the
# community has reported it isn't always sufficient on long-context
# reasoning (QwenLM/Qwen3.5#115, QwenLM/Qwen3.6#145, QwenLM/Qwen3-VL
# #1611). We add vLLM's `RepetitionDetectionParams` as a safety net.
# Settings deliberately lenient compared to gemma's (3/20/4): qwen's
# observed failure mode is paragraph-level repeats during reasoning,
# not the token-collapse pattern that hits gemma-4-NVFP4. Larger
# `min_pattern_size` avoids false positives on legitimate tight
# structures (numbered-list scaffolding, repeated tool-result markers,
# code snippets with regular cadence). `min_count=8` requires the
# loop to be unambiguous before firing.
QWEN3_6 = Model(
    name="qwen3.6",
    family="qwen3",
    extra_sampling={
        "repetition_detection": {
            "max_pattern_size": 80,
            "min_pattern_size": 10,
            "min_count": 8,
        },
    },
    # Match the gemma-4 ratio guard floor explicitly so the post-
    # stream `chars_per_token < 1.5` check is documented per-model
    # rather than relying on the env-default fallback. Qwen3-FP8's
    # documented coherence collapse on long context produces the
    # same low chars/token signature as gemma-NVFP4's token collapse,
    # so the same floor applies.
    loop_chars_per_token_min=1.5,
    # Compact context at 128k prompt tokens. Qwen3.6-27B-FP8 advertises
    # 256k native context but the long-context decode cliff (single-
    # digit tok/s past 16k per the vLLM recipe) and the linear-attn
    # FP8 quantization fragility (QwenLM/Qwen3.5#115) make 128k a
    # comfortable ceiling — gives the model 4× the documented sweet
    # spot, well below the size where the SSM-block coherence
    # collapse has been reproduced. The bridge squeezes old tool
    # results before the next round once we cross this; the model
    # keeps the compaction summary in `sess.compaction_summary`.
    compact_at_max_prompt_tokens=128_000,
)

# Gemma 3/4 family. vLLM with `--reasoning-parser gemma4` splits the
# thought channel off into `delta.reasoning_content`; the worker's
# splitter handles any leaked markers as a safety net.
#
# Protocol (per ai.google.dev/gemma/docs/core/prompt-formatting-gemma4
# and vLLM's gemma4 recipe): Gemma 4 wraps thinking in an *asymmetric*
# channel marker — open `<|channel>thought\n`, close `<channel|>` (note
# the `|` swaps sides). Thinking is enabled via the chat-template kwarg
# `enable_thinking=true`, NOT by prefilling an open tag with
# `continue_final_message=true` (we used to do that for `<thought>`,
# which is a different format that does not match Gemma 4's tokenizer
# — vLLM's parser then misclassified the entire response as reasoning
# and the TUI showed an empty bubble because `reasoning_visibility=off`
# is the default).
#
# Sampling: Gemma 4 31B has a model-level repetition bug
# (google-deepmind/gemma#622, vllm-project/vllm#40080) that
# `repetition_penalty` does not fix. Community-validated mitigation for
# agentic / tool-calling use is lower temperature, mild
# frequency/presence penalty, and `min_p=0` (any positive `min_p`
# breaks Gemma 4 tool calling).
#
# `max_completion_tokens=2048` is a deliberate tightening from the
# 4096 we initially shipped: NVFP4 quantization leaves attention
# weights in BF16 but truncates MLP mantissa, which in practice means
# the model is more likely to slip into a token-collapse loop on long
# planning rounds (we observed 4096-token loops at ~40k prompt
# context on gpu-d/gemma-4-31b-nvfp4-mtp). A 2048 ceiling lets the
# model land a normal answer in one round but caps the per-round blast
# radius when the streaming loop detectors haven't caught the
# collapse yet — pairs with the worker's `chars_per_token < 1.5`
# ratio guard that fires post-stream.
_GEMMA_SAMPLING = ModeSampling(
    temperature=0.4,
    top_p=0.9,
    top_k=20,
    min_p=0.0,
    frequency_penalty=0.4,
    presence_penalty=0.3,
    repetition_penalty=1.05,
    max_completion_tokens=2048,
    enable_thinking=True,
)

GEMMA4 = Model(
    name="gemma",
    family="gemma4",
    plan=_GEMMA_SAMPLING,
    ask=_GEMMA_SAMPLING,
    auto=_GEMMA_SAMPLING,
    thinking_tags=("<|channel>thought\n", "<channel|>"),
    prefill_thinking_open_tag=False,
    # NVFP4 + MTP slip into token-collapse looping more readily than
    # BF16/FP8 baselines do. Healthy per-round ratios on gpu-d measure
    # 1.7–3.5 chars/token; 2.0 is comfortably above the noise floor
    # while still being tight enough to catch a collapse round (live
    # measured collapse: 0.37 chars/token).
    loop_chars_per_token_min=2.0,
    extra_sampling={
        "dry_multiplier": 0.8,
        "dry_base": 1.75,
        "dry_allowed_length": 2,
        "dry_sequence_breakers": ["\n", ".", "!", "?", "<", ">"],
        # vLLM's server-side RepetitionDetectionParams (per the
        # community recipe for gemma-4-31b-nvfp4-mtp dual-GPU loop
        # mitigation): detect any 3–20 token N-gram repeating ≥4
        # times and end generation early. This is the in-decoder
        # backstop — fires before our streaming `_detect_loops_layered`
        # ever sees the chars, saving the upstream tokens we'd
        # otherwise burn while the streaming detector samples every
        # `LOOP_CHECK_STRIDE` chars.
        "repetition_detection": {
            "max_pattern_size": 20,
            "min_pattern_size": 3,
            "min_count": 4,
        },
    },
)

GENERIC = Model(
    name="generic",
    family="",
)

KNOWN_MODELS: tuple[Model, ...] = (QWEN3_6, GEMMA4)


def for_name(name: str) -> Model:
    """Resolve a Model by upstream model id. Falls back to `GENERIC`.

    Case-insensitive. Exact name match first; then substring (so
    `qwen3.6-27b-fp8` matches `qwen3.6`). Path-style ids (SGLang's
    `/home/.../Qwen3.6-27B`) are normalized to the basename for matching.
    """
    if not name:
        return GENERIC
    n = name.lower()
    base = n.rsplit("/", 1)[-1]
    for m in KNOWN_MODELS:
        if m.name.lower() == base or m.name.lower() == n:
            return m
    for m in KNOWN_MODELS:
        m_n = m.name.lower()
        if m_n and (m_n in n or m_n in base):
            return m
    return GENERIC


# Top-level chat/completions request fields we know about. Anything else
# in `ModeSampling` rides as a chat_template_kwarg.
_REQUEST_FIELD_NAMES: tuple[str, ...] = (
    "temperature",
    "top_p",
    "top_k",
    "min_p",
    "repetition_penalty",
    "presence_penalty",
    "frequency_penalty",
    "seed",
)


def sampling_to_request_fields(s: ModeSampling) -> tuple[dict[str, Any], dict[str, Any]]:
    """Split a `ModeSampling` into (top-level request fields, chat_template_kwargs).

    The top-level dict goes onto the chat/completions body; the
    chat_template_kwargs dict goes inside `chat_template_kwargs` so vLLM /
    SGLang forward it to the model's chat template (e.g. Qwen3's
    `enable_thinking` / `thinking_budget`). None values are dropped so we
    only send explicit knobs.
    """
    request_fields: dict[str, Any] = {}
    for k in _REQUEST_FIELD_NAMES:
        v = getattr(s, k, None)
        if v is not None:
            request_fields[k] = v
    if s.max_completion_tokens is not None:
        # OpenAI-compat name for the cap.
        request_fields["max_tokens"] = s.max_completion_tokens

    template_kwargs: dict[str, Any] = {}
    if s.enable_thinking is not None:
        template_kwargs["enable_thinking"] = s.enable_thinking
    if s.thinking_budget is not None:
        template_kwargs["thinking_budget"] = s.thinking_budget

    return request_fields, template_kwargs


def merge_overrides(base: ModeSampling, override: dict[str, Any] | None) -> ModeSampling:
    """Apply an override dict (from a per-turn `sampling` request body) on top of `base`.

    Returns a new `ModeSampling` with override fields replacing base fields
    where the override is non-None. Fields not present in override or set
    to None are inherited from base. Unknown keys in override are ignored
    so callers can't smuggle arbitrary fields through.
    """
    if not override:
        return base
    valid = {f.name for f in base.__dataclass_fields__.values()}
    kwargs = {f: getattr(base, f) for f in valid}
    for k, v in override.items():
        if k in valid and v is not None:
            kwargs[k] = v
    return ModeSampling(**kwargs)
