"""Structured error log at `~/.rtxclaw/errors/`.

When something goes wrong inside rtxclaw — a Claude-bridge readline
overflow, a worker that crashes, an unhandled exception in the agent
runtime — we write a Markdown file describing the failure: timestamp,
component, exception type, traceback, captured context. The agent can
later read these (`list_dir` + `read_file`) and propose fixes; once a
fix ships, the file is renamed with a `[fixed]_` prefix to keep the
"open" set small.

## File layout

```
~/.rtxclaw/errors/
  2026-04-26T14-32-15Z_a1b2c3d4_claude-bridge-overflow.md   ← open
  [fixed]_2026-04-25T10-00-00Z_d4e5f6a7_dispatch-race.md    ← resolved
```

Filename: `<UTC-ISO-ts>_<fp>_<slug>.md`, `[fixed]_` prefix when resolved.

`<fp>` is an 8-char SHA-1 of (component, exception type, top traceback
frame, first arg of the exception). Same fingerprint = same bug — so a
recurring crash appends `## Occurrence — <ts>` sections to one file
instead of flooding the directory.

## Frontmatter

YAML-style header at the top of every file:

```yaml
---
timestamp: 2026-04-26T14-32-15Z
component: claude_bridge
exception: ValueError
fingerprint: a1b2c3d4
status: open
---
```

The agent can grep these fields to triage without reading the body.

## API

- `log_error(component, exc, context=None, summary=None)` — write or
  append. Returns the file path.
- `mark_fixed(path)` — rename with `[fixed]_` prefix and append a
  resolution timestamp. Returns the new path.
- `list_errors(status="open" | "fixed" | "all")` — sorted recency-first.
- `errors_dir()` — `~/.rtxclaw/errors`, created lazily.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional


def errors_dir() -> Path:
    """`<root>/errors` for the active workspace.

    Resolves the workspace root the same way as
    :func:`rtxclaw_core.agent.rtxclaw_root` so a test that sets
    ``$RTXCLAW_HOME`` (or the more-specific ``$RTXCLAW_AGENTS_HOME``)
    gets an isolated errors dir alongside the rest of the runtime tree.
    """
    base = os.environ.get("RTXCLAW_AGENTS_HOME")
    if base:
        root = Path(base).parent
    else:
        home = os.environ.get("RTXCLAW_HOME")
        root = Path(home).expanduser() if home else Path.home() / ".rtxclaw"
    return root / "errors"


def _write_private(path: Path, body: str) -> None:
    """Write `body` to `path` with mode 0600.

    Tracebacks may include partial user prompts, env-var values, or
    captured tool args (which can contain API keys / file paths). The
    default umask makes new files world-readable on most systems; on a
    shared host that's a quiet PII / secret leak. Write 0600 so only the
    owner reads.
    """
    flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC
    fd = os.open(str(path), flags, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(body)
    except Exception:
        try:
            os.close(fd)
        except OSError:
            pass
        raise


def _open_private_append(path: Path):
    """Append-mode open with 0600 perms on first create. Returns a
    text-mode file object (caller `close`s it)."""
    flags = os.O_WRONLY | os.O_CREAT | os.O_APPEND
    fd = os.open(str(path), flags, 0o600)
    return os.fdopen(fd, "a", encoding="utf-8")


def _utc_ts() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H-%M-%SZ")


def _fingerprint(component: str, exc: BaseException) -> str:
    """8-char SHA-1 over (component, exc_type, top_frame_file:line, arg[0]).

    Stable enough to dedupe recurring failures, brittle enough that an
    edit which moves the failing line gets a fresh fingerprint — which
    is what we want; a relocated bug IS a new bug.
    """
    tb = exc.__traceback__
    while tb is not None and tb.tb_next is not None:
        tb = tb.tb_next
    if tb is not None:
        top_file = (tb.tb_frame.f_code.co_filename or "").rsplit("/", 1)[-1]
        top_line = tb.tb_lineno or 0
    else:
        top_file, top_line = "", 0
    arg0 = ""
    if exc.args:
        try:
            arg0 = str(exc.args[0])[:120]
        except Exception:  # noqa: BLE001
            arg0 = ""
    key = f"{component}:{type(exc).__name__}:{top_file}:{top_line}:{arg0}"
    return hashlib.sha1(key.encode("utf-8")).hexdigest()[:8]


def _slug(text: str, max_len: int = 60) -> str:
    """File-safe lowercase kebab. Always non-empty."""
    s = re.sub(r"[^a-z0-9]+", "-", (text or "").lower()).strip("-")
    return s[:max_len] or "error"


def _format_traceback(exc: BaseException, *, limit: int = 8000) -> str:
    text = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    return text[:limit]


def _format_context(context: Optional[dict[str, Any]], *, limit: int = 2000) -> str:
    if not context:
        return ""
    try:
        body = json.dumps(context, indent=2, default=str, ensure_ascii=False)
    except Exception:  # noqa: BLE001
        body = repr(context)
    return body[:limit]


def log_error(
    component: str,
    exc: BaseException,
    *,
    context: Optional[dict[str, Any]] = None,
    summary: Optional[str] = None,
) -> Path:
    """Record an error in `~/.rtxclaw/errors/`. See module docstring.

    If an OPEN file with the same fingerprint already exists, append a
    new `## Occurrence — <ts>` section to it. This way a flapping
    failure doesn't flood the dir; one fix retires one file.
    """
    d = errors_dir()
    d.mkdir(parents=True, exist_ok=True)
    ts = _utc_ts()
    fp = _fingerprint(component, exc)

    # Look for an existing OPEN file with this fingerprint.
    for existing in d.glob(f"*_{fp}_*.md"):
        if existing.name.startswith("[fixed]"):
            continue
        with _open_private_append(existing) as f:
            f.write(f"\n\n## Occurrence — {ts}\n\n")
            if context:
                f.write("**Context**:\n\n```json\n")
                f.write(_format_context(context))
                f.write("\n```\n\n")
            f.write("**Traceback**:\n\n```\n")
            f.write(_format_traceback(exc))
            f.write("\n```\n")
        return existing

    # New file.
    summary_slug = _slug(summary or f"{component}-{type(exc).__name__}")
    path = d / f"{ts}_{fp}_{summary_slug}.md"
    msg = ""
    if exc.args:
        try:
            msg = str(exc.args[0])[:400]
        except Exception:  # noqa: BLE001
            msg = ""
    body: list[str] = [
        "---",
        f"timestamp: {ts}",
        f"component: {component}",
        f"exception: {type(exc).__name__}",
        f"fingerprint: {fp}",
        "status: open",
        "---",
        "",
        f"# {component}: {type(exc).__name__}",
        "",
    ]
    if summary:
        body += [f"> {summary}", ""]
    if msg:
        body += ["**Message**:", "", f"> {msg}", ""]
    if context:
        body += ["## Context", "", "```json", _format_context(context), "```", ""]
    body += ["## Traceback", "", "```", _format_traceback(exc), "```", ""]
    _write_private(path, "\n".join(body))
    return path


def mark_fixed(path: Path | str, *, resolution: Optional[str] = None) -> Path:
    """Rename an error file with the `[fixed]_` prefix and append a
    resolution stamp. Idempotent — re-marking a `[fixed]_` file is a no-op.

    `resolution` is a one-line summary of how it got fixed (e.g. the
    commit hash, or a sentence). Stored at the bottom of the file so a
    future agent reading the dir can learn from past fixes.
    """
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(p)
    if p.name.startswith("[fixed]_"):
        return p
    new = p.with_name(f"[fixed]_{p.name}")
    p.rename(new)
    # Update frontmatter `status: open` → `status: fixed` and append a
    # resolution section.
    text = new.read_text(encoding="utf-8")
    text = re.sub(r"^status:\s*open\s*$", "status: fixed", text, count=1, flags=re.MULTILINE)
    ts = _utc_ts()
    text += f"\n---\n\n## Fixed — {ts}\n"
    if resolution:
        text += f"\n{resolution}\n"
    _write_private(new, text)
    return new


def list_errors(*, status: str = "open") -> list[Path]:
    """List error files, sorted most-recent-first.

    `status`: `"open"` (default), `"fixed"`, or `"all"`.
    """
    d = errors_dir()
    if not d.exists():
        return []
    paths = sorted(d.glob("*.md"), key=lambda p: p.stat().st_mtime, reverse=True)
    if status == "open":
        return [p for p in paths if not p.name.startswith("[fixed]_")]
    if status == "fixed":
        return [p for p in paths if p.name.startswith("[fixed]_")]
    return paths
