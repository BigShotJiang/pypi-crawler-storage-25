"""Heuristic shell-command classifier — defense-in-depth sanity check.

The PRIMARY criticality source is the model itself: we ask the model to
mark every tool call's `criticality` field via a system-prompt fragment
(see `tools.prompt`). This module is the SECONDARY source — a regex /
keyword classifier that catches obviously destructive commands the model
might have under-classified (e.g. it called `rm -rf /tmp/foo` and
labeled it `mutating` instead of `destructive`).

The evaluator takes the more cautious of {model_claim, heuristic}, so:

- If both agree, decision is unambiguous.
- If they disagree, the more cautious side wins (we never under-protect).
- If the model omits the claim entirely, the heuristic is the only signal.

This file ships with a hand-curated, conservative ruleset. It is **not**
a sandbox — it doesn't prevent malicious commands from running, it just
makes the permission gate aware of what's about to run. A user in `auto`
mode running `rm -rf /` will still get a confirmation prompt because
the heuristic flags `rm -rf` even if the model wrongly claimed otherwise.
"""
from __future__ import annotations

import re
import shlex
from enum import Enum


class CommandSafety(Enum):
    """Heuristic classification of a shell command.

    Values are ordered from least to most cautious so callers can take
    `max(a, b, key=CommandSafety.severity)` to merge two classifications.
    """

    READ_ONLY = "read_only"      # ls, cat, git status, grep — won't change anything
    UNKNOWN = "unknown"          # not on either allow- or deny-list
    MUTATING = "mutating"        # mkdir, touch, mv, sed -i — reversible-ish writes
    DESTRUCTIVE = "destructive"  # rm -rf, dd, drop table, force-push to main

    @property
    def severity(self) -> int:
        return _SEVERITY[self]


_SEVERITY: dict[CommandSafety, int] = {
    CommandSafety.READ_ONLY: 0,
    CommandSafety.UNKNOWN: 1,
    CommandSafety.MUTATING: 2,
    CommandSafety.DESTRUCTIVE: 3,
}


# Commands whose mere invocation can't change state (no flags that mutate).
# Conservative: a single argv[0] match, no flag inspection beyond what's
# checked below for `git`. Add to this list with care — a "read-only" tag
# is a permission for plan-mode users to run the command unprompted.
_READ_ONLY_COMMANDS: frozenset[str] = frozenset({
    # Inspection
    "ls", "cat", "head", "tail", "less", "more", "wc", "file", "stat",
    "tree", "tac", "nl", "fold", "fmt", "column", "diff", "cmp",
    # Search
    "grep", "egrep", "fgrep", "rg", "ack", "ag", "find", "locate", "which",
    # Process / system inspect
    "ps", "top", "htop", "free", "df", "du", "uptime", "who", "w", "id",
    "whoami", "hostname", "uname", "groups", "tty", "lsof", "lsblk", "lscpu",
    "lspci", "lsusb", "dmesg",
    # Network inspect (no mutations)
    "ping", "traceroute", "dig", "nslookup", "host", "ip",
    "ifconfig", "netstat", "ss", "arp", "route",
    # Date / env
    "date", "cal", "env", "printenv", "locale",
    # Help / docs
    "man", "info", "help", "type", "command", "alias", "history",
    # Compression inspect-only — `tar` / `unzip` are NOT here because
    # the classifier doesn't inspect their flags: `tar -xf foo.tar`
    # extracts and `unzip foo.zip` unpacks, both of which are mutating.
    # The classifier returns UNKNOWN (→ MUTATING) for them so the
    # permission evaluator prompts the user.
    "zcat", "bzcat", "xzcat", "zless", "bzless",
    # Python read-only invocations
    "pwd",
})

# Commands that DON'T change state when called without arguments / with
# specific subcommands. Limited to the ones we can be sure about.
#
# Excluded on purpose: `branch`, `tag`, `remote`, `stash`, `config`. Each
# has destructive variants that cannot be told apart from a read-only
# invocation by argv[1] alone:
#   - `git branch -d/-D <name>` deletes branches.
#   - `git tag -d <name>` deletes tags; `git tag <new>` creates them.
#   - `git remote add/remove/set-url …` mutates remotes.
#   - `git stash drop / pop / clear` discards stash entries.
#   - `git config --global user.email …` rewrites global git identity.
# The classifier returns UNKNOWN (→ MUTATING) for these so the permission
# evaluator prompts the user before executing — better than silently
# allowing them in PLAN mode.
_GIT_READ_ONLY_SUBCOMMANDS: frozenset[str] = frozenset({
    "status", "diff", "log", "show", "blame",
    "rev-parse", "ls-files", "ls-tree", "ls-remote",
    "describe", "shortlog", "reflog", "fsck", "count-objects",
    "cherry", "name-rev", "for-each-ref", "cat-file", "check-ignore",
})

# Things that are nearly always destructive / irreversible.
_DESTRUCTIVE_PATTERNS: tuple[re.Pattern[str], ...] = tuple(
    re.compile(p, re.IGNORECASE)
    for p in (
        r"\brm\s+(-[a-zA-Z]*[rRfF][a-zA-Z]*\s+)",       # rm -r / -rf / -fr / -Rf etc.
        r"\bsudo\s+rm\b",                                 # any sudo rm
        r"\bdd\s+.*\bof=/dev/",                           # dd of=/dev/sdX
        r"\bmkfs\.",                                      # mkfs.ext4 etc.
        r"\bmkfs\b",
        r"\bshred\b",
        r"\bwipefs\b",
        r"\bfind\b.*\s-delete\b",                         # find ... -delete
        r"\bxargs\s+rm\b",
        r":\(\)\s*\{\s*:\|:\s*&\s*\}\s*;",               # fork-bomb signature
        r">\s*/dev/sd[a-z]",                              # raw-device write
        # Any force-push is destructive — many teams promote to
        # `develop` / `production` / `release/*` and the previous
        # main|master-only filter let those slip through.
        r"\bgit\s+push\b[^|;&]*\s-{1,2}f\b",
        r"\bgit\s+push\b[^|;&]*\s-{1,2}force\b",
        r"\bgit\s+push\b[^|;&]*\s-{1,2}force-with-lease\b",
        r"\bgit\s+reset\s+--hard\b",
        r"\bgit\s+clean\s+-[a-zA-Z]*[fF][a-zA-Z]*[dD]?\b",
        # Branch deletion — BOTH `-d` (safe/merged-only) and `-D`
        # (force) are treated as destructive on purpose: deleting a
        # branch is rarely something an agent should do unprompted.
        # The class is matched explicitly via `-[dD]` rather than
        # leaning on the tuple-wide re.IGNORECASE flag so the intent
        # is in the pattern, not an accident of compilation.
        r"\bgit\s+branch\s+-[dD]\b",
        r"\bDROP\s+(TABLE|DATABASE|SCHEMA)\b",
        r"\bTRUNCATE\s+(TABLE|DATABASE)\b",
        r"\bDELETE\s+FROM\b\s+\w+\s*;?\s*$",              # DELETE FROM x; with no WHERE
    )
)

# Things that change state but are generally reversible.
_MUTATING_COMMANDS: frozenset[str] = frozenset({
    "mkdir", "rmdir", "touch", "ln", "chmod", "chown", "chgrp",
    "mv", "cp", "rsync", "install",
    "tee", "sed", "awk",
    "apt", "apt-get", "dnf", "yum", "brew", "pacman", "pip", "pip3",
    "npm", "yarn", "pnpm", "cargo", "go",
    "systemctl", "service", "launchctl", "kill", "killall", "pkill",
    "make", "cmake",
})


class SafetyClassifier:
    """Stateless wrapper around `classify_command` for monkeypatching in tests."""

    def classify(self, command: str) -> CommandSafety:
        return classify_command(command)


def classify_command(command: str) -> CommandSafety:
    """Heuristic-classify a shell command string.

    Examples:
        >>> classify_command("ls -la").name
        'READ_ONLY'
        >>> classify_command("rm -rf /tmp/foo").name
        'DESTRUCTIVE'
        >>> classify_command("git status").name
        'READ_ONLY'
        >>> classify_command("git push --force origin main").name
        'DESTRUCTIVE'
        >>> classify_command("mkdir -p build").name
        'MUTATING'
    """
    text = (command or "").strip()
    if not text:
        return CommandSafety.UNKNOWN

    # 1. Destructive patterns first — they win regardless of argv[0] form
    #    so things like `bash -c 'rm -rf /'` still trip.
    for pat in _DESTRUCTIVE_PATTERNS:
        if pat.search(text):
            return CommandSafety.DESTRUCTIVE

    # 2. Try to parse argv. If the command has a pipe, redirect, or
    #    chained `&&`/`;`, fall back to UNKNOWN — heuristic can't easily
    #    promise read-only-ness across a chain.
    if any(sep in text for sep in ("|", ";", "&&", "||", ">", "<", "`", "$(")):
        return CommandSafety.UNKNOWN

    try:
        argv = shlex.split(text)
    except ValueError:
        return CommandSafety.UNKNOWN
    if not argv:
        return CommandSafety.UNKNOWN

    cmd = argv[0]
    # Strip a leading path: `/usr/bin/rm` → `rm`. Bare names match more
    # readily than full paths in everyday usage.
    base = cmd.rsplit("/", 1)[-1]

    # 3. Special case: `git <subcommand>` with read-only subcommand.
    if base == "git" and len(argv) >= 2 and argv[1] in _GIT_READ_ONLY_SUBCOMMANDS:
        return CommandSafety.READ_ONLY

    # 4. argv[0] read-only allowlist.
    if base in _READ_ONLY_COMMANDS:
        return CommandSafety.READ_ONLY

    # 5. argv[0] mutating list.
    if base in _MUTATING_COMMANDS:
        return CommandSafety.MUTATING

    return CommandSafety.UNKNOWN
