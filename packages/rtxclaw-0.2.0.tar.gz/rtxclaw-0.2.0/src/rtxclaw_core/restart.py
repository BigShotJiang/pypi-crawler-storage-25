"""Cross-frontend gateway-restart helper.

``/restart`` from the TUI, the Telegram bot, or the CLI all collapse
to one operation: bounce the rtxclaw single-process gateway — the
parent process hosting every agent under ``/acp/<name>`` — without
taking the calling client down with it.

The single-process gateway is the only deployed model. The legacy
"one daemon per agent" units (``rtxclaw.service`` for ``main``,
``rtxclaw-<name>.service`` for others) have been retired; this
helper no longer probes for them.

Resolution order:

1. **systemd-managed**: ``rtxclaw-gateway.service`` is loaded and
   active → ``sudo -n systemctl restart rtxclaw-gateway.service``.
   This MUST come first when applicable: the in-process daemonizer
   below races systemd's ``Restart=always`` during its ``RestartSec``
   window and ends up creating an orphan ``gateway-serve`` that wins
   the bind race against systemd's next attempt — the bug reproduced
   2026-05-11 that stranded an orphan on port 7700 for ~11h. With
   systemd in the picture, it must be the single owner.
2. **gateway-managed** (no systemd): the gateway pidfile at
   ``$RTXCLAW_HOME/gateway.pid`` (default ``~/.rtxclaw/gateway.pid``)
   points at a live pid → ``rtxclaw_agent gateway restart``.
3. **CLI fallback**: neither systemd nor a live pidfile → shell out
   to ``rtxclaw gateway start`` so the bounce-as-start path "just
   works" on a box where the gateway hasn't been launched yet.

The actual work happens in a *detached* subprocess that sleeps ~1s
before doing the kill — that gap lets the calling wire response
flush before the daemon tears down its connections, which prevents
the caller from seeing an ugly "connection reset". Returns metadata
the calling frontend can use to render a clean confirmation.
"""
from __future__ import annotations

import os
import shlex
import subprocess
import sys
from pathlib import Path
from typing import Optional


def _gateway_pidfile() -> Path:
    """Single-process gateway pidfile path.

    Mirrors ``rtxclaw_agent.gateway._gateway_pidfile`` byte for byte —
    duplicated here so this module doesn't pull a runtime import on
    ``rtxclaw_agent`` (which itself imports ``rtxclaw_core``). The
    contract is the path; if it ever changes there, change it here.
    """
    root = os.environ.get("RTXCLAW_HOME")
    return (Path(root) if root else Path.home() / ".rtxclaw") / "gateway.pid"


def _gateway_running() -> bool:
    """True iff the gateway is reachable.

    Primary: the gateway pidfile points at a live pid. Fallback: a
    successful ``GET /health`` against the configured bind URL —
    covers a missing/raced pidfile while the listener is healthy
    (e.g. early in a systemd restart). Stale pidfile (exists, pid
    dead) only triggers the HTTP fallback; if both fail, the caller
    falls through to the gateway-start path.
    """
    pidfile = _gateway_pidfile()
    if pidfile.is_file():
        try:
            pid = int(pidfile.read_text().strip())
            if pid > 0:
                try:
                    os.kill(pid, 0)
                    return True
                except ProcessLookupError:
                    pass
                except PermissionError:
                    return True
        except (OSError, ValueError):
            pass
    # HTTP fallback. Pull host/port from the global config; on import
    # error or unset config fall back to the gateway's own defaults
    # (``rtxclaw_agent.gateway._DEFAULT_PORT`` — kept in sync by hand
    # here since this module deliberately avoids importing
    # ``rtxclaw_agent``; see ``_gateway_pidfile`` above for the same
    # duplication contract).
    host, port = "127.0.0.1", 20100
    try:
        from rtxclaw_core.agent import load_global_config
        gw = (load_global_config() or {}).get("gateway") or {}
        host = str(gw.get("host") or host)
        port = int(gw.get("port") or port)
    except Exception:  # noqa: BLE001
        pass
    try:
        import httpx as _httpx
        r = _httpx.get(f"http://{host}:{port}/health", timeout=1.0)
        return r.status_code == 200
    except Exception:  # noqa: BLE001
        return False


def _systemd_managed() -> bool:
    """True iff ``rtxclaw-gateway.service`` is loaded and active.

    Calls ``systemctl is-active --quiet`` synchronously (~10ms). When
    True, ``/restart`` must route through ``systemctl restart`` so
    systemd remains the single owner of the gateway port — see
    module docstring for the orphan-spawn bug this guards against.

    Returns False on any error (systemctl missing, timeout, unit
    not loaded, unit loaded-but-inactive). The fall-through is
    deliberate: a stopped or absent unit means no race risk, so the
    in-process daemonizer below is safe to use.
    """
    try:
        result = subprocess.run(  # noqa: S603, S607
            ["systemctl", "is-active", "--quiet", "rtxclaw-gateway.service"],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=2.0,
            check=False,
        )
        return result.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def _build_restart_command(agent_name: str) -> tuple[str, str, Optional[str]]:
    """Pure-function side: pick the (cmd, mode, unit) tuple for
    ``restart_agent_detached``, with no side effects so tests can
    pin the resolution order without spawning processes.

    ``agent_name`` is informational — the gateway restart bounces
    every agent at once. Kept in the signature so frontends don't
    have to special-case the call.
    """
    if _systemd_managed():
        # Systemd-managed: bounce the unit, never spawn our own
        # daemon. ``-n`` keeps sudo non-interactive so the detached
        # shell fails fast on a box without passwordless sudo
        # instead of hanging on a password prompt nobody will see.
        cmd = (
            "sleep 1 && exec sudo -n systemctl restart "
            "rtxclaw-gateway.service"
        )
        return cmd, "systemd", "rtxclaw-gateway"
    if _gateway_running():
        cmd = (
            "sleep 1 && exec "
            f"{shlex.quote(sys.executable)} -m rtxclaw_agent gateway restart"
        )
        return cmd, "gateway", "rtxclaw-gateway"
    # Gateway not running — start it. Same effect from the user's
    # perspective ("agent comes back"), surface the mode honestly so
    # the frontend can render a different confirmation if it wants.
    cmd = (
        "sleep 1 && exec "
        f"{shlex.quote(sys.executable)} -m rtxclaw_agent gateway start"
    )
    return cmd, "gateway-start", "rtxclaw-gateway"


def restart_agent_detached(agent_name: str) -> dict:
    """Schedule a gateway restart and return immediately.

    ``agent_name`` is informational — bouncing the gateway cascades
    to every agent (every child stdio process) at once. The signature
    accepts it for symmetry with the legacy per-agent helper that
    callers (bot, TUI, CLI) already pass.

    Returns:
        ``{"ok": True, "mode": "gateway"|"gateway-start", "unit":
        "rtxclaw-gateway", "pid": int, "agent": str}`` on a
        successfully *scheduled* restart (the actual bounce happens
        ~1s later in the detached child). ``{"ok": False, "error":
        "..."}`` if the restart could not be scheduled (e.g. spawn
        failure).

    The caller should drop any cached connection / session state
    BEFORE returning to the user — when the gateway respawns it will
    have a different PID and possibly a different listening URL, and
    a stale client would issue requests against the going-away
    instance for a few hundred milliseconds.
    """
    cmd, mode, unit = _build_restart_command(agent_name)

    try:
        proc = subprocess.Popen(  # noqa: S603
            ["/bin/sh", "-c", cmd],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
            close_fds=True,
        )
    except OSError as e:
        return {"ok": False, "error": f"spawn failed: {e}"}

    return {
        "ok": True,
        "mode": mode,
        "unit": unit,
        "pid": proc.pid,
        "agent": agent_name,
    }


__all__ = [
    "restart_agent_detached",
    "_build_restart_command",
    "_gateway_running",
    "_systemd_managed",
]
