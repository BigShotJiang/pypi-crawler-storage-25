"""Shared slash-command parsing + formatting for rtxclaw frontends.

The runtime owns command semantics; frontends should only adapt the
returned result to their UI surface (TUI widgets, Telegram messages,
plain JSON, etc.). Keep this module mostly pure so Telegram, the TUI,
and API endpoint do not drift in validation or wording.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


REASONING_VALID = {"off", "on", "stream"}
MODE_VALID = {"auto", "ask", "plan"}
TOOL_OUTPUT_VALID = {"on", "off"}


@dataclass(slots=True)
class ParsedCommand:
    raw: str
    name: str
    arg: str = ""


@dataclass(slots=True)
class CommandResult:
    ok: bool
    command: str
    text: str = ""
    data: dict[str, Any] = field(default_factory=dict)
    state_patch: dict[str, Any] = field(default_factory=dict)
    ui: dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "ok": self.ok,
            "command": self.command,
            "text": self.text,
            "data": self.data,
            "state_patch": self.state_patch,
            "ui": self.ui,
        }
        if self.error:
            payload["error"] = self.error
        return payload


def parse_command(text: str) -> Optional[ParsedCommand]:
    raw = (text or "").strip()
    if not raw.startswith("/"):
        return None
    head, _, arg = raw.partition(" ")
    # Telegram may send /cmd@BotName in groups.
    cmd = head.split("@", 1)[0].lower()
    aliases = {
        "/models": "models",
        "/model": "model",
        "/reason": "reasoning",
        "/reasoning": "reasoning",
        "/thinking": "thinking",
        "/on": "reasoning",
        "/off": "reasoning",
        "/stream": "reasoning",
        "/mode": "mode",
        "/status": "status",
        "/help": "help",
        "/new": "new",
        "/sessions": "sessions",
        "/history": "history",
        "/refresh": "refresh",
        "/abort": "abort",
        "/stop": "abort",
        "/compact": "compact",
        "/todo": "todo",
        "/todos": "todo",
        "/restart": "restart",
        "/tool": "tool",
        "/tools": "tool",
        "/context": "context",
        "/ctx": "context",
        "/skills": "skills",
        "/skill": "skills",
        "/commands": "commands",
        "/plugin": "plugin",
        "/plugins": "plugin",
        "/mcp": "mcp",
        "/mcps": "mcp",
        "/subagents": "subagents",
        "/monitors": "monitors",
        "/shells": "monitors",
    }
    name = aliases.get(cmd, cmd[1:])
    if cmd in ("/on", "/off", "/stream") and not arg.strip():
        arg = cmd[1:]
    return ParsedCommand(raw=raw, name=name, arg=arg.strip())


def normalize_reasoning_level(raw: str) -> Optional[str]:
    key = (raw or "").strip().lower().replace("_", "-")
    if key in ("off", "false", "no", "0", "hide", "hidden", "disable", "disabled"):
        return "off"
    if key in ("on", "true", "yes", "1", "show", "visible", "enable", "enabled"):
        return "on"
    if key in ("stream", "streaming", "draft", "live"):
        return "stream"
    return None


def normalize_mode(raw: str) -> Optional[str]:
    key = (raw or "").strip().lower()
    return key if key in MODE_VALID else None


def normalize_thinking(raw: str) -> Optional[bool]:
    key = (raw or "").strip().lower().replace("_", "-")
    if key in ("on", "true", "yes", "1", "enable", "enabled"):
        return True
    if key in ("off", "false", "no", "0", "disable", "disabled"):
        return False
    return None


def normalize_tool_output(raw: str) -> Optional[str]:
    """Three-state tool-output visibility:

    * ``"off"``    — hide everything tool-related (no header, no body)
    * ``"on"``     — show the tool-call header (``🔧 <title>…``) but
                     NOT the raw body the tool returned. The model's
                     prose answer (which may quote results) still
                     lands; only the raw tool payload is suppressed.
    * ``"stream"`` — show BOTH the call header AND the raw body
                     streaming as the tool produces it.

    Returns the canonical token or ``None`` on unknown input. Direct-
    dispatch tools (``delegate_claude`` / ``delegate_codex`` /
    ``compact_context``) IGNORE this gate — their body IS the
    answer; suppressing it would leave the chat empty.
    """
    key = (raw or "").strip().lower().replace("_", "-")
    if key in ("off", "false", "no", "0", "hide", "hidden", "disable", "disabled"):
        return "off"
    if key in ("on", "true", "yes", "1", "show", "visible", "enable", "enabled",
               "header", "headers"):
        return "on"
    if key in ("stream", "streaming", "live", "verbose", "all"):
        return "stream"
    return None


def format_help() -> str:
    return (
        "rtxclaw — quick reference\n\n"
        "Slash commands:\n"
        "  /help                 — this card\n"
        "  /new                  — abort + start a new session\n"
        "  /abort, /stop         — kill the current generation\n"
        "  /status               — session + mode + active turn\n"
        "  /models               — list configured models\n"
        "  /model <alias|url>    — switch this session model\n"
        "  /mode [plan|ask|auto] — show / cycle / set permission mode\n"
        "  /reasoning [on|off|stream] — reasoning visibility (default off)\n"
        "  /on, /off, /stream    — shortcuts for /reasoning <level>\n"
        "  /thinking [on|off]    — enable/disable model thinking\n"
        "  /tool [on|off]        — tool-output visibility (default off)\n"
        "  /compact              — compact saved session context\n"
        "  /skills               — list installed skills\n"
        "  /skill <name>         — show one skill's SKILL.md body\n"
        "  /commands             — list file-based slash commands\n"
        "  /<command> [args]     — run a file command (commands/*.md)\n"
        "  /plugin list                       — list installed plugins\n"
        "  /plugin search <query>             — search the plugin marketplace (skills/hooks/mcp/...)\n"
        "  /plugin install <name|url|path>    — install a plugin (skills+commands+hooks+agents+mcp)\n"
        "  /plugin enable|disable|remove <n>  — toggle / uninstall a plugin\n"
        "  /mcp [filter]                      — list MCP servers (config + ~/.claude/.mcp.json + plugins)\n"
        "  /subagents [N]        — list / enter delegated subagent sessions\n"
        "  /monitors, /shells    — live panel of background shells the model spawned\n"
        "  /todo                 — show this session's todo checklist\n"
        "  /context [list|detail|json] — context breakdown (chars + tokens)\n"
        "  /sessions [i|hash]    — list/switch saved sessions\n"
        "  /history [N]          — show recent turns\n"
        "  /refresh              — show/catch up current session state\n"
        "  /restart              — restart the gateway (detached helper)\n"
        "  /claude <prompt>      — delegate to Claude Code where available\n\n"
        "Permission modes: plan = research only · ask = prompt on writes · auto = autonomous"
    )


def format_status(data: dict[str, Any]) -> str:
    keys = ("agent", "upstream", "backend", "model", "mode", "reasoning", "thinking", "tool", "session", "active_turn")
    return "\n".join(f"{k}: {data.get(k, '?')}" for k in keys if k in data)


CONTEXT_SUBCOMMANDS = {"", "help", "list", "show", "detail", "deep", "json"}


def normalize_context_subcommand(arg: str) -> str:
    """Normalize ``/context <sub>`` → canonical subcommand.

    Mirrors OpenClaw's ``parseContextArgs`` behavior. Returns ``""`` for
    the bare ``/context`` (help mode), ``"list"`` / ``"detail"`` /
    ``"json"`` for the breakdown modes, or the raw token if unknown so
    the handler can render an "Unknown /context mode" error.
    """
    raw = (arg or "").strip().lower()
    if not raw:
        return ""
    head = raw.split()[0]
    return head


def format_model_list(
    rows: list[dict[str, Any]],
    *,
    current_endpoint: str = "",
    current_model: str = "",
) -> str:
    lines = ["configured models:"]
    current_norm = (current_endpoint or "").rstrip("/")
    for m in rows:
        alias = m.get("alias") or "?"
        # ``/v1/models`` auto-discovery has been removed — every row
        # now requires an explicit ``id``. Surface ``(missing id)``
        # for any row that still has an empty id so the operator
        # spots the misconfig before they try to /model it.
        model_id = m.get("id") or "(missing id)"
        backend = m.get("backend") or "?"
        url = (m.get("baseUrl") or "").rstrip("/")
        ctx = int(m.get("contextWindow") or 0)
        ctx_label = f"{ctx // 1024}k" if ctx else "?"
        mark = "● " if url and url == current_norm else "  "
        caps = m.get("capabilities") or []
        cap_label = ""
        if isinstance(caps, list) and caps:
            cap_label = " · " + ",".join(
                str(c).strip() for c in caps if str(c).strip()
            )
        lines.append(f"{mark}{alias}: {model_id} · {backend} · ctx={ctx_label}{cap_label}")
        lines.append(f"    {url or '(no baseUrl)'}")
    lines.append("")
    lines.append("switch: /model <alias|url>  (list anytime with /models)")
    if current_model:
        lines.append(f"current: {current_model}")
    return "\n".join(lines)


def resolve_model_row(cfg: Any, arg: str) -> Optional[dict[str, Any]]:
    """Resolve `/model <arg>` without silently falling back on typos.

    `AgentConfig.resolve_model()` intentionally falls back to the primary
    model for compatibility. Commands need stricter behavior so a typo —
    e.g. `/model gpu-aa` when the alias is `gpu-a` — reports an error
    instead of silently switching to the default.
    """
    target = (arg or "").strip()
    if not target:
        return None
    if target.startswith("http"):
        return cfg.resolve_model(target)
    rows = list(getattr(cfg, "models", None) or [])
    if not rows:
        primary = cfg._primary_model_row()
        if target == (primary.get("alias") or ""):
            return primary
        return None
    for row in rows:
        if target == (row.get("alias") or ""):
            return dict(row)
    return None


def model_switch_text(result: dict[str, Any]) -> str:
    model_id = result.get("id") or result.get("model") or "(missing id)"
    url = result.get("baseUrl") or result.get("endpoint") or "?"
    ctx = int(result.get("contextWindow") or 0)
    ctx_label = f" · ctx={ctx // 1024}k" if ctx else ""
    msg = f"model → {model_id}\n{url}{ctx_label}"
    warn = result.get("upstream_error")
    if warn:
        msg += f"\nupstream warn: {str(warn)[:120]}"
    return msg
