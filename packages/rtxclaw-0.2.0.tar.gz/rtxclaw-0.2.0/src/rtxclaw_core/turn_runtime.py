"""Turn lifecycle + prompt-build pipeline + session-helper utilities.

This module owns the **session-lifecycle** layer: top-level helpers
(prompt-compose, compaction, plan-pass, distillation, loop-detector)
and `TurnState`. The daemon / wire layer lives in
`rtxclaw_agent.runtime`. Direction is one-way: `rtxclaw_agent.runtime`
imports from this module, never the reverse.
"""
from __future__ import annotations

import asyncio
import concurrent.futures
import json
import math
import os
import secrets
import signal
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Optional

import httpx

from rtxclaw_core.agent import AgentConfig
from rtxclaw_core.context import load_system_prompt
from rtxclaw_core.session import Session



def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _publish_turn_completed(
    sess: "Session", user: Any, content: Any, cfg: "AgentConfig",
) -> None:
    """Best-effort `turn_completed` publish on the in-process bus.

    Called from every site where a successful turn lands on disk
    (`sess.add_turn` followed by `sess.save`). Memory providers
    subscribe via `memory_manager.MemoryManager.wire_events()` and
    use the payload to drive `provider.sync_turn(user, assistant)`
    — auto-fact extraction in the default sqlite_facts provider.

    Capped at 5000 chars per side so a runaway turn can't push huge
    payloads onto the bus. List-shaped multi-part `user` values are
    flattened to their text parts only (vision images skipped).
    Failures here are swallowed: this is downstream notification, not
    part of the durable save contract.
    """
    try:
        if isinstance(user, list):
            user_text = "\n".join(
                str(p.get("text") or "")
                for p in user
                if isinstance(p, dict)
                and str(p.get("type") or "").lower() == "text"
            )
        else:
            user_text = str(user or "")
        assistant_text = str(content or "")
        from rtxclaw_core.event_bus import get_bus
        get_bus().publish("turn_completed", {
            "session_hash": sess.hash,
            "agent_home": str(cfg.home),
            "user": user_text[:5000],
            "assistant": assistant_text[:5000],
            "workspace_origin": sess.workspace_origin,
        })
    except Exception:  # noqa: BLE001
        pass


def _spawn_detached_restart(agent_name: str) -> int:
    """Fire off a detached child that waits ~1s, then calls
    `rtxclaw agent restart <agent_name>`. Returns its PID.

    Used by the `/restart` slash command. The wait matters: the
    gateway's HTTP response must flush BEFORE `agent stop` SIGTERMs
    the daemon, otherwise the caller sees a connection reset and the
    Telegram bot reports "command failed". `start_new_session=True`
    detaches the helper so killing this process leaves it running.
    """
    import shlex
    import subprocess

    cmd = (
        "sleep 1; exec "
        f"{shlex.quote(sys.executable)} -m rtxclaw agent restart "
        f"{shlex.quote(agent_name)}"
    )
    proc = subprocess.Popen(  # noqa: S603
        ["/bin/sh", "-c", cmd],
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
        close_fds=True,
    )
    return proc.pid


def _new_turn_id() -> str:
    return secrets.token_hex(6)


def _has_image(content: Any) -> bool:
    """True if an OpenAI-style content blob carries any image part.

    User content can be either:
      - a plain string (text only — never matches)
      - a list of multi-part dicts, each with `type` and a payload key.
        Vision payloads use `type=="image_url"` (Chat Completions) or
        `type=="input_image"` (Responses-API style). Both count as images.

    Anything else (None, dict, bytes, etc.) returns False so a
    malformed payload doesn't accidentally trigger a model swap.
    """
    if not isinstance(content, list):
        return False
    for part in content:
        if not isinstance(part, dict):
            continue
        ptype = str(part.get("type") or "").lower()
        if ptype in ("image_url", "input_image"):
            return True
    return False


# --- streaming loop detector ---------------------------------------------
#
# Catches degenerative repetition in the reasoning stream BEFORE the
# model runs out of thinking budget, because repetition self-reinforces
# (arXiv 2512.04419, "Let's Let's Let's…" OpenReview lPwsHTEPQ9): once
# the model loops once, it gets monotonically more likely to loop
# again. The longer we wait, the
# harder recovery is. The detector runs O(n) over a rolling window of
# the reasoning buffer; the streaming loop only invokes it every
# LOOP_CHECK_STRIDE chars to keep amortised cost bounded.
#
# Algorithm: count occurrences of fixed-length substrings (n-grams) in
# the recent suffix of the buffer. If any n-gram appears at least
# LOOP_REPEAT_THRESHOLD times in the last LOOP_WINDOW_CHARS, the model
# is in a loop and the upstream stream is SIGTERM'd.
#
# Tunables are env-overridable so an operator can A/B without a code
# change. Defaults are conservative (long n-gram + many repeats) to
# avoid false positives on legitimate self-quoting like "as noted
# above…" or repeating tool-result snippets.

def _env_int(name: str, default: int) -> int:
    """Parse an int from `os.environ[name]`, falling back to `default`
    on missing OR garbage values. The agent imports this module at
    boot, and a bad env var would otherwise crash startup with a
    `ValueError` that doesn't name the offending knob clearly.
    """
    raw = os.environ.get(name)
    if raw is None or raw == "":
        return default
    try:
        return int(raw)
    except (TypeError, ValueError):
        # Fall back silently — operator typo'd a tunable, the agent
        # still starts. The whole reason the var is configurable is
        # to be opt-in; defaults must work without it.
        import logging as _logging
        _logging.getLogger("rtxclaw.config").warning(
            "ignoring bad env %s=%r; using default %s", name, raw, default,
        )
        return default


def _env_float(name: str, default: float) -> float:
    raw = os.environ.get(name)
    if raw is None or raw == "":
        return default
    try:
        return float(raw)
    except (TypeError, ValueError):
        import logging as _logging
        _logging.getLogger("rtxclaw.config").warning(
            "ignoring bad env %s=%r; using default %s", name, raw, default,
        )
        return default


LOOP_NGRAM_LEN: int = _env_int("RTXCLAW_LOOP_NGRAM_LEN", 60)
LOOP_REPEAT_THRESHOLD: int = _env_int("RTXCLAW_LOOP_REPEAT_THRESHOLD", 4)
LOOP_WINDOW_CHARS: int = _env_int("RTXCLAW_LOOP_WINDOW_CHARS", 1500)
LOOP_MIN_CONTEXT_CHARS: int = _env_int("RTXCLAW_LOOP_MIN_CONTEXT_CHARS", 1500)
LOOP_CHECK_STRIDE: int = _env_int("RTXCLAW_LOOP_CHECK_STRIDE", 300)
LOOP_TIGHT_NGRAM_LEN: int = _env_int("RTXCLAW_LOOP_TIGHT_NGRAM_LEN", 8)
LOOP_TIGHT_REPEAT_THRESHOLD: int = _env_int("RTXCLAW_LOOP_TIGHT_REPEAT_THRESHOLD", 8)
LOOP_TIGHT_MIN_CONTEXT_CHARS: int = _env_int("RTXCLAW_LOOP_TIGHT_MIN_CONTEXT_CHARS", 80)
LOOP_TIGHT_WINDOW_CHARS: int = _env_int("RTXCLAW_LOOP_TIGHT_WINDOW_CHARS", 240)
LOOP_ENTROPY_WINDOW: int = _env_int("RTXCLAW_LOOP_ENTROPY_WINDOW", 200)
LOOP_ENTROPY_BITS: float = _env_float("RTXCLAW_LOOP_ENTROPY_BITS", 2.5)
# Set RTXCLAW_LOOP_DETECT=0 to disable the loop detector entirely
# (e.g. during distill itself, since enable_thinking=False distillers
# never emit reasoning anyway, but a stray hook could mis-fire).
LOOP_DETECT_ENABLED: bool = os.environ.get(
    "RTXCLAW_LOOP_DETECT", "1",
) not in ("0", "false", "False")
PRESEND_SCAN_ENABLED: bool = os.environ.get(
    "RTXCLAW_LOOP_PRESEND_SCAN", "1",
) not in ("0", "false", "False")
DISTILL_RECOVERY_ENABLED: bool = os.environ.get(
    "RTXCLAW_LOOP_DISTILL_RECOVERY", "1",
) not in ("0", "false", "False")


def _detect_reasoning_loop(
    buf_text: str,
    *,
    ngram_len: int = LOOP_NGRAM_LEN,
    repeat_threshold: int = LOOP_REPEAT_THRESHOLD,
    window_chars: int = LOOP_WINDOW_CHARS,
    min_context_chars: int = LOOP_MIN_CONTEXT_CHARS,
) -> Optional[str]:
    """Return the offending n-gram if the suffix of `buf_text` shows
    degenerative repetition, else None.

    Pure function: no I/O, no side effects, fully testable. The streaming
    loop calls it on the joined `turn.thinking_buf`; we only inspect the
    last `window_chars` characters so the cost is bounded regardless of
    how long the round runs.

    Heuristic: slide a window of length `ngram_len` over the suffix and
    count occurrences. If the most-frequent n-gram appears at least
    `repeat_threshold` times, treat it as a loop. We require the buffer
    to have at least `min_context_chars` before firing so a short
    legitimate repetition (e.g. early in the CoT, "Let me re-check —
    let me re-check") doesn't trip the detector.

    The detector is intentionally simple — Tier 1 of the literature's
    repetition-detection ladder (n-gram counting; SpecRA-style FFT
    autocorrelation is Tier 2 and would only be added if Tier 1 has
    too many false negatives in production).
    """
    if not buf_text or len(buf_text) < min_context_chars:
        return None
    suffix = buf_text[-window_chars:] if len(buf_text) > window_chars else buf_text
    if len(suffix) < ngram_len * repeat_threshold:
        # Not enough material for `repeat_threshold` non-overlapping
        # occurrences even in the worst case.
        return None
    counts: dict[str, int] = {}
    n = ngram_len
    # Step by 1 so overlapping repetitions still count. Most loops are
    # exact repeats so the dominant n-gram emerges quickly.
    for i in range(len(suffix) - n + 1):
        ng = suffix[i:i + n]
        counts[ng] = counts.get(ng, 0) + 1
        if counts[ng] >= repeat_threshold:
            # Skip n-grams that are mostly whitespace / formatting (e.g.
            # 60 spaces in a markdown table). They're usually false
            # positives — formatting chrome, not reasoning.
            stripped = ng.strip()
            if len(stripped) < n // 2:
                continue
            # Skip n-grams that look like a single repeated character
            # (e.g. "==============…", a markdown rule).
            if len(set(stripped)) <= 2:
                continue
            return ng
    return None


def _detect_tight_loop(
    buf_text: str,
    *,
    ngram_len: int = LOOP_TIGHT_NGRAM_LEN,
    repeat_threshold: int = LOOP_TIGHT_REPEAT_THRESHOLD,
    window_chars: int = LOOP_TIGHT_WINDOW_CHARS,
    min_context_chars: int = LOOP_TIGHT_MIN_CONTEXT_CHARS,
) -> Optional[str]:
    """Tier-0 detector for short repeated units such as token collapse."""
    if not buf_text or len(buf_text) < min_context_chars:
        return None
    suffix = buf_text[-window_chars:] if len(buf_text) > window_chars else buf_text
    if len(suffix) < ngram_len * repeat_threshold:
        return None
    counts: dict[str, int] = {}
    n = ngram_len
    for i in range(len(suffix) - n + 1):
        ng = suffix[i:i + n]
        counts[ng] = counts.get(ng, 0) + 1
        if counts[ng] >= repeat_threshold:
            stripped = ng.strip()
            if len(stripped) < n // 2:
                continue
            if len(set(stripped)) <= 2:
                continue
            return ng
    return None


def _detect_entropy_collapse(buf_text: str) -> Optional[str]:
    """Tier-2 detector for low-entropy collapse in the recent suffix."""
    if len(buf_text) < LOOP_ENTROPY_WINDOW:
        return None
    suffix = buf_text[-LOOP_ENTROPY_WINDOW:]
    counts: dict[str, int] = {}
    for ch in suffix:
        counts[ch] = counts.get(ch, 0) + 1
    if len(counts) <= 2:
        return None
    total = len(suffix)
    entropy = 0.0
    for count in counts.values():
        p = count / total
        entropy -= p * math.log2(p)
    if entropy >= LOOP_ENTROPY_BITS:
        return None
    return f"H={entropy:.2f}bits unique={len(counts)}"


def _detect_loops_layered(buf_text: str) -> Optional[tuple[str, str]]:
    """Run loop detectors in tight-to-loose priority order."""
    if not LOOP_DETECT_ENABLED:
        return None
    evidence = _detect_tight_loop(buf_text)
    if evidence is not None:
        return ("tight", evidence)
    evidence = _detect_reasoning_loop(buf_text)
    if evidence is not None:
        return ("ngram", evidence)
    evidence = _detect_entropy_collapse(buf_text)
    if evidence is not None:
        return ("entropy", evidence)
    return None


# Distiller prompt body lives in ``<home>/DISTILL.md`` (operator-
# editable), loaded fresh on every recovery call via
# ``load_prompt_pair``. The file uses ``<!-- system -->`` / ``<!--
# user -->`` markers; the user section may carry ``{user}`` and
# ``{thinking}`` placeholders that this module fills in. If the file
# is missing or either section is empty, ``_distill_partial_reasoning``
# raises so the caller can fall through to its non-distill recovery
# path rather than send a half-formed prompt to the model.

# Distiller's own sampling. Diverges from the main turn's defaults on
# purpose:
#   - `enable_thinking=True` — Qwen 3.6 27B's no-thinking mode is
#     materially weaker on synthesis tasks, and a clean structured
#     summary IS a synthesis task. The thinking_budget cap below
#     prevents the distiller from inheriting the main turn's loop.
#   - `temperature=0.2` — distill is deterministic synthesis; we want
#     the same JSON shape every time, not creative paraphrase.
#   - `presence_penalty=1.0` — explicitly bumps above Qwen's
#     thinking-mode default (0.0) to break any residual repetition the
#     model might inherit from re-reading a 30k+ char looped CoT. The
#     official Qwen warning ("PP>1 hurts thinking-mode quality") is
#     accepted as the price of admission for a recovery path that
#     would otherwise risk re-looping. PP=1.0 is conservative — Qwen
#     itself uses 1.5 in instruct mode, so 1.0 in thinking mode is
#     a middle-ground operating point.
#   - `thinking_budget=2048` — modest hard cap; the distiller has the
#     trace in front of it and only needs to extract structure, not
#     re-derive. If the model emits a thinking-only stop here, the
#     caller catches the empty-content branch and surfaces the
#     failure (recovery cannot itself recursively recover).
_DISTILL_PRESENCE_PENALTY: float = _env_float("RTXCLAW_DISTILL_PRESENCE_PENALTY", 1.0)
_DISTILL_THINKING_BUDGET: int = _env_int("RTXCLAW_DISTILL_THINKING_BUDGET", 2048)


# Built-in fallback distiller prompt — used when the agent's
# ``<home>/DISTILL.md`` is missing or empty. Mirrors the shape of
# ``main``'s on-disk template so newly-scaffolded sub-agents (e.g.
# ``coder``) recover from loops out of the box. Operators can still
# override per-agent by dropping a real ``DISTILL.md`` into the
# agent's home — the file-based load wins when present.
_DEFAULT_DISTILL_SYSTEM: str = (
    "You compress in-progress reasoning into a structured handoff so "
    "a downstream model can finish the reply without re-deriving "
    "anything. The downstream model will VERIFY the facts you list, "
    "so do not over-claim — only state what the reasoning trace "
    "actually established. Mark anything still uncertain in "
    "`open_questions`. Output a SINGLE JSON object matching this "
    "schema and nothing else — no preamble, no markdown fences, no "
    "commentary:\n"
    "{\n"
    "  \"established_facts\": [\"...\", \"...\"],\n"
    "  \"open_questions\":    [\"...\", \"...\"],\n"
    "  \"next_action\":       \"...\"\n"
    "}\n"
    "Each bullet must be ONE concise sentence. Empty arrays / empty "
    "string are valid when the reasoning genuinely produced nothing "
    "in that category."
)
_DEFAULT_DISTILL_USER: str = (
    "The reasoning below was produced for the user request:\n"
    "<user_request>\n{user}\n</user_request>\n\n"
    "It was cut off before a final answer (the model either looped, "
    "ran out of thinking budget, or stopped without writing the "
    "reply). Extract a structured JSON handoff per the schema in the "
    "system prompt:\n"
    "- `established_facts`: claims supported by tool results / "
    "context in the trace below. NOT speculation.\n"
    "- `open_questions`: things the trace was uncertain about, or "
    "that would need re-verification before relying on.\n"
    "- `next_action`: the single most concrete next step the trace "
    "was moving toward — a tool call, a sub-question, or the final "
    "answer shape — in one sentence.\n\n"
    "REASONING SO FAR:\n"
    "<thinking>\n{thinking}\n</thinking>\n"
)


# --- plan-pass for complex turns --------------------------------------
#
# Plan-and-Act pattern (arXiv 2503.09572) applied to a single-model
# setup: when the user's turn looks like planning, run a one-shot
# planner call BEFORE the main reasoning+tool loop, with high thinking
# budget and no tools, asking the model to break the task into ≤5
# ordered subtasks. The resulting plan is injected as a `[PLAN]`
# scaffold so every subsequent round of the main loop has narrower
# per-step scope (which empirically reduces loop frequency on small
# models).
#
# Activation has two tiers:
#   1. FAST SKIP (zero cost) — short prompts that match a greeting /
#      ack / single-word-imperative regex. No upstream call.
#   2. CLASSIFIER (one ~500ms LLM call) — everything else asks the
#      upstream model to classify the prompt. JSON output:
#      `{plan_pass, kind, reason}`. On classifier failure the gate
#      fails CLOSED (no plan-pass) — better to skip than to fire on
#      a wrong heuristic.
#
# (Plan-pass / classifier was removed 2026-05-06 — the model now
# calls the canonical ``TodoWrite`` tool when it identifies multi-step
# work, instead of the bridge running mandatory pre-prompt LLM rounds.
# The persistent injections below — pinned facts + compaction summary
# — still apply between system prompt and live conversation tail.)


# Cap on persistent injection blocks so a runaway compaction summary
# or pinned-facts list can't push the cache prefix past the model's
# context window.
_PINNED_FACTS_MAX_CHARS: int = _env_int(
    "RTXCLAW_PINNED_FACTS_MAX_CHARS", 2000,
)
_COMPACTION_SUMMARY_MAX_CHARS: int = _env_int(
    "RTXCLAW_COMPACTION_SUMMARY_MAX_CHARS", 3000,
)


def _inject_pinned_facts(
    messages: list[dict],
    pinned_facts: list[str],
    *,
    max_chars: int = _PINNED_FACTS_MAX_CHARS,
) -> list[dict]:
    """Insert a `[PINNED FACTS]` user message right after the system
    prompt so the model sees these facts on every round, regardless of
    compaction.

    Rendered shape:
        [PINNED FACTS — survive every compaction; do not contradict]
        - fact 1
        - fact 2
        - …

    Idempotent: if a `[PINNED FACTS]` message is already present at the
    expected slot, it's REPLACED rather than duplicated. If
    `pinned_facts` is empty, any prior pinned-facts message is removed.
    Truncates to `max_chars` chars to keep the prompt budget bounded.
    """
    out = list(messages)
    sys_idx = 0 if out and out[0].get("role") == "system" else -1
    insert_idx = sys_idx + 1
    # Strip any existing pinned-facts marker.
    stripped = []
    for i, m in enumerate(out):
        c = m.get("content")
        if (
            isinstance(c, str)
            and c.startswith("[PINNED FACTS")
            and m.get("role") == "user"
        ):
            continue
        stripped.append(m)
    out = stripped
    if not pinned_facts:
        return out
    body = "\n".join(f"- {f}" for f in pinned_facts if str(f).strip())
    if not body:
        return out
    rendered = (
        "[PINNED FACTS — survive every compaction; do not contradict]\n"
        f"{body}"
    )
    if len(rendered) > max_chars:
        rendered = rendered[: max_chars - 3] + "..."
    msg = {"role": "user", "content": rendered}
    return out[:insert_idx] + [msg] + out[insert_idx:]


def _inject_compaction_summary(
    messages: list[dict],
    compaction_summary: str,
) -> list[dict]:
    """Insert the rolling cross-compaction summary right after pinned
    facts (or the system prompt if there are no pinned facts). Keeps
    one slot per session — replaces any existing
    `[ROLLING COMPACTION SUMMARY]` message in place.

    The point of having both this AND the in-turn `_splice_summary`
    (which compresses the CURRENT history into a single 'EARLIER
    CONVERSATION SUMMARY' message) is that `_splice_summary` only
    captures what was in the prompt at THIS compaction time. When
    successive compactions fire, each new in-turn summary's input is
    the previous summary plus new turns — so old facts can drop out
    silently. The rolling summary persists across compactions, gets
    merged forward, and acts as a long-term memory floor.
    """
    if not compaction_summary or not compaction_summary.strip():
        return list(messages)
    out = list(messages)
    # Strip any existing rolling summary marker.
    stripped = []
    for m in out:
        c = m.get("content")
        if (
            isinstance(c, str)
            and c.startswith("[ROLLING COMPACTION SUMMARY")
            and m.get("role") == "user"
        ):
            continue
        stripped.append(m)
    out = stripped
    sys_idx = 0 if out and out[0].get("role") == "system" else -1
    # Insert AFTER pinned facts if present.
    insert_idx = sys_idx + 1
    while (
        insert_idx < len(out)
        and out[insert_idx].get("role") == "user"
        and isinstance(out[insert_idx].get("content"), str)
        and out[insert_idx]["content"].startswith("[PINNED FACTS")
    ):
        insert_idx += 1
    rendered = (
        "[ROLLING COMPACTION SUMMARY — persistent memory floor across "
        "compactions; treat as already-established context]\n"
        + compaction_summary.strip()
    )
    msg = {"role": "user", "content": rendered}
    return out[:insert_idx] + [msg] + out[insert_idx:]


def _inject_current_todos(
    messages: list[dict],
    todos: list[dict],
) -> list[dict]:
    """Insert a `[CURRENT TODO LIST]` user message after the system
    prompt (and after pinned facts / rolling summary if present), so
    the model sees the live plan on every round.

    Without this, prior turns are replayed via ``_build_messages`` using
    only the assistant's final text — tool calls and tool results are
    dropped. When a prior turn aborted with no final text, the model
    starts the next turn with zero visibility into the persisted
    ``.todos.json`` and dutifully calls ``todo(replace=…)`` again,
    overwriting the prior plan with a near-duplicate. This injection
    surfaces the existing list so the model picks ``complete``/``add``
    instead.

    Idempotent: replaces any prior `[CURRENT TODO LIST]` message at the
    same slot. Empty/missing list → strips any prior marker (so a
    completed-and-cleared plan disappears from the prefix on the next
    round).
    """
    out = list(messages)
    # Strip any existing marker.
    out = [
        m for m in out
        if not (
            m.get("role") == "user"
            and isinstance(m.get("content"), str)
            and m["content"].startswith("[CURRENT TODO LIST")
        )
    ]
    if not todos:
        return out
    sys_idx = 0 if out and out[0].get("role") == "system" else -1
    insert_idx = sys_idx + 1
    # Insert AFTER pinned facts and rolling summary if present.
    while (
        insert_idx < len(out)
        and out[insert_idx].get("role") == "user"
        and isinstance(out[insert_idx].get("content"), str)
        and (
            out[insert_idx]["content"].startswith("[PINNED FACTS")
            or out[insert_idx]["content"].startswith("[ROLLING COMPACTION SUMMARY")
        )
    ):
        insert_idx += 1
    lines = []
    for i, t in enumerate(todos):
        mark = "x" if t.get("status") == "done" else " "
        content = (t.get("content") or "").strip()
        if content:
            lines.append(f"- [{mark}] {i}: {content}")
    if not lines:
        return out
    rendered = (
        "[CURRENT TODO LIST — persisted from earlier in this session; "
        "to make changes call `TodoWrite` with action=complete/add/delete. "
        "Do NOT call action=replace unless starting a fresh, unrelated task]\n"
        + "\n".join(lines)
    )
    msg = {"role": "user", "content": rendered}
    return out[:insert_idx] + [msg] + out[insert_idx:]


def _merge_compaction_summary(
    prior: str,
    fresh: str,
    *,
    max_chars: int = _COMPACTION_SUMMARY_MAX_CHARS,
) -> str:
    """Deterministic rolling merge of the cross-compaction summary.

    The fresh per-compaction summary already covers everything that
    was visible at this compaction; we keep the prior rolling summary
    as a "this is what older compactions established" prefix and
    append a "...and most recently:" tail. If the combined length
    exceeds `max_chars`, the prior summary is truncated tail-first
    (oldest content drops earliest). Pure deterministic: an LLM-based
    re-summarisation would be more accurate but blocks compaction on
    yet another upstream call.
    """
    prior = (prior or "").strip()
    fresh = (fresh or "").strip()
    if not prior:
        return fresh[:max_chars]
    if not fresh:
        return prior[:max_chars]
    sep = "\n\n--- and most recently ---\n\n"
    combined = prior + sep + fresh
    if len(combined) <= max_chars:
        return combined
    # Truncate prior from the FRONT (drop oldest material) until the
    # combined fits. Fresh summary gets to keep its full text. The
    # `[older context truncated]` marker counts against the budget.
    marker = "[older context truncated]\n"
    overhead = len(sep) + len(fresh) + len(marker)
    room_for_prior = max(0, max_chars - overhead)
    if room_for_prior <= 0:
        # Fresh summary alone (with marker + sep) is already at/over the
        # cap. Take the tail of fresh; prior is dropped entirely.
        return fresh[-max_chars:]
    truncated_prior = prior[-room_for_prior:]
    # Drop a leading partial sentence so the truncation point is on
    # a sentence boundary, but only if doing so leaves non-trivial
    # prior content (otherwise the truncation removes everything).
    cut = truncated_prior.find(". ")
    if 0 <= cut < 200 and cut + 2 < len(truncated_prior) - 20:
        truncated_prior = truncated_prior[cut + 2 :]
    out = marker + truncated_prior + sep + fresh
    # Final safety cap — the sentence-boundary trim above can leave us
    # very slightly over budget if `prior` lacked a clean cut point.
    if len(out) > max_chars:
        out = out[-max_chars:]
    return out


def _parse_distill_json(raw: str) -> tuple[Optional[dict], str]:
    """Best-effort JSON extraction from the distiller's output.

    Qwen sometimes wraps JSON in a `<think>` block, in markdown fences,
    or emits a small leading prose preamble despite the system-prompt
    instruction to output JSON only. We try the cheap parses first
    (raw, then strip fences, then locate the first `{` and last `}`)
    and fall through to "raw text fallback" so the caller can decide
    whether to use the structured form or treat the whole blob as the
    legacy free-text distill.

    Returns `(parsed_dict_or_None, fallback_text)`. The dict is None
    when nothing parseable was found; in that case the caller may
    use `fallback_text` (the original raw stripped of fences and
    `<think>` blocks) as a non-structured handoff instead of failing
    outright.
    """
    if not raw:
        return None, ""
    # Strip <think>...</think> blocks — present when the model leaked
    # its reasoning despite the prompt asking for JSON only.
    import re as _re
    cleaned = _re.sub(
        r"<thinking?\b[^>]*>.*?</thinking?\s*>",
        "",
        raw,
        flags=_re.IGNORECASE | _re.DOTALL,
    ).strip()
    # Strip markdown code fences (```json, ```).
    if cleaned.startswith("```"):
        # remove leading fence line and trailing fence
        cleaned = _re.sub(r"^```[a-zA-Z0-9]*\s*\n", "", cleaned, count=1)
        cleaned = _re.sub(r"\n```\s*$", "", cleaned)
        cleaned = cleaned.strip()
    # Try direct JSON parse.
    try:
        obj = json.loads(cleaned)
        if isinstance(obj, dict):
            return obj, cleaned
    except (json.JSONDecodeError, ValueError):
        pass
    # Try locating the first balanced `{...}` block.
    start = cleaned.find("{")
    end = cleaned.rfind("}")
    if start != -1 and end > start:
        candidate = cleaned[start:end + 1]
        try:
            obj = json.loads(candidate)
            if isinstance(obj, dict):
                return obj, candidate
        except (json.JSONDecodeError, ValueError):
            pass
    return None, cleaned


def _format_distill_for_recovery(parsed: Optional[dict], fallback_text: str) -> str:
    """Render a distill result into the recovery-prompt body.

    Structured form (parsed JSON):
        Established facts:
          - …
          - …
        Open questions:
          - …
        Next action: …

    Unstructured fallback: just the raw cleaned text. The recovery
    nudge wraps this with the "verify before relying" instruction.
    """
    if not isinstance(parsed, dict):
        return fallback_text.strip()
    lines: list[str] = []
    facts = parsed.get("established_facts") or []
    if isinstance(facts, list) and facts:
        lines.append("Established facts:")
        for f in facts:
            lines.append(f"  - {str(f).strip()}")
    open_qs = parsed.get("open_questions") or []
    if isinstance(open_qs, list) and open_qs:
        lines.append("Open questions:")
        for q in open_qs:
            lines.append(f"  - {str(q).strip()}")
    nxt = parsed.get("next_action")
    if isinstance(nxt, str) and nxt.strip():
        lines.append(f"Next action: {nxt.strip()}")
    return "\n".join(lines).strip() or fallback_text.strip()


async def _distill_partial_reasoning(
    *,
    endpoint: str,
    model: str,
    headers: dict,
    user_prompt: str,
    thinking: str,
    home: Path,
) -> tuple[str, dict]:
    """Compress an in-flight CoT into a structured JSON handoff.

    Distiller runs with `enable_thinking=True` (Qwen 3.6 27B's
    no-thinking mode degrades synthesis quality) but capped at a
    small `thinking_budget` so it can't inherit the main turn's
    loop, and with `presence_penalty=1.0` to break residual
    repetition the distiller might pick up from re-reading the
    looped CoT. The output is parsed as JSON; on parse failure we
    fall back to the raw text (still useful as a free-form summary).
    Streams the response so a slow upstream never triggers a read
    timeout. Returns
    `(formatted_handoff, debug_info)`. Raises on HTTP/transport failure,
    empty output, or a missing/incomplete ``<home>/DISTILL.md`` —
    recovery cannot itself recursively recover.
    """
    from rtxclaw_core.system_prompt import load_prompt_pair
    prompt_pair = load_prompt_pair(home / "DISTILL.md")
    system_msg = (prompt_pair.get("system") or "").strip()
    user_template = (prompt_pair.get("user") or "").strip()
    if not system_msg or not user_template:
        # Built-in fallback so newly-scaffolded agents (e.g. ``coder``
        # without an authored DISTILL.md) still recover from loops
        # instead of cancelling on first hit. The packaged template
        # mirrors the structure ``main``'s on-disk DISTILL.md uses
        # (system role tells the model what to produce; user role
        # carries the looped trace + original prompt). Operators can
        # override per-agent by dropping a real DISTILL.md into
        # ``<home>/`` — the load above wins when that file exists.
        system_msg = _DEFAULT_DISTILL_SYSTEM
        user_template = _DEFAULT_DISTILL_USER
    try:
        user_msg = user_template.format(
            user=(user_prompt or "(no original user prompt)").strip(),
            thinking=thinking,
        )
    except (KeyError, IndexError) as e:
        raise RuntimeError(
            f"distill skipped: {home}/DISTILL.md template missing "
            f"placeholder: {e}"
        ) from e
    payload = {
        "model": model,
        "stream": True,
        "stream_options": {"include_usage": True},
        "messages": [
            {"role": "system", "content": system_msg},
            {"role": "user", "content": user_msg},
        ],
        "temperature": 0.2,
        "presence_penalty": _DISTILL_PRESENCE_PENALTY,
        "chat_template_kwargs": {
            "enable_thinking": True,
            "thinking_budget": _DISTILL_THINKING_BUDGET,
        },
    }
    url = endpoint.rstrip("/") + "/chat/completions"
    timeout = httpx.Timeout(connect=10.0, read=None, write=10.0, pool=10.0)
    sse_headers = {"Accept": "text/event-stream", **headers}
    started = time.monotonic()
    chunks: list[str] = []
    finish_reason: Optional[str] = None
    usage: dict = {}
    saw_data_line: bool = False
    saw_choices: bool = False
    response_content_type: str = ""
    async with httpx.AsyncClient(timeout=timeout, headers=sse_headers) as c:
        async with c.stream("POST", url, json=payload) as resp:
            if resp.status_code != 200:
                body = (await resp.aread()).decode("utf-8", "replace")[:500]
                raise RuntimeError(
                    f"distill upstream HTTP {resp.status_code}: {body}"
                )
            response_content_type = str(resp.headers.get("content-type") or "")
            async for raw in resp.aiter_lines():
                if not raw or not raw.startswith("data:"):
                    continue
                saw_data_line = True
                data_str = raw[5:].strip()
                if not data_str or data_str == "[DONE]":
                    continue
                try:
                    obj = json.loads(data_str)
                except json.JSONDecodeError:
                    continue
                u = obj.get("usage")
                if isinstance(u, dict):
                    usage = u
                choices = obj.get("choices") or []
                if not choices:
                    continue
                saw_choices = True
                ch0 = choices[0] or {}
                delta = ch0.get("delta") or {}
                piece = delta.get("content")
                if piece:
                    chunks.append(piece)
                fr = ch0.get("finish_reason")
                if fr:
                    finish_reason = fr
    duration_s = round(time.monotonic() - started, 3)
    out = "".join(chunks).strip()
    if not out:
        # Distinguish between failure modes so an operator reading
        # the session record can debug:
        #   - never saw a `data:` line at all → upstream returned a
        #     non-SSE 200 (raw JSON / plain text). Most likely
        #     `stream=true` was ignored or stripped en route, or the
        #     proxy collapsed the SSE response. Surface the response
        #     content-type so they know where to look.
        #   - saw `data:` lines but never any `choices` → SSE was
        #     emitted, but only `usage` / heartbeat frames; the model
        #     produced zero output for this prompt.
        #   - saw choices but `chunks` is empty → all content fields
        #     came back empty/None (model genuinely produced nothing).
        if not saw_data_line:
            raise RuntimeError(
                "no SSE data lines received — check Content-Type and "
                "stream support on the upstream "
                f"(response Content-Type={response_content_type!r}, "
                f"finish_reason={finish_reason!r})"
            )
        if not saw_choices:
            raise RuntimeError(
                "SSE stream carried no `choices` payloads — upstream "
                "responded but produced zero output (usage-only / "
                "heartbeat frames). "
                f"finish_reason={finish_reason!r}"
            )
        raise RuntimeError(
            f"distill returned empty content (finish_reason={finish_reason!r})"
        )
    parsed, fallback_text = _parse_distill_json(out)
    formatted = _format_distill_for_recovery(parsed, fallback_text)
    debug = {
        "duration_s": duration_s,
        "prompt_tokens": usage.get("prompt_tokens"),
        "completion_tokens": usage.get("completion_tokens"),
        "finish_reason": finish_reason,
        "raw_chars": len(out),
        "structured": parsed is not None,
        "established_facts_count": (
            len(parsed.get("established_facts") or [])
            if isinstance(parsed, dict) else 0
        ),
        "open_questions_count": (
            len(parsed.get("open_questions") or [])
            if isinstance(parsed, dict) else 0
        ),
        "next_action_chars": (
            len(parsed.get("next_action") or "")
            if isinstance(parsed, dict) else 0
        ),
    }
    return formatted, debug



def _msg_chars(messages: list[dict]) -> int:
    """Total UTF-8 char count over the JSON-serialized messages list."""
    return sum(len(json.dumps(m, ensure_ascii=False)) for m in messages)


def _user_field_chars(u) -> int:
    """Char count of a `turn.user` field. Multipart user content (an
    OpenAI-style content list, e.g. Telegram photo turns shipped as
    `[image_url, text]`) is JSON-serialized so a 192k-char base64 image
    counts as 192k, not as `len(list) == 2`. The latter mistake made
    `_pretrim_loaded_session_for_overflow` undercount image-heavy
    sessions by ~7×, leaving them stuck at 450k tokens against a 256k
    context (fingerprint: empty-summary on session 69f621f9…).
    """
    if isinstance(u, str):
        return len(u)
    if isinstance(u, (list, dict)):
        try:
            return len(json.dumps(u, ensure_ascii=False))
        except (TypeError, ValueError):
            return 0
    return 0


def _content_has_image(content) -> bool:
    """True if a user content payload is a multipart list with at least
    one `image_url` part. Used to decide whether to strip image bytes
    from older turns when replaying history.
    """
    if not isinstance(content, list):
        return False
    for p in content:
        if isinstance(p, dict) and p.get("type") == "image_url":
            return True
    return False


def _strip_images_from_user_content(content):
    """Replace `image_url` parts in a multipart user content list with a
    short placeholder string. Strings pass through unchanged.

    Why: each saved turn keeps the original `user` payload on disk so
    we can replay the conversation byte-for-byte. For image turns that
    payload includes a `data:image/...;base64,…` URL whose body can
    easily be 100–500 KB. `_build_messages` replays every past turn on
    every subsequent turn, so without stripping a single image bloats
    the prompt by its full size FOREVER. Net effect: 5 image-bearing
    turns ⇒ ~1 MB of base64 sent on every reply, blowing past any
    reasonable context window.

    Strategy: keep text parts, count images, return a single-string
    summary like `"caption text\\n\\n[2 image(s) attached, stripped from
    earlier history]"`. `_build_messages` calls this on every past
    `turn.user`; the live new user message (passed as the `user`
    parameter) still carries the image so the model can describe it
    once, and the model's text description on `turn.content` provides
    full text-only continuity on every replay thereafter.
    """
    if not isinstance(content, list):
        return content
    text_parts: list[str] = []
    image_count = 0
    for part in content:
        if not isinstance(part, dict):
            continue
        ptype = part.get("type")
        if ptype == "text":
            t = part.get("text") or ""
            if t:
                text_parts.append(t)
        elif ptype == "image_url":
            image_count += 1
        # Unknown part types are dropped — conservative: an
        # unrecognised image-like part would re-bloat the history.
    text = "\n".join(text_parts)
    if image_count:
        suffix = (
            f"[{image_count} image(s) attached, "
            f"stripped from earlier history]"
        )
        text = f"{text}\n\n{suffix}" if text else suffix
    return text or "[multipart message]"


def _hash_prefix(messages: list[dict], *, max_chars: int = 1024) -> str:
    """Short hex hash of the JSON-serialized message-list prefix.

    Used by the round logger to detect byte drift across rounds: if
    round N+1's hash differs from round N's, vLLM's prefix cache will
    miss everything from the divergence point forward. The hash covers
    the first `max_chars` characters of the concatenated prefix —
    enough to catch system-prompt drift, tool-schema drift, or
    raw_arguments reorderings without paying the cost of hashing the
    whole prompt.
    """
    import hashlib
    blob: list[str] = []
    written = 0
    for m in messages:
        s = json.dumps(m, ensure_ascii=False, sort_keys=False)
        blob.append(s)
        written += len(s)
        if written >= max_chars:
            break
    text = "".join(blob)[:max_chars]
    return hashlib.sha1(text.encode("utf-8", "replace")).hexdigest()[:12]


def _hash_tools_payload(tools: list[dict]) -> str:
    """Hash of the tool-schemas list — independent from the messages
    hash because tools end up at a different spot in vLLM's chat
    template (typically before the conversation), so they cache
    separately. Lets us tell "tools drifted" apart from "messages
    drifted" when the cache-hit ratio drops.
    """
    import hashlib
    text = json.dumps(tools, ensure_ascii=False, sort_keys=False)
    return hashlib.sha1(text.encode("utf-8", "replace")).hexdigest()[:12]


# Conservative chars-per-token floor. Empirically observed ratios:
#   - dense code/JSON: ~3.5–4.0 chars/token
#   - english prose:   ~4.0+ chars/token
#   - HTML / minified: ~2.5–3.0 chars/token  (the dangerous case — a
#     65 KiB web_fetch payload tokenized to ~25k tokens, ratio 2.6)
# Using 3.0 keeps us safe on prose/code without dramatically over-
# trimming HTML payloads. The proactive compaction guard combines this
# with `compact_at_frac` (default 1.0 — only compact when the request
# would actually overflow the upstream context); HTML-dense rounds
# that slip past the estimate are caught by the post-overflow reactive
# squeeze on a context-length 400.
_FALLBACK_CHARS_PER_TOKEN = 3.0


def _approx_tokens(messages: list[dict], chars_per_token: float = _FALLBACK_CHARS_PER_TOKEN) -> int:
    """Cheap token count for OpenAI-style messages.

    Authoritative counts from upstream `/usage.prompt_tokens` are
    preferred when available (see `session_turn`'s use of
    `last_metrics["prompt_tokens"]`). This estimator is the fallback
    for the very first round and the starting point for the learned
    per-session ratio.
    """
    return int(_msg_chars(messages) / max(0.5, chars_per_token))


def compact_messages(
    messages: list[dict], target_tokens: int,
) -> tuple[list[dict], int, dict]:
    """Squeeze old tool results until estimated tokens ≤ target_tokens.

    Strategy (in order, oldest first):

    1. Replace `role: tool` content > 800 chars with `<truncated>`
       (keep the first 400 chars + `\\n\\n... [N chars trimmed]`).
    2. If still over: drop the truncated `tool` messages entirely
       (oldest first) and the matching `assistant.tool_calls`.
    3. If still over: drop oldest non-system user/assistant turns.

    Always preserves:
    - The `system` message at index 0.
    - The MOST RECENT user message (the live request).
    - The most recent assistant content message (the live answer
      assembling, if mid-loop).

    Returns `(new_messages, removed_tokens_estimate, audit)`. `audit` is:
        {
          "truncated_tool_call_ids": [str, ...],  # stage 1
          "dropped_tool_call_ids":   [str, ...],  # stage 2
          "dropped_turns":           int,         # stage 3
        }
    The TUI uses `audit` to surface, per-call_id, which transcript
    `ToolResultMessage` widgets had their content truncated or dropped
    on the wire even though the local widget still has the original.
    """
    audit = {
        "truncated_tool_call_ids": [],
        "dropped_tool_call_ids": [],
        "dropped_turns": 0,
    }
    if not messages:
        return messages, 0, audit

    before = _approx_tokens(messages)
    if before <= target_tokens:
        return messages, 0, audit

    sys_msg = messages[0] if messages and messages[0].get("role") == "system" else None
    body = messages[1:] if sys_msg is not None else messages[:]

    # Anchor: don't touch the last 2 messages (the user prompt that
    # triggered this round + any assistant we're mid-replying to).
    keep_tail = 2
    if len(body) <= keep_tail:
        return messages, 0, audit

    head = body[:-keep_tail]
    tail = body[-keep_tail:]

    # CRITICAL: vLLM's chat template rejects with HTTP 400 "No user query
    # found in messages." if the prompt has no `user` role anywhere.
    # `keep_tail=2` only protects the tail by position — when the tail
    # is `[assistant_tool_calls, tool_result]` (common after a tool
    # round), the user message lives in `head` and stage 3 will happily
    # pop it. Identify the most-recent user message by reference and
    # protect it through every stage. Bug surfaced as fingerprint
    # `4aea829f` after a `compact_context` tool call mid-turn.
    protected_user: dict | None = None
    for m in reversed(body):
        if m.get("role") == "user":
            protected_user = m
            break

    # Also collect tool_call_ids that live in the kept TAIL window so
    # stage 3 doesn't drop the assistant message that issued them —
    # leaving a tool message with no preceding `assistant.tool_calls`
    # is a separate vLLM 400 ("tool message without preceding assistant
    # tool_call"). We grow this set as stage 2 mutates the head, but
    # the *initial* set captures every tool_call_id referenced by tool
    # messages anywhere in the kept tail.
    tail_tool_call_ids: set[str] = set()
    for m in tail:
        if m.get("role") == "tool":
            tcid = m.get("tool_call_id")
            if isinstance(tcid, str) and tcid:
                tail_tool_call_ids.add(tcid)

    # Stage 1: truncate large tool results.
    for m in head:
        if m.get("role") != "tool":
            continue
        c = m.get("content")
        if isinstance(c, str) and len(c) > 800:
            trimmed = len(c) - 400
            m["content"] = c[:400] + f"\n\n... [compacted: {trimmed} chars trimmed]"
            tcid = m.get("tool_call_id")
            if tcid:
                audit["truncated_tool_call_ids"].append(tcid)
    rebuilt = ([sys_msg] if sys_msg else []) + head + tail
    if _approx_tokens(rebuilt) <= target_tokens:
        return rebuilt, before - _approx_tokens(rebuilt), audit

    # Stage 2: drop tool messages entirely, oldest first. Also drop
    # the matching tool_call entries from the preceding assistant
    # message so the tool_call_id refs don't go dangling.
    while head:
        # Find oldest tool message; drop it. Then walk backward to
        # find its assistant.tool_calls and prune the matching entry.
        idx = next(
            (i for i, m in enumerate(head) if m.get("role") == "tool"),
            None,
        )
        if idx is None:
            break
        tool_call_id = head[idx].get("tool_call_id")
        head.pop(idx)
        if tool_call_id:
            audit["dropped_tool_call_ids"].append(tool_call_id)
            # Promote: it's no longer "truncated", it's gone.
            try:
                audit["truncated_tool_call_ids"].remove(tool_call_id)
            except ValueError:
                pass
        # Strip the corresponding tool_calls[] entry from any earlier
        # assistant message; if that leaves it empty, drop the whole
        # assistant message too — UNLESS it would also drop the
        # protected user (assistants can't be users, but this guards
        # the index math from underflow).
        for j in range(idx - 1, -1, -1):
            a = head[j]
            if a.get("role") == "assistant" and isinstance(a.get("tool_calls"), list):
                a["tool_calls"] = [
                    tc for tc in a["tool_calls"] if tc.get("id") != tool_call_id
                ]
                if not a["tool_calls"] and not (a.get("content") or "").strip():
                    head.pop(j)
                break
        rebuilt = ([sys_msg] if sys_msg else []) + head + tail
        if _approx_tokens(rebuilt) <= target_tokens:
            return rebuilt, before - _approx_tokens(rebuilt), audit

    # Stage 3: drop oldest user/assistant turns until fits — but skip
    # the protected user AND any assistant whose tool_calls reference a
    # tool_call_id still kept in the tail. Dropping such an assistant
    # would dangle the surviving tool message → vLLM 400 "tool message
    # without preceding assistant tool_call". If the only messages
    # left in head are protected, exit; sending a prompt that's still
    # slightly over the soft target just makes the runtime's later
    # max_tokens rescale work harder (or triggers the post-overflow
    # reactive squeeze, which is recoverable).
    def _is_load_bearing_assistant(m: dict) -> bool:
        if m.get("role") != "assistant":
            return False
        tcalls = m.get("tool_calls")
        if not isinstance(tcalls, list):
            return False
        for tc in tcalls:
            if isinstance(tc, dict) and tc.get("id") in tail_tool_call_ids:
                return True
        return False

    while head:
        # Find the oldest message that is NOT the protected user and
        # NOT a load-bearing assistant.
        drop_idx = None
        for i, m in enumerate(head):
            if m is protected_user:
                continue
            if _is_load_bearing_assistant(m):
                continue
            drop_idx = i
            break
        if drop_idx is None:
            # head only contains protected messages; can't compact
            # further without breaking the upstream contract.
            break
        head.pop(drop_idx)
        audit["dropped_turns"] += 1
        rebuilt = ([sys_msg] if sys_msg else []) + head + tail
        if _approx_tokens(rebuilt) <= target_tokens:
            return rebuilt, before - _approx_tokens(rebuilt), audit

    rebuilt = ([sys_msg] if sys_msg else []) + head + tail
    return rebuilt, before - _approx_tokens(rebuilt), audit


def compact_session_data_in_place(
    data: dict,
    *,
    keep_recent: int = 1,
    min_chars: int = 800,
    head_chars: int = 400,
) -> tuple[int, list[str]]:
    """Apply deterministic truncation to oversized tool-call results
    stored on a session dict, in place.

    For every `tool_rounds[].calls[].result` longer than `min_chars`
    in the compactable slice, replace it with the first `head_chars`
    chars + a `[compacted: N chars trimmed]` marker. Preserves the most
    recent `keep_recent` turns intact so the active reasoning context
    keeps full fidelity.

    Returns `(removed_chars, affected_call_ids)`. The latter is the
    list of `tool_call_id`s whose results were trimmed — same shape as
    `compact_messages`'s `audit["truncated_tool_call_ids"]` so callers
    can surface the same TUI badging.

    Single source of truth for two callers:
    - `POST /v1/sessions/{sid}/compact` (between-turn manual via the
      TUI's `/compact` slash command).
    - `_pretrim_loaded_session_for_overflow` (load-time auto-trim
      when a stored session would already overflow upstream's
      context window — see that method's docstring for why).
    """
    turns = data.get("turns") or []
    compactable = (
        turns[:-keep_recent]
        if keep_recent and len(turns) > keep_recent
        else list(turns)
    )
    affected_ids: list[str] = []
    removed_chars = 0
    for turn in compactable:
        for r in turn.get("tool_rounds") or []:
            for c in r.get("calls") or []:
                res = c.get("result")
                if not isinstance(res, str) or len(res) <= min_chars:
                    continue
                trimmed = len(res) - head_chars
                c["result"] = (
                    res[:head_chars]
                    + f"\n\n... [compacted: {trimmed} chars trimmed]"
                )
                removed_chars += trimmed
                cid = c.get("id")
                if cid:
                    affected_ids.append(cid)
    return removed_chars, affected_ids


def _format_compaction_summary(removed: int, audit: dict, new_prompt_tokens: int) -> str:
    """Human-readable one-liner for a compaction tool_result body.

    Used both by the model-callable `compact_context` tool and by the
    `POST /v1/sessions/{sid}/compact` endpoint so the audit reads the
    same way wherever it surfaces.
    """
    n_trunc = len(audit.get("truncated_tool_call_ids") or [])
    n_drop = len(audit.get("dropped_tool_call_ids") or [])
    n_turns = int(audit.get("dropped_turns") or 0)
    bits: list[str] = [f"~{removed} tokens removed", f"prompt now ~{new_prompt_tokens} tokens"]
    if n_trunc:
        bits.append(f"{n_trunc} tool result(s) truncated")
    if n_drop:
        bits.append(f"{n_drop} tool result(s) dropped")
    if n_turns:
        bits.append(f"{n_turns} old turn(s) dropped")
    return "compacted: " + " · ".join(bits)


def _compose_system_prompt(
    cfg: "AgentConfig",
    mode: str,
    *,
    workspace_cwd: str = "",
    workspace_origin: str = "",
) -> str:
    """Assemble the full system prompt — workspace .md files + skills
    + per-session workspace context — with the rtxclaw cache boundary
    marker between the stable head and the dynamic tail.

    This is the single source of truth for what goes into a session's
    system message. It's called:

    - Once at session creation (`create_session`), persisted onto the
      session record's `system_prompt` field.
    - Once per turn from `_build_messages` IFF the cached prompt is
      missing or the active mode changed since it was cached.
    - Once per compaction event (`_reload_system_prompt_in_messages`)
      so a fresh, up-to-date prompt lands at messages[0] when the
      conversation context is reset.

    Layout:
        <WORKSPACE.md>...<MODE-*.md><skills>
        <RTXCLAW_CACHE_BOUNDARY>
        <# WORKSPACE-CONTEXT>

    Why split: vLLM APC / SGLang RadixAttention reuse KV cache by
    block-aligned token prefix. Putting the per-session-specific bits
    (cwd, origin) AFTER the boundary means two sessions in different
    cwds share the long stable head — only the last few lines diverge.
    The boundary itself is an HTML comment the model ignores; rtxclaw's
    own code (`system_prompt.split_system_prompt_cache_boundary`) uses
    it to insert dynamic additions in a cache-safe spot when needed
    (heartbeat content, time-of-day, …).

    Byte-stable for a given (.md files on disk, mode, workspace_cwd,
    workspace_origin) tuple — the prefix cache holds across turns of
    a session as long as none of those inputs changes.
    """
    from rtxclaw_core import skills as _skills_mod
    from rtxclaw_core.system_prompt import (
        compose_with_cache_boundary,
        execution_bias_prompt_section,
        mcp_acp_capabilities_block,
        tooling_prompt_section,
    )
    # Hardcoded runtime sections come FIRST — mirror OpenClaw's stable
    # prefix layout. The Tooling + Execution Bias pair carries
    # tool-contract guidance (the `TodoWrite` workflow lives WITH the tool
    # registry, not in operator-editable .md). They sit above all
    # bootstrap/.md content so the contract reaches the model early,
    # not buried at byte ~13 K of a 26 K head.
    #
    # 2026-05-07 reversal note: TODO_TOOL_PROMPT_SECTION was removed
    # 2026-05-06 in favor of "all prompt content lives in .md". A
    # follow-up review of OpenClaw showed the framework keeps tool
    # contracts in code (buildToolingPromptSection) — `.md` carries
    # behavioural style on top. We mirror that hybrid: tool semantics
    # in code, behavioural style in AGENTS.md.
    head_sections: list[str] = [
        tooling_prompt_section(),
        execution_bias_prompt_section(),
    ]
    head = "\n\n".join(s for s in head_sections if s and s.strip())
    md_stable = load_system_prompt(cfg.system, root=cfg.home, mode=mode)
    stable = f"{head}\n\n{md_stable}" if head and md_stable.strip() else (
        head or md_stable
    )
    skills_block = _skills_mod.skills_summary_block(cfg.home)
    if skills_block:
        stable = (
            f"{stable}\n\n{skills_block}" if stable.strip() else skills_block
        )
    # MCP / ACP capability list — short; lives in the stable head so
    # the prefix cache holds. Only emitted when at least one server or
    # agent is configured, so a fresh install with neither doesn't
    # ship a stub block.
    mcp_acp_block = mcp_acp_capabilities_block()
    if mcp_acp_block:
        stable = (
            f"{stable}\n\n{mcp_acp_block}" if stable.strip() else mcp_acp_block
        )
    # Deferred-tools catalog: name + 1-line description for every tool
    # NOT marked ``core``. The model picks the names it needs and calls
    # ``ToolSearch`` to load full schemas. Lives in the stable head
    # so the prefix cache holds; the catalog itself is byte-stable
    # because BUILTIN_TOOLS is module-frozen.
    try:
        from rtxclaw_core.tools import BUILTIN_TOOLS, ToolRegistry
        deferred_block = ToolRegistry(BUILTIN_TOOLS).deferred_catalog_block()
    except Exception:  # noqa: BLE001
        deferred_block = ""
    if deferred_block:
        stable = (
            f"{stable}\n\n{deferred_block}"
            if stable.strip()
            else deferred_block
        )
    dynamic_sections: list[str] = []
    if workspace_cwd or workspace_origin:
        bits = ["# WORKSPACE-CONTEXT"]
        if workspace_origin:
            bits.append(f"frontend: {workspace_origin}")
        if workspace_cwd:
            bits.append(f"cwd: {workspace_cwd}")
        dynamic_sections.append("\n".join(bits))
    # MEMORY.md goes BELOW the cache boundary in every session — same
    # OpenClaw pattern. Edits the model makes via tool calls between
    # turns invalidate only the trailing dynamic suffix on the
    # upstream's prefix cache; the long stable head stays warm.
    memory_path = cfg.home / "MEMORY.md"
    if memory_path.exists():
        try:
            mem_body = memory_path.read_text(encoding="utf-8").strip()
        except OSError:
            mem_body = ""
        if mem_body:
            dynamic_sections.append(f"# MEMORY.md\n\n{mem_body}")
    # HEARTBEAT.md is injected ONLY into the dedicated heartbeat
    # session (workspace_origin="heartbeat"). For all other sessions
    # we deliberately skip it: the model can read it on demand via
    # `Read` if it cares, and excluding it from the prompt
    # prevents heartbeat-edited tasks from invalidating user-session
    # caches. Mirrors OpenClaw's `runKind == "heartbeat"` filter.
    if workspace_origin == "heartbeat":
        hb_path = cfg.home / "HEARTBEAT.md"
        if hb_path.exists():
            try:
                hb_body = hb_path.read_text(encoding="utf-8").strip()
            except OSError:
                hb_body = ""
            if hb_body:
                dynamic_sections.append(f"# HEARTBEAT.md\n\n{hb_body}")
    return compose_with_cache_boundary([stable], dynamic_sections)


def _classify_upstream_error(msg: str) -> str:
    """Best-effort one-line summary for `errors.log_error(..., summary=)`.

    Keeps the structured error file's filename slug (and the Markdown
    tagline) human-readable so a glance at `~/.rtxclaw/errors/` tells
    the next agent what class of failure this was without opening the
    file. Falls back to the raw HTTP code when nothing matches.
    """
    m = (msg or "").lower()
    if "maximum context length" in m or "context window" in m or "context_length_exceeded" in m:
        return "upstream context-length overflow"
    if '"code":429' in m or "rate limit" in m or "429" in m[:30]:
        return "upstream rate-limited"
    if "timeout" in m or "timed out" in m:
        return "upstream timeout"
    if msg.startswith("HTTP "):
        # `HTTP 400: {...}` → "upstream HTTP 400"
        code = msg.split(":", 1)[0]
        return f"upstream {code}"
    return "upstream error"


class TurnState:
    """Lifecycle of one in-flight turn."""

    def __init__(self, turn_id: str, session_hash: str, proc: asyncio.subprocess.Process) -> None:
        self.id = turn_id
        self.session_hash = session_hash
        self.proc = proc
        # Per-tool-call subprocesses keyed by tool_call_id. The bridge
        # dispatch loop now runs read-only / state-file-distinct calls
        # concurrently, so a single ``turn.proc`` slot is no longer
        # enough — ESC must SIGTERM ALL active runners. ``self.proc``
        # still points at "the most recent process" (worker initially,
        # then a runner under the legacy single-call path) for back
        # compat with the cancel + drain helpers; ``runner_procs``
        # carries the multi-runner case.
        self.runner_procs: dict[str, asyncio.subprocess.Process] = {}
        self.state = "streaming"  # streaming | paused | done | aborted | error
        self.started_at = _now()
        # Monotonic timestamp for staleness checks (the ISO `started_at`
        # is wall-clock and not safe across NTP jumps). The heartbeat
        # scheduler uses this to evict TurnState entries that have
        # leaked past the heartbeat interval.
        self.started_mono = time.monotonic()
        self.ended_at: Optional[str] = None
        self.error: Optional[str] = None
        self.thinking_buf: list[str] = []
        self.content_buf: list[str] = []
        self.metrics: Optional[dict] = None
        # Tool calls the model emitted in this round (if any). The
        # session_turn loop dispatches these and starts another round.
        self.pending_tool_calls: list[dict] = []
        self._listeners: set[asyncio.Queue] = set()
        # Set True by the streaming loop detector
        # (`_detect_reasoning_loop`) when the model's CoT shows
        # degenerative repetition. The worker is SIGTERM'd as soon as
        # this is set; `session_turn` routes the round to the distill
        # recovery path the same way it would for a `thinking_only_stop`.
        # Stays False on healthy turns.
        self.loop_detected: bool = False
        # Mirrors the per-turn ``post_force_terminate`` flag in the
        # bridge prompt loop (acp_bridge.py). When True, the runner
        # spawner (``_default_run_tool``) clamps EXEC-kind tools'
        # ``timeout`` / ``wall_timeout`` args to a short ceiling so a
        # token-collapsed model that slips past the bridge's deny gate
        # can't dispatch a 30-minute bash. Belt-and-suspenders for the
        # bridge-level block.
        self.post_force_terminate: bool = False
        # Last `len(thinking_buf joined)` at which we ran the loop
        # detector. Throttles detection to once per ~LOOP_CHECK_STRIDE
        # chars rather than once per token; the detector itself is O(n)
        # in buffer size so without throttling it's quadratic over a
        # streaming round.
        self._loop_last_check_chars: int = 0

    def subscribe(self) -> asyncio.Queue:
        q: asyncio.Queue = asyncio.Queue()
        self._listeners.add(q)
        return q

    def unsubscribe(self, q: asyncio.Queue) -> None:
        self._listeners.discard(q)

    async def emit(self, event: str, data: dict) -> None:
        for q in list(self._listeners):
            await q.put((event, data))

    def stop(self, *, force: bool = False) -> None:
        """SIGTERM all in-flight subprocesses for this turn.

        With ``force=True`` (fix D — second cancel within 1 s), escalate
        to ``SIGKILL`` and also signal each subprocess's whole process
        group via ``killpg``. The default ``proc.kill()`` only kills the
        immediate child — a wedged python interpreter that swallowed
        SIGTERM keeps any descendants it has spawned (`sh -c …`, a
        long-running `find`, etc.) alive until they themselves exit.
        ``run_bash_async`` already starts each runner in its own session
        (``start_new_session=True``) so ``killpg`` reaches every
        descendant in one signal.
        """
        sig = signal.SIGKILL if force else signal.SIGTERM
        procs: list[asyncio.subprocess.Process] = []
        if self.proc is not None:
            procs.append(self.proc)
        procs.extend(self.runner_procs.values())
        for proc in procs:
            try:
                if force:
                    try:
                        os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                    except (ProcessLookupError, PermissionError, OSError):
                        pass
                proc.send_signal(sig)
            except ProcessLookupError:
                pass

    def register_runner(self, call_id: str, proc: asyncio.subprocess.Process) -> None:
        """Track an in-flight tool-runner subprocess by tool_call_id."""
        self.runner_procs[call_id] = proc

    def unregister_runner(self, call_id: str) -> None:
        """Drop a runner once its subprocess has exited / been reaped."""
        self.runner_procs.pop(call_id, None)

    def pause(self) -> bool:
        if self.state != "streaming":
            return False
        try:
            self.proc.send_signal(signal.SIGSTOP)
        except ProcessLookupError:
            return False
        self.state = "paused"
        return True

    def resume(self) -> bool:
        if self.state != "paused":
            return False
        try:
            self.proc.send_signal(signal.SIGCONT)
        except ProcessLookupError:
            return False
        self.state = "streaming"
        return True
