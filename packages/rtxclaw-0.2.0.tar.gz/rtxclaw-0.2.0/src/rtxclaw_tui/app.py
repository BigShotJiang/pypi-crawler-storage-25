from __future__ import annotations

import argparse
import asyncio
import difflib
import json
import os
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

import httpx
from rich.markdown import Markdown as RichMarkdown
from rich.text import Text
import contextlib
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import (
    Button, Checkbox, Collapsible, Header, Input, Label, ListItem, ListView,
    RadioButton, RadioSet, RichLog, Static, TextArea,
)

from rtxclaw_core import config as cfgmod
from rtxclaw_core import context as ctxmod
from rtxclaw_core.session import Session


# SSH detection — when the TUI runs over a remote shell, throttle paint
# rate and reduce the per-tick chatter. Each escape sequence is a
# round-trip in latency-bound terminal data, and Textual's default
# 60 FPS is overkill once you pay an extra 30-150 ms RTT per frame.
# Override with `RTXCLAW_TUI_FPS=<n>` if you want to force a value.
def _detect_ssh() -> bool:
    return bool(
        os.environ.get("SSH_CONNECTION")
        or os.environ.get("SSH_CLIENT")
        or os.environ.get("SSH_TTY")
    )


_IS_SSH = _detect_ssh()
_TUI_FPS = int(os.environ.get("RTXCLAW_TUI_FPS") or (20 if _IS_SSH else 60))


# Footer-spinner frames. Animated by `_animate_status` while
# `_worker_state` is non-empty so the operator sees motion even when the
# upstream pauses between chunks (e.g. right before a long tool call,
# or while a tool runs and no chunks are flowing). Braille frames are
# terminal-safe, low-bandwidth, and read at a glance.
_SPINNER_FRAMES = ("⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏")


# asyncio's StreamReader has a 64 KiB default per-line buffer
# (`asyncio.streams._DEFAULT_LIMIT`). Claude Code's stream-json output
# can emit single events > 64 KiB when a `tool_use` block carries a
# large input (e.g. a Read on a multi-page file, or a Write with a long
# document body). Same goes for the local `worker.py` when it emits a
# `tool_calls` event whose accumulated arguments are large. Bump the
# limit to 16 MiB so realistic agentic workloads never trip
# `LimitOverrunError` mid-stream.
_SUBPROCESS_STDIO_LIMIT = 16 * 1024 * 1024


def _alias_for_endpoint(models: Optional[list], endpoint: str) -> str:
    """Look up the configured alias for `endpoint` in the agent's
    `models[]` list. Returns "" when nothing matches (caller falls back
    to hostname). Trailing slashes are normalized so a session bound
    to `https://openrouter.ai/api/v1` matches a configured row whose
    `baseUrl` is the same with or without a trailing slash.
    """
    if not endpoint or not models:
        return ""
    target = endpoint.rstrip("/")
    for m in models:
        if (m.get("baseUrl") or "").rstrip("/") == target:
            return m.get("alias") or ""
    return ""


def _hostname_of(endpoint: str) -> str:
    """Pull the hostname out of an upstream URL, e.g. `host` from
    `http://host:8001/v1`. Returns "" on a malformed / empty URL.

    Used as a fallback for the status bar's provider alias when the
    user hasn't set `AgentConfig.upstream_alias` explicitly.
    """
    if not endpoint:
        return ""
    try:
        from urllib.parse import urlparse
        return urlparse(endpoint).hostname or ""
    except Exception:  # noqa: BLE001
        return ""


def _model_label(alias: object = "", model_id: object = "") -> str:
    """Render a compact user-facing model label without duplicated parts."""
    alias_s = str(alias or "")
    model_s = str(model_id or "")
    if alias_s and model_s and alias_s != model_s:
        return f"{alias_s}/{model_s}"
    return alias_s or model_s


def _engine_models_for(agent_cfg) -> Optional[list[dict]]:
    """Return engine-specific model rows for CLI agents, or ``None``.

    For ``gemini_cli`` agents the global config's ``models[]`` list
    (which describes the local-LLM upstreams: gpu-a, gpu-b, kimi, …) is
    meaningless — gemini-cli owns its own HTTP transport and only
    accepts a fixed set of Google model ids on ``--model``. Surface
    the curated list from :data:`GEMINI_MODELS` instead so `/models`
    shows the right thing.

    Returns ``None`` for engines that don't need an override (local_llm
    / claude_cli / codex_cli) — the caller falls back to
    ``cfg.models``.
    """
    engine = (getattr(agent_cfg, "engine", "") or "").strip()
    if engine == "gemini_cli":
        try:
            from rtxclaw_core.agents.gemini_engine import GEMINI_MODELS
        except Exception:  # noqa: BLE001
            return None
        return [dict(m) for m in GEMINI_MODELS]
    return None


def _model_alias_id_label(alias: object = "", model_id: object = "") -> str:
    """Render ``alias (id)`` unless both values are the same."""
    alias_s = str(alias or "")
    model_s = str(model_id or "")
    if alias_s and model_s and alias_s != model_s:
        return f"{alias_s} ({model_s})"
    return alias_s or model_s


# In-band tool-use / tool-result markers the legacy claude/gemini CLI
# runners inline into the assistant content body (see
# ``rtxclaw_core.tools.runners._format_claude_tool_use`` and
# ``_format_claude_tool_result``). When the saved turn carries
# structured ``tool_calls[]`` / ``tool_results[]`` lists we mount real
# ``ToolCallMessage`` / ``ToolResultMessage`` widgets and strip these
# markers from the prose so the operator doesn't see both.
#
# Marker shape (per runners.py):
#     "\n\n🔧 <name> <json-args>\n"
#     "↳ <summary> (<n> chars)\n"   (or "✗ ..." on error, or "↳ (<n> chars)\n")
_INLINE_TOOL_MARKER_RE = re.compile(
    r"\n*🔧 [^\n]*\n(?:[↳✗] [^\n]*\n)?",
)


def _strip_inline_tool_markers(content: str) -> str:
    """Remove the in-band 🔧 / ↳ tool markers from a saved assistant body.

    Idempotent and safe on strings that don't carry any markers
    (returns the input unchanged). Collapses the runs of blank lines
    the markers leave behind so the remaining prose reads cleanly.
    """
    if not content or "🔧" not in content:
        return content
    cleaned = _INLINE_TOOL_MARKER_RE.sub("\n", content)
    # Collapse 3+ newlines to 2 (one blank line between paragraphs).
    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
    return cleaned.strip("\n")


def _build_delegate_metrics(
    *,
    label: str,
    t0: float,
    first_chunk_at: Optional[float],
    chars: int,
) -> Optional[dict]:
    """Synthesize a native-style metrics row for a delegated turn.

    Mirrors what the bridge ships for local turns (``model``,
    ``ttft_ms``, ``tps``, ``completion_tokens``, ``wt_ms``) so the
    operator can compare a /claude / /codex run against a gpu-a-served
    one at a glance. The body of the delegate is opaque to us — we
    don't see prompt-token / cache-hit numbers, so those fields stay
    absent and the row is marked ``tokens_estimated`` (the ≈ glyph
    on ``gen``/``out``).

    Returns ``None`` when nothing useful can be reported (no chunks
    arrived, no wall time accumulated).
    """
    now = time.monotonic()
    wt_ms = max(0.0, (now - t0) * 1000.0)
    if wt_ms <= 0 and chars == 0:
        return None
    metrics: dict[str, Any] = {
        "model": label,
        "wt_ms": wt_ms,
        "tokens_estimated": True,
    }
    if first_chunk_at is not None:
        metrics["ttft_ms"] = (first_chunk_at - t0) * 1000.0
        if chars > 0:
            stream_s = max(now - first_chunk_at, 1e-3)
            est_tok = max(int(chars / 4), 1)
            metrics["completion_tokens"] = est_tok
            metrics["content_tokens"] = est_tok
            metrics["tps"] = est_tok / stream_s
    return metrics


def _gateway_url_and_token() -> tuple[str, Optional[str]]:
    """Resolve the rtxclaw gateway URL + bearer token for AgentClient.

    Order of precedence:

    1. ``$RTXCLAW_TUI_ACP_URL`` / ``$RTXCLAW_TUI_ACP_TOKEN`` — direct
       env override (also what :class:`AgentClient` reads as a default).
    2. ``~/.rtxclaw/config.json`` ``gateway`` block (host/port/auth_token).
    3. Hard default ``http://127.0.0.1:20100`` with no auth.

    The TUI uses this once on startup to populate the ``gateway_url``
    + ``gateway_token`` kwargs on every :class:`AgentClient` it
    constructs, so all agent traffic flows through the systemd-managed
    gateway and we never spawn a per-agent stdio child from the TUI.

    Steps 2 + 3 delegate to :func:`rtxclaw_agent.gateway._gateway_config`
    — the gateway's OWN resolver — so the TUI can never disagree with
    the port the gateway actually binds. Hand-rolling this resolution
    with a stale ``7700`` default is exactly what stranded a fresh
    install with "connection refused": the gateway bound :20100, the
    TUI dialed :7700.
    """
    env_url = os.environ.get("RTXCLAW_TUI_ACP_URL", "").strip()
    env_token = os.environ.get("RTXCLAW_TUI_ACP_TOKEN", "").strip() or None
    if env_url:
        return env_url.rstrip("/"), env_token
    try:
        from rtxclaw_agent.gateway import _gateway_config
        gw = _gateway_config()
    except Exception:  # noqa: BLE001
        gw = {"host": "127.0.0.1", "port": 20100, "auth_token": None}
    return f"http://{gw['host']}:{gw['port']}", (gw.get("auth_token") or None)


def _gateway_alive() -> bool:
    """True iff the rtxclaw gateway is reachable.

    Primary signal: ``$RTXCLAW_HOME/gateway.pid`` points at a live
    pid. Fallback: a successful ``GET /health`` against the gateway's
    bind URL — covers the case where the pidfile is missing (e.g.
    early in a systemd restart, or a stale-cleanup race) but the
    listener is healthy.
    """
    try:
        from rtxclaw_agent.gateway import _gateway_pidfile
    except Exception:  # noqa: BLE001
        return False
    pidfile = _gateway_pidfile()
    if pidfile.is_file():
        try:
            pid = int(pidfile.read_text().strip())
            os.kill(pid, 0)
            return True
        except (OSError, ValueError, PermissionError, ProcessLookupError):
            pass
    gateway_url, _ = _gateway_url_and_token()
    try:
        r = httpx.get(f"{gateway_url}/health", timeout=1.0)
        return r.status_code == 200
    except httpx.HTTPError:
        return False


# Thinking-title elapsed-time tick. Local: 5 Hz feels live. SSH: 2 Hz
# is plenty (humans don't read sub-half-second updates on a header
# anyway) and saves bandwidth during the multi-second think phase.
_THINK_TICK_INTERVAL_S = 0.5 if _IS_SSH else 0.2


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _enable_kitty_keyboard_enhancements(app: App) -> None:
    """Ask the terminal to disambiguate `shift+enter` from plain `enter`.

    Textual's Linux/Windows drivers write `\\x1b[>1u` to push flag 1
    (disambiguate escape codes) onto the kitty keyboard stack. We add
    flags 2/4/8 (report event types / alternate keys / report all keys
    as escape codes) so terminals that fully implement the protocol
    deliver `shift+enter` as a distinct key event instead of collapsing
    it into plain `enter`.

    PREVIOUSLY this wrote `\\x1b[=8;u`, which is SET-mode (mode `1`
    being the default) — that REPLACED Textual's flag 1 with 8 alone,
    nuking disambiguation, so `shift+enter` started arriving as plain
    `enter` and the input box submitted instead of inserting a newline.
    The fix is `\\x1b[>15u` (push 15 = 1+2+4+8 = all flags), which
    layers on top of whatever Textual already pushed without erasing
    it. Textual's own teardown (`\\x1b[<u`) pops the stack on exit so
    no cleanup is needed.

    On terminals that don't speak the kitty protocol at all the sequence
    is ignored — `MessageInput.BINDINGS` also includes a `ctrl+j`
    fallback (literal LF) that any terminal can deliver, so multi-line
    composition still works.

    Tracking upstream: https://github.com/Textualize/textual/issues/6074
    """
    driver = getattr(app, "_driver", None)
    if driver is None:
        return
    write = getattr(driver, "write", None)
    flush = getattr(driver, "flush", None)
    if write is None or flush is None:
        return
    try:
        write("\x1b[>15u")
        flush()
    except Exception:  # noqa: BLE001 — never crash boot over a TTY quirk
        pass


async def discover_model(endpoint: str, headers: Optional[dict] = None) -> str:
    async with httpx.AsyncClient(timeout=10, headers=headers or {}) as client:
        r = await client.get(f"{endpoint.rstrip('/')}/models")
        r.raise_for_status()
        data = r.json().get("data") or []
    if not data:
        raise RuntimeError(f"no models advertised by {endpoint}")
    return data[0]["id"]


class UserMessage(Static):
    def __init__(self, text: str) -> None:
        super().__init__(text, markup=False, classes="user-msg")


class AssistantMessage(Vertical):
    """One assistant turn: optional collapsible thinking + streamed content.

    Layout order (top → bottom): prefill-counter → thinking-box →
    content → metrics. The prefill counter is a small live-ticking
    line that's visible from the moment the widget mounts, so a fresh
    turn shows "yes, work is happening" feedback during the multi-second
    prefill window before the first token arrives. It freezes the
    instant the first thinking or content delta lands and stays as a
    quiet `[dim]· prefill 1.23s[/dim]` breadcrumb above the thinking box.
    """

    def __init__(self, *, from_replay: bool = False) -> None:
        super().__init__(classes="assist-msg")
        self.thinking_text = ""
        self.content_text = ""
        self._thinking_static: Optional[Static] = None
        self._thinking_box: Optional[Collapsible] = None
        self._content_static = Static("", markup=False, classes="assist-content")
        # Per-model-call telemetry footer — one line of dim stats stamped
        # below the content when the bridge ships a `metrics` event for
        # this round. Each AssistantMessage corresponds to ONE model call
        # (a "round"), so this is per-call, not per-turn.
        self._metrics_static = Static("", markup=True, classes="assist-metrics")
        self._prefill_static = Static("", markup=True, classes="assist-prefill")
        self._prefill_started: Optional[float] = None
        self._prefill_ended: Optional[float] = None
        self._prefill_timer = None
        self._from_replay = from_replay
        self._final = False
        self._think_started: Optional[float] = None
        self._think_ended: Optional[float] = None
        self._think_timer = None
        self.metrics: Optional[dict] = None

    def compose(self) -> ComposeResult:
        if not self._from_replay:
            yield self._prefill_static
        yield self._content_static
        yield self._metrics_static

    def on_mount(self) -> None:
        """Kick off the prefill counter immediately on mount.

        Mounting happens at round-start (eager mount in `_stream_via_agent`
        and after `tool_result`), so the elapsed time we display matches
        the user's perceived "how long since I hit Enter" / "how long
        since the tool returned and the model went quiet again". Replay
        path skips this — its pft is already known and shown in metrics.
        """
        if self._from_replay:
            return
        self._prefill_started = time.monotonic()
        self._refresh_prefill_label(active=True)
        self._prefill_timer = self.set_interval(
            _THINK_TICK_INTERVAL_S, self._tick_prefill
        )

    def set_metrics(self, metrics: dict) -> None:
        """Render a one-line dim footer with per-model-CALL telemetry.

        One AssistantMessage = one model call (a "round"), so each
        tool-using round gets its own stats line. Called once per
        `metrics` event during streaming, and again on replay if the
        saved turn carries a `metrics` dict.

        Order (left → right):
            <model> · classify <ms> · plan <ms>
              · prefill <ms> @ <prefill_tps> tok/s · ttft <ms>
              · gen <gen_tps> tok/s
              · ctx in <pt> (<cached> cached, <fresh> fresh) /<window>
              · out <ct> tok (think <rt> / result <ot>)
              · total <total> tok · wt <s>

        Fields are skipped when their value is missing.
        """
        if not metrics:
            return
        self.metrics = dict(metrics)
        parts: list[str] = []
        m = metrics
        model = m.get("model")
        # Operator-facing alias resolved by the bridge from the
        # serving endpoint. When present, render as
        # ``<alias>/<model>`` so the user sees BOTH the bucket they
        # picked (kimi) AND the wire-level model id
        # (qwen3.6-27b-fp8) — the raw id alone is misleading
        # because two aliases can share an upstream id and the
        # operator may have picked one specifically.
        model_alias = m.get("model_alias")
        classify_ms = m.get("classify_ms")
        plan_ms = m.get("plan_ms")
        ttft = m.get("ttft_ms")
        ttfc = m.get("ttfc_ms")
        prefill = m.get("prefill_ms")
        accept = m.get("accept_ms") or m.get("pft_ms")
        prefill_tps = m.get("prefill_tps")
        tps = m.get("tps")
        wt = m.get("wt_ms")
        ct = m.get("completion_tokens")
        rt = m.get("reasoning_tokens")
        ot = m.get("content_tokens")
        pt = m.get("prompt_tokens")
        ptc = m.get("prompt_tokens_cached")
        ptf = m.get("prompt_tokens_fresh")
        total = m.get("total_tokens")
        est = m.get("tokens_estimated")
        ctx_window = m.get("context_window")
        tool_events = m.get("tool_events")

        model_label = _model_label(model_alias, model)
        if model_label:
            parts.append(model_label)
        if isinstance(classify_ms, (int, float)):
            parts.append(f"classify {classify_ms:.0f}ms")
        if isinstance(plan_ms, (int, float)):
            parts.append(f"plan {plan_ms:.0f}ms")
        if isinstance(prefill, (int, float)):
            seg = f"prefill {prefill:.0f}ms"
            if isinstance(prefill_tps, (int, float)):
                seg += f" @ {prefill_tps:.0f} tok/s"
            parts.append(seg)
        elif isinstance(accept, (int, float)):
            parts.append(f"accept {accept:.0f}ms")
        if isinstance(ttft, (int, float)):
            # ``ttft`` is now "time to first stream event" (tool call
            # or content). When tool calls ran before prose, surface
            # the separate ``ttfc`` as "time to first prose" + a
            # ``N tools`` badge so the user sees the breakdown.
            seg = f"ttft {ttft:.0f}ms"
            if isinstance(tool_events, (int, float)) and tool_events:
                seg += f" · {int(tool_events)} tool{'s' if tool_events != 1 else ''}"
            if isinstance(ttfc, (int, float)) and ttfc > ttft + 1:
                seg += f" · ttfc {ttfc:.0f}ms"
            parts.append(seg)
        if isinstance(tps, (int, float)):
            parts.append(f"gen {tps:.1f} tok/s" + ("≈" if est else ""))
        if isinstance(pt, (int, float)):
            ctx_seg = f"in {int(pt)}"
            extras: list[str] = []
            if isinstance(ptc, (int, float)) and ptc:
                extras.append(f"{int(ptc)} cached")
            if isinstance(ptf, (int, float)) and (ptc or ptf != pt):
                extras.append(f"{int(ptf)} fresh")
            if extras:
                ctx_seg += f" ({', '.join(extras)})"
            if isinstance(ctx_window, (int, float)) and ctx_window:
                ctx_seg += f"/{int(ctx_window)}"
            parts.append(ctx_seg)
        if isinstance(ct, (int, float)):
            seg = f"out {int(ct)} tok" + ("≈" if est else "")
            if rt is not None or ot is not None:
                rt_disp = int(rt) if isinstance(rt, (int, float)) else 0
                ot_disp = int(ot) if isinstance(ot, (int, float)) else 0
                seg += f" (think {rt_disp} / result {ot_disp})"
            parts.append(seg)
        if isinstance(total, (int, float)) and total != ct:
            parts.append(f"total {int(total)} tok")
        if isinstance(wt, (int, float)):
            parts.append(f"wt {wt / 1000:.1f}s")
        if parts:
            self._metrics_static.update(f"[dim]─ {' · '.join(parts)}[/dim]")

    async def append_thinking(self, text: str) -> None:
        if not text:
            return
        self._freeze_prefill()
        if self._think_started is None:
            self._think_started = time.monotonic()
        self.thinking_text += text
        if self._thinking_box is None:
            self._thinking_static = Static("", markup=False, classes="thinking-body")
            self._thinking_box = Collapsible(
                self._thinking_static,
                title=self._think_title(active=True),
                collapsed=True,
                classes="thinking",
            )
            await self.mount(self._thinking_box, before=self._content_static)
            self._think_timer = self.set_interval(
                _THINK_TICK_INTERVAL_S, self._tick_think_title
            )
        assert self._thinking_static is not None
        self._thinking_static.update(self.thinking_text)
        self._refresh_think_title(active=True)

    def append_content(self, text: str) -> None:
        if not text:
            return
        self._freeze_prefill()
        if self._think_started is not None and self._think_ended is None:
            self._end_thinking()
        self.content_text += text
        # Late-chunk handling: bridge sometimes emits trailing text
        # chunks AFTER the next ``tool_call`` event, which triggered
        # finalize(). Old behaviour dropped those chunks (``if _final:
        # return``) — the operator saw a mid-word cutoff like ``with
        # correct `name` par`` because "ameter." landed after finalize.
        # Now we still accept the chunk, append to ``content_text``,
        # and re-render through RichMarkdown if finalize already
        # promoted us to markdown.
        if self._final:
            try:
                self._content_static.update(RichMarkdown(self.content_text))
            except Exception:  # noqa: BLE001
                self._content_static.update(self.content_text)
        else:
            self._content_static.update(self.content_text)
        # Force a layout pass on every chunk so the Static grows in
        # lockstep with the streamed text — under SSH-throttled 20fps
        # the implicit paint cycle can lag a couple of seconds,
        # creating the visible "sentence cut off before the tool widget
        # appears" symptom. The Static still has the full content in
        # ``content_text``; the issue was purely layout/paint timing.
        try:
            self._content_static.refresh(layout=True)
            self.refresh(layout=True)
        except Exception:  # noqa: BLE001
            pass

    def finalize(self) -> None:
        self._freeze_prefill()
        if self._think_started is not None and self._think_ended is None:
            self._end_thinking()
        self._final = True
        if self.content_text:
            # Replace the streamed plain-text view with a rendered Markdown
            # block. Force a layout refresh on BOTH the inner Static and
            # the outer AssistantMessage — without the outer refresh, the
            # parent VerticalScroll holds the height it computed for the
            # plain-text Static and the next widget (a ToolCallMessage in
            # the tool-call path) appears to overlap or push out the last
            # streamed lines. This is the "messages not flushing right
            # before a tool call" bug — the text was there in `content_text`
            # but the widget hadn't grown to render the last lines.
            self._content_static.update(RichMarkdown(self.content_text))
            self._content_static.refresh(layout=True)
            self.refresh(layout=True)

    def mark_aborted(self) -> None:
        self._freeze_prefill()
        if self._think_started is not None and self._think_ended is None:
            self._end_thinking()
        self._final = True
        suffix = "\n\n_[aborted]_" if self.content_text else "_[aborted]_"
        body = self.content_text + suffix
        self._content_static.update(RichMarkdown(body))

    def mark_error(self, message: str) -> None:
        self._freeze_prefill()
        if self._think_started is not None and self._think_ended is None:
            self._end_thinking()
        self._final = True
        body = (self.content_text + "\n\n" if self.content_text else "") + f"**[error]** {message}"
        self._content_static.update(RichMarkdown(body))

    # --- prefill (time-to-first-token) helpers ---

    def _refresh_prefill_label(self, *, active: bool) -> None:
        if self._prefill_started is None:
            return
        end = time.monotonic() if active else (self._prefill_ended or time.monotonic())
        elapsed = max(0.0, end - self._prefill_started)
        if active:
            # Bright-green pulse so it reads as "running, normal operation"
            # rather than an error/warning. The trailing dots cycle 1→2→3
            # so even on a slow tick rate (SSH: 2 Hz) the user sees motion
            # — and we never render zero dots, which would otherwise read
            # as "frozen" for a third of the cycle.
            phase = int(elapsed * 3) % 3 + 1
            dots = "." * phase + " " * (3 - phase)
            self._prefill_static.update(
                f"[bold green]▶ prefilling[/bold green]"
                f"[green]{dots}[/green] "
                f"[green]{elapsed:.1f}s[/green]"
            )
        else:
            self._prefill_static.update(
                f"[dim]· prefill {elapsed:.2f}s[/dim]"
            )

    def _tick_prefill(self) -> None:
        if self._prefill_ended is None:
            self._refresh_prefill_label(active=True)

    def _freeze_prefill(self) -> None:
        """Stop the live counter and freeze the line as a small breadcrumb.

        Called on the first thinking/content delta, on finalize, and on
        abort/error. Idempotent — late freezes from finalize/error after
        the first delta already froze it are no-ops.
        """
        if self._prefill_started is None or self._prefill_ended is not None:
            return
        self._prefill_ended = time.monotonic()
        if self._prefill_timer is not None:
            self._prefill_timer.stop()
            self._prefill_timer = None
        self._refresh_prefill_label(active=False)

    # --- thinking-title helpers ---

    def _think_title(self, *, active: bool) -> str:
        if self._think_started is None:
            return "Thinking"
        end = time.monotonic() if active else (self._think_ended or time.monotonic())
        elapsed = max(0.0, end - self._think_started)
        chars = len(self.thinking_text)
        # Hint flips with the box's current state so the user sees what Ctrl+R
        # will do at this moment.
        collapsed = self._thinking_box.collapsed if self._thinking_box is not None else True
        hint = "Ctrl+R to expand" if collapsed else "Ctrl+R to collapse"
        if active:
            return f"▶ Thinking… {elapsed:.1f}s · {chars} chars   ·   {hint}"
        return f"✓ Thought for {elapsed:.1f}s · {chars} chars   ·   {hint}"

    def _refresh_think_title(self, *, active: bool) -> None:
        if self._thinking_box is None:
            return
        self._thinking_box.title = self._think_title(active=active)

    def _tick_think_title(self) -> None:
        if self._think_ended is None:
            self._refresh_think_title(active=True)

    def _end_thinking(self) -> None:
        self._think_ended = time.monotonic()
        if self._think_timer is not None:
            self._think_timer.stop()
            self._think_timer = None
        self._refresh_think_title(active=False)


CLAUDE_MODE_MAP: dict[str, str] = {
    "plan": "plan",                # claude plan: research-only, doesn't edit
    "ask":  "default",             # claude default: prompts; in -p mode denies non-allowed
    "auto": "bypassPermissions",   # claude bypassPermissions: full bypass (Edit/Write/Bash/...)
}

# Display-only mapping for Codex. The actual flags are picked inside the
# `delegate_codex` runner; this is just the human-readable label the
# status bar shows ("mode=read-only", "mode=bypass") so the user knows
# what permission level Codex is running with.
CODEX_MODE_LABELS: dict[str, str] = {
    "plan": "read-only",
    "ask":  "workspace-write",
    "auto": "bypass",
}


def _codex_sandbox_label(rtxclaw_mode: str) -> str:
    """Map rtxclaw's plan/ask/auto to a short Codex sandbox label.

    Used by the TUI / bash bridge to render the active permission level
    in status messages. Falls back to `workspace-write` (the codex
    default) when the mode is unknown — mirrors `_claude_permission_mode`'s
    fallback to claude `default`.
    """
    if not rtxclaw_mode:
        return "workspace-write"
    return CODEX_MODE_LABELS.get(rtxclaw_mode, "workspace-write")


def _claude_permission_mode(rtxclaw_mode: str) -> str:
    """Map rtxclaw's plan/ask/auto to Claude Code's --permission-mode.

    `auto` maps to `bypassPermissions`: in headless `-p` mode there is
    no human to answer permission prompts, so `acceptEdits` (which only
    auto-approves Edit) leaves Bash/Write/etc. deadlocked. The user
    opts into "do whatever you need" by cycling rtxclaw to `auto`, so
    bypass is the right Claude analogue.

    Unknown / empty modes fall back to claude's `default` (asks for
    everything) — safest landing for a None mode coming through the CLI
    when no `--mode` was passed.
    """
    if not rtxclaw_mode:
        return "default"
    return CLAUDE_MODE_MAP.get(rtxclaw_mode, "default")


# Per-turn cap on how many characters of a prior turn's content/user we
# embed into the /claude preamble. Generous on purpose: dedup is handled
# upstream by `_{claude,codex}_synced_turn_idx` (only NEW turns since the
# last delegate call are forwarded) and `skip_source` (same-delegate
# turns are already in `claude --resume` / `codex exec resume`), so the
# only thing this cap protects against is a single pathological turn
# (e.g. a multi-megabyte tool dump) blowing the delegate's prompt. 200K
# chars is well under Claude's / Codex's 200K-token window for any one
# turn while leaving full tool-call output intact in normal use.
_CLAUDE_PREAMBLE_PER_TURN_CHARS = 200_000


def _build_delegate_preamble(
    unsynced_turns: list[dict],
    *,
    is_first_call: bool,
    skip_source: str,
) -> str:
    """Render unsynced rtxclaw turns as a context preamble for a delegate.

    Each rtxclaw turn is a dict shaped like
    `{"user": str, "content": str, "thinking": str?, "metrics"?: dict, ...}`.
    We render only `user` + `content` (thinking and tool rounds are
    skipped — the delegate doesn't need the local model's CoT). Turns
    whose `metrics.source == skip_source` are also skipped: those are
    prior turns from the SAME delegate, which it has already seen via
    its own resume state (`claude --resume` / `codex exec resume`), so
    re-feeding them would just be noise. Cross-delegate turns (e.g. a
    `/claude` exchange when building a `/codex` preamble) ARE included,
    because the OTHER delegate has no shared resume state.

    Returns "" when there's nothing useful to inject.
    """
    if not unsynced_turns:
        return ""
    lines: list[str] = []
    for t in unsynced_turns:
        if not isinstance(t, dict):
            continue
        meta = t.get("metrics") or {}
        if isinstance(meta, dict) and meta.get("source") == skip_source:
            # Already inside this delegate's own resume thread.
            continue
        user = (t.get("user") or "").strip()
        content = (t.get("content") or "").strip()
        if not user and not content:
            continue
        if user:
            lines.append(
                f"[user] {user[:_CLAUDE_PREAMBLE_PER_TURN_CHARS]}"
                + (" …[truncated]" if len(user) > _CLAUDE_PREAMBLE_PER_TURN_CHARS else "")
            )
        if content:
            lines.append(
                f"[assistant] {content[:_CLAUDE_PREAMBLE_PER_TURN_CHARS]}"
                + (" …[truncated]" if len(content) > _CLAUDE_PREAMBLE_PER_TURN_CHARS else "")
            )
        lines.append("")
    if not lines:
        return ""
    if is_first_call:
        header = (
            "You were invoked from inside an rtxclaw session. The user has been "
            "talking to a local model (rtxclaw) before this. Use the conversation "
            "below as context when answering — when the user says \"this\" or "
            "\"more on this\", they mean the topic of the prior exchange."
        )
    else:
        header = (
            "Additional rtxclaw turns since your last invocation (the user kept "
            "talking to the local model in between). Use them as context."
        )
    return (
        f"<rtxclaw-context>\n{header}\n\n"
        "=== rtxclaw conversation history ===\n"
        + "\n".join(lines).rstrip()
        + "\n=== end of conversation history ===\n"
        "</rtxclaw-context>\n\n"
        "The user's request follows.\n\n"
    )


class ClaudeMessage(AssistantMessage):
    """Inline transcript widget for ``/claude <prompt>`` output.

    Subclass of :class:`AssistantMessage` so the layout — prefill
    counter → optional thinking box → content → metrics row — is
    visually identical to a native rtxclaw turn. The ONLY difference
    is a one-line dim ``↳ via claude`` badge mounted above the
    content, so the operator can tell the answer was delegated to
    Claude Code without breaking the "just another turn" rhythm of
    the transcript.

    Public surface (kept compatible with the old Static-based widget):
    ``append_content(text)`` / ``finalize(session_id=None)`` /
    ``mark_aborted()`` / ``mark_error(message)`` and the
    ``content_text`` attribute.
    """

    DELEGATE_LABEL = "claude"
    DELEGATE_ID_LABEL = "session_id"

    def __init__(self, *, from_replay: bool = False) -> None:
        super().__init__(from_replay=from_replay)
        self._delegate_session_id: Optional[str] = None
        self._aborted = False
        self._error_message: Optional[str] = None
        # Lazily-mounted Static carrying the ``↳ via <delegate>`` badge.
        # We construct it now so it can be styled via CSS (`.delegate-badge`)
        # but mount it in ``on_mount`` (the parent class already mounts the
        # prefill / content / metrics children there).
        self._delegate_badge = Static(
            self._badge_text(),
            markup=True,
            classes="delegate-badge",
        )

    def _badge_text(self) -> str:
        # Inert dim, low-contrast — same vibe as the metrics row.
        return f"[dim]↳ via {self.DELEGATE_LABEL}[/dim]"

    def on_mount(self) -> None:
        super().on_mount()
        # Mount the delegate badge ABOVE the content static so it
        # sits between the prefill counter (or the top of the widget)
        # and the streaming content. ``before=self._content_static``
        # is the same anchor the thinking box uses when it appears.
        try:
            self.mount(self._delegate_badge, before=self._content_static)
        except Exception:  # noqa: BLE001
            # Mount can race with very-early lifecycle hooks; the badge
            # is purely visual, so a failure here is non-fatal.
            pass

    def finalize(self, session_id: Optional[str] = None) -> None:
        self._delegate_session_id = session_id or None
        if self._aborted:
            self._render_aborted_inline()
            return
        if self._error_message is not None:
            self._render_error_inline(self._error_message)
            return
        super().finalize()
        # Append a dim trailer with the delegate session id so a
        # follow-up ``/claude`` can be grounded by the operator if they
        # need to debug. Same place the old widget put it.
        if session_id:
            trailer = (
                f"\n\n[dim]_{self.DELEGATE_ID_LABEL}: {session_id}_[/dim]"
            )
            try:
                self._content_static.update(
                    RichMarkdown(self.content_text + trailer)
                )
                self.refresh(layout=True)
            except Exception:  # noqa: BLE001
                pass

    def mark_aborted(self) -> None:
        self._aborted = True
        self._render_aborted_inline()

    def mark_error(self, message: str) -> None:
        self._error_message = message
        self._render_error_inline(message)

    def _render_aborted_inline(self) -> None:
        body = self.content_text + "\n\n_[aborted]_"
        try:
            self._content_static.update(RichMarkdown(body))
            self._final = True
            self._freeze_prefill()
            self.refresh(layout=True)
        except Exception:  # noqa: BLE001
            pass

    def _render_error_inline(self, message: str) -> None:
        prefix = (self.content_text + "\n\n") if self.content_text else ""
        body = f"{prefix}**[error]** {message}"
        try:
            self._content_static.update(RichMarkdown(body))
            self._final = True
            self._freeze_prefill()
            self.refresh(layout=True)
        except Exception:  # noqa: BLE001
            pass


class CodexMessage(ClaudeMessage):
    """Inline transcript widget for ``/codex <prompt>`` output.

    Same layout/streaming contract as :class:`ClaudeMessage` — only
    the badge label changes to ``↳ via codex`` and the trailing
    session-id label uses Codex's ``thread_id`` term.
    """

    DELEGATE_LABEL = "codex"
    DELEGATE_ID_LABEL = "thread_id"


class GeminiMessage(ClaudeMessage):
    """Inline transcript widget for ``/gemini <prompt>`` output.

    Same layout/streaming contract as :class:`ClaudeMessage` — only
    the badge label changes to ``↳ via gemini`` and the trailing
    session-id field stays as ``session_id`` (Gemini CLI's ``--resume``
    takes a UUID just like Claude).
    """

    DELEGATE_LABEL = "gemini"
    DELEGATE_ID_LABEL = "session_id"


# `/claude`, `/codex`, and `/gemini` share `_build_delegate_preamble` and
# pass their own delegate name as `skip_source` so each one filters out
# only its own prior turns (which the delegate already has via its
# resume state) while still forwarding the OTHER delegates' exchanges
# as context.


class ToolCallMessage(Static):
    """Inline transcript pill: '🔧 tool(args)' shown when a tool starts running."""

    def __init__(self, name: str, args: dict) -> None:
        # Render args compactly so a long write_file doesn't dominate.
        compact = json.dumps({k: v for k, v in args.items() if k != "criticality"},
                             ensure_ascii=False)
        if len(compact) > 200:
            compact = compact[:200] + "…"
        super().__init__(f"🔧 {name} {compact}", markup=False, classes="tool-call")


class ToolResultMessage(Collapsible):
    """Tool-call output, collapsed by default.

    Subclasses Textual's `Collapsible` directly (not wrapped in a
    Vertical) so the visual is identical to `AssistantMessage`'s
    `_thinking_box`: collapsed-by-default header bar with a peek of
    the output, expand on `Ctrl+T`. All tool outputs — including
    streaming ones — start collapsed. Content accumulates in memory
    regardless of collapsed state; expanding mid-stream reveals
    everything received so far. Long outputs (a 64 KiB grep result,
    a web-fetched HTML page) stay folded out of the way until the
    user chooses to inspect them.
    """

    def __init__(self, call_id: str, ok: bool, content: str, *, streaming: bool = False) -> None:
        self.call_id = call_id
        self.ok = ok
        self.content = (content or "").rstrip()
        self._peek = self._build_peek()
        self._prefix = "🔧" if streaming else ("✅" if ok else "❌")
        # Set when a later compaction round trims or drops THIS tool
        # result on the wire to the upstream model. The transcript
        # widget still has the full content (set in __init__), but
        # this flag tells the user "the model didn't see all of this
        # on its last round" so they can correctly interpret answers.
        self._compaction_state: Optional[str] = None  # None | "truncated" | "dropped"
        # `_streaming` flips to False on `finalize_streaming(...)`. While
        # True, the title shows a 🔧 spinner-equivalent and incoming
        # `tool_delta` chunks append to the body Static. Used for
        # `delegate_claude` tool calls so the model's autonomous Claude
        # delegations stream visibly, same as the slash-command path.
        self._streaming = streaming
        # `_split` is True when a streaming widget was frozen mid-stream
        # by ``mark_split()`` because a nested ``tool_call`` arrived
        # (e.g., delegate_claude's inner Grep call). The next tool_delta
        # for the same call_id mounts a NEW streaming widget below the
        # inner tool widgets — without splitting, all of Claude's text
        # would land in the ORIGINAL widget mounted at the time of the
        # first chunk, visually placing the inner tool widgets AFTER
        # Claude's entire answer. See ``mark_split`` + the tool_call
        # handler's split loop.
        self._split = False
        body = Static(self.content or "(empty)", markup=False, classes="tool-result-body")
        self._body = body  # held for incremental updates during streaming
        # Auto-collapse only LONG outputs. Short tool results
        # (a 1-line ls, a small grep) are far more useful expanded
        # by default — operators were complaining the TUI looked
        # like "nothing happened" when only the collapsed-peek
        # header was visible. Threshold picked so a 5-line snippet
        # stays open but a 64KB grep dump still folds away.
        line_count = self.content.count("\n") + 1
        char_count = len(self.content)
        start_collapsed = (
            streaming
            or line_count > 12
            or char_count > 800
        )
        super().__init__(
            body,
            title=self._build_title(collapsed=start_collapsed),
            collapsed=start_collapsed,
            classes="tool-result",
        )

    def _build_peek(self) -> str:
        first = (self.content.splitlines()[0] if self.content else "(empty)")
        return first[:80] + "…" if len(first) > 80 else first

    def _build_title(self, *, collapsed: bool) -> str:
        hint = "Ctrl+T to expand" if collapsed else "Ctrl+T to collapse"
        badge = ""
        if self._compaction_state == "truncated":
            badge = "   🗜️ upstream-truncated"
        elif self._compaction_state == "dropped":
            badge = "   🗜️ upstream-dropped"
        # Textual's Collapsible parses the title as Rich markup, so
        # tool results containing [foo] or other bracketed content
        # (web_search JSON, exec stderr with traceback frames, …) get
        # rendered as literal markup tags and corrupt the header. Escape
        # the peek to neutralize brackets without touching our own
        # interpolations (prefix, hint, badge are static).
        from rich.markup import escape as _esc
        return f"{self._prefix} {_esc(self._peek)}   ·   {hint}{badge}"

    def mark_compacted(self, state: str) -> None:
        """Record that this tool result was trimmed/dropped on the wire
        in a subsequent round. Idempotent; "dropped" supersedes "truncated".
        """
        if state not in ("truncated", "dropped"):
            return
        # Once dropped, never demote back to truncated.
        if self._compaction_state == "dropped":
            return
        self._compaction_state = state
        self.title = self._build_title(collapsed=self.collapsed)

    def watch_collapsed(self, collapsed: bool) -> None:
        # Textual's reactive watcher: fires whenever `collapsed` changes
        # (whether via mouse click on the header arrow or via
        # `action_toggle_tool_output`). Refreshes the inline hint so the
        # user always sees what Ctrl+T does *next*, not what it did last.
        # Textual's framework dispatches base-class watchers separately,
        # so no super() chain is needed.
        self.title = self._build_title(collapsed=collapsed)

    def toggle(self) -> bool:
        """Flip the collapsed state and return the new value.

        Used by `action_toggle_tool_output`. The reactive watcher above
        keeps the title hint in sync.
        """
        self.collapsed = not self.collapsed
        return self.collapsed

    def append_streaming(self, text: str) -> None:
        """Append a `tool_delta` chunk while the result is still streaming.

        No-op once `finalize_streaming` has run. The body Static is
        replaced wholesale (Textual's Static renders fastest from a
        single `update()` rather than incremental concatenation).
        """
        if not self._streaming or not text:
            return
        self.content = (self.content + text).rstrip()
        self._body.update(self.content or "(empty)")
        self._peek = self._build_peek()
        self.title = self._build_title(collapsed=self.collapsed)

    def finalize_streaming(self, *, ok: bool, content: Optional[str] = None) -> None:
        """End-of-stream: stamp the result with success/failure and an
        authoritative content body (overrides streamed deltas if the
        final value differs — the agent always sends one).
        """
        self._streaming = False
        self.ok = ok
        if content is not None:
            self.content = content.rstrip()
            self._body.update(self.content or "(empty)")
        self._prefix = "✅" if ok else "❌"
        self._peek = self._build_peek()
        self.title = self._build_title(collapsed=self.collapsed)

    def mark_split(self) -> None:
        """Freeze a streaming widget mid-stream so a subsequent
        ``tool_delta`` for the same call_id mounts a NEW widget below
        whatever else just got placed in the transcript.

        Why: ``delegate_claude`` (and any future streaming-capable tool)
        emits ``tool_call_update`` deltas continuously. The inner Claude
        session may fire ``tool_use`` events in the MIDDLE of the
        outer's stream. Without splitting, every delta lands in the
        original streaming widget (mounted at the moment the FIRST
        delta arrived) — so the inner tool widgets, mounted later, end
        up visually BELOW Claude's entire combined output, including
        text that was emitted AFTER the inner tools ran. That looks to
        the operator like "the tool calls happened AFTER the final
        answer."

        Splitting flips ``_streaming`` to False so the
        ``tool_delta`` handler's ``next(... if w._streaming ...)``
        search returns None and a fresh streaming widget mounts. The
        prefix flips to ``🔧→`` so the operator sees this segment is a
        continuation, not the end. The final ``tool_result`` handler
        notices the prior split and skips the content-replacement
        path (the streamed segments together ARE the authoritative
        content; the agent's final `content` field would duplicate
        them).
        """
        if not self._streaming:
            return
        self._streaming = False
        self._split = True
        # Continuation marker — distinct from ✅ (final ok) and ❌ (final
        # fail). The next segment carries the final ✅/❌.
        self._prefix = "🔧→"
        self._peek = self._build_peek()
        self.title = self._build_title(collapsed=self.collapsed)


class PlanMessage(Vertical):
    """ExitPlanMode plan body, rendered as a prominent transcript card.

    The model emits ``ExitPlanMode {plan: "<markdown>"}`` in plan mode
    when it's done planning and wants the operator to leave plan mode
    and execute. The default tool widgets hide the plan in two ways:
    the ToolCallMessage pill truncates JSON-escaped args at 200 chars,
    and the ToolResultMessage Collapsible auto-folds outputs > 12
    lines / > 800 chars — every real plan is bigger than both caps,
    so the operator saw only "Plan ready — confirm to leave plan mode
    and execute:" and never the plan itself. This widget renders the
    plan as full markdown inline, the same shape as an
    AssistantMessage's content body.
    """

    def __init__(self, plan: str) -> None:
        super().__init__(classes="plan-msg")
        self._plan = (plan or "").strip()

    def compose(self) -> ComposeResult:
        yield Static(
            "📐 plan ready — review and approve to exit plan mode",
            markup=False,
            classes="plan-msg-header",
        )
        body = self._plan or "(empty plan)"
        yield Static(RichMarkdown(body), classes="plan-msg-body")


class OutputSectionMessage(Vertical):
    """One section of an ``OutputSection`` long-form answer.

    The model fires ``OutputSection {section_name, content, …}`` once
    per section when drafting reports or multi-step guides — the
    section body in ``content`` is the actual user-facing answer.
    Rendered through the generic tool widgets the prose ends up as
    a 200-char JSON-escaped pill (``\\n`` literals, brackets, the
    real content cut off) plus a collapsed "Section X/N saved" peek;
    operators report "the output is missing." This widget renders
    the section body as full markdown inline so each section reads
    as its own answer chunk.
    """

    def __init__(self, section_name: str, content: str) -> None:
        super().__init__(classes="section-msg")
        self._section_name = (section_name or "").strip() or "(untitled section)"
        self._content = (content or "").strip()

    def compose(self) -> ComposeResult:
        yield Static(
            f"📄 {self._section_name}",
            markup=False,
            classes="section-msg-header",
        )
        body = self._content or "(empty section)"
        yield Static(RichMarkdown(body), classes="section-msg-body")


class UpdateMessage(Vertical):
    """A file edit (`Update` / `Edit` tool) rendered as a colored code-diff card.

    Named after Claude Code's "Update" — the label Claude Code shows
    when the agent edits a file. The diff is computed *client-side*
    from the tool call's arguments (``old_string`` → ``new_string``),
    so the card appears the instant the call starts, before the tool
    even finishes — and the model's context stays lean because the
    `Update` runner only returns a one-line summary, not the diff.

    This widget is **TUI-only**. The Telegram frontend renders file
    edits as a plain ``🔧 Update…`` header with no diff body: it never
    echoes tool arguments, and the runner's result carries no diff.

    A green border-left marks a normal edit; ``mark_result(ok=False)``
    flips the card to the error palette if the tool reports failure.
    """

    # Cap the rendered diff so a giant edit doesn't flood the
    # transcript. The edit itself still applies in full — this only
    # trims the on-screen card.
    MAX_DIFF_LINES = 200

    def __init__(
        self,
        file_path: str,
        old_string: str,
        new_string: str,
        *,
        replace_all: bool = False,
        call_id: str = "",
    ) -> None:
        super().__init__(classes="update-msg")
        self._file_path = (file_path or "").strip() or "(unknown file)"
        self._old = old_string or ""
        self._new = new_string or ""
        self._replace_all = bool(replace_all)
        # Set so the matching `tool_result` can find THIS card among
        # several un-stamped parallel-edit cards (see `mark_result`).
        self.call_id = call_id or ""
        self._header_static: Optional[Static] = None
        # None while the tool is still running; True/False once the
        # matching tool_result lands (see `mark_result`).
        self._ok: Optional[bool] = None

    def _build_header(self) -> str:
        # Mirror Claude Code's "Update(path)" headline. The marker
        # reflects tool state: ✎ in-flight, ✓ applied, ✗ failed.
        if self._ok is True:
            marker = "✓"
        elif self._ok is False:
            marker = "✗"
        else:
            marker = "✎"
        suffix = "  (replace all)" if self._replace_all else ""
        return f"{marker} Update({self._file_path}){suffix}"

    def _diff_text(self) -> Text:
        """Build a Rich ``Text`` of the unified diff with +/- coloring.

        Uses a ``Text`` object (not a markup string) so source lines
        containing ``[...]`` can't corrupt the render.
        """
        old_lines = self._old.splitlines()
        new_lines = self._new.splitlines()
        diff = list(
            difflib.unified_diff(old_lines, new_lines, lineterm="", n=3)
        )
        # `unified_diff` prepends `--- ` / `+++ ` file-header lines from
        # the empty from/to names — drop them; our card header already
        # names the file.
        diff = [
            ln for ln in diff
            if not ln.startswith("--- ") and not ln.startswith("+++ ")
        ]
        text = Text(no_wrap=False)
        if not diff:
            text.append("(no textual change)", style="dim")
            return text
        shown = diff[: self.MAX_DIFF_LINES]
        for i, line in enumerate(shown):
            if i:
                text.append("\n")
            if line.startswith("@@"):
                text.append(line, style="cyan")
            elif line.startswith("+"):
                text.append(line, style="green")
            elif line.startswith("-"):
                text.append(line, style="red")
            else:
                text.append(line, style="dim")
        hidden = len(diff) - len(shown)
        if hidden > 0:
            text.append(
                f"\n… {hidden} more diff line(s) trimmed", style="dim"
            )
        return text

    def compose(self) -> ComposeResult:
        header = Static(
            self._build_header(), markup=False, classes="update-msg-header"
        )
        self._header_static = header
        yield header
        yield Static(self._diff_text(), classes="update-msg-body")

    def mark_result(self, ok: bool) -> None:
        """Stamp the card with the tool's success/failure once the
        matching ``tool_result`` arrives. Idempotent — safe to call
        before the widget has composed (the header refresh is skipped
        until ``compose`` runs)."""
        self._ok = bool(ok)
        if self._header_static is not None:
            self._header_static.update(self._build_header())
        self.set_class(not self._ok, "update-msg-failed")


class TaskUpdateMessage(Vertical):
    """A TodoWrite task list rendered as an inline transcript card.

    Mounted when the model emits a ``TodoWrite`` tool call, showing
    the full task list with per-item status (☑ completed, ▶ in-progress,
    ☐ pending). Updates in place on subsequent TodoWrite calls so the
    transcript stays clean — no duplicate cards for status nudges.
    Follows the same visual convention as the persistent
    ``#plan-checklist`` footer widget but as a dedicated card in the
    turn transcript, mirroring Claude Code's inline task display.

    Layout (top → bottom): header with progress summary → item list.
    """

    MAX_ITEMS = 12

    def __init__(
        self,
        items: list[dict],
        *,
        call_id: str = "",
    ) -> None:
        super().__init__(classes="task-update-msg")
        self._items: list[dict] = list(items)
        self._call_id = call_id or ""
        self._header_static: Optional[Static] = None
        self._body_static: Optional[Static] = None

    def _build_progress(self) -> tuple[int, int]:
        done = sum(
            1 for it in self._items
            if it.get("status") in ("completed", "done")
        )
        return done, len(self._items)

    def _build_header(self) -> str:
        done, total = self._build_progress()
        if total == 0:
            return "[bold magenta]📝 Tasks[/bold magenta]"
        return f"[bold magenta]📝 Tasks · {done}/{total} done[/bold magenta]"

    def _build_body(self) -> str:
        lines: list[str] = []
        for it in self._items:
            status = it.get("status") or "pending"
            content = (it.get("content") or "").strip()
            active = (it.get("activeForm") or "").strip()
            label = active if (status == "in_progress" and active) else content
            if len(label) > 90:
                label = label[:87] + "…"
            if status in ("completed", "done"):
                lines.append(f"  [dim strike]☑ {label}[/dim strike]")
            elif status == "in_progress":
                lines.append(f"  [bold cyan]▶ {label}[/bold cyan]")
            else:
                lines.append(f"  [dim]☐[/dim] {label}")
        return "\n".join(lines)

    def compose(self) -> ComposeResult:
        header = Static(
            self._build_header(), markup=True, classes="task-update-header"
        )
        self._header_static = header
        yield header
        body = Static(
            self._build_body(), markup=True, classes="task-update-body"
        )
        self._body_static = body
        yield body

    def update_from_todos(self, items: list[dict]) -> None:
        """Update the card with a new TodoWrite payload.

        Merges statuses forward (pending → in_progress → completed)
        so a stale re-emit can't visually regress a row. Content
        matching is by ``content`` key. Best-effort when the widget
        hasn't composed yet (header/body Static references are None).
        """
        if not items:
            return
        rank = {"pending": 0, "in_progress": 1, "completed": 2, "done": 2}
        old_by_content = {it.get("content"): it for it in self._items}
        merged: list[dict] = []
        for n in items:
            content = (n.get("content") or "").strip()
            if not content:
                continue
            old = old_by_content.get(content, {})
            old_rank = rank.get(old.get("status") or "pending", 0)
            new_rank = rank.get(n.get("status") or "pending", 0)
            merged.append({
                "content": content,
                "activeForm": (
                    n.get("activeForm")
                    or old.get("activeForm")
                    or ""
                ),
                "status": (
                    n["status"]
                    if new_rank >= old_rank
                    else old["status"]
                ),
            })
        self._items = merged[: self.MAX_ITEMS]
        if self._header_static is not None:
            self._header_static.update(self._build_header())
        if self._body_static is not None:
            self._body_static.update(self._build_body())


class HarnessTaskListMessage(Vertical):
    """Inline card for the harness ``Task*`` tool family (``TaskCreate``
    / ``TaskUpdate`` / ``TaskList`` / ``TaskGet`` / ``TaskOutput`` /
    ``TaskStop``). Mirrors :class:`TaskUpdateMessage` (the TodoWrite
    card) but keyed by numeric task id — Claude Code's harness Task
    tracker is a separate, persistent list from TodoWrite.

    Mounted lazily on the first ``Task*`` call; subsequent calls update
    the same card in place so the transcript stays clean — no duplicate
    pills for every TaskCreate / TaskUpdate the model fires.
    """

    MAX_ITEMS = 30

    def __init__(self) -> None:
        super().__init__(classes="harness-task-msg")
        # tid -> {"subject": str, "status": str}
        self._rows: dict[str, dict] = {}
        # Insertion order so the card reads top-to-bottom in creation order.
        self._order: list[str] = []
        self._header_static: Optional[Static] = None
        self._body_static: Optional[Static] = None

    def _build_progress(self) -> tuple[int, int]:
        done = sum(
            1 for r in self._rows.values()
            if r.get("status") in ("completed", "done")
        )
        return done, len(self._rows)

    def _build_header(self) -> str:
        done, total = self._build_progress()
        if total == 0:
            return "[bold blue]📋 Tasks[/bold blue]"
        return f"[bold blue]📋 Tasks · {done}/{total} done[/bold blue]"

    def _icon(self, status: str) -> str:
        return {
            "pending": "[dim]☐[/dim]",
            "in_progress": "[bold cyan]▶[/bold cyan]",
            "completed": "[dim strike]☑[/dim strike]",
            "done": "[dim strike]☑[/dim strike]",
            "deleted": "[red]✗[/red]",
        }.get(status, "[dim]?[/dim]")

    def _build_body(self) -> str:
        if not self._rows:
            return "  [dim](no tasks)[/dim]"
        lines: list[str] = []
        for tid in self._order[: self.MAX_ITEMS]:
            r = self._rows.get(tid)
            if not r:
                continue
            label = (r.get("subject") or "").strip()
            if len(label) > 90:
                label = label[:87] + "…"
            status = r.get("status") or "pending"
            icon = self._icon(status)
            if status in ("completed", "done", "deleted"):
                lines.append(f"  {icon} [dim strike]#{tid}[/dim strike] {label}")
            else:
                lines.append(f"  {icon} [bold]#{tid}[/bold] {label}")
        if len(self._order) > self.MAX_ITEMS:
            extra = len(self._order) - self.MAX_ITEMS
            lines.append(f"  [dim]… +{extra} more[/dim]")
        return "\n".join(lines)

    def compose(self) -> ComposeResult:
        header = Static(
            self._build_header(), markup=True, classes="harness-task-header"
        )
        self._header_static = header
        yield header
        body = Static(
            self._build_body(), markup=True, classes="harness-task-body"
        )
        self._body_static = body
        yield body

    def _redraw(self) -> None:
        if self._header_static is not None:
            self._header_static.update(self._build_header())
        if self._body_static is not None:
            self._body_static.update(self._build_body())

    def upsert(
        self,
        tid: str,
        *,
        subject: Optional[str] = None,
        status: Optional[str] = None,
    ) -> None:
        """Insert or merge a task row. Status only advances forward
        (pending → in_progress → completed) so a stale re-emit can't
        visually regress a row. ``deleted`` overrides everything.
        """
        tid = str(tid or "").strip()
        if not tid:
            return
        row = self._rows.get(tid)
        if row is None:
            row = {"subject": "", "status": "pending"}
            self._rows[tid] = row
            self._order.append(tid)
        if subject is not None:
            sb = str(subject).strip()
            if sb:
                row["subject"] = sb
        if status is not None:
            ns = str(status).strip().lower()
            if ns == "deleted":
                row["status"] = "deleted"
            else:
                rank = {
                    "pending": 0, "in_progress": 1,
                    "completed": 2, "done": 2,
                }
                old_rank = rank.get(row.get("status") or "pending", 0)
                new_rank = rank.get(ns, 0)
                if new_rank >= old_rank:
                    row["status"] = ns
        self._redraw()

    def apply_tasklist_payload(self, payload: list[dict]) -> None:
        """Apply a TaskList result (full snapshot of the task store).
        Best-effort: each entry needs at least ``id``; missing fields
        leave the existing row untouched.
        """
        for entry in payload or []:
            if not isinstance(entry, dict):
                continue
            tid = str(entry.get("id") or entry.get("taskId") or "")
            if not tid:
                continue
            self.upsert(
                tid,
                subject=entry.get("subject"),
                status=entry.get("status"),
            )


class SubagentBoxMessage(Vertical):
    """Bordered container that visually frames a single subagent run
    (``delegate_claude`` / ``delegate_codex`` / ``delegate_gemini`` /
    ``delegate_agent``).

    Why: without this wrapper, the subagent's text widget + its inner
    tool widgets mount directly into the parent transcript, interleaving
    with the parent agent's own output. Operators reported "multiple
    agents' messages appear on the same TUI and it's confusing." The
    box gives each subagent run a colored left border + a header pill
    ``🤖 Subagent: <name> · <task summary>`` so the boundary is
    impossible to miss, and a body that hosts the subagent's
    AssistantMessage + every inner ToolCallMessage / ToolResultMessage
    fired during the run.

    Public surface:
      ``body`` — Vertical child where inner widgets should be mounted.
      ``finalize(ok=True)`` — flip the header from running → done/error.
    """

    def __init__(self, label: str, task_summary: str = "") -> None:
        super().__init__(classes="subagent-box")
        self._label = label or "subagent"
        self._task_summary = (task_summary or "").strip()
        self._header_static: Optional[Static] = None
        self._body: Optional[Vertical] = None
        self._done = False
        self._ok = True
        # Per-run progress counters. Bumped from the parent TUI's
        # tool_call / tool_result dispatcher whenever an INNER event
        # arrives (a tool the subagent fired itself), with the actual
        # widget mount suppressed so the parent transcript stays
        # readable. The counters render in the header as
        # ``calls=N done=M`` so the operator sees the subagent is
        # alive even though its inner stream is hidden.
        self._inner_call_count: int = 0
        self._inner_done_count: int = 0
        self._inner_last_tool: str = ""
        self._t_start: float = time.monotonic()

    def _summary_line(self) -> str:
        if not self._task_summary:
            return ""
        s = self._task_summary
        if len(s) > 120:
            s = s[:117] + "…"
        return s

    def _build_header(self) -> str:
        elapsed = max(0.0, time.monotonic() - self._t_start)
        progress = ""
        if self._inner_call_count > 0:
            progress = (
                f" · {self._inner_done_count}/{self._inner_call_count} tools"
            )
            if self._inner_last_tool:
                progress += f" · last: {self._inner_last_tool}"
        if self._done:
            tag = "✅" if self._ok else "❌"
            colour = "green" if self._ok else "red"
            head = (
                f"[bold {colour}]🤖 Subagent · {self._label} · {tag}"
                f"{progress} · {elapsed:.0f}s[/bold {colour}]"
            )
        else:
            head = (
                f"[bold yellow]🤖 Subagent · {self._label} · running…"
                f"{progress} · {elapsed:.0f}s[/bold yellow]"
            )
        summary = self._summary_line()
        if summary:
            head += f"\n[dim]{summary}[/dim]"
        return head

    def note_inner_call(self, tool_name: str) -> None:
        """Bump the in-flight inner-tool counter. Called by the parent
        TUI's tool_call dispatcher whenever an INNER event arrives
        (a tool the subagent fired itself) while the parent has the
        widget mount suppressed — gives the operator a live ``N tools
        in flight · last: Bash`` indicator without flooding the
        transcript."""
        self._inner_call_count += 1
        self._inner_last_tool = (tool_name or "")[:24]
        if self._header_static is not None:
            self._header_static.update(self._build_header())

    def note_inner_done(self) -> None:
        """Bump the completed-inner-tool counter."""
        self._inner_done_count += 1
        if self._header_static is not None:
            self._header_static.update(self._build_header())

    def compose(self) -> ComposeResult:
        self._header_static = Static(
            self._build_header(), markup=True, classes="subagent-box-header"
        )
        yield self._header_static
        self._body = Vertical(classes="subagent-box-body")
        yield self._body

    @property
    def body(self) -> Vertical:
        """Mount target for inner widgets (the subagent's
        AssistantMessage + every tool widget the subagent fires)."""
        # Falls back to ``self`` if Textual hasn't composed yet; the
        # caller's mount will still attach correctly under the box.
        return self._body if self._body is not None else self

    def finalize(self, ok: bool = True) -> None:
        self._done = True
        self._ok = bool(ok)
        if self._header_static is not None:
            self._header_static.update(self._build_header())


class EmptyEosNotice(Static):
    """Inline transcript alert rendered when the upstream model emitted
    a premature EOS on a tool-followup round.

    Triggered by `auto_continue { reason: "empty_stop" }` from the agent
    runtime. The dispatch loop handles the recovery (it injects a nudge
    and resamples); this widget exists so the user sees, persistently in
    the scrollback, that the upstream model glitched on a tool followup.
    """

    def __init__(self, count: int, max_retries: int, round_idx: int) -> None:
        head = (
            f"⚠️ premature EOS on tool call · auto-continuing "
            f"(retry {count}/{max_retries}, round {round_idx})"
        )
        super().__init__(head, markup=False, classes="empty-eos-notice")


# Map from runtime-warning ``event`` slug (the first field
# `_format_runtime_warning` writes) to the human-readable headline shown
# in the transcript banner. Keeping it explicit means the operator sees
# wording tuned to the recovery being taken instead of a raw kebab-case
# event name. Unknown slugs fall back to the slug itself plus the raw
# fields, so a new bridge-side warning doesn't silently disappear.
_RUNTIME_WARNING_HEADLINES: dict[str, str] = {
    "loop-detected": "loop detected — pausing worker",
    "loop-distill": "distill recovery — resuming with summary",
    "loop-force-terminate": "loop force-terminate — turn aborted",
    "post-force-terminate-deny": "post-force-terminate — tool calls denied",
    "nudge": "premature finish — nudging model to continue",
}


class RuntimeWarningNotice(Static):
    """Inline transcript banner rendered when the runtime catches a
    recoverable failure mode mid-turn (loop / nudge / distill /
    force-terminate). Spans the full transcript width with a thick
    coloured border so the operator can see *at a glance* that the agent
    intervened — without this widget the only signal was a few lines of
    text inside the assistant message bubble, easy to miss when the
    model is also streaming prose around it.

    The data comes from the bridge's :func:`_format_runtime_warning`
    output (acp_bridge.py L1153). Each warning is emitted as a single
    ``agent_message_chunk`` whose body starts with one of two well-known
    glyph prefixes:

    - ``⚠ runtime: <event> · k1=v1 · k2=v2 …`` — hard intervention
      (loop hit, force-terminate). Renders red.
    - ``↻ runtime: <event> · …`` — soft recovery (distill, nudge).
      Renders blue.

    The TUI sniffs the chunk prefix in the dispatch loop and routes here
    instead of appending to the assistant message bubble (where it used
    to blend into the model's own prose).
    """

    def __init__(self, glyph: str, event: str, fields: dict[str, str]) -> None:
        self.event = event
        self.fields = dict(fields)
        # Soft (↻ distill / ↻ nudge) vs hard (⚠ loop / ⚠ force-terminate).
        # Carries through to the CSS class so the palette differs and
        # `loop detected` doesn't visually read as `compaction OK`.
        self.soft = glyph == "↻"
        headline = _RUNTIME_WARNING_HEADLINES.get(event, event)
        # One-line body. Lead with the headline so the operator can
        # parse it at a glance; trail with the structured fields so the
        # underlying tier/stream/round/evidence are still visible
        # without expanding anything.
        bits = [f"{glyph} {headline}"]
        for key in ("stream", "tier", "round", "tool"):
            val = fields.get(key)
            if val:
                bits.append(f"{key}={val}")
        evidence = fields.get("evidence", "")
        if evidence:
            # Trim aggressively: the evidence is usually the offending
            # n-gram repeated, often >80 chars of mostly-whitespace
            # noise. A short preview is enough to tell two loops apart.
            preview = evidence.strip().replace("\n", " ")
            if len(preview) > 60:
                preview = preview[:57] + "…"
            bits.append(f"evidence={preview!r}")
        cls = (
            "runtime-warning-notice soft"
            if self.soft
            else "runtime-warning-notice hard"
        )
        super().__init__(" · ".join(bits), markup=False, classes=cls)


# Prefix-sniff helpers for the chunk dispatcher. Kept at module scope so
# the dispatch loop's hot path doesn't re-allocate the prefix tuples on
# every chunk.
_RUNTIME_WARNING_GLYPHS = ("⚠", "↻")
_RUNTIME_WARNING_PREFIX = " runtime: "


def _parse_runtime_warning_chunk(
    text: str,
) -> Optional[tuple[str, str, dict[str, str]]]:
    """Parse a chunk body that *might* be a ``_format_runtime_warning``
    line. Returns ``(glyph, event, fields_dict)`` on a hit; ``None``
    otherwise — in which case the caller should treat the chunk as
    normal model output.

    The bridge formats warnings exactly as ``\\n\\n{glyph} runtime:
    {event} · k1=v1 · k2=v2 …\\n\\n`` (single chunk per warning, see
    acp_bridge.py L1153). We accept leading/trailing whitespace and
    only commit if both the glyph and the ``runtime:`` token are
    present, so legitimate model output that happens to contain a
    similar substring deeper in the chunk won't be misclassified.
    """
    if not text:
        return None
    stripped = text.lstrip()
    if not stripped or stripped[0] not in _RUNTIME_WARNING_GLYPHS:
        return None
    if _RUNTIME_WARNING_PREFIX not in stripped[:32]:
        return None
    glyph = stripped[0]
    body = stripped.split("\n", 1)[0].rstrip()
    parts = [p.strip() for p in body.split(" · ") if p.strip()]
    if not parts:
        return None
    # First piece is "<glyph> runtime: <event>" — slice off the prefix
    # to land on just the event slug.
    head = parts[0]
    if " runtime: " not in head:
        return None
    event = head.split(" runtime: ", 1)[1].strip()
    fields: dict[str, str] = {}
    for piece in parts[1:]:
        if "=" not in piece:
            continue
        k, _, v = piece.partition("=")
        k = k.strip()
        v = v.strip()
        if k:
            fields[k] = v
    return glyph, event, fields


class CompactionNotice(Collapsible):
    """Inline transcript marker rendered when the agent runtime compacted
    the upstream prompt mid-turn.

    Visible by default (so the user notices), and Ctrl+T-collapsible like
    the other expandable widgets. The body shows the full audit:
    estimated tokens removed, the post-compaction prompt size, the
    `tool_call_id`s that were truncated/dropped on the wire, and how
    many old user/assistant turns (if any) were discarded.

    The original transcript content for any affected `ToolResultMessage`
    is unchanged — `_apply_compaction_audit` *also* tags those widgets
    with a "🗜️ upstream-truncated/dropped" badge so the user can expand
    them and see exactly what the upstream model no longer has.
    """

    def __init__(self, reason: str, payload: dict) -> None:
        self.reason = reason
        self.payload = payload
        removed = int(payload.get("removed_tokens") or 0)
        new_size_raw = payload.get("new_prompt_tokens")
        new_size = int(new_size_raw) if isinstance(new_size_raw, (int, float)) and new_size_raw > 0 else None
        n_trunc = len(payload.get("truncated_tool_call_ids") or [])
        n_drop = len(payload.get("dropped_tool_call_ids") or [])
        n_turns = int(payload.get("dropped_turns") or 0)
        # LLM-summarization stats (present when the path went through
        # `_compact_via_llm` — the manual `/compact` endpoint always
        # does, the in-turn proactive trigger does too). When absent
        # the path was the deterministic post-overflow squeeze.
        summary_chars = int(payload.get("summary_chars") or 0)
        llm_pt = payload.get("prompt_tokens")
        llm_ct = payload.get("completion_tokens")
        llm_dur = payload.get("duration_s")
        llm_phase = payload.get("phase")
        llm_finish = payload.get("finish_reason")
        used_llm = summary_chars > 0 or llm_ct is not None

        emoji = "🗜️" if reason == "compacted" else "⚠️"
        label = "compacted" if reason == "compacted" else "compacted (after 400)"
        if used_llm:
            # Lead with proof the LLM ran: summary length + tokens-in/out
            # + wall-clock. This is the user's "yes the model summarised"
            # cue, otherwise `/compact` looks like a no-op.
            head = f"{emoji} {label} · summary {summary_chars} chars"
            tail_bits = []
            if isinstance(llm_pt, (int, float)) and llm_pt:
                tail_bits.append(f"pt {int(llm_pt)}")
            if isinstance(llm_ct, (int, float)) and llm_ct:
                tail_bits.append(f"ct {int(llm_ct)}")
            if isinstance(llm_dur, (int, float)) and llm_dur:
                tail_bits.append(f"{float(llm_dur):.1f}s")
            if tail_bits:
                head += " · " + " · ".join(tail_bits)
            if removed:
                head += f" · ~{removed} tok freed"
        else:
            head = f"{emoji} {label} · ~{removed} tok removed"
        if new_size is not None:
            head += f" · prompt now ~{new_size} tok"
        if n_trunc or n_drop or n_turns:
            bits = []
            if n_trunc:
                bits.append(f"{n_trunc} tool result(s) truncated")
            if n_drop:
                bits.append(f"{n_drop} tool result(s) dropped")
            if n_turns:
                bits.append(f"{n_turns} old turn(s) collapsed")
            head += " · " + ", ".join(bits)
        head += "   ·   Ctrl+T to expand"
        self._head_collapsed = head
        self._head_expanded = head.replace("Ctrl+T to expand", "Ctrl+T to collapse")

        # Body: structured dump. LLM stats are surfaced explicitly so
        # the user can confirm an actual summarization round happened.
        body_lines = [
            f"reason: {reason}",
            f"round: {payload.get('round')}",
            f"removed_tokens (est): {removed}",
            f"new_prompt_tokens (est): {new_size if new_size is not None else 'n/a (next turn)'}",
        ]
        if used_llm:
            body_lines.extend([
                "",
                "LLM summarization:",
                f"  summary_chars:     {summary_chars}",
                f"  prompt_tokens:     {llm_pt}",
                f"  completion_tokens: {llm_ct}",
                f"  duration_s:        {llm_dur}",
                f"  phase:             {llm_phase}",
                f"  finish_reason:     {llm_finish}",
            ])
        body_lines.extend([
            "",
            f"truncated tool_call_ids ({n_trunc}):",
        ])
        for tcid in (payload.get("truncated_tool_call_ids") or []):
            body_lines.append(f"  · {tcid}")
        body_lines.append("")
        body_lines.append(f"dropped tool_call_ids ({n_drop}):")
        for tcid in (payload.get("dropped_tool_call_ids") or []):
            body_lines.append(f"  · {tcid}")
        if n_turns:
            body_lines.append("")
            note = (
                "old turns collapsed into the summary above"
                if used_llm
                else "old turns dropped"
            )
            body_lines.append(f"{note}: {n_turns}")
        body_lines.append("")
        body_lines.append(
            "Note: the transcript above still has the original (untrimmed) "
            "tool outputs — only the upstream model's view was compacted."
        )
        body = Static("\n".join(body_lines), markup=False,
                      classes="compaction-notice-body")
        super().__init__(
            body,
            title=self._head_collapsed,
            collapsed=False,  # visible by default — this is the whole point
            classes="compaction-notice",
        )

    def watch_collapsed(self, collapsed: bool) -> None:
        self.title = self._head_collapsed if collapsed else self._head_expanded

    def toggle(self) -> bool:
        self.collapsed = not self.collapsed
        return self.collapsed


class PermissionModal(ModalScreen[str]):
    """Three-button confirmation modal for `permission_request` events.

    The screen returns one of `"yes"` / `"yes_dont_ask"` / `"no"` via
    `dismiss(...)`. The caller (TUI's `_handle_permission_request`) then
    POSTs the answer to `/v1/turns/{tid}/permission` and the agent
    resumes the dispatch loop.
    """

    CSS = """
    PermissionModal {
        align: center middle;
    }
    #perm-box {
        width: 80%;
        max-width: 100;
        height: auto;
        border: thick $accent;
        background: $panel;
        padding: 1 2;
    }
    #perm-title {
        text-style: bold;
        color: $warning;
        margin-bottom: 1;
    }
    #perm-args {
        background: $boost;
        color: $text;
        padding: 1;
        margin-bottom: 1;
    }
    #perm-buttons {
        height: auto;
        align-horizontal: right;
    }
    #perm-buttons Button { margin-left: 1; }
    """

    BINDINGS = [
        Binding("y", "answer('yes')", "Yes", show=True),
        Binding("a", "answer('yes_dont_ask')", "Always", show=True),
        Binding("n", "answer('no')", "No", show=True),
        Binding("escape", "answer('no')", "No", show=False),
    ]

    def __init__(self, *, tool: str, kind: str, arguments: dict) -> None:
        super().__init__()
        self._tool = tool
        self._kind = kind
        self._arguments = arguments

    def compose(self) -> ComposeResult:
        with Vertical(id="perm-box"):
            yield Label(f"⚠️  Tool call requires confirmation", id="perm-title")
            yield Label(f"tool: {self._tool}  ·  kind: {self._kind}")
            yield Static(
                json.dumps(self._arguments, indent=2, ensure_ascii=False),
                markup=False,
                id="perm-args",
            )
            with Horizontal(id="perm-buttons"):
                yield Button("Yes (y)", id="b-yes", variant="success")
                yield Button("Yes, don't ask again (a)", id="b-always", variant="primary")
                yield Button("No (n / esc)", id="b-no", variant="error")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        mapping = {"b-yes": "yes", "b-always": "yes_dont_ask", "b-no": "no"}
        self.dismiss(mapping.get(event.button.id, "no"))

    def action_answer(self, response: str) -> None:
        self.dismiss(response)


# Seconds a permission prompt stays open before it auto-denies. Matches
# the agent-side ``_PERMISSION_PROMPT_TIMEOUT_S`` backstop so the modal
# resolves itself rather than lingering after the agent has already
# moved on. "No answer" means "no" — see ``AcpPermissionModal``.
_ACP_PERMISSION_TIMEOUT_S: float = 30.0


class AcpPermissionModal(ModalScreen[str]):
    """Three-button modal for an ACP ``session/request_permission``.

    Distinct from :class:`PermissionModal` (the legacy CLI-engine
    ``permission_request`` event path): this one is wired straight to
    the ACP inbound handler — :meth:`AgentChatApp._on_request_permission`
    pops it from inside the client read loop and the agent's outbound
    request stays parked on its future until ``dismiss(...)`` fires.

    ``dismiss`` returns one of the ACP option ids — ``"allow_once"`` /
    ``"allow_always"`` / ``"reject_once"``. Esc, the timeout, and every
    error path resolve to ``"reject_once"``: a destructive op only
    reaches this modal because the agent decided it needs human
    sign-off, so anything short of an explicit allow is a no.
    """

    CSS = """
    AcpPermissionModal {
        align: center middle;
    }
    #acp-perm-box {
        width: 80%;
        max-width: 100;
        height: auto;
        border: thick $error;
        background: $panel;
        padding: 1 2;
    }
    #acp-perm-title {
        text-style: bold;
        color: $error;
        margin-bottom: 1;
    }
    #acp-perm-args {
        background: $boost;
        color: $text;
        padding: 1;
        margin-bottom: 1;
    }
    #acp-perm-countdown {
        color: $text-muted;
        margin-bottom: 1;
    }
    #acp-perm-buttons {
        height: auto;
        align-horizontal: right;
    }
    #acp-perm-buttons Button { margin-left: 1; }
    """

    BINDINGS = [
        Binding("a", "answer('allow_once')", "Allow once", show=True),
        Binding("s", "answer('allow_always')", "Allow always", show=True),
        Binding("r", "answer('reject_once')", "Reject", show=True),
        Binding("escape", "answer('reject_once')", "Reject", show=False),
    ]

    def __init__(self, params: dict) -> None:
        super().__init__()
        tool_call = params.get("toolCall") if isinstance(params, dict) else {}
        if not isinstance(tool_call, dict):
            tool_call = {}
        self._title = str(tool_call.get("title") or "tool")
        self._kind = str(tool_call.get("kind") or "other")
        raw_input = tool_call.get("rawInput")
        self._arguments = raw_input if isinstance(raw_input, dict) else {}
        self._remaining = int(_ACP_PERMISSION_TIMEOUT_S)
        self._countdown_timer = None
        self._resolved = False

    def compose(self) -> ComposeResult:
        with Vertical(id="acp-perm-box"):
            yield Label("⛔  Destructive tool call needs approval", id="acp-perm-title")
            yield Label(f"tool: {self._title}  ·  kind: {self._kind}")
            yield Static(
                json.dumps(self._arguments, indent=2, ensure_ascii=False),
                markup=False,
                id="acp-perm-args",
            )
            yield Label(
                f"auto-deny in {self._remaining}s if unanswered",
                id="acp-perm-countdown",
            )
            with Horizontal(id="acp-perm-buttons"):
                yield Button("Allow once (a)", id="acp-b-allow", variant="success")
                yield Button("Allow always (s)", id="acp-b-always", variant="primary")
                yield Button("Reject (r / esc)", id="acp-b-reject", variant="error")

    def on_mount(self) -> None:
        # Tick a 1s countdown; auto-deny when it hits zero so the modal
        # never outlives the agent-side timeout.
        self._countdown_timer = self.set_interval(1.0, self._tick)

    def _tick(self) -> None:
        self._remaining -= 1
        if self._remaining <= 0:
            self.action_answer("reject_once")
            return
        try:
            self.query_one("#acp-perm-countdown", Label).update(
                f"auto-deny in {self._remaining}s if unanswered"
            )
        except Exception:  # noqa: BLE001 - widget may be tearing down
            pass

    def on_button_pressed(self, event: Button.Pressed) -> None:
        mapping = {
            "acp-b-allow": "allow_once",
            "acp-b-always": "allow_always",
            "acp-b-reject": "reject_once",
        }
        self.action_answer(mapping.get(event.button.id, "reject_once"))

    def action_answer(self, option_id: str) -> None:
        # Guard against a double-resolve (a button press racing the
        # timeout tick) — ModalScreen.dismiss is not re-entrant.
        if self._resolved:
            return
        self._resolved = True
        if self._countdown_timer is not None:
            try:
                self._countdown_timer.stop()
            except Exception:  # noqa: BLE001
                pass
            self._countdown_timer = None
        self.dismiss(option_id)


class QuestionsModal(ModalScreen[dict]):
    """Multi-question selection modal for ``session/ask_user``.

    Renders 1–4 questions, each with 2–4 options + an "Other" free-form
    Input. Single-select questions use a ``RadioSet``; multi-select
    questions use a vertical ``Checkbox`` group. Submit returns a dict
    shaped like the wire response::

        {
          "answers": [
            {"question": <str>, "selected": [<label>, ...], "notes": <str>},
            ...
          ]
        }

    Esc / Cancel returns an empty answers list so the agent's bridge
    can synthesize a "user cancelled" tool_result rather than hang.
    """

    CSS = """
    QuestionsModal {
        align: center middle;
    }
    #q-box {
        width: 90%;
        max-width: 120;
        height: auto;
        max-height: 90%;
        border: thick $accent;
        background: $panel;
        padding: 1 2;
    }
    #q-title {
        text-style: bold;
        color: $accent;
        margin-bottom: 1;
    }
    #q-scroll {
        height: auto;
        max-height: 30;
    }
    .q-panel {
        height: auto;
        margin-bottom: 1;
        padding: 0 1;
        border-left: thick $accent 50%;
    }
    .q-header {
        text-style: bold;
        color: $warning;
    }
    .q-text {
        margin-bottom: 1;
    }
    .q-notes-label {
        color: $text-muted;
        margin-top: 1;
    }
    #q-buttons {
        height: auto;
        align-horizontal: right;
        margin-top: 1;
    }
    #q-buttons Button { margin-left: 1; }
    """

    BINDINGS = [
        Binding("escape", "cancel", "Cancel", show=True),
        Binding("ctrl+s", "submit", "Submit", show=True),
    ]

    def __init__(self, questions: list[dict]) -> None:
        super().__init__()
        # Defensive copy so we own the structure for the lifetime of
        # the modal — the agent_client sometimes hands us aliased
        # dicts from the JSON-RPC frame.
        self._questions: list[dict] = [
            dict(q) for q in (questions or []) if isinstance(q, dict)
        ]
        # Map question index → (radio_set_id | None, [(option_label, checkbox_id), ...], notes_input_id)
        # so the submit handler can walk the widget tree by id rather than
        # holding refs (which Textual reuses across screen pushes).
        self._index: list[dict] = []

    def on_mount(self) -> None:
        """Focus the first question's selector so keyboard nav works
        without an extra Tab. Without this, Textual's default tab
        order lands on the Submit button — so number-key bindings
        and arrow-key option nav both miss their target until the
        operator manually Tabs back into the question panel."""
        if not self._index:
            return
        first = self._index[0]
        try:
            if first.get("multi") and first.get("checkboxes"):
                _label, cb_id = first["checkboxes"][0]
                self.query_one(f"#{cb_id}", Checkbox).focus()
            elif first.get("radio_id"):
                self.query_one(f"#{first['radio_id']}", RadioSet).focus()
        except Exception:  # noqa: BLE001
            # Widget tree not ready yet (race against Textual's mount
            # ordering) — fall back to default focus rather than crash
            # the modal on a layout edge case.
            pass

    def _focused_question_index(self) -> int | None:
        """Return the index of the question whose RadioSet / Checkbox /
        RadioButton / notes Input currently has focus, or ``None`` if
        focus is outside the question panels (e.g. on Submit / Cancel).
        Widget ids follow the ``q-{qi}-…`` pattern set in
        :meth:`_compose_question`, so a single regex covers every
        selector kind."""
        f = self.focused
        if f is None:
            return None
        import re
        m = re.match(r"q-(\d+)-", f.id or "")
        if not m:
            return None
        qi = int(m.group(1))
        return qi if 0 <= qi < len(self._index) else None

    def on_key(self, event) -> None:  # noqa: ANN001
        """Number-key (1–4) selects option N of the currently-focused
        question. Yields to focused ``Input`` widgets so typing a
        digit into the "Other (free-form)" field stays a digit instead
        of toggling an option behind the user's back — matches the
        principle of least surprise. Operators on a Cancel/Submit
        button get the same shortcut to set the focused question
        without round-tripping back through Tab."""
        key = event.key
        if key not in ("1", "2", "3", "4"):
            return
        if isinstance(self.focused, Input):
            # Operator is typing in the notes field; the digit belongs
            # to the input, not us.
            return
        qi = self._focused_question_index()
        if qi is None:
            return
        oi = int(key) - 1
        entry = self._index[qi]
        options = entry.get("checkboxes") or []
        if oi >= len(options):
            return
        event.stop()
        _label, widget_id = options[oi]
        try:
            if entry.get("multi"):
                cb = self.query_one(f"#{widget_id}", Checkbox)
                cb.value = not cb.value
                cb.focus()
            else:
                # Set the matching RadioButton; RadioSet's own logic
                # turns the previously-pressed button off.
                rb = self.query_one(f"#{widget_id}", RadioButton)
                rb.value = True
                rb.focus()
        except Exception:  # noqa: BLE001
            pass

    def compose(self) -> ComposeResult:
        with Vertical(id="q-box"):
            n = len(self._questions)
            yield Label(
                f"❓  {n} question{'s' if n != 1 else ''}  ·  "
                "Ctrl+S submit  ·  Esc cancel",
                id="q-title",
            )
            with VerticalScroll(id="q-scroll"):
                for qi, q in enumerate(self._questions):
                    yield from self._compose_question(qi, q)
            with Horizontal(id="q-buttons"):
                yield Button("Submit (Ctrl+S)", id="q-submit", variant="success")
                yield Button("Cancel (Esc)", id="q-cancel", variant="error")

    def _compose_question(self, qi: int, q: dict) -> ComposeResult:
        header = str(q.get("header") or "").strip() or f"Question {qi + 1}"
        question = str(q.get("question") or "").strip() or "(no question text)"
        multi = bool(q.get("multiSelect"))
        options = q.get("options") or []
        with Vertical(classes="q-panel"):
            yield Static(f"[{header}]", classes="q-header")
            yield Label(question, classes="q-text")
            entry: dict = {"multi": multi, "checkboxes": [], "radio_id": None}
            if multi:
                # One Checkbox per option, stacked vertically.
                for oi, opt in enumerate(options):
                    if not isinstance(opt, dict):
                        continue
                    label = str(opt.get("label") or "").strip()
                    desc = str(opt.get("description") or "").strip()
                    if not label:
                        continue
                    cb_label = f"{label} — {desc}" if desc else label
                    cb_id = f"q-{qi}-cb-{oi}"
                    entry["checkboxes"].append((label, cb_id))
                    yield Checkbox(cb_label, id=cb_id)
            else:
                rs_id = f"q-{qi}-radio"
                entry["radio_id"] = rs_id
                # RadioSet wraps a tuple of RadioButtons; the first
                # button is pre-selected so Submit always has a value.
                buttons: list[RadioButton] = []
                first_set = False
                for oi, opt in enumerate(options):
                    if not isinstance(opt, dict):
                        continue
                    label = str(opt.get("label") or "").strip()
                    desc = str(opt.get("description") or "").strip()
                    if not label:
                        continue
                    rb_label = f"{label} — {desc}" if desc else label
                    rb_id = f"q-{qi}-rb-{oi}"
                    entry["checkboxes"].append((label, rb_id))
                    buttons.append(
                        RadioButton(rb_label, id=rb_id, value=not first_set)
                    )
                    first_set = True
                yield RadioSet(*buttons, id=rs_id)
            notes_id = f"q-{qi}-notes"
            entry["notes_id"] = notes_id
            yield Label("Other (free-form, optional):", classes="q-notes-label")
            yield Input(placeholder="…", id=notes_id)
            self._index.append(entry)

    def _collect_answers(self) -> dict:
        answers: list[dict] = []
        for qi, q in enumerate(self._questions):
            try:
                entry = self._index[qi]
            except IndexError:
                continue
            selected: list[str] = []
            if entry["multi"]:
                for label, cb_id in entry["checkboxes"]:
                    try:
                        cb = self.query_one(f"#{cb_id}", Checkbox)
                    except Exception:  # noqa: BLE001
                        continue
                    if cb.value:
                        selected.append(label)
            else:
                rs_id = entry.get("radio_id")
                if rs_id:
                    try:
                        rs = self.query_one(f"#{rs_id}", RadioSet)
                    except Exception:  # noqa: BLE001
                        rs = None
                    if rs is not None and rs.pressed_button is not None:
                        pressed_id = rs.pressed_button.id or ""
                        for label, rb_id in entry["checkboxes"]:
                            if rb_id == pressed_id:
                                selected.append(label)
                                break
            notes = ""
            notes_id = entry.get("notes_id")
            if notes_id:
                try:
                    notes = self.query_one(f"#{notes_id}", Input).value.strip()
                except Exception:  # noqa: BLE001
                    notes = ""
            answers.append(
                {
                    "question": str(q.get("question") or ""),
                    "selected": selected,
                    "notes": notes,
                }
            )
        return {"answers": answers}

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "q-submit":
            self.dismiss(self._collect_answers())
        elif event.button.id == "q-cancel":
            self.dismiss({"answers": [], "cancelled": True})

    def action_submit(self) -> None:
        self.dismiss(self._collect_answers())

    def action_cancel(self) -> None:
        self.dismiss({"answers": [], "cancelled": True})


def _humanize_age(ts: str) -> str:
    """Render an ISO-8601 timestamp as `"X min ago"` / `"X hour(s) ago"` /
    `"X day(s) ago"` / `"just now"`. Returns `"?"` on a parse failure so
    the picker stays usable even with malformed session JSON.
    """
    if not ts:
        return "?"
    try:
        # `fromisoformat` accepts the ISO-8601 we save (`+00:00` offset).
        from datetime import datetime, timezone
        when = datetime.fromisoformat(ts)
        if when.tzinfo is None:
            when = when.replace(tzinfo=timezone.utc)
        delta_s = (datetime.now(timezone.utc) - when).total_seconds()
    except (ValueError, TypeError):
        return "?"
    if delta_s < 0:
        # Future timestamps shouldn't happen in normal flow, but a clock
        # skew between agent host and TUI host could put us here. Fall
        # back to "just now" rather than rendering a negative age.
        return "just now"
    if delta_s < 45:
        return "just now"
    if delta_s < 60 * 90:
        return f"{int(delta_s / 60)} min ago"
    if delta_s < 60 * 60 * 36:
        return f"{int(delta_s / 3600)} hour" + ("s ago" if delta_s >= 7200 else " ago")
    days = int(delta_s / 86400)
    return f"{days} day" + ("s ago" if days != 1 else " ago")


class MonitorPanelModal(ModalScreen[None]):
    """Live shells panel — list every subprocess monitor for the active
    session, navigate with up/down, press ``x`` to SIGTERM the
    selected one, ``q`` / ``Escape`` to dismiss.

    Two-pane layout:

    - **Top:** every shell the model spawned via ``monitor_start(...)``.
      Source: per-session sidecar at
      ``<sessions_dir>/<sid>.monitors.json`` written by every
      ``monitor_start`` / ``monitor_stop`` runner call. A 1.5 s timer
      refreshes the list so a process that exits behind the operator's
      back disappears without a manual reload.
    - **Bottom:** tail of the currently-selected shell's logfile (path
      carried in the sidecar's ``log_path`` field; the monitor
      subprocess writes to it directly so reading from the TUI is
      process-safe — no IPC needed). Auto-scrolls in follow-mode (``f``
      toggles); ``Ctrl+L`` clears.

    Discoverability: opened via the ``/shells`` slash command, the
    older ``/monitors`` alias, or the ``Ctrl+S`` key binding.

    ``x`` sends SIGTERM directly to the recorded PID — same path
    ``MonitorRegistry._stop_by_sidecar`` uses, just bypassing the
    registry round-trip so the panel is responsive even if no tool
    subprocess is currently alive.
    """

    CSS = """
    MonitorPanelModal {
        align: center middle;
    }
    #mon-box {
        width: 90%;
        max-width: 160;
        height: 90%;
        max-height: 50;
        border: thick $accent;
        background: $panel;
        padding: 1 2;
    }
    #mon-title {
        text-style: bold;
        color: $accent;
        margin-bottom: 1;
    }
    /* Top pane: the list of subprocesses. Fixed minimum + flex up to
       40% of the modal so a long list doesn't crowd the output pane. */
    #mon-list {
        height: 30%;
        min-height: 6;
        border: round $accent 30%;
        background: $boost;
    }
    #mon-list > ListItem {
        padding: 0 1;
        height: 1;
    }
    #mon-list > ListItem.--highlight {
        background: $accent 30%;
    }
    #mon-list > ListItem.dead {
        color: $text-muted;
    }
    /* Bottom pane: tail of the currently-selected shell's logfile. */
    #mon-out-header {
        color: $text-muted;
        margin: 1 0 0 0;
    }
    #mon-out {
        height: 1fr;
        border: round $accent 30%;
        background: $boost;
        padding: 0 1;
        overflow-y: auto;
    }
    #mon-help {
        color: $text-muted;
        margin-top: 1;
    }
    """

    BINDINGS = [
        Binding("escape", "cancel", "Close", show=True),
        Binding("q",      "cancel", "Close", show=True),
        Binding("x",      "kill",   "Kill",  show=True),
        Binding("up",     "cursor_up",   "Up",   show=False),
        Binding("down",   "cursor_down", "Down", show=False),
        Binding("r",      "reload", "Reload", show=True),
        Binding("ctrl+l", "clear_output", "Clear", show=True),
        Binding("f",      "follow",  "Follow", show=True),
    ]

    REFRESH_INTERVAL_S = 1.5
    # Tail of the selected shell's logfile shown in the bottom pane.
    # Big enough to read a useful slice of stdout, small enough that a
    # runaway monitor doesn't lock the modal up.
    OUTPUT_TAIL_BYTES = 16 * 1024
    OUTPUT_TAIL_LINES = 200

    def __init__(self, sessions_dir: Path, session_id: str) -> None:
        super().__init__()
        self._sessions_dir = Path(sessions_dir)
        self._session_id = session_id
        self._rows: list[dict] = []
        self._listview: Optional[ListView] = None
        self._output: Optional[RichLog] = None
        self._output_header: Optional[Label] = None
        # When ``_follow`` is True the bottom pane auto-scrolls to the
        # end on every refresh. Disabled by the operator (Ctrl+L /
        # manual scroll) so they can pin to a particular slice of
        # output without it jumping away on each tick.
        self._follow = True
        self._timer = None

    def compose(self) -> ComposeResult:
        with Vertical(id="mon-box"):
            yield Label(
                "🖥️   Shells  ·  ↑/↓ navigate  ·  x kill  "
                "·  r reload  ·  f follow  ·  Ctrl+L clear  ·  q/Esc close",
                id="mon-title",
            )
            self._rows = self._load_rows()
            self._listview = ListView(
                *self._build_items(self._rows),
                id="mon-list",
            )
            yield self._listview
            self._output_header = Label(
                "(select a shell to tail its output)",
                id="mon-out-header",
            )
            yield self._output_header
            # ``RichLog`` is purpose-built for tailing line-oriented
            # output: it scrolls itself, handles overflow, and accepts
            # plain strings via ``.write(line)``. We ``.clear()`` + bulk-
            # write on each refresh so the tail always reflects the
            # latest slice of the logfile rather than an ever-growing
            # buffer.
            self._output = RichLog(
                id="mon-out",
                wrap=False,
                highlight=False,
                markup=False,
                auto_scroll=True,
            )
            yield self._output
            yield Label(
                "Tip: shells are spawned by the model via "
                "``monitor_start(...)``. The model also has tools to "
                "send input (``monitor_input``) and read output "
                "(``BashOutput``) — this panel is the operator's view.",
                id="mon-help",
            )

    def on_mount(self) -> None:
        # Periodic refresh so a monitor that exits / is killed elsewhere
        # disappears without manual reload. The same tick re-tails the
        # selected shell's logfile, so the bottom pane updates without
        # the operator pressing anything.
        self._timer = self.set_interval(self.REFRESH_INTERVAL_S, self._refresh)
        # Seed the output pane immediately if there's a current selection.
        self._refresh_output()

    def on_list_view_highlighted(self, event: Any) -> None:
        """ListView highlight changed (cursor moved up/down/clicked).
        Re-tail the newly selected shell's logfile immediately so the
        bottom pane responds without waiting for the next refresh tick."""
        # We don't filter on the event source — there's only one ListView
        # in this modal so any highlighted event refers to the shells list.
        self._refresh_output()

    def _load_rows(self) -> list[dict]:
        from rtxclaw_core.tools.monitor import live_monitors_for_session
        try:
            return live_monitors_for_session(
                self._sessions_dir, self._session_id,
            )
        except Exception:  # noqa: BLE001
            return []

    def _build_items(self, rows: list[dict]) -> list[ListItem]:
        items: list[ListItem] = []
        if not rows:
            items.append(ListItem(Static(
                "(no live monitors)", markup=False,
            )))
            return items
        for n, r in enumerate(rows, start=1):
            alive = bool(r.get("alive"))
            state = "running" if alive else "exited"
            pid = r.get("pid")
            mid = (r.get("monitor_id") or "")[:12]
            cmd = (r.get("command") or "")[:80]
            row = (
                f" {n:>2}. [{state:<7}] pid={pid!s:<7} {mid}  ·  {cmd}"
            )
            item = ListItem(Static(row, markup=False))
            if not alive:
                item.add_class("dead")
            items.append(item)
        return items

    def _refresh(self) -> None:
        if self._listview is None:
            return
        prev_idx = self._listview.index or 0
        loaded = self._load_rows()
        # Auto-cleanup: drop entries that are dead AND have no exit
        # observation pending. The watch_exit hook already removes
        # natural exits via the sidecar; this catches monitors that
        # were SIGTERMed via `x` in the panel (no exit_code observed
        # because the stopper was outside the registry). After one
        # tick of being shown as "exited", drop them so the panel
        # doesn't accumulate stale rows.
        previously_alive_ids = {
            r.get("monitor_id") for r in self._rows if r.get("alive")
        }
        kept: list[dict] = []
        for r in loaded:
            mid = r.get("monitor_id")
            if not r.get("alive") and mid in previously_alive_ids:
                # Just transitioned to dead — drop from sidecar.
                self._drop_dead_entry(mid)
                continue
            kept.append(r)
        self._rows = kept
        self._listview.clear()
        for item in self._build_items(self._rows):
            self._listview.append(item)
        if self._rows:
            self._listview.index = min(prev_idx, len(self._rows) - 1)
        # Re-tail the selected shell's logfile every tick so the bottom
        # pane stays current. Cheap on its own (we only read the tail of
        # one file) — no need for a separate timer.
        self._refresh_output()

    def _selected_row(self) -> Optional[dict]:
        """Return the row dict the operator currently has highlighted,
        or None if the list is empty / no valid index."""
        if not self._rows or self._listview is None:
            return None
        idx = self._listview.index
        if idx is None or not (0 <= idx < len(self._rows)):
            return None
        return self._rows[idx]

    def _load_tail(self, row: dict) -> str:
        """Read the trailing ~16 KB / 200 lines of the selected shell's
        logfile. The sidecar carries ``log_path`` (see
        ``monitor.py::_GLOBAL_REGISTRY.start``); the file is appended
        to by the monitor subprocess directly, so reading it from the
        TUI is process-safe — no IPC needed.

        Returns ``"(no log on disk)"`` when the sidecar lacks a
        ``log_path`` or the file isn't readable yet."""
        path_str = row.get("log_path") or ""
        if not path_str:
            return "(no log on disk)"
        try:
            p = Path(path_str)
            size = p.stat().st_size
        except OSError as e:
            return f"(can't stat logfile: {e})"
        if size == 0:
            return "(logfile is empty — shell hasn't written anything yet)"
        # Read just the tail. open + seek for the byte budget; then
        # split + take the last N lines so a single huge line doesn't
        # consume the whole budget.
        offset = max(0, size - self.OUTPUT_TAIL_BYTES)
        try:
            with p.open("rb") as f:
                f.seek(offset)
                blob = f.read()
        except OSError as e:
            return f"(can't read logfile: {e})"
        text = blob.decode("utf-8", errors="replace")
        # If we sliced into the middle of a line, drop the partial first
        # line so the output reads cleanly.
        if offset > 0:
            nl = text.find("\n")
            if nl >= 0:
                text = text[nl + 1:]
        lines = text.splitlines()
        if len(lines) > self.OUTPUT_TAIL_LINES:
            lines = lines[-self.OUTPUT_TAIL_LINES:]
        return "\n".join(lines)

    def _refresh_output(self) -> None:
        """Repaint the bottom pane with the current selection's logfile
        tail. Updates the header to identify which shell is showing.
        Safe to call before the modal has fully mounted (the widget
        handles are None then — bail quietly)."""
        if self._output is None or self._output_header is None:
            return
        row = self._selected_row()
        if row is None:
            self._output_header.update("(no shells)")
            self._output.clear()
            return
        mid = (row.get("monitor_id") or "")[:12]
        pid = row.get("pid")
        alive = bool(row.get("alive"))
        state = "● running" if alive else "○ exited"
        cmd_preview = (row.get("command") or "")[:80]
        header = f"{state}  ·  pid={pid}  ·  {mid}  ·  {cmd_preview}"
        if not self._follow:
            header += "  ·  [paused — press f to resume follow]"
        self._output_header.update(header)
        body = self._load_tail(row)
        # Bulk replace: clear, then write each line. RichLog appends
        # internally and auto-scrolls; we lean on its own scroll
        # behaviour rather than re-implementing.
        self._output.clear()
        for line in body.splitlines() or [""]:
            self._output.write(line)
        # ``auto_scroll=True`` (set at construction) keeps us pinned to
        # the bottom when follow-mode is on. If the operator paused
        # follow we leave the scroll position alone.

    def action_clear_output(self) -> None:
        """Ctrl+L — clear the bottom pane visually (next tick refills).
        Useful when a noisy shell has flooded the buffer and the
        operator wants a clean slate to read from."""
        if self._output is not None:
            self._output.clear()

    def action_follow(self) -> None:
        """f — toggle follow-mode for the bottom pane. When OFF, the
        pane keeps the operator's manual scroll position; when ON, it
        auto-scrolls to the end on every refresh.

        Toggling also flips ``RichLog.auto_scroll`` so freshly-written
        lines during the next refresh respect the operator's choice."""
        self._follow = not self._follow
        if self._output is not None:
            self._output.auto_scroll = self._follow
        self._refresh_output()

    def action_reload(self) -> None:
        self._refresh()

    def action_cursor_up(self) -> None:
        if self._listview is not None:
            self._listview.action_cursor_up()
            # ListView fires Highlighted as a Message, which our
            # `on_list_view_highlighted` handler picks up — that's where
            # the output pane re-tail happens. Explicit call here as a
            # belt-and-suspenders in case the message dispatch races a
            # rapid up/up burst.
            self._refresh_output()

    def action_cursor_down(self) -> None:
        if self._listview is not None:
            self._listview.action_cursor_down()
            self._refresh_output()

    def action_kill(self) -> None:
        """SIGTERM the selected monitor's PID, then refresh.

        Two states:

        - **alive row** → SIGTERM the process group (own session, so
          pid==pgid). Sidecar entry stays until the next refresh
          tick observes ``alive=False`` and auto-drops it.
        - **dead row** → drop the stale sidecar entry directly. Lets
          the operator clean up old rows without restarting the panel.
        """
        if not self._rows or self._listview is None:
            return
        idx = self._listview.index or 0
        if not (0 <= idx < len(self._rows)):
            return
        row = self._rows[idx]
        pid = row.get("pid")
        if not isinstance(pid, int) or pid <= 0:
            return
        if not row.get("alive"):
            self._drop_dead_entry(row.get("monitor_id"))
            self._refresh()
            self._log_panel_event(
                "MONITOR_PANEL_DROP",
                monitor_id=row.get("monitor_id"),
                pid=pid,
            )
            return
        import os as _os
        import signal as _signal
        try:
            _os.killpg(pid, _signal.SIGTERM)
            self._log_panel_event(
                "MONITOR_PANEL_KILL",
                monitor_id=row.get("monitor_id"),
                pid=pid,
                signal="SIGTERM",
                ok=True,
            )
        except (ProcessLookupError, PermissionError) as e:
            self._log_panel_event(
                "MONITOR_PANEL_KILL",
                monitor_id=row.get("monitor_id"),
                pid=pid,
                ok=False,
                error=str(e),
            )
        # Next refresh tick re-checks liveness via os.kill — the row
        # flips to "exited" automatically; the operator can press 'x'
        # again to drop the stale entry from the sidecar.
        self._refresh()

    def _log_panel_event(self, event: str, **fields: Any) -> None:
        """Append a structured event line to the agent's gateway.log.

        The TUI process doesn't inherit ``RTXCLAW_AGENT_HOME``, so
        ``rtxclaw_core.tools._log.log_event`` would silently no-op.
        We compute the agent log path from the panel's known
        ``sessions_dir`` (``<home>/sessions``) instead — the agent
        home is the parent.
        """
        from datetime import datetime as _dt
        agent_home = self._sessions_dir.parent
        log_path = agent_home / "logs" / "gateway.log"
        ts = _dt.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
        parts = [ts, event]
        for k, v in fields.items():
            try:
                rendered = json.dumps(v, ensure_ascii=False, default=str)
            except (TypeError, ValueError):
                rendered = json.dumps(repr(v))
            parts.append(f"{k}={rendered}")
        try:
            log_path.parent.mkdir(parents=True, exist_ok=True)
            with log_path.open("a", encoding="utf-8") as f:
                f.write(" ".join(parts) + "\n")
        except OSError:
            pass

    def _drop_dead_entry(self, monitor_id: Optional[str]) -> None:
        if not monitor_id:
            return
        path = self._sessions_dir / f"{self._session_id}.monitors.json"
        if not path.exists():
            return
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return
        if not isinstance(data, list):
            return
        keep = [e for e in data if e.get("monitor_id") != monitor_id]
        try:
            path.write_text(
                json.dumps(keep, indent=2, ensure_ascii=False) + "\n",
                encoding="utf-8",
            )
        except OSError:
            pass

    def action_cancel(self) -> None:
        if self._timer is not None:
            try:
                self._timer.stop()
            except Exception:  # noqa: BLE001
                pass
        self.dismiss(None)


class SessionPickerModal(ModalScreen[Optional[str]]):
    """Modal session picker invoked by `/sessions` (no args).

    Shows each session as a `ListItem` with:

        ● 1.  69ef481f1234  · 5 min ago   · 12 turns  · tui:/home/me/proj
              how to continue on the previous session?

    Up / Down navigate, Enter selects, Esc cancels. The currently
    active session is pre-highlighted with a `●` marker and pre-
    selected on open so a single Enter is a no-op.

    Returns the selected session's hash on success, `None` on cancel.
    """

    CSS = """
    SessionPickerModal {
        align: center middle;
    }
    #picker-box {
        width: 90%;
        max-width: 140;
        height: 80%;
        max-height: 40;
        border: thick $accent;
        background: $panel;
        padding: 1 2;
    }
    #picker-title {
        text-style: bold;
        color: $accent;
        margin-bottom: 1;
    }
    #picker-list {
        height: 1fr;
        border: round $accent 30%;
        background: $boost;
    }
    #picker-list > ListItem {
        padding: 0 1;
        height: 1;
    }
    #picker-list > ListItem.--highlight {
        background: $accent 30%;
    }
    #picker-list > ListItem.current {
        color: $success;
        text-style: bold;
    }
    #picker-list > ListItem.heartbeat {
        /* Dim heartbeat sessions a notch — still visible, but they
           don't fight for attention against interactive ones. */
        color: $text-muted;
    }
    #picker-help {
        color: $text-muted;
        margin-top: 1;
    }
    """

    BINDINGS = [
        Binding("escape", "cancel", "Cancel", show=True),
        Binding("enter", "pick", "Select", show=True),
    ]

    def __init__(
        self, sessions: list[dict], current_sid: str = "",
    ) -> None:
        super().__init__()
        self._sessions = sessions
        self._current_sid = current_sid

    def compose(self) -> ComposeResult:
        with Vertical(id="picker-box"):
            yield Label(
                f"📁  Sessions ({len(self._sessions)})  ·  "
                "↑/↓ navigate  ·  Enter select  ·  Esc cancel",
                id="picker-title",
            )
            items: list[ListItem] = []
            initial = 0
            for i, s in enumerate(self._sessions):
                h = s.get("hash") or ""
                short = h[:12]
                marker = "●" if h == self._current_sid else " "
                title = (s.get("title") or "(untitled)").strip()
                origin = s.get("workspace_origin") or "?"
                # Heartbeat sessions get a 💓 badge so they're visually
                # distinct from interactive sessions in the picker.
                # They still appear in the list — the user can switch
                # to one to inspect heartbeat history — they just don't
                # hide in plain sight.
                badge = "💓" if origin == "heartbeat" else "  "
                cwd = s.get("workspace_cwd") or "?"
                turns = s.get("turns") or 0
                age = _humanize_age(s.get("last_activity") or "")
                # Single-line list item so ~10–20 sessions fit on
                # screen at once. Title is appended to the metadata
                # row and clipped by the row's `height: 1` so long
                # titles can't push the layout open.
                row = (
                    f"{marker} {i + 1:>2}. {badge} {short}  ·  {age:<12}"
                    f"·  {turns:>3} turns  ·  {origin}:{cwd}  ·  {title}"
                )
                item = ListItem(Static(row, markup=False))
                if origin == "heartbeat":
                    item.add_class("heartbeat")
                if h == self._current_sid:
                    item.add_class("current")
                    initial = i
                items.append(item)
            self._listview = ListView(*items, id="picker-list", initial_index=initial)
            yield self._listview
            yield Label(
                "Tip: `/sessions <index|hash-prefix>` switches without the picker.",
                id="picker-help",
            )

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        # Enter on a row OR a mouse click — both fire `Selected`.
        idx = self._listview.index or 0
        if 0 <= idx < len(self._sessions):
            self.dismiss(self._sessions[idx].get("hash"))
        else:
            self.dismiss(None)

    def action_pick(self) -> None:
        idx = self._listview.index or 0
        if 0 <= idx < len(self._sessions):
            self.dismiss(self._sessions[idx].get("hash"))
        else:
            self.dismiss(None)

    def action_cancel(self) -> None:
        self.dismiss(None)


class ModelPickerModal(ModalScreen[Optional[dict]]):
    """Modal model picker invoked by `/model` or `/models` (no args).

    Shows each configured model as a `ListItem` with:

        ● 1.  gpu-a         qwen3.6-27b-fp8    ctx=256k  ·  http://gpu-a:8001/v1

    Up / Down navigate, Enter selects, Esc cancels. The currently
    active model is pre-highlighted with a `●` marker.

    Returns the selected model row dict on success, `None` on cancel.
    """

    CSS = """
    ModelPickerModal {
        align: center middle;
    }
    #picker-box {
        width: 90%;
        max-width: 150;
        height: 80%;
        max-height: 30;
        border: thick $accent;
        background: $panel;
        padding: 1 2;
    }
    #picker-title {
        text-style: bold;
        color: $accent;
        margin-bottom: 1;
    }
    #picker-list {
        height: 1fr;
        border: round $accent 30%;
        background: $boost;
    }
    #picker-list > ListItem {
        padding: 0 1;
        height: 1;
    }
    #picker-list > ListItem.--highlight {
        background: $accent 30%;
    }
    #picker-list > ListItem.current {
        color: $success;
        text-style: bold;
    }
    #picker-help {
        color: $text-muted;
        margin-top: 1;
    }
    """

    BINDINGS = [
        Binding("escape", "cancel", "Cancel", show=True),
        Binding("enter", "pick", "Select", show=True),
    ]

    def __init__(
        self, models: list[dict], current_url: str = "",
        *, current_alias: str = "",
    ) -> None:
        super().__init__()
        self._models = models
        self._current_url = (current_url or "").rstrip("/")
        # Alias-based "current" matching for engines whose rows have no
        # baseUrl (e.g. ``gemini_cli`` — the engine owns its own HTTP
        # transport, so there's no URL to compare). Falls back to
        # URL-based matching when this is empty.
        self._current_alias = (current_alias or "").strip()

    def compose(self) -> ComposeResult:
        with Vertical(id="picker-box"):
            yield Label(
                f"🧠  Models ({len(self._models)})  ·  "
                "↑/↓ navigate  ·  Enter select  ·  Esc cancel",
                id="picker-title",
            )
            items: list[ListItem] = []
            initial = 0
            for i, m in enumerate(self._models):
                alias = m.get("alias") or "?"
                # Auto-discover via /v1/models was removed — empty
                # `id` is now a config error. Render "(missing id)"
                # in the picker so the operator notices and edits
                # ~/.rtxclaw/config.json before trying to switch.
                raw_model_id = m.get("id") or ""
                model_id = raw_model_id or "(missing id)"
                model_col = (
                    "" if raw_model_id and raw_model_id == alias else model_id
                )
                url = (m.get("baseUrl") or "").rstrip("/")
                ctx = m.get("contextWindow") or 0
                backend = m.get("backend") or ""
                # Match either by URL (local-LLM, openrouter, …) OR by
                # alias (gemini-cli, claude-cli — no upstream URL).
                is_current = (
                    (bool(url) and url == self._current_url)
                    or (bool(self._current_alias) and alias == self._current_alias)
                )
                marker = "●" if is_current else " "
                ctx_label = f"{ctx // 1024}k" if ctx else "?"
                backend_label = f" ({backend})" if backend else ""
                # gemini-cli rows have no upstream URL; render the
                # human-readable description in its place so the
                # picker isn't all blank tails.
                tail = url or str(m.get("description") or "")
                row = (
                    f"{marker} {i + 1:>2}.  {alias:<12}"
                    f"{model_col:<30}"
                    f"ctx={ctx_label:<6}"
                    f"{backend_label}  ·  {tail}"
                )
                item = ListItem(Static(row, markup=False))
                if is_current:
                    item.add_class("current")
                    initial = i
                items.append(item)
            self._listview = ListView(*items, id="picker-list", initial_index=initial)
            yield self._listview
            yield Label(
                "Tip: `/model <alias>` switches without the picker.",
                id="picker-help",
            )

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        idx = self._listview.index or 0
        if 0 <= idx < len(self._models):
            self.dismiss(dict(self._models[idx]))
        else:
            self.dismiss(None)

    def action_pick(self) -> None:
        idx = self._listview.index or 0
        if 0 <= idx < len(self._models):
            self.dismiss(dict(self._models[idx]))
        else:
            self.dismiss(None)

    def action_cancel(self) -> None:
        self.dismiss(None)


class CommandHistory:
    """Persisted command history for the chat input.

    Stores a fixed-size list of previously submitted commands in
    ``~/.rtxclaw/command_history.json`` (one JSON array of strings).
    Thread-safe for single-process use (the TUI is single-threaded
    under Textual's event loop anyway).
    """

    MAX_ENTRIES = 256

    def __init__(self, path: Path | None = None) -> None:
        if path is None:
            path = Path.home() / ".rtxclaw" / "command_history.json"
        self.path = path
        self.entries: list[str] = []
        self._load()

    def _load(self) -> None:
        try:
            if self.path.exists():
                raw = self.path.read_text(encoding="utf-8").strip()
                if raw:
                    self.entries = json.loads(raw)
        except (json.JSONDecodeError, OSError):
            self.entries = []

    def _save(self) -> None:
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.path.write_text(
                json.dumps(self.entries, ensure_ascii=False) + "\n",
                encoding="utf-8",
            )
        except OSError:
            pass

    def add(self, text: str) -> None:
        """Append a command. Deduplicates against the most recent entry."""
        text = text.strip()
        if not text:
            return
        if self.entries and self.entries[-1] == text:
            return  # skip exact duplicate at top
        self.entries.append(text)
        if len(self.entries) > self.MAX_ENTRIES:
            self.entries = self.entries[-self.MAX_ENTRIES:]
        self._save()

    def navigate(self, index: int) -> str | None:
        """Return the command at *index* (0 = most recent), or None."""
        if not self.entries:
            return None
        # index 0 → most recent (end of list), index N → oldest
        pos = len(self.entries) - 1 - index
        if 0 <= pos < len(self.entries):
            return self.entries[pos]
        return None


# Slash commands the autocomplete popup offers. Each entry is
# ``(token, signature, description)``; the token is the prefix the
# user can match against (no args), the signature is what the popup
# renders (``/model <alias|url>``), and the description is the
# one-line hint. Order is operator-ergonomic: most-common first,
# delegate sugars at the bottom.
SLASH_COMMAND_HELP: list[tuple[str, str, str]] = [
    ("/help",      "/help",                       "show the quick reference card"),
    ("/new",       "/new",                        "abort + clear transcript + start a new session"),
    ("/abort",     "/abort",                      "kill the current generation (same as ESC)"),
    ("/restart",   "/restart",                    "restart the gateway daemon (detached)"),
    ("/agents",    "/agents",                     "list configured rtxclaw agents (with current marked)"),
    ("/agent",     "/agent <name>",               "switch this TUI to a different agent (fresh session)"),
    ("/sessions",  "/sessions [i|hash]",          "list saved sessions / switch by index or prefix"),
    ("/models",    "/models",                     "list configured models (interactive picker)"),
    ("/model",     "/model <alias|url>",          "switch the live session's model/upstream"),
    ("/mode",      "/mode <plan|ask|auto>",       "cycle the permission mode"),
    ("/status",    "/status",                     "show agent + endpoint + backend snapshot"),
    ("/history",   "/history",                    "dump the current session's transcript"),
    ("/refresh",   "/refresh",                    "pull turns appended by other frontends"),
    ("/compact",   "/compact",                    "squeeze oversized tool results in the saved session"),
    ("/tools",     "/tools [on|off]",             "toggle inline 🔧 tool-call header (default off)"),
    ("/thinking",  "/thinking [on|off]",          "show/hide thinking tokens"),
    ("/reasoning", "/reasoning [on|off|stream]",  "stream / hide / show thinking tokens"),
    ("/on",        "/on",                         "shortcut for /reasoning on"),
    ("/off",       "/off",                        "shortcut for /reasoning off"),
    ("/stream",    "/stream",                     "shortcut for /reasoning stream"),
    ("/mouse",     "/mouse",                      "toggle mouse tracking (text selection vs clickable UI)"),
    ("/todo",      "/todo",                       "show this session's todo checklist"),
    ("/subagents", "/subagents [N]",              "list subagents this session has spawned (delegate_agent / claude / codex). Pass N (1-based) to enter that subagent's session."),
    ("/monitors",  "/monitors",                   "live monitor panel — navigate / kill background shells (alias: /shells; binding: Ctrl+S)"),
    ("/shells",    "/shells",                     "alias for /monitors — same modal, more findable name"),
    ("/claude",    "/claude <prompt>",            "bridge the prompt to Claude Code"),
    ("/codex",     "/codex <prompt>",             "bridge the prompt to OpenAI's Codex CLI"),
    ("/gemini",    "/gemini <prompt>",            "bridge the prompt to Google Gemini CLI"),
    ("/plugin",    "/plugin <subcmd>",            "manage plugins: list / search / install / enable / disable / remove"),
    ("/mcp",       "/mcp [filter]",               "list MCP servers (Claude Code-compatible) — name, transport, source"),
    ("/skills",    "/skills [name]",              "list skills (or open one by name) — same store the agent loads from"),
    ("/commands",  "/commands",                   "list file-based slash commands (`commands/*.md`)"),
    ("/context",   "/context [N]",                "show what's filling the context window (token map per round)"),
]


def file_command_rows() -> list[tuple[str, str, str]]:
    """File-based slash commands (``commands/*.md``) as popup rows.

    Bridges ``rtxclaw_core.file_commands.discover_commands()`` into
    the same ``(token, signature, description)`` shape the popup
    renders for built-ins. Includes the operator's
    ``~/.rtxclaw/commands/``, ``~/.claude/commands/``, installed
    plugin commands, AND the package's bundled
    ``builtin_commands/`` (where ``/goal`` ships) — so every
    file-defined command is discoverable from the popup, not just
    the ones the TUI has hardcoded knowledge of.

    Fail-soft: any import / discovery error returns an empty list
    so a broken commands dir can't take down the chat input.
    """
    try:
        from rtxclaw_core.file_commands import discover_commands
        cmds = discover_commands()
    except Exception:  # noqa: BLE001
        return []
    rows: list[tuple[str, str, str]] = []
    for c in cmds:
        token = f"/{c.name}"
        hint = c.argument_hint.strip()
        sig = f"{token} {hint}" if hint else token
        rows.append((token, sig, c.short_description))
    return rows


def merge_slash_command_rows(
    builtin: list[tuple[str, str, str]],
    file_based: list[tuple[str, str, str]],
) -> list[tuple[str, str, str]]:
    """Combine the hardcoded popup table with file-command rows,
    dropping any file row whose token collides with a hardcoded
    built-in.

    Built-ins win on collision because dispatch in
    ``on_input_submitted`` runs built-in handlers FIRST and only
    unrecognised slashes fall through to file commands — so an
    operator's ``commands/help.md`` would never actually fire,
    listing it in the popup would just be misleading.
    """
    builtin_tokens = {row[0].lower() for row in builtin}
    extras = [r for r in file_based if r[0].lower() not in builtin_tokens]
    return list(builtin) + extras


def _longest_common_prefix(strings: list[str]) -> str:
    """Return the longest common prefix of all strings, or '' if the
    list is empty. Used by Tab-completion when multiple commands
    match the current partial — we fill in as many shared chars as
    we can, then leave the rest to the user."""
    if not strings:
        return ""
    base = strings[0]
    for s in strings[1:]:
        n = min(len(base), len(s))
        i = 0
        while i < n and base[i] == s[i]:
            i += 1
        base = base[:i]
        if not base:
            break
    return base


class MessageInput(TextArea):
    """Multi-line composition box for the chat input.

    Wraps long messages instead of scrolling horizontally, so a paste
    or a long thought stays readable. Two key bindings make it feel
    like an `Input` for the common case:

    - ``Enter``         — submit the message (single-line behaviour
                          the rest of the app expects).
    - ``Shift+Enter``   — insert a newline; lets the user compose
                          multi-line prompts naturally.
    - ``Up`` / ``Down`` — cycle through command history (like bash).

    Submission is signalled by posting an ``Input.Submitted`` message
    (same event class ``Input`` would post), so ``on_input_submitted``
    handlers stay unchanged. ``value`` proxies to ``self.text``, also
    matching ``Input``'s API — including the ``event.input.value = ""``
    clear pattern in the existing handler.
    """

    BINDINGS = [
        # Three submit/newline bindings to handle every terminal:
        #   - `enter` submits (with kitty disambiguation, this is ONLY
        #     plain Enter — shift+enter / ctrl+enter / ctrl+j produce
        #     distinct key events that don't match this binding).
        #   - `shift+enter` inserts a newline. Requires the terminal to
        #     speak the kitty keyboard protocol (kitty, foot, ghostty,
        #     recent Konsole/WezTerm). `_enable_kitty_keyboard_enhancements`
        #     pushes flags 1+2+4+8 so the modifier survives.
        #   - `ctrl+j` is the cross-terminal fallback. Ctrl+J is literal
        #     LF (ASCII 10) — every terminal sends it as a distinct
        #     keystroke from Enter (which is CR / ASCII 13), so this
        #     works in plain xterm / gnome-terminal / Alacritty without
        #     needing any protocol support.
        Binding("enter", "submit", "Send", show=False, priority=True),
        Binding("shift+enter", "insert_newline", "New line", show=False),
        Binding("ctrl+j", "insert_newline", "New line", show=False),
        Binding("up", "history_prev", "History ↑", show=False),
        Binding("down", "history_next", "History ↓", show=False),
        # Tab completes the slash command. ``priority=True`` so it
        # wins over TextArea's default ``tab`` (which inserts a tab
        # character) — typing a real tab in chat is rare, completing
        # a half-typed ``/sess`` is common.
        Binding("tab", "complete_slash", "Complete", show=False, priority=True),
    ]

    def __init__(self, placeholder: str = "", **kwargs) -> None:
        super().__init__(
            language=None,
            show_line_numbers=False,
            soft_wrap=True,
            placeholder=placeholder,
            **kwargs,
        )
        self._history = CommandHistory()
        # Index into history during navigation: -1 = typing freely (not
        # in history), 0 = most recent, N = older entries.
        self._history_index: int = -1
        # Text the user was typing *before* they pressed Up. Restored
        # when Down cycles past the oldest entry back to free typing.
        self._draft_text: str = ""

    @property
    def value(self) -> str:
        return self.text

    @value.setter
    def value(self, text: str) -> None:
        # Compatible with `event.input.value = ""` in `on_input_submitted`.
        self.text = text

    def action_submit(self) -> None:
        text = self.value.strip()
        if text:
            self._history.add(text)
        # Reset history navigation state on submit.
        self._history_index = -1
        self._draft_text = ""
        self.post_message(Input.Submitted(self, self.value))

    def action_insert_newline(self) -> None:
        self.insert("\n")

    # ---- slash-command autocomplete ----------------------------------

    def _slash_partial(self) -> Optional[str]:
        """Return the leading ``/<word>`` token of the input if the
        composition is exactly a single slash command (no space after,
        no second line). Otherwise ``None`` — the popup stays empty
        and Tab falls through to its TextArea default.

        Why "no space after"? Once the user's typed past the command
        name (``/model `` or ``/sessions <hash>``) the args are
        free-form and the popup would be more in the way than helpful.
        """
        text = self.text
        if not text.startswith("/"):
            return None
        # Suppress popup the moment the user starts typing args or
        # composes multi-line — neither needs command completion.
        if " " in text or "\n" in text:
            return None
        return text

    def _matching_slash_commands(self, partial: str) -> list[tuple[str, str, str]]:
        """All commands whose token starts with ``partial`` (case-fold).

        Returns the full ``(token, signature, description)`` rows so
        callers can render BOTH the signature and the description,
        and so Tab completion has the canonical token to fill in.

        Combines the hardcoded ``SLASH_COMMAND_HELP`` (built-in TUI
        handlers like ``/help``, ``/plugin``, ``/skills``) with the
        live ``discover_commands()`` listing for file-based commands
        like ``/goal``. Hardcoded built-ins win on token collision so
        an operator's ``commands/help.md`` can't accidentally shadow
        the TUI's own ``/help`` handler — matches the dispatch order
        in ``on_input_submitted`` where built-in handlers run first
        and only unrecognised slashes fall through to file commands.
        """
        all_rows = merge_slash_command_rows(
            SLASH_COMMAND_HELP, file_command_rows()
        )
        if not partial:
            return all_rows
        p = partial.lower()
        return [row for row in all_rows if row[0].lower().startswith(p)]

    def _refresh_slash_popup(self) -> None:
        """Repaint ``#slash-popup`` based on the current input value.

        Called from the TextArea ``Changed`` event hook on the parent
        app. Hidden (empty Static content) when the input doesn't
        start with a slash, or has already moved past the command
        name. Capped at 8 rows so a cursor on ``/`` (which matches
        every command) doesn't push the transcript off-screen.
        """
        try:
            popup = self.app.query_one("#slash-popup", Static)
        except Exception:  # noqa: BLE001
            return
        partial = self._slash_partial()
        if partial is None:
            popup.update("")
            return
        rows = self._matching_slash_commands(partial)
        if not rows:
            popup.update(
                f"[dim]no slash command matches {partial!r}[/dim]"
            )
            return
        # Render up to 8 rows so a long match list doesn't squash the
        # transcript. Each row: ``  <signature>      <description>``.
        # Highlight the exact-prefix-match column with bold so the
        # operator can scan the column quickly.
        sig_w = max(len(sig) for _, sig, _ in rows[:8])
        sig_w = min(sig_w, 30)  # cap absurdly long signatures
        lines: list[str] = []
        for token, sig, desc in rows[:8]:
            sig_padded = sig.ljust(sig_w)
            lines.append(f"  [bold cyan]{sig_padded}[/bold cyan]  [dim]{desc}[/dim]")
        if len(rows) > 8:
            lines.append(
                f"  [dim italic](+{len(rows) - 8} more — keep typing to narrow)[/dim italic]"
            )
        popup.update("\n".join(lines))

    def action_complete_slash(self) -> None:
        """Tab handler. Completes the current slash partial.

        - 0 matches: no-op (Tab does nothing).
        - 1 match: fill the input to the full command, leave a trailing
          space if the command takes args (``/model``, ``/sessions``,
          ``/claude``), else leave bare.
        - 2+ matches: extend to the longest common prefix of the
          matching tokens. The popup keeps showing the remaining
          options.

        When NO slash partial is active, fall through to inserting a
        literal tab — preserves the historical behaviour for users who
        actually want a tab character in their prompt.
        """
        partial = self._slash_partial()
        if partial is None:
            self.insert("\t")
            return
        rows = self._matching_slash_commands(partial)
        if not rows:
            return
        if len(rows) == 1:
            token, sig, _ = rows[0]
            takes_args = "<" in sig or "[" in sig
            self.text = token + (" " if takes_args else "")
            self.cursor_location = (0, len(self.text))
            self._refresh_slash_popup()
            return
        # Multi-match: extend to the LCP of the candidate tokens.
        lcp = _longest_common_prefix([r[0] for r in rows])
        if len(lcp) > len(partial):
            self.text = lcp
            self.cursor_location = (0, len(self.text))
            self._refresh_slash_popup()

    def action_history_prev(self) -> None:
        """Move back one entry in command history (Up arrow)."""
        if not self._history.entries:
            return
        # First press: save current text as draft so Down can restore it.
        if self._history_index == -1:
            self._draft_text = self.text
        # Clamp to available entries.
        self._history_index = min(self._history_index + 1, len(self._history.entries) - 1)
        entry = self._history.navigate(self._history_index)
        if entry is not None:
            self.text = entry

    def action_history_next(self) -> None:
        """Move forward one entry in command history (Down arrow)."""
        if self._history_index <= 0:
            # Past the top → restore draft and go back to free typing.
            if self._history_index == 0:
                self.text = self._draft_text
            self._history_index = -1
            return
        self._history_index -= 1
        entry = self._history.navigate(self._history_index)
        if entry is not None:
            self.text = entry

    # Min/max visual rows the input widget grows between. `MIN_ROWS` is
    # what the user sees before typing anything (so the box isn't a
    # one-line sliver). `MAX_ROWS` is the cap before internal scrolling
    # kicks in — high enough that long pastes / multi-paragraph prompts
    # stay fully visible on a normal-height terminal.
    MIN_ROWS = 3
    MAX_ROWS = 20

    def _autosize(self) -> None:
        """Resize the input box to fit its wrapped content.

        Textual's `height: auto` on a `TextArea` (a `ScrollView` subclass)
        doesn't expand with content — the widget stays at `min-height` and
        the cursor scrolls inside the fixed viewport, making typed text
        appear to "disappear" past row 2/3. We compute the wrapped-line
        count directly from `wrapped_document.height` and pin the widget's
        visual height so the cursor always stays in view.
        """
        try:
            lines = max(1, int(self.wrapped_document.height))
        except Exception:  # noqa: BLE001
            return
        target = max(self.MIN_ROWS, min(self.MAX_ROWS, lines))
        # Setting an int sets cells. Cheap when unchanged — Textual no-ops
        # if the new value matches the current scalar.
        self.styles.height = target

    def on_mount(self) -> None:
        # Ensure the initial size honors `MIN_ROWS` even before any edit.
        self._autosize()

    def on_text_area_changed(self, _event: "TextArea.Changed") -> None:
        # Fired on every edit (including programmatic `self.text = …` via
        # history navigation, so resize tracks history-restored prompts).
        self._autosize()
        # Repaint the slash-command autocomplete panel. Cheap (one
        # ``query_one`` + a Static.update with a precomputed string),
        # so running it on every keystroke is fine.
        self._refresh_slash_popup()


class ChatApp(App):
    CSS = """
    Screen { layout: vertical; }
    #transcript {
        background: $surface;
        padding: 1 2;
        height: 1fr;
    }
    .user-msg {
        background: $primary 20%;
        color: $text;
        padding: 0 1;
        margin: 1 0 0 0;
        border-left: thick $primary;
    }
    .assist-msg {
        margin: 1 0 0 0;
        height: auto;
    }
    .assist-content {
        padding: 0 1;
        height: auto;
    }
    /* Prefill (time-to-first-token) breadcrumb that ticks live above the
       thinking box until the first delta lands. Single-line, no border,
       no background — it's a quiet status line, not a panel. */
    .assist-prefill {
        height: 1;
        padding: 0 1;
        margin: 0;
    }
    /* Per-model-call stats line stamped under each AssistantMessage's
       content (model · ttft · gen tps · ctx · wt · …). Dim, single-line,
       no border so it reads as a quiet footnote — one row per round so
       multi-tool turns surface stats for every model call. */
    .assist-metrics {
        height: auto;
        padding: 0 1;
        margin: 0;
    }
    /* One-line dim badge mounted above the content of a delegated
       turn (Claude / Codex). Styled to read as a footnote — same
       low-contrast vibe as the metrics row — so the transcript still
       feels like a sequence of native rtxclaw turns. */
    .delegate-badge {
        height: 1;
        padding: 0 1;
        margin: 0;
        color: $text-muted;
    }
    .thinking {
        background: $boost;
        margin: 0 0 1 0;
    }
    .thinking-body {
        color: $text-muted;
        padding: 0 1;
    }
    .tool-call {
        background: $boost;
        color: $accent;
        padding: 0 1;
        margin: 1 0 0 0;
        border-left: thick $accent;
    }
    .claude-msg {
        background: $surface;
        color: $text;
        padding: 1 1;
        margin: 1 0;
        border-left: thick $secondary;
    }
    /* `.tool-result` is a Collapsible (subclass), styled like the
       reasoning Collapsible so the two read as siblings — same visual
       treatment, same expand/collapse affordance, just a different hint
       (Ctrl+T vs Ctrl+R). Minimal here so Textual's Collapsible chrome
       (▶/▼ arrow, header bar) renders naturally. */
    .tool-result {
        background: $boost;
        margin: 0 0 1 0;
    }
    .tool-result-body {
        color: $text-muted;
        padding: 0 1;
    }
    /* `.plan-msg` shows the ExitPlanMode body inline so the operator
       can read the plan and decide whether to leave plan mode. Green
       border-left distinguishes it from the surrounding tool widgets;
       never collapsed — the whole point is that it stays readable. */
    .plan-msg {
        background: $boost;
        margin: 1 0;
        border-left: thick $success;
        height: auto;
    }
    .plan-msg-header {
        color: $success;
        text-style: bold;
        padding: 0 1;
    }
    .plan-msg-body {
        color: $text;
        padding: 0 1 1 1;
    }
    /* `.section-msg` renders one OutputSection call's content inline as
       the model's actual answer body. Cyan/secondary border so it reads
       as model output (not a tool result, not a plan); never collapsed
       — operators want to see each section as it lands, just like a
       streamed AssistantMessage. */
    .section-msg {
        background: $surface;
        margin: 1 0;
        border-left: thick $secondary;
        height: auto;
    }
    .section-msg-header {
        color: $secondary;
        text-style: bold;
        padding: 0 1;
    }
    .section-msg-body {
        color: $text;
        padding: 0 1 1 1;
    }
    /* `.update-msg` renders an `Update`/`Edit` tool call as a colored
       code-diff card — Claude Code's "Update" treatment. Green
       border-left for a normal edit; `.update-msg-failed` flips the
       card to the error palette when the tool reports failure. Never
       collapsed — the diff IS the point. TUI-only: Telegram renders
       file edits as a plain `🔧 Update…` header with no diff body. */
    .update-msg {
        background: $boost;
        margin: 1 0;
        border-left: thick $success;
        height: auto;
    }
    .update-msg-failed {
        border-left: thick $error;
    }
    .update-msg-header {
        color: $success;
        text-style: bold;
        padding: 0 1;
    }
    .update-msg-failed .update-msg-header {
        color: $error;
    }
    .update-msg-body {
        padding: 0 1 1 1;
    }
    /* `.harness-task-msg` renders the harness ``Task*`` tool family
       (TaskCreate / TaskUpdate / TaskList / TaskGet / TaskOutput /
       TaskStop) as a single inline card that updates in place. Blue
       border-left to distinguish it from the TodoWrite plan (no
       border on plan-checklist footer) and from the cyan section /
       green plan / green update cards. Never collapsed — the card IS
       the task list view. */
    .harness-task-msg {
        background: $boost;
        margin: 1 0;
        border-left: thick $primary;
        height: auto;
    }
    .harness-task-header {
        color: $primary;
        text-style: bold;
        padding: 0 1;
    }
    .harness-task-body {
        color: $text;
        padding: 0 1 1 1;
    }
    /* `.subagent-box` frames one subagent run (delegate_claude /
       delegate_codex / delegate_gemini / delegate_agent). Thick yellow
       border-left so the operator can spot the run boundary at a
       glance; the subagent's AssistantMessage + every inner tool
       widget mounts inside `.subagent-box-body`. Header flips to
       green ✅ / red ❌ on finalize. */
    .subagent-box {
        background: $surface;
        margin: 1 0;
        border-left: thick $warning;
        padding: 0 0 0 1;
        height: auto;
    }
    /* Operator-focused subagent (via ``alt+up`` / ``alt+down``) gets
       a brighter border so the navigation cursor is easy to spot.
       Bumps the background slightly too so even a deeply-nested
       sequence of subagents reads as "this one is the current pick." */
    .subagent-box-focused {
        background: $boost;
        border-left: thick $accent;
    }
    .subagent-box-header {
        color: $warning;
        text-style: bold;
        padding: 0 1;
        height: auto;
    }
    .subagent-box-body {
        padding: 0 0 0 0;
        height: auto;
    }
    /* `.compaction-notice` highlights when the runtime trimmed the
       upstream prompt mid-turn. Yellow border so it stands out from the
       standard tool-result Collapsible — easy to spot in a long
       transcript when scrolling back to debug a "why didn't the model
       see X?" answer. */
    .compaction-notice {
        background: $warning 15%;
        margin: 1 0;
        border-left: thick $warning;
    }
    .compaction-notice-body {
        color: $text;
        padding: 0 1;
    }
    /* `.empty-eos-notice` flags a premature-EOS recovery: the upstream
       model emitted finish_reason=stop with empty output on a tool
       followup round (Qwen3-fp8 multi-turn EOS bug) and the agent
       auto-injected a "continue" nudge. Same yellow-warning palette as
       the compaction notice so the two read as a family. */
    .empty-eos-notice {
        background: $warning 15%;
        color: $warning;
        margin: 1 0;
        padding: 0 1;
        border-left: thick $warning;
    }
    /* `.runtime-warning-notice` surfaces a runtime intervention
       (loop detected, distill recovery, force-terminate, premature-end
       nudge) that the bridge used to drop into the assistant message
       bubble as plain text — invisible to anyone not scanning carefully.
       Two variants: `.hard` (loop-hit, force-terminate) in red so it
       reads as an emergency; `.soft` (distill, nudge) in blue so it
       reads as "the runtime is handling this." Thick left border + full
       width so both stand out clearly in the transcript scrollback. */
    .runtime-warning-notice {
        margin: 1 0;
        padding: 0 1;
    }
    .runtime-warning-notice.hard {
        background: $error 15%;
        color: $error;
        border-left: thick $error;
    }
    .runtime-warning-notice.soft {
        background: $accent 15%;
        color: $accent;
        border-left: thick $accent;
    }
    #slash-popup {
        /* Slash-command autocomplete panel pinned just above the
           input row. ``height: auto`` so empty content collapses
           the row entirely and the input sits flush against the
           transcript when no completion is active. Each visible
           row is one matching command + description. */
        height: auto;
        padding: 0 1;
        background: $boost 30%;
        color: $text-muted;
    }
    #status-events {
        /* Transient-event line above the footer. Hosts one-shot
           messages (session created, /restart scheduled, command
           failed, ``ESC to cancel`` hints, etc.) without polluting
           the persistent identity-and-state footer. ``height: auto``
           so long messages wrap onto a second row on narrow terminals
           rather than getting clipped. */
        height: auto;
        padding: 0 1;
        color: $text-muted;
    }
    #status-footer {
        /* Single consolidated footer: state · agent · mode · ctx · model ·
           upstream-status. ``height: auto`` so the footer word-wraps on
           narrow terminals — the operator gets to see every segment
           instead of having the right-hand side (upstream status,
           warnings) clipped off the edge. */
        height: auto;
        padding: 0 1;
        background: $primary 25%;
        color: $text;
    }
    MessageInput {
        /* `height` is driven dynamically by `MessageInput._autosize`
           (clamped to MIN_ROWS..MAX_ROWS based on wrapped line count) —
           Textual's `height: auto` on TextArea does NOT grow with content.
           The fixed default here just sets the initial render before the
           on_mount autosize runs. */
        height: 3;
        width: 1fr;
        border: none;
        background: $boost;
        padding: 0 1;
    }
    MessageInput.-focus {
        border: none;
    }
    /* Pending-turn queue rendered above the input. `display: none` keeps
       it out of the layout while empty; `_refresh_queue_display` flips
       it on whenever `_turn_queue` is non-empty. */
    #queue {
        display: none;
        height: auto;
        max-height: 6;
        background: $surface;
        border-left: thick $warning;
        padding: 0;
        margin: 0;
    }
    #queue > ListItem {
        padding: 0 1;
        height: 1;
        background: $surface;
        color: $text-muted;
    }
    #queue > ListItem.--highlight {
        background: $warning 30%;
        color: $text;
    }
    /* Shell-style `>` prompt to the left of the input. */
    #input-row {
        height: auto;
        background: $boost;
    }
    #input-prompt {
        width: 2;
        height: auto;
        color: $accent;
        background: $boost;
        padding: 0 0 0 1;
        text-style: bold;
    }
    """

    # ctrl+p is commonly used by tmux / bash readline; remap palette to ctrl+\
    COMMAND_PALETTE_BINDING = "ctrl+backslash"

    # Cap Textual's render rate so SSH sessions don't drown in escape
    # sequences. Local sessions still get 60 FPS (Textual's default);
    # SSH sessions get 20 FPS unless `RTXCLAW_TUI_FPS=<n>` overrides.
    # See `_detect_ssh()` above.
    MAX_FPS = _TUI_FPS

    # Disable mouse tracking by default so the terminal can handle native
    # text selection (shift+drag to copy). With mouse tracking on, the TUI
    # captures all mouse events and the terminal never sees a selection.
    # Collapsibles still work via Ctrl+R / Ctrl+T. Toggle with /mouse.
    mouse_support = False

    BINDINGS = [
        Binding("ctrl+/", "toggle_mouse", "Toggle mouse", show=True, priority=True),
        Binding("escape", "abort", "Abort", show=True, priority=True),
        Binding("ctrl+r", "toggle_thinking", "Toggle reasoning", show=True, priority=True),
        Binding("ctrl+t", "toggle_tool_output", "Toggle tool output", show=True, priority=True),
        Binding("ctrl+s", "open_shells", "Shells", show=True, priority=True),
        Binding("ctrl+c", "request_quit", "Quit", show=True, priority=True),
        Binding("shift+tab", "cycle_mode", "Mode (plan/ask/auto)", show=True, priority=True),
        # Queue navigation. Ctrl+Up/Down hops between input and the
        # pending-prompt queue (the raw Up/Down arrows are taken by
        # command-history scrolling inside ``MessageInput``). Once the
        # queue is focused, Textual ListView handles Up/Down natively,
        # Enter pulls a row back into the input via
        # ``on_list_view_selected``, and the bindings below add
        # delete (drop without re-edit) + shift+up/down (reorder).
        Binding("ctrl+up",    "queue_focus_prev",  "Queue ↑", show=True, priority=True),
        Binding("ctrl+down",  "queue_focus_next",  "Queue ↓", show=True, priority=True),
        # Subagent-box navigation. ``alt+up`` / ``alt+down`` step the
        # focus cursor through every SubagentBoxMessage currently
        # mounted in the transcript (oldest → newest); ``alt+enter``
        # pops a modal that prints the focused subagent's sidecar
        # JSON (prompt + result + elapsed) so the operator can
        # re-read the run without scrolling. Mirrors Claude Code's
        # subagent navigation panel.
        Binding("alt+up",      "subagent_focus_prev", "Subagent ↑", show=True, priority=True),
        Binding("alt+down",    "subagent_focus_next", "Subagent ↓", show=True, priority=True),
        Binding("alt+enter",   "subagent_open",       "Open subagent",   show=True, priority=True),
    ]

    def __init__(
        self,
        *,
        endpoint: str,
        model: str,
        system: str,
        temperature: float = 0.7,
        enable_thinking: bool = True,
    ) -> None:
        super().__init__()
        self.endpoint = endpoint
        self.model = model
        # Inject SOUL/AGENTS/TOOLS/MEMORY from .rtxclaw/ when present.
        self.system_prompt = ctxmod.load_system_prompt(system)
        self.temperature = temperature
        self.enable_thinking = enable_thinking
        self.reasoning_visibility = "on" if enable_thinking else "off"
        # Tool-call header (🔧 toolname {args}) visibility. Default OFF
        # to keep the transcript clean; the collapsed tool-result widget
        # still shows. Toggle live via /tool[s] [on|off].
        self.tool_output_visible: bool = False
        self.session: Optional[Session] = None
        self._proc: Optional[asyncio.subprocess.Process] = None
        self._abort_requested = False
        self._current_assistant: Optional[AssistantMessage] = None
        self._current_user_text = ""
        # Tool-call IDs announced this round but not yet resolved. With
        # parallel tool calls the bridge announces N `tool_call` events
        # back-to-back, then streams N `tool_result` events. We must NOT
        # mount the next-round AssistantMessage between those results
        # (the bug: round-2 chunks then land before remaining tool
        # widgets, so the answer renders ABOVE its tool results). Only
        # ensure a fresh AssistantMessage once this set is empty —
        # i.e., the LAST parallel result has landed.
        self._pending_tool_calls: set[str] = set()
        # ExitPlanMode call_ids whose plan body was rendered as a
        # PlanMessage at tool_call time. The matching tool_result event
        # would otherwise mount a redundant ToolResultMessage carrying
        # the same plan wrapped in "Plan ready — confirm…" boilerplate;
        # tracking ids here lets the tool_result branch skip that mount
        # while still doing pending-set housekeeping.
        self._plan_call_ids: set[str] = set()
        # OutputSection call_ids whose section body was rendered as an
        # OutputSectionMessage at tool_call time. The matching
        # tool_result body is just the "Section X/N saved, next: Y"
        # nudge meant for the model — drop it on success so the
        # transcript reads as a clean run of section bubbles. On
        # FAILURE we still mount the standard ToolResultMessage so the
        # operator sees the validation error.
        self._section_call_ids: set[str] = set()
        # `Update`/`Edit` call_ids whose diff was rendered as an
        # UpdateMessage card at tool_call time (Claude Code's "Update"
        # treatment). The matching tool_result body is just a one-line
        # "updated <path>" summary — drop the redundant Collapsible on
        # success and just stamp the card ✓/✗ via `mark_result`. On
        # FAILURE we still mount the standard ToolResultMessage so the
        # operator sees the error (old_string-not-found, etc.).
        self._update_call_ids: set[str] = set()
        # Reference to the most recent ``TaskUpdateMessage`` card
        # mounted in the transcript. On subsequent TodoWrite tool
        # calls we update this card in-place rather than stacking
        # duplicate plan cards — keeps the transcript clean.
        self._latest_task_update_widget: Optional["TaskUpdateMessage"] = None
        # Persistent harness-task state for the ``Task*`` tool family
        # (TaskCreate / TaskUpdate / TaskList / TaskGet / TaskOutput /
        # TaskStop). Rendered into the ``#harness-tasks`` footer Static
        # (analogous to the ``#plan-checklist`` footer for TodoWrite)
        # so the operator always sees the current task list pinned at
        # the bottom of the TUI — no scrolling back to find the card,
        # no duplicate 🔧 TaskCreate pills cluttering the transcript.
        # ``_harness_tasks`` is id → {"subject", "status"}; ``_harness_tasks_order``
        # preserves insertion order for the footer render.
        self._harness_tasks: dict[str, dict] = {}
        self._harness_tasks_order: list[str] = []
        # call_id → args dict for in-flight ``TaskCreate`` calls. The
        # numeric task id only lands in the matching tool_result body
        # (e.g. ``"Task #4 created successfully: …"``), so we hold the
        # args here and apply them when the result arrives.
        self._pending_task_create_calls: dict[str, dict] = {}
        # call_ids that the live ``tool_call`` branch routed to the
        # harness-task footer. Used by the matching ``tool_result``
        # branch to suppress the redundant ToolResultMessage Collapsible
        # (the footer already shows the row).
        self._harness_task_call_ids: set[str] = set()
        # Operator-driven focus cursor over mounted SubagentBoxMessage
        # widgets. Stepped by ``alt+up`` / ``alt+down`` (see
        # ``_step_subagent_focus``); ``alt+enter`` opens the focused
        # one. -1 means "no subagent currently focused."
        self._subagent_focus_idx: int = -1
        # Subagent counter state — total dispatched / completed since
        # session start. Rendered into the ``#subagent-counter``
        # footer Static. Lets the operator see overall fan-out
        # progress at a glance (the per-box ✅ flip is easy to miss
        # when boxes scroll out of the viewport).
        self._subagent_total: int = 0
        self._subagent_done: int = 0
        self._subagent_failed: int = 0
        # call_ids of INNER subagent tool calls whose widget mount we
        # suppressed (parent transcript stays clean per the
        # subagent-stream-offload rule). The matching tool_result
        # branch checks this set to skip its widget mount AND to bump
        # the SubagentBoxMessage's done-count, then discards.
        self._suppressed_subagent_calls: set[str] = set()
        # Stack of in-flight subagent containers. Each delegate_* tool
        # call pushes a SubagentBoxMessage; the matching tool_result
        # pops it. While a container is on the stack, inner widgets
        # (assistant deltas + nested tool calls) mount INSIDE the box
        # instead of into the parent transcript — visual containment.
        self._subagent_box_stack: list["SubagentBoxMessage"] = []
        # call_id → SubagentBoxMessage so a tool_result can find and
        # finalize the matching box even if other delegates have been
        # pushed/popped above it on the stack.
        self._subagent_boxes_by_call: dict[str, "SubagentBoxMessage"] = {}
        # Plan checklist. Single plan per session, mirroring Claude
        # Code's TodoWrite semantic: one logical list whose statuses
        # advance over time — re-emits replace/merge into the
        # existing plan rather than stacking new ones. Stored as a
        # length-0-or-1 list (``[{"items": [{content, activeForm,
        # status}, ...]}]``) so the renderer + replay scaffolding
        # don't have to special-case "no plan." Cleared on /new.
        self._plans: list[dict] = []

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        yield VerticalScroll(id="transcript")
        # Pending-turn queue. Hidden via `display: none` while empty;
        # `_refresh_queue_display` toggles it visible and populates rows
        # whenever `_turn_queue` changes. Rows are clickable / Enter-able:
        # selecting one pulls the text back into the input for editing.
        yield ListView(id="queue")
        # Slash-command autocomplete popup. Empty (and CSS-hidden) by
        # default; populates with matching ``/<command> — description``
        # rows whenever the input starts with ``/`` and contains no
        # space. Tab in the input completes to the longest common
        # prefix. See ``MessageInput._refresh_slash_popup``.
        yield Static("", id="slash-popup", markup=True)
        with Horizontal(id="input-row"):
            yield Static(">", id="input-prompt")
            yield MessageInput(placeholder="", id="input")
        # Plan checklist: persistent footer-area widget that lists
        # the multi-step todo from the most recent plan_pass.
        # Steps tick (☐ → ☑) as the model fires tool calls. Hidden
        # via empty content when there's no active plan.
        yield Static("", id="plan-checklist", markup=True)
        # Harness-task list footer. Persistent, pinned at the bottom
        # (above plan-checklist/status), populated from TaskCreate /
        # TaskUpdate tool calls. Empty content hides the row via the
        # ``height: auto`` CSS so an idle session has no extra chrome.
        yield Static("", id="harness-tasks", markup=True)
        # Subagent counter footer. Persistent, pinned at the bottom.
        # Bumps as each SubagentBoxMessage mounts (total) and finalizes
        # (done). Lets the operator see at a glance "3/8 subagents
        # complete" without having to scroll back through finalized
        # boxes that already left the viewport.
        yield Static("", id="subagent-counter", markup=True)
        # Single-row transient-event line above the footer — hosts
        # the one-shot ack messages (``session created``, ``/restart
        # scheduled``, ``command failed: …``) that used to clutter
        # the footer's state segment. Empty by default; cleared
        # whenever the operator types or a turn starts so stale
        # acks don't linger.
        yield Static("", id="status-events", markup=True)
        # Single consolidated footer (state · agent · mode · ctx ·
        # model · upstream-status). Identity + persistent
        # operational state only — transients live above.
        yield Static("", id="status-footer", markup=True)

    async def on_mount(self) -> None:
        # Textual dispatches on_mount on every class in the MRO that defines
        # one — child first, then parent. AgentChatApp does its own setup and
        # then this parent handler would otherwise stomp the status bar with
        # the legacy `endpoint=… model=… thinking=…` line. Gate it.
        if getattr(self, "_skip_legacy_setup", False):
            return
        _enable_kitty_keyboard_enhancements(self)
        self._start_new_session()
        think = "on" if self.enable_thinking else "off"
        self._set_status(f"endpoint={self.endpoint}  model={self.model}  thinking={think}")
        self.query_one(MessageInput).focus()
        # The TUI no longer auto-checkpoints memory on a timer. The
        # agent runtime persists every turn end-to-end already (session
        # JSON is the source of truth) and the OpenClaw heartbeat
        # scheduler running in the gateway covers the "proactive
        # memory maintenance" role this timer used to gesture at. See
        # `rtxclaw.heartbeat.HeartbeatScheduler`.

    def _start_new_session(self) -> None:
        self.session = Session.new(
            system_prompt=self.system_prompt,
            model=self.model,
            endpoint=self.endpoint,
        )
        self.session.save()
        self._refresh_title()

    def _refresh_title(self) -> None:
        s = self.session
        self.title = "rtxclaw"
        self.sub_title = f"{s.title}  [{s.hash}]" if s else ""

    def _set_status(self, msg: str) -> None:
        # Transient acks land on the events row above the footer.
        # The footer is identity-only and must never carry transient
        # messages — if the events row isn't mounted yet (compose,
        # older harness), silently drop the ack rather than leak it
        # into the footer.
        try:
            self.query_one("#status-events", Static).update(msg or "")
        except Exception:  # noqa: BLE001
            pass

    def _sibling_agent_names(self) -> set[str]:
        """Names of rtxclaw-native sibling agents available for the
        ``/<name> <task>`` auto-dispatch path. Loaded from the local
        ``AgentConfig.acp_agents`` at TUI construction (the gateway is
        co-located so we don't need an ACP round-trip). Returns an
        empty set on the legacy ``ChatApp`` (no agent_cfg attached).
        """
        return getattr(self, "_sibling_agents_cache", set())

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        text = event.value.strip()
        event.input.value = ""
        if not text:
            return
        if text == "/new":
            await self._cmd_new()
            return
        if text == "/abort":
            await self.action_abort(via="slash")
            return
        if text == "/restart":
            self._dispatch_restart()
            return
        if text == "/mouse":
            self.action_toggle_mouse()
            return
        if text == "/help":
            # Always render the local rich-Markdown help card. The
            # ACP adapter's ``session_command`` returns ``{"ok": True}``
            # with no text body for /help (it's a frontend-local view,
            # not an agent-state mutation), so routing through
            # ``_cmd_shared`` here would print "(no output)" instead
            # of the help table.
            await self._cmd_help()
            return
        if (
            text == "/status"
            or text == "/mode" or text.startswith("/mode ")
            or text == "/thinking" or text.startswith("/thinking ")
            or text == "/reasoning" or text.startswith("/reasoning ")
            or text == "/reason" or text.startswith("/reason ")
            or text in ("/on", "/off", "/stream")
            or text == "/tool" or text.startswith("/tool ")
            or text == "/tools" or text.startswith("/tools ")
            or text == "/history" or text.startswith("/history ")
            or text == "/context" or text.startswith("/context ")
            or text == "/ctx" or text.startswith("/ctx ")
        ):
            run = getattr(self, "_cmd_shared", None)
            if run is not None:
                self.run_worker(run(text), exclusive=False, name="command")
            else:
                self._set_status(f"{text.split()[0]} is only available via the agent runtime")
            return
        if text == "/compact":
            run = getattr(self, "_cmd_compact", None)
            if run is not None:
                self.run_worker(run(), exclusive=False, name="compact")
            else:
                self._set_status("/compact is only available via the agent runtime")
            return
        if text == "/sessions" or text.startswith("/sessions "):
            arg = text[len("/sessions"):].strip()
            run = getattr(self, "_cmd_sessions", None)
            if run is not None:
                self.run_worker(run(arg), exclusive=False, name="sessions")
            else:
                self._set_status("/sessions is only available via the agent runtime")
            return
        if text == "/refresh":
            run = getattr(self, "_poll_session_for_external_turns", None)
            if run is not None:
                self.run_worker(run(), exclusive=False, name="refresh")
                self._set_status("refreshing session…")
            else:
                self._set_status("/refresh is only available via the agent runtime")
            return
        if text.startswith("/claude "):
            rest = text[len("/claude "):].strip()
            if rest:
                # `_run_claude` is defined on AgentChatApp; the legacy
                # ChatApp doesn't have a Claude bridge but we still
                # parse the slash so the user gets a helpful error.
                if hasattr(self, "_enqueue_or_run") and hasattr(self, "_run_claude"):
                    self._enqueue_or_run("claude", rest)
                elif hasattr(self, "_run_claude"):
                    self.run_worker(self._run_claude(rest), exclusive=False, name="claude")
                else:
                    self._set_status("/claude is only available via the agent runtime")
            return
        if text.startswith("/codex "):
            rest = text[len("/codex "):].strip()
            if rest:
                # Mirror /claude: queue if AgentChatApp, direct-run if
                # legacy ChatApp, "not available" otherwise.
                if hasattr(self, "_enqueue_or_run") and hasattr(self, "_run_codex"):
                    self._enqueue_or_run("codex", rest)
                elif hasattr(self, "_run_codex"):
                    self.run_worker(self._run_codex(rest), exclusive=False, name="codex")
                else:
                    self._set_status("/codex is only available via the agent runtime")
            return
        if text.startswith("/gemini "):
            rest = text[len("/gemini "):].strip()
            if rest:
                # Same dispatch shape as /claude and /codex.
                if hasattr(self, "_enqueue_or_run") and hasattr(self, "_run_gemini"):
                    self._enqueue_or_run("gemini", rest)
                elif hasattr(self, "_run_gemini"):
                    self.run_worker(self._run_gemini(rest), exclusive=False, name="gemini")
                else:
                    self._set_status("/gemini is only available via the agent runtime")
            return
        if text == "/models" or text.startswith("/models "):
            arg = text[len("/models"):].strip()
            run = getattr(self, "_cmd_models", None)
            if run is not None:
                self.run_worker(run(arg), exclusive=False, name="models")
            else:
                self._set_status("/models is only available via the agent runtime")
            return
        if text == "/agents":
            run = getattr(self, "_cmd_agents", None)
            if run is not None:
                self.run_worker(run(), exclusive=False, name="agents")
            else:
                self._set_status("/agents is only available via the agent runtime")
            return
        if text == "/agent" or text.startswith("/agent "):
            arg = text[len("/agent"):].strip()
            run = getattr(self, "_cmd_agent", None)
            if run is not None:
                self.run_worker(run(arg), exclusive=False, name="agent-switch")
            else:
                self._set_status("/agent is only available via the agent runtime")
            return
        if text == "/todo" or text == "/todos":
            run = getattr(self, "_cmd_shared", None)
            if run is not None:
                self.run_worker(run("/todo"), exclusive=False, name="todo")
            else:
                self._set_status("/todo is only available via the agent runtime")
            return
        if text == "/task" or text.startswith("/task "):
            arg = text[len("/task"):].strip()
            run = getattr(self, "_cmd_task", None)
            if run is not None:
                self.run_worker(run(arg), exclusive=False, name="task")
            else:
                self._set_status("/task is only available via the agent runtime")
            return
        if text == "/subagents" or text.startswith("/subagents "):
            arg = text[len("/subagents"):].strip()
            run = getattr(self, "_cmd_subagents", None)
            if run is not None:
                self.run_worker(run(arg), exclusive=False, name="subagents")
            else:
                self._set_status("/subagents is only available via the agent runtime")
            return
        if text == "/monitors" or text == "/shells":
            # ``/shells`` is the discoverable alias — the modal navigates
            # every live subprocess the model spawned via ``monitor_*``
            # tools. Same dispatcher; just two trigger names so the
            # operator can find it under either mental model
            # ("monitors" matches the tool name, "shells" matches the
            # concept).
            run = getattr(self, "_cmd_monitors", None)
            if run is not None:
                self.run_worker(run(), exclusive=False, name="monitors")
            else:
                self._set_status(f"{text} is only available via the agent runtime")
            return
        if (
            text in ("/skills", "/skill")
            or text.startswith("/skill ")
            or text.startswith("/skills ")
        ):
            arg = text.split(" ", 1)[1].strip() if " " in text else ""
            run = getattr(self, "_cmd_skill", None)
            if run is not None:
                self.run_worker(run(arg), exclusive=False, name="skills")
            else:
                self._set_status("/skills is only available via the agent runtime")
            return
        if (
            text in ("/plugin", "/plugins")
            or text.startswith("/plugin ")
            or text.startswith("/plugins ")
        ):
            arg = text.split(" ", 1)[1].strip() if " " in text else ""
            run = getattr(self, "_cmd_plugin", None)
            if run is not None:
                self.run_worker(run(arg), exclusive=False, name="plugin")
            else:
                self._set_status("/plugin is only available via the agent runtime")
            return
        if (
            text in ("/mcp", "/mcps")
            or text.startswith("/mcp ")
            or text.startswith("/mcps ")
        ):
            arg = text.split(" ", 1)[1].strip() if " " in text else ""
            run = getattr(self, "_cmd_mcp", None)
            if run is not None:
                self.run_worker(run(arg), exclusive=False, name="mcp")
            else:
                self._set_status("/mcp is only available via the agent runtime")
            return
        if text == "/model" or text.startswith("/model "):
            arg = text[len("/model"):].strip()
            run = getattr(self, "_cmd_model", None)
            if run is not None:
                self.run_worker(run(arg), exclusive=False, name="model")
            else:
                self._set_status("/model is only available via the agent runtime")
            return
        # Auto-discovery for sibling agents — `/coder <task>`, `/scraper
        # <task>`, future `/<name>`. Distinct from `/claude` / `/codex`
        # / `/gemini` (handled above) which are external-LLM proxies
        # with bespoke per-vendor handlers. rtxclaw-native siblings all
        # share the uniform ``delegate_agent(name, task)`` interface,
        # so a single fallthrough wires them all without per-agent code.
        # Source of truth: ``cfg.acp_agents`` from the local AgentConfig
        # (gateway is co-located, no wire trip needed).
        if text.startswith("/") and " " in text:
            head, _, rest = text[1:].partition(" ")
            head = head.strip()
            rest = rest.strip()
            if head and rest and head in self._sibling_agent_names():
                if hasattr(self, "_enqueue_or_run"):
                    payload = (
                        "__RTXCLAW_DELEGATE__:delegate_agent:"
                        + json.dumps({"name": head, "task": rest})
                    )
                    self._enqueue_or_run("prompt", payload)
                    return
                self._set_status(
                    f"/{head} requires the agent runtime"
                )
                return
        # File-based slash commands (Claude Code `commands/*.md`, incl.
        # everything-claude-code). `/commands` lists them; `/<name>
        # [args]` expands the command's body (with $ARGUMENTS / $1…
        # substitution) into a normal user turn.
        if text == "/commands" or text.startswith("/commands "):
            run = getattr(self, "_cmd_commands", None)
            if run is not None:
                arg = text.split(" ", 1)[1].strip() if " " in text else ""
                self.run_worker(run(arg), exclusive=False, name="commands")
            else:
                self._set_status("/commands is only available via the agent runtime")
            return
        if text.startswith("/"):
            _head, _, _rest = text[1:].partition(" ")
            _head = _head.strip().lower()
            if _head:
                try:
                    from rtxclaw_core.file_commands import (
                        expand_command, find_command,
                    )
                    _fc = find_command(_head)
                except Exception:  # noqa: BLE001
                    _fc = None
                if _fc is not None:
                    _expanded = expand_command(_fc, _rest.strip())
                    # Stash a compact echo for the transcript — the
                    # full markdown body of a builtin command (e.g.
                    # /goal's 49-line preamble) goes to the model
                    # but the operator just wants to see ``❯ /goal
                    # <args>`` in the scrollback. ``_send_user_turn``
                    # picks this up, mounts it as the UserMessage,
                    # and clears the override so the next free-form
                    # prompt echoes verbatim.
                    _compact_echo = f"/{_head}"
                    if _rest.strip():
                        _compact_echo += f" {_rest.strip()}"
                    self._next_user_echo = _compact_echo
                    if hasattr(self, "_enqueue_or_run"):
                        self._enqueue_or_run("prompt", _expanded)
                    else:
                        await self._send_user_turn(_expanded)
                    return
        # Plain text → user turn. AgentChatApp queues if a turn is already
        # in flight (so a second Enter doesn't get dropped); legacy ChatApp
        # falls through to its direct-spawn busy-rejection path.
        if hasattr(self, "_enqueue_or_run"):
            self._enqueue_or_run("prompt", text)
        else:
            await self._send_user_turn(text)

    async def _cmd_new(self) -> None:
        if self._proc is not None:
            await self.action_abort(via="new")
            for _ in range(50):
                if self._proc is None:
                    break
                await asyncio.sleep(0.02)
        transcript = self.query_one("#transcript", VerticalScroll)
        await transcript.remove_children()
        self._start_new_session()
        assert self.session is not None
        self._set_status(f"new session [{self.session.hash}]")

    async def _cmd_help(self) -> None:
        """Render the rtxclaw help card inline. Available in both the
        legacy direct-spawn `ChatApp` and the agent-backed `AgentChatApp`
        — sections that depend on the agent runtime (`/claude`, `/compact`)
        are still listed because they're the most common reason new users
        need help; the legacy app surfaces a "not available" status when
        they're invoked there.
        """
        transcript = self.query_one("#transcript", VerticalScroll)
        await transcript.mount(UserMessage("❯ /help"))
        body = (
            "**rtxclaw — quick reference**\n\n"
            "**Slash commands**\n"
            "  /help                 — this card\n"
            "  /new                  — abort, clear transcript, start a new session\n"
            "  /abort                — kill the current generation (same as ESC)\n"
            "  /restart              — restart the gateway daemon (detached\n"
            "                          helper; bot reconnects in ~2s)\n"
            "  /mouse                — toggle mouse tracking (off = terminal\n"
            "                          text selection works; on = clickable UI)\n"
            "  /compact              — squeeze oversized tool results from the saved\n"
            "                          session so the next turn's prompt is shorter\n"
            "  /todo                 — show this session's todo checklist (the model\n"
            "                          writes it via the `todo` tool)\n"
            "  /skills               — list installed skills (name + description)\n"
            "  /skill <name>         — show one skill's full SKILL.md body\n"
            "  /commands             — list file-based slash commands (commands/*.md)\n"
            "  /<command> [args]     — run a file command (e.g. /refactor-clean)\n"
            "  /subagents [N]        — list / enter delegated subagent sessions\n"
            "  /monitors, /shells    — live panel of background shells the model\n"
            "                          spawned via the monitor_* tools\n"
            "  /sessions             — list saved sessions (most recent first)\n"
            "  /sessions <i|hash>    — switch to that session (index or hash prefix)\n"
            "  /models               — list configured models (interactive picker)\n"
            "  /model <alias|url>    — switch the live session to that model/upstream\n"
            "  /reasoning [on|off|stream] — show/stream/hide thinking tokens (default on)\n"
            "  /on, /off, /stream    — shortcuts for /reasoning <level>\n"
            "  /tools [on|off]       — toggle inline 🔧 tool-call header (default off)\n"
            "  /refresh              — pull any new turns appended by another\n"
            "                          frontend (Telegram, API) into the transcript\n"
            "  /claude <prompt>      — bridge the prompt to Claude Code (streams inline,\n"
            "                          chains across calls via --resume, includes the\n"
            "                          rtxclaw conversation as context)\n"
            "  /codex <prompt>       — same idea, bridges to OpenAI's Codex CLI\n"
            "                          (chains via `codex exec resume`, mirrors /claude)\n"
            "  /gemini <prompt>      — same idea, bridges to Google Gemini CLI\n"
            "                          (chains via `gemini --resume`, mirrors /claude)\n\n"
            "**Key bindings**\n"
            "  ESC                   — abort current operation (LLM round, tool, /claude, /codex, /gemini)\n"
            "  Ctrl+R                — toggle the most recent reasoning pane\n"
            "  Ctrl+T                — toggle the most recent tool result / compaction\n"
            "                          notice (expand/collapse)\n"
            "  Ctrl+/                — toggle mouse tracking (off = terminal text\n"
            "                          selection works; on = clickable collapsibles)\n"
            "  Shift+Tab             — cycle permission mode (plan → ask → auto)\n"
            "  Up / Down             — cycle through command history (like bash)\n"
            "  Ctrl+Up / Ctrl+Down   — hop into the pending-prompt queue (focus +\n"
            "                          navigate). Inside the queue: Enter pulls the\n"
            "                          row back into the input for editing, Delete\n"
            "                          drops it, Shift+Up/Down reorders, Escape\n"
            "                          returns focus to the input.\n\n"
            "**Mid-turn steering**\n"
            "  Submit a fresh prompt while the agent is mid-plan and the new\n"
            "  message lands at the next round boundary (no waiting for the\n"
            "  current turn to end). The transcript marks it with\n"
            "  `↳ injected mid-turn`. Queued entries for /claude / /codex /\n"
            "  /gemini bridges still wait for end-of-turn — those engines\n"
            "  don't support mid-flight steering.\n\n"
            "**Status bar**\n"
            "  agent · mode · model · ctx <used>/<max> · hb <age>s · uptime\n"
            "  ctx warns you before the runtime auto-compacts; /compact (or the\n"
            "  model's compact_context tool call) trims it manually.\n\n"
            "**Permission modes**\n"
            "  plan   — research only, no edits\n"
            "  ask    — prompts on every write/exec/network tool call\n"
            "  auto   — runs autonomously; ESC is the only bound (bypassPermissions in /claude)\n\n"
            "Configure agents with:  rtxclaw agent {init,list,start,stop,restart,status,logs}\n"
            "One-shot:               rtxclaw -p \"...\"\n"
            "Claude bridge from CLI: rtxclaw --claude --plan -p \"...\"\n"
            "Codex bridge from CLI:  rtxclaw --codex --plan -p \"...\"\n"
        )
        await transcript.mount(Static(RichMarkdown(body), classes="claude-msg"))
        self._maybe_scroll_end(transcript)

    async def action_abort(self) -> None:
        if self._proc is None:
            # No in-flight turn — surface the no-op so the operator
            # sees their /abort registered. Without this the status
            # footer just stays at "idle" and the user can't tell
            # whether the bind/keystroke landed at all.
            self._set_status("nothing to abort — no turn in flight")
            return
        self._abort_requested = True
        try:
            self._proc.terminate()
        except ProcessLookupError:
            pass
        self._set_status("aborting…")

    def action_toggle_thinking(self) -> None:
        """Expand/collapse the most recent assistant turn's reasoning pane.

        Walks the transcript in reverse so the binding always lands on the
        currently-streaming turn first; falls back to the last finished one.
        Bound to `Ctrl+R`.
        """
        messages = list(self.query(AssistantMessage))
        for msg in reversed(messages):
            if msg._thinking_box is not None:
                msg._thinking_box.collapsed = not msg._thinking_box.collapsed
                # Refresh the title so the "Ctrl+R to expand/collapse" hint
                # flips immediately rather than waiting for the next tick.
                msg._refresh_think_title(active=msg._think_ended is None)
                state = "expanded" if not msg._thinking_box.collapsed else "collapsed"
                self._set_status(f"reasoning {state}")
                return
        self._set_status("no reasoning to toggle yet")

    def action_toggle_tool_output(self) -> None:
        """Expand/collapse the most recent tool-result widget. Bound to `Ctrl+T`.

        Symmetric to `action_toggle_thinking` — walks the transcript in
        reverse and toggles the most recent `ToolResultMessage`. Tool
        results default to collapsed so a 64 KiB grep doesn't dominate
        the view; this binding pulls one open on demand.
        """
        results = list(self.query(ToolResultMessage))
        for r in reversed(results):
            collapsed = r.toggle()
            self._set_status(
                f"tool output {'collapsed' if collapsed else 'expanded'}"
            )
            return
        self._set_status("no tool output to toggle yet")

    def action_toggle_mouse(self) -> None:
        """Toggle mouse tracking on/off. Bound to Ctrl+/.

        Off (default): terminal handles native text selection (shift+drag).
        On: TUI captures mouse for clickable collapsibles, but you can't
        select/copy text with the mouse.
        """
        self.mouse_support = not self.mouse_support
        self._set_status(f"mouse {'enabled' if self.mouse_support else 'disabled'} (terminal selection {'blocked' if self.mouse_support else 'available'})")

    async def action_request_quit(self) -> None:
        """Two-press Ctrl+C with first-press warning.

        First press → warn + arm a 3-second window.
        Second press within the window → flush memory and exit.
        """
        now = time.monotonic()
        last = getattr(self, "_quit_armed_at", None)
        if last is not None and (now - last) < 3.0:
            try:
                await self._on_exit_flush()
            except Exception:  # noqa: BLE001
                pass
            self.exit()
            return
        self._quit_armed_at = now
        self._set_status("press Ctrl+C again within 3s to quit (memory will be saved)")

    async def _on_exit_flush(self) -> None:
        """Hook for subclasses to persist state before quit. No-op here."""
        return None

    async def _send_user_turn(self, text: str) -> None:
        if self._proc is not None:
            self._set_status("busy — press ESC or /abort to cancel current turn")
            return

        assert self.session is not None
        transcript = self.query_one("#transcript", VerticalScroll)
        await transcript.mount(UserMessage(f"❯ {text}"))
        assistant = AssistantMessage()
        await transcript.mount(assistant)
        self._maybe_scroll_end(transcript)

        self._current_assistant = assistant
        self._current_user_text = text

        messages: list[dict[str, str]] = [{"role": "system", "content": self.system_prompt}]
        for turn in self.session.turns:
            messages.append({"role": "user", "content": turn["user"]})
            content = turn.get("content") or ""
            if content:
                messages.append({"role": "assistant", "content": content})
        messages.append({"role": "user", "content": text})

        request = {
            "endpoint": self.endpoint,
            "model": self.model,
            "messages": messages,
            "temperature": self.temperature,
            "extra": {
                # vLLM's OpenAI-compat endpoint forwards this to the model's
                # chat template. Qwen3 family gates the <think> phase on it.
                "chat_template_kwargs": {"enable_thinking": self.enable_thinking},
            },
        }
        # Per-row upstream headers (OpenRouter Bearer + X-Title, etc.)
        # The TUI's legacy worker-spawn path bypasses the bridge, so
        # the same headers the bridge attaches in
        # ``_build_worker_request`` need to be plumbed in here too —
        # without this, switching to a model row with ``apiKeyEnv``
        # set (kimi → OpenRouter) hits HTTP 401 because the Bearer
        # token never reaches the worker. Local vLLM rows resolve to
        # an empty dict and are unaffected.
        try:
            upstream_hdrs = self.agent_cfg.upstream_headers(self.endpoint)
        except Exception:  # noqa: BLE001
            upstream_hdrs = {}
        if upstream_hdrs:
            request["headers"] = dict(upstream_hdrs)

        self.run_worker(self._stream_worker(request), exclusive=True, name="stream")

    async def _stream_worker(self, request: dict) -> None:
        assert self.session is not None
        assistant = self._current_assistant
        assert assistant is not None

        started = _now()
        self._abort_requested = False

        package_parent = str(Path(__file__).resolve().parent.parent)
        env = dict(os.environ)
        existing = env.get("PYTHONPATH", "")
        env["PYTHONPATH"] = (
            package_parent + (os.pathsep + existing if existing else "")
        )
        env["PYTHONUNBUFFERED"] = "1"

        proc = await asyncio.create_subprocess_exec(
            sys.executable,
            "-m",
            "rtxclaw_agent.worker",
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=env,
            limit=_SUBPROCESS_STDIO_LIMIT,
        )
        self._proc = proc
        self._set_status("[dim]ESC to cancel[/dim]")

        assert proc.stdin is not None
        proc.stdin.write(json.dumps(request).encode("utf-8"))
        await proc.stdin.drain()
        proc.stdin.close()

        worker_aborted = False
        worker_error: Optional[str] = None
        worker_metrics: Optional[dict] = None
        transcript = self.query_one("#transcript", VerticalScroll)

        try:
            assert proc.stdout is not None
            while True:
                line = await proc.stdout.readline()
                if not line:
                    break
                try:
                    event = json.loads(line.decode("utf-8"))
                except json.JSONDecodeError:
                    continue
                kind = event.get("kind")
                if kind == "thinking":
                    await assistant.append_thinking(event.get("text", ""))
                elif kind == "content":
                    assistant.append_content(event.get("text", ""))
                elif kind == "aborted":
                    worker_aborted = True
                elif kind == "error":
                    worker_error = event.get("message") or "unknown error"
                elif kind == "metrics":
                    worker_metrics = {k: v for k, v in event.items() if k != "kind"}
                elif kind == "done":
                    pass
                self._maybe_scroll_end(transcript)
        finally:
            await proc.wait()
            stderr_bytes = b""
            if proc.stderr is not None:
                try:
                    stderr_bytes = await proc.stderr.read()
                except Exception:  # noqa: BLE001
                    stderr_bytes = b""
            self._proc = None

        ended = _now()
        aborted = worker_aborted or self._abort_requested
        rc = proc.returncode or 0

        if worker_error:
            assistant.mark_error(worker_error)
            self._set_status(f"error: {worker_error[:80]}")
        elif aborted:
            assistant.mark_aborted()
            self._set_status("aborted")
        elif rc != 0:
            stderr_txt = stderr_bytes.decode("utf-8", "replace")[:300]
            msg = f"worker exited {rc}: {stderr_txt}".strip()
            assistant.mark_error(msg)
            self._set_status(f"error: rc={rc}")
        else:
            if worker_metrics:
                assistant.set_metrics(worker_metrics)
            assistant.finalize()
            # Footer no longer carries per-call stats — they live on the
            # assistant message itself. Clear any prior transient.
            self._set_status("")

        self.session.add_turn(
            user=self._current_user_text,
            thinking=assistant.thinking_text,
            content=assistant.content_text,
            started_at=started,
            ended_at=ended,
            aborted=aborted,
            error=worker_error,
            metrics=worker_metrics,
        )
        self.session.save()
        self._refresh_title()

    @classmethod
    def via_agent(cls, agent_cfg, *, endpoint_override: Optional[str] = None) -> "AgentChatApp":
        """Construct an AgentChatApp that talks to the given running agent.

        `endpoint_override` (when set) is the URL the daemon should use
        for this session's worker spawns — the resolved form of the
        user's `--endpoint <alias|url>` flag. Sticky for the session
        until changed via the `/model` slash command.
        """
        return AgentChatApp(agent_cfg=agent_cfg, endpoint_override=endpoint_override)


HEALTH_POLL_INTERVAL_S = 15.0  # /v1/control/status poll cadence


class AgentChatApp(ChatApp):
    """ChatApp that proxies turns through an AgentClient instead of spawning workers."""

    def __init__(self, *, agent_cfg, endpoint_override: Optional[str] = None) -> None:
        super().__init__(
            endpoint=agent_cfg.upstream_endpoint,
            model=agent_cfg.upstream_model or agent_cfg.name,
            system=agent_cfg.system,
            temperature=agent_cfg.temperature,
            enable_thinking=agent_cfg.enable_thinking,
        )
        self.agent_cfg = agent_cfg
        # Cached sibling-agent registry for the `/<name> <task>` auto-
        # dispatch fallthrough in `on_input_submitted`. Source: the
        # global ``~/.rtxclaw/config.json`` ``acp_agents`` map (this
        # isn't a dataclass field on ``AgentConfig`` so we read the
        # raw dict directly — same source the ``delegate_agent``
        # runner uses, so the slash registry can never disagree with
        # the dispatch path). Excludes the current agent's own name.
        try:
            from rtxclaw_core.agent import load_global_config
            siblings_cfg = (load_global_config() or {}).get("acp_agents") or {}
            my_name = getattr(agent_cfg, "name", "") or ""
            self._sibling_agents_cache: set[str] = {
                str(name) for name in siblings_cfg.keys()
                if isinstance(name, str) and name != my_name
            }
        except Exception:  # noqa: BLE001
            self._sibling_agents_cache = set()
        # The resolved upstream URL the next-created session should
        # bind to. None = let the agent daemon use its configured
        # primary. Set initially from `--endpoint <alias|url>`; the
        # `/model` slash command rebinds the LIVE session via a
        # daemon-side mutation rather than touching this field.
        self._endpoint_override: Optional[str] = endpoint_override
        # Tell ChatApp.on_mount to skip its legacy direct-spawn startup —
        # Textual would otherwise also fire it via MRO and stomp the bar.
        self._skip_legacy_setup = True
        self._client = None  # populated in on_mount
        self._sid: Optional[str] = None
        self._current_turn_id: Optional[str] = None
        # Composite status-bar state. Three layers, rendered together by
        # `_refresh_status_bar`:
        #   1. `_worker_state` — ALWAYS-VISIBLE indicator while a turn is in
        #      flight: "▶ streaming…", "🔧 running tool: bash", "🤖 claude
        #      running…". Set by the dispatch loop, cleared at end-of-turn.
        #      Lives BESIDE `_turn_state` so an unrelated transient ("reasoning
        #      expanded") doesn't clobber the streaming-is-alive cue — that's
        #      the user's primary signal that the agent isn't stuck.
        #   2. `_turn_state` — short transient feedback ("done · …", "session
        #      created", "compacting…", "reasoning expanded"). Updated by
        #      `_set_status`.
        #   3. health portion (refreshed by the 15s poll) + warn.
        self._health: Optional[dict] = None
        self._health_error: Optional[str] = None
        self._worker_state: str = ""
        self._turn_state: str = ""
        self._upstream_warn: Optional[str] = None
        # Pending-turn queue. New user prompts and /claude calls submitted
        # while a turn is already in flight land here as `(kind, payload)`
        # tuples — `kind` is "prompt" or "claude". Drained sequentially in
        # the order they were submitted by `_maybe_start_next` after each
        # turn ends. Without this queue the second Enter while the first
        # turn is still streaming would race the dispatcher: the busy
        # check rejected the input and silently dropped the user's text.
        from collections import deque as _deque
        self._turn_queue: _deque = _deque()
        self._health_timer = None
        # Wall-clock timestamp of the last successful `/v1/control/status`
        # poll. Drives the "hb Xs" heartbeat-age display in the status
        # bar so the user can tell at a glance whether the agent is
        # currently reachable. None means we haven't successfully polled
        # yet (or the most recent poll failed).
        self._last_health_at: Optional[float] = None
        # Latest authoritative prompt_tokens reported by the worker; the
        # status bar renders this as `ctx <last>/<max>` so the user can
        # see how close they are to the upstream context limit. None
        # until the first round's metrics arrive.
        self._last_prompt_tokens: Optional[int] = None
        self._last_context_window: Optional[int] = None
        # Display-refresh tick — re-renders the status bar so the
        # heartbeat age counts up between health polls. Doesn't fetch
        # anything new; SSH-aware (slower interval to save bandwidth).
        self._display_timer = None
        # Footer spinner. ``_anim_tick`` advances on a fast timer while
        # ``_worker_state`` is non-empty so the operator sees motion on
        # the state segment — the user's primary "TUI isn't frozen"
        # signal during long tool calls or stretches where the upstream
        # pauses between streaming chunks. Idle = timer is a no-op.
        self._anim_tick: int = 0
        self._anim_timer = None
        # Permission mode for this TUI session. Defaults to whatever the
        # agent's config says; cycled by Shift+Tab.
        self._permission_mode: str = (
            getattr(agent_cfg, "permission_mode", "auto") or "auto"
        )
        # `/claude <prompt>` chains across slash invocations within a single
        # rtxclaw session via Claude Code's `--resume <session_id>`. The id
        # is captured from the first call's stream-json events and reused
        # for subsequent calls. None until the first /claude runs.
        self._claude_session_id: Optional[str] = None
        # Server-side `delegate_claude` tool runner's turn id, captured
        # from the SSE response of `_run_claude`. Used by ESC to stop
        # the running tool through `turn_stop`. None when no /claude
        # call is in flight.
        self._claude_turn_id: Optional[str] = None
        # Number of rtxclaw session turns Claude has already been shown
        # via the context preamble. Each `/claude` invocation pre-pends
        # the user/local-model exchanges accumulated since the last call
        # so Claude can answer follow-ups like "research more on this"
        # without losing the prior conversation. `--resume` chains
        # Claude's own state turn-to-turn; this index avoids repeating
        # context Claude has already seen. Reset to 0 on session start.
        self._claude_synced_turn_idx: int = 0
        # `/codex <prompt>` mirrors `/claude` against OpenAI's Codex CLI:
        # `_codex_thread_id` is captured from `thread.started` events
        # and reused via `codex exec resume <id>` on follow-ups;
        # `_codex_turn_id` lets ESC stop the in-flight tool runner;
        # `_codex_synced_turn_idx` avoids re-feeding rtxclaw turns Codex
        # has already seen via its own resume state. None / 0 until the
        # first /codex runs in this session.
        self._codex_thread_id: Optional[str] = None
        self._codex_turn_id: Optional[str] = None
        self._codex_synced_turn_idx: int = 0
        self._codex_pending_synced_idx: int = 0
        # `/gemini <prompt>` mirrors `/claude` and `/codex` against the
        # Google Gemini CLI. ``_gemini_session_id`` is the Gemini-side
        # UUID surfaced via ``init`` events and reused via
        # ``--resume <id>`` on follow-ups.
        self._gemini_session_id: Optional[str] = None
        self._gemini_turn_id: Optional[str] = None
        self._gemini_synced_turn_idx: int = 0
        self._gemini_pending_synced_idx: int = 0
        # Number of turns we've already rendered into the transcript
        # (live + replayed). The poll timer compares this against the
        # session JSON's actual turn count to detect turns that landed
        # on disk while we weren't streaming — typically a Telegram or
        # API client writing to the same session — and renders them
        # inline so the user sees both sides of a multi-frontend
        # conversation in real time.
        self._known_turn_count: int = 0
        self._session_poll_timer = None

    async def on_mount(self) -> None:
        from rtxclaw_tui.agent_client import AgentClient
        gateway_url, gateway_token = _gateway_url_and_token()
        self._client = AgentClient(
            self.agent_cfg.url,
            agent_name=self.agent_cfg.name,
            gateway_url=gateway_url,
            gateway_token=gateway_token,
        )
        self._wire_client_callbacks(self._client)
        # Reconnect watcher state. The watcher fires every
        # ``RECONNECT_WATCH_INTERVAL_S`` and rebuilds the client when
        # the stdio child has died. The lock dedupes concurrent
        # callers (eager poll-driven retry + scheduled tick) so we
        # never spawn two stdio children for one disconnect — that
        # used to leak an orphaned acp-stdio child each time both
        # paths fired in the same loop tick.
        self._reconnect_lock: asyncio.Lock = asyncio.Lock()
        self._reconnect_attempts: int = 0
        self._last_reconnect_at: float = 0.0
        _enable_kitty_keyboard_enhancements(self)
        self.query_one(MessageInput).focus()

        # 1. Initial health probe so the status bar isn't blank for 15s.
        await self._poll_health()

        # 2. Schedule the recurring health poll. The status bar's durable
        #    portion (agent up/down, upstream up/down, model) is refreshed
        #    on every tick; transient turn-state ("streaming…", "done · …",
        #    "error: …") is set independently by _set_status.
        self._health_timer = self.set_interval(
            HEALTH_POLL_INTERVAL_S, self._poll_health
        )

        # 2.1 Reconnect watcher — runs at 2 s on a fresh boot, longer
        #     under SSH to keep link bandwidth modest. Detects a dead
        #     stdio child WITHOUT a network round-trip (just checks
        #     ``self._client._proc.returncode``); when dead, rebuilds
        #     the client and reattaches via ``session/load`` to keep
        #     the operator's active session id valid.
        reconnect_tick = 5.0 if _IS_SSH else 2.0
        self._reconnect_timer = self.set_interval(
            reconnect_tick, self._watch_connection,
        )

        # 2.5 Schedule a faster, *no-fetch* tick so the heartbeat-age
        #    indicator (`hb Xs`) counts up between polls. SSH-aware:
        #    slower interval so we don't waste link bandwidth on a
        #    1-second-resolution age display.
        display_tick = 10.0 if _IS_SSH else 5.0
        self._display_timer = self.set_interval(
            display_tick, self._refresh_status_bar
        )

        # 2.55 Spinner tick — fast cadence so the operator sees motion
        #      on the worker-state segment while a turn is in flight.
        #      The handler bails out immediately when ``_worker_state``
        #      is empty (idle), so this is essentially free except
        #      during an active turn. SSH-aware so we don't burn
        #      bandwidth on idle frames over a slow link.
        anim_tick = 0.5 if _IS_SSH else 0.25
        self._anim_timer = self.set_interval(
            anim_tick, self._animate_status,
        )

        # 2.6 Cross-frontend turn-sync poller. Picks up turns appended to
        #     the active session by other clients (Telegram, another
        #     TUI, a raw API caller) so the user sees both sides of a
        #     multi-frontend conversation without having to /sessions
        #     toggle. Skipped while a turn is in flight here — the SSE
        #     consumer is already rendering live events; layering the
        #     poll's replay on top would double-render. Picks up the
        #     pending turn on the very next tick after the live one
        #     finishes. SSH-aware to keep bandwidth modest.
        sync_tick = 8.0 if _IS_SSH else 5.0
        self._session_poll_timer = self.set_interval(
            sync_tick, self._poll_session_for_external_turns
        )

        # 3. If the agent is reachable, try to create a session. If it fails
        #    (e.g. transient upstream blip), keep the error visible —
        #    `_send_user_turn` will retry rather than locking us out.
        if self._health is not None:
            await self._ensure_session(initial=True)

    async def _poll_health(self) -> None:
        """One tick of the 15s health poll — repaints the status bar.

        On a connection failure, kicks the reconnect watcher so it
        notices the dead client even before its own 2 s tick fires.
        Without this, a network failure during a slow turn would
        leave the user staring at "error: connection refused" until
        the next watcher tick (up to 5 s on SSH).
        """
        if self._client is None:
            return
        try:
            self._health = await self._client.status()
            self._health_error = None
            self._last_health_at = time.monotonic()
        except Exception as e:  # noqa: BLE001
            self._health = None
            self._health_error = str(e) or repr(e)
            # Health failure usually means the stdio child is gone or
            # ACP transport is closed. Schedule an immediate reconnect
            # attempt rather than waiting for the next watcher tick.
            self.run_worker(
                self._watch_connection(),
                exclusive=False, name="reconnect-eager",
            )
        self._refresh_status_bar()

    async def _watch_connection(self) -> None:
        """Reconnect watcher tick.

        Cheap path: if the client looks live (``is_connected()``),
        return. Otherwise acquire ``self._reconnect_lock`` and
        rebuild — the lock dedupes concurrent callers (eager path
        from ``_poll_health`` + scheduled timer tick) so we never
        spawn two stdio children for one disconnect.

        Backoff: 1, 2, 4, 8, … seconds, capped at 30 s. Reset on
        success. We don't sleep here — we just *skip* if the prior
        attempt was less than the current backoff window ago.
        """
        if self._client is None:
            return
        if self._client.is_connected():
            # Healthy — reset backoff state.
            if self._reconnect_attempts:
                self._reconnect_attempts = 0
            return
        # Lock dedupes concurrent callers. ``locked()`` skip path
        # avoids piling up a queue of waiters behind a long
        # in-flight reconnect.
        if self._reconnect_lock.locked():
            return
        async with self._reconnect_lock:
            # Recheck inside the lock — another caller may have
            # already healed the client between our pre-lock peek
            # and acquisition.
            if self._client is not None and self._client.is_connected():
                self._reconnect_attempts = 0
                return
            backoff_s = min(2 ** self._reconnect_attempts, 30)
            if time.monotonic() - self._last_reconnect_at < backoff_s:
                return
            self._reconnect_attempts += 1
            self._last_reconnect_at = time.monotonic()
            await self._reconnect()

    async def _reconnect(self) -> None:
        """Tear down the dead ``AgentClient``, spawn a fresh one,
        and re-attach to the active session via ``session/load``.

        Best-effort: a reattach failure (e.g. the agent's session
        store rolled away) leaves ``self._sid = None`` so the next
        operation will create a fresh session instead of failing
        in a confusing way. Status bar tracks state across the
        reconnect window so the operator sees what's happening.
        """
        from rtxclaw_tui.agent_client import AgentClient
        self._set_status(
            f"⟳ reconnecting (attempt {self._reconnect_attempts})…",
        )
        # Tear down the dead client. ``close`` will SIGTERM/wait the
        # zombie child if any.
        try:
            await self._client.close()
        except Exception:  # noqa: BLE001
            pass
        # Build a fresh client against the gateway. The gateway owns
        # every agent's stdio child; reconnecting just rebuilds the
        # HTTP transport, no process spawn happens here.
        gateway_url, gateway_token = _gateway_url_and_token()
        new_client = AgentClient(
            self.agent_cfg.url,
            agent_name=self.agent_cfg.name,
            gateway_url=gateway_url,
            gateway_token=gateway_token,
        )
        try:
            # Probe by calling status() — that triggers the lazy
            # ``_ensure_connected`` path which spawns the child.
            await new_client.status()
        except Exception as e:  # noqa: BLE001
            self._set_status(
                f"reconnect failed: {e} — retrying in "
                f"{min(2 ** self._reconnect_attempts, 30)}s",
            )
            try:
                await new_client.close()
            except Exception:  # noqa: BLE001
                pass
            return
        # New client up. Try to re-attach to the existing session id;
        # if that fails (session_load not supported, or the agent
        # forgot the sid), fall back to a fresh session so the
        # operator can keep working without restarting the TUI.
        self._client = new_client
        self._wire_client_callbacks(self._client)
        if self._sid is not None:
            try:
                await new_client.attach_session(
                    self._sid, cwd=os.getcwd(),
                )
                self._set_status(
                    f"✓ reconnected — session {self._sid[:12]} resumed",
                )
            except Exception as e:  # noqa: BLE001
                # Reattach failed — the agent might have lost the
                # session record across the restart. Drop sid so
                # the next op spawns a fresh one. Reset the
                # plan-checklist and harness-task footers too, since
                # both lived only in the prior session and would
                # otherwise show stale rows above the new prompt.
                old_sid = self._sid
                self._sid = None
                self.session = None
                self._known_turn_count = 0
                try:
                    self.clear_plan_checklist()
                except Exception:  # noqa: BLE001
                    pass
                try:
                    self._clear_harness_tasks()
                except Exception:  # noqa: BLE001
                    pass
                self._set_status(
                    f"reconnected but couldn't resume {old_sid}: {e}. "
                    "next message starts a fresh session."
                )
        else:
            self._set_status("✓ reconnected — no active session")
        # Refresh status bar so the durable footer reflects the new
        # health probe immediately rather than on the next 15 s tick.
        await self._poll_health()

    async def _ensure_session(self, *, initial: bool = False) -> bool:
        """Create a session if we don't have one. Return True on success."""
        if self._sid is not None:
            return True
        assert self._client is not None
        try:
            # Pass the TUI's launch directory so the agent injects a
            # `# WORKSPACE-CONTEXT` block at the tail of the system
            # prompt — model knows which folder the user is in.
            # Pass the resolved `--endpoint` override (when set) so the
            # daemon spawns workers against the alternate upstream.
            sess = await self._client.create_session(
                workspace_cwd=os.getcwd(),
                workspace_origin="tui",
                endpoint=self._endpoint_override,
            )
        except Exception as e:  # noqa: BLE001
            self.session = Session.new(
                system_prompt="", model="", endpoint=self.agent_cfg.url,
            )
            self._refresh_title()
            self._upstream_warn = None
            self._set_status(f"session create failed: {e}")
            return False
        self._sid = sess["hash"]
        self.session = Session(
            hash=sess["hash"], title=sess["title"], created_at=sess["created_at"],
            system_prompt="", model=sess.get("model", ""),
            endpoint=sess.get("endpoint", ""), turns=[],
            context_window=int(sess.get("context_window") or 0),
        )
        # Brand-new session — no turns yet. Anchors the poll for any
        # cross-frontend turns that arrive before the user's first.
        self._known_turn_count = 0
        # Fresh session id: reset the harness-task footer so the new
        # session's TaskCreate calls start at #1 again on a clean slate.
        # Plan-checklist gets cleared by the caller (/new explicitly,
        # /restart via the reattach-failure branch above).
        try:
            self._clear_harness_tasks()
        except Exception:  # noqa: BLE001
            pass
        self._refresh_title()
        upstream_error = sess.get("upstream_error")
        self._upstream_warn = (
            f"upstream warn: {upstream_error[:60]}" if upstream_error else None
        )
        # Initial state is implicit: no turn state, just the health line + any warn.
        self._turn_state = ""
        self._refresh_status_bar()
        return True

    # -------- composite status bar --------

    async def _handle_permission_request(self, data: dict) -> None:
        """Pop the modal, POST the user's answer, return.

        The agent has paused its dispatch loop on a Future. We block the
        SSE consumer here too — modal is awaited, response goes back via
        the agent client, then the loop continues. The modal returns one
        of "yes" / "yes_dont_ask" / "no"; on errors / cancel we send "no".
        """
        tid = data.get("turn_id") or self._current_turn_id
        call_id = data.get("call_id")
        if not tid or not call_id:
            return
        try:
            answer = await self.push_screen_wait(
                PermissionModal(
                    tool=data.get("tool", "?"),
                    kind=data.get("kind", "?"),
                    arguments=data.get("arguments") or {},
                )
            )
        except Exception:  # noqa: BLE001
            answer = "no"
        try:
            await self._client.submit_permission(tid, call_id, answer or "no")
        except Exception as e:  # noqa: BLE001
            self._set_status(f"permission send failed: {e}")

    async def _on_ask_user(self, params: dict) -> dict:
        """Pop ``QuestionsModal`` and return selections to ``_inbound_ask_user``.

        Hooked via :meth:`AgentClient.set_ask_user_callback` on every
        client construction. The handler runs inside the ACP client's
        read loop, so we await the modal directly — the agent's
        outbound ``session/ask_user`` request stays parked on its
        future until ``push_screen_wait`` returns. Cancel / errors
        return an empty answers list so the bridge surfaces a clean
        "user cancelled" tool_result instead of hanging.
        """
        questions = params.get("questions") if isinstance(params, dict) else []
        if not isinstance(questions, list) or not questions:
            return {"answers": [], "cancelled": True}
        try:
            result = await self.push_screen_wait(QuestionsModal(questions))
        except Exception:  # noqa: BLE001
            return {"answers": [], "cancelled": True}
        if not isinstance(result, dict) or not isinstance(
            result.get("answers"), list
        ):
            return {"answers": [], "cancelled": True}
        return result

    async def _on_request_permission(self, params: dict) -> dict:
        """Pop :class:`AcpPermissionModal` and return the ACP outcome.

        Hooked via :meth:`AgentClient.set_permission_callback`. Like
        :meth:`_on_ask_user` it runs inside the ACP client's read loop,
        so we await the modal directly — the agent's outbound
        ``session/request_permission`` stays parked on its future until
        the user clicks (or the modal's 30s countdown auto-denies).
        Esc / cancel / any error resolves to ``reject_once``: the
        agent only asks because the op is destructive, so "not an
        explicit allow" is a deny.

        Returns the ACP ``RequestPermissionResponse`` mapping verbatim.
        """
        _DENY = {"outcome": {"outcome": "selected", "optionId": "reject_once"}}
        try:
            option_id = await self.push_screen_wait(AcpPermissionModal(params))
        except Exception:  # noqa: BLE001 - modal teardown / app closing
            return _DENY
        if option_id not in (
            "allow_once", "allow_always", "reject_once", "reject_always"
        ):
            return _DENY
        return {
            "outcome": {"outcome": "selected", "optionId": option_id}
        }

    def _wire_client_callbacks(self, client) -> None:
        """Install AskUserQuestion + permission UI hooks on a fresh
        ``AgentClient``. Called from each instantiation path —
        startup, reconnect-watcher, ``/agent`` swap — so newly built
        clients pop the modals instead of falling back to the
        synthetic auto-answer / deny-by-default."""
        try:
            client.set_ask_user_callback(self._on_ask_user)
        except Exception:  # noqa: BLE001
            # Older clients may lack the method on partial upgrades;
            # don't crash the App for a missing hook.
            pass
        try:
            client.set_permission_callback(self._on_request_permission)
        except Exception:  # noqa: BLE001
            pass

    _MODES_CYCLE = ("auto", "ask", "plan")

    def action_cycle_mode(self) -> None:
        """Cycle permission mode auto → ask → plan → auto.

        Local TUI state, sent as `permission_mode` in each turn request
        so the agent picks it up. Cycle order goes from least cautious
        to most cautious — a single press takes you tighter, and rolling
        all the way around lands you back on auto.
        """
        try:
            i = self._MODES_CYCLE.index(self._permission_mode)
        except ValueError:
            i = 0
        self._permission_mode = self._MODES_CYCLE[(i + 1) % len(self._MODES_CYCLE)]
        self._refresh_status_bar()
        # Surface the change as a transient turn-state suffix so the
        # user sees it acknowledged without having to read the wrapped
        # right-side fields.
        self._set_status(f"permission mode: {self._permission_mode}")

    def action_open_shells(self) -> None:
        """Ctrl+S — open the Shells modal (alias for the ``/shells`` /
        ``/monitors`` slash command). Dispatches into ``_cmd_monitors``
        via the same worker pattern the slash dispatcher uses so the
        modal mount path is identical."""
        run = getattr(self, "_cmd_monitors", None)
        if run is None:
            self._set_status("shells panel only available via the agent runtime")
            return
        self.run_worker(run(), exclusive=False, name="shells")

    # Auto-scroll affinity threshold in pixels (~3 text rows in
    # Textual's default Y-pixel unit, where 1 row = 1 unit). When the
    # transcript's bottom edge is within this distance from the
    # viewport's bottom edge, follow-mode is ON and ``scroll_end``
    # calls actually scroll. Above the threshold the user is reading
    # back-scroll and we leave them where they are. 3 was picked
    # empirically: less than the visible chunk of a typical
    # AssistantMessage (so a single new chunk landing at the bottom
    # while the user reads above doesn't yank them down), more than
    # the line-height jitter Textual's virtual_size emits during
    # mid-frame relayout.
    _SCROLL_FOLLOW_THRESHOLD = 3

    # Persistent follow-mode flag. Initial True so the empty
    # transcript starts in "follow the tail." We DON'T re-derive it
    # from ``virtual_size``/``scroll_y`` on each call (that loses
    # affinity across bulk mounts: a user who was at the bottom
    # right before an 8-row tool-result mount is suddenly 8 rows
    # away from it). Instead the on_scroll handler flips the flag
    # when the user actively scrolls — see ``on_scroll``.
    _scroll_follow: bool = True

    def on_scroll(self, event) -> None:  # noqa: ANN001
        """Track the user's scroll affinity for ``_maybe_scroll_end``.

        Textual dispatches ``Scroll`` events for every scroll change
        (wheel, page-up/down, scrollbar drag, programmatic). We use
        the user-initiated ones to decide whether passive auto-scroll
        should follow:

        * Scroll lands within ``_SCROLL_FOLLOW_THRESHOLD`` of the
          bottom → re-enable follow (the user is back at the tail).
        * Otherwise → disable follow (the user is reading back, do
          NOT yank them down on the next chunk).

        Filtered on the transcript's id so unrelated scroll containers
        (modal pickers, etc.) don't affect the flag.
        """
        try:
            target = getattr(event, "control", None)
            if target is None or getattr(target, "id", None) != "transcript":
                return
            virtual_height = target.virtual_size.height
            view_height = target.size.height
            scroll_y = target.scroll_y
        except Exception:  # noqa: BLE001
            return
        if virtual_height <= view_height:
            self._scroll_follow = True
            return
        max_scroll = virtual_height - view_height
        self._scroll_follow = (
            max_scroll - scroll_y
        ) <= self._SCROLL_FOLLOW_THRESHOLD

    def _is_at_bottom(
        self, container: Any = None,
    ) -> bool:
        """Whether auto-scroll-end should fire.

        Returns the cached ``_scroll_follow`` flag — updated only by
        :meth:`on_scroll` when the USER scrolls. This deliberately
        does NOT re-derive from post-mutation geometry: that path
        loses bottom affinity across bulk mounts (a multi-row tool
        result widget mounted under a user who was at the bottom
        pushes the bottom edge out of the threshold, so the helper
        wrongly concludes the user has scrolled away). The cached
        flag holds the user's actual intent regardless of how the
        content under them grew.
        """
        # ``container`` arg kept for back-compat with callers that
        # pass an explicit container; the cached flag is global to
        # the transcript so we ignore it.
        del container
        return self._scroll_follow

    def _maybe_scroll_end(
        self,
        container: Any = None,
        *,
        animate: bool = False,
    ) -> None:
        """Guarded version of ``container.scroll_end(...)``.

        Used as the canonical auto-scroll entry point so live
        streaming chunks, mid-turn renders, and queue/state repaints
        only follow when the operator hasn't scrolled away. Without
        this, every chunk on a long-running turn snaps the viewport
        back to the bottom, making it impossible to read prior turns
        until the model finishes.

        Operator submits + explicit "user is acting" events (sending
        a prompt, /new) still call ``scroll_end`` directly so the
        user's own action always brings them to the live tail; only
        the *passive* repaints route through this guard.

        Affinity caveat: by the time this fires, content has already
        been mounted/appended and ``virtual_size`` reflects the new
        layout — a user who was at the bottom right before the mount
        is no longer within the threshold. For passive flows where
        callers need "preserve bottom affinity across this update,"
        see :meth:`_scroll_end_if_was_at_bottom`. Here we accept the
        post-mount affinity check — works fine for small streaming
        chunks (single delta < 3 rows), trades correctness on bulk
        mounts (tool result cards) for a single hot-path helper that
        any call site can drop in without preceding bookkeeping.
        """
        if container is None:
            try:
                container = self.query_one(
                    "#transcript", VerticalScroll,
                )
            except Exception:  # noqa: BLE001
                return
        if not self._is_at_bottom(container):
            return
        try:
            container.scroll_end(animate=animate)
        except Exception:  # noqa: BLE001
            pass

    def _scroll_end_if_was_at_bottom(
        self,
        container: Any,
        was_at_bottom: bool,
        *,
        animate: bool = False,
    ) -> None:
        """Variant that uses a caller-captured affinity snapshot.

        Pattern:

            anchor = self._is_at_bottom(transcript)
            await transcript.mount(BigWidget())   # virtual_size jumps
            self._scroll_end_if_was_at_bottom(transcript, anchor)

        Lets passive bulk mounts (tool result cards, restored turns,
        compaction notices) preserve "follow the tail" affinity that
        ``_maybe_scroll_end`` alone can't infer post-mount.
        """
        if not was_at_bottom:
            return
        try:
            container.scroll_end(animate=animate)
        except Exception:  # noqa: BLE001
            pass

    def _refresh_status_bar(self) -> None:
        """Repaint the single consolidated ``#status-footer``.

        Order (left → right):
            <state> · agent <name> · mode <mode> · ctx <used>/<max>
              · model <alias>/<id> · upstream <ok|DOWN: …>

        Per-call detail (ttft · gen tps · wt …) lives on each
        AssistantMessage's own dim metrics row, but the footer
        carries the identity + operational fields the operator
        needs at a glance even when their eye is on the transcript:
        which agent, which mode, how full the context is, which
        model is wired, and whether the upstream is healthy.
        """
        parts: list[str] = []

        # State (always visible) + queued badge.
        # Transient acks (errors, "aborting…", "session created") go
        # to ``#status-events`` above the footer, NOT here — the
        # footer is identity + persistent state only.
        #
        # While a turn is in flight (``_worker_state`` set) prepend a
        # braille spinner frame so the user has a continuous "still
        # alive" cue even when chunks pause — the primary user-
        # reported failure mode here was "TUI looks frozen right
        # before a long tool call". The frame advances on a fast
        # timer (``_animate_status``); idle state shows no spinner.
        qn = len(self._turn_queue)
        if self._worker_state:
            frame = _SPINNER_FRAMES[
                self._anim_tick % len(_SPINNER_FRAMES)
            ]
            state_seg = f"[bold cyan]{frame}[/bold cyan] {self._worker_state}"
        else:
            state_seg = "[bold]idle[/bold]"
        if qn:
            state_seg = f"{state_seg} [yellow]+{qn} queued[/yellow]"
        parts.append(state_seg)

        # Agent name.
        parts.append(f"agent [bold]{self.agent_cfg.name}[/bold]")

        # Permission mode — colour-coded by danger level so a glance
        # at the status bar tells the operator whether the agent is in
        # a guarded mode (plan/ask) or autonomous (auto). Mapping:
        #   plan → green   (read-only, safest)
        #   ask  → yellow  (prompts before mutations)
        #   auto → red     (bypassPermissions; agent runs unrestricted)
        # Unknown modes fall through to plain bold so a typo doesn't
        # blank the indicator. ``[/]`` closes the most-recent opened
        # span — Rich's recommended form, immune to the name-matched
        # closing-tag edge cases.
        _mode_style = {
            "plan": "bold green",
            "ask": "bold yellow",
            "auto": "bold red",
        }.get(self._permission_mode, "bold")
        parts.append(f"mode: [{_mode_style}]{self._permission_mode}[/]")

        # Context used/max — pulled from the latest worker metrics
        # (``prompt_tokens`` per round) and the upstream's advertised
        # ``max_context``. Falls back to the live session's
        # ``contextWindow`` (set on /model and on session_new), then
        # to the upstream-health baseline so a fresh session before
        # any turn still shows a number.
        upstream = (self._health or {}).get("upstream") or {}
        # CLI-engine agents don't expose a usable context-window number
        # (the CLI manages its own context internally and never reports
        # token counts back to rtxclaw). The cfg-level
        # ``upstream_max_context`` is inherited from the global
        # local-LLM config and means nothing here — suppress the
        # ``ctx X/Y`` segment so the footer stops showing ``ctx —/262144``.
        _is_cli_engine = (
            (getattr(self.agent_cfg, "engine", "") or "").strip()
            in ("claude_cli", "codex_cli", "gemini_cli")
        )
        if _is_cli_engine:
            max_ctx = 0
        else:
            max_ctx = (
                self._last_context_window
                or upstream.get("max_context")
                or getattr(self.agent_cfg, "upstream_max_context", 0)
                or 0
            )
        if isinstance(max_ctx, int) and max_ctx > 0:
            if self._last_prompt_tokens is not None:
                used_disp = str(self._last_prompt_tokens)
            else:
                baseline = upstream.get("baseline_prompt_tokens")
                used_disp = (
                    f"~{baseline}"
                    if isinstance(baseline, int) and baseline > 0
                    else "\u2014"  # em dash — "no data yet"
                )
            parts.append(f"ctx {used_disp}/{max_ctx}")

        # Upstream model — alias/<model_id>. Resolution prefers the
        # live session's endpoint match against
        # ``agent_cfg.models[]``, then falls back to the configured
        # upstream alias / hostname.
        #
        # CLI-engine agents (claude/codex/gemini) don't drive an HTTP
        # upstream — the CLI itself owns the model call. The session
        # carries ``model = <engine name>`` and an empty endpoint, and
        # the inherited cfg.upstream_* fields belong to a different
        # (local-LLM) deployment. Render the engine name as-is so the
        # footer stops falsely advertising the global config's upstream
        # (e.g. ``gpu-a/qwen3.6-27b-fp8``).
        cli_engine = (getattr(self.agent_cfg, "engine", "") or "").strip()
        if cli_engine == "gemini_cli":
            # Gemini exposes a real model dimension (Auto / Pro / Flash
            # / …). Surface the selected id so the operator sees which
            # model the next turn will hit — "auto" when none picked.
            engine_name = cli_engine[:-4]  # "gemini"
            sel_alias = self._current_engine_model_alias() or "auto"
            parts.append(f"model [bold]{engine_name}/{sel_alias}[/bold]")
        elif cli_engine in ("claude_cli", "codex_cli"):
            engine_name = cli_engine[:-4]  # strip "_cli"
            parts.append(f"model [bold]{engine_name}[/bold]")
        else:
            sess_endpoint = (
                (self.session.endpoint if self.session else "")
                or upstream.get("endpoint", "")
            )
            model_id = (
                (self.session.model if self.session else "")
                or upstream.get("model")
                or ""
            )
            alias = (
                _alias_for_endpoint(
                    getattr(self.agent_cfg, "models", None),
                    sess_endpoint,
                )
                or (
                    getattr(self.agent_cfg, "upstream_alias", "")
                    if (sess_endpoint or "").rstrip("/")
                    == (self.agent_cfg.upstream_endpoint or "").rstrip("/")
                    else ""
                )
                or _hostname_of(sess_endpoint)
                or "upstream"
            )
            model_label = _model_label(alias, model_id)
            if model_label and (model_id or alias != "upstream"):
                parts.append(f"model [bold]{model_label}[/bold]")

        # Upstream status. Agent unreachable (``self._health_error``)
        # shadows everything else; otherwise we surface ``ok`` / DOWN
        # for the LLM upstream. The green ``ok`` badge is the
        # operator's at-a-glance "the model is reachable" signal.
        if self._health_error:
            parts.append(
                f"[red]agent unreachable: {self._health_error[:60]}[/red]"
            )
        elif upstream.get("ok") is False:
            err = str(upstream.get("error") or "")[:60]
            parts.append(
                f"[red]upstream DOWN{(': ' + err) if err else ''}[/red]"
            )
        elif upstream.get("ok") is True:
            # ``probed=False`` means we couldn't / wouldn't probe the
            # endpoint live (cloud providers, where every poll is a
            # paid API hit). Render a softer "cloud" badge so the
            # operator knows the green isn't a live reachability
            # signal — a real outage there surfaces as a turn-time
            # error via the ``upstream warn`` row instead.
            if upstream.get("probed") is False:
                parts.append("[dim green]upstream cloud[/dim green]")
            else:
                parts.append("[green]upstream ok[/green]")

        if self._upstream_warn:
            parts.append(f"[yellow]{self._upstream_warn}[/yellow]")

        line = "  ·  ".join(parts)
        try:
            self.query_one("#status-footer", Static).update(line)
        except Exception:  # noqa: BLE001
            # Widget may not be mounted yet on the first poll.
            pass

    def _animate_status(self) -> None:
        """Advance the footer spinner one frame while a worker is in flight.

        No-op when ``_worker_state`` is empty (idle) so the timer is
        essentially free outside an active turn. The spinner exists so
        the operator can tell the difference between "TUI is alive,
        upstream is slow or a tool is running" and "TUI is hung" —
        previously the static ``▶ streaming…`` / ``🔧 running tool``
        label gave no motion cue when chunks paused.
        """
        if not self._worker_state:
            return
        self._anim_tick += 1
        self._refresh_status_bar()

    def _set_status(self, msg: str) -> None:
        """Override: write transient acks to the events row above
        the footer.

        Transient messages (``done · …``, ``session created``,
        ``reasoning expanded``, command-failure replies, etc.) land
        on ``#status-events`` — a single row dedicated to one-shot
        feedback. The persistent ``#status-footer`` stays identity-
        only (state · agent · mode · ctx · model · upstream), so
        the operator's at-a-glance signals never wash out under
        ack noise.

        ``_turn_state`` is kept up to date so existing call sites
        that read it for diagnostic logging keep working, but it's
        no longer rendered into the footer.
        """
        self._turn_state = msg or ""
        try:
            self.query_one("#status-events", Static).update(msg or "")
        except Exception:  # noqa: BLE001
            # Widget not yet mounted (test harness, mid-compose);
            # fall through silently — the footer is repainted
            # separately and won't pick up the lost ack.
            pass

    def _set_worker_state(
        self, msg: str, *, detail: str = "",
    ) -> None:
        """Set the always-visible worker-state indicator on the footer,
        with an optional ``detail`` blurb that goes to ``#status-events``
        (the row above) instead of bleeding into the identity strip.

        Empty ``msg`` clears the footer state (turn done / nothing in
        flight). ``detail`` is the long-form transient (``mode=…  new
        session  ESC to abort``) that earlier code shoved straight into
        ``msg`` and ended up smearing the footer's `state · agent ·
        mode · ctx · model · upstream` strip into one unreadable line.
        Splitting the surfaces keeps the footer at-a-glance readable
        while the transient hint still appears (one row up).

        Call shape going forward:
            self._set_worker_state(
                "[bold green]▶ streaming…[/bold green]",
                detail="[dim]ESC to cancel[/dim]",
            )
        """
        self._worker_state = msg or ""
        # Reset the footer spinner frame whenever the state label
        # changes (``▶ streaming…`` → ``🔧 running tool: bash`` →
        # ``▶ streaming…`` …) so the operator gets a clean visual
        # restart on each phase transition rather than the spinner
        # smearing across phases at whatever frame it happened to be
        # on.
        self._anim_tick = 0
        if detail or msg:
            try:
                self.query_one("#status-events", Static).update(detail)
            except Exception:  # noqa: BLE001
                pass
        else:
            # Clearing both at once: wipe the events row too so a stale
            # "ESC to abort" detail doesn't outlive the worker state.
            try:
                self.query_one("#status-events", Static).update("")
            except Exception:  # noqa: BLE001
                pass
        self._refresh_status_bar()

    # ---- plan-checklist (footer-area widget) ---------------------------

    # Single plan per session. Claude Code's TodoWrite semantic is one
    # list whose statuses advance over time — re-emits replace the
    # current plan rather than stacking new ones. ``_plans`` stays a
    # list (length 0 or 1) for renderer continuity with prior code.

    @staticmethod
    def _plan_items(plan: dict) -> list[dict]:
        """Return the items list from a plan-group, materializing the
        legacy ``{steps:[str], cursor:int}`` shape into Claude TodoWrite
        ``{content, activeForm, status}`` dicts on the fly.

        Older plan-groups stored a flat ``steps`` list of strings plus a
        ``cursor`` int; new ones store ``items`` directly. Reading
        through this helper means the renderer + handlers don't need to
        branch on shape.
        """
        items = plan.get("items")
        if isinstance(items, list):
            return [it for it in items if isinstance(it, dict)]
        steps = plan.get("steps") or []
        cursor = max(0, min(int(plan.get("cursor") or 0), len(steps)))
        out: list[dict] = []
        for i, step in enumerate(steps):
            out.append({
                "content": str(step).strip(),
                "activeForm": "",
                "status": "completed" if i < cursor else "pending",
            })
        return out

    def _render_plan_checklist(self) -> None:
        """Repaint the persistent ``#plan-checklist`` widget.

        Each plan-group renders as its own ``📐 plan:`` block with
        per-item status: ``☑`` completed (struck-through), ``▶``
        in-progress (highlighted, uses ``activeForm`` so the row reads
        as a live verb-phrase), ``☐`` pending. Plans with every item
        completed keep showing fully struck-through so the operator can
        still scan the project narrative; the active plan is the last
        block.
        """
        try:
            widget = self.query_one("#plan-checklist", Static)
        except Exception:  # noqa: BLE001
            return
        if not self._plans:
            widget.update("")
            return
        rows: list[str] = []
        # Single-plan model: render the latest plan only. ``_plans``
        # holds at most one entry but kept as a list for legacy
        # callers and replay scaffolding.
        for plan in self._plans[-1:]:
            items = self._plan_items(plan)
            all_done = bool(items) and all(
                (it.get("status") in ("completed", "done")) for it in items
            )
            header = (
                "[bold magenta]📐 plan"
                f"{' (done)' if all_done else ''}:[/bold magenta]"
            )
            rows.append(header)
            for it in items:
                status = it.get("status") or "pending"
                content = (it.get("content") or "").strip()
                active = (it.get("activeForm") or "").strip()
                # Show the present-continuous verb-phrase while the step
                # is running — that's what Claude's spinner shows and
                # what the user wants to see during execution. Falls
                # back to `content` when activeForm is missing.
                label = active if (status == "in_progress" and active) else content
                if len(label) > 90:
                    label = label[:87] + "…"
                if status in ("completed", "done"):
                    rows.append(f"  [dim strike]☑ {label}[/dim strike]")
                elif status == "in_progress":
                    rows.append(f"  [bold cyan]▶ {label}[/bold cyan]")
                else:
                    rows.append(f"  [dim]☐[/dim] {label}")
        widget.update("\n".join(rows))

    def set_plan_checklist(self, items: list) -> None:
        """Replace the session's plan with the given items and render.

        Accepts either:
        - ``list[str]`` — legacy entry point; each string becomes
          ``{content, activeForm: "", status: "pending"}``.
        - ``list[dict]`` — Claude TodoWrite shape, ``{content,
          activeForm, status}``.

        Mirrors Claude Code's TodoWrite: a session has exactly ONE
        plan and re-emits replace its contents (status updates flow
        through ``_handle_todo_tool_call``'s in-place merge so a
        progress nudge doesn't blow away the existing list). Single-
        item "plans" are dropped — the bridge already filters at emit
        time, the TUI guards too. Capped at 12 items so a runaway
        model can't push the transcript off-screen.
        """
        norm: list[dict] = []
        for it in items:
            if isinstance(it, str):
                content = it.strip()
                if not content:
                    continue
                norm.append({
                    "content": content,
                    "activeForm": "",
                    "status": "pending",
                })
            elif isinstance(it, dict):
                content = (it.get("content") or "").strip()
                if not content:
                    continue
                status = (it.get("status") or "pending").strip().lower()
                if status not in ("pending", "in_progress", "completed", "done"):
                    status = "pending"
                norm.append({
                    "content": content,
                    "activeForm": (it.get("activeForm") or "").strip(),
                    "status": status,
                })
        if len(norm) < 2:
            return
        self._plans = [{"items": norm[:12]}]
        self._render_plan_checklist()

    def advance_plan_step(self) -> None:
        """Mark the next non-completed step on the LATEST plan-group as
        completed. No-op when the latest plan is already fully done.

        Used by the legacy ``todo complete`` action path; the new
        TodoWrite tool emits the full list with explicit per-item
        statuses, so the renderer reads those directly.
        """
        if not self._plans:
            return
        latest = self._plans[-1]
        items = self._plan_items(latest)
        if not items:
            return
        for it in items:
            if it.get("status") not in ("completed", "done"):
                it["status"] = "completed"
                latest["items"] = items
                self._render_plan_checklist()
                return

    def clear_plan_checklist(self) -> None:
        """Drop ALL plan-groups. Called on /new so a new session
        starts with a clean footer."""
        self._plans = []
        self._render_plan_checklist()

    @staticmethod
    def _normalize_todo_arg_item(it: Any) -> Optional[dict]:
        """Coerce one TodoWrite array entry into ``{content, activeForm,
        status}``. Returns ``None`` on items with no content."""
        if isinstance(it, str):
            content = it.strip()
            if not content:
                return None
            return {"content": content, "activeForm": "", "status": "pending"}
        if isinstance(it, dict):
            content = (it.get("content") or "").strip()
            if not content:
                return None
            status = str(it.get("status") or "").strip().lower()
            if status not in ("pending", "in_progress", "completed", "done"):
                status = "pending"
            active = it.get("activeForm") or it.get("active_form") or ""
            return {
                "content": content,
                "activeForm": str(active).strip(),
                "status": status,
            }
        return None

    def _upsert_harness_task(
        self,
        tid: str,
        *,
        subject: Optional[str] = None,
        status: Optional[str] = None,
    ) -> None:
        """Insert / merge a row in the harness-task footer state, then
        repaint. Status only advances forward (pending → in_progress →
        completed) so a stale TaskUpdate can't visually regress a row;
        ``deleted`` overrides everything.
        """
        tid = str(tid or "").strip()
        if not tid:
            return
        row = self._harness_tasks.get(tid)
        if row is None:
            row = {"subject": "", "status": "pending"}
            self._harness_tasks[tid] = row
            self._harness_tasks_order.append(tid)
        if subject is not None:
            sb = str(subject).strip()
            if sb:
                row["subject"] = sb
        if status is not None:
            ns = str(status).strip().lower()
            if ns == "deleted":
                row["status"] = "deleted"
            else:
                rank = {
                    "pending": 0, "in_progress": 1,
                    "completed": 2, "done": 2,
                }
                old_rank = rank.get(row.get("status") or "pending", 0)
                new_rank = rank.get(ns, 0)
                if new_rank >= old_rank:
                    row["status"] = ns
        self._render_harness_tasks()

    def _apply_task_update_args(self, args: dict) -> None:
        """Apply a ``TaskUpdate`` argument bundle to the harness-task
        footer (optimistic update at tool_call time)."""
        if not isinstance(args, dict):
            return
        tid = str(args.get("taskId") or "").strip()
        if not tid:
            return
        self._upsert_harness_task(
            tid,
            subject=args.get("subject"),
            status=args.get("status"),
        )

    def _apply_task_create_from_result(self, args: dict, result_text: str) -> None:
        """Parse the TaskCreate result body to recover the assigned id
        (``"Task #N created successfully: …"``), then upsert into the
        harness-task footer."""
        if not isinstance(args, dict):
            return
        m = re.search(r"Task\s+#(\d+)\s+created", result_text or "")
        if not m:
            return
        tid = m.group(1)
        self._upsert_harness_task(
            tid,
            subject=str(args.get("subject") or ""),
            status="pending",
        )

    def _render_subagent_counter(self) -> None:
        """Repaint the persistent ``#subagent-counter`` footer Static.
        Hidden when no subagents have run; otherwise shows ``🤖
        Subagents · N/M done [· K failed] [· in flight]`` so the
        operator sees overall fan-out progress even after individual
        boxes scroll out of the viewport.
        """
        try:
            widget = self.query_one("#subagent-counter", Static)
        except Exception:  # noqa: BLE001
            return
        if self._subagent_total == 0:
            widget.update("")
            return
        in_flight = (
            self._subagent_total
            - self._subagent_done
            - self._subagent_failed
        )
        line = (
            f"[bold magenta]🤖 Subagents · "
            f"{self._subagent_done}/{self._subagent_total} done"
        )
        if self._subagent_failed:
            line += f" · {self._subagent_failed} failed"
        if in_flight > 0:
            line += f" · {in_flight} in flight"
        line += "[/bold magenta]"
        # Navigation hint pinned beneath the counter so the operator
        # knows the SubagentBoxMessages in the transcript are
        # interactive — without it, the boxes look like passive
        # text. The hint disappears once all subagents have
        # completed (no point pointing at scrolled-off boxes).
        if in_flight > 0 or self._subagent_total <= 4:
            line += (
                "  [dim]alt+↑/alt+↓ to step · alt+Enter to open · "
                "/subagents N[/dim]"
            )
        widget.update(line)

    def _clear_harness_tasks(self) -> None:
        """Drop every row from the harness-task footer and repaint —
        called on /new, on session reset after a failed reattach, and
        whenever a fresh session-id is created (the prior session's
        tasks no longer apply). Also resets the subagent counter
        (same lifecycle)."""
        self._harness_tasks.clear()
        self._harness_tasks_order.clear()
        self._pending_task_create_calls.clear()
        self._harness_task_call_ids.clear()
        self._render_harness_tasks()
        self._subagent_total = 0
        self._subagent_done = 0
        self._subagent_failed = 0
        self._render_subagent_counter()

    def _render_harness_tasks(self) -> None:
        """Repaint the persistent ``#harness-tasks`` footer Static.

        Hidden via empty content when no tasks exist (``height: auto``
        collapses the row). When tasks are present, renders a header
        line with progress (``📋 Tasks · N/M done``) followed by one
        row per task with status icon + id + subject.
        """
        try:
            widget = self.query_one("#harness-tasks", Static)
        except Exception:  # noqa: BLE001
            return
        if not self._harness_tasks:
            widget.update("")
            return
        done = sum(
            1 for r in self._harness_tasks.values()
            if r.get("status") in ("completed", "done")
        )
        total = len(self._harness_tasks)
        rows: list[str] = [
            f"[bold blue]📋 Tasks · {done}/{total} done:[/bold blue]"
        ]
        for tid in self._harness_tasks_order:
            r = self._harness_tasks.get(tid)
            if not r:
                continue
            label = (r.get("subject") or "").strip()
            if len(label) > 90:
                label = label[:87] + "…"
            status = r.get("status") or "pending"
            if status in ("completed", "done"):
                rows.append(
                    f"  [dim strike]☑ #{tid} {label}[/dim strike]"
                )
            elif status == "in_progress":
                rows.append(
                    f"  [bold cyan]▶ #{tid} {label}[/bold cyan]"
                )
            elif status == "deleted":
                rows.append(
                    f"  [red]✗[/red] [dim]#{tid} {label}[/dim]"
                )
            else:
                rows.append(f"  [dim]☐[/dim] [bold]#{tid}[/bold] {label}")
        widget.update("\n".join(rows))

    def _is_harness_task_tool(self, name: str) -> bool:
        return name in (
            "TaskCreate",
            "TaskUpdate",
            "TaskList",
            "TaskGet",
            "TaskOutput",
            "TaskStop",
        )

    def _subagent_sidecar_path(self, call_id: str) -> Optional[Any]:
        """Path for a per-subagent run capture file.

        Pattern: ``<sessions_dir>/<sid>.subagent.<call_id>.json``.
        Holds the full prompt + result so the operator can re-read a
        subagent's run after it finishes (the cloud ``Agent`` tool
        returns only one final result text; without this sidecar the
        intermediate "what did I ask the subagent" is lost the moment
        it scrolls off the transcript). Independent from the
        ``<sid>.delegate_*.json`` sidecars rtxclaw's bridges write,
        which are keyed by subagent kind rather than call id.
        """
        sid = getattr(self, "_sid", None)
        if not sid or not call_id:
            return None
        try:
            from pathlib import Path as _Path
            sdir = _Path(self.agent_cfg.sessions_dir)
        except Exception:  # noqa: BLE001
            return None
        return sdir / f"{sid}.subagent.{call_id}.json"

    def _persist_subagent_call(
        self,
        call_id: str,
        tool_name: str,
        args: Any,
    ) -> None:
        """Write the start-of-run record for a subagent call. Called
        from the tool_call dispatch — captures args + a timestamp so
        the result-write later can compute elapsed time. Best-effort;
        any I/O failure is swallowed so it never breaks the live
        stream."""
        path = self._subagent_sidecar_path(call_id)
        if path is None:
            return
        try:
            import json as _json
            import time as _time
            payload = {
                "call_id": call_id,
                "tool": tool_name,
                "args": args if isinstance(args, dict) else {},
                "status": "running",
                "ts_start": _time.time(),
                "ts_start_iso": _time.strftime(
                    "%Y-%m-%dT%H:%M:%S",
                    _time.localtime(),
                ),
            }
            path.parent.mkdir(parents=True, exist_ok=True)
            tmp = path.with_name(f".{path.name}.tmp")
            tmp.write_text(
                _json.dumps(payload, indent=2, ensure_ascii=False) + "\n",
                encoding="utf-8",
            )
            tmp.replace(path)
        except Exception:  # noqa: BLE001
            pass

    def _persist_subagent_result(
        self,
        call_id: str,
        ok: bool,
        content: str,
    ) -> None:
        """Append the result record to the subagent sidecar. Reads the
        existing start-of-run payload, merges in the result + elapsed
        time, and rewrites the file atomically."""
        path = self._subagent_sidecar_path(call_id)
        if path is None or not path.exists():
            return
        try:
            import json as _json
            import time as _time
            payload = _json.loads(path.read_text(encoding="utf-8"))
            ts_end = _time.time()
            payload["ts_end"] = ts_end
            payload["ts_end_iso"] = _time.strftime(
                "%Y-%m-%dT%H:%M:%S",
                _time.localtime(ts_end),
            )
            ts_start = payload.get("ts_start") or ts_end
            payload["elapsed_s"] = round(float(ts_end) - float(ts_start), 3)
            payload["ok"] = bool(ok)
            payload["status"] = "done" if ok else "error"
            payload["result"] = content or ""
            tmp = path.with_name(f".{path.name}.tmp")
            tmp.write_text(
                _json.dumps(payload, indent=2, ensure_ascii=False) + "\n",
                encoding="utf-8",
            )
            tmp.replace(path)
        except Exception:  # noqa: BLE001
            pass

    def _is_delegate_tool(self, name: str) -> bool:
        # ``Agent`` is Claude Code's native subagent primitive (returns
        # a single final result text rather than streaming inner
        # events) — it still benefits from the bordered-box treatment
        # so a parent can visually distinguish "this came from a
        # subagent run" from its own parallel Bash/Read/Edit calls,
        # which was the original complaint.
        return name in (
            "Agent",
            "delegate_claude",
            "delegate_codex",
            "delegate_gemini",
            "delegate_agent",
        )

    def _mount_target(self, transcript: Any) -> Any:
        """If a subagent box is on the stack, route inner mounts there
        so the subagent's events nest visually under its container.
        Otherwise mount into the parent transcript."""
        if self._subagent_box_stack:
            return self._subagent_box_stack[-1].body
        return transcript

    def _delegate_summary(self, name: str, args: dict) -> tuple[str, str]:
        """Pretty label + short task summary for a delegate_* call.
        ``label`` reads in the subagent-box header (e.g.
        ``claude · qwen-coder``), ``summary`` is the truncated prompt."""
        label = ""
        if name == "delegate_claude":
            label = "claude"
        elif name == "delegate_codex":
            label = "codex"
        elif name == "delegate_gemini":
            label = "gemini"
        elif name == "delegate_agent":
            target = ""
            if isinstance(args, dict):
                target = str(args.get("name") or args.get("agent") or "")
            label = f"agent · {target}" if target else "agent"
        elif name == "Agent":
            # Claude Code's native Agent tool: subagent_type is the
            # canonical "what kind of subagent" label.
            stype = ""
            if isinstance(args, dict):
                stype = str(args.get("subagent_type") or "")
            label = f"agent · {stype}" if stype else "agent"
        else:
            label = name
        summary = ""
        if isinstance(args, dict):
            for k in ("task", "prompt", "description"):
                v = args.get(k)
                if isinstance(v, str) and v.strip():
                    summary = v.strip().splitlines()[0]
                    break
        return label, summary

    def _handle_todo_tool_call(self, args: dict) -> None:
        """Update the plan-checklist in response to a model-emitted
        ``TodoWrite`` tool call.

        Two arg shapes are accepted:

        1. **Claude TodoWrite** (current): ``todos: [{content,
           activeForm, status}]`` — the whole list with per-item
           status. ``status ∈ {pending, in_progress, completed}`` and
           ``activeForm`` is the present-continuous verb-phrase shown
           in the renderer while a step is running.
        2. **Legacy rtxclaw todo**: ``action`` ∈ {replace, add,
           complete, delete, list} with ``items`` / ``indexes``. Kept
           for older callers.

        Best-effort: malformed args never tank the prompt loop; the
        runner returns its own error to the model and the TUI keeps the
        previous plan-group state.
        """
        try:
            todos_arg = args.get("todos")
            if isinstance(todos_arg, list) and "action" not in args:
                action = "replace"
                items_in: list[Any] = list(todos_arg)
                indexes: list[Any] = []
            else:
                action = str(args.get("action") or "").strip().lower()
                items_in = list(args.get("items") or [])
                indexes = list(args.get("indexes") or [])

            if action == "replace":
                norm = [
                    n for n in (self._normalize_todo_arg_item(it) for it in items_in)
                    if n is not None
                ]
                if not norm:
                    return
                # When the model re-emits a `replace` whose content list
                # matches the latest in-flight plan-group, merge in
                # place — update statuses + activeForm rather than
                # appending a duplicate group. Without this the TUI
                # would show a second copy of the plan every round the
                # model nudges the list (e.g. flipping one item from
                # pending → in_progress).
                # Single-plan semantics: if the existing plan's content
                # set overlaps the new emit (ignoring order — Gemma 4
                # likes to reshuffle completed rows to the top each
                # round), merge in place and only forward-advance
                # statuses (pending → in_progress → completed) so a
                # stale re-emit can't visually regress a row. Otherwise
                # the new list replaces the plan outright.
                merged = False
                if self._plans and norm:
                    latest_items = self._plan_items(self._plans[-1])
                    old_set = {it.get("content") for it in latest_items}
                    new_set = {n["content"] for n in norm}
                    overlap = old_set & new_set
                    # "Same plan" if the new list is the same set of
                    # items OR a subset/superset that significantly
                    # overlaps — covers the "model dropped one item"
                    # and "model added one item" mid-plan tweaks.
                    if latest_items and overlap and (
                        old_set == new_set
                        or len(overlap) >= max(len(old_set), len(new_set)) - 1
                    ):
                        rank = {
                            "pending": 0, "in_progress": 1,
                            "completed": 2, "done": 2,
                        }
                        old_by_content = {
                            it.get("content"): it for it in latest_items
                        }
                        merged_items: list[dict] = []
                        for n in norm:
                            old = old_by_content.get(n["content"], {})
                            old_rank = rank.get(old.get("status") or "pending", 0)
                            new_rank = rank.get(n.get("status") or "pending", 0)
                            chosen = n if new_rank >= old_rank else old
                            merged_items.append({
                                "content": n["content"],
                                "activeForm": n.get("activeForm")
                                              or old.get("activeForm") or "",
                                "status": chosen.get("status") or "pending",
                            })
                        self._plans[-1] = {"items": merged_items}
                        self._render_plan_checklist()
                        merged = True
                if not merged:
                    self.set_plan_checklist(norm)
            elif action == "add":
                extra = [
                    n for n in (self._normalize_todo_arg_item(it) for it in items_in)
                    if n is not None
                ]
                if not extra:
                    return
                if not self._plans:
                    # `add` with no active plan implicitly creates one.
                    # Mirrors the runner's behaviour.
                    self.set_plan_checklist(extra)
                    return
                latest = self._plans[-1]
                cur = self._plan_items(latest)
                room = max(0, 12 - len(cur))
                cur.extend(extra[:room])
                latest["items"] = cur
                latest.pop("steps", None)
                latest.pop("cursor", None)
                self._render_plan_checklist()
            elif action == "complete":
                if not self._plans:
                    return
                latest = self._plans[-1]
                cur = self._plan_items(latest)
                if not cur:
                    return
                idx_set = {
                    int(i) for i in indexes
                    if isinstance(i, (int, float)) and not isinstance(i, bool)
                }
                for i, it in enumerate(cur):
                    if i in idx_set and it.get("status") not in ("completed", "done"):
                        it["status"] = "completed"
                latest["items"] = cur
                latest.pop("steps", None)
                latest.pop("cursor", None)
                self._render_plan_checklist()
            elif action == "delete":
                if not self._plans:
                    return
                latest = self._plans[-1]
                cur = self._plan_items(latest)
                if not cur:
                    return
                drop = {
                    int(i) for i in indexes
                    if isinstance(i, (int, float)) and not isinstance(i, bool)
                }
                kept = [it for i, it in enumerate(cur) if i not in drop]
                latest["items"] = kept
                latest.pop("steps", None)
                latest.pop("cursor", None)
                self._render_plan_checklist()
            # action=list is read-only — don't touch state.
        except Exception:  # noqa: BLE001
            # Best-effort UI sync; never let a malformed args dict
            # take down the prompt loop.
            pass

    # ---- prompt / /claude / /codex / /gemini queue --------------------

    def _is_busy(self) -> bool:
        """True iff a turn (local model, /claude, /codex, or /gemini) is in flight."""
        return (
            self._current_turn_id is not None
            or self._claude_turn_id is not None
            or self._codex_turn_id is not None
            or self._gemini_turn_id is not None
        )

    def _enqueue_or_run(self, kind: str, payload: str) -> None:
        """Enqueue a prompt / /claude / /codex call, or run immediately if idle.

        `kind` ∈ {"prompt", "claude", "codex", "gemini"}. Always
        returns synchronously; the actual work runs as a background
        Textual worker.

        Mid-turn injection — when ``kind == "prompt"`` and a *native*
        rtxclaw turn is already streaming on this sid (i.e. no
        delegated /claude / /codex / /gemini bridge is running), the
        new prompt skips the local queue and gets pushed straight to
        the agent's inject buffer via ``session/inject_user_message``.
        The engine drains injects at every round boundary so the
        steering message lands at the next worker spawn — no waiting
        for the multi-round plan to terminate. The queue stays for
        the delegated-bridge / pre-turn-startup cases where the
        agent can't accept mid-flight steering.
        """
        if kind == "prompt" and self._can_inject_mid_turn() and not self._turn_queue:
            self.run_worker(
                self._inject_user_message_via_acp(payload),
                exclusive=False,
                name="inject-user-msg",
            )
            return
        if self._is_busy() or self._turn_queue:
            self._turn_queue.append((kind, payload))
            self._refresh_status_bar()  # show "+N queued" badge
            self._refresh_queue_display()
            self._set_status(
                f"queued ({len(self._turn_queue)} pending) — "
                f"will run when current turn finishes"
            )
            return
        self._start_turn_now(kind, payload)

    def _can_inject_mid_turn(self) -> bool:
        """True iff a native rtxclaw turn is streaming and no delegated
        bridge (/claude / /codex / /gemini) is in flight.

        Injecting only makes sense when the engine running ``run_turn``
        is the local LLM — delegated CLI bridges drive their own
        round loops outside the agent and can't be re-steered without
        aborting.
        """
        if self._client is None or self._sid is None:
            return False
        if self._current_turn_id is None:
            return False
        if (
            self._claude_turn_id is not None
            or self._codex_turn_id is not None
            or self._gemini_turn_id is not None
        ):
            return False
        return True

    async def _inject_user_message_via_acp(self, text: str) -> None:
        """Push a mid-turn user message + render it inline in the transcript.

        Mounts a UserMessage immediately so the operator sees their
        steering input land, then fires the ACP call. On failure
        falls back to the local turn queue so the message isn't lost.
        """
        text = (text or "").strip()
        if not text:
            return
        transcript = self.query_one("#transcript", VerticalScroll)
        await transcript.mount(UserMessage(f"❯ {text}"))
        await transcript.mount(Static(
            "↳ injected mid-turn — will steer at next round boundary",
            classes="claude-msg",
        ))
        # User-action scroll: the operator just submitted, so they
        # explicitly want to see their input at the bottom regardless
        # of where the read-back scroll position was. Re-arm
        # follow-mode so subsequent passive deltas keep auto-
        # scrolling instead of holding the now-stale read-back
        # affinity.
        self._scroll_follow = True
        transcript.scroll_end(animate=False)
        try:
            ack = await self._client.inject_user_message(self._sid, text)
        except Exception as e:  # noqa: BLE001
            ack = {"ok": False, "error": str(e)}
        if not ack.get("ok"):
            # Engine doesn't support injection (e.g. older gateway) or
            # the call errored. Fall back to the post-turn queue.
            self._turn_queue.append(("prompt", text))
            self._refresh_status_bar()
            self._refresh_queue_display()
            self._set_status(
                f"inject not available ({ack.get('error') or ack.get('reason')}) "
                "— message queued for after the current turn"
            )
            return
        self._set_status("↳ injected — will land at next round boundary")

    def action_queue_focus_prev(self) -> None:
        """``Ctrl+Up`` — move focus to the queue (or up within it).

        When the queue widget already has focus we let Textual's
        ListView handle the Up navigation natively (highlighting the
        previous row). When focus is elsewhere we hop into the queue
        and select the last row — the operator's "edit the prompt I
        just queued" muscle memory.
        """
        try:
            qview = self.query_one("#queue", ListView)
        except Exception:  # noqa: BLE001
            return
        if not self._turn_queue:
            return
        if qview.styles.display == "none":
            return
        if self.focused is qview:
            qview.action_cursor_up()
            return
        qview.focus()
        # Pick the last row so the most-recently-queued entry is on
        # top of the cursor — matches the "I just queued this and
        # want to fix it" workflow better than highlighting [0].
        qview.index = len(self._turn_queue) - 1

    def action_queue_focus_next(self) -> None:
        """``Ctrl+Down`` — move focus to the queue (or down within it).

        Symmetric to :meth:`action_queue_focus_prev`: from outside the
        queue we focus and select [0]; inside we forward Down to
        ListView so it scrolls one entry.
        """
        try:
            qview = self.query_one("#queue", ListView)
        except Exception:  # noqa: BLE001
            return
        if not self._turn_queue:
            return
        if qview.styles.display == "none":
            return
        if self.focused is qview:
            qview.action_cursor_down()
            return
        qview.focus()
        qview.index = 0

    def action_subagent_focus_prev(self) -> None:
        """``alt+up`` — step the subagent-box focus cursor up by one,
        scroll the focused box into view, and stamp a CSS class on it
        so the operator can see which one is selected. Wraps to the
        last box when cursor is on the first.
        """
        self._step_subagent_focus(-1)

    def action_subagent_focus_next(self) -> None:
        """``alt+down`` — symmetric to :meth:`action_subagent_focus_prev`,
        stepping forward through the subagent boxes."""
        self._step_subagent_focus(+1)

    def _step_subagent_focus(self, delta: int) -> None:
        try:
            transcript = self.query_one("#transcript", VerticalScroll)
        except Exception:  # noqa: BLE001
            return
        boxes = list(transcript.query(SubagentBoxMessage))
        if not boxes:
            self._set_status("no subagents to navigate")
            return
        cur = getattr(self, "_subagent_focus_idx", -1)
        if cur < 0 or cur >= len(boxes):
            new_idx = 0 if delta > 0 else len(boxes) - 1
        else:
            new_idx = (cur + delta) % len(boxes)
        # Clear the old highlight before stamping the new one so two
        # boxes don't appear focused after a step.
        for b in boxes:
            try:
                b.remove_class("subagent-box-focused")
            except Exception:  # noqa: BLE001
                pass
        target = boxes[new_idx]
        try:
            target.add_class("subagent-box-focused")
        except Exception:  # noqa: BLE001
            pass
        # Scroll the focused box into view; ``animate=False`` so the
        # cursor feels snappy when the operator alt+down-mashes through
        # a long subagent list.
        try:
            transcript.scroll_to_widget(target, animate=False)
        except Exception:  # noqa: BLE001
            pass
        self._subagent_focus_idx = new_idx
        self._set_status(
            f"subagent {new_idx + 1}/{len(boxes)} focused "
            f"(alt+enter to open)"
        )

    def action_subagent_open(self) -> None:
        """``alt+enter`` — pop a modal showing the focused subagent's
        sidecar JSON (prompt + tool args + result + elapsed). When no
        subagent is focused, prints a hint to the status row instead
        of opening a blank modal."""
        try:
            transcript = self.query_one("#transcript", VerticalScroll)
        except Exception:  # noqa: BLE001
            return
        boxes = list(transcript.query(SubagentBoxMessage))
        if not boxes:
            self._set_status("no subagents to open")
            return
        idx = getattr(self, "_subagent_focus_idx", -1)
        if idx < 0 or idx >= len(boxes):
            self._set_status(
                "no subagent focused — alt+up / alt+down first"
            )
            return
        target_box = boxes[idx]
        call_id = next(
            (
                cid for cid, b in self._subagent_boxes_by_call.items()
                if b is target_box
            ),
            None,
        )
        # Even after the run finalizes the box stays mounted but the
        # call_id mapping is popped. Fall back to a sequential scan of
        # the sessions dir for the Nth subagent sidecar.
        sidecar_path = None
        if call_id:
            sidecar_path = self._subagent_sidecar_path(call_id)
        if sidecar_path is None or not sidecar_path.exists():
            try:
                from pathlib import Path as _Path
                sdir = _Path(self.agent_cfg.sessions_dir)
                sid = getattr(self, "_sid", None) or ""
                candidates = sorted(
                    sdir.glob(f"{sid}.subagent.*.json"),
                    key=lambda p: p.stat().st_mtime,
                )
                if 0 <= idx < len(candidates):
                    sidecar_path = candidates[idx]
            except Exception:  # noqa: BLE001
                sidecar_path = None
        if sidecar_path is None or not sidecar_path.exists():
            self._set_status(
                f"subagent {idx + 1}: no sidecar file yet "
                "(it may still be running)"
            )
            return
        # Run the inline /subagents-style viewer as a worker so the
        # mount + status updates happen on the right loop.
        self.run_worker(
            self._render_subagent_sidecar(sidecar_path, idx + 1),
            exclusive=False,
            name="subagent-open",
        )

    async def _render_subagent_sidecar(
        self,
        path: Any,
        n: int,
    ) -> None:
        """Mount a Static card showing the focused subagent's sidecar
        contents (description + prompt + result + elapsed). Lives in
        the same transcript as the prompts so it scrolls naturally;
        no modal, no extra dependencies.
        """
        try:
            transcript = self.query_one("#transcript", VerticalScroll)
        except Exception:  # noqa: BLE001
            return
        try:
            import json as _json
            data = _json.loads(path.read_text(encoding="utf-8"))
        except Exception as e:  # noqa: BLE001
            await transcript.mount(Static(
                f"error reading subagent sidecar: {e}",
                classes="claude-msg",
            ))
            return
        from rich.markup import escape as _esc
        args = data.get("args") or {}
        desc = str(
            args.get("description")
            or args.get("task")
            or args.get("name")
            or "(no description)"
        )
        prompt = str(args.get("prompt") or "")
        tool = data.get("tool") or "agent"
        status = data.get("status") or "?"
        elapsed = data.get("elapsed_s")
        result = data.get("result") or ""
        head = (
            f"[bold cyan]🤖 Subagent {n} · {tool} · {status}"
            f"{f' · {elapsed}s' if elapsed is not None else ''}[/bold cyan]\n"
            f"[bold]{_esc(desc)}[/bold]\n"
        )
        body_parts: list[str] = [head]
        if prompt:
            body_parts.append(
                f"\n[dim]── prompt ─────────────[/dim]\n{_esc(prompt[:4000])}"
            )
            if len(prompt) > 4000:
                body_parts.append(
                    f"\n[dim](… +{len(prompt) - 4000} chars truncated)[/dim]"
                )
        if result:
            body_parts.append(
                f"\n\n[dim]── result ─────────────[/dim]\n{_esc(result[:4000])}"
            )
            if len(result) > 4000:
                body_parts.append(
                    f"\n[dim](… +{len(result) - 4000} chars truncated)[/dim]"
                )
        body_parts.append(
            f"\n\n[dim]sidecar: {_esc(str(path))}[/dim]"
        )
        await transcript.mount(Static(
            "".join(body_parts),
            classes="claude-msg",
            markup=True,
        ))
        try:
            transcript.scroll_end(animate=False)
        except Exception:  # noqa: BLE001
            pass

    def on_key(self, event) -> None:  # noqa: ANN001
        """Queue-focused shortcuts: Escape returns to input; Delete
        removes the highlighted row WITHOUT pulling it back into the
        input (a quick "discard" path); Shift+Up / Shift+Down swap
        the highlighted row with the neighbor (priority reordering
        without leaving the keyboard).
        """
        try:
            qview = self.query_one("#queue", ListView)
        except Exception:  # noqa: BLE001
            return
        if self.focused is not qview:
            return
        idx = qview.index
        if idx is None or idx < 0 or idx >= len(self._turn_queue):
            return
        if event.key == "escape":
            try:
                self.query_one(MessageInput).focus()
            except Exception:  # noqa: BLE001
                pass
            event.stop()
            return
        if event.key == "delete":
            del self._turn_queue[idx]
            self._refresh_queue_display()
            self._refresh_status_bar()
            self._set_status(
                f"dropped queue entry — {len(self._turn_queue)} remaining"
            )
            event.stop()
            return
        if event.key == "shift+up" and idx > 0:
            self._turn_queue[idx - 1], self._turn_queue[idx] = (
                self._turn_queue[idx], self._turn_queue[idx - 1],
            )
            self._refresh_queue_display()
            qview.index = idx - 1
            event.stop()
            return
        if event.key == "shift+down" and idx < len(self._turn_queue) - 1:
            self._turn_queue[idx + 1], self._turn_queue[idx] = (
                self._turn_queue[idx], self._turn_queue[idx + 1],
            )
            self._refresh_queue_display()
            qview.index = idx + 1
            event.stop()
            return

    def _refresh_queue_display(self) -> None:
        """Repaint the queued-messages ListView from `_turn_queue`.

        Hides the widget while empty so it takes no vertical space; shows
        and rebuilds the rows on every queue mutation. Each row renders
        `[kind] payload` truncated to one line — selecting a row pulls
        the text back into the input for editing (handled in
        `on_list_view_selected`).
        """
        try:
            qview = self.query_one("#queue", ListView)
        except Exception:  # noqa: BLE001
            return
        if not self._turn_queue:
            qview.styles.display = "none"
            qview.clear()
            return
        qview.clear()
        for i, (kind, payload) in enumerate(self._turn_queue):
            preview = payload.replace("\n", " ").strip()
            if len(preview) > 200:
                preview = preview[:197] + "…"
            tag = kind if kind in ("claude", "codex") else "prompt"
            row = f"[{i + 1}] [{tag}] {preview}"
            qview.append(ListItem(Static(row, markup=False)))
        qview.styles.display = "block"

    def on_list_view_selected(self, event) -> None:  # noqa: ANN001
        """Click / Enter on a queued row → pull text back into the input.

        Removes the entry from `_turn_queue` and places its payload into
        the message input so the user can edit and resubmit (or just
        clear it). Filters by widget id so it doesn't fire on unrelated
        ListViews mounted elsewhere.
        """
        try:
            lv = event.list_view
        except AttributeError:
            return
        if getattr(lv, "id", None) != "queue":
            return
        idx = lv.index
        if idx is None or idx < 0 or idx >= len(self._turn_queue):
            return
        kind, payload = self._turn_queue[idx]
        del self._turn_queue[idx]
        self._refresh_queue_display()
        self._refresh_status_bar()
        try:
            inp = self.query_one(MessageInput)
            if kind == "claude":
                prefix = "/claude "
            elif kind == "codex":
                prefix = "/codex "
            elif kind == "gemini":
                prefix = "/gemini "
            else:
                prefix = ""
            inp.value = f"{prefix}{payload}"
            inp.focus()
        except Exception:  # noqa: BLE001
            pass
        self._set_status(f"unqueued — {len(self._turn_queue)} still pending")

    def _start_turn_now(self, kind: str, payload: str) -> None:
        """Spawn the worker for a queued (or directly submitted) entry."""
        if kind == "prompt":
            self.run_worker(
                self._send_user_turn(payload),
                exclusive=False,
                name="user-turn",
            )
        elif kind == "claude":
            self.run_worker(
                self._run_claude(payload),
                exclusive=False,
                name="claude",
            )
        elif kind == "codex":
            self.run_worker(
                self._run_codex(payload),
                exclusive=False,
                name="codex",
            )
        elif kind == "gemini":
            self.run_worker(
                self._run_gemini(payload),
                exclusive=False,
                name="gemini",
            )

    def _maybe_start_next(self) -> None:
        """End-of-turn hook: drain one queued entry, if any.

        Called from the `finally` blocks of `_stream_via_agent` and
        `_run_claude` after they've cleared `_current_turn_id` /
        `_claude_turn_id`. Pops one entry, repaints, and starts it. The
        repaint matters even when the queue is empty: clearing the
        `+N queued` badge.
        """
        self._refresh_status_bar()
        self._refresh_queue_display()
        if self._is_busy():
            return  # another turn is somehow still running; will retry
        if not self._turn_queue:
            return
        kind, payload = self._turn_queue.popleft()
        self._refresh_queue_display()
        self._start_turn_now(kind, payload)

    async def _on_exit_flush(self) -> None:
        """No-op on TUI close. The agent runtime persists every turn
        end-to-end already, so there's nothing to flush here. Memory
        curation is the model's job (OpenClaw-style: it edits MEMORY.md
        when it has something worth keeping), not the TUI's.
        """
        return

    async def _cmd_new(self) -> None:
        if self._current_turn_id is not None:
            await self.action_abort(via="new")
        transcript = self.query_one("#transcript", VerticalScroll)
        await transcript.remove_children()
        # Force a fresh session by clearing the current id, then go through
        # _ensure_session so we get the same retry/health-render behaviour.
        self._sid = None
        # The /claude bridge is per-rtxclaw-session: a new session means
        # a new Claude --resume thread (no prior id) and zero synced turns.
        self._claude_session_id = None
        self._claude_synced_turn_idx = 0
        # /codex bridge is also per-rtxclaw-session — same reset rule.
        self._codex_thread_id = None
        self._codex_synced_turn_idx = 0
        # Reset context tracking so the status bar doesn't show stale
        # token counts from the previous session.
        self._last_prompt_tokens = None
        self._last_context_window = None
        # Clear the persistent plan-checklist so the bottom-of-TUI
        # row doesn't carry over stale steps from the prior session.
        self.clear_plan_checklist()
        # Same treatment for the harness-task footer: a new session
        # starts at task #1 again, and any stale rows from the prior
        # session would be confusing.
        self._clear_harness_tasks()
        if not await self._ensure_session():
            return
        self._set_status(f"new session [{self.session.hash}]")

    async def _cmd_agents(self) -> None:
        """``/agents`` — list configured agents under
        ``~/.rtxclaw/agents/<name>/config.json`` with a marker for the
        currently-active one. Use ``/agent <name>`` to switch.
        """
        transcript = self.query_one("#transcript", VerticalScroll)
        await transcript.mount(UserMessage("❯ /agents"))
        agents_root = Path.home() / ".rtxclaw" / "agents"
        if not agents_root.is_dir():
            await transcript.mount(Static(
                "no agents configured at ~/.rtxclaw/agents/",
                classes="claude-msg",
            ))
            return
        rows: list[str] = []
        current = self.agent_cfg.name
        for entry in sorted(agents_root.iterdir()):
            if not entry.is_dir():
                continue
            if not (entry / "config.json").is_file():
                continue
            mark = "●" if entry.name == current else " "
            # Pull a friendly description: engine kind + upstream
            # alias for local-LLM agents, or just the engine kind
            # tag for CLI-engine agents. Cheap read, never blocks.
            engine_kind = "local_llm"
            try:
                from rtxclaw_core.agent import AgentConfig
                cfg = AgentConfig.load(entry.name)
                engine_kind = (
                    getattr(cfg, "engine", "") or "local_llm"
                )
                if engine_kind == "local_llm":
                    hint = (
                        getattr(cfg, "upstream_alias", "")
                        or getattr(cfg, "upstream_endpoint", "")
                        or "—"
                    )
                else:
                    # CLI-engine agents (claude_cli / codex_cli /
                    # gemini_cli) — show the engine tag, not an
                    # upstream URL.
                    hint = f"engine={engine_kind}"
            except Exception:  # noqa: BLE001
                hint = "—"
            rows.append(
                f"  [bold]{mark}[/bold]  {entry.name:<16}  "
                f"[dim]{hint}[/dim]"
            )
        if not rows:
            await transcript.mount(Static(
                "no agents found (no <name>/config.json directories)",
                classes="claude-msg",
            ))
            return
        # Mix of Rich-markup chrome (bold/dim) + plain text — render
        # via ``Static(markup=True)``, NOT RichMarkdown, since Markdown
        # passes through ``[bold]...[/bold]`` as literal text.
        body = (
            f"[bold]configured agents[/bold]  "
            f"(current: [bold cyan]{current}[/bold cyan]; "
            f"[dim]/agent <name> to switch[/dim])\n\n"
            + "\n".join(rows)
        )
        await transcript.mount(Static(
            body, classes="claude-msg", markup=True,
        ))

    async def _cmd_task(self, arg: str = "") -> None:
        """``/task <verb> [args]`` — operator-side steering of the
        harness-task footer + on-disk task store. Lets the operator
        add / mark / delete tasks directly without going through the
        model.

        Verbs:
          ``/task add <subject>``            create
          ``/task in <N>``                   flip N → in_progress
          ``/task done <N>``                 flip N → completed
          ``/task del <N>``                  remove N
          ``/task list``  (or just /task)    print current
          ``/task help``                     this help
        """
        from rich.markup import escape as _esc
        transcript = self.query_one("#transcript", VerticalScroll)
        await transcript.mount(UserMessage(
            "❯ /task" + (f" {arg}" if arg else "")
        ))
        sid = getattr(self, "_sid", None)
        if not sid:
            await transcript.mount(Static(
                "no active session — start one before /task",
                classes="claude-msg",
            ))
            return

        # Resolve the on-disk task-store path. Mirrors the runner's
        # ``_tasks_path_from_env`` resolution but uses the TUI's
        # agent config (which knows ``sessions_dir`` directly).
        from pathlib import Path as _Path
        sessions_dir = _Path(self.agent_cfg.sessions_dir)
        task_path = sessions_dir / f"{sid}.tasks.json"

        def _load() -> dict:
            if not task_path.exists():
                return {"next_id": 1, "tasks": {}}
            try:
                d = json.loads(task_path.read_text(encoding="utf-8"))
            except Exception:  # noqa: BLE001
                return {"next_id": 1, "tasks": {}}
            if not isinstance(d, dict):
                return {"next_id": 1, "tasks": {}}
            d.setdefault("tasks", {})
            d.setdefault(
                "next_id",
                max(
                    (int(k) for k in d["tasks"].keys() if str(k).isdigit()),
                    default=0,
                ) + 1,
            )
            return d

        def _save(state: dict) -> None:
            task_path.parent.mkdir(parents=True, exist_ok=True)
            tmp = task_path.with_name(f".{task_path.name}.tmp")
            tmp.write_text(
                json.dumps(state, indent=2, ensure_ascii=False) + "\n",
                encoding="utf-8",
            )
            tmp.replace(task_path)

        def _render_list() -> str:
            rows: list[str] = ["[bold blue]📋 Tasks[/bold blue]"]
            for tid in self._harness_tasks_order:
                r = self._harness_tasks.get(tid)
                if not r:
                    continue
                status = r.get("status") or "pending"
                subj = (r.get("subject") or "").strip()
                icon = {
                    "pending": "[dim]☐[/dim]",
                    "in_progress": "[bold cyan]▶[/bold cyan]",
                    "completed": "[dim strike]☑[/dim strike]",
                    "deleted": "[red]✗[/red]",
                }.get(status, "?")
                if status in ("completed", "deleted"):
                    rows.append(f"  {icon} [dim strike]#{tid} {_esc(subj)}[/dim strike]")
                else:
                    rows.append(f"  {icon} [bold]#{tid}[/bold] {_esc(subj)}")
            return "\n".join(rows) if len(rows) > 1 else "[dim](no tasks)[/dim]"

        parts = arg.split(None, 1) if arg else []
        verb = parts[0].lower() if parts else "list"
        rest = parts[1] if len(parts) > 1 else ""

        if verb in ("", "list", "ls"):
            await transcript.mount(Static(
                _render_list(), markup=True, classes="claude-msg",
            ))
            return

        if verb in ("help", "?", "h"):
            await transcript.mount(Static(
                "[bold]/task[/bold] — operator-side task steering\n"
                "  [bold]/task add[/bold] <subject>      append a new task\n"
                "  [bold]/task in[/bold] <N>             flip N → in_progress\n"
                "  [bold]/task done[/bold] <N>           flip N → completed\n"
                "  [bold]/task del[/bold] <N>            delete task N\n"
                "  [bold]/task list[/bold]               print tasks (default)\n"
                "[dim]Changes are mirrored to "
                f"{_esc(str(task_path))} so the model's TaskList call "
                "sees them on the next round.[/dim]",
                classes="claude-msg", markup=True,
            ))
            return

        if verb == "add":
            subject = rest.strip()
            if not subject:
                await transcript.mount(Static(
                    "usage: /task add <subject>",
                    classes="claude-msg",
                ))
                return
            state = _load()
            tid = str(state["next_id"])
            state["next_id"] = int(tid) + 1
            state["tasks"][tid] = {
                "id": int(tid),
                "subject": subject,
                "description": "",
                "activeForm": "",
                "status": "pending",
                "owner": "operator",
                "blocks": [],
                "blockedBy": [],
                "metadata": {"source": "operator"},
            }
            try:
                _save(state)
            except OSError as e:
                await transcript.mount(Static(
                    f"failed to write {task_path}: {e}",
                    classes="claude-msg",
                ))
                return
            # Mirror into the footer state so the operator sees it
            # immediately without waiting for the next TaskList round.
            self._upsert_harness_task(
                tid, subject=subject, status="pending",
            )
            await transcript.mount(Static(
                f"[green]✓[/green] Task #{tid} added: {_esc(subject)}\n"
                f"{_render_list()}",
                classes="claude-msg", markup=True,
            ))
            return

        if verb in ("in", "in-progress", "start", "claim"):
            tid = rest.strip().lstrip("#")
            if not tid.isdigit():
                await transcript.mount(Static(
                    "usage: /task in <N>",
                    classes="claude-msg",
                ))
                return
            state = _load()
            t = state["tasks"].get(tid)
            if t is None:
                await transcript.mount(Static(
                    f"unknown task #{tid}",
                    classes="claude-msg",
                ))
                return
            t["status"] = "in_progress"
            _save(state)
            self._upsert_harness_task(tid, status="in_progress")
            await transcript.mount(Static(
                f"[cyan]▶[/cyan] Task #{tid} → in_progress\n{_render_list()}",
                classes="claude-msg", markup=True,
            ))
            return

        if verb in ("done", "complete", "finish"):
            tid = rest.strip().lstrip("#")
            if not tid.isdigit():
                await transcript.mount(Static(
                    "usage: /task done <N>",
                    classes="claude-msg",
                ))
                return
            state = _load()
            t = state["tasks"].get(tid)
            if t is None:
                await transcript.mount(Static(
                    f"unknown task #{tid}",
                    classes="claude-msg",
                ))
                return
            t["status"] = "completed"
            _save(state)
            self._upsert_harness_task(tid, status="completed")
            await transcript.mount(Static(
                f"[green]☑[/green] Task #{tid} → completed\n{_render_list()}",
                classes="claude-msg", markup=True,
            ))
            return

        if verb in ("del", "delete", "rm", "drop"):
            tid = rest.strip().lstrip("#")
            if not tid.isdigit():
                await transcript.mount(Static(
                    "usage: /task del <N>",
                    classes="claude-msg",
                ))
                return
            state = _load()
            if tid not in state["tasks"]:
                await transcript.mount(Static(
                    f"unknown task #{tid}",
                    classes="claude-msg",
                ))
                return
            del state["tasks"][tid]
            _save(state)
            # Also drop from the footer state.
            self._harness_tasks.pop(tid, None)
            try:
                self._harness_tasks_order.remove(tid)
            except ValueError:
                pass
            self._render_harness_tasks()
            await transcript.mount(Static(
                f"[red]✗[/red] Task #{tid} deleted\n{_render_list()}",
                classes="claude-msg", markup=True,
            ))
            return

        await transcript.mount(Static(
            f"unknown /task verb: {_esc(verb)}  (try /task help)",
            classes="claude-msg", markup=True,
        ))

    async def _cmd_subagents(self, arg: str = "") -> None:
        """``/subagents [N]`` — list subagent sessions this rtxclaw
        session has spawned, or enter the Nth one.

        rtxclaw delegates work via three sibling tools — ``delegate_agent``
        (rtxclaw-on-rtxclaw), ``delegate_claude`` (Claude Code bridge),
        and ``delegate_codex`` (OpenAI Codex bridge). Each persists the
        child session id to a sidecar at
        ``<sessions_dir>/<parent_sid>.delegate_<kind>[.<target>].json``
        so the next call from the same parent resumes the same child.
        ``/subagents`` reads those sidecars and shows what's there.

        Without an argument: print a numbered list. With a number:
        switch the TUI's view to that subagent's session — for
        ``delegate_agent`` we hop into the target rtxclaw agent (same
        path ``/agent <name>`` takes), for the external bridges we
        print the bridge's session id and last-modified time so the
        operator can re-attach via the bridge's own CLI.
        """
        from pathlib import Path as _Path
        transcript = self.query_one("#transcript", VerticalScroll)
        await transcript.mount(UserMessage(
            "❯ /subagents" + (f" {arg}" if arg else "")
        ))
        sid = getattr(self, "_sid", None)
        if not sid:
            await transcript.mount(Static(
                "no active session — start one before listing subagents",
                classes="claude-msg",
            ))
            return
        sessions_dir = _Path(self.agent_cfg.sessions_dir)
        rows: list[tuple[str, str, str, _Path]] = []
        # (kind, target_or_id, mtime_str, sidecar_path) — `target_or_id`
        # is the named target for delegate_agent, "claude" / "codex"
        # otherwise.
        for entry in sorted(sessions_dir.glob(f"{sid}.delegate_agent.*.json")):
            try:
                data = json.loads(entry.read_text(encoding="utf-8"))
                cid = data.get("session_id") or "—"
            except Exception:  # noqa: BLE001
                cid = "—"
            target = entry.stem.split(".delegate_agent.", 1)[-1]
            mtime = datetime.fromtimestamp(entry.stat().st_mtime).strftime("%H:%M:%S")
            rows.append((
                "agent",
                target,
                f"{cid}  ({mtime})",
                entry,
            ))
        for entry in sorted(sessions_dir.glob(f"{sid}.delegate_claude.json")):
            try:
                data = json.loads(entry.read_text(encoding="utf-8"))
                cid = data.get("claude_session_id") or "—"
            except Exception:  # noqa: BLE001
                cid = "—"
            mtime = datetime.fromtimestamp(entry.stat().st_mtime).strftime("%H:%M:%S")
            rows.append(("claude", "claude-code", f"{cid}  ({mtime})", entry))
        for entry in sorted(sessions_dir.glob(f"{sid}.delegate_codex.json")):
            try:
                data = json.loads(entry.read_text(encoding="utf-8"))
                cid = data.get("thread_id") or data.get("session_id") or "—"
            except Exception:  # noqa: BLE001
                cid = "—"
            mtime = datetime.fromtimestamp(entry.stat().st_mtime).strftime("%H:%M:%S")
            rows.append(("codex", "openai-codex", f"{cid}  ({mtime})", entry))
        # Per-call subagent sidecars written by the TUI for every
        # ``Agent`` / ``delegate_*`` tool call (captures prompt + result
        # + elapsed time so the run is verifiable later).
        for entry in sorted(sessions_dir.glob(f"{sid}.subagent.*.json")):
            try:
                data = json.loads(entry.read_text(encoding="utf-8"))
                tool = data.get("tool") or "agent"
                status = data.get("status") or "?"
                args = data.get("args") or {}
                desc = (
                    args.get("description")
                    or args.get("task")
                    or args.get("name")
                    or ""
                )
                if isinstance(desc, str) and len(desc) > 60:
                    desc = desc[:57] + "…"
                elapsed = data.get("elapsed_s")
                tag = f"{tool}/{status}"
                if elapsed is not None:
                    tag = f"{tag} {elapsed}s"
            except Exception:  # noqa: BLE001
                tool = "agent"
                tag = "?"
                desc = ""
            mtime = datetime.fromtimestamp(entry.stat().st_mtime).strftime("%H:%M:%S")
            label = desc or entry.stem
            rows.append((
                "subagent",
                label,
                f"{tag}  ({mtime})",
                entry,
            ))
        if not rows:
            await transcript.mount(Static(
                "no subagents have been spawned from this session yet.\n"
                "[dim]rtxclaw spawns subagents via the canonical "
                "[bold]Agent[/bold] tool — call "
                "[bold]Agent(subagent_type=\"general-purpose\"|\"claude\"|\"codex\"|\"gemini\", "
                "description=…, prompt=…)[/bold] in a prompt to populate "
                "this list. Operator-side, the [bold]/claude[/bold] / "
                "[bold]/codex[/bold] / [bold]/gemini[/bold] slash commands "
                "also spawn entries here (session-continuation "
                "primitives — see CLAUDE.md).[/dim]",
                classes="claude-msg",
                markup=True,
            ))
            return
        # If `arg` is a 1-based index, hop to that subagent.
        if arg:
            try:
                idx = int(arg)
            except ValueError:
                await transcript.mount(Static(
                    f"usage: /subagents [N]  — N is 1..{len(rows)}",
                    classes="claude-msg",
                ))
                return
            if not (1 <= idx <= len(rows)):
                await transcript.mount(Static(
                    f"index {idx} out of range (have {len(rows)} subagent(s))",
                    classes="claude-msg",
                ))
                return
            kind, target, _ident, _path = rows[idx - 1]
            if kind == "agent":
                # Same path /agent uses — switch to the target rtxclaw agent.
                await transcript.mount(Static(
                    f"entering subagent → switching to agent [bold]{target}[/bold]",
                    classes="claude-msg", markup=True,
                ))
                run = getattr(self, "_cmd_agent", None)
                if run is not None:
                    await run(target)
                return
            await transcript.mount(Static(
                f"[bold]{kind}[/bold] subagents are external bridges — "
                f"reattach via their own CLI ({_ident}).",
                classes="claude-msg", markup=True,
            ))
            return
        # Render the list.
        body_lines = [
            f"[bold]{len(rows)} subagent(s) for this session[/bold]  "
            f"[dim]/subagents <N> to enter[/dim]\n",
        ]
        for n, (kind, target, ident, _path) in enumerate(rows, start=1):
            kind_disp = {
                "agent":  "🦞 agent ",
                "claude": "🤖 claude",
                "codex":  "🧪 codex ",
            }.get(kind, kind)
            body_lines.append(
                f"  [bold]{n:>2}.[/bold]  {kind_disp}  "
                f"[cyan]{target:<14}[/cyan]  [dim]{ident}[/dim]"
            )
        await transcript.mount(Static(
            "\n".join(body_lines),
            classes="claude-msg",
            markup=True,
        ))

    async def _cmd_monitors(self) -> None:
        """``/monitors`` — open the live monitor panel.

        Pushes ``MonitorPanelModal``: a navigable list of every
        monitor for the active session, refreshed every 1.5 s, with
        ``x`` to SIGTERM the selected monitor's PID and ``q`` /
        ``Esc`` to dismiss. Reads the same sidecar (``<sid>.monitors.json``)
        the runner code writes, so the panel and ``monitor_list``
        stay in sync.

        For non-interactive contexts (scripts, log review),
        ``monitor_list`` printed in a tool round gives the same data
        as a one-shot text dump.
        """
        from pathlib import Path as _Path
        transcript = self.query_one("#transcript", VerticalScroll)
        await transcript.mount(UserMessage("❯ /monitors"))
        sid = getattr(self, "_sid", None)
        if not sid:
            await transcript.mount(Static(
                "no active session — start one before opening the monitor panel",
                classes="claude-msg",
            ))
            return
        sessions_dir = _Path(self.agent_cfg.sessions_dir)
        await self.push_screen(MonitorPanelModal(sessions_dir, sid))

    async def _cmd_skill(self, arg: str = "") -> None:
        """``/skills`` — list installed skills; ``/skill <name>`` — show
        one skill's SKILL.md body.

        Skills are the agent's on-demand runbooks (the ``skill_get``
        tool). This is the operator-facing view of the same discovery
        chain the agent sees — per-agent → ``~/.rtxclaw/skills`` →
        config ``skills_dirs`` bundles → builtin — so it doubles as a
        quick check that an everything-claude-code / OpenClaw bundle
        registered. Disabled skills (``skills`` map in the global
        config) show with a ``✗`` marker.
        """
        from rtxclaw_core import skills as _skills_mod
        transcript = self.query_one("#transcript", VerticalScroll)
        arg = (arg or "").strip()
        await transcript.mount(UserMessage(
            "❯ /skill " + arg if arg else "❯ /skills"
        ))
        if arg:
            skill = _skills_mod.find_skill(arg)
            if skill is None:
                await transcript.mount(Static(
                    f"skill not found: {arg!r} — /skills to list what's installed",
                    classes="claude-msg",
                ))
                return
            lines = [f"# {skill.name}", skill.short_description, ""]
            if skill.version:
                lines.append(f"version: {skill.version}")
            if skill.requires_env:
                lines.append(f"requires env: {', '.join(skill.requires_env)}")
            if skill.requires_bins:
                lines.append(f"requires bins: {', '.join(skill.requires_bins)}")
            lines.append(f"source: {skill.source}")
            lines.append("")
            lines.append("─" * 40)
            lines.append(skill.body or "(SKILL.md has frontmatter only — no body)")
            await transcript.mount(Static("\n".join(lines), classes="claude-msg"))
            return
        skills = _skills_mod.discover_skills(include_disabled=True)
        if not skills:
            await transcript.mount(Static(
                "no skills installed — add a dir to `skills_dirs` in "
                "~/.rtxclaw/config.json, or drop one in ~/.rtxclaw/skills/<name>/",
                classes="claude-msg",
            ))
            return
        enabled = {s.name for s in _skills_mod.discover_skills()}
        lines = [f"{len(skills)} skill(s)  ·  /skill <name> to read one", ""]
        for s in skills:
            mark = "  " if s.name in enabled else "✗ "
            lines.append(f"{mark}{s.name:<30s} {s.short_description}")
        if len(enabled) < len(skills):
            lines.append("")
            lines.append("✗ = disabled via the `skills` map in ~/.rtxclaw/config.json")
        await transcript.mount(Static("\n".join(lines), classes="claude-msg"))

    async def _cmd_plugin(self, arg: str = "") -> None:
        """``/plugin list|install|enable|disable|remove`` — manage plugin
        bundles (one dir packaging skills + commands + agents + hooks
        as a unit). Installed plugins live at ``~/.rtxclaw/plugins/``
        and are discovered automatically — disabled ones use a
        ``.disabled`` suffix.
        """
        from rtxclaw_core import plugins as _plug
        transcript = self.query_one("#transcript", VerticalScroll)
        await transcript.mount(UserMessage(
            "❯ /plugin" + (f" {arg}" if arg else " list"),
        ))
        parts = (arg or "list").strip().split(None, 1)
        sub = parts[0].lower() if parts else "list"
        rest = parts[1].strip() if len(parts) > 1 else ""

        def _say(text: str) -> None:
            # Closure: mount a Static into the transcript.
            import asyncio as _aio
            _aio.create_task(transcript.mount(
                Static(text, classes="claude-msg"),
            ))

        if sub == "list":
            items = _plug.list_plugins()
            if not items:
                await transcript.mount(Static(
                    "no plugins installed — try "
                    "`/plugin search <query>` then "
                    "`/plugin install <name-or-git-url>`",
                    classes="claude-msg",
                ))
                return
            lines = [f"{len(items)} plugin(s) at ~/.rtxclaw/plugins/", ""]
            for p in items:
                mark = "  " if p.enabled else "✗ "
                comps = p.components()
                summary = ", ".join(f"{k}={v}" for k, v in comps.items()) or "(empty)"
                head = f"{mark}{p.name:<20s} {p.version or '-':<10s} {summary}"
                if p.description:
                    head += f"  — {p.description[:60]}"
                lines.append(head)
                if p.source:
                    lines.append(f"     source: {p.source}")
            if any(not p.enabled for p in items):
                lines.append("")
                lines.append("✗ = disabled (rename drops `.disabled` to re-enable)")
            await transcript.mount(Static("\n".join(lines), classes="claude-msg"))
            return

        if sub == "search":
            # ``/plugin search [query]`` — substring-rank the curated
            # marketplace registry (rtxclaw_core.plugins.search). Empty
            # query lists the full registry sorted by name. Mirrors
            # the Telegram bot's parity path so a plugin discovered on
            # one frontend is installable from the other.
            results = _plug.search(rest or "")
            if not results:
                await transcript.mount(Static(
                    f"no marketplace matches for {rest!r}\n"
                    "tip: try a broader keyword like `skill`, `hook`, `mcp`, or "
                    "drop ~/.rtxclaw/plugin-marketplace.json with your own entries",
                    classes="claude-msg",
                ))
                return
            label = f"matches for {rest!r}" if rest else "marketplace listing"
            lines = [f"{len(results)} {label}:", ""]
            for e in results:
                comps = ",".join(e.components) or "-"
                tags = ",".join(e.tags) or "-"
                lines.append(f"• {e.name} [{comps}]  tags={tags}")
                if e.description:
                    lines.append(f"     {e.description[:90]}")
                lines.append(f"     install: {e.install_hint()}")
            lines.append("")
            lines.append(
                "tip: `/plugin install <name>` installs by marketplace name, "
                "or paste any git URL / local path"
            )
            await transcript.mount(Static("\n".join(lines), classes="claude-msg"))
            return

        if sub == "install":
            if not rest:
                await transcript.mount(Static(
                    "usage: /plugin install <git-url|local-path> [--ref <branch>]",
                    classes="claude-msg",
                ))
                return
            src = rest
            ref: str = ""
            if " --ref " in src:
                src, _, ref = src.partition(" --ref ")
                src, ref = src.strip(), ref.strip()
            try:
                p = _plug.install(src.strip(), ref=ref or None)
            except Exception as exc:  # noqa: BLE001
                await transcript.mount(Static(
                    f"install failed: {exc}", classes="claude-msg",
                ))
                return
            comps = ", ".join(
                f"{k}={v}" for k, v in p.components().items()
            ) or "(no skills/commands/agents/hooks detected)"
            await transcript.mount(Static(
                f"installed {p.name} -> {p.path}\n  components: {comps}\n"
                "  (skills + commands are discovered automatically)",
                classes="claude-msg",
            ))
            return

        if sub in ("enable", "disable"):
            if not rest:
                await transcript.mount(Static(
                    f"usage: /plugin {sub} <name>", classes="claude-msg",
                ))
                return
            try:
                fn = _plug.enable if sub == "enable" else _plug.disable
                p = fn(rest)
            except Exception as exc:  # noqa: BLE001
                await transcript.mount(Static(
                    f"{sub} failed: {exc}", classes="claude-msg",
                ))
                return
            await transcript.mount(Static(
                f"{p.name}: {'enabled' if p.enabled else 'disabled'}",
                classes="claude-msg",
            ))
            return

        if sub == "remove":
            if not rest:
                await transcript.mount(Static(
                    "usage: /plugin remove <name> [--purge]",
                    classes="claude-msg",
                ))
                return
            purge = False
            name = rest
            if " --purge" in name or name.endswith(" --purge"):
                name = name.replace(" --purge", "").strip()
                purge = True
            try:
                where = _plug.remove(name, purge=purge)
            except Exception as exc:  # noqa: BLE001
                await transcript.mount(Static(
                    f"remove failed: {exc}", classes="claude-msg",
                ))
                return
            await transcript.mount(Static(
                f"removed {name} -> {where}"
                + ("" if purge else " (in .trash/; can be restored)"),
                classes="claude-msg",
            ))
            return

        await transcript.mount(Static(
            f"unknown /plugin subcommand: {sub!r}\n"
            "usage: /plugin {list|search|install|enable|disable|remove} [args]",
            classes="claude-msg",
        ))

    async def _cmd_mcp(self, arg: str = "") -> None:
        """``/mcp`` — list every MCP server visible to the agent, with
        its transport and discovery source.

        Mirrors Claude Code's ``/mcp`` command (CLAUDE_CODE_FEATURE_MAP
        sec 1). Reads from ``rtxclaw_mcp.list_mcp_servers_with_source``
        which folds three sources in precedence order:

          1. ``~/.rtxclaw/config.json`` → ``mcp_servers`` (legacy /
             snake_case) or ``mcpServers`` (Claude Code spec). Tagged
             ``[config]``.
          2. ``~/.claude/.mcp.json`` (Claude Code's user-level MCP
             file). Tagged ``[claude]``.
          3. Each enabled plugin bundle's ``.mcp.json``. Tagged
             ``[plugin]``.

        A filter argument scopes by substring match against name +
        transport + description: ``/mcp gitea`` lists only servers
        whose name or description mentions "gitea".
        """
        try:
            transcript = self.query_one("#chat-transcript")
        except Exception:  # noqa: BLE001
            return
        await transcript.mount(Static(
            "❯ /mcp" + (f" {arg}" if arg else ""),
            classes="user-msg",
        ))
        from rtxclaw_mcp.mcp_client import list_mcp_servers_with_source

        servers = list_mcp_servers_with_source()
        flt = (arg or "").strip().lower()
        if flt:
            servers = [
                (s, src) for (s, src) in servers
                if flt in s.name.lower()
                or flt in (s.transport or "").lower()
                or flt in (s.description or "").lower()
            ]
        if not servers:
            if flt:
                msg = (
                    f"no MCP servers match {arg!r}.\n"
                    "configured servers can be listed with `/mcp` "
                    "(no argument)."
                )
            else:
                msg = (
                    "no MCP servers configured.\n"
                    "tip: add one in ~/.rtxclaw/config.json under "
                    "`mcpServers`, drop ~/.claude/.mcp.json (Claude "
                    "Code spec), or install a plugin bundle that "
                    "ships an `.mcp.json`."
                )
            await transcript.mount(Static(msg, classes="claude-msg"))
            return
        lines = [f"{len(servers)} MCP server(s):", ""]
        for server, src in servers:
            badge = f"[{src}]"
            head = f"  {server.name:<24s} {server.transport:<5s} {badge}"
            lines.append(head)
            if server.transport == "stdio":
                cmd_line = server.command
                if server.args:
                    cmd_line += " " + " ".join(server.args)
                if cmd_line:
                    lines.append(f"     exec: {cmd_line}")
            else:
                if server.url:
                    lines.append(f"     url:  {server.url}")
            if server.description:
                lines.append(f"     desc: {server.description[:80]}")
        lines.append("")
        lines.append(
            "sources: [config]=~/.rtxclaw/config.json  "
            "[claude]=~/.claude/.mcp.json  [plugin]=bundle .mcp.json"
        )
        await transcript.mount(Static("\n".join(lines), classes="claude-msg"))

    async def _cmd_commands(self, arg: str = "") -> None:
        """``/commands`` — list file-based slash commands (Claude Code
        ``commands/*.md``, including everything-claude-code). Each
        ``/<name> [args]`` expands that command's prompt body into a
        normal user turn — type one to run it.
        """
        from rtxclaw_core import file_commands as _fc
        transcript = self.query_one("#transcript", VerticalScroll)
        await transcript.mount(UserMessage("❯ /commands"))
        cmds = _fc.discover_commands()
        if not cmds:
            await transcript.mount(Static(
                "no file commands installed — add a dir to `commands_dirs` "
                "in ~/.rtxclaw/config.json, or drop one in "
                "~/.rtxclaw/commands/<name>.md",
                classes="claude-msg",
            ))
            return
        lines = [
            f"{len(cmds)} command(s)  ·  type /<name> [args] to run one", "",
        ]
        for c in cmds:
            hint = f" {c.argument_hint}" if c.argument_hint else ""
            lines.append(f"  /{c.name}{hint}".ljust(32) + f" {c.short_description}")
        await transcript.mount(Static("\n".join(lines), classes="claude-msg"))

    async def _cmd_agent(self, arg: str) -> None:
        """``/agent <name>`` — switch this TUI to a different agent.

        Tears down the current stdio child agent, swaps the bound
        ``AgentConfig``, spawns a fresh stdio child against the new
        agent, and creates a fresh session in it. Transcript /
        plan-checklist / claude+codex chain ids all reset so the
        new agent starts from a clean slate.

        Use cases:
        - run a one-off task in the ``scraper`` agent without
          leaving the TUI.
        - flip between two specialized agents in a long working
          session (``main`` for code, ``scraper`` for web research).

        Failure modes are surfaced inline (``agent <name> not found``,
        ``connection failed``); the TUI stays on the previous agent
        rather than half-switching.
        """
        transcript = self.query_one("#transcript", VerticalScroll)
        target = (arg or "").strip()
        if not target:
            await transcript.mount(UserMessage("❯ /agent"))
            await transcript.mount(Static(
                "usage: /agent <name>  (use /agents to list available)",
                classes="claude-msg",
            ))
            return
        if target == self.agent_cfg.name:
            await transcript.mount(UserMessage(f"❯ /agent {target}"))
            await transcript.mount(Static(
                f"already on agent [bold]{target}[/bold]",
                classes="claude-msg",
            ))
            return

        # Validate the target exists BEFORE tearing the old client
        # down — otherwise a typo lands the operator in a no-agent
        # limbo with no way back.
        try:
            from rtxclaw_core.agent import AgentConfig
            new_cfg = AgentConfig.load(target)
        except Exception as e:  # noqa: BLE001
            await transcript.mount(UserMessage(f"❯ /agent {target}"))
            await transcript.mount(Static(
                f"[red]agent {target!r} not found:[/red] {e}\n"
                f"use [bold]/agents[/bold] to list configured agents.",
                classes="claude-msg",
            ))
            return

        await transcript.mount(UserMessage(f"❯ /agent {target}"))
        self._set_status(f"switching to agent {target}…")

        # Abort any in-flight turn before swapping clients.
        if self._current_turn_id is not None:
            await self.action_abort(via="agent_switch")
            for _ in range(50):
                if self._current_turn_id is None:
                    break
                await asyncio.sleep(0.02)

        # Tear down the existing AgentClient. The stdio child agent
        # gets SIGTERM'd; its sessions persist on disk so an
        # operator can ``/agent main`` back later and keep working.
        old_client = self._client
        if old_client is not None:
            try:
                await old_client.close()
            except Exception:  # noqa: BLE001
                pass

        # Swap the bound config + reset all per-session state.
        self.agent_cfg = new_cfg
        self._permission_mode = (
            getattr(new_cfg, "permission_mode", "auto") or "auto"
        )
        self._sid = None
        # Drop the prior session view too — otherwise the interim
        # ``_poll_health`` / ``_refresh_status_bar`` between here and
        # ``_ensure_session`` reads the OLD session's ``model`` field
        # under the NEW agent's engine, smearing e.g. ``qwen3.6-27b-fp8``
        # into a freshly-switched gemini agent's footer until the next
        # turn replaces the session view.
        self.session = None
        self._claude_session_id = None
        self._claude_synced_turn_idx = 0
        self._codex_thread_id = None
        self._codex_synced_turn_idx = 0
        self._last_prompt_tokens = None
        self._last_context_window = None
        self._endpoint_override = None  # picker / /model still work
        self.clear_plan_checklist()
        await transcript.remove_children()

        # Build a fresh AgentClient against the new agent's gateway
        # mount. URL is unused (the gateway hosts the child); the
        # ``gateway_url``/``gateway_token`` kwargs route the new
        # ``AgentClient`` at ``/acp/<new_cfg.name>``.
        from rtxclaw_tui.agent_client import AgentClient
        gateway_url, gateway_token = _gateway_url_and_token()
        self._client = AgentClient(
            new_cfg.url,
            agent_name=new_cfg.name,
            gateway_url=gateway_url,
            gateway_token=gateway_token,
        )
        self._wire_client_callbacks(self._client)

        # Re-poll health so the footer reflects the new agent's
        # upstream + reachability immediately.
        await self._poll_health()
        # Brand-new session against the swapped agent.
        if not await self._ensure_session(initial=True):
            self._set_status(f"agent {target}: session create failed")
            return

        self._refresh_status_bar()
        self._set_status(
            f"switched to agent {target} — new session [{self._sid[:12]}]"
        )
        await transcript.mount(Static(
            f"switched to agent [bold]{target}[/bold] — "
            f"new session [{self._sid[:12]}]",
            classes="claude-msg",
        ))

    async def _cmd_compact(self) -> None:
        """Manual `/compact` — between-turn equivalent of the model's
        `compact_context` tool call.

        Synthesizes a user prompt that biases the local model to emit
        ``compact_context``. The bridge intercepts that tool call and
        squeezes the live message list in-place, persisting a rolling
        summary onto the session. Same shape Telegram uses, so the
        two frontends stay in lock-step.
        """
        if self._sid is None:
            self._set_status("no session yet — wait for the agent to come up")
            return
        if self._current_turn_id is not None:
            # Mid-turn compaction is the model's job (`compact_context`).
            # Doing it from here would race the dispatch loop.
            self._set_status("turn in flight — abort first or call compact_context")
            return
        assert self._client is not None
        self._set_status("compacting…")
        # Hand off to the regular turn dispatcher with a synthesized
        # tool-use directive. The bridge intercept on compact_context
        # surfaces a tool_call_update with the audit; the standard TUI
        # rendering shows it as the round's tool result, plus the
        # status bar updates after `_send_user_turn` returns.
        compact_directive = (
            "Call the `compact_context` tool now to squeeze the running "
            "message list. Then briefly confirm in one sentence what was "
            "trimmed."
        )
        await self._send_user_turn(compact_directive)
        return
        # ------------------------------------------------------------
        # Legacy CompactionNotice rendering — left below for context;
        # the synthesized-turn path replaces it. Don't enable without
        # restoring a real ``compact_session`` endpoint that returns
        # an audit dict (the ACP path no longer exposes one).
        try:
            result: dict = {}
        except Exception as e:  # noqa: BLE001
            self._set_status(f"compact failed: {e}")
            return
        # Reuse `CompactionNotice`: payload shape mirrors the SSE
        # auto_continue event so a single widget renders both paths.
        # LLM stats (summary_chars / prompt_tokens / completion_tokens
        # / duration_s / phase / finish_reason) come straight from the
        # `/compact` endpoint and surface in the notice so the user can
        # confirm an LLM summarization round actually happened.
        audit = result.get("audit") or {}
        # Estimate post-compact prompt size from chars (same /3 fallback the
        # runtime uses) so the notice shows a real number instead of "n/a".
        try:
            _orig_c = int(result.get("original_chars") or 0)
            _rem_c = int(result.get("removed_chars") or 0)
            _new_c = max(0, _orig_c - _rem_c)
            _new_pt = int(_new_c / 3) if _new_c > 0 else None
        except (TypeError, ValueError):
            _new_pt = None
        notice_payload = {
            "removed_tokens": int((result.get("removed_chars") or 0) / 3),
            "new_prompt_tokens": _new_pt,
            "round": "(saved-session compact)",
            "truncated_tool_call_ids": audit.get("truncated_tool_call_ids") or [],
            "dropped_tool_call_ids": audit.get("dropped_tool_call_ids") or [],
            "dropped_turns": int(audit.get("dropped_turns") or 0),
            "summary_chars": int(result.get("summary_chars") or 0),
            "prompt_tokens": result.get("prompt_tokens"),
            "completion_tokens": result.get("completion_tokens"),
            "duration_s": result.get("duration_s"),
            "phase": result.get("phase"),
            "finish_reason": result.get("finish_reason"),
        }
        await transcript.mount(CompactionNotice("compacted", notice_payload))
        # Tag the matching ToolResultMessage widgets so the user can see
        # exactly which tool outputs got trimmed in the saved transcript
        # (the upstream model's view will be the trimmed version on the
        # next turn).
        truncated = set(audit.get("truncated_tool_call_ids") or [])
        if truncated:
            for w in transcript.query(ToolResultMessage):
                if w.call_id in truncated:
                    w.mark_compacted("truncated")
        self._maybe_scroll_end(transcript)
        # Update the `ctx X/Y` indicator NOW so the user sees the
        # post-compaction prompt size without waiting for the next turn.
        # The server returned `original_chars` and `removed_chars`; the
        # new prompt is `(original - removed)` chars ≈ `/3` tokens (the
        # same `_FALLBACK_CHARS_PER_TOKEN` the runtime uses elsewhere).
        # Without this the bar still showed the pre-compaction count
        # because it was sourced from the last turn's `prompt_tokens`.
        if _new_pt:
            self._last_prompt_tokens = _new_pt
            self._refresh_status_bar()

        # Status line: always lead with proof the LLM ran. Without this
        # `/compact` looked indistinguishable from the deterministic-only
        # path it replaced, even though the server logs (and now the
        # notice body) showed real `prompt_tokens` / `completion_tokens`.
        sc = int(result.get("summary_chars") or 0)
        ct = result.get("completion_tokens")
        dur = result.get("duration_s")
        if sc and ct is not None:
            dur_s = f" in {float(dur):.1f}s" if isinstance(dur, (int, float)) else ""
            self._set_status(
                f"compacted: LLM summary {sc} chars · {int(ct)} tok"
                f"{dur_s} · ~{result.get('removed_chars', 0)} chars freed"
            )
        else:
            self._set_status(
                f"compacted: {result.get('removed_chars', 0)} chars removed"
            )

    def _apply_command_state_patch(self, patch: dict) -> None:
        mode = patch.get("permission_mode") or patch.get("system_mode")
        if isinstance(mode, str):
            self._permission_mode = mode
        if "thinking_enabled" in patch:
            self.enable_thinking = bool(patch.get("thinking_enabled"))
        reasoning = patch.get("reasoning_visibility")
        if isinstance(reasoning, str):
            self.reasoning_visibility = reasoning
        if "tool_output_visible" in patch:
            self.tool_output_visible = bool(patch.get("tool_output_visible"))
        self._refresh_status_bar()

    def _dispatch_restart(self) -> None:
        """``/restart`` — bounce the rtxclaw gateway, keep the TUI up.

        Uses the cross-frontend
        :func:`rtxclaw_core.restart.restart_agent_detached` helper.
        Bouncing the single-process gateway cascades to every agent
        (every child stdio process) at once. The TUI loses its
        connection for a few seconds; we schedule an explicit
        :meth:`_reconnect` after the gateway's typical respawn
        window — the connection-watch loop alone can't recover
        because (a) it short-circuits when ``self._client is None``
        (the pre-mount guard), and (b) the HTTP-mode
        ``is_connected()`` is just a "client exists" check, never a
        live probe, so the watcher can't even detect a dead remote.
        Observed 2026-05-15: prompt after ``/restart`` crashed with
        ``'NoneType' object has no attribute 'session_turn'``.
        """
        try:
            from rtxclaw_core.restart import restart_agent_detached
        except ImportError as e:
            self._set_status(f"restart helper missing: {e}")
            return
        agent_name = getattr(self.agent_cfg, "name", "main")
        result = restart_agent_detached(agent_name)
        if not result.get("ok"):
            self._set_status(f"restart failed: {result.get('error')}")
            return
        # Drop the live ACP client so the next operation rebuilds
        # against the respawned gateway.
        self._client = None
        self._set_status("♻ restarting rtxclaw gateway (~3s)…")
        try:
            transcript = self.query_one("#transcript", VerticalScroll)
            transcript.mount(
                Static(
                    "♻ restart scheduled — rtxclaw gateway\n"
                    "Reconnecting once the gateway is back up.",
                    classes="claude-msg",
                ),
            )
        except Exception:  # noqa: BLE001
            pass
        # Schedule the reconnect. Wait > the restart_agent_detached
        # helper's typical respawn window (~3s) plus a small buffer
        # so the new daemon is bound to its port by the time we
        # probe. The reconnect path will fall back to its own
        # exponential backoff if the gateway is still warming up.
        try:
            self.set_timer(4.0, self._reconnect_after_restart)
        except Exception:  # noqa: BLE001
            pass

    async def _reconnect_after_restart(self) -> None:
        """Re-establish the AgentClient after a ``/restart``.

        Resets reconnect bookkeeping so the post-restart attempt
        doesn't inherit the previous session's backoff window, then
        defers to :meth:`_reconnect`. If the gateway hasn't bound
        its port yet, ``_reconnect`` sets back to ``self._client =
        None`` on probe failure — so we re-schedule ourselves with
        a small backoff until the gateway is up (or we've burned
        the attempt budget).
        """
        self._reconnect_attempts = 0
        self._last_reconnect_at = 0.0
        attempt = 0
        max_attempts = 8  # ~30s total at 1+2+3+4+5+5+5+5
        while attempt < max_attempts:
            async with self._reconnect_lock:
                await self._reconnect()
            if self._client is not None and self._client.is_connected():
                return
            attempt += 1
            backoff = min(attempt, 5)
            await asyncio.sleep(backoff)
        self._set_status(
            "reconnect after /restart timed out — submit a prompt to retry, "
            "or relaunch the TUI",
        )

    async def _cmd_shared(self, text: str) -> None:
        transcript = self.query_one("#transcript", VerticalScroll)
        await transcript.mount(UserMessage(f"❯ {text}"))
        if self._sid is None or self._client is None:
            self._set_status("no session yet — wait for the agent to come up")
            return
        if self._current_turn_id is not None and text.split()[0] not in ("/status", "/help"):
            self._set_status("turn in flight — abort first")
            return
        try:
            result = await self._client.session_command(self._sid, text, frontend="tui")
        except Exception as e:  # noqa: BLE001
            self._set_status(f"command failed: {e}")
            return
        self._apply_command_state_patch(result.get("state_patch") or {})
        msg = result.get("text") or "(no output)"
        self._set_status(msg.replace("\n", "  ")[:200])
        await transcript.mount(Static(msg, classes="claude-msg"))

    async def _cmd_models(self, arg: str = "") -> None:
        """`/models` — list configured models (interactive picker).

        Mirrors openclaw's `/models`: list-only entry point. The single
        configured-model case prints an inline summary; multi-model
        configs open the modal picker so the user can pick one. To
        switch directly without the picker, use `/model <alias|url>`.

        For CLI-engine agents whose model list is engine-owned (today:
        gemini-cli), the rows come from :func:`_engine_models_for`
        instead of ``cfg.models`` so the picker shows the right thing.
        """
        transcript = self.query_one("#transcript", VerticalScroll)
        await transcript.mount(UserMessage("❯ /models" + (f" {arg}" if arg else "")))
        if arg:
            self._set_status("usage: /models  (no args). switch with /model <alias|url>")
            return
        cfg = self.agent_cfg
        engine_rows = _engine_models_for(cfg)
        if engine_rows is not None:
            rows = engine_rows
        else:
            rows = cfg.models or []
            if not rows:
                rows = [cfg._primary_model_row()]
        current = self.session.endpoint if self.session else cfg.upstream_endpoint
        current_norm = (current or "").rstrip("/")
        # Engine-owned rows have no upstream URL; match by alias instead.
        current_alias = ""
        if engine_rows is not None:
            current_alias = self._current_engine_model_alias()

        if len(rows) == 1:
            m = rows[0]
            alias = m.get("alias") or "?"
            raw_model_id = m.get("id") or ""
            model_id = raw_model_id or "(missing id)"
            url = (m.get("baseUrl") or "").rstrip("/")
            ctx = m.get("contextWindow") or 0
            ctx_label = f"{ctx//1024}k" if ctx else "?"
            model_label = _model_alias_id_label(alias, model_id)
            lines = [
                f"current: {model_label}  ctx={ctx_label}",
                f"  {url}",
                "",
                "Add more models via `rtxclaw agent setup` or by editing "
                "~/.rtxclaw/config.json",
            ]
            await transcript.mount(Static("\n".join(lines), classes="claude-msg"))
            self._set_status("model info shown")
            return

        picked = await self.push_screen_wait(
            ModelPickerModal(
                rows,
                current_url=current_norm,
                current_alias=current_alias,
            ),
        )
        if not picked:
            return
        await self._switch_to_model_row(picked)

    def _current_engine_model_alias(self) -> str:
        """For engine-owned-models agents (gemini-cli), return the
        current session's selected alias — or the default-sentinel
        (``"auto"`` for gemini) when nothing was picked.

        Used to highlight the right row in the model picker and to
        render the footer's ``model gemini/<alias>`` segment.
        """
        engine = (getattr(self.agent_cfg, "engine", "") or "").strip()
        if engine != "gemini_cli":
            return ""
        sel = ""
        if self.session is not None:
            sel = (getattr(self.session, "model", "") or "").strip()
        # Treat the engine-name default (``"gemini"`` — what
        # ``Agent.create_session`` stamps on a fresh CLI session) as
        # "no model picked" so we surface "auto" instead.
        if not sel or sel == "gemini":
            return "auto"
        return sel

    async def _cmd_model(self, arg: str = "") -> None:
        """`/model <alias|url>` — switch the live session's model/upstream.

        Each configured model row in `cfg.models` carries an alias,
        baseUrl, id, backend, and contextWindow. The alias names the
        model from the user's POV. To list/pick interactively, use
        `/models`.
        """
        transcript = self.query_one("#transcript", VerticalScroll)
        await transcript.mount(UserMessage(f"❯ /model {arg}".rstrip()))
        if not arg:
            self._set_status("usage: /model <alias|url>. list available models with /models")
            return

        if self._sid is None:
            self._set_status("no session yet — wait for the agent to come up")
            return
        if self._current_turn_id is not None:
            self._set_status("turn in flight — abort first")
            return
        assert self._client is not None
        try:
            result = await self._client.session_command(self._sid, f"/model {arg}", frontend="tui")
        except Exception as e:  # noqa: BLE001
            self._set_status(f"model switch failed: {e}")
            return
        data = result.get("data") or {}
        if not result.get("ok"):
            self._set_status(result.get("text") or "model command failed")
            return
        if self.session is not None:
            self.session.endpoint = data.get("endpoint") or data.get("baseUrl") or self.session.endpoint
            self.session.model = data.get("model") or data.get("id") or self.session.model
            if data.get("contextWindow"):
                self.session.context_window = int(data.get("contextWindow") or 0)
        self.endpoint = data.get("endpoint") or data.get("baseUrl") or self.endpoint
        if data.get("contextWindow"):
            self._last_context_window = int(data.get("contextWindow") or 0)
        if data.get("model") or data.get("id"):
            self.model = data.get("model") or data.get("id")
        self._refresh_title()
        try:
            self._refresh_status_bar()
        except Exception:  # noqa: BLE001
            pass
        msg = result.get("text") or "model switched"
        self._set_status(msg.replace("\n", "  "))
        await transcript.mount(Static(msg, classes="claude-msg"))

    async def _switch_to_model_row(self, row: dict) -> None:
        """Rebind the session to a model row dict and update local state.

        Extracted from `_cmd_model` so both the modal picker path and
        the `/model <alias>` path share the same switch logic.
        """
        resolved = (row.get("baseUrl") or "").rstrip("/")
        # Engine-owned rows (gemini-cli) carry no baseUrl — they're
        # selected purely by alias. Only the local-LLM / openrouter
        # path requires a URL.
        engine = (getattr(self.agent_cfg, "engine", "") or "").strip()
        engine_owned = engine == "gemini_cli"
        if not resolved and not engine_owned:
            self._set_status(f"unknown model alias {row.get('alias', '?')!r}")
            return
        assert self._client is not None
        # Pass ``alias=`` so the bridge resolves the row by alias
        # (the only key it accepts on ``set_config_option(model=…)``),
        # and ``id=`` so the local view's stats line picks up the
        # right wire model id without a round-trip. Without
        # ``alias`` the picker silently fails on the wire because
        # the bridge's ``_resolve_model_row`` only matches by alias.
        row_id = row.get("id") or row.get("model")
        row_alias = row.get("alias") or ""
        try:
            result = await self._client.update_session_model(
                self._sid,
                baseUrl=resolved,
                id=row_id or None,
                alias=row_alias or None,
                backend=row.get("backend") or None,
                contextWindow=row.get("contextWindow") or None,
            )
        except Exception as e:  # noqa: BLE001
            self._set_status(f"model switch failed: {e}")
            return
        if not result.get("ok"):
            # Wire-side rejection (unknown alias, upstream
            # unreachable…). Surface it so the operator doesn't see
            # a green ack while messages keep landing on the
            # previous model.
            err = str(result.get("error") or "unknown error")
            self._set_status(f"model switch failed: {err[:100]}")
            transcript = self.query_one("#transcript", VerticalScroll)
            await transcript.mount(
                Static(
                    f"[red]model switch failed:[/red] {err}",
                    classes="claude-msg",
                ),
            )
            return
        # ``update_session_model`` returns the local-view shape
        # (``endpoint`` / ``model`` / ``context_window`` snake-case),
        # not the picker-row shape (``baseUrl`` / ``id`` /
        # ``contextWindow``). Read both so the post-switch ack works
        # whether the caller is the picker or a manual ``/model``.
        new_endpoint = (
            result.get("endpoint")
            or result.get("baseUrl")
            or resolved
        )
        new_model_id = (
            result.get("model")
            or result.get("id")
            or row_id
            or ""
        )
        new_ctx = (
            result.get("context_window")
            or result.get("contextWindow")
            or row.get("contextWindow")
            or 0
        )
        if self.session is not None:
            self.session.endpoint = new_endpoint
            if new_model_id:
                self.session.model = new_model_id
            if new_ctx:
                self.session.context_window = int(new_ctx)
        self.endpoint = new_endpoint
        if new_ctx:
            self._last_context_window = int(new_ctx)
        if new_model_id:
            self.model = new_model_id
        self._refresh_title()
        # Repaint the footer NOW so model/ctx update without waiting
        # for the next health poll — matches what the picker user
        # expects: pick → footer flips immediately.
        try:
            self._refresh_status_bar()
        except Exception:  # noqa: BLE001
            pass
        transcript = self.query_one("#transcript", VerticalScroll)
        warn = result.get("upstream_error")
        alias = row.get("alias") or "?"
        ctx_label = f" · ctx={new_ctx // 1024}k" if new_ctx else ""
        # Friendlier ack: alias is what the user picked from the
        # modal; model id is the wire identifier the agent will
        # actually request.
        model_label = _model_alias_id_label(alias, new_model_id)
        msg = f"model → {model_label or alias}{ctx_label}"
        msg += f"\n  {new_endpoint}"
        if warn:
            msg += f"  ·  upstream warn: {warn[:60]}"
        self._set_status(msg.replace("\n", "  ")[:200])
        await transcript.mount(Static(msg, classes="claude-msg"))

    async def _replay_session_into_transcript(self, data: dict) -> int:
        """Render the saved turns of `data` (a session JSON dict) into
        the transcript so the user can scroll back through prior history
        after a `/sessions` switch. Returns the number of turns replayed.

        The session JSON only retains AGGREGATE per-turn `thinking` /
        `content` (not per-round), so the replay can't reproduce the
        exact live interleaving of "round 0 reasoning → tool_call →
        tool_result → round 1 reasoning". Instead we render:

            ❯ user
            🔧 tool_call₁  /  ✅ tool_result₁   (per round, in order)
            🔧 tool_call₂  /  ✅ tool_result₂
            …
            <assistant content + collapsible thinking + metrics>

        which is enough for the user to see what happened and pick up
        the conversation. Turns from the `/claude` bridge are tagged
        via `metrics.source == "claude"` and render as a `ClaudeMessage`
        instead of `AssistantMessage` so attribution stays clear.
        """
        transcript = self.query_one("#transcript", VerticalScroll)
        turns = data.get("turns") or []
        for t in turns:
            await self._render_one_saved_turn(transcript, t)
        self._maybe_scroll_end(transcript)
        return len(turns)

    async def _render_one_saved_turn(
        self, transcript: VerticalScroll, t: dict,
    ) -> None:
        """Render a single saved turn (user prompt + tool rounds +
        assistant content + thinking + abort/error markers) into the
        transcript. Shared by `_replay_session_into_transcript` (used
        on `/sessions` switch) and `_poll_session_for_external_turns`
        (used to surface turns appended by another frontend).
        """
        user_text = t.get("user") or ""
        metrics = t.get("metrics") or {}
        # Map a saved turn's ``metrics.source`` to the right replay
        # widget. The bridge writes ``source = <tool name>``
        # (``delegate_claude`` / ``delegate_codex`` / ``delegate_gemini``);
        # legacy sessions persisted ``"claude"`` / ``"codex"`` directly
        # — accept both shapes so /history replays from old runs still
        # render with the delegation badge.
        delegate_source: Optional[str] = None
        if isinstance(metrics, dict):
            raw = str(metrics.get("source") or "")
            if raw in ("claude", "delegate_claude"):
                delegate_source = "claude"
            elif raw in ("codex", "delegate_codex"):
                delegate_source = "codex"
            elif raw in ("gemini", "delegate_gemini"):
                delegate_source = "gemini"
        from_delegate = delegate_source is not None
        # Back-compat alias for the few places below that still talk
        # in the original "claude vs not" terms.
        from_claude = delegate_source == "claude"

        if user_text:
            # Strip the slash-command prefix from the displayed prompt
            # so the bubble shows the question, not the slash command —
            # same as the live ``_run_*`` paths do.
            shown = user_text
            if from_delegate:
                prefix = f"/{delegate_source} "
                if shown.startswith(prefix):
                    shown = shown[len(prefix):]
            await transcript.mount(UserMessage(f"❯ {shown}"))

        # Two on-disk shapes exist for tool calls on a saved turn:
        #
        # * Local-LLM engine: nested ``tool_rounds[].calls[]`` with
        #   per-call ``decision`` / ``result`` fields (one round per
        #   model<->tool exchange).
        # * CLI engines (claude_cli / codex_cli / gemini_cli): flat
        #   ``tool_calls[]`` and ``tool_results[]`` lists paired by
        #   ``call_id`` — the CLI runs tools internally and rtxclaw
        #   sees them as a single round.
        #
        # The legacy renderer only handled ``tool_rounds``, so CLI-engine
        # sessions on replay (``/sessions`` switch, cross-frontend poll)
        # showed the inline 🔧/↳ markers the runner glued into
        # ``content`` instead of expandable widgets. Render whichever
        # shape is present.
        tool_rounds_data = t.get("tool_rounds") or []
        flat_calls = t.get("tool_calls") or []
        flat_results = t.get("tool_results") or []
        had_widgets = False
        if tool_rounds_data:
            had_widgets = True
            for r in tool_rounds_data:
                for c in r.get("calls") or []:
                    name = c.get("name") or "?"
                    args = c.get("arguments") or {}
                    # ExitPlanMode / OutputSection replay as their
                    # dedicated cards — same shape as the live path —
                    # so a resumed session shows the body inline
                    # instead of the collapsed peek.
                    if name == "ExitPlanMode":
                        plan_text = ""
                        if isinstance(args, dict):
                            plan_text = str(args.get("plan") or "")
                        await transcript.mount(PlanMessage(plan_text))
                        continue
                    if name == "OutputSection":
                        section_name = ""
                        section_content = ""
                        if isinstance(args, dict):
                            section_name = str(args.get("section_name") or "")
                            section_content = str(args.get("content") or "")
                        await transcript.mount(
                            OutputSectionMessage(section_name, section_content)
                        )
                        continue
                    if name in ("Update", "Edit"):
                        # Replay a file edit as its "Update" diff card,
                        # matching the live path; the saved decision
                        # tells us whether it applied.
                        _a = args if isinstance(args, dict) else {}
                        _card = UpdateMessage(
                            str(_a.get("file_path") or ""),
                            str(_a.get("old_string") or ""),
                            str(_a.get("new_string") or ""),
                            replace_all=bool(_a.get("replace_all", False)),
                            call_id=str(c.get("id") or ""),
                        )
                        await transcript.mount(_card)
                        _card.mark_result((c.get("decision") or "allow") == "allow")
                        continue
                    await transcript.mount(ToolCallMessage(name, args))
                    # Replay TodoWrite calls into the plan-checklist so a
                    # resumed session shows the accumulated plan in the
                    # footer (matches what was visible when the session
                    # was last live).
                    if name in ("TodoWrite", "todo") and isinstance(args, dict):
                        self._handle_todo_tool_call(args)
                    cid = c.get("id") or ""
                    decision = c.get("decision") or "allow"
                    result = c.get("result") or ""
                    ok = decision == "allow"
                    await transcript.mount(
                        ToolResultMessage(cid, ok, result)
                    )
        elif flat_calls:
            had_widgets = True
            # Index results by call_id so we can pair them in the order
            # the calls fired. CLI engines emit results in call order in
            # practice, but be defensive — a missing result still mounts
            # an empty ToolResultMessage so the operator sees the call.
            results_by_cid: dict[str, dict] = {}
            for r in flat_results:
                if not isinstance(r, dict):
                    continue
                cid = str(r.get("call_id") or "")
                if cid:
                    results_by_cid[cid] = r
            for c in flat_calls:
                if not isinstance(c, dict):
                    continue
                name = str(c.get("name") or "?")
                args = c.get("arguments") or {}
                # ExitPlanMode / OutputSection replay as their
                # dedicated cards so a resumed CLI-engine session
                # shows the body, matching the live path.
                if name == "ExitPlanMode":
                    plan_text = ""
                    if isinstance(args, dict):
                        plan_text = str(args.get("plan") or "")
                    await transcript.mount(PlanMessage(plan_text))
                    continue
                if name == "OutputSection":
                    section_name = ""
                    section_content = ""
                    if isinstance(args, dict):
                        section_name = str(args.get("section_name") or "")
                        section_content = str(args.get("content") or "")
                    await transcript.mount(
                        OutputSectionMessage(section_name, section_content)
                    )
                    continue
                if name in ("Update", "Edit"):
                    # Replay a file edit as its "Update" diff card,
                    # matching the live path.
                    _a = args if isinstance(args, dict) else {}
                    _cid = str(c.get("call_id") or "")
                    _r = results_by_cid.get(_cid) or {}
                    _card = UpdateMessage(
                        str(_a.get("file_path") or ""),
                        str(_a.get("old_string") or ""),
                        str(_a.get("new_string") or ""),
                        replace_all=bool(_a.get("replace_all", False)),
                        call_id=_cid,
                    )
                    await transcript.mount(_card)
                    _card.mark_result(bool(_r.get("ok", True)))
                    continue
                await transcript.mount(ToolCallMessage(name, args))
                if name in ("TodoWrite", "todo") and isinstance(args, dict):
                    self._handle_todo_tool_call(args)
                cid = str(c.get("call_id") or "")
                r = results_by_cid.get(cid) or {}
                ok = bool(r.get("ok", True))
                result_text = str(r.get("content") or "")
                await transcript.mount(
                    ToolResultMessage(cid, ok, result_text)
                )

        content = t.get("content") or ""
        thinking = t.get("thinking") or ""
        # When we mounted widgets from the flat shape, drop the inline
        # 🔧/↳ markers from the prose body so the operator doesn't see
        # both. Safe no-op if the content carries no markers.
        if had_widgets and flat_calls and content:
            content = _strip_inline_tool_markers(content)
        if from_delegate:
            widget_cls = {
                "claude": ClaudeMessage,
                "codex": CodexMessage,
                "gemini": GeminiMessage,
            }[delegate_source]
            delegate_msg = widget_cls(from_replay=True)
            await transcript.mount(delegate_msg)
            if content:
                delegate_msg.append_content(content)
            saved_metrics = t.get("metrics") or {}
            if saved_metrics:
                delegate_msg.set_metrics(saved_metrics)
            delegate_msg.finalize()
        else:
            # `from_replay=True` skips the live prefill counter — these
            # are already-completed turns being re-rendered from the
            # session JSON, so a "▶ prefilling…" tick would be both
            # wrong (no prefill is happening) and visually noisy.
            a = AssistantMessage(from_replay=True)
            await transcript.mount(a)
            if thinking:
                await a.append_thinking(thinking)
            if content:
                a.append_content(content)
            saved_metrics = t.get("metrics") or {}
            if saved_metrics:
                a.set_metrics(saved_metrics)
            a.finalize()

        if t.get("aborted"):
            from rich.markup import escape as _esc
            await transcript.mount(Static(
                f"[dim]{_esc('_[turn aborted]_')}[/dim]",
                markup=True, classes="claude-msg",
            ))
        elif t.get("error"):
            from rich.markup import escape as _esc
            await transcript.mount(Static(
                f"[red]{_esc('_[error: ' + str(t['error']) + ']_')}[/red]",
                markup=True, classes="claude-msg",
            ))

    async def _poll_session_for_external_turns(self) -> None:
        """Pick up turns appended by other frontends (Telegram, another
        TUI, the OpenAI-compat API) and render them inline so the user
        sees both sides of a multi-frontend conversation live.

        - Skipped while `_current_turn_id is not None`: a live turn is
          rendering its own SSE events; the poll would double-render
          the in-flight turn the moment it lands on disk.
        - Compares `len(disk turns)` against `self._known_turn_count`;
          renders only the suffix slice and updates the counter so the
          next poll won't re-render the same turns.
        - Errors are swallowed: the poll runs every few seconds and
          stuttering the status bar with transient HTTP errors would
          be more annoying than useful. Real-world failures surface
          via the `_send_user_turn` / `_ensure_session` paths.
        """
        if (
            self._sid is None
            or self._current_turn_id is not None
            or self._client is None
        ):
            return
        try:
            data = await self._client.get_session(self._sid)
        except Exception:  # noqa: BLE001
            return
        turns = data.get("turns") or []
        if len(turns) <= self._known_turn_count:
            return
        new_turns = turns[self._known_turn_count:]
        transcript = self.query_one("#transcript", VerticalScroll)
        for t in new_turns:
            await self._render_one_saved_turn(transcript, t)
        self._known_turn_count = len(turns)
        # Keep `self.session.turns` in sync so other code that reads it
        # (status bar title, /claude preamble builder) sees the merged
        # view.
        if self.session is not None:
            self.session.turns = list(turns)
        self._maybe_scroll_end(transcript)
        self._set_status(
            f"+{len(new_turns)} turn(s) from another frontend"
        )

    async def _cmd_sessions(self, arg: str = "") -> None:
        """`/sessions` — list saved sessions (no arg) or switch to one
        (`/sessions <index|hash-prefix>`).

        - No arg: render the most-recent-first list inline so the user
          can see indices, short hashes, titles, turn counts, last
          activity timestamps, and the workspace cwd each session was
          opened from.
        - With arg: resolve to a session and switch the TUI's active
          `_sid` to it. The transcript is cleared (we don't replay past
          turns yet — the model still has them in its session record;
          they'll re-enter `_build_messages` on the next turn). Active
          turn is aborted before the switch lands.
        """
        if self._client is None:
            self._set_status("agent not connected")
            return
        try:
            sessions = await self._client.list_sessions()
        except Exception as e:  # noqa: BLE001
            self._set_status(f"/sessions list failed: {e}")
            return

        transcript = self.query_one("#transcript", VerticalScroll)

        if not arg:
            # Echo the slash command in the transcript regardless of
            # whether the modal opens. The modal lives on a separate
            # ModalScreen and the underlying transcript paints behind
            # it, so this UserMessage is the only durable evidence the
            # operator (or test_11_tui_commands::test_sessions_listing)
            # sees that ``/sessions`` was received once the modal is
            # dismissed without a pick.
            await transcript.mount(UserMessage("❯ /sessions"))
            if not sessions:
                await transcript.mount(Static(
                    "no sessions yet — start typing and the agent will create one.",
                    classes="claude-msg",
                ))
                return
            # Inline the count + active id so the operator (and
            # tmux-capture-based tests) see proof that the list
            # was fetched even when the modal closes via cancel/Esc.
            await transcript.mount(Static(
                f"{len(sessions)} session(s) — current "
                f"[{(self._sid or '')[:12]}]. Pick one in the modal.",
                classes="claude-msg",
            ))
            # Push the modal picker. `push_screen_wait` blocks this
            # worker until the user selects (returns hash) or cancels
            # (returns None / empty). The modal owns ↑/↓ navigation and
            # Enter/Esc bindings — same UX shape as `PermissionModal`.
            picked = await self.push_screen_wait(
                SessionPickerModal(sessions, current_sid=self._sid or ""),
            )
            if not picked:
                return  # cancelled
            target = next(
                (s for s in sessions if s.get("hash") == picked), None,
            )
            if target is None:
                self._set_status(f"/sessions: picked hash {picked[:12]} not in list")
                return
        else:
            # Arg-path: numeric index or hash-prefix. Hash-prefix
            # match wins when numeric parse fails or yields out-of-
            # range. Modal-path skips this and resolves directly above.
            target: Optional[dict] = None
            if arg.isdigit():
                idx = int(arg)
                if 1 <= idx <= len(sessions):
                    target = sessions[idx - 1]
            if target is None:
                matches = [
                    s for s in sessions
                    if (s.get("hash") or "").startswith(arg)
                ]
                if len(matches) == 1:
                    target = matches[0]
                elif len(matches) > 1:
                    self._set_status(
                        f"/sessions: ambiguous prefix {arg!r}, "
                        f"{len(matches)} matches — use a longer prefix"
                    )
                    return
            if target is None:
                self._set_status(f"/sessions: no match for {arg!r}")
                return

        new_sid = target.get("hash") or ""
        if new_sid == (self._sid or ""):
            self._set_status(f"already on session [{new_sid[:12]}]")
            return

        # Abort any in-flight turn before swapping the active session.
        if self._current_turn_id is not None:
            await self.action_abort(via="session_switch")
            for _ in range(50):
                if self._current_turn_id is None:
                    break
                await asyncio.sleep(0.02)

        # Wipe the current transcript before replaying — we don't want
        # the OLD session's widgets sitting above the NEW session's
        # replayed history.
        await transcript.remove_children()

        self._sid = new_sid
        # The /claude bridge is per-rtxclaw-session — switching means a
        # different `--resume` thread (no prior id, no synced turns).
        self._claude_session_id = None
        self._claude_synced_turn_idx = 0
        # Reset context tracking so the status bar doesn't show stale
        # token counts from the previous session.
        self._last_prompt_tokens = None
        self._last_context_window = None
        # Hydrate `self.session` so the title bar and metric helpers
        # don't lag behind the switch, then replay the saved turns
        # into the transcript so the user can scroll back through prior
        # history of the session they just switched to.
        replayed = 0
        try:
            data = await self._client.get_session(new_sid)
            self.session = Session(
                hash=data.get("hash") or new_sid,
                title=data.get("title") or "",
                created_at=data.get("created_at") or "",
                system_prompt=data.get("system_prompt") or "",
                model=data.get("model") or "",
                endpoint=data.get("endpoint") or "",
                turns=list(data.get("turns") or []),
                context_window=int(data.get("context_window") or 0),
            )
            self._refresh_title()
            replayed = await self._replay_session_into_transcript(data)
            # Anchor the cross-frontend poll at the replayed-count so
            # turns appended after this moment will surface as deltas.
            self._known_turn_count = len(data.get("turns") or [])
        except Exception as e:  # noqa: BLE001
            self._set_status(f"switched to [{new_sid[:12]}] — replay failed: {e}")
            return
        title = (target.get("title") or "(untitled)").strip()
        self._set_status(
            f"switched to [{new_sid[:12]}] — {title} ({replayed} turn(s) replayed)"
        )

    def _tui_log(self, event: str, **fields) -> None:
        """Append one JSON line to ``<agent_home>/logs/tui.log``.

        Captures key TUI-side moments (ESC pressed, action_abort entry,
        turn_stop success/fail) so a post-mortem can prove whether a
        keystroke ever reached the TUI and whether the cancel hit the
        wire — gateway.log only sees the server side, so on the
        2026-05-12 session we couldn't tell whether the user's earlier
        ESCs got dropped in Textual or in transit. Best-effort: any
        IO failure here must NEVER bubble into the input handler.
        """
        try:
            path = Path(self.agent_cfg.logs_dir) / "tui.log"
            path.parent.mkdir(parents=True, exist_ok=True)
            entry = {
                "ts": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                "event": event,
                "sid": (self._sid or "")[:12],
            }
            for k, v in fields.items():
                if v is not None and v != "":
                    entry[k] = v
            with open(path, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except Exception:  # noqa: BLE001
            pass

    async def action_abort(self, via: str = "esc") -> None:
        # Instant feedback (fix C). Set the status BEFORE any await
        # so the operator sees "abort received" the same tick they
        # pressed it — without this, a slow gateway cancel ack was
        # indistinguishable from "the keystroke was eaten by Textual"
        # in the 2026-05-12 deepseek-v4-flash post-mortem. The wall-
        # clock stamp makes a second press visibly distinct from the
        # first one. ``via`` is set by callers to distinguish how the
        # abort was triggered ("esc" ← priority binding default,
        # "slash" ← typed /abort, "new" / "agent_switch" /
        # "session_switch" ← internal teardown paths). Surfaces in
        # the status line + tui.log so a post-mortem can tell whether
        # the operator hit ESC or a code path fired it implicitly.
        pressed_at = time.strftime("%H:%M:%S")
        self._set_status(f"abort received {pressed_at} ({via}) — sending cancel…")
        self._tui_log(
            "abort_requested",
            via=via,
            ts_local=pressed_at,
            claude_tid=self._claude_turn_id,
            codex_tid=self._codex_turn_id,
            gemini_tid=self._gemini_turn_id,
            current_tid=self._current_turn_id,
            queued=len(self._turn_queue),
        )
        # ESC means "stop what I have going" — drop any pending prompts
        # in the queue too, so a long queued backlog doesn't keep firing
        # after the user explicitly bailed. The queued entries weren't
        # mounted to the transcript yet, so dropping them is silent.
        n_dropped = len(self._turn_queue)
        if n_dropped:
            self._turn_queue.clear()
            self._refresh_status_bar()
            self._refresh_queue_display()

        async def _send_cancel(tid: str, label: str) -> None:
            sent_at = time.strftime("%H:%M:%S")
            err: Optional[str] = None
            try:
                await self._client.turn_stop(tid)
            except Exception as e:  # noqa: BLE001
                err = str(e) or repr(e)
            suffix = f" + dropped {n_dropped} queued" if n_dropped else ""
            if err:
                self._set_status(
                    f"{label} cancel FAILED at {sent_at}: "
                    f"{err[:60]}{suffix}"
                )
                self._tui_log(
                    "turn_stop_failed",
                    target=label,
                    tid=tid,
                    error=err[:200],
                )
            else:
                self._set_status(
                    f"{label} cancel sent at {sent_at}{suffix}"
                )
                self._tui_log(
                    "turn_stop_ok",
                    target=label,
                    tid=tid,
                )

        # If a /claude delegate is in-flight, stop it via the same
        # `turn_stop` path used for normal turns — the server-side
        # `delegate_to_external` endpoint registers the tool runner
        # under that turn_id, so SIGTERM flows through the agent's
        # `TurnState.proc` and kills the claude CLI subprocess.
        if self._claude_turn_id is not None:
            await _send_cancel(self._claude_turn_id, "claude")
            return
        if self._codex_turn_id is not None:
            await _send_cancel(self._codex_turn_id, "codex")
            return
        if self._gemini_turn_id is not None:
            await _send_cancel(self._gemini_turn_id, "gemini")
            return
        if self._current_turn_id is None:
            if n_dropped:
                self._set_status(f"dropped {n_dropped} queued prompt(s)")
                self._tui_log("esc_dropped_queue_only", queued=n_dropped)
            else:
                # Nothing in flight, nothing queued — surface the
                # no-op so /abort isn't a silent keystroke. Without
                # this the operator can't tell whether the bind even
                # registered when they hit ESC on an idle session.
                self._set_status("nothing to abort — no turn in flight")
                self._tui_log("esc_noop")
            return
        await _send_cancel(self._current_turn_id, "agent")

    def on_worker_state_changed(self, event) -> None:  # noqa: ANN001
        """Capture worker exceptions into the structured error log.

        Textual `run_worker(coro, …)` swallows exceptions into the
        worker's `state = ERROR` and `_error` attributes, prints a
        traceback to the dev console, but doesn't crash the app. We
        listen for the state change here and persist the error so the
        agent (or the user) can review it later out-of-band.
        """
        try:
            from textual.worker import WorkerState
        except Exception:  # noqa: BLE001
            return
        worker = getattr(event, "worker", None)
        state = getattr(worker, "state", None)
        if state != WorkerState.ERROR or worker is None:
            return
        exc = getattr(worker, "_error", None) or getattr(worker, "error", None)
        if not isinstance(exc, BaseException):
            return
        try:
            from rtxclaw_core import errors as _errors
            _errors.log_error(
                f"tui:{worker.name or 'worker'}",
                exc,
                summary=f"Textual worker '{worker.name}' raised {type(exc).__name__}",
                context={
                    "worker_name": worker.name,
                    "worker_description": str(worker.description)[:200],
                    "permission_mode": self._permission_mode,
                    "claude_session_id": self._claude_session_id,
                },
            )
        except Exception:  # noqa: BLE001
            # Logging errors must never themselves break the app.
            pass

    async def _run_claude(self, prompt: str) -> None:
        """Desugar `/claude <prompt>` to the `delegate_claude` tool.

        Routes through the agent's `POST /v1/sessions/{sid}/delegate`
        endpoint, which spawns the same `delegate_claude` tool runner
        the local model would use if it emitted the call autonomously.
        One path, one runner, one kill mechanism (per the foundational
        rule in CLAUDE.md: external agent bridges are tools, not slash
        commands or frontend-special-cased subprocess spawns).

        - Claude session reuse: server-side state file at
          `<sessions_dir>/<sid>.delegate_claude.json` (managed by the
          tool runner) — no TUI tracking needed.
        - Preamble: built locally from unsynced rtxclaw turns and
          prepended to the user's prompt so a follow-up like
          `/claude research more on this` resolves "this" against the
          prior local-model exchange. (When the local model emits the
          delegate tool call autonomously, it can pick context itself
          without the preamble; the slash command can't, since the
          user types raw text.)
        - Persistence: the server endpoint stores the result as a turn
          with `metrics.source = "claude"`, so `_build_messages` wraps
          it with attribution on the next local-model turn.
        - ESC: server tracks the running tool process under `turn_id`,
          so the abort path is the standard `turn_stop(turn_id)` we
          use for normal turns.
        - Streaming: Claude's text deltas flow through the runner's
          `on_delta` callback into `tool_call_update` ACP events,
          which the TUI renders into the inline `ClaudeMessage`
          widget.
        """
        transcript = self.query_one("#transcript", VerticalScroll)
        await transcript.mount(UserMessage(f"❯ /claude {prompt}"))
        msg = ClaudeMessage()
        await transcript.mount(msg)
        self._maybe_scroll_end(transcript)

        if self._sid is None or self._client is None:
            msg.mark_error("no active session — start one before using /claude")
            self._set_status("/claude requires an active session")
            return

        # Build the rtxclaw-context preamble. We pull the latest session
        # state from the agent (rather than self.session, which is only
        # refreshed at end-of-turn) so /claude after a long local-model
        # turn sees that turn too. Failures here are non-fatal — the
        # /claude run still happens, just without preamble.
        preamble = ""
        synced_after_call = self._claude_synced_turn_idx
        try:
            sess = await self._client.get_session(self._sid)
            turns = list(sess.get("turns") or [])
            start = max(0, self._claude_synced_turn_idx)
            unsynced = turns[start:]
            preamble = _build_delegate_preamble(
                unsynced,
                is_first_call=(self._claude_session_id is None),
                skip_source="claude",
            )
            synced_after_call = len(turns)
        except Exception:  # noqa: BLE001
            pass
        self._claude_pending_synced_idx = synced_after_call

        full_prompt = (preamble + prompt) if preamble else prompt

        claude_mode = _claude_permission_mode(self._permission_mode)
        resume_label = (
            f"resume={self._claude_session_id[:8]}…"
            if self._claude_session_id else "new session"
        )
        # Persistent indicator (survives transient `_set_status` writes
        # like "reasoning expanded") so the user always sees /claude is
        # in flight.
        self._set_worker_state(
            "[bold magenta]🤖 claude running…[/bold magenta]",
            detail="[dim]ESC to cancel[/dim]",
        )

        delegate_turn_id: Optional[str] = None
        # Direct-dispatch path emits ACP tool_call / tool_call_update
        # events. agent_client.session_turn translates them to
        # ``tool_call``, ``tool_delta``, ``tool_result``, ``done``.
        # Track terminal status so we can mark the message ok / error.
        delegate_done = False
        delegate_ok = False
        delegate_errored = False
        # The bridge announces ONE outer tool_call (title
        # ``delegate_claude``) plus zero-or-more inner tool_calls for
        # Claude's own ``Read`` / ``Bash`` / ``TodoWrite`` / etc.
        # blocks — the inner ones carry a ``.inner.`` segment in
        # their call_id. Distinguishing the two lets the outer
        # tool_delta / tool_result keep streaming into the
        # ClaudeMessage body while the inner ones get rendered as
        # native rtxclaw widgets (ToolCallMessage + ToolResultMessage,
        # TodoWrite tick-through into the plan checklist).
        outer_call_id: Optional[str] = None
        # Wall-clock timing for the per-call metrics row. Mirrors the
        # native-turn shape (``wt`` / ``ttft`` / ``gen`` / ``out``) so
        # /claude turns have the same telemetry footer as a gpu-a-served
        # turn — operators can compare them side by side. We don't get
        # real prefill/cache numbers from Claude Code, so the row is
        # marked ``tokens_estimated`` and the prompt-token segment is
        # omitted.
        delegate_t0 = time.monotonic()
        delegate_first_chunk_at: Optional[float] = None
        delegate_chars = 0

        def _is_outer(call_id: str) -> bool:
            if outer_call_id is None:
                return True
            return call_id == outer_call_id

        try:
            async for event_name, data, turn_id in self._client.delegate(
                self._sid,
                prompt=full_prompt,
                tool="delegate_claude",
                mode=self._permission_mode,
            ):
                if turn_id and delegate_turn_id is None:
                    delegate_turn_id = turn_id
                    self._claude_turn_id = turn_id
                if event_name == "started":
                    continue
                if event_name in ("delta", "tool_delta"):
                    # Outer-call streaming text only. Inner tool deltas
                    # would carry a different call_id; ignore them
                    # here so they don't leak Claude's tool stdout
                    # into the prose pane.
                    call_id = str(data.get("call_id") or "")
                    if outer_call_id and call_id and call_id != outer_call_id:
                        continue
                    txt = data.get("text") or ""
                    if txt:
                        if delegate_first_chunk_at is None:
                            delegate_first_chunk_at = time.monotonic()
                        delegate_chars += len(txt)
                        msg.append_content(txt)
                        self._maybe_scroll_end(transcript)
                    continue
                if event_name == "tool_call":
                    call_id = str(data.get("call_id") or "")
                    tool_name = str(data.get("tool") or "?")
                    # First tool_call is the outer delegate_claude
                    # itself — no widget for it, ClaudeMessage already
                    # owns the body.
                    if outer_call_id is None:
                        outer_call_id = call_id
                        continue
                    if call_id == outer_call_id:
                        continue
                    # Inner Claude tool: render as a native widget.
                    # TodoWrite additionally ticks the plan checklist
                    # via the existing handler — that's the path that
                    # makes ``/claude`` plans show up the same way a
                    # local-model plan does.
                    if tool_name in ("TodoWrite", "todo"):
                        self._handle_todo_tool_call(
                            data.get("arguments") or {},
                        )
                    inner_args = data.get("arguments") or {}
                    if tool_name == "ExitPlanMode":
                        plan_text = str(inner_args.get("plan") or "")
                        await transcript.mount(PlanMessage(plan_text))
                        if call_id:
                            self._plan_call_ids.add(call_id)
                    elif tool_name == "OutputSection":
                        section_name = str(inner_args.get("section_name") or "")
                        section_content = str(inner_args.get("content") or "")
                        await transcript.mount(
                            OutputSectionMessage(section_name, section_content)
                        )
                        if call_id:
                            self._section_call_ids.add(call_id)
                    elif tool_name in ("Update", "Edit"):
                        # Claude's inner file edits get the same
                        # "Update" diff-card treatment as a local-model
                        # edit — Claude Code itself labels `Edit` as
                        # "Update", so this matches the delegate's own
                        # UI exactly.
                        await transcript.mount(
                            UpdateMessage(
                                str(inner_args.get("file_path") or ""),
                                str(inner_args.get("old_string") or ""),
                                str(inner_args.get("new_string") or ""),
                                replace_all=bool(
                                    inner_args.get("replace_all", False)
                                ),
                                call_id=call_id,
                            )
                        )
                        if call_id:
                            self._update_call_ids.add(call_id)
                    else:
                        await transcript.mount(
                            ToolCallMessage(tool_name, inner_args)
                        )
                    self._maybe_scroll_end(transcript)
                    continue
                if event_name == "tool_result":
                    call_id = str(data.get("call_id") or "")
                    if outer_call_id is not None and not _is_outer(call_id):
                        # Inner Claude tool's terminal result. Mount a
                        # ToolResultMessage so the operator can fold
                        # open Read/Bash/etc. output. TodoWrite's
                        # result body is a recap of the plan — fine to
                        # show inline alongside the plan widget.
                        if call_id in self._plan_call_ids:
                            self._plan_call_ids.discard(call_id)
                            self._maybe_scroll_end(transcript)
                            continue
                        ok = bool(data.get("ok", True))
                        content = data.get("content") or ""
                        if call_id in self._section_call_ids:
                            self._section_call_ids.discard(call_id)
                            if ok:
                                self._maybe_scroll_end(transcript)
                                continue
                        if call_id in self._update_call_ids:
                            self._update_call_ids.discard(call_id)
                            card = next(
                                (w for w in transcript.query(UpdateMessage)
                                 if w.call_id == call_id),
                                None,
                            )
                            if card is not None:
                                card.mark_result(ok)
                            if ok:
                                self._maybe_scroll_end(transcript)
                                continue
                        await transcript.mount(
                            ToolResultMessage(call_id, ok, content)
                        )
                        self._maybe_scroll_end(transcript)
                        continue
                    # Outer delegate terminal: surface the body.
                    delegate_done = True
                    ok = bool(data.get("ok", False))
                    content = data.get("content") or ""
                    delegate_ok = ok
                    if not msg.content_text:
                        if delegate_first_chunk_at is None:
                            delegate_first_chunk_at = time.monotonic()
                        delegate_chars += len(content)
                        msg.append_content(content)
                        self._maybe_scroll_end(transcript)
                    if not ok:
                        delegate_errored = True
                        err = (content or "claude failed")[:300]
                        msg.mark_error(err)
                        self._set_status(f"claude error: {err[:80]}")
                    continue
                if event_name == "error":
                    err = (data.get("error") or data.get("message")
                           or "delegate failed")[:300]
                    delegate_errored = True
                    msg.mark_error(err)
                    self._set_status(f"claude error: {err[:80]}")
                    return
                if event_name == "done":
                    ok = delegate_ok if delegate_done else (
                        data.get("state") != "error"
                    )
                    if not ok and not delegate_errored:
                        err = (msg.content_text or "claude failed")[:300]
                        msg.mark_error(err)
                        self._set_status(f"claude error: {err[:80]}")
                        return
                    if delegate_errored:
                        return
                    # Stamp a metrics row on the delegated turn so it
                    # reads the same as a native turn (model · ttft ·
                    # gen tps · out · wt).
                    delegate_metrics = _build_delegate_metrics(
                        label="claude",
                        t0=delegate_t0,
                        first_chunk_at=delegate_first_chunk_at,
                        chars=delegate_chars,
                    )
                    if delegate_metrics:
                        msg.set_metrics(delegate_metrics)
                    msg.finalize(self._claude_session_id)
                    self._claude_synced_turn_idx = self._claude_pending_synced_idx + 1
                    # The agent appended one /claude turn to the saved
                    # session — keep `_known_turn_count` in sync with
                    # the disk row count so the cross-frontend poller
                    # doesn't treat our just-finished /claude reply as
                    # "external" and re-render it.
                    if self._sid is not None:
                        try:
                            data = await self._client.get_session(self._sid)
                            self._known_turn_count = len(data.get("turns") or [])
                            if self.session is not None:
                                self.session.turns = list(data.get("turns") or [])
                        except Exception:  # noqa: BLE001
                            self._known_turn_count += 1
                    sid_short = (self._claude_session_id or "?")[:12]
                    self._set_status(
                        f"claude done · session={sid_short} (saved)"
                    )
                    return
        except asyncio.CancelledError:
            # ESC landed during the delegate stream. Best-effort tell
            # the server to kill the tool runner — the streaming GET is
            # already cancelled, so the task we're in is unwinding.
            if delegate_turn_id:
                try:
                    await self._client.turn_stop(delegate_turn_id)
                except Exception:  # noqa: BLE001
                    pass
            msg.mark_aborted()
            raise
        except Exception as e:  # noqa: BLE001
            msg.mark_error(f"{e}"[:300])
            self._set_status(f"claude error: {e}"[:80])
        finally:
            self._claude_turn_id = None
            self._set_worker_state("")
            # Drain the queue so any prompts/claude calls submitted while
            # this one was running fire next.
            self._maybe_start_next()

    async def _run_codex(self, prompt: str) -> None:
        """Desugar `/codex <prompt>` to the `delegate_codex` tool.

        Mirrors `_run_claude` 1:1 against the Codex CLI: routes through
        the same `POST /v1/sessions/{sid}/delegate` endpoint, just with
        `tool="delegate_codex"`. Codex thread reuse, ESC-to-abort,
        unsynced-turn preamble, server-side persistence with
        `metrics.source = "codex"` — all the same machinery as
        `_run_claude`, parametrised on the codex-specific state.
        """
        transcript = self.query_one("#transcript", VerticalScroll)
        await transcript.mount(UserMessage(f"❯ /codex {prompt}"))
        msg = CodexMessage()
        await transcript.mount(msg)
        self._maybe_scroll_end(transcript)

        if self._sid is None or self._client is None:
            msg.mark_error("no active session — start one before using /codex")
            self._set_status("/codex requires an active session")
            return

        # Build the rtxclaw-context preamble — same logic as /claude.
        preamble = ""
        synced_after_call = self._codex_synced_turn_idx
        try:
            sess = await self._client.get_session(self._sid)
            turns = list(sess.get("turns") or [])
            start = max(0, self._codex_synced_turn_idx)
            unsynced = turns[start:]
            preamble = _build_delegate_preamble(
                unsynced,
                is_first_call=(self._codex_thread_id is None),
                skip_source="codex",
            )
            synced_after_call = len(turns)
        except Exception:  # noqa: BLE001
            pass
        self._codex_pending_synced_idx = synced_after_call

        full_prompt = (preamble + prompt) if preamble else prompt

        sandbox_label = _codex_sandbox_label(self._permission_mode)
        resume_label = (
            f"resume={self._codex_thread_id[:8]}…"
            if self._codex_thread_id else "new thread"
        )
        self._set_worker_state(
            "[bold magenta]🛠 codex running…[/bold magenta]",
            detail="[dim]ESC to cancel[/dim]",
        )

        delegate_turn_id: Optional[str] = None
        delegate_done = False
        delegate_ok = False
        delegate_errored = False
        # Same timing capture as ``_run_claude`` — synthesize a
        # native-style metrics row so /codex turns are comparable
        # to local turns at a glance.
        delegate_t0 = time.monotonic()
        delegate_first_chunk_at: Optional[float] = None
        delegate_chars = 0
        try:
            async for event_name, data, turn_id in self._client.delegate(
                self._sid,
                prompt=full_prompt,
                tool="delegate_codex",
                mode=self._permission_mode,
            ):
                if turn_id and delegate_turn_id is None:
                    delegate_turn_id = turn_id
                    self._codex_turn_id = turn_id
                if event_name == "started":
                    continue
                if event_name in ("delta", "tool_delta"):
                    txt = data.get("text") or ""
                    if txt:
                        if delegate_first_chunk_at is None:
                            delegate_first_chunk_at = time.monotonic()
                        delegate_chars += len(txt)
                        msg.append_content(txt)
                        self._maybe_scroll_end(transcript)
                    continue
                if event_name == "tool_call":
                    # Direct-dispatch announce — no visible widget; the
                    # ClaudeMessage / CodexMessage shows the body once
                    # tool_result lands.
                    continue
                if event_name == "tool_result":
                    delegate_done = True
                    ok = bool(data.get("ok", False))
                    content = data.get("content") or ""
                    delegate_ok = ok
                    if not msg.content_text:
                        if delegate_first_chunk_at is None:
                            delegate_first_chunk_at = time.monotonic()
                        delegate_chars += len(content)
                        msg.append_content(content)
                        self._maybe_scroll_end(transcript)
                    if not ok:
                        delegate_errored = True
                        err = (content or "codex failed")[:300]
                        msg.mark_error(err)
                        self._set_status(f"codex error: {err[:80]}")
                    continue
                if event_name == "error":
                    err = (data.get("error") or data.get("message")
                           or "delegate failed")[:300]
                    delegate_errored = True
                    msg.mark_error(err)
                    self._set_status(f"codex error: {err[:80]}")
                    return
                if event_name == "done":
                    if delegate_errored:
                        return
                    ok = delegate_ok if delegate_done else (
                        data.get("state") != "error"
                    )
                    if not ok:
                        err = (msg.content_text or "codex failed")[:300]
                        msg.mark_error(err)
                        self._set_status(f"codex error: {err[:80]}")
                        return
                    delegate_metrics = _build_delegate_metrics(
                        label="codex",
                        t0=delegate_t0,
                        first_chunk_at=delegate_first_chunk_at,
                        chars=delegate_chars,
                    )
                    if delegate_metrics:
                        msg.set_metrics(delegate_metrics)
                    msg.finalize(self._codex_thread_id)
                    self._codex_synced_turn_idx = self._codex_pending_synced_idx + 1
                    if self._sid is not None:
                        try:
                            data = await self._client.get_session(self._sid)
                            self._known_turn_count = len(data.get("turns") or [])
                            if self.session is not None:
                                self.session.turns = list(data.get("turns") or [])
                        except Exception:  # noqa: BLE001
                            self._known_turn_count += 1
                    tid_short = (self._codex_thread_id or "?")[:12]
                    self._set_status(
                        f"codex done · thread={tid_short} (saved)"
                    )
                    return
        except asyncio.CancelledError:
            if delegate_turn_id:
                try:
                    await self._client.turn_stop(delegate_turn_id)
                except Exception:  # noqa: BLE001
                    pass
            msg.mark_aborted()
            raise
        except Exception as e:  # noqa: BLE001
            msg.mark_error(f"{e}"[:300])
            self._set_status(f"codex error: {e}"[:80])
        finally:
            self._codex_turn_id = None
            self._set_worker_state("")
            self._maybe_start_next()

    async def _run_gemini(self, prompt: str) -> None:
        """Desugar `/gemini <prompt>` to the `delegate_gemini` tool.

        Mirrors `_run_claude` and `_run_codex` against the Google
        Gemini CLI: routes through the same agent delegate endpoint
        with `tool="delegate_gemini"`. Gemini session reuse,
        ESC-to-abort, unsynced-turn preamble, server-side persistence
        with `metrics.source = "delegate_gemini"` — all the same
        machinery, parametrised on the gemini-specific state
        (`_gemini_session_id`, `_gemini_turn_id`,
        `_gemini_pending_synced_idx`, `_gemini_synced_turn_idx`).
        """
        transcript = self.query_one("#transcript", VerticalScroll)
        await transcript.mount(UserMessage(f"❯ /gemini {prompt}"))
        msg = GeminiMessage()
        await transcript.mount(msg)
        self._maybe_scroll_end(transcript)

        if self._sid is None or self._client is None:
            msg.mark_error("no active session — start one before using /gemini")
            self._set_status("/gemini requires an active session")
            return

        preamble = ""
        synced_after_call = self._gemini_synced_turn_idx
        try:
            sess = await self._client.get_session(self._sid)
            turns = list(sess.get("turns") or [])
            start = max(0, self._gemini_synced_turn_idx)
            unsynced = turns[start:]
            preamble = _build_delegate_preamble(
                unsynced,
                is_first_call=(self._gemini_session_id is None),
                skip_source="gemini",
            )
            synced_after_call = len(turns)
        except Exception:  # noqa: BLE001
            pass
        self._gemini_pending_synced_idx = synced_after_call

        full_prompt = (preamble + prompt) if preamble else prompt

        self._set_worker_state(
            "[bold magenta]✨ gemini running…[/bold magenta]",
            detail="[dim]ESC to cancel[/dim]",
        )

        delegate_turn_id: Optional[str] = None
        delegate_done = False
        delegate_ok = False
        delegate_errored = False
        delegate_t0 = time.monotonic()
        delegate_first_chunk_at: Optional[float] = None
        delegate_chars = 0
        try:
            async for event_name, data, turn_id in self._client.delegate(
                self._sid,
                prompt=full_prompt,
                tool="delegate_gemini",
                mode=self._permission_mode,
            ):
                if turn_id and delegate_turn_id is None:
                    delegate_turn_id = turn_id
                    self._gemini_turn_id = turn_id
                if event_name == "started":
                    continue
                if event_name in ("delta", "tool_delta"):
                    txt = data.get("text") or ""
                    if txt:
                        if delegate_first_chunk_at is None:
                            delegate_first_chunk_at = time.monotonic()
                        delegate_chars += len(txt)
                        msg.append_content(txt)
                        self._maybe_scroll_end(transcript)
                    continue
                if event_name == "tool_call":
                    continue
                if event_name == "tool_result":
                    delegate_done = True
                    ok = bool(data.get("ok", False))
                    content = data.get("content") or ""
                    delegate_ok = ok
                    if not msg.content_text:
                        if delegate_first_chunk_at is None:
                            delegate_first_chunk_at = time.monotonic()
                        delegate_chars += len(content)
                        msg.append_content(content)
                        self._maybe_scroll_end(transcript)
                    if not ok:
                        delegate_errored = True
                        err = (content or "gemini failed")[:300]
                        msg.mark_error(err)
                        self._set_status(f"gemini error: {err[:80]}")
                    continue
                if event_name == "error":
                    err = (data.get("error") or data.get("message")
                           or "delegate failed")[:300]
                    delegate_errored = True
                    msg.mark_error(err)
                    self._set_status(f"gemini error: {err[:80]}")
                    return
                if event_name == "done":
                    if delegate_errored:
                        return
                    ok = delegate_ok if delegate_done else (
                        data.get("state") != "error"
                    )
                    if not ok:
                        err = (msg.content_text or "gemini failed")[:300]
                        msg.mark_error(err)
                        self._set_status(f"gemini error: {err[:80]}")
                        return
                    delegate_metrics = _build_delegate_metrics(
                        label="gemini",
                        t0=delegate_t0,
                        first_chunk_at=delegate_first_chunk_at,
                        chars=delegate_chars,
                    )
                    if delegate_metrics:
                        msg.set_metrics(delegate_metrics)
                    msg.finalize(self._gemini_session_id)
                    self._gemini_synced_turn_idx = self._gemini_pending_synced_idx + 1
                    if self._sid is not None:
                        try:
                            data = await self._client.get_session(self._sid)
                            self._known_turn_count = len(data.get("turns") or [])
                            if self.session is not None:
                                self.session.turns = list(data.get("turns") or [])
                        except Exception:  # noqa: BLE001
                            self._known_turn_count += 1
                    sid_short = (self._gemini_session_id or "?")[:12]
                    self._set_status(
                        f"gemini done · session={sid_short} (saved)"
                    )
                    return
        except asyncio.CancelledError:
            if delegate_turn_id:
                try:
                    await self._client.turn_stop(delegate_turn_id)
                except Exception:  # noqa: BLE001
                    pass
            msg.mark_aborted()
            raise
        except Exception as e:  # noqa: BLE001
            msg.mark_error(f"{e}"[:300])
            self._set_status(f"gemini error: {e}"[:80])
        finally:
            self._gemini_turn_id = None
            self._set_worker_state("")
            self._maybe_start_next()

    async def _send_user_turn(self, text: str) -> None:
        # Defence-in-depth: callers should go through `_enqueue_or_run`
        # to avoid clobbering an in-flight turn, but if anything reaches
        # us while busy, push to the queue rather than dropping the input.
        if self._is_busy():
            self._turn_queue.append(("prompt", text))
            self._set_status(
                f"queued ({len(self._turn_queue)} pending) — "
                f"will run when current turn finishes"
            )
            self._refresh_status_bar()
            self._refresh_queue_display()
            return
        # Recover from a previous failed session-create (e.g. transient agent
        # or upstream blip): try once more on the user's next input rather
        # than locking them out until they restart the TUI.
        if self._sid is None and not await self._ensure_session():
            return
        # ``/restart`` (or a watcher tear-down) leaves ``self._client = None``
        # while the gateway is bouncing. Without a guard the submit path
        # crashes downstream with ``'NoneType' object has no attribute
        # 'session_turn'``. Drive an explicit reconnect on the user's next
        # input rather than asking them to re-type after the TUI heals.
        if self._client is None:
            self._set_status("⟳ reconnecting to gateway…")
            try:
                await self._reconnect_after_restart()
            except Exception as e:  # noqa: BLE001
                self._set_status(f"reconnect failed: {e} — retry the prompt")
                return
            if self._client is None:
                self._set_status(
                    "gateway still warming up — wait a moment then retry"
                )
                return
            # Reattach to the existing session id if possible; if the agent
            # forgot the sid (process bounced), drop to a fresh session so
            # the prompt isn't sent against an orphan id.
            if self._sid is not None:
                try:
                    await self._client.attach_session(
                        self._sid, cwd=os.getcwd(),
                    )
                except Exception:  # noqa: BLE001
                    self._sid = None
                    if not await self._ensure_session():
                        return

        transcript = self.query_one("#transcript", VerticalScroll)
        # Slash-command compact echo: when the prompt was expanded
        # from a builtin command file, the operator typed something
        # short (``/goal X``) and shouldn't see the full markdown
        # body printed in the transcript. The dispatcher stashes the
        # compact form in ``self._next_user_echo`` right before
        # calling here; we use it for the UserMessage, then clear it
        # so the next free-form prompt echoes verbatim.
        _echo = getattr(self, "_next_user_echo", None) or text
        self._next_user_echo = None
        await transcript.mount(UserMessage(f"❯ {_echo}"))
        # Two-phase scroll: the immediate call covers the common case;
        # `call_after_refresh` re-scrolls AFTER Textual lays out the new
        # widget, which is when scroll_end actually has the right
        # target height. Without the second call, the user's message
        # only became visible once the first thinking/content chunk
        # arrived and triggered another scroll — the user-reported bug.
        # User-action scroll: the operator hit Enter, they explicitly
        # want their new message visible. Bypass the auto-follow gate
        # so they land at the bottom even if they were reading back,
        # and re-arm follow-mode for subsequent passive chunks.
        self._scroll_follow = True
        transcript.scroll_end(animate=False)
        self.call_after_refresh(
            lambda: transcript.scroll_end(animate=False)
        )
        # AssistantMessage is mounted lazily on the first `chunk` event of
        # each LLM round — that way the transcript reads chronologically:
        #     ❯ user → reasoning₁ → 🔧 tool_call → ✅ tool_result → reasoning₂ …
        # When a `tool_call` event arrives mid-turn we finalize the current
        # AssistantMessage and clear `_current_assistant`; the next chunk
        # mounts a fresh one below the tool widgets. Avoids the "all chunks
        # stack into one widget at the top, tools dangle below" bug.
        self._current_assistant = None
        self._current_user_text = text
        # Wipe any stale in-flight tool_call_ids from a prior turn (an
        # ESC abort or transport drop can leave the set non-empty);
        # otherwise the next-round eager assistant mount would be
        # suppressed forever on this fresh turn.
        self._pending_tool_calls.clear()
        self._plan_call_ids.clear()
        self._section_call_ids.clear()

        # `exclusive=False`: the dispatcher (`_enqueue_or_run`) guarantees
        # we never overlap turns, so we don't need Textual to cancel old
        # workers — and `exclusive=True` would cancel a still-running
        # `_run_claude` if the user submits a plain prompt right after.
        self.run_worker(self._stream_via_agent(text), exclusive=False, name="stream")

    async def _stream_via_agent(self, text: str) -> None:
        transcript = self.query_one("#transcript", VerticalScroll)
        self._set_worker_state(
            "[bold green]▶ streaming…[/bold green]",
            detail="[dim]ESC to cancel[/dim]",
        )
        self._tui_log("stream_start", prompt_chars=len(text))
        worker_metrics: Optional[dict] = None
        worker_error: Optional[str] = None

        async def _ensure_assistant() -> AssistantMessage:
            """Lazily mount a new AssistantMessage; the active round writes here.

            Stays on `self._current_assistant` between events. A `tool_call`
            event finalizes and clears it; the next `chunk` triggers another
            mount. That's how the transcript ordering stays chronological
            across multi-round tool-use turns.

            Late-chunk catch-up: if the assistant was just finalized but
            no other widget has mounted yet (the bridge emitted a stray
            trailing chunk AFTER the tool_call event, common with
            deepseek-v4-pro mid-sentence tool dispatches), reuse the
            last finalized assistant so the trailing text appears in
            the same bubble — operator no longer sees ``with correct
            `name` par`` chopped before the tool widget. Only fires
            when the LAST transcript child is still the just-finalized
            assistant; once anything else mounts (the tool widget),
            the new round mounts a fresh bubble below.
            """
            if self._current_assistant is None:
                # If the last transcript child is still a finalized
                # AssistantMessage (no tool widget mounted since the
                # finalize call), reuse it — the new chunk is the
                # trailing tail of the just-closed round, NOT a new
                # round's lead. Without this, deepseek-v4-pro's
                # mid-sentence tool dispatches produced ``with
                # correct `name` par`` in bubble N and ``ameter.`` in
                # an orphan bubble N+1 below the tool widget — the
                # operator only saw the cutoff. ``append_content``
                # re-renders through RichMarkdown when the bubble is
                # already finalized.
                children = list(transcript.children)
                if children:
                    tail = children[-1]
                    if (
                        isinstance(tail, AssistantMessage)
                        and getattr(tail, "_final", False)
                    ):
                        self._current_assistant = tail
                        return tail
                a = AssistantMessage()
                await transcript.mount(a)
                self._current_assistant = a
                self._maybe_scroll_end(transcript)
            return self._current_assistant

        # Eagerly mount the first round's AssistantMessage BEFORE the SSE
        # loop opens — its on_mount kicks off the prefill (TTFT) counter
        # so the user sees a live "▶ prefilling… 0.4s" line tick up while
        # the upstream model is still chewing on the prompt. Without this
        # eager mount the first visible widget after Enter would be the
        # thinking box that only appears once the first reasoning chunk
        # lands, leaving the screen looking frozen for several seconds on
        # large prompts.
        await _ensure_assistant()

        def _close_round_assistant() -> None:
            """Finalize the active AssistantMessage and clear the slot.

            ``_ensure_assistant`` re-routes any chunk that arrives
            before another widget mounts back to this same bubble (by
            checking whether the last transcript child is still a
            finalized AssistantMessage) so the "deepseek mid-sentence
            tool dispatch" race doesn't strand the trailing text in
            an orphan bubble below the tool widget.
            """
            if self._current_assistant is not None:
                self._current_assistant.finalize()
                self._current_assistant = None

        try:
            async for event, data, tid in self._client.session_turn(
                self._sid,
                user=text,
                enable_thinking=self.enable_thinking,
                permission_mode=self._permission_mode,
            ):
                if tid:
                    self._current_turn_id = tid
                if event == "started":
                    continue
                if event == "chunk":
                    delta = (data.get("choices") or [{}])[0].get("delta") or {}
                    rc = delta.get("reasoning") or delta.get("reasoning_content")
                    txt = delta.get("content")
                    if not (rc or txt):
                        continue
                    # Runtime-warning sniff: the bridge formats loop /
                    # nudge / distill / force-terminate alerts as a
                    # single chunk whose body starts with one of the
                    # `_format_runtime_warning` glyph prefixes
                    # (acp_bridge.py L1153). Route those to a dedicated
                    # `RuntimeWarningNotice` widget instead of letting
                    # them blend into the assistant message bubble —
                    # without this branch a "loop detected, distilling
                    # and retrying" event is just three lines of text
                    # inside the model's normal prose, easy to miss
                    # entirely. Suppress the regular append so the
                    # warning doesn't ALSO show up inside the bubble.
                    if txt:
                        parsed = _parse_runtime_warning_chunk(txt)
                        if parsed is not None:
                            glyph, warn_event, fields = parsed
                            await transcript.mount(
                                RuntimeWarningNotice(glyph, warn_event, fields),
                            )
                            self._maybe_scroll_end(transcript)
                            # Surface in the status bar too so the
                            # operator notices even when scrolled back —
                            # the banner is the persistent record, this
                            # is the live cue.
                            try:
                                head = _RUNTIME_WARNING_HEADLINES.get(
                                    warn_event, warn_event,
                                )
                                self._set_status(f"{glyph} {head}")
                            except Exception:  # noqa: BLE001
                                pass
                            continue
                    a = await _ensure_assistant()
                    if rc and getattr(self, "reasoning_visibility", "on") != "off":
                        await a.append_thinking(rc)
                    if txt:
                        a.append_content(txt)
                    self._maybe_scroll_end(transcript)
                elif event == "metrics":
                    worker_metrics = data
                    # Per-model-call metrics: stamp THIS round's stats
                    # line under the current AssistantMessage so each
                    # model call carries its own visible telemetry.
                    # Multi-tool turns thus get one stats row per round.
                    if self._current_assistant is not None:
                        self._current_assistant.set_metrics(data)
                    pt = data.get("prompt_tokens")
                    if isinstance(pt, (int, float)) and pt > 0:
                        self._last_prompt_tokens = int(pt)
                    ctx_window = data.get("context_window")
                    if isinstance(ctx_window, (int, float)) and ctx_window > 0:
                        self._last_context_window = int(ctx_window)
                    self._refresh_status_bar()
                elif event == "permission_request":
                    # Tool calls always come AFTER an assistant turn in the
                    # session_turn loop. Close the current round's
                    # AssistantMessage so the modal pops cleanly above the
                    # finalized turn — and so the tool widgets land in
                    # their own slot below.
                    _close_round_assistant()
                    await self._handle_permission_request(data)
                elif event == "tool_call":
                    tool_name = str(data.get("tool", "?"))
                    _incoming_cid = str(data.get("call_id") or "")
                    # Predict whether this tool_call will be
                    # SUPPRESSED (inner subagent event hidden from
                    # the parent transcript) — if so, don't split the
                    # streaming widget. Splitting only to suppress
                    # leaves a useless empty `🔧→ (empty)` widget in
                    # the transcript. Only split when the new tool
                    # widget will actually mount BELOW it.
                    _will_suppress_inner = bool(
                        self._subagent_box_stack
                        and _incoming_cid
                        and _incoming_cid not in self._subagent_boxes_by_call
                    )
                    if not _will_suppress_inner:
                        # SPLIT BOUNDARY for any in-flight streaming
                        # ToolResultMessage. The new tool_call event
                        # is about to mount a ToolCallMessage at the
                        # END of the transcript. ``mark_split``
                        # freezes the streaming widget so the next
                        # delta mounts a fresh one BELOW the inner
                        # tool. See ToolResultMessage.mark_split.
                        for w in transcript.query(ToolResultMessage):
                            if getattr(w, "_streaming", False):
                                w.mark_split()
                    # Model-emitted ``todo`` tool: parse the args to
                    # update the bottom-of-TUI plan checklist. Two
                    # cases that mutate the visible list:
                    #   action=replace + items=[…]  → install a fresh
                    #       checklist of pending steps
                    #   action=add + items=[…]      → append to the
                    #       current list
                    #   action=complete + indexes=[…] → tick those
                    #       steps off
                    # The tool itself returns the canonical markdown
                    # checklist as ``content``; we re-parse from that
                    # in the matching ``tool_result`` branch so the
                    # rendered list always matches what the model
                    # sees on its side of the wire.
                    # Subagent-emitted TodoWrite must NOT leak into the
                    # parent session's `#plan-checklist` footer — the
                    # subagent's plan belongs to its own view, the
                    # parent has its own (separately-tracked) plan +
                    # the `#harness-tasks` footer. Gate on the
                    # subagent-box stack: any tool_call that arrives
                    # while a SubagentBoxMessage is on the stack is by
                    # definition an inner-subagent event.
                    if (
                        tool_name in ("TodoWrite", "todo")
                        and not self._subagent_box_stack
                    ):
                        self._handle_todo_tool_call(
                            data.get("arguments") or {},
                        )
                    # Plan-checklist cursor only advances on explicit
                    # `todo complete` actions handled above. The old
                    # "tick on every non-todo tool call" heuristic
                    # double-counted: a turn that fires 17 tool calls
                    # against a 4-step plan blew past the end and
                    # misled the operator into thinking the model was
                    # done while it was still on step 1.
                    _close_round_assistant()
                    # Block until Textual has actually painted the
                    # just-finalized AssistantMessage at its grown size
                    # BEFORE we mount the tool widget below it. An
                    # earlier attempt used ``asyncio.sleep(0)`` to yield
                    # one event-loop tick, but under SSH-throttled FPS
                    # the compositor's paint timer hasn't fired by the
                    # time we get back — the tool widget then mounts on
                    # top of a still-laying-out assistant message and
                    # the prose before the tool call stays invisible
                    # for the entire (potentially long) tool run,
                    # reading as "agent stuck." ``wait_for_refresh``
                    # sets an ``asyncio.Event`` via
                    # ``call_after_refresh`` and awaits it, so we
                    # actually wait for a full paint cycle. A few extra
                    # ms here is fine; the bug it prevents looks like a
                    # hang.
                    #
                    # NOTE: must be called on a mounted widget, NOT on
                    # ``self`` (the App). Textual's ``MessagePump.
                    # wait_for_refresh`` asserts ``self._task is not
                    # None``, but on the App class ``_task`` is only
                    # set inside ``run_test`` — under normal
                    # ``run_async`` the App's message loop runs in
                    # ``run_process_messages`` without populating
                    # ``_task``, so ``await self.wait_for_refresh()``
                    # crashes every tool-call event with "Node must be
                    # running before calling wait_for_refresh".
                    # ``transcript`` is a started widget; its task is
                    # live, and ``call_after_refresh`` schedules onto
                    # the same app-level paint cycle either way.
                    await transcript.wait_for_refresh()
                    self._set_worker_state(
                        f"[bold yellow]🔧 running tool: {tool_name}[/bold yellow]",
                        detail="[dim]ESC to cancel[/dim]",
                    )
                    # Track this call as in-flight so the matching
                    # tool_result branch knows whether more parallel
                    # siblings are still pending before mounting the
                    # next-round AssistantMessage.
                    call_id = str(data.get("call_id") or "")
                    if call_id:
                        self._pending_tool_calls.add(call_id)
                    # Tools whose ARGS carry the user-facing artifact
                    # (not the result): render the arg body as a
                    # dedicated card and remember the call_id so the
                    # matching tool_result branch skips the redundant
                    # Collapsible. Every other tool falls through to
                    # the standard ToolCallMessage pill.
                    args_for_widget = data.get("arguments") or {}
                    # Subagent isolation: when a SubagentBoxMessage is
                    # on the stack AND the current call_id is NOT the
                    # outer Agent dispatch itself, this is an INNER
                    # tool fired by the subagent. Skip the widget
                    # mount entirely (the operator's main transcript
                    # stays clean — the full inner stream is captured
                    # in the sidecar JSON and reachable via
                    # alt+up/alt+down/alt+enter or /subagents). Bump
                    # the box's inner-tool counter so the operator
                    # still sees live progress in the header.
                    if (
                        self._subagent_box_stack
                        and call_id
                        and str(call_id) not in self._subagent_boxes_by_call
                    ):
                        try:
                            self._subagent_box_stack[-1].note_inner_call(
                                tool_name,
                            )
                        except Exception:  # noqa: BLE001
                            pass
                        # Track the call_id so the matching
                        # tool_result branch also skips its widget
                        # mount AND bumps the done counter.
                        self._suppressed_subagent_calls.add(str(call_id))
                        # Still track in _pending_tool_calls so the
                        # parent's "round complete" detection works
                        # correctly when the inner call returns.
                        self._pending_tool_calls.add(str(call_id))
                        self._set_worker_state(
                            f"[bold yellow]🔧 subagent running: "
                            f"{tool_name}[/bold yellow]",
                            detail="[dim]ESC to cancel[/dim]",
                        )
                        continue
                    # Route inner mounts under a subagent box when one
                    # is on the stack (visual containment for
                    # delegate_* runs). Falls through to ``transcript``
                    # otherwise.
                    _mount = self._mount_target(transcript)
                    if tool_name == "ExitPlanMode":
                        plan_text = str(args_for_widget.get("plan") or "")
                        await _mount.mount(PlanMessage(plan_text))
                        if call_id:
                            self._plan_call_ids.add(call_id)
                    elif tool_name == "OutputSection":
                        section_name = str(args_for_widget.get("section_name") or "")
                        section_content = str(args_for_widget.get("content") or "")
                        await _mount.mount(
                            OutputSectionMessage(section_name, section_content)
                        )
                        if call_id:
                            self._section_call_ids.add(call_id)
                    elif tool_name in ("Update", "Edit"):
                        # File edit → Claude Code's "Update" treatment:
                        # render the change as a colored code-diff card
                        # computed from the call's own args. The diff
                        # shows immediately, before the tool finishes;
                        # the matching tool_result just stamps it ✓/✗
                        # (see the `_update_call_ids` branch below).
                        await _mount.mount(
                            UpdateMessage(
                                str(args_for_widget.get("file_path") or ""),
                                str(args_for_widget.get("old_string") or ""),
                                str(args_for_widget.get("new_string") or ""),
                                replace_all=bool(
                                    args_for_widget.get("replace_all", False)
                                ),
                                call_id=call_id,
                            )
                        )
                        if call_id:
                            self._update_call_ids.add(call_id)
                    elif self._is_harness_task_tool(tool_name):
                        # Task* family → footer-only update, no inline
                        # widget. The ``#harness-tasks`` Static at the
                        # bottom of the TUI carries the live task list
                        # (analog to ``#plan-checklist`` for TodoWrite).
                        # TaskCreate's row needs the assigned id, which
                        # only arrives in the tool_result body; we
                        # stash the args here and apply them in the
                        # matching tool_result branch. TaskUpdate is
                        # applied optimistically here so the footer
                        # flips immediately on dispatch.
                        #
                        # Subagent gate: same logic as the TodoWrite
                        # branch above — a Task* fired by a subagent
                        # must not mutate the PARENT's footer. Skip
                        # the state update while a SubagentBoxMessage
                        # is on the stack (the subagent's own task
                        # list lives in its session view).
                        if not self._subagent_box_stack:
                            if tool_name == "TaskCreate":
                                if call_id:
                                    self._pending_task_create_calls[call_id] = (
                                        args_for_widget if isinstance(
                                            args_for_widget, dict
                                        ) else {}
                                    )
                            elif tool_name == "TaskUpdate":
                                self._apply_task_update_args(args_for_widget)
                        if call_id:
                            self._harness_task_call_ids.add(call_id)
                    elif self._is_delegate_tool(tool_name):
                        # Subagent run → wrap inner widgets in a
                        # bordered container so the operator can tell
                        # the subagent's events from the parent's.
                        label, summary = self._delegate_summary(
                            tool_name, args_for_widget
                        )
                        box = SubagentBoxMessage(label, summary)
                        await _mount.mount(box)
                        if call_id:
                            self._subagent_boxes_by_call[call_id] = box
                            # Persist the full prompt/args to a per-call
                            # sidecar so the operator can re-read it
                            # later (and so the upcoming subagent-
                            # navigation feature can list it). The
                            # matching tool_result branch appends the
                            # result + elapsed time to the same file.
                            self._persist_subagent_call(
                                call_id, tool_name, args_for_widget,
                            )
                        self._subagent_box_stack.append(box)
                        # Bump the pinned ``#subagent-counter`` footer
                        # so the operator sees the fan-out total grow
                        # in real time. The matching tool_result
                        # branch bumps done / failed.
                        self._subagent_total += 1
                        self._render_subagent_counter()
                        # Still mount the generic announcement pill
                        # INSIDE the box so the operator can see the
                        # full args (prompt, model, etc.) collapsibly.
                        await box.body.mount(
                            ToolCallMessage(tool_name, args_for_widget)
                        )
                    else:
                        # Always mount the inline 🔧 announcement widget
                        # so the user can see WHICH tool is running and
                        # with what args. Operators were reporting "the
                        # status bar shows exec but nothing's on the
                        # transcript" — that was this gate hiding the
                        # call until the result arrived. The widget is
                        # collapsed-by-default so it doesn't dominate
                        # the transcript; expand with Ctrl+T.
                        await _mount.mount(
                            ToolCallMessage(tool_name, args_for_widget)
                        )
                    self._maybe_scroll_end(transcript)
                elif event == "tool_delta":
                    # Streaming-capable tool (today: `delegate_claude`)
                    # is producing output incrementally. Find or mount
                    # a ToolResultMessage in streaming mode and append
                    # the chunk so the user sees Claude's text arrive
                    # token-by-token, same UX as the slash command.
                    #
                    # NOTE the ``and w._streaming`` filter: previously
                    # this match was ``call_id`` only, which meant
                    # split widgets (frozen by mark_split when an inner
                    # tool_call interrupted) would be re-found and
                    # appended to. With the filter, split widgets are
                    # bypassed and the next delta mounts a fresh
                    # streaming widget at the END of the transcript —
                    # below whatever inner tool widgets just mounted.
                    call_id = data.get("call_id", "")
                    txt = data.get("text") or ""
                    if not txt or not call_id:
                        continue
                    # Drop tool_delta chunks for inner subagent calls —
                    # we've suppressed the call's widget so there's no
                    # bubble to stream into anyway.
                    if str(call_id) in self._suppressed_subagent_calls:
                        continue
                    streaming = next(
                        (w for w in transcript.query(ToolResultMessage)
                         if w.call_id == call_id and w._streaming),
                        None,
                    )
                    if streaming is None:
                        streaming = ToolResultMessage(
                            call_id, ok=True, content="", streaming=True,
                        )
                        await transcript.mount(streaming)
                    streaming.append_streaming(txt)
                    self._maybe_scroll_end(transcript)
                elif event == "tool_result":
                    # Reuse a streaming widget if one was mounted via
                    # `tool_delta` for this call_id; otherwise mount a
                    # fresh ToolResultMessage with the full content.
                    call_id = data.get("call_id", "")
                    ok = bool(data.get("ok", True))
                    content = data.get("content", "")
                    # Inner subagent tool whose widget mount we
                    # suppressed at tool_call time: don't mount the
                    # ToolResultMessage either. Bump the subagent
                    # box's done counter so the header progress
                    # advances, then drop the housekeeping (pending
                    # tool set, worker state, next-round assistant
                    # gate) so the parent turn flows the same as
                    # always.
                    if str(call_id) in self._suppressed_subagent_calls:
                        self._suppressed_subagent_calls.discard(str(call_id))
                        try:
                            if self._subagent_box_stack:
                                self._subagent_box_stack[-1].note_inner_done()
                        except Exception:  # noqa: BLE001
                            pass
                        self._pending_tool_calls.discard(str(call_id or ""))
                        self._set_worker_state(
                            "[bold green]▶ streaming…[/bold green]",
                            detail="[dim]ESC to cancel[/dim]",
                        )
                        if not self._pending_tool_calls:
                            await _ensure_assistant()
                        self._maybe_scroll_end(transcript)
                        continue
                    # ExitPlanMode was rendered as a PlanMessage at
                    # tool_call time; the result body is just "Plan
                    # ready — confirm…\n\n<plan>" which duplicates the
                    # plan card. Skip the ToolResultMessage mount but
                    # keep the housekeeping (pending-set, worker state,
                    # next-round assistant) so the rest of the turn
                    # flows unchanged.
                    if str(call_id) in self._plan_call_ids:
                        self._plan_call_ids.discard(str(call_id))
                        self._pending_tool_calls.discard(str(call_id or ""))
                        self._set_worker_state(
                            "[bold green]▶ streaming…[/bold green]",
                            detail="[dim]ESC to cancel[/dim]",
                        )
                        if not self._pending_tool_calls:
                            await _ensure_assistant()
                        self._maybe_scroll_end(transcript)
                        continue
                    # OutputSection: on success the result body is the
                    # "Section X/N saved, next: Y" nudge meant for the
                    # model — we already rendered the section content
                    # as an OutputSectionMessage at tool_call time, so
                    # suppress the redundant Collapsible. On FAILURE
                    # fall through to the standard ToolResultMessage so
                    # the operator sees the validation error.
                    if str(call_id) in self._section_call_ids:
                        self._section_call_ids.discard(str(call_id))
                        if ok:
                            self._pending_tool_calls.discard(str(call_id or ""))
                            self._set_worker_state(
                                "[bold green]▶ streaming…[/bold green]",
                                detail="[dim]ESC to cancel[/dim]",
                            )
                            if not self._pending_tool_calls:
                                await _ensure_assistant()
                            self._maybe_scroll_end(transcript)
                            continue
                    # Update/Edit: the diff was already rendered as an
                    # UpdateMessage card at tool_call time. Stamp it
                    # ✓/✗ via `mark_result` and — on success — skip the
                    # redundant ToolResultMessage (the result body is
                    # just a one-line "updated <path>" summary). On
                    # FAILURE fall through so the operator sees the
                    # error text (old_string-not-found, etc.).
                    if str(call_id) in self._update_call_ids:
                        self._update_call_ids.discard(str(call_id))
                        card = next(
                            (w for w in transcript.query(UpdateMessage)
                             if w.call_id == call_id),
                            None,
                        )
                        if card is not None:
                            card.mark_result(ok)
                        if ok:
                            self._pending_tool_calls.discard(str(call_id or ""))
                            self._set_worker_state(
                                "[bold green]▶ streaming…[/bold green]",
                                detail="[dim]ESC to cancel[/dim]",
                            )
                            if not self._pending_tool_calls:
                                await _ensure_assistant()
                            self._maybe_scroll_end(transcript)
                            continue
                    # Harness Task* result: apply to the inline task
                    # card. TaskCreate's id comes from the result body;
                    # TaskUpdate was applied optimistically at call
                    # time. Suppress the redundant Collapsible on
                    # success (the card already shows the row); on
                    # failure fall through so the error text is visible.
                    if str(call_id) in self._harness_task_call_ids:
                        self._harness_task_call_ids.discard(str(call_id))
                        if str(call_id) in self._pending_task_create_calls:
                            create_args = self._pending_task_create_calls.pop(
                                str(call_id)
                            )
                            self._apply_task_create_from_result(
                                create_args, str(content or "")
                            )
                        if ok:
                            self._pending_tool_calls.discard(str(call_id or ""))
                            self._set_worker_state(
                                "[bold green]▶ streaming…[/bold green]",
                                detail="[dim]ESC to cancel[/dim]",
                            )
                            if not self._pending_tool_calls:
                                await _ensure_assistant()
                            self._maybe_scroll_end(transcript)
                            continue
                    # Subagent (delegate_*) result: finalize the box,
                    # pop from the containment stack so subsequent
                    # parent-agent widgets mount in the transcript
                    # again. The subagent's own final content text was
                    # already streamed into widgets INSIDE the box; we
                    # still let the standard Collapsible mount below
                    # so the full final result is foldable.
                    if str(call_id) in self._subagent_boxes_by_call:
                        box = self._subagent_boxes_by_call.pop(str(call_id))
                        try:
                            self._subagent_box_stack.remove(box)
                        except ValueError:
                            pass
                        box.finalize(ok=ok)
                        # Append result + elapsed to the sidecar so the
                        # per-subagent log is complete.
                        self._persist_subagent_result(
                            str(call_id), ok, str(content or ""),
                        )
                        # Bump the pinned ``#subagent-counter`` footer
                        # so the operator sees ``N/M done`` tick up
                        # even when the finalized box has scrolled off
                        # the viewport.
                        if ok:
                            self._subagent_done += 1
                        else:
                            self._subagent_failed += 1
                        self._render_subagent_counter()
                        # The result Collapsible should also land
                        # INSIDE the box so it stays visually grouped
                        # with the subagent's run.
                        if ok and not (content or "").strip():
                            self._pending_tool_calls.discard(str(call_id or ""))
                            self._set_worker_state(
                                "[bold green]▶ streaming…[/bold green]",
                                detail="[dim]ESC to cancel[/dim]",
                            )
                            if not self._pending_tool_calls:
                                await _ensure_assistant()
                            self._maybe_scroll_end(transcript)
                            continue
                        await box.body.mount(
                            ToolResultMessage(call_id, ok, content)
                        )
                        self._pending_tool_calls.discard(str(call_id or ""))
                        self._set_worker_state(
                            "[bold green]▶ streaming…[/bold green]",
                            detail="[dim]ESC to cancel[/dim]",
                        )
                        if not self._pending_tool_calls:
                            await _ensure_assistant()
                        self._maybe_scroll_end(transcript)
                        continue
                    streaming = next(
                        (w for w in transcript.query(ToolResultMessage)
                         if w.call_id == call_id and w._streaming),
                        None,
                    )
                    # Did we previously split this call's stream? If so,
                    # the streamed segments together ARE the
                    # authoritative content. The agent's final
                    # ``content`` field would duplicate the prior
                    # segments' text into the LAST one, re-showing
                    # everything that already rendered above the inner
                    # tool widgets. Pass content=None to keep streamed
                    # text and only stamp the ✅/❌ marker.
                    prior_splits = [
                        w for w in transcript.query(ToolResultMessage)
                        if w.call_id == call_id and getattr(w, "_split", False)
                    ]
                    if streaming is not None:
                        if prior_splits:
                            streaming.finalize_streaming(ok=ok, content=None)
                        else:
                            streaming.finalize_streaming(ok=ok, content=content)
                    elif prior_splits:
                        # All segments were split (inner tool came right
                        # at the end with no trailing delta). Just
                        # stamp the FINAL ok marker on the LAST split
                        # widget — don't re-show the body.
                        last = prior_splits[-1]
                        last.ok = ok
                        last._prefix = "✅" if ok else "❌"
                        last._peek = last._build_peek()
                        last.title = last._build_title(collapsed=last.collapsed)
                    else:
                        await transcript.mount(
                            ToolResultMessage(call_id, ok, content)
                        )
                    # Drop this call from the in-flight set. With
                    # parallel tool calls (one round, N tool_call
                    # events, then N tool_result events), if we mounted
                    # the next-round AssistantMessage now, remaining
                    # parallel results would land BELOW it and the
                    # next round's reasoning/content would render in
                    # the prematurely-mounted widget — visually the
                    # answer would appear ABOVE the still-pending tool
                    # widgets. Only re-arm the assistant once the LAST
                    # parallel sibling has resolved.
                    self._pending_tool_calls.discard(str(call_id or ""))
                    # Tool finished — model is about to re-prefill on the
                    # appended tool_result message and start streaming the
                    # next round. Flip the worker-state cue back to
                    # streaming so the user sees "still alive, model now"
                    # instead of leaving a stale "running tool" line up.
                    self._set_worker_state(
                        "[bold green]▶ streaming…[/bold green]",
                        detail="[dim]ESC to cancel[/dim]",
                    )
                    # Eagerly mount the next round's AssistantMessage so
                    # the prefill counter is visible during the upstream
                    # model's re-prefill on the just-grown chat history
                    # (tool result was just injected). Same fluidity goal
                    # as the eager mount before the SSE loop, but for
                    # round 2+ in a tool-use turn. Skipped while parallel
                    # siblings are still pending — see comment above.
                    if not self._pending_tool_calls:
                        await _ensure_assistant()
                    self._maybe_scroll_end(transcript)
                elif event == "auto_continue":
                    # Local-inference models often hit `finish_reason=length`
                    # mid-answer or run out of tool-call rounds in plan/ask.
                    # The agent auto-injects a continue prompt and runs
                    # another round. Close the current assistant so the
                    # next round mounts its own widget, and surface a
                    # status line so the user sees what's happening.
                    _close_round_assistant()
                    reason = data.get("reason", "?")
                    count = data.get("count", "?")
                    self._set_status(f"auto-continue: {reason} (#{count})")
                    # Premature EOS on a tool-followup round: surface a
                    # persistent inline alert so the user knows the
                    # upstream model glitched (qwen3-fp8 EOS-too-early
                    # bug) and the agent is retrying. Status bar fires
                    # for every auto_continue, but this gets a transcript
                    # widget so it's visible in scrollback.
                    if reason == "empty_stop":
                        try:
                            max_retries = int(data.get("max") or 0)
                        except (TypeError, ValueError):
                            max_retries = 0
                        try:
                            count_int = int(count)
                        except (TypeError, ValueError):
                            count_int = 0
                        try:
                            round_idx = int(data.get("round") or 0)
                        except (TypeError, ValueError):
                            round_idx = 0
                        await transcript.mount(EmptyEosNotice(
                            count_int, max_retries, round_idx,
                        ))
                        self._maybe_scroll_end(transcript)
                        self._set_status(
                            f"premature EOS on tool call · retry "
                            f"{count_int}/{max_retries}"
                        )
                    # Compaction events (proactive `compacted` and
                    # post-overflow `compacted_after_overflow`) get a
                    # persistent inline notice so the user can tell at
                    # a glance — and after-the-fact when scrolling back —
                    # that some tool results were trimmed/dropped on the
                    # wire to the upstream model. The transcript widgets
                    # for those calls also get a "🗜️ upstream-…" badge.
                    if reason in ("compacted", "compacted_after_overflow"):
                        await transcript.mount(CompactionNotice(reason, data))
                        self._maybe_scroll_end(transcript)
                        # Update `ctx X/Y` immediately so the user sees
                        # the post-compaction prompt size without having
                        # to wait for the next round's metrics event.
                        new_pt = data.get("new_prompt_tokens")
                        if isinstance(new_pt, (int, float)) and new_pt > 0:
                            self._last_prompt_tokens = int(new_pt)
                            self._refresh_status_bar()
                        truncated = set(data.get("truncated_tool_call_ids") or [])
                        dropped = set(data.get("dropped_tool_call_ids") or [])
                        if truncated or dropped:
                            for w in transcript.query(ToolResultMessage):
                                if w.call_id in dropped:
                                    w.mark_compacted("dropped")
                                elif w.call_id in truncated:
                                    w.mark_compacted("truncated")
                    # Mount the next round's AssistantMessage now so the
                    # prefill counter ticks while the agent retries the
                    # upstream model. Same rationale as post-tool_result.
                    await _ensure_assistant()
                elif event == "error":
                    worker_error = data.get("message")
                elif event == "done":
                    # `state == "aborted"` was previously a no-op and
                    # left the user wondering why their turn just
                    # stopped. Surface the reason: ESC ("aborted") gets
                    # a soft message; tool_runner crashes carry a real
                    # error string in `data["error"]` and route through
                    # the same banner path as other errors.
                    state = data.get("state")
                    err = data.get("error")
                    if state == "aborted" and err:
                        worker_error = err
                    elif state == "aborted":
                        worker_error = "turn aborted"
                    elif state == "error" and err:
                        worker_error = err
        except Exception as e:  # noqa: BLE001
            worker_error = str(e) or repr(e)
        finally:
            ended_tid = self._current_turn_id
            self._current_turn_id = None
            # Clear the always-visible worker indicator now that we're done.
            self._set_worker_state("")
            self._tui_log(
                "stream_end",
                tid=ended_tid,
                error=(worker_error or "")[:200] or None,
            )

        # End-of-turn: close whatever's still open. Per-call stats live
        # on each AssistantMessage (via the `metrics` SSE event), so the
        # footer doesn't decorate "done" with ttft/tps/wt — keep the
        # footer free of per-call telemetry.
        if worker_error:
            if self._current_assistant is not None:
                self._current_assistant.mark_error(worker_error)
            self._set_status(f"error: {worker_error[:80]}")
        else:
            # Stamp the LAST round's metrics if the per-round `metrics`
            # SSE event didn't fire (some bridges only ship usage at
            # turn-end). Otherwise the per-round events already painted
            # the line during streaming and this is a no-op refresh.
            if worker_metrics and self._current_assistant is not None:
                self._current_assistant.set_metrics(worker_metrics)
            _close_round_assistant()
            self._set_status("")

        # Refresh local session view from server
        try:
            data = await self._client.get_session(self._sid)
            self.session = Session(
                hash=data["hash"], title=data["title"], created_at=data["created_at"],
                system_prompt=data.get("system_prompt", ""),
                model=data["model"], endpoint=data["endpoint"],
                turns=list(data.get("turns") or []),
                context_window=int(data.get("context_window") or 0),
            )
            # Anchor the cross-frontend poll counter to the server's
            # current view: we just rendered our own turn live, and the
            # disk row was added by the agent at the same time. Without
            # this, the next poll tick would treat our own freshly-
            # saved turn as "external" and re-render it as a duplicate.
            self._known_turn_count = len(self.session.turns)
            self._refresh_title()
        except Exception:  # noqa: BLE001
            pass

        # Drain one queued entry, if any. Called after the session-view
        # refresh so the next turn starts from up-to-date state.
        self._maybe_start_next()


async def _cmd_session(args: argparse.Namespace) -> int:
    """Dispatch `rtxclaw session {list,compact}`. Hits the same agent
    that the TUI / `-p` flows use (selected via `-a/--agent`), so the
    `/compact` slash command in the TUI and `rtxclaw session compact`
    from the shell share the same server endpoint and audit format.
    """
    from rtxclaw_tui.agent_client import AgentClient
    from rtxclaw_core import agent as _agent_mod
    cfg = _resolve_agent_or_fail(args.agent or "main")
    if cfg is None:
        return 2
    op = getattr(args, "op", None)
    gateway_url, gateway_token = _gateway_url_and_token()
    client = AgentClient(
        cfg.url, agent_name=cfg.name,
        gateway_url=gateway_url, gateway_token=gateway_token,
    )

    if op == "list":
        try:
            sessions = await client.list_sessions()
        except Exception as e:  # noqa: BLE001
            print(f"agent unreachable: {e}", file=sys.stderr)
            return 2
        # Newest first by created_at; fall back to hash sort if missing.
        sessions.sort(key=lambda s: s.get("created_at") or s.get("hash", ""), reverse=True)
        for s in sessions[: max(1, int(args.limit))]:
            h = s.get("hash", "?")
            title = (s.get("title") or "").replace("\n", " ")[:60]
            created = s.get("created_at", "")
            print(f"{h}  {created}  {title}")
        return 0

    if op == "compact":
        sid = args.sid
        if not sid:
            # Convenience: pick the most recently modified session file
            # so `rtxclaw session compact` (no args) operates on whatever
            # the user was last using.
            try:
                files = sorted(
                    cfg.sessions_dir.glob("*.json"),
                    key=lambda p: p.stat().st_mtime,
                    reverse=True,
                )
            except OSError:
                files = []
            if not files:
                print("no saved sessions found", file=sys.stderr)
                return 2
            sid = files[0].stem
        try:
            result = await client.compact_session(
                sid,
                keep_recent_turns=args.keep_recent_turns,
                min_result_chars=args.min_result_chars,
                head_chars=args.head_chars,
            )
        except Exception as e:  # noqa: BLE001
            print(f"compact failed: {e}", file=sys.stderr)
            return 2
        if args.json:
            print(json.dumps(result, indent=2))
            return 0
        audit = result.get("audit") or {}
        n_trunc = len(audit.get("truncated_tool_call_ids") or [])
        n_drop = len(audit.get("dropped_tool_call_ids") or [])
        n_turns = int(audit.get("dropped_turns") or 0)
        print(
            f"compacted session {sid}: "
            f"{result.get('removed_chars', 0)} chars removed · "
            f"{n_trunc} tool result(s) truncated · "
            f"{n_drop} dropped · {n_turns} old turn(s) discarded"
        )
        return 0

    print(f"unknown session op: {op}", file=sys.stderr)
    return 2


def _cmd_memory(args: argparse.Namespace) -> int:
    """Dispatch `rtxclaw memory {status,search,index,prune}`. See `--help`.

    Each subcommand opens a fresh `MemoryIndex` against the named agent's
    home directory (`~/.rtxclaw/agents/<name>/`). `index --force` drops
    the entire DB first; otherwise we run incremental indexing — only
    re-chunk files whose hash has changed.
    """
    import json as _json
    from rtxclaw_core import agent as _agent_mod
    from rtxclaw_memory.memory_index import MemoryIndex
    op = getattr(args, "op", None)
    name = getattr(args, "agent", "main") or "main"
    home = _agent_mod.agents_root() / name
    if not home.is_dir():
        print(
            f"error: agent {name!r} has no home directory ({home}). "
            f"Run `rtxclaw agent init` first.",
            file=sys.stderr,
        )
        return 2

    embedder = None
    try:
        from rtxclaw_memory.memory_embed import resolve_embedder
        embedder = resolve_embedder()
    except Exception:  # noqa: BLE001
        embedder = None

    if op == "status":
        idx = MemoryIndex(home, embedder=embedder)
        s = idx.stats()
        meta = s.get("meta") or {}
        print(f"agent      : {name}")
        print(f"db         : {s['db_path']} ({s['db_size_bytes']:,} bytes)")
        print(f"vec0       : {'loaded' if s['has_vec0'] else 'NOT LOADED (FTS-only)'}")
        print(f"chunks     : {s['chunk_count']:,}")
        print(f"files      : {s['file_count']:,}")
        print(f"cache rows : {s['cache_count']:,}")
        last_ms = s.get("last_indexed_ms") or 0
        if last_ms:
            import datetime as _dt
            ts = _dt.datetime.fromtimestamp(last_ms / 1000).isoformat(timespec="seconds")
            print(f"last index : {ts}")
        else:
            print("last index : never")
        print(f"provider   : {meta.get('provider','none')}")
        print(f"model      : {meta.get('model','-')}")
        print(f"vec dims   : {meta.get('vectorDims','-')}")
        print(f"chunk_tok  : {meta.get('chunkTokens','-')}  overlap: {meta.get('chunkOverlap','-')}")
        print(f"sources    : {','.join(meta.get('sources',['memory']))}")
        if scope := meta.get("scopeHash"):
            print(f"scopeHash  : {scope[:24]}...")
        # Show tracked files
        tracked = idx.tracked_files()
        if tracked:
            print(f"\ntracked ({len(tracked)}):")
            for p in tracked[:20]:
                try:
                    size = p.stat().st_size
                    print(f"  {p.relative_to(home)}  ({size:,} bytes)")
                except OSError:
                    print(f"  {p.relative_to(home)}  (?)")
            if len(tracked) > 20:
                print(f"  ... and {len(tracked) - 20} more")
        return 0

    if op == "search":
        idx = MemoryIndex(home, embedder=embedder)
        if idx.needs_reindex():
            idx.index_all()
        hits = idx.search(
            args.query,
            top_k=int(args.top_k or 6),
            min_score=float(args.min_score or 0.35),
            relevance_floor=float(getattr(args, "relevance_floor", 0.0) or 0.0),
        )
        if args.json:
            print(_json.dumps([
                {
                    "id": h.id, "path": h.path, "source": h.source,
                    "start_line": h.start_line, "end_line": h.end_line,
                    "score": h.score, "vector_score": h.vector_score,
                    "text_score": h.text_score, "snippet": h.snippet,
                }
                for h in hits
            ], indent=2, ensure_ascii=False))
            return 0
        if not hits:
            print(f"no matches for {args.query!r} (min_score={args.min_score})")
            return 0
        for i, h in enumerate(hits, 1):
            print(f"\n--- {i}. score {h.score:.3f}  vec {h.vector_score:.3f}  text {h.text_score:.3f}")
            print(f"    {h.path}:{h.start_line}-{h.end_line}")
            print(f"    {h.snippet[:300]!r}")
        return 0

    if op == "index":
        idx = MemoryIndex(home, embedder=embedder)
        if getattr(args, "reembed", False):
            if embedder is None:
                print(
                    "error: --reembed requires a configured embedder "
                    "(set OPENAI_API_KEY, run `codex login`, or configure "
                    "memory_embedding in ~/.rtxclaw/config.json).",
                    file=sys.stderr,
                )
                return 2
            print("dropping chunks/FTS/vec/files AND embedding cache...")
            idx.clear()
            con = idx._connect()
            try:
                con.execute("DELETE FROM embedding_cache")
                con.commit()
            finally:
                con.close()
        elif args.force:
            print("dropping chunks/FTS/vec/files (cache survives)...")
            idx.clear()
        stats = idx.index_all()
        print(
            f"indexed:  files={stats['indexed_files']}  "
            f"chunks={stats['indexed_chunks']}  "
            f"skipped={stats['skipped_unchanged']}  "
            f"deleted={stats['deleted_files']}  "
            f"embedded={stats['embedded_chunks']}  "
            f"cache_hits={stats['cache_hits']}  "
            f"t={stats['duration_s']}s"
        )
        return 0

    if op == "prune":
        import datetime as _dt
        import re as _re
        import sqlite3 as _sql
        days = int(args.older_than_days or 365)
        cutoff = _dt.date.today() - _dt.timedelta(days=days)
        idx = MemoryIndex(home, embedder=embedder)
        # Match `memory/YYYY-MM-DD*.md` paths and compare to cutoff.
        date_re = _re.compile(r"^memory/(\d{4})-(\d{2})-(\d{2})")
        con = _sql.connect(str(idx.db_path))
        try:
            paths_to_prune: list[str] = []
            for r in con.execute("SELECT DISTINCT path FROM files"):
                p = r[0]
                m = date_re.match(p)
                if not m:
                    continue
                try:
                    d = _dt.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
                except ValueError:
                    continue
                if d < cutoff:
                    paths_to_prune.append(p)
            if not paths_to_prune:
                print(f"nothing older than {cutoff.isoformat()} to prune.")
                return 0
            print(f"pruning {len(paths_to_prune)} files older than {cutoff.isoformat()}:")
            for p in paths_to_prune[:20]:
                print(f"  {p}")
            if len(paths_to_prune) > 20:
                print(f"  ... and {len(paths_to_prune) - 20} more")
            for p in paths_to_prune:
                if idx.has_vec0:
                    con.execute(
                        "DELETE FROM chunks_vec WHERE id IN (SELECT id FROM chunks WHERE path = ?)",
                        (p,),
                    )
                con.execute("DELETE FROM chunks_fts WHERE id IN (SELECT id FROM chunks WHERE path = ?)", (p,))
                con.execute("DELETE FROM chunks WHERE path = ?", (p,))
                con.execute("DELETE FROM files  WHERE path = ?", (p,))
            con.commit()
        finally:
            con.close()
        print(f"pruned {len(paths_to_prune)} files.")
        return 0

    if op == "synth":
        # Force a memory-synth pass: read MEMORY.md + recent dailies,
        # ask the configured upstream to rewrite MEMORY.md, persist
        # atomically. ``--force`` bypasses the "no daily newer than
        # MEMORY.md" guard so an operator can re-run on demand. The
        # agent normally runs this on the ``daily_appended`` event;
        # this CLI is the manual escape hatch (and the test_07
        # forced-synth path).
        import asyncio as _asyncio
        from rtxclaw_memory.memory_synth import synth_memory as _synth
        from rtxclaw_core.agent import AgentConfig as _Acfg
        try:
            cfg = _Acfg.load(name)
        except FileNotFoundError:
            print(
                f"error: agent {name!r} not configured. "
                f"Run `rtxclaw agent init {name}` first.",
                file=sys.stderr,
            )
            return 2
        # Resolve the model in this priority order:
        #   1. CLI override (--model X)
        #   2. cfg.memory_flush_model (synth-specific override)
        #   3. cfg.upstream_model (primary chat model)
        endpoint = (
            getattr(args, "endpoint", None) or cfg.upstream_endpoint
        )
        model = (
            getattr(args, "model", None)
            or cfg.memory_flush_model
            or cfg.upstream_model
            or ""
        )
        if not endpoint:
            print(
                "error: no upstream endpoint configured. Set one via "
                "`rtxclaw configure --endpoint <url>` or pass --endpoint.",
                file=sys.stderr,
            )
            return 2
        # Empty model is fine — vLLM/SGLang routes to the endpoint's
        # default. For OpenAI-style routers (OpenRouter) pass --model.
        timeout_s = float(getattr(args, "timeout", None) or 60.0)
        force = bool(getattr(args, "force", False))
        if not (home / "MEMORY-SYNTH.md").is_file():
            print(
                f"warning: {home / 'MEMORY-SYNTH.md'} missing — synth will "
                "fail-soft. Re-run `rtxclaw agent init` to scaffold it.",
                file=sys.stderr,
            )
        stats = _asyncio.run(_synth(
            home,
            upstream_endpoint=endpoint,
            upstream_model=model,
            timeout_s=timeout_s,
            force=force,
        ))
        if getattr(args, "json", False):
            print(_json.dumps(stats, indent=2, ensure_ascii=False))
            return 0 if stats.get("ok") else 1
        ok = bool(stats.get("ok"))
        changed = bool(stats.get("changed"))
        reason = stats.get("reason") or ""
        err = stats.get("error") or ""
        dur = stats.get("duration_s")
        head = "✓" if ok else "✗"
        line = f"{head} memory synth — agent {name}"
        if dur is not None:
            line += f"  ({dur}s)"
        print(line)
        if ok:
            if changed:
                print(f"  MEMORY.md rewritten — {home / 'MEMORY.md'}")
            elif reason:
                print(f"  no-op: {reason}")
            else:
                print("  no-op")
        else:
            print(f"  error: {err}")
            preview = stats.get("preview")
            if preview:
                print(f"  preview: {preview!r}")
        return 0 if ok else 1

    print(f"unknown memory op: {op}", file=sys.stderr)
    return 2


def _cmd_skills(args: argparse.Namespace) -> int:
    """Dispatch `rtxclaw skills {list,show,import}`. See `--help`.

    `list` walks the search chain (env override → per-agent → shared
    → config `skills_dirs` bundles → builtin) and shows the
    unique-by-name set. `show <name>` prints the SKILL.md body.
    `import <name>` copies a skill from an `~/.openclaw/skills` dir
    into rtxclaw's shared skills dir as a snapshot (an explicit,
    opt-in migration helper — not part of normal discovery).
    """
    from rtxclaw_core import skills as _skills_mod
    op = getattr(args, "op", None)
    if op == "list":
        # Show every discovered skill, disabled ones included, so an
        # operator can see what's available to re-enable. The `✗`
        # marker = `enabled: false` in ~/.rtxclaw/config.json's
        # `skills` map; `discover_skills()` (no flag) is what the agent
        # actually sees, so the diff between the two is the disabled set.
        skills = _skills_mod.discover_skills(include_disabled=True)
        if not skills:
            print("(no skills installed; install or import to ~/.rtxclaw/skills/<name>/)")
            return 0
        enabled_names = {s.name for s in _skills_mod.discover_skills()}
        for s in skills:
            mark = "  " if s.name in enabled_names else "✗ "
            line = f"  {mark}{s.name:<28s}  {s.short_description}"
            print(line)
            if getattr(args, "verbose", False):
                print(f"  {'':30s}    source: {s.source}")
        if len(enabled_names) < len(skills):
            print("\n  ✗ = disabled via the `skills` map in ~/.rtxclaw/config.json")
        return 0
    if op == "show":
        name = args.name
        s = _skills_mod.find_skill(name)
        if s is None:
            sys.stderr.write(f"skill not found: {name!r}\n")
            return 1
        print(f"# {s.name}")
        if s.description:
            print(f"\n_{s.description}_\n")
        if s.version:
            print(f"version: {s.version}")
        if s.requires_env:
            print(f"requires env: {', '.join(s.requires_env)}")
        if s.requires_bins:
            print(f"requires bins: {', '.join(s.requires_bins)}")
        print(f"\n_(source: {s.source})_\n")
        print("---\n")
        print(s.body)
        return 0
    if op == "import":
        name = args.name
        try:
            dst = _skills_mod.import_openclaw_skill(name)
        except FileNotFoundError as e:
            sys.stderr.write(f"{e}\n")
            return 1
        except FileExistsError as e:
            sys.stderr.write(f"{e}\n")
            return 1
        print(f"imported to {dst}")
        # Re-discover so the user sees it active in the same shell.
        s = _skills_mod.find_skill(name)
        if s is not None:
            print(f"  {s.short_description}")
        return 0
    sys.stderr.write("unknown skills op; try `rtxclaw skills --help`\n")
    return 2


def _cmd_configure(args: argparse.Namespace) -> int:
    """Interactive or flag-driven configuration.

    Interactive (no flags, no --show) re-uses the same wizard the
    first-run flow runs (`agent_cli.setup_main_wizard(reconfigure=True)`)
    so there is exactly one code path that writes the canonical
    `~/.rtxclaw/config.json` + `~/.rtxclaw/agents/<name>/config.json`
    files. Every AgentConfig variable is configurable through the
    wizard (advanced fields gated behind a single Y/N prompt).

    Flag-driven: set individual fields via --endpoint, --model,
    --telegram-bot-token, etc. — useful for scripted bootstraps.
    --show prints the effective canonical config.
    """
    from rtxclaw_core.agent import (
        AgentConfig,
        global_config_path,
        load_global_config,
        save_global_config,
    )

    agent_name = getattr(args, "agent", "main") or "main"
    tg_token = getattr(args, "telegram_bot_token", None)
    tg_ids = getattr(args, "telegram_allowed_chat_ids", None)
    tg_user_ids = getattr(args, "telegram_allowed_user_ids", None)
    tg_mention_required = getattr(args, "telegram_mention_required", None)

    # ---- --show ----
    if args.show:
        gpath = global_config_path()
        print(f"# global config: {gpath}{'  (does not exist yet)' if not gpath.exists() else ''}")
        print(json.dumps(load_global_config(), indent=2, ensure_ascii=False))
        try:
            acfg = AgentConfig.load(agent_name)
            print(f"\n# per-agent config: {acfg.config_path}")
            print(acfg.config_path.read_text().strip())
        except FileNotFoundError:
            print(f"\n# per-agent config for {agent_name!r}: not configured")
        return 0

    # ---- Flag-driven: apply any flags and exit ----
    # Map the CLI flags (legacy `cfgmod.FIELDS` names) to canonical
    # AgentConfig / global-config field names. Keeps `--endpoint`,
    # `--model` etc. working as a scripted shortcut without writing the
    # legacy `~/.config/rtxclaw/config.json` file the runtime ignores.
    FLAG_TO_GLOBAL = {
        "endpoint": "upstream_endpoint",
        "model": "upstream_model",
        "temperature": "temperature",
        "enable_thinking": "enable_thinking",
    }
    flag_global_changes = {
        FLAG_TO_GLOBAL[f]: getattr(args, f)
        for f in FLAG_TO_GLOBAL
        if getattr(args, f, None) is not None
    }
    # `--system` is a per-agent field; route it there.
    sys_extra_arg = getattr(args, "system", None)

    any_flag = (
        bool(flag_global_changes)
        or sys_extra_arg is not None
        or tg_token is not None
        or tg_ids is not None
        or tg_user_ids is not None
        or tg_mention_required is not None
    )

    if any_flag:
        # Global fields → ~/.rtxclaw/config.json (canonical).
        if flag_global_changes:
            glob = load_global_config()
            glob.update(flag_global_changes)
            path = save_global_config(glob)
            print(f"wrote global config → {path}")

        # Per-agent fields → ~/.rtxclaw/agents/<name>/config.json.
        if sys_extra_arg is not None:
            try:
                acfg = AgentConfig.load(agent_name)
            except FileNotFoundError:
                print(f"agent {agent_name!r} not configured. run `rtxclaw configure` (no flags) for the full wizard.")
                return 2
            acfg.system = sys_extra_arg
            acfg.save()
            print(f"wrote per-agent config → {acfg.config_path}")

        # Telegram fields → ~/.rtxclaw/telegram/config.json
        # (the bot is now its own service; agent config is the wrong
        # home for these).
        if (
            tg_token is not None or tg_ids is not None
            or tg_user_ids is not None or tg_mention_required is not None
        ):
            from rtxclaw_telegram.config import TelegramConfig
            tg_cfg = TelegramConfig.load()
            if tg_token is not None:
                tg_cfg.bot_token = tg_token
            if tg_ids is not None:
                try:
                    tg_cfg.allowed_chat_ids = [
                        int(x.strip()) for x in tg_ids.split(",") if x.strip()
                    ]
                except ValueError:
                    print(f"invalid chat_ids: {tg_ids!r} (expected comma-separated integers)")
                    return 2
            if tg_user_ids is not None:
                # Empty string is the "clear the allowlist" signal —
                # ``--telegram-allowed-user-ids ""`` reverts to "any
                # member of an allowed chat may interact". Non-empty
                # input is parsed strictly: each comma-separated token
                # must be an int (Telegram user ids ARE numeric).
                raw = tg_user_ids.strip()
                if not raw:
                    tg_cfg.allowed_user_ids = []
                else:
                    try:
                        tg_cfg.allowed_user_ids = [
                            int(x.strip()) for x in raw.split(",") if x.strip()
                        ]
                    except ValueError:
                        print(
                            f"invalid user_ids: {tg_user_ids!r} "
                            "(expected comma-separated integers)"
                        )
                        return 2
            if tg_mention_required is not None:
                # argparse stores ``--telegram-mention-required`` as
                # the canonical token (``on``/``off``); coerce to the
                # bool the config carries.
                token = str(tg_mention_required).strip().lower()
                if token in ("on", "true", "yes", "1", "enable", "enabled"):
                    tg_cfg.mention_required_in_groups = True
                elif token in ("off", "false", "no", "0", "disable", "disabled"):
                    tg_cfg.mention_required_in_groups = False
                else:
                    print(
                        f"invalid --telegram-mention-required value "
                        f"{tg_mention_required!r} (expected on/off)"
                    )
                    return 2
            tg_cfg.save()
            print(f"wrote telegram config → {tg_cfg.config_path}")
        return 0

    # ---- Interactive: same wizard the first-run flow uses ----
    # `setup_main_wizard(reconfigure=True)` pre-fills every prompt from
    # the existing config (or falls through to first-run if nothing's
    # there yet) and covers every AgentConfig variable, including the
    # advanced fields gated behind a single Y/N.
    if not sys.stdin.isatty():
        print(
            "stdin is not a tty — use flags (--endpoint, --model, "
            "--telegram-bot-token, …) or run interactively."
        )
        return 1

    if agent_name != "main":
        # The wizard is hard-coded to the `main` agent (it's the only
        # one with a first-run path). Other agents should be configured
        # via flags or by hand-editing their config.json.
        print(
            f"interactive `rtxclaw configure` only supports the `main` agent; "
            f"got --agent {agent_name!r}. Use flags (--endpoint, …) or edit "
            f"{(AgentConfig(name=agent_name).config_path)} directly."
        )
        return 2

    from rtxclaw_agent import agent_cli as agentcli
    cfg = agentcli.setup_main_wizard(reconfigure=True)
    return 0 if cfg is not None else 1


def _print_agent_ready(cfg) -> None:
    """One-line health summary printed to stderr right before the TUI starts.

    Probes the running rtxclaw gateway at ``/acp/<agent>/acp`` —
    every agent is a stdio child of that gateway, never a standalone
    daemon. ``DOWN`` means the gateway isn't running (start it with
    ``rtxclaw gateway install-service`` or ``rtxclaw gateway start``).
    """
    upstream = getattr(cfg, "upstream_endpoint", "") or "<unresolved>"
    model = getattr(cfg, "upstream_model", "") or "<unresolved>"
    gateway_url, gateway_token = _gateway_url_and_token()
    headers: dict[str, str] = {"Content-Type": "application/json"}
    if gateway_token:
        headers["Authorization"] = f"Bearer {gateway_token}"
    health = "DOWN"
    try:
        r = httpx.post(
            f"{gateway_url}/acp/{cfg.name}/acp",
            content=json.dumps({
                "jsonrpc": "2.0", "id": 1,
                "method": "initialize",
                "params": {"protocolVersion": 1, "clientCapabilities": {}},
            }).encode("utf-8"),
            headers=headers,
            timeout=2.0,
        )
        if r.status_code == 200:
            try:
                if isinstance(r.json().get("result"), dict):
                    health = "ok"
            except (ValueError, AttributeError):
                pass
    except httpx.HTTPError:
        pass
    gw_pid = "?"
    try:
        from rtxclaw_agent.gateway import _gateway_pidfile
        pf = _gateway_pidfile()
        if pf.is_file():
            gw_pid = pf.read_text().strip() or "?"
    except Exception:  # noqa: BLE001
        pass
    sys.stderr.write(
        f"  agent={cfg.name} gateway_pid={gw_pid} "
        f"upstream={upstream} model={model} ({health})\n"
    )
    if _IS_SSH:
        sys.stderr.write(
            f"  [ssh] tui throttled to {_TUI_FPS} fps; "
            f"override with RTXCLAW_TUI_FPS=<n>. "
            f"For best feel, use `mosh` or `ssh -C`.\n"
        )
    sys.stderr.flush()


def _resolve_agent_or_fail(name: str) -> Optional["AgentConfig"]:
    """Resolve an agent and confirm the gateway is reachable.

    For the ``main`` agent: if it's not configured, run the first-run
    wizard so config exists on disk. We never spawn a process here —
    the rtxclaw gateway (``rtxclaw-gateway.service``) owns lifecycle
    and is the sole producer of agent stdio children. If the gateway
    isn't running, fail with a helpful systemctl pointer.
    """
    from rtxclaw_core.agent import AgentConfig
    from rtxclaw_agent import agent_cli as agentcli

    if name == "main":
        cfg = agentcli.ensure_main_configured()
    else:
        try:
            cfg = AgentConfig.load(name)
        except FileNotFoundError:
            sys.stderr.write(
                f"agent {name!r} not configured.\n"
                f"run `rtxclaw agent init {name}` first.\n"
            )
            return None
    if cfg is None:
        return None

    if not _gateway_alive():
        sys.stderr.write(
            "rtxclaw gateway is not running.\n"
            "bring it up once and for all with "
            "`rtxclaw gateway install-service`\n"
            "(installs the systemd unit so it starts on boot), or "
            "`rtxclaw gateway start`\n"
            "for a one-off background run. `rtxclaw configure` also "
            "offers this at\nthe end of the setup wizard.\n"
        )
        return None

    gateway_url, gateway_token = _gateway_url_and_token()
    headers: dict[str, str] = {"Content-Type": "application/json"}
    if gateway_token:
        headers["Authorization"] = f"Bearer {gateway_token}"
    try:
        r = httpx.post(
            f"{gateway_url}/acp/{name}/acp",
            content=json.dumps({
                "jsonrpc": "2.0", "id": 1,
                "method": "initialize",
                "params": {"protocolVersion": 1, "clientCapabilities": {}},
            }).encode("utf-8"),
            headers=headers,
            timeout=2.0,
        )
        if r.status_code != 200:
            raise httpx.HTTPError(f"HTTP {r.status_code}")
    except httpx.HTTPError as e:
        sys.stderr.write(
            f"agent {name!r} not reachable on the gateway at "
            f"{gateway_url}/acp/{name}: {e}\n"
        )
        return None
    _print_agent_ready(cfg)
    return cfg


def _launch_tui_via_agent(args: argparse.Namespace) -> int:
    cfg = _resolve_agent_or_fail(args.agent or "main")
    if cfg is None:
        return 2
    # `--endpoint <alias|url>`: resolve against the agent's named-endpoint
    # list, then carry both the resolved URL (for the daemon) and the
    # display alias (for the status bar) into the AgentChatApp. We mutate
    # `cfg` in place too so the initial status bar — rendered before any
    # session is created — already shows the override; the resolved
    # value is also passed to `create_session` so the daemon actually
    # spawns workers against the alternate host.
    initial_endpoint_override: Optional[str] = None
    if args.endpoint:
        resolved = cfg.resolve_endpoint(args.endpoint)
        if resolved:
            cfg.upstream_endpoint = resolved
            cfg.upstream_alias = cfg.resolve_alias(args.endpoint)
            initial_endpoint_override = resolved
    app = ChatApp.via_agent(cfg, endpoint_override=initial_endpoint_override)
    # CLI override of the initial permission mode (Shift+Tab still cycles
    # within the session). Useful for `rtxclaw --plan` to start in plan
    # mode without having to remember to tab over.
    cli_mode = getattr(args, "mode", None)
    if cli_mode and hasattr(app, "_permission_mode"):
        app._permission_mode = cli_mode
    app.run()
    return 0


def _oneshot_state_path(agent_name: str) -> Path:
    """Per-cwd state file remembering the last `rtxclaw --claude -p`
    rtxclaw session id, so `--continue` / `-c` can resume it.

    Path: `~/.rtxclaw/oneshot_claude/<agent>/<cwd_hash>.json` —
    namespaced by agent (so two agents have separate oneshot threads)
    and keyed by `cwd` (so different projects don't share Claude
    state, matching `claude --continue`'s per-cwd resume convention).
    """
    import hashlib
    cwd = str(Path.cwd().resolve())
    cwd_hash = hashlib.sha256(cwd.encode("utf-8")).hexdigest()[:16]
    base = Path.home() / ".rtxclaw" / "oneshot_claude" / agent_name
    return base / f"{cwd_hash}.json"


def _read_oneshot_state(agent_name: str) -> Optional[str]:
    p = _oneshot_state_path(agent_name)
    if not p.exists():
        return None
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    sid = data.get("session_id") if isinstance(data, dict) else None
    return sid if isinstance(sid, str) and sid else None


def _write_oneshot_state(agent_name: str, sid: str) -> None:
    p = _oneshot_state_path(agent_name)
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(
            json.dumps({"session_id": sid}, ensure_ascii=False),
            encoding="utf-8",
        )
    except OSError:
        pass


def _oneshot_codex_state_path(agent_name: str) -> Path:
    """Per-cwd state file for `rtxclaw --codex -p` `--continue` resume.

    Mirrors `_oneshot_state_path` but namespaced under `oneshot_codex`
    so claude and codex bridges keep independent rtxclaw-session
    caches: a `-c` follow-up always continues the same external agent
    it started with, never accidentally re-attaches a codex thread to
    a claude resume id.
    """
    import hashlib
    cwd = str(Path.cwd().resolve())
    cwd_hash = hashlib.sha256(cwd.encode("utf-8")).hexdigest()[:16]
    base = Path.home() / ".rtxclaw" / "oneshot_codex" / agent_name
    return base / f"{cwd_hash}.json"


def _read_oneshot_codex_state(agent_name: str) -> Optional[str]:
    p = _oneshot_codex_state_path(agent_name)
    if not p.exists():
        return None
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    sid = data.get("session_id") if isinstance(data, dict) else None
    return sid if isinstance(sid, str) and sid else None


def _write_oneshot_codex_state(agent_name: str, sid: str) -> None:
    p = _oneshot_codex_state_path(agent_name)
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(
            json.dumps({"session_id": sid}, ensure_ascii=False),
            encoding="utf-8",
        )
    except OSError:
        pass


async def _run_claude_oneshot(args: argparse.Namespace, prompt: str) -> int:
    """Bash bridge: `rtxclaw --claude -p "<prompt>"` → `delegate_claude` tool.

    The bash bridge routes through the same `delegate_claude` tool
    runner that the TUI's `/claude xxx` slash command and the local
    model's autonomous tool emit use. One path, one runner, one kill
    mechanism.

    Permission mode is mapped from the active rtxclaw mode
    (plan/ask/auto). Output is streamed to stdout token-by-token via
    the runner's streaming protocol. Ctrl+C cancels the stream,
    which propagates to the runner subprocess via SIGTERM.

    `--continue` / `-c`: reuse the most-recent rtxclaw session for
    this `(agent, cwd)` pair, so claude session reuse chains across
    bash-bridge invocations. The rtxclaw session id is persisted at
    `~/.rtxclaw/oneshot_claude/<agent>/<cwd-hash>.json`; the
    delegate_claude state file under that session id stores Claude's
    own `session_id` for `--resume`. Without `-c`, every invocation
    creates a fresh rtxclaw session (and therefore a fresh Claude
    thread). The state file is updated on every successful run so
    the NEXT `-c` finds it.

    Requires a running agent (the bridge is no longer self-contained).
    Surfaces a clear error if no agent is up.
    """
    from rtxclaw_tui.agent_client import AgentClient
    from rich.console import Console

    rtx_mode = getattr(args, "mode", None) or "auto"
    claude_mode = _claude_permission_mode(rtx_mode)
    continue_flag = bool(getattr(args, "bridge_continue", False))
    agent_name = args.agent or "main"

    cfg = _resolve_agent_or_fail(agent_name)
    if cfg is None:
        return 2

    out_tty = sys.stdout.isatty()
    err_tty = sys.stderr.isatty()
    err_console = Console(stderr=True, soft_wrap=True, highlight=False)
    out_console = Console()

    gateway_url, gateway_token = _gateway_url_and_token()
    client = AgentClient(
        cfg.url, agent_name=cfg.name,
        gateway_url=gateway_url, gateway_token=gateway_token,
    )
    try:
        # Resolve which rtxclaw session to attach to.
        sid: Optional[str] = None
        resumed = False
        if continue_flag:
            cached = _read_oneshot_state(agent_name)
            if cached:
                # Verify the session still exists on the agent — the
                # user might have rm'd it or it might be on a different
                # agent home. If gone, fall back to creating fresh.
                try:
                    await client.get_session(cached)
                    sid = cached
                    resumed = True
                except Exception:  # noqa: BLE001
                    sid = None
        if sid is None:
            sess = await client.create_session(
                workspace_cwd=os.getcwd(),
                workspace_origin="claude",
            )
            sid = sess["hash"]

        sid_short = sid[:12]
        head = (
            f"── claude ── mode={claude_mode}"
            f"{' resume=' + sid_short if resumed else ' new'}"
            f"{' (' + agent_name + ')' if agent_name != 'main' else ''}"
            f" ──"
        )
        if err_tty:
            err_console.print(f"[dim cyan]{head}[/dim cyan]")
        else:
            sys.stderr.write(head + "\n")
            sys.stderr.flush()

        answer_buf: list[str] = []
        claude_session_id: Optional[str] = None
        turn_id_seen: Optional[str] = None
        aborted = False

        try:
            async for event_name, data, tid in client.delegate(
                sid,
                prompt=prompt,
                tool="delegate_claude",
                mode=rtx_mode,
            ):
                turn_id_seen = tid or turn_id_seen
                if event_name == "started":
                    continue
                if event_name == "delta":
                    txt = data.get("text") or ""
                    if txt:
                        answer_buf.append(txt)
                        sys.stdout.write(txt)
                        sys.stdout.flush()
                    continue
                if event_name == "error":
                    err = data.get("error") or "delegate failed"
                    sys.stderr.write(f"\nclaude error: {err}\n")
                    return 1
                if event_name == "done":
                    if not data.get("ok"):
                        err = data.get("content") or "claude failed"
                        sys.stderr.write(f"\nclaude error: {err}\n")
                        return 1
                    cs_id = data.get("claude_session_id")
                    if isinstance(cs_id, str) and cs_id:
                        claude_session_id = cs_id
                    # If the agent didn't emit deltas (older runner or
                    # streaming protocol disabled), fall back to the
                    # full content from the `done` payload.
                    if not answer_buf:
                        full = data.get("content") or ""
                        if full:
                            sys.stdout.write(full)
                            sys.stdout.flush()
                            answer_buf.append(full)
                    break
        except KeyboardInterrupt:
            aborted = True
            if turn_id_seen:
                try:
                    await client.turn_stop(turn_id_seen)
                except httpx.HTTPError:
                    pass

        answer = "".join(answer_buf)
        if not answer.strip() and not aborted:
            sys.stderr.write("(empty answer)\n")
            return 1

        if out_tty and answer.strip():
            sys.stdout.write("\n")
            out_console.print(RichMarkdown(answer))
        else:
            if answer and not answer.endswith("\n"):
                sys.stdout.write("\n")
            sys.stdout.flush()

        # Persist the rtxclaw session id for `-c` next time. Done after
        # the call (not before) so a failed first call doesn't poison
        # the cache with a session that has no claude state — but ALSO
        # done before the early `return 1` paths below would matter,
        # because at this point `done.ok` was true.
        _write_oneshot_state(agent_name, sid)

        bits = [f"rtx={sid_short}"]
        if claude_session_id:
            bits.append(f"claude={claude_session_id[:12]}")
        bits.append("`-c` to continue")
        line = "── " + " · ".join(bits) + " ──"
        if err_tty:
            err_console.print(f"[dim cyan]{line}[/dim cyan]")
        else:
            sys.stderr.write(line + "\n")

        return 130 if aborted else 0
    finally:
        await client.close()


async def _run_codex_oneshot(args: argparse.Namespace, prompt: str) -> int:
    """Bash bridge: `rtxclaw --codex -p "<prompt>"` → `delegate_codex` tool.

    Mirrors `_run_claude_oneshot` against Codex: routes through the same
    `POST /v1/sessions/{sid}/delegate` endpoint with `tool="delegate_codex"`,
    streams `delta` events to stdout, persists Codex's `thread_id` via
    the runner-side state file, and uses an independent `oneshot_codex`
    cache for `-c` resume so claude and codex bridges never share state.
    """
    from rtxclaw_tui.agent_client import AgentClient
    from rich.console import Console

    rtx_mode = getattr(args, "mode", None) or "auto"
    sandbox_label = _codex_sandbox_label(rtx_mode)
    continue_flag = bool(getattr(args, "bridge_continue", False))
    agent_name = args.agent or "main"

    cfg = _resolve_agent_or_fail(agent_name)
    if cfg is None:
        return 2

    out_tty = sys.stdout.isatty()
    err_tty = sys.stderr.isatty()
    err_console = Console(stderr=True, soft_wrap=True, highlight=False)
    out_console = Console()

    gateway_url, gateway_token = _gateway_url_and_token()
    client = AgentClient(
        cfg.url, agent_name=cfg.name,
        gateway_url=gateway_url, gateway_token=gateway_token,
    )
    try:
        sid: Optional[str] = None
        resumed = False
        if continue_flag:
            cached = _read_oneshot_codex_state(agent_name)
            if cached:
                try:
                    await client.get_session(cached)
                    sid = cached
                    resumed = True
                except Exception:  # noqa: BLE001
                    sid = None
        if sid is None:
            sess = await client.create_session(
                workspace_cwd=os.getcwd(),
                workspace_origin="codex",
            )
            sid = sess["hash"]

        sid_short = sid[:12]
        head = (
            f"── codex ── mode={sandbox_label}"
            f"{' resume=' + sid_short if resumed else ' new'}"
            f"{' (' + agent_name + ')' if agent_name != 'main' else ''}"
            f" ──"
        )
        if err_tty:
            err_console.print(f"[dim cyan]{head}[/dim cyan]")
        else:
            sys.stderr.write(head + "\n")
            sys.stderr.flush()

        answer_buf: list[str] = []
        codex_thread_id: Optional[str] = None
        turn_id_seen: Optional[str] = None
        aborted = False

        try:
            async for event_name, data, tid in client.delegate(
                sid,
                prompt=prompt,
                tool="delegate_codex",
                mode=rtx_mode,
            ):
                turn_id_seen = tid or turn_id_seen
                if event_name == "started":
                    continue
                if event_name == "delta":
                    txt = data.get("text") or ""
                    if txt:
                        answer_buf.append(txt)
                        sys.stdout.write(txt)
                        sys.stdout.flush()
                    continue
                if event_name == "error":
                    err = data.get("error") or "delegate failed"
                    sys.stderr.write(f"\ncodex error: {err}\n")
                    return 1
                if event_name == "done":
                    if not data.get("ok"):
                        err = data.get("content") or "codex failed"
                        sys.stderr.write(f"\ncodex error: {err}\n")
                        return 1
                    cx_id = data.get("codex_thread_id")
                    if isinstance(cx_id, str) and cx_id:
                        codex_thread_id = cx_id
                    if not answer_buf:
                        full = data.get("content") or ""
                        if full:
                            sys.stdout.write(full)
                            sys.stdout.flush()
                            answer_buf.append(full)
                    break
        except KeyboardInterrupt:
            aborted = True
            if turn_id_seen:
                try:
                    await client.turn_stop(turn_id_seen)
                except httpx.HTTPError:
                    pass

        answer = "".join(answer_buf)
        if not answer.strip() and not aborted:
            sys.stderr.write("(empty answer)\n")
            return 1

        if out_tty and answer.strip():
            sys.stdout.write("\n")
            out_console.print(RichMarkdown(answer))
        else:
            if answer and not answer.endswith("\n"):
                sys.stdout.write("\n")
            sys.stdout.flush()

        _write_oneshot_codex_state(agent_name, sid)

        bits = [f"rtx={sid_short}"]
        if codex_thread_id:
            bits.append(f"codex={codex_thread_id[:12]}")
        bits.append("`-c` to continue")
        line = "── " + " · ".join(bits) + " ──"
        if err_tty:
            err_console.print(f"[dim cyan]{line}[/dim cyan]")
        else:
            sys.stderr.write(line + "\n")

        return 130 if aborted else 0
    finally:
        await client.close()


async def _run_oneshot_via_agent(args: argparse.Namespace, prompt: str) -> int:
    from rtxclaw_tui.agent_client import AgentClient
    from rich.console import Console

    cfg = _resolve_agent_or_fail(args.agent or "main")
    if cfg is None:
        return 2
    # `--endpoint <alias|url>`: resolve via the agent's named-endpoint
    # list, then send the URL through `create_session` so the daemon
    # binds this oneshot session to the alternate upstream.
    endpoint_override: Optional[str] = None
    if args.endpoint:
        resolved = cfg.resolve_endpoint(args.endpoint)
        if resolved:
            cfg.upstream_endpoint = resolved
            cfg.upstream_alias = cfg.resolve_alias(args.endpoint)
            endpoint_override = resolved

    out_tty = sys.stdout.isatty()
    err_tty = sys.stderr.isatty()
    err_console = Console(stderr=True, soft_wrap=True, highlight=False)
    out_console = Console()

    gateway_url, gateway_token = _gateway_url_and_token()
    client = AgentClient(
        cfg.url, agent_name=cfg.name,
        gateway_url=gateway_url, gateway_token=gateway_token,
    )
    try:
        sess = await client.create_session(
            workspace_cwd=os.getcwd(),
            workspace_origin="oneshot",
            endpoint=endpoint_override,
        )
        sid = sess["hash"]

        thinking_started = False
        content_buf: list[str] = []
        metrics: Optional[dict] = None
        turn_id_seen: Optional[str] = None
        aborted = False

        try:
            async for event, data, tid in client.session_turn(
                sid, user=prompt,
                enable_thinking=getattr(args, "enable_thinking", None),
                permission_mode=getattr(args, "mode", None),
            ):
                turn_id_seen = tid or turn_id_seen
                if event == "started":
                    continue
                if event == "chunk":
                    delta = (data.get("choices") or [{}])[0].get("delta") or {}
                    rc = delta.get("reasoning") or delta.get("reasoning_content")
                    if rc:
                        if not thinking_started:
                            if err_tty:
                                err_console.print("[dim cyan]── thinking ──[/dim cyan]")
                            else:
                                sys.stderr.write("── thinking ──\n")
                            thinking_started = True
                        if err_tty:
                            err_console.print(f"[dim]{rc}[/dim]", end="")
                        else:
                            sys.stderr.write(rc)
                            sys.stderr.flush()
                    txt = delta.get("content")
                    if txt:
                        content_buf.append(txt)
                elif event == "metrics":
                    metrics = data
                elif event == "error":
                    sys.stderr.write(f"\nerror: {data.get('message')}\n")
                    return 1
                elif event == "done":
                    pass
        except KeyboardInterrupt:
            aborted = True
            if turn_id_seen:
                try:
                    await client.turn_stop(turn_id_seen)
                except httpx.HTTPError:
                    pass

        if thinking_started:
            sys.stderr.write("\n")

        answer = "".join(content_buf)
        if not answer.strip():
            sys.stderr.write("(empty answer)\n")
            return 1

        if out_tty:
            if err_tty:
                err_console.print("[dim cyan]── answer ──[/dim cyan]")
            out_console.print(RichMarkdown(answer))
        else:
            sys.stdout.write(answer)
            if not answer.endswith("\n"):
                sys.stdout.write("\n")
            sys.stdout.flush()

        if metrics:
            parts = []
            if metrics.get("model"):
                parts.append(str(metrics["model"]))
            if metrics.get("ttft_ms") is not None:
                parts.append(f"ttft {metrics['ttft_ms']:.0f}ms")
            prefill_v = metrics.get("prefill_ms")
            accept_v = metrics.get("accept_ms")
            if accept_v is None:
                accept_v = metrics.get("pft_ms")
            if prefill_v is not None:
                parts.append(f"prefill {prefill_v:.0f}ms")
            elif accept_v is not None:
                parts.append(f"accept {accept_v:.0f}ms")
            if metrics.get("tps") is not None:
                est = "≈" if metrics.get("tokens_estimated") else ""
                parts.append(f"{metrics['tps']:.1f} tok/s{est}")
            if metrics.get("completion_tokens") is not None:
                parts.append(f"{metrics['completion_tokens']} tok")
            if metrics.get("wt_ms") is not None:
                parts.append(f"wt {metrics['wt_ms']/1000:.1f}s")
            line = "── " + " · ".join(parts) + " ──"
            if err_tty:
                err_console.print(f"[dim cyan]{line}[/dim cyan]")
            else:
                sys.stderr.write(line + "\n")

        return 130 if aborted else 0
    finally:
        await client.close()


def _launch_tui(args: argparse.Namespace) -> int:
    cfg = cfgmod.effective()
    endpoint = cfgmod.resolve_endpoint(args.endpoint, cfg)
    model = args.model if args.model is not None else cfg["model"]
    system = cfg["system"]
    temperature = cfg["temperature"]

    if not model:
        try:
            model = asyncio.run(discover_model(endpoint))
        except Exception as e:  # noqa: BLE001
            detail = str(e) or repr(e)
            sys.stderr.write(f"failed to discover model from {endpoint}: {detail}\n")
            sys.stderr.write(
                "fix the endpoint with `rtxclaw configure --endpoint http://IP:PORT/v1`\n"
                "or pin a model with `rtxclaw configure --model NAME`.\n"
            )
            return 2

    enable_thinking = bool(cfg["enable_thinking"])
    if getattr(args, "enable_thinking", None) is not None:
        enable_thinking = args.enable_thinking

    app = ChatApp(
        endpoint=endpoint,
        model=model,
        system=system,
        temperature=temperature,
        enable_thinking=enable_thinking,
    )
    app.run()
    return 0


async def _run_oneshot(args: argparse.Namespace, prompt: str) -> int:
    cfg = cfgmod.effective()
    endpoint = cfgmod.resolve_endpoint(args.endpoint, cfg)
    model = args.model if args.model is not None else cfg["model"]
    enable_thinking = bool(cfg["enable_thinking"])
    if getattr(args, "enable_thinking", None) is not None:
        enable_thinking = args.enable_thinking

    if not model:
        try:
            model = await discover_model(endpoint)
        except Exception as e:  # noqa: BLE001
            sys.stderr.write(f"failed to discover model from {endpoint}: {str(e) or repr(e)}\n")
            return 2

    system_full = ctxmod.load_system_prompt(cfg["system"])
    request = {
        "endpoint": endpoint,
        "model": model,
        "messages": [
            {"role": "system", "content": system_full},
            {"role": "user", "content": prompt},
        ],
        "temperature": cfg["temperature"],
        "extra": {"chat_template_kwargs": {"enable_thinking": enable_thinking}},
    }

    package_parent = str(Path(__file__).resolve().parent.parent)
    env = dict(os.environ)
    existing = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = package_parent + (os.pathsep + existing if existing else "")
    env["PYTHONUNBUFFERED"] = "1"

    proc = await asyncio.create_subprocess_exec(
        sys.executable, "-m", "rtxclaw_agent.worker",
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        env=env,
        limit=_SUBPROCESS_STDIO_LIMIT,
    )
    assert proc.stdin is not None
    proc.stdin.write(json.dumps(request).encode("utf-8"))
    await proc.stdin.drain()
    proc.stdin.close()

    from rich.console import Console

    out_tty = sys.stdout.isatty()
    err_tty = sys.stderr.isatty()
    err_console = Console(stderr=True, soft_wrap=True, highlight=False)
    out_console = Console()

    thinking_started = False
    content_buf: list[str] = []
    error: Optional[str] = None
    aborted = False
    metrics: Optional[dict] = None

    def _emit_thinking_header() -> None:
        nonlocal thinking_started
        if thinking_started:
            return
        if err_tty:
            err_console.print("[dim cyan]── thinking ──[/dim cyan]")
        else:
            sys.stderr.write("── thinking ──\n")
            sys.stderr.flush()
        thinking_started = True

    try:
        assert proc.stdout is not None
        while True:
            line = await proc.stdout.readline()
            if not line:
                break
            try:
                ev = json.loads(line.decode("utf-8"))
            except json.JSONDecodeError:
                continue
            kind = ev.get("kind")
            if kind == "thinking":
                _emit_thinking_header()
                txt = ev.get("text", "")
                if err_tty:
                    err_console.print(f"[dim]{txt}[/dim]", end="")
                else:
                    sys.stderr.write(txt)
                    sys.stderr.flush()
            elif kind == "content":
                content_buf.append(ev.get("text", ""))
            elif kind == "aborted":
                aborted = True
            elif kind == "error":
                error = ev.get("message")
            elif kind == "metrics":
                metrics = {k: v for k, v in ev.items() if k != "kind"}
    except KeyboardInterrupt:
        aborted = True
        try:
            proc.terminate()
        except ProcessLookupError:
            pass
    finally:
        await proc.wait()

    if thinking_started:
        sys.stderr.write("\n")
        sys.stderr.flush()

    if error:
        sys.stderr.write(f"error: {error}\n")
        return 1
    if aborted:
        sys.stderr.write("aborted\n")
        return 130

    answer = "".join(content_buf)
    if not answer.strip():
        sys.stderr.write("(empty answer)\n")
        return 1

    if out_tty:
        if err_tty:
            err_console.print("[dim cyan]── answer ──[/dim cyan]")
        out_console.print(RichMarkdown(answer))
    else:
        sys.stdout.write(answer)
        if not answer.endswith("\n"):
            sys.stdout.write("\n")
        sys.stdout.flush()

    if metrics:
        parts = []
        if metrics.get("model"):
            parts.append(str(metrics["model"]))
        if metrics.get("ttft_ms") is not None:
            parts.append(f"ttft {metrics['ttft_ms']:.0f}ms")
        prefill_v = metrics.get("prefill_ms")
        accept_v = metrics.get("accept_ms")
        if accept_v is None:
            accept_v = metrics.get("pft_ms")
        if prefill_v is not None:
            parts.append(f"prefill {prefill_v:.0f}ms")
        elif accept_v is not None:
            parts.append(f"accept {accept_v:.0f}ms")
        if metrics.get("tps") is not None:
            est = "≈" if metrics.get("tokens_estimated") else ""
            parts.append(f"{metrics['tps']:.1f} tok/s{est}")
        if metrics.get("completion_tokens") is not None:
            parts.append(f"{metrics['completion_tokens']} tok")
        if metrics.get("wt_ms") is not None:
            parts.append(f"wt {metrics['wt_ms']/1000:.1f}s")
        line = "── " + " · ".join(parts) + " ──"
        if err_tty:
            err_console.print(f"[dim cyan]{line}[/dim cyan]")
        else:
            sys.stderr.write(line + "\n")
            sys.stderr.flush()

    return 0


def main() -> None:
    parser = argparse.ArgumentParser(prog="rtxclaw", description="Sovereign-inference TUI chat.")
    parser.add_argument("--endpoint", help="Endpoint alias (from config) or raw URL for this run only")
    parser.add_argument("--model", help="Override model for this run only (required — no auto-discover)")
    parser.add_argument(
        "-p", "--prompt",
        help="One-shot mode: send PROMPT, stream thinking to stderr, render answer to stdout, exit.",
    )
    parser.add_argument(
        "--enable-thinking",
        dest="enable_thinking",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="Enable/disable Qwen3-style chat-template thinking for this run",
    )

    parser.add_argument(
        "-a", "--agent", default="main",
        help="Name of the agent to talk to (default: main).",
    )

    # Permission mode: pick one. The mutually-exclusive aliases (`--plan`,
    # `--ask`, `--auto`) are convenience shortcuts; `--mode <name>` is the
    # canonical form and accepts the literal mode names. If unset, the
    # agent's configured default applies (typically `auto`).
    mode_grp = parser.add_mutually_exclusive_group()
    mode_grp.add_argument(
        "--mode", choices=("plan", "ask", "auto"), default=None,
        help="Permission mode for this run (overrides agent default).",
    )
    mode_grp.add_argument("--plan", dest="mode", action="store_const", const="plan",
                          help="Shortcut for --mode plan (read-only, exhaustive answers).")
    mode_grp.add_argument("--ask", dest="mode", action="store_const", const="ask",
                          help="Shortcut for --mode ask (prompt before mutations).")
    mode_grp.add_argument("--auto", dest="mode", action="store_const", const="auto",
                          help="Shortcut for --mode auto (autonomous; pause on destructive).")

    # `--claude` / `--codex` route the prompt through the agent
    # runtime's `delegate_claude` / `delegate_codex` tool — same path
    # as the TUI's `/claude` / `/codex` slash command and the local
    # model's autonomous tool emit. Active mode (--plan/--ask/--auto)
    # maps to the external agent's permission level. `--continue` /
    # `-c` resumes the most-recent `rtxclaw --<bridge> -p` session for
    # this `(agent, cwd, bridge)` triple, so external-agent session
    # reuse chains across bash-bridge calls. Mutually exclusive: one
    # call goes to one bridge.
    bridge_grp = parser.add_mutually_exclusive_group()
    bridge_grp.add_argument(
        "--claude", action="store_true", default=False,
        help="One-shot via the agent's delegate_claude tool (requires a running agent).",
    )
    bridge_grp.add_argument(
        "--codex", action="store_true", default=False,
        help="One-shot via the agent's delegate_codex tool (requires a running agent).",
    )
    parser.add_argument(
        "--continue", "-c",
        dest="bridge_continue", action="store_true", default=False,
        help=(
            "(with --claude or --codex) resume the most recent "
            "`rtxclaw --<bridge> -p` session for this (agent, cwd, bridge) "
            "triple so the external agent's resume keeps the same "
            "conversation across invocations."
        ),
    )

    sub = parser.add_subparsers(dest="cmd")

    # `rtxclaw agent ...`
    from rtxclaw_agent import agent_cli as agentcli
    agentcli.add_subparser(sub)

    # `rtxclaw gateway ...` — single-process agent gateway lifecycle.
    # Hosts every agent as a stdio-ACP child subprocess; SIGTERM here
    # cascades to every live child. See ``rtxclaw_agent.gateway`` for
    # the full architecture.
    from rtxclaw_agent import gateway_cli as gw_cli
    gw_cli.add_subparser(sub)

    # `rtxclaw telegram ...` — standalone Telegram bot lifecycle.
    # Lives in its own module so the bot's CLI surface stays
    # decoupled from any one agent.
    from rtxclaw_telegram import cli as tg_cli
    tg_cli.add_subparser(sub)

    pc = sub.add_parser("configure", help="Set or show persistent config")
    pc.add_argument("--endpoint", help="vLLM/OpenAI-compatible base URL (e.g. http://host:8000/v1)")
    pc.add_argument("--model", help="Model id to pin (required — no auto-discover)")
    pc.add_argument("--system", help="System prompt")
    pc.add_argument("--temperature", type=float, help="Sampling temperature")
    pc.add_argument(
        "--enable-thinking",
        dest="enable_thinking",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="Persist whether to send chat_template_kwargs.enable_thinking=true (Qwen3 family)",
    )
    pc.add_argument("--show", action="store_true", help="Print effective config and exit")
    pc.add_argument("--agent", default="main", help="Agent name for per-agent fields (default: main)")
    pc.add_argument("--telegram-bot-token", help="Telegram BotFather token (per-agent)")
    pc.add_argument("--telegram-allowed-chat-ids", help="Comma-separated list of allowed Telegram chat_ids (per-agent)")
    pc.add_argument(
        "--telegram-allowed-user-ids",
        help=(
            "Comma-separated Telegram user ids the bot will reply to. "
            "When set, every other sender (even inside an allowed chat) is "
            "ignored silently. Pass an empty string to clear and revert to "
            "'any member of an allowed chat may interact'."
        ),
    )
    pc.add_argument(
        "--telegram-mention-required",
        choices=["on", "off"],
        help=(
            "Reply only when the bot is @-mentioned (or replied to) in "
            "non-private chats. DMs are unaffected. Default off; flip on "
            "for shared groups where the bot should stay quiet otherwise."
        ),
    )

    # `rtxclaw doctor ...` — let the agent fix its own logged errors.
    from rtxclaw_agent import doctor as doctor_mod
    doctor_mod.add_subparser(sub)

    # `rtxclaw session ...` — operate on saved agent sessions from the shell.
    # Same agent the TUI/`-p` flows use (selected via `-a/--agent`).
    psess = sub.add_parser("session", help="List or compact agent sessions")
    psess_inner = psess.add_subparsers(dest="op", required=True)
    psess_list = psess_inner.add_parser("list", help="List saved sessions for the selected agent")
    psess_list.add_argument(
        "-n", "--limit", type=int, default=20,
        help="Max sessions to print (default: 20, most recent first).",
    )
    psess_compact = psess_inner.add_parser(
        "compact",
        help="Trim oversized tool results in a saved session (between-turn /compact).",
    )
    psess_compact.add_argument(
        "sid", nargs="?",
        help="Session hash. Omit to compact the most recently modified session.",
    )
    psess_compact.add_argument(
        "--keep-recent-turns", type=int, default=1,
        help="Trailing turns to leave fully intact (default 1).",
    )
    psess_compact.add_argument(
        "--min-result-chars", type=int, default=800,
        help="Minimum tool_result length to consider for trimming (default 800).",
    )
    psess_compact.add_argument(
        "--head-chars", type=int, default=400,
        help="Chars kept from the head of each trimmed result (default 400).",
    )
    psess_compact.add_argument(
        "--json", action="store_true",
        help="Print the raw audit JSON instead of a human-readable summary.",
    )

    # `rtxclaw memory ...` — inspect / search / rebuild the SQLite memory index.
    pm = sub.add_parser(
        "memory",
        help="Inspect, search, rebuild, or prune the agent's memory index",
    )
    pm_inner = pm.add_subparsers(dest="op", required=True)
    pm_status = pm_inner.add_parser("status", help="Show index health (chunks, db size, scope, last indexed)")
    pm_status.add_argument("-a", "--agent", default="main", help="Agent name (default 'main')")
    pm_search = pm_inner.add_parser("search", help="Run a memory search and print results")
    pm_search.add_argument("-a", "--agent", default="main")
    pm_search.add_argument("query", help="Search query")
    pm_search.add_argument("-k", "--top-k", type=int, default=6)
    pm_search.add_argument("--min-score", type=float, default=0.35,
                           help="Absolute fused-score floor (0-1, default 0.35).")
    pm_search.add_argument("--relevance-floor", type=float, default=0.0,
                           help="Relative-to-best filter as a fraction of the top hit's score (0-1, default 0 = off).")
    pm_search.add_argument("--json", action="store_true", help="Emit machine-readable JSON instead of formatted snippets")
    pm_index = pm_inner.add_parser("index", help="Re-index memory files now")
    pm_index.add_argument("-a", "--agent", default="main")
    pm_index.add_argument(
        "--force", action="store_true",
        help="Drop chunks/FTS/vec first, then re-index from scratch. "
             "Embedding cache is KEPT — unchanged content reuses cached vectors.",
    )
    pm_index.add_argument(
        "--reembed", action="store_true",
        help="Drop chunks/FTS/vec AND the embedding cache, then re-embed every "
             "chunk via the configured provider's API. Implies --force. Use this "
             "when switching embedding models or recovering from a poisoned cache.",
    )
    pm_prune = pm_inner.add_parser("prune", help="Drop chunks for daily logs older than N days (MEMORY.md is always kept)")
    pm_prune.add_argument("-a", "--agent", default="main")
    pm_prune.add_argument("--older-than-days", type=int, default=365, help="Delete daily-log chunks older than this many days (default 365)")
    pm_synth = pm_inner.add_parser(
        "synth",
        help=(
            "Force a memory synthesis pass — read MEMORY.md + recent "
            "dailies, rewrite MEMORY.md via the configured upstream"
        ),
    )
    pm_synth.add_argument("-a", "--agent", default="main")
    pm_synth.add_argument(
        "--force", action="store_true",
        help="Bypass the 'no daily newer than MEMORY.md' guard so an "
             "operator can re-run synth on demand without touching a "
             "daily file.",
    )
    pm_synth.add_argument(
        "--model", default=None,
        help="Override the model id. Defaults to memory_flush_model "
             "(if set) → upstream_model.",
    )
    pm_synth.add_argument(
        "--endpoint", default=None,
        help="Override the upstream endpoint URL. Defaults to "
             "agent.upstream_endpoint.",
    )
    pm_synth.add_argument(
        "--timeout", type=float, default=60.0,
        help="HTTP timeout for the synth completion (default 60s).",
    )
    pm_synth.add_argument(
        "--json", action="store_true",
        help="Emit the raw stats dict as JSON instead of a formatted line.",
    )

    # `rtxclaw skills ...` — discover / show / import AgentSkills-format skills.
    ps = sub.add_parser("skills", help="List, show, or import AgentSkills-format skills")
    ps_inner = ps.add_subparsers(dest="op", required=True)
    ps_list = ps_inner.add_parser("list", help="List discovered skills (across the search chain)")
    ps_list.add_argument("-v", "--verbose", action="store_true", help="Show source paths")
    ps_show = ps_inner.add_parser("show", help="Print one skill's SKILL.md body")
    ps_show.add_argument("name", help="Skill name (as in `rtxclaw skills list`)")
    ps_imp = ps_inner.add_parser("import", help="Snapshot an OpenClaw skill into ~/.rtxclaw/skills/")
    ps_imp.add_argument("name", help="OpenClaw skill name (under ~/.openclaw/skills/)")

    args = parser.parse_args()

    if args.cmd == "configure":
        sys.exit(_cmd_configure(args))
    if args.cmd == "agent":
        from rtxclaw_agent import agent_cli as agentcli
        sys.exit(agentcli.dispatch(args))
    if args.cmd == "gateway":
        from rtxclaw_agent import gateway_cli as gw_cli
        sys.exit(gw_cli.dispatch(args))
    if args.cmd == "session":
        sys.exit(asyncio.run(_cmd_session(args)))
    if args.cmd == "memory":
        sys.exit(_cmd_memory(args))
    if args.cmd == "skills":
        sys.exit(_cmd_skills(args))
    if args.cmd == "doctor":
        from rtxclaw_agent import doctor as doctor_mod
        sys.exit(doctor_mod.dispatch(args))
    if args.cmd == "telegram":
        # ``rtxclaw_telegram.cli`` wires ``set_defaults(_dispatch=...)``
        # on each ``telegram <cmd>`` parser; without this branch the
        # call would fall through to ``_launch_tui_via_agent`` and
        # ``rtxclaw telegram stop`` / ``restart`` (used heavily by
        # test_08 and test_10) would silently launch the TUI and
        # never exit, surfacing as ``subprocess.TimeoutExpired``.
        dispatch = getattr(args, "_dispatch", None)
        if dispatch is None:
            # Bare ``rtxclaw telegram`` with no subcommand — exit 0.
            sys.exit(0)
        sys.exit(dispatch(args))
    if args.prompt is not None:
        if getattr(args, "claude", False):
            sys.exit(asyncio.run(_run_claude_oneshot(args, args.prompt)))
        if getattr(args, "codex", False):
            sys.exit(asyncio.run(_run_codex_oneshot(args, args.prompt)))
        sys.exit(asyncio.run(_run_oneshot_via_agent(args, args.prompt)))
    sys.exit(_launch_tui_via_agent(args))


if __name__ == "__main__":
    main()
