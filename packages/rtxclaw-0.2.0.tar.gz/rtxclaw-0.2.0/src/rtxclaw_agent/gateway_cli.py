"""CLI subcommands for the single-process agent gateway.

Wired into the top-level ``rtxclaw`` parser as the ``gateway`` subcommand:

    rtxclaw gateway start            # daemonize the gateway
    rtxclaw gateway stop             # SIGTERM the gateway (cascades to children)
    rtxclaw gateway restart
    rtxclaw gateway status           # pid/uptime + agent/child summary
    rtxclaw gateway serve            # foreground (used by start)
    rtxclaw gateway logs             # tail -f gateway.log

Daemon control uses pidfile signals (mirrors ``agent_cli``). The
gateway pidfile lives at ``~/.rtxclaw/gateway.pid`` (separate from
per-agent pidfiles so the legacy daemon and the gateway can coexist
during migration).

Cancel cascade contract: SIGTERM here triggers the gateway's signal
handler, which stops every per-agent heartbeat scheduler and drains
the shared HTTP listener — the operator's ``gateway stop`` is
therefore a "stop everything" button.
"""
from __future__ import annotations

import argparse
import getpass
import os
import shutil
import signal
import subprocess
import sys
import time
from pathlib import Path

import httpx

from .gateway import (
    _DEFAULT_HOST,
    _DEFAULT_PORT,
    _gateway_config,
    _gateway_pidfile,
)


# ---- systemd service -------------------------------------------------
#
# The setup wizard (and ``rtxclaw gateway install-service``) generate a
# unit tailored to THIS install — current user, current venv, current
# ``RTXCLAW_HOME`` — instead of shipping a hand-edited file. A fresh
# ``pip install rtxclaw`` therefore goes: wizard → service installed +
# started → ``rtxclaw`` drops you into the TUI, no manual ``systemctl``
# step. ``deploy/systemd/rtxclaw-gateway.service`` stays in the repo as
# a readable reference, but it is NOT what gets installed.

_SERVICE_NAME = "rtxclaw-gateway.service"
_UNIT_PATH = Path("/etc/systemd/system") / _SERVICE_NAME


# ---- helpers ---------------------------------------------------------


def _read_pid() -> int | None:
    pidfile = _gateway_pidfile()
    if not pidfile.exists():
        return None
    try:
        return int(pidfile.read_text().strip())
    except (OSError, ValueError):
        return None


def _is_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except (PermissionError, ProcessLookupError):
        return False


def _port_holder(host: str, port: int) -> int | None:
    """Return the pid holding ``host:port`` in LISTEN state, or None.

    Parses ``/proc/net/tcp`` directly so we don't depend on ``ss`` /
    ``lsof`` being on PATH and don't require sudo. Only matches IPv4 +
    IPv6 LISTEN sockets bound to the requested host (or 0.0.0.0 / ::).
    Returns the pid if the inode-to-pid lookup succeeds; if the socket
    is owned by another user (kernel exposes inode 0), returns -1 as a
    sentinel meaning "port is in use but pid not visible to us" so the
    caller can still surface a clean error.
    """
    import socket as _socket
    try:
        ip_int = int.from_bytes(
            _socket.inet_aton("127.0.0.1" if host in ("localhost", "127.0.0.1") else host),
            "big",
        )
    except OSError:
        return None
    target_local_hex = f"{ip_int:08X}".upper()
    target_any_hex = "00000000"
    target_port_hex = f"{port:04X}".upper()
    inode_to_match: set[str] = set()
    for tcp_path in ("/proc/net/tcp", "/proc/net/tcp6"):
        try:
            with open(tcp_path, "r") as fh:
                next(fh, None)  # header
                for line in fh:
                    cols = line.split()
                    if len(cols) < 10:
                        continue
                    state = cols[3]
                    if state != "0A":  # 0A = LISTEN
                        continue
                    local = cols[1]
                    if ":" not in local:
                        continue
                    addr_hex, port_hex = local.split(":", 1)
                    if port_hex.upper() != target_port_hex:
                        continue
                    if "tcp6" in tcp_path:
                        # IPv6 — accept any address since dual-stack
                        # listeners on `::` cover IPv4-mapped too.
                        inode_to_match.add(cols[9])
                    else:
                        if addr_hex.upper() in (target_local_hex, target_any_hex):
                            inode_to_match.add(cols[9])
        except OSError:
            continue
    if not inode_to_match:
        return None
    # Walk /proc/*/fd/* looking for socket:[<inode>] symlinks. Skip
    # processes whose fd dir we can't read (other users).
    visible_pid: int | None = None
    for proc_dir in os.listdir("/proc"):
        if not proc_dir.isdigit():
            continue
        fd_dir = f"/proc/{proc_dir}/fd"
        try:
            fds = os.listdir(fd_dir)
        except OSError:
            continue
        for fd in fds:
            try:
                target = os.readlink(f"{fd_dir}/{fd}")
            except OSError:
                continue
            if target.startswith("socket:[") and target[8:-1] in inode_to_match:
                visible_pid = int(proc_dir)
                return visible_pid
    # Inode found in /proc/net/tcp but no /proc/*/fd link visible —
    # the listener is owned by another user.
    return -1


def _running() -> tuple[bool, int | None]:
    """Return ``(alive, pid)`` for the gateway tracked by the pidfile.

    Note: this only reports the CLI-tracked pid. If a *different* pid
    (e.g. one started by systemd) holds the configured port, this
    function returns ``(False, None)`` and the caller is expected to
    consult ``_port_holder`` before spawning. Without that check the
    caller would happily start another orphan that fails to bind —
    the historical "10 zombie gateways" bug.
    """
    pid = _read_pid()
    if pid is None:
        return False, None
    if _is_alive(pid):
        return True, pid
    # Stale pidfile.
    try:
        _gateway_pidfile().unlink()
    except FileNotFoundError:
        pass
    return False, pid


def _wait_for_listener(url: str, *, timeout: float = 15.0) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            r = httpx.get(f"{url}/health", timeout=1.0)
            if r.status_code:
                return True
        except httpx.ConnectError:
            pass
        time.sleep(0.2)
    return False


def _gateway_logfile() -> Path:
    return Path(os.environ.get("RTXCLAW_HOME") or Path.home() / ".rtxclaw") / "gateway.log"


def _rtxclaw_home() -> Path:
    return Path(os.environ.get("RTXCLAW_HOME") or Path.home() / ".rtxclaw")


def start_gateway_background() -> dict:
    """Daemonize ``rtxclaw gateway-serve`` and wait for the listener.

    Returns ``{"ok", "already_running", "pid", "url", "error"}``. Kept
    free of stdout chatter so the setup wizard can call it directly;
    :func:`cmd_start` wraps it for the CLI and does the printing.
    """
    gw = _gateway_config()
    url = f"http://{gw['host']}:{gw['port']}"
    running, pid = _running()
    if running:
        return {"ok": True, "already_running": True, "pid": pid, "url": url, "error": None}
    # Port-conflict guard — see cmd_start's docstring for the orphan-
    # accumulation bug this prevents.
    holder = _port_holder(gw["host"], int(gw["port"]))
    if holder is not None:
        if holder == -1:
            err = (
                f"another process already holds {url} (owned by a different "
                f"user — pid not visible). Stop it with `sudo systemctl stop "
                f"rtxclaw-gateway` (if systemd-managed) or whatever started it."
            )
        else:
            err = (
                f"another process already holds {url} (pid={holder}). The "
                f"CLI's pidfile doesn't track it — stop it with `rtxclaw "
                f"gateway stop`, or `sudo systemctl restart rtxclaw-gateway` "
                f"if systemd-managed."
            )
        return {
            "ok": False, "already_running": False,
            "pid": holder if holder and holder > 0 else None,
            "url": url, "error": err,
        }
    log_path = _gateway_logfile()
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_fp = open(log_path, "ab", buffering=0)
    try:
        proc = subprocess.Popen(
            [sys.executable, "-m", "rtxclaw_agent", "gateway-serve"],
            stdin=subprocess.DEVNULL,
            stdout=log_fp,
            stderr=log_fp,
            env=os.environ.copy(),
            start_new_session=True,
        )
    except OSError as e:
        log_fp.close()
        return {"ok": False, "already_running": False, "pid": None, "url": url,
                "error": f"failed to spawn gateway: {e}"}
    # The child inherited its own dup of the fd; drop the parent copy.
    log_fp.close()
    if not _wait_for_listener(url, timeout=20.0):
        return {
            "ok": False, "already_running": False, "pid": proc.pid, "url": url,
            "error": (
                f"gateway listener at {url} did not respond within 20s "
                f"(pid={proc.pid}). Check {log_path}."
            ),
        }
    return {"ok": True, "already_running": False, "pid": proc.pid, "url": url, "error": None}


def systemd_available() -> bool:
    """True iff this host runs systemd and ``systemctl`` is on PATH.

    ``/run/systemd/system`` exists only when systemd is PID 1, so this
    cleanly returns False inside most containers / dev sandboxes — the
    caller then falls back to a plain background gateway.
    """
    return Path("/run/systemd/system").is_dir() and shutil.which("systemctl") is not None


def _resolve_gateway_exec() -> str:
    """Absolute ExecStart line for the unit.

    Prefers the installed ``rtxclaw`` console script (a ``pip install``
    venv puts one on PATH); falls back to ``<python> -m rtxclaw_agent
    gateway-serve`` so an editable / PYTHONPATH-only install still
    produces a working unit.
    """
    exe = shutil.which("rtxclaw")
    if exe:
        return f"{exe} gateway serve"
    return f"{sys.executable} -m rtxclaw_agent gateway-serve"


def render_gateway_unit() -> str:
    """Render the ``rtxclaw-gateway.service`` unit for THIS install.

    Everything the shipped template hard-codes (user, home, venv path,
    PYTHONPATH) is resolved at call time instead, so the unit is
    correct on any box a fresh ``pip install`` lands on.
    """
    user = getpass.getuser()
    try:
        import grp
        group = grp.getgrgid(os.getgid()).gr_name
    except Exception:  # noqa: BLE001
        group = user
    home = _rtxclaw_home()
    # Build a deterministic PATH rather than inheriting the (often
    # polluted) interactive-shell PATH: the venv bin dir first — so the
    # gateway's child processes (bundled MCP servers, CLI engines)
    # resolve against the SAME interpreter the gateway runs under —
    # then ``~/.local/bin`` (where ``pip install --user`` / pipx land
    # the ``rtxclaw`` script) and the standard system dirs.
    venv_bin = str(Path(sys.executable).parent)
    _path_parts = [
        venv_bin,
        str(Path.home() / ".local" / "bin"),
        "/usr/local/sbin", "/usr/local/bin",
        "/usr/sbin", "/usr/bin", "/sbin", "/bin", "/snap/bin",
    ]
    _seen: set[str] = set()
    path_env = os.pathsep.join(
        p for p in _path_parts if p and not (p in _seen or _seen.add(p))
    )
    return f"""\
[Unit]
Description=rtxclaw single-process agent gateway (hosts every agent as a stdio child)
After=network-online.target
Wants=network-online.target
StartLimitIntervalSec=300
StartLimitBurst=10

[Service]
Type=simple
User={user}
Group={group}
WorkingDirectory={home}
EnvironmentFile=-/etc/environment
EnvironmentFile=-{home}/.env
Environment="PATH={path_env}"
ExecStart={_resolve_gateway_exec()}
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=rtxclaw-gateway

[Install]
WantedBy=multi-user.target
"""


def _run_sudo(argv: list[str], *, interactive: bool, stdin: str | None = None
              ) -> subprocess.CompletedProcess:
    """Run ``argv`` under sudo. ``interactive=False`` adds ``-n`` so the
    call fails fast instead of blocking on a password prompt nobody
    will see (used by non-tty callers)."""
    sudo = ["sudo"] if interactive else ["sudo", "-n"]
    return subprocess.run(  # noqa: S603
        sudo + argv,
        input=stdin,
        capture_output=True,
        text=True,
        timeout=120,
    )


def install_systemd_service(*, enable: bool = True, start: bool = True,
                            interactive: bool = True) -> dict:
    """Install + enable + start ``rtxclaw-gateway.service``.

    Generates a unit tailored to this install (see
    :func:`render_gateway_unit`), writes it to ``/etc/systemd/system``
    via ``sudo tee``, ``daemon-reload``s, then ``enable``s and
    ``restart``s the unit (``restart`` covers both the cold-install and
    the re-run cases). Returns
    ``{"ok", "error", "unit_path", "url", "enabled", "started"}``.

    ``interactive=True`` (the default, used by the wizard and the CLI)
    lets ``sudo`` prompt for a password; ``interactive=False`` uses
    ``sudo -n`` for headless callers.
    """
    gw = _gateway_config()
    url = f"http://{gw['host']}:{gw['port']}"
    result: dict = {
        "ok": False, "error": None, "unit_path": str(_UNIT_PATH),
        "url": url, "enabled": False, "started": False,
    }
    if not systemd_available():
        result["error"] = "systemd not available on this host"
        return result
    # WorkingDirectory must exist before systemd will start the unit.
    try:
        _rtxclaw_home().mkdir(parents=True, exist_ok=True)
    except OSError as e:
        result["error"] = f"could not create {_rtxclaw_home()}: {e}"
        return result

    unit = render_gateway_unit()
    try:
        # `sudo tee` writes the unit as root from stdin — no temp file,
        # no world-readable intermediate.
        cp = _run_sudo(["tee", str(_UNIT_PATH)], interactive=interactive, stdin=unit)
        if cp.returncode != 0:
            hint = (cp.stderr or cp.stdout or "").strip()
            result["error"] = (
                f"failed to write {_UNIT_PATH} (sudo exit {cp.returncode})"
                + (f": {hint}" if hint else "")
                + ("  — passwordless sudo unavailable; re-run from an "
                   "interactive shell or install the unit by hand."
                   if not interactive else "")
            )
            return result
        cp = _run_sudo(["chmod", "0644", str(_UNIT_PATH)], interactive=interactive)
        # chmod failure is non-fatal (tee already created it 0644-ish);
        # don't abort the install over it.
        cp = _run_sudo(["systemctl", "daemon-reload"], interactive=interactive)
        if cp.returncode != 0:
            result["error"] = f"systemctl daemon-reload failed: {(cp.stderr or '').strip()}"
            return result
        if enable:
            cp = _run_sudo(["systemctl", "enable", _SERVICE_NAME], interactive=interactive)
            result["enabled"] = cp.returncode == 0
            if cp.returncode != 0:
                result["error"] = f"systemctl enable failed: {(cp.stderr or '').strip()}"
                return result
        if start:
            # `restart` starts a stopped unit and bounces a running one,
            # so it's correct whether or not the gateway was already up.
            cp = _run_sudo(["systemctl", "restart", _SERVICE_NAME], interactive=interactive)
            if cp.returncode != 0:
                result["error"] = f"systemctl restart failed: {(cp.stderr or '').strip()}"
                return result
            if not _wait_for_listener(url, timeout=20.0):
                result["error"] = (
                    f"{_SERVICE_NAME} started but the listener at {url} did not "
                    f"come up within 20s — check `journalctl -u {_SERVICE_NAME}`."
                )
                return result
            result["started"] = True
    except subprocess.SubprocessError as e:
        result["error"] = f"sudo/systemctl invocation failed: {e}"
        return result
    result["ok"] = True
    return result


# ---- subcommands -----------------------------------------------------


def cmd_start(args: argparse.Namespace) -> int:  # noqa: ARG001
    """Daemonize ``rtxclaw gateway-serve`` and return once the listener
    is bound. Idempotent: a no-op when an existing gateway is alive.

    Port-conflict guard: if the configured port is already held by a
    process the CLI doesn't track (e.g. one started by systemd, or a
    leftover orphan from an earlier broken restart), refuse to spawn
    another one. Without this check the new process can't bind, exits
    silently, and the operator's pidfile points at a dead pid while
    the orphan keeps serving stale config. Repeated restarts then
    accumulate one orphan per call — the bug that left 10 dead
    ``rtxclaw_agent gateway-serve`` processes around on 2026-05-10.

    The actual work lives in :func:`start_gateway_background` so the
    setup wizard can share it; this wrapper just prints + maps the
    result dict to an exit code.
    """
    result = start_gateway_background()
    if result["already_running"]:
        sys.stdout.write(f"gateway already running (pid={result['pid']})\n")
        return 0
    if not result["ok"]:
        sys.stderr.write(f"refusing to start: {result['error']}\n")
        return 1
    sys.stdout.write(f"gateway started (pid={result['pid']}) at {result['url']}\n")
    return 0


def cmd_stop(args: argparse.Namespace) -> int:  # noqa: ARG001
    """SIGTERM the gateway. The signal handler stops every per-agent
    heartbeat scheduler and drains the shared HTTP listener.

    Port-holder fallback: if the pidfile is missing/stale but the
    configured port is still occupied by a different pid (e.g. a
    leftover orphan from a broken restart), SIGTERM that pid too so
    the next ``cmd_start`` can actually bind. Without this fallback,
    ``cmd_stop`` reports "not running" while the orphan keeps serving
    — the user sees their config edits silently ignored.
    """
    running, pid = _running()
    gw = _gateway_config()
    if not running:
        # Pidfile says nothing's running, but the port might still be
        # held by an orphan. Reap it before reporting "not running" so
        # the next start has a clean port.
        holder = _port_holder(gw["host"], int(gw["port"]))
        if holder and holder > 0:
            sys.stdout.write(
                f"gateway pidfile clean but port {gw['port']} held by "
                f"orphan pid={holder}; reaping\n"
            )
            try:
                os.kill(holder, signal.SIGTERM)
            except ProcessLookupError:
                return 0
            deadline = time.monotonic() + 10.0
            while time.monotonic() < deadline:
                if not _is_alive(holder):
                    sys.stdout.write(f"gateway stopped (pid={holder})\n")
                    return 0
                time.sleep(0.2)
            sys.stderr.write(
                f"orphan pid={holder} did not exit within 10s; "
                f"sending SIGKILL\n"
            )
            try:
                os.kill(holder, signal.SIGKILL)
            except ProcessLookupError:
                pass
            return 1
        if holder == -1:
            sys.stderr.write(
                f"port {gw['port']} held by a different user — cannot "
                f"reap. Use ``sudo systemctl stop rtxclaw-gateway``.\n"
            )
            return 1
        sys.stdout.write("gateway is not running\n")
        return 0
    try:
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        return 0
    # Wait for the pidfile to disappear (gateway unlinks it on clean exit).
    deadline = time.monotonic() + 15.0
    while time.monotonic() < deadline:
        if not _is_alive(pid):
            sys.stdout.write(f"gateway stopped (pid={pid})\n")
            return 0
        time.sleep(0.2)
    sys.stderr.write(
        f"gateway pid={pid} did not exit within 15s; sending SIGKILL\n"
    )
    try:
        os.kill(pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    return 1


def cmd_restart(args: argparse.Namespace) -> int:
    rc = cmd_stop(args)
    if rc not in (0, 1):
        return rc
    return cmd_start(args)


def cmd_status(args: argparse.Namespace) -> int:  # noqa: ARG001
    """Print pid + agent / child summary by hitting the gateway's
    ``GET /`` index route."""
    running, pid = _running()
    gw = _gateway_config()
    url = f"http://{gw['host']}:{gw['port']}"
    if not running:
        sys.stdout.write(f"gateway: not running (configured: {url})\n")
        return 1
    sys.stdout.write(f"gateway: running (pid={pid}) at {url}\n")
    try:
        r = httpx.get(f"{url}/", timeout=2.0)
        if r.status_code == 200:
            data = r.json()
            agents = data.get("agents") or []
            live = data.get("live_children") or []
            sys.stdout.write(f"  agents:        {', '.join(agents) or '(none)'}\n")
            sys.stdout.write(f"  live children: {', '.join(live) or '(none)'}\n")
            sys.stdout.write(
                f"  max children:  {data.get('max_children')}  "
                f"idle timeout: {data.get('idle_timeout_s')}s\n"
            )
        else:
            sys.stdout.write(f"  index route returned HTTP {r.status_code}\n")
    except Exception as e:  # noqa: BLE001
        sys.stdout.write(f"  index route unreachable: {e}\n")
    return 0


def cmd_serve(args: argparse.Namespace) -> int:  # noqa: ARG001
    """Run the gateway in the foreground (no daemonize)."""
    from .gateway import serve_gateway_main
    return serve_gateway_main()


def cmd_logs(args: argparse.Namespace) -> int:  # noqa: ARG001
    """``tail -f`` the gateway log."""
    log_path = _gateway_logfile()
    if not log_path.is_file():
        sys.stderr.write(f"no gateway log at {log_path}\n")
        return 1
    try:
        os.execvp("tail", ["tail", "-f", str(log_path)])
    except FileNotFoundError:
        sys.stderr.write("`tail` not found on PATH\n")
        return 1


def cmd_install_service(args: argparse.Namespace) -> int:
    """Install + enable + start the ``rtxclaw-gateway`` systemd service.

    Generates a unit tailored to this install and writes it under
    ``/etc/systemd/system`` via sudo (you may be prompted for your
    password). After this the gateway starts on boot and the bare
    ``rtxclaw`` command just works — no manual ``systemctl`` step.

    The setup wizard offers this automatically; this subcommand is the
    same path for operators who skipped it then or want to re-apply the
    unit after an upgrade.
    """
    if not systemd_available():
        sys.stderr.write(
            "systemd is not available on this host — nothing to install.\n"
            "run the gateway directly instead: `rtxclaw gateway start`.\n"
        )
        return 1
    enable = not getattr(args, "no_enable", False)
    start = not getattr(args, "no_start", False)
    interactive = sys.stdin.isatty()
    sys.stderr.write(
        f"installing {_SERVICE_NAME} → {_UNIT_PATH}"
        + (" (you may be prompted for your sudo password)\n"
           if interactive else "\n")
    )
    result = install_systemd_service(
        enable=enable, start=start, interactive=interactive,
    )
    if not result["ok"]:
        sys.stderr.write(f"service install failed: {result['error']}\n")
        return 1
    bits = [f"installed {_SERVICE_NAME}"]
    if result["enabled"]:
        bits.append("enabled (starts on boot)")
    if result["started"]:
        bits.append(f"started → {result['url']}")
    sys.stdout.write("✓ " + ", ".join(bits) + "\n")
    return 0


# ---- argparse wiring -------------------------------------------------


def add_subparser(sub: argparse._SubParsersAction) -> None:
    """Wire ``rtxclaw gateway <op>`` into the top-level parser."""
    p = sub.add_parser(
        "gateway",
        help="Single-process agent gateway: hosts every agent as a child subprocess",
    )
    inner = p.add_subparsers(dest="gw_op")

    p_start = inner.add_parser("start", help="Daemonize the gateway")
    p_start.set_defaults(_gw_dispatch=cmd_start)

    p_stop = inner.add_parser("stop", help="SIGTERM the gateway (cascades to children)")
    p_stop.set_defaults(_gw_dispatch=cmd_stop)

    p_restart = inner.add_parser("restart", help="Stop + start the gateway")
    p_restart.set_defaults(_gw_dispatch=cmd_restart)

    p_status = inner.add_parser("status", help="Pid/uptime + agent/child summary")
    p_status.set_defaults(_gw_dispatch=cmd_status)

    p_serve = inner.add_parser("serve", help="Foreground run (used by start)")
    p_serve.set_defaults(_gw_dispatch=cmd_serve)

    p_logs = inner.add_parser("logs", help="tail -f gateway.log")
    p_logs.set_defaults(_gw_dispatch=cmd_logs)

    p_install = inner.add_parser(
        "install-service",
        help="Install + enable + start the rtxclaw-gateway systemd service (uses sudo)",
    )
    p_install.add_argument(
        "--no-enable", action="store_true",
        help="Install + start but don't enable the unit on boot",
    )
    p_install.add_argument(
        "--no-start", action="store_true",
        help="Install + enable but don't start the gateway now",
    )
    p_install.set_defaults(_gw_dispatch=cmd_install_service)


def dispatch(args: argparse.Namespace) -> int:
    """Run the chosen ``rtxclaw gateway <op>`` handler."""
    handler = getattr(args, "_gw_dispatch", None)
    if handler is None:
        sys.stderr.write(
            "usage: rtxclaw gateway "
            "<start|stop|restart|status|serve|logs|install-service>\n"
        )
        return 2
    return int(handler(args))


__all__ = [
    "add_subparser",
    "dispatch",
    "cmd_start",
    "cmd_stop",
    "cmd_restart",
    "cmd_status",
    "cmd_serve",
    "cmd_logs",
    "cmd_install_service",
    "start_gateway_background",
    "systemd_available",
    "render_gateway_unit",
    "install_systemd_service",
]
