"""ACP v2 backend bridge — adapts rtxclaw_core to ``AgentBackend``.

This module satisfies the :class:`rtxclaw_acp.server.AgentBackend`
Protocol for local-LLM agents. The multi-round turn loop runs in
:class:`rtxclaw_core.agents.local_llm.LocalLLMEngine`; what
:class:`CoreBackend` owns is:

* **Session lifecycle** — ``new_session`` / ``load_session`` /
  ``list_sessions`` / ``close_session`` / ``inject_user_message``,
  delegating to :class:`Session` + the on-disk JSON store.
* **Mode / config plumbing** — ``set_mode`` / ``set_config_option``
  forward into the live :class:`LocalLLMEngine` so per-session
  state on the engine (``_mode_overrides``, ``_promoted_tools``,
  ``cfg.reasoning_visibility`` / ``cfg.temperature``) takes effect
  on the next round.
* **Cancel routing** — ``cancel(sid)`` resolves the live ``turn_id``
  via ``_new_backend_active_turns`` and calls
  :meth:`Engine.abort(turn_id)`. Two presses inside
  ``_HARD_KILL_WINDOW_S`` escalate to SIGKILL via the engine's
  ``TurnState.stop(force=True)`` path.
* **Outbound channel binding** — ``bind_session_server`` /
  ``unbind_session_server`` / ``_outbound_for`` so
  ``session/request_permission`` and ``session/ask_user`` reach
  the connection that actually owns the session (the gateway
  shares one CoreBackend across many HTTP/WS connections).
* **Prompt** — ``prompt(sid, mid, blocks)`` is a 4-line proxy that
  resolves the session, allocates a turn id, and yields the
  :class:`AgentTurnEvent` → ACP sessionUpdate translation of
  :meth:`Agent.run_turn`. There is no second prompt code path.

Module-level helpers (``_default_run_tool``, ``_default_spawn_worker``,
``_build_worker_request``, ``_build_parallel_groups``,
``_ask_user_outbound``, etc.) are
the reusable building blocks the engine and the AcpServer call into
on the live path.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import os
import sys
import time as _time
from pathlib import Path
from typing import Any, AsyncIterator, Awaitable, Callable, Mapping, Optional, Sequence

from rtxclaw_core.agent import (
    AgentConfig,
    find_model_with_capability,
    has_capability,
)
from rtxclaw_core.session import Session
from rtxclaw_core.models import for_name, sampling_to_request_fields
from rtxclaw_core.tools import (
    BUILTIN_TOOLS,
    Criticality,
    PermissionEvaluator,
    Tool,
    ToolKind,
    ToolRegistry,
    discovered_mcp_tools_sync,
)
from rtxclaw_core.turn_runtime import (
    TurnState,
    _compose_system_prompt,
    _new_turn_id,
    _now,
)


_LOG = __import__("logging").getLogger("rtxclaw-agent.bridge")


# --- types ---------------------------------------------------------------

# Async iterator of worker JSONL events. Module-level helpers
# (``_default_spawn_worker``, ``_subprocess_event_stream``) produce
# these; :class:`rtxclaw_core.agents.local_llm.LocalLLMEngine` consumes
# them.
WorkerEventStream = AsyncIterator[Mapping[str, Any]]


# --- helpers -------------------------------------------------------------


def _content_block_to_text(block: Mapping[str, Any]) -> str:
    """Pull the textual payload from an ACP ContentBlock.

    The dispatcher has already rejected unsupported types (this agent
    advertises text + resource_link only). ``resource_link`` blocks
    have no inline text, so we collapse them to their ``uri`` — the
    model can fetch them via tools later.
    """
    t = block.get("type")
    if t == "text":
        return str(block.get("text") or "")
    if t == "resource_link":
        # Best-effort plain-text rendering; the wire boundary already
        # validated structure.
        uri = str(block.get("uri") or "")
        name = str(block.get("name") or uri)
        return f"[resource: {name}]({uri})" if uri else name
    return ""


def _flatten_prompt(blocks: list[Mapping[str, Any]]) -> str:
    """Join ContentBlocks into a single user-message string."""
    return "".join(_content_block_to_text(b) for b in blocks)


def _blocks_to_user_content(
    blocks: list[Mapping[str, Any]],
) -> Any:
    """Translate ACP ContentBlock[] into the upstream worker's user-content.

    When the prompt is text-only (the common case), returns a single
    string — keeps the worker request small and matches the
    string-content pattern OpenAI-compat upstreams default to.

    When ANY image block is present, returns the OpenAI multi-part
    list shape:
      ``[{"type": "text", "text": "..."},
         {"type": "image_url",
          "image_url": {"url": "data:<mime>;base64,<b64>"}}]``

    vLLM, openrouter, and every OpenAI-compat vision-capable upstream
    accept this shape natively. The vision model decides whether to
    look at the image; non-vision models will ignore the image_url
    parts.
    """
    has_image = any(
        isinstance(b, Mapping) and b.get("type") == "image" for b in blocks
    )
    if not has_image:
        return _flatten_prompt(blocks)
    parts: list[dict[str, Any]] = []
    text_buf: list[str] = []

    def flush_text() -> None:
        if text_buf:
            joined = "".join(text_buf)
            if joined:
                parts.append({"type": "text", "text": joined})
            text_buf.clear()

    for blk in blocks:
        if not isinstance(blk, Mapping):
            continue
        t = blk.get("type")
        if t == "image":
            flush_text()
            data = str(blk.get("data") or "")
            mime = str(blk.get("mimeType") or "image/jpeg")
            if not mime.startswith("image/"):
                mime = "image/jpeg"
            if data:
                parts.append({
                    "type": "image_url",
                    "image_url": {"url": f"data:{mime};base64,{data}"},
                })
        elif t == "text":
            text_buf.append(str(blk.get("text") or ""))
        elif t == "resource_link":
            uri = str(blk.get("uri") or "")
            name = str(blk.get("name") or uri)
            text_buf.append(f"[resource: {name}]({uri})" if uri else name)
    flush_text()
    return parts


# --- worker IO -----------------------------------------------------------


async def _subprocess_event_stream(
    proc: asyncio.subprocess.Process,
) -> WorkerEventStream:
    """Yield JSONL events parsed from ``proc.stdout`` line by line.

    Async generator so the bridge can interleave cancel-checks
    between events. EOF on stdout terminates the generator cleanly;
    the proc is awaited by the caller.
    """
    if proc.stdout is None:
        raise RuntimeError("worker subprocess stdout pipe is None")
    while True:
        line = await proc.stdout.readline()
        if not line:
            return
        try:
            yield json.loads(line.decode("utf-8"))
        except json.JSONDecodeError:
            # Defensive: skip a corrupt line rather than fail the turn.
            continue


# --- vision-capability bridge --------------------------------------------
#
# Telegram (and the TUI) let a user attach an image to ANY session,
# regardless of which model is selected. The bridge translates that
# image into the OpenAI ``image_url`` multi-part shape — which a
# text-only upstream (e.g. ``deepseek-v4-flash``) rejects outright:
#
#   HTTP 400: unknown variant `image_url`, expected `text`
#
# Worse, the offending message stays in the session transcript, so the
# 400 repeats on every subsequent turn until the session is dropped.
#
# The fix: before spawning the worker, if the selected model is NOT
# vision-capable (its ``cfg.models[]`` row lacks the ``vision``
# capability), route the image through the first configured
# vision-capable model for a one-shot transcription, then splice that
# text back in place of the ``image_url`` part. The selected model
# then sees a faithful text description and the turn runs normally.
# When no vision model is configured (or the transcription fails) the
# image is replaced with a short placeholder so the turn still runs
# instead of crashing.

_IMAGE_TRANSCRIBE_PROMPT = (
    "You are an image-to-text bridge. The image(s) below were sent to a "
    "text-only model that cannot see them. Transcribe everything visible "
    "in faithful, literal detail: all text verbatim, UI layout, charts "
    "and their numbers, code, error messages, diagrams, people and "
    "objects. Do not answer questions about the image or add commentary "
    "— only describe what is present so the text model can reason about it."
)

# Bounded cache of vision transcriptions keyed by (model id + image
# URLs) hash. A session whose transcript already carries an image
# replays it every turn; without this we'd re-bill the vision model
# each round.
_TRANSCRIPTION_CACHE: dict[str, str] = {}
_TRANSCRIPTION_CACHE_MAX = 64


def _message_image_parts(content: Any) -> list[Mapping[str, Any]]:
    """Return the ``image_url`` parts in a chat message's content.

    Empty for the common case — a plain-string content or a multi-part
    list with no images.
    """
    if not isinstance(content, list):
        return []
    return [
        p for p in content
        if isinstance(p, Mapping) and p.get("type") == "image_url"
    ]


async def _run_oneshot_worker(
    request: dict[str, Any], *, timeout_s: float = 90.0,
) -> str:
    """Spawn a one-shot ``rtxclaw_agent.worker`` and return its content.

    Used for out-of-band model calls (image transcription) that are
    NOT the user's turn — no tools, no streaming to the client, just
    the assembled ``content`` text. Raises :class:`RuntimeError` on a
    worker error, timeout, or empty output.
    """
    package_parent = str(Path(__file__).resolve().parent.parent)
    env = dict(os.environ)
    existing = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = package_parent + (os.pathsep + existing if existing else "")
    env["PYTHONUNBUFFERED"] = "1"
    proc = await asyncio.create_subprocess_exec(
        sys.executable, "-m", "rtxclaw_agent.worker",
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        env=env,
        limit=16 * 1024 * 1024,
    )
    if proc.stdin is None:
        raise RuntimeError("worker stdin pipe is None")
    proc.stdin.write(json.dumps(request).encode("utf-8"))
    await proc.stdin.drain()
    proc.stdin.close()

    content: list[str] = []
    err: Optional[str] = None

    async def _drain() -> None:
        nonlocal err
        # The worker exits after emitting ``done``/``aborted``, so the
        # event stream ends at stdout EOF — no explicit break needed.
        async for ev in _subprocess_event_stream(proc):
            kind = ev.get("kind")
            if kind == "content":
                content.append(str(ev.get("text") or ""))
            elif kind == "error":
                err = str(ev.get("message") or "worker error")

    try:
        await asyncio.wait_for(_drain(), timeout=timeout_s)
    except asyncio.TimeoutError:
        try:
            proc.kill()
        except ProcessLookupError:
            pass
        raise RuntimeError(f"transcription worker timed out after {timeout_s:.0f}s")
    finally:
        try:
            await proc.wait()
        except Exception:  # noqa: BLE001
            pass

    if err:
        raise RuntimeError(err)
    text = "".join(content).strip()
    if not text:
        raise RuntimeError("vision model returned an empty transcription")
    return text


async def _transcribe_image_parts(
    cfg: AgentConfig,
    vision_row: Mapping[str, Any],
    image_parts: Sequence[Mapping[str, Any]],
    caption: str,
) -> str:
    """Transcribe ``image_parts`` via the configured vision model.

    Results are cached on the (model id + image URL) hash so a
    replayed transcript image is only billed once per process.
    """
    endpoint = str(vision_row.get("baseUrl") or "").rstrip("/")
    model_id = str(vision_row.get("id") or "").strip()
    if not endpoint or not model_id:
        raise RuntimeError(
            f"vision model row missing baseUrl/id: {dict(vision_row)!r}"
        )

    urls = "\0".join(
        str((p.get("image_url") or {}).get("url") or "") for p in image_parts
    )
    key = hashlib.sha256(f"{model_id}\0{urls}".encode("utf-8")).hexdigest()
    cached = _TRANSCRIPTION_CACHE.get(key)
    if cached is not None:
        return cached

    prompt = _IMAGE_TRANSCRIBE_PROMPT
    if caption:
        prompt += f"\n\nThe user's accompanying message: {caption}"
    user_parts: list[dict[str, Any]] = [{"type": "text", "text": prompt}]
    user_parts.extend(dict(p) for p in image_parts)

    try:
        headers = cfg.upstream_headers(endpoint)
    except Exception:  # noqa: BLE001
        headers = {}

    request: dict[str, Any] = {
        "endpoint": endpoint,
        "model": model_id,
        "messages": [{"role": "user", "content": user_parts}],
        "temperature": 0.2,
        "enable_thinking": False,
    }
    if headers:
        request["headers"] = dict(headers)
    backend_kind = str(vision_row.get("backend") or "")
    if backend_kind:
        request["backend"] = backend_kind

    text = await _run_oneshot_worker(request)

    if len(_TRANSCRIPTION_CACHE) >= _TRANSCRIPTION_CACHE_MAX:
        _TRANSCRIPTION_CACHE.pop(next(iter(_TRANSCRIPTION_CACHE)), None)
    _TRANSCRIPTION_CACHE[key] = text
    _LOG.info(
        "transcribed %d image part(s) via %s (%d chars)",
        len(image_parts), vision_row.get("alias") or model_id, len(text),
    )
    return text


async def _resolve_images_for_model(
    backend: "CoreBackend",
    sess: Session,
    messages: list[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    """Make ``image_url`` content safe for the session's selected model.

    * Selected model is vision-capable → images pass through untouched
      (the upstream reads them natively).
    * Selected model is text-only → every ``image_url`` part is
      replaced with a transcription from the first vision-capable model
      in ``cfg.models[]``.
    * No vision model configured, or the transcription fails → the
      image is replaced with a short placeholder.

    Never raises: a failure here must not be worse than the text-only
    400 it exists to prevent.
    """
    msgs: list[dict[str, Any]] = [
        dict(m) if isinstance(m, Mapping) else m for m in messages
    ]
    img_indices = [
        i for i, m in enumerate(msgs)
        if isinstance(m, Mapping) and _message_image_parts(m.get("content"))
    ]
    if not img_indices:
        return msgs

    cfg = backend.cfg
    try:
        current_row = cfg.model_row_for_endpoint(sess.endpoint or "")
    except Exception:  # noqa: BLE001
        current_row = {}
    if has_capability(current_row, "vision"):
        # Selected model reads images natively — leave them alone.
        return msgs

    try:
        vision_row = find_model_with_capability(cfg, "vision")
    except Exception:  # noqa: BLE001
        vision_row = None

    for i in img_indices:
        m = msgs[i]
        content = m.get("content")
        image_parts = _message_image_parts(content)
        # Every text part on this message — the user's caption plus any
        # ``[Turn N]`` marker the message builder prepended.
        caption = "".join(
            str(p.get("text") or "")
            for p in content
            if isinstance(p, Mapping) and p.get("type") == "text"
        ).strip()

        if vision_row is None:
            _LOG.warning(
                "prompt carries %d image part(s) but no vision-capable "
                "model is configured (selected model=%s); replacing with "
                "a placeholder so the turn still runs",
                len(image_parts), sess.model,
            )
            inserted_text = (
                f"\n\n[{len(image_parts)} image(s) attached — no "
                "vision-capable model is configured to read them. Add a "
                'model with "capabilities": ["vision"] to '
                "~/.rtxclaw/config.json, or ask the user to describe it.]"
            )
        else:
            label = str(
                vision_row.get("alias") or vision_row.get("id") or "vision model"
            )
            try:
                transcription = await _transcribe_image_parts(
                    cfg, vision_row, image_parts, caption,
                )
                inserted_text = (
                    f"\n\n[Transcription of {len(image_parts)} attached "
                    f"image(s), read by {label} — the selected model is "
                    f"text-only:]\n{transcription}"
                )
            except Exception as exc:  # noqa: BLE001
                _LOG.warning(
                    "vision transcription via %s failed: %s; replacing "
                    "image with placeholder", label, exc,
                )
                inserted_text = (
                    f"\n\n[{len(image_parts)} image(s) attached but could "
                    f"not be transcribed by {label}: {exc}]"
                )

        # Rebuild content: keep text parts in order, splice the
        # transcription where the first image was, drop the image_url
        # parts (the selected model can't read them).
        new_parts: list[Any] = []
        inserted = False
        for p in content:
            if isinstance(p, Mapping) and p.get("type") == "image_url":
                if not inserted:
                    new_parts.append({"type": "text", "text": inserted_text})
                    inserted = True
                continue
            new_parts.append(p)
        if not inserted:
            new_parts.append({"type": "text", "text": inserted_text})

        # Collapse to a plain string when nothing but text remains —
        # matches the string-content convention text-only upstreams want.
        if all(
            isinstance(p, Mapping) and p.get("type") == "text"
            for p in new_parts
        ):
            m["content"] = "".join(
                str(p.get("text") or "") for p in new_parts
            )
        else:
            m["content"] = new_parts
        msgs[i] = m

    return msgs


def _build_worker_request(
    backend: "CoreBackend",
    sess: Session,
    messages: list[Mapping[str, Any]],
    *,
    include_tools: bool = True,
    allowed_tool_names: Optional[set[str]] = None,
) -> dict[str, Any]:
    """Assemble a single worker request payload.

    Shape: endpoint, model, messages, model-aware sampling, tools,
    tool_choice. Tool schemas come from :data:`BUILTIN_TOOLS` so the
    worker forwards the OpenAI-shaped list to the upstream and the
    model can emit ``tool_calls``.

    ``allowed_tool_names`` (when given) filters the tools[] payload to
    just those names — the engine passes ``core_tools | promoted`` so
    deferred tool schemas don't ride every round (saves ~30 KB / round
    on a small-model context). When None (legacy callers), every tool
    in the registry ships.
    """
    mdl = for_name(sess.model)
    if os.environ.get("RTXCLAW_DISABLE_MODEL_SAMPLING", "0") in ("1", "true", "True"):
        request_fields: dict[str, Any] = {}
        template_kwargs: dict[str, Any] = {}
    else:
        mode = str(getattr(sess, "system_mode", "") or getattr(sess, "mode", "") or "auto")
        profile = getattr(mdl, mode, mdl.auto)
        request_fields, template_kwargs = sampling_to_request_fields(profile)
    request: dict[str, Any] = {
        "endpoint": sess.endpoint,
        "model": sess.model,
        "messages": list(messages),
    }
    request.update(request_fields)
    request["temperature"] = backend.cfg.temperature
    extra: dict[str, Any] = {}
    if template_kwargs:
        extra["chat_template_kwargs"] = template_kwargs
    extra.update(mdl.extra_sampling)
    if extra:
        request["extra"] = extra
    # Resolve per-row auth + custom headers (OpenRouter Bearer token,
    # X-Title, etc.) from the AgentConfig and ship them on the wire
    # request so the worker subprocess attaches them to the upstream
    # POST. Without this the worker hits the upstream with NO
    # Authorization header — fine for local vLLM rows, but the moment
    # the operator switches to ``kimi`` (OpenRouter) every request
    # comes back HTTP 401. Empty dict for unconfigured rows is safe.
    try:
        upstream_hdrs = backend.cfg.upstream_headers(sess.endpoint or "")
    except Exception:  # noqa: BLE001
        upstream_hdrs = {}
    if upstream_hdrs:
        request["headers"] = dict(upstream_hdrs)
    if include_tools:
        # Sync cache read — the async sites in `prompt()` /
        # `_run_direct_tool_call` warm the discovery cache before this
        # function (called from `_default_spawn_worker`) runs.
        registry = ToolRegistry(BUILTIN_TOOLS + discovered_mcp_tools_sync())
        if allowed_tool_names is not None:
            # Always allow core tools — promoted is purely additive.
            allowed = set(allowed_tool_names) | {
                t.name for t in registry.core_tools()
            }
            request["tools"] = registry.filtered_schemas(allowed)
        else:
            request["tools"] = registry.openai_schemas()
        request["tool_choice"] = "auto"
    return request


async def _default_spawn_worker(
    backend: "CoreBackend",
    session_id: str,
    prompt_blocks: list[Mapping[str, Any]],
    turn_id: str,
    messages: Optional[list[Mapping[str, Any]]] = None,
    *,
    allowed_tool_names: Optional[set[str]] = None,
) -> tuple[TurnState, WorkerEventStream]:
    """Spawn a real ``rtxclaw_agent.worker`` subprocess.

    The request includes the assembled message list plus the OpenAI
    tool schemas (from :data:`BUILTIN_TOOLS`) and ``tool_choice="auto"``
    so the model can emit ``tool_calls`` events the bridge dispatches.

    On the first round (``messages is None``) the message list is
    derived from the session's persisted history + the new prompt.
    On follow-up rounds the caller passes the already-augmented
    list (with prior tool_calls / role=tool entries appended).
    """
    sess = backend._session_for(session_id)
    if sess is None:
        raise RuntimeError(f"unknown session: {session_id!r}")

    if messages is None:
        user_content = _blocks_to_user_content(prompt_blocks)
        msgs: list[dict[str, Any]] = []
        if sess.system_prompt:
            msgs.append({"role": "system", "content": sess.system_prompt})
        for prior in sess.turns:
            u = prior.get("user")
            if u:
                msgs.append({"role": "user", "content": u})
            c = prior.get("content")
            if c:
                msgs.append({"role": "assistant", "content": c})
        msgs.append({"role": "user", "content": user_content})
    else:
        msgs = list(messages)

    # Make any image content safe for the selected model — transcribe
    # via a vision model when the selected one is text-only, so a
    # ``deepseek-v4-flash``-style upstream doesn't 400 on ``image_url``.
    msgs = await _resolve_images_for_model(backend, sess, msgs)

    request = _build_worker_request(
        backend, sess, msgs, allowed_tool_names=allowed_tool_names,
    )

    package_parent = str(Path(__file__).resolve().parent.parent)
    env = dict(os.environ)
    existing = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = package_parent + (os.pathsep + existing if existing else "")
    env["PYTHONUNBUFFERED"] = "1"
    proc = await asyncio.create_subprocess_exec(
        sys.executable, "-m", "rtxclaw_agent.worker",
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        env=env,
        limit=16 * 1024 * 1024,
    )
    if proc.stdin is None:
        raise RuntimeError("worker stdin pipe is None")
    proc.stdin.write(json.dumps(request).encode("utf-8"))
    await proc.stdin.drain()
    proc.stdin.close()
    turn = TurnState(turn_id, session_hash=session_id, proc=proc)
    return turn, _subprocess_event_stream(proc)


# --- parallel-dispatch eligibility --------------------------------------
#
# The dispatch loop runs read-only / state-file-distinct calls
# concurrently (one ``asyncio.create_subprocess_exec`` runner per call,
# multiplexed through one shared event queue). Two gates decide whether
# a call can join a parallel batch:
#
#   1. ``_call_is_parallel_eligible`` — semantic safety. Read-only
#      criticality (model claim AND heuristic agree, per the
#      evaluator's ``_effective_criticality``) means siblings can't
#      step on each other's state. ``NETWORK``-kind tools (delegates,
#      ``acp_call``, ``web_fetch``, …) are I/O-bound and isolate state
#      via per-call session files — also eligible. Bridge-state
#      mutators (``compact_context``, ``tool_search``) are permanently
#      excluded: they mutate the running ``messages`` list / promoted-
#      tool set and would race against any sibling that read either.
#
#   2. ``_state_file_key`` — sequential per-batch uniqueness for
#      delegate-style tools that share a persisted ``<sid>.delegate_*.json``.
#      Two ``delegate_claude`` calls in one round both read+write the
#      same state file, so they collide; the batcher splits them into
#      separate groups (sequentially executed). Different ``name=``
#      arguments to ``delegate_agent`` / ``acp_call`` get distinct keys
#      because their state files are namespaced by target name.

_PARALLEL_UNSAFE_TOOLS: frozenset = frozenset({"compact_context", "ToolSearch"})


def _state_file_key(call: Mapping[str, Any]) -> Optional[str]:
    """Per-batch collision key for delegate-style tools. ``None`` means
    "no shared state file" (the call doesn't conflict with anything).
    """
    name = call.get("name")
    if name in ("delegate_claude", "delegate_codex", "delegate_gemini"):
        # Single state file per session — N concurrent calls would race
        # on ``<sid>.delegate_<kind>.json``.
        return str(name)
    if name in ("delegate_agent", "acp_call"):
        target = ((call.get("arguments") or {}).get("name") or "")
        target = target.strip() if isinstance(target, str) else ""
        return f"{name}:{target}" if target else str(name)
    return None


def _call_is_parallel_eligible(
    tool: Tool,
    call: Mapping[str, Any],
    evaluator: PermissionEvaluator,
) -> bool:
    """Eligibility for concurrent dispatch in a multi-call round."""
    if call.get("name") in _PARALLEL_UNSAFE_TOOLS:
        return False
    args = dict(call.get("arguments") or {})
    crit = evaluator._effective_criticality(tool, args)
    if crit == Criticality.READ_ONLY:
        return True
    # NETWORK tools (delegate_*, acp_call, web_fetch, …) are I/O-bound
    # and don't share local state. Per-batch state-file uniqueness is
    # checked separately in ``_build_parallel_groups``.
    if tool.kind == ToolKind.NETWORK:
        return True
    return False


def _build_parallel_groups(
    entries: Sequence[Mapping[str, Any]],
) -> list[list[int]]:
    """Walk ``entries`` and return groups of consecutive indices safe
    to dispatch together.

    Each entry must carry ``parallel_safe: bool`` and ``state_key: str|None``.
    A group is either a singleton (any non-eligible call) or a maximal
    run of consecutive eligible calls whose ``state_key``s are pairwise
    distinct within the run. Order is preserved across groups so the
    OpenAI-shape tool message list still tracks the assistant's
    ``tool_calls`` order.
    """
    groups: list[list[int]] = []
    i = 0
    n = len(entries)
    while i < n:
        if not entries[i].get("parallel_safe", False):
            groups.append([i])
            i += 1
            continue
        batch = [i]
        keys: set[str] = set()
        sk = entries[i].get("state_key")
        if sk is not None:
            keys.add(sk)
        j = i + 1
        while j < n:
            nxt = entries[j]
            if not nxt.get("parallel_safe", False):
                break
            nk = nxt.get("state_key")
            if nk is not None and nk in keys:
                break
            batch.append(j)
            if nk is not None:
                keys.add(nk)
            j += 1
        groups.append(batch)
        i = j
    return groups


# --- AskUserQuestion outbound -------------------------------------------


def _ask_user_auto_answers(questions: list[Any], note: str) -> list[dict[str, Any]]:
    """Synthesize first-option answers for each question.

    Used as a fallback when the connected frontend doesn't implement
    ``session/ask_user`` (e.g. Telegram, OpenAI endpoint), when the
    outbound request errors out, or when ``server_handle`` is None
    (tests / post-shutdown). ``note`` flows back to the model in each
    answer so the tool_result transparently records that no human
    actually picked.
    """
    answers: list[dict[str, Any]] = []
    for q in questions:
        if not isinstance(q, Mapping):
            continue
        opts = q.get("options")
        first_label = ""
        if isinstance(opts, list) and opts:
            first = opts[0]
            if isinstance(first, Mapping):
                first_label = str(first.get("label") or "")
        answers.append(
            {
                "question": str(q.get("question") or ""),
                "selected": [first_label] if first_label else [],
                "notes": note,
            }
        )
    return answers


async def _ask_user_outbound(
    backend: "CoreBackend",
    session_id: str,
    call: Mapping[str, Any],
) -> tuple[bool, str]:
    """Issue ``session/ask_user`` to the client and return ``(ok, content)``.

    The model's ``AskUserQuestion`` tool can't be executed inside the
    sandboxed subprocess runner — it has to round-trip through the
    connected frontend (TUI modal / Telegram / etc.) so a human can
    pick answers. We hijack the normal ``_default_run_tool`` dispatch
    on tool-name match and send the call out over the wire instead.

    Wire shape (request):

    .. code:: json

        {
          "sessionId": "...",
          "callId": "...",
          "questions": [
            {
              "question": "...", "header": "...", "multiSelect": false,
              "options": [
                {"label": "...", "description": "..."},
                ...
              ]
            },
            ...
          ]
        }

    Wire shape (response):

    .. code:: json

        {
          "answers": [
            {"question": "...", "selected": ["<label>", ...], "notes": "..."},
            ...
          ]
        }

    The returned ``content`` string is a stable JSON dump of the answers
    list so the model gets a deterministic tool_result it can parse.

    Robust degradation: frontends that don't implement
    ``session/ask_user`` (Telegram, OpenAI endpoint) return
    methodNotFound on the wire; rather than failing the tool we
    synthesize first-option answers + a transparent ``notes`` string
    so the model never hangs and knows the answer wasn't user-picked.
    """
    args = call.get("arguments") or {}
    questions_raw = args.get("questions") if isinstance(args, Mapping) else None
    if not isinstance(questions_raw, list) or not questions_raw:
        return False, "AskUserQuestion: arguments.questions must be a non-empty list"
    questions: list[Any] = list(questions_raw)

    server_handle = _resolve_outbound_channel(backend, session_id)
    if server_handle is None:
        # No outbound channel (self-contained task / tests / stub
        # server). Synthesize so the model gets a parseable tool_result
        # and can continue.
        synth = _ask_user_auto_answers(
            questions, "(auto-answered: no outbound channel)"
        )
        return True, json.dumps({"answers": synth}, ensure_ascii=False)

    payload: dict[str, Any] = {
        "sessionId": session_id,
        "callId": str(call.get("id") or ""),
        "questions": questions,
    }

    try:
        result = await server_handle.request_outbound("session/ask_user", payload)
    except (ConnectionError, asyncio.CancelledError):
        raise
    except Exception as exc:  # noqa: BLE001
        # Wire-level failure (methodNotFound from a frontend that
        # doesn't implement ask_user, transport error, etc.) — fall
        # back to synthesized first-option answers with a clear note
        # so the model and downstream caller can see the degradation.
        synth = _ask_user_auto_answers(
            questions, f"(auto-answered: outbound failed — {exc})"
        )
        return True, json.dumps({"answers": synth}, ensure_ascii=False)

    if not isinstance(result, Mapping):
        return False, "AskUserQuestion: malformed response (not a mapping)"
    answers = result.get("answers")
    if not isinstance(answers, list):
        return False, "AskUserQuestion: malformed response (answers not a list)"

    return True, json.dumps({"answers": answers}, ensure_ascii=False)


# --- tool runner subprocess ---------------------------------------------


async def _default_run_tool(
    backend: "CoreBackend",
    session_id: str,
    call: Mapping[str, Any],
    turn: TurnState,
    *,
    on_delta: Optional[Callable[[str], Awaitable[None]]] = None,
    on_event: Optional[Callable[[dict], Awaitable[None]]] = None,
) -> tuple[bool, str, bool, bool]:
    """Spawn ``rtxclaw.tool_runner`` for one tool call.

    Each call lives in its own OS process (foundational killability):
    ``turn.proc`` is updated to the runner so the existing
    :meth:`CoreBackend.cancel` SIGTERMs whichever subprocess is active
    AT THIS MOMENT — runner OR worker. The runner's stdout is parsed
    for ``{"type": "delta", "text": ...}`` lines (forwarded via
    ``on_delta`` when provided — Claude's in-band ``🔧 tool_use`` /
    ``↳ tool_result`` markers ride this channel) and a final
    ``{"type": "final", "ok": ..., "content": ..., "truncated": ...}``
    record. Returns ``(ok, content, aborted, truncated)``.

    ``on_event``, when wired, receives one ``{"kind": ...}`` dict per
    ``{"type": "tool_event", ...}`` runner-stdout record — today
    these come from ``delegate_claude`` surfacing its inner
    ``tool_use`` / ``tool_result`` blocks so the bridge can fan them
    out as additional ACP ``tool_call`` / ``tool_call_update``
    notifications and the TUI mounts native widgets for them.

    ``AskUserQuestion`` short-circuits before subprocess spawn: there's
    no runner implementation for it (the call has to round-trip
    through the connected frontend), so we hand it to
    :func:`_ask_user_outbound` and return the wire result directly.
    """
    if call.get("name") == "AskUserQuestion":
        ok, content = await _ask_user_outbound(backend, session_id, call)
        return ok, content, False, False

    package_parent = str(Path(__file__).resolve().parent.parent)
    env = dict(os.environ)
    existing = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = package_parent + (os.pathsep + existing if existing else "")
    env["PYTHONUNBUFFERED"] = "1"
    env["RTXCLAW_SESSION_ID"] = session_id
    env["RTXCLAW_SESSIONS_DIR"] = str(backend.cfg.sessions_dir)
    env["RTXCLAW_AGENT_HOME"] = str(backend.cfg.home)
    env["RTXCLAW_AGENT_NAME"] = backend.cfg.name
    env["RTXCLAW_PERMISSION_MODE"] = (backend.cfg.permission_mode or "auto")
    if backend.cfg.upstream_endpoint:
        env["RTXCLAW_UPSTREAM_ENDPOINT"] = backend.cfg.upstream_endpoint
    if backend.cfg.upstream_model:
        env["RTXCLAW_UPSTREAM_MODEL"] = backend.cfg.upstream_model

    # Fix B: post-force-terminate cap. If the bridge already fired
    # ``LOOP_FORCE_TERMINATE`` on this turn, clamp the EXEC tool's
    # idle + wall budget to 30s before handing args to the runner.
    # In normal operation the bridge's dispatch-level deny gate
    # (fix A) refuses these calls before we get here, so this branch
    # is dead code — but it's a cheap safety net for any future
    # refactor that loosens A or for any code path that bypasses it.
    # See acp_bridge.py: ``post_force_terminate`` near the prompt
    # loop's force-terminate block.
    call_args = dict(call.get("arguments") or {})
    if getattr(turn, "post_force_terminate", False) and call.get("name") == "Bash":
        cap_s = 30.0
        # Translate Claude-style millisecond ``timeout`` (max 600000)
        # consistently with ``run_bash_async`` so a model-supplied
        # value gets compared on the same axis as our cap.
        raw_idle = call_args.get("timeout")
        if raw_idle is not None:
            try:
                v = float(raw_idle)
                if v > 3600:
                    v = v / 1000.0
                call_args["timeout"] = min(v, cap_s)
            except (TypeError, ValueError):
                call_args["timeout"] = cap_s
        else:
            call_args["timeout"] = cap_s
        raw_wall = call_args.get("wall_timeout")
        if raw_wall is not None:
            try:
                call_args["wall_timeout"] = min(float(raw_wall), cap_s)
            except (TypeError, ValueError):
                call_args["wall_timeout"] = cap_s
        else:
            call_args["wall_timeout"] = cap_s
    request = {"tool": call["name"], "args": call_args}
    proc = await asyncio.create_subprocess_exec(
        sys.executable, "-m", "rtxclaw_core.tool_runner",
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        env=env,
        limit=16 * 1024 * 1024,
    )
    if proc.stdin is None:
        raise RuntimeError("tool_runner stdin pipe is None")
    proc.stdin.write(json.dumps(request).encode("utf-8"))
    await proc.stdin.drain()
    proc.stdin.close()
    # Re-point the live TurnState at the runner so ESC kills it
    # instantly (instead of trying to terminate the already-exited
    # worker proc). Also register on the runner_procs dict so parallel
    # batches with multiple in-flight runners all get SIGTERM'd by ESC,
    # not just whichever happened to land in turn.proc last.
    turn.proc = proc
    call_id = str(call.get("id") or "")
    if call_id:
        turn.register_runner(call_id, proc)

    final: Optional[dict] = None
    try:
        if proc.stdout is None:
            raise RuntimeError("tool_runner stdout pipe is None")
        while True:
            line = await proc.stdout.readline()
            if not line:
                break
            try:
                obj = json.loads(line.decode("utf-8", "replace"))
            except json.JSONDecodeError:
                continue
            if obj.get("type") == "delta":
                # Forward Claude/Codex's in-band streaming text +
                # tool-use markers if a callback was provided. Failures
                # in the callback don't kill the runner — log and move
                # on so a flaky frontend can't break the agent.
                if on_delta is not None:
                    text = obj.get("text") or ""
                    if text:
                        try:
                            await on_delta(text)
                        except Exception:  # noqa: BLE001
                            pass
                continue
            if obj.get("type") == "tool_event":
                # Structured inner-tool side-channel from streaming
                # wrappers (today: delegate_claude). The direct-
                # dispatch path uses this to fan out additional ACP
                # tool_call/tool_call_update notifications so the TUI
                # mounts native widgets for Claude's inner calls.
                if on_event is not None:
                    try:
                        await on_event({k: v for k, v in obj.items() if k != "type"})
                    except Exception:  # noqa: BLE001
                        pass
                continue
            if final is None:
                final = obj
    except asyncio.CancelledError:
        try:
            proc.kill()
        except ProcessLookupError:
            pass
        try:
            await proc.wait()
        except Exception:  # noqa: BLE001
            pass
        if call_id:
            turn.unregister_runner(call_id)
        raise

    try:
        await proc.wait()
    except Exception:  # noqa: BLE001
        pass
    if call_id:
        turn.unregister_runner(call_id)

    if final is None:
        head = ""
        if proc.stderr is not None:
            try:
                err_bytes = await proc.stderr.read()
                head_lines = err_bytes.decode("utf-8", "replace").strip().splitlines()
                head = (head_lines or [""])[-1][:200]
            except Exception:  # noqa: BLE001
                pass
        return (
            False,
            f"tool_runner crashed (rc={proc.returncode}): {head or '<no stderr>'}",
            False,
            False,
        )

    content = final.get("content", "")
    ok = bool(final.get("ok", False))
    truncated = bool(final.get("truncated", False))
    aborted = (not ok and content == "aborted")
    return ok, str(content), aborted, truncated


# --- outbound permission request ----------------------------------------


def _resolve_outbound_channel(
    backend: "CoreBackend", session_id: str
) -> Optional[Any]:
    """Resolve the outbound ACP channel (an :class:`AcpServer`) for a
    session.

    Prefers the backend's per-session resolver (``_outbound_for`` —
    routes to the connection that owns the session even when one
    CoreBackend is shared by many HTTP/WS connections); falls back to
    the bare ``server_handle`` attribute for stub backends in tests.
    Returns ``None`` when no usable channel exists.
    """
    resolver = getattr(backend, "_outbound_for", None)
    handle = resolver(session_id) if callable(resolver) else getattr(
        backend, "server_handle", None
    )
    if handle is None or not hasattr(handle, "request_outbound"):
        return None
    return handle



# --- bridge --------------------------------------------------------------


# Two-press hard-kill window (fix D). When the second ``cancel(sid)``
# arrives within this many seconds of the first, escalate the active
# subprocesses' termination from ``SIGTERM`` to ``SIGKILL`` + ``killpg``
# on the process group. The default ``SIGTERM`` flow is enough for any
# cooperative runner — its asyncio signal handler cancels the dispatch
# task which kills child process groups itself — but a wedged python
# interpreter that swallowed SIGTERM (or a C extension not yielding
# the GIL) wouldn't see it, leaving the operator with no second-line
# kill. One second matches the "natural retry latency" of a frustrated
# operator mashing ESC; tune via ``RTXCLAW_HARD_KILL_WINDOW_S``.
try:
    _HARD_KILL_WINDOW_S: float = float(
        os.environ.get("RTXCLAW_HARD_KILL_WINDOW_S", "1.0") or 1.0
    )
except (TypeError, ValueError):
    _HARD_KILL_WINDOW_S = 1.0

def _build_assistant_round_msg(
    *,
    content: str,
    thinking: str,
    tool_calls: list[Mapping[str, Any]],
) -> dict[str, Any]:
    """Build the assistant message that emitted this round's tool_calls.

    The message replays into ``messages`` so the next worker round
    sees the canonical OpenAI-shaped tool-call/tool-result history.

    Reasoning round-trip: when ``thinking`` is non-empty, attach it as
    ``reasoning_content``. DeepSeek (`deepseek-reasoner` /
    `deepseek-v4-flash`) HTTP-400s the tool-result follow-up with
    *"reasoning_content in the thinking mode must be passed back to
    the API"* when this field is missing. OpenAI / vLLM / SGLang
    silently ignore the extra field, so attaching it unconditionally
    is safe.
    """
    msg: dict[str, Any] = {
        "role": "assistant",
        "content": content or None,
        "tool_calls": [
            {
                "id": c["id"],
                "type": "function",
                "function": {
                    "name": c["name"],
                    "arguments": json.dumps(
                        c.get("arguments") or {},
                        ensure_ascii=False,
                    ),
                },
            }
            for c in tool_calls
        ],
    }
    if thinking:
        msg["reasoning_content"] = thinking
    return msg


# Sentinel marker the TUI / Telegram / one-shot CLI prepend on the
# first text block of a session/prompt to opt out of the LLM round
# entirely and dispatch a delegate-class tool directly — bypasses the
# local model so /claude, /codex, and /compact don't depend on a
# small model deciding to emit the right tool.
DIRECT_DELEGATE_PREFIX = "__RTXCLAW_DELEGATE__:"


def _parse_direct_delegate_marker(
    blocks: list[Mapping[str, Any]],
) -> Optional[dict[str, Any]]:
    """If ``blocks`` opens with the direct-dispatch sentinel, parse out
    ``{"tool": str, "arguments": dict}``; otherwise return None.

    Format on the wire (single text block):

        __RTXCLAW_DELEGATE__:<tool_name>:<json-args>

    where ``<json-args>`` is a JSON object passed straight through to
    the tool runner. Any malformed marker (missing tool, bad JSON,
    multi-block prompt) returns None so the caller falls back to the
    regular LLM round — fail-soft, never raise out of a bot path.
    """
    if not blocks:
        return None
    first = blocks[0]
    if not isinstance(first, Mapping) or first.get("type") != "text":
        return None
    text = str(first.get("text") or "")
    if not text.startswith(DIRECT_DELEGATE_PREFIX):
        return None
    rest = text[len(DIRECT_DELEGATE_PREFIX):]
    head, sep, args_text = rest.partition(":")
    tool_name = head.strip()
    if not tool_name:
        return None
    args_obj: dict[str, Any] = {}
    if sep and args_text:
        try:
            parsed = json.loads(args_text)
            if isinstance(parsed, dict):
                args_obj = parsed
        except (json.JSONDecodeError, TypeError):
            return None
    return {"tool": tool_name, "arguments": args_obj}


def _text_tool_content(text: str) -> list[dict[str, Any]]:
    """Wrap a text string as a single ACP-spec ToolCallContent entry.

    Per ``$defs/ToolCallContent`` (canonical schema): tool_call_update
    ``content`` is a discriminated union over
    ``{"type": "content", "content": <ContentBlock>}`` |
    ``{"type": "diff", ...}`` |
    ``{"type": "terminal", ...}`` — the inner ContentBlock is itself a
    union (text/image/audio/resource_link/resource).

    Earlier emission sites in this module passed the raw ContentBlock
    inline (``[{"type": "text", "text": ...}]``) which trips the SDK's
    pydantic validator (``Input should be 'terminal'`` because the
    discriminator picks the wrong branch). Use this helper everywhere
    a tool result is plain text.
    """
    return [{"type": "content", "content": {"type": "text", "text": text}}]


def list_sessions_acp(
    sessions_dir: Path,
    agent_home: Path,
    *,
    max_sessions: int = 20,
) -> dict[str, Any]:
    """Shared ACP-shape ``session/list`` impl, used by both:

    - :meth:`CoreBackend.list_sessions` — the local-LLM agent path
      (e.g., ``main``).
    - :meth:`AgentACPBackend.list_sessions` CLI-engine fallback in
      ``gateway_shim.py`` — the path for ``claude`` / ``codex`` /
      ``gemini`` agents whose engine doesn't carry a ``CoreBackend``.

    Returns the wire shape the ACP SDK validates against:
    ``{"sessions": [SessionInfo, ...], "nextCursor": None}``. CLI-engine
    agents previously fell through to :meth:`Agent.list_sessions`
    (which returns rtxclaw-internal field names — ``hash`` / ``turn_count``
    / ``created_at``) and the resulting payload failed SDK validation,
    so the TUI's session picker silently returned an empty list.

    Rules:

    1. Walk ``sessions_dir`` for ``*.json`` files.
    2. Skip sidecars (any stem containing a dot — these are
       ``<hash>.claude_cli.json`` / ``<hash>.delegate_claude.json`` /
       ``<hash>.todos.json``; sidecars do NOT carry the full session
       schema and a sidecar like ``.todos.json`` is a JSON array that
       would crash the dict loader below).
    3. Drop empty-turn sessions (created by ``/new`` + disconnect; no
       replay value).
    4. ACP ``SessionInfo`` requires a non-empty absolute ``cwd``; fall
       back to ``agent_home`` when ``workspace_cwd`` is missing on
       older session files.
    5. Sort most-recent first by ``updatedAt`` (last turn's end time,
       falling back to ``started_at`` then ``created_at``). Cap at
       ``max_sessions`` so a 339-session directory doesn't inflate
       every poll.
    """
    candidates: list[dict[str, Any]] = []
    if sessions_dir.is_dir():
        for entry in sessions_dir.iterdir():
            if not entry.is_file() or entry.suffix != ".json":
                continue
            if "." in entry.stem:
                continue
            try:
                data = json.loads(entry.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            if not isinstance(data, dict):
                continue
            turns = data.get("turns") or []
            if not isinstance(turns, list) or not turns:
                continue
            cwd_field = data.get("workspace_cwd") or str(agent_home)
            last = turns[-1] if isinstance(turns[-1], dict) else {}
            updated_at = (
                last.get("ended_at")
                or last.get("started_at")
                or data.get("created_at")
                or ""
            )
            candidates.append({
                "sessionId": data.get("hash") or entry.stem,
                "cwd": cwd_field,
                "title": data.get("title") or f"untitled-{entry.stem[-8:]}",
                "updatedAt": updated_at,
                "_meta": {
                    "rtxclaw": {
                        "turn_count": len(turns),
                        # Surface the engine so the picker can label
                        # claude/codex/gemini sessions when needed; the
                        # TUI's translation layer ignores unknown
                        # meta keys, so this is forward-compat.
                        "engine": data.get("engine") or "",
                    },
                },
            })
    candidates.sort(key=lambda s: s.get("updatedAt") or "", reverse=True)
    return {"sessions": candidates[:max_sessions], "nextCursor": None}


class CoreBackend:
    """Adapter from rtxclaw_core's session/turn primitives to
    :class:`rtxclaw_acp.server.AgentBackend`.

    Owns session lifecycle (new_session / load_session / list_sessions /
    close_session / inject_user_message / set_mode / set_config_option),
    cancel routing into the live :class:`LocalLLMEngine` via
    :meth:`Engine.abort(turn_id)`, and outbound channel binding
    (``bind_session_server`` / ``_outbound_for``) so permission +
    ask_user requests reach the connection that owns the session.

    :meth:`prompt` is a 4-line proxy that forwards through
    :meth:`Agent.run_turn` and translates the AgentTurnEvent stream
    to ACP sessionUpdate dicts via :mod:`.acp_translation`. The
    multi-round turn loop / compaction / loop detection / tool
    dispatch / hook lifecycle all live in
    :class:`rtxclaw_core.agents.local_llm.LocalLLMEngine`.

    State (keyed by ACP session id):

    * ``_active_sessions``: the in-memory :class:`Session` for sessions
      that have been created or loaded this run. Persistence is to
      ``cfg.sessions_dir/<hash>.json`` via :meth:`Session.save`.
    * ``_new_backend_active_turns``: ``sid → turn_id`` for the live
      in-flight turn so :meth:`cancel` can route through
      :meth:`Engine.abort(turn_id)`.
    """

    def __init__(
        self,
        config: AgentConfig,
        *,
        server_handle: Optional[Any] = None,
        agent: Optional[Any] = None,
    ) -> None:
        self.cfg = config
        # ``agent`` is the pre-built :class:`Agent` (with its
        # LocalLLMEngine) constructed by :class:`AgentACPBackend`.
        # When provided, ``_get_new_agent`` returns it instead of
        # building a duplicate pair — single source of truth for the
        # session lock / promoted-tools / mode-overrides state the
        # engine owns. Falls back to lazy construction for direct
        # callers (tests, stdio entry point) that don't have an
        # Agent on hand.
        self._preset_agent = agent
        # Optional handle to the AcpServer hosting this backend.
        # ``server_handle`` is the SINGLE-connection fallback (stdio
        # path, tests). Under the gateway, ONE CoreBackend is shared
        # by every HTTP/WS connection to ``/acp/<agent>`` — a single
        # handle would race between e.g. a TUI and a Telegram client.
        # ``_session_servers`` is the per-session override: each
        # AcpServer binds itself here for the sessions opened on its
        # connection (see ``bind_session_server``), and
        # ``_outbound_for`` resolves the right channel per session.
        # Permission / ask_user requests therefore always reach the
        # connection that actually owns the session.
        self.server_handle = server_handle
        self._session_servers: dict[str, Any] = {}
        self._active_sessions: dict[str, Session] = {}
        # The live Agent + LocalLLMEngine; built on first use (or
        # passed in via ``agent=``). All turn-loop state lives on
        # the engine — promoted_tools, mode_overrides, cancelled,
        # pending_user_messages, active_turns, session_to_turn.
        self._new_agent: Optional[Any] = None
        # sid → turn_id for the live in-flight turn so :meth:`cancel`
        # can route through ``engine.abort(turn_id)``. Populated by
        # the ``on_turn_started`` callback in ``agent_events_to_acp``.
        self._new_backend_active_turns: dict[str, str] = {}
        # sid → monotonic timestamp of the most recent :meth:`cancel`
        # call (fix D). A second cancel arriving within
        # ``_HARD_KILL_WINDOW_S`` of the first escalates ``TurnState.stop``
        # to SIGKILL + ``killpg`` so a wedged python tool runner (one
        # that swallowed the first SIGTERM) doesn't outlive the operator
        # double-tapping ESC. Cleared lazily — entries linger until the
        # next cancel rebinds them, which is fine since the timestamp
        # comparison is per-session and only an explicit cancel reads it.
        self._last_cancel_at: dict[str, float] = {}

    # -- outbound-channel routing -----------------------------------------

    def bind_session_server(self, session_id: str, server: Any) -> None:
        """Register ``server`` as the outbound ACP channel for ``session_id``.

        Called by :class:`AcpServer` on ``session/new`` / ``session/load``.
        Lets a backend shared across many connections (the gateway
        mounts one CoreBackend per agent) route ``session/request_permission``
        and ``session/ask_user`` to the connection that owns the
        session rather than to whichever connection happened to attach
        last. See ``_outbound_for``.
        """
        if session_id:
            self._session_servers[session_id] = server

    def unbind_session_server(self, session_id: str) -> None:
        """Drop the per-session outbound binding for ``session_id``.

        Called by :class:`AcpServer` on ``session/close`` and on
        connection teardown. Idempotent — unbinding an unknown session
        is a no-op.
        """
        self._session_servers.pop(session_id, None)

    def _outbound_for(self, session_id: str) -> Optional[Any]:
        """Resolve the outbound ACP channel for ``session_id``.

        Prefers the per-session binding written by
        :meth:`bind_session_server` (so a backend shared across many
        connections routes ``session/request_permission`` and
        ``session/ask_user`` to the connection that owns the session,
        not to whichever connection happened to attach last). Falls
        back to the bare ``server_handle`` for single-connection
        callers / stub backends in tests. ``None`` when neither is
        bound.
        """
        srv = self._session_servers.get(session_id)
        if srv is not None:
            return srv
        return getattr(self, "server_handle", None)

    # -- internal helpers --------------------------------------------------

    def _session_for(self, session_id: str) -> Optional[Session]:
        sess = self._active_sessions.get(session_id)
        if sess is not None:
            return sess
        # Try to lazy-load from disk so a fresh backend after a restart
        # can answer ``session/load`` for a hash it didn't create.
        path = self.cfg.sessions_dir / f"{session_id}.json"
        if not path.exists():
            return None
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None
        sess = Session(
            hash=data.get("hash") or session_id,
            title=data.get("title") or f"untitled-{session_id[-8:]}",
            created_at=data.get("created_at") or _now(),
            system_prompt=data.get("system_prompt") or "",
            model=data.get("model") or self.cfg.upstream_model,
            endpoint=data.get("endpoint") or self.cfg.upstream_endpoint,
            turns=list(data.get("turns") or []),
            workspace_cwd=data.get("workspace_cwd") or "",
            workspace_origin=data.get("workspace_origin") or "",
        )
        self._active_sessions[session_id] = sess
        return sess

    # -- AgentBackend Protocol --------------------------------------------

    async def initialize(
        self,
        protocol_version: int,
        client_capabilities: Mapping[str, Any] | None,
        client_info: Mapping[str, Any] | None,
    ) -> Mapping[str, Any] | None:
        """Record the negotiated peer info — the dispatcher's static
        ``initialize`` response is built from advertised capabilities,
        so the return value here is informational only."""
        self._peer_protocol_version = protocol_version
        self._peer_client_capabilities = client_capabilities
        self._peer_client_info = client_info
        return None

    async def authenticate(self, method_id: str) -> None:
        """No auth methods advertised today — the dispatcher refuses
        ``authenticate`` with METHOD_NOT_FOUND before reaching this
        hook. Implemented as a no-op for Protocol completeness."""
        return None

    async def new_session(
        self,
        cwd: str,
        mcp_servers: list[Mapping[str, Any]],
    ) -> Mapping[str, Any]:
        # The dispatcher already rejected http/sse mcp entries against
        # our advertised capabilities; stdio entries (no ``type`` field
        # or ``type=="stdio"``) are accepted unconditionally.
        # Require an explicit upstream model id. The previous
        # ``/v1/models`` auto-discovery was a footgun: the picked id
        # depended on whichever model the upstream happened to expose
        # first at session-start time, so two sessions launched minutes
        # apart could silently bind to different models — and the id
        # is baked into ``Session`` at creation, never re-resolved per
        # turn, so the operator only noticed when they got off-key
        # answers from the wrong checkpoint. Force the operator to
        # name the model explicitly via ``cfg.upstream_model`` (or via
        # the active row in ``cfg.models[]`` for alias switches).
        endpoint = self.cfg.upstream_endpoint
        model = (self.cfg.upstream_model or "").strip()
        if endpoint and not model:
            raise RuntimeError(
                f"upstream {endpoint!r} has no `upstream_model` configured. "
                f"Set an explicit model id in ~/.rtxclaw/config.json — "
                f"`/v1/models` auto-discovery has been removed."
            )
        # Compose the full system prompt: cfg.system + SOUL/USER/TOOLS/
        # AGENTS context files + skill index + MCP/ACP advertisement.
        # Build once at session creation and persist on the Session
        # record so every subsequent turn replays a byte-identical
        # prefix — vLLM APC / SGLang RadixAttention only reuses KV
        # cache if the prefix matches block-aligned bytes.
        # Re-composition would invalidate the cache mid-session.
        active_mode = self.cfg.permission_mode or "auto"
        try:
            composed_system = _compose_system_prompt(
                self.cfg,
                active_mode,
                workspace_cwd=cwd,
                workspace_origin="acp",
            )
        except Exception:  # noqa: BLE001
            # Best-effort: a missing/unreadable workspace file must not
            # block session creation. Fall back to the bare cfg.system
            # so the session is still usable.
            composed_system = self.cfg.system or ""
        sess = Session.new(
            system_prompt=composed_system,
            system_mode=active_mode,
            model=model,
            endpoint=endpoint,
            sessions_dir=self.cfg.sessions_dir,
            workspace_cwd=cwd,
            workspace_origin="acp",
        )
        # Persist immediately so ``session/list`` after a restart finds
        # the row even if no turn has run yet — and, critically, so
        # ``Agent.get_session`` (which only reads disk) can resolve
        # the sid on the very first prompt. Without ``force=True``
        # the empty-session skip in ``Session.save`` short-circuits
        # this write and the bridge-created sid then 404s in
        # ``Agent.run_turn`` (observed 2026-05-15: every fresh TUI
        # got ``session not found`` on its first submit). The
        # orphan-empty-file cost the skip was designed to avoid is
        # bounded — see gc note below.
        try:
            sess.save(self.cfg.sessions_dir, force=True)
        except Exception:  # noqa: BLE001
            # Persistence is best-effort during session creation; the
            # in-memory record is the source of truth for an active
            # bridge.
            pass
        self._active_sessions[sess.hash] = sess
        return {
            "sessionId": sess.hash,
            "modes": self._modes_state(active_mode),
            # ``models`` is a non-spec extension we kept for legacy
            # frontends; rename to a non-conflicting key prefixed with
            # ``_`` so spec-strict ACP clients don't see it as a typed
            # field. Frontends that read it from rtxclaw still get the
            # data via ``configOptions``.
            "configOptions": self._config_options_state(),
            "_meta": {"rtxclaw": {"siblings": self._sibling_registry()}},
        }

    def _modes_state(self, active_mode: str) -> dict[str, Any]:
        """Build a spec-shaped ``SessionModeState`` payload.

        Spec ref: ``schema.json:SessionModeState`` —
        ``{availableModes: SessionMode[], currentModeId: string}``.
        Without this, ACP clients can't drive ``session/set_mode``
        because they have no list of valid mode ids to choose from.
        """
        return {
            "availableModes": [
                {"id": "auto",
                 "name": "auto",
                 "description":
                     "Auto-approve safe tools; prompt on destructive actions."},
                {"id": "ask",
                 "name": "ask",
                 "description":
                     "Prompt for confirmation on every tool call."},
                {"id": "plan",
                 "name": "plan",
                 "description":
                     "Plan-only mode — propose tool calls without executing."},
            ],
            "currentModeId": active_mode,
        }

    def _sibling_registry(self) -> list[dict[str, Any]]:
        """Names + capability hints of every rtxclaw-native sibling
        agent the gateway hosts. Frontends consume this to auto-wire
        ``/<name> <task>`` slash commands without hardcoding.

        Excludes the calling agent's OWN name (you can't delegate to
        yourself) and excludes external-LLM proxies (claude / codex /
        gemini) since those have bespoke per-vendor handlers, not the
        uniform ``delegate_agent(name, task)`` interface.

        Reads from ``load_global_config()`` directly because
        ``acp_agents`` isn't a dataclass field on ``AgentConfig`` (the
        merged-config path drops global-only keys that weren't in the
        per-agent allowlist). Same source the ``delegate_agent`` runner
        uses, so the registry the frontend sees can never disagree with
        what the runner can dispatch.
        """
        from rtxclaw_core.agent import load_global_config
        glob = load_global_config()
        agents = glob.get("acp_agents") or {}
        my_name = getattr(self.cfg, "name", "") or ""
        out: list[dict[str, Any]] = []
        for name, row in agents.items():
            if not isinstance(row, Mapping):
                continue
            if name == my_name:
                continue
            out.append(
                {
                    "name": name,
                    "capabilities": list(row.get("capabilities") or []),
                    "timeout_s": row.get("timeout_s"),
                }
            )
        return out

    def _config_options_state(self) -> list[dict[str, Any]]:
        """Spec-shaped ``SessionConfigOption`` list for the wire.

        The ACP SDK's ``SessionConfigOptionSelect`` schema requires
        ``{id, name, type:"select", currentValue, options:[{id,
        label}]}`` — building a payload that doesn't validate breaks
        every ``session/new`` response (pydantic rejects, the SDK
        raises mid-prompt and the bot surfaces "agent error").
        Today rtxclaw does NOT expose ``model`` as a wire-level config
        option (we use the dedicated ``session/set_config_option``
        path with a free-form alias). Until the schema-shaped option
        list is wired, keep the field empty so the response validates.
        """
        return []

    async def load_session(
        self,
        session_id: str,
        cwd: str,
        mcp_servers: list[Mapping[str, Any]],
    ) -> Mapping[str, Any]:
        sess = self._session_for(session_id)
        if sess is None:
            raise RuntimeError(f"session not found: {session_id!r}")
        # Refresh workspace context — a frontend reattaching from a
        # different cwd should see its updated workspace string in the
        # next composed system prompt.
        if cwd:
            sess.workspace_cwd = cwd
        return {
            "modes": self._modes_state(
                sess.system_mode or self.cfg.permission_mode or "auto",
            ),
            "configOptions": self._config_options_state(),
            "_meta": {"rtxclaw": {"siblings": self._sibling_registry()}},
        }

    async def list_sessions(
        self,
        cursor: str | None,
        cwd: str | None,
    ) -> Mapping[str, Any]:
        return list_sessions_acp(self.cfg.sessions_dir, self.cfg.home)

    async def close_session(self, session_id: str) -> None:
        # Cancel any in-flight turn first so we don't leak a worker.
        await self.cancel(session_id)
        sess = self._active_sessions.pop(session_id, None)
        if sess is not None:
            try:
                sess.save(self.cfg.sessions_dir)
            except Exception:  # noqa: BLE001
                pass

    async def inject_user_message(
        self, session_id: str, text: str,
    ) -> Mapping[str, Any]:
        """Push a mid-turn user prompt into the engine's inject buffer.

        Frontend calls this when the operator submits a fresh prompt
        while a multi-round plan is still streaming. The engine drains
        the buffer at every round boundary, appending each entry to
        the live message list as a ``user`` role message before the
        next worker spawn — so the model sees the steering message on
        its very next round.

        Returns ``{"ok": True, "queued": True}`` on success;
        ``{"ok": False, "reason": "..."}`` if the engine doesn't
        support injection or the message is empty. Does NOT require
        an active turn; if no turn is running the message lands at
        the start of the next ``prompt`` call for this sid.
        """
        sess = self._session_for(session_id)
        if sess is None:
            raise RuntimeError(f"session not found: {session_id!r}")
        text = (text or "").strip()
        if not text:
            return {"ok": False, "reason": "empty text"}
        agent = self._get_new_agent()
        ok = False
        try:
            ok = bool(agent.inject_user_message(session_id, text))
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "reason": f"inject failed: {exc}"}
        return {"ok": ok, "queued": ok}

    async def set_mode(self, session_id: str, mode_id: str) -> None:
        sess = self._session_for(session_id)
        if sess is None:
            raise RuntimeError(f"session not found: {session_id!r}")
        sess.system_mode = mode_id
        # Propagate to the engine's per-session ``_mode_overrides``
        # map so the live turn loop (rounds-cap, permission policy)
        # sees the new mode immediately. Eagerly build the engine if
        # the client called ``set_mode`` before its first prompt —
        # otherwise the engine state is set on the wrong instance
        # and the mode silently no-ops for the rest of the session.
        try:
            agent = self._get_new_agent()
        except Exception:  # noqa: BLE001
            agent = None
        if agent is not None:
            engine_set_mode = getattr(agent.engine, "set_mode", None)
            if callable(engine_set_mode):
                try:
                    res = engine_set_mode(session_id, mode_id)
                    if hasattr(res, "__await__"):
                        await res
                except ValueError:
                    raise
                except Exception:  # noqa: BLE001
                    pass
        # Spec compliance (ACP 0.12.x): emit ``current_mode_update`` so
        # the client can refresh its mode UI. Fire-and-forget — we
        # MUST NOT block the set_mode response on a transport write,
        # because the same transport is also writing the response to
        # the in-flight set_mode request and a circular await on
        # ``write_lock`` would deadlock the whole connection.
        # Use the per-session outbound resolver so a TUI + Telegram
        # multi-connection setup notifies the connection that owns
        # this session, not whichever happened to attach last.
        srv = self._outbound_for(session_id) if hasattr(
            self, "_outbound_for"
        ) else getattr(self, "server_handle", None)
        notify = getattr(srv, "notify_session_update", None)
        if notify is None:
            return

        async def _emit() -> None:
            try:
                await notify(
                    session_id=session_id,
                    update={
                        "sessionUpdate": "current_mode_update",
                        "currentModeId": mode_id,
                    },
                )
            except Exception:  # noqa: BLE001
                pass

        try:
            asyncio.create_task(_emit())
        except RuntimeError:
            # No running loop (in-process tests); skip the notification.
            pass

    async def set_config_option(
        self, session_id: str, config_id: str, value: Any
    ) -> None:
        """Apply a session-scoped config option.

        Today the only registered option is ``model`` — the value is an
        alias from ``cfg.models[]``. We resolve the row, mutate the
        bound :class:`Session` so subsequent worker-spawn rounds talk to
        the new endpoint/model, and persist via :meth:`Session.save` so
        a frontend reattach (or session reload after a restart) sees
        the same model.

        Unknown aliases raise :class:`ValueError`; the dispatcher's
        generic-exception handler turns the raise into a JSON-RPC
        error response so the caller sees a clean failure rather than
        a silent no-op.
        """
        sess = self._session_for(session_id)
        if sess is None:
            raise RuntimeError(f"session not found: {session_id!r}")

        # Propagate every option to the live engine so per-session
        # ``_promoted_tools`` / ``reasoning_visibility`` / ``temperature``
        # / etc. take effect on the next round. Eagerly build the
        # engine if the client called ``set_config_option`` before
        # its first prompt — the previous gating on
        # ``self._new_agent is not None`` silently no-op'd
        # pre-prompt callers and dropped the option on the floor.
        try:
            agent = self._get_new_agent()
        except Exception:  # noqa: BLE001
            agent = None
        if agent is not None:
            engine_set_opt = getattr(
                agent.engine, "set_config_option", None,
            )
            if callable(engine_set_opt):
                try:
                    res = engine_set_opt(session_id, config_id, value)
                    if hasattr(res, "__await__"):
                        await res
                except ValueError:
                    raise
                except Exception:  # noqa: BLE001
                    pass

        if config_id == "model":
            value_s = "" if value is None else str(value)
            row = self._resolve_model_row(value_s)
            if row is None and value_s.startswith(("http://", "https://")):
                # Manual ``/model https://…`` / picker-without-alias
                # path: resolve the row by URL through the regular
                # endpoint resolver. ``model_row_for_endpoint``
                # returns a synthetic row when the URL doesn't match
                # any configured entry — that's intentional, lets an
                # operator switch to an ad-hoc upstream.
                try:
                    candidate = self.cfg.model_row_for_endpoint(value_s)
                except Exception:  # noqa: BLE001
                    candidate = None
                if candidate and candidate.get("baseUrl"):
                    row = candidate
            if row is None:
                raise ValueError(f"unknown model alias: {value_s}")
            row_id = str(row.get("id") or "").strip()
            base_url = str(row.get("baseUrl") or "")
            if not row_id:
                # Auto-discovery removed: every model row must name an
                # explicit id. Reject the switch with a clear pointer
                # to the config so the operator knows where to fix it.
                raise ValueError(
                    f"model alias {value_s!r} has no `id` configured "
                    f"({base_url or '<no baseUrl>'}). Set the model id "
                    f"explicitly in ~/.rtxclaw/config.json — auto-discover "
                    f"via /v1/models has been removed."
                )
            sess.model = row_id
            sess.endpoint = base_url
            sess.backend = str(row.get("backend") or "")
            try:
                sess.context_window = int(row.get("contextWindow") or 0)
            except (TypeError, ValueError):
                sess.context_window = 0
            try:
                sess.save(self.cfg.sessions_dir)
            except Exception:  # noqa: BLE001
                # Persistence is best-effort; the in-memory mutation is
                # what the next worker round reads from.
                pass
            return

        # Unknown config id — record on the session so subsequent
        # ``set_mode`` / ``load_session`` round-trips can observe the
        # value, but don't act on anything else.
        if not hasattr(sess, "_acp_config"):
            sess._acp_config = {}  # type: ignore[attr-defined]
        sess._acp_config[config_id] = value  # type: ignore[attr-defined]

    def _resolve_model_row(self, alias: str) -> Optional[Mapping[str, Any]]:
        """Look up a model row in ``cfg.models`` by alias.

        Returns ``None`` when the alias does not match any configured
        row. We deliberately do NOT fall through to
        :meth:`AgentConfig.resolve_model` here — that helper synthesizes
        a primary row when nothing matches, which would silently mask
        an unknown-alias request.
        """
        if not alias:
            return None
        for row in self.cfg.models or []:
            if not isinstance(row, Mapping):
                continue
            if str(row.get("alias") or "") == alias:
                return dict(row)
        return None

    async def cancel(self, session_id: str) -> None:
        """Abort the in-flight turn for ``session_id``.

        Resolves the live ``turn_id`` via
        ``_new_backend_active_turns[sid]`` and calls
        :meth:`Engine.abort(turn_id)`. The engine flips its per-
        session cancel flag and SIGTERMs the active subprocess
        (worker OR tool runner) via :meth:`TurnState.stop`. Two
        presses inside ``_HARD_KILL_WINDOW_S`` escalate to SIGKILL +
        ``killpg`` on the process group.
        """
        # Fix D: two-press hard-kill. If a previous cancel for this
        # session landed within the window, escalate to SIGKILL +
        # killpg on the active subprocesses. The 2026-05-12
        # deepseek-v4-flash post-mortem showed the dispatch loop
        # repeatedly emitting fresh tool calls after force-terminate;
        # while fix A blocks that case at the bridge level, a wedged
        # tool_runner that swallowed SIGTERM (rare but possible for
        # GIL-blocking C extensions) would still leave the operator
        # without a second-line kill. Tracked even when no turn is
        # currently active so a cancel-after-turn-end double-press
        # doesn't reset the window for the next turn.
        now_mono = _time.monotonic()
        last_mono = self._last_cancel_at.get(session_id)
        force_kill = bool(
            last_mono is not None
            and (now_mono - last_mono) <= _HARD_KILL_WINDOW_S
        )
        self._last_cancel_at[session_id] = now_mono

        # Route the abort through the live engine. ``LocalLLMEngine.abort``
        # flips its per-session cancel flag and SIGTERMs the active
        # subprocess (worker OR tool runner) via ``TurnState.stop``.
        # Pass ``force=force_kill`` so the two-press hard-kill window
        # actually escalates to SIGKILL + ``killpg`` on the process
        # group (the previous code computed the flag but never
        # threaded it through — audit 2026-05-15 finding B3).
        new_turn_id = self._new_backend_active_turns.get(session_id)
        had_active_turn = bool(new_turn_id)
        if new_turn_id and self._new_agent is not None:
            try:
                await self._new_agent.engine.abort(
                    new_turn_id, force=force_kill,
                )
            except TypeError:
                # Engine.abort without the ``force`` kwarg — fall
                # back to a plain abort so older engine subclasses
                # still cancel.
                try:
                    await self._new_agent.engine.abort(new_turn_id)
                except Exception:  # noqa: BLE001
                    pass
            except Exception:  # noqa: BLE001
                pass
        # External cancel (ESC in TUI, /cancel from a frontend, ACP
        # session/cancel from a remote client). The session record
        # will show aborted=true on the in-flight turn; this log
        # entry distinguishes "operator stopped me" from a loop-
        # detector kill or a runner SIGTERM. ``force`` exposes the
        # SIGKILL escalation path so a post-mortem can tell which
        # ESC press finally landed the kill.
        self._log_event(
            "EXTERNAL_CANCEL",
            sid=session_id[:12],
            had_active_turn=had_active_turn,
            force=force_kill,
        )

    # -- prompt orchestration ----------------------------------------------

    def _log_event(self, event: str, **fields: Any) -> None:
        """Append one structured event line to ``cfg.logfile``.

        Used for silent control-flow milestones — loop-detector hits,
        external cancels, runner aborts, permission denials, max-round
        exhaustion, worker errors. Without this, the only signal that
        something cancelled a turn is ``aborted=true`` in the session
        JSON and the user-facing ``stopReason=cancelled`` — neither
        names a cause, which is how the "I didn't cancel anything"
        2026-05-07 ticket happened.

        Format mirrors ``TURN_METRICS``: a single tag token followed
        by a JSON object so ``grep`` + ``jq`` work against gateway.log
        without a parser. ``ts`` is added if the caller didn't supply
        one. Field values are passed through ``json.dumps(default=str)``
        so non-JSON types (e.g. ``Exception``) don't blow up the write.

        Never raises: the logfile is best-effort observability and a
        failed write must not abort the turn it's describing. Falls
        back to stderr so tests + ``journalctl`` still capture the
        line if the configured path is unwritable.
        """
        payload = {"ts": _now(), **fields}
        try:
            line = f"{event} {json.dumps(payload, default=str)}\n"
        except Exception:  # noqa: BLE001
            line = f"{event} {{\"_log_event_serialise_failed\": true}}\n"
        try:
            with open(self.cfg.logfile, "a", encoding="utf-8") as _f:
                _f.write(line)
        except Exception:  # noqa: BLE001
            try:
                print(line.rstrip(), file=sys.stderr, flush=True)
            except Exception:  # noqa: BLE001
                pass
        # Also surface via the python logger so anything that wires
        # up a handler (tests, dev runs) sees the event without having
        # to tail gateway.log. ``warning`` (not info) so abort/cancel
        # signals stand out from the per-round noise.
        try:
            _LOG.warning("%s %s", event, payload)
        except Exception:  # noqa: BLE001
            pass

    def _get_new_agent(self) -> Any:
        """Return the live Agent that drives this backend's turns.

        Single-source-of-truth contract: when the gateway pre-built
        the Agent and passed it via ``agent=`` to our constructor,
        return it unchanged so :class:`AgentACPBackend` and
        :class:`CoreBackend` share ONE :class:`LocalLLMEngine`
        instance (per-session locks, promoted-tools, mode overrides
        all single-sourced). Stand-alone callers (tests, the stdio
        entry point) that didn't pre-build an Agent get a lazily-
        constructed one wired to the same ``_default_run_tool``
        dispatcher.

        The ``backend=self`` closure is preserved in both branches:
        the engine's :meth:`_invoke_runner` calls
        ``runner(session_id, call, turn, **kwargs)`` — narrower than
        the standalone ``_default_run_tool`` signature that expects
        ``backend`` first — so the wrapper has to inject ``self``.
        Without this binding every tool call 404s with
        ``_default_run_tool() missing 1 required positional argument:
        'turn'`` (observed 2026-05-15: every TUI tool call failed).
        """
        if self._new_agent is not None:
            return self._new_agent

        backend = self  # captured by the closure below

        async def _tool_runner(
            session_id: str,
            call: Mapping[str, Any],
            turn: TurnState,
            **kwargs: Any,
        ) -> Any:
            return await _default_run_tool(
                backend, session_id, call, turn, **kwargs
            )

        if self._preset_agent is not None:
            # Re-wire the preset engine's tool_runner so tool calls
            # go through THIS CoreBackend (the one bound to this
            # connection) instead of any backend wired at factory
            # time (factory.load_agent has no CoreBackend handle).
            try:
                self._preset_agent.engine._tool_runner = _tool_runner
            except Exception:  # noqa: BLE001
                pass
            # Install our per-session outbound resolver so
            # ``Agent.resolve_permission`` can surface mode=ask
            # prompts to the connection that opened the session.
            # Without this the new path's PermissionRequested →
            # ask_user(outbound=None) flow silently auto-denies on
            # every destructive tool call.
            self._preset_agent._outbound_resolver = self._outbound_for
            self._new_agent = self._preset_agent
            return self._new_agent

        from rtxclaw_core.agents import local_llm
        from rtxclaw_core.agents.agent import Agent

        engine = local_llm.LocalLLMEngine(self.cfg, tool_runner=_tool_runner)
        self._new_agent = Agent(cfg=self.cfg, engine=engine)
        self._new_agent._outbound_resolver = self._outbound_for
        return self._new_agent

    async def _prompt_via_new_backend(
        self,
        session_id: str,
        prompt: list[Mapping[str, Any]],
        turn_id: str,
    ) -> AsyncIterator[Mapping[str, Any]]:
        """Run one turn through ``Agent.run_turn``.

        Routes through the cached Agent (see :meth:`_get_new_agent`)
        and translates the ``AgentTurnEvent`` stream to ACP
        sessionUpdate dicts via :mod:`rtxclaw_core.agents.acp_translation`.
        The Agent's :class:`~rtxclaw_core.agents.local_llm.LocalLLMEngine`
        owns the full multi-round loop — worker spawn, tool dispatch,
        permission policy, the Claude Code hook lifecycle, compaction,
        layered loop detection, distill / nudge / force-terminate
        recovery, and the three premature-turn-end variants.
        """
        from rtxclaw_core.agents import acp_translation

        agent = self._get_new_agent()

        # First-call-per-sid: attach the live session so the engine's
        # per-session state (cancelled, promoted_tools, mode override)
        # gets populated from the loaded Session record (codex audit
        # phase-3a final #3).
        if session_id not in agent.engine._cancelled:
            sess = self._session_for(session_id)
            if sess is not None:
                try:
                    agent.engine.attach_session(session_id, sess)
                except Exception:  # noqa: BLE001
                    pass

        # Flatten the ACP prompt blocks into (text, parts).
        text = _flatten_prompt(prompt)
        parts: list[dict[str, Any]] = []
        if any((b.get("type") or "") != "text" for b in prompt):
            user_content = _blocks_to_user_content(prompt)
            if isinstance(user_content, list):
                parts = [dict(p) for p in user_content]

        events = agent.run_turn(
            session_id,
            prompt=text,
            prompt_parts=parts or None,
        )

        def _on_turn_started(ev: Any) -> None:
            # Wire the gateway's sid → turn_id map for ACP cancel
            # routing (codex audit phase-3a final #2).
            try:
                self._new_backend_active_turns[session_id] = ev.turn_id
            except Exception:  # noqa: BLE001
                pass

        try:
            async for msg in acp_translation.agent_events_to_acp(
                events,
                context_window=int(
                    getattr(self.cfg, "upstream_max_context", 0) or 0
                ),
                on_turn_started=_on_turn_started,
            ):
                yield msg
        except Exception as exc:  # noqa: BLE001
            self._log_event(
                "NEW_BACKEND_FAILED",
                sid=session_id[:12],
                turn_id=turn_id,
                error=str(exc)[:300],
            )
            yield {
                "sessionUpdate": "agent_message_chunk",
                "content": {
                    "type": "text",
                    "text": f"[new backend failed: {exc}]",
                },
            }
            yield {"stopReason": "end_turn"}
        finally:
            # Drop the active-turn mapping so a subsequent cancel
            # doesn't fire against a finished turn_id.
            self._new_backend_active_turns.pop(session_id, None)

    async def prompt(
        self,
        session_id: str,
        message_id: str | None,
        prompt: list[Mapping[str, Any]],
    ) -> AsyncIterator[Mapping[str, Any]]:
        """Run one prompt turn against the bound session.

        rtxclaw has ONE turn architecture: the Agent + Engine path.
        This thin wrapper resolves the session, allocates a turn id,
        and routes through :meth:`_prompt_via_new_backend` ->
        ``Agent.run_turn`` -> ``LocalLLMEngine.run_turn``, which owns
        the entire multi-round loop — worker spawn, tool dispatch,
        permission policy, the Claude Code hook lifecycle
        (UserPromptSubmit / PreToolUse / PostToolUse / Stop /
        PreCompact), proactive + reactive compaction, layered loop
        detection, distill / nudge / force-terminate recovery, and
        the three premature-turn-end variants (silent EOS,
        mid-syntax cutoff, colon cliffhanger). Yields
        ``AgentTurnEvent``s that ``acp_translation`` turns into ACP
        sessionUpdate dicts.
        """
        sess = self._session_for(session_id)
        if sess is None:
            raise RuntimeError(f"session not found: {session_id!r}")
        turn_id = _new_turn_id()
        async for ev in self._prompt_via_new_backend(
            session_id, prompt, turn_id,
        ):
            yield ev
