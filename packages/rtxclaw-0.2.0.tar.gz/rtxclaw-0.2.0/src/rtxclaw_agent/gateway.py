"""Single-process agent gateway.

Hosts every configured agent in one parent process. Binds a single ACP
Streamable HTTP listener (default :20100) and mounts one
:class:`AgentACPBackend` per discovered agent under ``/acp/<agent>``.

ACP-compliance:

* The gateway IS an ACP server externally — same Starlette app a
  per-agent daemon would expose, mounted once per agent name.
* Each backend is in-process; no child subprocess. For local-LLM
  agents :class:`AgentACPBackend` holds an in-process
  :class:`CoreBackend` wrapper that delegates the multi-round turn
  loop to ``Agent.run_turn`` → :class:`LocalLLMEngine.run_turn`. For
  CLI agents (claude / codex / gemini) it routes through
  :class:`Agent` → :class:`ExternalCliEngine` → the per-turn CLI
  subprocess; the CLI process itself runs only for the duration of
  one turn.
* No protocol additions. ``new_session`` against ``/acp/main``
  allocates a session via the ``main`` agent's backend; subsequent
  calls for that session id route to the same backend.

Cancel cascade:

* Gateway-level abort (SIGTERM, ``rtxclaw gateway stop``) stops every
  per-agent heartbeat scheduler, then drains the HTTP listener.
* ACP ``cancel(session_id)`` routes through
  :meth:`AgentACPBackend.cancel` → :meth:`Engine.abort(turn_id)`
  which SIGTERMs the active subprocess (worker OR tool runner) via
  :class:`TurnState.stop`. Two ESC presses inside
  ``_HARD_KILL_WINDOW_S`` escalate to SIGKILL + ``killpg``.
"""
from __future__ import annotations

import asyncio
import contextlib
import logging
import os
import signal
from pathlib import Path
from typing import Any, Optional

from rtxclaw_core.agent import (
    AgentConfig,
    agents_root,
    load_global_config,
)


_LOG = logging.getLogger("rtxclaw.gateway")


# ---- defaults --------------------------------------------------------

_DEFAULT_HOST = "127.0.0.1"
_DEFAULT_PORT = 20100
# ---- AgentRegistry --------------------------------------------------
#
# Single-process replacement for the legacy ``ChildManager`` /
# ``ChildSession`` / ``RoutingBackend`` triplet that used to spawn one
# stdio ACP subprocess per agent. The user's "no legacy non-compliant
# routing" requirement: every agent is loaded in-memory via
# :func:`factory.load_agent` and exposed through a single
# :class:`AgentACPBackend` instance.
#
# ``AgentRegistry.get(name)`` returns that backend (lazy-allocated on
# first access so the boot sequence doesn't have to pay the
# load-every-agent cost for agents that are never used). All callers
# (the ACP HTTP mount, the openai_endpoint helper) talk to backends
# directly without any subprocess hop.


class AgentRegistry:
    """In-process agent registry. Replaces ChildManager.

    Holds one :class:`AgentACPBackend` instance per discovered agent
    for the gateway process's lifetime. No subprocess spawn, no idle
    GC, no LRU eviction — backends are lightweight Python objects.
    """

    def __init__(self, agent_names: list[str]) -> None:
        self.agent_names = list(agent_names)
        self._backends: dict[str, Any] = {}

    def get(self, name: str) -> Any:
        """Return the in-process :class:`AgentACPBackend` for ``name``."""
        if name in self._backends:
            return self._backends[name]
        from rtxclaw_core.agents.factory import load_agent
        from rtxclaw_core.agents.gateway_shim import AgentACPBackend
        agent = load_agent(name)
        backend = AgentACPBackend(agent)
        self._backends[name] = backend
        return backend

    def keys(self) -> list[str]:
        return list(self.agent_names)

    async def shutdown(self) -> None:
        """No-op — backends hold only in-memory state."""
        return None


# ---- gateway server --------------------------------------------------


def _gateway_config(global_cfg: Optional[dict] = None) -> dict[str, Any]:
    """Resolve gateway config from ``~/.rtxclaw/config.json``.

    Defaults: host=127.0.0.1, port=20100. ``host`` / ``port`` /
    ``auth_token`` overridable via the ``gateway`` block in the
    global config.
    """
    if global_cfg is None:
        global_cfg = load_global_config() or {}
    raw = global_cfg.get("gateway") or {}
    return {
        "host": str(raw.get("host") or _DEFAULT_HOST),
        "port": int(raw.get("port") or _DEFAULT_PORT),
        "auth_token": raw.get("auth_token") or None,
    }


def _discover_agents() -> list[str]:
    """Walk ``agents_root()`` and return every configured agent name.

    Each subdirectory with a ``config.json`` is considered an agent.
    Returns sorted names so the mount order is deterministic.
    """
    root = agents_root()
    if not root.is_dir():
        return []
    out: list[str] = []
    for entry in sorted(root.iterdir()):
        if not entry.is_dir():
            continue
        if (entry / "config.json").is_file():
            out.append(entry.name)
    return out


def _gateway_pidfile() -> Path:
    return Path(os.environ.get("RTXCLAW_HOME") or Path.home() / ".rtxclaw") / "gateway.pid"


async def serve_gateway() -> None:
    """Run the gateway parent process until SIGTERM/INT.

    Binds one Streamable HTTP listener; mounts ``/acp/<agent>`` for
    every discovered agent; lazy-spawns each child on first
    ``session/new``; cascades shutdown to every live child on stop.
    """
    from hypercorn.asyncio import serve as _h_serve
    from hypercorn.config import Config as _HCConfig
    from starlette.applications import Starlette
    from starlette.routing import Mount, Route
    from starlette.responses import JSONResponse, PlainTextResponse

    from rtxclaw_acp.server.http_server import make_acp_app
    from rtxclaw_agent.acp_stdio_main import (
        _build_agent_info,
        _build_capabilities,
    )

    gw = _gateway_config()
    bearer = gw["auth_token"]

    # Auto-scaffold built-in CLI-engine agents (claude/codex/gemini)
    # when their CLI is on PATH. Idempotent on every boot — never
    # overwrites operator customization. See
    # ``rtxclaw_core.agents.factory.ensure_default_external_agents``.
    try:
        from rtxclaw_core.agents.factory import ensure_default_external_agents
        scaffolded = ensure_default_external_agents()
        if scaffolded:
            _LOG.info(
                "auto-scaffolded built-in CLI-engine agents: %s",
                ", ".join(scaffolded),
            )
    except Exception as exc:  # noqa: BLE001
        # Scaffold failure must not block gateway boot; log + continue.
        _LOG.warning("auto-scaffold failed (continuing): %s", exc)

    agent_names = _discover_agents()
    if not agent_names:
        _LOG.warning(
            "no agents discovered under %s; gateway will run but every "
            "/acp/<name> route will 404 until an agent is configured",
            agents_root(),
        )

    # In-process agent registry replaces the legacy ChildManager.
    # See AgentRegistry above — each agent's :class:`AgentACPBackend`
    # is lazy-built on first use; no subprocess spawn.
    manager = AgentRegistry(agent_names)

    # Mount one ACP app per discovered agent under /acp/<name>. EVERY
    # agent is exposed through :class:`AgentACPBackend` regardless of
    # engine kind. AgentACPBackend internally:
    #
    #   * For local_llm agents — holds an in-process CoreBackend
    #     wrapper around the same Agent + LocalLLMEngine (single source
    #     of truth for session-lifecycle / cancel-routing / outbound
    #     channel binding). The multi-round dispatch / compaction /
    #     loop detection / distill recovery / premature-turn-end
    #     nudges all live in :class:`LocalLLMEngine.run_turn`.
    #   * For claude_cli / codex_cli / gemini_cli agents — routes
    #     through Agent.run_turn → Engine.run_turn →
    #     :func:`run_delegate_*_async` (the CLI subprocess driver
    #     shared between :meth:`ExternalCliEngine.delegate_runner`
    #     and the delegate-tool entry points in
    #     :mod:`rtxclaw_core.agents.delegate_shims`). The new engine
    #     layer adds agent-context priming (--append-system-prompt) and
    #     sha-change session-resume override.
    routes: list[Any] = []
    for name in agent_names:
        try:
            cfg = AgentConfig.load(name)
        except FileNotFoundError:
            continue
        # AgentACPBackend construction; lazy via the registry so the
        # boot sequence doesn't pay the full agent-load cost for
        # agents never used by a frontend.
        backend = manager.get(name)
        sub_app = make_acp_app(
            backend=backend,
            agent_capabilities=_build_capabilities(cfg),
            agent_info=_build_agent_info(cfg),
            auth_methods=[],
            bearer_token=bearer,
        )
        routes.append(Mount(f"/acp/{name}", app=sub_app))

        # Start the per-agent heartbeat scheduler when the config
        # asks for it. The pre-refactor stdio-per-agent path fired
        # this; the single-process gateway needs to start it explicitly
        # so background memory-synth / idle cleanup keeps running.
        try:
            agent_obj = getattr(backend, "agent", None)
            if agent_obj is not None and getattr(
                cfg, "heartbeat_enabled", False
            ):
                hb_task = agent_obj.start_heartbeat()
                if hb_task is not None:
                    _LOG.info(
                        "heartbeat scheduler started for agent %r", name,
                    )
        except Exception as exc:  # noqa: BLE001
            _LOG.warning(
                "heartbeat scheduler failed to start for %r: %s",
                name, exc,
            )

    async def _index(_request: Any) -> Any:
        return JSONResponse({
            "service": "rtxclaw-gateway",
            "agents": agent_names,
            "live_backends": sorted(manager._backends.keys()),
        })

    async def _health(_request: Any) -> Any:
        return PlainTextResponse("ok")

    routes.append(Route("/", _index, methods=["GET"]))
    routes.append(Route("/health", _health, methods=["GET"]))

    # OpenAI-compatible HTTP API at /openai/v1 — point Open WebUI (or any
    # OpenAI-spec client) here. Same gateway, same auth, same lifecycle;
    # routes the chat/completions field 'model' → AgentRegistry.get(name)
    # so each agent shows up as one OpenAI 'model'.
    from rtxclaw_agent.openai_endpoint import make_openai_app
    routes.append(Mount(
        "/openai/v1",
        app=make_openai_app(
            agent_names=agent_names,
            manager=manager,
            bearer_token=bearer,
        ),
    ))

    app = Starlette(routes=routes)

    stop_event = asyncio.Event()
    loop = asyncio.get_running_loop()

    def _on_signal() -> None:
        stop_event.set()

    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            loop.add_signal_handler(sig, _on_signal)
        except NotImplementedError:
            pass

    _hc_cfg = _HCConfig()
    _hc_cfg.bind = [f"{gw['host']}:{gw['port']}"]
    _hc_cfg.alpn_protocols = ["h2", "http/1.1"]
    _hc_cfg.accesslog = None
    _hc_cfg.errorlog = "-"

    # AgentRegistry has no GC loop — backends live for the process
    # lifetime (no per-agent subprocess to reap, no idle-eviction
    # window to enforce).
    pidfile = _gateway_pidfile()
    pidfile.parent.mkdir(parents=True, exist_ok=True)
    pidfile.write_text(str(os.getpid()))

    hc_task = asyncio.create_task(
        _h_serve(
            app,  # type: ignore[arg-type]
            _hc_cfg,
            shutdown_trigger=stop_event.wait,
        ),
        name="rtxclaw-gateway-http",
    )
    _LOG.info(
        "gateway listening on http://%s:%d/  (agents: %s)",
        gw["host"], gw["port"], ", ".join(agent_names) or "(none)",
    )
    print(
        f"[rtxclaw-gateway] listening on http://{gw['host']}:{gw['port']}/  "
        f"agents: {', '.join(agent_names) or '(none)'}",
        flush=True,
    )

    try:
        await stop_event.wait()
    finally:
        # Stop every running heartbeat scheduler before the listener
        # drains so background work doesn't outlive the gateway.
        for backend in list(manager._backends.values()):
            agent_obj = getattr(backend, "agent", None)
            if agent_obj is None:
                continue
            with contextlib.suppress(Exception):
                await asyncio.wait_for(
                    agent_obj.stop_heartbeat(), timeout=5.0,
                )
        # Cancel-cascade: shutdown manager first so all children get
        # SIGTERM before the HTTP listener fully drains. This honors
        # the "abort reaches all child subagents" contract.
        with contextlib.suppress(Exception):
            await asyncio.wait_for(manager.shutdown(), timeout=10.0)
        if not hc_task.done():
            try:
                await asyncio.wait_for(hc_task, timeout=5.0)
            except asyncio.TimeoutError:
                hc_task.cancel()
                with contextlib.suppress(asyncio.CancelledError, Exception):
                    await hc_task
        with contextlib.suppress(FileNotFoundError):
            pidfile.unlink()
        print("[rtxclaw-gateway] stopped", flush=True)


def serve_gateway_main() -> int:
    """Sync wrapper for the ``rtxclaw gateway serve`` subcommand."""
    try:
        asyncio.run(serve_gateway())
    except KeyboardInterrupt:
        return 0
    return 0


__all__ = [
    "AgentRegistry",
    "serve_gateway",
    "serve_gateway_main",
]
