# Modified from https://github.com/PathologyFoundation/plip/blob/main/plip.py
import warnings

import torch

from lazyslide_models._model_registry import register
from lazyslide_models._utils import find_stack_level, hf_access
from lazyslide_models.base import DenseTokens, ImageTextModel, ModelTask


@register(
    key="plip",
    task=ModelTask.multimodal,
    license="Non-commercial",
    description="Pathology Language-Image Pretraining (PLIP)",
    commercial=False,
    hf_url="https://huggingface.co/vinid/plip",
    github_url="https://github.com/PathologyFoundation/plip",
    paper_url="https://doi.org/10.1038/s41591-023-02504-3",
    bib_key="Huang2023-wi",
    param_size="87.8M",
    encode_dim=512,
    flops="8.73G",
)
class PLIP(ImageTextModel):
    def __init__(self, model_path=None, token=None):
        warnings.warn(
            "As from v0.8.2, Normalization will not be applied to image embedding of PLIP model anymore."
            "A `normalize=True` argument is added to the `text_image_similarity` method."
            "If you only use the image embedding for text image similarity, you can safely ignore this warning.",
            stacklevel=find_stack_level(),
        )
        try:
            from transformers import CLIPModel, CLIPProcessor
        except ImportError:
            raise ImportError(
                "Please install the 'transformers' package to use the PLIP model"
            )

        if model_path is None:
            model_path = "vinid/plip"

        with hf_access(model_path):
            self.model = CLIPModel.from_pretrained(model_path, token=token)
            self.model.eval()
            self.processor = CLIPProcessor.from_pretrained(model_path, token=token)

    def get_transform(self):
        return None

    @torch.inference_mode()
    def encode_image_dense(self, image):
        inputs = self.processor(images=image, return_tensors="pt")
        inputs = {k: v.to(self.model.device) for k, v in inputs.items()}
        hidden = self.model.vision_model(
            pixel_values=inputs["pixel_values"]
        ).last_hidden_state
        return DenseTokens(cls_token=hidden[:, 0], patch_tokens=hidden[:, 1:])

    @torch.inference_mode()
    def encode_image(self, image):
        inputs = self.processor(images=image, return_tensors="pt")
        inputs = {k: v.to(self.model.device) for k, v in inputs.items()}
        vision_out = self.model.vision_model(pixel_values=inputs["pixel_values"])
        pooled = vision_out.pooler_output
        return self.model.visual_projection(pooled)

    @torch.inference_mode()
    def encode_text(self, text):
        inputs = self.processor(
            text=text,
            return_tensors="pt",
            max_length=77,
            padding="max_length",
            truncation=True,
        )
        inputs = {k: v.to(self.model.device) for k, v in inputs.items()}
        text_out = self.model.text_model(
            input_ids=inputs["input_ids"],
            attention_mask=inputs["attention_mask"],
        )
        pooled = text_out.pooler_output
        text_features = self.model.text_projection(pooled)
        text_features = torch.nn.functional.normalize(text_features, p=2, dim=-1)
        return text_features
