import torch

from lazyslide_models._model_registry import register
from lazyslide_models._utils import hf_access
from lazyslide_models.base import ImageTextModel, ModelTask


@register(
    key="medsiglip",
    is_gated=True,
    task=ModelTask.multimodal,
    license="health-ai-developer-foundations",
    license_url="https://developers.google.com/health-ai-developer-foundations/terms",
    description="MedSigLip is a variant of SigLip from Google for medical image analysis.",
    commercial=False,
    hf_url="https://huggingface.co/google/medsiglip-448",
    github_url="https://github.com/google-health/medsiglip",
    paper_url="https://arxiv.org/abs/2507.05201",
    bib_key="Sellergren2025-qq",
    encode_dim=1152,
    param_size="878M",
    input_size=448,
)
class MedSigLip(ImageTextModel):
    def __init__(self, model_path=None, token=None):
        try:
            from transformers import AutoModel, AutoProcessor
        except ModuleNotFoundError:
            raise ModuleNotFoundError(
                "To run MedSigLip model, 'transformers' must be installed, try "
                "`pip install transformers`."
            )

        with hf_access("google/medsiglip-448"):
            self.model = AutoModel.from_pretrained("google/medsiglip-448")
            self.processor = AutoProcessor.from_pretrained("google/medsiglip-448")
            self.model.eval()

    def get_transform(self):
        from torchvision.transforms.v2 import Compose, Resize, ToDtype, ToImage

        return Compose([ToImage(), Resize(448), ToDtype(torch.float32, scale=False)])

    @torch.inference_mode()
    def encode_image(self, image):
        inputs = self.processor(images=image, padding="max_length", return_tensors="pt")
        inputs = {k: v.to(self.model.device) for k, v in inputs.items()}
        vision_out = self.model.vision_model(pixel_values=inputs["pixel_values"])
        return vision_out.pooler_output

    @torch.inference_mode()
    def encode_text(self, text):
        inputs = self.processor(text=text, padding="max_length", return_tensors="pt")
        inputs = {k: v.to(self.model.device) for k, v in inputs.items()}
        text_out = self.model.text_model(
            input_ids=inputs["input_ids"],
            attention_mask=inputs.get("attention_mask"),
        )
        text_features = text_out.pooler_output
        text_features = torch.nn.functional.normalize(text_features, p=2, dim=-1)
        return text_features
