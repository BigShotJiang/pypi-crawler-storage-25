import torch

from lazyslide_models._model_registry import register
from lazyslide_models.base import ModelTask, TimmViTModel


@register(
    key="virchow",
    is_gated=True,
    task=ModelTask.vision,
    license="Apache 2.0",
    description="A foundation model for clinical-grade computational pathology and rare cancers detection",
    commercial=True,
    hf_url="https://huggingface.co/paige-ai/Virchow",
    paper_url="https://doi.org/10.1038/s41591-024-03141-0",
    bib_key="Vorontsov2024-di",
    param_size="631.2M",
    encode_dim=2560,
    flops="323.93G",
)
class Virchow(TimmViTModel):
    _hf_hub_id = "paige-ai/Virchow"

    def __init__(self, model_path=None, token=None):
        from timm.layers import SwiGLUPacked

        super().__init__(
            f"hf-hub:{self._hf_hub_id}",
            pretrained=True,
            mlp_layer=SwiGLUPacked,
            act_layer=torch.nn.SiLU,
            token=token,
        )

    @torch.inference_mode()
    def encode_image(self, img):
        dense = self.encode_image_dense(img)
        return torch.cat((dense.cls_token, dense.patch_tokens.mean(1)), dim=-1)


@register(
    key="virchow2",
    is_gated=True,
    task=ModelTask.vision,
    description="Scaling self-supervised mixed magnification models in pathology",
    commercial=False,
    hf_url="https://huggingface.co/paige-ai/Virchow2",
    paper_url="https://doi.org/10.48550/arXiv.2408.00738",
    bib_key="Zimmermann2024-ya",
    param_size="631.2M",
    license="CC-BY-NC-ND-4.0",
    encode_dim=2560,
    flops="328.97G",
)
class Virchow2(Virchow):
    _hf_hub_id = "paige-ai/Virchow2"
