import torch

from lazyslide_models._model_registry import register
from lazyslide_models._utils import hf_access
from lazyslide_models.base import DenseTokens, ImageModel, ModelTask


@register(
    key="midnight",
    is_gated=True,
    task=ModelTask.vision,
    license="MIT",
    description="Training state-of-the-art pathology foundation models with orders of magnitude less data",
    commercial=True,
    hf_url="https://huggingface.co/kaiko-ai/midnight",
    github_url="https://github.com/kaiko-ai/midnight",
    paper_url="https://doi.org/10.48550/arXiv.2504.05186",
    bib_key="Karasikov2025-wp",
    param_size="1.14B",
    encode_dim=3072,
    flops="582.55G",
)
class Midnight(ImageModel):
    def __init__(self, model_path=None, token=None):
        try:
            from transformers import AutoModel
        except ImportError:
            raise ImportError(
                "transformers is not installed. You can install it using "
                "`pip install transformers`."
            )

        with hf_access("kaiko-ai/midnight"):
            self.model = AutoModel.from_pretrained("kaiko-ai/midnight")

        self.img_size = (224, 224)  # Trained in 518, 518
        self.patch_size = (14, 14)
        self.grid_size = (16, 16)
        self.num_prefix_tokens: int = 1

    def get_transform(self):
        from torchvision.transforms import v2

        return v2.Compose(
            [
                v2.ToImage(),
                v2.Resize(224),
                v2.CenterCrop(224),
                v2.ToDtype(dtype=torch.float32, scale=True),
                v2.Normalize(mean=(0.5, 0.5, 0.5), std=(0.5, 0.5, 0.5)),
            ]
        )

    @torch.inference_mode()
    def encode_image_dense(self, image):
        hidden = self.model(image).last_hidden_state
        return DenseTokens(
            cls_token=hidden[:, 0],
            patch_tokens=hidden[:, self.num_prefix_tokens :],
        )

    @torch.inference_mode()
    def encode_image(self, image):
        dense = self.encode_image_dense(image)
        return torch.cat([dense.cls_token, dense.patch_tokens.mean(dim=1)], dim=-1)
