import warnings
from typing import Literal

import torch

from lazyslide_models._model_registry import register
from lazyslide_models.base import ModelTask, SegmentationModel


@register(
    key="grandqc-artifact",
    task=ModelTask.segmentation,
    license="CC-BY-NC-SA-4.0",
    description="Artifact segmentation model from GrandQC",
    commercial=False,
    github_url="https://github.com/cpath-ukk/grandqc",
    paper_url="https://doi.org/10.1038/s41467-024-54769-y",
    bib_key="Weng2024-jf",
    param_size="6.3M",
    flops="4.63G",
)
class GrandQCArtifact(SegmentationModel):
    """
    The output classes are:

    - 0: Background
    - 1: Normal Tissue
    - 2: Fold
    - 3: Darkspot & Foreign Object
    - 4: PenMarking
    - 5: Edge & Air Bubble
    - 6: Out of Focus
    - 7: Background

    """

    CLASS_MAPPING = {
        0: "Background",
        1: "Normal Tissue",
        2: "Fold",
        3: "Darkspot & Foreign Object",
        4: "PenMarking",
        5: "Edge & Air Bubble",
        6: "Out of Focus",
        7: "Background",
    }

    def __init__(self, variant: Literal["5x", "7x", "10x"] = "7x"):
        from huggingface_hub import hf_hub_download

        weights_map = {
            "5x": "GrandQC_MPP2_exported.pt2",
            "7x": "GrandQC_MPP15_exported.pt2",
            "10x": "GrandQC_MPP1_exported.pt2",
        }
        model_file = hf_hub_download(
            "RendeiroLab/LazySlide-models",
            f"GrandQC/{weights_map[variant]}",
        )

        with warnings.catch_warnings():
            warnings.filterwarnings(
                "ignore", message="The given buffer is not writable"
            )
            self.model = torch.export.load(model_file).module()

    def get_transform(self):
        import torch
        from torchvision.transforms.v2 import (
            Compose,
            Normalize,
            ToDtype,
            ToImage,
        )

        return Compose(
            [
                ToImage(),
                ToDtype(dtype=torch.float32, scale=True),
                Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
            ]
        )

    @torch.inference_mode()
    def segment(self, image):
        out = self.model(image)
        return {"probability_map": out}

    def supported_outputs(self):
        return ("probability_map",)


@register(
    key="grandqc-tissue",
    task=ModelTask.segmentation,
    license="CC-BY-NC-SA-4.0",
    description="Tissue segmentation model from GrandQC",
    commercial=False,
    github_url="https://github.com/cpath-ukk/grandqc",
    paper_url="https://doi.org/10.1038/s41467-024-54769-y",
    bib_key="Weng2024-jf",
    param_size="6.6M",
    flops="8.46G",
)
class GrandQCTissue(
    SegmentationModel,
):
    CLASS_MAPPING = {
        0: "Background",
        1: "Tissue",
    }

    def __init__(self):
        from huggingface_hub import hf_hub_download

        model_file = hf_hub_download(
            "RendeiroLab/LazySlide-models",
            "GrandQC/GrandQC_tissue_seg_exported.pt2",
        )

        with warnings.catch_warnings():
            warnings.filterwarnings(
                "ignore", message="The given buffer is not writable"
            )
            self.model = torch.export.load(model_file).module()

    @torch.inference_mode()
    def segment(self, image):
        return {"probability_map": self.model(image).softmax(dim=1)}

    def supported_outputs(self):
        return ("probability_map",)
