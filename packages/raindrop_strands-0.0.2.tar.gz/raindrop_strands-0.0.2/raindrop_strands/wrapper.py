"""
Strands Agents integration for Raindrop observability.

Wraps Strands Agents via the hook system to automatically capture agent
invocations, model calls, tool usage, and token metrics, then ships them
to the Raindrop API.

Usage::

    from raindrop_strands import RaindropStrands

    raindrop = RaindropStrands(api_key="rk_...")
    agent = Agent(model=model)
    raindrop.handler.register_hooks(agent)
    agent("Hello!")
    raindrop.flush()

IMPORTANT: Every handler method MUST be wrapped in try/except.
Telemetry must NEVER crash the user's pipeline.
"""

from __future__ import annotations

import json
import logging
import time
import uuid
import warnings
from typing import TYPE_CHECKING, Dict, Literal, Optional, Set, Union

import raindrop.analytics as raindrop

if TYPE_CHECKING:
    from raindrop.interaction import Interaction
    from strands.hooks.events import (
        AfterInvocationEvent,
        AfterModelCallEvent,
        AfterToolCallEvent,
        BeforeInvocationEvent,
        BeforeModelCallEvent,
        BeforeToolCallEvent,
    )

logger = logging.getLogger("raindrop_strands")


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _safe_serialize(value: object) -> str:
    """Safely serialize *value* to a JSON string, falling back to ``str()``.

    This must never raise so that callers can use it in telemetry paths
    without risk of crashing the user's pipeline.
    """
    try:
        return json.dumps(value)
    except Exception:
        logger.debug("Failed to JSON-serialize value", exc_info=True)
        return str(value)


def _extract_text_from_message(message: object) -> Optional[str]:
    """Extract concatenated text from a Strands ``Message`` dict.

    A Strands message is a ``TypedDict`` with a ``content`` list whose
    items are content-block dicts.  Text blocks have a ``"text"`` key.
    Non-text blocks (tool-use, images, etc.) are silently skipped.

    Returns ``None`` when no text can be extracted.
    """
    try:
        content = message.get("content") if isinstance(message, dict) else None
        if not content or not isinstance(content, list):
            return None

        text_parts: list[str] = []
        for block in content:
            if block is None:
                continue
            if isinstance(block, str):
                text_parts.append(block)
            elif isinstance(block, dict) and "text" in block:
                text = block["text"]
                if isinstance(text, str):
                    text_parts.append(text)
        return "\n".join(text_parts) if text_parts else None
    except Exception:
        logger.debug("Failed to extract text from message", exc_info=True)
        return None


def _extract_user_input(messages: object) -> Optional[str]:
    """Return the text of the last user message in *messages*.

    Falls back to the very last message (regardless of role) when no
    ``"user"`` message is found.  Returns ``None`` for empty or invalid
    input.
    """
    try:
        if not messages or not isinstance(messages, list):
            return None

        for msg in reversed(messages):
            if not isinstance(msg, dict):
                continue
            if msg.get("role") != "user":
                continue
            text = _extract_text_from_message(msg)
            if text:
                return text

        # Fallback: try the last message regardless of role
        if messages:
            last_msg = messages[-1]
            if isinstance(last_msg, dict):
                return _extract_text_from_message(last_msg)

        return None
    except Exception:
        logger.debug("Failed to extract user input", exc_info=True)
        return None


def _extract_token_count(container: object, key: str) -> Optional[int]:
    """Extract an integer token count from a dict-or-object *container*.

    Supports both ``TypedDict``-style ``container[key]`` access and
    attribute access (``container.key``).  Returns ``None`` when the key
    is missing or the value is ``None``.
    """
    try:
        if isinstance(container, dict):
            value = container.get(key)
        else:
            value = getattr(container, key, None)
        if value is not None:
            return int(value)
    except Exception:
        logger.debug("Failed to extract token count for key %s", key, exc_info=True)
    return None


def _build_token_properties(
    prompt_tokens: Optional[int],
    completion_tokens: Optional[int],
    cached_tokens: Optional[int] = None,
) -> Optional[Dict[str, int]]:
    """Build the ``ai.usage.*`` properties dict from token counts.

    Returns ``None`` when all counts are ``None`` so that callers can
    skip sending an empty properties payload.
    """
    if prompt_tokens is None and completion_tokens is None and cached_tokens is None:
        return None
    props: Dict[str, int] = {}
    if prompt_tokens is not None:
        props["ai.usage.prompt_tokens"] = prompt_tokens
    if completion_tokens is not None:
        props["ai.usage.completion_tokens"] = completion_tokens
    if cached_tokens is not None:
        props["ai.usage.cached_tokens"] = cached_tokens
    return props


# ---------------------------------------------------------------------------
# Internal invocation context
# ---------------------------------------------------------------------------


class _InvocationContext:
    """Mutable bag of state tracked for one agent invocation."""

    __slots__ = (
        "event_id",
        "input",
        "output",
        "model",
        "prompt_tokens",
        "completion_tokens",
        "cached_tokens",
        "tool_use_ids",
        "error_type",
        "error_message",
        "finish_reason",
        "interaction",
    )

    def __init__(self, event_id: str, input_text: Optional[str]) -> None:
        self.event_id: str = event_id
        self.input: Optional[str] = input_text
        self.output: Optional[str] = None
        self.model: Optional[str] = None
        self.prompt_tokens: Optional[int] = None
        self.completion_tokens: Optional[int] = None
        self.cached_tokens: Optional[int] = None
        self.tool_use_ids: Set[str] = set()
        self.error_type: Optional[str] = None
        self.error_message: Optional[str] = None
        self.finish_reason: Optional[str] = None
        self.interaction: Optional["Interaction"] = None

    def build_properties(self) -> Optional[Dict[str, Union[str, int]]]:
        """Build the event properties dict from accumulated context.

        Returns ``None`` when no properties have been collected.
        """
        props: Dict[str, Union[str, int]] = {}
        token_props = _build_token_properties(
            self.prompt_tokens, self.completion_tokens, self.cached_tokens
        )
        if token_props:
            props.update(token_props)
        if self.error_type is not None:
            props["error.type"] = self.error_type
        if self.error_message is not None:
            props["error.message"] = self.error_message
        if self.finish_reason is not None:
            props["strands.finish_reason"] = self.finish_reason
        return props if props else None


# ---------------------------------------------------------------------------
# Tool-span context
# ---------------------------------------------------------------------------


class _ToolSpanContext:
    """Mutable bag of state tracked for one tool call span."""

    __slots__ = ("name", "input", "start_time_ns")

    def __init__(self, name: Optional[str], input_serialized: Optional[str]) -> None:
        self.name: Optional[str] = name
        self.input: Optional[str] = input_serialized
        self.start_time_ns: int = time.monotonic_ns()


# ---------------------------------------------------------------------------
# RaindropEventHandler — the Strands hook handler
# ---------------------------------------------------------------------------


class RaindropEventHandler:
    """Strands Agents hook handler that ships events to Raindrop.

    This is an internal implementation detail.  Users should interact with
    the :class:`RaindropStrands` wrapper class instead.
    """

    def __init__(
        self,
        user_id: Optional[str] = None,
        convo_id: Optional[str] = None,
    ) -> None:
        self._user_id: Optional[str] = user_id
        self._convo_id: Optional[str] = convo_id

        # Map id(agent) -> invocation context.
        # Cleaned up explicitly in on_after_invocation to prevent leaks.
        self._invocations: Dict[int, _InvocationContext] = {}
        # toolUseId -> span context for active tool calls
        self._tool_spans: Dict[str, _ToolSpanContext] = {}

        # Tracking counters for memory leak detection in tests
        self._active_invocations: int = 0
        self._active_tool_spans: int = 0

    def register_hooks(self, agent: object) -> None:
        """Register all Raindrop hook callbacks on a Strands agent.

        Args:
            agent: A Strands ``Agent`` instance with an ``add_hook`` method.
        """
        try:
            from strands.hooks.events import (
                AfterInvocationEvent,
                AfterModelCallEvent,
                AfterToolCallEvent,
                BeforeInvocationEvent,
                BeforeModelCallEvent,
                BeforeToolCallEvent,
            )

            add_hook = getattr(agent, "add_hook")
            add_hook(self.on_before_invocation, BeforeInvocationEvent)
            add_hook(self.on_after_invocation, AfterInvocationEvent)
            add_hook(self.on_before_model_call, BeforeModelCallEvent)
            add_hook(self.on_after_model_call, AfterModelCallEvent)
            add_hook(self.on_before_tool_call, BeforeToolCallEvent)
            add_hook(self.on_after_tool_call, AfterToolCallEvent)
        except Exception:
            logger.debug("Failed to register hooks", exc_info=True)

    # --- Hook callback methods ---

    def on_before_invocation(
        self, event: BeforeInvocationEvent, **kwargs: object
    ) -> None:
        """Called before an agent invocation starts."""
        try:
            agent = event.agent
            event_id = str(uuid.uuid4())

            messages = getattr(agent, "messages", None)
            input_text = _extract_user_input(messages)

            ctx = _InvocationContext(event_id=event_id, input_text=input_text)

            # Begin an interaction for tool span tracking
            try:
                interaction = raindrop.begin(
                    user_id=self._user_id or "unknown",
                    event="ai_generation",
                    event_id=event_id,
                    input=input_text,
                    convo_id=self._convo_id,
                )
                ctx.interaction = interaction
            except Exception:
                logger.debug("Failed to begin interaction", exc_info=True)

            self._invocations[id(agent)] = ctx
            self._active_invocations += 1
        except Exception:
            logger.debug("on_before_invocation failed", exc_info=True)

    def on_after_invocation(
        self, event: AfterInvocationEvent, **kwargs: object
    ) -> None:
        """Called after an agent invocation completes."""
        try:
            agent = event.agent
            ctx = self._invocations.get(id(agent))
            if not ctx:
                return

            # Extract output from the result if available
            result = getattr(event, "result", None)
            if result is not None:
                message = getattr(result, "message", None)
                if message is not None:
                    output = _extract_text_from_message(message)
                    if output:
                        ctx.output = output

                # Extract token usage from metrics
                metrics = getattr(result, "metrics", None)
                if metrics is not None:
                    accumulated = getattr(metrics, "accumulated_usage", None)
                    if accumulated is not None:
                        input_tokens = _extract_token_count(
                            accumulated, "inputTokens"
                        )
                        output_tokens = _extract_token_count(
                            accumulated, "outputTokens"
                        )
                        # Cached tokens: prefer cacheReadInputTokens,
                        # fall back to cacheCreationInputTokens
                        cached = _extract_token_count(
                            accumulated, "cacheReadInputTokens"
                        )
                        if cached is None:
                            cached = _extract_token_count(
                                accumulated, "cacheCreationInputTokens"
                            )
                        if input_tokens is not None:
                            ctx.prompt_tokens = input_tokens
                        if output_tokens is not None:
                            ctx.completion_tokens = output_tokens
                        if cached is not None:
                            ctx.cached_tokens = cached

            properties = ctx.build_properties()

            if ctx.interaction is not None:
                # Use the interaction lifecycle (begin → partial → finish)
                # following the pattern established by the agno integration.
                # This avoids duplicate events from calling both track_ai()
                # and begin()/finish() for the same event_id.
                partial_ok = False
                if ctx.model:
                    try:
                        raindrop._track_ai_partial(
                            raindrop.PartialTrackAIEvent(
                                event_id=ctx.event_id,
                                ai_data={"model": ctx.model},
                            )
                        )
                        partial_ok = True
                    except Exception:
                        logger.debug(
                            "Failed to send partial AI data", exc_info=True
                        )

                # If partial failed, include model in properties so
                # finish() still carries the model name.
                finish_props = properties
                if ctx.model and not partial_ok:
                    finish_props = dict(properties) if properties else {}
                    finish_props["ai.model"] = ctx.model

                try:
                    ctx.interaction.finish(
                        output=ctx.output,
                        properties=finish_props if finish_props else None,
                    )
                except Exception:
                    logger.debug(
                        "Failed to finish interaction, falling back to track_ai",
                        exc_info=True,
                    )
                    # Fallback: finish() failed, try single-shot track_ai
                    # so the event data is not silently lost.
                    try:
                        raindrop.track_ai(
                            user_id=self._user_id or "unknown",
                            event="ai_generation",
                            event_id=ctx.event_id,
                            input=ctx.input,
                            output=ctx.output,
                            model=ctx.model,
                            convo_id=self._convo_id,
                            properties=properties if properties else None,
                        )
                    except Exception:
                        logger.debug(
                            "track_ai fallback also failed", exc_info=True
                        )
                # Mark as finished so the finally block won't double-finish
                ctx.interaction = None
            else:
                # Fallback: begin() failed earlier, use single-shot track_ai
                try:
                    raindrop.track_ai(
                        user_id=self._user_id or "unknown",
                        event="ai_generation",
                        event_id=ctx.event_id,
                        input=ctx.input,
                        output=ctx.output,
                        model=ctx.model,
                        convo_id=self._convo_id,
                        properties=properties if properties else None,
                    )
                except Exception:
                    logger.debug(
                        "track_ai fallback failed", exc_info=True
                    )
        except Exception:
            logger.debug("on_after_invocation failed", exc_info=True)
        finally:
            try:
                agent = event.agent
                ctx = self._invocations.get(id(agent))
                if ctx is not None:
                    # Finish the interaction if it wasn't already finished
                    # above (e.g. if the try block failed partway through).
                    # Pass whatever data ctx has accumulated so we don't
                    # silently discard available telemetry.
                    if ctx.interaction is not None:
                        try:
                            ctx.interaction.finish(
                                output=ctx.output,
                                properties=ctx.build_properties(),
                            )
                        except Exception:
                            logger.debug(
                                "Failed to finish interaction in safety net",
                                exc_info=True,
                            )
                    self._invocations.pop(id(agent), None)
                    self._active_invocations = max(0, self._active_invocations - 1)
                    # Clean up any orphaned tool spans owned by this invocation
                    for tool_id in ctx.tool_use_ids:
                        if self._tool_spans.pop(tool_id, None) is not None:
                            self._active_tool_spans = max(
                                0, self._active_tool_spans - 1
                            )
            except Exception:
                logger.debug(
                    "on_after_invocation cleanup failed", exc_info=True
                )

    def on_before_model_call(
        self, event: BeforeModelCallEvent, **kwargs: object
    ) -> None:
        """Called before a model call within an invocation."""
        try:
            # No span-based tracing in Python SDK; model call data is
            # captured in on_after_model_call and attached to the invocation.
            pass
        except Exception:
            logger.debug("on_before_model_call failed", exc_info=True)

    def on_after_model_call(
        self, event: AfterModelCallEvent, **kwargs: object
    ) -> None:
        """Called after a model call completes."""
        try:
            agent = event.agent
            ctx = self._invocations.get(id(agent))
            if not ctx:
                return

            # Reset per-model-call fields so stale data from a previous
            # call within the same invocation never leaks through.
            ctx.finish_reason = None
            ctx.cached_tokens = None
            ctx.error_type = None
            ctx.error_message = None

            # Extract output from stop response
            stop_response = getattr(event, "stop_response", None)
            if stop_response is not None:
                message = getattr(stop_response, "message", None)
                if message is not None:
                    output = _extract_text_from_message(message)
                    if output:
                        ctx.output = output

                # Extract usage from stop response
                usage = getattr(stop_response, "usage", None)
                if usage is not None:
                    input_tokens = _extract_token_count(usage, "inputTokens")
                    output_tokens = _extract_token_count(usage, "outputTokens")
                    if input_tokens is not None:
                        ctx.prompt_tokens = input_tokens
                    if output_tokens is not None:
                        ctx.completion_tokens = output_tokens

                    # Cached tokens: prefer cacheReadInputTokens,
                    # fall back to cacheCreationInputTokens
                    cached = _extract_token_count(
                        usage, "cacheReadInputTokens"
                    )
                    if cached is None:
                        cached = _extract_token_count(
                            usage, "cacheCreationInputTokens"
                        )
                    if cached is not None:
                        ctx.cached_tokens = cached

                # Extract model name
                model_id = getattr(stop_response, "model", None)
                if model_id is not None:
                    ctx.model = str(model_id)

                # Extract finish reason (stop_reason takes precedence)
                finish_reason = getattr(stop_response, "stop_reason", None)
                if finish_reason is None:
                    finish_reason = getattr(stop_response, "finish_reason", None)
                if finish_reason is not None:
                    ctx.finish_reason = str(finish_reason)

            # Capture error information if present, clearing stale data
            # from previous model calls within the same invocation
            error = getattr(event, "error", None)
            if error is None:
                error = getattr(event, "exception", None)
            if error is not None:
                ctx.error_type = type(error).__name__
                ctx.error_message = str(error)[:500]
        except Exception:
            logger.debug("on_after_model_call failed", exc_info=True)

    def on_before_tool_call(
        self, event: BeforeToolCallEvent, **kwargs: object
    ) -> None:
        """Called before a tool call within an invocation."""
        try:
            agent = getattr(event, "agent", None)
            if agent is None:
                return
            ctx = self._invocations.get(id(agent))
            if not ctx:
                return

            tool_use = getattr(event, "tool_use", None)
            if tool_use is None:
                return

            tool_use_id = (
                tool_use.get("toolUseId")
                if isinstance(tool_use, dict)
                else getattr(tool_use, "toolUseId", None)
            )
            tool_name = (
                tool_use.get("name")
                if isinstance(tool_use, dict)
                else getattr(tool_use, "name", None)
            )
            tool_input = (
                tool_use.get("input")
                if isinstance(tool_use, dict)
                else getattr(tool_use, "input", None)
            )

            if tool_use_id:
                tid = str(tool_use_id)
                self._tool_spans[tid] = _ToolSpanContext(
                    name=tool_name,
                    input_serialized=(
                        _safe_serialize(tool_input)
                        if tool_input is not None
                        else None
                    ),
                )
                ctx.tool_use_ids.add(tid)
                self._active_tool_spans += 1
        except Exception:
            logger.debug("on_before_tool_call failed", exc_info=True)

    def on_after_tool_call(
        self, event: AfterToolCallEvent, **kwargs: object
    ) -> None:
        """Called after a tool call completes."""
        try:
            tool_use = getattr(event, "tool_use", None)
            if tool_use is None:
                return

            tool_use_id = (
                tool_use.get("toolUseId")
                if isinstance(tool_use, dict)
                else getattr(tool_use, "toolUseId", None)
            )
            if tool_use_id:
                tid = str(tool_use_id)
                span = self._tool_spans.pop(tid, None)

                # Resolve agent and invocation context once for both
                # tool-span tracking and cleanup.
                agent = getattr(event, "agent", None)
                ctx = (
                    self._invocations.get(id(agent))
                    if agent is not None
                    else None
                )

                if span is not None:
                    self._active_tool_spans = max(0, self._active_tool_spans - 1)

                    # Track tool span via interaction API
                    if ctx is not None and ctx.interaction is not None:
                        try:
                            # Calculate duration
                            duration_ms = (
                                time.monotonic_ns() - span.start_time_ns
                            ) / 1_000_000

                            # Extract tool output
                            tool_output = None
                            tool_result = getattr(event, "tool_result", None)
                            if tool_result is None:
                                tool_result = getattr(event, "result", None)
                            if tool_result is not None:
                                tool_output = _safe_serialize(tool_result)

                            # Extract error if present
                            tool_error: Optional[BaseException] = None
                            exc = getattr(event, "error", None)
                            if exc is None:
                                exc = getattr(event, "exception", None)
                            if exc is not None:
                                if isinstance(exc, BaseException):
                                    tool_error = exc
                                else:
                                    tool_error = RuntimeError(str(exc))

                            ctx.interaction.track_tool(
                                name=span.name or "unknown",
                                input=span.input,
                                output=tool_output,
                                duration_ms=duration_ms,
                                error=tool_error,
                            )
                        except Exception:
                            logger.debug(
                                "Failed to track tool span",
                                exc_info=True,
                            )

                # Also remove from invocation's tracked set
                if ctx is not None:
                    ctx.tool_use_ids.discard(tid)
        except Exception:
            logger.debug("on_after_tool_call failed", exc_info=True)

    @property
    def _map_sizes(self) -> Dict[str, int]:
        """Get the current sizes of internal tracking maps (for testing)."""
        return {
            "invocations": self._active_invocations,
            "tool_spans": self._active_tool_spans,
        }


# ---------------------------------------------------------------------------
# RaindropStrands — public wrapper class
# ---------------------------------------------------------------------------


class RaindropStrands:
    """Top-level Raindrop integration for Strands Agents.

    Wraps the internal :class:`RaindropEventHandler` and provides a
    convenient interface for configuring Raindrop telemetry, registering
    hooks on agents, and managing the telemetry lifecycle.

    Args:
        api_key: Raindrop API key (``rk_...``).  Omit to disable telemetry
            shipping (a warning is emitted).
        user_id: Associate all events with this user.
        convo_id: Conversation / session ID to group related events.
        tracing_enabled: Enable OTEL-based tracing (default ``True``).
        bypass_otel_for_tools: Bypass OTEL for tool spans (default ``True``).
        debug: Enable debug logging when ``True``.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        user_id: Optional[str] = None,
        convo_id: Optional[str] = None,
        tracing_enabled: bool = True,
        bypass_otel_for_tools: bool = True,
        debug: bool = False,
    ) -> None:
        if not api_key:
            warnings.warn(
                "[raindrop-strands] api_key not provided; "
                "telemetry shipping is disabled",
                stacklevel=2,
            )

        if debug:
            logger.setLevel(logging.DEBUG)

        raindrop.init(
            api_key=api_key or "",
            tracing_enabled=tracing_enabled,
            bypass_otel_for_tools=bypass_otel_for_tools,
        )

        self._handler = RaindropEventHandler(
            user_id=user_id,
            convo_id=convo_id,
        )

    @property
    def handler(self) -> RaindropEventHandler:
        """Return the :class:`RaindropEventHandler` for passing to an Agent.

        Example::

            agent = Agent(model=model)
            raindrop.handler.register_hooks(agent)
        """
        return self._handler

    def flush(self) -> None:
        """Flush any pending telemetry events to Raindrop."""
        try:
            raindrop.flush()
        except Exception:
            logger.debug("Failed to flush events", exc_info=True)

    def shutdown(self) -> None:
        """Flush pending events and release resources."""
        try:
            raindrop.shutdown()
        except Exception:
            logger.debug("Failed to shutdown", exc_info=True)

    def identify(
        self,
        user_id: str,
        traits: Optional[Dict[str, Union[str, int, bool, float]]] = None,
    ) -> None:
        """Identify a user with optional traits.

        Args:
            user_id: The user identifier.
            traits: Optional dictionary of user traits.
        """
        try:
            raindrop.identify(user_id=user_id, traits=traits or {})
        except Exception:
            logger.debug("Failed to identify user", exc_info=True)

    def track_signal(
        self,
        event_id: str,
        name: str,
        signal_type: Literal["default", "feedback", "edit"] = "default",
        *,
        timestamp: Optional[str] = None,
        properties: Optional[Dict[str, object]] = None,
        attachment_id: Optional[str] = None,
        comment: Optional[str] = None,
        after: Optional[str] = None,
        sentiment: Optional[Literal["POSITIVE", "NEGATIVE"]] = None,
    ) -> None:
        """Track a signal event.

        Args:
            event_id: The event ID to associate the signal with.
            name: Signal name.
            signal_type: One of ``"default"``, ``"feedback"``, or ``"edit"``.
            timestamp: Optional ISO-8601 timestamp string.
            properties: Optional extra properties dict.
            attachment_id: Optional attachment identifier.
            comment: Optional comment text.
            after: Optional "after" value for edit signals.
            sentiment: Optional sentiment (``"POSITIVE"`` or ``"NEGATIVE"``).
        """
        try:
            raindrop.track_signal(
                event_id=event_id,
                name=name,
                signal_type=signal_type,
                timestamp=timestamp,
                properties=properties,
                attachment_id=attachment_id,
                comment=comment,
                after=after,
                sentiment=sentiment,
            )
        except Exception:
            logger.debug("Failed to track signal", exc_info=True)


# ---------------------------------------------------------------------------
# Factory function (backward-compatible)
# ---------------------------------------------------------------------------


def create_raindrop_strands(
    api_key: Optional[str] = None,
    user_id: Optional[str] = None,
    convo_id: Optional[str] = None,
    tracing_enabled: bool = True,
    bypass_otel_for_tools: bool = True,
    debug: bool = False,
) -> RaindropStrands:
    """Create a Raindrop-instrumented Strands Agents integration.

    This is a convenience factory that returns a :class:`RaindropStrands`
    instance.

    Args:
        api_key: Raindrop API key (``rk_...``).  Omit to disable telemetry
            shipping.
        user_id: Associate all events with this user.
        convo_id: Conversation ID to group related events.
        tracing_enabled: Enable OTEL-based tracing (default ``True``).
        bypass_otel_for_tools: Bypass OTEL for tool spans (default ``True``).
        debug: Enable debug logging when ``True``.

    Returns:
        A :class:`RaindropStrands` instance with ``handler``, ``flush()``,
        ``shutdown()``, ``identify()``, and ``track_signal()`` methods.

    Usage::

        from raindrop_strands import create_raindrop_strands

        raindrop = create_raindrop_strands(api_key="rk_...")
        agent = Agent(model=model)
        raindrop.handler.register_hooks(agent)
        agent("Hello!")
        raindrop.flush()
    """
    try:
        return RaindropStrands(
            api_key=api_key,
            user_id=user_id,
            convo_id=convo_id,
            tracing_enabled=tracing_enabled,
            bypass_otel_for_tools=bypass_otel_for_tools,
            debug=debug,
        )
    except Exception:
        logger.debug("Failed to create RaindropStrands", exc_info=True)
        try:
            return RaindropStrands(api_key="")
        except Exception:
            logger.debug("Failed to create fallback RaindropStrands", exc_info=True)
            # Last resort: construct without calling __init__ so we never crash.
            # raindrop.init() is skipped — every telemetry call will fail
            # silently (each is wrapped in try/except).  Emit a warning so
            # the user knows telemetry is completely disabled.
            warnings.warn(
                "[raindrop-strands] Failed to initialize; "
                "telemetry is fully disabled for this instance",
                stacklevel=2,
            )
            instance = object.__new__(RaindropStrands)
            instance._handler = RaindropEventHandler()
            return instance
