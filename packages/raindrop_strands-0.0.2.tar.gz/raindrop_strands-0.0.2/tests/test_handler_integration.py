"""Comprehensive end-to-end tests for the Strands Agents Python integration.

Simulates realistic agent lifecycles:
- Full agentic loop: model call → tool calls → model call → finalization
- Multiple sequential tool calls in a single invocation
- Concurrent agents on a shared handler
- Orphaned tool spans on invocation abort
- Model name extraction from stop_response
- Token usage from both model call and accumulated metrics
- Error resilience with malformed events
- Optional api_key (disabled mode)
"""

from unittest.mock import MagicMock, patch
from types import SimpleNamespace

MODULE_PATH = "raindrop_strands.wrapper.raindrop"


def _make_client(mock_raindrop, **kwargs):
    from raindrop_strands.wrapper import RaindropStrands
    return RaindropStrands(api_key="test-key", **kwargs)


def _fake_agent(messages=None, **extra):
    agent = SimpleNamespace()
    agent.messages = messages or []
    agent.add_hook = MagicMock()
    for k, v in extra.items():
        setattr(agent, k, v)
    return agent


def _before_invocation_event(agent):
    return SimpleNamespace(agent=agent)


def _after_invocation_event(agent, result=None):
    return SimpleNamespace(agent=agent, result=result)


def _before_model_call_event(agent):
    return SimpleNamespace(agent=agent)


def _after_model_call_event(agent, stop_response=None):
    return SimpleNamespace(agent=agent, stop_response=stop_response)


def _before_tool_call_event(agent, tool_use):
    return SimpleNamespace(agent=agent, tool_use=tool_use)


def _after_tool_call_event(agent, tool_use, result):
    return SimpleNamespace(agent=agent, tool_use=tool_use, result=result)


def _agent_result(message=None, metrics=None):
    return SimpleNamespace(message=message, metrics=metrics)


def _metrics(input_tokens=None, output_tokens=None):
    usage = {"inputTokens": input_tokens, "outputTokens": output_tokens}
    return SimpleNamespace(accumulated_usage=usage)


class TestFullAgenticLoop:
    """Simulates a realistic agent lifecycle: model → tools → model → result."""

    def test_model_tool_model_result_lifecycle(self):
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction
            handler = _make_client(mock_rd, user_id="e2e-user", convo_id="sess-1").handler
            agent = _fake_agent([
                {"role": "user", "content": [{"text": "What's the weather in SF?"}]}
            ])

            handler.on_before_invocation(_before_invocation_event(agent))

            # First model call
            handler.on_before_model_call(_before_model_call_event(agent))
            handler.on_after_model_call(_after_model_call_event(agent, stop_response=SimpleNamespace(
                message={"role": "assistant", "content": [{"text": "Let me check..."}]},
                usage={"inputTokens": 50, "outputTokens": 15},
                model="us.amazon.nova-lite-v1:0",
            )))

            # Tool call
            tool_use = {"toolUseId": "wu-1", "name": "get_weather", "input": {"city": "SF"}}
            handler.on_before_tool_call(_before_tool_call_event(agent, tool_use))
            result = SimpleNamespace(content=[{"text": '{"temp":62}'}], status="success")
            handler.on_after_tool_call(_after_tool_call_event(agent, tool_use, result))

            # Second model call with final output
            handler.on_before_model_call(_before_model_call_event(agent))
            handler.on_after_model_call(_after_model_call_event(agent, stop_response=SimpleNamespace(
                message={"role": "assistant", "content": [{"text": "It's 62°F in SF."}]},
                usage={"inputTokens": 120, "outputTokens": 30},
                model="us.amazon.nova-lite-v1:0",
            )))

            # Finalize
            handler.on_after_invocation(_after_invocation_event(agent))

            mock_interaction.finish.assert_called_once()
            fkw = mock_interaction.finish.call_args[1]
            assert fkw["output"] == "It's 62°F in SF."
            assert fkw["properties"]["ai.usage.prompt_tokens"] == 120
            assert fkw["properties"]["ai.usage.completion_tokens"] == 30
            bkw = mock_rd.begin.call_args[1]
            assert bkw["user_id"] == "e2e-user"
            assert bkw["convo_id"] == "sess-1"
            assert bkw["input"] == "What's the weather in SF?"
            mock_rd._track_ai_partial.assert_called_once()
            mock_rd.track_ai.assert_not_called()


class TestMultipleSequentialToolCalls:
    """Multiple tool calls within a single invocation."""

    def test_three_sequential_tools_all_tracked(self):
        with patch(MODULE_PATH) as mock_rd:
            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "Plan trip"}]}])

            handler.on_before_invocation(_before_invocation_event(agent))

            tools = [
                {"toolUseId": "t-1", "name": "search_flights", "input": {"from": "SFO"}},
                {"toolUseId": "t-2", "name": "search_hotels", "input": {"city": "NYC"}},
                {"toolUseId": "t-3", "name": "get_forecast", "input": {"days": 5}},
            ]

            for tool in tools:
                handler.on_before_tool_call(_before_tool_call_event(agent, tool))
                assert handler._active_tool_spans >= 1
                result = SimpleNamespace(content=[{"text": f"Result for {tool['name']}"}], status="success")
                handler.on_after_tool_call(_after_tool_call_event(agent, tool, result))

            assert handler._active_tool_spans == 0
            handler.on_after_invocation(_after_invocation_event(agent))
            assert handler._map_sizes == {"invocations": 0, "tool_spans": 0}


class TestConcurrentAgents:
    """Two agents sharing the same handler with overlapping invocations."""

    def test_concurrent_agents_isolated(self):
        with patch(MODULE_PATH) as mock_rd:
            mock_interactions = [MagicMock(), MagicMock()]
            mock_rd.begin.side_effect = mock_interactions
            handler = _make_client(mock_rd).handler

            agent_a = _fake_agent([{"role": "user", "content": [{"text": "Agent A"}]}])
            agent_b = _fake_agent([{"role": "user", "content": [{"text": "Agent B"}]}])

            handler.on_before_invocation(_before_invocation_event(agent_a))
            handler.on_before_invocation(_before_invocation_event(agent_b))
            assert handler._active_invocations == 2

            # Agent A tool
            tool_a = {"toolUseId": "a-t1", "name": "alpha", "input": {}}
            handler.on_before_tool_call(_before_tool_call_event(agent_a, tool_a))

            # Agent B tool
            tool_b = {"toolUseId": "b-t1", "name": "beta", "input": {}}
            handler.on_before_tool_call(_before_tool_call_event(agent_b, tool_b))
            assert handler._active_tool_spans == 2

            # B finishes first
            handler.on_after_tool_call(_after_tool_call_event(
                agent_b, tool_b, SimpleNamespace(content=[], status="success"),
            ))
            handler.on_after_invocation(_after_invocation_event(agent_b))
            assert handler._active_invocations == 1
            assert handler._active_tool_spans == 1  # A's tool still active

            # A finishes
            handler.on_after_tool_call(_after_tool_call_event(
                agent_a, tool_a, SimpleNamespace(content=[], status="success"),
            ))
            handler.on_after_invocation(_after_invocation_event(agent_a))
            assert handler._active_invocations == 0
            assert handler._active_tool_spans == 0

            assert mock_rd.begin.call_count == 2
            mock_interactions[0].finish.assert_called_once()
            mock_interactions[1].finish.assert_called_once()
            mock_rd.track_ai.assert_not_called()

    def test_concurrent_agents_events_have_distinct_event_ids(self):
        with patch(MODULE_PATH) as mock_rd:
            handler = _make_client(mock_rd).handler

            agent_a = _fake_agent([{"role": "user", "content": [{"text": "A"}]}])
            agent_b = _fake_agent([{"role": "user", "content": [{"text": "B"}]}])

            handler.on_before_invocation(_before_invocation_event(agent_a))
            handler.on_before_invocation(_before_invocation_event(agent_b))

            handler.on_after_invocation(_after_invocation_event(agent_a))
            handler.on_after_invocation(_after_invocation_event(agent_b))

            assert mock_rd.begin.call_count == 2
            event_ids = [c[1]["event_id"] for c in mock_rd.begin.call_args_list]
            assert event_ids[0] != event_ids[1]


class TestOrphanedToolSpans:
    """Tool spans started but never completed before invocation ends."""

    def test_orphaned_tool_spans_cleaned_up(self):
        with patch(MODULE_PATH) as mock_rd:
            handler = _make_client(mock_rd).handler
            agent = _fake_agent()

            handler.on_before_invocation(_before_invocation_event(agent))
            handler.on_before_tool_call(_before_tool_call_event(agent, {
                "toolUseId": "o-1", "name": "slow", "input": {},
            }))
            handler.on_before_tool_call(_before_tool_call_event(agent, {
                "toolUseId": "o-2", "name": "slower", "input": {},
            }))
            assert handler._active_tool_spans == 2

            # Invocation ends without completing tools
            handler.on_after_invocation(_after_invocation_event(agent))
            assert handler._active_tool_spans == 0
            assert handler._active_invocations == 0


class TestModelNameExtraction:
    """Model name from stop_response.model."""

    def test_model_name_sent_via_track_ai_partial(self):
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction
            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "hi"}]}])

            handler.on_before_invocation(_before_invocation_event(agent))
            handler.on_before_model_call(_before_model_call_event(agent))
            handler.on_after_model_call(_after_model_call_event(agent, stop_response=SimpleNamespace(
                message={"role": "assistant", "content": [{"text": "hello"}]},
                usage=None,
                model="us.anthropic.claude-3-5-haiku-20241022-v1:0",
            )))
            handler.on_after_invocation(_after_invocation_event(agent))

            mock_rd._track_ai_partial.assert_called_once()
            mock_rd.track_ai.assert_not_called()


class TestTokenUsage:
    """Token usage from both model call and accumulated metrics."""

    def test_token_usage_from_model_call_usage(self):
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction
            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "count"}]}])

            handler.on_before_invocation(_before_invocation_event(agent))
            handler.on_after_model_call(_after_model_call_event(agent, stop_response=SimpleNamespace(
                message=None, usage={"inputTokens": 200, "outputTokens": 80}, model=None,
            )))
            handler.on_after_invocation(_after_invocation_event(agent))

            kw = mock_interaction.finish.call_args[1]
            assert kw["properties"]["ai.usage.prompt_tokens"] == 200
            assert kw["properties"]["ai.usage.completion_tokens"] == 80

    def test_accumulated_usage_from_result_metrics(self):
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction
            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "sum"}]}])

            handler.on_before_invocation(_before_invocation_event(agent))

            result = _agent_result(metrics=_metrics(input_tokens=500, output_tokens=150))
            handler.on_after_invocation(_after_invocation_event(agent, result=result))

            kw = mock_interaction.finish.call_args[1]
            assert kw["properties"]["ai.usage.prompt_tokens"] == 500
            assert kw["properties"]["ai.usage.completion_tokens"] == 150

    def test_no_tokens_means_no_token_properties(self):
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction
            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "no tokens"}]}])

            handler.on_before_invocation(_before_invocation_event(agent))
            handler.on_after_invocation(_after_invocation_event(agent))

            kw = mock_interaction.finish.call_args[1]
            assert "ai.usage.prompt_tokens" not in (kw.get("properties") or {})
            assert "ai.usage.completion_tokens" not in (kw.get("properties") or {})


class TestToolCallGuard:
    """Tool calls without invocation context should be dropped."""

    def test_tool_call_without_invocation_is_no_op(self):
        with patch(MODULE_PATH) as mock_rd:
            handler = _make_client(mock_rd).handler
            agent = _fake_agent()

            # No on_before_invocation — tool call should be silently ignored
            handler.on_before_tool_call(_before_tool_call_event(agent, {
                "toolUseId": "stray-1", "name": "stray_tool", "input": {},
            }))
            assert handler._active_tool_spans == 0
            assert "stray-1" not in handler._tool_spans


class TestOptionalApiKey:
    """Handler works in disabled mode when api_key is omitted."""

    def test_no_api_key_still_creates_handler(self):
        with patch(MODULE_PATH) as mock_rd:
            import warnings
            from raindrop_strands.wrapper import RaindropStrands
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                client = RaindropStrands()

            assert client.handler is not None
            mock_rd.init.assert_called_once_with(
                api_key="",
                tracing_enabled=True,
                bypass_otel_for_tools=True,
            )


class TestMixedSuccessAndErrorTools:
    """Interleaved success and error tool calls."""

    def test_mixed_tools_dont_affect_invocation(self):
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction
            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "go"}]}])

            handler.on_before_invocation(_before_invocation_event(agent))

            # Good tool
            good = {"toolUseId": "ok-1", "name": "good_tool", "input": {}}
            handler.on_before_tool_call(_before_tool_call_event(agent, good))
            handler.on_after_tool_call(_after_tool_call_event(
                agent, good, SimpleNamespace(content=[{"text": "ok"}], status="success"),
            ))

            # Bad tool
            bad = {"toolUseId": "fail-1", "name": "bad_tool", "input": {}}
            handler.on_before_tool_call(_before_tool_call_event(agent, bad))
            handler.on_after_tool_call(_after_tool_call_event(
                agent, bad, SimpleNamespace(content=[], status="error"),
            ))

            # Another good tool
            retry = {"toolUseId": "ok-2", "name": "retry_tool", "input": {}}
            handler.on_before_tool_call(_before_tool_call_event(agent, retry))
            handler.on_after_tool_call(_after_tool_call_event(
                agent, retry, SimpleNamespace(content=[{"text": "recovered"}], status="success"),
            ))

            handler.on_after_invocation(_after_invocation_event(agent))
            assert handler._map_sizes == {"invocations": 0, "tool_spans": 0}
            mock_interaction.finish.assert_called_once()
            mock_rd.track_ai.assert_not_called()


class TestSequentialInvocations:
    """Multiple invocations reusing the same handler."""

    def test_five_sequential_invocations_with_tools(self):
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction
            handler = _make_client(mock_rd, user_id="seq-user").handler

            for i in range(5):
                agent = _fake_agent([{"role": "user", "content": [{"text": f"Query {i}"}]}])
                handler.on_before_invocation(_before_invocation_event(agent))

                handler.on_before_model_call(_before_model_call_event(agent))
                handler.on_after_model_call(_after_model_call_event(agent, stop_response=SimpleNamespace(
                    message={"role": "assistant", "content": [{"text": f"Answer {i}"}]},
                    usage={"inputTokens": 100 + i * 10, "outputTokens": 50 + i * 5},
                    model=f"model-v{i}",
                )))

                tool = {"toolUseId": f"st-{i}", "name": f"tool_{i}", "input": {}}
                handler.on_before_tool_call(_before_tool_call_event(agent, tool))
                handler.on_after_tool_call(_after_tool_call_event(
                    agent, tool, SimpleNamespace(content=[], status="success"),
                ))

                handler.on_after_invocation(_after_invocation_event(agent))

            assert handler._map_sizes == {"invocations": 0, "tool_spans": 0}
            assert mock_rd.begin.call_count == 5
            assert mock_interaction.finish.call_count == 5

            # Verify each begin() call has unique event_id and correct input
            event_ids = set()
            for i, call_obj in enumerate(mock_rd.begin.call_args_list):
                bkw = call_obj[1]
                event_ids.add(bkw["event_id"])
                assert bkw["input"] == f"Query {i}"

            assert len(event_ids) == 5

            # Verify each finish() call has correct output and properties
            for i, call_obj in enumerate(mock_interaction.finish.call_args_list):
                fkw = call_obj[1]
                assert fkw["output"] == f"Answer {i}"
                assert fkw["properties"]["ai.usage.prompt_tokens"] == 100 + i * 10

            mock_rd.track_ai.assert_not_called()


# ---------------------------------------------------------------------------
# Advanced scenarios: subagents, nesting, ReAct, parallel tools, scale
# ---------------------------------------------------------------------------


class TestSubagentDelegation:
    """Parent agent delegates to a child agent via tool call."""

    def test_parent_child_interleaved_lifecycle(self):
        with patch(MODULE_PATH) as mock_rd:
            mock_parent_interaction = MagicMock()
            mock_child_interaction = MagicMock()
            mock_rd.begin.side_effect = [mock_parent_interaction, mock_child_interaction]
            handler = _make_client(mock_rd, user_id="sub-user").handler

            parent = _fake_agent([{"role": "user", "content": [{"text": "Summarize sales"}]}])
            child = _fake_agent([{"role": "user", "content": [{"text": "Fetch DB data"}]}])

            # Parent starts
            handler.on_before_invocation(_before_invocation_event(parent))
            handler.on_before_model_call(_before_model_call_event(parent))
            handler.on_after_model_call(_after_model_call_event(parent, stop_response=SimpleNamespace(
                message={"role": "assistant", "content": [{"text": "Delegating..."}]},
                usage=None, model="nova-pro",
            )))

            # Parent starts tool call wrapping child
            tool_delegate = {"toolUseId": "del-1", "name": "data_agent", "input": {}}
            handler.on_before_tool_call(_before_tool_call_event(parent, tool_delegate))

            # Child lifecycle inside parent's tool
            handler.on_before_invocation(_before_invocation_event(child))
            handler.on_before_model_call(_before_model_call_event(child))
            handler.on_after_model_call(_after_model_call_event(child, stop_response=SimpleNamespace(
                message={"role": "assistant", "content": [{"text": "Q4: $1.2M"}]},
                usage={"inputTokens": 50, "outputTokens": 20}, model="nova-lite",
            )))
            handler.on_after_invocation(_after_invocation_event(child))

            # Parent's tool completes
            handler.on_after_tool_call(_after_tool_call_event(
                parent, tool_delegate, SimpleNamespace(content=[{"text": "Q4: $1.2M"}], status="success"),
            ))

            # Parent finalizes
            handler.on_before_model_call(_before_model_call_event(parent))
            handler.on_after_model_call(_after_model_call_event(parent, stop_response=SimpleNamespace(
                message={"role": "assistant", "content": [{"text": "Sales were $1.2M"}]},
                usage={"inputTokens": 200, "outputTokens": 40}, model="nova-pro",
            )))
            handler.on_after_invocation(_after_invocation_event(parent))

            assert handler._map_sizes == {"invocations": 0, "tool_spans": 0}
            assert mock_rd.begin.call_count == 2

            # Verify distinct event_ids via begin()
            event_ids = {c[1]["event_id"] for c in mock_rd.begin.call_args_list}
            assert len(event_ids) == 2

            # Verify inputs via begin()
            begin_inputs = {c[1]["input"] for c in mock_rd.begin.call_args_list}
            assert "Summarize sales" in begin_inputs
            assert "Fetch DB data" in begin_inputs

            # Child finishes first, then parent
            mock_child_interaction.finish.assert_called_once()
            child_fkw = mock_child_interaction.finish.call_args[1]
            assert child_fkw["output"] == "Q4: $1.2M"

            mock_parent_interaction.finish.assert_called_once()
            parent_fkw = mock_parent_interaction.finish.call_args[1]
            assert parent_fkw["output"] == "Sales were $1.2M"

            mock_rd.track_ai.assert_not_called()


class TestThreeLevelNesting:
    """Orchestrator -> coordinator -> worker, 3 levels deep."""

    def test_three_levels_all_isolated(self):
        with patch(MODULE_PATH) as mock_rd:
            mock_interactions = [MagicMock(), MagicMock(), MagicMock()]
            mock_rd.begin.side_effect = mock_interactions
            handler = _make_client(mock_rd).handler

            orch = _fake_agent([{"role": "user", "content": [{"text": "Build report"}]}])
            coord = _fake_agent([{"role": "user", "content": [{"text": "Gather data"}]}])
            worker = _fake_agent([{"role": "user", "content": [{"text": "Query metrics"}]}])

            # L1 start
            handler.on_before_invocation(_before_invocation_event(orch))
            tool_orch = {"toolUseId": "orch-t", "name": "coordinate", "input": {}}
            handler.on_before_tool_call(_before_tool_call_event(orch, tool_orch))

            # L2 start
            handler.on_before_invocation(_before_invocation_event(coord))
            tool_coord = {"toolUseId": "coord-t", "name": "fetch", "input": {}}
            handler.on_before_tool_call(_before_tool_call_event(coord, tool_coord))

            # L3 start and finish
            handler.on_before_invocation(_before_invocation_event(worker))
            handler.on_before_model_call(_before_model_call_event(worker))
            handler.on_after_model_call(_after_model_call_event(worker, stop_response=SimpleNamespace(
                message={"role": "assistant", "content": [{"text": "42"}]},
                usage=None, model=None,
            )))
            handler.on_after_invocation(_after_invocation_event(worker))

            # L2 finish
            handler.on_after_tool_call(_after_tool_call_event(
                coord, tool_coord, SimpleNamespace(content=[{"text": "42"}], status="success"),
            ))
            handler.on_after_invocation(_after_invocation_event(coord))

            # L1 finish
            handler.on_after_tool_call(_after_tool_call_event(
                orch, tool_orch, SimpleNamespace(content=[{"text": "done"}], status="success"),
            ))
            handler.on_after_invocation(_after_invocation_event(orch))

            assert handler._map_sizes == {"invocations": 0, "tool_spans": 0}
            assert mock_rd.begin.call_count == 3
            for mi in mock_interactions:
                mi.finish.assert_called_once()

            event_ids = {c[1]["event_id"] for c in mock_rd.begin.call_args_list}
            assert len(event_ids) == 3
            mock_rd.track_ai.assert_not_called()


class TestReActLoop:
    """Multi-step reasoning: 4 model calls interleaved with 3 tool calls."""

    def test_react_4_model_3_tool(self):
        with patch(MODULE_PATH) as mock_rd:
            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "GDP growth?"}]}])

            handler.on_before_invocation(_before_invocation_event(agent))

            steps = [
                ("model", "search"), ("tool", "web_search"),
                ("model", "analyze"), ("tool", "calculator"),
                ("model", "verify"), ("tool", "format"),
                ("model", "summarize"),
            ]

            tool_idx = 0
            for step_type, name in steps:
                if step_type == "model":
                    handler.on_before_model_call(_before_model_call_event(agent))
                    handler.on_after_model_call(_after_model_call_event(agent, stop_response=SimpleNamespace(
                        message={"role": "assistant", "content": [{"text": f"Step: {name}"}]},
                        usage={"inputTokens": 100, "outputTokens": 30}, model="nova",
                    )))
                else:
                    tool = {"toolUseId": f"react-{tool_idx}", "name": name, "input": {}}
                    handler.on_before_tool_call(_before_tool_call_event(agent, tool))
                    handler.on_after_tool_call(_after_tool_call_event(
                        agent, tool, SimpleNamespace(content=[{"text": f"{name} result"}], status="success"),
                    ))
                    tool_idx += 1

            handler.on_after_invocation(_after_invocation_event(agent))

            assert handler._map_sizes == {"invocations": 0, "tool_spans": 0}
            mock_rd.begin.return_value.finish.assert_called_once()
            fkw = mock_rd.begin.return_value.finish.call_args[1]
            assert fkw["output"] == "Step: summarize"
            mock_rd.track_ai.assert_not_called()


class TestParallelToolCalls:
    """4 tool calls started before any complete, resolved out of order."""

    def test_parallel_tools_resolved_out_of_order(self):
        with patch(MODULE_PATH) as mock_rd:
            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "parallel"}]}])

            handler.on_before_invocation(_before_invocation_event(agent))

            tool_ids = ["p-1", "p-2", "p-3", "p-4"]
            names = ["fetch_a", "fetch_b", "fetch_c", "fetch_d"]

            # Start all 4
            for i in range(4):
                handler.on_before_tool_call(_before_tool_call_event(agent, {
                    "toolUseId": tool_ids[i], "name": names[i], "input": {},
                }))
            assert handler._active_tool_spans == 4

            # Complete in reverse order
            for i in [3, 1, 0, 2]:
                handler.on_after_tool_call(_after_tool_call_event(
                    agent,
                    {"toolUseId": tool_ids[i], "name": names[i]},
                    SimpleNamespace(content=[{"text": f"{names[i]} done"}], status="success"),
                ))

            assert handler._active_tool_spans == 0
            handler.on_after_invocation(_after_invocation_event(agent))
            assert handler._map_sizes == {"invocations": 0, "tool_spans": 0}


class TestSubagentInterleaving:
    """Exact hook call order for parent + child with cross-agent validation."""

    def test_exact_interleaving_no_cross_contamination(self):
        with patch(MODULE_PATH) as mock_rd:
            mock_parent_interaction = MagicMock()
            mock_child_interaction = MagicMock()
            mock_rd.begin.side_effect = [mock_parent_interaction, mock_child_interaction]
            handler = _make_client(mock_rd).handler

            parent = _fake_agent([{"role": "user", "content": [{"text": "Parent"}]}])
            child = _fake_agent([{"role": "user", "content": [{"text": "Child"}]}])

            handler.on_before_invocation(_before_invocation_event(parent))
            handler.on_before_model_call(_before_model_call_event(parent))
            handler.on_after_model_call(_after_model_call_event(parent))

            # Parent tool wrapping child
            p_tool = {"toolUseId": "p-del", "name": "delegate", "input": {}}
            handler.on_before_tool_call(_before_tool_call_event(parent, p_tool))

            # Child runs inside
            handler.on_before_invocation(_before_invocation_event(child))
            handler.on_before_model_call(_before_model_call_event(child))
            c_tool = {"toolUseId": "c-t", "name": "child_work", "input": {}}
            handler.on_before_tool_call(_before_tool_call_event(child, c_tool))
            handler.on_after_tool_call(_after_tool_call_event(
                child, c_tool, SimpleNamespace(content=[{"text": "child ok"}], status="success"),
            ))
            handler.on_after_model_call(_after_model_call_event(child, stop_response=SimpleNamespace(
                message={"role": "assistant", "content": [{"text": "Child done"}]},
                usage=None, model=None,
            )))
            handler.on_after_invocation(_after_invocation_event(child))

            # Parent tool completes
            handler.on_after_tool_call(_after_tool_call_event(
                parent, p_tool, SimpleNamespace(content=[{"text": "delegated"}], status="success"),
            ))
            handler.on_before_model_call(_before_model_call_event(parent))
            handler.on_after_model_call(_after_model_call_event(parent, stop_response=SimpleNamespace(
                message={"role": "assistant", "content": [{"text": "Parent done"}]},
                usage=None, model=None,
            )))
            handler.on_after_invocation(_after_invocation_event(parent))

            assert handler._map_sizes == {"invocations": 0, "tool_spans": 0}
            assert mock_rd.begin.call_count == 2

            # Verify inputs via begin()
            begin_inputs = {c[1]["input"] for c in mock_rd.begin.call_args_list}
            assert "Parent" in begin_inputs
            assert "Child" in begin_inputs

            # Verify event_ids are distinct
            event_ids = {c[1]["event_id"] for c in mock_rd.begin.call_args_list}
            assert len(event_ids) == 2

            # Child finishes first, parent finishes second
            mock_child_interaction.finish.assert_called_once()
            assert mock_child_interaction.finish.call_args[1]["output"] == "Child done"
            mock_parent_interaction.finish.assert_called_once()
            assert mock_parent_interaction.finish.call_args[1]["output"] == "Parent done"

            mock_rd.track_ai.assert_not_called()


class TestLargeScale:
    """Single invocation with 10 tool calls."""

    def test_10_tool_calls_all_tracked(self):
        with patch(MODULE_PATH) as mock_rd:
            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "run all"}]}])

            handler.on_before_invocation(_before_invocation_event(agent))
            handler.on_before_model_call(_before_model_call_event(agent))
            handler.on_after_model_call(_after_model_call_event(agent))

            for i in range(10):
                tool = {"toolUseId": f"lg-{i}", "name": f"tool_{i}", "input": {}}
                handler.on_before_tool_call(_before_tool_call_event(agent, tool))
                handler.on_after_tool_call(_after_tool_call_event(
                    agent, tool, SimpleNamespace(content=[], status="success"),
                ))

            handler.on_after_invocation(_after_invocation_event(agent))
            assert handler._map_sizes == {"invocations": 0, "tool_spans": 0}
            mock_rd.begin.return_value.finish.assert_called_once()
            mock_rd.track_ai.assert_not_called()


class TestStress50Invocations:
    """50 sequential invocations with model + 2 tools each."""

    def test_50_invocations_zero_leaks(self):
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction
            handler = _make_client(mock_rd).handler

            for i in range(50):
                agent = _fake_agent([{"role": "user", "content": [{"text": f"Stress {i}"}]}])
                handler.on_before_invocation(_before_invocation_event(agent))

                handler.on_before_model_call(_before_model_call_event(agent))
                handler.on_after_model_call(_after_model_call_event(agent, stop_response=SimpleNamespace(
                    message={"role": "assistant", "content": [{"text": f"R{i}"}]},
                    usage={"inputTokens": 100 + i, "outputTokens": 50 + i},
                    model=f"m{i}",
                )))

                for t in range(2):
                    tool = {"toolUseId": f"s{i}-t{t}", "name": f"tool_{t}", "input": {}}
                    handler.on_before_tool_call(_before_tool_call_event(agent, tool))
                    handler.on_after_tool_call(_after_tool_call_event(
                        agent, tool, SimpleNamespace(content=[], status="success"),
                    ))

                handler.on_after_invocation(_after_invocation_event(agent))

            assert handler._map_sizes == {"invocations": 0, "tool_spans": 0}
            assert mock_rd.begin.call_count == 50
            assert mock_interaction.finish.call_count == 50

            event_ids = {c[1]["event_id"] for c in mock_rd.begin.call_args_list}
            assert len(event_ids) == 50

            # Verify first and last have correct input via begin()
            first = mock_rd.begin.call_args_list[0][1]
            last = mock_rd.begin.call_args_list[49][1]
            assert first["input"] == "Stress 0"
            assert last["input"] == "Stress 49"

            mock_rd.track_ai.assert_not_called()
