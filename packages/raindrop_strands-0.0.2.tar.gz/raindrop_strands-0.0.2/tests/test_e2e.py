"""End-to-end tests for the Strands Agents Python integration.

These tests use REAL API calls to a Strands-compatible LLM provider and the
Raindrop API, then verify that events land in the Raindrop dashboard via
the TRPC API.

Required environment variables:
    RAINDROP_WRITE_KEY or RAINDROP_API_KEY  — Raindrop write key
    OPENAI_API_KEY                          — OpenAI API key (default provider)
    RAINDROP_DASHBOARD_TOKEN                — Bearer token for dashboard API
    RAINDROP_BACKEND_URL                    — Backend URL (default: https://backend.raindrop.ai)

These tests are skipped in CI where keys are not available.
"""

import json
import os
import time
import uuid

import pytest
import requests

WRITE_KEY = os.getenv("RAINDROP_WRITE_KEY") or os.getenv("RAINDROP_API_KEY")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
DASHBOARD_TOKEN = os.getenv("RAINDROP_DASHBOARD_TOKEN")
BACKEND_URL = os.getenv("RAINDROP_BACKEND_URL", "https://backend.raindrop.ai")

skip_unless_e2e = pytest.mark.skipif(
    not all([WRITE_KEY, OPENAI_API_KEY, DASHBOARD_TOKEN]),
    reason="RAINDROP_WRITE_KEY, OPENAI_API_KEY, and RAINDROP_DASHBOARD_TOKEN required",
)


def _fetch_events(convo_id: str, timeout: int = 30) -> list:
    """Poll backend until events appear or timeout."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        resp = requests.get(
            f"{BACKEND_URL}/api/trpc/events.getByConvoId",
            params={"input": json.dumps({"convoId": convo_id})},
            headers={"Authorization": f"Bearer {DASHBOARD_TOKEN}"},
        )
        if resp.ok:
            data = resp.json().get("result", {}).get("data", [])
            if data:
                return data
        time.sleep(2)
    return []


@skip_unless_e2e
class TestBasicInvocation:
    """Basic agent invocation → verify event in dashboard."""

    def test_single_invocation_tracked(self):
        from strands import Agent
        from raindrop_strands import RaindropStrands

        convo_id = f"e2e-strands-basic-{uuid.uuid4().hex[:8]}"
        raindrop = RaindropStrands(
            api_key=WRITE_KEY,
            user_id="e2e-test-user",
            convo_id=convo_id,
        )

        agent = Agent(
            model_id="us.amazon.nova-lite-v1:0",
            system_prompt="Reply in one short sentence.",
        )
        raindrop.handler.register_hooks(agent)

        agent("What is 2+2?")
        raindrop.shutdown()

        events = _fetch_events(convo_id)
        assert len(events) >= 1, f"Expected at least 1 event, got {len(events)}"

        event = events[0]
        assert event.get("input") is not None
        assert event.get("output") is not None


@skip_unless_e2e
class TestToolCalls:
    """Agent with tool calls → verify tool spans tracked."""

    def test_tool_call_tracked(self):
        from strands import Agent, tool
        from raindrop_strands import RaindropStrands

        convo_id = f"e2e-strands-tool-{uuid.uuid4().hex[:8]}"
        raindrop = RaindropStrands(
            api_key=WRITE_KEY,
            user_id="e2e-test-user",
            convo_id=convo_id,
        )

        @tool
        def add_numbers(a: int, b: int) -> int:
            """Add two numbers together."""
            return a + b

        agent = Agent(
            model_id="us.amazon.nova-lite-v1:0",
            system_prompt="Use the add_numbers tool to answer math questions.",
            tools=[add_numbers],
        )
        raindrop.handler.register_hooks(agent)

        agent("What is 17 + 25?")
        raindrop.shutdown()

        events = _fetch_events(convo_id)
        assert len(events) >= 1, f"Expected at least 1 event, got {len(events)}"


@skip_unless_e2e
class TestSequentialInvocations:
    """Multiple sequential invocations → verify no state leak."""

    def test_sequential_calls_isolated(self):
        from strands import Agent
        from raindrop_strands import RaindropStrands

        convo_id = f"e2e-strands-seq-{uuid.uuid4().hex[:8]}"
        raindrop = RaindropStrands(
            api_key=WRITE_KEY,
            user_id="e2e-test-user",
            convo_id=convo_id,
        )

        agent = Agent(
            model_id="us.amazon.nova-lite-v1:0",
            system_prompt="Reply in one word.",
        )
        raindrop.handler.register_hooks(agent)

        agent("Say hello")
        agent("Say goodbye")
        raindrop.shutdown()

        events = _fetch_events(convo_id, timeout=45)
        assert len(events) >= 2, f"Expected at least 2 events, got {len(events)}"

        # Verify each event has distinct event_id
        event_ids = {e.get("eventId") for e in events if e.get("eventId")}
        assert len(event_ids) >= 2, "Events should have distinct event IDs"


@skip_unless_e2e
class TestTokenUsage:
    """Token usage verification."""

    def test_tokens_present_in_event(self):
        from strands import Agent
        from raindrop_strands import RaindropStrands

        convo_id = f"e2e-strands-tokens-{uuid.uuid4().hex[:8]}"
        raindrop = RaindropStrands(
            api_key=WRITE_KEY,
            user_id="e2e-test-user",
            convo_id=convo_id,
        )

        agent = Agent(
            model_id="us.amazon.nova-lite-v1:0",
            system_prompt="Reply in one sentence.",
        )
        raindrop.handler.register_hooks(agent)

        agent("Explain what Python is.")
        raindrop.shutdown()

        events = _fetch_events(convo_id)
        assert len(events) >= 1

        event = events[0]
        props = event.get("properties", {})
        # Token counts should be present (may be in properties or top-level)
        has_tokens = (
            props.get("ai.usage.prompt_tokens") is not None
            or event.get("promptTokens") is not None
        )
        assert has_tokens, "Expected token usage data in event"


@skip_unless_e2e
class TestConvoIdGrouping:
    """Conversation grouping via convo_id."""

    def test_events_grouped_by_convo_id(self):
        from strands import Agent
        from raindrop_strands import RaindropStrands

        convo_id = f"e2e-strands-convo-{uuid.uuid4().hex[:8]}"
        raindrop = RaindropStrands(
            api_key=WRITE_KEY,
            user_id="e2e-test-user",
            convo_id=convo_id,
        )

        agent = Agent(
            model_id="us.amazon.nova-lite-v1:0",
            system_prompt="Reply in one word.",
        )
        raindrop.handler.register_hooks(agent)

        agent("Say yes")
        agent("Say no")
        raindrop.shutdown()

        events = _fetch_events(convo_id, timeout=45)
        assert len(events) >= 2

        # All events should share the same convo_id
        for event in events:
            assert event.get("convoId") == convo_id


@skip_unless_e2e
class TestFactoryFunction:
    """Factory function API works the same as class-based API."""

    def test_factory_function_creates_events(self):
        from strands import Agent
        from raindrop_strands import create_raindrop_strands

        convo_id = f"e2e-strands-factory-{uuid.uuid4().hex[:8]}"
        raindrop = create_raindrop_strands(
            api_key=WRITE_KEY,
            user_id="e2e-test-user",
            convo_id=convo_id,
        )

        agent = Agent(
            model_id="us.amazon.nova-lite-v1:0",
            system_prompt="Reply in one word.",
        )
        raindrop.handler.register_hooks(agent)

        agent("Say hello")
        raindrop.shutdown()

        events = _fetch_events(convo_id)
        assert len(events) >= 1
