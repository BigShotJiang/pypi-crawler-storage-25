"""Tests for Strands Agents integration.

Uses unittest.mock.patch to mock the raindrop module.

CRITICAL RULES:
  1. NEVER bypass __init__ with __new__ -- always construct normally inside patch().
  2. ALWAYS use patch("raindrop_strands.wrapper.raindrop") to mock at the import site.
  3. Assert actual API calls (mock_interaction.finish, _track_ai_partial, etc.),
     not internal state.
  4. Each test that triggers data emission must re-patch.
"""

from unittest.mock import MagicMock, patch
from types import SimpleNamespace

MODULE_PATH = "raindrop_strands.wrapper.raindrop"


def _make_client(mock_raindrop, **kwargs):
    """Create a RaindropStrands instance with an already-active raindrop mock."""
    from raindrop_strands.wrapper import RaindropStrands
    return RaindropStrands(api_key="test-key", **kwargs)


def _make_client_factory(mock_raindrop, **kwargs):
    """Create via factory function with an already-active raindrop mock."""
    from raindrop_strands.wrapper import create_raindrop_strands
    return create_raindrop_strands(api_key="test-key", **kwargs)


def _fake_agent(messages=None):
    """Create a minimal fake agent object with messages."""
    agent = SimpleNamespace()
    agent.messages = messages or []
    agent.add_hook = MagicMock()
    return agent


def _before_invocation_event(agent):
    return SimpleNamespace(agent=agent)


def _after_invocation_event(agent, result=None):
    return SimpleNamespace(agent=agent, result=result)


def _before_model_call_event(agent):
    return SimpleNamespace(agent=agent)


def _after_model_call_event(agent, stop_response=None, exception=None):
    return SimpleNamespace(agent=agent, stop_response=stop_response, exception=exception)


def _before_tool_call_event(agent, tool_use):
    return SimpleNamespace(agent=agent, tool_use=tool_use)


def _after_tool_call_event(agent, tool_use, result, exception=None):
    return SimpleNamespace(agent=agent, tool_use=tool_use, result=result, exception=exception)


def _agent_result(message=None, metrics=None):
    """Create a fake AgentResult."""
    return SimpleNamespace(message=message, metrics=metrics)


def _metrics(input_tokens=None, output_tokens=None):
    """Create a fake EventLoopMetrics with accumulated_usage.

    Uses a plain dict for usage to match the real SDK's TypedDict (Usage),
    which is a dict — not an object with attributes.
    """
    usage = {"inputTokens": input_tokens, "outputTokens": output_tokens}
    return SimpleNamespace(accumulated_usage=usage)


class TestRaindropStrandsClass:
    """Tests for the RaindropStrands class."""

    def test_has_handler_flush_shutdown(self):
        with patch(MODULE_PATH) as mock_rd:
            client = _make_client(mock_rd)
        assert client.handler is not None
        assert callable(client.flush)
        assert callable(client.shutdown)

    def test_calls_raindrop_init_with_api_key(self):
        with patch(MODULE_PATH) as mock_rd:
            _make_client(mock_rd)
        mock_rd.init.assert_called_once_with(
            api_key="test-key",
            tracing_enabled=True,
            bypass_otel_for_tools=True,
        )

    def test_flush_delegates_to_raindrop(self):
        with patch(MODULE_PATH) as mock_rd:
            client = _make_client(mock_rd)
            client.flush()
        mock_rd.flush.assert_called_once()

    def test_shutdown_delegates_to_raindrop(self):
        with patch(MODULE_PATH) as mock_rd:
            client = _make_client(mock_rd)
            client.shutdown()
        mock_rd.shutdown.assert_called_once()

    def test_identify_delegates_to_raindrop(self):
        with patch(MODULE_PATH) as mock_rd:
            client = _make_client(mock_rd)
            client.identify(user_id="u1", traits={"name": "Alice"})
        mock_rd.identify.assert_called_once_with(user_id="u1", traits={"name": "Alice"})

    def test_identify_defaults_traits_to_empty_dict(self):
        with patch(MODULE_PATH) as mock_rd:
            client = _make_client(mock_rd)
            client.identify(user_id="u1")
        mock_rd.identify.assert_called_once_with(user_id="u1", traits={})

    def test_track_signal_delegates_to_raindrop(self):
        with patch(MODULE_PATH) as mock_rd:
            client = _make_client(mock_rd)
            client.track_signal(
                event_id="evt-1",
                name="thumbs_up",
                signal_type="feedback",
                sentiment="POSITIVE",
            )
        mock_rd.track_signal.assert_called_once_with(
            event_id="evt-1",
            name="thumbs_up",
            signal_type="feedback",
            timestamp=None,
            properties=None,
            attachment_id=None,
            comment=None,
            after=None,
            sentiment="POSITIVE",
        )

    def test_has_version(self):
        import raindrop_strands
        assert hasattr(raindrop_strands, "__version__")
        assert raindrop_strands.__version__ == "0.0.2"


class TestCreateRaindropStrands:
    """Tests for the create_raindrop_strands factory."""

    def test_returns_raindrop_strands_instance(self):
        with patch(MODULE_PATH) as mock_rd:
            from raindrop_strands.wrapper import RaindropStrands
            client = _make_client_factory(mock_rd)
        assert isinstance(client, RaindropStrands)

    def test_has_handler_flush_shutdown(self):
        with patch(MODULE_PATH) as mock_rd:
            client = _make_client_factory(mock_rd)
        assert client.handler is not None
        assert callable(client.flush)
        assert callable(client.shutdown)

    def test_calls_raindrop_init_with_api_key(self):
        with patch(MODULE_PATH) as mock_rd:
            _make_client_factory(mock_rd)
        mock_rd.init.assert_called_once_with(
            api_key="test-key",
            tracing_enabled=True,
            bypass_otel_for_tools=True,
        )

    def test_flush_delegates_to_raindrop(self):
        with patch(MODULE_PATH) as mock_rd:
            client = _make_client_factory(mock_rd)
            client.flush()
        mock_rd.flush.assert_called_once()

    def test_shutdown_delegates_to_raindrop(self):
        with patch(MODULE_PATH) as mock_rd:
            client = _make_client_factory(mock_rd)
            client.shutdown()
        mock_rd.shutdown.assert_called_once()


class TestRegisterHooks:
    """Tests for the register_hooks method."""

    def test_register_hooks_calls_add_hook_six_times(self):
        with patch(MODULE_PATH):
            from raindrop_strands.wrapper import RaindropEventHandler
            handler = RaindropEventHandler()
        agent = _fake_agent()
        handler.register_hooks(agent)
        assert agent.add_hook.call_count == 6


class TestInputExtraction:
    """Tests for _extract_user_input and _extract_text_from_message."""

    def test_extracts_last_user_message_text(self):
        from raindrop_strands.wrapper import _extract_user_input
        messages = [
            {"role": "assistant", "content": [{"text": "I am assistant"}]},
            {"role": "user", "content": [{"text": "User question"}]},
        ]
        assert _extract_user_input(messages) == "User question"

    def test_skips_assistant_messages(self):
        from raindrop_strands.wrapper import _extract_user_input
        messages = [
            {"role": "user", "content": [{"text": "First user msg"}]},
            {"role": "assistant", "content": [{"text": "Response"}]},
            {"role": "user", "content": [{"text": "Second user msg"}]},
        ]
        assert _extract_user_input(messages) == "Second user msg"

    def test_handles_multi_block_content(self):
        from raindrop_strands.wrapper import _extract_text_from_message
        msg = {"content": [{"text": "Part one"}, {"text": "Part two"}]}
        assert _extract_text_from_message(msg) == "Part one\nPart two"

    def test_skips_non_text_blocks(self):
        from raindrop_strands.wrapper import _extract_text_from_message
        msg = {
            "content": [
                {"toolUse": {"toolUseId": "123", "name": "t", "input": {}}},
                {"text": "Actual text"},
                {"image": {"source": "data:..."}},
            ]
        }
        assert _extract_text_from_message(msg) == "Actual text"

    def test_returns_none_for_empty_messages(self):
        from raindrop_strands.wrapper import _extract_user_input
        assert _extract_user_input([]) is None
        assert _extract_user_input(None) is None

    def test_returns_none_for_message_without_text(self):
        from raindrop_strands.wrapper import _extract_text_from_message
        msg = {"content": [{"image": {"source": "data:..."}}]}
        assert _extract_text_from_message(msg) is None

    def test_returns_none_for_invalid_message(self):
        from raindrop_strands.wrapper import _extract_text_from_message
        assert _extract_text_from_message(None) is None
        assert _extract_text_from_message("not a dict") is None
        assert _extract_text_from_message({"content": "not a list"}) is None

    def test_fallback_to_last_message_if_no_user_message(self):
        from raindrop_strands.wrapper import _extract_user_input
        messages = [
            {"role": "assistant", "content": [{"text": "Only assistant"}]},
        ]
        assert _extract_user_input(messages) == "Only assistant"


class TestBeforeInvocation:
    """Tests for the on_before_invocation hook callback."""

    def test_sets_up_context_with_input(self):
        with patch(MODULE_PATH) as mock_rd:
            client = _make_client(mock_rd, user_id="u1")
            handler = client.handler
            agent = _fake_agent([
                {"role": "user", "content": [{"text": "Hello agent"}]}
            ])
            handler.on_before_invocation(_before_invocation_event(agent))

            mock_rd.track_ai.assert_not_called()
            assert handler._active_invocations == 1

    def test_increments_active_invocations(self):
        with patch(MODULE_PATH) as mock_rd:
            handler = _make_client(mock_rd).handler
            agent = _fake_agent()
            assert handler._active_invocations == 0
            handler.on_before_invocation(_before_invocation_event(agent))
            assert handler._active_invocations == 1


class TestAfterInvocation:
    """Tests for the on_after_invocation hook callback."""

    def test_finalizes_event_with_output_and_tokens(self):
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction
            client = _make_client(mock_rd, user_id="u1")
            handler = client.handler
            agent = _fake_agent([
                {"role": "user", "content": [{"text": "Input text"}]}
            ])
            handler.on_before_invocation(_before_invocation_event(agent))

            result = _agent_result(
                message={"role": "assistant", "content": [{"text": "Output text"}]},
                metrics=_metrics(input_tokens=100, output_tokens=50),
            )
            handler.on_after_invocation(_after_invocation_event(agent, result=result))

            mock_interaction.finish.assert_called_once()
            call_kwargs = mock_interaction.finish.call_args[1]
            assert call_kwargs["output"] == "Output text"
            assert call_kwargs["properties"]["ai.usage.prompt_tokens"] == 100
            assert call_kwargs["properties"]["ai.usage.completion_tokens"] == 50
            mock_rd.track_ai.assert_not_called()

    def test_decrements_active_invocations(self):
        with patch(MODULE_PATH) as mock_rd:
            handler = _make_client(mock_rd).handler
            agent = _fake_agent()
            handler.on_before_invocation(_before_invocation_event(agent))
            assert handler._active_invocations == 1
            handler.on_after_invocation(_after_invocation_event(agent))
            assert handler._active_invocations == 0

    def test_no_crash_when_no_matching_context(self):
        with patch(MODULE_PATH) as mock_rd:
            handler = _make_client(mock_rd).handler
            agent = _fake_agent()
            # Call after without before — should not raise
            handler.on_after_invocation(_after_invocation_event(agent))

    def test_handles_none_result_gracefully(self):
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction
            handler = _make_client(mock_rd).handler
            agent = _fake_agent()
            handler.on_before_invocation(_before_invocation_event(agent))
            handler.on_after_invocation(_after_invocation_event(agent, result=None))
            mock_interaction.finish.assert_called_once()

    def test_user_id_defaults_to_unknown(self):
        with patch(MODULE_PATH) as mock_rd:
            handler = _make_client(mock_rd).handler
            agent = _fake_agent()
            handler.on_before_invocation(_before_invocation_event(agent))
            # user_id is passed to begin(), not track_ai()
            call_kwargs = mock_rd.begin.call_args[1]
            assert call_kwargs["user_id"] == "unknown"


class TestAfterModelCall:
    """Tests for the on_after_model_call hook callback."""

    def test_extracts_output_from_stop_response(self):
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction
            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "Q"}]}])
            handler.on_before_invocation(_before_invocation_event(agent))

            stop_response = SimpleNamespace(
                message={"role": "assistant", "content": [{"text": "Model answer"}]},
                usage={"inputTokens": 10, "outputTokens": 20},
                model="claude-3",
            )
            handler.on_after_model_call(_after_model_call_event(agent, stop_response=stop_response))

            handler.on_after_invocation(_after_invocation_event(agent))
            call_kwargs = mock_interaction.finish.call_args[1]
            assert call_kwargs["output"] == "Model answer"
            assert call_kwargs["properties"]["ai.usage.prompt_tokens"] == 10
            assert call_kwargs["properties"]["ai.usage.completion_tokens"] == 20
            # Model is sent via _track_ai_partial
            mock_rd._track_ai_partial.assert_called_once()

    def test_no_crash_when_no_matching_context(self):
        with patch(MODULE_PATH) as mock_rd:
            handler = _make_client(mock_rd).handler
            agent = _fake_agent()
            handler.on_after_model_call(_after_model_call_event(agent))

    def test_handles_none_stop_response(self):
        with patch(MODULE_PATH) as mock_rd:
            handler = _make_client(mock_rd).handler
            agent = _fake_agent()
            handler.on_before_invocation(_before_invocation_event(agent))
            handler.on_after_model_call(_after_model_call_event(agent, stop_response=None))


class TestToolCallHooks:
    """Tests for before/after tool call hooks."""

    def test_tracks_tool_span_with_name_and_input(self):
        with patch(MODULE_PATH) as mock_rd:
            handler = _make_client(mock_rd).handler
            agent = _fake_agent()
            handler.on_before_invocation(_before_invocation_event(agent))

            tool_use = {"toolUseId": "t-1", "name": "calculator", "input": {"expr": "2+2"}}
            handler.on_before_tool_call(_before_tool_call_event(agent, tool_use))

            assert handler._active_tool_spans == 1
            assert "t-1" in handler._tool_spans

    def test_cleans_up_tool_span_after_call(self):
        with patch(MODULE_PATH) as mock_rd:
            handler = _make_client(mock_rd).handler
            agent = _fake_agent()
            handler.on_before_invocation(_before_invocation_event(agent))

            tool_use = {"toolUseId": "t-1", "name": "search", "input": "query"}
            handler.on_before_tool_call(_before_tool_call_event(agent, tool_use))
            assert handler._active_tool_spans == 1

            result = SimpleNamespace(content=[{"text": "result"}], status="success")
            handler.on_after_tool_call(_after_tool_call_event(agent, tool_use, result))
            assert handler._active_tool_spans == 0
            assert "t-1" not in handler._tool_spans

    def test_no_crash_with_none_tool_use(self):
        with patch(MODULE_PATH) as mock_rd:
            handler = _make_client(mock_rd).handler
            agent = _fake_agent()
            event = SimpleNamespace(agent=agent, tool_use=None)
            handler.on_before_tool_call(event)
            handler.on_after_tool_call(SimpleNamespace(agent=agent, tool_use=None, result=None))


class TestCrashProtection:
    """Tests that telemetry failures never crash the user's pipeline."""

    def test_before_invocation_sets_up_context(self):
        with patch(MODULE_PATH) as mock_rd:
            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "test"}]}])
            handler.on_before_invocation(_before_invocation_event(agent))
            assert handler._active_invocations == 1

    def test_after_invocation_swallows_finish_error(self):
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction
            handler = _make_client(mock_rd).handler
            agent = _fake_agent()
            handler.on_before_invocation(_before_invocation_event(agent))
            mock_interaction.finish.side_effect = RuntimeError("API down")
            # Should not raise
            handler.on_after_invocation(_after_invocation_event(agent))

    def test_invalid_event_does_not_crash(self):
        with patch(MODULE_PATH) as mock_rd:
            handler = _make_client(mock_rd).handler
            handler.on_before_invocation(None)
            handler.on_after_invocation(None)
            handler.on_before_model_call(None)
            handler.on_after_model_call(None)
            handler.on_before_tool_call(None)
            handler.on_after_tool_call(None)


class TestMemoryCleanup:
    """Tests that internal state is properly cleaned up."""

    def test_invocation_context_cleaned_after_completion(self):
        with patch(MODULE_PATH) as mock_rd:
            handler = _make_client(mock_rd).handler
            agent = _fake_agent()

            assert handler._map_sizes == {"invocations": 0, "tool_spans": 0}
            handler.on_before_invocation(_before_invocation_event(agent))
            assert handler._map_sizes["invocations"] == 1

            handler.on_after_invocation(_after_invocation_event(agent))
            assert handler._map_sizes["invocations"] == 0

    def test_tool_spans_cleaned_after_completion(self):
        with patch(MODULE_PATH) as mock_rd:
            handler = _make_client(mock_rd).handler
            agent = _fake_agent()
            handler.on_before_invocation(_before_invocation_event(agent))

            tool_use = {"toolUseId": "t-1", "name": "test", "input": {}}
            handler.on_before_tool_call(_before_tool_call_event(agent, tool_use))
            assert handler._map_sizes["tool_spans"] == 1

            result = SimpleNamespace(content=[], status="success")
            handler.on_after_tool_call(_after_tool_call_event(agent, tool_use, result))
            assert handler._map_sizes["tool_spans"] == 0

    def test_no_leak_across_10_sequential_invocations(self):
        with patch(MODULE_PATH) as mock_rd:
            handler = _make_client(mock_rd).handler

            for i in range(10):
                agent = _fake_agent([{"role": "user", "content": [{"text": f"Req {i}"}]}])
                handler.on_before_invocation(_before_invocation_event(agent))
                tool_use = {"toolUseId": f"t-{i}", "name": "test", "input": {}}
                handler.on_before_tool_call(_before_tool_call_event(agent, tool_use))
                result = SimpleNamespace(content=[], status="success")
                handler.on_after_tool_call(_after_tool_call_event(agent, tool_use, result))
                handler.on_after_invocation(_after_invocation_event(agent))

            assert handler._map_sizes == {"invocations": 0, "tool_spans": 0}
            assert mock_rd.begin.return_value.finish.call_count == 10


class TestConvoIdForwarding:
    """Tests that convoId is forwarded to events."""

    def test_convo_id_included_in_begin(self):
        with patch(MODULE_PATH) as mock_rd:
            client = _make_client(mock_rd, convo_id="conv-42")
            handler = client.handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "Hi"}]}])
            handler.on_before_invocation(_before_invocation_event(agent))

            call_kwargs = mock_rd.begin.call_args[1]
            assert call_kwargs["convo_id"] == "conv-42"


class TestNoDoubleTracking:
    """Tests that a single invocation produces exactly one finish() call."""

    def test_single_invocation_produces_one_finish_call(self):
        """interaction.finish() is called once in on_after_invocation with final data."""
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction
            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "test"}]}])

            handler.on_before_invocation(_before_invocation_event(agent))
            handler.on_after_invocation(_after_invocation_event(agent))

            assert mock_interaction.finish.call_count == 1
            mock_rd.track_ai.assert_not_called()

    def test_model_and_tool_calls_dont_emit_extra_events(self):
        """Model and tool calls should not trigger additional finish() calls."""
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction
            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "test"}]}])

            handler.on_before_invocation(_before_invocation_event(agent))
            handler.on_before_model_call(_before_model_call_event(agent))
            handler.on_after_model_call(_after_model_call_event(agent))
            tool_use = {"toolUseId": "t-1", "name": "test", "input": {}}
            handler.on_before_tool_call(_before_tool_call_event(agent, tool_use))
            result = SimpleNamespace(content=[], status="success")
            handler.on_after_tool_call(_after_tool_call_event(agent, tool_use, result))
            handler.on_after_invocation(_after_invocation_event(agent))

            assert mock_interaction.finish.call_count == 1
            mock_rd.track_ai.assert_not_called()

    def test_falls_back_to_track_ai_when_begin_fails(self):
        """When begin() fails, track_ai() is used as fallback."""
        with patch(MODULE_PATH) as mock_rd:
            mock_rd.begin.side_effect = RuntimeError("begin failed")
            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "test"}]}])

            handler.on_before_invocation(_before_invocation_event(agent))
            handler.on_after_invocation(_after_invocation_event(agent))

            mock_rd.track_ai.assert_called_once()
            call_kwargs = mock_rd.track_ai.call_args[1]
            assert call_kwargs["user_id"] == "unknown"
            assert call_kwargs["event"] == "ai_generation"


class TestSafeSerialize:
    """Tests for _safe_serialize helper."""

    def test_serializes_dict(self):
        from raindrop_strands.wrapper import _safe_serialize
        assert _safe_serialize({"a": 1}) == '{"a": 1}'

    def test_handles_non_serializable(self):
        from raindrop_strands.wrapper import _safe_serialize
        result = _safe_serialize(object())
        assert isinstance(result, str)


class TestErrorTracking:
    """Tests for error type and message capture in properties."""

    def test_error_captured_from_model_call_exception(self):
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction
            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "test"}]}])
            handler.on_before_invocation(_before_invocation_event(agent))

            error = ValueError("model call failed")
            event = SimpleNamespace(agent=agent, stop_response=None, exception=error, error=error)
            handler.on_after_model_call(event)
            handler.on_after_invocation(_after_invocation_event(agent))

            call_kwargs = mock_interaction.finish.call_args[1]
            assert call_kwargs["properties"]["error.type"] == "ValueError"
            assert call_kwargs["properties"]["error.message"] == "model call failed"

    def test_error_cleared_by_successful_model_call(self):
        """A successful model call after a failed one should clear stale error data."""
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction
            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "test"}]}])
            handler.on_before_invocation(_before_invocation_event(agent))

            # First model call fails
            error = RuntimeError("temporary failure")
            fail_event = SimpleNamespace(
                agent=agent, stop_response=None, exception=error, error=error,
            )
            handler.on_after_model_call(fail_event)

            # Second model call succeeds — should clear stale error
            success_event = SimpleNamespace(
                agent=agent,
                stop_response=SimpleNamespace(
                    message={"content": [{"text": "ok"}]},
                    usage=None,
                    model=None,
                ),
                exception=None,
                error=None,
            )
            handler.on_after_model_call(success_event)
            handler.on_after_invocation(_after_invocation_event(agent))

            call_kwargs = mock_interaction.finish.call_args[1]
            # No error properties should be present
            props = call_kwargs.get("properties") or {}
            assert "error.type" not in props
            assert "error.message" not in props


class TestTracingEnabledFlags:
    """Tests that tracing_enabled and bypass_otel_for_tools are passed to init."""

    def test_init_passes_tracing_flags(self):
        with patch(MODULE_PATH) as mock_rd:
            _make_client(mock_rd)
        mock_rd.init.assert_called_once_with(
            api_key="test-key",
            tracing_enabled=True,
            bypass_otel_for_tools=True,
        )

    def test_no_api_key_still_passes_tracing_flags(self):
        with patch(MODULE_PATH) as mock_rd:
            import warnings
            from raindrop_strands.wrapper import RaindropStrands
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                RaindropStrands()
        mock_rd.init.assert_called_once_with(
            api_key="",
            tracing_enabled=True,
            bypass_otel_for_tools=True,
        )

    def test_custom_tracing_enabled_false(self):
        with patch(MODULE_PATH) as mock_rd:
            from raindrop_strands.wrapper import RaindropStrands
            RaindropStrands(api_key="test-key", tracing_enabled=False)
        mock_rd.init.assert_called_once_with(
            api_key="test-key",
            tracing_enabled=False,
            bypass_otel_for_tools=True,
        )

    def test_custom_bypass_otel_false(self):
        with patch(MODULE_PATH) as mock_rd:
            from raindrop_strands.wrapper import RaindropStrands
            RaindropStrands(api_key="test-key", bypass_otel_for_tools=False)
        mock_rd.init.assert_called_once_with(
            api_key="test-key",
            tracing_enabled=True,
            bypass_otel_for_tools=False,
        )

    def test_factory_passes_custom_tracing_flags(self):
        with patch(MODULE_PATH) as mock_rd:
            from raindrop_strands.wrapper import create_raindrop_strands
            create_raindrop_strands(
                api_key="test-key",
                tracing_enabled=False,
                bypass_otel_for_tools=False,
            )
        mock_rd.init.assert_called_once_with(
            api_key="test-key",
            tracing_enabled=False,
            bypass_otel_for_tools=False,
        )


class TestWarningsWarn:
    """Tests that warnings.warn is used for empty api_key (not logger.warning)."""

    def test_empty_api_key_emits_warning(self):
        import warnings
        with patch(MODULE_PATH):
            from raindrop_strands.wrapper import RaindropStrands
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                RaindropStrands()
            assert len(w) == 1
            assert "api_key not provided" in str(w[0].message)

    def test_provided_api_key_no_warning(self):
        import warnings
        with patch(MODULE_PATH):
            from raindrop_strands.wrapper import RaindropStrands
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                RaindropStrands(api_key="rk_test")
            assert len(w) == 0


class TestInteractionTrackTool:
    """Tests for interaction.track_tool() being called with correct args."""

    def test_track_tool_called_on_tool_completion(self):
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction

            handler = _make_client(mock_rd, user_id="u1").handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "test"}]}])
            handler.on_before_invocation(_before_invocation_event(agent))

            tool_use = {"toolUseId": "t-1", "name": "calculator", "input": {"expr": "2+2"}}
            handler.on_before_tool_call(_before_tool_call_event(agent, tool_use))

            result = SimpleNamespace(content=[{"text": "4"}], status="success")
            handler.on_after_tool_call(_after_tool_call_event(agent, tool_use, result))

            mock_interaction.track_tool.assert_called_once()
            call_kwargs = mock_interaction.track_tool.call_args[1]
            assert call_kwargs["name"] == "calculator"
            assert '"expr": "2+2"' in call_kwargs["input"]
            assert call_kwargs["output"] is not None
            assert call_kwargs["duration_ms"] >= 0
            assert call_kwargs["error"] is None

    def test_track_tool_with_error(self):
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction

            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "test"}]}])
            handler.on_before_invocation(_before_invocation_event(agent))

            tool_use = {"toolUseId": "t-err", "name": "failing_tool", "input": {}}
            handler.on_before_tool_call(_before_tool_call_event(agent, tool_use))

            exc = ValueError("tool crashed")
            event = SimpleNamespace(
                agent=agent, tool_use=tool_use,
                result=None, exception=exc, error=None,
            )
            handler.on_after_tool_call(event)

            mock_interaction.track_tool.assert_called_once()
            call_kwargs = mock_interaction.track_tool.call_args[1]
            assert call_kwargs["name"] == "failing_tool"
            assert isinstance(call_kwargs["error"], ValueError)

    def test_track_tool_duration_is_positive(self):
        """Duration should be a positive number of milliseconds."""
        import time as _time
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction

            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "test"}]}])
            handler.on_before_invocation(_before_invocation_event(agent))

            tool_use = {"toolUseId": "t-dur", "name": "slow_tool", "input": {}}
            handler.on_before_tool_call(_before_tool_call_event(agent, tool_use))

            _time.sleep(0.01)  # 10ms

            result = SimpleNamespace(content=[], status="success")
            handler.on_after_tool_call(_after_tool_call_event(agent, tool_use, result))

            call_kwargs = mock_interaction.track_tool.call_args[1]
            assert call_kwargs["duration_ms"] >= 5  # should be at least ~10ms

    def test_track_tool_not_called_without_interaction(self):
        """If begin() fails, track_tool should not be attempted."""
        with patch(MODULE_PATH) as mock_rd:
            mock_rd.begin.side_effect = RuntimeError("begin failed")

            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "test"}]}])
            handler.on_before_invocation(_before_invocation_event(agent))

            tool_use = {"toolUseId": "t-noint", "name": "tool", "input": {}}
            handler.on_before_tool_call(_before_tool_call_event(agent, tool_use))

            result = SimpleNamespace(content=[], status="success")
            handler.on_after_tool_call(_after_tool_call_event(agent, tool_use, result))

            # No interaction means no track_tool call — should not crash
            assert handler._active_tool_spans == 0

    def test_track_tool_exception_does_not_crash(self):
        """If track_tool itself raises, it should be swallowed."""
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_interaction.track_tool.side_effect = RuntimeError("track failed")
            mock_rd.begin.return_value = mock_interaction

            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "test"}]}])
            handler.on_before_invocation(_before_invocation_event(agent))

            tool_use = {"toolUseId": "t-fail", "name": "tool", "input": {}}
            handler.on_before_tool_call(_before_tool_call_event(agent, tool_use))

            result = SimpleNamespace(content=[], status="success")
            # Should not raise
            handler.on_after_tool_call(_after_tool_call_event(agent, tool_use, result))
            assert handler._active_tool_spans == 0

    def test_track_tool_without_matching_before(self):
        """After tool call for an unknown tool_use_id should not crash."""
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction

            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "test"}]}])
            handler.on_before_invocation(_before_invocation_event(agent))

            # After call with no matching before
            tool_use = {"toolUseId": "unknown-id", "name": "ghost"}
            handler.on_after_tool_call(_after_tool_call_event(agent, tool_use, None))

            mock_interaction.track_tool.assert_not_called()

    def test_interaction_finish_called_on_after_invocation(self):
        """interaction.finish() should be called when invocation ends."""
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction

            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "test"}]}])
            handler.on_before_invocation(_before_invocation_event(agent))
            handler.on_after_invocation(_after_invocation_event(agent))

            mock_interaction.finish.assert_called_once()

    def test_interaction_begin_called_with_correct_args(self):
        """begin() should pass user_id, event, event_id, input, convo_id."""
        with patch(MODULE_PATH) as mock_rd:
            mock_rd.begin.return_value = MagicMock()

            handler = _make_client(mock_rd, user_id="u1", convo_id="c1").handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "Hello"}]}])
            handler.on_before_invocation(_before_invocation_event(agent))

            mock_rd.begin.assert_called_once()
            call_kwargs = mock_rd.begin.call_args[1]
            assert call_kwargs["user_id"] == "u1"
            assert call_kwargs["event"] == "ai_generation"
            assert call_kwargs["input"] == "Hello"
            assert call_kwargs["convo_id"] == "c1"
            assert "event_id" in call_kwargs

    def test_multiple_tools_each_tracked(self):
        """Each tool call in an invocation should produce a separate track_tool."""
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction

            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "multi"}]}])
            handler.on_before_invocation(_before_invocation_event(agent))

            for i in range(3):
                tool_use = {"toolUseId": f"mt-{i}", "name": f"tool_{i}", "input": {}}
                handler.on_before_tool_call(_before_tool_call_event(agent, tool_use))
                result = SimpleNamespace(content=[], status="success")
                handler.on_after_tool_call(_after_tool_call_event(agent, tool_use, result))

            assert mock_interaction.track_tool.call_count == 3
            names = [c[1]["name"] for c in mock_interaction.track_tool.call_args_list]
            assert names == ["tool_0", "tool_1", "tool_2"]


class TestFinishReason:
    """Tests for finish_reason capture in on_after_model_call."""

    def test_finish_reason_from_stop_reason(self):
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction
            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "test"}]}])
            handler.on_before_invocation(_before_invocation_event(agent))

            stop_response = SimpleNamespace(
                message=None, usage=None, model=None,
                stop_reason="end_turn",
            )
            handler.on_after_model_call(_after_model_call_event(agent, stop_response=stop_response))
            handler.on_after_invocation(_after_invocation_event(agent))

            kw = mock_interaction.finish.call_args[1]
            assert kw["properties"]["strands.finish_reason"] == "end_turn"

    def test_finish_reason_from_finish_reason_attr(self):
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction
            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "test"}]}])
            handler.on_before_invocation(_before_invocation_event(agent))

            stop_response = SimpleNamespace(
                message=None, usage=None, model=None,
                finish_reason="tool_use",
            )
            handler.on_after_model_call(_after_model_call_event(agent, stop_response=stop_response))
            handler.on_after_invocation(_after_invocation_event(agent))

            kw = mock_interaction.finish.call_args[1]
            assert kw["properties"]["strands.finish_reason"] == "tool_use"

    def test_stop_reason_takes_precedence_over_finish_reason(self):
        """stop_reason is checked first; finish_reason is fallback."""
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction
            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "test"}]}])
            handler.on_before_invocation(_before_invocation_event(agent))

            stop_response = SimpleNamespace(
                message=None, usage=None, model=None,
                stop_reason="end_turn",
                finish_reason="should_not_use",
            )
            handler.on_after_model_call(_after_model_call_event(agent, stop_response=stop_response))
            handler.on_after_invocation(_after_invocation_event(agent))

            kw = mock_interaction.finish.call_args[1]
            assert kw["properties"]["strands.finish_reason"] == "end_turn"

    def test_no_finish_reason_when_absent(self):
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction
            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "test"}]}])
            handler.on_before_invocation(_before_invocation_event(agent))

            stop_response = SimpleNamespace(message=None, usage=None, model=None)
            handler.on_after_model_call(_after_model_call_event(agent, stop_response=stop_response))
            handler.on_after_invocation(_after_invocation_event(agent))

            kw = mock_interaction.finish.call_args[1]
            props = kw.get("properties") or {}
            assert "strands.finish_reason" not in props


class TestExtendedTokenCategories:
    """Tests for cached token extraction from Bedrock/Anthropic responses."""

    def test_cache_read_input_tokens(self):
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction
            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "test"}]}])
            handler.on_before_invocation(_before_invocation_event(agent))

            stop_response = SimpleNamespace(
                message=None, model=None,
                usage={"inputTokens": 100, "outputTokens": 50, "cacheReadInputTokens": 80},
            )
            handler.on_after_model_call(_after_model_call_event(agent, stop_response=stop_response))
            handler.on_after_invocation(_after_invocation_event(agent))

            kw = mock_interaction.finish.call_args[1]
            assert kw["properties"]["ai.usage.cached_tokens"] == 80

    def test_cache_creation_input_tokens_as_fallback(self):
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction
            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "test"}]}])
            handler.on_before_invocation(_before_invocation_event(agent))

            stop_response = SimpleNamespace(
                message=None, model=None,
                usage={"inputTokens": 100, "outputTokens": 50, "cacheCreationInputTokens": 30},
            )
            handler.on_after_model_call(_after_model_call_event(agent, stop_response=stop_response))
            handler.on_after_invocation(_after_invocation_event(agent))

            kw = mock_interaction.finish.call_args[1]
            assert kw["properties"]["ai.usage.cached_tokens"] == 30

    def test_cache_read_preferred_over_creation(self):
        """cacheReadInputTokens should take priority over cacheCreationInputTokens."""
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction
            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "test"}]}])
            handler.on_before_invocation(_before_invocation_event(agent))

            stop_response = SimpleNamespace(
                message=None, model=None,
                usage={
                    "inputTokens": 100, "outputTokens": 50,
                    "cacheReadInputTokens": 80, "cacheCreationInputTokens": 20,
                },
            )
            handler.on_after_model_call(_after_model_call_event(agent, stop_response=stop_response))
            handler.on_after_invocation(_after_invocation_event(agent))

            kw = mock_interaction.finish.call_args[1]
            assert kw["properties"]["ai.usage.cached_tokens"] == 80

    def test_no_cached_tokens_when_absent(self):
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction
            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "test"}]}])
            handler.on_before_invocation(_before_invocation_event(agent))

            stop_response = SimpleNamespace(
                message=None, model=None,
                usage={"inputTokens": 100, "outputTokens": 50},
            )
            handler.on_after_model_call(_after_model_call_event(agent, stop_response=stop_response))
            handler.on_after_invocation(_after_invocation_event(agent))

            kw = mock_interaction.finish.call_args[1]
            assert "ai.usage.cached_tokens" not in (kw.get("properties") or {})


class TestDebugFlag:
    """Tests for the debug=True constructor flag."""

    def test_debug_enables_debug_logging(self):
        import logging
        with patch(MODULE_PATH):
            from raindrop_strands.wrapper import RaindropStrands
            client = RaindropStrands(api_key="test-key", debug=True)
        rd_logger = logging.getLogger("raindrop_strands")
        assert rd_logger.level == logging.DEBUG

    def test_no_debug_does_not_set_debug_level(self):
        import logging
        with patch(MODULE_PATH):
            from raindrop_strands.wrapper import RaindropStrands
            rd_logger = logging.getLogger("raindrop_strands")
            rd_logger.setLevel(logging.WARNING)
            RaindropStrands(api_key="test-key", debug=False)
        assert rd_logger.level == logging.WARNING


class TestToolSpanContextStartTime:
    """Tests that _ToolSpanContext records start_time_ns."""

    def test_tool_span_has_start_time(self):
        from raindrop_strands.wrapper import _ToolSpanContext
        import time as _time

        before = _time.monotonic_ns()
        span = _ToolSpanContext(name="test", input_serialized=None)
        after = _time.monotonic_ns()

        assert before <= span.start_time_ns <= after


class TestEdgeCases:
    """Edge cases: None values, missing attributes, etc."""

    def test_tool_call_with_none_input(self):
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction

            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "test"}]}])
            handler.on_before_invocation(_before_invocation_event(agent))

            tool_use = {"toolUseId": "t-none", "name": "tool", "input": None}
            handler.on_before_tool_call(_before_tool_call_event(agent, tool_use))

            result = SimpleNamespace(content=[], status="success")
            handler.on_after_tool_call(_after_tool_call_event(agent, tool_use, result))

            call_kwargs = mock_interaction.track_tool.call_args[1]
            assert call_kwargs["input"] is None

    def test_tool_call_with_none_name(self):
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction

            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "test"}]}])
            handler.on_before_invocation(_before_invocation_event(agent))

            tool_use = {"toolUseId": "t-noname", "name": None, "input": {}}
            handler.on_before_tool_call(_before_tool_call_event(agent, tool_use))

            result = SimpleNamespace(content=[], status="success")
            handler.on_after_tool_call(_after_tool_call_event(agent, tool_use, result))

            call_kwargs = mock_interaction.track_tool.call_args[1]
            assert call_kwargs["name"] == "unknown"

    def test_tool_output_from_tool_result_attr(self):
        """Output extracted from event.tool_result if present."""
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction

            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "test"}]}])
            handler.on_before_invocation(_before_invocation_event(agent))

            tool_use = {"toolUseId": "t-res", "name": "tool", "input": {}}
            handler.on_before_tool_call(_before_tool_call_event(agent, tool_use))

            event = SimpleNamespace(
                agent=agent, tool_use=tool_use,
                tool_result={"data": "result_value"},
                result=None,
            )
            handler.on_after_tool_call(event)

            call_kwargs = mock_interaction.track_tool.call_args[1]
            assert "result_value" in call_kwargs["output"]

    def test_error_from_string_exception(self):
        """Non-BaseException error should be wrapped in RuntimeError."""
        with patch(MODULE_PATH) as mock_rd:
            mock_interaction = MagicMock()
            mock_rd.begin.return_value = mock_interaction

            handler = _make_client(mock_rd).handler
            agent = _fake_agent([{"role": "user", "content": [{"text": "test"}]}])
            handler.on_before_invocation(_before_invocation_event(agent))

            tool_use = {"toolUseId": "t-strerr", "name": "tool", "input": {}}
            handler.on_before_tool_call(_before_tool_call_event(agent, tool_use))

            event = SimpleNamespace(
                agent=agent, tool_use=tool_use,
                result=None, exception="string error", error=None,
            )
            handler.on_after_tool_call(event)

            call_kwargs = mock_interaction.track_tool.call_args[1]
            assert isinstance(call_kwargs["error"], RuntimeError)
            assert "string error" in str(call_kwargs["error"])
