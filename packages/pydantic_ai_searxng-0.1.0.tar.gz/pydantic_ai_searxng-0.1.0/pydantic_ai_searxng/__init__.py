"""SearXNG web-search tool for Pydantic AI."""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version

from .searxng import (
    SafeSearch,
    SearxngResult,
    SearxngSearchTool,
    TimeRange,
    searxng_search_tool,
)

try:
    __version__ = version("pydantic-ai-searxng")
except PackageNotFoundError:  # pragma: no cover - only used from an unpackaged tree
    __version__ = "0.1.0"


__all__ = [
    "SafeSearch",
    "SearxngResult",
    "SearxngSearchTool",
    "TimeRange",
    "__version__",
    "searxng_search_tool",
]
