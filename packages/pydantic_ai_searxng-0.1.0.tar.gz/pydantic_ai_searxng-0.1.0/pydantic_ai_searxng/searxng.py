from __future__ import annotations

from dataclasses import KW_ONLY, dataclass
from typing import Any, Literal

import httpx
from pydantic import TypeAdapter
from pydantic_ai.tools import Tool
from typing_extensions import NotRequired, TypedDict

__all__ = ("SearxngResult", "SearxngSearchTool", "searxng_search_tool")

SafeSearch = Literal[0, 1, 2]
TimeRange = Literal["day", "week", "month", "year"]


class SearxngResult(TypedDict):
    """A single SearXNG search result."""

    url: str
    """The URL of the result."""
    title: str
    """The title of the result."""
    content: str
    """A short text snippet describing the result."""
    engine: NotRequired[str]
    """The SearXNG engine that produced this result."""
    publishedDate: NotRequired[str]
    """ISO publication date, when reported by the engine."""
    thumbnail: NotRequired[str]
    """Thumbnail URL, when reported by the engine."""


_results_ta = TypeAdapter(list[SearxngResult])


@dataclass
class SearxngSearchTool:
    """The SearXNG search tool implementation."""

    searxng_url: str
    """Base URL of the SearXNG instance (e.g. ``https://searxng.example.com``)."""

    _: KW_ONLY

    client: httpx.AsyncClient
    """The httpx async client used for requests."""

    max_results: int | None = None
    categories: str | None = None
    engines: str | None = None
    language: str | None = None
    safesearch: SafeSearch | None = None
    time_range: TimeRange | None = None
    timeout: float = 30.0

    async def __call__(self, query: str) -> list[SearxngResult]:
        """Search SearXNG for the given query and return the results.

        Args:
            query: The query to search for.
        """
        params: dict[str, Any] = {"q": query, "format": "json"}
        if self.categories is not None:
            params["categories"] = self.categories
        if self.engines is not None:
            params["engines"] = self.engines
        if self.language is not None:
            params["language"] = self.language
        if self.safesearch is not None:
            params["safesearch"] = self.safesearch
        if self.time_range is not None:
            params["time_range"] = self.time_range

        url = self.searxng_url.rstrip("/") + "/search"
        response = await self.client.get(url, params=params, timeout=self.timeout)
        response.raise_for_status()

        content_type = response.headers.get("content-type", "")
        if "application/json" not in content_type:
            raise RuntimeError(
                f"SearXNG instance at {self.searxng_url!r} did not return JSON "
                f"(got Content-Type {content_type!r}). Add `json` to "
                "`search.formats` in the instance settings.yml."
            )

        results = response.json().get("results", [])
        if self.max_results is not None:
            results = results[: self.max_results]
        cleaned = [
            {k: v for k, v in result.items() if v is not None} for result in results
        ]
        return _results_ta.validate_python(cleaned)


def searxng_search_tool(
    searxng_url: str,
    *,
    client: httpx.AsyncClient | None = None,
    max_results: int | None = None,
    categories: str | None = None,
    engines: str | None = None,
    language: str | None = None,
    safesearch: SafeSearch | None = None,
    time_range: TimeRange | None = None,
    timeout: float = 30.0,
) -> Tool[Any]:
    """Create a SearXNG search ``Tool`` for a Pydantic AI agent.

    Args:
        searxng_url: Base URL of the SearXNG instance. The instance must have
            ``json`` listed in ``search.formats`` of its ``settings.yml``;
            JSON is not enabled by default.
        client: Optional ``httpx.AsyncClient`` to reuse for connection pooling.
            A new client is created if not provided.
        max_results: When set, truncate the results list client-side.
        categories: Comma-separated SearXNG categories (e.g. ``general,news``).
        engines: Comma-separated SearXNG engines (e.g. ``google,duckduckgo``).
        language: Result language code (e.g. ``en``, ``en-US``, ``all``).
        safesearch: ``0`` off, ``1`` moderate, ``2`` strict.
        time_range: One of ``day``, ``week``, ``month``, ``year``.
        timeout: Per-request timeout in seconds.
    """
    impl = SearxngSearchTool(
        searxng_url=searxng_url,
        client=client or httpx.AsyncClient(),
        max_results=max_results,
        categories=categories,
        engines=engines,
        language=language,
        safesearch=safesearch,
        time_range=time_range,
        timeout=timeout,
    )
    return Tool[Any](
        impl.__call__,
        name="searxng_search",
        description=(
            "Search the web via a SearXNG instance and return the top results. "
            "Use to ground answers in current information from the public web."
        ),
    )
