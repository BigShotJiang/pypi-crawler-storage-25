"""
CuPy implementation of the F1-score metric for the PyDTNN framework.
"""

import logging
from typing import TYPE_CHECKING

from pydtnn.backends.cupy.metrics.metric import MetricCupy
from pydtnn.backends.numpy.metrics.f1_score import F1ScoreNumpy
from pydtnn.libs import numpy as np

__all__ = ("F1ScoreCupy",)

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    import numpy as np


class F1ScoreCupy(F1ScoreNumpy, MetricCupy):
    """
    F1-score metric implementation using CuPy for GPU-accelerated computation.
    """

    def compute(self, y_pred: np.ndarray, y_targ: np.ndarray) -> float:
        """
        Computes the F1-score based on the confusion matrix statistics.

        Args:
            y_pred: Predicted labels.
            y_targ: Ground truth labels.

        Returns:
            The average F1-score across classes.
        """
        true_positives = self.true_positives
        false_positives = self.false_positives
        false_negatives = self.false_negatives

        # This variable is not necessary, is to make the code more understandable.
        aggregation = false_positives
        f1 = aggregation

        true_positives[:] = self.conf_matrix_metric.get_true_positives()
        false_positives[:] = self.conf_matrix_metric.get_false_positives()
        false_negatives[:] = self.conf_matrix_metric.get_false_negatives()

        # f1 =  2 * true_positives / (2 * true_positives + false_positives + false_negatives
        np.multiply(2, true_positives, out=true_positives)
        np.add(true_positives, false_positives, out=aggregation)
        np.add(aggregation, false_negatives, out=aggregation)

        for i in range(true_positives.shape[0]):
            f1[i] = (true_positives[i] / aggregation[i]) if aggregation[i] != 0 else 0

        return np.average(f1).item()
