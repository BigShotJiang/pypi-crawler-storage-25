"""
Cython-accelerated ReLU activation function implementations for PyDTNN.
"""

import numpy as _np

from pydtnn.backends.cython.utils.base import _npDT, _npDT_1Dims

def relu_cython[T: _npDT](x: _npDT_1Dims[T], max: _npDT_1Dims[T], mask: _np.ndarray[tuple[int], _np.dtype[_np.int8]]) -> None:
    """
    Computes the ReLU activation function in-place.

    Args:
        x (npDT_1Dims): 1-dimensional input's array.
        max (npDT_1Dims): 1-dimensional array where the ouput is stored
        mask (np.ndarray[tuple[int], np.int8]): 1-dimensional array where the output's mask is stored.
    Returns:
        Nothing. The output is stored in "max" and "mask".
    """

def capped_relu_cython[T: _npDT](x: _npDT_1Dims[T], max: _npDT_1Dims[T], mask: _np.ndarray[tuple[int], _np.dtype[_np.int8]], cap: float) -> None:
    """
    ReLU function where the values above "cap"'s value are set as this value.

    Note: if cap is 6, this is a Relu6

    Args:
        x (npDT_1Dims): 1-dimensional input's array.
        max (npDT_1Dims): 1-dimensional array where the ouput is stored
        mask (np.ndarray[tuple[int], np.int8]): 1-dimensional array where the output's mask is stored.
        cap (float): The ReLU's superior limit. Any value in x greater that this parameter will be set to this parameter in the ouput.
    Returns:
        Nothing. The output is stored in "max" and "mask".
    """

def leaky_relu_cython[T: _npDT](x: _npDT_1Dims[T], max: _npDT_1Dims[T], mask: _npDT_1Dims[T], negative_slope: float) -> None:
    """
    Computes the Leaky ReLU activation function in-place.

    Args:
        x (npDT_1Dims): 1-dimensional input's array.
        max (npDT_1Dims): 1-dimensional array where the ouput is stored
        mask (np.ndarray[tuple[int], np.int8]): 1-dimensional array where the output's mask is stored.
        negative_slope (float): The negative value's multiplayer (if is 0, this function acts as a normal ReLU)
    Returns:
        Nothing. The output is stored in "max" and "mask".
    """
