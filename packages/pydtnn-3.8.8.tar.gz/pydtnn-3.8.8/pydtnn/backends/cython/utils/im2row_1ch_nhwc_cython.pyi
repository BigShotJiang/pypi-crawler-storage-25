"""Cython-accelerated utility functions for image-to-row and row-to-image transformations in NHWC format."""

from pydtnn.backends.cython.utils.base import _npDT, _npDT_2Dims, _npDT_4Dims

def im2row_1ch_nhwc_cython[T: _npDT](
    x: _npDT_4Dims[T], rows: _npDT_2Dims[T], kh: int, kw: int, ho: int, wo: int, vpadding: int, hpadding: int, vstride: int, hstride: int, vdilation: int, hdilation: int
) -> None:
    """
    Performs im2row transformation for a single channel NHWC input using Cython.

    Args:
        x (npDT_4Dims): The 4 dimensional array (the image).
        rows (npDT_2Dims): The 2 dimensional array where the image will be stored as rows (it should be initalized with 0s).
        kh (int): Kernel's heigth.
        kw (int): Kernel's width.
        ho (int): Output's heigth.
        wo (int): Output's width.
        vpadding (int): vertical padding value.
        hpadding (int): horizontal padding value.
        vstride (int): vertical stride value.
        hstride (int): horizontal stride value.
        vdilation (int): vertical dilation value.
        hdilation (int): horizontal dilation value.
    Returns:
        Nothing. The output is stored in "rows".
    """

def row2im_1ch_nhwc_cython[T: _npDT](
    rows: _npDT_2Dims[T],
    x: _npDT_4Dims[T],
    n: int,
    h: int,
    w: int,
    c: int,
    kh: int,
    kw: int,
    ho: int,
    wo: int,
    vpadding: int,
    hpadding: int,
    vstride: int,
    hstride: int,
    vdilation: int,
    hdilation: int,
) -> None:
    """
    Performs row2im transformation for a single channel NHWC output using Cython.

    Args:
        rows (npDT_2Dims): The 2 dimensional array (the image as rows).
        x (npDT_4Dims): The 4 dimensional array where the image will be stored (it should be initalized with 0s).
        n (int): Batch size.
        h (int): Input height.
        w (int): Input width.
        c (int): Number of channels.
        kh (int): Kernel's heigth.
        kw (int): Kernel's width.
        ho (int): Output's heigth.
        wo (int): Output's width.
        vpadding (int): vertical padding value.
        hpadding (int): horizontal padding value.
        vstride (int): vertical stride value.
        hstride (int): horizontal stride value.
        vdilation (int): vertical dilation value.
        hdilation (int): horizontal dilation value.
    Returns:
        Nothing. The output is sotred in "x".
    """
