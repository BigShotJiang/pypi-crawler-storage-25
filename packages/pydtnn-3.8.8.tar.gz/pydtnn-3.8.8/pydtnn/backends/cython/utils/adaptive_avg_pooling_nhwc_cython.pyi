"""
Cython-accelerated adaptive average pooling utilities for NHWC tensor layouts.
"""

from pydtnn.backends.cython.utils.base import _npDT, _npDT_4Dims

def adaptive_avg_pooling_fwd_nhwc_cython[T: _npDT](x: _npDT_4Dims[T], pooled_x: _npDT_4Dims[T]) -> None:
    """
    Performs forward adaptive average pooling on NHWC input data.

    Args:
        x (npDT_4Dims): data input.
        pooled_x (npDT_4Dims): ndarray where the output will be stored.
    Returns:
        Nothing; the return is stored in "dx".
    """

def adaptive_avg_pooling_bwd_nhwc_cython[T: _npDT](dy: _npDT_4Dims[T], dx: _npDT_4Dims[T]) -> None:
    """
    Performs backward adaptive average pooling on NHWC input data.

    Args:
        dy (npDT_4Dims): data input.
        dx (npDT_4Dims): ndarray where the output will be stored.
    Returns:
        Nothing; the return is stored in "dx".
    """
