"""
PyDTNN PyCUDA Adam optimizer implementation.
"""

import logging

import numpy as np
from pycuda import gpuarray  # type:ignore
from pycuda.elementwise import ElementwiseKernel  # type:ignore

from pydtnn.backends.pycuda.layers.layer import LayerPycuda
from pydtnn.backends.pycuda.optimizers.optimizer import OptimizerPycuda
from pydtnn.backends.pycuda.utils.tensor_array import TensorArray
from pydtnn.optimizers.adam import Adam
from pydtnn.utils.constants import DTYPE2CTYPE

__all__ = ("AdamPycuda",)

logger = logging.getLogger(__name__)


class AdamPycuda(Adam[TensorArray], OptimizerPycuda):
    """
    PyCUDA implementation of the Adam optimizer.
    """

    def __init__(self, learning_rate=1e-2, beta1=0.99, beta2=0.999, epsilon=1e-7, decay=0.0):
        """
        Initialize the AdamPycuda optimizer.
        """
        super().__init__(learning_rate, beta1, beta2, epsilon, decay)

    def _kernel_init(self) -> None:
        """
        Initialize PyCUDA elementwise kernels for Adam updates.
        """
        func_pow = {np.dtype(np.float32): "powf", np.dtype(np.float64): "pow"}

        # --- GPU ---
        parameters_gpu = "{T} *w, {T} *dw, {T} *m, {T} *v, float it, float lr, float decay, float beta1, float beta2, float epsilon".format(T=DTYPE2CTYPE[self.model.dtype])
        operations_gpu = """
            m[i] = beta1 * m[i] + (1 - beta1) * dw[i];
            v[i] = beta2 * v[i] + (1 - beta2) * {func}(dw[i], 2);
            w[i] -= lr * (decay * w[i] + ((m[i] / (1 - {func}(beta1, it))) / sqrt(v[i] / (1 - {func}(beta2, it)) + epsilon)));
        """.format(func=func_pow[self.model.dtype])

        self.update_kernel = ElementwiseKernel(parameters_gpu, operations_gpu, "Adam_kernel")

        # GPU DIRECT-
        self.defines_replaces: dict[str, str] = {'"TYPE"': DTYPE2CTYPE[self.model.dtype], "powf_or_pow": func_pow[self.model.dtype]}
        self.update_gpudirect = self._get_kernel(func_name_subfix="_gpudirect")

    def _model_init(self, list_layers: list[LayerPycuda]) -> None:
        """
        Initialize optimizer state buffers for each layer on the GPU.
        """
        super()._model_init(list_layers)  # type: ignore (The type is correct: LayerPycuda extends LayerBase)

        for layer in list_layers:
            self.context[layer.id] = dict[str, int | gpuarray.GPUArray]()
            self.context[layer.id]["it"] = 0

            for w_ in layer.grad_vars.keys():
                w = getattr(layer, w_)
                self.context[layer.id]["m_%s" % w_] = gpuarray.zeros(w.shape, dtype=layer.model.dtype)
                self.context[layer.id]["v_%s" % w_] = gpuarray.zeros(w.shape, dtype=layer.model.dtype)

                self.memory_used += self.context[layer.id]["m_%s" % w_].nbytes + self.context[layer.id]["v_%s" % w_].nbytes  # type: ignore (They are both "gpuarray" and not "int")

    def update(self, layer: LayerPycuda):
        """
        Perform a single optimization step for the given layer.
        """
        self.context[layer.id]["it"] += 1  # type: ignore ("it" is an "int".)
        it: int = self.context[layer.id]["it"]  # type: ignore ("it" is an "int".)

        for w_, dw_ in layer.grad_vars.items():
            w, dw = getattr(layer, w_), getattr(layer, dw_)
            m = self.context[layer.id]["m_%s" % w_]
            v = self.context[layer.id]["v_%s" % w_]
            w: TensorArray
            dw: TensorArray
            m: gpuarray.GPUArray
            v: gpuarray.GPUArray

            if self.gpudirect:
                n = self.get_batch_size(w)
                self.update_gpudirect(
                    w.gpudata,
                    dw.ptr_intp,
                    m.gpudata,
                    v.gpudata,
                    np.float32(it),
                    np.float32(self.learning_rate),
                    np.float32(self.decay),
                    np.float32(self.beta1),
                    np.float32(self.beta2),
                    np.float32(self.epsilon),
                    np.int32(n),
                    self.model.cuda_grid,
                    block=self.model.cuda_block,
                    stream=layer.stream_2,
                )
            else:
                self.update_kernel(
                    w.ary,
                    dw.ary,
                    m,
                    v,
                    np.float32(it),
                    np.float32(self.learning_rate),
                    np.float32(self.decay),
                    np.float32(self.beta1),
                    np.float32(self.beta2),
                    np.float32(self.epsilon),
                    stream=layer.stream_2,
                )
            self._dtoh_ary(layer=layer, w_gpu=w, w_cpu=getattr(layer, f"{w_}_cpu"))
