"""
VGG-style neural network architecture for tropical cyclone intensity estimation.
"""

from collections.abc import Sequence

from pydtnn.abstract.layerable import Layerable
from pydtnn.activations.relu import Relu
from pydtnn.layers.conv_2d import Conv2D
from pydtnn.layers.fc import FC
from pydtnn.layers.flatten import Flatten
from pydtnn.layers.input import Input
from pydtnn.layers.max_pool_2d import MaxPool2D
from pydtnn.utils.constants import ArrayShape

__all__ = ("vgg_cyclone",)


def vgg_cyclone(input_shape: ArrayShape, output_shape: ArrayShape) -> Sequence[Layerable]:
    """
    Constructs a VGG-style convolutional neural network for tropical cyclone data.

    Args:
        input_shape: The shape of the input data (channels, height, width).
        output_shape: The shape of the output layer.

    Returns:
        A sequence of layers defining the VGG-cyclone architecture.
    """
    model = list[Layerable]()
    _ = model.append

    _(Input(shape=input_shape))
    conv_pattern = [[3, 3, 1, 64], [2, 3, 1, 128], [2, 3, 1, 256], [3, 3, 1, 512]]
    for nlayers, filter_, padding_, nfilters_ in conv_pattern:
        for layer in range(nlayers):
            _(Conv2D(nfilters=nfilters_, filter_shape=(filter_, filter_), padding=padding_, stride=1, activation=Relu))
        _(MaxPool2D(pool_shape=(2, 2), stride=2))
    _(Flatten())
    _(FC(shape=(512,), activation=Relu))
    _(FC(shape=(256,), activation=Relu))
    _(FC(shape=(128,), activation=Relu))
    _(FC(shape=(64,), activation=Relu))
    _(FC(shape=output_shape))

    return model
