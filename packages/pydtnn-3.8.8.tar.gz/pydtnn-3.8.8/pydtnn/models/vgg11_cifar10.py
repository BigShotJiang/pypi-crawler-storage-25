"""
VGG11 model implementation specifically configured for the CIFAR-10 dataset.
"""

from pydtnn.models.vgg11 import vgg11 as vgg11_cifar10

__all__ = ("vgg11_cifar10",)
