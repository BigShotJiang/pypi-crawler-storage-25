"""
Test suite for PyDTNN convolution layer converters.

This module provides functional tests for various convolution layer types,
including standard, depthwise, and pointwise convolutions, as well as
activation layers, ensuring correct forward and backward pass behavior.
"""

from copy import deepcopy

import numpy as np

from pydtnn.abstract.layerable import Layerable
from pydtnn.activations.leaky_relu import LeakyRelu
from pydtnn.activations.relu6 import Relu6
from pydtnn.backends.pycuda.utils.tensor_array import TensorArray
from pydtnn.layers.conv_2d import Conv2D
from pydtnn.layers.conv_2d_depthwise import Conv2DDepthwise
from pydtnn.layers.conv_2d_pointwise import Conv2DPointwise
from pydtnn.layers.input import Input
from pydtnn.model import Model
from pydtnn.utils import random

try:
    import pycuda.gpuarray as gpuarray  # type: ignore

    from pydtnn.libs import cudnn as cudnn
except BaseException:
    pass

__all__ = ("main",)

# Constants
TENSOR_FORMAT = "NCHW"  # "NCHW" # "NHWC" # "NCHW"
N, C, H, W = 2, 2, 3, 3
SHAPE = (C, H, W) if TENSOR_FORMAT == "NCHW" else (H, W, C)
CONV_IN_CHANNELS = C
CONV_OUT_CHANNELS = 2  # = PyTorch's Number filters
CONV_KERNEL_SIZE = (1, 1)
SEED = 1234
DTYPE = np.float32

KWARGS = {
    "model_name": None,
    "evaluate_only": True,
    "parallel_data": False,
    "tensor_format": TENSOR_FORMAT,
    "enable_cudnn": False,  # True,
    "omm": None,
    "dtype": DTYPE,
    "tracing": False,
    "tracer_output": "",
    "batch_size": min(64, N),
    "optimizer_name": "adam",
}

# End Constants

random.seed(SEED)


def main():
    """
    Executes the main test routine for convolution layers.

    Initializes multiple model configurations, performs forward and backward
    passes through various layer types, and validates output shapes.
    """
    model_I2C = Model(**KWARGS)
    model_DEPTH = Model(**KWARGS)
    model_POINT = Model(**KWARGS)
    model_RELU = Model(**KWARGS)

    shape = (N, *SHAPE)
    dataset = np.arange(np.prod(shape), dtype=DTYPE).reshape(shape)
    dataset *= -1
    dataset *= dataset % 2
    print(f"{dataset=}")
    print(f"{dataset.shape}")

    use_bias = True

    models = [
        ("=============\n==== I2C ====\n=============", model_I2C),
        ("=============\n= POINTWISE =\n=============", model_POINT),
        ("=============\n= DEPTHWISE =\n=============", model_DEPTH),
        ("=============\n= LEAKY RELU =\n=============", model_RELU),
    ]

    for _, model in models:
        model: Model

    model_RELU.add(Input(SHAPE))
    model_RELU.add(LeakyRelu(negative_slope=-32))
    model_RELU.add(Relu6())
    model_RELU._model_init()

    model_DEPTH.add(Input(SHAPE))
    model_DEPTH.add(Conv2DDepthwise(nfilters=CONV_OUT_CHANNELS, filter_shape=CONV_KERNEL_SIZE, use_bias=use_bias))
    model_DEPTH._model_init()

    model_POINT.add(Input(SHAPE))
    model_POINT.add(Conv2DPointwise(nfilters=CONV_OUT_CHANNELS, filter_shape=CONV_KERNEL_SIZE, use_bias=use_bias))
    model_POINT._model_init()

    model_I2C.add(Input(SHAPE))
    model_I2C.add(Conv2D(nfilters=CONV_OUT_CHANNELS, filter_shape=CONV_KERNEL_SIZE, use_bias=use_bias))
    model_I2C._model_init()

    for name, model in models:
        print(f"{name}")

        model.mode = Model.Mode.TRAIN
        # model.show()

        x = deepcopy(dataset)
        if KWARGS["enable_cudnn"]:
            _dataset = TensorArray(gpu_arr=gpuarray.zeros(shape=dataset.shape, dtype=KWARGS["dtype"]), tensor_format=model.tensor_format, cudnn_dtype=model.cudnn_dtype)
            _dataset.set(dataset)
            x = _dataset

        num_layers = len(model.layers)
        print("Forward")
        for i in range(num_layers):
            layer: Layerable = model.layers[i]
            print(f"{layer=}")
            x: np.ndarray | TensorArray = layer.forward(x)
            print(f"{x.shape=}")
        print("\n----------")

        dy = x
        print("Backward")
        for i in range(num_layers - 1, 0, -1):
            layer: Layerable = model.layers[i]
            dy: np.ndarray | TensorArray = layer.backward(dy)
            print(f"{dy.shape=}")
        print("\n=========\n")

        for i in range(num_layers - 1, 0, -1):
            layer: Layerable = model.layers[i]
            layer.update_weights(model.optimizer)


if __name__ == "__main__":
    main()
