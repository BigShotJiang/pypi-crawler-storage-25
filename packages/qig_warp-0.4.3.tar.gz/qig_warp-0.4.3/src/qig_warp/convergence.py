"""
Convergence: Anderson-style stopping and CI stabilization.

Uses the frozen Anderson orthogonality rate to decide when additional
measurements are not worth the cost.

Frozen source: EXP-041 Anderson combined
  α = 0.089356/site (R² = 0.9996)
  ln(|⟨ψ(J₁)|ψ(J₂)⟩|²) = -0.0894×N + 0.1391

Also provides generic stopping rules:
  - CI band stabilization (exponent converges)
  - Discrimination threshold (separation is decisive)
  - Diminishing returns (marginal gain < threshold)
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


# Frozen Anderson constant
ANDERSON_ALPHA = 0.089356  # per site, R² = 0.9996
ANDERSON_INTERCEPT = 0.1391


@dataclass
class StopDecision:
    """Decision from convergence check."""
    should_stop: bool
    reason: str
    metric_value: float
    threshold: float
    n_evaluated: int


def anderson_overlap(N_sites: int, alpha: float = ANDERSON_ALPHA) -> float:
    """Predicted state overlap at N sites from Anderson orthogonality.

    Returns |⟨ψ₁|ψ₂⟩|² = exp(-α×N + intercept)
    """
    return np.exp(-alpha * N_sites + ANDERSON_INTERCEPT)


def anderson_marginal_gain(N_current: int, N_next: int,
                           alpha: float = ANDERSON_ALPHA) -> float:
    """Marginal gain in information from measuring N_next - N_current more sites.

    Returns the fractional change in overlap. When this is small,
    additional measurements provide diminishing returns.
    """
    overlap_current = anderson_overlap(N_current, alpha)
    overlap_next = anderson_overlap(N_next, alpha)
    if overlap_current < 1e-15:
        return 0.0
    return abs(overlap_next - overlap_current) / overlap_current


def check_ci_stabilized(
    values: list[float],
    window: int = 5,
    rel_change_threshold: float = 0.05,
    min_points_before_stop: int = 5,
    min_strong_coupling_points: int = 3,
    strong_coupling_indices: list[int] | None = None,
) -> StopDecision:
    """Check if a running estimate has stabilized (CI band not moving).

    Computes the relative change in the rolling mean over the last `window`
    points. If the mean is changing by less than threshold, stop.

    TIGHTENING #1 (council): Require min_strong_coupling_points at J≥2.5
    before allowing stop. This cuts bias from 5.3% to <2%.

    Args:
        values: Sequence of estimates (e.g., fitted exponents from subsets)
        window: Rolling window size
        rel_change_threshold: Stop if relative change < this
        min_points_before_stop: Minimum total points before stop allowed
        min_strong_coupling_points: Require this many high-J points
        strong_coupling_indices: Which indices are strong-coupling (J≥2.5)

    Returns:
        StopDecision
    """
    n = len(values)
    if n < max(window + 1, min_points_before_stop):
        return StopDecision(
            should_stop=False,
            reason=f"Not enough points ({n} < {max(window + 1, min_points_before_stop)})",
            metric_value=float('inf'),
            threshold=rel_change_threshold,
            n_evaluated=n,
        )

    # TIGHTENING #1: require sufficient strong-coupling representation
    if strong_coupling_indices is not None:
        n_strong = sum(1 for i in strong_coupling_indices if i < n)
        if n_strong < min_strong_coupling_points:
            return StopDecision(
                should_stop=False,
                reason=f"Need {min_strong_coupling_points} strong-coupling points "
                       f"(have {n_strong})",
                metric_value=float('inf'),
                threshold=rel_change_threshold,
                n_evaluated=n,
            )

    recent = np.array(values[-window:])
    previous = np.array(values[-(window + 1):-1])

    mean_recent = np.mean(recent)
    mean_previous = np.mean(previous)

    if abs(mean_previous) < 1e-15:
        rel_change = float('inf')
    else:
        rel_change = abs(mean_recent - mean_previous) / abs(mean_previous)

    return StopDecision(
        should_stop=rel_change < rel_change_threshold,
        reason=f"CI {'stabilized' if rel_change < rel_change_threshold else 'still moving'}: "
               f"Δ={rel_change:.4f} vs threshold={rel_change_threshold}",
        metric_value=rel_change,
        threshold=rel_change_threshold,
        n_evaluated=n,
    )


def check_discrimination(
    signal_values: list[float],
    noise_values: list[float],
    separation_threshold: float = 10.0,
) -> StopDecision:
    """Check if two distributions are decisively separated.

    Used for Lindblad vs unitary purity discrimination:
    stop once the ratio of means exceeds threshold.

    Args:
        signal_values: Values from the signal channel (e.g., Lindblad purity loss)
        noise_values: Values from the noise channel (e.g., unitary purity loss)
        separation_threshold: Stop if signal/noise ratio exceeds this

    Returns:
        StopDecision
    """
    if not signal_values or not noise_values:
        return StopDecision(
            should_stop=False,
            reason="No data",
            metric_value=0.0,
            threshold=separation_threshold,
            n_evaluated=0,
        )

    signal_mean = np.mean(np.abs(signal_values))
    noise_mean = np.mean(np.abs(noise_values))

    if noise_mean < 1e-15:
        ratio = float('inf') if signal_mean > 1e-15 else 0.0
    else:
        ratio = signal_mean / noise_mean

    return StopDecision(
        should_stop=ratio > separation_threshold,
        reason=f"Separation ratio {ratio:.1f} {'>' if ratio > separation_threshold else '<='} "
               f"{separation_threshold} threshold",
        metric_value=ratio,
        threshold=separation_threshold,
        n_evaluated=len(signal_values) + len(noise_values),
    )


def check_diminishing_returns(
    cumulative_values: list[float],
    marginal_threshold: float = 0.01,
) -> StopDecision:
    """Check if adding more data points gives diminishing returns.

    Computes the marginal change from the last point. If below threshold, stop.

    Args:
        cumulative_values: Running estimates as data accumulates
        marginal_threshold: Stop if |v[n] - v[n-1]| / |v[n]| < this
    """
    if len(cumulative_values) < 2:
        return StopDecision(
            should_stop=False,
            reason="Need at least 2 values",
            metric_value=float('inf'),
            threshold=marginal_threshold,
            n_evaluated=len(cumulative_values),
        )

    current = cumulative_values[-1]
    previous = cumulative_values[-2]

    if abs(current) < 1e-15:
        marginal = float('inf')
    else:
        marginal = abs(current - previous) / abs(current)

    return StopDecision(
        should_stop=marginal < marginal_threshold,
        reason=f"Marginal gain {marginal:.4f} {'<' if marginal < marginal_threshold else '>='} "
               f"{marginal_threshold} threshold",
        metric_value=marginal,
        threshold=marginal_threshold,
        n_evaluated=len(cumulative_values),
    )


def find_early_stop_point(
    values: list[float],
    known_answer: float,
    tolerance_pct: float = 5.0,
) -> dict:
    """Find the earliest point where a running fit converges to the known answer.

    Used in replay validation: given a full sequence of accumulated estimates,
    find the first index where the estimate is within tolerance of the final
    known answer and stays there.

    Args:
        values: Running estimates (e.g., fitted exponent after 3,4,5,...,N points)
        known_answer: The correct answer (frozen result)
        tolerance_pct: Percentage tolerance for convergence

    Returns:
        Dict with early_stop_index, n_total, savings_pct
    """
    n = len(values)
    if n == 0:
        return {"early_stop_index": None, "n_total": 0, "savings_pct": 0}

    tol = abs(known_answer) * tolerance_pct / 100

    # Find first index where value is within tolerance AND stays there
    for i in range(n):
        if abs(values[i] - known_answer) <= tol:
            # Check if it stays within tolerance for the rest
            if all(abs(values[j] - known_answer) <= tol for j in range(i, n)):
                return {
                    "early_stop_index": i,
                    "n_total": n,
                    "savings_pct": round((1 - (i + 1) / n) * 100, 1),
                    "value_at_stop": values[i],
                    "known_answer": known_answer,
                    "tolerance_pct": tolerance_pct,
                }

    return {
        "early_stop_index": None,
        "n_total": n,
        "savings_pct": 0,
        "note": "Never converged within tolerance",
    }
