"""
Auto-discovery: OBSERVE → DISCOVER → NAVIGATE
==============================================

Self-calibrating warp bubble. Discovers screening length, cost exponent,
and convergence rate from pilot probes on ANY expensive callable.

No physics knowledge required. The callable is a black box. The bubble
probes it, discovers the structure, and navigates efficiently.

Experimental (v0.4.0e). Source: generalisation of EXP-066 (screening
discovery), EXP-042 (cost scaling), EXP-045 (convergence).

Usage:
    from qig_warp import WarpBubble

    bubble = WarpBubble.auto()
    result = bubble.navigate(
        fn=my_expensive_function,
        params=param_list,
        budget_s=3600,
    )
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field

import numpy as np


@dataclass
class ProbeResult:
    """Result of a single pilot probe."""
    param: float
    value: float
    runtime_s: float
    metadata: dict = field(default_factory=dict)


@dataclass
class DiscoveredConstants:
    """Constants discovered from pilot probes."""
    screening_length: float | None = None
    screening_r2: float | None = None
    cost_exponent: float | None = None
    cost_r2: float | None = None
    convergence_rate: float | None = None
    n_probes: int = 0
    regime_boundaries: list[float] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def is_valid(self) -> bool:
        return self.screening_length is not None or self.cost_exponent is not None


@dataclass
class NavigationPlan:
    """Plan for the full computation based on discovered constants."""
    params_to_run: list[float]
    params_skipped: list[float]
    predicted_total_s: float
    predicted_per_param: dict[float, float]
    early_stop_after: int | None
    savings_pct: float


@dataclass
class NavigationResult:
    """Result of a navigated computation."""
    results: dict[float, float]          # param -> value
    discovered: DiscoveredConstants
    plan: NavigationPlan
    actual_total_s: float
    actual_savings_pct: float
    probes_used: int
    full_evals: int


def _fit_exponential_decay(distances: np.ndarray, values: np.ndarray):
    """Fit |values| ~ A * exp(-d/ξ). Returns (ξ, R²) or (None, None).

    Uses log-linear initial guess + Gauss-Newton refinement.
    polyfit-on-log alone is 28.6% biased (overweights small values).
    Gauss-Newton matches scipy curve_fit to 0.00007%.
    """
    mask = values > 0
    if mask.sum() < 2:
        return None, None

    d = distances[mask]
    v = values[mask]

    if len(d) < 2:
        return None, None

    # Initial guess from log-linear fit
    log_v = np.log(v)
    coeffs = np.polyfit(d, log_v, 1)
    if coeffs[0] >= 0:
        return None, None

    A = float(np.exp(coeffs[1]))
    xi = float(-1.0 / coeffs[0])

    # Gauss-Newton refinement on original (non-log) residuals
    for _ in range(10):
        pred = A * np.exp(-d / xi)
        residuals = v - pred
        J = np.column_stack([
            np.exp(-d / xi),
            A * d / xi**2 * np.exp(-d / xi),
        ])
        try:
            delta = np.linalg.lstsq(J, residuals, rcond=None)[0]
            A += float(delta[0])
            xi += float(delta[1])
            if xi <= 0:
                xi = float(-1.0 / coeffs[0])  # reset to initial
                break
        except np.linalg.LinAlgError:
            break

    # R² on original scale (not log)
    pred = A * np.exp(-d / xi)
    ss_res = float(np.sum((v - pred) ** 2))
    ss_tot = float(np.sum((v - np.mean(v)) ** 2))
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else 0

    return float(xi), float(r2)


def _fit_power_law(params: np.ndarray, costs: np.ndarray):
    """Fit cost ~ A * param^α. Returns (α, R²) or (None, None)."""
    mask = (params > 0) & (costs > 0)
    if mask.sum() < 2:
        return None, None

    log_p = np.log(params[mask])
    log_c = np.log(costs[mask])

    coeffs = np.polyfit(log_p, log_c, 1)
    alpha = coeffs[0]

    predicted = np.polyval(coeffs, log_p)
    ss_res = np.sum((log_c - predicted) ** 2)
    ss_tot = np.sum((log_c - np.mean(log_c)) ** 2)
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else 0

    return float(alpha), float(r2)


def _fit_convergence_rate(estimates: list[float]):
    """Fit |estimate[i] - estimate[-1]| ~ A * exp(-rate * i). Returns rate or None.

    Uses Gauss-Newton refinement (same fix as screening decay).
    """
    if len(estimates) < 3:
        return None

    final = estimates[-1]
    diffs = np.array([abs(e - final) for e in estimates[:-1]])
    indices = np.arange(len(diffs), dtype=float)

    mask = diffs > 0
    if mask.sum() < 2:
        return None

    d = diffs[mask]
    idx = indices[mask]

    # Log-linear initial guess
    log_d = np.log(d)
    coeffs = np.polyfit(idx, log_d, 1)
    rate = -coeffs[0]
    A = np.exp(coeffs[1])

    if rate <= 0:
        return None

    # Gauss-Newton refinement
    for _ in range(10):
        pred = A * np.exp(-rate * idx)
        residuals = d - pred
        J = np.column_stack([
            np.exp(-rate * idx),
            -A * idx * np.exp(-rate * idx),
        ])
        try:
            delta = np.linalg.lstsq(J, residuals, rcond=None)[0]
            A += float(delta[0])
            rate += float(delta[1])
            if rate <= 0:
                rate = -coeffs[0]
                break
        except np.linalg.LinAlgError:
            break

    return float(rate) if rate > 0 else None


def observe(fn, params: list[float], n_probes: int = 5) -> list[ProbeResult]:
    """Phase 1: Run pilot probes.

    Selects probe points spanning the parameter range.
    Records value and runtime for each.
    """
    if not params:
        return []
    params = sorted(params)
    n = min(n_probes, len(params))

    # Select evenly spaced probe indices
    if n <= 1 or n >= len(params):
        probe_indices = list(range(len(params)))
    else:
        probe_indices = [int(i * (len(params) - 1) / (n - 1)) for i in range(n)]
        probe_indices = sorted(set(probe_indices))

    probes = []
    for idx in probe_indices:
        p = params[idx]
        t0 = time.time()
        try:
            value = fn(p)
            runtime = time.time() - t0
            probes.append(ProbeResult(param=p, value=float(value), runtime_s=runtime))
        except Exception as e:
            probes.append(ProbeResult(
                param=p, value=float("nan"), runtime_s=time.time() - t0,
                metadata={"error": str(e)}
            ))

    return probes


def observe_screening(fn, center_param: float, deltas: list[float] | None = None):
    """Probe the screening structure: perturb at center, measure response at distances.

    fn should accept (param, perturbation_distance) and return response magnitude.
    If fn only takes one param, we estimate screening from the parameter-space
    gradient of the output.
    """
    if deltas is None:
        deltas = [0.1, 0.2, 0.5, 1.0, 2.0]

    distances = []
    responses = []

    base_value = fn(center_param)

    for delta in deltas:
        try:
            perturbed_value = fn(center_param + delta)
            response = abs(perturbed_value - base_value)
            distances.append(delta)
            responses.append(response)
        except Exception:
            continue

    return np.array(distances), np.array(responses)


def discover(probes: list[ProbeResult],
             screening_distances: np.ndarray | None = None,
             screening_responses: np.ndarray | None = None) -> DiscoveredConstants:
    """Phase 2: Discover constants from pilot data."""
    dc = DiscoveredConstants(n_probes=len(probes))

    # Cost exponent from runtime vs parameter
    valid = [p for p in probes if not np.isnan(p.value) and p.runtime_s > 0]
    if len(valid) >= 3:
        params = np.array([p.param for p in valid])
        costs = np.array([p.runtime_s for p in valid])
        alpha, r2 = _fit_power_law(params, costs)
        dc.cost_exponent = round(alpha, 4) if alpha is not None else None
        dc.cost_r2 = round(r2, 4) if r2 is not None else None

    # Screening from perturbation response
    if screening_distances is not None and screening_responses is not None:
        xi, r2 = _fit_exponential_decay(screening_distances, screening_responses)
        dc.screening_length = round(xi, 4) if xi is not None else None
        dc.screening_r2 = round(r2, 4) if r2 is not None else None

    # Convergence from cumulative estimates
    if len(valid) >= 3:
        estimates = [p.value for p in valid]
        rate = _fit_convergence_rate(estimates)
        dc.convergence_rate = round(rate, 4) if rate is not None else None

    # Regime detection: check if cost exponent changes across the domain
    if len(valid) >= 6:
        mid = len(valid) // 2
        first_half = valid[:mid]
        second_half = valid[mid:]
        p1 = np.array([p.param for p in first_half])
        c1 = np.array([p.runtime_s for p in first_half])
        p2 = np.array([p.param for p in second_half])
        c2 = np.array([p.runtime_s for p in second_half])
        a1, _ = _fit_power_law(p1, c1)
        a2, _ = _fit_power_law(p2, c2)
        if a1 is not None and a2 is not None and abs(a1 - a2) > 0.3:
            boundary = (valid[mid - 1].param + valid[mid].param) / 2
            dc.regime_boundaries = [boundary]
            dc.warnings.append(
                f"Regime boundary detected at param≈{boundary:.2f}: "
                f"α={a1:.2f} below, α={a2:.2f} above"
            )

    return dc


def plan(params: list[float], discovered: DiscoveredConstants,
         budget_s: float | None = None,
         baseline_runtime: float | None = None) -> NavigationPlan:
    """Phase 3a: Create navigation plan from discovered constants."""
    params = sorted(params)

    # Predict cost per param
    predicted = {}
    if discovered.cost_exponent is not None and baseline_runtime is not None:
        base_param = params[0]
        for p in params:
            ratio = (p / base_param) ** discovered.cost_exponent if base_param > 0 else 1.0
            predicted[p] = baseline_runtime * ratio
    elif baseline_runtime is not None:
        for p in params:
            predicted[p] = baseline_runtime
    else:
        for p in params:
            predicted[p] = 1.0  # unknown

    # Apply budget constraint
    total_predicted = sum(predicted.values())
    if budget_s is not None and total_predicted > budget_s:
        # Sort by cost, keep cheapest first until budget exhausted
        by_cost = sorted(predicted.items(), key=lambda x: x[1])
        cumulative = 0.0
        to_run = []
        to_skip = []
        for p, cost in by_cost:
            if cumulative + cost <= budget_s:
                to_run.append(p)
                cumulative += cost
            else:
                to_skip.append(p)
        to_run.sort()
        to_skip.sort()
    else:
        to_run = list(params)
        to_skip = []

    # Early stopping from convergence rate
    early_stop = None
    if discovered.convergence_rate is not None and discovered.convergence_rate > 0.1:
        # Estimate: need ~5/rate evaluations to converge
        early_stop = max(3, int(5.0 / discovered.convergence_rate))
        if early_stop < len(to_run):
            pass  # will check during execution
        else:
            early_stop = None

    savings = len(to_skip) / len(params) * 100 if params else 0

    return NavigationPlan(
        params_to_run=to_run,
        params_skipped=to_skip,
        predicted_total_s=sum(predicted[p] for p in to_run),
        predicted_per_param=predicted,
        early_stop_after=early_stop,
        savings_pct=round(savings, 1),
    )


def navigate(fn, params: list[float], budget_s: float | None = None,
             n_probes: int = 5, screening_fn=None) -> NavigationResult:
    """Full OBSERVE → DISCOVER → NAVIGATE pipeline.

    Args:
        fn: Callable that takes a parameter value and returns a result.
        params: List of parameter values to evaluate.
        budget_s: Maximum total runtime budget in seconds. None = unlimited.
        n_probes: Number of pilot probes (default 5).
        screening_fn: Optional callable(center, delta) -> response for screening.

    Returns:
        NavigationResult with results, discovered constants, and savings.
    """
    t_total = time.time()

    # Phase 1: OBSERVE
    probes = observe(fn, params, n_probes=n_probes)

    # Screening probes (if fn supports it)
    scr_d, scr_r = None, None
    if screening_fn is not None:
        center = params[len(params) // 2]
        scr_d, scr_r = observe_screening(screening_fn, center)

    # Phase 2: DISCOVER
    discovered = discover(probes, scr_d, scr_r)

    # Get baseline runtime from probes
    valid_probes = [p for p in probes if not np.isnan(p.value)]
    baseline = valid_probes[0].runtime_s if valid_probes else 1.0

    # Phase 3a: PLAN
    nav_plan = plan(params, discovered, budget_s=budget_s, baseline_runtime=baseline)

    # Phase 3b: EXECUTE
    results = {}

    # Include probe results (already computed, don't rerun)
    probe_params = {p.param for p in valid_probes}
    for p in valid_probes:
        results[p.param] = p.value

    # Run remaining params
    converged = False
    recent_values = list(results.values())
    full_evals = 0

    for p in nav_plan.params_to_run:
        if p in results:
            continue  # already have from probes

        t0 = time.time()
        try:
            value = fn(p)
            results[p] = float(value)
            full_evals += 1
            recent_values.append(float(value))
        except Exception:
            continue

        # Check early stopping
        if nav_plan.early_stop_after and full_evals >= nav_plan.early_stop_after:
            if len(recent_values) >= 3:
                last_3 = recent_values[-3:]
                if max(last_3) - min(last_3) < 0.01 * abs(np.mean(last_3)):
                    converged = True
                    break

    actual_total = time.time() - t_total

    # Calculate actual savings vs running everything
    naive_estimate = baseline * len(params) if baseline > 0 else actual_total
    actual_savings = (1 - actual_total / naive_estimate) * 100 if naive_estimate > 0 else 0

    return NavigationResult(
        results=results,
        discovered=discovered,
        plan=nav_plan,
        actual_total_s=round(actual_total, 2),
        actual_savings_pct=round(max(0, actual_savings), 1),
        probes_used=len(valid_probes),
        full_evals=full_evals,
    )
