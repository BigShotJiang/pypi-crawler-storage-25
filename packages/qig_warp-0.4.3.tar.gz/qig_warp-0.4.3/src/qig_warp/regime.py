"""
Regime classification and regime-dependent constants.

New in v0.4.0: The warp bubble's constants are regime-dependent.
Single-calibration frozen mode (v0.3.0) used one set of constants.
Regime-aware mode selects constants based on h/J ratio.

Source: EXP-035-E, EXP-042-E, EXP-079 (2026-04-10 sweep execution)

Three regimes for 2D TFIM (h_c ≈ 3.04J for square lattice PBC):
  ORDERED:    h/J < 0.8 * h_c  — stiffer springs, fast oscillations
  CRITICAL:   0.8 * h_c <= h/J <= 1.2 * h_c  — richest dynamics, bridge strongest
  DISORDERED: h/J > 1.2 * h_c  — lighter effective mass, slow oscillations

For 1D TFIM: h_c = J (exact).
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

import numpy as np


# Critical field ratios (h_c / J) by dimensionality
# 2D square lattice PBC: Kramers-Wannier duality gives h_c/J ≈ 3.044
# 1D chain: exact h_c/J = 1.0
CRITICAL_RATIO_2D = 3.044
CRITICAL_RATIO_1D = 1.0


class Regime(Enum):
    """Dynamical regime classification."""
    ORDERED = "ordered"        # h/J well below critical — stiffer, faster ω
    CRITICAL = "critical"      # h/J near critical — bridge strongest, ξ ≈ 1/φ
    DISORDERED = "disordered"  # h/J well above critical — lighter, slower ω


@dataclass
class RegimeConstants:
    """Regime-dependent navigation constants."""
    regime: Regime
    screening_length: float   # ξ_G
    bridge_exponent: float    # α in τ ~ J^α
    gr_direction: str         # "heavy_faster" or "heavy_slower"
    confidence: str           # "high" / "medium" / "low"


# Calibration table from EXP-079 (screening) and EXP-042-E (bridge)
# All at L=4, 2D torus, J=1.0
_SCREENING_TABLE_L4 = {
    # h: (ξ_G, ξ_T, ξ_G/ξ_T, R²_G, R²_T)
    1.0: (0.503, 0.384, 1.31, 0.78, 0.99),
    1.5: (0.944, 0.563, 1.68, 0.76, 0.99),
    2.0: (2.043, 0.824, 2.48, 0.89, 0.98),
    3.0: (0.784, 1.122, 0.70, 0.62, 0.96),
}

# Bridge exponent from EXP-042-E (L=4, 2D torus)
# At h=1.0: α_X ≈ 0 (flat), α_E ≈ 0.38 (J≥2.0 only)
# At h=3.0: α ≈ 0.86 (frozen EXP-042)
_BRIDGE_TABLE = {
    # h: (α_X, α_E, α_best, source)
    1.0: (0.0, 0.38, 0.38, "EXP-042-E, J≥2.0, E-channel"),
    3.0: (0.86, None, 0.86, "EXP-042/050, frozen"),
}

# GR direction from EXP-035-E (1D, but direction generalises)
_GR_DIRECTION = {
    # regime: direction
    Regime.ORDERED: "heavy_faster",     # anti-GR
    Regime.CRITICAL: "transitional",    # crossover region
    Regime.DISORDERED: "heavy_slower",  # GR-consistent
}


def classify_regime(h: float, J: float, dim: int = 2) -> Regime:
    """Classify the dynamical regime from field and coupling.

    Args:
        h: Transverse field strength
        J: Coupling strength (use mean J if inhomogeneous)
        dim: Spatial dimension (1 or 2)

    Returns:
        Regime enum value
    """
    h_c_ratio = CRITICAL_RATIO_2D if dim == 2 else CRITICAL_RATIO_1D
    ratio = h / J if J > 0 else float("inf")

    if ratio < 0.8 * h_c_ratio:
        return Regime.ORDERED
    elif ratio > 1.2 * h_c_ratio:
        return Regime.DISORDERED
    else:
        return Regime.CRITICAL


def regime_constants(h: float, J: float = 1.0, dim: int = 2) -> RegimeConstants:
    """Get regime-dependent navigation constants.

    Interpolates screening length from calibration table.
    Selects bridge exponent by regime.

    Args:
        h: Transverse field
        J: Coupling (default 1.0)
        dim: Spatial dimension

    Returns:
        RegimeConstants with regime-appropriate values
    """
    regime = classify_regime(h, J, dim)

    # Screening: interpolate from table
    # Table calibrated at J=1. For J≠1, look up at equivalent h for J=1.
    # h/J gives the same physics as h at J=1 (TFIM scaling symmetry).
    xi = _interpolate_screening(h / J)  # normalised field strength

    # Bridge exponent
    if regime == Regime.CRITICAL:
        alpha = 0.86  # strongest near h_c
        confidence = "high"
    elif regime == Regime.ORDERED:
        alpha = 0.0   # flat far from critical
        confidence = "medium"
    else:  # DISORDERED
        alpha = 0.38  # weak bridge in E channel
        confidence = "low"

    return RegimeConstants(
        regime=regime,
        screening_length=xi,
        bridge_exponent=alpha,
        gr_direction=_GR_DIRECTION[regime],
        confidence=confidence,
    )


def _interpolate_screening(h: float) -> float:
    """Interpolate screening length from calibration table."""
    from qig_warp.screening import PHI_INV

    table_h = sorted(_SCREENING_TABLE_L4.keys())
    table_xi = [_SCREENING_TABLE_L4[hv][0] for hv in table_h]

    if h <= table_h[0]:
        return table_xi[0]
    if h >= table_h[-1]:
        return table_xi[-1]

    # Linear interpolation
    for i in range(len(table_h) - 1):
        if table_h[i] <= h <= table_h[i + 1]:
            frac = (h - table_h[i]) / (table_h[i + 1] - table_h[i])
            return table_xi[i] + frac * (table_xi[i + 1] - table_xi[i])

    return PHI_INV  # fallback
