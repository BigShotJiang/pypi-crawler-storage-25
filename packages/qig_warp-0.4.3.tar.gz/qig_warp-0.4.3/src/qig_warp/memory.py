"""
Geometric memory for navigation — basin tracking and recall.

Embedded from QIGRAM. Stores observation basins (parameter-space coordinates),
recalls by Fisher-Rao proximity, integrates new observations with precession.

Two modes:
  - Frozen mode: constants from physics (screening=1/φ, bridge=0.74, Anderson=0.089)
  - Learning mode: calibrate from first measurements (fits screening, cost, convergence)

The memory accumulates observations and refines navigation over time.
Frozen values are the prior. Learned values are the posterior.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np

# Geometry backend: prefer qig-core (single source of truth), fallback to numpy
try:
    from qig_core.geometry.fisher_rao import fisher_rao_distance as fisher_rao, slerp_sqrt as slerp
except ImportError:
    # Minimal fallback for environments without qig-core
    import math

    def fisher_rao(p, q) -> float:
        p_arr = np.maximum(np.asarray(p, dtype=float).ravel(), 1e-15)
        q_arr = np.maximum(np.asarray(q, dtype=float).ravel(), 1e-15)
        p_arr /= p_arr.sum(); q_arr /= q_arr.sum()
        n = min(len(p_arr), len(q_arr))
        bc = float(np.sum(np.sqrt(p_arr[:n] * q_arr[:n])))
        return float(np.arccos(np.clip(bc, -1.0, 1.0)))

    def slerp(p, q, t: float):
        p_s = np.sqrt(np.maximum(np.asarray(p, dtype=float).ravel(), 1e-15))
        q_s = np.sqrt(np.maximum(np.asarray(q, dtype=float).ravel(), 1e-15))
        n = min(len(p_s), len(q_s)); p_s, q_s = p_s[:n], q_s[:n]
        p_s /= np.sqrt(p_s @ p_s); q_s /= np.sqrt(q_s @ q_s)
        cos_w = float(np.clip(p_s @ q_s, -1.0, 1.0))
        w = math.acos(cos_w)
        if w < 1e-10:
            return list(p_s ** 2)
        sw = math.sin(w)
        r = (math.sin((1-t)*w)/sw) * p_s + (math.sin(t*w)/sw) * q_s
        r = r ** 2; r /= r.sum()
        return list(r)

PRECESSION_WEIGHT = 0.14159 / 3.14159265  # ~0.04507


@dataclass
class Basin:
    """A stored observation in parameter space."""
    coords: list[float]       # parameter-space coordinates (normalised)
    value: float              # observed value (e.g., ξ, τ, κ)
    cost: float = 0.0         # wall-clock or compute cost
    weight: float = 1.0       # geometric confidence
    metadata: dict = field(default_factory=dict)


class NavigationMemory:
    """Geometric working memory for the warp bubble.

    Stores basins (parameter-space observations), recalls nearest by
    Fisher-Rao distance, integrates new observations with precession.

    In learning mode, calibrates screening length, cost exponent, and
    convergence rate from accumulated observations.
    """

    DECAY_FACTOR = 0.95

    def __init__(self):
        self.basins: dict[str, Basin] = {}
        self.observation_log: list[dict] = []

    def store(self, key: str, coords, value: float, cost: float = 0.0,
              weight: float = 1.0, metadata: dict | None = None):
        """Store an observation basin.

        If key exists, slerp toward new observation (precession).
        """
        coords_list = list(np.asarray(coords, dtype=float).ravel())

        if key in self.basins:
            old = self.basins[key]
            # Precession: slerp existing coords toward new
            if len(old.coords) == len(coords_list):
                new_coords = slerp(old.coords, coords_list, PRECESSION_WEIGHT)
            else:
                new_coords = coords_list
            self.basins[key] = Basin(
                coords=new_coords,
                value=value,
                cost=cost,
                weight=max(old.weight, weight),
                metadata=metadata or {},
            )
        else:
            self.basins[key] = Basin(
                coords=coords_list,
                value=value,
                cost=cost,
                weight=weight,
                metadata=metadata or {},
            )

        self.observation_log.append({
            "key": key, "value": value, "cost": cost, "n_total": len(self.basins),
        })

    def recall(self, query_coords) -> Optional[dict]:
        """Find nearest stored basin by Fisher-Rao distance."""
        if not self.basins:
            return None

        query = list(np.asarray(query_coords, dtype=float).ravel())
        nearest_key = None
        nearest_dist = float('inf')

        for key, basin in self.basins.items():
            if basin.weight < 0.01:
                continue
            if len(basin.coords) != len(query):
                continue
            d = fisher_rao(query, basin.coords)
            if d < nearest_dist:
                nearest_dist = d
                nearest_key = key

        if nearest_key is None:
            return None

        b = self.basins[nearest_key]
        return {
            "key": nearest_key,
            "d_FR": round(nearest_dist, 6),
            "value": b.value,
            "cost": b.cost,
            "weight": b.weight,
        }

    def decay_all(self):
        """Apply per-step decay to all weights."""
        for b in self.basins.values():
            b.weight *= self.DECAY_FACTOR

    def calibrate_screening(self) -> Optional[float]:
        """Learn screening length from stored distance-value pairs.

        Fits |value| ~ A * exp(-d/ξ) to the observation log.
        Returns ξ or None if insufficient data.
        """
        from scipy.optimize import curve_fit

        if len(self.basins) < 3:
            return None

        # Use basins that have 'distance' in metadata
        ds, vs = [], []
        for b in self.basins.values():
            d = b.metadata.get("distance")
            if d is not None and d > 0:
                ds.append(float(d))
                vs.append(abs(b.value))

        if len(ds) < 2:
            return None

        ds_arr = np.array(ds)
        vs_arr = np.array(vs)

        try:
            def exp_decay(r, A, xi):
                return A * np.exp(-r / xi)
            popt, _ = curve_fit(exp_decay, ds_arr, vs_arr, p0=[vs_arr[0], 0.6], maxfev=5000)
            return float(popt[1])
        except Exception:
            return None

    def calibrate_bridge(self) -> Optional[float]:
        """Learn bridge exponent from stored J-tau pairs.

        Fits tau ~ A * J^alpha to basins with 'J' in metadata.
        Returns alpha or None.
        """
        from scipy.optimize import curve_fit

        Js, taus = [], []
        for b in self.basins.values():
            J = b.metadata.get("J")
            if J is not None and J > 0:
                Js.append(float(J))
                taus.append(abs(b.value))

        if len(Js) < 3:
            return None

        try:
            def power_law(J, A, alpha):
                return A * J ** alpha
            popt, _ = curve_fit(power_law, np.array(Js), np.array(taus),
                                p0=[0.2, 0.7], maxfev=5000)
            return float(popt[1])
        except Exception:
            return None

    @property
    def n_observations(self) -> int:
        return len(self.basins)

    @property
    def sovereignty(self) -> float:
        """Fraction of basins that are active (weight > 0.01)."""
        if not self.basins:
            return 0.0
        active = sum(1 for b in self.basins.values() if b.weight > 0.01)
        return active / len(self.basins)
