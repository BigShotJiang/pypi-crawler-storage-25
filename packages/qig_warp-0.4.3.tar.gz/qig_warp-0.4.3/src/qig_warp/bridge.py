"""
Bridge: τ ~ J^α → cost prediction and sweep planning.

Uses the frozen bridge law to predict runtime/cost of expensive
computations as a function of coupling strength J.

Frozen source: EXP-050 combined bridge fit
  τ_phase = 0.1975 × J^0.7415, R² = 0.967
  τ_discrete = 0.156 × J^0.9436, R² = 0.951
  ω = 7.1303 × J^1.0752, R² = 0.999

Source data: 36 points (seed 42 + 43), strong coupling J≥1.5, uncensored.

L-dependence: The frozen constant α=0.7415 was calibrated at L=5.
  L=5 gives α=0.74, L=4 gives α=0.97. The frozen constant is L=5-specific.
  When using predict_tau() or predict_runtime() at L≠5, a warning is emitted
  because the bridge exponent may differ significantly.
"""

from __future__ import annotations

import warnings
from dataclasses import dataclass

import numpy as np


# Frozen bridge constants
BRIDGE_EXPONENT = 0.7415       # τ_phase ~ J^α
BRIDGE_PREFACTOR = 0.1975      # τ_phase = prefactor × J^α
BRIDGE_CI_LOW = 0.69           # 95% CI lower bound on exponent
BRIDGE_CI_HIGH = 0.81          # 95% CI upper bound on exponent
OMEGA_EXPONENT = 1.0752        # ω ~ J^β (transport law)
OMEGA_PREFACTOR = 7.1303


@dataclass
class CostPrediction:
    """Predicted cost for a computation at given parameters."""
    J: float
    predicted_tau: float           # bridge-predicted τ
    predicted_runtime_s: float     # estimated wall-clock seconds
    cost_relative: float           # cost relative to J=1.0 baseline
    confidence_band: tuple[float, float]  # (low, high) from CI


def predict_tau(J: float, exponent: float = BRIDGE_EXPONENT,
                prefactor: float = BRIDGE_PREFACTOR,
                L: int = 5) -> float:
    """Predict τ from bridge law at coupling J.

    Args:
        J: Coupling strength
        exponent: Bridge exponent (default: frozen 0.7415 from L=5)
        prefactor: Bridge prefactor (default: frozen 0.1975 from L=5)
        L: Lattice size. The frozen constants were calibrated at L=5.
           L=5 gives α=0.74, L=4 gives α=0.97. A warning is emitted
           when L≠5 and the default exponent is used.
    """
    if L != 5 and exponent == BRIDGE_EXPONENT:
        warnings.warn(
            f"predict_tau called with L={L} but using frozen exponent "
            f"α={BRIDGE_EXPONENT} calibrated at L=5. "
            f"L=5 gives α=0.74, L=4 gives α=0.97. "
            f"Results may be inaccurate for L≠5.",
            stacklevel=2,
        )
    return prefactor * J ** exponent


def predict_cost_ratio(J: float, J_ref: float = 1.0) -> float:
    """Predict relative cost of J vs J_ref from bridge scaling.

    Cost scales as J^α where α = 0.7415 (frozen).
    """
    if J_ref <= 0:
        return float('inf')
    return (J / J_ref) ** BRIDGE_EXPONENT


def predict_runtime(
    J: float,
    baseline_runtime_s: float,
    baseline_J: float = 1.0,
    L: int = 5,
) -> CostPrediction:
    """Predict runtime at coupling J given a baseline measurement.

    Args:
        J: Target coupling strength
        baseline_runtime_s: Measured runtime at baseline_J
        baseline_J: Coupling where baseline was measured
        L: Lattice size. The frozen constants were calibrated at L=5.
           A warning is emitted when L≠5. See predict_tau() docstring.

    Returns:
        CostPrediction with estimated runtime and confidence band
    """
    if L != 5:
        warnings.warn(
            f"predict_runtime called with L={L} but using frozen bridge "
            f"exponent α={BRIDGE_EXPONENT} calibrated at L=5. "
            f"L=5 gives α=0.74, L=4 gives α=0.97. "
            f"Results may be inaccurate for L≠5.",
            stacklevel=2,
        )
    ratio = predict_cost_ratio(J, baseline_J)
    predicted = baseline_runtime_s * ratio

    # Confidence band from CI on exponent
    ratio_low = (J / baseline_J) ** BRIDGE_CI_LOW
    ratio_high = (J / baseline_J) ** BRIDGE_CI_HIGH
    band = (baseline_runtime_s * min(ratio_low, ratio_high),
            baseline_runtime_s * max(ratio_low, ratio_high))

    return CostPrediction(
        J=J,
        predicted_tau=predict_tau(J, L=L),
        predicted_runtime_s=predicted,
        cost_relative=ratio,
        confidence_band=band,
    )


def budget_sweep(
    J_values: list[float],
    baseline_runtime_s: float,
    baseline_J: float = 1.0,
    max_total_s: float | None = None,
) -> dict:
    """Budget a J-sweep: predict total cost and flag over-budget points.

    Args:
        J_values: List of J values to sweep
        baseline_runtime_s: Measured runtime at baseline_J
        baseline_J: Reference coupling
        max_total_s: Maximum total budget in seconds (None = no limit)

    Returns:
        Dict with per-point predictions, total, and flagged points
    """
    predictions = []
    total_predicted = 0.0

    for J in sorted(J_values):
        pred = predict_runtime(J, baseline_runtime_s, baseline_J)
        predictions.append(pred)
        total_predicted += pred.predicted_runtime_s

    flagged = []
    if max_total_s is not None:
        cumulative = 0.0
        for pred in predictions:
            cumulative += pred.predicted_runtime_s
            if cumulative > max_total_s:
                flagged.append(pred.J)

    return {
        "predictions": predictions,
        "total_predicted_s": total_predicted,
        "total_predicted_h": total_predicted / 3600,
        "n_points": len(J_values),
        "flagged_over_budget": flagged,
        "budget_s": max_total_s,
    }


def validate_bridge_law(
    J_values: list[float],
    measured_taus: list[float],
    measured_runtimes_s: list[float] | None = None,
) -> dict:
    """Validate bridge law against measured data.

    Returns fit quality, predicted vs measured, and residuals.
    """
    J_arr = np.array(J_values)
    tau_arr = np.array(measured_taus)

    # Predict from frozen law
    predicted = np.array([predict_tau(J) for J in J_values])

    # Residuals
    residuals = tau_arr - predicted
    rel_errors = np.abs(residuals) / np.maximum(np.abs(tau_arr), 1e-15)

    result = {
        "n_points": len(J_values),
        "mean_abs_error": float(np.mean(np.abs(residuals))),
        "mean_rel_error_pct": float(np.mean(rel_errors) * 100),
        "max_rel_error_pct": float(np.max(rel_errors) * 100),
        "per_point": [
            {"J": float(J), "measured": float(m), "predicted": float(p),
             "residual": float(r), "rel_error_pct": float(re * 100)}
            for J, m, p, r, re in zip(J_values, tau_arr, predicted, residuals, rel_errors)
        ],
    }

    # If runtime data available, validate cost prediction
    if measured_runtimes_s is not None:
        rt_arr = np.array(measured_runtimes_s)
        # Use first point as baseline
        baseline_rt = rt_arr[0]
        baseline_J = J_values[0]
        predicted_rts = np.array([
            predict_runtime(J, baseline_rt, baseline_J).predicted_runtime_s
            for J in J_values
        ])
        rt_residuals = rt_arr - predicted_rts
        rt_rel = np.abs(rt_residuals) / np.maximum(rt_arr, 1e-15)
        result["runtime_validation"] = {
            "baseline_J": baseline_J,
            "baseline_runtime_s": float(baseline_rt),
            "mean_runtime_error_pct": float(np.mean(rt_rel) * 100),
            "max_runtime_error_pct": float(np.max(rt_rel) * 100),
        }

    return result
