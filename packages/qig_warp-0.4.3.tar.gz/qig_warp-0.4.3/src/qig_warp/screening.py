"""
Screening: Yukawa locality → spatial pruning.

Uses the frozen screening length ξ to decide which sites/shells
need measuring and which are already below noise floor.

Frozen source: EXP-066 Yukawa kernel
  L=4: ξ = 0.85, R² = 0.957
  L=5: ξ = 0.6182 ≈ 1/φ, R² = 0.990

Validated: d≤3 pruning deviates <2.1% (L=4), <0.3% (L=5).
           d≤2 pruning FAILS (8-20% deviation).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import numpy as np

PHI_INV = 2 / (1 + np.sqrt(5))  # 1/φ = 0.6180339...

# TIGHTENING #5 (council): rolling audit config
AUDIT_EVERY_N_RUNS = 5        # spot-check predicted sites every N runs
AUDIT_N_SITES = 2             # number of predicted sites to spot-check


@dataclass
class PruningResult:
    """Result of spatial pruning."""
    selected_sites: list[tuple[int, int, int]]  # (ed_index, row, col)
    distances: list[int]                         # distance per selected site
    n_selected: int
    n_total: int
    max_distance: int
    sites_by_distance: dict[int, int]            # d → count


def manhattan_distance_pbc(r1: int, c1: int, r2: int, c2: int, L: int) -> int:
    """Manhattan distance on L×L PBC torus."""
    dr = min(abs(r1 - r2), L - abs(r1 - r2))
    dc = min(abs(c1 - c2), L - abs(c1 - c2))
    return dr + dc


def screening_cutoff(xi: float, confidence: float = 0.05,
                     min_distance: int = 3) -> int:
    """Compute the distance shell beyond which signal < confidence fraction of peak.

    |ΔG(d)| ~ A * exp(-d/ξ)
    We want exp(-d/ξ) < confidence → d > -ξ * ln(confidence)

    min_distance default is 3 because d<=2 gives 8-20% deviation in Yukawa fit
    (validated in EXP-066). d<=3 validated at <2.1% deviation.
    """
    if xi <= 0:
        return max(1, min_distance)
    d_max = int(np.ceil(-xi * np.log(confidence)))
    return max(d_max, 1, min_distance)


def prune_sites(
    L: int,
    center_row: int,
    center_col: int,
    xi: float | None = None,
    max_distance: int | None = None,
    pbc: bool = True,
) -> PruningResult:
    """Select sites within screening range of a center point.

    Either provide xi (screening length, auto-computes cutoff) or
    max_distance (explicit shell cutoff). If both given, max_distance wins.

    Args:
        L: Lattice size
        center_row, center_col: Defect/center position
        xi: Screening length (will compute cutoff at 5% residual)
        max_distance: Explicit max Manhattan distance (overrides xi)
        pbc: Periodic boundary conditions

    Returns:
        PruningResult with selected sites and metadata
    """
    if max_distance is None:
        if xi is None:
            xi = PHI_INV  # default to frozen 1/φ
        max_distance = screening_cutoff(xi)

    N = L * L
    selected = []
    distances = []
    by_dist: dict[int, int] = {}

    for r in range(L):
        for c in range(L):
            if pbc:
                d = manhattan_distance_pbc(r, c, center_row, center_col, L)
            else:
                d = abs(r - center_row) + abs(c - center_col)

            if d <= max_distance:
                ed_idx = r * L + c
                selected.append((ed_idx, r, c))
                distances.append(d)
                by_dist[d] = by_dist.get(d, 0) + 1

    # Sort by distance then index
    pairs = sorted(zip(distances, selected), key=lambda x: (x[0], x[1][0]))
    distances = [p[0] for p in pairs]
    selected = [p[1] for p in pairs]

    return PruningResult(
        selected_sites=selected,
        distances=distances,
        n_selected=len(selected),
        n_total=N,
        max_distance=max_distance,
        sites_by_distance=dict(sorted(by_dist.items())),
    )


def adaptive_shell_expansion(
    per_site_data: Sequence[dict],
    initial_max_d: int = 2,
    expansion_threshold: float = 0.05,
    fit_d_min: int = 1,
) -> dict:
    """TIGHTENING #2 (council): Start at d≤2, audit d=3, expand if needed.

    Fits on d≤initial_max_d. Then checks if the d=(initial_max_d+1) shell
    changes the fitted ξ by more than expansion_threshold. If so, expands.

    Args:
        per_site_data: List of dicts with 'distance' and 'dG'
        initial_max_d: Starting shell cutoff (default 2)
        expansion_threshold: Expand if ξ changes by more than this fraction
        fit_d_min: Minimum distance for fit

    Returns:
        Dict with recommended_max_d, fits at each level, expansion decisions
    """
    from scipy.optimize import curve_fit

    def _exp_decay(r, A, xi):
        return A * np.exp(-r / xi)

    by_dist: dict[int, list[float]] = {}
    for s in per_site_data:
        d = s["distance"]
        if d not in by_dist:
            by_dist[d] = []
        by_dist[d].append(abs(s["dG"]))

    all_ds = sorted(d for d in by_dist if d >= fit_d_min)
    max_available = max(all_ds) if all_ds else 0

    def fit_up_to(d_max):
        ds = [d for d in all_ds if d <= d_max]
        if len(ds) < 2:
            return None
        d_arr = np.array(ds, dtype=float)
        m_arr = np.array([np.mean(by_dist[d]) for d in ds])
        try:
            popt, _ = curve_fit(_exp_decay, d_arr, m_arr, p0=[m_arr[0], 0.6], maxfev=10000)
            return float(popt[1])
        except Exception:
            return None

    results = {"initial_max_d": initial_max_d, "expansions": []}
    current_d = initial_max_d
    prev_xi = fit_up_to(current_d)

    while current_d < max_available:
        next_d = current_d + 1
        next_xi = fit_up_to(next_d)

        if prev_xi is None or next_xi is None:
            break

        change = abs(next_xi - prev_xi) / abs(prev_xi)
        expand = change > expansion_threshold

        results["expansions"].append({
            "d": next_d,
            "xi_before": round(prev_xi, 6),
            "xi_after": round(next_xi, 6),
            "change_pct": round(change * 100, 2),
            "expanded": expand,
        })

        if expand:
            current_d = next_d
            prev_xi = next_xi
        else:
            break

    results["recommended_max_d"] = current_d
    results["final_xi"] = round(prev_xi, 6) if prev_xi else None

    return results


def select_audit_sites(
    L: int,
    center_row: int,
    center_col: int,
    measured_max_d: int,
    n_audit: int = AUDIT_N_SITES,
    pbc: bool = True,
) -> list[tuple[int, int, int, int]]:
    """TIGHTENING #5 (council): Select random predicted sites for spot-checking.

    Returns sites at d = measured_max_d + 1 (one shell beyond measured).
    These are the cheapest spot-checks: closest to the measurement boundary.

    Returns: list of (ed_index, row, col, distance) tuples
    """
    candidates = []
    target_d = measured_max_d + 1
    for r in range(L):
        for c in range(L):
            if pbc:
                d = manhattan_distance_pbc(r, c, center_row, center_col, L)
            else:
                d = abs(r - center_row) + abs(c - center_col)
            if d == target_d:
                candidates.append((r * L + c, r, c, d))

    if not candidates:
        return []

    rng = np.random.default_rng()
    n = min(n_audit, len(candidates))
    selected = rng.choice(len(candidates), size=n, replace=False)
    return [candidates[i] for i in selected]


def reconstruct_full_profile(
    measured_sites: list[dict],
    L: int,
    center_row: int,
    center_col: int,
    fit_d_min: int = 1,
    pbc: bool = True,
) -> list[dict]:
    """Reconstruct full spatial profile from measured shells + exponential fit.

    Measured sites are labelled "MEASURED". Sites beyond the measured range
    are labelled "PREDICTED from fit" using the fitted Yukawa parameters.

    The bubble always reconstructs the full picture. Nobody sees a sparse
    result — they see the full profile with transparency about which points
    are data and which are geometry.

    Args:
        measured_sites: Per-site dicts with 'row', 'col', 'distance', 'dG'
        L: Lattice size
        center_row, center_col: Defect position
        fit_d_min: Min distance for fit (1 = skip defect site)
        pbc: Periodic boundary conditions

    Returns:
        List of dicts for ALL L² sites, each with 'source' = "MEASURED" or "PREDICTED"
    """
    from scipy.optimize import curve_fit

    def _exp_decay(r, A, xi):
        return A * np.exp(-r / xi)

    # Bin measured data by distance
    measured_by_dist: dict[int, list[float]] = {}
    measured_set = set()
    for s in measured_sites:
        d = s["distance"]
        if d not in measured_by_dist:
            measured_by_dist[d] = []
        measured_by_dist[d].append(abs(s["dG"]))
        measured_set.add((s["row"], s["col"]))

    # Fit exponential on measured shells (d >= fit_d_min)
    fit_ds = sorted([d for d in measured_by_dist if d >= fit_d_min])
    xi_fit, A_fit = None, None
    if len(fit_ds) >= 2:
        d_arr = np.array(fit_ds, dtype=float)
        m_arr = np.array([np.mean(measured_by_dist[d]) for d in fit_ds])
        try:
            popt, _ = curve_fit(_exp_decay, d_arr, m_arr, p0=[m_arr[0], 0.6], maxfev=10000)
            A_fit, xi_fit = float(popt[0]), float(popt[1])
        except Exception:
            pass

    # Build full profile
    full_profile = []
    for r in range(L):
        for c in range(L):
            if pbc:
                d = manhattan_distance_pbc(r, c, center_row, center_col, L)
            else:
                d = abs(r - center_row) + abs(c - center_col)

            if (r, c) in measured_set:
                # Find the measured value
                for s in measured_sites:
                    if s["row"] == r and s["col"] == c:
                        full_profile.append({
                            "row": r, "col": c, "distance": d,
                            "dG": s["dG"],
                            "source": "MEASURED",
                        })
                        break
            else:
                # Predict from fit
                if xi_fit is not None and A_fit is not None and d > 0:
                    predicted_dG = A_fit * np.exp(-d / xi_fit)
                else:
                    predicted_dG = 0.0

                full_profile.append({
                    "row": r, "col": c, "distance": d,
                    "dG": round(predicted_dG, 8),
                    "source": f"PREDICTED from ξ={xi_fit:.4f}, A={A_fit:.4f}" if xi_fit else "PREDICTED (no fit)",
                })

    full_profile.sort(key=lambda x: (x["distance"], x["row"], x["col"]))

    return full_profile


def validate_pruning(
    per_site_data: Sequence[dict],
    max_distances: Sequence[int],
    fit_d_min: int = 1,
) -> dict:
    """Validate pruning rule by comparing fits at different shell cutoffs.

    Args:
        per_site_data: List of dicts with 'distance' and 'dG' keys
        max_distances: Shell cutoffs to test (e.g. [2, 3, 4])
        fit_d_min: Minimum distance to include in fit (default 1, skip d=0)

    Returns:
        Dict with xi and R² for each cutoff, plus deviation from full fit.
    """
    from scipy.optimize import curve_fit

    def exp_decay(r, A, xi):
        return A * np.exp(-r / xi)

    # Bin by distance
    by_dist: dict[int, list[float]] = {}
    for s in per_site_data:
        d = s["distance"]
        if d not in by_dist:
            by_dist[d] = []
        by_dist[d].append(abs(s["dG"]))

    def fit_shells(d_min, d_max):
        ds = sorted([d for d in by_dist if d_min <= d <= d_max])
        if len(ds) < 2:
            return None, None
        d_arr = np.array(ds, dtype=float)
        m_arr = np.array([np.mean(by_dist[d]) for d in ds])
        try:
            popt, _ = curve_fit(exp_decay, d_arr, m_arr, p0=[m_arr[0], 0.6], maxfev=10000)
            pred = exp_decay(d_arr, *popt)
            ss_res = np.sum((m_arr - pred) ** 2)
            ss_tot = np.sum((m_arr - np.mean(m_arr)) ** 2)
            r2 = float(1 - ss_res / ss_tot) if ss_tot > 0 else 0
            return float(popt[1]), r2
        except Exception:
            return None, None

    # Full fit
    all_ds = sorted(d for d in by_dist if d >= fit_d_min)
    xi_full, r2_full = fit_shells(fit_d_min, max(all_ds)) if all_ds else (None, None)

    results = {"full": {"xi": xi_full, "R2": r2_full, "d_range": f"{fit_d_min}..{max(all_ds)}" if all_ds else None}}

    for d_max in max_distances:
        xi_p, r2_p = fit_shells(fit_d_min, d_max)
        dev = abs(xi_p - xi_full) / abs(xi_full) * 100 if xi_full and xi_p else None
        results[f"d_max_{d_max}"] = {
            "xi": xi_p, "R2": r2_p,
            "deviation_pct": round(dev, 4) if dev is not None else None,
            "passes_5pct": dev < 5.0 if dev is not None else False,
        }

    return results
