"""
qig-warp v0.3.0 — Physics-Based Navigation for Expensive Computation

Substrate-agnostic wrapper that uses frozen physics results to reduce
the search space before infrastructure debate begins.

Architecture:
  engine = TeNPy / Block2 / CuPy / Ollama / whatever computes
  bubble = decides where to sample, what to skip, when to stop

Core (backend-agnostic):
  screening  — locality → spatial pruning
  bridge     — cost scaling → budget prediction
  convergence — stability → stopping rules

QIG mode (geometry from qig-core):
  WarpBubble.qig_frozen()  — frozen constants from physics
  WarpBubble.qig_learning() — learn constants from data (future)

The bubble core is general at the level of navigation logic.
QIGRAM / qig-core provides one powerful geometry backend.
The core remains backend-agnostic.

Usage:
    from qig_warp import WarpBubble

    # QIG frozen mode (our experiments)
    bubble = WarpBubble.qig_frozen()

    # General mode (pluggable)
    bubble = WarpBubble(rules={
        "screening_length": 0.5,
        "bridge_exponent": 0.8,
    })
"""

from __future__ import annotations

__version__ = "0.4.3"

from dataclasses import dataclass

import numpy as np

from qig_warp.bridge import (
    BRIDGE_CI_HIGH,
    BRIDGE_CI_LOW,
    BRIDGE_EXPONENT,
    BRIDGE_PREFACTOR,
    CostPrediction,
    budget_sweep,
    predict_runtime,
    predict_tau,
)
from qig_warp.convergence import (
    ANDERSON_ALPHA,
    StopDecision,
    check_ci_stabilized,
    check_diminishing_returns,
    check_discrimination,
    find_early_stop_point,
)
from qig_warp.regime import (
    CRITICAL_RATIO_1D,
    CRITICAL_RATIO_2D,
    Regime,
    RegimeConstants,
    classify_regime,
    regime_constants,
)
from qig_warp.screening import (
    PHI_INV,
    PruningResult,
    adaptive_shell_expansion,
    manhattan_distance_pbc,
    prune_sites,
    reconstruct_full_profile,
    screening_cutoff,
    select_audit_sites,
    validate_pruning,
)

from qig_warp.auto import (
    DiscoveredConstants,
    NavigationPlan,
    NavigationResult,
    navigate,
)

# Optional: memory layer (not mandatory)
try:
    from qig_warp.memory import NavigationMemory
    _HAS_MEMORY = True
except ImportError:
    _HAS_MEMORY = False

# Optional: qig-core geometry backend
try:
    from qig_core.geometry.fisher_rao import fisher_rao_distance, slerp_sqrt, bhattacharyya_coefficient
    _HAS_QIG_CORE = True
except ImportError:
    _HAS_QIG_CORE = False

__all__ = [
    "WarpBubble", "NavigationRules",
    "Regime", "RegimeConstants", "classify_regime", "regime_constants",
    "prune_sites", "predict_runtime", "predict_tau", "budget_sweep",
    "check_ci_stabilized", "check_discrimination", "find_early_stop_point",
    "validate_pruning", "screening_cutoff", "reconstruct_full_profile",
    "adaptive_shell_expansion", "select_audit_sites",
]


@dataclass
class NavigationRules:
    """Pluggable frozen physics constants for navigation."""
    screening_length: float = PHI_INV         # ξ = 1/φ
    bridge_exponent: float = BRIDGE_EXPONENT  # 0.7415
    bridge_prefactor: float = BRIDGE_PREFACTOR
    anderson_alpha: float = ANDERSON_ALPHA    # 0.089/site
    ci_window: int = 5
    ci_threshold: float = 0.05
    discrimination_threshold: float = 10.0


class WarpBubble:
    """Physics-based navigation layer for expensive computation.

    Backend-agnostic core with three cost-reduction strategies:
      1. Spatial pruning (screening / locality)
      2. Cost prediction (bridge / cost scaling)
      3. Early stopping (convergence / stability)

    QIG mode wires in qig-core geometry. General mode uses pluggable
    distance_fn. The core navigation logic is the same either way.

    Council tightenings:
      #1: Bridge requires 3+ strong-coupling points before stop
      #2: Adaptive shell expansion (start d≤2, audit d=3)
      #3: Bootstrap CIs reported on all estimates
      #4: Prospective cross-validation (first 3 runs: both modes)
      #5: Rolling audit (every 5th run, spot-check predicted sites)
    """

    def __init__(self, rules: NavigationRules | dict | None = None,
                 distance_fn=None):
        """Create a WarpBubble.

        Args:
            rules: Navigation constants. None = QIG frozen defaults.
            distance_fn: Optional pluggable distance function for general mode.
                If None and qig-core available, uses Fisher-Rao.
                If None and no qig-core, uses Euclidean fallback.
        """
        if rules is None:
            self.rules = NavigationRules()
        elif isinstance(rules, dict):
            self.rules = NavigationRules(**rules)
        else:
            self.rules = rules

        # Pluggable geometry backend
        if distance_fn is not None:
            self._distance_fn = distance_fn
        elif _HAS_QIG_CORE:
            self._distance_fn = fisher_rao_distance
        else:
            self._distance_fn = None

        # Optional memory (not mandatory)
        self.memory = NavigationMemory() if _HAS_MEMORY else None

        # Regime info (set by qig_regime factory)
        self._regime: RegimeConstants | None = None

        # Auto mode (set by auto factory)
        self._auto_mode: bool = False
        self._discovered: DiscoveredConstants | None = None

        # Tightening #4: cross-validation tracking
        self._run_count = 0
        self._cross_validation_limit = 3

        # Tightening #5: audit tracking
        self._audit_log: list[dict] = []

    @classmethod
    def qig_frozen(cls) -> "WarpBubble":
        """QIG frozen mode: single-calibration constants from physics.

        Uses fixed constants from L=5 h=1.0 regime. For regime-aware
        navigation, use qig_regime() instead.
        """
        return cls(rules=NavigationRules())

    @classmethod
    def qig_regime(cls, h: float, J: float = 1.0, dim: int = 2) -> "WarpBubble":
        """QIG regime-aware mode: constants selected by regime.

        New in v0.4.0. Uses calibration data from EXP-035-E, EXP-042-E,
        EXP-079 (2026-04-10 sweep) to select regime-appropriate constants.

        Three regimes:
          ORDERED (h/J << h_c): ξ short, bridge flat, heavy faster
          CRITICAL (h/J ≈ h_c): ξ ≈ 1/φ, bridge strongest, transition
          DISORDERED (h/J >> h_c): ξ varies, bridge weak, heavy slower (GR)

        Args:
            h: Transverse field strength
            J: Coupling strength (default 1.0)
            dim: Spatial dimension (1 or 2)

        Returns:
            WarpBubble with regime-appropriate constants
        """
        rc = regime_constants(h, J, dim)
        rules = NavigationRules(
            screening_length=rc.screening_length,
            bridge_exponent=rc.bridge_exponent,
            anderson_alpha=ANDERSON_ALPHA,
        )
        bubble = cls(rules=rules)
        bubble._regime = rc
        return bubble

    @classmethod
    def auto(cls) -> "WarpBubble":
        """Auto-discovery mode: constants discovered from pilot probes.

        New in v0.4.0e. The bubble starts with no constants. Call
        .navigate(fn, params) to run the OBSERVE → DISCOVER → NAVIGATE
        pipeline. The pilot probes discover screening, cost scaling,
        and convergence from the callable itself.

        No physics knowledge required. The callable is a black box.
        """
        bubble = cls(rules=NavigationRules(
            screening_length=0.0,   # will be discovered
            bridge_exponent=0.0,    # will be discovered
            anderson_alpha=0.0,     # will be discovered
        ))
        bubble._auto_mode = True
        return bubble

    @classmethod
    def general(cls, screening_length: float, bridge_exponent: float,
                anderson_alpha: float = 0.089, distance_fn=None) -> "WarpBubble":
        """General mode: user-specified constants, optional geometry."""
        rules = NavigationRules(
            screening_length=screening_length,
            bridge_exponent=bridge_exponent,
            anderson_alpha=anderson_alpha,
        )
        return cls(rules=rules, distance_fn=distance_fn)

    # ── Core navigation ──────────────────────────────────────────

    def prune(
        self,
        L: int,
        center: tuple[int, int],
        max_distance: int | None = None,
        pbc: bool = True,
    ) -> PruningResult:
        """Prune sites using screening length."""
        return prune_sites(
            L=L,
            center_row=center[0],
            center_col=center[1],
            xi=self.rules.screening_length,
            max_distance=max_distance,
            pbc=pbc,
        )

    def predict_cost(
        self,
        J: float,
        baseline_runtime: float,
        baseline_J: float = 1.0,
        L: int = 5,
    ) -> CostPrediction:
        """Predict runtime at coupling J from bridge law.

        In regime-aware mode, uses the regime-appropriate bridge exponent.
        """
        alpha = self.rules.bridge_exponent
        prefactor = self.rules.bridge_prefactor
        tau_J = predict_tau(J, exponent=alpha, prefactor=prefactor, L=L)
        tau_base = predict_tau(baseline_J, exponent=alpha, prefactor=prefactor, L=L)
        ratio = tau_J / tau_base if tau_base > 0 else 1.0
        predicted_s = baseline_runtime * ratio
        # Confidence band from exponent CI
        tau_lo = predict_tau(J, exponent=BRIDGE_CI_LOW, prefactor=prefactor, L=L)
        tau_hi = predict_tau(J, exponent=BRIDGE_CI_HIGH, prefactor=prefactor, L=L)
        tau_base_lo = predict_tau(baseline_J, exponent=BRIDGE_CI_LOW, prefactor=prefactor, L=L)
        tau_base_hi = predict_tau(baseline_J, exponent=BRIDGE_CI_HIGH, prefactor=prefactor, L=L)
        lo = baseline_runtime * (tau_lo / tau_base_lo) if tau_base_lo > 0 else predicted_s
        hi = baseline_runtime * (tau_hi / tau_base_hi) if tau_base_hi > 0 else predicted_s
        return CostPrediction(
            J=J,
            predicted_tau=tau_J,
            predicted_runtime_s=predicted_s,
            cost_relative=ratio,
            confidence_band=(lo, hi),
        )

    def budget(
        self,
        J_values: list[float],
        baseline_runtime: float,
        baseline_J: float = 1.0,
        max_total_s: float | None = None,
    ) -> dict:
        """Budget an entire sweep."""
        return budget_sweep(J_values, baseline_runtime, baseline_J, max_total_s)

    def should_stop(
        self,
        estimates: list[float] | None = None,
        signal: list[float] | None = None,
        noise: list[float] | None = None,
    ) -> StopDecision:
        """Check if computation should stop."""
        if signal is not None and noise is not None:
            return check_discrimination(
                signal, noise,
                separation_threshold=self.rules.discrimination_threshold,
            )
        if estimates is not None:
            return check_ci_stabilized(
                estimates,
                window=self.rules.ci_window,
                rel_change_threshold=self.rules.ci_threshold,
            )
        return StopDecision(
            should_stop=False, reason="No data provided",
            metric_value=0.0, threshold=0.0, n_evaluated=0,
        )

    # ── Learning mode (requires memory) ──────────────────────────

    def observe(self, key: str, coords, value: float, cost: float = 0.0,
                metadata: dict | None = None):
        """Record an observation. Requires memory layer."""
        if self.memory is None:
            return
        self.memory.store(key, coords, value, cost, metadata=metadata or {})
        self._run_count += 1

    def calibrate(self) -> dict:
        """Learn navigation constants from accumulated observations."""
        if self.memory is None:
            return {"error": "No memory layer available"}

        result = {"n_observations": self.memory.n_observations}

        xi_learned = self.memory.calibrate_screening()
        if xi_learned is not None:
            result["screening_length"] = {
                "frozen": self.rules.screening_length,
                "learned": round(xi_learned, 6),
                "change_pct": round(abs(xi_learned - self.rules.screening_length) /
                                    self.rules.screening_length * 100, 2),
            }

        alpha_learned = self.memory.calibrate_bridge()
        if alpha_learned is not None:
            result["bridge_exponent"] = {
                "frozen": self.rules.bridge_exponent,
                "learned": round(alpha_learned, 6),
                "change_pct": round(abs(alpha_learned - self.rules.bridge_exponent) /
                                    self.rules.bridge_exponent * 100, 2),
            }

        return result

    # ── Tightening #2: Adaptive shell expansion ──────────────────

    def adaptive_prune(self, per_site_data: list[dict], L: int,
                       center: tuple[int, int], pbc: bool = True) -> dict:
        """Start at d≤2, audit d=3, expand if needed."""
        expansion = adaptive_shell_expansion(per_site_data)
        recommended_d = expansion["recommended_max_d"]
        return {
            "recommended_max_d": recommended_d,
            "expansion_trace": expansion,
            "pruning": self.prune(L, center, max_distance=recommended_d, pbc=pbc),
        }

    # ── Tightening #4: Cross-validation gate ─────────────────────

    @property
    def in_cross_validation(self) -> bool:
        """True if still in first N runs (should run both bubble and full)."""
        return self._run_count < self._cross_validation_limit

    def log_cross_validation(self, bubble_result: float, full_result: float,
                             metric_name: str = "xi"):
        """Log a cross-validation comparison."""
        dev = abs(bubble_result - full_result) / abs(full_result) * 100 if full_result != 0 else 0.0
        self._audit_log.append({
            "type": "cross_validation", "run": self._run_count,
            "metric": metric_name, "bubble": bubble_result,
            "full": full_result, "deviation_pct": round(dev, 4),
        })

    # ── Tightening #5: Rolling audit ─────────────────────────────

    def get_audit_sites(self, L: int, center: tuple[int, int],
                        measured_max_d: int, pbc: bool = True) -> list:
        """Get random predicted sites for spot-checking (every 5th run)."""
        if self._run_count % 5 != 0:
            return []
        return select_audit_sites(L, center[0], center[1], measured_max_d, pbc=pbc)

    def log_audit(self, site: tuple, predicted: float, actual: float):
        """Log an audit spot-check result."""
        error = abs(predicted - actual) / abs(actual) * 100 if actual != 0 else 0.0
        self._audit_log.append({
            "type": "audit_spot_check", "run": self._run_count,
            "site": site, "predicted": predicted, "actual": actual,
            "error_pct": round(error, 2),
        })

    @property
    def audit_summary(self) -> dict:
        """Summary of all audit results."""
        audits = [a for a in self._audit_log if a["type"] == "audit_spot_check"]
        cv = [a for a in self._audit_log if a["type"] == "cross_validation"]
        return {
            "n_audits": len(audits),
            "n_cross_validations": len(cv),
            "mean_audit_error_pct": round(np.mean([a["error_pct"] for a in audits]), 2) if audits else None,
            "mean_cv_deviation_pct": round(np.mean([a["deviation_pct"] for a in cv]), 2) if cv else None,
        }

    # ── Summary ──────────────────────────────────────────────────

    @property
    def geometry_backend(self) -> str:
        if _HAS_QIG_CORE:
            return "qig-core (Fisher-Rao)"
        elif self._distance_fn is not None:
            return f"custom ({self._distance_fn.__name__})"
        return "none (navigation only)"

    # ── Auto-discovery navigation ─────────────────────────────────

    def navigate(
        self,
        fn,
        params: list[float],
        budget_s: float | None = None,
        n_probes: int = 5,
        screening_fn=None,
    ) -> NavigationResult:
        """Run the full OBSERVE → DISCOVER → NAVIGATE pipeline.

        Auto mode: discovers screening, cost scaling, convergence from
        pilot probes, then navigates the full parameter sweep efficiently.

        Works in any mode, but most useful with WarpBubble.auto().

        Args:
            fn: Callable(param) -> value. The expensive function.
            params: Parameter values to evaluate.
            budget_s: Max runtime in seconds. None = unlimited.
            n_probes: Number of pilot probes (default 5).
            screening_fn: Optional callable for screening probes.

        Returns:
            NavigationResult with results, discovered constants, savings.
        """
        result = navigate(fn, params, budget_s=budget_s,
                          n_probes=n_probes, screening_fn=screening_fn)

        # Update bubble with discovered constants
        self._discovered = result.discovered
        if result.discovered.screening_length is not None:
            self.rules.screening_length = result.discovered.screening_length
        if result.discovered.cost_exponent is not None:
            self.rules.bridge_exponent = result.discovered.cost_exponent
        if result.discovered.convergence_rate is not None:
            self.rules.anderson_alpha = result.discovered.convergence_rate

        return result

    @property
    def regime(self) -> RegimeConstants | None:
        """Regime classification (set by qig_regime factory)."""
        return self._regime

    def summary(self) -> str:
        """Navigation rules summary."""
        if self._auto_mode:
            mode = "AUTO" + (" (calibrated)" if self._discovered else " (uncalibrated)")
        elif self._regime is not None:
            mode = f"REGIME-AWARE ({self._regime.regime.value})"
        elif self.rules.screening_length == PHI_INV:
            mode = "FROZEN"
        else:
            mode = "CUSTOM"
        mem_str = f", memory={self.memory.n_observations} obs" if self.memory else ""
        regime_str = ""
        if self._regime is not None:
            regime_str = (
                f"  Regime: {self._regime.regime.value} "
                f"(GR: {self._regime.gr_direction}, "
                f"confidence: {self._regime.confidence})\n"
            )
        return (
            f"WarpBubble v{__version__} [{mode}]\n"
            f"  Geometry: {self.geometry_backend}\n"
            f"{regime_str}"
            f"  Screening: ξ = {self.rules.screening_length:.4f} "
            f"(cutoff d≤{screening_cutoff(self.rules.screening_length)})\n"
            f"  Bridge: τ ~ J^{self.rules.bridge_exponent:.4f} "
            f"(CI [{BRIDGE_CI_LOW}, {BRIDGE_CI_HIGH}])\n"
            f"  Anderson: α = {self.rules.anderson_alpha:.6f}/site\n"
            f"  Runs: {self._run_count}{mem_str}\n"
        )
