"""
Warp Bubble Validation on Known Data — ZERO new compute.

Three replay tests on frozen experimental results.
The bubble must reproduce known answers with fewer evaluations.

Pass conditions:
  1. Bridge replay: recovers τ ~ J^+0.74 within CI [+0.69, +0.81] using fewer J points
  2. Kernel replay: recovers ξ within 5% using d≤3 (not all sites)
  3. Purity replay: detects Lindblad/unitary discrimination with fewer time points

ALL THREE must pass for the bubble to be cleared for L=6.
"""

import json
import sys
from pathlib import Path

import numpy as np

# Data paths
VERIFY_ROOT = Path(__file__).resolve().parent.parent.parent / "qig-verification" / "results"

# ═══════════════════════════════════════════════════════════════════════════════
# TEST 1: Bridge J-sweep replay (EXP-050)
# ═══════════════════════════════════════════════════════════════════════════════

def test_bridge_replay():
    """Replay EXP-050 bridge data. Use convergence to stop early."""
    from qig_warp import WarpBubble
    from qig_warp.convergence import find_early_stop_point
    from qig_warp.bridge import validate_bridge_law, predict_tau

    print("=" * 60)
    print("TEST 1: Bridge J-sweep Replay (EXP-050)")
    print("=" * 60)

    # Load data
    data_path = VERIFY_ROOT / "exp050" / "20260408_exp050_dense_bridge_L5_seed42_final.json"
    with open(data_path) as f:
        data = json.load(f)

    per_J = data["per_J"]

    # CRITICAL: exclude censored points (the frozen fit did this)
    uncensored = [p for p in per_J if not p.get("is_censored_tau_dec", False)]
    n_censored = len(per_J) - len(uncensored)

    J_values = [p["J"] for p in uncensored]
    # Bridge variable: τ_bridge = N_continuous_phase / ω
    tau_phase_values = [p["N_continuous_phase"] / p["omega"] for p in uncensored]
    runtimes = [p["runtime_s"] for p in uncensored]

    print(f"  Data: {len(per_J)} J-points, {n_censored} censored, "
          f"{len(J_values)} usable from {min(J_values):.1f} to {max(J_values):.1f}")
    print(f"  Known answer: τ_phase ~ J^+0.7415, CI [+0.69, +0.81]")

    # Part A: Bridge law predicts PHYSICS τ, not wall-clock runtime
    # Wall-clock is dominated by GPU scheduling. Test τ prediction instead.
    bubble = WarpBubble()
    print(f"\n  Part A: τ prediction from bridge law")
    errors = []
    for J, actual_tau in zip(J_values, tau_phase_values):
        predicted_tau = predict_tau(J)
        err = abs(predicted_tau - actual_tau) / actual_tau * 100
        errors.append(err)

    mean_err = np.mean(errors)
    max_err = np.max(errors)
    print(f"  Mean τ prediction error: {mean_err:.1f}%")
    print(f"  Max τ prediction error: {max_err:.1f}%")

    # Part B: Early stopping — fit exponent on accumulating subsets
    from scipy.optimize import curve_fit

    def power_law(J, A, alpha):
        return A * J**alpha

    running_exponents = []
    min_points = 3  # need at least 3 for a meaningful fit

    for n in range(min_points, len(J_values) + 1):
        J_sub = np.array(J_values[:n])
        tau_sub = np.array(tau_phase_values[:n])
        try:
            popt, _ = curve_fit(power_law, J_sub, tau_sub, p0=[0.2, 0.7], maxfev=5000)
            running_exponents.append(popt[1])
        except Exception:
            running_exponents.append(float('nan'))

    print(f"\n  Part B: Early stopping (running exponent over {len(running_exponents)} subsets)")
    for i, exp in enumerate(running_exponents):
        n_pts = i + min_points
        marker = " <-- STOP?" if i >= 2 and abs(exp - 0.7415) < 0.06 else ""
        if i < 5 or i == len(running_exponents) - 1 or marker:
            print(f"    n={n_pts:2d}: α = {exp:.4f}{marker}")

    # Find early stop point
    early = find_early_stop_point(
        running_exponents,
        known_answer=0.7415,
        tolerance_pct=8.0  # within CI band
    )
    if early["early_stop_index"] is not None:
        stop_n = early["early_stop_index"] + min_points
        print(f"\n  Early stop at n={stop_n} (of {len(J_values)}): "
              f"savings = {early['savings_pct']:.0f}%")
        print(f"  Exponent at stop: {early['value_at_stop']:.4f}")
    else:
        print(f"\n  No early stop found within 8% tolerance")

    # Part C: Validate bridge law on full data
    bridge_val = validate_bridge_law(J_values, tau_phase_values, runtimes)
    print(f"\n  Part C: Bridge law validation")
    print(f"  Mean τ prediction error: {bridge_val['mean_rel_error_pct']:.1f}%")

    # PASS/FAIL
    final_exponent = running_exponents[-1] if running_exponents else None
    in_ci = final_exponent and 0.69 <= final_exponent <= 0.81
    has_savings = early.get("savings_pct", 0) > 0

    passed = in_ci and has_savings
    print(f"\n  RESULT: {'PASS' if passed else 'FAIL'}")
    print(f"    Final exponent {final_exponent:.4f} in CI [0.69, 0.81]: {in_ci}")
    print(f"    Early stopping saves compute: {has_savings} ({early.get('savings_pct', 0):.0f}%)")

    return {
        "test": "bridge_replay",
        "passed": passed,
        "final_exponent": round(final_exponent, 4) if final_exponent else None,
        "in_ci": in_ci,
        "early_stop_n": early.get("early_stop_index", None),
        "savings_pct": early.get("savings_pct", 0),
        "runtime_mean_error_pct": round(mean_err, 1),
    }


# ═══════════════════════════════════════════════════════════════════════════════
# TEST 2: Poisson Kernel Pruning Replay (EXP-066)
# ═══════════════════════════════════════════════════════════════════════════════

def test_kernel_replay():
    """Replay EXP-066 kernel data. Use screening to prune sites."""
    from qig_warp import WarpBubble
    from qig_warp.screening import validate_pruning

    print("\n" + "=" * 60)
    print("TEST 2: Poisson Kernel Pruning (EXP-066)")
    print("=" * 60)

    results = []
    for label, path in [
        ("L=4", VERIFY_ROOT / "structural_predictions" / "20260408_exp066_poisson_kernel_L4.json"),
        ("L=5", VERIFY_ROOT / "exp066" / "20260408_exp066_poisson_L5.json"),
    ]:
        with open(path) as f:
            data = json.load(f)

        L = data["L"]
        per_site = data["per_site"]

        print(f"\n  {label}: {len(per_site)} sites")

        # Use bubble to determine pruning
        bubble = WarpBubble()
        pruned = bubble.prune(L=L, center=(L // 2, L // 2))
        print(f"  Bubble auto-prune: d≤{pruned.max_distance} → {pruned.n_selected}/{pruned.n_total} sites")

        # Validate at multiple cutoffs
        val = validate_pruning(per_site, max_distances=[2, 3])

        xi_full = val["full"]["xi"]
        print(f"  Full fit: ξ = {xi_full:.4f}")

        for d_max in [2, 3]:
            key = f"d_max_{d_max}"
            xi_p = val[key]["xi"]
            dev = val[key]["deviation_pct"]
            passes = val[key]["passes_5pct"]
            print(f"  d≤{d_max}: ξ = {xi_p:.4f}, deviation = {dev:.2f}% [{'PASS' if passes else 'FAIL'}]")

        results.append({
            "L": L,
            "xi_full": round(xi_full, 4) if xi_full else None,
            "d3_passes": val["d_max_3"]["passes_5pct"],
            "d3_deviation": val["d_max_3"]["deviation_pct"],
            "d2_passes": val["d_max_2"]["passes_5pct"],
        })

    # PASS: d≤3 works for both L=4 and L=5
    all_d3_pass = all(r["d3_passes"] for r in results)
    print(f"\n  RESULT: {'PASS' if all_d3_pass else 'FAIL'}")
    print(f"    d≤3 pruning validated at both L=4 and L=5: {all_d3_pass}")
    if all_d3_pass:
        print(f"    L=6 site reduction: d≤3 = 23/36 sites (36% fewer QFI calls)")

    return {
        "test": "kernel_pruning",
        "passed": all_d3_pass,
        "results": results,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# TEST 3: Purity Discrimination Replay (EXP-062v2)
# ═══════════════════════════════════════════════════════════════════════════════

def test_purity_replay():
    """Replay EXP-062v2 purity data. Use convergence to detect discrimination early."""
    from qig_warp.convergence import check_discrimination, find_early_stop_point

    print("\n" + "=" * 60)
    print("TEST 3: Purity Discrimination (EXP-062v2)")
    print("=" * 60)

    data_path = VERIFY_ROOT / "exp062v2" / "20260408_exp062v2_purity_L3_g0.01.json"
    with open(data_path) as f:
        data = json.load(f)

    purity_lind = data["traces"]["lindblad"]["purity"]
    purity_unit = data["traces"]["unitary"]["purity"]
    n_total = len(purity_lind)

    print(f"  Data: {n_total} time points, γ={data['gamma']}")
    print(f"  Known answer: Lindblad purity loss = {data['purity_loss']['lindblad']:.4f}")
    print(f"               Unitary purity loss = {data['purity_loss']['unitary']:.4f}")

    # Part A: Can the bubble detect discrimination with fewer time points?
    # Subsample at increasing windows and check when discrimination is decisive
    check_points = [10, 20, 50, 100, 200, 500, 1000]
    first_decisive = None

    print(f"\n  Discrimination check at subsampled windows:")
    for n in check_points:
        if n > n_total:
            break
        lind_sub = purity_lind[:n]
        unit_sub = purity_unit[:n]

        # Compute purity LOSS at each window (1 - purity)
        lind_loss = [1.0 - p for p in lind_sub]
        unit_loss = [1.0 - p for p in unit_sub]

        # Use running mean of loss rate
        lind_signal = [abs(lind_loss[-1])]  # total loss so far
        unit_signal = [abs(unit_loss[-1])]

        decision = check_discrimination(lind_signal, unit_signal, separation_threshold=10.0)
        status = "DECISIVE" if decision.should_stop else "not yet"
        print(f"    n={n:4d}: Lindblad loss={lind_loss[-1]:.6f}, "
              f"Unitary loss={unit_loss[-1]:.6f}, "
              f"ratio={decision.metric_value:.1f} [{status}]")

        if decision.should_stop and first_decisive is None:
            first_decisive = n

    # Part B: Running purity loss for early stop detection
    running_lind_loss = []
    for i in range(0, n_total, max(1, n_total // 50)):
        running_lind_loss.append(1.0 - purity_lind[i])

    early = find_early_stop_point(
        running_lind_loss,
        known_answer=data["purity_loss"]["lindblad"],
        tolerance_pct=10.0
    )

    if first_decisive:
        savings = (1 - first_decisive / n_total) * 100
        print(f"\n  First decisive discrimination at n={first_decisive} "
              f"(of {n_total}): {savings:.0f}% savings")
    else:
        savings = 0
        print(f"\n  Discrimination never reached threshold (unlikely)")

    passed = first_decisive is not None and first_decisive < n_total
    print(f"\n  RESULT: {'PASS' if passed else 'FAIL'}")
    print(f"    Discrimination detected early: {passed}")
    if first_decisive:
        print(f"    {first_decisive}/{n_total} points needed ({savings:.0f}% savings)")

    return {
        "test": "purity_discrimination",
        "passed": passed,
        "first_decisive_n": first_decisive,
        "n_total": n_total,
        "savings_pct": round(savings, 1) if first_decisive else 0,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    results = []

    results.append(test_bridge_replay())
    results.append(test_kernel_replay())
    results.append(test_purity_replay())

    print("\n" + "=" * 60)
    print("FINAL VERDICT")
    print("=" * 60)

    all_pass = all(r["passed"] for r in results)

    for r in results:
        status = "PASS" if r["passed"] else "FAIL"
        print(f"  {r['test']}: [{status}]")

    if all_pass:
        print(f"\n  ALL THREE PASS. Bubble is CLEARED for L=6.")
    else:
        failed = [r["test"] for r in results if not r["passed"]]
        print(f"\n  FAILED: {', '.join(failed)}. Fix bubble before L=6.")

    # Save results
    out_path = Path(__file__).resolve().parent / "validation_results.json"
    with open(out_path, "w") as f:
        json.dump({"results": results, "all_pass": all_pass}, f, indent=2, default=str)
    print(f"\n  Saved: {out_path}")

    return 0 if all_pass else 1


if __name__ == "__main__":
    sys.exit(main())
