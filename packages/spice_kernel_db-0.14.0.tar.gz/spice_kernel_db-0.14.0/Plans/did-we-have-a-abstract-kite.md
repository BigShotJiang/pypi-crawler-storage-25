# Plan — NASA-mission metakernel discovery (Tier 1) + Tier 2 sketch

## Context

`spice-kernel-db` currently hardcodes every mission's metakernel directory to
`{server_url}{MISSION}/kernels/mk/` (`cli.py:1465`, probe at `remote.py:153`).
This works for ESA missions and a handful of NASA missions, but most NASA
archives don't fit:

- Some NASA missions have metakernels under non-standard NAIF paths
  (e.g. `data/spice/mk/`, `spice_kernels/mk/`, only in `former_versions/`).
- Some are archived in PDS bundles instead of (or in addition to) NAIF —
  already covered by the user's `planetarypy` library.
- Some have no curated mission-wide metakernel at all and require a synthesized
  one from individual kernel listings.

Today `_mission_add_interactive` filters these out with a "not yet supported"
message (`cli.py:1441–1446`, tracked as GitHub issue #2). Goal: lift that
limitation in two tiers. Tier 1 (this plan) adds layered discovery for missions
whose metakernels exist but live elsewhere. Tier 2 (sketched) handles missions
with no metakernel at all.

User decisions captured during planning:
- Tier 1 first; all three discovery strategies layered (manual override +
  curated registry + auto-probe).
- planetarypy: optional extra, delegate when registry says so.
- Tier 2: type+time-window filter, but filename heuristics must be defined
  per mission (no universal regex).

---

## Tier 1 — Implementation phases

### Phase 1 — Registry scaffolding

**New file:** `src/spice_kernel_db/mission_registry.toml` — per-mission
candidate metakernel directory URLs. Placeholders: `{server}` = server URL
with trailing slash, `{m}` = mission directory name. Probed in declared order.

```toml
# Entries below are format examples; real alt paths must be confirmed against
# NAIF before merging.

[LRO]
candidates = [
  "{server}{m}/data/spice/mk/",
  "{server}{m}/kernels/mk/",
]
planetarypy = true

[MSL]
candidates = [
  "{server}{m}/kernels/mk/",
  "{server}{m}/kernels/mk/former_versions/",
]
planetarypy = true

["OSIRIS-REX"]
candidates = [
  "{server}{m}/kernels/mk/",
  "{server}{m}/spice_kernels/mk/",
]
```

**New module:** `src/spice_kernel_db/registry.py`
- `@dataclass MissionEntry: name: str; candidates: list[str]; planetarypy: bool = False`
- `load_registry() -> dict[str, MissionEntry]` — read via `importlib.resources.files("spice_kernel_db") / "mission_registry.toml"`, cache with `functools.cache`.
- `registry_candidates(mission, server_url) -> list[str]` — expand placeholders, preserve order, dedup.
- `is_planetarypy_managed(mission) -> bool`.

### Phase 2 — Auto-probe in `remote.py`

Add after `check_mk_availability` (`remote.py:176`):

- `DEFAULT_ALT_MK_PATHS: tuple[str, ...]` — generic fallback templates probed
  when neither registry nor `kernels/mk/` works:
  ```
  "{server}{m}/kernels/mk/",
  "{server}{m}/spice_kernels/mk/",
  "{server}{m}/data/spice/mk/",
  "{server}{m}/data/mk/",
  "{server}{m}/kernels/mk/former_versions/",
  ```
- `probe_mk_candidates(urls, *, max_workers=8, timeout=5.0) -> list[str]` —
  parallel HEAD, returns URLs that responded 200 **in original (priority) order**.
  Extract the HEAD logic in `check_mk_availability._check` into a shared
  `_head_ok(url, timeout)` private helper while editing.
- `discover_mk_url(server_url, mission, *, registry_entry=None) -> list[str]` —
  composes `registry_candidates(...)` first, then `DEFAULT_ALT_MK_PATHS`,
  dedups, calls `probe_mk_candidates`.

### Phase 3 — CLI flag surface

Edit `cli.py:300–308` (mission subparser block):

```python
p_mission_add = mission_sub.add_parser("add", help="Add a new mission")
p_mission_add.add_argument("name", nargs="?", help="Mission name (skip prompts when given)")
p_mission_add.add_argument("--server-url", help="Archive server base URL (required with positional name)")
p_mission_add.add_argument("--mk-dir-url", help="Override metakernel directory URL (bypasses discovery)")
p_mission_add.add_argument("--no-dedup", action="store_true", help="Disable deduplication")
p_mission_add.add_argument("--use-planetarypy", action="store_true",
                           help="Delegate kernel mgmt to planetarypy if available")
```

Edit `cli.py:1399–1400` dispatch:

```python
elif args.mission_command == "add":
    if args.mk_dir_url or args.name:
        _mission_add_noninteractive(db, args)
    else:
        _mission_add_interactive(db, args)
```

### Phase 4 — Surgical refactor of `_mission_add_interactive`

Extract helpers from the existing body (do not rewrite the function):

- `_choose_server() -> tuple[str, str]` — current `cli.py:1409–1420`.
- `_choose_mission(server_url, server_label) -> tuple[str, list[str]]` —
  current `cli.py:1423–1462`, returning `(name, candidate_mk_urls)`.
  - If user picks from the `supported` list, candidates = `[f"{server_url}{name}/kernels/mk/"]` (preserves current behavior).
  - If user types a name from `unsupported`, call `registry_candidates()` then `discover_mk_url()`; present hits as a numbered selector ("Found 2 alternate metakernel locations: [1] …/data/spice/mk/  [2] …/spice_kernels/mk/").
  - Abort gracefully with the new troubleshooting message when zero hits.
- `_choose_dedup(mission_name) -> bool` — current `cli.py:1468–1471`.

The `cli.py:1465` hardcoded `mk_dir_url` becomes whatever
`_choose_mission` returned. When the chosen mission is registry-flagged
`planetarypy=true` and `planetarypy_bridge.is_available()`, the user is
prompted whether to delegate.

### Phase 5 — Non-interactive path

```python
def _mission_add_noninteractive(db: KernelDB, args) -> None:
    # If --mk-dir-url: validate via probe_mk_candidates([url]); db.add_mission(...); done.
    # Else: server_url required (or inferable from SPICE_SERVERS); run discover_mk_url().
    #   - exactly one hit  → add_mission
    #   - multiple hits    → exit 1 with numbered list, instruct user to re-run with --mk-dir-url
    #   - zero hits        → exit 1, point at troubleshooting docs
```

### Phase 6 — planetarypy hook

**New module:** `src/spice_kernel_db/planetarypy_bridge.py`

```python
def is_available() -> bool:
    return importlib.util.find_spec("planetarypy") is not None

def delegate_mission_add(mission: str, server_url: str) -> dict | None:
    """Stub. Returns {'mk_dir_url': ..., 'managed_by': 'planetarypy'} or None.
    Full integration tracked in a follow-up issue."""
    return None
```

`pyproject.toml`:
```toml
[project.optional-dependencies]
planetarypy = ["planetarypy>=0.27"]
```

CLI calls `delegate_mission_add` only when (registry `planetarypy=true`) AND
(`--use-planetarypy` set OR interactive prompt accepted) AND `is_available()`.
Stub returning `None` falls back to normal discovery and emits
"planetarypy detected but delegation not yet implemented (issue #N)".

### Phase 7 — Tests (`tests/test_kernel_db.py` additions)

- `test_registry_load_and_expand` — loads bundled TOML; LRO has ≥1 candidate, planetarypy flag True.
- `test_probe_mk_candidates_parallel` — `unittest.mock.patch("urllib.request.urlopen")` mixes 200/404 responses; assert priority order preserved.
- `test_discover_mk_url_registry_first` — mocks HEAD; registry candidates tried before `DEFAULT_ALT_MK_PATHS`.
- `test_mission_add_noninteractive_with_mk_dir_url` — `pytest-tmp-files` tmp db; `main(["mission","add","FOO","--server-url","http://x/","--mk-dir-url","http://x/FOO/data/spice/mk/"])`; mock `probe_mk_candidates` → True; assert row in `missions` table.
- `test_mission_add_noninteractive_no_hits_errors` — exit code 1, stderr contains "no metakernel directory".
- `test_planetarypy_bridge_unavailable` — without the extra, `is_available()` False; `delegate_mission_add` returns None.
- Fixture `tests/fixtures/mission_registry_min.toml` mounted via `monkeypatch.setattr(registry, "_REGISTRY_PATH", ...)`.

Run via py314 conda env per project convention.

### Phase 8 — Docs (mandatory, same PR)

- `docs/cli.qmd` — append rows to mission-add options table for the four new flags + positional `name`. Add one non-interactive example.
- `docs/api.qmd` — document `remote.probe_mk_candidates`, `remote.discover_mk_url`, `registry.load_registry`, `planetarypy_bridge.is_available`.
- `docs/troubleshooting.qmd` — new section "Mission has no metakernel directory at the default path": lists the probed alt paths and points at `mission_registry.toml` for contributions.
- `CHANGELOG.md` — under Unreleased: "Added `mission add` non-interactive form, curated `mission_registry.toml`, auto-probe of alternate metakernel paths, optional `[planetarypy]` extra."

---

## Critical files

| Action | File |
|--------|------|
| New registry data | `src/spice_kernel_db/mission_registry.toml` |
| New registry loader | `src/spice_kernel_db/registry.py` |
| New planetarypy bridge | `src/spice_kernel_db/planetarypy_bridge.py` |
| Edit — auto-probe helpers | `src/spice_kernel_db/remote.py` (after line 176) |
| Edit — CLI flags + dispatch | `src/spice_kernel_db/cli.py` (lines 300–308, 1399–1400) |
| Edit — extract helpers, wire discovery | `src/spice_kernel_db/cli.py` (`_mission_add_interactive`, 1406–1482) |
| Edit — optional extra | `pyproject.toml` |
| Tests | `tests/test_kernel_db.py`, `tests/fixtures/mission_registry_min.toml` |
| Docs | `docs/cli.qmd`, `docs/api.qmd`, `docs/troubleshooting.qmd`, `CHANGELOG.md` |

## Reused existing components

- `KernelDB.add_mission` (`db.py:357`) — schema already accepts arbitrary `mk_dir_url`; no migration needed.
- `check_mk_availability._check` (`remote.py:152`) — extract `_head_ok` instead of duplicating.
- Existing `pytest-tmp-files` fixture pattern and `unittest.mock.patch` HTTP mocking in `tests/test_kernel_db.py`.
- `rich.progress.Progress` block style (`remote.py:162–175`) for the auto-probe progress UI.

## Verification

```bash
# Use the py314 conda env (project convention)
conda run -n py314 pytest tests/test_kernel_db.py -k "registry or probe or mission_add" -v

# Manual: explicit override, non-interactive
spice-kernel-db mission add LRO \
  --server-url https://naif.jpl.nasa.gov/pub/naif/ \
  --mk-dir-url https://naif.jpl.nasa.gov/pub/naif/LRO/data/spice/mk/
spice-kernel-db mission list      # confirm row, mk_dir_url stored

# Manual: interactive discovery for a previously "not yet supported" mission
spice-kernel-db mission add       # pick NASA, type OSIRIS-REX → should offer alt paths

# Regression: an ESA mission still works through the original supported path
spice-kernel-db mission add       # pick ESA → JUICE → confirm kernels/mk/ used
```

Docs preview:
```bash
cd docs && quarto preview
```

---

## Tier 2 — Sketch (deferred to follow-up)

Per-mission filename-heuristic modules under
`src/spice_kernel_db/heuristics/{lro,msl,osiris_rex}.py`, each exposing
`classify(filename) -> KernelType` and `time_window(filename) -> tuple[date, date] | None`.
A new `KernelDB.synthesize_metakernel(mission, *, types, start, end)` walks
each kernel-type subdir on NAIF, applies the mission's heuristic module, and
emits a `.tm` file under `~/.cache/spice-kernel-db/synthesized/{mission}/{hash}.tm`.
A new `synthesized_metakernels` table references the source kernel rows. The
existing `get` command grows `--synthesize --types spk,ck --start … --end …`
flags that build, persist, and then download through the existing
`resolve_kernel_urls` / `download_kernels_parallel` pipeline — no separate
download path needed. The Tier 1 registry's `planetarypy=true` flag remains
the boundary marker that prevents Tier 2 synthesis from being attempted on
missions where planetarypy is authoritative.
