"""
— Dataclasses du manifeste plugin.

PluginManifest est l'objet riche parsé par ManifestValidator.
Il remplace le _SimpleManifest pour les usages SDK complets.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ..kernel.api.contract import ExecutionMode


@dataclass
class RateLimitConfig:
    """
    rate limite configuration configuration
    """

    calls: int = 100
    period_seconds: int = 60


@dataclass
class ResourceConfig:
    """
    Resource Configuration
    """

    timeout_seconds: int = 10
    max_memory_mb: int = 128
    max_disk_mb: int = 50
    rate_limit: RateLimitConfig = field(default_factory=RateLimitConfig)


@dataclass
class HealthCheckConfig:
    """
    healh check config
    """

    enabled: bool = True
    interval_seconds: int = 30
    timeout_seconds: int = 3


@dataclass
class RetryConfig:
    """
    max retry for plugin
    """

    max_attempts: int = 1
    backoff_seconds: float = 0.0


@dataclass
class RuntimeConfig:
    health_check: HealthCheckConfig = field(default_factory=HealthCheckConfig)
    retry: RetryConfig = field(default_factory=RetryConfig)


@dataclass
class FilesystemConfig:
    allowed_paths: list[str] = field(default_factory=lambda: ["data/"])
    denied_paths: list[str] = field(default_factory=lambda: ["src/"])


@dataclass
class PluginDependency:
    """
    Dépendance d'un plugin vers un autre avec contrainte de version.

    Format YAML supporté:
        requires:
          - other_plugin                    # version="*" (n'importe quelle version)
          - name: other_plugin
            version: ">=2.0,<3.0"           # contrainte semver
    """

    name: str
    version_constraint: str = "*"  # * pour tout, ou >=2.0,<3.0 etc.

    def is_compatible(self, version: str) -> bool:
        """Vérifie si une version satisfait la contrainte."""
        if self.version_constraint == "*":
            return True
        return VersionConstraint(self.version_constraint).matches(version)

    def __hash__(self) -> int:
        return hash(self.name)

    def __eq__(self, other: object) -> bool:
        if isinstance(other, PluginDependency):
            return self.name == other.name
        return self.name == other if isinstance(other, str) else False

    @classmethod
    def from_raw(cls, raw: str | dict) -> "PluginDependency":
        """
        Convertit un élément YAML de `requires` en PluginDependency.

        Formats supportés:
            - "plugin_name"
            - {name: plugin_name}
            - {name: plugin_name, version: ">=1.0,<2.0"}
        """

        if isinstance(raw, str):
            return cls(name=raw, version_constraint="*")

        if isinstance(raw, dict):
            name = raw.get("name")
            if not name:
                raise ValueError("Plugin dependency requires a 'name' field")

            version = raw.get("version", "*")
            return cls(name=name, version_constraint=version)

        raise TypeError(f"Invalid dependency format: {raw}")


class VersionConstraint:
    """Parse et évalue une contrainte de version semver."""

    def __init__(self, constraint: str) -> None:
        self._raw = constraint.strip()
        self._specs = self._parse(self._raw)

    def _parse(self, constraint: str) -> list[tuple[str, tuple[int, ...]]]:
        """Parse une contrainte comme '>=2.0,<3.0' en liste de specs."""
        specs = []
        parts = [p.strip() for p in constraint.split(",")]

        for part in parts:
            for op in (">=", "<=", ">", "<", "==", "!=", "^", "~"):
                if part.startswith(op):
                    version_str = part[len(op) :].strip()
                    version = self._to_tuple(version_str)
                    specs.append((op, version))
                    break
            else:
                # Pas d'opérateur = égalité exacte
                specs.append(("==", self._to_tuple(part)))
        return specs

    def _to_tuple(self, version: str) -> tuple[int, ...]:
        """Convertit '1.2.3' en (1, 2, 3)."""
        parts = version.lstrip("vV").split(".")
        nums = [int(p) for p in parts if p.isdigit()]
        while len(nums) < 3:
            nums.append(0)
        return tuple(nums)

    def matches(self, version: str) -> bool:
        """Vérifie si 'version' satisfait cette contrainte."""
        target = self._to_tuple(version)

        for op, spec in self._specs:
            if op == "==" and target != spec:
                return False
            if op == "!=" and target == spec:
                return False
            if op == ">=" and not (target >= spec):
                return False
            if op == ">" and not (target > spec):
                return False
            if op == "<=" and not (target <= spec):
                return False
            if op == "<" and not (target < spec):
                return False
            if op == "^":
                # ^1.2.3 := >=1.2.3,<2.0.0
                if not (target >= spec):
                    return False
                if target[0] != spec[0]:
                    return False
            elif op == "~":
                # ~1.2.3 := >=1.2.3,<1.3.0
                if not (target >= spec):
                    return False
                if len(spec) >= 2 and target[0:2] != spec[0:2]:
                    return False
        return True


@dataclass
class PluginManifest:
    """
    Représentation complète et typée d'un manifeste plugin.yaml.

    Champs obligatoires : name, version
    Tous les autres ont des valeurs par défaut.
    """

    name: str
    version: str
    plugin_dir: Path

    # Identité
    author: str = "unknown"
    description: str = ""
    framework_version: str = ">=2.0"
    entry_point: str = "src/main.py"
    execution_mode: ExecutionMode = ExecutionMode.LEGACY

    # Dépendances et imports
    requires: list[PluginDependency] = field(default_factory=list)
    allowed_imports: list[str] = field(default_factory=list)
    permissions: list[dict] = field(default_factory=list)

    # Environnement
    env: dict[str, str] = field(default_factory=dict)

    # Ressources, runtime, filesystem
    resources: ResourceConfig = field(default_factory=ResourceConfig)
    runtime: RuntimeConfig = field(default_factory=RuntimeConfig)
    filesystem: FilesystemConfig = field(default_factory=FilesystemConfig)

    # Config arbitraire du plugin (bloc extra)
    extra: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_raw(
        cls,
        raw: dict[str, Any],
        mode: ExecutionMode,
        resolved_env: dict[str, str],
        requires: list[PluginDependency],
        plugin_dir: Path,
    ) -> "PluginManifest":
        res_raw = raw.get("resources", {})
        rt_raw = raw.get("runtime", {})
        fs_raw = raw.get("filesystem", {})
        rl_raw = res_raw.get("rate_limit", {})
        hc_raw = rt_raw.get("health_check", {})
        ret_raw = rt_raw.get("retry", {})

        known = {
            "name",
            "version",
            "author",
            "description",
            "framework_version",
            "entry_point",
            "execution_mode",
            "requires",
            "allowed_imports",
            "permissions",
            "env",
            "envconfiguration",
            "resources",
            "runtime",
            "filesystem",
        }
        extra = {k: v for k, v in raw.items() if k not in known}

        return cls(
            name=str(raw["name"]),
            version=str(raw["version"]),
            plugin_dir=plugin_dir,
            author=raw.get("author", "unknown"),
            description=raw.get("description", ""),
            framework_version=raw.get("framework_version", ">=2.0"),
            entry_point=raw.get("entry_point", "src/main.py"),
            execution_mode=mode,
            requires=requires,
            allowed_imports=raw.get("allowed_imports", []),
            permissions=raw.get("permissions", []),
            env=resolved_env,
            resources=ResourceConfig(
                timeout_seconds=res_raw.get("timeout_seconds", 10),
                max_memory_mb=res_raw.get("max_memory_mb", 128),
                max_disk_mb=res_raw.get("max_disk_mb", 50),
                rate_limit=RateLimitConfig(
                    calls=rl_raw.get("calls", 100),
                    period_seconds=rl_raw.get("period_seconds", 60),
                ),
            ),
            runtime=RuntimeConfig(
                health_check=HealthCheckConfig(
                    enabled=hc_raw.get("enabled", True),
                    interval_seconds=hc_raw.get("interval_seconds", 30),
                    timeout_seconds=hc_raw.get("timeout_seconds", 3),
                ),
                retry=RetryConfig(
                    max_attempts=ret_raw.get("max_attempts", 1),
                    backoff_seconds=ret_raw.get("backoff_seconds", 0.0),
                ),
            ),
            filesystem=FilesystemConfig(
                allowed_paths=fs_raw.get("allowed_paths", ["data/"]),
                denied_paths=fs_raw.get("denied_paths", ["src/"]),
            ),
            extra=extra,
        )

    def __repr__(self) -> str:
        return (
            f"<PluginManifest name='{self.name}' version='{self.version}' "
            f"mode={self.execution_mode.value}>"
        )
