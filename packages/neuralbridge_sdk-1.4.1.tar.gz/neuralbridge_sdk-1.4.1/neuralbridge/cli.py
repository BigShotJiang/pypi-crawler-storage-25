#!/usr/bin/env python3
"""
NeuralBridge CLI — nb-doctor command line tool
v1.4.0

Usage:
    nb-doctor scan          # Scan current directory
    nb-doctor scan --deep   # Deep scan (with dependency analysis)
    nb-doctor check <file>  # Check a single Python file
    nb-doctor report        # Generate HTML report
    nb-doctor scan /path    # Scan a specific directory
"""

import sys
import os
import argparse


def main():
    parser = argparse.ArgumentParser(
        prog="nb-doctor",
        description="🩺 NeuralBridge Doctor — Zero-barrier Agent Health Scanner",
        epilog="Scan your Python project for Agent reliability risks. No API key needed.",
    )
    parser.add_argument("--version", action="version", version="nb-doctor 1.4.1 (neuralbridge-sdk)")

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # scan subcommand
    scan_parser = subparsers.add_parser("scan", help="Scan a Python project directory")
    scan_parser.add_argument("path", nargs="?", default=".", help="Path to Python project (default: current directory)")
    scan_parser.add_argument("--deep", action="store_true", help="Deep scan with dependency chain analysis")
    scan_parser.add_argument("--json", action="store_true", help="Output JSON report")
    scan_parser.add_argument("--html", action="store_true", help="Output HTML report")

    # check subcommand
    check_parser = subparsers.add_parser("check", help="Check a single Python file")
    check_parser.add_argument("file", help="Path to Python file")
    check_parser.add_argument("--json", action="store_true", help="Output JSON report")

    # report subcommand
    report_parser = subparsers.add_parser("report", help="Generate HTML health report")
    report_parser.add_argument("path", nargs="?", default=".", help="Path to Python project (default: current directory)")
    report_parser.add_argument("-o", "--output", default="nb-doctor-report.html", help="Output HTML file (default: nb-doctor-report.html)")
    report_parser.add_argument("--deep", action="store_true", help="Include dependency analysis")

    args = parser.parse_args()

    # If no command, default to scan current directory
    if not args.command:
        args.command = "scan"
        args.path = "."
        args.deep = False
        args.json = False
        args.html = False

    from neuralbridge.scanner.engine import (
        scan_directory, scan_file, report_terminal, report_json, report_html,
        Severity, compute_scores, overall_score,
    )

    if args.command == "scan":
        path = os.path.abspath(args.path)
        if not os.path.isdir(path):
            print(f"[91mError: {path} is not a directory[0m")
            sys.exit(1)

        findings = scan_directory(path, deep=args.deep)

        if args.json:
            print(report_json(findings, scan_path=path))
        elif args.html:
            html = report_html(findings, scan_path=path)
            outfile = os.path.join(path, "nb-doctor-report.html")
            with open(outfile, "w", encoding="utf-8") as f:
                f.write(html)
            print(f"[92mHTML report saved to {outfile}[0m")
        else:
            report_terminal(findings, scan_path=path)

        sys.exit(1 if any(f.severity == Severity.CRITICAL for f in findings) else 0)

    elif args.command == "check":
        filepath = os.path.abspath(args.file)
        findings = scan_file(filepath)

        if args.json:
            print(report_json(findings, scan_path=filepath))
        else:
            print(report_terminal(findings, scan_path=filepath))

        sys.exit(1 if any(f.severity == Severity.CRITICAL for f in findings) else 0)

    elif args.command == "report":
        path = os.path.abspath(args.path)
        if not os.path.isdir(path):
            print(f"[91mError: {path} is not a directory[0m")
            sys.exit(1)

        findings = scan_directory(path, deep=args.deep)
        html = report_html(findings, scan_path=path)

        outfile = os.path.abspath(args.output)
        with open(outfile, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"[92mHTML report saved to {outfile}[0m")

        scores = compute_scores(findings)
        overall = overall_score(scores)
        from neuralbridge.scanner.engine import grade_label
        grade = grade_label(overall)
        print(f"  Overall: {grade} ({overall}/100) | {len(findings)} findings")

        sys.exit(1 if any(f.severity == Severity.CRITICAL for f in findings) else 0)

    else:
        parser.print_help()
        sys.exit(0)


if __name__ == "__main__":
    main()
