"""
NeuralBridge StateMachine — Agent Behavior Guardrails
v1.3.0-dev

Combines API self-healing with state machine constraints.
One SDK for complete agent reliability.
"""

from enum import Enum
from typing import Any, Callable, Optional
from dataclasses import dataclass, field
import time
import json


class StateType(Enum):
    PLANNING = "planning"
    CODING = "coding"
    TESTING = "testing"
    REVIEW = "review"
    DEPLOYING = "deploying"
    CUSTOM = "custom"


@dataclass
class State:
    """A state in the state machine with tool restrictions."""
    name: str
    allowed_tools: list[str] = field(default_factory=list)
    max_iterations: int = 10
    description: str = ""
    on_enter: Optional[Callable] = None
    on_exit: Optional[Callable] = None


@dataclass
class Transition:
    """A transition between states with a guard condition."""
    from_state: str
    to_state: str
    guard: Optional[Callable] = None  # Returns True if transition is allowed
    description: str = ""


class StateMachine:
    """
    Define and enforce state machine guardrails for AI agents.
    
    Usage:
        sm = nb.StateMachine()
        sm.add_state("planning", tools=["read", "search"], max_iterations=5)
        sm.add_state("coding", tools=["read", "write", "bash_safe"], max_iterations=10)
        sm.add_transition("planning", "coding", when=lambda ctx: ctx.get("analysis_done"))
        sm.start("planning")
    """
    
    def __init__(self, name: str = "default"):
        self.name = name
        self.states: dict[str, State] = {}
        self.transitions: list[Transition] = []
        self.current_state: Optional[str] = None
        self.history: list[dict] = []
        self.iteration_count: int = 0
        self._context: dict = {}
        
    def add_state(
        self,
        name: str,
        tools: list[str] = None,
        max_iterations: int = 10,
        description: str = "",
        on_enter: Callable = None,
        on_exit: Callable = None,
    ) -> "StateMachine":
        """Add a state with tool restrictions."""
        self.states[name] = State(
            name=name,
            allowed_tools=tools or [],
            max_iterations=max_iterations,
            description=description,
            on_enter=on_enter,
            on_exit=on_exit,
        )
        return self
    
    def add_transition(
        self,
        from_state: str,
        to_state: str,
        when: Callable = None,
        description: str = "",
    ) -> "StateMachine":
        """Add a transition with an optional guard condition."""
        self.transitions.append(Transition(
            from_state=from_state,
            to_state=to_state,
            guard=when,
            description=description,
        ))
        return self
    
    def start(self, initial_state: str) -> "StateMachine":
        """Start the state machine at a given state."""
        if initial_state not in self.states:
            raise ValueError(f"Unknown state: {initial_state}")
        self.current_state = initial_state
        self.iteration_count = 0
        self._log("start", initial_state)
        state = self.states[initial_state]
        if state.on_enter:
            state.on_enter(self._context)
        return self
    
    def can_use_tool(self, tool_name: str) -> bool:
        """Check if a tool is allowed in the current state."""
        if self.current_state is None:
            return False
        state = self.states[self.current_state]
        if not state.allowed_tools:
            return True  # No restrictions = all tools allowed
        return tool_name in state.allowed_tools
    
    def check_tool(self, tool_name: str) -> None:
        """Raise if tool is not allowed in current state."""
        if not self.can_use_tool(tool_name):
            state = self.states[self.current_state]
            raise ToolNotAllowedError(
                f"Tool '{tool_name}' not allowed in state '{self.current_state}'. "
                f"Allowed: {state.allowed_tools}"
            )
    
    def try_transition(self, context: dict = None) -> Optional[str]:
        """Attempt all transitions from current state. Returns new state or None."""
        if context:
            self._context.update(context)
        
        for t in self.transitions:
            if t.from_state != self.current_state:
                continue
            if t.guard and not t.guard(self._context):
                continue
            # Transition allowed
            old_state = self.states[self.current_state]
            if old_state.on_exit:
                old_state.on_exit(self._context)
            
            self.current_state = t.to_state
            self.iteration_count = 0
            self._log("transition", t.to_state, description=t.description)
            
            new_state = self.states[t.to_state]
            if new_state.on_enter:
                new_state.on_enter(self._context)
            
            return t.to_state
        
        return None
    
    def increment(self) -> bool:
        """Increment iteration count. Returns False if max exceeded."""
        self.iteration_count += 1
        state = self.states[self.current_state]
        if self.iteration_count >= state.max_iterations:
            self._log("max_iterations", self.current_state, 
                      detail=f"Reached {state.max_iterations}")
            return False
        return True
    
    def get_allowed_tools(self) -> list[str]:
        """Get list of tools allowed in current state."""
        if self.current_state is None:
            return []
        state = self.states[self.current_state]
        return state.allowed_tools
    
    def get_available_transitions(self) -> list[dict]:
        """Get all transitions that could fire from current state."""
        result = []
        for t in self.transitions:
            if t.from_state != self.current_state:
                continue
            can_fire = t.guard(self._context) if t.guard else True
            result.append({
                "to": t.to_state,
                "can_fire": can_fire,
                "description": t.description,
            })
        return result
    
    def to_dict(self) -> dict:
        """Export state machine definition for visualization."""
        return {
            "name": self.name,
            "current_state": self.current_state,
            "iteration_count": self.iteration_count,
            "states": {
                name: {
                    "tools": s.allowed_tools,
                    "max_iterations": s.max_iterations,
                    "description": s.description,
                }
                for name, s in self.states.items()
            },
            "transitions": [
                {
                    "from": t.from_state,
                    "to": t.to_state,
                    "description": t.description,
                    "has_guard": t.guard is not None,
                }
                for t in self.transitions
            ],
            "history": self.history,
            "context_keys": list(self._context.keys()),
        }
    
    def _log(self, action: str, state: str, description: str = "", detail: str = ""):
        self.history.append({
            "timestamp": time.time(),
            "action": action,
            "state": state,
            "description": description,
            "detail": detail,
        })
    
    def __repr__(self):
        return f"StateMachine(name='{self.name}', current='{self.current_state}', states={list(self.states.keys())})"


class ToolNotAllowedError(Exception):
    """Raised when a tool is used outside its allowed state."""
    pass


# === Pre-built workflows ===

def bugfix_workflow() -> StateMachine:
    """Pre-built bugfix workflow: analyze → code → test → review"""
    sm = StateMachine(name="bugfix")
    sm.add_state("analyzing", tools=["read", "search", "grep"], max_iterations=5,
                 description="Analyze the bug, find root cause")
    sm.add_state("coding", tools=["read", "write", "bash_safe"], max_iterations=10,
                 description="Implement the fix")
    sm.add_state("testing", tools=["read", "bash_test"], max_iterations=5,
                 description="Run tests to verify the fix")
    sm.add_state("reviewing", tools=["read"], max_iterations=3,
                 description="Review changes before commit")
    
    sm.add_transition("analyzing", "coding", 
                      when=lambda ctx: ctx.get("root_cause_found"),
                      description="Root cause identified")
    sm.add_transition("coding", "testing",
                      when=lambda ctx: ctx.get("fix_implemented"),
                      description="Fix implemented")
    sm.add_transition("testing", "coding",
                      when=lambda ctx: not ctx.get("tests_pass"),
                      description="Tests failed, iterate on fix")
    sm.add_transition("testing", "reviewing",
                      when=lambda ctx: ctx.get("tests_pass"),
                      description="All tests pass")
    
    return sm


def feature_workflow() -> StateMachine:
    """Pre-built feature development workflow: plan → design → code → test → deploy"""
    sm = StateMachine(name="feature")
    sm.add_state("planning", tools=["read", "search"], max_iterations=5,
                 description="Plan the feature requirements")
    sm.add_state("designing", tools=["read", "write", "search"], max_iterations=5,
                 description="Design the architecture")
    sm.add_state("coding", tools=["read", "write", "bash_safe"], max_iterations=15,
                 description="Implement the feature")
    sm.add_state("testing", tools=["read", "bash_test"], max_iterations=5,
                 description="Write and run tests")
    sm.add_state("deploying", tools=["bash_deploy"], max_iterations=3,
                 description="Deploy to staging/production")
    
    sm.add_transition("planning", "designing",
                      when=lambda ctx: ctx.get("requirements_done"),
                      description="Requirements finalized")
    sm.add_transition("designing", "coding",
                      when=lambda ctx: ctx.get("design_approved"),
                      description="Design approved")
    sm.add_transition("coding", "testing",
                      when=lambda ctx: ctx.get("implementation_done"),
                      description="Implementation complete")
    sm.add_transition("testing", "coding",
                      when=lambda ctx: not ctx.get("tests_pass"),
                      description="Tests failed, iterate")
    sm.add_transition("testing", "deploying",
                      when=lambda ctx: ctx.get("tests_pass"),
                      description="All tests pass")
    
    return sm


def research_workflow() -> StateMachine:
    """Pre-built research workflow: question → search → analyze → synthesize"""
    sm = StateMachine(name="research")
    sm.add_state("questioning", tools=["read", "search"], max_iterations=3,
                 description="Define research questions and scope")
    sm.add_state("searching", tools=["search", "fetch", "read"], max_iterations=10,
                 description="Gather information from multiple sources")
    sm.add_state("analyzing", tools=["read", "calculate", "search"], max_iterations=8,
                 description="Analyze findings and cross-reference")
    sm.add_state("synthesizing", tools=["read", "write"], max_iterations=5,
                 description="Synthesize findings into conclusions")
    
    sm.add_transition("questioning", "searching",
                      when=lambda ctx: ctx.get("questions_defined"),
                      description="Research questions finalized")
    sm.add_transition("searching", "analyzing",
                      when=lambda ctx: ctx.get("sufficient_data"),
                      description="Enough data gathered")
    sm.add_transition("analyzing", "searching",
                      when=lambda ctx: not ctx.get("analysis_complete"),
                      description="Need more data, go back to search")
    sm.add_transition("analyzing", "synthesizing",
                      when=lambda ctx: ctx.get("analysis_complete"),
                      description="Analysis complete, synthesize")
    
    return sm


def trading_workflow() -> StateMachine:
    """
    Pre-built trading/quant workflow: signal → validate → execute → monitor → recover
    
    Designed for quantitative trading and financial API reliability:
    - Signal: Market data arrives, evaluate signal
    - Validate: Cross-check signal against multiple sources
    - Execute: Place order via exchange API (with self-healing)
    - Monitor: Track position and risk limits
    - Recover: Auto-recover from API failures or rejected orders
    """
    sm = StateMachine(name="trading")
    sm.add_state("signal", tools=["market_data", "indicator"], max_iterations=3,
                 description="Receive and evaluate trading signal")
    sm.add_state("validate", tools=["market_data", "risk_check", "indicator"], max_iterations=5,
                 description="Cross-validate signal against multiple sources and risk limits")
    sm.add_state("execute", tools=["order_api", "market_data"], max_iterations=3,
                 description="Execute order via exchange API")
    sm.add_state("monitor", tools=["position_api", "market_data", "risk_check"], max_iterations=100,
                 description="Monitor position, P&L, and risk limits")
    sm.add_state("recover", tools=["order_api", "market_data", "risk_check"], max_iterations=5,
                 description="Auto-recover from API failure or rejected order")
    
    sm.add_transition("signal", "validate",
                      when=lambda ctx: ctx.get("signal_detected"),
                      description="Signal detected, validate before trading")
    sm.add_transition("signal", "signal",
                      when=lambda ctx: not ctx.get("signal_detected"),
                      description="No signal, continue monitoring")
    sm.add_transition("validate", "execute",
                      when=lambda ctx: ctx.get("signal_validated") and ctx.get("risk_ok"),
                      description="Signal validated and within risk limits")
    sm.add_transition("validate", "signal",
                      when=lambda ctx: not ctx.get("signal_validated"),
                      description="Signal invalid, return to monitoring")
    sm.add_transition("validate", "signal",
                      when=lambda ctx: not ctx.get("risk_ok"),
                      description="Risk limit exceeded, abort trade")
    sm.add_transition("execute", "monitor",
                      when=lambda ctx: ctx.get("order_accepted"),
                      description="Order accepted, monitor position")
    sm.add_transition("execute", "recover",
                      when=lambda ctx: not ctx.get("order_accepted"),
                      description="Order failed, attempt recovery")
    sm.add_transition("monitor", "execute",
                      when=lambda ctx: ctx.get("exit_signal"),
                      description="Exit signal triggered, close position")
    sm.add_transition("recover", "execute",
                      when=lambda ctx: ctx.get("recovery_ready"),
                      description="Recovery successful, retry execution")
    sm.add_transition("recover", "monitor",
                      when=lambda ctx: ctx.get("partial_fill"),
                      description="Partial fill, monitor remaining position")
    
    return sm