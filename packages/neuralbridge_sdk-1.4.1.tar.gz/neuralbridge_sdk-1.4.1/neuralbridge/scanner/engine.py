#!/usr/bin/env python3
"""
NeuralBridge Scanner Engine - Static Agent Health Scanner
v1.4.1

Pure local AST-based analysis. No API key, no network, no dependencies.
"""

import ast
import argparse
import json
import os
import sys
from enum import Enum
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Tuple


# ── ANSI Colors ──────────────────────────────────────────────────────────────

class C:
    RED = "\033[91m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    GREEN = "\033[92m"
    MAGENTA = "\033[95m"
    CYAN = "\033[96m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    RESET = "\033[0m"


# ── Data Models ──────────────────────────────────────────────────────────────

class Severity(Enum):
    CRITICAL = "CRITICAL"
    WARNING = "WARNING"
    INFO = "INFO"

    @property
    def icon(self):
        return {"CRITICAL": "🔴", "WARNING": "🟡", "INFO": "🔵"}[self.value]

    @property
    def color(self):
        return {"CRITICAL": C.RED, "WARNING": C.YELLOW, "INFO": C.BLUE}[self.value]


class Dimension(Enum):
    RELIABILITY = "reliability"
    CONTEXT = "context"
    CASCADE = "cascade"
    SECURITY = "security"

    @property
    def label(self):
        return {
            "reliability": "Reliability Collapse",
            "context": "Context Bloat",
            "cascade": "Cascade Failure",
            "security": "Security & Compliance",
        }[self.value]

    @property
    def icon(self):
        return {
            "reliability": "🩺",
            "context": "🧠",
            "cascade": "⛓️",
            "security": "🛡️",
        }[self.value]


@dataclass
class Finding:
    file: str
    line: int
    severity: Severity
    dimension: Dimension
    category: str
    message: str
    suggestion: str


# ── AST Scanner ──────────────────────────────────────────────────────────────

class AgentScanner(ast.NodeVisitor):
    """Scans AST for Agent health risks across 4 dimensions."""

    def __init__(self, filepath: str):
        self.filepath = filepath
        self.findings: List[Finding] = []
        self._in_try = 0
        self._in_except = False
        self._in_while = 0
        self._in_for = 0
        self._function_depth = 0

    # ── Control flow tracking ────────────────────────────────────────────

    def visit_Try(self, node: ast.Try):
        self._in_try += 1
        for child in node.body:
            self.visit(child)
        self._in_except = True
        for handler in node.handlers:
            for child in handler.body:
                self.visit(child)
        self._in_except = False
        for child in node.orelse:
            self.visit(child)
        for child in node.finalbody:
            self.visit(child)
        self._in_try -= 1

    def visit_While(self, node: ast.While):
        self._in_while += 1
        # Check for infinite loop patterns with LLM calls
        if node.test.value is True if isinstance(node.test, ast.Constant) else False:
            self._check_infinite_loop(node)
        self.generic_visit(node)
        self._in_while -= 1

    def visit_For(self, node: ast.For):
        self._in_for += 1
        self.generic_visit(node)
        self._in_for -= 1

    def visit_FunctionDef(self, node: ast.FunctionDef):
        self._function_depth += 1
        self._check_agent_function(node)
        self.generic_visit(node)
        self._function_depth -= 1

    visit_AsyncFunctionDef = visit_FunctionDef

    # ── Dimension 1: Reliability Collapse ────────────────────────────────

    def visit_Call(self, node: ast.Call):
        call_name = self._get_call_name(node)

        # API call checks
        if call_name and self._is_api_call(call_name):
            # No error handling
            if self._in_try == 0:
                self.findings.append(Finding(
                    file=self.filepath,
                    line=node.lineno,
                    severity=Severity.CRITICAL,
                    dimension=Dimension.RELIABILITY,
                    category="no_error_handling",
                    message=f"API call `{call_name}` has no try/except — exceptions will crash your agent",
                    suggestion="Wrap in try/except or use NeuralBridge for automatic error handling",
                ))

            # No timeout
            has_timeout = any(kw.arg == "timeout" for kw in node.keywords)
            if not has_timeout:
                self.findings.append(Finding(
                    file=self.filepath,
                    line=node.lineno,
                    severity=Severity.WARNING,
                    dimension=Dimension.RELIABILITY,
                    category="no_timeout",
                    message=f"API call `{call_name}` has no timeout — agent may hang indefinitely",
                    suggestion="Add timeout parameter: `timeout=30`",
                ))

            # Hardcoded model
            for kw in node.keywords:
                if kw.arg == "model" and isinstance(kw.value, ast.Constant):
                    model_val = str(kw.value.value)
                    if any(m in model_val for m in HARDCODED_MODELS):
                        self.findings.append(Finding(
                            file=self.filepath,
                            line=node.lineno,
                            severity=Severity.WARNING,
                            dimension=Dimension.RELIABILITY,
                            category="hardcoded_model",
                            message=f"Hardcoded model `{model_val}` — no fallback when model is down",
                            suggestion="Use a model list with fallback: `['gpt-4', 'gpt-3.5-turbo']`",
                        ))

            # No max_tokens (context bloat)
            has_max_tokens = any(kw.arg in ("max_tokens", "max_new_tokens") for kw in node.keywords)
            if not has_max_tokens and self._is_api_call(call_name):
                self.findings.append(Finding(
                    file=self.filepath,
                    line=node.lineno,
                    severity=Severity.WARNING,
                    dimension=Dimension.CONTEXT,
                    category="no_max_tokens",
                    message=f"API call `{call_name}` has no max_tokens — response may bloat context window",
                    suggestion="Set max_tokens to prevent runaway generation: `max_tokens=2048`",
                ))

        # Tool call without return check
        if call_name and self._is_tool_call(call_name):
            if self._in_try == 0 and not self._in_except:
                self.findings.append(Finding(
                    file=self.filepath,
                    line=node.lineno,
                    severity=Severity.WARNING,
                    dimension=Dimension.RELIABILITY,
                    category="unchecked_tool_call",
                    message=f"Tool call `{call_name}` return value not checked — silent failures possible",
                    suggestion="Always check tool return values before proceeding",
                ))

        # Retry bomb detection: while/retry without backoff
        if call_name and self._in_while > 0:
            if any(r in call_name.lower() for r in ["retry", "create", "complete", "run", "call"]):
                if self._in_try == 0:
                    self.findings.append(Finding(
                        file=self.filepath,
                        line=node.lineno,
                        severity=Severity.CRITICAL,
                        dimension=Dimension.RELIABILITY,
                        category="retry_storm",
                        message=f"API call `{call_name}` in loop without backoff — retry storm risk",
                        suggestion="Add exponential backoff: `time.sleep(2 ** attempt)` or use NeuralBridge auto-retry",
                    ))

        self.generic_visit(node)

    # ── Dimension 2: Context Bloat ───────────────────────────────────────

    def visit_Assign(self, node: ast.Assign):
        # Hardcoded API keys
        for target in node.targets:
            name = ""
            if isinstance(target, ast.Name):
                name = target.id.lower()
            elif isinstance(target, ast.Attribute):
                name = target.attr.lower()

            if any(k in name for k in ["api_key", "apikey", "openai_key", "anthropic_key"]):
                if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
                    val = node.value.value
                    if len(val) > 10 and not val.startswith("os.") and not val.startswith("env"):
                        self.findings.append(Finding(
                            file=self.filepath,
                            line=node.lineno,
                            severity=Severity.CRITICAL,
                            dimension=Dimension.SECURITY,
                            category="hardcoded_api_key",
                            message="API key hardcoded in source code — security risk",
                            suggestion="Use environment variables: `os.environ['OPENAI_API_KEY']`",
                        ))

        # Message list append without truncation
        if isinstance(node.value, ast.Call):
            call_name = self._get_call_name(node.value)
            if call_name and call_name.endswith(".append"):
                for target in node.targets:
                    tgt_name = self._get_target_name(target)
                    if tgt_name and any(k in tgt_name.lower() for k in ["messages", "history", "context", "conversation"]):
                        self.findings.append(Finding(
                            file=self.filepath,
                            line=node.lineno,
                            severity=Severity.WARNING,
                            dimension=Dimension.CONTEXT,
                            category="unbounded_messages",
                            message=f"Message list `{tgt_name}.append()` without truncation — context will grow unbounded",
                            suggestion="Truncate old messages: `messages = messages[-MAX_HISTORY:]` or implement summarization",
                        ))

        self.generic_visit(node)

    # ── Helper: Infinite loop check ──────────────────────────────────────

    def _check_infinite_loop(self, node: ast.While):
        """Check if while True contains LLM/tool calls without break condition."""
        has_llm_call = False
        has_break = False

        for child in ast.walk(node):
            if isinstance(child, ast.Call):
                name = self._get_call_name(child)
                if name and (self._is_api_call(name) or self._is_tool_call(name)):
                    has_llm_call = True
            if isinstance(child, ast.Break):
                has_break = True

        if has_llm_call and not has_break:
            self.findings.append(Finding(
                file=self.filepath,
                line=node.lineno,
                severity=Severity.CRITICAL,
                dimension=Dimension.RELIABILITY,
                category="agent_dead_loop",
                message="while True with LLM/tool calls and no break — agent may loop forever",
                suggestion="Add a max iteration counter and break condition",
            ))

    # ── Helper: Agent function check ─────────────────────────────────────

    def _check_agent_function(self, node: ast.FunctionDef):
        """Check agent-like functions for missing safeguards."""
        func_name = node.name.lower()
        is_agent_func = any(k in func_name for k in [
            "agent", "run", "execute", "pipeline", "chain", "workflow",
            "process", "handle", "dispatch", "orchestrate",
        ])

        if not is_agent_func:
            return

        # Count API/tool calls
        api_calls = 0
        has_checkpoint = False
        has_circuit_breaker = False

        for child in ast.walk(node):
            if isinstance(child, ast.Call):
                name = self._get_call_name(child)
                if name and (self._is_api_call(name) or self._is_tool_call(name)):
                    api_calls += 1

        # Multi-step agent without checkpoint
        if api_calls >= 3 and not has_checkpoint:
            self.findings.append(Finding(
                file=self.filepath,
                line=node.lineno,
                severity=Severity.WARNING,
                dimension=Dimension.CASCADE,
                category="no_checkpoint",
                message=f"Agent function `{node.name}` has {api_calls} API/tool calls but no checkpoint — failure means restart from scratch",
                suggestion="Save intermediate state so the agent can resume after failures",
            ))

        # Multi-step agent without circuit breaker
        if api_calls >= 3 and not has_circuit_breaker:
            self.findings.append(Finding(
                file=self.filepath,
                line=node.lineno,
                severity=Severity.WARNING,
                dimension=Dimension.CASCADE,
                category="no_circuit_breaker",
                message=f"Agent function `{node.name}` has {api_calls} sequential calls but no circuit breaker — one failure cascades to all",
                suggestion="Add circuit breaker pattern: skip downstream steps if upstream fails",
            ))

    # ── Dimension 4: Security & Compliance ───────────────────────────────

    def visit_Expr(self, node: ast.Expr):
        """Check for dangerous function calls."""
        if isinstance(node.value, ast.Call):
            call_name = self._get_call_name(node.value)
            if call_name:
                # eval/exec usage
                if call_name in ("eval", "exec"):
                    self.findings.append(Finding(
                        file=self.filepath,
                        line=node.lineno,
                        severity=Severity.CRITICAL,
                        dimension=Dimension.SECURITY,
                        category="code_injection",
                        message=f"`{call_name}()` detected — agent can execute arbitrary code",
                        suggestion="Use ast.literal_eval() for safe parsing, or sandbox execution",
                    ))

                # subprocess calls
                if "subprocess" in call_name:
                    self.findings.append(Finding(
                        file=self.filepath,
                        line=node.lineno,
                        severity=Severity.CRITICAL,
                        dimension=Dimension.SECURITY,
                        category="shell_injection",
                        message=f"`{call_name}()` — agent can run system commands",
                        suggestion="Restrict subprocess usage or use NeuralBridge security护栏",
                    ))

                # pickle.load
                if "pickle" in call_name and "load" in call_name:
                    self.findings.append(Finding(
                        file=self.filepath,
                        line=node.lineno,
                        severity=Severity.CRITICAL,
                        dimension=Dimension.SECURITY,
                        category="unsafe_deserialization",
                        message=f"`{call_name}()` — arbitrary code execution via deserialization",
                        suggestion="Use json.loads() or restrict pickle to trusted data only",
                    ))

        self.generic_visit(node)

    def visit_JoinedStr(self, node: ast.JoinedStr):
        """Check for f-string prompt injection."""
        # Walk up to see if this is inside an API call's prompt/message arg
        for value in node.values:
            if isinstance(value, ast.FormattedValue):
                if isinstance(value.value, ast.Name):
                    var_name = value.value.id.lower()
                    if any(k in var_name for k in ["user", "input", "query", "message", "prompt", "request"]):
                        self.findings.append(Finding(
                            file=self.filepath,
                            line=node.lineno,
                            severity=Severity.WARNING,
                            dimension=Dimension.SECURITY,
                            category="prompt_injection_risk",
                            message=f"User input `{value.value.id}` directly interpolated into string — prompt injection risk",
                            suggestion="Sanitize user input before including in prompts, or use structured message format",
                        ))
                        break
        self.generic_visit(node)

    # ── Utility methods ──────────────────────────────────────────────────

    def _get_call_name(self, node: ast.Call) -> Optional[str]:
        parts = []
        current = node.func
        while isinstance(current, ast.Attribute):
            parts.append(current.attr)
            current = current.value
        if isinstance(current, ast.Name):
            parts.append(current.id)
        parts.reverse()
        return ".".join(parts) if parts else None

    def _is_api_call(self, name: str) -> bool:
        indicators = [
            "openai.", "ChatCompletion", "Completion.create",
            "anthropic.", "messages.create",
            "google.generativeai", "GenerativeModel",
            "completions.create", "chat.completions",
        ]
        return any(ind in name for ind in indicators)

    def _is_tool_call(self, name: str) -> bool:
        tool_indicators = [
            "tool", "function_call", "browse", "search",
            "execute", "run_code", "repl", "shell",
            "http", "request", "fetch", "get(", "post(",
        ]
        return any(ind in name.lower() for ind in tool_indicators)

    def _get_target_name(self, node) -> str:
        if isinstance(node, ast.Name):
            return node.id
        if isinstance(node, ast.Attribute):
            return node.attr
        if isinstance(node, ast.Subscript):
            return self._get_target_name(node.value)
        return ""


# ── Known Models ─────────────────────────────────────────────────────────────

HARDCODED_MODELS = {
    "gpt-4", "gpt-4o", "gpt-4-turbo", "gpt-3.5-turbo",
    "claude-3-opus", "claude-3-sonnet", "claude-3-haiku",
    "claude-3.5-sonnet", "claude-4",
    "gemini-pro", "gemini-1.5-pro", "gemini-1.5-flash",
    "deepseek-chat", "deepseek-reasoner",
    "mistral-large", "mistral-medium", "mistral-small",
}


# ── Scanner Engine ───────────────────────────────────────────────────────────

def scan_directory(path: str, deep: bool = False) -> List[Finding]:
    findings = []
    for root, dirs, files in os.walk(path):
        dirs[:] = [d for d in dirs if d not in {
            ".git", "__pycache__", "node_modules", ".venv", "venv",
            "env", ".env", ".tox", ".mypy_cache", ".pytest_cache",
        }]
        for f in files:
            if not f.endswith(".py"):
                continue
            filepath = os.path.join(root, f)
            try:
                with open(filepath, "r", encoding="utf-8", errors="ignore") as fh:
                    source = fh.read()
                tree = ast.parse(source, filename=filepath)
                scanner = AgentScanner(filepath)
                scanner.visit(tree)
                findings.extend(scanner.findings)
            except (SyntaxError, UnicodeDecodeError):
                continue

    # Regex-based API key detection on all files
    all_files = []
    for root2, dirs2, files2 in os.walk(path):
        dirs2[:] = [d for d in dirs2 if d not in {
            ".git", "__pycache__", "node_modules", ".venv", "venv",
            "env", ".env", ".tox", ".mypy_cache", ".pytest_cache",
            "dist", "build",
        }]
        for f2 in files2:
            if f2.endswith(".py"):
                all_files.append(os.path.join(root2, f2))

    for fp in all_files:
        _regex_check_file(fp, findings)

    # Single provider check
    sp = _check_single_provider(path)
    if sp:
        findings.append(sp)

    # Deep scan: dependency checking
    if deep:
        dep_findings = _check_dependencies(path)
        findings.extend(dep_findings)

    return findings



# ── New Functions (v1.4.1) ──────────────────────────────────────────────────

def scan_file(filepath: str) -> List[Finding]:
    """Scan a single Python file."""
    if not os.path.isfile(filepath):
        print(f"{C.RED}Error: {filepath} is not a file{C.RESET}")
        return []
    if not filepath.endswith(".py"):
        print(f"{C.YELLOW}Warning: {filepath} is not a Python file{C.RESET}")
        return []
    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as fh:
            source = fh.read()
        tree = ast.parse(source, filename=filepath)
        scanner = AgentScanner(filepath)
        scanner.visit(tree)
        _regex_check_file(filepath, scanner.findings, source)
        return scanner.findings
    except SyntaxError as e:
        print(f"{C.RED}Syntax error in {filepath}: {e}{C.RESET}")
        return []


def _regex_check_file(filepath: str, findings: List[Finding], source: str = None):
    """Regex-based checks for patterns AST cannot catch."""
    import re
    if source is None:
        try:
            with open(filepath, "r", encoding="utf-8", errors="ignore") as fh:
                source = fh.read()
        except Exception:
            return

    api_key_patterns = [
        (r'sk-[a-zA-Z0-9]{20,}', "OpenAI API key"),
        (r'sk-proj-[a-zA-Z0-9_-]{20,}', "OpenAI project API key"),
        (r'sk-ant-api[a-zA-Z0-9_-]{20,}', "Anthropic API key"),
        (r'AIza[a-zA-Z0-9_-]{30,}', "Google AI API key"),
    ]

    for i, line in enumerate(source.splitlines(), 1):
        stripped = line.strip()
        if stripped.startswith('#'):
            continue
        for pattern, desc in api_key_patterns:
            if re.search(pattern, stripped):
                if 'os.environ' in stripped or 'os.getenv' in stripped or 'environ.get' in stripped:
                    continue
                findings.append(Finding(
                    file=filepath, line=i,
                    severity=Severity.CRITICAL,
                    dimension=Dimension.SECURITY,
                    category="hardcoded_api_key_pattern",
                    message=f"Possible {desc} found in source code",
                    suggestion="Move to environment variable",
                ))
                break


def _check_single_provider(path: str) -> Optional[Finding]:
    """Check if project depends on only one LLM provider."""
    providers = set()
    for root2, dirs2, files2 in os.walk(path):
        dirs2[:] = [d for d in dirs2 if d not in {
            ".git", "__pycache__", "node_modules", ".venv", "venv", "env",
            ".tox", ".mypy_cache", ".pytest_cache", "dist", "build",
        }]
        for f2 in files2:
            if not f2.endswith(".py"):
                continue
            fp = os.path.join(root2, f2)
            try:
                with open(fp, "r", encoding="utf-8", errors="ignore") as fh:
                    src = fh.read()
                if "openai" in src:
                    providers.add("openai")
                if "anthropic" in src:
                    providers.add("anthropic")
                if "google.generativeai" in src or "genai" in src:
                    providers.add("google")
                if "groq" in src:
                    providers.add("groq")
            except Exception:
                continue

    if len(providers) == 1:
        provider = list(providers)[0]
        return Finding(
            file="<project>", line=0,
            severity=Severity.WARNING,
            dimension=Dimension.RELIABILITY,
            category="single_provider",
            message=f"Project depends on only one LLM provider ({provider}) - no fallback if it goes down",
            suggestion="Add a fallback provider with NeuralBridge",
        )
    return None


def _check_dependencies(path: str) -> List[Finding]:
    """Check pip dependencies for known vulnerabilities."""
    import re as _re
    findings = []
    req_files = []
    for name in ["requirements.txt", "requirements-dev.txt", "pyproject.toml"]:
        req_path = os.path.join(path, name)
        if os.path.exists(req_path):
            req_files.append(req_path)

    if not req_files:
        return findings

    packages = set()
    for req_file in req_files:
        try:
            with open(req_file, "r", encoding="utf-8") as fh:
                for line in fh:
                    line = line.strip()
                    if line and not line.startswith('#') and not line.startswith('-'):
                        pkg = _re.split(r'[=<>!~[]', line)[0].strip()
                        if pkg:
                            packages.add(pkg.lower())
        except Exception:
            continue

    if packages:
        findings.append(Finding(
            file="<dependencies>", line=0,
            severity=Severity.INFO,
            dimension=Dimension.SECURITY,
            category="dependency_check",
            message=f"Found {len(packages)} packages in {len(req_files)} requirement files - run pip-audit for CVE scanning",
            suggestion="Install pip-audit: pip install pip-audit && pip-audit",
        ))

    return findings


# ── Scoring ──────────────────────────────────────────────────────────────────

def compute_scores(findings: List[Finding]) -> Dict[str, int]:
    """Compute health score per dimension (0-100, 100=perfect)."""
    scores = {}
    for dim in Dimension:
        dim_findings = [f for f in findings if f.dimension == dim]
        if not dim_findings:
            scores[dim.value] = 100
            continue
        penalty = 0
        for f in dim_findings:
            if f.severity == Severity.CRITICAL:
                penalty += 15
            elif f.severity == Severity.WARNING:
                penalty += 5
            else:
                penalty += 1
        scores[dim.value] = max(0, 100 - penalty)
    return scores


def overall_score(scores: Dict[str, int]) -> int:
    return sum(scores.values()) // len(scores) if scores else 100


def grade_label(score: int) -> str:
    if score >= 90:
        return "A 🟢"
    elif score >= 75:
        return "B 🟡"
    elif score >= 60:
        return "C 🟠"
    elif score >= 40:
        return "D 🔴"
    else:
        return "F 💀"


def ascii_radar(scores: Dict[str, int]) -> str:
    """Draw ASCII radar chart for 4 dimensions."""
    labels = {
        "reliability": "Reliability",
        "context": "Context    ",
        "cascade": "Cascade    ",
        "security": "Security   ",
    }
    lines = []
    lines.append("         ┌─────────────────────────┐")
    for dim_key in ["reliability", "context", "cascade", "security"]:
        score = scores.get(dim_key, 100)
        filled = score // 5
        empty = 20 - filled
        bar = "█" * filled + "░" * empty
        label = labels[dim_key]
        lines.append(f"  {label} │{bar}│ {score:3d}")
    lines.append("         └─────────────────────────┘")
    return "\n".join(lines)


# ── Reporters ────────────────────────────────────────────────────────────────

def report_terminal(findings: List[Finding], scan_path: str = ".") -> str:
    if not findings:
        print(f"\n{C.GREEN}{C.BOLD}✓ Agent health check passed!{C.RESET}")
        print(f"\n{C.DIM}Your Agent looks healthy across all 4 dimensions.{C.RESET}")
        print(ascii_radar({"reliability": 100, "context": 100, "cascade": 100, "security": 100}))
        return

    scores = compute_scores(findings)
    overall = overall_score(scores)

    # Header
    print(f"\n{C.BOLD}╔══════════════════════════════════════════════════════╗{C.RESET}")
    print(f"{C.BOLD}║  nb doctor v2 — Agent Health Diagnostic Report      ║{C.RESET}")
    print(f"{C.BOLD}╚══════════════════════════════════════════════════════╝{C.RESET}")

    # Overall
    grade = grade_label(overall)
    print(f"\n  {C.BOLD}Overall Agent Health: {grade} ({overall}/100){C.RESET}")

    # Radar
    print()
    print(ascii_radar(scores))

    # Summary by dimension
    print(f"\n  {C.BOLD}By Dimension:{C.RESET}")
    for dim in Dimension:
        dim_findings = [f for f in findings if f.dimension == dim]
        critical = sum(1 for f in dim_findings if f.severity == Severity.CRITICAL)
        warning = sum(1 for f in dim_findings if f.severity == Severity.WARNING)
        info = sum(1 for f in dim_findings if f.severity == Severity.INFO)
        score = scores[dim.value]
        dim_grade = grade_label(score)
        print(f"    {dim.icon} {dim.label:25s} {dim_grade:6s}  🔴{critical}  🟡{warning}  🔵{info}")

    # Details by dimension
    severity_order = {Severity.CRITICAL: 0, Severity.WARNING: 1, Severity.INFO: 2}

    for dim in Dimension:
        dim_findings = [f for f in findings if f.dimension == dim]
        if not dim_findings:
            continue
        dim_findings.sort(key=lambda f: (severity_order[f.severity], f.file, f.line))

        print(f"\n  {C.BOLD}{dim.icon} {dim.label}{C.RESET}")
        print(f"  {'─' * 52}")
        current_file = None
        for f in dim_findings:
            if f.file != current_file:
                current_file = f.file
                print(f"    {C.BOLD}📄 {f.file}{C.RESET}")
            sev = f.severity
            print(f"      {sev.icon} {sev.color}{C.BOLD}L{f.line}{C.RESET} {sev.color}[{sev.value}]{C.RESET} {f.message}")
            print(f"        {C.DIM}→ {f.suggestion}{C.RESET}")

    # CTA
    print(f"\n  {C.BOLD}{'─' * 54}{C.RESET}")
    print(f"\n  {C.GREEN}{C.BOLD}🩺 Diagnosis done. Now heal your Agent:{C.RESET}")
    print(f"""
    {C.DIM}# Before: unprotected agent calls{C.RESET}
    response = openai.chat.completions.create(model="gpt-4", ...)

    {C.GREEN}# After: self-healing agent calls{C.RESET}
    {C.GREEN}from neuralbridge import register, heal{C.RESET}
    {C.GREEN}register("gpt-4", strategy="fallback", alternatives=["gpt-3.5-turbo"]){C.RESET}
    {C.GREEN}response = heal(lambda: openai.chat.completions.create(model="gpt-4", ...)){C.RESET}
    """)
    print(f"  {C.BOLD}pip install neuralbridge-sdk{C.RESET}")
    print(f"  {C.DIM}95.19% self-heal rate · 0.0025ms latency · 110KB · zero dependencies{C.RESET}")
    print(f"  {C.DIM}https://pypi.org/project/neuralbridge-sdk/{C.RESET}")
    print(f"  {C.DIM}https://neuralbridge.cn{C.RESET}\n")


def report_json(findings: List[Finding], scan_path: str = ".") -> str:
    scores = compute_scores(findings)
    overall = overall_score(scores)
    return json.dumps({
        "overall_score": overall,
        "overall_grade": grade_label(overall).split()[0],
        "dimension_scores": {k: v for k, v in scores.items()},
        "findings": [
            {
                "file": f.file,
                "line": f.line,
                "severity": f.severity.value,
                "dimension": f.dimension.value,
                "category": f.category,
                "message": f.message,
                "suggestion": f.suggestion,
            }
            for f in findings
        ],
    }, indent=2)



# ── HTML Report (v1.4.1) ─────────────────────────────────────────────────

def report_html(findings: List[Finding], scan_path: str = ".") -> str:
    """Generate an HTML health report."""
    from datetime import datetime
    scores = compute_scores(findings)
    overall = overall_score(scores)
    grade = grade_label(overall)

    findings_html = ""
    severity_order = {Severity.CRITICAL: 0, Severity.WARNING: 1, Severity.INFO: 2}
    for dim in Dimension:
        dim_findings = [f for f in findings if f.dimension == dim]
        if not dim_findings:
            continue
        dim_findings.sort(key=lambda f: (severity_order[f.severity], f.file, f.line))
        findings_html += f"<h2>{dim.icon} {dim.label}</h2>\n"
        current_file = None
        for f in dim_findings:
            if f.file != current_file:
                current_file = f.file
                findings_html += f"<h3>&#128196; {f.file}</h3>\n"
            sev_class = f.severity.value.lower()
            findings_html += f'<div class="finding {sev_class}"><span class="severity">{f.severity.icon} [{f.severity.value}]</span> <span class="location">L{f.line}</span> <span class="message">{f.message}</span><div class="suggestion">&#8594; {f.suggestion}</div></div>\n'

    dim_bars = ""
    for dim in Dimension:
        score = scores[dim.value]
        dg = grade_label(score)
        bar_color = "#4caf50" if score >= 90 else "#ff9800" if score >= 60 else "#f44336"
        dim_bars += f'<div class="dim-row"><span class="dim-label">{dim.icon} {dim.label}</span><div class="dim-bar-bg"><div class="dim-bar" style="width:{score}%;background:{bar_color}"></div></div><span class="dim-score">{score} ({dg})</span></div>\n'

    html = f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><title>nb doctor - Agent Health Report</title>
<style>
body {{ font-family: -apple-system, sans-serif; max-width: 900px; margin: 40px auto; padding: 0 20px; background: #0d1117; color: #c9d1d9; }}
h1 {{ color: #58a6ff; border-bottom: 1px solid #21262d; padding-bottom: 12px; }}
h2 {{ color: #f0883e; margin-top: 32px; }}
h3 {{ color: #8b949e; font-size: 14px; }}
.dim-row {{ display: flex; align-items: center; margin: 8px 0; }}
.dim-label {{ width: 180px; font-size: 14px; }}
.dim-bar-bg {{ flex: 1; height: 20px; background: #21262d; border-radius: 10px; overflow: hidden; }}
.dim-bar {{ height: 100%; border-radius: 10px; }}
.dim-score {{ width: 80px; text-align: right; font-size: 14px; }}
.finding {{ margin: 8px 0; padding: 10px 14px; border-radius: 6px; border-left: 3px solid; }}
.finding.critical {{ background: #3d1114; border-color: #f85149; }}
.finding.warning {{ background: #3b2e00; border-color: #d29922; }}
.finding.info {{ background: #0c2d6b; border-color: #58a6ff; }}
.severity {{ font-weight: bold; margin-right: 8px; }}
.location {{ color: #8b949e; margin-right: 8px; font-family: monospace; }}
.message {{ font-size: 14px; }}
.suggestion {{ color: #8b949e; font-size: 13px; margin-top: 4px; }}
.cta {{ margin-top: 32px; padding: 20px; background: #161b22; border-radius: 8px; border: 1px solid #21262d; }}
</style></head><body>
<h1>&#129658; nb doctor - Agent Health Report</h1>
<p style="color:#8b949e;font-size:13px">Scanned: {scan_path} | {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
<div style="text-align:center;margin:24px 0"><div style="font-size:48px;font-weight:bold">{grade}</div><div style="font-size:16px;color:#8b949e">Overall Score: {overall}/100</div></div>
<h2>Dimension Scores</h2>
{dim_bars}
<h2>Findings ({len(findings)} total)</h2>
{findings_html if findings else '<p style="color:#3fb950">All clear!</p>'}
<div class="cta"><h3>Heal your Agent</h3><p>pip install neuralbridge-sdk</p></div>
</body></html>"""
    return html


# ── CLI ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        prog="nb doctor v2",
        description="🔍 Scan your Python Agent for health risks across 4 dimensions",
    )
    parser.add_argument(
        "path",
        help="Path to Python project directory",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output JSON report",
    )
    args = parser.parse_args()

    if not os.path.isdir(args.path):
        print(f"{C.RED}Error: {args.path} is not a directory{C.RESET}")
        sys.exit(1)

    findings = scan_directory(args.path)

    if args.json:
        print(report_json(findings))
    else:
        report_terminal(findings)

    sys.exit(1 if any(f.severity == Severity.CRITICAL for f in findings) else 0)


if __name__ == "__main__":
    main()
