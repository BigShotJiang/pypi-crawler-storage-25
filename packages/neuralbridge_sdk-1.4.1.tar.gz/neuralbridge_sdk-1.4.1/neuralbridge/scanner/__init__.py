"""
NeuralBridge Scanner — Static Agent Health Scanner
Zero-dependency, no API key required. Pure local AST analysis.
"""

from neuralbridge.scanner.engine import (
    AgentScanner,
    Finding,
    Severity,
    Dimension,
    scan_directory,
    scan_file,
    compute_scores,
    overall_score,
    grade_label,
    ascii_radar,
    report_terminal,
    report_json,
    report_html,
)

__all__ = [
    "AgentScanner", "Finding", "Severity", "Dimension",
    "scan_directory", "scan_file",
    "compute_scores", "overall_score", "grade_label", "ascii_radar",
    "report_terminal", "report_json", "report_html",
]
