#!/usr/bin/env python3
"""
NeuralBridge Doctor v2 — Free Agent Health Diagnostic Tool
Coverage: All 4 Agent Runtime Problems

🩺 Diagnostic Flywheel — see where it hurts, for free.

Usage:
  nb doctor                    # Run with demo data
  nb doctor --live             # Probe your real APIs
  nb doctor --watch            # Continuous monitoring
  nb doctor --format markdown  # Markdown output (for sharing)
"""

import time
import json
import math
import statistics
from typing import Optional
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime


# ═══════════════════════════════════════════════════════════
#  Core Types
# ═══════════════════════════════════════════════════════════

class ErrorType(Enum):
    # Layer 1: Reliability Collapse
    RATE_LIMIT = "rate_limit"
    TIMEOUT = "timeout"
    SERVER_ERROR = "server_error"
    AUTH_FAILURE = "auth_failure"
    NETWORK_ERROR = "network_error"
    MODEL_OVERLOAD = "model_overload"
    QUOTA_EXCEEDED = "quota_exceeded"
    # Layer 2: Context Bloat & Silent Failure
    CONTEXT_OVERFLOW = "context_overflow"
    SILENT_DEGRADATION = "silent_degradation"
    TOKEN_EXPIRY = "token_expiry"
    MEMORY_LEAK = "memory_leak"
    # Layer 3: Cascade Collapse
    TOOL_HALLUCINATION = "tool_hallucination"
    GUARDRAIL_BYPASS = "guardrail_bypass"
    INFINITE_LOOP = "infinite_loop"
    CASCADE_FAILURE = "cascade_failure"
    # Layer 4: Security & Compliance
    SUPPLY_CHAIN_ATTACK = "supply_chain_attack"
    MODEL_SUBSTITUTION = "model_substitution"
    PERMISSION_ESCALATION = "permission_escalation"
    DATA_EXFILTRATION = "data_exfiltration"
    UNKNOWN = "unknown"


class Severity(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class ProblemLayer(Enum):
    RELIABILITY = "🩺 可靠性崩塌"
    CONTEXT_BLOAT = "🧠 上下文膨胀"
    CASCADE = "🔗 级联崩溃"
    SECURITY = "🛡️ 安全合规"


# Map error types to problem layers
ERROR_LAYER_MAP = {
    ErrorType.RATE_LIMIT: ProblemLayer.RELIABILITY,
    ErrorType.TIMEOUT: ProblemLayer.RELIABILITY,
    ErrorType.SERVER_ERROR: ProblemLayer.RELIABILITY,
    ErrorType.AUTH_FAILURE: ProblemLayer.RELIABILITY,
    ErrorType.NETWORK_ERROR: ProblemLayer.RELIABILITY,
    ErrorType.MODEL_OVERLOAD: ProblemLayer.RELIABILITY,
    ErrorType.QUOTA_EXCEEDED: ProblemLayer.RELIABILITY,
    ErrorType.CONTEXT_OVERFLOW: ProblemLayer.CONTEXT_BLOAT,
    ErrorType.SILENT_DEGRADATION: ProblemLayer.CONTEXT_BLOAT,
    ErrorType.TOKEN_EXPIRY: ProblemLayer.CONTEXT_BLOAT,
    ErrorType.MEMORY_LEAK: ProblemLayer.CONTEXT_BLOAT,
    ErrorType.TOOL_HALLUCINATION: ProblemLayer.CASCADE,
    ErrorType.GUARDRAIL_BYPASS: ProblemLayer.CASCADE,
    ErrorType.INFINITE_LOOP: ProblemLayer.CASCADE,
    ErrorType.CASCADE_FAILURE: ProblemLayer.CASCADE,
    ErrorType.SUPPLY_CHAIN_ATTACK: ProblemLayer.SECURITY,
    ErrorType.MODEL_SUBSTITUTION: ProblemLayer.SECURITY,
    ErrorType.PERMISSION_ESCALATION: ProblemLayer.SECURITY,
    ErrorType.DATA_EXFILTRATION: ProblemLayer.SECURITY,
    ErrorType.UNKNOWN: ProblemLayer.RELIABILITY,
}


@dataclass
class AgentEvent:
    """A single event in an Agent's lifecycle."""
    timestamp: float
    agent_name: str
    provider: str
    model: str
    latency_ms: float
    token_count: int = 0
    context_tokens: int = 0
    cost: float = 0.0
    success: bool = True
    error_type: Optional[ErrorType] = None
    tool_used: str = ""
    step_number: int = 0
    metadata: dict = field(default_factory=dict)


@dataclass
class LayerDiagnosis:
    """Diagnosis for one of the 4 problem layers."""
    layer: ProblemLayer
    severity: Severity
    total_events: int
    problem_events: int
    problem_rate: float
    findings: list
    recommendations: list
    healable_rate: float
    estimated_monthly_loss: float


@dataclass
class DoctorReport:
    """Complete Agent Health Report — covers all 4 problem layers."""
    scan_time: str
    scan_duration_seconds: float
    total_events_analyzed: int
    total_problems: int
    overall_problem_rate: float
    estimated_monthly_loss: float
    healable_savings: float
    layer_diagnoses: list  # List[LayerDiagnosis]
    top_pain_points: list
    savings_if_healed: dict
    risk_alerts: list
    agent_score: float  # 0-100, overall Agent health score


# ═══════════════════════════════════════════════════════════
#  Agent Health Scanner
# ═══════════════════════════════════════════════════════════

class AgentHealthScanner:
    """
    Scan Agent event history to identify all 4 problem layers.

    Usage:
        scanner = AgentHealthScanner()
        scanner.add_event(agent="trader", provider="openai", model="gpt-4", ...)
        report = scanner.diagnose()
        print(ReportFormatter.terminal(report))
    """

    HEALABLE_RATES = {
        ErrorType.RATE_LIMIT: 0.95,
        ErrorType.TIMEOUT: 0.90,
        ErrorType.SERVER_ERROR: 0.85,
        ErrorType.MODEL_OVERLOAD: 0.92,
        ErrorType.NETWORK_ERROR: 0.88,
        ErrorType.QUOTA_EXCEEDED: 0.60,
        ErrorType.AUTH_FAILURE: 0.10,
        ErrorType.CONTEXT_OVERFLOW: 0.80,
        ErrorType.SILENT_DEGRADATION: 0.75,
        ErrorType.TOKEN_EXPIRY: 0.70,
        ErrorType.MEMORY_LEAK: 0.50,
        ErrorType.TOOL_HALLUCINATION: 0.70,
        ErrorType.GUARDRAIL_BYPASS: 0.85,
        ErrorType.INFINITE_LOOP: 0.90,
        ErrorType.CASCADE_FAILURE: 0.80,
        ErrorType.SUPPLY_CHAIN_ATTACK: 0.60,
        ErrorType.MODEL_SUBSTITUTION: 0.65,
        ErrorType.PERMISSION_ESCALATION: 0.85,
        ErrorType.DATA_EXFILTRATION: 0.40,
        ErrorType.UNKNOWN: 0.50,
    }

    def __init__(self):
        self._events: list[AgentEvent] = []

    def add_event(self, agent_name: str = "default", provider: str = "",
                  model: str = "", latency_ms: float = 0.0,
                  token_count: int = 0, context_tokens: int = 0,
                  cost: float = 0.0, success: bool = True,
                  error_type: Optional[ErrorType] = None,
                  tool_used: str = "", step_number: int = 0,
                  metadata: dict = None) -> None:
        self._events.append(AgentEvent(
            timestamp=time.time(), agent_name=agent_name,
            provider=provider, model=model, latency_ms=latency_ms,
            token_count=token_count, context_tokens=context_tokens,
            cost=cost, success=success, error_type=error_type,
            tool_used=tool_used, step_number=step_number,
            metadata=metadata or {},
        ))

    def diagnose(self) -> DoctorReport:
        start = time.time()

        if not self._events:
            return DoctorReport(
                scan_time=datetime.now().isoformat(),
                scan_duration_seconds=time.time() - start,
                total_events_analyzed=0, total_problems=0,
                overall_problem_rate=0.0, estimated_monthly_loss=0.0,
                healable_savings=0.0, layer_diagnoses=[],
                top_pain_points=["No Agent event data. Run with --live or import logs."],
                savings_if_healed={}, risk_alerts=[], agent_score=100.0,
            )

        # Group events by problem layer
        layer_events: dict[ProblemLayer, list[AgentEvent]] = {layer: [] for layer in ProblemLayer}
        for event in self._events:
            if not event.success and event.error_type:
                layer = ERROR_LAYER_MAP.get(event.error_type, ProblemLayer.RELIABILITY)
                layer_events[layer].append(event)

        # Also put successful events in reliability layer for context
        successful = [e for e in self._events if e.success]

        # Diagnose each layer
        layer_diagnoses = []
        total_loss = 0.0
        total_healable = 0.0

        for layer in ProblemLayer:
            problems = layer_events[layer]
            total_in_layer = len(problems)

            # Calculate problem rate relative to all events
            problem_rate = len(problems) / len(self._events) * 100 if self._events else 0

            # Severity based on problem rate and layer criticality
            if layer == ProblemLayer.SECURITY:
                if len(problems) > 0:
                    severity = Severity.CRITICAL if len(problems) >= 3 else Severity.HIGH
                else:
                    severity = Severity.LOW
            elif problem_rate > 10:
                severity = Severity.CRITICAL
            elif problem_rate > 5:
                severity = Severity.HIGH
            elif problem_rate > 2:
                severity = Severity.MEDIUM
            else:
                severity = Severity.LOW

            # Findings
            findings = []
            error_breakdown = {}
            for e in problems:
                etype = e.error_type or ErrorType.UNKNOWN
                error_breakdown[etype.value] = error_breakdown.get(etype.value, 0) + 1

            for etype_val, count in sorted(error_breakdown.items(), key=lambda x: -x[1]):
                pct = round(count / len(problems) * 100) if problems else 0
                findings.append(f"{etype_val}: {count}次 ({pct}%)")

            # Layer-specific analysis
            if layer == ProblemLayer.CONTEXT_BLOAT and problems:
                context_sizes = [e.context_tokens for e in problems if e.context_tokens > 0]
                if context_sizes:
                    avg_ctx = statistics.mean(context_sizes)
                    max_ctx = max(context_sizes)
                    findings.append(f"上下文平均: {avg_ctx:.0f} tokens, 峰值: {max_ctx} tokens")

            if layer == ProblemLayer.CASCADE and problems:
                steps = [e.step_number for e in problems if e.step_number > 0]
                if steps:
                    findings.append(f"级联发生在步骤: {min(steps)}-{max(steps)}")

            # Recommendations
            recs = self._get_recommendations(layer, error_breakdown, problem_rate)

            # Healable rate
            healable = 0.0
            for e in problems:
                etype = e.error_type or ErrorType.UNKNOWN
                healable += self.HEALABLE_RATES.get(etype, 0.5)
            healable_rate = (healable / len(problems) * 100) if problems else 0

            # Monthly loss estimate
            avg_cost = 0.005
            success_costs = [e.cost for e in successful if e.cost > 0]
            if success_costs:
                avg_cost = statistics.mean(success_costs)
            monthly_loss = len(problems) * avg_cost * (30 / 7) * 3  # 3x multiplier for cascade/opacity costs

            layer_diagnoses.append(LayerDiagnosis(
                layer=layer, severity=severity,
                total_events=len(self._events),
                problem_events=len(problems),
                problem_rate=round(problem_rate, 2),
                findings=findings, recommendations=recs,
                healable_rate=round(healable_rate, 1),
                estimated_monthly_loss=round(monthly_loss, 2),
            ))
            total_loss += monthly_loss
            total_healable += monthly_loss * (healable_rate / 100)

        # Agent health score (0-100)
        problem_ratio = len([e for e in self._events if not e.success]) / len(self._events)
        agent_score = round(max(0, 100 * (1 - problem_ratio * 5)), 1)  # 5x penalty

        # Top pain points
        pain_points = []
        for ld in sorted(layer_diagnoses, key=lambda x: x.problem_rate, reverse=True):
            if ld.problem_events > 0:
                top_finding = ld.findings[0] if ld.findings else "unknown"
                pain_points.append(f"{ld.layer.value}: {top_finding} (月损失${ld.estimated_monthly_loss:.2f})")

        # Risk alerts
        alerts = []
        for ld in layer_diagnoses:
            if ld.severity == Severity.CRITICAL:
                alerts.append(f"🚨 {ld.layer.value}: {ld.problem_rate}% 问题率")
            elif ld.severity == Severity.HIGH:
                alerts.append(f"⚠️ {ld.layer.value}: {ld.problem_rate}% 问题率")

        return DoctorReport(
            scan_time=datetime.now().isoformat(),
            scan_duration_seconds=round(time.time() - start, 2),
            total_events_analyzed=len(self._events),
            total_problems=len([e for e in self._events if not e.success]),
            overall_problem_rate=round(
                len([e for e in self._events if not e.success]) / len(self._events) * 100, 2
            ) if self._events else 0,
            estimated_monthly_loss=round(total_loss, 2),
            healable_savings=round(total_healable, 2),
            layer_diagnoses=layer_diagnoses,
            top_pain_points=pain_points,
            savings_if_healed={
                "current_monthly_loss": round(total_loss, 2),
                "healable_amount": round(total_healable, 2),
                "recovery_rate": round(total_healable / total_loss * 100, 1) if total_loss > 0 else 0,
            },
            risk_alerts=alerts,
            agent_score=agent_score,
        )

    def _get_recommendations(self, layer: ProblemLayer, error_breakdown: dict, rate: float) -> list:
        recs = []
        if layer == ProblemLayer.RELIABILITY:
            if "rate_limit" in error_breakdown:
                recs.append("⚡ Rate limit — 智能重试+退避可恢复95%")
            if "timeout" in error_breakdown:
                recs.append("⏱ Timeout — 自适应超时+重试可恢复90%")
            if "server_error" in error_breakdown:
                recs.append("🔥 5xx — 自动故障切换可恢复85%")
            if "model_overload" in error_breakdown:
                recs.append("🚨 模型过载 — 自动切换备用模型可恢复92%")
            if rate > 5:
                recs.append("💡 NeuralBridge SDK自愈引擎: 95.19%自动恢复率")

        elif layer == ProblemLayer.CONTEXT_BLOAT:
            if "context_overflow" in error_breakdown:
                recs.append("📦 上下文溢出 — 自动裁剪+摘要可恢复80%")
            if "silent_degradation" in error_breakdown:
                recs.append("🔇 静默退化 — 行为基线监控可检测75%")
            if "token_expiry" in error_breakdown:
                recs.append("🔑 Token过期 — 自动刷新+重试可恢复70%")
            if "memory_leak" in error_breakdown:
                recs.append("💧 内存泄漏 — 周期性重启策略可恢复50%")
            recs.append("💡 状态机约束: 限制最大迭代次数+上下文窗口监控")

        elif layer == ProblemLayer.CASCADE:
            if "tool_hallucination" in error_breakdown:
                recs.append("🤖 工具幻觉 — 状态机白名单可阻断70%")
            if "guardrail_bypass" in error_breakdown:
                recs.append("🛡️ 护栏绕过 — 状态机强制执行可恢复85%")
            if "infinite_loop" in error_breakdown:
                recs.append("🔄 无限循环 — 最大迭代限制可恢复90%")
            if "cascade_failure" in error_breakdown:
                recs.append("💥 级联故障 — 熔断器+降级策略可恢复80%")
            recs.append("💡 StateMachine: 状态转换守卫+工具白名单+迭代上限")

        elif layer == ProblemLayer.SECURITY:
            if "supply_chain_attack" in error_breakdown:
                recs.append("⚔️ 供应链攻击 — 响应指纹验证可检测60%")
            if "model_substitution" in error_breakdown:
                recs.append("🎭 模型替换 — 行为签名验证可检测65%")
            if "permission_escalation" in error_breakdown:
                recs.append("🔓 权限越界 — 状态机工具约束可阻断85%")
            if "data_exfiltration" in error_breakdown:
                recs.append("📡 数据外泄 — 输出审计+沙箱可阻断40%")
            recs.append("💡 IntegrityChecker: 三层防御(指纹+身份+篡改检测)")

        return recs


# ═══════════════════════════════════════════════════════════
#  Report Formatter
# ═══════════════════════════════════════════════════════════

class ReportFormatter:
    @staticmethod
    def terminal(report: DoctorReport) -> str:
        lines = []
        lines.append("")
        lines.append("╔══════════════════════════════════════════════════════════╗")
        lines.append("║     🏥 NeuralBridge Doctor — Agent Health Report v2     ║")
        lines.append("╚══════════════════════════════════════════════════════════╝")
        lines.append("")
        lines.append(f"  Scan Time:  {report.scan_time}")
        lines.append(f"  Events:     {report.total_events_analyzed}")
        lines.append(f"  Duration:   {report.scan_duration_seconds}s")

        # Health score
        score = report.agent_score
        score_icon = "🟢" if score >= 80 else "🟡" if score >= 60 else "🟠" if score >= 40 else "🔴"
        lines.append(f"  Health:     {score_icon} {score}/100")
        lines.append("")

        # Summary box
        if report.total_events_analyzed > 0:
            loss_icon = "🔴" if report.estimated_monthly_loss > 100 else "🟡" if report.estimated_monthly_loss > 10 else "🟢"
            lines.append("┌──────────────────────────────────────────────────────────┐")
            lines.append(f"│  Problem Rate:      {report.overall_problem_rate:>8}%                      │")
            lines.append(f"│  Total Problems:    {report.total_problems:>8}                        │")
            lines.append(f"│  {loss_icon} Monthly Loss:     ${report.estimated_monthly_loss:>8.2f}                     │")
            lines.append(f"│  💊 Healable:       ${report.healable_savings:>8.2f}                     │")
            lines.append("└──────────────────────────────────────────────────────────┘")
        lines.append("")

        # Risk alerts
        if report.risk_alerts:
            lines.append("⚠️  RISK ALERTS:")
            for a in report.risk_alerts:
                lines.append(f"   {a}")
            lines.append("")

        # Layer-by-layer diagnosis
        lines.append("🔍 FOUR-LAYER AGENT DIAGNOSIS:")
        lines.append("═" * 58)
        for ld in report.layer_diagnoses:
            si = {"critical": "🔴", "high": "🟠", "medium": "🟡", "low": "🟢"}[ld.severity.value]
            lines.append("")
            lines.append(f"  {si} {ld.layer.value}")
            lines.append(f"     严重程度: {ld.severity.value.upper()}")
            lines.append(f"     问题次数: {ld.problem_events} / {ld.total_events} ({ld.problem_rate}%)")
            if ld.findings:
                for f in ld.findings[:5]:
                    lines.append(f"     • {f}")
            if ld.recommendations:
                for r in ld.recommendations[:3]:
                    lines.append(f"     → {r}")
            lines.append(f"     可恢复: {ld.healable_rate}% | 月损失: ${ld.estimated_monthly_loss:.2f}")

        lines.append("")
        lines.append("═" * 58)

        # Top pain points
        if report.top_pain_points:
            lines.append("")
            lines.append("🔥 TOP PAIN POINTS:")
            for i, pp in enumerate(report.top_pain_points, 1):
                lines.append(f"   {i}. {pp}")

        # Savings
        if report.savings_if_healed and report.savings_if_healed.get("current_monthly_loss", 0) > 0:
            s = report.savings_if_healed
            lines.append("")
            lines.append("💊 NEURALBRIDGE CAN SAVE YOU:")
            lines.append("─" * 58)
            lines.append(f"   Monthly Loss:     ${s['current_monthly_loss']:.2f}")
            lines.append(f"   Auto-Recoverable: ${s['healable_amount']:.2f} ({s['recovery_rate']}%)")
            lines.append(f"   Net Savings:      ${s['healable_amount']:.2f}/month")
            lines.append("")
            lines.append("   pip install neuralbridge-sdk")
            lines.append("   >>> import neuralbridge as nb")
            lines.append("   >>> nb.run_doctor()  # ← 你刚跑的就是这个")
            lines.append("   >>> nb.NeuralBridge().wrap(your_api_call)  # ← 自动修复")

        lines.append("")
        lines.append("──────────────────────────────────────────────────────────")
        lines.append("  🩺 nb doctor — Agent运行时诊断（免费）")
        lines.append("  💊 NeuralBridge SDK — Agent运行时保障（自愈）")
        lines.append("  诊断→策略→执行，一气呵成")
        lines.append("──────────────────────────────────────────────────────────")
        return "\n".join(lines)

    @staticmethod
    def markdown(report: DoctorReport) -> str:
        lines = []
        score = report.agent_score
        lines.append("## 🏥 NeuralBridge Doctor — Agent Health Report")
        lines.append("")
        lines.append(f"**Health Score:** {score}/100 | **Events:** {report.total_events_analyzed} | **Scan:** {report.scan_time}")
        lines.append("")

        if report.total_events_analyzed > 0:
            lines.append("### Summary")
            lines.append("")
            lines.append("| Metric | Value |")
            lines.append("|--------|-------|")
            lines.append(f"| Problem Rate | {report.overall_problem_rate}% |")
            lines.append(f"| Total Problems | {report.total_problems} |")
            lines.append(f"| Monthly Loss | ${report.estimated_monthly_loss:.2f} |")
            lines.append(f"| Healable | ${report.healable_savings:.2f} |")
            lines.append("")

        lines.append("### Four-Layer Diagnosis")
        lines.append("")
        for ld in report.layer_diagnoses:
            lines.append(f"#### {ld.layer.value}")
            lines.append(f"Severity: **{ld.severity.value.upper()}** | Rate: {ld.problem_rate}% | Loss: ${ld.estimated_monthly_loss:.2f}")
            if ld.findings:
                for f in ld.findings:
                    lines.append(f"- {f}")
            if ld.recommendations:
                lines.append("")
                for r in ld.recommendations:
                    lines.append(f"- {r}")
            lines.append("")

        lines.append("---")
        lines.append("*Generated by [NeuralBridge Doctor](https://neuralbridge.cn)* — `pip install neuralbridge-sdk`")
        return "\n".join(lines)

    @staticmethod
    def json_report(report: DoctorReport) -> str:
        def _ser(obj):
            if isinstance(obj, (ErrorType, Severity, ProblemLayer)):
                return obj.value
            if hasattr(obj, '__dataclass_fields__'):
                return {k: _ser(v) for k, v in obj.__dict__.items()}
            if isinstance(obj, list):
                return [_ser(i) for i in obj]
            if isinstance(obj, dict):
                return {k: _ser(v) for k, v in obj.items()}
            return obj
        return json.dumps(_ser(report), indent=2, ensure_ascii=False)


# ═══════════════════════════════════════════════════════════
#  Demo Data — Realistic Agent Workload
# ═══════════════════════════════════════════════════════════

def load_demo_data(scanner: AgentHealthScanner) -> AgentHealthScanner:
    """
    Load realistic demo data simulating a typical Agent production workload.
    Includes all 4 problem layers with realistic ratios.
    """

    # ── Layer 1: Reliability Collapse (4.7% failure) ──
    # OpenAI GPT-4
    for i in range(962):
        scanner.add_event(
            agent_name="coding-agent", provider="openai", model="gpt-4",
            latency_ms=1200 + (i % 7) * 200,
            token_count=800 + (i % 5) * 200,
            context_tokens=2000 + (i % 3) * 1000,
            cost=0.024, success=True, step_number=i % 8 + 1,
        )
    for _ in range(28):
        scanner.add_event(
            agent_name="coding-agent", provider="openai", model="gpt-4",
            latency_ms=5000 + (_ % 3) * 3000,
            success=False, error_type=ErrorType.RATE_LIMIT,
            step_number=3,
        )
    for _ in range(12):
        scanner.add_event(
            agent_name="coding-agent", provider="openai", model="gpt-4",
            latency_ms=30000 + (_ % 2) * 15000,
            success=False, error_type=ErrorType.TIMEOUT,
            step_number=5,
        )
    for _ in range(3):
        scanner.add_event(
            agent_name="coding-agent", provider="openai", model="gpt-4",
            latency_ms=800, success=False, error_type=ErrorType.SERVER_ERROR,
        )

    # DeepSeek — higher failure rate
    for i in range(380):
        scanner.add_event(
            agent_name="research-agent", provider="deepseek", model="deepseek-chat",
            latency_ms=600 + (i % 4) * 150,
            token_count=500 + (i % 3) * 100, cost=0.003,
            success=True, step_number=i % 6 + 1,
        )
    for _ in range(22):
        scanner.add_event(
            agent_name="research-agent", provider="deepseek", model="deepseek-chat",
            latency_ms=2000, success=False, error_type=ErrorType.RATE_LIMIT,
        )
    for _ in range(10):
        scanner.add_event(
            agent_name="research-agent", provider="deepseek", model="deepseek-chat",
            latency_ms=15000, success=False, error_type=ErrorType.SERVER_ERROR,
        )

    # ── Layer 2: Context Bloat & Silent Failure ──
    # Simulating the RapidClaw experiment pattern
    for _ in range(4):
        scanner.add_event(
            agent_name="email-agent", provider="openai", model="gpt-4",
            latency_ms=2500, context_tokens=120000,
            success=False, error_type=ErrorType.CONTEXT_OVERFLOW,
            step_number=15,
        )
    for _ in range(6):
        scanner.add_event(
            agent_name="email-agent", provider="openai", model="gpt-4",
            latency_ms=900, context_tokens=95000,
            success=False, error_type=ErrorType.SILENT_DEGRADATION,
            step_number=8, metadata={"note": "Day4: 开始误分类垃圾邮件"},
        )
    for _ in range(2):
        scanner.add_event(
            agent_name="crawler-agent", provider="anthropic", model="claude-3-sonnet",
            latency_ms=0, success=False, error_type=ErrorType.TOKEN_EXPIRY,
            step_number=3, metadata={"note": "Day11: token过期静默停止"},
        )
    for _ in range(1):
        scanner.add_event(
            agent_name="monitor-agent", provider="deepseek", model="deepseek-chat",
            latency_ms=0, success=False, error_type=ErrorType.MEMORY_LEAK,
            metadata={"note": "Day23: 内存泄漏杀死Agent"},
        )

    # ── Layer 3: Cascade Collapse ──
    # E-commerce Agent cascade pattern
    for _ in range(3):
        scanner.add_event(
            agent_name="ecommerce-agent", provider="openai", model="gpt-4",
            latency_ms=5000, success=False, error_type=ErrorType.TOOL_HALLUCINATION,
            tool_used="fake_address_api", step_number=6,
            metadata={"note": "API延迟→重试风暴→工具幻觉(捏造收货地址)"},
        )
    for _ in range(2):
        scanner.add_event(
            agent_name="ecommerce-agent", provider="openai", model="gpt-4",
            latency_ms=1200, success=False, error_type=ErrorType.GUARDRAIL_BYPASS,
            step_number=7, metadata={"note": "上下文爆炸→安全护栏被遗忘"},
        )
    for _ in range(1):
        scanner.add_event(
            agent_name="ecommerce-agent", provider="openai", model="gpt-4",
            latency_ms=30000, success=False, error_type=ErrorType.INFINITE_LOOP,
            step_number=99, metadata={"note": "死循环，重试99次"},
        )
    for _ in range(2):
        scanner.add_event(
            agent_name="multi-agent", provider="openai", model="gpt-4",
            latency_ms=8000, success=False, error_type=ErrorType.CASCADE_FAILURE,
            step_number=4, metadata={"note": "Agent A失败→拖垮Agent B→整条链路崩溃"},
        )

    # ── Layer 4: Security & Compliance ──
    for _ in range(2):
        scanner.add_event(
            agent_name="proxy-agent", provider="openai", model="gpt-4",
            latency_ms=600, success=False, error_type=ErrorType.MODEL_SUBSTITUTION,
            metadata={"note": "CISPA: 45.83%端点偷换模型 GPT-4→GLM-4"},
        )
    for _ in range(1):
        scanner.add_event(
            agent_name="proxy-agent", provider="openai", model="gpt-4",
            latency_ms=500, success=False, error_type=ErrorType.SUPPLY_CHAIN_ATTACK,
            metadata={"note": "LiteLLM CVE-2024-6587 SSRF攻击"},
        )
    for _ in range(1):
        scanner.add_event(
            agent_name="ops-agent", provider="openai", model="gpt-4",
            latency_ms=400, success=False, error_type=ErrorType.PERMISSION_ESCALATION,
            tool_used="rm -rf /", step_number=2,
            metadata={"note": "PocketOS Agent 9秒删除生产数据库"},
        )

    return scanner


# ═══════════════════════════════════════════════════════════
#  CLI Entry Point
# ═══════════════════════════════════════════════════════════

def run_doctor(data_source: str = "demo", format: str = "terminal") -> str:
    """
    Run the NeuralBridge Doctor v2 diagnostic.

    Args:
        data_source: 'demo' for simulated data, 'live' for real API probes
        format: 'terminal', 'json', or 'markdown'
    """
    scanner = AgentHealthScanner()
    if data_source == "demo":
        scanner = load_demo_data(scanner)
    report = scanner.diagnose()

    if format == "json":
        return ReportFormatter.json_report(report)
    elif format == "markdown":
        return ReportFormatter.markdown(report)
    else:
        return ReportFormatter.terminal(report)


def main():
    """CLI entry point for nb-doctor command."""
    import argparse
    parser = argparse.ArgumentParser(
        prog="nb-doctor",
        description="🩺 NeuralBridge Doctor — Agent Health Diagnostic Tool",
    )
    parser.add_argument("--source", default="demo", choices=["demo", "live"],
                        help="Data source: 'demo' for simulated data, 'live' for real API probes")
    parser.add_argument("--format", default="terminal", choices=["terminal", "json", "markdown"],
                        help="Output format")
    args = parser.parse_args()
    print(run_doctor(data_source=args.source, format=args.format))


if __name__ == "__main__":
    main()
