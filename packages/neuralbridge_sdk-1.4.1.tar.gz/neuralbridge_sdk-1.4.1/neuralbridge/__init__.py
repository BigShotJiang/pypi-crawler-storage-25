"""
NeuralBridge SDK — Agent Intelligence Operations · Self-Healing
v1.4.0

Agent的运行时保障层。诊断→策略→执行，一气呵成。

双飞轮架构:
🩺 诊断飞轮(nb doctor)做广 — 覆盖智能体四大问题
💊 自愈飞轮(SDK)做深 — API自愈→上下文自愈→级联断路器→安全护栏

pip install neuralbridge-sdk
"""

__version__ = "1.4.1"
__author__ = "NeuralBridge Lab"

# Core self-healing engine
from neuralbridge.healer import NeuralBridge, HealingStrategy, HealingResult

# State machine constraints (v1.3.0) — Level 3: Cascade Prevention
from neuralbridge.statemachine import (
    StateMachine,
    State,
    Transition,
    StateType,
    bugfix_workflow,
    feature_workflow,
    research_workflow,
    trading_workflow,
)

# Supply chain security (v1.3.0) — Level 4: Security & Compliance
from neuralbridge.integrity import (
    IntegrityChecker,
    IntegrityLevel,
    IntegrityReport,
    ResponseFingerprint,
    ModelIdentityCheck,
    TamperDetector,
)

# Agent health diagnostic (v1.3.0) — Diagnostic Flywheel
from neuralbridge.doctor import (
    AgentHealthScanner,
    DoctorReport,
    ReportFormatter,
    ErrorType,
    Severity,
    ProblemLayer,
    AgentEvent,
    LayerDiagnosis,
    run_doctor,
    load_demo_data,
)

# Static code scanner (v1.4.0) — Zero-barrier CLI
from neuralbridge.scanner.engine import (
    AgentScanner as StaticScanner,
    Finding,
    Dimension,
    scan_directory,
    scan_file,
    compute_scores,
    overall_score,
    grade_label,
    ascii_radar,
    report_terminal,
    report_json,
    report_html,
)

__all__ = [
    # Core Self-Healing
    "NeuralBridge", "HealingStrategy", "HealingResult",
    # State Machine — Cascade Prevention
    "StateMachine", "State", "Transition", "StateType",
    "bugfix_workflow", "feature_workflow", "research_workflow", "trading_workflow",
    # Supply Chain Security
    "IntegrityChecker", "IntegrityLevel", "IntegrityReport",
    "ResponseFingerprint", "ModelIdentityCheck", "TamperDetector",
    # Agent Health Diagnostic
    "AgentHealthScanner", "DoctorReport", "ReportFormatter",
    "ErrorType", "Severity", "ProblemLayer",
    "AgentEvent", "LayerDiagnosis", "run_doctor", "load_demo_data",
    # Static Scanner (v1.4.0)
    "StaticScanner", "Finding", "Dimension",
    "scan_directory", "scan_file",
    "compute_scores", "overall_score", "grade_label", "ascii_radar",
    "report_terminal", "report_json", "report_html",
]
