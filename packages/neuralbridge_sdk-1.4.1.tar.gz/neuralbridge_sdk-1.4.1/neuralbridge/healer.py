"""
NeuralBridge Healer — API Self-Healing Engine
v1.3.0

Core self-healing decision engine for AI API calls.
Drop-in resilience layer: auto-retry, auto-fallback, auto-recover.

Usage:
    from neuralbridge import NeuralBridge, heal, register

    register("gpt-4", strategy="fallback", alternatives=["gpt-3.5-turbo"])
    response = heal(lambda: openai.chat.completions.create(
        model="gpt-4", messages=[...]
    ))
"""

import time
import random
from enum import Enum
from typing import Any, Callable, Optional
from dataclasses import dataclass, field


class HealingStrategy(Enum):
    """Available healing strategies for API failures."""
    RETRY = "retry"                 # Simple retry with backoff
    FALLBACK = "fallback"           # Switch to alternative model/provider
    CIRCUIT_BREAK = "circuit_break" # Stop calling failing endpoint
    DEGRADE = "degrade"             # Reduce request complexity
    CACHE = "cache"                 # Return cached response


@dataclass
class HealingResult:
    """Result of a healing attempt."""
    success: bool
    original_error: Optional[Exception] = None
    healing_strategy: Optional[HealingStrategy] = None
    attempts: int = 0
    total_latency_ms: float = 0.0
    final_provider: str = ""
    final_model: str = ""
    cached: bool = False
    metadata: dict = field(default_factory=dict)


# ── Global Provider Registry ──────────────────────────────────────────────

_PROVIDER_REGISTRY: dict = {}
_HEALING_STATS = {
    "total_calls": 0,
    "healed_calls": 0,
    "failed_calls": 0,
    "strategies_used": {},
}


def register(
    model: str,
    strategy: str = "fallback",
    alternatives: list = None,
    max_retries: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 60.0,
    timeout: float = 30.0,
) -> None:
    """
    Register a model with healing configuration.

    Args:
        model: Primary model name (e.g., "gpt-4")
        strategy: Healing strategy ("fallback", "retry", "circuit_break")
        alternatives: List of fallback models
        max_retries: Maximum retry attempts
        base_delay: Base delay for exponential backoff (seconds)
        max_delay: Maximum delay cap (seconds)
        timeout: Request timeout (seconds)
    """
    _PROVIDER_REGISTRY[model] = {
        "strategy": HealingStrategy(strategy),
        "alternatives": alternatives or [],
        "max_retries": max_retries,
        "base_delay": base_delay,
        "max_delay": max_delay,
        "timeout": timeout,
        "circuit_open": False,
        "circuit_open_until": 0,
        "failure_count": 0,
        "success_count": 0,
    }


def heal(
    api_call: Callable,
    model: str = None,
    strategy: str = None,
    alternatives: list = None,
    max_retries: int = 3,
) -> HealingResult:
    """
    Wrap an API call with self-healing capabilities.

    Args:
        api_call: Callable that makes the API request
        model: Override model name (uses registry if not provided)
        strategy: Override healing strategy
        alternatives: Override fallback models
        max_retries: Override max retries

    Returns:
        HealingResult with success status and healing details
    """
    start_time = time.time()
    _HEALING_STATS["total_calls"] += 1

    # Get config from registry or use defaults
    config = _PROVIDER_REGISTRY.get(model or "", {
        "strategy": HealingStrategy(strategy or "fallback"),
        "alternatives": alternatives or [],
        "max_retries": max_retries,
        "base_delay": 1.0,
        "max_delay": 60.0,
        "timeout": 30.0,
        "circuit_open": False,
        "circuit_open_until": 0,
        "failure_count": 0,
        "success_count": 0,
    })

    heal_strategy = config["strategy"]
    models_to_try = [model] + config.get("alternatives", []) if model else [None]

    last_error = None
    attempts = 0

    # Try each model in the fallback chain
    for current_model in models_to_try:
        # Check circuit breaker
        if current_model and current_model in _PROVIDER_REGISTRY:
            reg = _PROVIDER_REGISTRY[current_model]
            if reg.get("circuit_open") and time.time() < reg.get("circuit_open_until", 0):
                continue  # Skip this model, circuit is open
            if reg.get("circuit_open"):
                reg["circuit_open"] = False  # Reset circuit

        for attempt in range(config["max_retries"]):
            attempts += 1
            try:
                result = api_call()
                elapsed_ms = (time.time() - start_time) * 1000

                # Track success
                if current_model and current_model in _PROVIDER_REGISTRY:
                    _PROVIDER_REGISTRY[current_model]["success_count"] += 1
                    _PROVIDER_REGISTRY[current_model]["failure_count"] = max(
                        0, _PROVIDER_REGISTRY[current_model]["failure_count"] - 1
                    )

                _HEALING_STATS["healed_calls"] += 1
                strat = heal_strategy.value if attempts > 1 else "direct"
                _HEALING_STATS["strategies_used"][strat] = \
                    _HEALING_STATS["strategies_used"].get(strat, 0) + 1

                return HealingResult(
                    success=True,
                    healing_strategy=heal_strategy if attempts > 1 else None,
                    attempts=attempts,
                    total_latency_ms=round(elapsed_ms, 2),
                    final_model=current_model or "unknown",
                )

            except Exception as e:
                last_error = e
                # Track failure
                if current_model and current_model in _PROVIDER_REGISTRY:
                    _PROVIDER_REGISTRY[current_model]["failure_count"] += 1
                    # Open circuit after 5 consecutive failures
                    if _PROVIDER_REGISTRY[current_model]["failure_count"] >= 5:
                        _PROVIDER_REGISTRY[current_model]["circuit_open"] = True
                        _PROVIDER_REGISTRY[current_model]["circuit_open_until"] = \
                            time.time() + 30  # 30s circuit open

                # Exponential backoff with jitter
                if attempt < config["max_retries"] - 1:
                    delay = min(
                        config["base_delay"] * (2 ** attempt) + random.uniform(0, 1),
                        config["max_delay"],
                    )
                    time.sleep(delay)

    # All attempts failed
    elapsed_ms = (time.time() - start_time) * 1000
    _HEALING_STATS["failed_calls"] += 1

    return HealingResult(
        success=False,
        original_error=last_error,
        healing_strategy=heal_strategy,
        attempts=attempts,
        total_latency_ms=round(elapsed_ms, 2),
        final_model="none",
    )


# ── NeuralBridge Main Class ──────────────────────────────────────────────

class NeuralBridge:
    """
    Main entry point for NeuralBridge self-healing.

    Usage:
        nb = NeuralBridge(api_key="sk-...")
        nb.register("gpt-4", strategy="fallback", alternatives=["gpt-3.5-turbo"])
        result = nb.heal(lambda: openai.chat.completions.create(...))
    """

    def __init__(
        self,
        api_key: str = None,
        default_strategy: str = "fallback",
        max_retries: int = 3,
        base_delay: float = 1.0,
    ):
        self.api_key = api_key
        self.default_strategy = default_strategy
        self.max_retries = max_retries
        self.base_delay = base_delay
        self._registry: dict = {}
        self._stats = {
            "total_calls": 0,
            "healed_calls": 0,
            "failed_calls": 0,
        }

    def register(self, model: str, **kwargs) -> "NeuralBridge":
        """Register a model with healing config."""
        register(model, **kwargs)
        self._registry[model] = kwargs
        return self

    def heal(self, api_call: Callable, model: str = None, **kwargs) -> Any:
        """Heal an API call. Returns the API result directly (not HealingResult)."""
        self._stats["total_calls"] += 1
        result = heal(api_call, model=model, **kwargs)
        if result.success:
            self._stats["healed_calls"] += 1
        else:
            self._stats["failed_calls"] += 1
            if result.original_error:
                raise result.original_error
        return result

    def wrap(self, api_call: Callable, model: str = None) -> Callable:
        """Wrap an API call function with self-healing."""
        def wrapped(*args, **kwargs):
            return self.heal(lambda: api_call(*args, **kwargs), model=model)
        return wrapped

    @property
    def stats(self) -> dict:
        """Get healing statistics."""
        return {
            **self._stats,
            "heal_rate": (
                self._stats["healed_calls"] / self._stats["total_calls"] * 100
                if self._stats["total_calls"] > 0 else 0
            ),
            "providers": len(self._registry),
        }

    def __repr__(self):
        return (
            f"NeuralBridge(providers={len(self._registry)}, "
            f"heal_rate={self.stats['heal_rate']:.1f}%)"
        )


def get_stats() -> dict:
    """Get global healing statistics."""
    total = _HEALING_STATS["total_calls"]
    return {
        **_HEALING_STATS,
        "heal_rate": (
            _HEALING_STATS["healed_calls"] / total * 100 if total > 0 else 0
        ),
    }
