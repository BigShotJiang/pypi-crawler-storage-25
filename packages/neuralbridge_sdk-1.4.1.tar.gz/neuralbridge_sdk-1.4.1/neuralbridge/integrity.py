"""
NeuralBridge Integrity — API Supply Chain Security & Model Verification
v1.0.0

Solves Pain Point #5: API supply chain security / model substitution.
- CISPA research: 45.83% of API proxy endpoints silently substitute models
- 72% enterprises care about security but only 19% actually protect

Three-layer defense:
1. ResponseFingerprint — fingerprint API responses to detect anomalies
2. ModelIdentityCheck — verify model identity via behavior signatures
3. TamperDetector — detect response tampering via consistency analysis
"""

import hashlib
import math
import time
import statistics
from typing import Optional
from dataclasses import dataclass, field
from enum import Enum


class IntegrityLevel(Enum):
    VERIFIED = "verified"
    SUSPICIOUS = "suspicious"
    TAMPERED = "tampered"
    UNKNOWN = "unknown"


@dataclass
class Fingerprint:
    response_hash: str
    model_claim: str
    timestamp: float
    token_count: int
    latency_ms: float
    metadata: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "response_hash": self.response_hash,
            "model_claim": self.model_claim,
            "timestamp": self.timestamp,
            "token_count": self.token_count,
            "latency_ms": self.latency_ms,
            "metadata": self.metadata,
        }


@dataclass
class IntegrityReport:
    level: IntegrityLevel
    fingerprint: Fingerprint
    checks_passed: list
    checks_failed: list
    confidence: float
    details: dict = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)

    @property
    def is_safe(self) -> bool:
        return self.level in (IntegrityLevel.VERIFIED, IntegrityLevel.UNKNOWN)

    def to_dict(self) -> dict:
        return {
            "level": self.level.value,
            "fingerprint": self.fingerprint.to_dict(),
            "checks_passed": self.checks_passed,
            "checks_failed": self.checks_failed,
            "confidence": round(self.confidence, 4),
            "details": self.details,
            "timestamp": self.timestamp,
        }


class ResponseFingerprint:
    """Fingerprint API responses to detect anomalies and model substitution."""

    def __init__(self, model_name: str = "default", window_size: int = 100):
        self.model_name = model_name
        self.window_size = window_size
        self._fingerprints: list[Fingerprint] = []
        self._baseline: Optional[dict] = None

    def _hash_response(self, content: str) -> str:
        return hashlib.sha256(content.encode("utf-8")).hexdigest()[:16]

    def capture(self, response_content: str, model_claim: str,
                token_count: int = 0, latency_ms: float = 0.0,
                metadata: dict = None) -> Fingerprint:
        fp = Fingerprint(
            response_hash=self._hash_response(response_content),
            model_claim=model_claim, timestamp=time.time(),
            token_count=token_count, latency_ms=latency_ms,
            metadata=metadata or {},
        )
        self._fingerprints.append(fp)
        if len(self._fingerprints) > self.window_size:
            self._fingerprints = self._fingerprints[-self.window_size:]
        self._update_baseline()
        return fp

    def _update_baseline(self):
        if len(self._fingerprints) < 5:
            self._baseline = None
            return
        tokens = [fp.token_count for fp in self._fingerprints if fp.token_count > 0]
        latencies = [fp.latency_ms for fp in self._fingerprints if fp.latency_ms > 0]
        self._baseline = {}
        if tokens:
            self._baseline["token_mean"] = statistics.mean(tokens)
            self._baseline["token_stdev"] = statistics.stdev(tokens) if len(tokens) > 1 else 0
        if latencies:
            self._baseline["latency_mean"] = statistics.mean(latencies)
            self._baseline["latency_stdev"] = statistics.stdev(latencies) if len(latencies) > 1 else 0

    def check_deviation(self, fp: Fingerprint, sigma_threshold: float = 2.5) -> dict:
        if not self._baseline:
            return {"deviation": False, "reason": "No baseline yet"}
        anomalies = []
        if "token_mean" in self._baseline and fp.token_count > 0:
            mean, stdev = self._baseline["token_mean"], self._baseline["token_stdev"]
            if stdev > 0:
                z = abs(fp.token_count - mean) / stdev
                if z > sigma_threshold:
                    anomalies.append(f"token_count z={z:.2f}")
        if "latency_mean" in self._baseline and fp.latency_ms > 0:
            mean, stdev = self._baseline["latency_mean"], self._baseline["latency_stdev"]
            if stdev > 0:
                z = abs(fp.latency_ms - mean) / stdev
                if z > sigma_threshold:
                    anomalies.append(f"latency z={z:.2f}")
        return {"deviation": len(anomalies) > 0, "anomalies": anomalies, "baseline_samples": len(self._fingerprints)}


class ModelIdentityCheck:
    """Verify model identity through behavioral signatures."""

    MODEL_SIGNATURES = {
        "gpt-4": {"avg_tokens_per_char": 0.25, "code_block_ratio": 0.3, "refusal_keywords": ["I'm sorry", "I can't", "As an AI"], "typical_latency_ms": (800, 3000)},
        "gpt-4o": {"avg_tokens_per_char": 0.25, "code_block_ratio": 0.25, "refusal_keywords": ["I'm sorry", "I can't", "As an AI"], "typical_latency_ms": (300, 1500)},
        "gpt-3.5-turbo": {"avg_tokens_per_char": 0.22, "code_block_ratio": 0.2, "refusal_keywords": ["I'm sorry", "I can't"], "typical_latency_ms": (200, 1200)},
        "claude-3-opus": {"avg_tokens_per_char": 0.28, "code_block_ratio": 0.35, "refusal_keywords": ["I apologize", "I'm not able", "I must note"], "typical_latency_ms": (1500, 6000)},
        "claude-3-sonnet": {"avg_tokens_per_char": 0.26, "code_block_ratio": 0.3, "refusal_keywords": ["I apologize", "I'm not able"], "typical_latency_ms": (500, 3000)},
        "deepseek-chat": {"avg_tokens_per_char": 0.23, "code_block_ratio": 0.28, "refusal_keywords": ["抱歉", "我无法", "I'm sorry"], "typical_latency_ms": (300, 2000)},
    }

    def verify(self, model_claim: str, response_content: str,
               token_count: int = 0, latency_ms: float = 0.0) -> dict:
        signature = self.MODEL_SIGNATURES.get(model_claim)
        if not signature:
            return {"verified": True, "confidence": 0.0, "reason": f"No signature for '{model_claim}'", "checks": {}}

        checks, anomalies = {}, []
        content_lower = response_content.lower()

        # Refusal pattern
        has_refusal = any(kw.lower() in content_lower for kw in signature["refusal_keywords"])
        is_likely_refusal = any(w in content_lower for w in ["sorry", "apologize", "can't", "unable", "抱歉", "无法"])
        if is_likely_refusal and not has_refusal:
            anomalies.append("refusal_style_mismatch")
            checks["refusal_pattern"] = "mismatch"
        else:
            checks["refusal_pattern"] = "consistent"

        # Code block ratio
        code_ratio = response_content.count("```") / max(len(response_content) / 500, 1)
        expected = signature["code_block_ratio"]
        if abs(code_ratio - expected) > expected * 2:
            anomalies.append("code_ratio_anomaly")
            checks["code_ratio"] = f"anomaly ({code_ratio:.2f} vs ~{expected:.2f})"
        else:
            checks["code_ratio"] = "consistent"

        # Latency range
        if latency_ms > 0:
            min_lat, max_lat = signature["typical_latency_ms"]
            if latency_ms < min_lat * 0.3 or latency_ms > max_lat * 3:
                anomalies.append("latency_out_of_range")
                checks["latency"] = f"anomaly ({latency_ms:.0f}ms vs {min_lat}-{max_lat}ms)"
            else:
                checks["latency"] = "in_range"

        # Token/char ratio
        if token_count > 0 and len(response_content) > 0:
            actual = token_count / len(response_content)
            expected_tpc = signature["avg_tokens_per_char"]
            if abs(actual - expected_tpc) > expected_tpc * 0.5:
                anomalies.append("token_ratio_anomaly")
                checks["token_ratio"] = f"anomaly ({actual:.3f} vs ~{expected_tpc:.3f})"
            else:
                checks["token_ratio"] = "consistent"

        confidence = max(0, 1.0 - len(anomalies) * 0.3)
        return {"verified": len(anomalies) == 0, "confidence": round(confidence, 4), "anomalies": anomalies, "checks": checks}


class TamperDetector:
    """Detect response tampering through consistency analysis."""

    def __init__(self):
        self._response_pairs: list[dict] = []

    def compute_entropy(self, text: str) -> float:
        if not text:
            return 0.0
        freq = {}
        for char in text:
            freq[char] = freq.get(char, 0) + 1
        length = len(text)
        return round(-sum((c / length) * math.log2(c / length) for c in freq.values()), 4)

    def compare_responses(self, response_a: str, response_b: str, prompt: str = "") -> dict:
        entropy_a, entropy_b = self.compute_entropy(response_a), self.compute_entropy(response_b)
        len_a, len_b = len(response_a), len(response_b)
        length_ratio = min(len_a, len_b) / max(len_a, len_b) if max(len_a, len_b) > 0 else 0
        entropy_diff = abs(entropy_a - entropy_b)
        exact_match = hashlib.sha256(response_a.encode()).hexdigest()[:16] == hashlib.sha256(response_b.encode()).hexdigest()[:16]
        pa, pb = set(response_a[:200].split()), set(response_b[:200].split())
        jaccard = len(pa & pb) / len(pa | pb) if (pa or pb) else 0.0

        indicators = []
        if entropy_diff > 1.5: indicators.append("entropy_divergence")
        if length_ratio < 0.3: indicators.append("length_divergence")
        if jaccard < 0.1 and not exact_match: indicators.append("structural_divergence")

        result = {"exact_match": exact_match, "entropy_a": entropy_a, "entropy_b": entropy_b,
                  "entropy_diff": round(entropy_diff, 4), "length_ratio": round(length_ratio, 4),
                  "jaccard_similarity": round(jaccard, 4), "tamper_indicators": indicators,
                  "likely_tampered": len(indicators) >= 2}
        self._response_pairs.append({"prompt": prompt, "result": result, "timestamp": time.time()})
        return result


class IntegrityChecker:
    """
    Unified integrity checker — three layers in one call.

    Usage:
        checker = IntegrityChecker()
        report = checker.check(response="...", model_claim="gpt-4", token_count=150, latency_ms=1200)
        if not report.is_safe:
            print(f"⚠️ {report.level.value}")
    """

    def __init__(self, model_name: str = "default"):
        self.fingerprint = ResponseFingerprint(model_name=model_name)
        self.identity = ModelIdentityCheck()
        self.tamper = TamperDetector()
        self._history: list[IntegrityReport] = []

    def check(self, response: str, model_claim: str = "",
              token_count: int = 0, latency_ms: float = 0.0,
              metadata: dict = None) -> IntegrityReport:
        checks_passed, checks_failed, details = [], [], {}

        fp = self.fingerprint.capture(response, model_claim, token_count, latency_ms, metadata)
        deviation = self.fingerprint.check_deviation(fp)
        details["fingerprint_deviation"] = deviation
        (checks_failed if deviation["deviation"] else checks_passed).append("fingerprint_deviation")

        identity_result = self.identity.verify(model_claim, response, token_count, latency_ms)
        details["model_identity"] = identity_result
        (checks_failed if not identity_result["verified"] else checks_passed).append("model_identity")

        entropy = self.tamper.compute_entropy(response)
        details["entropy"] = entropy
        (checks_failed if not (2.0 <= entropy <= 6.5) else checks_passed).append("entropy_normal" if 2.0 <= entropy <= 6.5 else "entropy_anomaly")

        total = len(checks_passed) + len(checks_failed)
        confidence = len(checks_passed) / total if total > 0 else 0.5

        if not checks_failed:
            level = IntegrityLevel.VERIFIED
        elif len(checks_failed) == 1 and "fingerprint_deviation" in checks_failed:
            level = IntegrityLevel.SUSPICIOUS
        elif "model_identity" in checks_failed and len(checks_failed) >= 2:
            level = IntegrityLevel.TAMPERED
        else:
            level = IntegrityLevel.SUSPICIOUS

        report = IntegrityReport(level=level, fingerprint=fp, checks_passed=checks_passed,
                                 checks_failed=checks_failed, confidence=confidence, details=details)
        self._history.append(report)
        return report

    def compare_endpoints(self, response_a: str, response_b: str,
                          model_claim: str = "", prompt: str = "") -> dict:
        ra, rb = self.check(response_a, model_claim), self.check(response_b, model_claim)
        comparison = self.tamper.compare_responses(response_a, response_b, prompt)
        return {
            "endpoint_a_integrity": ra.level.value,
            "endpoint_b_integrity": rb.level.value,
            "comparison": comparison,
            "recommendation": (
                "TRUSTED: Both endpoints consistent" if not comparison["likely_tampered"] and ra.is_safe and rb.is_safe
                else "WARNING: Possible tampering" if comparison["likely_tampered"]
                else "CAUTION: Minor inconsistencies"
            ),
        }

    def get_stats(self) -> dict:
        if not self._history:
            return {"total_checks": 0}
        levels = [r.level for r in self._history]
        return {
            "total_checks": len(self._history),
            "verified": levels.count(IntegrityLevel.VERIFIED),
            "suspicious": levels.count(IntegrityLevel.SUSPICIOUS),
            "tampered": levels.count(IntegrityLevel.TAMPERED),
            "unknown": levels.count(IntegrityLevel.UNKNOWN),
            "tamper_rate": round(levels.count(IntegrityLevel.TAMPERED) / len(self._history), 4),
            "avg_confidence": round(sum(r.confidence for r in self._history) / len(self._history), 4),
        }
