# NeuralBridge SDK v1.4.1

**Agent Runtime Assurance

One command, zero code, no API key:



## Commands

| Command | What it does |
|---------|-------------|
|  | Scan current directory |
|  | Deep scan with dependency analysis |
|  | Check single file |
|  | Generate HTML report |
|  | JSON output for CI/CD |

## What It Detects

| Dimension | What it detects |
|-----------|----------------|
| **Reliability** | No try/except, no timeout, hardcoded models, retry storms, single provider |
| **Context Bloat** | No max_tokens, unbounded messages |
| **Cascade Failure** | No circuit breakers, no checkpoints |
| **Security** | Hardcoded API keys, prompt injection, eval/exec, subprocess |

## Quick Start



## 95.19% Self-Heal Rate | Zero Dependencies

- [PyPI](https://pypi.org/project/neuralbridge-sdk)
- [neuralbridge.cn](https://neuralbridge.cn)

## License

Apache-2.0 with commercial restriction.
