from __future__ import annotations

from workagent.skills.models import LoadedSkillManifest, SkillSource, SkillTrustState


def ensure_can_promote_to_trusted(entry: LoadedSkillManifest) -> bool:
    if entry.manifest.trust_state is SkillTrustState.disabled:
        raise ValueError("disabled skills cannot transition directly to trusted")
    if entry.source not in {SkillSource.local_dir, SkillSource.git_repo}:
        raise ValueError("only external untrusted skills can transition to trusted")
    if entry.manifest.trust_state is SkillTrustState.builtin:
        raise ValueError("only external untrusted skills can transition to trusted")
    if entry.manifest.trust_state is SkillTrustState.trusted:
        return False
    return True
