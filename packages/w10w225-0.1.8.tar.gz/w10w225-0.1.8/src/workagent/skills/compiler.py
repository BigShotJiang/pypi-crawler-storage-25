from __future__ import annotations

import re

from workagent.skills.assets import SkillAssetBundle
from workagent.skills.models import CompiledSkillContract, SkillCandidate

_SECTION_ALIASES = {
    "rules": "instructions",
    "rule": "instructions",
    "instruction": "instructions",
    "instructions": "instructions",
    "checklist": "checklist",
    "workflow": "workflow_steps",
    "workflow steps": "workflow_steps",
    "tool policy": "tool_policy",
    "tools": "tool_policy",
    "validation": "validation_rules",
}


class SkillContractCompiler:
    def compile(
        self,
        *,
        candidate: SkillCandidate,
        asset: SkillAssetBundle,
    ) -> CompiledSkillContract:
        instructions: list[str] = []
        checklist: list[str] = []
        workflow_steps: list[str] = []
        allowed_tools: list[str] = []
        blocked_tools: list[str] = []
        preferred_tools: list[str] = []
        validation_rules: list[str] = []
        raw_asset_refs = [
            str(path.name)
            for path in (asset.entrypoint_path, asset.readme_path)
            if path is not None
        ]

        for raw_text in (asset.entrypoint_text, asset.readme_text):
            text = str(raw_text or "").strip()
            if not text:
                continue
            parsed = _parse_skill_text(text)
            instructions.extend(parsed["instructions"])
            checklist.extend(parsed["checklist"])
            workflow_steps.extend(parsed["workflow_steps"])
            allowed_tools.extend(parsed["allowed_tools"])
            blocked_tools.extend(parsed["blocked_tools"])
            preferred_tools.extend(parsed["preferred_tools"])
            validation_rules.extend(parsed["validation_rules"])

        if not instructions and not checklist and not workflow_steps and not validation_rules:
            fallback_text = "\n\n".join(
                part.strip()
                for part in (asset.entrypoint_text, asset.readme_text)
                if str(part or "").strip()
            ).strip()
            if fallback_text:
                instructions.append(fallback_text)

        return CompiledSkillContract(
            skill_id=candidate.skill_id,
            name=candidate.name,
            source=candidate.source,
            trust_state=candidate.trust_state,
            capabilities=tuple(candidate.capabilities),
            instructions=tuple(_dedupe_preserve_order(instructions)),
            checklist=tuple(_dedupe_preserve_order(checklist)),
            workflow_steps=tuple(_dedupe_preserve_order(workflow_steps)),
            allowed_tools=tuple(_dedupe_preserve_order(allowed_tools)),
            blocked_tools=tuple(_dedupe_preserve_order(blocked_tools)),
            preferred_tools=tuple(_dedupe_preserve_order(preferred_tools)),
            validation_rules=tuple(_dedupe_preserve_order(validation_rules)),
            raw_asset_refs=tuple(raw_asset_refs),
        )

    def compile_many(
        self,
        *,
        candidates: tuple[SkillCandidate, ...],
        assets: tuple[SkillAssetBundle, ...],
    ) -> tuple[CompiledSkillContract, ...]:
        compiled: list[CompiledSkillContract] = []
        for candidate in candidates:
            asset = next((item for item in assets if item.skill_id == candidate.skill_id), None)
            if asset is None:
                continue
            compiled.append(self.compile(candidate=candidate, asset=asset))
        return tuple(compiled)


def _dedupe_preserve_order(values: list[str]) -> list[str]:
    output: list[str] = []
    seen: set[str] = set()
    for value in values:
        normalized = str(value).strip()
        if not normalized or normalized in seen:
            continue
        seen.add(normalized)
        output.append(normalized)
    return output


def _parse_skill_text(text: str) -> dict[str, list[str]]:
    parsed = {
        "instructions": [],
        "checklist": [],
        "workflow_steps": [],
        "allowed_tools": [],
        "blocked_tools": [],
        "preferred_tools": [],
        "validation_rules": [],
    }
    active_section = "instructions"
    instruction_buffer: list[str] = []

    def flush_instructions() -> None:
        if not instruction_buffer:
            return
        joined = "\n".join(line for line in instruction_buffer if line).strip()
        if joined:
            parsed["instructions"].append(joined)
        instruction_buffer.clear()

    for raw_line in text.splitlines():
        stripped = raw_line.strip()
        if not stripped:
            if active_section == "instructions" and instruction_buffer:
                instruction_buffer.append("")
            continue
        section_name = _match_section_heading(stripped)
        if section_name == "__skip__":
            flush_instructions()
            continue
        if section_name is not None:
            flush_instructions()
            active_section = section_name
            continue
        item_text = _strip_list_marker(stripped)
        if active_section == "instructions":
            instruction_buffer.append(item_text)
            continue
        if active_section == "checklist":
            parsed["checklist"].append(item_text)
            continue
        if active_section == "workflow_steps":
            parsed["workflow_steps"].append(item_text)
            continue
        if active_section == "validation_rules":
            parsed["validation_rules"].append(item_text)
            continue
        if active_section == "tool_policy":
            _parse_tool_policy_line(
                item_text,
                allowed_tools=parsed["allowed_tools"],
                blocked_tools=parsed["blocked_tools"],
                preferred_tools=parsed["preferred_tools"],
                instructions=parsed["instructions"],
            )
    flush_instructions()
    return parsed


def _match_section_heading(line: str) -> str | None:
    match = re.match(r"^#{1,6}\s+(.+?)\s*$", line)
    if match is None:
        return None
    normalized = match.group(1).strip().lower().rstrip(":")
    return _SECTION_ALIASES.get(normalized, "__skip__")


def _strip_list_marker(line: str) -> str:
    match = re.match(r"^(?:[-*+]\s+|\d+\.\s+)(.+)$", line)
    if match is not None:
        return match.group(1).strip()
    return line.strip()


def _parse_tool_policy_line(
    line: str,
    *,
    allowed_tools: list[str],
    blocked_tools: list[str],
    preferred_tools: list[str],
    instructions: list[str],
) -> None:
    if ":" in line:
        prefix, raw_values = line.split(":", 1)
        values = [item.strip() for item in raw_values.split(",") if item.strip()]
        lowered_prefix = prefix.strip().lower()
        if lowered_prefix in {"allow", "allowed", "allowed_tools", "allowed tools"}:
            allowed_tools.extend(values)
            return
        if lowered_prefix in {"block", "blocked", "blocked_tools", "blocked tools", "deny", "denied"}:
            blocked_tools.extend(values)
            return
        if lowered_prefix in {"prefer", "preferred", "preferred_tools", "preferred tools"}:
            preferred_tools.extend(values)
            return
    instructions.append(line.strip())
