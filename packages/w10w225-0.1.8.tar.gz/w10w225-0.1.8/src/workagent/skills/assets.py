from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from workagent.skills.models import LoadedSkillManifest


@dataclass(frozen=True, slots=True)
class SkillAssetBundle:
    skill_id: str
    entrypoint_path: Path | None
    entrypoint_text: str | None
    readme_path: Path | None
    readme_text: str | None


class SkillAssetLoader:
    def load(self, entry: LoadedSkillManifest) -> SkillAssetBundle:
        return SkillAssetBundle(
            skill_id=entry.manifest.skill_id,
            entrypoint_path=self._resolve_path(entry, entry.manifest.entrypoint),
            entrypoint_text=self._read_optional_text(entry, entry.manifest.entrypoint),
            readme_path=self._resolve_path(entry, entry.manifest.readme),
            readme_text=self._read_optional_text(entry, entry.manifest.readme),
        )

    @staticmethod
    def _resolve_path(entry: LoadedSkillManifest, relative_path: str | None) -> Path | None:
        if not relative_path:
            return None
        return entry.skill_dir / relative_path

    def _read_optional_text(self, entry: LoadedSkillManifest, relative_path: str | None) -> str | None:
        path = self._resolve_path(entry, relative_path)
        if path is None or not path.exists():
            return None
        return path.read_text(encoding="utf-8")
