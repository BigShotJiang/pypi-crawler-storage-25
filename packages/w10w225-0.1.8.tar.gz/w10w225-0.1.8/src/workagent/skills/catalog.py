from __future__ import annotations

from typing import Protocol

from workagent.skills.cache import read_catalog_cache, write_catalog_cache
from workagent.skills.loader import SkillManifestLoader
from workagent.skills.models import (
    LoadedSkillManifest,
    SkillCandidate,
    SkillCapability,
    SkillCatalogPaths,
    SkillCatalogSnapshot,
    SkillSearchQuery,
    SkillSource,
    SkillTrustState,
)

_SOURCE_PRECEDENCE = {
    SkillSource.builtin: 0,
    SkillSource.git_repo: 1,
    SkillSource.local_dir: 2,
    SkillSource.disabled: -1,
}

_TRUST_PRECEDENCE = {
    SkillTrustState.builtin: 2,
    SkillTrustState.trusted: 1,
    SkillTrustState.untrusted: 0,
    SkillTrustState.disabled: -1,
}

_TASK_CAPABILITY_HINTS: dict[str, set[SkillCapability]] = {
    "read": {SkillCapability.prompt_template, SkillCapability.tool_binding},
    "review": {SkillCapability.review_checklist, SkillCapability.prompt_template},
    "write": {SkillCapability.workflow, SkillCapability.formatter},
    "followup": {SkillCapability.prompt_template, SkillCapability.workflow},
}


class SkillCatalogService:
    def __init__(self, paths: SkillCatalogPaths | None = None) -> None:
        self.paths = paths or SkillCatalogPaths.default()
        self.loader = SkillManifestLoader(self.paths)

    def load(self) -> SkillCatalogSnapshot:
        manifest_locations = self.loader.discover_manifest_locations()
        cached_snapshot = read_catalog_cache(self.paths.cache_file, manifest_locations)
        if cached_snapshot is not None:
            return cached_snapshot
        load_result = self.loader.load_all(manifest_locations)
        snapshot = SkillCatalogSnapshot(
            entries=self._index_entries(load_result.entries),
            issues=load_result.issues,
            loaded_from_cache=False,
        )
        write_catalog_cache(self.paths.cache_file, manifest_locations, snapshot)
        return snapshot

    def search(self, query: SkillSearchQuery) -> tuple[SkillCandidate, ...]:
        normalized_tags = tuple(_normalize_tag(tag) for tag in query.tags if _normalize_tag(tag))
        candidates: list[SkillCandidate] = []
        for entry in self.load().entries:
            candidate = self._score_entry(
                entry,
                platform=str(query.platform or "").strip().lower() or None,
                task_type=str(query.task_type or "").strip().lower() or None,
                tags=normalized_tags,
                trusted_only=query.trusted_only,
            )
            if candidate is not None:
                candidates.append(candidate)
        candidates.sort(key=lambda item: (-item.score, item.skill_id))
        return tuple(candidates[: max(1, int(query.limit))])

    def _index_entries(self, entries: tuple[LoadedSkillManifest, ...]) -> tuple[LoadedSkillManifest, ...]:
        indexed: dict[str, LoadedSkillManifest] = {}
        for entry in entries:
            if entry.is_disabled or entry.manifest.trust_state is SkillTrustState.disabled:
                continue
            skill_id = entry.manifest.skill_id
            current = indexed.get(skill_id)
            if current is None or _SOURCE_PRECEDENCE[entry.source] > _SOURCE_PRECEDENCE[current.source]:
                indexed[skill_id] = entry
        return tuple(sorted(indexed.values(), key=lambda entry: entry.manifest.skill_id))

    def _score_entry(
        self,
        entry: LoadedSkillManifest,
        *,
        platform: str | None,
        task_type: str | None,
        tags: tuple[str, ...],
        trusted_only: bool,
    ) -> SkillCandidate | None:
        manifest = entry.manifest
        if trusted_only and manifest.trust_state not in {SkillTrustState.builtin, SkillTrustState.trusted}:
            return None

        score = _TRUST_PRECEDENCE[manifest.trust_state] * 100
        reasons: list[str] = []

        normalized_platforms = {str(item).strip().lower() for item in manifest.supported_platforms if str(item).strip()}
        if platform:
            if normalized_platforms and platform not in normalized_platforms:
                return None
            platform_matched = platform in normalized_platforms
        else:
            platform_matched = False
        if platform_matched:
            score += 30
            reasons.append(f"platform:{platform}")

        task_hint_capabilities = _TASK_CAPABILITY_HINTS.get(task_type or "", set())
        normalized_manifest_tags = {_normalize_tag(tag) for tag in manifest.tags if _normalize_tag(tag)}
        task_tag_matched = False
        capability_matched = False
        if task_type:
            if task_type in normalized_manifest_tags:
                score += 40
                reasons.append(f"task:{task_type}")
                task_tag_matched = True
            capability_hits = sorted(capability.value for capability in set(manifest.capabilities) & task_hint_capabilities)
            if capability_hits:
                score += 20 * len(capability_hits)
                reasons.extend(f"capability:{capability}" for capability in capability_hits)
                capability_matched = True

        tag_hits = [tag for tag in tags if tag in normalized_manifest_tags]
        if tags and not tag_hits:
            return None
        if not tag_hits and not platform_matched and not task_tag_matched and not capability_matched:
            return None
        if tag_hits:
            score += 10 * len(tag_hits)
            reasons.extend(f"tag:{tag}" for tag in tag_hits)

        return SkillCandidate(
            skill_id=manifest.skill_id,
            name=manifest.name,
            description=manifest.description,
            source=entry.source,
            trust_state=manifest.trust_state,
            capabilities=tuple(manifest.capabilities),
            supported_platforms=tuple(manifest.supported_platforms),
            tags=tuple(manifest.tags),
            requires_approval=manifest.requires_approval,
            score=score,
            match_reasons=tuple(reasons),
        )


class SkillCatalog(Protocol):
    def load(self) -> SkillCatalogSnapshot: ...
    def search(self, query: SkillSearchQuery) -> tuple[SkillCandidate, ...]: ...


def _normalize_tag(raw_value: str) -> str:
    return str(raw_value).strip().lower().replace(" ", "_")
