from __future__ import annotations

from collections.abc import Sequence
from pathlib import Path

from pydantic import BaseModel, Field, ValidationError

from workagent.skills.models import (
    LoadedSkillManifest,
    SkillCatalogSnapshot,
    SkillLintIssue,
    SkillManifest,
    SkillManifestLocation,
    SkillSource,
)


class _CachedSkillEntry(BaseModel):
    source: SkillSource
    skill_dir: str = Field(alias="skillDir")
    manifest_path: str = Field(alias="manifestPath")
    manifest: SkillManifest

    model_config = {"populate_by_name": True}


class _CachedSkillLintIssue(BaseModel):
    code: str
    message: str
    manifest_path: str = Field(alias="manifestPath")
    field_name: str | None = Field(default=None, alias="fieldName")

    model_config = {"populate_by_name": True}


class _SkillCatalogCachePayload(BaseModel):
    schema_version: int = Field(default=1, alias="schemaVersion")
    manifest_files: list[str] = Field(default_factory=list, alias="manifestFiles")
    entries: list[_CachedSkillEntry] = Field(default_factory=list)
    issues: list[_CachedSkillLintIssue] = Field(default_factory=list)

    model_config = {"populate_by_name": True}


def read_catalog_cache(cache_file: Path, manifest_locations: Sequence[SkillManifestLocation]) -> SkillCatalogSnapshot | None:
    if not cache_file.exists():
        return None
    try:
        payload = _SkillCatalogCachePayload.model_validate_json(cache_file.read_text(encoding="utf-8"))
    except (OSError, ValidationError):
        return None
    manifest_files = [str(location.manifest_path) for location in manifest_locations]
    if payload.manifest_files != manifest_files:
        return None
    cache_mtime = cache_file.stat().st_mtime
    for location in manifest_locations:
        try:
            if location.manifest_path.stat().st_mtime > cache_mtime:
                return None
        except OSError:
            return None
    return SkillCatalogSnapshot(
        entries=tuple(_load_cached_entry(entry) for entry in payload.entries),
        issues=tuple(_load_cached_issue(issue) for issue in payload.issues),
        loaded_from_cache=True,
    )


def write_catalog_cache(
    cache_file: Path,
    manifest_locations: Sequence[SkillManifestLocation],
    snapshot: SkillCatalogSnapshot,
) -> None:
    payload = _SkillCatalogCachePayload(
        manifestFiles=[str(location.manifest_path) for location in manifest_locations],
        entries=[_dump_cached_entry(entry) for entry in snapshot.entries],
        issues=[_dump_cached_issue(issue) for issue in snapshot.issues],
    )
    cache_file.parent.mkdir(parents=True, exist_ok=True)
    cache_file.write_text(payload.model_dump_json(by_alias=True, indent=2) + "\n", encoding="utf-8")


def _dump_cached_entry(entry: LoadedSkillManifest) -> _CachedSkillEntry:
    return _CachedSkillEntry(
        source=entry.source,
        skillDir=str(entry.skill_dir),
        manifestPath=str(entry.manifest_path),
        manifest=entry.manifest,
    )


def _load_cached_entry(entry: _CachedSkillEntry) -> LoadedSkillManifest:
    return LoadedSkillManifest(
        source=entry.source,
        skill_dir=Path(entry.skill_dir),
        manifest_path=Path(entry.manifest_path),
        manifest=entry.manifest,
    )


def _dump_cached_issue(issue: SkillLintIssue) -> _CachedSkillLintIssue:
    return _CachedSkillLintIssue(
        code=issue.code,
        message=issue.message,
        manifestPath=str(issue.manifest_path),
        fieldName=issue.field_name,
    )


def _load_cached_issue(issue: _CachedSkillLintIssue) -> SkillLintIssue:
    return SkillLintIssue(
        code=issue.code,
        message=issue.message,
        manifest_path=Path(issue.manifest_path),
        field_name=issue.field_name,
    )
