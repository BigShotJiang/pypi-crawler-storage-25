from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path

from pydantic import BaseModel, Field, model_validator

from workagent.config.env import resolve_agents_skills_home, resolve_workagent_home


class SkillCapability(StrEnum):
    prompt_template = "prompt_template"
    workflow = "workflow"
    review_checklist = "review_checklist"
    formatter = "formatter"
    tool_binding = "tool_binding"


class SkillTrustState(StrEnum):
    builtin = "builtin"
    trusted = "trusted"
    disabled = "disabled"
    untrusted = "untrusted"


class SkillSource(StrEnum):
    builtin = "builtin"
    local_dir = "local_dir"
    git_repo = "git_repo"
    disabled = "disabled"


class SkillManifest(BaseModel):
    schema_version: int = Field(default=1, alias="schemaVersion", ge=1)
    skill_id: str = Field(alias="id", min_length=1, pattern=r"^[a-z0-9][a-z0-9_-]*$")
    name: str = Field(min_length=1)
    version: str = Field(min_length=1, pattern=r"^\d+\.\d+\.\d+(?:[-+][A-Za-z0-9.-]+)?$")
    description: str = Field(min_length=1)
    author: str = Field(min_length=1)
    source: SkillSource
    capabilities: list[SkillCapability] = Field(min_length=1)
    supported_platforms: list[str] = Field(default_factory=list, alias="supportedPlatforms")
    input_schema: dict[str, object] = Field(default_factory=dict, alias="inputSchema")
    output_schema: dict[str, object] = Field(default_factory=dict, alias="outputSchema")
    tags: list[str] = Field(default_factory=list)
    requires_approval: bool = Field(default=False, alias="requiresApproval")
    trust_state: SkillTrustState = Field(default=SkillTrustState.untrusted, alias="trustState")
    entrypoint: str | None = None
    readme: str | None = None

    model_config = {"populate_by_name": True, "extra": "forbid"}

    @model_validator(mode="after")
    def _validate_unique_capabilities(self) -> SkillManifest:
        if len(set(self.capabilities)) != len(self.capabilities):
            raise ValueError("capabilities must be unique")
        return self


@dataclass(frozen=True, slots=True)
class SkillCatalogPaths:
    root: Path
    builtin_dir: Path
    local_dir: Path
    installed_dir: Path
    disabled_dir: Path
    cache_file: Path

    @classmethod
    def from_root(cls, root: Path) -> SkillCatalogPaths:
        return cls(
            root=root,
            builtin_dir=root / "builtin",
            local_dir=root / "local",
            installed_dir=root / "installed",
            disabled_dir=root / "disabled",
            cache_file=root / "catalog-cache.json",
        )

    @classmethod
    def default(cls, *, home_override: str | Path | None = None) -> SkillCatalogPaths:
        if home_override is not None:
            return cls.from_root(resolve_workagent_home(home_override=home_override) / "skills")
        return cls.from_root(resolve_agents_skills_home())

    def directory_for(self, source: SkillSource) -> Path:
        if source is SkillSource.builtin:
            return self.builtin_dir
        if source is SkillSource.local_dir:
            return self.local_dir
        if source is SkillSource.git_repo:
            return self.installed_dir
        return self.disabled_dir


@dataclass(frozen=True, slots=True)
class SkillManifestLocation:
    source: SkillSource
    skill_dir: Path
    manifest_path: Path


@dataclass(frozen=True, slots=True)
class SkillLintIssue:
    code: str
    message: str
    manifest_path: Path
    field_name: str | None = None


@dataclass(frozen=True, slots=True)
class SkillManifestValidationResult:
    manifest: SkillManifest | None
    issues: tuple[SkillLintIssue, ...] = ()


@dataclass(frozen=True, slots=True)
class LoadedSkillManifest:
    source: SkillSource
    skill_dir: Path
    manifest_path: Path
    manifest: SkillManifest

    @property
    def is_disabled(self) -> bool:
        return self.source is SkillSource.disabled


@dataclass(frozen=True, slots=True)
class SkillManifestLoadResult:
    entries: tuple[LoadedSkillManifest, ...]
    issues: tuple[SkillLintIssue, ...]


@dataclass(frozen=True, slots=True)
class SkillCatalogSnapshot:
    entries: tuple[LoadedSkillManifest, ...]
    issues: tuple[SkillLintIssue, ...]
    loaded_from_cache: bool = False

    def get(self, skill_id: str) -> LoadedSkillManifest | None:
        for entry in self.entries:
            if entry.manifest.skill_id == skill_id:
                return entry
        return None


@dataclass(frozen=True, slots=True)
class SkillSearchQuery:
    platform: str | None = None
    task_type: str | None = None
    tags: tuple[str, ...] = ()
    trusted_only: bool = True
    limit: int = 5


@dataclass(frozen=True, slots=True)
class SkillCandidate:
    skill_id: str
    name: str
    description: str
    source: SkillSource
    trust_state: SkillTrustState
    capabilities: tuple[SkillCapability, ...]
    supported_platforms: tuple[str, ...]
    tags: tuple[str, ...]
    requires_approval: bool
    score: int
    match_reasons: tuple[str, ...] = ()

    def as_prompt_dict(self) -> dict[str, object]:
        return {
            "id": self.skill_id,
            "name": self.name,
            "description": self.description,
            "source": self.source.value,
            "trustState": self.trust_state.value,
            "capabilities": [capability.value for capability in self.capabilities],
            "supportedPlatforms": list(self.supported_platforms),
            "tags": list(self.tags),
            "requiresApproval": self.requires_approval,
            "priorityScore": self.score,
            "matchReasons": list(self.match_reasons),
        }


@dataclass(frozen=True, slots=True)
class CompiledSkillContract:
    skill_id: str
    name: str
    source: SkillSource
    trust_state: SkillTrustState
    capabilities: tuple[SkillCapability, ...]
    instructions: tuple[str, ...] = ()
    checklist: tuple[str, ...] = ()
    workflow_steps: tuple[str, ...] = ()
    allowed_tools: tuple[str, ...] = ()
    blocked_tools: tuple[str, ...] = ()
    preferred_tools: tuple[str, ...] = ()
    validation_rules: tuple[str, ...] = ()
    raw_asset_refs: tuple[str, ...] = ()

    def as_prompt_dict(self) -> dict[str, object]:
        return {
            "id": self.skill_id,
            "name": self.name,
            "source": self.source.value,
            "trustState": self.trust_state.value,
            "capabilities": [capability.value for capability in self.capabilities],
            "instructions": list(self.instructions),
            "checklist": list(self.checklist),
            "workflowSteps": list(self.workflow_steps),
            "allowedTools": list(self.allowed_tools),
            "blockedTools": list(self.blocked_tools),
            "preferredTools": list(self.preferred_tools),
            "validationRules": list(self.validation_rules),
            "rawAssetRefs": list(self.raw_asset_refs),
        }
