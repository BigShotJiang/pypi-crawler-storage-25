from __future__ import annotations

from collections.abc import Sequence

from workagent.skills.models import (
    LoadedSkillManifest,
    SkillCatalogPaths,
    SkillManifestLoadResult,
    SkillManifestLocation,
    SkillSource,
)
from workagent.skills.validation import validate_skill_manifest_file

SKILL_MANIFEST_FILENAME = "skill.json"
SKILL_MARKDOWN_FILENAME = "SKILL.md"
_SOURCE_ORDER = (
    SkillSource.builtin,
    SkillSource.local_dir,
    SkillSource.git_repo,
    SkillSource.disabled,
)


class SkillManifestLoader:
    def __init__(self, paths: SkillCatalogPaths) -> None:
        self.paths = paths

    def discover_manifest_locations(self) -> tuple[SkillManifestLocation, ...]:
        locations: list[SkillManifestLocation] = []
        for skill_dir in sorted(self.paths.root.iterdir(), key=lambda item: item.name) if self.paths.root.exists() else []:
            if not skill_dir.is_dir():
                continue
            manifest_path = skill_dir / SKILL_MARKDOWN_FILENAME
            if manifest_path.is_file():
                locations.append(
                    SkillManifestLocation(
                        source=SkillSource.local_dir,
                        skill_dir=skill_dir,
                        manifest_path=manifest_path,
                    )
                )
        for source in _SOURCE_ORDER:
            root_dir = self.paths.directory_for(source)
            if not root_dir.exists():
                continue
            for skill_dir in sorted(root_dir.iterdir(), key=lambda item: item.name):
                if not skill_dir.is_dir():
                    continue
                manifest_path = skill_dir / SKILL_MANIFEST_FILENAME
                if manifest_path.is_file():
                    locations.append(
                        SkillManifestLocation(
                            source=source,
                            skill_dir=skill_dir,
                            manifest_path=manifest_path,
                        )
                    )
        return tuple(locations)

    def load_all(self, locations: Sequence[SkillManifestLocation] | None = None) -> SkillManifestLoadResult:
        effective_locations = tuple(locations) if locations is not None else self.discover_manifest_locations()
        entries: list[LoadedSkillManifest] = []
        issues = []
        for location in effective_locations:
            result = validate_skill_manifest_file(location.manifest_path)
            issues.extend(result.issues)
            if result.manifest is None:
                continue
            entries.append(
                LoadedSkillManifest(
                    source=location.source,
                    skill_dir=location.skill_dir,
                    manifest_path=location.manifest_path,
                    manifest=result.manifest,
                )
            )
        return SkillManifestLoadResult(entries=tuple(entries), issues=tuple(issues))
