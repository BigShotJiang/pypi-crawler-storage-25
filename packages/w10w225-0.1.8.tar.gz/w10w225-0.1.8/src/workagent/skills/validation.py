from __future__ import annotations

import json
from pathlib import Path

import yaml
from pydantic import ValidationError

from workagent.skills.models import SkillLintIssue, SkillManifest, SkillManifestValidationResult


def validate_skill_manifest_file(manifest_path: Path) -> SkillManifestValidationResult:
    if manifest_path.name == "SKILL.md":
        return validate_skill_markdown_file(manifest_path)
    try:
        payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        issue = SkillLintIssue(
            code="manifest_parse_error",
            message=str(exc),
            manifest_path=manifest_path,
        )
        return SkillManifestValidationResult(manifest=None, issues=(issue,))

    try:
        manifest = SkillManifest.model_validate(payload)
    except ValidationError as exc:
        issue = SkillLintIssue(
            code="manifest_validation_error",
            message=str(exc),
            manifest_path=manifest_path,
        )
        return SkillManifestValidationResult(manifest=None, issues=(issue,))

    issues = tuple(_lint_manifest_paths(manifest, manifest_path))
    if issues:
        return SkillManifestValidationResult(manifest=None, issues=issues)
    return SkillManifestValidationResult(manifest=manifest, issues=())


def validate_skill_markdown_file(manifest_path: Path) -> SkillManifestValidationResult:
    try:
        raw_text = manifest_path.read_text(encoding="utf-8")
    except OSError as exc:
        issue = SkillLintIssue(
            code="manifest_parse_error",
            message=str(exc),
            manifest_path=manifest_path,
        )
        return SkillManifestValidationResult(manifest=None, issues=(issue,))

    try:
        payload = _skill_markdown_to_manifest_payload(manifest_path, raw_text)
    except ValueError as exc:
        issue = SkillLintIssue(
            code="manifest_parse_error",
            message=str(exc),
            manifest_path=manifest_path,
        )
        return SkillManifestValidationResult(manifest=None, issues=(issue,))

    try:
        manifest = SkillManifest.model_validate(payload)
    except ValidationError as exc:
        issue = SkillLintIssue(
            code="manifest_validation_error",
            message=str(exc),
            manifest_path=manifest_path,
        )
        return SkillManifestValidationResult(manifest=None, issues=(issue,))

    return SkillManifestValidationResult(manifest=manifest, issues=())


def _skill_markdown_to_manifest_payload(manifest_path: Path, raw_text: str) -> dict[str, object]:
    if not raw_text.startswith("---\n"):
        raise ValueError("SKILL.md missing YAML frontmatter")
    try:
        _, frontmatter_text, _body = raw_text.split("---", 2)
    except ValueError as exc:
        raise ValueError("SKILL.md frontmatter is malformed") from exc
    metadata = yaml.safe_load(frontmatter_text) or {}
    if not isinstance(metadata, dict):
        raise ValueError("SKILL.md frontmatter must be a mapping")

    skill_id = str(metadata.get("name") or manifest_path.parent.name).strip()
    description = str(metadata.get("description") or "").strip()
    if not skill_id or not description:
        raise ValueError("SKILL.md frontmatter must include name and description")

    raw_meta = metadata.get("metadata")
    author = "skills.sh"
    version = "1.0.0"
    tags: list[str] = [skill_id]
    if isinstance(raw_meta, dict):
        author = str(raw_meta.get("author") or author).strip() or author
        version = str(raw_meta.get("version") or version).strip() or version
        category = str(raw_meta.get("category") or "").strip()
        if category:
            tags.append(category)

    return {
        "schemaVersion": 1,
        "id": skill_id,
        "name": skill_id,
        "version": version if version[0].isdigit() else "1.0.0",
        "description": description,
        "author": author,
        "source": "local_dir",
        "capabilities": ["prompt_template", "workflow"],
        "supportedPlatforms": [],
        "inputSchema": {},
        "outputSchema": {},
        "tags": tags,
        "requiresApproval": False,
        "trustState": "untrusted",
        "entrypoint": "SKILL.md",
    }


def _lint_manifest_paths(manifest: SkillManifest, manifest_path: Path) -> list[SkillLintIssue]:
    issues: list[SkillLintIssue] = []
    for field_name in ("entrypoint", "readme"):
        raw_value = getattr(manifest, field_name)
        if raw_value is None:
            continue
        if _is_safe_relative_path(raw_value):
            continue
        issues.append(
            SkillLintIssue(
                code="unsafe_relative_path",
                message=f"{field_name} must stay inside the skill directory",
                manifest_path=manifest_path,
                field_name=field_name,
            )
        )
    return issues


def _is_safe_relative_path(raw_value: str) -> bool:
    path = Path(raw_value)
    if path.is_absolute():
        return False
    if not path.parts:
        return False
    return all(part != ".." for part in path.parts)
