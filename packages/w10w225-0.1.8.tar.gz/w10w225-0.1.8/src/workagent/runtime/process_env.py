from __future__ import annotations

import json
import os
import platform
import shlex
import shutil
import stat
import subprocess
from pathlib import Path

_KEYRING_ENV_KEYS = (
    "DBUS_SESSION_BUS_ADDRESS",
    "DBUS_SESSION_BUS_PID",
    "GNOME_KEYRING_CONTROL",
    "GNOME_KEYRING_PID",
    "SSH_AUTH_SOCK",
)


def workagent_codex_home(home_dir: Path) -> Path:
    return home_dir / "codex-home"


def keyring_session_env_file(home_dir: Path) -> Path:
    return home_dir / "keyring-session.env"


def load_keyring_session_env(home_dir: Path) -> dict[str, str]:
    env_file = keyring_session_env_file(home_dir)
    if not env_file.exists():
        return {}
    loaded: dict[str, str] = {}
    for raw_line in env_file.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line.startswith("export ") or "=" not in line:
            continue
        assignment = line[len("export ") :]
        key, raw_value = assignment.split("=", 1)
        key = key.strip()
        if key not in _KEYRING_ENV_KEYS:
            continue
        parts = shlex.split(raw_value, posix=True)
        if parts:
            loaded[key] = parts[0]
    return loaded


def _write_keyring_session_env(home_dir: Path, payload: dict[str, str]) -> None:
    env_file = keyring_session_env_file(home_dir)
    env_file.parent.mkdir(parents=True, exist_ok=True)
    lines = [f"export {key}={shlex.quote(value)}" for key, value in payload.items() if value]
    env_file.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")


def _activate_linux_keyring_session() -> dict[str, str]:
    script = """
set -euo pipefail
if [[ -z "${DBUS_SESSION_BUS_ADDRESS:-}" ]]; then
  if command -v dbus-launch >/dev/null 2>&1; then
    eval "$(dbus-launch --sh-syntax 2>/dev/null)" || true
  elif command -v dbus-daemon >/dev/null 2>&1; then
    dbus_info="$(dbus-daemon --session --fork --print-address=1 --print-pid=1 2>/dev/null)" || true
    address="$(printf '%s\n' "${dbus_info}" | sed -n '1p')"
    pid="$(printf '%s\n' "${dbus_info}" | sed -n '2p')"
    [[ -n "${address}" ]] && export DBUS_SESSION_BUS_ADDRESS="${address}"
    [[ -n "${pid}" ]] && export DBUS_SESSION_BUS_PID="${pid}"
  fi
fi
if command -v gnome-keyring-daemon >/dev/null 2>&1; then
  daemon_output="$(gnome-keyring-daemon --start --components=secrets 2>/dev/null)" || true
  if [[ -n "${daemon_output}" ]]; then
    eval "${daemon_output}" || true
  fi
fi
python - <<'PY'
import json
import os

keys = [
    "DBUS_SESSION_BUS_ADDRESS",
    "DBUS_SESSION_BUS_PID",
    "GNOME_KEYRING_CONTROL",
    "GNOME_KEYRING_PID",
    "SSH_AUTH_SOCK",
]
print(json.dumps({key: os.environ.get(key, "") for key in keys if os.environ.get(key)}))
PY
"""
    try:
        completed = subprocess.run(  # noqa: S603
            ["bash", "-lc", script],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return {}
    if completed.returncode != 0:
        return {}
    try:
        payload = json.loads(completed.stdout.strip() or "{}")
    except json.JSONDecodeError:
        return {}
    return {key: str(value) for key, value in payload.items() if key in _KEYRING_ENV_KEYS and str(value).strip()}


def ensure_keyring_session_env(home_dir: Path) -> dict[str, str]:
    home_dir.mkdir(parents=True, exist_ok=True)
    loaded = load_keyring_session_env(home_dir)
    if loaded.get("DBUS_SESSION_BUS_ADDRESS"):
        return loaded
    if platform.system().lower() != "linux":
        return loaded
    activated = _activate_linux_keyring_session()
    if activated:
        _write_keyring_session_env(home_dir, activated)
        return activated
    return loaded


def _seed_codex_auth(home_dir: Path) -> None:
    codex_home = workagent_codex_home(home_dir)
    codex_home.mkdir(parents=True, exist_ok=True)
    destination = codex_home / "auth.json"
    if destination.exists():
        return
    source = Path.home() / ".codex" / "auth.json"
    if not source.exists():
        return
    shutil.copy2(source, destination)
    destination.chmod(stat.S_IRUSR | stat.S_IWUSR)


def build_codex_env_overrides(
    home_dir: Path,
    *,
    base_env: dict[str, str] | None = None,
) -> dict[str, str]:
    _seed_codex_auth(home_dir)
    overrides = dict(os.environ)
    overrides.update(base_env or {})
    overrides["CODEX_HOME"] = str(workagent_codex_home(home_dir))
    overrides.update(ensure_keyring_session_env(home_dir))
    return overrides


def build_workagent_process_env(home_dir: Path) -> dict[str, str]:
    env = dict(os.environ)
    env["WORKAGENT_HOME"] = str(home_dir)
    env.update(ensure_keyring_session_env(home_dir))
    return env
