from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from workagent.config.env import load_local_env_overrides
from workagent.config.models import (
    AppConfig,
    ConnectorConfig,
    LocalSettings,
    Platform,
    SlackTargetMode,
    WatchProfile,
    WatchProfilePreset,
)
from workagent.config.store import ConfigStore, default_config_paths
from workagent.connectors.asana_client import AsanaApiClient
from workagent.connectors.asana_sync import AsanaSyncService
from workagent.connectors.confluence_client import ConfluenceApiClient
from workagent.connectors.confluence_sync import ConfluenceSyncService
from workagent.connectors.discord_client import DiscordApiClient
from workagent.connectors.discord_sync import DiscordSyncService
from workagent.connectors.gitlab_client import GitLabApiClient
from workagent.connectors.gitlab_sync import GitLabSyncService
from workagent.connectors.gmail_client import GmailApiClient
from workagent.connectors.gmail_sync import GmailSyncService
from workagent.connectors.google_calendar_client import GoogleCalendarApiClient
from workagent.connectors.google_calendar_sync import GoogleCalendarSyncService
from workagent.connectors.google_drive_client import GoogleDriveApiClient
from workagent.connectors.google_drive_sync import GoogleDriveSyncService
from workagent.connectors.jira_client import JiraApiClient
from workagent.connectors.jira_sync import JiraSyncService
from workagent.connectors.linear_client import LinearApiClient
from workagent.connectors.linear_sync import LinearSyncService
from workagent.connectors.microsoft_teams_client import MicrosoftTeamsApiClient
from workagent.connectors.microsoft_teams_sync import MicrosoftTeamsSyncService
from workagent.connectors.notion_client import NotionApiClient
from workagent.connectors.notion_sync import NotionSyncService
from workagent.connectors.slack_client import SlackApiClient
from workagent.connectors.slack_send import SlackOutboundSender
from workagent.connectors.zendesk_client import ZendeskApiClient
from workagent.connectors.zendesk_sync import ZendeskSyncService
from workagent.db.enums import CaseStatus, ConnectorType, ExecutionEngine
from workagent.db.models import AppSetting
from workagent.executors.api import AnthropicExecutionEngine, GeminiExecutionEngine, OpenAIExecutionEngine
from workagent.executors.cli_adapters import ClaudeCliEngine, CopilotCliEngine, GeminiCliEngine
from workagent.executors.codex import CodexCliExecutor
from workagent.runtime.app_runtime import AppRuntime
from workagent.runtime.daemon_loop import PeriodicDaemonLoop
from workagent.runtime.loop import WorkAgentRuntimeLoop
from workagent.runtime.process_env import build_codex_env_overrides
from workagent.runtime.queue import LocalRunQueue
from workagent.runtime.secrets import FileSecretStore, SecretStore
from workagent.runtime.sync_loop import GitLabSyncLoop, GitLabSyncLoopSummary, SlackSyncLoop, SlackSyncLoopSummary
from workagent.runtime.tick import DaemonTickRuntime
from workagent.runtime.worker import LocalWorkerRuntime
from workagent.scheduler import SchedulerRuntime, SqlAlchemySchedulerJobRepository
from workagent.services import (
    CaseService,
    ScheduledCaseLauncher,
)
from workagent.services.agent_runtime_factory import (
    build_agent_onboarding_sync_runtime,
    build_agent_pending_sync_runtime,
    build_agent_socket_transport,
)
from workagent.services.asana_ingest import AsanaIngestService
from workagent.services.audit import AuditService
from workagent.services.confluence_ingest import ConfluenceIngestService
from workagent.services.credentials import CredentialTokenResolver
from workagent.services.discord_ingest import DiscordIngestService
from workagent.services.gmail_ingest import GmailIngestService
from workagent.services.google_calendar_ingest import GoogleCalendarIngestService
from workagent.services.google_drive_ingest import GoogleDriveIngestService
from workagent.services.jira_ingest import JiraIngestService
from workagent.services.linear_ingest import LinearIngestService
from workagent.services.microsoft_teams_ingest import MicrosoftTeamsIngestService
from workagent.services.notion_ingest import NotionIngestService
from workagent.services.outbound import OutboundQueueProcessor
from workagent.services.recovery import RecoveryService
from workagent.services.relay_runtime_factory import build_request_router
from workagent.services.review_push import ReviewPushService
from workagent.services.review_runtime_factory import build_review_sync_runtime
from workagent.services.sync_metadata import SyncMetadataService
from workagent.services.sync_state import (
    AsanaSeenStore,
    ConfluenceSeenStore,
    DiscordSeenStore,
    GmailSeenStore,
    GoogleCalendarSeenStore,
    GoogleDriveSeenStore,
    JiraSeenStore,
    LinearSeenStore,
    MicrosoftTeamsSeenStore,
    NotionSeenStore,
    SqlAlchemyCursorStore,
    ZendeskSeenStore,
)
from workagent.services.tool_shims import (
    ConfluenceReadTool,
    DynamicToolShimService,
    GitLabReadTool,
    JiraReadTool,
    SlackSearchTool,
    ToolShimService,
)
from workagent.services.topic_continuity import TopicContinuityService
from workagent.services.zendesk_ingest import ZendeskIngestService
from workagent.skills import SkillCatalogPaths, SkillCatalogService
from workagent.sync.runtime import ReviewSyncCycleSummary


@dataclass(frozen=True, slots=True)
class _ConfiguredExecutorBundle:
    engine_name: ExecutionEngine
    executor: object
    model: str | None


API_PLANNER_TIMEOUT_SECONDS = 60.0
API_TASK_TIMEOUT_SECONDS = 240.0


def _api_secret_key(provider: str) -> str:
    return f"engine:{provider}:api_key"


def _build_execution_bundle_for_engine(
    config: AppConfig,
    secret_store: SecretStore,
    engine_name: ExecutionEngine,
    *,
    home_dir: Path | None = None,
    api_timeout_seconds: float | None = None,
) -> _ConfiguredExecutorBundle:
    if engine_name.value == ExecutionEngine.codex_cli.value:
        settings = config.engine.codex_cli
        env_overrides = (
            build_codex_env_overrides(home_dir, base_env={"RUST_LOG": "warn"})
            if home_dir is not None
            else {"RUST_LOG": "warn"}
        )
        if settings.command == "codex" and not settings.profile:
            executor = CodexCliExecutor(reasoning_effort=None, env_overrides=env_overrides)
        else:
            executor = CodexCliExecutor(
                command=settings.command,
                profile=settings.profile,
                reasoning_effort=None,
                env_overrides=env_overrides,
            )
        return _ConfiguredExecutorBundle(
            engine_name=ExecutionEngine.codex_cli,
            executor=executor,
            model=settings.model,
        )
    if engine_name.value == ExecutionEngine.copilot_cli.value:
        settings = config.engine.copilot_cli
        token = secret_store.get("engine:copilot:github_token") if settings.auth_mode.value == "github_token" else None
        executor = CopilotCliEngine(command=settings.command, auth_token=token)
        return _ConfiguredExecutorBundle(
            engine_name=ExecutionEngine.copilot_cli,
            executor=executor,
            model=settings.model,
        )
    if engine_name.value == ExecutionEngine.claude_cli.value:
        settings = config.engine.claude_cli
        executor = ClaudeCliEngine(command=settings.command, model=settings.model)
        return _ConfiguredExecutorBundle(
            engine_name=ExecutionEngine.claude_cli,
            executor=executor,
            model=settings.model,
        )
    if engine_name.value == ExecutionEngine.gemini_cli.value:
        settings = config.engine.gemini_cli
        executor = GeminiCliEngine(command=settings.command, model=settings.model)
        return _ConfiguredExecutorBundle(
            engine_name=ExecutionEngine.gemini_cli,
            executor=executor,
            model=settings.model,
        )
    if engine_name.value == ExecutionEngine.openai_api.value:
        settings = config.engine.openai_api
        executor = OpenAIExecutionEngine(
            model_name=settings.model,
            api_key=secret_store.get(_api_secret_key("openai")),
            base_url=settings.base_url,
            timeout=api_timeout_seconds or API_TASK_TIMEOUT_SECONDS,
        )
        return _ConfiguredExecutorBundle(engine_name=ExecutionEngine.openai_api, executor=executor, model=settings.model)
    if engine_name.value == ExecutionEngine.anthropic_api.value:
        settings = config.engine.anthropic_api
        executor = AnthropicExecutionEngine(
            model_name=settings.model,
            api_key=secret_store.get(_api_secret_key("anthropic")),
            base_url=settings.base_url,
            timeout=api_timeout_seconds or API_TASK_TIMEOUT_SECONDS,
        )
        return _ConfiguredExecutorBundle(
            engine_name=ExecutionEngine.anthropic_api,
            executor=executor,
            model=settings.model,
        )
    settings = config.engine.gemini_api
    executor = GeminiExecutionEngine(
        model_name=settings.model,
        api_key=secret_store.get(_api_secret_key("gemini")),
        base_url=settings.base_url,
        timeout=api_timeout_seconds or API_TASK_TIMEOUT_SECONDS,
    )
    return _ConfiguredExecutorBundle(engine_name=ExecutionEngine.gemini_api, executor=executor, model=settings.model)


def _build_execution_bundle(
    config: AppConfig,
    secret_store: SecretStore,
    *,
    home_dir: Path | None = None,
) -> _ConfiguredExecutorBundle:
    return _build_execution_bundle_for_engine(
        config,
        secret_store,
        config.engine.default_engine,
        home_dir=home_dir,
    )


def _apply_env_overrides(config: AppConfig) -> AppConfig:
    """Override config.local with values from .env / environment variables if set."""
    overrides = load_local_env_overrides()
    workspace_dirs = overrides["workspace_dirs"] or config.local.workspace_dirs
    if workspace_dirs == config.local.workspace_dirs:
        return config
    updated_local = LocalSettings(
        workspaceDirs=workspace_dirs,
        launcherLanguage=config.local.launcher_language.value,
    )
    return config.model_copy(update={"local": updated_local})


def _get_code_model(config: AppConfig) -> str | None:
    """Return the code-task model override for the currently configured engine."""
    engine = config.engine.default_engine
    if engine.value == ExecutionEngine.codex_cli.value:
        return config.engine.codex_cli.model_code
    if engine.value == ExecutionEngine.copilot_cli.value:
        return config.engine.copilot_cli.model_code
    if engine.value == ExecutionEngine.claude_cli.value:
        return config.engine.claude_cli.model_code
    if engine.value == ExecutionEngine.gemini_cli.value:
        return config.engine.gemini_cli.model_code
    if engine.value == ExecutionEngine.openai_api.value:
        return config.engine.openai_api.model_code
    if engine.value == ExecutionEngine.anthropic_api.value:
        return config.engine.anthropic_api.model_code
    if engine.value == ExecutionEngine.gemini_api.value:
        return config.engine.gemini_api.model_code
    return None


def _get_code_reasoning_effort(config: AppConfig) -> str | None:
    """Return the code-task reasoning_effort override (Codex only)."""
    if config.engine.default_engine.value == ExecutionEngine.codex_cli.value:
        return config.engine.codex_cli.reasoning_effort_code
    return None


@dataclass(frozen=True, slots=True)
class DaemonRuntimeBundle:
    app_runtime: AppRuntime
    runtime_loop: WorkAgentRuntimeLoop | AppRuntimeLoopAdapter
    review_push_service: object
    outbound_processor: OutboundQueueProcessor
    tick_runtime: DaemonTickRuntime
    daemon_loop: PeriodicDaemonLoop
    recovery_service: RecoveryService
    queue: LocalRunQueue

    async def recover_startup(self):
        return await self.recovery_service.recover(queue=self.queue)


class AppRuntimeLoopAdapter:
    def __init__(self, app_runtime: AppRuntime) -> None:
        self.app_runtime = app_runtime

    async def run_cycle(self):
        return await self.app_runtime.run_once()


@dataclass(frozen=True, slots=True)
class PlatformSyncRegistration:
    platform_key: str
    build_loop: Callable[..., object]


class _NoopSlackSyncLoop:
    async def run_once(self) -> SlackSyncLoopSummary:
        return SlackSyncLoopSummary(
            polled_channels=0,
            polled_events=0,
            created_cases=0,
        )


class _NoopGitLabSyncLoop:
    async def run_once(self) -> GitLabSyncLoopSummary:
        return GitLabSyncLoopSummary(
            polled_events=0,
            created_cases=0,
            next_cursor=None,
        )


@dataclass(frozen=True, slots=True)
class _JiraSyncLoopSummary:
    polled_events: int
    created_cases: int
    next_cursor: str | None


@dataclass(frozen=True, slots=True)
class _ConfluenceSyncLoopSummary:
    polled_events: int
    created_cases: int
    next_cursor: str | None


@dataclass(frozen=True, slots=True)
class _NotionSyncLoopSummary:
    polled_events: int
    created_cases: int
    next_cursor: str | None


@dataclass(frozen=True, slots=True)
class _AsanaSyncLoopSummary:
    polled_events: int
    created_cases: int
    next_cursor: str | None


@dataclass(frozen=True, slots=True)
class _LinearSyncLoopSummary:
    polled_events: int
    created_cases: int
    next_cursor: str | None


@dataclass(frozen=True, slots=True)
class _GmailSyncLoopSummary:
    polled_events: int
    created_cases: int
    next_cursor: str | None


@dataclass(frozen=True, slots=True)
class _GoogleCalendarSyncLoopSummary:
    polled_events: int
    created_cases: int
    next_cursor: str | None


@dataclass(frozen=True, slots=True)
class _GoogleDriveSyncLoopSummary:
    polled_events: int
    created_cases: int
    next_cursor: str | None


@dataclass(frozen=True, slots=True)
class _ZendeskSyncLoopSummary:
    polled_events: int
    created_cases: int
    next_cursor: str | None


@dataclass(frozen=True, slots=True)
class _DiscordSyncLoopSummary:
    polled_events: int
    created_cases: int
    next_cursor: str | None


@dataclass(frozen=True, slots=True)
class _MicrosoftTeamsSyncLoopSummary:
    polled_events: int
    created_cases: int
    next_cursor: str | None


class _NoopJiraSyncLoop:
    async def run_once(self) -> _JiraSyncLoopSummary:
        return _JiraSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)


class _NoopConfluenceSyncLoop:
    async def run_once(self) -> _ConfluenceSyncLoopSummary:
        return _ConfluenceSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)


class _NoopNotionSyncLoop:
    async def run_once(self) -> _NotionSyncLoopSummary:
        return _NotionSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)


class _NoopAsanaSyncLoop:
    async def run_once(self) -> _AsanaSyncLoopSummary:
        return _AsanaSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)


class _NoopLinearSyncLoop:
    async def run_once(self) -> _LinearSyncLoopSummary:
        return _LinearSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)


class _NoopGmailSyncLoop:
    async def run_once(self) -> _GmailSyncLoopSummary:
        return _GmailSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)


class _NoopGoogleCalendarSyncLoop:
    async def run_once(self) -> _GoogleCalendarSyncLoopSummary:
        return _GoogleCalendarSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)


class _NoopGoogleDriveSyncLoop:
    async def run_once(self) -> _GoogleDriveSyncLoopSummary:
        return _GoogleDriveSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)


class _NoopZendeskSyncLoop:
    async def run_once(self) -> _ZendeskSyncLoopSummary:
        return _ZendeskSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)


class _NoopDiscordSyncLoop:
    async def run_once(self) -> _DiscordSyncLoopSummary:
        return _DiscordSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)


class _NoopMicrosoftTeamsSyncLoop:
    async def run_once(self) -> _MicrosoftTeamsSyncLoopSummary:
        return _MicrosoftTeamsSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)


class _NoopReviewRuntime:
    async def run_cycle(self) -> ReviewSyncCycleSummary:
        return ReviewSyncCycleSummary(
            total_commands=0,
            completed_commands=0,
            failed_commands=0,
        )


class _NoopAgentPendingRuntime:
    async def run_cycle(self):
        from workagent.sync.agent_runtime import AgentPendingSyncCycleSummary

        return AgentPendingSyncCycleSummary(total_items=0, completed_items=0, failed_items=0)


class _NoopAgentOnboardingRuntime:
    async def run_cycle(self):
        from workagent.sync.agent_runtime import AgentOnboardingSyncCycleSummary

        return AgentOnboardingSyncCycleSummary(total_items=0, completed_items=0, failed_items=0)


class _NoopReviewPushService:
    async def push_ready_cases(self) -> list[str]:
        return []


class _NoopRequestRouter:
    async def process_next(self) -> bool:
        return False

    async def route(self, pending_item) -> None:
        pass


class _ReloadableLoop:
    def __init__(self, *, config_loader: Callable[[], AppConfig], build_loop: Callable[[AppConfig], object]) -> None:
        self._config_loader = config_loader
        self._build_loop = build_loop
        self._prepared_loop: object | None = None

    def _ensure_loop(self) -> object:
        if self._prepared_loop is None:
            self._prepared_loop = self._build_loop(self._config_loader())
        return self._prepared_loop

    @property
    def runtime(self):  # noqa: ANN201
        loop = self._ensure_loop()
        return getattr(loop, "runtime", loop)

    async def run_once(self):  # noqa: ANN201
        loop = self._ensure_loop()
        self._prepared_loop = None
        return await loop.run_once()


class _ManagedSlackSyncLoop:
    def __init__(self, *, runtime, sync_metadata: SyncMetadataService, poll_interval_seconds: int) -> None:  # noqa: ANN001
        self.runtime = runtime
        self.sync_metadata = sync_metadata
        self.poll_interval_seconds = poll_interval_seconds

    async def run_once(self) -> SlackSyncLoopSummary:
        status = await self.sync_metadata.get_status(ConnectorType.slack)
        now = datetime.now(UTC)
        if status.last_success_at is not None and now < status.last_success_at + timedelta(seconds=self.poll_interval_seconds):
            return SlackSyncLoopSummary(polled_channels=0, polled_events=0, created_cases=0)
        if not await self.sync_metadata.is_sync_allowed(ConnectorType.slack, now=now):
            return SlackSyncLoopSummary(polled_channels=0, polled_events=0, created_cases=0)
        try:
            result = await self.runtime.run_once()
        except Exception as exc:  # noqa: BLE001
            await self.sync_metadata.record_failure(ConnectorType.slack, error=str(exc))
            return SlackSyncLoopSummary(polled_channels=0, polled_events=0, created_cases=0)
        await self.sync_metadata.record_success(ConnectorType.slack)
        return result


class _ManagedGitLabSyncLoop:
    def __init__(self, *, runtime, sync_metadata: SyncMetadataService, poll_interval_seconds: int) -> None:  # noqa: ANN001
        self.runtime = runtime
        self.sync_metadata = sync_metadata
        self.poll_interval_seconds = poll_interval_seconds

    async def run_once(self) -> GitLabSyncLoopSummary:
        status = await self.sync_metadata.get_status(ConnectorType.gitlab)
        now = datetime.now(UTC)
        if status.last_success_at is not None and now < status.last_success_at + timedelta(seconds=self.poll_interval_seconds):
            return GitLabSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        if not await self.sync_metadata.is_sync_allowed(ConnectorType.gitlab, now=now):
            return GitLabSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        try:
            result = await self.runtime.run_once()
        except Exception as exc:  # noqa: BLE001
            await self.sync_metadata.record_failure(ConnectorType.gitlab, error=str(exc))
            return GitLabSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        await self.sync_metadata.record_success(ConnectorType.gitlab)
        return result


class _JiraSyncLoopRuntime:
    def __init__(self, *, sync_service: JiraSyncService, ingest_service: JiraIngestService, queue: LocalRunQueue) -> None:
        self.sync_service = sync_service
        self.ingest_service = ingest_service
        self.queue = queue

    async def run_once(self) -> _JiraSyncLoopSummary:
        batch = await self.sync_service.sync_once()
        case_ids = await self.ingest_service.ingest(batch.events)
        for case_id in case_ids:
            await self.queue.enqueue(case_id)
        await self.sync_service.commit(batch)
        return _JiraSyncLoopSummary(
            polled_events=len(batch.events),
            created_cases=len(case_ids),
            next_cursor=batch.next_cursor,
        )


class _ConfluenceSyncLoopRuntime:
    def __init__(
        self,
        *,
        sync_service: ConfluenceSyncService,
        ingest_service: ConfluenceIngestService,
        queue: LocalRunQueue,
    ) -> None:
        self.sync_service = sync_service
        self.ingest_service = ingest_service
        self.queue = queue

    async def run_once(self) -> _ConfluenceSyncLoopSummary:
        batch = await self.sync_service.sync_once()
        case_ids = await self.ingest_service.ingest(batch.events)
        for case_id in case_ids:
            await self.queue.enqueue(case_id)
        await self.sync_service.commit(batch)
        return _ConfluenceSyncLoopSummary(
            polled_events=len(batch.events),
            created_cases=len(case_ids),
            next_cursor=batch.next_cursor,
        )


class _NotionSyncLoopRuntime:
    def __init__(
        self,
        *,
        sync_service: NotionSyncService,
        ingest_service: NotionIngestService,
        queue: LocalRunQueue,
    ) -> None:
        self.sync_service = sync_service
        self.ingest_service = ingest_service
        self.queue = queue

    async def run_once(self) -> _NotionSyncLoopSummary:
        batch = await self.sync_service.sync_once()
        case_ids = await self.ingest_service.ingest(batch.events)
        for case_id in case_ids:
            await self.queue.enqueue(case_id)
        await self.sync_service.commit(batch)
        return _NotionSyncLoopSummary(
            polled_events=len(batch.events),
            created_cases=len(case_ids),
            next_cursor=batch.next_cursor,
        )


class _AsanaSyncLoopRuntime:
    def __init__(
        self,
        *,
        sync_service: AsanaSyncService,
        ingest_service: AsanaIngestService,
        queue: LocalRunQueue,
    ) -> None:
        self.sync_service = sync_service
        self.ingest_service = ingest_service
        self.queue = queue

    async def run_once(self) -> _AsanaSyncLoopSummary:
        batch = await self.sync_service.sync_once()
        case_ids = await self.ingest_service.ingest(batch.events)
        for case_id in case_ids:
            await self.queue.enqueue(case_id)
        await self.sync_service.commit(batch)
        return _AsanaSyncLoopSummary(
            polled_events=len(batch.events),
            created_cases=len(case_ids),
            next_cursor=batch.next_cursor,
        )


class _LinearSyncLoopRuntime:
    def __init__(
        self,
        *,
        sync_service: LinearSyncService,
        ingest_service: LinearIngestService,
        queue: LocalRunQueue,
    ) -> None:
        self.sync_service = sync_service
        self.ingest_service = ingest_service
        self.queue = queue

    async def run_once(self) -> _LinearSyncLoopSummary:
        batch = await self.sync_service.sync_once()
        case_ids = await self.ingest_service.ingest(batch.events)
        for case_id in case_ids:
            await self.queue.enqueue(case_id)
        await self.sync_service.commit(batch)
        return _LinearSyncLoopSummary(
            polled_events=len(batch.events),
            created_cases=len(case_ids),
            next_cursor=batch.next_cursor,
        )


class _GmailSyncLoopRuntime:
    def __init__(
        self,
        *,
        sync_service: GmailSyncService,
        ingest_service: GmailIngestService,
        queue: LocalRunQueue,
    ) -> None:
        self.sync_service = sync_service
        self.ingest_service = ingest_service
        self.queue = queue

    async def run_once(self) -> _GmailSyncLoopSummary:
        batch = await self.sync_service.sync_once()
        case_ids = await self.ingest_service.ingest(batch.events)
        for case_id in case_ids:
            await self.queue.enqueue(case_id)
        await self.sync_service.commit(batch)
        return _GmailSyncLoopSummary(
            polled_events=len(batch.events),
            created_cases=len(case_ids),
            next_cursor=batch.next_cursor,
        )


class _GoogleCalendarSyncLoopRuntime:
    def __init__(
        self,
        *,
        sync_service: GoogleCalendarSyncService,
        ingest_service: GoogleCalendarIngestService,
        queue: LocalRunQueue,
    ) -> None:
        self.sync_service = sync_service
        self.ingest_service = ingest_service
        self.queue = queue

    async def run_once(self) -> _GoogleCalendarSyncLoopSummary:
        batch = await self.sync_service.sync_once()
        case_ids = await self.ingest_service.ingest(batch.events)
        for case_id in case_ids:
            await self.queue.enqueue(case_id)
        await self.sync_service.commit(batch)
        return _GoogleCalendarSyncLoopSummary(
            polled_events=len(batch.events),
            created_cases=len(case_ids),
            next_cursor=batch.next_cursor,
        )


class _GoogleDriveSyncLoopRuntime:
    def __init__(
        self,
        *,
        sync_service: GoogleDriveSyncService,
        ingest_service: GoogleDriveIngestService,
        queue: LocalRunQueue,
    ) -> None:
        self.sync_service = sync_service
        self.ingest_service = ingest_service
        self.queue = queue

    async def run_once(self) -> _GoogleDriveSyncLoopSummary:
        batch = await self.sync_service.sync_once()
        case_ids = await self.ingest_service.ingest(batch.events)
        for case_id in case_ids:
            await self.queue.enqueue(case_id)
        await self.sync_service.commit(batch)
        return _GoogleDriveSyncLoopSummary(
            polled_events=len(batch.events),
            created_cases=len(case_ids),
            next_cursor=batch.next_cursor,
        )


class _ZendeskSyncLoopRuntime:
    def __init__(
        self,
        *,
        sync_service: ZendeskSyncService,
        ingest_service: ZendeskIngestService,
        queue: LocalRunQueue,
    ) -> None:
        self.sync_service = sync_service
        self.ingest_service = ingest_service
        self.queue = queue

    async def run_once(self) -> _ZendeskSyncLoopSummary:
        batch = await self.sync_service.sync_once()
        case_ids = await self.ingest_service.ingest(batch.events)
        for case_id in case_ids:
            await self.queue.enqueue(case_id)
        await self.sync_service.commit(batch)
        return _ZendeskSyncLoopSummary(
            polled_events=len(batch.events),
            created_cases=len(case_ids),
            next_cursor=batch.next_cursor,
        )


class _DiscordSyncLoopRuntime:
    def __init__(
        self,
        *,
        sync_service: DiscordSyncService,
        ingest_service: DiscordIngestService,
        queue: LocalRunQueue,
    ) -> None:
        self.sync_service = sync_service
        self.ingest_service = ingest_service
        self.queue = queue

    async def run_once(self) -> _DiscordSyncLoopSummary:
        batch = await self.sync_service.sync_once()
        case_ids = await self.ingest_service.ingest(batch.events)
        for case_id in case_ids:
            await self.queue.enqueue(case_id)
        await self.sync_service.commit(batch)
        return _DiscordSyncLoopSummary(
            polled_events=len(batch.events),
            created_cases=len(case_ids),
            next_cursor=batch.next_cursor,
        )


class _MicrosoftTeamsSyncLoopRuntime:
    def __init__(
        self,
        *,
        sync_service: MicrosoftTeamsSyncService,
        ingest_service: MicrosoftTeamsIngestService,
        queue: LocalRunQueue,
    ) -> None:
        self.sync_service = sync_service
        self.ingest_service = ingest_service
        self.queue = queue

    async def run_once(self) -> _MicrosoftTeamsSyncLoopSummary:
        batch = await self.sync_service.sync_once()
        case_ids = await self.ingest_service.ingest(batch.events)
        for case_id in case_ids:
            await self.queue.enqueue(case_id)
        await self.sync_service.commit(batch)
        return _MicrosoftTeamsSyncLoopSummary(
            polled_events=len(batch.events),
            created_cases=len(case_ids),
            next_cursor=batch.next_cursor,
        )


class _ManagedJiraSyncLoop:
    def __init__(self, *, runtime, sync_metadata: SyncMetadataService, poll_interval_seconds: int) -> None:  # noqa: ANN001
        self.runtime = runtime
        self.sync_metadata = sync_metadata
        self.poll_interval_seconds = poll_interval_seconds

    async def run_once(self) -> _JiraSyncLoopSummary:
        status = await self.sync_metadata.get_status(ConnectorType.jira)
        now = datetime.now(UTC)
        if status.last_success_at is not None and now < status.last_success_at + timedelta(seconds=self.poll_interval_seconds):
            return _JiraSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        if not await self.sync_metadata.is_sync_allowed(ConnectorType.jira, now=now):
            return _JiraSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        try:
            result = await self.runtime.run_once()
        except Exception as exc:  # noqa: BLE001
            await self.sync_metadata.record_failure(ConnectorType.jira, error=str(exc))
            return _JiraSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        await self.sync_metadata.record_success(ConnectorType.jira)
        return result


class _ManagedConfluenceSyncLoop:
    def __init__(self, *, runtime, sync_metadata: SyncMetadataService, poll_interval_seconds: int) -> None:  # noqa: ANN001
        self.runtime = runtime
        self.sync_metadata = sync_metadata
        self.poll_interval_seconds = poll_interval_seconds

    async def run_once(self) -> _ConfluenceSyncLoopSummary:
        status = await self.sync_metadata.get_status(ConnectorType.confluence)
        now = datetime.now(UTC)
        if status.last_success_at is not None and now < status.last_success_at + timedelta(seconds=self.poll_interval_seconds):
            return _ConfluenceSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        if not await self.sync_metadata.is_sync_allowed(ConnectorType.confluence, now=now):
            return _ConfluenceSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        try:
            result = await self.runtime.run_once()
        except Exception as exc:  # noqa: BLE001
            await self.sync_metadata.record_failure(ConnectorType.confluence, error=str(exc))
            return _ConfluenceSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        await self.sync_metadata.record_success(ConnectorType.confluence)
        return result


class _ManagedNotionSyncLoop:
    def __init__(self, *, runtime, sync_metadata: SyncMetadataService, poll_interval_seconds: int) -> None:  # noqa: ANN001
        self.runtime = runtime
        self.sync_metadata = sync_metadata
        self.poll_interval_seconds = poll_interval_seconds

    async def run_once(self) -> _NotionSyncLoopSummary:
        status = await self.sync_metadata.get_status(ConnectorType.notion)
        now = datetime.now(UTC)
        if status.last_success_at is not None and now < status.last_success_at + timedelta(seconds=self.poll_interval_seconds):
            return _NotionSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        if not await self.sync_metadata.is_sync_allowed(ConnectorType.notion, now=now):
            return _NotionSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        try:
            result = await self.runtime.run_once()
        except Exception as exc:  # noqa: BLE001
            await self.sync_metadata.record_failure(ConnectorType.notion, error=str(exc))
            return _NotionSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        await self.sync_metadata.record_success(ConnectorType.notion)
        return result


class _ManagedAsanaSyncLoop:
    def __init__(self, *, runtime, sync_metadata: SyncMetadataService, poll_interval_seconds: int) -> None:  # noqa: ANN001
        self.runtime = runtime
        self.sync_metadata = sync_metadata
        self.poll_interval_seconds = poll_interval_seconds

    async def run_once(self) -> _AsanaSyncLoopSummary:
        status = await self.sync_metadata.get_status(ConnectorType.asana)
        now = datetime.now(UTC)
        if status.last_success_at is not None and now < status.last_success_at + timedelta(seconds=self.poll_interval_seconds):
            return _AsanaSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        if not await self.sync_metadata.is_sync_allowed(ConnectorType.asana, now=now):
            return _AsanaSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        try:
            result = await self.runtime.run_once()
        except Exception as exc:  # noqa: BLE001
            await self.sync_metadata.record_failure(ConnectorType.asana, error=str(exc))
            return _AsanaSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        await self.sync_metadata.record_success(ConnectorType.asana)
        return result


class _ManagedLinearSyncLoop:
    def __init__(self, *, runtime, sync_metadata: SyncMetadataService, poll_interval_seconds: int) -> None:  # noqa: ANN001
        self.runtime = runtime
        self.sync_metadata = sync_metadata
        self.poll_interval_seconds = poll_interval_seconds

    async def run_once(self) -> _LinearSyncLoopSummary:
        status = await self.sync_metadata.get_status(ConnectorType.linear)
        now = datetime.now(UTC)
        if status.last_success_at is not None and now < status.last_success_at + timedelta(seconds=self.poll_interval_seconds):
            return _LinearSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        if not await self.sync_metadata.is_sync_allowed(ConnectorType.linear, now=now):
            return _LinearSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        try:
            result = await self.runtime.run_once()
        except Exception as exc:  # noqa: BLE001
            await self.sync_metadata.record_failure(ConnectorType.linear, error=str(exc))
            return _LinearSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        await self.sync_metadata.record_success(ConnectorType.linear)
        return result


class _ManagedGmailSyncLoop:
    def __init__(self, *, runtime, sync_metadata: SyncMetadataService, poll_interval_seconds: int) -> None:  # noqa: ANN001
        self.runtime = runtime
        self.sync_metadata = sync_metadata
        self.poll_interval_seconds = poll_interval_seconds

    async def run_once(self) -> _GmailSyncLoopSummary:
        status = await self.sync_metadata.get_status(ConnectorType.gmail)
        now = datetime.now(UTC)
        if status.last_success_at is not None and now < status.last_success_at + timedelta(seconds=self.poll_interval_seconds):
            return _GmailSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        if not await self.sync_metadata.is_sync_allowed(ConnectorType.gmail, now=now):
            return _GmailSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        try:
            result = await self.runtime.run_once()
        except Exception as exc:  # noqa: BLE001
            await self.sync_metadata.record_failure(ConnectorType.gmail, error=str(exc))
            return _GmailSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        await self.sync_metadata.record_success(ConnectorType.gmail)
        return result


class _ManagedGoogleCalendarSyncLoop:
    def __init__(self, *, runtime, sync_metadata: SyncMetadataService, poll_interval_seconds: int) -> None:  # noqa: ANN001
        self.runtime = runtime
        self.sync_metadata = sync_metadata
        self.poll_interval_seconds = poll_interval_seconds

    async def run_once(self) -> _GoogleCalendarSyncLoopSummary:
        status = await self.sync_metadata.get_status(ConnectorType.google_calendar)
        now = datetime.now(UTC)
        if status.last_success_at is not None and now < status.last_success_at + timedelta(seconds=self.poll_interval_seconds):
            return _GoogleCalendarSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        if not await self.sync_metadata.is_sync_allowed(ConnectorType.google_calendar, now=now):
            return _GoogleCalendarSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        try:
            result = await self.runtime.run_once()
        except Exception as exc:  # noqa: BLE001
            await self.sync_metadata.record_failure(ConnectorType.google_calendar, error=str(exc))
            return _GoogleCalendarSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        await self.sync_metadata.record_success(ConnectorType.google_calendar)
        return result


class _ManagedGoogleDriveSyncLoop:
    def __init__(self, *, runtime, sync_metadata: SyncMetadataService, poll_interval_seconds: int) -> None:  # noqa: ANN001
        self.runtime = runtime
        self.sync_metadata = sync_metadata
        self.poll_interval_seconds = poll_interval_seconds

    async def run_once(self) -> _GoogleDriveSyncLoopSummary:
        status = await self.sync_metadata.get_status(ConnectorType.google_drive)
        now = datetime.now(UTC)
        if status.last_success_at is not None and now < status.last_success_at + timedelta(seconds=self.poll_interval_seconds):
            return _GoogleDriveSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        if not await self.sync_metadata.is_sync_allowed(ConnectorType.google_drive, now=now):
            return _GoogleDriveSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        try:
            result = await self.runtime.run_once()
        except Exception as exc:  # noqa: BLE001
            await self.sync_metadata.record_failure(ConnectorType.google_drive, error=str(exc))
            return _GoogleDriveSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        await self.sync_metadata.record_success(ConnectorType.google_drive)
        return result


class _ManagedZendeskSyncLoop:
    def __init__(self, *, runtime, sync_metadata: SyncMetadataService, poll_interval_seconds: int) -> None:  # noqa: ANN001
        self.runtime = runtime
        self.sync_metadata = sync_metadata
        self.poll_interval_seconds = poll_interval_seconds

    async def run_once(self) -> _ZendeskSyncLoopSummary:
        status = await self.sync_metadata.get_status(ConnectorType.zendesk)
        now = datetime.now(UTC)
        if status.last_success_at is not None and now < status.last_success_at + timedelta(seconds=self.poll_interval_seconds):
            return _ZendeskSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        if not await self.sync_metadata.is_sync_allowed(ConnectorType.zendesk, now=now):
            return _ZendeskSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        try:
            result = await self.runtime.run_once()
        except Exception as exc:  # noqa: BLE001
            await self.sync_metadata.record_failure(ConnectorType.zendesk, error=str(exc))
            return _ZendeskSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        await self.sync_metadata.record_success(ConnectorType.zendesk)
        return result


class _ManagedDiscordSyncLoop:
    def __init__(self, *, runtime, sync_metadata: SyncMetadataService, poll_interval_seconds: int) -> None:  # noqa: ANN001
        self.runtime = runtime
        self.sync_metadata = sync_metadata
        self.poll_interval_seconds = poll_interval_seconds

    async def run_once(self) -> _DiscordSyncLoopSummary:
        status = await self.sync_metadata.get_status(ConnectorType.discord)
        now = datetime.now(UTC)
        if status.last_success_at is not None and now < status.last_success_at + timedelta(seconds=self.poll_interval_seconds):
            return _DiscordSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        if not await self.sync_metadata.is_sync_allowed(ConnectorType.discord, now=now):
            return _DiscordSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        try:
            result = await self.runtime.run_once()
        except Exception as exc:  # noqa: BLE001
            await self.sync_metadata.record_failure(ConnectorType.discord, error=str(exc))
            return _DiscordSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        await self.sync_metadata.record_success(ConnectorType.discord)
        return result


class _ManagedMicrosoftTeamsSyncLoop:
    def __init__(self, *, runtime, sync_metadata: SyncMetadataService, poll_interval_seconds: int) -> None:  # noqa: ANN001
        self.runtime = runtime
        self.sync_metadata = sync_metadata
        self.poll_interval_seconds = poll_interval_seconds

    async def run_once(self) -> _MicrosoftTeamsSyncLoopSummary:
        status = await self.sync_metadata.get_status(ConnectorType.microsoft_teams)
        now = datetime.now(UTC)
        if status.last_success_at is not None and now < status.last_success_at + timedelta(seconds=self.poll_interval_seconds):
            return _MicrosoftTeamsSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        if not await self.sync_metadata.is_sync_allowed(ConnectorType.microsoft_teams, now=now):
            return _MicrosoftTeamsSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        try:
            result = await self.runtime.run_once()
        except Exception as exc:  # noqa: BLE001
            await self.sync_metadata.record_failure(ConnectorType.microsoft_teams, error=str(exc))
            return _MicrosoftTeamsSyncLoopSummary(polled_events=0, created_cases=0, next_cursor=None)
        await self.sync_metadata.record_success(ConnectorType.microsoft_teams)
        return result


class SlackChannelCursorStore:
    def __init__(self, *, session_factory: async_sessionmaker[AsyncSession], channel_id: str) -> None:
        self.session_factory = session_factory
        self.channel_id = channel_id

    async def load(self) -> str | None:
        async with self.session_factory() as session:
            row = await session.get(AppSetting, self._key)
            if row is None:
                return None
            return str(row.value_json.get("cursor") or "").strip() or None

    async def save(self, cursor: str | None) -> None:
        async with self.session_factory() as session:
            row = await session.get(AppSetting, self._key)
            payload = {"cursor": cursor}
            if row is None:
                session.add(AppSetting(key=self._key, value_json=payload))
            else:
                row.value_json = payload
            await session.commit()

    @property
    def _key(self) -> str:
        return f"slack_channel_cursor:{self.channel_id}"


class SqlAlchemyDefaultSlackChannelStore:
    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self.session_factory = session_factory

    async def get_channel_id(self) -> str | None:
        async with self.session_factory() as session:
            row = await session.get(AppSetting, "agent_slack_channel_id")
            if row is None:
                return None
            return str(row.value_json.get("channelId") or "").strip() or None


class QueueingCaseService:
    def __init__(self, inner: CaseService, *, continuity_service: TopicContinuityService | None = None) -> None:
        self.inner = inner
        self.continuity_service = continuity_service

    async def create_case(self, *, source, connector_type, title, payload):  # noqa: ANN001
        enriched_payload = payload
        if self.continuity_service is not None and isinstance(payload, dict):
            enriched_payload = await self.continuity_service.enrich_payload(
                source=source,
                connector_type=connector_type,
                title=title,
                payload=payload,
            )
        case = await self.inner.create_case(
            source=source,
            connector_type=connector_type,
            title=title,
            payload=enriched_payload,
        )
        await self.inner.transition_case(
            case.id,
            CaseStatus.queued_for_local_run,
            payload={"reason": "sync_ingest"},
        )
        return case

    async def add_artifact(self, case_id: str, *, artifact_type: str, relative_path: str, metadata=None) -> None:  # noqa: ANN001
        await self.inner.add_artifact(
            case_id,
            artifact_type=artifact_type,
            relative_path=relative_path,
            metadata=metadata,
        )


def build_daemon_runtime_bundle(
    *,
    config: AppConfig,
    session_factory: async_sessionmaker[AsyncSession],
    secret_store: SecretStore,
    review_client,
    interval_seconds: float | None = None,
    extra_platform_registrations: list[PlatformSyncRegistration] | None = None,
    home_dir: Path | None = None,
) -> DaemonRuntimeBundle:
    config = _apply_env_overrides(config)
    daemon_interval_seconds = float(interval_seconds or config.runtime.daemon_interval_seconds)
    queue = LocalRunQueue()
    case_service = CaseService(session_factory)
    sync_metadata = SyncMetadataService(session_factory)
    recovery_service = RecoveryService(session_factory)
    memory_writer = None
    execution_bundle = _build_execution_bundle(config, secret_store, home_dir=home_dir)
    if execution_bundle.engine_name not in {
        ExecutionEngine.codex_cli,
        ExecutionEngine.copilot_cli,
        ExecutionEngine.claude_cli,
        ExecutionEngine.gemini_cli,
    }:
        raise RuntimeError(
            "personal-work-agent relay runtime supports CLI engines only; "
            f"configured={execution_bundle.engine_name.value}"
        )
    runtime_config_loader = _build_runtime_config_loader(static_config=config, secret_store=secret_store)
    _unused_reasoning_executor = execution_bundle.executor  # kept for future use
    if execution_bundle.engine_name is ExecutionEngine.codex_cli:
        codex_settings = config.engine.codex_cli
        _unused_reasoning_executor = CodexCliExecutor(
            command=codex_settings.command,
            profile=codex_settings.profile,
            ephemeral_fresh=True,
            reasoning_effort=None,
            env_overrides=(
                build_codex_env_overrides(home_dir, base_env={"RUST_LOG": "warn"})
                if home_dir is not None
                else {"RUST_LOG": "warn"}
            ),
        )

    graph_processor = None
    continuity_service = TopicContinuityService(
        session_factory=session_factory,
        lookback_minutes=config.review.topic_lookback_minutes,
    )

    slack_loop = _ReloadableLoop(
        config_loader=runtime_config_loader,
        build_loop=lambda latest_config: _build_slack_loop(
            config=latest_config,
            session_factory=session_factory,
            secret_store=secret_store,
            case_service=case_service,
            queue=queue,
            sync_metadata=sync_metadata,
            continuity_service=continuity_service,
        ),
    )
    gitlab_loop = _ReloadableLoop(
        config_loader=runtime_config_loader,
        build_loop=lambda latest_config: _build_gitlab_loop(
            config=latest_config,
            session_factory=session_factory,
            secret_store=secret_store,
            case_service=case_service,
            queue=queue,
            sync_metadata=sync_metadata,
            continuity_service=continuity_service,
        ),
    )
    jira_loop = _ReloadableLoop(
        config_loader=runtime_config_loader,
        build_loop=lambda latest_config: _build_jira_loop(
            config=latest_config,
            session_factory=session_factory,
            secret_store=secret_store,
            case_service=case_service,
            queue=queue,
            sync_metadata=sync_metadata,
            continuity_service=continuity_service,
        ),
    )
    confluence_loop = _ReloadableLoop(
        config_loader=runtime_config_loader,
        build_loop=lambda latest_config: _build_confluence_loop(
            config=latest_config,
            session_factory=session_factory,
            secret_store=secret_store,
            case_service=case_service,
            queue=queue,
            sync_metadata=sync_metadata,
            continuity_service=continuity_service,
        ),
    )
    notion_loop = _ReloadableLoop(
        config_loader=runtime_config_loader,
        build_loop=lambda latest_config: _build_notion_loop(
            config=latest_config,
            session_factory=session_factory,
            secret_store=secret_store,
            case_service=case_service,
            queue=queue,
            sync_metadata=sync_metadata,
            continuity_service=continuity_service,
        ),
    )
    asana_loop = _ReloadableLoop(
        config_loader=runtime_config_loader,
        build_loop=lambda latest_config: _build_asana_loop(
            config=latest_config,
            session_factory=session_factory,
            secret_store=secret_store,
            case_service=case_service,
            queue=queue,
            sync_metadata=sync_metadata,
            continuity_service=continuity_service,
        ),
    )
    linear_loop = _ReloadableLoop(
        config_loader=runtime_config_loader,
        build_loop=lambda latest_config: _build_linear_loop(
            config=latest_config,
            session_factory=session_factory,
            secret_store=secret_store,
            case_service=case_service,
            queue=queue,
            sync_metadata=sync_metadata,
            continuity_service=continuity_service,
        ),
    )
    gmail_loop = _ReloadableLoop(
        config_loader=runtime_config_loader,
        build_loop=lambda latest_config: _build_gmail_loop(
            config=latest_config,
            session_factory=session_factory,
            secret_store=secret_store,
            case_service=case_service,
            queue=queue,
            sync_metadata=sync_metadata,
            continuity_service=continuity_service,
        ),
    )
    google_calendar_loop = _ReloadableLoop(
        config_loader=runtime_config_loader,
        build_loop=lambda latest_config: _build_google_calendar_loop(
            config=latest_config,
            session_factory=session_factory,
            secret_store=secret_store,
            case_service=case_service,
            queue=queue,
            sync_metadata=sync_metadata,
            continuity_service=continuity_service,
        ),
    )
    google_drive_loop = _ReloadableLoop(
        config_loader=runtime_config_loader,
        build_loop=lambda latest_config: _build_google_drive_loop(
            config=latest_config,
            session_factory=session_factory,
            secret_store=secret_store,
            case_service=case_service,
            queue=queue,
            sync_metadata=sync_metadata,
            continuity_service=continuity_service,
        ),
    )
    zendesk_loop = _ReloadableLoop(
        config_loader=runtime_config_loader,
        build_loop=lambda latest_config: _build_zendesk_loop(
            config=latest_config,
            session_factory=session_factory,
            secret_store=secret_store,
            case_service=case_service,
            queue=queue,
            sync_metadata=sync_metadata,
            continuity_service=continuity_service,
        ),
    )
    discord_loop = _ReloadableLoop(
        config_loader=runtime_config_loader,
        build_loop=lambda latest_config: _build_discord_loop(
            config=latest_config,
            session_factory=session_factory,
            secret_store=secret_store,
            case_service=case_service,
            queue=queue,
            sync_metadata=sync_metadata,
            continuity_service=continuity_service,
        ),
    )
    microsoft_teams_loop = _ReloadableLoop(
        config_loader=runtime_config_loader,
        build_loop=lambda latest_config: _build_microsoft_teams_loop(
            config=latest_config,
            session_factory=session_factory,
            secret_store=secret_store,
            case_service=case_service,
            queue=queue,
            sync_metadata=sync_metadata,
            continuity_service=continuity_service,
        ),
    )
    extra_platform_loops: dict[str, object] = {}
    for registration in extra_platform_registrations or []:
        extra_platform_loops[registration.platform_key] = _ReloadableLoop(
            config_loader=runtime_config_loader,
            build_loop=lambda latest_config, registration=registration: registration.build_loop(
                config=latest_config,
                session_factory=session_factory,
                secret_store=secret_store,
                case_service=case_service,
                queue=queue,
                sync_metadata=sync_metadata,
                continuity_service=continuity_service,
            ),
        )
    review_runtime = build_review_sync_runtime(
        session_factory=session_factory,
        review_client=review_client,
        queue=queue,
        memory_writer=memory_writer,
        graph_processor=graph_processor,
    ) or _NoopReviewRuntime()
    agent_socket_transport = build_agent_socket_transport(
        review_client,
        initial_retry_delay_seconds=daemon_interval_seconds,
    )
    if agent_socket_transport is not None and hasattr(review_client, "set_socket_transport"):
        review_client.set_socket_transport(agent_socket_transport)
    outbound_processor = OutboundQueueProcessor(
        session_factory=session_factory,
        slack_sender=SlackOutboundSender(),
        token_resolver=CredentialTokenResolver(session_factory=session_factory, secret_store=secret_store),
        memory_writer=memory_writer,
        review_client=review_client,
    )
    relay_request_router = (
        build_request_router(
            session_factory=session_factory,
            sync_api=review_client,
            executor=execution_bundle.executor,
            model=execution_bundle.model,
            outbound_processor=outbound_processor,
        )
        if review_client is not None
        else None
    )
    pending_runtime = build_agent_pending_sync_runtime(
        session_factory=session_factory,
        review_client=review_client,
        request_router=relay_request_router,
        execution_engine=execution_bundle.engine_name,
        socket_transport=agent_socket_transport,
    ) or _NoopAgentPendingRuntime()
    onboarding_runtime = build_agent_onboarding_sync_runtime(
        session_factory=session_factory,
        review_client=review_client,
        secret_store=secret_store,
        socket_transport=agent_socket_transport,
    ) or _NoopAgentOnboardingRuntime()
    if agent_socket_transport is not None:
        if hasattr(getattr(pending_runtime, "sync_service", None), "process_remote_item"):
            agent_socket_transport.set_pending_handler(pending_runtime.sync_service.process_remote_item)
        if hasattr(getattr(onboarding_runtime, "sync_service", None), "process_remote_item"):
            agent_socket_transport.set_onboarding_handler(onboarding_runtime.sync_service.process_remote_item)
        # MVP2: agent_definition.push → LocalAgentStore에 저장
        from workagent.services.local_agent_store import LocalAgentStore

        _agent_store = LocalAgentStore(agents_dir=Path.home() / ".personal-work-agent" / "agents")

        async def _handle_agent_definition_push(data: dict) -> None:
            _agent_store.save_agent(
                agent_id=data.get("agentId", ""),
                agent_prompt=data.get("agentPrompt", ""),
                skills=data.get("skills", []),
                version=data.get("version", 0),
                content_hash=data.get("contentHash", ""),
            )

        agent_socket_transport.set_agent_definition_push_handler(_handle_agent_definition_push)
    scheduler_runtime = SchedulerRuntime(
        SqlAlchemySchedulerJobRepository(session_factory),
        launcher=ScheduledCaseLauncher(
            case_service=case_service,
            queue=queue,
            channel_store=SqlAlchemyDefaultSlackChannelStore(session_factory),
        ),
    )
    worker_runtime = LocalWorkerRuntime(
        queue=queue,
        processor=None,
        max_concurrency=5,
    )
    app_runtime = AppRuntime(
        slack_loop=slack_loop,
        gitlab_loop=gitlab_loop,
        jira_loop=jira_loop,
        confluence_loop=confluence_loop,
        notion_loop=notion_loop,
        asana_loop=asana_loop,
        linear_loop=linear_loop,
        gmail_loop=gmail_loop,
        google_calendar_loop=google_calendar_loop,
        google_drive_loop=google_drive_loop,
        zendesk_loop=zendesk_loop,
        discord_loop=discord_loop,
        microsoft_teams_loop=microsoft_teams_loop,
        extra_platform_loops=extra_platform_loops,
        review_runtime=review_runtime,
        scheduler_runtime=scheduler_runtime,
        worker_runtime=worker_runtime,
        outbound_processor=outbound_processor,
        pending_runtime=pending_runtime,
        onboarding_runtime=onboarding_runtime,
    )
    runtime_loop = WorkAgentRuntimeLoop(
        pending_sync=pending_runtime,
        onboarding_sync=onboarding_runtime,
        request_router=relay_request_router or _NoopRequestRouter(),
    )
    review_push_service = (
        ReviewPushService(
            session_factory,
            review_client,
            bot_user_id=config.review.bot_sender_user_id,
            bot_user_nickname=config.review.bot_sender_user_nickname,
            memory_writer=memory_writer,
        )
        if review_client is not None
        else _NoopReviewPushService()
    )
    tick_runtime = DaemonTickRuntime(
        runtime_loop=runtime_loop,
        review_push_service=review_push_service,
    )
    daemon_loop = PeriodicDaemonLoop(
        tick_runtime=tick_runtime,
        interval_seconds=daemon_interval_seconds,
    )
    return DaemonRuntimeBundle(
        app_runtime=app_runtime,
        runtime_loop=runtime_loop,
        review_push_service=review_push_service,
        outbound_processor=outbound_processor,
        tick_runtime=tick_runtime,
        daemon_loop=daemon_loop,
        recovery_service=recovery_service,
        queue=queue,
    )


def _build_memory_writer(session_factory: async_sessionmaker[AsyncSession]) -> None:
    return None


def _build_memory_retrieval(session_factory: async_sessionmaker[AsyncSession]) -> None:
    return None


def _build_runtime_config_loader(*, static_config: AppConfig, secret_store: SecretStore) -> Callable[[], AppConfig]:
    config_store = (
        ConfigStore(default_config_paths(secret_store.path.parent))
        if isinstance(secret_store, FileSecretStore)
        else None
    )

    def _load() -> AppConfig:
        if config_store is None:
            return static_config
        return config_store.load() or static_config

    return _load


def _build_direct_tool_service_from_config(
    *,
    config: AppConfig,
    secret_store: SecretStore,
    session_factory: async_sessionmaker[AsyncSession],
) -> ToolShimService | None:
    tools = []
    slack_connector = config.connectors.get(Platform.SLACK.value)
    if slack_connector is not None and slack_connector.secret_key:
        slack_token = str(secret_store.get(slack_connector.secret_key) or "").strip()
        if slack_token:
            tools.append(
                SlackSearchTool(
                    client=SlackApiClient(base_url=slack_connector.base_url),
                    token=slack_token,
                )
            )
    gitlab_connector = config.connectors.get(Platform.GITLAB.value)
    if gitlab_connector is not None and gitlab_connector.secret_key:
        gitlab_token = str(secret_store.get(gitlab_connector.secret_key) or "").strip()
        if gitlab_token:
            tools.append(
                GitLabReadTool(
                    client=GitLabApiClient(
                        base_url=gitlab_connector.base_url,
                        private_token=gitlab_token,
                    )
                )
            )
    jira_connector = config.connectors.get(Platform.JIRA.value)
    if jira_connector is not None and jira_connector.secret_key:
        jira_token = str(secret_store.get(jira_connector.secret_key) or "").strip()
        if jira_token:
            tools.append(
                JiraReadTool(
                    client=JiraApiClient(
                        base_url=jira_connector.api_base_url or jira_connector.base_url,
                        api_token=jira_token,
                    ),
                    expected_base_url=jira_connector.base_url,
                )
            )
    confluence_connector = config.connectors.get(Platform.CONFLUENCE.value)
    if confluence_connector is not None and confluence_connector.secret_key:
        confluence_token = str(secret_store.get(confluence_connector.secret_key) or "").strip()
        if confluence_token:
            tools.append(
                ConfluenceReadTool(
                    client=ConfluenceApiClient(
                        base_url=confluence_connector.api_base_url or confluence_connector.base_url,
                        api_token=confluence_token,
                    ),
                    expected_base_url=confluence_connector.base_url,
                )
            )
    if not tools:
        return None
    return ToolShimService(
        tools=tools,
        audit_service=AuditService(session_factory),
    )


def _build_direct_tool_service(
    *,
    config_loader: Callable[[], AppConfig],
    secret_store: SecretStore,
    session_factory: async_sessionmaker[AsyncSession],
) -> DynamicToolShimService:
    return DynamicToolShimService(
        service_factory=lambda: _build_direct_tool_service_from_config(
            config=config_loader(),
            secret_store=secret_store,
            session_factory=session_factory,
        )
    )


def _build_slack_loop(
    *,
    config: AppConfig,
    session_factory: async_sessionmaker[AsyncSession],
    secret_store: SecretStore,
    case_service: CaseService,
    queue,
    sync_metadata: SyncMetadataService,
    continuity_service: TopicContinuityService,
):
    connector, token = _resolve_connector(
        config=config,
        platform=Platform.SLACK,
        secret_store=secret_store,
    )
    if connector is None or token is None:
        return _NoopSlackSyncLoop()
    slack_watch_profile = _resolve_watch_profile(config, Platform.SLACK)
    client = SlackApiClient(base_url=connector.base_url)
    return _ManagedSlackSyncLoop(
        runtime=SlackSyncLoop(
            client=client,
            token=token,
            cursor_store_factory=lambda channel_id: SlackChannelCursorStore(
                session_factory=session_factory,
                channel_id=channel_id,
            ),
            ingest_service=None,
            queue=queue,
            limit=config.slack_sync.history_limit,
            target_mode=_slack_target_mode(slack_watch_profile, config),
            selected_channel_ids=_slack_selected_channel_ids(slack_watch_profile, config),
            optional_keywords=list(slack_watch_profile.optional_keywords) if slack_watch_profile is not None else [],
        ),
        sync_metadata=sync_metadata,
        poll_interval_seconds=config.slack_sync.poll_interval_seconds,
    )


def _build_gitlab_loop(
    *,
    config: AppConfig,
    session_factory: async_sessionmaker[AsyncSession],
    secret_store: SecretStore,
    case_service: CaseService,
    queue,
    sync_metadata: SyncMetadataService,
    continuity_service: TopicContinuityService,
):
    connector, token = _resolve_connector(
        config=config,
        platform=Platform.GITLAB,
        secret_store=secret_store,
    )
    if connector is None or token is None:
        return _NoopGitLabSyncLoop()
    gitlab_watch_profile = _resolve_watch_profile(config, Platform.GITLAB)
    sync_service = GitLabSyncService(
        client=GitLabApiClient(base_url=connector.base_url, private_token=token),
        cursor_store=SqlAlchemyCursorStore(
            session_factory=session_factory,
            connector_type=ConnectorType.gitlab,
        ),
        limit=config.gitlab_sync.activity_limit,
        lookback_window_minutes=config.gitlab_sync.lookback_window_minutes,
        project_scope_prefixes=_gitlab_project_scope_prefixes(gitlab_watch_profile),
        optional_keywords=list(gitlab_watch_profile.optional_keywords) if gitlab_watch_profile is not None else [],
    )
    return _ManagedGitLabSyncLoop(
        runtime=GitLabSyncLoop(
            sync_service=sync_service,
            ingest_service=None,
            queue=queue,
        ),
        sync_metadata=sync_metadata,
        poll_interval_seconds=config.gitlab_sync.poll_interval_seconds,
    )


def _build_jira_loop(
    *,
    config: AppConfig,
    session_factory: async_sessionmaker[AsyncSession],
    secret_store: SecretStore,
    case_service: CaseService,
    queue,
    sync_metadata: SyncMetadataService,
    continuity_service: TopicContinuityService,
):
    connector, token = _resolve_connector(
        config=config,
        platform=Platform.JIRA,
        secret_store=secret_store,
    )
    jira_watch_profile = _resolve_watch_profile(config, Platform.JIRA)
    if connector is None or token is None or jira_watch_profile is None:
        return _NoopJiraSyncLoop()
    sync_service = JiraSyncService(
        client=JiraApiClient(base_url=connector.api_base_url or connector.base_url, api_token=token),
        cursor_store=SqlAlchemyCursorStore(
            session_factory=session_factory,
            connector_type=ConnectorType.jira,
        ),
        limit=20,
        lookback_window_minutes=_profile_lookback_window(jira_watch_profile, default_minutes=120),
        preset=jira_watch_profile.preset.value,
        project_keys=_jira_project_keys(jira_watch_profile),
        optional_keywords=list(jira_watch_profile.optional_keywords),
        optional_jql=_jira_optional_jql(jira_watch_profile),
    )
    return _ManagedJiraSyncLoop(
        runtime=_JiraSyncLoopRuntime(
            sync_service=sync_service,
            ingest_service=JiraIngestService(
                case_service=QueueingCaseService(case_service, continuity_service=continuity_service),
                seen_store=JiraSeenStore(session_factory),
                jira_base_url=connector.base_url,
            ),
            queue=queue,
        ),
        sync_metadata=sync_metadata,
        poll_interval_seconds=_profile_poll_interval(jira_watch_profile, default_seconds=60),
    )


def _build_confluence_loop(
    *,
    config: AppConfig,
    session_factory: async_sessionmaker[AsyncSession],
    secret_store: SecretStore,
    case_service: CaseService,
    queue,
    sync_metadata: SyncMetadataService,
    continuity_service: TopicContinuityService,
):
    connector, token = _resolve_connector(
        config=config,
        platform=Platform.CONFLUENCE,
        secret_store=secret_store,
    )
    confluence_watch_profile = _resolve_watch_profile(config, Platform.CONFLUENCE)
    if connector is None or token is None or confluence_watch_profile is None:
        return _NoopConfluenceSyncLoop()
    sync_service = ConfluenceSyncService(
        client=ConfluenceApiClient(base_url=connector.api_base_url or connector.base_url, api_token=token),
        cursor_store=SqlAlchemyCursorStore(
            session_factory=session_factory,
            connector_type=ConnectorType.confluence,
        ),
        limit=20,
        lookback_window_minutes=_profile_lookback_window(confluence_watch_profile, default_minutes=120),
        preset=confluence_watch_profile.preset.value,
        space_keys=_confluence_space_keys(confluence_watch_profile),
        optional_keywords=list(confluence_watch_profile.optional_keywords),
        optional_cql=_confluence_optional_cql(confluence_watch_profile),
    )
    return _ManagedConfluenceSyncLoop(
        runtime=_ConfluenceSyncLoopRuntime(
            sync_service=sync_service,
            ingest_service=ConfluenceIngestService(
                case_service=QueueingCaseService(case_service, continuity_service=continuity_service),
                seen_store=ConfluenceSeenStore(session_factory),
                confluence_base_url=connector.base_url,
            ),
            queue=queue,
        ),
        sync_metadata=sync_metadata,
        poll_interval_seconds=_profile_poll_interval(confluence_watch_profile, default_seconds=60),
    )


def _build_notion_loop(
    *,
    config: AppConfig,
    session_factory: async_sessionmaker[AsyncSession],
    secret_store: SecretStore,
    case_service: CaseService,
    queue,
    sync_metadata: SyncMetadataService,
    continuity_service: TopicContinuityService,
):
    connector, token = _resolve_connector(
        config=config,
        platform=Platform.NOTION,
        secret_store=secret_store,
    )
    notion_watch_profile = _resolve_watch_profile(config, Platform.NOTION)
    if connector is None or token is None or notion_watch_profile is None:
        return _NoopNotionSyncLoop()
    sync_service = NotionSyncService(
        client=NotionApiClient(base_url=connector.base_url, api_token=token),
        cursor_store=SqlAlchemyCursorStore(
            session_factory=session_factory,
            connector_type=ConnectorType.notion,
        ),
        limit=20,
        lookback_window_minutes=_profile_lookback_window(notion_watch_profile, default_minutes=120),
        preset=notion_watch_profile.preset.value,
        workspace_ids=_notion_workspace_ids(notion_watch_profile),
        optional_keywords=list(notion_watch_profile.optional_keywords),
        optional_query=_notion_optional_query(notion_watch_profile),
    )
    return _ManagedNotionSyncLoop(
        runtime=_NotionSyncLoopRuntime(
            sync_service=sync_service,
            ingest_service=NotionIngestService(
                case_service=QueueingCaseService(case_service, continuity_service=continuity_service),
                seen_store=NotionSeenStore(session_factory),
            ),
            queue=queue,
        ),
        sync_metadata=sync_metadata,
        poll_interval_seconds=_profile_poll_interval(notion_watch_profile, default_seconds=60),
    )


def _build_asana_loop(
    *,
    config: AppConfig,
    session_factory: async_sessionmaker[AsyncSession],
    secret_store: SecretStore,
    case_service: CaseService,
    queue,
    sync_metadata: SyncMetadataService,
    continuity_service: TopicContinuityService,
):
    connector, token = _resolve_connector(
        config=config,
        platform=Platform.ASANA,
        secret_store=secret_store,
    )
    asana_watch_profile = _resolve_watch_profile(config, Platform.ASANA)
    if connector is None or token is None or asana_watch_profile is None:
        return _NoopAsanaSyncLoop()
    sync_service = AsanaSyncService(
        client=AsanaApiClient(base_url=connector.base_url, api_token=token),
        cursor_store=SqlAlchemyCursorStore(
            session_factory=session_factory,
            connector_type=ConnectorType.asana,
        ),
        limit=20,
        lookback_window_minutes=_profile_lookback_window(asana_watch_profile, default_minutes=120),
        preset=asana_watch_profile.preset.value,
        workspace_ids=_asana_workspace_ids(asana_watch_profile),
        optional_keywords=list(asana_watch_profile.optional_keywords),
        optional_query=_asana_optional_query(asana_watch_profile),
    )
    return _ManagedAsanaSyncLoop(
        runtime=_AsanaSyncLoopRuntime(
            sync_service=sync_service,
            ingest_service=AsanaIngestService(
                case_service=QueueingCaseService(case_service, continuity_service=continuity_service),
                seen_store=AsanaSeenStore(session_factory),
            ),
            queue=queue,
        ),
        sync_metadata=sync_metadata,
        poll_interval_seconds=_profile_poll_interval(asana_watch_profile, default_seconds=60),
    )


def _build_linear_loop(
    *,
    config: AppConfig,
    session_factory: async_sessionmaker[AsyncSession],
    secret_store: SecretStore,
    case_service: CaseService,
    queue,
    sync_metadata: SyncMetadataService,
    continuity_service: TopicContinuityService,
):
    connector, token = _resolve_connector(
        config=config,
        platform=Platform.LINEAR,
        secret_store=secret_store,
    )
    linear_watch_profile = _resolve_watch_profile(config, Platform.LINEAR)
    if connector is None or token is None or linear_watch_profile is None:
        return _NoopLinearSyncLoop()
    sync_service = LinearSyncService(
        client=LinearApiClient(base_url=connector.base_url, api_token=token),
        cursor_store=SqlAlchemyCursorStore(
            session_factory=session_factory,
            connector_type=ConnectorType.linear,
        ),
        limit=20,
        lookback_window_minutes=_profile_lookback_window(linear_watch_profile, default_minutes=120),
        preset=linear_watch_profile.preset.value,
        team_ids=_linear_team_ids(linear_watch_profile),
        optional_keywords=list(linear_watch_profile.optional_keywords),
        optional_query=_linear_optional_query(linear_watch_profile),
    )
    return _ManagedLinearSyncLoop(
        runtime=_LinearSyncLoopRuntime(
            sync_service=sync_service,
            ingest_service=LinearIngestService(
                case_service=QueueingCaseService(case_service, continuity_service=continuity_service),
                seen_store=LinearSeenStore(session_factory),
            ),
            queue=queue,
        ),
        sync_metadata=sync_metadata,
        poll_interval_seconds=_profile_poll_interval(linear_watch_profile, default_seconds=60),
    )


def _build_gmail_loop(
    *,
    config: AppConfig,
    session_factory: async_sessionmaker[AsyncSession],
    secret_store: SecretStore,
    case_service: CaseService,
    queue,
    sync_metadata: SyncMetadataService,
    continuity_service: TopicContinuityService,
):
    connector, token = _resolve_connector(
        config=config,
        platform=Platform.GMAIL,
        secret_store=secret_store,
    )
    gmail_watch_profile = _resolve_watch_profile(config, Platform.GMAIL)
    if connector is None or token is None or gmail_watch_profile is None:
        return _NoopGmailSyncLoop()
    sync_service = GmailSyncService(
        client=GmailApiClient(base_url=connector.base_url, api_token=token),
        cursor_store=SqlAlchemyCursorStore(
            session_factory=session_factory,
            connector_type=ConnectorType.gmail,
        ),
        limit=20,
        lookback_window_minutes=_profile_lookback_window(gmail_watch_profile, default_minutes=120),
        preset=gmail_watch_profile.preset.value,
        label_ids=_gmail_label_ids(gmail_watch_profile),
        optional_keywords=list(gmail_watch_profile.optional_keywords),
        optional_query=_gmail_optional_query(gmail_watch_profile),
    )
    return _ManagedGmailSyncLoop(
        runtime=_GmailSyncLoopRuntime(
            sync_service=sync_service,
            ingest_service=GmailIngestService(
                case_service=QueueingCaseService(case_service, continuity_service=continuity_service),
                seen_store=GmailSeenStore(session_factory),
            ),
            queue=queue,
        ),
        sync_metadata=sync_metadata,
        poll_interval_seconds=_profile_poll_interval(gmail_watch_profile, default_seconds=60),
    )


def _build_google_calendar_loop(
    *,
    config: AppConfig,
    session_factory: async_sessionmaker[AsyncSession],
    secret_store: SecretStore,
    case_service: CaseService,
    queue,
    sync_metadata: SyncMetadataService,
    continuity_service: TopicContinuityService,
):
    connector, token = _resolve_connector(
        config=config,
        platform=Platform.GOOGLE_CALENDAR,
        secret_store=secret_store,
    )
    google_calendar_watch_profile = _resolve_watch_profile(config, Platform.GOOGLE_CALENDAR)
    if connector is None or token is None or google_calendar_watch_profile is None:
        return _NoopGoogleCalendarSyncLoop()
    sync_service = GoogleCalendarSyncService(
        client=GoogleCalendarApiClient(base_url=connector.base_url, api_token=token),
        cursor_store=SqlAlchemyCursorStore(
            session_factory=session_factory,
            connector_type=ConnectorType.google_calendar,
        ),
        limit=20,
        lookback_window_minutes=_profile_lookback_window(google_calendar_watch_profile, default_minutes=120),
        preset=google_calendar_watch_profile.preset.value,
        calendar_ids=_google_calendar_ids(google_calendar_watch_profile),
        optional_keywords=list(google_calendar_watch_profile.optional_keywords),
        optional_query=_google_calendar_optional_query(google_calendar_watch_profile),
    )
    return _ManagedGoogleCalendarSyncLoop(
        runtime=_GoogleCalendarSyncLoopRuntime(
            sync_service=sync_service,
            ingest_service=GoogleCalendarIngestService(
                case_service=QueueingCaseService(case_service, continuity_service=continuity_service),
                seen_store=GoogleCalendarSeenStore(session_factory),
            ),
            queue=queue,
        ),
        sync_metadata=sync_metadata,
        poll_interval_seconds=_profile_poll_interval(google_calendar_watch_profile, default_seconds=60),
    )


def _build_google_drive_loop(
    *,
    config: AppConfig,
    session_factory: async_sessionmaker[AsyncSession],
    secret_store: SecretStore,
    case_service: CaseService,
    queue,
    sync_metadata: SyncMetadataService,
    continuity_service: TopicContinuityService,
):
    connector, token = _resolve_connector(
        config=config,
        platform=Platform.GOOGLE_DRIVE,
        secret_store=secret_store,
    )
    google_drive_watch_profile = _resolve_watch_profile(config, Platform.GOOGLE_DRIVE)
    if connector is None or token is None or google_drive_watch_profile is None:
        return _NoopGoogleDriveSyncLoop()
    sync_service = GoogleDriveSyncService(
        client=GoogleDriveApiClient(base_url=connector.base_url, api_token=token),
        cursor_store=SqlAlchemyCursorStore(
            session_factory=session_factory,
            connector_type=ConnectorType.google_drive,
        ),
        limit=20,
        lookback_window_minutes=_profile_lookback_window(google_drive_watch_profile, default_minutes=120),
        preset=google_drive_watch_profile.preset.value,
        drive_ids=_google_drive_ids(google_drive_watch_profile),
        optional_keywords=list(google_drive_watch_profile.optional_keywords),
        optional_query=_google_drive_optional_query(google_drive_watch_profile),
    )
    return _ManagedGoogleDriveSyncLoop(
        runtime=_GoogleDriveSyncLoopRuntime(
            sync_service=sync_service,
            ingest_service=GoogleDriveIngestService(
                case_service=QueueingCaseService(case_service, continuity_service=continuity_service),
                seen_store=GoogleDriveSeenStore(session_factory),
            ),
            queue=queue,
        ),
        sync_metadata=sync_metadata,
        poll_interval_seconds=_profile_poll_interval(google_drive_watch_profile, default_seconds=60),
    )


def _build_zendesk_loop(
    *,
    config: AppConfig,
    session_factory: async_sessionmaker[AsyncSession],
    secret_store: SecretStore,
    case_service: CaseService,
    queue,
    sync_metadata: SyncMetadataService,
    continuity_service: TopicContinuityService,
):
    connector, token = _resolve_connector(
        config=config,
        platform=Platform.ZENDESK,
        secret_store=secret_store,
    )
    zendesk_watch_profile = _resolve_watch_profile(config, Platform.ZENDESK)
    if connector is None or token is None or zendesk_watch_profile is None:
        return _NoopZendeskSyncLoop()
    sync_service = ZendeskSyncService(
        client=ZendeskApiClient(base_url=connector.base_url, api_token=token),
        cursor_store=SqlAlchemyCursorStore(
            session_factory=session_factory,
            connector_type=ConnectorType.zendesk,
        ),
        limit=20,
        lookback_window_minutes=_profile_lookback_window(zendesk_watch_profile, default_minutes=120),
        preset=zendesk_watch_profile.preset.value,
        view_ids=_zendesk_view_ids(zendesk_watch_profile),
        optional_keywords=list(zendesk_watch_profile.optional_keywords),
        optional_query=_zendesk_optional_query(zendesk_watch_profile),
    )
    return _ManagedZendeskSyncLoop(
        runtime=_ZendeskSyncLoopRuntime(
            sync_service=sync_service,
            ingest_service=ZendeskIngestService(
                case_service=QueueingCaseService(case_service, continuity_service=continuity_service),
                seen_store=ZendeskSeenStore(session_factory),
            ),
            queue=queue,
        ),
        sync_metadata=sync_metadata,
        poll_interval_seconds=_profile_poll_interval(zendesk_watch_profile, default_seconds=60),
    )


def _build_discord_loop(
    *,
    config: AppConfig,
    session_factory: async_sessionmaker[AsyncSession],
    secret_store: SecretStore,
    case_service: CaseService,
    queue,
    sync_metadata: SyncMetadataService,
    continuity_service: TopicContinuityService,
):
    connector, token = _resolve_connector(
        config=config,
        platform=Platform.DISCORD,
        secret_store=secret_store,
    )
    discord_watch_profile = _resolve_watch_profile(config, Platform.DISCORD)
    if connector is None or token is None or discord_watch_profile is None:
        return _NoopDiscordSyncLoop()
    sync_service = DiscordSyncService(
        client=DiscordApiClient(base_url=connector.base_url, api_token=token),
        cursor_store=SqlAlchemyCursorStore(
            session_factory=session_factory,
            connector_type=ConnectorType.discord,
        ),
        limit=20,
        lookback_window_minutes=_profile_lookback_window(discord_watch_profile, default_minutes=120),
        preset=discord_watch_profile.preset.value,
        guild_ids=_discord_guild_ids(discord_watch_profile),
        optional_keywords=list(discord_watch_profile.optional_keywords),
        optional_query=_discord_optional_query(discord_watch_profile),
    )
    return _ManagedDiscordSyncLoop(
        runtime=_DiscordSyncLoopRuntime(
            sync_service=sync_service,
            ingest_service=DiscordIngestService(
                case_service=QueueingCaseService(case_service, continuity_service=continuity_service),
                seen_store=DiscordSeenStore(session_factory),
            ),
            queue=queue,
        ),
        sync_metadata=sync_metadata,
        poll_interval_seconds=_profile_poll_interval(discord_watch_profile, default_seconds=60),
    )


def _build_microsoft_teams_loop(
    *,
    config: AppConfig,
    session_factory: async_sessionmaker[AsyncSession],
    secret_store: SecretStore,
    case_service: CaseService,
    queue,
    sync_metadata: SyncMetadataService,
    continuity_service: TopicContinuityService,
):
    connector, token = _resolve_connector(
        config=config,
        platform=Platform.MICROSOFT_TEAMS,
        secret_store=secret_store,
    )
    microsoft_teams_watch_profile = _resolve_watch_profile(config, Platform.MICROSOFT_TEAMS)
    if connector is None or token is None or microsoft_teams_watch_profile is None:
        return _NoopMicrosoftTeamsSyncLoop()
    sync_service = MicrosoftTeamsSyncService(
        client=MicrosoftTeamsApiClient(base_url=connector.base_url, api_token=token),
        cursor_store=SqlAlchemyCursorStore(
            session_factory=session_factory,
            connector_type=ConnectorType.microsoft_teams,
        ),
        limit=20,
        lookback_window_minutes=_profile_lookback_window(microsoft_teams_watch_profile, default_minutes=120),
        preset=microsoft_teams_watch_profile.preset.value,
        team_ids=_microsoft_teams_team_ids(microsoft_teams_watch_profile),
        optional_keywords=list(microsoft_teams_watch_profile.optional_keywords),
        optional_query=_microsoft_teams_optional_query(microsoft_teams_watch_profile),
    )
    return _ManagedMicrosoftTeamsSyncLoop(
        runtime=_MicrosoftTeamsSyncLoopRuntime(
            sync_service=sync_service,
            ingest_service=MicrosoftTeamsIngestService(
                case_service=QueueingCaseService(case_service, continuity_service=continuity_service),
                seen_store=MicrosoftTeamsSeenStore(session_factory),
            ),
            queue=queue,
        ),
        sync_metadata=sync_metadata,
        poll_interval_seconds=_profile_poll_interval(microsoft_teams_watch_profile, default_seconds=60),
    )


def _resolve_connector(
    *,
    config: AppConfig,
    platform: Platform,
    secret_store: SecretStore,
) -> tuple[ConnectorConfig | None, str | None]:
    connector = config.connectors.get(platform.value)
    if connector is None:
        return None, None
    token = secret_store.get(connector.secret_key) if connector.secret_key else None
    token = token.strip() if token else None
    if not token:
        return None, None
    return connector, token


def _resolve_watch_profile(config: AppConfig, platform: Platform) -> WatchProfile | None:
    profiles = config.watch_profiles.get(platform.value) or []
    for profile in profiles:
        if profile.enabled:
            return profile
    return None


def _slack_target_mode(profile: WatchProfile | None, config: AppConfig) -> SlackTargetMode:
    if profile is None:
        return config.slack_sync.target_mode
    if profile.preset == WatchProfilePreset.personal_inbox:
        return SlackTargetMode.dms_and_mentions
    if _slack_selected_channel_ids(profile, config):
        return SlackTargetMode.selected_channels
    return SlackTargetMode.dms_and_mentions


def _slack_selected_channel_ids(profile: WatchProfile | None, config: AppConfig) -> list[str]:
    if profile is None:
        return list(config.slack_sync.channel_ids)
    raw_scope = str(profile.scope.get("raw") or "").strip()
    return [item.strip() for item in raw_scope.split(",") if item.strip()]


def _gitlab_project_scope_prefixes(profile: WatchProfile | None) -> list[str]:
    if profile is None:
        return []
    return _scope_items(profile)


def _jira_project_keys(profile: WatchProfile | None) -> list[str]:
    if profile is None:
        return []
    return _scope_items(profile)


def _confluence_space_keys(profile: WatchProfile | None) -> list[str]:
    if profile is None:
        return []
    return _scope_items(profile)


def _jira_optional_jql(profile: WatchProfile | None) -> str | None:
    if profile is None:
        return None
    return str(profile.scope.get("jql") or "").strip() or None


def _confluence_optional_cql(profile: WatchProfile | None) -> str | None:
    if profile is None:
        return None
    return str(profile.scope.get("cql") or "").strip() or None


def _notion_workspace_ids(profile: WatchProfile | None) -> list[str]:
    if profile is None:
        return []
    workspace_ids = profile.scope.get("workspaceIds")
    if isinstance(workspace_ids, list):
        return [str(item).strip() for item in workspace_ids if str(item).strip()]
    return _scope_items(profile)


def _notion_optional_query(profile: WatchProfile | None) -> str | None:
    if profile is None:
        return None
    return str(profile.scope.get("query") or "").strip() or None


def _asana_workspace_ids(profile: WatchProfile | None) -> list[str]:
    if profile is None:
        return []
    workspace_ids = profile.scope.get("workspaceIds")
    if isinstance(workspace_ids, list):
        return [str(item).strip() for item in workspace_ids if str(item).strip()]
    return _scope_items(profile)


def _asana_optional_query(profile: WatchProfile | None) -> str | None:
    if profile is None:
        return None
    return str(profile.scope.get("query") or "").strip() or None


def _linear_team_ids(profile: WatchProfile | None) -> list[str]:
    if profile is None:
        return []
    team_ids = profile.scope.get("teamIds")
    if isinstance(team_ids, list):
        return [str(item).strip() for item in team_ids if str(item).strip()]
    return _scope_items(profile)


def _linear_optional_query(profile: WatchProfile | None) -> str | None:
    if profile is None:
        return None
    return str(profile.scope.get("query") or "").strip() or None


def _gmail_label_ids(profile: WatchProfile | None) -> list[str]:
    if profile is None:
        return []
    label_ids = profile.scope.get("labelIds")
    if isinstance(label_ids, list):
        return [str(item).strip() for item in label_ids if str(item).strip()]
    return _scope_items(profile)


def _gmail_optional_query(profile: WatchProfile | None) -> str | None:
    if profile is None:
        return None
    return str(profile.scope.get("query") or "").strip() or None


def _google_calendar_ids(profile: WatchProfile | None) -> list[str]:
    if profile is None:
        return []
    calendar_ids = profile.scope.get("calendarIds")
    if isinstance(calendar_ids, list):
        return [str(item).strip() for item in calendar_ids if str(item).strip()]
    return _scope_items(profile)


def _google_calendar_optional_query(profile: WatchProfile | None) -> str | None:
    if profile is None:
        return None
    return str(profile.scope.get("query") or "").strip() or None


def _google_drive_ids(profile: WatchProfile | None) -> list[str]:
    if profile is None:
        return []
    drive_ids = profile.scope.get("driveIds")
    if isinstance(drive_ids, list):
        return [str(item).strip() for item in drive_ids if str(item).strip()]
    return _scope_items(profile)


def _google_drive_optional_query(profile: WatchProfile | None) -> str | None:
    if profile is None:
        return None
    return str(profile.scope.get("query") or "").strip() or None


def _zendesk_view_ids(profile: WatchProfile | None) -> list[str]:
    if profile is None:
        return []
    view_ids = profile.scope.get("viewIds")
    if isinstance(view_ids, list):
        return [str(item).strip() for item in view_ids if str(item).strip()]
    return _scope_items(profile)


def _zendesk_optional_query(profile: WatchProfile | None) -> str | None:
    if profile is None:
        return None
    return str(profile.scope.get("query") or "").strip() or None


def _discord_guild_ids(profile: WatchProfile | None) -> list[str]:
    if profile is None:
        return []
    guild_ids = profile.scope.get("guildIds")
    if isinstance(guild_ids, list):
        return [str(item).strip() for item in guild_ids if str(item).strip()]
    return _scope_items(profile)


def _discord_optional_query(profile: WatchProfile | None) -> str | None:
    if profile is None:
        return None
    return str(profile.scope.get("query") or "").strip() or None


def _microsoft_teams_team_ids(profile: WatchProfile | None) -> list[str]:
    if profile is None:
        return []
    team_ids = profile.scope.get("teamIds")
    if isinstance(team_ids, list):
        return [str(item).strip() for item in team_ids if str(item).strip()]
    return _scope_items(profile)


def _microsoft_teams_optional_query(profile: WatchProfile | None) -> str | None:
    if profile is None:
        return None
    return str(profile.scope.get("query") or "").strip() or None


def _scope_items(profile: WatchProfile) -> list[str]:
    raw_scope = str(profile.scope.get("raw") or "").strip()
    return [item.strip() for item in raw_scope.split(",") if item.strip()]


def _profile_poll_interval(profile: WatchProfile | None, *, default_seconds: int) -> int:
    if profile is None:
        return default_seconds
    return int(profile.poll_interval or default_seconds)


def _profile_lookback_window(profile: WatchProfile | None, *, default_minutes: int) -> int:
    if profile is None:
        return default_minutes
    return int(profile.lookback_window or default_minutes)


def _build_skill_catalog(session_factory: async_sessionmaker[AsyncSession]) -> SkillCatalogService | None:
    bind = session_factory.kw.get("bind")
    if bind is None or bind.url.database is None:
        return None
    return SkillCatalogService(SkillCatalogPaths.default())
