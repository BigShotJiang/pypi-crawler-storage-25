from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class DaemonTickSummary:
    runtime_cycle_executed: bool
    pushed_case_count: int


class DaemonTickRuntime:
    def __init__(self, *, runtime_loop, review_push_service) -> None:  # noqa: ANN001
        self.runtime_loop = runtime_loop
        self.review_push_service = review_push_service

    async def run_once(self) -> DaemonTickSummary:
        await self.runtime_loop.run_cycle()
        pushed = await self.review_push_service.push_ready_cases()
        return DaemonTickSummary(
            runtime_cycle_executed=True,
            pushed_case_count=len(pushed),
        )
