from __future__ import annotations

import json
import logging
import os
import shlex
import subprocess
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Protocol

from workagent.executors.base import (
    CancelSignal,
    ExecutionCancelled,
    ExecutionFailureKind,
    NormalizedExecutionResult,
    render_prompt_from_request,
)
from workagent.executors.cli_base import CliSubprocessEngine

logger = logging.getLogger("workagent.executor.codex")
logger.propagate = True

@dataclass(frozen=True, slots=True)
class ExecutionOutput:
    thread_id: str | None
    assistant_text: str
    raw_stdout: str
    raw_stderr: str
    return_code: int


class CommandRunner(Protocol):
    def run(
        self,
        command: list[str],
        *,
        timeout_seconds: int,
        cancel_signal: CancelSignal | None = None,
        env: dict[str, str] | None = None,
        input_text: str | None = None,
        stdout_line_callback: Callable[[str], None] | None = None,
        stderr_line_callback: Callable[[str], None] | None = None,
    ) -> tuple[int, str, str]: ...


class SubprocessRunner:
    def run(
        self,
        command: list[str],
        *,
        timeout_seconds: int,
        cancel_signal: CancelSignal | None = None,
        env: dict[str, str] | None = None,
        input_text: str | None = None,
        stdout_line_callback: Callable[[str], None] | None = None,
        stderr_line_callback: Callable[[str], None] | None = None,
    ) -> tuple[int, str, str]:
        resolved_env = {**os.environ, **env} if env else None
        if cancel_signal is not None and cancel_signal.is_cancelled():
            raise ExecutionCancelled("codex execution cancelled")
        return self._run_with_streaming_callbacks(
            command,
            timeout_seconds=timeout_seconds,
            env=resolved_env,
            input_text=input_text,
            cancel_signal=cancel_signal,
            stdout_line_callback=stdout_line_callback,
            stderr_line_callback=stderr_line_callback,
        )

    def _run_with_streaming_callbacks(
        self,
        command: list[str],
        *,
        timeout_seconds: int,
        env: dict[str, str] | None,
        input_text: str | None,
        cancel_signal: CancelSignal | None,
        stdout_line_callback: Callable[[str], None] | None,
        stderr_line_callback: Callable[[str], None] | None,
    ) -> tuple[int, str, str]:
        process = subprocess.Popen(  # noqa: S603
            command,
            stdin=subprocess.PIPE if input_text is not None else None,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
            env=env,
        )
        stdout_chunks: list[str] = []
        stderr_chunks: list[str] = []
        stdout_stream = process.stdout
        stderr_stream = process.stderr
        stdout_thread = threading.Thread(
            target=_consume_stream_lines,
            args=(stdout_stream, stdout_chunks, stdout_line_callback),
            daemon=True,
        )
        stderr_thread = threading.Thread(
            target=_consume_stream_lines,
            args=(stderr_stream, stderr_chunks, stderr_line_callback),
            daemon=True,
        )
        stdin_thread = None
        if input_text is not None and process.stdin is not None:
            stdin_thread = threading.Thread(
                target=_write_process_stdin,
                args=(process.stdin, input_text),
                daemon=True,
            )
        stdout_thread.start()
        stderr_thread.start()
        if stdin_thread is not None:
            stdin_thread.start()
        deadline = time.monotonic() + timeout_seconds
        return_code: int | None = None
        try:
            while process.poll() is None:
                if cancel_signal is not None and cancel_signal.is_cancelled():
                    process.terminate()
                    try:
                        process.wait(timeout=1)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait(timeout=1)
                    raise ExecutionCancelled("codex execution cancelled")
                if time.monotonic() >= deadline:
                    process.terminate()
                    try:
                        process.wait(timeout=1)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait(timeout=1)
                    raise subprocess.TimeoutExpired(cmd=command, timeout=timeout_seconds)
                time.sleep(0.1)
            return_code = int(process.returncode or 0)
        finally:
            if stdin_thread is not None:
                stdin_thread.join(timeout=1)
            stdout_thread.join(timeout=1)
            stderr_thread.join(timeout=1)
            if process.poll() is None:
                process.terminate()
                process.wait(timeout=1)
        return return_code, "".join(stdout_chunks), "".join(stderr_chunks)


class CodexCliExecutor(CliSubprocessEngine):
    def __init__(
        self,
        *,
        command: str = "codex",
        profile: str | None = None,
        runner: CommandRunner | None = None,
        timeout_seconds: int = 600,
        ephemeral_fresh: bool = False,
        reasoning_effort: str | None = None,
        env_overrides: dict[str, str] | None = None,
    ) -> None:
        super().__init__(command=command, runner=runner or SubprocessRunner(), timeout_seconds=timeout_seconds)
        self.profile = profile
        self.ephemeral_fresh = ephemeral_fresh
        self.reasoning_effort = reasoning_effort
        self.env_overrides = dict(env_overrides or {})

    def build_fresh_command(
        self, *, model: str | None, prompt: str, reasoning_effort_override: str | None = None
    ) -> list[str]:
        command = [
            self.command,
            "exec",
            "--json",
            "--color",
            "never",
            "--sandbox",
            "danger-full-access",
            "--ask-for-approval",
            "never",
            "--skip-git-repo-check",
        ]
        if self.profile:
            command.extend(["--profile", self.profile])
        effective_effort = reasoning_effort_override or self.reasoning_effort
        if effective_effort:
            command.extend(["-c", f'model_reasoning_effort="{effective_effort}"'])
        if model:
            command.extend(["--model", model])
        if self.ephemeral_fresh:
            command.append("--ephemeral")
        command.append("-")
        return command

    def build_resume_command(self, *, thread_id: str, prompt: str | None = None) -> list[str]:
        command = [
            self.command,
            "exec",
            "resume",
            thread_id,
            "--color",
            "never",
            "--sandbox",
            "danger-full-access",
            "--skip-git-repo-check",
        ]
        if self.reasoning_effort:
            command.extend(["-c", f'model_reasoning_effort="{self.reasoning_effort}"'])
        if prompt:
            command.append("-")
        return command

    def run_fresh(
        self,
        *,
        model: str | None,
        prompt: str,
        cancel_signal: CancelSignal | None = None,
        reasoning_effort_override: str | None = None,
        execution_request=None,
    ) -> ExecutionOutput:
        effective_prompt = render_prompt_from_request(prompt=prompt, execution_request=execution_request)
        return self._run_and_parse(
            self.build_fresh_command(model=model, prompt=effective_prompt, reasoning_effort_override=reasoning_effort_override),
            cancel_signal=cancel_signal,
            input_text=effective_prompt,
        )

    def run_resume(
        self,
        *,
        thread_id: str,
        prompt: str | None = None,
        cancel_signal: CancelSignal | None = None,
        execution_request=None,
    ) -> ExecutionOutput:
        effective_prompt = render_prompt_from_request(prompt=prompt or "", execution_request=execution_request)
        return self._run_and_parse(
            self.build_resume_command(thread_id=thread_id, prompt=effective_prompt or None),
            cancel_signal=cancel_signal,
            input_text=effective_prompt or None,
        )

    def normalize_output(self, output: ExecutionOutput) -> NormalizedExecutionResult:
        draft = output.assistant_text.strip()
        summary = None
        for line in draft.splitlines():
            normalized = line.strip()
            if normalized:
                summary = normalized
                break
        return NormalizedExecutionResult(
            thread_id=output.thread_id,
            draft=draft,
            summary=summary,
            evidence_refs=[],
            raw_transcript=output.raw_stdout,
            clarification_question=_extract_clarification_question(output.raw_stdout),
        )

    def classify_failure(self, output: ExecutionOutput) -> ExecutionFailureKind:
        stderr = output.raw_stderr.lower()
        if "timeout" in stderr or "network" in stderr or "temporarily unavailable" in stderr:
            return ExecutionFailureKind.retryable
        if "permission denied" in stderr or "manual" in stderr or "auth" in stderr:
            return ExecutionFailureKind.manual_required
        return ExecutionFailureKind.fatal

    def _run_and_parse(
        self,
        command: list[str],
        *,
        cancel_signal: CancelSignal | None = None,
        input_text: str | None = None,
    ) -> ExecutionOutput:
        rendered_command = shlex.join(command)
        cmd_label = _truncate_for_log(rendered_command, limit=80)
        stderr_logger = _StreamedStderrLogger(rendered_command=cmd_label)
        keep_ignored_stderr = True
        logger.info("codex command started command=%s", _truncate_for_log(rendered_command, limit=4000))
        try:
            return_code, stdout, stderr = self.runner.run(
                command,
                timeout_seconds=self.timeout_seconds,
                cancel_signal=cancel_signal,
                env=self.env_overrides or None,
                input_text=input_text,
                stdout_line_callback=lambda line: self._log_stream_stdout_line(cmd_label, line),
                stderr_line_callback=stderr_logger.log_line,
            )
            keep_ignored_stderr = return_code != 0
        except ExecutionCancelled:
            logger.warning("codex command cancelled command=%s", _truncate_for_log(rendered_command, limit=4000))
            raise
        finally:
            stderr_logger.flush(keep_ignored=keep_ignored_stderr)
        stderr = _sanitize_codex_stderr(stderr, keep_ignored=keep_ignored_stderr)
        thread_id = None
        assistant_chunks: list[str] = []
        for raw_line in stdout.splitlines():
            line = raw_line.strip()
            if not line:
                continue
            try:
                payload = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(payload, dict):
                if isinstance(payload.get("thread_id"), str):
                    thread_id = payload["thread_id"]
                message = payload.get("message")
                if isinstance(message, dict) and payload.get("type") in {"assistant", "message"}:
                    content = message.get("content")
                    if isinstance(content, str):
                        assistant_chunks.append(content)
                if isinstance(payload.get("content"), str) and payload.get("type") in {"assistant", "message"}:
                    assistant_chunks.append(payload["content"])
                item = payload.get("item")
                if isinstance(item, dict) and payload.get("type") == "item.completed" and item.get("type") == "agent_message":
                    text = item.get("text")
                    if isinstance(text, str):
                        assistant_chunks.append(text)
        output = ExecutionOutput(
            thread_id=thread_id,
            assistant_text="\n".join(chunk for chunk in assistant_chunks if chunk).strip(),
            raw_stdout=stdout,
            raw_stderr=stderr,
            return_code=return_code,
        )
        logger.info(
            "codex command completed command=%s return_code=%s thread_id=%r assistant_text=%r stdout=%r stderr=%r",
            _truncate_for_log(rendered_command, limit=4000),
            output.return_code,
            output.thread_id,
            _truncate_for_log(output.assistant_text, limit=4000),
            _truncate_for_log(output.raw_stdout, limit=4000),
            _truncate_for_log(output.raw_stderr, limit=4000),
        )
        return output

    @staticmethod
    def _log_stream_stdout_line(rendered_command: str, raw_line: str) -> None:
        line = raw_line.rstrip()
        if not line:
            return
        logger.info(
            "codex command event command=%s line=%s",
            _truncate_for_log(rendered_command, limit=4000),
            _truncate_for_log(line, limit=4000),
        )

    @staticmethod
    def _log_stream_stderr_line(rendered_command: str, raw_line: str) -> None:
        line = raw_line.rstrip()
        if not line:
            return
        logger.warning(
            "codex command stderr command=%s line=%s",
            _truncate_for_log(rendered_command, limit=4000),
            _truncate_for_log(line, limit=4000),
        )


@dataclass(slots=True)
class _StreamedStderrLogger:
    rendered_command: str
    _seen_lines: set[str] = field(default_factory=set)
    _suppressed_counts: dict[str, int] = field(default_factory=dict)
    _ignored_seen_lines: set[str] = field(default_factory=set)
    _ignored_suppressed_counts: dict[str, int] = field(default_factory=dict)

    def log_line(self, raw_line: str) -> None:
        line = raw_line.rstrip()
        if not line:
            return
        if _is_ignorable_codex_stderr_line(line):
            if line in self._ignored_seen_lines:
                self._ignored_suppressed_counts[line] = self._ignored_suppressed_counts.get(line, 0) + 1
                return
            self._ignored_seen_lines.add(line)
            return
        if line in self._seen_lines:
            self._suppressed_counts[line] = self._suppressed_counts.get(line, 0) + 1
            return
        self._seen_lines.add(line)
        CodexCliExecutor._log_stream_stderr_line(self.rendered_command, line)

    def flush(self, *, keep_ignored: bool) -> None:
        if keep_ignored:
            for line in self._ignored_seen_lines:
                CodexCliExecutor._log_stream_stderr_line(self.rendered_command, line)
            self._flush_repeated_counts(self._ignored_suppressed_counts)
        self._flush_repeated_counts(self._suppressed_counts)

    def _flush_repeated_counts(self, counts: dict[str, int]) -> None:
        for line, count in counts.items():
            logger.warning(
                "codex command stderr repeated command=%s count=%s line=%s",
                _truncate_for_log(self.rendered_command, limit=4000),
                count,
                _truncate_for_log(line, limit=4000),
            )


def _sanitize_codex_stderr(stderr: str, *, keep_ignored: bool) -> str:
    if keep_ignored or not stderr:
        return stderr
    kept_lines = [
        raw_line
        for raw_line in stderr.splitlines(keepends=True)
        if not _is_ignorable_codex_stderr_line(raw_line.rstrip())
    ]
    return "".join(kept_lines)


def _is_ignorable_codex_stderr_line(line: str) -> bool:
    normalized = line.strip().lower()
    if not normalized:
        return False
    if "failed to refresh token" in normalized and "refresh token was already used" in normalized:
        return True
    return "refresh_token_reused" in normalized


def _consume_stream_lines(
    stream,
    chunks: list[str],
    callback: Callable[[str], None] | None,
) -> None:  # noqa: ANN001
    if stream is None:
        return
    try:
        for raw_line in iter(stream.readline, ""):
            if not raw_line:
                break
            chunks.append(raw_line)
            if callback is not None:
                callback(raw_line)
    finally:
        stream.close()


def _write_process_stdin(stream, input_text: str) -> None:  # noqa: ANN001
    try:
        stream.write(input_text)
        stream.flush()
    except BrokenPipeError:
        pass
    finally:
        stream.close()


def _truncate_for_log(value: str, *, limit: int) -> str:
    if len(value) <= limit:
        return value
    return f"{value[: limit - 3]}..."


def _extract_clarification_question(raw_stdout: str) -> str | None:
    for raw_line in raw_stdout.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        try:
            payload = json.loads(line)
        except json.JSONDecodeError:
            continue
        if not isinstance(payload, dict):
            continue
        if str(payload.get("type") or "").strip().lower() != "clarification":
            continue
        content = payload.get("content")
        if isinstance(content, str) and content.strip():
            return content.strip()
        message = payload.get("message")
        if isinstance(message, dict):
            message_content = message.get("content")
            if isinstance(message_content, str) and message_content.strip():
                return message_content.strip()
    return None
