from __future__ import annotations

from enum import StrEnum


class CaseStatus(StrEnum):
    new = "new"
    queued_for_local_run = "queued_for_local_run"
    interactive_queued = "interactive_queued"
    interactive_running = "interactive_running"
    clarification_needed = "clarification_needed"
    waiting_user_reply = "waiting_user_reply"
    ready_to_execute = "ready_to_execute"
    researching = "researching"
    draft_ready = "draft_ready"
    awaiting_review = "awaiting_review"
    awaiting_send_approval = "awaiting_send_approval"
    revising = "revising"
    approved_to_send = "approved_to_send"
    executing_approved_action = "executing_approved_action"
    sending = "sending"
    sent = "sent"
    completed = "completed"
    rejected = "rejected"
    expired = "expired"
    manual_required = "manual_required"
    failed = "failed"


class CaseSource(StrEnum):
    slack_sync = "slack_sync"
    gitlab_sync = "gitlab_sync"
    jira_sync = "jira_sync"
    confluence_sync = "confluence_sync"
    notion_sync = "notion_sync"
    asana_sync = "asana_sync"
    linear_sync = "linear_sync"
    gmail_sync = "gmail_sync"
    google_calendar_sync = "google_calendar_sync"
    google_drive_sync = "google_drive_sync"
    zendesk_sync = "zendesk_sync"
    discord_sync = "discord_sync"
    microsoft_teams_sync = "microsoft_teams_sync"
    scheduled_job = "scheduled_job"
    manual_followup = "manual_followup"
    w10w225_direct_request = "w10w225_direct_request"
    project_workflow = "project_workflow"


class ExecutionEngine(StrEnum):
    codex_cli = "codex_cli"
    copilot_cli = "copilot_cli"
    claude_cli = "claude_cli"
    gemini_cli = "gemini_cli"
    openai_api = "openai_api"
    anthropic_api = "anthropic_api"
    gemini_api = "gemini_api"


class ReviewDecisionType(StrEnum):
    approve_send = "approve_send"
    edit_and_send = "edit_and_send"
    request_followup = "request_followup"
    reject = "reject"


class ReviewCommandStatus(StrEnum):
    pending = "pending"
    claimed = "claimed"
    completed = "completed"
    failed = "failed"
    cancelled = "cancelled"


class ConnectorType(StrEnum):
    slack = "slack"
    jira = "jira"
    confluence = "confluence"
    gitlab = "gitlab"
    notion = "notion"
    linear = "linear"
    gmail = "gmail"
    google_calendar = "google_calendar"
    google_drive = "google_drive"
    trello = "trello"
    asana = "asana"
    discord = "discord"
    microsoft_teams = "microsoft_teams"
    zendesk = "zendesk"


class AgentSessionMode(StrEnum):
    interactive = "interactive"


class AgentSessionStatus(StrEnum):
    queued = "queued"
    running = "running"
    waiting_user_reply = "waiting_user_reply"
    awaiting_approval = "awaiting_approval"
    completed = "completed"
    rejected = "rejected"
    failed = "failed"
    expired = "expired"


class AgentPendingItemType(StrEnum):
    new_direct_request = "new_direct_request"
    interactive_user_reply = "interactive_user_reply"
    interactive_execution_decision = "interactive_execution_decision"
    project_workflow_stage_execute = "project_workflow_stage_execute"


class AgentPendingItemStatus(StrEnum):
    pending = "pending"
    claimed = "claimed"
    acknowledged = "acknowledged"
    completed = "completed"
    failed = "failed"
    cancelled = "cancelled"
    expired = "expired"


class AgentExecutionDecisionType(StrEnum):
    approve_execute = "approve_execute"
    edit_and_execute = "edit_and_execute"
    request_followup = "request_followup"
    reject = "reject"


class AgentWriteDraftKind(StrEnum):
    slack_send_message = "slack_send_message"
    slack_thread_reply = "slack_thread_reply"
    gitlab_note_create = "gitlab_note_create"
    jira_comment_create = "jira_comment_create"
    confluence_comment_create = "confluence_comment_create"
    generic_external_action = "generic_external_action"


class AgentWriteDraftStatus(StrEnum):
    draft_ready = "draft_ready"
    awaiting_approval = "awaiting_approval"
    approved = "approved"
    edited = "edited"
    executed = "executed"
    rejected = "rejected"
    superseded = "superseded"


class AgentOnboardingItemType(StrEnum):
    oauth_connection_ready = "oauth_connection_ready"
    oauth_refresh_required = "oauth_refresh_required"
    oauth_disconnect_requested = "oauth_disconnect_requested"
    connection_health_check_requested = "connection_health_check_requested"
    agent_character_sync = "agent_character_sync"
    project_agent_definition_sync = "project_agent_definition_sync"
    project_agent_install_update_requested = "project_agent_install_update_requested"


class AgentOnboardingItemStatus(StrEnum):
    pending = "pending"
    claimed = "claimed"
    acknowledged = "acknowledged"
    completed = "completed"
    failed = "failed"
    expired = "expired"


class AgentConnectedAccountStatus(StrEnum):
    active = "active"
    refresh_required = "refresh_required"
    revoked = "revoked"
    disconnected = "disconnected"
