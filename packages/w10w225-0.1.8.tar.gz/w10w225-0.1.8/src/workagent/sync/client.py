from __future__ import annotations

import hashlib
import hmac
from datetime import UTC, datetime
from typing import Protocol

import httpx

from workagent.sync.models import (
    AgentConnectedAccountStatusPayload,
    AgentOnboardingItemAckPayload,
    AgentOnboardingItemPullResponse,
    AgentOnboardingItemResultPayload,
    AgentPendingItemAckPayload,
    AgentPendingItemPullResponse,
    AgentPendingItemResultPayload,
    AgentRoomMessagePayload,
    AgentSessionMessagePayload,
    AgentWriteDraftCreatePayload,
    AgentWriteDraftStatusPayload,
    ProjectAgentInstallationStatusPayload,
    ProjectWorkflowStageResultPayload,
    ReviewCasePushPayload,
    ReviewCommandAckPayload,
    ReviewCommandPullResponse,
    ReviewCommandResultPayload,
)


class HmacSigner(Protocol):
    def sign(self, *, method: str, path: str, body: bytes) -> dict[str, str]: ...


class NullSigner:
    def sign(self, *, method: str, path: str, body: bytes) -> dict[str, str]:  # noqa: ARG002
        return {}


class ReviewSyncClient:
    def __init__(
        self,
        *,
        base_url: str,
        target_installation_id: str | None = None,
        local_agent_secret: str | None = None,
        socket_transport=None,  # noqa: ANN001
        signer: HmacSigner | None = None,
        transport: httpx.BaseTransport | None = None,
        timeout: float = 10.0,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._target_installation_id = str(target_installation_id or "").strip() or None
        self._local_agent_secret = str(local_agent_secret or "").strip() or None
        self._socket_transport = socket_transport
        self._signer = signer or NullSigner()
        self._transport = transport
        self._timeout = timeout

    async def push_review_case(self, payload: ReviewCasePushPayload) -> dict:
        return await self._request(
            "POST",
            "/api/v1/review-cases",
            json=payload.model_dump(mode="json", by_alias=True),
        )

    async def pull_review_commands(self, *, cursor: str | None = None, limit: int = 20) -> ReviewCommandPullResponse:
        data = await self._request(
            "GET",
            "/api/v1/review-commands",
            params={k: v for k, v in {"cursor": cursor, "limit": limit}.items() if v is not None},
        )
        return ReviewCommandPullResponse.model_validate(data)

    async def ack_review_command(self, command_id: str, payload: ReviewCommandAckPayload) -> dict:
        return await self._request(
            "POST",
            f"/api/v1/review-commands/{command_id}/ack",
            json=payload.model_dump(mode="json", by_alias=True),
        )

    async def push_review_command_result(self, command_id: str, payload: ReviewCommandResultPayload) -> dict:
        return await self._request(
            "POST",
            f"/api/v1/review-commands/{command_id}/result",
            json=payload.model_dump(mode="json", by_alias=True),
        )

    async def pull_agent_pending_items(self, *, cursor: str | None = None, limit: int = 20) -> AgentPendingItemPullResponse:
        data = await self._request(
            "GET",
            "/api/v2/assistant/agent-pending-items",
            params={
                k: v
                for k, v in {
                    "cursor": cursor,
                    "limit": limit,
                    "targetInstallationId": self._target_installation_id,
                }.items()
                if v is not None
            },
        )
        return AgentPendingItemPullResponse.model_validate(data)

    async def ack_agent_pending_item(self, item_id: str, payload: AgentPendingItemAckPayload) -> dict:
        socket_transport = self._connected_socket_transport()
        if socket_transport is not None:
            return await socket_transport.ack_agent_pending_item(item_id, payload)
        return await self._request(
            "POST",
            f"/api/v2/assistant/agent-pending-items/{item_id}/ack",
            json=payload.model_dump(mode="json", by_alias=True),
        )

    async def push_agent_pending_item_result(self, item_id: str, payload: AgentPendingItemResultPayload) -> dict:
        socket_transport = self._connected_socket_transport()
        if socket_transport is not None:
            return await socket_transport.push_agent_pending_item_result(item_id, payload)
        return await self._request(
            "POST",
            f"/api/v2/assistant/agent-pending-items/{item_id}/result",
            json=payload.model_dump(mode="json", by_alias=True),
        )

    async def post_agent_room_message(self, payload: AgentRoomMessagePayload) -> dict:
        return await self._request(
            "POST",
            "/api/v2/assistant/agent-room/messages",
            json=payload.model_dump(mode="json", by_alias=True),
        )

    async def post_agent_session_message(self, session_id: str, payload: AgentSessionMessagePayload) -> dict:
        if self._socket_transport is not None and getattr(self._socket_transport, "is_connected", False):
            try:
                return await self._socket_transport.post_agent_session_message(session_id, payload)
            except Exception:  # noqa: BLE001
                pass
        return await self._request(
            "POST",
            f"/api/v2/assistant/agent-sessions/{session_id}/messages",
            json=payload.model_dump(mode="json", by_alias=True),
        )

    async def fetch_agent_session_artifact_content(self, session_id: str, artifact_id: str) -> tuple[bytes, str]:
        path = f"/api/v2/assistant/agent-sessions/{session_id}/artifacts/{artifact_id}"
        headers = self._build_local_agent_headers(headers={})
        async with httpx.AsyncClient(base_url=self._base_url, timeout=self._timeout, transport=self._transport) as client:
            response = await client.get(path, headers=headers)
        response.raise_for_status()
        return response.content, str(response.headers.get("content-type") or "application/octet-stream")

    async def fetch_agent_model_catalog(self) -> dict:
        return await self._request(
            "GET",
            "/api/v2/assistant/agent-model-catalog",
        )

    async def create_agent_write_draft(self, payload: AgentWriteDraftCreatePayload) -> dict:
        if self._socket_transport is not None and getattr(self._socket_transport, "is_connected", False):
            try:
                return await self._socket_transport.create_agent_write_draft(payload)
            except Exception:  # noqa: BLE001
                pass
        return await self._request(
            "POST",
            "/api/v2/assistant/agent-write-drafts",
            json=payload.model_dump(mode="json", by_alias=True),
        )

    async def update_agent_write_draft_status(self, draft_id: str, payload: AgentWriteDraftStatusPayload) -> dict:
        if self._socket_transport is not None and getattr(self._socket_transport, "is_connected", False):
            try:
                return await self._socket_transport.update_agent_write_draft_status(draft_id, payload)
            except Exception:  # noqa: BLE001
                pass
        return await self._request(
            "POST",
            f"/api/v2/assistant/agent-write-drafts/{draft_id}/status",
            json=payload.model_dump(mode="json", by_alias=True),
        )

    async def pull_agent_onboarding_items(
        self,
        *,
        cursor: str | None = None,
        limit: int = 20,
    ) -> AgentOnboardingItemPullResponse:
        data = await self._request(
            "GET",
            "/api/v2/assistant/agent-onboarding-items",
            params={
                k: v
                for k, v in {
                    "cursor": cursor,
                    "limit": limit,
                    "targetInstallationId": self._target_installation_id,
                }.items()
                if v is not None
            },
        )
        return AgentOnboardingItemPullResponse.model_validate(data)

    async def ack_agent_onboarding_item(self, item_id: str, payload: AgentOnboardingItemAckPayload) -> dict:
        socket_transport = self._connected_socket_transport()
        if socket_transport is not None:
            return await socket_transport.ack_agent_onboarding_item(item_id, payload)
        return await self._request(
            "POST",
            f"/api/v2/assistant/agent-onboarding-items/{item_id}/ack",
            json=payload.model_dump(mode="json", by_alias=True),
        )

    async def push_agent_onboarding_item_result(
        self,
        item_id: str,
        payload: AgentOnboardingItemResultPayload,
    ) -> dict:
        socket_transport = self._connected_socket_transport()
        if socket_transport is not None:
            return await socket_transport.push_agent_onboarding_item_result(item_id, payload)
        return await self._request(
            "POST",
            f"/api/v2/assistant/agent-onboarding-items/{item_id}/result",
            json=payload.model_dump(mode="json", by_alias=True),
        )

    async def push_agent_connected_account_status(self, payload: AgentConnectedAccountStatusPayload) -> dict:
        return await self._request(
            "POST",
            "/api/v2/assistant/agent-connected-accounts/status",
            json=payload.model_dump(mode="json", by_alias=True),
        )

    async def push_project_workflow_stage_result(
        self,
        workflow_run_id: str,
        payload: ProjectWorkflowStageResultPayload,
    ) -> dict:
        socket_transport = self._connected_socket_transport()
        if socket_transport is not None:
            return await socket_transport.push_project_workflow_stage_result(workflow_run_id, payload)
        return await self._request(
            "POST",
            f"/api/v2/assistant/project-workflow-runs/{workflow_run_id}/result",
            json=payload.model_dump(mode="json", by_alias=True),
        )

    async def push_project_agent_installation_status(
        self,
        payload: ProjectAgentInstallationStatusPayload,
    ) -> dict:
        return await self._request(
            "POST",
            "/api/v2/assistant/project-agent-installations/status",
            json=payload.model_dump(mode="json", by_alias=True),
        )

    def set_socket_transport(self, socket_transport) -> None:  # noqa: ANN001
        self._socket_transport = socket_transport

    def _connected_socket_transport(self):  # noqa: ANN001
        if self._socket_transport is None or not getattr(self._socket_transport, "is_connected", False):
            return None
        return self._socket_transport

    def _require_connected_socket_transport(self, operation: str):  # noqa: ANN001
        socket_transport = self._connected_socket_transport()
        if socket_transport is None:
            raise RuntimeError(f"{operation} requires a connected local agent socket transport")
        return socket_transport

    async def _request(
        self,
        method: str,
        path: str,
        *,
        json: dict | None = None,
        params: dict | None = None,
    ) -> dict:
        body = b""
        if json is not None:
            body = httpx.Request(method, self._base_url + path, json=json).content
        headers = self._signer.sign(method=method, path=path, body=body)
        headers.update(self._build_local_agent_headers(headers=headers))
        async with httpx.AsyncClient(base_url=self._base_url, timeout=self._timeout, transport=self._transport) as client:
            response = await client.request(method, path, json=json, params=params, headers=headers)
        response.raise_for_status()
        payload = response.json()
        return payload.get("data", payload)

    def _build_local_agent_headers(self, *, headers: dict[str, str]) -> dict[str, str]:
        if not self._target_installation_id or not self._local_agent_secret:
            return {}
        timestamp = headers.get("x-workagent-timestamp") or datetime.now(UTC).isoformat()
        signature = hmac.new(
            self._local_agent_secret.encode("utf-8"),
            f"{self._target_installation_id}\n{timestamp}".encode(),
            hashlib.sha256,
        ).hexdigest()
        return {
            "x-agent-installation-id": self._target_installation_id,
            "x-agent-timestamp": timestamp,
            "x-agent-signature": signature,
        }
