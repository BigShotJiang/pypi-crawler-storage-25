"""CLI tool commands for external system connectors.

Usage:
  w10w225 slack list-channels
  w10w225 slack read --channel C123 --limit 10
  w10w225 slack read-thread --channel C123 --thread-ts TS
  w10w225 slack search --query "deploy" --limit 5
  w10w225 slack send --channel C123 --text "Hello"
  w10w225 slack reply --channel C123 --thread-ts TS --text "Hello"
  w10w225 jira search --jql "project=PROJ" --limit 10
  w10w225 jira get --key PROJ-123
  w10w225 jira me
  w10w225 jira comment --key PROJ-123 --body TEXT
  w10w225 gitlab activity [--limit N]
  w10w225 gitlab me
  w10w225 gitlab mr --project PATH --iid N
  w10w225 gitlab discussions --project PATH --iid N
  w10w225 gitlab pipeline --project PATH --id N
  w10w225 gitlab commit --project PATH --sha SHA
  w10w225 gitlab mr-note --project PATH --iid N --body TEXT
  w10w225 confluence search --query QUERY [--limit N]
  w10w225 confluence search-cql --cql CQL [--limit N]
  w10w225 confluence page --id PAGE_ID
  w10w225 confluence me
  w10w225 confluence comment --page-id PAGE_ID --body TEXT
  w10w225 notion me
  w10w225 notion page --id PAGE_ID
  w10w225 notion search --query QUERY [--limit N]
  w10w225 notion comment --page-id PAGE_ID --text TEXT
  w10w225 linear me
  w10w225 linear issue --id ISSUE_ID
  w10w225 linear search --query QUERY [--limit N]
  w10w225 linear comment --issue-id ISSUE_ID --body TEXT
  w10w225 gmail me
  w10w225 gmail get --id MESSAGE_ID
  w10w225 gmail search --query QUERY [--limit N]
  w10w225 gmail send --to EMAIL --subject SUBJECT --body TEXT
  w10w225 discord me
  w10w225 discord get --channel-id CID --message-id MID
  w10w225 discord search --query QUERY [--limit N]
  w10w225 discord send --channel-id CID --text TEXT
  w10w225 gcalendar me
  w10w225 gcalendar get --calendar-id CID --event-id EID
  w10w225 gcalendar list --query QUERY [--limit N]
  w10w225 gcalendar create --calendar-id CID --summary TEXT --start DATETIME --end DATETIME
  w10w225 gdrive me
  w10w225 gdrive get --file-id FID
  w10w225 gdrive search --query QUERY [--limit N]
  w10w225 gdrive comment --file-id FID --content TEXT
  w10w225 asana me
  w10w225 asana task --id TASK_ID
  w10w225 asana search --query QUERY [--limit N]
  w10w225 asana comment --task-id TASK_ID --text TEXT
  w10w225 zendesk me
  w10w225 zendesk ticket --id TICKET_ID
  w10w225 zendesk search --query QUERY [--limit N]
  w10w225 zendesk comment --ticket-id TICKET_ID --body TEXT [--public]
  w10w225 teams me
  w10w225 teams get --team-id TID --channel-id CID --message-id MID
  w10w225 teams search --query QUERY [--limit N]
  w10w225 teams send --team-id TID --channel-id CID --text TEXT
  w10w225 trello me
  w10w225 trello card --id CARD_ID
  w10w225 trello comment --card-id CARD_ID --text TEXT
"""
from __future__ import annotations

import argparse
import asyncio
import dataclasses
import json
import sys
from pathlib import Path
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from workagent.db.models import CredentialBindingMetadata

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

async def _load_credential(
    session_factory: async_sessionmaker[AsyncSession],
    connector_type: str,
) -> CredentialBindingMetadata | None:
    """Load the enabled credential row for a platform from the DB."""
    async with session_factory() as session:
        result = await session.execute(
            select(CredentialBindingMetadata).where(
                CredentialBindingMetadata.connector_type == connector_type,
                CredentialBindingMetadata.is_enabled.is_(True),
            )
        )
        return result.scalars().first()


def _get_session_factory() -> async_sessionmaker[AsyncSession]:
    db_path = Path.home() / ".personal-work-agent" / "data" / "app.db"
    engine = create_async_engine(f"sqlite+aiosqlite:///{db_path}")
    return async_sessionmaker(engine, expire_on_commit=False)


def _print_json(data: Any) -> None:
    """Serialize *data* to JSON on stdout. Handles dataclasses and lists."""
    if dataclasses.is_dataclass(data) and not isinstance(data, type):
        data = dataclasses.asdict(data)
    elif isinstance(data, list):
        data = [
            dataclasses.asdict(item) if dataclasses.is_dataclass(item) and not isinstance(item, type) else item
            for item in data
        ]
    print(json.dumps(data, ensure_ascii=False, indent=2, default=str))


def _error_exit(msg: str) -> None:
    print(json.dumps({"error": msg}), file=sys.stderr)
    sys.exit(1)


# ---------------------------------------------------------------------------
# Slack handlers (synchronous client)
# ---------------------------------------------------------------------------

async def _handle_slack(args: argparse.Namespace) -> None:
    from workagent.connectors.slack_client import SlackApiClient
    from workagent.connectors.slack_send import SlackOutboundSender

    cred = await _load_credential(_get_session_factory(), "slack")
    if cred is None:
        _error_exit("No enabled Slack credential found")
        return  # unreachable, keeps type-checker happy
    token = cred.secret_key
    base = cred.base_url or "https://slack.com"

    action: str = args.action

    if action == "list-channels":
        client = SlackApiClient(base_url=base)
        result = client.list_conversations(token=token, limit=getattr(args, "limit", 100))
        _print_json(result)

    elif action == "read":
        client = SlackApiClient(base_url=base)
        resp = client.fetch_recent(token=token, channel_id=args.channel, limit=getattr(args, "limit", 50))
        _print_json({"messages": resp.messages, "next_cursor": resp.next_cursor})

    elif action == "read-thread":
        client = SlackApiClient(base_url=base)
        messages = client.fetch_thread_replies(token=token, channel_id=args.channel, thread_ts=args.thread_ts)
        _print_json(messages)

    elif action == "search":
        client = SlackApiClient(base_url=base)
        result = client.search_messages(token=token, query=args.query, limit=getattr(args, "limit", 20))
        _print_json(result)

    elif action == "send":
        sender = SlackOutboundSender(base_url=base)
        result = sender.send_message(token=token, channel_id=args.channel, text=args.text)
        _print_json(result)

    elif action == "reply":
        sender = SlackOutboundSender(base_url=base)
        result = sender.reply_in_thread(token=token, channel_id=args.channel, thread_ts=args.thread_ts, text=args.text)
        _print_json(result)

    else:
        _error_exit(f"Unknown slack action: {action}")


# ---------------------------------------------------------------------------
# Jira handlers (async client, needs base_url)
# ---------------------------------------------------------------------------

async def _handle_jira(args: argparse.Namespace) -> None:
    from workagent.connectors.jira_client import JiraApiClient

    cred = await _load_credential(_get_session_factory(), "jira")
    if cred is None:
        _error_exit("No enabled Jira credential found")
        return
    client = JiraApiClient(base_url=cred.base_url, api_token=cred.secret_key)
    action: str = args.action

    if action == "search":
        result = await client.search_issues(args.jql, limit=getattr(args, "limit", 20))
        _print_json(result)
    elif action == "get":
        result = await client.get_issue(args.key)
        _print_json(result)
    elif action == "me":
        result = await client.get_current_user()
        _print_json(result)
    elif action == "comment":
        result = await client.create_issue_comment(args.key, args.body)
        _print_json(result)
    else:
        _error_exit(f"Unknown jira action: {action}")


# ---------------------------------------------------------------------------
# GitLab handlers (async client, needs base_url)
# ---------------------------------------------------------------------------

async def _handle_gitlab(args: argparse.Namespace) -> None:
    from workagent.connectors.gitlab_client import GitLabApiClient

    cred = await _load_credential(_get_session_factory(), "gitlab")
    if cred is None:
        _error_exit("No enabled GitLab credential found")
        return
    client = GitLabApiClient(base_url=cred.base_url, private_token=cred.secret_key)
    action: str = args.action

    if action == "activity":
        events, _cursor = await client.list_activity(limit=getattr(args, "limit", 20))
        _print_json(events)
    elif action == "me":
        result = await client.get_current_user()
        _print_json(result)
    elif action == "mr":
        result = await client.get_merge_request(args.project, args.iid)
        _print_json(result)
    elif action == "discussions":
        result = await client.get_discussions(args.project, args.iid)
        _print_json(result)
    elif action == "pipeline":
        result = await client.get_pipeline(args.project, args.id)
        _print_json(result)
    elif action == "commit":
        result = await client.get_commit_summary(args.project, args.sha)
        _print_json(result)
    elif action == "mr-note":
        result = await client.create_merge_request_note(args.project, args.iid, args.body)
        _print_json(result)
    else:
        _error_exit(f"Unknown gitlab action: {action}")


# ---------------------------------------------------------------------------
# Confluence handlers (async client, needs base_url)
# ---------------------------------------------------------------------------

async def _handle_confluence(args: argparse.Namespace) -> None:
    from workagent.connectors.confluence_client import ConfluenceApiClient

    cred = await _load_credential(_get_session_factory(), "confluence")
    if cred is None:
        _error_exit("No enabled Confluence credential found")
        return
    client = ConfluenceApiClient(base_url=cred.base_url, api_token=cred.secret_key)
    action: str = args.action

    if action == "search":
        result = await client.search_pages(args.query, limit=getattr(args, "limit", 10))
        _print_json(result)
    elif action == "search-cql":
        result = await client.search_content(args.cql, limit=getattr(args, "limit", 20))
        _print_json(result)
    elif action == "page":
        result = await client.get_page_summary(args.id)
        _print_json(result)
    elif action == "me":
        result = await client.get_current_user()
        _print_json(result)
    elif action == "comment":
        result = await client.create_page_comment(args.page_id, args.body)
        _print_json(result)
    else:
        _error_exit(f"Unknown confluence action: {action}")


# ---------------------------------------------------------------------------
# Notion handlers (async client, needs base_url)
# ---------------------------------------------------------------------------

async def _handle_notion(args: argparse.Namespace) -> None:
    from workagent.connectors.notion_client import NotionApiClient

    cred = await _load_credential(_get_session_factory(), "notion")
    if cred is None:
        _error_exit("No enabled Notion credential found")
        return
    client = NotionApiClient(base_url=cred.base_url, api_token=cred.secret_key)
    action: str = args.action

    if action == "me":
        result = await client.get_current_user()
        _print_json(result)
    elif action == "page":
        result = await client.get_page(args.id)
        _print_json(result)
    elif action == "search":
        result = await client.search_pages(args.query, limit=getattr(args, "limit", 20))
        _print_json(result)
    elif action == "comment":
        result = await client.create_page_comment(args.page_id, args.text)
        _print_json(result)
    else:
        _error_exit(f"Unknown notion action: {action}")


# ---------------------------------------------------------------------------
# Linear handlers (async client, needs base_url)
# ---------------------------------------------------------------------------

async def _handle_linear(args: argparse.Namespace) -> None:
    from workagent.connectors.linear_client import LinearApiClient

    cred = await _load_credential(_get_session_factory(), "linear")
    if cred is None:
        _error_exit("No enabled Linear credential found")
        return
    client = LinearApiClient(base_url=cred.base_url, api_token=cred.secret_key)
    action: str = args.action

    if action == "me":
        result = await client.get_current_user()
        _print_json(result)
    elif action == "issue":
        result = await client.get_issue(args.id)
        _print_json(result)
    elif action == "search":
        result = await client.search_issues(args.query, limit=getattr(args, "limit", 20))
        _print_json(result)
    elif action == "comment":
        result = await client.create_issue_comment(args.issue_id, args.body)
        _print_json(result)
    else:
        _error_exit(f"Unknown linear action: {action}")


# ---------------------------------------------------------------------------
# Gmail handlers (async client, needs base_url)
# ---------------------------------------------------------------------------

async def _handle_gmail(args: argparse.Namespace) -> None:
    from workagent.connectors.gmail_client import GmailApiClient

    cred = await _load_credential(_get_session_factory(), "gmail")
    if cred is None:
        _error_exit("No enabled Gmail credential found")
        return
    client = GmailApiClient(base_url=cred.base_url, api_token=cred.secret_key)
    action: str = args.action

    if action == "me":
        result = await client.get_current_user()
        _print_json(result)
    elif action == "get":
        result = await client.get_message(args.id)
        _print_json(result)
    elif action == "search":
        result = await client.search_messages(args.query, limit=getattr(args, "limit", 20))
        _print_json(result)
    elif action == "send":
        result = await client.send_message(to=args.to, subject=args.subject, body=args.body)
        _print_json(result)
    else:
        _error_exit(f"Unknown gmail action: {action}")


# ---------------------------------------------------------------------------
# Discord handlers (async client, needs base_url)
# ---------------------------------------------------------------------------

async def _handle_discord(args: argparse.Namespace) -> None:
    from workagent.connectors.discord_client import DiscordApiClient

    cred = await _load_credential(_get_session_factory(), "discord")
    if cred is None:
        _error_exit("No enabled Discord credential found")
        return
    client = DiscordApiClient(base_url=cred.base_url, api_token=cred.secret_key)
    action: str = args.action

    if action == "me":
        result = await client.get_current_user()
        _print_json(result)
    elif action == "get":
        result = await client.get_message(args.channel_id, args.message_id)
        _print_json(result)
    elif action == "search":
        result = await client.search_messages(args.query, limit=getattr(args, "limit", 20))
        _print_json(result)
    elif action == "send":
        result = await client.create_message(args.channel_id, args.text)
        _print_json(result)
    else:
        _error_exit(f"Unknown discord action: {action}")


# ---------------------------------------------------------------------------
# Google Calendar handlers (async client, needs base_url)
# ---------------------------------------------------------------------------

async def _handle_gcalendar(args: argparse.Namespace) -> None:
    from workagent.connectors.google_calendar_client import GoogleCalendarApiClient

    cred = await _load_credential(_get_session_factory(), "google_calendar")
    if cred is None:
        _error_exit("No enabled Google Calendar credential found")
        return
    client = GoogleCalendarApiClient(base_url=cred.base_url, api_token=cred.secret_key)
    action: str = args.action

    if action == "me":
        result = await client.get_current_user()
        _print_json(result)
    elif action == "get":
        result = await client.get_event(args.calendar_id, args.event_id)
        _print_json(result)
    elif action == "list":
        result = await client.list_events(args.query, limit=getattr(args, "limit", 20))
        _print_json(result)
    elif action == "create":
        result = await client.create_event(args.calendar_id, summary=args.summary, start=args.start, end=args.end)
        _print_json(result)
    else:
        _error_exit(f"Unknown gcalendar action: {action}")


# ---------------------------------------------------------------------------
# Google Drive handlers (async client, needs base_url)
# ---------------------------------------------------------------------------

async def _handle_gdrive(args: argparse.Namespace) -> None:
    from workagent.connectors.google_drive_client import GoogleDriveApiClient

    cred = await _load_credential(_get_session_factory(), "google_drive")
    if cred is None:
        _error_exit("No enabled Google Drive credential found")
        return
    client = GoogleDriveApiClient(base_url=cred.base_url, api_token=cred.secret_key)
    action: str = args.action

    if action == "me":
        result = await client.get_current_user()
        _print_json(result)
    elif action == "get":
        result = await client.get_file(args.file_id)
        _print_json(result)
    elif action == "search":
        result = await client.search_files(args.query, limit=getattr(args, "limit", 20))
        _print_json(result)
    elif action == "comment":
        result = await client.create_file_comment(args.file_id, args.content)
        _print_json(result)
    else:
        _error_exit(f"Unknown gdrive action: {action}")


# ---------------------------------------------------------------------------
# Asana handlers (async client, needs base_url)
# ---------------------------------------------------------------------------

async def _handle_asana(args: argparse.Namespace) -> None:
    from workagent.connectors.asana_client import AsanaApiClient

    cred = await _load_credential(_get_session_factory(), "asana")
    if cred is None:
        _error_exit("No enabled Asana credential found")
        return
    client = AsanaApiClient(base_url=cred.base_url, api_token=cred.secret_key)
    action: str = args.action

    if action == "me":
        result = await client.get_current_user()
        _print_json(result)
    elif action == "task":
        result = await client.get_task(args.id)
        _print_json(result)
    elif action == "search":
        result = await client.search_tasks(args.query, limit=getattr(args, "limit", 20))
        _print_json(result)
    elif action == "comment":
        result = await client.create_task_comment(args.task_id, args.text)
        _print_json(result)
    else:
        _error_exit(f"Unknown asana action: {action}")


# ---------------------------------------------------------------------------
# Zendesk handlers (async client, needs base_url)
# ---------------------------------------------------------------------------

async def _handle_zendesk(args: argparse.Namespace) -> None:
    from workagent.connectors.zendesk_client import ZendeskApiClient

    cred = await _load_credential(_get_session_factory(), "zendesk")
    if cred is None:
        _error_exit("No enabled Zendesk credential found")
        return
    client = ZendeskApiClient(base_url=cred.base_url, api_token=cred.secret_key)
    action: str = args.action

    if action == "me":
        result = await client.get_current_user()
        _print_json(result)
    elif action == "ticket":
        result = await client.get_ticket(args.id)
        _print_json(result)
    elif action == "search":
        result = await client.search_tickets(args.query, limit=getattr(args, "limit", 20))
        _print_json(result)
    elif action == "comment":
        result = await client.create_ticket_comment(
            args.ticket_id, args.body, public=getattr(args, "public", True),
        )
        _print_json(result)
    else:
        _error_exit(f"Unknown zendesk action: {action}")


# ---------------------------------------------------------------------------
# Microsoft Teams handlers (async client, needs base_url)
# ---------------------------------------------------------------------------

async def _handle_teams(args: argparse.Namespace) -> None:
    from workagent.connectors.microsoft_teams_client import MicrosoftTeamsApiClient

    cred = await _load_credential(_get_session_factory(), "microsoft_teams")
    if cred is None:
        _error_exit("No enabled Microsoft Teams credential found")
        return
    client = MicrosoftTeamsApiClient(base_url=cred.base_url, api_token=cred.secret_key)
    action: str = args.action

    if action == "me":
        result = await client.get_current_user()
        _print_json(result)
    elif action == "get":
        result = await client.get_message(args.team_id, args.channel_id, args.message_id)
        _print_json(result)
    elif action == "search":
        result = await client.search_messages(args.query, limit=getattr(args, "limit", 20))
        _print_json(result)
    elif action == "send":
        result = await client.create_message(args.team_id, args.channel_id, args.text)
        _print_json(result)
    else:
        _error_exit(f"Unknown teams action: {action}")


# ---------------------------------------------------------------------------
# Trello handlers (async client, needs base_url)
# ---------------------------------------------------------------------------

async def _handle_trello(args: argparse.Namespace) -> None:
    from workagent.connectors.trello_client import TrelloApiClient

    cred = await _load_credential(_get_session_factory(), "trello")
    if cred is None:
        _error_exit("No enabled Trello credential found")
        return
    client = TrelloApiClient(base_url=cred.base_url, api_token=cred.secret_key)
    action: str = args.action

    if action == "me":
        result = await client.get_current_member()
        _print_json(result)
    elif action == "card":
        result = await client.get_card(args.id)
        _print_json(result)
    elif action == "comment":
        result = await client.create_card_comment(args.card_id, args.text)
        _print_json(result)
    else:
        _error_exit(f"Unknown trello action: {action}")


# ---------------------------------------------------------------------------
# Platform dispatcher
# ---------------------------------------------------------------------------

_PLATFORM_HANDLERS: dict[str, Any] = {
    "slack": _handle_slack,
    "jira": _handle_jira,
    "gitlab": _handle_gitlab,
    "confluence": _handle_confluence,
    "notion": _handle_notion,
    "linear": _handle_linear,
    "gmail": _handle_gmail,
    "discord": _handle_discord,
    "gcalendar": _handle_gcalendar,
    "gdrive": _handle_gdrive,
    "asana": _handle_asana,
    "zendesk": _handle_zendesk,
    "teams": _handle_teams,
    "trello": _handle_trello,
}


# ---------------------------------------------------------------------------
# Argparse registration helpers
# ---------------------------------------------------------------------------

def _add_limit(parser: argparse.ArgumentParser, default: int = 20) -> None:
    parser.add_argument("--limit", type=int, default=default, help=f"Max results (default: {default})")


def _register_slack(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    sp = subparsers.add_parser("slack", help="Slack commands")
    sp.set_defaults(platform="slack")
    sub = sp.add_subparsers(dest="action", required=True)

    p = sub.add_parser("list-channels", help="List conversations")
    _add_limit(p, 100)

    p = sub.add_parser("read", help="Read channel history")
    p.add_argument("--channel", required=True, help="Channel ID")
    _add_limit(p, 50)

    p = sub.add_parser("read-thread", help="Read thread replies")
    p.add_argument("--channel", required=True, help="Channel ID")
    p.add_argument("--thread-ts", required=True, help="Thread timestamp")

    p = sub.add_parser("search", help="Search messages")
    p.add_argument("--query", required=True, help="Search query")
    _add_limit(p)

    p = sub.add_parser("send", help="Send a message")
    p.add_argument("--channel", required=True, help="Channel ID")
    p.add_argument("--text", required=True, help="Message text")

    p = sub.add_parser("reply", help="Reply in thread")
    p.add_argument("--channel", required=True, help="Channel ID")
    p.add_argument("--thread-ts", required=True, help="Thread timestamp")
    p.add_argument("--text", required=True, help="Reply text")


def _register_jira(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    sp = subparsers.add_parser("jira", help="Jira commands")
    sp.set_defaults(platform="jira")
    sub = sp.add_subparsers(dest="action", required=True)

    p = sub.add_parser("search", help="Search issues with JQL")
    p.add_argument("--jql", required=True, help="JQL query")
    _add_limit(p)

    p = sub.add_parser("get", help="Get issue by key")
    p.add_argument("--key", required=True, help="Issue key (e.g. PROJ-123)")

    sub.add_parser("me", help="Get current user info")

    p = sub.add_parser("comment", help="Add comment to issue")
    p.add_argument("--key", required=True, help="Issue key")
    p.add_argument("--body", required=True, help="Comment body")


def _register_gitlab(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    sp = subparsers.add_parser("gitlab", help="GitLab commands")
    sp.set_defaults(platform="gitlab")
    sub = sp.add_subparsers(dest="action", required=True)

    p = sub.add_parser("activity", help="List recent activity (MRs, todos)")
    _add_limit(p)

    sub.add_parser("me", help="Get current user info")

    p = sub.add_parser("mr", help="Get merge request details")
    p.add_argument("--project", required=True, help="Project path (e.g. group/project)")
    p.add_argument("--iid", required=True, type=int, help="Merge request IID")

    p = sub.add_parser("discussions", help="List MR discussions")
    p.add_argument("--project", required=True, help="Project path")
    p.add_argument("--iid", required=True, type=int, help="Merge request IID")

    p = sub.add_parser("pipeline", help="Get pipeline details")
    p.add_argument("--project", required=True, help="Project path")
    p.add_argument("--id", required=True, type=int, help="Pipeline ID")

    p = sub.add_parser("commit", help="Get commit summary")
    p.add_argument("--project", required=True, help="Project path")
    p.add_argument("--sha", required=True, help="Commit SHA")

    p = sub.add_parser("mr-note", help="Add note to merge request")
    p.add_argument("--project", required=True, help="Project path")
    p.add_argument("--iid", required=True, type=int, help="Merge request IID")
    p.add_argument("--body", required=True, help="Note body")


def _register_confluence(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    sp = subparsers.add_parser("confluence", help="Confluence commands")
    sp.set_defaults(platform="confluence")
    sub = sp.add_subparsers(dest="action", required=True)

    p = sub.add_parser("search", help="Search pages by text")
    p.add_argument("--query", required=True, help="Search query")
    _add_limit(p, 10)

    p = sub.add_parser("search-cql", help="Search content by CQL")
    p.add_argument("--cql", required=True, help="CQL expression")
    _add_limit(p)

    p = sub.add_parser("page", help="Get page summary")
    p.add_argument("--id", required=True, help="Page ID")

    sub.add_parser("me", help="Get current user info")

    p = sub.add_parser("comment", help="Add comment to page")
    p.add_argument("--page-id", required=True, help="Page ID")
    p.add_argument("--body", required=True, help="Comment body (storage format)")


def _register_notion(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    sp = subparsers.add_parser("notion", help="Notion commands")
    sp.set_defaults(platform="notion")
    sub = sp.add_subparsers(dest="action", required=True)

    sub.add_parser("me", help="Get current user info")

    p = sub.add_parser("page", help="Get page details")
    p.add_argument("--id", required=True, help="Page ID")

    p = sub.add_parser("search", help="Search pages")
    p.add_argument("--query", required=True, help="Search query")
    _add_limit(p)

    p = sub.add_parser("comment", help="Add comment to page")
    p.add_argument("--page-id", required=True, help="Page ID")
    p.add_argument("--text", required=True, help="Comment text")


def _register_linear(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    sp = subparsers.add_parser("linear", help="Linear commands")
    sp.set_defaults(platform="linear")
    sub = sp.add_subparsers(dest="action", required=True)

    sub.add_parser("me", help="Get current user info")

    p = sub.add_parser("issue", help="Get issue details")
    p.add_argument("--id", required=True, help="Issue ID")

    p = sub.add_parser("search", help="Search issues")
    p.add_argument("--query", required=True, help="Search query")
    _add_limit(p)

    p = sub.add_parser("comment", help="Add comment to issue")
    p.add_argument("--issue-id", required=True, help="Issue ID")
    p.add_argument("--body", required=True, help="Comment body")


def _register_gmail(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    sp = subparsers.add_parser("gmail", help="Gmail commands")
    sp.set_defaults(platform="gmail")
    sub = sp.add_subparsers(dest="action", required=True)

    sub.add_parser("me", help="Get current user profile")

    p = sub.add_parser("get", help="Get message by ID")
    p.add_argument("--id", required=True, help="Message ID")

    p = sub.add_parser("search", help="Search messages")
    p.add_argument("--query", required=True, help="Search query")
    _add_limit(p)

    p = sub.add_parser("send", help="Send email")
    p.add_argument("--to", required=True, help="Recipient email")
    p.add_argument("--subject", required=True, help="Email subject")
    p.add_argument("--body", required=True, help="Email body")


def _register_discord(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    sp = subparsers.add_parser("discord", help="Discord commands")
    sp.set_defaults(platform="discord")
    sub = sp.add_subparsers(dest="action", required=True)

    sub.add_parser("me", help="Get current user info")

    p = sub.add_parser("get", help="Get message by ID")
    p.add_argument("--channel-id", required=True, help="Channel ID")
    p.add_argument("--message-id", required=True, help="Message ID")

    p = sub.add_parser("search", help="Search messages")
    p.add_argument("--query", required=True, help="Search query")
    _add_limit(p)

    p = sub.add_parser("send", help="Send message to channel")
    p.add_argument("--channel-id", required=True, help="Channel ID")
    p.add_argument("--text", required=True, help="Message text")


def _register_gcalendar(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    sp = subparsers.add_parser("gcalendar", help="Google Calendar commands")
    sp.set_defaults(platform="gcalendar")
    sub = sp.add_subparsers(dest="action", required=True)

    sub.add_parser("me", help="Get primary calendar info")

    p = sub.add_parser("get", help="Get event details")
    p.add_argument("--calendar-id", required=True, help="Calendar ID")
    p.add_argument("--event-id", required=True, help="Event ID")

    p = sub.add_parser("list", help="List/search events")
    p.add_argument("--query", required=True, help="Search query")
    _add_limit(p)

    p = sub.add_parser("create", help="Create calendar event")
    p.add_argument("--calendar-id", required=True, help="Calendar ID")
    p.add_argument("--summary", required=True, help="Event summary/title")
    p.add_argument("--start", required=True, help="Start datetime (ISO 8601)")
    p.add_argument("--end", required=True, help="End datetime (ISO 8601)")


def _register_gdrive(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    sp = subparsers.add_parser("gdrive", help="Google Drive commands")
    sp.set_defaults(platform="gdrive")
    sub = sp.add_subparsers(dest="action", required=True)

    sub.add_parser("me", help="Get current user info")

    p = sub.add_parser("get", help="Get file metadata")
    p.add_argument("--file-id", required=True, help="File ID")

    p = sub.add_parser("search", help="Search files")
    p.add_argument("--query", required=True, help="Search query (Drive API format)")
    _add_limit(p)

    p = sub.add_parser("comment", help="Add comment to file")
    p.add_argument("--file-id", required=True, help="File ID")
    p.add_argument("--content", required=True, help="Comment content")


def _register_asana(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    sp = subparsers.add_parser("asana", help="Asana commands")
    sp.set_defaults(platform="asana")
    sub = sp.add_subparsers(dest="action", required=True)

    sub.add_parser("me", help="Get current user info")

    p = sub.add_parser("task", help="Get task details")
    p.add_argument("--id", required=True, help="Task ID")

    p = sub.add_parser("search", help="Search tasks")
    p.add_argument("--query", required=True, help="Search query")
    _add_limit(p)

    p = sub.add_parser("comment", help="Add comment to task")
    p.add_argument("--task-id", required=True, help="Task ID")
    p.add_argument("--text", required=True, help="Comment text")


def _register_zendesk(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    sp = subparsers.add_parser("zendesk", help="Zendesk commands")
    sp.set_defaults(platform="zendesk")
    sub = sp.add_subparsers(dest="action", required=True)

    sub.add_parser("me", help="Get current user info")

    p = sub.add_parser("ticket", help="Get ticket details")
    p.add_argument("--id", required=True, help="Ticket ID")

    p = sub.add_parser("search", help="Search tickets")
    p.add_argument("--query", required=True, help="Search query")
    _add_limit(p)

    p = sub.add_parser("comment", help="Add comment to ticket")
    p.add_argument("--ticket-id", required=True, help="Ticket ID")
    p.add_argument("--body", required=True, help="Comment body")
    p.add_argument("--public", action="store_true", default=True, help="Public comment (default: true)")


def _register_teams(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    sp = subparsers.add_parser("teams", help="Microsoft Teams commands")
    sp.set_defaults(platform="teams")
    sub = sp.add_subparsers(dest="action", required=True)

    sub.add_parser("me", help="Get current user info")

    p = sub.add_parser("get", help="Get message details")
    p.add_argument("--team-id", required=True, help="Team ID")
    p.add_argument("--channel-id", required=True, help="Channel ID")
    p.add_argument("--message-id", required=True, help="Message ID")

    p = sub.add_parser("search", help="Search messages")
    p.add_argument("--query", required=True, help="Search query")
    _add_limit(p)

    p = sub.add_parser("send", help="Send message to channel")
    p.add_argument("--team-id", required=True, help="Team ID")
    p.add_argument("--channel-id", required=True, help="Channel ID")
    p.add_argument("--text", required=True, help="Message text")


def _register_trello(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    sp = subparsers.add_parser("trello", help="Trello commands")
    sp.set_defaults(platform="trello")
    sub = sp.add_subparsers(dest="action", required=True)

    sub.add_parser("me", help="Get current member info")

    p = sub.add_parser("card", help="Get card details")
    p.add_argument("--id", required=True, help="Card ID")

    p = sub.add_parser("comment", help="Add comment to card")
    p.add_argument("--card-id", required=True, help="Card ID")
    p.add_argument("--text", required=True, help="Comment text")


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def register_tool_subcommands(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    """Register all platform subcommands under the given *subparsers* action.

    This is intended to be called from the main ``cli.py`` module, e.g.::

        tool_subparsers = parser.add_subparsers(...)
        register_tool_subcommands(tool_subparsers)
    """
    _register_slack(subparsers)
    _register_jira(subparsers)
    _register_gitlab(subparsers)
    _register_confluence(subparsers)
    _register_notion(subparsers)
    _register_linear(subparsers)
    _register_gmail(subparsers)
    _register_discord(subparsers)
    _register_gcalendar(subparsers)
    _register_gdrive(subparsers)
    _register_asana(subparsers)
    _register_zendesk(subparsers)
    _register_teams(subparsers)
    _register_trello(subparsers)


def run_tool_command(args: argparse.Namespace) -> int:
    """Dispatch to the correct platform handler and run it.

    Returns 0 on success, 1 on error.
    """
    platform: str | None = getattr(args, "platform", None)
    if platform is None:
        _error_exit("No platform specified")
        return 1  # unreachable

    handler = _PLATFORM_HANDLERS.get(platform)
    if handler is None:
        _error_exit(f"Unknown platform: {platform}")
        return 1  # unreachable

    try:
        asyncio.run(handler(args))
    except SystemExit:
        raise
    except KeyboardInterrupt:
        return 130
    except Exception as exc:
        _error_exit(str(exc))
        return 1  # unreachable

    return 0
