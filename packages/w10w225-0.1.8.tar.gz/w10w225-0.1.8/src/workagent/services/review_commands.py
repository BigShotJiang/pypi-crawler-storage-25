from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from workagent.db.enums import CaseSource, CaseStatus, ReviewCommandStatus, ReviewDecisionType
from workagent.db.models import AuditEvent, Case, CaseEvent, ReviewCommand
from workagent.domain.case_state import assert_case_transition_allowed


def _utcnow() -> datetime:
    return datetime.now(UTC)


MAX_CASE_REVISIONS = 5


@dataclass(frozen=True, slots=True)
class ProcessedCommandResult:
    command_id: str
    case_id: str
    new_case_status: CaseStatus
    command_status: ReviewCommandStatus


class ReviewCommandProcessor:
    def __init__(
        self,
        session_factory: async_sessionmaker[AsyncSession],
        *,
        queue=None,  # noqa: ANN001
        memory_writer: object | None = None,
        graph_processor=None,  # noqa: ANN001
    ) -> None:
        self.session_factory = session_factory
        self.queue = queue
        self.memory_writer = memory_writer
        self.graph_processor = graph_processor

    async def process_command(self, command_id: str) -> ProcessedCommandResult:
        if self.graph_processor is not None:
            async with self.session_factory() as session:
                command = await session.get(ReviewCommand, command_id)
                case = await session.get(Case, command.case_id) if command is not None else None
                if (
                    case is not None
                    and (
                        bool((case.payload_json or {}).get("graphPhase"))
                        or bool((case.payload_json or {}).get("actionIntent"))
                        or case.source == CaseSource.w10w225_direct_request
                    )
                ):
                    return await self._process_command_with_graph(command_id)
        async with self.session_factory() as session:
            command = await session.get(ReviewCommand, command_id)
            if command is None:
                raise ValueError(f"review command not found: {command_id}")
            case = await session.get(Case, command.case_id)
            if case is None:
                raise ValueError(f"case not found: {command.case_id}")

            next_status = self._resolve_next_status(case, command.command_type)
            assert_case_transition_allowed(case.status, next_status)

            case.payload_json = self._next_case_payload(case, command, next_status)
            case.status = next_status
            case.updated_at = _utcnow()
            command.status = ReviewCommandStatus.completed
            command.completed_at = _utcnow()
            command.updated_at = _utcnow()

            session.add(
                CaseEvent(
                    case_id=case.id,
                    event_type=f"review_command.{command.command_type.value}",
                    payload_json=command.payload_json,
                )
            )

            if command.command_type == ReviewDecisionType.request_followup:
                session.add(
                    AuditEvent(
                        event_type="review_command.followup_instruction",
                        entity_type="case",
                        entity_id=case.id,
                        payload_json={
                            "commandId": command.id,
                            "instruction": str(command.payload_json.get("instruction") or "").strip(),
                            "revisionNumber": case.payload_json.get("revisionNumber"),
                        },
                    )
                )
            if (
                command.command_type == ReviewDecisionType.edit_and_send
                and int(((case.payload_json or {}).get("memorySearch") or {}).get("hitCount") or 0) == 0
            ):
                session.add(
                    AuditEvent(
                        event_type="memory.human_correction",
                        entity_type="case",
                        entity_id=case.id,
                        payload_json={
                            "commandId": command.id,
                            "reason": "memory_miss",
                        },
                    )
                )

            await session.commit()
            if self.queue is not None and case.status == CaseStatus.revising:
                await self.queue.enqueue(case.id)
            return ProcessedCommandResult(
                command_id=command.id,
                case_id=case.id,
                new_case_status=case.status,
                command_status=command.status,
            )

    async def _process_command_with_graph(self, command_id: str) -> ProcessedCommandResult:
        async with self.session_factory() as session:
            command = await session.get(ReviewCommand, command_id)
            if command is None:
                raise ValueError(f"review command not found: {command_id}")
            case = await session.get(Case, command.case_id)
            if case is None:
                raise ValueError(f"case not found: {command.case_id}")
            next_status = self._resolve_next_status(case, command.command_type)
            assert_case_transition_allowed(case.status, next_status)
            case.status = next_status
            case.updated_at = _utcnow()
            case.payload_json = self._next_case_payload(case, command, next_status)
            command.status = ReviewCommandStatus.completed
            command.completed_at = _utcnow()
            command.updated_at = _utcnow()
            session.add(
                CaseEvent(
                    case_id=case.id,
                    event_type=f"review_command.{command.command_type.value}",
                    payload_json=command.payload_json,
                )
            )
            if command.command_type == ReviewDecisionType.request_followup:
                session.add(
                    AuditEvent(
                        event_type="review_command.followup_instruction",
                        entity_type="case",
                        entity_id=case.id,
                        payload_json={
                            "commandId": command.id,
                            "instruction": str(
                                command.payload_json.get("instruction") or command.payload_json.get("followupInstruction") or ""
                            ).strip(),
                        },
                    )
                )
            await session.commit()
            case_id = case.id
            command_type = command.command_type.value
            payload_json = dict(command.payload_json)

        await self.graph_processor.resume_case(
            case_id,
            {
                "source": "review_command",
                "decisionType": command_type,
                "actorUserId": str(payload_json.get("operatorId") or "").strip() or None,
                "editedText": (
                    str(payload_json.get("editedDraft") or payload_json.get("editedText") or "").strip() or None
                ),
                "editedPayloadJson": payload_json if command_type == ReviewDecisionType.edit_and_send.value else None,
                "followupInstruction": (
                    str(payload_json.get("instruction") or payload_json.get("followupInstruction") or "").strip() or None
                ),
            },
        )

        async with self.session_factory() as session:
            refreshed = await session.get(Case, case_id)
            if refreshed is None:
                raise ValueError(f"case not found after graph resume: {case_id}")
            return ProcessedCommandResult(
                command_id=command_id,
                case_id=refreshed.id,
                new_case_status=refreshed.status,
                command_status=ReviewCommandStatus.completed,
            )

    @staticmethod
    def _resolve_next_status(case: Case, command_type: ReviewDecisionType) -> CaseStatus:
        mapping = {
            ReviewDecisionType.request_followup: CaseStatus.revising,
            ReviewDecisionType.approve_send: CaseStatus.approved_to_send,
            ReviewDecisionType.edit_and_send: CaseStatus.approved_to_send,
            ReviewDecisionType.reject: CaseStatus.rejected,
        }
        if command_type == ReviewDecisionType.request_followup:
            revision_number = int((case.payload_json or {}).get("revisionNumber") or 0)
            if revision_number >= MAX_CASE_REVISIONS:
                return CaseStatus.manual_required
        return mapping[command_type]

    @staticmethod
    def _next_case_payload(case: Case, command: ReviewCommand, next_status: CaseStatus) -> dict[str, Any]:
        payload = dict(case.payload_json or {})
        payload.update(ReviewCommandProcessor._command_thread_payload(command))
        if command.command_type != ReviewDecisionType.request_followup:
            return payload

        instruction = str(command.payload_json.get("instruction") or command.payload_json.get("followupInstruction") or "").strip()
        revision_number = int(payload.get("revisionNumber") or 0)
        history = list(payload.get("followupInstructions") or [])
        history.append(
            {
                "commandId": command.id,
                "instruction": instruction,
                "recordedAt": _utcnow().isoformat(),
            }
        )
        if payload.get("draft"):
            payload["previousDraft"] = str(payload.get("draft"))
        payload["followupInstructions"] = history
        payload["latestInstruction"] = instruction
        payload["reuseExistingContext"] = True
        payload["revisionNumber"] = revision_number + 1
        if next_status == CaseStatus.manual_required:
            payload["maxRevisionExceeded"] = True
        return payload

    @staticmethod
    def _command_thread_payload(command: ReviewCommand) -> dict[str, Any]:
        next_payload: dict[str, Any] = {}
        for source_key, target_key in (
            ("threadId", "threadId"),
            ("topicSessionId", "topicSessionId"),
            ("replyMode", "replyMode"),
            ("botSenderUserId", "botSenderUserId"),
            ("botSenderUserNickname", "botSenderUserNickname"),
        ):
            value = command.payload_json.get(source_key)
            if value not in {None, ""}:
                next_payload[target_key] = value
        return next_payload

    @staticmethod
    def _build_outbound_payload(payload_json: dict[str, Any]) -> dict[str, Any]:
        payload = dict(payload_json)
        edited_text = str(payload.get("editedDraft") or payload.get("editedText") or "").strip()
        draft_text = str(payload.get("draft") or "").strip()
        if edited_text:
            payload["text"] = edited_text
        elif draft_text:
            payload.setdefault("text", draft_text)
        return payload
