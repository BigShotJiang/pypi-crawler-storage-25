from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class ExecutionResult:
    success: bool
    payload: dict[str, object]

    def to_dict(self) -> dict[str, object]:
        return dict(self.payload)


class ActionExecutor:
    def __init__(self, *, connectors: dict[str, object]) -> None:
        self.connectors = dict(connectors)

    async def execute(self, action_payload: dict[str, object]) -> ExecutionResult:
        kind = str(action_payload.get("kind") or "").strip()
        connector = self.connectors.get(kind)
        if connector is None:
            return ExecutionResult(success=False, payload={"error": f"Unknown action kind: {kind}"})
        result = await connector.execute(action_payload)
        if isinstance(result, dict):
            return ExecutionResult(success=True, payload=result)
        return ExecutionResult(success=True, payload={"result": result})
