from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from workagent.db.enums import AgentWriteDraftKind, AgentWriteDraftStatus
from workagent.db.models import AgentSession, AgentWriteDraft
from workagent.sync.models import (
    AgentSessionMessagePayload,
    AgentWriteDraftCreatePayload,
    AgentWriteDraftStatusPayload,
    ProjectWorkflowStageResultPayload,
)


class Nk304Transport:
    def __init__(self, *, session_factory: async_sessionmaker[AsyncSession], sync_api) -> None:  # noqa: ANN001
        self.session_factory = session_factory
        self.sync_api = sync_api

    async def post_session_message(
        self,
        *,
        session_id: str,
        message_type: str,
        text: str,
        metadata: dict[str, object] | None = None,
    ) -> None:
        response = await self.sync_api.post_agent_session_message(
            session_id,
            AgentSessionMessagePayload(
                messageType=message_type,
                text=text,
                metadata=dict(metadata or {}),
            ),
        )
        message_id = str(response.get("messageId") or "").strip() or None
        if not message_id:
            return
        async with self.session_factory() as session:
            session_row = await session.get(AgentSession, session_id)
            if session_row is None:
                return
            session_row.latest_agent_message_id = message_id
            await session.commit()

    async def create_write_draft(
        self,
        *,
        session_id: str,
        draft_kind: str,
        target_ref: dict[str, object],
        draft_text: str,
        draft_payload: dict[str, object],
    ) -> str:
        response = await self.sync_api.create_agent_write_draft(
            AgentWriteDraftCreatePayload(
                sessionId=session_id,
                draftKind=draft_kind,
                targetRef=target_ref,
                draftText=draft_text,
                draftPayload=draft_payload,
            )
        )
        draft_id = str(response.get("draftId") or "").strip()
        async with self.session_factory() as session:
            row = await session.get(AgentWriteDraft, draft_id)
            if row is None:
                row = AgentWriteDraft(
                    id=draft_id,
                    session_id=session_id,
                    draft_kind=AgentWriteDraftKind(draft_kind),
                    target_ref_json=target_ref,
                    draft_text=draft_text,
                    draft_payload_json=draft_payload,
                    status=AgentWriteDraftStatus.awaiting_approval,
                )
                session.add(row)
            else:
                row.draft_kind = AgentWriteDraftKind(draft_kind)
                row.target_ref_json = target_ref
                row.draft_text = draft_text
                row.draft_payload_json = draft_payload
                row.status = AgentWriteDraftStatus.awaiting_approval
            session_row = await session.get(AgentSession, session_id)
            if session_row is not None:
                session_row.current_write_draft_id = draft_id
            await session.commit()
        return draft_id

    async def update_write_draft_status(
        self,
        *,
        draft_id: str,
        status: str,
        execution_result: dict[str, object] | None = None,
    ) -> None:
        await self.sync_api.update_agent_write_draft_status(
            draft_id,
            AgentWriteDraftStatusPayload(
                status=status,
                executionResult=dict(execution_result or {}),
            ),
        )
        async with self.session_factory() as session:
            row = await session.get(AgentWriteDraft, draft_id)
            if row is None:
                return
            row.status = AgentWriteDraftStatus(status)
            row.execution_result_json = dict(execution_result or {})
            await session.commit()

    async def push_project_workflow_stage_result(
        self,
        workflow_run_id: str,
        payload: dict[str, object],
    ) -> None:
        await self.sync_api.push_project_workflow_stage_result(
            workflow_run_id,
            ProjectWorkflowStageResultPayload.model_validate(payload),
        )
