from __future__ import annotations

import asyncio
from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from workagent.db.enums import ConnectorType
from workagent.services.action_executor import ActionExecutor
from workagent.services.action_parser import ActionParser
from workagent.services.chat_pipeline import ChatPipeline
from workagent.services.document_pipeline import DocumentPipeline
from workagent.services.file_memory import FileMemoryStore
from workagent.services.local_agent_store import LocalAgentStore
from workagent.services.nk304_transport import Nk304Transport
from workagent.services.request_router import RequestRouter


@dataclass(frozen=True, slots=True)
class _RelayExecutionResult:
    text: str


class _ConfiguredRelayExecutor:
    def __init__(self, *, executor, model: str | None) -> None:  # noqa: ANN001
        self.executor = executor
        self.model = model

    async def run(self, prompt: str) -> _RelayExecutionResult:
        output = await asyncio.to_thread(self.executor.run_fresh, model=self.model, prompt=prompt)
        normalized = self.executor.normalize_output(output)
        text = (
            str(normalized.draft or "").strip()
            or str(normalized.clarification_question or "").strip()
            or str(getattr(output, "assistant_text", "") or "").strip()
        )
        return _RelayExecutionResult(text=text)


class _ImmediateOutboundConnector:
    def __init__(self, *, outbound_processor, connector_type: ConnectorType | None) -> None:  # noqa: ANN001
        self.outbound_processor = outbound_processor
        self.connector_type = connector_type

    async def execute(self, action_payload: dict[str, object]):  # noqa: ANN201
        resolved_connector = self.connector_type
        if resolved_connector is None:
            resolved_connector = ConnectorType(str(action_payload.get("connectorType") or "").strip().lower())
        outbound = SimpleNamespace(
            connector_type=resolved_connector,
            payload_json=dict(action_payload),
        )
        return await self.outbound_processor._send(outbound)


def _build_action_connectors(outbound_processor) -> dict[str, object]:  # noqa: ANN001
    return {
        "slack_send_message": _ImmediateOutboundConnector(
            outbound_processor=outbound_processor,
            connector_type=ConnectorType.slack,
        ),
        "slack_thread_reply": _ImmediateOutboundConnector(
            outbound_processor=outbound_processor,
            connector_type=ConnectorType.slack,
        ),
        "gitlab_note_create": _ImmediateOutboundConnector(
            outbound_processor=outbound_processor,
            connector_type=ConnectorType.gitlab,
        ),
        "jira_comment_create": _ImmediateOutboundConnector(
            outbound_processor=outbound_processor,
            connector_type=ConnectorType.jira,
        ),
        "confluence_comment_create": _ImmediateOutboundConnector(
            outbound_processor=outbound_processor,
            connector_type=ConnectorType.confluence,
        ),
        "generic_external_action": _ImmediateOutboundConnector(
            outbound_processor=outbound_processor,
            connector_type=None,
        ),
    }


def build_request_router(
    *,
    session_factory: async_sessionmaker[AsyncSession],
    sync_api,
    executor,
    model: str | None,
    outbound_processor,
) -> RequestRouter:
    transport = Nk304Transport(session_factory=session_factory, sync_api=sync_api)
    relay_executor = _ConfiguredRelayExecutor(executor=executor, model=model)
    action_executor = ActionExecutor(connectors=_build_action_connectors(outbound_processor))
    pwa_home = Path.home() / ".personal-work-agent"
    agent_store = LocalAgentStore(agents_dir=pwa_home / "agents")
    memory_store = FileMemoryStore(memory_dir=pwa_home / "memory")
    return RequestRouter(
        chat_pipeline=ChatPipeline(
            executor=relay_executor,
            transport=transport,
            action_parser=ActionParser(),
            action_executor=action_executor,
            agent_store=agent_store,
            memory_store=memory_store,
        ),
        document_pipeline=DocumentPipeline(
            executor=relay_executor,
            transport=transport,
            agent_store=agent_store,
        ),
        session_factory=session_factory,
    )
