from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

from workagent.db.enums import CaseSource
from workagent.db.models import Case
from workagent.services.agent_artifacts import (
    build_agent_artifact_prompt_section,
    build_extracted_artifact_prompt_section,
)
from workagent.skills import CompiledSkillContract, SkillAssetBundle, SkillCandidate

REDACTED_KEYS = {"api_key", "apikey", "apitoken", "authorization", "password", "secret", "token"}


@dataclass(frozen=True, slots=True)
class ToolAvailabilityManifest:
    slack_search: bool = False
    slack_thread: bool = False
    gitlab_read: bool = False
    jira_read: bool = False
    confluence_read: bool = False

    def as_dict(self) -> dict[str, bool]:
        return {
            "slack_search": self.slack_search,
            "slack_thread": self.slack_thread,
            "gitlab_read": self.gitlab_read,
            "jira_read": self.jira_read,
            "confluence_read": self.confluence_read,
        }


@dataclass(frozen=True, slots=True)
class CasePromptBundle:
    system_prompt: str
    user_prompt: str
    tool_manifest: str
    output_contract: str
    skill_manifest: str | None = None
    skill_guidance: str | None = None
    skill_candidates: tuple[SkillCandidate, ...] = field(default_factory=tuple)
    skill_assets: tuple[SkillAssetBundle, ...] = field(default_factory=tuple)
    compiled_skill_contracts: tuple[CompiledSkillContract, ...] = field(default_factory=tuple)
    retrieved_memory_count: int = 0
    recent_output_texts: tuple[str, ...] = field(default_factory=tuple)
    repetition_guard_enabled: bool = False

    def render(self) -> str:
        return "\n\n".join(
            [
                self.system_prompt,
                self.tool_manifest,
                self.skill_manifest or "",
                self.skill_guidance or "",
                self.output_contract,
                self.user_prompt,
            ]
        )


def build_case_prompt(
    case: Case,
    *,
    followup_instruction: str | None = None,
    tool_manifest: ToolAvailabilityManifest | None = None,
    skill_candidates: tuple[SkillCandidate, ...] | None = None,
    skill_assets: tuple[SkillAssetBundle, ...] | None = None,
    compiled_skill_contracts: tuple[CompiledSkillContract, ...] | None = None,
    retrieved_memory_text: str | None = None,
    retrieved_memory_count: int = 0,
    recent_output_texts: tuple[str, ...] | None = None,
    repetition_guard_enabled: bool = False,
) -> CasePromptBundle:
    manifest = tool_manifest or ToolAvailabilityManifest()
    resolved_skill_candidates = skill_candidates or ()
    resolved_skill_assets = skill_assets or ()
    resolved_compiled_skill_contracts = compiled_skill_contracts or ()
    system_prompt = _system_prompt_for_source(case.source, skill_candidates=resolved_skill_candidates)
    user_sections = [
        f"Title:\n{case.title.strip()}",
    ]
    summary = (case.summary or "").strip()
    if summary:
        user_sections.append(f"Summary:\n{summary}")
    payload = case.payload_json or {}
    if payload:
        user_sections.append("Payload:\n" + json.dumps(_redact_value(payload), ensure_ascii=True, indent=2, sort_keys=True))
    artifact_summary = build_agent_artifact_prompt_section(payload)
    if artifact_summary:
        user_sections.append(artifact_summary)
    extracted_artifact_summary = build_extracted_artifact_prompt_section(payload)
    if extracted_artifact_summary:
        user_sections.append(extracted_artifact_summary)
    clarification_history = _build_clarification_history(payload)
    if clarification_history:
        user_sections.append(f"Clarification History:\n{clarification_history}")
    effective_followup_instruction = followup_instruction or str(payload.get("latestInstruction") or "").strip() or None
    if effective_followup_instruction:
        user_sections.append(f"Supervisor Follow-up:\n{effective_followup_instruction.strip()}")
    resolved_recent_output_texts = tuple(text.strip() for text in (recent_output_texts or ()) if str(text).strip())
    if resolved_recent_output_texts:
        recent_outputs = "\n".join(
            f"- {_truncate_prompt_text(text, limit=280)}" for text in resolved_recent_output_texts
        )
        user_sections.append(
            "Recent Outputs For This Scheduled Task (avoid repeating or closely paraphrasing them):\n"
            + recent_outputs
        )
    if retrieved_memory_text:
        user_sections.append(f"Retrieved Memory:\n{retrieved_memory_text.strip()}")
    output_contract = (
        "Return the result in this structure: summary + reasoning + proposed reply + evidence. "
        "Format evidence as bullet items with source, locator, and why it matters. "
        "For Jira and Confluence evidence, use the issue key or page id/title as the locator and include the canonical URL when available. "
        "Do not perform any external write action."
    )
    return CasePromptBundle(
        system_prompt=system_prompt,
        user_prompt="\n\n".join(section for section in user_sections if section.strip()),
        tool_manifest="Tool Availability:\n" + json.dumps(manifest.as_dict(), ensure_ascii=True, indent=2, sort_keys=True),
        output_contract=output_contract,
        skill_manifest=_build_skill_manifest(resolved_skill_candidates),
        skill_guidance=_build_skill_guidance(
            resolved_skill_candidates,
            resolved_skill_assets,
            resolved_compiled_skill_contracts,
        ),
        skill_candidates=resolved_skill_candidates,
        skill_assets=resolved_skill_assets,
        compiled_skill_contracts=resolved_compiled_skill_contracts,
        retrieved_memory_count=retrieved_memory_count,
        recent_output_texts=resolved_recent_output_texts,
        repetition_guard_enabled=repetition_guard_enabled,
    )


def _truncate_prompt_text(text: str, *, limit: int) -> str:
    normalized = " ".join(str(text).split())
    if len(normalized) <= limit:
        return normalized
    return normalized[: limit - 3].rstrip() + "..."


def _system_prompt_for_source(source: CaseSource, *, skill_candidates: tuple[SkillCandidate, ...] = ()) -> str:
    skill_rule = (
        " If trusted skill candidates are listed, decide whether any of them materially improve the result, "
        "and request specific skill ids via requestedSkillIds before relying on detailed workflow guidance beyond the provided metadata."
    )
    if source == CaseSource.slack_sync:
        return "You are handling a Slack work inquiry. Investigate available Slack/JIRA/Confluence context and draft a precise reply." + (
            skill_rule if skill_candidates else ""
        )
    if source == CaseSource.gitlab_sync:
        return "You are handling a GitLab review request. Investigate merge request context and draft a concise review response." + (
            skill_rule if skill_candidates else ""
        )
    if source == CaseSource.jira_sync:
        return "You are handling a Jira work issue. Investigate issue history and draft a concise next action." + (
            skill_rule if skill_candidates else ""
        )
    if source == CaseSource.confluence_sync:
        return "You are handling a Confluence page change. Investigate the page update and draft the required follow-up." + (
            skill_rule if skill_candidates else ""
        )
    if source == CaseSource.scheduled_job:
        return "You are handling a scheduled work check. Review the job context and draft the required follow-up." + (
            skill_rule if skill_candidates else ""
        )
    return "You are handling a work case. Investigate context and draft the next response." + (
        skill_rule if skill_candidates else ""
    )


def _build_skill_manifest(skill_candidates: tuple[SkillCandidate, ...]) -> str | None:
    if not skill_candidates:
        return None
    return "Skill Candidates:\n" + json.dumps(
        [candidate.as_prompt_dict() for candidate in skill_candidates],
        ensure_ascii=True,
        indent=2,
        sort_keys=True,
    )


def _build_skill_guidance(
    skill_candidates: tuple[SkillCandidate, ...],
    skill_assets: tuple[SkillAssetBundle, ...],
    compiled_skill_contracts: tuple[CompiledSkillContract, ...],
) -> str | None:
    if not skill_candidates:
        return None
    sections = ["Loaded Skill Guidance:"]
    loaded_any = False
    for candidate in skill_candidates:
        contract = next((item for item in compiled_skill_contracts if item.skill_id == candidate.skill_id), None)
        asset = next((item for item in skill_assets if item.skill_id == candidate.skill_id), None)
        if contract is None and asset is None:
            continue
        loaded_any = True
        sections.extend(
            [
                f"Skill: {candidate.skill_id}",
                f"Match Reasons: {', '.join(candidate.match_reasons) if candidate.match_reasons else 'selected candidate'}",
            ]
        )
        if contract is not None:
            rendered_contract = _render_compiled_skill_contract(contract)
            if rendered_contract:
                sections.append(rendered_contract)
                continue
        if asset is None:
            continue
        entrypoint_excerpt = _excerpt_text(asset.entrypoint_text)
        if entrypoint_excerpt:
            sections.append(f"Workflow Asset:\n{entrypoint_excerpt}")
        readme_excerpt = _excerpt_text(asset.readme_text)
        if readme_excerpt:
            sections.append(f"Reference Notes:\n{readme_excerpt}")
    if not loaded_any:
        return None
    return "\n\n".join(section for section in sections if section.strip())


def _excerpt_text(raw_text: str | None, *, max_chars: int = 600) -> str | None:
    text = str(raw_text or "").strip()
    if not text:
        return None
    if len(text) <= max_chars:
        return text
    return text[: max_chars - 3].rstrip() + "..."


def _render_compiled_skill_contract(contract: CompiledSkillContract) -> str:
    sections: list[str] = []
    if contract.instructions:
        sections.append("Instructions:\n" + "\n".join(f"- {item}" for item in contract.instructions))
    if contract.checklist:
        sections.append("Checklist:\n" + "\n".join(f"- {item}" for item in contract.checklist))
    if contract.workflow_steps:
        sections.append("Workflow:\n" + "\n".join(f"- {item}" for item in contract.workflow_steps))
    tool_lines: list[str] = []
    if contract.allowed_tools:
        tool_lines.append("Allowed: " + ", ".join(contract.allowed_tools))
    if contract.blocked_tools:
        tool_lines.append("Blocked: " + ", ".join(contract.blocked_tools))
    if contract.preferred_tools:
        tool_lines.append("Preferred: " + ", ".join(contract.preferred_tools))
    if tool_lines:
        sections.append("Tool Policy:\n" + "\n".join(tool_lines))
    if contract.validation_rules:
        sections.append("Validation:\n" + "\n".join(f"- {item}" for item in contract.validation_rules))
    return "\n\n".join(sections)


def _build_clarification_history(payload: dict[str, Any]) -> str | None:
    clarification_items = payload.get("interactiveClarifications")
    reply_items = payload.get("interactiveReplies")
    if not isinstance(clarification_items, list) and not isinstance(reply_items, list):
        return None

    clarifications = clarification_items if isinstance(clarification_items, list) else []
    replies = reply_items if isinstance(reply_items, list) else []
    lines: list[str] = []
    for index in range(max(len(clarifications), len(replies))):
        turn_number = index + 1
        if index < len(clarifications) and isinstance(clarifications[index], dict):
            question = str(clarifications[index].get("question") or "").strip()
            if question:
                lines.append(f"Turn {turn_number} Agent: {question}")
        if index < len(replies) and isinstance(replies[index], dict):
            reply_text = str(replies[index].get("replyText") or "").strip()
            if reply_text:
                lines.append(f"Turn {turn_number} User: {reply_text}")
    return "\n".join(lines).strip() or None


def _redact_value(value: Any) -> Any:
    if isinstance(value, dict):
        redacted: dict[str, Any] = {}
        for key, child in value.items():
            normalized = key.replace("-", "").replace("_", "").lower()
            if normalized in REDACTED_KEYS:
                redacted[key] = "[REDACTED]"
            else:
                redacted[key] = _redact_value(child)
        return redacted
    if isinstance(value, list):
        return [_redact_value(item) for item in value]
    return value
