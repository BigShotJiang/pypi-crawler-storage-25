from __future__ import annotations

from typing import TYPE_CHECKING, Any

from workagent.sync.models import AgentPendingItemRecord

if TYPE_CHECKING:
    from workagent.services.file_memory import FileMemoryStore
    from workagent.services.local_agent_store import LocalAgentStore


class ChatPipeline:
    def __init__(self, *, executor, transport, action_parser, action_executor, agent_store: LocalAgentStore | None = None, memory_store: FileMemoryStore | None = None) -> None:  # noqa: ANN001
        self.executor = executor
        self.transport = transport
        self.action_parser = action_parser
        self.action_executor = action_executor
        self.agent_store = agent_store
        self.memory_store = memory_store

    async def handle_new_request(self, pending_item: AgentPendingItemRecord) -> None:
        request_text = str(pending_item.payload.get("requestText") or "").strip()
        await self._run_and_publish(pending_item, request_text=request_text)

    async def handle_reply(self, pending_item: AgentPendingItemRecord) -> None:
        reply_text = str(pending_item.payload.get("replyText") or "").strip()
        await self._run_and_publish(pending_item, request_text=reply_text)

    async def handle_decision(self, pending_item: AgentPendingItemRecord) -> None:
        payload = pending_item.payload
        draft_id = str(payload.get("writeDraftId") or "").strip()
        decision_type = str(payload.get("decisionType") or "").strip().lower()

        if decision_type == "reject":
            if draft_id:
                await self.transport.update_write_draft_status(draft_id=draft_id, status="rejected")
            return
        if decision_type == "request_followup":
            return

        action_payload = self._resolve_action_payload(payload, decision_type=decision_type)
        execution_result = await self.action_executor.execute(action_payload)
        if draft_id:
            await self.transport.update_write_draft_status(
                draft_id=draft_id,
                status="executed" if execution_result.success else "failed",
                execution_result=execution_result.to_dict(),
            )

    async def _run_and_publish(self, pending_item: AgentPendingItemRecord, *, request_text: str) -> None:
        payload = pending_item.payload
        agent_id = payload.get("agent_id") or payload.get("agentId")
        agent_prompt = None
        skill_contents: list[str] = []
        if agent_id and self.agent_store:
            agent_prompt = self.agent_store.load_agent_prompt(str(agent_id))
            skill_contents = self.agent_store.load_skills(str(agent_id))

        # Read long-term memory for context
        memory_context = ""
        if self.memory_store:
            memory_context = self.memory_store.read_recent(max_chars=20_000)

        prompt = self.build_chat_prompt(
            conversation_turns=list(payload.get("conversationTurns") or []),
            request_text=request_text,
            agent_prompt=agent_prompt,
            skill_contents=skill_contents,
            memory_context=memory_context,
        )
        result = await self.executor.run(prompt)
        action, clean_text = self.action_parser.parse(result.text)
        session_id = pending_item.session_id or pending_item.id

        # Write to long-term memory
        if self.memory_store and request_text and result.text:
            self.memory_store.append(
                summary=f"Q: {request_text[:200]}\nA: {result.text[:500]}",
                source="chat",
                session_id=str(session_id),
                agent_id=str(agent_id) if agent_id else None,
            )

        if action is None:
            await self.transport.post_session_message(
                session_id=session_id,
                message_type="result",
                text=result.text,
                metadata={},
            )
            return

        draft_id = await self.transport.create_write_draft(
            session_id=session_id,
            draft_kind=action.kind,
            target_ref=action.target_ref,
            draft_text=action.content,
            draft_payload=action.payload,
        )
        await self.transport.post_session_message(
            session_id=session_id,
            message_type="draft_proposal",
            text=clean_text,
            metadata={"writeDraftId": draft_id},
        )

    @staticmethod
    def build_chat_prompt(
        *,
        conversation_turns: list[dict[str, Any]],
        request_text: str,
        agent_prompt: str | None = None,
        skill_contents: list[str] | None = None,
        memory_context: str | None = None,
    ) -> str:
        preamble: list[str] = []
        if agent_prompt:
            preamble.append(f"Agent Prompt:\n{agent_prompt.strip()}")
        if skill_contents:
            for i, skill in enumerate(skill_contents, 1):
                preamble.append(f"Skill {i}:\n{skill.strip()}")
        if memory_context and memory_context.strip():
            preamble.append(f"Previous Interactions (Long-term Memory):\n{memory_context.strip()}")

        turn_lines = [
            f"{str(turn.get('role') or '').strip()}: {str(turn.get('text') or '').strip()}"
            for turn in conversation_turns
            if isinstance(turn, dict) and str(turn.get("role") or "").strip() and str(turn.get("text") or "").strip()
        ]
        sections = [*preamble, "Conversation:", *turn_lines, "", "Latest request:", request_text.strip()]
        return "\n".join(section for section in sections if section is not None).strip()

    @staticmethod
    def _resolve_action_payload(payload: dict[str, object], *, decision_type: str) -> dict[str, object]:
        if decision_type == "edit_and_execute":
            edited_payload = payload.get("editedPayload")
            if isinstance(edited_payload, dict):
                return dict(edited_payload)
            edited_payload_json = payload.get("editedPayloadJson")
            if isinstance(edited_payload_json, dict):
                return dict(edited_payload_json)
        original_payload = payload.get("originalPayload")
        if isinstance(original_payload, dict):
            return dict(original_payload)
        original_payload_json = payload.get("originalPayloadJson")
        if isinstance(original_payload_json, dict):
            return dict(original_payload_json)
        raise ValueError("execution decision payload missing action payload")
