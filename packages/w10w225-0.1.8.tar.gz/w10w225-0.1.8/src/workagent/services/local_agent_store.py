from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path


class LocalAgentStore:
    """Stores agent definitions + skills received from nk304 to ~/.personal-work-agent/agents/{agent_id}/"""

    def __init__(self, agents_dir: Path) -> None:
        self.agents_dir = agents_dir

    def save_agent(
        self,
        agent_id: str,
        agent_prompt: str,
        skills: list[dict],
        version: int,
        content_hash: str,
    ) -> None:
        agent_dir = self.agents_dir / agent_id
        skills_dir = agent_dir / "skills"
        skills_dir.mkdir(parents=True, exist_ok=True)

        (agent_dir / "agent.md").write_text(agent_prompt, encoding="utf-8")

        # Remove old skills and write fresh
        for existing in skills_dir.glob("*.md"):
            existing.unlink()
        for skill in skills:
            skill_id = skill.get("skillId", "unknown")
            content = skill.get("contentText", "")
            if content:
                (skills_dir / f"{skill_id}.md").write_text(content, encoding="utf-8")

        meta = {
            "version": version,
            "contentHash": content_hash,
            "skillIds": [s.get("skillId") for s in skills],
            "updatedAt": datetime.now(UTC).isoformat(),
        }
        (agent_dir / "meta.json").write_text(json.dumps(meta, ensure_ascii=False), encoding="utf-8")

    def load_agent_prompt(self, agent_id: str) -> str | None:
        agent_file = self.agents_dir / agent_id / "agent.md"
        if agent_file.exists():
            return agent_file.read_text(encoding="utf-8")
        return None

    def load_skills(self, agent_id: str) -> list[str]:
        skills_dir = self.agents_dir / agent_id / "skills"
        if not skills_dir.exists():
            return []
        return [f.read_text(encoding="utf-8") for f in sorted(skills_dir.glob("*.md"))]

    def is_up_to_date(self, agent_id: str, content_hash: str) -> bool:
        meta_file = self.agents_dir / agent_id / "meta.json"
        if not meta_file.exists():
            return False
        try:
            meta = json.loads(meta_file.read_text(encoding="utf-8"))
            return meta.get("contentHash") == content_hash
        except (json.JSONDecodeError, OSError):
            return False
