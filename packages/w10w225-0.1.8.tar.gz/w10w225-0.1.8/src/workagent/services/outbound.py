from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any, Protocol

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from workagent.connectors.confluence_client import ConfluenceApiClient
from workagent.connectors.gitlab_client import GitLabApiClient
from workagent.connectors.jira_client import JiraApiClient
from workagent.db.enums import CaseSource, ConnectorType
from workagent.db.models import AuditEvent, Case, CredentialBindingMetadata
from workagent.services.agent_artifacts import build_attachment_session_metadata, build_attachment_session_note
from workagent.skills import SkillCatalogPaths, SkillCatalogService, SkillTrustState
from workagent.sync.models import AgentSessionMessagePayload, AgentWriteDraftStatusPayload


def _utcnow() -> datetime:
    return datetime.now(UTC)


class SlackSenderProtocol(Protocol):
    def send_message(self, *, token: str, channel_id: str, text: str): ...

    def reply_in_thread(self, *, token: str, channel_id: str, thread_ts: str, text: str): ...


class ConnectorTokenResolver(Protocol):
    async def get_token(self, connector_type: ConnectorType) -> str | None: ...


type GitLabClientFactory = Callable[[str, str], GitLabApiClient]
type JiraClientFactory = Callable[[str, str], JiraApiClient]
type ConfluenceClientFactory = Callable[[str, str], ConfluenceApiClient]


@dataclass(slots=True)
class OutboundQueueProcessor:
    session_factory: async_sessionmaker[AsyncSession]
    slack_sender: SlackSenderProtocol
    token_resolver: ConnectorTokenResolver | None = None
    memory_writer: object | None = None
    review_client: object | None = None
    gitlab_client_factory: GitLabClientFactory | None = None
    jira_client_factory: JiraClientFactory | None = None
    confluence_client_factory: ConfluenceClientFactory | None = None
    skill_catalog: SkillCatalogService | None = None

    MANUAL_REQUIRED_SLACK_ERROR_CODES = {
        "invalid_auth",
        "missing_scope",
        "not_in_channel",
        "channel_not_found",
        "thread_not_found",
        "message_not_found",
    }

    async def process_once(self) -> list[str]:
        return []  # OutboundMessage model deleted

    async def _process_row(self, outbound_id: str) -> str:
        return "missing"  # OutboundMessage model deleted

    async def _resolve_preflight_block(
        self,
        *,
        session: AsyncSession,
        case: Case | None,
    ) -> tuple[str, str] | None:
        return None  # OutboundMessage model deleted

    @staticmethod
    def _sanitize_approved_payload(payload: dict[str, Any]) -> dict[str, Any]:
        return {
            key: value
            for key, value in payload.items()
            if key
            not in {
                "approvalRequired",
                "approvedByUserId",
                "approvedAt",
                "approvalSource",
                "approvedPayloadHash",
                "intentId",
                "token",
                "writeDraftId",
            }
        }

    @staticmethod
    async def _mark_connector_attention(
        *,
        session: AsyncSession,
        connector_type: ConnectorType,
        error: str,
        error_code: str,
    ) -> None:
        row = (
            await session.execute(
                select(CredentialBindingMetadata).where(
                    CredentialBindingMetadata.connector_type == connector_type
                )
            )
        ).scalars().first()
        if row is None:
            return
        row.metadata_json = {
            **row.metadata_json,
            "manualActionRequired": True,
            "lastError": error,
            "lastErrorCode": error_code,
        }

    @staticmethod
    async def _clear_connector_attention(
        *,
        session: AsyncSession,
        connector_type: ConnectorType,
    ) -> None:
        row = (
            await session.execute(
                select(CredentialBindingMetadata).where(
                    CredentialBindingMetadata.connector_type == connector_type
                )
            )
        ).scalars().first()
        if row is None:
            return
        row.metadata_json = {
            **row.metadata_json,
            "manualActionRequired": False,
            "lastError": None,
            "lastErrorCode": None,
        }

    @staticmethod
    async def _load_connector_binding(
        *,
        session: AsyncSession,
        connector_type: ConnectorType,
    ) -> CredentialBindingMetadata | None:
        return (
            await session.execute(
                select(CredentialBindingMetadata).where(
                    CredentialBindingMetadata.connector_type == connector_type
                )
            )
        ).scalars().first()

    def _resolve_revoked_skill_ids(self, case: Case | None) -> list[str]:
        if case is None:
            return []
        provenance_rows = case.payload_json.get("skillProvenance")
        if not isinstance(provenance_rows, list) or not provenance_rows:
            return []
        catalog = self.skill_catalog or self._build_skill_catalog()
        if catalog is None:
            return []
        snapshot = catalog.load()
        revoked_skill_ids: list[str] = []
        for row in provenance_rows:
            if not isinstance(row, dict):
                continue
            skill_id = str(row.get("skillId") or "").strip()
            if not skill_id:
                continue
            entry = snapshot.get(skill_id)
            if entry is None or entry.manifest.trust_state not in {
                SkillTrustState.builtin,
                SkillTrustState.trusted,
            }:
                revoked_skill_ids.append(skill_id)
        return revoked_skill_ids

    def _build_skill_catalog(self) -> SkillCatalogService | None:
        bind = self.session_factory.kw.get("bind")
        if bind is None or bind.url.database is None:
            return None
        return SkillCatalogService(SkillCatalogPaths.default())

    @staticmethod
    def _build_result_artifact_path(connector_type: ConnectorType, result_payload: Any) -> str:
        if connector_type == ConnectorType.slack:
            if isinstance(result_payload, dict):
                channel = str(result_payload.get("channel") or "unknown").strip() or "unknown"
                ts = str(result_payload.get("ts") or "unknown").strip() or "unknown"
                return f"slack/{channel}/{ts}"
            return "slack/unknown/unknown"
        if connector_type == ConnectorType.gitlab:
            note_id = str((result_payload or {}).get("id") or "unknown").strip() if isinstance(result_payload, dict) else "unknown"
            return f"gitlab/notes/{note_id or 'unknown'}"
        if connector_type == ConnectorType.jira:
            comment_id = str((result_payload or {}).get("id") or "unknown").strip() if isinstance(result_payload, dict) else "unknown"
            return f"jira/comments/{comment_id or 'unknown'}"
        comment_id = str((result_payload or {}).get("id") or "unknown").strip() if isinstance(result_payload, dict) else "unknown"
        return f"confluence/comments/{comment_id or 'unknown'}"

    async def _report_interactive_outcome(
        self,
        case: Case | None,
        *,
        status: str,
        result_payload: dict[str, Any],
    ) -> None:
        if case is None or case.source != CaseSource.w10w225_direct_request or self.review_client is None:
            return
        write_draft_id = str(case.payload_json.get("writeDraftId") or "").strip()
        agent_session_id = str(case.payload_json.get("agentSessionId") or "").strip()
        if write_draft_id and hasattr(self.review_client, "update_agent_write_draft_status"):
            await self.review_client.update_agent_write_draft_status(
                write_draft_id,
                AgentWriteDraftStatusPayload(
                    status="executed" if status == "completed" else status,
                    executionResult=result_payload,
                ),
            )
        if agent_session_id and hasattr(self.review_client, "post_agent_session_message"):
            message = "Completed approved action." if status == "completed" else f"Action {status}."
            attachment_note = build_attachment_session_note(case.payload_json)
            attachment_metadata = build_attachment_session_metadata(case.payload_json)
            if attachment_note:
                message = f"{message}\n\n{attachment_note}"
            await self.review_client.post_agent_session_message(
                agent_session_id,
                AgentSessionMessagePayload(
                    messageType="result",
                    text=message,
                    metadata={
                        "caseId": case.id,
                        "status": status,
                        "result": result_payload,
                        **(
                            {
                                "attachmentHandling": str(attachment_metadata.get("attachmentHandling") or "").strip(),
                                "attachmentSummary": attachment_metadata,
                            }
                            if attachment_metadata is not None
                            else {}
                        ),
                    },
                ),
            )

    async def _record_case_audit(self, case_id: str, *, event_type: str, payload: dict) -> None:
        async with self.session_factory() as session:
            session.add(
                AuditEvent(
                    event_type=event_type,
                    entity_type="case",
                    entity_id=case_id,
                    payload_json=payload,
                )
            )
            await session.commit()


def _artifact_type_for_connector(connector_type: ConnectorType) -> str:
    if connector_type == ConnectorType.slack:
        return "slack_send_receipt"
    if connector_type == ConnectorType.gitlab:
        return "gitlab_note_receipt"
    if connector_type == ConnectorType.jira:
        return "jira_comment_receipt"
    return "confluence_comment_receipt"
