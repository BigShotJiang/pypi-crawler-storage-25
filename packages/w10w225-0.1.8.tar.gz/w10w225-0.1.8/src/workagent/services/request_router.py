from __future__ import annotations

import logging
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from workagent.db.enums import AgentPendingItemType, CaseStatus
from workagent.db.models import Case
from workagent.sync.models import AgentPendingItemRecord

logger = logging.getLogger(__name__)


class RequestRouter:
    def __init__(
        self,
        *,
        chat_pipeline,  # noqa: ANN001
        document_pipeline,  # noqa: ANN001
        session_factory: async_sessionmaker[AsyncSession] | None = None,
    ) -> None:
        self.chat_pipeline = chat_pipeline
        self.document_pipeline = document_pipeline
        self.session_factory = session_factory

    async def process_next(self) -> bool:
        """Process the next queued scheduled case, if any."""
        if self.session_factory is None:
            return False
        case = await self._dequeue_next_scheduled_case()
        if case is None:
            return False
        # Convert scheduled case to a synthetic pending item for ChatPipeline
        task_text = str((case.payload_json or {}).get("taskText") or case.title or "").strip()
        synthetic_item = AgentPendingItemRecord(
            id=str(case.id),
            sessionId=None,
            threadId=f"scheduled:{case.id}",
            messageId=None,
            itemType=AgentPendingItemType.new_direct_request.value,
            payload={"requestText": task_text, **(case.payload_json or {})},
        )
        try:
            await self.chat_pipeline.handle_new_request(synthetic_item)
            await self._mark_case_completed(str(case.id))
        except Exception:
            logger.exception("Failed to process scheduled case %s", case.id)
            await self._mark_case_failed(str(case.id))
        return True

    async def route(self, pending_item: AgentPendingItemRecord) -> None:
        item_type = AgentPendingItemType(pending_item.item_type)
        if item_type is AgentPendingItemType.new_direct_request:
            await self.chat_pipeline.handle_new_request(pending_item)
            return
        if item_type is AgentPendingItemType.interactive_user_reply:
            await self.chat_pipeline.handle_reply(pending_item)
            return
        if item_type is AgentPendingItemType.interactive_execution_decision:
            await self.chat_pipeline.handle_decision(pending_item)
            return
        await self.document_pipeline.execute(pending_item)

    async def _dequeue_next_scheduled_case(self) -> Any | None:
        async with self.session_factory() as session:
            row = (
                await session.exec(  # type: ignore[union-attr]
                    select(Case)
                    .where(Case.status == CaseStatus.queued_for_local_run)
                    .order_by(Case.created_at.asc())
                    .limit(1)
                )
            ).first()
            if row is None:
                return None
            row.status = CaseStatus.running
            await session.commit()
            await session.refresh(row)
            return row

    async def _mark_case_completed(self, case_id: str) -> None:
        async with self.session_factory() as session:
            case = await session.get(Case, case_id)
            if case is not None:
                case.status = CaseStatus.completed
                await session.commit()

    async def _mark_case_failed(self, case_id: str) -> None:
        async with self.session_factory() as session:
            case = await session.get(Case, case_id)
            if case is not None:
                case.status = CaseStatus.failed
                await session.commit()
