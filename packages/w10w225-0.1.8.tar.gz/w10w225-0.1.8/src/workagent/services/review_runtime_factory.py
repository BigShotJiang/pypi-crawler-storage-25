from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from workagent.db.models import AppSetting
from workagent.services.review_sync import ReviewCommandSyncService
from workagent.sync.poller import ReviewCommandPoller
from workagent.sync.runtime import ReviewSyncCycleSummary, ReviewSyncRuntime


class ReviewCommandCursorStore:
    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self.session_factory = session_factory

    async def load(self) -> str | None:
        async with self.session_factory() as session:
            row = await session.get(AppSetting, "review_command_cursor")
            if row is None:
                return None
            return str(row.value_json.get("cursor") or "").strip() or None

    async def save(self, cursor: str | None) -> None:
        async with self.session_factory() as session:
            row = await session.get(AppSetting, "review_command_cursor")
            payload = {"cursor": cursor}
            if row is None:
                row = AppSetting(key="review_command_cursor", value_json=payload)
                session.add(row)
            else:
                row.value_json = payload
            await session.commit()


@dataclass(frozen=True, slots=True)
class ReviewSyncRuntimeState:
    failure_count: int
    last_error: str | None
    next_allowed_at: datetime | None
    last_success_at: datetime | None


class ReviewSyncRuntimeStateStore:
    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self.session_factory = session_factory

    async def load(self) -> ReviewSyncRuntimeState:
        async with self.session_factory() as session:
            row = await session.get(AppSetting, "review_sync_runtime_state")
            payload = row.value_json if row is not None else {}
        return ReviewSyncRuntimeState(
            failure_count=int(payload.get("failure_count") or 0),
            last_error=str(payload.get("last_error") or "").strip() or None,
            next_allowed_at=_parse_datetime(payload.get("next_allowed_at")),
            last_success_at=_parse_datetime(payload.get("last_success_at")),
        )

    async def save_success(self, *, at: datetime | None = None) -> None:
        timestamp = _normalize_datetime(at)
        await self._save(
            {
                "failure_count": 0,
                "last_error": None,
                "next_allowed_at": None,
                "last_success_at": timestamp.isoformat(),
            }
        )

    async def save_failure(self, *, error: str, at: datetime | None = None, base_backoff_seconds: int = 30) -> None:
        timestamp = _normalize_datetime(at)
        current = await self.load()
        failure_count = current.failure_count + 1
        next_allowed_at = timestamp + timedelta(seconds=base_backoff_seconds * failure_count)
        await self._save(
            {
                "failure_count": failure_count,
                "last_error": error,
                "next_allowed_at": next_allowed_at.isoformat(),
                "last_success_at": current.last_success_at.isoformat() if current.last_success_at else None,
            }
        )

    async def _save(self, payload: dict) -> None:
        async with self.session_factory() as session:
            row = await session.get(AppSetting, "review_sync_runtime_state")
            if row is None:
                row = AppSetting(key="review_sync_runtime_state", value_json=payload)
                session.add(row)
            else:
                row.value_json = payload
            await session.commit()


class ManagedReviewSyncRuntime:
    def __init__(
        self,
        *,
        runtime: ReviewSyncRuntime,
        state_store: ReviewSyncRuntimeStateStore,
        base_backoff_seconds: int = 30,
    ) -> None:
        self.runtime = runtime
        self.state_store = state_store
        self.base_backoff_seconds = base_backoff_seconds

    async def run_cycle(self) -> ReviewSyncCycleSummary:
        state = await self.state_store.load()
        now = datetime.now(UTC)
        if state.next_allowed_at is not None and now < state.next_allowed_at:
            return ReviewSyncCycleSummary(total_commands=0, completed_commands=0, failed_commands=0)
        try:
            summary = await self.runtime.run_cycle()
        except Exception as exc:  # noqa: BLE001
            await self.state_store.save_failure(
                error=str(exc),
                at=now,
                base_backoff_seconds=self.base_backoff_seconds,
            )
            return ReviewSyncCycleSummary(total_commands=0, completed_commands=0, failed_commands=0)
        await self.state_store.save_success(at=now)
        return summary


def _parse_datetime(raw_value) -> datetime | None:  # noqa: ANN001
    if not raw_value:
        return None
    value = datetime.fromisoformat(str(raw_value))
    if value.tzinfo is None:
        value = value.replace(tzinfo=UTC)
    return value.astimezone(UTC)


def _normalize_datetime(value: datetime | None) -> datetime:
    if value is None:
        return datetime.now(UTC)
    if value.tzinfo is None:
        return value.replace(tzinfo=UTC)
    return value.astimezone(UTC)


def build_review_sync_runtime(
    *,
    session_factory: async_sessionmaker[AsyncSession],
    review_client,
    base_backoff_seconds: int = 30,
    queue=None,  # noqa: ANN001
    memory_writer: object | None = None,
    graph_processor=None,  # noqa: ANN001
):
    if review_client is None:
        return None
    cursor_store = ReviewCommandCursorStore(session_factory)
    poller = ReviewCommandPoller(client=review_client, cursor_store=cursor_store)
    service = ReviewCommandSyncService(
        session_factory=session_factory,
        poller=poller,
        sync_api=review_client,
        queue=queue,
        memory_writer=memory_writer,
        graph_processor=graph_processor,
    )
    return ManagedReviewSyncRuntime(
        runtime=ReviewSyncRuntime(sync_service=service),
        state_store=ReviewSyncRuntimeStateStore(session_factory),
        base_backoff_seconds=base_backoff_seconds,
    )
