"""
AlgoGTT Python SDK
==================
A lightweight client for interacting with the AlgoGTT Strategy Export API.
"""

import requests
import pandas as pd
import io
from .version import __version__

class Client:
    """
    Main client for AlgoGTT API.
    
    Args:
        api_key (str): Your STS API Key from the Profile page.
        base_url (str): The base URL of the AlgoGTT API.
    """
    def __init__(self, api_key, base_url="https://api.algogtt.in/api/v1"):
        self.api_key = api_key
        self.base_url = base_url.rstrip('/')
        self.headers = {
            "X-API-KEY": api_key,
            "User-Agent": f"AlgoGTT-Python-SDK/{__version__}"
        }

    def get_signals(self, symbol: str, strategy: str, format: str = "csv"):
        """
        Fetch strategy signals for a specific symbol.
        
        Args:
            symbol (str): Symbol name (e.g., NIFTY, BANKNIFTY).
            strategy (str): Strategy name (e.g., swing_breakout).
            format (str): 'csv' or 'json'.
            
        Returns:
            pd.DataFrame or dict: Signals data.
        """
        url = f"{self.base_url}/export/signals"
        params = {"symbol": symbol, "strategy": strategy, "format": format}
        
        response = requests.get(url, headers=self.headers, params=params)
        response.raise_for_status()
        
        if format == "csv":
            return pd.read_csv(io.StringIO(response.text), index_col='datetime', parse_dates=True)
        return response.json()

    def compute_signals(self, symbol: str, strategy: str, data: list, parameters: dict = None, format: str = "csv"):
        """
        Send custom OHLCV data to compute signals dynamically.
        
        Args:
            symbol (str): Symbol name.
            strategy (str): Strategy name.
            data (list): List of dicts with OHLCV data.
            parameters (dict): Optional strategy parameters to tweak.
            format (str): 'csv' or 'json'.
            
        Returns:
            pd.DataFrame or dict: Signals data.
        """
        url = f"{self.base_url}/export/signals/compute"
        payload = {
            "symbol": symbol,
            "strategy": strategy,
            "data": data,
            "parameters": parameters or {},
            "format": format
        }
        
        response = requests.post(url, headers=self.headers, json=payload)
        response.raise_for_status()
        
        if format == "csv":
            return pd.read_csv(io.StringIO(response.text), index_col='datetime', parse_dates=True)
        return response.json()

    def get_account_status(self):
        """Check API key validity and license status."""
        url = f"{self.base_url}/account/status"
        response = requests.get(url, headers=self.headers)
        response.raise_for_status()
        return response.json()
