# AlgoGTT Python SDK

Official Python client for the [AlgoGTT](https://algogtt.in) Strategy Export API. This SDK allows quants and developers to fetch strategy signals and compute custom signals using the AlgoGTT backend.

## Installation

```bash
pip install algogtt
```

## Quick Start

### 1. Initialize Client
Get your **STS API Key** from the Profile page on the AlgoGTT dashboard.

```python
from algogtt import Client

client = Client(api_key="STS_your_api_key_here")
```

### 2. Fetch Historical Signals
Fetch signals generated on AlgoGTT's internal data.

```python
df = client.get_signals(symbol="NIFTY", strategy="swing_breakout")
print(df.tail())
```

### 3. Compute Signals on Custom Data
Inject your own OHLCV data to see how AlgoGTT strategies perform on it.

```python
custom_data = [
    {"datetime": "2024-01-01 09:15:00", "open": 21000, "high": 21050, "low": 20950, "close": 21020, "volume": 1000},
    # ... more rows
]

df = client.compute_signals(
    symbol="NIFTY", 
    strategy="swing_breakout", 
    data=custom_data
)
```

## Integration with VectorBT

```python
import vectorbt as vbt
from algogtt import Client

client = Client(api_key="...")
df = client.get_signals(symbol="NIFTY", strategy="swing_breakout")

portfolio = vbt.Portfolio.from_signals(
    df['Close'],
    entries=df['buy_signal'],
    exits=df['sell_signal'],
    freq='1m'
)
print(portfolio.stats())
```

## Support
For API keys and support, visit [algogtt.in](https://algogtt.in).
