from setuptools import setup, find_packages
import os

# Read version from version.py
version = {}
with open(os.path.join("algogtt", "version.py")) as f:
    exec(f.read(), version)

setup(
    name="algogtt",
    version=version["__version__"],
    author="Miten Solanki",
    author_email="algogtt@gmail.com",
    description="Python SDK for AlgoGTT Strategy Export API",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/vrsolankiGH/SwingTradingSystem",
    packages=find_packages(),
    install_requires=[
        "requests>=2.25.0",
        "pandas>=1.0.0",
    ],
    license="MIT",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "Topic :: Office/Business :: Financial :: Investment",
    ],
    python_requires=">=3.7",
)
