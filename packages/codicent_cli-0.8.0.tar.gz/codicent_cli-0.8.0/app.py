import sys
import os
import logging
import glob
import requests
import base64
import json
import re
import subprocess
from codicentpy import Codicent
from rich.console import Console
from rich.markdown import Markdown
from prompt_toolkit import prompt
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.keys import Keys
from prompt_toolkit.filters import Condition
from auth import CodicentAuth

# Configure logging
logging.basicConfig(level=logging.WARNING, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)

def show_help():
    """Display help information."""
    help_text = """
Codicent CLI - Command-line interface for the Codicent API

USAGE:
    codicent [OPTIONS] [QUESTION]
    codicent [OPTIONS] < file.txt
    echo "question" | codicent [OPTIONS]
    codicent upload <file_pattern> [<file_pattern> ...]

OPTIONS:
    -t, --interactive    Start interactive chat mode
    -h, --help          Show this help message
    -v, --version       Show version information
    --verbose           Enable verbose logging
    --quiet             Suppress non-essential output

AUTHENTICATION:
    auth                Authenticate using device flow (project selected during web auth)
    auth --local        Authenticate and store token in the current directory (.codicent_token)
    logout              Clear stored global authentication
    logout --local      Clear only the local (.codicent_token) token in the current directory
    status              Check authentication status (shows whether local or global token is used)

FILE UPLOAD:
    upload              Upload files and post messages with tags
    
    Example:
        codicent upload file.txt *.log
        
    This uploads the files and posts a message for each file with:
        @project #index #summarize #file:FILE_GUID

    PROJECT INIT:
    init                Initialize current project with a template
    
        --list              List available templates with descriptions
        --template NAME     Use a specific template (default: 'default')
        --dry-run           Preview messages without posting (no auth needed)
        --force             Re-initialize even if project already has #instructions
    
    Templates:
        default             General-purpose: task workflow + auto-summarize notes
        koi-studio          CRM: lead extraction + follow-up email drafting pipeline
        document-processing Document intake: extract, structure, and review documents
    
    Examples:
        codicent init
        codicent init --template koi-studio
        codicent init --template document-processing --dry-run
        codicent init --list
        codicent init --force

WRAP (AI CLI Remote Bridge):
    wrap                Bridge a local AI CLI tool to a remote codicent chat session.
                        Remote users and AI can interact with the locally running tool.
    
        <tool>              Tool to wrap: claude, codex, opencode, or any CLI tool
        [tool-args...]      Arguments passed through to the wrapped tool
        --label TEXT        Session label shown in codicent UI (default: "<tool> session")
        --binary PATH       Explicit path to the tool binary
        --poll-interval N   Seconds between input polls (default: 2)
    
    How it works:
        1. Starts the tool as a local subprocess
        2. Posts tool output to codicent tagged #wrap #wrap_<id> #output
        3. Polls for messages tagged #wrap #wrap_<id> #input and writes them to stdin
        4. Remote users tag messages with #wrap_<id> #input to send text to the tool
    
    Config file (~/.codicent/wrap-config.yaml):
        poll_interval: 2
        output_batch_ms: 500
        tools:
          claude:
            binary: claude
        auto_responses:
          - pattern: "Do you want to continue"
            reply: "y"
    
    Examples:
        codicent wrap claude
        codicent wrap --label "Refactor session" opencode
        codicent wrap --poll-interval 5 codex
        codicent wrap --binary /usr/local/bin/claude claude --model claude-opus-4-5

EXAMPLES:
    codicent auth
    codicent "What is Python?"
    codicent -t
    codicent "@mention Hello there"
    codicent upload document.txt *.log
    codicent init --template koi-studio
    codicent wrap claude
    echo "Help me debug this" | codicent

ENVIRONMENT:
    CODICENT_TOKEN     Your Codicent API token (fallback if no cached auth)

For more information, visit: https://github.com/izaxon/codicent-cli
"""
    print(help_text.strip())

def show_version():
    """Display version information."""
    print("Codicent CLI v0.8.0")

def validate_input(question):
    """Validate user input."""
    if not question or not question.strip():
        return False, "Empty question provided"
    
    if len(question) > 10000:  # Reasonable limit
        return False, "Question too long (max 10,000 characters)"
    
    return True, None

def main():
    console = Console()
    
    # Parse command line arguments
    if "-h" in sys.argv or "--help" in sys.argv:
        show_help()
        return 0
    
    if "-v" in sys.argv or "--version" in sys.argv:
        show_version()
        return 0
    
    # Set logging level based on flags
    if "--verbose" in sys.argv:
        logging.getLogger().setLevel(logging.INFO)
        sys.argv.remove("--verbose")
        logger.info("Verbose logging enabled")
    
    if "--quiet" in sys.argv:
        logging.getLogger().setLevel(logging.ERROR)
        sys.argv.remove("--quiet")
    
    # Parse --local flag (store/remove token in current working directory)
    use_local = "--local" in sys.argv
    if use_local:
        sys.argv.remove("--local")
    
    # Initialize auth handler
    auth = CodicentAuth()
    
    # Handle authentication commands
    if len(sys.argv) > 1 and sys.argv[1] in ["auth", "logout", "status"]:
        command = sys.argv[1]
        
        if command == "auth":
            token = auth.get_token(force_reauth=True, local=use_local)
            if token:
                console.print("[green]✅ Authentication successful![/green]")
                return 0
            else:
                console.print("[red]❌ Authentication failed[/red]")
                return 1
        
        elif command == "logout":
            auth.logout(local=use_local)
            return 0
        
        elif command == "status":
            source = auth.get_token_source()
            if source:
                console.print(f"[green]✅ Authenticated[/green] [dim]({source})[/dim]")
                return 0
            else:
                env_token = os.getenv("CODICENT_TOKEN")
                if env_token:
                    console.print("[yellow]⚠ Using CODICENT_TOKEN environment variable[/yellow]")
                    console.print("[dim]Consider running 'codicent auth' to use persistent authentication[/dim]")
                    return 0
                else:
                    console.print("[red]❌ Not authenticated[/red]")
                    console.print("[dim]Run 'codicent auth' to authenticate[/dim]")
                    return 1
    
    # Handle upload command
    if len(sys.argv) > 1 and sys.argv[1] == "upload":
        if len(sys.argv) < 3:
            console.print("[red]❌ Error: No files specified for upload[/red]")
            console.print("[dim]Usage: codicent upload <file_pattern> [<file_pattern> ...][/dim]")
            console.print("[dim]Example: codicent upload file.txt *.log[/dim]")
            return 1
        
        # Get authentication token
        token = auth.get_cached_token()
        if not token:
            # Fallback to environment variable
            token = os.getenv("CODICENT_TOKEN")
            if not token:
                console.print("[red]❌ No authentication found.[/red]")
                console.print("[dim]Run 'codicent auth' to authenticate, or set CODICENT_TOKEN environment variable[/dim]")
                return 1
            else:
                logger.info("Using CODICENT_TOKEN environment variable")
        
        # Initialize API client with error handling
        try:
            codicent = Codicent(token)
            logger.info("Codicent API client initialized successfully")
        except Exception as e:
            console.print(f"[red]❌ Failed to initialize Codicent API client: {e}[/red]")
            logger.error(f"API client initialization failed: {e}")
            console.print("[dim]Try running 'codicent auth' to re-authenticate[/dim]")
            return 1
        
        # Extract project from JWT token
        try:
            payload = token.split(".")[1]
            payload += '=' * (-len(payload) % 4)
            decoded_payload = base64.urlsafe_b64decode(payload).decode('utf-8')
            jwt_data = json.loads(decoded_payload)
            project = jwt_data["project"]
        except Exception as e:
            console.print(f"[red]❌ Failed to extract project from token: {e}[/red]")
            return 1
        
        # Collect all files from patterns
        file_patterns = sys.argv[2:]
        files_to_upload = []
        
        for pattern in file_patterns:
            matched_files = glob.glob(pattern)
            if matched_files:
                files_to_upload.extend(matched_files)
            else:
                # If no glob match, check if it's a direct file path
                if os.path.isfile(pattern):
                    files_to_upload.append(pattern)
                else:
                    console.print(f"[yellow]⚠ Warning: No files found matching pattern '{pattern}'[/yellow]")
        
        if not files_to_upload:
            console.print("[red]❌ Error: No files found to upload[/red]")
            return 1
        
        # Remove duplicates while preserving order
        files_to_upload = list(dict.fromkeys(files_to_upload))
        
        console.print(f"[dim]Found {len(files_to_upload)} file(s) to upload[/dim]")
        
        # Upload each file and post a message
        uploaded_count = 0
        failed_count = 0
        
        for filepath in files_to_upload:
            try:
                filename = os.path.basename(filepath)
                console.print(f"[dim]Uploading {filename}...[/dim]")
                
                with console.status(f"[dim]Uploading {filename}...[/dim]", spinner="dots"):
                    # Upload the file
                    with open(filepath, 'rb') as file:
                        url = f"{codicent.base_url}app/UploadFile"
                        files = {"file": file}
                        params = {"filename": filename}
                        response = requests.post(url, files=files, params=params, verify=codicent.verify_https)
                        if response.ok:
                            file_guid = response.json()
                        else:
                            raise Exception(f"Upload failed: {response.status_code} - {response.text}")

                    # Post a message with the file reference
                    # Get project name from first @ mention if available, otherwise use @myproject
                    message = f"@{project} #index #summarize #file:{file_guid}"
                    codicent.post_message(message, type="info")
                
                console.print(f"[green]✅ Uploaded: {filename} (File ID: {file_guid})[/green]")
                uploaded_count += 1
                
            except FileNotFoundError:
                console.print(f"[red]❌ File not found: {filepath}[/red]")
                failed_count += 1
            except PermissionError:
                console.print(f"[red]❌ Permission denied: {filepath}[/red]")
                failed_count += 1
            except Exception as e:
                console.print(f"[red]❌ Failed to upload {filename}: {e}[/red]")
                logger.error(f"Upload failed for {filepath}: {e}")
                failed_count += 1
        
        # Summary
        console.print()
        console.print(f"[bold]Upload Summary:[/bold]")
        console.print(f"  [green]✅ Uploaded: {uploaded_count}[/green]")
        if failed_count > 0:
            console.print(f"  [red]❌ Failed: {failed_count}[/red]")
        
        return 0 if failed_count == 0 else 1

    # Handle init command
    if len(sys.argv) > 1 and sys.argv[1] == "init":
        templates_dir = os.path.join(os.path.dirname(__file__), "templates")

        dry_run = "--dry-run" in sys.argv
        force = "--force" in sys.argv

        # --list: show available templates
        if "--list" in sys.argv:
            try:
                available = [os.path.splitext(f)[0] for f in os.listdir(templates_dir) if f.endswith(".json")]
                console.print("[bold]Available templates:[/bold]")
                for name in sorted(available):
                    template_path = os.path.join(templates_dir, f"{name}.json")
                    with open(template_path, encoding="utf-8") as fh:
                        meta = json.load(fh)
                    vars_info = ""
                    if meta.get("variables"):
                        vars_info = f" [dim]({len(meta['variables'])} variable(s))[/dim]"
                    console.print(f"  [bold bright_cyan]{name}[/bold bright_cyan]{vars_info} — {meta.get('description', '')}")
            except Exception as e:
                console.print(f"[red]❌ Error listing templates: {e}[/red]")
            return 0

        # Resolve template name
        template_name = "default"
        if "--template" in sys.argv:
            idx = sys.argv.index("--template")
            if idx + 1 < len(sys.argv):
                template_name = sys.argv[idx + 1]
            else:
                console.print("[red]❌ --template requires a name. Use 'codicent init --list' to see options.[/red]")
                return 1

        template_path = os.path.join(templates_dir, f"{template_name}.json")
        if not os.path.isfile(template_path):
            console.print(f"[red]❌ Template '{template_name}' not found. Use 'codicent init --list' to see options.[/red]")
            return 1

        with open(template_path, encoding="utf-8") as fh:
            template = json.load(fh)

        # Resolve variables: prompt for any without defaults
        variable_values = {}
        template_variables = template.get("variables", {})
        for var_name, var_meta in template_variables.items():
            default = var_meta.get("default", "")
            description = var_meta.get("description", var_name)
            if dry_run:
                # In dry-run, use defaults without prompting
                variable_values[var_name] = default or f"{{{var_name}}}"
            elif default:
                variable_values[var_name] = default
                console.print(f"[dim]  {var_name}: {default} (default)[/dim]")
            else:
                value = input(f"  {description}: ").strip()
                if not value:
                    console.print(f"[red]❌ Variable '{var_name}' is required.[/red]")
                    return 1
                variable_values[var_name] = value

        def apply_variables(text, project):
            result = text.replace("{project}", project)
            for var_name, var_value in variable_values.items():
                result = result.replace("{" + var_name + "}", var_value)
            return result

        # --- Dry-run mode: print plan without calling API ---
        if dry_run:
            messages = template.get("messages", [])
            console.print(f"\n[bold]Dry run — template [bright_cyan]{template_name}[/bright_cyan] ({len(messages)} messages)[/bold]")
            console.print(f"[dim]No messages will be posted. Remove --dry-run to execute.[/dim]\n")
            for i, entry in enumerate(messages, 1):
                label = entry.get("label", f"Message {i}")
                content = apply_variables(entry["content"], "{project}")
                # Show first 120 chars of content
                preview = content.replace("\n", "  ↵  ")
                if len(preview) > 120:
                    preview = preview[:117] + "..."
                console.print(f"  [bold]{i}.[/bold] [bright_cyan]{label}[/bright_cyan]")
                console.print(f"     [dim]{preview}[/dim]")
            console.print()
            return 0

        # Get authentication token
        token = auth.get_cached_token()
        if not token:
            token = os.getenv("CODICENT_TOKEN")
            if not token:
                console.print("[red]❌ No authentication found.[/red]")
                console.print("[dim]Run 'codicent auth' to authenticate, or set CODICENT_TOKEN environment variable[/dim]")
                return 1

        # Extract project from JWT token
        try:
            payload = token.split(".")[1]
            payload += '=' * (-len(payload) % 4)
            decoded_payload = base64.urlsafe_b64decode(payload).decode('utf-8')
            jwt_data = json.loads(decoded_payload)
            project = jwt_data["project"]
        except Exception as e:
            console.print(f"[red]❌ Failed to extract project from token: {e}[/red]")
            return 1

        try:
            codicent = Codicent(token)
        except Exception as e:
            console.print(f"[red]❌ Failed to initialize Codicent API client: {e}[/red]")
            return 1

        # Idempotency check: warn if #instructions already exists in this project
        if not force:
            try:
                headers = {"Authorization": f"Bearer {token}"}
                check_url = f"{codicent.base_url}api/GetMessages"
                resp = requests.get(
                    check_url,
                    params={"mention": project, "tags": "instructions", "length": "1"},
                    headers=headers,
                    verify=codicent.verify_https,
                    timeout=10,
                )
                if resp.ok and resp.json():
                    console.print(f"[yellow]⚠ Project [bold]{project}[/bold] already has #instructions — it may have been initialized before.[/yellow]")
                    console.print("[dim]Pass --force to initialize anyway, or --dry-run to preview what would be posted.[/dim]")
                    return 1
            except Exception:
                logger.debug("Idempotency check failed (skipping)")

        messages = template.get("messages", [])
        console.print(f"Initializing [bold]{project}[/bold] with template [bold bright_cyan]{template_name}[/bold bright_cyan] ({len(messages)} messages)...")

        posted = 0
        failed = 0
        for i, entry in enumerate(messages, 1):
            label = entry.get("label", f"Message {i}")
            content = apply_variables(entry["content"], project)
            msg_type = entry.get("type", "info")
            try:
                with console.status(f"[dim]({i}/{len(messages)}) {label}...[/dim]", spinner="dots"):
                    codicent.post_message(content, type=msg_type)
                console.print(f"  [green]✓[/green] [dim]{label}[/dim]")
                posted += 1
            except Exception as e:
                console.print(f"  [red]✗ {label}: {e}[/red]")
                failed += 1

        console.print()
        console.print(f"[green]✅ Done — {posted} message(s) posted to {project}.[/green]")
        if failed:
            console.print(f"[red]❌ {failed} message(s) failed.[/red]")
        return 0 if failed == 0 else 1

    # Handle wrap command
    if len(sys.argv) > 1 and sys.argv[1] == "wrap":
        from wrap import run_wrap_command

        wrap_token = auth.get_cached_token()
        if not wrap_token:
            wrap_token = os.getenv("CODICENT_TOKEN")
        if not wrap_token:
            console.print("[red]❌ No authentication found.[/red]")
            console.print("[dim]Run 'codicent auth' to authenticate, or set CODICENT_TOKEN environment variable[/dim]")
            return 1

        # Extract project and base_url from JWT token
        try:
            wrap_payload = wrap_token.split(".")[1]
            wrap_payload += '=' * (-len(wrap_payload) % 4)
            wrap_jwt = json.loads(base64.urlsafe_b64decode(wrap_payload).decode('utf-8'))
            wrap_project = wrap_jwt["project"]
            wrap_base_url = wrap_jwt.get("baseUrl", "https://codicent.com/")
        except Exception as e:
            console.print(f"[red]❌ Failed to extract project from token: {e}[/red]")
            return 1

        # Pass everything after "wrap" as args
        wrap_args = sys.argv[2:]
        return run_wrap_command(
            args=wrap_args,
            token=wrap_token,
            base_url=wrap_base_url,
            project=wrap_project,
        )

    # Get authentication token
    token = auth.get_cached_token()
    if not token:
        # Fallback to environment variable
        token = os.getenv("CODICENT_TOKEN")
        if not token:
            console.print("[red]❌ No authentication found.[/red]")
            console.print("[dim]Run 'codicent auth' to authenticate, or set CODICENT_TOKEN environment variable[/dim]")
            return 1
        else:
            logger.info("Using CODICENT_TOKEN environment variable")
    
    # Initialize API client with error handling
    try:
        codicent = Codicent(token)
        logger.info("Codicent API client initialized successfully")
    except Exception as e:
        console.print(f"[red]❌ Failed to initialize Codicent API client: {e}[/red]")
        logger.error(f"API client initialization failed: {e}")
        console.print("[dim]Try running 'codicent auth' to re-authenticate[/dim]")
        return 1
    
    conversationId = None

    # Parse interactive mode flags
    interactive = False
    if "-t" in sys.argv or "--interactive" in sys.argv:
        interactive = True
        if "-t" in sys.argv:
            sys.argv.remove("-t")
        if "--interactive" in sys.argv:
            sys.argv.remove("--interactive")
    elif len(sys.argv) == 1:
        interactive = True
        
    # Get input based on mode (skip if we already handled auth commands)
    question = ""
    if not interactive:
        if len(sys.argv) < 2:
            if sys.stdin.isatty():
                console.print("Usage: codicent <question> or codicent < chat.txt or cat chat.txt | codicent or codicent (equal to codicent -t)")
                console.print("Use 'codicent --help' for more information.")
                return 1
            try:
                question = sys.stdin.read().strip()
            except (KeyboardInterrupt, EOFError):
                return 1
        else:
            question = " ".join(sys.argv[1:])
    else:
        if len(sys.argv) > 1:
            question = " ".join(sys.argv[1:])
        elif not sys.stdin.isatty():
            try:
                question = sys.stdin.read().strip()
            except (KeyboardInterrupt, EOFError):
                return 1

    def handle_question(question):
        nonlocal conversationId
        
        # Validate input
        is_valid, error_msg = validate_input(question)
        if not is_valid:
            print(f"Error: {error_msg}")
            logger.warning(f"Invalid input: {error_msg}")
            return False
        
        console = Console()
        
        try:
            if question.strip().startswith("@"):
                logger.info("Sending message to Codicent API")
                with console.status("[dim]Sending message...[/dim]", spinner="dots"):
                    response = codicent.post_message(question, type="info")
                console.print("[green]✅ Message posted successfully.[/green]")
            else:
                logger.info("Sending chat reply to Codicent API")
                with console.status("[dim]🤔 Thinking...[/dim]", spinner="dots"):
                    response = codicent.post_chat_reply(question, conversationId)
                conversationId = response["id"]
                logger.info(f"Updated conversation ID: {conversationId}")
                
                # Show bot response with markdown formatting in green
                if interactive:
                    console.print()
                
                content = response["content"]
                
                # Detect shell: markers in AI response
                shell_commands = re.findall(r'^shell:(.+)$', content, re.MULTILINE)
                
                # Also detect ```shell code blocks
                shell_blocks = re.findall(r'```shell\n(.*?)```', content, re.DOTALL)
                
                # Create markdown with green styling
                from rich.text import Text
                markdown_content = Markdown(content)
                console.print(markdown_content, style="green")
                console.print()
                
                # Offer to run detected shell commands
                all_commands = shell_commands + [block.strip() for block in shell_blocks]
                for cmd in all_commands:
                    cmd = cmd.strip()
                    if not cmd:
                        continue
                    console.print(f"[bold yellow]Shell command detected:[/bold yellow] {cmd}")
                    if interactive:
                        try:
                            confirm = prompt("Run this command? (y/N) ")
                        except (KeyboardInterrupt, EOFError):
                            confirm = "n"
                        if confirm.strip().lower() == 'y':
                            console.print(f"[dim]Running: {cmd}[/dim]")
                            try:
                                # Run command with proper encoding handling for cross-platform compatibility
                                result = subprocess.run(
                                    cmd,
                                    shell=True,
                                    capture_output=True,
                                    text=True,
                                    timeout=60,
                                    encoding='utf-8',
                                    errors='replace'  # Replace invalid chars instead of failing
                                )

                                # Display output to user
                                if result.stdout:
                                    console.print(result.stdout)
                                if result.stderr:
                                    console.print(f"[red]{result.stderr}[/red]")
                                if result.returncode == 0:
                                    console.print(f"[green]Exit code: {result.returncode}[/green]")
                                else:
                                    console.print(f"[red]Exit code: {result.returncode}[/red]")

                                # Send command output back to AI chat so it can see the results
                                output_parts = []
                                output_parts.append(f"Command executed: `{cmd}`")
                                output_parts.append("")
                                if result.stdout:
                                    output_parts.append("Output:")
                                    output_parts.append("```")
                                    output_parts.append(result.stdout.strip())
                                    output_parts.append("```")
                                if result.stderr:
                                    output_parts.append("Errors:")
                                    output_parts.append("```")
                                    output_parts.append(result.stderr.strip())
                                    output_parts.append("```")
                                output_parts.append(f"Exit code: {result.returncode}")

                                command_output = "\n".join(output_parts)

                                # Post the output back to the chat
                                with console.status("[dim]Sending output to AI...[/dim]", spinner="dots"):
                                    response = codicent.post_chat_reply(command_output, conversationId)
                                conversationId = response["id"]

                                # Show AI's response to the command output
                                console.print()
                                console.print("[dim]AI response:[/dim]")
                                ai_response = response["content"]
                                markdown_content = Markdown(ai_response)
                                console.print(markdown_content, style="green")
                                console.print()

                            except subprocess.TimeoutExpired:
                                error_msg = "Command timed out after 60 seconds"
                                console.print(f"[red]{error_msg}[/red]")
                                # Send timeout info to AI
                                try:
                                    with console.status("[dim]Sending timeout info to AI...[/dim]", spinner="dots"):
                                        response = codicent.post_chat_reply(f"Command timed out: `{cmd}`", conversationId)
                                    conversationId = response["id"]
                                except Exception:
                                    pass  # Don't fail if we can't send the timeout
                            except Exception as e:
                                error_msg = f"Error: {e}"
                                console.print(f"[red]{error_msg}[/red]")
                                # Send error info to AI
                                try:
                                    with console.status("[dim]Sending error info to AI...[/dim]", spinner="dots"):
                                        response = codicent.post_chat_reply(f"Command failed: `{cmd}`\nError: {str(e)}", conversationId)
                                    conversationId = response["id"]
                                except Exception:
                                    pass  # Don't fail if we can't send the error
                        else:
                            console.print("[dim]Skipped.[/dim]")
                    else:
                        console.print("[dim]Use interactive mode (-t) to execute commands.[/dim]")
            
            return True
            
        except KeyboardInterrupt:
            console.print("\n[yellow]Operation cancelled by user[/yellow]")
            return False
        except ConnectionError as e:
            console.print(f"[red]Network error: Unable to connect to Codicent API[/red]")
            logger.error(f"Connection error: {e}")
            return False
        except Exception as e:
            console.print(f"[red]API error: {e}[/red]")
            logger.error(f"API call failed (CODICENT_API_TOKEN expired?): {e}")
            return False

    # Handle initial question if provided
    if question != "":
        success = handle_question(question)
        if not success and not interactive:
            return 1
    
    # Interactive mode loop
    if interactive:
        from rich.panel import Panel
        from rich.text import Text
        from rich.columns import Columns
        console = Console()

        logo = Text()
        logo.append("██", style="bold bright_cyan")
        logo.append("██\n", style="bold green")
        logo.append("██", style="bold green")
        logo.append("██", style="bold bright_cyan")

        header = Text()
        header.append("Codicent CLI", style="bold bright_cyan")
        header.append(" v0.8.0\n", style="bright_cyan")
        header.append("Type your questions or use Ctrl+C to exit.\n", style="dim")
        header.append("\n")
        header.append("Tip: ", style="bold dim")
        header.append("@message", style="bold bright_cyan")
        header.append(" to post an info message to your project\n", style="dim")
        header.append("Codicent uses AI, so always check for mistakes.", style="dim")

        content = Columns([logo, header], padding=(0, 2))
        console.print(Panel(content, border_style="bright_cyan", padding=(1, 2)))
        console.print("[dim]Enter: send | Alt+Enter: new line | Paste: multi-line supported[/dim]")
        
        # Create custom key bindings
        bindings = KeyBindings()

        @bindings.add(Keys.Enter)
        def _(event):
            """Enter submits the input."""
            event.current_buffer.validate_and_handle()

        @bindings.add(Keys.Escape, Keys.Enter)  # Alt+Enter
        def _(event):
            """Alt+Enter inserts a newline."""
            event.current_buffer.insert_text('\n')

        while True:
            try:
                # Use prompt_toolkit's prompt instead of input()
                question = prompt(
                    "¤ ",
                    multiline=True,
                    key_bindings=bindings,
                    prompt_continuation=""  # No continuation prompt for clean look
                )
            except KeyboardInterrupt:
                console.print("\n[yellow]👋 Goodbye![/yellow]")
                break
            except EOFError:
                break
            
            if question.strip() != "":
                handle_question(question)
                # Add a separator line after each interaction
                if question.strip() != "" and not question.strip().startswith("@"):
                    console.print("[dim]" + "─" * 50 + "[/dim]")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
