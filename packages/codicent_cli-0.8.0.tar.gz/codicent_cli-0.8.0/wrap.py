"""
codicent wrap — AI CLI Remote Chat Bridge

Wraps a local AI CLI tool (claude, codex, opencode, etc.) and bridges its
stdin/stdout to a Codicent chat conversation. Remote users can chat with the
locally running tool in real time via the Codicent web UI or ClientApp chat.

Conversation model:
  The session-open message (type "wrap-session") becomes the conversation root.
  Its returned id is the conversation_id = originalMessageId for all messages.
  All subsequent messages chain via parentId — forming a native Codicent chat.

Message types:
  Session root:  type="wrap-session"      (engine uses this to skip LLM processing)
  Tool output:   type="ai-chat-answer2"   (renders as bot bubble in ChatPage)
  User input:    type="ai-chat-prompt2"   (sent by ChatPage, detected by type prefix)
"""

import os
import sys
import time
import logging
import threading
import subprocess
import shutil
import re

import requests

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DEFAULT_CONFIG = {
    "poll_interval": 2,
    "output_batch_ms": 500,
    "tools": {},
    "auto_responses": [],
}

CONFIG_PATH = os.path.join(os.path.expanduser("~"), ".codicent", "wrap-config.yaml")


def load_config():
    """Load wrap config from ~/.codicent/wrap-config.yaml, falling back to defaults."""
    config = dict(DEFAULT_CONFIG)
    config["auto_responses"] = list(DEFAULT_CONFIG["auto_responses"])
    config["tools"] = dict(DEFAULT_CONFIG["tools"])

    if os.path.exists(CONFIG_PATH):
        try:
            import yaml
            with open(CONFIG_PATH, "r") as f:
                user_config = yaml.safe_load(f) or {}
            config.update(user_config)
            logger.info(f"Loaded wrap config from {CONFIG_PATH}")
        except Exception as e:
            logger.warning(f"Could not load wrap config from {CONFIG_PATH}: {e}")

    return config


def resolve_binary(tool_name, config, explicit_binary=None):
    """Resolve the binary path for a tool name."""
    if explicit_binary:
        return explicit_binary
    tool_config = config.get("tools", {}).get(tool_name, {})
    if isinstance(tool_config, dict):
        binary = tool_config.get("binary", tool_name)
    else:
        binary = str(tool_config)
    resolved = shutil.which(binary)
    if resolved:
        return resolved
    return binary


# ---------------------------------------------------------------------------
# Session
# ---------------------------------------------------------------------------

class WrapSession:
    """
    Manages a single wrap session: subprocess lifecycle, output capture,
    remote input polling, and codicent message posting.
    """

    def __init__(self, tool_name, tool_args, token, base_url, project,
                 label=None, explicit_binary=None, poll_interval=None,
                 verify_https=True):
        self.tool_name = tool_name
        self.tool_args = tool_args or []
        self.token = token
        self.base_url = base_url.rstrip("/") + "/"
        self.project = project
        self.verify_https = verify_https

        self.config = load_config()
        self.poll_interval = poll_interval or self.config.get("poll_interval", 2)
        self.output_batch_ms = self.config.get("output_batch_ms", 500)

        self.label = label or f"{tool_name} session"
        self.binary = resolve_binary(tool_name, self.config, explicit_binary)

        self._process = None
        self._running = False
        # Conversation model: _conversation_id is set after the first post;
        # _last_message_id is updated after every post for parentId chaining.
        self._conversation_id: str | None = None
        self._last_message_id: str | None = None
        self._seen_input_ids: set = set()

        self._output_thread = None
        self._input_thread = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run(self):
        """Start the wrap session. Blocks until the subprocess exits."""
        from rich.console import Console
        console = Console()

        console.print(f"\n[bold bright_cyan]🔗 Wrap session starting…[/bold bright_cyan]")
        console.print(f"   Project:    [bold]{self.project}[/bold]")
        console.print(f"   Tool:       [bold]{self.tool_name}[/bold]  ([dim]{self.binary}[/dim])")
        console.print(f"   [dim]Press Ctrl+C to stop the session.[/dim]\n")

        try:
            self._post_session_message(f"🔗 Wrap session started: {self.label}\nTool: `{self.tool_name}`")
        except Exception as e:
            logger.warning(f"Could not post session-open message: {e}")

        # Print the chat URL now that _conversation_id is set
        chat_url = f"{self.base_url}chat/{self.project}/{self._conversation_id}"
        console.print(f"   Chat URL:   [bold bright_cyan]{chat_url}[/bold bright_cyan]\n")

        try:
            self._start_subprocess()
        except FileNotFoundError:
            console.print(f"[red]❌ Could not start '{self.binary}'. Is it installed and on your PATH?[/red]")
            return 1
        except Exception as e:
            console.print(f"[red]❌ Failed to start subprocess: {e}[/red]")
            return 1

        self._running = True

        self._output_thread = threading.Thread(target=self._output_reader, daemon=True, name="wrap-output")
        # Input poller started after _conversation_id is guaranteed to be set
        self._input_thread = threading.Thread(target=self._input_poller, daemon=True, name="wrap-input")

        self._output_thread.start()
        self._input_thread.start()

        exit_code = 0
        try:
            exit_code = self._process.wait()
        except KeyboardInterrupt:
            console.print("\n[yellow]⚠ Interrupted — closing session…[/yellow]")
            self._process.terminate()
            try:
                self._process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self._process.kill()

        self._running = False
        self._output_thread.join(timeout=3)
        self._input_thread.join(timeout=3)

        try:
            self._post_session_message(f"🔒 Wrap session closed (exit code: {exit_code})")
        except Exception as e:
            logger.warning(f"Could not post session-close message: {e}")

        console.print(f"\n[dim]Wrap session ended (exit code: {exit_code}).[/dim]")
        return exit_code

    # ------------------------------------------------------------------
    # Subprocess management
    # ------------------------------------------------------------------

    def _start_subprocess(self):
        cmd = [self.binary] + self.tool_args
        logger.info(f"Starting subprocess: {cmd}")
        self._process = subprocess.Popen(
            cmd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
        )

    # ------------------------------------------------------------------
    # Output reader — reads subprocess stdout, batches, posts to codicent
    # ------------------------------------------------------------------

    def _output_reader(self):
        """Reads subprocess stdout line-by-line. Batches output and posts to codicent."""
        batch = []
        batch_lock = threading.Lock()

        def flush_batch():
            with batch_lock:
                if not batch:
                    return
                text = "".join(batch).strip()
                batch.clear()
            if text:
                # Echo locally
                print(text, flush=True)
                # Apply auto-response rules
                self._maybe_auto_respond(text)
                # Post to codicent
                try:
                    self._post_output_message(text)
                except Exception as e:
                    logger.warning(f"Failed to post output: {e}")

        def timer_flush():
            """Periodically flush the batch so bursts of output aren't held indefinitely."""
            while self._running:
                time.sleep(self.output_batch_ms / 1000)
                flush_batch()

        timer_thread = threading.Thread(target=timer_flush, daemon=True, name="wrap-flush")
        timer_thread.start()

        try:
            for line in self._process.stdout:
                with batch_lock:
                    batch.append(line)
            # Final flush after subprocess exits
            flush_batch()
        except Exception as e:
            logger.error(f"Output reader error: {e}")

    # ------------------------------------------------------------------
    # Input poller — polls GetMessages API, writes new ones to subprocess stdin
    # ------------------------------------------------------------------

    def _input_poller(self):
        """Polls GetMessageHistory for user messages (ai-chat-prompt*) and forwards them to subprocess stdin."""
        while self._running:
            try:
                if self._conversation_id:
                    messages = self._fetch_conversation_messages()
                    for msg in messages:
                        msg_id = msg.get("id")
                        if msg_id in self._seen_input_ids:
                            continue
                        msg_type = msg.get("type") or ""
                        # Only forward user input messages — not wrap's own output
                        if not msg_type.startswith("ai-chat-prompt"):
                            continue
                        self._seen_input_ids.add(msg_id)
                        content = self._extract_input_text(msg)
                        if content:
                            logger.info(f"Received remote input: {content[:80]}")
                            from rich.console import Console
                            Console().print(f"[dim]  ← Remote input:[/dim] [cyan]{content}[/cyan]")
                            try:
                                # Write raw bytes to avoid Windows \n→\r\n translation in text mode
                                self._process.stdin.buffer.write((content + "\n").encode("utf-8"))
                                self._process.stdin.buffer.flush()
                            except BrokenPipeError:
                                logger.warning("Subprocess stdin closed")
                                self._running = False
                                break
            except Exception as e:
                logger.warning(f"Input poller error: {e}")
            time.sleep(self.poll_interval)

    def _fetch_conversation_messages(self):
        """Fetch the full conversation thread via GetMessageHistory."""
        url = f"{self.base_url}app/GetMessageHistory"
        headers = {
            "Authorization": f"Bearer {self.token}",
        }
        resp = requests.get(url, params={"messageId": self._conversation_id},
                            headers=headers, verify=self.verify_https, timeout=10)
        resp.raise_for_status()
        return resp.json() if resp.text else []

    def _extract_input_text(self, message):
        """Strip tags and @mention from a message to get the bare input text."""
        content = message.get("content") or ""
        # Remove @mention at start
        content = re.sub(r"^@\S+\s*", "", content)
        # Remove #tags
        content = re.sub(r"#\S+", "", content)
        # Strip whitespace and Windows carriage returns
        return content.strip().replace("\r", "")

    # ------------------------------------------------------------------
    # Auto-response rules
    # ------------------------------------------------------------------

    def _maybe_auto_respond(self, output_text):
        """Check output against auto-response rules and send reply if matched."""
        for rule in self.config.get("auto_responses", []):
            pattern = rule.get("pattern", "")
            reply = rule.get("reply", "")
            if pattern and reply and re.search(pattern, output_text, re.IGNORECASE):
                logger.info(f"Auto-responding to pattern '{pattern}' with '{reply}'")
                from rich.console import Console
                Console().print(f"[dim]  ↩ Auto-response:[/dim] [yellow]{reply}[/yellow]")
                try:
                    self._process.stdin.buffer.write((reply + "\n").encode("utf-8"))
                    self._process.stdin.buffer.flush()
                except BrokenPipeError:
                    pass
                break

    # ------------------------------------------------------------------
    # Codicent API helpers
    # ------------------------------------------------------------------

    def _post_output_message(self, text):
        """Post tool output as a bot message, chained into the conversation."""
        content = f"@{self.project}\n{text}"
        self._post_raw(content, msg_type="ai-chat-answer2")

    def _post_session_message(self, text):
        """Post a session lifecycle event."""
        content = f"@{self.project}\n{text}"
        # The very first post uses type "wrap-session" so the engine can detect and skip LLM.
        # Subsequent session messages (e.g. close) reuse ai-chat-answer2 to stay in the conversation.
        msg_type = "wrap-session" if self._conversation_id is None else "ai-chat-answer2"
        self._post_raw(content, msg_type=msg_type)

    def _post_raw(self, content, msg_type="ai-chat-answer2") -> str:
        """POST a message to AddChatMessage, chain it via parentId, and return the new message id."""
        url = f"{self.base_url}app/AddChatMessage"
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json",
        }
        payload: dict = {"content": content, "type": msg_type}
        if self._last_message_id:
            payload["parentId"] = self._last_message_id
        resp = requests.post(url, json=payload, headers=headers,
                             verify=self.verify_https, timeout=15)
        resp.raise_for_status()
        new_id = resp.json().get("id") or resp.json().get("Id")
        if new_id:
            self._last_message_id = new_id
            if self._conversation_id is None:
                self._conversation_id = new_id
        return new_id or ""


# ---------------------------------------------------------------------------
# Entry point called from app.py
# ---------------------------------------------------------------------------

def run_wrap_command(args, token, base_url, project, verify_https=True):
    """
    Parse wrap sub-command args and run the session.

    args: sys.argv after "wrap" has been consumed, e.g.:
        ["claude", "--model", "claude-opus-4-5"]
        ["--label", "My session", "opencode"]
        ["--binary", "/usr/local/bin/claude", "claude"]
        ["--poll-interval", "5", "codex"]
    """
    from rich.console import Console
    console = Console()

    # Parse wrap-specific flags
    label = None
    explicit_binary = None
    poll_interval = None
    remaining = list(args)

    i = 0
    while i < len(remaining):
        arg = remaining[i]
        if arg in ("--label",) and i + 1 < len(remaining):
            label = remaining[i + 1]
            remaining = remaining[:i] + remaining[i + 2:]
            continue
        if arg in ("--binary",) and i + 1 < len(remaining):
            explicit_binary = remaining[i + 1]
            remaining = remaining[:i] + remaining[i + 2:]
            continue
        if arg in ("--poll-interval",) and i + 1 < len(remaining):
            try:
                poll_interval = float(remaining[i + 1])
            except ValueError:
                console.print(f"[red]❌ --poll-interval must be a number[/red]")
                return 1
            remaining = remaining[:i] + remaining[i + 2:]
            continue
        i += 1

    if not remaining:
        console.print("[red]❌ Usage: codicent wrap <tool> [tool-args...][/red]")
        console.print("[dim]Examples:[/dim]")
        console.print("[dim]  codicent wrap claude[/dim]")
        console.print("[dim]  codicent wrap claude --model claude-opus-4-5[/dim]")
        console.print("[dim]  codicent wrap opencode[/dim]")
        console.print("[dim]  codicent wrap --label 'Refactor session' codex[/dim]")
        return 1

    tool_name = remaining[0]
    tool_args = remaining[1:]

    session = WrapSession(
        tool_name=tool_name,
        tool_args=tool_args,
        token=token,
        base_url=base_url,
        project=project,
        label=label,
        explicit_binary=explicit_binary,
        poll_interval=poll_interval,
        verify_https=verify_https,
    )

    return session.run()
