"""Portable TenantID propagation for Temporal workflows.

Single source of truth for multi-tenant runtime context. Both the
worker (that sets TenantID via interceptor) and the pipeline author
(that reads TenantID via ``get_current_tenant``) import from here
so the underlying ``contextvars.ContextVar`` object is shared.

Worker setup (activity side)::

    from pipeline_sdk.tenant import TenantInterceptor, get_current_tenant

    worker = Worker(..., interceptors=[TenantInterceptor()])

    @activity.defn
    async def my_activity(params) -> ...:
        tenant = get_current_tenant()   # agency_uuid, workspace_id

Client setup (workflow starter)::

    from pipeline_sdk.tenant import TenantClientInterceptor
    from pipeline_sdk.types import TenantID

    tenant_client = Client(
        service_client=base_client.service_client,
        namespace=base_client.namespace,
        data_converter=base_client.data_converter,
        interceptors=[TenantClientInterceptor(TenantID('agency', 42))],
    )
    await tenant_client.start_workflow(...)
"""

from __future__ import annotations

import contextvars
import dataclasses
import inspect
import json
from datetime import timedelta
from typing import Any, Optional, Type

from temporalio import client as temporal_client
from temporalio.api.common.v1 import Payload
from temporalio.common import RetryPolicy
from temporalio.exceptions import ApplicationError
from temporalio.worker import (
    ActivityInboundInterceptor,
    ExecuteActivityInput,
    ExecuteWorkflowInput,
    Interceptor,
    StartActivityInput,
    StartChildWorkflowInput,
    StartLocalActivityInput,
    WorkflowInboundInterceptor,
    WorkflowInterceptorClassInput,
    WorkflowOutboundInterceptor,
)

try:  # temporalio>=1.11 (Nexus)
    from temporalio.worker import StartNexusOperationInput  # type: ignore
    _HAS_NEXUS_OUTBOUND = True
except ImportError:  # pragma: no cover
    StartNexusOperationInput = None  # type: ignore
    _HAS_NEXUS_OUTBOUND = False

from pipeline_sdk.types import TenantID

# ── Public constants ───────────────────────────────────────────────

TENANT_HEADER_KEY = 'x-tenant-id'
"""Temporal header key carrying the encoded ``TenantID``.

Public so out-of-process consumers (e.g. the DTS Nexus service handler)
can validate the inbound header by name without re-declaring the string
and silently drifting from the SDK.
"""

DEFAULT_TENANT_RETRY_POLICY = RetryPolicy(
    initial_interval=timedelta(seconds=10),
    backoff_coefficient=2.0,
    maximum_attempts=3,
)
"""Default execution-level retry policy applied to tenant workflows.

Paired with ``Worker(workflow_failure_exception_types=[Exception])`` this
turns an unhandled Python exception in workflow code into an execution
failure that Temporal retries up to ``maximum_attempts`` times — instead
of the default server-side behaviour of retrying the Workflow Task
forever.

The policy is injected by ``TenantClientInterceptor`` on both
``start_workflow`` and ``create_schedule`` / ``update_schedule`` paths.
A caller-supplied ``retry_policy`` is never overridden.
"""


DEFAULT_TENANT_ACTIVITY_RETRY_POLICY = RetryPolicy(
    initial_interval=timedelta(seconds=1),
    backoff_coefficient=2.0,
    maximum_interval=timedelta(seconds=100),
    maximum_attempts=3,
)
"""Default retry policy applied to tenant-issued activities and child workflows.

Temporal's server-side default for activities has no ``maximum_attempts``
cap, so a buggy activity (e.g. raising ``AttributeError`` in tenant code)
would loop forever — even after IMD-59204 bounded the workflow execution
retries. This policy is injected by ``_TenantWorkflowOutbound`` on
``start_activity`` / ``start_local_activity`` / ``start_child_workflow``
when the workflow author did not pass an explicit ``retry_policy``.
A caller-supplied ``retry_policy`` is never overridden.
"""


# ── Context ────────────────────────────────────────────────────────

_current_tenant: contextvars.ContextVar[TenantID | None] = (
    contextvars.ContextVar('current_tenant', default=None)
)
_current_workflow_tenant: contextvars.ContextVar[TenantID | None] = (
    contextvars.ContextVar('current_workflow_tenant', default=None)
)


def get_current_tenant() -> TenantID:
    """Return the TenantID for the current activity execution."""
    tenant = _current_tenant.get()
    if tenant is None:
        raise ApplicationError(
            'No TenantID in context. '
            'Was the workflow started with the x-tenant-id header?',
            non_retryable=True,
        )
    return tenant


def get_current_workflow_tenant() -> TenantID:
    """Return the TenantID for the current workflow execution.

    Read inside workflow code (``@workflow.run``). Requires the workflow
    to have been started with the x-tenant-id header, i.e. the starter
    client wrapped with ``TenantClientInterceptor``.
    """
    tenant = _current_workflow_tenant.get()
    if tenant is None:
        raise ApplicationError(
            'No TenantID in workflow context. '
            'Was the workflow started with the x-tenant-id header?',
            non_retryable=True,
        )
    return tenant


# ── Serialization ──────────────────────────────────────────────────
#
# Two wire formats live side-by-side:
#
# - ``Payload`` for everything that goes through Temporal's standard
#   ``Mapping[str, Payload]`` header maps: workflow start, activity,
#   local activity, child workflow.
# - ``str`` (the same JSON body, decoded UTF-8) for Nexus operation
#   headers — these are ``map<string, string>`` at the protobuf wire
#   level, so a Payload object cannot be passed through.
#
# Both encodings carry the same payload, so any consumer that bridges
# transports (e.g. a Nexus service handler that needs to forward the
# inbound header onto a spawned workflow) can decode and re-encode
# identically regardless of side.


def tenant_to_json(tenant: TenantID) -> str:
    """Encode ``tenant`` as the JSON body used in Nexus headers."""
    # Workspace-scope tenants (``user_id is None``) and user-scope
    # tenants (``user_id`` set) are both first-class — the key is
    # written only in the user-scope case so the workspace-scope wire
    # payload stays the same shape across SDK versions. DTS-side
    # handlers on SDK <0.6 parse ``agency_uuid`` / ``workspace_id``
    # and ignore unknown keys, so adding ``user_id`` here is also
    # backward-compatible during phased rollouts (ADR-010 §2).
    payload: dict[str, Any] = {
        'agency_uuid': tenant.agency_uuid,
        'workspace_id': tenant.workspace_id,
    }
    if tenant.user_id is not None:
        payload['user_id'] = tenant.user_id
    return json.dumps(payload)


def tenant_from_json(value: str | bytes) -> TenantID:
    """Decode the JSON body from a Nexus ``x-tenant-id`` header."""
    data = json.loads(value)
    return TenantID(
        agency_uuid=data['agency_uuid'],
        workspace_id=data['workspace_id'],
        user_id=data.get('user_id'),
    )


def tenant_to_payload(tenant: TenantID) -> Payload:
    """Encode ``tenant`` as a Temporal ``Payload`` (workflow/activity headers)."""
    return Payload(data=tenant_to_json(tenant).encode())


def payload_to_tenant(payload: Payload) -> TenantID:
    """Decode a Temporal ``Payload`` from the ``x-tenant-id`` header."""
    return tenant_from_json(payload.data)


# ── Public helper for non-start_workflow paths ─────────────────────


def build_tenant_headers(tenant: TenantID) -> dict[str, Payload]:
    """Return Temporal header dict that propagates ``tenant``.

    ``TenantClientInterceptor`` handles the common ``start_workflow``
    path automatically. Use this helper only for code paths that build
    headers directly — e.g. ``ScheduleActionStartWorkflow``.
    """
    return {TENANT_HEADER_KEY: tenant_to_payload(tenant)}


# ── Client interceptor (workflow starter) ──────────────────────────


class TenantClientInterceptor(temporal_client.Interceptor):
    """Injects x-tenant-id header into every start_workflow call."""

    def __init__(self, tenant: TenantID) -> None:
        self._tenant = tenant

    def intercept_client(
        self,
        nxt: temporal_client.OutboundInterceptor,
    ) -> temporal_client.OutboundInterceptor:
        return _TenantClientOutbound(nxt, self._tenant)


class _TenantClientOutbound(temporal_client.OutboundInterceptor):

    def __init__(
        self,
        nxt: temporal_client.OutboundInterceptor,
        tenant: TenantID,
    ) -> None:
        super().__init__(nxt)
        self._payload = tenant_to_payload(tenant)

    async def start_workflow(
        self,
        start_input: temporal_client.StartWorkflowInput,
    ) -> temporal_client.WorkflowHandle[Any, Any]:
        headers = {
            **start_input.headers,
            TENANT_HEADER_KEY: self._payload,
        }
        retry_policy = (
            start_input.retry_policy
            if start_input.retry_policy is not None
            else DEFAULT_TENANT_RETRY_POLICY
        )
        return await super().start_workflow(
            dataclasses.replace(
                start_input,
                headers=headers,
                retry_policy=retry_policy,
            ),
        )

    async def create_schedule(
        self,
        input: temporal_client.CreateScheduleInput,
    ) -> temporal_client.ScheduleHandle:
        return await super().create_schedule(
            dataclasses.replace(
                input,
                schedule=_with_default_retry_policy(input.schedule),
            ),
        )

    async def update_schedule(
        self,
        input: temporal_client.UpdateScheduleInput,
    ) -> None:
        original_updater = input.updater

        async def wrapped_updater(
            upd_input: temporal_client.ScheduleUpdateInput,
        ) -> temporal_client.ScheduleUpdate | None:
            result = original_updater(upd_input)
            if inspect.isawaitable(result):
                result = await result
            if result is None:
                return None
            return dataclasses.replace(
                result,
                schedule=_with_default_retry_policy(result.schedule),
            )

        return await super().update_schedule(
            dataclasses.replace(input, updater=wrapped_updater),
        )


def _with_default_retry_policy(
    schedule: temporal_client.Schedule,
) -> temporal_client.Schedule:
    """Return ``schedule`` with default retry_policy on its StartWorkflow action.

    Only applied when the action is ``ScheduleActionStartWorkflow`` and no
    retry_policy is set by the caller. Other action types (e.g. Nexus) and
    caller-supplied policies pass through untouched.
    """
    action = schedule.action
    if (
        isinstance(action, temporal_client.ScheduleActionStartWorkflow)
        and action.retry_policy is None
    ):
        new_action = dataclasses.replace(
            action,
            retry_policy=DEFAULT_TENANT_RETRY_POLICY,
        )
        return dataclasses.replace(schedule, action=new_action)
    return schedule


# ── Worker interceptor (workflow + activity side) ──────────────────


class TenantInterceptor(Interceptor):
    """Propagates x-tenant-id: workflow headers → activity contextvars."""

    def intercept_activity(
        self,
        nxt: ActivityInboundInterceptor,
    ) -> ActivityInboundInterceptor:
        return _TenantActivityInbound(nxt)

    def workflow_interceptor_class(
        self,
        wf_input: WorkflowInterceptorClassInput,
    ) -> Optional[Type[WorkflowInboundInterceptor]]:
        return _TenantWorkflowInbound


class _TenantWorkflowInbound(WorkflowInboundInterceptor):

    _tenant_payload: Payload | None = None
    _tenant: TenantID | None = None

    def init(self, outbound: WorkflowOutboundInterceptor) -> None:
        self.next.init(_TenantWorkflowOutbound(outbound, self))

    async def execute_workflow(
        self,
        wf_input: ExecuteWorkflowInput,
    ) -> Any:
        self._tenant_payload = wf_input.headers.get(TENANT_HEADER_KEY)
        if self._tenant_payload is None:
            return await self.next.execute_workflow(wf_input)

        self._tenant = payload_to_tenant(self._tenant_payload)
        token = _current_workflow_tenant.set(self._tenant)
        try:
            return await self.next.execute_workflow(wf_input)
        finally:
            _current_workflow_tenant.reset(token)


class _TenantWorkflowOutbound(WorkflowOutboundInterceptor):

    def __init__(
        self,
        nxt: WorkflowOutboundInterceptor,
        inbound: _TenantWorkflowInbound,
    ) -> None:
        super().__init__(nxt)
        self._inbound = inbound

    def _inject_payload_header(self, activity_input: Any) -> Any:
        # Activity / local activity / child workflow inputs all use
        # ``Mapping[str, Payload]`` headers. The field defaults to ``{}``
        # in current Temporal versions, but be defensive about ``None``
        # so a future field-default change can't crash the worker.
        if self._inbound._tenant_payload is None:
            return activity_input
        existing = activity_input.headers or {}
        headers = {
            **existing,
            TENANT_HEADER_KEY: self._inbound._tenant_payload,
        }
        return dataclasses.replace(activity_input, headers=headers)

    @staticmethod
    def _with_default_retry(activity_input: Any) -> Any:
        # Applies to ``StartActivityInput`` / ``StartLocalActivityInput`` /
        # ``StartChildWorkflowInput`` — all expose ``retry_policy`` and
        # default it to ``None``, in which case Temporal would otherwise
        # apply a server default with no ``maximum_attempts`` cap.
        if activity_input.retry_policy is not None:
            return activity_input
        return dataclasses.replace(
            activity_input,
            retry_policy=DEFAULT_TENANT_ACTIVITY_RETRY_POLICY,
        )

    def _inject_str_header(self, nexus_input: Any) -> Any:
        # ``StartNexusOperationInput.headers`` is ``Mapping[str, str] |
        # None`` and serializes to a protobuf ``map<string, string>``,
        # so a Payload object cannot be placed there. Encode the tenant
        # as a JSON string carrying the same fields as the Payload form.
        if self._inbound._tenant is None:
            return nexus_input
        existing = nexus_input.headers or {}
        headers = {
            **existing,
            TENANT_HEADER_KEY: tenant_to_json(self._inbound._tenant),
        }
        return dataclasses.replace(nexus_input, headers=headers)

    def start_activity(self, activity_input: StartActivityInput) -> Any:
        return self.next.start_activity(
            self._with_default_retry(
                self._inject_payload_header(activity_input),
            ),
        )

    def start_local_activity(
        self,
        activity_input: StartLocalActivityInput,
    ) -> Any:
        return self.next.start_local_activity(
            self._with_default_retry(
                self._inject_payload_header(activity_input),
            ),
        )

    def start_child_workflow(
        self,
        activity_input: StartChildWorkflowInput,
    ) -> Any:
        return self.next.start_child_workflow(
            self._with_default_retry(
                self._inject_payload_header(activity_input),
            ),
        )

    if _HAS_NEXUS_OUTBOUND:
        def start_nexus_operation(
            self,
            nexus_input: 'StartNexusOperationInput',  # type: ignore[name-defined]
        ) -> Any:
            return self.next.start_nexus_operation(
                self._inject_str_header(nexus_input),
            )


class _TenantActivityInbound(ActivityInboundInterceptor):

    async def execute_activity(
        self,
        activity_input: ExecuteActivityInput,
    ) -> Any:
        payload = activity_input.headers.get(TENANT_HEADER_KEY)
        if payload is None:
            return await self.next.execute_activity(activity_input)

        tenant = payload_to_tenant(payload)
        token = _current_tenant.set(tenant)
        try:
            return await self.next.execute_activity(activity_input)
        finally:
            _current_tenant.reset(token)


__all__ = [
    'TENANT_HEADER_KEY',
    'DEFAULT_TENANT_RETRY_POLICY',
    'DEFAULT_TENANT_ACTIVITY_RETRY_POLICY',
    'TenantID',
    'get_current_tenant',
    'get_current_workflow_tenant',
    'build_tenant_headers',
    'tenant_to_json',
    'tenant_from_json',
    'tenant_to_payload',
    'payload_to_tenant',
    'TenantInterceptor',
    'TenantClientInterceptor',
]
