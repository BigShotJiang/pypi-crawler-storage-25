"""Unit tests for ``_TenantWorkflowOutbound`` header injection.

Regression coverage for two crashes that the Nexus-backed credentials
path produced in production (IMD-58671 follow-up):

1. ``StartNexusOperationInput.headers`` defaults to ``None`` (not
   ``{}``), so ``{**input.headers, ...}`` raised
   ``TypeError: 'NoneType' object is not a mapping`` on the first
   ``prepare_credentials`` call.
2. Even with ``None`` handled, Nexus headers are
   ``Mapping[str, str]`` at the protobuf wire level — passing the
   tenant ``Payload`` object through the same code path as the
   Payload-typed activity headers fails on serialization.
"""
from __future__ import annotations

import dataclasses
import json
from typing import Any

from temporalio.api.common.v1 import Payload

from pipeline_sdk.tenant import (
    TENANT_HEADER_KEY,
    _TenantWorkflowInbound,
    _TenantWorkflowOutbound,
    payload_to_tenant,
    tenant_from_json,
    tenant_to_json,
    tenant_to_payload,
)
from pipeline_sdk.types import TenantID


@dataclasses.dataclass
class _FakePayloadInput:
    """Mimics activity / local activity / child workflow inputs."""
    headers: dict[str, Payload] | None


@dataclasses.dataclass
class _FakeNexusInput:
    """Mimics ``StartNexusOperationInput`` (str-typed headers)."""
    headers: dict[str, str] | None


class _NoopOutbound:
    """Stub ``next`` for the outbound interceptor under test."""

    next = None

    def start_activity(self, _: Any) -> Any:  # pragma: no cover
        raise AssertionError('not called in these tests')


def _make_outbound(tenant: TenantID | None) -> _TenantWorkflowOutbound:
    inbound = _TenantWorkflowInbound.__new__(_TenantWorkflowInbound)
    inbound._tenant_payload = (
        tenant_to_payload(tenant) if tenant is not None else None
    )
    inbound._tenant = tenant
    # ``next`` is required by ``WorkflowOutboundInterceptor.__init__``
    # but the units under test (``_inject_*``) never delegate to it.
    return _TenantWorkflowOutbound(_NoopOutbound(), inbound)  # type: ignore[arg-type]


def test_payload_inject_handles_none_headers() -> None:
    """Activity inputs with ``headers=None`` do not blow up."""
    tenant = TenantID(agency_uuid='agency-1', workspace_id=7)
    outbound = _make_outbound(tenant)
    inp = _FakePayloadInput(headers=None)

    out = outbound._inject_payload_header(inp)

    assert out.headers is not None
    assert TENANT_HEADER_KEY in out.headers
    assert isinstance(out.headers[TENANT_HEADER_KEY], Payload)


def test_payload_inject_preserves_existing_headers() -> None:
    tenant = TenantID(agency_uuid='agency-1', workspace_id=7)
    outbound = _make_outbound(tenant)
    other = Payload(data=b'other')
    inp = _FakePayloadInput(headers={'other': other})

    out = outbound._inject_payload_header(inp)

    assert out.headers['other'] is other
    assert isinstance(out.headers[TENANT_HEADER_KEY], Payload)


def test_payload_inject_no_tenant_passthrough() -> None:
    outbound = _make_outbound(None)
    inp = _FakePayloadInput(headers=None)

    assert outbound._inject_payload_header(inp) is inp


def test_nexus_inject_handles_none_headers() -> None:
    """``StartNexusOperationInput.headers`` defaults to ``None`` —
    must not crash on ``{**None, ...}``.
    """
    tenant = TenantID(agency_uuid='agency-1', workspace_id=7)
    outbound = _make_outbound(tenant)
    inp = _FakeNexusInput(headers=None)

    out = outbound._inject_str_header(inp)

    assert out.headers is not None
    assert TENANT_HEADER_KEY in out.headers


def test_nexus_inject_value_is_string_not_payload() -> None:
    """Nexus protobuf headers are ``map<string, string>`` — the value
    must be a JSON string, not a ``Payload`` object."""
    tenant = TenantID(agency_uuid='agency-1', workspace_id=7)
    outbound = _make_outbound(tenant)
    inp = _FakeNexusInput(headers=None)

    out = outbound._inject_str_header(inp)
    value = out.headers[TENANT_HEADER_KEY]

    assert isinstance(value, str)
    assert json.loads(value) == {
        'agency_uuid': 'agency-1',
        'workspace_id': 7,
    }


def test_nexus_inject_preserves_existing_headers() -> None:
    tenant = TenantID(agency_uuid='agency-1', workspace_id=7)
    outbound = _make_outbound(tenant)
    inp = _FakeNexusInput(headers={'traceparent': 'abc'})

    out = outbound._inject_str_header(inp)

    assert out.headers['traceparent'] == 'abc'
    assert TENANT_HEADER_KEY in out.headers


def test_nexus_inject_no_tenant_passthrough() -> None:
    outbound = _make_outbound(None)
    inp = _FakeNexusInput(headers=None)

    assert outbound._inject_str_header(inp) is inp


# ── Wire-format round-trip with optional user_id (ADR-010) ────────


def test_json_omits_user_id_when_none() -> None:
    """Workspace-scope tenants (a first-class permanent mode, not a
    deprecation target) emit only ``agency_uuid`` / ``workspace_id``
    so the wire payload shape stays the same across SDK versions.
    """
    tenant = TenantID(agency_uuid='agency-1', workspace_id=7)

    payload = json.loads(tenant_to_json(tenant))

    assert payload == {'agency_uuid': 'agency-1', 'workspace_id': 7}
    assert 'user_id' not in payload


def test_json_carries_user_id_when_set() -> None:
    tenant = TenantID(agency_uuid='agency-1', workspace_id=7, user_id=999)

    payload = json.loads(tenant_to_json(tenant))

    assert payload == {
        'agency_uuid': 'agency-1',
        'workspace_id': 7,
        'user_id': 999,
    }


def test_json_roundtrip_preserves_user_id() -> None:
    tenant = TenantID(agency_uuid='agency-1', workspace_id=7, user_id=999)

    parsed = tenant_from_json(tenant_to_json(tenant))

    assert parsed == tenant


def test_json_roundtrip_without_user_id_yields_none() -> None:
    tenant = TenantID(agency_uuid='agency-1', workspace_id=7)

    parsed = tenant_from_json(tenant_to_json(tenant))

    assert parsed == tenant
    assert parsed.user_id is None


def test_payload_roundtrip_preserves_user_id() -> None:
    """Payload form (used in activity / child workflow / start_workflow
    headers) carries the same JSON, so user_id must round-trip there too.
    """
    tenant = TenantID(agency_uuid='agency-1', workspace_id=7, user_id=42)

    parsed = payload_to_tenant(tenant_to_payload(tenant))

    assert parsed == tenant


def test_json_from_payload_without_user_id_key() -> None:
    """A workspace-scope payload (or a peer on SDK <0.6) carries no
    ``user_id`` key — our parser must tolerate the missing key and
    default ``user_id`` to ``None`` (workspace-scope).
    """
    payload = '{"agency_uuid": "agency-1", "workspace_id": 7}'

    parsed = tenant_from_json(payload)

    assert parsed == TenantID(agency_uuid='agency-1', workspace_id=7)
    assert parsed.user_id is None
