"""Unit tests for pipeline_sdk.types — TenantID namespace (de)serialization."""
from __future__ import annotations

import pytest

from pipeline_sdk.types import TenantID


def test_tenant_id_roundtrip_via_namespace() -> None:
    tenant = TenantID(agency_uuid='agency-1', workspace_id=7)

    ns = tenant.to_namespace()

    assert ns == 'tenant.agency-1.7'
    assert TenantID.from_namespace(ns) == tenant


def test_tenant_id_from_namespace_handles_uuid_with_dashes() -> None:
    """Switching separator from '-' to '.' was the whole point of this
    encoding — UUID-form agency_uuid must not confuse the parser.
    """
    ns = 'tenant.abc-123-def-456.42'

    tenant = TenantID.from_namespace(ns)

    assert tenant == TenantID(agency_uuid='abc-123-def-456', workspace_id=42)


def test_tenant_id_from_namespace_captures_user_id() -> None:
    """Per ADR-010, the optional 4th segment is parsed into ``user_id``."""
    ns = 'tenant.agency-1.7.999'

    tenant = TenantID.from_namespace(ns)

    assert tenant == TenantID(
        agency_uuid='agency-1', workspace_id=7, user_id=999,
    )


def test_tenant_id_with_user_id_roundtrip_via_namespace() -> None:
    tenant = TenantID(agency_uuid='agency-1', workspace_id=7, user_id=999)

    ns = tenant.to_namespace()

    assert ns == 'tenant.agency-1.7.999'
    assert TenantID.from_namespace(ns) == tenant


def test_tenant_id_path_prefix_without_user_id() -> None:
    tenant = TenantID(agency_uuid='agency-1', workspace_id=7)

    assert tenant.path_prefix == 'agency-1/7'


def test_tenant_id_path_prefix_with_user_id() -> None:
    tenant = TenantID(agency_uuid='agency-1', workspace_id=7, user_id=999)

    assert tenant.path_prefix == 'agency-1/7/999'


def test_tenant_id_post_init_canonicalizes_uuid() -> None:
    """Real UUIDs are coerced to lowercase-dashed canonical form."""
    upper = '0123ABCD-0123-0123-0123-0123456789AB'
    tenant = TenantID(agency_uuid=upper, workspace_id=1)

    assert tenant.agency_uuid == upper.lower()


def test_tenant_id_post_init_passes_through_non_uuid() -> None:
    """Slugs / fixtures that are not real UUIDs survive intact."""
    tenant = TenantID(agency_uuid='agency-1', workspace_id=1)

    assert tenant.agency_uuid == 'agency-1'


def test_tenant_id_from_namespace_rejects_wrong_prefix() -> None:
    with pytest.raises(ValueError, match='not a tenant namespace'):
        TenantID.from_namespace('default')


def test_tenant_id_from_namespace_rejects_short_form() -> None:
    """Short tenant.<tenant_id> form needs a DB resolver (follow-up)."""
    with pytest.raises(ValueError, match='Short tenant'):
        TenantID.from_namespace('tenant.opaque-tenant-id')


def test_tenant_id_from_namespace_rejects_non_int_workspace() -> None:
    with pytest.raises(ValueError, match='is not an int'):
        TenantID.from_namespace('tenant.agency-1.notanumber')


def test_tenant_id_from_namespace_rejects_non_int_user_id() -> None:
    with pytest.raises(ValueError, match='user_id segment'):
        TenantID.from_namespace('tenant.agency-1.7.notanumber')


def test_tenant_id_from_namespace_rejects_too_many_segments() -> None:
    """Five segments are not a valid tenant namespace form."""
    with pytest.raises(ValueError, match='too many segments'):
        TenantID.from_namespace('tenant.agency-1.7.999.extra')
