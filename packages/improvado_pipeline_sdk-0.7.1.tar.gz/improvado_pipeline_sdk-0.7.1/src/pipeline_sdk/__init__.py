"""Improvado Pipeline SDK — types and helpers for workflow authoring.

Four subpackages, aligned with Temporal's execution model:

* ``pipeline_sdk.types`` — pure data types / enums (sandbox-safe).
* ``pipeline_sdk.activities`` — predefined workflow-side wrappers
  (``les_extract``, ``ch_load``, ``prepare_credentials``,
  ``cleanup_credentials``). Import inside
  ``workflow.unsafe.imports_passed_through()``.
* ``pipeline_sdk.runtime`` — activity-side helpers
  (``read_pipeline_secret``, ``PipelineState``, ``get_current_tenant``).
* ``pipeline_sdk.tenant`` — tenant propagation interceptors for
  worker/client setup.

Typical workflow file::

    with workflow.unsafe.imports_passed_through():
        from pipeline_sdk.types import DataRef, DateRangeRequest
        from pipeline_sdk.activities import (
            les_extract, ch_load,
            prepare_credentials, cleanup_credentials,
        )

Typical activity file::

    from pipeline_sdk.runtime import (
        read_pipeline_secret, PipelineState, get_current_tenant,
    )
"""
