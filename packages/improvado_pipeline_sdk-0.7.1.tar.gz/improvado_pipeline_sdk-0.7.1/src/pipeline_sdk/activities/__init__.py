"""Predefined workflow-side activity wrappers.

Call these from ``@workflow.defn`` code (they invoke
``workflow.execute_activity`` under the hood). Import inside
``workflow.unsafe.imports_passed_through()``::

    with workflow.unsafe.imports_passed_through():
        from pipeline_sdk.activities import (
            les_extract, ch_load,
            prepare_credentials, cleanup_credentials,
        )

Custom activities defined in your own pipeline module inherit the
workflow's task queue automatically — do not pass ``task_queue`` to
``workflow.execute_activity`` for them.
"""

from __future__ import annotations

from pipeline_sdk.activities.ch import ch_load as ch_load
from pipeline_sdk.activities.credentials import (
    cleanup_credentials as cleanup_credentials,
    prepare_credentials as prepare_credentials,
)
from pipeline_sdk.activities.les import les_extract as les_extract


__all__ = [
    'les_extract',
    'ch_load',
    'prepare_credentials',
    'cleanup_credentials',
]
