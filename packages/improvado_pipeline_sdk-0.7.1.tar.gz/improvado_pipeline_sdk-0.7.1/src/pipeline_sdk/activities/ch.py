"""CH Loader — predefined activity wrapper.

``ch_load`` dispatches ``run_pipeline_load_activity`` on the CH Loader
queue. It derives the full ``_PipelineLoadParams`` payload from a LES
result plus the caller-supplied ``data_source`` / ``report_type`` /
``account_id``.

Usage::

    with workflow.unsafe.imports_passed_through():
        from pipeline_sdk.activities import les_extract, ch_load

    les_result = await les_extract(...)
    if les_result.result_stage_has_data:
        load_result = await ch_load(
            les_result,
            data_source=params.data_source,
            report_type=params.report_type,
            account_id=params.account_id,
        )
"""

from __future__ import annotations

import dataclasses
import datetime
from datetime import timedelta
from enum import StrEnum

from temporalio import workflow
from temporalio.common import RetryPolicy

from pipeline_sdk.types import (
    LesActivityWithS3Result,
    PipelineLoadResult,
    SchemaField,
)

# ── Internal activity/queue identifiers ────────────────────────────

_PIPELINE_LOAD_ACTIVITY = 'run_pipeline_load_activity'
_CH_LOADER_QUEUE = 'ch-activities-queue'


# ── Internal enums (lowercase values — matched by CH Loader) ──────


class _FieldType(StrEnum):
    STRING = 'string'
    NUMBER = 'number'
    BOOL = 'boolean'
    DATE = 'date'
    DATETIME = 'datetime'


class _FieldKind(StrEnum):
    METRIC = 'metric'
    DIMENSION = 'dimension'
    PROPERTY = 'property'
    DATE_KEY = 'date_key'


class _ReportTypeClass(StrEnum):
    DAILY = 'daily'
    MONTHLY = 'monthly'
    WEEKLY = 'weekly'
    LAST_DAY = 'last_day'
    LAST_DAY_INCREMENTAL = 'last_day_incremental'
    DEFAULT = 'default'


class _WriteMethod(StrEnum):
    OVERWRITE = 'overwrite'
    UPSERT = 'upsert'


class _WriteScope(StrEnum):
    BY_DATE_RANGE = 'by_date_range'
    WHOLE_DATA = 'whole_data'


class _DuplicatesStatus(StrEnum):
    NO_DUPLICATES = 'no_duplicates'
    VALID_DUPLICATES = 'valid_duplicates'
    INVALID_DUPLICATES = 'invalid_duplicates'


# ── Internal LES → CH field-type mappings ─────────────────────────

_LES_TO_CH_FIELD_TYPE: dict[str, _FieldType] = {
    'string': _FieldType.STRING,
    'number': _FieldType.NUMBER,
    'boolean': _FieldType.BOOL,
    'date': _FieldType.DATE,
    'object': _FieldType.STRING,
}

_LES_TO_CH_FIELD_KIND: dict[str, _FieldKind] = {
    'metric': _FieldKind.METRIC,
    'dimension': _FieldKind.DIMENSION,
    'property': _FieldKind.PROPERTY,
    'date_key': _FieldKind.DATE_KEY,
}


# ── Internal params (Temporal wire format) ─────────────────────────


@dataclasses.dataclass(frozen=True)
class _PipelineLoadField:
    name: str
    field_type: _FieldType
    kind: _FieldKind
    sql_name: str
    title: str
    is_dynamic: bool = False


@dataclasses.dataclass(frozen=True)
class _PipelineLoadParams:
    data_source: str
    report_type: str
    account_id: str
    date_from: datetime.date
    date_to: datetime.date
    s3_path: str
    data_format: str
    fields: list[_PipelineLoadField]
    report_type_class: _ReportTypeClass
    write_method: _WriteMethod
    write_scope: _WriteScope
    duplicates_status: _DuplicatesStatus


# ── Internal converters ────────────────────────────────────────────


def _les_field_to_load_field(field: SchemaField) -> _PipelineLoadField:
    field_type_str = str(field.type).lower() if field.type else 'string'
    field_kind_str = str(field.kind).lower() if field.kind else 'dimension'

    return _PipelineLoadField(
        name=field.name,
        field_type=_LES_TO_CH_FIELD_TYPE.get(
            field_type_str, _FieldType.STRING,
        ),
        kind=_LES_TO_CH_FIELD_KIND.get(
            field_kind_str, _FieldKind.DIMENSION,
        ),
        sql_name=field.sql_name,
        title=field.title,
        is_dynamic=field.dynamic,
    )


def _build_load_params(
    les_result: LesActivityWithS3Result,
    *,
    data_source: str,
    report_type: str,
    account_id: str,
) -> _PipelineLoadParams:
    result_stage = les_result.executor_result.result_stage
    date_from, date_to = result_stage.get_range()
    meta = les_result.executor_result.report_type_meta
    fields = result_stage.fields or []

    return _PipelineLoadParams(
        data_source=data_source,
        report_type=report_type,
        account_id=account_id,
        date_from=date_from,
        date_to=date_to,
        s3_path=f's3://{les_result.s3_bucket}/{les_result.s3_key}',
        data_format=les_result.data_format,
        fields=[_les_field_to_load_field(f) for f in fields],
        report_type_class=_ReportTypeClass(
            str(meta.report_type_class).lower(),
        ),
        write_method=_WriteMethod(str(meta.write_method).lower()),
        write_scope=_WriteScope(str(meta.write_scope).lower()),
        duplicates_status=_DuplicatesStatus(
            str(meta.duplicates_status).lower(),
        ),
    )


# ── Internal default retry / timeouts ──────────────────────────────

_CH_LOAD_DEFAULT_RETRY = RetryPolicy(
    initial_interval=timedelta(seconds=30),
    backoff_coefficient=2.0,
    maximum_interval=timedelta(minutes=5),
    maximum_attempts=3,
    non_retryable_error_types=['ApplicationError'],
)

_CH_LOAD_DEFAULT_SCHEDULE_TO_CLOSE = timedelta(hours=2)
_CH_LOAD_DEFAULT_HEARTBEAT = timedelta(minutes=5)


# ── Public wrapper ─────────────────────────────────────────────────


async def ch_load(
    les_result: LesActivityWithS3Result,
    *,
    data_source: str,
    report_type: str,
    account_id: str,
    schedule_to_close_timeout: timedelta = (
        _CH_LOAD_DEFAULT_SCHEDULE_TO_CLOSE
    ),
    heartbeat_timeout: timedelta = _CH_LOAD_DEFAULT_HEARTBEAT,
    retry_policy: RetryPolicy = _CH_LOAD_DEFAULT_RETRY,
) -> PipelineLoadResult:
    """Load a LES extraction result into ClickHouse.

    Must be called from workflow context. Pair with ``les_extract()``:
    feed its result here after checking ``result_stage_has_data``.
    """
    params = _build_load_params(
        les_result,
        data_source=data_source,
        report_type=report_type,
        account_id=account_id,
    )
    return await workflow.execute_activity(
        _PIPELINE_LOAD_ACTIVITY,
        params,
        task_queue=_CH_LOADER_QUEUE,
        schedule_to_close_timeout=schedule_to_close_timeout,
        heartbeat_timeout=heartbeat_timeout,
        retry_policy=retry_policy,
        result_type=PipelineLoadResult,
    )


__all__ = ['ch_load']
