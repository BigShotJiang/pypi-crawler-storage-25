"""LES extraction — predefined activity wrapper.

``les_extract`` dispatches ``run_les_activity_with_s3_upload`` on the
LES activities queue and returns ``LesActivityWithS3Result``. Queue,
activity name and default retry/timeouts are hidden implementation
details — tune via kwargs.

Usage from workflow code::

    with workflow.unsafe.imports_passed_through():
        from pipeline_sdk.activities import les_extract

    result = await les_extract(
        connector_id=123,
        data_source='facebook',
        report_type='ad_insights',
        date_range=params.date_range,
    )
"""

from __future__ import annotations

from datetime import timedelta
from typing import Any

from temporalio import workflow
from temporalio.common import RetryPolicy

from pipeline_sdk.types import (
    DateRangeRequest,
    LesActivityWithS3Result,
    _LesS3UploadActivityParams,
)

# ── Internal activity/queue identifiers ────────────────────────────

_LES_ACTIVITY_WITH_S3 = 'run_les_activity_with_s3_upload'
_LES_QUEUE = 'les-activities-queue'

# ── Internal default retry / timeouts ──────────────────────────────

_LES_DEFAULT_RETRY = RetryPolicy(
    initial_interval=timedelta(minutes=5),
    backoff_coefficient=2.0,
    maximum_interval=timedelta(minutes=15),
    maximum_attempts=34,
    non_retryable_error_types=['ApplicationError'],
)

_LES_DEFAULT_SCHEDULE_TO_CLOSE = timedelta(hours=48)
_LES_DEFAULT_HEARTBEAT = timedelta(minutes=15)


# ── Public wrapper ─────────────────────────────────────────────────


async def les_extract(
    connector_id: int,
    data_source: str,
    report_type: str,
    date_range: DateRangeRequest | None = None,
    fields: list[str] | None = None,
    args: dict[str, Any] | None = None,
    hashed_fields: list[str] | None = None,
    save_raw_data: bool = False,
    raw_responses_exclude_request: bool = False,
    *,
    schedule_to_close_timeout: timedelta = _LES_DEFAULT_SCHEDULE_TO_CLOSE,
    heartbeat_timeout: timedelta = _LES_DEFAULT_HEARTBEAT,
    retry_policy: RetryPolicy = _LES_DEFAULT_RETRY,
) -> LesActivityWithS3Result:
    """Extract data via LES.

    Returns a result with ``.data_ref`` and ``.result_stage_has_data``.

    Must be called from workflow context — uses
    ``workflow.execute_activity`` under the hood.
    """
    return await workflow.execute_activity(
        _LES_ACTIVITY_WITH_S3,
        _LesS3UploadActivityParams(
            connector_id=connector_id,
            data_source=data_source,
            report_type=report_type,
            fields=fields or [],
            date_range_request=date_range,
            args=args or {},
            hashed_fields=hashed_fields or [],
            save_raw_data=save_raw_data,
            raw_responses_exclude_request=raw_responses_exclude_request,
        ),
        task_queue=_LES_QUEUE,
        schedule_to_close_timeout=schedule_to_close_timeout,
        heartbeat_timeout=heartbeat_timeout,
        retry_policy=retry_policy,
        result_type=LesActivityWithS3Result,
    )


__all__ = ['les_extract']
