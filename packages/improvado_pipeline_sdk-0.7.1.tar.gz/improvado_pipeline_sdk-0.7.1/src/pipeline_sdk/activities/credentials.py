"""Credential lifecycle — Nexus-backed DTS calls.

``prepare_credentials`` reserves a Vault secret + scoped S3 prefix for a
pipeline run. ``cleanup_credentials`` revokes it. Both dispatch to DTS
via Temporal Nexus; each tenant's workflow namespace has its own Nexus
endpoint that routes to the DTS namespace.

Tenant identity is never taken from the caller — it is read from the
workflow's inbound x-tenant-id header (set by the trusted starter via
``TenantClientInterceptor``). The Nexus endpoint is derived from that
same tenant, so a pipeline author cannot address another tenant's
endpoint even by calling the Nexus SDK directly with private symbols.

Usage::

    with workflow.unsafe.imports_passed_through():
        from pipeline_sdk.activities import (
            prepare_credentials, cleanup_credentials,
        )

    creds = await prepare_credentials(
        run_id=workflow.info().workflow_id,
        connection_aliases=[...],
    )
    try:
        ...
    finally:
        await cleanup_credentials(
            run_id=creds.secret_path.split('/')[-1],
            vault_token=creds.vault_token,
        )
"""

from __future__ import annotations

import dataclasses
import os

import nexusrpc
from temporalio import workflow

from pipeline_sdk.tenant import get_current_workflow_tenant
from pipeline_sdk.types import PipelineCredentials


# ── Nexus service (client mirror of DTS CustomPipelinesNexusService) ─
# Source of truth: dts/custom_pipelines/activities/prepare_credentials.py.
# Dataclass fields must match exactly — Nexus wire format is JSON via
# the payload converter.
#
# These types are module-private on purpose: the only supported way for
# a pipeline author to talk to the DTS credentials Nexus service is
# through ``prepare_credentials`` / ``cleanup_credentials`` below. That
# keeps tenant/endpoint resolution under this module's control.


@dataclasses.dataclass(frozen=True)
class _PreparePipelineCredentialsV2Params:
    run_id: str
    connection_aliases: list[dict]
    created_by_user_id: int = 0


@dataclasses.dataclass(frozen=True)
class _PreparePipelineCredentialsV2Result:
    secret_path: str
    vault_token: str
    s3_bucket: str
    s3_prefix: str


@dataclasses.dataclass(frozen=True)
class _CleanupPipelineSecretParams:
    run_id: str
    vault_token: str = ''


@nexusrpc.service(name='CustomPipelinesNexusService')
class CustomPipelinesNexusService:
    prepare_pipeline_credentials_v2: nexusrpc.Operation[
        _PreparePipelineCredentialsV2Params,
        _PreparePipelineCredentialsV2Result,
    ]
    cleanup_pipeline_secret: nexusrpc.Operation[
        _CleanupPipelineSecretParams, None,
    ]


# ── Endpoint ───────────────────────────────────────────────────────
# Single cluster-wide Nexus endpoint targeting the DTS namespace +
# task-queue where CustomPipelinesNexusServiceHandler is hosted.
# Provisioned once via `tctl nexus endpoint create`; tenant isolation
# is enforced by the x-tenant-id header (set by TenantInterceptor on
# outbound and validated on the DTS handler ingress), not by per-tenant
# endpoint names.

# Endpoint name uses dashes (Temporal namespace-name rules for Nexus
# endpoint identifiers). Historically this default was ``im.dts.custom_pipeline``
# which never matched the endpoint actually provisioned in Temporal —
# schedules failed at ``BadScheduleNexusOperationAttributes``. Keep in sync
# with the endpoint created by the DTS provisioning step.
_CREDENTIALS_ENDPOINT = os.getenv(
    'DTS_CREDENTIALS_NEXUS_ENDPOINT', 'im-dts-custom-pipeline',
)


def _nexus_client():
    # Fail-fast if the workflow starter forgot TenantClientInterceptor:
    # without the header the DTS handler would reject the call anyway,
    # but raising here keeps the error close to the real cause.
    get_current_workflow_tenant()
    return workflow.create_nexus_client(
        service=CustomPipelinesNexusService,
        endpoint=_CREDENTIALS_ENDPOINT,
    )


# ── Public wrappers ────────────────────────────────────────────────


async def prepare_credentials(
    run_id: str,
    connection_aliases: list[dict],
    *,
    agency_chief_id: int | None = None,
) -> PipelineCredentials:
    """Call DTS ``prepare_pipeline_credentials_v2`` over Nexus.

    Tenant is taken from the current workflow's ``x-tenant-id`` header
    (propagated by ``TenantInterceptor``). Callers cannot pass another
    tenant — the shared Nexus endpoint is resolved from the module config.
    """
    client = _nexus_client()
    result = await client.execute_operation(
        CustomPipelinesNexusService.prepare_pipeline_credentials_v2,
        _PreparePipelineCredentialsV2Params(
            run_id=run_id,
            connection_aliases=connection_aliases,
            created_by_user_id=agency_chief_id or 0,
        ),
    )
    return PipelineCredentials(
        secret_path=result.secret_path,
        vault_token=result.vault_token,
        s3_bucket=result.s3_bucket,
        s3_prefix=result.s3_prefix,
    )


async def cleanup_credentials(
    run_id: str,
    vault_token: str = '',
) -> None:
    """Call DTS ``cleanup_pipeline_secret`` over Nexus.

    Tenant is taken from the current workflow's ``x-tenant-id`` header.
    """
    client = _nexus_client()
    await client.execute_operation(
        CustomPipelinesNexusService.cleanup_pipeline_secret,
        _CleanupPipelineSecretParams(
            run_id=run_id,
            vault_token=vault_token,
        ),
    )


__all__ = [
    'prepare_credentials',
    'cleanup_credentials',
]
