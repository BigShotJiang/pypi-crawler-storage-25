"""Unit tests for the Nexus-backed credential helpers."""
from __future__ import annotations

import importlib

import pytest

from pipeline_sdk.activities import credentials as credentials_module
from pipeline_sdk.types import PipelineCredentials


def test_default_credentials_endpoint() -> None:
    # Dashes — Temporal Nexus endpoint names cannot contain dots. Keep in
    # sync with the endpoint provisioned on the DTS side.
    assert credentials_module._CREDENTIALS_ENDPOINT == 'im-dts-custom-pipeline'


def test_credentials_endpoint_env_override(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv('DTS_CREDENTIALS_NEXUS_ENDPOINT', 'im-dts-custom-pipeline-staging')
    reloaded = importlib.reload(credentials_module)
    try:
        assert reloaded._CREDENTIALS_ENDPOINT == 'im-dts-custom-pipeline-staging'
    finally:
        monkeypatch.delenv('DTS_CREDENTIALS_NEXUS_ENDPOINT', raising=False)
        importlib.reload(credentials_module)


def test_public_api_accepts_no_tenant_or_endpoint_params() -> None:
    """Tenant/endpoint must not be passable from pipeline authors.

    Guards against regressions that would reintroduce a ``tenant=`` or
    ``nexus_endpoint=`` kwarg on the public helpers — the whole point
    of this API is that tenant identity comes from the trusted inbound
    header only.
    """
    import inspect

    from pipeline_sdk.activities.credentials import (
        cleanup_credentials, prepare_credentials,
    )

    forbidden = {'tenant', 'nexus_endpoint', 'endpoint'}
    for fn in (prepare_credentials, cleanup_credentials):
        params = set(inspect.signature(fn).parameters)
        leaked = params & forbidden
        assert not leaked, (
            f'{fn.__name__} leaks tenant/endpoint params: {leaked}'
        )


def test_pipeline_credentials_has_expected_fields() -> None:
    """Guard against PipelineCredentials drifting from V2 result shape."""
    creds = PipelineCredentials(
        secret_path='p',
        vault_token='t',
        s3_bucket='b',
        s3_prefix='x',
    )
    assert creds.secret_path == 'p'
    assert creds.vault_token == 't'
    assert creds.s3_bucket == 'b'
    assert creds.s3_prefix == 'x'
