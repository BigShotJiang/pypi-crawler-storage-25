"""Vault secret reader — activity-side.

``read_pipeline_secret`` fetches the full pipeline secret from Vault
using the token from ``PipelineCredentials``. Call from
``@activity.defn`` code only — this performs I/O.

``VAULT_ADDR`` / ``VAULT_MOUNT_POINT`` are module-level constants
initialized from environment variables. They can be overridden via
env var before import, or reassigned directly in tests.
"""

from __future__ import annotations

import os

import aiohttp

from pipeline_sdk.types import (
    PipelineSecret,
    S3Credentials,
    StorageCredentials,
    PipelineCredentials,
)

VAULT_ADDR = os.getenv('VAULT_ADDR', 'http://vault:8200')
VAULT_MOUNT_POINT = os.getenv(
    'VAULT_AI_AGENT_MOUNT_POINT',
    'ai_agent',
)


async def read_pipeline_secret(
    creds: PipelineCredentials,
) -> PipelineSecret:
    """Read the full pipeline secret from Vault.

    Call from activity code only (performs I/O).
    """
    url = f'{VAULT_ADDR}/v1/{VAULT_MOUNT_POINT}/data/{creds.secret_path}'
    headers = {'X-Vault-Token': creds.vault_token}

    timeout = aiohttp.ClientTimeout(total=30)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.get(url, headers=headers) as resp:
            resp.raise_for_status()
            body = await resp.json()

    data = body['data']['data']

    return PipelineSecret(
        connections=data['connections'],
        storage=StorageCredentials(**data['storage']),
        dts_session_id=data['dts_session_id'],
        s3=S3Credentials(**data['s3']),
    )


__all__ = ['read_pipeline_secret', 'VAULT_ADDR', 'VAULT_MOUNT_POINT']
