"""Activity-side runtime helpers.

Call these from ``@activity.defn`` functions (they perform I/O
and/or read activity context)::

    from pipeline_sdk.runtime import (
        read_pipeline_secret, PipelineState, get_current_tenant,
        call_datasource_proxy, call_mcp_tool,
    )
"""

from __future__ import annotations

from pipeline_sdk.runtime.platform import PLATFORM_HOST as PLATFORM_HOST
from pipeline_sdk.runtime.proxy import (
    LES_WEB_HOST as LES_WEB_HOST,
    call_datasource_proxy as call_datasource_proxy,
    call_mcp_tool as call_mcp_tool,
)
from pipeline_sdk.runtime.secrets import (
    VAULT_ADDR as VAULT_ADDR,
    VAULT_MOUNT_POINT as VAULT_MOUNT_POINT,
    read_pipeline_secret as read_pipeline_secret,
)
from pipeline_sdk.runtime.state import PipelineState as PipelineState
from pipeline_sdk.tenant import get_current_tenant as get_current_tenant

__all__ = [
    'read_pipeline_secret',
    'PipelineState',
    'get_current_tenant',
    'PLATFORM_HOST',
    'VAULT_ADDR',
    'VAULT_MOUNT_POINT',
    'call_datasource_proxy',
    'call_mcp_tool',
    'LES_WEB_HOST',
]
