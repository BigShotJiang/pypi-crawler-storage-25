"""Unit tests for pipeline_sdk.runtime.proxy."""

from __future__ import annotations

import json
from collections.abc import Iterator
from typing import Any

import aiohttp
import pytest
from aioresponses import aioresponses

from pipeline_sdk.runtime import proxy as proxy_module
from pipeline_sdk.runtime.proxy import (
    call_datasource_proxy,
    call_mcp_tool,
)
from pipeline_sdk.tenant import _current_tenant
from pipeline_sdk.types import TenantID


_DTS_SESSION_ID = 'sess-token'


@pytest.fixture
def les_web_host(monkeypatch: pytest.MonkeyPatch) -> str:
    host = 'https://les-dev.test'
    monkeypatch.setattr(proxy_module, 'LES_WEB_HOST', host)
    return host


@pytest.fixture
def platform_host(monkeypatch: pytest.MonkeyPatch) -> str:
    host = 'https://platform.test'
    monkeypatch.setattr(proxy_module, 'PLATFORM_HOST', host)
    return host


@pytest.fixture(autouse=True)
def _tenant() -> Iterator[TenantID]:
    tenant = TenantID(agency_uuid='agency-uuid', workspace_id=42)
    token = _current_tenant.set(tenant)
    try:
        yield tenant
    finally:
        _current_tenant.reset(token)


def _make_tool_body(payload: Any) -> dict:
    text = payload if isinstance(payload, str) else json.dumps(payload)
    return {'result': {'content': [{'type': 'text', 'text': text}]}}


# ── call_datasource_proxy — secret-proxy on LES_WEB_HOST ───────────


async def test_call_datasource_proxy_yields_aiohttp_response(
    les_web_host: str,
) -> None:
    captured: dict[str, Any] = {}

    def _capture(*_args: Any, **kwargs: Any) -> None:
        captured['json'] = kwargs['json']
        captured['cookies'] = kwargs.get('cookies')

    with aioresponses() as m:
        m.post(
            f'{les_web_host}/api/v4/secret-proxy/request',
            payload={'ok': True},
            status=200,
            callback=_capture,
        )

        async with call_datasource_proxy(
            dts_session_id=_DTS_SESSION_ID,
            data_source='google_ads_ql',
            connection_id=1803,
            method='POST',
            url='https://googleads.googleapis.com/v23/customers/123/userLists:mutate',
            json={'operations': [{'create': {'name': 'aud'}}]},
            headers={'X-Custom': '1'},
            params={'q': 'a'},
        ) as resp:
            assert isinstance(resp, aiohttp.ClientResponse)
            assert resp.status == 200
            assert await resp.json() == {'ok': True}

    assert captured['cookies'] == {'dts_sessionid': _DTS_SESSION_ID}
    # Flat payload — no JSON-RPC envelope, no connectorId stringification.
    assert captured['json'] == {
        'data_source': 'google_ads_ql',
        'connection_id': 1803,
        'method': 'post',
        'url': (
            'https://googleads.googleapis.com/v23/customers/123/'
            'userLists:mutate'
        ),
        'params': {'q': 'a'},
        'headers': {'X-Custom': '1'},
        'json_body': {'operations': [{'create': {'name': 'aud'}}]},
        'data': None,
        'allow_redirects': True,
    }


async def test_call_datasource_proxy_supports_text_response(
    les_web_host: str,
) -> None:
    """Caller can choose .text() instead of .json() — body need not be JSON."""
    with aioresponses() as m:
        m.post(
            f'{les_web_host}/api/v4/secret-proxy/request',
            body='plain error text',
            status=500,
            content_type='text/plain',
        )
        async with call_datasource_proxy(
            dts_session_id=_DTS_SESSION_ID,
            data_source='ds',
            connection_id=1,
            method='get',
            url='https://x.test/y',
        ) as resp:
            assert resp.status == 500
            assert await resp.text() == 'plain error text'


async def test_call_datasource_proxy_supports_streaming_download(
    les_web_host: str,
) -> None:
    """Big-file path — caller streams chunks instead of materializing."""
    body = b'chunk-' * 1000  # 6 KiB to exercise multiple chunks
    with aioresponses() as m:
        m.post(
            f'{les_web_host}/api/v4/secret-proxy/request',
            body=body,
            status=200,
            content_type='application/octet-stream',
        )
        async with call_datasource_proxy(
            dts_session_id=_DTS_SESSION_ID,
            data_source='ds',
            connection_id=1,
            method='get',
            url='https://x.test/file.bin',
        ) as resp:
            assert resp.status == 200
            collected = bytearray()
            async for chunk in resp.content.iter_chunked(1024):
                collected.extend(chunk)
    assert bytes(collected) == body


async def test_call_datasource_proxy_propagates_upstream_status(
    les_web_host: str,
) -> None:
    """Proxy mirrors upstream HTTP — non-2xx must come back as-is, no exception."""
    with aioresponses() as m:
        m.post(
            f'{les_web_host}/api/v4/secret-proxy/request',
            payload={'error': {'code': 'NOT_FOUND'}},
            status=404,
        )
        async with call_datasource_proxy(
            dts_session_id=_DTS_SESSION_ID,
            data_source='ds',
            connection_id=1,
            method='get',
            url='https://x.test/y',
        ) as resp:
            assert resp.status == 404
            assert (await resp.json()) == {'error': {'code': 'NOT_FOUND'}}


async def test_call_datasource_proxy_requires_les_web_host(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(proxy_module, 'LES_WEB_HOST', '')

    with pytest.raises(RuntimeError, match='LES_WEB_HOST'):
        call_datasource_proxy(
            dts_session_id=_DTS_SESSION_ID,
            data_source='ds',
            connection_id=1,
            method='get',
            url='https://x.test/y',
        )


async def test_call_datasource_proxy_lowercases_method(
    les_web_host: str,
) -> None:
    """LES SecretProxyPayload.normalize_method requires lowercase."""
    captured: dict[str, Any] = {}

    def _capture(*_args: Any, **kwargs: Any) -> None:
        captured['json'] = kwargs['json']

    with aioresponses() as m:
        m.post(
            f'{les_web_host}/api/v4/secret-proxy/request',
            payload={},
            callback=_capture,
        )
        async with call_datasource_proxy(
            dts_session_id=_DTS_SESSION_ID,
            data_source='ds',
            connection_id=1,
            method='PATCH',
            url='https://x.test/y',
        ) as resp:
            assert resp.status == 200

    assert captured['json']['method'] == 'patch'


async def test_call_datasource_proxy_reuses_external_session(
    les_web_host: str,
) -> None:
    """Caller-provided session: SDK does not close it after the response."""
    with aioresponses() as m:
        m.post(
            f'{les_web_host}/api/v4/secret-proxy/request',
            payload={'ok': True},
        )
        m.post(
            f'{les_web_host}/api/v4/secret-proxy/request',
            payload={'ok': True},
        )

        async with aiohttp.ClientSession() as session:
            async with call_datasource_proxy(
                dts_session_id=_DTS_SESSION_ID,
                data_source='ds',
                connection_id=1,
                method='get',
                url='https://x.test/y',
                session=session,
            ) as r1:
                assert r1.status == 200
                await r1.read()
            assert not session.closed

            # Same session must still be usable for a second call.
            async with call_datasource_proxy(
                dts_session_id=_DTS_SESSION_ID,
                data_source='ds',
                connection_id=1,
                method='get',
                url='https://x.test/y',
                session=session,
            ) as r2:
                assert r2.status == 200


# ── call_mcp_tool — MCP gateway on PLATFORM_HOST ───────────────────


async def test_call_mcp_tool_sends_correct_envelope_and_parses_json(
    platform_host: str,
) -> None:
    captured: dict[str, Any] = {}

    def _capture(*_args: Any, **kwargs: Any) -> None:
        captured['json'] = kwargs['json']
        captured['headers'] = kwargs['headers']
        captured['cookies'] = kwargs.get('cookies')

    with aioresponses() as m:
        m.post(
            f'{platform_host}/experimental/agent/api/mcp/v1/invoke',
            payload=_make_tool_body({'rows': [1, 2, 3]}),
            callback=_capture,
        )

        result = await call_mcp_tool(
            dts_session_id=_DTS_SESSION_ID,
            data_source='facebook',
            connection_id=987,
            tool_name='get_insights',
            arguments={'date_from': '2026-01-01'},
        )

    assert result == {'rows': [1, 2, 3]}

    assert captured['headers']['x-im-workspace-id'] == '42'
    assert 'Cookie' not in captured['headers']
    assert captured['cookies'] == {'dts_sessionid': _DTS_SESSION_ID}

    args = captured['json']['params']['arguments']
    assert captured['json']['params']['name'] == 'mcpCallToolTool'
    assert args == {
        'dataSource': 'facebook',
        'connectionId': 987,
        'toolName': 'get_insights',
        'arguments': {'date_from': '2026-01-01'},
    }


async def test_call_mcp_tool_returns_raw_text_when_not_json(
    platform_host: str,
) -> None:
    with aioresponses() as m:
        m.post(
            f'{platform_host}/experimental/agent/api/mcp/v1/invoke',
            payload=_make_tool_body('not json — just a message'),
        )

        result = await call_mcp_tool(
            dts_session_id=_DTS_SESSION_ID,
            data_source='ds',
            connection_id=1,
            tool_name='ping',
            arguments={},
        )

    assert result == 'not json — just a message'


async def test_call_mcp_tool_returns_none_on_empty_content(
    platform_host: str,
) -> None:
    with aioresponses() as m:
        m.post(
            f'{platform_host}/experimental/agent/api/mcp/v1/invoke',
            payload={'result': {'content': []}},
        )

        result = await call_mcp_tool(
            dts_session_id=_DTS_SESSION_ID,
            data_source='ds',
            connection_id=1,
            tool_name='ping',
            arguments={},
        )

    assert result is None


async def test_call_mcp_tool_raises_on_jsonrpc_error(
    platform_host: str,
) -> None:
    with aioresponses() as m:
        m.post(
            f'{platform_host}/experimental/agent/api/mcp/v1/invoke',
            payload={'error': {'code': -32000, 'message': 'boom'}},
        )

        with pytest.raises(RuntimeError, match='mcpCallToolTool'):
            await call_mcp_tool(
                dts_session_id=_DTS_SESSION_ID,
                data_source='ds',
                connection_id=1,
                tool_name='ping',
                arguments={},
            )


async def test_call_mcp_tool_raises_for_non_2xx_gateway_response(
    platform_host: str,
) -> None:
    """Gateway 5xx with HTML/plain body must surface the HTTP status,
    not get swallowed by ContentTypeError on resp.json()."""
    with aioresponses() as m:
        m.post(
            f'{platform_host}/experimental/agent/api/mcp/v1/invoke',
            body='<html>502 Bad Gateway</html>',
            status=502,
            content_type='text/html',
        )

        with pytest.raises(aiohttp.ClientResponseError) as exc:
            await call_mcp_tool(
                dts_session_id=_DTS_SESSION_ID,
                data_source='ds',
                connection_id=1,
                tool_name='ping',
                arguments={},
            )
    assert exc.value.status == 502


async def test_call_mcp_tool_requires_platform_host(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(proxy_module, 'PLATFORM_HOST', '')

    with pytest.raises(RuntimeError, match='PLATFORM_HOST'):
        await call_mcp_tool(
            dts_session_id=_DTS_SESSION_ID,
            data_source='ds',
            connection_id=1,
            tool_name='ping',
            arguments={},
        )
