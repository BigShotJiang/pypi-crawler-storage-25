"""Platform host config — activity-side.

``PLATFORM_HOST`` is the base URL of the Improvado platform API
(e.g. ``https://report.improvado.io/``). Tenant pipeline code reads
it to construct platform-facing HTTP requests from activities.

Initialized from the ``PLATFORM_HOST`` environment variable,
propagated into tenant worker pods by the Workflow Manager
autoscaler. Reassign for tests.
"""

from __future__ import annotations

import os

PLATFORM_HOST = os.getenv('PLATFORM_HOST', '')

__all__ = ['PLATFORM_HOST']
