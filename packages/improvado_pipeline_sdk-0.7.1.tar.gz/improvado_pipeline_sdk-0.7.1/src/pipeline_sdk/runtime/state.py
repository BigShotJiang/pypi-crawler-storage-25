"""Durable pipeline state in ClickHouse.

Activities can persist key-value state across pipeline runs using
``PipelineState``. State is scoped per workflow type + tenant and
stored in a ``ReplacingMergeTree`` table with TTL cleanup for adhoc
runs.

pipeline_id is built automatically from ``activity.info().workflow_type``
and ``get_current_tenant()`` — no manual configuration needed.

Usage::

    from pipeline_sdk.runtime import PipelineState, read_pipeline_secret

    @activity.defn
    async def my_activity(params) -> Result:
        secret = await read_pipeline_secret(params.creds)
        state = PipelineState(storage=secret.storage)

        last_cursor = state.get('cursor')
        state.set('cursor', '2026-04-08')
        state.set({'cursor': '2026-04-08', 'rows_loaded': '42000'})
        state.delete('cursor')
        state.delete()
        all_state = state.get()
"""

from __future__ import annotations

from typing import overload

import clickhouse_connect
from temporalio import activity

from pipeline_sdk.tenant import get_current_tenant
from pipeline_sdk.types import StorageCredentials

_STATE_TABLE = '_custom_pipeline_state'


def _parse_host(raw_host: str) -> tuple[str, int | None, bool]:
    """Parse host that may contain scheme and/or port."""
    secure = False
    host = raw_host
    if host.startswith('https://'):
        host = host[len('https://'):]
        secure = True
    elif host.startswith('http://'):
        host = host[len('http://'):]

    port = None
    if ':' in host:
        host, port_str = host.rsplit(':', 1)
        try:
            port = int(port_str)
        except ValueError:
            pass

    return host.rstrip('/'), port, secure


def _build_pipeline_id() -> str:
    """Build pipeline_id from activity context: workflow_type + tenant.

    Format: '{workflow_type}:{agency_uuid}/{workspace_id}'
    """
    info = activity.info()
    tenant = get_current_tenant()
    return f'{info.workflow_type}:{tenant.path_prefix}'


class PipelineState:
    """Key-value state persistence for a pipeline.

    Backed by ClickHouse ``_custom_pipeline_state`` table
    (``ReplacingMergeTree``, TTL 7 days for adhoc runs).

    State is scoped by workflow type + tenant — the same workflow
    running for the same tenant shares state across runs.
    """

    def __init__(self, storage: StorageCredentials) -> None:
        self._pipeline_id = _build_pipeline_id()
        self._is_adhoc = activity.info().workflow_id.startswith('adhoc-')
        self._client = self._make_client(storage)
        self._ensure_table()

    def _make_client(self, storage: StorageCredentials):
        host, parsed_port, secure = _parse_host(storage.host)
        port = parsed_port or 8123
        return clickhouse_connect.get_client(
            host=host,
            port=port,
            database=storage.database,
            username=storage.user,
            password=storage.password,
            secure=secure,
        )

    def _ensure_table(self) -> None:
        self._client.command(f"""
            CREATE TABLE IF NOT EXISTS {_STATE_TABLE} (
                pipeline_id String,
                key String,
                value String,
                is_adhoc UInt8 DEFAULT 0,
                updated_at DateTime DEFAULT now()
            ) ENGINE = ReplacingMergeTree(updated_at)
            ORDER BY (pipeline_id, key)
            TTL updated_at + INTERVAL 7 DAY WHERE is_adhoc = 1
        """)

    @overload
    def get(self, key: str) -> str | None: ...
    @overload
    def get(self) -> dict[str, str]: ...

    def get(self, key: str | None = None):
        """Read pipeline state.

        With key: returns the value as str, or None if not found.
        Without key: returns all state as dict[str, str].
        """
        pid = self._pipeline_id

        if key is not None:
            result = self._client.query(
                f'SELECT value FROM {_STATE_TABLE} FINAL '
                f'WHERE pipeline_id = {{pid:String}} '
                f"AND key = {{key:String}} AND value != ''",
                parameters={'pid': pid, 'key': key},
            )
            rows = result.result_rows
            return rows[0][0] if rows else None

        result = self._client.query(
            f'SELECT key, value FROM {_STATE_TABLE} FINAL '
            f"WHERE pipeline_id = {{pid:String}} AND value != ''",
            parameters={'pid': pid},
        )
        return {row[0]: row[1] for row in result.result_rows}

    def set(self, key_or_dict, value: str | None = None) -> None:
        """Upsert pipeline state.

        Accepts either (key, value) for a single entry,
        or a dict of {key: value} for multiple entries.
        """
        adhoc = 1 if self._is_adhoc else 0

        if isinstance(key_or_dict, dict):
            pairs = key_or_dict
        else:
            if value is None:
                raise TypeError(
                    'value must be a str when key_or_dict is a str',
                )
            pairs = {key_or_dict: value}

        rows = [
            [self._pipeline_id, k, v, adhoc] for k, v in pairs.items()
        ]
        self._client.insert(
            _STATE_TABLE,
            rows,
            column_names=['pipeline_id', 'key', 'value', 'is_adhoc'],
        )

    def delete(self, key: str | None = None) -> None:
        """Delete pipeline state by overwriting with empty value.

        With key: deletes a single key.
        Without key: clears all state for this pipeline.
        """
        adhoc = 1 if self._is_adhoc else 0

        if key is not None:
            self._client.insert(
                _STATE_TABLE,
                [[self._pipeline_id, key, '', adhoc]],
                column_names=[
                    'pipeline_id', 'key', 'value', 'is_adhoc',
                ],
            )
        else:
            existing = self._client.query(
                f'SELECT key FROM {_STATE_TABLE} FINAL '
                f"WHERE pipeline_id = {{pid:String}} AND value != ''",
                parameters={'pid': self._pipeline_id},
            )
            keys = [row[0] for row in existing.result_rows]
            if keys:
                rows = [
                    [self._pipeline_id, k, '', adhoc] for k in keys
                ]
                self._client.insert(
                    _STATE_TABLE,
                    rows,
                    column_names=[
                        'pipeline_id', 'key', 'value', 'is_adhoc',
                    ],
                )


__all__ = ['PipelineState']
