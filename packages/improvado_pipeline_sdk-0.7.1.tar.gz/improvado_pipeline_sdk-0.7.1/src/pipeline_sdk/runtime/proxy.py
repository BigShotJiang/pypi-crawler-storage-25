"""Platform proxy helpers — activity-side.

Two thin helpers, two different gateways:

* ``call_datasource_proxy`` — proxy an HTTP request to a data-source
  provider through the LES **secret-proxy** at
  ``POST {LES_WEB_HOST}/api/v4/secret-proxy/request``. The proxy resolves
  credentials from the connection ID, signs/authenticates the request,
  and streams the upstream response back unchanged. Use this whenever
  the workflow's own credentials are insufficient to talk to the
  provider directly.

  Returns an ``aiohttp`` request context manager — the caller picks
  how to consume the response (JSON, text, byte stream).

* ``call_mcp_tool`` — call an MCP tool registered on a data-source
  connection through the platform MCP gateway at
  ``POST {PLATFORM_HOST}/experimental/agent/api/mcp/v1/invoke``. This
  is JSON-RPC ``tools/call`` for ``mcpCallToolTool``.

Both take ``dts_session_id`` directly (you would normally read it from
``read_pipeline_secret(creds).dts_session_id``). ``call_mcp_tool``
additionally pulls ``workspace_id`` from ``get_current_tenant()``.

Note: ``dts_session_id`` is only populated when the workflow was started
with ``prepare_credentials(..., agency_chief_id=<user_id>)`` — DTS
provisions an impersonated session under that user. Without it, the
secret carries an empty string and the gateway returns 401.

Usage::

    @activity.defn
    async def push_audience(params) -> ...:
        secret = await read_pipeline_secret(params.creds)

        # JSON request/response
        async with call_datasource_proxy(
            dts_session_id=secret.dts_session_id,
            data_source='google_ads_ql',
            connection_id=params.connection_id,
            method='post',
            url=f'{base}/userLists:mutate',
            json={'operations': [...]},
        ) as resp:
            if resp.status not in (200, 201):
                raise RuntimeError(
                    f'userLists:mutate {resp.status}: {await resp.text()}'
                )
            user_list = (await resp.json())['results'][0]['resourceName']

        # Stream a binary download to disk
        async with call_datasource_proxy(
            dts_session_id=secret.dts_session_id,
            data_source='dropbox',
            connection_id=params.connection_id,
            method='get',
            url=f'{base}/files/download/{file_id}',
        ) as resp:
            with open('/tmp/file.bin', 'wb') as f:
                async for chunk in resp.content.iter_chunked(64 * 1024):
                    f.write(chunk)

        # Reuse one session across many proxy calls in a tight loop.
        async with aiohttp.ClientSession() as session:
            for batch in batches:
                async with call_datasource_proxy(
                    dts_session_id=secret.dts_session_id,
                    data_source='google_ads_ql',
                    connection_id=params.connection_id,
                    method='post',
                    url=...,
                    json=...,
                    session=session,
                ) as resp:
                    resp.raise_for_status()
"""

from __future__ import annotations

import json as _json
import os
from typing import Any

import aiohttp

from pipeline_sdk.runtime.platform import PLATFORM_HOST
from pipeline_sdk.tenant import get_current_tenant

# ── Module-level config ────────────────────────────────────────────

LES_WEB_HOST = os.getenv('LES_WEB_HOST', '')
"""Base URL of the LES web service hosting ``/api/v4/secret-proxy/request``.

Per-cluster (e.g. ``https://les-dev.tools.improvado.io`` on lisbon).
Set on the tenant pipeline worker pod by the autoscaler. Reassign for
tests.
"""

# ── Internal constants ─────────────────────────────────────────────

_SECRET_PROXY_PATH = '/api/v4/secret-proxy/request'
_MCP_INVOKE_PATH = '/experimental/agent/api/mcp/v1/invoke'

_DEFAULT_TIMEOUT_SECONDS = 60.0
_MCP_CALL_TOOL = 'mcpCallToolTool'


# ── Public helpers ─────────────────────────────────────────────────


def call_datasource_proxy(
    *,
    dts_session_id: str,
    data_source: str,
    connection_id: int,
    method: str,
    url: str,
    json: Any = None,
    data: Any = None,
    params: dict[str, Any] | None = None,
    headers: dict[str, str] | None = None,
    allow_redirects: bool = True,
    session: aiohttp.ClientSession | None = None,
    request_timeout: float = _DEFAULT_TIMEOUT_SECONDS,
) -> _ProxyRequestCM:
    """Proxy an HTTP request to a data-source provider via secret-proxy.

    Returns an async context manager yielding an ``aiohttp.ClientResponse``
    that mirrors the upstream provider's HTTP response — same status,
    headers (minus hop-by-hop), and body. Consume with ``await
    resp.json()`` / ``await resp.text()`` / ``await resp.read()`` /
    ``resp.content.iter_chunked(...)`` depending on payload size and
    type.

    The proxy resolves credentials from ``connection_id``, applies
    provider-specific auth (OAuth refresh, signing, headers) and forwards
    the request. Use this when the workflow's own credentials are not
    enough to reach the provider — e.g. Google Ads, Meta, Snapchat.

    Must be called from ``@activity.defn`` code (performs I/O).
    """
    if not LES_WEB_HOST:
        raise RuntimeError(
            'LES_WEB_HOST is not set — tenant pipeline workers must '
            'have it injected by the autoscaler. See ADR-003.',
        )

    payload: dict[str, Any] = {
        'data_source': data_source,
        'connection_id': connection_id,
        'method': method.lower(),
        'url': url,
        'params': params,
        'headers': headers,
        'json_body': json,
        'data': data,
        'allow_redirects': allow_redirects,
    }
    proxy_url = f'{LES_WEB_HOST.rstrip("/")}{_SECRET_PROXY_PATH}'
    return _ProxyRequestCM(
        url=proxy_url,
        payload=payload,
        cookies={'dts_sessionid': dts_session_id},
        timeout=aiohttp.ClientTimeout(total=request_timeout),
        external_session=session,
    )


async def call_mcp_tool(
    *,
    dts_session_id: str,
    data_source: str,
    connection_id: int,
    tool_name: str,
    arguments: dict[str, Any],
    session: aiohttp.ClientSession | None = None,
    request_timeout: float = _DEFAULT_TIMEOUT_SECONDS,
) -> Any:
    """Call an MCP tool registered for a data-source connection.

    Equivalent to MCP's ``mcpCallToolTool``. Returns the parsed tool
    result — JSON-decoded if the tool produced JSON text, otherwise the
    raw text payload.

    Must be called from ``@activity.defn`` code (performs I/O).
    """
    if not PLATFORM_HOST:
        raise RuntimeError(
            'PLATFORM_HOST is not set — tenant pipeline workers must '
            'have it injected by the autoscaler. See ADR-003.',
        )

    tenant = get_current_tenant()
    invoke_url = f'{PLATFORM_HOST.rstrip("/")}{_MCP_INVOKE_PATH}'
    payload = {
        'jsonrpc': '2.0',
        'id': '1',
        'method': 'tools/call',
        'params': {
            'name': _MCP_CALL_TOOL,
            'arguments': {
                'dataSource': data_source,
                'connectionId': connection_id,
                'toolName': tool_name,
                'arguments': arguments,
            },
        },
    }
    request_headers = {
        'Content-Type': 'application/json',
        'x-im-workspace-id': str(tenant.workspace_id),
    }
    request_cookies = {'dts_sessionid': dts_session_id}
    timeout = aiohttp.ClientTimeout(total=request_timeout)

    async def _post(s: aiohttp.ClientSession) -> dict[str, Any]:
        async with s.post(
            invoke_url,
            headers=request_headers,
            cookies=request_cookies,
            json=payload,
            timeout=timeout,
        ) as resp:
            resp.raise_for_status()
            body = await resp.json()
        if 'error' in body:
            raise RuntimeError(
                f'MCP invoke error ({_MCP_CALL_TOOL}): {body["error"]}',
            )
        return body

    if session is not None:
        body = await _post(session)
    else:
        async with aiohttp.ClientSession() as owned:
            body = await _post(owned)
    return _parse_tool_content(body)


# ── Internals ──────────────────────────────────────────────────────


class _ProxyRequestCM:
    """Async context manager for a secret-proxy POST.

    Owns an aiohttp ClientSession when the caller didn't pass one, so
    the underlying connection lives exactly as long as the response.
    """

    def __init__(
        self,
        *,
        url: str,
        payload: dict[str, Any],
        cookies: dict[str, str],
        timeout: aiohttp.ClientTimeout,
        external_session: aiohttp.ClientSession | None,
    ) -> None:
        self._url = url
        self._payload = payload
        self._cookies = cookies
        self._timeout = timeout
        self._external_session = external_session
        self._owned_session: aiohttp.ClientSession | None = None
        self._resp_cm: Any = None

    async def __aenter__(self) -> aiohttp.ClientResponse:
        if self._external_session is not None:
            session = self._external_session
        else:
            self._owned_session = aiohttp.ClientSession()
            session = self._owned_session

        self._resp_cm = session.post(
            self._url,
            json=self._payload,
            cookies=self._cookies,
            timeout=self._timeout,
        )
        try:
            return await self._resp_cm.__aenter__()
        except BaseException:
            await self._close_owned_session()
            raise

    async def __aexit__(self, exc_type, exc, tb) -> None:
        try:
            if self._resp_cm is not None:
                await self._resp_cm.__aexit__(exc_type, exc, tb)
        finally:
            await self._close_owned_session()

    async def _close_owned_session(self) -> None:
        if self._owned_session is not None:
            await self._owned_session.close()
            self._owned_session = None


def _parse_tool_content(body: dict[str, Any]) -> Any:
    contents = body['result']['content']
    if not contents:
        return None
    first = contents[0]
    text = first.get('text')
    if text is None:
        return first
    try:
        return _json.loads(text)
    except (ValueError, TypeError):
        return text


__all__ = [
    'LES_WEB_HOST',
    'call_datasource_proxy',
    'call_mcp_tool',
]
