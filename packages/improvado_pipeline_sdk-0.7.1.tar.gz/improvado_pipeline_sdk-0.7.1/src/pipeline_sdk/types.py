"""Shared pure types for the pipeline SDK.

All dataclasses and enums here are Temporal-serializable and
sandbox-safe: no I/O, no side effects. Import from either workflow
or activity code.

Public symbols are listed in ``__all__``. Nested LES types
(``LesActivityResult``, ``StageResult``, ``ReportTypeMeta``,
``SchemaField``, ``CursorRange``) are reachable through attribute
access on ``LesActivityWithS3Result`` and remain importable by name,
but are not part of the primary public surface.
"""

from __future__ import annotations

import dataclasses
import datetime
import enum
import uuid
from typing import Any

from temporalio.exceptions import ApplicationError


# ── Storage & Data References ──────────────────────────────────────


class StorageType(str, enum.Enum):
    S3 = 's3'
    NFS = 'nfs'


@dataclasses.dataclass(frozen=True)
class DataRef:
    """Pointer to data in S3 or NFS.

    Large data never flows through Temporal payloads — only refs.

    Examples::

        DataRef.s3('bucket', 'key/path.parquet', 'parquet')
        DataRef.nfs('/media/les_efs/store/run1/result.json',
                    'json_each_row')
    """

    storage: str  # StorageType value: 's3' | 'nfs'
    path: str  # s3: 'bucket/key', nfs: absolute path
    data_format: str  # 'parquet' | 'json' | 'csv' | 'json_each_row'

    @staticmethod
    def s3(bucket: str, key: str, fmt: str) -> DataRef:
        return DataRef(
            storage=StorageType.S3,
            path=f'{bucket}/{key}',
            data_format=fmt,
        )

    @staticmethod
    def nfs(path: str, fmt: str) -> DataRef:
        return DataRef(
            storage=StorageType.NFS,
            path=path,
            data_format=fmt,
        )

    @property
    def uri(self) -> str:
        if self.storage == StorageType.S3:
            return f's3://{self.path}'
        return self.path

    @property
    def s3_bucket(self) -> str:
        if self.storage != StorageType.S3:
            raise ValueError(f'Not an S3 ref: {self.storage}')
        return self.path.split('/', 1)[0]

    @property
    def s3_key(self) -> str:
        if self.storage != StorageType.S3:
            raise ValueError(f'Not an S3 ref: {self.storage}')
        return self.path.split('/', 1)[1]

    @property
    def is_s3(self) -> bool:
        return self.storage == StorageType.S3

    @property
    def is_nfs(self) -> bool:
        return self.storage == StorageType.NFS


# ── Cluster ────────────────────────────────────────────────────────


class Cluster(str, enum.Enum):
    LISBON = 'lisbon'
    TOKYO = 'tokyo'
    MONTANA = 'montana'


# ── Tenant ─────────────────────────────────────────────────────────


# Temporal namespace convention for tenant pipeline workers.
#
# Naming: ``tenant.<agency_uuid>.<workspace_id>[.<user_id>]``.
# - ``.`` (not ``-``) is used as the field separator because
#   ``agency_uuid`` may itself contain ``-`` (UUIDs, slugs), which
#   would make ``-``-split ambiguous.
# - ``:`` would have been the other natural choice but is rejected
#   by Temporal's namespace name validator; ``.`` is allowed.
# - Trailing ``user_id`` distinguishes two first-class tenant scopes
#   that coexist permanently (ADR-010): workspace-scope
#   (``user_id is None``) shares one namespace per workspace,
#   user-scope (``user_id`` set) gives per-user isolation across
#   every derived identifier (namespace, task queue, S3 prefix, K8s
#   deployment/SA name, schedule prefix). Workspace-scope is not a
#   migration step — it stays the right choice whenever per-user
#   isolation isn't needed.
# - A future short form ``tenant.<tenant_id>`` (single-segment opaque
#   id) is planned; its parser will do a DB lookup to resolve back
#   to ``(agency_uuid, workspace_id)`` and is out of scope here.
#
# Both the tenant worker starter (which creates the namespace) and
# the DTS Nexus handler (which validates the caller namespace against
# the x-tenant-id header) must agree on this encoding — keep that
# in mind when changing either helper.
_TENANT_NAMESPACE_PREFIX = 'tenant.'


@dataclasses.dataclass(frozen=True)
class TenantID:
    agency_uuid: str
    workspace_id: int
    user_id: int | None = None

    def __post_init__(self) -> None:
        # Canonicalize real UUIDs to lowercase-dashed form so downstream
        # case-sensitive consumers (schedule_id / run_id prefixes, S3
        # keys, ownership ``startswith`` checks) observe a single
        # representation. Non-UUID strings pass through unchanged —
        # ``TenantID`` is also built from internal test fixtures.
        try:
            canonical = str(uuid.UUID(self.agency_uuid))
        except (ValueError, AttributeError):
            return
        if canonical != self.agency_uuid:
            object.__setattr__(self, 'agency_uuid', canonical)

    @property
    def path_prefix(self) -> str:
        """S3/NFS path segment: ``{agency_uuid}/{workspace_id}[/{user_id}]``."""
        if self.user_id is None:
            return f'{self.agency_uuid}/{self.workspace_id}'
        return f'{self.agency_uuid}/{self.workspace_id}/{self.user_id}'

    def to_namespace(self) -> str:
        """Render as Temporal namespace ``tenant.<agency>.<ws>[.<user_id>]``."""
        base = (
            f'{_TENANT_NAMESPACE_PREFIX}{self.agency_uuid}'
            f'.{self.workspace_id}'
        )
        if self.user_id is None:
            return base
        return f'{base}.{self.user_id}'

    @classmethod
    def from_namespace(cls, ns: str) -> TenantID:
        """Parse a Temporal namespace name into a ``TenantID``.

        Captures the optional 4th segment as ``user_id``. Raises
        ``ValueError`` if ``ns`` does not match the
        ``tenant.<agency>.<workspace>[.<user_id>]`` form. The short
        ``tenant.<tenant_id>`` (single-segment) form is not yet
        supported here — see module comment.
        """
        if not ns.startswith(_TENANT_NAMESPACE_PREFIX):
            raise ValueError(
                f'Namespace {ns!r} is not a tenant namespace '
                f'(expected prefix {_TENANT_NAMESPACE_PREFIX!r}).',
            )
        parts = ns[len(_TENANT_NAMESPACE_PREFIX):].split('.')
        if len(parts) < 2:
            raise ValueError(
                f'Short tenant.<id> form {ns!r} is not yet supported '
                '— needs tenant_id resolver follow-up.',
            )
        if len(parts) > 3:
            raise ValueError(
                f'Tenant namespace {ns!r} has too many segments '
                f'(expected 2 or 3 after prefix, got {len(parts)}).',
            )
        try:
            workspace = int(parts[1])
        except ValueError as exc:
            raise ValueError(
                f'workspace segment {parts[1]!r} in {ns!r} is not an int',
            ) from exc
        user_id: int | None = None
        if len(parts) == 3:
            try:
                user_id = int(parts[2])
            except ValueError as exc:
                raise ValueError(
                    f'user_id segment {parts[2]!r} in {ns!r} is not an int',
                ) from exc
        return cls(
            agency_uuid=parts[0],
            workspace_id=workspace,
            user_id=user_id,
        )


# ── Credentials ────────────────────────────────────────────────────


@dataclasses.dataclass(frozen=True)
class S3Credentials:
    access_key: str
    secret_key: str
    session_token: str
    bucket: str
    # Layout (ADR-010 §Phase 2):
    #   'pipeline-data/{agency_uuid}/{workspace_id}[/{user_id}]/{run_id}'
    prefix: str


@dataclasses.dataclass(frozen=True)
class StorageCredentials:
    host: str  # 'http://ch-host:8123'
    database: str
    user: str
    password: str


@dataclasses.dataclass(frozen=True)
class PipelineSecret:
    """Full contents of the Vault secret for a pipeline run."""

    connections: dict[str, dict]  # alias -> credential dict
    storage: StorageCredentials
    dts_session_id: str
    s3: S3Credentials


@dataclasses.dataclass(frozen=True)
class PipelineCredentials:
    """Returned by ``prepare_credentials``. Vault pointer + S3."""

    secret_path: str  # 'custom-pipelines/{run_id}'
    vault_token: str  # scoped read-only Vault token
    s3_bucket: str
    # Layout (ADR-010 §Phase 2):
    #   'pipeline-data/{agency_uuid}/{workspace_id}[/{user_id}]/{run_id}'
    s3_prefix: str


# ── LES — date range ───────────────────────────────────────────────


class DateRangeType(str, enum.Enum):
    LIVE = 'live'
    AUTO = 'auto'
    MANUAL = 'manual'
    MAX = 'max'
    SYNC_HISTORICAL = 'sync_historical'
    CUSTOM = 'custom'
    CUSTOM_REFRESH_WINDOW = 'custom_refresh_window'
    LIFETIME = 'lifetime'


@dataclasses.dataclass(frozen=True)
class DateRangeRequest:
    """Date range for LES extraction."""

    date_range_type: DateRangeType
    params: dict[str, Any]

    def __init__(self, **kwargs: Any) -> None:
        ttype = kwargs.get('date_range_type') or kwargs.get('type')
        object.__setattr__(
            self,
            'date_range_type',
            DateRangeType(ttype),
        )
        object.__setattr__(
            self,
            'params',
            kwargs.get('params') or kwargs.get('param'),
        )


# ── LES — nested result types (internal surface) ──────────────────


class _LesFieldType(str, enum.Enum):
    STRING = 'string'
    DATE = 'date'
    BOOL = 'boolean'
    NUMBER = 'number'
    OBJECT = 'object'


class _LesFieldKind(str, enum.Enum):
    METRIC = 'metric'
    DIMENSION = 'dimension'
    PROPERTY = 'property'
    DATE_KEY = 'date_key'


class _ReportTypeClass(str, enum.Enum):
    DAILY = 'daily'
    MONTHLY = 'monthly'
    WEEKLY = 'weekly'
    LAST_DAY = 'last_day'
    LAST_DAY_INCREMENTAL = 'last_day_incremental'
    DEFAULT = 'default'


class _WriteMethod(str, enum.Enum):
    OVERWRITE = 'overwrite'
    UPSERT = 'upsert'


class _WriteScope(str, enum.Enum):
    BY_DATE_RANGE = 'by_date_range'
    WHOLE_DATA = 'whole_data'


class _DuplicatesStatus(str, enum.Enum):
    NO_DUPLICATES = 'no_duplicates'
    VALID_DUPLICATES = 'valid_duplicates'
    INVALID_DUPLICATES = 'invalid_duplicates'


_TCursorValue = datetime.date | datetime.datetime | int


@dataclasses.dataclass(frozen=True)
class SchemaField:
    type: _LesFieldType  # noqa: A003
    name: str
    sql_name: str
    kind: _LesFieldKind
    title: str
    required: bool = False
    dynamic: bool = False


@dataclasses.dataclass(frozen=True)
class CursorRange:
    min_value: _TCursorValue
    max_value: _TCursorValue


@dataclasses.dataclass(frozen=True)
class StageResult:
    name: str
    path: str
    raw_storage_path: str = ''
    cursor_range: CursorRange | None = None
    fields: list[SchemaField] | None = None

    def get_range(self) -> tuple[datetime.date, datetime.date]:
        """Return (date_from, date_to) from cursor_range.

        Falls back to 1970-01-01 range for non-date cursors.
        """
        empty = (datetime.date(1970, 1, 1), datetime.date(1970, 1, 1))
        if self.cursor_range is None:
            return empty

        max_value = self.cursor_range.max_value
        min_value = self.cursor_range.min_value

        if (
            isinstance(min_value, datetime.date)
            and isinstance(max_value, datetime.date)
            and not isinstance(min_value, datetime.datetime)
            and not isinstance(max_value, datetime.datetime)
        ):
            return min_value, max_value

        if (
            isinstance(min_value, datetime.datetime)
            and isinstance(max_value, datetime.datetime)
        ):
            return min_value.date(), max_value.date()

        return empty


@dataclasses.dataclass(frozen=True)
class ReportTypeMeta:
    report_type_class: _ReportTypeClass
    write_method: _WriteMethod
    write_scope: _WriteScope
    duplicates_status: _DuplicatesStatus


@dataclasses.dataclass(frozen=True)
class LesActivityResult:
    stages: list[StageResult]
    result_stage_name: str
    report_type_meta: ReportTypeMeta
    result_stage_has_data: bool | None = None
    raw_responses_path: str = ''

    @property
    def result_stage(self) -> StageResult:
        for stage in self.stages:
            if stage.name == self.result_stage_name:
                return stage
        raise ApplicationError(
            f'Stage {self.result_stage_name} not found in stages',
        )


@dataclasses.dataclass(frozen=True)
class _LesS3UploadActivityParams:
    """Internal params for ``run_les_activity_with_s3_upload``."""

    connector_id: int
    data_source: str
    report_type: str
    fields: list[str] = dataclasses.field(default_factory=list)
    date_range_request: DateRangeRequest | None = None
    args: dict[str, Any] = dataclasses.field(default_factory=dict)
    hashed_fields: list[str] = dataclasses.field(
        default_factory=list,
    )
    save_raw_data: bool = False
    raw_responses_exclude_request: bool = False


@dataclasses.dataclass(frozen=True)
class LesActivityWithS3Result:
    """Return type of ``les_extract``."""

    executor_result: LesActivityResult
    s3_bucket: str = ''
    s3_key: str = ''
    data_format: str = 'json_each_row'

    @property
    def result_stage_has_data(self) -> bool | None:
        return self.executor_result.result_stage_has_data

    @property
    def data_ref(self) -> DataRef:
        if not self.s3_bucket:
            return DataRef.nfs(path='', fmt=self.data_format)
        return DataRef.s3(
            bucket=self.s3_bucket,
            key=self.s3_key,
            fmt=self.data_format,
        )


# ── CH Loader — result ─────────────────────────────────────────────


@dataclasses.dataclass(frozen=True)
class PipelineLoadResult:
    """Return type of ``ch_load``."""

    error: str | None
    inserted_rows: int
    deleted_rows: int
    processed_rows: int
    updated_rows: int
    duplicate_rows: int
    actual_date_from: datetime.date
    actual_date_to: datetime.date


__all__ = [
    # Data references
    'DataRef',
    'StorageType',
    # Tenant / cluster
    'TenantID',
    'Cluster',
    # Credentials
    'PipelineCredentials',
    'PipelineSecret',
    'S3Credentials',
    'StorageCredentials',
    # LES
    'DateRangeRequest',
    'DateRangeType',
    'LesActivityWithS3Result',
    # CH Loader
    'PipelineLoadResult',
]
