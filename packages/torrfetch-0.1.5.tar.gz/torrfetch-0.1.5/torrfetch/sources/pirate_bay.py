import aiohttp
from bs4 import BeautifulSoup

BASE_URLS = [
    "https://thepiratebay.xyz/",
    "https://thepiratebay.party/",
    "https://thepibay.site/",
]


def _parse_int(value):
    try:
        return int(value.strip())
    except (TypeError, ValueError, AttributeError):
        return 0


def _parse_results(html):
    results = []
    soup = BeautifulSoup(html, "html.parser")
    rows = soup.select("table#searchResult tr")

    if not rows:
        return []

    for row in rows:
        cols = row.find_all("td")
        if len(cols) < 4:
            continue

        title_tag = cols[1].find("a", href=lambda h: h and "/torrent/" in h)
        if not title_tag:
            continue
        title = title_tag.text.strip()

        magnet_tag = row.find("a", href=lambda h: h and h.startswith("magnet:?"))
        magnet = magnet_tag["href"] if magnet_tag else None

        uploaded = cols[2].get_text(" ", strip=True) if len(cols) > 2 else "Unknown"
        seeders = _parse_int(cols[-2].get_text()) if len(cols) >= 2 else 0
        leechers = _parse_int(cols[-1].get_text()) if len(cols) >= 1 else 0
        size = "Unknown"
        uploader = "Unknown"

        category_tag = cols[0].find("a")
        category = category_tag.text if category_tag else "Unknown"

        results.append({
            "title": title,
            "magnet": magnet,
            "size": size,
            "uploaded": uploaded,
            "uploader": uploader,
            "category": category,
            "seeders": seeders,
            "leechers": leechers,
            "source": "piratebay",
        })

    return results

async def search(query, timeout=10):
    headers = {"User-Agent": "Mozilla/5.0"}

    try:
        timeout_obj = aiohttp.ClientTimeout(total=timeout)
        async with aiohttp.ClientSession(timeout=timeout_obj) as session:
            for base_url in BASE_URLS:
                search_url = f"{base_url}search/{query.replace(' ', '%20')}/1/7/0"
                try:
                    async with session.get(search_url, headers=headers) as resp:
                        if resp.status != 200:
                            continue
                        html = await resp.text()
                except Exception:
                    continue

                results = _parse_results(html)
                if results:
                    return results
    except Exception:
        pass

    return []
