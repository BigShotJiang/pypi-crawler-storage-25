# NX + UV Monorepo Setup Guide

This guide explains how to set up a monorepo that combines NX (for Node / TypeScript) and UV (for Python).

## Prerequisites

Install the following:

- **Node.js**: latest LTS version from [nodejs.org](https://nodejs.org/)
- **npm**: comes with Node.js
- **UV**: install from [uv.io](https://uv.io/)
- **Python**: latest version from [python.org](https://www.python.org/)
- **Git**: latest version from [git-scm.com](https://git-scm.com/)
- **Rust**: latest version from [rust-lang.org](https://www.rust-lang.org/) (optional, for Rust-based engines)

## Initial Setup

### Step 1: Create NX Workspace

```shell
npx create-nx-workspace@latest my-monorepo --preset=apps --nxCloud=never --interactive=false
cd my-monorepo
```

If you already have an existing directory, you can initialize NX in it:

```shell
npx nx init --interactive=false --nxCloud=false
```

### Step 2: Initialize UV

Create a root `pyproject.toml` file for UV workspace management

```shell
uv init --no-readme --no-pin-python --python {python_version}
```

Edit the generated `pyproject.toml` to include the following configuration:

```toml
[project]
name = "my-monorepo"
version = "0.1.0"
description = "A monorepo combining NX and UV"
readme = "README.md"
requires-python = ">={python_version}"
dependencies = []

[tool.uv.workspace]
members = [
    # Add your python app and packages here
    # Example: "apps/api", "packages/python/domain"
]

[dependency-groups]
dev = [
    # Add development dependencies here
    # Example: "pytest", "pytest-asyncio", "pytest-cov", "ruff", "pre-commit"
]

[tool.pytest.ini_options]
pythonpath = [
    # Add paths to your python apps and packages for pytest discovery
    # Example: "apps/api", "packages/python/domain"
]
testpaths = [
    # Add paths to your test directories for pytest discovery
    # Example: "apps/api/tests", "packages/python/domain/tests"
]
```

### Step 3: Create Virtual Environment

```shell
uv venv
```

Activate it

```shell
source .venv/bin/activate  # On Unix/macOS
```

### Step 4: Update .gitignore

Add Python-specific entries to your `.gitignore` file:

```gitignore
# Python
__pycache__/
*.py[cod]
*$py.class
*.so
*.egg
*.egg-info/
dist/
build/
.venv/
.env
.pytest_cache/
.coverage
htmlcov/
.ruff_cache/
env/
.Python
coverage.xml
```

## Add Node.js Projects

Use NX generator to create your Node.js applications and libraries as needed. For example:

### React App

Create the thin shell React App, this app will only define the routes. All of the business logic and ui components are part of the ui library.

```shell
npx nx g @nx/react:app {name} --bundler=vite [--dry-run]
```

### React Library

Create the React UI library, this library will contain all of the ui components and business logic. This library should not have any dependencies on other libraries in the monorepo.

```shell
npx nx g @nx/react:lib {lib-name} --directory=packages/node/{lib-name} --bundler=vite --importPath=@{scope}/{lib-name} --style=css --unitTestRunner=vitest [--dry-run]
```

### Storybook

Optional

```shell
# First generate a project to host storybook
npx nx g @nx/react:app {sb-name} --directory=packages/node/{sb-name} --bundler=vite --style=node --unitTestRunner=none --e2eTestRunner=none --importPath=@{scope}/{sb-name} [--dry-run]
# Then generate Storybook configuration for a project
npx nx g @nx/storybook:configuration {sb-name} --uiFramework=@storybook/react-vite --interactionTests=true [--dry-run]
```

## Adding Python Projects

Python projects require manual setup since NX doesn't have built-in Python plugins.

### Step 1: Create Directory Structure

```shell
# For an application
mkdir -p apps/{my-python-app}/src/{my_python_app}
mkdir -p apps/{my-python-app}/tests

# For a library
mkdir -p packages/python/{my-python-lib}/src/{my_python_lib}
mkdir -p packages/python/{my-python-lib}/tests
```

### Step 2: Update pyproject.toml

Create a `pyproject.toml` file in your Python project directory:

**For the root `pyproject.toml`**

```toml
[project]
name = "my-monorepo"
version = "0.1.0"
description = "A monorepo combining NX and UV"
readme = "README.md"
requires-python = ">={python_version}"
dependencies = []

[tool.uv]
required-version = ">={uv_version}" # use the latest you have installed

[tool.uv.workspace]
members = [
    # Add your members here
    # Example: "apps/{my-python-app}", "packages/python/{my-python-lib}"
]

[dependency-groups]
dev = [
    "pytest",
    "pytest-asyncio",
    "pytest-cov",
    "ipykernel", # if you want to use Jupyter notebooks for development
    "pre-commit",
    "pyright", # for type checking
    "maturin" # if you are developing Rust extensions
]
[tool.ruff]
line-length = 88
target-version = "py314" # Update to match your target Python version
exclude = ["**/migrations/**"]

[tool.ruff.lint]
select = [
    "E",
    "F",
    "W",
    "I001"
]

ignore = [
    "E501", # Line length handled by Black
    "B008", # Do not use function calls in argument defaults, handled by Black
    "C901" # Complexity, can be handled by refactoring when needed, but not a hard rule
]

[tool.ruff.lint.per-file-ignores]
"__init__.py" = [
    "F401", # Allow unused imports in __init__.py for package exports
]
"tests/**/*.py" = ["F841"]

[tool.ruff.format]
quote-style = "double"
indent-style = "space"
skip-magic-trailing-comma = false
line-ending = "lf"

[tool.pytest.ini_options]
pythonpath = [
# Add paths to your python apps and packages for pytest discovery
# Example: "apps/{my-python-app}", "packages/python/{my-python-lib}"
]
testpaths = [
# Add paths to your test directories for pytest discovery
# Example: "apps/{my-python-app}/tests", "packages/python/{my-python-lib}/tests"
]
```

**For a FastAPI application (`apps/{my-python-app}/pyproject.toml`)**

```toml
[project]
name = "{my-python-app}"
version = "0.1.0"
description = "A Python application"
readme = "README.md"
requires-python = ">={python_version}"
dependencies = [
    "fastapi[standard]",
    "uvicorn[standard]",
    # Add other workspace dependencies here e.g. "{my-python-lib}" must be defined in tool.uv.sources
]

[tool.uv.sources]
"{my-python-lib}" = { workspace = true }

[project.optional-dependencies]
dev = [
    "pytest",
    "pytest-asyncio",
    "pytest-cov",
    "ruff",
    "debugpy"
]

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src/{my_python_app}"]

[tool.coverage.run]
source = ["src"]
omit = [
    "*/tests/*",
    "*/test_*",
    "*/__pycache__/*",
    "*/venv/*",
    "*/.venv/*"
]

[tool.coverage.xml]
output = "coverage.xml"

[tool.coverage.report]
exclude_lines = [
    "pragma: no cover",
    "def __str__",
    "def __repr__",
    "if self.debug",
    "if settings.DEBUG",
    "raise AssertionError",
    "raise NotImplementedError",
    "if 0:",
    "if __name__ == .__main__.:",
    "class .*\\bProtocol\\):",
    "@(abc\\.)?abstractmethod",
]

```

**For a Python library (`packages/python/{my-python-lib}/pyproject.toml`)**

```toml
[project]
name = "{my-python-lib}"
version = "0.1.0"
description = "A Python library"
requires-python = ">={python_version}"
dependencies = []

[tool.uv.sources] # if you depend on another library in the workspace, add it here and in the dependencies array
# another-lib = { workspace = true }

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src/{my_python_lib}"]

# if you have files that are not code like json or yaml you can include them in the wheel with:
# [tool.hatch.build.targets.wheel.force-include]
# "src/{my_python_lib}/data/*" = "src/{my_python_lib}/data/*"

# Add the pytest ini options, coverage and reports similar to the other pyproject.toml example above, adjusting the paths accordingly.
[tool.pytest.ini_options]
testpaths = [
    "tests"
]
```

### Step 3: Create project.json for NX

Create a `project.json` file in your Python projects directory to integrate with NX:

For example you would need to add in
`apps/{my-python-app}/project.json`
`packages/python/{my-python-lib}/project.json`

### Step 4: Create source files

Create basic source files:
**apps/{my-python-app}/src/{my_python_app}/init.py**

```python
"""My Python App"""
__version__ = "0.1.0"
```

**packages/python/{my-python-lib}/src/{my_python_lib}/init.py**

```python
"""My Python Library"""
__version__ = "0.1.0"
```

### Step 5: Install Dependencies

```shell
uv sync --all-packages
```

### Step 6: Using Workspace Dependencies

If you want one Python package to depend on another in your workspace update the pyproject.toml, add the dependency and add the source in the tool.uv.sources section.

### Step 7: Add Alembic Migrations with NX

For Python service that own database schema changes, add Alembic to the package that owns your domain models and expose it through an NX target.
This keeps database operations consistent with the rest of the monorepo

Add Alembic to the package dependencies:

```toml
[project]
dependencies = [
    "alembic",
    "sqlmodel",
    # other dependencies...
]
```

Create an Alembic configuration file in the package, for example in the domain dir:

```text
packages/python/domain/
├── alembic.ini
├── migrations/
|   ├── env.py
|   └──versions/
├── project.json
└── pyproject.toml
```

The `env.py` should look something like

```python
  from {name}_domain.config.settings import Settings
  from {name}_domain.models.entities import *

  from alembic import context
  from sqlalchemy.ext.asyncio import create_async_engine
  from sqlmodel import SQLModel
  from logging.config import fileConfig
  import asyncio

  # Getting the settings and database URL
  settings = Settings()

  config = context.config

  if config.config_file_name is not None:
    fileConfig(config.config_file_name)

  target_metadata = SQLModel.metadata

  def include_object(object, name, type_, reflected, compare_to):
    if type_ == "table":
      entity_table_names = set(target_metadata.tables.keys())
      return name in entity_table_names

    if type_ in ("index", "unique_constraint", "foreign_key_constraint", "check_constraint"):
      if hasattr(object, "table"):
          entity_table_names = set(target_metadata.tables.keys())
          return object.table.name in entity_table_names

    return True

  def do_run_migrations(connection):
    context.configure(
      connection=connection,
      target_metadata=target_metadata,
      compare_type=True,
      include_object=include_object
    )

    with context.begin_transaction():
      context.run_migrations()

  def run_migrations_offline():
    url = settings.database_url
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        include_object=include_object
    )

    with context.begin_transaction():
        context.run_migrations()

  async def run_migrations_online():
    connectable = create_async_engine(
      settings.database_url,
      pool_pre_ping=True
    )

    async with connectable.connect() as connection:
      await connection.run_sync(do_run_migrations)

    await connectable.dispose()

  if context.is_offline_mode():
    run_migrations_offline()
  else:
    asyncio.run(run_migrations_online())
```

Then add a migration target to the package `project.json`:

```json
{
  "name": "domain",
  "targets": {
    "migrate": {
      "executor": "@nx/workspace:run-commands",
      "options": {
        "command": "uv run alembic -c packages/python/domain/alembic.ini",
        "cwd": "."
      }
    }
  }
}
```

Run migration commands from the workspace root. The standalone `--` is important because it separates NX options from the arguments passed to Alembic:

```shell
npx nx run domain:migrate -- revision --autogenerate -m "{number}_a_descriptive_message" # creates a new migration file with autogenerated schema changes
npx nx run domain:migrate -- upgrade head # applies all pending migrations
npx nx run domain:migrate -- downgrade -1 # rolls back the most recent migration
```

Alembic autogeneration relies on model discovery, make sure the new entity modules are imported by the package's model registry such as `models/entities/__init__.py` file.

## Adding other languages (e.g. Rust)

The same pattern can be applied to other languages. Here is how you would set up a Rust project:

### Step 1: Create Directory Structure

```shell
mkdir -p apps/{my-rust-app}/src
```

### Step 2: Initialize Cargo

```shell
cd apps/{my-rust-app}
cargo init --name {my-rust-app}
```

### Step 3: Create project.json for NX

**apps/{my-rust-app}/project.json**

### Step 4: Update .gitignore

Add rust specific entries to your `.gitignore` file:

```gitignore
# Rust
target/
**/*.rs.bk
```

## Project Structure

A typical NX + UV monorepo might look like this:

```
my-monorepo/
├── apps/
│   ├── {name}-api/                 # Python FastAPI app (rpr generated)
│   │   ├── src/
|   |   │   └── {name}_api/
│   │   ├── tests/
│   │   ├── project.json
│   │   └── pyproject.toml
│   ├── {name}-rust-app/            # Rust app (rpr generated)
│   │   ├── src/
│   │   ├── project.json
│   │   └── Cargo.toml
|   ├── {name}-web/                 # React app (nx generated)
|   |   ├── src/
|   |   ├── project.json
|   |   ├── vite.config.ts
|   |   └── tsconfig.json
├── packages/
│   ├── node/
│   │   ├── {name}-ui/              #React library (nx generated)
│   │   │   ├── src/
│   │   │   ├── project.json
│   │   │   └── tsconfig.json
│   |   └── sb/                     # Storybook project (nx generated)
│   │       ├── .storybook/
│   │       └── project.json
|   └── python/
|       └── domain/            # Python library (manual setup)
|           ├── src/
|           │   └── {name}_domain/
|           ├── tests/
|           ├── project.json
|           └── pyproject.toml
|── .venv/                      # UV virtual environment
|── node_modules/               # Node modules
|── .gitignore                  # Git ignore file
|── pyproject.toml              # UV workspace configuration
|── package.json                # NX workspace configuration
|── README.md                   # Project readme
|── tsconfig.base.json          # NX base TypeScript configuration
```

## Best Practices

### 1. Consistent Naming Conventions

- **Node.js packages**: Use kebab-case for package names (e.g., `my-python-app`, `my-python-lib`).
- **Python packages**: Use snake_case for package names (e.g., `my_python`), but kebab-case for directory names (e.g., `my-python-app`) and for package names in pyproject.toml (e.g. `my-python-app`).
- **NX projects**: Use kebab-case consistently.

### 2. Project Organization

- **apps/**: Applications that are deployable, such as web apps, APIs, or services.
- **packages/node/**: Reusable Node.js libraries and components.
- **packages/python/**: Reusable Python libraries and modules.

### 3. NX Configuration

Update `nx.json` to configure caching and target defaults:

```json
{
  "$schema": "./node_modules/nx/schemas/nx-schema.json",
  "taskRunnerOptions": {
    "default": {
      "runner": "@nx/workspace/tasks-runners/default",
      "options": {
        "cacheableOperations": ["build", "test", "lint"],
        "parallel": 3
      }
    }
  },
  "targetDefaults": {
    "build": {
      "dependsOn": ["^build"],
      "outputs": ["{workspaceRoot}/dist"]
    },
    "test": {
      "outputs": ["{workspaceRoot}/coverage"]
    }
  }
}
```

### 4. Package Scripts

Add convenience scripts to your root `package.json` for common operations:

Example:

```json
{
  "scripts": {
    "api:serve": "nx serve api",
    "api:test": "nx test api",
    "web:serve": "nx serve web",
    "web:test": "nx test web",
    "test:python": "nx run-many --target=test --projects=api,domain",
    "test:all": "nx run-many --target=test --all",
    "build:all": "nx run-many --target=build --all",
    "lint:python": "uvx ruff check .",
    "lint:python:fix": "uvx ruff check . --fix",
    "format:python": "uvx ruff format .",
    "lint:js": "nx lint",
    "format:js": "nx format"
  }
}
```

### 5. Environment Variables

- Use `.env` files for local development
- Use `.env.example` to document required environment variables without exposing sensitive information
- Never commit `.env` files to version control
- For python use `python-dotenv` or `pydantic-settings` to load environment variables in your application
- For Node.js use `dotenv` or Vite's built-in environment variable support

### 6. Testing

- **Python**: Use `pytest` with coverage.
- Use Vitest (NX default) for testing React components and libraries.
- Run all tests: `npx nx run-many --target=test --all`
- Run specific tests: `npx nx test {project-name}`

### 7. Code Quality Tools

- Use `ruff` for Python linting and formatting.
- Use `prettier` and `eslint` for JavaScript/TypeScript linting `npm run format:fix`, `npx nx run-many --target=lint --fix --all`

### 8. Pre-commit Hooks

Setup pre-commit hooks for code quality:

```shell
uv run pre-commit install
uv run pre-commit run --all-files
```

Create a `.pre-commit-config.yaml` file in the root of your repository:

```yaml
repos:
  - repo: https://github.com/pre-commit/pre-commit-hooks
    rev: v6.0.0 # Use the latest version of ruff-pre-commit
    hooks:
      - id: check-merge-conflict
      - id: end-of-file-fixer
      - id: trailing-whitespace
        args: [--markdown-linebreak-ext=md]
      - id: fix-byte-order-marker
      - id: mixed-line-ending
        args: [--fix=lf]
        exclude: \.ipynb$ # Exclude Jupyter notebooks from line ending fixes
      - id: detect-private-key
  # Optional for repos with notebooks
  - repo: https://github.com/kynan/nbstripout
    rev: v0.8.2 # Use the latest version of nbstripout
    hooks:
      - id: nbstripout

  # Project toolchain hooks should run from the local UV/npm lockfiles
  - repo: local
    hooks:
      - id: ruff-format
        name: Ruff format
        entry: uv run ruff format
        language: system
        types: [python]
        pass_filenames: false

      - id: ruff-lint
        name: Ruff lint
        entry: uv run ruff check --fix
        language: system
        types: [python]
        pass_filenames: false

      - id: prettier
        name: Prettier format
        entry: npx prettier --write --log-level=warn
        language: system
        types_or: [javascript, jsx, ts, tsx, json, css, scss, html, markdown]
        exclude: \.ipynb$ # Exclude Jupyter notebooks from Prettier formatting
        pass_filenames: true

      - id: eslint
        name: ESLint (NX)
        entry: npx nx run-many --target=lint --all --fix --exclude=engine
        language: system
        types_or: [javascript, jsx, ts, tsx]
        pass_filenames: false
```

### 9. CI / CD Considerations

- Use NX's affected commands to only test/build changed projects
- Cache build between CI runs
- Example GitHub Actions:

```yaml
name: CI
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - uses: actions/setup-node@v4
        with:
          node-version: 20

      - name: Install UV
        run: curl -LsSf https://uv.io/install.sh | sh

      - name: Install dependencies
        run: |
          npm ci
          uv sync --all-packages

      - name: Run tests
        run: npx nx affected --target=test --base=origin/main
```

### 10. Dependency Management

**Python:**

- Use `uv add <package>` to add dependencies
- Use `uv add --dev <package>` for dev dependencies
- Use `uv sync` to install all dependencies from pyproject.toml
- Use `uv lock` to update the lock file

**Node.js:**

- Use `npm install <package>` to add dependencies
- Use `npm install -D <package>` for dev dependencies
- Use `npm ci` to install dependencies from package-lock.json

### NX Commands:

```shell
npx nx <target> <project-name> # Run a target for a specific project
npx nx run-many --target=<target> --all # Run a target for all projects
npx nx affected --target=<target> --base=origin/main # Run a target for affected projects based on changes from main
npx nx graph # Visualize project dependencies
npx nx reset # Reset the workspace state (useful for testing)
```

### UV Commands:

```shell
uv venv # Create virtual environment
uv sync --all-packages # Install dependencies for all packages

# Add a dependency to a specific package
cd apps/{my-python-app} or packages/python/{my-python-lib}
uv add <package> # Add a runtime dependency

uv run <command> # Run a command in the context of the virtual environment
uv run python script.py # Run a Python script
uv run pytest # Run tests with pytest
uv lock --upgrade # Update dependencies and lock file
```

### Combined Workflows:

```shell
npm run serve:all # Serve all applications (Node and Python) concurrently using npm scripts
npx nx run-many --target=test --all # Run all tests for both Node and Python projects
npx nx run-many --target=build --all # Build all projects (e.g., compile TypeScript, build Python wheels)
npm run format:fix # Format all code if set in package.json scripts
uvx ruff format . # Format Python code with Ruff
```

## Troubleshooting

### Issue: UV can't find a workspace package

**Problem:**

1. The package is not listed in the root `pyproject.toml` under `[tool.uv.workspace].members`
2. You have not run `uv sync --all-packages` after adding the package to the workspace configuration
3. The workspace dependency was not declared with `{ workspace = true }` in the `[tool.uv.sources]` section of the dependent package's `pyproject.toml`

### Issue: NX can't find Python projects

**Problem:**

1. The project is missing a `project.json` file with the correct configuration
2. The `project.json` file is missing a unique `name` field
3. The cache is in a bad state, try running `npx nx reset` to clear the cache and re-discover projects

### Issue: Import error in Python

**Problem:**

1. Current virtual environment is not activated, run `source .venv/bin/activate`.
2. Packages are not installed, run `uv sync --all-packages`.
3. Package structure does not match `pyproject.toml` configuration.

## Conclusion

This setup gives you the best of both worlds:

- **NX** for Node.js/TypeScript projects with excellent tooling and generators
- **UV** for Python projects with modern dependency management and workspace support
- A unified monorepo structure that allows you to manage both ecosystems in one place.
- Extensible to other languages like Rust with manual setup.

The key insight is that NX commands executor allows you to integrate any custom command, so you can run UV commands as part of your NX workflow, giving you a seamless developer experience across languages. UV workspace features manages Python dependencies across multiple packages.
