---
applyTo: "pyproject.toml,nx.json,package.json,.pre-commit-config.yaml,.gitignore,.env.example,apps/*/project.json,apps/*/pyproject.toml,packages/**/project.json,packages/**/pyproject.toml,packages/**/alembic.ini,packages/**/migrations/**"
description: "Use when checking or updating NX + UV monorepo setup, project layout, naming, workspace membership, or generated command surfaces"
---

# NX + UV Setup Guide

Use this guidance when validating or changing the monorepo setup against the RPR workspace contract.

## Workspace Contract

- Treat NX as the task surface for the workspace.
- Treat UV as the Python environment and dependency manager.
- Keep root workspace setup, generated project layout, and documented commands in sync.
- If the generated code and the guide disagree, update one so they match instead of leaving drift in place.

## Root Bootstrap

- Bootstrap NX as an empty workspace and keep Nx Cloud disabled during initialization and in `nx.json`.
- Initialize UV at the root and keep the root `pyproject.toml` as the source of truth for workspace members, Python dev dependencies, Ruff, and pytest discovery.
- Keep the root `package.json` aligned with the actual Nx targets the workspace generates.
- Keep `.pre-commit-config.yaml` valid YAML and make sure every documented hook command is runnable in the generated workspace.

## Naming And Layout

- Use kebab-case for project roots and Nx project names.
- Keep the frontend app at `apps/{name_kebab}-web`.
- Keep the FastAPI app at `apps/{name_underscore}_api`.
- Keep the reusable React library at `packages/node/{name_kebab}-ui`.
- Keep the dedicated Storybook host at `packages/node/sb`.
- Keep the Python domain package at `packages/python/domain`.
- Keep the domain import package at `packages/python/domain/src/{name_underscore}_domain` so imports read as `from {name_underscore}_domain ...`.
- Keep optional Rust engine packages at `packages/python/{name_underscore}_engine` unless the product contract changes.

## Python Naming Rule

- Use snake_case for Python filesystem roots and import packages, for example `apps/{name_underscore}_api/src/{name_underscore}_api`.
- Apply the same rule to the domain package: keep the root directory `packages/python/domain`, but keep the import package at `src/{name_underscore}_domain`.
- Keep the Python package name in `pyproject.toml` kebab-case.
- Add a `tests/` directory for generated Python apps and libraries.

## Node And Storybook Expectations

- Generate React app and library projects in a way that preserves the expected Nx command surface.
- The web app should expose at least `serve`, `build`, `lint`, `test`, and `typecheck` when those capabilities exist in the generated project.
- The UI library should expose at least `build`, `lint`, `test`, and `typecheck`.
- Use app-scoped Node package names: `packages/node/{name_kebab}-ui` publishes as `@{name_kebab}/ui`, `apps/{name_kebab}-web` publishes as `@{name_kebab}/web`, and Storybook publishes as `@{name_kebab}/sb`.
- Import the shared UI package through `@{name_kebab}/ui`, for example `import { AppThemeProvider } from "@testapp/ui"` for a `TestApp` workspace.
- Link local Node workspace packages with relative `file:` dependency specs instead of `workspace:*`, because npm must be able to install the generated workspace without unsupported protocol errors.
- Keep Storybook as a dedicated host project at `packages/node/sb`; do not silently repurpose the UI library as the Storybook project.

## Python Expectations

- Generated Python projects should use `src/` and `tests/` layout.
- Keep Python projects registered in `[tool.uv.workspace].members`.
- Use Nx `project.json` files to expose Python tasks through `nx:run-commands`.
- Ensure generated API code only imports scaffolds that actually exist in the generated domain package.

## Alembic And Nx Migrations

- For Python services that own schema changes, add Alembic to the package that owns the domain models and expose it through an Nx target.
- The standard domain layout is `packages/python/domain/alembic.ini` plus `packages/python/domain/migrations/`.
- The standard Nx target shape is a `migrate` target on the domain project that runs `uv run alembic -c packages/python/domain/alembic.ini` from the workspace root.
- Run migration commands from the workspace root with the `--` separator so Alembic receives its own arguments.

```sh
npx nx run domain:migrate -- revision --autogenerate -m "{number}_a_descriptive_message"
npx nx run domain:migrate -- upgrade head
npx nx run domain:migrate -- downgrade -1
```

- Alembic autogeneration depends on model discovery, so make sure the domain model registry imports newly added entity modules.

## Dependency And Membership Rules

- When one workspace Python package depends on another, declare it in dependencies and mirror it in `[tool.uv.sources]` with `workspace = true`.
- After creating or modifying workspace packages, keep root UV workspace membership current.
- Do not document `uv sync --all-packages` or Nx commands unless the generated workspace can actually run them.

## Review Checklist

- Root files match the generated command surface: `pyproject.toml`, `nx.json`, `package.json`, `.pre-commit-config.yaml`.
- Project roots and import package names follow the kebab-case and snake_case rules.
- Python projects have both `src/` and `tests/`.
- The domain import package remains `src/{name_underscore}_domain`.
- Node imports use app-scoped package names such as `@{name_kebab}/ui`, not stale `@repo/*` aliases.
- Storybook remains hosted in `packages/node/sb`.
- Workspace members and workspace dependency sources are complete.
- Generated instructions, checks, and scaffolds refer to the current contract rather than stale paths.
