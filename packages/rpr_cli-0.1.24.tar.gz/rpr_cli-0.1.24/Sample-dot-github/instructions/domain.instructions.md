---
applyTo: "packages/python/domain/**"
description: "Domain layer structure, entities, DTOs, repos, and workflows"
---

# Domain Layer

Use a DDD-style domain layer with explicit boundaries, SQLModel entities, Dependency Injector for composition, and Alembic for schema changes.

## Structure

- **models/entities**: SQLModel-based persistence models. Use the shared base entity pattern for ids and timestamps.
- **models/dtos**: request, response, and integration models.
- **repos**: data-access layer. Extend the shared base repository pattern.
- **services**: external clients and provider integrations. Keep transport-specific logic here, not in workflows.
- **workflows**: business use cases and multi-step orchestration. Pub/sub handlers belong in `workflows/handlers` when the project uses them.
- **config**: settings, dependency-injection container, URLs, and logging.

## Utilities

- Keep shared domain utilities in `src/{name_underscore}_domain/utils/`.
- Use `apply_partial_update()` from `utils/partial_update.py` for PATCH-style entity updates instead of handwritten field assignment.
- Use `Mapper` and the `mapper` decorator from `utils/mapper_util.py` when repository methods should support both raw ORM access and `.to_dto()` conversion.
- Use `DtoHelper` and `dto_helper` from `utils/dto_util.py` when the same DTO mapper should support both single models and lists.
- Use `EncryptedColumn` from `utils/encrypted_column.py` for encrypted persisted values.

## Reference Scaffolds

When creating or modifying shared domain primitives, use the matching file in `.github/scaffolds/domain/` as a reference implementation if it exists.

- `BaseEntity`: use `.github/scaffolds/domain/base_entity.md` as a reference for ids, timestamps, and SQLModel defaults.
- Base repository pattern: use `.github/scaffolds/domain/base-repo.md` as a reference for shared repository behavior.

These scaffold files are examples, not strict requirements. Prefer existing project-local conventions if the codebase already differs.

## Migrations

- Do not create Alembic migration files by hand.
- Prefer the workspace migration command so schema changes run through the same project wiring as the rest of the repo.
- The standard target shape is an Nx `migrate` target on the domain project that executes `uv run alembic -c packages/python/domain/alembic.ini` from the workspace root.
- Run migration commands from the workspace root and keep the standalone `--` separator between Nx arguments and Alembic arguments.

```sh
npx nx run domain:migrate -- revision --autogenerate -m "{number}_a_descriptive_message"
npx nx run domain:migrate -- upgrade head
npx nx run domain:migrate -- downgrade -1
```

- Keep the Alembic CLI under the project's configured Python environment.
- Alembic autogeneration depends on model discovery, so make sure new entity modules are imported by the domain model registry such as `models/entities/__init__.py`.

## Repository Pattern

- Repositories should extend the project's shared base repository abstraction. Do not introduce competing base repository names or patterns in the same codebase.
- The base constructor should receive the model type, engine, and default DTO mapper used by the repository.
- Use the `@mapper` decorator when a repository method should support `.to_dto()` in addition to returning the raw ORM result.
- Use `@mapper(dto_func=...)` only when a method needs a mapper different from the repository default.
- For session management, prefer `async with AsyncSession(self.engine) as session`.
- Methods suffixed with `_in_session` should work inside an existing session and should not commit on their own.

## Entity Pattern

- Entities inherit from `BaseEntity`.
- Prefer server-side defaults where the database should own the value.
- Always set `__tablename__` to the table name in the database.
- Use `__table_args__` to define table-level concerns such as indexes, constraints, and schema.
- Prefer SQLModel APIs. Use raw SQLAlchemy only when SQLModel does not expose what you need, such as `func.now()` or `func.gen_random_uuid()` for database-level defaults.

## Service Pattern

- Register new services in the DI `Container`.
- Dependencies are injected through constructors, not ad hoc method parameters.
- Use `get_logger(self.__class__.__name__)` for service-local logging.
- Keep workflows responsible for multi-step business logic and coordination across services and repositories.

## DTO Discipline

- Reuse existing DTOs when the contract is the same. Do not create near-duplicate DTOs for every small variation.
- DTOs exposed through the API should stay minimal and focused on the contract, not internal persistence details.
- Mapper functions should live in the DTO or mapper layer and follow a clear `to_dto()` naming convention.
- DTOs that are serialized to JSON should use the project's camelCase-aware base model.
- DTOs that represent external-service payloads can use `TypedDict` when a Pydantic model would add unnecessary weight.
- Internal data containers that are not serialized can use `@dataclass` when that is the simplest fit.

## Log Injection Prevention

- Add a shared `sanitize_for_log()` helper if the project does not already have one.
- Sanitize untrusted values before logging them, especially identifiers and externally supplied strings.

## Testing

- Service and repository tests should verify DTO mapping behavior, including `.to_dto()` paths when `mapper_util` is in use.
- Use `@pytest.fixture` for reusable test setup.
