## Domain Settings Template

Target path: `packages/python/{name_underscore}_domain/src/{name_underscore}_domain/config/settings.py`

Use this template when scaffolding the domain configuration layer. It provides a Pydantic `BaseSettings` class that loads from `.env` and defines all core infrastructure settings needed by the DI container.

The first Python block is the generated file used by `rpr generate domain` and `rpr add template domain_settings`.

```python
from __future__ import annotations

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    db_host: str = Field(default="localhost", description="Database host")
    db_port: int = Field(default=5432, description="Database port")
    db_name: str = Field(default="postgres", description="Database name")
    db_user: str = Field(default="postgres", description="Database user")
    db_password: str = Field(default="", description="Database password")
    db_sslmode: str = Field(default="prefer", description="Database SSL mode")
    db_echo: bool = Field(default=False, description="Enable SQL query logging")
    db_encrypt_key: bytes | None = Field(default=None, description="Fernet encryption key")

    http_timeout: float = Field(default=30.0, description="HTTP client timeout in seconds")
    httpx_max_connections: int = Field(default=100, description="Maximum HTTP connections")
    http_max_keepalive: int = Field(default=20, description="Maximum keepalive HTTP connections")

    @property
    def database_url(self) -> str:
        return (
            f"postgresql+asyncpg://{self.db_user}:{self.db_password}"
            f"@{self.db_host}:{self.db_port}/{self.db_name}"
            f"?sslmode={self.db_sslmode}"
        )
```

## What This Template Provides

- Reads all settings from `.env` with `case_sensitive=False` and `extra="ignore"` so unknown keys never raise errors.
- Defines the full set of database fields used to build `database_url` in the `@property`.
- Defines `http_timeout`, `httpx_max_connections`, and `http_max_keepalive` so the container's `http_client` provider can bind them without extra lookups.
- `db_encrypt_key` is `bytes | None` to pair with the `encrypted_column` utility when needed.

## Usage Notes

- Add corresponding keys to `.env.example` for each field (see `special_files.md` ENV section).
- Extend `Settings` in the domain package to add app-specific fields; do not modify this base set.
- `database_url` is a computed property — it is not read from `.env` directly.
