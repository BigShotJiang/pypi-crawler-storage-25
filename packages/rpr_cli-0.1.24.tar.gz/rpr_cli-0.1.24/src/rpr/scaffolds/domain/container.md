## Domain Container Template

Target path: `packages/python/{name_underscore}_domain/src/{name_underscore}_domain/config/container.py`

Use this template when scaffolding the domain DI container. It wires the core infrastructure providers — database engine and HTTP client — as singletons driven by `Settings`.

The first Python block is the generated file used by `rpr generate domain` and `rpr add template domain_container`.

```python
from __future__ import annotations

import httpx
from dependency_injector import containers, providers
from sqlalchemy.ext.asyncio import create_async_engine

from your_app_domain.config.settings import Settings


class Container(containers.DeclarativeContainer):
    config = providers.Singleton(Settings)

    db_engine = providers.Singleton(
        lambda settings: create_async_engine(
            settings.database_url,
            echo=settings.db_echo,
            pool_pre_ping=True,
            pool_recycle=3600,
        ),
        settings=config,
    )

    http_client = providers.Singleton(
        httpx.AsyncClient,
        timeout=config.provided.http_timeout,
        limits=providers.Factory(
            httpx.Limits,
            max_connections=config.provided.httpx_max_connections,
            max_keepalive_connections=config.provided.http_max_keepalive,
        ),
    )

    # To add lifecycle methods (startup/shutdown hooks), override __new__:
    #
    #   def __new__(cls):
    #       instance = super().__new__(cls)
    #       return add_lifecycle_methods(instance)
    #
    # Implement add_lifecycle_methods() in this module to attach
    # startup and shutdown handlers to the container instance.
```

## What This Template Provides

- `config`: a singleton `Settings` instance that reads from `.env`.
- `db_engine`: a singleton async SQLAlchemy engine built from `settings.database_url`, with connection-pool tuning defaults (`pool_pre_ping`, `pool_recycle`).
- `http_client`: a singleton `httpx.AsyncClient` with timeout and connection limits sourced from `Settings`.

## Lifecycle Extension Pattern

If the project needs startup or shutdown hooks (e.g., acquiring a connection pool, registering signal handlers), override `__new__` on `Container`:

```python
def __new__(cls):
    instance = super().__new__(cls)
    return add_lifecycle_methods(instance)
```

Define `add_lifecycle_methods(instance)` in the same module to attach `on_startup` and `on_shutdown` handlers without modifying the provider declarations.

## Usage Notes

- Register new services and repositories as providers directly on `Container`; do not subclass it.
- Inject the container into FastAPI (or the framework of your choice) via its `wire()` method in the app factory.
- Keep transport-specific clients (e.g., third-party API clients) as additional `providers.Singleton` entries, bound to `config` for their credentials.
