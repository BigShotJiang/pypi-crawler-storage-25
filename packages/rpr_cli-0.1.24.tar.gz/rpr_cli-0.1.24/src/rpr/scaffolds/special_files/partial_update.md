## Partial Update Utility Template

Target path: `/packages/python/{name_underscore}_domain/src/{name_underscore}_domain/utils/partial_update.py`

Use this helper when a PATCH-style DTO should update only the fields that were explicitly provided by the caller.

The first Python block is the generated file used by `rpr add template partial_update`.

```python
from __future__ import annotations
from typing import TypeVar
from my_app_domain.models.entities import BaseEntity
from pydantic import BaseModel

EntityT = TypeVar("EntityT", bound="BaseEntity")
EXCLUDED_FIELDS = frozenset({'id', 'created_at', 'updated_at', 'created_by', 'updated_by'})

def apply_partial_update(entity: EntityT, partial_dto: BaseModel, *, field_mapping: dict[str, str] | None = None) -> EntityT:
    """
    Apply explicitly set fields from a partial update DTO onto the current Entity.
    Iterates over model_fields_set (only fields explicitly included in the request payload),
    excluding id, created_at, and updated_at, and sets the corresponding attribute on current_entity.
    Fields absent from the payload are left unchanged.

    When field names differ between the DTO and the Entity, provide a field_mapping dict mapping DTO field name => entity attribute name.
    entity: The ORM entity to update.
    partial_dto: The Pydantic model containing the fields to update.
    field_mapping: Optional dictionary mapping DTO field names to entity attribute names.

    Returns:
      The same entity instance, mutated in place.
    """
    field_mapping = field_mapping or {}

    for field_name in partial_dto.model_fields_set:
        if field_name in EXCLUDED_FIELDS:
            continue

        value = getattr(partial_dto, field_name)
        target_attr = field_mapping.get(field_name, field_name)
        setattr(entity, target_attr, value)
    return entity
```

### Usage:

```python
# PATCH endpoint handler
async def update_user(id: str, body: UpdateUserDto) -> UserDto:
    user = await repo.get_user_by_id(id)
    user = apply_partial_update(user, body)

#with field names mismatch
apply_partial_update(entity, dto, field_mapping={"displayName": "name"})
```

## Notes

- The helper mutates the existing entity in place and returns that same instance for convenience.
- `model_fields_set` ensures omitted fields are left untouched.
- Use `field_mapping` when DTO field names and entity attribute names differ.
