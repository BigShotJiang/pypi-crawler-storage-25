## Encrypted Column Template

Target path: `/packages/python/{name_underscore}_domain/src/{name_underscore}_domain/utils/encrypted_column.py`

Use this template when a SQLModel field must be stored encrypted at rest without changing the rest of the model or repository code.

Dependency: `uv add cryptography`

The first Python block is the generated file used by `rpr add template encrypted_column`.

```python
import json
from typing import Any

from cryptography.fernet import Fernet
from sqlalchemy import Column
from sqlalchemy.types import TypeDecorator
from sqlmodel import Field, SQLModel
from sqlmodel.sql.sqltypes import AutoString

def _get_fernet_key() -> bytes:
    """
    Return the Fernet encryption key.

    Replace this with your project's settings / secret manager lookup.
    return b"your-fernet-key-here"
    """
    # Important this is sample or temp code, the key should not come from env but from a secure secret manager, like GCP, Doppler, AWS Secrets Manager, etc.
    import os
    key = os.environ.get("FERNET_KEY")
    if key is None:
        raise RuntimeError("FERNET_KEY environment variable is not set")
    return key.encode()

class EncryptedColumn(TypeDecorator):
    """
    SQLAlchemy column type that transparently encrypts and decrypts values using Fernet symmetric encryption.

    Stores the encrypted value as a string in the database.
    Supports any JSON serializable Python value (str, dict, list, int, etc.).

    Usage in a SQLModel:

    class MyModel(SQLModel, table=True):
        api_token: str | None = Field(
          default=None,
          sa_column=Column(EncryptedColumn())
        )

    """
    impl = AutoString(length=1000)
    cache_ok = True

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._fernet = Fernet(_get_fernet_key())

    def process_bind_param(self, value: Any, dialect) -> str | None:
        """
        Encrypt the value before storing it in the database.
        """
        if value is None:
            return None
        try:
            json_value = json.dumps(value)
            encrypted = self._fernet.encrypt(json_value.encode("utf-8"))
            return encrypted.decode("utf-8")
        except Exception as e:
            raise ValueError(f"Error encrypting value: {e}")

    def process_result_value(self, value: str | None, dialect) -> Any:
        """
        Decrypt the value when loading it from the database.
        """
        if value is None:
            return None
        try:
            decrypted_value = self._fernet.decrypt(value.encode("utf-8"))
            return json.loads(decrypted_value.decode("utf-8"))
        except Exception as e:
            # log error
            # Return None if decryption fails, we don't want the app to crash unless the consumer needs it to crash
            return None
```

## Security Notes

- Replace `_get_fernet_key()` with the project's real secret-loading path before using this in production.
- Prefer a secrets manager over environment variables for long-lived deployments.
- Decide whether decryption failures should return `None`, be logged, or raise loudly based on the sensitivity of the consuming workflow.

## Key Generation

```python
from cryptography.fernet import Fernet
key = Fernet.generate_key().decode()
# Store in secrets manager
```
