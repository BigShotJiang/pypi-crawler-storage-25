from __future__ import annotations

import json
import tomllib
from pathlib import Path

from rpr.checks.base import CheckResult
from rpr.dependencies import (
    DOMAIN_RUNTIME_DEPENDENCIES,
    MATURIN_SPEC,
    api_runtime_dependencies,
    dependency_names,
    node_project_name,
    npm_package_name,
    python_project_name,
)


def check_packages(project_dir: Path, variables: dict[str, str]) -> list[CheckResult]:
    results: list[CheckResult] = []
    name = variables.get("name", "<name>")
    name_underscore = variables.get("name_underscore", name.replace("-", "_")).lower()
    domain_name = python_project_name(name, "domain")
    api_name = python_project_name(name, "api")
    ui_name = node_project_name(name, "ui")
    web_name = node_project_name(name, "web")

    pyproject = project_dir / "pyproject.toml"
    workspace_members: set[str] = set()
    if pyproject.exists():
        try:
            data = tomllib.loads(pyproject.read_text())
            members = (
                data.get("tool", {})
                .get("uv", {})
                .get("workspace", {})
                .get("members", [])
            )
            if isinstance(members, list):
                workspace_members = set(members)
        except OSError, tomllib.TOMLDecodeError:
            workspace_members = set()

    # Domain package
    domain_dir = project_dir / "packages" / "python" / domain_name
    results.append(
        CheckResult(
            group="Generated Packages & Apps",
            area="Domain package",
            status=domain_dir.exists(),
            path=str(domain_dir)
            if domain_dir.exists()
            else f"packages/python/{domain_name}/ missing",
            suggestion=f"rpr generate domain {name}",
        )
    )
    if domain_dir.exists():
        results.extend(
            _check_python_layout(
                area="Domain layout",
                project_dir=domain_dir,
                src_package=domain_dir / "src" / domain_name,
                suggestion=f"rpr generate domain {name}",
            )
        )
        results.append(
            _check_project_targets(
                area="Domain targets",
                project_json=domain_dir / "project.json",
                required_targets={"build", "test", "lint"},
                suggestion=f"rpr generate domain {name}",
            )
        )
        results.append(
            _check_project_name(
                area="Domain project name",
                project_json=domain_dir / "project.json",
                expected_name=domain_name,
                suggestion=f"rpr generate domain {name}",
            )
        )
        results.append(
            _check_python_dependency_contract(
                area="Domain install metadata",
                pyproject=domain_dir / "pyproject.toml",
                required_dependencies=dependency_names(DOMAIN_RUNTIME_DEPENDENCIES),
                suggestion=f"rpr generate domain {name}",
            )
        )
        results.append(
            _check_domain_migration_scaffold(
                domain_dir=domain_dir,
                name=name,
                name_underscore=name_underscore,
            )
        )
        results.append(
            CheckResult(
                group="Generated Packages & Apps",
                area="Domain workspace member",
                status=f"packages/python/{domain_name}" in workspace_members,
                path=f"packages/python/{domain_name}"
                if f"packages/python/{domain_name}" in workspace_members
                else f"packages/python/{domain_name} missing from [tool.uv.workspace].members",
                suggestion=f"rpr generate domain {name}",
            )
        )

    # API app
    api_dir = project_dir / "apps" / api_name
    results.append(
        CheckResult(
            group="Generated Packages & Apps",
            area="API app",
            status=api_dir.exists(),
            path=str(api_dir) if api_dir.exists() else f"apps/{api_name}/ missing",
            suggestion=f"rpr generate api {name}",
        )
    )
    if api_dir.exists():
        results.extend(
            _check_python_layout(
                area="API layout",
                project_dir=api_dir,
                src_package=api_dir / "src" / api_name,
                suggestion=f"rpr generate api {name}",
            )
        )
        results.append(
            _check_project_targets(
                area="API targets",
                project_json=api_dir / "project.json",
                required_targets={"serve", "build", "test", "lint"},
                suggestion=f"rpr generate api {name}",
            )
        )
        results.append(
            _check_python_dependency_contract(
                area="API install metadata",
                pyproject=api_dir / "pyproject.toml",
                required_dependencies=set(api_runtime_dependencies(name)),
                suggestion=f"rpr generate api {name}",
                required_sources={domain_name: {"workspace": True}},
            )
        )
        results.append(
            CheckResult(
                group="Generated Packages & Apps",
                area="API workspace member",
                status=f"apps/{api_name}" in workspace_members,
                path=f"apps/{api_name}"
                if f"apps/{api_name}" in workspace_members
                else f"apps/{api_name} missing from [tool.uv.workspace].members",
                suggestion=f"rpr generate api {name}",
            )
        )

    # UI library
    ui_dir = project_dir / "packages" / "node" / ui_name
    results.append(
        CheckResult(
            group="Generated Packages & Apps",
            area="UI library",
            status=ui_dir.exists(),
            path=str(ui_dir)
            if ui_dir.exists()
            else f"packages/node/{name}-ui/ missing",
            suggestion=f"rpr generate ui {name}",
        )
    )
    if ui_dir.exists():
        results.append(
            _check_project_targets(
                area="UI targets",
                project_json=ui_dir / "project.json",
                required_targets={"build", "lint", "test", "typecheck"},
                suggestion=f"rpr generate ui {name}",
            )
        )
        results.append(
            _check_node_dependency_contract(
                area="UI install metadata",
                package_json=ui_dir / "package.json",
                expected_name=f"@{npm_package_name(name)}/ui",
                suggestion=f"rpr generate ui {name}",
            )
        )

    # Web app
    web_dir = project_dir / "apps" / web_name
    results.append(
        CheckResult(
            group="Generated Packages & Apps",
            area="Web app",
            status=web_dir.exists(),
            path=str(web_dir) if web_dir.exists() else f"apps/{web_name}/ missing",
            suggestion=f"rpr generate ui {name} --no-library",
        )
    )
    if web_dir.exists():
        results.append(
            _check_project_targets(
                area="Web targets",
                project_json=web_dir / "project.json",
                required_targets={"serve", "build", "lint", "test", "typecheck"},
                suggestion=f"rpr generate ui {name} --no-library",
            )
        )
        results.append(
            _check_node_dependency_contract(
                area="Web package metadata",
                package_json=web_dir / "package.json",
                expected_name=f"@{npm_package_name(name)}/web",
                suggestion=f"rpr generate ui {name} --no-library",
            )
        )

    # Storybook
    sb_dir = project_dir / "packages" / "node" / "sb"
    results.append(
        CheckResult(
            group="Generated Packages & Apps",
            area="Storybook",
            status=sb_dir.exists(),
            path=str(sb_dir) if sb_dir.exists() else "packages/node/sb/ missing",
            suggestion="rpr generate storybook",
        )
    )
    if sb_dir.exists():
        results.append(
            _check_project_targets(
                area="Storybook targets",
                project_json=sb_dir / "project.json",
                required_targets={
                    "serve",
                    "build",
                    "lint",
                    "test",
                    "typecheck",
                    "storybook",
                    "build-storybook",
                },
                suggestion="rpr generate storybook",
            )
        )
        results.append(
            _check_node_dependency_contract(
                area="Storybook host package metadata",
                package_json=sb_dir / "package.json",
                expected_name=f"@{npm_package_name(name)}/sb",
                suggestion="rpr generate storybook",
            )
        )

    # Engine
    engine_dir = next(project_dir.glob("packages/python/*_engine"), None)
    results.append(
        CheckResult(
            group="Generated Packages & Apps",
            area="Engine (optional)",
            status=True,
            path=str(engine_dir) if engine_dir else "not scaffolded",
            suggestion=f"rpr generate engine {name}",
        )
    )
    if engine_dir is not None:
        results.append(
            _check_engine_install_metadata(
                engine_dir=engine_dir,
                suggestion=f"rpr generate engine {name}",
            )
        )

    return results


def _load_json(path: Path) -> dict[str, object] | None:
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text())
    except OSError, json.JSONDecodeError:
        return None
    return data if isinstance(data, dict) else None


def _load_toml(path: Path) -> dict[str, object] | None:
    if not path.exists():
        return None
    try:
        data = tomllib.loads(path.read_text())
    except OSError, tomllib.TOMLDecodeError:
        return None
    return data if isinstance(data, dict) else None


def _check_python_layout(
    *, area: str, project_dir: Path, src_package: Path, suggestion: str
) -> list[CheckResult]:
    tests_dir = project_dir / "tests"
    return [
        CheckResult(
            group="Generated Packages & Apps",
            area=area,
            status=src_package.exists() and tests_dir.exists(),
            path=str(project_dir)
            if src_package.exists() and tests_dir.exists()
            else f"{project_dir} missing src/ package or tests/",
            suggestion=suggestion,
        )
    ]


def _check_project_targets(
    *, area: str, project_json: Path, required_targets: set[str], suggestion: str
) -> CheckResult:
    data = _load_json(project_json)
    if data is None:
        return CheckResult(
            group="Generated Packages & Apps",
            area=area,
            status=False,
            path=f"{project_json} missing or invalid",
            suggestion=suggestion,
        )

    targets = data.get("targets", {})
    if not isinstance(targets, dict):
        targets = {}
    missing = sorted(required_targets.difference(targets.keys()))

    return CheckResult(
        group="Generated Packages & Apps",
        area=area,
        status=not missing,
        path=str(project_json)
        if not missing
        else f"{project_json} missing targets: {', '.join(missing)}",
        suggestion=suggestion,
    )


def _check_project_name(
    *, area: str, project_json: Path, expected_name: str, suggestion: str
) -> CheckResult:
    data = _load_json(project_json)
    if data is None:
        return CheckResult(
            group="Generated Packages & Apps",
            area=area,
            status=False,
            path=f"{project_json} missing or invalid",
            suggestion=suggestion,
        )

    project_name = data.get("name")
    status = project_name == expected_name
    return CheckResult(
        group="Generated Packages & Apps",
        area=area,
        status=status,
        path=str(project_json)
        if status
        else f"{project_json} expected name '{expected_name}'",
        suggestion=suggestion,
    )


def _check_python_dependency_contract(
    *,
    area: str,
    pyproject: Path,
    required_dependencies: set[str],
    suggestion: str,
    required_sources: dict[str, object] | None = None,
) -> CheckResult:
    data = _load_toml(pyproject)
    if data is None:
        return CheckResult(
            group="Generated Packages & Apps",
            area=area,
            status=False,
            path=f"{pyproject} missing or invalid",
            suggestion=suggestion,
        )

    project = (
        data.get("project", {}) if isinstance(data.get("project", {}), dict) else {}
    )
    dependencies = project.get("dependencies", []) if isinstance(project, dict) else []
    dependency_set = set(dependencies) if isinstance(dependencies, list) else set()
    missing_dependencies = sorted(required_dependencies.difference(dependency_set))

    sources = (
        data.get("tool", {}).get("uv", {}).get("sources", {})
        if isinstance(data.get("tool", {}), dict)
        else {}
    )
    source_errors: list[str] = []
    if required_sources and isinstance(sources, dict):
        for key, expected in required_sources.items():
            if sources.get(key) != expected:
                source_errors.append(key)
    elif required_sources:
        source_errors.extend(sorted(required_sources))

    status = not missing_dependencies and not source_errors
    details: list[str] = []
    if missing_dependencies:
        details.append(f"missing dependencies: {', '.join(missing_dependencies)}")
    if source_errors:
        details.append(f"missing uv sources: {', '.join(source_errors)}")

    return CheckResult(
        group="Generated Packages & Apps",
        area=area,
        status=status,
        path=str(pyproject) if status else f"{pyproject} {'; '.join(details)}",
        suggestion=suggestion,
    )


def _check_node_dependency_contract(
    *,
    area: str,
    package_json: Path,
    suggestion: str,
    expected_name: str | None = None,
    required_dependencies: set[str] | None = None,
    required_dev_dependencies: set[str] | None = None,
) -> CheckResult:
    data = _load_json(package_json)
    if data is None:
        return CheckResult(
            group="Generated Packages & Apps",
            area=area,
            status=False,
            path=f"{package_json} missing or invalid",
            suggestion=suggestion,
        )

    if expected_name is not None and data.get("name") != expected_name:
        return CheckResult(
            group="Generated Packages & Apps",
            area=area,
            status=False,
            path=f"{package_json} expected name '{expected_name}'",
            suggestion=suggestion,
        )

    dependencies = data.get("dependencies", {})
    dev_dependencies = data.get("devDependencies", {})
    dependency_keys = set(dependencies) if isinstance(dependencies, dict) else set()
    dev_dependency_keys = (
        set(dev_dependencies) if isinstance(dev_dependencies, dict) else set()
    )

    missing_dependencies = sorted(
        (required_dependencies or set()).difference(dependency_keys)
    )
    missing_dev_dependencies = sorted(
        (required_dev_dependencies or set()).difference(dev_dependency_keys)
    )

    status = not missing_dependencies and not missing_dev_dependencies
    details: list[str] = []
    if missing_dependencies:
        details.append(f"missing dependencies: {', '.join(missing_dependencies)}")
    if missing_dev_dependencies:
        details.append(
            f"missing devDependencies: {', '.join(missing_dev_dependencies)}"
        )

    return CheckResult(
        group="Generated Packages & Apps",
        area=area,
        status=status,
        path=str(package_json) if status else f"{package_json} {'; '.join(details)}",
        suggestion=suggestion,
    )


def _check_domain_migration_scaffold(
    *, domain_dir: Path, name: str, name_underscore: str
) -> CheckResult:
    project_json = domain_dir / "project.json"
    project = _load_json(project_json) or {}
    targets = (
        project.get("targets", {})
        if isinstance(project.get("targets", {}), dict)
        else {}
    )
    migrate_target = targets.get("migrate") if isinstance(targets, dict) else None

    alembic_ini = domain_dir / "alembic.ini"
    env_py = domain_dir / "migrations" / "env.py"
    versions_dir = domain_dir / "migrations" / "versions"
    scaffold_requested = any(
        [
            alembic_ini.exists(),
            env_py.exists(),
            versions_dir.exists(),
            isinstance(migrate_target, dict),
        ]
    )
    if not scaffold_requested:
        return CheckResult(
            group="Generated Packages & Apps",
            area="Domain migration scaffold (optional)",
            status=True,
            path="not scaffolded",
            suggestion=f"rpr generate domain {name} --migrations",
        )

    options = (
        migrate_target.get("options", {}) if isinstance(migrate_target, dict) else {}
    )
    command_ok = isinstance(options, dict) and options.get("command") == (
        f"uv run alembic -c packages/python/{name_underscore}_domain/alembic.ini"
    )
    cwd_ok = isinstance(options, dict) and options.get("cwd") == "."
    env_ok = False
    if env_py.exists():
        env_content = env_py.read_text()
        env_ok = (
            f"from {name_underscore}_domain.config.settings import Settings"
            in env_content
            and f"import {name_underscore}_domain.models.entities" in env_content
        )

    missing: list[str] = []
    if not alembic_ini.exists():
        missing.append("alembic.ini")
    if not env_py.exists():
        missing.append("migrations/env.py")
    if not versions_dir.is_dir():
        missing.append("migrations/versions/")
    if not isinstance(migrate_target, dict):
        missing.append("migrate target")
    elif not command_ok or not cwd_ok:
        missing.append("migrate target command")
    if env_py.exists() and not env_ok:
        missing.append("env.py imports")

    return CheckResult(
        group="Generated Packages & Apps",
        area="Domain migration scaffold (optional)",
        status=not missing,
        path=str(domain_dir)
        if not missing
        else f"{domain_dir} incomplete migration scaffold: {', '.join(missing)}",
        suggestion=f"rpr generate domain {name} --migrations",
    )


def _check_engine_install_metadata(*, engine_dir: Path, suggestion: str) -> CheckResult:
    pyproject = engine_dir / "pyproject.toml"
    data = _load_toml(pyproject)
    if data is None:
        return CheckResult(
            group="Generated Packages & Apps",
            area="Engine install metadata",
            status=False,
            path=f"{pyproject} missing or invalid",
            suggestion=suggestion,
        )

    build_system = data.get("build-system", {})
    requires = (
        build_system.get("requires", []) if isinstance(build_system, dict) else []
    )
    requires_set = set(requires) if isinstance(requires, list) else set()
    status = MATURIN_SPEC in requires_set
    return CheckResult(
        group="Generated Packages & Apps",
        area="Engine install metadata",
        status=status,
        path=str(pyproject)
        if status
        else f"{pyproject} missing maturin build requirement",
        suggestion=suggestion,
    )
