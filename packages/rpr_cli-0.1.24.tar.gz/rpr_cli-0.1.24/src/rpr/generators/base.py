from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

import yaml


@dataclass
class Rule:
    id: str
    content: str
    description: str = ""
    apply_to: str = "**"
    rule_type: str = "instruction"
    language: str = "all"
    source_path: Path | None = None


def load_rules(source_dir: Path) -> list[Rule]:
    """Load all markdown rules from a source directory, parsing YAML frontmatter."""
    rules: list[Rule] = []

    for md_file in sorted(source_dir.rglob("*.md")):
        if ".venv" in md_file.parts:
            continue

        text = md_file.read_text()
        rule_id = md_file.stem.replace(".instructions", "")
        frontmatter: dict = {}
        body = text

        fm_match = re.match(r"^---\s*\n(.*?)\n---\s*\n(.*)$", text, re.DOTALL)
        if fm_match:
            try:
                frontmatter = yaml.safe_load(fm_match.group(1)) or {}
            except yaml.YAMLError:
                frontmatter = {}
            body = fm_match.group(2)

        first_heading = ""
        heading_match = re.search(r"^#+\s+(.+)$", body, re.MULTILINE)
        if heading_match:
            first_heading = heading_match.group(1).strip()

        rules.append(
            Rule(
                id=rule_id,
                content=body.strip(),
                description=frontmatter.get("description", first_heading),
                apply_to=frontmatter.get("applyTo", "**"),
                rule_type=frontmatter.get("type", "instruction"),
                language=frontmatter.get("language", "all"),
                source_path=md_file,
            )
        )

    return rules


def interpolate(text: str, variables: dict[str, str]) -> str:
    """Replace {variable} placeholders with values from the variables dict."""
    if not variables:
        return text
    for key, value in variables.items():
        text = text.replace(f"{{{key}}}", value)
    return text


@dataclass
class SyncConfig:
    source: str = ""
    targets: list[str] = field(
        default_factory=lambda: ["cursor", "github", "copilot", "claude"]
    )
    include: list[str] = field(default_factory=list)
    exclude: list[str] = field(default_factory=list)
    variables: dict[str, str] = field(default_factory=dict)

    @classmethod
    def load(cls, path: Path) -> SyncConfig:
        if not path.exists():
            return cls()
        try:
            data = yaml.safe_load(path.read_text()) or {}
        except yaml.YAMLError:
            data = {}
        return cls(
            source=data.get("source", ""),
            targets=data.get("targets", ["cursor", "github", "copilot", "claude"]),
            include=data.get("include", []),
            exclude=data.get("exclude", []),
            variables=data.get("variables", {}),
        )

    def save(self, path: Path) -> None:
        data = {
            "source": self.source,
            "targets": self.targets,
            "include": self.include,
            "exclude": self.exclude,
            "variables": self.variables,
        }
        path.write_text(yaml.dump(data, default_flow_style=False, sort_keys=False))

    def filter_rules(self, rules: list[Rule]) -> list[Rule]:
        if self.include:
            rules = [r for r in rules if r.id in self.include]
        if self.exclude:
            rules = [r for r in rules if r.id not in self.exclude]
        return rules
