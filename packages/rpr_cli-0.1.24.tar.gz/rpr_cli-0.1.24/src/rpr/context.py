from __future__ import annotations

import os
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

from rpr.ui.console import console
from rpr.ui.markdown import DEFAULT_MARKDOWN_PREVIEW_LINES, render_markdown
from rpr.ui.renderers import render_command_start, render_file_preview


def _should_preview_markdown(path: Path, preview_markdown: bool) -> bool:
    return preview_markdown and path.suffix.lower() in {".md", ".mdc"}


def _render_markdown_file_preview(
    path: Path,
    content: str,
    *,
    is_dry_run: bool,
    is_update: bool,
    title: str | None,
    max_lines: int | None,
) -> None:
    if is_dry_run:
        action = "update" if is_update else "create"
        console.print(
            f"\n[dry_run][DRY RUN][/] Would {action}: [path]{path}[/]", soft_wrap=True
        )

    render_markdown(
        content,
        mode="preview",
        title=title or path.name,
        max_lines=max_lines,
    )


def _format_dependency_groups(
    *, runtime: list[str] | None = None, dev: list[str] | None = None
) -> str:
    groups: list[str] = []
    if runtime:
        groups.append(f"runtime=[{', '.join(runtime)}]")
    if dev:
        groups.append(f"dev=[{', '.join(dev)}]")
    return " ".join(groups)


def _uv_activation_env(
    project_dir: Path, env: dict[str, str] | None = None
) -> dict[str, str]:
    effective_env = dict(env or {})
    venv_dir = project_dir / ".venv"
    venv_bin = venv_dir / "bin"
    if venv_bin.exists():
        current_path = effective_env.get("PATH", os.environ.get("PATH", ""))
        effective_env["VIRTUAL_ENV"] = str(venv_dir)
        effective_env["PATH"] = f"{venv_bin}{os.pathsep}{current_path}"
    return effective_env


@dataclass
class RunContext:
    dry_run: bool = False
    project_dir: Path = field(default_factory=Path.cwd)

    def preview_dependencies(
        self,
        *,
        manager: str,
        target: Path | str,
        runtime: list[str] | None = None,
        dev: list[str] | None = None,
    ) -> None:
        scope = "Would install" if self.dry_run else "Installing"
        groups = _format_dependency_groups(runtime=runtime, dev=dev)
        message = f"{scope} {manager} dependencies for {target}"
        if groups:
            message = f"{message}: {groups}"
        console.print(
            f"[DRY RUN] {message}" if self.dry_run else message,
            soft_wrap=True,
            markup=False,
        )

    def run_command(
        self,
        cmd: list[str],
        *,
        cwd: Path | str | None = None,
        env: dict[str, str] | None = None,
        capture: bool = False,
        supports_dry_run: bool = False,
    ) -> subprocess.CompletedProcess[str]:
        resolved_cwd = str(cwd) if cwd else str(self.project_dir)
        env_prefix = " ".join(f"{key}={value}" for key, value in (env or {}).items())

        display_cmd = " ".join(cmd)
        if env_prefix:
            display_cmd = f"{env_prefix} {display_cmd}"

        if self.dry_run and not supports_dry_run:
            render_command_start(display_cmd, resolved_cwd, is_dry_run=True)
            return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")

        effective_cmd = (
            cmd + ["--dry-run"] if (self.dry_run and supports_dry_run) else cmd
        )
        if self.dry_run and supports_dry_run:
            display_cmd = " ".join(effective_cmd)
            if env_prefix:
                display_cmd = f"{env_prefix} {display_cmd}"

        render_command_start(display_cmd, resolved_cwd, is_dry_run=False)

        effective_env = None
        if env:
            effective_env = os.environ.copy()
            effective_env.update(env)
        result = subprocess.run(
            effective_cmd,
            cwd=resolved_cwd,
            env=effective_env,
            capture_output=capture,
            text=True,
            check=True,
        )
        return result

    def run_uv_command(
        self,
        cmd: list[str],
        *,
        cwd: Path | str | None = None,
        env: dict[str, str] | None = None,
        capture: bool = False,
        supports_dry_run: bool = False,
    ) -> subprocess.CompletedProcess[str]:
        return self.run_command(
            cmd,
            cwd=cwd,
            env=_uv_activation_env(self.project_dir, env),
            capture=capture,
            supports_dry_run=supports_dry_run,
        )

    def write_file(
        self,
        path: Path,
        content: str,
        *,
        preview_markdown: bool = False,
        markdown_title: str | None = None,
        markdown_max_lines: int | None = DEFAULT_MARKDOWN_PREVIEW_LINES,
    ) -> None:
        if self.dry_run:
            if _should_preview_markdown(path, preview_markdown):
                _render_markdown_file_preview(
                    path,
                    content,
                    is_dry_run=True,
                    is_update=False,
                    title=markdown_title,
                    max_lines=markdown_max_lines,
                )
                return
            render_file_preview(path, content, is_dry_run=True, is_update=False)
            return

        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content)
        render_file_preview(path, content, is_dry_run=False, is_update=False)
        if _should_preview_markdown(path, preview_markdown):
            _render_markdown_file_preview(
                path,
                content,
                is_dry_run=False,
                is_update=False,
                title=markdown_title,
                max_lines=markdown_max_lines,
            )

    def ensure_dir(self, path: Path) -> None:
        if self.dry_run:
            from rpr.ui.console import console

            console.print(
                f"[dry_run][DRY RUN][/] Would create directory: [path]{path}[/]",
                soft_wrap=True,
            )
            return

        path.mkdir(parents=True, exist_ok=True)
        from rpr.ui.console import console

        console.print(f"[success]Created:[/] [path]{path}/[/]")

    def update_file(
        self,
        path: Path,
        content: str,
        *,
        preview_markdown: bool = False,
        markdown_title: str | None = None,
        markdown_max_lines: int | None = DEFAULT_MARKDOWN_PREVIEW_LINES,
    ) -> None:
        if self.dry_run:
            if _should_preview_markdown(path, preview_markdown):
                _render_markdown_file_preview(
                    path,
                    content,
                    is_dry_run=True,
                    is_update=True,
                    title=markdown_title,
                    max_lines=markdown_max_lines,
                )
                return
            render_file_preview(path, content, is_dry_run=True, is_update=True)
            return

        path.write_text(content)
        render_file_preview(path, content, is_dry_run=False, is_update=True)
        if _should_preview_markdown(path, preview_markdown):
            _render_markdown_file_preview(
                path,
                content,
                is_dry_run=False,
                is_update=True,
                title=markdown_title,
                max_lines=markdown_max_lines,
            )
