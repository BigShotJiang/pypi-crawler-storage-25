from __future__ import annotations

# This file is maintained by `rpr refresh manifest`.
# Keep the structure stable so the refresh command can rewrite it safely.

MANIFEST = {
    "root_node_dev_dependencies": {
        "@eslint/js": {
            "specifier": "latest",
        },
        "@nx/eslint": {
            "specifier": "latest",
        },
        "@nx/eslint-plugin": {
            "specifier": "latest",
        },
        "eslint": {
            "specifier": "latest",
        },
        "eslint-plugin-react-hooks": {
            "specifier": "latest",
        },
        "globals": {
            "specifier": "latest",
        },
        "prettier": {
            "specifier": "latest",
        },
        "typescript-eslint": {
            "specifier": "latest",
        },
    },
    "root_storybook_dev_dependencies": {
        "@nx/storybook": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "latest",
        }
    },
    "ui_library_dependencies": {
        "@mui/material": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "latest",
        },
        "@emotion/react": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "latest",
        },
        "@emotion/styled": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "latest",
        },
        "@tanstack/react-query": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "latest",
        },
        "@tanstack/react-router": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "latest",
        },
        "react": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "latest",
        },
        "react-dom": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "latest",
        },
    },
    "ui_library_dev_dependencies": {
        "@types/react": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "latest",
        },
        "@types/react-dom": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "latest",
        },
        "typescript": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "latest",
        },
        "vite": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "latest",
        },
        "vitest": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "latest",
        },
    },
    "web_app_dev_dependencies": {
        "@types/react": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "latest",
        },
        "@types/react-dom": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "latest",
        },
        "@vitejs/plugin-react": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "latest",
        },
        "typescript": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "latest",
        },
        "vite": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "latest",
        },
        "vitest": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "latest",
        },
    },
    "storybook_dependencies": {
        "@emotion/react": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "latest",
        },
        "@emotion/styled": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "latest",
        },
        "@mui/material": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "latest",
        },
        "react": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "latest",
        },
        "react-dom": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "latest",
        },
    },
    "storybook_dev_dependencies": {
        "@storybook/react": {
            "registry": "npm",
            "specifier": "^10.3.6",
            "strategy": "pinned-major",
        },
        "@storybook/react-vite": {
            "registry": "npm",
            "specifier": "^10.3.6",
            "strategy": "pinned-major",
        },
        "@vitejs/plugin-react": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "latest",
        },
        "@types/react": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "latest",
        },
        "@types/react-dom": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "latest",
        },
        "storybook": {
            "registry": "npm",
            "specifier": "^10.3.6",
            "strategy": "pinned-major",
        },
        "typescript": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "latest",
        },
        "vite": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "latest",
        },
        "vitest": {
            "registry": "npm",
            "specifier": "latest",
            "strategy": "latest",
        },
    },
    "domain_runtime_dependencies": {
        "sqlmodel": {
            "registry": "pypi",
            "specifier": "sqlmodel",
            "strategy": "latest",
        },
        "httpx": {
            "registry": "pypi",
            "specifier": "httpx",
            "strategy": "latest",
        },
        "dependency-injector": {
            "registry": "pypi",
            "specifier": "dependency-injector",
            "strategy": "latest",
        },
        "pydantic": {
            "registry": "pypi",
            "specifier": "pydantic",
            "strategy": "latest",
        },
        "pydantic-settings": {
            "registry": "pypi",
            "specifier": "pydantic-settings",
            "strategy": "latest",
        },
        "asyncpg": {
            "registry": "pypi",
            "specifier": "asyncpg",
            "strategy": "latest",
        },
    },
    "domain_migration_dependencies": {
        "alembic": {
            "registry": "pypi",
            "specifier": "alembic",
            "strategy": "latest",
        }
    },
    "api_runtime_base_dependencies": {
        "fastapi": {
            "registry": "pypi",
            "specifier": "fastapi",
            "strategy": "latest",
            "package": "fastapi",
        },
        "uvicorn[standard]": {
            "registry": "pypi",
            "specifier": "uvicorn[standard]",
            "strategy": "latest",
            "package": "uvicorn",
        },
    },
    "engine": {
        "pyo3": {
            "registry": "cratesio",
            "specifier": "*",
            "strategy": "latest",
        },
        "maturin": {
            "registry": "pypi",
            "specifier": "maturin",
            "strategy": "latest",
        },
    },
}
