from __future__ import annotations

from contextlib import chdir
import json
import subprocess
from pathlib import Path

from rich.console import Console
from typer.testing import CliRunner

from rpr.cli import app

runner = CliRunner()


def _completed(cmd: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")


def test_generate_ui_scaffolds_eslint_and_typecheck(monkeypatch):
    recorded_calls: list[list[str]] = []

    def fake_run_command(
        self, cmd, *, cwd=None, env=None, capture=False, supports_dry_run=False
    ):
        recorded_calls.append(cmd)
        return _completed(cmd)

    monkeypatch.setattr("rpr.context.RunContext.run_command", fake_run_command)

    with runner.isolated_filesystem():
        result = runner.invoke(app, ["generate", "ui", "my-app"])
        assert result.exit_code == 0, result.stdout

        root_package = json.loads(Path("package.json").read_text())
        lib_package = json.loads(
            Path("packages/node/my-app-ui/package.json").read_text()
        )
        lib_project = json.loads(
            Path("packages/node/my-app-ui/project.json").read_text()
        )
        app_package = json.loads(Path("apps/my-app-web/package.json").read_text())
        app_project = json.loads(Path("apps/my-app-web/project.json").read_text())

        assert root_package["workspaces"] == ["apps/*", "packages/node/*"]
        assert root_package["private"] is True
        assert "dependencies" not in lib_package
        assert "devDependencies" not in lib_package
        assert (
            lib_project["targets"]["build"]["options"]["command"]
            == "npx tsc -p tsconfig.json"
        )
        assert lib_project["targets"]["lint"]["options"]["command"] == "npx eslint ."
        assert lib_project["targets"]["test"]["options"]["command"] == "npx vitest run"
        assert (
            lib_project["targets"]["typecheck"]["options"]["command"]
            == "npx tsc --noEmit"
        )
        assert app_package["name"] == "@my-app/web"
        assert "dependencies" not in app_package
        assert "devDependencies" not in app_package
        assert app_project["targets"]["serve"]["options"]["command"] == "npx vite"
        assert app_project["targets"]["build"]["options"]["command"] == "npx vite build"
        assert app_project["targets"]["lint"]["options"]["command"] == "npx eslint ."
        assert app_project["targets"]["test"]["options"]["command"] == "npx vitest run"
        assert (
            app_project["targets"]["typecheck"]["options"]["command"]
            == "npx tsc --noEmit"
        )

        assert Path("packages/node/my-app-ui/eslint.config.mjs").exists()
        assert Path("packages/node/my-app-ui/src/index.test.ts").exists()
        assert Path("packages/node/my-app-ui/src/theme.ts").exists()
        assert (
            'export * from "./theme";'
            in Path("packages/node/my-app-ui/src/index.ts").read_text()
        )
        assert (
            "export const appTheme = createTheme"
            in Path("packages/node/my-app-ui/src/theme.ts").read_text()
        )
        assert Path("apps/my-app-web/eslint.config.mjs").exists()
        assert Path("apps/my-app-web/src/App.test.ts").exists()
        app_tsx = Path("apps/my-app-web/src/App.tsx").read_text()
        assert (
            'import { AppThemeProvider, uiPackageName } from "@my-app/ui";' in app_tsx
        )
        assert "<AppThemeProvider>" in app_tsx
        assert "Run with: npx nx serve my-app-web" in result.stdout
        assert any(
            cmd[:2] == ["npm", "i"] and "-D" not in cmd for cmd in recorded_calls
        )
        assert any(cmd[:3] == ["npm", "i", "-D"] for cmd in recorded_calls)


def test_generate_ui_dry_run_previews_files_and_skips_install(monkeypatch, capsys):
    recorded_calls: list[list[str]] = []

    def fake_run_command(
        self, cmd, *, cwd=None, env=None, capture=False, supports_dry_run=False
    ):
        recorded_calls.append(cmd)
        return _completed(cmd)

    monkeypatch.setattr("rpr.context.RunContext.run_command", fake_run_command)
    monkeypatch.setattr("rpr.context.console", Console(highlight=False, no_color=True))
    monkeypatch.setattr(
        "rpr.commands.generate.ui.console", Console(highlight=False, no_color=True)
    )

    with runner.isolated_filesystem():
        result = runner.invoke(app, ["generate", "ui", "my-app", "--dry-run"])
        assert result.exit_code == 0, result.stdout

        output = result.stdout + capsys.readouterr().out

        assert "Would create:" in output
        assert "package.json" in output
        assert "packages/node/my-app-ui/package.json" in output
        assert "packages/node/my-app-ui/src/theme.ts" in output
        assert "apps/my-app-web/package.json" in output
        assert "DRY RUN" in output
        assert "Would install npm dependencies for packages/node/my-app-ui" in output
        assert (
            "runtime=[@mui/material, @emotion/react, @emotion/styled, @tanstack/react-query, @tanstack/react-router, react, react-dom]"
            in output
        )
        assert "Would install npm dependencies for apps/my-app-web" in output
        assert "runtime=[@my-app/ui, react, react-dom]" in output
        assert recorded_calls == []
        assert not Path("package.json").exists()
        assert not Path("packages/node/my-app-ui/package.json").exists()
        assert not Path("apps/my-app-web/package.json").exists()


def test_generate_ui_preserves_existing_package_versions(monkeypatch):
    def fake_run_command(
        self, cmd, *, cwd=None, env=None, capture=False, supports_dry_run=False
    ):
        return _completed(cmd)

    monkeypatch.setattr("rpr.context.RunContext.run_command", fake_run_command)

    with runner.isolated_filesystem():
        lib_root = Path("packages/node/my-app-ui")
        app_root = Path("apps/my-app-web")
        lib_root.mkdir(parents=True)
        app_root.mkdir(parents=True)

        (lib_root / "package.json").write_text(
            json.dumps(
                {
                    "name": "@my-app/ui",
                    "dependencies": {
                        "@tanstack/react-query": "^5.99.0",
                        "zod": "^3.0.0",
                    },
                }
            )
        )
        (app_root / "package.json").write_text(
            json.dumps(
                {
                    "name": "@my-app/web",
                    "dependencies": {
                        "@my-app/ui": "workspace:*",
                        "react": "^19.1.0",
                    },
                }
            )
        )

        result = runner.invoke(app, ["generate", "ui", "my-app"])
        assert result.exit_code == 0, result.stdout

        lib_package = json.loads((lib_root / "package.json").read_text())
        app_package = json.loads((app_root / "package.json").read_text())

        assert lib_package["dependencies"]["@tanstack/react-query"] == "^5.99.0"
        assert lib_package["dependencies"]["zod"] == "^3.0.0"
        assert app_package["dependencies"]["react"] == "^19.1.0"
        assert app_package["dependencies"]["@my-app/ui"] == "workspace:*"
        assert "devDependencies" not in app_package


def test_generate_ui_normalizes_npm_package_names_for_mixed_case_app(monkeypatch):
    def fake_run_command(
        self, cmd, *, cwd=None, env=None, capture=False, supports_dry_run=False
    ):
        return _completed(cmd)

    monkeypatch.setattr("rpr.context.RunContext.run_command", fake_run_command)

    with runner.isolated_filesystem():
        Path("TestApp").mkdir()
        with chdir("TestApp"):
            result = runner.invoke(app, ["generate", "ui", "TestApp"])
            assert result.exit_code == 0, result.stdout

            root_package = json.loads(Path("package.json").read_text())
            lib_package = json.loads(
                Path("packages/node/testapp-ui/package.json").read_text()
            )
            app_package = json.loads(Path("apps/testapp-web/package.json").read_text())
            app_tsx = Path("apps/testapp-web/src/App.tsx").read_text()

            assert root_package["name"] == "testapp"
            assert lib_package["name"] == "@testapp/ui"
            assert app_package["name"] == "@testapp/web"
            assert "dependencies" not in app_package
            assert "workspace:*" not in json.dumps(app_package)
            assert 'from "@testapp/ui"' in app_tsx


def test_generate_ui_repairs_existing_workspace_protocol_for_mixed_case_app(
    monkeypatch,
):
    def fake_run_command(
        self, cmd, *, cwd=None, env=None, capture=False, supports_dry_run=False
    ):
        return _completed(cmd)

    monkeypatch.setattr("rpr.context.RunContext.run_command", fake_run_command)

    with runner.isolated_filesystem():
        Path("TestApp").mkdir()
        with chdir("TestApp"):
            lib_root = Path("packages/node/testapp-ui")
            app_root = Path("apps/testapp-web")
            lib_root.mkdir(parents=True)
            app_root.mkdir(parents=True)
            Path("package.json").write_text(
                json.dumps({"name": "TestApp", "private": True})
            )
            (lib_root / "package.json").write_text(
                json.dumps({"name": "@repo/TestApp-ui", "private": True})
            )
            (app_root / "package.json").write_text(
                json.dumps(
                    {
                        "name": "@repo/TestApp-web",
                        "dependencies": {
                            "@repo/TestApp-ui": "workspace:*",
                        },
                    }
                )
            )

            result = runner.invoke(app, ["generate", "ui", "TestApp"])
            assert result.exit_code == 0, result.stdout

            root_package = json.loads(Path("package.json").read_text())
            lib_package = json.loads((lib_root / "package.json").read_text())
            app_package = json.loads((app_root / "package.json").read_text())

            assert root_package["name"] == "testapp"
            assert lib_package["name"] == "@testapp/ui"
            assert app_package["name"] == "@testapp/web"
            assert app_package["dependencies"] == {"@repo/TestApp-ui": "workspace:*"}
