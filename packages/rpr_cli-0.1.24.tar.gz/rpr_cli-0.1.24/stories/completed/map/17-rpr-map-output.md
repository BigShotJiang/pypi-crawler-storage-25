# Story 17: Map Output — Generate Agent-Readable Markdown

## User Story

As an AI agent, I want to read a `code-map.md` file and immediately understand the architectural layers of a project, its entry points, its core domain objects, and the dependency relationships between files — without having to explore the codebase directly.

## Details

The output writer (`src/rpr/map/output.py`) takes the `DependencyGraph` and `list[ClassifiedNode]` and writes a single structured Markdown file. The format is designed for agent consumption: it is dense, consistent, and machine-parseable. Python owns this step regardless of whether the graph came from the Rust engine or the Python fallback.

### Output sections

#### 1. Header block (metadata)

```md
# Code Map

Generated: {ISO timestamp}
Root: {root path}
Files analyzed: {count}
Languages: {comma-separated list of languages actually found in the scanned files}
Analysis backend: rust | python-fallback
```

`Analysis backend` reflects whether the graph was produced by the Rust engine (`rpr_parser`) or the Python fallback pipeline, so agents and developers can judge both performance and likely accuracy at a glance.

#### 2. Layer summary table

One row per layer that has at least one file. Columns: `Layer | File count | Entry files (top 3 by in-degree)`.

#### 3. Entry points

List every `entry_point`-classified file with its `rel_path` and `out_degree`.

#### 4. Layers breakdown

One subsection per layer (skip empty layers). Each subsection lists:

- `rel_path` — `in_degree` dependents, `out_degree` dependencies
- Mark leaf nodes with `(leaf)`.

```
## Entities
- src/my_domain/models/entities/user.py — 4 dependents, 1 dependency
- src/my_domain/models/entities/base.py — 6 dependents, 0 dependencies (leaf)
```

#### 5. Dependency edges (condensed)

List edges **only for non-test files** to keep the file concise. Format:

```
src/rpr/cli.py → src/rpr/commands/map.py, src/rpr/commands/init.py
```

Omit files with no project-internal out-edges (leaves).

#### 6. Cycles (if any)

If the graph has cycles, list each cycle as a chain:

```
## ⚠ Cycles Detected
- src/a.py → src/b.py → src/a.py
```

If no cycles: omit this section entirely.

### File size constraint

If the total edge list would exceed ~300 lines, truncate it and add a note: `(truncated — {N} edges omitted)`. The summary and layers sections are never truncated.

## Assumptions

- The output is Markdown but is **not** intended for human reading or visualization rendering.
- Mermaid/Graphviz blocks are explicitly **not** included — this is a text-only agent artifact.
- Timestamps are in UTC ISO 8601 format.
- The output file is always overwritten (not appended) on each run.
- `--dry-run` mode prints the first 30 lines of what would be written, then stops.

## Acceptance Criteria

- [ ] `write_map(graph: DependencyGraph, nodes: list[ClassifiedNode], output: Path, root: Path, dry_run: bool = False) -> None` is the public API of `src/rpr/map/output.py`.
- [ ] Output file always starts with the metadata header block.
- [ ] The metadata header includes `Analysis backend: ...` sourced from `graph.backend`.
- [ ] Layer summary table is present and only includes layers with at least one file.
- [ ] Entry points section lists all `entry_point` nodes.
- [ ] Each layer subsection is only included if at least one file is classified to that layer.
- [ ] Leaf nodes are annotated with `(leaf)`.
- [ ] Dependency edges section omits test files and leaf nodes.
- [ ] Cycles section is included only when `graph.cycles` is non-empty.
- [ ] If edges exceed 300 lines, the list is truncated with a count of omitted edges.
- [ ] `--dry-run` mode passes `dry_run=True` to `write_map`; the function prints to stdout instead of writing to disk.
- [ ] Unit tests cover: correct layer table generation, cycle section presence/absence, leaf annotation, and dry-run stdout output.
