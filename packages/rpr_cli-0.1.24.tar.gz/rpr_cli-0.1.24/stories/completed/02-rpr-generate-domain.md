# Story 02: `rpr generate domain <name>`

## User Story

As a developer, I want to run `rpr generate domain my-app` to scaffold the Python domain package so that I have the DDD directory structure with entities, DTOs, repos, services, workflows, and DI configuration ready to go.

## Goal

Generate the backend domain package in the expected UV `src` layout and make it available as an NX target and UV workspace member.

## Acceptance Criteria

- [ ] Creates `packages/python/domain/` (structure only; utilities are added via `rpr add template`).
- [ ] Creates `packages/python/domain/pyproject.toml`.
- [ ] Creates the package under `src/<name_underscore>_domain/` (underscored form of `<name>`).
- [ ] Creates subfolders: `entities/`, `dtos/`, `repos/`, `services/`, `workflows/`, `config/`, `utils/`.
- [ ] Creates `__init__.py` in each subfolder.
- [ ] Scaffolds `config/settings.py` (Pydantic `BaseSettings` with `.env` loading) and `config/container.py` (Dependency Injector `DeclarativeContainer` with DB engine and HTTP client providers). See **Story 10** for the exact content contract.
- [ ] Scaffolds a `BaseEntity` in `models/entities/base.py` using `Sample-dot-github/scaffolds/domain/base_entity.md` as the reference.
- [ ] Scaffolds a base repository in `repos/base.py` using `Sample-dot-github/scaffolds/domain/base-repo.md` as the reference.
- [ ] The `utils/` folder is created but left empty; utilities are added via `rpr add template`.
- [ ] Adds the package to `[tool.uv.workspace].members` in the root `pyproject.toml`.
- [ ] Creates `project.json` with `test` and `lint` NX targets (see NX Targets below).
- [ ] Prompts for `<name>` if omitted.
- [ ] Supports `--dry-run`; always displays commands before executing (per Story 00).

## Generated File Manifest

```
packages/python/domain/
├── pyproject.toml
├── project.json
└── src/
    └── {name_underscore}_domain/
        ├── __init__.py
        ├── entities/
        │   ├── __init__.py
        │   └── base.py          # BaseEntity scaffold
        ├── dtos/
        │   └── __init__.py
        ├── repos/
        │   ├── __init__.py
        │   └── base.py          # Base repository scaffold
        ├── services/
        │   └── __init__.py
        ├── workflows/
        │   └── __init__.py
        ├── config/
        │   ├── __init__.py
        │   ├── settings.py      # Pydantic settings stub
        │   └── container.py     # Dependency Injector container stub
        └── utils/
            └── __init__.py      # empty; populated by rpr add template
```

## NX Targets

The `project.json` must define at minimum `test` and `lint` targets. Use `uv run` to invoke Python tools so they execute inside the package's managed environment:

| Target | Command                                        |
| ------ | ---------------------------------------------- |
| `test` | `uv run pytest packages/python/domain`         |
| `lint` | `uv run ruff check packages/python/domain/src` |

## Key Files

- `src/rpr/commands/generate/domain.py`
- `src/rpr/scaffolds/domain/`
- `Sample-dot-github/scaffolds/domain/base_entity.md` (reference for `BaseEntity`)
- `Sample-dot-github/scaffolds/domain/base-repo.md` (reference for base repository)
- `stories/10-rpr-domain-config.md` (defines the exact Settings and Container contract)

## Notes

- The domain package name uses underscores in the Python import path (`{name_underscore}_domain`) and dashes in the directory and `pyproject.toml` name (`{name}-domain`).
- Use `uv add` if stored dependencies need to be managed programmatically.
- The utils folder is scaffolded empty; use `rpr add template mapper_util`, `rpr add template dto_util`, `rpr add template partial_update`, or `rpr add template encrypted_column` to add those utilities.
- After scaffolding, offer to run `rpr add template` for the most common utilities (mapper_util, dto_util, partial_update).
- `config/settings.py` and `config/container.py` are generated from `src/rpr/scaffolds/domain/settings.md` and `container.md` (bundled templates that mirror `special_files/domain_settings.md` and `special_files/domain_container.md`). They can be reset at any time via `rpr add template domain_settings` or `rpr add template domain_container`.
- If the domain Container ever needs lifecycle hooks (startup/shutdown), see the lifecycle extension pattern documented in Story 10.

## Definition of Done

- [ ] UV workspace membership is updated.
- [ ] NX targets exist for domain linting (`ruff`) and testing (`pytest`).
- [ ] `BaseEntity` and base repository are scaffolded from the scaffold reference files.
- [ ] `config/settings.py` and `config/container.py` stubs exist.
- [ ] All subfolders have `__init__.py`.
- [ ] The command preview is fully represented in `--dry-run`.
