from tritlib.trits import Trits
from tritlib.trit import Trit
from tritlib.tryte import Tryte
from tritlib.trit import Z,N,P
import pytest

def test_tryte():
    a = Tryte(0, width = 6) 
    assert list(a.trits) == [Z]*6
    b = Tryte(2, width = 6)
    assert list(b.trits) == [N, P] + [Z] * 4

    with pytest.raises(OverflowError):
        Tryte(-400, width=6)
    with pytest.raises(OverflowError):
        Tryte(400, width=6)

    assert Tryte(42, width=6) == Tryte("+---0",6)

def test_tryte_lt():
    assert Tryte(42, width=6) < Tryte(45, width=6)
    assert Tryte(-19, width=6) < Tryte(45, width=6)
    assert Tryte(-42, width=6) < Tryte(-14, width=6)
    assert Tryte(45, width=6) > Tryte(-42, width=6)
    assert Tryte(45, width=6) > Tryte(42, width=6)
    assert Tryte(-15, width=6) > Tryte(-42, width=6)
    assert Tryte(-42, width=6) <= Tryte(-42, width=6)
    assert Tryte(42, width=6) >= Tryte(42, width=6)

def test_tryte_width():
    assert len(Tryte(42,6)) == 6
    with pytest.raises(ValueError):
        _ = Tryte(42,6) > Tryte(42,9)
    with pytest.raises(ValueError):
        _ = Tryte(42,6) == Tryte(42,9)

def test_tryte_add():
    assert Tryte(42,6) == Tryte(31,6) + Tryte(11,6)
    assert Tryte(300,6) + Tryte(300,6)
    assert (Tryte(332,6),Trit(0)) == Tryte(300,6).add_with_carry(Tryte(32,6))
    assert (Tryte(-364,6),Trit(1)) == Tryte(300,6).add_with_carry(Tryte(65,6))
    for i in range(-10,10):
        for j in range(-10,10):
            assert Tryte(j,6) + Tryte(i,6) == Tryte(i+j, 6)

def test_tryte_neg():
    assert Tryte(4,6) == -Tryte(-4,6)
    assert Tryte(0,6) == -Tryte(0,6)
    assert Tryte(-10,6) == -Tryte(10,6)

def test_tryte_sub():
    assert Tryte(6,6) - Tryte(7,6) == Tryte(-1,6)
    assert Tryte(20,6) - Tryte(4,6) == Tryte(16,6)
    assert Tryte(10,6) - Tryte(24,6) == Tryte(-14,6)
    for i in range(-10,10):
        for j in range(-10,10):
            assert Tryte(j,6) - Tryte(i,6) == Tryte(j-i, 6)

def test_tryte_mul():
    for i in range(-10,10):
        for j in range(-10,10):
            assert Tryte(j,6) * Tryte(i,6) == Tryte(i*j, 6)

def test_tryte_to_str():
    assert str(Tryte(-1,6)) == "00000-"
    assert str(Tryte(1,6)) == "00000+"
    assert str(Tryte(0,6)) == "000000"
    assert str(Tryte(2,6)) == "0000+-"
    assert str(Tryte(3,6)) == "0000+0"
    assert str(Tryte(5,6)) == "000+--"
    assert str(Tryte(-2,6)) == "0000-+"
    assert str(Tryte(-3,6)) == "0000-0"
    assert str(Tryte(-5,6)) == "000-++"

def test_tryte_to_trits():
    for i in range(-15,15):
        assert Tryte(i,6).to_trits() == Trits(i)


def test_be_trits():
    assert Tryte(-1,6)._be_trits == [N]
    assert Tryte(2,6)._be_trits == [P,N]
    assert Tryte(5,6)._be_trits == [P,N,N]
    assert Tryte(5,9)._be_trits == [P,N,N]
    assert Tryte(-5,6)._be_trits == [N,P,P]
    assert Tryte(-5,9)._be_trits == [N,P,P]

    assert Tryte.from_be_trits([N,P,P],6) == Tryte(-5,6)
    assert Tryte.from_be_trits([P,N],6) == Tryte(2,6)
    assert Tryte.from_be_trits([P,N,N],6) == Tryte(5,6)
    assert Tryte.from_be_trits([N,P,P],9) == Tryte(-5,9)

    for i in range(-105,355):
        t = Tryte(i, 6)
        b = t._be_trits
        assert Tryte.from_be_trits(b, 6) == t

def test_resize():
    for j in range(-10,10):
        for i in range(7,10):
            a = Tryte(j, 6)
            assert a.to_width(i) == Tryte(j,i)

    be_trits = [N,P,P,Z,P]
    assert Tryte.from_be_trits(be_trits,6).to_width(3) == Tryte.from_be_trits(be_trits[2:],3)


def test_divmod():
    a = [-101,-42,-13,-4,0,5,11,43,123]
    b = [-89,-34,-10,-1,2,8,20,40,80]
    for i in a[::1]:
        for j in b:
            q, r = divmod(Tryte(i,6), Tryte(j,6))
            assert int(q) * j + int(r) == i
    q, r = divmod(Tryte(13,6), Tryte(4,6))
    assert int(q) * 4 + int(r) == 13
    q, r = divmod(Tryte(7,6), Tryte(4,6))
    assert int(q) == 2 and int(r) == -1
    q, r = divmod(Tryte(-7,6), Tryte(4,6))
    assert int(q) * 4 + int(r) == -7

    q, r = divmod(Tryte(40,27), Tryte(6, 27))
    assert len(q) == len(r) == 27
    assert int(q) == 6
    assert int(r) == 4

    q, r = divmod(Tryte(0,6), Tryte(5,6))
    assert int(q) == 0 and int(r) == 0

    with pytest.raises(ZeroDivisionError):
        divmod(Tryte(4,6),Tryte(0,6))

    q, r = divmod(Tryte(5,6), Tryte(15,6))
    assert int(q) == 0 and int(r) == 5
    q, r = divmod(Tryte(14,6), Tryte(15,6))
    assert int(q) == 1 and int(r) == -1
