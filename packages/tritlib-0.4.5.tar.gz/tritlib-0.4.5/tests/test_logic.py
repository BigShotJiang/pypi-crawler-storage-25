from tritlib import Z, N, P, RM3, Bochvar, Lukasiewicz, HT, Kleene

def test_kleene_imply():
    logic = Kleene()
    assert logic.imply_op(N,N) == P
    assert logic.imply_op(Z,N) == Z
    assert logic.imply_op(P,N) == N
    assert logic.imply_op(N,Z) == P
    assert logic.imply_op(Z,Z) == Z
    assert logic.imply_op(P,Z) == Z
    assert logic.imply_op(N,P) == P
    assert logic.imply_op(Z,P) == P
    assert logic.imply_op(P,P) == P

def test_kleene_xor():
    logic = Kleene()
    assert logic.xor_op(N,N) == N
    assert logic.xor_op(N,Z) == Z
    assert logic.xor_op(N,P) == P
    assert logic.xor_op(Z,N) == Z
    assert logic.xor_op(Z,Z) == Z
    assert logic.xor_op(Z,P) == Z
    assert logic.xor_op(P,N) == P
    assert logic.xor_op(P,Z) == Z
    assert logic.xor_op(P,P) == N

    for a in [N,Z,P]:
        for b in [N,Z,P]:
            assert logic.equiv_op(a,b) == -logic.xor_op(a,b)



def test_lukasiewicz_imply():
    logic = Lukasiewicz()
    assert logic.imply_op(N,N) == P
    assert logic.imply_op(Z,N) == Z
    assert logic.imply_op(P,N) == N
    assert logic.imply_op(N,Z) == P
    assert logic.imply_op(Z,Z) == P
    assert logic.imply_op(P,Z) == Z
    assert logic.imply_op(N,P) == P
    assert logic.imply_op(Z,P) == P
    assert logic.imply_op(P,P) == P

def test_heyting():
    logic = HT()
    assert logic.not_op(N) == P
    assert logic.not_op(Z) == N
    assert logic.not_op(P) == N


    assert logic.imply_op(N,N) == P
    assert logic.imply_op(Z,N) == N
    assert logic.imply_op(P,N) == N
    assert logic.imply_op(N,Z) == P
    assert logic.imply_op(Z,Z) == P
    assert logic.imply_op(P,Z) == Z
    assert logic.imply_op(N,P) == P
    assert logic.imply_op(Z,P) == P
    assert logic.imply_op(P,P) == P

def test_rmingle3():
    logic = RM3()
    assert logic.imply_op(N,N) == P
    assert logic.imply_op(Z,N) == N
    assert logic.imply_op(P,N) == N
    assert logic.imply_op(N,Z) == P
    assert logic.imply_op(Z,Z) == Z
    assert logic.imply_op(P,Z) == N
    assert logic.imply_op(N,P) == P
    assert logic.imply_op(Z,P) == P
    assert logic.imply_op(P,P) == P

def test_bochvar():
    logic = Bochvar()
    assert logic.and_op(N,N) == N
    assert logic.and_op(N,Z) == Z
    assert logic.and_op(N,P) == N
    assert logic.and_op(Z,N) == Z
    assert logic.and_op(Z,Z) == Z
    assert logic.and_op(Z,P) == Z
    assert logic.and_op(P,N) == N
    assert logic.and_op(P,Z) == Z
    assert logic.and_op(P,P) == P

    assert logic.or_op(N,N) == N
    assert logic.or_op(N,Z) == Z
    assert logic.or_op(N,P) == P
    assert logic.or_op(Z,N) == Z
    assert logic.or_op(Z,Z) == Z
    assert logic.or_op(Z,P) == Z
    assert logic.or_op(P,N) == P
    assert logic.or_op(P,Z) == Z
    assert logic.or_op(P,P) == P

    assert logic.imply_op(N,N) == P
    assert logic.imply_op(Z,N) == Z
    assert logic.imply_op(P,N) == N
    assert logic.imply_op(N,Z) == Z
    assert logic.imply_op(Z,Z) == Z
    assert logic.imply_op(P,Z) == Z
    assert logic.imply_op(N,P) == P
    assert logic.imply_op(Z,P) == Z
    assert logic.imply_op(P,P) == P
