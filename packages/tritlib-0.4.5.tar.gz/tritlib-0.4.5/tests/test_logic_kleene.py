from tritlib.trit import Z, N, P

def test_and():
    assert (P & P) == P
    assert (P & Z) == Z
    assert (P & N) == N
    assert (Z & Z) == Z
    assert (Z & N) == N

def test_or():
    assert (N | N) == N
    assert (N | Z) == Z
    assert (N | P) == P
    assert (Z | Z) == Z
    assert (Z | P) == P

def test_not():
    assert ~P == N
    assert ~Z == Z
    assert ~N == P

