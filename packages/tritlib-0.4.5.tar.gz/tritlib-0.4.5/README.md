# tritlib

Balanced ternary arithmetic and multi-valued logic library for Python.

## What is balanced ternary?

Balanced ternary is a numeral system in base 3 where each digit (called a *trit*) takes values from {−1, 0, +1} instead of the conventional {0, 1, 2}. It allows representing negative numbers without a sign bit, and negation is as simple as inverting every trit. Donald Knuth called it *"perhaps the prettiest number system of all."*

## Features

- `Trit` — immutable single‑trit type with arithmetic and logic operators
- `Trits` — arbitrary‑length balanced ternary integers
- `Tryte` — fixed‑width ternary words
- Multiple ternary logic systems: Kleene (K3), Łukasiewicz (L3), Heyting (HT), Bochvar and R-mingle 3 (RM3)
- Step‑by‑step arithmetic (carry propagation, partial products) for educational use
- Pure Python, no dependencies, type‑hinted

## Installation

```bash
pip install tritlib
```

## Quick start

```python
from tritlib.trit import Trit, P, Z, N

# Create trits
t = Trit(1)   # +1
print(t)       # "+"
print(-t)      # "-"

# Predefined constants
assert P == Trit(1)
assert Z == Trit(0)
assert N == Trit(-1)
```

## Roadmap

- [x] `Trit` type with immutability, arithmetic, hashing
- [x] Trit‑level logic (Kleene K3)
- [x] `Trits` arbitrary‑precision integers
- [x] `Tryte` fixed‑width words
- [x] Additional logic systems (L3, HT, Bochvar, RM3)
- [ ] Conversion utilities (int, str, float, binary‑coded ternary)
- [ ] Educational step‑by‑step computation output

## Development

```bash
git clone https://codeberg.org/newick_2/tritlib.git
cd tritlib
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
python -m pytest
```

## License

MIT License — see LICENSE file for details.
