from functools import total_ordering

@total_ordering
class Trit:
    """
    Represents an immutable trinary digit (trit) with possible values: N (-1), Z (0), or P (1).
    Provides arithmetic and logical operations for trits, including addition, multiplication,
    negation, and bitwise operations.

    Attributes:
        _value (int): Internal value of the trit (-1, 0, or 1).

    Properties:
        value (int): Returns the integer value of the trit.

    Methods:
        __repr__(): Returns the official string representation of the trit.
        __str__(): Returns the user-friendly string representation ('-', '0', or '+').
        __eq__(other): Checks equality with another trit.
        __hash__(): Returns the hash of the trit.
        __neg__(): Returns the negation of the trit.
        __mul__(other): Multiplies two trits.
        half_add(other): Performs a half-addition with another trit, returning sum and carry.
        full_add(other, carry): Performs a full-addition with another trit and a carry, returning sum and carry.
        __invert__(): Returns the negation of the trit (alias for __neg__).
        __and__(other): Returns the logical AND of two trits (minimum value).
        __or__(other): Returns the logical OR of two trits (maximum value).
        __lt__(other): Compares two trits for ordering.

    Constants:
        N (Trit): Represents the trit value -1.
        Z (Trit): Represents the trit value 0.
        P (Trit): Represents the trit value 1.
    """
    __slots__ = ("_value",)

    def __init__(self, value: int):
        if not -2 < value < 2:
            raise ValueError

        object.__setattr__(self,"_value", value)

    def __repr__(self) -> str:
        return f"Trit({self._value})"

    def __str__(self) -> str:
        if self._value > 0:
            return "+"
        elif self._value == 0:
            return "0"
        else :
            return "-"

    def __eq__(self, other) -> bool:
        if not isinstance(other, Trit):
            return NotImplemented
        return self.value == other.value

    def __hash__(self) -> int:
        return hash(self._value)

    def __setattr__(self, name, value):
        raise AttributeError("Trit is immutable")

    @property
    def value(self) -> int:
        return self._value

    def __neg__(self) :
        return Trit(-self._value)

    def __mul__(self, other) :
        if not isinstance(other, Trit):
            return NotImplemented
        return Trit(self.value * other.value)

    def half_add(self, other):
        if not isinstance(other, Trit):
            return NotImplemented
        if self.value == other.value :
            s = -self
            c = self
        else:
            s = Trit(self.value + other.value)
            c = Z
        return (s,c)

    def full_add(self, other, carry):
        if not (isinstance(other, Trit) and isinstance(carry, Trit)):
            return NotImplemented
        s1, c1 = self.half_add(other)
        s2, c2 = s1.half_add(carry)
        return s2, Trit(c1.value+c2.value)

    def __invert__(self):
        return self.__neg__()

    def __and__(self, other):
        if not isinstance(other, Trit):
            return NotImplemented
        return Trit(min(self._value, other._value))

    def __or__(self, other):
        if not isinstance(other, Trit):
            return NotImplemented
        return Trit(max(self._value, other._value))

    def __lt__(self, other):
        return self.value < other.value
        
N = Trit(-1)
Z = Trit(0)
P = Trit(1)
