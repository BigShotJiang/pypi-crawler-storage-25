from __future__ import annotations
from functools import total_ordering
from tritlib.trits import Trits
from tritlib.trit import Z, N, P, Trit

@total_ordering
class Tryte:
    """
    Represents a fixed-width trit-based number system (tryte).
    Supports arithmetic operations, comparisons, and conversions between trits and integers.
    The class is immutable and handles overflow by truncating to the specified width.

    Attributes:
        _trits (tuple[Trit]): Internal tuple of Trit objects representing the tryte.
        _width (int): Fixed width of the tryte.

    Properties:
        width (int): Returns the width of the tryte.
        trits (list[Trit]): Returns the list of Trit objects representing the tryte.
        _be_trits (list[Trit]): Returns the trits in little-endian order.

    Class Methods:
        _from_trits(trits, width): Creates a Tryte object from a list of Trit objects (little-endian) and a width.
        from_be_trits(trits, width): Creates a Tryte object from a list of Trit objects in big-endian order and a width.

    Methods:
        __hash__(): Returns the hash of the Tryte object.
        __init__(value, width): Initializes a Tryte object from a value (int or Trits) and a width.
        __int__(): Converts the Tryte number to an integer.
        to_trits(): Converts the Tryte object to a Trits object.
        resize(width): Returns a new Tryte object with the specified width.
        __len__(): Returns the number of trits in the tryte.
        __eq__(other): Checks equality with another Tryte object.
        __lt__(other): Compares two Tryte objects for ordering.
        __repr__(): Returns the official string representation of the Tryte object.
        __str__(): Returns the string representation of the Tryte number.
        __add__(other): Adds two Tryte numbers.
        __neg__(): Returns the negation of the Tryte number.
        __sub__(other): Subtracts two Tryte numbers.
        __mul__(other): Multiplies two Tryte numbers.
        add_with_carry(other): Adds two Tryte numbers and returns the result and carry flag.
        __divmod__(other): Performs division and modulus operations between two Tryte numbers.
        __floordiv__(other): Performs floor division between two Tryte numbers.
        __mod__(other): Performs modulus operation between two Tryte numbers.

    Usage:
        >>> tryte = Tryte(10, 5)
        >>> print(tryte)
        +-000
    """
    __slots__ = ("_trits", "_width")

    def __hash__(self) -> int:
        return hash(self._trits)

    def __setattr__(self, name, value):
        raise AttributeError("Trits is immutable")

    def __init__(self, value, width: int):
        trits = Trits(value)
        if len(trits) > width:
            raise OverflowError
        else:
            trits = list(trits.trits) + [Z] * (width - len(trits.trits))
        object.__setattr__(self, "_trits", tuple(trits))
        object.__setattr__(self, "_width", width)

    @classmethod
    def _from_trits(cls, trits: list[Trit] | tuple[Trit], width: int) -> Tryte:
        # Do not raise OverflowError to simulate hardware behaviour
        if isinstance(trits, tuple):
            trits = list(trits)
        trits = trits + [Z]*(width - len(trits))
        obj = cls.__new__(cls)
        object.__setattr__(obj,"_trits",tuple(trits[:width]))
        object.__setattr__(obj,"_width",width)
        return obj 

    @property
    def width(self) -> int:
        return self._width

    def __int__(self) -> int:
        acc = 0
        # Horner's method
        for trit in reversed(self._trits):
            acc = acc * 3 + trit.value
        return acc

    @property
    def trits(self) -> tuple[Trit]:
        return self._trits

    def to_trits(self) -> Trits:
        s = list(self._trits)
        while s[-1] == Z and len(s)>1:
            s= s[:-1]
        return Trits._from_trits(s)

    @property    
    def _be_trits(self) -> list[Trit]:
        s = list(self.trits)
        r = []
        while len(s)>0:
            a = s.pop()
            if len(r) == 0 and a == Z:
                continue
            r.append(a)
        return [Z] if len(r) == 0 else r

    @classmethod
    def from_be_trits(cls, trits: list[Trit], width: int) -> Tryte:
        return cls._from_trits(list(reversed(trits)), width)

    def to_width(self, width) -> Tryte:
        return Tryte._from_trits(list(self._trits), width)

    def __len__(self) -> int:
        return len(self._trits)

    def __getitem__(self, s):
        return Trits._from_trits(self.trits[s]) 

    def __eq__(self, other) -> bool:
        if len(self) != len(other):
            raise ValueError
        return self.trits == other.trits

    def __lt__(self, other) -> bool:
        if len(self) != len(other):
            raise ValueError
        for t1, t2 in zip(reversed(self.trits), reversed(other.trits)):
            if t1 < t2:
                return True
            elif t1 > t2:
                return False
        return False

    def __abs__(self) -> Tryte:
        if self._be_trits[0] == N:
            return -self
        return self

    def __repr__(self) -> str:
        return f'Tryte({int(self)}, {self.width})'
    
        
    def __str__(self) -> str:
        trit_dict = {P: "+", N: "-", Z: "0"}
        return "".join(trit_dict[t] for t in reversed(self._trits))

    def __add__(self, other) -> Tryte:
        if not isinstance(other, Tryte):
            return NotImplemented
        if len(self) != len(other):
            raise TypeError 
        _trits = []
        c = Z
        for a,b in zip(self.trits, other.trits):
            s, c = a.full_add(b, c)
            _trits.append(s)
        return Tryte._from_trits(_trits, self.width)

    def __neg__(self) -> Tryte:
        return Tryte._from_trits([-t for t in self.trits], self.width)

    def __sub__(self, other) -> Tryte:
        if len(self) != len(other):
            raise TypeError 
        return self + -other

    def __mul__(self, other) -> Tryte:
        if not isinstance(other, Tryte):
            return NotImplemented
        if len(self) != len(other):
            raise TypeError 
        result = Tryte._from_trits([Z], self.width)
        for i,t in enumerate(self._trits):
            if t == Z:
                continue
            partial = [Z] * i + [t*a for a in other._trits]
            p = Tryte._from_trits(partial, self.width)
            result = result + p
        return Tryte._from_trits(list(result.trits), self.width)

    def add_with_carry(self, other) -> tuple[Tryte,Trit]:
        if not isinstance(other, Tryte):
            return NotImplemented
        if len(self) != len(other):
            raise TypeError 
        _trits = []
        c = Z
        for a,b in zip(self.trits, other.trits):
            s, c = a.full_add(b, c)
            _trits.append(s)
        return Tryte._from_trits(_trits, self.width), c


    def __divmod__(self, other) -> tuple[Tryte, Tryte]:
        if not isinstance(other, Tryte):
            return NotImplemented
        if other == Tryte(0, self.width):
            raise ZeroDivisionError
        if self == Tryte(0, self.width):
            return Tryte(0, self.width), Tryte(0, self.width)
        if len(self) != len(other):
            raise TypeError 
        sign_s = self._be_trits[0] == P
        sign_d = other._be_trits[0] == P
    
        s = abs(self)._be_trits
        d = abs(other)._be_trits
        partial_rest = s[:len(d)-1]
        rem = s[len(d)-1:]
        q = []
        while len(rem) > 0:
            partial_rest += [rem.pop(0)]
            if d[0]*partial_rest[0] == P:
                q.append(P)
                pr = Tryte.from_be_trits(partial_rest, self.width) - abs(other)
                partial_rest = pr._be_trits
            elif d[0]*partial_rest[0] == N:
                q.append(N)
                pr = Tryte.from_be_trits(partial_rest, self.width) + abs(other)
                partial_rest = pr._be_trits
            else:
                q.append(Z)

        q = Tryte.from_be_trits(q, self.width)
        pr = Tryte.from_be_trits(partial_rest, self.width) 

        while pr > other:
            q = q + Tryte(1, self.width)
            pr = pr - abs(other)

        # signe : quotient négatif si signes opposés
        if sign_s != sign_d:
            q = -q
        # reste : signe du dividende
        if not sign_s:
            pr = -pr
        return q, pr

    def __floordiv__(self, other) -> Tryte:
        return divmod(self, other)[0]
       
    def __mod__(self, other) -> Tryte:
        return divmod(self, other)[1]
