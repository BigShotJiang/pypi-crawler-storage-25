from __future__ import annotations
from functools import total_ordering
from typing import Tuple
from tritlib.trit import Trit, N, Z, P
from itertools import zip_longest

def _str_to_trits(s: str):
    trit_dict = {"+": P, "-": N, "0": Z}
    trits = []
    for char in reversed(s):
        if char not in trit_dict:
            raise ValueError
        else:
            trits.append(trit_dict.get(char))
    return trits

@total_ordering
class Trits:
    """
    Represents an immutable number in a balanced ternary system using trits (ternary digits: P, Z, N).
    Supports arithmetic operations, comparisons, and conversions between strings and integers.

    Attributes:
        _trits (tuple[Trit]): Internal tuple of Trit objects representing the number.

    Class Methods:
        _from_trits(trits): Creates a Trits object from a list of Trit objects (little-endian).
        _from_be_trits(trits): Creates a Trits object from a list of Trit objects in big-endian order.
        from_str(str_value): Creates a Trits object from a string representation (e.g., "+-0").

    Properties:
        _be_trits (list[Trit]): Returns the trits in big-endian order.

    Methods:
        __hash__(): Returns the hash of the Trits object.
        __str__(): Returns the string representation of the Trits number.
        __init__(n): Initializes a Trits object from a string or integer.
        __eq__(other): Checks equality with another Trits object.
        __lt__(other): Compares two Trits objects for ordering.
        __add__(other): Adds two Trits numbers.
        __sub__(other): Subtracts two Trits numbers.
        __mul__(other): Multiplies two Trits numbers.
        __floordiv__(other): Performs floor division between two Trits numbers.
        to_int(): Converts the Trits number to an integer.

    Usage:
        >>> trits = Trits.from_str("+-0")
        >>> print(trits)
        +-0
    """
    __slots__ = ("_trits",)

    def __hash__(self) -> int:
        return hash(self._trits)

    def __setattr__(self, name, value):
        raise AttributeError("Trits is immutable")
    
    @classmethod
    def _from_trits(cls, trits: list[Trit] | tuple[Trit]) -> Trits:
        if isinstance(trits, tuple):
            trits = list(trits)
        while len(trits)>1 and trits[-1] == Z:
            trits.pop()
        obj = cls.__new__(cls)
        if len(trits) == 0:
            trits = [Z]
        object.__setattr__(obj,"_trits",tuple(trits))
        return obj

    @classmethod
    def from_be_trits(cls, trits: list[Trit]) -> Trits:
        return cls._from_trits(list(reversed(trits)))

    @property
    def _be_trits(self):
        return list(reversed(self.trits))

    @classmethod 
    def from_str(cls, str_value: str) -> Trits:
        return cls._from_trits(_str_to_trits(str_value))

    def __str__(self) -> str:
        trit_dict = {P: "+", N: "-", Z: "0"}
        return "".join(trit_dict[t] for t in reversed(self._trits))

    def __init__(self, n):
        if isinstance(n, str):
            object.__setattr__(self, "_trits", tuple(_str_to_trits(n)))
        elif isinstance(n, int):
            if n == 0:
                object.__setattr__(self, "_trits", (Z,))
                return
            _trits = []
            while n != 0:
                n, r = divmod(n, 3)
                if r == 2 :
                    n += 1
                    _trits.append(N)
                elif r == 1:
                    _trits.append(P)
                else :
                    _trits.append(Z)
            object.__setattr__(self, "_trits", tuple(_trits))
        else:
            raise TypeError(f"cannot convert {type(n)} to Trits")

    def __repr__(self) -> str:
        return f"Trits(\"{str(self)}\")"
    
    def __int__(self) -> int:
        acc = 0
        # Horner's method
        for trit in reversed(self._trits):
            acc = acc * 3 + trit.value

        return acc

    @property
    def trits(self) -> Tuple[Trit]:
        return self._trits

    def __eq__(self, other) -> bool:
        if not isinstance(other, Trits):
            return NotImplemented
        return self.trits == other.trits

    def __abs__(self) -> Trits:
        if self.trits[-1] == N:
            return -self
        return self

    def __add__(self, other) -> Trits:
        if not isinstance(other, Trits):
            return NotImplemented
        _trits = []
        c = Z
        for a,b in zip_longest(self.trits, other.trits, fillvalue=Z):
            s, c = a.full_add(b, c)
            _trits.append(s)
        if c != Z:
            _trits.append(c)
        return Trits._from_trits(_trits)

    def __neg__(self) -> Trits:
        return Trits._from_trits([-t for t in self._trits])

    def __sub__(self, other) -> Trits:
        if not isinstance(other, Trits):
            return NotImplemented
        return self + -other

    def __mul__(self, other) -> Trits:
        if not isinstance(other, Trits):
            return NotImplemented
        result = Trits._from_trits([Z])
        for i,t in enumerate(self._trits):
            if t == Z:
                continue
            partial = [Z] * i + [t*a for a in other._trits]
            p = Trits._from_trits(partial)
            result = result + p
        return result

    def __len__(self):
        return len(self._trits)

    def __lt__(self, other):
        if not isinstance(other, Trits):
            return NotImplemented
        if len(self) < len(other):
            return other.trits[-1] == P
        elif len(self) > len(other):
            return self.trits[-1] == N 
        else:
            for t1, t2 in zip(reversed(self.trits), reversed(other.trits)):
                if t1 < t2:
                    return True
                elif t1 > t2:
                    return False
            return False

    def __divmod__(self, other) -> tuple[Trits, Trits]:
        if not isinstance(other, Trits):
            return NotImplemented
        if other == Trits(0):
            raise ZeroDivisionError
        if self._trits == (Z,):
            return Trits(0), Trits(0)
        if len(self) < len(other):
            return Trits(0), self 

        sign_s = self._be_trits[0] == P
        sign_d = other._be_trits[0] == P
    
        s = abs(self)._be_trits
        d = abs(other)._be_trits
        partial_rest = s[:len(d)-1]
        rem = s[len(d)-1:]
        q = []
        while len(rem) > 0:
            partial_rest += [rem.pop(0)]
            if d[0]*partial_rest[0] == P:
                q.append(P)
                pr = Trits.from_be_trits(partial_rest) - abs(other)
                partial_rest = pr._be_trits
            elif d[0]*partial_rest[0] == N:
                q.append(N)
                pr = Trits.from_be_trits(partial_rest) + abs(other)
                partial_rest = pr._be_trits
            else:
                q.append(Z)

        q = Trits.from_be_trits(q)
        pr = Trits.from_be_trits(partial_rest) 

        while pr > other:
            q = q + Trits(1)
            pr = pr - abs(other)

        # signe : quotient négatif si signes opposés
        if sign_s != sign_d:
            q = -q
        # reste : signe du dividende
        if not sign_s:
            pr = -pr
        return q, pr

    def __floordiv__(self, other) -> Trits:
        return divmod(self, other)[0]
       
    def __mod__(self, other) -> Trits:
        return divmod(self, other)[1]
