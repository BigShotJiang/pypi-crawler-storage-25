from tritlib.logic.base import TernaryLogic
from tritlib.trit import N, P,Z, Trit


class HT(TernaryLogic):
    """
    Implements Heyting ternary logic operations.
    Provides specific implementations for logical NOT and IMPLY operations.

    Methods:
        not_op(a): Returns the Heyting logical NOT of a trit.
        imply_op(a, b): Returns the Heyting logical implication of two trits.
    """
    def not_op(self, a:Trit) -> Trit:
        return P if a == N else N

    def imply_op(self, a: Trit, b: Trit) -> Trit:
        if b == P:
            return P
        elif b == Z:
            return Z if a == P else P
        else :
            return self.not_op(a)

