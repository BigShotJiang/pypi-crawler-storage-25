from tritlib.logic.base import TernaryLogic
from tritlib.trit import Trit


class Kleene(TernaryLogic):
    """
    Implements Kleene ternary logic operations.
    Provides a specific implementation for the logical IMPLY operation.

    Methods:
        imply_op(a, b): Returns the Kleene logical implication of two trits.
    """
    def imply_op(self, a: Trit, b: Trit) -> Trit:
        return -a | b
