"""
tritlib.logic: Ternary logic operations.

This subpackage provides implementations of various ternary logic systems:
Lukasiewicz, RM3, Bochvar, Heyting, and Kleene.
"""

from .lukasiewicz import Lukasiewicz
from .rm3 import RM3
from .bochvar import Bochvar
from .heyting import HT
from .kleene import Kleene

__all__ = ["Lukasiewicz", "RM3", "Bochvar", "HT", "Kleene"]
