from tritlib.logic.base import TernaryLogic
from tritlib.trit import Trit, P, Z


class Lukasiewicz(TernaryLogic):
    """
    Implements Lukasiewicz ternary logic operations.
    Provides specific implementations for logical NOT and IMPLY operations.

    Methods:
        imply_op(a, b): Returns the Lukasiewicz logical implication of two trits.
    """


    def imply_op(self, a: Trit, b: Trit) -> Trit:
        if a == b == Z:
            return P
        else:
            return -a | b

