from tritlib.logic.base import TernaryLogic
from tritlib.trit import Trit, P, Z, N

class RM3(TernaryLogic):
    """
    Implements RM3 ternary logic operations.
    Provides specific implementations for logical NOT and IMPLY operations.

    Methods:
        not_op(a): Returns the RM3 logical NOT of a trit.
        imply_op(a, b): Returns the RM3 logical implication of two trits.
    """
    def imply_op(self, a: Trit, b: Trit) -> Trit:
        if b == P :
            return P
        elif b == Z:
            return -a
        else :
            return P if a == N else N
       
