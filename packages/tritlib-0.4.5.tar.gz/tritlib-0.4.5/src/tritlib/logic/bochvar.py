from tritlib.logic.base import TernaryLogic
from tritlib import N, P,Z, Trit

class Bochvar(TernaryLogic):
    """
    Implements Bochvar's three-valued logic operations.
    Provides specific implementations for logical AND, OR, and IMPLY operations.

    Methods:
        and_op(a, b): Returns the Bochvar logical AND of two trits.
        or_op(a, b): Returns the Bochvar logical OR of two trits.
        imply_op(a, b): Returns the Bochvar logical implication of two trits.
    """
    def and_op(self, a: Trit, b: Trit) -> Trit:
        if a == Z or b == Z:
            return Z
        if a == b == P:
            return P
        return N

    def imply_op(self, a: Trit, b: Trit) -> Trit:
        if a == Z or b == Z:
            return Z
        elif b == P:
            return P
        else:
            return -a

    def or_op(self, a: Trit, b: Trit) -> Trit:
        if a == Z or b == Z:
            return Z
        if a == b == N:
            return N
        return P

