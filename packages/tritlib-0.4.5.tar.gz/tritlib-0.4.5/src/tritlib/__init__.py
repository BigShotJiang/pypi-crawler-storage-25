"""
tritlib: A Python library for trinary arithmetic and logic operations.

This package provides classes for working with trits (ternary digits), trits numbers, and fixed-width trytes.
It supports arithmetic operations, comparisons, and conversions between strings, integers, and trits.
"""

from .trit import Trit, N, Z, P
from .trits import Trits
from .tryte import Tryte
from .logic import Lukasiewicz, RM3, Bochvar, HT, Kleene

__all__ = ["Trit", "Trits", "Tryte", "N", "Z", "P", "Lukasiewicz", "RM3", "Bochvar", "HT", "Kleene"]
