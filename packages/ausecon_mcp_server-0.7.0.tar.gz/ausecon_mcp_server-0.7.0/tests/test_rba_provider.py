from pathlib import Path

import pytest
import respx
from httpx import Response

from ausecon_mcp.providers.rba import RBAProvider

FIXTURES = Path(__file__).parent / "fixtures"


def test_rba_provider_lists_tables_by_category() -> None:
    provider = RBAProvider()

    results = provider.list_tables(category="exchange_rates")

    ids = [item["id"] for item in results]

    assert "f11" in ids
    assert "a5" not in ids
    assert all(item["discontinued"] is False for item in results)


def test_rba_provider_can_include_discontinued_tables() -> None:
    provider = RBAProvider()

    results = provider.list_tables(category="exchange_rates", include_discontinued=True)

    ids = [item["id"] for item in results]

    assert "f11" in ids
    assert "a5" in ids
    assert any(item["id"] == "a5" and item["discontinued"] is True for item in results)


@pytest.mark.asyncio
async def test_rba_provider_fetches_table_and_uses_cache() -> None:
    provider = RBAProvider()
    csv_payload = (FIXTURES / "rba_g1_sample.csv").read_text()

    with respx.mock(assert_all_called=True) as router:
        route = router.get("https://www.rba.gov.au/statistics/tables/csv/g1-data.csv").mock(
            return_value=Response(200, text=csv_payload)
        )

        first = await provider.get_table("g1", last_n=2)
        second = await provider.get_table("g1", last_n=2)

    assert route.call_count == 1
    assert first == second
    assert len(first["observations"]) == 2
    assert first["metadata"]["truncated"] is True
    assert first["metadata"]["retrieval_url"].endswith("/g1-data.csv")


@pytest.mark.asyncio
async def test_rba_provider_reuses_cached_raw_payload_across_client_side_filters() -> None:
    provider = RBAProvider()
    csv_payload = (FIXTURES / "rba_g1_sample.csv").read_text()

    with respx.mock(assert_all_called=True) as router:
        route = router.get("https://www.rba.gov.au/statistics/tables/csv/g1-data.csv").mock(
            return_value=Response(200, text=csv_payload)
        )

        first = await provider.get_table("g1", series_ids=["GCPIAGYP"], last_n=1)
        second = await provider.get_table("g1", series_ids=["GCPIAGSAQP", "GCPIAGYP"], last_n=2)

    assert route.call_count == 1
    assert len(first["observations"]) == 1
    assert len(second["observations"]) == 2


@pytest.mark.asyncio
async def test_rba_provider_normalises_series_id_order_for_equivalent_filters() -> None:
    provider = RBAProvider()
    csv_payload = (FIXTURES / "rba_g1_sample.csv").read_text()

    with respx.mock(assert_all_called=True) as router:
        route = router.get("https://www.rba.gov.au/statistics/tables/csv/g1-data.csv").mock(
            return_value=Response(200, text=csv_payload)
        )

        first = await provider.get_table("g1", series_ids=["GCPIAGYP", "GCPIAGSAQP"])
        second = await provider.get_table("g1", series_ids=["GCPIAGSAQP", "GCPIAGYP"])

    assert route.call_count == 1
    assert first == second


@pytest.mark.asyncio
async def test_rba_provider_retries_transient_failures() -> None:
    provider = RBAProvider()
    csv_payload = (FIXTURES / "rba_g1_sample.csv").read_text()

    with respx.mock(assert_all_called=True) as router:
        route = router.get("https://www.rba.gov.au/statistics/tables/csv/g1-data.csv").mock(
            side_effect=[
                Response(500, text="server unavailable"),
                Response(502, text="bad gateway"),
                Response(200, text=csv_payload),
            ]
        )

        result = await provider.get_table("g1")

    assert route.call_count == 3
    assert result["metadata"]["dataset_id"] == "g1"


@pytest.mark.asyncio
async def test_rba_provider_wraps_parse_failures() -> None:
    provider = RBAProvider()

    with respx.mock(assert_all_called=True) as router:
        router.get("https://www.rba.gov.au/statistics/tables/csv/g1-data.csv").mock(
            return_value=Response(200, text="bad-payload")
        )

        with pytest.raises(Exception, match="Failed to parse RBA table payload for 'g1'"):
            await provider.get_table("g1")


@pytest.mark.asyncio
async def test_rba_provider_does_not_retry_client_errors() -> None:
    provider = RBAProvider()

    with respx.mock(assert_all_called=True) as router:
        route = router.get("https://www.rba.gov.au/statistics/tables/csv/g1-data.csv").mock(
            return_value=Response(404, text="not found")
        )

        with pytest.raises(Exception, match="404"):
            await provider.get_table("g1")

    assert route.call_count == 1


@pytest.mark.asyncio
async def test_rba_provider_supports_a2_event_tables() -> None:
    provider = RBAProvider()
    csv_payload = (FIXTURES / "rba_a2_sample.csv").read_text()

    with respx.mock(assert_all_called=True) as router:
        router.get("https://www.rba.gov.au/statistics/tables/csv/a2-data.csv").mock(
            return_value=Response(200, text=csv_payload)
        )

        result = await provider.get_table("a2")

    assert result["metadata"]["dataset_id"] == "a2"
    assert result["observations"][0]["date"] == "1990-01-23"
    assert result["observations"][0]["raw_value"] == "-0.50 to -1.00"
    assert result["observations"][-1]["series_id"] == "ARBAMPNORR"
    assert result["observations"][-1]["value"] == 7.25


@pytest.mark.asyncio
async def test_rba_provider_stamps_server_version_in_metadata() -> None:
    provider = RBAProvider()
    csv_payload = (FIXTURES / "rba_g1_sample.csv").read_text()

    with respx.mock(assert_all_called=True) as router:
        router.get("https://www.rba.gov.au/statistics/tables/csv/g1-data.csv").mock(
            return_value=Response(200, text=csv_payload)
        )

        result = await provider.get_table("g1")

    assert isinstance(result["metadata"]["server_version"], str)
    assert result["metadata"]["server_version"]


@pytest.mark.asyncio
async def test_rba_provider_returns_stale_on_upstream_failure(tmp_path) -> None:
    import json as _json

    from httpx import ConnectTimeout

    from ausecon_mcp.cache import TTLCache

    cache = TTLCache(disk_dir=tmp_path / "cache", ttl_seconds=60)
    provider = RBAProvider(cache=cache)
    csv_payload = (FIXTURES / "rba_g1_sample.csv").read_text()

    with respx.mock(assert_all_called=True) as router:
        router.get("https://www.rba.gov.au/statistics/tables/csv/g1-data.csv").mock(
            return_value=Response(200, text=csv_payload)
        )
        await provider.get_table("g1")

    (file,) = (tmp_path / "cache").glob("*.json")
    data = _json.loads(file.read_text())
    data["expires_at"] = 0.0
    file.write_text(_json.dumps(data))

    fresh_cache = TTLCache(disk_dir=tmp_path / "cache", ttl_seconds=60)
    fresh_provider = RBAProvider(cache=fresh_cache)

    with respx.mock(assert_all_called=True) as router:
        router.get("https://www.rba.gov.au/statistics/tables/csv/g1-data.csv").mock(
            side_effect=ConnectTimeout("network down")
        )

        stale = await fresh_provider.get_table("g1")

    assert stale["metadata"]["stale"] is True
    assert "cached_at" in stale["metadata"]
    assert "expires_at" in stale["metadata"]
    assert stale["observations"]


@pytest.mark.asyncio
async def test_rba_provider_parse_failure_is_not_masked_by_stale(tmp_path) -> None:
    import json as _json

    from ausecon_mcp.cache import TTLCache

    cache = TTLCache(disk_dir=tmp_path / "cache", ttl_seconds=60)
    provider = RBAProvider(cache=cache)
    csv_payload = (FIXTURES / "rba_g1_sample.csv").read_text()

    with respx.mock(assert_all_called=True) as router:
        router.get("https://www.rba.gov.au/statistics/tables/csv/g1-data.csv").mock(
            return_value=Response(200, text=csv_payload)
        )
        await provider.get_table("g1")

    (file,) = (tmp_path / "cache").glob("*.json")
    data = _json.loads(file.read_text())
    data["expires_at"] = 0.0
    file.write_text(_json.dumps(data))

    fresh_cache = TTLCache(disk_dir=tmp_path / "cache", ttl_seconds=60)
    fresh_provider = RBAProvider(cache=fresh_cache)

    with respx.mock(assert_all_called=True) as router:
        router.get("https://www.rba.gov.au/statistics/tables/csv/g1-data.csv").mock(
            return_value=Response(200, text="")
        )

        with pytest.raises(Exception, match="Failed to parse RBA table payload"):
            await fresh_provider.get_table("g1")


@pytest.mark.asyncio
async def test_rba_provider_sends_identified_user_agent() -> None:
    provider = RBAProvider()
    csv_payload = (FIXTURES / "rba_g1_sample.csv").read_text()

    with respx.mock(assert_all_called=True) as router:
        route = router.get("https://www.rba.gov.au/statistics/tables/csv/g1-data.csv").mock(
            return_value=Response(200, text=csv_payload)
        )

        await provider.get_table("g1")

    ua = route.calls.last.request.headers["user-agent"]
    assert ua.startswith("ausecon-mcp-server/")
    assert "github.com/AnthonyPuggs/ausecon-mcp-server" in ua
