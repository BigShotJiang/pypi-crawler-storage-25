"""Policy engine for Agent-Airlock.

Provides RBAC (Role-Based Access Control) for AI agents with:
- Tool allow/deny lists
- Time-based restrictions
- Rate limiting
- Agent identity tracking
- Capability gating (V0.4.0)
"""

from __future__ import annotations

import copy
import fnmatch
import hashlib
import json
import re
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import TYPE_CHECKING, Any, Literal

import structlog

from .exceptions import AirlockError

if TYPE_CHECKING:
    from .capabilities import CapabilityPolicy
    from .cost_tracking import (
        BudgetEstimate,
        CostTracker,
        ModelTierBudget,
    )

logger = structlog.get_logger("agent-airlock.policy")


class PolicyMutationError(AirlockError):
    """Raised when a frozen policy's digest no longer matches its content.

    Introduced 2026-04-24 to close CVE-2026-41349 (OpenClaw agentic
    consent-bypass, CVSS 8.8). The attack mutated ``allowed_tools`` /
    ``denied_tools`` mid-session to add a tool the user hadn't approved.
    :meth:`SecurityPolicy.freeze` records a SHA-256 digest of the
    policy's public fields; :meth:`SecurityPolicy.verify_frozen`
    recomputes the digest and raises this error on drift.

    Attributes:
        stored_digest: Digest recorded by ``freeze()``.
        actual_digest: Digest recomputed at verification time.
    """

    def __init__(
        self,
        message: str,
        *,
        stored_digest: str | None = None,
        actual_digest: str | None = None,
    ) -> None:
        self.stored_digest = stored_digest
        self.actual_digest = actual_digest
        super().__init__(message)


class PolicyViolation(Exception):
    """Raised when a policy check fails."""

    def __init__(
        self,
        message: str,
        violation_type: str,
        details: dict[str, Any] | None = None,
    ) -> None:
        self.message = message
        self.violation_type = violation_type
        self.details = details or {}
        super().__init__(message)


class ViolationType(str, Enum):
    """Types of policy violations."""

    TOOL_DENIED = "tool_denied"
    TOOL_NOT_ALLOWED = "tool_not_allowed"
    TIME_RESTRICTED = "time_restricted"
    RATE_LIMITED = "rate_limited"
    REAUTH_REQUIRED = "reauth_required"


@dataclass
class TimeWindow:
    """Represents a time window for restrictions.

    Format: "HH:MM-HH:MM" (24-hour format)
    Example: "09:00-17:00" means allowed between 9 AM and 5 PM
    """

    start_hour: int
    start_minute: int
    end_hour: int
    end_minute: int

    @classmethod
    def parse(cls, window_str: str) -> TimeWindow:
        """Parse a time window string.

        Args:
            window_str: Time window in "HH:MM-HH:MM" format.

        Returns:
            TimeWindow instance.

        Raises:
            ValueError: If format is invalid.
        """
        pattern = r"^(\d{2}):(\d{2})-(\d{2}):(\d{2})$"
        match = re.match(pattern, window_str)

        if not match:
            raise ValueError(
                f"Invalid time window format: '{window_str}'. "
                "Expected 'HH:MM-HH:MM' (e.g., '09:00-17:00')"
            )

        start_hour, start_minute, end_hour, end_minute = map(int, match.groups())

        # Validate ranges
        if not (0 <= start_hour <= 23 and 0 <= end_hour <= 23):
            raise ValueError("Hour must be between 00 and 23")
        if not (0 <= start_minute <= 59 and 0 <= end_minute <= 59):
            raise ValueError("Minute must be between 00 and 59")

        return cls(start_hour, start_minute, end_hour, end_minute)

    def is_within(self, dt: datetime | None = None) -> bool:
        """Check if a datetime is within this time window.

        Args:
            dt: Datetime to check. Defaults to now.

        Returns:
            True if within window, False otherwise.
        """
        dt = dt or datetime.now()
        current_minutes = dt.hour * 60 + dt.minute
        start_minutes = self.start_hour * 60 + self.start_minute
        end_minutes = self.end_hour * 60 + self.end_minute

        # Handle overnight windows (e.g., "22:00-06:00")
        if end_minutes < start_minutes:
            return current_minutes >= start_minutes or current_minutes <= end_minutes

        return start_minutes <= current_minutes <= end_minutes


@dataclass
class RateLimit:
    """Rate limit configuration using token bucket algorithm.

    Format: "count/period" where period is hour, minute, or second
    Examples: "100/hour", "10/minute", "1/second"
    """

    max_tokens: int
    refill_period_seconds: float
    tokens: float = field(default=0.0, repr=False)
    last_refill: float = field(default_factory=time.time, repr=False)
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def __post_init__(self) -> None:
        """Initialize tokens to max."""
        self.tokens = float(self.max_tokens)

    @classmethod
    def parse(cls, limit_str: str) -> RateLimit:
        """Parse a rate limit string.

        Args:
            limit_str: Rate limit in "count/period" format.

        Returns:
            RateLimit instance.

        Raises:
            ValueError: If format is invalid.
        """
        pattern = r"^(\d+)/(second|minute|hour|day)$"
        match = re.match(pattern, limit_str.lower())

        if not match:
            raise ValueError(
                f"Invalid rate limit format: '{limit_str}'. "
                "Expected 'count/period' (e.g., '100/hour', '10/minute')"
            )

        count = int(match.group(1))
        period = match.group(2)

        period_seconds = {
            "second": 1.0,
            "minute": 60.0,
            "hour": 3600.0,
            "day": 86400.0,
        }

        return cls(max_tokens=count, refill_period_seconds=period_seconds[period])

    def _refill(self) -> None:
        """Refill tokens based on elapsed time."""
        now = time.time()
        elapsed = now - self.last_refill

        # Calculate tokens to add
        tokens_to_add = (elapsed / self.refill_period_seconds) * self.max_tokens
        self.tokens = min(self.max_tokens, self.tokens + tokens_to_add)
        self.last_refill = now

    def acquire(self, tokens: int = 1) -> bool:
        """Try to acquire tokens.

        Args:
            tokens: Number of tokens to acquire.

        Returns:
            True if tokens acquired, False if rate limited.
        """
        with self._lock:
            self._refill()

            if self.tokens >= tokens:
                self.tokens -= tokens
                return True

            return False

    def remaining(self) -> int:
        """Get remaining tokens."""
        with self._lock:
            self._refill()
            return int(self.tokens)


@dataclass
class StdioGuardConfig:
    """Config for the Ox MCP STDIO sanitizer (v0.5.1+).

    Applied before any ``subprocess.Popen`` invocation driven by an MCP
    STDIO transport. Mitigates the Ox Security advisory class
    (CVE-2026-30616 and siblings) where MCP clients passed attacker-
    controlled argv straight to ``execve``. See
    ``agent_airlock.mcp_spec.stdio_guard.validate_stdio_command``.

    Attributes:
        allowed_binaries: argv[0] basename must be in this set unless
            the argv[0] starts with one of ``allowed_binary_prefixes``.
        allowed_binary_prefixes: absolute-path prefixes that bypass the
            basename allowlist (e.g. ``/usr/local/bin/``).
        deny_patterns: compiled regex list; an arg matching any is
            rejected. Applied after metachar check.
        allow_shell_metachars: if True, ``metachars`` is ignored.
            Default False — keep False unless you deliberately want to
            spawn a shell from your MCP transport (you don't).
        metachars: the shell metacharacter tokens that cause a reject.
    """

    allowed_binaries: frozenset[str] = field(default_factory=frozenset)
    allowed_binary_prefixes: tuple[str, ...] = ()
    deny_patterns: tuple[re.Pattern[str], ...] = ()
    allow_shell_metachars: bool = False
    metachars: tuple[str, ...] = (
        ";",
        "&&",
        "||",
        "|",
        "`",
        "$(",
        "$",
        "\n",
        "\r",
    )


@dataclass
class AgentIdentity:
    """Represents an AI agent's identity for policy enforcement.

    Attributes:
        agent_id: Unique identifier for the agent.
        session_id: Current session identifier.
        roles: List of roles assigned to this agent.
        metadata: Additional agent metadata.
    """

    agent_id: str
    session_id: str | None = None
    roles: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def has_role(self, role: str) -> bool:
        """Check if agent has a specific role."""
        return role in self.roles


@dataclass
class SecurityPolicy:
    """Security policy for tool access control.

    Example:
        policy = SecurityPolicy(
            allowed_tools=["read_file", "write_file"],
            denied_tools=["delete_database", "rm_*"],
            time_restrictions={"delete_*": "09:00-17:00"},
            rate_limits={"*": "100/hour", "expensive_*": "10/minute"},
        )

    Attributes:
        allowed_tools: List of allowed tool patterns. If empty, all tools allowed
                       (unless explicitly denied). Supports glob patterns.
        denied_tools: List of denied tool patterns. Takes precedence over allowed.
                      Supports glob patterns.
        time_restrictions: Dict mapping tool patterns to time windows.
                          Tools matching pattern only allowed during window.
        rate_limits: Dict mapping tool patterns to rate limit strings.
                     More specific patterns take precedence.
        require_agent_id: If True, reject calls without agent identity.
        allowed_roles: If set, agent must have at least one of these roles.
        capability_policy: V0.4.0 - Capability gating policy for per-tool permissions.
    """

    allowed_tools: list[str] = field(default_factory=list)
    denied_tools: list[str] = field(default_factory=list)
    time_restrictions: dict[str, str] = field(default_factory=dict)
    rate_limits: dict[str, str] = field(default_factory=dict)
    require_agent_id: bool = False
    allowed_roles: list[str] = field(default_factory=list)
    # V0.4.0 capability gating
    capability_policy: CapabilityPolicy | None = None
    # V0.8.6 debate-amplification guard (camouflage-resistant preset).
    # When True, any tool reinvocation past the threshold within a context
    # whose origin includes untrusted tool output requires a fresh
    # authorize_once() grant on the AirlockContext. Treats tool output that
    # re-enters the model as potentially camouflage-laden directives
    # (arXiv:2605.22001).
    reauth_on_untrusted_reinvocation: bool = False
    untrusted_reinvocation_threshold: int = 1
    # V0.8.6 deny-by-default allowlist. The classic SecurityPolicy
    # semantic treats an empty ``allowed_tools`` as "allow all" — kept
    # for backwards compatibility with PERMISSIVE_POLICY and existing
    # users. When ``default_deny=True``, an empty allowlist becomes
    # deny-all (camouflage-resistant posture).
    default_deny: bool = False
    # V0.5.7 STDIO subprocess execution mode. ``"allowlist"`` keeps the
    # v0.5.1 ``validate_stdio_command`` behaviour. ``"manifest_only"``
    # forces all spawns through ``launch_from_manifest`` (signed
    # registry; runtime cannot construct argv). ``"disabled"`` blocks
    # STDIO subprocesses entirely.
    stdio_mode: Literal["allowlist", "manifest_only", "disabled"] = "allowlist"
    # V0.8.7 per-model-tier cost budgets. When set, the @Airlock seam
    # runs a worst-case cost estimate against the resolved tier's cap
    # BEFORE execution (block over-budget calls with a structured
    # AirlockBudgetExceeded). Reconciliation of estimated vs actual cost
    # happens AFTER execution. Untagged calls fall back to the budget's
    # ``strict_tier`` (deny-by-default). The check is invoked from
    # ``core.py``'s ``_pre_execution`` rather than ``SecurityPolicy.check()``
    # because it needs runtime args (input token counts) that ``check()``
    # does not see.
    model_tier_budget: ModelTierBudget | None = None

    # Parsed/cached values
    _time_windows: dict[str, TimeWindow] = field(default_factory=dict, repr=False)
    _rate_limiters: dict[str, RateLimit] = field(default_factory=dict, repr=False)
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)
    # V0.5.5: SHA-256 digest recorded by freeze(); None means policy is mutable.
    _frozen_digest: str | None = field(default=None, repr=False)

    def __post_init__(self) -> None:
        """Parse time restrictions and rate limits."""
        # Parse time windows
        for pattern, window_str in self.time_restrictions.items():
            self._time_windows[pattern] = TimeWindow.parse(window_str)

        # Parse rate limits
        for pattern, limit_str in self.rate_limits.items():
            self._rate_limiters[pattern] = RateLimit.parse(limit_str)

    def _matches_pattern(self, tool_name: str, pattern: str) -> bool:
        """Check if tool name matches a glob pattern."""
        return fnmatch.fnmatch(tool_name, pattern)

    def _find_matching_patterns(self, tool_name: str, patterns: dict[str, Any]) -> list[str]:
        """Find all patterns that match a tool name, sorted by specificity."""
        matches = [p for p in patterns if self._matches_pattern(tool_name, p)]
        # Sort by specificity (longer patterns are more specific)
        # Patterns without wildcards are most specific
        return sorted(
            matches,
            key=lambda p: (p.count("*") == 0, len(p.replace("*", ""))),
            reverse=True,
        )

    def check_tool_allowed(self, tool_name: str) -> None:
        """Check if a tool is allowed by allow/deny lists.

        Args:
            tool_name: Name of the tool to check.

        Raises:
            PolicyViolation: If tool is denied or not in allowed list.
        """
        # Check denied list first (takes precedence)
        for pattern in self.denied_tools:
            if self._matches_pattern(tool_name, pattern):
                raise PolicyViolation(
                    f"Tool '{tool_name}' is denied by policy (matches '{pattern}')",
                    violation_type=ViolationType.TOOL_DENIED.value,
                    details={"tool": tool_name, "pattern": pattern},
                )

        # Check allowed list. With default_deny=True (camouflage-resistant
        # posture), an empty allowlist is deny-all. Without it, an empty
        # allowlist preserves the legacy "allow all" semantic.
        if self.allowed_tools or self.default_deny:
            allowed = any(
                self._matches_pattern(tool_name, pattern) for pattern in self.allowed_tools
            )
            if not allowed:
                raise PolicyViolation(
                    f"Tool '{tool_name}' is not in allowed tools list",
                    violation_type=ViolationType.TOOL_NOT_ALLOWED.value,
                    details={"tool": tool_name, "allowed": self.allowed_tools},
                )

    def check_time_restriction(self, tool_name: str, dt: datetime | None = None) -> None:
        """Check if a tool call is within allowed time window.

        Args:
            tool_name: Name of the tool to check.
            dt: Datetime to check against. Defaults to now.

        Raises:
            PolicyViolation: If outside allowed time window.
        """
        matching_patterns = self._find_matching_patterns(tool_name, self._time_windows)

        if not matching_patterns:
            return  # No time restriction applies

        # Use most specific matching pattern
        pattern = matching_patterns[0]
        window = self._time_windows[pattern]

        if not window.is_within(dt):
            dt = dt or datetime.now()
            raise PolicyViolation(
                f"Tool '{tool_name}' is time-restricted. "
                f"Allowed: {self.time_restrictions[pattern]}, "
                f"Current: {dt.strftime('%H:%M')}",
                violation_type=ViolationType.TIME_RESTRICTED.value,
                details={
                    "tool": tool_name,
                    "pattern": pattern,
                    "allowed_window": self.time_restrictions[pattern],
                    "current_time": dt.strftime("%H:%M"),
                },
            )

    def check_rate_limit(self, tool_name: str) -> None:
        """Check if a tool call is within rate limits.

        Args:
            tool_name: Name of the tool to check.

        Raises:
            PolicyViolation: If rate limit exceeded.
        """
        matching_patterns = self._find_matching_patterns(tool_name, self._rate_limiters)

        if not matching_patterns:
            return  # No rate limit applies

        # Use most specific matching pattern
        pattern = matching_patterns[0]
        limiter = self._rate_limiters[pattern]

        if not limiter.acquire():
            raise PolicyViolation(
                f"Rate limit exceeded for tool '{tool_name}'. Limit: {self.rate_limits[pattern]}",
                violation_type=ViolationType.RATE_LIMITED.value,
                details={
                    "tool": tool_name,
                    "pattern": pattern,
                    "limit": self.rate_limits[pattern],
                    "remaining": limiter.remaining(),
                },
            )

    def check_agent_identity(self, agent: AgentIdentity | None) -> None:
        """Check if agent identity meets policy requirements.

        Args:
            agent: Agent identity to check.

        Raises:
            PolicyViolation: If agent identity requirements not met.
        """
        if self.require_agent_id and agent is None:
            raise PolicyViolation(
                "Agent identity required but not provided",
                violation_type="agent_required",
                details={},
            )

        if agent and self.allowed_roles:
            has_allowed_role = any(agent.has_role(role) for role in self.allowed_roles)
            if not has_allowed_role:
                raise PolicyViolation(
                    f"Agent does not have required role. "
                    f"Required: one of {self.allowed_roles}, "
                    f"Agent roles: {agent.roles}",
                    violation_type="role_required",
                    details={
                        "required_roles": self.allowed_roles,
                        "agent_roles": agent.roles,
                    },
                )

    def check_reauthorization(
        self,
        tool_name: str,
        context: Any | None,
    ) -> None:
        """V0.8.6 debate-amplification guard.

        When ``reauth_on_untrusted_reinvocation`` is True, this method
        blocks any tool reinvocation past ``untrusted_reinvocation_threshold``
        unless the calling harness has issued ``context.authorize_once(tool_name)``
        on the current ``AirlockContext`` since the last untrusted-marked
        tool output. Threat model: arXiv:2605.22001 ("Blind Spots in the
        Guard", Pai 2026) found Llama Guard 3 IDR drops to 0.000 on
        domain-camouflaged payloads, so any tool output flowing back into
        the model context can carry an undetectable directive that
        amplifies across sub-agents on reinvocation.

        Args:
            tool_name: Tool being invoked.
            context: AirlockContext for the current call (or None — no-op).

        Raises:
            PolicyViolation: If reauthorization is required but not granted.
        """
        if not self.reauth_on_untrusted_reinvocation:
            return
        if context is None:
            return
        # Duck-typed: avoid a hard import cycle with context.py
        counts: dict[str, int] = getattr(context, "untrusted_reinvocation_count", {})
        authorized: set[str] = getattr(context, "_authorized_once", set())
        prior = counts.get(tool_name, 0)
        if prior < self.untrusted_reinvocation_threshold:
            return
        if tool_name in authorized:
            # Consume the one-shot grant
            authorized.discard(tool_name)
            return
        raise PolicyViolation(
            (
                f"Tool '{tool_name}' reinvocation requires re-authorization "
                f"(camouflage-resistant guard: {prior} prior call(s), "
                f"threshold {self.untrusted_reinvocation_threshold}). "
                "Call context.authorize_once(tool_name) to grant one more invocation. "
                "Rationale: tool output may carry a domain-camouflaged directive "
                "(arXiv:2605.22001)."
            ),
            violation_type=ViolationType.REAUTH_REQUIRED.value,
            details={
                "tool": tool_name,
                "prior_invocations": prior,
                "threshold": self.untrusted_reinvocation_threshold,
            },
        )

    def check(
        self,
        tool_name: str,
        agent: AgentIdentity | None = None,
        dt: datetime | None = None,
    ) -> None:
        """Run all policy checks for a tool call.

        Args:
            tool_name: Name of the tool to check.
            agent: Agent identity (optional).
            dt: Datetime for time checks (defaults to now).

        Raises:
            PolicyViolation: If any policy check fails.
        """
        logger.debug(
            "policy_check",
            tool=tool_name,
            agent_id=agent.agent_id if agent else None,
        )

        # Check agent identity
        self.check_agent_identity(agent)

        # Check allow/deny lists
        self.check_tool_allowed(tool_name)

        # Check time restrictions
        self.check_time_restriction(tool_name, dt)

        # Check rate limits
        self.check_rate_limit(tool_name)

        logger.debug("policy_check_passed", tool=tool_name)

    # -- v0.8.7 per-model-tier cost budget --

    def check_model_tier_budget(
        self,
        *,
        tier_label: str | None,
        input_tokens: int,
        cost_tracker: CostTracker,
        model_id: str | None = None,
    ) -> BudgetEstimate | None:
        """Run the per-model-tier budget pre-execute check.

        No-op when ``model_tier_budget`` is None. When set, resolves the
        tier (caller-supplied ``tier_label`` wins; otherwise the budget's
        ``tier_resolver`` is tried with ``model_id``; otherwise the
        budget's ``strict_tier`` is used) and runs the worst-case cost
        estimate. Raises :class:`AirlockBudgetExceeded` on cap breach.

        Args:
            tier_label: Explicit tier label (e.g. from a router-supplied
                ``_airlock_tier`` kwarg). May be None — the budget will
                fall back via resolver or to ``strict_tier``.
            input_tokens: Caller's best estimate of input tokens for the
                call. Pass 0 if unknown.
            cost_tracker: Cost tracker carrying the pricing table.
            model_id: Optional model identifier, surfaced in telemetry
                and threaded to the resolver.

        Returns:
            The :class:`BudgetEstimate` to thread into post-execute
            reconciliation, or None when no budget is configured.

        Raises:
            AirlockBudgetExceeded: If the worst-case estimate exceeds
                the resolved tier's cap.
            UnknownTierError: If ``tier_label`` is explicitly supplied
                but not a configured tier.
        """
        if self.model_tier_budget is None:
            return None
        resolved = self.model_tier_budget.resolve_tier(
            explicit=tier_label,
            model_id=model_id,
        )
        return self.model_tier_budget.check_pre_execute(
            tier_label=resolved,
            input_tokens=input_tokens,
            cost_tracker=cost_tracker,
            model_id=model_id,
        )

    # -- v0.5.5 policy freezing (CVE-2026-41349 consent-bypass guard) --

    def _canonical_bytes(self) -> bytes:
        """Serialize the public fields into stable bytes for digesting.

        Internal caches (``_time_windows``, ``_rate_limiters``, ``_lock``,
        ``_frozen_digest``) are deliberately excluded so the digest only
        covers user-visible configuration. A ``CapabilityPolicy`` is
        reduced to the integer values of its three ``Capability`` flags.
        A :class:`ModelTierBudget` is serialized via its
        ``canonical_payload()`` (tier_resolver callback is reduced to a
        boolean — callable identity is non-deterministic across processes
        and ``freeze()`` covers config, not behavior).
        """
        cap = self.capability_policy
        cap_tuple: tuple[int, int, int] | None = None
        if cap is not None:
            cap_tuple = (
                int(cap.granted.value),
                int(cap.denied.value),
                int(cap.require_sandbox_for.value),
            )
        tier_budget_payload = (
            self.model_tier_budget.canonical_payload()
            if self.model_tier_budget is not None
            else None
        )
        payload = {
            "allowed_tools": sorted(self.allowed_tools),
            "denied_tools": sorted(self.denied_tools),
            "time_restrictions": dict(sorted(self.time_restrictions.items())),
            "rate_limits": dict(sorted(self.rate_limits.items())),
            "require_agent_id": self.require_agent_id,
            "allowed_roles": sorted(self.allowed_roles),
            "capability_policy": cap_tuple,
            "reauth_on_untrusted_reinvocation": self.reauth_on_untrusted_reinvocation,
            "untrusted_reinvocation_threshold": self.untrusted_reinvocation_threshold,
            "default_deny": self.default_deny,
            "model_tier_budget": tier_budget_payload,
        }
        return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")

    def _compute_policy_digest(self) -> str:
        """Return the canonical SHA-256 hex digest of this policy's public fields."""
        return hashlib.sha256(self._canonical_bytes()).hexdigest()

    def freeze(self) -> SecurityPolicy:
        """Return a frozen copy of this policy with a SHA-256 digest.

        The returned instance will refuse :meth:`verify_frozen` checks
        after any mutation of ``allowed_tools`` / ``denied_tools`` /
        ``time_restrictions`` / ``rate_limits`` / ``require_agent_id``
        / ``allowed_roles`` / ``capability_policy``. The original
        instance is left unchanged.

        Note: ``threading.Lock`` can't be deep-copied, so this method
        rebuilds the ``SecurityPolicy`` from the public fields (which
        is all the digest cares about) and gets a fresh lock / cache
        for free via ``__post_init__``.

        Idempotent: calling ``freeze()`` on an already-frozen policy
        returns another fresh copy with the same canonical digest
        (since the digest is excluded from the canonical-bytes payload).
        """
        frozen = SecurityPolicy(
            allowed_tools=list(self.allowed_tools),
            denied_tools=list(self.denied_tools),
            time_restrictions=copy.deepcopy(self.time_restrictions),
            rate_limits=copy.deepcopy(self.rate_limits),
            require_agent_id=self.require_agent_id,
            allowed_roles=list(self.allowed_roles),
            capability_policy=self.capability_policy,
            reauth_on_untrusted_reinvocation=self.reauth_on_untrusted_reinvocation,
            untrusted_reinvocation_threshold=self.untrusted_reinvocation_threshold,
            default_deny=self.default_deny,
            model_tier_budget=self.model_tier_budget,
        )
        frozen._frozen_digest = frozen._compute_policy_digest()
        return frozen

    def is_frozen(self) -> bool:
        """Whether this policy was produced by :meth:`freeze`."""
        return self._frozen_digest is not None

    def verify_frozen(self, digest: str | None = None) -> None:
        """Raise :class:`PolicyMutationError` if the policy has drifted.

        Args:
            digest: Optional expected digest. If omitted, the digest
                stored on ``freeze()`` is used. Callers that want
                end-to-end custody (freeze in one process, verify in
                another) should pass the explicit value.

        Raises:
            PolicyMutationError: If the policy has not been frozen
                or if the stored / supplied digest does not match
                the recomputed digest of the current public fields.
        """
        if self._frozen_digest is None:
            raise PolicyMutationError(
                "SecurityPolicy.verify_frozen() called on an unfrozen policy — "
                "call freeze() first to lock the digest",
                stored_digest=None,
                actual_digest=None,
            )
        expected = digest if digest is not None else self._frozen_digest
        actual = self._compute_policy_digest()
        if actual != expected:
            raise PolicyMutationError(
                "SecurityPolicy has been mutated after freeze() — "
                f"expected digest {expected!r}, got {actual!r} "
                "(CVE-2026-41349 consent-bypass guard)",
                stored_digest=expected,
                actual_digest=actual,
            )


# Predefined policies for common use cases


PERMISSIVE_POLICY = SecurityPolicy()
"""Allows all tools with no restrictions."""


def _get_strict_capability_policy() -> CapabilityPolicy | None:
    """Lazy import capability policy for STRICT_POLICY."""
    try:
        from .capabilities import Capability, CapabilityPolicy

        return CapabilityPolicy(
            granted=Capability.FILESYSTEM_READ
            | Capability.NETWORK_HTTPS
            | Capability.DATABASE_READ,
            denied=Capability.PROCESS_SHELL | Capability.FILESYSTEM_DELETE,
            require_sandbox_for=Capability.DANGEROUS,
        )
    except ImportError:
        return None


def _get_read_only_capability_policy() -> CapabilityPolicy | None:
    """Lazy import capability policy for READ_ONLY_POLICY."""
    try:
        from .capabilities import Capability, CapabilityPolicy

        return CapabilityPolicy(
            granted=Capability.FILESYSTEM_READ
            | Capability.DATABASE_READ
            | Capability.NETWORK_HTTPS,
            denied=Capability.FILESYSTEM_WRITE
            | Capability.FILESYSTEM_DELETE
            | Capability.DATABASE_WRITE,
            require_sandbox_for=Capability.PROCESS_EXEC | Capability.PROCESS_SHELL,
        )
    except ImportError:
        return None


STRICT_POLICY = SecurityPolicy(
    require_agent_id=True,
    rate_limits={"*": "100/hour"},
    capability_policy=_get_strict_capability_policy(),
)
"""Requires agent identity, applies global rate limit, and enforces strict capabilities.

V0.4.0: Adds capability policy that:
- Grants: FILESYSTEM_READ, NETWORK_HTTPS, DATABASE_READ
- Denies: PROCESS_SHELL, FILESYSTEM_DELETE
- Requires sandbox for: DANGEROUS operations
"""


READ_ONLY_POLICY = SecurityPolicy(
    allowed_tools=["read_*", "get_*", "list_*", "search_*"],
    denied_tools=["write_*", "delete_*", "update_*", "create_*"],
    capability_policy=_get_read_only_capability_policy(),
)
"""Only allows read operations with matching capability policy.

V0.4.0: Adds capability policy that denies write/delete capabilities.
"""


BUSINESS_HOURS_POLICY = SecurityPolicy(
    time_restrictions={
        "delete_*": "09:00-17:00",
        "drop_*": "09:00-17:00",
        "*_production": "09:00-17:00",
    },
)
"""Restricts dangerous operations to business hours."""


def _get_camouflage_resistant_capability_policy() -> CapabilityPolicy | None:
    """Lazy capability policy for CAMOUFLAGE_RESISTANT_POLICY.

    Denies the long tail of dangerous capabilities outright; granted set
    is empty so the caller must opt in per deployment.
    """
    try:
        from .capabilities import Capability, CapabilityPolicy

        return CapabilityPolicy(
            granted=Capability(0),
            denied=Capability.PROCESS_SHELL
            | Capability.PROCESS_EXEC
            | Capability.FILESYSTEM_DELETE
            | Capability.FILESYSTEM_WRITE,
            require_sandbox_for=Capability.DANGEROUS,
        )
    except ImportError:
        return None


CAMOUFLAGE_RESISTANT_POLICY = SecurityPolicy(
    allowed_tools=[],
    require_agent_id=True,
    capability_policy=_get_camouflage_resistant_capability_policy(),
    reauth_on_untrusted_reinvocation=True,
    untrusted_reinvocation_threshold=1,
    default_deny=True,
)
"""V0.8.6 preset: detector-independent defense against camouflaged prompt injection.

Targets the failure mode documented in arXiv:2605.22001 ("Blind Spots in
the Guard", Pai 2026): production detectors including Llama Guard 3 drop
to IDR=0.000 on domain-camouflaged injection payloads. Rather than rely
on payload-content signatures, this preset denies-by-default at every
seam an attacker would need to ride:

- Empty ``allowed_tools`` — caller MUST opt every tool in by name; no
  glob shortcuts. A camouflaged directive targeting an unregistered
  tool is blocked on allowlist grounds regardless of detector score.
- ``require_agent_id=True`` — calls without an attributable agent are
  rejected before any content scan.
- Dangerous capabilities (process exec/shell, filesystem write/delete)
  are denied; ``DANGEROUS`` requires sandbox.
- ``reauth_on_untrusted_reinvocation=True`` with threshold 1 — once a
  tool has run once and its output has flowed into the model context,
  any reinvocation requires an explicit ``context.authorize_once(tool)``
  grant from the harness. This breaks the multi-agent debate
  amplification path: a camouflaged directive embedded in tool output
  cannot fan out into repeated downstream invocations.

This preset is intentionally incomplete on its own: ``AirlockConfig``
also needs ``unknown_args=UnknownArgsMode.BLOCK``, ``sanitize_output=True``,
and a tight ``max_output_chars``. Use ``apply_camouflage_resistant()``
from :mod:`agent_airlock.camouflage_resistant` to compose both.
"""
