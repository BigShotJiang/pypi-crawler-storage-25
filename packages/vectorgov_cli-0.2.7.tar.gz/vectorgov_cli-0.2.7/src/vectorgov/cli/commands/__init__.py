"""
Comandos do CLI VectorGov.
"""

from . import auth, search, ask, feedback, docs, config, tokens
from . import smart_search, hybrid, lookup, grep_cmd, merged, audit, quota, prompts
from . import context, init

__all__ = [
    "auth",
    "search",
    "ask",
    "feedback",
    "docs",
    "config",
    "tokens",
    "smart_search",
    "hybrid",
    "lookup",
    "grep_cmd",
    "merged",
    "audit",
    "quota",
    "prompts",
    "context",
    "init",
]
