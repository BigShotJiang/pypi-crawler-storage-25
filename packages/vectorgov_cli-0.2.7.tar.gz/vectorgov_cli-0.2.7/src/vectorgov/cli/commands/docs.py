"""
Comando de documentos do CLI VectorGov.
"""

import json
import typer
from rich.console import Console
from rich.table import Table

from ..utils.config import ConfigManager

app = typer.Typer(no_args_is_help=True)
console = Console()
config_manager = ConfigManager()


@app.command("list")
def list_docs(
    page: int = typer.Option(1, "--page", "-p", help="Página (1+)"),
    limit: int = typer.Option(50, "--limit", "-l", help="Itens por página (1-100)"),
    output: str = typer.Option("table", "--output", "-o", help="Formato: table, json"),
):
    """
    Lista documentos disponíveis na base.

    Exemplos:
        vectorgov docs list
        vectorgov docs list --page 2 --limit 20
        vectorgov docs list --output json
    """
    # Obtém API key
    api_key = config_manager.get("api_key")
    if not api_key:
        console.print("[red]Erro:[/red] API key não configurada.")
        console.print("  Use 'vectorgov auth login' para configurar.")
        raise typer.Exit(1)

    if page < 1:
        console.print("[red]Erro:[/red] --page deve ser >= 1.")
        raise typer.Exit(1)
    if limit < 1 or limit > 100:
        console.print("[red]Erro:[/red] --limit deve estar entre 1 e 100.")
        raise typer.Exit(1)

    try:
        from vectorgov import VectorGov

        vg = VectorGov(api_key=api_key)
        resp = vg.list_documents(page=page, limit=limit)
        # SDK v0.16 retorna DocumentsResponse com atributo .documents
        doc_list = getattr(resp, "documents", resp) or []

        if output == "json":
            data = [
                {
                    "id": getattr(d, "document_id", getattr(d, "id", "")),
                    "title": getattr(d, "titulo", getattr(d, "title", "")),
                    "type": getattr(d, "tipo_documento", getattr(d, "type", "")),
                    "year": getattr(d, "ano", getattr(d, "year", "")),
                    "chunks": getattr(d, "chunks_count", 0),
                }
                for d in doc_list
            ]
            console.print_json(json.dumps(data, ensure_ascii=False))
        else:
            table = Table(title="Documentos Disponíveis")
            table.add_column("ID", style="cyan")
            table.add_column("Título")
            table.add_column("Tipo", style="green")
            table.add_column("Ano", justify="right")
            table.add_column("Chunks", justify="right")

            for d in doc_list:
                doc_id = getattr(d, "document_id", getattr(d, "id", ""))
                titulo = getattr(d, "titulo", getattr(d, "title", "")) or ""
                tipo = getattr(d, "tipo_documento", getattr(d, "type", ""))
                ano = getattr(d, "ano", getattr(d, "year", ""))
                chunks = getattr(d, "chunks_count", 0)
                table.add_row(
                    str(doc_id),
                    titulo[:50] + "..." if len(str(titulo)) > 50 else str(titulo),
                    str(tipo),
                    str(ano),
                    str(chunks),
                )

            console.print(table)
            total = getattr(resp, "total", len(doc_list))
            pages = getattr(resp, "pages", 1)
            console.print(
                f"\nPágina [cyan]{page}[/cyan]/[cyan]{pages}[/cyan]  "
                f"•  Total na base: [cyan]{total}[/cyan] documentos  "
                f"•  Mostrando: [cyan]{len(doc_list)}[/cyan]"
            )

    except Exception as e:
        console.print(f"[red]Erro:[/red] {e}")
        raise typer.Exit(1)


@app.command("info")
def doc_info(
    document_id: str = typer.Argument(..., help="ID do documento"),
):
    """
    Mostra informações detalhadas de um documento.

    Exemplos:
        vectorgov docs info LEI-14133-2021
        vectorgov docs info IN-58-2022
    """
    # Obtém API key
    api_key = config_manager.get("api_key")
    if not api_key:
        console.print("[red]Erro:[/red] API key não configurada.")
        console.print("  Use 'vectorgov auth login' para configurar.")
        raise typer.Exit(1)

    try:
        from vectorgov import VectorGov

        vg = VectorGov(api_key=api_key)

        doc = None
        try:
            doc = vg.get_document(document_id)
        except Exception:
            # Fallback: try to find the document in list_documents (e.g. 404)
            try:
                all_docs = vg.list_documents()
                for d in all_docs:
                    d_id = getattr(d, "document_id", getattr(d, "id", ""))
                    if str(d_id) == document_id:
                        doc = d
                        break
            except Exception:
                pass

        if doc is None:
            console.print(f"[red]Erro:[/red] Documento '{document_id}' não encontrado.")
            raise typer.Exit(1)

        titulo = getattr(doc, "titulo", getattr(doc, "title", ""))
        doc_id = getattr(doc, "document_id", getattr(doc, "id", ""))
        tipo = getattr(doc, "tipo_documento", getattr(doc, "type", ""))
        ano = getattr(doc, "ano", getattr(doc, "year", ""))
        chunks = getattr(doc, "chunks_count", 0)

        console.print(f"\n[bold]{titulo}[/bold]")
        console.print(f"ID: [cyan]{doc_id}[/cyan]")
        console.print(f"Tipo: [green]{tipo}[/green]")
        console.print(f"Ano: {ano}")
        console.print(f"Chunks: {chunks}")

        if hasattr(doc, 'description') and doc.description:
            console.print(f"\nDescrição: {doc.description}")

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Erro:[/red] {e}")
        raise typer.Exit(1)
