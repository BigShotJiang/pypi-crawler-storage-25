"""System prompts prontos para usar com LLMs externos."""

import typer
from rich.console import Console
from rich.panel import Panel
from ..utils.config import ConfigManager

app = typer.Typer(no_args_is_help=True)
console = Console()
config_manager = ConfigManager()


@app.command("list")
def list_prompts():
    """Lista os estilos de system prompt disponíveis.

    Exemplo:
        vectorgov prompts list
    """
    try:
        from vectorgov import VectorGov

        api_key = config_manager.get("api_key")
        if not api_key:
            console.print("[red]Erro:[/red] API key não configurada.")
            console.print("  Use [cyan]vectorgov auth login[/cyan] para configurar.")
            raise typer.Exit(1)

        vg = VectorGov(api_key=api_key)

        styles = vg.available_prompts

        console.print("\n[bold]System Prompts Disponíveis[/bold]\n")
        for style in styles:
            console.print(f"  [cyan]•[/cyan] {style}")
        console.print(f"\n[dim]Use 'vectorgov prompts show <estilo>' para ver o prompt completo.[/dim]")

    except Exception as e:
        console.print(f"[red]Erro:[/red] {e}")
        raise typer.Exit(1)


@app.command("show")
def show_prompt(
    style: str = typer.Argument(..., help="Estilo do prompt (ex: 'juridico', 'tecnico')"),
    raw: bool = typer.Option(False, "--raw", help="Texto puro para copiar/colar"),
):
    """Exibe um system prompt completo para usar com LLMs.

    Copie e use como system prompt no ChatGPT, Claude, Gemini, etc.

    Exemplo:
        vectorgov prompts show juridico
        vectorgov prompts show tecnico --raw
    """
    try:
        from vectorgov import VectorGov

        api_key = config_manager.get("api_key")
        if not api_key:
            console.print("[red]Erro:[/red] API key não configurada.")
            console.print("  Use [cyan]vectorgov auth login[/cyan] para configurar.")
            raise typer.Exit(1)

        vg = VectorGov(api_key=api_key)

        prompt_text = vg.get_system_prompt(style=style)

        if raw:
            print(prompt_text)
        else:
            console.print(Panel(prompt_text, title=f"System Prompt: {style}", border_style="cyan"))
            console.print(f"\n[dim]Dica: use --raw para copiar o texto sem formatação.[/dim]")

    except Exception as e:
        console.print(f"[red]Erro:[/red] {e}")
        raise typer.Exit(1)
