"""Busca no índice curado (filesystem search)."""

import json
import typer
from rich.console import Console
from rich.table import Table
from ..utils.config import ConfigManager
from ..utils.output import get_evidence_links, render_evidence_lines_text, render_llm_output, resolve_output_format

app = typer.Typer()
console = Console()
config_manager = ConfigManager()


@app.callback(invoke_without_command=True)
def fs_search(
    query: str = typer.Argument(..., help="Pergunta ou termo para buscar"),
    document_id: str = typer.Option(None, "--doc", "-d", help="Filtrar por documento (ex: LEI-14133-2021)"),
    top_k: int = typer.Option(10, "--top-k", "-k", help="Quantidade de resultados (1-50)"),
    mode: str = typer.Option("auto", "--mode", "-m", help="Modo: auto, index, grep, both"),
    output: str = typer.Option("table", "--output", "-o", help="Formato: table, json, text, llm"),
    raw: bool = typer.Option(False, "--raw", help="JSON bruto para piping"),
):
    """Busca no índice curado do filesystem.

    Diferente de 'search' (vetorial), busca por termos exatos no índice curado.
    Combina busca indexada (aliases, termos) com busca textual (texto canônico).

    Exemplo:
        vectorgov fs-search "art. 75 da Lei 14.133"
        vectorgov fs-search "pregão eletrônico" --mode index
        vectorgov fs-search "dispensa" --doc LEI-14.133-2021 --output json
    """
    try:
        from vectorgov import VectorGov

        api_key = config_manager.get("api_key")
        if not api_key:
            console.print("[red]Erro:[/red] API key nao configurada.")
            console.print("  Use [cyan]vectorgov auth login[/cyan] para configurar.")
            raise typer.Exit(1)

        if top_k < 1 or top_k > 50:
            console.print("[red]Erro:[/red] --top-k deve estar entre 1 e 50.")
            raise typer.Exit(1)

        if mode not in ("auto", "index", "grep", "both"):
            console.print("[red]Erro:[/red] --mode deve ser: auto, index, grep ou both.")
            raise typer.Exit(1)

        effective_output = resolve_output_format(output, is_raw=raw)

        vg = VectorGov(api_key=api_key)

        with console.status("[bold]Buscando no indice curado...[/bold]"):
            result = vg.filesystem_search(
                query=query,
                document_id=document_id or None,
                mode=mode,
                top_k=top_k,
            )

        hits = getattr(result, "results", [])
        if not isinstance(hits, list):
            hits = []

        if effective_output == "raw":
            data = {
                "query": query,
                "total": len(hits),
                "mode_used": getattr(result, "mode_used", mode),
                "latency_ms": getattr(result, "latency_ms", None),
                "hits": [
                    {
                        "node_id": getattr(h, "node_id", ""),
                        "document_id": getattr(h, "document_id", ""),
                        "span_id": getattr(h, "span_id", ""),
                        "text": getattr(h, "text", str(h)),
                        "score": getattr(h, "score", 0),
                        "source": getattr(h, "source", ""),
                        "breadcrumb": getattr(h, "breadcrumb", ""),
                        "match_reason": getattr(h, "match_reason", ""),
                        **get_evidence_links(h),
                    }
                    for h in hits
                ],
            }
            print(json.dumps(data, ensure_ascii=False, indent=2))
            return

        if effective_output == "llm":
            metadata = {"total": len(hits), "latency_ms": getattr(result, "latency_ms", None), "query_id": getattr(result, "query_id", None)}
            print(render_llm_output(hits, query, metadata))
            return

        if not hits:
            console.print("[yellow]Nenhum resultado encontrado.[/yellow]")
            raise typer.Exit(0)

        if output == "json":
            data = [
                {
                    "source": getattr(h, "source", ""),
                    "score": getattr(h, "score", 0),
                    "text": getattr(h, "text", str(h))[:300],
                    "breadcrumb": getattr(h, "breadcrumb", ""),
                }
                for h in hits
            ]
            console.print_json(json.dumps(data, ensure_ascii=False))
        elif output == "table":
            table = Table(title=f"Filesystem Search ({len(hits)} resultados)")
            table.add_column("#", style="dim", width=3)
            table.add_column("Fonte", style="cyan", width=30)
            table.add_column("Texto", width=65)
            table.add_column("Score", justify="right", width=6)
            table.add_column("Motivo", width=10)
            for i, h in enumerate(hits, 1):
                source = getattr(h, "source", getattr(h, "document_id", ""))
                score = getattr(h, "score", 0)
                text = getattr(h, "text", str(h))
                text = text[:160] + "..." if len(text) > 160 else text
                reason = getattr(h, "match_reason", "")
                table.add_row(
                    str(i), source, text, f"{score:.2f}" if score else "-", reason[:10]
                )
            console.print(table)
        else:
            for i, h in enumerate(hits, 1):
                source = getattr(h, "source", getattr(h, "document_id", ""))
                breadcrumb = getattr(h, "breadcrumb", "")
                console.print(f"\n[cyan][{i}][/cyan] [bold]{source}[/bold]")
                if breadcrumb:
                    console.print(f"  [dim]{breadcrumb}[/dim]")
                console.print(f"  {getattr(h, 'text', str(h))[:300]}")
                for line in render_evidence_lines_text(h):
                    console.print(f"[dim]{line}[/dim]")

        query_id = getattr(result, "query_id", None)
        if query_id:
            console.print(f"\n[dim]query_id: {query_id}[/dim]")

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Erro:[/red] {e}")
        raise typer.Exit(1)
