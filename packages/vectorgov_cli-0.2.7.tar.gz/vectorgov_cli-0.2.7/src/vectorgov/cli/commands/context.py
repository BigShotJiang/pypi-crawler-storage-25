"""Gera contexto completo pronto para usar com LLMs (busca + system prompt)."""

import json

import typer
from rich.console import Console

from ..utils.config import ConfigManager

app = typer.Typer()
console = Console()
config_manager = ConfigManager()


@app.callback(invoke_without_command=True)
def context(
    query: str = typer.Argument(..., help="Pergunta jurídica"),
    top_k: int = typer.Option(5, "--top-k", "-k", help="Quantidade de resultados (1-20)"),
    mode: str = typer.Option(
        "balanced", "--mode", "-m", help="Modo: fast, balanced, precise"
    ),
    prompt_style: str = typer.Option(
        "default", "--prompt", "-p", help="Estilo do system prompt"
    ),
    format: str = typer.Option(
        "raw", "--format", "-f",
        help="Formato: raw (texto puro), messages (JSON OpenAI-compatible), clipboard"
    ),
    smart: bool = typer.Option(
        False, "--smart", help="Usar smart_search (mais lento, mais preciso)"
    ),
):
    """Gera bloco de contexto completo para colar em qualquer LLM.

    Combina busca + system prompt + formatação em um único passo.
    Ideal para vibe coding: o AI chama este comando e recebe tudo pronto.

    Exemplos:
        vectorgov context "Quando posso usar dispensa de licitação?"
        vectorgov context "ETP" --mode precise --top-k 10
        vectorgov context "Art. 75" --format messages
        vectorgov context "pregão eletrônico" --smart
        vectorgov context "pesquisa de preços" --prompt detailed
    """
    try:
        from vectorgov import VectorGov

        api_key = config_manager.get("api_key")
        if not api_key:
            console.print("[red]Erro:[/red] API key não configurada.")
            console.print("  Use [cyan]vectorgov auth login[/cyan] para configurar.")
            raise typer.Exit(1)

        if top_k < 1 or top_k > 20:
            console.print("[red]Erro:[/red] --top-k deve estar entre 1 e 20.")
            raise typer.Exit(1)

        vg = VectorGov(api_key=api_key)

        # Busca
        if smart:
            with console.status(
                "[bold]Executando smart_search (pode levar até 60s)...[/bold]",
                spinner="dots",
            ):
                result = vg.smart_search(query=query)

            # Smart search: montar contexto manualmente
            system_prompt = vg.get_system_prompt(style=prompt_style)
            context_parts = [f"=== ANÁLISE DE COMPLETUDE ==="]
            context_parts.append(f"Confiança: {result.confianca}")
            if result.raciocinio:
                context_parts.append(f"Raciocínio: {result.raciocinio}")
            context_parts.append("")
            context_parts.append("=== EVIDÊNCIAS ===")
            for i, h in enumerate(result.hits, 1):
                source = getattr(h, "source", getattr(h, "document_id", ""))
                context_parts.append(f"\n[{i}] {source}")
                context_parts.append(h.text)

            context_text = "\n".join(context_parts)

            if format == "messages":
                messages = [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": f"Contexto:\n{context_text}\n\nPergunta: {query}"},
                ]
                print(json.dumps(messages, ensure_ascii=False, indent=2))
            elif format == "clipboard":
                block = f"--- SYSTEM PROMPT ---\n{system_prompt}\n\n--- CONTEXTO ---\n{context_text}\n\n--- PERGUNTA ---\n{query}"
                print(block)
                console.print("\n[green]Bloco pronto para colar no LLM.[/green]")
            else:  # raw
                block = f"{system_prompt}\n\n---\n\n{context_text}\n\n---\nPergunta: {query}"
                print(block)

        else:
            with console.status("[bold]Buscando contexto...[/bold]", spinner="dots"):
                results = vg.search(query, top_k=top_k, mode=mode)

            if format == "messages":
                system_prompt = vg.get_system_prompt(style=prompt_style)
                messages = results.to_messages(query, system_prompt=system_prompt)
                print(json.dumps(messages, ensure_ascii=False, indent=2))

            elif format == "clipboard":
                system_prompt = vg.get_system_prompt(style=prompt_style)
                context_text = results.to_context()
                block = f"--- SYSTEM PROMPT ---\n{system_prompt}\n\n--- CONTEXTO ---\n{context_text}\n\n--- PERGUNTA ---\n{query}"
                print(block)
                console.print("\n[green]Bloco pronto para colar no LLM.[/green]")

            else:  # raw
                system_prompt = vg.get_system_prompt(style=prompt_style)
                context_text = results.to_context()
                block = f"{system_prompt}\n\n---\n\n{context_text}\n\n---\nPergunta: {query}"
                print(block)

    except Exception as e:
        console.print(f"[red]Erro:[/red] {e}")
        raise typer.Exit(1)
