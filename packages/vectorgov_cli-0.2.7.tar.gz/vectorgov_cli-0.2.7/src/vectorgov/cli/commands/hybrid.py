"""Busca híbrida com expansão por grafo normativo."""

import json
import typer
from rich.console import Console
from rich.table import Table
from ..utils.config import ConfigManager
from ..utils.output import get_evidence_links, render_evidence_lines_text, render_llm_output, resolve_output_format

app = typer.Typer()
console = Console()
config_manager = ConfigManager()


@app.callback(invoke_without_command=True)
def hybrid(
    query: str = typer.Argument(..., help="Pergunta jurídica"),
    top_k: int = typer.Option(10, "--top-k", "-k", help="Quantidade de resultados (1-50)"),
    hops: int = typer.Option(1, "--hops", help="Saltos no grafo normativo (1 ou 2)"),
    graph_expansion: str = typer.Option(
        "bidirectional", "--graph-expansion",
        help="Tipo de expansão: bidirectional ou forward",
    ),
    token_budget: int = typer.Option(None, "--token-budget", help="Limite de tokens para contexto"),
    output: str = typer.Option("table", "--output", "-o", help="Formato: table, json, text, llm"),
    raw: bool = typer.Option(False, "--raw", help="JSON bruto para piping"),
):
    """Busca semântica + expansão por grafo de citações normativas.

    Combina busca vetorial com navegação por relações entre normas via grafo.
    Ideal para encontrar artigos relacionados que citam ou são citados pelo resultado.

    Exemplo:
        vectorgov hybrid "Critérios de julgamento em licitações"
        vectorgov hybrid "Dispensa de licitação" --hops 2 --top-k 15
    """
    try:
        from vectorgov import VectorGov

        api_key = config_manager.get("api_key")
        if not api_key:
            console.print("[red]Erro:[/red] API key não configurada.")
            console.print("  Use [cyan]vectorgov auth login[/cyan] para configurar.")
            raise typer.Exit(1)

        if top_k < 1 or top_k > 50:
            console.print("[red]Erro:[/red] --top-k deve estar entre 1 e 50.")
            raise typer.Exit(1)

        if hops not in (1, 2):
            console.print("[red]Erro:[/red] --hops deve ser 1 ou 2.")
            raise typer.Exit(1)

        if graph_expansion not in ("bidirectional", "forward"):
            console.print("[red]Erro:[/red] --graph-expansion deve ser 'bidirectional' ou 'forward'.")
            raise typer.Exit(1)

        effective_output = resolve_output_format(output, is_raw=raw)

        vg = VectorGov(api_key=api_key)

        hybrid_kwargs = dict(query=query, top_k=top_k, hops=hops, graph_expansion=graph_expansion)
        if token_budget is not None:
            hybrid_kwargs["token_budget"] = token_budget

        with console.status("[bold]Buscando com expansão por grafo...[/bold]"):
            result = vg.hybrid(**hybrid_kwargs)

        # hits = direct_evidence do SDK (seeds da busca semântica). Se vazio,
        # usa graph_nodes como fallback (expansão via grafo com score>0).
        direct_hits = list(result.hits) if hasattr(result, "hits") else list(result)
        graph_hits = list(getattr(result, "graph_nodes", []) or [])
        hits = direct_hits if direct_hits else graph_hits

        if effective_output == "raw":
            # Safe serializer for stats dict
            raw_stats = {}
            stats_obj = getattr(result, "stats", None)
            if stats_obj is not None:
                if isinstance(stats_obj, dict):
                    raw_stats = stats_obj
                elif hasattr(stats_obj, "__dict__"):
                    raw_stats = {k: v for k, v in stats_obj.__dict__.items()
                                 if not k.startswith("_")}

            graph_nodes_raw = []
            for gn in getattr(result, "graph_nodes", []):
                graph_nodes_raw.append({
                    "text": getattr(gn, "text", ""),
                    "hop": getattr(gn, "hop", 0),
                    "source": getattr(gn, "source", ""),
                    "frequency": getattr(gn, "frequency", 0),
                    "node_id": getattr(gn, "node_id", ""),
                    "span_id": getattr(gn, "span_id", ""),
                    **get_evidence_links(gn),
                })

            data = {
                "query": query,
                "total": len(hits),
                "query_id": getattr(result, "query_id", None),
                "latency_ms": getattr(result, "latency_ms", None),
                "cached": getattr(result, "cached", None),
                "hits": [
                    {
                        "text": h.text,
                        "source": getattr(h, "source", ""),
                        "score": getattr(h, "score", 0),
                        "document_id": getattr(h, "document_id", ""),
                        "span_id": getattr(h, "span_id", ""),
                        "is_graph_expanded": getattr(h, "is_graph_expanded", False),
                        "hop": getattr(h, "hop", 0),
                        **get_evidence_links(h),
                    }
                    for h in hits
                ],
                "graph_nodes": graph_nodes_raw,
                "stats": raw_stats,
            }
            print(json.dumps(data, ensure_ascii=False, indent=2))
            return

        if effective_output == "llm":
            metadata = {"total": len(hits), "latency_ms": getattr(result, "latency_ms", None), "query_id": getattr(result, "query_id", None)}
            print(render_llm_output(hits, query, metadata))
            return

        if output == "json":
            data = [
                {
                    "source": getattr(h, "source", ""),
                    "score": getattr(h, "score", 0),
                    "text": h.text[:300],
                    "graph": getattr(h, "is_graph_expanded", False),
                }
                for h in hits
            ]
            console.print_json(json.dumps(data, ensure_ascii=False))
        elif output == "table":
            table = Table(title=f"Busca Híbrida ({len(hits)} resultados)")
            table.add_column("#", style="dim", width=3)
            table.add_column("Fonte", style="cyan", width=30)
            table.add_column("Texto", width=70)
            table.add_column("Score", justify="right", width=6)
            table.add_column("Grafo", width=5)
            for i, h in enumerate(hits, 1):
                source = getattr(h, "source", getattr(h, "document_id", ""))
                score = getattr(h, "score", 0)
                text = h.text[:180] + "..." if len(h.text) > 180 else h.text
                graph = "+" if getattr(h, "is_graph_expanded", False) else ""
                table.add_row(
                    str(i), source, text, f"{score:.2f}" if score else "-", graph
                )
            console.print(table)
        else:
            for i, h in enumerate(hits, 1):
                source = getattr(h, "source", getattr(h, "document_id", ""))
                graph_tag = (
                    " [yellow][grafo][/yellow]"
                    if getattr(h, "is_graph_expanded", False)
                    else ""
                )
                console.print(f"\n[cyan][{i}][/cyan] [bold]{source}[/bold]{graph_tag}")
                console.print(f"  {h.text[:300]}")
                for line in render_evidence_lines_text(h):
                    console.print(f"[dim]{line}[/dim]")

        query_id = getattr(result, "query_id", None)
        if query_id:
            console.print(f"\n[dim]query_id: {query_id}[/dim]")

    except Exception as e:
        console.print(f"[red]Erro:[/red] {e}")
        raise typer.Exit(1)
