"""Consulta de uso e limites do plano (smart_search e créditos)."""

import json
import typer
from rich.console import Console
from ..utils.config import ConfigManager

app = typer.Typer()
console = Console()
config_manager = ConfigManager()


@app.callback(invoke_without_command=True)
def quota(
    output: str = typer.Option("text", "--output", "-o", help="Formato: text, json"),
):
    """Exibe uso atual do plano: créditos e limite de smart_search.

    Mostra quantas consultas smart_search foram usadas no mês e
    quantos créditos gerais restam no plano.

    Exemplo:
        vectorgov quota
        vectorgov quota --output json
    """
    try:
        import httpx

        api_key = config_manager.get("api_key")
        if not api_key:
            console.print("[red]Erro:[/red] API key não configurada.")
            console.print("  Use [cyan]vectorgov auth login[/cyan] para configurar.")
            raise typer.Exit(1)

        base_url = config_manager.get("base_url", "https://vectorgov.io")

        with console.status("[bold]Consultando uso do plano...[/bold]"):
            headers = {"X-API-Key": api_key}
            client = httpx.Client(base_url=base_url, headers=headers, timeout=15)

            # Smart search usage
            ss_data = None
            try:
                resp = client.get("/api/v1/billing/smart-search-usage")
                if resp.status_code == 200:
                    ss_data = resp.json()
            except Exception:
                pass

            # Credit balance
            balance_data = None
            try:
                resp = client.get("/api/v1/billing/credits/balance")
                if resp.status_code == 200:
                    balance_data = resp.json()
            except Exception:
                pass

            client.close()

        if output == "json":
            data = {"smart_search": ss_data, "credits": balance_data}
            console.print_json(json.dumps(data, ensure_ascii=False, default=str))
            return

        console.print("\n[bold]Uso do Plano[/bold]\n")

        # Smart search quota
        if ss_data:
            if ss_data.get("unlimited"):
                console.print("  [cyan]Smart Search:[/cyan] [green]Ilimitado[/green]")
            else:
                used = ss_data.get("used", 0)
                limit = ss_data.get("limit", 0)
                remaining = ss_data.get("remaining", 0)
                pct = (used / limit * 100) if limit > 0 else 0
                color = "green" if pct < 80 else ("yellow" if pct < 100 else "red")
                console.print(f"  [cyan]Smart Search:[/cyan] [{color}]{used}/{limit}[/{color}] usadas este mês ({remaining} restantes)")
                if ss_data.get("resets_at"):
                    console.print(f"  [dim]Renova em: {ss_data['resets_at'][:10]}[/dim]")
        else:
            console.print("  [cyan]Smart Search:[/cyan] [dim]Informação não disponível[/dim]")

        # Credits
        if balance_data:
            total = balance_data.get("credits_total", 0)
            used = balance_data.get("credits_used", 0)
            remaining = balance_data.get("credits_remaining", 0)
            pct = (used / total * 100) if total > 0 else 0
            color = "green" if pct < 80 else ("yellow" if pct < 100 else "red")
            console.print(f"  [cyan]Créditos:    [/cyan] [{color}]{used}/{total}[/{color}] usados ({remaining} restantes)")
        else:
            console.print("  [cyan]Créditos:    [/cyan] [dim]Informação não disponível[/dim]")

        console.print()

    except Exception as e:
        console.print(f"[red]Erro:[/red] {e}")
        raise typer.Exit(1)
