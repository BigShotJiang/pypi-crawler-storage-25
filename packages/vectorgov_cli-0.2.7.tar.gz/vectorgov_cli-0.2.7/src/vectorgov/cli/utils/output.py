"""
Utilitários de formatação de saída do CLI VectorGov.
"""

import json
import os
from enum import Enum
from typing import Any, Dict, List, Optional

from rich.console import Console
from rich.table import Table
from rich.panel import Panel


BASE_URL = "https://vectorgov.io"


class OutputFormat(str, Enum):
    """Formatos de saída suportados."""
    table = "table"
    json = "json"
    text = "text"
    markdown = "markdown"
    llm = "llm"


# ─── Helpers de evidência ────────────────────────────────────────────────────

def absolute_url(relative_or_absolute: Optional[str]) -> Optional[str]:
    """Prefixa com https://vectorgov.io se vier relativo. None se vazio."""
    if not relative_or_absolute:
        return None
    if relative_or_absolute.startswith("http://") or relative_or_absolute.startswith("https://"):
        return relative_or_absolute
    if relative_or_absolute.startswith("/"):
        return f"{BASE_URL}{relative_or_absolute}"
    return f"{BASE_URL}/{relative_or_absolute}"


def get_evidence_links(hit: Any) -> Dict[str, Optional[str]]:
    """Extrai evidence_url e document_url de um hit do SDK.

    Retorna dict com ambos absolutos (com https://vectorgov.io prefixado),
    ou None se ausentes. Aceita hit objeto ou dict.
    """
    if isinstance(hit, dict):
        return {
            "evidence_url": absolute_url(hit.get("evidence_url")),
            "document_url": absolute_url(hit.get("document_url")),
        }
    return {
        "evidence_url": absolute_url(getattr(hit, "evidence_url", None)),
        "document_url": absolute_url(getattr(hit, "document_url", None)),
    }


def hit_to_raw_dict(hit: Any) -> Dict[str, Any]:
    """Serialização padronizada de um hit para JSON/raw output.

    Inclui evidence_url e document_url absolutos (null se ausentes).
    """
    links = get_evidence_links(hit)
    return {
        "text": getattr(hit, "text", ""),
        "article_number": getattr(hit, "article_number", None),
        "document_id": getattr(hit, "document_id", None) or getattr(hit, "source", None),
        "score": getattr(hit, "score", 0),
        "evidence_url": links["evidence_url"],
        "document_url": links["document_url"],
    }


def render_evidence_lines_text(hit: Any, indent: str = "    ") -> List[str]:
    """Linhas formatadas para text output. Lista vazia se nenhum link."""
    links = get_evidence_links(hit)
    lines: List[str] = []
    if links["evidence_url"]:
        lines.append(f"{indent}Ver trecho: {links['evidence_url']}")
    if links["document_url"]:
        lines.append(f"{indent}Baixar PDF: {links['document_url']}")
    return lines


def render_evidence_cell_table(hit: Any) -> str:
    """Célula curta para coluna de tabela. Usa Rich link markup clicável."""
    links = get_evidence_links(hit)
    ev = links["evidence_url"]
    if ev:
        return f"[link={ev}]ver trecho[/link]"
    return "-"


def render_evidence_markdown(hit: Any, indent: str = "") -> List[str]:
    """Seção Fontes em Markdown. Lista vazia se nenhum link."""
    links = get_evidence_links(hit)
    if not (links["evidence_url"] or links["document_url"]):
        return []
    lines = [f"{indent}**Fontes**:"]
    if links["evidence_url"]:
        lines.append(f"{indent}- [Ver trecho destacado]({links['evidence_url']})")
    if links["document_url"]:
        lines.append(f"{indent}- [Baixar PDF original]({links['document_url']})")
    return lines


# ─── Output LLM (texto puro) ─────────────────────────────────────────────────

def render_llm_output(hits: list, query: str, metadata: dict = None) -> str:
    """Output otimizado para consumo por LLMs. Texto puro, sem formatacao."""
    lines = []
    total = len(hits)
    for i, hit in enumerate(hits, 1):
        source = getattr(hit, "source", None) or getattr(hit, "document_id", "") or ""
        article = getattr(hit, "article_number", None) or ""
        score = getattr(hit, "score", 0)
        text = getattr(hit, "text", "")

        header = f"[{i}/{total}]"
        if source:
            header += f" {source}"
        if article and article not in source:
            header += f", Art. {article}"
        header += f" (score={score:.2f})"

        lines.append(header)
        lines.append(text[:500])

        links = get_evidence_links(hit)
        if links["evidence_url"]:
            lines.append(f"EVIDENCE: {links['evidence_url']}")
        if links["document_url"]:
            lines.append(f"PDF: {links['document_url']}")

        if i < total:
            lines.append("---")

    if metadata:
        parts = []
        if metadata.get("total") is not None:
            parts.append(f"Total: {metadata['total']} hits")
        if metadata.get("latency_ms") is not None:
            parts.append(f"Latencia: {metadata['latency_ms']/1000:.1f}s")
        if metadata.get("query_id"):
            parts.append(f"Query ID: {metadata['query_id']}")
        if parts:
            lines.append("---")
            lines.append(" | ".join(parts))

    return "\n".join(lines)


# ─── Resolução de formato de output ─────────────────────────────────────────

def resolve_output_format(explicit: str = "table", is_raw: bool = False) -> str:
    """Resolve formato de output com fallback: flag > env var > config > default.

    Se is_raw=True, retorna "raw" (bypass tudo).
    """
    if is_raw:
        return "raw"
    if explicit and explicit != "table":
        return explicit
    env_val = os.environ.get("VECTORGOV_OUTPUT", "").lower().strip()
    if env_val and env_val in ("table", "json", "text", "markdown", "llm", "raw"):
        return env_val
    try:
        from ..utils.config import ConfigManager
        config_val = ConfigManager().get("default_output")
        if config_val and config_val.lower() in ("table", "json", "text", "markdown", "llm", "raw"):
            return config_val.lower()
    except Exception:
        pass
    return explicit or "table"


# ─── Formatador principal ────────────────────────────────────────────────────

def format_search_results(console: Console, results: Any, output_format: OutputFormat, query: str):
    """
    Formata e exibe resultados de busca.

    Args:
        console: Console Rich para output
        results: Objeto SearchResult da API
        output_format: Formato desejado
        query: Query original
    """
    if output_format == OutputFormat.json:
        data = {
            "query": query,
            "total": results.total,
            "cached": results.cached,
            "latency_ms": results.latency_ms,
            "query_id": results.query_id,
            "hits": [hit_to_raw_dict(h) for h in results.hits],
        }
        console.print_json(json.dumps(data, ensure_ascii=False))

    elif output_format == OutputFormat.table:
        # Cabeçalho
        console.print()
        console.print(f"[bold]Resultados para:[/bold] {query}")
        console.print(f"[dim]Total: {results.total} | Latência: {results.latency_ms:.0f}ms | Cache: {'Sim' if results.cached else 'Não'}[/dim]")
        console.print()

        # Tabela
        table = Table(show_header=True, header_style="bold cyan")
        table.add_column("#", justify="right", style="dim", width=3)
        table.add_column("Artigo", style="green", width=10)
        table.add_column("Texto", width=55)
        table.add_column("Score", justify="right", width=7)
        table.add_column("Evidência", width=14)

        for i, hit in enumerate(results.hits, 1):
            article = getattr(hit, "article_number", "-") or "-"
            text = hit.text[:95] + "..." if len(hit.text) > 95 else hit.text
            text = text.replace("\n", " ")
            evidence_cell = render_evidence_cell_table(hit)
            table.add_row(str(i), str(article), text, f"{hit.score:.3f}", evidence_cell)

        console.print(table)

        # Footer com dica sobre evidência
        first_links = get_evidence_links(results.hits[0]) if results.hits else {"document_url": None}
        if first_links.get("document_url"):
            console.print(f"\n[dim]PDF do primeiro resultado: {first_links['document_url']}[/dim]")
        console.print(f"[dim]Query ID: {results.query_id}[/dim]")
        console.print("[dim]Use 'vectorgov feedback send <query_id> --like' para avaliar[/dim]")

    elif output_format == OutputFormat.markdown:
        console.print(f"## Resultados para: \"{query}\"\n")
        console.print(f"*Total: {results.total} | Latência: {results.latency_ms:.0f}ms*\n")
        for i, hit in enumerate(results.hits, 1):
            article = getattr(hit, "article_number", None)
            doc_id = getattr(hit, "document_id", None) or getattr(hit, "source", "")
            header = f"### {i}. Art. {article}" if article else f"### {i}."
            if doc_id:
                header += f" — {doc_id}"
            console.print(header)
            console.print()
            console.print(hit.text)
            console.print()
            for line in render_evidence_markdown(hit, indent=""):
                console.print(line)
            console.print()

    elif output_format == OutputFormat.llm or output_format == "llm":
        metadata = {
            "total": results.total,
            "latency_ms": results.latency_ms,
            "query_id": results.query_id,
        }
        print(render_llm_output(results.hits, query, metadata))

    else:  # text
        console.print()
        console.print(Panel(f"[bold]{query}[/bold]", title="Busca", border_style="blue"))

        for i, hit in enumerate(results.hits, 1):
            article = getattr(hit, "article_number", None)
            header = f"[{i}] Art. {article}" if article else f"[{i}]"

            console.print(f"\n[bold cyan]{header}[/bold cyan] (score: {hit.score:.3f})")
            console.print(hit.text[:300] + "..." if len(hit.text) > 300 else hit.text)
            # Links de evidência
            for line in render_evidence_lines_text(hit):
                console.print(f"[dim]{line}[/dim]")

        console.print(f"\n[dim]Total: {results.total} | Latência: {results.latency_ms:.0f}ms[/dim]")
        console.print(f"[dim]Query ID: {results.query_id}[/dim]")


def format_code_block(console: Console, code: str, language: str = "python"):
    """
    Formata e exibe um bloco de código.

    Args:
        console: Console Rich
        code: Código a exibir
        language: Linguagem para syntax highlighting
    """
    from rich.syntax import Syntax
    syntax = Syntax(code, language, theme="monokai", line_numbers=True)
    console.print(syntax)
