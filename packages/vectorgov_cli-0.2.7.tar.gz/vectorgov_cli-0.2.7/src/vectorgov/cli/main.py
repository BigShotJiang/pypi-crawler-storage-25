"""
Ponto de entrada principal do CLI VectorGov.
"""

import typer
from rich.console import Console

from .commands import auth, search, ask, feedback, docs, config, tokens
from .commands import smart_search, hybrid, lookup, grep_cmd, merged, audit, quota, prompts
from .commands import context, init, fs_search, read, explain

# Console para output formatado
console = Console()

# App principal
app = typer.Typer(
    name="vectorgov",
    help="CLI para a API VectorGov - Busca semântica em legislação brasileira",
    add_completion=True,
    no_args_is_help=True,
)

# Registra subcomandos
app.add_typer(auth.app, name="auth", help="Autenticação e gerenciamento de credenciais")
app.add_typer(search.app, name="search", help="Buscar documentos na base de legislação")
app.add_typer(ask.app, name="ask", help="[ADMIN] Fazer perguntas com resposta de IA", hidden=True)
app.add_typer(feedback.app, name="feedback", help="Enviar feedback sobre respostas")
app.add_typer(docs.app, name="docs", help="Listar e consultar documentos disponíveis")
app.add_typer(config.app, name="config", help="Gerenciar configurações")
app.add_typer(tokens.app, name="tokens", help="Estimar tokens para planejamento de uso de LLM")
app.add_typer(smart_search.app, name="smart-search", help="Busca inteligente com análise jurídica (MOC v4)")
app.add_typer(hybrid.app, name="hybrid", help="Busca híbrida com expansão por grafo normativo")
app.add_typer(lookup.app, name="lookup", help="Consulta artigo específico por referência legal")
app.add_typer(grep_cmd.app, name="grep", help="Busca exata por texto nas normas")
app.add_typer(merged.app, name="merged", help="Busca dual-path (semântica + índice curado)")
app.add_typer(audit.app, name="audit", help="Auditoria e histórico de uso")
app.add_typer(quota.app, name="quota", help="Uso e limites do plano")
app.add_typer(prompts.app, name="prompts", help="System prompts para LLMs")
app.add_typer(context.app, name="context", help="Gera contexto completo pronto para LLMs")
app.add_typer(init.app, name="init", help="Inicializa projeto para ferramentas AI")
app.add_typer(fs_search.app, name="fs-search", help="Busca no índice curado (filesystem)")
app.add_typer(read.app, name="read", help="Lê texto canônico de um documento ou dispositivo")
app.add_typer(explain.app, name="explain", help="Contexto completo de um dispositivo legal")


def _version_callback(value: bool):
    """Callback para o flag --version."""
    if value:
        from . import __version__
        console.print(f"vectorgov-cli versão {__version__}")
        raise typer.Exit()


@app.command()
def version():
    """Mostra a versão do CLI."""
    from . import __version__
    console.print(f"vectorgov-cli versão {__version__}")


@app.callback()
def callback(
    version: bool = typer.Option(
        False,
        "--version", "-V",
        callback=_version_callback,
        is_eager=True,
        help="Mostra a versão do CLI e sai.",
    ),
):
    """
    VectorGov CLI - Busca semântica em legislação brasileira.

    Use 'vectorgov COMANDO --help' para mais informações sobre cada comando.
    """
    pass


def main():
    """Função principal executada pelo entry point."""
    app()


if __name__ == "__main__":
    main()
