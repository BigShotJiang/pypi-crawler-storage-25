#!/usr/bin/env python3
"""
live eta watcher for codex tasks.
run in a separate terminal or auto-spawned by the mcp server.
works on macos, linux, windows.
"""

import json
import os
import sys
import time

_home = os.path.expanduser("~")
PROGRESS_FILE = os.path.join(_home, ".codex", "eta_progress")
LOG_FILE = os.path.join(_home, ".codex", "eta_monitor_log.jsonl")

SPINNER = ["\u280b", "\u2819", "\u281a", "\u281e", "\u2816", "\u2826", "\u2834", "\u2832", "\u2833", "\u2813"]


def get_terminal_width():
    try:
        return os.get_terminal_size().columns
    except:
        return 80


def main():
    spin_idx = 0
    last_log_size = 0
    completed_msg = None
    completed_at = 0

    sys.stdout.write("\033[?25l")
    sys.stdout.flush()

    try:
        while True:
            width = get_terminal_width()
            spin = SPINNER[spin_idx % len(SPINNER)]
            spin_idx += 1

            try:
                if os.path.exists(LOG_FILE):
                    cur_size = os.path.getsize(LOG_FILE)
                    if cur_size != last_log_size:
                        last_log_size = cur_size
                        with open(LOG_FILE, encoding="utf-8", errors="replace") as f:
                            lines = f.readlines()
                        if lines:
                            last = json.loads(lines[-1])
                            if last.get("event") == "complete":
                                d = last.get("data", {})
                                actual = d.get("actual_seconds", 0)
                                planned = d.get("planned_steps", d.get("estimated_steps", "?"))
                                actual_steps = d.get("actual_steps", "?")
                                err = d.get("estimation_error_pct")
                                err_str = f" | estimate was {abs(err):.0f}% {'over' if err > 0 else 'under'}" if err else ""
                                m, s = divmod(int(actual), 60)
                                time_str = f"{m}m {s}s" if m else f"{s}s"
                                completed_msg = f"\u2713 done in {time_str} ({actual_steps}/{planned} steps){err_str}"
                                completed_at = time.time()
            except:
                pass

            if completed_msg and (time.time() - completed_at) < 10:
                line = f"\033[32m{completed_msg}\033[0m"
                padded = line + " " * max(0, width - len(completed_msg) - 2)
                sys.stdout.write(f"\r{padded}")
                sys.stdout.flush()
                time.sleep(1)
                continue
            elif completed_msg and (time.time() - completed_at) >= 10:
                completed_msg = None

            try:
                if os.path.exists(PROGRESS_FILE):
                    mtime = os.path.getmtime(PROGRESS_FILE)
                    age = time.time() - mtime

                    if age < 30:
                        with open(PROGRESS_FILE, encoding="utf-8", errors="replace") as f:
                            content = f.read().strip()
                        if content:
                            line = f" {spin} {content}"
                            if len(line) > width - 1:
                                line = line[:width - 4] + "..."
                            padded = line + " " * max(0, width - len(line) - 1)
                            sys.stdout.write(f"\r{padded}")
                            sys.stdout.flush()
                            time.sleep(0.08)
                            continue

                line = f" {spin} waiting for codex task..."
                padded = line + " " * max(0, width - len(line) - 1)
                sys.stdout.write(f"\r\033[2m{padded}\033[0m")
                sys.stdout.flush()

            except:
                pass

            time.sleep(0.08)

    except KeyboardInterrupt:
        pass
    finally:
        sys.stdout.write("\033[?25h\r\033[K\n")
        sys.stdout.flush()


if __name__ == "__main__":
    main()
