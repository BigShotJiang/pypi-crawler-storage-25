#!/usr/bin/env python3
"""
openclaw-eta sidecar: monitors openclaw tasks via codex rollout files + gateway log.
- rollout files at ~/.openclaw/.../codex-home/sessions/ for live steps, tokens, prompts
- gateway log at /tmp/openclaw/ for completion detection ([end_turn])
usage: openclaw-eta-sidecar
"""

import json
import os
import sys
import tempfile
import time
import glob
import threading

_home = os.path.expanduser("~")

SESSIONS_DIR = os.path.join(_home, ".openclaw", "agents", "main", "agent", "codex-home", "sessions")
GATEWAY_LOG_DIR = os.path.join(tempfile.gettempdir(), "openclaw")
PROGRESS_FILE = os.path.join(_home, ".codex", "eta_progress")
LOG_FILE = os.path.join(_home, ".codex", "eta_monitor_log.jsonl")

SPINNER = ["\u280b", "\u2819", "\u281a", "\u281e", "\u2816", "\u2826", "\u2834", "\u2832", "\u2833", "\u2813"]

from codex_eta.sidecar import (
    call_codex_exec, parse_range_response, estimate_steps_heuristic,
    read_latest_task, fmt_time, fmt_range, fmt_tokens,
    write_progress, get_width, render_line,
)


def find_active_session():
    pattern = os.path.join(SESSIONS_DIR, "**", "rollout-*.jsonl")
    files = glob.glob(pattern, recursive=True)
    if not files:
        return None
    mtimes = []
    for f in files:
        try:
            mtimes.append((os.path.getmtime(f), f))
        except OSError:
            continue
    if not mtimes:
        return None
    mtime, latest = max(mtimes)
    if time.time() - mtime < 60:
        return latest
    return None


def get_gateway_log():
    from datetime import datetime
    today = datetime.now().strftime("%Y-%m-%d")
    path = os.path.join(GATEWAY_LOG_DIR, f"openclaw-{today}.log")
    if os.path.exists(path):
        return path
    return None


def check_gateway_end_turn(log_file, file_pos):
    try:
        cur_size = os.path.getsize(log_file)
        if cur_size <= file_pos:
            return False, file_pos
        with open(log_file, encoding="utf-8", errors="replace") as f:
            f.seek(file_pos)
            new_lines = f.readlines()
        for line in new_lines:
            try:
                d = json.loads(line)
                msg = d.get("message", d.get("0", ""))
                if isinstance(msg, str) and "[end_turn]" in msg:
                    return True, cur_size
            except:
                pass
        return False, cur_size
    except:
        return False, file_pos


def extract_user_prompt(data):
    msg = data.get("user_message") or data.get("prompt") or ""
    if not msg:
        return None

    if "Current user request:" in msg:
        msg = msg.split("Current user request:")[-1].strip()

    if msg.startswith("Delivery:"):
        nl = msg.find("\n\n")
        if nl != -1:
            msg = msg[nl + 2:].strip()

    if msg.startswith("Sender (untrusted metadata):"):
        end = msg.find("```\n\n")
        if end != -1:
            msg = msg[end + 5:].strip()

    if msg.startswith("[") and "]" in msg:
        after = msg[msg.find("]") + 1:].strip()
        if after.startswith("[Working directory:"):
            after = after[after.find("]") + 1:].strip()
        if after:
            msg = after

    return msg[:500] if msg else None


def log_event(event, data):
    entry = {"timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"), "event": event, "source": "openclaw", "data": data}
    try:
        os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
        if os.path.exists(LOG_FILE) and os.path.getsize(LOG_FILE) > 1_000_000:
            with open(LOG_FILE, encoding="utf-8", errors="replace") as f:
                lines = f.readlines()
            with open(LOG_FILE, "w") as f:
                f.writelines(lines[len(lines) // 2:])
        with open(LOG_FILE, "a") as f:
            f.write(json.dumps(entry) + "\n")
    except OSError:
        pass


def estimate_range_llm(prompt, callback, heuristic_lo=0, heuristic_hi=0,
                       step_log=None, elapsed=None, model=None, effort=None):
    def _run():
        _start = time.time()
        if step_log and elapsed:
            steps_desc = "\n".join(f"  step {s['step']}: {s['name']}" for s in step_log[-10:])
            est_prompt = (
                "You are codex. Another instance of you has been running this task for "
                f"{int(elapsed)} seconds, completing {len(step_log)} tool calls:\n"
                f"{steps_desc}\n\n"
                "How many MORE seconds to finish? "
                "If under 2 mins left, keep range within 45 seconds. "
                "If 2-5 mins left, within 90 seconds. If longer, within 2 minutes. "
                "Two numbers only.\n\n"
                f"Task: {prompt[:400]}"
            )
        else:
            est_prompt = (
                "You are codex. Another instance of you is about to execute this task. "
                f"A heuristic estimated {heuristic_lo}-{heuristic_hi} seconds. "
                "Do you agree or adjust? "
                "If task will take under 5 mins, keep range within 90 seconds spread. "
                "If 5-10 mins, within 2 minutes spread. If longer, within 3 minutes spread. "
                "Two numbers only.\n\n"
                f"Task: {prompt[:400]}"
            )
        response = call_codex_exec(est_prompt, model=model, reasoning_effort=effort)
        result = parse_range_response(response)
        log_event("llm_call_done", {
            "response": response[:100] if response else "None",
            "parsed": list(result) if result else None,
            "took": round(time.time() - _start, 1),
        })
        if result:
            callback(result)

    t = threading.Thread(target=_run, daemon=True)
    t.start()


def main():
    is_tty = sys.stdout.isatty()

    spin_idx = 0
    current_session = None

    prompt = None
    task_start_time = None
    logged_plan = False

    range_lo = 0
    range_hi = 0
    range_source = "none"
    llm_result = [None]
    llm_pending = False
    re_estimating = False
    reestimate_count = 0

    completed_msg = ""
    completed_at = 0
    showing_complete = False

    last_task_active = False
    last_task_done = False

    gateway_log = None
    gateway_pos = 0

    if is_tty:
        sys.stdout.write("\033[?25l")
        sys.stdout.flush()

    try:
        while True:
            width = get_width() if is_tty else 80
            spin = SPINNER[spin_idx % len(SPINNER)]
            spin_idx += 1

            if showing_complete and (time.time() - completed_at) < 10:
                if is_tty:
                    green_msg = f"\033[32m\u2713 {completed_msg}\033[0m"
                    padded = green_msg + " " * max(0, width - len(completed_msg) - 4)
                    sys.stdout.write(f"\r{padded}")
                    sys.stdout.flush()
                write_progress(completed_msg)
                time.sleep(0.1)
                continue
            elif showing_complete and (time.time() - completed_at) >= 10:
                showing_complete = False
                write_progress("")

            session_file = find_active_session()

            if session_file and session_file != current_session:
                current_session = session_file
                last_task_active = False
                last_task_done = False

            gw = get_gateway_log()
            if gw and gw != gateway_log:
                gateway_log = gw
                gateway_pos = os.path.getsize(gw)

            if not current_session:
                if is_tty:
                    sys.stdout.write(f"\r\033[2m {spin} waiting for openclaw...\033[0m{' ' * (width - 28)}")
                    sys.stdout.flush()
                time.sleep(0.3)
                continue

            data = read_latest_task(current_session)
            if not data:
                time.sleep(0.3)
                continue

            gateway_done = False
            if gateway_log and data["task_active"]:
                gateway_done, gateway_pos = check_gateway_end_turn(gateway_log, gateway_pos)

            if data["task_active"] and not last_task_active:
                prompt = extract_user_prompt(data) or data.get("prompt")
                task_start_time = time.time()
                last_step_count = 0
                logged_plan = False
                showing_complete = False
                llm_result = [None]
                llm_pending = False
                re_estimating = False
                reestimate_count = 0
                range_lo = 0
                range_hi = 0

            last_task_active = data["task_active"]

            task_finished = (data["task_done"] and not last_task_done) or (gateway_done and task_start_time)

            if task_finished and not last_task_done:
                last_task_done = True
                if task_start_time:
                    elapsed = time.time() - task_start_time
                    steps = data["steps"]
                    tok = data["token_events"][-1]["total"] if data["token_events"] else 0
                    in_range = range_lo <= elapsed <= range_hi if range_hi > 0 else False

                    log_event("complete", {
                        "prompt": (prompt or "")[:200],
                        "actual_seconds": round(elapsed, 1),
                        "actual_steps": steps,
                        "range": [round(range_lo), round(range_hi)],
                        "range_source": range_source,
                        "in_range": in_range,
                        "total_tokens": tok,
                    })

                    m, s = divmod(int(elapsed), 60)
                    time_str = f"{m}m {s}s" if m else f"{s}s"
                    if range_hi == 0:
                        accuracy = "no estimate"
                    elif in_range:
                        accuracy = f"within est {fmt_range(range_lo, range_hi)}"
                    elif elapsed < range_lo:
                        accuracy = f"faster than est {fmt_range(range_lo, range_hi)}"
                    else:
                        accuracy = f"exceeded est {fmt_range(range_lo, range_hi)}"
                    completed_msg = f"done in {time_str} ({steps} steps, {fmt_tokens(tok)}) [{accuracy}]"
                    completed_at = time.time()
                    showing_complete = True
                    write_progress(completed_msg)
                continue
            elif data["task_done"]:
                if not showing_complete:
                    if is_tty:
                        sys.stdout.write(f"\r\033[2m {spin} waiting for next task...\033[0m{' ' * (width - 30)}")
                        sys.stdout.flush()
                time.sleep(0.3)
                continue

            if data["task_active"]:
                last_task_done = False

            if data["task_active"] and not logged_plan and (data.get("prompt") or data["steps"] > 0):
                if not prompt:
                    prompt = extract_user_prompt(data) or data.get("prompt")

                if prompt:
                    estimated_steps = estimate_steps_heuristic(prompt)
                    range_lo = max(5, int(estimated_steps * 5))
                    range_hi = max(15, int(estimated_steps * 15))
                    range_source = "heuristic"
                else:
                    range_lo = 15
                    range_hi = 120
                    range_source = "default"

                logged_plan = True
                task_start_time = task_start_time or time.time()

                llm_pending = os.environ.get("ETA_NO_LLM") != "1"
                if llm_pending:
                    def _on_first(r):
                        llm_result[0] = r
                    estimate_range_llm(
                        prompt or "openclaw task", _on_first,
                        heuristic_lo=range_lo, heuristic_hi=range_hi,
                        model=data.get("model"), effort=data.get("reasoning_effort"),
                    )

                log_event("plan", {
                    "prompt": (prompt or "")[:200],
                    "heuristic_range": [range_lo, range_hi],
                    "source": range_source,
                })

            if llm_pending and llm_result[0] is not None:
                llm_lo, llm_hi = llm_result[0]
                merged_lo = min(range_lo, llm_lo)
                merged_hi = max(range_hi, llm_hi)
                if merged_hi - merged_lo > 180:
                    mid = (merged_lo + merged_hi) // 2
                    merged_lo = max(5, mid - 90)
                    merged_hi = mid + 90
                range_lo = merged_lo
                range_hi = merged_hi
                range_source = "llm_merged"
                llm_pending = False
                log_event("range_set", {
                    "range": [range_lo, range_hi],
                    "llm_raw": [llm_lo, llm_hi],
                    "source": "llm_merged",
                })

            if llm_pending and task_start_time and (time.time() - task_start_time) > 95:
                llm_pending = False

            if data["task_active"] and task_start_time and range_hi > 0 and not re_estimating and not llm_pending and reestimate_count < 2:
                elapsed = time.time() - task_start_time
                if elapsed > range_hi:
                    re_estimating = True
                    llm_result = [None]
                    if os.environ.get("ETA_NO_LLM") != "1":
                        def _on_reest(r):
                            llm_result[0] = r
                        estimate_range_llm(
                            prompt or "openclaw task", _on_reest,
                            step_log=data.get("step_log", []),
                            elapsed=elapsed,
                            model=data.get("model"), effort=data.get("reasoning_effort"),
                        )
                    log_event("re_estimating", {
                        "elapsed": round(elapsed, 1),
                        "steps_so_far": data["steps"],
                        "old_range": [round(range_lo), round(range_hi)],
                    })

            if re_estimating and llm_result[0] is not None:
                elapsed = time.time() - task_start_time if task_start_time else 0
                additional_lo, additional_hi = llm_result[0]
                range_lo = round(elapsed + additional_lo)
                range_hi = round(elapsed + additional_hi)
                range_source = "llm_reestimate"
                re_estimating = False
                reestimate_count += 1
                log_event("range_set", {
                    "range": [range_lo, range_hi],
                    "source": "llm_reestimate",
                })

            if data["task_active"] and task_start_time:
                elapsed = time.time() - task_start_time
                steps_done = data["steps"]
                tok = data["token_events"][-1] if data["token_events"] else None
                short_prompt = (prompt or "openclaw")[:30].replace("\n", " ")
                tok_str = f" {fmt_tokens(tok['total'])}" if tok else ""

                if re_estimating:
                    text = f"{short_prompt} | {fmt_time(elapsed)} elapsed, re-estimating... | step {steps_done}{tok_str}"
                elif range_hi > 0:
                    target = (range_lo + range_hi * 3) / 4
                    pct = min(95, int(elapsed / max(target, 1) * 100))
                    bar_w = 15
                    filled = pct * bar_w // 100
                    bar = "\u2588" * filled + "\u2591" * (bar_w - filled)
                    text = f"{short_prompt} | [{bar}] | {fmt_time(elapsed)} elapsed, est {fmt_range(range_lo, range_hi)} | step {steps_done}{tok_str}"
                elif llm_pending:
                    text = f"{short_prompt} | {fmt_time(elapsed)} elapsed, estimating... | step {steps_done}{tok_str}"
                else:
                    text = f"{short_prompt} | {fmt_time(elapsed)} elapsed | step {steps_done}{tok_str}"

                if is_tty:
                    render_line(spin, text, width)
                write_progress(text)

            elif not showing_complete and not data["task_active"]:
                if is_tty:
                    sys.stdout.write(f"\r\033[2m {spin} waiting for openclaw task...\033[0m{' ' * (width - 32)}")
                    sys.stdout.flush()

            time.sleep(0.1)

    except KeyboardInterrupt:
        pass
    finally:
        write_progress("")
        if is_tty:
            sys.stdout.write("\033[?25h\r\033[K\n")
            sys.stdout.flush()


if __name__ == "__main__":
    main()
