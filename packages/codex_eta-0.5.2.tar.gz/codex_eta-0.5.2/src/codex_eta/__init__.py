"""codex-eta: time estimation for codex tasks."""
__version__ = "0.5.2"
