#!/usr/bin/env python3
"""Install codex-eta sidecar to auto-start with codex."""

import os
import shutil
import sys
import time


BEGIN_MARKER = "# >>> codex-eta >>>"
END_MARKER = "# <<< codex-eta <<<"
LEGACY_MARKER = "# codex-eta:"

HOOK = f'''
{BEGIN_MARKER}
codex-eta-hook() {{
    (codex-eta-sidecar &>/dev/null &) 2>/dev/null
}}
codex() {{ codex-eta-hook; command codex "$@"; }}
codx() {{ codex-eta-hook; command codx "$@"; }}
{END_MARKER}
'''


def get_shell_rc():
    if sys.platform == "win32":
        raise SystemExit("shell hook install not supported on Windows. run codex-eta-sidecar manually.")
    shell = os.environ.get("SHELL", "")
    if "zsh" in shell:
        return os.path.expanduser("~/.zshrc")
    return os.path.expanduser("~/.bashrc")


def install():
    rc = get_shell_rc()
    try:
        with open(rc, encoding="utf-8") as f:
            existing = f.read()
    except FileNotFoundError:
        existing = ""
    except OSError as exc:
        raise SystemExit(f"could not read {rc}: {exc}") from exc

    if BEGIN_MARKER in existing or LEGACY_MARKER in existing:
        print(f"already installed in {rc}")
        return

    if os.path.exists(rc):
        backup = f"{rc}.codex-eta.bak.{int(time.time())}"
        shutil.copy2(rc, backup)
        print(f"backup written to {backup}")

    with open(rc, "a", encoding="utf-8") as f:
        f.write("\n" + HOOK)

    print(f"installed to {rc}")
    print(f"restart your shell or run: source {rc}")


def uninstall():
    rc = get_shell_rc()
    try:
        with open(rc, encoding="utf-8") as f:
            text = f.read()
    except FileNotFoundError:
        print("nothing to remove")
        return
    except OSError as exc:
        raise SystemExit(f"could not read {rc}: {exc}") from exc

    if BEGIN_MARKER not in text and LEGACY_MARKER not in text:
        print("nothing to remove")
        return

    backup = f"{rc}.codex-eta.bak.{int(time.time())}"
    shutil.copy2(rc, backup)

    lines = text.split("\n")
    new_lines = []
    skip = False
    legacy_skip = False
    for line in lines:
        if line.strip() == BEGIN_MARKER:
            skip = True
            continue
        if skip and line.strip() == END_MARKER:
            skip = False
            continue
        if skip:
            continue

        if LEGACY_MARKER in line:
            legacy_skip = True
            continue
        if legacy_skip and line.strip() == "":
            legacy_skip = False
            continue
        if legacy_skip and (
            line.startswith("codex-eta")
            or line.startswith("codex()")
            or line.startswith("codx()")
            or line.startswith("# trigger on codex/codx commands")
        ):
            continue
        if legacy_skip:
            legacy_skip = False
        new_lines.append(line)

    with open(rc, "w", encoding="utf-8") as f:
        f.write("\n".join(new_lines))

    print(f"removed from {rc}")
    print(f"backup written to {backup}")


def main():
    if "--help" in sys.argv or "-h" in sys.argv:
        print("usage: codex-eta-install [--uninstall]")
        print()
        print("Install or remove shell wrappers that auto-start codex-eta-sidecar.")
        return
    if "--uninstall" in sys.argv:
        uninstall()
    else:
        install()


if __name__ == "__main__":
    main()
