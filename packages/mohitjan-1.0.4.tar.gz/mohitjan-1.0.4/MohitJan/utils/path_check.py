import os
import site
import sys
import winreg


def get_scripts_path():
    return os.path.join(site.USER_BASE, "Scripts")


def is_path_set():
    scripts_path = get_scripts_path().lower()
    return scripts_path in os.environ.get("PATH", "").lower()


def show_warning():
    scripts_path = get_scripts_path()

    print("\n[WARNING] 'mohitjan' command is not available globally.\n")
    print("Add this path to your PATH:\n")
    print(scripts_path)
    print()


def add_to_path():
    scripts_path = os.path.join(site.USER_BASE, "Scripts")

    try:
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            "Environment",
            0,
            winreg.KEY_READ | winreg.KEY_WRITE
        )

        current_path, _ = winreg.QueryValueEx(key, "PATH")

        if scripts_path.lower() not in current_path.lower():
            new_path = current_path + ";" + scripts_path
            winreg.SetValueEx(key, "PATH", 0, winreg.REG_EXPAND_SZ, new_path)
            print("\nPATH updated safely.")
        else:
            print("\nPATH already contains Scripts folder.")

        winreg.CloseKey(key)

        print("Restart terminal and run: mohitjan\n")

    except Exception as e:
        print("Failed to update PATH:", e)


def check_and_fix_path():
    if not is_path_set():
        show_warning()

        choice = input("Fix automatically? (y/n): ").strip().lower()

        if choice == "y":
            add_to_path()
        else:
            print("\nSkipped. You can fix it manually later.\n")