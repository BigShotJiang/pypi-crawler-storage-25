from __future__ import annotations

from pathlib import Path

from tools.diagnostics.parity_sweep_manifest import (
    DEFAULT_MANIFEST,
    _evaluate_freeb_thresholds,
    _evaluate_runtime_thresholds,
    _parse_manifest,
)


REPO_ROOT = DEFAULT_MANIFEST.parents[2]


def test_parity_manifest_smoke_tier_covers_required_physics_classes() -> None:
    """Guard the required parity matrix against accidental case removal."""

    _, cases = _parse_manifest(DEFAULT_MANIFEST)
    smoke_cases = [case for case in cases if case.get("enabled", True) and case.get("tier") == "smoke"]

    def has_case(*, lfreeb: bool, lasym: bool, axisymmetric: bool | None = None) -> bool:
        for case in smoke_cases:
            if bool(case.get("lfreeb")) != lfreeb:
                continue
            if bool(case.get("lasym")) != lasym:
                continue
            if axisymmetric is not None and bool(case.get("axisymmetric")) != axisymmetric:
                continue
            return True
        return False

    assert has_case(lfreeb=False, lasym=False, axisymmetric=True)
    assert has_case(lfreeb=False, lasym=True, axisymmetric=True)
    assert has_case(lfreeb=False, lasym=False, axisymmetric=False)
    assert has_case(lfreeb=False, lasym=True, axisymmetric=False)
    assert has_case(lfreeb=True, lasym=False)


def test_parity_manifest_has_optional_bounded_freeb_lasym_true_case() -> None:
    """Keep a self-contained LASYM=true free-boundary case ready for optional parity."""

    _, cases = _parse_manifest(DEFAULT_MANIFEST)
    case = next(
        (
            case
            for case in cases
            if case.get("id") == "freeb_nonaxis_lasym_true_cth_like_local"
        ),
        None,
    )
    assert case is not None
    assert case.get("enabled") is True
    assert case.get("tier") == "planning"
    assert case.get("source") == "vmec_jax/examples"
    assert case.get("compare") == "freeb_scalpot"
    assert bool(case.get("lfreeb")) is True
    assert bool(case.get("lasym")) is True
    assert bool(case.get("axisymmetric")) is False
    assert case.get("input") == "examples/data/input.cth_like_free_bdy_lasym_small"
    assert float(case.get("max_runtime_s", 0.0)) > 0.0
    assert float(case.get("max_total_runtime_s", 0.0)) > 0.0
    assert set(case.get("runtime_thresholds_s_by_iter", {})) == {"80", "100"}
    assert case.get("metric_thresholds_rel_scaled_by_iter", {}).get("80", {}).get("source_sym") == 1.0e-2


def test_parity_manifest_smoke_cases_define_accuracy_and_runtime_contracts() -> None:
    """Keep fast parity cases explicit about tolerances, inputs, and cost gates."""

    _, cases = _parse_manifest(DEFAULT_MANIFEST)
    smoke_cases = [case for case in cases if case.get("enabled", True) and case.get("tier") == "smoke"]
    assert smoke_cases

    for case in smoke_cases:
        assert case["input"], case["id"]
        assert case.get("goal"), case["id"]
        assert case["compare"] in {"stage_trace", "freeb_scalpot"}, case["id"]
        assert float(case.get("atol", 0.0)) >= 0.0, case["id"]
        if case["compare"] == "stage_trace":
            assert float(case.get("rtol", 0.0)) > 0.0, case["id"]
            assert int(case.get("max_iter", 0)) > 0 or case.get("use_input_niter"), case["id"]
        if bool(case.get("lfreeb")):
            assert float(case.get("max_runtime_s", 0.0)) > 0.0, case["id"]
            assert float(case.get("max_total_runtime_s", 0.0)) > 0.0, case["id"]


def test_parity_manifest_enabled_local_inputs_exist() -> None:
    """Catch stale local manifest paths before optional sweeps are launched."""

    _, cases = _parse_manifest(DEFAULT_MANIFEST)
    local_cases = [
        case
        for case in cases
        if case.get("enabled", True) and str(case.get("source")) == "vmec_jax/examples"
    ]
    assert local_cases

    for case in local_cases:
        input_path = Path(case["input"])
        if not input_path.is_absolute():
            input_path = REPO_ROOT / input_path
        assert input_path.exists(), case["id"]


def test_parity_manifest_compare_modes_have_bounded_schema() -> None:
    """Keep manifest cases runnable by the sweep driver without broad VMEC runs."""

    _, cases = _parse_manifest(DEFAULT_MANIFEST)
    enabled_cases = [case for case in cases if case.get("enabled", True)]
    assert enabled_cases

    for case in enabled_cases:
        assert case["tier"] in {"smoke", "full", "planning"}, case["id"]
        assert case["compare"] in {"stage_trace", "freeb_scalpot"}, case["id"]
        assert isinstance(case.get("lfreeb"), bool), case["id"]
        assert isinstance(case.get("lasym"), bool), case["id"]
        assert isinstance(case.get("axisymmetric"), bool), case["id"]
        assert int(case.get("nfp", 0)) > 0, case["id"]
        assert int(case.get("ntor", -1)) >= 0, case["id"]
        assert float(case.get("vmec_timeout", 0.0)) > 0.0, case["id"]

        if case["compare"] == "stage_trace":
            assert "iter_list" not in case, case["id"]
            assert float(case.get("rtol", 0.0)) > 0.0, case["id"]
            assert float(case.get("atol", -1.0)) >= 0.0, case["id"]
            assert int(case.get("max_iter", 0)) > 0 or case.get("use_input_niter"), case["id"]
        else:
            assert bool(case.get("lfreeb")) is True, case["id"]
            iter_list = case.get("iter_list")
            assert isinstance(iter_list, list) and iter_list, case["id"]
            assert all(int(iter_idx) > 0 for iter_idx in iter_list), case["id"]
            assert int(case.get("max_iter", 0)) >= max(int(iter_idx) for iter_idx in iter_list), case["id"]
            assert case.get("metric_thresholds_rel_scaled") or case.get("metric_thresholds_rel_scaled_by_iter"), case[
                "id"
            ]


def test_evaluate_freeb_thresholds_global_pass() -> None:
    case = {"metric_thresholds_rel_scaled": {"source_sym": 1.0e-2, "amatrix": 2.0e-1}}
    runs = [
        {"iter": 53, "metrics_full": {"source_sym": {"rel_scaled": 5.0e-3}, "amatrix": {"rel_scaled": 1.0e-1}}},
        {"iter": 60, "metrics_full": {"amatrix": {"rel_scaled": 1.5e-1}}},
    ]
    ok, report = _evaluate_freeb_thresholds(case, runs)
    assert ok
    assert report["global"]["source_sym"]["pass"]
    assert report["global"]["amatrix"]["pass"]


def test_evaluate_freeb_thresholds_global_fail_on_limit() -> None:
    case = {"metric_thresholds_rel_scaled": {"source_sym": 1.0e-2}}
    runs = [{"iter": 53, "metrics_full": {"source_sym": {"rel_scaled": 2.0e-2}}}]
    ok, report = _evaluate_freeb_thresholds(case, runs)
    assert not ok
    assert not report["global"]["source_sym"]["pass"]


def test_evaluate_freeb_thresholds_by_iter_and_missing_metric_fail() -> None:
    case = {
        "metric_thresholds_rel_scaled_by_iter": {
            "53": {"source_sym": 1.0e-2},
            "54": {"potvac": 5.0e-1},
        }
    }
    runs = [{"iter": 53, "metrics_full": {"source_sym": {"rel_scaled": 5.0e-3}}}]
    ok, report = _evaluate_freeb_thresholds(case, runs)
    assert not ok
    assert report["by_iter"]["53"]["source_sym"]["pass"]
    assert not report["by_iter"]["54"]["potvac"]["pass"]


def test_evaluate_freeb_thresholds_bad_iter_key_fails() -> None:
    case = {"metric_thresholds_rel_scaled_by_iter": {"iter53": {"source_sym": 1.0e-2}}}
    runs = [{"iter": 53, "metrics_full": {"source_sym": {"rel_scaled": 5.0e-3}}}]
    ok, report = _evaluate_freeb_thresholds(case, runs)
    assert not ok
    assert report["by_iter"]["iter53"]["pass"] is False
    assert "error" in report["by_iter"]["iter53"]


def test_evaluate_runtime_thresholds_global_pass() -> None:
    case = {"max_runtime_s": 20.0, "max_total_runtime_s": 50.0}
    runs = [{"iter": 53, "runtime_s": 18.0}, {"iter": 54, "runtime_s": 17.0}]
    ok, report = _evaluate_runtime_thresholds(case, runs)
    assert ok
    assert report["max_runtime_s"]["pass"]
    assert report["max_total_runtime_s"]["pass"]


def test_evaluate_runtime_thresholds_by_iter_fail() -> None:
    case = {"runtime_thresholds_s_by_iter": {"53": {"max_runtime_s": 10.0}}}
    runs = [{"iter": 53, "runtime_s": 18.0}]
    ok, report = _evaluate_runtime_thresholds(case, runs)
    assert not ok
    assert not report["by_iter"]["53"]["max_runtime_s"]["pass"]


def test_evaluate_runtime_thresholds_bad_iter_key_fails() -> None:
    case = {"runtime_thresholds_s_by_iter": {"iter53": {"max_runtime_s": 10.0}}}
    runs = [{"iter": 53, "runtime_s": 8.0}]
    ok, report = _evaluate_runtime_thresholds(case, runs)
    assert not ok
    assert report["by_iter"]["iter53"]["pass"] is False
