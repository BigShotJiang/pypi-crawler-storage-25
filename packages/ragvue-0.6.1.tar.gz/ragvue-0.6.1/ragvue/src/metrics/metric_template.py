"""
RAGVue Custom Metric Template
==============================
Copy this file into ragvue/src/metrics/<your_metric_name>.py.
It will be auto-discovered as long as:
  - The file has a module-level  evaluate(item: dict) -> dict  function.
  - The filename is not in the denylist (see metrics_loader.py).
  - The filename does not start with '_'.

No registration needed — just drop the file and run `pip install -e .`
(editable installs pick up new files without reinstall).

CONTRACT
--------
Input  : item  — dict with keys: question (str), answer (str), contexts (list[str])
Output : dict  — MUST contain at least {"name": str, "score": float (0.0–1.0)}
                 Any extra keys are surfaced in the report as-is.

PATTERNS
--------
Two patterns are shown below. Use whichever fits your metric:
  A. OpenAI-based  — uses an LLM judge via the OpenAI API
  B. Local         — pure Python, no API calls (e.g. overlap, length, similarity)

This file is in the denylist and will NOT be auto-discovered.
"""

from __future__ import annotations
from typing import Dict, Any

# ══════════════════════════════════════════════════════════════════════════════
# PATTERN A — OpenAI-based metric
# ══════════════════════════════════════════════════════════════════════════════
# Uncomment and adapt the block below for an LLM-judge metric.

# import os, json
# from pathlib import Path
#
# def _ensure_openai_env():
#     """Load OPENAI_API_KEY from .env if not already set."""
#     if os.getenv("OPENAI_API_KEY"):
#         return
#     try:
#         from dotenv import load_dotenv, find_dotenv
#         load_dotenv(find_dotenv(filename=".env", usecwd=True), override=True)
#         if os.getenv("OPENAI_API_KEY"):
#             return
#         load_dotenv(Path(__file__).resolve().parents[2] / ".env", override=True)
#     except Exception:
#         pass
#
# _ensure_openai_env()
#
# # ── Prompt ──────────────────────────────────────────────────────────────────
# USER_TEMPLATE = (
#     "Metric: <your metric name>.\n"
#     "Task: <describe what to evaluate>.\n"
#     "Scoring guidelines:\n"
#     "  - 0.9–1.0: <describe high score>\n"
#     "  - 0.5–0.8: <describe mid score>\n"
#     "  - <0.5: <describe low score>\n\n"
#     "QUESTION:\n{question}\n\nANSWER:\n{answer}\n\nCONTEXT:\n{context}\n\n"
#     "Return compact JSON only, exactly:\n"
#     '{"score": <float 0.0-1.0>, "justification": "...", "extra_field": "..."}'
# )
#
# def _make_openai():
#     from openai import OpenAI
#     kwargs = {"api_key": os.getenv("OPENAI_API_KEY")}
#     base = os.getenv("OPENAI_BASE_URL")
#     if base:
#         kwargs["base_url"] = base
#     return OpenAI(**kwargs)
#
# def _parse_json(text: str) -> dict:
#     try:
#         return json.loads(text)
#     except Exception:
#         s, e = text.find("{"), text.rfind("}")
#         if s != -1 and e > s:
#             try:
#                 return json.loads(text[s:e+1])
#             except Exception:
#                 pass
#     return {}
#
# def _clamp(x) -> float:
#     try:
#         v = float(x)
#         return max(0.0, min(1.0, v))
#     except Exception:
#         return 0.0
#
# def evaluate(item: Dict[str, Any]) -> Dict[str, Any]:
#     client = _make_openai()
#     context = "\n".join(f"- {c}" for c in item.get("contexts", []))
#     user = USER_TEMPLATE.format(
#         question=item.get("question", ""),
#         answer=item.get("answer", ""),
#         context=context,
#     )
#     try:
#         out = client.chat.completions.create(
#             model=os.getenv("MY_METRIC_MODEL", "gpt-4o-mini"),
#             messages=[
#                 {"role": "system", "content": "You are a strict evaluation judge. Output ONLY compact JSON."},
#                 {"role": "user",   "content": user},
#             ],
#             temperature=float(os.getenv("MY_METRIC_TEMPERATURE", "0.0")),
#             response_format={"type": "json_object"},
#         )
#         text = out.choices[0].message.content or ""
#     except Exception as e:
#         return {"name": "my_metric", "score": 0.0, "error": str(e)}
#
#     obj = _parse_json(text)
#     return {
#         "name": "my_metric",           # must match the filename stem
#         "score": _clamp(obj.get("score", 0.0)),
#         "justification": obj.get("justification", ""),
#         "extra_field": obj.get("extra_field", ""),
#         "raw": obj,
#     }


# ══════════════════════════════════════════════════════════════════════════════
# PATTERN B — Local metric (no API calls)
# ══════════════════════════════════════════════════════════════════════════════
# Uncomment and adapt the block below for a pure-Python metric.

# def evaluate(item: Dict[str, Any]) -> Dict[str, Any]:
#     question = item.get("question", "")
#     answer   = item.get("answer", "")
#     contexts = item.get("contexts", [])
#
#     # --- your logic here ---
#     score = 0.0   # compute a float in [0.0, 1.0]
#
#     return {
#         "name": "my_local_metric",     # must match the filename stem
#         "score": score,
#         "detail_field": "...",         # any extra diagnostic fields
#     }


# ══════════════════════════════════════════════════════════════════════════════
# NOTES
# ══════════════════════════════════════════════════════════════════════════════
# - "name" in the return dict should match the Python filename stem exactly.
# - "score" must be a float in [0.0, 1.0].
# - Extra keys are surfaced verbatim in the report JSON and Streamlit UI.
# - For LLM-based metrics, honour the <METRIC>_MODEL and <METRIC>_TEMPERATURE
#   env vars so users can override per-metric without touching your code.
# - Local metrics are automatically treated as diagnostic-only (no weight in
#   answer_overall). To participate in answer_overall, add your metric name
#   and weight to _synthesize_answer_overall() in agentic_mode.py.
# - See any existing metric in this folder for a complete working example.
