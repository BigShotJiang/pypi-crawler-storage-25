"""
widdx/hooks/__init__.py — Hooks System (GAP-2)

Loads and fires hooks from ~/.widdx/hooks.json and .widdx/hooks.json.
Hooks run automatically on lifecycle events (PreToolUse, PostToolUse, etc.).
"""

from __future__ import annotations

import json
import logging
import re
import threading
from pathlib import Path

from widdx.hooks.events import HookEvent
from widdx.hooks.handlers import CommandHandler, HookResult, PromptHandler

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Data types
# ---------------------------------------------------------------------------

# HookResult is defined in handlers.py to avoid circular imports.
# Re-exported here so callers can do: from widdx.hooks import HookResult


# ---------------------------------------------------------------------------
# HookManager
# ---------------------------------------------------------------------------


class HookManager:
    """Loads and fires hooks from ~/.widdx/hooks.json and .widdx/hooks.json.

    hooks.json format::

        {
          "hooks": {
            "PostToolUse": [
              {
                "matcher": "Write|Edit",
                "type": "command",
                "command": "ruff check $WIDDX_FILE_PATH --fix",
                "async": false
              }
            ],
            "PreToolUse": [
              {
                "matcher": "Bash",
                "type": "prompt",
                "prompt": "Is this command safe? Reply ALLOW or DENY only."
              }
            ],
            "SessionStart": [
              {
                "type": "command",
                "command": "echo 'WIDDX session started' >> ~/.widdx/session.log"
              }
            ]
          }
        }
    """

    def __init__(self, router=None) -> None:
        # event name (str) → list of hook config dicts
        self._hooks: dict[str, list[dict]] = {}
        self._router = router

    def set_router(self, router) -> None:
        """Set or replace the LLM router used by prompt hooks."""
        self._router = router

    # ------------------------------------------------------------------
    # Loading
    # ------------------------------------------------------------------

    def load(self, paths: list[str] | None = None) -> None:
        """Load hooks from hooks.json files.

        Searches (in order):
          1. ~/.widdx/hooks.json  (user-level)
          2. .widdx/hooks.json    (project-level, relative to cwd)

        If *paths* is provided it overrides the default search list.
        Hooks from later files are appended to (not replacing) earlier ones,
        so project-level hooks extend user-level hooks.
        """
        self._hooks = {}

        search_paths: list[Path]
        if paths is not None:
            search_paths = [Path(p) for p in paths]
        else:
            search_paths = [
                Path("~/.widdx/hooks.json").expanduser(),
                Path(".widdx/hooks.json"),
            ]

        for hooks_file in search_paths:
            if not hooks_file.exists():
                continue
            self._load_file(hooks_file)

    def _load_file(self, path: Path) -> None:
        """Parse a single hooks.json file and merge into self._hooks."""
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            logger.warning("Failed to load hooks from %s: %s", path, exc)
            return

        hooks_section = data.get("hooks", {})
        if not isinstance(hooks_section, dict):
            logger.warning("Invalid hooks.json at %s: 'hooks' must be an object", path)
            return

        for event_name, hook_list in hooks_section.items():
            if not isinstance(hook_list, list):
                continue
            existing = self._hooks.setdefault(event_name, [])
            for hook in hook_list:
                if isinstance(hook, dict):
                    existing.append(hook)

    # ------------------------------------------------------------------
    # Firing
    # ------------------------------------------------------------------

    def fire(self, event: str, context: dict) -> list[HookResult]:
        """Fire all hooks registered for *event*.

        Hooks with ``"async": true`` are dispatched to a background thread
        (non-blocking); their results are not included in the return value.
        All other hooks run synchronously and their results are returned.

        PreToolUse hooks are never dispatched async — their results must be
        returned synchronously to block dangerous tool calls. Any async flag
        on a PreToolUse hook is silently ignored.

        Args:
            event:   Event name string (e.g. "PreToolUse", "PostToolUse").
            context: Arbitrary context dict passed to each hook.
                     ``context["tool"]`` is used for matcher filtering.

        Returns:
            List of HookResult objects for synchronous hooks only.
        """
        hook_configs = self._hooks.get(str(event), [])
        results: list[HookResult] = []
        allow_async = event != "PreToolUse"

        for hook in hook_configs:
            if allow_async and hook.get("async", False):
                # Run this individual hook in a background thread; skip result.
                thread = threading.Thread(
                    target=self._run_hook_and_log,
                    args=(str(event), hook, context),
                    daemon=True,
                    name=f"widdx-hook-async-{event}",
                )
                thread.start()
            else:
                result = self._run_hook(str(event), hook, context)
                if result is not None:
                    results.append(result)

        return results

    def fire_async(self, event: str, context: dict) -> None:
        """Fire hooks in a background thread (non-blocking).

        Results are logged but not returned to the caller.

        PreToolUse hooks are never dispatched async — their results must be
        returned synchronously to block dangerous tool calls.  This method
        logs a warning and falls back to synchronous execution for PreToolUse.
        """
        if str(event) == "PreToolUse":
            logger.warning(
                "fire_async called for PreToolUse — falling back to sync fire() "
                "because PreToolUse hooks must block tool execution."
            )
            self.fire(event, context)
            return

        thread = threading.Thread(
            target=self._fire_and_log,
            args=(event, context),
            daemon=True,
            name=f"widdx-hook-{event}",
        )
        thread.start()

    def _fire_and_log(self, event: str, context: dict) -> None:
        """Background worker: fire hooks and log any warnings."""
        results = self.fire(event, context)
        for r in results:
            if not r.success:
                logger.warning(
                    "Hook [%s/%s] failed: %s", r.event, r.hook_type, r.output
                )

    def _run_hook_and_log(self, event: str, hook: dict, context: dict) -> None:
        """Background worker: run a single hook and log on failure."""
        result = self._run_hook(event, hook, context)
        if result is not None and not result.success:
            logger.warning(
                "Async hook [%s/%s] failed: %s", result.event, result.hook_type, result.output
            )

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    def all_hooks(self) -> dict[str, list[dict]]:
        """Return all loaded hooks keyed by event name.

        Used by the /hooks REPL command to display the current hook list.
        """
        return dict(self._hooks)

    # ------------------------------------------------------------------
    # Internal hook execution
    # ------------------------------------------------------------------

    def _run_hook(self, event: str, hook: dict, context: dict) -> HookResult | None:
        """Execute a single hook config dict.

        Returns None if the hook's matcher does not match the current tool.
        """
        # Matcher filtering — only applies when a matcher is specified
        matcher = hook.get("matcher", "")
        if matcher:
            tool_name = context.get("tool", "")
            if not re.search(matcher, tool_name):
                return None

        hook_type = hook.get("type", "command")

        if hook_type == "command":
            return self._run_command_hook(event, hook, context)
        elif hook_type == "prompt":
            return self._run_prompt_hook(event, hook, context)
        else:
            logger.warning("Unknown hook type %r for event %s", hook_type, event)
            return HookResult(
                event=event,
                hook_type=hook_type,
                success=False,
                output=f"Unknown hook type: {hook_type!r}",
            )

    def _run_command_hook(self, event: str, hook: dict, context: dict) -> HookResult:
        """Execute a shell command hook via CommandHandler."""
        from widdx.hooks import handlers as _handlers

        return _handlers.CommandHandler().run(event, hook, context)

    def _run_prompt_hook(self, event: str, hook: dict, context: dict) -> HookResult:
        """Handle a prompt-type hook via PromptHandler."""
        from widdx.hooks import handlers as _handlers

        return _handlers.PromptHandler(router=self._router).run(event, hook, context)


__all__ = ["HookEvent", "HookManager", "HookResult"]
