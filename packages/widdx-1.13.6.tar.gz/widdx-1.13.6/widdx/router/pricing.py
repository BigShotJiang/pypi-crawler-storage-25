"""Router pricing — cost tracking and token estimation."""
from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

# DeepSeek pricing per 1M tokens (April 2025)
PRICING = {
    "deepseek-v4-pro":    {"input": 0.55, "output": 2.19},
    "deepseek-v4-flash":  {"input": 0.27, "output": 1.10},
    "deepseek-v4-flash-free": {"input": 0.0, "output": 0.0},
    "big-pickle": {"input": 0.0, "output": 0.0},
    # Google Gemini (free tier via AI Studio)
    "gemini-2.0-flash":   {"input": 0.0, "output": 0.0},
    "gemini-2.5-flash":   {"input": 0.0, "output": 0.0},
    "gemini-2.5-pro":     {"input": 0.0, "output": 0.0},
}

# Global tiktoken encoder (lazy-loaded)
_TIKTOKEN_ENCODING = None


def _get_encoder():
    """Return a tiktoken encoder, or None if not available."""
    global _TIKTOKEN_ENCODING
    if _TIKTOKEN_ENCODING is None:
        try:
            import tiktoken
            _TIKTOKEN_ENCODING = tiktoken.get_encoding("cl100k_base")
        except Exception:
            logger.debug("tiktoken not available — falling back to char/4 estimation")
            _TIKTOKEN_ENCODING = False
    return _TIKTOKEN_ENCODING if _TIKTOKEN_ENCODING is not False else None


def _count_tokens(text: str) -> int:
    """Count tokens for a single string using tiktoken, or fallback to len/4."""
    enc = _get_encoder()
    if enc is not None:
        return len(enc.encode(text, disallowed_special=()))
    return len(text) // 4


def _init_cost_tracking(self) -> None:
    self._session_input_tokens = 0
    self._session_output_tokens = 0
    self._session_cost = 0.0


def _track_usage(self, model: str, input_tokens: int, output_tokens: int) -> None:
    """Accumulate token usage and calculate cost."""
    self._session_input_tokens += input_tokens
    self._session_output_tokens += output_tokens
    pricing = PRICING.get(model, {"input": 0.27, "output": 1.10})
    cost = (
        (input_tokens / 1_000_000) * pricing["input"]
        + (output_tokens / 1_000_000) * pricing["output"]
    )
    self._session_cost += cost


def _estimate_tokens(self, messages: list[dict]) -> int:
    """Accurate token estimate using tiktoken (falls back to chars/4)."""
    total = 0
    for msg in messages:
        content = msg.get("content", "")
        if isinstance(content, str):
            total += _count_tokens(content)
        for tc in msg.get("tool_calls", []):
            fn = tc.get("function", {})
            total += _count_tokens(fn.get("arguments", ""))
            total += _count_tokens(fn.get("name", ""))
    return total



