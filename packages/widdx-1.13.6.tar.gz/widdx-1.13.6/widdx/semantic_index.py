"""Semantic code search — local embeddings, no API cost, instant results.

Uses sentence-transformers (all-MiniLM-L6-v2, ~80MB) for embeddings and
ChromaDB for vector storage. Runs entirely in-process — no server needed.

Usage:
    index = SemanticIndex(persist_dir=".widdx/embeddings")
    index.index_project(Path("."))          # One-time index
    results = index.search("how does auth work", top_k=5)  # Search
    index.update_file(Path("src/auth.py"))  # Incremental update
"""
from __future__ import annotations

import fnmatch
import hashlib
import logging
import os
import re
import time
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# ── Chunking ──────────────────────────────────────────────────────────

# Files to skip entirely
_SKIP_GLOBS = [
    "*.pyc", "*__pycache__*", "*.egg-info*", "*.git/*",
    "node_modules/*", "vendor/*", "*.log", "*.lock",
    "*.min.js", "*.min.css", "*.map", "*.svg", "*.png", "*.jpg",
    ".widdx/embeddings/*", "graphify-out/*",
]
# Extensions worth indexing
_INDEX_EXTS = {
    ".py", ".js", ".ts", ".tsx", ".jsx", ".go", ".rs", ".java",
    ".rb", ".php", ".swift", ".kt", ".cs", ".scala", ".cpp", ".c",
    ".h", ".hpp", ".cc", ".cxx", ".vue", ".svelte", ".sql",
    ".md", ".txt", ".yaml", ".yml", ".toml", ".json", ".cfg",
    ".html", ".css", ".scss", ".less", ".sh", ".bash", ".ps1",
    ".dockerfile", ".dockerignore", "Makefile", ".env.example",
    ".gitignore", ".graphql", ".proto",
}

_MAX_FILE_BYTES = 500_000  # Skip huge files (>500KB)
_CHUNK_SIZE = 800          # Characters per chunk
_CHUNK_OVERLAP = 200       # Overlap between chunks


def _should_index(path: Path) -> bool:
    """Return True if this file should be indexed."""
    if path.is_dir():
        return False
    try:
        if path.stat().st_size > _MAX_FILE_BYTES:
            return False
    except OSError:
        return False
    name = path.name.lower()
    # Skip common noise
    if name in ("package-lock.json", "composer.lock", "yarn.lock"):
        return False
    # Check extension
    suffix = path.suffix.lower()
    if suffix in _INDEX_EXTS:
        return True
    # Extensionless files with known names
    if name in ("makefile", "dockerfile", ".gitignore", ".env.example",
                ".dockerignore"):
        return True
    return False


def _chunk_code(content: str, file_path: str) -> list[dict[str, Any]]:
    """Split file content into overlapping chunks with metadata."""
    chunks: list[dict[str, Any]] = []
    if not content.strip():
        return chunks

    # Try to chunk by function/class boundaries first
    sections = re.split(
        r'(?:(?:^|\n)(?:def |class |async def |function |func |public function '
        r'|export function |export class |const \w+ = |export const ))',
        content,
    )

    # If we got too many tiny sections, use fixed-size chunks
    if len(sections) > 100 or all(len(s) < 100 for s in sections if s.strip()):
        return _fixed_chunks(content, file_path)

    pos = 0
    for i, section in enumerate(sections):
        text = section.strip()
        if not text:
            continue
        if len(text) < 50:
            continue
        if len(text) > _CHUNK_SIZE + _CHUNK_OVERLAP:
            # Sub-chunk large sections
            sub = _fixed_chunks(text, file_path)
            for s in sub:
                s["chunk_index"] = i
                chunks.append(s)
        else:
            start_line = content[:pos].count('\n') + 1 if pos < len(content) else 1
            chunks.append({
                "text": text,
                "file": file_path,
                "chunk_index": i,
                "start_line": start_line,
                "source": f"{file_path}:{start_line}",
            })
            pos += len(section)

    return chunks


def _fixed_chunks(content: str, file_path: str) -> list[dict[str, Any]]:
    """Fallback: fixed-size overlapping chunks."""
    chunks: list[dict[str, Any]] = []
    lines = content.split('\n')
    current = ""
    start_line = 1
    line_idx = 0

    for line in lines:
        if len(current) + len(line) > _CHUNK_SIZE and current:
            chunks.append({
                "text": current.strip(),
                "file": file_path,
                "chunk_index": len(chunks),
                "start_line": start_line,
                "source": f"{file_path}:{start_line}",
            })
            # Overlap: keep last _CHUNK_OVERLAP chars
            overlap_start = max(0, len(current) - _CHUNK_OVERLAP)
            current = current[overlap_start:]
            start_line = line_idx - current.count('\n')
        current += line + '\n'
        line_idx += 1

    if current.strip():
        chunks.append({
            "text": current.strip(),
            "file": file_path,
            "chunk_index": len(chunks),
            "start_line": start_line,
            "source": f"{file_path}:{start_line}",
        })

    return chunks


# ── Semantic Index ─────────────────────────────────────────────────────

class SemanticIndex:
    """Local semantic code search using embeddings + ChromaDB."""

    def __init__(self, persist_dir: str = ".widdx/embeddings"):
        self._persist_dir = Path(persist_dir).resolve()
        self._persist_dir.mkdir(parents=True, exist_ok=True)
        self._model = None
        self._client = None
        self._collection = None
        self._file_hashes: dict[str, str] = {}
        self._ready = False

    # ── Lazy init ──────────────────────────────────────────────────

    def _ensure_model(self) -> None:
        if self._model is not None:
            return
        try:
            from sentence_transformers import SentenceTransformer
            self._model = SentenceTransformer('all-MiniLM-L6-v2')
        except ImportError:
            raise ImportError(
                "sentence-transformers is required for semantic search.\n"
                "Run: pip install sentence-transformers"
            ) from None

    def _ensure_db(self) -> None:
        if self._collection is not None:
            return
        try:
            import chromadb
            self._client = chromadb.PersistentClient(
                path=str(self._persist_dir),
                settings=chromadb.Settings(anonymized_telemetry=False),
            )
            self._collection = self._client.get_or_create_collection(
                name="codebase",
                metadata={"hnsw:space": "cosine"},
            )
        except ImportError:
            raise ImportError(
                "chromadb is required for semantic search.\n"
                "Run: pip install chromadb"
            ) from None

    @property
    def is_ready(self) -> bool:
        return self._ready

    @property
    def chunk_count(self) -> int:
        if self._collection is None:
            return 0
        return self._collection.count()

    # ── Indexing ────────────────────────────────────────────────────

    def index_project(self, root: Path, batch_size: int = 50) -> dict:
        """Index all indexable files under root. Returns stats dict."""
        self._ensure_model()
        self._ensure_db()

        t0 = time.time()
        files = []
        for path in root.rglob("*"):
            try:
                rel_str = str(path.relative_to(root))
            except ValueError:
                rel_str = str(path)
            if any(fnmatch.fnmatch(rel_str, pat) for pat in _SKIP_GLOBS):
                continue
            if _should_index(path):
                files.append(path)

        stats = {"files": 0, "chunks": 0, "skipped": 0, "elapsed": 0}
        all_ids: list[str] = []
        all_embeddings: list[list[float]] = []
        all_documents: list[str] = []
        all_metadatas: list[dict] = []

        for i, fpath in enumerate(files):
            try:
                rel = str(fpath.relative_to(root))
            except ValueError:
                rel = str(fpath)

            # Check if file changed
            file_hash = _file_hash(fpath)
            if self._file_hashes.get(rel) == file_hash:
                stats["skipped"] += 1
                continue

            try:
                content = fpath.read_text(encoding="utf-8", errors="replace")
            except OSError:
                stats["skipped"] += 1
                continue

            chunks = _chunk_code(content, rel)
            if not chunks:
                stats["skipped"] += 1
                continue

            for chunk in chunks:
                all_ids.append(f"{rel}:{chunk['chunk_index']}")
                all_documents.append(chunk["text"])
                all_metadatas.append({
                    "file": rel,
                    "source": chunk["source"],
                    "start_line": chunk["start_line"],
                })

            self._file_hashes[rel] = file_hash
            stats["files"] += 1

            # Batch insert
            if len(all_ids) >= batch_size:
                embeddings = self._model.encode(
                    all_documents, show_progress_bar=False
                ).tolist()
                self._collection.upsert(
                    ids=all_ids,
                    embeddings=embeddings,
                    documents=all_documents,
                    metadatas=all_metadatas,
                )
                stats["chunks"] += len(all_ids)
                all_ids, all_embeddings, all_documents, all_metadatas = [], [], [], []

        # Final batch
        if all_ids:
            embeddings = self._model.encode(
                all_documents, show_progress_bar=False
            ).tolist()
            self._collection.upsert(
                ids=all_ids,
                embeddings=embeddings,
                documents=all_documents,
                metadatas=all_metadatas,
            )
            stats["chunks"] += len(all_ids)

        stats["elapsed"] = round(time.time() - t0, 2)
        self._ready = True
        return stats

    def update_file(self, path: Path, root: Path | None = None) -> bool:
        """Re-index a single changed file. Returns True if updated."""
        self._ensure_model()
        self._ensure_db()

        if not _should_index(path):
            return False

        try:
            if root:
                rel = str(path.relative_to(root))
            else:
                rel = str(path)
        except ValueError:
            rel = str(path)

        try:
            content = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return False

        # Remove old chunks for this file
        try:
            existing = self._collection.get(where={"file": rel})
            if existing and existing["ids"]:
                self._collection.delete(ids=existing["ids"])
        except Exception:
            pass

        chunks = _chunk_code(content, rel)
        if not chunks:
            return True  # File indexed (zero chunks)

        ids = [f"{rel}:{c['chunk_index']}" for c in chunks]
        documents = [c["text"] for c in chunks]
        metadatas = [{
            "file": rel,
            "source": c["source"],
            "start_line": c["start_line"],
        } for c in chunks]

        embeddings = self._model.encode(
            documents, show_progress_bar=False
        ).tolist()

        self._collection.upsert(
            ids=ids,
            embeddings=embeddings,
            documents=documents,
            metadatas=metadatas,
        )
        self._file_hashes[rel] = _file_hash(path)
        return True

    # ── Search ───────────────────────────────────────────────────────

    def search(self, query: str, top_k: int = 10) -> list[dict]:
        """Return top-k chunks semantically matching the query.

        Each result: {file, source, text, start_line, score}
        """
        self._ensure_model()
        self._ensure_db()

        if self._collection.count() == 0:
            return []

        query_embedding = self._model.encode(
            [query], show_progress_bar=False
        ).tolist()

        results = self._collection.query(
            query_embeddings=query_embedding,
            n_results=min(top_k, self._collection.count()),
            include=["documents", "metadatas", "distances"],
        )

        hits = []
        if not results or not results["ids"] or not results["ids"][0]:
            return hits

        for i, chunk_id in enumerate(results["ids"][0]):
            meta = results["metadatas"][0][i] if results["metadatas"] else {}
            doc = results["documents"][0][i] if results["documents"] else ""
            dist = results["distances"][0][i] if results["distances"] else 1.0
            # Cosine distance -> similarity score
            score = max(0.0, 1.0 - dist)

            hits.append({
                "id": chunk_id,
                "file": meta.get("file", ""),
                "source": meta.get("source", ""),
                "start_line": meta.get("start_line", 0),
                "text": doc[:1000],
                "score": round(score, 3),
            })

        return hits

    def search_context(self, query: str, top_k: int = 8,
                       max_chars: int = 8000) -> str:
        """Return a formatted context string for injection into prompts."""
        hits = self.search(query, top_k=top_k)
        if not hits:
            return ""

        parts = []
        total = 0
        for hit in hits:
            block = f"=== {hit['source']} (score={hit['score']}) ===\n{hit['text']}\n\n"
            if total + len(block) > max_chars:
                break
            parts.append(block)
            total += len(block)

        return '\n'.join(parts)


# ── Helpers ────────────────────────────────────────────────────────────

def _file_hash(path: Path) -> str:
    """Fast content hash for change detection."""
    try:
        st = path.stat()
        return hashlib.sha1(
            f"{st.st_size}:{st.st_mtime}".encode()
        ).hexdigest()[:16]
    except OSError:
        return ""


def get_semantic_index(persist_dir: str | None = None) -> SemanticIndex:
    """Get or create a global SemanticIndex singleton."""
    if persist_dir is None:
        persist_dir = os.environ.get(
            "WIDDX_EMBEDDINGS_DIR",
            str(Path.home() / ".widdx" / "embeddings"),
        )
    return SemanticIndex(persist_dir=persist_dir)
