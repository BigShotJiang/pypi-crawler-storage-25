"""Tool loop display — professional terminal visual language.

Auto-detects terminal capabilities and uses:
  - Unicode emoji on modern terminals (WT, iTerm2, Kitty, etc.)
  - ASCII fallback on legacy terminals (cmd.exe, xterm, etc.)

Visual grammar (modern):
  📄  tool call header   (colored icon)
  │  diff line          (red/green)
  ✓  result / output    (dim, indented)

Visual grammar (legacy):
  [READ]   tool call header
  |        diff line
  OK       result / output
"""
from __future__ import annotations

import difflib
import os
import sys

from ..ui.arabic import _d


def _get_console():
    from .. import ui
    return ui.get_console()


def _reshape_line(text: str) -> str:
    return _d(text)


def _short_path(path: str) -> str:
    parts = path.replace("\\", "/").split("/")
    return "/".join(parts[-2:]) if len(parts) > 2 else path


def _short_path_display(path: str) -> str:
    return _short_path(path)


# ── Terminal capability detection ──────────────────────────────────

def _supports_unicode() -> bool:
    """Check if the terminal likely supports Unicode emoji characters."""
    term = os.environ.get("TERM", "")
    term_prog = os.environ.get("TERM_PROGRAM", "")
    wt_session = os.environ.get("WT_SESSION", "")
    # Modern terminals
    modern_terms = ("xterm-256color", "screen-256color", "tmux-256color",
                     "alacritty", "kitty", "wezterm", "foot", "rio")
    modern_progs = ("vscode", "WarpTerminal", "iTerm.app", "Hyper",
                     "Windows Terminal", "Tabby", "Ghostty")
    if wt_session:
        return True
    if any(p.lower() in term_prog.lower() for p in modern_progs):
        return True
    if any(t in term for t in modern_terms):
        return True
    # Legacy fallback — no emoji
    if sys.platform == "win32" and not wt_session:
        return False
    # Default: try unicode (Linux/macOS terminals usually support it)
    return True


_UNICODE_OK: bool | None = None


def _unicode_ok() -> bool:
    global _UNICODE_OK
    if _UNICODE_OK is None:
        _UNICODE_OK = _supports_unicode()
    return _UNICODE_OK


# ── Tool → icon + color mapping ─────────────────────────────────────
# Dual icons: (unicode_emoji, ascii_fallback)
_TOOL_META: dict[str, tuple[str, str, str]] = {
    "Read":      ("\U0001f4c4", "READ",  "tool_read"),
    "ListDir":   ("\U0001f4c1", "DIR",   "tool_read"),
    "Glob":      ("\U0001f50d", "FIND",  "tool_read"),
    "Grep":      ("\U0001f50e", "GREP",  "tool_read"),
    "WebSearch": ("\U0001f310", "WEB",   "tool_web"),
    "Write":     ("\u2728",     "WRITE", "tool_write"),
    "Edit":      ("\u270f",     "EDIT",  "tool_shell"),
    "Bash":      ("\u2699",     "RUN",   "tool_shell"),
}


def _tool_icon(name: str) -> str:
    """Return the appropriate icon for this tool based on terminal capability."""
    meta = _TOOL_META.get(name, ("\u25c6", "TOOL", "brand"))
    return meta[0] if _unicode_ok() else f"[{meta[1]}]"


def _tool_style(name: str) -> str:
    return _TOOL_META.get(name, ("\u25c6", "TOOL", "brand"))[2]


def _tool_label(name: str, args: dict) -> str:
    if name == "Read":
        fp = args.get("file_path", "")
        offset = args.get("offset", 0)
        limit = args.get("limit", -1)
        suffix = f":{offset}" if offset else ""
        suffix += f"+{limit}" if (limit and limit != -1) else ""
        return f"{_short_path(fp)}{suffix}"
    if name in ("Write", "Edit"):
        return _short_path(args.get("file_path", ""))
    if name == "Grep":
        pat = args.get("pattern", "")
        path = args.get("path", ".")
        pp = f", {_short_path(path)}" if path and path != "." else ""
        return f'"{pat[:40]}{"…" if len(pat) > 40 else ""}"{pp}'
    if name == "Glob":
        return f'"{args.get("pattern", "")}"'
    if name == "Bash":
        cmd = args.get("command", "")
        return f'"{cmd[:65]}{"…" if len(cmd) > 65 else ""}"'
    if name == "WebSearch":
        q = args.get("query", "")
        return f'"{q[:55]}{"…" if len(q) > 55 else ""}"'
    if name == "ListDir":
        return _short_path(args.get("path", "."))
    if name.startswith("mcp__"):
        parts = name[5:].split("__", 1)
        return parts[1] if len(parts) > 1 else ""
    return ""


def print_tool_call(name: str, args: dict) -> None:
    """Print the tool call header.

    Modern:  📄 Reading  src/app.py
    Legacy:  [READ] Reading  src/app.py
    """
    c = _get_console()
    icon = _tool_icon(name)
    style = _tool_style(name)
    label = _tool_label(name, args)

    display_name = name
    if name.startswith("mcp__"):
        parts = name[5:].split("__", 1)
        display_name = f"MCP:{parts[0]}"
        label = parts[1] if len(parts) > 1 else ""

    action_verb = _action_verb(name)
    icon_display = f"[{style}]{icon}[/]"
    c.print(f"\n  {icon_display} [bold {style}]{action_verb}[/] [dim]{label}[/]")


def _action_verb(name: str) -> str:
    verbs = {
        "Read":  "Reading", "Write": "Creating", "Edit": "Editing",
        "Bash":  "Running", "Grep": "Searching", "Glob": "Finding",
        "ListDir": "Listing", "WebSearch": "Searching web",
    }
    if name.startswith("mcp__"):
        return name[5:].split("__", 1)[0]
    return verbs.get(name, name)


def print_tool_result(name: str, output: dict) -> None:
    """Print the result sub-line with status icon."""
    c = _get_console()
    if "error" in output:
        err_icon = "\u2717" if _unicode_ok() else "ERR"
        c.print(f"    [error]{err_icon} {output['error'][:100]}[/]")
        return

    hint = _tool_hint(name, output)
    if not hint:
        return

    ok_icon = "\u2713" if _unicode_ok() else "OK"
    style = _tool_style(name)
    if name in ("Write", "Edit"):
        c.print(f"    [{style}]{ok_icon}[/] [dim]{hint}[/]")
    else:
        c.print(f"    [dim]{hint}[/]")


def _tool_hint(name: str, output: dict) -> str:
    if "error" in output:
        return f"Error: {output['error'][:100]}"
    if name == "Read":
        lines = output.get("total_lines", 0)
        return f"{lines} lines read" if lines else "read"
    if name == "Write":
        written = output.get("written", 0)
        v = output.get("verification") or {}
        status = output.get("status", "created")
        base = f"{_fmt_bytes(written)} · {status}"
        if v.get("skipped"):
            return f"{base} · syntax verified · tests skipped"
        if v.get("verified"):
            return f"{base} · verified"
        if "error" in v:
            return f"{base} · verification failed"
        return base
    if name == "Edit":
        n = output.get("replacements", 1)
        v = output.get("verification") or {}
        s = f"{n} replacement{'s' if n != 1 else ''}"
        if v.get("skipped"):
            return f"{s} · syntax verified · tests skipped"
        if v.get("verified"):
            return f"{s} · verified"
        if "error" in v:
            return f"{s} · verification failed"
        return s
    if name == "Grep":
        count = output.get("count", 0)
        return f"{count} match{'es' if count != 1 else ''}"
    if name == "Glob":
        count = output.get("count", 0)
        return f"{count} file{'s' if count != 1 else ''} found"
    if name == "Bash":
        code = output.get("exit_code", 0)
        stdout = (output.get("stdout") or "").strip()
        stderr = (output.get("stderr") or "").strip()
        if code == 0 and not stdout:
            return "ok"
        if code == 0:
            first = stdout.split("\n")[0][:100]
            rest_count = len(stdout.split("\n")) - 1
            if rest_count > 0:
                return f"{first} [{rest_count} more lines]"
            return first
        first = (stderr or stdout).split("\n")[0][:80]
        return f"exit {code}" + (f" · {first}" if first else "")
    if name == "WebSearch":
        count = output.get("count", 0)
        return f"{count} result{'s' if count != 1 else ''}"
    if name == "ListDir":
        count = output.get("count", 0)
        return f"{count} item{'s' if count != 1 else ''}"
    return ""


def _fmt_bytes(n: int) -> str:
    if n < 1024:
        return f"{n}B"
    if n < 1024 * 1024:
        return f"{n / 1024:.1f}KB"
    return f"{n / (1024 * 1024):.1f}MB"


def _render_diff(old_content: str, new_content: str, file_path: str) -> None:
    """Render a unified diff with Rich markup.

    Lines prefixed with:
      -  (red)   = removed
      +  (green) = added
      ~  (dim)   = context
    """
    c = _get_console()
    old_lines = old_content.splitlines(keepends=True)
    new_lines = new_content.splitlines(keepends=True)

    diff = list(difflib.unified_diff(
        old_lines, new_lines,
        fromfile=file_path, tofile=file_path,
        n=2,
    ))
    if not diff:
        return

    removed = added = total_shown = 0
    max_each = 8
    total_delta = sum(1 for ln in diff if ln.startswith(("+", "-")) and not ln.startswith(("---", "+++")))

    for line in diff:
        if line.startswith(("---", "+++", "@@")):
            continue
        stripped = line[1:].rstrip()[:100]
        if line.startswith("-") and removed < max_each:
            c.print(f"    [red]- {stripped}[/]")
            removed += 1
        elif line.startswith("+") and added < max_each:
            c.print(f"    [green]+ {stripped}[/]")
            added += 1
        elif not line.startswith(("-", "+")):
            if total_shown < 3:
                c.print(f"    [dim]  {stripped[:100]}[/]")
                total_shown += 1

    total_shown_real = removed + added
    if total_delta > total_shown_real:
        rest = total_delta - total_shown_real
        c.print(f"    [dim]  … {rest} more change{'s' if rest != 1 else ''}[/]")


def _summarize_final(self) -> str:
    for m in reversed(self._messages):
        if m["role"] == "assistant" and isinstance(m.get("content"), str) and m["content"]:
            return str(m["content"])
    return "Task completed."


def _format_result(self, text: str, elapsed: float, steps: int,
                   *, use_markdown: bool = True) -> str:
    """Show the metrics footer after a completed response."""
    c = _get_console()

    if use_markdown and text:
        from .. import ui
        ui.render_markdown(_d(text))

    tokens_in  = getattr(self._router, "_session_input_tokens", 0)
    tokens_out = getattr(self._router, "_session_output_tokens", 0)
    total_tok  = tokens_in + tokens_out
    cost       = getattr(self._router, "_session_cost", 0.0)
    elapsed_ms = int(elapsed * 1000)
    n_tools    = getattr(self, "_tool_calls_count", 0)

    parts: list[str] = []
    if total_tok > 0:
        tok_str = f"{total_tok / 1000:.1f}k" if total_tok >= 1000 else str(total_tok)
        parts.append(f"tokens: {tok_str}")
    if cost > 0:
        parts.append(f"${cost:.4f}")
    if elapsed_ms > 0:
        if elapsed_ms < 1000:
            parts.append(f"{elapsed_ms}ms")
        elif elapsed_ms < 60_000:
            parts.append(f"{elapsed_ms / 1000:.1f}s")
        else:
            parts.append(f"{elapsed_ms / 60_000:.1f}m")
    if n_tools > 0:
        parts.append(f"{n_tools} tool{'s' if n_tools != 1 else ''}")

    if parts:
        c.print(f"\n  [dim]   {' · '.join(parts)}[/]")

    return text
