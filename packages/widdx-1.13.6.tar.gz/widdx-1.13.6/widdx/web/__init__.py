"""WIDDX Web UI — FastAPI server with SSE streaming and professional dashboard.

Start:  widdx web          (opens http://localhost:8520)
        widdx web --port 9000
        widdx web --no-open

Security:
  Set WIDDX_WEB_KEY env var to enable Bearer token authentication.
  All API endpoints (except /health) will require `Authorization: Bearer <key>`.
  Rate limiting: 60 req/min per IP on API routes, 10 req/min on /api/chat.
"""
from __future__ import annotations

import json
import logging
import os
import queue
import threading
import time
from collections import defaultdict
from pathlib import Path

logger = logging.getLogger(__name__)

try:
    from fastapi import FastAPI, Request, HTTPException, WebSocket, WebSocketDisconnect
    from fastapi.responses import StreamingResponse, HTMLResponse, JSONResponse
    from fastapi.staticfiles import StaticFiles
    import uvicorn
    HAS_WEB = True
except ImportError:
    HAS_WEB = False


_STATIC_DIR = Path(__file__).parent / "static"
_WEB_KEY = os.environ.get("WIDDX_WEB_KEY", "")

# ── Security audit logging ────────────────────────────────────────────
_security_log = logging.getLogger("widdx.web.security")


def _audit(request: Request, event: str, detail: str = "", level: str = "INFO") -> None:
    ip = request.client.host if request.client else "unknown"
    path = request.url.path
    _security_log.log(
        getattr(logging, level, logging.INFO),
        "security: %s | ip=%s | path=%s | %s",
        event, ip, path, detail,
    )


class RateLimiter:
    def __init__(self, default_limit: int = 60, window: float = 60.0):
        self._buckets: dict[str, list[float]] = defaultdict(list)
        self._default_limit = default_limit
        self._window = window
        self._last_cleanup = time.time()

    def check(self, ip: str, limit: int | None = None) -> bool:
        now = time.time()
        bucket = self._buckets[ip]
        cutoff = now - self._window
        while bucket and bucket[0] < cutoff:
            bucket.pop(0)
        effective = limit or self._default_limit
        if len(bucket) >= effective:
            return False
        bucket.append(now)
        if now - self._last_cleanup > 300:
            self._cleanup(now)
            self._last_cleanup = now
        return True

    def _cleanup(self, now: float) -> None:
        cutoff = now - self._window
        expired = [ip for ip, b in list(self._buckets.items()) if not b or b[-1] < cutoff]
        for ip in expired:
            del self._buckets[ip]


_limiter = RateLimiter()


_project_root: Path | None = None


def _get_project_root() -> Path:
    """Return resolved project root, cached."""
    global _project_root
    if _project_root is None:
        try:
            _project_root = Path.cwd().resolve()
        except (PermissionError, OSError):
            _project_root = Path.cwd().absolute()
    return _project_root


def _path_within_project(p: Path) -> bool:
    """Return True if *p* is inside (or equal to) the project root."""
    try:
        resolved = p.resolve()
    except (PermissionError, OSError):
        try:
            resolved = p.absolute()
        except (PermissionError, OSError):
            return False
    try:
        return resolved.is_relative_to(_get_project_root())
    except ValueError:
        return False


def _mask_key(key: str) -> str:
    """Return a masked preview of an API key (first 6 + last 4 chars)."""
    if not key:
        return ""
    if len(key) <= 10:
        return key[:2] + "***" + key[-2:]
    return key[:6] + "***" + key[-4:]


class WiddxWebServer:
    """Embedded web server that exposes WIDDX via a browser-based UI."""

    def __init__(self, port: int = 8520, open_browser: bool = True) -> None:
        if not HAS_WEB:
            raise ImportError("Web UI requires: pip install fastapi uvicorn")
        self._port = port
        self._open_browser = open_browser
        self._app = FastAPI(
            title="WIDDX Web UI",
            version=__import__("widdx").__version__,
            docs_url=None, redoc_url=None,
        )
        self._sessions: dict[str, dict] = {}
        self._cancel_flags: dict[str, dict[str, bool]] = {}
        self._setup_security()
        self._setup_routes()

    def _setup_security(self) -> None:
        """Add security headers middleware to all responses."""
        @self._app.middleware("http")
        async def security_headers(request: Request, call_next):
            response = await call_next(request)
            response.headers["X-Content-Type-Options"] = "nosniff"
            response.headers["X-Frame-Options"] = "DENY"
            response.headers["X-XSS-Protection"] = "1; mode=block"
            response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
            response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
            response.headers["Content-Security-Policy"] = (
                "default-src 'self'; "
                "script-src 'self' 'unsafe-inline' 'unsafe-eval'; "
                "style-src 'self' 'unsafe-inline'"
            )
            response.headers["Cache-Control"] = "no-store"
            return response

    def _auth_required(self, request: Request) -> None:
        if not _WEB_KEY:
            return
        auth = request.headers.get("authorization", "")
        if auth.lower().startswith("bearer "):
            token = auth[7:]
            if token == _WEB_KEY:
                return
        _audit(request, "AUTH_FAILURE", "Invalid or missing bearer token", "WARNING")
        raise HTTPException(status_code=401, detail="Unauthorized")

    def _rate_limit(self, request: Request, limit: int | None = None) -> None:
        ip = request.client.host if request.client else "unknown"
        if not _limiter.check(ip, limit=limit):
            _audit(request, "RATE_LIMIT", f"IP {ip} exceeded limit", "WARNING")
            raise HTTPException(status_code=429, detail="Rate limit exceeded. Try again later.")

    def _setup_routes(self) -> None:
        app = self._app

        # Mount static files (CSS, JS)
        if _STATIC_DIR.is_dir():
            app.mount("/static", StaticFiles(directory=str(_STATIC_DIR)), name="static")

        @app.get("/", response_class=HTMLResponse)
        async def index(request: Request):
            self._auth_required(request)
            self._rate_limit(request)
            return _get_html()

        @app.get("/api/status")
        async def status(request: Request):
            self._auth_required(request)
            self._rate_limit(request)
            providers = []
            try:
                from widdx.config import load_config
                from widdx.router import AIRouter
                config = load_config()
                router = AIRouter(config, None)
                providers = [p["name"] for p in router.list_providers()]
            except Exception:
                pass
            return {"status": "running", "version": __import__("widdx").__version__,
                    "providers": providers}

        @app.post("/api/chat")
        async def chat(request: Request):
            self._auth_required(request)
            self._rate_limit(request, limit=10)
            data = await request.json()
            task = data.get("task", "").strip()
            session_id = data.get("session_id", str(time.time_ns()))
            if not task:
                return JSONResponse({"error": "Empty task"}, status_code=400)
            self._get_or_create_session(session_id)
            return StreamingResponse(
                self._stream_task(task, session_id),
                media_type="text/event-stream",
                headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
            )

        @app.websocket("/ws/chat")
        async def ws_chat(ws: WebSocket):
            if _WEB_KEY:
                token = ws.headers.get("authorization", "")
                if token.lower().startswith("bearer "):
                    token = token[7:]
                if token != _WEB_KEY:
                    await ws.close(code=4001)
                    return
            await ws.accept()
            try:
                while True:
                    data = await ws.receive_json()
                    msg_type = data.get("type", "")
                    if msg_type == "start":
                        task = data.get("task", "").strip()
                        session_id = data.get("session_id", str(time.time_ns()))
                        if not task:
                            await ws.send_json({"type": "error", "text": "Empty task"})
                            continue
                        await self._ws_stream_task(ws, task, session_id)
                    elif msg_type == "cancel":
                        sid = data.get("session_id", "")
                        if sid in self._cancel_flags:
                            self._cancel_flags[sid]["cancelled"] = True
                        await ws.send_json({"type": "cancelled", "session_id": sid})
                    elif msg_type == "ping":
                        await ws.send_json({"type": "pong"})
            except WebSocketDisconnect:
                pass

        @app.get("/api/files")
        async def list_files(request: Request, path: str = "."):
            self._auth_required(request)
            self._rate_limit(request)
            p = Path(path).resolve()
            if not _path_within_project(p):
                return JSONResponse({"error": "Access denied"}, status_code=403)
            if not p.exists():
                return {"files": [], "error": f"Path not found: {path}"}
            files = []
            try:
                for item in sorted(p.iterdir()):
                    if item.name.startswith(".") or item.name == "__pycache__":
                        continue
                    files.append({
                        "name": item.name, "path": str(item),
                        "type": "dir" if item.is_dir() else "file",
                        "size": item.stat().st_size if item.is_file() else 0,
                    })
            except PermissionError:
                pass
            return {"files": files, "cwd": str(p)}

        @app.get("/api/file")
        async def read_file(request: Request, path: str):
            self._auth_required(request)
            self._rate_limit(request)
            p = Path(path).resolve()
            if not _path_within_project(p):
                return JSONResponse({"error": "Access denied"}, status_code=403)
            if not p.exists() or not p.is_file():
                return JSONResponse({"error": "File not found"}, status_code=404)
            try:
                content = p.read_text(encoding="utf-8", errors="replace")
                return {"content": content, "path": str(p), "size": p.stat().st_size}
            except Exception as e:
                return JSONResponse({"error": str(e)}, status_code=500)

        @app.get("/api/search")
        async def search(request: Request, q: str = ""):
            self._auth_required(request)
            self._rate_limit(request)
            results = []
            seen: set[str] = set()
            cwd = Path.cwd()
            exts = {
                ".py", ".js", ".ts", ".tsx", ".jsx", ".css", ".html", ".json", ".md",
                ".yml", ".yaml", ".toml", ".txt", ".cfg", ".go", ".rs",
            }
            max_depth = 5
            try:
                root_len = len(cwd.parts)
                for f in cwd.rglob("*"):
                    if not f.is_file() or f.suffix not in exts:
                        continue
                    if not _path_within_project(f):
                        continue
                    if len(f.parts) - root_len > max_depth:
                        continue
                    if any(p.startswith(".") or p == "__pycache__" or p == "node_modules" for p in f.parts):
                        continue
                    try:
                        rel = str(f.relative_to(cwd))
                        if rel in seen:
                            continue
                        seen.add(rel)
                        content = f.read_text(encoding="utf-8", errors="ignore")
                        if q.lower() not in content.lower():
                            continue
                        for i, cl in enumerate(content.split("\n")):
                            if q.lower() in cl.lower():
                                results.append({"file": rel, "line": str(i+1), "content": cl.strip()[:160]})
                                if len(results) >= 30:
                                    break
                        if len(results) >= 30:
                            break
                    except (OSError, UnicodeDecodeError):
                        pass
            except Exception:
                pass
            return {"results": results, "query": q}

        @app.get("/api/health")
        async def health(request: Request):
            self._rate_limit(request)
            providers = []
            try:
                from widdx.config import load_config
                from widdx.router import AIRouter
                config = load_config()
                router = AIRouter(config, None)
                providers = router.list_providers()
            except Exception:
                pass
            return {"status": "healthy", "python": True, "providers": [p["name"] for p in providers]}

        @app.get("/api/config")
        async def get_config(request: Request):
            self._auth_required(request)
            self._rate_limit(request)
            try:
                from widdx.config import load_config
                config = load_config()
                dk = config.get("__env__", {}).get("deepseek_key") or ""
                gk = config.get("__env__", {}).get("google_key") or ""
                return {
                    "deepseek": {"configured": bool(dk), "preview": _mask_key(dk)},
                    "google": {"configured": bool(gk), "preview": _mask_key(gk)},
                    "needs_setup": not dk and not gk,
                }
            except Exception:
                return {"error": "Failed to load config", "needs_setup": True}

        @app.post("/api/config/key")
        async def save_config_key(request: Request):
            self._auth_required(request)
            self._rate_limit(request)
            try:
                data = await request.json()
                provider = data.get("provider", "").strip()
                api_key = data.get("api_key", "").strip()
                if provider not in ("deepseek", "google"):
                    return JSONResponse({"error": "Invalid provider"}, status_code=400)
                if not api_key or len(api_key) < 10:
                    return JSONResponse({"error": "Invalid API key"}, status_code=400)
                from widdx.config import save_config_key
                config_key = f"{provider}_api_key"
                env_key = f"{provider.upper()}_API_KEY"
                save_config_key(config_key, api_key)
                # Also set runtime env var for immediate use
                import os
                os.environ[env_key] = api_key
                return {"status": "saved", "provider": provider, "preview": _mask_key(api_key)}
            except Exception as e:
                logger.exception("Failed to save config key")
                return JSONResponse({"error": str(e)}, status_code=500)

        @app.get("/api/config/status")
        async def config_status(request: Request):
            self._auth_required(request)
            self._rate_limit(request)
            try:
                from widdx.config import load_config
                config = load_config()
                dk = config.get("__env__", {}).get("deepseek_key")
                gk = config.get("__env__", {}).get("google_key")
                needs_setup = not dk and not gk
                has_providers = bool(dk or gk)
                return {"needs_setup": needs_setup, "has_providers": has_providers}
            except Exception:
                return {"needs_setup": True, "has_providers": False}

        @app.get("/api/project")
        async def project_info(request: Request):
            self._auth_required(request)
            self._rate_limit(request)
            cwd = Path.cwd()
            files = []
            try:
                files = [f.name for f in sorted(cwd.iterdir())
                        if not f.name.startswith(".") and f.is_file()][:20]
            except Exception:
                pass
            return {"cwd": str(cwd), "name": cwd.name, "files": files,
                    "files_count": len(list(cwd.glob("*")))}

        @app.get("/api/git/status")
        async def git_status(request: Request):
            self._auth_required(request)
            self._rate_limit(request)
            import subprocess
            try:
                r = subprocess.run(["git", "rev-parse", "--abbrev-ref", "HEAD"],
                                   capture_output=True, text=True, timeout=5, cwd=Path.cwd())
                branch = r.stdout.strip() if r.returncode == 0 else ""
            except Exception:
                branch = ""
            try:
                r = subprocess.run(["git", "status", "--porcelain"],
                                   capture_output=True, text=True, timeout=5, cwd=Path.cwd())
                if r.returncode == 0:
                    modified = [
                        line[3:].strip()
                        for line in r.stdout.strip().split("\n")
                        if line.strip()
                    ]
                else:
                    modified = []
            except Exception:
                modified = []
            dirty = len(modified) > 0
            return {
                "branch": branch,
                "dirty": dirty,
                "modified": modified[:50],
                "count": len(modified),
            }
        @app.get("/api/agents")
        async def list_agents(request: Request):
            self._auth_required(request)
            self._rate_limit(request)
            try:
                from widdx.agents import AgentRegistry
                reg = AgentRegistry()
                agents = reg.list_agents()
                result = []
                for a in agents:
                    if isinstance(a, dict):
                        result.append({"name": a.get("name", ""), "desc": a.get("description", "")})
                    elif isinstance(a, str):
                        result.append({"name": a, "desc": ""})
                return result
            except Exception:
                return [{"name": "Backend Architect", "desc": "Backend API design and server-side development"},
                        {"name": "Frontend Developer", "desc": "Builds responsive, accessible web UIs"},
                        {"name": "DevOps Automator", "desc": "Containerizes apps, sets up CI/CD"},
                        {"name": "QA Engineer", "desc": "Writes tests, runs linters, ensures quality"},
                        {"name": "Software Architect", "desc": "Plans system, defines tech stack"},
                        {"name": "Full-Stack Developer", "desc": "Handles both frontend and backend"},
                        {"name": "Security Reviewer", "desc": "Security auditing and vulnerability assessment"},
                        {"name": "Data Engineer", "desc": "ETL pipelines, data warehouses, optimization"},
                        {"name": "Code Reviewer", "desc": "Code review with constructive feedback"},
                        {"name": "Laravel Architect", "desc": "Laravel full-stack development"},
                        {"name": "Systems Architect", "desc": "High-level architecture for large projects"},
                        {"name": "Database Architect", "desc": "Database design, query optimization"}]

        @app.get("/api/skills")
        async def list_skills(request: Request):
            self._auth_required(request)
            self._rate_limit(request)
            try:
                from widdx.skills import SkillManager
                sm = SkillManager()
                sm.load()
                skills = sm.list_skills()
                return [{"name": name, "desc": desc} for name, desc in skills]
            except Exception:
                return []

        @app.post("/api/file/save")
        async def save_file(request: Request):
            self._auth_required(request)
            self._rate_limit(request)
            data = await request.json()
            path = data.get("path", "").strip()
            content = data.get("content", "")
            if not path:
                return JSONResponse({"error": "Path is required"}, status_code=400)
            try:
                p = Path(path).resolve()
                if not _path_within_project(p):
                    return JSONResponse({"error": "Access denied"}, status_code=403)
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(content, encoding="utf-8")
                return {"status": "saved", "path": str(p), "size": len(content)}
            except Exception as e:
                return JSONResponse({"error": str(e)}, status_code=500)

        @app.post("/api/file/create")
        async def create_file(request: Request):
            self._auth_required(request)
            self._rate_limit(request)
            data = await request.json()
            path = data.get("path", "").strip()
            if not path:
                return JSONResponse({"error": "Path is required"}, status_code=400)
            try:
                p = Path(path).resolve()
                if not _path_within_project(p):
                    return JSONResponse({"error": "Access denied"}, status_code=403)
                if p.exists():
                    return JSONResponse({"error": "File already exists"}, status_code=409)
                p.parent.mkdir(parents=True, exist_ok=True)
                p.touch()
                return {"status": "created", "path": str(p)}
            except Exception as e:
                return JSONResponse({"error": str(e)}, status_code=500)

        @app.post("/api/file/delete")
        async def delete_file(request: Request):
            self._auth_required(request)
            self._rate_limit(request)
            data = await request.json()
            path = data.get("path", "").strip()
            if not path:
                return JSONResponse({"error": "Path is required"}, status_code=400)
            try:
                p = Path(path).resolve()
                if not _path_within_project(p):
                    return JSONResponse({"error": "Access denied"}, status_code=403)
                if not p.exists():
                    return JSONResponse({"error": "File not found"}, status_code=404)
                if p.is_dir():
                    import shutil
                    shutil.rmtree(p)
                else:
                    p.unlink()
                return {"status": "deleted", "path": str(p)}
            except Exception as e:
                return JSONResponse({"error": str(e)}, status_code=500)

        @app.post("/api/file/rename")
        async def rename_file(request: Request):
            self._auth_required(request)
            self._rate_limit(request)
            data = await request.json()
            old_path = data.get("old_path", "").strip()
            new_path = data.get("new_path", "").strip()
            if not old_path or not new_path:
                return JSONResponse({"error": "Both paths are required"}, status_code=400)
            try:
                p_old = Path(old_path).resolve()
                p_new = Path(new_path).resolve()
                if not _path_within_project(p_old) or not _path_within_project(p_new):
                    return JSONResponse({"error": "Access denied"}, status_code=403)
                if not p_old.exists():
                    return JSONResponse({"error": "Source file not found"}, status_code=404)
                if p_new.exists():
                    return JSONResponse({"error": "Destination already exists"}, status_code=409)
                p_old.rename(p_new)
                return {"status": "renamed", "old_path": str(p_old), "new_path": str(p_new)}
            except Exception as e:
                return JSONResponse({"error": str(e)}, status_code=500)

        @app.post("/api/folder/create")
        async def create_folder(request: Request):
            self._auth_required(request)
            self._rate_limit(request)
            data = await request.json()
            path = data.get("path", "").strip()
            if not path:
                return JSONResponse({"error": "Path is required"}, status_code=400)
            try:
                p = Path(path).resolve()
                if not _path_within_project(p):
                    return JSONResponse({"error": "Access denied"}, status_code=403)
                if p.exists():
                    return JSONResponse({"error": "Folder already exists"}, status_code=409)
                p.mkdir(parents=True, exist_ok=True)
                return {"status": "created", "path": str(p)}
            except Exception as e:
                return JSONResponse({"error": str(e)}, status_code=500)

    def _get_or_create_session(self, session_id: str) -> dict:
        if session_id not in self._sessions:
            if len(self._sessions) >= 100:
                self._purge_sessions()
            self._sessions[session_id] = {
                "id": session_id, "created_at": time.time(),
                "history": [], "created_files": [], "edited_files": [],
            }
        return self._sessions[session_id]

    def _purge_sessions(self) -> None:
        now = time.time()
        expired = [sid for sid, s in self._sessions.items() if now - s["created_at"] > 3600]
        for sid in expired:
            del self._sessions[sid]

    async def _stream_task(self, task: str, session_id: str):
        q: queue.Queue = queue.Queue()
        yield f"data: {json.dumps({'type': 'start', 'task': task})}\n\n"

        cancel_flag: dict[str, bool] = {"cancelled": False}
        self._cancel_flags[session_id] = cancel_flag

        thread = threading.Thread(target=self._run_task_in_thread, args=(task, session_id, q, cancel_flag), daemon=True)
        thread.start()

        last_hb = time.time()
        while thread.is_alive() or not q.empty():
            try:
                event = q.get(timeout=0.1)
                yield f"data: {json.dumps(event, default=str)}\n\n"
                last_hb = time.time()
            except queue.Empty:
                if time.time() - last_hb > 1:
                    yield f"data: {json.dumps({'type': 'heartbeat'})}\n\n"
                    last_hb = time.time()
        yield f"data: {json.dumps({'type': 'closed'})}\n\n"

    async def _ws_stream_task(self, ws: WebSocket, task: str, session_id: str):
        q: queue.Queue = queue.Queue()
        await ws.send_json({"type": "start", "task": task})

        cancel_flag: dict[str, bool] = {"cancelled": False}
        self._cancel_flags[session_id] = cancel_flag

        thread = threading.Thread(target=self._run_task_in_thread, args=(task, session_id, q, cancel_flag), daemon=True)
        thread.start()

        last_hb = time.time()
        while thread.is_alive() or not q.empty():
            try:
                event = q.get(timeout=0.1)
                await ws.send_json(event)
                last_hb = time.time()
            except queue.Empty:
                if time.time() - last_hb > 1:
                    await ws.send_json({"type": "heartbeat"})
                    last_hb = time.time()
            except (WebSocketDisconnect, RuntimeError):
                cancel_flag["cancelled"] = True
                thread.join(timeout=3)
                return

        try:
            await ws.send_json({"type": "closed"})
        except (WebSocketDisconnect, RuntimeError):
            pass
        finally:
            self._cancel_flags.pop(session_id, None)

    def _run_task_in_thread(self, task: str, session_id: str, q: queue.Queue, cancel_flag: dict[str, bool]):
        try:
            from widdx.config import load_config
            from widdx.memory import MemoryStore
            from widdx.router import AIRouter
            config = load_config()
            memory = MemoryStore(config.get("memory", {}).get("db_path", "~/.widdx/memory.db"))
            router = AIRouter(config, memory)

            session = self._get_or_create_session(session_id)

            # ── 1. Analyze task ──────────────────────────────────
            if cancel_flag["cancelled"]:
                return
            task_type = router.infer_task_type(task)
            complexity = router.classify(task)
            q.put({"type": "analysis", "task_type": task_type, "complexity": complexity,
                   "intent": task[:120]})

            # ── 2. Select agents automatically based on task ──────
            if cancel_flag["cancelled"]:
                return
            lowered = task.lower()
            selected_agents = []
            agent_rules = {
                "architect": (
                    ["architecture", "design", "plan", "system", "scaffold", "build"],
                    "Planning & Design", "architect",
                ),
                "backend": (
                    ["api", "backend", "server", "database", "laravel", "fastapi",
                     "django", "rest"],
                    "Backend Development", "executor",
                ),
                "frontend": (
                    ["frontend", "ui", "vue", "react", "angular", "css", "html",
                     "dashboard"],
                    "Frontend Development", "executor",
                ),
                "security": (
                    ["security", "vulnerability", "audit", "owasp", "auth",
                     "permission"],
                    "Security Review", "executor",
                ),
                "devops": (
                    ["deploy", "docker", "ci/cd", "pipeline", "kubernetes",
                     "infrastructure"],
                    "DevOps & Deployment", "executor",
                ),
                "qa": (
                    ["test", "quality", "lint", "coverage", "assertion"],
                    "Quality Assurance", "executor",
                ),
                "data": (
                    ["data", "etl", "pipeline", "analytics", "warehouse"],
                    "Data Engineering", "executor",
                ),
                "review": (
                    ["review", "refactor", "improve", "optimize", "clean"],
                    "Code Review", "executor",
                ),
            }

            for agent_name, (keywords, role_label, router_role) in agent_rules.items():
                if any(kw in lowered for kw in keywords):
                    selected_agents.append({
                        "name": agent_name.title(),
                        "role": role_label,
                        "router_role": router_role,
                    })

            # Always include architect for build/design tasks
            if any(kw in lowered for kw in ["build", "create", "generate", "implement", "scaffold"]):
                if not any(a["name"] == "Architect" for a in selected_agents):
                    selected_agents.insert(0, {
                        "name": "Architect",
                        "role": "Planning & Design",
                        "router_role": "architect",
                    })

            if not selected_agents:
                # Default: use executor for general tasks
                selected_agents.append({
                    "name": "Executor",
                    "role": "General Execution",
                    "router_role": "executor",
                })

            # ── 3. Assign models to agents ───────────────────────
            if cancel_flag["cancelled"]:
                return
            providers = router._providers_for_role("executor")
            arch_providers = router._providers_for_role("architect")
            used_provs = set()
            for agent in selected_agents:
                rr = agent["router_role"]
                if rr == "architect":
                    ps = arch_providers
                else:
                    ps = providers
                if ps:
                    # Distribute providers round-robin among agents
                    idx = len(used_provs) % len(ps)
                    p = ps[idx]
                    agent["provider"] = p["name"]
                    agent["model"] = p.get("architect_model" if rr == "architect" else "executor_model", "?")
                    used_provs.add(p["name"])
                else:
                    agent["provider"] = "opencode"
                    agent["model"] = "deepseek-v4-flash-free"

            q.put({"type": "agents_selected", "agents": selected_agents,
                   "task_type": task_type, "complexity": complexity})

            # ── 4. Run execution with ToolLoop ────────────────────
            if cancel_flag["cancelled"]:
                return
            from widdx.tool_loop import ToolLoop
            import widdx.tool_loop.display as dm
            import widdx.tool_loop as tl
            _orig_call = dm.print_tool_call
            _orig_result = dm.print_tool_result

            def _cap_call(name, args):
                q.put({"type": "tool_call", "name": name, "args": args})

            def _cap_result(name, output):
                q.put({"type": "tool_result", "name": name, "output": output})

            dm.print_tool_call = _cap_call
            dm.print_tool_result = _cap_result
            tl.print_tool_call = _cap_call
            tl.print_tool_result = _cap_result

            q.put({"type": "pipeline_stage", "stage": "execution", "label": "Executing task..."})
            loop = ToolLoop(router, max_steps=15)
            result = loop.run(task)

            # Restore originals
            dm.print_tool_call = _orig_call
            dm.print_tool_result = _orig_result

            session["history"].append({"role": "user", "content": task})
            session["history"].append({"role": "assistant", "content": result[:2000]})
            created = list(loop._created_files) if hasattr(loop, '_created_files') else []
            edited = list(loop._edited_files) if hasattr(loop, '_edited_files') else []

            q.put({"type": "done", "result": result[:5000],
                   "files": {"created": created, "edited": edited},
                   "agents": selected_agents})
        except Exception as e:
            logger.exception("Task execution failed")
            q.put({"type": "error", "text": str(e)[:500]})

    def run(self) -> None:
        print(f"\n  ◆ WIDDX Web UI  →  http://localhost:{self._port}")
        if _WEB_KEY:
            print(f"  ◆ Auth: Bearer token required (set WIDDX_WEB_KEY)")
        else:
            print(f"  ◆ Auth: none (set WIDDX_WEB_KEY env var to enable)")
        print(f"  ◆ Rate limit: 60 req/min (10 req/min on /api/chat)")
        print(f"  ◆ Press Ctrl+C to stop\n")
        if self._open_browser:
            threading.Timer(1.0, lambda: __import__("webbrowser").open(
                f"http://localhost:{self._port}")).start()
        uvicorn.run(self._app, host="0.0.0.0", port=self._port, log_level="warning")


_TEMPLATE_DIR = Path(__file__).parent / "templates"
_TEMPLATE_CACHE: str | None = None
_TEMPLATE_MTIME: float = 0.0


def _get_html() -> str:
    global _TEMPLATE_CACHE, _TEMPLATE_MTIME
    path = _TEMPLATE_DIR / "index.html"
    mtime = path.stat().st_mtime if path.exists() else 0
    if _TEMPLATE_CACHE is None or mtime > _TEMPLATE_MTIME:
        _TEMPLATE_CACHE = path.read_text(encoding="utf-8")
        _TEMPLATE_MTIME = mtime
    return _TEMPLATE_CACHE.replace("{{VERSION}}", __import__("widdx").__version__)


def start_web_server(port: int = 8520, open_browser: bool = True) -> None:
    if not HAS_WEB:
        print("Web UI requires: pip install fastapi uvicorn")
        return
    server = WiddxWebServer(port=port, open_browser=open_browser)
    server.run()
