from quapp_common.config.logging_config import job_logger
from quapp_common.factory.handler_factory import HandlerFactory
from quapp_common.handler.handler import Handler

from ..handler.invocation_handler import InvocationHandler
from ..handler.job_fetching_handler import SlurmJobFetchingHandler


class HpcHandlerFactory(HandlerFactory):

    @staticmethod
    def create_handler(event, circuit_preparation_fn, post_processing_fn) -> Handler:
        request_data = event.json()
        logger = job_logger(request_data.get("jobId"))

        provider_job_id = request_data.get("providerJobId")

        if provider_job_id:
            logger.debug(f"HpcHandlerFactory: job fetching (slurmJobId={provider_job_id})")
            return SlurmJobFetchingHandler(
                request_data=request_data,
                post_processing_fn=post_processing_fn,
            )

        logger.debug("HpcHandlerFactory: initial invocation")
        return InvocationHandler(
            request_data=request_data,
            circuit_preparation_fn=circuit_preparation_fn,
            post_processing_fn=post_processing_fn,
        )
