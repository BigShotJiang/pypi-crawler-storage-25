from quapp_common.config.logging_config import job_logger
from quapp_common.model.provider.provider import Provider

from ..model.device.slurm_device import SlurmDevice

logger = job_logger('HpcDeviceFactory')


class HpcDeviceFactory:

    @staticmethod
    def create_device(
        provider: Provider,
        device_specification: str,
        job_uuid: str,
        hpc_config: dict = None,
    ) -> SlurmDevice:
        logger.debug(f"Creating SlurmDevice: partition={device_specification}")
        return SlurmDevice(provider, device_specification, job_uuid, hpc_config=hpc_config)
