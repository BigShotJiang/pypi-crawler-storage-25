import os
from quapp_common.enum.provider_tag import ProviderTag
from quapp_common.config.logging_config import job_logger

from ..model.provider.slurm_provider import SlurmProvider

logger = job_logger('HpcProviderFactory')

SLURM_JWT = os.getenv("SLURM_JWT", "")


class HpcProviderFactory:

    @staticmethod
    def create_provider(provider_type: ProviderTag, authentication: dict):
        logger.debug(f"Creating HPC provider: {provider_type}")

        if provider_type == ProviderTag.QUAPP_HPC:
            jwt = authentication.get("slurm_jwt") or SLURM_JWT
            if not jwt:
                raise ValueError("SLURM_JWT not set — cannot authenticate with Slurm API")
            return SlurmProvider(jwt_token=jwt)

        raise NotImplementedError(f"Unsupported HPC provider: {provider_type}")
