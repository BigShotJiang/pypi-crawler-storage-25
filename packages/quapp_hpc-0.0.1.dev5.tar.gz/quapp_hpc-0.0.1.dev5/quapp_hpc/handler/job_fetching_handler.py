from quapp_common.data.request.job_fetching_request import JobFetchingRequest
from quapp_common.handler.handler import Handler

from ..component.backend.slurm_job_fetching import SlurmJobFetching


class SlurmJobFetchingHandler(Handler):
    """Handles watchdog-triggered job status polls for Slurm jobs."""

    def __init__(self, request_data: dict, post_processing_fn):
        super().__init__(request_data, post_processing_fn)

    def handle(self):
        self.logger.debug("SlurmJobFetchingHandler: start")
        request = JobFetchingRequest(self.request_data)
        return SlurmJobFetching(request).fetch(
            post_processing_fn=self.post_processing_fn
        )
