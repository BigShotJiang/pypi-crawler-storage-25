from quapp_common.data.request.invocation_request import InvocationRequest
from quapp_common.handler.handler import Handler

from ..component.backend.hpc_invocation import HpcInvocation


class InvocationHandler(Handler):

    def __init__(self, request_data: dict, circuit_preparation_fn, post_processing_fn):
        super().__init__(request_data, post_processing_fn)
        self.circuit_preparation_fn = circuit_preparation_fn

    def handle(self):
        self.logger.debug("HPC InvocationHandler: start")
        try:
            invocation_request = InvocationRequest(self.request_data)
            HpcInvocation(invocation_request).submit_job(
                circuit_preparation_fn=self.circuit_preparation_fn,
                post_processing_fn=self.post_processing_fn,
            )
        except Exception as exc:
            self.logger.exception(f"HPC invocation failed: {exc}")
            raise
