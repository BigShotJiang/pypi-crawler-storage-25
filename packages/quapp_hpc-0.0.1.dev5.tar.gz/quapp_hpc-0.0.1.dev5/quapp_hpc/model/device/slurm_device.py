import base64
import json
import os
import shlex
import time

import boto3
import requests
from quapp_common.config.logging_config import job_logger
from quapp_common.data.device.circuit_running_option import CircuitRunningOption
from quapp_common.enum.status.job_status import JobStatus
from quapp_common.model.device.device import Device
from quapp_common.model.provider.provider import Provider

from ..provider.slurm_provider import SlurmProvider, SLURM_ACCOUNT

# ── System config (read from K8s secret slurm-credentials at ksvc startup) ───
S3_BUCKET         = os.getenv("S3_BUCKET",               "quapp-slurm-output-dev")
AWS_REGION        = os.getenv("AWS_REGION",               "ap-southeast-1")
SLURM_POLL_SEC    = int(os.getenv("SLURM_POLL_SEC",      "30"))
SLURM_TIMEOUT_SEC = int(os.getenv("SLURM_TIMEOUT_SEC",   "21600"))  # 6 hours
SLURM_TIME_LIMIT  = int(os.getenv("SLURM_TIME_LIMIT_MIN", "60"))

# ── Compute runtime config (injected by builder when creating ksvc) ──────────
# Builder sets these env vars based on the function's qapp_compute_runtime row.
# The path is resolved per-function: /data/containers/functions/<fn_hash>_<fn_tag>.sif
# CTS knative_builder/function/handler.sh adds these via --env to `kn ksvc create`.
COMPUTE_SIF_PATH   = os.getenv("COMPUTE_SIF_PATH")
COMPUTE_ENTRYPOINT = os.getenv("COMPUTE_ENTRYPOINT", "python3 /tmp/quapp_job.py")
COMPUTE_SCRIPT_EXT = os.getenv("COMPUTE_SCRIPT_EXT", "py")

_TERMINAL_STATES = {"COMPLETED", "FAILED", "CANCELLED", "TIMEOUT", "NODE_FAIL", "PREEMPTED"}
_DONE_STATE      = "COMPLETED"

_SLURM_TERMINAL_TO_JOB_STATUS = {
    "COMPLETED":   JobStatus.DONE.value,
    "FAILED":      JobStatus.ERROR.value,
    "CANCELLED":   JobStatus.ERROR.value,
    "TIMEOUT":     JobStatus.ERROR.value,
    "NODE_FAIL":   JobStatus.ERROR.value,
    "PREEMPTED":   JobStatus.ERROR.value,
}

_COLLECT_PY = (
    "import json, os; "
    "ec = int(open('/tmp/quapp_exit_code.txt').read().strip()) "
    "if os.path.exists('/tmp/quapp_exit_code.txt') else 0; "
    "out = open('/tmp/quapp_stdout.txt').read() "
    "if os.path.exists('/tmp/quapp_stdout.txt') else ''; "
    "err = open('/tmp/quapp_stderr.txt').read() "
    "if os.path.exists('/tmp/quapp_stderr.txt') else ''; "
    "json.dump({'exit_code': ec, 'stdout': out, 'stderr': err}, open('/tmp/output.json','w'))"
)


def _resolve_compute_container(container_cfg: dict) -> tuple[str, str, str]:
    """Resolve Apptainer image path, entrypoint command, and script extension.

    Resolution order (first match wins):
      1. User override via invocation `container`:
           container.type = 'sif'    + container.image  →  /data/containers/<image>
           container.type = 'docker' + container.image  →  docker://<image>
      2. Builder-injected env vars (per-function SIF from build step):
           COMPUTE_SIF_PATH + COMPUTE_ENTRYPOINT + COMPUTE_SCRIPT_EXT
      3. Hard error — no valid configuration. Container is mandatory; running user
         scripts on bare metal is not supported (see HPC design philosophy).
    """
    container_type = (container_cfg or {}).get("type", "").lower()
    user_image     = (container_cfg or {}).get("image", "")
    user_entry     = (container_cfg or {}).get("entrypoint")
    user_ext       = (container_cfg or {}).get("script_extension")

    # 1. User override — explicit container choice in invocation input
    if container_type in ("sif", "docker"):
        if not user_image:
            raise ValueError(
                f"container.type={container_type!r} requires container.image"
            )
        if container_type == "sif":
            sif_path = f"/data/containers/{user_image}"
        else:
            sif_path = f"docker://{user_image}"
        return (
            sif_path,
            user_entry or COMPUTE_ENTRYPOINT,
            user_ext   or COMPUTE_SCRIPT_EXT,
        )

    # 2. Builder-injected default — per-function SIF built at deploy time
    if COMPUTE_SIF_PATH:
        return (COMPUTE_SIF_PATH, COMPUTE_ENTRYPOINT, COMPUTE_SCRIPT_EXT)

    # 3. No path resolved → fail explicitly. Running outside a container is not
    # supported per the Quapp-HPC design philosophy (container-first sandboxing).
    raise RuntimeError(
        "No compute container configured. Either the function pod is missing the "
        "COMPUTE_SIF_PATH env var (builder did not produce a per-function SIF — "
        "rebuild required) or the invocation must explicitly provide "
        "container.type and container.image."
    )


class SlurmDevice(Device):

    def __init__(
        self,
        provider: Provider,
        device_specification: str,
        job_uuid: str,
        hpc_config: dict = None,
    ):
        super().__init__(provider, device_specification)
        self.job_uuid:  str          = job_uuid
        self.slurm:     SlurmProvider = provider
        self.logger                  = job_logger(job_uuid)
        self.hpc_config              = hpc_config or {}
        # S3 bucket is a system field — read only from env (no input override).
        # Per HPC design philosophy: system fields are not user-controlled.
        self.s3_bucket               = S3_BUCKET

    # ── Abstract method implementations ──────────────────────────────────────

    def _is_simulator(self) -> bool:
        return False

    def _create_job(self, circuit: str, options: CircuitRunningOption) -> dict:
        """Wrap circuit (user script string) in SBATCH infrastructure and submit to Slurm REST API."""
        bash = self._build_sbatch_script(circuit)

        payload = {
            "job": {
                "name":    f"quapp-{self.job_uuid[:8]}",
                "account": SLURM_ACCOUNT,
                "environment": [
                    "PATH=/usr/bin:/bin:/usr/local/bin",
                    f"AWS_DEFAULT_REGION={AWS_REGION}",
                ],
                "time_limit": {
                    "number":   SLURM_TIME_LIMIT,
                    "set":      True,
                    "infinite": False,
                },
                "partition": self.device,
                "current_working_directory": "/data/jobs",
                "standard_output": f"/data/jobs/{self.job_uuid}.out",
                "standard_error":  f"/data/jobs/{self.job_uuid}.err",
            },
            "script": bash,
        }

        resp = requests.post(
            f"{self.slurm.base_url}/job/submit",
            headers=self.slurm.auth_headers(),
            json=payload,
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json()
        slurm_job_id = data.get("job_id") or data.get("jobId")

        if not slurm_job_id:
            raise RuntimeError(f"Slurm submit response missing job_id: {data}")

        self.logger.info(f"Slurm job submitted: slurm_job_id={slurm_job_id}")
        return {"slurm_job_id": str(slurm_job_id), "job_uuid": self.job_uuid}

    def _get_provider_job_id(self, job: dict) -> str:
        return job["slurm_job_id"]

    def _get_job_status(self, job: dict) -> str:
        state = self._fetch_slurm_state(job["slurm_job_id"])
        return _SLURM_TERMINAL_TO_JOB_STATUS.get(state, state)

    def _get_job_result(self, job: dict):
        """Block until Slurm job finishes, then download result from S3."""
        slurm_job_id = job["slurm_job_id"]
        job_uuid     = job["job_uuid"]

        elapsed = 0
        while elapsed < SLURM_TIMEOUT_SEC:
            state = self._fetch_slurm_state(slurm_job_id)
            self.logger.debug(f"Slurm job {slurm_job_id} state: {state}")

            if state == _DONE_STATE:
                return self._download_s3_result(job_uuid)

            if state in _TERMINAL_STATES:
                raise RuntimeError(f"Slurm job {slurm_job_id} ended with state: {state}")

            time.sleep(SLURM_POLL_SEC)
            elapsed += SLURM_POLL_SEC

        raise TimeoutError(f"Slurm job {slurm_job_id} timed out after {SLURM_TIMEOUT_SEC}s")

    def _produce_histogram_data(self, job_result) -> None:
        return None

    def _calculate_execution_time(self, job_result) -> None:
        self.execution_time = None

    # ── SBATCH script builder ─────────────────────────────────────────────────

    def _build_sbatch_script(self, user_script: str) -> str:
        """Build the full SBATCH bash script that wraps the user's computation.

        Container resolution (see _resolve_compute_container):
          - Default: per-function SIF built at deploy time, identified by env
            COMPUTE_SIF_PATH + COMPUTE_ENTRYPOINT + COMPUTE_SCRIPT_EXT
          - Override: invocation `container` block can point at a shared SIF or
            pull a Docker image at runtime

        The user script string is base64-encoded into the SBATCH script and
        written to /tmp/quapp_job.<ext> on the compute node, then executed
        through Apptainer with the configured entrypoint.
        """
        resources      = self.hpc_config.get("resources", {})
        container      = self.hpc_config.get("container", {})
        environment    = self.hpc_config.get("environment", {})
        input_s3_paths = self.hpc_config.get("input_s3_paths", [])

        sif_path, entrypoint, script_ext = _resolve_compute_container(container)
        script_file = f"/tmp/quapp_job.{script_ext}"

        # Entrypoint may reference the canonical filename; rewrite to actual extension
        entrypoint_resolved = entrypoint.replace("/tmp/quapp_job.py", script_file) \
                                       .replace("/tmp/quapp_job.sh", script_file)

        self.logger.info(
            "Compute container resolved: sif=%s entrypoint=%s script_file=%s",
            sif_path, entrypoint_resolved, script_file,
        )

        lines = ["#!/bin/bash"]

        # ── SBATCH directives ─────────────────────────────────────────────────
        gpus = int(resources.get("gpus", 0))
        memory_mb = (resources.get("memoryMb")
                     or resources.get("memory_mb")
                     or int(resources.get("memory_gb", 4)) * 1024)
        lines += [
            f"#SBATCH --account=quapp",
            f"#SBATCH --partition={resources.get('partition', 'cpu')}",
            f"#SBATCH --nodes={resources.get('nodes', 1)}",
            f"#SBATCH --ntasks={resources.get('ntasks', 1)}",
            f"#SBATCH --cpus-per-task={resources.get('cpus_per_task', 1)}",
            f"#SBATCH --mem={memory_mb}M",
            f"#SBATCH --time={resources.get('walltime') or resources.get('time_limit', '01:00:00')}",
        ]
        if gpus > 0:
            gpu_type = resources.get("gpu_type", "")
            gres = f"gpu:{gpu_type}:{gpus}" if gpu_type else f"gpu:{gpus}"
            lines.append(f"#SBATCH --gres={gres}")
        lines.append("")

        # ── Runtime setup ─────────────────────────────────────────────────────
        lines += ["set -euo pipefail", "module load apptainer 2>/dev/null || true", ""]

        # ── Download S3 input files ───────────────────────────────────────────
        if input_s3_paths:
            lines.append("mkdir -p /tmp/quapp_inputs")
            for path in input_s3_paths:
                lines.append(f"aws s3 cp {shlex.quote(path)} /tmp/quapp_inputs/")
            lines.append("")

        # ── Extra environment variables ───────────────────────────────────────
        for k, v in environment.items():
            lines.append(f"export {k}={shlex.quote(str(v))}")
        if environment:
            lines.append("")

        # ── Write and run user script inside Apptainer ────────────────────────
        b64 = base64.b64encode(user_script.encode()).decode()
        exec_prefix = f"apptainer exec {shlex.quote(sif_path)}" \
            if not sif_path.startswith("docker://") \
            else f"apptainer exec {sif_path}"
        lines += [
            f"echo {shlex.quote(b64)} | base64 -d > {script_file}",
            f"chmod +x {script_file}",
            "",
            f"{exec_prefix} {entrypoint_resolved} > /tmp/quapp_stdout.txt 2>/tmp/quapp_stderr.txt || true",
            "echo $? > /tmp/quapp_exit_code.txt",
            "",
        ]

        # ── Collect output and upload to S3 ──────────────────────────────────
        s3_uri = f"s3://{self.s3_bucket}/{self.job_uuid}/output.json"
        lines += [
            f"python3 -c {shlex.quote(_COLLECT_PY)}",
            f"aws s3 cp /tmp/output.json {shlex.quote(s3_uri)}",
        ]

        return "\n".join(lines)

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _fetch_slurm_state(self, slurm_job_id: str) -> str:
        resp = requests.get(
            f"{self.slurm.base_url}/job/{slurm_job_id}",
            headers=self.slurm.auth_headers(),
            timeout=15,
        )
        resp.raise_for_status()
        data = resp.json()

        jobs = data.get("jobs", [data])
        if not jobs:
            return "UNKNOWN"

        raw_state = jobs[0].get("job_state", "UNKNOWN")
        if isinstance(raw_state, list):
            raw_state = raw_state[0] if raw_state else "UNKNOWN"

        return str(raw_state).strip()

    def _download_s3_result(self, job_uuid: str) -> dict:
        s3_key = f"{job_uuid}/output.json"
        self.logger.info(f"Downloading result from s3://{self.s3_bucket}/{s3_key}")

        s3   = boto3.client("s3", region_name=AWS_REGION)
        resp = s3.get_object(Bucket=self.s3_bucket, Key=s3_key)
        return json.loads(resp["Body"].read())
