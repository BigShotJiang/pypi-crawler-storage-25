import os
import requests
from quapp_common.config.logging_config import job_logger
from quapp_common.enum.provider_tag import ProviderTag
from quapp_common.model.provider.provider import Provider

logger = job_logger('SlurmProvider')

SLURM_API_URL  = os.getenv("SLURM_API_URL",  "http://10.1.0.15:6820")
SLURM_API_VER  = os.getenv("SLURM_API_VER",  "v0.0.40")
SLURM_USERNAME = os.getenv("SLURM_USERNAME", "quapp-svc")
SLURM_ACCOUNT  = os.getenv("SLURM_ACCOUNT",  "quapp")


class SlurmProvider(Provider):

    def __init__(self, jwt_token: str):
        super().__init__(ProviderTag.QUAPP_HPC)
        self.jwt_token = jwt_token
        self.base_url  = f"{SLURM_API_URL}/slurm/{SLURM_API_VER}"

    def get_backend(self, device_specification: str) -> str:
        # device_specification maps to Slurm partition name
        return device_specification or "compute"

    def collect_provider(self):
        resp = requests.get(
            f"{SLURM_API_URL}/ping",
            timeout=10,
        )
        resp.raise_for_status()
        logger.debug(f"Slurm API reachable: {resp.json()}")
        return self

    def auth_headers(self) -> dict:
        return {
            "X-SLURM-USER-NAME":  SLURM_USERNAME,
            "X-SLURM-USER-TOKEN": self.jwt_token,
            "Content-Type":       "application/json",
        }
