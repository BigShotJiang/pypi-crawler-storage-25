from quapp_common.component.backend.invocation import Invocation
from quapp_common.data.request.invocation_request import InvocationRequest
from quapp_common.model.provider.provider import Provider

from ...factory.hpc_device_factory import HpcDeviceFactory
from ...factory.hpc_provider_factory import HpcProviderFactory


class HpcInvocation(Invocation):

    def __init__(self, request_data: InvocationRequest):
        super().__init__(request_data)
        raw = request_data.input or {}
        job = raw.get("job", {})
        # s3Bucket intentionally dropped — S3 bucket is system config, read by
        # SlurmDevice from the S3_BUCKET env var (slurm-credentials secret).
        # User input must not override system fields (HPC design philosophy).
        self._hpc_config = {
            "resources":      raw.get("resources", {}),
            "container":      raw.get("container", {}),
            "environment":    job.get("environment", {}),
            "input_s3_paths": job.get("input_s3_paths", []),
        }

    def _export_circuit(self, circuit):
        pass

    def _get_qubit_amount(self, circuit) -> int:
        return 0

    def _create_provider(self) -> Provider:
        return HpcProviderFactory.create_provider(
            provider_type=self.backend_information.provider_tag,
            authentication=self.backend_information.authentication,
        )

    def _create_device(self, provider: Provider):
        return HpcDeviceFactory.create_device(
            provider=provider,
            device_specification=self.backend_information.device_name,
            job_uuid=self.job_id,
            hpc_config=self._hpc_config,
        )
