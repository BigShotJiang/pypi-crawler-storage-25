import json
import os

import boto3
import requests
from quapp_common.component.backend.job_fetching import JobFetching
from quapp_common.config.logging_config import job_logger
from quapp_common.data.request.job_fetching_request import JobFetchingRequest
from quapp_common.enum.status.job_status import JobStatus

from ...model.provider.slurm_provider import SlurmProvider

SLURM_JWT  = os.getenv("SLURM_JWT", "")
S3_BUCKET  = os.getenv("S3_BUCKET",  "quapp-slurm-output-dev")
AWS_REGION = os.getenv("AWS_REGION", "ap-southeast-1")

_SLURM_TERMINAL_TO_JOB_STATUS = {
    "COMPLETED":   JobStatus.DONE.value,
    "FAILED":      JobStatus.ERROR.value,
    "CANCELLED":   JobStatus.ERROR.value,
    "TIMEOUT":     JobStatus.ERROR.value,
    "NODE_FAIL":   JobStatus.ERROR.value,
    "PREEMPTED":   JobStatus.ERROR.value,
}


class _SlurmJobResult:
    """Lazy S3 download of the Slurm job's output.json.

    result() downloads from S3 only when called (after DONE is confirmed).
    usage() returns None so JobFetching.__get_execution_time() doesn't raise.
    """

    def __init__(self, job_uuid: str, s3_bucket: str = S3_BUCKET, aws_region: str = AWS_REGION):
        self._job_uuid = job_uuid
        self._s3_bucket = s3_bucket
        self._aws_region = aws_region
        self._logger = job_logger(job_uuid)

    def usage(self):
        return None

    def result(self):
        s3_key = f"{self._job_uuid}/output.json"
        self._logger.info(f"Downloading result from s3://{self._s3_bucket}/{s3_key}")
        s3 = boto3.client("s3", region_name=self._aws_region)
        resp = s3.get_object(Bucket=self._s3_bucket, Key=s3_key)
        return json.loads(resp["Body"].read())


class SlurmJobFetching(JobFetching):
    """Polls Slurm REST API for job status (IBM-pattern, triggered by watchdog)."""

    def __init__(self, request_data: JobFetchingRequest):
        super().__init__(request_data)
        self.job_id = request_data.job_id
        self._logger = job_logger(request_data.job_id)

    # ── Abstract implementations ──────────────────────────────────────────────

    def _collect_provider(self) -> SlurmProvider:
        jwt = (self.provider_authentication or {}).get("slurm_jwt") or SLURM_JWT
        if not jwt:
            raise ValueError("SLURM_JWT not set — cannot authenticate with Slurm API")
        return SlurmProvider(jwt_token=jwt)

    def _retrieve_job(self, provider: SlurmProvider) -> dict:
        return {"slurm_job_id": self.provider_job_id, "provider": provider}

    def _get_job_status(self, job: dict) -> str:
        provider: SlurmProvider = job["provider"]
        slurm_job_id = job["slurm_job_id"]

        resp = requests.get(
            f"{provider.base_url}/job/{slurm_job_id}",
            headers=provider.auth_headers(),
            timeout=15,
        )
        resp.raise_for_status()
        data = resp.json()

        jobs = data.get("jobs", [data])
        if not jobs:
            return "UNKNOWN"

        raw_state = jobs[0].get("job_state", "UNKNOWN")
        if isinstance(raw_state, list):
            raw_state = raw_state[0] if raw_state else "UNKNOWN"

        state = str(raw_state).strip()
        self._logger.info(f"Slurm job {slurm_job_id} state: {state}")
        return _SLURM_TERMINAL_TO_JOB_STATUS.get(state, state)

    def _get_job_result(self, job: dict) -> _SlurmJobResult:
        return _SlurmJobResult(job_uuid=self.job_id, s3_bucket=S3_BUCKET, aws_region=AWS_REGION)
