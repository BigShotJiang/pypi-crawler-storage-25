# SPDX-License-Identifier: MIT
"""Tests for the Security domain plugin and its engines."""

import json
import os
import sqlite3
import sys
import tempfile
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.domain_registry import DomainRegistry
from domains.security.domain import SecurityDomain
from domains.security.engines.adversarial_reviewer import (
    REVIEW_CATEGORIES,
    build_review_prompt,
    parse_review_response,
    persist_findings,
    review_contract,
)
from domains.security.engines.report_generator import (
    generate_full_report,
    generate_pr_security_section,
    generate_war_room_section,
    get_findings,
    get_summary_counts,
)
from domains.security.engines.static_analyzer import (
    analyze_all_contracts,
    analyze_contract,
    check_bare_error_discards,
    check_receive_calls_validate,
    check_validate_send_repacks,
)
from domains.security.engines.vuln_scanner import (
    DEFAULT_PATTERNS,
    get_default_patterns,
    load_patterns,
    scan_file,
    seed_patterns,
)

# -- Fixtures --


@pytest.fixture(autouse=True)
def reset_registry():
    DomainRegistry.reset()
    yield
    DomainRegistry.reset()


@pytest.fixture
def tmp_db():
    """Create a temporary database with security domain schema."""
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = f.name

    conn = sqlite3.connect(db_path)
    domain = SecurityDomain()
    conn.executescript(domain.get_db_schema_sql())
    conn.commit()
    conn.close()

    yield db_path
    os.unlink(db_path)


# -- Domain registration tests --


class TestSecurityDomainRegistration:
    def test_domain_name(self):
        domain = SecurityDomain()
        assert domain.name() == "security"

    def test_domain_priority(self):
        domain = SecurityDomain()
        assert domain.get_priority() == 1  # Highest

    def test_domain_registers_with_registry(self):
        registry = DomainRegistry.instance()
        domain = SecurityDomain()
        registry.register(domain)
        assert "security" in registry.get_domain_names()
        retrieved = registry.get_domain("security")
        assert retrieved is domain

    def test_domain_engines_count(self):
        domain = SecurityDomain()
        engines = domain.get_engines()
        assert len(engines) >= 4
        names = {e.name for e in engines}
        assert "adversarial_reviewer" in names
        assert "vuln_scanner" in names
        assert "static_analyzer" in names
        assert "report_generator" in names

    def test_domain_hypothesis_types(self):
        domain = SecurityDomain()
        types = domain.get_hypothesis_types()
        assert len(types) >= 4
        type_ids = {t.type_id for t in types}
        assert "fund_theft_vector" in type_ids
        assert "fund_lock_vector" in type_ids

    def test_domain_db_schema(self):
        domain = SecurityDomain()
        sql = domain.get_db_schema_sql()
        assert "security_reviews" in sql
        assert "vuln_patterns" in sql

    def test_decide_next_action_urgent(self):
        domain = SecurityDomain()
        action = domain.decide_next_action(
            {
                "trigger_level": "urgent",
                "stale_data": [],
            }
        )
        assert action is not None
        assert action["engine"] == "adversarial_reviewer"
        assert action["priority"] == 1

    def test_decide_next_action_routine(self):
        domain = SecurityDomain()
        action = domain.decide_next_action(
            {
                "trigger_level": "routine",
                "stale_data": [],
            }
        )
        assert action is not None
        assert action["engine"] == "static_analyzer"

    def test_decide_next_action_stale_scan(self):
        domain = SecurityDomain()
        action = domain.decide_next_action(
            {
                "trigger_level": "routine",
                "stale_data": ["security_scan"],
            }
        )
        assert action["engine"] == "vuln_scanner"

    def test_duplicate_registration_raises(self):
        registry = DomainRegistry.instance()
        registry.register(SecurityDomain())
        with pytest.raises(ValueError):
            registry.register(SecurityDomain())


# -- Adversarial reviewer tests --


class TestAdversarialReviewer:
    def test_review_categories_defined(self):
        assert "fund_theft" in REVIEW_CATEGORIES
        assert "fund_lock" in REVIEW_CATEGORIES
        assert "dos_vector" in REVIEW_CATEGORIES

    def test_build_review_prompt(self):
        prompt = build_review_prompt("htlc", "func main() {}")
        assert "htlc" in prompt
        assert "fund theft" in prompt.lower()
        assert "func main" in prompt

    def test_parse_valid_response(self):
        raw = json.dumps(
            [
                {
                    "category": "fund_theft",
                    "severity": "critical",
                    "title": "Unauthorized withdrawal",
                    "description": "Found a path to drain funds",
                    "line_hint": 42,
                },
            ]
        )
        findings = parse_review_response(raw)
        assert len(findings) == 1
        assert findings[0]["category"] == "fund_theft"
        assert findings[0]["severity"] == "critical"

    def test_parse_markdown_fenced_response(self):
        raw = '```json\n[{"category":"dos_vector","severity":"medium","title":"Loop","description":"Unbounded loop","line_hint":0}]\n```'
        findings = parse_review_response(raw)
        assert len(findings) == 1
        assert findings[0]["category"] == "dos_vector"

    def test_parse_empty_response(self):
        findings = parse_review_response("[]")
        assert findings == []

    def test_parse_invalid_json(self):
        findings = parse_review_response("this is not json")
        assert findings == []

    def test_parse_normalizes_severity(self):
        raw = json.dumps(
            [
                {"category": "fund_theft", "severity": "CRITICAL", "title": "Test"},
            ]
        )
        findings = parse_review_response(raw)
        assert findings[0]["severity"] == "critical"

    def test_persist_findings(self, tmp_db):
        findings = [
            {
                "category": "fund_theft",
                "severity": "critical",
                "title": "Test finding",
                "description": "Test description",
                "line_hint": 10,
            },
        ]
        count = persist_findings("htlc", findings, db_path=tmp_db)
        assert count == 1

        conn = sqlite3.connect(tmp_db)
        row = conn.execute("SELECT * FROM security_reviews WHERE contract_name = 'htlc'").fetchone()
        conn.close()
        assert row is not None

    def test_review_contract_no_source(self, tmp_db):
        result = review_contract(
            "nonexistent_contract",
            db_path=tmp_db,
        )
        assert result["source_found"] is False
        assert result["findings"] == []

    def test_review_contract_dry_run(self, tmp_db):
        result = review_contract("htlc", db_path=tmp_db)
        # Without llm_call, no LLM findings generated
        assert result["findings"] == []
        # Static analysis may produce findings (persisted_count >= 0)
        assert result["persisted_count"] >= 0

    def test_review_contract_with_mock_llm(self, tmp_db):
        mock_response = json.dumps(
            [
                {
                    "category": "access_control_bypass",
                    "severity": "high",
                    "title": "Missing caller check",
                    "description": "No check on msg.sender",
                    "line_hint": 5,
                },
            ]
        )

        def mock_llm(prompt):
            return mock_response

        result = review_contract(
            "htlc",
            llm_call=mock_llm,
            db_path=tmp_db,
        )
        # May or may not find source depending on repo layout
        if result["source_found"]:
            assert len(result["findings"]) == 1
            # persisted_count includes LLM findings + static findings
            assert result["persisted_count"] >= 1

    def test_review_contract_persists_non_empty_summary(self, tmp_db):
        """Regression: the static_review_summary row must have non-empty text.

        The harden run showed every cycle emitting "Plausibility gate REJECTED
        finding from security/adversarial_reviewer: Finding text is empty"
        because review_contract was building a static_results dict with
        summary="" and handing it to persist_static_findings. The plausibility
        gate rejected it; the engine's logged count was inflated.
        """
        from unittest.mock import patch

        fake_static_finding = {
            "category": "fund_lock",
            "severity": "high",
            "title": "Missing reclaim path",
            "description": "WHAT: no reclaim. SO WHAT: funds lock. NOW WHAT: add path.",
            "line_hint": 42,
            "source_file": "vm/embedded/implementation/htlc.go",
        }

        with (
            patch(
                "domains.security.engines.adversarial_reviewer.read_contract_source",
                return_value="func main() {}",
            ),
            patch(
                "domains.security.engines.adversarial_reviewer.static_review",
                return_value=[fake_static_finding],
            ),
        ):
            review_contract("htlc", db_path=tmp_db)

        conn = sqlite3.connect(tmp_db)
        try:
            row = conn.execute(
                "SELECT finding FROM evidence WHERE evidence_type = ?",
                ("static_review_summary",),
            ).fetchone()
        finally:
            conn.close()

        assert row is not None, "static_review_summary evidence row was not persisted"
        assert row[0], "static_review_summary finding text must not be empty"
        assert len(row[0]) > 20, "summary should carry real WHAT/SO WHAT/NOW WHAT content"


# -- Vuln scanner tests --


class TestVulnScanner:
    def test_default_patterns_exist(self):
        patterns = get_default_patterns()
        assert len(patterns) >= 6
        names = {p["pattern_name"] for p in patterns}
        assert "unchecked_error_return" in names
        assert "bare_underscore_error" in names

    def test_seed_patterns(self, tmp_db):
        count = seed_patterns(db_path=tmp_db)
        assert count == len(DEFAULT_PATTERNS)

        # Second seed should return 0 (already seeded)
        count2 = seed_patterns(db_path=tmp_db)
        assert count2 == 0

    def test_load_patterns_fallback(self):
        patterns = load_patterns(db_path="/nonexistent/path.db")
        assert len(patterns) == len(DEFAULT_PATTERNS)

    def test_scan_file_with_pattern(self, tmp_path):
        # Create a test Go file with a known vulnerability
        go_file = tmp_path / "test.go"
        go_file.write_text(
            "package main\n\n"
            "func bad() {\n"
            "    _ = doSomething()\n"  # bare underscore error
            "}\n"
        )
        patterns = get_default_patterns()
        matches = scan_file(go_file, patterns)
        # Should find the bare underscore pattern
        bare_matches = [m for m in matches if m["pattern_name"] == "bare_underscore_error"]
        assert len(bare_matches) >= 1

    def test_scan_file_clean(self, tmp_path):
        go_file = tmp_path / "clean.go"
        go_file.write_text("package main\n\nfunc good() error {\n    return nil\n}\n")
        patterns = get_default_patterns()
        matches = scan_file(go_file, patterns)
        # Filter out info-level matches
        serious = [m for m in matches if m["severity"] in ("critical", "high")]
        assert len(serious) == 0


# -- Static analyzer tests --


class TestStaticAnalyzer:
    def test_check_bare_error_discards(self, tmp_path):
        go_file = tmp_path / "test.go"
        go_file.write_text("package impl\n\nfunc bad() {\n    _ = db.GetEntry(key)\n}\n")
        findings = check_bare_error_discards(go_file)
        assert len(findings) >= 1
        assert findings[0].check == "bare_error_discard"

    def test_check_validate_send_repacks(self, tmp_path):
        # File without repack in ValidateSendBlock
        go_file = tmp_path / "test.go"
        go_file.write_text(
            "package impl\n\n"
            "func (h *Handler) ValidateSendBlock(block *types.Block) error {\n"
            "    if block == nil {\n"
            '        return errors.New("nil block")\n'
            "    }\n"
            "    return nil\n"
            "}\n"
        )
        findings = check_validate_send_repacks(go_file)
        assert len(findings) >= 1
        assert findings[0].check == "validate_send_no_repack"

    def test_check_receive_calls_validate(self, tmp_path):
        # File without ValidateSendBlock call in ReceiveBlock
        go_file = tmp_path / "test.go"
        go_file.write_text(
            "package impl\n\n"
            "func (h *Handler) ReceiveBlock(block *types.Block) error {\n"
            "    // does stuff but no validate call\n"
            "    return nil\n"
            "}\n"
        )
        findings = check_receive_calls_validate(go_file)
        assert len(findings) >= 1
        assert findings[0].check == "receive_no_validate"

    def test_analyze_contract_returns_list(self):
        # May be empty if no go-zenon found
        results = analyze_contract("nonexistent_contract_xyz")
        assert isinstance(results, list)

    def test_analyze_all_returns_dict(self):
        results = analyze_all_contracts()
        assert isinstance(results, dict)


# -- Report generator tests --


class TestReportGenerator:
    def test_get_findings_empty_db(self, tmp_db):
        findings = get_findings(db_path=tmp_db)
        assert findings == []

    def test_get_summary_counts_empty(self, tmp_db):
        counts = get_summary_counts(db_path=tmp_db)
        assert counts["total"] == 0
        assert counts["critical"] == 0

    def test_generate_pr_section_empty(self, tmp_db):
        section = generate_pr_security_section(db_path=tmp_db)
        assert "No security findings" in section

    def test_generate_pr_section_with_findings(self, tmp_db):
        # Insert a finding
        conn = sqlite3.connect(tmp_db)
        conn.execute(
            """INSERT INTO security_reviews
               (contract_name, engine, severity, category, title,
                description, line_number, confidence)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                "htlc",
                "test",
                "critical",
                "fund_theft",
                "Test critical finding",
                "Description",
                42,
                0.9,
            ),
        )
        conn.commit()
        conn.close()

        section = generate_pr_security_section("htlc", db_path=tmp_db)
        assert "CRITICAL" in section
        assert "Test critical finding" in section

    def test_generate_war_room_section(self, tmp_db):
        section = generate_war_room_section(db_path=tmp_db)
        assert "Security Posture" in section

    def test_generate_full_report_empty(self, tmp_db):
        report = generate_full_report(db_path=tmp_db)
        assert "No security findings" in report

    def test_generate_full_report_with_data(self, tmp_db):
        conn = sqlite3.connect(tmp_db)
        for sev in ("critical", "high", "medium"):
            conn.execute(
                """INSERT INTO security_reviews
                   (contract_name, engine, severity, category, title,
                    description, line_number, confidence)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                ("bridge", "test", sev, "test_cat", f"Finding {sev}", f"Desc {sev}", 0, 0.5),
            )
        conn.commit()
        conn.close()

        report = generate_full_report(db_path=tmp_db)
        assert "bridge" in report
        assert "CRITICAL" in report
