# SPDX-License-Identifier: MIT
"""
LiquidityMonitor -- Monitor Uniswap pool depth, slippage, and volume for ZNN pairs.

Queries DexScreener API for real-time DEX data on wZNN/ETH pairs,
estimates slippage at various trade sizes, and persists metrics.
"""

import logging
import math
from pathlib import Path

from core.market_data import DEXSCREENER_BASE, WZNN_CONTRACT, _get
from core.persist_to_db import persist_metric, query_table

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

# wZNN token address on Ethereum (re-exported from core.market_data)
WZNN_TOKEN = WZNN_CONTRACT


def fetch_dex_pairs() -> list[dict]:
    """Fetch all DEX pairs for wZNN from DexScreener.

    Returns list of pair dicts sorted by liquidity (highest first).
    Uses core.market_data for the HTTP request layer.
    """
    data = _get(f"{DEXSCREENER_BASE}/tokens/{WZNN_TOKEN}")
    if not data or "pairs" not in data:
        return []

    pairs = data["pairs"]
    # Sort by liquidity descending
    pairs.sort(key=lambda p: float(p.get("liquidity", {}).get("usd", 0) or 0), reverse=True)
    return pairs


def parse_pair_data(pair: dict) -> dict:
    """Parse a DexScreener pair into our standard format."""
    liquidity = pair.get("liquidity", {})
    volume = pair.get("volume", {})
    price_change = pair.get("priceChange", {})

    return {
        "pair_name": pair.get("baseToken", {}).get("symbol", "ZNN")
        + "/"
        + pair.get("quoteToken", {}).get("symbol", "ETH"),
        "pool_address": pair.get("pairAddress", ""),
        "dex": pair.get("dexId", "unknown"),
        "chain": pair.get("chainId", "ethereum"),
        "price_usd": float(pair.get("priceUsd", 0) or 0),
        "liquidity_usd": float(liquidity.get("usd", 0) or 0),
        "liquidity_base": float(liquidity.get("base", 0) or 0),
        "liquidity_quote": float(liquidity.get("quote", 0) or 0),
        "volume_24h": float(volume.get("h24", 0) or 0),
        "volume_6h": float(volume.get("h6", 0) or 0),
        "volume_1h": float(volume.get("h1", 0) or 0),
        "price_change_24h": float(price_change.get("h24", 0) or 0),
        "price_change_6h": float(price_change.get("h6", 0) or 0),
    }


def estimate_slippage(liquidity_usd: float, trade_size_usd: float) -> float:
    """Estimate price slippage for a given trade size.

    Uses constant-product AMM formula approximation:
    slippage ~= trade_size / (2 * liquidity)

    Returns slippage as a percentage.
    """
    if liquidity_usd <= 0:
        return 100.0

    # Constant product approximation
    slippage = (trade_size_usd / (2 * liquidity_usd)) * 100
    return round(min(slippage, 100.0), 2)


def calculate_liquidity_score(liquidity_usd: float, volume_24h: float) -> float:
    """Calculate a liquidity health score from 0-100.

    Based on pool depth and trading activity.
    """
    if liquidity_usd <= 0:
        return 0.0

    # Liquidity depth score (log scale, $100k = 50, $1M = 75, $10M = 100)
    depth_score = min(100.0, 25 * math.log10(max(liquidity_usd, 1)) - 75)
    depth_score = max(0.0, depth_score)

    # Volume/liquidity ratio (healthy = 10-50% daily)
    vol_ratio = volume_24h / liquidity_usd if liquidity_usd > 0 else 0
    if 0.05 <= vol_ratio <= 1.0:
        activity_score = 100.0
    elif vol_ratio > 1.0:
        activity_score = 80.0  # Very high volume, possible wash trading
    elif vol_ratio > 0.01:
        activity_score = vol_ratio * 2000  # Scale 0.01->0.05 to 20->100
    else:
        activity_score = 10.0  # Very low activity

    return round((depth_score * 0.7 + activity_score * 0.3), 1)


def persist_liquidity_snapshot(
    pair_data: dict,
    slippage_1k: float,
    slippage_10k: float,
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist a liquidity snapshot to the database."""
    return persist_metric(
        db_path=db_path,
        table="liquidity_metrics",
        data={
            "pair_name": pair_data["pair_name"],
            "pool_address": pair_data["pool_address"],
            "liquidity_usd": pair_data["liquidity_usd"],
            "volume_24h_usd": pair_data["volume_24h"],
            "price_usd": pair_data["price_usd"],
            "price_change_24h": pair_data["price_change_24h"],
            "slippage_1k_usd": slippage_1k,
            "slippage_10k_usd": slippage_10k,
        },
    )


def get_liquidity_history(
    *,
    db_path: str = DEFAULT_DB,
    pair_name: str | None = None,
    limit: int = 30,
) -> list[dict]:
    """Get recent liquidity snapshots."""
    if pair_name:
        return query_table(
            db_path=db_path,
            table="liquidity_metrics",
            where="pair_name = ?",
            params=(pair_name,),
            order_by="timestamp DESC",
            limit=limit,
        )
    return query_table(
        db_path=db_path,
        table="liquidity_metrics",
        order_by="timestamp DESC",
        limit=limit,
    )


def run_liquidity_check(*, db_path: str = DEFAULT_DB) -> dict:
    """Run a full liquidity check: fetch pairs, calculate slippage, persist.

    Returns comprehensive liquidity status dict.
    """
    pairs = fetch_dex_pairs()
    if not pairs:
        return {
            "success": False,
            "error": "No DEX pairs found for wZNN token.",
        }

    results = []
    total_liquidity = 0.0
    total_volume_24h = 0.0

    for raw_pair in pairs[:5]:  # Top 5 pairs by liquidity
        pair_data = parse_pair_data(raw_pair)
        slippage_1k = estimate_slippage(pair_data["liquidity_usd"], 1000)
        slippage_10k = estimate_slippage(pair_data["liquidity_usd"], 10000)
        score = calculate_liquidity_score(pair_data["liquidity_usd"], pair_data["volume_24h"])

        snapshot_id = persist_liquidity_snapshot(
            pair_data, slippage_1k, slippage_10k, db_path=db_path
        )

        total_liquidity += pair_data["liquidity_usd"]
        total_volume_24h += pair_data["volume_24h"]

        results.append(
            {
                **pair_data,
                "slippage_1k": slippage_1k,
                "slippage_10k": slippage_10k,
                "liquidity_score": score,
                "snapshot_id": snapshot_id,
            }
        )

    # Persist actionable finding
    try:
        from core.persist_to_db import ensure_schema, persist_finding

        ensure_schema(db_path)

        top_pair = results[0] if results else {}
        slippage_10k = top_pair.get("slippage_10k", 0)
        top_pair.get("liquidity_score", 0)

        if total_liquidity < 50_000:
            severity = "CRITICAL"
            action = "Liquidity is dangerously low; large trades will suffer extreme slippage. Consider incentivizing LP provision urgently."
        elif total_liquidity < 200_000:
            severity = "LOW"
            action = f"Liquidity is thin; a $10k trade would slip ~{slippage_10k:.1f}%. Monitor for further decline and consider LP incentive programs."
        else:
            severity = "ADEQUATE"
            action = "Continue monitoring; track liquidity trends weekly for early warning of withdrawal."

        persist_finding(
            db_path=db_path,
            domain="economics",
            engine="liquidity_monitor",
            evidence_type="liquidity_snapshot",
            finding=(
                f"WHAT: Total wZNN DEX liquidity ${total_liquidity:,.0f} across {len(results)} pairs, "
                f"24h volume ${total_volume_24h:,.0f}, $10k slippage est. {slippage_10k:.2f}%. "
                f"SO WHAT: Liquidity is {severity}; "
                f"vol/liq ratio {total_volume_24h / max(total_liquidity, 1):.2f} "
                f"({'healthy' if 0.05 <= total_volume_24h / max(total_liquidity, 1) <= 1.0 else 'abnormal'}). "
                f"NOW WHAT: {action}"
            ),
            confidence=0.80,
            raw_data={
                "total_liquidity_usd": total_liquidity,
                "total_volume_24h_usd": total_volume_24h,
                "pairs_tracked": len(results),
            },
            source_repo="dex_api",
        )
    except Exception as exc:
        logger.debug("Liquidity finding persistence failed: %s", exc)

    return {
        "success": True,
        "pairs_tracked": len(results),
        "total_liquidity_usd": round(total_liquidity, 2),
        "total_volume_24h_usd": round(total_volume_24h, 2),
        "pairs": results,
    }
