# Sparki

AI-powered video editing from the command line.

## Installation

```
pip install sparki-cli
```

Or with [uv](https://docs.astral.sh/uv/):

```
uv tool install sparki-cli

# Upgrade to the latest release
uv tool install --upgrade sparki-cli
```

## Quick Start

```bash
# Configure your API key and verify the install
sparki setup --api-key YOUR_KEY
sparki doctor

# Upload one or multiple files (positional args; shell glob works)
sparki upload video1.mp4 video2.mp4
sparki upload *.mp4
sparki upload --dir ./clips

# Edit: combine multiple source clips into ONE output project
sparki run clip1.mp4 clip2.mp4 clip3.mp4 \
  --mode style-guided --style montage/highlight-reel

# Edit: loop for N independent outputs
for f in *.mp4; do
  sparki run "$f" --mode style-guided --style vlog/daily
done

# Clean up storage
sparki assets list
sparki assets delete assets/98/old1.mp4 assets/98/old2.mp4
sparki assets delete --all --yes   # wipe everything
```

## Commands

| Command | Description |
|---------|-------------|
| `setup` | Save and validate your API key |
| `doctor` | Self-check CLI version, API key, base URL, config directory |
| `upload` | Upload video file(s); positional args, `--file`, or `--dir`; retries + partial success |
| `assets list` | List uploaded assets (alias: `sparki assets`) |
| `assets delete` | Delete uploaded assets by key, `--name`, or `--all --yes` |
| `edit` | Create an edit project from uploaded object keys |
| `status` | Check project status |
| `download` | Download completed result |
| `run` | End-to-end: upload → edit → download (accepts multiple positional files) |
| `history` | List recent projects |

## Edit Modes

- **style-guided** — Choose from preset styles (e.g. `vlog/daily`, `montage/highlight-reel`)
- **prompt-driven** — Describe what you want in natural language
- **style-clone** — Clone the style of a reference video

## Multi-file upload

`sparki upload` and `sparki run` accept multiple files three ways:

- **Positional args** (recommended): `sparki upload a.mp4 b.mp4`
- **Shell glob**: `sparki upload *.mp4`
- **Directory** (single-level): `sparki upload --dir ./clips`
- **--file** (deprecated alias): `sparki upload --file a.mp4 --file b.mp4`

Reliability options:

- `--max-retries N` (default 3; 0 disables) — per-file retries on network errors / 429 / 5xx
- `--upload-timeout SEC` (default 600) — per-file timeout
- `--quiet` — suppress stderr progress output
- `--strict` (run only) — abort if any source file fails upload (default: proceed with successful ones)

## Links

- Website: https://sparki.io
- Telegram: https://t.me/Sparki_AI_bot
