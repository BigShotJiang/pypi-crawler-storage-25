"""Tests for sparki doctor command."""

import json
from pathlib import Path

import httpx
import pytest
import respx
from typer.testing import CliRunner

from sparki.cli import app
from sparki import constants


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


@pytest.fixture
def fake_home(tmp_path: Path, monkeypatch) -> Path:
    home = tmp_path / "home"
    cfg_dir = home / ".openclaw" / "config"
    cfg_dir.mkdir(parents=True)
    monkeypatch.setenv("HOME", str(home))
    monkeypatch.setattr("sparki.config.DEFAULT_CONFIG_DIR", cfg_dir)
    monkeypatch.delenv("SPARKI_API_KEY", raising=False)
    return home


def _write_config(fake_home: Path, api_key: str | None = None, base_url: str | None = None):
    cfg = fake_home / ".openclaw" / "config" / "sparki.json"
    data = {}
    if api_key:
        data["api_key"] = api_key
    if base_url:
        data["base_url"] = base_url
    cfg.write_text(json.dumps(data))


def _write_skill_manifest(cwd: Path, domains: list[str]):
    skill = cwd / "SKILL.md"
    domain_yaml = ", ".join(f'"{d}"' for d in domains)
    skill.write_text(
        "---\n"
        "name: sparki-video-editor\n"
        "version: 1.1.0\n"
        "metadata:\n"
        "  clawdbot:\n"
        "    permissions:\n"
        "      network:\n"
        f"        domains: [{domain_yaml}]\n"
        "---\n"
        "# Skill body\n"
    )


@respx.mock
def test_doctor_all_pass(runner: CliRunner, fake_home: Path, tmp_path: Path, monkeypatch):
    _write_config(fake_home, api_key="KEY", base_url="https://agent-api.sparki.io")
    _write_skill_manifest(tmp_path, ["agent-api.sparki.io"])
    monkeypatch.chdir(tmp_path)

    respx.get("https://agent-api.sparki.io/api/v1/account/info").mock(
        return_value=httpx.Response(200, json={"ok": True})
    )
    respx.get(constants.PYPI_JSON_URL).mock(
        return_value=httpx.Response(200, json={"info": {"version": "1.1.0"}})
    )

    result = runner.invoke(app, ["doctor", "--json"])
    assert result.exit_code == 0, result.stdout
    payload = json.loads(result.stdout)
    assert payload["ok"] is True
    checks = {c["name"]: c for c in payload["data"]["checks"]}
    assert checks["api_key"]["status"] == "pass"
    assert checks["base_url"]["status"] == "pass"
    assert checks["cli_version"]["status"] == "pass"


@respx.mock
def test_doctor_no_api_key(runner: CliRunner, fake_home: Path, tmp_path: Path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    respx.get(constants.PYPI_JSON_URL).mock(
        return_value=httpx.Response(200, json={"info": {"version": "1.1.0"}})
    )
    result = runner.invoke(app, ["doctor", "--json"])
    assert result.exit_code != 0
    payload = json.loads(result.stdout)
    assert payload["ok"] is False
    checks = {c["name"]: c for c in payload["error"]["checks"]}
    assert checks["api_key"]["status"] == "fail"


@respx.mock
def test_doctor_baseurl_mismatch(runner: CliRunner, fake_home: Path, tmp_path: Path, monkeypatch):
    _write_config(fake_home, api_key="KEY", base_url="https://wrong.example.com")
    _write_skill_manifest(tmp_path, ["agent-api.sparki.io"])
    monkeypatch.chdir(tmp_path)
    respx.get("https://wrong.example.com/api/v1/account/info").mock(
        return_value=httpx.Response(200)
    )
    respx.get(constants.PYPI_JSON_URL).mock(
        return_value=httpx.Response(200, json={"info": {"version": "1.1.0"}})
    )
    result = runner.invoke(app, ["doctor", "--json"])
    payload = json.loads(result.stdout)
    checks = {c["name"]: c for c in payload["error"]["checks"]}
    assert checks["base_url"]["status"] == "fail"


@respx.mock
def test_doctor_outdated_cli(runner: CliRunner, fake_home: Path, tmp_path: Path, monkeypatch):
    _write_config(fake_home, api_key="KEY", base_url="https://agent-api.sparki.io")
    _write_skill_manifest(tmp_path, ["agent-api.sparki.io"])
    monkeypatch.chdir(tmp_path)
    respx.get("https://agent-api.sparki.io/api/v1/account/info").mock(
        return_value=httpx.Response(200)
    )
    respx.get(constants.PYPI_JSON_URL).mock(
        return_value=httpx.Response(200, json={"info": {"version": "9.9.9"}})
    )
    result = runner.invoke(app, ["doctor", "--json"])
    payload = json.loads(result.stdout)
    # Failed overall → checks are in error.checks
    data = payload.get("data")
    if data and data.get("checks"):
        checks = {c["name"]: c for c in data["checks"]}
    else:
        checks = {c["name"]: c for c in payload["error"]["checks"]}
    assert checks["cli_latest"]["status"] == "fail"
    assert "9.9.9" in (checks["cli_latest"].get("latest") or "")


@respx.mock
def test_doctor_baseurl_passes_via_cli_fallback_when_no_skill_md(
    runner: CliRunner, fake_home: Path, tmp_path: Path, monkeypatch
):
    """When SKILL.md is not findable (agent invokes doctor from arbitrary cwd),
    base_url check should still work by falling back to the CLI's own
    expected-hosts constant, not 'skip'."""
    _write_config(fake_home, api_key="KEY", base_url="https://agent-api.sparki.io")
    # Intentionally do NOT write a SKILL.md anywhere reachable.
    isolated = tmp_path / "no-skill"
    isolated.mkdir()
    monkeypatch.chdir(isolated)
    # Block the HOME-based fallback probe by pointing HOME at a dir with no .openclaw tree.
    monkeypatch.setenv("HOME", str(tmp_path / "empty_home"))
    (tmp_path / "empty_home").mkdir()
    # Also clear the OPENCLAW_STATE_DIR and the skill-dir env hints.
    for v in ("CLAWDBOT_SKILL_DIR", "OPENCLAW_SKILL_DIR", "SKILL_DIR", "OPENCLAW_STATE_DIR"):
        monkeypatch.delenv(v, raising=False)

    respx.get("https://agent-api.sparki.io/api/v1/account/info").mock(
        return_value=httpx.Response(200, json={"ok": True})
    )
    respx.get(constants.PYPI_JSON_URL).mock(
        return_value=httpx.Response(200, json={"info": {"version": "1.1.0"}})
    )

    result = runner.invoke(app, ["doctor", "--json"])
    assert result.exit_code == 0, result.stdout
    payload = json.loads(result.stdout)
    checks = {c["name"]: c for c in payload["data"]["checks"]}
    assert checks["base_url"]["status"] == "pass"
    assert checks["base_url"].get("source") == "CLI constants"


@respx.mock
def test_doctor_pypi_unreachable_degrades_gracefully(
    runner: CliRunner, fake_home: Path, tmp_path: Path, monkeypatch
):
    _write_config(fake_home, api_key="KEY", base_url="https://agent-api.sparki.io")
    _write_skill_manifest(tmp_path, ["agent-api.sparki.io"])
    monkeypatch.chdir(tmp_path)
    respx.get("https://agent-api.sparki.io/api/v1/account/info").mock(
        return_value=httpx.Response(200)
    )
    respx.get(constants.PYPI_JSON_URL).mock(side_effect=httpx.ConnectError("boom"))
    result = runner.invoke(app, ["doctor", "--json"])
    payload = json.loads(result.stdout)
    data = payload.get("data")
    if data and data.get("checks"):
        checks = {c["name"]: c for c in data["checks"]}
    else:
        checks = {c["name"]: c for c in payload["error"]["checks"]}
    assert checks["cli_latest"]["status"] == "skip"
