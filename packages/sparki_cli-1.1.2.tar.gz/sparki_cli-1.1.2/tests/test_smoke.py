"""Smoke tests — verify the package loads and CLI is importable."""

from sparki import __version__
from sparki.cli import app


def test_version_is_semver():
    assert isinstance(__version__, str)
    parts = __version__.split(".")
    assert len(parts) == 3
    assert all(p.isdigit() for p in parts)


def test_cli_app_has_commands():
    import typer.main

    assert app is not None
    click_app = typer.main.get_command(app)
    command_names = list(click_app.commands.keys())
    assert "setup" in command_names
    assert "upload" in command_names
    assert "run" in command_names
