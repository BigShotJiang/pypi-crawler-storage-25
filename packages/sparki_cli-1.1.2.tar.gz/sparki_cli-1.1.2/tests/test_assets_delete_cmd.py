"""Tests for sparki assets delete and list subcommands."""

import json
from pathlib import Path

import httpx
import pytest
import respx
from typer.testing import CliRunner

from sparki.cli import app


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


@pytest.fixture(autouse=True)
def fake_home(tmp_path: Path, monkeypatch):
    cfg_dir = tmp_path / ".openclaw" / "config"
    cfg_dir.mkdir(parents=True)
    monkeypatch.setattr("sparki.config.DEFAULT_CONFIG_DIR", cfg_dir)
    (cfg_dir / "sparki.json").write_text(json.dumps({
        "api_key": "KEY",
        "base_url": "https://agent-api.sparki.io",
    }))
    monkeypatch.delenv("SPARKI_API_KEY", raising=False)
    return cfg_dir


def _delete_response(items):
    return {
        "code": 200,
        "data": {
            "items": items,
            "success_count": sum(1 for i in items if i.get("success")),
            "failed_count": sum(1 for i in items if not i.get("success")),
        },
    }


@respx.mock
def test_assets_delete_positional(runner: CliRunner):
    respx.post("https://agent-api.sparki.io/api/v1/assets/batch_delete").mock(
        return_value=httpx.Response(200, json=_delete_response([
            {"object_key": "k1", "success": True, "message": None},
        ]))
    )
    result = runner.invoke(app, ["assets", "delete", "k1"])
    assert result.exit_code == 0, result.stdout
    payload = json.loads(result.stdout)
    assert payload["ok"] is True
    assert payload["data"]["summary"]["deleted"] == 1


@respx.mock
def test_assets_delete_reports_skipped_when_in_use(runner: CliRunner):
    respx.post("https://agent-api.sparki.io/api/v1/assets/batch_delete").mock(
        return_value=httpx.Response(200, json=_delete_response([
            {"object_key": "k1", "success": False, "message": "in use by active project"},
        ]))
    )
    result = runner.invoke(app, ["assets", "delete", "k1"])
    payload = json.loads(result.stdout)
    assert payload["ok"] is True
    assert payload["data"]["summary"]["skipped"] == 1


@respx.mock
def test_assets_delete_reports_failed_when_not_found(runner: CliRunner):
    respx.post("https://agent-api.sparki.io/api/v1/assets/batch_delete").mock(
        return_value=httpx.Response(200, json=_delete_response([
            {"object_key": "kx", "success": False, "message": "Asset not found"},
        ]))
    )
    result = runner.invoke(app, ["assets", "delete", "kx"])
    payload = json.loads(result.stdout)
    assert payload["data"]["summary"]["failed"] == 1


@respx.mock
def test_assets_delete_all_requires_yes(runner: CliRunner):
    respx.get("https://agent-api.sparki.io/api/v1/assets/user_assets").mock(
        return_value=httpx.Response(200, json={
            "code": 200,
            "data": {"assets": [
                {"object_key": "k1", "file_name": "a.mp4"},
                {"object_key": "k2", "file_name": "b.mp4"},
            ]},
        })
    )
    delete_route = respx.post("https://agent-api.sparki.io/api/v1/assets/batch_delete").mock(
        return_value=httpx.Response(200, json=_delete_response([]))
    )
    result = runner.invoke(app, ["assets", "delete", "--all"])
    assert result.exit_code != 0
    payload = json.loads(result.stdout)
    assert payload["error"]["code"] == "CONFIRMATION_REQUIRED"
    assert delete_route.call_count == 0


@respx.mock
def test_assets_delete_all_with_yes(runner: CliRunner):
    respx.get("https://agent-api.sparki.io/api/v1/assets/user_assets").mock(
        return_value=httpx.Response(200, json={
            "code": 200,
            "data": {"assets": [
                {"object_key": "k1", "file_name": "a.mp4"},
                {"object_key": "k2", "file_name": "b.mp4"},
            ]},
        })
    )
    respx.post("https://agent-api.sparki.io/api/v1/assets/batch_delete").mock(
        return_value=httpx.Response(200, json=_delete_response([
            {"object_key": "k1", "success": True, "message": None},
            {"object_key": "k2", "success": True, "message": None},
        ]))
    )
    result = runner.invoke(app, ["assets", "delete", "--all", "--yes"])
    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["data"]["summary"]["deleted"] == 2


@respx.mock
def test_assets_delete_by_name(runner: CliRunner):
    respx.get("https://agent-api.sparki.io/api/v1/assets/user_assets").mock(
        return_value=httpx.Response(200, json={
            "code": 200,
            "data": {"assets": [
                {"object_key": "k1", "file_name": "clip1.mp4"},
                {"object_key": "k2", "file_name": "clip2.mp4"},
            ]},
        })
    )
    respx.post("https://agent-api.sparki.io/api/v1/assets/batch_delete").mock(
        return_value=httpx.Response(200, json=_delete_response([
            {"object_key": "k1", "success": True, "message": None},
        ]))
    )
    result = runner.invoke(app, ["assets", "delete", "--name", "clip1.mp4"])
    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["data"]["summary"]["deleted"] == 1


@respx.mock
def test_assets_list_works(runner: CliRunner):
    respx.get("https://agent-api.sparki.io/api/v1/assets/user_assets").mock(
        return_value=httpx.Response(200, json={"code": 200, "data": {"assets": []}})
    )
    result = runner.invoke(app, ["assets", "list"])
    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["ok"] is True


@respx.mock
def test_assets_default_callback_lists(runner: CliRunner):
    """`sparki assets` with no subcommand should list (backward compat)."""
    respx.get("https://agent-api.sparki.io/api/v1/assets/user_assets").mock(
        return_value=httpx.Response(200, json={"code": 200, "data": {"assets": []}})
    )
    result = runner.invoke(app, ["assets"])
    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["ok"] is True
