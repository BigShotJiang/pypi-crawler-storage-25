"""Tests for multi-file upload CLI."""

import json
from pathlib import Path

import httpx
import pytest
import respx
from typer.testing import CliRunner

from sparki.cli import app


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


@pytest.fixture(autouse=True)
def fake_home(tmp_path: Path, monkeypatch):
    cfg_dir = tmp_path / ".openclaw" / "config"
    cfg_dir.mkdir(parents=True)
    monkeypatch.setattr("sparki.config.DEFAULT_CONFIG_DIR", cfg_dir)
    (cfg_dir / "sparki.json").write_text(json.dumps({
        "api_key": "KEY",
        "base_url": "https://agent-api.sparki.io",
    }))
    monkeypatch.delenv("SPARKI_API_KEY", raising=False)
    return cfg_dir


def _make_video(p: Path, size: int = 1024) -> Path:
    p.write_bytes(b"x" * size)
    return p


@respx.mock
def test_upload_positional_two_files(runner: CliRunner, tmp_path: Path):
    a = _make_video(tmp_path / "a.mp4")
    b = _make_video(tmp_path / "b.mp4")
    respx.post("https://agent-api.sparki.io/api/v1/assets/upload").mock(
        side_effect=[
            httpx.Response(200, json={"code": 200, "data": {"object_key": "kA", "file_name": "a.mp4"}}),
            httpx.Response(200, json={"code": 200, "data": {"object_key": "kB", "file_name": "b.mp4"}}),
        ]
    )
    result = runner.invoke(app, ["upload", str(a), str(b), "--max-retries", "0", "--quiet"])
    assert result.exit_code == 0, result.stdout
    payload = json.loads(result.stdout)
    assert payload["ok"] is True
    assert payload["data"]["summary"]["ok"] == 2
    assert payload["data"]["summary"]["failed"] == 0


@respx.mock
def test_upload_backward_compat_file_flag(runner: CliRunner, tmp_path: Path):
    a = _make_video(tmp_path / "a.mp4")
    respx.post("https://agent-api.sparki.io/api/v1/assets/upload").mock(
        return_value=httpx.Response(200, json={"code": 200, "data": {"object_key": "kA", "file_name": "a.mp4"}})
    )
    result = runner.invoke(app, ["upload", "--file", str(a), "--max-retries", "0", "--quiet"])
    assert result.exit_code == 0, result.stdout
    payload = json.loads(result.stdout)
    assert payload["data"]["summary"]["ok"] == 1


@respx.mock
def test_upload_dir_scans_video_files(runner: CliRunner, tmp_path: Path):
    d = tmp_path / "clips"; d.mkdir()
    _make_video(d / "x.mp4")
    _make_video(d / "y.mov")
    (d / "ignored.txt").write_text("not a video")
    respx.post("https://agent-api.sparki.io/api/v1/assets/upload").mock(
        side_effect=[
            httpx.Response(200, json={"code": 200, "data": {"object_key": "kX"}}),
            httpx.Response(200, json={"code": 200, "data": {"object_key": "kY"}}),
        ]
    )
    result = runner.invoke(app, ["upload", "--dir", str(d), "--max-retries", "0", "--quiet"])
    assert result.exit_code == 0, result.stdout
    payload = json.loads(result.stdout)
    assert payload["data"]["summary"]["ok"] == 2


@respx.mock
def test_upload_partial_failure(runner: CliRunner, tmp_path: Path):
    a = _make_video(tmp_path / "a.mp4")
    b = _make_video(tmp_path / "b.mp4")
    respx.post("https://agent-api.sparki.io/api/v1/assets/upload").mock(
        side_effect=[
            httpx.Response(200, json={"code": 200, "data": {"object_key": "kA"}}),
            httpx.Response(400, json={"error": "bad file"}),
        ]
    )
    result = runner.invoke(app, ["upload", str(a), str(b), "--max-retries", "0", "--quiet"])
    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["data"]["summary"]["ok"] == 1
    assert payload["data"]["summary"]["failed"] == 1


@respx.mock
def test_upload_all_failures(runner: CliRunner, tmp_path: Path):
    a = _make_video(tmp_path / "a.mp4")
    respx.post("https://agent-api.sparki.io/api/v1/assets/upload").mock(
        return_value=httpx.Response(400, json={"error": "bad"})
    )
    result = runner.invoke(app, ["upload", str(a), "--max-retries", "0", "--quiet"])
    assert result.exit_code == 0  # exit code is 0 even when print_error runs (no typer.Exit in upload)
    payload = json.loads(result.stdout)
    assert payload["ok"] is False
    assert payload["error"]["code"] == "UPLOAD_FAILED"
