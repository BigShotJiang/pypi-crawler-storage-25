"""Tests for file_input gathering helper."""

from pathlib import Path

import pytest

from sparki.file_input import gather_files, GatherError


@pytest.fixture
def vid_dir(tmp_path: Path) -> Path:
    d = tmp_path / "clips"
    d.mkdir()
    (d / "a.mp4").write_bytes(b"x")
    (d / "b.MOV").write_bytes(b"x")
    (d / "c.txt").write_text("not a video")
    sub = d / "nested"
    sub.mkdir()
    (sub / "nope.mp4").write_bytes(b"x")
    return d


def test_gather_positional_only(tmp_path: Path):
    p1 = tmp_path / "a.mp4"; p1.write_bytes(b"x")
    p2 = tmp_path / "b.mov"; p2.write_bytes(b"x")
    files = gather_files(positional=[p1, p2], file_opts=[], dir_path=None)
    assert files == [p1, p2]


def test_gather_file_opts_only(tmp_path: Path):
    p1 = tmp_path / "a.mp4"; p1.write_bytes(b"x")
    files = gather_files(positional=[], file_opts=[p1], dir_path=None)
    assert files == [p1]


def test_gather_dir_filters_and_is_not_recursive(vid_dir: Path):
    files = gather_files(positional=[], file_opts=[], dir_path=vid_dir)
    names = sorted(p.name for p in files)
    assert names == ["a.mp4", "b.MOV"]


def test_gather_merges_and_dedups(tmp_path: Path):
    p1 = tmp_path / "a.mp4"; p1.write_bytes(b"x")
    p2 = tmp_path / "b.mp4"; p2.write_bytes(b"x")
    files = gather_files(
        positional=[p1, p2],
        file_opts=[p1],
        dir_path=None,
    )
    assert files == [p1, p2]


def test_gather_empty_raises(tmp_path: Path):
    with pytest.raises(GatherError):
        gather_files(positional=[], file_opts=[], dir_path=None)


def test_gather_dir_missing_raises(tmp_path: Path):
    with pytest.raises(GatherError):
        gather_files(positional=[], file_opts=[], dir_path=tmp_path / "nope")


def test_gather_dir_empty_video_dir_raises(tmp_path: Path):
    empty = tmp_path / "empty"; empty.mkdir()
    with pytest.raises(GatherError):
        gather_files(positional=[], file_opts=[], dir_path=empty)
