"""Tests for retry helper."""

import httpx
import pytest

from sparki.retry import RETRYABLE_STATUS, is_retryable_exception, with_retries


class _FlakyCounter:
    def __init__(self, fail_times: int, error: Exception):
        self.fail_times = fail_times
        self.error = error
        self.calls = 0

    async def __call__(self) -> str:
        self.calls += 1
        if self.calls <= self.fail_times:
            raise self.error
        return "ok"


@pytest.mark.asyncio
async def test_succeeds_first_try():
    c = _FlakyCounter(0, RuntimeError("never raised"))
    result = await with_retries(c, max_retries=3, base_delay=0, factor=1, max_delay=0)
    assert result == "ok"
    assert c.calls == 1


@pytest.mark.asyncio
async def test_retries_on_transport_error_then_succeeds():
    c = _FlakyCounter(2, httpx.ConnectError("boom"))
    result = await with_retries(c, max_retries=3, base_delay=0, factor=1, max_delay=0)
    assert result == "ok"
    assert c.calls == 3


@pytest.mark.asyncio
async def test_retries_on_5xx_status_error():
    request = httpx.Request("POST", "http://example.com")
    response = httpx.Response(503, request=request)
    status_err = httpx.HTTPStatusError("5xx", request=request, response=response)
    c = _FlakyCounter(1, status_err)
    result = await with_retries(c, max_retries=3, base_delay=0, factor=1, max_delay=0)
    assert result == "ok"
    assert c.calls == 2


@pytest.mark.asyncio
async def test_retries_on_429():
    request = httpx.Request("POST", "http://example.com")
    response = httpx.Response(429, request=request)
    err = httpx.HTTPStatusError("429", request=request, response=response)
    c = _FlakyCounter(1, err)
    await with_retries(c, max_retries=3, base_delay=0, factor=1, max_delay=0)
    assert c.calls == 2


@pytest.mark.asyncio
async def test_does_not_retry_4xx_except_429():
    request = httpx.Request("POST", "http://example.com")
    response = httpx.Response(400, request=request)
    err = httpx.HTTPStatusError("400", request=request, response=response)
    c = _FlakyCounter(10, err)
    with pytest.raises(httpx.HTTPStatusError):
        await with_retries(c, max_retries=3, base_delay=0, factor=1, max_delay=0)
    assert c.calls == 1


@pytest.mark.asyncio
async def test_max_retries_zero_disables_retry():
    c = _FlakyCounter(1, httpx.ConnectError("boom"))
    with pytest.raises(httpx.ConnectError):
        await with_retries(c, max_retries=0, base_delay=0, factor=1, max_delay=0)
    assert c.calls == 1


@pytest.mark.asyncio
async def test_exhausts_retries_and_raises_last_error():
    c = _FlakyCounter(10, httpx.ConnectError("boom"))
    with pytest.raises(httpx.ConnectError):
        await with_retries(c, max_retries=2, base_delay=0, factor=1, max_delay=0)
    assert c.calls == 3


def test_is_retryable_status():
    assert 500 in RETRYABLE_STATUS
    assert 502 in RETRYABLE_STATUS
    assert 503 in RETRYABLE_STATUS
    assert 429 in RETRYABLE_STATUS
    assert 400 not in RETRYABLE_STATUS
    assert 404 not in RETRYABLE_STATUS


def test_is_retryable_exception():
    assert is_retryable_exception(httpx.ConnectError("x"))
    assert is_retryable_exception(httpx.ReadTimeout("x"))
    assert not is_retryable_exception(ValueError("x"))
