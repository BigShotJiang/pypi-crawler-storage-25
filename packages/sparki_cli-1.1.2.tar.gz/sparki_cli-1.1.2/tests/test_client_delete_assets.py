"""Tests for SparkiClient.delete_assets."""

import json as _json

import httpx
import pytest
import respx

from sparki.client import SparkiClient


@pytest.mark.asyncio
@respx.mock
async def test_delete_assets_sends_correct_body():
    route = respx.post("https://api.example.com/api/v1/assets/batch_delete").mock(
        return_value=httpx.Response(200, json={
            "code": 200,
            "data": {
                "items": [
                    {"object_key": "k1", "success": True, "message": None},
                    {"object_key": "k2", "success": False, "message": "Asset not found"},
                ],
                "success_count": 1,
                "failed_count": 1,
            },
        })
    )
    client = SparkiClient(base_url="https://api.example.com", api_key="KEY")
    result = await client.delete_assets(["k1", "k2"])

    assert route.called
    req = route.calls[0].request
    assert req.headers.get("X-API-Key") == "KEY"
    body = _json.loads(req.content)
    assert body == {"object_keys": ["k1", "k2"]}
    assert result["code"] == 200
    assert result["data"]["success_count"] == 1


@pytest.mark.asyncio
@respx.mock
async def test_delete_assets_raises_on_error_status():
    respx.post("https://api.example.com/api/v1/assets/batch_delete").mock(
        return_value=httpx.Response(500, json={"error": "boom"})
    )
    client = SparkiClient(base_url="https://api.example.com", api_key="KEY")
    with pytest.raises(httpx.HTTPStatusError):
        await client.delete_assets(["k1"])
