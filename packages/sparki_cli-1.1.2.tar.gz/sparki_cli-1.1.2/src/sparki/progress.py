"""Upload progress reporter — stderr only, percent-stepped."""

import sys

from sparki.constants import PROGRESS_REPORT_PERCENT_STEP


def _format_bytes(n: int) -> str:
    if n >= 1024 ** 3:
        return f"{n / 1024 ** 3:.1f}GB"
    if n >= 1024 ** 2:
        return f"{n / 1024 ** 2:.0f}MB"
    if n >= 1024:
        return f"{n / 1024:.0f}KB"
    return f"{n}B"


class UploadProgress:
    """Track bytes uploaded for a single file and print percent-stepped
    progress to stderr. No-op when quiet or total<=0."""

    def __init__(self, label: str, total: int, quiet: bool = False):
        self.label = label
        self.total = total
        self.quiet = quiet
        self._sent = 0
        self._last_reported_percent = -1

    def update(self, n_bytes: int) -> None:
        if self.quiet or self.total <= 0:
            return
        self._sent += n_bytes
        pct = int(self._sent * 100 / self.total)
        if pct >= self._last_reported_percent + PROGRESS_REPORT_PERCENT_STEP or pct >= 100:
            self._last_reported_percent = pct
            print(
                f"Uploading {self.label}: {pct}% "
                f"({_format_bytes(self._sent)}/{_format_bytes(self.total)})",
                file=sys.stderr,
                flush=True,
            )
