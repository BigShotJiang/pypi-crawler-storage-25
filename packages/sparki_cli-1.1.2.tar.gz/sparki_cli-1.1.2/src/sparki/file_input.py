"""Gather video files from positional args, --file, and --dir into a deduped list."""

from pathlib import Path

from sparki.constants import ALLOWED_EXTENSIONS


class GatherError(ValueError):
    """Raised when no valid files could be gathered."""


def _is_video_file(p: Path) -> bool:
    return p.is_file() and p.suffix.lstrip(".").lower() in ALLOWED_EXTENSIONS


def gather_files(
    positional: list[Path],
    file_opts: list[Path],
    dir_path: Path | None,
) -> list[Path]:
    """Merge positional args, --file options, and --dir scan into a deduped
    ordered list (first-seen wins). Non-recursive for --dir."""
    collected: list[Path] = []

    if dir_path is not None:
        if not dir_path.exists() or not dir_path.is_dir():
            raise GatherError(f"Directory not found: {dir_path}")
        dir_files = sorted(
            p for p in dir_path.iterdir()
            if _is_video_file(p)
        )
        if not dir_files:
            raise GatherError(
                f"No mp4/mov files found in directory: {dir_path}"
            )
        collected.extend(dir_files)

    for p in list(positional) + list(file_opts):
        if p not in collected:
            collected.append(p)

    if not collected:
        raise GatherError("No input files provided")

    return collected
