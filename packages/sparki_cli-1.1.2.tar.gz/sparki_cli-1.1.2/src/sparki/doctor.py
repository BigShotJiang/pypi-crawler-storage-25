"""Implementation of `sparki doctor` — environment/config self-check."""

from __future__ import annotations

import asyncio
import importlib.metadata
import os
import re
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import httpx

from sparki.client import SparkiClient
from sparki.config import Config, DEFAULT_CONFIG_DIR
from sparki.constants import EXPECTED_API_HOSTS, PYPI_JSON_URL, SKILL_SLUG


def _version_tuple(v: str) -> tuple[int, ...]:
    """Parse a dotted version into an int tuple; non-numeric parts become 0."""
    parts: list[int] = []
    for p in v.split("."):
        num = "".join(ch for ch in p if ch.isdigit())
        parts.append(int(num) if num else 0)
    return tuple(parts)


def _cli_version() -> str | None:
    try:
        return importlib.metadata.version("sparki-cli")
    except importlib.metadata.PackageNotFoundError:
        return None


async def _pypi_latest(url: str = PYPI_JSON_URL) -> str | None:
    try:
        async with httpx.AsyncClient(timeout=3.0) as c:
            resp = await c.get(url)
            resp.raise_for_status()
            return resp.json().get("info", {}).get("version")
    except Exception:
        return None


def _skill_md_paths(cwd: Path) -> list[Path]:
    """Candidate SKILL.md locations, in priority order.

    Covers explicit env var overrides, cwd + a few parents (for agents running
    inside the skill dir), and well-known Openclaw install paths (so the check
    still works when `sparki doctor` is invoked from an arbitrary cwd).
    """
    paths: list[Path] = []

    for env_var in ("CLAWDBOT_SKILL_DIR", "OPENCLAW_SKILL_DIR", "SKILL_DIR"):
        v = os.environ.get(env_var)
        if v:
            paths.append(Path(v) / "SKILL.md")

    paths.append(cwd / "SKILL.md")
    for parent in list(cwd.parents)[:4]:
        paths.append(parent / "SKILL.md")

    state_dir = os.environ.get("OPENCLAW_STATE_DIR")
    if state_dir:
        paths.append(Path(state_dir) / "workspace" / "skills" / SKILL_SLUG / "SKILL.md")

    home = Path(os.path.expanduser("~"))
    paths.append(home / ".openclaw" / "workspace" / "skills" / SKILL_SLUG / "SKILL.md")
    try:
        for d in sorted(home.glob(".openclaw-*")):
            paths.append(d / "workspace" / "skills" / SKILL_SLUG / "SKILL.md")
    except OSError:
        pass

    return paths


# Regex-extract the YAML frontmatter's network.domains without a YAML parser.
_DOMAINS_RE = re.compile(
    r"network:\s*\n\s+domains:\s*\[([^\]]+)\]",
    re.MULTILINE,
)


def _parse_skill_domains(skill_md_text: str) -> list[str] | None:
    if not skill_md_text.startswith("---"):
        return None
    end = skill_md_text.find("\n---", 3)
    if end == -1:
        return None
    frontmatter = skill_md_text[:end]
    m = _DOMAINS_RE.search(frontmatter)
    if not m:
        return None
    raw = m.group(1)
    return [d.strip().strip('"').strip("'") for d in raw.split(",") if d.strip()]


def _find_skill_domains(cwd: Path) -> list[str] | None:
    for p in _skill_md_paths(cwd):
        if p.exists():
            try:
                return _parse_skill_domains(p.read_text())
            except Exception:
                continue
    return None


async def run_checks(cwd: Path, do_fix: bool = False) -> tuple[bool, list[dict[str, Any]]]:
    checks: list[dict[str, Any]] = []
    overall_ok = True

    # 1. CLI version
    ver = _cli_version()
    if ver:
        checks.append({"name": "cli_version", "status": "pass", "value": ver})
    else:
        checks.append({
            "name": "cli_version",
            "status": "fail",
            "error": "sparki-cli package metadata not found",
            "action": "uv tool install --force --upgrade sparki-cli",
        })
        overall_ok = False

    # 2. CLI latest (best-effort)
    latest = await _pypi_latest()
    if latest is None:
        checks.append({
            "name": "cli_latest",
            "status": "skip",
            "error": "Could not reach PyPI",
        })
    elif ver:
        if _version_tuple(ver) >= _version_tuple(latest):
            checks.append({
                "name": "cli_latest",
                "status": "pass",
                "value": ver,
                "latest": latest,
            })
        else:
            checks.append({
                "name": "cli_latest",
                "status": "fail",
                "value": ver,
                "latest": latest,
                "action": "uv tool install --upgrade sparki-cli",
            })
            overall_ok = False

    # 3 & 4. API key existence + validity
    # Re-read DEFAULT_CONFIG_DIR dynamically so tests that monkeypatch it work.
    from sparki.config import DEFAULT_CONFIG_DIR as _CFG_DIR
    cfg = Config(config_dir=_CFG_DIR)
    if not cfg.api_key:
        checks.append({
            "name": "api_key",
            "status": "fail",
            "error": "No API key configured",
            "action": "Run `sparki setup --api-key <YOUR_KEY>`; get a key from @Sparki_AI_bot on Telegram",
        })
        overall_ok = False
    else:
        try:
            client = SparkiClient(base_url=cfg.base_url, api_key=cfg.api_key)
            valid = await client.validate_key()
            err_msg = None if valid else "Key rejected by server"
        except Exception as e:
            valid = False
            err_msg = str(e)
        if valid:
            checks.append({"name": "api_key", "status": "pass"})
        else:
            checks.append({
                "name": "api_key",
                "status": "fail",
                "error": err_msg,
                "action": "Get a new key from @Sparki_AI_bot on Telegram",
            })
            overall_ok = False

    # 5. Base URL matches SKILL manifest (if findable) OR CLI's expected hosts.
    #    SKILL.md-declared domains take precedence when available; otherwise
    #    fall back to the CLI's own constants, which are authoritative for
    #    the backend this CLI version targets.
    skill_domains = _find_skill_domains(cwd)
    authoritative_domains = skill_domains if skill_domains else list(EXPECTED_API_HOSTS)
    source = "SKILL.md" if skill_domains else "CLI constants"
    host = urlparse(cfg.base_url).hostname or ""
    if any(host == d or host.endswith(f".{d}") for d in authoritative_domains):
        checks.append({
            "name": "base_url",
            "status": "pass",
            "value": cfg.base_url,
            "source": source,
        })
    else:
        checks.append({
            "name": "base_url",
            "status": "fail",
            "value": cfg.base_url,
            "source": source,
            "error": f"Base URL host '{host}' not in expected domains {sorted(authoritative_domains)} (from {source})",
            "action": "Re-run `sparki setup --api-key <KEY> --base-url https://<one-of-expected-domains>`",
        })
        overall_ok = False

    # 6. Config dir writable
    try:
        if do_fix:
            _CFG_DIR.mkdir(parents=True, exist_ok=True)
        writable = _CFG_DIR.exists() and os.access(_CFG_DIR, os.W_OK)
    except Exception:
        writable = False
    if writable:
        checks.append({
            "name": "config_dir",
            "status": "pass",
            "value": str(_CFG_DIR),
        })
    else:
        checks.append({
            "name": "config_dir",
            "status": "fail",
            "value": str(_CFG_DIR),
            "error": "Config dir not writable",
            "action": "Pass --fix to create, or `mkdir -p ~/.openclaw/config`",
        })
        overall_ok = False

    return overall_ok, checks


def run(cwd: Path | None = None, do_fix: bool = False) -> tuple[bool, list[dict[str, Any]]]:
    """Sync wrapper; returns (overall_ok, checks)."""
    return asyncio.run(run_checks(cwd or Path.cwd(), do_fix=do_fix))
