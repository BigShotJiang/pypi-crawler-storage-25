"""`sparki assets` sub-commands: list, delete."""

from __future__ import annotations

import asyncio
from typing import Annotated, Optional

import httpx
import typer

from sparki.client import SparkiClient
from sparki.config import Config, DEFAULT_CONFIG_DIR
from sparki.output import print_error, print_success, log

assets_app = typer.Typer(help="Manage uploaded assets.")


def _auth() -> tuple[Config, SparkiClient] | None:
    # Re-read DEFAULT_CONFIG_DIR dynamically so tests that monkeypatch it work.
    from sparki.config import DEFAULT_CONFIG_DIR as _CFG_DIR
    cfg = Config(config_dir=_CFG_DIR)
    if not cfg.api_key:
        print_error("AUTH_FAILED")
        return None
    return cfg, SparkiClient(base_url=cfg.base_url, api_key=cfg.api_key)


def _run_async(coro_fn):
    try:
        asyncio.run(coro_fn())
    except (httpx.HTTPError, httpx.StreamError) as e:
        print_error("NETWORK_ERROR", str(e))


@assets_app.callback(invoke_without_command=True)
def _default(
    ctx: typer.Context,
    limit: Annotated[int, typer.Option("--limit", help="Max number of assets (list mode only)")] = 20,
) -> None:
    """Default: list uploaded assets (backward-compat with flat `sparki assets`)."""
    if ctx.invoked_subcommand is not None:
        return
    _list_impl(limit=limit)


@assets_app.command("list")
def list_cmd(
    limit: Annotated[int, typer.Option("--limit", help="Max number of assets")] = 20,
) -> None:
    """List uploaded assets."""
    _list_impl(limit=limit)


def _list_impl(limit: int) -> None:
    auth = _auth()
    if auth is None:
        return
    _, client = auth

    async def _run() -> None:
        resp = await client.list_assets(page_size=limit)
        if resp.get("code") != 200:
            print_error("NETWORK_ERROR", resp.get("message"))
            return
        print_success(resp["data"])

    _run_async(_run)


@assets_app.command("delete")
def delete_cmd(
    object_keys: Annotated[Optional[list[str]], typer.Argument(
        help="Object keys to delete (positional, space-separated)"
    )] = None,
    object_key_opts: Annotated[Optional[list[str]], typer.Option(
        "--object-key", help="Object key to delete (repeatable)"
    )] = None,
    name: Annotated[Optional[list[str]], typer.Option(
        "--name", help="Match by file name (repeatable)"
    )] = None,
    delete_all: Annotated[bool, typer.Option(
        "--all", help="Delete all user assets"
    )] = False,
    yes: Annotated[bool, typer.Option(
        "--yes", help="Confirm destructive operation (required with --all)"
    )] = False,
) -> None:
    """Delete uploaded assets by key, name, or --all."""
    auth = _auth()
    if auth is None:
        return
    _, client = auth

    positional = list(object_keys or [])
    via_option = list(object_key_opts or [])
    names = list(name or [])

    async def _run() -> None:
        keys_to_delete: list[str] = []
        seen: set[str] = set()

        if delete_all:
            if not yes:
                resp = await client.list_assets(page=1, page_size=1000)
                assets = (resp.get("data") or {}).get("assets") \
                    or (resp.get("data") or {}).get("items") or []
                count = len(assets)
                log(f"This will delete {count} asset(s). Pass --yes to confirm.")
                print_error(
                    "CONFIRMATION_REQUIRED",
                    "--all requires --yes",
                    extra={"count": count},
                )
                raise typer.Exit(code=1)
            resp = await client.list_assets(page=1, page_size=1000)
            assets = (resp.get("data") or {}).get("assets") \
                or (resp.get("data") or {}).get("items") or []
            for a in assets:
                k = a.get("object_key") or a.get("objectKey")
                if k and k not in seen:
                    keys_to_delete.append(k)
                    seen.add(k)

        if names:
            resp = await client.list_assets(page=1, page_size=1000)
            assets = (resp.get("data") or {}).get("assets") \
                or (resp.get("data") or {}).get("items") or []
            by_name: dict[str, list[str]] = {}
            for a in assets:
                fname = a.get("file_name") or a.get("fileName") or ""
                k = a.get("object_key") or a.get("objectKey") or ""
                by_name.setdefault(fname, []).append(k)
            for n in names:
                hits = by_name.get(n, [])
                if len(hits) > 1:
                    log(f"Matched {len(hits)} assets for '{n}'")
                for k in hits:
                    if k and k not in seen:
                        keys_to_delete.append(k)
                        seen.add(k)

        for k in positional + via_option:
            if k and k not in seen:
                keys_to_delete.append(k)
                seen.add(k)

        if not keys_to_delete:
            print_error("UPLOAD_FAILED", "No assets matched the given criteria")
            raise typer.Exit(code=1)

        resp = await client.delete_assets(keys_to_delete)
        items = ((resp.get("data") or {}).get("items")) or []
        deleted, skipped, failures = [], [], []
        for it in items:
            k = it.get("object_key")
            if it.get("success"):
                deleted.append({"object_key": k})
            else:
                msg = (it.get("message") or "").lower()
                if "in use" in msg or "active" in msg:
                    skipped.append({"object_key": k, "reason": "in_use_by_active_project"})
                else:
                    failures.append({"object_key": k, "error": it.get("message")})
        print_success({
            "deleted": deleted,
            "skipped": skipped,
            "failures": failures,
            "summary": {
                "deleted": len(deleted),
                "skipped": len(skipped),
                "failed": len(failures),
            },
        })

    _run_async(_run)
