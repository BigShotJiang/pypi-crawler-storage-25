"""HTTP API client wrapping all Sparki C-end API endpoints."""

from pathlib import Path
from typing import Any, Callable

import httpx

from sparki.constants import (
    DEFAULT_MAX_RETRIES,
    DEFAULT_UPLOAD_TIMEOUT,
    RETRY_BACKOFF_BASE_SECONDS,
    RETRY_BACKOFF_FACTOR,
    RETRY_BACKOFF_MAX_SECONDS,
)
from sparki.retry import with_retries

ProgressCallback = Callable[[int], None]


class _ProgressFile:
    """File wrapper that reports read byte count to a callback.

    Used so httpx multipart sees a normal file-like object while we capture
    per-chunk progress. The wrapper forwards all attributes except read().
    """

    def __init__(self, fileobj, progress: ProgressCallback):
        self._f = fileobj
        self._progress = progress

    def read(self, size: int = -1) -> bytes:
        chunk = self._f.read(size)
        if chunk:
            try:
                self._progress(len(chunk))
            except Exception:
                pass
        return chunk

    def __getattr__(self, name):
        return getattr(self._f, name)


class SparkiClient:
    def __init__(self, base_url: str, api_key: str):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self._headers = {"X-API-Key": api_key}

    def _url(self, path: str) -> str:
        return f"{self.base_url}{path}"

    async def validate_key(self) -> bool:
        async with httpx.AsyncClient() as c:
            resp = await c.get(self._url("/api/v1/account/info"),
                               headers=self._headers)
            return resp.status_code == 200

    async def upload_asset(
        self,
        file_path: Path,
        *,
        max_retries: int = DEFAULT_MAX_RETRIES,
        timeout: int = DEFAULT_UPLOAD_TIMEOUT,
        progress: ProgressCallback | None = None,
        on_retry: Callable[[int, BaseException, float], None] | None = None,
    ) -> dict[str, Any]:
        """Upload a single file with retries and optional progress reporting.

        Progress callback receives delta bytes per read chunk.
        """
        ctype = f"video/{file_path.suffix.lstrip('.').lower()}"

        async def _do_upload() -> dict[str, Any]:
            async with httpx.AsyncClient(timeout=timeout) as c:
                with open(file_path, "rb") as f:
                    fobj: Any = _ProgressFile(f, progress) if progress is not None else f
                    files = {"file": (file_path.name, fobj, ctype)}
                    resp = await c.post(
                        self._url("/api/v1/assets/upload"),
                        headers=self._headers, files=files,
                    )
                resp.raise_for_status()
                return resp.json()

        return await with_retries(
            _do_upload,
            max_retries=max_retries,
            base_delay=RETRY_BACKOFF_BASE_SECONDS,
            factor=RETRY_BACKOFF_FACTOR,
            max_delay=RETRY_BACKOFF_MAX_SECONDS,
            on_retry=on_retry,
        )

    async def delete_assets(self, object_keys: list[str]) -> dict[str, Any]:
        async with httpx.AsyncClient(timeout=30) as c:
            resp = await c.post(
                self._url("/api/v1/assets/batch_delete"),
                headers=self._headers,
                json={"object_keys": object_keys},
            )
            resp.raise_for_status()
            return resp.json()

    async def list_assets(self, page: int = 1, page_size: int = 20) -> dict[str, Any]:
        params: dict[str, Any] = {"page": page, "page_size": page_size}
        async with httpx.AsyncClient() as c:
            resp = await c.get(self._url("/api/v1/assets/user_assets"),
                               headers=self._headers, params=params)
            return resp.json()

    async def get_asset_status(self, object_key: str) -> dict[str, Any]:
        page = 1
        page_size = 50
        while True:
            result = await self.list_assets(page=page, page_size=page_size)
            data = result.get("data", {})
            items = data.get("assets", data.get("items", []))
            for item in items:
                if item.get("object_key") == object_key or item.get("objectKey") == object_key:
                    return {"code": result.get("code"), "data": item}
            if len(items) < page_size:
                break
            page += 1
        return {"code": result.get("code"), "data": None}

    async def create_project(
        self,
        object_keys: list[str],
        tags: list[str],
        user_input: str = "",
        aspect_ratio: str = "9:16",
        agent_type: str | None = None,
        duration_range: str | None = None,
    ) -> dict[str, Any]:
        resources = [{"idx": i, "s3_object_key": key}
                     for i, key in enumerate(object_keys)]
        body: dict[str, Any] = {
            "resources": resources,
            "user_input": user_input,
            "generation_preferences": {"aspect_ratio": aspect_ratio},
            "send_after_create": True,
        }
        if tags:
            body["tags"] = tags
        if agent_type:
            body["agent_type"] = agent_type
        if duration_range:
            body["generation_preferences"]["duration_range"] = duration_range
        async with httpx.AsyncClient() as c:
            resp = await c.post(self._url("/api/v1/projects/"),
                                headers=self._headers, json=body)
            return resp.json()

    async def get_project_status(self, task_id: str) -> dict[str, Any]:
        async with httpx.AsyncClient() as c:
            resp = await c.get(self._url(f"/api/v1/projects/task/{task_id}"),
                               headers=self._headers)
            return resp.json()

    async def create_emulate_project(
        self,
        source_object_keys: list[str],
        reference_object_key: str | None = None,
        reference_url: str | None = None,
        user_input: str = "",
        aspect_ratio: str = "9:16",
    ) -> dict[str, Any]:
        ref: dict[str, Any] = {"idx": 0, "media_type": "video"}
        if reference_object_key:
            ref["s3_object_key"] = reference_object_key
        elif reference_url:
            ref["video_url"] = reference_url

        sources = [{"idx": i, "s3_object_key": key, "media_type": "video"}
                   for i, key in enumerate(source_object_keys)]

        body: dict[str, Any] = {
            "reference_resource": [ref],
            "resources": sources,
            "user_input": user_input,
            "send_after_create": True,
            "generation_preferences": {"aspect_ratio": aspect_ratio},
        }
        async with httpx.AsyncClient() as c:
            resp = await c.post(self._url("/api/v1/emulate/projects/"),
                                headers=self._headers, json=body)
            return resp.json()

    async def get_emulate_project_status(self, task_id: str) -> dict[str, Any]:
        async with httpx.AsyncClient() as c:
            resp = await c.get(
                self._url(f"/api/v1/emulate/projects/task/{task_id}"),
                headers=self._headers)
            return resp.json()

    async def download_result(self, url: str, output_path: Path) -> int:
        async with httpx.AsyncClient(timeout=600, follow_redirects=True) as c:
            async with c.stream("GET", url) as resp:
                resp.raise_for_status()
                output_path.parent.mkdir(parents=True, exist_ok=True)
                total = 0
                with open(output_path, "wb") as f:
                    async for chunk in resp.aiter_bytes(chunk_size=1024 * 1024):
                        f.write(chunk)
                        total += len(chunk)
                return total
