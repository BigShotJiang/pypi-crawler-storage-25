"""Unified JSON output formatter for all CLI commands."""

import json
import sys
from typing import Any

from sparki.constants import ERROR_CODES


def success(data: dict[str, Any]) -> str:
    return json.dumps({"ok": True, "data": data, "error": None}, ensure_ascii=False)


def format_error(
    code: str,
    message: str | None = None,
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    defaults = ERROR_CODES.get(code, {
        "message": "An unexpected error occurred",
        "action": "Please try again or contact support",
    })
    payload: dict[str, Any] = {
        "code": code,
        "message": message or defaults["message"],
        "action": defaults["action"],
    }
    if extra:
        payload.update(extra)
    return payload


def error(
    code: str,
    message: str | None = None,
    extra: dict[str, Any] | None = None,
) -> str:
    return json.dumps(
        {"ok": False, "data": None, "error": format_error(code, message, extra)},
        ensure_ascii=False,
    )


def print_success(data: dict[str, Any]) -> None:
    print(success(data))


def print_error(
    code: str,
    message: str | None = None,
    extra: dict[str, Any] | None = None,
) -> None:
    print(error(code, message, extra))


def log(msg: str) -> None:
    print(msg, file=sys.stderr)


def warn(msg: str) -> None:
    print(f"[warn] {msg}", file=sys.stderr)
