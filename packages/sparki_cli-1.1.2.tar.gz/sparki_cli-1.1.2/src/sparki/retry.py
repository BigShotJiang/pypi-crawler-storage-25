"""Async retry helper with exponential backoff for HTTP calls."""

import asyncio
from typing import Awaitable, Callable, TypeVar

import httpx

T = TypeVar("T")

RETRYABLE_STATUS = frozenset({429, 500, 502, 503, 504})

_RETRYABLE_EXCEPTION_TYPES = (
    httpx.ConnectError,
    httpx.ReadTimeout,
    httpx.WriteTimeout,
    httpx.PoolTimeout,
    httpx.RemoteProtocolError,
    httpx.ConnectTimeout,
)


def is_retryable_exception(exc: BaseException) -> bool:
    if isinstance(exc, _RETRYABLE_EXCEPTION_TYPES):
        return True
    if isinstance(exc, httpx.HTTPStatusError):
        return exc.response.status_code in RETRYABLE_STATUS
    return False


async def with_retries(
    fn: Callable[[], Awaitable[T]],
    *,
    max_retries: int,
    base_delay: float,
    factor: float,
    max_delay: float,
    on_retry: Callable[[int, BaseException, float], None] | None = None,
) -> T:
    attempt = 0
    while True:
        try:
            return await fn()
        except BaseException as exc:
            if not is_retryable_exception(exc):
                raise
            if attempt >= max_retries:
                raise
            delay = min(base_delay * (factor ** attempt), max_delay)
            if on_retry is not None:
                try:
                    on_retry(attempt + 1, exc, delay)
                except Exception:
                    pass
            if delay > 0:
                await asyncio.sleep(delay)
            attempt += 1
