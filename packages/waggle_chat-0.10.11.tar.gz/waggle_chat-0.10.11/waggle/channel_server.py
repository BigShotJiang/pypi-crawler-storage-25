"""waggle channel-mode MCP server.

Runs as Claude Code's child process (stdio MCP), combining:
- claude/channel capability → push Telegram messages into Claude's context
- Tools (reply, react, edit_message, etc.) → Claude sends messages to Telegram

Architecture:
  Claude Code (parent, interactive mode)
      │
      └── waggle channel_server (stdio MCP child)
              ├── Telegram polling (aiogram)
              ├── Inject HTTP endpoint (:8090)
              ├── Hook receiver (:8091)
              ├── Access control
              ├── Rate limiting
              └── Owner ops

This replaces the CLI-mode architecture where waggle is parent and Claude
is a stream-json subprocess. The channel tag format is identical — Claude
sees the same <channel> tags regardless of mode.
"""

from __future__ import annotations

import asyncio
import logging
import os
import signal
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from aiogram import Bot
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.types import FSInputFile, InlineKeyboardButton, InlineKeyboardMarkup, ReactionTypeEmoji
from mcp.server import NotificationOptions, Server
from mcp.server.models import InitializationOptions
from mcp.server.session import ServerSession
from mcp.server.stdio import stdio_server
from mcp.shared.message import SessionMessage, ServerMessageMetadata
import mcp.types as mt

from .access import AccessControl
from .channel_tag import ChannelTag
from .config import Config, load as load_config
from .events import AcceptEvent, EventSink, RejectEvent, build_sink
from .hook_receiver import HookReceiver
from .owner_ops import OwnerState
from .rate_limit import RateLimiter

log = logging.getLogger(__name__)


def _ok(msg: str) -> list[mt.TextContent]:
    return [mt.TextContent(type="text", text=msg)]


def _err(msg: str) -> list[mt.TextContent]:
    return [mt.TextContent(type="text", text=f"error: {msg}")]


# Import tool schemas from tools_server to avoid duplication.
from .tools_server import _TOOL_SCHEMAS, SERVER_INSTRUCTIONS


SERVER_NAME = "waggle"
SERVER_VERSION = "0.10.0"


class ChannelModeServer:
    """Unified MCP server: channel notifications + Telegram tools."""

    def __init__(self, config: Config, config_path: Path):
        self.config = config
        self.access = AccessControl(config_path)
        self.events: EventSink = build_sink(
            config.events.sink if config.events.sink is not None
            else config.events.reject_sink
        )
        self.rate_limiter = RateLimiter(self.access.rate_limit)
        self.access.on_rate_limit_change(self.rate_limiter.update_config)
        self.owner_state = OwnerState()

        # MCP server with channel capability
        self.mcp = Server(SERVER_NAME)

        # Telegram bot — send-only instance (same as tools_server)
        token = config.transports[0].model_dump()["bot_token"]
        self._bot = Bot(
            token=token,
            default=DefaultBotProperties(parse_mode=ParseMode.HTML),
        )

        # Hook receiver on :8091
        hook_port = int(os.environ.get("WAGGLE_HOOK_PORT", "8091"))
        self._hook_receiver = HookReceiver(port=hook_port)

        # Telegram client for polling — lazily imported to avoid circular deps
        self._telegram_client = None
        self._telegram_task: asyncio.Task | None = None

        # MCP session — captured during stdio_server run, used for notifications
        self._session: ServerSession | None = None

        self._wire_tools()

    def _wire_tools(self) -> None:
        @self.mcp.list_tools()
        async def _list_tools() -> list[mt.Tool]:
            # Capture session early — list_tools fires during initialization
            if self._session is None:
                try:
                    self._session = self.mcp.request_context.session
                    log.info("MCP session captured from list_tools — channel notifications ready")
                except Exception:
                    pass
            tools = []
            for name, (desc, schema) in _TOOL_SCHEMAS.items():
                if name == "request_permission":
                    continue
                tools.append(mt.Tool(name=name, description=desc, inputSchema=schema))
            return tools

        @self.mcp.call_tool()
        async def _call_tool(name: str, arguments: dict) -> list[mt.TextContent]:
            # Capture session on first tool call (request_context is available here)
            if self._session is None:
                try:
                    self._session = self.mcp.request_context.session
                    log.info("MCP session captured — channel notifications ready")
                except Exception:
                    pass
            try:
                return await self._dispatch_tool(name, arguments)
            except Exception as e:
                log.exception("tool %s failed: %r", name, e)
                return _err(str(e))

    async def _dispatch_tool(self, name: str, args: dict) -> list[mt.TextContent]:
        """Route tool calls to Telegram API — same logic as tools_server."""
        bot = self._bot

        if name == "reply" or name == "send_to_chat":
            chat_id = args["chat_id"]
            text = args["text"]
            fmt = args.get("format", "text")
            spoiler = args.get("spoiler", False)
            reply_to = args.get("reply_to")
            thread_id = args.get("message_thread_id")

            parse_mode_val = ParseMode.MARKDOWN_V2 if fmt == "markdownv2" or spoiler else None

            if spoiler:
                text = f"||{text}||"

            kwargs: dict[str, Any] = {"chat_id": int(chat_id), "text": text}
            if parse_mode_val:
                kwargs["parse_mode"] = parse_mode_val
            if reply_to:
                kwargs["reply_to_message_id"] = int(reply_to)
            if thread_id:
                kwargs["message_thread_id"] = int(thread_id)

            msg = await bot.send_message(**kwargs)
            return _ok(f"sent (id: {msg.message_id})")

        elif name == "react":
            await bot.set_message_reaction(
                chat_id=int(args["chat_id"]),
                message_id=int(args["message_id"]),
                reaction=[ReactionTypeEmoji(emoji=args["emoji"])],
            )
            return _ok("reacted")

        elif name == "edit_message":
            await bot.edit_message_text(
                chat_id=int(args["chat_id"]),
                message_id=int(args["message_id"]),
                text=args["text"],
            )
            return _ok("edited")

        elif name == "download_attachment":
            import tempfile
            file = await bot.get_file(args["file_id"])
            if not file.file_path:
                return _err("file_path not available")
            dest = os.path.join(tempfile.gettempdir(), "waggle-attachments", os.path.basename(file.file_path))
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            await bot.download_file(file.file_path, dest)
            return _ok(dest)

        elif name == "send_photo":
            chat_id = int(args["chat_id"])
            path = args["path"]
            caption = args.get("caption")
            spoiler = args.get("spoiler", False)
            reply_to = args.get("reply_to")
            thread_id = args.get("message_thread_id")
            fmt = args.get("format", "text")
            parse_mode_val = ParseMode.MARKDOWN_V2 if fmt == "markdownv2" else None

            kwargs = {"chat_id": chat_id, "photo": FSInputFile(path), "has_spoiler": spoiler}
            if caption:
                kwargs["caption"] = caption
            if parse_mode_val:
                kwargs["parse_mode"] = parse_mode_val
            if reply_to:
                kwargs["reply_to_message_id"] = int(reply_to)
            if thread_id:
                kwargs["message_thread_id"] = int(thread_id)

            msg = await bot.send_photo(**kwargs)
            return _ok(f"sent photo (id: {msg.message_id})")

        elif name == "send_document":
            chat_id = int(args["chat_id"])
            path = args["path"]
            caption = args.get("caption")
            reply_to = args.get("reply_to")
            thread_id = args.get("message_thread_id")
            fmt = args.get("format", "text")
            parse_mode_val = ParseMode.MARKDOWN_V2 if fmt == "markdownv2" else None

            kwargs = {"chat_id": chat_id, "document": FSInputFile(path)}
            if caption:
                kwargs["caption"] = caption
            if parse_mode_val:
                kwargs["parse_mode"] = parse_mode_val
            if reply_to:
                kwargs["reply_to_message_id"] = int(reply_to)
            if thread_id:
                kwargs["message_thread_id"] = int(thread_id)

            msg = await bot.send_document(**kwargs)
            return _ok(f"sent document (id: {msg.message_id})")

        elif name == "reply_with_choices":
            chat_id = int(args["chat_id"])
            text = args["text"]
            choices = args["choices"]
            columns = args.get("columns", 1)
            reply_to = args.get("reply_to")
            thread_id = args.get("message_thread_id")
            fmt = args.get("format", "text")
            parse_mode_val = ParseMode.MARKDOWN_V2 if fmt == "markdownv2" else None

            rows = []
            row = []
            for c in choices:
                row.append(InlineKeyboardButton(text=c, callback_data=f"choice:{c[:60]}"))
                if len(row) >= columns:
                    rows.append(row)
                    row = []
            if row:
                rows.append(row)
            kb = InlineKeyboardMarkup(inline_keyboard=rows)

            kwargs = {"chat_id": chat_id, "text": text, "reply_markup": kb}
            if parse_mode_val:
                kwargs["parse_mode"] = parse_mode_val
            if reply_to:
                kwargs["reply_to_message_id"] = int(reply_to)
            if thread_id:
                kwargs["message_thread_id"] = int(thread_id)

            msg = await self._bot.send_message(**kwargs)
            return _ok(f"sent with {len(choices)} choices (id: {msg.message_id})")

        return _err(f"unknown tool: {name}")

    async def _push_notification(self, content: str, meta: dict[str, str]) -> None:
        """Push a channel notification to Claude via MCP."""
        session = self._session
        if session is None:
            log.warning("cannot push notification — MCP session not ready")
            return
        notification = mt.Notification(
            method="notifications/claude/channel",
            params={"content": content, "meta": meta},
        )
        try:
            # Build raw JSON-RPC notification — Notification model strips
            # free-form params via Pydantic validation. We need the raw
            # {content, meta} dict to reach Claude intact.
            raw_notification = mt.JSONRPCNotification(
                jsonrpc="2.0",
                method="notifications/claude/channel",
                params={"content": content, "meta": meta},
            )
            message = SessionMessage(
                message=mt.JSONRPCMessage(raw_notification),
            )
            await session.send_message(message)
            log.debug("channel notification pushed to Claude (raw)")
        except (BrokenPipeError, ConnectionError, OSError) as e:
            log.error("MCP pipe broken — Claude may have disconnected: %r", e)
        except Exception as e:
            log.error("notification push failed: %r", e)

    async def submit_inbound(
        self,
        *,
        chat_id: int,
        user_id: int,
        username: str,
        message_id: str,
        text: str,
        attachments: tuple[dict, ...] = (),
        ts: datetime | None = None,
        is_mentioned: bool = False,
        reply_to: dict | None = None,
        first_name: str = "",
        last_name: str = "",
        is_premium: bool | None = None,
        chat_type: str = "",
        chat_title: str = "",
        message_thread_id: str = "",
        is_topic_message: bool | None = None,
    ) -> None:
        """Called by the Telegram client when a message arrives.

        Same interface as WaggleOrchestrator.submit_inbound — the Telegram
        client doesn't need to know which mode it's in.
        """
        # Access control
        if not self.access.allows(chat_id, user_id, is_mentioned=is_mentioned):
            reason = "not-allowlisted" if chat_id >= 0 else "group-not-allowlisted"
            await self.events.emit_reject(
                RejectEvent(
                    reason=reason, source="telegram",
                    chat=str(chat_id), user=str(user_id),
                    text_preview=(text or "")[:80],
                    ts=datetime.now(timezone.utc),
                )
            )
            return

        # Rate limiting
        if user_id != self.config.owner.user_id:
            decision = self.rate_limiter.check(chat_id=chat_id, user_id=user_id)
            if not decision.allow:
                return

        # Build channel tag
        tag_kwargs = dict(
            username=username, first_name=first_name, last_name=last_name,
            is_premium=is_premium, chat_type=chat_type, chat_title=chat_title,
            message_thread_id=message_thread_id, is_topic_message=is_topic_message,
        )
        if ts is not None:
            tag = ChannelTag.at(source="telegram", chat=chat_id, user=user_id,
                                ts=ts, message_id=message_id, **tag_kwargs)
        else:
            tag = ChannelTag.now(source="telegram", chat=chat_id, user=user_id,
                                  message_id=message_id, **tag_kwargs)

        content = tag.render(text, attachments=attachments, reply_to=reply_to)

        # Build meta dict for the notification
        meta = {
            "chat_id": str(chat_id),
            "user": str(user_id),
            "username": username,
            "message_id": message_id,
            "ts": (ts or datetime.now(timezone.utc)).isoformat(),
        }

        log.info("→ channel notification chat=%s user=%s: %s",
                 chat_id, user_id, (text or "").replace("\n", " ")[:120])

        # Push to Claude via MCP notification
        try:
            await self._push_notification(content, meta)
        except Exception as e:
            log.error("failed to push notification: %r", e)

    async def submit_external(
        self,
        *,
        chat_id: int,
        prompt: str,
        source_label: str = "external",
        silent: bool = False,
    ) -> None:
        """External inject — same interface as WaggleOrchestrator."""
        tag = ChannelTag.now(source=source_label, chat=chat_id, user="external")
        content = tag.render(prompt)
        meta = {
            "chat_id": str(chat_id),
            "source": source_label,
            "ts": datetime.now(timezone.utc).isoformat(),
        }
        log.info("↪ external inject chat=%s: %s",
                 chat_id, prompt.replace("\n", " ")[:120])
        try:
            await self._push_notification(content, meta)
        except Exception as e:
            log.error("failed to push inject notification: %r", e)

    async def run(self) -> None:
        """Main entry: start all services, then run MCP stdio server."""
        # Ignore SIGPIPE — MCP stdio writes can trigger SIGPIPE if Claude's
        # pipe buffer is full or Claude closed its end. Default SIGPIPE kills
        # the process; we want to catch BrokenPipeError in Python instead.
        signal.signal(signal.SIGPIPE, signal.SIG_IGN)

        await self.access.start()
        await self._hook_receiver.start()

        # Start inject endpoint
        inject_server = None
        if self.config.inject.enabled:
            from .inject import InjectServer
            inject_server = InjectServer(
                bind=self.config.inject.bind,
                shared_secret=self.config.inject.shared_secret,
                default_chat_id=self.config.inject.default_chat_id,
                orchestrator=self,
            )
            await inject_server.start()

        # Start Telegram polling in background with resilient wrapper
        from .clients.telegram import TelegramClient
        self._telegram_client = TelegramClient.from_config(
            self.config.transports[0].model_dump()
        )

        async def _resilient_telegram():
            while True:
                try:
                    await self._telegram_client.run(self)
                except asyncio.CancelledError:
                    raise
                except Exception as e:
                    log.warning("telegram polling crashed, restarting in 5s: %r", e)
                    await asyncio.sleep(5)

        self._telegram_task = asyncio.create_task(_resilient_telegram())

        # Global exception handler — prevent unhandled exceptions from
        # killing the event loop (and thus the MCP server process).
        def _handle_exception(loop, context):
            exc = context.get("exception")
            msg = context.get("message", "")
            log.warning("unhandled async exception: %s %r", msg, exc)

        asyncio.get_event_loop().set_exception_handler(_handle_exception)

        # Monitor telegram task — restart on crash without killing MCP
        async def _telegram_watchdog():
            while True:
                if self._telegram_task is not None and self._telegram_task.done():
                    exc = self._telegram_task.exception() if not self._telegram_task.cancelled() else None
                    if exc:
                        log.warning("telegram task died: %r — restarting in 5s", exc)
                    else:
                        log.warning("telegram task exited — restarting in 5s")
                    await asyncio.sleep(5)
                    from .clients.telegram import TelegramClient
                    self._telegram_client = TelegramClient.from_config(
                        self.config.transports[0].model_dump()
                    )
                    self._telegram_task = asyncio.create_task(
                        _resilient_telegram()
                    )
                await asyncio.sleep(2)

        watchdog_task = asyncio.create_task(_telegram_watchdog())

        try:
            # MCP stdio server — Claude disconnects after each turn, so we
            # reconnect in a loop. Each iteration handles one connection
            # lifecycle (init → list_tools → notifications → disconnect).
            while True:
                try:
                    self._session = None  # reset for new connection
                    log.info("MCP stdio server starting (re)connection...")
                    async with stdio_server() as (read_stream, write_stream):
                        init_options = InitializationOptions(
                            server_name=SERVER_NAME,
                            server_version=SERVER_VERSION,
                            capabilities=self.mcp.get_capabilities(
                                notification_options=NotificationOptions(),
                                experimental_capabilities={
                                    "claude/channel": {},
                                },
                            ),
                        )
                        await self.mcp.run(
                            read_stream, write_stream, init_options,
                            raise_exceptions=False,
                        )
                    log.info("MCP connection closed — reconnecting...")
                except (BrokenPipeError, ConnectionError, OSError) as e:
                    log.warning("MCP pipe error: %r — reconnecting in 1s", e)
                    await asyncio.sleep(1)
                except Exception as e:
                    log.error("MCP server error: %r — reconnecting in 2s", e)
                    await asyncio.sleep(2)
        finally:
            log.warning("channel server shutting down")
            watchdog_task.cancel()
            if self._telegram_task is not None:
                self._telegram_task.cancel()
                try:
                    await self._telegram_task
                except (asyncio.CancelledError, Exception):
                    pass
            await self._hook_receiver.stop()
            if inject_server is not None:
                await inject_server.stop()
            await self.access.stop()
            await self.events.aclose()
            if self._bot:
                await self._bot.session.close()
