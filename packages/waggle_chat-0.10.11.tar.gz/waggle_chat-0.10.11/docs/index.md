# waggle

Chat-layer runtime that wires one Claude Code agent to many chat platforms. One agent, unified context, many channels.

## Quick Links

- [Requirements](./REQUIREMENTS) — what waggle does and why
- [Architecture](./ARCHITECTURE) — component view inside the waggle process
- [Design](./DESIGN) — implementation decisions and wire formats
- [Comparison](./COMPARISON) — waggle vs Anthropic Telegram Channel
- [API](./API) — inject endpoint, config schema, events
- [Roadmap](./ROADMAP) — phased delivery plan
- [Tests](./TESTS) — test strategy and running guide

## What is waggle?

waggle sits between chat platforms (Telegram, Matrix, ...) and a Claude Code subprocess. It carries messages in, delivers replies out, and gives the operator runtime controls (restart, compact, pause) — nothing more.

```
external trigger ---+
                    +--> waggle --> claude-code --> waggle --> chat platforms
chat platforms -----+
```

## Key Features

- **Mid-turn inject** — fold new messages into a running turn
- **Owner operations** — /restart, /status, /compact, /fresh, /cancel, /pause
- **Working indicator** — rolling status with Show Thinking + Show Tasks
- **Permission prompts** — route dangerous tool calls to Telegram for approval
- **Access control** — per-user, per-group, hot-reload allow-list
- **Inject endpoint** — HTTP trigger for CI, schedulers, alerts
