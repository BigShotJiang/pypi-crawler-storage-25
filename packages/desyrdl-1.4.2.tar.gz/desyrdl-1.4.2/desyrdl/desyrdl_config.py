#!/usr/bin/env python
# --------------------------------------------------------------------------- #
#           ____  _____________  __                                           #
#          / __ \/ ____/ ___/\ \/ /                 _   _   _                 #
#         / / / / __/  \__ \  \  /                 / \ / \ / \                #
#        / /_/ / /___ ___/ /  / /               = ( M | S | K )=              #
#       /_____/_____//____/  /_/                   \_/ \_/ \_/                #
#                                                                             #
# --------------------------------------------------------------------------- #
# @copyright Copyright 2025 DESY
# SPDX-License-Identifier: Apache-2.0
# --------------------------------------------------------------------------- #
# @date 2025-05-11
# @author Lukasz Butkowski <lukasz.butkowski@desy.de>
# --------------------------------------------------------------------------- #
"""desyrdl-config script.

Allows to get current desyrdl configuration such as path to libaries
"""

import argparse
import sys
from pathlib import Path

base_dir = Path(__file__).parent.resolve()
base_desyrdl_dir = base_dir.parent.joinpath("desyrdl").resolve()

lib_dir = base_desyrdl_dir.joinpath("libraries").joinpath("rdl")


def main():
    """Main desyrdl-config script."""
    arg_parser = argparse.ArgumentParser("desyrdl-config script options")

    argp = arg_parser.add_mutually_exclusive_group()
    argp.add_argument(
        "--lib-dir",
        action="store_true",
        help="Print the absolute path to the DesyRDL rdl libraries location",
    )
    argp.add_argument(
        "--python-bin",
        action="store_true",
        help="Print the path to the Python executable associated with the environment that desyrdl is installed in.",
    )

    min_req_args = 2

    if len(sys.argv) < min_req_args:
        arg_parser.print_help()
        sys.exit(1)

    args = arg_parser.parse_args()
    if args.lib_dir:
        print(lib_dir.as_posix())
    elif args.python_bin:
        print(Path(sys.executable).as_posix())


if __name__ == "__main__":
    main()
