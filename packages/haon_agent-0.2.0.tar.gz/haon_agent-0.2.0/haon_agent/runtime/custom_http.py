"""Custom HTTP runtime — generic container that exposes its own HTTP endpoint.

Miners can package their own inference server (llama.cpp, vLLM, TensorRT-LLM,
or anything else that speaks HTTP on localhost). This runtime opts in to
bridge networking but STILL drops all caps and runs non-root, and does not
mount any host paths. Outbound network allowlist is a Phase 22 concern.
"""

from __future__ import annotations

from haon_agent.runtime.base import register
from haon_agent.runtime.docker import DockerRuntime, RuntimeDefaults


class CustomHttpRuntime(DockerRuntime):
    defaults = RuntimeDefaults(
        image="ghcr.io/haon/runtime-custom-http",
        image_digest=(
            "sha256:0000000000000000000000000000000000000000000000000000000000000000"
        ),
        command=[],  # image's default entrypoint
        env={},
        cpus="2.0",
        memory="4g",
        pids_limit=256,
        requires_gpu=False,
        gpus=None,
        needs_network=True,  # opt-in — miner must accept in agent config
        tmpfs=[
            ("/tmp", "rw,noexec,nosuid,size=512m"),
        ],
        extra_labels={"haon.runtime.kind": "custom-http"},
    )


register("custom-http", CustomHttpRuntime)
