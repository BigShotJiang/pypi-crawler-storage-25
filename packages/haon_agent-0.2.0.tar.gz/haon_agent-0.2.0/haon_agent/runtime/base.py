"""Runtime protocol shared by all runtime adapters."""

from __future__ import annotations

from typing import Awaitable, Callable, Protocol


class Runtime(Protocol):
    """A runtime receives worker bytes, may produce bytes back.

    `start(on_output)` spawns the runtime and registers a callback the runtime
    calls whenever it has bytes to forward back to the worker. `push(data)`
    feeds bytes from the worker into the runtime. `stop()` tears it down.
    """

    async def start(
        self, on_output: Callable[[bytes], Awaitable[None]]
    ) -> None: ...

    async def push(self, data: bytes) -> None: ...

    async def stop(self) -> None: ...


RuntimeFactory = Callable[[], Runtime]


_REGISTRY: dict[str, RuntimeFactory] = {}


def register(name: str, factory: RuntimeFactory) -> None:
    _REGISTRY[name] = factory


def get_runtime(name: str) -> Runtime:
    if name not in _REGISTRY:
        raise KeyError(f"unknown runtime: {name!r} (have {sorted(_REGISTRY)})")
    return _REGISTRY[name]()


def supported() -> list[str]:
    return sorted(_REGISTRY)
