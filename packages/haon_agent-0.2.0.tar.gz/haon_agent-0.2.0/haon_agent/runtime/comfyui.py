"""ComfyUI runtime — image-generation workflow engine."""

from __future__ import annotations

from haon_agent.runtime.base import register
from haon_agent.runtime.docker import DockerRuntime, RuntimeDefaults


class ComfyUIRuntime(DockerRuntime):
    defaults = RuntimeDefaults(
        image="ghcr.io/haon/runtime-comfyui",
        image_digest=(
            "sha256:0000000000000000000000000000000000000000000000000000000000000000"
        ),
        command=["python", "main.py", "--listen", "0.0.0.0", "--port", "8188"],
        env={
            "COMFYUI_DISABLE_AUTO_UPDATE": "1",
        },
        cpus="6.0",
        memory="24g",
        pids_limit=512,
        requires_gpu=True,
        gpus="all",
        needs_network=False,
        tmpfs=[
            ("/tmp", "rw,noexec,nosuid,size=2g"),
            ("/app/output", "rw,nosuid,size=4g"),
        ],
        extra_labels={"haon.runtime.kind": "diffusion"},
    )


register("comfyui", ComfyUIRuntime)
