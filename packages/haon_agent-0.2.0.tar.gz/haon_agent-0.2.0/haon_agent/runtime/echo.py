"""In-process echo runtime.

Every byte the worker pushes is echoed back verbatim, once. Useful as an
end-to-end smoke test and as the Phase 10 default runtime before Phase 11
wires real sandboxes. Pure Python, no subprocess.
"""

from __future__ import annotations

from typing import Awaitable, Callable

from haon_agent.runtime.base import register


class EchoRuntime:
    def __init__(self) -> None:
        self._on_output: Callable[[bytes], Awaitable[None]] | None = None
        self._started = False

    async def start(
        self, on_output: Callable[[bytes], Awaitable[None]]
    ) -> None:
        self._on_output = on_output
        self._started = True

    async def push(self, data: bytes) -> None:
        if not self._started or self._on_output is None:
            raise RuntimeError("echo runtime not started")
        # Echo verbatim.
        await self._on_output(data)

    async def stop(self) -> None:
        self._started = False
        self._on_output = None


register("echo", EchoRuntime)
