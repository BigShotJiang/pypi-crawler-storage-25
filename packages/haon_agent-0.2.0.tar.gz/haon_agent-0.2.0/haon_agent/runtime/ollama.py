"""Ollama runtime — LLM inference via ollama.com/ollama image.

Digest below is a placeholder; production deploy (Phase 25) pins a vetted
digest after reproducible-build review. We keep the placeholder here so tests
can verify shape without reaching out to Docker Hub.
"""

from __future__ import annotations

from haon_agent.runtime.base import register
from haon_agent.runtime.docker import DockerRuntime, RuntimeDefaults


class OllamaRuntime(DockerRuntime):
    defaults = RuntimeDefaults(
        image="ollama/ollama",
        image_digest=(
            "sha256:0000000000000000000000000000000000000000000000000000000000000000"
        ),  # placeholder — replaced by Phase 25 deploy manifest
        command=["ollama", "serve"],
        env={
            "OLLAMA_HOST": "0.0.0.0:11434",
            "OLLAMA_NOHISTORY": "1",
        },
        cpus="4.0",
        memory="16g",
        pids_limit=512,
        requires_gpu=True,
        gpus="all",
        needs_network=False,
        # Model weights tmpfs is ephemeral per session in Phase 11; a persistent
        # volume will land in Phase 22 hardening so we don't re-download on every
        # session (subject to eviction policy).
        tmpfs=[
            ("/tmp", "rw,noexec,nosuid,size=1g"),
            ("/root/.ollama", "rw,nosuid,size=8g"),
        ],
        extra_labels={"haon.runtime.kind": "llm"},
    )


register("ollama", OllamaRuntime)
