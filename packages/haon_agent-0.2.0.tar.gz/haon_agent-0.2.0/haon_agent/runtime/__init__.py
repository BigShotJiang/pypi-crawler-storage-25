"""Runtime adapters.

Phase 10 shipped `echo` (in-process). Phase 11 adds Docker-based runtimes
`ollama`, `comfyui`, `custom-http`. All implement the same `Runtime`
Protocol and are looked up by name via `get_runtime(name)`.
"""

from haon_agent.runtime.base import Runtime, RuntimeFactory, get_runtime, supported
from haon_agent.runtime.echo import EchoRuntime

# Importing these modules triggers their `register()` calls on the registry.
from haon_agent.runtime import comfyui as _comfyui  # noqa: F401
from haon_agent.runtime import custom_http as _custom_http  # noqa: F401
from haon_agent.runtime import ollama as _ollama  # noqa: F401
from haon_agent.runtime.comfyui import ComfyUIRuntime
from haon_agent.runtime.custom_http import CustomHttpRuntime
from haon_agent.runtime.docker import DockerRuntime, RuntimeDefaults
from haon_agent.runtime.ollama import OllamaRuntime

__all__ = [
    "Runtime",
    "RuntimeFactory",
    "EchoRuntime",
    "DockerRuntime",
    "RuntimeDefaults",
    "OllamaRuntime",
    "ComfyUIRuntime",
    "CustomHttpRuntime",
    "get_runtime",
    "supported",
]
