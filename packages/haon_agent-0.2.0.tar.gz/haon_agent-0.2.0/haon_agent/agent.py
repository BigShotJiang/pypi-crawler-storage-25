"""The agent's main orchestrator loop.

    heartbeat (every N seconds)
      │
      ├── if heartbeat.session_accepted_ids non-empty:
      │     for each session_id:
      │       accept_session(session_id)
      │
      └── sleep(heartbeat_interval)

    accept_session(session_id):
      call POST /v1/sessions/{id}/start → handoff
      connect to broker with handoff.tunnel_token
      wait for PAIRED
      spawn runtime
      concurrently:
        - forward worker DATA frames to runtime.push
        - forward runtime output to broker.send_data
      on CLOSE / UNPAIRED / runtime stop: tear everything down, POST /close.

Recovery:
    If heartbeat fails we keep retrying with exponential backoff. If broker
    disconnects mid-session we close the session via API. No silent failures.
"""

from __future__ import annotations

import asyncio
import contextlib
from dataclasses import dataclass
from typing import Awaitable, Callable

import structlog

from haon_agent.api_client import ApiClient, ApiError, SessionHandoff
from haon_agent.broker_client import BrokerClient, FrameType
from haon_agent.config import AgentConfig
from haon_agent.runtime import get_runtime
from haon_agent.runtime.base import Runtime

log = structlog.get_logger("agent")


@dataclass
class AgentDeps:
    api: ApiClient
    config: AgentConfig
    # Factory so tests can inject a fake BrokerClient.
    broker_factory: Callable[[str, str], BrokerClient] = lambda url, token: BrokerClient(url, token)
    # Runtime resolver (defaults to the module-level registry).
    runtime_factory: Callable[[str], Runtime] = get_runtime


class Agent:
    def __init__(self, deps: AgentDeps) -> None:
        self._deps = deps
        self._running = False
        self._active_sessions: dict[str, asyncio.Task[None]] = {}
        self._stop_event = asyncio.Event()

    async def run(self) -> None:
        self._running = True
        log.info("agent_starting", api_url=self._deps.config.api_url)
        try:
            await self._main_loop()
        finally:
            self._running = False
            # Cancel any active session tasks.
            for sid, task in list(self._active_sessions.items()):
                log.info("session_task_cancelling", session_id=sid)
                task.cancel()
            for task in list(self._active_sessions.values()):
                with contextlib.suppress(asyncio.CancelledError):
                    await task
            log.info("agent_stopped")

    def request_stop(self) -> None:
        self._stop_event.set()

    async def _main_loop(self) -> None:
        cfg = self._deps.config
        if not cfg.machine_id:
            raise RuntimeError("machine_id not configured; run `haon-agent register` first")

        backoff = 1.0
        while not self._stop_event.is_set():
            try:
                resp = await self._deps.api.heartbeat(
                    cfg.machine_id,
                    runtime_ready=True,
                    pending_sessions=len(self._active_sessions),
                )
                backoff = 1.0  # reset on success
                offered = resp.get("session_accepted_ids") or []
                for sid in offered:
                    if sid in self._active_sessions:
                        continue
                    log.info("session_offered_received", session_id=sid)
                    task = asyncio.create_task(self._run_session(sid))
                    self._active_sessions[sid] = task
                    # Purge completed tasks.
                    for done_sid in [
                        s for s, t in self._active_sessions.items() if t.done()
                    ]:
                        self._active_sessions.pop(done_sid, None)
            except ApiError as e:
                log.warning(
                    "heartbeat_failed",
                    code=e.code,
                    status_code=e.status_code,
                )
            except Exception as e:  # noqa: BLE001
                log.exception("heartbeat_unhandled_error", error=str(e))
                backoff = min(backoff * 2, 30.0)

            try:
                await asyncio.wait_for(
                    self._stop_event.wait(),
                    timeout=cfg.heartbeat_interval_seconds if backoff <= 1.0 else backoff,
                )
            except asyncio.TimeoutError:
                pass

    # ── Per-session pipeline ────────────────────────────────────────────

    async def _run_session(self, session_id: str) -> None:
        try:
            handoff = await self._deps.api.start_session(session_id)
        except ApiError as e:
            log.warning(
                "session_start_rejected",
                session_id=session_id,
                code=e.code,
            )
            return

        runtime_name = handoff.runtime or self._deps.config.default_runtime
        try:
            runtime = self._deps.runtime_factory(runtime_name)
        except KeyError:
            log.warning(
                "runtime_unsupported",
                session_id=session_id,
                runtime=runtime_name,
            )
            await self._safe_close(session_id, reason="miner_closed")
            return

        broker = self._deps.broker_factory(
            handoff.tunnel_broker_url, handoff.tunnel_token
        )
        close_reason = "miner_closed"
        tick_emitter = None
        try:
            await broker.connect()
            # Wait for PAIRED — the worker-client opens the other side of the tunnel.
            paired_task = asyncio.create_task(broker.await_paired(timeout=15))

            async def on_runtime_output(data: bytes) -> None:
                await broker.send_data(data)

            await runtime.start(on_runtime_output)
            await paired_task

            log.info("session_paired_and_running", session_id=session_id)

            # Phase 12: start the tick emitter for this session.
            from haon_agent.tick_emitter import TickEmitter

            container_name = None
            handle = getattr(runtime, "_handle", None)
            if handle is not None:
                container_name = getattr(handle, "container_name", None)
            tick_emitter = TickEmitter(
                api=self._deps.api,
                session_id=session_id,
                broker=broker,
                container_name=container_name,
            )
            tick_emitter.start()

            async for ev in broker.events():
                if ev.type is FrameType.DATA:
                    await runtime.push(ev.payload)
                elif ev.type is FrameType.UNPAIRED:
                    log.warning("session_unpaired", session_id=session_id)
                    # Worker dropped — Phase 10 treats it as session end.
                    # A reconnection-grace window can land later.
                    break
                elif ev.type is FrameType.CLOSE:
                    log.info(
                        "session_broker_closed",
                        session_id=session_id,
                        payload=ev.json(),
                    )
                    break
                elif ev.type is FrameType.ERROR:
                    log.error(
                        "session_broker_error",
                        session_id=session_id,
                        payload=ev.json(),
                    )
                    break
        except Exception as e:  # noqa: BLE001
            log.exception(
                "session_pipeline_error", session_id=session_id, error=str(e)
            )
            close_reason = "miner_closed"
        finally:
            if tick_emitter is not None:
                try:
                    await tick_emitter.stop()
                except Exception:  # noqa: BLE001
                    pass
            try:
                await runtime.stop()
            except Exception:  # noqa: BLE001
                pass
            await broker.close()
            await self._safe_close(session_id, reason=close_reason)
            self._active_sessions.pop(session_id, None)

    async def _safe_close(self, session_id: str, *, reason: str) -> None:
        try:
            await self._deps.api.close_session(session_id, reason=reason)
        except ApiError as e:
            log.warning(
                "session_close_failed", session_id=session_id, code=e.code
            )
        except Exception as e:  # noqa: BLE001
            log.warning(
                "session_close_unhandled", session_id=session_id, error=str(e)
            )
