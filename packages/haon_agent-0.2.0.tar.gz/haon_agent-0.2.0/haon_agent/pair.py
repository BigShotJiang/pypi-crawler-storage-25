"""One-command miner pairing.

`haon-agent pair` walks the user from "I typed my email" to "my rig is
in the marketplace" in a single interactive flow:

    1. Login (or signup) with email + password
    2. Discover available hubs, pick one (or auto-pick if only one)
    3. Probe hardware (CPU / RAM / GPU via nvidia-smi when present)
    4. Register the machine with the miner's JWT
    5. Mint an api key scoped to `miner:agent`
    6. Write ~/.haon/agent.toml + ~/.haon/credentials.toml

Everything except hub creation can be done with the miner's own account —
no admin password required. The hub must exist beforehand (ops creates
one public "Alpha" hub per region).

After pairing, `haon-agent run` picks up the config and the machine is
online within a heartbeat interval (~15s).
"""

from __future__ import annotations

import getpass
import socket
from dataclasses import dataclass
from decimal import Decimal
from typing import Any

import httpx

from haon_agent import config as cfg_mod
from haon_agent import credentials as cred_mod
from haon_agent import hardware as hw_mod


class PairError(Exception):
    """Raised for any recoverable failure in the pair flow."""


@dataclass
class PairResult:
    machine_id: str
    machine_name: str
    hub_id: str
    hub_name: str
    api_key_preview: str  # never the raw key


def _raise(r: httpx.Response, step: str) -> None:
    if r.is_success:
        return
    try:
        err = r.json().get("error", {})
        msg = err.get("message", r.text)
        code = err.get("code", "HTTP")
    except Exception:  # noqa: BLE001
        msg = r.text[:200]
        code = "HTTP"
    raise PairError(f"{step}: {code} ({r.status_code}) — {msg}")


def _login_or_register(
    client: httpx.Client, email: str, password: str
) -> tuple[str, str]:
    """Return (access_token, user_id). Tries login first; if invalid credentials,
    offers to register. We don't auto-register on missing-user: the user typing
    a new email should get an explicit 'create new account?' prompt."""
    r = client.post(
        "/v1/auth/login", json={"email": email, "password": password}
    )
    if r.is_success:
        body = r.json()
        return body["access_token"], body["user"]["id"]

    if r.status_code == 401:
        # Either wrong password on existing account, OR account doesn't exist.
        # The API's signup endpoint errors if email exists, so ordering is:
        # offer signup; on 409 tell the user their password is wrong.
        print()
        print(f"  Login failed for {email}.")
        choice = input("  Create a new account with this email? [y/N]: ").strip().lower()
        if choice != "y":
            raise PairError(
                "Pairing aborted. Re-run and enter the correct password, "
                "or use the same email with 'y' to create the account."
            )
        r2 = client.post(
            "/v1/auth/register",
            json={"email": email, "password": password, "role": "miner"},
        )
        if r2.status_code == 409:
            raise PairError(
                f"Account {email} already exists — your password is wrong. "
                "Reset it at https://staging.haon.run/forgot-password."
            )
        _raise(r2, "signup")
        # Re-login (signup does not always return tokens).
        r3 = client.post(
            "/v1/auth/login", json={"email": email, "password": password}
        )
        _raise(r3, "login-after-signup")
        body = r3.json()
        return body["access_token"], body["user"]["id"]

    _raise(r, "login")
    raise AssertionError("unreachable")  # for type checker


def _list_hubs(client: httpx.Client, token: str) -> list[dict[str, Any]]:
    r = client.get("/v1/hubs", headers={"Authorization": f"Bearer {token}"})
    _raise(r, "list-hubs")
    body = r.json()
    return body.get("items", [])


def _pick_hub(hubs: list[dict[str, Any]]) -> dict[str, Any]:
    if not hubs:
        raise PairError(
            "No hubs exist on this environment yet. Ask the HAON ops team to "
            "create one (admin-only operation) and retry."
        )
    if len(hubs) == 1:
        h = hubs[0]
        print(f"  Auto-selecting the only hub: {h['name']} ({h.get('region', '?')})")
        return h
    print()
    print("  Available hubs:")
    for i, h in enumerate(hubs, 1):
        print(
            f"    {i}. {h['name']} — region={h.get('region', '?')} "
            f"country={h.get('country', '?')}"
        )
    while True:
        raw = input(f"  Choose hub [1-{len(hubs)}]: ").strip()
        try:
            n = int(raw)
            if 1 <= n <= len(hubs):
                return hubs[n - 1]
        except ValueError:
            pass
        print("  Invalid selection.")


def _register_machine(
    client: httpx.Client,
    token: str,
    *,
    hub_id: str,
    machine_name: str,
    hardware: hw_mod.HardwareReport,
    supported_runtimes: list[str],
) -> str:
    payload = {
        "hub_id": hub_id,
        "name": machine_name,
        "cpu_model": hardware.cpu_model,
        "cpu_cores": hardware.cpu_cores,
        "ram_gb": hardware.ram_gb,
        "gpu_count": hardware.gpu_count,
        "supported_runtimes": supported_runtimes,
        "hardware_fingerprint": hardware.fingerprint(),
    }
    if hardware.gpu_model is not None:
        payload["gpu_model"] = hardware.gpu_model
    if hardware.gpu_vram_gb is not None:
        payload["gpu_vram_gb"] = hardware.gpu_vram_gb

    r = client.post(
        "/v1/machines",
        json=payload,
        headers={"Authorization": f"Bearer {token}"},
    )
    _raise(r, "register-machine")
    return r.json()["id"]


def _mint_api_key(
    client: httpx.Client, token: str, *, name: str
) -> tuple[str, str]:
    """Return (raw_key, key_preview). raw_key is shown once by the server."""
    r = client.post(
        "/v1/me/api-keys",
        json={"name": name, "scopes": ["miner:agent"]},
        headers={"Authorization": f"Bearer {token}"},
    )
    _raise(r, "mint-api-key")
    body = r.json()
    return body["raw_key"], body["api_key"]["key_preview"]


def _default_machine_name() -> str:
    host = socket.gethostname() or "haon-miner"
    # Keep it short + safe for the UI
    return host.split(".")[0][:40]


def _positive_price(raw: str) -> str:
    try:
        val = Decimal(raw)
    except Exception:  # noqa: BLE001
        raise PairError(f"Invalid price: {raw}") from None
    if val <= 0:
        raise PairError("Price per hour must be positive.")
    return f"{val:.4f}"


def run_pair(
    *,
    api_url: str,
    email: str | None = None,
    password: str | None = None,
    machine_name: str | None = None,
    price_per_hour: str | None = None,
    runtimes: list[str] | None = None,
    hub_id: str | None = None,
    non_interactive: bool = False,
) -> PairResult:
    """Entry point called by the CLI. All `None` args get prompted unless
    `non_interactive=True`, in which case missing args raise `PairError`."""

    def _prompt(label: str, *, secret: bool = False, default: str | None = None) -> str:
        if non_interactive:
            raise PairError(f"--non-interactive set but {label!r} missing.")
        suffix = f" [{default}]" if default else ""
        prompt = f"{label}{suffix}: "
        raw = (getpass.getpass(prompt) if secret else input(prompt)).strip()
        return raw or (default or "")

    print(f"HAON PowerHub — miner pairing")
    print(f"  API: {api_url}")
    print()

    if email is None:
        email = _prompt("Email")
    if not email or "@" not in email:
        raise PairError("A valid email is required.")
    if password is None:
        password = _prompt("Password", secret=True)
    if not password:
        raise PairError("Password is required.")

    with httpx.Client(
        base_url=api_url.rstrip("/"),
        timeout=20.0,
        headers={"User-Agent": "haon-agent/pair"},
    ) as client:
        print()
        print("→ Authenticating…")
        token, _user_id = _login_or_register(client, email, password)
        print("  ok")

        print()
        print("→ Discovering hubs…")
        hubs = _list_hubs(client, token)
        if hub_id is not None:
            match = next((h for h in hubs if h["id"] == hub_id), None)
            if match is None:
                raise PairError(
                    f"--hub-id {hub_id} not found. Available: "
                    f"{[h['id'] for h in hubs]}"
                )
            chosen = match
            print(f"  using pinned hub: {chosen['name']}")
        else:
            chosen = _pick_hub(hubs)

        print()
        print("→ Probing hardware…")
        hw = hw_mod.detect()
        print(f"  CPU: {hw.cpu_model} ({hw.cpu_cores}c)")
        print(f"  RAM: {hw.ram_gb} GB")
        if hw.gpu_count > 0:
            print(f"  GPU: {hw.gpu_model} ({hw.gpu_vram_gb} GB) × {hw.gpu_count}")
        else:
            print("  GPU: none detected")

        if runtimes is None:
            # Default advertise: echo always; ollama if a GPU is present.
            runtimes = ["echo"]
            if hw.gpu_count > 0:
                runtimes.append("ollama")
        print(f"  Advertising runtimes: {', '.join(runtimes)}")

        if machine_name is None:
            default_name = _default_machine_name()
            machine_name = _prompt("Machine name", default=default_name) or default_name
        if price_per_hour is None:
            default_price = "0.4000" if hw.gpu_count > 0 else "0.0500"
            raw = _prompt("Price per hour (USD)", default=default_price) or default_price
            price_per_hour = _positive_price(raw)
        else:
            price_per_hour = _positive_price(price_per_hour)

        print()
        print(f"→ Registering machine `{machine_name}` in hub `{chosen['name']}`…")
        machine_id = _register_machine(
            client,
            token,
            hub_id=chosen["id"],
            machine_name=machine_name,
            hardware=hw,
            supported_runtimes=runtimes,
        )
        print(f"  machine_id = {machine_id}")

        print()
        print("→ Minting miner:agent API key…")
        raw_key, key_preview = _mint_api_key(
            client, token, name=f"haon-miner/{machine_name}"
        )
        print(f"  key_preview = {key_preview}")

    # ── Persist config + credentials ────────────────────────────────────
    cfg = cfg_mod.AgentConfig(
        api_url=api_url,
        machine_id=machine_id,
        machine_name=machine_name,
        hub_id=chosen["id"],
        price_per_hour=price_per_hour,
        supported_runtimes=runtimes,
        default_runtime=runtimes[0],
    )
    cfg_mod.save(cfg)
    cred_mod.store(raw_key)

    print()
    print("Paired.")
    print()
    print(f"  Config: {cfg_mod.DEFAULT_CONFIG_PATH}")
    print(f"  Credentials: (OS keyring, or {cfg_mod.DEFAULT_CONFIG_DIR / 'credentials.toml'})")
    print()
    print("Start the agent with:")
    print("  haon-agent run")
    print()
    print("Your machine appears in the marketplace within ~30 seconds.")

    return PairResult(
        machine_id=machine_id,
        machine_name=machine_name,
        hub_id=chosen["id"],
        hub_name=chosen["name"],
        api_key_preview=key_preview,
    )
