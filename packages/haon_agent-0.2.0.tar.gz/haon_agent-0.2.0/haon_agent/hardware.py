"""Host hardware detection.

Intentionally conservative: if a probe fails, return neutral defaults rather
than crashing. The backend re-validates the claims against runtime metrics,
so lying here gains nothing.

Fake-hardware mode:
  Set HAON_FAKE_HARDWARE=1 (or pass --fake-hardware to the CLI) to bypass
  all probes and report a synthetic RTX 4090 rig. Intended for:
    - Phase 24 E2E testing on hosts without a real GPU
    - Developer dry-runs in Docker containers / CI
    - Staging smoke tests
  NEVER set this in production — the backend audit trail will flag a
  fingerprint that doesn't match runtime metrics, and Phase 20 alerts
  will fire.
"""

from __future__ import annotations

import hashlib
import os
import platform
import re
import shutil
import subprocess
import sys
import uuid
from dataclasses import dataclass, field

try:
    import psutil
    _HAS_PSUTIL = True
except ImportError:  # pragma: no cover
    _HAS_PSUTIL = False


@dataclass
class HardwareReport:
    cpu_model: str
    cpu_cores: int
    ram_gb: int
    gpu_model: str | None = None
    gpu_vram_gb: int | None = None
    gpu_count: int = 0
    os: str = field(default_factory=lambda: platform.platform())
    python: str = field(default_factory=lambda: sys.version.split()[0])

    def fingerprint(self) -> str:
        """Stable SHA-256 hex over the key identifying fields.

        Intentional: changing GPU count or RAM re-fingerprints. The MAC address
        is not included (Phase 6 `UNIQUE(miner_id, hardware_fingerprint)` scopes
        uniqueness to the miner already, and a MAC would leak network identity).
        """
        parts = [
            self.cpu_model,
            str(self.cpu_cores),
            str(self.ram_gb),
            self.gpu_model or "cpu-only",
            str(self.gpu_vram_gb or 0),
            str(self.gpu_count),
        ]
        return hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest()


# ── CPU / RAM ────────────────────────────────────────────────────────────


def _cpu_model() -> str:
    """Best-effort CPU model string. Never raises."""
    try:
        # /proc/cpuinfo on Linux.
        with open("/proc/cpuinfo", encoding="utf-8") as f:
            for line in f:
                if line.startswith("model name"):
                    _, _, rest = line.partition(":")
                    return rest.strip()
    except (FileNotFoundError, PermissionError):
        pass
    # macOS.
    try:
        out = subprocess.check_output(
            ["sysctl", "-n", "machdep.cpu.brand_string"], text=True, timeout=2
        )
        return out.strip()
    except (FileNotFoundError, subprocess.SubprocessError, subprocess.TimeoutExpired):
        pass
    # Windows / fallback.
    return platform.processor() or platform.machine() or "Unknown CPU"


def _cpu_cores() -> int:
    if _HAS_PSUTIL:
        try:
            return psutil.cpu_count(logical=True) or 1
        except Exception:  # noqa: BLE001
            pass
    import os as _os

    return _os.cpu_count() or 1


def _ram_gb() -> int:
    if _HAS_PSUTIL:
        try:
            total = psutil.virtual_memory().total
            return max(1, round(total / (1024**3)))
        except Exception:  # noqa: BLE001
            pass
    # Fallback for tests: assume 1 GB to be safe.
    return 1


# ── GPU ──────────────────────────────────────────────────────────────────


_NVSMI_QUERY = "--query-gpu=name,memory.total,uuid"
_NVSMI_FORMAT = "--format=csv,noheader,nounits"


def _detect_nvidia() -> tuple[str | None, int | None, int]:
    """Return (model, vram_gb, count). (None, None, 0) when no NVIDIA GPU."""
    nvsmi = shutil.which("nvidia-smi")
    if nvsmi is None:
        return None, None, 0
    try:
        out = subprocess.check_output(
            [nvsmi, _NVSMI_QUERY, _NVSMI_FORMAT],
            text=True,
            timeout=5,
            stderr=subprocess.DEVNULL,
        )
    except (subprocess.SubprocessError, subprocess.TimeoutExpired, FileNotFoundError):
        return None, None, 0

    lines = [ln.strip() for ln in out.splitlines() if ln.strip()]
    if not lines:
        return None, None, 0

    model: str | None = None
    vram_mib_total = 0
    count = 0
    for line in lines:
        fields = [f.strip() for f in line.split(",")]
        if len(fields) < 2:
            continue
        name = fields[0]
        mem_raw = re.sub(r"[^0-9]", "", fields[1]) or "0"
        mem_mib = int(mem_raw)
        count += 1
        vram_mib_total = max(vram_mib_total, mem_mib)
        if model is None:
            model = name
    vram_gb = round(vram_mib_total / 1024) if vram_mib_total > 0 else None
    return model, vram_gb, count


_FAKE_HARDWARE_ENV = "HAON_FAKE_HARDWARE"


def _fake_report() -> HardwareReport:
    """Synthetic rig for dev/test. NOT for production."""
    return HardwareReport(
        cpu_model="FAKE CPU — HAON_FAKE_HARDWARE=1",
        cpu_cores=8,
        ram_gb=32,
        gpu_model="FAKE NVIDIA RTX 4090 (simulated)",
        gpu_vram_gb=24,
        gpu_count=1,
    )


def detect(
    *, nvsmi_detector=_detect_nvidia
) -> HardwareReport:
    """Build a HardwareReport. `nvsmi_detector` swappable for tests.

    If HAON_FAKE_HARDWARE is set to a truthy value (`1`, `true`, `yes`),
    returns a synthetic report instead of probing the host. Used for Phase 24
    E2E tests on laptops without a real GPU.
    """
    if os.environ.get(_FAKE_HARDWARE_ENV, "").strip().lower() in ("1", "true", "yes", "y"):
        return _fake_report()
    gpu_model, gpu_vram_gb, gpu_count = nvsmi_detector()
    return HardwareReport(
        cpu_model=_cpu_model(),
        cpu_cores=_cpu_cores(),
        ram_gb=_ram_gb(),
        gpu_model=gpu_model,
        gpu_vram_gb=gpu_vram_gb,
        gpu_count=gpu_count,
    )
