"""Usage sampling for ticks.

Two sources:
  - `docker stats --no-stream --format '{{json .}}'` for CPU % and memory.
  - `nvidia-smi --query-gpu=utilization.gpu,memory.used` for GPU usage.

Both are best-effort: if the probe fails, we emit zeroes for those fields
(the backend clamps and re-validates regardless). Parsers are pure and unit-
testable; the live-subprocess variant is gated behind `SamplerBackend`.
"""

from __future__ import annotations

import asyncio
import json
import re
import shutil
import subprocess
from dataclasses import dataclass
from typing import Protocol


@dataclass(frozen=True)
class Sample:
    cpu_percent: float
    ram_mb: int
    gpu_percent: float
    vram_mb: int


class SamplerBackend(Protocol):
    """Pluggable backend — real `subprocess` in prod, fakes in tests."""

    async def docker_stats(self, container_name: str) -> dict | None: ...
    async def nvidia_smi(self) -> list[dict] | None: ...


# ── Pure parsers ─────────────────────────────────────────────────────────


def parse_cpu_percent(raw: str) -> float:
    """`docker stats` emits strings like "12.34%" or "0.00%". Returns float."""
    if raw is None:
        return 0.0
    m = re.match(r"^\s*([0-9]+(?:\.[0-9]+)?)\s*%?\s*$", str(raw))
    if not m:
        return 0.0
    return float(m.group(1))


_MEM_UNITS = {
    "b": 1 / (1024**2),
    "kib": 1 / 1024,
    "kb": 1 / 1024,
    "mib": 1.0,
    "mb": 1.0,
    "gib": 1024.0,
    "gb": 1024.0,
    "tib": 1024.0 * 1024.0,
    "tb": 1024.0 * 1024.0,
}


def parse_mem_mb(raw: str) -> int:
    """Parse docker stats memory strings like "512.3MiB", "1.2GiB", "800B"."""
    if raw is None:
        return 0
    m = re.match(
        r"^\s*([0-9]+(?:\.[0-9]+)?)\s*([a-zA-Z]+)\s*$", str(raw).strip()
    )
    if not m:
        return 0
    value = float(m.group(1))
    unit = m.group(2).lower()
    mult = _MEM_UNITS.get(unit)
    if mult is None:
        return 0
    return max(0, round(value * mult))


def parse_docker_mem_usage(raw: str) -> int:
    """`MemUsage` is "512.3MiB / 2GiB" — we want the first side in MiB."""
    if raw is None:
        return 0
    head, _, _ = str(raw).partition("/")
    return parse_mem_mb(head.strip())


def parse_nvsmi_row(raw: str) -> tuple[float, int] | None:
    """Parse a single line from `nvidia-smi --query-gpu=utilization.gpu,memory.used --format=csv,noheader,nounits`.

    Returns (util_percent, vram_mb) or None on parse failure.
    """
    if not raw:
        return None
    parts = [p.strip() for p in raw.split(",")]
    if len(parts) < 2:
        return None
    try:
        util = float(parts[0])
    except ValueError:
        return None
    try:
        vram_mib = int(float(parts[1]))
    except ValueError:
        return None
    return util, max(0, vram_mib)


# ── Sampler ──────────────────────────────────────────────────────────────


class SubprocessSamplerBackend:
    """Real implementation — invokes docker + nvidia-smi via subprocess."""

    async def docker_stats(self, container_name: str) -> dict | None:
        if shutil.which("docker") is None:
            return None
        try:
            proc = await asyncio.create_subprocess_exec(
                "docker",
                "stats",
                "--no-stream",
                "--format",
                "{{json .}}",
                container_name,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.DEVNULL,
            )
            out, _ = await asyncio.wait_for(proc.communicate(), timeout=5)
        except (FileNotFoundError, asyncio.TimeoutError):
            return None
        if proc.returncode != 0 or not out:
            return None
        try:
            return json.loads(out.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            return None

    async def nvidia_smi(self) -> list[dict] | None:
        if shutil.which("nvidia-smi") is None:
            return None
        try:
            proc = await asyncio.create_subprocess_exec(
                "nvidia-smi",
                "--query-gpu=utilization.gpu,memory.used",
                "--format=csv,noheader,nounits",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.DEVNULL,
            )
            out, _ = await asyncio.wait_for(proc.communicate(), timeout=5)
        except (FileNotFoundError, asyncio.TimeoutError):
            return None
        if proc.returncode != 0:
            return None
        rows = []
        for line in out.decode("utf-8", errors="replace").splitlines():
            parsed = parse_nvsmi_row(line)
            if parsed is not None:
                rows.append({"util": parsed[0], "vram_mb": parsed[1]})
        return rows or None


async def sample(
    *,
    container_name: str,
    backend: SamplerBackend,
) -> Sample:
    """Return a single Sample. Never raises; zero-fill on probe failure."""
    cpu_percent = 0.0
    ram_mb = 0
    gpu_percent = 0.0
    vram_mb = 0

    stats = await backend.docker_stats(container_name)
    if stats is not None:
        cpu_percent = parse_cpu_percent(stats.get("CPUPerc") or stats.get("cpu_perc") or "")
        mem_raw = stats.get("MemUsage") or stats.get("mem_usage") or ""
        ram_mb = parse_docker_mem_usage(mem_raw)

    gpus = await backend.nvidia_smi()
    if gpus:
        # Take the max of all bound GPUs — single session = single logical GPU
        # allocation today, but multi-GPU surfaces the busiest one.
        gpu_percent = max((g["util"] for g in gpus), default=0.0)
        vram_mb = max((g["vram_mb"] for g in gpus), default=0)

    return Sample(
        cpu_percent=cpu_percent,
        ram_mb=ram_mb,
        gpu_percent=gpu_percent,
        vram_mb=vram_mb,
    )
