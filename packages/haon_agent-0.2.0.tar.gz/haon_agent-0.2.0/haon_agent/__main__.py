"""Entry point for `python -m haon_agent`."""

from haon_agent.cli import cli

if __name__ == "__main__":
    cli()
