"""`haon-agent` CLI."""

from __future__ import annotations

import asyncio
import logging
import os
import sys
from getpass import getpass

import click
import structlog

from haon_agent import __version__, config, credentials, hardware
from haon_agent.agent import Agent, AgentDeps
from haon_agent.api_client import ApiClient, ApiError


def _apply_fake_hardware(flag: bool) -> None:
    """If --fake-hardware was passed, set the env var hardware.detect reads.
    Safe to call multiple times (idempotent). Logged loudly so it never
    ships to prod by accident — operator sees it every single invocation."""
    if flag:
        os.environ["HAON_FAKE_HARDWARE"] = "1"
        click.echo(
            "⚠️  HAON_FAKE_HARDWARE=1 — reporting synthetic RTX 4090 to the backend. "
            "Dev/test only. Do NOT use in production.",
            err=True,
        )


def _configure_logging(level: str = "info") -> None:
    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso", utc=True),
            structlog.processors.JSONRenderer(),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(
            getattr(logging, level.upper(), logging.INFO)
        ),
        logger_factory=structlog.PrintLoggerFactory(file=sys.stderr),
    )


@click.group()
@click.version_option(__version__)
def cli() -> None:
    """HAON PowerHub miner agent."""


@cli.command()
@click.option("--api-url", default="https://api.staging.haon.run", show_default=True)
def login(api_url: str) -> None:
    """Paste an API key created in the dashboard / via /v1/me/api-keys."""
    click.echo(f"API URL: {api_url}")
    raw = getpass("Paste your miner:agent API key: ").strip()
    if not raw.startswith("haon_"):
        click.echo("That does not look like a HAON API key.", err=True)
        raise SystemExit(2)
    credentials.store(raw)
    cfg = config.load()
    cfg.api_url = api_url
    config.save(cfg)
    click.echo("Stored. Run `haon-agent hardware` to see what will be registered.")


@cli.command()
@click.option(
    "--api-url",
    default="https://api.staging.haon.run",
    show_default=True,
    help="HAON API base URL to pair against.",
)
@click.option(
    "--email",
    default=None,
    help="Skip the prompt and use this email.",
)
@click.option(
    "--password",
    default=None,
    help=(
        "Skip the prompt and use this password. Prefer interactive entry; "
        "passing --password puts the secret in shell history."
    ),
)
@click.option("--name", "machine_name", default=None, help="Machine name (default: hostname).")
@click.option("--price", "price_per_hour", default=None, help="Price per hour in USD (e.g. 0.40).")
@click.option("--hub-id", default=None, help="Pin to a specific hub UUID (skip interactive pick).")
@click.option(
    "--non-interactive",
    is_flag=True,
    default=False,
    help="Fail instead of prompting for missing values. Useful in installer scripts.",
)
def pair(
    api_url: str,
    email: str | None,
    password: str | None,
    machine_name: str | None,
    price_per_hour: str | None,
    hub_id: str | None,
    non_interactive: bool,
) -> None:
    """One-command pairing: login, register machine, mint API key, save config.

    This is the plug-and-play path for new miners. Prompts for email + password,
    discovers hubs, probes hardware, and writes everything to ~/.haon/.
    After it returns, `haon-agent run` works without flags.
    """
    from haon_agent.pair import PairError, run_pair

    try:
        run_pair(
            api_url=api_url,
            email=email,
            password=password,
            machine_name=machine_name,
            price_per_hour=price_per_hour,
            hub_id=hub_id,
            non_interactive=non_interactive,
        )
    except PairError as e:
        click.echo(f"\npair failed: {e}", err=True)
        raise SystemExit(2) from e
    except KeyboardInterrupt:
        click.echo("\naborted.", err=True)
        raise SystemExit(130) from None


@cli.command()
def logout() -> None:
    credentials.clear()
    click.echo("Credentials cleared.")


@cli.command()
@click.option(
    "--fake-hardware",
    is_flag=True,
    default=False,
    help="Dev/test: report a synthetic RTX 4090 rig without probing the host.",
)
def hardware_info(fake_hardware: bool) -> None:
    """Show detected hardware. No network calls."""
    _apply_fake_hardware(fake_hardware)
    report = hardware.detect()
    click.echo(f"CPU: {report.cpu_model} ({report.cpu_cores} cores)")
    click.echo(f"RAM: {report.ram_gb} GB")
    if report.gpu_count > 0:
        click.echo(
            f"GPU: {report.gpu_model} "
            f"({report.gpu_count}× @ {report.gpu_vram_gb} GB VRAM)"
        )
    else:
        click.echo("GPU: none detected (CPU-only)")
    click.echo(f"Fingerprint: {report.fingerprint()[:16]}…")


cli.add_command(hardware_info, name="hardware")


@cli.command()
def status() -> None:
    """Show config + credential presence (never echoes the key itself)."""
    cfg = config.load()
    has_key = credentials.load() is not None
    click.echo(f"API URL: {cfg.api_url}")
    click.echo(f"Machine ID: {cfg.machine_id or '(not registered)'}")
    click.echo(f"Hub ID: {cfg.hub_id or '(not set)'}")
    click.echo(f"Runtimes: {', '.join(cfg.supported_runtimes)}")
    click.echo(f"Default runtime: {cfg.default_runtime}")
    click.echo(f"Credentials present: {'yes' if has_key else 'no'}")


@cli.command()
def diagnose() -> None:
    """Dump a redacted support bundle to stdout."""
    cfg = config.load()
    report = hardware.detect()
    has_key = credentials.load() is not None
    bundle = {
        "agent_version": __version__,
        "config": {
            "api_url": cfg.api_url,
            "machine_id": cfg.machine_id,
            "hub_id": cfg.hub_id,
            "runtimes": cfg.supported_runtimes,
        },
        "credentials_present": has_key,
        "hardware": {
            "cpu_model": report.cpu_model,
            "cpu_cores": report.cpu_cores,
            "ram_gb": report.ram_gb,
            "gpu_model": report.gpu_model,
            "gpu_vram_gb": report.gpu_vram_gb,
            "gpu_count": report.gpu_count,
            "fingerprint": report.fingerprint(),
        },
    }
    import json

    click.echo(json.dumps(bundle, indent=2, default=str))


@cli.command()
@click.option("--machine-id", required=False)
@click.option(
    "--fake-hardware",
    is_flag=True,
    default=False,
    help="Dev/test: report a synthetic RTX 4090 rig instead of probing the host.",
)
def run(machine_id: str | None, fake_hardware: bool) -> None:
    """Start the agent loop: heartbeat + session accept."""
    _apply_fake_hardware(fake_hardware)
    cfg = config.load()
    if machine_id:
        cfg.machine_id = machine_id
        config.save(cfg)
    if not cfg.machine_id:
        click.echo(
            "No machine_id configured. Register your machine in the dashboard "
            "first, then run `haon-agent run --machine-id <uuid>`.",
            err=True,
        )
        raise SystemExit(2)

    key = credentials.load()
    if not key:
        click.echo("No credentials. Run `haon-agent login` first.", err=True)
        raise SystemExit(2)

    _configure_logging(cfg.log_level)

    async def _main() -> None:
        async with ApiClient(base_url=cfg.api_url, api_key=key) as api:
            agent = Agent(AgentDeps(api=api, config=cfg))
            try:
                await agent.run()
            except KeyboardInterrupt:
                agent.request_stop()

    try:
        asyncio.run(_main())
    except ApiError as e:
        click.echo(f"API error on startup: {e.code} — {e.message}", err=True)
        raise SystemExit(3) from None
