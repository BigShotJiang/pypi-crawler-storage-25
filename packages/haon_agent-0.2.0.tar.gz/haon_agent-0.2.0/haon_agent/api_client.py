"""Thin HAON API client used by the agent.

One class, one responsibility per method. In tests we swap `httpx`'s transport
for an `ASGITransport` pointed at an in-process FastAPI app — no network, no
mocks.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx


class ApiError(Exception):
    def __init__(self, status_code: int, code: str, message: str, details: dict | None = None) -> None:
        super().__init__(f"{code}: {message}")
        self.status_code = status_code
        self.code = code
        self.message = message
        self.details = details or {}


def _raise_for_error(r: httpx.Response) -> None:
    if r.is_success:
        return
    try:
        body = r.json()
        err = body.get("error", {})
        code = err.get("code", "UNKNOWN")
        message = err.get("message", r.text)
        details = err.get("details", {})
    except Exception:  # noqa: BLE001
        code = "HTTP_ERROR"
        message = r.text
        details = {}
    raise ApiError(r.status_code, code, message, details)


@dataclass
class SessionHandoff:
    """What the agent needs to actually run a session."""
    session_id: str
    worker_id: str
    machine_id: str
    runtime: str
    tunnel_broker_url: str
    tunnel_token: str
    expires_at: str


class ApiClient:
    """Token-auth HTTP client for the HAON API."""

    def __init__(
        self,
        base_url: str,
        api_key: str,
        *,
        transport: httpx.AsyncBaseTransport | None = None,
        timeout: float = 10.0,
    ) -> None:
        self._client = httpx.AsyncClient(
            base_url=base_url.rstrip("/"),
            transport=transport,
            timeout=timeout,
            headers={"X-API-Key": api_key, "User-Agent": "haon-agent/0.2"},
        )

    async def aclose(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> "ApiClient":
        return self

    async def __aexit__(self, *_exc: Any) -> None:
        await self._client.aclose()

    # ── Machines ────────────────────────────────────────────────────────

    async def register_machine(
        self,
        *,
        hub_id: str,
        name: str,
        cpu_model: str,
        cpu_cores: int,
        ram_gb: int,
        gpu_model: str | None,
        gpu_vram_gb: int | None,
        gpu_count: int,
        supported_runtimes: list[str],
        hardware_fingerprint: str,
        hardware_signature: str | None = None,
    ) -> dict:
        payload = {
            "hub_id": hub_id,
            "name": name,
            "cpu_model": cpu_model,
            "cpu_cores": cpu_cores,
            "ram_gb": ram_gb,
            "gpu_count": gpu_count,
            "supported_runtimes": supported_runtimes,
            "hardware_fingerprint": hardware_fingerprint,
        }
        if gpu_model is not None:
            payload["gpu_model"] = gpu_model
        if gpu_vram_gb is not None:
            payload["gpu_vram_gb"] = gpu_vram_gb
        if hardware_signature is not None:
            payload["hardware_signature"] = hardware_signature

        # Agent needs a user JWT (not API key) to register a machine. In Phase 10
        # registration happens via `haon-agent register` which prompts for
        # email+password → JWT → register. The runtime agent uses API keys.
        # For now the method exists as a convenience; the CLI uses the login flow.
        r = await self._client.post("/v1/machines", json=payload)
        _raise_for_error(r)
        return r.json()

    async def heartbeat(
        self,
        machine_id: str,
        *,
        runtime_ready: bool,
        cpu_percent: float | None = None,
        ram_used_mb: int | None = None,
        gpu_utilization_percent: list[float] | None = None,
        pending_sessions: int | None = None,
    ) -> dict:
        payload: dict = {"runtime_ready": runtime_ready}
        if cpu_percent is not None:
            payload["cpu_percent"] = cpu_percent
        if ram_used_mb is not None:
            payload["ram_used_mb"] = ram_used_mb
        if gpu_utilization_percent is not None:
            payload["gpu_utilization_percent"] = gpu_utilization_percent
        if pending_sessions is not None:
            payload["pending_sessions"] = pending_sessions
        r = await self._client.post(
            f"/v1/machines/{machine_id}/heartbeat", json=payload
        )
        _raise_for_error(r)
        return r.json()

    # ── Sessions ────────────────────────────────────────────────────────

    async def start_session(self, session_id: str) -> SessionHandoff:
        r = await self._client.post(f"/v1/sessions/{session_id}/start")
        _raise_for_error(r)
        body = r.json()
        sess = body["session"]
        return SessionHandoff(
            session_id=sess["id"],
            worker_id=sess["worker_id"],
            machine_id=sess["machine_id"],
            runtime=sess.get("runtime") or "",
            tunnel_broker_url=body["tunnel"]["broker_url"],
            tunnel_token=body["tunnel"]["token"],
            expires_at=body["tunnel"]["expires_at"],
        )

    async def close_session(self, session_id: str, reason: str = "miner_closed") -> dict:
        r = await self._client.post(
            f"/v1/sessions/{session_id}/close", json={"reason": reason}
        )
        _raise_for_error(r)
        return r.json()

    async def get_session(self, session_id: str) -> dict:
        r = await self._client.get(f"/v1/sessions/{session_id}")
        _raise_for_error(r)
        return r.json()

    # ── Usage ticks ─────────────────────────────────────────────────────

    async def post_ticks(self, ticks: list[dict]) -> dict:
        """Submit a batch (1..10) of UsageTick records."""
        r = await self._client.post("/v1/usage/ticks", json={"ticks": ticks})
        _raise_for_error(r)
        return r.json()
