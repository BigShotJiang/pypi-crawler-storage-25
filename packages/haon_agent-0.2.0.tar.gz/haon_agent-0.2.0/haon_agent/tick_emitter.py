"""Per-session background task that samples usage and POSTs ticks.

Spawned by the agent's `_run_session` right after the runtime starts. Stops
when the session ends. On transient API failures it logs and keeps trying —
missed ticks are fine (the backend already tolerates gaps in `tick_seq`) as
long as we don't double-post or rollback.
"""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from typing import Any

import structlog

from haon_agent.api_client import ApiClient, ApiError
from haon_agent.broker_client import BrokerClient
from haon_agent.usage import Sample, SamplerBackend, SubprocessSamplerBackend, sample

log = structlog.get_logger("agent.ticks")


def _utcnow() -> datetime:
    return datetime.now(tz=timezone.utc)


class TickEmitter:
    """Drives the 10-second tick cadence for one session."""

    def __init__(
        self,
        *,
        api: ApiClient,
        session_id: str,
        broker: BrokerClient,
        container_name: str | None,
        interval_seconds: int = 10,
        sampler: SamplerBackend | None = None,
    ) -> None:
        self._api = api
        self._session_id = session_id
        self._broker = broker
        self._container_name = container_name
        self._interval = interval_seconds
        self._sampler = sampler or SubprocessSamplerBackend()
        self._task: asyncio.Task[None] | None = None
        self._stop = asyncio.Event()
        self._tick_seq = 0
        self._last_bytes_sent = 0
        self._last_bytes_recv = 0

    def start(self) -> None:
        if self._task is not None:
            return
        self._task = asyncio.create_task(self._run())

    async def stop(self) -> None:
        self._stop.set()
        if self._task is not None:
            try:
                await asyncio.wait_for(self._task, timeout=5)
            except asyncio.TimeoutError:
                self._task.cancel()
            self._task = None

    async def _run(self) -> None:
        while not self._stop.is_set():
            try:
                await asyncio.wait_for(
                    self._stop.wait(), timeout=self._interval
                )
                # If we were asked to stop, exit without emitting a partial tick.
                return
            except asyncio.TimeoutError:
                pass  # normal cadence

            await self._emit_one()

    async def _emit_one(self) -> None:
        smp: Sample
        if self._container_name is None:
            smp = Sample(cpu_percent=0.0, ram_mb=0, gpu_percent=0.0, vram_mb=0)
        else:
            try:
                smp = await sample(
                    container_name=self._container_name, backend=self._sampler
                )
            except Exception as e:  # noqa: BLE001
                log.warning("tick_sample_failed", error=str(e))
                smp = Sample(cpu_percent=0.0, ram_mb=0, gpu_percent=0.0, vram_mb=0)

        bytes_sent = self._broker.bytes_sent
        bytes_recv = self._broker.bytes_recv
        delta_sent = max(0, bytes_sent - self._last_bytes_sent)
        delta_recv = max(0, bytes_recv - self._last_bytes_recv)
        self._last_bytes_sent = bytes_sent
        self._last_bytes_recv = bytes_recv

        payload: dict[str, Any] = {
            "session_id": self._session_id,
            "tick_seq": self._tick_seq,
            "emitted_at": _utcnow().isoformat(),
            "duration_seconds": self._interval,
            "cpu_percent": smp.cpu_percent,
            "gpu_percent": smp.gpu_percent,
            "ram_mb": smp.ram_mb,
            "vram_mb": smp.vram_mb,
            "bytes_in": delta_recv,     # worker → miner
            "bytes_out": delta_sent,    # miner → worker
        }
        try:
            resp = await self._api.post_ticks([payload])
            results = resp.get("results") or []
            if results and not results[0].get("accepted"):
                log.warning(
                    "tick_rejected",
                    tick_seq=self._tick_seq,
                    reason=results[0].get("rejection_reason"),
                )
            self._tick_seq += 1
        except ApiError as e:
            log.warning("tick_post_failed", code=e.code, status=e.status_code)
        except Exception as e:  # noqa: BLE001
            log.exception("tick_post_unhandled", error=str(e))
