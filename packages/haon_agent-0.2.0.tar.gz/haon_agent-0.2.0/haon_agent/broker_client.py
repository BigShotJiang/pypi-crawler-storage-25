"""Agent-side broker client.

Opens a WebSocket to the tunnel broker, presents the session token via
subprotocol, encodes/decodes the same frame protocol the broker speaks
(see services/tunnel-broker/app/protocol.py).

Intentionally minimal: this is the data-plane edge. No business logic — it
ferries bytes + signals to the orchestrator.
"""

from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass
from enum import IntEnum
from typing import AsyncIterator

import structlog
import websockets

log = structlog.get_logger("agent.broker")


class FrameType(IntEnum):
    DATA = 0x01
    PING = 0x02
    PONG = 0x03
    PAIRED = 0x10
    UNPAIRED = 0x11
    REFRESH_TOKEN = 0x12
    CLOSE = 0x13
    STATS = 0x14
    ERROR = 0x7F


MAX_FRAME_BYTES = 1 * 1024 * 1024


def encode(ftype: FrameType, payload: bytes = b"") -> bytes:
    return bytes([int(ftype)]) + payload


def decode(raw: bytes) -> tuple[FrameType, bytes]:
    if not isinstance(raw, (bytes, bytearray, memoryview)):
        raise ValueError("binary frame expected")
    if not raw:
        raise ValueError("empty frame")
    if len(raw) > MAX_FRAME_BYTES + 1:
        raise ValueError(f"frame too large: {len(raw)}")
    t = FrameType(raw[0])
    return t, bytes(raw[1:])


@dataclass
class BrokerEvent:
    type: FrameType
    payload: bytes

    def json(self) -> dict:
        if not self.payload:
            return {}
        return json.loads(self.payload.decode("utf-8"))


class BrokerClient:
    """Connect, emit DATA, listen for PAIRED/UNPAIRED/CLOSE/DATA.

    Byte counters `bytes_sent` (miner→worker) and `bytes_recv` (worker→miner)
    are maintained locally so the agent can report them in UsageTick without
    coordinating with the broker. The broker keeps its own authoritative
    counter per session; ours is a shadow used only for ticks.
    """

    def __init__(self, broker_url: str, token: str) -> None:
        self._url = broker_url
        self._token = token
        self._ws: websockets.WebSocketClientProtocol | None = None
        self.bytes_sent: int = 0
        self.bytes_recv: int = 0

    async def connect(self) -> None:
        self._ws = await websockets.connect(
            self._url,
            subprotocols=["haon-tunnel.v1", f"bearer.{self._token}"],
            max_size=MAX_FRAME_BYTES + 1,
        )
        log.info("broker_connected", broker_url=_redact_url(self._url))

    async def close(self) -> None:
        ws = self._ws
        self._ws = None
        if ws is not None:
            try:
                await ws.close()
            except Exception:  # noqa: BLE001
                pass
            log.info("broker_closed")

    async def send_data(self, payload: bytes) -> None:
        if self._ws is None:
            raise RuntimeError("broker not connected")
        if len(payload) > MAX_FRAME_BYTES:
            raise ValueError(f"payload too large: {len(payload)}")
        await self._ws.send(encode(FrameType.DATA, payload))
        self.bytes_sent += len(payload)

    async def send_ping(self) -> None:
        if self._ws is None:
            raise RuntimeError("broker not connected")
        await self._ws.send(encode(FrameType.PING))

    async def events(self) -> AsyncIterator[BrokerEvent]:
        """Yield every inbound frame until the broker disconnects."""
        if self._ws is None:
            raise RuntimeError("broker not connected")
        try:
            async for msg in self._ws:
                if isinstance(msg, str):
                    # Protocol is binary-only; ignore text.
                    continue
                try:
                    t, payload = decode(msg)
                except ValueError as e:
                    log.warning("broker_decode_failed", error=str(e))
                    continue
                if t is FrameType.DATA:
                    self.bytes_recv += len(payload)
                yield BrokerEvent(type=t, payload=payload)
        except websockets.exceptions.ConnectionClosed:
            return

    async def await_paired(self, timeout: float = 10.0) -> BrokerEvent:
        """Read until a PAIRED event arrives. Times out otherwise."""
        async def _loop() -> BrokerEvent:
            async for ev in self.events():
                if ev.type is FrameType.PAIRED:
                    return ev
                if ev.type is FrameType.CLOSE:
                    raise RuntimeError(
                        f"broker closed before pairing: {ev.json()}"
                    )
            raise RuntimeError("broker disconnected before pairing")

        return await asyncio.wait_for(_loop(), timeout=timeout)


def _redact_url(url: str) -> str:
    """Strip any `?token=...` for log safety."""
    return url.split("?")[0]
