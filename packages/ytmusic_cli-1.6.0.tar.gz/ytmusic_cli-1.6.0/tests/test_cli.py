"""Tests for CLI argument parsing."""

from ytmusic.cli import create_parser


def test_cli_defaults():
    parser = create_parser()
    args = parser.parse_args(["https://example.com"])

    assert args.output == "music_library"
    assert args.threshold == 0.5
    assert args.quiet is False
    assert args.dry_run is False
    assert args.sync is False


def test_cli_flags():
    parser = create_parser()
    args = parser.parse_args(
        [
            "https://example.com",
            "-o",
            "~/Music",
            "-t",
            "0.7",
            "-q",
            "--sync",
            "--dry-run",
        ]
    )

    assert args.output == "~/Music"
    assert args.threshold == 0.7
    assert args.quiet is True
    assert args.sync is True
    assert args.dry_run is True
