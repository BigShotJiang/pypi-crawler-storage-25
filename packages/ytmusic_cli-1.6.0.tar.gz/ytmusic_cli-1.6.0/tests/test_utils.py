"""Tests for ytmusic CLI tool."""

from ytmusic.utils import (
    calculate_similarity,
    extract_song_info,
    extract_version_and_clean,
    parse_youtube_title,
    sanitize_filename,
    strip_cjk_characters,
)


class TestUtils:
    """Test utility functions."""

    def test_sanitize_filename(self):
        """Test filename sanitization."""
        assert sanitize_filename("Artist - Song.mp3") == "Artist - Song.mp3"
        assert sanitize_filename("Artist<Song>.mp3") == "ArtistSong.mp3"
        assert sanitize_filename("Artist:Song?.mp3") == "ArtistSong.mp3"

    def test_calculate_similarity(self):
        """Test string similarity calculation."""
        assert calculate_similarity("hello", "hello") == 1.0
        assert calculate_similarity("hello", "world") < 0.5
        assert calculate_similarity("", "test") == 0.0

    def test_extract_song_info(self):
        """Test song info extraction from titles."""
        artist, song = extract_song_info("Artist - Song Title")
        assert artist == "Artist"
        assert song == "Song Title"

        artist, song = extract_song_info("Just a title")
        assert artist is None
        assert song == "Just a title"

    def test_strip_cjk_preserves_extended_latin(self):
        """CJK stripped, extended Latin preserved."""
        # Accented characters preserved
        assert strip_cjk_characters("Mötley Crüe") == "Mötley Crüe"
        assert strip_cjk_characters("Beyoncé") == "Beyoncé"
        # CJK punctuation stripped (may affect spacing around it)
        result = strip_cjk_characters("TWICE「Song」")
        assert "「" not in result
        assert "」" not in result
        # Hangul stripped
        result = strip_cjk_characters("BTS (방탄소년단)")
        assert "방" not in result  # Verify Hangul removed
        # CJK ideographs stripped
        assert strip_cjk_characters("歌曲名") == ""

    def test_extract_version_and_clean_priority(self):
        """[] checked before (), version beats promotional."""
        # Version in [] brackets
        title, version = extract_version_and_clean("Song [Remastered 2024] (Official)")
        assert title == "Song"
        assert version == "remastered"

        # Version in () parentheses
        title, version = extract_version_and_clean("Song (Live at Venue)")
        assert title == "Song"
        assert version == "live"

        # Promotional junk stripped, no version
        title, version = extract_version_and_clean("Song (Official Video)")
        assert title == "Song"
        assert version is None

        # Acoustic version
        title, version = extract_version_and_clean("Song [Acoustic Version]")
        assert title == "Song"
        assert version == "acoustic"

    def test_parse_youtube_title_collaborations(self):
        """Test collaboration handling with feat. extraction."""
        # feat. in song portion moves to artist
        artist, song, version = parse_youtube_title("Artist - Song (feat. Guest)")
        assert artist == "Artist feat. Guest"
        assert song == "Song"
        assert version is None

        # x between artists normalized to feat.
        artist, song, version = parse_youtube_title("Artist1 x Artist2 - Song")
        assert artist == "Artist1 feat. Artist2"
        assert song == "Song"

        # & between artists normalized
        artist, song, version = parse_youtube_title("Artist & Other - Song")
        assert artist == "Artist feat. Other"
        assert song == "Song"

        # Combined: feat. in song + x in artist
        artist, song, version = parse_youtube_title("Artist1 x Artist2 - Song (feat. Guest)")
        assert artist == "Artist1 feat. Artist2 feat. Guest"
        assert song == "Song"

    def test_parse_youtube_title_auto_generated(self):
        """Test YouTube auto-generated format parsing."""
        # Pipe separator
        artist, song, version = parse_youtube_title("Song Title | Artist Name")
        assert artist == "Artist Name"
        assert song == "Song Title"

        # Bullet separator
        artist, song, version = parse_youtube_title("Song Title • Artist Name")
        assert artist == "Artist Name"
        assert song == "Song Title"

    def test_parse_youtube_title_versions(self):
        """Test version suffix extraction in full parsing."""
        # Live version
        artist, song, version = parse_youtube_title("Artist - Song (Live at Madison Square Garden)")
        assert artist == "Artist"
        assert song == "Song"
        assert version == "live"

        # Acoustic with promotional junk
        artist, song, version = parse_youtube_title("Artist - Song [Acoustic] (Official Video)")
        assert artist == "Artist"
        assert song == "Song"
        assert version == "acoustic"

        # Remix version
        artist, song, version = parse_youtube_title("Artist - Song (Remix)")
        assert artist == "Artist"
        assert song == "Song"
        assert version == "remix"

    def test_parse_youtube_title_cjk_stripping(self):
        """Test CJK character removal during parsing."""
        # When no separator exists, whole thing becomes song with no artist
        artist, song, version = parse_youtube_title("TWICE「Song」")
        # CJK punctuation stripped, may result in single combined string
        assert "「" not in song
        assert "」" not in song

        # Standard format with CJK should work
        artist, song, version = parse_youtube_title("TWICE - 「Song」")
        assert artist == "TWICE"
        assert "「" not in song
        assert "」" not in song

    def test_parse_youtube_title_comprehensive(self):
        """Test complex real-world title parsing."""
        # Complex case: collaboration + version + promotional
        artist, song, version = parse_youtube_title(
            "Artist1 x Artist2 - Song Name (feat. Guest) [Live] (Official Video)"
        )
        assert artist == "Artist1 feat. Artist2 feat. Guest"
        assert song == "Song Name"
        assert version == "live"

        # Auto-generated with version
        artist, song, version = parse_youtube_title("Song (Acoustic) | Artist")
        assert artist == "Artist"
        assert song == "Song"
        assert version == "acoustic"
