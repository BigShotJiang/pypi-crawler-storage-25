"""Basic tests for the new database and sync modules."""

import os
import tempfile
from pathlib import Path

import pytest

from ytmusic.database import MusicDatabase
from ytmusic.local_sync_file import LocalSyncFile
from ytmusic.models import DownloadStatus, Playlist, Song
from ytmusic.sync import PlaylistSync


class TestMusicDatabase:
    """Tests for the MusicDatabase class."""

    def test_database_initialization(self):
        """Test that database initializes correctly."""
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "test.db"
            db = MusicDatabase(db_path)

            # Check that tables exist
            conn = db._get_connection()
            cursor = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            )
            tables = {row[0] for row in cursor.fetchall()}

            expected_tables = {
                "schema_version",
                "playlists",
                "songs",
                "youtube_sources",
                "local_files",
                "download_history",
                "sync_state",
            }
            assert expected_tables.issubset(tables)

            db.close()

    def test_playlist_crud(self):
        """Test playlist create and retrieve operations."""
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "test.db"
            db = MusicDatabase(db_path)

            # Create playlist
            playlist = db.get_or_create_playlist(
                youtube_id="PL123",
                title="Test Playlist",
                url="https://youtube.com/playlist?list=PL123",
                track_count=10,
            )

            assert playlist.id is not None
            assert playlist.youtube_id == "PL123"
            assert playlist.title == "Test Playlist"

            # Retrieve existing playlist
            existing = db.get_or_create_playlist(
                youtube_id="PL123",
                title="Different Title",  # Should not update
                url="https://youtube.com/playlist?list=PL123",
            )

            assert existing.id == playlist.id
            assert existing.title == "Test Playlist"  # Original title preserved

            db.close()

    def test_song_crud(self):
        """Test song create and retrieve operations."""
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "test.db"
            db = MusicDatabase(db_path)

            # Create song
            song = db.get_or_create_song(
                title="Test Song",
                artist="Test Artist",
                album="Test Album",
                genre="Rock",
                year=2024,
                isrc="USABC1234567",
            )

            assert song.id is not None
            assert song.title == "Test Song"
            assert song.isrc == "USABC1234567"

            # Create different song (same artist/title but different album)
            song2 = db.get_or_create_song(
                title="Test Song",
                artist="Test Artist",
                album="Different Album",
            )

            assert song2.id != song.id

            db.close()

    def test_download_history(self):
        """Test download history tracking."""
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "test.db"
            db = MusicDatabase(db_path)

            # Create required entities
            playlist = db.get_or_create_playlist(
                youtube_id="PL456", title="Test", url="http://test"
            )
            song = db.get_or_create_song(title="Song", artist="Artist")
            yt_source = db.get_or_create_youtube_source(
                video_id="abc123",
                playlist_id=playlist.id,
                song_id=song.id,
                youtube_title="Original Title",
            )

            # Record download attempt
            history = db.record_download_attempt(
                youtube_source_id=yt_source.id,
                status=DownloadStatus.SUCCESS,
            )

            assert history.id is not None
            assert history.status == DownloadStatus.SUCCESS

            # Retrieve history
            recent = db.get_download_history(yt_source.id)
            assert len(recent) == 1
            assert recent[0].status == DownloadStatus.SUCCESS

            db.close()


class TestLocalSyncFile:
    """Tests for the LocalSyncFile class."""

    def test_sync_file_creation(self):
        """Test creating and reading sync file."""
        with tempfile.TemporaryDirectory() as tmpdir:
            sync_file = LocalSyncFile(tmpdir)
            playlist = Playlist(
                id=1,
                youtube_id="PL789",
                title="My Playlist",
                url="https://youtube.com/playlist?list=PL789",
            )

            # Initialize
            data = sync_file.initialize(playlist)
            assert sync_file.exists()

            # Read back
            read_data = sync_file.read()
            assert read_data is not None
            assert read_data.playlist["youtube_id"] == "PL789"

    def test_add_song_to_sync(self):
        """Test adding songs to sync file."""
        with tempfile.TemporaryDirectory() as tmpdir:
            sync_file = LocalSyncFile(tmpdir)
            playlist = Playlist(
                id=1,
                youtube_id="PL999",
                title="Test",
                url="http://test",
            )
            sync_file.initialize(playlist)

            # Create song
            song = Song(
                id=123,
                title="Awesome Song",
                artist="Great Artist",
                album="Best Album",
            )

            # Add to sync
            sync_file.add_song(
                song=song,
                video_id="xyz789",
                local_file="Great Artist - Awesome Song.m4a",
                version_type="studio",
            )

            # Verify
            entries = sync_file.get_all_songs()
            assert len(entries) == 1
            assert entries[0].title == "Awesome Song"
            assert entries[0].video_id == "xyz789"

    def test_file_detection(self):
        """Test file change detection."""
        with tempfile.TemporaryDirectory() as tmpdir:
            sync_file = LocalSyncFile(tmpdir)
            playlist = Playlist(
                id=1,
                youtube_id="PL111",
                title="Test",
                url="http://test",
            )
            sync_file.initialize(playlist)

            # Create a fake audio file
            fake_file = Path(tmpdir) / "test_song.m4a"
            fake_file.write_text("fake audio data")

            # Scan
            files = sync_file.scan_local_files()
            assert len(files) == 1
            assert files[0][0] == "test_song.m4a"


class TestPlaylistSync:
    """Tests for the PlaylistSync class."""

    def test_rescan_no_sync_file(self):
        """Test rescan when no sync file exists."""
        with tempfile.TemporaryDirectory() as tmpdir:
            sync = PlaylistSync()
            result = sync.rescan_playlist(Path(tmpdir))
            assert "error" in result
            sync.close()

    def test_cleanup_dry_run(self):
        """Test cleanup in dry-run mode."""
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "test.db"
            db = MusicDatabase(db_path)
            sync = PlaylistSync(db)

            # Should not fail even with empty database
            stats = sync.cleanup_orphaned_records(dry_run=True, verbose=False)
            assert isinstance(stats, dict)
            assert "orphaned_local_files" in stats

            sync.close()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
