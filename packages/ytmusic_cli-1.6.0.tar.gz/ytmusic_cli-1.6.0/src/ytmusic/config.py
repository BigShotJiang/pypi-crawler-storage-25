"""Configuration file support for ytmusic-cli."""

import os
from pathlib import Path
from typing import Any

from ytmusic.constants import console

CONFIG_MAPPING = {
    ("download", "path"): "output",
    ("download", "sync"): "sync",
    ("download", "quiet"): "quiet",
    ("metadata", "threshold"): "threshold",
}

DEFAULT_CONFIG = {
    "output": "music_library",
    "threshold": 0.5,
    "quiet": False,
    "sync": False,
}

CONFIG_TEMPLATE = """# ytmusic config.yaml
# Configuration file for ytmusic-cli

download:
  path: "~/Music"           # Output directory
  sync: false               # Skip existing files
  quiet: false              # Only show errors

metadata:
  threshold: 0.5            # Similarity threshold 0.0-1.0
"""


def get_config_path() -> Path:
    """Get the configuration file path."""
    # Check environment variable first
    if env_path := os.environ.get("YTMUSIC_CONFIG"):
        return Path(env_path)

    # Default: ~/.config/ytmusic/config.yaml
    return Path.home() / ".config" / "ytmusic" / "config.yaml"


def load_config(config_path: Path | None = None) -> dict[str, Any]:
    """
    Load configuration from YAML file.
    Returns empty dict if file doesn't exist or is invalid.
    """
    path = config_path or get_config_path()

    if not path.exists():
        return {}

    try:
        import yaml

        with open(path, encoding="utf-8") as f:
            raw_config = yaml.safe_load(f) or {}
    except ImportError:
        console.print("[yellow]⚠ PyYAML not installed, cannot load config file[/yellow]")
        return {}
    except Exception as e:
        console.print(f"[yellow]⚠ Failed to load config: {e}[/yellow]")
        return {}

    # Flatten nested structure to match CLI argument names
    config = {}
    for (section, key), arg_name in CONFIG_MAPPING.items():
        if section in raw_config and key in raw_config[section]:
            config[arg_name] = raw_config[section][key]

    return config


def save_default_config(config_path: Path | None = None) -> Path:
    """Create default configuration file."""
    path = config_path or get_config_path()
    path.parent.mkdir(parents=True, exist_ok=True)

    with open(path, "w", encoding="utf-8") as f:
        f.write(CONFIG_TEMPLATE)

    return path


def merge_config(args: Any) -> Any:
    """
    Merge config file values with CLI arguments.
    Precedence: CLI args > config file > defaults
    """
    config = load_config()

    for key, default_value in DEFAULT_CONFIG.items():
        config_value = config.get(key)
        current_value = getattr(args, key, None)

        # Apply config value if:
        # 1. Config has a value for this key
        # 2. Current value is None (not explicitly set via CLI)
        if (
            config_value is not None
            and current_value is None
            or config_value is not None
            and current_value == default_value
        ):
            setattr(args, key, config_value)

    return args


def init_config_command():
    """Initialize config file command handler."""
    path = get_config_path()

    if path.exists():
        console.print(f"[yellow]Config file already exists at {path}[/yellow]")
        overwrite = input("Overwrite? [y/N]: ").lower().strip() == "y"
        if not overwrite:
            return

    save_default_config(path)
    console.print(f"[green]✓ Created config file at {path}[/green]")
