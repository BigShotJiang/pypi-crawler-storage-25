"""Data models for the music library database."""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional


class DownloadStatus(Enum):
    """Status of a download attempt."""

    SUCCESS = "success"
    FAILED = "failed"
    SKIPPED = "skipped"
    RETRY = "retry"
    PENDING = "pending"


@dataclass
class Song:
    """Canonical song entity, independent of sources."""

    title: str
    artist: str
    album: Optional[str] = None
    genre: Optional[str] = None
    year: Optional[int] = None
    track_number: Optional[int] = None
    disc_number: Optional[int] = None
    duration_seconds: Optional[int] = None
    isrc: Optional[str] = None
    id: Optional[int] = None
    created_at: Optional[datetime] = None

    def __hash__(self) -> int:
        """Hash based on unique identifying fields."""
        return hash(
            (
                self.artist.lower().strip(),
                self.title.lower().strip(),
                self.album.lower().strip() if self.album else "",
                self.isrc or "",
                self.duration_seconds or 0,
            )
        )

    def __eq__(self, other: object) -> bool:
        """Equality check for deduplication."""
        if not isinstance(other, Song):
            return NotImplemented
        return (
            self.artist.lower().strip() == other.artist.lower().strip()
            and self.title.lower().strip() == other.title.lower().strip()
            and (self.album or "").lower().strip() == (other.album or "").lower().strip()
            and (self.isrc or "") == (other.isrc or "")
            and (self.duration_seconds or 0) == (other.duration_seconds or 0)
        )


@dataclass
class Playlist:
    """YouTube playlist being tracked."""

    youtube_id: str
    title: str
    url: str
    track_count: Optional[int] = None
    last_synced_at: Optional[datetime] = None
    created_at: Optional[datetime] = None
    id: Optional[int] = None

    @property
    def sync_filename(self) -> str:
        """Name of the local sync file for this playlist."""
        return ".ytmusic-sync.yaml"


@dataclass
class YoutubeSource:
    """Link between a YouTube video and a canonical song."""

    video_id: str
    playlist_id: int
    song_id: int
    youtube_title: str
    version_type: Optional[str] = None
    position_in_playlist: Optional[int] = None
    similarity_score: float = 0.0
    metadata_source: Optional[str] = None  # itunes, musicbrainz, etc.
    added_at: Optional[datetime] = None
    removed_from_playlist_at: Optional[datetime] = None
    id: Optional[int] = None

    @property
    def youtube_url(self) -> str:
        """Full YouTube URL for this video."""
        return f"https://www.youtube.com/watch?v={self.video_id}"


@dataclass
class LocalFile:
    """Link between a canonical song and a local audio file."""

    song_id: int
    file_path: str
    file_name: str
    file_size_bytes: Optional[int] = None
    mtime: Optional[int] = None  # Unix timestamp for quick change detection
    format: Optional[str] = None
    bitrate: Optional[str] = None
    checksum: Optional[str] = None  # Format: "sha256:abc..." or "xxhash:def..."
    downloaded_at: Optional[datetime] = None
    modified_at: Optional[datetime] = None
    last_verified_at: Optional[datetime] = None
    id: Optional[int] = None

    def has_changed(self, current_mtime: int, current_size: int) -> bool:
        """Quick check if file has changed since last sync."""
        if self.mtime is None or self.file_size_bytes is None:
            return True
        return self.mtime != current_mtime or self.file_size_bytes != current_size


@dataclass
class DownloadHistory:
    """Record of a download attempt."""

    youtube_source_id: int
    local_file_id: Optional[int] = None
    status: DownloadStatus = DownloadStatus.PENDING
    error_message: Optional[str] = None
    downloaded_at: Optional[datetime] = None
    attempt_number: int = 1
    id: Optional[int] = None


@dataclass
class SyncState:
    """State of a synchronization operation."""

    playlist_id: int
    sync_type: str  # download, rescan, cleanup
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    items_processed: int = 0
    items_added: int = 0
    items_removed: int = 0
    items_failed: int = 0
    id: Optional[int] = None


@dataclass
class LocalSyncEntry:
    """Entry in the local sync YAML file (per playlist)."""

    song_id: int
    video_id: str
    title: str
    artist: str
    album: Optional[str] = None
    local_file: str = ""
    downloaded_at: Optional[str] = None  # ISO format
    mtime: Optional[int] = None  # Unix timestamp
    size: Optional[int] = None  # Bytes
    checksum: Optional[str] = None  # Format: "algo:value"
    version_type: Optional[str] = None


@dataclass
class LocalSyncData:
    """Complete data for a local sync file."""

    playlist: dict = field(default_factory=dict)
    songs: list = field(default_factory=list)

    @classmethod
    def from_playlist(cls, playlist: Playlist) -> "LocalSyncData":
        """Create initial sync data from a playlist."""
        return cls(
            playlist={
                "youtube_id": playlist.youtube_id,
                "name": playlist.title,
                "last_sync": None,
                "sync_version": 1,
            },
            songs=[],
        )
