"""Synchronization logic for playlist management and rescan operations."""

import os
from datetime import datetime
from pathlib import Path
from typing import Optional

from rich.panel import Panel
from rich.table import Table

from ytmusic.database import MusicDatabase
from ytmusic.local_sync_file import LocalSyncFile
from ytmusic.models import LocalSyncEntry, SyncState
from ytmusic.constants import AUDIO_EXTENSIONS, console


class PlaylistSync:
    """Handles synchronization between YouTube playlists and local files."""

    def __init__(self, db: Optional[MusicDatabase] = None):
        """Initialize sync manager.

        Args:
            db: Database instance. If None, creates a new one.
        """
        self.db = db or MusicDatabase()

    def rescan_playlist(
        self,
        playlist_dir: Path,
        auto_fix: bool = False,
        verbose: bool = False,
    ) -> dict:
        """Rescan a local playlist folder and detect changes.

        Args:
            playlist_dir: Path to the playlist folder
            auto_fix: If True, automatically update sync file to match reality
            verbose: Show detailed output

        Returns:
            Dict with change statistics
        """
        sync_file = LocalSyncFile(playlist_dir)

        if not sync_file.exists():
            console.print(f"[yellow]⚠ No sync file found in {playlist_dir}[/yellow]")
            return {"error": "No sync file"}

        # Read current sync state
        sync_data = sync_file.read()
        if not sync_data:
            console.print(f"[yellow]⚠ Could not read sync file[/yellow]")
            return {"error": "Invalid sync file"}

        # Detect changes
        changes = sync_file.detect_changes()

        # Display results
        console.print(
            Panel.fit(
                f"[bold cyan]Rescan: {sync_data.playlist.get('name', 'Unknown')}[/bold cyan]",
                border_style="cyan",
            )
        )

        stats = {
            "new_files": len(changes["new_files"]),
            "missing_files": len(changes["missing_files"]),
            "modified_files": len(changes["modified_files"]),
        }

        if verbose:
            if changes["new_files"]:
                console.print("\n[green]New files found:[/green]")
                for f in changes["new_files"]:
                    console.print(f"  + {f}")

            if changes["missing_files"]:
                console.print("\n[red]Missing files:[/red]")
                for f in changes["missing_files"]:
                    console.print(f"  - {f}")

            if changes["modified_files"]:
                console.print("\n[yellow]Modified files:[/yellow]")
                for item in changes["modified_files"]:
                    console.print(f"  ~ {item['filename']}")

        console.print(f"\n[dim]New: {stats['new_files']} | Missing: {stats['missing_files']} | Modified: {stats['modified_files']}[/dim]")

        # Auto-fix: update sync file to match reality
        if auto_fix:
            self._apply_rescan_fixes(sync_file, changes, playlist_dir)
            console.print("[green]✓ Sync file updated[/green]")

        return stats

    def _apply_rescan_fixes(
        self,
        sync_file: LocalSyncFile,
        changes: dict,
        playlist_dir: Path,
    ) -> None:
        """Apply fixes to sync file based on detected changes."""
        sync_data = sync_file.read()
        if not sync_data:
            return

        # Remove entries for missing files
        for filename in changes["missing_files"]:
            # Find and remove entry by filename
            sync_data.songs = [
                s for s in sync_data.songs if s.get("local_file") != filename
            ]

        # Add entries for new files (basic info only)
        audio_extensions = AUDIO_EXTENSIONS
        for filename in changes["new_files"]:
            file_path = playlist_dir / filename
            if file_path.suffix.lower() in audio_extensions:
                # Try to parse artist and title from filename
                from ytmusic.utils import extract_song_info

                artist, title = extract_song_info(file_path.stem)
                mtime, size, checksum = LocalSyncFile._get_file_metadata(file_path)

                new_entry = {
                    "song_id": None,  # Unknown until matched
                    "video_id": None,  # Unknown (added manually)
                    "title": title or file_path.stem,
                    "artist": artist or "Unknown",
                    "album": None,
                    "local_file": filename,
                    "downloaded_at": None,
                    "mtime": mtime,
                    "size": size,
                    "checksum": checksum,
                    "version_type": None,
                }
                sync_data.songs.append(new_entry)

        # Update modified files
        for item in changes["modified_files"]:
            filename = item["filename"]
            # Find entry and update checksum
            for entry in sync_data.songs:
                if entry.get("local_file") == filename:
                    entry["mtime"] = item["new_mtime"]
                    entry["checksum"] = item["new_checksum"]
                    break

        # Update sync timestamp
        sync_file.write(sync_data)

    def get_playlist_status(
        self,
        playlist_dir: Path,
        show_files: bool = False,
    ) -> Optional[Table]:
        """Get detailed status of a playlist folder.

        Args:
            playlist_dir: Path to the playlist folder
            show_files: If True, include file list in output

        Returns:
            Rich Table with status information, or None if no sync file
        """
        sync_file = LocalSyncFile(playlist_dir)

        if not sync_file.exists():
            return None

        sync_data = sync_file.read()
        if not sync_data:
            return None

        # Build status table
        table = Table(title=f"Playlist: {sync_data.playlist.get('name', 'Unknown')}")
        table.add_column("Property", style="cyan")
        table.add_column("Value", style="white")

        table.add_row("YouTube ID", sync_data.playlist.get("youtube_id", "Unknown"))
        table.add_row("Last Sync", sync_data.playlist.get("last_sync", "Never"))
        table.add_row("Tracked Songs", str(len(sync_data.songs)))

        # Count actual files
        actual_files = sync_file.scan_local_files()
        table.add_row("Actual Files", str(len(actual_files)))

        # Check for discrepancies
        changes = sync_file.detect_changes()
        issues = changes["new_files"] or changes["missing_files"] or changes["modified_files"]
        table.add_row("Status", "[red]Issues detected[/red]" if issues else "[green]OK[/green]")

        if show_files and sync_data.songs:
            table.add_row("", "")
            files_info = "\n".join(
                f"  {s.get('artist', '?')} - {s.get('title', '?')}"
                for s in sync_data.songs[:10]  # Limit to first 10
            )
            if len(sync_data.songs) > 10:
                files_info += f"\n  ... and {len(sync_data.songs) - 10} more"
            table.add_row("Files", files_info)

        return table

    def cleanup_orphaned_records(
        self,
        dry_run: bool = True,
        verbose: bool = False,
    ) -> dict:
        """Clean up orphaned database records.

        Removes:
        - Local file records where the file no longer exists
        - YouTube sources marked as removed from playlist (soft delete)
        - Download history older than retention period

        Args:
            dry_run: If True, only report what would be deleted
            verbose: Show detailed output

        Returns:
            Dict with cleanup statistics
        """
        stats = {
            "orphaned_local_files": 0,
            "removed_youtube_sources": 0,
            "old_download_history": 0,
        }

        # Find orphaned local files
        conn = self.db._get_connection()

        # Check each local file
        cursor = conn.execute(
            "SELECT id, file_path FROM local_files WHERE last_verified_at IS NULL OR last_verified_at < datetime('now', '-7 days')"
        )

        orphaned_ids = []
        for row in cursor.fetchall():
            file_path = Path(row["file_path"])
            if not file_path.exists():
                orphaned_ids.append(row["id"])

        stats["orphaned_local_files"] = len(orphaned_ids)

        # Count removed YouTube sources
        cursor = conn.execute(
            "SELECT COUNT(*) FROM youtube_sources WHERE removed_from_playlist_at IS NOT NULL"
        )
        stats["removed_youtube_sources"] = cursor.fetchone()[0]

        # Count old download history (older than 90 days)
        cursor = conn.execute(
            "SELECT COUNT(*) FROM download_history WHERE downloaded_at < datetime('now', '-90 days')"
        )
        stats["old_download_history"] = cursor.fetchone()[0]

        if verbose:
            console.print("\n[bold cyan]Cleanup Report[/bold cyan]")
            console.print(f"Orphaned local files: {stats['orphaned_local_files']}")
            console.print(f"Removed YouTube sources: {stats['removed_youtube_sources']}")
            console.print(f"Old download history: {stats['old_download_history']}")

        if not dry_run:
            # Delete orphaned local files
            if orphaned_ids:
                placeholders = ",".join("?" * len(orphaned_ids))
                conn.execute(
                    f"DELETE FROM local_files WHERE id IN ({placeholders})",
                    orphaned_ids,
                )

            # Delete removed YouTube sources
            conn.execute(
                "DELETE FROM youtube_sources WHERE removed_from_playlist_at IS NOT NULL"
            )

            # Delete old download history
            conn.execute(
                "DELETE FROM download_history WHERE downloaded_at < datetime('now', '-90 days')"
            )

            conn.commit()

            if verbose:
                console.print("[green]✓ Cleanup completed[/green]")

        return stats

    def sync_playlist_from_yaml(
        self,
        playlist_dir: Path,
        verbose: bool = False,
    ) -> bool:
        """Sync database state from a local YAML file.

        This is useful when restoring a playlist folder on a new machine
        and wanting to rebuild the central database.

        Args:
            playlist_dir: Path to the playlist folder
            verbose: Show detailed output

        Returns:
            True if successful
        """
        sync_file = LocalSyncFile(playlist_dir)

        if not sync_file.exists():
            console.print(f"[red]✗ No sync file found in {playlist_dir}[/red]")
            return False

        sync_data = sync_file.read()
        if not sync_data:
            console.print(f"[red]✗ Could not read sync file[/red]")
            return False

        # Get or create playlist in database
        youtube_id = sync_data.playlist.get("youtube_id")
        if not youtube_id:
            console.print("[red]✗ No YouTube ID in sync file[/red]")
            return False

        playlist = self.db.get_or_create_playlist(
            youtube_id=youtube_id,
            title=sync_data.playlist.get("name", "Unknown"),
            url=f"https://www.youtube.com/playlist?list={youtube_id}",
        )

        # Sync each song
        synced_count = 0
        for entry_data in sync_data.songs:
            try:
                # Create or get song
                song = self.db.get_or_create_song(
                    title=entry_data.get("title", "Unknown"),
                    artist=entry_data.get("artist", "Unknown"),
                    album=entry_data.get("album"),
                )

                # Create YouTube source
                video_id = entry_data.get("video_id")
                if video_id:
                    self.db.get_or_create_youtube_source(
                        video_id=video_id,
                        playlist_id=playlist.id,
                        song_id=song.id,
                        youtube_title=entry_data.get("title", "Unknown"),
                        version_type=entry_data.get("version_type"),
                    )

                # Create local file record if file exists
                local_file = entry_data.get("local_file")
                if local_file:
                    file_path = playlist_dir / local_file
                    if file_path.exists():
                        self.db.create_local_file(
                            song_id=song.id,
                            file_path=str(file_path),
                            file_name=local_file,
                            mtime=entry_data.get("mtime"),
                            checksum=entry_data.get("checksum"),
                        )

                synced_count += 1
            except Exception as e:
                if verbose:
                    console.print(f"[red]✗ Error syncing {entry_data.get('title')}: {e}[/red]")

        self.db.update_playlist_sync_time(playlist.id)

        console.print(
            f"[green]✓ Synced {synced_count}/{len(sync_data.songs)} songs from {playlist_dir.name}[/green]"
        )
        return True

    def close(self) -> None:
        """Close database connection."""
        self.db.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
