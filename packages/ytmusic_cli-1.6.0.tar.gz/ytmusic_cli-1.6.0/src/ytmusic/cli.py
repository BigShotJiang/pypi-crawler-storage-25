"""Command-line interface for YouTube Music Library."""

import argparse
import ssl
import sys

from ytmusic import __version__
from ytmusic.constants import console
from ytmusic.downloader import PlaylistDownloader

try:
    import certifi
except Exception:  # pragma: no cover - optional at runtime
    certifi = None



def create_parser() -> argparse.ArgumentParser:
    """Create and configure argument parser."""
    parser = argparse.ArgumentParser(
        prog="ytmusic",
        description="Download YouTube playlists as audio with rich metadata",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  ytmusic "https://www.youtube.com/playlist?list=PLAYLIST_ID"
  ytmusic "PLAYLIST_URL" -o ~/Music
  ytmusic "PLAYLIST_URL" --dry-run
        """,
    )

    parser.add_argument("url", help="YouTube playlist URL or ID")

    parser.add_argument(
        "-o",
        "--output",
        default="music_library",
        metavar="DIR",
        help="Output directory (default: music_library)",
    )

    parser.add_argument(
        "-t",
        "--threshold",
        type=float,
        default=0.5,
        metavar="0.0-1.0",
        help="Similarity threshold 0.0-1.0 (default: 0.5)",
    )

    parser.add_argument(
        "-q",
        "--quiet",
        action="store_true",
        help="Only show errors",
    )

    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview without downloading",
    )

    parser.add_argument(
        "--sync",
        action="store_true",
        help="Skip existing files",
    )

    parser.add_argument(
        "--rescan",
        metavar="DIR",
        help="Rescan playlist folder for changes",
    )

    parser.add_argument(
        "--cleanup",
        action="store_true",
        help="Clean up orphaned database records",
    )

    parser.add_argument(
        "--config",
        action="store_true",
        help="Show config file path",
    )

    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")

    return parser


def _handle_sync_commands(args) -> bool:
    """Handle sync-related CLI commands."""
    from pathlib import Path

    from ytmusic.sync import PlaylistSync

    sync = PlaylistSync()
    handled = False

    try:
        if args.rescan:
            handled = True
            sync.rescan_playlist(
                playlist_dir=Path(args.rescan),
                auto_fix=True,
                verbose=True,
            )
        elif args.cleanup:
            handled = True
            stats = sync.cleanup_orphaned_records(dry_run=False, verbose=True)
    finally:
        sync.close()

    return handled


def validate_args(args) -> bool:
    """Validate command line arguments."""
    if args.threshold < 0.0 or args.threshold > 1.0:
        console.print("[red]Error: Threshold must be between 0.0 and 1.0[/red]")
        return False

    # Validate URL
    if "youtube.com" not in args.url and "youtu.be" not in args.url:
        if not args.url.startswith("PL"):
            console.print("[red]Error: Invalid YouTube URL[/red]")
            return False
        else:
            # Assume it's just a playlist ID
            args.url = f"https://www.youtube.com/playlist?list={args.url}"

    return True


def main(args=None):
    """Main CLI entry point."""
    from ytmusic.constants import DEFAULT_BITRATE, DEFAULT_OUTPUT_FORMAT

    if certifi is not None:
        ssl._create_default_https_context = lambda: ssl.create_default_context(
            cafile=certifi.where()
        )

    if args is None:
        args = sys.argv[1:]
    if "--config" in args:
        from ytmusic.config import get_config_path

        console.print(str(get_config_path()))
        return

    parser = create_parser()
    parsed_args = parser.parse_args(args)

    from ytmusic.config import merge_config

    args = merge_config(parsed_args)

    if _handle_sync_commands(args):
        return

    if not validate_args(args):
        sys.exit(1)

    if args.dry_run:
        console.print("[yellow]Dry run mode - no files will be downloaded[/yellow]\n")
        from pytubefix import Playlist

        from ytmusic.metadata import search_itunes_metadata
        from ytmusic.utils import extract_song_info

        playlist = Playlist(args.url)
        console.print(f"Playlist: [bold]{playlist.title}[/bold]")
        console.print(f"Videos: {len(playlist.video_urls)}\n")

        for idx, url in enumerate(playlist.video_urls, 1):
            from pytubefix import YouTube

            yt = YouTube(url)
            artist, song = extract_song_info(yt.title)
            metadata, similarity = (
                search_itunes_metadata(artist, song, yt.title) if artist and song else (None, 0)
            )
            if not metadata:
                metadata, similarity = search_itunes_metadata(None, yt.title, yt.title)

            status = "[green]![/green]" if similarity >= args.threshold else "[red]![/red]"
            console.print(f"{status} [{idx}] {yt.title[:50]}... ({similarity:.0%} match)")

        console.print("\n[dim]Use without --dry-run to download[/dim]")
        return

    downloader = PlaylistDownloader(
        similarity_threshold=args.threshold,
        output_dir=args.output,
        output_format=DEFAULT_OUTPUT_FORMAT,
        bitrate=DEFAULT_BITRATE,
        convert=True,
        quiet=args.quiet,
        verbose=False,
        summary=False,
        max_workers=None,
        cache_ttl_days=None,
        sync_mode=args.sync,
    )
    downloader.process(args.url)


if __name__ == "__main__":
    main()
