"""YouTube playlist and audio downloading functionality."""

import os
import shutil
import subprocess
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from time import perf_counter
from typing import Optional

from pytubefix import Playlist, YouTube
from pytubefix.cli import on_progress
from rich.console import Console
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TaskProgressColumn,
    TextColumn,
    TimeRemainingColumn,
)

from ytmusic.cache import ItunesCache
from ytmusic.constants import AUDIO_EXTENSIONS, TAGABLE_EXTENSIONS, console
from ytmusic.database import MusicDatabase
from ytmusic.local_sync_file import LocalSyncFile
from ytmusic.metadata import download_cover_art, search_itunes_metadata
from ytmusic.models import DownloadStatus
from ytmusic.tagger import embed_metadata
from ytmusic.utils import (
    VERSION_PRIORITY,
    calculate_similarity,
    extract_song_info,
    format_filename_from_metadata,
    parse_youtube_title,
    sanitize_filename,
)


class PlaylistDownloader:
    """Handles downloading and processing of YouTube playlists."""

    def __init__(
        self,
        similarity_threshold: float = 0.5,
        output_dir: str = "music_library",
        output_format: str = "m4a",
        bitrate: str = "192k",
        convert: bool = True,
        quiet: bool = False,
        verbose: bool = False,
        summary: bool = False,
        max_workers: int | None = None,
        cache_ttl_days: int | None = None,
        sync_mode: bool = False,
    ):
        self.similarity_threshold = similarity_threshold
        self.output_dir = Path(output_dir)
        self.output_format = output_format
        self.bitrate = bitrate
        self.convert = convert
        self.quiet = quiet
        self.verbose = verbose
        self.summary = summary
        self.max_workers = max_workers or min(32, (os.cpu_count() or 1) + 4)
        self.sync_mode = sync_mode
        self._lock = threading.Lock()
        self.skipped_count = 0
        self.downloaded_count = 0
        self.error_count = 0
        self._cache = ItunesCache(ttl_days=cache_ttl_days)
        self._db = MusicDatabase()
        self._sync_file: Optional[LocalSyncFile] = None
        self._playlist_id: Optional[int] = None

    def get_best_audio_stream(self, yt: YouTube) -> Optional:
        """Get the best quality audio-only stream."""
        audio_streams = yt.streams.filter(only_audio=True)

        if not audio_streams:
            return None

        # Prefer AAC/mp4a codec for best compatibility
        for stream in audio_streams:
            if stream.audio_codec and ("mp4a" in stream.audio_codec or "aac" in stream.audio_codec):
                return stream

        # Fall back to first available
        return audio_streams.first()

    def _log(self, message: str):
        if not self.quiet:
            console.print(message)

    def _log_verbose(self, message: str):
        if self.verbose and not self.quiet:
            console.print(message)

    def _log_error(self, message: str):
        console.print(message)

    def _unique_path(self, path: Path) -> Path:
        """Ensure output path does not collide with an existing file."""
        if not path.exists():
            return path

        counter = 1
        while True:
            candidate = path.with_name(f"{path.stem}_{counter}{path.suffix}")
            if not candidate.exists():
                return candidate
            counter += 1

    def _extension_from_stream(self, stream: YouTube) -> str:
        """Best-effort extension from stream mime type."""
        mime_type = getattr(stream, "mime_type", "") or ""
        if "/" not in mime_type:
            return ""

        subtype = mime_type.split("/", 1)[1].lower()
        mapping = {
            "webm": ".webm",
            "mp4": ".m4a",
            "mpeg": ".mp3",
            "aac": ".aac",
            "ogg": ".ogg",
            "x-m4a": ".m4a",
            "x-ms-wma": ".wma",
            "wav": ".wav",
            "flac": ".flac",
        }
        return mapping.get(subtype, "")

    def _extract_playlist_id(self, playlist_url: str) -> str:
        """Extract playlist ID from URL or return the ID if already just the ID."""
        if "list=" in playlist_url:
            return playlist_url.split("list=")[1].split("&")[0]
        return playlist_url.strip()

    def _convert_audio(self, source_path: Path, target_ext: str) -> Path | None:
        """Convert audio using ffmpeg if available."""
        if shutil.which("ffmpeg") is None:
            return None

        target_path = self._unique_path(source_path.with_suffix(target_ext))
        codec = "aac" if target_ext == ".m4a" else "libmp3lame"
        try:
            subprocess.run(
                [
                    "ffmpeg",
                    "-y",
                    "-i",
                    str(source_path),
                    "-vn",
                    "-c:a",
                    codec,
                    "-b:a",
                    self.bitrate,
                    str(target_path),
                ],
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            return target_path
        except subprocess.CalledProcessError:
            return None

    def _truncate(self, text: str, max_len: int = 60) -> str:
        if len(text) <= max_len:
            return text
        return text[: max_len - 1] + "…"

    def _collect_all_metadata(self, playlist_urls: list[str]) -> list[dict]:
        """
        Pre-scan ALL videos before downloading to enable deduplication.
        Uses concurrent processing for speed with progress indication.
        """
        all_metadata = [None] * len(playlist_urls)  # Pre-allocate to maintain order
        completed = 0
        errors = 0

        self._log(f"[dim]Pre-scanning {len(playlist_urls)} videos for deduplication...[/dim]")

        def scan_single(idx_url: tuple) -> tuple[int, dict]:
            """Scan a single video. Returns (index, metadata_dict)."""
            idx, video_url = idx_url
            try:
                yt = YouTube(video_url)
                youtube_title = yt.title

                # Parse title using enhanced parser
                artist, song, version = parse_youtube_title(youtube_title)

                # Extract video ID for caching
                video_id = ItunesCache.extract_video_id(video_url)

                # Search metadata with version info
                metadata = None
                similarity = 0.0

                if artist and song:
                    metadata, similarity, _ = search_itunes_metadata(
                        artist,
                        song,
                        youtube_title,
                        version,
                        video_id=video_id,
                        cache=self._cache,
                        verbose=self.verbose,
                    )

                if not metadata:
                    metadata, similarity, _ = search_itunes_metadata(
                        None,
                        youtube_title,
                        youtube_title,
                        version,
                        video_id=video_id,
                        cache=self._cache,
                        verbose=self.verbose,
                    )

                return idx, {
                    "url": video_url,
                    "idx": idx + 1,  # 1-based for display
                    "youtube_title": youtube_title,
                    "artist": artist,
                    "song": song,
                    "version": version,
                    "metadata": metadata,
                    "similarity": similarity,
                }
            except Exception:
                # Return empty metadata on error
                return idx, {
                    "url": video_url,
                    "idx": idx + 1,
                    "youtube_title": None,
                    "artist": None,
                    "song": None,
                    "version": None,
                    "metadata": None,
                    "similarity": 0.0,
                }

        # Use ThreadPoolExecutor for concurrent scanning
        with ThreadPoolExecutor(max_workers=min(8, self.max_workers)) as executor:
            # Submit all tasks
            future_to_idx = {
                executor.submit(scan_single, (i, url)): i for i, url in enumerate(playlist_urls)
            }

            # Process results as they complete
            for future in as_completed(future_to_idx):
                idx = future_to_idx[future]
                try:
                    _, meta = future.result(timeout=30)  # 30s timeout per video
                    all_metadata[idx] = meta
                    if meta.get("youtube_title"):
                        completed += 1
                    else:
                        errors += 1
                except Exception:
                    # Timeout or other error
                    all_metadata[idx] = {
                        "url": playlist_urls[idx],
                        "idx": idx + 1,
                        "youtube_title": None,
                        "artist": None,
                        "song": None,
                        "version": None,
                        "metadata": None,
                        "similarity": 0.0,
                    }
                    errors += 1

                # Update progress display every few items
                total_done = completed + errors
                if total_done % 5 == 0 or total_done == len(playlist_urls):
                    self._log(
                        f"[dim]Pre-scanning: {total_done}/{len(playlist_urls)} "
                        f"({completed} found, {errors} errors)[/dim]"
                    )

        self._log(f"[green]✓[/green] Pre-scan complete: {completed} ready, {errors} errors\n")
        return all_metadata

    def _find_exact_duplicates(self, metadata_list: list[dict]) -> dict[str, list[int]]:
        """
        Group by (artist_clean.lower(), song_clean.lower()) exact match.

        Returns: {hash: [indices]} where each group has same artist+title
        """
        groups = {}

        for idx, meta in enumerate(metadata_list):
            if not meta.get("artist") or not meta.get("song"):
                continue

            # Create hash from normalized artist + clean song
            artist_key = meta["artist"].lower().strip()
            song_key = meta["song"].lower().strip()
            hash_key = f"{artist_key}::{song_key}"

            if hash_key not in groups:
                groups[hash_key] = []
            groups[hash_key].append(idx)

        # Only return groups with duplicates (more than 1)
        return {k: v for k, v in groups.items() if len(v) > 1}

    def _resolve_version_conflicts(
        self, duplicate_groups: dict[str, list[int]], metadata_list: list[dict]
    ) -> set[int]:
        """
        For each duplicate group, keep highest priority version.

        Returns: set of indices to SKIP (lower priority versions)
        """
        skip_indices = set()

        for _hash_key, indices in duplicate_groups.items():
            # Get version priorities for each duplicate
            versions_with_priority = []
            for idx in indices:
                meta = metadata_list[idx]
                version = meta.get("version")
                # Get priority from VERSION_PRIORITY, default to high number (low priority)
                priority = VERSION_PRIORITY.get(version, 10) if version else 0
                versions_with_priority.append((idx, version, priority, meta["similarity"]))

            # Sort by priority (lower = better), then by similarity (higher = better)
            versions_with_priority.sort(key=lambda x: (x[2], -x[3]))

            # Keep the first one (best), skip the rest
            best_idx, best_version, best_priority, best_sim = versions_with_priority[0]

            for idx, _version, _priority, _similarity in versions_with_priority[1:]:
                skip_indices.add(idx)
                meta = metadata_list[idx]
                best_meta = metadata_list[best_idx]

                self._log(
                    f"[yellow]⏭[/yellow] Skipping duplicate (lower priority): "
                    f"'{meta['artist']} - {meta['song']}' ({meta['version'] or 'studio'}) "
                    f"→ keeping ({best_meta['version'] or 'studio'})"
                )

        return skip_indices

    def download_song(
        self,
        video_url: str,
        playlist_dir: Path,
        idx: int,
        total: int,
        progress: Progress | None = None,
        task_id: int | None = None,
        precomputed_metadata: dict | None = None,
    ) -> bool:
        """Download and process a single song with database tracking."""
        youtube_source_id: Optional[int] = None
        song_id: Optional[int] = None
        final_path: Optional[Path] = None

        try:
            yt = YouTube(video_url, on_progress_callback=on_progress)
            youtube_title = yt.title
            if progress is not None and task_id is not None:
                progress.update(
                    task_id, description=f"[{idx}/{total}] {self._truncate(youtube_title)}"
                )

            # Extract video ID
            video_id = ItunesCache.extract_video_id(video_url)

            # Extract song info and metadata
            metadata = None
            similarity = 0.0
            artist: Optional[str] = None
            song_title: Optional[str] = None

            if precomputed_metadata:
                metadata = precomputed_metadata.get("metadata")
                similarity = precomputed_metadata.get("similarity", 0.0)
                artist = precomputed_metadata.get("artist")
                song_title = precomputed_metadata.get("song")
            else:
                artist, song_title = extract_song_info(youtube_title)

                if artist and song_title:
                    metadata, similarity, _ = search_itunes_metadata(
                        artist,
                        song_title,
                        youtube_title,
                        video_id=video_id,
                        cache=self._cache,
                        verbose=self.verbose,
                    )

                if not metadata:
                    metadata, similarity, _ = search_itunes_metadata(
                        None,
                        youtube_title,
                        youtube_title,
                        video_id=video_id,
                        cache=self._cache,
                        verbose=self.verbose,
                    )

            # Skip if similarity is too low
            if similarity < self.similarity_threshold:
                self._log(
                    f"[yellow]⏭[/yellow] Skipping (low similarity {similarity:.0%}): {youtube_title}"
                )
                with self._lock:
                    self.skipped_count += 1
                # Record skipped download
                if self._playlist_id and video_id:
                    self._record_download_attempt(
                        video_id, None, DownloadStatus.SKIPPED, "Low similarity"
                    )
                return False

            # Create or get song in database
            if self._playlist_id and metadata:
                song = self._db.get_or_create_song(
                    title=metadata.get("trackName", song_title or "Unknown"),
                    artist=metadata.get("artistName", artist or "Unknown"),
                    album=metadata.get("collectionName"),
                    genre=metadata.get("primaryGenreName"),
                    year=metadata.get("releaseDate", "")[:4]
                    if metadata.get("releaseDate")
                    else None,
                    isrc=metadata.get("isrc"),
                )
                song_id = song.id

                # Create YouTube source
                version_type = precomputed_metadata.get("version") if precomputed_metadata else None
                yt_source = self._db.get_or_create_youtube_source(
                    video_id=video_id,
                    playlist_id=self._playlist_id,
                    song_id=song_id,
                    youtube_title=youtube_title,
                    version_type=version_type,
                    position=idx,
                    similarity=similarity,
                    metadata_source="itunes" if metadata else None,
                )
                youtube_source_id = yt_source.id

            # Generate filename from metadata
            target_filename = format_filename_from_metadata(metadata) or sanitize_filename(
                youtube_title
            )
            target_filename = sanitize_filename(target_filename)

            # Check if already exists
            existing_files = list(playlist_dir.glob(f"{target_filename}.*"))
            if existing_files:
                self._log(f"[yellow]⏭[/yellow] Skipping (already exists): {existing_files[0].name}")
                with self._lock:
                    self.skipped_count += 1
                # Update sync file for existing file
                if self._sync_file and song_id and video_id:
                    self._sync_file.add_song(
                        song=self._db.get_song_by_id(song_id),
                        video_id=video_id,
                        local_file=existing_files[0].name,
                        version_type=version_type,
                    )
                # Record skipped download
                if youtube_source_id:
                    self._db.record_download_attempt(
                        youtube_source_id=youtube_source_id,
                        local_file_id=None,
                        status=DownloadStatus.SKIPPED,
                        error_message="File already exists",
                    )
                return False

            # Check for incomplete marker (resumed download)
            marker_path = playlist_dir / f".incomplete_{target_filename}"
            if marker_path.exists():
                self._log(f"[yellow]⟳[/yellow] Resuming: {target_filename}")
            else:
                # Create marker to indicate download in progress
                marker_path.touch()

            # Get audio stream
            audio_stream = self.get_best_audio_stream(yt)
            if not audio_stream:
                self._log_error(f"[red]✗[/red] No audio stream for: {youtube_title}")
                with self._lock:
                    self.error_count += 1
                marker_path.unlink(missing_ok=True)
                # Record failed download
                if youtube_source_id:
                    self._db.record_download_attempt(
                        youtube_source_id=youtube_source_id,
                        status=DownloadStatus.FAILED,
                        error_message="No audio stream",
                    )
                return False

            self._log_verbose(
                f"[dim]Stream: {audio_stream.mime_type} / {audio_stream.audio_codec}[/dim]"
            )

            # Download
            temp_file = audio_stream.download(
                output_path=str(playlist_dir),
                filename=f"temp_{idx}_{threading.current_thread().ident}",
            )
            file_ext = Path(temp_file).suffix
            if not file_ext:
                file_ext = self._extension_from_stream(audio_stream)

            # Rename to final filename
            final_filename = f"{target_filename}{file_ext}" if file_ext else target_filename
            final_path = playlist_dir / final_filename

            # Handle duplicates
            final_path = self._unique_path(final_path)

            os.rename(temp_file, final_path)

            # Remove incomplete marker on success
            marker_path.unlink(missing_ok=True)

            # Convert based on output format if requested
            if self.output_format in {"m4a", "mp3"} and self.convert:
                target_ext = ".m4a" if self.output_format == "m4a" else ".mp3"
                if final_path.suffix.lower() != target_ext:
                    converted_path = self._convert_audio(final_path, target_ext)
                    if converted_path:
                        final_path.unlink(missing_ok=True)
                        final_path = converted_path
                        file_ext = final_path.suffix
                        self._log_verbose(
                            f"[dim]Converted to {final_path.suffix} at {self.bitrate}[/dim]"
                        )
                    else:
                        self._log(
                            "[yellow]⚠ ffmpeg not available; keeping original format.[/yellow]"
                        )
            elif final_path.suffix.lower() not in TAGABLE_EXTENSIONS:
                if self.convert and self.output_format != "original":
                    self._log("[yellow]⚠ Unsupported format and conversion disabled.[/yellow]")

            # Create local file record in database
            local_file_id: Optional[int] = None
            if song_id and self._db:
                local_file = self._db.create_local_file(
                    song_id=song_id,
                    file_path=str(final_path),
                    file_name=final_path.name,
                    file_size=final_path.stat().st_size if final_path.exists() else None,
                    mtime=int(final_path.stat().st_mtime) if final_path.exists() else None,
                    format=file_ext.lstrip(".") if file_ext else None,
                    bitrate=self.bitrate if self.convert else None,
                    checksum=LocalSyncFile.quick_checksum(final_path) if final_path.exists() else None,
                )
                local_file_id = local_file.id

            # Download cover art
            cover_art = None
            if metadata and metadata.get("cover_url"):
                cover_art = download_cover_art(metadata["cover_url"])

            # Embed metadata
            if final_path.suffix.lower() in TAGABLE_EXTENSIONS:
                embed_metadata(str(final_path), file_ext, metadata, cover_art)
            else:
                self._log(
                    f"[yellow]⚠ Skipping metadata embedding for unsupported format: {final_path.suffix}[/yellow]"
                )

            # Record successful download
            if youtube_source_id:
                self._db.record_download_attempt(
                    youtube_source_id=youtube_source_id,
                    local_file_id=local_file_id,
                    status=DownloadStatus.SUCCESS,
                )

            # Update sync file
            if self._sync_file and song_id and video_id:
                song = self._db.get_song_by_id(song_id)
                if song:
                    self._sync_file.add_song(
                        song=song,
                        video_id=video_id,
                        local_file=final_path.name,
                        version_type=version_type,
                    )

            self._log(
                f"[green]✓[/green] Downloaded: [bold]{final_path.name}[/bold] ([cyan]{similarity:.0%}[/cyan] match)"
            )
            with self._lock:
                self.downloaded_count += 1
            return True

        except Exception as e:
            self._log_error(f"[red]✗[/red] Error processing video: {e}")
            with self._lock:
                self.error_count += 1
            # Clean up marker on error
            try:
                marker_path = playlist_dir / f".incomplete_{target_filename}"
                marker_path.unlink(missing_ok=True)
            except NameError:
                pass  # target_filename not defined yet
            # Record failed download
            if youtube_source_id:
                self._db.record_download_attempt(
                    youtube_source_id=youtube_source_id,
                    status=DownloadStatus.FAILED,
                    error_message=str(e),
                )
            return False

    def _record_download_attempt(
        self,
        video_id: str,
        local_file_id: Optional[int],
        status: DownloadStatus,
        error_message: Optional[str] = None,
    ) -> None:
        """Helper to record download attempt when youtube_source_id is not available."""
        if not self._playlist_id:
            return
        # Get the YouTube source for this video
        conn = self._db._get_connection()
        cursor = conn.execute(
            "SELECT id FROM youtube_sources WHERE video_id = ? AND playlist_id = ?",
            (video_id, self._playlist_id),
        )
        row = cursor.fetchone()
        if row:
            self._db.record_download_attempt(
                youtube_source_id=row["id"],
                local_file_id=local_file_id,
                status=status,
                error_message=error_message,
            )

    def _scan_local_songs(self, playlist_dir: Path) -> list[dict]:
        """
        Scan local folder for existing audio files and extract artist/song info.
        Returns list of dicts with artist and song extracted from filenames.
        """
        audio_extensions = AUDIO_EXTENSIONS
        existing_songs = []

        if not playlist_dir.exists():
            return existing_songs

        for file_path in playlist_dir.iterdir():
            if file_path.is_file() and file_path.suffix.lower() in audio_extensions:
                # Extract artist and song from filename (format: "Artist - Song.m4a")
                filename = file_path.stem  # filename without extension
                artist, song = extract_song_info(filename)
                if artist and song:
                    existing_songs.append({
                        "artist": artist.lower().strip(),
                        "song": song.lower().strip(),
                        "filename": file_path.name,
                    })

        return existing_songs

    def _song_exists_locally(
        self, artist: str | None, song: str, local_songs: list[dict]
    ) -> bool:
        """
        Check if a song already exists in the local collection.
        Uses fuzzy matching on artist and song name.
        """
        if not artist or not song:
            return False

        target_artist = artist.lower().strip()
        target_song = song.lower().strip()

        for existing in local_songs:
            # Check artist similarity
            artist_sim = calculate_similarity(target_artist, existing["artist"])
            # Check song similarity
            song_sim = calculate_similarity(target_song, existing["song"])

            # Both artist and song should match with high similarity
            if artist_sim >= 0.8 and song_sim >= 0.8:
                return True

        return False

    def process(self, playlist_url: str):
        """Process entire playlist."""
        sync_info = " [SYNC MODE]" if self.sync_mode else ""
        self._log(
            Panel.fit(
                "[bold cyan]🎵 YouTube Music Library[/bold cyan]",
                subtitle=f"Threshold: {self.similarity_threshold:.0%}{sync_info}",
                border_style="cyan",
            )
        )

        # Fetch playlist info
        with console.status("[bold green]Fetching playlist info..."):
            playlist = Playlist(playlist_url)
            playlist_title = sanitize_filename(playlist.title)

        self._log(f"[green]✓[/green] Playlist: [bold]{playlist.title}[/bold]")
        self._log(f"[green]✓[/green] {len(playlist.video_urls)} videos\n")

        # Create output directory
        playlist_dir = self.output_dir / playlist_title
        playlist_dir.mkdir(parents=True, exist_ok=True)

        # Initialize database tracking for this playlist
        self._sync_file = LocalSyncFile(playlist_dir)
        db_playlist = self._db.get_or_create_playlist(
            youtube_id=self._extract_playlist_id(playlist_url),
            title=playlist.title,
            url=playlist_url,
            track_count=len(playlist.video_urls),
        )
        self._playlist_id = db_playlist.id

        # Initialize local sync file
        if not self._sync_file.exists():
            self._sync_file.initialize(db_playlist)
            self._log_verbose(f"[dim]Created sync file: {self._sync_file.file_path}[/dim]")

        # Pre-scan all metadata before downloading
        all_metadata = self._collect_all_metadata(playlist.video_urls)

        # Initialize skip indices set
        skip_indices: set[int] = set()

        # Sync mode: scan local folder and filter out existing songs
        if self.sync_mode:
            local_songs = self._scan_local_songs(playlist_dir)
            if local_songs:
                self._log(f"[dim]Found {len(local_songs)} existing songs in local folder[/dim]")

                # Mark existing songs for skipping
                for idx, meta in enumerate(all_metadata):
                    if meta.get("artist") and meta.get("song"):
                        if self._song_exists_locally(meta["artist"], meta["song"], local_songs):
                            skip_indices.add(idx)
                            self._log(
                                f"[yellow]⏭[/yellow] Skipping (exists locally): "
                                f"'{meta['artist']} - {meta['song']}'"
                            )
            else:
                self._log("[dim]Sync mode: no existing songs found, all will be downloaded[/dim]")

        # Find and resolve duplicates (exact artist+title match)
        duplicate_groups = self._find_exact_duplicates(all_metadata)
        skip_indices.update(self._resolve_version_conflicts(duplicate_groups, all_metadata))

        # Create list of videos to actually download
        videos_to_download = [
            (idx, url, all_metadata[idx - 1])  # idx is 1-based, list is 0-based
            for idx, url in enumerate(playlist.video_urls, 1)
            if (idx - 1) not in skip_indices
        ]

        # Update total for progress bar
        total_to_download = len(videos_to_download)
        self._log(
            f"[dim]Will download {total_to_download} of {len(playlist.video_urls)} songs[/dim]\n"
        )

        # Process videos concurrently
        start = perf_counter()
        with Progress(
            SpinnerColumn(),
            TextColumn("[bold blue]{task.description}"),
            BarColumn(bar_width=40),
            TaskProgressColumn(),
            TimeRemainingColumn(),
            console=console,
        ) as progress:
            task = progress.add_task("Processing songs...", total=total_to_download)

            # Clean up any stale incomplete markers from previous interrupted runs
            for marker in playlist_dir.glob(".incomplete_*"):
                marker.unlink()
                self._log(f"[dim]Cleaned up stale marker: {marker.name}[/dim]")

            # Submit all download tasks to thread pool
            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                future_to_video = {
                    executor.submit(
                        self.download_song,
                        meta["url"],
                        playlist_dir,
                        idx,
                        total_to_download,
                        progress=progress,
                        task_id=task,
                        precomputed_metadata=all_metadata[idx - 1],
                    ): (idx, meta)
                    for idx, url, meta in videos_to_download
                }

                # Process completed downloads as they finish
                for future in as_completed(future_to_video):
                    idx, meta = future_to_video[future]
                    try:
                        future.result()
                    except Exception as e:
                        self._log_error(f"[red]✗[/red] Unexpected error for video {idx}: {e}")
                        with self._lock:
                            self.error_count += 1
                    progress.advance(task)

        # Update skipped count from duplicates
        self.skipped_count += len(skip_indices)

        # Summary
        duration = perf_counter() - start

        # Update playlist sync time in database
        if self._playlist_id:
            self._db.update_playlist_sync_time(self._playlist_id)

        if self.summary or not self.quiet:
            self._log("\n[bold green]✓ Complete![/bold green]")
            self._log(f"  Downloaded: {self.downloaded_count}")
            self._log(f"  Skipped: {self.skipped_count}")
            self._log(f"  Errors: {self.error_count}")
            self._log(f"  Time: {duration:.1f}s")
            self._log(f"\nLocation: {playlist_dir}")

        # Close database connections
        self._cache.close()
        self._db.close()
