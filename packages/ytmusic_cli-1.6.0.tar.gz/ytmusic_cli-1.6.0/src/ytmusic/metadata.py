"""Music metadata search and embedding functionality."""

import threading
import time
from typing import Any

import requests

from ytmusic.cache import ItunesCache
from ytmusic.constants import console
from ytmusic.utils import calculate_similarity

ITUNES_SEARCH_URL = "https://itunes.apple.com/search"

DEFAULT_MIN_DELAY = 0.1


class ItunesRateLimiter:
    """Thread-safe rate limiter for iTunes API calls."""

    def __init__(self, min_delay: float = DEFAULT_MIN_DELAY):
        self._min_delay = min_delay
        self._lock = threading.Lock()
        self._last_call = 0.0

    def wait(self) -> None:
        """Wait if necessary to enforce rate limiting."""
        with self._lock:
            elapsed = time.time() - self._last_call
            if elapsed < self._min_delay:
                time.sleep(self._min_delay - elapsed)

    def record_call(self) -> None:
        """Record that a call was made."""
        with self._lock:
            self._last_call = time.time()


_rate_limiter = ItunesRateLimiter()


def _rate_limited_request(
    params: dict, max_retries: int = 3, base_delay: float = 1.0
) -> dict | None:
    """
    Make iTunes API request with rate limiting and retry logic.
    Ensures minimum delay between calls and handles 403/429 errors.
    """
    for attempt in range(max_retries):
        try:
            _rate_limiter.wait()

            response = requests.get(ITUNES_SEARCH_URL, params=params, timeout=10)
            _rate_limiter.record_call()

            if response.status_code == 403:
                if attempt < max_retries - 1:
                    wait_time = 2 + attempt * 2
                    console.print(
                        f"[yellow]⚠ Blocked by iTunes (403), waiting {wait_time}s...[/yellow]"
                    )
                    time.sleep(wait_time)
                    continue
                return None

            if response.status_code == 429:
                if attempt < max_retries - 1:
                    retry_after = int(response.headers.get("Retry-After", 5))
                    console.print(
                        f"[yellow]⚠ Rate limited by iTunes API, waiting {retry_after}s...[/yellow]"
                    )
                    time.sleep(retry_after)
                    continue
                return None

            response.raise_for_status()

            try:
                return response.json()
            except ValueError:
                if attempt < max_retries - 1:
                    console.print("[yellow]⚠ Empty response from iTunes, retrying...[/yellow]")
                    continue
                return None

        except requests.exceptions.Timeout:
            if attempt < max_retries - 1:
                console.print("[yellow]⚠ iTunes request timeout, retrying...[/yellow]")
                continue
            return None

        except requests.exceptions.RequestException as e:
            if attempt < max_retries - 1:
                console.print(f"[yellow]⚠ iTunes request failed: {e}, retrying...[/yellow]")
                continue
            return None

    return None


def search_itunes_metadata(
    artist: str | None,
    song: str,
    original_title: str,
    version: str | None = None,
    video_id: str | None = None,
    cache: ItunesCache | None = None,
    verbose: bool = False,
) -> tuple[dict[str, Any] | None, float, str | None]:
    """
    Search for song metadata on iTunes API.

    Strategy:
    1. Check cache first if video_id provided
    2. Search without version first (find studio version)
    3. If version provided and low similarity, try with version appended
    4. Returns metadata, similarity, and version_type
    """
    try:
        # Check cache first
        if cache and video_id:
            cached = cache.get(video_id)
            if cached:
                if verbose:
                    console.print(f"[dim]  Cache hit for {video_id}[/dim]")
                return cached.metadata, cached.similarity, cached.version_type
            elif verbose:
                console.print(f"[dim]  Cache miss for {video_id}[/dim]")

        # Build query - try without version first for better matches
        base_query = f"{artist} {song}" if artist else song
        queries = [base_query]

        # If version provided, also try with version appended
        if version:
            version_query = f"{base_query} {version}"
            queries.append(version_query)

        best_match = None
        best_similarity = 0.0

        for query in queries:
            params = {"term": query, "media": "music", "entity": "song", "limit": 5}
            data = _rate_limited_request(params, max_retries=3)

            if data and data.get("resultCount", 0) > 0:
                for result in data["results"]:
                    result_title = result.get("trackName", "")
                    result_artist = result.get("artistName", "")

                    # Calculate similarity with original title
                    full_result = f"{result_artist} - {result_title}"
                    similarity = calculate_similarity(original_title, full_result)

                    # Also check individual components
                    # Compare with clean song (without version)
                    clean_song = song.lower()
                    title_sim = calculate_similarity(clean_song, result_title.lower())
                    if artist:
                        artist_sim = calculate_similarity(artist.lower(), result_artist.lower())
                        similarity = max(similarity, (title_sim + artist_sim) / 2)
                    else:
                        similarity = max(similarity, title_sim)

                    if similarity > best_similarity:
                        best_similarity = similarity
                        best_match = {
                            "title": result.get("trackName"),
                            "artist": result.get("artistName"),
                            "album": result.get("collectionName"),
                            "year": result.get("releaseDate", "")[:4]
                            if result.get("releaseDate")
                            else None,
                            "genre": result.get("primaryGenreName"),
                            "cover_url": result.get("artworkUrl100", "").replace(
                                "100x100bb", "600x600bb"
                            ),
                            "track_number": result.get("trackNumber"),
                            "disc_number": result.get("discNumber"),
                            "version_type": version if version else None,
                        }

        # Store in cache if we have a result
        if cache and video_id and best_match:
            cache.set(video_id, original_title, best_match, best_similarity, version)

        return best_match, best_similarity, version
    except Exception as e:
        console.print(f"[yellow]⚠ Metadata search failed: {e}[/yellow]")

    return None, 0.0, version


def download_cover_art(url: str) -> bytes | None:
    """Download album cover art."""
    try:
        response = requests.get(url, timeout=10)
        if response.status_code == 200:
            return response.content
    except Exception:
        pass
    return None
