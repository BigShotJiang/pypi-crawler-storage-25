"""SQLite-based cache for iTunes API responses."""

import json
import os
import sqlite3
import threading
from collections import OrderedDict
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from ytmusic.constants import DEFAULT_CACHE_DIR


@dataclass
class CacheEntry:
    """Represents a cached iTunes metadata entry."""

    metadata: dict
    similarity: float
    version_type: str | None


class ItunesCache:
    """Thread-safe SQLite cache for iTunes API responses using YouTube video ID as key."""

    DEFAULT_TTL_DAYS = 30
    MAX_ENTRIES = 10000
    MAX_MEMORY_ENTRIES = 1000  # In-memory LRU cache size

    def __init__(self, ttl_days: int | None = None):
        self.ttl_days = ttl_days or int(os.environ.get("YTMUSIC_CACHE_TTL", self.DEFAULT_TTL_DAYS))
        self._lock = threading.RLock()
        self._local = threading.local()

        # In-memory LRU cache to prevent duplicate API calls within same run
        self._memory_cache = OrderedDict()
        self._memory_lock = threading.Lock()

        # Ensure cache directory exists
        self.cache_dir = DEFAULT_CACHE_DIR
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.db_path = self.cache_dir / "itunes_cache.db"

        # Initialize database
        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        """Get a thread-local database connection."""
        if not hasattr(self._local, "conn") or self._local.conn is None:
            self._local.conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
            self._local.conn.execute("PRAGMA journal_mode=WAL;")
            self._local.conn.execute("PRAGMA synchronous=NORMAL;")
        return self._local.conn

    def _init_db(self) -> None:
        """Create cache table if it doesn't exist."""
        with self._lock:
            conn = self._get_connection()
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS itunes_cache (
                    video_id TEXT PRIMARY KEY,
                    youtube_title TEXT,
                    metadata TEXT NOT NULL,
                    similarity REAL NOT NULL,
                    version_type TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    accessed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_accessed_at
                ON itunes_cache(accessed_at)
            """
            )
            conn.commit()

    @staticmethod
    def extract_video_id(video_url: str) -> str | None:
        """Extract YouTube video ID from various URL formats."""
        parsed = urlparse(video_url)

        # Handle youtube.com/watch?v=VIDEO_ID
        if parsed.netloc in ("www.youtube.com", "youtube.com", "m.youtube.com"):
            if parsed.path == "/watch":
                qs = parse_qs(parsed.query)
                if "v" in qs:
                    return qs["v"][0]
            # Handle youtube.com/shorts/VIDEO_ID
            if parsed.path.startswith("/shorts/"):
                return parsed.path.split("/")[2].split("?")[0]
            # Handle youtube.com/embed/VIDEO_ID
            if parsed.path.startswith("/embed/"):
                return parsed.path.split("/")[2].split("?")[0]
            # Handle youtube.com/v/VIDEO_ID
            if parsed.path.startswith("/v/"):
                return parsed.path.split("/")[2].split("?")[0]

        # Handle youtu.be/VIDEO_ID
        if parsed.netloc == "youtu.be":
            return parsed.path.strip("/").split("?")[0]

        return None

    def get(self, video_id: str) -> CacheEntry | None:
        """Retrieve cached metadata for a video ID."""
        if not video_id:
            return None

        # Check in-memory cache first (fast, prevents race condition duplicates)
        with self._memory_lock:
            if video_id in self._memory_cache:
                # Move to end (most recently used)
                entry = self._memory_cache.pop(video_id)
                self._memory_cache[video_id] = entry
                return entry

        # Check SQLite cache
        with self._lock:
            conn = self._get_connection()
            cursor = conn.execute(
                f"""
                SELECT metadata, similarity, version_type
                FROM itunes_cache
                WHERE video_id = ?
                AND created_at > datetime('now', '-{self.ttl_days} days')
            """,
                (video_id,),
            )
            row = cursor.fetchone()

            if row:
                # Update accessed_at for LRU tracking
                conn.execute(
                    """
                    UPDATE itunes_cache
                    SET accessed_at = CURRENT_TIMESTAMP
                    WHERE video_id = ?
                """,
                    (video_id,),
                )
                conn.commit()

                metadata = json.loads(row[0])
                entry = CacheEntry(metadata=metadata, similarity=row[1], version_type=row[2])

                # Also populate in-memory cache
                with self._memory_lock:
                    self._memory_cache[video_id] = entry
                    # Evict oldest if over limit
                    while len(self._memory_cache) > self.MAX_MEMORY_ENTRIES:
                        self._memory_cache.popitem(last=False)

                return entry

            return None

    def set(
        self,
        video_id: str,
        youtube_title: str,
        metadata: dict,
        similarity: float,
        version_type: str | None,
    ) -> None:
        """Store metadata in cache."""
        if not video_id:
            return

        # Create entry and store in memory first (so other threads see it immediately)
        entry = CacheEntry(metadata=metadata, similarity=similarity, version_type=version_type)
        with self._memory_lock:
            self._memory_cache[video_id] = entry
            # Evict oldest if over limit
            while len(self._memory_cache) > self.MAX_MEMORY_ENTRIES:
                self._memory_cache.popitem(last=False)

        # Store in SQLite for persistence
        with self._lock:
            conn = self._get_connection()
            conn.execute(
                """
                INSERT OR REPLACE INTO itunes_cache
                (video_id, youtube_title, metadata, similarity, version_type, created_at, accessed_at)
                VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            """,
                (video_id, youtube_title, json.dumps(metadata), similarity, version_type),
            )
            conn.commit()

            # Cleanup if needed (do this occasionally to avoid overhead)
            self._maybe_cleanup()

    def _maybe_cleanup(self) -> None:
        """Occasional cleanup of expired or LRU entries."""
        conn = self._get_connection()
        cursor = conn.execute("SELECT COUNT(*) FROM itunes_cache")
        count = cursor.fetchone()[0]

        if count > self.MAX_ENTRIES:
            # Remove oldest 10% of entries by LRU
            to_remove = count // 10
            conn.execute(
                """
                DELETE FROM itunes_cache
                WHERE video_id IN (
                    SELECT video_id FROM itunes_cache
                    ORDER BY accessed_at ASC
                    LIMIT ?
                )
            """,
                (to_remove,),
            )
            conn.commit()

    def clear(self) -> int:
        """Clear all cache entries. Returns number of entries deleted."""
        with self._lock:
            conn = self._get_connection()
            cursor = conn.execute("SELECT COUNT(*) FROM itunes_cache")
            count = cursor.fetchone()[0]
            conn.execute("DELETE FROM itunes_cache")
            conn.commit()
            return count

    def close(self) -> None:
        """Close the database connection for the current thread."""
        if hasattr(self._local, "conn") and self._local.conn is not None:
            self._local.conn.close()
            self._local.conn = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
