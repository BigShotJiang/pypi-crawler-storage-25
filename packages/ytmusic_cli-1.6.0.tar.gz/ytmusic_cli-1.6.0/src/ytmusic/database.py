"""Central SQLite database management for music library."""

import json
import os
import sqlite3
import threading
from datetime import datetime
from pathlib import Path
from typing import Optional

from ytmusic.constants import DEFAULT_CACHE_DIR

from ytmusic.models import (
    DownloadHistory,
    DownloadStatus,
    LocalFile,
    Playlist,
    Song,
    SyncState,
    YoutubeSource,
)

CURRENT_SCHEMA_VERSION = 1


class MusicDatabase:
    """Thread-safe SQLite database for the music library."""

    def __init__(self, db_path: Optional[Path] = None):
        """Initialize database connection.

        Args:
            db_path: Path to SQLite database file. Defaults to ~/.cache/ytmusic/library.db
        """
        if db_path is None:
            cache_dir = DEFAULT_CACHE_DIR
            cache_dir.mkdir(parents=True, exist_ok=True)
            db_path = cache_dir / "library.db"

        self.db_path = db_path
        self._lock = threading.RLock()
        self._local = threading.local()

        # Initialize database
        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        """Get a thread-local database connection."""
        if not hasattr(self._local, "conn") or self._local.conn is None:
            self._local.conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
            self._local.conn.execute("PRAGMA journal_mode=WAL;")
            self._local.conn.execute("PRAGMA synchronous=NORMAL;")
            self._local.conn.execute("PRAGMA foreign_keys=ON;")
            self._local.conn.row_factory = sqlite3.Row
        return self._local.conn

    def _init_db(self) -> None:
        """Initialize database schema with versioning support."""
        with self._lock:
            conn = self._get_connection()

            # Schema version table (must exist first)
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS schema_version (
                    version INTEGER PRIMARY KEY,
                    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """
            )

            # Get current version
            cursor = conn.execute("SELECT MAX(version) FROM schema_version")
            current_version = cursor.fetchone()[0] or 0

            # Apply migrations
            if current_version < 1:
                self._migrate_v1(conn)
                conn.execute(
                    "INSERT INTO schema_version (version) VALUES (?)", (1,)
                )

            conn.commit()

    def _migrate_v1(self, conn: sqlite3.Connection) -> None:
        """Initial schema creation."""
        # Playlists table
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS playlists (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                youtube_id TEXT UNIQUE NOT NULL,
                title TEXT NOT NULL,
                url TEXT NOT NULL,
                track_count INTEGER,
                last_synced_at TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """
        )

        # Songs table (canonical)
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS songs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                artist TEXT NOT NULL,
                album TEXT,
                genre TEXT,
                year INTEGER,
                track_number INTEGER,
                disc_number INTEGER,
                duration_seconds INTEGER,
                isrc TEXT
            )
        """
        )

        # Unique index for songs (handles Deluxe editions via ISRC/duration)
        conn.execute(
            """
            CREATE UNIQUE INDEX IF NOT EXISTS idx_songs_unique ON songs(
                artist, title, album,
                COALESCE(isrc, ''),
                COALESCE(duration_seconds, 0)
            )
        """
        )

        # YouTube sources table
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS youtube_sources (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                video_id TEXT UNIQUE NOT NULL,
                playlist_id INTEGER REFERENCES playlists(id) ON DELETE CASCADE,
                song_id INTEGER REFERENCES songs(id) ON DELETE CASCADE,
                youtube_title TEXT NOT NULL,
                version_type TEXT,
                position_in_playlist INTEGER,
                similarity_score REAL,
                metadata_source TEXT,
                added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                removed_from_playlist_at TIMESTAMP
            )
        """
        )

        # Index on video_id for fast lookups
        conn.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_yt_video_id ON youtube_sources(video_id)
        """
        )

        # Local files table
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS local_files (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                song_id INTEGER REFERENCES songs(id) ON DELETE CASCADE,
                file_path TEXT UNIQUE NOT NULL,
                file_name TEXT NOT NULL,
                file_size_bytes INTEGER,
                mtime INTEGER,
                format TEXT,
                bitrate TEXT,
                checksum TEXT,
                downloaded_at TIMESTAMP,
                modified_at TIMESTAMP,
                last_verified_at TIMESTAMP
            )
        """
        )

        # Index on song_id for fast lookups
        conn.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_local_files_song ON local_files(song_id)
        """
        )

        # Download history table
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS download_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                youtube_source_id INTEGER REFERENCES youtube_sources(id) ON DELETE CASCADE,
                local_file_id INTEGER REFERENCES local_files(id) ON DELETE SET NULL,
                status TEXT NOT NULL,
                error_message TEXT,
                downloaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                attempt_number INTEGER DEFAULT 1
            )
        """
        )

        # Sync state table
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS sync_state (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                playlist_id INTEGER REFERENCES playlists(id) ON DELETE CASCADE,
                sync_type TEXT NOT NULL,
                started_at TIMESTAMP,
                completed_at TIMESTAMP,
                items_processed INTEGER DEFAULT 0,
                items_added INTEGER DEFAULT 0,
                items_removed INTEGER DEFAULT 0,
                items_failed INTEGER DEFAULT 0
            )
        """
        )

    # -------------------------------------------------------------------------
    # Playlist operations
    # -------------------------------------------------------------------------

    def get_or_create_playlist(
        self, youtube_id: str, title: str, url: str, track_count: Optional[int] = None
    ) -> Playlist:
        """Get existing playlist or create new one."""
        with self._lock:
            conn = self._get_connection()
            cursor = conn.execute(
                "SELECT * FROM playlists WHERE youtube_id = ?", (youtube_id,)
            )
            row = cursor.fetchone()

            if row:
                return self._row_to_playlist(row)

            # Create new playlist
            cursor = conn.execute(
                """
                INSERT INTO playlists (youtube_id, title, url, track_count)
                VALUES (?, ?, ?, ?)
            """,
                (youtube_id, title, url, track_count),
            )
            conn.commit()

            return Playlist(
                id=cursor.lastrowid,
                youtube_id=youtube_id,
                title=title,
                url=url,
                track_count=track_count,
                created_at=datetime.now(),
            )

    def update_playlist_sync_time(self, playlist_id: int) -> None:
        """Update last_synced_at timestamp for a playlist."""
        with self._lock:
            conn = self._get_connection()
            conn.execute(
                "UPDATE playlists SET last_synced_at = CURRENT_TIMESTAMP WHERE id = ?",
                (playlist_id,),
            )
            conn.commit()

    def get_playlist_by_youtube_id(self, youtube_id: str) -> Optional[Playlist]:
        """Get playlist by YouTube ID."""
        with self._lock:
            conn = self._get_connection()
            cursor = conn.execute(
                "SELECT * FROM playlists WHERE youtube_id = ?", (youtube_id,)
            )
            row = cursor.fetchone()
            return self._row_to_playlist(row) if row else None

    # -------------------------------------------------------------------------
    # Song operations
    # -------------------------------------------------------------------------

    def get_or_create_song(
        self,
        title: str,
        artist: str,
        album: Optional[str] = None,
        **kwargs,
    ) -> Song:
        """Get existing song or create new one (based on unique constraint)."""
        with self._lock:
            conn = self._get_connection()

            # Try to find existing song
            isrc = kwargs.get("isrc")
            duration = kwargs.get("duration_seconds")

            cursor = conn.execute(
                """
                SELECT * FROM songs
                WHERE artist = ? AND title = ? AND album = ?
                AND COALESCE(isrc, '') = ?
                AND COALESCE(duration_seconds, 0) = ?
            """,
                (
                    artist,
                    title,
                    album or "",
                    isrc or "",
                    duration or 0,
                ),
            )
            row = cursor.fetchone()

            if row:
                return self._row_to_song(row)

            # Create new song
            cursor = conn.execute(
                """
                INSERT INTO songs (title, artist, album, genre, year, 
                    track_number, disc_number, duration_seconds, isrc)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
                (
                    title,
                    artist,
                    album,
                    kwargs.get("genre"),
                    kwargs.get("year"),
                    kwargs.get("track_number"),
                    kwargs.get("disc_number"),
                    duration,
                    isrc,
                ),
            )
            conn.commit()

            return Song(
                id=cursor.lastrowid,
                title=title,
                artist=artist,
                album=album,
                created_at=datetime.now(),
                **kwargs,
            )

    def get_song_by_id(self, song_id: int) -> Optional[Song]:
        """Get song by ID."""
        with self._lock:
            conn = self._get_connection()
            cursor = conn.execute("SELECT * FROM songs WHERE id = ?", (song_id,))
            row = cursor.fetchone()
            return self._row_to_song(row) if row else None

    # -------------------------------------------------------------------------
    # YouTube source operations
    # -------------------------------------------------------------------------

    def get_or_create_youtube_source(
        self,
        video_id: str,
        playlist_id: int,
        song_id: int,
        youtube_title: str,
        version_type: Optional[str] = None,
        position: Optional[int] = None,
        similarity: float = 0.0,
        metadata_source: Optional[str] = None,
    ) -> YoutubeSource:
        """Get or create YouTube source entry."""
        with self._lock:
            conn = self._get_connection()

            # Check if exists
            cursor = conn.execute(
                "SELECT * FROM youtube_sources WHERE video_id = ?", (video_id,)
            )
            row = cursor.fetchone()

            if row:
                # Update position and mark as not removed
                conn.execute(
                    """
                    UPDATE youtube_sources 
                    SET position_in_playlist = ?,
                        removed_from_playlist_at = NULL,
                        playlist_id = ?
                    WHERE video_id = ?
                """,
                    (position, playlist_id, video_id),
                )
                conn.commit()
                return self._row_to_youtube_source(row)

            # Create new
            cursor = conn.execute(
                """
                INSERT INTO youtube_sources 
                (video_id, playlist_id, song_id, youtube_title, version_type,
                 position_in_playlist, similarity_score, metadata_source)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
                (
                    video_id,
                    playlist_id,
                    song_id,
                    youtube_title,
                    version_type,
                    position,
                    similarity,
                    metadata_source,
                ),
            )
            conn.commit()

            return YoutubeSource(
                id=cursor.lastrowid,
                video_id=video_id,
                playlist_id=playlist_id,
                song_id=song_id,
                youtube_title=youtube_title,
                version_type=version_type,
                position_in_playlist=position,
                similarity_score=similarity,
                metadata_source=metadata_source,
                added_at=datetime.now(),
            )

    def mark_youtube_source_removed(self, video_id: str) -> None:
        """Mark a YouTube source as removed from playlist."""
        with self._lock:
            conn = self._get_connection()
            conn.execute(
                """
                UPDATE youtube_sources 
                SET removed_from_playlist_at = CURRENT_TIMESTAMP
                WHERE video_id = ?
            """,
                (video_id,),
            )
            conn.commit()

    def get_youtube_sources_by_playlist(self, playlist_id: int) -> list[YoutubeSource]:
        """Get all active YouTube sources for a playlist."""
        with self._lock:
            conn = self._get_connection()
            cursor = conn.execute(
                """
                SELECT * FROM youtube_sources 
                WHERE playlist_id = ? AND removed_from_playlist_at IS NULL
                ORDER BY position_in_playlist
            """,
                (playlist_id,),
            )
            return [self._row_to_youtube_source(row) for row in cursor.fetchall()]

    # -------------------------------------------------------------------------
    # Local file operations
    # -------------------------------------------------------------------------

    def create_local_file(
        self,
        song_id: int,
        file_path: str,
        file_name: str,
        file_size: Optional[int] = None,
        mtime: Optional[int] = None,
        format: Optional[str] = None,
        bitrate: Optional[str] = None,
        checksum: Optional[str] = None,
    ) -> LocalFile:
        """Create a new local file record."""
        with self._lock:
            conn = self._get_connection()
            now = datetime.now()

            cursor = conn.execute(
                """
                INSERT INTO local_files 
                (song_id, file_path, file_name, file_size_bytes, mtime,
                 format, bitrate, checksum, downloaded_at, modified_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
                (
                    song_id,
                    file_path,
                    file_name,
                    file_size,
                    mtime,
                    format,
                    bitrate,
                    checksum,
                    now,
                    now,
                ),
            )
            conn.commit()

            return LocalFile(
                id=cursor.lastrowid,
                song_id=song_id,
                file_path=file_path,
                file_name=file_name,
                file_size_bytes=file_size,
                mtime=mtime,
                format=format,
                bitrate=bitrate,
                checksum=checksum,
                downloaded_at=now,
                modified_at=now,
            )

    def get_local_file_by_path(self, file_path: str) -> Optional[LocalFile]:
        """Get local file by path."""
        with self._lock:
            conn = self._get_connection()
            cursor = conn.execute(
                "SELECT * FROM local_files WHERE file_path = ?", (file_path,)
            )
            row = cursor.fetchone()
            return self._row_to_local_file(row) if row else None

    def get_local_files_by_song(self, song_id: int) -> list[LocalFile]:
        """Get all local files for a song."""
        with self._lock:
            conn = self._get_connection()
            cursor = conn.execute(
                "SELECT * FROM local_files WHERE song_id = ?", (song_id,)
            )
            return [self._row_to_local_file(row) for row in cursor.fetchall()]

    def update_local_file_metadata(
        self,
        file_id: int,
        file_size: Optional[int] = None,
        mtime: Optional[int] = None,
        checksum: Optional[str] = None,
    ) -> None:
        """Update local file metadata after rescan."""
        with self._lock:
            conn = self._get_connection()
            conn.execute(
                """
                UPDATE local_files 
                SET file_size_bytes = ?, mtime = ?, checksum = ?,
                    modified_at = CURRENT_TIMESTAMP,
                    last_verified_at = CURRENT_TIMESTAMP
                WHERE id = ?
            """,
                (file_size, mtime, checksum, file_id),
            )
            conn.commit()

    # -------------------------------------------------------------------------
    # Download history operations
    # -------------------------------------------------------------------------

    def record_download_attempt(
        self,
        youtube_source_id: int,
        local_file_id: Optional[int] = None,
        status: DownloadStatus = DownloadStatus.PENDING,
        error_message: Optional[str] = None,
        attempt_number: int = 1,
    ) -> DownloadHistory:
        """Record a download attempt in history."""
        with self._lock:
            conn = self._get_connection()
            now = datetime.now()

            cursor = conn.execute(
                """
                INSERT INTO download_history 
                (youtube_source_id, local_file_id, status, error_message, 
                 downloaded_at, attempt_number)
                VALUES (?, ?, ?, ?, ?, ?)
            """,
                (
                    youtube_source_id,
                    local_file_id,
                    status.value,
                    error_message,
                    now,
                    attempt_number,
                ),
            )
            conn.commit()

            return DownloadHistory(
                id=cursor.lastrowid,
                youtube_source_id=youtube_source_id,
                local_file_id=local_file_id,
                status=status,
                error_message=error_message,
                downloaded_at=now,
                attempt_number=attempt_number,
            )

    def get_download_history(
        self, youtube_source_id: int, limit: int = 10
    ) -> list[DownloadHistory]:
        """Get recent download history for a YouTube source."""
        with self._lock:
            conn = self._get_connection()
            cursor = conn.execute(
                """
                SELECT * FROM download_history 
                WHERE youtube_source_id = ?
                ORDER BY downloaded_at DESC
                LIMIT ?
            """,
                (youtube_source_id, limit),
            )
            return [self._row_to_download_history(row) for row in cursor.fetchall()]

    # -------------------------------------------------------------------------
    # Sync state operations
    # -------------------------------------------------------------------------

    def start_sync(self, playlist_id: int, sync_type: str) -> SyncState:
        """Start recording a sync operation."""
        with self._lock:
            conn = self._get_connection()
            now = datetime.now()

            cursor = conn.execute(
                """
                INSERT INTO sync_state 
                (playlist_id, sync_type, started_at)
                VALUES (?, ?, ?)
            """,
                (playlist_id, sync_type, now),
            )
            conn.commit()

            return SyncState(
                id=cursor.lastrowid,
                playlist_id=playlist_id,
                sync_type=sync_type,
                started_at=now,
            )

    def complete_sync(
        self,
        sync_id: int,
        processed: int = 0,
        added: int = 0,
        removed: int = 0,
        failed: int = 0,
    ) -> None:
        """Complete a sync operation with results."""
        with self._lock:
            conn = self._get_connection()
            conn.execute(
                """
                UPDATE sync_state 
                SET completed_at = CURRENT_TIMESTAMP,
                    items_processed = ?,
                    items_added = ?,
                    items_removed = ?,
                    items_failed = ?
                WHERE id = ?
            """,
                (processed, added, removed, failed, sync_id),
            )
            conn.commit()

    # -------------------------------------------------------------------------
    # Migration from old cache
    # -------------------------------------------------------------------------

    def migrate_from_old_cache(self, old_cache_path: Path) -> int:
        """Migrate data from old itunes_cache.db format.

        Returns number of entries migrated.
        """
        if not old_cache_path.exists():
            return 0

        migrated = 0
        try:
            old_conn = sqlite3.connect(str(old_cache_path))
            old_conn.row_factory = sqlite3.Row

            cursor = old_conn.execute(
                "SELECT video_id, youtube_title, metadata, similarity, version_type FROM itunes_cache"
            )

            with self._lock:
                conn = self._get_connection()

                for row in cursor.fetchall():
                    try:
                        metadata = json.loads(row["metadata"])

                        # Create or get song
                        song = self.get_or_create_song(
                            title=metadata.get("trackName", "Unknown"),
                            artist=metadata.get("artistName", "Unknown"),
                            album=metadata.get("collectionName"),
                            genre=metadata.get("primaryGenreName"),
                            year=metadata.get("releaseDate", "")[:4]
                            if metadata.get("releaseDate")
                            else None,
                            isrc=metadata.get("isrc"),
                        )

                        # Create YouTube source
                        self.get_or_create_youtube_source(
                            video_id=row["video_id"],
                            playlist_id=0,  # Will be updated when re-downloaded
                            song_id=song.id,
                            youtube_title=row["youtube_title"],
                            version_type=row["version_type"],
                            similarity=row["similarity"],
                            metadata_source="itunes",
                        )

                        migrated += 1
                    except Exception:
                        # Skip entries that fail to migrate
                        continue

                conn.commit()

            old_conn.close()

        except Exception:
            # Migration failed, continue with empty database
            pass

        return migrated

    # -------------------------------------------------------------------------
    # Row converters
    # -------------------------------------------------------------------------

    def _row_to_playlist(self, row: sqlite3.Row) -> Playlist:
        """Convert database row to Playlist object."""
        return Playlist(
            id=row["id"],
            youtube_id=row["youtube_id"],
            title=row["title"],
            url=row["url"],
            track_count=row["track_count"],
            last_synced_at=row["last_synced_at"],
            created_at=row["created_at"],
        )

    def _row_to_song(self, row: sqlite3.Row) -> Song:
        """Convert database row to Song object."""
        return Song(
            id=row["id"],
            title=row["title"],
            artist=row["artist"],
            album=row["album"],
            genre=row["genre"],
            year=row["year"],
            track_number=row["track_number"],
            disc_number=row["disc_number"],
            duration_seconds=row["duration_seconds"],
            isrc=row["isrc"],
        )

    def _row_to_youtube_source(self, row: sqlite3.Row) -> YoutubeSource:
        """Convert database row to YoutubeSource object."""
        return YoutubeSource(
            id=row["id"],
            video_id=row["video_id"],
            playlist_id=row["playlist_id"],
            song_id=row["song_id"],
            youtube_title=row["youtube_title"],
            version_type=row["version_type"],
            position_in_playlist=row["position_in_playlist"],
            similarity_score=row["similarity_score"],
            metadata_source=row["metadata_source"],
            added_at=row["added_at"],
            removed_from_playlist_at=row["removed_from_playlist_at"],
        )

    def _row_to_local_file(self, row: sqlite3.Row) -> LocalFile:
        """Convert database row to LocalFile object."""
        return LocalFile(
            id=row["id"],
            song_id=row["song_id"],
            file_path=row["file_path"],
            file_name=row["file_name"],
            file_size_bytes=row["file_size_bytes"],
            mtime=row["mtime"],
            format=row["format"],
            bitrate=row["bitrate"],
            checksum=row["checksum"],
            downloaded_at=row["downloaded_at"],
            modified_at=row["modified_at"],
            last_verified_at=row["last_verified_at"],
        )

    def _row_to_download_history(self, row: sqlite3.Row) -> DownloadHistory:
        """Convert database row to DownloadHistory object."""
        return DownloadHistory(
            id=row["id"],
            youtube_source_id=row["youtube_source_id"],
            local_file_id=row["local_file_id"],
            status=DownloadStatus(row["status"]),
            error_message=row["error_message"],
            downloaded_at=row["downloaded_at"],
            attempt_number=row["attempt_number"],
        )

    # -------------------------------------------------------------------------
    # Cleanup
    # -------------------------------------------------------------------------

    def close(self) -> None:
        """Close database connection for current thread."""
        if hasattr(self._local, "conn") and self._local.conn is not None:
            self._local.conn.close()
            self._local.conn = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
