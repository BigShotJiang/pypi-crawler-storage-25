"""Shared constants and configuration values across the project."""

from pathlib import Path

from rich.console import Console

AUDIO_EXTENSIONS = {".m4a", ".mp3", ".mp4", ".aac", ".ogg", ".flac", ".wav", ".wma"}

TAGABLE_EXTENSIONS = {".m4a", ".mp4", ".aac", ".mp3"}

DEFAULT_CACHE_DIR = Path.home() / ".cache" / "ytmusic"

DEFAULT_OUTPUT_DIR = "music_library"

DEFAULT_SIMILARITY_THRESHOLD = 0.5

DEFAULT_BITRATE = "192k"

DEFAULT_OUTPUT_FORMAT = "m4a"

DEFAULT_CACHE_TTL_DAYS = 30

DEFAULT_MAX_WORKERS = 8

CONVERSION_BITRATES = ["128k", "192k", "256k", "320k"]

console = Console()
