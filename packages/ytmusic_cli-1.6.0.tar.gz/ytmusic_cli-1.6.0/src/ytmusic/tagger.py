"""Audio metadata tag embedding for various formats."""

from typing import Any

from mutagen.id3 import APIC, TALB, TCON, TDRC, TIT2, TPE1
from mutagen.mp3 import MP3
from mutagen.mp4 import MP4, MP4Cover

from ytmusic.constants import console


def _detect_cover_format(cover_art: bytes) -> tuple[str, int] | tuple[None, None]:
    """Detect cover art format for correct embedding."""
    if cover_art.startswith(b"\xff\xd8"):
        return "image/jpeg", MP4Cover.FORMAT_JPEG
    if cover_art.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png", MP4Cover.FORMAT_PNG
    return None, None


def embed_metadata_m4a(file_path: str, metadata: dict[str, Any], cover_art: bytes | None = None):
    """Embed metadata into M4A/AAC files."""
    try:
        audio = MP4(file_path)

        if metadata.get("title"):
            audio["\xa9nam"] = metadata["title"]
        if metadata.get("artist"):
            audio["\xa9ART"] = metadata["artist"]
        if metadata.get("album"):
            audio["\xa9alb"] = metadata["album"]
        if metadata.get("year"):
            audio["\xa9day"] = metadata["year"]
        if metadata.get("genre"):
            audio["\xa9gen"] = metadata["genre"]
        if metadata.get("track_number"):
            audio["trkn"] = [(metadata["track_number"], 0)]

        if cover_art:
            _, mp4_format = _detect_cover_format(cover_art)
            if mp4_format is not None:
                audio["covr"] = [MP4Cover(cover_art, imageformat=mp4_format)]

        audio.save()
    except Exception as e:
        console.print(f"[yellow]⚠ Could not embed M4A metadata: {e}[/yellow]")


def embed_metadata_mp3(file_path: str, metadata: dict[str, Any], cover_art: bytes | None = None):
    """Embed metadata into MP3 files."""
    try:
        audio = MP3(file_path)

        if audio.tags is None:
            audio.add_tags()

        if metadata.get("title"):
            audio.tags["TIT2"] = TIT2(encoding=3, text=metadata["title"])
        if metadata.get("artist"):
            audio.tags["TPE1"] = TPE1(encoding=3, text=metadata["artist"])
        if metadata.get("album"):
            audio.tags["TALB"] = TALB(encoding=3, text=metadata["album"])
        if metadata.get("year"):
            audio.tags["TDRC"] = TDRC(encoding=3, text=metadata["year"])
        if metadata.get("genre"):
            audio.tags["TCON"] = TCON(encoding=3, text=metadata["genre"])

        if cover_art:
            mime, _ = _detect_cover_format(cover_art)
            audio.tags["APIC"] = APIC(
                encoding=3, mime=mime or "image/jpeg", type=3, desc="Cover", data=cover_art
            )

        audio.save()
    except Exception as e:
        console.print(f"[yellow]⚠ Could not embed MP3 metadata: {e}[/yellow]")


def embed_metadata(
    file_path: str, file_ext: str, metadata: dict[str, Any], cover_art: bytes | None = None
):
    """Embed metadata into audio file based on format."""
    ext_lower = file_ext.lower()
    if ext_lower in [".m4a", ".mp4", ".aac"]:
        embed_metadata_m4a(file_path, metadata, cover_art)
    elif ext_lower == ".mp3":
        embed_metadata_mp3(file_path, metadata, cover_art)
    else:
        console.print(f"[yellow]⚠ Unsupported format for metadata embedding: {file_ext}[/yellow]")
