"""Utilities for string manipulation and file operations."""

import re
from difflib import SequenceMatcher

# Unicode ranges for CJK characters only (not extended Latin)
CJK_RANGES = [
    (0x4E00, 0x9FFF),  # CJK Unified Ideographs
    (0x3040, 0x309F),  # Hiragana
    (0x30A0, 0x30FF),  # Katakana
    (0xFF00, 0xFFEF),  # Full-width ASCII
    (0x3000, 0x303F),  # CJK Punctuation
    (0xAC00, 0xD7AF),  # Hangul Syllables
    (0x1100, 0x11FF),  # Hangul Jamo
]

# Version keywords to extract (in priority order)
VERSION_KEYWORDS = [
    "remastered",
    "remaster",
    "acoustic",
    "unplugged",
    "piano",
    "stripped",
    "live",
    "concert",
    "tour",
    "session",
    "mtv unplugged",
    "remix",
    "mix",
    "reprise",
    "edit",
    "radio edit",
    "single edit",
]

# Promotional junk to strip (not versions)
PROMOTIONAL_KEYWORDS = [
    "official video",
    "official audio",
    "visualizer",
    "lyric video",
    "lyrics",
    "official",
    "hd",
    "4k",
    "1080p",
    "video",
]

# Deduplication priority (lower = better)
VERSION_PRIORITY = {
    None: 0,
    "": 0,
    "studio": 0,
    "remastered": 1,
    "remaster": 1,
    "acoustic": 2,
    "unplugged": 2,
    "piano": 2,
    "stripped": 2,
    "live": 3,
    "concert": 3,
    "tour": 3,
    "session": 3,
    "mtv unplugged": 3,
    "remix": 4,
    "mix": 4,
    "reprise": 4,
    "edit": 5,
    "radio edit": 5,
    "single edit": 5,
}


def sanitize_filename(filename: str) -> str:
    """Remove invalid characters from filename."""
    invalid_chars = '<>:"/\\|?*'
    for char in invalid_chars:
        filename = filename.replace(char, "")
    return filename.strip()


def calculate_similarity(a: str, b: str) -> float:
    """Calculate similarity ratio between two strings (0.0 to 1.0)."""
    if not a or not b:
        return 0.0
    return SequenceMatcher(None, a.lower(), b.lower()).ratio()


def strip_cjk_characters(text: str) -> str:
    """
    Remove only CJK characters while preserving extended Latin.
    Mötley Crüe → Mötley Crüe (unchanged)
    TWICE「Song」→ TWICE Song
    """
    if not text:
        return ""

    result = []
    for char in text:
        code = ord(char)
        is_cjk = any(start <= code <= end for start, end in CJK_RANGES)
        if not is_cjk:
            result.append(char)
    return "".join(result)


def _extract_feat_from_song(song: str) -> tuple[str, str | None]:
    """
    Extract (feat. Artist) or [feat. Artist] from song title.
    Returns: (clean_song, feat_artist or None)
    """
    # Pattern: (feat. Artist) or [feat. Artist] or (ft. Artist) etc.
    feat_pattern = r"[\(\[]\s*(?:feat\.?|ft\.?)\s+([^\)\]]+)[\)\]]"
    match = re.search(feat_pattern, song, re.IGNORECASE)
    if match:
        feat_artist = match.group(1).strip()
        # Remove the feat. part from song
        clean_song = re.sub(feat_pattern, "", song, flags=re.IGNORECASE).strip()
        # Clean up any double spaces
        clean_song = re.sub(r"\s+", " ", clean_song).strip()
        return clean_song, feat_artist
    return song, None


def _normalize_collaboration_markers(artist: str) -> str:
    """
    Normalize all collaboration markers to 'feat.' format.
    x, ×, &, with → feat.
    """
    # Normalize spacing around existing feat.
    artist = re.sub(r"\s+feat\.\s*", " feat. ", artist, flags=re.IGNORECASE)
    artist = re.sub(r"\s+ft\.\s*", " feat. ", artist, flags=re.IGNORECASE)

    # Replace other collaboration markers with feat.
    artist = re.sub(r"\s+x\s+", " feat. ", artist, flags=re.IGNORECASE)
    artist = re.sub(r"\s+×\s+", " feat. ", artist)
    artist = re.sub(r"\s+&\s+", " feat. ", artist)
    artist = re.sub(r"\s+with\s+", " feat. ", artist, flags=re.IGNORECASE)

    # Clean up multiple spaces
    artist = re.sub(r"\s+", " ", artist).strip()

    return artist


def extract_version_and_clean(title: str) -> tuple[str, str | None]:
    """
    Extract version suffix from both [] and () brackets, strip promotional junk.
    Returns: (clean_title, version_type or None)

    Strategy:
    1. Check [] brackets first for version keywords
    2. Then check () parentheses for version keywords
    3. Remaining () content → strip as promotional junk
    4. Take first match from priority list
    """
    if not title:
        return title, None

    version_found = None
    clean_title = title

    # Check [] brackets first (higher priority)
    square_pattern = r"\[([^\]]+)\]"
    square_matches = re.findall(square_pattern, title)
    for match in square_matches:
        match_lower = match.lower()
        for keyword in VERSION_KEYWORDS:
            if keyword in match_lower:
                version_found = keyword
                clean_title = clean_title.replace(f"[{match}]", "")
                break
        if version_found:
            break

    # Then check () parentheses
    if not version_found:
        paren_pattern = r"\(([^\)]+)\)"
        paren_matches = re.findall(paren_pattern, title)
        for match in paren_matches:
            match_lower = match.lower()
            for keyword in VERSION_KEYWORDS:
                if keyword in match_lower:
                    version_found = keyword
                    clean_title = clean_title.replace(f"({match})", "")
                    break
            if version_found:
                break

    # Strip promotional junk from remaining () content
    paren_pattern = r"\(([^\)]+)\)"
    paren_matches = re.findall(paren_pattern, clean_title)
    for match in paren_matches:
        match_lower = match.lower()
        is_promo = any(promo in match_lower for promo in PROMOTIONAL_KEYWORDS)
        if is_promo:
            clean_title = clean_title.replace(f"({match})", "")

    # Also strip [] that weren't version markers (likely junk)
    square_pattern = r"\[([^\]]+)\]"
    square_matches = re.findall(square_pattern, clean_title)
    for match in square_matches:
        clean_title = clean_title.replace(f"[{match}]", "")

    # Clean up
    clean_title = re.sub(r"\s+", " ", clean_title).strip()
    clean_title = clean_title.strip("-—:|• ")

    return clean_title, version_found


def parse_youtube_title(title: str) -> tuple[str | None, str, str | None]:
    """
    Parse YouTube title into (artist, song, version).

    Steps:
    1. Strip CJK characters (preserve extended Latin like Mötley Crüe)
    2. Extract artist-song using patterns (including auto-generated formats)
    3. Normalize collaborations (move feat. from song to artist, normalize x/&/with)
    4. Extract version suffix
    5. Strip promotional junk

    Returns: (artist or None, song, version or None)
    """
    if not title:
        return None, "", None

    # Step 1: Strip CJK characters
    title = strip_cjk_characters(title)

    # Step 2: Extract artist-song using expanded patterns
    artist, song = None, title

    patterns = [
        # Standard: Artist - Song
        r"^(.*?)\s*[-—:]\s*(.*?)(?:\s*$)",
        # Quoted: Artist "Song"
        r'^(.*?)\s+"(.*?)"',
        # Auto-generated: Song | Artist (YouTube Music format)
        r"^(.*?)\s*\|\s*(.*?)$",
        # Auto-generated: Song • Artist (bullet separator)
        r"^(.*?)\s*•\s*(.*?)$",
    ]

    for pattern in patterns:
        match = re.match(pattern, title.strip())
        if match:
            part1, part2 = match.group(1).strip(), match.group(2).strip()
            # For auto-generated formats (| and •), order is Song | Artist
            if "|" in pattern or "•" in pattern:
                song, artist = part1, part2
            else:
                artist, song = part1, part2
            break

    if not artist:
        # Couldn't parse, return title as song with no artist
        return None, title.strip(), None

    # Step 3: Extract feat. from song and normalize collaborations
    song, feat_artist = _extract_feat_from_song(song)
    if feat_artist:
        artist = f"{artist} feat. {feat_artist}"

    # Normalize all collaboration markers in artist
    artist = _normalize_collaboration_markers(artist)

    # Step 4: Extract version suffix
    song, version = extract_version_and_clean(song)

    # Final cleanup
    artist = artist.strip("-—:|• ") if artist else None
    song = song.strip("-—:|• ")

    return artist, song, version


def extract_song_info(title: str) -> tuple:
    """
    Extract artist and song title from YouTube video title.
    Common formats: "Artist - Song", "Artist — Song", "Artist: Song",
    "Song | Artist" (auto-generated), "Song • Artist" (auto-generated)

    Uses the enhanced parse_youtube_title internally but discards version info
    for backward compatibility.
    """
    artist, song, _ = parse_youtube_title(title)
    return artist, song


def format_filename_from_metadata(metadata: dict) -> str | None:
    """Generate filename from metadata (Artist - Song format)."""
    if metadata.get("artist") and metadata.get("title"):
        return f"{metadata['artist']} - {metadata['title']}"
    return None
