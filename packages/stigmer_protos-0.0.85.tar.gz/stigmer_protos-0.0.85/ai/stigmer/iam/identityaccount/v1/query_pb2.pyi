from ai.stigmer.commons.apiresource import rpc_service_options_pb2 as _rpc_service_options_pb2
from ai.stigmer.commons.apiresource import status_pb2 as _status_pb2
from ai.stigmer.commons.rpc import method_options_pb2 as _method_options_pb2
from ai.stigmer.iam.identityaccount.v1 import api_pb2 as _api_pb2
from ai.stigmer.iam.identityaccount.v1 import io_pb2 as _io_pb2
from google.protobuf import empty_pb2 as _empty_pb2
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor
