from _typeshed import Incomplete
from aip_agents.audio_interface.config import AudioSessionConfig as AudioSessionConfig, LiveKitConfig as LiveKitConfig
from aip_agents.audio_interface.errors import AudioConfigError as AudioConfigError, AudioSessionUnavailableError as AudioSessionUnavailableError
from aip_agents.utils.logger import get_logger as get_logger
from typing import Any

logger: Incomplete

class LiveKitRealtimeAudioSession:
    """Bridge class for provider=`livekit_realtime`."""
    def __init__(self, config: AudioSessionConfig) -> None:
        """Initialize the LiveKit realtime audio session wrapper.

        Args:
            config (AudioSessionConfig): Session configuration including provider and provider config.

        Returns:
            None: This initializer returns None.
        """
    async def start(self, aip_agent: Any, *, instructions: str) -> None:
        """Start gllm-inference LiveKitRealtimeSession in a background task.

        Note:
            This provider adapts the transport/session layer only. The `aip_agent`
            and `instructions` parameters are currently ignored by the underlying
            gllm-inference LiveKit realtime session API.
        """
    async def stop(self) -> None:
        """Stop background run task."""
    async def wait_closed(self) -> None:
        """Wait for session termination."""
