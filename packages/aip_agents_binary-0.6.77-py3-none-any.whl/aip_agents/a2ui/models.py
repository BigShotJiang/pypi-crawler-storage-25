"""A2UI data and action models.

These models represent the minimal runtime contract for A2UI validation in this
v0.8 standard-catalog slice.

Authors:
    Reinhart Linanda (reinhart.linanda@gdplabs.id)
"""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Any

from a2ui.schema.constants import VERSION_0_8
from pydantic import BaseModel, Field

try:  # pragma: no cover
    from pydantic import ConfigDict as _ConfigDict  # type: ignore
except Exception:  # pragma: no cover
    _ConfigDict = None


if _ConfigDict is not None:
    ModelConfig = _ConfigDict(extra="allow")  # type: ignore[assignment]
else:  # pragma: no cover

    class _PydanticCompatConfig:  # type: ignore[no-redef]
        extra = "allow"

    ModelConfig = _PydanticCompatConfig  # type: ignore[assignment]

STANDARD_SCHEMA_VERSION = VERSION_0_8


class A2UIContentMetadataStatus(StrEnum):
    """Status of the A2UI content metadata."""

    VALID = "valid"
    FALLBACK = "fallback"


class A2UIActionStatus(StrEnum):
    """Status of the A2UI action."""

    VALID = "valid"
    INVALID = "invalid"


class A2UIContext(BaseModel):
    """Agent-provided A2UI capability context."""

    enabled: bool = False
    schema_version: str = STANDARD_SCHEMA_VERSION
    allow_user_actions: bool = True
    fallback_to_text: bool = True

    model_config = ModelConfig


class A2UIContentMetadata(BaseModel):
    """Final-response metadata payload stored in ``metadata.a2ui_content``."""

    schema_version: str = STANDARD_SCHEMA_VERSION
    messages: list[dict[str, Any]]
    validation: dict[str, Any] | None = None

    model_config = ModelConfig

    @property
    def is_valid(self) -> bool:
        """Check if the content is valid."""
        return bool(self.validation and self.validation.get("status") == A2UIContentMetadataStatus.VALID)


class A2UIActionContext(BaseModel):
    """Normalized inbound `userAction` context."""

    name: str
    surface_id: str
    source_component_id: str
    timestamp: str
    context: dict[str, Any] | None = None

    model_config = ModelConfig

    @classmethod
    def from_normalized_payload(
        cls, name: str, surface_id: str, source_component_id: str, timestamp: str, context: Any
    ) -> A2UIActionContext:
        """Create an action context from a normalized payload."""
        if not isinstance(context, dict):
            context_dict: dict[str, Any] = {}
        else:
            context_dict = context

        if not timestamp:
            raise ValueError("timestamp is required")
        normalized_timestamp = _normalize_iso_timestamp(timestamp)

        return cls(
            name=name,
            surface_id=surface_id,
            source_component_id=source_component_id,
            timestamp=normalized_timestamp,
            context=context_dict,
        )


class A2UIActionValidationResult(BaseModel):
    """Result container for inbound action normalization."""

    status: A2UIActionStatus = A2UIActionStatus.VALID
    normalized_action: A2UIActionContext | None = None
    errors: list[str] = Field(default_factory=list)

    model_config = ModelConfig


def _normalize_iso_timestamp(value: str) -> str:
    """Convert incoming timestamp input into a stable ISO-8601 string."""
    try:
        normalized = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return normalized.isoformat()
    except Exception:
        raise ValueError("timestamp must be ISO-8601 parsable")


__all__ = [
    "A2UIContext",
    "A2UIContentMetadata",
    "A2UIActionContext",
    "A2UIActionValidationResult",
    "A2UIContentMetadataStatus",
    "A2UIActionStatus",
    "STANDARD_SCHEMA_VERSION",
    "_normalize_iso_timestamp",
]
