from a2ui.schema.constants import VERSION_0_8
from enum import StrEnum
from pydantic import BaseModel
from typing import Any

__all__ = ['A2UIContext', 'A2UIContentMetadata', 'A2UIActionContext', 'A2UIActionValidationResult', 'A2UIContentMetadataStatus', 'A2UIActionStatus', 'STANDARD_SCHEMA_VERSION', '_normalize_iso_timestamp']

class _PydanticCompatConfig:
    extra: str
STANDARD_SCHEMA_VERSION = VERSION_0_8

class A2UIContentMetadataStatus(StrEnum):
    """Status of the A2UI content metadata."""
    VALID: str
    FALLBACK: str

class A2UIActionStatus(StrEnum):
    """Status of the A2UI action."""
    VALID: str
    INVALID: str

class A2UIContext(BaseModel):
    """Agent-provided A2UI capability context."""
    enabled: bool
    schema_version: str
    allow_user_actions: bool
    fallback_to_text: bool
    model_config = ModelConfig

class A2UIContentMetadata(BaseModel):
    """Final-response metadata payload stored in ``metadata.a2ui_content``."""
    schema_version: str
    messages: list[dict[str, Any]]
    validation: dict[str, Any] | None
    model_config = ModelConfig
    @property
    def is_valid(self) -> bool:
        """Check if the content is valid."""

class A2UIActionContext(BaseModel):
    """Normalized inbound `userAction` context."""
    name: str
    surface_id: str
    source_component_id: str
    timestamp: str
    context: dict[str, Any] | None
    model_config = ModelConfig
    @classmethod
    def from_normalized_payload(cls, name: str, surface_id: str, source_component_id: str, timestamp: str, context: Any) -> A2UIActionContext:
        """Create an action context from a normalized payload."""

class A2UIActionValidationResult(BaseModel):
    """Result container for inbound action normalization."""
    status: A2UIActionStatus
    normalized_action: A2UIActionContext | None
    errors: list[str]
    model_config = ModelConfig

def _normalize_iso_timestamp(value: str) -> str:
    """Convert incoming timestamp input into a stable ISO-8601 string."""
