"""A2UI package for aip-agents.

This package hosts protocol models and middleware used to support
agent-driven UI payloads in the v0.8 standard-catalog slice.

Authors:
    Reinhart Linanda (reinhart.linanda@gdplabs.id)
"""

from __future__ import annotations

from aip_agents.a2ui.middleware import A2UIMiddleware
from aip_agents.a2ui.models import (
    A2UIActionContext,
    A2UIActionValidationResult,
    A2UIContentMetadata,
    A2UIContext,
)

__all__ = [
    "A2UIMiddleware",
    "A2UIActionContext",
    "A2UIActionValidationResult",
    "A2UIContentMetadata",
    "A2UIContext",
]
