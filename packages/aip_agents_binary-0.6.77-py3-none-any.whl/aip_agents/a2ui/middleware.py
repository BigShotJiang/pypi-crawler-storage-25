"""A2UI middleware for protocol-driven prompt enrichment and validation.

Authors:
    Reinhart Linanda (reinhart.linanda@gdplabs.id)
"""

from __future__ import annotations

from typing import Any

import jsonschema
from a2ui.basic_catalog.provider import BasicCatalog
from a2ui.parser.parser import parse_response
from a2ui.schema.common_modifiers import remove_strict_validation
from a2ui.schema.constants import A2UI_CLOSE_TAG, A2UI_OPEN_TAG
from a2ui.schema.manager import A2uiSchemaManager

from aip_agents.a2ui.models import (
    STANDARD_SCHEMA_VERSION,
    A2UIActionContext,
    A2UIActionStatus,
    A2UIActionValidationResult,
    A2UIContentMetadata,
    A2UIContentMetadataStatus,
    A2UIContext,
    _normalize_iso_timestamp,
)
from aip_agents.middleware.base import AgentMiddleware, ModelRequest
from aip_agents.utils.logger import get_logger

logger = get_logger(__name__)

_REQUIRED_ACTION_FIELDS = ("name", "surfaceId", "sourceComponentId", "timestamp", "context")


class A2UIMiddleware(AgentMiddleware):
    """Middleware for A2UI protocol responsibilities.

    The current implementation stores minimal state required by callers and
    provides protocol-defined hooks with default no-op behavior.
    """

    tools: list[Any] = []
    system_prompt_additions: str | None = None

    def __init__(self, context: A2UIContext | None = None) -> None:
        """Create a middleware instance.

        Args:
            context: Optional A2UI context resolved at agent creation.
        """
        self.context = context or A2UIContext()
        self.schema_version = self.context.schema_version or STANDARD_SCHEMA_VERSION
        self.schema_manager = A2uiSchemaManager(
            version=self.schema_version,
            catalogs=[BasicCatalog.get_config(version=self.schema_version)],
            schema_modifiers=[remove_strict_validation],
        )

    def before_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """No-op hook prior to model call in first implementation pass."""
        return {}

    async def abefore_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Asynchronous mirror of before_model."""
        return self.before_model(state)

    def modify_model_request(self, request: ModelRequest, state: dict[str, Any]) -> ModelRequest:
        """Append A2UI prompt instructions when enabled."""
        if not self.context.enabled:
            return request

        prompt = request.get("system_prompt") or ""
        prompt = prompt.rstrip("\n")
        prompt = self.schema_manager.generate_system_prompt(role_description=prompt, include_schema=True)
        request["system_prompt"] = prompt
        return request

    def after_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """No-op post-model hook."""
        return {}

    async def aafter_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Asynchronous mirror of after_model."""
        return self.after_model(state)

    def on_final_response(self, content: str, context: dict[str, Any]) -> None:
        """Capture final response and attach validated A2UI metadata."""
        if not self.context.enabled:
            return

        a2ui_content, sanitized_content = self._extract_a2ui_content(content)

        context["a2ui_content"] = a2ui_content.model_dump(exclude_none=True)
        final_state = context.get("final_state")
        if isinstance(final_state, dict):
            final_state["a2ui_content"] = a2ui_content.model_dump(exclude_none=True)

        context["final_content"] = sanitized_content
        event = context.get("event")
        if isinstance(event, dict) and "content" in event:
            event["content"] = sanitized_content

    def _extract_a2ui_content(self, content: str) -> tuple[A2UIContentMetadata, str]:
        """Extract validated A2UI metadata and sanitized final text."""
        if not content or not isinstance(content, str):
            return (
                A2UIContentMetadata(
                    schema_version=self.schema_version,
                    messages=[],
                    validation=self._build_validation_block(
                        status=A2UIContentMetadataStatus.FALLBACK,
                        fallback_reason="missing_content",
                        errors=["missing_content"],
                    ),
                ),
                "",
            )

        if not self._contains_a2ui_payload(content):
            return (
                A2UIContentMetadata(
                    schema_version=self.schema_version,
                    messages=[],
                    validation=self._build_validation_block(
                        status=A2UIContentMetadataStatus.FALLBACK,
                        fallback_reason="missing_content",
                        errors=["missing_content"],
                    ),
                ),
                content,
            )

        messages: list[dict[str, Any]] = []
        response_text_parts: list[str] = []
        selected_catalog = self.schema_manager.get_selected_catalog()

        try:
            candidate = content.strip()
            response_parts = parse_response(candidate)

            for part in response_parts:
                if part.text:
                    response_text_parts.append(part.text)

                if not part.a2ui_json:
                    continue

                parsed_json_data = part.a2ui_json
                selected_catalog.validator.validate(parsed_json_data)
                messages.extend(parsed_json_data)

        except (ValueError, jsonschema.exceptions.ValidationError) as e:
            return (
                A2UIContentMetadata(
                    schema_version=self.schema_version,
                    messages=[],
                    validation=self._build_validation_block(
                        status=A2UIContentMetadataStatus.FALLBACK,
                        fallback_reason="invalid_content",
                        errors=[str(e)],
                    ),
                ),
                content,
            )

        return (
            A2UIContentMetadata(
                schema_version=self.schema_version,
                messages=messages,
                validation=self._build_validation_block(
                    status=A2UIContentMetadataStatus.VALID,
                ),
            ),
            "\n".join(response_text_parts),
        )

    def _contains_a2ui_payload(self, content: str) -> bool:
        """Return True when the response contains an A2UI payload marker."""
        return A2UI_OPEN_TAG in content and A2UI_CLOSE_TAG in content

    def _build_validation_block(
        self, status: str, fallback_reason: str | None = None, errors: list[str] | None = None
    ) -> dict[str, Any]:
        """Build normalized validation result object."""
        block: dict[str, Any] = {"status": status}
        if errors is not None:
            block["errors"] = errors
        if fallback_reason is not None and status == A2UIContentMetadataStatus.FALLBACK:
            block["fallback_reason"] = fallback_reason
        return block

    def normalize_user_action(self, action: dict[str, Any]) -> A2UIActionValidationResult:
        """Normalize raw renderer action payloads to canonical structure."""
        if not self.context.enabled or not self.context.allow_user_actions:
            return A2UIActionValidationResult(status=A2UIActionStatus.INVALID, errors=["user_actions_disabled"])

        if not isinstance(action, dict):
            return A2UIActionValidationResult(status=A2UIActionStatus.INVALID, errors=["action_payload_must_be_object"])

        wrapped_action = action.get("userAction")
        if wrapped_action is not None and not isinstance(wrapped_action, dict):
            return A2UIActionValidationResult(status=A2UIActionStatus.INVALID, errors=["missing_userAction_payload"])
        raw_action = wrapped_action if isinstance(wrapped_action, dict) else action

        missing_fields = []
        for field in _REQUIRED_ACTION_FIELDS:
            if field not in raw_action:
                missing_fields.append(f"missing_{field}")
        if missing_fields:
            return A2UIActionValidationResult(status=A2UIActionStatus.INVALID, errors=missing_fields)

        if not isinstance(raw_action["context"], dict):
            return A2UIActionValidationResult(status=A2UIActionStatus.INVALID, errors=["context_must_be_object"])

        try:
            normalized_action = A2UIActionContext.from_normalized_payload(
                name=str(raw_action["name"]),
                surface_id=str(raw_action["surfaceId"]),
                source_component_id=str(raw_action["sourceComponentId"]),
                timestamp=_normalize_iso_timestamp(str(raw_action["timestamp"])),
                context=raw_action["context"],
            )
            return A2UIActionValidationResult(status=A2UIActionStatus.VALID, normalized_action=normalized_action)
        except ValueError as exc:
            return A2UIActionValidationResult(status=A2UIActionStatus.INVALID, errors=[str(exc)])
