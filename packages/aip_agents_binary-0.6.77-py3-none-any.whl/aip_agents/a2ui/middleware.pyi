from _typeshed import Incomplete
from aip_agents.a2ui.models import A2UIActionContext as A2UIActionContext, A2UIActionStatus as A2UIActionStatus, A2UIActionValidationResult as A2UIActionValidationResult, A2UIContentMetadata as A2UIContentMetadata, A2UIContentMetadataStatus as A2UIContentMetadataStatus, A2UIContext as A2UIContext, STANDARD_SCHEMA_VERSION as STANDARD_SCHEMA_VERSION
from aip_agents.middleware.base import AgentMiddleware as AgentMiddleware, ModelRequest as ModelRequest
from aip_agents.utils.logger import get_logger as get_logger
from typing import Any

logger: Incomplete

class A2UIMiddleware(AgentMiddleware):
    """Middleware for A2UI protocol responsibilities.

    The current implementation stores minimal state required by callers and
    provides protocol-defined hooks with default no-op behavior.
    """
    tools: list[Any]
    system_prompt_additions: str | None
    context: Incomplete
    schema_version: Incomplete
    schema_manager: Incomplete
    def __init__(self, context: A2UIContext | None = None) -> None:
        """Create a middleware instance.

        Args:
            context: Optional A2UI context resolved at agent creation.
        """
    def before_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """No-op hook prior to model call in first implementation pass."""
    async def abefore_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Asynchronous mirror of before_model."""
    def modify_model_request(self, request: ModelRequest, state: dict[str, Any]) -> ModelRequest:
        """Append A2UI prompt instructions when enabled."""
    def after_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """No-op post-model hook."""
    async def aafter_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Asynchronous mirror of after_model."""
    def on_final_response(self, content: str, context: dict[str, Any]) -> None:
        """Capture final response and attach validated A2UI metadata."""
    def normalize_user_action(self, action: dict[str, Any]) -> A2UIActionValidationResult:
        """Normalize raw renderer action payloads to canonical structure."""
