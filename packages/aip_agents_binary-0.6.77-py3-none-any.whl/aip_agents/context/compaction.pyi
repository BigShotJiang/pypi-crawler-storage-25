from aip_agents.context.utils import redact_sensitive as redact_sensitive
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Protocol

REFERENCE_ONLY_PREFIX: str
SUMMARY_SECTIONS: tuple[str, ...]

@dataclass(frozen=True)
class CompactionSummary:
    """Structured compaction summary metadata and body.

    Attributes:
        summary_id: Stable identifier for this generated reference summary.
        body: Reference-only summary text safe to insert into context.
        source_message_range: Inclusive source message indexes summarized by this body.
        previous_summary_id: Identifier of the summary this one supersedes, if any.
        focus_topic: Optional user-requested focus topic preserved in the summary.
        prompt_tokens_before: Estimated prompt tokens before compaction.
        prompt_tokens_after: Estimated prompt tokens after compaction.
        offloaded_ref_ids: Payload reference identifiers included in the summary scope.
        redaction_applied: Whether input or generated text required redaction.
        created_at: UTC timestamp when the summary was created.
    """
    summary_id: str
    body: str
    source_message_range: tuple[int, int]
    previous_summary_id: str | None
    focus_topic: str | None
    prompt_tokens_before: int
    prompt_tokens_after: int
    offloaded_ref_ids: tuple[str, ...]
    redaction_applied: bool
    created_at: datetime

@dataclass(frozen=True)
class CompressionResult:
    """Outcome of a compaction summary generation attempt.

    Attributes:
        summary: Structured summary produced by the compressor.
        used_fallback: Whether deterministic fallback summarization was used.
        error: Safe error text when auxiliary summary generation failed.
    """
    summary: CompactionSummary
    used_fallback: bool
    error: str | None = ...

class SummarizerClient(Protocol):
    """Minimal abstraction for auxiliary summary generation."""
    def summarize(self, prompt: str) -> str:
        """Return summary text from a redacted prompt input."""

class ContextCompressor:
    """Generate structured reference-only summaries from prior conversation turns."""
    def __init__(self, summarizer: SummarizerClient | None = None) -> None:
        """Initialize compressor with optional auxiliary summarizer client."""
    def compress(self, messages: Sequence[Any], *, previous_summary: CompactionSummary | None = None, focus_topic: str | None = None, offloaded_ref_ids: Sequence[str] = (), source_message_range: tuple[int, int] | None = None, prompt_tokens_before: int = 0, prompt_tokens_after: int = 0) -> CompressionResult:
        """Create a structured summary with safe fallback behavior.

        Usage::

            from aip_agents.context.compaction import ContextCompressor

            compressor = ContextCompressor()  # uses fallback summarization
            result = compressor.compress(messages)
            # result.summary.body contains the structured summary
            # result.used_fallback is True when no external summarizer was set
        """
