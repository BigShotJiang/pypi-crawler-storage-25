"""State contracts for context compaction decisions.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal


@dataclass(frozen=True)
class SummaryInsertionPoint:
    """Index metadata describing where a reference summary can be inserted.

    Attributes:
        protected_head_indexes: Initial message indexes preserved unchanged.
        protected_tail_start_index: First recent-tail message index preserved unchanged.
        replace_start_index: First message index replaced by the reference summary.
        replace_end_index: Last message index replaced by the reference summary.
    """

    protected_head_indexes: tuple[int, ...]
    protected_tail_start_index: int
    replace_start_index: int
    replace_end_index: int


@dataclass(frozen=True)
class CompactionState:
    """Observed compaction metadata tracked outside mutable agent state.

    Attributes:
        compaction_count: Number of compaction attempts observed for the current scope.
        last_summary_status: Outcome of the latest summary attempt.
        offloaded_ref_count: Number of payload references produced by offloading.
        estimated_token_savings: Estimated token reduction from the latest compaction.
        last_reason: Stable reason code from the latest compaction decision.
        last_error_code: Safe error code for the latest failed compaction step.
    """

    compaction_count: int = 0
    last_summary_status: Literal["none", "succeeded", "failed", "skipped"] = "none"
    offloaded_ref_count: int = 0
    estimated_token_savings: int | None = None
    last_reason: str | None = None
    last_error_code: str | None = None
