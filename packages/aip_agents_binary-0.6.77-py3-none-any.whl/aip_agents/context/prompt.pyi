from dataclasses import dataclass

@dataclass(frozen=True)
class PromptBuildContext:
    """Typed context for deterministic system prompt assembly.

    The field order encodes the canonical layer order. Empty or None values are
    skipped during rendering.
    """
    base_instruction: str
    date_time_context: str | None = ...
    runtime_platform_hints: str | None = ...
    durable_memory_guidance: str | None = ...
    session_recall_guidance: str | None = ...
    project_context: str | None = ...
    compaction_summary: str | None = ...
    model_steering: str | None = ...
    middleware_prompts: tuple[str, ...] = ...

def build_system_prompt(context: PromptBuildContext) -> str:
    """Build a system prompt from ordered context layers.

    Args:
        context: Prompt context containing ordered optional layers.

    Returns:
        Combined system prompt with non-empty layers joined by double newlines.
    """
