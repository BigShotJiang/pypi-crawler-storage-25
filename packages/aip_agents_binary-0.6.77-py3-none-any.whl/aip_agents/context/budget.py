"""Context budget and compaction decision helpers.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any, Literal

from aip_agents.context.state import SummaryInsertionPoint

_CHARS_PER_TOKEN = 4
_BASE_TOKENS_PER_MESSAGE = 4
_IMAGE_PART_TOKEN_ESTIMATE = 256

CompactionReason = Literal[
    "below_threshold",
    "proactive_threshold",
    "fallback_threshold",
    "manual_focus",
    "provider_overflow",
    "anti_thrash_skip",
]


@dataclass(frozen=True)
class ContextBudgetConfig:
    """Configuration for context budget decisions.

    Attributes:
        threshold_ratio: Fraction of the model context that triggers proactive compaction.
        fallback_threshold_tokens: Absolute threshold when the model context window is unknown.
        min_tail_tokens: Minimum recent-token budget preserved after compaction.
        target_tail_ratio: Fraction of estimated prompt tokens preserved as recent tail.
        min_head_messages: Number of initial messages always preserved.
        anti_thrash_min_savings_ratio: Minimum useful savings before repeated compaction.
        max_retry_after_overflow: Runtime retry cap consumed by overflow handling.
    """

    threshold_ratio: float = 0.85
    fallback_threshold_tokens: int = 170_000
    min_tail_tokens: int = 6_000
    target_tail_ratio: float = 0.10
    min_head_messages: int = 2
    anti_thrash_min_savings_ratio: float = 0.10
    max_retry_after_overflow: int = 1


@dataclass(frozen=True)
class CompactionDecision:
    """Result of pure compaction decision-making.

    Attributes:
        should_compact: Whether the current input should enter the compaction path.
        reason: Stable reason code for logging, tests, and retry behavior.
        estimated_prompt_tokens: Estimated prompt size before compaction.
        model_context_tokens: Model context window used for thresholding, if known.
        threshold_tokens: Effective token threshold used by this decision.
        protected_head_indexes: Initial message indexes excluded from replacement.
        protected_tail_start_index: First recent-tail message index to preserve.
        focus_topic: Optional user-provided focus topic for manual compaction.
        summary_insertion_point: Replaceable range where a summary can be inserted.
    """

    should_compact: bool
    reason: CompactionReason
    estimated_prompt_tokens: int
    model_context_tokens: int | None
    threshold_tokens: int
    protected_head_indexes: tuple[int, ...]
    protected_tail_start_index: int
    focus_topic: str | None = None
    summary_insertion_point: SummaryInsertionPoint | None = None


def estimate_message_token_counts(messages: Sequence[Any]) -> list[int]:
    """Estimate token counts per message with conservative heuristics."""
    return [_estimate_single_message_tokens(message) for message in messages]


def estimate_prompt_tokens(messages: Sequence[Any]) -> int:
    """Estimate total prompt tokens from message sequence."""
    return sum(estimate_message_token_counts(messages))


def compute_protected_regions(
    token_counts: Sequence[int],
    config: ContextBudgetConfig | None = None,
) -> tuple[tuple[int, ...], int]:
    """Compute protected head indexes and token-budget tail start index."""
    cfg = config or ContextBudgetConfig()
    if not token_counts:
        return (), 0

    message_count = len(token_counts)
    head_count = min(cfg.min_head_messages, message_count)
    protected_head_indexes = tuple(range(head_count))

    total_tokens = sum(token_counts)
    tail_target_tokens = max(cfg.min_tail_tokens, int(total_tokens * cfg.target_tail_ratio))

    running = 0
    tail_start = message_count
    for index in range(message_count - 1, -1, -1):
        running += token_counts[index]
        tail_start = index
        if running >= tail_target_tokens:
            break

    if tail_start < head_count:
        tail_start = head_count

    return protected_head_indexes, tail_start


def classify_provider_overflow_error(error: Exception | str) -> bool:
    """Return whether an error appears to be a context-window overflow."""
    text = str(error).lower()
    patterns = (
        "context window",
        "maximum context length",
        "too many tokens",
        "prompt is too long",
        "context_length_exceeded",
        "input length exceeds",
        "token limit",
        "context limit",
    )
    return any(pattern in text for pattern in patterns)


def decide_compaction(
    messages: Sequence[Any],
    *,
    config: ContextBudgetConfig | None = None,
    model_context_tokens: int | None = None,
    focus_topic: str | None = None,
    provider_overflow: bool = False,
    recent_savings_ratio: float | None = None,
) -> CompactionDecision:
    """Return a pure compaction decision from budget inputs.

    This function does not call models and does not mutate runtime state.
    """
    cfg = config or ContextBudgetConfig()
    token_counts = estimate_message_token_counts(messages)
    estimated_tokens = sum(token_counts)
    threshold_tokens = (
        max(1, int(model_context_tokens * cfg.threshold_ratio))
        if model_context_tokens is not None
        else cfg.fallback_threshold_tokens
    )

    protected_head_indexes, protected_tail_start_index = compute_protected_regions(token_counts, config=cfg)
    replace_start_index = len(protected_head_indexes)
    replace_end_index = protected_tail_start_index - 1
    insertion_point = None
    if replace_start_index <= replace_end_index:
        insertion_point = SummaryInsertionPoint(
            protected_head_indexes=protected_head_indexes,
            protected_tail_start_index=protected_tail_start_index,
            replace_start_index=replace_start_index,
            replace_end_index=replace_end_index,
        )

    reason: CompactionReason
    should_compact = False

    normalized_focus_topic = (focus_topic or "").strip() or None
    if normalized_focus_topic is not None:
        reason = "manual_focus"
        should_compact = True
    elif provider_overflow:
        reason = "provider_overflow"
        should_compact = True
    elif estimated_tokens > threshold_tokens:
        reason = "proactive_threshold" if model_context_tokens is not None else "fallback_threshold"
        should_compact = True
    elif recent_savings_ratio is not None and recent_savings_ratio < cfg.anti_thrash_min_savings_ratio:
        reason = "anti_thrash_skip"
        should_compact = False
    else:
        reason = "below_threshold"

    return CompactionDecision(
        should_compact=should_compact,
        reason=reason,
        estimated_prompt_tokens=estimated_tokens,
        model_context_tokens=model_context_tokens,
        threshold_tokens=threshold_tokens,
        protected_head_indexes=protected_head_indexes,
        protected_tail_start_index=protected_tail_start_index,
        focus_topic=normalized_focus_topic,
        summary_insertion_point=insertion_point,
    )


def _estimate_single_message_tokens(message: Any) -> int:
    if isinstance(message, str):
        content = message
    elif isinstance(message, dict) and "content" in message:
        content = message["content"]
    else:
        content = getattr(message, "content", message)

    if isinstance(content, list):
        return _BASE_TOKENS_PER_MESSAGE + sum(_estimate_content_part_tokens(part) for part in content)

    text = str(content or "")
    return _BASE_TOKENS_PER_MESSAGE + _estimate_text_tokens(text, _CHARS_PER_TOKEN)


def _estimate_content_part_tokens(part: Any) -> int:
    if isinstance(part, dict):
        part_type = str(part.get("type", "")).lower()
        if "image" in part_type:
            return _IMAGE_PART_TOKEN_ESTIMATE

        for key in ("text", "content"):
            value = part.get(key)
            if isinstance(value, str):
                return _estimate_text_tokens(value, _CHARS_PER_TOKEN)

        return _estimate_text_tokens(str(part), _CHARS_PER_TOKEN)

    return _estimate_text_tokens(str(part), _CHARS_PER_TOKEN)


def _estimate_text_tokens(text: str, chars_per_token: int) -> int:
    # deferred to #809: Use shared aip_agents.context.utils.estimate_tokens
    if not text:
        return 0
    safe_chars_per_token = max(chars_per_token, 1)
    return max(1, (len(text) + safe_chars_per_token - 1) // safe_chars_per_token)
