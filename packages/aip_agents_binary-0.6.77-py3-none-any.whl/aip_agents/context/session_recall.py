"""Session recall seam contracts.

This module defines lightweight contracts for short-lived session/task recall
without coupling them to durable memory persistence.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class SessionRecallSnapshot:
    """Snapshot of short-lived task/session state.

    This snapshot is intentionally scoped to active work context and should not
    be treated as durable memory by default.
    """

    active_task: str | None = None
    recent_decisions: tuple[str, ...] = field(default_factory=tuple)
    changed_files: tuple[str, ...] = field(default_factory=tuple)
    blockers: tuple[str, ...] = field(default_factory=tuple)
    handoff_summary: str | None = None
    stale: bool = False


def build_session_recall_guidance(snapshot: SessionRecallSnapshot | None) -> str | None:
    """Render session recall guidance text from a snapshot.

    Args:
        snapshot: Optional session recall snapshot.

    Returns:
        A guidance block describing short-lived task/session context, or None
        when no snapshot is available.
    """
    if snapshot is None:
        return None

    active_task = snapshot.active_task.strip() if snapshot.active_task else None
    handoff_summary = snapshot.handoff_summary.strip() if snapshot.handoff_summary else None
    recent_decisions = tuple(d.strip() for d in snapshot.recent_decisions if d.strip())
    changed_files = tuple(f.strip() for f in snapshot.changed_files if f.strip())
    blockers = tuple(b.strip() for b in snapshot.blockers if b.strip())

    lines = ["Session Recall Snapshot:"]
    if active_task:
        lines.append(f"- Active task: {active_task}")
    if recent_decisions:
        lines.append("- Recent decisions:")
        lines.extend(f"  - {decision}" for decision in recent_decisions)
    if changed_files:
        lines.append("- Changed files:")
        lines.extend(f"  - {path}" for path in changed_files)
    if blockers:
        lines.append("- Blockers:")
        lines.extend(f"  - {blocker}" for blocker in blockers)
    if handoff_summary:
        lines.append(f"- Handoff summary: {handoff_summary}")
    if snapshot.stale:
        lines.append("- Recall freshness: stale")

    if len(lines) == 1:
        return None
    return "\n".join(lines)
