from _typeshed import Incomplete
from aip_agents.context.state import SummaryInsertionPoint as SummaryInsertionPoint
from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any

CompactionReason: Incomplete

@dataclass(frozen=True)
class ContextBudgetConfig:
    """Configuration for context budget decisions.

    Attributes:
        threshold_ratio: Fraction of the model context that triggers proactive compaction.
        fallback_threshold_tokens: Absolute threshold when the model context window is unknown.
        min_tail_tokens: Minimum recent-token budget preserved after compaction.
        target_tail_ratio: Fraction of estimated prompt tokens preserved as recent tail.
        min_head_messages: Number of initial messages always preserved.
        anti_thrash_min_savings_ratio: Minimum useful savings before repeated compaction.
        max_retry_after_overflow: Runtime retry cap consumed by overflow handling.
    """
    threshold_ratio: float = ...
    fallback_threshold_tokens: int = ...
    min_tail_tokens: int = ...
    target_tail_ratio: float = ...
    min_head_messages: int = ...
    anti_thrash_min_savings_ratio: float = ...
    max_retry_after_overflow: int = ...

@dataclass(frozen=True)
class CompactionDecision:
    """Result of pure compaction decision-making.

    Attributes:
        should_compact: Whether the current input should enter the compaction path.
        reason: Stable reason code for logging, tests, and retry behavior.
        estimated_prompt_tokens: Estimated prompt size before compaction.
        model_context_tokens: Model context window used for thresholding, if known.
        threshold_tokens: Effective token threshold used by this decision.
        protected_head_indexes: Initial message indexes excluded from replacement.
        protected_tail_start_index: First recent-tail message index to preserve.
        focus_topic: Optional user-provided focus topic for manual compaction.
        summary_insertion_point: Replaceable range where a summary can be inserted.
    """
    should_compact: bool
    reason: CompactionReason
    estimated_prompt_tokens: int
    model_context_tokens: int | None
    threshold_tokens: int
    protected_head_indexes: tuple[int, ...]
    protected_tail_start_index: int
    focus_topic: str | None = ...
    summary_insertion_point: SummaryInsertionPoint | None = ...

def estimate_message_token_counts(messages: Sequence[Any]) -> list[int]:
    """Estimate token counts per message with conservative heuristics."""
def estimate_prompt_tokens(messages: Sequence[Any]) -> int:
    """Estimate total prompt tokens from message sequence."""
def compute_protected_regions(token_counts: Sequence[int], config: ContextBudgetConfig | None = None) -> tuple[tuple[int, ...], int]:
    """Compute protected head indexes and token-budget tail start index."""
def classify_provider_overflow_error(error: Exception | str) -> bool:
    """Return whether an error appears to be a context-window overflow."""
def decide_compaction(messages: Sequence[Any], *, config: ContextBudgetConfig | None = None, model_context_tokens: int | None = None, focus_topic: str | None = None, provider_overflow: bool = False, recent_savings_ratio: float | None = None) -> CompactionDecision:
    """Return a pure compaction decision from budget inputs.

    This function does not call models and does not mutate runtime state.
    """
