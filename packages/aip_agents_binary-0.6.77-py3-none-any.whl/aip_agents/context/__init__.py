"""Context preparation, compaction, and token budget utilities for agents.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""
