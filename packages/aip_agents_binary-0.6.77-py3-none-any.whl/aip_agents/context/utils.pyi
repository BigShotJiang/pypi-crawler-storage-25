def estimate_tokens(text: str, chars_per_token: int = 4) -> int:
    """Estimate token count for a text string."""
def redact_sensitive(text: str) -> tuple[str, bool]:
    """Redact sensitive content from text."""
def safe_preview(content: str, *, max_chars: int) -> tuple[str, bool]:
    """Create a redacted preview of content."""
