from aip_agents.context.budget import CompactionDecision as CompactionDecision, ContextBudgetConfig as ContextBudgetConfig, decide_compaction as decide_compaction, estimate_message_token_counts as estimate_message_token_counts
from aip_agents.context.compaction import CompactionSummary as CompactionSummary, CompressionResult as CompressionResult, ContextCompressor as ContextCompressor
from aip_agents.context.offload import OffloadedPayloadRef as OffloadedPayloadRef, offload_oversized_payloads as offload_oversized_payloads, prune_duplicate_tool_outputs as prune_duplicate_tool_outputs, repair_tool_result_pairing as repair_tool_result_pairing
from aip_agents.context.prompt import PromptBuildContext as PromptBuildContext
from aip_agents.context.state import CompactionState as CompactionState
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Any

@dataclass(frozen=True)
class ContextPreparationResult:
    """Single output of the context preparation pipeline.

    Composes all compaction primitives into one result object
    so runtime code calls one facade instead of orchestrating
    budget, offload, prune, repair, and summary individually.

    Attributes:
        messages: Provider-ready messages after context preparation.
        prompt_context: Prompt assembly context used to build the system prompt.
        decision: Budget decision that determined whether compaction was needed.
        state: Safe compaction metadata for logging and observability.
        offloaded_refs: Payload references produced by lossless offloading.
        summary: Reference-only compaction summary inserted into context, if any.
    """
    messages: list[Any]
    prompt_context: PromptBuildContext | None = ...
    decision: CompactionDecision | None = ...
    state: CompactionState | None = ...
    offloaded_refs: tuple[OffloadedPayloadRef, ...] = field(default_factory=tuple)
    summary: CompactionSummary | None = ...

def prepare_context(messages: Sequence[Any], *, config: ContextBudgetConfig | None = None, backend: Any | None = None, model_context_tokens: int | None = None, summarizer: Any | None = None, previous_summary: CompactionSummary | None = None, focus_topic: str | None = None) -> ContextPreparationResult:
    """Run the full context preparation pipeline.

    Args:
        messages: Full message sequence to prepare for model invocation.
        config: Budget configuration for compaction decisions.
        backend: Optional backend for offloading oversized payloads.
        model_context_tokens: Provider model context window size, if known.
        summarizer: Optional external summarizer client.
        previous_summary: Previous compaction summary for incremental update.
        focus_topic: Optional focus topic for manual/guided compaction.

    Returns:
        ContextPreparationResult with processed messages and metadata.

    Order of operations:
    1. Budget decision (estimate tokens, decide if compaction needed)
    2. Lossless offload (oversized payloads to backend, if backend provided)
    3. Prune duplicate tool outputs
    4. Repair tool-result pairing
    5. Generate compaction summary (if should_compact)
    6. Assemble final messages (head + summary + tail)
    """
