"""Shared context utilities for token estimation, redaction, and safe preview.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

from __future__ import annotations

import re


def estimate_tokens(text: str, chars_per_token: int = 4) -> int:
    """Estimate token count for a text string."""
    if not text:
        return 0
    safe_ratio = max(chars_per_token, 1)
    return max(1, (len(text) + safe_ratio - 1) // safe_ratio)


_secret_kv_pattern = re.compile(r"(?i)(api[_-]?key|token|password|secret)\s*[:=]\s*[^\s]+")
_long_base64_pattern = re.compile(r"(?=[^+/=]*[+/=])[A-Za-z0-9+/=]{120,}")
_auth_header_pattern = re.compile(r"(?i)(Authorization|X-API-Key|Cookie)\s*:\s*[^\n]+")
_credential_query_pattern = re.compile(r"(?i)(api_key|token|secret|key|password|signature)=[^\s&]+")
_signed_url_pattern = re.compile(r"(?i)\b(x-amz-signature|sig|signature)\s*=\s*[^\s&]+")


def redact_sensitive(text: str) -> tuple[str, bool]:
    """Redact sensitive content from text."""
    redacted = _secret_kv_pattern.sub(lambda m: f"{m.group(1)}=[REDACTED]", text)
    redacted = _long_base64_pattern.sub("[BASE64_REDACTED]", redacted)
    redacted = _auth_header_pattern.sub(r"\1: [REDACTED]", redacted)
    redacted = _credential_query_pattern.sub(r"\1=[REDACTED]", redacted)
    redacted = _signed_url_pattern.sub(lambda m: f"{m.group(1)}=[REDACTED]", redacted)
    redaction_applied = redacted != text
    return redacted, redaction_applied


def safe_preview(content: str, *, max_chars: int) -> tuple[str, bool]:
    """Create a redacted preview of content."""
    redacted, redaction_applied = redact_sensitive(content)
    clipped = redacted[:max_chars]
    if len(redacted) > max_chars:
        clipped += "..."
    return clipped, redaction_applied
