from dataclasses import dataclass, field

@dataclass(frozen=True)
class SessionRecallSnapshot:
    """Snapshot of short-lived task/session state.

    This snapshot is intentionally scoped to active work context and should not
    be treated as durable memory by default.
    """
    active_task: str | None = ...
    recent_decisions: tuple[str, ...] = field(default_factory=tuple)
    changed_files: tuple[str, ...] = field(default_factory=tuple)
    blockers: tuple[str, ...] = field(default_factory=tuple)
    handoff_summary: str | None = ...
    stale: bool = ...

def build_session_recall_guidance(snapshot: SessionRecallSnapshot | None) -> str | None:
    """Render session recall guidance text from a snapshot.

    Args:
        snapshot: Optional session recall snapshot.

    Returns:
        A guidance block describing short-lived task/session context, or None
        when no snapshot is available.
    """
