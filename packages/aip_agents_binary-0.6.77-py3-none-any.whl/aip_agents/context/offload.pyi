from _typeshed import Incomplete
from aip_agents.middleware.backends.protocol import BackendProtocol as BackendProtocol
from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any

SourceKind: Incomplete

@dataclass(frozen=True)
class OffloadedPayloadRef:
    """Reference metadata for an offloaded payload.

    Attributes:
        ref_id: Stable identifier returned by the offload backend.
        source_kind: Payload origin used for audit and downstream handling.
        backend_uri: Backend-specific location for retrieving the full payload.
        display_name: Safe human-readable name for the payload, if available.
        mime_type: Payload MIME type, if known.
        size_bytes: Original payload size in bytes, if known.
        token_estimate: Estimated token cost of the original payload, if known.
        checksum: Integrity checksum for the original payload, if available.
        preview: Redacted inline preview used in the transformed message.
        redaction_applied: Whether the preview was changed by secret redaction.
    """
    ref_id: str
    source_kind: SourceKind
    backend_uri: str
    display_name: str | None
    mime_type: str | None
    size_bytes: int | None
    token_estimate: int | None
    checksum: str | None
    preview: str
    redaction_applied: bool

def offload_oversized_payloads(messages: Sequence[dict[str, Any]], *, backend: BackendProtocol | None = None, max_inline_chars: int = 4000, preview_chars: int = 400) -> tuple[list[dict[str, Any]], list[OffloadedPayloadRef]]:
    '''Offload oversized or sensitive payload content from messages.

    Message order and tool-call IDs are preserved.

    Usage::

        from aip_agents.context.offload import offload_oversized_payloads

        messages = [
            {"role": "tool", "name": "search", "content": "x" * 5000},
        ]
        transformed, refs = offload_oversized_payloads(
            messages, backend=backend, max_inline_chars=4000
        )
        # transformed[0]["content"] contains a preview + ref link
        # refs[0] has the OffloadedPayloadRef metadata
    '''
def offload_payload(payload_text: str, *, source_kind: SourceKind, display_name: str | None, backend: BackendProtocol | None = None, preview_chars: int = 400, mime_type: str | None = 'text/plain') -> OffloadedPayloadRef | None:
    """Create an offloaded payload reference and optional backend write.

    Returns None when no backend is provided or the backend write fails.
    """
def render_offloaded_reference_message(ref: OffloadedPayloadRef) -> str:
    """Render model-visible replacement content for an offloaded payload."""
def prune_duplicate_tool_outputs(messages: Sequence[dict[str, Any]], *, protected_tail_start_index: int) -> list[dict[str, Any]]:
    """Prune duplicate older tool outputs while preserving provider-valid pairs.

    Usage::

        from aip_agents.context.offload import prune_duplicate_tool_outputs

        # Only tool results at or after protected_tail_start_index are kept;
        # older duplicates are replaced with back-reference placeholders.
        pruned = prune_duplicate_tool_outputs(messages, protected_tail_start_index=10)
    """
def repair_tool_result_pairing(messages: Sequence[dict[str, Any]]) -> list[dict[str, Any]]:
    """Repair missing tool-result IDs when a single prior tool call is unambiguous.

    Usage::

        from aip_agents.context.offload import repair_tool_result_pairing

        # After pruning or offloading, tool-call IDs may be missing from
        # tool-result messages. This restores them when one unambiguous call
        # precedes each result.
        repaired = repair_tool_result_pairing(messages)
    """
