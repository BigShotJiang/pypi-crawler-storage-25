from aip_agents.storage import InMemoryStorageProvider as InMemoryStorageProvider, MinioConfig as MinioConfig, MinioObjectStorage as MinioObjectStorage, ObjectStorageProvider as ObjectStorageProvider
from aip_agents.utils.langgraph.tool_output_management import StoreOutputParams as StoreOutputParams, ToolOutputConfig as ToolOutputConfig, ToolOutputManager as ToolOutputManager
from typing import Protocol

__all__ = ['InMemoryStorageProvider', 'MinioConfig', 'MinioObjectStorage', 'ObjectStorageProvider', 'StoreOutputParams', 'ToolOutputConfig', 'ToolOutputManager', 'ToolOutputManagerProtocol']

class ToolOutputManagerProtocol(Protocol):
    """Minimal tool-output manager contract used by local-mode integrations."""
    def store_output(self, params: StoreOutputParams) -> None:
        """Persist a tool output entry."""
    def has_outputs(self, thread_id: str | None = None) -> bool:
        """Return whether any outputs are available."""
    def get_latest_reference(self, thread_id: str) -> str | None:
        """Return the latest reference token for a thread."""
