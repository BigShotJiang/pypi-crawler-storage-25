from aip_agents.ptc import PTCCustomToolConfig as PTCCustomToolConfig, PTCSandboxConfig as PTCSandboxConfig, PromptConfig as PromptConfig
from aip_agents.ptc.custom_tools import PTCCustomToolValidationError as PTCCustomToolValidationError, PTCFileToolDef as PTCFileToolDef, PTCPackageToolDef as PTCPackageToolDef, PTCToolDef as PTCToolDef, check_name_collisions as check_name_collisions, enrich_tool_def_with_metadata as enrich_tool_def_with_metadata, extract_tool_metadata as extract_tool_metadata, validate_custom_tool_config as validate_custom_tool_config
from aip_agents.ptc.naming import sanitize_function_name as sanitize_function_name
from aip_agents.ptc.tool_def_helpers import file_tool as file_tool, package_tool as package_tool
from typing import Any, Protocol

__all__ = ['PTCFileToolDef', 'PTCPackageToolDef', 'PTCSandboxConfig', 'PTCToolDef', 'PTCCustomToolConfig', 'PTCCustomToolValidationError', 'PromptBuilderProtocol', 'PromptConfig', 'check_name_collisions', 'enrich_tool_def_with_metadata', 'extract_tool_metadata', 'file_tool', 'package_tool', 'sanitize_function_name', 'validate_custom_tool_config']

class PromptBuilderProtocol(Protocol):
    """Callable contract for building PTC usage guidance."""
    def __call__(self, mcp_client: Any | None = None, config: PromptConfig | None = None, custom_tools_config: PTCCustomToolConfig | None = None) -> str:
        """Build a prompt describing the available PTC tool surface."""
