from aip_agents.agent import AgentInterface as AgentInterface, LangGraphReactAgent as LangGraphReactAgent
from typing import Any, Protocol

__all__ = ['AgentInterface', 'AgentRunProtocol', 'LangGraphReactAgent']

class AgentRunProtocol(Protocol):
    """Minimal async agent execution contract used by integration callers."""
    async def arun(self, *args: Any, **kwargs: Any) -> Any:
        """Run the agent and return the final result."""
    async def arun_stream(self, *args: Any, **kwargs: Any) -> Any:
        """Run the agent and stream incremental results."""
    async def arun_sse_stream(self, *args: Any, **kwargs: Any) -> Any:
        """Run the agent and stream SSE-compatible incremental results."""
