from aip_agents.skills import Skill as Skill

__all__ = ['Skill']
