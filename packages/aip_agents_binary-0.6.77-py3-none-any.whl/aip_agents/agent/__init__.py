"""This module initializes the agent package.

Exposes the core agent classes and interfaces.

Author:
    Christian Trisno Sen Long Chen (christian.t.s.l.chen@gdplabs.id)
"""

from __future__ import annotations

import importlib.util
from typing import TYPE_CHECKING, Any

from aip_agents.agent.base_agent import BaseAgent
from aip_agents.agent.google_adk_constants import GOOGLE_ADK_IMPORT_ERROR_MESSAGE

if TYPE_CHECKING:
    from aip_agents.agent.google_adk_agent import GoogleADKAgent
    from aip_agents.agent.langflow_agent import LangflowAgent
from aip_agents.agent.base_langgraph_agent import BaseLangGraphAgent
from aip_agents.agent.interface import AgentInterface
from aip_agents.agent.langgraph_react_agent import (
    LangChainAgent,
    LangGraphAgent,
    LangGraphReactAgent,
)

__all__ = [
    "AgentInterface",
    "BaseAgent",
    "BaseLangGraphAgent",
    "LangGraphReactAgent",
    "LangGraphAgent",
    "LangChainAgent",
    "LangflowAgent",
]

if importlib.util.find_spec("google.adk") is not None:
    __all__.append("GoogleADKAgent")


def __getattr__(name: str) -> Any:
    """Lazy import of heavy agent implementations.

    This avoids importing heavy dependencies (Google ADK, etc.)
    when they are not needed.

    Args:
        name: Attribute name to import.

    Returns:
        The requested class.

    Raises:
        AttributeError: If attribute is not found.
    """
    if name == "GoogleADKAgent":
        try:
            from aip_agents.agent.google_adk_agent import (
                GoogleADKAgent as _GoogleADKAgent,
            )
        except ModuleNotFoundError as e:
            if e.name and e.name.startswith("google"):
                raise ImportError(GOOGLE_ADK_IMPORT_ERROR_MESSAGE) from e
            raise

        return _GoogleADKAgent
    elif name == "LangflowAgent":
        from aip_agents.agent.langflow_agent import LangflowAgent as _LangflowAgent

        return _LangflowAgent
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")
