"""Shared constants for Google ADK agent integrations."""

# Default authentication URL presented when the ADK agent requires auth.
DEFAULT_AUTH_URL = "https://auth.example.com"

GOOGLE_ADK_IMPORT_ERROR_MESSAGE = (
    'Google ADK support requires the optional dependency. Install with: pip install "aip-agents[google-adk]" '
    'or "aip-agents[google]" for the umbrella extra'
)

__all__ = ["DEFAULT_AUTH_URL", "GOOGLE_ADK_IMPORT_ERROR_MESSAGE"]
