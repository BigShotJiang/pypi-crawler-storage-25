from _typeshed import Incomplete
from aip_agents.middleware.base import ModelRequest as ModelRequest
from aip_agents.utils.pii import get_pii_agent_prompt as get_pii_agent_prompt
from typing import Any

class PIIMiddleware:
    """Middleware for injecting PII awareness guidance into agent system prompts.

    This middleware contributes a system prompt addition that instructs the LLM about
    anonymized PII handling. It is automatically configured when `enable_pii=True`
    in the agent initialization.

    The prompt block is computed once at middleware instantiation time and remains
    constant throughout the agent's lifetime.

    Attributes:
        tools: Empty list (no tools provided by this middleware).
        system_prompt_additions: The PII guidance block to append to the system prompt,
            or None if PII is not enabled.
    """
    tools: Incomplete
    system_prompt_additions: Incomplete
    def __init__(self) -> None:
        """Initialize PII prompt middleware with the guidance block."""
    def before_model(self, _state: dict[str, Any]) -> dict[str, Any]:
        """Hook executed before each model invocation.

        This middleware does not modify state before model calls since the PII
        guidance is already provided via system_prompt_additions.

        Args:
            _state: Current agent state containing messages and other context.

        Returns:
            Empty dict (no state updates).
        """
    async def abefore_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Async hook executed before model invocation (no-op for this middleware)."""
    def modify_model_request(self, request: ModelRequest, _state: dict[str, Any]) -> ModelRequest:
        """Hook to modify model request before invocation.

        This middleware does not modify the model request since the PII guidance
        is already provided via system_prompt_additions.

        Args:
            request: The model request that will be sent to the LLM.
            _state: Current agent state for context.

        Returns:
            Unmodified ModelRequest.
        """
    def after_model(self, _state: dict[str, Any]) -> dict[str, Any]:
        """Hook executed after each model invocation.

        This middleware does not perform any post-processing after model calls.

        Args:
            _state: Current agent state after model invocation.

        Returns:
            Empty dict (no state updates).
        """
    async def aafter_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Async hook executed after model invocation (no-op for this middleware)."""
    def before_run(self, _state: dict[str, Any], _config: dict[str, Any] | None) -> dict[str, Any]:
        """Hook executed before each agent run.

        This middleware does not perform run-level setup since the PII guidance
        is already provided via system_prompt_additions.

        Args:
            _state: Initial agent state.
            _config: Optional run configuration.

        Returns:
            Empty dict (no state updates).
        """
    async def abefore_run(self, state: dict[str, Any], config: dict[str, Any] | None) -> dict[str, Any]:
        """Async hook executed before agent run (no-op for this middleware)."""
    def after_run(self, *, _final_state: dict[str, Any], _output: str | None, _config: dict[str, Any] | None, _error: Exception | None) -> None | dict[str, Any]:
        """Hook executed after each agent run.

        This middleware does not perform run-level cleanup or persistence.

        Args:
            _final_state: Final state after agent run completion.
            _output: Agent's final output string, or None if run ended with error.
            _config: Run configuration used for this execution.
            _error: Exception raised during run, or None if run succeeded.

        Returns:
            None (no updates or cleanup needed).
        """
    async def aafter_run(self, *, final_state: dict[str, Any], output: str | None, config: dict[str, Any] | None, error: Exception | None) -> None | dict[str, Any]:
        """Async hook executed after agent run (no-op for this middleware)."""
    def on_final_response(self, _content: str, _context: dict[str, Any]) -> None:
        """Hook executed when streaming final response is captured.

        This middleware does not process the final response content.

        Args:
            _content: Final response text from the agent.
            _context: Context dict containing metadata about the response.

        Returns:
            None.
        """
