from pydantic import BaseModel

class MiddlewareToolConfig(BaseModel):
    """Agent-level configuration schema for middleware-created tools.

    Attributes:
        resilience: Resilience policy dict (timeout_seconds, retry, circuit_breaker).
        hitl: Human-in-the-loop approval config dict (timeout_seconds, etc.).
    """
    resilience: dict
    hitl: dict
