"""Read file tool for agents.

TODO: After migrating to deepagents:
  - Keep this tool implementation (it's incompatible with deepagents' version)
  - Reuse from deepagents: BackendProtocol, FileInfo, format_content_with_line_numbers()

Authors:
    Christian Trisno Sen Long Chen (christian.t.s.l.chen@gdplabs.id)
"""

from typing import Annotated, Any

from langchain_core.tools import BaseTool
from pydantic import AliasChoices, BaseModel, Field, SkipValidation

from aip_agents.middleware.schema import MiddlewareToolConfig

READ_FILE_TOOL_DESCRIPTION = """Reads a file from the filesystem.

Assume this tool is able to read all files. If the User provides a path to a file assume that path is valid. It is okay to read a file that does not exist; an error will be returned.

**Two modes - pick ONE and stick with it for the entire file:**

**Mode 1: Line-based** - for normal code/text files with reasonable line lengths
- First scan: read_file(path, line_offset=0, limit=100)
- Continue: read_file(path, line_offset=100, limit=100)
- Results include line numbers (cat -n format)
- Do NOT set char_offset or max_chars

**Mode 2: Character-based** - for large/long-line files (minified JS, JSON, CSV, etc.)
- First chunk: read_file(path, char_offset=0, max_chars=20000)
- Continue: read_file(path, char_offset=20000, max_chars=20000)
- Returns raw text without line numbers
- Hard limit: 80000 characters per call
- Do NOT set line_offset or limit

**Rules:**
- Start with line-based for unknown files. If the result includes a truncation warning,
  follow its instruction to continue with char-based only. Do NOT re-read from char_offset=0.
- Never mix both modes in the same call.
- Once you pick a mode for a file, continue with that mode until done.
- You can call multiple tools in a single response
- If file has empty contents you will receive a warning
- Always make sure a file has been read before editing it"""

# Constants for character-based pagination
MAX_READ_FILE_CHARS_HARD_LIMIT = 80000
MAX_READ_FILE_CHARS_DEFAULT = 20000
MIN_READ_FILE_CHARS = 1

# If a line-based result exceeds this size, the file likely has very long lines
# and the agent should switch to char-based pagination instead.
LINE_BASED_RESULT_CHAR_WARN_THRESHOLD = MAX_READ_FILE_CHARS_DEFAULT


class ReadFileInput(BaseModel):
    """Input schema for read_file tool."""

    path: str = Field(description="File path to read")
    line_offset: int | None = Field(
        default=None,
        validation_alias=AliasChoices("line_offset", "offset"),
        description=(
            "Line offset (0-indexed). Also accepted as 'offset' for backward compatibility. "
            "Line-based mode only. Leave None for char mode."
        ),
    )
    limit: int | None = Field(
        default=None,
        description="Max lines to return. Line-based mode only. Leave None for char mode.",
    )
    char_offset: int | None = Field(
        default=None,
        description=("Character position to start from (0-indexed). Char-based mode only. Leave None for line mode."),
    )
    max_chars: int | None = Field(
        default=None,
        description=(
            f"Max characters to return. Char-based mode only. Leave None for line mode."
            f" Hard limit: {MAX_READ_FILE_CHARS_HARD_LIMIT}"
        ),
    )


class ReadFileTool(BaseTool):
    """Tool for reading file contents with optional pagination."""

    name: str = "read_file"
    description: str = READ_FILE_TOOL_DESCRIPTION
    args_schema: type[BaseModel] = ReadFileInput  # type: ignore[assignment]
    tool_config_schema: type[BaseModel] = MiddlewareToolConfig
    backend: Annotated[Any, SkipValidation]  # BackendProtocol - skip validation for Protocol type

    def _clamp_max_chars(self, max_chars: int | None) -> int:
        """Clamp a char-based read size to supported bounds.

        Args:
            max_chars: Requested number of characters, or None to use the default.

        Returns:
            A character count between the minimum and hard limit.
        """
        requested = max_chars if max_chars is not None else MAX_READ_FILE_CHARS_DEFAULT
        return max(MIN_READ_FILE_CHARS, min(requested, MAX_READ_FILE_CHARS_HARD_LIMIT))

    def _build_line_truncation_result(self, path: str, line_result: str, line_offset: int) -> str:
        """Build the safest response for an oversized line-based read.

        Args:
            path: File path being read.
            line_result: Line-based backend output for the current request.
            line_offset: Effective line offset used for the request.

        Returns:
            A raw first chunk with continuation guidance, a later-page warning, or the original result.
        """
        page_char_offset = self._line_offset_to_char_offset(path, line_offset)
        raw_chunk = self.backend.read_chars(
            path,
            char_offset=page_char_offset,
            max_chars=MAX_READ_FILE_CHARS_DEFAULT,
        )
        next_offset = page_char_offset + len(raw_chunk)
        has_more = self.backend.read_chars(path, char_offset=next_offset, max_chars=1) != "[End of file reached]"

        if not has_more:
            return line_result

        return (
            raw_chunk + "\n\n[TRUNCATED. Continue with char-based only:"
            f" read_file('{path}', char_offset={next_offset},"
            f" max_chars={MAX_READ_FILE_CHARS_DEFAULT})."
            f" Do NOT use line_offset/limit for this file.]"
        )

    def _line_offset_to_char_offset(self, path: str, line_offset: int) -> int:
        """Convert a line offset into the corresponding raw character offset.

        Args:
            path: File path being read.
            line_offset: Zero-based line offset to convert.

        Returns:
            Raw character offset for the first character of the requested line.
        """
        if line_offset <= 0:
            return 0

        text = self.backend.read_bytes(path).decode("utf-8", errors="replace")
        current_offset = 0
        current_line = 0

        while current_line < line_offset and current_offset < len(text):
            newline_index = text.find("\n", current_offset)
            if newline_index == -1:
                return len(text)
            current_offset = newline_index + 1
            current_line += 1

        return current_offset

    def _run_char_mode(self, path: str, char_offset: int, max_chars: int | None) -> str:
        """Read file content using character-based pagination.

        Args:
            path: File path to read.
            char_offset: Character offset to start from.
            max_chars: Optional maximum characters to return.

        Returns:
            Raw file content from the requested character offset.
        """
        clamped_max_chars = self._clamp_max_chars(max_chars)
        return self.backend.read_chars(path, char_offset=char_offset, max_chars=clamped_max_chars)

    def _run_line_mode(self, path: str, line_offset: int | None, limit: int | None) -> str:
        """Read file content using line-based pagination.

        Args:
            path: File path to read.
            line_offset: Optional starting line offset.
            limit: Optional maximum number of lines to return.

        Returns:
            A line-numbered result or a truncation handoff response.
        """
        effective_offset = line_offset if line_offset is not None else 0
        effective_limit = limit if limit is not None else 100
        result = self.backend.read(path, line_offset=effective_offset, limit=effective_limit)

        if len(result) <= LINE_BASED_RESULT_CHAR_WARN_THRESHOLD:
            return result

        return self._build_line_truncation_result(path, result, effective_offset)

    def _format_read_error(self, path: str, error: Exception) -> str:
        """Convert backend exceptions into stable tool responses.

        Args:
            path: File path that was being read.
            error: Exception raised by the backend call.

        Returns:
            A user-facing error string that preserves the existing tool contract.
        """
        if isinstance(error, FileNotFoundError):
            return f"Error: File not found: {path}"
        if isinstance(error, ValueError):
            return f"Error: {str(error)}"
        return f"Error reading file: {str(error)}"

    def _run(
        self,
        path: str,
        line_offset: int | None = None,
        limit: int | None = None,
        char_offset: int | None = None,
        max_chars: int | None = None,
    ) -> str:
        """Execute the read operation.

        Args:
            path: File path to read.
            line_offset: Line number to start from (for line-based pagination).
            limit: Maximum lines to return.
            char_offset: Character position to start from (for char-based pagination).
                When provided, takes precedence over line_offset/limit.
            max_chars: Maximum characters to return (clamped to hard limit).

        Returns:
            File contents or error message.
        """
        try:
            if char_offset is not None:
                return self._run_char_mode(path, char_offset, max_chars)

            return self._run_line_mode(path, line_offset, limit)
        except Exception as error:
            return self._format_read_error(path, error)
