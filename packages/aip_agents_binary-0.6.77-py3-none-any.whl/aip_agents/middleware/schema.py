"""Shared Pydantic schemas for middleware tool configuration.

Used as tool_config_schema on middleware-created tool classes to enable
agent-level config injection (resilience, HITL, etc.) via tool_configs.
"""

from pydantic import BaseModel, Field


class MiddlewareToolConfig(BaseModel):
    """Agent-level configuration schema for middleware-created tools.

    Attributes:
        resilience: Resilience policy dict (timeout_seconds, retry, circuit_breaker).
        hitl: Human-in-the-loop approval config dict (timeout_seconds, etc.).
    """

    resilience: dict = Field(default_factory=dict)
    hitl: dict = Field(default_factory=dict)
