from _typeshed import Incomplete
from aip_agents.middleware.base import AgentMiddleware as AgentMiddleware, ModelRequest as ModelRequest
from aip_agents.middleware.schema import MiddlewareToolConfig as MiddlewareToolConfig
from aip_agents.schema.step_limit import StepLimitConfig as StepLimitConfig
from aip_agents.utils.langgraph.tool_managers.delegation_tool_manager import DELEGATED_AGENT_TIMEOUT_CONFIG_ERROR_KEY as DELEGATED_AGENT_TIMEOUT_CONFIG_ERROR_KEY, INVALID_DELEGATED_AGENT_TIMEOUT_MESSAGE as INVALID_DELEGATED_AGENT_TIMEOUT_MESSAGE
from aip_agents.utils.logger import get_logger as get_logger
from aip_agents.utils.metadata_helper import MetadataFieldKeys as MetadataFieldKeys, get_next_step_number as get_next_step_number
from aip_agents.utils.pii.pii_helper import extract_pii_mapping_from_agent_response as extract_pii_mapping_from_agent_response
from aip_agents.utils.step_limit_manager import StepLimitManager as StepLimitManager
from aip_agents.utils.token_usage_helper import STEP_USAGE_KEY as STEP_USAGE_KEY, TOTAL_USAGE_KEY as TOTAL_USAGE_KEY, USAGE_METADATA_KEY as USAGE_METADATA_KEY
from dataclasses import dataclass
from langchain_core.runnables import RunnableConfig
from langchain_core.tools import ArgsSchema, BaseTool
from langgraph.types import StreamWriter
from pydantic import BaseModel, SkipValidation
from typing import Any

logger: Incomplete
TASK_DELEGATION_SYSTEM_PROMPT: str
WORKER_DELEGATION_NOT_ALLOWED: str
WORKER_CONCURRENCY_LIMIT_REACHED: str
UNKNOWN_OR_DISALLOWED_TOOLS: str
INSUFFICIENT_STEP_BUDGET: str
DEFAULT_MAX_CONCURRENT_WORKERS: int
DEFAULT_MAX_PENDING_WORKERS: int
MAX_ERROR_MESSAGE_LENGTH: int
ALLOWED_TOOL_NAME_PREFIXES: Incomplete
EVENT_TYPE_TOOL_CALL: str
EVENT_TYPE_TOOL_RESULT: str
EVENT_TYPE_FINAL_RESPONSE: str
EVENT_TYPE_CONTENT_CHUNK: str
EVENT_TYPE_STATUS_UPDATE: str
SUB_AGENT_EVENT_METADATA_KEY: str
DELEGATION_METADATA_KEY: str
DELEGATION_FAILED_STATUS: str
DELEGATION_TOOL_TIMEOUT_REASON: str
SUB_AGENT_TERMINAL_EVENT_REMAP: Incomplete
METADATA_INTERNAL_PREFIXES: Incomplete
METADATA_INTERNAL_KEYS: Incomplete

class TaskDelegationConfig(BaseModel):
    """Configuration for dynamic task delegation middleware."""
    max_concurrent_workers: int
    max_pending_workers: int
    timeout_seconds: float | None
    def create_middleware(self, parent_agent: Any) -> TaskDelegationMiddleware:
        """Create task delegation middleware for one parent agent.

        Returns:
            TaskDelegationMiddleware: Configured middleware instance.
        """

class TaskToolSchema(BaseModel):
    """Schema for task tool inputs.

    Attributes:
        query (str): Delegated task mission text.
        prompt (str | None): Optional additional instruction context.
        allowed_tools (list[str] | None): Optional narrowing-only allowlist.
    """
    query: str
    prompt: str | None
    allowed_tools: list[str] | None

class TaskResult(BaseModel):
    """Deterministic task execution result.

    Attributes:
        success (bool): True when delegated execution completed successfully.
        result (str): Worker output text, or empty string on failure.
        error (str | None): Failure reason when ``success`` is False.
    """
    success: bool
    result: str
    error: str | None
    worker_response: dict[str, Any] | None

@dataclass(frozen=True)
class WorkerExecutionPlan:
    """Precomputed worker execution inputs used by ``run_task``.

    Attributes:
        worker_tools (list[BaseTool]): Effective toolset for worker execution.
        filesystem_backend (Any | None): Shared filesystem backend when enabled.
        use_shared_filesystem_middleware (bool): Whether worker should reuse parent
            filesystem middleware backend.
        child_budget (int): Derived worker step budget.
        worker_instruction (str): Final worker system prompt.
        worker_kwargs (dict[str, Any]): Child runnable kwargs.
    """
    worker_tools: list[BaseTool]
    filesystem_backend: Any | None
    use_shared_filesystem_middleware: bool
    child_budget: int
    worker_instruction: str
    worker_kwargs: dict[str, Any]

class TaskDelegationTool(BaseTool):
    """LangChain-compatible ``task`` tool wrapper.

    Attributes:
        name (str): Tool name exposed to the model.
        description (str): Tool behavior summary and argument contract.
        args_schema (ArgsSchema): Input schema used for argument validation.
        middleware (TaskDelegationMiddleware): Owning middleware instance.
    """
    name: str
    description: str
    args_schema: ArgsSchema
    tool_config_schema: type[BaseModel]
    middleware: SkipValidation[TaskDelegationMiddleware]
    metadata: dict[str, Any] | None

class TaskDelegationMiddleware(AgentMiddleware):
    """Middleware that injects runtime task delegation support.

    The middleware adds a ``task`` tool and enforces bounded worker delegation.
    It prevents nested worker delegation, applies queue/concurrency limits, and
    narrows worker tools when an allowlist is provided.
    """
    parent_agent: Incomplete
    max_concurrent_workers: Incomplete
    max_pending_workers: Incomplete
    worker_timeout_seconds: Incomplete
    system_prompt_additions: Incomplete
    tools: list[BaseTool]
    def __init__(self, parent_agent: Any, *, max_concurrent_workers: int = ..., max_pending_workers: int = ..., worker_timeout_seconds: float | None = None) -> None:
        """Initialize task delegation middleware.

        Args:
            parent_agent (Any): Parent agent instance that owns this middleware.
            max_concurrent_workers (int, optional): Maximum concurrently running
                workers. Defaults to 5.
            max_pending_workers (int, optional): Maximum pending worker requests
                allowed in addition to active workers. Defaults to 20.
            worker_timeout_seconds (float | None, optional): Parent-owned timeout
                budget for each dynamic worker run. Defaults to None.

        Raises:
            ValueError: If concurrency or pending limits are invalid.
        """
    def before_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """No-op hook before model invocation.

        Args:
            state (dict[str, Any]): Current graph state.

        Returns:
            dict[str, Any]: Empty update.
        """
    def modify_model_request(self, request: ModelRequest, state: dict[str, Any]) -> ModelRequest:
        """Pass through model request unchanged.

        Args:
            request (ModelRequest): Outgoing model request payload.
            state (dict[str, Any]): Current graph state.

        Returns:
            ModelRequest: Unmodified request.
        """
    def after_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """No-op hook after model invocation.

        Args:
            state (dict[str, Any]): Current graph state.

        Returns:
            dict[str, Any]: Empty update.
        """
    async def run_task(self, *, query: str, prompt: str | None, allowed_tools: list[str] | None, config: RunnableConfig | None, stream_writer: StreamWriter | None = None) -> TaskResult:
        """Run one delegated worker task with safety constraints.

        Args:
            query (str): Delegated task mission text.
            prompt (str | None): Optional additional worker instructions.
            allowed_tools (list[str] | None): Optional narrowing-only allowlist.
            config (RunnableConfig | None): Runnable execution config.
            stream_writer (StreamWriter | None, optional): Parent stream writer
                receiving forwarded sub-agent events. Defaults to None.

        Returns:
            TaskResult: Execution result with success flag and error context.

        Raises:
            None: All internal failures are converted into ``TaskResult`` with
                ``success=False``.
        """
