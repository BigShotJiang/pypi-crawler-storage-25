from aip_agents.mcp.client.base_mcp_client import BaseMCPClient as BaseMCPClient
from aip_agents.ptc.custom_tools import PTCCustomToolConfig as PTCCustomToolConfig, validate_custom_tool_config as validate_custom_tool_config
from aip_agents.ptc.custom_tools_payload import build_custom_tools_payload as build_custom_tools_payload
from aip_agents.ptc.doc_gen import render_tool_doc as render_tool_doc
from aip_agents.ptc.exceptions import PTCPayloadConflictError as PTCPayloadConflictError
from aip_agents.ptc.mcp.sandbox_bridge import build_mcp_payload as build_mcp_payload
from aip_agents.ptc.naming import example_value_from_schema as example_value_from_schema, project_custom_tool_signature as project_custom_tool_signature, sanitize_function_name as sanitize_function_name, sanitize_param_name as sanitize_param_name
from aip_agents.ptc.payload import SandboxPayload as SandboxPayload

async def build_sandbox_payload(mcp_client: BaseMCPClient | None = None, default_tool_timeout: float = 60.0, custom_tools_config: PTCCustomToolConfig | None = None, tool_configs: dict[str, dict] | None = None) -> SandboxPayload:
    """Build sandbox payload from all configured tool sources.

    Composes MCP and custom LangChain tool payloads into a single payload.

    Args:
        mcp_client: The MCP client with configured servers. Can be None if only custom tools.
        default_tool_timeout: Default timeout for tool calls in seconds.
        custom_tools_config: Optional custom LangChain tools configuration.
        tool_configs: Optional per-tool config values for custom tools.

    Returns:
        SandboxPayload containing files and env vars for the sandbox.
    """
def wrap_ptc_code(code: str, include_packages_path: bool = False) -> str:
    """Wrap user PTC code with necessary imports and setup.

    This prepends sys.path setup to ensure the tools package is importable.
    When custom tools with bundled package sources are enabled, also adds
    the packages/ directory to sys.path.

    Args:
        code: User-provided Python code.
        include_packages_path: If True, also add packages/ dir to sys.path
            for bundled package sources from custom LangChain tools.

    Returns:
        Wrapped code ready for sandbox execution.
    """
