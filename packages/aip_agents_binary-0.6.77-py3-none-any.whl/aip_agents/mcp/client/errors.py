"""Typed MCP startup errors.

This module defines structured startup failures so higher layers can distinguish
real startup/auth failures from outer timeout guards.
"""


class MCPServerStartupError(Exception):
    """Base structured error for MCP server startup failures."""

    def __init__(
        self,
        server_name: str,
        message: str,
        *,
        transport: str | None = None,
        status_code: int | None = None,
        cause: BaseException | None = None,
    ) -> None:
        """Initialize the startup error with server details and failure context."""
        self.server_name = server_name
        self.transport = transport
        self.status_code = status_code
        self.message = message
        self.cause = cause
        super().__init__(message)

    def __str__(self) -> str:
        """Return the error message."""
        return self.message


class MCPServerAuthError(MCPServerStartupError):
    """Structured startup error for definitive authentication failures."""


class MCPServerStartupTimeoutError(MCPServerStartupError):
    """Structured startup error for inner MCP startup timeout failures."""


_AUTH_STATUS_CODES = {401, 403}
_TIMEOUT_SIGNAL = "timeout"
_TIMED_OUT_SIGNAL = "timed out"


def get_exception_status_code(exc: BaseException) -> int | None:
    """Extract an HTTP status code from an exception or one of its common attributes."""
    response = getattr(exc, "response", None)
    status_code = getattr(response, "status_code", None)
    if isinstance(status_code, int):
        return status_code

    direct_status_code = getattr(exc, "status_code", None)
    if isinstance(direct_status_code, int):
        return direct_status_code

    return None


def is_auth_status_code(status_code: int | None) -> bool:
    """Return True for definitive auth failures relevant to startup handling."""
    return status_code in _AUTH_STATUS_CODES


def _has_timeout_signal(exc: BaseException) -> bool:
    """Return True when the exception itself looks timeout-related."""
    if isinstance(exc, TimeoutError):
        return True

    exception_name = type(exc).__name__.lower()
    if _TIMEOUT_SIGNAL in exception_name:
        return True

    message = str(exc).lower()
    return _TIMEOUT_SIGNAL in message or _TIMED_OUT_SIGNAL in message


def is_timeout_exception(exc: BaseException | None) -> bool:
    """Return True when an exception (or its chained cause) is timeout-shaped."""
    current = exc
    visited: set[int] = set()

    while current is not None and id(current) not in visited:
        if _has_timeout_signal(current):
            return True
        visited.add(id(current))
        current = current.__cause__ or current.__context__

    return False


def build_startup_error(
    *,
    server_name: str,
    message: str,
    transport: str | None = None,
    cause: BaseException | None = None,
    status_code: int | None = None,
) -> MCPServerStartupError:
    """Create the most specific structured startup error for a startup failure."""
    resolved_status = status_code
    if resolved_status is None and cause is not None:
        resolved_status = get_exception_status_code(cause)

    error_cls: type[MCPServerStartupError]
    if is_auth_status_code(resolved_status):
        error_cls = MCPServerAuthError
    elif is_timeout_exception(cause):
        error_cls = MCPServerStartupTimeoutError
    else:
        error_cls = MCPServerStartupError

    return error_cls(
        server_name=server_name,
        message=message,
        transport=transport,
        status_code=resolved_status,
        cause=cause,
    )
