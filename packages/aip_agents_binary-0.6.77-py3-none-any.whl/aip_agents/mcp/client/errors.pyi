from _typeshed import Incomplete

class MCPServerStartupError(Exception):
    """Base structured error for MCP server startup failures."""
    server_name: Incomplete
    transport: Incomplete
    status_code: Incomplete
    message: Incomplete
    cause: Incomplete
    def __init__(self, server_name: str, message: str, *, transport: str | None = None, status_code: int | None = None, cause: BaseException | None = None) -> None:
        """Initialize the startup error with server details and failure context."""

class MCPServerAuthError(MCPServerStartupError):
    """Structured startup error for definitive authentication failures."""
class MCPServerStartupTimeoutError(MCPServerStartupError):
    """Structured startup error for inner MCP startup timeout failures."""

def get_exception_status_code(exc: BaseException) -> int | None:
    """Extract an HTTP status code from an exception or one of its common attributes."""
def is_auth_status_code(status_code: int | None) -> bool:
    """Return True for definitive auth failures relevant to startup handling."""
def is_timeout_exception(exc: BaseException | None) -> bool:
    """Return True when an exception (or its chained cause) is timeout-shaped."""
def build_startup_error(*, server_name: str, message: str, transport: str | None = None, cause: BaseException | None = None, status_code: int | None = None) -> MCPServerStartupError:
    """Create the most specific structured startup error for a startup failure."""
