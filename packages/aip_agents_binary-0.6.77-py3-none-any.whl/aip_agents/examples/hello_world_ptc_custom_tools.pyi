from aip_agents.agent import LangGraphReactAgent as LangGraphReactAgent
from aip_agents.examples.tools.multiply_tool import MultiplyTool as MultiplyTool
from aip_agents.ptc import PTCCustomToolConfig as PTCCustomToolConfig, PTCSandboxConfig as PTCSandboxConfig, PromptConfig as PromptConfig, file_tool as file_tool, package_tool as package_tool
from aip_agents.tools.time_tool import TimeTool as TimeTool

async def main() -> None:
    """Run a hello-world PTC flow with custom tools."""
