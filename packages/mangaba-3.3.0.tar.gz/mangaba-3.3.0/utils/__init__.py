"""Utilities for Mangaba AI"""

from utils.logger import get_logger

__all__ = ["get_logger"]