"""Convert PDF to structured text using Grobid"""

__version__ = "1.6.37"
