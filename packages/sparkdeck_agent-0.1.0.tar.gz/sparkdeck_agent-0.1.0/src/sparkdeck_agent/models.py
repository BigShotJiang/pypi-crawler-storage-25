"""Pydantic models for the SparkDeck Agent API."""

from __future__ import annotations

from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, Field, computed_field


class GPUMetrics(BaseModel):
    """Current GPU telemetry from NVML."""

    gpu_name: str
    utilization: float = Field(ge=0, le=100, description="GPU utilization %")
    memory_used: int = Field(ge=0, description="GPU memory used in MiB")
    memory_total: int = Field(gt=0, description="Total GPU memory in MiB")
    temperature: float = Field(description="GPU temperature in Celsius")
    power_draw: float = Field(ge=0, description="Current power draw in watts")
    fan_speed: float = Field(ge=0, le=100, description="Fan speed %")

    @computed_field  # type: ignore[prop-decorator]
    @property
    def memory_utilization(self) -> float:
        """Memory utilization as a percentage."""
        return round(self.memory_used / self.memory_total * 100, 2)


class ContainerInfo(BaseModel):
    """Running Docker container summary."""

    id: str
    name: str
    image: str
    status: str
    ports: List[str] = Field(default_factory=list)


class EndpointType(str, Enum):
    """Supported LLM endpoint types."""

    OPENAI = "openai"
    OLLAMA = "ollama"
    VLLM = "vllm"
    CUSTOM = "custom"


class LLMEndpoint(BaseModel):
    """Discovered LLM inference endpoint."""

    name: str
    base_url: str
    model_name: str
    endpoint_type: EndpointType
    online: bool = True


class DeviceStatus(BaseModel):
    """Full device status snapshot sent to the hub."""

    hostname: str
    agent_version: str
    uptime: str = Field(description="Device uptime")
    tailscale_ip: Optional[str] = None
    disk_usage: Optional[str] = None  # e.g. "420G/1.8T (25%)"
    gpu: Optional[GPUMetrics] = None
    containers_running: List[ContainerInfo] = Field(default_factory=list)
    llm_endpoints: List[LLMEndpoint] = Field(default_factory=list)


class ContainerAction(BaseModel):
    """Request to start or stop a container."""

    action: str = Field(pattern="^(start|stop)$")


class NotifyRegistration(BaseModel):
    """Register a device for push notifications."""

    device_token: str = Field(min_length=1)
    events: List[str] = Field(min_length=1)
