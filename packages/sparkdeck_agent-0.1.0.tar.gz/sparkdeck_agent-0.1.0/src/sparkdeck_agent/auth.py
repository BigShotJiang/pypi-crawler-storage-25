"""Token-based authentication for SparkDeck Agent."""

from __future__ import annotations

import secrets
from pathlib import Path


def generate_token() -> str:
    return secrets.token_hex(32)


def verify_token(provided: str, expected: str) -> bool:
    if not provided or not expected:
        return False
    return secrets.compare_digest(provided, expected)


def load_or_create_token(token_path: Path) -> str:
    token_path.parent.mkdir(parents=True, exist_ok=True)
    if token_path.exists():
        token = token_path.read_text().strip()
        if token:
            return token
    token = generate_token()
    token_path.write_text(token)
    token_path.chmod(0o600)
    return token
