"""Allow running as `python -m sparkdeck_agent`."""

from sparkdeck_agent.cli import main

main()
