"""GPU monitoring via pynvml (NVIDIA Management Library)."""

from __future__ import annotations

import os
import pynvml

from sparkdeck_agent.models import GPUMetrics


class GPUMonitor:
    """Reads GPU telemetry from a single NVIDIA device via NVML.

    All pynvml calls are wrapped in try/except because the GB10 may
    report N/A for certain metrics (e.g. fan speed).
    """

    def __init__(self) -> None:
        self._initialized = False
        self._handle: object | None = None

    def _ensure_init(self) -> None:
        """Lazily initialise pynvml and grab the first device handle."""
        if not self._initialized:
            pynvml.nvmlInit()
            self._handle = pynvml.nvmlDeviceGetHandleByIndex(0)
            self._initialized = True

    def get_metrics(self) -> GPUMetrics:
        """Query all GPU metrics and return a validated GPUMetrics model."""
        self._ensure_init()
        handle = self._handle

        try:
            name = pynvml.nvmlDeviceGetName(handle)
            if isinstance(name, bytes):
                name = name.decode("utf-8")
        except Exception:
            name = "Unknown GPU"

        try:
            util = pynvml.nvmlDeviceGetUtilizationRates(handle)
            utilization = util.gpu
        except Exception:
            utilization = 0

        try:
            mem = pynvml.nvmlDeviceGetMemoryInfo(handle)
            memory_used = mem.used // (1024 * 1024)
            memory_total = mem.total // (1024 * 1024)
        except Exception:
            memory_used = 0
            memory_total = 1

        # GB10 unified memory: pynvml may report 0 or 1 MB.
        # Fall back to system memory via /proc/meminfo.
        if memory_total <= 1:
            sys_total, sys_used = self._get_system_memory()
            if sys_total > 0:
                memory_total = sys_total
                memory_used = sys_used

        try:
            temperature = pynvml.nvmlDeviceGetTemperature(
                handle, pynvml.NVML_TEMPERATURE_GPU
            )
        except Exception:
            temperature = 0

        try:
            power = pynvml.nvmlDeviceGetPowerUsage(handle)
            power_draw = power // 1000  # milliwatts -> watts
        except Exception:
            power_draw = 0

        try:
            fan_speed = pynvml.nvmlDeviceGetFanSpeed(handle)
        except Exception:
            fan_speed = 0

        return GPUMetrics(
            gpu_name=name,
            utilization=utilization,
            memory_used=memory_used,
            memory_total=memory_total,
            temperature=temperature,
            power_draw=power_draw,
            fan_speed=fan_speed,
        )

    @staticmethod
    def _get_system_memory() -> tuple[int, int]:
        """Read system memory from /proc/meminfo (Linux). Returns (total_mb, used_mb)."""
        try:
            with open("/proc/meminfo") as f:
                info = {}
                for line in f:
                    parts = line.split()
                    if len(parts) >= 2:
                        info[parts[0].rstrip(":")] = int(parts[1])
            total = info.get("MemTotal", 0) // 1024  # kB → MB
            available = info.get("MemAvailable", 0) // 1024
            used = total - available
            return (total, used)
        except Exception:
            return (0, 0)

    def shutdown(self) -> None:
        """Release NVML resources."""
        if self._initialized:
            pynvml.nvmlShutdown()
            self._initialized = False
