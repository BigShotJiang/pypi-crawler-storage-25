"""FastAPI server for SparkDeck Agent."""

from __future__ import annotations

import asyncio
import logging
import platform
import subprocess
from contextlib import asynccontextmanager
from typing import AsyncGenerator, List

from fastapi import APIRouter, Depends, FastAPI, HTTPException, Query, Request, WebSocket, WebSocketDisconnect
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from sparkdeck_agent import __version__
from sparkdeck_agent.auth import load_or_create_token, verify_token
from sparkdeck_agent.config import SparkDeckConfig
from sparkdeck_agent.discovery import LLMDiscovery
from sparkdeck_agent.docker_manager import DockerManager
from sparkdeck_agent.gpu import GPUMonitor
from sparkdeck_agent.models import (
    ContainerAction,
    ContainerInfo,
    DeviceStatus,
    EndpointType,
    GPUMetrics,
    LLMEndpoint,
    NotifyRegistration,
)

logger = logging.getLogger(__name__)

security = HTTPBearer()


def _get_tailscale_ip() -> str | None:
    """Return the device's Tailscale IPv4 address, or None if unavailable."""
    try:
        result = subprocess.run(
            ["tailscale", "ip", "-4"],
            capture_output=True, text=True, timeout=2,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass
    return None


def _get_disk_usage() -> str:
    """Return human-readable disk usage for the root filesystem."""
    try:
        result = subprocess.run(
            ["df", "-h", "/"],
            capture_output=True, text=True, timeout=2,
        )
        if result.returncode == 0:
            lines = result.stdout.strip().split("\n")
            if len(lines) >= 2:
                parts = lines[1].split()
                if len(parts) >= 5:
                    return f"{parts[2]}/{parts[1]} ({parts[4]})"
    except Exception:
        pass
    return "N/A"


def _get_device_uptime() -> str:
    """Return the device uptime as a human-readable string."""
    try:
        result = subprocess.run(
            ["uptime", "-p"],
            capture_output=True, text=True, timeout=2,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass
    return "unknown"


# ------------------------------------------------------------------
# Auth dependency
# ------------------------------------------------------------------


async def require_auth(
    request: Request,
    credentials: HTTPAuthorizationCredentials = Depends(security),
) -> str:
    """Validate the bearer token on every request."""
    token = credentials.credentials
    if not verify_token(token, request.app.state.token):
        raise HTTPException(status_code=401, detail="Invalid token")
    return token


# ------------------------------------------------------------------
# Lifespan
# ------------------------------------------------------------------


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Initialise GPU monitor, Docker manager, LLM discovery, and auth token."""
    config: SparkDeckConfig = app.state.config
    config.ensure_dirs()

    # Auth token
    app.state.token = load_or_create_token(config.token_path)
    logger.info("Auth token loaded from %s", config.token_path)

    # GPU monitor
    gpu: GPUMonitor | None = None
    try:
        gpu = GPUMonitor()
        gpu.get_metrics()  # trigger init to verify GPU is available
        logger.info("GPU monitor initialised")
    except Exception as exc:
        logger.warning("GPU monitoring unavailable: %s", exc)
        gpu = None
    app.state.gpu_monitor = gpu

    # Docker manager
    app.state.docker_manager = DockerManager()

    # LLM discovery
    app.state.llm_discovery = LLMDiscovery(ports=config.discovery_ports)

    yield

    # Cleanup
    if gpu is not None:
        gpu.shutdown()


# ------------------------------------------------------------------
# App factory
# ------------------------------------------------------------------


def create_app(config: SparkDeckConfig | None = None) -> FastAPI:
    """Build and return a configured FastAPI application."""
    if config is None:
        config = SparkDeckConfig.load()

    app = FastAPI(
        title="SparkDeck Agent",
        version=__version__,
        lifespan=lifespan,
    )
    app.state.config = config

    # Register routes
    app.include_router(_build_router())

    return app


# ------------------------------------------------------------------
# Router
# ------------------------------------------------------------------


def _build_router() -> APIRouter:
    router = APIRouter(prefix="/api")

    # -- GET /api/status ------------------------------------------------

    @router.get("/status", response_model=DeviceStatus)
    async def get_status(
        request: Request,
        _token: str = Depends(require_auth),
    ) -> DeviceStatus:
        """Return a full device status snapshot."""
        gpu_metrics: GPUMetrics | None = None
        gpu_monitor: GPUMonitor | None = request.app.state.gpu_monitor
        if gpu_monitor is not None:
            try:
                gpu_metrics = gpu_monitor.get_metrics()
            except Exception:
                gpu_metrics = None

        docker_mgr: DockerManager = request.app.state.docker_manager
        containers = docker_mgr.list_containers(all=False)

        discovery: LLMDiscovery = request.app.state.llm_discovery
        endpoints = discovery.scan()

        return DeviceStatus(
            hostname=platform.node(),
            agent_version=__version__,
            uptime=_get_device_uptime(),
            tailscale_ip=_get_tailscale_ip(),
            disk_usage=_get_disk_usage(),
            gpu=gpu_metrics,
            containers_running=containers,
            llm_endpoints=endpoints,
        )

    # -- GET /api/gpu/metrics -------------------------------------------

    @router.get("/gpu/metrics", response_model=GPUMetrics)
    async def get_gpu_metrics(
        request: Request,
        _token: str = Depends(require_auth),
    ) -> GPUMetrics:
        """Return current GPU metrics."""
        gpu_monitor: GPUMonitor | None = request.app.state.gpu_monitor
        if gpu_monitor is None:
            raise HTTPException(status_code=503, detail="GPU monitoring unavailable")
        try:
            return gpu_monitor.get_metrics()
        except Exception as exc:
            raise HTTPException(status_code=503, detail=str(exc))

    # -- WS /api/gpu/stream ---------------------------------------------

    @router.websocket("/gpu/stream")
    async def gpu_stream(
        websocket: WebSocket,
        token: str = Query(...),
    ) -> None:
        """Stream GPU metrics over WebSocket at the configured poll interval."""
        app = websocket.app
        if not verify_token(token, app.state.token):
            await websocket.close(code=4001, reason="Invalid token")
            return

        gpu_monitor: GPUMonitor | None = app.state.gpu_monitor
        if gpu_monitor is None:
            await websocket.close(code=4003, reason="GPU monitoring unavailable")
            return

        await websocket.accept()
        config: SparkDeckConfig = app.state.config
        try:
            while True:
                try:
                    metrics = gpu_monitor.get_metrics()
                    await websocket.send_json(metrics.model_dump())
                except Exception as exc:
                    await websocket.send_json({"error": str(exc)})
                await asyncio.sleep(config.gpu_poll_interval)
        except WebSocketDisconnect:
            logger.debug("WebSocket client disconnected")
        except Exception:
            logger.debug("WebSocket connection closed")

    # -- GET /api/containers --------------------------------------------

    @router.get("/containers", response_model=List[ContainerInfo])
    async def list_containers(
        request: Request,
        _token: str = Depends(require_auth),
    ) -> List[ContainerInfo]:
        """Return all Docker containers."""
        docker_mgr: DockerManager = request.app.state.docker_manager
        return docker_mgr.list_containers(all=True)

    # -- POST /api/containers/{id} --------------------------------------

    @router.post("/containers/{container_id}")
    async def container_action(
        container_id: str,
        action: ContainerAction,
        request: Request,
        _token: str = Depends(require_auth),
    ) -> dict:
        """Start or stop a container."""
        docker_mgr: DockerManager = request.app.state.docker_manager
        if action.action == "start":
            ok = docker_mgr.start_container(container_id)
        else:
            ok = docker_mgr.stop_container(container_id)

        if not ok:
            raise HTTPException(
                status_code=400,
                detail=f"Failed to {action.action} container {container_id}",
            )
        return {"status": "ok", "action": action.action, "container_id": container_id}

    # -- GET /api/models ------------------------------------------------

    @router.get("/models", response_model=List[LLMEndpoint])
    async def list_models(
        request: Request,
        _token: str = Depends(require_auth),
    ) -> List[LLMEndpoint]:
        """Return discovered LLM endpoints."""
        discovery: LLMDiscovery = request.app.state.llm_discovery
        return discovery.scan()

    # -- POST /api/chat/proxy ---------------------------------------------

    @router.post("/chat/proxy")
    async def chat_proxy(
        request: Request,
        _token: str = Depends(require_auth),
    ) -> dict:
        """Proxy chat requests to local LLM endpoints.

        Accepts OpenAI-compatible format, forwards to the local LLM
        (Ollama, NIM, vLLM) which is only accessible on localhost.
        Returns the response in OpenAI-compatible format.
        """
        import httpx

        body = await request.json()
        model = body.get("model", "")
        messages = body.get("messages", [])
        thinking = body.get("thinking", False)


        # Discover which local endpoint has this model
        discovery: LLMDiscovery = request.app.state.llm_discovery
        endpoints = discovery.scan()

        target_url = None
        target_type = None
        for ep in endpoints:
            if ep.model_name == model:
                target_url = ep.base_url
                target_type = ep.endpoint_type
                break

        if not target_url:
            target_url = "http://localhost:11434"
            target_type = EndpointType.OLLAMA

        async with httpx.AsyncClient(timeout=300.0, limits=httpx.Limits(max_connections=10)) as client:
            # Ollama uses /api/chat
            if target_type == EndpointType.OLLAMA:
                try:
                    ollama_body = {
                        "model": model,
                        "messages": messages,
                        "stream": False,
                        "think": thinking,
                    }
                    resp = await client.post(f"{target_url}/api/chat", json=ollama_body)
                    if resp.status_code == 200:
                        data = resp.json()
                        return {
                            "id": "chatcmpl-proxy",
                            "object": "chat.completion",
                            "choices": [{
                                "index": 0,
                                "message": data.get("message", {"role": "assistant", "content": ""}),
                                "finish_reason": "stop",
                            }],
                        }
                except Exception:
                    pass

            # OpenAI-compatible API (llama.cpp, vLLM, NIM, etc.)
            try:
                # Add thinking control per backend type
                openai_body = dict(body)
                openai_body.pop("thinking", None)  # Remove our custom field
                if target_type == EndpointType.VLLM:
                    openai_body["enable_thinking"] = thinking
                else:
                    # llama.cpp and others
                    openai_body["chat_template_kwargs"] = {"enable_thinking": thinking}

                resp = await client.post(
                    f"{target_url}/v1/chat/completions",
                    json=openai_body,
                )
                if resp.status_code == 200:
                    data = resp.json()
                    # Handle thinking models: include reasoning in content
                    if "choices" in data:
                        for choice in data["choices"]:
                            msg = choice.get("message", {})
                            reasoning = msg.pop("reasoning_content", None)
                            if reasoning:
                                content = msg.get("content", "")
                                # Wrap reasoning in markers so iOS can render it
                                msg["content"] = f"<thinking>\n{reasoning}\n</thinking>\n\n{content}"
                    return data
            except Exception as exc:
                raise HTTPException(status_code=502, detail=f"LLM proxy failed: {exc}")

        raise HTTPException(status_code=502, detail="Could not reach any LLM endpoint")

    # -- POST /api/notify/register --------------------------------------

    @router.post("/notify/register", response_model=NotifyRegistration, status_code=201)
    async def register_notifications(
        registration: NotifyRegistration,
        request: Request,
        _token: str = Depends(require_auth),
    ) -> NotifyRegistration:
        """Register a device for push notifications (stub -- stores in memory)."""
        logger.info(
            "Notification registration: token=%s events=%s",
            registration.device_token[:8] + "...",
            registration.events,
        )
        return registration

    return router
