"""SparkDeck Agent - Remote AI Command Center for NVIDIA DGX Spark."""

__version__ = "0.1.0"
