"""Docker container management for SparkDeck Agent."""

from __future__ import annotations

import logging
from typing import List

from sparkdeck_agent.models import ContainerInfo

logger = logging.getLogger(__name__)


class DockerManager:
    """Thin wrapper around the Docker SDK.

    Handles the case where the Docker daemon is unavailable (common on
    macOS when Docker Desktop is not running) by setting ``_client`` to
    ``None`` and returning safe defaults from every public method.
    """

    def __init__(self) -> None:
        try:
            import docker

            self._client = docker.from_env()
            # Quick connectivity check
            self._client.ping()
            logger.info("Docker daemon connected")
        except Exception as exc:
            logger.warning("Docker unavailable: %s", exc)
            self._client = None

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def available(self) -> bool:
        """Return ``True`` when the Docker daemon is reachable."""
        return self._client is not None

    # ------------------------------------------------------------------
    # Container operations
    # ------------------------------------------------------------------

    def list_containers(self, all: bool = True) -> List[ContainerInfo]:
        """Return a list of containers visible to the daemon."""
        if self._client is None:
            return []
        try:
            containers = self._client.containers.list(all=all)
            results: List[ContainerInfo] = []
            for c in containers:
                ports: List[str] = []
                port_mapping = c.attrs.get("NetworkSettings", {}).get("Ports") or {}
                for container_port, host_bindings in port_mapping.items():
                    if host_bindings:
                        for binding in host_bindings:
                            host_port = binding.get("HostPort", "")
                            if host_port:
                                ports.append(f"{host_port}->{container_port}")
                    else:
                        ports.append(container_port)
                results.append(
                    ContainerInfo(
                        id=c.short_id,
                        name=c.name,
                        image=",".join(c.image.tags) if c.image.tags else str(c.image.id)[:12],
                        status=c.status,
                        ports=ports,
                    )
                )
            return results
        except Exception as exc:
            logger.error("Failed to list containers: %s", exc)
            return []

    def start_container(self, container_id: str) -> bool:
        """Start a stopped container by *id* or *name*."""
        if self._client is None:
            return False
        try:
            container = self._client.containers.get(container_id)
            container.start()
            logger.info("Started container %s", container_id)
            return True
        except Exception as exc:
            logger.error("Failed to start container %s: %s", container_id, exc)
            return False

    def stop_container(self, container_id: str) -> bool:
        """Stop a running container by *id* or *name*."""
        if self._client is None:
            return False
        try:
            container = self._client.containers.get(container_id)
            container.stop()
            logger.info("Stopped container %s", container_id)
            return True
        except Exception as exc:
            logger.error("Failed to stop container %s: %s", container_id, exc)
            return False
