"""LLM endpoint discovery for SparkDeck Agent."""

from __future__ import annotations

import logging
from typing import Dict, List, Tuple

import httpx

from sparkdeck_agent.models import EndpointType, LLMEndpoint

logger = logging.getLogger(__name__)

# Default timeout for probing endpoints (seconds).
_TIMEOUT = 2.0

# Map of well-known ports to (friendly name, endpoint type).
KNOWN_ENDPOINTS: Dict[int, Tuple[str, EndpointType]] = {
    11434: ("Ollama", EndpointType.OLLAMA),
    8000: ("vLLM / OpenAI-compatible", EndpointType.VLLM),
    5000: ("OpenAI-compatible", EndpointType.OPENAI),
    8080: ("llama.cpp", EndpointType.CUSTOM),
    8081: ("llama.cpp", EndpointType.CUSTOM),
}


class LLMDiscovery:
    """Scan localhost (or a given host) for running LLM inference servers."""

    def __init__(self, ports: List[int] | None = None) -> None:
        self.ports = ports or list(KNOWN_ENDPOINTS.keys())

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def scan(self, host: str = "localhost") -> List[LLMEndpoint]:
        """Probe all known ports and return any discovered endpoints."""
        endpoints: List[LLMEndpoint] = []
        for port in self.ports:
            name, ep_type = KNOWN_ENDPOINTS.get(port, ("Unknown", EndpointType.CUSTOM))
            base_url = f"http://{host}:{port}"

            if ep_type == EndpointType.OLLAMA:
                found = self._check_ollama(base_url, name)
            else:
                found = self._check_openai_compatible(base_url, name, ep_type)

            endpoints.extend(found)
        return endpoints

    # ------------------------------------------------------------------
    # Internal probes
    # ------------------------------------------------------------------

    def _check_ollama(
        self, base_url: str, name: str
    ) -> List[LLMEndpoint]:
        """Probe an Ollama instance via ``GET /api/tags``."""
        try:
            resp = httpx.get(f"{base_url}/api/tags", timeout=_TIMEOUT)
            resp.raise_for_status()
            data = resp.json()
            models = data.get("models", [])
            if not models:
                return [
                    LLMEndpoint(
                        name=name,
                        base_url=base_url,
                        model_name="(no models loaded)",
                        endpoint_type=EndpointType.OLLAMA,
                        online=True,
                    )
                ]
            return [
                LLMEndpoint(
                    name=name,
                    base_url=base_url,
                    model_name=m.get("name", "unknown"),
                    endpoint_type=EndpointType.OLLAMA,
                    online=True,
                )
                for m in models
            ]
        except Exception as exc:
            logger.debug("Ollama not found at %s: %s", base_url, exc)
            return []

    def _check_openai_compatible(
        self, base_url: str, name: str, ep_type: EndpointType
    ) -> List[LLMEndpoint]:
        """Probe an OpenAI-compatible server via ``GET /v1/models``."""
        try:
            resp = httpx.get(f"{base_url}/v1/models", timeout=_TIMEOUT)
            resp.raise_for_status()
            data = resp.json()
            models = data.get("data", [])
            if not models:
                return [
                    LLMEndpoint(
                        name=name,
                        base_url=base_url,
                        model_name="(no models listed)",
                        endpoint_type=ep_type,
                        online=True,
                    )
                ]
            return [
                LLMEndpoint(
                    name=name,
                    base_url=base_url,
                    model_name=m.get("id", "unknown"),
                    endpoint_type=ep_type,
                    online=True,
                )
                for m in models
            ]
        except Exception as exc:
            logger.debug("OpenAI-compatible server not found at %s: %s", base_url, exc)
            return []
