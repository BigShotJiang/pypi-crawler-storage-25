"""Standalone runner for systemd ExecStart.

Usage::

    python -m sparkdeck_agent.server_runner

Loads config from the default location, creates the FastAPI app, and
starts uvicorn.  This module is intentionally kept minimal so that the
systemd unit file can point directly at it.
"""

from __future__ import annotations

import uvicorn

from sparkdeck_agent.config import SparkDeckConfig
from sparkdeck_agent.server import create_app


def run() -> None:
    """Load configuration, create the app, and start uvicorn."""
    config = SparkDeckConfig.load()
    app = create_app(config)
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=config.port,
        log_level=config.log_level,
    )


if __name__ == "__main__":
    run()
