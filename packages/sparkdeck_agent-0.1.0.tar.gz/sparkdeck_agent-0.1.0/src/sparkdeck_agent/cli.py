"""CLI entry point for SparkDeck Agent."""

from __future__ import annotations

import shutil
import subprocess
import sys
import textwrap
from pathlib import Path

import click

from sparkdeck_agent import __version__
from sparkdeck_agent.auth import load_or_create_token
from sparkdeck_agent.config import SparkDeckConfig

SYSTEMD_SERVICE_NAME = "sparkdeck-agent"


def _systemd_unit_path() -> Path:
    """Return the path for the user-level systemd unit file."""
    return Path.home() / ".config" / "systemd" / "user" / f"{SYSTEMD_SERVICE_NAME}.service"


def _write_systemd_unit(config: SparkDeckConfig) -> Path:
    """Generate and write a systemd user service unit file."""
    python = shutil.which("python3") or sys.executable
    unit = textwrap.dedent(f"""\
        [Unit]
        Description=SparkDeck Agent
        After=network.target

        [Service]
        Type=simple
        ExecStart={python} -m sparkdeck_agent.server_runner
        Restart=on-failure
        RestartSec=5
        Environment=PYTHONUNBUFFERED=1

        [Install]
        WantedBy=default.target
    """)
    unit_path = _systemd_unit_path()
    unit_path.parent.mkdir(parents=True, exist_ok=True)
    unit_path.write_text(unit)
    return unit_path


@click.group()
@click.version_option(version=__version__, prog_name="sparkdeck-agent")
def main() -> None:
    """SparkDeck Agent - Remote AI Command Center for DGX Spark."""


@main.command()
@click.option("--port", type=int, default=None, help="Port to listen on (default: 8420).")
@click.option("--daemon", is_flag=True, default=False, help="Install and start as a systemd user service.")
def start(port: int | None, daemon: bool) -> None:
    """Start the SparkDeck Agent."""
    config = SparkDeckConfig.load()
    if port is not None:
        config.port = port

    if daemon:
        _write_systemd_unit(config)
        click.echo(f"Systemd unit written to {_systemd_unit_path()}")
        subprocess.run(["systemctl", "--user", "daemon-reload"], check=False)
        subprocess.run(
            ["systemctl", "--user", "enable", "--now", SYSTEMD_SERVICE_NAME],
            check=False,
        )
        click.echo(f"Service {SYSTEMD_SERVICE_NAME} enabled and started.")
    else:
        import uvicorn

        from sparkdeck_agent.server import create_app

        click.echo(f"Starting SparkDeck Agent v{__version__} on port {config.port} ...")
        app = create_app(config)
        uvicorn.run(
            app,
            host="0.0.0.0",
            port=config.port,
            log_level=config.log_level,
        )


@main.command()
def stop() -> None:
    """Stop the SparkDeck Agent daemon."""
    if not shutil.which("systemctl"):
        click.echo("systemctl not found (systemd is required for daemon mode).")
        sys.exit(1)
    result = subprocess.run(
        ["systemctl", "--user", "stop", SYSTEMD_SERVICE_NAME],
        capture_output=True,
        text=True,
    )
    if result.returncode == 0:
        click.echo(f"Service {SYSTEMD_SERVICE_NAME} stopped.")
    else:
        click.echo(f"Failed to stop service: {result.stderr.strip() or 'unknown error'}")
        sys.exit(1)


@main.command()
def status() -> None:
    """Show agent version, config, and daemon state."""
    config = SparkDeckConfig.load()

    click.echo(f"SparkDeck Agent v{__version__}")
    click.echo(f"  Port:              {config.port}")
    click.echo(f"  Log level:         {config.log_level}")
    click.echo(f"  GPU poll interval: {config.gpu_poll_interval}s")
    click.echo(f"  Discovery ports:   {config.discovery_ports}")
    click.echo(f"  Config dir:        {config.config_dir}")

    # Check systemd daemon state
    if shutil.which("systemctl"):
        result = subprocess.run(
            ["systemctl", "--user", "is-active", SYSTEMD_SERVICE_NAME],
            capture_output=True,
            text=True,
        )
        daemon_state = result.stdout.strip() if result.returncode == 0 else "inactive"
    else:
        daemon_state = "n/a (systemctl not found)"
    click.echo(f"  Daemon:            {daemon_state}")


@main.command()
@click.option("--reset", is_flag=True, default=False, help="Generate a new token.")
def token(reset: bool) -> None:
    """Show (or reset) the auth token."""
    config = SparkDeckConfig.load()
    config.ensure_dirs()

    if reset:
        # Remove the existing token so load_or_create_token generates a new one
        if config.token_path.exists():
            config.token_path.unlink()
        click.echo("Token reset.")

    tok = load_or_create_token(config.token_path)
    click.echo(tok)


@main.command("config")
def show_config() -> None:
    """Show current configuration values."""
    config = SparkDeckConfig.load()

    click.echo(f"port             = {config.port}")
    click.echo(f"log_level        = {config.log_level}")
    click.echo(f"gpu_poll_interval = {config.gpu_poll_interval}")
    click.echo(f"discovery_ports  = {config.discovery_ports}")
    click.echo(f"config_dir       = {config.config_dir}")
    click.echo(f"token_path       = {config.token_path}")
    click.echo(f"config_path      = {config.config_path}")
