"""Configuration management for SparkDeck Agent."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

DEFAULT_CONFIG_DIR = Path.home() / ".config" / "sparkdeck"
DEFAULT_PORT = 8420
DEFAULT_DISCOVERY_PORTS = [11434, 8000, 5000, 8080, 8081]


@dataclass
class SparkDeckConfig:
    port: int = DEFAULT_PORT
    log_level: str = "info"
    gpu_poll_interval: float = 1.0
    discovery_ports: list[int] = field(default_factory=lambda: list(DEFAULT_DISCOVERY_PORTS))
    config_dir: Path | str = DEFAULT_CONFIG_DIR

    def __post_init__(self):
        self.config_dir = Path(self.config_dir)

    @property
    def token_path(self) -> Path:
        return self.config_dir / "token"

    @property
    def config_path(self) -> Path:
        return self.config_dir / "config.toml"

    def ensure_dirs(self):
        self.config_dir.mkdir(parents=True, exist_ok=True)

    def save(self):
        import tomli_w
        self.ensure_dirs()
        data = {
            "port": self.port,
            "log_level": self.log_level,
            "gpu_poll_interval": self.gpu_poll_interval,
            "discovery_ports": self.discovery_ports,
        }
        self.config_path.write_bytes(tomli_w.dumps(data).encode())

    @classmethod
    def load(cls, config_dir: Path | str = DEFAULT_CONFIG_DIR) -> SparkDeckConfig:
        config_dir = Path(config_dir)
        config_path = config_dir / "config.toml"
        if not config_path.exists():
            return cls(config_dir=config_dir)
        try:
            import tomllib
            data = tomllib.loads(config_path.read_text())
            return cls(config_dir=config_dir, **data)
        except Exception:
            return cls(config_dir=config_dir)
