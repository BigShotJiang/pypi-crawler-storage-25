"""Tests for the FastAPI server."""

from __future__ import annotations

from contextlib import asynccontextmanager
from unittest.mock import MagicMock, patch

import pytest
from httpx import ASGITransport, AsyncClient

from sparkdeck_agent.config import SparkDeckConfig
from sparkdeck_agent.models import GPUMetrics
from sparkdeck_agent.server import create_app


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

TEST_TOKEN = "testtoken1234567890abcdef1234567890abcdef1234567890abcdef12345678"


def _make_gpu_metrics() -> GPUMetrics:
    return GPUMetrics(
        gpu_name="Test GPU",
        utilization=50.0,
        memory_used=4096,
        memory_total=16384,
        temperature=60.0,
        power_draw=200.0,
        fan_speed=40.0,
    )


@pytest.fixture()
def config(tmp_path):
    cfg = SparkDeckConfig(config_dir=str(tmp_path), gpu_poll_interval=0.1)
    cfg.ensure_dirs()
    token_path = cfg.token_path
    token_path.write_text(TEST_TOKEN)
    return cfg


@pytest.fixture()
def mock_gpu():
    gpu = MagicMock()
    gpu.get_metrics.return_value = _make_gpu_metrics()
    gpu.shutdown.return_value = None
    return gpu


@pytest.fixture()
def mock_docker():
    dm = MagicMock()
    dm.available = True
    dm.list_containers.return_value = []
    dm.start_container.return_value = True
    dm.stop_container.return_value = True
    return dm


@pytest.fixture()
def mock_discovery():
    disc = MagicMock()
    disc.scan.return_value = []
    return disc


@asynccontextmanager
async def _noop_lifespan(app):
    """A no-op lifespan so that the test controls state setup."""
    yield


@pytest.fixture()
def app(config, mock_gpu, mock_docker, mock_discovery):
    """Create a test app with mocked subsystems and manually-set state."""
    with patch("sparkdeck_agent.server.lifespan", new=_noop_lifespan):
        application = create_app(config)

    # Manually set the state that lifespan would set
    application.state.token = TEST_TOKEN
    application.state.gpu_monitor = mock_gpu
    application.state.docker_manager = mock_docker
    application.state.llm_discovery = mock_discovery
    return application


@pytest.fixture()
async def client(app):
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac


def auth_headers(token: str = TEST_TOKEN) -> dict:
    return {"Authorization": f"Bearer {token}"}


# ---------------------------------------------------------------------------
# Auth tests
# ---------------------------------------------------------------------------


class TestAuth:
    @pytest.mark.asyncio
    async def test_no_auth_returns_403(self, client):
        resp = await client.get("/api/status")
        assert resp.status_code in (401, 403)

    @pytest.mark.asyncio
    async def test_bad_token_returns_401(self, client):
        resp = await client.get("/api/status", headers=auth_headers("wrongtoken"))
        assert resp.status_code == 401

    @pytest.mark.asyncio
    async def test_valid_token_returns_200(self, client):
        resp = await client.get("/api/status", headers=auth_headers())
        assert resp.status_code == 200


# ---------------------------------------------------------------------------
# GET /api/status
# ---------------------------------------------------------------------------


class TestGetStatus:
    @pytest.mark.asyncio
    async def test_status_returns_device_status(self, client):
        resp = await client.get("/api/status", headers=auth_headers())
        assert resp.status_code == 200
        data = resp.json()
        assert "hostname" in data
        assert data["agent_version"] == "0.1.0"
        assert "uptime" in data

    @pytest.mark.asyncio
    async def test_status_includes_gpu(self, client):
        resp = await client.get("/api/status", headers=auth_headers())
        data = resp.json()
        assert data["gpu"] is not None
        assert data["gpu"]["gpu_name"] == "Test GPU"


# ---------------------------------------------------------------------------
# GET /api/gpu/metrics
# ---------------------------------------------------------------------------


class TestGetGPUMetrics:
    @pytest.mark.asyncio
    async def test_gpu_metrics_returns_200(self, client):
        resp = await client.get("/api/gpu/metrics", headers=auth_headers())
        assert resp.status_code == 200
        data = resp.json()
        assert data["gpu_name"] == "Test GPU"
        assert data["utilization"] == 50.0

    @pytest.mark.asyncio
    async def test_gpu_metrics_no_gpu_returns_503(self, config):
        """When GPU is unavailable the endpoint should return 503."""
        with patch("sparkdeck_agent.server.lifespan", new=_noop_lifespan):
            application = create_app(config)

        application.state.token = TEST_TOKEN
        application.state.gpu_monitor = None
        application.state.docker_manager = MagicMock()
        application.state.llm_discovery = MagicMock()

        transport = ASGITransport(app=application)
        async with AsyncClient(transport=transport, base_url="http://test") as ac:
            resp = await ac.get("/api/gpu/metrics", headers=auth_headers())
            assert resp.status_code == 503


# ---------------------------------------------------------------------------
# GET /api/containers
# ---------------------------------------------------------------------------


class TestListContainers:
    @pytest.mark.asyncio
    async def test_empty_containers(self, client):
        resp = await client.get("/api/containers", headers=auth_headers())
        assert resp.status_code == 200
        assert resp.json() == []


# ---------------------------------------------------------------------------
# POST /api/containers/{id}
# ---------------------------------------------------------------------------


class TestContainerAction:
    @pytest.mark.asyncio
    async def test_start_container(self, client, mock_docker):
        resp = await client.post(
            "/api/containers/abc123",
            json={"action": "start"},
            headers=auth_headers(),
        )
        assert resp.status_code == 200
        assert resp.json()["status"] == "ok"
        mock_docker.start_container.assert_called_once_with("abc123")

    @pytest.mark.asyncio
    async def test_stop_container(self, client, mock_docker):
        resp = await client.post(
            "/api/containers/abc123",
            json={"action": "stop"},
            headers=auth_headers(),
        )
        assert resp.status_code == 200
        mock_docker.stop_container.assert_called_once_with("abc123")

    @pytest.mark.asyncio
    async def test_invalid_action(self, client):
        resp = await client.post(
            "/api/containers/abc123",
            json={"action": "restart"},
            headers=auth_headers(),
        )
        assert resp.status_code == 422

    @pytest.mark.asyncio
    async def test_failed_action(self, client, mock_docker):
        mock_docker.start_container.return_value = False
        resp = await client.post(
            "/api/containers/abc123",
            json={"action": "start"},
            headers=auth_headers(),
        )
        assert resp.status_code == 400


# ---------------------------------------------------------------------------
# GET /api/models
# ---------------------------------------------------------------------------


class TestListModels:
    @pytest.mark.asyncio
    async def test_empty_models(self, client):
        resp = await client.get("/api/models", headers=auth_headers())
        assert resp.status_code == 200
        assert resp.json() == []


# ---------------------------------------------------------------------------
# POST /api/notify/register
# ---------------------------------------------------------------------------


class TestNotifyRegister:
    @pytest.mark.asyncio
    async def test_register_notification(self, client):
        resp = await client.post(
            "/api/notify/register",
            json={"device_token": "tok123", "events": ["gpu_overheat"]},
            headers=auth_headers(),
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["device_token"] == "tok123"
        assert data["events"] == ["gpu_overheat"]

    @pytest.mark.asyncio
    async def test_register_empty_token_fails(self, client):
        resp = await client.post(
            "/api/notify/register",
            json={"device_token": "", "events": ["e"]},
            headers=auth_headers(),
        )
        assert resp.status_code == 422

    @pytest.mark.asyncio
    async def test_register_empty_events_fails(self, client):
        resp = await client.post(
            "/api/notify/register",
            json={"device_token": "tok", "events": []},
            headers=auth_headers(),
        )
        assert resp.status_code == 422
