"""Tests for the SparkDeck Agent CLI."""

from __future__ import annotations

from unittest.mock import patch

import pytest
from click.testing import CliRunner

from sparkdeck_agent import __version__
from sparkdeck_agent.cli import main


@pytest.fixture()
def runner():
    return CliRunner()


class TestCLIGroup:
    def test_version(self, runner):
        result = runner.invoke(main, ["--version"])
        assert result.exit_code == 0
        assert __version__ in result.output

    def test_help(self, runner):
        result = runner.invoke(main, ["--help"])
        assert result.exit_code == 0
        assert "SparkDeck Agent" in result.output


class TestTokenCommand:
    def test_token_show(self, runner, tmp_path):
        with patch("sparkdeck_agent.cli.SparkDeckConfig.load") as mock_load:
            cfg = _make_config(tmp_path)
            mock_load.return_value = cfg
            result = runner.invoke(main, ["token"])
            assert result.exit_code == 0
            # Should print a 64-char hex token
            token = result.output.strip()
            assert len(token) == 64

    def test_token_reset(self, runner, tmp_path):
        with patch("sparkdeck_agent.cli.SparkDeckConfig.load") as mock_load:
            cfg = _make_config(tmp_path)
            mock_load.return_value = cfg
            # First call to get the initial token
            r1 = runner.invoke(main, ["token"])
            token1 = r1.output.strip()
            # Reset
            r2 = runner.invoke(main, ["token", "--reset"])
            assert "Token reset" in r2.output
            token2 = r2.output.strip().split("\n")[-1]
            # Tokens should differ
            assert token1 != token2


class TestStatusCommand:
    def test_status_shows_version(self, runner, tmp_path):
        with patch("sparkdeck_agent.cli.SparkDeckConfig.load") as mock_load, \
             patch("sparkdeck_agent.cli.subprocess") as mock_sp:
            mock_load.return_value = _make_config(tmp_path)
            mock_sp.run.return_value.returncode = 1
            mock_sp.run.return_value.stdout = ""
            result = runner.invoke(main, ["status"])
            assert result.exit_code == 0
            assert __version__ in result.output
            assert "8420" in result.output


class TestConfigCommand:
    def test_config_shows_values(self, runner, tmp_path):
        with patch("sparkdeck_agent.cli.SparkDeckConfig.load") as mock_load:
            mock_load.return_value = _make_config(tmp_path)
            result = runner.invoke(main, ["config"])
            assert result.exit_code == 0
            assert "8420" in result.output
            assert "info" in result.output


class TestStartCommand:
    def test_start_daemon_installs_service(self, runner, tmp_path):
        with patch("sparkdeck_agent.cli.SparkDeckConfig.load") as mock_load, \
             patch("sparkdeck_agent.cli.subprocess") as mock_sp, \
             patch("sparkdeck_agent.cli._systemd_unit_path") as mock_path:
            mock_load.return_value = _make_config(tmp_path)
            mock_sp.run.return_value.returncode = 0
            unit_file = tmp_path / "sparkdeck-agent.service"
            mock_path.return_value = unit_file
            result = runner.invoke(main, ["start", "--daemon"])
            assert result.exit_code == 0
            assert "enabled and started" in result.output
            assert unit_file.exists()


class TestStopCommand:
    def test_stop_success(self, runner):
        with patch("sparkdeck_agent.cli.subprocess") as mock_sp, \
             patch("sparkdeck_agent.cli.shutil.which", return_value="/usr/bin/systemctl"):
            mock_sp.run.return_value.returncode = 0
            result = runner.invoke(main, ["stop"])
            assert result.exit_code == 0
            assert "stopped" in result.output

    def test_stop_failure(self, runner):
        with patch("sparkdeck_agent.cli.subprocess") as mock_sp, \
             patch("sparkdeck_agent.cli.shutil.which", return_value="/usr/bin/systemctl"):
            mock_sp.run.return_value.returncode = 1
            mock_sp.run.return_value.stderr = "Unit not loaded"
            result = runner.invoke(main, ["stop"])
            assert result.exit_code == 1

    def test_stop_no_systemctl(self, runner):
        with patch("sparkdeck_agent.cli.shutil.which", return_value=None):
            result = runner.invoke(main, ["stop"])
            assert result.exit_code == 1
            assert "systemctl not found" in result.output


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_config(tmp_path):
    from sparkdeck_agent.config import SparkDeckConfig

    cfg = SparkDeckConfig(config_dir=str(tmp_path))
    cfg.ensure_dirs()
    return cfg
