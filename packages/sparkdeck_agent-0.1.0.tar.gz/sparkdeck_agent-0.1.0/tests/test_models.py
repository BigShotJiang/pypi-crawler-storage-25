"""Tests for SparkDeck Agent Pydantic models."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from sparkdeck_agent.models import (
    ContainerAction,
    ContainerInfo,
    DeviceStatus,
    EndpointType,
    GPUMetrics,
    LLMEndpoint,
    NotifyRegistration,
)


# ---------------------------------------------------------------------------
# GPUMetrics
# ---------------------------------------------------------------------------

class TestGPUMetrics:
    def _sample(self, **overrides) -> dict:
        defaults = dict(
            gpu_name="NVIDIA GR00T GPU",
            utilization=75.0,
            memory_used=8192,
            memory_total=16384,
            temperature=62.0,
            power_draw=250.0,
            fan_speed=55.0,
        )
        defaults.update(overrides)
        return defaults

    def test_valid_gpu_metrics(self):
        m = GPUMetrics(**self._sample())
        assert m.gpu_name == "NVIDIA GR00T GPU"
        assert m.utilization == 75.0
        assert m.memory_used == 8192
        assert m.memory_total == 16384

    def test_computed_memory_utilization(self):
        m = GPUMetrics(**self._sample(memory_used=4096, memory_total=16384))
        assert m.memory_utilization == 25.0

    def test_memory_utilization_rounding(self):
        m = GPUMetrics(**self._sample(memory_used=1000, memory_total=3000))
        assert m.memory_utilization == 33.33

    def test_memory_utilization_in_serialization(self):
        m = GPUMetrics(**self._sample())
        data = m.model_dump()
        assert "memory_utilization" in data
        assert data["memory_utilization"] == 50.0

    def test_utilization_out_of_range(self):
        with pytest.raises(ValidationError):
            GPUMetrics(**self._sample(utilization=101))

    def test_negative_memory_used(self):
        with pytest.raises(ValidationError):
            GPUMetrics(**self._sample(memory_used=-1))

    def test_zero_memory_total_rejected(self):
        with pytest.raises(ValidationError):
            GPUMetrics(**self._sample(memory_total=0))

    def test_fan_speed_out_of_range(self):
        with pytest.raises(ValidationError):
            GPUMetrics(**self._sample(fan_speed=110))


# ---------------------------------------------------------------------------
# ContainerInfo
# ---------------------------------------------------------------------------

class TestContainerInfo:
    def test_valid_container(self):
        c = ContainerInfo(
            id="abc123",
            name="my-container",
            image="nginx:latest",
            status="running",
            ports=["80/tcp", "443/tcp"],
        )
        assert c.id == "abc123"
        assert c.name == "my-container"
        assert len(c.ports) == 2

    def test_empty_ports_default(self):
        c = ContainerInfo(
            id="abc123",
            name="my-container",
            image="nginx:latest",
            status="running",
        )
        assert c.ports == []

    def test_serialization_round_trip(self):
        data = dict(
            id="x", name="n", image="img", status="running", ports=["8080/tcp"]
        )
        c = ContainerInfo(**data)
        assert c.model_dump() == data


# ---------------------------------------------------------------------------
# LLMEndpoint
# ---------------------------------------------------------------------------

class TestLLMEndpoint:
    def test_valid_endpoint(self):
        ep = LLMEndpoint(
            name="local-ollama",
            base_url="http://localhost:11434",
            model_name="llama3",
            endpoint_type=EndpointType.OLLAMA,
            online=True,
        )
        assert ep.endpoint_type == EndpointType.OLLAMA
        assert ep.online is True

    def test_endpoint_type_from_string(self):
        ep = LLMEndpoint(
            name="vllm-server",
            base_url="http://localhost:8000",
            model_name="mistral-7b",
            endpoint_type="vllm",
        )
        assert ep.endpoint_type == EndpointType.VLLM

    def test_online_defaults_true(self):
        ep = LLMEndpoint(
            name="ep",
            base_url="http://localhost",
            model_name="m",
            endpoint_type="custom",
        )
        assert ep.online is True

    def test_invalid_endpoint_type(self):
        with pytest.raises(ValidationError):
            LLMEndpoint(
                name="ep",
                base_url="http://localhost",
                model_name="m",
                endpoint_type="nonexistent",
            )


# ---------------------------------------------------------------------------
# DeviceStatus
# ---------------------------------------------------------------------------

class TestDeviceStatus:
    def test_minimal_device_status(self):
        ds = DeviceStatus(
            hostname="dgx-spark-01",
            agent_version="0.1.0",
            uptime="up 2 hours, 30 minutes",
        )
        assert ds.hostname == "dgx-spark-01"
        assert ds.uptime == "up 2 hours, 30 minutes"
        assert ds.disk_usage is None
        assert ds.gpu is None
        assert ds.containers_running == []
        assert ds.llm_endpoints == []

    def test_full_device_status(self):
        gpu = GPUMetrics(
            gpu_name="GPU",
            utilization=50,
            memory_used=4096,
            memory_total=16384,
            temperature=60,
            power_draw=200,
            fan_speed=40,
        )
        container = ContainerInfo(
            id="c1", name="web", image="nginx", status="running"
        )
        endpoint = LLMEndpoint(
            name="ollama",
            base_url="http://localhost:11434",
            model_name="llama3",
            endpoint_type="ollama",
        )
        ds = DeviceStatus(
            hostname="dgx-spark-01",
            agent_version="0.1.0",
            uptime="up 2 hours",
            disk_usage="420G/1.8T (25%)",
            gpu=gpu,
            containers_running=[container],
            llm_endpoints=[endpoint],
        )
        assert ds.gpu is not None
        assert ds.gpu.memory_utilization == 25.0
        assert len(ds.containers_running) == 1
        assert len(ds.llm_endpoints) == 1
        assert ds.disk_usage == "420G/1.8T (25%)"

    def test_serialization_includes_nested(self):
        gpu = GPUMetrics(
            gpu_name="GPU",
            utilization=10,
            memory_used=100,
            memory_total=1000,
            temperature=50,
            power_draw=100,
            fan_speed=30,
        )
        ds = DeviceStatus(
            hostname="h",
            agent_version="0.1.0",
            uptime="up 1 day",
            gpu=gpu,
        )
        data = ds.model_dump()
        assert data["gpu"]["memory_utilization"] == 10.0


# ---------------------------------------------------------------------------
# ContainerAction
# ---------------------------------------------------------------------------

class TestContainerAction:
    def test_start_action(self):
        a = ContainerAction(action="start")
        assert a.action == "start"

    def test_stop_action(self):
        a = ContainerAction(action="stop")
        assert a.action == "stop"

    def test_invalid_action(self):
        with pytest.raises(ValidationError):
            ContainerAction(action="restart")


# ---------------------------------------------------------------------------
# NotifyRegistration
# ---------------------------------------------------------------------------

class TestNotifyRegistration:
    def test_valid_registration(self):
        nr = NotifyRegistration(
            device_token="abc123token",
            events=["gpu_overheat", "container_crash"],
        )
        assert nr.device_token == "abc123token"
        assert len(nr.events) == 2

    def test_empty_token_rejected(self):
        with pytest.raises(ValidationError):
            NotifyRegistration(device_token="", events=["e"])

    def test_empty_events_rejected(self):
        with pytest.raises(ValidationError):
            NotifyRegistration(device_token="tok", events=[])
