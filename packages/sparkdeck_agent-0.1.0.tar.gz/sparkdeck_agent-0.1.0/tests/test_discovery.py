"""Tests for LLM endpoint discovery."""

from __future__ import annotations

from unittest.mock import patch, MagicMock

import httpx
import pytest

from sparkdeck_agent.discovery import LLMDiscovery, KNOWN_ENDPOINTS
from sparkdeck_agent.models import EndpointType


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _mock_response(json_data: dict, status_code: int = 200) -> httpx.Response:
    """Build a fake ``httpx.Response``."""
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status_code
    resp.json.return_value = json_data
    resp.raise_for_status.return_value = None
    if status_code >= 400:
        resp.raise_for_status.side_effect = httpx.HTTPStatusError(
            "error", request=MagicMock(), response=resp
        )
    return resp


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestLLMDiscovery:
    """Unit tests for :class:`LLMDiscovery`."""

    def test_scan_ollama_with_models(self):
        """Ollama returns two loaded models."""
        discovery = LLMDiscovery(ports=[11434])
        ollama_resp = _mock_response(
            {"models": [{"name": "llama3"}, {"name": "mistral"}]}
        )
        with patch("sparkdeck_agent.discovery.httpx.get", return_value=ollama_resp):
            endpoints = discovery.scan()

        assert len(endpoints) == 2
        assert endpoints[0].model_name == "llama3"
        assert endpoints[1].model_name == "mistral"
        assert all(e.endpoint_type == EndpointType.OLLAMA for e in endpoints)
        assert all(e.online is True for e in endpoints)

    def test_scan_ollama_no_models(self):
        """Ollama is running but has no models loaded."""
        discovery = LLMDiscovery(ports=[11434])
        ollama_resp = _mock_response({"models": []})
        with patch("sparkdeck_agent.discovery.httpx.get", return_value=ollama_resp):
            endpoints = discovery.scan()

        assert len(endpoints) == 1
        assert endpoints[0].model_name == "(no models loaded)"

    def test_scan_openai_compatible(self):
        """OpenAI-compatible endpoint returns one model."""
        discovery = LLMDiscovery(ports=[8000])
        oai_resp = _mock_response(
            {"data": [{"id": "meta-llama/Llama-3-8B"}]}
        )
        with patch("sparkdeck_agent.discovery.httpx.get", return_value=oai_resp):
            endpoints = discovery.scan()

        assert len(endpoints) == 1
        assert endpoints[0].model_name == "meta-llama/Llama-3-8B"
        assert endpoints[0].endpoint_type == EndpointType.VLLM

    def test_scan_openai_compatible_no_models(self):
        """OpenAI-compatible endpoint has no listed models."""
        discovery = LLMDiscovery(ports=[5000])
        oai_resp = _mock_response({"data": []})
        with patch("sparkdeck_agent.discovery.httpx.get", return_value=oai_resp):
            endpoints = discovery.scan()

        assert len(endpoints) == 1
        assert endpoints[0].model_name == "(no models listed)"

    def test_scan_connection_error(self):
        """Unreachable endpoint returns an empty list."""
        discovery = LLMDiscovery(ports=[11434])
        with patch(
            "sparkdeck_agent.discovery.httpx.get",
            side_effect=httpx.ConnectError("connection refused"),
        ):
            endpoints = discovery.scan()

        assert endpoints == []

    def test_scan_http_error(self):
        """HTTP 500 from an endpoint returns an empty list."""
        discovery = LLMDiscovery(ports=[8000])
        bad_resp = _mock_response({}, status_code=500)
        with patch("sparkdeck_agent.discovery.httpx.get", return_value=bad_resp):
            endpoints = discovery.scan()

        assert endpoints == []

    def test_scan_multiple_ports(self):
        """Scanning multiple ports aggregates results."""
        discovery = LLMDiscovery(ports=[11434, 8000])

        ollama_resp = _mock_response({"models": [{"name": "llama3"}]})
        oai_resp = _mock_response({"data": [{"id": "gpt-custom"}]})

        def route_get(url: str, **kwargs):
            if "11434" in url:
                return ollama_resp
            return oai_resp

        with patch("sparkdeck_agent.discovery.httpx.get", side_effect=route_get):
            endpoints = discovery.scan()

        assert len(endpoints) == 2
        names = {e.model_name for e in endpoints}
        assert names == {"llama3", "gpt-custom"}

    def test_known_endpoints_dict(self):
        """Sanity-check the KNOWN_ENDPOINTS mapping."""
        assert 11434 in KNOWN_ENDPOINTS
        assert KNOWN_ENDPOINTS[11434][1] == EndpointType.OLLAMA
