import pytest
from pathlib import Path
from sparkdeck_agent.auth import generate_token, verify_token, load_or_create_token


def test_generate_token():
    token = generate_token()
    assert len(token) == 64  # 32 bytes hex
    assert token.isalnum()


def test_generate_token_unique():
    t1 = generate_token()
    t2 = generate_token()
    assert t1 != t2


def test_verify_token():
    token = "abc123"
    assert verify_token("abc123", token) is True
    assert verify_token("wrong", token) is False
    assert verify_token("", token) is False


def test_load_or_create_token_creates(tmp_path):
    token_path = tmp_path / "token"
    token = load_or_create_token(token_path)
    assert len(token) == 64
    assert token_path.read_text().strip() == token


def test_load_or_create_token_loads_existing(tmp_path):
    token_path = tmp_path / "token"
    token_path.write_text("existingtoken123")
    token = load_or_create_token(token_path)
    assert token == "existingtoken123"
