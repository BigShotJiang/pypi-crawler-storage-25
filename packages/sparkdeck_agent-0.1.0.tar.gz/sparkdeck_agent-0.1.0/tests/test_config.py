import pytest
from pathlib import Path
from sparkdeck_agent.config import SparkDeckConfig


def test_default_config():
    config = SparkDeckConfig()
    assert config.port == 8420
    assert config.log_level == "info"
    assert config.gpu_poll_interval == 1.0
    assert 11434 in config.discovery_ports


def test_config_from_dict():
    config = SparkDeckConfig(port=9000, log_level="debug")
    assert config.port == 9000
    assert config.log_level == "debug"


def test_config_dir(tmp_path):
    config = SparkDeckConfig(config_dir=str(tmp_path))
    assert config.config_dir == tmp_path
    assert config.token_path == tmp_path / "token"
    assert config.config_path == tmp_path / "config.toml"
