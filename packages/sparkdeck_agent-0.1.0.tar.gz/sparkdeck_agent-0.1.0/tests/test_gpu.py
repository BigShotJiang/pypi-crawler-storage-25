"""Tests for GPUMonitor with fully-mocked pynvml."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from sparkdeck_agent.gpu import GPUMonitor


@pytest.fixture()
def mock_nvml():
    with patch("sparkdeck_agent.gpu.pynvml") as mock:
        mock.nvmlInit = MagicMock()
        mock.nvmlShutdown = MagicMock()
        mock.nvmlDeviceGetCount.return_value = 1
        mock.NVML_TEMPERATURE_GPU = 0

        handle = MagicMock()
        mock.nvmlDeviceGetHandleByIndex.return_value = handle
        mock.nvmlDeviceGetName.return_value = "NVIDIA GB10"

        util = MagicMock()
        util.gpu = 45
        mock.nvmlDeviceGetUtilizationRates.return_value = util

        mem = MagicMock()
        mem.used = 1024 * 1024 * 1024  # 1 GB in bytes
        mem.total = 32 * 1024 * 1024 * 1024  # 32 GB in bytes
        mock.nvmlDeviceGetMemoryInfo.return_value = mem

        mock.nvmlDeviceGetTemperature.return_value = 52
        mock.nvmlDeviceGetPowerUsage.return_value = 150_000  # milliwatts
        mock.nvmlDeviceGetFanSpeed.return_value = 30

        yield mock


def test_get_metrics(mock_nvml):
    monitor = GPUMonitor()
    metrics = monitor.get_metrics()

    assert metrics.gpu_name == "NVIDIA GB10"
    assert metrics.utilization == 45
    assert metrics.memory_used == 1024  # MB
    assert metrics.memory_total == 32768  # MB
    assert metrics.temperature == 52
    assert metrics.power_draw == 150  # watts
    assert metrics.fan_speed == 30


def test_get_metrics_handles_na(mock_nvml):
    """GB10 may raise for fan speed -- verify graceful fallback to 0."""
    mock_nvml.nvmlDeviceGetFanSpeed.side_effect = Exception("N/A")
    monitor = GPUMonitor()
    metrics = monitor.get_metrics()

    assert metrics.fan_speed == 0
    # Other metrics should still be populated
    assert metrics.gpu_name == "NVIDIA GB10"
    assert metrics.utilization == 45


def test_shutdown(mock_nvml):
    monitor = GPUMonitor()
    monitor.get_metrics()  # triggers init
    monitor.shutdown()

    mock_nvml.nvmlShutdown.assert_called_once()
    assert not monitor._initialized


def test_shutdown_noop_when_not_initialized(mock_nvml):
    monitor = GPUMonitor()
    monitor.shutdown()  # should not call nvmlShutdown

    mock_nvml.nvmlShutdown.assert_not_called()
