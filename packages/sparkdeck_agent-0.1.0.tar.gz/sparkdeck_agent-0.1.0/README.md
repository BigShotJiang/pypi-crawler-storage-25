# SparkDeck Agent

Remote AI Command Center agent for NVIDIA DGX Spark.

## Install

```bash
pip install -e ".[dev]"
```

## Usage

```bash
sparkdeck-agent --help
```

Or run as a module:

```bash
python -m sparkdeck_agent
```
