"""ShieldPi Watchtower — Python SDK.

Usage:

    from shieldpi import Monitor

    monitor = Monitor(sdk_key="shpi_live_...")
    session = monitor.start_session(agent_name="invoice-bot", stated_goal="help users with invoices")

    session.log_user_message("How do I file an invoice?")
    session.log_tool_call("search_docs", {"query": "invoice filing"})
    session.log_tool_result("search_docs", {"results": [...]})
    session.log_final_response("Here's how to file an invoice...")

    session.end()

For LangChain:

    from shieldpi import Monitor
    from shieldpi.hooks.langchain import ShieldPiCallbackHandler

    monitor = Monitor(sdk_key="shpi_live_...")
    callbacks = [ShieldPiCallbackHandler(monitor, agent_name="my-agent")]

    agent.run("...", callbacks=callbacks)

For Anthropic tool use:

    from shieldpi import Monitor
    from shieldpi.hooks.anthropic import monitored_tool_use

    monitor = Monitor(sdk_key="shpi_live_...")
    with monitored_tool_use(monitor, agent_name="my-agent") as session:
        result = anthropic_client.messages.create(...)
        session.observe_anthropic_response(result)
"""

from shieldpi.client import Monitor, Session, ShieldPiError

__version__ = "0.1.0"
__all__ = ["Monitor", "Session", "ShieldPiError", "__version__"]
