"""Framework-specific instrumentation hooks for the ShieldPi SDK."""
