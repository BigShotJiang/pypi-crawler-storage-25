"""Anthropic tool-use instrumentation for ShieldPi.

Wraps the Anthropic Python SDK messages.create call so every tool_use block
and subsequent tool_result is logged to a ShieldPi session.

Usage:

    from anthropic import Anthropic
    from shieldpi import Monitor
    from shieldpi.hooks.anthropic import monitored_tool_use

    anth = Anthropic()
    monitor = Monitor(sdk_key="shpi_live_...")

    with monitored_tool_use(monitor, agent_name="invoice-bot") as session:
        session.log_user_message("Help me file an invoice")
        response = anth.messages.create(
            model="claude-opus-4-20250514",
            messages=[{"role": "user", "content": "Help me file an invoice"}],
            tools=[...],
        )
        session.observe_anthropic_response(response)
"""

from __future__ import annotations

import logging
from contextlib import contextmanager
from typing import Any, Iterator, Optional

from shieldpi.client import Monitor, Session

logger = logging.getLogger("shieldpi.anthropic")


class _AnthropicAwareSession:
    """Thin wrapper that adds ``observe_anthropic_response`` to a Session."""

    def __init__(self, session: Session) -> None:
        self._session = session

    def __getattr__(self, name: str) -> Any:
        return getattr(self._session, name)

    def observe_anthropic_response(self, response: Any) -> None:
        """Walk an Anthropic messages.create response and emit events."""
        try:
            blocks = getattr(response, "content", None) or []
            for block in blocks:
                btype = getattr(block, "type", None) or (block.get("type") if isinstance(block, dict) else None)
                if btype == "text":
                    text = getattr(block, "text", None) or (block.get("text") if isinstance(block, dict) else "")
                    if text:
                        self._session.log_llm_call(text[:4000])
                elif btype == "tool_use":
                    name = getattr(block, "name", None) or (block.get("name") if isinstance(block, dict) else "unknown_tool")
                    args = getattr(block, "input", None) or (block.get("input") if isinstance(block, dict) else {}) or {}
                    if not isinstance(args, dict):
                        args = {"input": str(args)}
                    self._session.log_tool_call(name, args)
        except Exception as exc:
            logger.warning("[shieldpi.anthropic] observe_anthropic_response failed: %s", exc)

    def observe_tool_result(self, tool_name: str, result: Any) -> None:
        """Call this after you execute a tool_use block locally."""
        self._session.log_tool_result(tool_name, result)


@contextmanager
def monitored_tool_use(
    monitor: Monitor,
    *,
    agent_name: Optional[str] = None,
    stated_goal: Optional[str] = None,
    external_id: Optional[str] = None,
) -> Iterator[_AnthropicAwareSession]:
    session = monitor.start_session(
        external_id=external_id,
        agent_name=agent_name,
        framework="anthropic",
        stated_goal=stated_goal,
    )
    wrapper = _AnthropicAwareSession(session)
    try:
        yield wrapper
        session.end(status="ended")
    except BaseException:
        session.end(status="abandoned")
        raise
