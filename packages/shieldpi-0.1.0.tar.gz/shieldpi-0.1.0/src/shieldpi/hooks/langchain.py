"""LangChain callback handler for ShieldPi.

Usage:

    from shieldpi import Monitor
    from shieldpi.hooks.langchain import ShieldPiCallbackHandler

    monitor = Monitor(sdk_key="shpi_live_...")
    handler = ShieldPiCallbackHandler(
        monitor,
        agent_name="invoice-bot",
        stated_goal="help users file invoices",
    )

    agent.invoke({"input": "..."}, config={"callbacks": [handler]})

The handler creates one Session per chain run. It hooks into every LangChain
event (chat model start/end, tool start/end, agent action, agent finish) and
translates each into a ShieldPi event.
"""

from __future__ import annotations

import logging
from typing import Any, Optional
from uuid import UUID

try:
    from langchain_core.callbacks.base import BaseCallbackHandler
except ImportError as exc:  # pragma: no cover
    raise RuntimeError(
        "shieldpi[langchain] requires langchain-core — install with "
        "`pip install shieldpi[langchain]`"
    ) from exc

from shieldpi.client import Monitor, Session

logger = logging.getLogger("shieldpi.langchain")


class ShieldPiCallbackHandler(BaseCallbackHandler):
    """Instruments a LangChain run with a ShieldPi live monitoring session."""

    def __init__(
        self,
        monitor: Monitor,
        *,
        agent_name: Optional[str] = None,
        stated_goal: Optional[str] = None,
        framework: str = "langchain",
        external_id: Optional[str] = None,
    ) -> None:
        self.monitor = monitor
        self.agent_name = agent_name
        self.stated_goal = stated_goal
        self.framework = framework
        self.external_id = external_id
        self._sessions: dict[UUID, Session] = {}

    # ── Root run lifecycle ─────────────────────────────────────────

    def _ensure_session(self, run_id: UUID) -> Session:
        if run_id in self._sessions:
            return self._sessions[run_id]
        session = self.monitor.start_session(
            external_id=self.external_id or str(run_id),
            agent_name=self.agent_name,
            framework=self.framework,
            stated_goal=self.stated_goal,
        )
        self._sessions[run_id] = session
        return session

    def _finish_session(self, run_id: UUID, status: str = "ended") -> None:
        session = self._sessions.pop(run_id, None)
        if session is not None:
            try:
                session.end(status=status)
            except Exception:
                logger.warning("[shieldpi.langchain] end_session failed", exc_info=True)

    # ── LangChain callbacks ────────────────────────────────────────

    def on_chain_start(
        self,
        serialized: dict[str, Any],
        inputs: dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        if parent_run_id is not None:
            return  # only the root chain creates a session
        session = self._ensure_session(run_id)
        user_input = inputs.get("input") or inputs.get("question") or str(inputs)
        if isinstance(user_input, str) and user_input:
            session.log_user_message(user_input)

    def on_chain_end(
        self,
        outputs: dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        if parent_run_id is not None:
            return
        session = self._sessions.get(run_id)
        if session is not None:
            output = outputs.get("output") or outputs.get("answer") or str(outputs)
            if isinstance(output, str) and output:
                session.log_final_response(output)
        self._finish_session(run_id, status="ended")

    def on_chain_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        if parent_run_id is not None:
            return
        session = self._sessions.get(run_id)
        if session is not None:
            session.log_error(str(error))
        self._finish_session(run_id, status="abandoned")

    # ── LLM calls ──────────────────────────────────────────────────

    def on_llm_start(
        self,
        serialized: dict[str, Any],
        prompts: list[str],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        root = self._root_run_id(run_id, parent_run_id)
        session = self._sessions.get(root)
        if session is None:
            return
        for prompt in prompts:
            session.log_llm_call(prompt[:4000])

    def on_chat_model_start(
        self,
        serialized: dict[str, Any],
        messages: list[list[Any]],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        root = self._root_run_id(run_id, parent_run_id)
        session = self._sessions.get(root)
        if session is None:
            return
        for batch in messages:
            for m in batch:
                content = getattr(m, "content", None) or str(m)
                if isinstance(content, str) and content:
                    session.log_llm_call(content[:4000])

    # ── Tool calls ─────────────────────────────────────────────────

    def on_tool_start(
        self,
        serialized: dict[str, Any],
        input_str: str,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        root = self._root_run_id(run_id, parent_run_id)
        session = self._sessions.get(root)
        if session is None:
            return
        tool_name = (serialized or {}).get("name") or "unknown_tool"
        args = kwargs.get("inputs") or {"input": input_str}
        if not isinstance(args, dict):
            args = {"input": str(args)}
        session.log_tool_call(tool_name, args)

    def on_tool_end(
        self,
        output: Any,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        root = self._root_run_id(run_id, parent_run_id)
        session = self._sessions.get(root)
        if session is None:
            return
        tool_name = kwargs.get("name") or "unknown_tool"
        session.log_tool_result(tool_name, output)

    def on_tool_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        root = self._root_run_id(run_id, parent_run_id)
        session = self._sessions.get(root)
        if session is None:
            return
        session.log_error(f"Tool error: {error}")

    # ── Helpers ────────────────────────────────────────────────────

    def _root_run_id(self, run_id: UUID, parent_run_id: Optional[UUID]) -> UUID:
        """Find the root run that owns the Session. LangChain nests runs;
        we attach the Session to the outermost chain run_id only."""
        # Simple heuristic: if run_id is a known session, use it; otherwise
        # fall back to parent_run_id. Deeply nested agents may skip this and
        # that's acceptable — events just drop silently for non-root runs.
        if run_id in self._sessions:
            return run_id
        if parent_run_id is not None and parent_run_id in self._sessions:
            return parent_run_id
        # Last resort: attach to any active session
        if self._sessions:
            return next(iter(self._sessions.keys()))
        return run_id
