"""ShieldPi SDK core — Monitor + Session objects.

Design:
- ``Monitor`` is created once with an SDK key and a base URL.
- ``Session`` is created per agent conversation/task via ``monitor.start_session``.
- Every ``log_*`` call fires an async HTTP POST that never blocks the agent.
  Failures are caught, counted, and (optionally) raised via a ``raise_on_error``
  flag. The default is silent failure — we never break production because a
  monitoring call timed out.
- Batching happens automatically for high-throughput agents via the
  ``batch_size`` + ``flush_interval_s`` knobs on the ``Monitor``.
"""

from __future__ import annotations

import atexit
import logging
import os
import queue
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Optional

try:
    import httpx
except ImportError as exc:  # pragma: no cover
    raise RuntimeError(
        "shieldpi requires httpx — install with `pip install shieldpi`"
    ) from exc


logger = logging.getLogger("shieldpi")


class ShieldPiError(RuntimeError):
    """Base class for SDK errors."""


_DEFAULT_BASE_URL = "https://api.shieldpi.io/api/agent-monitor"
_USER_AGENT = "shieldpi-python/0.1.0"


# ── Event envelopes ─────────────────────────────────────────────────


@dataclass
class _QueuedEvent:
    path: str  # "/event" or "/events/batch"
    body: dict
    session: "Session"


# ── Monitor ─────────────────────────────────────────────────────────


class Monitor:
    """SDK entrypoint. One instance per process.

    Args:
        sdk_key: Your per-target SDK key. Starts with ``shpi_live_``.
        base_url: Override the API base URL (defaults to prod).
        raise_on_error: If True, ingest failures raise ``ShieldPiError``.
            Default False — monitoring must never break the agent.
        batch_size: Max events to buffer before flushing.
        flush_interval_s: Max seconds between flushes.
        timeout_s: HTTP timeout for each request.
    """

    def __init__(
        self,
        sdk_key: Optional[str] = None,
        *,
        base_url: Optional[str] = None,
        raise_on_error: bool = False,
        batch_size: int = 20,
        flush_interval_s: float = 1.0,
        timeout_s: float = 5.0,
    ) -> None:
        self.sdk_key = sdk_key or os.environ.get("SHIELDPI_SDK_KEY", "")
        if not self.sdk_key:
            raise ShieldPiError(
                "ShieldPi SDK key is required. Pass sdk_key= or set SHIELDPI_SDK_KEY"
            )
        self.base_url = (base_url or os.environ.get("SHIELDPI_BASE_URL") or _DEFAULT_BASE_URL).rstrip("/")
        self.raise_on_error = raise_on_error
        self.batch_size = max(1, batch_size)
        self.flush_interval_s = max(0.1, flush_interval_s)
        self.timeout_s = timeout_s

        self._client = httpx.Client(
            timeout=timeout_s,
            headers={
                "Authorization": f"Bearer {self.sdk_key}",
                "User-Agent": _USER_AGENT,
                "Content-Type": "application/json",
            },
        )
        self._queue: queue.Queue[_QueuedEvent] = queue.Queue(maxsize=10_000)
        self._shutdown = threading.Event()
        self._worker = threading.Thread(
            target=self._worker_loop, name="shieldpi-flusher", daemon=True
        )
        self._worker.start()
        atexit.register(self.flush)
        atexit.register(self.close)

        # Counters
        self.events_sent = 0
        self.events_failed = 0

    # ── Session API ────────────────────────────────────────────────

    def start_session(
        self,
        *,
        external_id: Optional[str] = None,
        agent_name: Optional[str] = None,
        framework: Optional[str] = None,
        stated_goal: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> "Session":
        """Create a new live monitoring session. Returns a Session object."""
        body = {
            "external_id": external_id,
            "agent_name": agent_name,
            "framework": framework,
            "stated_goal": stated_goal,
            "metadata": metadata,
        }
        try:
            resp = self._client.post(f"{self.base_url}/session/start", json=body)
            resp.raise_for_status()
            data = resp.json()
        except Exception as exc:
            if self.raise_on_error:
                raise ShieldPiError(f"start_session failed: {exc}") from exc
            logger.warning("[shieldpi] start_session failed, returning offline session: %s", exc)
            return Session(self, session_id="offline", offline=True)
        return Session(self, session_id=data["session_id"])

    # ── Ingest ─────────────────────────────────────────────────────

    def _enqueue(self, session: "Session", body: dict) -> None:
        try:
            self._queue.put_nowait(_QueuedEvent(path="/event", body=body, session=session))
        except queue.Full:
            self.events_failed += 1
            logger.warning("[shieldpi] event queue full — dropping event")

    # ── Worker thread ──────────────────────────────────────────────

    def _worker_loop(self) -> None:
        buffer: list[_QueuedEvent] = []
        last_flush = time.time()
        while not self._shutdown.is_set():
            try:
                timeout = max(0.05, self.flush_interval_s - (time.time() - last_flush))
                item = self._queue.get(timeout=timeout)
                buffer.append(item)
            except queue.Empty:
                pass
            now = time.time()
            if buffer and (
                len(buffer) >= self.batch_size
                or (now - last_flush) >= self.flush_interval_s
            ):
                self._flush_buffer(buffer)
                buffer.clear()
                last_flush = now
        # Final flush on shutdown
        if buffer:
            self._flush_buffer(buffer)

    def _flush_buffer(self, buffer: list[_QueuedEvent]) -> None:
        # Group by single vs batch. Right now everything goes in a batch call.
        body = {"events": [ev.body for ev in buffer]}
        try:
            resp = self._client.post(f"{self.base_url}/events/batch", json=body)
            if resp.status_code >= 400:
                self.events_failed += len(buffer)
                logger.warning("[shieldpi] batch ingest %d: %s", resp.status_code, resp.text[:200])
                return
            self.events_sent += len(buffer)
        except Exception as exc:
            self.events_failed += len(buffer)
            if self.raise_on_error:
                raise ShieldPiError(f"ingest failed: {exc}") from exc
            logger.warning("[shieldpi] ingest failed: %s", exc)

    def flush(self) -> None:
        """Force-drain the queue. Called on atexit."""
        deadline = time.time() + 5.0
        while not self._queue.empty() and time.time() < deadline:
            time.sleep(0.05)

    def close(self) -> None:
        self._shutdown.set()
        try:
            self._worker.join(timeout=2.0)
        except Exception:
            pass
        try:
            self._client.close()
        except Exception:
            pass


# ── Session ─────────────────────────────────────────────────────────


class Session:
    """A live monitoring session for one agent conversation or task.

    Call ``log_*`` methods for each step the agent takes. They never block.
    Call ``end()`` when the session is over (or let atexit handle it).
    """

    def __init__(self, monitor: Monitor, session_id: str, *, offline: bool = False) -> None:
        self._monitor = monitor
        self.session_id = session_id
        self._offline = offline

    # ── log_* helpers ──────────────────────────────────────────────

    def log_user_message(self, content: str, *, metadata: Optional[dict] = None) -> None:
        self._enqueue("user_message", content=content, actor="user", metadata=metadata)

    def log_llm_call(self, content: str, *, metadata: Optional[dict] = None) -> None:
        self._enqueue("llm_call", content=content, actor="assistant", metadata=metadata)

    def log_final_response(self, content: str, *, metadata: Optional[dict] = None) -> None:
        self._enqueue("final_response", content=content, actor="assistant", metadata=metadata)

    def log_tool_call(
        self,
        tool_name: str,
        tool_args: Optional[dict] = None,
        *,
        metadata: Optional[dict] = None,
    ) -> None:
        self._enqueue(
            "tool_call",
            tool_name=tool_name,
            tool_args=tool_args,
            actor="assistant",
            metadata=metadata,
        )

    def log_tool_result(
        self,
        tool_name: str,
        tool_result: Any,
        *,
        metadata: Optional[dict] = None,
    ) -> None:
        if tool_result is not None and not isinstance(tool_result, dict):
            tool_result = {"value": tool_result}
        self._enqueue(
            "tool_result",
            tool_name=tool_name,
            tool_result=tool_result,
            actor="tool",
            metadata=metadata,
        )

    def log_memory_write(
        self,
        memory_key: str,
        memory_value: str,
        *,
        metadata: Optional[dict] = None,
    ) -> None:
        self._enqueue(
            "memory_write",
            memory_key=memory_key,
            memory_value=memory_value,
            actor="system",
            metadata=metadata,
        )

    def log_memory_read(
        self,
        memory_key: str,
        *,
        metadata: Optional[dict] = None,
    ) -> None:
        self._enqueue("memory_read", memory_key=memory_key, actor="system", metadata=metadata)

    def log_error(self, message: str, *, metadata: Optional[dict] = None) -> None:
        self._enqueue("error", content=message, actor="system", metadata=metadata)

    def end(self, status: str = "ended") -> None:
        if self._offline:
            return
        try:
            resp = self._monitor._client.post(
                f"{self._monitor.base_url}/session/end",
                json={"session_id": self.session_id, "status": status},
            )
            resp.raise_for_status()
        except Exception as exc:
            if self._monitor.raise_on_error:
                raise ShieldPiError(f"end_session failed: {exc}") from exc
            logger.warning("[shieldpi] end_session failed: %s", exc)

    # ── Internal ───────────────────────────────────────────────────

    def _enqueue(self, event_type: str, **fields) -> None:
        if self._offline:
            return
        body: dict[str, Any] = {"session_id": self.session_id, "event_type": event_type}
        for k, v in fields.items():
            if v is not None:
                body[k] = v
        self._monitor._enqueue(self, body)

    def __enter__(self) -> "Session":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.end(status="ended" if exc_type is None else "abandoned")
