# ShieldPi Python SDK

Official Python SDK for the ShieldPi LLM Security Scanner API.

## Installation

```bash
pip install shieldpi
```

## Quick Start

```python
from shieldpi import ShieldPi

client = ShieldPi(api_key="your-api-key")

# Create a target
target = client.targets.create(
    name="My Chatbot",
    url="https://my-chatbot.com/api/chat",
    scan_mode="api"
)

# Run a scan
scan = client.scans.create(target_id=target.id)

# Wait for completion
result = client.scans.wait(scan.id)

# Get the report
print(f"Security Grade: {result.grade}")
print(f"Score: {result.score}/100")
print(f"Findings: {result.total_findings}")
```

## API Reference

### Authentication
```python
client = ShieldPi(api_key="sk-...", base_url="https://api.shieldpi.io/api")
```

### Targets
```python
client.targets.list()
client.targets.create(name="...", url="...", scan_mode="model")
client.targets.get(target_id)
client.targets.delete(target_id)
```

### Scans
```python
client.scans.create(target_id=target_id)
client.scans.get(scan_id)
client.scans.list()
client.scans.wait(scan_id, timeout=3600)
```

### Reports
```python
client.scans.download_report(scan_id, format="pdf")
client.scans.download_report(scan_id, format="json")
```

## Live Agent Monitoring

For real-time agent monitoring, use the `Monitor` class:

```python
from shieldpi import Monitor

monitor = Monitor(sdk_key="shpi_live_...")

with monitor.start_session(
    agent_name="invoice-bot",
    stated_goal="help users file invoices",
) as session:
    session.log_user_message("How do I file a Q1 invoice?")
    session.log_tool_call("search_docs", {"query": "Q1 invoice filing"})
    session.log_tool_result("search_docs", {"results": [...]})
    session.log_final_response("Here's how to file a Q1 invoice...")
```

### LangChain Integration

```python
from shieldpi import Monitor
from shieldpi.hooks.langchain import ShieldPiCallbackHandler

monitor = Monitor(sdk_key="shpi_live_...")
callbacks = [ShieldPiCallbackHandler(
    monitor,
    agent_name="my-agent",
    stated_goal="help users with their accounts",
)]

agent.invoke({"input": "..."}, config={"callbacks": callbacks})
```

### Anthropic Tool Use

```python
from anthropic import Anthropic
from shieldpi import Monitor
from shieldpi.hooks.anthropic import monitored_tool_use

anth = Anthropic()
monitor = Monitor(sdk_key="shpi_live_...")

with monitored_tool_use(monitor, agent_name="invoice-bot") as session:
    session.log_user_message("Help me file an invoice")
    response = anth.messages.create(
        model="claude-opus-4-20250514",
        messages=[{"role": "user", "content": "Help me file an invoice"}],
        tools=[...],
    )
    session.observe_anthropic_response(response)
```

## Configuration

Environment variables:

- `SHIELDPI_API_KEY` — API key for scanner operations
- `SHIELDPI_SDK_KEY` — SDK key for live monitoring
- `SHIELDPI_BASE_URL` — Override the API base URL (default: `https://api.shieldpi.io/api`)

## License

Apache-2.0
