"""
Z-Arch Extension Execution Policy
-----------------------------------------------
Defines the authoritative execution policy for Z-Arch extension lifecycle hooks.

This module is owned exclusively by Z-Arch core and establishes a hard security
boundary between hooks that are permitted to execute in the local CLI process
and hooks that must execute in an isolated environment.

Extensions have no ability to influence or override this policy. The execution
target for each hook is determined unconditionally by Z-Arch to prevent
untrusted extension code from running inside sensitive processes such as the
Control Plane.

Any hook marked as "remote" will never be executed in-process. Instead, Z-Arch
will forward the invocation to a dedicated extension runner environment.

Copyright © 2026 RAM Cloud Code LLC
Licensed under the Apache License, Version 2.0.
"""

from typing import Dict, Literal

ExecutionTarget = Literal["local", "remote"]

HOOK_EXECUTION_POLICY: Dict[str, ExecutionTarget] = {
    "pre_project_bootstrap": "local",
    "post_project_bootstrap": "local",
    "pre_service_deploy": "local",
    "post_service_ensureSA": "remote",
    "post_service_deploy": "remote",
    "pre_gateway_deploy": "local",
    "post_gateway_ensureSA": "remote",
    "post_gateway_deploy": "remote",
    "pre_job_deploy": "local",
    "post_job_ensureSA": "remote",
    "post_job_deploy": "remote",
    "pre_topic_deploy": "local",   
    "post_topic_deploy": "local",
    "pre_scheduler_deploy": "local",
    "post_scheduler_ensureSA": "local",
    "post_scheduler_deploy": "local",
}
