from narwhals.utils import requiresfrom narwhals.utils import requires

# py_menu_tui

`py_menu_tui` is a lightweight **terminal user interface (TUI) navigation framework** for Python.  
It allows developers to quickly build interactive command-line menus with keyboard navigation and nested subsections.

The interface is controlled using simple keys and is designed for **Windows terminals** using `msvcrt`.

---

# Features

- Keyboard navigation (`w` / `s`)
- Nested menu sections
- Simple function binding to menu entries
- Scrollable menus
- Progress bar utility
- Confirmation prompts
- No external dependencies

---

# Installation

Currently the package can be installed with:

```bash
pip install py_menu_tui
```
## Controls

| Key | Action |
|----|----|
| w | Move up |
| s | Move down |
| Enter | Select option |
| Esc | Go back |
| Ctrl+C | Exit program |



## Example
```python
from py_menu_tui import UserInterface

def hello():
    print("Hello World")

ui = UserInterface()

ui.setup(
    ["Say Hello"],
    [hello]
)

ui.begin()
```

## Creating Subsections

```python
# Create a subsection
ui.add_sub_section(
    ["Option 1", "Option 2"],
    [func1, func2],
    section="Settings"
)

# Create a nested subsection inside "Settings"
ui.add_sub_section(
    ["Option 1", "Option 2"],
    [func1, func2],
    section="Audio",
    uppersection="Settings"
)
```
## Utilities
````python
#Progressbar
from py_menu_tui import progressbar
progressbar(50)

#Clear Terminal
from py_menu_tui import clear
clear()

#Confirmation Prompt
from py_menu_tui import confirm

if confirm("Continue?"):
    print("Confirmed")

#Wait for user input
ui.hold()

# Wait 5 seconds
ui.hold(time=5)

# Custom message and wait for input
ui.hold(msg="Press spacebar to continue")
````
## Requirements

- Python 3+
- Windows terminal (uses `msvcrt`)
- No external dependencies

## License

This project is licensed under the **MIT License**.