"""
Class for handling Webcams. This class provides methods to connect to a webcam,
capture single frames, and stream video frames. It uses OpenCV for camera
interfacing and integrates with BabyROS for communication.
"""

from typing import Optional
import time

import cv2
import numpy as np
from loguru import logger

from babyros import node


class Webcam:
    """
    Webcam class using OpenCV.

    Provides methods for connecting to the camera, capturing single frames,
    and streaming video frames.
    """

    def __init__(
        self,
        name: str,
        camera_id: int = 0,
    ) -> None:
        """
        Initialize the internal states.

        On construction, BabyROS servers/subscribers are registered for connect,
        capture, start_video_stream, and stop_video_stream topics under
        ``medulla/v1/camera/webcam/<name>``.

        Args:
            name (str):
                Unqiue name of the camera.
            camera_id (int):
                OpenCV camera index (default ``0`` for the first connected
                webcam).

        """
        self._name = name
        self._id = camera_id
        self._is_connected = False
        self._is_streaming = False
        self._cap = None

        self._base = f"medulla/v1/camera/webcam/{name}"

        self._connect_server = node.Server(
            topic=f"{self._base}/connect",
            callback=self._handle_connection_trigger,
        )
        self._capture_single_color_frame_server = node.Server(
            topic=f"{self._base}/capture",
            callback=self._handle_capture,
        )
        self._video_frame_publisher = node.Publisher(
            topic=f"{self._base}/video",
        )
        self._start_video_stream = node.Subscriber(
            topic=f"{self._base}/start_video_stream",
            callback=self.start_video_stream,
        )
        self._stop_video_stream = node.Subscriber(
            topic=f"{self._base}/stop_video_stream",
            callback=self.stop_video_stream,
        )

    def connect(self) -> bool:
        """
        Open the OpenCV video capture for this camera.

        Returns:
            True if the camera is now open.

        Raises:
            RuntimeError:
                - If OpenCV could not open the camera.
        """
        if self._is_connected:
            logger.info("Already connected to camera.")
            return True

        self._cap = cv2.VideoCapture(self._id)

        if not self._cap.isOpened():
            raise RuntimeError(
                f"Failed to connect to camera with ID {self._id}. "
                f"Please check that the camera is properly connected and the ID "
                f"is correct."
            )

        self._is_connected = True
        logger.info(f"Successfully connected to camera with ID {self._id}.")
        return True

    def disconnect(self) -> bool:
        """
        Release the OpenCV video capture and mark the camera as disconnected.

        Returns:
            True if the camera was open and is now released, False if it was
            already disconnected.
        """
        if not self._is_connected:
            self.delete()
            return False

        if self._is_streaming:
            self._is_streaming = False

        if self._cap:
            # Small delay to ensure any ongoing capture is finished
            time.sleep(0.5)
            self._cap.release()

        self._is_connected = False
        self.delete()
        logger.info(
            f"Disconnected from camera {self._name} with ID {self._id}."
        )
        return True

    def capture_video_color_frame(self) -> Optional[np.ndarray]:
        """
        Capture and return a single BGR frame from the camera.

        Returns:
            The captured frame as a NumPy array in BGR format.

        Raises:
            RuntimeError:
                - If the camera is not connected or the frame cannot be read.
        """
        if not self._is_connected:
            raise RuntimeError("Camera is not connected.")

        frame = None
        if self._cap:
            ret, frame = self._cap.read()
            if not ret:
                raise RuntimeError("Could not read frame from camera.")

        if frame is None:
            logger.error("Captured frame is None.")
        else:
            # Convert frame to RGB format for consistency with other cameras
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        return frame

    def capture_single_color_frame(self) -> Optional[np.ndarray]:
        """
        Capture and return a single BGR frame from the camera for streaming.

        Just a wrapper around ``capture_video_color_frame`` to be consistent
        with the naming convention for streaming frames.

        Returns:
            The captured frame as a NumPy array in BGR format.
        """
        # Small delay to allow camera to warm up if just connected
        time.sleep(0.1)
        return self.capture_video_color_frame()

    def _handle_connection_trigger(
        self, data: dict[str, bool]
    ) -> dict[str, bool]:
        """
        Handle a connect/disconnect request received over Zenoh.

        Args:
            data: Payload dict with a ``"connect"`` bool key.

        Returns:
            Dict with a ``"status"`` key reflecting the current connection state.
        """
        connect = data.get("connect", False)
        try:
            if connect and not self._is_connected:
                self.connect()
            elif not connect and self._is_connected:
                self.disconnect()
        except RuntimeError as e:
            logger.error(f"Connection trigger failed: {e}")
        logger.info(
            f"Connection trigger handled. connect={connect}, "
            f"is_connected={self._is_connected}"
        )
        return {"status": self._is_connected}

    def _handle_capture(self, request: dict[str, bool]) -> Optional[np.ndarray]:
        """
        Handle the capture trigger from BabyROS.

        Args:
            request (dict[str, bool]):
                Not used currently, but can be extended in the future.
        """
        image = self.capture_single_color_frame()
        if image is not None:
            return image
        else:
            logger.error(f"Unable to capture image with camera {self._name}.")
            return None

    def start_video_stream(self, _=None) -> None:
        """
        Start capturing and publishing video frames until ``stop_video_stream``
        is called.

        Raises:
            RuntimeError:
                - If a frame cannot be read mid-stream.
        """
        logger.info("Start video stream trigger received.")
        self._is_streaming = True
        start_time = time.time()
        frame_count = 0
        fps = 0
        logger.info(f"Started video stream for camera {self._name}.")
        while self._is_streaming and self._is_connected:
            image = self.capture_video_color_frame()
            if image is not None:
                self._video_frame_publisher.publish(image)
            else:
                logger.warning(f"Image is None for camera {self._name}.")
            elapsed = time.time() - start_time
            frame_count += 1
            if elapsed >= 1.0:
                fps = frame_count / elapsed
                logger.info(f"FPS: {fps:.2f}")
                frame_count = 0
                start_time = time.time()

    def stop_video_stream(self, _=None) -> None:
        """Stop the running video stream.

        Args:
            _: Unused trigger payload from the Zenoh subscriber.
        """
        self._is_streaming = False
        logger.info(f"Stoped video stream for camera {self._name}")

    def delete(self) -> None:
        """
        Release OpenCV resources with disconnect() and shutdown all node servers
        """
        if self._cap:
            self._cap.release()
        self._connect_server.delete()
        self._capture_single_color_frame_server.delete()
        self._video_frame_publisher.delete()
        self._start_video_stream.delete()
        self._stop_video_stream.delete()
        logger.info(f"Deleted all servers of camera {self._name}")
