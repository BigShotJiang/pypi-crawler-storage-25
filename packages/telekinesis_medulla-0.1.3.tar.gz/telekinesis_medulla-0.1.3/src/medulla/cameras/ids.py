"""
Class for handling IDS cameras. This is thin wrapper around the IDS Peak SDK
extended with BabyROS nodes for remote triggering and parameter control.
"""

from typing import cast, Optional, Any
import time
import pathlib

import cv2
import numpy as np
from loguru import logger
from ids_peak import ids_peak
from ids_peak_icv.pipeline.default_pipeline import DefaultPipeline
from ids_peak_common.datatypes.pixelformat import PixelFormat
from ids_peak_common.datatypes.range import Range

from babyros import node

ROOT_DIR = pathlib.Path(__file__).resolve().parent.parent


class IDS:
    """
    Base class for IDS cameras using the IDS Peak SDK and BabyROS for remote
    triggering and parameter control.
    """

    parameter_name_to_type_map: dict[str, type] = {
        "AcquisitionFrameRate": ids_peak.FloatNode,
        "ExposureTime": ids_peak.FloatNode,
        "DeviceLinkThroughputLimit": ids_peak.IntegerNode,
    }

    def __init__(
        self,
        name: str,
        serial_number: str | None = None,
        load_factory_defaults: bool = False,
    ) -> None:
        """
        Initialize the internal states.

        Includes the creating of a default pixel pipline which defines a
        sequence of processing steps that are applied to an acquired raw image.
        The image is then processed into an image of the specified output pixel
        format.

        Creates also the BabyROS nodes for remote triggering and parameter
        control.

        Args:
            name (str):
                Unqiue name of the camera.
            serial_number (str | None):
                Serial number of the camera.
            load_factory_defaults (bool):
                Whether to load the factory default camera
        """
        self._name = name
        self._serial_number = serial_number
        self._load_factory_defaults = load_factory_defaults
        self._is_connected = False
        self._is_library_initialized = False
        self._is_acquisition_started = False
        self._is_streaming = False
        self.device: ids_peak.Device | None = None
        self._data_stream: ids_peak.DataStream | None = None
        self._remote_nodemap: ids_peak.NodeMap | None = None

        self._image_pipeline = DefaultPipeline()
        self._image_pipeline.output_pixel_format = PixelFormat.BGRA_8

        # BabyROS nodes
        base_topic = f"medulla/v1/camera/ids/IDS/{name}"

        self._connect_server = node.Server(
            topic=f"{base_topic}/connect",
            callback=self._handle_connection_trigger,
        )

        self._capture_single_color_frame_server = node.Server(
            topic=f"{base_topic}/capture", callback=self._handle_capture
        )

        self._parameter_server = node.Server(
            topic=f"{base_topic}/parameter", callback=self._handle_parameter
        )

        self._video_frame_publisher = node.Publisher(
            topic=f"{base_topic}/video"
        )

        self._start_video_stream = node.Subscriber(
            topic=f"{base_topic}/start_video_stream",
            callback=self.start_video_stream,
        )

        self._stop_video_stream = node.Subscriber(
            topic=f"{base_topic}/stop_video_stream",
            callback=self.stop_video_stream,
        )

    def connect(
        self,
        load_factory_defaults: bool = False,
    ) -> bool:
        """
        Open the camera for image aquisition.

        The library must be initialized before use. Each 'Initialize' call must
        be matched with a corresponding call to 'Close'. The Initilaize() call
        basically loads and initilizes the GenTL producer libraries that IDS
        ships.

        If you want to controll the lifecycle manually, you have to wrap your
        code aorund a try/finally block, e.g.:

        .. code-block:: python

            cam = IDS()
            try:
                cam.connect()
                # Work with cam
                ...
            except Exception as e:
                # handle exception
                ...
            finally:
                cam.disconnect()

        The main steps for connecting the camera and preapring for acquisition
        are:
        - Open device
        - Allocate buffers

        The acquisiton is started when a capture is triggered either in image or
        video mode.

        Args:
            load_factory_defaults (bool):
                Whether to load the factroy default camera settings. Defaults to
                false.
        """
        if not self._is_connected:
            ids_peak.Library.Initialize()
            self._is_library_initialized = True
            self._open_device()
            if load_factory_defaults:
                try:
                    if self._remote_nodemap is None:
                        ids_peak.Library.Close()
                        raise RuntimeError("Device is not opened!")
                    cast(
                        ids_peak.EnumerationNode,
                        self._remote_nodemap.FindNode("UserSetSelector"),
                    ).SetCurrentEntry("Default")
                    user_set_load_node = cast(
                        ids_peak.CommandNode,
                        self._remote_nodemap.FindNode("UserSetLoad"),
                    )
                    user_set_load_node.Execute()
                    user_set_load_node.WaitUntilDone()
                    logger.info("Loaded factory defaults.")
                except RuntimeError as e:
                    logger.error(
                        f"Unable to load factory defaults."
                        f"Caught exception: {type(e).__name__}: {e}"
                    )
                    self._close_camera()
                    return False
            self._alloc_buffers()
            self._is_connected = True
            logger.info(f"Connected to camera {self._name}.")
            return True
        else:
            logger.warning(f"Camera {self._name} is already connected.")
            return True

    def _open_device(
        self,
    ) -> None:
        """
        Update the DeviceManager. Try to open the device. In case of an error,
        make sure to close the initialized ids_peak library.

        When 'Update' is called, it searches for all producer libraries
        contained in the directories found in the official GenICam GenTL
        environment variable GENICAM_GENTL{32/64}_PATH. It then opens all
        found ProducerLibraries, their Systems, their Interfaces, and lists
        all available DeviceDescriptors.

        The enviornment variable is added automatically during the installation
        of the IDS Peak Software.

        Raises:
            RuntimeError:
                - If the device with the specified serial number cannot be found
                or opened.
        """
        try:
            device_manager = ids_peak.DeviceManager.Instance()
            device_manager.Update()

            # List all available devices.
            for i, dev in enumerate(device_manager.Devices()):
                logger.info(
                    str(i)
                    + ": "
                    + dev.ModelName()
                    + " ("
                    + dev.ParentInterface().DisplayName()
                    + "; "
                    + dev.ParentInterface().ParentSystem().DisplayName()
                    + "v."
                    + dev.ParentInterface().ParentSystem().Version()
                    + "), Serial Number: "
                    + dev.SerialNumber()
                )

            # Open the device with the specified serial number.
            for dev in device_manager.Devices():
                if dev.IsOpenable(ids_peak.DeviceAccessType_Control):
                    # Select the device with the specified serial number
                    if dev.SerialNumber() == self._serial_number:
                        self.device = dev.OpenDevice(
                            ids_peak.DeviceAccessType_Control
                        )

            if self.device is None:
                ids_peak.Library.Close()
                raise RuntimeError(
                    f"Unable to find device with serial number "
                    f"{self._serial_number}."
                    "Make sure that the camera is physically "
                    "connected and is not in use by another program, e.g. IDS"
                    "Cockpit. Exiting Program."
                )

            logger.info("Using Device " + self.device.DisplayName())

            # Retrieve the remote device's primary node map.
            # In GenICam, a node map represents a hierarchical set of parameters
            # (features) such as exposure, gain, and firmware info. The node map
            # provides access to controls implemented on the device itself,
            # typically following the GenICam SFNC, while allowing for
            # device-specific extensions.
            self._remote_nodemap = self.device.RemoteDevice().NodeMaps()[0]
            self._data_stream = self.device.DataStreams()[0].OpenDataStream()
        except Exception as e:
            logger.error(
                f"Unable to open device for camera {self._name}. "
                f"Caught exception: {type(e).__name__}: {e}"
            )
            self._close_camera()
            raise e

    def _alloc_buffers(
        self,
    ) -> None:
        """
        Allocate buffers for the acquisition.

        Raises:
            RuntimeError:
                - If the device is not opened.
        """
        try:
            if self._remote_nodemap is None or self._data_stream is None:
                raise RuntimeError("Device is not opened!")

            # Buffer size
            payload_size = cast(
                ids_peak.IntegerNode,
                self._remote_nodemap.FindNode("PayloadSize"),
            ).Value()

            # Minimum number of required buffers
            buffer_count_max = (
                self._data_stream.NumBuffersAnnouncedMinRequired()
            )

            # Allocate buffers and add them to the pool
            for _ in range(buffer_count_max):
                # Let the TL allocate the buffers
                buffer = self._data_stream.AllocAndAnnounceBuffer(payload_size)
                # Put the buffer in the pool
                self._data_stream.QueueBuffer(buffer)
        except Exception as e:
            logger.error(
                f"Unable to allocate buffers for camera {self._name}."
                f"Caught exception: {type(e).__name__}: {e}"
            )
            self._close_camera()
            raise e

    def _start_acquisition(self) -> None:
        """
        Start acquisition. Involves:
            - Lock writable nodes, which could influence the payload size or
            similar information during acquisition.
            - Start acquisition both locally and on device.

        Raises:
            RuntimeError:
                - If the acquisition is already running or if the device is not
                opened.
        """
        try:
            if self._is_acquisition_started:
                raise RuntimeError("Acquisition is already running.")
            if self._remote_nodemap is None or self._data_stream is None:
                raise RuntimeError("Device is not opened!")

            # Lock writable nodes, which could influence the payload size or
            # similar information during acquisition.
            cast(
                ids_peak.IntegerNode,
                self._remote_nodemap.FindNode("TLParamsLocked"),
            ).SetValue(1)

            # Start acquisition both locally and on device.
            self._data_stream.StartAcquisition()
            acquisition_start_node = cast(
                ids_peak.CommandNode,
                self._remote_nodemap.FindNode("AcquisitionStart"),
            )
            acquisition_start_node.Execute()
            acquisition_start_node.WaitUntilDone()
            self._is_acquisition_started = True
            logger.info("Started acquisition for camera {self._name}.")
        except Exception as e:
            logger.error(
                f"Unable to start acquisition for camera {self._name}."
                f"Caught exception: {type(e).__name__}: {e}"
            )
            self._close_camera()

    def disconnect(
        self,
    ) -> bool:
        """
        Disconnect the camera. Involves:
            - Stopping the acquisition
            - Revoking allocated buffers
            - Closing the camera
            - Deleting the BabyROS nodes

        If the camera is already disconnected, this method deletes the BabyROS
        nodes and returns False. Otherwise, it disconnects the camera and
        returns True.

        Returns:
            bool: True if the camera was successfully disconnected, False if the
                camera was already disconnected.
        """
        if self._is_connected is False or self._is_library_initialized is False:
            logger.info(f"Camera {self._name} is already disconnected.")
            # Delete BabyROS nodes
            self.delete()
            return False
        else:
            self._stop_acquisition()
            self._revoke_buffers()
            self._close_camera()
            # Delete BabyROS nodes
            self.delete()
            logger.info(f"Disconnected camera {self._name}.")
            return True

    def _close_camera(
        self,
    ) -> None:
        """
        Close the camera and clean up internal states.
        """
        ids_peak.Library.Close()
        self.device = None
        self._remote_nodemap = None
        self._data_stream = None
        self._is_connected = False
        self._is_library_initialized = False
        logger.info(f"Closed camera {self._name}.")

    def _stop_acquisition(self) -> None:
        """
        Stop acquisition. Involves:
            - Stopping acquisition on the device
            - Flushing the data stream to stop any pending acquisition and
                re-queue the buffers.
            - Unlock writable nodes again.

        Raises:
            RuntimeError:
                - If the acquisition is not running or if the device is not
                opened.
        """
        try:
            if not self._is_acquisition_started:
                logger.warning("Acquisition is not started.")
                return
            if self._remote_nodemap is None or self._data_stream is None:
                raise RuntimeError("Device is not opened!")

            cast(
                ids_peak.CommandNode,
                self._remote_nodemap.FindNode("AcquisitionStop"),
            ).Execute()

            # Stop and flush the 'DataStream'.
            # 'KillWait' will cancel pending 'WaitForFinishedBuffer' calls.
            # One call to 'KillWait' will cancel one pending
            # 'WaitForFinishedBuffer'. For more information, refer to the
            # documentation of 'KillWait.

            if self._data_stream.IsGrabbing():
                self._data_stream.StopAcquisition(
                    ids_peak.AcquisitionStopMode_Kill
                )

            # Discard all buffers from the acquisition engine.
            # They remain in the announced buffer pool.
            self._data_stream.Flush(ids_peak.DataStreamFlushMode_DiscardAll)

            # Unlock writable nodes again. See `Lock writable nodes`.
            cast(
                ids_peak.IntegerNode,
                self._remote_nodemap.FindNode("TLParamsLocked"),
            ).SetValue(0)
            self._is_acquisition_started = False
            logger.info(f"Stopped acquisition for camera {self._name}.")
        except Exception as e:
            logger.error(
                f"Unable to stop acquisition for camera {self._name}."
                f"Caught exception: {type(e).__name__}: {e}"
            )
            self._close_camera()

    def _revoke_buffers(
        self,
    ) -> None:
        """
        Revoke all buffers.

        Raises:
            RuntimeError:
                - If the device is not opened.
        """
        if self._data_stream is None:
            raise RuntimeError("Device is not opened!")

        # Remove buffers from any associated queue
        self._data_stream.Flush(ids_peak.DataStreamFlushMode_DiscardAll)

        for buffer in self._data_stream.AnnouncedBuffers():
            # Remove buffer from the transport layer
            self._data_stream.RevokeBuffer(buffer)

    def capture_single_color_frame(
        self,
    ) -> Optional[np.ndarray]:
        """
        Single frame acquistion. See:
        https://www.1stvision.com/cameras/IDS/IDS-manuals/en/operate-single-frame-acquisition.html
        """
        if self._is_acquisition_started:
            self._stop_acquisition()
            if self._data_stream is not None:
                # Re-queue all announced buffers (flushed by _stop_acquisition)
                for buffer in self._data_stream.AnnouncedBuffers():
                    self._data_stream.QueueBuffer(buffer)
        try:
            if self._remote_nodemap is None or self._data_stream is None:
                raise RuntimeError("Device is not connected.")

            # Set acquisition mode to SingleFrame
            acquisition_mode_node = cast(
                ids_peak.EnumerationNode,
                self._remote_nodemap.FindNode("AcquisitionMode"),
            )

            # Switch to SingleFrame
            acquisition_mode_node.SetCurrentEntry("SingleFrame")

            # Start acquisition
            self._start_acquisition()

            # Wait for the finished/filled buffer event.
            buffer = self._data_stream.WaitForFinishedBuffer(
                ids_peak.Timeout(5000)
            )

            # Convert the acquired buffer to an image view.
            # The ImageView defines a standard way to access image properties and raw pixel
            # data, enabling interoperability with different image processing libraries or
            # backends.
            # Note: This object does not own the image memory.
            image_view = buffer.ToImageView()

            # Pass the ImageView through the image pipeline which runs all processing steps
            # in sequence. The resulting image is guaranteed to be a copy.
            converted_image = self._image_pipeline.process(image_view)
            image_numpy = converted_image.to_numpy_array()

            # Put the buffer back in the pool, so it can be filled again.
            self._data_stream.QueueBuffer(buffer)
            return image_numpy
        except Exception as e:
            logger.error(
                f"Unable to capture single color frame from camera {self._name}."
                f"Caught exception: {type(e).__name__}: {e}"
            )
            self._close_camera()
        finally:
            # The acquisition is automatically stopped in this mode but we stop
            # it manually for convinence (changes self._is_acquisition_started)
            self._stop_acquisition()
            if self._data_stream is not None:
                # Re-queue all announced buffers (flushed by _stop_acquisition)
                for buffer in self._data_stream.AnnouncedBuffers():
                    self._data_stream.QueueBuffer(buffer)

    def capture_video_color_frame(self) -> Optional[np.ndarray]:
        """
        Capture a single video frame. The acquisition is not stopped after the
        capture. Involves:
            - Change acquisition mode to Continuous
            - Start acquisition if not already started
            - Wait for the finished/filled buffer event
            - Convert the acquired buffer to an image view and pass it through
            the image pipeline.
            - Put the buffer back in the pool, so it can be filled again.

        Raises:
            RuntimeError:
                - If the device is not opened.
        """
        # Change continous acqusition mode and start the acquisition
        if (
            not self._is_acquisition_started
            and self._remote_nodemap is not None
        ):
            acquisition_mode_node = cast(
                ids_peak.EnumerationNode,
                self._remote_nodemap.FindNode("AcquisitionMode"),
            )

            # Switch to Continous
            acquisition_mode_node.SetCurrentEntry("Continuous")

            # Start acquisition
            self._start_acquisition()
        try:
            if self._remote_nodemap is None or self._data_stream is None:
                raise RuntimeError("Camera is not connected.")
            buffer = self._data_stream.WaitForFinishedBuffer(
                ids_peak.Timeout.INFINITE_TIMEOUT
            )
            print(f"\rReceived FrameID: {buffer.FrameID()}", end="", flush=True)

            # Convert the acquired buffer to an image view.
            # The ImageView defines a standard way to access image properties and raw pixel
            # data, enabling interoperability with different image processing libraries or
            # backends.
            # Note: This object does not own the image memory.
            image_view = buffer.ToImageView()

            # Pass the ImageView through the image pipeline which runs all processing steps
            # in sequence. The resulting image is guaranteed to be a copy.
            converted_image = self._image_pipeline.process(image_view)

            # Append image to video
            data = converted_image.to_numpy_array()

            # Put the buffer back in the pool, so it can be filled again.
            self._data_stream.QueueBuffer(buffer)
            return data
        except Exception as e:
            logger.error(
                f"Unable to capture video color frame from camera {self._name}."
                f"Caught exception: {type(e).__name__}: {e}"
            )
            self._close_camera()

    def _encode_image(self, image: np.ndarray) -> np.ndarray:
        """
        Encode the image for transmission with BabyROS.

        Args:
            image (np.ndarray): The image to encode.

        Returns:
            The encoded image as a numpy array.
        """
        _, encoded = cv2.imencode(".jpg", image, [cv2.IMWRITE_JPEG_QUALITY, 80])
        return encoded

    def get_parameter(self, name: str) -> bool | int | float | str:
        """
        Retrieve the current value of a camera parameter by name.

        Args:
            name (str):
                The GenICam node name (must be a key in
                'parameter_name_to_type_map').

        Returns:
            The parameter value as bool, int, float, or str depending on node
            type.

        Raises:
            RuntimeError:
                - If the camera is not connected.
            KeyError:
                - If 'name' is not in 'parameter_name_to_type_map'.
            ValueError:
                - If the node type is not supported.
        """
        if not self._is_connected:
            raise RuntimeError("Camera is not connected.")
        if name not in self.parameter_name_to_type_map:
            raise KeyError(f"Unknown parameter: {name!r}")
        node_type = self.parameter_name_to_type_map[name]
        assert self._remote_nodemap is not None
        if node_type is ids_peak.FloatNode:
            return cast(
                ids_peak.FloatNode, self._remote_nodemap.FindNode(name)
            ).Value()
        elif node_type is ids_peak.IntegerNode:
            return cast(
                ids_peak.IntegerNode, self._remote_nodemap.FindNode(name)
            ).Value()
        elif node_type is ids_peak.EnumerationNode:
            return (
                cast(
                    ids_peak.EnumerationNode,
                    self._remote_nodemap.FindNode(name),
                )
                .CurrentEntry()
                .SymbolicValue()
            )
        elif node_type is ids_peak.BooleanNode:
            return cast(
                ids_peak.BooleanNode, self._remote_nodemap.FindNode(name)
            ).Value()
        else:
            raise ValueError(
                f"Unsupported node type for get_parameter: {node_type}"
            )

    def _range_from_node(self, node_name: str) -> Range:
        """
        Get the range of a node by name.

        Args:
            node_name (str): The name of the node.

        Returns:
            The range of the node as a Range object.
        Raises:
            ValueError:
                - If the node has no supported increment type.
        """
        assert self._remote_nodemap is not None
        raw_node = cast(
            ids_peak.IntegerNode | ids_peak.FloatNode,
            self._remote_nodemap.FindNode(node_name),
        )
        increment_type = raw_node.IncrementType()
        node_type = raw_node.Type()
        if increment_type == ids_peak.NodeIncrementType_NoIncrement:
            return Range(
                raw_node.Minimum(),
                raw_node.Maximum(),
                0.0 if node_type is ids_peak.NodeType_Float else 0,
            )
        elif increment_type == ids_peak.NodeIncrementType_FixedIncrement:
            return Range(
                raw_node.Minimum(), raw_node.Maximum(), raw_node.Increment()
            )
        else:
            raise ValueError(f"Node {node_name} has no supported increment")

    def set_parameter(
        self,
        name: str,
        value: bool | int | float | str,
    ) -> None:
        """
        Set a camera parameter to the given value.

        Args:
            name (str):
                The GenICam node name (must be a key in
                'parameter_name_to_type_map').
            value (bool | int | float | str):
                The new value. Type must match the node type:
                - FloatNode  → int or float
                - IntegerNode → int
                - EnumerationNode → str (symbolic value)
                - BooleanNode → bool

        Raises:
            RuntimeError:
                - If the camera is not connected.
            KeyError:
                - If 'name' is not in 'parameter_name_to_type_map'.
            TypeError:
                - If 'value' has the wrong Python type for this node.
            ValueError:
                - If 'value`' is out of range or not an available enum entry.
        """
        if not self._is_connected:
            raise RuntimeError("Camera is not connected.")
        if name not in self.parameter_name_to_type_map:
            raise KeyError(f"Unknown parameter: {name!r}")
        node_type = self.parameter_name_to_type_map[name]
        assert self._remote_nodemap is not None

        raw_node = self._remote_nodemap.TryFindNode(name)
        was_started = False
        # Check whether the node is available and writeable. If not start the
        # acquisition and revoke the buffers and check again. If not is still
        # not available and writable, raise and error
        if raw_node.IsAvailable() and not raw_node.IsWriteable():
            was_started = self._is_acquisition_started
            if was_started:
                self._stop_acquisition()
                # Revoke announced buffers after stopping acquisition because
                # settings that influence the payload size might change
                # before starting the acquisition.
                self._revoke_buffers()
            if not raw_node.IsAvailable():
                raise RuntimeError(f"Parameter {name} is not available.")
            if not raw_node.IsWriteable():
                raise RuntimeError(f"Parameter {name} is not writeable.")

        if node_type is ids_peak.FloatNode:
            if not isinstance(value, (int, float)):
                raise TypeError(
                    f"{name} expects a float, got {type(value).__name__}"
                )
            r = self._range_from_node(name)
            if not (r.minimum <= float(value) <= r.maximum):
                raise ValueError(
                    f"{name}={value} out of range [{r.minimum}, {r.maximum}]"
                )
            cast(
                ids_peak.FloatNode, self._remote_nodemap.FindNode(name)
            ).SetValue(float(value))
        elif node_type is ids_peak.IntegerNode:
            if not isinstance(value, int):
                raise TypeError(
                    f"{name} expects an int, got {type(value).__name__}"
                )
            r = self._range_from_node(name)
            if not (r.minimum <= value <= r.maximum):
                raise ValueError(
                    f"{name}={value} out of range [{r.minimum}, {r.maximum}]"
                )
            cast(
                ids_peak.IntegerNode, self._remote_nodemap.FindNode(name)
            ).SetValue(value)
        elif node_type is ids_peak.EnumerationNode:
            if not isinstance(value, str):
                raise TypeError(
                    f"{name} expects a str, got {type(value).__name__}"
                )
            raw_node = cast(
                ids_peak.EnumerationNode, self._remote_nodemap.FindNode(name)
            )
            available = [e.SymbolicValue() for e in raw_node.AvailableEntries()]
            if value not in available:
                raise ValueError(
                    f"{name}={value!r} not in available entries: {available}"
                )
            raw_node.SetCurrentEntry(value)
        elif node_type is ids_peak.BooleanNode:
            if not isinstance(value, bool):
                raise TypeError(
                    f"{name} expects a bool, got {type(value).__name__}"
                )
            cast(
                ids_peak.BooleanNode, self._remote_nodemap.FindNode(name)
            ).SetValue(value)
        else:
            raise ValueError(
                f"Unsupported node type for set_parameter: {node_type}"
            )

        if was_started:
            self._alloc_buffers()

    # BabyROS methods
    def _handle_connection_trigger(
        self, request: dict[str, bool]
    ) -> dict[str, bool]:
        """
        Handle the connection trigger from BabyROS. Connects or disconnects the
        camera based on the 'connect' field in the request.

        Args:
            request (dict[str, bool]):
                A dictionary with a 'connect' field that indicates whether to
                connect or disconnect the camera.

        Returns:
            A dictionary with a 'status' field indicating the current connection
            status of the camera after handling the trigger.

        Raises:
            RuntimeError:
                - If the connection or disconnection process fails.
        """
        connect = request.get("connect", False)
        try:
            if connect and not self._is_connected:
                is_connected = self.connect()
                self._is_connected = is_connected
            elif not connect and self._is_connected:
                self.disconnect()
                self._is_connected = False
        except RuntimeError as e:
            logger.error(f"Connection trigger failed for {self._name}: {e}")
        return {"status": self._is_connected}

    def _handle_parameter(self, request: dict[str, Any]) -> dict[str, Any]:
        """
        Handle the parameter trigger from BabyROS. Gets or sets a camera
        parameter based on the 'mode' field in the request. The 'name' field
        specifies the parameter name, and the 'value' field specifies the new
        value for 'set' mode.

        Args:
            request (dict[str, Any]):
                A dictionary with the following fields:
                - 'mode' (str): Either 'get' or 'set' to indicate the operation.
                - 'name' (str): The name of the parameter to get or set.
                - 'value' (Any): The new value for the parameter (required for
                    'set' mode).
        Returns:
            A dictionary with the following fields:
            - 'name' (str): The name of the parameter that was accessed.
            - 'value' (Any): The current value of the parameter after the get or
                set operation. For 'get' mode, this is the retrieved value. For
                'set' mode, this is the new value that was set.
            - 'status' (bool): True if the operation was successful, False
            otherwise.

        Raises:
            RuntimeError:
                - If the get or set operation fails, e.g., due to an invalid
                  parameter name or value.
        """
        mode = request.get("mode", "get")
        parameter_name = request["name"]
        parameter_value = None
        try:
            if mode == "get":
                parameter_value = self.get_parameter(parameter_name)
            elif mode == "set":
                parameter_value = request["value"]
                self.set_parameter(parameter_name, parameter_value)
            else:
                raise RuntimeError(
                    f"Unsupported mode {mode} for parameter handling. Use "
                    f"either 'get' or 'set'."
                )
        except RuntimeError as e:
            logger.error(f"Parameter trigger failed: {e}")
        return {
            "name": parameter_name,
            "value": parameter_value,
            "status": True,
        }

    def _handle_capture(self, request: dict[str, bool]) -> Optional[np.ndarray]:
        """
        Handle the capture trigger from BabyROS.

        Args:
            request (dict[str, bool]):
                Not used currently, but can be extended in the future.
        """
        image = self.capture_single_color_frame()
        if image is not None:
            return image
        else:
            logger.error(f"Unable to capture image with camera {self._name}.")
            return None

    def start_video_stream(self, _=None) -> None:
        """
        Start the video stream. Continuously captures video frames and publishes
        them until the stream is stopped or the camera is disconnected.

        The image is encoded before publishing to reduce the bandwidth.

        Args:
            _: Unused trigger payload from the BabyROS subscriber.
        """
        self._is_streaming = True
        start_time = time.time()
        frame_count = 0
        fps = 0
        logger.info(f"Started video stream for camera {self._name}.")
        while self._is_streaming and self._is_connected:
            image = self.capture_video_color_frame()
            if image is not None:
                # Compressed version
                encoded = self._encode_image(image)
                # Reshape to (1, N, 1) so it looks like 3D for babyros
                encoded = encoded.reshape(1, -1, 1)
                self._video_frame_publisher.publish(encoded)
            else:
                logger.warning(f"Image is None for camera {self._name}.")
            elapsed = time.time() - start_time
            frame_count += 1
            if elapsed >= 1.0:
                fps = frame_count / elapsed
                logger.info(f"FPS: {fps:.2f}")
                frame_count = 0
                start_time = time.time()

    def stop_video_stream(self, _=None) -> None:
        """
        Stop the running video stream.

        Args:
            _: Unused trigger payload from the BabyROS subscriber.
        """
        self._is_streaming = False
        logger.info(f"Stoped video stream for camera {self._name}")

    def delete(self) -> None:
        """
        Release Python resources with disconnect() and shutdown all node servers
        """
        self._connect_server.delete()
        self._capture_single_color_frame_server.delete()
        self._parameter_server.delete()
        self._video_frame_publisher.delete()
        self._start_video_stream.delete()
        self._stop_video_stream.delete()
        logger.info(f"Deleted all servers of camera {self._name}")
