<div align="center">
  <p>
    <a align="center" href="" target="_blank">
      <img
        width="100%"
        src="https://telekinesis-public-assets.s3.us-east-1.amazonaws.com/Telekinesis+Banner.png"
      >
    </a>
  </p>

  <br>

  [Telekinesis Examples](https://github.com/telekinesis-ai/telekinesis-examples) | [Telekinesis Data](https://gitlab.com/telekinesis/telekinesis-data)
  <br>

[![PyPI version](https://img.shields.io/pypi/v/telekinesis-medulla)](https://pypi.org/project/telekinesis-medulla/)
[![License](https://img.shields.io/pypi/l/telekinesis-medulla)](https://pypi.org/project/telekinesis-medulla/)
[![Python versions](https://img.shields.io/pypi/pyversions/telekinesis-medulla)](https://pypi.org/project/telekinesis-medulla/)

</div>

<p align="center">
  <a href="https://github.com/telekinesis-ai">GitHub</a>
  &nbsp;•&nbsp;
  <a href="https://www.linkedin.com/company/telekinesis-ai/">LinkedIn</a>
  &nbsp;•&nbsp;
  <a href="https://x.com/telekinesis_ai">X</a>
  &nbsp;•&nbsp;
  <a href="https://discord.gg/7NnQ3bQHqm">Discord</a>
</p>


# Medulla: Hardware Communication Skills

Medulla is a module in the Telekinesis SDK for connecting to cameras and hardware devices. It provides tools to interface with various 2D and 3D cameras and integrate them into Telekinesis applications.
It includes:
- 2D and 3D camera interfacing
- Data acquisition and preprocessing
- Time-synchronized sensor streams
- Integration with Telekinesis modules (Vitreous, Retina, Cornea, Pupil, Neuroplan)

This library is used for robotics applications that require camera connectivity, including vision pipelines, multi-camera robot perception, and Physical AI agent integration.

**Medulla is currently in its early development phase (pre-1.0). There will be continuous minor version updates that may introduce new features and improvements. To ensure compatibility and have the latest features, please always install or upgrade to the latest version of the package.**

## Installation

1. Create an isolated environment to avoid dependency conflicts. We recommend installing `Miniconda` by following the instructions from [here](https://docs.conda.io/en/latest/miniconda.html#installing).

2. Create a new `conda` environment called `telekinesis-medulla`:
    ```bash
    conda create -n telekinesis-medulla python=3.11
    ```

3. Activate the environment:
    ```bash
    conda activate telekinesis-medulla
    ```

4. Install the package using `pip`:

    **We currently support Python versions - 3.11, 3.12. Ensure your environment is in the specified Python version.**

    ```bash
    pip install telekinesis-medulla
    ```

### Additional Setup

Camera drivers and vendor SDKs require additional installation steps. Please follow the [Installation details](docs/installation.md) for vendor-specific SDK setup.

### Dependencies

Medulla requires BabyROS. Please refer to the README in [BabyROS](https://github.com/telekinesis-ai/babyros) to install it.

## Example

Install the optional dependencies in order to run the examples

Run a sample Python script to quickly test your installation.

1. Create a `Python` file named `medulla_example.py` in a directory of your choice and paste the following:

    ```python
    from medulla.cameras import webcam

    camera = webcam.Webcam(name="my_webcam", camera_id=0)
    camera.connect()
    image = camera.capture_single_color_frame()
    camera.disconnect()
    ```

2. On a terminal, navigate to the directory where `medulla_example.py` was created and run:

    ```bash
    python medulla_example.py
    ```

## Supported Cameras

| Vendor | Status |
| --- | --- |
| Webcam | Available |
| IDS | Available |
| ZIVID | Coming Soon |
| SensoPart | Coming Soon |
| MechMind | Coming Soon |
| Azure Kinect | Coming Soon |
| Intel RealSense | Coming Soon |


## Resources

- Examples  
  Runnable usage examples for Medulla: [Telekinesis Examples](https://github.com/telekinesis-ai/telekinesis-examples)

- Documentation  
  Full SDK documentation and usage details: [Telekinesis Documentation](https://docs.telekinesis.ai)

- Sample Data  
  Datasets used across the examples: [Telekinesis Data](https://gitlab.com/telekinesis/telekinesis-data)

## Support

For issues and questions:
- Create an [issue](https://github.com/telekinesis-ai/telekinesis-examples/issues) in the GitHub repository.
- Contact the Telekinesis development team at support@telekinesis.ai or on [Discord](https://discord.com/invite/7NnQ3bQHqm).


## Resources

- Examples  
  Runnable usage examples for Medulla: [Telekinesis Examples](https://github.com/telekinesis-ai/telekinesis-examples)

- Documentation  
  Full SDK documentation and usage details: [Telekinesis Documentation](https://docs.telekinesis.ai)

- Sample Data  
  Datasets used across the examples: [Telekinesis Data](https://gitlab.com/telekinesis/telekinesis-data)

## Support

For issues and questions:
- Create an [issue](https://github.com/telekinesis-ai/telekinesis-examples/issues) in the GitHub repository.
- Contact the Telekinesis development team at support@telekinesis.ai or on [Discord](https://discord.com/invite/7NnQ3bQHqm).
