from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List, Tuple
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


def create_async_redis_client(
    host: str = "localhost",
    port: int = 6379,
    password: Optional[str] = None,
    username: Optional[str] = None,
    db: int = 0,
    sentinel_hosts: Optional[List[Tuple[str, int]]] = None,
    master_name: Optional[str] = None,
    decode_responses: bool = False,
    socket_keepalive: bool = True,
    socket_timeout: int = 30,
    health_check_interval: int = 30,
    max_connections: Optional[int] = None,
    socket_connect_timeout: Optional[int] = None,
):
    """Create an async Redis client, with Sentinel support if configured.

    Args:
        host: Redis host (used as fallback if Sentinel not configured)
        port: Redis port
        password: Redis password
        username: Redis username (Redis 6.0+ ACL)
        db: Redis database number
        sentinel_hosts: List of (host, port) tuples for Sentinel nodes
        master_name: Sentinel master name
        decode_responses: Whether to decode byte responses
        socket_keepalive: Enable TCP keepalive
        socket_timeout: Socket timeout in seconds
        health_check_interval: Health check interval in seconds
        max_connections: Max pool connections (None = default)
        socket_connect_timeout: Connect timeout (None = use socket_timeout)

    Returns:
        redis.asyncio.Redis client (either direct or via Sentinel)
    """
    import redis.asyncio as aioredis

    if sentinel_hosts and master_name:
        from redis.asyncio.sentinel import Sentinel as AsyncSentinel

        sentinel_kwargs: Dict[str, Any] = {
            "socket_timeout": socket_timeout,
        }
        if password is not None:
            sentinel_kwargs["password"] = password
        sentinel = AsyncSentinel(sentinel_hosts, **sentinel_kwargs)
        master_kwargs: Dict[str, Any] = {
            "db": db,
            "socket_timeout": socket_timeout,
            "decode_responses": decode_responses,
            "retry_on_timeout": True,
            "health_check_interval": health_check_interval,
            "socket_keepalive": socket_keepalive,
        }
        if password is not None:
            master_kwargs["password"] = password
        if username is not None:
            master_kwargs["username"] = username
        client = sentinel.master_for(master_name, **master_kwargs)
        logger.info(
            "Created async Redis Sentinel client (master=%s, sentinels=%d)",
            master_name, len(sentinel_hosts),
        )
        return client

    kwargs: Dict[str, Any] = {
        "host": host,
        "port": port,
        "db": db,
        "decode_responses": decode_responses,
        "socket_keepalive": socket_keepalive,
        "socket_timeout": socket_timeout,
        "health_check_interval": health_check_interval,
    }
    if password is not None:
        kwargs["password"] = password
    if username is not None:
        kwargs["username"] = username
    if max_connections is not None:
        kwargs["max_connections"] = max_connections
    if socket_connect_timeout is not None:
        kwargs["socket_connect_timeout"] = socket_connect_timeout

    return aioredis.Redis(**kwargs)


@dataclass
class CameraConfig:
    """Configuration for a camera stream."""
    camera_id: str
    input_topic: str
    output_topic: str
    stream_config: Dict[str, Any] = field(default_factory=dict)
    enabled: bool = True


@dataclass
class StreamMessage:
    """Raw message from stream."""
    camera_id: str
    message_key: str
    data: Any
    timestamp: datetime
    priority: int = 1