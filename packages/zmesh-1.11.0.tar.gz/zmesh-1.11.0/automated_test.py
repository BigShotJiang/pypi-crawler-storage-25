import pytest
import numpy as np
import gzip
import os
import sys

import zmesh

DTYPE = [ np.uint8, np.uint16, np.uint32, np.uint64 ]

@pytest.fixture
def connectomics_labels():
  with gzip.open('./connectomics.npy.gz', 'rb') as f:
    return np.load(f)

@pytest.fixture
def fanc_label():
  with gzip.open('./fanc_bug.npy.gz', 'rb') as f:
    return np.load(f)[...,0]

@pytest.mark.parametrize("dtype", DTYPE)
@pytest.mark.parametrize("close", [ False, True ])
@pytest.mark.parametrize("order", [ 'C', 'F' ])
def test_executes_legacy(dtype, close, order):
  labels = np.zeros( (11,17,19), dtype=dtype, order=order)
  labels[1:-1, 1:-1, 1:-1] = 1

  mesher = zmesh.Mesher( (4,4,40) )
  mesher.mesh(labels, close=close)

  mesh = mesher.get_mesh(1, normals=False)
  assert len(mesh.vertices) > 0
  assert len(mesh.faces) > 0
  assert mesh.normals is None

  mesh = mesher.get_mesh(1, normals=True)
  assert len(mesh.vertices) > 0
  assert len(mesh.faces) > 0
  assert len(mesh.normals) > 0


@pytest.mark.parametrize("dtype", DTYPE)
@pytest.mark.parametrize("close", [ False, True ])
@pytest.mark.parametrize("order", [ 'C', 'F' ])
def test_executes(dtype, close, order):
  labels = np.zeros( (11,17,19), dtype=dtype, order=order)
  labels[1:-1, 1:-1, 1:-1] = 1

  mesher = zmesh.Mesher( (4,4,40) )
  mesher.mesh(labels, close=close)

  mesh = mesher.get(1, normals=False)
  assert len(mesh.vertices) > 0
  assert len(mesh.faces) > 0
  assert mesh.normals is None

  mesh = mesher.get(1, normals=True)
  assert len(mesh.vertices) > 0
  assert len(mesh.faces) > 0
  assert len(mesh.normals) > 0

@pytest.mark.parametrize("dtype", DTYPE)
@pytest.mark.parametrize("order", [ 'C', 'F' ])
def test_simplify(dtype, order):
  labels = np.zeros( (11,17,19), dtype=dtype, order=order)
  labels[1:-1, 1:-1, 1:-1] = 1

  mesher = zmesh.Mesher( (4,4,40) )
  mesher.mesh(labels)

  mesh = mesher.get_mesh(1, normals=False)
  Nv = len(mesh.vertices)
  Nf = len(mesh.faces)
  
  mesh = mesher.simplify(mesh, reduction_factor=10, max_error=40)
  assert len(mesh) > 0
  assert len(mesh) < Nv 
  assert mesh.faces.shape[0] < Nf
  assert mesh.normals is None or mesh.normals.size == 0

  mesh = mesher.simplify(mesh, reduction_factor=10, max_error=40, compute_normals=True)
  assert len(mesh) > 0
  assert len(mesh) < Nv 
  assert mesh.faces.shape[0] < Nf
  assert mesh.normals.size > 0

  mesher.voxel_res = (1,1,1)
  mesh = mesher.get_mesh(1, normals=False)

  # ensure negative vertices work
  mesh.vertices -= 10000
  mesh = mesher.simplify(mesh, reduction_factor=2, max_error=40, compute_normals=True)
  assert len(mesh) > 0
  assert len(mesh) <= Nv 
  assert mesh.faces.shape[0] <= Nf
  assert mesh.normals.size > 0

  # check that upper limit of precision errors
  try:
    mesh.vertices[0] = 0
    mesh.vertices[1:] = 2**20
    mesh = mesher.simplify(mesh, reduction_factor=2, max_error=40, compute_normals=True)
    assert False
  except ValueError:
    pass

@pytest.mark.parametrize("dtype", DTYPE)
def test_precomputed_legacy(dtype):
  labels = np.zeros( (11,17,19), dtype=dtype)
  labels[1:-1, 1:-1, 1:-1] = 1

  mesher = zmesh.Mesher( (4,4,40) )
  mesher.mesh(labels)
  mesh = mesher.get_mesh(1, normals=False)

  precomputed_mesh = mesh.to_precomputed()
  reconstituted = zmesh.Mesh.from_precomputed(precomputed_mesh)
  assert reconstituted == mesh

  mesh = mesher.get_mesh(1, normals=True)

  precomputed_mesh = mesh.to_precomputed()
  reconstituted = zmesh.Mesh.from_precomputed(precomputed_mesh)
  assert reconstituted != mesh # Precomputed doesn't preserve normals

@pytest.mark.parametrize("dtype", DTYPE)
def test_precomputed(dtype):
  labels = np.zeros( (11,17,19), dtype=dtype)
  labels[1:-1, 1:-1, 1:-1] = 1

  mesher = zmesh.Mesher( (4,4,40) )
  mesher.mesh(labels)
  mesh = mesher.get(1, normals=False)

  precomputed_mesh = mesh.to_precomputed()
  reconstituted = zmesh.Mesh.from_precomputed(precomputed_mesh)
  assert reconstituted == mesh

  mesh = mesher.get(1, normals=True)

  precomputed_mesh = mesh.to_precomputed()
  reconstituted = zmesh.Mesh.from_precomputed(precomputed_mesh)
  assert reconstituted != mesh # Precomputed doesn't preserve normals

def test_obj_import():
  labels = np.zeros( (11,17,19), dtype=np.uint32)
  labels[1:-1, 1:-1, 1:-1] = 1

  mesher = zmesh.Mesher( (4,4,40) )
  mesher.mesh(labels)
  mesh = mesher.get(1, normals=False)

  obj_str = mesh.to_obj()
  mesh2 = zmesh.Mesh.from_obj(obj_str)
  
  assert mesh == mesh2

def test_ply_import():
  labels = np.zeros( (11,17,19), dtype=np.uint32)
  labels[1:-1, 1:-1, 1:-1] = 1

  mesher = zmesh.Mesher( (4,4,40) )
  mesher.mesh(labels)
  mesh = mesher.get(1, normals=False)

  plydata = mesh.to_ply()
  mesh2 = zmesh.Mesh.from_ply(plydata)
  
  assert mesh == mesh2

def test_C_F_meshes_same_legacy(connectomics_labels):
  connectomics_labels = connectomics_labels[102:,31:,17:]

  fdata = np.asfortranarray(connectomics_labels)
  cdata = np.ascontiguousarray(connectomics_labels)

  f_mesher = zmesh.Mesher((1,1,1))
  f_mesher.mesh(fdata)

  c_mesher = zmesh.Mesher((1,1,1))
  c_mesher.mesh(cdata)

  cids = c_mesher.ids()
  cids.sort()
  fids = f_mesher.ids()
  fids.sort()
  assert cids == fids

  for label in c_mesher.ids()[:300]:
    c_mesh = c_mesher.get_mesh(label, normals=False, simplification_factor=0)
    f_mesh = f_mesher.get_mesh(label, normals=False, simplification_factor=0)
    assert np.isclose(c_mesh.vertices.mean(), f_mesh.vertices.mean())

@pytest.mark.parametrize("transpose", [True,False])
def test_fanc_bug(fanc_label, transpose):
  if transpose:
    fanc_label = fanc_label.T
  fdata = np.asfortranarray(fanc_label)
  cdata = np.ascontiguousarray(fanc_label)

  f_mesher = zmesh.Mesher((1,1,1))
  f_mesher.mesh(fdata)

  c_mesher = zmesh.Mesher((1,1,1))
  c_mesher.mesh(cdata)

  assert c_mesher.ids() == f_mesher.ids()

  for label in c_mesher.ids():
    c_mesh = c_mesher.get(label, normals=False, reduction_factor=0)
    f_mesh = f_mesher.get(label, normals=False, reduction_factor=0)
    assert np.isclose(c_mesh.vertices.mean(), f_mesh.vertices.mean())

@pytest.mark.parametrize("order", [ 'C', 'F' ])
def test_unsimplified_meshes_remain_the_same(connectomics_labels, order):
  if order == "C":
    connectomics_labels = np.ascontiguousarray(connectomics_labels)
  else:
    connectomics_labels = np.asfortranarray(connectomics_labels)

  mesher = zmesh.Mesher( (32,32,40) )
  mesher.mesh(connectomics_labels)

  for lbl in mesher.ids()[:300]:
    with gzip.open(f"./connectomics_npy_meshes/unsimplified/{lbl}.ply.gz", "rb") as f:
      old_mesh = zmesh.Mesh.from_ply(f.read())
    new_mesh = mesher.get_mesh(lbl, normals=False, simplification_factor=0, max_simplification_error=40)
    assert np.all(np.sort(old_mesh.vertices[old_mesh.faces], axis=0) == np.sort(new_mesh.vertices[new_mesh.faces], axis=0))
    print(lbl, "ok")


  mesher = zmesh.Mesher( (1,1,1) )
  mesher.mesh(connectomics_labels)

  mesher2 = zmesh.Mesher( (1,1,1) )
  mesher2.mesh(connectomics_labels)

  for lbl in mesher.ids()[:50]:
    old_mesh = mesher.get_mesh(lbl, normals=False, simplification_factor=0, max_simplification_error=40)
    new_mesh = mesher2.get(lbl, normals=False, reduction_factor=0, max_error=40)

    old_pts = old_mesh.vertices[old_mesh.faces]
    old_pts = old_pts.reshape(old_pts.shape[0] * old_pts.shape[1], 3)
    transposed_old = np.copy(old_pts)
    transposed_old[:,0] = old_pts[:,2]
    transposed_old[:,2] = old_pts[:,0]
    del old_pts
    transposed_old.sort(axis=0)

    new_pts = new_mesh.vertices[new_mesh.faces]
    new_pts = new_pts.reshape(new_pts.shape[0] * new_pts.shape[1], 3)
    new_pts.sort(axis=0)

    assert np.all(transposed_old == new_pts)
    print(lbl, "ok")  

# F order meshes are processed in a different order and so
# the simplifier produces a different mesh. Will have to add F order examples
# in order to test.
@pytest.mark.parametrize("order", [ 'C' ])
@pytest.mark.skipif(sys.platform != 'darwin', reason="Different implementations of unordered_map on different platforms have different iteration behavior. Only MacOS will match.")
def test_simplified_meshes_remain_the_same(connectomics_labels, order):
  if order == "C":
    connectomics_labels = np.ascontiguousarray(connectomics_labels)
  else:
    connectomics_labels = np.asfortranarray(connectomics_labels)

  mesher = zmesh.Mesher( (32,32,40) )
  mesher.mesh(connectomics_labels)

  for lbl in mesher.ids()[:300]:
    with gzip.open(f"./connectomics_npy_meshes/simplified/{lbl}.ply.gz", "rb") as f:
      old_mesh = zmesh.Mesh.from_ply(f.read())
    new_mesh = mesher.get_mesh(lbl, normals=False, simplification_factor=100, max_simplification_error=40)

    f1 = np.sort(np.sort(old_mesh.faces, axis=0), axis=1)
    f2 = np.sort(np.sort(new_mesh.faces, axis=0), axis=1)
    v1 = np.sort(old_mesh.vertices[f1], axis=0)
    v2 = np.sort(new_mesh.vertices[f2], axis=0)
    assert np.all(np.isclose(v1, v2))
    print(lbl, "ok")


@pytest.mark.parametrize("reduction_factor", [2,5,10])
def test_min_error_skip(reduction_factor):
  for order in ['C','F']:
    labels = np.zeros((11, 17, 19), dtype=np.uint8, order=order)
    labels[1:-1, 1:-1, 1:-1] = 1

    mesher = zmesh.Mesher((4, 4, 40))
    mesher.mesh(labels)

    original_mesh = mesher.get_mesh(1, normals=False)
    mesh = mesher.simplify(
        original_mesh, 
        reduction_factor=reduction_factor, 
        max_error=40, 
        min_error=0,
        compute_normals=True
    )
    factor = len(original_mesh.faces) / len(mesh.faces)
    assert abs(factor - reduction_factor) < 1


def test_chunk_shape():
  labels = np.zeros( (10, 10, 10), dtype=np.uint32)
  labels[1:-1, 1:-1, 1:-1] = 1

  mesher = zmesh.Mesher( (1, 1, 1) )
  mesher.mesh(labels)
  mesh = mesher.get_mesh(1, normals=False, simplification_factor=0, max_simplification_error=100)

  meshes = zmesh.chunk_mesh(
    mesh,
    [5.,5.,5.],
  )

  assert len(meshes) == 8
  assert not any([
    m.empty() for m in meshes.values()
  ])

def test_delete_unreference_vertices():
  vertices = [
    [0,0,0],
    [0,1,0],
    [1,0,0],
    [5,5,5],
    [7,7,7],
    [8,7,7],
    [7,8,8],
  ]
  faces = [[0,1,2],[4,5,6]]

  mesh = zmesh.Mesh(vertices=vertices, faces=faces, normals=None)
  res = mesh.remove_unreferenced_vertices()

  ans_verts = vertices[:3] + vertices[4:]
  ans_faces = [[0,1,2],[3,4,5]]

  assert res.vertices.shape == (6,3)
  assert res.faces.shape == (2,3)
  assert np.all(res.vertices == np.array(ans_verts))
  assert np.all(res.faces == np.array(ans_faces))

def test_chunk_mesh_triangle():
  vertices = [
    [0,0,0],
    [0,1,0],
    [1,0,0],
  ]
  faces = [[0,1,2]]

  mesh = zmesh.Mesh(vertices=vertices, faces=faces, normals=None)

  meshes = zmesh.chunk_mesh(mesh, [.5,.5,.5])

  meshes = [ m for m in meshes.values() if not m.empty() ]

  assert len(meshes) == 3

  m = zmesh.Mesh.concatenate(*meshes).consolidate()

  assert m.vertices.shape[0] == 6

  assert [0,0,0] in m.vertices
  assert [1,0,0] in m.vertices
  assert [0,1,0] in m.vertices
  assert [0,0.5,0] in m.vertices
  assert [0.5,0,0] in m.vertices
  assert [0.5,0.5,0] in m.vertices

  
def test_vertex_ccl_single_component():
  vertices = [
    [0,0,0],
    [1,0,0],
    [0,1,0],
    [0,0,1],
    [1,0,1],
  ]
  faces = [
    [0, 1, 2],
    [2, 3, 4],
  ]
  mesh = zmesh.Mesh(vertices, faces)
  ccls = zmesh.vertex_connected_components(mesh)
  assert len(ccls) == 1


def test_vertex_ccl_separate_components():
  vertices = [
    [0,0,0],
    [1,0,0],
    [0,1,0],
    [0,0,1],
    [1,0,1],
    [1,1,1],
  ]
  faces = [
    [0, 1, 2],
    [3, 4, 5],
  ]
  mesh = zmesh.Mesh(vertices, faces)
  ccls = zmesh.vertex_connected_components(mesh)
  assert len(ccls) == 2

def test_vertex_ccl_chain():
  vertices = [
    [0,0,0],
    [1,0,0],
    [0,1,0],
    [0,0,1],
    [1,0,1],
    [1,1,1],
    [2,0,1],
  ]
  faces = [
    [0, 1, 2],
    [2, 3, 4],
    [4, 5, 6],
  ]
  mesh = zmesh.Mesh(vertices, faces)
  ccls = zmesh.vertex_connected_components(mesh)
  assert len(ccls) == 1

def test_face_ccl_chain():
  vertices = [
    [0,0,0],
    [1,1,0],
    [1,0,0],
    [2,1,0],
    [2,0,0],
    [3,1,0],
    [3,0,0],
    [4,1,0],
  ]
  faces = [
    [0, 1, 2],
    [2, 1, 3],
    [3, 2, 4],
    [4, 3, 5],
    [5, 4, 6],
    [6, 5, 7],
  ]
  mesh = zmesh.Mesh(vertices, faces)
  ccls = zmesh.face_connected_components(mesh)
  assert len(ccls) == 1

def test_non_manifold_vertex_ccl():

  # a triangle strip where one vertex is shared
  # between two manifolds

  #              here
  # . -- . -- . --. -- .
  #  \  / \  / \ / \  / \
  #   . -- . -- .    . -- .

  vertices = [
    [0,0,0],
    [1,1,0],
    [1,0,0],
    [2,1,0],
    [2,0,0],
    [3,1,0],
    [3,0,0],
    [4,1,0],

    [10, 0, 0],
    [10, 1, 0],
    [11, 0, 0],
  ]
  faces = [
    [0, 1, 2],
    [2, 1, 3],
    [3, 2, 4],
    [4, 3, 5],
    [5, 4, 6],
    [6, 5, 7],
    
    [7, 8, 9],
    [8, 9, 10],
  ]
  mesh = zmesh.Mesh(vertices, faces)
  ccls = zmesh.face_connected_components(mesh)
  assert len(ccls) == 2

  ccls = zmesh.vertex_connected_components(mesh)
  assert len(ccls) == 1

def test_dust_vertex_metric():
  """Test dust removes small components with vertex metric."""
  vertices = [
    [0, 0, 0], [1, 0, 0], [0, 1, 0],  # Component 1: 3 vertices
    [5, 5, 5], [6, 5, 5], [5, 6, 5], [5, 5, 6], [6, 6, 6],  # Component 2: 5 vertices
  ]
  faces = [
    [0, 1, 2],  # Component 1
    [3, 4, 5], [5, 6, 7],  # Component 2
  ]
  mesh = zmesh.Mesh(vertices, faces)

  result = zmesh.dust(mesh, threshold=4, metric="vertices", ccl="vertices")

  # Should remove component with 3 vertices, keep component with 5 vertices
  assert result.vertices.shape[0] == 5
  assert result.faces.shape[0] == 2

def test_dust_face_metric_face_ccl():
  """Test dust removes small components with vertex metric."""
  vertices = [
    [0, 0, 0], [1, 0, 0], [0, 1, 0],  # Component 1: 3 vertices
    [5, 5, 5], [6, 5, 5], [5, 6, 5], [5, 5, 6], [6, 6, 6],  # Component 2: 5 vertices
  ]
  faces = [
    [0, 1, 2],  # Component 1
    [3, 4, 5], [4, 5, 6], [5, 6, 7], # Component 2
  ]
  mesh = zmesh.Mesh(vertices, faces)

  result = zmesh.dust(mesh, threshold=2, metric="faces", ccl="faces")
  # Should remove component with 3 vertices, keep component with 5 vertices
  assert result.vertices.shape[0] == 5
  assert result.faces.shape[0] == 3

def test_dust_vertex_metric_inverted():
  """Test dust keeps large components with invert=True."""
  vertices = [
    [0, 0, 0], [1, 0, 0], [0, 1, 0],  # Component 1: 3 vertices
    [5, 5, 5], [6, 5, 5], [5, 6, 5], [5, 5, 6], [6, 6, 6],  # Component 2: 5 vertices
  ]
  faces = [
    [0, 1, 2],  # Component 1
    [3, 4, 5], [5, 6, 7],  # Component 2
  ]
  mesh = zmesh.Mesh(vertices, faces)

  result = zmesh.dust(mesh, threshold=4, metric="vertices", ccl="vertices", invert=True)

  assert result.vertices.shape[0] == 3
  assert result.faces.shape[0] == 1


def test_dust_face_metric():
  """Test dust with face metric."""
  vertices = [
    [0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1],  # Component 1: 4 vertices, 1 face
    [5, 5, 5], [6, 5, 5], [5, 6, 5], [5, 5, 6],  # Component 2: 4 vertices, 3 faces
  ]
  faces = [
    [0, 1, 2],  # Component 1: 1 face
    [4, 5, 6], [5, 6, 7], [4, 6, 7],  # Component 2: 3 faces
  ]
  mesh = zmesh.Mesh(vertices, faces)

  result = zmesh.dust(mesh, threshold=2, metric="faces", ccl="vertices")

  # Should remove component with 1 face, keep component with 3 faces
  assert result.faces.shape[0] == 3


def test_dust_face_metric_inverted():
  """Test dust with face metric inverted."""
  vertices = [
    [0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1],  # Component 1: 1 face
    [5, 5, 5], [6, 5, 5], [5, 6, 5], [5, 5, 6],  # Component 2: 3 faces
  ]
  faces = [
    [0, 1, 2],  # Component 1
    [4, 5, 6], [5, 6, 7], [4, 6, 7],  # Component 2
  ]
  mesh = zmesh.Mesh(vertices, faces)

  result = zmesh.dust(mesh, threshold=2, metric="faces", ccl="vertices", invert=True)

  assert result.faces.shape[0] == 1

def test_dust_removes_all_components():
  """Test when all components are filtered out."""
  vertices = [
    [0, 0, 0], [1, 0, 0], [0, 1, 0],  # Small component
  ]
  faces = [[0, 1, 2]]
  mesh = zmesh.Mesh(vertices, faces)

  result = zmesh.dust(mesh, threshold=10, metric="vertices", ccl="vertices")

  # All components removed
  assert result.vertices.shape[0] == 0
  assert result.faces.shape[0] == 0

def test_largest_k_vertex_metric():
  """Test keeping k largest components by vertex count."""
  vertices = [
    [0, 0, 0], [1, 0, 0], [0, 1, 0],  # Component 1: 3 vertices
    [3, 3, 3], [4, 3, 3], [3, 4, 3], [3, 3, 4], [4, 4, 4],  # Component 2: 5 vertices
    [7, 7, 7], [8, 7, 7], [7, 8, 7], [7, 7, 8], [8, 8, 8], [8, 8, 9], [9, 9, 9],  # Component 3: 7 vertices
  ]
  faces = [
    [0, 1, 2],  # Component 1
    [3, 4, 5], [5, 6, 7],  # Component 2
    [8, 9, 10], [10, 11, 12], [12, 13, 14],  # Component 3
  ]
  mesh = zmesh.Mesh(vertices, faces)
  result = zmesh.largest_k(mesh, k=2, metric="vertices", ccl="vertices")

  # Should keep 2 largest: component 3 (7 vertices) and component 2 (5 vertices)
  assert result.vertices.shape[0] == 12

def test_largest_k_vertex_metric_inverted():
  """Test keeping k smallest components with invert=True."""
  vertices = [
    [0, 0, 0], [1, 0, 0], [0, 1, 0],  # Component 1: 3 vertices
    [3, 3, 3], [4, 3, 3], [3, 4, 3], [3, 3, 4], [4, 4, 4],  # Component 2: 5 vertices
    [7, 7, 7], [8, 7, 7], [7, 8, 7], [7, 7, 8], [8, 8, 8], [8, 8, 9], [9, 9, 9],  # Component 3: 7 vertices
  ]
  faces = [
    [0, 1, 2],  # Component 1
    [3, 4, 5], [5, 6, 7],  # Component 2
    [8, 9, 10], [10, 11, 12], [12, 13, 14],  # Component 3
  ]
  mesh = zmesh.Mesh(vertices, faces)

  result = zmesh.largest_k(mesh, k=2, metric="vertices", ccl="vertices", invert=True)

  # Should keep 2 smallest: component 1 (3 vertices) and component 2 (5 vertices)
  assert result.vertices.shape[0] == 8


def test_largest_k_face_metric():
  """Test keeping k largest components by face count."""
  vertices = [
    [0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1],  # Component 1: 1 face
    [3, 3, 3], [4, 3, 3], [3, 4, 3], [3, 3, 4],  # Component 2: 3 faces
  ]
  faces = [
    [0, 1, 2],  # Component 1: 1 face
    [4, 5, 6], [5, 6, 7], [4, 6, 7],  # Component 2: 3 faces
  ]
  mesh = zmesh.Mesh(vertices, faces)

  result = zmesh.largest_k(mesh, k=1, metric="faces", ccl="vertices")

  # Should keep largest: component 2 with 3 faces
  assert result.faces.shape[0] == 3


def test_largest_k_k_exceeds_components():
  """Test that original mesh is returned when k >= number of components."""
  vertices = [
    [0, 0, 0], [1, 0, 0], [0, 1, 0],  # Component 1
    [5, 5, 5], [6, 5, 5], [5, 6, 5],  # Component 2
  ]
  faces = [
    [0, 1, 2],  # Component 1
    [3, 4, 5],  # Component 2
  ]
  mesh = zmesh.Mesh(vertices, faces)

  result = zmesh.largest_k(mesh, k=5, metric="vertices", ccl="vertices")

  # k exceeds component count, should return clone of original
  assert result.vertices.shape[0] == 6
  assert result.faces.shape[0] == 2

def test_largest_k_k_equals_one():
  """Test keeping only the single largest component."""
  vertices = [
    [0, 0, 0], [1, 0, 0], [0, 1, 0],  # Component 1: 3 vertices
    [5, 5, 5], [6, 5, 5], [5, 6, 5], [5, 5, 6], [6, 6, 6],  # Component 2: 5 vertices
  ]
  faces = [
    [0, 1, 2],  # Component 1
    [3, 4, 5], [5, 6, 7],  # Component 2
  ]
  mesh = zmesh.Mesh(vertices, faces)

  result = zmesh.largest_k(mesh, k=1, metric="vertices", ccl="vertices")

  # Should keep only component 2 with 5 vertices
  assert result.vertices.shape[0] == 5

def test_largest_k_k_zero():
  """Test edge case with k=0."""
  vertices = [
    [0, 0, 0], [1, 0, 0], [0, 1, 0],
  ]
  faces = [[0, 1, 2]]
  mesh = zmesh.Mesh(vertices, faces)

  result = zmesh.largest_k(mesh, k=0, metric="vertices", ccl="vertices")

  # k=0 should return empty mesh
  assert result.vertices.shape[0] == 0
  assert result.faces.shape[0] == 0

@pytest.mark.parametrize("target_count", [100, 200, 500])
def test_fqmr_simplification(target_count):
  path = os.path.join("connectomics_npy_meshes", "unsimplified")
  for filename in os.listdir(path)[:10]:
    filepath = os.path.join(path, filename)
    mesh = zmesh.Mesh.load(filepath)
    simplified_mesh = zmesh.simplify_fqmr(
      mesh,
      target_count=target_count,
      max_iterations=999,
    )
    assert simplified_mesh.vertices.shape[0] <= target_count
    assert simplified_mesh.vertices.shape[0] > 10




