# cython:language_level = 3
# distutils: language = c++
import cython

from typing import List, Tuple, Sequence

from libc.stdint cimport (
  uint64_t, uint32_t, uint16_t, uint8_t, 
  int64_t, int32_t, int16_t, int8_t,
)
from libcpp.vector cimport vector
from libcpp.string cimport string
from libcpp cimport bool

import operator
from functools import reduce
import sys

cimport numpy as cnp
import numpy as np
from zmesh.mesh import Mesh

cdef extern from "fqmr.hpp" namespace "zmesh::fqmr":
  cdef struct FqmrMesh:
    void set(
      float* verts, uint64_t Nv,
      uint32_t* faces, uint64_t Nf
    )
    vector[float] getVertices()
    vector[uint32_t] getFaces()

  cdef void simplify_to_triangle_count(
    FqmrMesh& mesh,
    int64_t target_count, 
    int update_rate,
    double agressiveness,
    int max_iterations,
    double alpha,
    int K,
    bool lossless,
    double threshold_lossless,
    bool preserve_border
  )

cdef extern from "utility.hpp" namespace "zmesh::utility":
  cdef struct MeshObject:
    vector[float] points
    vector[float] normals
    vector[unsigned int] faces
    void load_obj(string)
    void save_obj(string)

cdef extern from "chunk_mesh.hpp" namespace "zmesh::chunk_mesh":
  cdef vector[MeshObject] chunk_mesh_accelerated(
    float* vertices, uint64_t num_vertices,
    unsigned int* faces, uint64_t num_faces,
    float cx, float cy, float cz,
    float ox, float oy, float oz
  ) except +

  cdef vector[float] compute_vertex_normals_from_faces(
    float* vertices, uint64_t Nv,
    uint32_t* faces, uint64_t Nf
  )

cdef extern from "ccl.hpp" namespace "zmesh::ccl":
  cdef vector[vector[uint64_t]] vertex_connected_components_mask(
    uint64_t* faces, uint64_t num_verts, uint64_t num_faces
  )
  cdef vector[vector[uint64_t]] face_connected_components_mask(
    uint64_t* faces, uint64_t num_faces
  )

cdef extern from "cMesher.hpp" namespace "zmesh":
  cdef cppclass CMesher[P,L,S]:
    CMesher(vector[float] voxel_res) except +
    void mesh(
      L* data, 
      unsigned int sx, 
      unsigned int sy, 
      unsigned int sz, 
      bool c_order
    )
    vector[L] ids()
    MeshObject get_mesh(
      L segid, 
      bool normals,
      int simplification_factor, 
      float max_simplification_error, 
      float min_simplification_error,
      bool transpose
    )
    # NOTE: need to define triangle_t
    MeshObject simplify_points(
      uint64_t* points, 
      size_t Nv, 
      bool normals, 
      int simplification_factor, 
      float max_simplification_error,
      float min_simplification_error,
    )
    bool erase(L segid)
    void clear()
    P pack_coords(P x, P y, P z)


cdef object cpp_meshobj_to_mesh(MeshObject mobj):
  cdef uint64_t Nv = mobj.points.size() // 3
  cdef uint64_t Nf = mobj.faces.size() // 3
  cdef uint64_t Nn = mobj.normals.size() // 3;
  
  points = None
  faces = None
  normals = None
  
  if Nv > 0:
    points = np.asarray(<float[:mobj.points.size()]>mobj.points.data()).reshape(Nv, 3).copy()

  if Nf > 0:
    faces = np.asarray(<unsigned int[:mobj.faces.size()]>mobj.faces.data()).reshape(Nf, 3).copy()

  if Nn > 0:
    normals = np.asarray(<float[:mobj.normals.size()]>mobj.normals.data()).reshape(Nn, 3).copy()

  return Mesh(points, faces, normals)

@cython.binding(True)
def load_obj(filename:str) -> Mesh:
  """Load an obj using accelerated code."""
  cdef MeshObject m;
  m.load_obj(filename.encode("utf8"))
  return cpp_meshobj_to_mesh(m)

@cython.binding(True)
def compute_normals(mesh:Mesh) -> Mesh:
  """
  Returns: Mesh with normals computed
  """
  cdef unsigned int Nv = mesh.vertices.shape[0]
  cdef cnp.ndarray[float, ndim=2] verts = mesh.vertices
  cdef cnp.ndarray[unsigned int, ndim=2] faces = mesh.faces

  cdef vector[float] normals = compute_vertex_normals_from_faces(
    &verts[0,0], Nv,
    &faces[0,0], mesh.faces.size,
  )
  mesh.normals = np.array(normals).reshape((Nv, 3), order="C")
  return mesh

@cython.binding(True)
def compute_normals_meshobj(mesh:dict) -> Mesh:
  """
  Returns: Mesh with normals computed
  """
  cdef unsigned int Nv = len(mesh["points"]) // 3
  cdef unsigned int Nf = len(mesh["faces"]) // 3
  cdef cnp.ndarray[float] verts = np.array(mesh["points"], dtype=np.float32)
  cdef cnp.ndarray[unsigned int] faces = np.array(mesh["faces"], dtype=np.uint32)

  cdef vector[float] normals = compute_vertex_normals_from_faces(
    &verts[0], Nv,
    &faces[0], Nf,
  )
  mesh["normals"] = np.array(normals).reshape((Nv, 3), order="C")
  return mesh

@cython.binding(True)
def simplify_fqmr(
  mesh:Mesh,
  target_count:int, 
  update_rate:int = 5,
  aggressiveness:float = 7,
  max_iterations:int = 100,
  alpha:float = 1e-9,
  K:int = 3,
  preserve_border:bool = False,
  compute_normals:bool = False,
  voxel_centered:bool = False,
  return_iterations:bool = False,
) -> Mesh:
  """
  Perform a quadrics based mesh simplification that 
  does not preserve topology. This version is based
  on the Fast Quadratic Mesh Reduction implementation
  
  https://github.com/Kramer84/pyfqmr-Fast-Quadric-Mesh-Reduction

  This method scores the error resulting from simplifying
  a vertex and performs simplification for all those vertices
  below a certain threshold. At each iteration, the threshold
  is increased until the target count is reached.

  The formula for the current threshold is:

    threshold = alpha * (iteration + K)^aggressiveness

  Where alpha, K, and aggressiveness are user defined and iteration
  starts at 0.

  Parameters
  ----------
  target_count: Target number of triangles
  update_rate: Number of iterations between each update.
  aggressiveness:
      Parameter controlling the growth rate of the threshold at each
      iteration when lossless is False.
  max_iterations:
      Maximal number of iterations
  threshold_lossless: 
      Maximal error after which a vertex is not deleted, only for
      lossless method.
  alpha:
      Parameter for controlling the threshold growth
  K:
      Parameter for controlling the thresold growth
  preserve_border: 
      Flag for preserving vertices on open border

  Returns:
    if return_iterations:
      return (mesh, num_iterations)
    else:
      return mesh
  """
  mesh.vertices = np.ascontiguousarray(mesh.vertices)
  mesh.faces = np.ascontiguousarray(mesh.faces)

  cdef FqmrMesh fqmr_mesh
  cdef cnp.ndarray[float] verts = mesh.vertices.reshape([ mesh.vertices.size, ])
  cdef cnp.ndarray[unsigned int] faces = mesh.faces.reshape([ mesh.faces.size ])

  fqmr_mesh.set(
    <float*>&verts[0], mesh.vertices.shape[0],
    <uint32_t*>&faces[0], mesh.faces.shape[0]
  );

  lossless = False
  threshold_lossless = 1e-4

  num_iters = simplify_to_triangle_count(
    fqmr_mesh, 
    target_count, 
    update_rate, 
    aggressiveness, 
    max_iterations, 
    alpha, 
    K, 
    lossless, 
    threshold_lossless, 
    preserve_border
  )

  simplified_vertices = np.asarray(fqmr_mesh.getVertices(), dtype=np.float32)
  simplifed_faces = np.asarray(fqmr_mesh.getFaces(), dtype=np.uint32)

  simplified_vertices = simplified_vertices.reshape([simplified_vertices.size // 3, 3])
  simplifed_faces = simplifed_faces.reshape([simplifed_faces.size // 3, 3])

  new_mesh = Mesh(simplified_vertices, simplifed_faces, id=mesh.id)

  if compute_normals:
    new_mesh = globals()["compute_normals"](new_mesh)

  if return_iterations:
    return (new_mesh, num_iters)
  else:
    return new_mesh

@cython.binding(True)
def chunk_mesh(
  mesh:Mesh,
  chunk_size:Sequence[float],
  grid_origin:Optional[tuple[float,float,float]] = None,
) -> Dict[Tuple[int,int,int], Mesh]:
  """
  Cut a mesh into a regular grid of meshes.
  """
  vert_order = 'C' if mesh.vertices.flags.c_contiguous else 'F'
  face_order = 'C' if mesh.faces.flags.c_contiguous else 'F'

  cdef cnp.ndarray[float] vertices = mesh.vertices.reshape([mesh.vertices.size], order=vert_order)
  cdef cnp.ndarray[unsigned int] faces = mesh.faces.reshape([mesh.faces.size], order=face_order)

  if vertices.size % 3 != 0:
    raise ValueError(f"Invalid vertex array. Must be a multiple of 3. Got: {vertices.size}")

  if faces.size % 3 != 0:
    raise ValueError(f"Invalid faces array. Must be a multiple of 3. Got: {faces.size}")

  minpt = np.min(mesh.vertices, axis=0)
  maxpt = np.max(mesh.vertices, axis=0)

  if grid_origin is None:
    grid_origin = minpt

  cdef vector[MeshObject] objs = chunk_mesh_accelerated(
    <float*>&vertices[0], mesh.vertices.shape[0],
    <unsigned int*>&faces[0], mesh.faces.shape[0],
    chunk_size[0], chunk_size[1], chunk_size[2],
    grid_origin[0], grid_origin[1], grid_origin[2]
  )
  
  grid_size = np.ceil((maxpt - grid_origin) / np.array(chunk_size)).astype(int)
  grid_size = np.maximum(grid_size, [1,1,1])

  chunked_meshes = {}
  i = 0
  for gz in range(grid_size[2]):
    for gy in range(grid_size[1]):
      for gx in range(grid_size[0]):
        submesh = cpp_meshobj_to_mesh(objs[i])
        if hasattr(mesh, 'id'):
          submesh.id = mesh.id

        i += 1

        if submesh.empty():
          continue
        
        chunked_meshes[(gx,gy,gz)] = submesh
  
  return chunked_meshes
  
@cython.binding(True)
def vertex_connected_components(mesh:Mesh) -> list[Mesh]:
  """
  Split a mesh into its components based on vertex connectivity.

  Note: This can cause shared single points to connect two objects 
    which would be non-manifold geometry. Use face_connected_components
    to guarantee connected components are manifolds.
  """
  if mesh.empty():
    return []

  face_order = 'C' if mesh.faces.flags.c_contiguous else 'F'
  cdef cnp.ndarray[uint64_t] faces = mesh.faces.reshape(
    [mesh.faces.size], order=face_order
  ).astype(np.uint64, copy=False)

  cdef uint64_t Nv = mesh.vertices.shape[0]

  cdef vector[vector[uint64_t]] vertex_masks = vertex_connected_components_mask(
    <uint64_t*>&faces[0], Nv, mesh.faces.shape[0]
  )

  cdef uint64_t[:] mask_view

  face_map = np.zeros([ Nv ], dtype=np.uint64)

  ccls = []
  for mask in vertex_masks:
    if mask.empty():
      continue

    mask_view = <uint64_t[:mask.size()]> &mask[0]
    mask_np = np.frombuffer(
      mask_view,
      dtype=np.uint64,
      count=mask.size()
    )
    uniq, idx = np.unique(mask_np, return_index=True)
    verts = mesh.vertices[uniq]

    face_map[uniq] = np.arange(len(uniq), dtype=np.uint64)
    remapped_faces = face_map[mask_np].reshape(mask.size() // 3, 3, order="C")
    remapped_faces = remapped_faces.astype(mesh.faces.dtype, copy=False)

    ccls.append(
      Mesh(verts, remapped_faces)
    )

  return ccls

@cython.binding(True)
def face_connected_components(mesh:Mesh) -> list[Mesh]:
  """Split a mesh into its components based on face connectivity."""
  if mesh.empty():
    return []

  face_order = 'C' if mesh.faces.flags.c_contiguous else 'F'
  cdef cnp.ndarray[uint64_t] faces = mesh.faces.reshape(
    [mesh.faces.size], order=face_order
  ).astype(np.uint64, copy=False)

  cdef vector[vector[uint64_t]] face_masks = face_connected_components_mask(
    <uint64_t*>&faces[0], mesh.faces.shape[0]
  )

  cdef uint64_t[:] mask_view
  face_map = np.zeros([ mesh.vertices.shape[0] ], dtype=np.uint64)

  ccls = []
  for mask in face_masks:
    if mask.empty():
      continue

    mask_view = <uint64_t[:mask.size()]> &mask[0]
    mask_np = np.frombuffer(
      mask_view,
      dtype=np.uint64,
      count=mask.size()
    )

    ccl_faces = mesh.faces[mask_np,:].reshape(-1)
    uniq, idx = np.unique(ccl_faces, return_index=True)
    verts = mesh.vertices[uniq]

    face_map[uniq] = np.arange(len(uniq), dtype=np.uint64)
    remapped_faces = face_map[ccl_faces].reshape(ccl_faces.size // 3, 3, order="C")
    remapped_faces = remapped_faces.astype(mesh.faces.dtype, copy=False)

    ccls.append(
      Mesh(verts, remapped_faces)
    )

  return ccls

def _normalize_mesh(mesh, voxel_centered, physical, resolution):
  """Apply scaling factors to convert from zmesh internals to physical coordinates."""

  if not physical:
    mesh.vertices *= resolution

  if voxel_centered:
    mesh.vertices += resolution
  
  mesh.vertices /= 2.0
  return mesh

class Mesher:
  """
  Represents a meshed volume. 

  Call mesher.mesh(labels) then you can 
  extract meshes from it using mesher.get(label).
  """
  def __init__(self, voxel_res):
    self.voxel_res = voxel_res
    self._mesher = Mesher6464(self.voxel_res)

  @property
  def voxel_res(self):
    return self._voxel_res

  @voxel_res.setter
  def voxel_res(self, res):
    self._voxel_res = np.array(res, dtype=np.float32)

  @cython.binding(True)
  def mesh(self, data, close=False):
    """
    Triggers the multi-label meshing process.
    After the mesher has run, you can call mesher.get.

    data: 3d numpy array
    close: By default, meshes flush against the edge of
      the image will be left open on the sides that touch
      the boundary. If True, this ensures that all meshes
      produced will be closed.
    """
    del self._mesher

    if not data.flags.c_contiguous and not data.flags.f_contiguous:
      data = np.ascontiguousarray(data)

    if close:
      tmp = np.zeros(np.array(data.shape) + 2, dtype=data.dtype, order="C")
      tmp[1:-1,1:-1,1:-1] = data
      data = tmp
      del tmp

    shape = np.array(data.shape)
    nbytes = np.dtype(data.dtype).itemsize

    # z is allocated 10 position bits, y 11, and x 11 bits.
    # The last bit is 2^-1 (fixed point) so divide by two to
    # get the maximum supported shape. 
    if shape[0] > 1023 or shape[1] > 1023 or shape[2] > 511:
      MesherClass = Mesher6464
      if nbytes == 4:
        MesherClass = Mesher6432
      elif nbytes == 2:
        MesherClass = Mesher6416
      elif nbytes == 1:
        MesherClass = Mesher6408
    else:
      MesherClass = Mesher3264
      if nbytes == 4:
        MesherClass = Mesher3232
      elif nbytes == 2:
        MesherClass = Mesher3216
      elif nbytes == 1:
        MesherClass = Mesher3208

    self._mesher = MesherClass(self.voxel_res)

    return self._mesher.mesh(data)

  @cython.binding(True)
  def ids(self):
    return self._mesher.ids()

  @cython.binding(True)
  def get_mesh(
    self, mesh_id, normals=False, 
    simplification_factor=0, max_simplification_error=40,
    voxel_centered=False
  ):
    """
    NOTE: This function is deprecated. Please use "get" as 
    this function transposes the mesh.

    mesh_id: the integer id of the mesh
    normals: whether to calculate vertex normals for the mesh
    simplification_factor: Try to reduce the number of triangles by this factor.
    max_simplification_error: maximum distance vertices are allowed to deviate from
      their original position. Units are physical, not voxels.
    voxel_centered: By default, the meshes produced will be centered at 0,0,0.
      If enabled, the meshes will be centered in the voxel at 0.5,0.5,0.5.

    Returns: Mesh
    """
    mesh = self._mesher.get_mesh(
      mesh_id, False, 
      simplification_factor, max_simplification_error, 
      transpose=True
    )

    if normals:
      mesh = compute_normals(mesh)

    mesh.id = int(mesh_id)

    return _normalize_mesh(mesh, voxel_centered, physical=True, resolution=self.voxel_res)

  @cython.binding(True)
  def get(
    self, label, 
    normals = False, 
    reduction_factor = 0, 
    max_error = None,
    voxel_centered = False
  ):
    """
    label: the integer id of the mesh
    normals: whether to calculate vertex normals for the mesh
    reduction_factor: Try to reduce the number of triangles by this integer factor. 
      0 disables simplification.
    max_error: maximum distance vertices are allowed to deviate from
      their original position. Units are physical, not voxels. If None, automatically
      is set to at most one voxel distortion based on the provided resolution.
    voxel_centered: By default, the meshes produced will be centered at 0,0,0.
      If enabled, the meshes will be centered in the voxel at 0.5,0.5,0.5.

    Returns: Mesh
    """
    # automatically select one voxel max distortion
    if max_error is None:
      max_error = self.voxel_res.max()

    mesh = self._mesher.get_mesh(
      label, False, 
      reduction_factor, max_error,
      transpose=False
    )

    if normals:
      mesh = compute_normals(mesh)

    mesh = _normalize_mesh(mesh, voxel_centered, physical=True, resolution=self.voxel_res)
    mesh.id = int(label)
    return mesh

  @cython.binding(True)
  def compute_normals(self, mesh:Mesh) -> Mesh:
    """
    Returns: Mesh with normals computed
    """
    return compute_normals(mesh)

  # adding this causes a cython compilation error as of 3.0.10
  # @cython.binding(True)
  def simplify(
    self, mesh, 
    int reduction_factor = 0, 
    float max_error = 40, 
    compute_normals = False,
    voxel_centered = False, 
    float min_error = -1,
  ):
    """
    Mesh simplify(
      mesh, reduction_factor=0, 
      max_error=40, compute_normals=False, 
      voxel_centered=False, min_error = -1
    )

    Given a mesh object (either zmesh.Mesh or another object that has
    mesh.vertices and mesh.faces implemented as numpy arrays), apply
    the quadratic edge collapse algorithm. 

    Note: the maximum range spread between vertex values (in x, y, or z)
    is 2^20. The simplifier cannot represent values outside that range.

    Optional:
      reduction_factor: Triangle reduction factor target. If all vertices
        are maxxed out in terms of their error tolerance the algorithm will
        stop short of this target.
      max_error: The maximum allowed displacement of a vertex in physical
        distance.
      min_error: Continue simplifying until this error target is met OR secondarily 
        the target number of triangles is met. Set this to 0 to force the 
        reduction_factor to take precedence. -1 indicates that the c++ default
        value should be used.

        The c++ default value is std::numeric_limits<Float>::epsilon() * 25

      compute_normals: whether or not to also compute the vertex normals
      voxel_centered: By default, the meshes produced will be centered at 
        0,0,0. If enabled, the meshes will be centered in the voxel at 
        0.5,0.5,0.5.

    Returns: Mesh
    """
    if mesh.empty():
      return Mesh()

    mesher = new CMesher[uint64_t, uint64_t, float]((1,1,1))

    cdef size_t ti = 0
    cdef size_t vi = 0
    cdef uint64_t vert = 0

    cdef cnp.ndarray[float, ndim=3] triangles = mesh.vertices[mesh.faces]
    cdef cnp.ndarray[uint64_t, ndim=2] packed_triangles = np.zeros( 
      (triangles.shape[0], 3), dtype=np.uint64, order='C'
    ) 

    max_error //= np.sqrt(np.sum(self.voxel_res ** 2))

    triangles /= self.voxel_res
    triangles *= 2.0
    cdef float min_vertex = np.min(triangles)
    if min_vertex != 0:
      triangles -= min_vertex

    # uint64 // 3 = 21 bits - 1 bit for representing half voxels
    if np.max(triangles) > 2**20:
      raise ValueError(
        "Vertex positions larger than simplifier representation limit (2^20). "
        f"Did you set the resolution correctly? voxel res: {self.voxel_res}"
      )

    cdef size_t Nv = triangles.shape[0]

    for ti in range(Nv):
      for vi in range(3):
        packed_triangles[ti, vi] = mesher.pack_coords(
          <uint64_t>triangles[ti, vi, 0], <uint64_t>triangles[ti, vi, 1], <uint64_t>triangles[ti, vi, 2]
        )
    del triangles

    cdef MeshObject result = mesher.simplify_points(
      <uint64_t*>&packed_triangles[0,0], Nv, 
      <bool>compute_normals, reduction_factor, 
      max_error, min_error
    )
    del mesher

    simplified_mesh = cpp_meshobj_to_mesh(result)

    if min_vertex != 0:
      simplified_mesh.vertices += min_vertex

    if hasattr(mesh, 'id'):
      simplified_mesh.id = mesh.id

    return _normalize_mesh(simplified_mesh, voxel_centered, physical=False, resolution=self.voxel_res)
  
  def clear(self):
    self._mesher.clear()
  
  @cython.binding(True) 
  def erase(self, segid):
    return self._mesher.erase(segid)

def reshape(arr, shape, order=None):
  """
  If the array is contiguous, attempt an in place reshape
  rather than potentially making a copy.

  Required:
    arr: The input numpy array.
    shape: The desired shape (must be the same size as arr)

  Optional: 
    order: 'C', 'F', or None (determine automatically)

  Returns: reshaped array
  """
  if order is None:
    if arr.flags['F_CONTIGUOUS']:
      order = 'F'
    elif arr.flags['C_CONTIGUOUS']:
      order = 'C'
    else:
      return arr.reshape(shape)

  cdef int nbytes = np.dtype(arr.dtype).itemsize

  if order == 'C':
    strides = [ reduce(operator.mul, shape[i:]) * nbytes for i in range(1, len(shape)) ]
    strides += [ nbytes ]
    return np.lib.stride_tricks.as_strided(arr, shape=shape, strides=strides)
  else:
    strides = [ reduce(operator.mul, shape[:i]) * nbytes for i in range(1, len(shape)) ]
    strides = [ nbytes ] + strides
    return np.lib.stride_tricks.as_strided(arr, shape=shape, strides=strides)


# NOTE: THE USER INTERFACE CLASS IS "Mesher" ABOVE

# The following wrapper classes are generated from a template!!

# The pattern is: Mesher[PositionType bits][LabelType bits]
# 64 bit position type can represent very large arrays
# 32 bit can represent 1023 x 1023 x 511 arrays
cdef class Mesher3208:
  cdef CMesher[uint32_t, uint8_t, float] *ptr      # hold a C++ instance which we're wrapping

  def __cinit__(self, voxel_res):
    self.ptr = new CMesher[uint32_t, uint8_t, float](voxel_res)

  def __dealloc__(self):
    del self.ptr

  def mesh(self, data):
    cdef cnp.ndarray[uint8_t, ndim=1] flat_data = reshape(data, (data.size,)).view(np.uint8)
    self.ptr.mesh(
      &flat_data[0],
      data.shape[0], data.shape[1], data.shape[2],
      data.flags.c_contiguous
    )

  def ids(self):
    return self.ptr.ids()
  
  def get_mesh(self, mesh_id, normals=False, simplification_factor=0, max_simplification_error=40, min_simplification_error=(25 * sys.float_info.epsilon), transpose=True):
    cdef MeshObject meshobj = self.ptr.get_mesh(mesh_id, normals, simplification_factor, max_simplification_error, min_simplification_error, transpose)
    return cpp_meshobj_to_mesh(meshobj)
  
  def clear(self):
    self.ptr.clear()

  def erase(self, mesh_id):
    return self.ptr.erase(mesh_id)

cdef class Mesher3216:
  cdef CMesher[uint32_t, uint16_t, float] *ptr      # hold a C++ instance which we're wrapping

  def __cinit__(self, voxel_res):
    self.ptr = new CMesher[uint32_t, uint16_t, float](voxel_res)

  def __dealloc__(self):
    del self.ptr

  def mesh(self, data):
    cdef cnp.ndarray[uint16_t, ndim=1] flat_data = reshape(data, (data.size,)).view(np.uint16)
    self.ptr.mesh(
      &flat_data[0],
      data.shape[0], data.shape[1], data.shape[2],
      data.flags.c_contiguous
    )

  def ids(self):
    return self.ptr.ids()
  
  def get_mesh(self, mesh_id, normals=False, simplification_factor=0, max_simplification_error=40, min_simplification_error=(25 * sys.float_info.epsilon), transpose=True):
    cdef MeshObject meshobj = self.ptr.get_mesh(mesh_id, normals, simplification_factor, max_simplification_error, min_simplification_error, transpose)
    return cpp_meshobj_to_mesh(meshobj)
  
  def clear(self):
    self.ptr.clear()

  def erase(self, mesh_id):
    return self.ptr.erase(mesh_id)

cdef class Mesher3232:
  cdef CMesher[uint32_t, uint32_t, float] *ptr      # hold a C++ instance which we're wrapping

  def __cinit__(self, voxel_res):
    self.ptr = new CMesher[uint32_t, uint32_t, float](voxel_res)

  def __dealloc__(self):
    del self.ptr

  def mesh(self, data):
    cdef cnp.ndarray[uint32_t, ndim=1] flat_data = reshape(data, (data.size,)).view(np.uint32)
    self.ptr.mesh(
      &flat_data[0],
      data.shape[0], data.shape[1], data.shape[2],
      data.flags.c_contiguous
    )

  def ids(self):
    return self.ptr.ids()
  
  def get_mesh(self, mesh_id, normals=False, simplification_factor=0, max_simplification_error=40, min_simplification_error=(25 * sys.float_info.epsilon), transpose=True):
    cdef MeshObject meshobj = self.ptr.get_mesh(mesh_id, normals, simplification_factor, max_simplification_error, min_simplification_error, transpose)
    return cpp_meshobj_to_mesh(meshobj)
  
  def clear(self):
    self.ptr.clear()

  def erase(self, mesh_id):
    return self.ptr.erase(mesh_id)

cdef class Mesher3264:
  cdef CMesher[uint32_t, uint64_t, float] *ptr      # hold a C++ instance which we're wrapping

  def __cinit__(self, voxel_res):
    self.ptr = new CMesher[uint32_t, uint64_t, float](voxel_res)

  def __dealloc__(self):
    del self.ptr

  def mesh(self, data):
    cdef cnp.ndarray[uint64_t, ndim=1] flat_data = reshape(data, (data.size,)).view(np.uint64)
    self.ptr.mesh(
      &flat_data[0],
      data.shape[0], data.shape[1], data.shape[2],
      data.flags.c_contiguous
    )

  def ids(self):
    return self.ptr.ids()
  
  def get_mesh(self, mesh_id, normals=False, simplification_factor=0, max_simplification_error=40, min_simplification_error=(25 * sys.float_info.epsilon), transpose=True):
    cdef MeshObject meshobj = self.ptr.get_mesh(mesh_id, normals, simplification_factor, max_simplification_error, min_simplification_error, transpose)
    return cpp_meshobj_to_mesh(meshobj)
  
  def clear(self):
    self.ptr.clear()

  def erase(self, mesh_id):
    return self.ptr.erase(mesh_id)

cdef class Mesher6408:
  cdef CMesher[uint64_t, uint8_t, float] *ptr      # hold a C++ instance which we're wrapping

  def __cinit__(self, voxel_res):
    self.ptr = new CMesher[uint64_t, uint8_t, float](voxel_res)

  def __dealloc__(self):
    del self.ptr

  def mesh(self, data):
    cdef cnp.ndarray[uint8_t, ndim=1] flat_data = reshape(data, (data.size,)).view(np.uint8)
    self.ptr.mesh(
      &flat_data[0],
      data.shape[0], data.shape[1], data.shape[2],
      data.flags.c_contiguous
    )

  def ids(self):
    return self.ptr.ids()
  
  def get_mesh(self, mesh_id, normals=False, simplification_factor=0, max_simplification_error=40, min_simplification_error=(25 * sys.float_info.epsilon), transpose=True):
    cdef MeshObject meshobj = self.ptr.get_mesh(mesh_id, normals, simplification_factor, max_simplification_error, min_simplification_error, transpose)
    return cpp_meshobj_to_mesh(meshobj)
  
  def clear(self):
    self.ptr.clear()

  def erase(self, mesh_id):
    return self.ptr.erase(mesh_id)

cdef class Mesher6416:
  cdef CMesher[uint64_t, uint16_t, float] *ptr      # hold a C++ instance which we're wrapping

  def __cinit__(self, voxel_res):
    self.ptr = new CMesher[uint64_t, uint16_t, float](voxel_res)

  def __dealloc__(self):
    del self.ptr

  def mesh(self, data):
    cdef cnp.ndarray[uint16_t, ndim=1] flat_data = reshape(data, (data.size,)).view(np.uint16)
    self.ptr.mesh(
      &flat_data[0],
      data.shape[0], data.shape[1], data.shape[2],
      data.flags.c_contiguous
    )

  def ids(self):
    return self.ptr.ids()
  
  def get_mesh(self, mesh_id, normals=False, simplification_factor=0, max_simplification_error=40, min_simplification_error=(25 * sys.float_info.epsilon), transpose=True):
    cdef MeshObject meshobj = self.ptr.get_mesh(mesh_id, normals, simplification_factor, max_simplification_error, min_simplification_error, transpose)
    return cpp_meshobj_to_mesh(meshobj)
  
  def clear(self):
    self.ptr.clear()

  def erase(self, mesh_id):
    return self.ptr.erase(mesh_id)

cdef class Mesher6432:
  cdef CMesher[uint64_t, uint32_t, float] *ptr      # hold a C++ instance which we're wrapping

  def __cinit__(self, voxel_res):
    self.ptr = new CMesher[uint64_t, uint32_t, float](voxel_res)

  def __dealloc__(self):
    del self.ptr

  def mesh(self, data):
    cdef cnp.ndarray[uint32_t, ndim=1] flat_data = reshape(data, (data.size,)).view(np.uint32)
    self.ptr.mesh(
      &flat_data[0],
      data.shape[0], data.shape[1], data.shape[2],
      data.flags.c_contiguous
    )

  def ids(self):
    return self.ptr.ids()
  
  def get_mesh(self, mesh_id, normals=False, simplification_factor=0, max_simplification_error=40, min_simplification_error=(25 * sys.float_info.epsilon), transpose=True):
    cdef MeshObject meshobj = self.ptr.get_mesh(mesh_id, normals, simplification_factor, max_simplification_error, min_simplification_error, transpose)
    return cpp_meshobj_to_mesh(meshobj)
  
  def clear(self):
    self.ptr.clear()

  def erase(self, mesh_id):
    return self.ptr.erase(mesh_id)

cdef class Mesher6464:
  cdef CMesher[uint64_t, uint64_t, float] *ptr      # hold a C++ instance which we're wrapping

  def __cinit__(self, voxel_res):
    self.ptr = new CMesher[uint64_t, uint64_t, float](voxel_res)

  def __dealloc__(self):
    del self.ptr

  def mesh(self, data):
    cdef cnp.ndarray[uint64_t, ndim=1] flat_data = reshape(data, (data.size,)).view(np.uint64)
    self.ptr.mesh(
      &flat_data[0],
      data.shape[0], data.shape[1], data.shape[2],
      data.flags.c_contiguous
    )

  def ids(self):
    return self.ptr.ids()
  
  def get_mesh(self, mesh_id, normals=False, simplification_factor=0, max_simplification_error=40, min_simplification_error=(25 * sys.float_info.epsilon), transpose=True):
    cdef MeshObject meshobj = self.ptr.get_mesh(mesh_id, normals, simplification_factor, max_simplification_error, min_simplification_error, transpose)
    return cpp_meshobj_to_mesh(meshobj)
  
  def clear(self):
    self.ptr.clear()

  def erase(self, mesh_id):
    return self.ptr.erase(mesh_id)

