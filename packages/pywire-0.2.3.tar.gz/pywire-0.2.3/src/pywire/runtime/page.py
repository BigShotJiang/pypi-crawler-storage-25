"""Base page class with lifecycle system."""

import inspect
import asyncio
from collections import defaultdict
from .events import create_event_data
from typing import (
    TYPE_CHECKING,
    Any,
    Awaitable,
    Callable,
    ClassVar,
    Dict,
    List,
    Optional,
    Set,
    Tuple,
    Union,
)
import logging

from starlette.requests import Request
from starlette.responses import Response

if TYPE_CHECKING:
    from pywire.runtime.router import URLHelper

from pywire.runtime.style_collector import StyleCollector

logger = logging.getLogger(__name__)


class DotDict(dict):
    """Dict that allows dot-access to keys. Returns None for missing keys."""

    def __getattr__(self, name: str) -> Any:
        try:
            return self[name]
        except KeyError:
            return None

    def __setattr__(self, name: str, value: Any) -> None:
        self[name] = value


# EventData moved to .events


class BasePage:
    """Base class for all compiled pages."""

    # Layout ID (overridden by generator)
    LAYOUT_ID: Optional[str] = None
    __file_path__: ClassVar[str]
    _FRAMEWORK_PROP_KEYS: ClassVar[Set[str]] = {
        "request",
        "params",
        "query",
        "path",
        "url",
        "slots",
        "__is_component__",
        "_style_collector",
        "_context",
        "_parent_page",
        "_component_key",
    }

    # Lifecycle hooks registry (extensible!)
    INIT_HOOKS = [
        "on_before_load",
        "on_load",
    ]

    RENDER_HOOKS = [
        "on_after_render",
    ]

    # Legacy support / full list
    LIFECYCLE_HOOKS = INIT_HOOKS + RENDER_HOOKS

    def __init__(
        self,
        request: Request,
        params: Dict[str, str],
        query: Dict[str, str],
        path: Optional[Dict[str, bool]] = None,
        url: Optional["URLHelper"] = None,
        **kwargs: Any,
    ) -> None:
        self.request = request
        self.params = DotDict(params or {})  # URL params from route
        self.query = DotDict(query or {})  # Query string params
        self.path = DotDict(path or {})
        self.url = url

        # Style collector management
        # If passed from parent component (via kwargs), reuse it.
        # Otherwise create new one (root page).
        if "_style_collector" in kwargs:
            self._style_collector: StyleCollector = kwargs.pop("_style_collector")
        else:
            self._style_collector = StyleCollector()

        # Context inheritance for !provide/!inject
        # If passed from parent component, make a shallow copy for child-specific shadowing.
        # Otherwise create a new empty context (root page).
        if "_context" in kwargs:
            self.context = kwargs.pop("_context").copy()
        else:
            self.context = {}
        self.context: Dict[str, Any]

        self.user: Any = None  # Set by middleware

        # Expose params as attributes for easy access in templates
        for k, v in self.params.items():
            setattr(self, k, v)

        # Ensure path is exhaustive if __routes__ is present
        routes = getattr(self.__class__, "__routes__", {})
        if routes:
            for name in routes:
                if name not in self.path:
                    self.path[name] = False
        elif hasattr(self.__class__, "__route__") and "main" not in self.path:
            self.path["main"] = self.path.get("main", False)

        # Framework-managed state
        self.errors: Dict[str, Any] = {}
        self.loading: Dict[str, bool] = {}

        # Slot registry: layout_id -> slot_name -> renderer (replacement semantics)
        self.slots: Dict[str, Dict[str, Union[Callable, str]]] = defaultdict(dict)

        # Populate slots from kwargs (for components)
        if "slots" in kwargs and self.LAYOUT_ID:
            self.slots[self.LAYOUT_ID].update(kwargs["slots"])

        # Component flag (internal)
        self.__is_component__ = kwargs.pop("__is_component__", False)
        self._parent_page: Optional["BasePage"] = kwargs.pop("_parent_page", None)
        self._component_key: Optional[str] = kwargs.pop("_component_key", None)
        self._handler_prefix: str = ""
        if self.__is_component__ and self._parent_page and self._component_key:
            self._handler_prefix = (
                f"{self._parent_page._handler_prefix}_comp:{self._component_key}:"
            )

        # Store remaining kwargs as fallthrough attributes
        self.attrs = {k: v for k, v in kwargs.items() if k != "slots"}

        # Head slot registry: layout_id -> list of renderers (append semantics, top-down order)
        self.head_slots: Dict[str, List[Callable]] = defaultdict(list)

        # Async update hook for intermediate state (injected by runtime)
        self._on_update: Optional[Callable[[], Awaitable[None]]] = None
        self._wire_subscribers: Dict[Tuple[Any, str], Set[str]] = defaultdict(set)
        self._region_dependencies: Dict[str, Set[Tuple[Any, str]]] = defaultdict(set)
        self._dirty_regions: Set[str] = set()

        # Error state for error pages
        self.error_code: Optional[int] = None
        self.error_detail: Optional[str] = None
        self.error_trace: Optional[str] = None

        # Partial update static cache
        self._static_cache: Dict[str, Any] = {}
        self._expr_counts: Dict[str, int] = defaultdict(int)
        self._capturing_deps: bool = False
        self._captured_deps: Set[Tuple[Any, str]] = set()

        self._instance_id = id(self)
        logger.debug(f"[{self._instance_id}] BasePage initialized")

        # Await block state: await_id -> {"status": "pending"|"success"|"error", "result": Any, "error": Any}

        # Await block state: await_id -> {"status": "pending"|"success"|"error", "result": Any, "error": Any}
        self._await_states: Dict[str, Dict[str, Any]] = {}
        self._background_tasks: Set["asyncio.Task[Any]"] = set()

        # Component ref support
        self._ref: Optional[Any] = None  # wire passed via $ref={my_ref}
        self._refs_by_id: Dict[str, Any] = {}  # registry for ref instances
        self._exposed_methods: Set[str] = getattr(self, "__exposed_methods__", set())
        self._pending_navigation: Optional[str] = None
        self._components: Dict[str, "BasePage"] = {}
        self._active_component_keys: Set[str] = set()
        self._component_state_snapshots: Dict[str, Dict[str, Any]] = {}

    @property
    def navigate(self) -> Callable[[str], None]:
        """Return a callable that sets the pending navigation path."""

        def _navigate(path: str) -> None:
            self._pending_navigation = path

        return _navigate

    def _is_debug(self) -> bool:
        try:
            return getattr(self.request.app.state, "debug", False)
        except Exception:
            return False

    @classmethod
    def _is_framework_prop_key(cls, key: str) -> bool:
        return key in cls._FRAMEWORK_PROP_KEYS

    def _update_props(self, new_kwargs: Dict[str, Any]) -> None:
        if "request" in new_kwargs:
            self.request = new_kwargs["request"]
        if "params" in new_kwargs:
            self.params = DotDict(new_kwargs["params"] or {})
        if "query" in new_kwargs:
            self.query = DotDict(new_kwargs["query"] or {})
        if "path" in new_kwargs:
            self.path = DotDict(new_kwargs["path"] or {})
        if "url" in new_kwargs:
            self.url = new_kwargs["url"]
        if "_style_collector" in new_kwargs:
            self._style_collector = new_kwargs["_style_collector"]
        if "_context" in new_kwargs:
            self.context = new_kwargs["_context"].copy()

        fallback_attrs: Dict[str, Any] = {}
        for key, value in new_kwargs.items():
            if self._is_framework_prop_key(key):
                continue

            # Prop reconciliation:
            # - existing attributes on the component instance are treated as props/state
            # - unknown keys are fallthrough HTML attrs
            if hasattr(self, key):
                setattr(self, key, value)
                continue
            fallback_attrs[key] = value

        if "slots" in new_kwargs and self.LAYOUT_ID:
            self.slots[self.LAYOUT_ID].update(new_kwargs["slots"])

        self.attrs = fallback_attrs

    def _resolve_component(
        self, key: str, cls: type["BasePage"], **kwargs: Any
    ) -> "BasePage":
        self._active_component_keys.add(key)

        component = self._components.get(key)
        if component is not None and isinstance(component, cls):
            component._update_props(kwargs)
            return component

        kwargs["_parent_page"] = self
        kwargs["_component_key"] = key
        instance = cls(**kwargs)

        snapshot = self._component_state_snapshots.pop(key, None)
        if snapshot:
            for attr, value in snapshot.items():
                try:
                    setattr(instance, attr, value)
                except AttributeError:
                    continue

        self._components[key] = instance
        return instance

    def _collect_all_commands(self) -> List[Dict[str, Any]]:
        """Collect commands from all internal refs and recursive child components."""
        commands = []
        # 1. Collect from own refs
        for rid, r in self._refs_by_id.items():
            cmds = r._collect_commands()
            if cmds:
                commands.extend(cmds)

        # 2. Collect from all child components
        for key, comp in self._components.items():
            cmds = comp._collect_all_commands()
            if cmds:
                commands.extend(cmds)
        return commands

    def _cleanup_components(self) -> None:
        stale_keys = [
            key
            for key in self._components.keys()
            if key not in self._active_component_keys
        ]
        for key in stale_keys:
            self._components.pop(key, None)
        self._active_component_keys.clear()

    def _sync_ref_data(self, event_data: Dict[str, Any]) -> None:
        ref_id = event_data.get("refId")
        if not ref_id:
            return

        ref_obj = self._refs_by_id.get(ref_id)
        if ref_obj is None:
            return

        if "formData" in event_data:
            ref_obj._update_data(event_data["formData"])
        if "value" in event_data:
            ref_obj._update_value(event_data["value"])
        if "rect" in event_data:
            ref_obj._update_rect(event_data["rect"])

    @staticmethod
    def _parse_component_event(event_name: str) -> Optional[Tuple[str, str]]:
        if not event_name.startswith("_comp:"):
            return None

        payload = event_name[len("_comp:") :]
        comp_key, sep, remainder = payload.partition(":")
        if not sep or not comp_key or not remainder:
            raise ValueError(f"Malformed component event '{event_name}'")
        return comp_key, remainder

    async def _dispatch_handler(
        self, event_name: str, event_data: Dict[str, Any]
    ) -> None:
        self._sync_ref_data(event_data)

        # Framework-generated handlers are always allowed (form wrappers, bindings)
        is_framework_handler = event_name.startswith(
            "_handle_bind_"
        ) or event_name.startswith("_handler_")
        if not is_framework_handler and event_name.startswith("_"):
            raise ValueError(f"Handler '{event_name}' not allowed")

        handler = getattr(self, event_name, None)
        if not handler:
            raise ValueError(f"Handler {event_name} not found")

        if event_name.startswith("_handle_bind_"):
            if inspect.iscoroutinefunction(handler):
                await handler(event_data)
            else:
                handler(event_data)
            return

        args = event_data.get("args", {})
        normalized_args = {}
        for key, value in args.items():
            if key.startswith("arg"):
                normalized_args[key.replace("-", "")] = value
                continue
            normalized_args[key] = value

        call_kwargs = {k: v for k, v in event_data.items() if k != "args"}
        call_kwargs.update(normalized_args)

        sig = inspect.signature(handler)
        bound_kwargs = {}

        has_var_kw = False
        for param in sig.parameters.values():
            if param.kind == inspect.Parameter.VAR_KEYWORD:
                has_var_kw = True
                break

        if has_var_kw:
            bound_kwargs = call_kwargs
        else:
            for name in sig.parameters:
                if name == "event_data" or name == "event":
                    bound_kwargs[name] = create_event_data(call_kwargs)
                    continue
                if name in call_kwargs:
                    bound_kwargs[name] = call_kwargs[name]

        from pywire.shell import _request_ctx

        token = _request_ctx.set(self.request)
        try:
            if inspect.iscoroutinefunction(handler):
                await handler(**bound_kwargs)
            else:
                handler(**bound_kwargs)
        finally:
            _request_ctx.reset(token)

    async def _handle_component_event(
        self, event_name: str, event_data: Dict[str, Any]
    ) -> None:
        parsed = self._parse_component_event(event_name)
        if parsed:
            comp_key, remainder = parsed
            component = self._components.get(comp_key)
            if component is None:
                raise ValueError(f"Component '{comp_key}' not found")
            await component._handle_component_event(remainder, event_data)
            return

        await self._dispatch_handler(event_name, event_data)

    def register_slot(
        self, layout_id: str, slot_name: str, renderer: Callable[..., Any]
    ) -> None:
        """Register a content renderer for a slot in a specific layout."""
        self.slots[layout_id][slot_name] = renderer

    def register_head_slot(self, layout_id: str, renderer: Callable[..., Any]) -> None:
        """Register head content to be appended (top-down order)."""
        # Prevent duplicate registration (can happen with super()._init_slots() chaining)
        if renderer not in self.head_slots[layout_id]:
            self.head_slots[layout_id].append(renderer)

    async def render_slot(
        self,
        slot_name: str,
        default_renderer: Optional[Callable[..., Any]] = None,
        layout_id: Optional[str] = None,
        append: bool = False,
    ) -> str:
        """Render a slot for the current layout."""
        target_id = layout_id or self.LAYOUT_ID

        # Handle $head slots with append semantics
        if append:
            parts = []
            # Render default content first (from the layout itself)
            if default_renderer:
                if inspect.iscoroutinefunction(default_renderer):
                    parts.append(await default_renderer())
                else:
                    parts.append(default_renderer())

            # Collect head content from ALL layout IDs in the inheritance chain
            for layout_id_key in self.head_slots:
                for head_renderer in self.head_slots[layout_id_key]:
                    if inspect.iscoroutinefunction(head_renderer):
                        parts.append(await head_renderer())
                    else:
                        parts.append(head_renderer())
            return "".join(parts)

        # Normal replacement semantics
        if target_id and slot_name in self.slots[target_id]:
            renderer: Union[Callable[..., Any], str] = self.slots[target_id][slot_name]
            if callable(renderer):
                if inspect.iscoroutinefunction(renderer):
                    return str(await renderer())
                return str(renderer())  # ty: ignore[call-top-callable]
            return str(renderer)

        # Fallback to default content if provided
        if default_renderer:
            if inspect.iscoroutinefunction(default_renderer):
                return str(await default_renderer())
            return str(default_renderer())

        return ""

    async def render(self, init: bool = True) -> Response:
        """Main render method - calls lifecycle hooks."""

        # Cleanup background tasks on new full load
        if init:
            for task in self._background_tasks:
                if not task.done():
                    task.cancel()
            self._background_tasks.clear()
            self._await_states.clear()

        # Run init hooks only if requested (new page load)
        if init:
            for hook_name in self.INIT_HOOKS:
                if hasattr(self, hook_name):
                    hook = getattr(self, hook_name)
                    if inspect.iscoroutinefunction(hook):
                        await hook()
                    else:
                        hook()

        # Render template (may be async for layouts with render_slot calls)
        # Render HTML
        # Render template (may be async for layouts with render_slot calls)
        # Render HTML
        self._clear_wire_tracking()
        self._expr_counts.clear()

        # Initial render: we populate the cache
        # Future renders: we use the cache
        # The cache is persistent across renders

        from pywire.core.wire import set_render_context, reset_render_context

        token = set_render_context(self, None)
        try:
            self._active_component_keys.clear()
            html = await self._render_template()
            self._cleanup_components()
        finally:
            reset_render_context(token)

        # If this is an update (init=False), strip the surrounding <html>/<body> tags
        # and return only the inner content. This prevents nested HTML on the client.
        if not init:
            import re

            # Try to match body content
            body_match = re.search(
                r"<body[^>]*>(.*)</body>", html, re.IGNORECASE | re.DOTALL
            )
            if body_match:
                html = body_match.group(1)
            else:
                # Fallback: if no body tag found, maybe it's already a fragment?
                # But if it has <html, strip it?
                # For safety, let's look for html tags and warn/strip if we can't find body
                pass

        # Inject styles if this is the root render (not a component or partial update)
        styles = self._style_collector.render()
        if styles:
            if "</head>" in html:
                parts = html.rsplit("</head>", 1)
                html = parts[0] + f"{styles}</head>" + parts[1]
            else:
                html = f"{styles}{html}"

        # Inject PyWire client and SPA metadata only on initial page load (init=True)
        # Components and WebSocket updates (init=False) should NOT include these scripts,
        # otherwise they trigger redundant re-initialization and loops.
        if init:
            no_spa = getattr(self, "__no_spa__", False)
            is_component = getattr(self, "__is_component__", False)

            # Check if SPA features are enabled via attribute or app state
            pjax_enabled = False
            debug_mode = False
            try:
                pjax_enabled = bool(
                    getattr(self.request.app.state, "enable_pjax", False)
                )
                debug_mode = bool(getattr(self.request.app.state, "debug", False))
            except (AttributeError, KeyError):
                pass

            if not no_spa and not is_component:
                meta = {
                    "sibling_paths": getattr(self, "__sibling_paths__", []),
                    "enable_pjax": pjax_enabled,
                    "debug": debug_mode,
                }
                import json

                meta_json = json.dumps(meta)
                meta_script = f'<script id="_pywire_spa_meta" type="application/json">{meta_json}</script>'

                # Determine client script URL
                script_url = "/_pywire/static/pywire.core.min.js"
                try:
                    pywire_app = self.request.app.state.pywire
                    script_url = pywire_app._get_client_script_url()
                except (AttributeError, KeyError):
                    # Fallback to dev if we can't detect, or keep core default
                    pass

                client_script = f'<script src="{script_url}"></script>'
                injection = f"{meta_script}{client_script}"

                if "</body>" in html:
                    parts = html.rsplit("</body>", 1)
                    html = parts[0] + f"{injection}</body>" + parts[1]
                else:
                    html += injection

        # Run post-render hooks (always run on render)
        for hook_name in self.RENDER_HOOKS:
            if hasattr(self, hook_name):
                hook = getattr(self, hook_name)
                if inspect.iscoroutinefunction(hook):
                    await hook()
                else:
                    hook()

        return Response(html, media_type="text/html")

    def _clear_wire_tracking(self) -> None:
        self._wire_subscribers.clear()
        self._region_dependencies.clear()
        self._dirty_regions.clear()

    def _begin_region_render(self, region_id: str) -> None:
        deps = self._region_dependencies.get(region_id)
        if deps:
            for dep in deps:
                regions = self._wire_subscribers.get(dep)
                if regions and region_id in regions:
                    regions.discard(region_id)
                    if not regions:
                        self._wire_subscribers.pop(dep, None)
                    if regions and region_id in regions:
                        regions.discard(region_id)
                        if not regions:
                            self._wire_subscribers.pop(dep, None)
        self._region_dependencies[region_id] = set()

    def _render_expr(self, static_id: str, compute_func: Callable[[], Any]) -> Any:
        # Generate instance ID based on execution count
        count = self._expr_counts[static_id]
        self._expr_counts[static_id] += 1
        instance_id = f"{static_id}:{count}"

        # If cached, return it
        if instance_id in self._static_cache:
            return self._static_cache[instance_id]

        # Otherwise compute and potentially cache
        # We need to capture dependencies to know if it's static
        prev_capturing = self._capturing_deps
        prev_captured = self._captured_deps

        self._capturing_deps = True
        self._captured_deps = set()

        try:
            result = compute_func()
        finally:
            deps = self._captured_deps
            self._capturing_deps = prev_capturing
            self._captured_deps = prev_captured

        # If no wire dependencies, cache it
        if not deps:
            self._static_cache[instance_id] = result

        return result

    def _register_wire_read(self, wire_obj: Any, field: str, region_id: str) -> None:
        key = (wire_obj, field)
        self._wire_subscribers[key].add(region_id)
        self._region_dependencies[region_id].add(key)

        logger.debug(
            f"register_read: page={id(self)} wire={id(wire_obj)} field={field} region={region_id}"
        )

        if self._capturing_deps:
            self._captured_deps.add(key)

    def _invalidate_wire(self, wire_obj: Any, field: str) -> None:
        regions = set()
        key = (wire_obj, field)
        if key in self._wire_subscribers:
            regions |= self._wire_subscribers[key]

        print(
            f"INVALIDATE: page={id(self)} wire={id(wire_obj)} key={key} affected_regions={regions}",
            flush=True,
        )

        if regions:
            self._dirty_regions.update(regions)

    async def handle_event(
        self, event_name: str, event_data: dict[str, Any]
    ) -> Dict[str, Any]:
        """Handle client event (from @click, etc.)."""
        parsed = self._parse_component_event(event_name)
        if parsed:
            comp_key, remainder = parsed
            component = self._components.get(comp_key)
            if component is None:
                raise ValueError(f"Component '{comp_key}' not found")
            await component._handle_component_event(remainder, event_data)
        else:
            await self._dispatch_handler(event_name, event_data)

        # Re-render without re-initializing
        from pywire.shell import _request_ctx

        token = _request_ctx.set(self.request)
        try:
            return await self.render_update(init=False)
        finally:
            _request_ctx.reset(token)

    async def render_update(self, init: bool = False) -> Dict[str, Any]:
        # Optimization: If we have region renderers (compiled page) and this is a partial update (init=False),
        # check if we really need to update anything.
        if hasattr(self, "__region_renderers__") and (self._dirty_regions or not init):
            # If no dirty regions (and init=False), return empty update
            if not self._dirty_regions:
                result: Dict[str, Any] = {"type": "regions", "regions": []}
                commands = self._collect_all_commands()
                if commands:
                    result["commands"] = commands
                return result

            logger.debug(f"render_update: dirty_regions={self._dirty_regions}")

            # Check for Root invalidation (None in dirty set)
            # If the root scope is dirty, we must do a full render.
            has_root_dirty = None in self._dirty_regions

            if not has_root_dirty:
                self._expr_counts.clear()

                from pywire.core.wire import set_render_context, reset_render_context

                updates = []
                region_map = getattr(self, "__region_renderers__", {}) or {}

                # Safe to sort now as we know no None is present
                for region_id in sorted(self._dirty_regions):
                    method_name = region_map.get(region_id)
                    if not method_name:
                        continue
                    renderer = getattr(self, method_name, None)
                    if not renderer:
                        continue

                    token = set_render_context(self, region_id)
                    try:
                        if inspect.iscoroutinefunction(renderer):
                            region_html = await renderer()
                        else:
                            region_html = renderer()
                    finally:
                        reset_render_context(token)

                    stripped_html = region_html.lstrip()
                    if stripped_html.startswith(
                        ("<!DOCTYPE", "<!doctype", "<html", "<HTML")
                    ):
                        logger.debug(
                            "render_update: falling back to FULL update, "
                            f"region {region_id} rendered full-document HTML"
                        )
                        has_root_dirty = True
                        break

                    updates.append({"region": region_id, "html": region_html})

                if not has_root_dirty:
                    self._dirty_regions.clear()

                    # If we successfully generated partial updates, return them
                    result = {"type": "regions", "regions": updates}
                    print(f"RENDER-UPDATE-REGIONS: {updates}", flush=True)

                    # 2. Collect commands from all refs (recursively)
                    commands = self._collect_all_commands()
                    if commands:
                        result["commands"] = commands

                    return result

        response = await self.render(init=init)
        html = bytes(response.body).decode("utf-8")
        logger.debug(f"render_update: returning FULL update (len={len(html)})")

        result: dict[str, Any] = {"type": "full", "html": html}
        commands = self._collect_all_commands()
        if commands:
            result["commands"] = commands
        return result

    async def push_state(self) -> None:
        """Force a UI update with current state (useful for streaming progress)."""
        logger.debug(
            f"[{self._instance_id}] push_state called. Has _on_update: {bool(self._on_update)}"
        )
        if self._on_update:
            if inspect.iscoroutinefunction(self._on_update):
                await self._on_update()
            else:
                self._on_update()

    async def _resolve_await(self, await_id: str, awaitable: Awaitable) -> None:
        """Background task to resolve an await block and trigger update."""
        import inspect

        logger.debug(f"[{self._instance_id}] Starting resolution for {await_id}")
        self._await_states[await_id] = {
            "status": "pending",
            "result": None,
            "error": None,
        }

        try:
            if inspect.isawaitable(awaitable):
                result = await awaitable
            else:
                result = awaitable

            logger.debug(
                f"[{self._instance_id}] Resolution success for {await_id}: {result}"
            )
            self._await_states[await_id] = {
                "status": "success",
                "result": result,
                "error": None,
            }
        except Exception as e:
            logger.debug(f"[{self._instance_id}] Resolution error for {await_id}: {e}")
            self._await_states[await_id] = {
                "status": "error",
                "result": None,
                "error": e,
            }

        # Mark region as dirty and push state
        self._dirty_regions.add(await_id)
        logger.debug(
            f"[{self._instance_id}] Marked {await_id} dirty. Calls push_state..."
        )
        try:
            await self.push_state()
        except Exception as e:
            logger.debug(f"[{self._instance_id}] push_state failed: {e}")
            # push_state might fail if connection closed
            pass

    async def _render_template(self) -> str:
        """Render template - implemented by codegen."""
        return ""
