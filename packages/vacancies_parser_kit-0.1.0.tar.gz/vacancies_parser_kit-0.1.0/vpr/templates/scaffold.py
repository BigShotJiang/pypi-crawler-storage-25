"""Project scaffold templates for `vpr init`."""

from __future__ import annotations

from pathlib import Path

VPR_PROJECT_YML = """\
name: {project_name}
version: "1.0"

default_profile: dev

paths:
  sources: sources
  dictionaries: dictionaries
"""

PROFILES_YML = """\
default_profile: dev

profiles:
  dev:
    targets:
      clickhouse_local:
        type: clickhouse
        host: localhost
        port: 9000
        database: vacancies
        user: default
        password: ""

      postgres_local:
        type: postgres
        host: localhost
        port: 5432
        database: vacancies
        user: postgres
        password: ""

  # prod:
  #   targets:
  #     clickhouse_prod:
  #       type: clickhouse
  #       host: "{{{{ env_var('CH_HOST') }}}}"
  #       port: 9000
  #       database: vacancies
  #       user: "{{{{ env_var('CH_USER') }}}}"
  #       password: "{{{{ env_var('CH_PASSWORD') }}}}"
"""

EXAMPLE_SOURCE_YML = """\
name: hh_example
type: headhunter
tags: [hh, example]

params:
  # Токен приложения (client_credentials) — получить на dev.hh.ru
  # token: "YOUR_APP_TOKEN"

  # Параметры поиска (все опциональны)
  search_text: "python developer"
  area: 1                       # Москва (id из /areas)
  experience: noExperience      # noExperience | between1And3 | between3And6 | moreThan6
  # employment: full            # full | part | project | volunteer | probation
  # schedule: remote            # fullDay | shift | flexible | remote | flyInFlyOut
  # professional_role: 96       # id из /professional_roles
  # industry: 7                 # id из /industries
  # salary: 100000
  # currency: RUR
  # date_from: "2026-04-01T00:00:00+0300"
  # date_to: "2026-04-05T00:00:00+0300"
  # period: 7                   # последние N дней (нельзя с date_from/date_to)
  # order_by: publication_time  # relevance | publication_time | salary_desc | salary_asc

  # Обогащение: запрашивать полные данные по каждой вакансии (description, key_skills)
  enrich: true

  # Задержка между запросами (секунды)
  request_delay: 0.25

# targets:
#   - clickhouse_local
#   - postgres_local
"""


def render_project_scaffold(target: Path, project_name: str) -> None:
    """Create a full project skeleton at *target*."""
    target.mkdir(parents=True)
    (target / "sources").mkdir()
    (target / "dictionaries").mkdir()

    (target / "vpr_project.yml").write_text(
        VPR_PROJECT_YML.format(project_name=project_name)
    )
    (target / "profiles.yml").write_text(PROFILES_YML)
    (target / "sources" / "hh_example.yml").write_text(EXAMPLE_SOURCE_YML)
    (target / "sources" / ".gitkeep").touch()
    (target / "dictionaries" / ".gitkeep").touch()
