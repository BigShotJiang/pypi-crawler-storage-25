"""Source plugins — import here so @register_source decorators fire."""

import vpr.sources.headhunter  # noqa: F401
