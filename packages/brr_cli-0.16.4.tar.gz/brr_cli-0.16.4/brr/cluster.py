import shlex
import shutil
import subprocess
import sys
from collections import defaultdict
from pathlib import Path

import click
from rich import box
from rich.console import Console
from rich.markup import escape
from rich.table import Table

from brr.state import (
    read_config, read_merged_config, find_project_root, find_project_providers,
    cluster_ssh_alias, check_provider_configured, is_provider_configured,
    nebius_regions, nebius_default_region, nebius_region_config,
)
from brr.templates import (
    resolve_template,
    render,
    apply_overrides,
    prepare_staging,
    inject_brr_infra,
    write_yaml,
    output_path_for,
    list_templates,
    find_project_templates,
    extract_template_aliases,
    check_required,
    find_required,
    _get_nested,
    GLOBAL_ARGS,
)

console = Console()


def _get_git_info(project_root):
    """Get git repo metadata for project sync.

    Returns dict with remote_url, branch, commit, repo_name, project_path
    or None if not a git repo or has no remote.
    """
    project_root = Path(project_root)

    def _git(*args):
        return subprocess.run(
            ["git"] + list(args),
            cwd=project_root, capture_output=True, text=True,
        )

    # Must be a git repo
    if _git("rev-parse", "--git-dir").returncode != 0:
        return None

    # Must have a remote
    r = _git("remote", "get-url", "origin")
    if r.returncode != 0:
        return None
    remote_url = r.stdout.strip()

    r = _git("rev-parse", "--abbrev-ref", "HEAD")
    if r.returncode != 0:
        return None
    branch = r.stdout.strip()

    r = _git("rev-parse", "HEAD")
    if r.returncode != 0:
        return None
    commit = r.stdout.strip()

    return {
        "remote_url": remote_url,
        "branch": branch,
        "commit": commit,
        "repo_name": project_root.name,
        "project_path": str(project_root),
    }


def _validate_git_for_sync(project_root, git_info, config, allow_dirty=False):
    """Validate git state before first deploy. Raises click.UsageError on failure.

    allow_dirty relaxes only the clean-working-tree requirement (the cluster
    still syncs the pushed HEAD via sync-repo.sh, so local uncommitted edits are
    not deployed). The remaining checks are hard preconditions for sync-repo.sh
    and are always enforced.
    """
    project_root = Path(project_root)

    def _git(*args):
        return subprocess.run(
            ["git"] + list(args),
            cwd=project_root, capture_output=True, text=True,
        )

    errors = []

    # Working tree must be clean (unless --allow-dirty)
    r = _git("status", "--porcelain")
    if r.stdout.strip():
        if allow_dirty:
            console.print(
                "[yellow]--allow-dirty: working tree has uncommitted changes. "
                "The cluster will run the pushed HEAD; local uncommitted edits "
                "are NOT synced.[/yellow]"
            )
        else:
            errors.append(
                "Working tree has uncommitted changes. Commit or stash before "
                "deploying (or pass --allow-dirty to deploy the pushed HEAD anyway)."
            )

    # Remote URL must be SSH
    url = git_info["remote_url"]
    if not (url.startswith("git@") or url.startswith("ssh://")):
        errors.append(
            f"Remote URL is not SSH: {url}\n"
            "  Set an SSH remote: git remote set-url origin git@github.com:user/repo.git"
        )

    # All changes must be pushed. Use `git fetch` to refresh origin refs first,
    # otherwise `origin/BRANCH..HEAD` silently returns empty when the local
    # remote ref is stale or missing, and sync-repo.sh's `git reset --hard`
    # on the head then fails with "Could not parse object" because the commit
    # was never pushed.
    branch = git_info["branch"]
    _git("fetch", "--quiet", "origin", branch)
    r = _git("rev-parse", "--verify", f"origin/{branch}")
    if r.returncode != 0:
        errors.append(
            f"Branch '{branch}' is not on origin. Push it first: "
            f"`git push -u origin {branch}`"
        )
    else:
        r = _git("merge-base", "--is-ancestor", "HEAD", f"origin/{branch}")
        if r.returncode != 0:
            commit = git_info["commit"][:8]
            errors.append(
                f"Local commit {commit} is not reachable from origin/{branch}. "
                f"Push before deploying."
            )

    # GitHub SSH keys must be configured
    if not config.get("GITHUB_SSH_KEY"):
        errors.append("GITHUB_SSH_KEY not configured. Run `brr configure` to set up GitHub SSH access.")

    if errors:
        raise click.UsageError("Git pre-flight checks failed:\n  " + "\n  ".join(errors))


def _resolve_provider(name):
    """Parse provider:name syntax. Requires explicit prefix.

    Returns (provider, template_or_cluster_name).
    - Explicit prefix (aws:dev) → provider from prefix
    - File path (./foo.yaml) → default provider (aws)
    - Bare name (dev) → raises UsageError
    """
    # File path — pass through with default provider
    if "/" in name or name.endswith(".yaml"):
        return "aws", name
    # Require explicit provider:name prefix
    if ":" not in name:
        raise click.UsageError(
            f"Template '{name}' requires a provider prefix.\n"
            f"Use provider:name syntax (e.g. aws:{name}, nebius:{name}, verda:{name})."
        )
    provider, _, tpl = name.partition(":")
    return provider, tpl


def _project_root_for(provider, tpl_name, no_project=False):
    """Find project_root relevant to this template.

    Returns project root if a matching project template exists.
    Raises UsageError if inside a project but template doesn't exist
    (unless no_project=True, which always returns None).
    """
    if no_project:
        return None
    project_root = find_project_root()
    if project_root is not None:
        project_tpl = Path(project_root) / ".brr" / provider / f"{tpl_name}.yaml"
        if not project_tpl.exists():
            # List available project templates for this provider
            provider_dir = Path(project_root) / ".brr" / provider
            available = sorted(p.stem for p in provider_dir.glob("*.yaml")) if provider_dir.is_dir() else []
            msg = f"Template '{tpl_name}' not found in project .brr/{provider}/."
            if available:
                msg += f"\nAvailable project templates: {', '.join(available)}"
            msg += "\nUse --no-project to use built-in templates."
            raise click.UsageError(msg)
    return project_root


def _ray_cmd(provider="aws"):
    """Return the command prefix for invoking ray.

    Inside a uv project, uses ``uv run ray``.  Otherwise finds the ray
    binary from the current venv or PATH.
    """
    project_root = find_project_root()
    if project_root:
        pr = Path(project_root)
        if (pr / "pyproject.toml").exists() and (pr / "uv.lock").exists():
            # Probe the ray *CLI* — brr runs `uv run ray`, not `import ray`.
            # The module can import while the console script is broken (e.g. a
            # stale absolute shebang after the project dir was renamed/moved),
            # which otherwise surfaces as an opaque `uv` spawn ENOENT later.
            probe = subprocess.run(
                ["uv", "run", "ray", "--version"],
                cwd=pr, capture_output=True,
            )
            if probe.returncode != 0:
                importable = subprocess.run(
                    ["uv", "run", "python", "-c", "import ray"],
                    cwd=pr, capture_output=True,
                ).returncode == 0
                if importable:
                    console.print(
                        "[red]The `ray` CLI in your project venv is broken.[/red]\n"
                        "`import ray` works but `uv run ray` fails — usually a "
                        "stale venv (project dir renamed or moved, leaving a dead "
                        "interpreter path in .venv/bin/ray).\n"
                        "Rebuild it with:\n"
                        f"  [bold]cd {pr} && rm -rf .venv && uv sync[/bold]"
                    )
                else:
                    sdk = {"aws": "boto3"}.get(provider, provider)
                    console.print(
                        f"[red]Ray is not installed in your project.[/red]\n"
                        f"Add cluster dependencies with:\n"
                        f"  [bold]uv add 'ray[default]' {sdk}[/bold]"
                    )
                raise SystemExit(1)
            return ["uv", "run", "ray"]

    venv_ray = Path(sys.executable).parent / "ray"
    if venv_ray.is_file():
        return [str(venv_ray)]

    on_path = shutil.which("ray")
    if on_path:
        return [on_path]

    console.print("[red]Ray is not installed.[/red]")
    console.print("Install it with: [bold]uv tool install brr-cli[/bold]")
    raise SystemExit(1)


def _provider_env(provider):
    """Build env dict with PYTHONPATH for non-AWS providers (local Ray import)."""
    if provider == "aws":
        return None
    import os

    brr_parent = str(Path(__file__).parent.parent)
    env = os.environ.copy()
    env["PYTHONPATH"] = brr_parent + ":" + env.get("PYTHONPATH", "")
    return env


def _run_ray(args, provider="aws"):
    """Run a ray CLI command, passing through stdout/stderr."""
    cmd = _ray_cmd(provider) + args
    console.print(f"[dim]$ {escape(' '.join(cmd))}[/dim]")
    result = subprocess.run(cmd, env=_provider_env(provider))
    if result.returncode != 0:
        sys.exit(result.returncode)


def _resolve_cluster_name(tpl_name, project_root=None, region=None):
    """Resolve template name to cluster_name.

    Inside a project: derives {repo_name}-{tpl_name}.
    Outside a project: returns tpl_name.
    If region is provided, appends -{region} to disambiguate multi-region clusters.
    """
    if "/" in tpl_name or tpl_name.endswith(".yaml"):
        return tpl_name
    base = f"{Path(project_root).name}-{tpl_name}" if project_root else tpl_name
    if region:
        base = f"{base}-{region}"
    return base


def _resolve_nebius_region(config, region):
    """Validate the --region flag (or default) against configured regions.

    Returns (region, cluster_suffix_region). `cluster_suffix_region` is the
    region to append to cluster names, or None when only one region is
    configured (legacy / single-region users keep their existing cluster
    names). Raises click.UsageError if the region is invalid.
    """
    regions = nebius_regions(config)
    if not regions:
        raise click.UsageError(
            "Nebius not configured. Run `brr configure nebius`."
        )
    if region is None:
        region = nebius_default_region(config)
    if region not in regions:
        raise click.UsageError(
            f"Nebius region '{region}' not configured. "
            f"Configured regions: {', '.join(regions)}"
        )
    suffix = region if len(regions) >= 2 else None
    return region, suffix


def _reject_nebius_region_override(provider, overrides):
    """Catch `region=X` / `provider.region=X` used for Nebius region selection.

    For AWS, `region=` is a valid positional override (maps to provider.region).
    For Nebius, region selection goes through the --region flag (per-region
    config overlay + cluster-name suffix); a positional `region=` is inert and
    silently produces the wrong cluster name. Fail loud with the fix.
    """
    if provider != "nebius":
        return
    for o in overrides:
        key, _, val = o.partition("=")
        if key.strip() in ("region", "provider.region"):
            raise click.UsageError(
                f"'{o}' does not select a Nebius region. "
                f"Use the --region flag instead: --region {val or '<name>'}"
            )


def _find_nebius_cluster_variants(base_name):
    """Scan staging dirs for clusters matching {base_name} or {base_name}-{region}.

    Returns list of (cluster_name, region_or_None) tuples. Used for auto-resolving
    `brr attach nebius:h100` when region isn't specified but multiple regional
    clusters share the same base name.
    """
    from brr.state import STATE_DIR
    nebius_dir = STATE_DIR / "staging" / "nebius"
    if not nebius_dir.is_dir():
        return []
    variants = []
    for entry in nebius_dir.iterdir():
        if not entry.is_dir():
            continue
        name = entry.name
        if name == base_name:
            variants.append((name, None))
        elif name.startswith(f"{base_name}-"):
            region = name[len(base_name) + 1:]
            variants.append((name, region))
    return variants


def _resolve_nebius_cluster_name_for_attach(tpl_name, project_root, config, region_opt):
    """For attach/vscode: resolve cluster name given optional region.

    1. If region_opt is given, append directly.
    2. Else if user typed a name that already has a region suffix (i.e. it matches
       a staging dir exactly), use it.
    3. Else scan for variants of the base name — use it if exactly one exists;
       list options and error if multiple.
    """
    base = _resolve_cluster_name(tpl_name, project_root)
    # Case 1: explicit region
    if region_opt:
        suffix = region_opt if len(nebius_regions(config)) >= 2 else None
        return _resolve_cluster_name(tpl_name, project_root, region=suffix)
    # Case 2: the name already resolves to a staging dir (legacy or fully-qualified)
    from brr.state import staging_dir_for
    if staging_dir_for(base, "nebius").exists():
        return base
    # Case 3: scan for variants
    variants = _find_nebius_cluster_variants(base)
    if len(variants) == 1:
        return variants[0][0]
    if len(variants) > 1:
        names = ", ".join(v[0] for v in variants)
        raise click.UsageError(
            f"Multiple clusters match '{base}': {names}\n"
            f"  Specify the region, e.g. `brr attach nebius:{tpl_name} --region=<name>`"
        )
    # No variants found — return the base anyway (will fail downstream with a clear error)
    return base


def _project_cluster_map(project_root):
    """Return mapping of cluster_name → template_stem for project templates.

    For Nebius templates, also enumerates per-region variants
    ({repo}-{tpl}-{region}) when 2+ regions are configured, since `brr up`
    auto-suffixes multi-region cluster names.
    """
    mapping = {}
    repo_name = Path(project_root).name
    brr_dir = Path(project_root) / ".brr"
    config = read_config()
    nebius_region_list = nebius_regions(config) if len(nebius_regions(config)) >= 2 else []
    for yaml_file in brr_dir.glob("*/*.yaml"):
        tpl_stem = yaml_file.stem
        provider = yaml_file.parent.name
        base = f"{repo_name}-{tpl_stem}"
        mapping[base] = tpl_stem
        if provider == "nebius":
            for region in nebius_region_list:
                mapping[f"{base}-{region}"] = tpl_stem
    return mapping


def _staging_project_map():
    """Scan staging dirs to map cluster_name → project_path.

    Reads repo_info.json from each staging directory to find the local
    project path associated with each cluster.
    """
    import json
    from brr.state import STATE_DIR

    mapping = {}  # cluster_name → project_path_str
    staging = STATE_DIR / "staging"
    if not staging.is_dir():
        return mapping

    for repo_info in staging.glob("**/repo_info.json"):
        try:
            info = json.loads(repo_info.read_text())
            project_path = info.get("project_path", "")
            if project_path:
                cluster_name = repo_info.parent.name
                mapping[cluster_name] = project_path
        except (json.JSONDecodeError, KeyError):
            continue
    return mapping


def _sync_ssh_config(provider, cluster_name, display_name=None, region_suffix=""):
    """Query the cloud for the cluster head IP and update local SSH config."""
    from brr.providers import get_provider
    from brr.ssh import update_ssh_config

    config = read_config()
    if not config:
        return
    prov = get_provider(provider)
    head_ip = prov.find_head_ip(config, cluster_name)
    if head_ip:
        ssh_alias = cluster_ssh_alias(provider, cluster_name)
        update_ssh_config(ssh_alias, head_ip, prov.ssh_key(config), prov.ssh_user(config))
        attach_name = display_name or cluster_name
        console.print(f"Updated local SSH config: [green]{ssh_alias}[/green]")
        console.print(f"  Connect with: [bold]brr attach {attach_name}{region_suffix}[/bold]")
        console.print(f"  VS Code:      [bold]brr vscode {attach_name}{region_suffix}[/bold]")
    else:
        console.print(f"[yellow]Warning: could not find head IP for cluster '{cluster_name}'[/yellow]")


@click.command()
@click.argument("template")
@click.argument("overrides", nargs=-1)
@click.option("-y", "--yes", is_flag=True, help="Skip confirmation prompts")
@click.option("--dry-run", is_flag=True, help="Print rendered config without launching")
@click.option("--no-project", is_flag=True, help="Use built-in template even inside a project")
@click.option("--region", default=None, help="Nebius region (when multiple configured)")
@click.option("--allow-dirty", is_flag=True,
              help="Deploy even with an unclean working tree. The cluster still "
                   "runs the pushed HEAD — local uncommitted changes are NOT synced.")
def up(template, overrides, yes, dry_run, no_project, region, allow_dirty):
    """Launch or update a Ray cluster.

    TEMPLATE is provider:name (aws:h100, nebius:cpu) or a .yaml file path.
    Inside a project, provider:name resolves project templates (e.g.
    aws:dev → .brr/aws/dev.yaml). Use --no-project for built-in templates.

    OVERRIDES are key=value pairs applied to the rendered YAML.
    Use `brr templates show TEMPLATE` to see available overrides.

    \b
      instance_type=p5.48xlarge    Override head node instance type
      max_workers=4                Set max workers
      spot=true                    Enable spot pricing
      az=us-east-1a                Override availability zone
      provider.region=us-west-2    Dot-notation for arbitrary YAML paths
    """
    import yaml

    provider, tpl_name = _resolve_provider(template)
    _reject_nebius_region_override(provider, overrides)
    project_root = _project_root_for(provider, tpl_name, no_project=no_project)

    config, _ = read_merged_config(project_root)
    check_provider_configured(provider, config)

    # Nebius: resolve region and overlay its per-region config before render/staging.
    nebius_region = None
    nebius_cluster_suffix = None
    nebius_overlay = None
    if provider == "nebius":
        nebius_region, nebius_cluster_suffix = _resolve_nebius_region(config, region)
        nebius_overlay = nebius_region_config(config, nebius_region)
        config = {**config, **nebius_overlay}
        console.print(f"Nebius region: [bold cyan]{nebius_region}[/bold cyan]")

    try:
        tpl_content, tpl_name = resolve_template(tpl_name, provider, project_root=project_root)
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1)

    if project_root:
        tpl_path = Path(project_root) / ".brr" / provider / f"{tpl_name}.yaml"
        console.print(f"Template: [bold cyan]{tpl_name}[/bold cyan] (project {tpl_path.relative_to(project_root)})")
    else:
        console.print(f"Template: [bold cyan]{tpl_name}[/bold cyan] (built-in)")

    rendered = render(tpl_content, config)
    template_aliases = extract_template_aliases(rendered)

    if overrides:
        console.print(f"Overrides: [yellow]{' '.join(overrides)}[/yellow]")
        try:
            rendered = apply_overrides(rendered, overrides, template_aliases)
        except (ValueError, KeyError) as e:
            console.print(f"[red]Override error: {e}[/red]")
            raise SystemExit(1)

    check_required(rendered, template_aliases)

    # Nebius: require security_group_id in template
    if provider == "nebius":
        sg_id = rendered.get("provider", {}).get("security_group_id", "")
        if not sg_id or "{{" in str(sg_id):
            if not config.get("NEBIUS_SECURITY_GROUP_ID"):
                raise click.UsageError(
                    "Nebius security group not configured.\n"
                    "  Run `brr configure nebius` to create one."
                )
            raise click.UsageError(
                "Template is missing security_group_id in the provider section.\n"
                "  Add this line under 'provider:' in your template:\n"
                '    security_group_id: "{{NEBIUS_SECURITY_GROUP_ID}}"'
            )

    # Nebius: validate node_config keys to catch typos early
    if provider == "nebius":
        from brr.nebius.node_provider import NebiusNodeProvider
        for nt_name, nt in rendered.get("available_node_types", {}).items():
            nc = nt.get("node_config", {})
            unknown = set(nc) - NebiusNodeProvider._KNOWN_NODE_CONFIG_KEYS
            if unknown:
                raise click.UsageError(
                    f"Unknown node_config keys in {nt_name} (typo?): {', '.join(sorted(unknown))}"
                )

    # Verda: validate node_config keys to catch typos early
    if provider == "verda":
        from brr.verda.node_provider import VerdaNodeProvider
        for nt_name, nt in rendered.get("available_node_types", {}).items():
            nc = nt.get("node_config", {})
            unknown = set(nc) - VerdaNodeProvider._KNOWN_NODE_CONFIG_KEYS
            if unknown:
                raise click.UsageError(
                    f"Unknown node_config keys in {nt_name} (typo?): {', '.join(sorted(unknown))}"
                )

        # Shared-volume location sanity check. Verda volumes are
        # region-scoped, so instances must be in the same datacenter as
        # the shared volume to attach it. Surface a clear error instead
        # of the opaque 'volumes.attach' API failure we'd get at launch.
        shared_volume_id = rendered.get("provider", {}).get("shared_volume_id", "")
        if shared_volume_id and "{{" not in str(shared_volume_id):
            template_locations = {
                nt.get("node_config", {}).get("location")
                for nt in rendered.get("available_node_types", {}).values()
                if nt.get("node_config", {}).get("location")
            }
            provider_loc = rendered.get("provider", {}).get("location")
            if provider_loc and "{{" not in str(provider_loc):
                template_locations.add(provider_loc)
            try:
                from brr.verda.nodes import _verda_client
                volume = _verda_client().volumes.get_by_id(shared_volume_id)
                volume_location = getattr(volume, "location", None)
            except Exception as e:
                console.print(f"[yellow]Warning: could not verify shared-volume location: {e}[/yellow]")
                volume_location = None

            if volume_location and template_locations:
                mismatched = {loc for loc in template_locations if loc != volume_location}
                if mismatched:
                    raise click.UsageError(
                        f"Shared volume {shared_volume_id} lives in "
                        f"{volume_location}, but the template wants to launch in "
                        f"{', '.join(sorted(mismatched))}. "
                        f"Edit the template to use location: {volume_location}, "
                        f"or run `brr configure verda` to pick a different shared "
                        f"volume."
                    )

    if project_root and "cluster_name" in rendered:
        console.print(
            "[yellow]Warning: 'cluster_name' in your project template is ignored "
            "(auto-derived from project + template name). "
            "You can safely remove it from your template.[/yellow]"
        )

    cluster_name = _resolve_cluster_name(tpl_name, project_root, region=nebius_cluster_suffix)
    rendered["cluster_name"] = cluster_name

    # Always emit sync-repo.sh when the project is a git repo — the script is
    # idempotent (skips if $PROJECT_DIR/.git exists), so re-deploys cost nothing
    # but recover when a first-deploy clone silently failed (e.g. stale GitHub
    # key on the cluster) or when the cluster lands on a fresh shared FS in a
    # new region. Validation always runs: a stale repo pin would fail sync-repo
    # on the head with an opaque "Could not parse object" error; catching it
    # here is cheaper than debugging it on the cluster.
    git_info = None
    if project_root:
        git_info = _get_git_info(project_root)
        if git_info is not None:
            _validate_git_for_sync(project_root, git_info, config, allow_dirty=allow_dirty)

    first_deploy = True
    if project_root and not dry_run:
        out_path = output_path_for(cluster_name, provider)
        if out_path.exists():
            first_deploy = False

    # _brr.shared=false: skip mounting any shared filesystem (EFS / virtiofs /
    # Verda volume) by zeroing the relevant config keys in the staged
    # config.env. setup.sh already short-circuits when these are empty.
    config_overlay = dict(nebius_overlay or {})
    if template_aliases.get("shared") is False:
        config_overlay.update({
            "EFS_ID": "",
            "NEBIUS_FILESYSTEM_ID": "",
            "VERDA_SHARED_VOLUME_ID": "",
        })

    staging = prepare_staging(
        cluster_name, provider, project_root=project_root,
        config_overlay=config_overlay or None,
    )
    inject_brr_infra(rendered, staging, git_info=git_info, brr_meta=template_aliases)

    # Persist the Nebius region alongside the staged YAML so later commands
    # (down, attach, nuke, list) can route to the correct region without
    # scanning all configured regions.
    if provider == "nebius" and nebius_region:
        import json
        meta_path = staging / "brr_meta.json"
        meta = {}
        if meta_path.exists():
            try:
                meta = json.loads(meta_path.read_text())
            except (json.JSONDecodeError, OSError):
                meta = {}
        meta["region"] = nebius_region
        meta_path.write_text(json.dumps(meta, indent=2) + "\n")

    if dry_run:
        console.print()
        console.print(yaml.dump(rendered, default_flow_style=False, sort_keys=False), end="", highlight=False)
        return

    # Self-heal backstop: with cache_stopped_nodes false, Ray's stock AWS
    # provider never reuses or reaps a stopped instance — anything stopped
    # out-of-band (console-stop, legacy idle-shutdown husks) is an orphan
    # leaking its EBS volume. Sweep this cluster's orphans before launch.
    # Skipped when nodes are cached (a stopped node is then intentional).
    if provider == "aws" and not rendered.get("provider", {}).get(
        "cache_stopped_nodes", False
    ):
        from brr.providers import get_provider
        try:
            swept = get_provider(provider).cleanup_stopped(config, cluster_name)
            if swept:
                console.print(
                    f"[dim]Swept {swept} orphaned stopped instance(s) "
                    f"for '{cluster_name}'[/dim]"
                )
        except Exception as e:
            console.print(
                f"[yellow]Warning: orphaned-instance sweep failed: {e}[/yellow]"
            )

    # Nebius self-heal backstop: a boot disk is created before its instance,
    # and DeleteInstance never cascades to the disk. A disk abandoned when
    # CreateInstance failed (no instance ever existed) is invisible to the
    # instance-centric autoscaler sweep and leaks forever. Sweep this
    # cluster's unreferenced, non-recycle disks before launch. The filter
    # only ever touches disks no instance references, so it is safe even with
    # cache_stopped_nodes on (a cached instance still references its disk).
    if provider == "nebius":
        from brr.providers import get_provider
        try:
            swept = get_provider(provider).cleanup_orphan_disks(config, cluster_name)
            if swept:
                console.print(
                    f"[dim]Swept {swept} orphaned disk(s) "
                    f"for '{cluster_name}'[/dim]"
                )
        except Exception as e:
            console.print(
                f"[yellow]Warning: orphaned-disk sweep failed: {e}[/yellow]"
            )

    if project_root and git_info:
        if first_deploy:
            console.print(f"Repo sync: [green]git clone {git_info['repo_name']}[/green] → ~/code/{git_info['repo_name']}/")
        else:
            console.print(f"Repo sync: [dim]sync-repo.sh will run (no-op if already cloned)[/dim]")
    elif project_root:
        console.print(f"Repo sync: [yellow]skipped (not a git repo with remote)[/yellow]")

    out = output_path_for(cluster_name, provider)
    write_yaml(rendered, out)
    console.print(f"Wrote [green]{out}[/green]")

    ray_args = ["up", str(out)]
    # Always disable config cache — brr regenerates staging every time, and
    # cached configs cause stale/missing /tmp/brr/staging/ on node restarts.
    ray_args.append("--no-config-cache")
    if yes:
        ray_args.append("-y")

    cmd = _ray_cmd(provider) + ray_args
    console.print(f"[dim]$ {escape(' '.join(cmd))}[/dim]")
    ray_result = subprocess.run(cmd, env=_provider_env(provider))

    # Post-ray: sync SSH config even if ray up had warnings (non-zero exit)
    try:
        display_name = f"{provider}:{tpl_name}"
        region_suffix = ""
        if provider == "nebius" and nebius_cluster_suffix:
            region_suffix = f" --region {nebius_cluster_suffix}"
        _sync_ssh_config(
            provider, cluster_name,
            display_name=display_name,
            region_suffix=region_suffix,
        )
    except Exception as e:
        console.print(f"[yellow]Warning: SSH config sync failed: {e}[/yellow]")

    if ray_result.returncode != 0:
        sys.exit(ray_result.returncode)


@click.command()
@click.argument("template")
@click.argument("overrides", nargs=-1)
@click.option("-y", "--yes", is_flag=True, help="Skip confirmation prompts")
@click.option("--delete", is_flag=True, help="Full cleanup: terminate all instances, remove local staging files")
@click.option("--no-project", is_flag=True, help="Use built-in template even inside a project")
@click.option("--region", default=None, help="Nebius region (when multiple configured)")
def down(template, overrides, yes, delete, no_project, region):
    """Stop a cluster (preserving instances for fast restart).

    Instances are stopped, not terminated — local disk data is preserved and
    the cluster restarts quickly on the next `brr up`. No hourly charges while
    stopped (EBS storage charges still apply).

    With --delete, terminates all instances (data lost) and removes local
    staging files. Use `brr clean` to selectively terminate stopped instances.

    For Nebius with multiple regions configured, pass --region=<name> to target
    a specific region's cluster (e.g. `brr down nebius:h100 --region=eu-north1`).
    """
    import shutil
    from pathlib import Path
    from brr.providers import get_provider
    from brr.ssh import remove_ssh_config
    from brr.state import staging_dir_for, rendered_yaml_for

    provider, tpl_name = _resolve_provider(template)
    _reject_nebius_region_override(provider, overrides)
    project_root = _project_root_for(provider, tpl_name, no_project=no_project)

    # down does not render, so any positional overrides are ignored. Surface
    # this for every provider — previously only non-nebius warned, so a stray
    # Nebius override (e.g. region=) vanished with zero feedback.
    if overrides:
        console.print(f"[yellow]Ignoring overrides (down does not render): {' '.join(overrides)}[/yellow]")

    nebius_suffix = None
    if provider == "nebius":
        config = read_config()
        if nebius_regions(config):
            _, nebius_suffix = _resolve_nebius_region(config, region)

    cluster_name = _resolve_cluster_name(tpl_name, project_root, region=nebius_suffix)
    ssh_alias = cluster_ssh_alias(provider, cluster_name)

    if "/" in tpl_name or tpl_name.endswith(".yaml"):
        yaml_path = tpl_name
    else:
        yaml_path = str(output_path_for(cluster_name, provider))

    # Run ray down if YAML exists
    yaml_file = Path(yaml_path)
    if yaml_file.exists():
        ray_args = ["down", yaml_path]
        if yes or delete:
            ray_args.append("-y")
        _run_ray(ray_args, provider=provider)
    elif delete:
        console.print(f"[yellow]No rendered YAML at {yaml_path}, skipping ray down.[/yellow]")
    else:
        console.print(f"[red]No rendered YAML at {yaml_path}. Did you mean --delete?[/red]")
        raise SystemExit(1)

    # Clean up SSH config entry
    remove_ssh_config(ssh_alias)

    if not delete:
        return

    # Terminate any remaining cloud instances
    config = read_config()
    prov = get_provider(provider)

    with console.status(f"[bold green]Terminating instances for '{cluster_name}'..."):
        count = prov.terminate_cluster(config, cluster_name)
    if count:
        console.print(f"[green]Terminated {count} instance(s).[/green]")

    # Remove local staging files
    staging = staging_dir_for(cluster_name, provider)
    rendered = rendered_yaml_for(cluster_name, provider)

    if staging.exists():
        shutil.rmtree(staging)
        console.print(f"Removed staging: [dim]{staging}[/dim]")

    if rendered.exists():
        rendered.unlink()
        console.print(f"Removed config: [dim]{rendered}[/dim]")


@click.command()
@click.argument("cluster")
@click.argument("command", nargs=-1)
@click.option("--region", default=None, help="Nebius region (when multiple configured)")
@click.option("--no-project", is_flag=True, help="Use built-in template even inside a project")
def attach(cluster, command, region, no_project):
    """SSH into the head node of a Ray cluster.

    CLUSTER is provider:name (e.g. aws:h100, nebius:cpu).
    Uses the SSH config entry written by `brr up`.

    Optionally pass a COMMAND to run on the node (e.g. brr attach aws:h100 claude).

    For Nebius with multiple regions, pass --region=<name> or type the full
    suffixed cluster name (e.g. `brr attach nebius:h100-eu-north1`). When
    unambiguous, auto-resolves from staged clusters.
    """
    provider, name = _resolve_provider(cluster)
    project_root = _project_root_for(provider, name, no_project=no_project)
    if provider == "nebius":
        config = read_config()
        cluster_name = _resolve_nebius_cluster_name_for_attach(name, project_root, config, region)
    else:
        cluster_name = _resolve_cluster_name(name, project_root)
    host = cluster_ssh_alias(provider, cluster_name)

    # If launched from a project, cd into ~/code/{repo} on the remote
    cd_prefix = ""
    if project_root:
        repo_name = project_root.name
        cd_prefix = f"cd ~/code/{repo_name} 2>/dev/null; "

    if command:
        remote_cmd = " ".join(shlex.quote(c) for c in command)
        full_cmd = f"bash -lic {shlex.quote(cd_prefix + remote_cmd)}"
        console.print(f"[dim]$ ssh -t {host} {full_cmd}[/dim]")
        result = subprocess.run(["ssh", "-t", host, full_cmd])
    else:
        if cd_prefix:
            full_cmd = f"bash -lic {shlex.quote(cd_prefix + 'exec bash')}"
            console.print(f"[dim]$ ssh -t {host} (~/code/{project_root.name}/)[/dim]")  # type: ignore[union-attr]
            result = subprocess.run(["ssh", "-t", host, full_cmd])
        else:
            console.print(f"[dim]$ ssh {host}[/dim]")
            result = subprocess.run(["ssh", host])
    sys.exit(result.returncode)


@click.command()
@click.argument("template", required=False)
@click.argument("overrides", nargs=-1)
@click.option("-y", "--yes", is_flag=True, help="Skip confirmation prompt")
@click.option("--no-project", is_flag=True, help="Use built-in template even inside a project")
@click.option("--region", default=None, help="Nebius region (when multiple configured)")
def clean(template, overrides, yes, no_project, region):
    """Terminate stopped (cached) instances.

    Stopped instances are left behind by `brr down` (which stops rather than
    terminates). Use this to free them when cached instances have stale AMIs.

    If TEMPLATE is given, clean only that cluster. Otherwise clean all stopped
    Ray instances.

    For Nebius, pass --region=<name> to target one region (when the cluster name
    should include the region suffix).
    """
    from brr.providers import get_provider

    config = read_config()

    if template:
        provider, tpl_name = _resolve_provider(template)
        project_root = _project_root_for(provider, tpl_name, no_project=no_project)
        nebius_suffix = None
        if provider == "nebius" and nebius_regions(config):
            _, nebius_suffix = _resolve_nebius_region(config, region)
        cluster_name = _resolve_cluster_name(tpl_name, project_root, region=nebius_suffix)
        providers_to_clean = [(provider, cluster_name)]
    else:
        # Clean all configured providers
        providers_to_clean = [
            (p, None) for p in ("aws", "nebius", "verda")
            if is_provider_configured(p, config)
        ]
        if not providers_to_clean:
            console.print("[dim]No providers configured.[/dim]")
            return

    all_stopped = []
    for provider, cluster_name in providers_to_clean:
        prov = get_provider(provider)
        with console.status(f"[bold green]Querying stopped {provider} instances..."):
            stopped = prov.query_stopped(config, cluster_name)
        all_stopped.extend([(provider, inst) for inst in stopped])

    if not all_stopped:
        console.print("[dim]No stopped instances found.[/dim]")
        return

    by_cluster = defaultdict(list)
    for provider, inst in all_stopped:
        by_cluster[(provider, inst["cluster_name"])].append(inst)

    total = len(all_stopped)
    for (provider, name), instances in sorted(by_cluster.items()):
        console.print(f"  [cyan]{name}[/cyan] ({provider}): {len(instances)} stopped instance(s)")
    console.print(f"\nTotal: [bold]{total}[/bold] instance(s).")

    if not yes and not click.confirm("Terminate?", default=True):
        return

    # Group by provider for termination
    by_provider = defaultdict(list)
    for provider, inst in all_stopped:
        by_provider[provider].append(inst["instance_id"])

    terminated = 0
    for provider, ids in by_provider.items():
        prov = get_provider(provider)
        with console.status(f"[bold green]Terminating {provider} instances..."):
            terminated += prov.terminate_by_ids(config, ids)
    console.print(f"[green]Terminated {terminated} instance(s).[/green]")


@click.command()
@click.argument("cluster")
@click.option("--region", default=None, help="Nebius region (when multiple configured)")
@click.option("--no-project", is_flag=True, help="Use built-in template even inside a project")
def vscode(cluster, region, no_project):
    """Open VS Code on a running cluster via Remote SSH.

    Looks up the head node IP for CLUSTER (provider:name, e.g. aws:h100),
    updates the SSH config entry, and launches VS Code.

    For Nebius with multiple regions, pass --region=<name> or type the full
    suffixed name (e.g. `brr vscode nebius:h100-eu-north1`).
    """
    from brr.providers import get_provider
    from brr.ssh import update_ssh_config

    config = read_config()

    provider, name = _resolve_provider(cluster)
    check_provider_configured(provider, config)
    project_root = _project_root_for(provider, name, no_project=no_project)
    if provider == "nebius":
        cluster_name = _resolve_nebius_cluster_name_for_attach(name, project_root, config, region)
    else:
        cluster_name = _resolve_cluster_name(name, project_root)

    prov = get_provider(provider)

    with console.status(f"[bold green]Looking up cluster '{cluster_name}'..."):
        head_ip = prov.find_head_ip(config, cluster_name)

    if not head_ip:
        console.print(f"[red]No running cluster '{cluster_name}' found.[/red]")
        raise SystemExit(1)

    host = cluster_ssh_alias(provider, cluster_name)
    update_ssh_config(host, head_ip, prov.ssh_key(config), prov.ssh_user(config))

    remote_path = f"/home/ubuntu/code/{project_root.name}" if project_root else "/home/ubuntu/code"

    if shutil.which("code"):
        subprocess.run(["code", "--remote", f"ssh-remote+{host}", remote_path])
    else:
        console.print(
            f"[yellow]'code' command not found. "
            f"In VS Code: Cmd+Shift+P -> 'Shell Command: Install code command in PATH'[/yellow]"
        )
        console.print(f"[dim]Then run: code --remote ssh-remote+{host} {remote_path}[/dim]")


@click.command("list")
@click.option("-a", "--all", "show_all", is_flag=True, help="Show all clusters, not just this project's")
def list_cmd(show_all):
    """List live Ray clusters across configured providers.

    Inside a project, shows only clusters defined in .brr/ templates.
    Use --all to show every cluster.
    """
    from brr.providers import get_provider
    from brr.ssh import get_ray_status
    from brr.state import is_provider_configured

    config = read_config()

    project_root = find_project_root()

    if not show_all and not project_root:
        console.print("[yellow]Not in a brr project.[/yellow] Use [bold]brr list --all[/bold] to see all clusters.")
        return

    all_clusters = []  # list of (provider, cluster_dict)
    ray_statuses = {}
    any_queried = False

    for provider_name in ("aws", "nebius", "verda"):
        if not is_provider_configured(provider_name, config):
            continue
        any_queried = True
        try:
            prov = get_provider(provider_name)

            with console.status(f"[bold green]Querying {provider_name} clusters..."):
                provider_clusters = prov.list_clusters(config)

            for c in provider_clusters:
                all_clusters.append((provider_name, c))

            running = [c for c in provider_clusters if c["state"] == "running" and c["head_ip"] != "-"]
            key = prov.ssh_key(config)
            if running and key:
                with console.status(f"[bold green]Querying {provider_name} Ray status..."):
                    for c in running:
                        ray_statuses[(provider_name, c["cluster_name"])] = get_ray_status(c["head_ip"], key)
        except (ImportError, ModuleNotFoundError):
            console.print(f"[dim]{provider_name} configured but SDK not installed[/dim]")
        except TimeoutError as e:
            console.print(f"[yellow]{provider_name}: {e}[/yellow]")
        except Exception as e:
            console.print(f"[yellow]{provider_name}: query failed: {type(e).__name__}: {e}[/yellow]")

    # Build project cluster map (always, for display purposes)
    cluster_map = {}  # cluster_name → template_stem
    if project_root:
        cluster_map = _project_cluster_map(project_root)

    # For --all, also scan staging YAMLs to identify projects for all clusters
    project_paths = {}  # cluster_name → project_path_str
    if show_all:
        project_paths = _staging_project_map()
        # Build cluster maps for all discovered projects (not just the current one)
        for proj_path in set(project_paths.values()):
            proj = Path(proj_path)
            if proj.is_dir() and proj_path != (str(project_root) if project_root else ""):
                cluster_map.update(_project_cluster_map(proj))

    # Filter to project clusters unless --all
    if not show_all and project_root:
        all_clusters = [(p, c) for p, c in all_clusters if c["cluster_name"] in cluster_map]

    if not all_clusters:
        if not any_queried:
            console.print("[yellow]No cloud provider configured.[/yellow]")
            console.print("Run [bold]brr configure[/bold] to set up AWS or Nebius.")
        elif not show_all:
            console.print("[dim]No clusters found for this project. Use --all to see all clusters.[/dim]")
        else:
            console.print("[dim]No Ray clusters found.[/dim]")
        return

    has_multiple_providers = len({p for p, _ in all_clusters}) > 1
    has_regions = any(c.get("region") for _, c in all_clusters)

    if project_root and not show_all:
        console.print(f"Project: [bold]{project_root.name}[/bold]")

    table = Table(box=box.ROUNDED, show_header=True, header_style="bold white")
    if has_multiple_providers:
        table.add_column("Provider", style="dim")
    if show_all:
        table.add_column("Project")
    table.add_column("Cluster", style="cyan")
    if has_regions:
        table.add_column("Region", style="magenta")
    table.add_column("State")
    table.add_column("Head IP", style="green")
    table.add_column("Instance Type")
    table.add_column("Nodes", justify="right")
    table.add_column("Uptime", justify="right")
    table.add_column("Resources")

    for provider, c in all_clusters:
        state = c["state"]
        if state == "running":
            state_str = "[green]running[/green]"
        elif state == "stopped":
            state_str = "[red]stopped[/red]"
        else:
            state_str = "[yellow]mixed[/yellow]"

        rs = ray_statuses.get((provider, c["cluster_name"]))
        if rs:
            parts = [f"{rs['cpu']} CPU"]
            if rs["gpu"]:
                parts.append(f"{rs['gpu']} GPU")
            resources = ", ".join(parts)
        else:
            resources = "-"

        # Show template name (e.g. "dev") instead of cluster_name when in project
        display_name = cluster_map.get(c["cluster_name"], c["cluster_name"])

        row = []
        if has_multiple_providers:
            row.append(provider)
        if show_all:
            row.append(project_paths.get(c["cluster_name"], ""))
        row.append(display_name)
        if has_regions:
            row.append(c.get("region", "-"))
        row.extend([
            state_str,
            c["head_ip"],
            c["instance_type"],
            str(c["node_count"]),
            c["uptime"],
            resources,
        ])
        table.add_row(*row)

    console.print(table)


@click.group()
def templates():
    """Template configuration commands."""


@templates.command("list")
def templates_list():
    """List available templates (project + built-in)."""
    project_root = find_project_root()

    if project_root:
        providers = find_project_providers(project_root)
        for provider in providers:
            project_tpls = find_project_templates(project_root, provider)
            if project_tpls:
                console.print(f"[bold].brr/{provider}/ (project)[/bold]")
                for name in project_tpls:
                    console.print(f"  [bold cyan]{provider}:{name}[/bold cyan]")

    for provider in ("aws", "nebius", "verda"):
        builtin_tpls = list_templates(provider)
        if builtin_tpls:
            console.print(f"[bold]Built-in ({provider})[/bold]")
            for name in builtin_tpls:
                console.print(f"  [dim]{provider}:{name}[/dim]")


@templates.command()
@click.argument("template")
@click.option("--no-project", is_flag=True, help="Use built-in template even inside a project")
def show(template, no_project):
    """Show configurable arguments and rendered config for a template."""
    import yaml

    provider, tpl_name = _resolve_provider(template)
    project_root = _project_root_for(provider, tpl_name, no_project=no_project)

    cfg, _ = read_merged_config(project_root)
    check_provider_configured(provider, cfg)

    try:
        tpl_content, tpl_name = resolve_template(tpl_name, provider, project_root=project_root)
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1)

    rendered = render(tpl_content, cfg)
    template_aliases = extract_template_aliases(rendered)

    console.print(f"Template: [bold cyan]{template}[/bold cyan]")
    console.print()

    required_paths = find_required(rendered)
    if required_paths:
        reverse = {}
        for name, path in template_aliases.items():
            if isinstance(path, str):
                reverse[path] = name
        for name, info in GLOBAL_ARGS.items():
            if info["path"]:
                reverse[info["path"]] = name

        console.print("[bold]Required:[/bold]")
        for path in required_paths:
            friendly = reverse.get(path)
            if friendly:
                console.print(f"  [bold red]{friendly}[/bold red]  ({path})")
            else:
                console.print(f"  [bold red]{path}[/bold red]")
        console.print()

    non_required_aliases = {k: v for k, v in template_aliases.items()
                           if isinstance(v, str) and v not in required_paths}
    if non_required_aliases:
        console.print("[bold]Template overrides:[/bold]")
        for name, path in non_required_aliases.items():
            current = _get_nested(rendered, path)
            if current is not None:
                console.print(f"  {name:<24} \\[{current}]")
            else:
                console.print(f"  {name}")
        console.print()

    console.print("[bold]Common overrides:[/bold]")
    for name, info in GLOBAL_ARGS.items():
        path = info["path"]
        help_text = info["help"]
        if path:
            current = _get_nested(rendered, path)
            if current is not None:
                console.print(f"  {name:<24} {help_text} [dim]\\[{current}][/dim]")
            else:
                console.print(f"  {name:<24} {help_text}")
        else:
            console.print(f"  {name:<24} {help_text}")

    console.print()
    console.print("[dim]Any key=value using dot-notation also accepted.[/dim]")

    console.print()
    console.print("[bold]Rendered config:[/bold]")
    console.print(yaml.dump(rendered, default_flow_style=False, sort_keys=False), end="", highlight=False)
