"""Deterministic enforcement helpers."""
