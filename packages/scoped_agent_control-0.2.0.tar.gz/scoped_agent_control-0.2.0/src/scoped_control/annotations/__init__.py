"""Annotation parsing and scanning."""
