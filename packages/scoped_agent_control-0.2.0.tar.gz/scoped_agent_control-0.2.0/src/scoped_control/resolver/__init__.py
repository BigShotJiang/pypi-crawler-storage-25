"""Scope resolution helpers."""
