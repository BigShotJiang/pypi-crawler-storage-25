"""Index persistence helpers."""
