"""Executor adapters."""
