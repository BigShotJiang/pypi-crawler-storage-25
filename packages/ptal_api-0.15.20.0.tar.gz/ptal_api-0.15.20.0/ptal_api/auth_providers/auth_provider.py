from abc import ABC, abstractmethod

from httpx import Headers


class AuthProvider(ABC):
    """Abstract base class for authentication providers."""

    @abstractmethod
    async def get_auth_headers(self) -> Headers:
        """Return authentication headers."""
        ...
