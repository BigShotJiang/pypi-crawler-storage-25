import logging
import time
from typing import cast

from httpx import Headers
from keycloak import KeycloakOpenID

from .auth_provider import AuthProvider


class KeycloakAuthProvider(AuthProvider):
    """Provides authentication headers using Keycloak OpenID Connect tokens."""

    _TIME_OFFSET = 10  # in seconds

    def __init__(
        self,
        auth_url: str,
        realm: str,
        client_id: str,
        client_secret: str,
        user: str,
        password: str,
    ) -> None:
        """
        Args:
            auth_url: Base URL of the Keycloak authentication server.
            realm: Name of the realm to which the client belongs.
            client_id: Identifier of the OAuth client.
            client_secret: Secret associated with the client identifier.
            user: Username for resource-owner password credentials flow.
            password: Password for the specified user.

        Returns:
            None

        """
        self._auth_url = auth_url
        self._realm = realm
        self._client_id = client_id
        self._client_secret = client_secret
        self._user = user
        self._password = password

        self._logger = logging.getLogger(__name__)
        self._keycloak_openid = KeycloakOpenID(self._auth_url, self._realm, self._client_id, self._client_secret)

        self._access_token: str | None = None
        self._refresh_token: str | None = None
        self._access_expiration_timestamp: float | None = None
        self._refresh_expiration_timestamp: float | None = None

    async def get_auth_headers(self) -> Headers:
        """Return authentication headers."""
        await self._ensure_session_liveness()
        return Headers({"X-Auth-Token": cast(str, self._access_token), "Authorization": f"Bearer {self._access_token}"})

    async def _ensure_session_liveness(self) -> None:
        offsetted_time = time.time() + self._TIME_OFFSET
        if self._access_expiration_timestamp is not None and offsetted_time < self._access_expiration_timestamp:
            return

        time_before_req = time.time()

        if self._refresh_expiration_timestamp is not None and offsetted_time < self._refresh_expiration_timestamp:
            self._logger.info("refreshing access token with refresh token")
            token_info = await self._keycloak_openid.a_refresh_token(cast(str, self._refresh_token))
        else:
            self._logger.info("refreshing access token with credentials")
            token_info = await self._keycloak_openid.a_token(self._user, self._password)

        self._access_token = token_info["access_token"]
        self._access_expiration_timestamp = time_before_req + token_info["expires_in"]
        self._refresh_token = token_info["refresh_token"]
        self._refresh_expiration_timestamp = time_before_req + token_info["refresh_expires_in"]
