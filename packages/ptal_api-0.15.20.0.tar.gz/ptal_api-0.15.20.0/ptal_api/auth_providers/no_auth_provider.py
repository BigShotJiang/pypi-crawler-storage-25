from httpx import Headers

from .auth_provider import AuthProvider


class NoAuthProvider(AuthProvider):
    """Simple empty auth headers provider."""

    async def get_auth_headers(self) -> Headers:
        """Return authentication headers."""
        return Headers({})
