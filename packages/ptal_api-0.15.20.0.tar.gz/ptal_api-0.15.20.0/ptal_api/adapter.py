import logging
from collections.abc import AsyncGenerator, Iterable, Sequence
from copy import copy

# from functools import wraps
from time import time

from ptal_api.schemas.mesh_schema import (
    DocumentFilterSettings,
    DocumentGrouping,
    DocumentNodeUpdateInput,
    DocumentSorting,
    ExtraSettings,
    LanguageInput,
    LanguageUpdateInput,
    SortDirection,
    TimestampInterval,
    TranslationInput,
)
from ptal_api.schemas.mesh_schema.custom_fields import (
    AccessLevelFields,
    AccountFields,
    CompositeValueFields,
    ConceptCandidateFactFields,
    ConceptFactFields,
    ConceptFields,
    ConceptPropertyCandidateFactFields,
    ConceptPropertyValueCandidateFactFields,
    ConceptTypeFields,
    CoordinatesFields,
    DateFields,
    DateTimeValueFields,
    DocumentFields,
    DocumentMetadataFields,
    DoubleValueFields,
    FlatDocumentStructureFields,
    GeoPointValueFields,
    IntValueFields,
    LanguageFields,
    LinkValueFields,
    NamedValueFields,
    NodeMentionFields,
    ParagraphMetadataFields,
    PlatformFields,
    StoryPaginationFields,
    StringLocaleValueFields,
    StringValueFields,
    TimeFields,
    TimestampValueFields,
    UserFields,
)
from ptal_api.schemas.mesh_schema.custom_mutations import Mutation
from ptal_api.schemas.mesh_schema.custom_queries import Query
from ptal_api.schemas.mesh_schema.custom_typing_fields import AnyValueUnion, ValueUnion
from ptal_api.schemas.system_utils_schema.custom_queries import Query as SystemUtilsQuery

# from sgqlc.operation import Fragment
from .client import Client
from .kb_iterator_config import KBIteratorConfig

# from .core.kb_sync.object_time_interval import ObjectTimeInterval
# from .core.query_factory import make_operation
# from .core.type_mapper.data_model.base_data_model import TypeMapping
# from .core.type_mapper.modules.type_mapping_loader.type_mapping_loader import TypeMappingLoader
# from .core.type_mapper.modules.type_mapping_loader.type_mapping_loader_interface import TypeMappingLoaderInterface
# from .core.values.value_mapping import get_map_helper
# from .pretty_adapter import object_types, objects
# from .pretty_adapter.transformer import prettify
# from .schema import tcontroller_api_schema as tc
# from .schema import translator_api_schema as ts
# from .schema import utils_api_schema as uas
# from .schema.api_schema import (
#     Account,
#     AccountFilterSettings,
#     AccountPagination,
#     AccountUpdateInput,
#     ComponentValueInput,
#     CompositePropertyTypeFilterSettings,
#     CompositePropertyTypeSorting,
#     CompositePropertyValueTemplate,
#     CompositePropertyValueType,
#     CompositeValue,
#     Concept,
#     ConceptCandidateFact,
#     ConceptFact,
#     ConceptFactPagination,
#     ConceptFilterSettings,
#     ConceptLink,
#     ConceptLinkCreationMutationInput,
#     ConceptLinkFilterSettings,
#     ConceptLinkPagination,
#     ConceptLinkPropertyInput,
#     ConceptLinkPropertyTypeCreationInput,
#     ConceptLinkPropertyTypeUpdateInput,
#     ConceptLinkType,
#     ConceptLinkTypeFilterSettings,
#     ConceptLinkTypePagination,
#     ConceptLinkTypeSorting,
#     ConceptLinkUpdateMutationInput,
#     ConceptMergeInput,
#     ConceptMutationInput,
#     ConceptPagination,
#     ConceptPresentation,
#     ConceptPresentationWidgetRowPagination,
#     ConceptProperty,
#     ConceptPropertyCandidateFact,
#     ConceptPropertyCreateInput,
#     ConceptPropertyFilterSettings,
#     ConceptPropertyPagination,
#     ConceptPropertyType,
#     ConceptPropertyTypeCreationInput,
#     ConceptPropertyTypeFilterSettings,
#     ConceptPropertyTypePagination,
#     ConceptPropertyTypeSorting,
#     ConceptPropertyUpdateInput,
#     ConceptPropertyValueType,
#     ConceptPropertyValueTypeFilterSettings,
#     ConceptPropertyValueTypePagination,
#     ConceptPropertyValueTypeSorting,
#     ConceptPropertyValueTypeUpdateInput,
#     ConceptSorting,
#     ConceptType,
#     ConceptTypeFilterSettings,
#     ConceptTypePagination,
#     ConceptTypeSorting,
#     ConceptUnmergeInput,
#     ConceptUpdateInput,
#     CoordinatesInput,
#     DateInput,
#     DateTimeInput,
#     DateTimeValue,
#     Document,
#     DocumentFilterSettings,
#     DocumentGrouping,
#     DocumentNodeUpdateInput,
#     DocumentPagination,
#     DocumentSorting,
#     DoubleValue,
#     DoubleValueInput,
#     ExtraSettings,
#     FactInput,
#     GeoPointInput,
#     GeoPointValue,
#     IntValue,
#     IntValueInput,
#     LanguageInput,
#     LanguageUpdateInput,
#     LinkedDocumentFilterSettings,
#     LinkValue,
#     LinkValueInput,
#     Mutation,
#     NodeMention,
#     PerformSynchronously,
#     Platform,
#     PlatformFilterSettings,
#     PlatformPagination,
#     PlatformSorting,
#     PlatformUpdateInput,
#     PropertyFilterSettings,
#     Query,
#     SortDirection,
#     State,
#     Story,
#     StoryPagination,
#     StringLocaleValue,
#     StringLocaleValueInput,
#     StringValue,
#     StringValueInput,
#     TimeInput,
#     TimestampValue,
#     TimestampValueInput,
#     TranslationInput,
#     ValueInput,
#     StringFilterInput,
#     TimestampIntervalInput,
# )
# from .schema.auth_api_schema import User
# from .schema.crawlers_api_schema import Crawler, CrawlerPagination
# from .schema.crawlers_api_schema import Query as CrQuery
# from .tdm_builder.tdm_builder import AbstractTdmBuilder

logger = logging.getLogger(__name__)


# def check_utils_gql_client(f):
#     @wraps(f)
#     def wrapper(self: "TalismanAPIAdapter", *args, **kwargs):
#         if self._utils_gql_client is None:
#             raise Exception("Utils methods cannot be used because the corresponding gql_client is not specified.")
#         return f(self, *args, **kwargs)
#
#     return wrapper


class NoUtilsGQLClientError(Exception):
    """Indicate query or mutation is not possible without utils gql client."""


class TalismanAPIAdapter:
    """Adapter that encapsulates communication with the Talisman GraphQL API."""

    def __init__(
        self,
        gql_client: Client,
        # type_mapping: Optional[Union[str, dict, TypeMapping]] = None,
        # type_mapping_loader: Optional[TypeMappingLoaderInterface] = None,
        utils_gql_client: Client | None = None,
        kb_iterator_config: KBIteratorConfig | None = None,
        limit: int = 100,
        *,
        perform_synchronously: bool = True,
        prettify_output: bool = False,
    ) -> None:
        """
        Parameters
        ----------
        gql_client : Client
            GraphQL client used for primary operations.
        utils_gql_client : Client | None, optional
            Secondary GraphQL client for utility queries.
        kb_iterator_config : KBIteratorConfig | None, optional
            Configuration for knowledge-base iterator; defaults to a preset config.
        limit : int, optional
            Maximum number of items to retrieve per request; defaults to 100.

        Keyword Arguments
        -----------------
        perform_synchronously : bool, optional
            Determines whether requests are executed synchronously; defaults to True.
        prettify_output : bool, optional
            If True, output JSON is formatted for readability; defaults to False.

        Returns
        -------
        None

        """
        self._gql_client = gql_client
        self._utils_gql_client = utils_gql_client
        # self._type_mapping_loader = type_mapping_loader if type_mapping_loader else TypeMappingLoader(logger)
        # self._type_mapping = self._type_mapping_loader.load_type_mapping(type_mapping)
        self._limit = limit
        self._perform_synchronously = perform_synchronously
        self.prettify_output = prettify_output

        self.document_fields_truncated = (
            DocumentFields.id,
            DocumentFields.external_url,
            DocumentFields.uuid,
        )
        self.document_fields = (
            *self.document_fields_truncated,
            DocumentFields.title,
            DocumentFields.publication_author,
            DocumentFields.publication_date,
            DocumentFields.internal_url,
            DocumentFields.markers,
            DocumentFields.system_registration_date,
            DocumentFields.system_update_date,
            DocumentFields.notes,
            DocumentFields.access_level().fields(
                AccessLevelFields.id,
                AccessLevelFields.name,
                AccessLevelFields.order,
            ),
            DocumentFields.trust_level,
        )
        self.document_text_fields = (
            FlatDocumentStructureFields.node_id,
            FlatDocumentStructureFields.text,
        )
        self.document_additional_text_fields = (
            FlatDocumentStructureFields.node_id,
            FlatDocumentStructureFields.text,
        )
        self.document_text_metadata_fields = (ParagraphMetadataFields.paragraph_type,)
        self.document_platform_fields = (
            PlatformFields.id,
            PlatformFields.name,
        )
        self.document_account_fields = (
            AccountFields.id,
            AccountFields.name,
        )

        self.translation_node_mention_fields = (
            NodeMentionFields.id,
            NodeMentionFields.node_id,
        )

        self.user_fields = (UserFields.id,)

        self.concept_fields = (
            "id",
            "name",
            "notes",
            "markers",
            "system_registration_date",
            "system_update_date",
        )
        self.concept_type_fields = (ConceptTypeFields.id, ConceptTypeFields.name)

        self.concept_property_fields = ("id", "is_main", "status", "system_registration_date")
        self.concept_property_type_fields = ("id", "name")
        self.cpvt_fields_truncated = ("id", "name", "value_type")
        self.cpvt_fields = ("id", "name", "value_type", "value_restriction", "pretrained_nercmodels")

        self.composite_property_value_template_fields = ("id", "name")
        self.component_value_types_fields = ("id", "name")

        self.concept_link_fields = ("id", "notes")
        self.concept_link_type_fields = ("id", "name", "is_directed", "is_hierarchical")
        self.concept_link_type_fields_truncated = ("id", "name", "is_directed")

        self.concept_fact_fields = (ConceptFactFields.id,)
        self.concept_candidate_fact_fields = (ConceptCandidateFactFields.id,)
        self.concept_candidate_fact_property_fields = (ConceptPropertyCandidateFactFields.id,)
        self.concept_candidate_fact_property_value_fields = (ConceptPropertyValueCandidateFactFields.id,)

        self.concept_presentation_widget_type = ("id", "name")
        self.concept_presentation_widget_type_columns_info = ("name",)

        self.date_time_value_date_fields = (DateFields.year, DateFields.month, DateFields.day)
        self.date_time_value_time_fields = (TimeFields.hour, TimeFields.minute, TimeFields.second)
        self.geo_point_value_point_fields = (CoordinatesFields.latitude, CoordinatesFields.longitude)

        self.platform_fields = ("id", "name", "platform_type", "url", "country", "language", "markers", "params")
        self.account_fields = ("id", "name", "url", "country", "markers", "params")

        self.pipeline_config_fields = ("id", "description")

        self.pipeline_topic_fields = ("topic", "description", "stopped", "metrics", "pipeline")
        self.pipeline_metrics_fields = ("duplicate", "failed", "messages", "ok")

        self.kb_iterator_config = kb_iterator_config or KBIteratorConfig()

    # @property
    # def prettify_output(self) -> bool:
    #     return self._prettify_output

    # @prettify_output.setter
    # def prettify_output(self, value: bool) -> None:
    #     self._prettify_output = value

    # @property
    # def type_mapping(self):
    #     return self._type_mapping

    # @type_mapping.setter
    # def type_mapping(self, new_type_mapping: TypeMapping):
    #     self._type_mapping = new_type_mapping

    # @property
    # def limit(self) -> int:
    #     return self._limit
    #
    # @limit.setter
    # def limit(self, new_limit: int) -> None:
    #     self._limit = new_limit
    #
    # @property
    # def perform_synchronously(self) -> bool:
    #     return self._perform_synchronously
    #
    # @perform_synchronously.setter
    # def perform_synchronously(self, new_perform_synchronously: bool) -> None:
    #     self._perform_synchronously = new_perform_synchronously
    #
    def get_take_value(self, take: int | None) -> int:
        """Return ``take`` or adapter's limit."""
        return self._limit if take is None else take

    # def get_perform_synchronously_value(self, *, perform_synchronously: bool | None) -> bool:
    #     return self.perform_synchronously if perform_synchronously is None else perform_synchronously

    def __value_fragment[T: (ValueUnion, AnyValueUnion)](self, graphql_value: T) -> T:
        # TODO: delete ignoring ty as https://github.com/astral-sh/ty/issues/1503 resolved
        graphql_value.on(  # ty: ignore[invalid-argument-type]
            "DateTimeValue",
            DateTimeValueFields.date().fields(*self.date_time_value_date_fields),
            DateTimeValueFields.time().fields(*self.date_time_value_time_fields),
        ).on(
            "TimestampValue",
            TimestampValueFields.value.alias("unixtime"),
        ).on("StringLocaleValue", StringLocaleValueFields.value, StringLocaleValueFields.locale).on(
            "StringValue",
            StringValueFields.value,
        ).on(
            "LinkValue",
            LinkValueFields.link,
        ).on(
            "DoubleValue",
            DoubleValueFields.value.alias("double"),
        ).on(
            "IntValue",
            IntValueFields.value.alias("number"),
        ).on(
            "GeoPointValue",
            GeoPointValueFields.name.alias("geo_name"),
            GeoPointValueFields.point().fields(*self.geo_point_value_point_fields),
        )
        return graphql_value

    def _configure_output_value_fields(
        self, graphql_value: ValueUnion, *, with_composite_values: bool = False, with_object_values: bool = False
    ) -> None:
        self.__value_fragment(graphql_value)

        if with_composite_values:
            graphql_value.on(
                "CompositeValue",
                CompositeValueFields.list_value().fields(
                    NamedValueFields.id,
                    NamedValueFields.property_value_type(),
                    self.__value_fragment(NamedValueFields.value),
                ),
            )

        if with_object_values:
            graphql_value.on(
                "User",
                UserFields.login,
                UserFields.first_name,
                UserFields.last_name,
            ).on(
                "Concept",
                ConceptFields.id,
                ConceptFields.name,
            ).on(
                "ConceptType",
                *self.concept_type_fields,
            )

    def _configure_output_concept_candidate_fact_fields(
        self, document_object: DocumentFields, *, with_candidate_fact_properties: bool = False
    ) -> None:
        document_object.fields(
            document_object.list_fact.on(
                "ConceptCandidateFact",
                ConceptCandidateFactFields("listFact").fields(*self.concept_candidate_fact_fields),
                ConceptCandidateFactFields("listFact").fields(
                    ConceptCandidateFactFields.concept_type().fields(*self.concept_type_fields)
                ),
                ConceptCandidateFactFields("listFact").fields(ConceptCandidateFactFields.list_concept()),
            )
        )

        if with_candidate_fact_properties:
            document_object.fields(
                document_object.list_fact.on(
                    "ConceptPropertyCandidateFact",
                    ConceptPropertyCandidateFactFields("listFact").fields(*self.concept_candidate_fact_property_fields),
                    ConceptPropertyCandidateFactFields("listFact").fields(
                        ConceptPropertyCandidateFactFields.fact_from.on(
                            "ConceptCandidateFact",
                            ConceptCandidateFactFields.id,
                        )
                    ),
                    ConceptPropertyCandidateFactFields.fact_to().fields(
                        *self.concept_candidate_fact_property_value_fields
                    ),
                )
            )

            self._configure_output_value_fields(ConceptPropertyCandidateFactFields.fact_to().meanings().value)

    def _configure_output_document_fields(
        self,
        doc_object: DocumentFields,
        *,
        with_extended_information: bool = False,
        with_text: bool = False,
        with_text_metadata: bool = False,
        with_additional_text: bool = False,
        with_translation_mentions: bool = False,
        with_updater: bool = False,
        with_creator: bool = False,
        with_facts: bool = False,
        with_candidate_facts: bool = False,
        with_candidate_fact_properties: bool = False,
        with_children: bool = False,
    ) -> None:
        if with_extended_information:
            metadata = doc_object.metadata()
            metadata.fields(
                DocumentMetadataFields.platform().fields(*self.document_platform_fields),
                DocumentMetadataFields.account().fields(*self.document_account_fields),
            )
            doc_object.fields(*self.document_fields, metadata)
        else:
            doc_object.fields(*self.document_fields_truncated)
        if with_text:
            doc_text = doc_object.text(show_hidden=True)
            doc_text.fields(*self.document_text_fields)
            if with_text_metadata:
                doc_text.fields(doc_text.metadata().fields(*self.document_text_metadata_fields))
            if with_translation_mentions:
                doc_text.fields(
                    doc_text.translation_mention.on(
                        "NodeMention",
                        *self.translation_node_mention_fields,
                    )
                )
            doc_object.fields(doc_text)
        if with_additional_text:
            doc_additional_text = doc_object.additional_text(show_hidden=True)
            doc_additional_text.fields(*self.document_additional_text_fields)
            doc_additional_text.fields(FlatDocumentStructureFields.language().fields(LanguageFields.id))
            doc_object.fields(doc_additional_text)
        if with_updater:
            doc_object.fields(doc_object.last_updater().fields(*self.user_fields))
        if with_creator:
            doc_object.fields(doc_object.creator().fields(*self.user_fields))
        if with_facts:
            doc_object.fields(doc_object.list_concept_fact().fields(*self.concept_fact_fields))
        if with_candidate_facts:
            self._configure_output_concept_candidate_fact_fields(
                document_object=doc_object,
                with_candidate_fact_properties=with_candidate_fact_properties,
            )
        if with_children:
            list_child = doc_object.list_child()
            self._configure_output_document_fields(
                list_child,
                with_extended_information=with_extended_information,
                with_text=with_text,
                with_text_metadata=with_text_metadata,
                with_additional_text=with_additional_text,
                with_translation_mentions=with_translation_mentions,
                with_updater=with_updater,
                with_creator=with_creator,
            )
            doc_object.fields(list_child)

    async def get_documents_count(self, filter_settings: DocumentFilterSettings | None = None) -> int:
        """
        Retrieve the total number of documents that match optional filter criteria.

        Args:
            filter_settings: DocumentFilterSettings | None, optional
                Settings used to filter which documents are counted. If omitted,
                all documents are considered.

        Returns:
            int
                The total count of documents as reported by the backend pagination
                query.

        """
        query = Query.pagination_story(
            limit=1,
            filter_settings=filter_settings,
            extra_settings=ExtraSettings(),
        ).fields(StoryPaginationFields.show_total)
        response = await self._gql_client.query(query, operation_name="get_documents_count")
        return response["paginationStory"]["showTotal"]

    async def get_all_documents(
        self,
        grouping: DocumentGrouping = DocumentGrouping.none,
        filter_settings: DocumentFilterSettings | None = None,
        direction: SortDirection = SortDirection.descending,
        sort_field: DocumentSorting = DocumentSorting.title,
        extra_settings: ExtraSettings | None = None,
        *,
        with_extended_information: bool = False,
        with_text: bool = False,
        with_text_metadata: bool = False,
        with_additional_text: bool = False,
        with_translation_mentions: bool = False,
        with_updater: bool = False,
        with_creator: bool = False,
        with_facts: bool = False,
        with_candidate_facts: bool = False,
        with_candidate_fact_properties: bool = False,
        with_children: bool = False,
    ) -> AsyncGenerator:  # TODO: make pydantic class as return value
        """
        Retrieve all documents that match the given criteria, handling large result sets
        by recursively partitioning the registration date interval when the total number
        of matching documents exceeds the configured maximum.

        Parameters
        ----------
        grouping : DocumentGrouping
            Determines how documents are grouped in the result set.
        filter_settings : DocumentFilterSettings | None, optional
            Settings used to filter documents; a default instance is created when None.
        direction : SortDirection, optional
            Sort direction to apply to the result set.
        sort_field : DocumentSorting, optional
            Field used for sorting the documents.
        extra_settings : ExtraSettings | None, optional
            Additional configuration that influences document retrieval.
        with_extended_information : bool, optional
            When True, include extended information for each document.
        with_text : bool, optional
            When True, include the main text content of each document.
        with_text_metadata : bool, optional
            When True, include metadata associated with the document text.
        with_additional_text : bool, optional
            When True, include any additional text attached to the document.
        with_translation_mentions : bool, optional
            When True, include translation mention details.
        with_updater : bool, optional
            When True, include information about the user who last updated the
            document.
        with_creator : bool, optional
            When True, include information about the document's creator.
        with_facts : bool, optional
            When True, include factual data extracted from the document.
        with_candidate_facts : bool, optional
            When True, include candidate facts that have not been confirmed.
        with_candidate_fact_properties : bool, optional
            When True, include properties of candidate facts.
        with_children : bool, optional
            When True, include child documents related to each returned document.

        Yields
        ------
        document
            Documents that satisfy the supplied filters and sorting criteria.  The
            exact type is defined elsewhere; the generator yields one document per
            iteration.

        """
        if filter_settings is None:
            filter_settings = DocumentFilterSettings()
        if extra_settings is None:
            extra_settings = ExtraSettings()

        total = await self.get_documents_count(filter_settings=filter_settings)

        if total > self.kb_iterator_config.max_total_count:
            had_creation_date = filter_settings.registration_date
            old_timestamp_interval = None
            if had_creation_date:
                old_timestamp_interval = copy(filter_settings.registration_date)
            start: int = getattr(old_timestamp_interval, "start", self.kb_iterator_config.earliest_created_time)
            end: int = getattr(old_timestamp_interval, "end", int(time()))
            middle: int = (end + start) // 2

            for next_start, next_end in (start, middle), (middle + 1, end):
                if next_start == start and next_end == end:
                    logger.info(
                        f"Processed only {self.kb_iterator_config.max_total_count} documents, "
                        f"{total - self.kb_iterator_config.max_total_count} ignored"
                    )
                    continue
                filter_settings.registration_date = TimestampInterval(start=next_start, end=next_end)
                async for document in self.get_all_documents(
                    grouping=grouping,
                    filter_settings=filter_settings,
                    direction=direction,
                    sort_field=sort_field,
                    extra_settings=extra_settings,
                    with_extended_information=with_extended_information,
                    with_text=with_text,
                    with_text_metadata=with_text_metadata,
                    with_additional_text=with_additional_text,
                    with_translation_mentions=with_translation_mentions,
                    with_updater=with_updater,
                    with_creator=with_creator,
                    with_facts=with_facts,
                    with_candidate_facts=with_candidate_facts,
                    with_candidate_fact_properties=with_candidate_fact_properties,
                    with_children=with_children,
                ):
                    yield document

            if had_creation_date:
                filter_settings.registration_date = old_timestamp_interval
            else:
                filter_settings.registration_date = None
            return
        elif not total:
            return

        documents: Iterable = [None]
        i: int = 0
        while documents:
            documents = await self.get_documents(
                skip=i * self._limit,
                take=self._limit,
                grouping=grouping,
                filter_settings=filter_settings,
                direction=direction,
                sort_field=sort_field,
                extra_settings=extra_settings,
                with_extended_information=with_extended_information,
                with_text=with_text,
                with_text_metadata=with_text_metadata,
                with_additional_text=with_additional_text,
                with_translation_mentions=with_translation_mentions,
                with_updater=with_updater,
                with_creator=with_creator,
                with_facts=with_facts,
                with_candidate_facts=with_candidate_facts,
                with_candidate_fact_properties=with_candidate_fact_properties,
                with_children=with_children,
            )
            for document in documents:
                yield document
            i += 1

    async def get_documents(
        self,
        skip: int = 0,
        take: int | None = None,
        grouping: DocumentGrouping = DocumentGrouping.none,
        filter_settings: DocumentFilterSettings | None = None,
        direction: SortDirection = SortDirection.descending,
        sort_field: DocumentSorting = DocumentSorting.title,
        extra_settings: ExtraSettings | None = None,
        *,
        with_extended_information: bool = False,
        with_text: bool = False,
        with_text_metadata: bool = False,
        with_additional_text: bool = False,
        with_translation_mentions: bool = False,
        with_updater: bool = False,
        with_creator: bool = False,
        with_facts: bool = False,
        with_candidate_facts: bool = False,
        with_candidate_fact_properties: bool = False,
        with_children: bool = False,
    ) -> Sequence:  # TODO: make pydantic class
        """
        Retrieve a paginated collection of documents with optional filtering,
        grouping, sorting, and extended field inclusion.

        Args:
            skip: Number of items to skip before starting to collect results.
            take: Maximum number of items to return. If ``None``, a default limit
                based on client settings is applied.
            grouping: Determines how documents are grouped in the result.
            filter_settings: Settings used to filter the documents. If omitted,
                a default ``DocumentFilterSettings`` instance is used.
            direction: Sort direction applied to the result set.
            sort_field: Field used for sorting documents.
            extra_settings: Additional pagination settings. If omitted, a default
                ``ExtraSettings`` instance is used.

        Keyword Args:
            with_extended_information: Include extended information fields in the
                main document.
            with_text: Include the primary text content of the main document.
            with_text_metadata: Include metadata associated with the document text.
            with_additional_text: Include any additional text attached to the
                document.
            with_translation_mentions: Include translation mention data.
            with_updater: Include information about the last updater of the document.
            with_creator: Include information about the creator of the document.
            with_facts: Include factual data linked to the document.
            with_candidate_facts: Include candidate facts associated with the
                document.
            with_candidate_fact_properties: Include properties of candidate facts.
            with_children: Include child documents related to the main document.

        Returns:
            A sequence containing the list of documents retrieved from the GraphQL
            ``paginationStory`` query.

        """
        take = self.get_take_value(take)
        if filter_settings is None:
            filter_settings = DocumentFilterSettings()
        if extra_settings is None:
            extra_settings = ExtraSettings()

        pagination_story = Query.pagination_story(
            extra_settings=extra_settings,
            direction=direction,
            filter_settings=filter_settings,
            grouping=grouping,
            limit=take,
            offset=skip,
            sort_field=sort_field,
        )

        list_document = pagination_story.list_story().list_document()
        self._configure_output_document_fields(list_document)

        main_document = pagination_story.list_story().main()
        self._configure_output_document_fields(
            main_document,
            with_extended_information=with_extended_information,
            with_text=with_text,
            with_text_metadata=with_text_metadata,
            with_additional_text=with_additional_text,
            with_translation_mentions=with_translation_mentions,
            with_updater=with_updater,
            with_creator=with_creator,
            with_facts=with_facts,
            with_candidate_facts=with_candidate_facts,
            with_candidate_fact_properties=with_candidate_fact_properties,
            with_children=with_children,
        )

        pagination_story.fields(pagination_story.list_story().fields(list_document, main_document))

        response = await self._gql_client.query(pagination_story, operation_name="get_documents")
        return response["paginationStory"]["listStory"]

    async def get_document(
        self,
        document_id: str,
        *,
        with_candidate_facts: bool = False,
        with_candidate_fact_properties: bool = False,
    ) -> dict:
        """
        Retrieve a single document by its identifier, optionally including extended
        information such as candidate facts and their properties.

        Args:
            document_id: Identifier of the document to retrieve.

        Keyword Args:
            with_candidate_facts: Include candidate facts in the document payload when
                set to True. Defaults to False.
            with_candidate_fact_properties: Include properties of candidate facts when
                set to True. Defaults to False.

        Returns:
            dict: The document data returned by the GraphQL service.

        """
        document = Query.document(id=document_id)

        self._configure_output_document_fields(
            document,
            with_extended_information=True,
            with_text=True,
            with_text_metadata=True,
            with_additional_text=True,
            with_translation_mentions=True,
            with_updater=True,
            with_creator=True,
            with_facts=True,
            with_candidate_facts=with_candidate_facts,
            with_candidate_fact_properties=with_candidate_fact_properties,
            with_children=True,
        )
        response = await self._gql_client.query(document, operation_name="get_document")
        return response["document"]

    async def update_document_node(
        self, document_id: str, node_id: str, target: str, translation: str, source: str | None = None
    ) -> dict:
        """
        Update a specific node within a document by applying a translation.

        Args:
            document_id: Identifier of the document containing the node.
            node_id: Identifier of the node to be updated.
            target: Language identifier for the translation target.
            translation: Text to set for the target language.
            source: Optional language identifier of the source text.

        Returns:
            dict: The response payload from the GraphQL server for the
            ``updateDocumentNode`` mutation, containing the fields configured by
            ``_configure_output_document_fields``.

        """
        update_document_node = Mutation.update_document_node(
            form=DocumentNodeUpdateInput(
                id=document_id,
                nodeId=node_id,
                language=LanguageUpdateInput(id=source),
                translation=TranslationInput(language=LanguageInput(id=target), text=translation),
            )
        )
        self._configure_output_document_fields(update_document_node)

        response = await self._gql_client.mutation(update_document_node, operation_name="update_document_node")
        return response["updateDocumentNode"]

    async def get_new_tdm(self, doc_id: str) -> str:
        """
        Retrieve a fresh TDM identifier for the given document.

        Args:
            doc_id: The identifier of the document for which a new TDM is requested.

        Returns:
            str
                The newly generated TDM string.

        """
        if self._utils_gql_client is None:
            raise NoUtilsGQLClientError
        response = await self._utils_gql_client.query(
            SystemUtilsQuery.tdm_new_internal(id=doc_id), operation_name="get_new_tdm"
        )
        return response["tdmNewInternal"]

    async def translate_str(self, text: str, target: str, source: str | None = None) -> str:
        """
        Translate a piece of text using the configured GraphQL translation service.

        Args:
            text:
                The text to be translated.
            target:
                The target language code.
            source:
                Optional source language code.  If omitted, the service may attempt to
                detect the source language automatically.

        Returns:
            The translated string obtained from the GraphQL response.

        """
        translate_str = Query.translate_str(text=text, target=target, source=source)
        response = await self._gql_client.query(translate_str, operation_name="translate_str")
        return response["translateStr"]
