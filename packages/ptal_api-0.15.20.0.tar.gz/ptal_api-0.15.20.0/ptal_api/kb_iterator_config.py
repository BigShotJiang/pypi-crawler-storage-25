from dataclasses import dataclass


@dataclass
class KBIteratorConfig:
    """
    KBIteratorConfig encapsulates the parameters that control how many items the
    iterator will return overall and the earliest creation timestamp that an
    item must have to be considered.

    Attributes
    ----------
        max_total_count
            Upper bound on the total number of items the iterator may yield.
            The default value is 1000.

        earliest_created_time
            Unix timestamp that specifies the earliest creation time an item
            must have to be included.  The default corresponds to Fri Jan 01
            2021 00:00:00 GMT+0300.

    """

    max_total_count: int = 1000
    earliest_created_time: int = 1609448400  # Fri Jan 01 2021 00:00:00 GMT+0300
