from typing import Dict, Any, Optional
from pydantic import BaseModel, Field, model_validator, field_validator, SecretStr
from google.genai import types as adk_types
from solace_agent_mesh.agent.tools.dynamic_tool import DynamicTool
from solace_agent_mesh.agent.sac.component import SamAgentComponent
from .services.database_service import DatabaseService
from .services.connection_validator import validate_connection_string

import logging
log = logging.getLogger(__name__)

class DatabaseConfig(BaseModel):
    tool_name: str = Field(
        description="The name of the tool as it will be invoked by the LLM."
    )
    tool_description: Optional[str] = Field(
        default="", description="A description of what the tool does."
    )
    connection_string: SecretStr = Field(
        description="The full database connection string (e.g., 'postgresql+psycopg2://user:password@host:port/dbname')."
    )
    auto_detect_schema: bool = Field(
        default=True,
        description="If true, automatically detect schema. If false, overrides must be provided.",
    )
    schema_summary_override: Optional[str] = Field(
        default=None,
        description="Natural language summary of the schema if auto_detect_schema is false.",
    )
    max_enum_cardinality: int = Field(
        default=100,
        description="Maximum number of distinct values to consider a column as an enum (default: 100).",
    )
    schema_sample_size: int = Field(
        default=100,
        description="Number of rows to sample per table for schema detection (default: 100).",
    )
    cache_ttl_seconds: int = Field(
        default=3600,
        description="Time-to-live for schema cache in seconds (default: 3600 = 1 hour).",
    )

    # Connection pool settings
    pool_size: int = Field(
        default=10,
        description="Number of persistent connections to maintain in the pool (default: 10).",
    )
    max_overflow: int = Field(
        default=10,
        description="Maximum temporary connections allowed beyond pool_size during traffic spikes (default: 10).",
    )
    pool_timeout: int = Field(
        default=30,
        description="Seconds to wait for a pool connection before raising TimeoutError (default: 30).",
    )
    pool_recycle: int = Field(
        default=1800,
        description=(
            "Recycle connections after this many seconds to prevent stale connections. "
            "Set below your database's idle timeout (default: 1800). Use -1 to disable."
        ),
    )
    pool_pre_ping: bool = Field(
        default=True,
        description="Test connections for liveness before use. Disable only to improve performance on reliable networks (default: true).",
    )

    # Engine-level settings
    connect_args: Dict[str, Any] = Field(
        default_factory=dict,
        description=(
            "Extra keyword arguments passed directly to the database driver's connect() call. "
            "Use for SSL certificates, driver-specific timeouts, charsets, etc."
        ),
    )
    isolation_level: Optional[str] = Field(
        default=None,
        description=(
            "Transaction isolation level: 'READ_COMMITTED', 'SERIALIZABLE', 'AUTOCOMMIT', etc. "
            "Defaults to the database dialect's default if not set."
        ),
    )
    echo: bool = Field(
        default=False,
        description="Log all SQL statements to the Python logger. Enable for development/troubleshooting only (default: false).",
    )

    @field_validator('connection_string', mode='before')
    @classmethod
    def validate_connection_string_format(cls, v: str) -> str:
        """Validate connection string format before converting to SecretStr."""
        validate_connection_string(v)
        return v

    @model_validator(mode='after')
    def check_required_fields(self) -> 'DatabaseConfig':
        if self.auto_detect_schema is False:
            if self.schema_summary_override is None:
                raise ValueError(
                    "'schema_summary_override' is required when 'auto_detect_schema' is false"
                )
        return self
    
    def get(self, key: str, default: Any = None) -> Any:
        """Allows dictionary-like access to the model's attributes."""
        return getattr(self, key, default)

class SqlDatabaseTool(DynamicTool):
    config_model = DatabaseConfig

    def __init__(self, tool_config: DatabaseConfig):
        super().__init__(tool_config)
        self.db_service: Optional[DatabaseService] = None
        self._schema_context: Optional[str] = None
        self._connection_healthy: bool = False
        self._connection_error: Optional[str] = None
        self.description = self.tool_description

    @property
    def tool_name(self) -> str:
        """Return the function name that the LLM will call."""
        return self.tool_config.get("tool_name", "unnamed_sql_database_tool")

    @property
    def tool_description(self) -> str:
        """Return the description of what this tool does, including schema context."""
        base_description = self.tool_config.get("tool_description", "")

        if not self._connection_healthy:
            status_message = "\n\n❌ WARNING: This database is currently UNAVAILABLE.\n"
            if self._connection_error:
                status_message += f"Connection Error: {self._connection_error}\n"
            status_message += "Queries to this database will fail until connectivity is restored."
            return f"{base_description}{status_message}"

        if self._schema_context:
            return f"{base_description}\n\n✅ Database Connected\n\nDatabase Schema:\n{self._schema_context}"

        return base_description

    @property
    def parameters_schema(self) -> adk_types.Schema:
        return adk_types.Schema(
            type=adk_types.Type.OBJECT,
            properties={
                "query": adk_types.Schema(
                    type=adk_types.Type.STRING,
                    description="The SQL query to execute."
                ),
            },
            required=["query"],
        )

    async def init(self, component: SamAgentComponent, tool_config: Dict):
        log_identifier = f"[{self.tool_name}:init]"
        log.info("%s Initializing connection...", log_identifier)

        connection_string = self.tool_config.connection_string.get_secret_value()
        cache_ttl = self.tool_config.cache_ttl_seconds

        try:
            self.db_service = DatabaseService(
                connection_string=connection_string,
                cache_ttl_seconds=cache_ttl,
                pool_size=self.tool_config.pool_size,
                max_overflow=self.tool_config.max_overflow,
                pool_timeout=self.tool_config.pool_timeout,
                pool_recycle=self.tool_config.pool_recycle,
                pool_pre_ping=self.tool_config.pool_pre_ping,
                connect_args=self.tool_config.connect_args,
                isolation_level=self.tool_config.isolation_level,
                echo=self.tool_config.echo,
            )
        except Exception as e:
            self._connection_healthy = False
            self._connection_error = f"Failed to create database engine: {type(e).__name__}: {str(e)}"
            log.error(
                "%s Failed to initialize DatabaseService: %s. Tool will be marked as unavailable.",
                log_identifier,
                e
            )
            log.warning(
                "%s Tool '%s' initialized in DEGRADED mode. It will not accept queries until database connectivity is restored.",
                log_identifier,
                self.tool_name
            )
            return

        try:
            if self.tool_config.auto_detect_schema:
                log.debug("%s Auto-detecting database schema...", log_identifier)
                self._schema_context = self.db_service.get_optimized_schema_for_llm(
                    max_enum_cardinality=self.tool_config.max_enum_cardinality,
                    sample_size=self.tool_config.schema_sample_size
                )
                log.debug("%s Schema cached in memory (%d chars)", log_identifier, len(self._schema_context))
            else:
                log.debug("%s Using provided schema overrides.", log_identifier)
                if not self.tool_config.schema_summary_override:
                    raise ValueError(
                        "schema_summary_override is required when auto_detect_schema is false."
                    )
                self._schema_context = self.tool_config.schema_summary_override
                log.debug("%s Schema overrides applied.", log_identifier)

            if not self._schema_context:
                log.warning(
                    "%s Schema context is empty. This may impact LLM performance.",
                    log_identifier,
                )

            self._connection_healthy = True
            self._connection_error = None
            log.info("%s Connection for '%s' established successfully.", log_identifier, self.tool_name)

        except Exception as e:
            self._connection_healthy = False
            self._connection_error = f"Schema detection failed: {type(e).__name__}: {str(e)}"
            log.error(
                "%s Error during schema handling: %s. Tool will be marked as unavailable.",
                log_identifier,
                e
            )
            log.warning(
                "%s Tool '%s' initialized in DEGRADED mode. It will not accept queries until database connectivity is restored.",
                log_identifier,
                self.tool_name
            )

    async def cleanup(self, component: SamAgentComponent, tool_config: Dict):
        log_identifier = f"[{self.tool_name}:cleanup]"
        log.info("%s Closing connection...", log_identifier)
        if self.db_service:
            self.db_service.close()
        log.info("%s Connection for '%s' closed.", log_identifier, self.tool_name)

    async def _run_async_impl(self, args: Dict[str, Any], **kwargs) -> Dict[str, Any]:
        log_identifier = f"[{self.tool_name}:run]"
        query = args.get("query")

        if not self.db_service:
            return {"error": f"The database connection for '{self.tool_name}' is not available. Database service failed to initialize."}

        log.info("%s Executing query on '%s': %s", log_identifier, self.tool_name, query)
        try:
            results = self.db_service.execute_query(query)

            if not self._connection_healthy:
                self._connection_healthy = True
                self._connection_error = None
                log.info("%s Database connection recovered for '%s'", log_identifier, self.tool_name)

                if not self._schema_context and self.tool_config.auto_detect_schema:
                    log.debug("%s Attempting to fetch schema after recovery...", log_identifier)
                    try:
                        self._schema_context = self.db_service.get_optimized_schema_for_llm(
                            max_enum_cardinality=self.tool_config.max_enum_cardinality,
                            sample_size=self.tool_config.schema_sample_size
                        )
                        log.debug("%s Schema successfully fetched after recovery (%d chars)", log_identifier, len(self._schema_context))
                    except Exception as schema_error:
                        log.warning("%s Schema fetch failed after recovery: %s", log_identifier, schema_error)

            return {"result": results}
        except Exception as e:
            was_healthy = self._connection_healthy
            self._connection_healthy = False
            self._connection_error = f"Query error: {type(e).__name__}: {str(e)}"

            if was_healthy:
                log.error("%s Database connection lost for '%s': %s", log_identifier, self.tool_name, e)
            else:
                log.warning("%s Query failed on degraded database '%s': %s", log_identifier, self.tool_name, e)

            return {"error": str(e)}
