uv run fimama
