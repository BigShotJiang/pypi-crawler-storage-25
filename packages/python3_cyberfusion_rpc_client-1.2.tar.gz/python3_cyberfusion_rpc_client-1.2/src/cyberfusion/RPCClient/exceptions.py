class MessageUnroutable(Exception):
    pass
