API reference
=============

The full public API of ``pybmodes``. The semver-stable surface is
enumerated in :doc:`api_contract`.

High-level models
-----------------

.. automodule:: pybmodes.models.blade
   :members:
   :show-inheritance:

.. automodule:: pybmodes.models.tower
   :members:
   :show-inheritance:

.. automodule:: pybmodes.models.result
   :members:
   :show-inheritance:

Input / output
--------------

Parse errors (common across every ``pybmodes.io.*`` reader)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: pybmodes.io.errors
   :members:
   :show-inheritance:

BModes ``.bmi``
^^^^^^^^^^^^^^^

.. automodule:: pybmodes.io.bmi
   :members:
   :show-inheritance:

ElastoDyn deck reader
^^^^^^^^^^^^^^^^^^^^^

.. automodule:: pybmodes.io.elastodyn_reader
   :members:
   :show-inheritance:

SubDyn reader
^^^^^^^^^^^^^

.. automodule:: pybmodes.io.subdyn_reader
   :members:
   :show-inheritance:

WAMIT / HydroDyn reader
^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: pybmodes.io.wamit_reader
   :members:
   :show-inheritance:

BModes ``.out`` output
^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: pybmodes.io.out_parser
   :members:
   :show-inheritance:

WindIO ontology — tubular tower / monopile
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: pybmodes.io.windio
   :members:
   :show-inheritance:

WindIO ontology — composite blade
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: pybmodes.io.windio_blade
   :members:
   :show-inheritance:

WindIO ontology — floating substructure
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: pybmodes.io.windio_floating
   :members:
   :show-inheritance:

Geometry & section properties
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: pybmodes.io.geometry
   :members:
   :show-inheritance:

.. automodule:: pybmodes.io.sec_props
   :members:
   :show-inheritance:

Polynomial fitting + ElastoDyn helpers
--------------------------------------

.. automodule:: pybmodes.fitting.poly_fit
   :members:
   :show-inheritance:

.. automodule:: pybmodes.elastodyn.params
   :members:
   :show-inheritance:

.. automodule:: pybmodes.elastodyn.validate
   :members:
   :show-inheritance:

.. automodule:: pybmodes.elastodyn.writer
   :members:
   :show-inheritance:

Campbell
--------

.. automodule:: pybmodes.campbell
   :members:
   :show-inheritance:

Modal Assurance Criterion
-------------------------

.. automodule:: pybmodes.mac
   :members:
   :show-inheritance:

Pre-solve sanity checks
-----------------------

.. automodule:: pybmodes.checks
   :members:
   :show-inheritance:

Numerical options
-----------------

Centralised numerical-options dataclasses. Defaults preserve every
previously-embedded magic number from ``fem/solver.py``,
``elastodyn/params.py``, and ``checks.py`` — importing this module
changes no behaviour; the value is that callers (and reviewers) can
now find every numerical threshold in one place.

.. automodule:: pybmodes.options
   :members:
   :show-inheritance:

Report generation
-----------------

.. automodule:: pybmodes.report
   :members:
   :show-inheritance:

Mooring
-------

.. automodule:: pybmodes.mooring
   :members:
   :show-inheritance:

Plot helpers (``[plots]`` extra)
--------------------------------

.. automodule:: pybmodes.plots
   :members:
   :show-inheritance:

Workflows (library-callable CLI subcommands)
--------------------------------------------

Phase 2 of the v1.x architecture refactor exposes each CLI
subcommand as a typed library function. The CLI in
:mod:`pybmodes.cli` becomes a thin ``argparse + delegation``
layer; notebooks and external scripts can call the same flows
directly without :mod:`subprocess`.

.. automodule:: pybmodes.workflows
   :members:
   :show-inheritance:

.. automodule:: pybmodes.workflows._base
   :members:
   :show-inheritance:

.. automodule:: pybmodes.workflows.validate
   :members:
   :show-inheritance:

.. automodule:: pybmodes.workflows.examples
   :members:
   :show-inheritance:

.. automodule:: pybmodes.workflows.patch
   :members:
   :show-inheritance:

.. automodule:: pybmodes.workflows.report
   :members:
   :show-inheritance:

.. automodule:: pybmodes.workflows.batch
   :members:
   :show-inheritance:

.. automodule:: pybmodes.workflows.campbell
   :members:
   :show-inheritance:

.. automodule:: pybmodes.workflows.windio
   :members:
   :show-inheritance:

CLI
---

.. automodule:: pybmodes.cli
   :members:
   :show-inheritance:
