# Copyright 2024-2026 Jae Hoon Seo
# Marine Structural Mechanics and Integrity Lab (SMI Lab), Inha University
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""I/O sub-package: BModes ``.bmi`` and OpenFAST ``.dat`` parsers.

Most callers reach the parsers through their submodules
(``pybmodes.io.bmi``, ``pybmodes.io.elastodyn_reader``,
``pybmodes.io.subdyn_reader``); the WAMIT / HydroDyn / mooring entry
points below are also surfaced here for convenience because the
typical use — ``HydroDynReader(...).read_platform_matrices()`` and
``MooringSystem.from_moordyn(...)`` — is one import line per reader.
"""

from pybmodes.io.bmi import PlatformSupport, TipMassProps
from pybmodes.io.errors import (
    BMIParseError,
    ElastoDynParseError,
    MoorDynParseError,
    ParseError,
    SubDynParseError,
    WAMITParseError,
    WindIOParseError,
)
from pybmodes.io.out_parser import BModeOutParseError, read_out
from pybmodes.io.wamit_reader import HydroDynReader, WamitData, WamitReader
from pybmodes.mooring import MooringSystem

__all__ = [
    "BMIParseError",
    "BModeOutParseError",
    "ElastoDynParseError",
    "HydroDynReader",
    "MoorDynParseError",
    "MooringSystem",
    "ParseError",
    "PlatformSupport",
    "SubDynParseError",
    "TipMassProps",
    "WAMITParseError",
    "WamitData",
    "WamitReader",
    "WindIOParseError",
    "read_out",
]
