"""Declarative theming for subdomain apps.

Provides a ``Theme`` dataclass that controls colors, typography, border radii,
and branding (logo / tagline). Includes built-in presets that can be used as
starting points.

Usage::

    app = cpsl.App(name="my-app")
    app.theme(preset="light", accent="#e09145", logo="assets/logo.png")
"""

from __future__ import annotations

from dataclasses import dataclass, fields, asdict
from typing import Any


@dataclass
class Theme:
    # branding
    logo: str | None = None
    tagline: str | None = None

    # colors
    primary: str | None = None
    accent: str | None = None
    background: str | None = None
    foreground: str | None = None
    sidebar: str | None = None
    surface: str | None = None
    border: str | None = None
    muted: str | None = None
    danger: str | None = None
    success: str | None = None

    # typography (Google Fonts family names)
    font_sans: str | None = None
    font_mono: str | None = None

    # shape — "sm" | "md" | "lg"
    radius: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {k: v for k, v in asdict(self).items() if v is not None}

    def merge(self, overrides: dict[str, Any]) -> Theme:
        """Return a new Theme with non-None overrides applied on top."""
        base = asdict(self)
        for k, v in overrides.items():
            if v is not None and k in base:
                base[k] = v
        return Theme(**base)


# ---------------------------------------------------------------------------
# Built-in presets
# ---------------------------------------------------------------------------

PRESETS: dict[str, Theme] = {
    "dark": Theme(
        primary="#00b4d8",
        accent="#e09145",
        background="#1c1f26",
        foreground="#eef0f4",
        sidebar="#161820",
        surface="#252830",
        border="#333845",
        muted="#9ca3b0",
        danger="#ef4444",
        success="#22c55e",
        radius="md",
    ),
    "light": Theme(
        primary="#1565c0",
        accent="#d97706",
        background="#ffffff",
        foreground="#1a1d21",
        sidebar="#f5f6f8",
        surface="#f0f1f3",
        border="#e0e2e6",
        muted="#6b7280",
        danger="#c62828",
        success="#16a34a",
        radius="md",
    ),
    "midnight": Theme(
        primary="#38bdf8",
        accent="#a78bfa",
        background="#0f172a",
        foreground="#e2e8f0",
        sidebar="#0b1120",
        surface="#1e293b",
        border="#334155",
        muted="#94a3b8",
        danger="#f87171",
        success="#34d399",
        radius="md",
    ),
    "warm": Theme(
        primary="#b45309",
        accent="#dc8b4f",
        background="#fdf8f0",
        foreground="#292524",
        sidebar="#f5ebe0",
        surface="#faebd7",
        border="#d6cfc7",
        muted="#78716c",
        danger="#b91c1c",
        success="#15803d",
        radius="lg",
    ),
}


def resolve_theme(
    preset: str | None = None,
    **overrides: Any,
) -> Theme:
    """Build a Theme from an optional preset plus keyword overrides."""
    valid_fields = {f.name for f in fields(Theme)}
    bad = set(overrides) - valid_fields
    if bad:
        raise ValueError(f"Unknown theme fields: {', '.join(sorted(bad))}")

    if preset is not None:
        if preset not in PRESETS:
            raise ValueError(
                f"Unknown preset '{preset}'. Available: {', '.join(sorted(PRESETS))}"
            )
        base = PRESETS[preset]
        return base.merge(overrides)

    return Theme(**{k: v for k, v in overrides.items() if v is not None})
