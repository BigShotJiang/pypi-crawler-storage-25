"""Single source of truth for wire-format strings and limits.

Every constant here corresponds to a value that crosses a module boundary
or appears in serialized JSON / HTTP headers / gRPC metadata.  If a string
is used in only one place, it doesn't belong here.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

# ---------------------------------------------------------------------------
# Collection scopes — stored in Mongo docs as filter keys
# ---------------------------------------------------------------------------

SCOPE_APP: Literal["app"] = "app"
SCOPE_USER: Literal["user"] = "user"
SCOPE_TEAM: Literal["team"] = "team"
SCOPE_SESSION: Literal["session"] = "session"

CollectionScope = Literal["app", "user", "team", "session"]

VALID_SCOPES: frozenset[str] = frozenset({SCOPE_APP, SCOPE_USER, SCOPE_TEAM, SCOPE_SESSION})

SCOPE_FIELD_USER = "_user_id"
SCOPE_FIELD_TEAM = "_team_id"
SCOPE_FIELD_SESSION = "_session_id"

# ---------------------------------------------------------------------------
# Access control levels — pages, data sources, endpoints
# ---------------------------------------------------------------------------

ACCESS_PUBLIC: Literal["public"] = "public"
ACCESS_AUTHENTICATED: Literal["authenticated"] = "authenticated"

AccessLevel = Literal["public", "authenticated"]

# ---------------------------------------------------------------------------
# HTTP headers injected by the Go gateway → runner
# ---------------------------------------------------------------------------

HEADER_AUTHENTICATED = "X-Capsule-Authenticated"
HEADER_EMAIL = "X-Capsule-Email"
HEADER_USER_ID = "X-Capsule-User-Id"
HEADER_ORG_ID = "X-Capsule-Org-Id"
HEADER_SESSION_ID = "X-Capsule-Session-Id"

# ---------------------------------------------------------------------------
# Collection query defaults
# ---------------------------------------------------------------------------

DEFAULT_PAGE_SIZE = 50
MAX_PAGE_SIZE = 200

# ---------------------------------------------------------------------------
# Pricing types — stored on apps, sent in DeployRequest
# ---------------------------------------------------------------------------

PRICING_ONE_TIME: Literal["one_time"] = "one_time"
PRICING_MONTHLY: Literal["monthly"] = "monthly"

PricingType = Literal["one_time", "monthly"]

# ---------------------------------------------------------------------------
# Page types
# ---------------------------------------------------------------------------

PAGE_TYPE_REACT: Literal["react"] = "react"
PAGE_TYPE_DSL: Literal["dsl"] = "dsl"

# ---------------------------------------------------------------------------
# Session defaults
# ---------------------------------------------------------------------------

DEFAULT_CHANNEL_TYPE = "chat"
DEFAULT_TOKEN_TYPE = "Bearer"

HISTORY_FETCH_COUNT = 50

# ---------------------------------------------------------------------------
# Collection declaration — typed struct instead of dict[str, Any]
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class CollectionDecl:
    """Immutable declaration of a named collection (scope, columns, UI hints)."""

    name: str
    scope: CollectionScope = SCOPE_APP
    columns: tuple[str, ...] | None = None
    sortable: bool = False
    filterable: bool = False
    paginate: int = 0

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "columns": list(self.columns) if self.columns else None,
            "scope": self.scope,
            "sortable": self.sortable,
            "filterable": self.filterable,
            "paginate": self.paginate,
        }

    @classmethod
    def from_dict(cls, d: dict) -> CollectionDecl:
        cols = d.get("columns")
        return cls(
            name=d["name"],
            scope=d.get("scope", SCOPE_APP),
            columns=tuple(cols) if cols else None,
            sortable=d.get("sortable", False),
            filterable=d.get("filterable", False),
            paginate=d.get("paginate", 0),
        )

    def scope_filter(self, *, user_id: str, team_id: str = "", session_id: str) -> dict[str, str]:
        if self.scope == SCOPE_USER:
            return {SCOPE_FIELD_USER: user_id}
        if self.scope == SCOPE_TEAM:
            return {SCOPE_FIELD_TEAM: team_id or user_id}
        if self.scope == SCOPE_SESSION:
            return {SCOPE_FIELD_SESSION: session_id}
        return {}
