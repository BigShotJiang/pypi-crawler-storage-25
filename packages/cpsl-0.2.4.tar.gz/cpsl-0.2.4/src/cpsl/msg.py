from __future__ import annotations

import time as _time
from dataclasses import dataclass, field


@dataclass
class Attachment:
    """File attached to a message."""

    name: str
    content_type: str
    url: str

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "content_type": self.content_type,
            "url": self.url,
        }


@dataclass
class Message:
    """A single message exchanged between user and app."""

    text: str
    sender: str  # "user" | "app"
    channel_type: str  # "chat" | "api" | ...
    timestamp: float = field(default_factory=_time.time)
    attachments: list[Attachment] | None = None

    def to_dict(self) -> dict:
        d = {
            "text": self.text,
            "sender": self.sender,
            "channel_type": self.channel_type,
            "timestamp": self.timestamp,
        }
        if self.attachments:
            d["attachments"] = [a.to_dict() for a in self.attachments]
        return d
