from __future__ import annotations

import asyncio
import json
import uuid
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

from .db import ScopedDatabaseProxy
from .integration import IntegrationCredentials
from .msg import Message


@dataclass
class Block:
    """Structured inline message sent over the chat transport.

    `type` picks the renderer on the client side (e.g. ``task_card``,
    ``integration_prompt``). ``payload`` is an arbitrary JSON-serializable
    dict. An ``id`` is auto-generated if not supplied.
    """

    type: str
    payload: dict[str, Any]
    id: str = ""

    def to_envelope(self) -> dict[str, Any]:
        return {
            "id": self.id or f"blk_{uuid.uuid4().hex[:12]}",
            "type": self.type,
            "payload": self.payload,
        }


@dataclass
class SessionChannel:
    """Describes the transport a session message arrived on (chat, telegram, etc.)."""

    type: str


@dataclass
class UserInfo:
    """Identity of the authenticated user.

    ``id`` identifies the individual. ``org_id`` is set when the user
    belongs to an organization — used for ``scope="team"`` partitioning.
    ``scope="user"`` always filters by ``id``.
    """

    id: str
    email: str | None = None
    org_id: str | None = None

    @property
    def is_org_member(self) -> bool:
        """True when this user belongs to an app organization."""
        return bool(self.org_id)

    @property
    def owner_id(self) -> str:
        """Org-aware scoping key: ``org_id`` when present, else ``id``.

        Used for runtime isolation, task ownership, and ``scope="team"``
        collection partitioning.
        """
        return self.org_id or self.id


class Session:
    """Per-user conversation context, persisted across messages.

    Concurrency: handlers for the same session are serialized via an
    ``asyncio.Lock``. Handlers across *different* sessions may run
    concurrently. Avoid mutating shared app-instance state without your
    own synchronization.

    Attributes:
        id:      Unique session identifier.
        user:    Identity of the user — ``UserInfo(id, email)``.
        channel: Channel this session is on (chat, api, etc.).
        history: Recent messages, rehydrated from the backing store.
        data:    Persistent key-value dict, saved automatically after each message.
    """

    __slots__ = (
        "id",
        "user",
        "channel",
        "history",
        "data",
        "integrations",
        "_reply_callback",
        "_stream_callback",
        "_notify_callback",
        "_block_callback",
        "_db_proxy",
    )

    def __init__(
        self,
        id: str,
        user: UserInfo,
        channel: SessionChannel,
        history: list[Message] | None = None,
        data: dict[str, Any] | None = None,
        integrations: dict[str, IntegrationCredentials] | None = None,
    ) -> None:
        self.id = id
        self.user = user
        self.channel = channel
        self.history: list[Message] = history or []
        self.data: dict[str, Any] = data or {}
        self.integrations: dict[str, IntegrationCredentials] = integrations or {}
        self._reply_callback: Any = None
        self._stream_callback: Any = None
        self._notify_callback: Any = None
        self._block_callback: Any = None
        self._db_proxy: ScopedDatabaseProxy | None = None

    @property
    def db(self) -> ScopedDatabaseProxy:
        """Scoped database proxy — collections auto-filtered by user/team/session identity."""
        if self._db_proxy is None:
            raise RuntimeError("session.db not available (database not configured)")
        return self._db_proxy

    async def reply(self, text: str) -> None:
        """Send a complete message back to the user."""
        msg = Message(text=text, sender="app", channel_type=self.channel.type)
        self.history.append(msg)
        if self._reply_callback:
            await self._reply_callback(msg)

    async def notify(self, text: str) -> None:
        """Send a lightweight status notification to the user."""
        msg = Message(text=text, sender="system", channel_type=self.channel.type)
        if self._notify_callback:
            await self._notify_callback(msg)
        elif self._reply_callback:
            await self._reply_callback(msg)

    async def stream(self, chunks: AsyncIterator[str]) -> None:
        """Stream response chunks to the user in real time."""
        if self._stream_callback:
            await self._stream_callback(chunks)

    async def show(self, block: Block) -> None:
        """Render a structured block inline in the chat transport.

        The block is delivered as a one-shot chunk on the session's SSE
        stream and persisted in history so it replays on page reload. The
        block itself is stateless — renderers fetch live data (e.g.
        ``task_card`` re-reads ``/tasks/:id``).
        """
        if not self._block_callback:
            return
        envelope = block.to_envelope()
        await self._block_callback(json.dumps(envelope))

    async def show_task(
        self, handle_or_id: Any, *, message: str | None = None
    ) -> None:
        """Render an inline card that tracks the given task's live state.

        Accepts a ``TaskHandle`` or raw task-id string. The card polls
        the task endpoint client-side, so we only have to name the task
        here — no payload snapshot is captured.

        ``message`` sets the card's headline (e.g. "Generating report…").
        When omitted, the card falls back to a humanized task name.
        """
        task_id = getattr(handle_or_id, "task_id", None) or str(handle_or_id)
        if not task_id:
            return
        payload: dict[str, Any] = {"task_id": task_id}
        if message:
            payload["message"] = message
        await self.show(Block(type="task_card", payload=payload))

    async def show_integration(self, integration_type: str, *, reason: str = "") -> None:
        """Render an inline Connect-Integration card without blocking.

        Useful when a handler wants to hint that an integration would
        unlock more functionality but can still proceed without it.
        """
        await self.show(
            Block(
                type="integration_prompt",
                payload={"type": integration_type, "reason": reason, "blocking": False},
            )
        )

    async def prompt_integration(
        self,
        integration_type: str,
        *,
        reason: str = "",
        timeout: float = 300.0,
    ) -> IntegrationCredentials:
        """Render a blocking Connect-Integration card and wait for connection.

        Returns the live ``IntegrationCredentials`` once the user completes
        the OAuth flow. If the user is already connected this returns
        immediately (idempotent). Raises ``IntegrationTimeout`` if the
        timeout elapses before the connection is made.

        """
        from .clients.capsule import WaitForIntegrationRequest

        existing = self.integrations.get(integration_type)
        if existing:
            return existing

        await self.show(
            Block(
                type="integration_prompt",
                payload={"type": integration_type, "reason": reason, "blocking": True},
            )
        )

        runner = _get_runner_for_session(self)
        if runner is None or runner._session_stub is None:
            raise IntegrationDeclined(
                f"no gateway connection available to prompt for '{integration_type}'"
            )

        app_id = getattr(runner, "_app_id", "") or ""
        req = WaitForIntegrationRequest(
            app_id=app_id,
            user_id=self.user.email or self.user.id or "",
            integration_type=integration_type,
            timeout_seconds=int(timeout),
        )

        def _call():
            return runner._session_stub.wait_for_integration(req)

        resp = await asyncio.get_running_loop().run_in_executor(None, _call)

        if resp.timed_out:
            raise IntegrationTimeout(f"timed out waiting for '{integration_type}' connection")
        if not resp.connected:
            raise IntegrationDeclined(f"user did not connect '{integration_type}'")

        cred = IntegrationCredentials(
            access_token=resp.credential.access_token,
            token_type=resp.credential.token_type or "Bearer",
            scopes=list(resp.credential.scopes),
            expires_at=resp.credential.expires_at,
        )
        self.integrations[integration_type] = cred
        return cred


class IntegrationTimeout(TimeoutError):
    """Raised when ``session.prompt_integration`` times out."""


class IntegrationDeclined(RuntimeError):
    """Raised when the user explicitly declines an integration prompt."""


def _get_runner_for_session(session: "Session"):
    """Return the active ``Runner``, avoiding a circular import."""
    try:
        from .runner import Runner
    except ImportError:
        return None
    return Runner._current_instance()
