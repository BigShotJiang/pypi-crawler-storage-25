from __future__ import annotations

from dataclasses import fields as dc_fields
from typing import Any, Callable, TypeVar, Union

from .channels import Chat, ChannelRef, _DeprecatedChannel, API
from .constants import (
    ACCESS_PUBLIC, AccessLevel,
    CollectionDecl, CollectionScope,
    PAGE_TYPE_DSL, PAGE_TYPE_REACT,
    PRICING_ONE_TIME, PricingType,
    SCOPE_APP, VALID_SCOPES,
)
from .db import CollectionRef
from .filesystem import FileSystem
from .image import Image
from .integration import IntegrationConfig
from .decorators import _SCHEDULE_ATTR
from .secret import Secret
from .theme import Theme, resolve_theme

ChannelLike = Union[Chat, ChannelRef, _DeprecatedChannel, API]

T = TypeVar("T")

_REGISTERED_CLASSES: list[dict[str, Any]] = []
_DATA_REGISTRY: dict[str, Callable] = {}

_DATA_ATTR = "__cpsl_data__"
_ACCESS_ATTR = "_cpsl_access"


def _collect_channel_secrets(channels: list[ChannelLike]) -> list[str]:
    """Extract secret names from channel credential fields."""
    names: list[str] = []
    for ch in channels:
        if isinstance(ch, (Chat, ChannelRef, API)):
            continue
        for f in dc_fields(ch):
            v = getattr(ch, f.name)
            if isinstance(v, Secret) and v.name:
                names.append(v.name)
    return names


class App:
    """Lightweight deployment namespace. All deploy config lives on the decorator."""

    def __init__(self, name: str) -> None:
        self.name = name
        self._integrations: list[IntegrationConfig] = []
        self._pages: list[dict[str, Any]] = []
        self._collections: list[CollectionDecl] = []
        self._collection_refs: list[CollectionRef] = []
        self._data_sources: dict[str, Callable] = {}
        self._page_order: int = 0
        self._theme: Theme | None = None

    # -- collections ---------------------------------------------------------

    def collection(
        self,
        name: str,
        *,
        columns: list[str] | None = None,
        scope: CollectionScope = SCOPE_APP,
        sortable: bool = False,
        filterable: bool = False,
        paginate: int = 0,
    ) -> CollectionRef:
        """Declare a collection and return a ``CollectionRef`` handle.

        Scopes: ``"app"`` (shared), ``"user"`` (per individual),
        ``"team"`` (per org), ``"session"`` (per chat session).
        """
        if scope not in VALID_SCOPES:
            raise ValueError(f"scope must be one of {VALID_SCOPES}, got {scope!r}")
        decl = CollectionDecl(
            name=name,
            scope=scope,
            columns=tuple(columns) if columns else None,
            sortable=sortable,
            filterable=filterable,
            paginate=paginate,
        )
        self._collections.append(decl)
        ref = CollectionRef(name=name, decl=decl)
        self._collection_refs.append(ref)
        return ref

    # -- theme ---------------------------------------------------------------

    def theme(self, *, preset: str | None = None, **kwargs: Any) -> None:
        """Configure the visual theme for the subdomain app.

        Accepts an optional ``preset`` ("dark", "light", "midnight", "warm")
        as a starting point, plus keyword overrides for individual properties
        (colors, fonts, radius, logo, tagline).
        """
        self._theme = resolve_theme(preset=preset, **kwargs)

    # -- integrations --------------------------------------------------------

    def add_integration(
        self,
        integration_type: str,
        *,
        client_id: str | Secret,
        client_secret: str | Secret,
        scopes: list[str] | None = None,
    ) -> None:
        """Declare an OAuth integration the app requires from end users."""
        self._integrations.append(IntegrationConfig(
            type=integration_type,
            client_id=client_id,
            client_secret=client_secret,
            scopes=scopes or [],
        ))

    # -- pages ---------------------------------------------------------------

    def add_page(
        self,
        name: str,
        *,
        icon: str = "file",
        component: str,
        packages: list[str] | None = None,
        order: int | None = None,
        access: AccessLevel = ACCESS_PUBLIC,
    ) -> None:
        """Declare a React/TSX page that appears in the subdomain sidebar.

        ``access`` controls who can view the page:
        ``"public"`` (default) — anyone, ``"authenticated"`` — logged-in users only.
        """
        if order is None:
            order = self._page_order
        self._page_order = max(self._page_order, order) + 1
        self._pages.append({
            "name": name,
            "icon": icon,
            "type": PAGE_TYPE_REACT,
            "component": component,
            "packages": packages or [],
            "order": order,
            "access": access,
        })

    def page(
        self,
        name: str,
        *,
        icon: str = "file",
        order: int | None = None,
        access: AccessLevel = ACCESS_PUBLIC,
    ) -> Callable[[Callable], Callable]:
        """Decorator for Python DSL pages. The function must return a ui.Page widget tree.

        ``access`` controls who can view the page:
        ``"public"`` (default) — anyone, ``"authenticated"`` — logged-in users only.
        """
        if order is None:
            order = self._page_order
        self._page_order = max(self._page_order, order) + 1
        _order = order
        _access = access

        def decorator(fn: Callable) -> Callable:
            widget_tree = fn()
            tree_dict = widget_tree.to_dict() if hasattr(widget_tree, "to_dict") else {}
            self._pages.append({
                "name": name,
                "icon": icon,
                "type": PAGE_TYPE_DSL,
                "widget_tree": tree_dict,
                "order": _order,
                "access": _access,
            })
            return fn

        return decorator

    # -- data sources --------------------------------------------------------

    def data(self, name: str, *, access: AccessLevel = ACCESS_PUBLIC) -> Callable[[Callable], Callable]:
        """Register a named data source endpoint. The function is called on
        ``GET /data/<name>`` and should return JSON-serializable data.

        ``access`` controls who can call the endpoint:
        ``"public"`` (default) — anyone, ``"authenticated"`` — logged-in users only.
        """
        _access = access

        def decorator(fn: Callable) -> Callable:
            self._data_sources[name] = fn
            _DATA_REGISTRY[name] = fn
            setattr(fn, _DATA_ATTR, name)
            setattr(fn, _ACCESS_ATTR, _access)
            return fn
        return decorator

    # -- cls decorator -------------------------------------------------------

    def cls(
        self,
        *,
        image: Image,
        price: int = 0,
        pricing_type: PricingType = PRICING_ONE_TIME,
        channels: list[ChannelLike] | None = None,
        keep_warm_seconds: int = 0,
        secrets: list[str] | None = None,
        filesystems: dict[str, FileSystem] | None = None,
    ) -> Callable[[type[T]], type[T]]:
        """Decorator for class-based apps. Captures deploy config."""
        app_name = self.name
        all_channels = channels or []
        all_secrets = list(secrets or [])
        for name in _collect_channel_secrets(all_channels):
            if name not in all_secrets:
                all_secrets.append(name)

        fs_map: dict[str, str] = {}
        if filesystems:
            for mount_path, fs_obj in filesystems.items():
                fs_map[mount_path] = fs_obj.name

        integrations = [ig.to_dict() for ig in self._integrations]
        pages = sorted(self._pages, key=lambda p: p.get("order", 0))
        data_source_names = list(self._data_sources.keys())
        collections = [c.to_dict() for c in self._collections]
        collection_refs = list(self._collection_refs)
        theme_dict = self._theme.to_dict() if self._theme else None

        def decorator(klass: type[T]) -> type[T]:
            schedule_specs: list[dict[str, str]] = []
            for attr_name in dir(klass):
                fn = getattr(klass, attr_name, None)
                cron_val = getattr(fn, _SCHEDULE_ATTR, None)
                if cron_val and isinstance(cron_val, str):
                    schedule_specs.append({"name": attr_name, "cron": cron_val})

            config = {
                "app_name": app_name,
                "image": image.to_dict(),
                "price": price,
                "pricing_type": pricing_type,
                "channels": [c.to_dict() for c in all_channels],
                "keep_warm_seconds": keep_warm_seconds,
                "secrets": all_secrets,
                "filesystems": fs_map,
                "integrations": integrations,
                "schedules": schedule_specs,
                "pages": pages,
                "collections": collections,
                "collection_refs": collection_refs,
                "data_sources": data_source_names,
                "theme": theme_dict,
                "module": klass.__module__,
                "class_name": klass.__qualname__,
            }
            klass._cpsl_config = config  # type: ignore[attr-defined]
            _REGISTERED_CLASSES.append(config)
            return klass

        return decorator

    def _serialize(self) -> dict[str, Any] | None:
        """Return the deploy spec for the class registered under this app."""
        for cfg in _REGISTERED_CLASSES:
            if cfg["app_name"] == self.name:
                return cfg
        return None
