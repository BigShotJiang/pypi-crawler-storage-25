"""Filesystem resource — a named, mountable storage volume backed by Airstore."""

from __future__ import annotations


class FileSystem:
    """Declare a named filesystem that can be mounted into an app.

    Usage::

        fs = cpsl.FileSystem("my-data")

        @app.cls(
            image=cpsl.Image(...),
            filesystems={"/data": fs},
        )
        class MyApp:
            ...
    """

    def __init__(self, name: str) -> None:
        if not name:
            raise ValueError("FileSystem name must not be empty")
        self.name = name

    def __repr__(self) -> str:
        return f"FileSystem({self.name!r})"
