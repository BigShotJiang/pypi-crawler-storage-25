"""Integration declarations for Capsule apps.

Integrations are user-facing OAuth connections declared at the app level
via ``app.add_integration()``. At runtime, credentials are available on
``session.integrations``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Union

from .secret import Secret


# Supported integration types. Gmail / Google Calendar / Google Drive all
# share Google's OAuth endpoints but are exposed as distinct types so apps
# can reason about each surface independently and the UI can show
# "Connect Gmail" instead of a generic "Connect Google".
INTEGRATION_GOOGLE = "google"
INTEGRATION_GMAIL = "gmail"
INTEGRATION_GCAL = "gcal"
INTEGRATION_GDRIVE = "gdrive"
INTEGRATION_GITHUB = "github"
INTEGRATION_LINEAR = "linear"


@dataclass
class IntegrationConfig:
    """Describes an OAuth integration the app requires.

    Attributes:
        type: Provider name. One of ``google``, ``gmail``, ``gcal``,
            ``gdrive``, ``github``, ``linear``.
        client_id: Secret reference for the developer's OAuth client ID.
        client_secret: Secret reference for the developer's OAuth client secret.
        scopes: OAuth scopes to request from the user.
    """

    type: str
    client_id: Union[str, Secret] = ""
    client_secret: Union[str, Secret] = ""
    scopes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        cid = self.client_id
        cs = self.client_secret
        return {
            "type": self.type,
            "scopes": list(self.scopes),
            "client_id_secret": cid._name if isinstance(cid, Secret) else cid,
            "client_secret_secret": cs._name if isinstance(cs, Secret) else cs,
        }


@dataclass
class IntegrationCredentials:
    """Decrypted OAuth credentials provided on the session at runtime."""

    access_token: str
    token_type: str = "Bearer"
    scopes: list[str] = field(default_factory=list)
    expires_at: int = 0
