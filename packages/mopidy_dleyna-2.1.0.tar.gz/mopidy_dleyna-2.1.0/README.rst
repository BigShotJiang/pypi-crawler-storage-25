*************
Mopidy-dLeyna
*************

.. image:: https://img.shields.io/pypi/v/Mopidy-dLeyna
    :target: https://pypi.org/project/Mopidy-dLeyna/
    :alt: Latest PyPI version

.. image:: https://img.shields.io/github/actions/workflow/status/tkem/mopidy-dleyna/ci.yml
   :target: https://github.com/tkem/mopidy-dleyna/actions/workflows/ci.yml
   :alt: CI build status

.. image:: https://img.shields.io/readthedocs/mopidy-dleyna
    :target: https://mopidy-dleyna.readthedocs.io/
    :alt: Documentation build status

.. image:: https://img.shields.io/codecov/c/gh/tkem/mopidy-dleyna
    :target: https://codecov.io/gh/tkem/mopidy-dleyna
    :alt: Test coverage

.. image:: https://img.shields.io/github/license/tkem/mopidy-dleyna
   :target: https://raw.github.com/tkem/mopidy-dleyna/master/LICENSE
   :alt: License

.. image:: https://img.shields.io/badge/code%20style-black-000000.svg
   :target: https://github.com/psf/black
   :alt: Code style: black

Mopidy-dLeyna is a Mopidy_ extension that lets you play music from
DLNA_ Digital Media Servers using the dLeyna_ D-Bus interface.

This extension lets you browse, search, and stream music from your
NAS, PC, or any other device running a UPnP/DLNA compliant media
server.  Compatible devices are discovered automatically on your local
network, so there is no configuration needed.

For more information and installation instructions, please see
Mopidy-dLeyna's online documentation_.

.. _Mopidy: http://www.mopidy.com/
.. _DLNA: http://www.dlna.org/
.. _dLeyna: http://01.org/dleyna
.. _Documentation: https://mopidy-dleyna.readthedocs.io/


Project resources
=================

- `Source code <https://github.com/tkem/mopidy-dleyna>`_
- `Issue tracker <https://github.com/tkem/mopidy-dleyna/issues>`_
- `Changelog <https://github.com/tkem/mopidy-dleyna/blob/master/CHANGELOG.rst>`_


Credits
=======

- Original author: `Thomas Kemmer <https://github.com/tkem>`__
- Current maintainer: `Thomas Kemmer <https://github.com/tkem>`__
- `Contributors <https://github.com/tkem/mopidy-dleyna/graphs/contributors>`_
