# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["CliVersionParams"]


class CliVersionParams(TypedDict, total=False):
    current: str

    platform: str
