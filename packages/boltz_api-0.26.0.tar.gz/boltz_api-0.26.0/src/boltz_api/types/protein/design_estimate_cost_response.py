# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal

from ..._models import BaseModel

__all__ = ["DesignEstimateCostResponse", "Breakdown"]


class Breakdown(BaseModel):
    """Cost breakdown for the billed application."""

    application: Literal[
        "structure_and_binding",
        "small_molecule_design",
        "small_molecule_library_screen",
        "protein_design",
        "protein_library_screen",
        "adme",
    ]

    cost_per_unit_usd: str
    """
    Estimated cost per displayed unit as a decimal string, rounded up to 4 decimal
    places. This may include token-size multipliers or generation overhead;
    estimated_cost_usd is the authoritative total.
    """

    num_units: int
    """Number of units shown for the estimate.

    For structure-and-binding, this is the requested number of samples. For protein
    and small-molecule design/screen endpoints, this is the requested number of
    proteins or molecules.
    """


class DesignEstimateCostResponse(BaseModel):
    """
    Estimate response with monetary values encoded as decimal strings to preserve precision.
    """

    breakdown: Breakdown
    """Cost breakdown for the billed application."""

    disclaimer: str

    estimated_cost_usd: str
    """Estimated total cost as a decimal string"""
