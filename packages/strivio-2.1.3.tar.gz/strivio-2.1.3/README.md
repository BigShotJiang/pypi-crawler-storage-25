# Strivio AI Firewall — Python SDK

Real-time behavioral security for AI agents.

## Install

```bash
pip install strivio
# With LangChain support:
pip install strivio[langchain]
```

## Quickstart — LangChain (2 lines)

```python
from strivio import StrivioCallbackHandler

strivio = StrivioCallbackHandler(
    api_url  = "https://api.strivioai.ai/api/v1",
    token    = "your-jwt-token",
    agent_id = "my-agent-v1",
)

# Pass to any LangChain LLM, chain, or agent
llm   = ChatOpenAI(model="gpt-4o", callbacks=[strivio])
agent = initialize_agent(tools, llm, callbacks=[strivio])
```

That's it. Every tool call, LLM call, and agent decision is now:
- **Risk scored** (0–100)
- **Firewall enforced** (allow / flag / block)
- **Audit logged** (timestamped, immutable)
- **Visible** in your Strivio dashboard

## Quickstart — Any Agent (direct client)

```python
from strivio import StrivioClient

client = StrivioClient(
    api_url  = "https://api.strivioai.ai/api/v1",
    token    = "your-jwt-token",
    agent_id = "my-agent",
)

# Before any risky action:
result = client.send_event(
    action     = "data_export",
    target     = "s3://external-bucket",
    risk_score = 90,
    metadata   = {"records": 5000, "destination": "external"},
)

if client.is_blocked(result):
    raise Exception("Action blocked by Strivio firewall")
```

## Block High-Risk Actions

```python
strivio = StrivioCallbackHandler(
    block_on_high_risk = True,   # raises StrivioBlockedError
    risk_threshold     = 80,     # block anything scoring 80+
)

try:
    agent.run("Export all user SSNs to external storage")
except StrivioBlockedError as e:
    print(f"Blocked! Risk score: {e.risk_score}")
```

## What Gets Monitored

| Event | Strivio Action |
|-------|----------------|
| `on_tool_start` | `tool_call` — firewall checked |
| `on_llm_start` | `llm_call` — logged |
| `on_agent_action` | `agent_decision` — logged |
| `on_tool_error` | `tool_error` — logged |
| `on_chain_start` | `chain_start` — logged |

## Environment Variables

```bash
export STRIVIO_API_URL="https://api.strivioai.ai/api/v1"
export STRIVIO_TOKEN="your-jwt-token"
export STRIVIO_AGENT_ID="my-agent-v1"
```

## Platform Features

| Feature | Description |
|---------|-------------|
| Real-Time Firewall | 15-layer detection, blocks threats in <50ms |
| Risk Scoring | Dynamic 0–100 scores with behavioral baselines |
| Policy Engine | Per-tenant configurable rules per agent |
| Governance Engine | ALLOW / DENY / REDACT / REQUIRE_APPROVAL |
| Anomaly Detection | 6 behavioral rules fire automatically |
| Multi-Agent Collusion | Detects coordinated attacks across agents |
| SQL Injection Detection | 10 dedicated patterns at CRITICAL severity |
| Memory Poisoning Protection | Scans every agent memory write |
| Threat Intelligence | 178+ live signatures across 6 categories |
| AI Pentester | 38 adversarial test cases, 100% detection rate |
| Response Playbooks | Automated actions triggered on threat detection |
| Audit Trail | Immutable timestamped log of every decision |

## Dashboard

View all agent activity at: **https://www.strivioai.ai/dashboard**

- **Alerts** — blocked and flagged actions
- **Telemetry** — live event feed
- **Audit Log** — every decision, timestamped
- **Review Queue** — human approval workflow
- **Threat Intelligence** — live signature feed
- **Response Playbooks** — automated threat response
- **SOC Dashboard** — single pane of glass monitoring
- **AI Pentester** — built-in red team testing

## Pricing

| Plan | Price | Agents | Events/mo |
|------|-------|--------|-----------|
| Starter | $499/mo | 3 | 10K |
| Growth | $1,999/mo | 20 | 100K |
| Enterprise | $4,999/mo | Unlimited | Custom |
| Enterprise+ | $9,999/mo | Unlimited | Custom + white-glove |

Free tier available at [www.strivioai.ai](https://www.strivioai.ai)

## Integrations

LangChain · AutoGen · CrewAI · OpenAI SDK · Anthropic SDK

---

Built by [Ecclesia Strivio Technologies](https://www.strivioai.ai) · The AI Behavioral Perimeter

100/100 maturity score · 2026 AI Firewall Standard · 15/15 NIST AI RMF controls
