"""Tests for Pydantic models in datasecops_cli.models.project_config."""
import pytest
from datasecops_cli.models.project_config import (
    DatasecopsConfig,
    DbtTarget,
    ProjectSettings,
    SourceControl,
    BranchType,
    EnvironmentBranch,
    ProjectProfile,
    CortexSkill,
    CortexSkillFile,
)


class TestDatasecopsConfig:
    def test_defaults(self):
        config = DatasecopsConfig()
        assert config.connection_name == ""
        assert config.app_database == ""
        assert config.profile_name == ""

    def test_with_values(self):
        config = DatasecopsConfig(
            connection_name="my_conn",
            app_database="MY_DB",
            profile_name="dev",
        )
        assert config.connection_name == "my_conn"
        assert config.app_database == "MY_DB"
        assert config.profile_name == "dev"


class TestDbtTarget:
    def test_defaults(self):
        target = DbtTarget()
        assert target.target_name == ""
        assert target.target_schema == "PUBLIC"
        assert target.is_default is False

    def test_with_values(self):
        target = DbtTarget(
            target_name="prod",
            branch_name="main",
            target_role="ADMIN",
            target_warehouse="PROD_WH",
            target_schema="ANALYTICS",
            is_default=True,
        )
        assert target.target_name == "prod"
        assert target.branch_name == "main"
        assert target.is_default is True


class TestProjectSettings:
    def test_defaults(self):
        settings = ProjectSettings()
        assert settings.project_dir == "./dbt"
        assert settings.profile_dir == "~/.dbt"
        assert settings.execution_mode == "dbt_cli"
        assert len(settings.targets) == 3

    def test_get_default_target(self):
        settings = ProjectSettings()
        default = settings.get_default_target()
        assert default is not None
        assert default.target_name == "dev"
        assert default.is_default is True

    def test_get_default_target_no_default(self):
        settings = ProjectSettings(targets=[
            DbtTarget(target_name="staging", is_default=False),
            DbtTarget(target_name="prod", is_default=False),
        ])
        # Falls back to first target
        default = settings.get_default_target()
        assert default.target_name == "staging"

    def test_get_default_target_empty(self):
        settings = ProjectSettings(targets=[])
        assert settings.get_default_target() is None

    def test_get_deployment_branches(self):
        settings = ProjectSettings()
        branches = settings.get_deployment_branches()
        assert "dev" in branches
        assert "test" in branches
        assert "prod" in branches

    def test_get_deployment_branches_excludes_empty(self):
        settings = ProjectSettings(targets=[
            DbtTarget(target_name="dev", branch_name="dev"),
            DbtTarget(target_name="local", branch_name=""),
        ])
        branches = settings.get_deployment_branches()
        assert branches == ["dev"]


class TestSourceControl:
    def test_defaults(self):
        sc = SourceControl()
        assert sc.branch_types == []
        assert sc.ticket_number_required is False
        assert sc.branch_format == "{branch_type}/{branch_name}"
        assert sc.source_control_platform == "GitHub"
        assert sc.environments == []

    def test_with_branch_types(self):
        sc = SourceControl(
            branch_types=[BranchType(name="feature", purpose="New features")],
            environments=[EnvironmentBranch(branch_name="main", purpose="Production")],
        )
        assert len(sc.branch_types) == 1
        assert sc.branch_types[0].name == "feature"
        assert len(sc.environments) == 1


class TestProjectProfile:
    def test_defaults(self):
        profile = ProjectProfile()
        assert profile.project_id == 0
        assert profile.dbt_version == "1.9"
        assert profile.model_types == []

    def test_with_values(self):
        profile = ProjectProfile(
            project_id=1,
            profile_name="analytics",
            project_name="Analytics Project",
            target_database="ANALYTICS_DB",
            dbt_version="1.8",
            model_types=["staging", "marts"],
        )
        assert profile.project_id == 1
        assert profile.profile_name == "analytics"
        assert profile.model_types == ["staging", "marts"]


class TestCortexSkill:
    def test_defaults(self):
        skill = CortexSkill()
        assert skill.skill_id == ""
        assert skill.version == "0.1.0"
        assert skill.category == "general"
        assert skill.enabled is True
        assert skill.files == []

    def test_with_files(self):
        skill = CortexSkill(
            skill_id="sk1",
            name="My Skill",
            files=[CortexSkillFile(filename="main.py", content="print('hi')")],
        )
        assert len(skill.files) == 1
        assert skill.files[0].filename == "main.py"
