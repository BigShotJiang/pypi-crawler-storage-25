"""Tests for datasecops_cli.utilities.file_utils."""
import pytest
from pathlib import Path
from datasecops_cli.utilities.file_utils import (
    ensure_dir,
    read_file,
    write_file,
    file_exists,
    find_files,
    get_dbt_profiles_dir,
    get_cortex_skills_dir,
)


class TestEnsureDir:
    def test_creates_directory(self, tmp_path):
        d = tmp_path / "new" / "nested"
        result = ensure_dir(d)
        assert d.exists()
        assert d.is_dir()
        assert result == d

    def test_existing_directory(self, tmp_path):
        result = ensure_dir(tmp_path)
        assert result == tmp_path


class TestReadFile:
    def test_reads_existing_file(self, tmp_path):
        f = tmp_path / "hello.txt"
        f.write_text("hello world", encoding="utf-8")
        assert read_file(f) == "hello world"

    def test_returns_empty_for_missing_file(self, tmp_path):
        f = tmp_path / "missing.txt"
        assert read_file(f) == ""


class TestWriteFile:
    def test_writes_content(self, tmp_path):
        f = tmp_path / "output.txt"
        write_file(f, "test content")
        assert f.read_text(encoding="utf-8") == "test content"

    def test_creates_parent_dirs(self, tmp_path):
        f = tmp_path / "a" / "b" / "output.txt"
        write_file(f, "nested")
        assert f.exists()
        assert f.read_text(encoding="utf-8") == "nested"


class TestFileExists:
    def test_existing_file(self, tmp_path):
        f = tmp_path / "exists.txt"
        f.write_text("x", encoding="utf-8")
        assert file_exists(f) is True

    def test_missing_file(self, tmp_path):
        assert file_exists(tmp_path / "nope.txt") is False

    def test_directory_returns_false(self, tmp_path):
        assert file_exists(tmp_path) is False


class TestFindFiles:
    def test_finds_matching_files(self, tmp_path):
        (tmp_path / "a.sql").write_text("select 1", encoding="utf-8")
        (tmp_path / "b.sql").write_text("select 2", encoding="utf-8")
        (tmp_path / "c.txt").write_text("not sql", encoding="utf-8")
        results = find_files(tmp_path, "*.sql")
        assert len(results) == 2
        assert all(p.suffix == ".sql" for p in results)

    def test_finds_nested_files(self, tmp_path):
        sub = tmp_path / "sub"
        sub.mkdir()
        (sub / "nested.yml").write_text("key: val", encoding="utf-8")
        results = find_files(tmp_path, "*.yml")
        assert len(results) == 1

    def test_returns_empty_for_no_matches(self, tmp_path):
        assert find_files(tmp_path, "*.xyz") == []


class TestPathHelpers:
    def test_dbt_profiles_dir(self):
        result = get_dbt_profiles_dir()
        assert result == Path.home() / ".dbt"

    def test_cortex_skills_dir(self):
        result = get_cortex_skills_dir()
        assert result == Path.home() / ".cortex" / "skills"
