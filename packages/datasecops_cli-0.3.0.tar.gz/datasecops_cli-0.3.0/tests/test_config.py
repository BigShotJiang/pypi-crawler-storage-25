"""Tests for datasecops_cli.config.Config."""
import pytest
from pathlib import Path
from datasecops_cli.config import Config


class TestConfigLoad:
    def test_load_success(self, tmp_path):
        """Config.load() succeeds with valid .datasecops.yml and dbt_project.yml."""
        (tmp_path / ".datasecops.yml").write_text(
            "connection_name: myconn\napp_database: MYDB\nprofile_name: dev\n",
            encoding="utf-8",
        )
        (tmp_path / "dbt_project.yml").write_text(
            "name: test_project\nprofile: analytics\n",
            encoding="utf-8",
        )

        config = Config()
        result = config.load(project_dir=tmp_path)

        assert result is True
        assert config.datasecops.connection_name == "myconn"
        assert config.datasecops.app_database == "MYDB"
        assert config.profile_name == "analytics"
        assert config.dbt_project_dir == tmp_path

    def test_load_no_datasecops_yml(self, tmp_path):
        """Config.load() fails when .datasecops.yml is missing."""
        config = Config()
        result = config.load(project_dir=tmp_path)
        assert result is False

    def test_load_missing_connection_name(self, tmp_path):
        """Config.load() fails when connection_name is empty string."""
        (tmp_path / ".datasecops.yml").write_text(
            "connection_name: ''\napp_database: MYDB\n",
            encoding="utf-8",
        )

        config = Config()
        result = config.load(project_dir=tmp_path)
        assert result is False

    def test_load_missing_app_database(self, tmp_path):
        """Config.load() fails when app_database is empty string."""
        (tmp_path / ".datasecops.yml").write_text(
            "connection_name: myconn\napp_database: ''\n",
            encoding="utf-8",
        )

        config = Config()
        result = config.load(project_dir=tmp_path)
        assert result is False

    def test_load_dbt_in_subdir(self, tmp_path):
        """Config resolves dbt_project_dir when dbt_project.yml is in dbt/ subdir."""
        (tmp_path / ".datasecops.yml").write_text(
            "connection_name: conn\napp_database: DB\nprofile_name: p\n",
            encoding="utf-8",
        )
        dbt_dir = tmp_path / "dbt"
        dbt_dir.mkdir()
        (dbt_dir / "dbt_project.yml").write_text(
            "name: sub\nprofile: sub_profile\n",
            encoding="utf-8",
        )

        config = Config()
        result = config.load(project_dir=tmp_path)

        assert result is True
        assert config.dbt_project_dir == dbt_dir
        assert config.profile_name == "sub_profile"

    def test_load_uses_datasecops_profile_name_as_fallback(self, tmp_path):
        """When no dbt_project.yml exists, profile_name comes from .datasecops.yml."""
        (tmp_path / ".datasecops.yml").write_text(
            "connection_name: conn\napp_database: DB\nprofile_name: fallback\n",
            encoding="utf-8",
        )

        config = Config()
        result = config.load(project_dir=tmp_path)

        assert result is True
        assert config.profile_name == "fallback"
