"""Smoke tests for package import and version."""


def test_package_imports():
    """Verify the package can be imported without errors."""
    import datasecops_cli
    assert hasattr(datasecops_cli, "__version__")


def test_version_is_string():
    from datasecops_cli import __version__
    assert isinstance(__version__, str)
    assert len(__version__) > 0


def test_models_importable():
    """Verify core models can be imported."""
    from datasecops_cli.models.project_config import (
        DatasecopsConfig,
        ProjectSettings,
        DbtTarget,
        SourceControl,
        ProjectProfile,
    )
    assert DatasecopsConfig is not None
    assert ProjectSettings is not None
    assert DbtTarget is not None
    assert SourceControl is not None
    assert ProjectProfile is not None
