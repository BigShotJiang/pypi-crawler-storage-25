"""Tests for datasecops_cli.utilities.yaml_utils."""
import pytest
from pathlib import Path
from datasecops_cli.utilities.yaml_utils import (
    read_yaml,
    write_yaml,
    read_datasecops_config,
    read_dbt_project,
    get_profile_name,
)


class TestReadYaml:
    def test_read_existing_file(self, tmp_path):
        f = tmp_path / "test.yml"
        f.write_text("key: value\nnested:\n  a: 1\n", encoding="utf-8")
        result = read_yaml(f)
        assert result == {"key": "value", "nested": {"a": 1}}

    def test_read_nonexistent_file(self, tmp_path):
        f = tmp_path / "missing.yml"
        assert read_yaml(f) is None

    def test_read_empty_file(self, tmp_path):
        f = tmp_path / "empty.yml"
        f.write_text("", encoding="utf-8")
        result = read_yaml(f)
        assert result is None


class TestWriteYaml:
    def test_write_creates_file(self, tmp_path):
        f = tmp_path / "output.yml"
        write_yaml(f, {"hello": "world"})
        assert f.exists()
        content = f.read_text(encoding="utf-8")
        assert "hello: world" in content

    def test_write_creates_parent_dirs(self, tmp_path):
        f = tmp_path / "sub" / "dir" / "output.yml"
        write_yaml(f, {"key": "val"})
        assert f.exists()

    def test_write_sort_keys(self, tmp_path):
        f = tmp_path / "sorted.yml"
        write_yaml(f, {"b": 2, "a": 1}, sort_keys=True)
        content = f.read_text(encoding="utf-8")
        assert content.index("a:") < content.index("b:")


class TestReadDatasecopsConfig:
    def test_reads_config(self, tmp_path):
        cfg = tmp_path / ".datasecops.yml"
        cfg.write_text(
            "connection_name: myconn\napp_database: MYDB\nprofile_name: dev\n",
            encoding="utf-8",
        )
        result = read_datasecops_config(tmp_path)
        assert result["connection_name"] == "myconn"
        assert result["app_database"] == "MYDB"

    def test_returns_none_if_missing(self, tmp_path):
        assert read_datasecops_config(tmp_path) is None


class TestReadDbtProject:
    def test_reads_from_root(self, tmp_path):
        f = tmp_path / "dbt_project.yml"
        f.write_text("name: my_project\nprofile: analytics\n", encoding="utf-8")
        result = read_dbt_project(tmp_path)
        assert result["name"] == "my_project"
        assert result["profile"] == "analytics"

    def test_reads_from_dbt_subdir(self, tmp_path):
        dbt_dir = tmp_path / "dbt"
        dbt_dir.mkdir()
        f = dbt_dir / "dbt_project.yml"
        f.write_text("name: sub_project\nprofile: sub\n", encoding="utf-8")
        result = read_dbt_project(tmp_path)
        assert result["name"] == "sub_project"

    def test_returns_none_if_missing(self, tmp_path):
        assert read_dbt_project(tmp_path) is None


class TestGetProfileName:
    def test_returns_profile(self, tmp_path):
        f = tmp_path / "dbt_project.yml"
        f.write_text("profile: my_profile\n", encoding="utf-8")
        assert get_profile_name(tmp_path) == "my_profile"

    def test_returns_empty_if_no_project(self, tmp_path):
        assert get_profile_name(tmp_path) == ""
