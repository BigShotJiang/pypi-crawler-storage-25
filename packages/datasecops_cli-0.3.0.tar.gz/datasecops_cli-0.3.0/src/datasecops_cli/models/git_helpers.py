from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

@dataclass
class GitBranchState:
    is_dirty: bool = False
    commits_behind_main: int = 0
    syncs_ahead: int = 0
    syncs_behind: int = 0
    uncommitted_file_count: int = 0
    last_reset: Optional[datetime] = None
    remote_exists: bool = True
    
    def should_reset(self) -> bool:
        if self.last_reset is None:
            return True
        return (datetime.now() - self.last_reset).total_seconds() > 60

@dataclass
class GitCommitHelper:
    file: str = ""
    checked: bool = True

@dataclass 
class GitBranchComparison:
    local: str = ""
    remote: str = ""
    is_current: bool = False
