from pydantic import BaseModel, Field
from typing import Optional

class DatasecopsConfig(BaseModel):
    """Local .datasecops.yml config."""
    connection_name: str = ""
    app_database: str = ""
    profile_name: str = ""

class DbtTarget(BaseModel):
    target_name: str = ""
    branch_name: str = ""
    target_role: str = ""
    target_warehouse: str = ""
    target_schema: str = "PUBLIC"
    is_default: bool = False

class ProjectSettings(BaseModel):
    project_dir: str = "./dbt"
    profile_dir: str = "~/.dbt"
    execution_mode: str = "dbt_cli"
    targets: list[DbtTarget] = Field(default_factory=lambda: [
        DbtTarget(target_name="dev", branch_name="dev", target_role="DEVELOPERS", target_warehouse="DEV_WH", is_default=True),
        DbtTarget(target_name="test", branch_name="test", target_role="DATAOPS_ADMIN", target_warehouse="DATAOPS_WH"),
        DbtTarget(target_name="prod", branch_name="prod", target_role="DATAOPS_ADMIN", target_warehouse="DATAOPS_WH"),
    ])
    sources_database_prefix: list[str] = Field(default_factory=list)
    
    def get_default_target(self) -> Optional[DbtTarget]:
        for t in self.targets:
            if t.is_default:
                return t
        return self.targets[0] if self.targets else None
    
    def get_deployment_branches(self) -> list[str]:
        return [t.branch_name for t in self.targets if t.branch_name]

class BranchType(BaseModel):
    name: str = ""
    purpose: str = ""
    lifecycle: str = ""
    use_case: str = ""

class EnvironmentBranch(BaseModel):
    branch_name: str = ""
    purpose: str = ""
    merge_into_using: str = ""
    auto_released_to_environment: str = ""

class SourceControl(BaseModel):
    branch_types: list[BranchType] = Field(default_factory=list)
    ticket_number_required: bool = False
    branch_format: str = "{branch_type}/{branch_name}"
    source_control_platform: str = "GitHub"
    environments: list[EnvironmentBranch] = Field(default_factory=list)

class ProjectProfile(BaseModel):
    project_id: int = 0
    profile_name: str = ""
    project_name: str = ""
    project_description: str = ""
    model_types: list[str] = Field(default_factory=list)
    downstream_projects: list[str] = Field(default_factory=list)
    git_url: str = ""
    target_database: str = ""
    dbt_version: str = "1.9"
    dbt_packages: list[str] = Field(default_factory=list)

class DbtPackage(BaseModel):
    name: str = ""
    source: str = "git"
    url: str = ""
    description: str = ""
    latest_version: str = ""

class CortexSkillFile(BaseModel):
    filename: str = ""
    content: str = ""

class CortexSkill(BaseModel):
    skill_id: str = ""
    name: str = ""
    description: str = ""
    version: str = "0.1.0"
    category: str = "general"
    files: list[CortexSkillFile] = Field(default_factory=list)
    enabled: bool = True
