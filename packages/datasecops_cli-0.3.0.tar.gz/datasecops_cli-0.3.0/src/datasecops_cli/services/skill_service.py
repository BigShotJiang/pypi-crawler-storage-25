from pathlib import Path
from typing import Optional

from datasecops_cli.services.snowflake_service import SnowflakeService
from datasecops_cli.models.project_config import CortexSkill, CortexSkillFile
from datasecops_cli.utilities.display import info_line, success_line, error_line, warning_line
from datasecops_cli.utilities.file_utils import write_file, ensure_dir, get_cortex_skills_dir


class SkillService:
    """Manages Cortex Code skill installation."""
    
    def __init__(self, snowflake_service: SnowflakeService):
        self.sf = snowflake_service
    
    def get_available_skills(self) -> list[CortexSkill]:
        raw = self.sf.get_framework_config("CORTEX_SKILLS")
        if not raw:
            return []
        skills_data = raw.get("skills", [])
        result = []
        for s in skills_data:
            if isinstance(s, dict):
                files = [CortexSkillFile(**f) for f in s.get("files", []) if isinstance(f, dict)]
                skill = CortexSkill(
                    skill_id=s.get("skill_id", ""),
                    name=s.get("name", ""),
                    description=s.get("description", ""),
                    version=s.get("version", "0.1.0"),
                    category=s.get("category", "general"),
                    files=files,
                    enabled=s.get("enabled", True),
                )
                if skill.enabled:
                    result.append(skill)
        return result
    
    def list_skills(self) -> None:
        skills = self.get_available_skills()
        if not skills:
            info_line("No skills available in the native app")
            return
        
        info_line(f"Available Cortex Code skills ({len(skills)}):")
        for s in skills:
            installed = self._is_installed(s.skill_id)
            status = "installed" if installed else "not installed"
            info_line(f"  [{s.category}] {s.name} v{s.version} — {status}")
            if s.description:
                info_line(f"           {s.description}")
    
    def install_skill(self, skill: CortexSkill, target_dir: Path = None) -> bool:
        target = target_dir or get_cortex_skills_dir()
        skill_dir = target / skill.skill_id
        ensure_dir(skill_dir)
        
        for f in skill.files:
            if f.filename and f.content:
                write_file(skill_dir / f.filename, f.content)
        
        success_line(f"Installed skill: {skill.name} v{skill.version} -> {skill_dir}")
        return True
    
    def install_all(self, target_dir: Path = None) -> int:
        skills = self.get_available_skills()
        count = 0
        for skill in skills:
            if self.install_skill(skill, target_dir):
                count += 1
        success_line(f"Installed {count} skill(s)")
        return count
    
    def update_skills(self, target_dir: Path = None) -> int:
        skills = self.get_available_skills()
        target = target_dir or get_cortex_skills_dir()
        count = 0
        for skill in skills:
            if self._is_installed(skill.skill_id, target):
                self.install_skill(skill, target)
                count += 1
        success_line(f"Updated {count} skill(s)")
        return count
    
    def _is_installed(self, skill_id: str, target_dir: Path = None) -> bool:
        target = target_dir or get_cortex_skills_dir()
        return (target / skill_id).exists()
