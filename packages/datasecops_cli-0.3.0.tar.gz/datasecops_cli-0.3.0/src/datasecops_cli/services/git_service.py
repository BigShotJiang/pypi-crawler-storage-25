from pathlib import Path
from typing import Optional
from git import Repo, GitCommandError

from datasecops_cli.models.git_helpers import GitCommitHelper
from datasecops_cli.utilities.display import info_line, error_line, success_line, warning_line


class GitService:
    """Git operations via GitPython."""
    
    def __init__(self, repo_path: Path):
        self.repo = Repo(repo_path)
    
    def get_current_branch(self) -> str:
        try:
            return self.repo.active_branch.name
        except TypeError:
            return "DETACHED HEAD"
    
    def is_dirty(self) -> bool:
        return self.repo.is_dirty(untracked_files=True)
    
    def get_uncommitted_file_count(self) -> int:
        return len(self.repo.index.diff(None)) + len(self.repo.untracked_files)
    
    def get_changed_files(self) -> list[GitCommitHelper]:
        return [GitCommitHelper(file=d.a_path) for d in self.repo.index.diff(None)]
    
    def get_new_files(self) -> list[GitCommitHelper]:
        return [GitCommitHelper(file=f) for f in self.repo.untracked_files]
    
    def get_local_branches(self) -> dict[str, str]:
        return {b.name: b.name for b in self.repo.branches}
    
    def get_remote_branches(self) -> dict[str, str]:
        self.repo.remotes.origin.fetch()
        return {
            ref.remote_head: ref.remote_head
            for ref in self.repo.remotes.origin.refs
            if ref.remote_head != "HEAD"
        }
    
    def create_branch(self, branch_type: str, ticket: str, name: str) -> None:
        branch_name = f"{branch_type}/{ticket}_{name}" if ticket else f"{branch_type}/{name}"
        info_line(f"Creating branch: {branch_name}")
        self.repo.remotes.origin.fetch()
        new_branch = self.repo.create_head(branch_name, "origin/main")
        new_branch.checkout()
        self.repo.remotes.origin.push(branch_name, set_upstream=True)
        success_line(f"Branch {branch_name} created and checked out")
    
    def checkout_branch(self, remote_name: str) -> None:
        info_line(f"Checking out: {remote_name}")
        self.repo.remotes.origin.fetch()
        try:
            self.repo.git.checkout(remote_name)
        except GitCommandError:
            self.repo.git.checkout("-b", remote_name, f"origin/{remote_name}")
        success_line(f"Switched to {remote_name}")
    
    def switch_branch(self, name: str) -> None:
        self.repo.branches[name].checkout()
        success_line(f"Switched to {name}")
    
    def delete_branch(self, name: str) -> None:
        if name == self.get_current_branch():
            error_line("Cannot delete the current branch")
            return
        self.repo.delete_head(name, force=True)
        try:
            self.repo.remotes.origin.push(refspec=f":{name}")
        except GitCommandError:
            pass
        success_line(f"Deleted branch {name}")
    
    def commit_changes(self, message: str) -> None:
        self.repo.git.add(A=True)
        self.repo.index.commit(message)
        success_line(f"Committed: {message}")
    
    def push_branch(self) -> None:
        branch = self.get_current_branch()
        info_line(f"Pushing {branch}...")
        self.repo.remotes.origin.push(branch)
        success_line(f"Pushed {branch}")
    
    def pull_branch(self) -> None:
        branch = self.get_current_branch()
        info_line(f"Pulling {branch}...")
        self.repo.remotes.origin.pull(branch)
        success_line(f"Pulled {branch}")
    
    def push_branch_to_destination(self, destination: str, force: bool = False) -> None:
        current = self.get_current_branch()
        info_line(f"Pushing {current} to {destination}...")
        refspec = f"{current}:{destination}"
        self.repo.remotes.origin.push(refspec=refspec, force=force)
        success_line(f"Pushed to {destination}")
    
    def rebase_with_main(self) -> bool:
        try:
            self.repo.remotes.origin.fetch()
            self.repo.git.rebase("origin/main")
            success_line("Rebase with main completed")
            return True
        except GitCommandError as e:
            error_line(f"Rebase conflict: {e}")
            warning_line("Resolve conflicts then use 'rebase continue' or 'rebase abort'")
            return False
    
    def rebase_continue(self) -> None:
        self.repo.git.rebase("--continue")
        success_line("Rebase continued")
    
    def rebase_abort(self) -> None:
        self.repo.git.rebase("--abort")
        success_line("Rebase aborted")
    
    def squash_and_rebase(self) -> bool:
        try:
            self.repo.remotes.origin.fetch()
            main_commit = self.repo.commit("origin/main")
            current = self.get_current_branch()
            self.repo.git.reset("--soft", main_commit.hexsha)
            self.repo.index.commit(f"squash: {current}")
            self.repo.git.rebase("origin/main")
            success_line("Squash and rebase completed")
            return True
        except GitCommandError as e:
            error_line(f"Squash rebase failed: {e}")
            return False
    
    def squash_merge_into_test(self) -> bool:
        current = self.get_current_branch()
        try:
            self.repo.remotes.origin.fetch()
            self.repo.git.checkout("test")
            self.repo.remotes.origin.pull("test")
            self.repo.git.merge("--squash", current)
            self.repo.index.commit(f"squash merge: {current} into test")
            self.repo.remotes.origin.push("test")
            self.repo.git.checkout(current)
            success_line(f"Squash merged {current} into test")
            return True
        except GitCommandError as e:
            error_line(f"Squash merge failed: {e}")
            try:
                self.repo.git.checkout(current)
            except Exception:
                pass
            return False
    
    def cherry_pick_from_test(self, commit_sha: str) -> bool:
        try:
            self.repo.git.cherry_pick(commit_sha)
            success_line(f"Cherry-picked {commit_sha[:8]}")
            return True
        except GitCommandError as e:
            error_line(f"Cherry-pick failed: {e}")
            return False
    
    def get_test_commits(self, limit: int = 20) -> list[dict]:
        try:
            self.repo.remotes.origin.fetch()
            commits = list(self.repo.iter_commits("origin/test", max_count=limit))
            return [{"sha": c.hexsha, "message": c.message.strip(), "author": str(c.author), "date": str(c.committed_datetime)} for c in commits]
        except Exception:
            return []
    
    def prune_remote_branches(self) -> None:
        self.repo.remotes.origin.fetch(prune=True)
        success_line("Pruned remote branches")
    
    def reset_to_main(self) -> None:
        self.repo.remotes.origin.fetch()
        self.repo.git.checkout("main")
        self.repo.git.reset("--hard", "origin/main")
        # Delete all local branches except main
        for branch in self.repo.branches:
            if branch.name != "main":
                self.repo.delete_head(branch, force=True)
        success_line("Reset to main completed")
