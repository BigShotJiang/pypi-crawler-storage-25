from pathlib import Path
from typing import Optional

from datasecops_cli.models.project_config import (
    DatasecopsConfig, ProjectSettings, SourceControl, ProjectProfile, DbtTarget
)
from datasecops_cli.utilities.yaml_utils import read_datasecops_config, read_dbt_project
from datasecops_cli.utilities.display import error_line, info_line


class Config:
    """Central configuration for the CLI, loaded from .datasecops.yml and native app."""
    
    def __init__(self):
        self.datasecops: DatasecopsConfig = DatasecopsConfig()
        self.project_settings: ProjectSettings = ProjectSettings()
        self.source_control: SourceControl = SourceControl()
        self.profile: Optional[ProjectProfile] = None
        self.all_profiles: list[ProjectProfile] = []
        self.project_dir: Path = Path.cwd()
        self.dbt_project_dir: Path = Path.cwd()
        self.profile_name: str = ""
    
    def load(self, project_dir: Path = None) -> bool:
        """Load configuration from .datasecops.yml and dbt_project.yml."""
        self.project_dir = project_dir or Path.cwd()
        
        # Load .datasecops.yml
        raw = read_datasecops_config(self.project_dir)
        if raw is None:
            error_line("No .datasecops.yml found. Run setup.sh/setup.ps1 first.")
            return False
        
        self.datasecops = DatasecopsConfig(
            connection_name=raw.get("connection_name", ""),
            app_database=raw.get("app_database", ""),
            profile_name=raw.get("profile_name", ""),
        )
        
        if not self.datasecops.connection_name or not self.datasecops.app_database:
            error_line(".datasecops.yml is missing connection_name or app_database.")
            return False
        
        # Load dbt_project.yml to get profile name
        dbt_data = read_dbt_project(self.project_dir)
        if dbt_data:
            self.profile_name = dbt_data.get("profile", self.datasecops.profile_name)
        else:
            self.profile_name = self.datasecops.profile_name
        
        # Resolve dbt project directory
        for candidate in [self.project_dir / "dbt", self.project_dir]:
            if (candidate / "dbt_project.yml").exists():
                self.dbt_project_dir = candidate
                break
        
        return True
    
    def load_from_native_app(self, snowflake_service) -> bool:
        """Load configuration from the native app database."""
        try:
            # Load project settings
            raw = snowflake_service.get_framework_config("PROJECT")
            if raw:
                self.project_settings = ProjectSettings(**{k: v for k, v in raw.items() if k in ProjectSettings.model_fields})
            
            # Load source control
            raw = snowflake_service.get_framework_config("SOURCE_CONTROL")
            if raw:
                self.source_control = SourceControl(**{k: v for k, v in raw.items() if k in SourceControl.model_fields})
            
            # Load project profiles
            profiles_data = snowflake_service.get_project_profiles()
            if profiles_data:
                self.all_profiles = [ProjectProfile(**{k.lower(): v for k, v in p.items()}) for p in profiles_data]
            
            # Find the active profile
            if self.profile_name:
                for p in self.all_profiles:
                    if p.profile_name == self.profile_name:
                        self.profile = p
                        break
            
            if not self.profile and self.all_profiles:
                self.profile = self.all_profiles[0]
                self.profile_name = self.profile.profile_name
            
            return True
        except Exception as e:
            error_line(f"Failed to load from native app: {e}")
            return False
    
    def get_dbt_profiles_dir(self) -> Path:
        return Path(self.project_settings.profile_dir).expanduser()
    
    def get_default_target(self) -> Optional[DbtTarget]:
        return self.project_settings.get_default_target()
    
    def get_deployment_branches(self) -> dict[str, str]:
        return {b: b for b in self.project_settings.get_deployment_branches()}
