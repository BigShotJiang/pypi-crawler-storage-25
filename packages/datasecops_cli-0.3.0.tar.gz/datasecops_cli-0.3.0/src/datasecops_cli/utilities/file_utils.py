from pathlib import Path


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def read_file(path: Path) -> str:
    if path.exists():
        return path.read_text(encoding="utf-8")
    return ""


def write_file(path: Path, content: str) -> None:
    ensure_dir(path.parent)
    path.write_text(content, encoding="utf-8")


def file_exists(path: Path) -> bool:
    return path.exists() and path.is_file()


def find_files(root: Path, pattern: str) -> list[Path]:
    return sorted(root.rglob(pattern))


def get_dbt_profiles_dir() -> Path:
    return Path.home() / ".dbt"


def get_cortex_skills_dir() -> Path:
    return Path.home() / ".cortex" / "skills"
