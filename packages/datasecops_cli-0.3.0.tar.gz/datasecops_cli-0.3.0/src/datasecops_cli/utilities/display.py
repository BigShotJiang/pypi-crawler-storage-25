import os
from colorama import init, Fore, Style

init(autoreset=True)


def clear():
    os.system('cls' if os.name == 'nt' else 'clear')


def print_detail(message: str, color: str = Fore.WHITE) -> None:
    print(Style.NORMAL + color + message)


def print_long_line(color: str = Fore.GREEN) -> None:
    print_detail("=" * 76, color)


def section_header(message: str, active_profile: str = None, current_branch: str = None) -> None:
    print_long_line(Fore.GREEN)
    print_detail(message, Fore.GREEN)
    print_long_line(Fore.GREEN)
    if active_profile:
        print_detail(f"  Profile: {active_profile}", Fore.GREEN)
    if current_branch:
        print_detail(f"  Branch:  {current_branch}", Fore.GREEN)
    if active_profile or current_branch:
        print_long_line(Fore.GREEN)


def display_action_header(message: str) -> None:
    clear()
    print_long_line(Fore.GREEN)
    print_detail(f"  {message}", Fore.GREEN)
    print_long_line(Fore.GREEN)


def menu_option(number: int, text: str) -> None:
    print_detail(f"  [{number}] {text}", Fore.WHITE)


def info_line(message: str) -> None:
    print_detail(message, Fore.BLUE)


def warning_line(message: str) -> None:
    print_detail(f"WARNING: {message}", Fore.YELLOW)


def error_line(message: str) -> None:
    print_detail(f"ERROR: {message}", Fore.RED)


def success_line(message: str) -> None:
    print_detail(message, Fore.GREEN)


def complete_action(message: str = None) -> None:
    print_long_line()
    input(message or "Press Enter to continue...")


def get_input_string(message: str, allow_empty: bool = False) -> str:
    while True:
        result = input(message)
        if result.strip() or allow_empty:
            return result.strip()


def get_input_number(message: str) -> int:
    while True:
        result = input(message).strip()
        if result.isdigit() or (result.startswith('-') and result[1:].isdigit()):
            return int(result)
        if not result:
            return 0


def get_input_true_false(message: str, default: str = "n") -> bool:
    while True:
        result = input(f"{message} (y/n, default: {default}): ").strip().lower()
        if not result:
            result = default
        if result in ("y", "n"):
            return result == "y"


def get_input_string_or_default(message: str, default_value: str) -> str:
    result = input(f"{message} (default: '{default_value}'): ").strip()
    return result if result else default_value


def select_from_dict(options: dict[str, str], select_name: str, add_back: bool = True) -> str:
    """Numbered selection from a dict. Returns the selected value. '0' returns 'back'."""
    items = list(options.items())
    if add_back and "back" not in options:
        items.append(("back", "back"))

    for idx, (key, _) in enumerate(items):
        if key == "back":
            print_detail(f"  [0] {key}", Fore.WHITE)
        else:
            print_detail(f"  [{idx + 1}] {key}", Fore.WHITE)

    while True:
        raw = get_input_string(f"Select {select_name}: ")
        if raw == "0":
            return "back"
        try:
            num = int(raw) - 1
            if 0 <= num < len(items) and items[num][0] != "back":
                info_line(f"Selected {select_name}: {items[num][0]}")
                return items[num][1]
        except ValueError:
            pass
        warning_line(f"Please select a valid {select_name} number")


def select_from_list(options: list[str], select_name: str, add_back: bool = True) -> str:
    """Numbered selection from a list. Returns the selected value."""
    d = {opt: opt for opt in options}
    return select_from_dict(d, select_name, add_back)
