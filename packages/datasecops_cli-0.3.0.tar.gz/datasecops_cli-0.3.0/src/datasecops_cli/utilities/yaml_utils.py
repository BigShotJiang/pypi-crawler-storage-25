from pathlib import Path
from typing import Any, Optional
import yaml


def read_yaml(path: Path) -> Optional[dict]:
    if not path.exists():
        return None
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def write_yaml(path: Path, data: Any, sort_keys: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        yaml.dump(data, f, default_flow_style=False, sort_keys=sort_keys)


def read_datasecops_config(project_dir: Path) -> Optional[dict]:
    return read_yaml(project_dir / ".datasecops.yml")


def write_datasecops_config(project_dir: Path, config: dict) -> None:
    write_yaml(project_dir / ".datasecops.yml", config)


def read_dbt_project(project_dir: Path) -> Optional[dict]:
    for name in ["dbt_project.yml", "dbt/dbt_project.yml"]:
        p = project_dir / name
        if p.exists():
            return read_yaml(p)
    return None


def get_profile_name(project_dir: Path) -> str:
    data = read_dbt_project(project_dir)
    if data:
        return data.get("profile", "")
    return ""
