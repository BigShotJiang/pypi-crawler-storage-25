from datasecops_cli.services.git_service import GitService
from datasecops_cli.models.project_config import SourceControl
from datasecops_cli.utilities.display import (
    clear, section_header, display_action_header, menu_option,
    get_input_number, get_input_string, get_input_true_false,
    complete_action, info_line, error_line, warning_line,
    select_from_dict, select_from_list
)


class GitOperationsMenu:
    def __init__(self, git_service: GitService, source_control: SourceControl,
                 deployment_branches: dict[str, str], profile_name: str):
        self.git = git_service
        self.source_control = source_control
        self.deployment_branches = deployment_branches
        self.profile_name = profile_name
    
    def show(self) -> None:
        self._menu()
        option = get_input_number("Choose an option: ")
        while option != 0:
            if option == 1:
                self._branch_menu()
            elif option == 2:
                self._commit()
            elif option == 3:
                self._push()
            elif option == 4:
                self._pull()
            elif option == 5:
                self._rebase_menu()
            elif option == 6:
                self._deploy()
            elif option == 7:
                self._squash_merge_test()
            elif option == 8:
                self._cherry_pick_test()
            self._menu()
            option = get_input_number("Choose an option: ")
    
    def _menu(self) -> None:
        clear()
        section_header("Git Operations", self.profile_name, self.git.get_current_branch())
        menu_option(1, "branching         - Manage branches")
        menu_option(2, "commit            - Commit changes")
        menu_option(3, "push              - Push to remote")
        menu_option(4, "pull              - Pull from remote")
        menu_option(5, "rebase            - Rebase with main")
        menu_option(6, "deploy            - Deploy to environment")
        menu_option(7, "squash to test    - Squash merge into test")
        menu_option(8, "cherry-pick test  - Cherry-pick commits from test")
        menu_option(0, "back              - Return to main menu")
    
    def _branch_menu(self) -> None:
        clear()
        display_action_header("Branch Management")
        menu_option(1, "new      - Create new branch")
        menu_option(2, "checkout - Checkout remote branch")
        menu_option(3, "switch   - Switch to local branch")
        menu_option(4, "delete   - Delete local branch")
        menu_option(5, "prune    - Prune remote branches")
        menu_option(6, "reset    - Reset to main")
        menu_option(0, "back     - Return to git menu")
        option = get_input_number("Choose an option: ")
        if option == 1:
            self._create_branch()
        elif option == 2:
            branches = self.git.get_remote_branches()
            if branches:
                selected = select_from_dict(branches, "branch")
                if selected != "back":
                    self.git.checkout_branch(selected)
            else:
                info_line("No remote branches found")
        elif option == 3:
            branches = self.git.get_local_branches()
            selected = select_from_dict(branches, "branch")
            if selected != "back":
                self.git.switch_branch(selected)
        elif option == 4:
            branches = self.git.get_local_branches()
            selected = select_from_dict(branches, "branch")
            if selected != "back":
                self.git.delete_branch(selected)
        elif option == 5:
            self.git.prune_remote_branches()
        elif option == 6:
            if get_input_true_false("This will delete all local branches. Continue?", "n"):
                self.git.reset_to_main()
        complete_action()
    
    def _create_branch(self) -> None:
        branch_types = {bt.name: bt.name for bt in self.source_control.branch_types}
        if not branch_types:
            branch_types = {"feature": "feature", "bugfix": "bugfix", "hotfix": "hotfix"}
        
        selected_type = select_from_dict(branch_types, "branch type")
        if selected_type == "back":
            return
        
        ticket = ""
        if self.source_control.ticket_number_required:
            ticket = get_input_string("Enter ticket number: ")
            if ticket == "0":
                return
        else:
            ticket = get_input_string("Enter ticket number (or press Enter to skip): ", allow_empty=True)
        
        name = get_input_string("Enter branch name: ")
        if name == "0":
            return
        
        self.git.create_branch(selected_type, ticket, name.replace(" ", "-").lower())
    
    def _commit(self) -> None:
        display_action_header("Commit Changes")
        if not self.git.is_dirty():
            info_line("No changes to commit")
            complete_action()
            return
        
        info_line(f"{self.git.get_uncommitted_file_count()} change(s) detected")
        for f in self.git.get_changed_files():
            info_line(f"  M {f.file}")
        for f in self.git.get_new_files():
            info_line(f"  + {f.file}")
        
        message = get_input_string("Enter commit message (0 to cancel): ")
        if message == "0":
            return
        
        self.git.commit_changes(message)
        self.git.push_branch()
        complete_action()
    
    def _push(self) -> None:
        display_action_header("Push")
        self.git.push_branch()
        complete_action()
    
    def _pull(self) -> None:
        display_action_header("Pull")
        self.git.pull_branch()
        complete_action()
    
    def _rebase_menu(self) -> None:
        clear()
        display_action_header("Rebase Options")
        menu_option(1, "rebase           - Standard rebase with main")
        menu_option(2, "squash & rebase  - Squash commits then rebase")
        menu_option(3, "continue         - Continue after resolving conflicts")
        menu_option(4, "abort            - Abort rebase")
        menu_option(0, "back             - Return to git menu")
        option = get_input_number("Choose an option: ")
        if option == 1:
            self.git.rebase_with_main()
        elif option == 2:
            self.git.squash_and_rebase()
        elif option == 3:
            self.git.rebase_continue()
        elif option == 4:
            self.git.rebase_abort()
        complete_action()
    
    def _deploy(self) -> None:
        display_action_header("Deploy to Environment")
        if not self.deployment_branches:
            error_line("No deployment branches configured")
            complete_action()
            return
        
        selected = select_from_dict(self.deployment_branches, "environment")
        if selected == "back":
            return
        
        current = self.git.get_current_branch()
        if selected.lower() == "prod" and current.lower() != "main":
            warning_line("Production deployments must come from the main branch")
            if get_input_true_false("Switch to main and deploy?", "n"):
                self.git.checkout_branch("main")
                self.git.pull_branch()
            else:
                return
        
        force = selected.lower() != "prod"
        self.git.push_branch_to_destination(selected, force=force)
        complete_action()
    
    def _squash_merge_test(self) -> None:
        display_action_header("Squash Merge into Test")
        current = self.git.get_current_branch()
        info_line(f"This will squash merge {current} into the test branch")
        if get_input_true_false("Continue?", "n"):
            self.git.squash_merge_into_test()
        complete_action()
    
    def _cherry_pick_test(self) -> None:
        display_action_header("Cherry-pick from Test")
        commits = self.git.get_test_commits()
        if not commits:
            info_line("No commits found on test branch")
            complete_action()
            return
        
        info_line("Recent commits on test:")
        for i, c in enumerate(commits):
            info_line(f"  [{i+1}] {c['sha'][:8]} - {c['message'][:60]}")
        
        choice = get_input_number("Select commit number (0 to cancel): ")
        if 0 < choice <= len(commits):
            self.git.cherry_pick_from_test(commits[choice-1]["sha"])
        complete_action()
