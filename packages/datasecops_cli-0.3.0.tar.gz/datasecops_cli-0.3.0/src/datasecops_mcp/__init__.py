"""DataSecOps Framework MCP Server - exposes governance config as MCP tools."""
