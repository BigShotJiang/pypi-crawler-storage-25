"""DataSecOps Framework MCP Server.

Exposes the Snowflake Native App governance configuration as MCP tools,
allowing AI coding assistants to access branching rules, linting config,
dbt packages, project profiles, and deployment settings in real-time.
"""

import json
import logging

from mcp.server.fastmcp import FastMCP

from datasecops_mcp.connection import get_snowflake_service

logger = logging.getLogger(__name__)

mcp = FastMCP("datasecops-framework")


# --- Configuration Tools ---


@mcp.tool()
def get_branching_rules() -> str:
    """Get the source control branching rules enforced by the framework.

    Returns branch types (feature, hotfix, etc.), naming conventions,
    environment branches, merge strategies, and whether ticket numbers are required.
    Use this to understand how branches should be created and named.
    """
    sf = get_snowflake_service()
    raw = sf.get_framework_config("SOURCE_CONTROL")
    if not raw:
        return "No source control configuration found in native app"

    result = {
        "branch_types": raw.get("branch_types", []),
        "ticket_number_required": raw.get("ticket_number_required", False),
        "branch_format": raw.get("branch_format", "{branch_type}/{branch_name}"),
        "source_control_platform": raw.get("source_control_platform", "GitHub"),
        "environments": raw.get("environments", []),
    }
    return json.dumps(result, indent=2)


@mcp.tool()
def get_linting_rules() -> str:
    """Get the SQLFluff linting rules configured for this project.

    Returns the active SQL linting rules including dialect, indentation settings,
    and enabled rule codes. Use this when writing or reviewing SQL to ensure
    compliance with the team's standards.
    """
    sf = get_snowflake_service()
    raw = sf.get_framework_config("SQLFLUFF_RULES")
    if not raw:
        return "No SQLFluff rules found in native app"

    return json.dumps(raw, indent=2)


@mcp.tool()
def get_dbt_packages() -> str:
    """Get the approved dbt packages and their versions for this project.

    Returns the list of approved packages (git repos or dbt hub packages)
    with their pinned versions. Use this when adding dependencies to ensure
    only approved packages at correct versions are used.
    """
    sf = get_snowflake_service()
    raw = sf.get_framework_config("DBT_PACKAGES")
    if not raw:
        return "No dbt packages configuration found in native app"

    return json.dumps(raw, indent=2)


@mcp.tool()
def get_pipeline_config(platform: str = "github") -> str:
    """Get the CI/CD pipeline configuration for the specified platform.

    Args:
        platform: Either "github" or "azure_devops". Defaults to "github".

    Returns the pipeline YAML templates that should be used for CI/CD.
    Use this to understand the deployment workflow and what checks run on PRs.
    """
    sf = get_snowflake_service()
    raw = sf.get_framework_config("PIPELINES")
    if not raw:
        return "No pipeline configuration found in native app"

    pipelines = raw.get("pipelines", [])
    filtered = [p for p in pipelines if p.get("platform", "github") == platform and p.get("enabled", True)]
    return json.dumps(filtered, indent=2)


@mcp.tool()
def get_dbt_versions() -> str:
    """Get the active dbt and SQLFluff versions mandated by the framework.

    Returns the pinned versions of dbt-core, sqlfluff, and related packages
    that the team must use. Use this to check version compatibility.
    """
    sf = get_snowflake_service()
    raw = sf.get_framework_config("DBT_VERSIONS")
    if not raw:
        return "No DBT versions configuration found in native app"

    return json.dumps(raw, indent=2)


# --- Project Tools ---


@mcp.tool()
def get_project_settings() -> str:
    """Get the project settings from the framework.

    Returns project directory paths, execution mode, deployment targets
    (dev/test/prod) with their roles, warehouses, and schemas.
    Use this to understand the project structure and deployment environments.
    """
    sf = get_snowflake_service()
    raw = sf.get_framework_config("PROJECT")
    if not raw:
        return "No project settings found in native app"

    return json.dumps(raw, indent=2)


@mcp.tool()
def get_project_profiles() -> str:
    """Get all project profiles registered in the framework.

    Returns details about each dbt project including profile name, target database,
    dbt version, model types, downstream dependencies, and git URL.
    Use this to understand the project landscape and inter-project relationships.
    """
    sf = get_snowflake_service()
    profiles = sf.get_project_profiles()
    if not profiles:
        return "No project profiles found in native app"

    return json.dumps(profiles, indent=2)


@mcp.tool()
def get_deployment_targets() -> str:
    """Get the deployment target environments (dev, test, prod) and their configuration.

    Returns each target's branch mapping, Snowflake role, warehouse, and schema.
    Use this when deploying or understanding which branch maps to which environment.
    """
    sf = get_snowflake_service()
    raw = sf.get_framework_config("PROJECT")
    if not raw:
        return "No project settings found in native app"

    targets = raw.get("targets", [])
    return json.dumps(targets, indent=2)


@mcp.tool()
def get_default_macros(profile_name: str) -> str:
    """Get the default macros configured for a project profile.

    Args:
        profile_name: The project profile name to get macros for.

    Returns the list of macros (name and SQL content) that should be present
    in the project's macros/ directory. These are framework-standard macros
    like generate_schema_name, generate_database_name, etc.
    """
    sf = get_snowflake_service()
    raw = sf.get_macros_for_profile(profile_name)
    if not raw:
        return "No macros found for this profile"

    macros = raw.get("macros", [])
    # Return name and a preview of SQL (first 200 chars) to avoid overwhelming responses
    summary = []
    for m in macros:
        entry = {
            "macro_name": m.get("macro_name"),
            "sql_preview": m.get("sql", "")[:200] + ("..." if len(m.get("sql", "")) > 200 else ""),
            "file_path": f"macros/{m.get('macro_name', 'unknown')}.sql",
        }
        summary.append(entry)
    return json.dumps(summary, indent=2)


@mcp.tool()
def get_available_skills() -> str:
    """Get the Cortex Code skills available from the framework.

    Returns a list of skills with their IDs, names, descriptions, versions,
    and categories. Skills provide AI-assisted workflows for dbt development.
    """
    sf = get_snowflake_service()
    raw = sf.get_framework_config("CORTEX_SKILLS")
    if not raw:
        return "No skills found in native app"

    skills = raw.get("skills", [])
    summary = []
    for s in skills:
        if s.get("enabled", True):
            summary.append({
                "skill_id": s.get("skill_id"),
                "name": s.get("name"),
                "description": s.get("description"),
                "version": s.get("version"),
                "category": s.get("category"),
                "file_count": len(s.get("files", [])),
            })
    return json.dumps(summary, indent=2)


# --- Git / Source Control Tools ---


@mcp.tool()
def validate_branch_name(branch_name: str) -> str:
    """Validate a branch name against the framework's naming conventions.

    Args:
        branch_name: The branch name to validate (e.g., "feature/JIRA-123_add_new_model").

    Returns whether the branch name is valid, and if not, what's wrong and
    what the correct format should be.
    """
    sf = get_snowflake_service()
    raw = sf.get_framework_config("SOURCE_CONTROL")
    if not raw:
        return "No source control config found - cannot validate"

    branch_types = [bt.get("name", "") for bt in raw.get("branch_types", [])]
    ticket_required = raw.get("ticket_number_required", False)
    branch_format = raw.get("branch_format", "{branch_type}/{branch_name}")

    parts = branch_name.split("/", 1)
    errors = []

    if len(parts) < 2:
        errors.append(f"Branch must follow format: {branch_format}")
        errors.append(f"Valid branch types: {', '.join(branch_types)}")
    else:
        branch_type, remainder = parts
        if branch_type not in branch_types:
            errors.append(f"Invalid branch type '{branch_type}'. Valid types: {', '.join(branch_types)}")

        if ticket_required and "_" in remainder:
            ticket_part = remainder.split("_", 1)[0]
            if not ticket_part or ticket_part.isalpha():
                errors.append("Ticket number is required before the underscore (e.g., JIRA-123_description)")
        elif ticket_required:
            errors.append("Ticket number is required in branch name (e.g., feature/JIRA-123_description)")

    if errors:
        result = {"valid": False, "errors": errors, "format": branch_format, "valid_types": branch_types}
    else:
        result = {"valid": True, "branch_name": branch_name}

    return json.dumps(result, indent=2)


@mcp.tool()
def get_deployment_workflow() -> str:
    """Get the deployment workflow showing how code flows through environments.

    Returns the environment branches (dev, test, prod), their merge strategies,
    and which environments auto-deploy. Use this to understand the release process.
    """
    sf = get_snowflake_service()
    raw = sf.get_framework_config("SOURCE_CONTROL")
    if not raw:
        return "No source control config found"

    environments = raw.get("environments", [])
    platform = raw.get("source_control_platform", "GitHub")

    steps = []
    for env in environments:
        name = env.get("branch_name", "unknown")
        merge = env.get("merge_into_using", "push")
        auto_release = env.get("auto_released_to_environment", "")
        step = f"{name} (merge via: {merge})"
        if auto_release:
            step += f" -> auto-deploys to {auto_release}"
        steps.append(step)

    result = {
        "platform": platform,
        "environments": environments,
        "workflow_summary": " -> ".join(steps) if steps else "No environments configured",
    }
    return json.dumps(result, indent=2)


# --- Linting Tools ---


@mcp.tool()
def lint_sql(file_path: str) -> str:
    """Lint a SQL file using SQLFluff with the project's configured rules.

    Args:
        file_path: Path to the SQL file to lint (relative or absolute).

    Returns the linting results including rule violations, line numbers,
    and descriptions. Uses the project's .sqlfluff config from the framework.
    """
    import subprocess
    from pathlib import Path

    project_dir = _find_project_dir()
    target = Path(file_path)
    if not target.is_absolute():
        target = project_dir / target

    if not target.exists():
        return json.dumps({"error": f"File not found: {target}"})

    cmd = ["sqlfluff", "lint", str(target), "--format", "json"]
    config_path = project_dir / ".sqlfluff"
    if config_path.exists():
        cmd += ["--config", str(config_path)]

    result = subprocess.run(cmd, capture_output=True, text=True, cwd=str(project_dir))

    # SQLFluff returns exit code 1 when violations are found (not an error)
    if result.returncode > 1:
        return json.dumps({"error": f"SQLFluff failed: {result.stderr.strip()}"})

    if result.stdout.strip():
        try:
            violations = json.loads(result.stdout)
            return json.dumps(violations, indent=2)
        except json.JSONDecodeError:
            return result.stdout
    return json.dumps({"status": "clean", "message": "No linting issues found"})


@mcp.tool()
def fix_sql(file_path: str) -> str:
    """Auto-fix linting issues in a SQL file using SQLFluff.

    Args:
        file_path: Path to the SQL file to fix (relative or absolute).

    Applies automatic fixes using the project's .sqlfluff config.
    Returns the fix results and what was changed.
    """
    import subprocess
    from pathlib import Path

    project_dir = _find_project_dir()
    target = Path(file_path)
    if not target.is_absolute():
        target = project_dir / target

    if not target.exists():
        return json.dumps({"error": f"File not found: {target}"})

    cmd = ["sqlfluff", "fix", str(target), "--force", "--format", "json"]
    config_path = project_dir / ".sqlfluff"
    if config_path.exists():
        cmd += ["--config", str(config_path)]

    result = subprocess.run(cmd, capture_output=True, text=True, cwd=str(project_dir))

    if result.returncode > 1:
        return json.dumps({"error": f"SQLFluff fix failed: {result.stderr.strip()}"})

    if result.stdout.strip():
        try:
            fix_results = json.loads(result.stdout)
            return json.dumps(fix_results, indent=2)
        except json.JSONDecodeError:
            return result.stdout
    return json.dumps({"status": "fixed", "message": f"Fixes applied to {target.name}"})


@mcp.tool()
def lint_project(fix: bool = False) -> str:
    """Lint all SQL models in the dbt project.

    Args:
        fix: If True, auto-fix issues instead of just reporting them. Defaults to False.

    Lints the models/ directory using the project's .sqlfluff config.
    Returns a summary of violations or fixes applied.
    """
    import subprocess
    from pathlib import Path

    project_dir = _find_project_dir()
    models_dir = project_dir / "models"
    if not models_dir.exists():
        return json.dumps({"error": f"No models directory found at {models_dir}"})

    action = "fix" if fix else "lint"
    cmd = ["sqlfluff", action, str(models_dir), "--format", "json"]
    if fix:
        cmd.append("--force")

    config_path = project_dir / ".sqlfluff"
    if config_path.exists():
        cmd += ["--config", str(config_path)]

    result = subprocess.run(cmd, capture_output=True, text=True, cwd=str(project_dir))

    if result.returncode > 1:
        return json.dumps({"error": f"SQLFluff {action} failed: {result.stderr.strip()}"})

    if result.stdout.strip():
        try:
            output = json.loads(result.stdout)
            # Summarize for large projects
            if isinstance(output, list) and len(output) > 10:
                total_violations = sum(len(f.get("violations", [])) for f in output)
                files_with_issues = sum(1 for f in output if f.get("violations"))
                summary = {
                    "action": action,
                    "files_checked": len(output),
                    "files_with_issues": files_with_issues,
                    "total_violations": total_violations,
                    "details": output[:5],
                    "truncated": True,
                    "message": f"Showing first 5 of {len(output)} files",
                }
                return json.dumps(summary, indent=2)
            return json.dumps(output, indent=2)
        except json.JSONDecodeError:
            return result.stdout
    return json.dumps({"status": "clean", "action": action, "message": "No issues found"})


def _find_project_dir() -> "Path":
    """Find the dbt project directory from .datasecops.yml or cwd."""
    from pathlib import Path

    cwd = Path.cwd()
    # Check for dbt_project.yml in common locations
    for candidate in [cwd, cwd / "dbt"]:
        if (candidate / "dbt_project.yml").exists():
            return candidate
    return cwd


def main():
    """Run the MCP server via stdio transport."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
