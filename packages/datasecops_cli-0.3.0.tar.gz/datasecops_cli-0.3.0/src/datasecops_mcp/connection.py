"""Snowflake connection management for the MCP server.

Reads .datasecops.yml from the current working directory (or a configured path)
to establish a connection to the native app.
"""

import json
from pathlib import Path
from typing import Any, Optional

import snowflake.connector
import yaml


class MCPSnowflakeService:
    """Lightweight Snowflake service for the MCP server."""

    def __init__(self, connection_name: str, app_database: str):
        self.connection_name = connection_name
        self.app_database = app_database
        self._conn: Optional[snowflake.connector.SnowflakeConnection] = None

    @property
    def conn(self) -> snowflake.connector.SnowflakeConnection:
        if self._conn is None:
            self._conn = snowflake.connector.connect(
                connection_name=self.connection_name,
            )
        return self._conn

    def get_framework_config(self, config_code: str) -> Optional[dict]:
        """Call the native app's get_framework_config procedure."""
        sql = f"CALL {self.app_database}.api.get_framework_config(%s)"
        cur = self.conn.cursor(snowflake.connector.DictCursor)
        try:
            cur.execute(sql, [config_code])
            rows = cur.fetchall()
            if rows:
                first_val = list(rows[0].values())[0]
                if isinstance(first_val, str):
                    try:
                        return json.loads(first_val)
                    except (json.JSONDecodeError, TypeError):
                        return {"raw": first_val}
                return first_val
            return None
        finally:
            cur.close()

    def get_macros_for_profile(self, profile_name: str) -> Optional[dict]:
        """Call the native app's get_macros_for_profile procedure."""
        sql = f"CALL {self.app_database}.api.get_macros_for_profile(%s)"
        cur = self.conn.cursor(snowflake.connector.DictCursor)
        try:
            cur.execute(sql, [profile_name])
            rows = cur.fetchall()
            if rows:
                first_val = list(rows[0].values())[0]
                if isinstance(first_val, str):
                    try:
                        return json.loads(first_val)
                    except (json.JSONDecodeError, TypeError):
                        return None
                return first_val
            return None
        finally:
            cur.close()

    def get_project_profiles(self) -> Optional[list[dict]]:
        """Call the native app's get_project_profiles procedure."""
        sql = f"CALL {self.app_database}.api.get_project_profiles()"
        cur = self.conn.cursor(snowflake.connector.DictCursor)
        try:
            cur.execute(sql)
            rows = cur.fetchall()
            if rows:
                first_val = list(rows[0].values())[0]
                if isinstance(first_val, str):
                    try:
                        return json.loads(first_val)
                    except (json.JSONDecodeError, TypeError):
                        return None
                return first_val
            return None
        finally:
            cur.close()

    def close(self):
        if self._conn:
            self._conn.close()
            self._conn = None


def load_datasecops_config(project_dir: Path = None) -> dict:
    """Load .datasecops.yml from the project directory."""
    search_dir = project_dir or Path.cwd()
    config_path = search_dir / ".datasecops.yml"
    if not config_path.exists():
        raise FileNotFoundError(
            f"No .datasecops.yml found in {search_dir}. "
            "Run 'datasecops' CLI setup first."
        )
    with open(config_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


# Module-level singleton for the MCP server session
_service: Optional[MCPSnowflakeService] = None


def get_snowflake_service(project_dir: Path = None) -> MCPSnowflakeService:
    """Get or create the Snowflake service singleton."""
    global _service
    if _service is None:
        config = load_datasecops_config(project_dir)
        connection_name = config.get("connection_name", "")
        app_database = config.get("app_database", "")
        if not connection_name or not app_database:
            raise ValueError(
                ".datasecops.yml is missing connection_name or app_database"
            )
        _service = MCPSnowflakeService(connection_name, app_database)
    return _service
