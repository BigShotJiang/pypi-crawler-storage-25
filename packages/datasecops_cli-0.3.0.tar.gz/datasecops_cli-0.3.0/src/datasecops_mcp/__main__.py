"""Entry point for running the MCP server directly: python -m datasecops_mcp"""

from datasecops_mcp.server import main

main()
