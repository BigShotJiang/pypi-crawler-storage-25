under the folder /legacy_framework/app/commandline is the legacy framework which this native app has replaced the configuration for.

I want to re-create the command line segment so that users can still use it against the native app.
It needs to:
1 - ensure cortex code, uv and dbt (dbt fusion) is installed. If it isnt then needs to install them
2 - select which connection they want to use
3 - select the database name for the native app
4 - create a venv under uv for the project to run under
5 - ensure the packages are installed as defined in settings => requirements of the framework
6 - the project profile to use should come from the dbtproject.yml file and needs to ensure a project profile exists inside the framework database
7 - display option menus so a user can run dbt or git based commands.

For the dbt run commands, the user needs to be able to run them under dbt fusion
For the git commands, they need to be able to pull, push, checkout etc as per current menus, but they also need to be able to do a squash merge into test and cherry pick commits out of test.

We also need the ability to download the config file for SQLFluff as well as the pipeline files and also bring down updated dbt package versions/revisions for the dbt dependancies.

step 1, 2, 3, 4 need to be in a setup script (bash & ps based). Then download the framework command line package from pypi

Create a plan of what we need to
- build into the framework command line package
- deployment path into pypi
- scripts needed to be included in the local repo