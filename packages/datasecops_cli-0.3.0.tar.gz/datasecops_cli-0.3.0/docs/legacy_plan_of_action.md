# DataSecOps Framework CLI - Plan of Action

## Overview

Re-create the legacy command-line interface as a standalone PyPI package (`datasecops-cli`) that works against the native app. The legacy framework (`legacy_framework/app/commandline`) provided an interactive terminal-based tool for managing dbt projects on Snowflake with numbered menus for dbt, git, linting, and project management. The new CLI must replicate this workflow but target **dbt Fusion** instead of dbt-core's Python API, use **uv** for environment management, and pull configuration from the native app database rather than local DuckDB/YAML files.

---

## 1. Setup Scripts (Included in Local Repo)

Steps 1-4 from the requirements must live in platform-specific setup scripts that users run before the CLI package itself.

### 1.1 `setup.sh` (Bash - Linux/macOS)

- Check for and install **Cortex Code** (prompt user or provide install command)
- Check for and install **uv** (`curl -LsSf https://astral.sh/uv/install.sh | sh`)
- Check for and install **dbt Fusion** (install via appropriate method)
- Prompt user to **select a Snowflake connection** (list available connections from `~/.snowflake/connections.toml` or Cortex Code config)
- Prompt user to **enter the native app database name**
- **Create a uv venv** for the project (`uv venv .venv`)
- **Install the CLI package** from PyPI into the venv (`uv pip install datasecops-cli`)
- Write a local `.datasecops.yml` config file storing the selected connection and database name

### 1.2 `setup.ps1` (PowerShell - Windows)

- Same logic as `setup.sh` but using PowerShell equivalents
- Use `Invoke-WebRequest` for downloads
- Use `uv` PowerShell commands for venv creation
- Handle Windows-specific path conventions

### 1.3 What the setup scripts produce

```
project_root/
  .venv/                  # uv-managed virtual environment
  .datasecops.yml         # local config (connection name, app database, profile)
```

---

## 2. Framework CLI Package (PyPI: `datasecops-cli`)

### 2.1 Package Structure

```
datasecops-cli/
  pyproject.toml
  src/
    datasecops_cli/
      __init__.py
      main.py                  # Entry point, main menu loop
      config.py                # Read .datasecops.yml + native app config
      menus/
        __init__.py
        development.py         # dbt development menu
        git_operations.py      # Git operations menu
        downloads.py           # Config/pipeline/package downloads/skills
      services/
        __init__.py
        dbt_runner.py          # dbt Fusion subprocess runner
        git_service.py         # Git operations (GitPython)
        snowflake_service.py   # Snowflake queries against native app
        linting_service.py     # SQLFluff integration
        download_service.py    # Download configs/pipelines/packages from native app
        skill_service.py       # Cortex Code skill installation
      models/
        __init__.py
        project_config.py      # Project/profile config models
        git_helpers.py         # Branch state, commit helpers
      utilities/
        __init__.py
        display.py             # Cross-platform terminal UI (replace Windows-only code)
        file_utils.py          # File I/O utilities
        yaml_utils.py          # YAML config reading
```

### 2.2 Entry Point & Main Menu

- CLI entry via `datasecops` command (defined in `pyproject.toml [project.scripts]`)
- On startup:
  - Read `.datasecops.yml` for connection and database name
  - Read `dbt_project.yml` to determine the project profile name
  - Verify the profile exists inside the framework native app database; if not, create it
  - Ensure packages from the framework's `settings => requirements` are installed in the venv
- Main menu options:
  1. **Development** (dbt commands)
  2. **Git** (source control)
  3. **Downloads** (config files, pipelines, packages, Cortex Code skills)
  4. **Project** (switch profile/connection)
  0. **Exit**

### 2.3 dbt Commands (via dbt Fusion)

Replace the legacy `dbtRunner` Python API calls with **subprocess calls to dbt Fusion**:

| Menu Option | Command |
|---|---|
| Run | `dbt run [--select] [--exclude] [--full-refresh]` |
| Build | `dbt build [--select] [--exclude]` |
| Test | `dbt test [--select]` |
| Compile | `dbt compile [--select]` |
| Deps | `dbt deps` |
| Seed | `dbt seed` |
| Snapshot | `dbt snapshot` |
| Source Freshness | `dbt source freshness` |
| Docs Generate | `dbt docs generate` |
| Docs Serve | `dbt docs serve` |
| Clean | `dbt clean` |
| Debug | `dbt debug` |
| List | `dbt list [--select] [--resource-type]` |
| Retry | `dbt retry` |

- All commands pass `--project-dir` and `--profiles-dir` from config
- Support `state:modified+` for slim CI runs
- Copy `target/manifest.json` after runs for state tracking (preserving legacy behaviour)

### 2.4 Git Commands

Retain GitPython-based operations from the legacy framework, with additions:

**Existing (from legacy `gitOptions.py`):**

- Create branch (`{type}/{ticket}_{name}` convention)
- Checkout / switch branch
- Delete branch (local + remote)
- Commit (show dirty files, prompt message, auto-push)
- Push / Pull with sync status checks
- Rebase (standard and squash)
- Deploy to environment branches (dev/test/prod)
- Prune remote branches
- Reset branch

**New additions required:**

- **Squash merge into test** - merge current feature branch into `test` using `--squash`, commit with combined message
- **Cherry-pick commits out of test** - list commits on `test`, let user select specific commits to cherry-pick onto another branch (e.g., removing a feature from test)

### 2.5 Downloads from Native App

New menu section for pulling configuration and dependencies from the native app database:

| Download | Source | Target |
|---|---|---|
| SQLFluff config | Native app settings table | `.sqlfluff` / `.sqlfluffconfig` in project root |
| Pipeline files | Native app pipelines config | CI/CD files in project (e.g., `.github/workflows/`, `azure-pipelines.yml`) |
| dbt package versions | Native app package registry | `packages.yml` in dbt project |
| Cortex Code skills | Native app skills table | `~/.cortex/skills/` or `.cortex/skills/` in project |

- Query the native app database for stored configurations
- Write files to appropriate locations in the local project
- For dbt packages, update `packages.yml` with current versions/revisions then run `dbt deps`

### 2.6 Cortex Code Skills Download

The native app stores Cortex Code skill definitions that can be downloaded and installed locally so users can leverage framework-specific skills inside Cortex Code sessions.

**Workflow:**

1. Query the native app database for available skills (skill name, version, contents)
2. List available skills in a selection menu, showing name, description, and current vs installed version
3. User selects which skills to install (or "all")
4. Write skill files to the appropriate local Cortex Code skills directory (`~/.cortex/skills/` or project-level `.cortex/skills/`)
5. Verify installation by checking that Cortex Code recognises the installed skills

**Menu options under Downloads:**

| Option | Action |
|---|---|
| List available skills | Show all skills stored in the native app with versions |
| Install skill | Download and install a selected skill |
| Install all skills | Download and install all available skills |
| Update skills | Check for newer versions and update installed skills |

**Skill storage in native app:**

- Skills are stored as records in the native app database containing: skill name, description, version, skill definition files (YAML + prompt content)
- The download service reads these records, reconstructs the skill directory structure, and writes them locally

**Integration with setup scripts:**

- The setup scripts (`setup.sh` / `setup.ps1`) should verify Cortex Code is installed (already covered in step 1)
- After initial setup, the CLI can prompt the user to download available skills as part of first-run onboarding

### 2.7 Profile Management

- On startup, read `dbt_project.yml` to get the `profile:` value
- Query the native app database to check if that profile exists
- If not, prompt user for connection details and create the profile in the native app
- Write/update `~/.dbt/profiles.yml` with a `local-dev` target for the profile
- Support switching between profiles/projects

### 2.8 Package Installation from Framework Settings

- Query the native app's `settings => requirements` configuration
- Compare against currently installed packages in the venv
- Install/upgrade missing or outdated packages via `uv pip install`

### 2.9 Cross-Platform Compatibility

The legacy code is Windows-only. The new package must be cross-platform:

| Legacy (Windows-only) | New (Cross-platform) |
|---|---|
| `os.system('cls')` | `os.system('cls' if os.name == 'nt' else 'clear')` |
| `msvcrt.getch()` | `input("Press Enter to continue...")` or `readchar` library |
| `\\` path separators | `pathlib.Path` throughout |
| `wxPython` file dialogs | Remove or replace with CLI path prompts |
| `colorama` | Keep (already cross-platform) |

### 2.10 Dependencies

```
dbt-core          # For dbt manifest parsing (if needed)
dbt-snowflake     # Snowflake adapter
gitpython         # Git operations
snowflake-connector-python  # Direct Snowflake queries
colorama          # Terminal colors
pyyaml            # YAML config files
sqlfluff          # SQL linting
readchar          # Cross-platform key input (replaces msvcrt)
pydantic          # Data models
```

---

## 3. Deployment Path to PyPI

### 3.1 Package Configuration (`pyproject.toml`)

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "datasecops-cli"
version = "0.1.0"
description = "DataSecOps Framework CLI for Snowflake Native App"
requires-python = ">=3.10"
dependencies = [
    "gitpython>=3.1",
    "snowflake-connector-python>=3.0",
    "colorama>=0.4",
    "pyyaml>=6.0",
    "sqlfluff>=3.0",
    "readchar>=4.0",
    "pydantic>=2.0",
]

[project.scripts]
datasecops = "datasecops_cli.main:main"
```

### 3.2 Build & Publish Pipeline

1. **Build**: `uv build` or `python -m build` to produce sdist + wheel
2. **Test PyPI first**: publish to `test.pypi.org` for validation
3. **Publish to PyPI**: `uv publish` or `twine upload dist/*`
4. **Versioning**: Semantic versioning (MAJOR.MINOR.PATCH), managed in `pyproject.toml`

### 3.3 CI/CD for Package Publishing

Create a GitHub Actions workflow (`.github/workflows/publish-cli.yml`):

- Trigger on tags matching `cli-v*`
- Steps: checkout, setup Python, install build tools, build, publish to PyPI
- Use PyPI trusted publisher (OIDC) for authentication - no API tokens needed

---

## 4. Scripts Included in the Local Repo

These files live in the user's dbt project repo (not in the PyPI package):

```
project_root/
  setup.sh                    # Bash setup script (Linux/macOS)
  setup.ps1                   # PowerShell setup script (Windows)
  .datasecops.yml             # Generated by setup - connection & database config
  dbt/dbt_project.yml             # Existing dbt project file (profile name read from here)
  dbt/packages.yml                # dbt package dependencies (updated by downloads)
  dbt/.sqlfluff                   # Downloaded from native app
  dbt/.sqlfluffignore             # SQLFluff exclusions
```

### 4.1 Setup Script Responsibilities

| Step | Action | Script |
|---|---|---|
| 1 | Verify/install Cortex Code, uv, dbt Fusion | `setup.sh` / `setup.ps1` |
| 2 | Select Snowflake connection | `setup.sh` / `setup.ps1` |
| 3 | Select native app database name | `setup.sh` / `setup.ps1` |
| 4 | Create uv venv | `setup.sh` / `setup.ps1` |
| 5 | Install `datasecops-cli` from PyPI | `setup.sh` / `setup.ps1` |

After setup, user activates the venv and runs `datasecops` to enter the interactive CLI.

---

## 5. Implementation Order

1. **Scaffold the `datasecops-cli` package** - pyproject.toml, package structure, entry point
2. **Port display utilities** - cross-platform terminal menus, colors, input handling
3. **Implement config module** - read `.datasecops.yml`, query native app for settings, read `dbt_project.yml`
4. **Implement Snowflake service** - connect via selected connection, query native app tables
5. **Implement dbt runner** - subprocess wrapper for dbt Fusion commands
6. **Implement git service** - port GitPython operations, add squash merge and cherry-pick
7. **Implement download service** - SQLFluff config, pipeline files, dbt package versions
8. **Implement Cortex Code skill service** - query native app for skills, download and install to local skills directory
9. **Build menus** - main menu, development menu, git menu, downloads menu (including skills)
10. **Implement profile management** - profile validation, creation, switching
11. **Write setup scripts** - `setup.sh` and `setup.ps1`
12. **Test end-to-end** - run against a live native app instance
13. **Configure PyPI publishing** - pyproject.toml metadata, GitHub Actions workflow
14. **Publish to PyPI** - test.pypi.org first, then production PyPI

---

## 6. Key Differences from Legacy

| Aspect | Legacy | New CLI |
|---|---|---|
| dbt execution | `dbtRunner` Python API (dbt-core) | dbt Fusion via subprocess |
| Config storage | Local DuckDB (`config.db`) | `.datasecops.yml` + native app database |
| Environment | Manual pip/venv | uv-managed venv |
| Platform | Windows-only | Cross-platform (Linux, macOS, Windows) |
| Distribution | Not packaged | PyPI package (`datasecops-cli`) |
| Setup | Manual | Automated setup scripts |
| Profile source | Local `~/.dbt/profiles.yml` only | `dbt_project.yml` + native app validation |
| SQLFluff config | Local `.sqlfluffconfig` template | Downloaded from native app |
| Pipeline files | Not managed | Downloaded from native app |
| dbt packages | Manual `packages.yml` edits | Versions pulled from native app |
| Cortex Code skills | Not supported | Downloaded from native app and installed locally |

---

## 7. Native App Modifications for CLI Support

The CLI needs to pull configuration and push data back to the native app. The following stored procedures have been added to `app/scripts/05-procs.sql` under the `api` schema:

### 7.1 Generic Configuration Export

```sql
CALL <app_db>.api.get_framework_config('<configuration_code>');
```

Returns the `record_data` JSON for any configuration code. The CLI uses this to download:

| Configuration Code | What the CLI gets |
|---|---|
| `PROJECT` | Project settings (targets, execution mode, dirs) |
| `SOURCE_CONTROL` | Git platform, branch types, environments |
| `DBT_PACKAGES` | Default dbt packages with URLs and versions |
| `DBT_VERSIONS` | Allowed dbt-core and dbt-snowflake versions |
| `PIPELINES` | CI/CD pipeline definitions and step catalog |
| `SQLFLUFF_RULES` | SQLFluff linter rule configuration |
| `CORTEX_SKILLS` | Cortex Code skill definitions and files |
| `WAREHOUSES` | Warehouse definitions |
| `SECURITY_MODEL` | RBAC role definitions |

### 7.2 Project Profiles Export

```sql
CALL <app_db>.api.get_project_profiles();
```

Returns all rows from `data.projects` as a JSON array. The CLI uses this to:
- Validate that the profile from `dbt_project.yml` exists in the native app
- List available profiles for the user to select
- Retrieve `target_database`, `git_url`, `dbt_version`, and `dbt_packages` for the active profile

### 7.3 Cortex Code Skills Import

```sql
CALL <app_db>.api.import_cortex_skills(<skills_json variant>);
```

Accepts a JSON array of skill objects and writes them to the `CORTEX_SKILLS` configuration. Used for bulk importing skills from external sources.

### 7.4 CLI Download Flow

When the CLI user selects a download option, the flow is:

1. **Connect** to the native app database using the connection from `.datasecops.yml`
2. **Call** the appropriate stored procedure (e.g., `api.get_framework_config('CORTEX_SKILLS')`)
3. **Parse** the returned JSON into the corresponding Pydantic model
4. **Write** the files to the correct local locations:
   - Skills: `~/.cortex/skills/<skill_id>/` (each file written from the skill's `files` array)
   - SQLFluff: `.sqlfluff` in project root (generated from `SQLFLUFF_RULES` config)
   - Pipelines: `.github/workflows/` or Azure DevOps YAML (generated from `PIPELINES` config)
   - dbt packages: `packages.yml` in dbt project (generated from `DBT_PACKAGES` config)

### 7.5 Existing Procedures (Already Available)

These procedures were already present and are also useful to the CLI:

| Procedure | Purpose |
|---|---|
| `api.fetch_dbt_package_versions(variant)` | Fetch latest GitHub tags for dbt packages |
| `api.fetch_dbt_releases(string, int)` | Fetch dbt versions from PyPI |
| `api.import_security_roles(variant)` | Import RBAC roles from external tools |
| `api.import_security_warehouses(variant)` | Import warehouse definitions from external tools |
