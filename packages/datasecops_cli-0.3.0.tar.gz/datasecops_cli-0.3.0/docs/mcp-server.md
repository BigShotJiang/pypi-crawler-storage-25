# DataSecOps Framework MCP Server

The MCP (Model Context Protocol) server exposes your framework's governance configuration to AI coding assistants like Cortex Code, Claude Code, and Cursor. Instead of static skill files, the MCP server gives AI tools live access to your native app's current rules.

## Installation

```bash
pip install datasecops-cli[mcp]
```

## Quick Start

Run the server:

```bash
datasecops-mcp
```

The server communicates via stdio transport and is designed to be launched by an MCP client (not run interactively).

## Configuring Your AI Tool

### Cortex Code

Add to your Cortex Code MCP configuration:

```json
{
  "mcpServers": {
    "datasecops-framework": {
      "command": "datasecops-mcp",
      "args": []
    }
  }
}
```

### Claude Code

```bash
claude mcp add datasecops-framework datasecops-mcp
```

### Cursor / VS Code

Add to `.cursor/mcp.json` or your IDE's MCP settings:

```json
{
  "mcpServers": {
    "datasecops-framework": {
      "command": "datasecops-mcp",
      "args": []
    }
  }
}
```

## Prerequisites

The MCP server requires a `.datasecops.yml` file in your project root (the same file used by the `datasecops` CLI):

```yaml
connection_name: my_snowflake_connection
app_database: DATASECOPS_APP
profile_name: my_project
```

It uses your Snowflake connection from `~/.snowflake/connections.toml` to authenticate.

## Available Tools

### Configuration Tools

| Tool | Description |
|------|-------------|
| `get_branching_rules` | Branch types, naming conventions, ticket requirements, merge strategies |
| `get_linting_rules` | SQLFluff rules (dialect, indentation, enabled rule codes) |
| `get_dbt_packages` | Approved packages with pinned versions |
| `get_pipeline_config` | CI/CD pipeline YAML templates (GitHub Actions or Azure DevOps) |
| `get_dbt_versions` | Mandated versions of dbt and SQLFluff |

### Project Tools

| Tool | Description |
|------|-------------|
| `get_project_settings` | Project directory paths, execution mode, targets |
| `get_project_profiles` | All registered dbt projects with metadata |
| `get_deployment_targets` | Environment targets (dev/test/prod) with roles and warehouses |
| `get_available_skills` | Cortex Code skills available from the native app |

### Linting Tools

| Tool | Description |
|------|-------------|
| `lint_sql` | Lint a single SQL file using the project's SQLFluff config |
| `fix_sql` | Auto-fix linting issues in a SQL file |
| `lint_project` | Lint all models in the project (optionally auto-fix) |

### Source Control Tools

| Tool | Description |
|------|-------------|
| `validate_branch_name` | Check if a branch name meets naming conventions |
| `get_deployment_workflow` | How code flows through environments (merge strategies, auto-deploy) |

## How Users Interact With It

The MCP server works transparently in the background. When you ask your AI assistant questions, it automatically calls the relevant tools.

### Example Interactions

**Creating a branch:**
> "Create a new branch for ticket JIRA-456 to add a customer dimension model"

The AI calls `get_branching_rules` to learn valid branch types and naming format, then creates `feature/JIRA-456_add_customer_dimension`.

**Writing SQL:**
> "Write a staging model for the orders table"

The AI calls `get_linting_rules` to check indentation rules and dialect settings, then writes SQL that passes `sqlfluff lint` without changes.

**Linting a file:**
> "Lint my staging orders model"

The AI calls `lint_sql("models/staging/stg_orders.sql")` and reports violations with line numbers and rule codes.

**Fixing linting issues:**
> "Fix all the linting issues in this file"

The AI calls `fix_sql("models/staging/stg_orders.sql")` which applies auto-fixes using your framework's rules.

**Linting the whole project:**
> "Are there any linting issues across the project?"

The AI calls `lint_project()` and returns a summary of violations across all models.

**Adding a dbt package:**
> "I need to add dbt-utils to the project"

The AI calls `get_dbt_packages` to check if dbt-utils is already approved and at what version, preventing unapproved dependencies.

**Understanding deployment:**
> "How do I get my changes to production?"

The AI calls `get_deployment_workflow` and `get_deployment_targets` to explain the full path: push to feature branch → merge to test → promote to prod, including which roles and warehouses are used.

**Validating work:**
> "Is my branch name correct?"

The AI calls `validate_branch_name("bugfix/fix_null_handling")` and reports whether it meets the framework's conventions.

**Checking CI/CD:**
> "What checks run when I open a PR?"

The AI calls `get_pipeline_config("github")` to show the workflow YAML and explain what steps execute.

## Adding GitHub / Azure DevOps MCP Servers

For full platform integration (PR creation, CI status, issue tracking), add the platform MCP servers alongside the framework server.

### GitHub

```json
{
  "mcpServers": {
    "datasecops-framework": {
      "command": "datasecops-mcp",
      "args": []
    },
    "github": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-github"],
      "env": {
        "GITHUB_PERSONAL_ACCESS_TOKEN": "<your-pat>"
      }
    }
  }
}
```

This enables:
- Auto-creating PRs after pushing branches
- Checking CI pipeline status
- Linking PRs to issues
- Requesting code reviews
- Viewing check results before deploying

### Azure DevOps

```json
{
  "mcpServers": {
    "datasecops-framework": {
      "command": "datasecops-mcp",
      "args": []
    },
    "azure-devops": {
      "command": "npx",
      "args": ["-y", "@tiberriver256/mcp-server-azure-devops"],
      "env": {
        "AZURE_DEVOPS_ORG_URL": "https://dev.azure.com/<your-org>",
        "AZURE_DEVOPS_AUTH_METHOD": "pat",
        "AZURE_DEVOPS_PAT": "<your-pat>"
      }
    }
  }
}
```

This enables:
- Creating pull requests with templates
- Checking build pipeline status
- Linking to work items
- Managing boards and sprints

## Combined Workflow Example

With both the framework MCP server and GitHub MCP server configured, a developer can say:

> "I've finished my changes. Create a PR for this branch."

The AI will:
1. Call `get_branching_rules` to understand the merge target
2. Call `get_deployment_workflow` to determine the correct base branch
3. Use the GitHub MCP server to create the PR with the correct base, title derived from the branch name, and appropriate labels
4. Report back the PR URL

## Architecture

```
┌─────────────────────┐     stdio      ┌──────────────────────┐
│  AI Coding Tool     │◄──────────────►│  datasecops-mcp      │
│  (Cortex Code,      │                │  (MCP Server)        │
│   Claude, Cursor)   │                └──────────┬───────────┘
└─────────────────────┘                           │
                                                  │ SQL (stored procedures)
                                                  ▼
                                       ┌──────────────────────┐
                                       │  Snowflake Native App│
                                       │  DATASECOPS_APP.api  │
                                       └──────────────────────┘
```

The MCP server is a thin layer — it reads `.datasecops.yml`, connects to Snowflake using your existing credentials, and translates native app stored procedure responses into MCP tool responses.

## Development

Run from source:

```bash
python -m datasecops_mcp
```

Test with the MCP Inspector:

```bash
npx @modelcontextprotocol/inspector datasecops-mcp
```
