# DataSecOps CLI

A command-line interface for the [Data Engineers DataSecOps Native App](https://app.snowflake.com/marketplace) on Snowflake. Streamlines dbt development, source control workflows, and framework configuration management for teams using the DataSecOps Framework.

## What is this?

The DataSecOps CLI is the local developer companion to the **Data Engineers DataSecOps Native App** — a Snowflake Native App that provides governance, configuration management, and standardised development workflows for data teams.

This CLI connects to the native app and gives developers:

- **dbt development commands** — run, build, test, lint, and manage dbt projects via dbt Fusion
- **Source control operations** — branching, committing, rebasing, and deploying via GitPython with naming conventions enforced by the framework
- **Configuration downloads** — pull SQLFluff rules, CI/CD pipelines, dbt packages, and Cortex Code skills from the native app to your local project
- **MCP server** — expose framework governance rules to AI coding assistants (VS Code, Cursor, Cortex Code, Claude Code)

## Installation

```bash
pip install datasecops-cli
```

With MCP server support:

```bash
pip install "datasecops-cli[mcp]"
```

Requires Python 3.10 or later.

## Prerequisites

- A Snowflake connection configured in `~/.snowflake/connections.toml`
- The **Data Engineers DataSecOps Native App** installed in your Snowflake account
- A project profile created in the native app

Optional:

- **dbt Fusion** — required for dbt commands (`dbtf`). Install from https://docs.getdbt.com/docs/core/installation
- **Cortex Code** for skill downloads
- **Node.js 18+** for GitHub/Azure DevOps MCP servers

## Quick Start

### 1. Configure your project

```bash
datasecops setup
```

This prompts for your Snowflake connection name and native app database, then writes `.datasecops.yml`.

If you skip this step, running `datasecops` will offer to run setup automatically.

### 2. Run the CLI

```bash
datasecops
```

## Features

| Menu | Capabilities |
|------|-------------|
| **Development** | dbt run, build, test, lint (SQLFluff), deps, seed, compile, snapshot, freshness, docs |
| **Git** | Branch create/checkout/delete, commit & push, rebase, squash, deploy to environment branches, cherry-pick |
| **Downloads** | SQLFluff config, CI/CD pipelines (GitHub Actions / Azure DevOps), dbt packages, Cortex Code skills |

## Non-Interactive Mode (CI/CD)

The `download` subcommand lets you pull framework config in CI/CD pipelines without interactive prompts:

```bash
# Download specific items
datasecops download sqlfluff
datasecops download sqlfluff packages
datasecops download pipelines macros

# Install framework-pinned package versions
datasecops download install-sqlfluff
datasecops download install-dbt

# Download config and install packages together
datasecops download sqlfluff install-sqlfluff

# Download and install everything
datasecops download all
```

Available items: `sqlfluff`, `pipelines`, `packages`, `macros`, `install-sqlfluff`, `install-dbt`, `all`

The pipeline platform (GitHub / Azure DevOps) is auto-detected from the native app's source control configuration.

### Pipeline Setup

Your pipeline needs two things:

1. **A `.datasecops.yml`** in the repo (already committed — contains no secrets):

   ```yaml
   connection_name: "ci"
   app_database: "DATA_ENGINEERS_DATASECOPS_FRAMEWORK"
   ```

2. **A Snowflake connection** in `~/.snowflake/connections.toml` for the CI service account:

   ```yaml
   # GitHub Actions example
   - name: Configure Snowflake connection
     run: |
       mkdir -p ~/.snowflake
       cat > ~/.snowflake/connections.toml << EOF
       [ci]
       account = "${{ vars.SNOWFLAKE_ACCOUNT }}"
       user = "${{ vars.SNOWFLAKE_USER }}"
       authenticator = "snowflake_jwt"
       private_key_file = "/tmp/rsa_key.p8"
       warehouse = "CI_WH"
       role = "CI_ROLE"
       EOF

   - name: Download SQLFluff config
     run: datasecops download sqlfluff
   ```

The exit code is `0` on success, `1` if any download fails.

## MCP Server

The package includes an MCP (Model Context Protocol) server that exposes your framework's governance configuration to AI coding assistants. Instead of static skill files, the MCP server gives AI tools live access to your native app's current rules.

### Available Tools

| Category | Tools |
|----------|-------|
| **Configuration** | `get_branching_rules`, `get_linting_rules`, `get_dbt_packages`, `get_pipeline_config`, `get_dbt_versions` |
| **Project** | `get_project_settings`, `get_project_profiles`, `get_deployment_targets`, `get_available_skills` |
| **Linting** | `lint_sql`, `fix_sql`, `lint_project` |
| **Source Control** | `validate_branch_name`, `get_deployment_workflow` |

### Setup for AI Tools

**Cortex Code:**

```bash
cortex mcp add datasecops-framework -- datasecops-mcp
```

**VS Code / Cursor** — add to `.vscode/mcp.json` or `.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "datasecops-framework": {
      "command": "datasecops-mcp",
      "args": []
    }
  }
}
```

### Recommended MCP Server Stack

For full integration with Snowflake, dbt, and your source control platform, configure these MCP servers alongside the framework server:

| Server | Purpose | Install |
|--------|---------|---------|
| **datasecops-framework** | Governance rules, linting, branch validation | Included (`datasecops-mcp`) |
| **dbt** | Lineage, model discovery, codegen, semantic layer | `pip install dbt-mcp` |
| **GitHub** | PRs, issues, CI checks, releases | `npx -y @modelcontextprotocol/server-github` |
| **Azure DevOps** | PRs, pipelines, work items, boards | `npx -y @tiberriver256/mcp-server-azure-devops` |

See the [Getting Started Guide](docs/getting-started.md) for full configuration instructions for each editor and platform.

## Configuration

The CLI reads from a `.datasecops.yml` file in your project root (created by the setup script):

```yaml
connection_name: "my_connection"
app_database: "DATA_ENGINEERS_DATASECOPS_FRAMEWORK"
```

Project profiles, linting rules, pipeline templates, and deployment targets are all managed centrally in the native app and pulled down by the CLI.

## License

MIT
