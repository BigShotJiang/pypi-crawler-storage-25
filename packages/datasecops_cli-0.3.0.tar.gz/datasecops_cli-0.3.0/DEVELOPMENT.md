# DataSecOps Framework CLI

Command-line interface for the DataSecOps Framework Snowflake Native App. Provides interactive menus for dbt development, git source control, and downloading framework configurations locally.

## Prerequisites

Before running setup, ensure you have:

1. **Python 3.10+** installed
2. **A Snowflake connection** configured in `~/.snowflake/connections.toml`
3. **The DataSecOps Framework native app** installed in your Snowflake account
4. **A project profile** created in the native app (via the admin UI)

Optional but recommended:

- **dbt Fusion** (or dbt-core with dbt-snowflake) — required for dbt commands
- **Cortex Code** — required for skill downloads

## Quick Start

### 1. Run the setup script

The setup script checks prerequisites, creates a virtual environment, installs the CLI, and writes your local configuration.

**Linux / macOS:**

```bash
chmod +x setup.sh
./setup.sh
```

**Windows (PowerShell):**

```powershell
.\setup.ps1
```

The script will prompt you for:

- **Connection name** — the name of your Snowflake connection from `~/.snowflake/connections.toml`
- **Native app database name** — the database where the DataSecOps Framework app is installed (e.g. `DATA_ENGINEERS_DATASECOPS_FRAMEWORK`)

### 2. Activate the virtual environment

**Linux / macOS:**

```bash
source .venv/bin/activate
```

**Windows:**

```powershell
.\.venv\Scripts\Activate.ps1
```

### 3. Run the CLI

```bash
datasecops
```

This connects to the native app, loads your project configuration, and presents the main menu.

## What the CLI Does

### Main Menu

```
[1] development   - dbt Development Commands
[2] git           - Source Control Operations
[3] downloads     - Download Configs & Skills
[0] exit          - Exit
```

### Development Menu

Run dbt commands via dbt Fusion:

- **run** — full run, modified only (`state:modified+`), or specific models
- **build** — run + test in one command
- **test** — all tests or specific selectors
- **lint** — SQLFluff lint/fix on modified files or entire project
- **deps** — install dbt packages
- **seed** — load seed data
- **compile** — compile models
- **snapshot** — run snapshots
- **freshness** — check source freshness
- **docs** — generate and serve dbt docs
- **clean / debug / list / retry**

### Git Menu

Source control operations via GitPython:

- **branching** — create, checkout, switch, delete, prune, reset
- **commit** — stage all changes, enter message, auto-push
- **push / pull** — sync with remote
- **rebase** — standard rebase or squash & rebase with main
- **deploy** — push to environment branches (dev/test/prod)
- **squash to test** — squash merge current branch into test
- **cherry-pick from test** — select and cherry-pick specific commits from test

Branch naming follows the convention configured in the native app (e.g. `feature/123_my-feature`).

### Downloads Menu

Pull configurations from the native app to your local project:

- **SQLFluff config** — downloads linting rules to `.sqlfluff`
- **Pipeline files** — downloads CI/CD workflows (GitHub Actions or Azure DevOps)
- **dbt packages** — updates `packages.yml` with versions from the framework, optionally runs `dbt deps`
- **Cortex Code skills** — list, install, or update framework skills for Cortex Code

## Configuration

### `.datasecops.yml`

Created by the setup script in your project root. Contains:

```yaml
connection_name: "my_connection"    # Snowflake connection name
app_database: "DATA_ENGINEERS_DATASECOPS_FRAMEWORK"  # Native app database
profile_name: ""                    # Auto-detected from dbt_project.yml
```

### `dbt_project.yml`

The CLI reads the `profile:` field from your `dbt_project.yml` (looks in both `./dbt_project.yml` and `./dbt/dbt_project.yml`) to determine which project profile to load from the native app.

### Snowflake Connection

The CLI uses `snowflake-connector-python` with the connection name from `.datasecops.yml`. Connections are configured in `~/.snowflake/connections.toml`:

```toml
[my_connection]
account = "my_account"
user = "my_user"
authenticator = "externalbrowser"
warehouse = "MY_WH"
role = "MY_ROLE"
```

## Project Structure

```
datasecops-cli/
├── pyproject.toml                    # Package config, dependencies, entry point
├── setup.sh                          # Bash setup (Linux/macOS)
├── setup.ps1                         # PowerShell setup (Windows)
├── .github/workflows/publish-cli.yml # PyPI publish workflow
└── src/datasecops_cli/
    ├── main.py                       # Entry point and main menu
    ├── config.py                     # Configuration loader
    ├── models/                       # Pydantic data models
    ├── services/                     # Business logic (dbt, git, Snowflake, downloads)
    ├── menus/                        # Interactive menu modules
    └── utilities/                    # Display, file I/O, YAML helpers
```

## Publishing to PyPI

The package is published automatically when a tag matching `cli-v*` is pushed:

```bash
git tag cli-v0.1.0
git push origin cli-v0.1.0
```

The GitHub Actions workflow builds the package and publishes to PyPI using OIDC trusted publishing.

To build and publish manually:

```bash
pip install build twine
python -m build
twine upload dist/*
```

## Native App API

The CLI communicates with the native app through stored procedures:

| Procedure | Purpose |
|---|---|
| `api.get_framework_config(code)` | Fetch any config by code (PROJECT, PIPELINES, SQLFLUFF_RULES, CORTEX_SKILLS, etc.) |
| `api.get_project_profiles()` | List all project profiles |
| `api.import_cortex_skills(json)` | Import skills into the native app |
| `api.fetch_dbt_package_versions(json)` | Fetch latest package versions from GitHub |

These procedures are granted to the `data_engineers_framework_admin` application role.
