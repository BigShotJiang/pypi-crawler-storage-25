"""Shared utilities for the Rewind memory stack."""

import glob
import os
import platform
import sqlite3
from typing import Optional


def find_vec0() -> Optional[str]:
    """Find the sqlite-vec (vec0) shared library.

    Search order:
    1. sqlite_vec Python package (pip install sqlite-vec)
    2. Common system paths
    3. Node.js module paths (for OpenClaw users)
    """
    # 1. Try Python package
    try:
        import sqlite_vec
        return "python_package"  # sentinel — use sqlite_vec.load() instead
    except ImportError:
        pass

    # 2. Platform-specific paths
    arch = platform.machine()
    system = platform.system().lower()

    if system == "linux":
        arch_suffix = "arm64" if arch == "aarch64" else "x64"
        candidates = [
            f"/usr/lib/sqlite3/vec0.so",
            f"/usr/local/lib/vec0.so",
            os.path.expanduser(f"~/.local/lib/vec0.so"),
        ]
        # Node.js paths (glob for any node version)
        candidates += glob.glob(
            os.path.expanduser(
                f"~/.nvm/versions/node/*/lib/node_modules/*/node_modules/"
                f"sqlite-vec-linux-{arch_suffix}/vec0.so"
            )
        )
    elif system == "darwin":
        candidates = [
            "/usr/local/lib/vec0.dylib",
            os.path.expanduser("~/.local/lib/vec0.dylib"),
        ]
        candidates += glob.glob(
            os.path.expanduser(
                "~/.nvm/versions/node/*/lib/node_modules/*/node_modules/"
                "sqlite-vec-darwin-*/vec0.dylib"
            )
        )
    else:
        candidates = []

    for path in candidates:
        if os.path.exists(path):
            return path

    return None


def load_vec0(conn: sqlite3.Connection) -> bool:
    """Load sqlite-vec extension into a connection. Returns True on success."""
    path = find_vec0()
    if path is None:
        return False

    if path == "python_package":
        try:
            conn.enable_load_extension(True)
            import sqlite_vec
            sqlite_vec.load(conn)
            return True
        except Exception:
            return False

    try:
        conn.enable_load_extension(True)
        conn.load_extension(path)
        return True
    except Exception:
        return False
