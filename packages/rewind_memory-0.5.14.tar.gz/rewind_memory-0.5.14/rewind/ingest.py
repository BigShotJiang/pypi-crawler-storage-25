"""Ingest pipeline — chunk files into the memory stack.

Reads files from a workspace directory, chunks them, and writes to:
- L0: FTS5 index (chunks_fts) for BM25 keyword search
- L4: sqlite-vec (chunks_vec) for semantic vector search
- L3: SQLite graph (entity extraction from chunks)

Usage::

    from rewind.ingest import IngestPipeline
    from rewind.config import default_config

    pipeline = IngestPipeline(default_config("free"))
    stats = pipeline.ingest_directory("./workspace")
    print(stats)  # {"files": 42, "chunks": 186, "vectors": 186, "entities": 23}
"""

from __future__ import annotations

import logging
import os
import re
import sqlite3
import struct
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set

from rewind.config import RewindConfig, default_config

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Chunking
# ---------------------------------------------------------------------------

# File extensions we can ingest
TEXT_EXTENSIONS = {
    ".md", ".txt", ".py", ".js", ".ts", ".json", ".yaml", ".yml",
    ".toml", ".cfg", ".ini", ".sh", ".bash", ".zsh", ".html", ".css",
    ".xml", ".csv", ".rst", ".org", ".tex", ".r", ".sql", ".go",
    ".rs", ".java", ".kt", ".swift", ".c", ".cpp", ".h", ".hpp",
}

# Directories to skip
SKIP_DIRS = {
    "__pycache__", ".git", "node_modules", ".venv", "venv",
    ".mypy_cache", ".pytest_cache", ".tox", "dist", "build",
    ".eggs", "*.egg-info",
}

# Default chunk config
DEFAULT_MAX_CHARS = 1200
DEFAULT_OVERLAP = 100


def chunk_text(
    text: str,
    source_path: str = "",
    max_chars: int = DEFAULT_MAX_CHARS,
    overlap: int = DEFAULT_OVERLAP,
) -> List[Dict[str, Any]]:
    """Split text into overlapping chunks with section awareness.

    For markdown files, splits on ## / ### headings first.
    For other files, splits on double newlines or at max_chars boundaries.

    Returns list of dicts: {"text": str, "heading": str, "index": int}
    """
    if not text.strip():
        return []

    is_markdown = source_path.endswith(".md")

    if is_markdown:
        return _chunk_markdown(text, max_chars, overlap)
    else:
        return _chunk_plain(text, max_chars, overlap)


def _chunk_markdown(
    text: str, max_chars: int, overlap: int
) -> List[Dict[str, Any]]:
    """Chunk markdown by heading boundaries."""
    chunks: List[Dict[str, Any]] = []
    sections = re.split(r"(^#{1,3}\s+.+$)", text, flags=re.MULTILINE)

    current_heading = ""
    current_text = ""
    idx = 0

    for part in sections:
        if re.match(r"^#{1,3}\s+", part):
            if current_text.strip():
                for sub in _split_long(current_text.strip(), max_chars, overlap):
                    chunks.append({
                        "text": sub,
                        "heading": current_heading,
                        "index": idx,
                    })
                    idx += 1
            current_heading = part.strip().lstrip("#").strip()
            current_text = ""
        else:
            current_text += part

    if current_text.strip():
        for sub in _split_long(current_text.strip(), max_chars, overlap):
            chunks.append({
                "text": sub,
                "heading": current_heading,
                "index": idx,
            })
            idx += 1

    # Fallback
    if not chunks and text.strip():
        chunks.append({"text": text.strip()[:max_chars], "heading": "", "index": 0})

    return chunks


def _chunk_plain(
    text: str, max_chars: int, overlap: int
) -> List[Dict[str, Any]]:
    """Chunk plain text by paragraph boundaries."""
    paragraphs = re.split(r"\n\n+", text)
    chunks: List[Dict[str, Any]] = []
    current = ""
    idx = 0

    for para in paragraphs:
        para = para.strip()
        if not para:
            continue
        if len(current) + len(para) + 2 > max_chars and current:
            chunks.append({"text": current, "heading": "", "index": idx})
            idx += 1
            # Keep overlap from end of current chunk
            current = current[-overlap:] + "\n\n" + para if overlap else para
        else:
            current = current + "\n\n" + para if current else para

    if current.strip():
        chunks.append({"text": current.strip(), "heading": "", "index": idx})

    if not chunks and text.strip():
        for sub in _split_long(text.strip(), max_chars, overlap):
            chunks.append({"text": sub, "heading": "", "index": len(chunks)})

    return chunks


def _split_long(text: str, max_chars: int, overlap: int) -> List[str]:
    """Split text exceeding max_chars into overlapping windows."""
    if len(text) <= max_chars:
        return [text]

    parts: List[str] = []
    start = 0
    while start < len(text):
        end = start + max_chars
        # Try to break at a sentence or newline boundary
        if end < len(text):
            for sep in ["\n\n", "\n", ". ", "! ", "? "]:
                bp = text.rfind(sep, start + max_chars // 2, end)
                if bp > start:
                    end = bp + len(sep)
                    break
        parts.append(text[start:end].strip())
        start = end - overlap if overlap else end

    return [p for p in parts if p]


# ---------------------------------------------------------------------------
# Simple entity extraction (no LLM needed)
# ---------------------------------------------------------------------------

# Common stop words for entity filtering
_ENTITY_STOP = frozenset({
    "the", "and", "for", "with", "that", "this", "from", "what",
    "how", "does", "have", "has", "are", "was", "were", "been",
    "not", "but", "can", "will", "all", "any", "each", "which",
    "when", "where", "who", "why", "its", "also", "than", "then",
    "into", "only", "other", "some", "such", "new", "use", "used",
    "using", "may", "must", "should", "would", "could", "very",
    "true", "false", "none", "null", "todo", "note", "see",
})


_SPACY_NLP = None

def _get_spacy_nlp():
    """Lazy-load spaCy en_core_web_sm, return None if not installed."""
    global _SPACY_NLP
    if _SPACY_NLP is False:  # previously failed
        return None
    if _SPACY_NLP is None:
        try:
            import spacy
            _SPACY_NLP = spacy.load("en_core_web_sm")
        except Exception as exc:
            log.info(f"spaCy not available, using heuristic entity extraction: {exc}")
            _SPACY_NLP = False
            return None
    return _SPACY_NLP


def extract_entities_spacy(text: str, max_entities: int = 50) -> List[Dict[str, str]]:
    """Extract named entities + salient noun/verb lemmas using spaCy.

    Returns proper entity types (PERSON, GPE, ORG, DATE, EVENT, etc.) plus
    lemmatised nouns/verbs that serve as topic anchors. Falls back to the
    heuristic extractor if spaCy is not installed.

    Why lemmas matter: conversations use inflected forms ("researching",
    "researched", "has researched") that won't match the question term
    "research". Lemmatisation normalises them so graph lookups and BM25
    expansion catch them reliably.
    """
    nlp = _get_spacy_nlp()
    if nlp is None:
        return extract_entities(text)

    entities: List[Dict[str, str]] = []
    seen: set = set()

    SPACY_LABELS = {
        "PERSON": "Person",
        "GPE": "Place",
        "LOC": "Place",
        "ORG": "Organisation",
        "EVENT": "Event",
        "WORK_OF_ART": "Work",
        "PRODUCT": "Product",
        "NORP": "Group",
        "FAC": "Place",
        "DATE": "Date",
        "TIME": "Date",
    }

    # Noun/verb skip list (question-words, aux verbs, bland fillers)
    SKIP_LEMMAS = {
        "be", "have", "do", "go", "get", "make", "take", "give", "know",
        "think", "want", "need", "like", "say", "tell", "see", "look",
        "come", "use", "find", "try", "work", "feel", "leave", "call",
        "what", "who", "where", "when", "how", "why", "which", "that",
        "thing", "time", "day", "year", "way", "people", "man", "woman",
        "life", "world", "hand", "part", "place", "case", "week", "company",
        "system", "group", "number", "point", "government", "problem", "fact",
    }

    doc = nlp(text[:5000])  # cap for speed

    # Named entities
    for ent in doc.ents:
        label = SPACY_LABELS.get(ent.label_)
        if not label:
            continue
        name = ent.text.strip()
        if len(name) < 2:
            continue
        key = name.lower()
        if key in seen:
            continue
        seen.add(key)
        entities.append({"name": name, "label": label})
        if len(entities) >= max_entities:
            return entities

    # Salient noun/verb lemmas (topic anchors)
    for token in doc:
        if token.pos_ not in ("NOUN", "PROPN", "VERB"):
            continue
        lemma = token.lemma_.strip().lower()
        if (not lemma
                or len(lemma) < 3
                or not lemma.isalpha()
                or lemma in SKIP_LEMMAS
                or lemma in seen):
            continue
        seen.add(lemma)
        label = "Topic" if token.pos_ in ("NOUN", "VERB") else "Entity"
        entities.append({"name": lemma, "label": label})
        if len(entities) >= max_entities:
            return entities

    return entities


def extract_entities(text: str) -> List[Dict[str, str]]:
    """Extract named entities from text using simple heuristics.

    Returns list of {"name": str, "label": str} dicts.
    No LLM required — uses capitalisation, patterns, and context clues.
    """
    entities: List[Dict[str, str]] = []
    seen: Set[str] = set()

    # Title-case words (proper nouns)
    words = text.split()
    for i, word in enumerate(words):
        clean = re.sub(r"[^\w\s-]", "", word).strip()
        if not clean or len(clean) < 3:
            continue
        if clean.lower() in _ENTITY_STOP:
            continue

        if clean[0].isupper() and not clean.isupper():
            # Check for multi-word entities
            name = clean
            if i + 1 < len(words):
                next_word = re.sub(r"[^\w\s-]", "", words[i + 1]).strip()
                if next_word and next_word[0:1].isupper() and len(next_word) > 2:
                    name = f"{clean} {next_word}"

            if name.lower() not in seen and name.lower() not in _ENTITY_STOP:
                seen.add(name.lower())
                entities.append({"name": name, "label": "Entity"})

    # Email addresses → Person
    for email in re.findall(r"[\w.+-]+@[\w.-]+\.\w+", text):
        local = email.split("@")[0].replace(".", " ").replace("_", " ").title()
        if local.lower() not in seen:
            seen.add(local.lower())
            entities.append({"name": local, "label": "Person"})

    # URLs → System/Project
    for url in re.findall(r"https?://[\w.-]+(?:/[\w./-]*)?", text):
        domain = url.split("//")[1].split("/")[0]
        if domain not in seen and "localhost" not in domain:
            seen.add(domain)
            entities.append({"name": domain, "label": "System"})

    return entities[:50]  # Cap to prevent explosion


def _extract_entities_modal(text: str, modal_cfg) -> Dict[str, Any]:
    """Extract entities and relations via Modal Graph-Preflexor endpoint."""
    import httpx
    extract_url = modal_cfg.extract_url
    if not extract_url:
        return {"nodes": [], "edges": []}
    auth_token = modal_cfg.resolve_auth()
    try:
        resp = httpx.post(
            extract_url,
            json={"auth_token": auth_token, "text": text[:4096]},
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json()
        return {
            "nodes": data.get("nodes", []),
            "edges": data.get("edges", []),
        }
    except Exception as exc:
        log.debug(f"Modal graph extraction failed: {exc}")
        return {"nodes": [], "edges": []}


def extract_entities_ollama(
    text: str,
    url: str = "http://localhost:11434",
    model: str = "graph-preflexor:v3c",
) -> Dict[str, Any]:
    """Extract entities and relations using Graph-PReFLexOR via Ollama.

    Returns {"nodes": [...], "edges": [...]} or falls back to heuristic.
    """
    try:
        import httpx

        resp = httpx.post(
            f"{url}/api/generate",
            json={
                "model": model,
                "prompt": text[:2000],
                "stream": False,
                "options": {"temperature": 0.1, "num_predict": 300},
            },
            timeout=60,
        )
        resp.raise_for_status()
        raw = resp.json().get("response", "")

        # Parse JSON — model prefills with { so prepend it
        full = "{" + raw if not raw.strip().startswith("{") else raw
        # Cut at </think> if present
        if "</think>" in full:
            full = full[:full.index("</think>")]
        # Find JSON object
        start = full.find("{")
        end = full.rfind("}") + 1
        if start >= 0 and end > start:
            import json as _json
            result = _json.loads(full[start:end])
            return {
                "nodes": result.get("nodes", []),
                "edges": result.get("edges", []),
            }
    except Exception as exc:
        log.debug("Ollama KG extraction failed, falling back to heuristic: %s", exc)

    # Fallback to heuristic
    entities = extract_entities(text)
    return {
        "nodes": [{"name": e["name"], "type": e["label"]} for e in entities],
        "edges": [],
    }


# ---------------------------------------------------------------------------
# Ingest Pipeline
# ---------------------------------------------------------------------------

class IngestPipeline:
    """Chunks files and writes to L0 (FTS5), L4 (sqlite-vec), and L3 (graph).

    Usage::

        pipeline = IngestPipeline(config)
        stats = pipeline.ingest_directory("./workspace")
        # or single file:
        stats = pipeline.ingest_file("./workspace/MEMORY.md")
    """

    def __init__(
        self,
        config: Optional[RewindConfig] = None,
        embedding_fn: Optional[Callable[[str], List[float]]] = None,
    ) -> None:
        self.config = config or default_config()
        self._embedding_fn = embedding_fn
        self._db_conn: Optional[sqlite3.Connection] = None
        self._graph = None
        self._embed_dim: Optional[int] = None

    def _get_conn(self) -> sqlite3.Connection:
        """Get or create a SQLite connection for L0+L4.
        
        Uses per-thread connections to avoid 'SQLite objects created in a 
        thread can only be used in that same thread' errors when the file
        watcher ingests from multiple threads concurrently.
        """
        import threading
        tid = threading.get_ident()
        
        if not hasattr(self, '_thread_conns'):
            self._thread_conns: dict[int, sqlite3.Connection] = {}
        
        if tid in self._thread_conns:
            return self._thread_conns[tid]

        db_path = os.path.expanduser(self.config.vector_db_path)
        os.makedirs(os.path.dirname(db_path) or ".", exist_ok=True)

        conn = sqlite3.connect(db_path, timeout=30, check_same_thread=False)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA busy_timeout=5000")
        self._ensure_schema(conn)
        self._thread_conns[tid] = conn
        return conn

    def _ensure_schema(self, conn: sqlite3.Connection) -> None:
        """Create chunks, chunks_fts, and chunks_vec tables if needed."""
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS chunks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                path TEXT NOT NULL,
                text TEXT NOT NULL,
                heading TEXT DEFAULT '',
                source TEXT DEFAULT 'file',
                chunk_index INTEGER DEFAULT 0,
                created_at TEXT DEFAULT (datetime('now')),
                updated_at TEXT DEFAULT (datetime('now'))
            );
            CREATE INDEX IF NOT EXISTS idx_chunks_path ON chunks(path);
        """)
        # Best-effort add column for pre-existing DBs that lack updated_at
        try:
            conn.execute("ALTER TABLE chunks ADD COLUMN updated_at TEXT")
        except sqlite3.OperationalError:
            pass  # column already exists

        # FTS5 virtual table for L0
        try:
            conn.execute("""
                CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts
                USING fts5(path, text, content=chunks, content_rowid=id)
            """)
        except Exception as e:
            log.warning("FTS5 table creation failed (may already exist): %s", e)

        conn.commit()

    def _ensure_vec_table(self, conn: sqlite3.Connection, dim: int) -> bool:
        """Create (or migrate) the vec0 virtual table for L4.

        sqlite-vec's ``vec0`` declares its dimension at CREATE time and does NOT
        honour a later CREATE-IF-NOT-EXISTS with a different dimension — it
        silently keeps the old dim, and the next INSERT explodes with
        ``Dimension mismatch. Expected N but received M``.

        This function:
          1. Detects existing ``chunks_vec`` dimension from ``sqlite_master``.
          2. If it matches ``dim``: no-op.
          3. If it differs: drops the table (vectors are regenerable from
             ``chunks.text`` on next ingest) and recreates at the new dim.
          4. If it does not exist: creates it at the new dim.

        Returns True if the table is usable at the requested dim, False if
        sqlite-vec is unavailable or creation failed.
        """
        try:
            from rewind.utils import load_vec0
            if not load_vec0(conn):
                log.debug("sqlite-vec not available — L4 vectors will be skipped")
                return False

            # 1. Detect existing dimension, if any.
            row = conn.execute(
                "SELECT sql FROM sqlite_master WHERE type='table' AND name='chunks_vec'"
            ).fetchone()
            existing_dim: Optional[int] = None
            if row and row[0]:
                import re
                m = re.search(r"float\[(\d+)\]", row[0])
                if m:
                    existing_dim = int(m.group(1))

            if existing_dim is not None and existing_dim != dim:
                # 3. Dim mismatch — migrate. Vectors are regenerable from
                # chunks.text, so drop + recreate is safe. Log loudly so
                # an operator understands the first-ingest re-embed cost.
                try:
                    existing_rows = conn.execute(
                        "SELECT COUNT(*) FROM chunks_vec"
                    ).fetchone()[0]
                except Exception:
                    existing_rows = "unknown"
                log.warning(
                    "L4 dimension migration: chunks_vec was %s-dim, now %s-dim "
                    "(discarding %s stale vectors; they will be re-embedded "
                    "from chunks.text on this ingest run). "
                    "This is expected during a Free→Pro upgrade.",
                    existing_dim, dim, existing_rows,
                )
                conn.execute("DROP TABLE chunks_vec")
                # Invalidate cached embeddings: blank the hash column on
                # chunks so the ingest loop re-embeds every row. The hash
                # column is optional — skip gracefully if schema is older.
                try:
                    conn.execute("UPDATE chunks SET hash = '' WHERE hash IS NOT NULL")
                except Exception:
                    pass
                conn.commit()
                existing_dim = None  # fall through to CREATE

            if existing_dim is None:
                conn.execute(
                    f"CREATE VIRTUAL TABLE chunks_vec USING vec0(embedding float[{dim}])"
                )
                conn.commit()
            # else: existing_dim == dim, nothing to do.
            return True
        except Exception as e:
            log.warning("vec0 table creation failed: %s", e)
            return False

    def _get_embedding_fn(self) -> Optional[Callable[[str], List[float]]]:
        """Get embedding function from config."""
        if self._embedding_fn:
            return self._embedding_fn

        cfg = self.config.embedding
        if cfg.provider == "ollama":
            try:
                import httpx

                def embed(text: str) -> List[float]:
                    resp = httpx.post(
                        f"{cfg.url}/api/embed",
                        json={"model": cfg.model, "input": text},
                        timeout=30,
                    )
                    resp.raise_for_status()
                    data = resp.json()
                    return data["embeddings"][0] if "embeddings" in data else data["embedding"]

                return embed
            except ImportError:
                log.warning("httpx not installed — embeddings unavailable")
                return None

        elif cfg.provider in ("nv_embed", "openai"):
            try:
                import httpx
            except ImportError:
                log.warning("httpx not installed — embeddings unavailable")
                return None

            if cfg.url == "modal":
                # Modal cloud endpoint — different API format.
                # Requires explicit config (modal.embed_url or REWIND_EMBED_URL).
                modal_cfg = self.config.modal
                modal_url = modal_cfg.embed_url
                if not modal_url:
                    log.error(
                        "Ingest: provider=modal but no embed_url configured. "
                        "Set modal.embed_url in config.yaml or REWIND_EMBED_URL env var."
                    )
                    return None
                modal_auth = modal_cfg.resolve_auth()

                def embed(text: str, _url=modal_url, _auth=modal_auth) -> List[float]:
                    resp = httpx.post(
                        _url,
                        json={"auth_token": _auth, "texts": [text[:4096]]},
                        timeout=120.0,
                    )
                    resp.raise_for_status()
                    data = resp.json()
                    embeddings = data.get("embeddings", [])
                    return embeddings[0] if embeddings else []

                return embed
            else:
                def embed(text: str, _url=cfg.url) -> List[float]:
                    resp = httpx.post(
                        f"{_url}/v1/embeddings",
                        json={"model": cfg.model, "input": text},
                        timeout=60,
                    )
                    resp.raise_for_status()
                    return resp.json()["data"][0]["embedding"]

                return embed

        return None

    def _get_graph(self):
        """Get or create the L3 graph backend."""
        if self._graph is not None:
            return self._graph

        if not self.config.layers.l3_graph:
            return None

        try:
            from rewind.layers.l3_graph_sqlite import L3GraphSQLite
            db_path = os.path.expanduser(self.config.vector_db_path)
            graph_db = str(Path(db_path).parent / "graph.db")
            self._graph = L3GraphSQLite(graph_db)
            return self._graph
        except Exception as exc:
            log.warning("L3 graph init failed: %s", exc)
            return None

    # -- Public API -------------------------------------------------------

    def ingest_file(
        self,
        file_path: str,
        source: str = "file",
    ) -> Dict[str, int]:
        """Ingest a single file into the memory stack.

        Args:
            file_path: Path to the file to ingest.
            source: Source label (e.g. "file", "chat", "email").

        Returns:
            Stats dict: {"chunks": N, "vectors": N, "entities": N}
        """
        path = Path(file_path)
        if not path.exists():
            return {"chunks": 0, "vectors": 0, "entities": 0, "error": "file not found"}

        ext = path.suffix.lower()
        if ext not in TEXT_EXTENSIONS:
            return {"chunks": 0, "vectors": 0, "entities": 0, "error": f"unsupported extension: {ext}"}

        try:
            text = path.read_text(errors="ignore")
        except Exception as exc:
            return {"chunks": 0, "vectors": 0, "entities": 0, "error": str(exc)}

        if not text.strip():
            return {"chunks": 0, "vectors": 0, "entities": 0}

        # Chunk
        chunks = chunk_text(text, str(path))
        if not chunks:
            return {"chunks": 0, "vectors": 0, "entities": 0}

        conn = self._get_conn()
        str_path = str(path.resolve())

        # Delete existing chunks for this path (re-ingest)
        conn.execute("DELETE FROM chunks WHERE path = ?", (str_path,))

        # Insert chunks into L0 (chunks + FTS5)
        chunk_ids: List[int] = []
        for chunk in chunks:
            cursor = conn.execute(
                "INSERT INTO chunks (path, text, heading, source, chunk_index) VALUES (?, ?, ?, ?, ?)",
                (str_path, chunk["text"], chunk.get("heading", ""), source, chunk["index"]),
            )
            chunk_ids.append(cursor.lastrowid)

        # Sync FTS5
        try:
            conn.execute("INSERT INTO chunks_fts(chunks_fts) VALUES('rebuild')")
        except Exception as e:
            log.debug("FTS5 rebuild: %s", e)

        conn.commit()

        # L4: Generate embeddings and insert vectors
        vectors_written = 0
        embed_fn = self._get_embedding_fn()
        if embed_fn:
            try:
                # Get dimension from first embedding
                test_emb = embed_fn(chunks[0]["text"][:500])
                if not test_emb:
                    log.debug("Embedding service unavailable — skipping L4 vectors")
                    embed_fn = None  # disable for remaining chunks
                    raise ValueError("no embeddings")
                dim = len(test_emb)

                if self._embed_dim is None:
                    self._embed_dim = dim
                    self._ensure_vec_table(conn, dim)

                # Parallel batched embedding — previously one chunk at a time,
                # which wasted 90%+ of wall time on HTTP + GPU kernel launch
                # overhead. NV-Embed can embed 50-100 texts in a single call.
                # We use a thread pool so the embedding backend batches our
                # overlapping requests naturally (OpenAI-style /v1/embeddings
                # accepts a list; NV-Embed sees N parallel POSTs and auto-
                # batches them on the GPU).
                import concurrent.futures

                texts = [chunk["text"][:500] for chunk in chunks]

                # Try true batched embedding first — if embed_fn accepts
                # a list and returns a list-of-lists, we get the biggest win.
                batched_embs = None
                try:
                    maybe = embed_fn(texts) if len(texts) > 1 else None
                    if isinstance(maybe, list) and maybe and isinstance(maybe[0], list):
                        batched_embs = maybe
                except Exception:
                    batched_embs = None

                if batched_embs is not None and len(batched_embs) == len(chunks):
                    # True batch path — one HTTP call for N texts
                    for chunk_id, emb in zip(chunk_ids, batched_embs):
                        try:
                            blob = struct.pack(f"{len(emb)}f", *emb)
                            conn.execute(
                                "INSERT INTO chunks_vec (rowid, embedding) VALUES (?, ?)",
                                (chunk_id, blob),
                            )
                            vectors_written += 1
                        except Exception as exc:
                            log.debug("Batch embedding insert failed for chunk %d: %s", chunk_id, exc)
                else:
                    # Fallback: parallel single-text calls so NV-Embed still
                    # batches them on the server side
                    def _embed_one(idx_text):
                        idx, text = idx_text
                        for attempt in range(3):
                            try:
                                return idx, embed_fn(text)
                            except Exception as exc:
                                msg = str(exc)
                                if "429" in msg or "Too Many" in msg:
                                    import time as _t
                                    wait = 2 ** attempt + 1
                                    log.debug("Rate limited on chunk %d, retrying in %ds", chunk_ids[idx], wait)
                                    _t.sleep(wait)
                                    continue
                                log.debug("Embedding failed for chunk %d: %s", chunk_ids[idx], exc)
                                return idx, None
                        return idx, None

                    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
                        results = list(pool.map(_embed_one, enumerate(texts)))

                    for idx, emb in results:
                        if not emb:
                            continue
                        try:
                            blob = struct.pack(f"{len(emb)}f", *emb)
                            conn.execute(
                                "INSERT INTO chunks_vec (rowid, embedding) VALUES (?, ?)",
                                (chunk_ids[idx], blob),
                            )
                            vectors_written += 1
                        except Exception as exc:
                            log.debug("Parallel embed insert failed for chunk %d: %s", chunk_ids[idx], exc)

                conn.commit()
            except ValueError:
                pass  # no embeddings available — expected on free tier without Ollama
            except Exception as exc:
                log.debug("L4 vector ingest skipped: %s", exc)

        # L3: Extract entities and add to graph
        entities_added = 0
        graph = self._get_graph()
        # `graph_extraction` is an optional config attr; fresh default
        # configs (no YAML) don't include it. Fall back to spaCy-only
        # extraction (no LLM) rather than crashing.
        class _GEDefault:
            provider = "spacy"
            url = ""
            model = ""
        ge = getattr(self.config, "graph_extraction", None) or _GEDefault()
        if graph:
            use_ollama = ge.provider == "ollama"
            use_modal = ge.provider == "modal"
            all_entities: List[str] = []
            # Labels that represent actual named entities (not topic
            # anchors). We create edges between named entities co-occurring
            # in the same chunk so graph traversal works as expected
            # (e.g. Caroline → Sweden via the session_4 chunk where both
            # are mentioned). Topic lemmas (research, move, art) are stored
            # as nodes but NOT cross-linked, to avoid edge explosion.
            NAMED_LABELS = {"Person", "Place", "Organisation", "Event",
                            "Work", "Product", "Group"}

            for chunk_idx, chunk in enumerate(chunks):
                if use_ollama or use_modal:
                    if use_modal:
                        result = _extract_entities_modal(
                            chunk["text"], self.config.modal,
                        )
                    else:
                        result = extract_entities_ollama(
                            chunk["text"], url=ge.url, model=ge.model,
                        )
                    chunk_id = chunk_ids[chunk_idx] if chunk_idx < len(chunk_ids) else None
                    chunk_props = {
                        "chunk_id": chunk_id,
                        "chunk_text": chunk["text"][:500],
                        "chunk_path": str_path,
                    }
                    chunk_named_entities: List[str] = []
                    for node in result.get("nodes", []):
                        name = node.get("name", "")
                        label = node.get("type", "Entity")
                        if name:
                            graph.add_node(name, label, properties=chunk_props)
                            all_entities.append(name)
                            entities_added += 1
                            if label in NAMED_LABELS:
                                chunk_named_entities.append(name)
                    for edge in result.get("edges", []):
                        src, tgt, rel = edge.get("source", ""), edge.get("target", ""), edge.get("relation", "RELATED_TO")
                        if src and tgt:
                            graph.add_edge(src, tgt, rel)
                    # Create co-occurrence edges between named entities in same chunk
                    for i, e1 in enumerate(chunk_named_entities):
                        for e2 in chunk_named_entities[i + 1:]:
                            graph.add_edge(e1, e2, "CO_OCCURS")
                else:
                    # Use spaCy NER + lemma extraction when available,
                    # falls back to heuristic internally if spaCy is missing.
                    # Each entity extracted from a chunk is stored WITH the
                    # chunk properties so L3 search can return actual chunk
                    # text, not just useless relationship triples.
                    chunk_id = chunk_ids[chunk_idx] if chunk_idx < len(chunk_ids) else None
                    chunk_props = {
                        "chunk_id": chunk_id,
                        "chunk_text": chunk["text"][:500],
                        "chunk_path": str_path,
                    }
                    chunk_named_entities: List[str] = []
                    for ent in extract_entities_spacy(chunk["text"]):
                        node_name = ent["name"]
                        graph.add_node(
                            node_name,
                            ent["label"],
                            properties=chunk_props,
                        )
                        all_entities.append(node_name)
                        entities_added += 1
                        if ent["label"] in NAMED_LABELS:
                            chunk_named_entities.append(node_name)

                    # Detect user preferences and add as graph nodes
                    _PREFERENCE_PATTERNS = [
                        r"(?:I|my|we)\s+(?:use|prefer|like|love|have|own|bought|got)\s+(.+?)(?:\.|,|$)",
                        r"(?:I'm|I am)\s+(?:a|an)\s+(.+?)(?:\.|,|$)",
                        r"(?:my\s+favorite|my\s+favourite)\s+(?:is|are)\s+(.+?)(?:\.|,|$)",
                    ]
                    for _pref_pat in _PREFERENCE_PATTERNS:
                        _pref_matches = re.findall(_pref_pat, chunk["text"], re.IGNORECASE)
                        for _pref_match in _pref_matches:
                            _pref_match = _pref_match.strip()[:50]
                            if _pref_match and len(_pref_match) > 3:
                                graph.add_node(_pref_match, "Preference")
                                # Link preference to first person entity in chunk
                                for _ent_name in chunk_named_entities[:1]:
                                    graph.add_edge(_ent_name, _pref_match, "PREFERS")

                    # Per-chunk co-occurrence edges between NAMED entities.
                    # This is what gives the graph real traversal value:
                    # (Caroline)-[CO_OCCURS]->(Sweden) when both appear
                    # in chunk 29. Topic lemmas are skipped to keep edge
                    # count bounded.
                    if not use_ollama and len(chunk_named_entities) >= 2:
                        unique_named = list(dict.fromkeys(chunk_named_entities))
                        for i, e1 in enumerate(unique_named):
                            for e2 in unique_named[i + 1:]:
                                graph.add_edge(e1, e2, "CO_OCCURS")

        return {
            "chunks": len(chunks),
            "vectors": vectors_written,
            "entities": entities_added,
        }

    def ingest_directory(
        self,
        directory: str,
        source: str = "file",
        recursive: bool = True,
    ) -> Dict[str, Any]:
        """Ingest all supported files from a directory.

        Args:
            directory: Path to the directory to scan.
            source: Source label for all files.
            recursive: Whether to recurse into subdirectories.

        Returns:
            Stats dict with totals and per-file breakdown.
        """
        root = Path(directory).resolve()
        if not root.is_dir():
            return {"error": f"Not a directory: {directory}", "files": 0}

        start = time.time()
        totals = {"files": 0, "chunks": 0, "vectors": 0, "entities": 0, "errors": 0}
        file_stats: List[Dict] = []

        pattern = root.rglob("*") if recursive else root.glob("*")

        for path in sorted(pattern):
            if not path.is_file():
                continue

            # Skip hidden and excluded directories
            parts = path.relative_to(root).parts
            if any(p.startswith(".") or p in SKIP_DIRS for p in parts[:-1]):
                continue

            ext = path.suffix.lower()
            if ext not in TEXT_EXTENSIONS:
                continue

            stats = self.ingest_file(str(path), source)
            totals["files"] += 1
            totals["chunks"] += stats.get("chunks", 0)
            totals["vectors"] += stats.get("vectors", 0)
            totals["entities"] += stats.get("entities", 0)
            if "error" in stats:
                totals["errors"] += 1

            if stats.get("chunks", 0) > 0:
                file_stats.append({"path": str(path), **stats})

            # Progress logging every 50 files
            if totals["files"] % 50 == 0:
                log.info(
                    "Ingest progress: %d files, %d chunks, %d vectors",
                    totals["files"], totals["chunks"], totals["vectors"],
                )

        elapsed = time.time() - start
        totals["elapsed_seconds"] = round(elapsed, 2)
        totals["files_detail"] = file_stats

        log.info(
            "Ingest complete: %d files → %d chunks, %d vectors, %d entities in %.1fs",
            totals["files"], totals["chunks"], totals["vectors"],
            totals["entities"], elapsed,
        )

        return totals

    def ingest_chat(
        self,
        messages: List[Dict[str, Any]],
        collection: str = "conversations",
        qdrant_url: str = "http://localhost:6333",
    ) -> Dict[str, int]:
        """Ingest chat messages into comms layer (Pro tier).

        Args:
            messages: List of dicts with keys: text, contact_name, channel,
                date_str, source_file (all optional except text).
            collection: Qdrant collection name.
            qdrant_url: Qdrant HTTP URL.

        Returns:
            Stats dict: {"points": N, "skipped": N}
        """
        embed_fn = self._get_embedding_fn()
        if not embed_fn:
            return {"points": 0, "skipped": len(messages), "error": "no embedding function"}

        try:
            import httpx
        except ImportError:
            return {"points": 0, "skipped": len(messages), "error": "httpx not installed"}

        # Ensure collection exists
        client = httpx.Client(base_url=qdrant_url, timeout=30)
        test_emb = embed_fn(messages[0]["text"][:500]) if messages else []
        if not test_emb:
            client.close()
            return {"points": 0, "skipped": len(messages), "error": "embedding failed"}

        dim = len(test_emb)
        try:
            client.put(f"/collections/{collection}", json={
                "vectors": {"size": dim, "distance": "Cosine"},
            })
        except Exception:
            pass  # may exist

        points_written = 0
        skipped = 0
        batch: List[Dict] = []

        for i, msg in enumerate(messages):
            text = msg.get("text", "").strip()
            if not text:
                skipped += 1
                continue

            emb = embed_fn(text[:500])
            if not emb:
                skipped += 1
                continue

            batch.append({
                "id": abs(hash(f"{collection}:{i}:{text[:50]}")) % (2**63),
                "vector": emb,
                "payload": {
                    "text": text[:2000],
                    "contact_name": msg.get("contact_name", ""),
                    "channel": msg.get("channel", ""),
                    "date_str": msg.get("date_str", ""),
                    "source_file": msg.get("source_file", ""),
                    "confidence": 1.0,
                },
            })

            if len(batch) >= 50:
                try:
                    client.put(
                        f"/collections/{collection}/points",
                        json={"points": batch},
                    )
                    points_written += len(batch)
                except Exception as exc:
                    log.warning("Chat ingest batch failed: %s", exc)
                    skipped += len(batch)
                batch = []

        if batch:
            try:
                client.put(
                    f"/collections/{collection}/points",
                    json={"points": batch},
                )
                points_written += len(batch)
            except Exception as exc:
                log.warning("Chat ingest final batch failed: %s", exc)
                skipped += len(batch)

        client.close()
        return {"points": points_written, "skipped": skipped}

    def ingest_emails(
        self,
        emails: List[Dict[str, Any]],
        qdrant_url: str = "http://localhost:6333",
    ) -> Dict[str, int]:
        """Ingest emails into comms layer (Pro tier).

        Args:
            emails: List of dicts with keys: subject, body, from_addr,
                to_addr, date_str, source_file.

        Returns:
            Stats dict.
        """
        # Convert emails to messages format
        messages = []
        for email in emails:
            subject = email.get("subject", "")
            body = email.get("body", "")
            text = f"Subject: {subject}\n\n{body}" if subject else body
            messages.append({
                "text": text,
                "contact_name": email.get("from_addr", ""),
                "channel": "email",
                "date_str": email.get("date_str", ""),
                "source_file": email.get("source_file", ""),
            })
        return self.ingest_chat(messages, collection="emails", qdrant_url=qdrant_url)

    def close(self) -> None:
        """Close all connections."""
        if self._db_conn:
            self._db_conn.close()
            self._db_conn = None
        if self._graph:
            self._graph.close()
            self._graph = None
