"""L3 Graph (SQLite) — lightweight knowledge graph for free tier.

Provides the same interface as L3Graph (Neo4j) but backed by SQLite.
Uses adjacency lists with recursive CTEs for multi-hop traversal.
Supports Hebbian edge strengthening and spreading activation.
"""

import logging
import sqlite3
from datetime import datetime
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)


class L3GraphSQLite:
    """SQLite-backed knowledge graph with spreading activation.

    Schema:
        - nodes(id, name, label, properties_json, created_at, updated_at)
        - edges(id, source_id, target_id, rel_type, weight, last_accessed, created_at)

    Scores match the Neo4j L3Graph interface:
        - Direct matches: min(0.95, 0.7 + edge_weight * 0.1)
        - 2-hop activation: min(0.85, 0.5 + activation * 0.05)
    """

    def __init__(self, db_path: str) -> None:
        self.db_path = db_path
        self._conn: Optional[sqlite3.Connection] = None

    def _get_conn(self) -> sqlite3.Connection:
        if self._conn is None:
            self._conn = sqlite3.connect(self.db_path, timeout=5,
                                         check_same_thread=False)
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA foreign_keys=ON")
            self._conn.row_factory = sqlite3.Row
            self._ensure_schema()
        return self._conn

    def _ensure_schema(self) -> None:
        conn = self._conn
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS nodes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                label TEXT DEFAULT 'Entity',
                properties_json TEXT DEFAULT '{}',
                created_at TEXT DEFAULT (datetime('now')),
                updated_at TEXT DEFAULT (datetime('now'))
            );
            CREATE UNIQUE INDEX IF NOT EXISTS idx_nodes_name_label
                ON nodes(name, label);
            CREATE INDEX IF NOT EXISTS idx_nodes_name
                ON nodes(name);

            CREATE TABLE IF NOT EXISTS edges (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_id INTEGER NOT NULL REFERENCES nodes(id),
                target_id INTEGER NOT NULL REFERENCES nodes(id),
                rel_type TEXT DEFAULT 'RELATED_TO',
                weight REAL DEFAULT 1.0,
                last_accessed TEXT DEFAULT (datetime('now')),
                created_at TEXT DEFAULT (datetime('now'))
            );
            CREATE INDEX IF NOT EXISTS idx_edges_source ON edges(source_id);
            CREATE INDEX IF NOT EXISTS idx_edges_target ON edges(target_id);
        """)
        conn.commit()

    def warmup(self) -> None:
        """Pre-warm connection."""
        self._get_conn()
        log.info("L3 SQLite graph warmed up: %s", self.db_path)

    def search(
        self,
        query: str,
        entities: Optional[List[str]] = None,
        limit: int = 8,
    ) -> Dict[str, Any]:
        """Search the graph for entity matches + 2-hop spreading activation.

        Returns dict matching L3Graph interface:
            {"results": [...], "graph_entities": [...], "entity_count": int}
        """
        conn = self._get_conn()
        if not entities:
            # Extract entities from query using spaCy if available, falling
            # back to capitalised-word heuristic otherwise. spaCy gives us
            # lemmatised nouns/verbs (research, move, art) in addition to
            # NER entities (Caroline, Sweden), which dramatically improves
            # graph lookup recall on questions.
            try:
                from rewind.ingest import _get_spacy_nlp
                nlp = _get_spacy_nlp()
                if nlp is not None:
                    doc = nlp(query)
                    ent_set: set = set()
                    SPACY_LABELS = {"PERSON", "GPE", "LOC", "ORG",
                                    "EVENT", "WORK_OF_ART", "PRODUCT",
                                    "NORP", "FAC"}
                    SKIP = {"be", "have", "do", "go", "get", "make", "take",
                            "give", "know", "think", "want", "need", "like",
                            "what", "who", "where", "when", "how", "why",
                            "which", "that"}
                    for e in doc.ents:
                        if e.label_ in SPACY_LABELS:
                            ent_set.add(e.text.strip())
                    for t in doc:
                        if t.pos_ in ("NOUN", "PROPN", "VERB"):
                            lemma = t.lemma_.strip().lower()
                            if (lemma and len(lemma) > 2
                                    and lemma.isalpha()
                                    and lemma not in SKIP):
                                ent_set.add(lemma)
                    entities = list(ent_set)
                else:
                    entities = [
                        w for w in query.split()
                        if w[0:1].isupper() and len(w) > 2
                    ]
            except Exception:
                entities = [
                    w for w in query.split()
                    if w[0:1].isupper() and len(w) > 2
                ]

        if not entities:
            return {"results": [], "graph_entities": [], "entity_count": 0}

        results: List[Dict] = []
        graph_entities: List[str] = []
        all_node_names: List[str] = []

        for entity in entities:
            # Direct entity match
            direct = conn.execute("""
                SELECT n.id, n.name, n.label, n.properties_json,
                       e.rel_type, e.weight,
                       cn.name as connected_name, cn.label as connected_label
                FROM nodes n
                LEFT JOIN edges e ON (e.source_id = n.id OR e.target_id = n.id)
                    AND e.weight >= 0.2
                LEFT JOIN nodes cn ON (
                    CASE WHEN e.source_id = n.id THEN e.target_id ELSE e.source_id END = cn.id
                )
                WHERE n.name LIKE ? COLLATE NOCASE
                ORDER BY e.weight DESC
                LIMIT ?
            """, (f"%{entity}%", limit)).fetchall()

            import json as _json
            _emitted_chunk_ids: set = set()
            for row in direct:
                node_name = row["name"]
                if node_name not in graph_entities:
                    graph_entities.append(node_name)
                if node_name not in all_node_names:
                    all_node_names.append(node_name)

                # Parse appended chunk list stored at ingest time
                try:
                    props = _json.loads(row["properties_json"] or "{}")
                except Exception:
                    props = {}
                chunk_list = props.get("chunks", [])

                edge_weight = row["weight"] or 1.0
                connected = row["connected_name"]
                if connected and connected not in graph_entities:
                    graph_entities.append(connected)

                if chunk_list:
                    # Emit one result per linked chunk. Score in the
                    # 0.65-0.80 range so strong L4 vectors can still win
                    # on semantic match, but graph-linked chunks rank
                    # above pure L0 BM25 hits. Score each chunk identically
                    # and rely on cross-encoder rerank to discriminate.
                    base_score = min(0.80, 0.65 + edge_weight * 0.02)
                    for ch in chunk_list[:5]:  # cap per-entity fanout
                        cid = ch.get("id")
                        if cid is not None and cid in _emitted_chunk_ids:
                            continue
                        if cid is not None:
                            _emitted_chunk_ids.add(cid)
                        chunk_text = ch.get("text", "")
                        if not chunk_text:
                            continue
                        results.append({
                            "text": chunk_text,
                            "score": base_score,
                            "layer": "L3_graph",
                            "source": "sqlite_graph",
                            "path": ch.get("path", ""),
                            "entity": node_name,
                            "connected": connected,
                            "edge_weight": edge_weight,
                        })
                else:
                    # Fallback: no linked chunks, return a relationship triple
                    score = min(0.45, 0.30 + edge_weight * 0.05)
                    results.append({
                        "text": f"{node_name} ({row['label']}) --[{row['rel_type'] or 'RELATED'}]--> {connected or ''}",
                        "score": score,
                        "layer": "L3_graph",
                        "source": "sqlite_graph",
                        "path": "",
                        "entity": node_name,
                        "connected": connected,
                        "edge_weight": edge_weight,
                    })

            # 2-hop spreading activation
            activated = conn.execute("""
                WITH start_nodes AS (
                    SELECT id, name FROM nodes
                    WHERE name LIKE ? COLLATE NOCASE
                    LIMIT 3
                ),
                hop1 AS (
                    SELECT s.id as start_id, s.name as start_name,
                           CASE WHEN e.source_id = s.id THEN e.target_id ELSE e.source_id END as mid_id,
                           e.weight as w1
                    FROM start_nodes s
                    JOIN edges e ON (e.source_id = s.id OR e.target_id = s.id)
                    WHERE e.weight >= 0.5
                    LIMIT 20
                ),
                hop2 AS (
                    SELECT h.start_name, h.mid_id,
                           CASE WHEN e.source_id = h.mid_id THEN e.target_id ELSE e.source_id END as end_id,
                           h.w1 * e.weight as activation,
                           mn.name as via_name
                    FROM hop1 h
                    JOIN edges e ON (e.source_id = h.mid_id OR e.target_id = h.mid_id)
                    JOIN nodes mn ON mn.id = h.mid_id
                    WHERE e.weight >= 0.5
                )
                SELECT DISTINCT en.name as end_name, en.label as end_label,
                       en.properties_json as end_props,
                       hop2.activation, hop2.via_name
                FROM hop2
                JOIN nodes en ON en.id = hop2.end_id
                WHERE en.name NOT IN (SELECT name FROM start_nodes)
                ORDER BY hop2.activation DESC
                LIMIT 5
            """, (f"%{entity}%",)).fetchall()

            for row in activated:
                end_name = row["end_name"]
                activation = row["activation"]

                if end_name not in graph_entities:
                    graph_entities.append(end_name)

                # Fetch the activated entity's chunks and emit them as
                # real retrieval results, not useless placeholder text.
                # This is the "Caroline → Sweden" traversal path: query
                # mentions Caroline, graph traversal surfaces Sweden via
                # the co-occurrence edge in session_4's chunk, we return
                # the actual Sweden chunk text.
                try:
                    end_props = _json.loads(row["end_props"] or "{}")
                except Exception:
                    end_props = {}
                end_chunks = end_props.get("chunks", [])

                if end_chunks:
                    # 2-hop chunks score below direct hits but still
                    # above pure BM25 — cap at 0.75 vs direct 0.80.
                    base_score = min(0.75, 0.55 + activation * 0.05)
                    for ch in end_chunks[:3]:  # cap 2-hop fanout
                        cid = ch.get("id")
                        if cid is not None and cid in _emitted_chunk_ids:
                            continue
                        if cid is not None:
                            _emitted_chunk_ids.add(cid)
                        chunk_text = ch.get("text", "")
                        if not chunk_text:
                            continue
                        results.append({
                            "text": chunk_text,
                            "score": base_score,
                            "layer": "L3_graph",
                            "source": "sqlite_graph_activation",
                            "path": ch.get("path", ""),
                            "entity": end_name,
                            "via": row["via_name"],
                            "activation": activation,
                        })
                else:
                    score = min(0.55, 0.40 + activation * 0.05)
                    results.append({
                        "text": f"[activated] {end_name} ({row['end_label']}) via {row['via_name']}",
                        "score": score,
                        "layer": "L3_graph",
                        "source": "sqlite_graph_activation",
                        "path": "",
                        "entity": end_name,
                        "via": row["via_name"],
                        "activation": activation,
                    })

        # Hebbian strengthening: edges between co-accessed entities
        self._hebbian_strengthen(conn, all_node_names)

        # Dedup and sort
        seen: set = set()
        unique: List[Dict] = []
        for r in results:
            key = (r.get("entity", ""), r.get("connected", ""))
            if key not in seen:
                unique.append(r)
                seen.add(key)

        unique.sort(key=lambda r: r["score"], reverse=True)

        return {
            "results": unique[:limit],
            "graph_entities": graph_entities[:20],
            "entity_count": len(graph_entities),
        }

    def _hebbian_strengthen(
        self,
        conn: sqlite3.Connection,
        node_names: List[str],
        increment: float = 0.05,
    ) -> None:
        """Strengthen edges between co-accessed nodes (Hebbian learning)."""
        if len(node_names) < 2:
            return
        now = datetime.utcnow().isoformat()
        for i, n1 in enumerate(node_names):
            for n2 in node_names[i + 1:]:
                try:
                    conn.execute("""
                        UPDATE edges SET
                            weight = weight + ?,
                            last_accessed = ?
                        WHERE id IN (
                            SELECT e.id FROM edges e
                            JOIN nodes s ON e.source_id = s.id
                            JOIN nodes t ON e.target_id = t.id
                            WHERE (s.name = ? AND t.name = ?)
                               OR (s.name = ? AND t.name = ?)
                        )
                    """, (increment, now, n1, n2, n2, n1))
                except Exception:
                    pass
        try:
            conn.commit()
        except Exception:
            pass

    # -- Mutation API (for ingest) --

    def add_node(self, name: str, label: str = "Entity",
                 properties: Optional[Dict] = None) -> int:
        """Insert a node or append chunk references to an existing node.

        When ``properties`` contains ``chunk_id``/``chunk_text``/``chunk_path``,
        we maintain an append-only list under ``properties_json.chunks`` so
        every chunk that references this entity is remembered. Without this,
        each entity would only know about its most recently ingested chunk,
        making L3 graph lookup useless for retrieval.
        """
        import json
        conn = self._get_conn()
        props = properties or {}

        # Check if node already exists
        existing = conn.execute(
            "SELECT id, properties_json FROM nodes WHERE name = ? AND label = ?",
            (name, label)
        ).fetchone()

        new_chunk_ref = None
        if any(k in props for k in ("chunk_id", "chunk_text", "chunk_path")):
            new_chunk_ref = {
                "id": props.get("chunk_id"),
                "text": props.get("chunk_text", "")[:500],
                "path": props.get("chunk_path", ""),
            }

        if existing:
            node_id = existing["id"]
            if new_chunk_ref is not None:
                try:
                    existing_props = json.loads(existing["properties_json"] or "{}")
                except Exception:
                    existing_props = {}
                chunks_list = existing_props.get("chunks", [])
                # Dedup by chunk_id to avoid unbounded growth
                existing_ids = {c.get("id") for c in chunks_list if c.get("id") is not None}
                if new_chunk_ref["id"] not in existing_ids:
                    chunks_list.append(new_chunk_ref)
                    # Cap list at 50 references per entity
                    existing_props["chunks"] = chunks_list[-50:]
                    try:
                        conn.execute(
                            "UPDATE nodes SET properties_json = ?, updated_at = datetime('now') WHERE id = ?",
                            (json.dumps(existing_props), node_id)
                        )
                        conn.commit()
                    except Exception as exc:
                        log.warning("add_node update failed: %s", exc)
            return node_id

        # New node — initial insert
        if new_chunk_ref is not None:
            props_json = json.dumps({"chunks": [new_chunk_ref]})
        else:
            props_json = json.dumps(props)

        try:
            conn.execute(
                "INSERT INTO nodes (name, label, properties_json) VALUES (?, ?, ?)",
                (name, label, props_json)
            )
            conn.commit()
            row = conn.execute(
                "SELECT id FROM nodes WHERE name = ? AND label = ?",
                (name, label)
            ).fetchone()
            return row["id"] if row else -1
        except Exception as exc:
            log.warning("add_node failed: %s", exc)
            return -1

    def add_edge(self, source_name: str, target_name: str,
                 rel_type: str = "RELATED_TO", weight: float = 1.0) -> bool:
        """Add an edge between two nodes (creates nodes if needed)."""
        src_id = self.add_node(source_name)
        tgt_id = self.add_node(target_name)
        if src_id < 0 or tgt_id < 0:
            return False
        conn = self._get_conn()
        try:
            conn.execute("""
                INSERT OR IGNORE INTO edges (source_id, target_id, rel_type, weight)
                VALUES (?, ?, ?, ?)
            """, (src_id, tgt_id, rel_type, weight))
            conn.commit()
            return True
        except Exception as exc:
            log.warning("add_edge failed: %s", exc)
            return False

    def count_entities(self, entity_type: str = None, connected_to: str = None) -> int:
        """Count entities, optionally filtered by type or connection.

        Args:
            entity_type: If set, count only nodes with this label.
            connected_to: If set, count distinct nodes connected to entities
                matching this name (case-insensitive substring match).

        Returns:
            Count of matching entities.
        """
        conn = self._get_conn()
        if connected_to:
            result = conn.execute("""
                SELECT COUNT(DISTINCT n2.name)
                FROM nodes n1
                JOIN edges e ON (e.source_id = n1.id OR e.target_id = n1.id)
                JOIN nodes n2 ON (n2.id = CASE WHEN e.source_id = n1.id THEN e.target_id ELSE e.source_id END)
                WHERE n1.name LIKE ? COLLATE NOCASE
            """, (f"%{connected_to}%",)).fetchone()
        elif entity_type:
            result = conn.execute(
                "SELECT COUNT(*) FROM nodes WHERE label = ?",
                (entity_type,)
            ).fetchone()
        else:
            result = conn.execute("SELECT COUNT(*) FROM nodes").fetchone()
        return result[0] if result else 0

    def health(self) -> Dict[str, Any]:
        """Health check.

        Returns ``ok (empty)`` when the database file does not yet exist
        (fresh install) rather than ``error``, since absence of data is not
        a fault in heuristic/SQLite mode.
        """
        import os
        db_path = os.path.expanduser(self.db_path)

        # Database has never been created yet — normal on a fresh install
        if not os.path.exists(db_path):
            return {
                "status": "ok",
                "backend": "sqlite",
                "db_path": db_path,
                "nodes": 0,
                "edges": 0,
                "detail": "empty (no data yet)",
            }

        try:
            conn = self._get_conn()
            node_count = conn.execute("SELECT COUNT(*) FROM nodes").fetchone()[0]
            edge_count = conn.execute("SELECT COUNT(*) FROM edges").fetchone()[0]
            return {
                "status": "ok",
                "backend": "sqlite",
                "db_path": db_path,
                "nodes": node_count,
                "edges": edge_count,
            }
        except Exception as exc:
            return {"status": "error", "detail": str(exc)}

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None
