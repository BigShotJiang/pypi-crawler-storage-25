"""L0 Full-Text Search — BM25/FTS5 keyword matching.

Bio-inspired analogy: **Reflexive pattern detection** (brainstem level).
The fastest, lowest-latency layer — sub-millisecond keyword matching over
pre-indexed workspace chunks. No network calls, no embeddings. Pure lexical
recall, like a startle reflex that fires before conscious processing begins.
"""

import hashlib
import logging
import os
import sqlite3
from pathlib import Path
from typing import Dict, List, Optional

log = logging.getLogger(__name__)

# Stop words filtered from queries to improve BM25 precision
_STOP_WORDS = frozenset({
    "the", "and", "for", "with", "that", "this", "from", "what",
    "how", "does", "have", "has", "are", "was", "were", "been",
})


class L0FullTextSearch:
    """BM25 keyword search over SQLite FTS5-indexed workspace chunks.

    Scores are normalised into [0, 0.70] using a dampened relevance formula
    so they sit below graph/vector layers in the fusion ranking.
    """

    def __init__(self, db_path: str, workspace: str = "") -> None:
        """Initialise with path to the SQLite database containing FTS5 tables.

        Args:
            db_path: Filesystem path to the SQLite DB (must have ``chunks_fts`` virtual table).
            workspace: Workspace directory for auto-building the index if DB is missing.
        """
        self.db_path = db_path
        self.workspace = workspace or os.environ.get("REWIND_WORKSPACE", "")
        self._auto_built = False

    def search(
        self,
        query: str,
        limit: int = 6,
        namespace: Optional[str] = None,
    ) -> List[Dict]:
        """Run BM25 keyword search.

        Args:
            query: Natural-language query string.
            limit: Maximum results to return.
            namespace: If set, restrict results to paths starting with this prefix.

        Returns:
            List of result dicts with keys: path, text, score, layer, source.
        """
        if not os.path.exists(self.db_path):
            if not self._auto_built:
                self._auto_build()
            if not os.path.exists(self.db_path):
                return []

        try:
            tokens = query.lower().split()
            meaningful = [
                t for t in tokens
                if len(t) > 2 and t not in _STOP_WORDS
            ]
            if not meaningful:
                return []

            fts_query = " OR ".join(f'"{t}"' for t in meaningful)

            conn = sqlite3.connect(self.db_path, timeout=2)
            conn.execute("PRAGMA journal_mode=WAL")

            # Check which timestamp columns exist (schemas evolve over time)
            _has_created_at = False
            _has_updated_at = False
            try:
                _cols = [r[1] for r in conn.execute("PRAGMA table_info(chunks)").fetchall()]
                _has_created_at = "created_at" in _cols
                _has_updated_at = "updated_at" in _cols
            except Exception:
                pass

            # Build SELECT list dynamically so we don't break old DBs.
            select_cols = ["c.path", "c.text", "bm25(chunks_fts) as rank"]
            if _has_created_at:
                select_cols.append("c.created_at")
            else:
                select_cols.append("NULL as created_at")
            if _has_updated_at:
                select_cols.append("c.updated_at")
            else:
                # Mirror created_at if updated_at is missing (best-effort for
                # integrators who expect the field in responses).
                select_cols.append(
                    "c.created_at as updated_at" if _has_created_at else "NULL as updated_at"
                )
            sql = f"""
                SELECT {', '.join(select_cols)}
                FROM chunks_fts
                JOIN chunks c ON c.rowid = chunks_fts.rowid
                WHERE chunks_fts MATCH ?
            """
            params: list = [fts_query]

            if namespace:
                sql += " AND path LIKE ? || '%'"
                params.append(namespace)

            sql += " ORDER BY rank ASC LIMIT ?"
            params.append(limit * 2)

            rows = conn.execute(sql, params).fetchall()
            conn.close()

            results: List[Dict] = []
            seen_paths: set = set()
            for row in rows:
                path, text, rank = row[0], row[1], row[2]
                created_at = row[3] if len(row) > 3 else None
                updated_at = row[4] if len(row) > 4 else None
                if path in seen_paths:
                    continue
                seen_paths.add(path)

                # BM25 returns negative ranks; convert to positive relevance
                relevance = -rank if rank < 0 else 0.001
                # Dampened score capped at 0.70 so L0 doesn't outrank deeper layers
                score = min(relevance / (1 + relevance) * 0.75, 0.70)

                result_dict = {
                    "path": path,
                    "text": text[:600],
                    "score": round(score, 4),
                    "layer": "L0",
                    "source": "bm25",
                }
                if created_at:
                    result_dict["created_at"] = created_at
                if updated_at:
                    result_dict["updated_at"] = updated_at
                results.append(result_dict)
                if len(results) >= limit:
                    break

            return results

        except Exception as e:
            log.debug(f"L0 BM25 search error: {e}")
            return []

    def _auto_build(self) -> None:
        """Auto-build the FTS5 index from workspace .md files if DB is missing."""
        self._auto_built = True
        ws = self.workspace
        if not ws:
            for candidate in [Path.home() / "rewind", Path.home() / ".openclaw" / "workspace"]:
                if candidate.exists():
                    ws = str(candidate)
                    break
        if not ws or not Path(ws).exists():
            log.debug("L0 auto-build: no workspace found")
            return

        log.info(f"L0 auto-build: indexing .md files from {ws}")
        try:
            db_dir = Path(self.db_path).parent
            db_dir.mkdir(parents=True, exist_ok=True)
            conn = sqlite3.connect(self.db_path)
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute(
                "CREATE TABLE IF NOT EXISTS chunks "
                "(id INTEGER PRIMARY KEY, path TEXT, text TEXT, hash TEXT UNIQUE, "
                "created_at TEXT DEFAULT (datetime('now')), "
                "updated_at TEXT DEFAULT (datetime('now')))"
            )
            # Best-effort add column for pre-existing DBs that lack updated_at
            try:
                conn.execute("ALTER TABLE chunks ADD COLUMN updated_at TEXT")
            except sqlite3.OperationalError:
                pass  # column already exists
            conn.execute(
                "CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts "
                "USING fts5(path, text, content=chunks, content_rowid=id)"
            )
            count = 0
            workspace_path = Path(ws)
            for md_file in workspace_path.rglob("*.md"):
                try:
                    text = md_file.read_text(errors="replace")
                    rel = str(md_file.relative_to(workspace_path))
                    for chunk in [c.strip() for c in text.split("\n\n") if c.strip() and len(c.strip()) > 20]:
                        h = hashlib.md5((rel + chunk[:200]).encode()).hexdigest()
                        try:
                            conn.execute(
                                "INSERT INTO chunks (path, text, hash) VALUES (?, ?, ?)",
                                (rel, chunk, h),
                            )
                            rid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
                            conn.execute(
                                "INSERT INTO chunks_fts (rowid, path, text) VALUES (?, ?, ?)",
                                (rid, rel, chunk),
                            )
                            count += 1
                        except sqlite3.IntegrityError:
                            pass
                except Exception:
                    pass
            conn.commit()
            conn.close()
            log.info(f"L0 auto-build: indexed {count} chunks")
        except Exception as e:
            log.debug(f"L0 auto-build failed: {e}")
