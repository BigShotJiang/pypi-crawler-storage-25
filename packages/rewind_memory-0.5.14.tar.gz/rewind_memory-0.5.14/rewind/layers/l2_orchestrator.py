"""L2 Orchestrator — HybridRAG fusion across all memory layers.

Bio-inspired analogy: **Prefrontal cortex** (executive function).
Coordinates parallel retrieval from L0, L1, L3, L4, extracts entities from
the query, fuses results with adaptive scoring based on query intent,
deduplicates by content, and returns a unified ranked result set.
The orchestrator doesn't store data itself — it orchestrates and
integrates, exactly like the prefrontal cortex coordinates information
from specialised brain regions.
"""

import concurrent.futures
import logging
import re
import time
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)

# Scoring constants
GRAPH_PRIORITY_BOOST = 0.5
VECTOR_BASE_WEIGHT = 0.5


def extract_query_entities(query: str) -> List[str]:
    """Extract potential entities (proper nouns) from a query string.

    Looks for capitalised words and multi-word title-case phrases,
    filtering common stop words. Used to prime L3 graph search.
    """
    words = [re.sub(r"[^\w\s-]", "", w).strip() for w in query.split()]
    words = [w for w in words if w]
    stop_words = {
        "what", "who", "where", "when", "how", "does", "did",
        "the", "and", "for", "with", "from", "about", "this", "that",
    }

    potential_entities: List[str] = []

    # Single capitalised words (proper nouns)
    for word in words:
        if word.istitle() and len(word) > 2 and word.lower() not in stop_words:
            potential_entities.append(word)

    # Multi-word title-case phrases
    for i in range(len(words) - 1):
        if (
            words[i].istitle()
            and words[i + 1].istitle()
            and words[i].lower() not in stop_words
        ):
            potential_entities.append(f"{words[i]} {words[i + 1]}")

    log.info(f"Extracted entities: {potential_entities}")
    return potential_entities



class L2Orchestrator:
    """HybridRAG orchestrator — parallel multi-layer search with adaptive fusion.

    Runs L0, L1, L3, L4 in parallel via ThreadPoolExecutor, then fuses results:
    1. Deduplicates by ``text[:200]``
    2. Applies adaptive scoring boosts based on query intent (conversational,
       email, knowledge signals)
    3. Sorts by final score descending
    """

    def __init__(self, config: Any, layers: Dict[str, Any]) -> None:
        """Initialise orchestrator.

        Args:
            config: Configuration object/dict. Expected keys (all optional):
                - ``enable_l0`` (bool, default True)
                - ``enable_l1`` (bool, default True)
                - ``enable_l3`` (bool, default True)
                - ``enable_l4`` (bool, default True)

            layers: Dict mapping layer names to initialised layer instances.
                Expected keys: ``"l0"``, ``"l1"``, ``"l3"``, ``"l4"``.
        """
        self.config = config if isinstance(config, dict) else {}
        self.layers = layers

    def _is_enabled(self, layer_key: str) -> bool:
        return self.config.get(f"enable_{layer_key}", True)


    def search(
        self,
        query: str,
        limit: int = 16,
        namespace: Optional[str] = None,
        skip_l4: bool = False,
    ) -> List[Dict]:
        """Run full HybridRAG search across all enabled layers.

        Args:
            query: Natural-language query string.
            limit: Maximum results to return after fusion.
            namespace: If set, scope L0/L1/L4 results to paths with this prefix.
            skip_l4: If True, skip L4 vector search (useful when the caller
                already performs its own vector search).

        Returns:
            Fused, deduplicated, scored list of result dicts.
        """
        start_time = time.time()
        ns_label = f" [ns={namespace}]" if namespace else ""
        log.info(f"Starting parallel HybridRAG search{ns_label} for: '{query}'")

        # Extract entities for L3
        entities = extract_query_entities(query)

        # -- Parallel group: L0, L1, L3 --
        l0_results: List[Dict] = []
        l1_results: List[Dict] = []
        l3_entities: List[str] = []
        graph_context: Dict = {"results": [], "graph_entities": [], "entity_count": 0}

        def _run_l0():
            if self._is_enabled("l0") and "l0" in self.layers:
                return self.layers["l0"].search(query, limit=6, namespace=namespace)
            return []

        def _run_l1():
            if self._is_enabled("l1") and "l1" in self.layers:
                return self.layers["l1"].search(query, limit=4, namespace=namespace)
            return []

        def _run_l3():
            if self._is_enabled("l3") and "l3" in self.layers:
                return self.layers["l3"].search(query, entities, limit=8)
            return {"results": [], "graph_entities": [], "entity_count": 0}

        def _safe_result(future, name, default=None):
            """Safely collect a future result — never let one layer kill the pipeline."""
            if default is None:
                default = []
            try:
                return future.result(timeout=20)
            except Exception as exc:
                log.warning(f"{name} failed (graceful degradation): {exc}")
                return default

        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            f_l0 = pool.submit(_run_l0)
            f_l1 = pool.submit(_run_l1)
            f_l3 = pool.submit(_run_l3)

            l0_results = _safe_result(f_l0, "L0")
            l1_results = _safe_result(f_l1, "L1")
            graph_context = _safe_result(f_l3, "L3", default={"results": [], "graph_entities": [], "entity_count": 0})

        parallel_ms = (time.time() - start_time) * 1000
        log.info(
            f"L0={len(l0_results)} L1={len(l1_results)} "
            f"L3={len(graph_context['results'])} (parallel done in {parallel_ms:.0f}ms)"
        )

        # -- Sequential: L4 needs L3 graph context --
        l4_results: List[Dict] = []
        if skip_l4:
            log.info("L4 Vector search: SKIPPED (skip_l4=True)")
        elif self._is_enabled("l4") and "l4" in self.layers:
            try:
                l4_results = self.layers["l4"].search(
                    query, graph_context=graph_context, limit=8, namespace=namespace
                )
                log.info(f"L4 Vector search: {len(l4_results)} results")
            except Exception as exc:
                log.warning(f"L4 failed (graceful degradation): {exc}")
                l4_results = []

        # -- L2 Fusion --
        graph_results = graph_context["results"]
        if namespace:
            graph_results = [
                r for r in graph_results
                if r.get("path", "").startswith(namespace)
            ]

        all_results = (
            l0_results + l1_results + graph_results
            + l4_results
        )

        # Dedup by text[:200]
        seen_texts: set = set()
        deduplicated: List[Dict] = []
        for result in all_results:
            text_key = result.get("text", "")[:200]
            if text_key not in seen_texts:
                deduplicated.append(result)
                seen_texts.add(text_key)

        # -- Unified Multi-Signal Scoring --
        # 4 signals: relevance + adaptive recency + frequency + graph proximity
        # Weights configurable via RewindConfig.scoring (default 0.45/0.25/0.15/0.15)
        import math
        from datetime import datetime as _dt

        q_lower = query.lower()
        query_ents = extract_query_entities(query)
        max_ac = max((r.get("access_count", 0) for r in deduplicated), default=1) or 1


        # Adaptive query-aware weights
        # Simple factual queries → relevance-dominant (0.70)
        # Relationship/multi-hop → balanced (0.40) with stronger graph signal
        # Temporal queries → recency-boosted (0.35)
        _is_simple = not any(
            s in q_lower
            for s in [
                "who", "what relationship", "connected to", "work with",
                "how many", "between", "together", "related",
                "all the", "list of", "compare", "difference",
            ]
        )
        _is_temporal = any(
            s in q_lower
            for s in [
                "when", "first", "last", "before", "after", "recent",
                "latest", "earliest", "updated", "changed", "current",
                "new", "old", "originally", "previously",
            ]
        )
        if _is_temporal:
            w_rel, w_rec, w_freq, w_graph = 0.40, 0.35, 0.10, 0.15
        elif _is_simple:
            w_rel, w_rec, w_freq, w_graph = 0.70, 0.12, 0.08, 0.10
        else:
            w_rel, w_rec, w_freq, w_graph = 0.40, 0.20, 0.15, 0.25

        for r in deduplicated:
            # Signal 1: Relevance (use existing layer score as-is)
            relevance = r.get("score", 0.0)

            # Signal 2: Adaptive recency — half-life decay (30-day half-life)
            recency = 0.5  # default for chunks without timestamps
            created = r.get("created_at")
            if created:
                try:
                    age_h = max((_dt.now() - _dt.fromisoformat(str(created).split(".")[0])).total_seconds() / 3600, 0.1)
                    recency = math.exp(-0.693 * age_h / 720)  # ln(2) / 720h half-life
                except (ValueError, TypeError):
                    pass

            # Signal 3: Frequency — Hebbian chunk strengthening
            frequency = 0.0
            ac = r.get("access_count", 0)
            if ac and max_ac > 0:
                frequency = math.log(ac + 1) / math.log(max_ac + 2)

            # Signal 4: Graph proximity — entity overlap
            graph_prox = 0.0
            if query_ents:
                text_lower = r.get("text", "").lower()
                hits = sum(1 for e in query_ents if e.lower() in text_lower)
                graph_prox = min(hits / max(len(query_ents), 1), 1.0)

            r["score"] = (
                w_rel * relevance
                + w_rec * recency
                + w_freq * frequency
                + w_graph * graph_prox
            )


        deduplicated.sort(key=lambda x: x["score"], reverse=True)



        # Post-fusion intelligence: type classification, recency, drift detection
        try:
            from rewind.intelligence import post_fusion_enhance
            deduplicated = post_fusion_enhance(query, deduplicated, limit=limit)
        except Exception as e:
            log.debug(f"Post-fusion intelligence skipped: {e}")
            deduplicated = deduplicated[:limit]

        search_time_ms = (time.time() - start_time) * 1000
        log.info(
            f"L2 HybridRAG final: {len(deduplicated)} deduped "
            f"(L0={len(l0_results)}, L1={len(l1_results)}, "
            f"L3={len(graph_context['results'])}, L4={len(l4_results)}) "
            f"[{search_time_ms:.0f}ms]"
        )

        return deduplicated
