"""
Post-compaction session continuity.

Zero LLM tokens — pure regex/heuristic extraction of location, timezone,
and active topics from the recent transcript.
"""

import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Optional


class SessionContinuity:
    """Extract and persist session context for post-compaction recovery."""

    # Timezone map — exact from post-compaction-context.py
    TZ_MAP: Dict[str, str] = {
        "San Francisco": "America/Los_Angeles (PST, UTC-8)",
        "SF": "America/Los_Angeles (PST, UTC-8)",
        "LA": "America/Los_Angeles (PST, UTC-8)",
        "New York": "America/New_York (EST, UTC-5)",
        "NYC": "America/New_York (EST, UTC-5)",
        "London": "Europe/London (GMT, UTC+0)",
        "Berlin": "Europe/Berlin (CET, UTC+1)",
        "Hamburg": "Europe/Berlin (CET, UTC+1)",
        "Frankfurt": "Europe/Berlin (CET, UTC+1)",
        "Munich": "Europe/Berlin (CET, UTC+1)",
        "Paris": "Europe/Paris (CET, UTC+1)",
        "Amsterdam": "Europe/Amsterdam (CET, UTC+1)",
        "Brighton": "Europe/London (GMT, UTC+0)",
        "Dubai": "Asia/Dubai (GST, UTC+4)",
        "Edinburgh": "Europe/London (GMT, UTC+0)",
        "Manchester": "Europe/London (GMT, UTC+0)",
        "Bristol": "Europe/London (GMT, UTC+0)",
        "Cambridge": "Europe/London (GMT, UTC+0)",
        "Oxford": "Europe/London (GMT, UTC+0)",
        "Dublin": "Europe/Dublin (IST, UTC+1)",
        "Glasgow": "Europe/London (GMT, UTC+0)",
        "Leeds": "Europe/London (GMT, UTC+0)",
        "Liverpool": "Europe/London (GMT, UTC+0)",
        "Cardiff": "Europe/London (GMT, UTC+0)",
        "Stockholm": "Europe/Stockholm (CET, UTC+1)",
        "Copenhagen": "Europe/Copenhagen (CET, UTC+1)",
        "Oslo": "Europe/Oslo (CET, UTC+1)",
        "Helsinki": "Europe/Helsinki (EET, UTC+2)",
        "Madrid": "Europe/Madrid (CET, UTC+1)",
        "Rome": "Europe/Rome (CET, UTC+1)",
        "Milan": "Europe/Rome (CET, UTC+1)",
        "Vienna": "Europe/Vienna (CET, UTC+1)",
        "Prague": "Europe/Prague (CET, UTC+1)",
        "Warsaw": "Europe/Warsaw (CET, UTC+1)",
        "Athens": "Europe/Athens (EET, UTC+2)",
        "Istanbul": "Europe/Istanbul (TRT, UTC+3)",
        "Mumbai": "Asia/Kolkata (IST, UTC+5:30)",
        "Bangalore": "Asia/Kolkata (IST, UTC+5:30)",
        "Delhi": "Asia/Kolkata (IST, UTC+5:30)",
        "Seoul": "Asia/Seoul (KST, UTC+9)",
        "Shanghai": "Asia/Shanghai (CST, UTC+8)",
        "Beijing": "Asia/Shanghai (CST, UTC+8)",
        "Sydney": "Australia/Sydney (AEDT, UTC+11)",
        "Melbourne": "Australia/Melbourne (AEDT, UTC+11)",
        "Toronto": "America/Toronto (EST, UTC-5)",
        "Vancouver": "America/Vancouver (PST, UTC-8)",
        "Denver": "America/Denver (MST, UTC-7)",
        "Phoenix": "America/Phoenix (MST, UTC-7)",
        "Atlanta": "America/New_York (EST, UTC-5)",
        "San Diego": "America/Los_Angeles (PST, UTC-8)",
        "Mexico City": "America/Mexico_City (CST, UTC-6)",
        "Tokyo": "Asia/Tokyo (JST, UTC+9)",
        "Singapore": "Asia/Singapore (SGT, UTC+8)",
        "Hong Kong": "Asia/Hong_Kong (HKT, UTC+8)",
        "Austin": "America/Chicago (CST, UTC-6)",
        "Chicago": "America/Chicago (CST, UTC-6)",
        "Seattle": "America/Los_Angeles (PST, UTC-8)",
        "Boston": "America/New_York (EST, UTC-5)",
        "Miami": "America/New_York (EST, UTC-5)",
        "Kyiv": "Europe/Kiev (EET, UTC+2)",
        "Kiev": "Europe/Kiev (EET, UTC+2)",
        "Lisbon": "Europe/Lisbon (WET, UTC+0)",
        "Barcelona": "Europe/Madrid (CET, UTC+1)",
        "Geneva": "Europe/Zurich (CET, UTC+1)",
        "Zurich": "Europe/Zurich (CET, UTC+1)",
    }

    # All known city names for pattern matching
    _CITIES = "|".join(TZ_MAP.keys())

    def __init__(self, workspace_path: str) -> None:
        self.workspace = Path(workspace_path)
        self.transcript_path = self.workspace / "chats" / "transcript" / "last-reload.txt"
        self.output_path = self.workspace / "SESSION-CONTEXT.md"
        self.session_state_path = self.workspace / "SESSION-STATE.md"

    def extract_context(self, transcript_path: Optional[str] = None) -> Dict:
        """Extract location, timezone, and key topics from transcript.

        Args:
            transcript_path: Override path to the transcript file.

        Returns:
            Context dict with keys ``extracted_at``, ``user_location``,
            ``user_timezone``, ``travel_detected``, ``key_topics``.
        """
        tp = Path(transcript_path) if transcript_path else self.transcript_path
        if not tp.exists():
            return {}

        text = tp.read_text(errors="ignore")
        recent = text[-20000:]

        context: Dict = {
            "extracted_at": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
            "user_location": None,
            "user_timezone": None,
            "travel_detected": False,
            "key_topics": [],
        }

        cities = self._CITIES

        # --- Location extraction ---
        location_patterns = [
            rf"(?:I'?m|I am)\s+in\s+({cities})",
            rf"here\s+in\s+({cities})",
            r"it'?s\s+\d{1,2}[:.]\d{2}\s*(?:pm|am)\s+(?:here|in\s+(\w+))",
            r"I'?m\s+in\s+(\w[\w\s]*?)(?:!|,|\.|$)",
        ]

        for pattern in location_patterns:
            matches = re.findall(pattern, recent, re.IGNORECASE)
            if matches:
                loc = matches[-1].strip() if isinstance(matches[-1], str) else matches[-1]
                if loc and len(loc) > 1:
                    context["user_location"] = loc
                    context["travel_detected"] = True
                    break

        # --- Indirect location signals ---
        if not context["user_location"]:
            indirect_patterns = [
                rf"Airbnb.{{0,30}}({cities})",
                rf"(?:flight|flew|flying)\s+to\s+({cities})",
                rf"(?:hotel|staying)\s+in\s+({cities})",
            ]
            for pattern in indirect_patterns:
                matches = re.findall(pattern, recent, re.IGNORECASE)
                if matches:
                    loc = matches[-1].strip()
                    if loc:
                        context["user_location"] = loc
                        context["travel_detected"] = True
                        break

        # --- Check SESSION-STATE.md ---
        if not context["user_location"] and self.session_state_path.exists():
            state = self.session_state_path.read_text(errors="ignore")
            loc_match = re.search(
                rf"(?:location|travelling|travel).*?({cities})",
                state,
                re.IGNORECASE,
            )
            if loc_match:
                context["user_location"] = loc_match.group(1)
                context["travel_detected"] = True

        # --- Timezone from location ---
        if context["user_location"]:
            context["user_timezone"] = self.TZ_MAP.get(
                context["user_location"], "Unknown"
            )

        # --- Explicit time corrections ---
        time_corrections = re.findall(
            r"it'?s\s+(\d{1,2})[:.:](\d{2})\s*(pm|am)", recent, re.IGNORECASE
        )
        if time_corrections:
            context["user_stated_time"] = (
                f"{time_corrections[-1][0]}:{time_corrections[-1][1]} "
                f"{time_corrections[-1][2]}"
            )

        # --- Key recent topics (generic heuristics, no deployment-specific strings) ---
        # Detect verb + noun patterns that suggest active work threads.
        # Falls back to the most frequently mentioned capitalised phrases
        # if no pattern matches.
        topic_patterns = [
            ("build", r"\b(building|built|builds)\s+(?:the\s+|a\s+)?([a-z][\w-]{2,30})"),
            ("debug", r"\b(debugging|debug|fixing|fixed)\s+(?:the\s+|a\s+)?([a-z][\w-]{2,30})"),
            ("deploy", r"\b(deploying|deployed|deploys)\s+(?:the\s+|a\s+)?([a-z][\w-]{2,30})"),
            ("audit", r"\b(auditing|audited|audit)\s+(?:the\s+|a\s+)?([a-z][\w-]{2,30})"),
            ("investigate", r"\b(investigating|investigate)\s+(?:the\s+|a\s+)?([a-z][\w-]{2,30})"),
        ]
        topics_seen: set = set()
        for verb, pattern in topic_patterns:
            for m in re.findall(pattern, recent, re.IGNORECASE):
                if isinstance(m, tuple) and len(m) >= 2:
                    noun = m[1].lower().strip()
                    if noun and len(noun) > 2 and noun not in topics_seen:
                        topics_seen.add(noun)
                        context["key_topics"].append(f"{verb} {noun}")
                        if len(context["key_topics"]) >= 5:
                            break
            if len(context["key_topics"]) >= 5:
                break

        return context

    def write_context(self, context: Dict, output_path: Optional[str] = None) -> None:
        """Write extracted context to a markdown file.

        Args:
            context: Dict from :meth:`extract_context`.
            output_path: Override output file path.
        """
        if not context:
            return

        out = Path(output_path) if output_path else self.output_path

        lines = [
            "# SESSION-CONTEXT.md",
            f"**Auto-extracted:** {context['extracted_at']}",
            "",
        ]

        if context.get("user_location"):
            lines.append("## ⚠️ User's Current Location")
            lines.append(f"- **Location:** {context['user_location']}")
            if context.get("user_timezone"):
                lines.append(f"- **Timezone:** {context['user_timezone']}")
            if context.get("user_stated_time"):
                lines.append(f"- **Last stated time:** {context['user_stated_time']}")
            lines.append(
                f"- **Travel detected:** {'Yes' if context['travel_detected'] else 'No'}"
            )
            lines.append("")
            lines.append(
                "**Use the detected timezone above for the user's local time.**"
            )
            lines.append("")

        if context.get("key_topics"):
            lines.append("## Recent Topics")
            for topic in context["key_topics"]:
                lines.append(f"- {topic}")
            lines.append("")

        lines.append("---")
        lines.append(
            "*Auto-generated by rewind session continuity. Do not edit manually.*"
        )

        out.write_text("\n".join(lines))
