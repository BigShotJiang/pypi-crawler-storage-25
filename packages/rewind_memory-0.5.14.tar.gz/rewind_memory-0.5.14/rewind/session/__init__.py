"""Session-level continuity (Free tier).

Pro tier adds HybridRAG-anchored recall, token-budget-aware context
assembly, and cross-encoder reranking. See ``rewind-memory-pro``.
"""

from .continuity import SessionContinuity
from .rewind_session import (
    RewindSession,
    FlushResult,
    ResumeBlock,
    DetectResult,
)

__all__ = [
    "SessionContinuity",
    "RewindSession",
    "FlushResult",
    "ResumeBlock",
    "DetectResult",
]
