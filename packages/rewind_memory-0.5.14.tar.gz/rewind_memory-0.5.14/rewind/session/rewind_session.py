"""rewind-session (Free tier) — compaction-safe session continuity.

Three primitives, usable as library or CLI:

- ``flush()`` — called before context compaction. Extracts durable state
  (location, timezone, active topics) and writes it to ``SESSION-CONTEXT.md``
  plus a ``.rewind-session-flush`` marker.

- ``resume()`` — called at the top of a new session. Returns a markdown
  block the orchestrator can inject at turn 1.

- ``detect()`` — heuristic "am I post-compaction?" check.

The Free tier uses the transcript + SESSION-STATE.md only. Pro adds
HybridRAG-anchored recall (L3 entities + L5 comms + cross-encoder rerank)
for richer context assembly — see ``rewind-memory-pro``.
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from .continuity import SessionContinuity

log = logging.getLogger(__name__)

MARKER_FILENAME = ".rewind-session-flush"


def _marker_path(workspace: Path) -> Path:
    return workspace / MARKER_FILENAME


@dataclass
class FlushResult:
    workspace: str
    context_file: str
    marker_file: str
    topics: List[str] = field(default_factory=list)
    location: Optional[str] = None
    timezone: Optional[str] = None
    flushed_at: str = ""
    bytes_written: int = 0


@dataclass
class ResumeBlock:
    markdown: str
    empty: bool = False
    source_files: List[str] = field(default_factory=list)


@dataclass
class DetectResult:
    post_compaction: bool
    last_flush_age_s: Optional[int] = None
    marker_path: Optional[str] = None
    reason: str = ""


class RewindSession:
    """Compaction-safe session continuity (Free tier).

    Usage::

        from rewind.session import RewindSession
        session = RewindSession(workspace="/path/to/workspace")
        session.flush()             # pre-compaction
        block = session.resume()    # post-compaction
        print(block.markdown)

    CLI::

        rewind session flush
        rewind session resume
        rewind session detect --json
    """

    def __init__(
        self,
        workspace: str,
        continuity: Optional[SessionContinuity] = None,
    ) -> None:
        self.workspace = Path(workspace).expanduser().resolve()
        self.workspace.mkdir(parents=True, exist_ok=True)
        self._continuity = continuity or SessionContinuity(str(self.workspace))
        self._tier = "free"

    # ------------------------------------------------------------------
    # flush()
    # ------------------------------------------------------------------

    def flush(
        self,
        transcript_path: Optional[str] = None,
        daily_note_path: Optional[str] = None,
    ) -> FlushResult:
        ctx = self._continuity.extract_context(transcript_path)
        self._continuity.write_context(ctx)

        flushed_at = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        marker = _marker_path(self.workspace)
        marker_payload = {
            "flushed_at_epoch": int(time.time()),
            "flushed_at_utc": flushed_at,
            "location": ctx.get("user_location"),
            "timezone": ctx.get("user_timezone"),
            "topics": ctx.get("key_topics", []),
            "tier": self._tier,
        }
        marker.write_text(json.dumps(marker_payload, indent=2))

        bytes_written = 0
        daily_path = None
        if daily_note_path:
            daily_path = Path(daily_note_path).expanduser().resolve()
        else:
            memory_dir = self.workspace / "memory"
            if memory_dir.exists() and memory_dir.is_dir():
                daily_path = memory_dir / (
                    datetime.now(timezone.utc).strftime("%Y-%m-%d") + ".md"
                )
        if daily_path is not None:
            try:
                daily_path.parent.mkdir(parents=True, exist_ok=True)
                snippet = self._render_daily_snippet(ctx, flushed_at)
                mode = "a" if daily_path.exists() else "w"
                with open(daily_path, mode) as fh:
                    fh.write(snippet)
                bytes_written = len(snippet.encode("utf-8"))
            except Exception as e:
                log.warning("rewind-session: daily note append failed: %s", e)

        return FlushResult(
            workspace=str(self.workspace),
            context_file=str(self._continuity.output_path),
            marker_file=str(marker),
            topics=ctx.get("key_topics", []),
            location=ctx.get("user_location"),
            timezone=ctx.get("user_timezone"),
            flushed_at=flushed_at,
            bytes_written=bytes_written,
        )

    def _render_daily_snippet(self, ctx: Dict, flushed_at: str) -> str:
        lines = [
            "",
            "",
            f"## {flushed_at} — Pre-compaction flush (rewind-session)",
            "",
        ]
        if ctx.get("user_location"):
            lines.append(f"- **Location:** {ctx['user_location']}")
        if ctx.get("user_timezone"):
            lines.append(f"- **Timezone:** {ctx['user_timezone']}")
        if ctx.get("key_topics"):
            lines.append(f"- **Active topics:** {', '.join(ctx['key_topics'])}")
        lines.append(f"- **Tier:** {self._tier}")
        lines.append("")
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # detect()
    # ------------------------------------------------------------------

    def detect(self, max_age_s: int = 7200) -> DetectResult:
        marker = _marker_path(self.workspace)
        if not marker.exists():
            return DetectResult(
                post_compaction=False,
                last_flush_age_s=None,
                marker_path=str(marker),
                reason="no marker file",
            )
        try:
            payload = json.loads(marker.read_text())
            flushed_epoch = int(payload.get("flushed_at_epoch", 0))
            age = int(time.time()) - flushed_epoch
            if age <= max_age_s:
                return DetectResult(
                    post_compaction=True,
                    last_flush_age_s=age,
                    marker_path=str(marker),
                    reason=f"flush marker {age}s old (<={max_age_s}s)",
                )
            return DetectResult(
                post_compaction=False,
                last_flush_age_s=age,
                marker_path=str(marker),
                reason=f"flush marker stale ({age}s > {max_age_s}s)",
            )
        except Exception as e:
            return DetectResult(
                post_compaction=False,
                last_flush_age_s=None,
                marker_path=str(marker),
                reason=f"marker unreadable: {e}",
            )

    # ------------------------------------------------------------------
    # resume()
    # ------------------------------------------------------------------

    def resume(self, token_budget: int = 1500) -> ResumeBlock:
        char_budget = token_budget * 4
        marker = _marker_path(self.workspace)

        sections: List[str] = []
        source_files: List[str] = []

        ctx: Dict[str, Any] = {}
        if marker.exists():
            try:
                ctx = json.loads(marker.read_text())
                source_files.append(str(marker))
            except Exception:
                ctx = {}

        sc_path = self.workspace / "SESSION-CONTEXT.md"
        if sc_path.exists():
            source_files.append(str(sc_path))

        ss_path = self.workspace / "SESSION-STATE.md"
        state_excerpt = ""
        if ss_path.exists():
            source_files.append(str(ss_path))
            try:
                text = ss_path.read_text(errors="ignore")
                idx = text.find("## LIVE")
                if idx == -1:
                    idx = text.find("LIVE")
                if idx != -1:
                    tail = text[idx: idx + 2000]
                    end = tail.find("\n---", 50)
                    if end != -1:
                        tail = tail[:end]
                    state_excerpt = tail.strip()
            except Exception:
                pass

        header = [
            "# Session Resume",
            "",
            f"_Generated by rewind-session ({self._tier} tier)._",
            "",
        ]
        if ctx.get("flushed_at_utc"):
            header.append(f"- **Last flush:** {ctx['flushed_at_utc']}")
        if ctx.get("location"):
            header.append(f"- **User location:** {ctx['location']}")
        if ctx.get("timezone"):
            header.append(f"- **User timezone:** {ctx['timezone']}")
        if ctx.get("topics"):
            header.append(f"- **Active topics:** {', '.join(ctx['topics'])}")
        header.append("")
        sections.append("\n".join(header))

        if state_excerpt:
            sections.append("## Live work (from SESSION-STATE.md)")
            sections.append("")
            sections.append(state_excerpt)
            sections.append("")

        md = "\n".join(sections)
        if len(md) > char_budget:
            md = md[: char_budget - 80] + "\n\n_...truncated at token_budget._\n"

        empty = not any([
            ctx.get("flushed_at_utc"),
            state_excerpt,
            ctx.get("topics"),
        ])
        return ResumeBlock(markdown=md, empty=empty, source_files=source_files)


# ----------------------------------------------------------------------
# CLI entry points
# ----------------------------------------------------------------------

def cli_flush(workspace: str, transcript: Optional[str] = None) -> int:
    session = RewindSession(workspace=workspace)
    result = session.flush(transcript_path=transcript)
    print(json.dumps({
        "flushed_at": result.flushed_at,
        "context_file": result.context_file,
        "marker_file": result.marker_file,
        "location": result.location,
        "timezone": result.timezone,
        "topics": result.topics,
        "daily_bytes": result.bytes_written,
    }, indent=2))
    return 0


def cli_resume(workspace: str, token_budget: int = 1500) -> int:
    session = RewindSession(workspace=workspace)
    block = session.resume(token_budget=token_budget)
    print(block.markdown)
    return 0 if not block.empty else 2


def cli_detect(workspace: str, max_age_s: int = 7200, as_json: bool = False) -> int:
    session = RewindSession(workspace=workspace)
    result = session.detect(max_age_s=max_age_s)
    if as_json:
        print(json.dumps({
            "post_compaction": result.post_compaction,
            "last_flush_age_s": result.last_flush_age_s,
            "marker_path": result.marker_path,
            "reason": result.reason,
        }, indent=2))
    else:
        print(f"post_compaction={result.post_compaction} "
              f"age={result.last_flush_age_s}s "
              f"reason={result.reason!r}")
    return 0 if result.post_compaction else 1
