"""Rewind CLI — memory stack for AI agents.

Usage:
    rewind ingest <path> [--tier free|pro|enterprise] [--db ./data/vector.db]
    rewind search <query> [--tier free|pro|enterprise] [--limit 10]
    rewind health [--tier free|pro|enterprise]
    rewind stats
"""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime
import logging
import os
import sqlite3
import sys
from pathlib import Path


def cmd_remember(args: argparse.Namespace) -> None:
    """Store a freeform text note directly into memory."""
    import tempfile
    import os
    from rewind.config import default_config
    from rewind.ingest import IngestPipeline

    text = args.text
    if not text.strip():
        print("Error: text cannot be empty", file=sys.stderr)
        sys.exit(1)

    cfg = default_config(args.tier)
    if args.db:
        cfg.vector_db_path = args.db

    # Write text to a temp file so the existing ingest pipeline handles it
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".txt", delete=False, prefix="rewind_note_"
    ) as fh:
        fh.write(text)
        tmp_path = fh.name

    try:
        pipeline = IngestPipeline(cfg)
        pipeline.ingest_file(tmp_path, source="note")
        pipeline.close()
    finally:
        os.unlink(tmp_path)

    preview = text[:50]
    suffix = "..." if len(text) > 50 else ""
    print(f'Stored: "{preview}{suffix}"')


def cmd_ingest(args: argparse.Namespace) -> None:
    """Ingest files into the memory stack."""
    from rewind.config import default_config
    from rewind.ingest import IngestPipeline
    from pathlib import Path

    cfg = default_config(args.tier)
    if args.db:
        cfg.vector_db_path = args.db

    pipeline = IngestPipeline(cfg)

    path = Path(args.path)
    if path.is_dir():
        stats = pipeline.ingest_directory(str(path))
    elif path.is_file():
        stats = pipeline.ingest_file(str(path))
    else:
        print(f"Error: {args.path} not found", file=sys.stderr)
        sys.exit(1)

    pipeline.close()

    # Print summary
    print(f"Files:    {stats.get('files', 1)}")
    print(f"Chunks:   {stats.get('chunks', 0)}")
    print(f"Vectors:  {stats.get('vectors', 0)}")
    print(f"Entities: {stats.get('entities', 0)}")
    if "elapsed_seconds" in stats:
        print(f"Time:     {stats['elapsed_seconds']}s")
    if stats.get("errors"):
        print(f"Errors:   {stats['errors']}")


def cmd_search(args: argparse.Namespace) -> None:
    """Search the memory stack."""
    from rewind.client import RewindClient
    from rewind.config import default_config

    cfg = default_config(args.tier)
    if args.db:
        cfg.vector_db_path = args.db

    client = RewindClient(cfg)
    results = client.search(args.query, limit=args.limit)
    client.close()

    if not results:
        print("No results found.")
        return

    if args.json:
        print(json.dumps([{
            "score": r.score, "layer": r.layer,
            "path": r.path, "text": r.text[:200],
        } for r in results], indent=2))
    else:
        for i, r in enumerate(results, 1):
            print(f"\n{'─' * 60}")
            print(f"  #{i}  score={r.score:.3f}  layer={r.layer}")
            if r.path:
                print(f"  path: {r.path}")
            print(f"  {r.text[:200]}")


def cmd_health(args: argparse.Namespace) -> None:
    """Health check."""
    from rewind.client import RewindClient
    from rewind.config import default_config

    cfg = default_config(args.tier)
    if args.db:
        cfg.vector_db_path = args.db

    client = RewindClient(cfg)
    health = client.health()
    client.close()

    print(f"Tier:         {health['tier']}")
    print(f"Orchestrator: {'✅' if health['orchestrator'] else '❌'}")
    print(f"Bio:          {'✅' if health['bio'] else '❌'}")
    print(f"Healthy:      {'✅' if health['healthy'] else '❌'}")
    print()
    for name, status in health.get("layers", {}).items():
        s = status.get("status", "unknown")
        icon = "✅" if s == "ok" else "❌" if s == "error" else "⚠️"
        extra = ""
        if "nodes" in status:
            extra = f" ({status['nodes']} nodes, {status.get('edges', 0)} edges)"
        elif "total_chunks" in status:
            extra = f" ({status['total_chunks']} chunks)"
        elif "backend" in status:
            extra = f" ({status['backend']})"
        print(f"  {icon} {name}: {s}{extra}")


def cmd_doctor(args: argparse.Namespace) -> None:
    """Auto-diagnose and fix common issues with the memory stack."""
    import hashlib
    import sqlite3
    from pathlib import Path

    fixes = []
    warnings = []
    ok = []

    # ── Resolve paths ─────────────────────────────────────────────────────
    db_path = Path(
        args.db
        or os.environ.get("REWIND_MEMORY_DB", "")
        or str(Path.home() / ".rewind" / "memory" / "main.sqlite")
    )
    workspace = Path(
        getattr(args, "workspace", None)
        or os.environ.get("REWIND_WORKSPACE", "")
        or ""
    )
    if not workspace or not workspace.exists():
        for candidate in [Path.home() / "rewind", Path.home() / ".openclaw" / "workspace"]:
            if candidate.exists():
                workspace = candidate
                break

    print("Rewind Doctor")
    print("=" * 50)
    print(f"  L0 DB:     {db_path}")
    print(f"  Workspace: {workspace}")
    print()

    # ── 1. L0 FTS5 index ─────────────────────────────────────────────────
    print("Checking L0 FTS5 index...")
    db_path.parent.mkdir(parents=True, exist_ok=True)
    needs_build = False

    if not db_path.exists():
        needs_build = True
        print("  ⚠️  Database missing — will create")
    else:
        try:
            conn = sqlite3.connect(str(db_path), timeout=2)
            count = conn.execute(
                "SELECT COUNT(*) FROM chunks_fts"
            ).fetchone()[0]
            conn.close()
            if count == 0:
                needs_build = True
                print("  ⚠️  FTS5 table empty — will rebuild")
            else:
                ok.append(f"L0 FTS5: {count} chunks indexed")
                print(f"  ✅ {count} chunks indexed")
        except Exception:
            needs_build = True
            print("  ⚠️  FTS5 table missing or corrupt — will rebuild")

    if needs_build:
        if not workspace or not workspace.exists():
            warnings.append("L0: no workspace found to index")
            print("  ❌ No workspace directory found — cannot build index")
        else:
            print(f"  Building index from {workspace}...")
            conn = sqlite3.connect(str(db_path))
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("""
                CREATE TABLE IF NOT EXISTS chunks (
                    id INTEGER PRIMARY KEY,
                    path TEXT,
                    text TEXT,
                    hash TEXT UNIQUE
                )
            """)
            conn.execute("""
                CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts
                USING fts5(path, text, content=chunks, content_rowid=id)
            """)

            chunk_count = 0
            for md_file in workspace.rglob("*.md"):
                try:
                    text = md_file.read_text(errors="replace")
                    rel = str(md_file.relative_to(workspace))
                    paragraphs = [
                        c.strip() for c in text.split("\n\n")
                        if c.strip() and len(c.strip()) > 20
                    ]
                    for chunk in paragraphs:
                        h = hashlib.md5(
                            (rel + chunk[:200]).encode()
                        ).hexdigest()
                        try:
                            conn.execute(
                                "INSERT INTO chunks (path, text, hash) VALUES (?, ?, ?)",
                                (rel, chunk, h),
                            )
                            rid = conn.execute(
                                "SELECT last_insert_rowid()"
                            ).fetchone()[0]
                            conn.execute(
                                "INSERT INTO chunks_fts (rowid, path, text) VALUES (?, ?, ?)",
                                (rid, rel, chunk),
                            )
                            chunk_count += 1
                        except sqlite3.IntegrityError:
                            pass
                except Exception:
                    pass

            conn.commit()
            conn.close()
            fixes.append(f"L0 FTS5: indexed {chunk_count} chunks")
            print(f"  ✅ Built L0 index: {chunk_count} chunks")

    # ── 2. OpenClaw config validation fix ─────────────────────────────────
    print()
    print("Checking OpenClaw config...")
    oc_config = Path.home() / ".openclaw" / "openclaw.json"

    if not oc_config.exists():
        ok.append("OpenClaw config: not present (skip)")
        print("  ℹ️  No OpenClaw config found — skipping")
    else:
        try:
            raw = oc_config.read_text()
            try:
                data = json.loads(raw)
            except json.JSONDecodeError:
                try:
                    import json5  # type: ignore
                    data = json5.loads(raw)
                except (ImportError, Exception):
                    warnings.append("OpenClaw config: not valid JSON (json5 not installed)")
                    print("  ⚠️  Config is not valid JSON and json5 is not installed — skipping")
                    data = None

            if data is not None:
                # Strip keys that OpenClaw's validator rejects
                strip_rules = {
                    ("channels", "bluebubbles"): ["enrichGroupParticipantsFromContacts"],
                }
                dirty = False
                for path_keys, bad_keys in strip_rules.items():
                    obj = data
                    for p in path_keys:
                        obj = obj.get(p, {}) if isinstance(obj, dict) else {}
                    for k in bad_keys:
                        if isinstance(obj, dict) and k in obj:
                            del obj[k]
                            dirty = True
                            fixes.append(f"OpenClaw config: stripped {'.'.join(path_keys)}.{k}")
                            print(f"  🔧 Stripped invalid key: {'.'.join(path_keys)}.{k}")

                if dirty:
                    oc_config.write_text(json.dumps(data, indent=2))
                    print("  ✅ Config fixed and saved")
                else:
                    ok.append("OpenClaw config: clean")
                    print("  ✅ Config is clean — no invalid keys found")
        except Exception as e:
            warnings.append(f"OpenClaw config: error — {e}")
            print(f"  ❌ Error checking config: {e}")

    # ── 3. OpenClaw pre-turn hook ───────────────────────────────────
    print()
    print("Checking OpenClaw pre-turn hook...")
    hook_ts = workspace / "hooks" / "pre-turn-memory" / "handler.ts" if workspace else None
    if hook_ts and hook_ts.exists():
        ok.append("Pre-turn hook: installed")
        print("  \u2705 Pre-turn hook: OK")
    else:
        warnings.append("Pre-turn hook not installed")
        print("  \u26a0\ufe0f  Pre-turn hook not installed")
        print("     Fix: rewind-ocplatform hook")

    # ── 4. Health check ───────────────────────────────────────────────────
    print()
    print("Running health check...")
    try:
        from rewind.client import RewindClient
        from rewind.config import default_config

        cfg = default_config(args.tier)
        if args.db:
            cfg.vector_db_path = args.db

        client = RewindClient(cfg)
        health = client.health()
        client.close()

        for name, status in health.get("layers", {}).items():
            s = status.get("status", "unknown")
            icon = "✅" if s == "ok" else "❌" if s == "error" else "⚠️"
            extra = ""
            if "nodes" in status:
                extra = f" ({status['nodes']} nodes)"
            elif "total_chunks" in status:
                extra = f" ({status['total_chunks']} chunks)"
            print(f"  {icon} {name}: {s}{extra}")
            if s == "ok":
                ok.append(f"{name}: {s}{extra}")
            else:
                warnings.append(f"{name}: {s}")
    except Exception as e:
        warnings.append(f"Health check failed: {e}")
        print(f"  ⚠️  Health check failed: {e}")

    # ── 4. Config Discovery ──────────────────────────────────────────────
    print()
    print("Checking config discovery...")
    try:
        from rewind.config import _CONFIG_SEARCH_PATHS, load_config
        found_yaml = None
        env_cfg = os.environ.get("REWIND_CONFIG")
        if env_cfg and Path(env_cfg).expanduser().exists():
            found_yaml = env_cfg
        else:
            for cp in _CONFIG_SEARCH_PATHS:
                if Path(cp).expanduser().exists():
                    found_yaml = cp
                    break
        if found_yaml:
            ok.append(f"Config: loaded from {found_yaml}")
            print(f"  ✅ Config loaded from {found_yaml}")
        else:
            warnings.append("Config: no YAML found, using hardcoded defaults")
            print("  ⚠️  No config.yaml found — using hardcoded defaults")
            print("     Create ~/.rewind/config.yaml to customise settings")
    except Exception as e:
        warnings.append(f"Config discovery error: {e}")
        print(f"  ❌ Config discovery error: {e}")

    # ── 5. Embedding Health ──────────────────────────────────────────────
    print()
    print("Checking embedding endpoint...")
    try:
        from rewind.config import default_config as _dc
        _cfg = _dc(args.tier)
        embed_url = _cfg.embedding.url
        embed_dim = _cfg.embedding.dimension
        print(f"  Provider: {_cfg.embedding.provider}, URL: {embed_url}, Dim: {embed_dim}")
        
        if embed_url == "modal":
            # Modal cloud endpoint — test with actual API format
            modal_url = _cfg.modal.embed_url
            if not modal_url:
                warnings.append("Modal: no embed_url configured")
                print("  ⚠️  No Modal embed_url — set modal.embed_url in config or REWIND_EMBED_URL env")
                modal_url = ""
            auth = _cfg.modal.resolve_auth()
            if not auth:
                warnings.append("Modal: no auth token")
                print("  \u26a0\ufe0f  No Modal auth token \u2014 set modal.auth_token in config or REWIND_MODAL_TOKEN env")
            else:
                try:
                    import httpx
                    r = httpx.post(modal_url, json={"auth_token": auth, "texts": ["test"]}, timeout=120)
                    if r.status_code == 200:
                        dims = len(r.json().get("embeddings", [[]])[0])
                        ok.append(f"Modal embedding: {dims}-dim NV-Embed-v2")
                        print(f"  \u2705 Modal embedding: {dims}-dim NV-Embed-v2")
                    elif r.status_code == 401:
                        warnings.append("Modal: auth failed")
                        print("  \u274c Modal auth failed \u2014 check your API key")
                    else:
                        warnings.append(f"Modal: HTTP {r.status_code}")
                        print(f"  \u274c Modal embedding: HTTP {r.status_code}")
                except Exception as e:
                    warnings.append(f"Modal: {e}")
                    print(f"  \u274c Modal embedding: {e}")
        elif embed_url:
            import httpx
            try:
                health_url = f"{embed_url.rstrip('/')}/health"
                r = httpx.get(health_url, timeout=5)
                if r.status_code == 200:
                    ok.append(f"Embedding: {_cfg.embedding.provider} on {embed_url} healthy")
                    print(f"  ✅ Embedding endpoint healthy")
                else:
                    warnings.append(f"Embedding: {embed_url} returned {r.status_code}")
                    print(f"  ⚠️  Embedding endpoint returned {r.status_code}")
            except Exception:
                # Try the embeddings endpoint directly
                try:
                    r = httpx.post(f"{embed_url.rstrip('/')}/v1/embeddings",
                                   json={"input": "test", "model": _cfg.embedding.model}, timeout=10)
                    if r.status_code == 200:
                        actual_dim = len(r.json().get("data", [{}])[0].get("embedding", []))
                        if actual_dim == embed_dim:
                            ok.append(f"Embedding: {actual_dim}-dim OK")
                            print(f"  ✅ Embedding works, {actual_dim}-dim (matches config)")
                        elif actual_dim > 0:
                            warnings.append(f"Embedding: config says {embed_dim}-dim but got {actual_dim}-dim")
                            print(f"  ⚠️  Dimension mismatch! Config: {embed_dim}, actual: {actual_dim}")
                        else:
                            ok.append("Embedding: endpoint responds")
                            print(f"  ✅ Embedding endpoint responds")
                    else:
                        warnings.append(f"Embedding: endpoint error {r.status_code}")
                        print(f"  ❌ Embedding endpoint error: {r.status_code}")
                except Exception as e2:
                    warnings.append(f"Embedding: {embed_url} unreachable — {e2}")
                    print(f"  ❌ Embedding unreachable: {embed_url}")
                    print(f"     Fix: check if embedding service is running on that port")
        elif embed_url == "modal":
            ok.append("Embedding: Modal cloud (not tested locally)")
            print(f"  ℹ️  Using Modal cloud embeddings — not tested locally")
    except Exception as e:
        warnings.append(f"Embedding check error: {e}")
        print(f"  ❌ Embedding check error: {e}")

    # ── 6. sqlite-vec (vec0) ─────────────────────────────────────────────
    print()
    print("Checking sqlite-vec (L4 vector search)...")
    try:
        try:
            import sqlite_vec
            ok.append("sqlite-vec: installed")
            print(f"  ✅ sqlite-vec package installed")
        except ImportError:
            warnings.append("sqlite-vec: not installed — L4 vector search disabled")
            print(f"  ❌ sqlite-vec not installed")
            print(f"     Fix: pip install sqlite-vec")
        
        if db_path.exists():
            conn = sqlite3.connect(str(db_path), timeout=2)
            tables = [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
            if "chunks_vec" in tables:
                try:
                    row = conn.execute("SELECT COUNT(*) FROM chunks_vec").fetchone()
                    ok.append(f"chunks_vec: {row[0]} vectors")
                    print(f"  ✅ chunks_vec table: {row[0]} vectors")
                    # B4 fix: dim-mismatch silent failure detection.
                    # If L4 was indexed under e.g. 768-d (Ollama) and the current
                    # config is 4096-d, subsequent indexer runs may appear healthy
                    # but drop rows at upsert time. Compare the stored blob length
                    # to the configured embedding dimension.
                    try:
                        from rewind.config import default_config as _dc4
                        expected_dim = _dc4(args.tier).embedding.dimension
                        stored = conn.execute(
                            "SELECT embedding FROM chunks_vec LIMIT 1"
                        ).fetchone()
                        if stored and stored[0] is not None:
                            blob = stored[0]
                            actual_dim = len(blob) // 4 if isinstance(blob, (bytes, bytearray)) else None
                            if actual_dim and actual_dim != expected_dim:
                                warnings.append(
                                    f"L4 dim mismatch: stored={actual_dim} config={expected_dim}"
                                )
                                print(
                                    f"  ❌ L4 dim mismatch: stored={actual_dim}-d config={expected_dim}-d"
                                )
                                print(
                                    f"     Fix: drop chunks_vec and re-ingest, or pin config to stored dim"
                                )
                            elif actual_dim:
                                ok.append(f"L4 dim check: {actual_dim}-d (matches config)")
                                print(f"  ✅ L4 dim: {actual_dim}-d matches config")
                    except Exception:
                        # Best-effort check; do not fail doctor on dim-probe error.
                        pass
                except Exception as e:
                    warnings.append(f"chunks_vec query failed: {e}")
                    print(f"  ⚠️  chunks_vec exists but query failed: {e}")
            else:
                warnings.append("chunks_vec table missing — L4 not indexed")
                print(f"  ⚠️  chunks_vec table missing — run rewind ingest to build vectors")
            conn.close()
    except Exception as e:
        warnings.append(f"vec0 check error: {e}")
        print(f"  ❌ vec0 check error: {e}")

    # ── 7. Neo4j ─────────────────────────────────────────────────────────
    print()
    print("Checking Neo4j (L3 knowledge graph)...")
    try:
        from rewind.config import default_config as _dc2
        _cfg2 = _dc2(args.tier)
        neo_pw = _cfg2.neo4j.resolve_password()
        if neo_pw:
            try:
                from neo4j import GraphDatabase
                driver = GraphDatabase.driver(_cfg2.neo4j.uri, auth=(_cfg2.neo4j.user, neo_pw))
                driver.verify_connectivity()
                with driver.session() as s:
                    count = s.run("MATCH (n) RETURN count(n) as c").single()["c"]
                ok.append(f"Neo4j: connected, {count} nodes")
                print(f"  ✅ Neo4j connected: {count} nodes")
                driver.close()
            except ImportError:
                warnings.append("Neo4j: neo4j package not installed")
                print(f"  ⚠️  neo4j Python package not installed")
                print(f"     Fix: pip install neo4j")
            except Exception as e:
                warnings.append(f"Neo4j: connection failed — {e}")
                print(f"  ❌ Neo4j connection failed: {e}")
                if "authentication" in str(e).lower():
                    print(f"     Fix: check password in config or secrets file")
                else:
                    print(f"     Fix: ensure Neo4j is running on {_cfg2.neo4j.uri}")
        else:
            ok.append("Neo4j: not configured (no password)")
            print(f"  ℹ️  Neo4j not configured (no password set) — using SQLite graph")
    except Exception as e:
        warnings.append(f"Neo4j check error: {e}")
        print(f"  ❌ Neo4j check error: {e}")

    # ── 8. Qdrant ────────────────────────────────────────────────────────
    print()
    print("Checking Qdrant collections...")
    try:
        from rewind.config import default_config as _dc3
        _cfg3 = _dc3(args.tier)
        qdrant_url = _cfg3.qdrant.url
        import httpx
        r = httpx.get(f"{qdrant_url}/collections", timeout=5)
        if r.status_code == 200:
            collections = r.json().get("result", {}).get("collections", [])
            dims = {}
            for col in collections:
                name = col["name"]
                try:
                    info = httpx.get(f"{qdrant_url}/collections/{name}", timeout=5).json()
                    pts = info.get("result", {}).get("points_count", 0)
                    vcfg = info.get("result", {}).get("config", {}).get("params", {}).get("vectors", {})
                    dim = vcfg.get("size", 0) if isinstance(vcfg, dict) else 0
                    dims[name] = dim
                    print(f"  ✅ {name}: {pts} points, {dim}-dim")
                except Exception:
                    print(f"  ⚠️  {name}: couldn't read details")
            
            unique_dims = set(d for d in dims.values() if d > 0)
            if len(unique_dims) > 1:
                warnings.append(f"Qdrant: mixed dimensions {unique_dims} — check embedding consistency")
                print(f"  ⚠️  Mixed dimensions detected: {unique_dims}")
                print(f"     Ensure each collection uses the correct embedding model")
            ok.append(f"Qdrant: {len(collections)} collections")
        else:
            warnings.append(f"Qdrant: returned {r.status_code}")
            print(f"  ❌ Qdrant returned {r.status_code}")
    except httpx.ConnectError:
        warnings.append(f"Qdrant: not reachable on {qdrant_url}")
        print(f"  ⚠️  Qdrant not reachable on {qdrant_url}")
        print(f"     This is OK if you're using Free tier (Qdrant is Pro/Enterprise)")
    except Exception as e:
        warnings.append(f"Qdrant check error: {e}")
        print(f"  ⚠️  Qdrant check: {e}")

    # ── 9. Schema Validation ─────────────────────────────────────────────
    print()
    print("Checking database schema...")
    try:
        if db_path.exists():
            conn = sqlite3.connect(str(db_path), timeout=2)
            cols = [c[1] for c in conn.execute("PRAGMA table_info(chunks)").fetchall()]
            expected = {"id", "path", "text"}
            optional_migrations = {
                "source": "TEXT DEFAULT ''",
                "chunk_index": "INTEGER DEFAULT 0",
                "heading": "TEXT DEFAULT ''",
                "compressed_content": "TEXT DEFAULT ''",
                "valence": "TEXT DEFAULT 'neutral'",
                "quality_score": "REAL DEFAULT 1.0",
                "review_status": "TEXT DEFAULT 'pending'",
            }
            
            missing_required = expected - set(cols)
            if missing_required:
                warnings.append(f"Schema: missing required columns {missing_required}")
                print(f"  ❌ Missing required columns: {missing_required}")
            else:
                print(f"  ✅ Required columns present: {expected}")
            
            auto_fix = getattr(args, 'no_fix', False) is False
            for col_name, col_def in optional_migrations.items():
                if col_name not in cols:
                    if auto_fix:
                        try:
                            conn.execute(f"ALTER TABLE chunks ADD COLUMN {col_name} {col_def}")
                            conn.commit()
                            fixes.append(f"Schema: added column {col_name}")
                            print(f"  🔧 Added missing column: {col_name}")
                        except Exception as e:
                            warnings.append(f"Schema: couldn't add {col_name}: {e}")
                            print(f"  ⚠️  Couldn't add {col_name}: {e}")
                    else:
                        warnings.append(f"Schema: missing optional column {col_name}")
                        print(f"  ⚠️  Missing optional column: {col_name} (run with --fix)")
            
            conn.close()
            ok.append(f"Schema: {len(cols)} columns in chunks table")
    except Exception as e:
        warnings.append(f"Schema check error: {e}")
        print(f"  ❌ Schema check error: {e}")

    # ── 10. Remote Diagnostic Bundle ─────────────────────────────────────
    if getattr(args, 'remote', False):
        print()
        print("Generating diagnostic bundle...")
        try:
            bundle = {
                "timestamp": datetime.now().isoformat(),
                "version": getattr(__import__("rewind"), "__version__", "unknown"),
                "tier": args.tier,
                "ok": ok,
                "warnings": warnings,
                "fixes": fixes,
                "db_path": str(db_path),
                "db_exists": db_path.exists(),
                "db_size_bytes": db_path.stat().st_size if db_path.exists() else 0,
            }
            bundle_path = Path.home() / ".rewind" / f"diagnostic-{datetime.now().strftime('%Y%m%d-%H%M%S')}.json"
            bundle_path.parent.mkdir(parents=True, exist_ok=True)
            bundle_path.write_text(json.dumps(bundle, indent=2, default=str))
            print(f"  ✅ Bundle saved: {bundle_path}")
            print(f"     Send this file to support for remote debugging")
        except Exception as e:
            print(f"  ❌ Bundle generation failed: {e}")

    # ── 11. Summary ────────────────────────────────────────────────────────
    print()
    print("=" * 50)
    print("Summary")
    print("=" * 50)
    if fixes:
        print(f"  🔧 Fixed:    {len(fixes)}")
        for f in fixes:
            print(f"     • {f}")
    if warnings:
        print(f"  ⚠️  Warnings: {len(warnings)}")
        for w in warnings:
            print(f"     • {w}")
    if ok:
        print(f"  ✅ OK:       {len(ok)}")

    if not fixes and not warnings:
        print("  ✅ Everything looks healthy!")


def _extract_channel_meta(obj: dict) -> tuple:
    """Extract channel metadata from a JSONL message object. Returns (channel, sender, chat_id)."""
    import re as _re

    channel = obj.get("channel") or obj.get("provider") or ""
    sender = obj.get("sender") or obj.get("from") or obj.get("author") or ""
    chat_id = obj.get("chat_id") or obj.get("chatId") or obj.get("conversation_id") or ""

    # Parse embedded metadata from OpenClaw message content
    # OCPlatform embeds metadata as JSON blocks inside message.content[0].text
    if not (channel and sender):
        content = obj.get("message", {}).get("content", [])
        text = ""
        if isinstance(content, list) and content:
            text = content[0].get("text", "") if isinstance(content[0], dict) else str(content[0])
        elif isinstance(content, str):
            text = content
        if text:
            match = _re.search(r'Conversation info.*?```json\s*({[^`]+})', text, _re.DOTALL)
            if match:
                try:
                    import json as _json
                    conv_meta = _json.loads(match.group(1))
                    if not sender:
                        sender = conv_meta.get("sender", conv_meta.get("sender_id", ""))
                    if not chat_id:
                        chat_id = conv_meta.get("message_id", conv_meta.get("chat_id", ""))
                    # Detect channel from sender metadata or conversation label
                    if not channel:
                        conv_label = str(conv_meta.get("conversation_label", "")).lower()
                        sender_id = str(conv_meta.get("sender_id", "")).lower()
                        for known in ("telegram", "whatsapp", "slack", "discord", "imessage"):
                            if known in conv_label or known in sender_id:
                                channel = known
                                break
                except (ValueError, KeyError):
                    pass

    # Normalise channel name
    if channel:
        channel = str(channel).lower()
        for known in ("telegram", "whatsapp", "slack", "discord", "imessage"):
            if known in channel:
                channel = known
                break
    return str(channel), str(sender), str(chat_id)


def cmd_ingest_chats(args: argparse.Namespace) -> None:
    """One-time backfill: scan all OpenClaw session JSONL files and index into L0."""
    import hashlib
    import json
    import os
    import sqlite3
    from pathlib import Path

    rewind_dir = Path.home() / ".rewind"
    rewind_dir.mkdir(parents=True, exist_ok=True)

    db_path = Path(
        args.db
        or os.environ.get("REWIND_MEMORY_DB", "")
        or str(rewind_dir / "memory" / "main.sqlite")
    )
    db_path.parent.mkdir(parents=True, exist_ok=True)

    qdrant_url = getattr(args, "qdrant_url", "http://localhost:6333")
    embed_url = getattr(args, "embed_url", "http://localhost:8041/v1/embeddings")
    ollama_url = getattr(args, "ollama_url", None)

    # ── Session directory detection ────────────────────────────────────────
    if args.session_dir:
        jsonl_files = sorted(Path(args.session_dir).glob("*.jsonl"))
    else:
        agents_root = Path.home() / ".openclaw" / "agents"
        jsonl_files = sorted(agents_root.glob("*/sessions/*.jsonl")) if agents_root.exists() else []

    jsonl_files = [f for f in jsonl_files if ".lock" not in f.name and ".deleted" not in f.name]

    if not jsonl_files:
        print("No OpenClaw session JSONL files found.")
        return

    # ── L3 graph setup (Pro) ───────────────────────────────────────────────
    from rewind.ingest import extract_entities, extract_entities_ollama
    from rewind.layers.l3_graph_sqlite import L3GraphSQLite

    graph: L3GraphSQLite | None = None
    try:
        graph_db_path = str(db_path.parent / "graph.db")
        graph = L3GraphSQLite(graph_db_path)
        graph.warmup()
        print("[ingest-chats] L3 KG entity extraction enabled")
    except Exception as _ge:
        print(f"[ingest-chats] L3 graph init failed ({_ge}), continuing without KG")
        graph = None

    # ── DB setup ───────────────────────────────────────────────────────────
    conn = sqlite3.connect(str(db_path), timeout=10)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("""
        CREATE TABLE IF NOT EXISTS chunks (
            id INTEGER PRIMARY KEY,
            path TEXT,
            text TEXT,
            hash TEXT UNIQUE
        )
    """)
    conn.execute("""
        CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts
        USING fts5(path, text, content=chunks, content_rowid=id)
    """)
    # Add channel metadata columns (Pro feature)
    for col_sql in [
        "ALTER TABLE chunks ADD COLUMN channel TEXT",
        "ALTER TABLE chunks ADD COLUMN sender TEXT",
        "ALTER TABLE chunks ADD COLUMN chat_id TEXT",
    ]:
        try:
            conn.execute(col_sql)
        except Exception:
            pass  # column already exists
    conn.commit()


    def index_text(path_label: str, text: str, channel: str = "", sender: str = "", chat_id: str = "") -> tuple:
        """Returns (indexed: bool, hash_str: str)."""
        text = text.strip()
        if not text or len(text) < 10:
            return False, ""
        h = hashlib.md5((path_label + text[:200]).encode()).hexdigest()
        try:
            conn.execute(
                "INSERT INTO chunks (path, text, hash, channel, sender, chat_id) VALUES (?, ?, ?, ?, ?, ?)",
                (path_label, text, h, channel, sender, chat_id),
            )
            rid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
            conn.execute(
                "INSERT INTO chunks_fts (rowid, path, text) VALUES (?, ?, ?)",
                (rid, path_label, text),
            )
            return True, h
        except sqlite3.IntegrityError:
            return False, h

    total_chunks = 0
    total_messages = 0
    files_processed = 0
    total_files = len(jsonl_files)

    for idx, filepath in enumerate(jsonl_files, 1):
        messages = []
        try:
            with open(filepath, "r", errors="replace") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        obj = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    role = obj.get("role", "")
                    if role not in ("user", "assistant"):
                        continue
                    content = obj.get("content", "")
                    if isinstance(content, list):
                        parts = []
                        for block in content:
                            if isinstance(block, dict) and block.get("type") == "text":
                                parts.append(block.get("text", ""))
                            elif isinstance(block, str):
                                parts.append(block)
                        content = " ".join(parts)
                    if not isinstance(content, str):
                        content = str(content)
                    channel, sender, chat_id = _extract_channel_meta(obj)
                    messages.append((role, content, channel, sender, chat_id))
        except Exception as e:
            print(f"  Warning: could not read {filepath.name}: {e}")
            continue

        print(f"Processing file {idx}/{total_files}: {filepath.name} ({len(messages)} messages)")

        agent_name = filepath.parent.parent.name if filepath.parent.name == "sessions" else filepath.parent.name
        file_chunks = 0
        for role, content, channel, sender, chat_id in messages:
            path_label = f"session:{agent_name}/{filepath.stem}:{role}"
            chunk_size = 500
            for i in range(0, max(1, len(content)), chunk_size):
                chunk = content[i:i + chunk_size].strip()
                indexed, h = index_text(path_label, chunk, channel, sender, chat_id)
                if indexed:
                    file_chunks += 1

        # KG entity extraction for this file
        if graph is not None:
            file_entity_count = 0
            for role, content, channel, sender, chat_id in messages:
                if not content.strip():
                    continue
                try:
                    if ollama_url:
                        kg = extract_entities_ollama(content, url=ollama_url)
                        ents = [{"name": n.get("name", ""), "label": n.get("type", "Entity")} for n in kg.get("nodes", [])]
                    else:
                        ents = extract_entities(content)
                    for ent in ents:
                        if ent.get("name"):
                            graph.add_node(ent["name"], ent["label"])
                    file_entity_count += len(ents)
                except Exception:
                    pass
            if file_entity_count:
                print(f"  Extracted {file_entity_count} entities from {filepath.name}")

        total_chunks += file_chunks
        total_messages += len(messages)
        files_processed += 1

    conn.commit()
    conn.close()

    graph_nodes = 0
    if graph is not None:
        try:
            h = graph.health()
            graph_nodes = h.get("nodes", 0)
            graph.close()
        except Exception:
            pass

    print(f"\nIndexed {total_chunks} chunks from {files_processed} files ({total_messages} messages)")
    if graph_nodes:
        print(f"KG entities: {graph_nodes} nodes in L3 graph")


def cmd_serve(args: argparse.Namespace) -> None:
    """Start the API server, optionally with a background file watcher."""
    import signal
    import threading
    from rewind.api.server import create_app

    watcher_state = None

    if not args.no_watch:
        from rewind.watch import start_background_watcher, stop_background_watcher

        workspace = (
            args.workspace
            or os.environ.get("REWIND_WORKSPACE")
            or os.getcwd()
        )
        try:
            watcher_state = start_background_watcher(
                workspace=workspace,
                tier=args.tier,
                db=args.db,
            )
        except FileNotFoundError as e:
            logging.getLogger(__name__).warning(
                "File watcher disabled: %s", e,
            )

    app = create_app(config_path=args.config, tier=args.tier)

    # Graceful shutdown — stop watcher + server
    def _shutdown(signum, frame):
        if watcher_state is not None:
            stop_background_watcher(*watcher_state)
        raise SystemExit(0)

    signal.signal(signal.SIGINT, _shutdown)
    signal.signal(signal.SIGTERM, _shutdown)

    import uvicorn
    try:
        uvicorn.run(app, host=args.host, port=args.port)
    finally:
        if watcher_state is not None:
            from rewind.watch import stop_background_watcher
            stop_background_watcher(*watcher_state)


def cmd_watch(args: argparse.Namespace) -> None:
    """Watch workspace for file changes and auto-ingest."""
    from rewind.watch import main as watch_main
    watch_main(
        workspace=args.workspace,
        tier=args.tier,
        debounce=args.debounce,
        verbose=args.verbose,
        db=args.db,
    )


def cmd_watch_sessions(args: argparse.Namespace) -> None:
    """Watch OpenClaw session files and index conversations in real-time into L0 FTS5."""
    import hashlib
    import json
    import os
    import signal
    import sqlite3
    import sys
    import time
    from pathlib import Path

    try:
        from watchdog.observers import Observer
        from watchdog.events import FileSystemEventHandler
    except ImportError:
        print("Error: watchdog library not installed. Run: pip install 'watchdog>=3.0'", file=sys.stderr)
        sys.exit(1)

    # ── Paths ──────────────────────────────────────────────────────────────
    rewind_dir = Path.home() / ".rewind"
    rewind_dir.mkdir(parents=True, exist_ok=True)

    db_path = Path(
        args.db
        or os.environ.get("REWIND_MEMORY_DB", "")
        or str(rewind_dir / "memory" / "main.sqlite")
    )
    db_path.parent.mkdir(parents=True, exist_ok=True)

    state_file = rewind_dir / "watch-state.json"
    pid_file = rewind_dir / "watch.pid"

    qdrant_url = getattr(args, "qdrant_url", "http://localhost:6333")
    embed_url = getattr(args, "embed_url", "http://localhost:8041/v1/embeddings")
    ollama_url = getattr(args, "ollama_url", None)

    # ── Session directory detection ────────────────────────────────────────
    if args.session_dir:
        session_dirs = [Path(args.session_dir)]
    else:
        agents_root = Path.home() / ".openclaw" / "agents"
        session_dirs = sorted(agents_root.glob("*/sessions")) if agents_root.exists() else []

    if not session_dirs:
        print("No OpenClaw session directories found.", file=sys.stderr)
        sys.exit(1)

    # ── L3 graph setup (Pro) ──────────────────────────────────────────────
    from rewind.ingest import extract_entities, extract_entities_ollama
    from rewind.layers.l3_graph_sqlite import L3GraphSQLite as _L3GraphSQLite

    _graph: _L3GraphSQLite | None = None
    try:
        _graph_db_path = str(db_path.parent / "graph.db")
        _graph = _L3GraphSQLite(_graph_db_path)
        _graph.warmup()
        print("[watch] L3 KG entity extraction enabled")
    except Exception as _ge:
        print(f"[watch] L3 graph init failed ({_ge}), continuing without KG")
        _graph = None

    # ── Daemon mode ────────────────────────────────────────────────────────
    if args.daemon:
        pid = os.fork()
        if pid > 0:
            print(f"Watch daemon started (PID {pid})")
            pid_file.write_text(str(pid))
            sys.exit(0)
        os.setsid()


    # ── DB setup ───────────────────────────────────────────────────────────
    def get_conn():
        conn = sqlite3.connect(str(db_path), timeout=10)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS chunks (
                id INTEGER PRIMARY KEY,
                path TEXT,
                text TEXT,
                hash TEXT UNIQUE
            )
        """)
        conn.execute("""
            CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts
            USING fts5(path, text, content=chunks, content_rowid=id)
        """)
        # Pro: channel metadata columns
        for col_sql in [
            "ALTER TABLE chunks ADD COLUMN channel TEXT",
            "ALTER TABLE chunks ADD COLUMN sender TEXT",
            "ALTER TABLE chunks ADD COLUMN chat_id TEXT",
        ]:
            try:
                conn.execute(col_sql)
            except Exception:
                pass
        conn.commit()
        return conn

    # ── State persistence (file offsets) ──────────────────────────────────
    def load_state():
        if state_file.exists():
            try:
                return json.loads(state_file.read_text())
            except Exception:
                pass
        return {}

    def save_state(state):
        state_file.write_text(json.dumps(state, indent=2))

    # ── Index a chunk of text ──────────────────────────────────────────────
    def index_text(conn, path_label: str, text: str, channel: str = "", sender: str = "", chat_id: str = "") -> tuple:
        """Returns (indexed: bool, hash_str: str)."""
        text = text.strip()
        if not text or len(text) < 10:
            return False, ""
        h = hashlib.md5((path_label + text[:200]).encode()).hexdigest()
        try:
            conn.execute(
                "INSERT INTO chunks (path, text, hash, channel, sender, chat_id) VALUES (?, ?, ?, ?, ?, ?)",
                (path_label, text, h, channel, sender, chat_id),
            )
            rid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
            conn.execute(
                "INSERT INTO chunks_fts (rowid, path, text) VALUES (?, ?, ?)",
                (rid, path_label, text),
            )
            return True, h
        except sqlite3.IntegrityError:
            return False, h

    # ── Process new lines from a JSONL session file ────────────────────────
    def process_file(filepath: Path, state: dict, conn) -> int:
        key = str(filepath)
        offset = state.get(key, 0)
        indexed = 0
        try:
            with open(filepath, "r", errors="replace") as f:
                f.seek(offset)
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        obj = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    role = obj.get("role", "")
                    if role not in ("user", "assistant"):
                        continue
                    content = obj.get("content", "")
                    if isinstance(content, list):
                        parts = []
                        for block in content:
                            if isinstance(block, dict) and block.get("type") == "text":
                                parts.append(block.get("text", ""))
                            elif isinstance(block, str):
                                parts.append(block)
                        content = " ".join(parts)
                    if not isinstance(content, str):
                        content = str(content)

                    channel, sender, chat_id = _extract_channel_meta(obj)
                    path_label = f"session:{filepath.parent.parent.name}/{filepath.stem}:{role}"
                    chunk_size = 500
                    for i in range(0, max(1, len(content)), chunk_size):
                        chunk = content[i:i + chunk_size].strip()
                        ok, h = index_text(conn, path_label, chunk, channel, sender, chat_id)
                        if ok:
                            indexed += 1

                    # KG entity extraction
                    if _graph is not None and content.strip():
                        try:
                            if ollama_url:
                                _kg = extract_entities_ollama(content, url=ollama_url)
                                _ents = [{"name": n.get("name", ""), "label": n.get("type", "Entity")} for n in _kg.get("nodes", [])]
                            else:
                                _ents = extract_entities(content)
                            for _ent in _ents:
                                if _ent.get("name"):
                                    _graph.add_node(_ent["name"], _ent["label"])
                            if _ents:
                                print(f"[watch] Extracted {len(_ents)} entities from message")
                        except Exception:
                            pass

                new_offset = f.tell()
            state[key] = new_offset
        except Exception as e:
            print(f"[watch] Error processing {filepath}: {e}", file=sys.stderr)
        return indexed

    # ── Scan all existing files on startup ────────────────────────────────
    state = load_state()
    conn = get_conn()

    total_startup = 0
    for sdir in session_dirs:
        for jsonl in sdir.glob("*.jsonl"):
            if ".lock" in jsonl.suffixes or ".deleted" in jsonl.name:
                continue
            n = process_file(jsonl, state, conn)
            if n:
                print(f"[watch] Indexed {n} chunks from {jsonl.name}")
                total_startup += n

    conn.commit()
    save_state(state)
    if total_startup:
        print(f"[watch] Startup: indexed {total_startup} new chunks total")

    print(f"[watch] Watching {len(session_dirs)} session dir(s)...")
    for d in session_dirs:
        print(f"  → {d}")

    # ── Watchdog handler ──────────────────────────────────────────────────
    class SessionHandler(FileSystemEventHandler):
        def on_modified(self, event):
            if event.is_directory:
                return
            p = Path(event.src_path)
            if p.suffix != ".jsonl" or ".lock" in p.name or ".deleted" in p.name:
                return
            n = process_file(p, state, conn)
            conn.commit()
            save_state(state)
            if n:
                print(f"[watch] +{n} chunks ← {p.name}")

        def on_created(self, event):
            self.on_modified(event)

    observer = Observer()
    handler = SessionHandler()
    for sdir in session_dirs:
        if sdir.exists():
            observer.schedule(handler, str(sdir), recursive=False)

    observer.start()

    # ── Graceful shutdown ─────────────────────────────────────────────────
    def shutdown(signum, frame):
        print("\n[watch] Shutting down...")
        observer.stop()
        observer.join()
        conn.close()
        if _graph is not None:
            try:
                _graph.close()
            except Exception:
                pass
        save_state(state)
        if pid_file.exists():
            try:
                pid_file.unlink()
            except Exception:
                pass
        sys.exit(0)

    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        shutdown(None, None)


def cmd_migrate(args: argparse.Namespace) -> None:
    """Migrate SQLite backends to Neo4j/Qdrant, or re-index embeddings."""
    from rewind.migrate import Migrator, MODAL_EMBED_URL

    db = args.db or "./data/vector.db"
    migrator = Migrator(sqlite_db=db)

    # ── Re-index embeddings (768 → 4096) ──────────────────────────────────
    if getattr(args, "reindex", False):
        # Resolve Modal auth token: CLI flag → config.yaml → error
        modal_token: str = getattr(args, "modal_token", None) or ""
        if not modal_token:
            # Try to read from config.yaml
            import os as _os
            from pathlib import Path as _Path
            cfg_path = str(_Path(db).parent / "config.yaml")
            if _os.path.exists(cfg_path):
                try:
                    import yaml  # type: ignore
                    with open(cfg_path) as fh:
                        cfg = yaml.safe_load(fh) or {}
                    modal_token = (cfg.get("modal", {}) or {}).get("auth_token", "")
                except Exception:
                    pass

        if not modal_token:
            print(
                "Error: --modal-token is required (or set modal.auth_token in config.yaml)",
                file=sys.stderr,
            )
            sys.exit(1)

        from pathlib import Path as _Path2
        result = migrator.reindex_embeddings(
            modal_token=modal_token,
            modal_url=getattr(args, "modal_url", None) or MODAL_EMBED_URL,
            config_path=str(_Path2(db).parent / "config.yaml"),
        )

        if "error" in result:
            print(f"Error: {result['error']}", file=sys.stderr)
            sys.exit(1)

        print()
        print("── Embedding re-index complete ───────────────────────────")
        print(f"  Chunks re-indexed : {result['chunks_reindexed']}")
        print(f"  Old dimension     : {result['old_dim'] or 'unknown'}")
        print(f"  New dimension     : {result['new_dim']}")
        print(f"  Failures skipped  : {result['failures']}")
        print(f"  Elapsed           : {result['elapsed_seconds']}s")
        return

    # ── Standard subcommands ──────────────────────────────────────────────
    if args.subcmd == "status":
        import json as _json
        print(_json.dumps(migrator.status(), indent=2))
        return

    if args.subcmd == "graph":
        result = migrator.migrate_graph_to_neo4j(
            uri=args.uri or "bolt://localhost:7687",
            user=args.user or "neo4j",
            password=args.password or "",
            dry_run=args.dry_run,
        )
    elif args.subcmd == "vectors":
        result = migrator.migrate_vectors_to_qdrant(
            qdrant_url=args.uri or "http://localhost:6333",
            collection=args.collection or "rewind_chunks",
            dry_run=args.dry_run,
        )
    else:
        print("Usage: rewind migrate {status|graph|vectors} [--reindex]", file=sys.stderr)
        sys.exit(1)

    if "error" in result:
        print(f"Error: {result['error']}", file=sys.stderr)
        sys.exit(1)

    import json
    print(json.dumps(result, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="rewind",
        description="Rewind — bio-inspired memory stack for AI agents",
    )
    parser.add_argument(
        "-v", "--verbose", action="store_true",
        help="Enable debug logging",
    )

    sub = parser.add_subparsers(dest="command")

    # remember
    p_remember = sub.add_parser("remember", help="Store a text note into memory")
    p_remember.add_argument("text", help="Text to store")
    p_remember.add_argument("--tier", default="free", choices=["free", "pro", "enterprise"])
    p_remember.add_argument("--db", default=None, help="Path to vector DB")

    # ingest
    p_ingest = sub.add_parser("ingest", help="Ingest files into memory")
    p_ingest.add_argument("path", help="File or directory to ingest")
    p_ingest.add_argument("--tier", default="free", choices=["free", "pro", "enterprise"])
    p_ingest.add_argument("--db", default=None, help="Path to vector DB")

    # search
    p_search = sub.add_parser("search", help="Search memory")
    p_search.add_argument("query", help="Search query")
    p_search.add_argument("--tier", default="free", choices=["free", "pro", "enterprise"])
    p_search.add_argument("--db", default=None, help="Path to vector DB")
    p_search.add_argument("--limit", type=int, default=10)
    p_search.add_argument("--json", action="store_true", help="Output JSON")

    # health
    p_health = sub.add_parser("health", help="Health check")
    p_health.add_argument("--tier", default="free", choices=["free", "pro", "enterprise"])
    p_health.add_argument("--db", default=None, help="Path to vector DB")

    # migrate
    p_migrate = sub.add_parser("migrate", help="Migrate backends (Pro)")
    p_migrate.add_argument(
        "subcmd", nargs="?", choices=["status", "graph", "vectors"],
        help="Migration target (omit when using --reindex)",
    )
    p_migrate.add_argument("--db", default=None, help="Path to SQLite DB")
    p_migrate.add_argument("--uri", default=None, help="Target URI (bolt:// or http://)")
    p_migrate.add_argument("--user", default="neo4j", help="Neo4j username")
    p_migrate.add_argument("--password", default="", help="Neo4j password")
    p_migrate.add_argument("--collection", default="rewind_chunks", help="Qdrant collection")
    p_migrate.add_argument("--dry-run", action="store_true", help="Report only, don't write")
    # Re-index flags (Pro upgrade: 768-dim → 4096-dim)
    p_migrate.add_argument(
        "--reindex", action="store_true",
        help="Re-embed all chunks with NV-Embed-v2 (768 → 4096 dims, Pro upgrade)",
    )
    p_migrate.add_argument(
        "--modal-token", default=None,
        help="Modal auth token for NV-Embed-v2 endpoint (or set modal.auth_token in config.yaml)",
    )
    p_migrate.add_argument(
        "--modal-url", default=None,
        help="Override the Modal NV-Embed-v2 endpoint URL",
    )

    # ingest-chats
    p_ic = sub.add_parser("ingest-chats", help="Backfill historical OpenClaw conversations into memory")
    p_ic.add_argument("--session-dir", help="Override session directory")
    p_ic.add_argument("--db", default=None, help="Path to L0 SQLite DB")
    p_ic.add_argument("--embed-url", default="http://localhost:8041/v1/embeddings", help="Embedding service URL")
    p_ic.add_argument("--ollama-url", default=None, help="Ollama URL for LLM-based entity extraction (default: heuristic)")

    # watch (workspace file watcher)
    p_watch = sub.add_parser("watch", help="Watch workspace for file changes and auto-ingest")
    p_watch.add_argument("--workspace", default=".", help="Directory to watch (default: current dir)")
    p_watch.add_argument("--tier", default="pro", choices=["free", "pro", "enterprise"])
    p_watch.add_argument("--debounce", type=float, default=2.0, help="Debounce delay in seconds")
    p_watch.add_argument("--verbose", action="store_true", help="Enable debug logging")
    p_watch.add_argument("--db", default=None, help="Path to vector DB")

    # watch-sessions (OpenClaw session watcher — legacy)
    p_ws = sub.add_parser("watch-sessions", help="Watch OCPlatform sessions and index conversations in real-time")
    p_ws.add_argument("--session-dir", help="Override session directory")
    p_ws.add_argument("--daemon", action="store_true", help="Run as background daemon")
    p_ws.add_argument("--db", default=None, help="Path to L0 SQLite DB")
    p_ws.add_argument("--embed-url", default="http://localhost:8041/v1/embeddings", help="Embedding service URL")
    p_ws.add_argument("--ollama-url", default=None, help="Ollama URL for LLM-based entity extraction (default: heuristic)")

    # serve
    p_serve = sub.add_parser("serve", help="Start the API server (with background file watcher)")
    p_serve.add_argument("--config", default=None, help="Config YAML path")
    p_serve.add_argument("--tier", default="free", choices=["free", "pro", "enterprise"])
    p_serve.add_argument("--port", type=int, default=8080, help="API server port")
    p_serve.add_argument("--host", default="127.0.0.1", help="API server host")
    p_serve.add_argument("--db", default=None, help="Path to vector DB")
    p_serve.add_argument("--workspace", default=None, help="Workspace path for file watcher")
    p_serve.add_argument(
        "--no-watch", action="store_true",
        help="Disable the background file watcher",
    )

    # bench
    p_bench = sub.add_parser("bench", help="Run LoCoMo benchmark")
    p_bench.add_argument("--limit", type=int, default=0, help="Limit QA pairs (0=all)")
    p_bench.add_argument("--verbose", action="store_true", help="Show per-question results")
    p_bench.add_argument("--tier", default="free", help="Tier to benchmark")

    # doctor
    p_doctor = sub.add_parser("doctor", help="Auto-diagnose and fix common issues")
    p_doctor.add_argument("--tier", default="free", choices=["free", "pro", "enterprise"])
    p_doctor.add_argument("--db", default=None, help="Path to L0 SQLite DB")
    p_doctor.add_argument("--workspace", default=None, help="Path to workspace directory")
    p_doctor.add_argument("--no-fix", action="store_true", help="Diagnose only, don't auto-repair")
    p_doctor.add_argument("--remote", action="store_true", help="Generate diagnostic bundle for support")
    p_doctor.add_argument("--verbose", action="store_true", help="Show extra detail")

    # ---- session (flush / resume / detect) --------------------------------
    p_session = sub.add_parser(
        "session",
        help="Compaction-safe session continuity (flush/resume/detect)",
    )
    p_session_sub = p_session.add_subparsers(dest="session_cmd", required=True)

    p_flush = p_session_sub.add_parser("flush", help="Pre-compaction: persist durable state")
    p_flush.add_argument("--workspace", default=str(Path.cwd()), help="Workspace directory (default: cwd)")
    p_flush.add_argument("--transcript", default=None, help="Transcript path override")

    p_resume = p_session_sub.add_parser("resume", help="Post-compaction: emit resume markdown")
    p_resume.add_argument("--workspace", default=str(Path.cwd()), help="Workspace directory (default: cwd)")
    p_resume.add_argument("--token-budget", type=int, default=1500, help="Approx token budget for output (default: 1500)")

    p_detect = p_session_sub.add_parser("detect", help="Heuristic post-compaction detection")
    p_detect.add_argument("--workspace", default=str(Path.cwd()), help="Workspace directory (default: cwd)")
    p_detect.add_argument("--max-age", type=int, default=7200, help="Marker max age in seconds (default: 7200)")
    p_detect.add_argument("--json", dest="as_json", action="store_true", help="Emit JSON output")

    args = parser.parse_args()

    if args.verbose:
        logging.basicConfig(level=logging.DEBUG, format="%(levelname)s %(name)s: %(message)s")
    else:
        logging.basicConfig(level=logging.WARNING)

    if args.command == "serve":
        cmd_serve(args)
    elif args.command == "remember":
        cmd_remember(args)
    elif args.command == "ingest":
        cmd_ingest(args)
    elif args.command == "search":
        cmd_search(args)
    elif args.command == "health":
        cmd_health(args)
    elif args.command == "doctor":
        cmd_doctor(args)
    elif args.command == "migrate":
        cmd_migrate(args)
    elif args.command == "ingest-chats":
        cmd_ingest_chats(args)
    elif args.command == "watch":
        cmd_watch(args)
    elif args.command == "watch-sessions":
        cmd_watch_sessions(args)
    elif args.command == "bench":
        from rewind.bench import run_benchmark
        run_benchmark(limit=args.limit, verbose=args.verbose, tier=args.tier)
    elif args.command == "session":
        from rewind.session.rewind_session import cli_flush, cli_resume, cli_detect
        if args.session_cmd == "flush":
            sys.exit(cli_flush(args.workspace, transcript=args.transcript))
        elif args.session_cmd == "resume":
            sys.exit(cli_resume(args.workspace, token_budget=args.token_budget))
        elif args.session_cmd == "detect":
            sys.exit(cli_detect(args.workspace, max_age_s=args.max_age, as_json=args.as_json))
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
