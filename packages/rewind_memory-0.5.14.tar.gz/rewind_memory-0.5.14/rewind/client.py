"""RewindClient — unified interface to the 7-layer memory stack.

Wires real layer implementations (L0–L4 + Bio) based on tier config.
Free tier runs entirely on SQLite — zero external dependencies.
Pro/Enterprise can optionally use Neo4j (L3).
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from rewind.config import RewindConfig, default_config

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Result type
# ---------------------------------------------------------------------------

@dataclass
class Result:
    path: str = ""
    text: str = ""
    score: float = 0.0
    layer: str = ""          # e.g. "L0_fts", "L3_graph"
    source: str = ""         # originating store / index name
    metadata: Dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------

class RewindClient:
    """Unified gateway to the 7-layer memory architecture.

    Usage::

        from rewind.client import RewindClient
        from rewind.config import default_config

        client = RewindClient(default_config("free"))
        results = client.search("what is Hebbian learning")
        for r in results:
            print(f"{r.score:.2f} [{r.layer}] {r.text[:80]}")
    """

    def __init__(
        self,
        config: Optional[RewindConfig] = None,
        embedding_fn: Optional[Callable[[str], List[float]]] = None,
        feedback_dir: Optional[str] = None,
    ) -> None:
        self.config = config or default_config()
        self._embedding_fn = embedding_fn
        self._layers: Dict[str, Any] = {}
        self._orchestrator = None
        self._bio = None
        self._feedback = None
        self._feedback_dir = feedback_dir
        self._initialised = False

    # -- lazy init --------------------------------------------------------

    def _init_layers(self) -> None:
        if self._initialised:
            return

        cfg = self.config
        lf = cfg.layers

        # Resolve paths
        workspace = os.path.expanduser(cfg.workspace_path)
        db_path = os.path.expanduser(cfg.vector_db_path)

        # -- L0: FTS5/BM25 keyword search (always on) --
        if lf.l0_sensory:
            try:
                from rewind.layers.l0_fts import L0FullTextSearch
                self._layers["l0"] = L0FullTextSearch(db_path)
                log.info("L0 (FTS5) initialised: %s", db_path)
            except Exception as exc:
                log.warning("L0 init failed: %s", exc)

        # -- L1: System files (always on) --
        if lf.l1_stm:
            try:
                from rewind.layers.l1_system import L1SystemFiles
                self._layers["l1"] = L1SystemFiles(workspace)
                log.info("L1 (System Files) initialised: %s", workspace)
            except Exception as exc:
                log.warning("L1 init failed: %s", exc)

        # -- L3: Knowledge graph --
        if lf.l3_graph:
            l3 = self._init_l3_graph(cfg)
            if l3:
                self._layers["l3"] = l3

        # -- L4: Vector search (sqlite-vec) --
        if lf.l4_workspace:
            try:
                from rewind.layers.l4_vector import L4Vector
                self._layers["l4"] = L4Vector(
                    db_path=db_path,
                    embedding_fn=self._get_embedding_fn(),
                )
                log.info("L4 (Vector) initialised: %s", db_path)
            except Exception as exc:
                log.warning("L4 init failed: %s", exc)



        # -- Bio layer (MOS/Enterprise only) --
        if lf.bio:
            self._init_bio()

        # -- L2: Orchestrator (always created when any layer is present) --
        if self._layers:
            try:
                from rewind.layers.l2_orchestrator import L2Orchestrator
                orch_config = {
                    f"enable_{k}": True for k in self._layers
                }
                self._orchestrator = L2Orchestrator(orch_config, self._layers)
                log.info("L2 (Orchestrator) initialised with layers: %s",
                         list(self._layers.keys()))
            except Exception as exc:
                log.warning("L2 orchestrator init failed: %s", exc)

        # -- Retrieval feedback (demotions + boosts) --
        self._init_feedback()

        self._initialised = True

    def _init_l3_graph(self, cfg: RewindConfig) -> Any:
        """Initialise L3 graph — tries Neo4j first, falls back to SQLite graph."""
        # Try Neo4j if password is configured
        if cfg.neo4j.password or cfg.neo4j.secrets_file:
            try:
                from rewind.layers.l3_graph import L3Graph
                pwd = cfg.neo4j.resolve_password() or cfg.neo4j.password
                l3 = L3Graph(cfg.neo4j.uri, cfg.neo4j.user, pwd)
                l3.warmup()
                log.info("L3 (Graph/Neo4j) initialised: %s", cfg.neo4j.uri)
                return l3
            except ImportError:
                log.info("neo4j driver not installed — trying SQLite graph")
            except Exception as exc:
                log.warning("L3 Neo4j init failed (%s) — trying SQLite graph", exc)

        # Fall back to SQLite graph (free tier default)
        try:
            from rewind.layers.l3_graph_sqlite import L3GraphSQLite
            db_path = os.path.expanduser(cfg.vector_db_path)
            graph_db = str(Path(db_path).parent / "graph.db")
            l3 = L3GraphSQLite(graph_db)
            log.info("L3 (Graph/SQLite) initialised: %s", graph_db)
            return l3
        except ImportError:
            log.warning("L3 SQLite graph module not found")
        except Exception as exc:
            log.warning("L3 SQLite graph init failed: %s", exc)
        return None


    def _init_bio(self) -> None:
        """Initialise bio-inspired lifecycle layer."""
        try:
            from rewind.bio.decay import ConfidenceDecay
            from rewind.bio.consolidation import MemoryConsolidation
            from rewind.bio.pruning import MemoryPruning
            from rewind.bio.hebbian import HebbianStrengthener
            qdrant_url = self.config.qdrant.url
            collections = ["conversations", "chats", "emails",
                           "memory", "knowledge", "contacts"]
            self._bio = {
                "decay": ConfidenceDecay(qdrant_url, collections),
                "consolidation": MemoryConsolidation(qdrant_url),
                "pruning": MemoryPruning(qdrant_url, collections=collections),
                "hebbian": HebbianStrengthener(),
            }
            log.info("Bio layer initialised (decay, consolidation, pruning, hebbian)")
        except Exception as exc:
            log.warning("Bio layer init failed: %s", exc)

    def _init_feedback(self) -> None:
        """Initialise retrieval feedback system (demotions + boosts)."""
        artifacts_dir = self._feedback_dir or os.path.expanduser(
            os.path.join(os.path.dirname(self.config.vector_db_path), "feedback")
        )
        try:
            from rewind.feedback.demotions import DemotionComputer
            from rewind.feedback.boosts import BoostComputer
            demotions = DemotionComputer(artifacts_dir)
            boosts = BoostComputer(artifacts_dir)
            demotion_result = demotions.compute()
            boost_result = boosts.compute()
            # Extract path→factor mappings from nested dicts
            d_factors = {
                path: info.get("factor", 1.0)
                for path, info in demotion_result.get("demotions", {}).items()
            }
            b_factors = {
                path: info.get("boost", 1.0)
                for path, info in boost_result.get("boosts", {}).items()
            }
            self._feedback = {
                "demotions": demotions,
                "boosts": boosts,
                "demotion_factors": d_factors,
                "boost_factors": b_factors,
            }
            d_count = len(d_factors)
            b_count = len(b_factors)
            if d_count or b_count:
                log.info("Feedback loaded: %d demotions, %d boosts", d_count, b_count)
        except Exception as exc:
            log.debug("Feedback init skipped: %s", exc)

    def _apply_feedback(self, results: List[Result]) -> List[Result]:
        """Apply demotion and boost factors to search results."""
        if not self._feedback:
            return results

        demotion_factors = self._feedback.get("demotion_factors", {})
        boost_factors = self._feedback.get("boost_factors", {})

        for r in results:
            path = r.path
            if path in demotion_factors:
                r.score *= demotion_factors[path]
            if path in boost_factors:
                r.score *= boost_factors[path]

        results.sort(key=lambda r: r.score, reverse=True)
        return results

    def feedback(
        self,
        query: str,
        incorrect_path: str,
        correct_text: str = "",
        score: float = 0.0,
    ) -> dict:
        """Report a correction — this result was wrong for this query.

        Used by MCP server and CLI to feed the retrieval feedback loop.
        """
        if not self._feedback:
            self._init_feedback()
        if not self._feedback:
            return {"status": "feedback not available"}

        from rewind.feedback.corrections import CorrectionDetector
        artifacts_dir = self._feedback_dir or os.path.expanduser(
            os.path.join(os.path.dirname(self.config.vector_db_path), "feedback")
        )
        detector = CorrectionDetector(artifacts_dir)
        event = detector.log_correction(
            query=query, path=incorrect_path,
            score=score, correction_text=correct_text,
            source="api",
        )
        # Recompute demotions
        demotion_result = self._feedback["demotions"].compute()
        self._feedback["demotion_factors"] = {
            path: info.get("factor", 1.0)
            for path, info in demotion_result.get("demotions", {}).items()
        }
        return {"status": "logged", "event": event}

    def _get_embedding_fn(self) -> Optional[Callable[[str], List[float]]]:
        """Return the embedding function — user-provided or auto-configured."""
        if self._embedding_fn:
            return self._embedding_fn

        cfg = self.config.embedding
        if cfg.provider == "ollama":
            return self._make_ollama_embedder(cfg.url, cfg.model)
        elif cfg.provider in ("nv_embed", "openai"):
            if cfg.url == "modal":
                # Modal cloud endpoint — different API format.
                # Requires explicit config (modal.embed_url or REWIND_EMBED_URL).
                modal_cfg = self.config.modal
                embed_url = modal_cfg.embed_url
                if not embed_url:
                    log.error(
                        "cfg.provider set to 'modal' but no embed_url configured. "
                        "Set modal.embed_url in config.yaml or REWIND_EMBED_URL env var."
                    )
                    return None
                auth_token = modal_cfg.resolve_auth()
                return self._make_modal_embedder(embed_url, auth_token)
            return self._make_openai_embedder(cfg.url, cfg.model)
        return None

    @staticmethod
    def _make_ollama_embedder(url: str, model: str) -> Callable[[str], List[float]]:
        """Create an Ollama embedding function. Returns empty list on failure."""
        def embed(text: str) -> List[float]:
            try:
                import httpx
                resp = httpx.post(
                    f"{url}/api/embed",
                    json={"model": model, "input": text},
                    timeout=60,
                )
                resp.raise_for_status()
                data = resp.json()
                return data["embeddings"][0] if "embeddings" in data else data["embedding"]
            except Exception:
                return []
        return embed

    @staticmethod
    def _make_modal_embedder(url: str, auth_token: str) -> Callable[[str], List[float]]:
        """Create a Modal cloud embedding function (NV-Embed-v2 4096-dim)."""
        def embed(text: str) -> List[float]:
            try:
                import httpx
                resp = httpx.post(
                    url,
                    json={"auth_token": auth_token, "texts": [text[:4096]]},
                    timeout=120.0,  # Modal cold starts can take 30-60s
                )
                resp.raise_for_status()
                data = resp.json()
                embeddings = data.get("embeddings", [])
                return embeddings[0] if embeddings else []
            except Exception:
                return []
        return embed

    @staticmethod
    def _make_openai_embedder(url: str, model: str) -> Callable[[str], List[float]]:
        """Create an OpenAI-compatible embedding function. Returns empty list on failure."""
        def embed(text: str) -> List[float]:
            try:
                import httpx
                resp = httpx.post(
                    f"{url}/v1/embeddings",
                    json={"model": model, "input": text},
                    timeout=60,
                )
                resp.raise_for_status()
                return resp.json()["data"][0]["embedding"]
            except Exception:
                return []
        return embed

    # -- public API -------------------------------------------------------

    def search(
        self,
        query: str,
        limit: int = 16,
        namespace: Optional[str] = None,
    ) -> List[Result]:
        """Search across all enabled layers via L2 orchestrator.

        If the orchestrator is available, uses full HybridRAG fusion with
        parallel dispatch, entity extraction, and adaptive scoring.
        Falls back to simple sequential search if orchestrator init failed.
        """
        self._init_layers()

        if self._orchestrator:
            raw_results = self._orchestrator.search(
                query, limit=limit, namespace=namespace,
            )
            results = [
                Result(
                    path=r.get("path", ""),
                    text=r.get("text", ""),
                    score=r.get("score", 0.0),
                    layer=r.get("layer", ""),
                    source=r.get("source", ""),
                    metadata={k: v for k, v in r.items()
                              if k not in ("path", "text", "score", "layer", "source")},
                )
                for r in raw_results
            ]
            return self._apply_feedback(results)

        # Fallback: simple sequential search across layers
        results: List[Result] = []
        for name, layer in self._layers.items():
            try:
                layer_results = layer.search(query, limit=limit, namespace=namespace)
                if isinstance(layer_results, list):
                    for r in layer_results:
                        if isinstance(r, dict):
                            results.append(Result(
                                path=r.get("path", ""),
                                text=r.get("text", ""),
                                score=r.get("score", 0.0),
                                layer=r.get("layer", name),
                                source=r.get("source", ""),
                            ))
                elif isinstance(layer_results, dict) and "results" in layer_results:
                    # L3 returns {"results": [...], "graph_entities": [...]}
                    for r in layer_results["results"]:
                        results.append(Result(
                            path=r.get("path", ""),
                            text=r.get("text", ""),
                            score=r.get("score", 0.0),
                            layer=r.get("layer", name),
                            source=r.get("source", ""),
                        ))
            except Exception as exc:
                log.warning("Search failed on %s: %s", name, exc)

        results.sort(key=lambda r: r.score, reverse=True)
        return self._apply_feedback(results[:limit])

    def ingest(self, path: str, arena: str = "general") -> dict:
        """Ingest a document through L0 sensory buffer.

        For free tier: chunks into FTS5 + sqlite-vec.
        For pro/enterprise: also feeds L3 graph.
        """
        self._init_layers()
        l0 = self._layers.get("l0")
        if l0 and hasattr(l0, "ingest"):
            return l0.ingest(path, arena)
        return {"status": "error", "detail": "L0 sensory layer not available"}

    def health(self) -> dict:
        """Health check across all enabled layers."""
        self._init_layers()
        report: Dict[str, Any] = {
            "tier": self.config.tier,
            "layers": {},
            "orchestrator": self._orchestrator is not None,
            "bio": self._bio is not None,
        }

        for key, layer in self._layers.items():
            try:
                if hasattr(layer, "health"):
                    report["layers"][key] = layer.health()
                else:
                    report["layers"][key] = {"status": "ok"}
            except Exception as exc:
                report["layers"][key] = {"status": "error", "detail": str(exc)}

        report["healthy"] = all(
            v.get("status") in ("ok", "degraded")
            for v in report["layers"].values()
        )
        return report

    def close(self) -> None:
        """Shut down all layer connections."""
        for name, layer in self._layers.items():
            try:
                if hasattr(layer, "close"):
                    layer.close()
            except Exception as exc:
                log.warning("Close failed on %s: %s", name, exc)
        self._layers.clear()
        self._orchestrator = None
        self._bio = None
        self._initialised = False
