"""
Native OpenClaw hooks integration for Rewind Memory.

Creates a pre-turn hook that injects memory context before each LLM turn,
using OpenClaw's native hooks system. Unlike the gateway patch, this
survives npm updates.
"""

import shutil
from pathlib import Path
from typing import Optional

HOOK_DIR_NAME = "pre-turn-memory"

HOOK_MD = """\
---
event: pre-turn
name: rewind-memory
description: Injects relevant memory context before each LLM turn
---

# Rewind Memory Pre-Turn Hook

Queries Rewind's HybridRAG proxy on every inbound message and prepends
the top results as `[Rewind Memory Context]`. Non-fatal — if Rewind is
unreachable, the message passes through unchanged.
"""


def _handler_ts(rewind_url: str) -> str:
    return f"""\
// Rewind Memory pre-turn hook — queries HybridRAG and prepends context
const REWIND_URL = "{rewind_url}";

export default async function handler(message: string): Promise<string> {{
  try {{
    const res = await fetch(`${{REWIND_URL}}/v1/memory/search`, {{
      method: "POST",
      headers: {{ "Content-Type": "application/json" }},
      body: JSON.stringify({{ query: message, limit: 5 }}),
      signal: AbortSignal.timeout(3000),
    }});
    if (!res.ok) return message;
    const data = await res.json();
    const results = data.results ?? data.data ?? [];
    if (!results.length) return message;
    const context = results
      .map((r: any) => r.text ?? r.content ?? "")
      .filter(Boolean)
      .join("\\n---\\n");
    if (!context) return message;
    return `[Rewind Memory Context]\\n${{context}}\\n[/Rewind Memory Context]\\n\\n${{message}}`;
  }} catch {{
    return message;
  }}
}}
"""


def _resolve_workspace(workspace_path: Optional[str] = None) -> Path:
    if workspace_path:
        return Path(workspace_path)
    candidate = Path.home() / ".ocplatform" / "workspace"
    if candidate.exists():
        return candidate
    return Path.cwd()


def create_hook(
    rewind_url: str = "http://localhost:8031",
    workspace_path: Optional[str] = None,
) -> dict:
    """Create the native OpenClaw pre-turn hook for Rewind."""
    workspace = _resolve_workspace(workspace_path)
    hooks_dir = workspace / "hooks" / HOOK_DIR_NAME

    hooks_dir.mkdir(parents=True, exist_ok=True)
    (hooks_dir / "HOOK.md").write_text(HOOK_MD)
    (hooks_dir / "handler.ts").write_text(_handler_ts(rewind_url))

    return {
        "status": "ok",
        "hook_dir": str(hooks_dir),
        "rewind_url": rewind_url,
    }


def verify_hook(workspace_path: Optional[str] = None) -> dict:
    """Check if the pre-turn hook is installed."""
    workspace = _resolve_workspace(workspace_path)
    hooks_dir = workspace / "hooks" / HOOK_DIR_NAME

    hook_md = hooks_dir / "HOOK.md"
    handler = hooks_dir / "handler.ts"

    return {
        "installed": hook_md.exists() and handler.exists(),
        "hook_dir": str(hooks_dir),
        "hook_md": hook_md.exists(),
        "handler_ts": handler.exists(),
    }


def remove_hook(workspace_path: Optional[str] = None) -> dict:
    """Remove the pre-turn hook."""
    workspace = _resolve_workspace(workspace_path)
    hooks_dir = workspace / "hooks" / HOOK_DIR_NAME

    if hooks_dir.exists():
        shutil.rmtree(hooks_dir)
        return {"status": "removed", "hook_dir": str(hooks_dir)}
    return {"status": "not_found", "hook_dir": str(hooks_dir)}
