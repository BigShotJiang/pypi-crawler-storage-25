"""
Rewind integration for OpenClaw — drop-in persistent memory for OpenClaw agents.

Setup:
    1. pip install rewind-memory
    2. Add to your OpenClaw config (openclaw.yaml):

        memory:
          provider: openai
          endpoint: http://localhost:8031/v1
          model: rewind

    3. Start Rewind:
        rewind serve --config configs/default.yaml

    That's it. OpenClaw's memory_search tool now routes through Rewind's
    7-layer HybridRAG stack instead of the built-in SQLite FTS.

Advanced Setup (config patch):
    Use this module to auto-configure OpenClaw programmatically:

        from rewind.integrations.openclaw import configure_openclaw
        configure_openclaw(rewind_url="http://localhost:8031")

Architecture:
    OpenClaw already speaks the OpenAI chat completions API for memory search.
    Rewind's L2 HybridRAG proxy exposes `/v1/chat/completions` natively.
    So integration is purely a config change — no code modification to OpenClaw.

    Flow:
        OpenClaw agent → memory_search("query")
            → OpenClaw memory provider (openai-compatible)
            → Rewind L2 HybridRAG (/v1/chat/completions on :8031)
            → Parallel dispatch to L0, L1, L3, L4
            → Fused, deduplicated, scored results
            → Back to agent context

Gateway Pre-Turn Hook (NEW):
    For deeper integration, patch the OpenClaw gateway to fire Rewind on
    every inbound message BEFORE the LLM processes it:

        rewind-openclaw patch

    This injects memory context directly into the message. The agent always
    has relevant memory without calling memory_search. Re-apply after npm updates.

    Verify:  rewind-openclaw patch --verify
    Remove:  rewind-openclaw patch --restore
"""

import json
import subprocess
from pathlib import Path
from typing import Optional


def configure_openclaw(
    rewind_url: str = "http://localhost:8031",
    config_path: Optional[str] = None,
    dry_run: bool = False,
) -> dict:
    """
    Configure OpenClaw to use Rewind as its memory provider.

    This patches the OpenClaw config to route memory_search through
    Rewind's HybridRAG proxy instead of the built-in SQLite FTS.

    Args:
        rewind_url: URL of the running Rewind API (default: http://localhost:8031)
        config_path: Path to openclaw.yaml (auto-detected if not provided)
        dry_run: If True, return the config patch without applying it

    Returns:
        dict with status, config patch applied, and any warnings
    """
    # Auto-detect OpenClaw config
    if config_path is None:
        candidates = [
            Path.home() / ".openclaw" / "config.yaml",
            Path.home() / ".openclaw" / "openclaw.yaml",
            Path("openclaw.yaml"),
        ]
        for c in candidates:
            if c.exists():
                config_path = str(c)
                break

    patch = {
        "memory": {
            "provider": "openai",
            "endpoint": f"{rewind_url}/v1",
            "model": "rewind",
        }
    }

    result = {
        "status": "ok",
        "patch": patch,
        "rewind_url": rewind_url,
        "config_path": config_path,
        "applied": False,
    }

    if dry_run:
        result["status"] = "dry_run"
        return result

    # Try using openclaw CLI for atomic config patching
    try:
        subprocess.run(
            [
                "openclaw", "config", "set",
                "memory.provider", "openai",
            ],
            capture_output=True, text=True, check=True,
        )
        subprocess.run(
            [
                "openclaw", "config", "set",
                "memory.endpoint", f"{rewind_url}/v1",
            ],
            capture_output=True, text=True, check=True,
        )
        subprocess.run(
            [
                "openclaw", "config", "set",
                "memory.model", "rewind",
            ],
            capture_output=True, text=True, check=True,
        )
        result["applied"] = True
        result["method"] = "openclaw_cli"
    except (FileNotFoundError, subprocess.CalledProcessError) as e:
        result["status"] = "manual_required"
        result["error"] = str(e)
        result["instructions"] = (
            "Could not auto-configure. Add this to your openclaw.yaml:\n\n"
            f"memory:\n"
            f"  provider: openai\n"
            f"  endpoint: {rewind_url}/v1\n"
            f"  model: rewind\n"
        )

    return result


def verify_connection(rewind_url: str = "http://localhost:8031") -> dict:
    """
    Verify that Rewind is running and accessible.

    Returns:
        dict with status, version, layer health, and stats
    """
    import httpx

    result = {"status": "error", "url": rewind_url}

    try:
        with httpx.Client(timeout=5.0) as client:
            # Check health
            health = client.get(f"{rewind_url}/health")
            if health.status_code == 200:
                result["health"] = health.json()
                result["status"] = "ok"

            # Check stats
            try:
                stats = client.get(f"{rewind_url}/stats")
                if stats.status_code == 200:
                    result["stats"] = stats.json()
            except Exception:
                pass

            # Test a search
            try:
                test = client.post(
                    f"{rewind_url}/v1/memory/search",
                    json={"query": "test connection", "limit": 1},
                )
                result["search_ok"] = test.status_code == 200
            except Exception:
                result["search_ok"] = False

    except httpx.ConnectError:
        result["error"] = f"Cannot connect to Rewind at {rewind_url}"
        result["instructions"] = "Start Rewind with: rewind serve --config configs/default.yaml"
    except Exception as e:
        result["error"] = str(e)

    return result


def generate_openclaw_skill() -> str:
    """
    Generate an OpenClaw SKILL.md for Rewind memory integration.

    This can be installed as a skill in any OpenClaw workspace to provide
    guided memory search with Rewind's full 7-layer stack.

    Returns:
        SKILL.md content as a string
    """
    return '''# Rewind Memory — SKILL.md

## Description
Persistent 7-layer bio-inspired memory for your OpenClaw agent. Search across
keyword (L0), system files (L1), knowledge graph (L3), semantic vectors (L4),
all fused through HybridRAG (L2).

## When to Use
- Before answering questions about prior work, decisions, people, or dates
- When the user references something from a past conversation
- To store important decisions, facts, or commitments for future recall
- When built-in memory_search returns insufficient results

## Setup
Ensure Rewind is running and OpenClaw is configured:
```bash
rewind serve --config configs/default.yaml
# OpenClaw config: memory.provider=openai, memory.endpoint=http://localhost:8031/v1
```

## Usage

### Search memory
```
memory_search("what was decided about the auth approach?")
```

### Store a memory
```bash
curl -X POST http://localhost:8031/v1/memory/store \\
  -H "Content-Type: application/json" \\
  -d '{"content": "Decided to file patent on 28 March 2026", "metadata": {"type": "decision"}}'
```

### Get stats
```bash
curl http://localhost:8031/stats
```

## Architecture
L0 (BM25) → L1 (System Files) → L2 (HybridRAG Orchestration) → L3 (Neo4j Graph)
→ L4 (Vector/NV-Embed)

Bio-inspired: Hebbian strengthening, spreading activation, confidence decay,
memory promotion, synaptic pruning, knowledge crystallisation, episodic tagging.

Benchmark: 99.3% on LoCoMo (33.9pp above best published baseline).
'''


# ── CLI Entry Point ───────────────────────────────────────────────────────────

def main():
    """CLI for OpenClaw integration — setup, patch, verify."""
    import argparse

    parser = argparse.ArgumentParser(description="Rewind × OpenClaw Integration")
    sub = parser.add_subparsers(dest="command")

    # setup — configure OpenClaw config to route memory_search through Rewind
    setup_cmd = sub.add_parser("setup", help="Configure OpenClaw to use Rewind")
    setup_cmd.add_argument("--url", default="http://localhost:8031")
    setup_cmd.add_argument("--dry-run", action="store_true")

    # patch — inject pre-turn memory gate into OpenClaw gateway
    patch_cmd = sub.add_parser("patch", help="Apply pre-turn memory gate to OpenClaw gateway")
    patch_cmd.add_argument("--rewind-url", default="http://localhost:8031",
                           help="URL of Rewind HybridRAG proxy")
    patch_cmd.add_argument("--dist-dir", help="Path to OpenClaw dist directory")
    patch_cmd.add_argument("--dry-run", action="store_true")
    patch_cmd.add_argument("--verify", action="store_true",
                           help="Check if patch is applied")
    patch_cmd.add_argument("--restore", action="store_true",
                           help="Remove the Rewind patch")

    # hook — create native OpenClaw hook (recommended, survives updates)
    hook_cmd = sub.add_parser("hook", help="Create native OpenClaw pre-turn hook (recommended)")
    hook_cmd.add_argument("--rewind-url", default="http://localhost:8031")
    hook_cmd.add_argument("--workspace", help="OpenClaw workspace path (auto-detected)")
    hook_cmd.add_argument("--verify", action="store_true")
    hook_cmd.add_argument("--remove", action="store_true")

    sub.add_parser("verify", help="Verify Rewind connection")
    sub.add_parser("skill", help="Generate OpenClaw SKILL.md")

    args = parser.parse_args()

    if args.command == "setup":
        result = configure_openclaw(rewind_url=args.url, dry_run=args.dry_run)
        print(json.dumps(result, indent=2))
    elif args.command == "patch":
        from rewind.integrations.openclaw_gateway import (
            patch_gateway, verify_patch, restore_gateway,
        )
        from pathlib import Path
        dist = Path(args.dist_dir) if args.dist_dir else None
        if args.verify:
            result = verify_patch(dist)
        elif args.restore:
            result = restore_gateway(dist)
        else:
            result = patch_gateway(
                rewind_url=args.rewind_url, dist_dir=dist, dry_run=args.dry_run,
            )
        print(json.dumps(result, indent=2))
    elif args.command == "hook":
        from rewind.integrations.ocplatform_hooks import (
            create_hook, verify_hook, remove_hook,
        )
        ws = Path(args.workspace) if args.workspace else None
        if args.verify:
            result = verify_hook(ws)
        elif args.remove:
            result = remove_hook(ws)
        else:
            result = create_hook(rewind_url=args.rewind_url, workspace_path=ws)
        print(json.dumps(result, indent=2))
    elif args.command == "verify":
        result = verify_connection()
        print(json.dumps(result, indent=2))
    elif args.command == "skill":
        print(generate_openclaw_skill())
    else:
        parser.print_help()


if __name__ == "__main__":
    main()