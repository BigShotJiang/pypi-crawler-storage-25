"""
OpenClaw Gateway Autopatcher — Pre-turn Memory Gate.

Patches the OpenClaw gateway to fire Rewind memory search on every inbound
message BEFORE the LLM processes it. The agent always has relevant memory
context without needing to call memory_search manually.

Usage (CLI):
    rewind-openclaw patch [--rewind-url http://localhost:8031] [--dry-run]
    rewind-openclaw patch --verify
    rewind-openclaw patch --restore

Usage (Python):
    from rewind.integrations.openclaw_gateway import patch_gateway
    result = patch_gateway(rewind_url="http://localhost:8031")

How it works:
    1. Finds the OpenClaw gateway dispatch function (auth-profiles-*.js)
    2. Injects a pre-turn hook that:
       - Takes the inbound message text
       - Queries Rewind's HybridRAG proxy for relevant memory
       - Prepends the top results as context to the message
    3. The LLM sees memory context automatically — zero extra tool calls
    4. Non-destructive: guarded by try/catch, failures are silent
"""

import re
import shutil
import subprocess
from pathlib import Path
from typing import Optional


MARKER = "__REWIND_PRETURN_GATE_v1__"


def find_openclaw_dist() -> Optional[Path]:
    """Auto-detect the OpenClaw dist directory."""
    # npm global root
    try:
        result = subprocess.run(
            ["npm", "root", "-g"], capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            dist = Path(result.stdout.strip()) / "openclaw" / "dist"
            if dist.exists():
                return dist
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    # nvm versions
    nvm_base = Path.home() / ".nvm" / "versions"
    if nvm_base.exists():
        matches = sorted(nvm_base.glob("node/*/lib/node_modules/openclaw/dist"))
        if matches:
            return matches[-1]

    # System locations
    for p in [
        Path("/usr/lib/node_modules/openclaw/dist"),
        Path("/usr/local/lib/node_modules/openclaw/dist"),
    ]:
        if p.exists():
            return p

    return None


def find_auth_file(dist_dir: Path) -> Optional[Path]:
    """Find the auth-profiles JS file."""
    matches = [
        m for m in dist_dir.glob("auth-profiles-*.js")
        if not str(m).endswith(".map")
    ]
    return matches[0] if matches else None


def is_patched(auth_file: Path) -> bool:
    """Check if the pre-turn gate is already applied."""
    return MARKER in auth_file.read_text()


def _build_patch_js(rewind_url: str) -> str:
    """Build the injected JavaScript.

    Uses String.fromCharCode(10) for newlines to avoid escaping issues
    across shell/Python/JS boundaries.
    """
    return f"""\t/* {MARKER} */
\ttry {{
\t\tconst _userText = finalized.Body || finalized.Text || '';
\t\tif (_userText && _userText.length > 15) {{
\t\t\tconst _resp = await fetch('{rewind_url}/search?q=' + encodeURIComponent(_userText.substring(0, 200)) + '&limit=5', {{ signal: AbortSignal.timeout(4000) }}).catch(() => null);
\t\t\tif (_resp && _resp.ok) {{
\t\t\t\tconst _data = await _resp.json().catch(() => null);
\t\t\t\tif (_data && _data.results && _data.results.length > 0) {{
\t\t\t\t\tconst _ctx = _data.results.slice(0, 5).map(r => {{
\t\t\t\t\t\tconst t = (r.text || r.snippet || '').substring(0, 200);
\t\t\t\t\t\tconst s = r.path || r.source || 'memory';
\t\t\t\t\t\treturn '- ' + t + ' (source: ' + s + ')';
\t\t\t\t\t}}).join(String.fromCharCode(10));
\t\t\t\t\tconst _hdr = '[Rewind Memory Context]' + String.fromCharCode(10);
\t\t\t\t\tconst _sep = String.fromCharCode(10, 10);
\t\t\t\t\tif (finalized.Body) finalized.Body = _hdr + _ctx + _sep + finalized.Body;
\t\t\t\t\telse if (finalized.Text) finalized.Text = _hdr + _ctx + _sep + finalized.Text;
\t\t\t\t}}
\t\t\t}}
\t\t}}
\t}} catch(_e) {{ /* rewind pre-turn gate — non-fatal */ }}
"""


def patch_gateway(
    rewind_url: str = "http://localhost:8031",
    dist_dir: Optional[Path] = None,
    dry_run: bool = False,
) -> dict:
    """
    Patch the OpenClaw gateway with the Rewind pre-turn memory gate.

    Args:
        rewind_url: URL of the running Rewind HybridRAG proxy
        dist_dir: Path to OpenClaw dist directory (auto-detected if None)
        dry_run: If True, report what would be done without modifying files

    Returns:
        dict with status and details
    """
    result = {"status": "error", "rewind_url": rewind_url}

    if dist_dir is None:
        dist_dir = find_openclaw_dist()
    if dist_dir is None or not dist_dir.exists():
        result["error"] = "Could not find OpenClaw dist directory"
        result["hint"] = "Ensure OpenClaw is installed globally via npm"
        return result

    result["dist_dir"] = str(dist_dir)

    auth_file = find_auth_file(dist_dir)
    if auth_file is None:
        result["error"] = "Could not find auth-profiles-*.js in dist"
        return result

    result["auth_file"] = str(auth_file)

    if is_patched(auth_file):
        result["status"] = "already_patched"
        result["message"] = "Pre-turn memory gate already applied"
        return result

    if dry_run:
        result["status"] = "dry_run"
        result["message"] = f"Would patch {auth_file.name}"
        return result

    content = auth_file.read_text()

    # Find the dispatch anchor
    anchor_re = (
        r"(async function dispatchInboundMessage\(params\)\s*\{\s*"
        r"const finalized = finalizeInboundContext\(params\.ctx\);\s*)"
        r"(return await withReplyDispatcher\(\{)"
    )
    match = re.search(anchor_re, content)
    if not match:
        result["error"] = "Could not find dispatchInboundMessage anchor"
        result["hint"] = "OpenClaw version may be incompatible"
        return result

    # Backup
    backup = auth_file.with_suffix(".js.rewind-backup")
    shutil.copy2(auth_file, backup)

    # Inject
    patch_js = _build_patch_js(rewind_url)
    replacement = match.group(1) + patch_js + "\t" + match.group(2)
    content = content[:match.start()] + replacement + content[match.end():]
    auth_file.write_text(content)

    # Verify
    if is_patched(auth_file):
        backup.unlink(missing_ok=True)
        result["status"] = "ok"
        result["message"] = "Pre-turn memory gate applied successfully"
    else:
        shutil.copy2(backup, auth_file)
        backup.unlink(missing_ok=True)
        result["error"] = "Patch verification failed — restored backup"

    return result


def verify_patch(dist_dir: Optional[Path] = None) -> dict:
    """Check if the gateway patch is in place."""
    if dist_dir is None:
        dist_dir = find_openclaw_dist()
    if dist_dir is None:
        return {"status": "error", "error": "OpenClaw dist not found"}

    auth_file = find_auth_file(dist_dir)
    if auth_file is None:
        return {"status": "error", "error": "auth-profiles JS not found"}

    patched = is_patched(auth_file)
    return {"status": "ok" if patched else "not_patched", "patched": patched}


def restore_gateway(dist_dir: Optional[Path] = None) -> dict:
    """Remove the Rewind pre-turn gate from the gateway."""
    if dist_dir is None:
        dist_dir = find_openclaw_dist()
    if dist_dir is None:
        return {"status": "error", "error": "OpenClaw dist not found"}

    auth_file = find_auth_file(dist_dir)
    if auth_file is None:
        return {"status": "error", "error": "auth-profiles JS not found"}

    if not is_patched(auth_file):
        return {"status": "ok", "message": "Not patched — nothing to restore"}

    content = auth_file.read_text()
    pattern = rf'\t/\* {re.escape(MARKER)} \*/.*?/\* rewind pre-turn gate — non-fatal \*/ \}}\n'
    content = re.sub(pattern, '', content, flags=re.DOTALL)
    auth_file.write_text(content)

    return {
        "status": "ok" if not is_patched(auth_file) else "error",
        "message": "Patch removed" if not is_patched(auth_file) else "Partial removal",
    }
