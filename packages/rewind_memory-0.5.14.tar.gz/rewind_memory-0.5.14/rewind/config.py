"""Rewind configuration — YAML-driven, tier-aware, no hardcoded paths."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Optional

import yaml


# ---------------------------------------------------------------------------
# Sub-configs
# ---------------------------------------------------------------------------

@dataclass
class EmbeddingConfig:
    provider: str = "ollama"          # ollama | nv_embed | openai
    url: str = "http://localhost:11434"
    model: str = "nomic-embed-text"
    dimension: int = 768


@dataclass
class Neo4jConfig:
    uri: str = "bolt://localhost:7687"
    user: str = "neo4j"
    password: str = ""
    secrets_file: Optional[str] = None   # path to JSON with {"password": "..."}

    def resolve_password(self) -> str:
        """Return password, loading from secrets file if configured."""
        if self.secrets_file and not self.password:
            p = Path(self.secrets_file).expanduser()
            if p.exists():
                data = json.loads(p.read_text())
                self.password = data.get("password", data.get("neo4j_password", ""))
        return self.password


@dataclass
class QdrantConfig:
    url: str = "http://localhost:6333"


@dataclass
class LayerFlags:
    l0_sensory: bool = True       # always on — FTS5/BM25 keyword search
    l1_stm: bool = True           # short-term memory (sqlite-vec)
    l2_orchestrator: bool = True  # search router — implicitly on when any store is
    l3_graph: bool = True         # knowledge graph (SQLite default, Neo4j optional)
    l4_workspace: bool = True     # file-system workspace memory (sqlite-vec)
    bio: bool = False             # bio-inspired lifecycle (decay, consolidation, pruning)


# ---------------------------------------------------------------------------
# Main config
# ---------------------------------------------------------------------------

@dataclass
class RewindConfig:
    layers: LayerFlags = field(default_factory=LayerFlags)
    embedding: EmbeddingConfig = field(default_factory=EmbeddingConfig)
    neo4j: Neo4jConfig = field(default_factory=Neo4jConfig)
    qdrant: QdrantConfig = field(default_factory=QdrantConfig)
    vector_db_path: str = "./data/vector.db"
    workspace_path: str = "./workspace"
    tier: str = "free"

    # Arbitrary extra keys from YAML
    extra: Dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Tier presets
# ---------------------------------------------------------------------------

_TIER_LAYERS: Dict[str, Dict[str, bool]] = {
    "free": dict(
        l0_sensory=True, l1_stm=True, l2_orchestrator=True,
    ),
    "pro": dict(
        l0_sensory=True, l1_stm=True, l2_orchestrator=True,
    ),
    "enterprise": dict(
        l0_sensory=True, l1_stm=True, l2_orchestrator=True,
    ),
}

_TIER_EMBEDDING: Dict[str, Dict[str, Any]] = {
    "free": dict(provider="ollama", url="http://localhost:11434",
                 model="nomic-embed-text", dimension=768),
    "pro": dict(provider="nv_embed", url="http://localhost:8080",
                model="NV-Embed-v2", dimension=4096),
    "enterprise": dict(provider="nv_embed", url="http://localhost:8080",
                       model="NV-Embed-v2", dimension=4096),
}


def detect_tier(layers: LayerFlags) -> str:
    """Infer tier string from enabled layers."""
    if layers.bio:
        return "enterprise"
        return "pro"
    return "free"


# ---------------------------------------------------------------------------
# Builders
# ---------------------------------------------------------------------------

def _build_sub(cls, raw: dict | None):
    """Instantiate a dataclass from a dict, ignoring unknown keys."""
    if not raw:
        return cls()
    valid = {f.name for f in cls.__dataclass_fields__.values()}
    return cls(**{k: v for k, v in raw.items() if k in valid})


def load_config(path: str) -> RewindConfig:
    """Load an RewindConfig from a YAML file."""
    p = Path(path).expanduser()
    with p.open() as f:
        raw: dict = yaml.safe_load(f) or {}

    layers = _build_sub(LayerFlags, raw.get("layers"))
    embedding = _build_sub(EmbeddingConfig, raw.get("embedding"))
    neo4j = _build_sub(Neo4jConfig, raw.get("neo4j"))
    qdrant = _build_sub(QdrantConfig, raw.get("qdrant"))

    # Resolve neo4j password from env or secrets file
    if not neo4j.password:
        neo4j.password = os.environ.get("REWIND_NEO4J_PASSWORD", "")
    neo4j.resolve_password()

    known = {"layers", "embedding", "neo4j", "qdrant",
             "vector_db_path", "workspace_path", "tier"}
    extra = {k: v for k, v in raw.items() if k not in known}

    cfg = RewindConfig(
        layers=layers,
        embedding=embedding,
        neo4j=neo4j,
        qdrant=qdrant,
        vector_db_path=raw.get("vector_db_path", "./data/vector.db"),
        workspace_path=raw.get("workspace_path", "./workspace"),
        tier=raw.get("tier", detect_tier(layers)),
        extra=extra,
    )
    return cfg


_CONFIG_SEARCH_PATHS = [
    "~/.rewind/config.yaml",
    "~/.rewind/config.yml",
    ".rewind/config.yaml",
    "rewind.yaml",
]


def default_config(tier: str = "free") -> RewindConfig:
    """Return config, auto-loading from YAML if found.

    Search order:
      1. REWIND_CONFIG env var
      2. ~/.rewind/config.yaml
      3. ~/.rewind/config.yml
      4. .rewind/config.yaml
      5. rewind.yaml
      6. Hardcoded tier defaults
    """
    env_path = os.environ.get("REWIND_CONFIG")
    if env_path:
        p = Path(env_path).expanduser()
        if p.exists():
            return load_config(str(p))

    for candidate in _CONFIG_SEARCH_PATHS:
        p = Path(candidate).expanduser()
        if p.exists():
            return load_config(str(p))

    tier = tier.lower()
    if tier not in _TIER_LAYERS:
        raise ValueError(f"Unknown tier {tier!r}; choose free/pro/enterprise")

    return RewindConfig(
        layers=LayerFlags(**_TIER_LAYERS[tier]),
        embedding=EmbeddingConfig(**_TIER_EMBEDDING[tier]),
        neo4j=Neo4jConfig(),
        qdrant=QdrantConfig(),
        tier=tier,
    )
