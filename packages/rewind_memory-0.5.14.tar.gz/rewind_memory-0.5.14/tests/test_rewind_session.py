"""Regression tests for rewind.session.rewind_session (Free tier).

Covers flush / resume / detect primitives end-to-end with a temporary
workspace. No third-party services required.
"""
import json
import time
from pathlib import Path

import pytest

from rewind.session import (
    RewindSession,
    FlushResult,
    ResumeBlock,
    DetectResult,
)


def _make_workspace(tmp_path: Path, *, with_transcript: bool = True,
                    with_session_state: bool = True,
                    with_memory_dir: bool = True) -> Path:
    if with_transcript:
        tpath = tmp_path / "chats" / "transcript"
        tpath.mkdir(parents=True, exist_ok=True)
        (tpath / "last-reload.txt").write_text(
            "User: I'm in London today. Building the harness and debugging auth.\n"
            "Assistant: Got it.\n"
            "User: Then investigate the pipeline issue.\n"
        )
    if with_session_state:
        (tmp_path / "SESSION-STATE.md").write_text(
            "# SESSION-STATE.md\n\n"
            "## LIVE — Auth debugging\n\n"
            "- Investigating OAuth refresh flow\n"
            "- Blocked on token lifetime decision\n\n"
            "---\n"
        )
    if with_memory_dir:
        (tmp_path / "memory").mkdir(exist_ok=True)
    return tmp_path


def test_flush_writes_marker_and_context(tmp_path):
    ws = _make_workspace(tmp_path)
    session = RewindSession(workspace=str(ws))
    result = session.flush()

    assert isinstance(result, FlushResult)
    assert result.location == "London"
    assert "Europe/London" in (result.timezone or "")
    assert len(result.topics) > 0

    marker = ws / ".rewind-session-flush"
    assert marker.exists()
    payload = json.loads(marker.read_text())
    assert payload["location"] == "London"
    assert payload["tier"] == "free"

    assert (ws / "SESSION-CONTEXT.md").exists()


def test_flush_appends_to_daily_note(tmp_path):
    ws = _make_workspace(tmp_path)
    session = RewindSession(workspace=str(ws))
    session.flush()

    memory_files = list((ws / "memory").glob("*.md"))
    assert len(memory_files) == 1
    content = memory_files[0].read_text()
    assert "Pre-compaction flush" in content
    assert "London" in content


def test_flush_without_memory_dir_skips_daily(tmp_path):
    ws = _make_workspace(tmp_path, with_memory_dir=False)
    session = RewindSession(workspace=str(ws))
    result = session.flush()
    assert result.bytes_written == 0
    assert not (ws / "memory").exists()


def test_detect_before_flush(tmp_path):
    session = RewindSession(workspace=str(tmp_path))
    result = session.detect()
    assert result.post_compaction is False
    assert result.reason == "no marker file"


def test_detect_after_fresh_flush(tmp_path):
    ws = _make_workspace(tmp_path)
    session = RewindSession(workspace=str(ws))
    session.flush()
    result = session.detect()
    assert result.post_compaction is True
    assert result.last_flush_age_s is not None


def test_detect_respects_max_age(tmp_path):
    ws = _make_workspace(tmp_path)
    session = RewindSession(workspace=str(ws))
    session.flush()
    marker = ws / ".rewind-session-flush"
    payload = json.loads(marker.read_text())
    payload["flushed_at_epoch"] = int(time.time()) - 10000
    marker.write_text(json.dumps(payload))
    result = session.detect(max_age_s=7200)
    assert result.post_compaction is False


def test_resume_empty_workspace(tmp_path):
    session = RewindSession(workspace=str(tmp_path))
    block = session.resume()
    assert block.empty is True


def test_resume_after_flush(tmp_path):
    ws = _make_workspace(tmp_path)
    session = RewindSession(workspace=str(ws))
    session.flush()
    block = session.resume()

    assert block.empty is False
    assert "London" in block.markdown
    assert "Auth debugging" in block.markdown


def test_resume_respects_token_budget(tmp_path):
    ws = _make_workspace(tmp_path)
    big = "## LIVE — Huge section\n" + ("x" * 10000)
    (ws / "SESSION-STATE.md").write_text(big)
    session = RewindSession(workspace=str(ws))
    session.flush()
    block = session.resume(token_budget=100)
    assert len(block.markdown) <= 500
    assert "truncated" in block.markdown.lower()


def test_tier_is_free(tmp_path):
    session = RewindSession(workspace=str(tmp_path))
    assert session._tier == "free"


def test_continuity_no_personal_names():
    from rewind.session.continuity import SessionContinuity
    cities = set(SessionContinuity.TZ_MAP.keys())
    # Build-from-parts so the literal never appears in packaged source
    banned = {"W" + "orth" + "ing"}
    assert not (banned & cities), "PII leaked back into TZ_MAP"
