"""Regression test for L4 sqlite-vec dimension-migration bug.

Covers the Free→Pro upgrade path where chunks_vec was created at 768-dim
(local sentence-transformers) and must be migrated to 4096-dim (Modal
NV-Embed-v2) without corrupting the DB.

Bug history: first observed 2026-04-15 during CaP-X strategy-hint ingest,
documented in memory/sarai/rewind-distribution-rules.md.
"""
import os
import sqlite3
import struct
import tempfile

import pytest


@pytest.fixture
def vec_db():
    from rewind.utils import load_vec0

    tmp = tempfile.mkdtemp(prefix="rewind-dim-test-")
    db_path = os.path.join(tmp, "t.db")
    conn = sqlite3.connect(db_path)
    if not load_vec0(conn):
        pytest.skip("sqlite-vec extension not available")
    conn.executescript(
        """
        CREATE TABLE chunks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            path TEXT NOT NULL,
            text TEXT NOT NULL,
            hash TEXT
        );
        """
    )
    yield conn, db_path
    conn.close()


def _pack(dim, val=0.1):
    return struct.pack(f"{dim}f", *([val] * dim))


def test_ensure_vec_table_creates_new(vec_db):
    """Calling _ensure_vec_table on a fresh DB creates chunks_vec at given dim."""
    from rewind.ingest import IngestPipeline

    conn, _ = vec_db
    pipeline = IngestPipeline.__new__(IngestPipeline)
    assert pipeline._ensure_vec_table(conn, 768) is True

    row = conn.execute(
        "SELECT sql FROM sqlite_master WHERE name='chunks_vec'"
    ).fetchone()
    assert "float[768]" in row[0]


def test_ensure_vec_table_is_idempotent(vec_db):
    """Calling twice with the same dim does not discard vectors."""
    from rewind.ingest import IngestPipeline

    conn, _ = vec_db
    pipeline = IngestPipeline.__new__(IngestPipeline)
    pipeline._ensure_vec_table(conn, 768)
    conn.execute("INSERT INTO chunks(path, text) VALUES ('/a', 'hi')")
    conn.execute(
        "INSERT INTO chunks_vec(rowid, embedding) VALUES (1, ?)", (_pack(768),)
    )
    conn.commit()

    assert pipeline._ensure_vec_table(conn, 768) is True
    n = conn.execute("SELECT COUNT(*) FROM chunks_vec").fetchone()[0]
    assert n == 1, "same-dim call must be a no-op"


def test_ensure_vec_table_migrates_on_dim_change(vec_db):
    """Free→Pro upgrade (768→4096) triggers a safe migration."""
    from rewind.ingest import IngestPipeline

    conn, _ = vec_db
    pipeline = IngestPipeline.__new__(IngestPipeline)

    # Stage: Free installation (768-dim)
    pipeline._ensure_vec_table(conn, 768)
    conn.execute(
        "INSERT INTO chunks(path, text, hash) VALUES ('/a', 'hi', 'OLD')"
    )
    conn.execute(
        "INSERT INTO chunks_vec(rowid, embedding) VALUES (1, ?)", (_pack(768),)
    )
    conn.commit()

    # Stage: Pro upgrade (4096-dim)
    assert pipeline._ensure_vec_table(conn, 4096) is True

    # Table now 4096-dim
    row = conn.execute(
        "SELECT sql FROM sqlite_master WHERE name='chunks_vec'"
    ).fetchone()
    assert "float[4096]" in row[0]

    # Stale vectors discarded
    n = conn.execute("SELECT COUNT(*) FROM chunks_vec").fetchone()[0]
    assert n == 0

    # Hash invalidated so next ingest re-embeds from chunks.text
    h = conn.execute("SELECT hash FROM chunks WHERE id=1").fetchone()[0]
    assert h == ""

    # 4096-dim inserts now work — this is the bug's surface symptom
    conn.execute(
        "INSERT INTO chunks_vec(rowid, embedding) VALUES (1, ?)", (_pack(4096),)
    )
    conn.commit()
    n = conn.execute("SELECT COUNT(*) FROM chunks_vec").fetchone()[0]
    assert n == 1
