"""paper_writing sub-module — Journal 論文の作文技術."""
from . import tools as _tools


def register(mcp) -> int:
    """Register paper_writing_* tools with the given FastMCP instance."""
    count = 0
    for name in dir(_tools):
        if name.startswith("paper_writing_") and callable(getattr(_tools, name)):
            mcp.tool()(getattr(_tools, name))
            count += 1
    return count
