"""Tool functions for the paper-writing domain of mcp-server-document.

All functions are plain callables; they get wrapped by @mcp.tool()
in the top-level server.py. No FastMCP import here (that would
accidentally register a second MCP server).
"""

from __future__ import annotations

import pathlib
import re


_HERE = pathlib.Path(__file__).resolve().parent
KNOWLEDGE = _HERE


def _load_skill() -> str:
    return (KNOWLEDGE / "skill.md").read_text(encoding="utf-8")


# ------------------------------------------------------------------
# Knowledge loader
# ------------------------------------------------------------------
def paper_writing_usage() -> str:
    """Journal 論文 (IEEE / IEEJ / APS / Elsevier 等) の作文技術ガイド全体。

    IMRAD 構造 (Abstract/Intro/Method/Result/Discussion/Conclusion) の
    書き方、contribution 明示、reviewer 2 対策、citation pattern、
    figure placement、abstract 字数、英文 red-flag 検出、cover letter
    テンプレート等の総合ガイド。

    呼び出しタイミング:
    - Journal paper ドラフトのレビュー依頼
    - 「contribution が不明瞭」feedback 対応
    - Reviewer コメントへの response letter 作成
    - Abstract / Introduction の書き直し
    - 英文チェック (冠詞抜け、時制不統一、自動詞/他動詞)
    - 投稿前の最終チェックリスト

    活動ツール (実測) は以下を併用:
    - paper_writing_count_underlines(tex_path)         — 下線/強調の密度
    - paper_writing_validate_pdf_pages(pdf_path, limit) — 投稿ページ制限
    - paper_writing_check_overfull_hbox(log_path)       — 組版警告
    - paper_writing_analyze_sentences(text, max_len)    — 文長統計
    - paper_writing_count_weak_expressions(text)        — 弱気修飾語
    - paper_writing_validate_abstract_length(text, max) — abstract 字数
    - paper_writing_check_citation_usage(tex, bib)      — 引用/文献整合
    """
    return _load_skill()


# ------------------------------------------------------------------
# Active diagnostic tools (shared across writing MCPs)
# ------------------------------------------------------------------
def paper_writing_count_underlines(tex_path: str) -> dict:
    """TeX/LaTeX 内の下線コマンドを実測。論文では原則ゼロを目指す。

    目標: 0 (journal paper では strong/em で十分、下線は稀)
    警告: >=5 per page
    """
    p = pathlib.Path(tex_path)
    if not p.exists():
        return {"error": f"file not found: {tex_path}"}
    text = p.read_text(encoding="utf-8", errors="replace")
    macros = ["uline", "underline", "uwave", "uuline",
              "sout", "dashuline", "dotuline"]
    by_macro: dict[str, int] = {}
    total = 0
    for m in macros:
        n = len(re.findall(r"\\" + m + r"\{", text))
        if n:
            by_macro[m] = n
            total += n
    return {
        "file": str(p),
        "total_underlines": total,
        "by_macro": by_macro,
        "target_range": "0 (journal paper では 強調は \\emph / \\textbf)",
        "warning_threshold": ">=5 per page",
    }


def paper_writing_validate_pdf_pages(pdf_path: str, page_limit: int) -> dict:
    """PDF のページ数が投稿制限内か検証。pymupdf が必要。

    参考:
        IEEE Transactions: 規定なし (extended)、letter形式は 4 page
        IEEJ Transactions: 原著論文 8 pages 推奨、10 pages 上限
        APS PRL: 4 pages (本文+refs+fig)
        APS PRB: 制限なし (ページ課金あり)
        Elsevier JMMM: 制限なし
    """
    try:
        import pymupdf  # type: ignore
    except ImportError:
        return {"error": "pymupdf not installed. `pip install pymupdf`"}
    p = pathlib.Path(pdf_path)
    if not p.exists():
        return {"error": f"file not found: {pdf_path}"}
    doc = pymupdf.open(pdf_path)
    n = doc.page_count
    doc.close()
    return {
        "file": str(p),
        "page_count": n,
        "page_limit": page_limit,
        "within_limit": n <= page_limit,
        "pages_over": max(0, n - page_limit),
    }


def paper_writing_check_overfull_hbox(log_path: str) -> dict:
    """LaTeX ログ中の Overfull \\hbox 警告をカウント。journal では許容ゼロ。"""
    p = pathlib.Path(log_path)
    if not p.exists():
        return {"error": f"file not found: {log_path}"}
    text = p.read_text(encoding="utf-8", errors="replace")
    matches = re.findall(
        r"Overfull \\hbox \(([^)]+)\) in paragraph at lines (\d+)(?:--(\d+))?",
        text,
    )
    details = [
        {"severity": m[0], "lines": m[1] + (f"-{m[2]}" if m[2] else "")}
        for m in matches[:20]
    ]
    return {
        "file": str(p),
        "overfull_count": len(matches),
        "overfull_details": details,
        "target": "0 (journal は許容なし)",
    }


def paper_writing_analyze_sentences(text: str, max_len: int = 80) -> dict:
    """文長分析 (和文)。journal では長文を避けて読みやすさ重視。

    目標: 平均 <= 60 字 / 文 (journal は grant 申請書より厳しめ)
    警告: 個別で >= 100 字 / 文

    引数:
        text: 解析対象の日本語テキスト
        max_len: 1 文の上限 (既定 80)
    """
    sentences = [s.strip() for s in re.split(r"[。．]", text) if s.strip()]
    if not sentences:
        return {"error": "no sentences found (no 。 or ．)"}
    lengths = [len(s) for s in sentences]
    avg = sum(lengths) / len(lengths)
    long_ones = [
        {"index": i, "length": ln, "head": s[:40] + ("..." if len(s) > 40 else "")}
        for i, (s, ln) in enumerate(zip(sentences, lengths))
        if ln > max_len
    ]
    return {
        "total_sentences": len(sentences),
        "avg_length": round(avg, 1),
        "max_length": max(lengths),
        "threshold": max_len,
        "over_threshold_count": len(long_ones),
        "over_threshold_examples": long_ones[:5],
        "target": f"avg <= 60 (journal), or avg <= {max_len}",
        "warning": "any sentence >= 100",
    }


def paper_writing_count_weak_expressions(text: str) -> dict:
    """弱気修飾語の出現数。journal 論文では conclusion / contribution で
    使うと査読で突っ込まれる (Reviewer 2 trigger)。

    目標: ゼロ (特に Abstract / Contribution 文)
    警告: >= 3 / ページ
    """
    patterns = {
        "と考えられる": r"と考えられ(る|ます)",
        "と思われる": r"と思われ(る|ます)",
        "ではないかと": r"ではないかと",
        "可能性がある": r"可能性が(ある|あります)",
        "示唆される": r"示唆され(る|ます)",
        "期待される": r"期待され(る|ます)",
        "ように思う": r"ように思(う|います|われる)",
        # English weak hedges (ACS / IEEE にも適用)
        "it seems": r"\bit seems\b",
        "might be": r"\bmight be\b",
        "could be": r"\bcould be\b",
        "tends to": r"\btends to\b",
    }
    by_pat: dict[str, int] = {}
    total = 0
    for name, pat in patterns.items():
        n = len(re.findall(pat, text, re.IGNORECASE))
        if n:
            by_pat[name] = n
            total += n
    return {
        "total_weak_expressions": total,
        "by_pattern": by_pat,
        "target": "0 in Abstract/Contribution, <=2 per page elsewhere",
        "warning": ">=3 per page (Reviewer 2 trigger)",
    }


# ------------------------------------------------------------------
# Paper-specific diagnostic tools
# ------------------------------------------------------------------
def paper_writing_validate_abstract_length(text: str,
                                            max_words: int = 250,
                                            max_chars_ja: int = 400) -> dict:
    """Abstract 字数 / 語数が制限内か検証。言語を自動判定。

    参考制限:
        IEEE Transactions: 200 words (structured abstract は 250)
        IEEJ 和文: 400 字
        APS: 250 words
        Elsevier: 200-300 words
    """
    # Crude language detection: if >30% of chars are CJK, treat as Japanese
    cjk = sum(1 for c in text if "぀" <= c <= "ヿ"
              or "一" <= c <= "鿿")
    ja_ratio = cjk / max(1, len(text))
    is_japanese = ja_ratio > 0.3

    if is_japanese:
        n = len(text.replace(" ", "").replace("\n", ""))
        limit = max_chars_ja
        unit = "chars (ja)"
    else:
        n = len(text.split())
        limit = max_words
        unit = "words (en)"

    return {
        "detected_language": "ja" if is_japanese else "en",
        "count": n,
        "unit": unit,
        "limit": limit,
        "within_limit": n <= limit,
        "excess": max(0, n - limit),
        "recommendation": (
            "Abstract は問題提起→手法→結果→意義 の 4 要素で構成。"
            "5-7 文が目安 (IEEE 200 words / IEEJ 400 字)。"
        ),
    }


def paper_writing_check_citation_usage(tex_path: str,
                                        bib_path: str = "") -> dict:
    """TeX 本文中の \\cite{} キーと bib file の entries を突合。
    未使用文献 / 未定義 cite を検出。

    引数:
        tex_path: 論文本体の .tex (メインファイル)
        bib_path: .bib ファイル (省略時は tex_path と同ディレクトリの *.bib)
    """
    p = pathlib.Path(tex_path)
    if not p.exists():
        return {"error": f"tex file not found: {tex_path}"}
    text = p.read_text(encoding="utf-8", errors="replace")

    # Collect all \cite{...} keys (multiple keys in one \cite separated by ,)
    cite_keys: set[str] = set()
    for m in re.finditer(r"\\(?:cite|citep|citet|autocite|parencite)\*?"
                         r"(?:\[[^\]]*\])?\{([^}]+)\}", text):
        for k in m.group(1).split(","):
            k = k.strip()
            if k:
                cite_keys.add(k)

    # Find bib file
    if bib_path:
        bibs = [pathlib.Path(bib_path)]
    else:
        bibs = list(p.parent.glob("*.bib"))
    if not bibs:
        return {
            "error": "no .bib file found (pass bib_path= or place *.bib next to tex)"
        }

    bib_entries: set[str] = set()
    for bp in bibs:
        btext = bp.read_text(encoding="utf-8", errors="replace")
        for m in re.finditer(r"@\w+\s*\{\s*([^,\s]+)", btext):
            bib_entries.add(m.group(1))

    missing_in_bib = cite_keys - bib_entries  # cited but not in bib
    unused_in_tex = bib_entries - cite_keys   # in bib but not cited

    return {
        "tex_file": str(p),
        "bib_files": [str(b) for b in bibs],
        "total_citations": len(cite_keys),
        "total_bib_entries": len(bib_entries),
        "missing_in_bib_count": len(missing_in_bib),
        "missing_in_bib": sorted(missing_in_bib)[:20],
        "unused_in_tex_count": len(unused_in_tex),
        "unused_in_tex": sorted(unused_in_tex)[:20],
        "recommendation": (
            "missing_in_bib があれば .bib に追加。"
            "unused_in_tex が 5 件以上ある場合は refs を整理 "
            "(実際に論じていない文献の引用は査読者に嫌われる)。"
        ),
    }


def paper_writing_check_english_redflags(text: str) -> dict:
    """英文論文の典型的 red flag を検出 (冠詞、時制、自動詞/他動詞 の混同)。

    NOTE: 網羅的ではなく高頻度パターンのみ。通った後も native proof は
          推奨。
    """
    issues: list[dict] = []

    # Definite/indefinite article mis-use signals (limited heuristics)
    if re.search(r"\bIn the (paper|study|work)\b", text):
        issues.append({
            "pattern": "In the paper/study/work (without first reference)",
            "hint": "初出は 'In this paper/study/work'。'the' は既知物に限る。",
        })
    # Tense consistency (past result + present claim is fine, but all-past in
    # discussion is weak)
    # "will be" in future-work without section header
    if re.search(r"\bwe will\b", text, re.IGNORECASE):
        count = len(re.findall(r"\bwe will\b", text, re.IGNORECASE))
        issues.append({
            "pattern": f"'we will' appears {count} times",
            "hint": "Future work 以外では使わない。Method は過去形または現在形 で記述。",
        })
    # "Please refer to"
    if re.search(r"\bPlease refer to\b", text, re.IGNORECASE):
        issues.append({
            "pattern": "Please refer to",
            "hint": "論文調ではない。'See Section X' or 'Fig. Y shows ...' に置換。",
        })
    # "In order to" (can almost always be just "to")
    n_io = len(re.findall(r"\bIn order to\b", text, re.IGNORECASE))
    if n_io >= 3:
        issues.append({
            "pattern": f"'In order to' appears {n_io} times",
            "hint": "almost always replaceable with just 'to'. 冗長表現。",
        })
    # Capital after semicolon (subtle bug)
    if re.search(r";\s+[A-Z][a-z]", text):
        issues.append({
            "pattern": "Capital letter after semicolon",
            "hint": "セミコロン後は小文字が標準。'; However, ...' は '. However, ...' へ。",
        })
    # "which is" / "that is" redundancy
    n_wi = len(re.findall(r"\bwhich is\b", text, re.IGNORECASE))
    if n_wi >= 5:
        issues.append({
            "pattern": f"'which is' appears {n_wi} times",
            "hint": "'the coil, which is made of copper' -> 'the copper coil' が簡潔。",
        })
    # Passive voice over-use
    passive_count = len(re.findall(
        r"\b(is|are|was|were|been|being)\s+\w+ed\b", text))
    total_verbs_est = len(re.findall(r"\b\w+ed\b", text)) + 1
    passive_ratio = passive_count / total_verbs_est
    if passive_ratio > 0.4:
        issues.append({
            "pattern": f"High passive voice ratio ({passive_ratio:.0%})",
            "hint": "Method は passive 可だが Discussion/Contribution は active 推奨。",
        })

    return {
        "total_issues": len(issues),
        "issues": issues,
        "note": (
            "Heuristic のみ。最終的には native proof (IEEE Author Tools / "
            "DeepL Write / Grammarly Pro) を併用。"
        ),
    }


# ------------------------------------------------------------------
# Deep-learning diagnostic tools (from アクセプト術 2026-04-21 upgrade)
# ------------------------------------------------------------------

_BANNED_INTRO_OPENERS = [
    r"^\s*In this (paper|section|study|work|chapter)",
    r"^\s*This (paper|section|study|work) (presents|describes|deals)",
    r"^\s*Recent advances in",
    r"^\s*The last few years (have seen|has seen)",
    r"^\s*It is (well[- ]known|often said)",
    r"^\s*There (is|are) (many|several|a number)",
    r"^\s*First(ly)?\s*,",
    r"^\s*Several studies",
    r"^\s*Many (authors|researchers)",
]


def paper_writing_check_paragraph_opener(text: str) -> dict:
    """Introduction/Abstract の段落冒頭が禁断フレーズで始まるか検出。

    Wallwork §13.15, §14.11 のブラックリスト:
    - "In this paper, ..."
    - "Recent advances in ..."
    - "The last few years ..."
    - "It is well-known that ..."
    - "Several studies ..."

    目標: 0 (特に Abstract + Introduction の最初の段落)
    警告: >=2 / section
    """
    # Split paragraphs by blank lines
    paragraphs = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    flagged: list[dict] = []
    for i, para in enumerate(paragraphs, start=1):
        first_line = para.split("\n", 1)[0]
        for pat in _BANNED_INTRO_OPENERS:
            if re.match(pat, first_line, re.IGNORECASE):
                flagged.append({
                    "paragraph_index": i,
                    "pattern": pat,
                    "head": first_line[:80],
                })
                break
    return {
        "total_paragraphs": len(paragraphs),
        "weak_opener_count": len(flagged),
        "flagged": flagged[:10],
        "target": "0 in Abstract/Intro opening paragraphs",
        "warning": ">=2 in a single section",
        "source": "Wallwork §13.15, §14.11",
    }


def paper_writing_check_paragraph_length(text: str,
                                          min_chars_ja: int = 150,
                                          max_chars_ja: int = 400,
                                          min_words_en: int = 75,
                                          max_words_en: int = 175,
                                          ) -> dict:
    """段落の字数/語数が適正範囲内か検出。

    目標:
        EN: 75-175 words/段落 (Wallwork §14.9)
        JP: 150-400 字/段落
    警告: >200 words / >500 字
    致命: >300 words / >800 字、または Introduction が 1 段落のみ

    引数:
        text: 複数段落の本文 (空行で区切る)
    """
    paragraphs = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]

    def _is_japanese(s):
        cjk = sum(1 for c in s if "一" <= c <= "鿿" or "぀" <= c <= "ヿ")
        return cjk / max(1, len(s)) > 0.3

    lang_ja = _is_japanese(text)
    vmin = min_chars_ja if lang_ja else min_words_en
    vmax = max_chars_ja if lang_ja else max_words_en
    unit = "chars (ja)" if lang_ja else "words (en)"

    stats = []
    for i, para in enumerate(paragraphs, start=1):
        if lang_ja:
            n = len(para.replace(" ", "").replace("\n", ""))
        else:
            n = len(para.split())
        stats.append({"paragraph": i, "count": n,
                      "within": vmin <= n <= vmax})
    over_count = sum(1 for s in stats if s["count"] > vmax)
    way_over = sum(1 for s in stats if s["count"] > vmax * 1.5)
    under_count = sum(1 for s in stats if s["count"] < vmin)

    too_few_paragraphs = len(paragraphs) == 1 and sum(
        s["count"] for s in stats
    ) > vmin * 2

    return {
        "total_paragraphs": len(paragraphs),
        "language": "ja" if lang_ja else "en",
        "unit": unit,
        "target_range": f"{vmin}-{vmax} {unit}",
        "over_warn": over_count,
        "over_fatal": way_over,
        "under": under_count,
        "single_giant_paragraph": too_few_paragraphs,
        "per_paragraph": stats[:20],
        "source": "Wallwork §14.9",
    }


def paper_writing_check_abstract_background_ratio(abstract: str) -> dict:
    """Abstract 内で background (導入文) が占める割合を推定。

    Wallwork §13.16: >25% background は日本型 abstract で editor が reject。

    推定法: 第 1 文から順に、動詞に 'we'/'our' が無く数値結果が無い文を
    "background" として分類。数値 or 能動的動詞 (we propose/show/
    demonstrate/find/report) が出現した文から "content" に切替。

    Args:
        abstract: Abstract 本文のみ。
    """
    if not abstract.strip():
        return {"error": "abstract is empty"}
    # Split sentences: handle both .  and 。
    sentences = re.split(r"(?<=[.。])\s+", abstract.strip())
    sentences = [s for s in sentences if s.strip()]
    if not sentences:
        return {"error": "no sentences found"}

    background_chars = 0
    total_chars = 0
    break_index = None
    for i, s in enumerate(sentences):
        total_chars += len(s)
        has_digit = bool(re.search(r"\d", s))
        has_agent = bool(re.search(
            r"\b(we|our|I)\s+(propose|show|demonstrate|find|"
            r"report|present|develop|derive|measure|compare|"
            r"introduce)\b", s, re.IGNORECASE))
        if break_index is None:
            if has_digit or has_agent:
                break_index = i
            else:
                background_chars += len(s)

    ratio = background_chars / max(1, total_chars)
    return {
        "total_sentences": len(sentences),
        "background_break_index": break_index,
        "background_chars": background_chars,
        "total_chars": total_chars,
        "background_ratio": round(ratio, 3),
        "target": "<= 0.25 (Wallwork §13.16)",
        "warning": "> 0.25 (Japanese-style abstract)",
        "fatal": "> 0.40 (near-certain reject)",
    }


def paper_writing_check_figure_caption_showing(caption: str) -> dict:
    """Figure caption が showing (describe) 形か telling (claim) 形か判定。

    Wallwork §17.9: "Figure 4 shows X" (NG) より "X was observed (Fig. 4)"
    (OK)。caption の主語が figure ではなく主張動詞。

    Args:
        caption: 1 つの figure caption テキスト (Fig. 番号から末尾まで)
    """
    cap = caption.strip()
    if not cap:
        return {"error": "caption is empty"}

    # Detect "Fig. N shows/illustrates/presents ..." pattern
    tells = re.search(
        r"^(?:Fig(?:ure)?\.?\s*\d+)?\.?\s*"
        r"(shows|illustrates|presents|depicts|gives|describes)",
        cap, re.IGNORECASE
    )

    return {
        "caption_head": cap[:80],
        "is_showing_form": bool(tells),
        "recommendation": (
            "Convert to 'claim + (Fig. N)' form. "
            "NG: 'Figure 4 shows the relationship between A and B.' "
            "OK: 'The abundances of A and B were inversely related (Fig. 4).'"
        ) if tells else "OK: caption opens with a claim, not a describe verb.",
        "source": "Wallwork §17.9",
    }


def paper_writing_check_strong_adjective_budget(text: str) -> dict:
    """強調副詞/形容詞の過剰使用を検出。

    Wallwork §8.12: 2 個超で "hype" 判定、reader が信頼感を失う。

    目標: 全体で 2 個以内 (Abstract + Intro で 1-2 個 max)
    警告: 5 個超
    """
    patterns = {
        "remarkably": r"\bremarkably\b",
        "notably": r"\bnotably\b",
        "importantly": r"\bimportantly\b",
        "interestingly": r"\binterestingly\b",
        "novel": r"\bnovel\b",
        "innovative": r"\binnovative\b",
        "cutting-edge": r"\bcutting[- ]edge\b",
        "state-of-the-art": r"\bstate[- ]of[- ]the[- ]art\b",
        "crucial": r"\bcrucial\b",
        "groundbreaking": r"\bgroundbreaking\b",
        "significantly": r"\bsignificantly\b",
        "substantially": r"\bsubstantially\b",
    }
    by_pat = {}
    total = 0
    for name, pat in patterns.items():
        n = len(re.findall(pat, text, re.IGNORECASE))
        if n:
            by_pat[name] = n
            total += n
    return {
        "total_strong_adjectives": total,
        "by_adjective": by_pat,
        "target": "<=2 overall (Wallwork §8.12)",
        "warning": ">=5 overall",
        "note": (
            "Strong modifiers above threshold signal hype. Replace with "
            "quantitative claims: 'substantially faster' -> '3.2x faster "
            "(Table II)'."
        ),
    }


