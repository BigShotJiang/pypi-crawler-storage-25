"""grant_writing sub-module — 申請書の作文技術."""
from . import tools as _tools


def register(mcp) -> int:
    """Register grant_writing_* tools with the given FastMCP instance.

    Returns the number of tools registered.
    """
    count = 0
    for name in dir(_tools):
        if name.startswith("grant_writing_") and callable(getattr(_tools, name)):
            mcp.tool()(getattr(_tools, name))
            count += 1
    return count
