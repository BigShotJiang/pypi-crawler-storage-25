"""Tool functions for the presentation domain of mcp-server-document.

All functions are plain callables; they get wrapped by @mcp.tool()
in the top-level server.py. No FastMCP import here (that would
accidentally register a second MCP server).
"""

from __future__ import annotations

import pathlib
import re


_HERE = pathlib.Path(__file__).resolve().parent
KNOWLEDGE = _HERE


def _load_skill() -> str:
    return (KNOWLEDGE / "skill.md").read_text(encoding="utf-8")


# ------------------------------------------------------------------
# Knowledge loader
# ------------------------------------------------------------------
def presentation_usage() -> str:
    """学会発表スライド (IEEJ SA / IEEE conference / セミナー) の作文技術ガイド全体。

    高橋メソッド, Garr Reynolds 流, 横徹流の統合。時間配分、Hook,
    key message 1 枚 1 主張, PDF 印刷耐性, Q&A 準備, 動画収録対応等。

    呼び出しタイミング:
    - 学会発表 (IEEJ SA / IEEE / APS) のドラフト review
    - 「スライドが読めない」「情報が多すぎ」feedback 対応
    - 時間配分 / storyboarding の相談
    - beamer / pptx の overfull / 字数チェック
    - Q&A 想定問答の整理

    活動ツール (実測) は以下を併用:
    - presentation_count_underlines(tex_path)
    - presentation_validate_pdf_pages(pdf_path, max)
    - presentation_check_overfull_hbox(log_path)
    - presentation_analyze_sentences(text, max_len)
    - presentation_count_weak_expressions(text)
    - presentation_count_slides(input_path)      — beamer frame / pptx slide 数
    - presentation_estimate_speaking_time(text, wpm) — 発表時間推定
    - presentation_check_slide_density(text, max_chars) — 1 枚あたり字数
    """
    return _load_skill()


# ------------------------------------------------------------------
# Shared diagnostic tools (copy from grant-writing pattern)
# ------------------------------------------------------------------
def presentation_count_underlines(tex_path: str) -> dict:
    """beamer ソース内の下線コマンドを実測。

    目標: 1-3 per slide (key number のみ下線)
    警告: スライド全体で >=20 (頻用しすぎ)
    """
    p = pathlib.Path(tex_path)
    if not p.exists():
        return {"error": f"file not found: {tex_path}"}
    text = p.read_text(encoding="utf-8", errors="replace")
    macros = ["uline", "underline", "uwave", "uuline",
              "sout", "dashuline", "dotuline", "alert"]
    by_macro: dict[str, int] = {}
    total = 0
    for m in macros:
        n = len(re.findall(r"\\" + m + r"\{", text))
        if n:
            by_macro[m] = n
            total += n
    return {
        "file": str(p),
        "total_emphasis": total,
        "by_macro": by_macro,
        "target_range": "1-3 per slide (key number only)",
        "warning_threshold": ">=20 total",
    }


def presentation_validate_pdf_pages(pdf_path: str,
                                     max_pages: int) -> dict:
    """スライド PDF のページ数を実測。発表時間 / slot との整合を検証。

    参考 (1 page = 1 slide):
        20 min talk: 10-15 slides (タイトル + 結論含む)
        30 min talk: 15-25 slides
        60 min talk: 30-45 slides
        高橋メソッド: 大字 1 word per slide は 60 slides/30min 可
    """
    try:
        import pymupdf  # type: ignore
    except ImportError:
        return {"error": "pymupdf not installed. `pip install pymupdf`"}
    p = pathlib.Path(pdf_path)
    if not p.exists():
        return {"error": f"file not found: {pdf_path}"}
    doc = pymupdf.open(pdf_path)
    n = doc.page_count
    doc.close()
    return {
        "file": str(p),
        "page_count": n,
        "max_pages": max_pages,
        "within_limit": n <= max_pages,
        "pages_over": max(0, n - max_pages),
        "estimated_time_min": {
            "conservative (2 min/slide)": round(n * 2, 1),
            "moderate (1.5 min/slide)": round(n * 1.5, 1),
            "fast (1 min/slide)": round(n * 1.0, 1),
            "takahashi (0.5 min/slide)": round(n * 0.5, 1),
        },
    }


def presentation_check_overfull_hbox(log_path: str) -> dict:
    """beamer ログ中の Overfull \\hbox をカウント。スライドでは致命的。

    目標: 0。overflow があると図が切れる / 文字がはみ出す。
    """
    p = pathlib.Path(log_path)
    if not p.exists():
        return {"error": f"file not found: {log_path}"}
    text = p.read_text(encoding="utf-8", errors="replace")
    matches = re.findall(
        r"Overfull \\hbox \(([^)]+)\) in paragraph at lines (\d+)(?:--(\d+))?",
        text,
    )
    details = [
        {"severity": m[0], "lines": m[1] + (f"-{m[2]}" if m[2] else "")}
        for m in matches[:20]
    ]
    return {
        "file": str(p),
        "overfull_count": len(matches),
        "overfull_details": details,
        "target": "0 (beamer は overflow で致命的)",
    }


def presentation_analyze_sentences(text: str, max_len: int = 30) -> dict:
    """文長分析。スライドは短文指向。

    目標: 平均 <=20 字 / 文 (高橋メソッド系), <=30 字 (standard)
    警告: >=50 字 / 文 (読まれない)

    引数:
        text: 解析対象 (スライド 1 枚ぶんのテキスト)
        max_len: 1 文上限 (既定 30)
    """
    sentences = [s.strip() for s in re.split(r"[。．\n]", text) if s.strip()]
    if not sentences:
        return {"error": "no sentences found (no 。 or ．)"}
    lengths = [len(s) for s in sentences]
    avg = sum(lengths) / len(lengths)
    long_ones = [
        {"index": i, "length": ln, "head": s[:30] + ("..." if len(s) > 30 else "")}
        for i, (s, ln) in enumerate(zip(sentences, lengths))
        if ln > max_len
    ]
    return {
        "total_sentences": len(sentences),
        "avg_length": round(avg, 1),
        "max_length": max(lengths),
        "threshold": max_len,
        "over_threshold_count": len(long_ones),
        "over_threshold_examples": long_ones[:5],
        "target": f"avg <= {max_len} (slide short-form)",
        "warning": "any sentence >= 50 字",
    }


def presentation_count_weak_expressions(text: str) -> dict:
    """弱気修飾語の出現。presentation では key slide 上で使うと信頼感低下。

    目標: key slide (contribution / result) は 0
    警告: >=2 / スライド
    """
    patterns = {
        "と考えられる": r"と考えられ(る|ます)",
        "と思われる": r"と思われ(る|ます)",
        "かもしれない": r"かもしれ(ない|ません)",
        "だろう": r"だろう|でしょう",
        "ではないか": r"ではないか",
        "可能性": r"可能性が(ある|あります)",
        "示唆": r"示唆され(る|ます)",
        "期待": r"期待され(る|ます)",
    }
    by_pat: dict[str, int] = {}
    total = 0
    for name, pat in patterns.items():
        n = len(re.findall(pat, text))
        if n:
            by_pat[name] = n
            total += n
    return {
        "total_weak_expressions": total,
        "by_pattern": by_pat,
        "target": "0 on key slides (contribution / result)",
        "warning": ">=2 per slide",
    }


# ------------------------------------------------------------------
# Slide-specific diagnostic tools
# ------------------------------------------------------------------
def presentation_count_slides(input_path: str) -> dict:
    """スライド数を count。beamer (.tex) の \\begin{frame} か、
    pptx の slide count を自動判定。

    引数:
        input_path: .tex (beamer) または .pptx のパス
    """
    p = pathlib.Path(input_path)
    if not p.exists():
        return {"error": f"file not found: {input_path}"}
    suffix = p.suffix.lower()

    if suffix == ".tex":
        text = p.read_text(encoding="utf-8", errors="replace")
        # \begin{frame} ... or \frame{...} both supported
        frames = len(re.findall(r"\\begin\{frame\}", text))
        short_frames = len(re.findall(r"\\frame\b", text)) - frames
        total = frames + max(0, short_frames)
        return {
            "file": str(p),
            "format": "beamer",
            "frame_environments": frames,
            "short_frame_calls": max(0, short_frames),
            "total_slides": total,
        }

    if suffix == ".pptx":
        try:
            import pptx  # type: ignore
        except ImportError:
            return {"error": "python-pptx not installed. `pip install python-pptx`"}
        prs = pptx.Presentation(str(p))
        return {
            "file": str(p),
            "format": "pptx",
            "total_slides": len(prs.slides),
            "layouts": [s.slide_layout.name for s in prs.slides][:30],
        }

    return {"error": f"unsupported format: {suffix} (expected .tex or .pptx)"}


def presentation_estimate_speaking_time(text: str,
                                         wpm_ja: int = 300,
                                         wpm_en: int = 130) -> dict:
    """原稿テキストから発表時間を推定。

    日本語: 300 字/分 (学会のあっさり目発表) ~ 400 字/分 (速い講演)
    英語: 130 words/min (standard) ~ 150 words/min (native fast)

    引数:
        text: 発表原稿全体
        wpm_ja: 1 分あたりの字数 (日本語)
        wpm_en: 1 分あたりの語数 (英語)
    """
    cjk = sum(1 for c in text if "぀" <= c <= "ヿ" or "一" <= c <= "鿿")
    ja_ratio = cjk / max(1, len(text))
    is_japanese = ja_ratio > 0.3

    if is_japanese:
        n = len(text.replace(" ", "").replace("\n", ""))
        minutes = n / wpm_ja
        unit = f"{n} 字 / {wpm_ja} 字/分"
    else:
        words = len(text.split())
        minutes = words / wpm_en
        unit = f"{words} words / {wpm_en} wpm"

    return {
        "detected_language": "ja" if is_japanese else "en",
        "count_or_words": (len(text) if is_japanese else len(text.split())),
        "estimated_minutes": round(minutes, 2),
        "detail": unit,
        "hint": (
            "20-min talk = 300 字×20 = 6000 字 (ja) / 130×20 = 2600 words (en)。"
            " 質疑 5 分を別枠で確保する前提。"
        ),
    }


def presentation_check_slide_density(text: str,
                                      max_chars_per_slide: int = 80) -> dict:
    """1 スライドあたりの文字密度チェック (テキストを直接渡す)。

    目標: <= 80 字 / slide (標準) or <= 20 字 / slide (高橋メソッド)
    警告: >= 150 字 / slide (読まれない)

    引数:
        text: 1 スライドの内容 (短いブロックを想定)
        max_chars_per_slide: 閾値 (既定 80)
    """
    n = len(text.replace(" ", "").replace("\n", ""))
    over = n - max_chars_per_slide
    return {
        "char_count": n,
        "threshold": max_chars_per_slide,
        "within_limit": n <= max_chars_per_slide,
        "chars_over": max(0, over),
        "recommendation": (
            "高橋メソッド: 20 字以下 (大字・1 スライド 1 主張)。 "
            "standard: 80 字以下 (本文 + bullet)。 "
            "150 字以上は「読まれないスライド」。"
        ),
    }


def presentation_extract_pptx_text(pptx_path: str) -> dict:
    """pptx の各 slide のテキストを抽出。密度チェックや文字起こしに。

    note: python-pptx 依存。画像内の文字は拾えない (OCR 不要時のみ)。
    """
    try:
        import pptx  # type: ignore
    except ImportError:
        return {"error": "python-pptx not installed. `pip install python-pptx`"}
    p = pathlib.Path(pptx_path)
    if not p.exists():
        return {"error": f"file not found: {pptx_path}"}
    prs = pptx.Presentation(str(p))
    slides_text = []
    for i, slide in enumerate(prs.slides, start=1):
        texts: list[str] = []
        for shape in slide.shapes:
            if shape.has_text_frame:
                for para in shape.text_frame.paragraphs:
                    for run in para.runs:
                        if run.text.strip():
                            texts.append(run.text)
        joined = "\n".join(texts)
        slides_text.append({
            "slide": i,
            "layout": slide.slide_layout.name,
            "char_count": len(joined.replace(" ", "").replace("\n", "")),
            "text_preview": joined[:200] + ("..." if len(joined) > 200 else ""),
        })
    return {
        "file": str(p),
        "total_slides": len(prs.slides),
        "slides": slides_text,
    }


# ------------------------------------------------------------------
# Deep-learning diagnostic tools (from 作図力学 + 木下 講演章)
# ------------------------------------------------------------------

def presentation_check_slide_line_count(pptx_path: str,
                                         max_horiz_lines: int = 8,
                                         max_vert_lines: int = 12,
                                         ) -> dict:
    """pptx の各 slide で text 行数が木下推奨の範囲内か検証。

    木下『理科系の作文技術』p.227: 横向き slide なら 8 行、縦向き slide
    なら 12 行を上限にせよ。これを超えると文字が小さくなりすぎる。

    Args:
        pptx_path: .pptx
        max_horiz_lines: 横 slide の行数上限 (既定 8)
        max_vert_lines: 縦 slide の行数上限 (既定 12)
    """
    try:
        import pptx  # type: ignore
    except ImportError:
        return {"error": "python-pptx not installed. `pip install python-pptx`"}
    p = pathlib.Path(pptx_path)
    if not p.exists():
        return {"error": f"file not found: {pptx_path}"}
    prs = pptx.Presentation(str(p))
    # Determine orientation from slide size
    w = prs.slide_width
    h = prs.slide_height
    is_horiz = w >= h
    limit = max_horiz_lines if is_horiz else max_vert_lines
    violations: list[dict] = []
    for i, slide in enumerate(prs.slides, start=1):
        lines = 0
        for shape in slide.shapes:
            if shape.has_text_frame:
                for para in shape.text_frame.paragraphs:
                    text = "".join(run.text for run in para.runs)
                    if text.strip():
                        lines += 1
        if lines > limit:
            violations.append({"slide": i, "lines": lines, "limit": limit})
    return {
        "file": str(p),
        "orientation": "horizontal" if is_horiz else "vertical",
        "line_limit": limit,
        "total_slides": len(prs.slides),
        "violations": violations[:20],
        "violation_count": len(violations),
        "source": "木下『理科系の作文技術』p.227",
    }


def presentation_check_hedge_on_key_slides(pptx_path: str) -> dict:
    """pptx で Result / Conclusion / Summary スライドに弱気修飾語が
    含まれていないかチェック。木下 p.235 のズバリ話法。

    key slide = title が Result/Conclusion/Summary/まとめ/結論/結果
    を含むもの。

    弱気リスト: ようです、らしい、かもしれません、ではなかろうか、
    と思われる、と考えられる、だろう、でしょう、のようだ、と見られる
    """
    try:
        import pptx  # type: ignore
    except ImportError:
        return {"error": "python-pptx not installed. `pip install python-pptx`"}
    p = pathlib.Path(pptx_path)
    if not p.exists():
        return {"error": f"file not found: {pptx_path}"}
    prs = pptx.Presentation(str(p))

    key_title_pat = re.compile(
        r"(result|conclusion|summary|take.?home|まとめ|結論|結果|考察)",
        re.IGNORECASE)
    hedge_patterns = [
        (r"ようです", "ようです"),
        (r"らしい", "らしい"),
        (r"かもしれ(ない|ません)", "かもしれない"),
        (r"ではな(かろうか|いでしょうか)", "ではなかろうか"),
        (r"と(思われ|考えられ|見られ)(る|ます)", "〜と考えられる"),
        (r"だろう|でしょう", "だろう"),
        (r"ようだ[。、]", "ようだ"),
        (r"と見てよい", "と見てよい"),
    ]

    issues: list[dict] = []
    for i, slide in enumerate(prs.slides, start=1):
        # Extract slide title (first text frame with placeholder idx 0
        # or the first shape's first paragraph)
        title_text = ""
        body_text_parts: list[str] = []
        for shape in slide.shapes:
            if not shape.has_text_frame:
                continue
            text = shape.text_frame.text
            if not title_text and text.strip():
                title_text = text.splitlines()[0]
            body_text_parts.append(text)
        body = "\n".join(body_text_parts)
        if not key_title_pat.search(title_text):
            continue
        # Scan body for hedges
        for pat, label in hedge_patterns:
            ms = re.findall(pat, body)
            if ms:
                issues.append({
                    "slide": i,
                    "title": title_text[:60],
                    "hedge": label,
                    "count": len(ms),
                })
    return {
        "file": str(p),
        "total_slides": len(prs.slides),
        "key_slide_hedge_issues": issues[:30],
        "issue_count": len(issues),
        "target": "0 hedges on Result/Conclusion slides",
        "source": "木下『理科系の作文技術』p.235",
    }


def presentation_check_script_paragraph_length(script: str,
                                                 min_chars: int = 150,
                                                 max_chars: int = 350,
                                                 ) -> dict:
    """発表原稿の 1 パラグラフが 200-300 字目安から大きく外れていないか。

    木下 p.225 + まんが p.158: 「区切りの明確なパラグラフを 200-300 字で
    十分考えて配列した原稿ができあがれば、その講演は半ば成功」

    Args:
        script: 発表原稿 (空行で段落区切り)
        min_chars: 下限 (既定 150)
        max_chars: 上限 (既定 350)
    """
    paragraphs = [p.strip() for p in re.split(r"\n\s*\n", script) if p.strip()]
    out: list[dict] = []
    for i, para in enumerate(paragraphs, start=1):
        n = len(para.replace(" ", "").replace("\n", ""))
        within = min_chars <= n <= max_chars
        if not within:
            out.append({"paragraph": i, "chars": n,
                        "head": para[:40] + ("..." if len(para) > 40 else "")})
    return {
        "total_paragraphs": len(paragraphs),
        "target_range": f"{min_chars}-{max_chars} chars",
        "violation_count": len(out),
        "violations": out[:15],
        "allow_ratio": f"up to 10% of paragraphs outside range",
        "source": "木下 p.225 / まんが p.158",
    }


def presentation_check_over_politeness(script: str) -> dict:
    """学会発表で過剰に丁寧な言い回しを検出。木下 p.235。

    学会は平等な場。「報告させていただきます」「であります」等は
    緊張の signal として聴衆に取られる。
    """
    patterns = {
        "報告させていただきます": r"報告させていただきま(す|した)",
        "発表させていただきます": r"発表させていただきま(す|した)",
        "であります": r"であります",
        "と思わせていただきます": r"と思わせていただき",
        "お話させていただきます": r"お話させていただきま",
        "〜させていただきたい": r"させていただ(きたい|こう)",
        "申し上げます": r"申し上げ(ます|たい)",
    }
    by_pat = {}
    total = 0
    for name, pat in patterns.items():
        n = len(re.findall(pat, script))
        if n:
            by_pat[name] = n
            total += n
    return {
        "total_over_polite": total,
        "by_pattern": by_pat,
        "target": "0 (学会 は 平等)",
        "recommendation": (
            "「報告させていただきます」→「報告します」、"
            "「であります」→「です」。"
            "学会は立場を対等と扱う場。過剰な丁寧は緊張の signal。"
        ),
        "source": "木下『理科系の作文技術』p.235",
    }


def presentation_check_time_13_rule(script: str,
                                     slot_min: float = 20.0,
                                     wpm_ja: int = 240,
                                     ) -> dict:
    """木下 1/3 則 — 前半で全員わかる話、中盤で大半が分かった気、
    後半で専門家向け、の layering が script に表れているか。

    簡易判定: script を 3 等分し、各 block 内の「専門用語密度」を比較。
    前 1/3 の専門用語密度 < 中 1/3 < 後 1/3 であれば layering 済。

    Args:
        script: 発表原稿
        slot_min: 持ち時間 (1/3 則の spacing 確認用)
        wpm_ja: 字数/分 (木下 学会は 240)
    """
    chars = list(script.replace("\n", " "))
    if not chars:
        return {"error": "script is empty"}
    third = len(chars) // 3
    blocks = [
        "".join(chars[:third]),
        "".join(chars[third:2 * third]),
        "".join(chars[2 * third:]),
    ]
    # Simplified specialist-marker density: count katakana runs >=4 chars
    # (concept names), digits + units ("kHz", "mT"), equations
    def _density(s):
        katakana = len(re.findall(r"[ァ-ヴー]{4,}", s))
        units = len(re.findall(r"\d+[.]?\d*\s*(kHz|mT|mm|V|A|Hz|μm|Ω|T|s)",
                                s))
        equations = len(re.findall(r"[=<>≤≥][ =<>≤≥]?|[\w]_[\w]", s))
        return (katakana + units + equations) / max(1, len(s)) * 1000

    densities = [round(_density(b), 2) for b in blocks]
    layered = densities[0] <= densities[1] <= densities[2]

    return {
        "slot_min": slot_min,
        "wpm_ja": wpm_ja,
        "script_chars": len(script),
        "estimated_minutes": round(len(script) / wpm_ja, 1),
        "block_specialist_densities": densities,
        "layered_correctly": layered,
        "target": "density[前] <= density[中] <= density[後]",
        "source": "木下 1/3 則 p.224",
    }


