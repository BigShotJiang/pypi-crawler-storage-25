"""Tool functions for the diagram sub-module of mcp-server-document.

Exposes the `separate_layers` and `compose_layers` pipeline from the
sibling `excalidraw/src/trace/` directory as MCP tools. The two scripts
are imported lazily so users without opencv/skimage still get the rest
of mcp-server-document's tools without ImportError at server start.
"""
from __future__ import annotations

import json
import pathlib


def _load_skill() -> str:
    """Return the sub-module's skill.md if present, else a short blurb."""
    p = pathlib.Path(__file__).resolve().parent / "skill.md"
    if p.exists():
        return p.read_text(encoding="utf-8")
    return (
        "diagram sub-module: raster-to-Excalidraw pipeline.\n\n"
        "Two main tools:\n"
        "- diagram_separate_layers(image_path, out_dir, k)\n"
        "- diagram_compose_layers(layers_dir, out_path, config_json)\n"
    )


def _locate_trace_scripts() -> pathlib.Path | None:
    """Find the sibling excalidraw/src/trace/ dir (outside the pip package).

    The scripts live in the parent repo alongside the Python package,
    not inside the pip-installed tree. When installed from PyPI, they
    may not be present; in that case the tools return a descriptive
    error.
    """
    # mcp_server_document/diagram/tools.py
    pkg_dir = pathlib.Path(__file__).resolve().parent.parent
    # Try: repo layout = .../01_GitHub/src/mcp_server_document/
    candidates = [
        pkg_dir.parent.parent / "excalidraw" / "src" / "trace",  # editable install in 01_GitHub
        pathlib.Path.cwd() / "excalidraw" / "src" / "trace",
        pathlib.Path.home() / "mcp-server-document" / "excalidraw" / "src" / "trace",
    ]
    for c in candidates:
        if c.is_dir() and (c / "separate_layers.py").is_file():
            return c
    return None


def diagram_usage() -> str:
    """raster→Excalidraw pipeline の使い方と設計思想を返す。

    呼び出しタイミング:
    - 画像 (ロゴ / 手描き図 / 研究イラスト) を Excalidraw のベクター要素に
      変換したい場合
    - 「どのレイヤーがどう分離されるか」を確認したい場合
    - trace 性能が悪く diagnosis したい場合
    """
    return _load_skill()


def diagram_separate_layers(image_path: str,
                             out_dir: str = "",
                             k: int = 5,
                             min_fill_area: int = 500) -> dict:
    """画像を意味的レイヤー PNG に分離する (Step 1 of trace pipeline)。

    入力画像を解析して以下の層を独立 PNG として保存:
      - quantized_k{k}.png: k-means 色量子化版
      - layer_color{0..k-1}_rgb*.png: 色クラスタ毎 (+ white-bg flat 版)
      - layer_bg.png: 近白背景 (マスク)
      - layer_foreground.png: 非背景 全部 (反転、黒FG on 白BG)
      - layer_edges_canny.png: Canny エッジ
      - layer_thin_lines_all.png / _short.png / _long.png: 細線 (短/長分割)
      - layer_thick_fills.png: 大きい塗り潰し領域
      - layer_circles.png: Hough 検出円
      - layer_text_mser.png: MSER text 候補領域
      - layers_overview.png: タイル状まとめビュー (人間確認用)

    Args:
        image_path: 入力ラスター画像 (PNG/JPG)。日本語パス可 (内部で ASCII 化)。
        out_dir: 出力 dir。未指定時は <image_parent>/<stem>_layers/。
        k: 色クラスタ数 (3-10 推奨、既定 5)。
        min_fill_area: thick_fills のピクセル閾値 (既定 500)。

    Returns:
        dict with 'out_dir', 'color_layers' (list), 'binary_layers'.
    """
    trace_dir = _locate_trace_scripts()
    if trace_dir is None:
        return {
            "error": (
                "separate_layers.py not found. Clone "
                "https://github.com/ksugahar/mcp-server-document and "
                "run the tool from within the repo, or set the "
                "`excalidraw/` sibling directory next to the cwd."
            )
        }
    import sys
    sys.path.insert(0, str(trace_dir))
    try:
        # Force fresh load in case of multiple invocations
        if "separate_layers" in sys.modules:
            del sys.modules["separate_layers"]
        from separate_layers import separate  # type: ignore
    except ImportError as exc:
        return {
            "error": f"failed to import separate_layers: {exc}. "
                     "Missing opencv-python / scikit-image?"
        }
    finally:
        sys.path.remove(str(trace_dir))

    src = pathlib.Path(image_path).expanduser()
    if not src.exists():
        return {"error": f"image not found: {src}"}
    if out_dir:
        out = pathlib.Path(out_dir).expanduser()
    else:
        out = src.parent / f"{src.stem}_layers"

    try:
        result = separate(src, out, k=k, min_fill_area=min_fill_area)
    except Exception as exc:
        return {"error": f"{type(exc).__name__}: {exc}"}
    return result


def diagram_compose_layers(layers_dir: str,
                            out_path: str,
                            config_json: str = "",
                            scale: float = 2.0,
                            offset_x: float = 50.0,
                            offset_y: float = 50.0,
                            seed: int = 42) -> dict:
    """レイヤー PNG 群から Excalidraw JSON を合成する (Step 2)。

    separate_layers で生成した dir を入力に取り、各 PNG に対して
    戦略 (fill_contour / skeleton_lines / circles_fit / points ...)
    を適用して .excalidraw 形式に組み立てる。

    Args:
        layers_dir: diagram_separate_layers の出力 dir。
        out_path: 書き出す .excalidraw JSON パス。
        config_json: 戦略設定 JSON 文字列。省略時は default_config_for で
                     自動設定 (thick_fills→fill_contour, thin_long→
                     skeleton_lines, circles→circles_fit 等)。
                     形式:
                       {"layers": [
                         {"filename": "layer_thick_fills.png",
                          "strategy": "fill_contour",
                          "stroke": "#1e3a6a", "fill": "#3388a0",
                          "group": "brain", "min_area": 150},
                         ...
                       ]}
        scale: 座標スケール (既定 2.0)
        offset_x, offset_y: 原点オフセット (既定 50, 50)
        seed: ランダム種 (既定 42、element ID の再現性用)

    Returns:
        dict with 'total_elements', 'per_layer' counts, 'out_path'.
    """
    trace_dir = _locate_trace_scripts()
    if trace_dir is None:
        return {"error": "compose_layers.py not found (see diagram_separate_layers error)"}
    import sys
    sys.path.insert(0, str(trace_dir))
    try:
        for m in ("compose_layers", "separate_layers", "trace_image"):
            if m in sys.modules:
                del sys.modules[m]
        from compose_layers import (  # type: ignore
            compose, default_config_for, to_excalidraw_json,
        )
    except ImportError as exc:
        return {
            "error": f"failed to import compose_layers: {exc}. "
                     "Missing opencv-python / scikit-image?"
        }
    finally:
        sys.path.remove(str(trace_dir))

    ld = pathlib.Path(layers_dir).expanduser()
    if not ld.is_dir():
        return {"error": f"layers_dir not found: {ld}"}

    if config_json.strip():
        try:
            cfg = json.loads(config_json)
        except json.JSONDecodeError as exc:
            return {"error": f"config_json parse error: {exc}"}
    else:
        cfg = default_config_for(ld)

    try:
        elements, summary = compose(
            ld, cfg,
            scale=scale, offset=(offset_x, offset_y), seed=seed,
        )
    except Exception as exc:
        return {"error": f"compose failed: {type(exc).__name__}: {exc}"}

    doc = to_excalidraw_json(elements)
    out_p = pathlib.Path(out_path).expanduser()
    out_p.parent.mkdir(parents=True, exist_ok=True)
    out_p.write_text(json.dumps(doc, ensure_ascii=False), encoding="utf-8")

    return {
        "out_path": str(out_p),
        "total_elements": summary["total_elements"],
        "per_layer": summary["layers"],
        "config_used": cfg,
    }


def diagram_list_strategies() -> dict:
    """compose_layers で使用可能な戦略 6 種の一覧と用途を返す。"""
    return {
        "strategies": {
            "fill_contour": {
                "description": "External contour → solid-filled polygon",
                "best_for": "brain silhouette, logo glyphs, filled text",
                "params": ["stroke", "fill", "group", "min_area", "epsilon"],
            },
            "outline": {
                "description": "Each contour → closed polyline (no fill)",
                "best_for": "coils, rings, outline-only shapes",
                "params": ["stroke", "group", "min_area", "epsilon", "width"],
            },
            "skeleton_lines": {
                "description": "Skeletonize + trace → polylines",
                "best_for": "thin field lines, hand-drawn strokes",
                "params": ["stroke", "group", "min_length", "simplify",
                           "width", "max_lines"],
            },
            "circles_fit": {
                "description": "HoughCircles → ellipses",
                "best_for": "concentric field rings, circular logos",
                "params": ["stroke", "fill", "group", "min_radius",
                           "max_radius", "max_circles"],
            },
            "text_placeholder": {
                "description": "MSER regions → empty text-element stubs",
                "best_for": "text areas needing later manual fill-in",
                "params": ["stroke", "group", "min_area", "min_height"],
            },
            "points": {
                "description": "Small components → tiny filled circles",
                "best_for": "glow nodes, bullet-point dots",
                "params": ["stroke", "fill", "group", "max_area", "min_area"],
            },
        },
        "usage_hint": (
            "Pass a config_json to diagram_compose_layers with a 'layers' "
            "array, each entry specifying filename + strategy + params. "
            "Omit config_json for sensible defaults."
        ),
    }
