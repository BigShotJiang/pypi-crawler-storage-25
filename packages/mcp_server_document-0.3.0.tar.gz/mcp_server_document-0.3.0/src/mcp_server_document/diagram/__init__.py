"""diagram sub-module — raster-to-Excalidraw pipeline.

Exposes 4 MCP tools:
  diagram_usage            — pipeline overview + design notes (skill.md)
  diagram_separate_layers  — image → semantic PNG layers
  diagram_compose_layers   — layer PNGs → single Excalidraw JSON
  diagram_list_strategies  — enumerate the 6 per-layer strategies

The actual CV pipeline (separate_layers.py + compose_layers.py) lives
in the sibling excalidraw/src/trace/ directory for organizational
reasons — they are shared with the Node.js Excalidraw MCP runtime.
Optional dependencies (opencv-python, scikit-image) are needed; install
via `pip install mcp-server-document[full]` or manually.
"""
from . import tools as _tools


def register(mcp) -> int:
    """Register diagram_* tools with the given FastMCP instance."""
    count = 0
    for name in dir(_tools):
        if name.startswith("diagram_") and callable(getattr(_tools, name)):
            mcp.tool()(getattr(_tools, name))
            count += 1
    return count
