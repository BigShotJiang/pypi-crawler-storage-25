"""mcp-server-document — unified MCP server for academic document authoring.

Sub-modules:
  grant_writing  - 科研費 / JSPS / 助成金 申請書
  paper_writing  - Journal papers (IEEE / IEEJ / APS / Elsevier)
  presentation   - Research-talk slides (IEEJ SA / IEEE conference)
  diagram        - Figure / diagram design helpers (planned)

Entry point: `mcp-server-document` console script (stdio MCP transport).
"""

__version__ = "0.1.0"
