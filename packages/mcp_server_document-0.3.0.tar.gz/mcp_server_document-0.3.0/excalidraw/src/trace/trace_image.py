"""trace_image.py — generic raster-to-Excalidraw tracer (v2).

v2 improvements over v1:
  * Smoother silhouette outline (approxPolyDP epsilon halved).
  * Field/polyline stroke color & width sampled from the actual pixels.
  * Neural-node detection: separate "near-white core" pass finds many more
    glowing dots than the old compactness heuristic.
  * Arrowhead detection: when a traced polyline endpoint sits on a dense
    dark-blob (a painted arrow triangle), the element is emitted as
    type="arrow" with endArrowhead="arrow" instead of "line".

Usage (CLI):
    python trace_image.py --image-path SRC
                          [--scale 3.0] [--offset-x 50] [--offset-y 50]
                          [--layers background,fill_blobs,ring_polygons,polylines,bright_dots]
                          [--server-url http://localhost:3000]
                          [--out-json PATH.json]
                          [--clear-canvas]
                          [--min-blob-area 500]
                          [--polyline-simplify 0.6]
                          [--max-polylines 400]
                          [--polyline-width 1.8]
                          [--outline-epsilon 0.0008]
                          [--arrowhead-radius 5]

Invoked by the `trace_image` MCP tool. Every element carries a `groupId`
matching its semantic layer (background/brain/coil/field/neural).

Dependencies: opencv-python, numpy, scikit-image, pillow.
"""
from __future__ import annotations
import argparse
import json
import math
import random
import sys
import time
import urllib.request

import cv2
import numpy as np
from skimage.morphology import skeletonize


# --------------------------------------------------------------------
# Excalidraw element helpers
# --------------------------------------------------------------------
def _rid(rng: random.Random) -> str:
    return "t-" + "".join(rng.choices("abcdefghijklmnop0123456789", k=16))


def _r32(rng: random.Random) -> int:
    return rng.randint(0, 2**31 - 1)


def _base_el(rng: random.Random, now_ms: int, **kw) -> dict:
    e = {
        "id": _rid(rng), "type": "rectangle",
        "x": 0, "y": 0, "width": 1, "height": 1,
        "angle": 0,
        "strokeColor": "#1e1e1e", "backgroundColor": "transparent",
        "fillStyle": "solid", "strokeWidth": 1, "strokeStyle": "solid",
        "roughness": 0, "opacity": 100,
        "groupIds": [], "frameId": None, "roundness": None,
        "seed": _r32(rng), "version": 1, "versionNonce": _r32(rng),
        "isDeleted": False, "boundElements": None, "updated": now_ms,
        "link": None, "locked": False,
    }
    e.update(kw)
    return e


def polyline_el(rng, now_ms, pts, *, stroke, width=1, fill=None,
                closed=False, opacity=100, group=None,
                start_arrow=False, end_arrow=False):
    if len(pts) < 2:
        return None
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    bx, by = min(xs), min(ys)
    rel = [[p[0] - bx, p[1] - by] for p in pts]
    if closed and rel[0] != rel[-1]:
        rel.append(rel[0])
    use_arrow_type = (start_arrow or end_arrow) and not closed
    e = _base_el(rng, now_ms,
                 type=("arrow" if use_arrow_type else "line"),
                 x=bx, y=by,
                 width=max(1, max(xs) - bx),
                 height=max(1, max(ys) - by),
                 strokeColor=stroke,
                 strokeWidth=width,
                 backgroundColor=(fill or "transparent"),
                 fillStyle="solid",
                 opacity=opacity)
    e["points"] = rel
    e["lastCommittedPoint"] = None
    e["startBinding"] = None
    e["endBinding"] = None
    e["startArrowhead"] = "arrow" if start_arrow else None
    e["endArrowhead"]   = "arrow" if end_arrow   else None
    if group:
        e["groupIds"] = [group]
    return e


def circle_el(rng, now_ms, cx, cy, r, *, stroke, fill,
              stroke_w=0, opacity=100, group=None):
    e = _base_el(rng, now_ms,
                 type="ellipse",
                 x=cx - r, y=cy - r, width=2 * r, height=2 * r,
                 strokeColor=stroke, backgroundColor=fill,
                 fillStyle="solid", strokeWidth=stroke_w, opacity=opacity)
    if group:
        e["groupIds"] = [group]
    return e


def rect_el(rng, now_ms, x, y, w, h, *, fill, group=None):
    e = _base_el(rng, now_ms,
                 type="rectangle",
                 x=x, y=y, width=w, height=h,
                 strokeColor=fill, backgroundColor=fill,
                 fillStyle="solid", strokeWidth=0)
    if group:
        e["groupIds"] = [group]
    return e


# --------------------------------------------------------------------
# Skeleton path tracing
# --------------------------------------------------------------------
def _neighbors8(y, x, mask, H, W):
    out = []
    for dy in (-1, 0, 1):
        for dx in (-1, 0, 1):
            if dx == 0 and dy == 0:
                continue
            ny, nx = y + dy, x + dx
            if 0 <= ny < H and 0 <= nx < W and mask[ny, nx]:
                out.append((ny, nx))
    return out


def trace_skeleton_paths(skel_mask):
    H, W = skel_mask.shape
    visited = np.zeros_like(skel_mask, dtype=bool)
    kernel = np.array([[1, 1, 1], [1, 0, 1], [1, 1, 1]], dtype=np.uint8)
    deg = cv2.filter2D((skel_mask > 0).astype(np.uint8), -1, kernel)
    deg = deg * (skel_mask > 0)
    endpoints = list(zip(*np.where(deg == 1)))
    junctions = list(zip(*np.where(deg >= 3)))
    junction_set = set(junctions)
    paths = []

    def walk(start):
        path = [start]
        visited[start] = True
        cur = start
        while True:
            ny, nx = cur
            options = [n for n in _neighbors8(ny, nx, skel_mask, H, W) if not visited[n]]
            if not options:
                break
            options.sort(key=lambda n: abs(n[0] - ny) + abs(n[1] - nx))
            cur = options[0]
            path.append(cur)
            visited[cur] = True
            if cur in junction_set:
                break
        return path

    for ep in endpoints:
        if visited[ep]:
            continue
        p = walk(ep)
        if len(p) >= 3:
            paths.append(p)
    for j in junctions:
        for n in _neighbors8(j[0], j[1], skel_mask, H, W):
            if visited[n]:
                continue
            visited[n] = True
            path = [j, n]
            cur = n
            while True:
                ny, nx = cur
                options = [m for m in _neighbors8(ny, nx, skel_mask, H, W)
                           if not visited[m] and m != j]
                if not options:
                    break
                options.sort(key=lambda m: abs(m[0] - ny) + abs(m[1] - nx))
                cur = options[0]
                path.append(cur)
                visited[cur] = True
                if cur in junction_set:
                    break
            if len(path) >= 3:
                paths.append(path)
    ys, xs = np.where((skel_mask > 0) & ~visited)
    for y, x in zip(ys, xs):
        if visited[y, x]:
            continue
        p = walk((y, x))
        if len(p) >= 3:
            paths.append(p)
    return paths


# --------------------------------------------------------------------
# Arrowhead detection
# --------------------------------------------------------------------
def detect_arrowhead(py, px, fat_mask, skel_mask, *,
                     radius=4, min_extra=14, min_thickness_ratio=2.8):
    """Return True iff a skeleton endpoint likely sits on an arrow-head blob.

    Straight thin lines have near-uniform thickness along their length. An
    arrow-head appears as a short triangular widening right at the tip, so
    in a small neighbourhood around the endpoint the fat-to-skeleton pixel
    ratio spikes above the average.

    We threshold on both the absolute extra-pixel count and the fat/skel
    ratio to avoid false positives from stubby broken skeletons.
    """
    H, W = fat_mask.shape
    y0, y1 = max(0, py - radius), min(H, py + radius + 1)
    x0, x1 = max(0, px - radius), min(W, px + radius + 1)
    fat = int((fat_mask[y0:y1, x0:x1] > 0).sum())
    sk  = int((skel_mask[y0:y1, x0:x1] > 0).sum())
    if sk < 1:
        return False
    extra = fat - sk
    ratio = fat / sk
    return extra >= min_extra and ratio >= min_thickness_ratio


# --------------------------------------------------------------------
# Color sampling
# --------------------------------------------------------------------
def _mean_hex(img, mask):
    if not mask.any():
        return None
    bgr = cv2.mean(img, mask=mask)[:3]
    return "#{:02x}{:02x}{:02x}".format(int(bgr[2]), int(bgr[1]), int(bgr[0]))


def _darken(hex_str, factor=0.55):
    r = int(hex_str[1:3], 16); g = int(hex_str[3:5], 16); b = int(hex_str[5:7], 16)
    return "#{:02x}{:02x}{:02x}".format(
        max(0, int(r * factor)),
        max(0, int(g * factor)),
        max(0, int(b * factor)),
    )


def _bg_mask(hsv):
    return cv2.inRange(hsv, (0, 0, 200), (180, 40, 255))


def _dominant_blob_mask(hsv):
    return cv2.inRange(hsv, (85, 60, 20), (135, 255, 200))


def _orange_mask(hsv):
    return cv2.inRange(hsv, (5, 80, 100), (25, 255, 255))


def _bright_cyan_wide_mask(hsv):
    """Wider cyan — includes both dim lines and bright node glows."""
    return cv2.inRange(hsv, (80, 30, 170), (110, 220, 255))


def _node_core_mask(hsv):
    """Near-white cyan — the bright *cores* of glowing nodes (V high, S low)."""
    return cv2.inRange(hsv, (0, 0, 215), (180, 110, 255))


# --------------------------------------------------------------------
# Core tracer
# --------------------------------------------------------------------
def trace(
    *, image_path, scale=3.0, offset=(50, 50),
    layers=("background", "fill_blobs", "ring_polygons",
            "polylines", "bright_dots"),
    min_blob_area=500,
    polyline_simplify=0.6,
    max_polylines=400,
    polyline_width=1.8,
    outline_epsilon=0.0008,
    arrowhead_radius=5,
    seed=42,
):
    rng = random.Random(seed)
    now_ms = int(time.time() * 1000)
    img = cv2.imread(image_path)
    if img is None:
        raise RuntimeError(f"cannot read image: {image_path}")
    H, W = img.shape[:2]
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    def to_canvas(pt):
        return (pt[0] * scale + offset[0], pt[1] * scale + offset[1])

    elements = []
    summary: dict = {"image_size": [W, H], "layers": {}}

    # -------------------- background --------------------
    if "background" in layers:
        bg = _bg_mask(hsv)
        color = _mean_hex(img, bg) or "#faf6e8"
        elements.append(rect_el(rng, now_ms,
                                offset[0], offset[1],
                                W * scale, H * scale,
                                fill=color, group="background"))
        summary["layers"]["background"] = {"count": 1, "color": color}

    # -------------------- fill_blobs (brain) --------------------
    brain_filled = np.zeros((H, W), dtype=np.uint8)
    blob_color = "#1e6988"
    if "fill_blobs" in layers:
        dark = _dominant_blob_mask(hsv)
        dark = cv2.morphologyEx(dark, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))
        blob_color = _mean_hex(img, dark) or blob_color
        # erode to disconnect thin field lines from brain bulk
        eroded = cv2.erode(dark, np.ones((5, 5), np.uint8), iterations=3)
        num, labels, stats, _ = cv2.connectedComponentsWithStats(eroded, 8)
        seed_mask = np.zeros_like(dark)
        if num > 1:
            k_idx = 1 + max(range(num - 1),
                            key=lambda k: stats[k + 1, cv2.CC_STAT_AREA])
            seed_mask = (labels == k_idx).astype(np.uint8) * 255
        grown = cv2.dilate(seed_mask, np.ones((5, 5), np.uint8), iterations=4)
        blob_mask = cv2.bitwise_and(grown, dark)
        cc, _ = cv2.findContours(blob_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        blob_emitted = 0
        if cc:
            big = max(cc, key=cv2.contourArea)
            if cv2.contourArea(big) >= min_blob_area:
                cv2.drawContours(brain_filled, [big], -1, 255, thickness=cv2.FILLED)
                eps = outline_epsilon * cv2.arcLength(big, True)
                approx = cv2.approxPolyDP(big, eps, True)
                pts = [to_canvas((int(p[0][0]), int(p[0][1]))) for p in approx]
                el = polyline_el(rng, now_ms, pts,
                                 stroke=_darken(blob_color, 0.75),
                                 width=2,
                                 fill=blob_color, closed=True, group="brain")
                if el:
                    elements.append(el)
                    blob_emitted = 1
                    summary["layers"]["fill_blobs"] = {
                        "count": 1, "color": blob_color,
                        "vertices": len(approx),
                    }
        if blob_emitted == 0:
            summary["layers"]["fill_blobs"] = {"count": 0, "color": blob_color}

    # -------------------- ring_polygons (coil) --------------------
    orange_mask = np.zeros((H, W), dtype=np.uint8)
    if "ring_polygons" in layers:
        orange = _orange_mask(hsv)
        orange = cv2.morphologyEx(orange, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))
        orange_mask = orange
        ring_color = _mean_hex(img, orange) or "#d88040"
        ring_stk = _darken(ring_color, 0.4)
        num, labels, stats, _ = cv2.connectedComponentsWithStats(orange, 8)
        rings = 0
        for k in range(1, num):
            if stats[k, cv2.CC_STAT_AREA] < 40:
                continue
            m = (labels == k).astype(np.uint8) * 255
            cc, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
            if not cc:
                continue
            c = max(cc, key=cv2.contourArea)
            eps = 0.003 * cv2.arcLength(c, True)  # slightly smoother rings too
            approx = cv2.approxPolyDP(c, eps, True)
            if len(approx) < 4:
                continue
            pts = [to_canvas((int(p[0][0]), int(p[0][1]))) for p in approx]
            el = polyline_el(rng, now_ms, pts, stroke=ring_stk, width=1,
                             fill=ring_color, closed=True, group="coil")
            if el:
                elements.append(el)
                rings += 1
        summary["layers"]["ring_polygons"] = {"count": rings, "color": ring_color}

    # -------------------- polylines (field lines) --------------------
    if "polylines" in layers:
        dark = _dominant_blob_mask(hsv)
        thin = cv2.bitwise_and(dark, cv2.bitwise_not(brain_filled))
        thin = cv2.bitwise_and(thin, cv2.bitwise_not(orange_mask))
        # Sample actual field color from outside-brain dark pixels, darkened
        # slightly so the strokes read as "ink" not "cream smudge".
        field_sampled = _mean_hex(img, thin) or "#1e3a6a"
        field_color = _darken(field_sampled, 0.85)

        skel = skeletonize(thin > 0).astype(np.uint8)
        n_s, lab_s, stat_s, _ = cv2.connectedComponentsWithStats(skel, 8)
        pruned = np.zeros_like(skel)
        for k in range(1, n_s):
            if stat_s[k, cv2.CC_STAT_AREA] >= 8:
                pruned[lab_s == k] = 1
        paths = trace_skeleton_paths(pruned)
        paths.sort(key=lambda p: -len(p))
        paths = paths[:max_polylines]
        count = 0
        arrowed = 0
        for path in paths:
            arr = np.array([[x, y] for (y, x) in path], dtype=np.int32).reshape(-1, 1, 2)
            if len(arr) < 3:
                continue
            simp = cv2.approxPolyDP(arr, polyline_simplify, False)
            pts = [to_canvas((int(p[0][0]), int(p[0][1]))) for p in simp]
            if len(pts) < 2:
                continue
            # Only probe arrow-heads on paths long enough to be real lines
            if len(path) >= 14:
                sy, sx = path[0]
                ey, ex = path[-1]
                has_s_arrow = detect_arrowhead(sy, sx, thin, pruned * 255,
                                               radius=arrowhead_radius)
                has_e_arrow = detect_arrowhead(ey, ex, thin, pruned * 255,
                                               radius=arrowhead_radius)
            else:
                has_s_arrow = has_e_arrow = False
            el = polyline_el(rng, now_ms, pts, stroke=field_color,
                             width=polyline_width, group="field",
                             start_arrow=has_s_arrow, end_arrow=has_e_arrow)
            if el:
                elements.append(el)
                count += 1
                if has_s_arrow or has_e_arrow:
                    arrowed += 1
        summary["layers"]["polylines"] = {
            "count": count, "arrowed": arrowed,
            "color": field_color, "width": polyline_width,
        }

    # -------------------- bright_dots (neural nodes + circuit lines) --------------------
    if "bright_dots" in layers:
        wide  = _bright_cyan_wide_mask(hsv)
        cores = _node_core_mask(hsv)
        # Constrain to brain interior when we have one
        if brain_filled.any():
            wide  = cv2.bitwise_and(wide,  brain_filled)
            cores = cv2.bitwise_and(cores, brain_filled)
        # cores may over-include the cream background if brain_filled is empty,
        # so exclude low-saturation but don't-touch-brain regions as safety.
        # Sample colors from cores and lines
        node_fill_hex = _mean_hex(img, cores) or "#eafcff"
        line_color    = _mean_hex(img, cv2.bitwise_and(wide, cv2.bitwise_not(cores))) or "#7adcf0"
        # Darken line slightly for ink-on-brain visibility
        line_color    = _darken(line_color, 0.95)

        # Node centers from cores
        num_c, lab_c, stats_c, cents_c = cv2.connectedComponentsWithStats(cores, 8)
        nodes = []
        node_mask = np.zeros_like(cores)
        for k in range(1, num_c):
            a = stats_c[k, cv2.CC_STAT_AREA]
            if a < 1:
                continue
            cx, cy = cents_c[k]
            # Radius derived from area (circle assumption), capped so that
            # glowing halos don't cover neighbouring circuit lines.
            r_px = min(3.0, max(1.4, math.sqrt(a / math.pi) * 1.2))
            nodes.append((cx, cy, r_px))
            node_mask[lab_c == k] = 255

        # Line mask = wide cyan MINUS an expanded node region
        node_dil = cv2.dilate(node_mask, np.ones((3, 3), np.uint8), iterations=2)
        line_only = cv2.bitwise_and(wide, cv2.bitwise_not(node_dil))
        # Skeletonize and trace
        skel2 = skeletonize(line_only > 0).astype(np.uint8)
        n_s, lab_s, stat_s, _ = cv2.connectedComponentsWithStats(skel2, 8)
        pruned2 = np.zeros_like(skel2)
        for k in range(1, n_s):
            if stat_s[k, cv2.CC_STAT_AREA] >= 5:
                pruned2[lab_s == k] = 1
        paths = trace_skeleton_paths(pruned2)
        line_count = 0
        for path in paths:
            arr = np.array([[x, y] for (y, x) in path], dtype=np.int32).reshape(-1, 1, 2)
            if len(arr) < 3:
                continue
            simp = cv2.approxPolyDP(arr, polyline_simplify, False)
            pts = [to_canvas((int(p[0][0]), int(p[0][1]))) for p in simp]
            if len(pts) < 2:
                continue
            el = polyline_el(rng, now_ms, pts, stroke=line_color, width=1.2,
                             opacity=90, group="neural")
            if el:
                elements.append(el)
                line_count += 1

        # Emit node glow + core on top
        glow_color = node_fill_hex
        for (cx, cy, r_px) in nodes:
            cx_c, cy_c = to_canvas((cx, cy))
            rr = max(2.0, r_px * scale)
            # 2 halos (soft glow) then the bright core
            elements.append(circle_el(rng, now_ms, cx_c, cy_c, rr * 2.4,
                                      stroke=glow_color, fill=glow_color,
                                      opacity=16, group="neural"))
            elements.append(circle_el(rng, now_ms, cx_c, cy_c, rr * 1.5,
                                      stroke=glow_color, fill=glow_color,
                                      opacity=34, group="neural"))
            elements.append(circle_el(rng, now_ms, cx_c, cy_c, rr,
                                      stroke=node_fill_hex, fill=node_fill_hex,
                                      opacity=100, group="neural"))

        summary["layers"]["bright_dots"] = {
            "count": len(nodes), "line_count": line_count,
            "color": node_fill_hex,
        }

    summary["total_elements"] = len(elements)
    return elements, summary


# --------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------
def main(argv=None):
    p = argparse.ArgumentParser(description="Raster-to-Excalidraw tracer")
    p.add_argument("--image-path", required=True)
    p.add_argument("--scale", type=float, default=3.0)
    p.add_argument("--offset-x", type=float, default=50)
    p.add_argument("--offset-y", type=float, default=50)
    p.add_argument("--layers", default="background,fill_blobs,ring_polygons,polylines,bright_dots")
    p.add_argument("--min-blob-area", type=float, default=500)
    p.add_argument("--polyline-simplify", type=float, default=0.6)
    p.add_argument("--max-polylines", type=int, default=400)
    p.add_argument("--polyline-width", type=float, default=1.8)
    p.add_argument("--outline-epsilon", type=float, default=0.0008)
    p.add_argument("--arrowhead-radius", type=int, default=5)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--server-url", default=None)
    p.add_argument("--out-json", default=None)
    p.add_argument("--clear-canvas", action="store_true")
    args = p.parse_args(argv)

    layers = tuple(s.strip() for s in args.layers.split(",") if s.strip())
    elements, summary = trace(
        image_path=args.image_path,
        scale=args.scale,
        offset=(args.offset_x, args.offset_y),
        layers=layers,
        min_blob_area=args.min_blob_area,
        polyline_simplify=args.polyline_simplify,
        max_polylines=args.max_polylines,
        polyline_width=args.polyline_width,
        outline_epsilon=args.outline_epsilon,
        arrowhead_radius=args.arrowhead_radius,
        seed=args.seed,
    )

    if args.out_json:
        doc = {
            "type": "excalidraw", "version": 2,
            "source": "mcp_excalidraw.trace_image",
            "elements": elements,
            "appState": {"gridSize": None, "viewBackgroundColor": "#ffffff"},
            "files": {},
        }
        with open(args.out_json, "w", encoding="utf-8") as f:
            json.dump(doc, f, ensure_ascii=False)
        summary["out_json"] = args.out_json

    if args.server_url:
        base = args.server_url.rstrip("/")
        if args.clear_canvas:
            try:
                req = urllib.request.Request(f"{base}/api/elements/clear", method="DELETE")
                urllib.request.urlopen(req, timeout=10).read()
            except Exception as e:
                summary.setdefault("warnings", []).append(f"clear failed: {e}")
        body = json.dumps({"elements": elements}).encode("utf-8")
        req = urllib.request.Request(f"{base}/api/elements/batch",
                                     data=body,
                                     headers={"Content-Type": "application/json"},
                                     method="POST")
        with urllib.request.urlopen(req, timeout=60) as r:
            res = json.loads(r.read())
            summary["posted"] = {"status": r.status, "count": res.get("count")}

    json.dump(summary, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
