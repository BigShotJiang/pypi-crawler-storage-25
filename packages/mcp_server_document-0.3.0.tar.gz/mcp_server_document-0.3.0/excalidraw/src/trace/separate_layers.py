"""separate_layers.py — split a raster image into semantic PNG layers.

Rationale
---------
`trace_image.py` does layer separation implicitly and then emits Excalidraw
elements in one pass. That fails when the HSV thresholds don't match the
input palette. This script is the *preview* / *debug* step: it renders
each extracted layer as its own PNG so the user can eyeball quality before
committing to trace.

Outputs (per input image, into <out_dir>/<stem>/):
    _source.png            — copy of input (for reference)
    quantized_k{K}.png     — k-means color-quantized version
    layer_color_<n>.png    — one PNG per dominant color cluster (transparent bg)
    layer_bg.png           — near-white background mask
    layer_dark.png         — all dark pixels (V<80 OR S<30 & V<150)
    layer_thin_lines.png   — skeletonized thin strokes
    layer_thick_fills.png  — solid filled regions (erosion-dilation large blobs)
    layer_circles.png      — detected circles/rings (Hough circle)
    layer_text.png         — MSER text-like regions (fallback; no OCR)
    layers_overview.png    — tiled grid of all layers + source

Usage:
    python separate_layers.py --image-path SRC [--out-dir DIR] [--k 5]
"""
from __future__ import annotations

import argparse
import pathlib
import shutil
import sys

import cv2
import numpy as np
from skimage.morphology import skeletonize


def _save_transparent(mask_u8: np.ndarray, rgb_source: np.ndarray,
                      out_path: pathlib.Path) -> None:
    """Save a BGR source masked by `mask_u8` with an alpha channel (transparent bg)."""
    bgra = cv2.cvtColor(rgb_source, cv2.COLOR_BGR2BGRA)
    bgra[:, :, 3] = mask_u8
    cv2.imwrite(str(out_path), bgra)


def _save_binary(mask_u8: np.ndarray, out_path: pathlib.Path) -> None:
    cv2.imwrite(str(out_path), mask_u8)


def _flatten_on_white(img_bgr: np.ndarray, mask_u8: np.ndarray) -> np.ndarray:
    """Return BGR image where masked-in pixels keep their color, else white.

    Used for overview tiling so the user can see what's actually in each
    layer (black-bg masks are invisible when compacted into tiles).
    """
    out = np.full_like(img_bgr, 255)
    mask_bool = mask_u8 > 0
    out[mask_bool] = img_bgr[mask_bool]
    return out


def _save_flat_png(mask_u8: np.ndarray, rgb_source: np.ndarray,
                   out_path: pathlib.Path) -> None:
    """Save BGR source masked with WHITE background (viewer-friendly)."""
    flat = _flatten_on_white(rgb_source, mask_u8)
    cv2.imwrite(str(out_path), flat)


def _save_binary_inverted(mask_u8: np.ndarray, out_path: pathlib.Path) -> None:
    """Save a binary mask with black foreground on white (easier to read)."""
    inv = 255 - mask_u8
    cv2.imwrite(str(out_path), inv)


def _kmeans_quantize(img: np.ndarray, k: int = 5) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return (quantized_image, labels_H×W, centers_K×3_BGR)."""
    H, W = img.shape[:2]
    Z = img.reshape((-1, 3)).astype(np.float32)
    _, labels, centers = cv2.kmeans(
        Z, k, None,
        (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.5),
        3, cv2.KMEANS_PP_CENTERS)
    labels = labels.flatten()
    quantized = centers[labels].reshape(H, W, 3).astype(np.uint8)
    return quantized, labels.reshape(H, W), centers.astype(np.uint8)


def _color_distance_sort(centers: np.ndarray) -> list[int]:
    """Order cluster indices from lightest (background) to darkest."""
    brightness = centers.mean(axis=1)
    return list(np.argsort(-brightness))  # lightest first


def _extract_thin_lines(gray: np.ndarray) -> np.ndarray:
    """Return a binary mask of skeletonized thin dark strokes."""
    # Adaptive threshold for hand-drawn style lines with varying thickness
    th = cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 15, 8
    )
    # Keep only thin strokes: erode then subtract = removes fat regions
    kernel = np.ones((5, 5), np.uint8)
    fat = cv2.erode(th, kernel, iterations=2)
    thin = cv2.subtract(th, cv2.dilate(fat, kernel, iterations=2))
    # Skeletonize to 1-pixel wide
    skel = skeletonize(thin > 0).astype(np.uint8) * 255
    return skel


def _extract_thick_fills(gray: np.ndarray, min_area: int = 500) -> np.ndarray:
    """Return a binary mask of solid filled regions (e.g., brain shape, logos)."""
    th = cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 25, 12
    )
    # Remove thin features via opening
    kernel = np.ones((5, 5), np.uint8)
    opened = cv2.morphologyEx(th, cv2.MORPH_OPEN, kernel, iterations=2)
    # Keep only large connected components
    num, lab, stats, _ = cv2.connectedComponentsWithStats(opened, 8)
    out = np.zeros_like(opened)
    for k in range(1, num):
        if stats[k, cv2.CC_STAT_AREA] >= min_area:
            out[lab == k] = 255
    return out


def _extract_circles(gray: np.ndarray) -> np.ndarray:
    """Return a mask rendering the detected circles / rings."""
    blurred = cv2.GaussianBlur(gray, (7, 7), 1.5)
    circles = cv2.HoughCircles(
        blurred, cv2.HOUGH_GRADIENT, dp=1.2, minDist=20,
        param1=120, param2=35,
        minRadius=10, maxRadius=min(gray.shape) // 3,
    )
    out = np.zeros_like(gray)
    if circles is not None:
        for (cx, cy, r) in circles[0]:
            cv2.circle(out, (int(cx), int(cy)), int(r), 255, 2)
    return out


def _extract_text_like(gray: np.ndarray) -> np.ndarray:
    """MSER-based text-candidate detection with relaxed thresholds.

    v2: allow wider min/max area and looser aspect ratio. MSER is invoked
    on BOTH polarities (dark-on-light and light-on-dark) and the union is
    returned.
    """
    H, W = gray.shape
    out = np.zeros_like(gray)
    for delta in (5, 2):  # two MSER sensitivities
        mser = cv2.MSER_create()
        mser.setDelta(delta)
        mser.setMinArea(15)
        mser.setMaxArea(int(H * W * 0.02))
        for img in (gray, 255 - gray):  # both polarities
            regions, _ = mser.detectRegions(img)
            for pts in regions:
                x, y, w, h = cv2.boundingRect(pts)
                if h < 5 or w < 3:
                    continue
                ar = w / max(1, h)
                if not (0.05 <= ar <= 20):
                    continue
                if h > H * 0.4:
                    continue
                cv2.drawContours(out, [pts.reshape(-1, 1, 2)], -1, 255, -1)
    return out


def _extract_edges_canny(gray: np.ndarray) -> np.ndarray:
    """Return Canny edge mask — tight outline of everything."""
    blurred = cv2.GaussianBlur(gray, (3, 3), 1.0)
    return cv2.Canny(blurred, 80, 180)


def _split_short_long_strokes(mask: np.ndarray,
                               short_cutoff: int = 40,
                               ) -> tuple[np.ndarray, np.ndarray]:
    """Split a binary mask into (short_strokes, long_strokes) by component size.

    `short_strokes` ≈ text glyph / small details (few pixels per component)
    `long_strokes` ≈ field lines, long outlines

    short_cutoff: component pixel count boundary.
    """
    num, lab, stats, _ = cv2.connectedComponentsWithStats(mask, 8)
    short = np.zeros_like(mask)
    long = np.zeros_like(mask)
    for k in range(1, num):
        area = stats[k, cv2.CC_STAT_AREA]
        if area <= short_cutoff:
            short[lab == k] = 255
        else:
            long[lab == k] = 255
    return short, long


def _tile(images: list[tuple[str, np.ndarray]], cols: int = 4) -> np.ndarray:
    """Tile a list of (label, image) into an overview grid with labels."""
    if not images:
        return np.zeros((100, 100, 3), dtype=np.uint8)
    # Normalize to BGR
    norm = []
    for lbl, im in images:
        if im.ndim == 2:
            im = cv2.cvtColor(im, cv2.COLOR_GRAY2BGR)
        elif im.shape[2] == 4:
            # Flatten alpha onto white
            bg = np.full_like(im[:, :, :3], 255)
            alpha = im[:, :, 3:4] / 255.0
            im = (im[:, :, :3] * alpha + bg * (1 - alpha)).astype(np.uint8)
        norm.append((lbl, im))

    # Use first image as reference size
    h, w = norm[0][1].shape[:2]
    # Scale each to (h, w)
    scaled = []
    for lbl, im in norm:
        sc = cv2.resize(im, (w, h))
        cv2.rectangle(sc, (0, 0), (w - 1, h - 1), (60, 60, 60), 1)
        cv2.putText(sc, lbl, (8, 20),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1, cv2.LINE_AA)
        scaled.append(sc)
    rows = []
    for i in range(0, len(scaled), cols):
        row = scaled[i:i + cols]
        while len(row) < cols:
            row.append(np.full((h, w, 3), 240, dtype=np.uint8))
        rows.append(np.hstack(row))
    return np.vstack(rows)


def separate(
    image_path: pathlib.Path,
    out_dir: pathlib.Path,
    *,
    k: int = 5,
    min_fill_area: int = 500,
) -> dict:
    """Split an image into semantic layers + write PNGs + overview."""
    img = cv2.imread(str(image_path))
    if img is None:
        raise RuntimeError(f"cannot read image: {image_path}")
    H, W = img.shape[:2]
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    out_dir.mkdir(parents=True, exist_ok=True)

    # Copy source for reference
    shutil.copy(str(image_path), str(out_dir / "_source.png"))

    layers = []  # list of (label, path, image_for_overview)

    # 1. K-means quantize
    quantized, labels_hw, centers = _kmeans_quantize(img, k=k)
    cv2.imwrite(str(out_dir / f"quantized_k{k}.png"), quantized)
    layers.append(("quantized", quantized))

    # 2. Per-cluster layers — saved TWO ways:
    #    *.png       (transparent bg, for Excalidraw import)
    #    *_flat.png  (white bg, for visual inspection / overview)
    sorted_idx = _color_distance_sort(centers)
    summaries = []
    for rank, idx in enumerate(sorted_idx):
        mask = (labels_hw == idx).astype(np.uint8) * 255
        b, g, r = int(centers[idx][0]), int(centers[idx][1]), int(centers[idx][2])
        pct = 100 * (mask > 0).sum() / mask.size
        stem = f"layer_color{rank}_rgb{r:03d}-{g:03d}-{b:03d}"
        _save_transparent(mask, img, out_dir / f"{stem}.png")
        _save_flat_png(mask, img, out_dir / f"{stem}_flat.png")
        summaries.append({
            "layer": f"{stem}.png", "rank_by_brightness": rank,
            "rgb": [r, g, b], "hex": f"#{r:02x}{g:02x}{b:02x}",
            "pixel_percent": round(pct, 2),
        })
        # Overview: use white-bg flat version so colors are visible
        flat_for_tile = _flatten_on_white(img, mask)
        layers.append((f"color{rank} {pct:.0f}% #{r:02x}{g:02x}{b:02x}", flat_for_tile))

    # 3. Background (near-white)
    bg_mask = cv2.inRange(hsv, (0, 0, 200), (180, 40, 255))
    _save_binary(bg_mask, out_dir / "layer_bg.png")
    layers.append(("background", bg_mask))

    # 4. Foreground (everything non-bg) — single-color (black on white)
    fg_mask = cv2.bitwise_not(bg_mask)
    _save_binary_inverted(fg_mask, out_dir / "layer_foreground.png")
    layers.append(("foreground (non-bg)", fg_mask))

    # 5. Canny edges
    edges = _extract_edges_canny(gray)
    _save_binary_inverted(edges, out_dir / "layer_edges_canny.png")
    layers.append(("edges (Canny)", edges))

    # 6. Thin lines (skeleton) — split into short/long by component size
    thin = _extract_thin_lines(gray)
    text_strokes, line_strokes = _split_short_long_strokes(thin, short_cutoff=40)
    _save_binary_inverted(thin, out_dir / "layer_thin_lines_all.png")
    _save_binary_inverted(text_strokes, out_dir / "layer_thin_short.png")
    _save_binary_inverted(line_strokes, out_dir / "layer_thin_long.png")
    layers.append(("thin short (text)", text_strokes))
    layers.append(("thin long (lines)", line_strokes))

    # 7. Thick fills
    fills = _extract_thick_fills(gray, min_area=min_fill_area)
    _save_binary_inverted(fills, out_dir / "layer_thick_fills.png")
    layers.append(("thick fills", fills))

    # 8. Circles (Hough)
    circles = _extract_circles(gray)
    _save_binary_inverted(circles, out_dir / "layer_circles.png")
    layers.append(("circles (Hough)", circles))

    # 9. Text-like (MSER, v2: relaxed thresholds)
    text = _extract_text_like(gray)
    _save_binary_inverted(text, out_dir / "layer_text_mser.png")
    layers.append(("text (MSER)", text))

    # 10. Overview tile
    overview = _tile(
        [("source", img)] + layers,
        cols=4,
    )
    cv2.imwrite(str(out_dir / "layers_overview.png"), overview)

    return {
        "image": str(image_path),
        "size": [W, H],
        "out_dir": str(out_dir),
        "k": k,
        "color_layers": summaries,
        "binary_layers": [
            "layer_bg", "layer_foreground", "layer_edges_canny",
            "layer_thin_lines_all", "layer_thin_short", "layer_thin_long",
            "layer_thick_fills", "layer_circles", "layer_text_mser",
        ],
    }


def main(argv=None) -> int:
    p = argparse.ArgumentParser(
        description="Separate a raster image into semantic PNG layers"
    )
    p.add_argument("--image-path", required=True)
    p.add_argument("--out-dir", default=None,
                   help="output dir; defaults to <image_parent>/<stem>_layers/")
    p.add_argument("--k", type=int, default=5)
    p.add_argument("--min-fill-area", type=int, default=500)
    args = p.parse_args(argv)

    src = pathlib.Path(args.image_path)
    if args.out_dir:
        out = pathlib.Path(args.out_dir)
    else:
        out = src.parent / f"{src.stem}_layers"

    summary = separate(src, out, k=args.k, min_fill_area=args.min_fill_area)
    import json
    json.dump(summary, sys.stdout, indent=2)
    sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
