"""compose_layers.py — trace already-separated layer PNGs and compose
into a single Excalidraw JSON.

Typical workflow:
  1. `separate_layers.py --image-path SRC`   → out_dir/*.png
  2. (human review: pick which layers to include + strategy per layer)
  3. `compose_layers.py --layers-dir DIR --config config.json`
     where config.json maps layer_filename → {strategy, stroke, fill, group}
  4. output: single .excalidraw JSON that the user imports

Strategies
----------
- ``fill_contour``   : solid-filled polygon per external contour
                        (good for brain silhouette, logo glyphs)
- ``outline``        : closed polyline of each contour (no fill)
                        (good for coils, rings, outline-only shapes)
- ``skeleton_lines`` : trace skeletonized strokes as polylines
                        (good for thin field lines)
- ``circles_fit``    : Hough-detected circles as ellipses
                        (good for concentric field rings)
- ``text_placeholder``: emit small text-element stubs at each MSER region
                        (user fills in the actual text later)
- ``points``         : tiny filled circles for small components
                        (good for glow-nodes, bullet points)

Each strategy takes: stroke (hex), fill (hex or None), group (str).

Usage:
    python compose_layers.py --layers-dir PATH --out PATH.excalidraw
                             [--config PATH.json]
                             [--scale 3.0] [--offset 50 50]
"""
from __future__ import annotations

import argparse
import json
import math
import pathlib
import random
import sys
import time
from typing import Iterable

import cv2
import numpy as np
from skimage.morphology import skeletonize

# Re-use the helper builders from trace_image.py
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from trace_image import (  # noqa: E402
    _base_el, _rid, _r32, circle_el, polyline_el, rect_el,
    trace_skeleton_paths,
)


# --------------------------------------------------------------------
# Strategy implementations
# --------------------------------------------------------------------
def _load_mask(path: pathlib.Path) -> np.ndarray:
    """Load a binary mask from PNG.

    - If 4-channel: use alpha channel
    - If 3-channel: threshold the inverse (since we saved inverted binary)
    - If 1-channel: use directly. Treat near-zero OR near-255 as "content"
      depending on polarity (autodetect: foreground = minority color).
    """
    img = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
    if img is None:
        raise RuntimeError(f"cannot read mask: {path}")
    if img.ndim == 3 and img.shape[2] == 4:
        mask = img[:, :, 3]
    elif img.ndim == 3:
        g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        # Threshold binary: treat any strongly non-mid value as content
        # using the minority side (works for both white-bg and black-bg)
        _, bin1 = cv2.threshold(g, 127, 255, cv2.THRESH_BINARY)
        if (bin1 > 0).sum() > bin1.size * 0.5:
            bin1 = 255 - bin1
        mask = bin1
    else:
        mask = img
        if (mask > 128).sum() > mask.size * 0.5:
            mask = 255 - mask
    return mask


def _strategy_fill_contour(mask: np.ndarray, *, rng, now_ms, scale, offset,
                            stroke, fill, group, min_area=300,
                            epsilon=0.002) -> list[dict]:
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL,
                                    cv2.CHAIN_APPROX_NONE)
    out = []
    for c in contours:
        a = cv2.contourArea(c)
        if a < min_area:
            continue
        eps = epsilon * cv2.arcLength(c, True)
        approx = cv2.approxPolyDP(c, eps, True)
        if len(approx) < 3:
            continue
        pts = [(int(p[0][0]) * scale + offset[0],
                int(p[0][1]) * scale + offset[1]) for p in approx]
        el = polyline_el(rng, now_ms, pts,
                         stroke=stroke, width=2,
                         fill=fill, closed=True, group=group)
        if el:
            out.append(el)
    return out


def _strategy_outline(mask: np.ndarray, *, rng, now_ms, scale, offset,
                      stroke, group, min_area=150,
                      epsilon=0.003, width=1.5) -> list[dict]:
    contours, _ = cv2.findContours(mask, cv2.RETR_LIST,
                                    cv2.CHAIN_APPROX_NONE)
    out = []
    for c in contours:
        if cv2.contourArea(c) < min_area and cv2.arcLength(c, False) < 30:
            continue
        eps = epsilon * cv2.arcLength(c, True)
        approx = cv2.approxPolyDP(c, eps, True)
        if len(approx) < 3:
            continue
        pts = [(int(p[0][0]) * scale + offset[0],
                int(p[0][1]) * scale + offset[1]) for p in approx]
        el = polyline_el(rng, now_ms, pts,
                         stroke=stroke, width=width,
                         closed=True, group=group)
        if el:
            out.append(el)
    return out


def _strategy_skeleton_lines(mask: np.ndarray, *, rng, now_ms, scale, offset,
                              stroke, group, min_length=6,
                              simplify=0.7, width=1.5,
                              max_lines=500) -> list[dict]:
    skel = skeletonize(mask > 0).astype(np.uint8)
    n, lab, stats, _ = cv2.connectedComponentsWithStats(skel, 8)
    pruned = np.zeros_like(skel)
    for k in range(1, n):
        if stats[k, cv2.CC_STAT_AREA] >= min_length:
            pruned[lab == k] = 1
    paths = trace_skeleton_paths(pruned)
    paths.sort(key=lambda p: -len(p))
    paths = paths[:max_lines]
    out = []
    for path in paths:
        arr = np.array([[x, y] for (y, x) in path],
                       dtype=np.int32).reshape(-1, 1, 2)
        if len(arr) < 3:
            continue
        simp = cv2.approxPolyDP(arr, simplify, False)
        pts = [(int(p[0][0]) * scale + offset[0],
                int(p[0][1]) * scale + offset[1]) for p in simp]
        if len(pts) < 2:
            continue
        el = polyline_el(rng, now_ms, pts,
                         stroke=stroke, width=width, group=group)
        if el:
            out.append(el)
    return out


def _strategy_circles_fit(mask: np.ndarray, *, rng, now_ms, scale, offset,
                           stroke, fill, group,
                           min_radius=15, max_radius=300,
                           max_circles=30) -> list[dict]:
    gray = mask.copy()
    blur = cv2.GaussianBlur(gray, (5, 5), 1.2)
    # Stricter Hough parameters to avoid detecting every pixel blob as a circle:
    #   param2 = minimum accumulator threshold (higher = only strong circles)
    #   minDist = 2x min_radius to avoid clustered detections
    circles = cv2.HoughCircles(
        blur, cv2.HOUGH_GRADIENT, dp=1.5, minDist=max(50, min_radius * 2),
        param1=120, param2=55,
        minRadius=min_radius, maxRadius=max_radius,
    )
    out = []
    if circles is not None:
        # Sort by radius descending, emit at most max_circles
        sorted_c = sorted(circles[0], key=lambda c: -float(c[2]))
        for (cx, cy, r) in sorted_c[:max_circles]:
            cx_c = float(cx) * scale + offset[0]
            cy_c = float(cy) * scale + offset[1]
            rr = float(r) * scale
            out.append(circle_el(rng, now_ms, cx_c, cy_c, rr,
                                  stroke=stroke, fill=fill or "transparent",
                                  stroke_w=2, opacity=100, group=group))
    return out


def _strategy_text_placeholder(mask: np.ndarray, *, rng, now_ms, scale, offset,
                                stroke, group,
                                min_area=30, min_height=8) -> list[dict]:
    """Emit empty text-element stubs at each component bounding box.

    User fills in the actual glyph content later in Excalidraw.
    """
    n, _lab, stats, _cents = cv2.connectedComponentsWithStats(mask, 8)
    out = []
    for k in range(1, n):
        x, y, w, h, a = stats[k]
        if a < min_area or h < min_height:
            continue
        cx = (x + w / 2) * scale + offset[0]
        cy = (y + h / 2) * scale + offset[1]
        el = _base_el(rng, now_ms,
                      type="text",
                      x=cx - w * scale / 2, y=cy - h * scale / 2,
                      width=w * scale, height=h * scale,
                      strokeColor=stroke,
                      text="?", fontSize=int(h * scale * 0.8),
                      fontFamily=1, textAlign="center", verticalAlign="middle",
                      baseline=int(h * scale * 0.8), originalText="?")
        if group:
            el["groupIds"] = [group]
        out.append(el)
    return out


def _strategy_points(mask: np.ndarray, *, rng, now_ms, scale, offset,
                      stroke, fill, group,
                      max_area=30, min_area=2) -> list[dict]:
    n, _lab, stats, cents = cv2.connectedComponentsWithStats(mask, 8)
    out = []
    for k in range(1, n):
        a = int(stats[k, cv2.CC_STAT_AREA])
        if not (min_area <= a <= max_area):
            continue
        cx, cy = cents[k]
        cx_c = float(cx) * scale + offset[0]
        cy_c = float(cy) * scale + offset[1]
        r = max(1.5, math.sqrt(a / math.pi) * 1.1) * scale
        out.append(circle_el(rng, now_ms, cx_c, cy_c, r,
                              stroke=stroke, fill=fill or stroke,
                              stroke_w=0, opacity=100, group=group))
    return out


STRATEGIES = {
    "fill_contour": _strategy_fill_contour,
    "outline": _strategy_outline,
    "skeleton_lines": _strategy_skeleton_lines,
    "circles_fit": _strategy_circles_fit,
    "text_placeholder": _strategy_text_placeholder,
    "points": _strategy_points,
}


# --------------------------------------------------------------------
# Composer
# --------------------------------------------------------------------
def compose(
    layers_dir: pathlib.Path,
    config: dict,
    *,
    scale: float = 3.0,
    offset: tuple[float, float] = (50, 50),
    seed: int = 42,
) -> tuple[list[dict], dict]:
    """Apply the per-layer strategies from config and produce Excalidraw elements.

    config format:
        {
          "layers": [
            {
              "filename": "layer_thick_fills.png",
              "strategy": "fill_contour",
              "stroke": "#1e3a6a",
              "fill": "#3388a0",
              "group": "brain",
              "min_area": 300
            },
            ...
          ]
        }
    """
    rng = random.Random(seed)
    now_ms = int(time.time() * 1000)

    all_elements: list[dict] = []
    summary: dict = {"layers": []}

    for entry in config.get("layers", []):
        fname = entry.get("filename")
        if not fname:
            continue
        mask_path = layers_dir / fname
        if not mask_path.exists():
            summary["layers"].append({
                "filename": fname, "error": "not found",
            })
            continue
        strategy_name = entry.get("strategy", "outline")
        strategy = STRATEGIES.get(strategy_name)
        if strategy is None:
            summary["layers"].append({
                "filename": fname, "error": f"unknown strategy: {strategy_name}",
            })
            continue

        mask = _load_mask(mask_path)
        kwargs = {
            k: v for k, v in entry.items()
            if k not in ("filename", "strategy")
        }
        # Default required kwargs for each strategy
        kwargs.setdefault("stroke", "#1e1e1e")
        if strategy_name in ("fill_contour", "circles_fit", "points"):
            kwargs.setdefault("fill", None)
        kwargs.setdefault("group", entry.get("group", fname))
        try:
            els = strategy(
                mask, rng=rng, now_ms=now_ms,
                scale=scale, offset=offset, **kwargs,
            )
        except TypeError as exc:
            summary["layers"].append({
                "filename": fname, "strategy": strategy_name,
                "error": f"bad kwargs: {exc}",
            })
            continue
        all_elements.extend(els)
        summary["layers"].append({
            "filename": fname,
            "strategy": strategy_name,
            "emitted": len(els),
            "group": kwargs.get("group"),
        })

    summary["total_elements"] = len(all_elements)
    return all_elements, summary


def default_config_for(layers_dir: pathlib.Path) -> dict:
    """Inspect the layers dir and produce a sensible default config.

    Tuned for clean output on logos / research-illustration raster images.
    Users wanting different results should pass their own --config.
    """
    layers = []
    pref = [
        # Large solid shapes (brain, bulb, text bold). min_area scaled to
        # catch sub-icons but not noise specks.
        {"filename": "layer_thick_fills.png", "strategy": "fill_contour",
         "stroke": "#1e3a6a", "fill": "#3388a0", "group": "fills",
         "min_area": 150, "epsilon": 0.003},
        # Long thin strokes (field lines, coil outlines). Cap lines to 200
        # to keep the canvas readable.
        {"filename": "layer_thin_long.png", "strategy": "skeleton_lines",
         "stroke": "#2c77af", "group": "lines",
         "min_length": 8, "simplify": 0.8, "width": 1.5,
         "max_lines": 200},
        # Only the strongest circles (spiral field rings). At most 20
        # per image to avoid Hough noise overflow.
        {"filename": "layer_circles.png", "strategy": "circles_fit",
         "stroke": "#153453", "fill": None, "group": "rings",
         "min_radius": 20, "max_radius": 300, "max_circles": 20},
        # Small bright dots (glow nodes, bullet points). min_area=4 to
        # skip 1-2px noise.
        {"filename": "layer_thin_short.png", "strategy": "points",
         "stroke": "#153453", "fill": "#153453", "group": "dots",
         "min_area": 4, "max_area": 40},
    ]
    out = []
    for entry in pref:
        if (layers_dir / entry["filename"]).exists():
            out.append(entry)
    return {"layers": out}


def to_excalidraw_json(elements: list[dict],
                        background: str = "#ffffff") -> dict:
    return {
        "type": "excalidraw",
        "version": 2,
        "source": "mcp_excalidraw.compose_layers",
        "elements": elements,
        "appState": {
            "gridSize": None,
            "viewBackgroundColor": background,
        },
        "files": {},
    }


# --------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------
def main(argv=None) -> int:
    p = argparse.ArgumentParser(
        description="Compose Excalidraw JSON from pre-separated layer PNGs"
    )
    p.add_argument("--layers-dir", required=True,
                   help="output dir of separate_layers.py")
    p.add_argument("--out", required=True, help="output .excalidraw JSON path")
    p.add_argument("--config", default=None,
                   help="JSON config (default: auto-generated)")
    p.add_argument("--scale", type=float, default=3.0)
    p.add_argument("--offset", nargs=2, type=float, default=(50.0, 50.0))
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--background", default="#ffffff")
    args = p.parse_args(argv)

    layers_dir = pathlib.Path(args.layers_dir)
    if args.config:
        config = json.loads(pathlib.Path(args.config).read_text(encoding="utf-8"))
    else:
        config = default_config_for(layers_dir)

    elements, summary = compose(
        layers_dir, config,
        scale=args.scale, offset=tuple(args.offset), seed=args.seed,
    )
    doc = to_excalidraw_json(elements, background=args.background)
    pathlib.Path(args.out).write_text(
        json.dumps(doc, ensure_ascii=False), encoding="utf-8"
    )
    summary["out"] = args.out
    summary["config_used"] = config
    json.dump(summary, sys.stdout, ensure_ascii=False, indent=2)
    sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
