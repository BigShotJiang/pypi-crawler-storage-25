# mcp-server-document

MCP server for academic document authoring — grant proposals, journal papers, and research-talk slides — distilled from 14 classical Japanese/English writing-technique books.

> **Status**: 0.1.0 (beta). Battle-tested on grant 申請書 (JSPS, KDDI, パワーアカデミー), IEEJ / IEEE journal submissions, and 20-minute research talks.

## What it does

Exposes **40 MCP tools** across three sub-domains, plus a placeholder for a diagram-drawing companion:

| Sub-module     | Tools | Covers                                                     |
|----------------|------:|------------------------------------------------------------|
| `grant_writing`  | 11  | Hook/Vision, Araki 物語論, NG パターン診断, 木下 10 原則, 本多テン原則 |
| `paper_writing`  | 14  | IMRAD, Reviewer 2 4-tier, Given-New 配置, 禁断 Intro 冒頭, Wallwork アクセプト術 |
| `presentation`   | 15  | 高橋メソッド / Zen / 横徹流, 作図力学, 1/3則・1/4則, 木下 10章 講演術 |
| `diagram`        | 0   | Planned — HTTP bridge to the sibling Node.js Excalidraw MCP |

Tools are split between:

- **Knowledge loaders** (`*_usage`): return the full skill.md guide for LLM context injection.
- **Active diagnostics** (`*_check_*`, `*_count_*`, `*_validate_*`): Python-implemented lint rules that operate on `.tex`, `.pdf`, `.log`, `.pptx`, or raw text — overfull hbox, sentence length, weak hedges, Abstract background ratio, strong-adjective budget, slide line count, hedge-on-key-slide, 漢字比率, 本多テン第二原則, and ~30 more.

## Install

```bash
pip install mcp-server-document
```

For PDF page-count and pptx slide-count diagnostics:

```bash
pip install "mcp-server-document[full]"   # pymupdf + python-pptx
```

## Register with Claude Code / Claude Desktop

Add to `.claude.json` (or Claude Desktop `config.json`):

```json
{
  "mcpServers": {
    "document": {
      "type": "stdio",
      "command": "mcp-server-document",
      "args": [],
      "env": {}
    }
  }
}
```

Then in Claude: reference `document.paper_writing_usage` for IMRAD guidance, `document.presentation_check_over_politeness` to lint your 発表原稿, etc.

## Example: diagnose a journal paper draft

```python
# Inside Claude Code, with mcp-server-document registered:
# (pseudocode — actual invocation is through MCP protocol)

mcp.document.paper_writing_check_paragraph_opener(text=intro_text)
# -> flags "In this paper, we propose..." as a banned Wallwork §14.11 opener

mcp.document.paper_writing_check_abstract_background_ratio(abstract=abstract_text)
# -> reports background_ratio: 0.42 (target <= 0.25; Wallwork §13.16 hard reject)

mcp.document.paper_writing_check_strong_adjective_budget(text=full_paper)
# -> 7 strong adjectives ("novel", "innovative", ...) — Wallwork §8.12 warns >=5 reads as hype
```

## Source knowledge

The skill.md guides are distilled from (Japanese):

- 木下是雄 『理科系の作文技術』 (中公新書)
- 本多勝一 『日本語の作文技術』 / 『中学生からの作文技術』 (朝日)
- 北原保雄 編 『問題な日本語』 (大修館書店)
- 荒木飛呂彦 『荒木飛呂彦の漫画術』 (集英社新書)
- 児島将康 『いちばんやさしい科研費の申請書の教科書』 (羊土社)
- 佐藤雅昭 『なぜあなたは論文が書けないのか』 (メディカルレビュー社)
- まんが版 / 『知的な科学・技術文章の書き方』 / 『作図力学』 / 『研究発表のためのスライドデザイン』

and (English):

- A. Wallwork, *English for Writing Research Papers* — the Japanese edition 『日本人研究者のための論文の書き方・アクセプト術』
- J. Swales, *Academic Writing for Graduate Students* (CARS model)
- E. Tufte, *The Visual Display of Quantitative Information*

All page references in skill.md point back to the cited books so you can verify.

## License

MIT — see [LICENSE](LICENSE).

Author: Kengo Sugahara (Kindai University, 近畿大学)

## Related

- [`excalidraw/`](./excalidraw/) — Node.js sibling MCP (whiteboard canvas for figure drafting). See also upstream [yctimlin/mcp_excalidraw](https://github.com/yctimlin/mcp_excalidraw) which this clone is based on.
- [Model Context Protocol](https://modelcontextprotocol.io/) — the spec this server implements.

## Contributing

Issues and PRs welcome. The skill.md guides are deliberately quotable (with page refs) so additions should cite their source too. Please open an issue before adding new diagnostic tools.
