# hk-mall-wx

好客商城基础包

## 安装

```bash
pip install hk-mall
```

## 依赖

- seven-cloudapp-frame==1.2.129

## 使用

```python
# 导入包使用
from libs.customize import member_base_model
```

