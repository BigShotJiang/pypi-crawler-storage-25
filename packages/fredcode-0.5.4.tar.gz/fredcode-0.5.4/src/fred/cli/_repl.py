"""REPL loop body extracted from the typer ``_run`` callback.

`run_repl(...)` is the body of the original `_run` from the api-key
check through `tracer.drain` cleanup. The typer-decorated callback in
``_main.py`` does CLI argument validation + the early-exit branches
(`--version`, subcommand dispatch) and delegates to this function for
everything else.
"""
from __future__ import annotations

import os
import uuid
from pathlib import Path
from typing import Any, Optional

import typer
from prompt_toolkit import PromptSession
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.shortcuts import CompleteStyle
from prompt_toolkit.styles import Style as PTKStyle
from rich.console import Console

from fred._constants import MENU_RESERVED_LINES
from fred.agent import run_turn
from fred.checkpoints import Checkpointer, prune_stale
from fred.cli._banner import _render_banner, _render_no_credentials_panel
from fred.cli._main import Mode, OutputStyle
from fred.cli._models import _RunMode
from fred.cli._session_state import _SessionState, _build_initial_messages, _make_repo_map_provider
from fred.cli._slash_commands import SLASH_DISPATCH, SlashContext
from fred.cli._telemetry import _maybe_show_first_run_notice
from fred.client import DEFAULT_BASE_URL, DEFAULT_MODEL, DSClient
from fred.config import ModelConfig, get_api_key, load_model_config
from fred.hooks import load_hooks_config, run_hooks
from fred.input_parse import count_mentions, expand_bang, expand_mentions
from fred.mcp import (
    cleanup_servers as mcp_cleanup_servers,
    connect_servers as mcp_connect_servers,
    load_mcp_config,
    register_mcp_tools as mcp_register_tools,
)
from fred.mode import reset_mode_state, set_mode_state
from fred.permissions import PermissionPolicy, normalize_approval_mode
from fred.plan_file import plan_file_path
from fred.render import Renderer
from fred.repomap import RepoMap
from fred.rules import RuleSet, env_disables_rules
from fred.slash_commands import SlashCommandCompleter
from fred.telemetry import make_tracer
from fred import update_check
from fred.tools._sandbox import (
    SandboxMode,
    current_sandbox_mode,
    normalize_mode as normalize_sandbox_mode,
    reset_sandbox_mode,
    set_sandbox_mode,
)
from fred.tools._session_files import reset_tracked_files, set_tracked_files
from fred.tools import bash_bg as _bash_bg
from fred.tools.registry import Registry


def run_repl(
    *,
    prompt: Optional[str],
    yolo: bool,
    plan: bool,
    no_stream: bool,
    model: str,
    architect: bool,
    output_style: str,
    sandbox: Optional[str],
    approval: Optional[str],
    no_telemetry: bool,
) -> None:
    """Body of the typer ``_run`` callback. See ``_main._run`` for arg docs."""

    # P3.3: validate the output style early so a typo fails fast with a
    # clear message rather than silently falling back to the default.
    if output_style not in ("concise", "explanatory"):
        typer.echo(
            f"Invalid --output-style {output_style!r}. "
            "Expected 'concise' or 'explanatory'.",
            err=True,
        )
        raise typer.Exit(code=1)
    output_style_state: list[str] = [output_style]

    if not get_api_key():
        _render_no_credentials_panel()
        raise typer.Exit(code=1)

    console = Console()
    renderer = Renderer(console=console, stream=not no_stream)

    # P4.1: validate the two new orthogonal axis flags up-front so a typo
    # fails loud rather than silently falling back to the default.
    sandbox_mode_override: SandboxMode | None = None
    if sandbox is not None:
        sandbox_mode_override = normalize_sandbox_mode(sandbox)
        if sandbox_mode_override is None:
            typer.echo(
                f"Invalid --sandbox {sandbox!r}. "
                "Expected ro|workspace-write|full.",
                err=True,
            )
            raise typer.Exit(code=1)
    if approval is not None:
        if normalize_approval_mode(approval) is None:
            typer.echo(
                f"Invalid --approval {approval!r}. "
                "Expected untrusted|on_request|never.",
                err=True,
            )
            raise typer.Exit(code=1)

    permissions = PermissionPolicy(
        yolo=yolo, console=console, approval_mode=approval,
    )

    # Install the session-scoped sandbox mode. None defers to env / settings.
    _sandbox_mode_token = set_sandbox_mode(sandbox_mode_override)

    # Multi-model routing: build the four-slot config now so the
    # banner, tracer snapshot, and `/model` slash all read from the same
    # source of truth. Explicit `--model` overrides `FRED_MAIN_MODEL` for
    # the main slot only; editor, weak, and subagent_main still inherit
    # from main when their env vars / prefs are unset, which is the
    # friendly default.
    model_cfg = load_model_config()
    if model != DEFAULT_MODEL:
        new_main = model
        new_editor = model_cfg.editor_model
        new_weak = model_cfg.weak_model
        new_subagent_main = model_cfg.subagent_main_model
        if new_editor == model_cfg.main_model:
            new_editor = new_main
        if new_weak == model_cfg.main_model:
            new_weak = new_main
        if new_subagent_main == model_cfg.main_model:
            new_subagent_main = new_main
        model_cfg = ModelConfig(
            main_model=new_main,
            editor_model=new_editor,
            weak_model=new_weak,
            subagent_main_model=new_subagent_main,
        )

    client = DSClient(model=model_cfg.main_model)

    # P2.2 plan/act mode. The `mode_state` list is the SINGLE source of
    # truth for the current mode — slash commands, the Shift+Tab
    # keybinding, and `exit_plan_mode` (called by the model) all mutate
    # the same list, and `Registry.dispatch` reads from it via the
    # `fred.mode` ContextVar installed below. The initial value comes
    # from the `--plan` flag.
    initial_mode: Mode = "plan" if plan else "act"
    mode_state: list[str] = [initial_mode]
    _mode_state_token = set_mode_state(mode_state)
    # PR-D1: install a session-scoped todo list so sub-agents (which
    # dispatch fresh run_session calls) get their own isolated lists.
    # Without this the module-global _state would leak across the
    # parent → subagent boundary; the `plan` subagent profile in
    # particular has todo_write AND would otherwise share the parent's
    # storage. Token is held for the lifetime of the REPL.
    from fred.tools.todo import install_todo_list, reset_todo_list as _reset_todos
    _todos_token = install_todo_list()
    messages, registry = _build_initial_messages(
        mode=initial_mode, output_style=output_style_state[0],  # type: ignore[arg-type]
    )
    # Box-list rebind contract (PR-12). /clear, /compact, /sandbox,
    # /model, /flash, /pro need to swap state that downstream
    # consumers (the post-turn run_turn call, _emit_status_line,
    # _bottom_toolbar, the finally: token reset) read. Boxes seed
    # from these locals; from here on every read of registry /
    # messages / model_cfg / the sandbox token must go through the
    # box so a slash handler's rebind takes effect.
    registry_box: list[Registry] = [registry]
    messages_box: list[list[dict]] = [messages]
    model_cfg_box: list[ModelConfig] = [model_cfg]
    sandbox_token_box: list[Any] = [_sandbox_mode_token]

    # Convenience: short helper that reads the live mode (the slash
    # command + keybinding mutate `mode_state[0]`, so this always
    # returns the current value, not a captured snapshot).
    def current_mode() -> Mode:
        return "plan" if mode_state[0] == "plan" else "act"

    # P3.3: helper for the live output style (mutated by `/style`).
    def current_output_style() -> OutputStyle:
        v = output_style_state[0]
        return "explanatory" if v == "explanatory" else "concise"

    # Plan-file scratchpad path (P2.2). Computed once per session;
    # exposed via session_state so the banner / future status line
    # can show it. The directory is created lazily.
    session_state = _SessionState()
    session_state.plan_file_path = plan_file_path(uuid.uuid4().hex)

    run_mode = _RunMode.ARCHITECT if architect else _RunMode.NORMAL

    tracer = make_tracer(session_disabled=no_telemetry)
    # First-run notice — print once on the first session that successfully
    # constructs a non-NullTracer, then never again. Lives here (after
    # tracer construction, before start_session) so users see the
    # disclosure exactly when telemetry is about to fire.
    _maybe_show_first_run_notice(tracer, console)
    if prompt is None:
        # Background PyPI poll for the update notice. Daemon thread,
        # never blocks startup, silent on every error. One-shot mode
        # (-p) deliberately skips this — scriptable users get no notice
        # and no PyPI traffic.
        update_check.kickoff()
    tracer.start_session(
        model=model_cfg.main_model,
        base_url=DEFAULT_BASE_URL,
        yolo=yolo,
        one_shot=prompt is not None,
        system_prompt=messages[0]["content"],
        registry_names=registry.names(),
        registry_perms={n: registry.get(n).requires_permission for n in registry.names()},
        config_snapshot={
            "main_model": model_cfg.main_model,
            "editor_model": model_cfg.editor_model,
            "weak_model": model_cfg.weak_model,
            "subagent_main_model": model_cfg.subagent_main_model,
            "run_mode": run_mode,
            # P3.3: persists the starting output style so analytics can
            # join sessions to behavior outcomes (e.g. "do explanatory
            # sessions complete in fewer iterations?").
            "output_style": output_style_state[0],
        },
    )
    # Thread the local session_id into the proxy via x-fred-session-id
    # so usage_events rows the proxy writes can be joined back to this
    # CLI session in /usage and /admin/models. NullTracer returns "" —
    # in that case the header isn't sent.
    if tracer.session_id:
        client.correlation_session_id = tracer.session_id
    if plan:
        # The flag-driven entry into plan mode is the first user-visible
        # mode change of the session — emit a `mode_change` event with
        # source="flag" so analytics can attribute it correctly.
        tracer.event("mode_change", payload={
            "from": "act", "to": "plan", "source": "flag",
        })

    # --- Repo map (P1.1). Cold-start scan now so the first turn has
    # a populated tag cache and personalization can take effect. The
    # feature can be disabled via `FRED_REPOMAP=0` (e.g., in CI or for
    # tiny one-off invocations where the scan would be wasted work).
    repo_map_obj: RepoMap | None = None
    if os.environ.get("FRED_REPOMAP", "1") != "0":
        try:
            repo_map_obj = RepoMap(Path.cwd())
            tracer.event("repo_map_scan_start", payload={"root": str(Path.cwd())})
            renderer.info("repo map: scanning…")
            stats = repo_map_obj.scan()
            tracer.event("repo_map_scan_complete", payload=stats)
            renderer.info(
                f"repo map: parsed {stats['files_parsed']}/{stats['files_seen']} files "
                f"in {stats['parse_ms'] + stats['walk_ms']}ms "
                f"({len(stats['languages_found'])} language(s))"
            )
        except Exception as e:
            # Best-effort: if the scan fails (sqlite db corrupt, perms,
            # ...), drop the repo map silently and continue.
            tracer.event("repo_map_scan_failed", payload={
                "type": type(e).__name__, "message": str(e)[:200],
            })
            repo_map_obj = None

    repo_map_provider = _make_repo_map_provider(repo_map_obj, session_state)

    # P1.4 prior-Read enforcement: install the session-scoped tracked-files
    # set so `view` / `create_file` populate it via `mark_tracked` and
    # `str_replace` can consult it. We share the SAME object as
    # `session_state.viewed_files` so the repo-map personalization
    # (which already reads viewed_files) keeps working without duplicate
    # bookkeeping. The token is reset in the `finally` block below.
    _tracked_files_token = set_tracked_files(session_state.viewed_files)

    # P3.4 background bash: install a fresh per-session state for the
    # bash_bg / bash_read / bash_kill tools so handles never leak across
    # CLI invocations (or `/clear`, which forks the ContextVar). Also
    # install a tracer-emitter shim so the bash_bg events land in the
    # session's tracer rather than the module-level NullTracer fallback.
    _bash_bg_state_token = _bash_bg.set_session_state()

    def _bash_bg_emit(kind: str, payload: dict) -> None:
        # Wraps Tracer.event so the bash_bg module stays decoupled from
        # the tracer interface. Errors are swallowed inside _bash_bg._emit.
        tracer.event(kind, payload=payload)

    _bash_bg_emit_token = _bash_bg.set_event_emitter(_bash_bg_emit)

    # P2.4 hooks: load `~/.fred/settings.json` and project-level
    # `.fred/settings.json` and merge them. UserPromptSubmit + Stop fire
    # from the cli; PreToolUse + PostToolUse fire inside `run_session`.
    hooks_config = load_hooks_config(Path.cwd())

    # P4.2 MCP: spawn user-configured MCP servers and merge their tools
    # into the active registry. `mcp_session` is None when no servers
    # are configured (the common case). Failures degrade to info lines
    # and crashed entries — they never bring down the session.
    mcp_configs = load_mcp_config(Path.cwd())
    mcp_session = None
    if mcp_configs:
        def _mcp_event(kind: str, payload: dict) -> None:
            try:
                tracer.event(kind, payload=payload)
            except Exception:
                pass

        try:
            mcp_session = mcp_connect_servers(
                mcp_configs,
                on_event=_mcp_event,
                on_info=renderer.info,
            )
            tools_added = mcp_register_tools(
                registry, mcp_session, on_event=_mcp_event,
            )
            if tools_added:
                renderer.info(f"mcp: registered {tools_added} tool(s)")
        except Exception as e:
            tracer.event("mcp_load_failed", payload={
                "type": type(e).__name__, "message": str(e)[:200],
            })
            mcp_session = None

    # P3.2 rules: discover `.fred/rules/*.md` once at session start. The
    # set is passed to `run_turn`/`run_session` and is the source of
    # truth for the per-iteration "active" + "available" rule blocks.
    # `FRED_RULES=0` disables the feature entirely; matches FRED_REPOMAP.
    rule_set: RuleSet | None = None
    if not env_disables_rules():
        try:
            rule_set = RuleSet.load(Path.cwd())
            if rule_set.rules:
                renderer.info(
                    f"rules: loaded {len(rule_set.rules)} from "
                    f"{', '.join(str(s) for s in rule_set.sources)}"
                )
        except Exception as e:
            tracer.event("rules_load_failed", payload={
                "type": type(e).__name__, "message": str(e)[:200],
            })
            rule_set = None

    def _chat_files_provider() -> set[Path]:
        """Snapshot the files referenced this turn for glob matching."""
        return set(session_state.viewed_files) | set(session_state.mentioned_files)

    # P4.3: shadow-git checkpoints. Construct the Checkpointer once per
    # session; the bare repo is initialized lazily on the first
    # successful tool dispatch. Disabled when ``FRED_CHECKPOINTS=0`` —
    # matches the on/off switch used by other Phase-3/4 features.
    checkpointer: Checkpointer | None = None
    if os.environ.get("FRED_CHECKPOINTS", "1") != "0":
        try:
            checkpointer = Checkpointer(Path.cwd())
        except Exception as e:
            tracer.event("checkpoints_init_failed", payload={
                "type": type(e).__name__, "message": str(e)[:200],
            })
            checkpointer = None
        # Once-per-week stale-workspace prune. Best-effort; failures
        # silent so a slow disk doesn't delay session startup. The
        # function emits its own short-circuit when the marker says
        # "not due yet" so this is essentially free on most launches.
        try:
            pruned = prune_stale()
            for entry in pruned:
                tracer.event("checkpoint_pruned", payload=entry)
        except Exception:
            pass

    # P3.3: status line state. We sample the per-turn telemetry event so
    # we don't flood `fred_events` on chatty sessions: emit when the
    # session cost crosses a $0.01 boundary OR every 10 turns.
    last_status_cost_cents = [0]
    turns_since_status_event = [0]

    def _emit_status_line() -> None:
        cache_rate: float | None = None
        if renderer.session_in > 0 and renderer.session_cached > 0:
            cache_rate = renderer.session_cached / renderer.session_in
        repo_size: int | None = None
        if repo_map_obj is not None:
            stats = getattr(repo_map_obj, "last_scan_stats", None) or {}
            files_parsed = stats.get("files_parsed")
            if isinstance(files_parsed, int) and files_parsed > 0:
                repo_size = files_parsed
        try:
            from fred.tools.todo import get_todos
            todos = get_todos()
        except Exception:
            todos = []
        active = sum(1 for t in todos if getattr(t, "status", "") == "in_progress")
        done = sum(1 for t in todos if getattr(t, "status", "") == "completed")
        pending = sum(1 for t in todos if getattr(t, "status", "") == "pending")

        # Token / cost / cache stats now live in the persistent bottom
        # toolbar (`Renderer.footer_text`). The end-of-turn rule is
        # purely a visual divider for what the toolbar can't carry:
        # mode, repo size, and todo progress.
        # Read model_cfg through the box so /model, /flash, /pro
        # mutations are visible in the status line immediately.
        live_model_cfg = model_cfg_box[0]
        line = renderer.print_status_line(
            model_cfg=live_model_cfg,
            mode=current_mode(),
            repo_map_size=repo_size,
            todos_active=(active, done, pending) if (active + done + pending) > 0 else None,
        )

        turns_since_status_event[0] += 1
        cents = int(renderer.session_cost * 100)
        cost_crossed = cents != last_status_cost_cents[0]
        time_for_emit = turns_since_status_event[0] >= 10
        if cost_crossed or time_for_emit:
            last_status_cost_cents[0] = cents
            turns_since_status_event[0] = 0
            tracer.event("status_line_rendered", payload={
                "model": live_model_cfg.main_model,
                "mode": current_mode(),
                "output_style": current_output_style(),
                "session_in": renderer.session_in,
                "session_out": renderer.session_out,
                "session_cached": renderer.session_cached,
                "session_cost": round(renderer.session_cost, 6),
                "cache_hit_rate": round(cache_rate, 4) if cache_rate is not None else None,
                "repo_map_size": repo_size,
                "todos_total": active + done + pending,
                "todos_in_progress": active,
                "rendered_chars": len(line),
            })

    end_reason = "natural"
    try:
        if prompt is not None:
            try:
                # UserPromptSubmit hook (P2.4): exit-2 cancels the turn
                # before any model call. The one-shot path mirrors the
                # REPL behavior — we print a banner and return without
                # an error code so a successful "blocked" hook isn't
                # mistaken for a runtime crash by callers.
                up_outcome = run_hooks(
                    "UserPromptSubmit",
                    hooks_config,
                    tracer=tracer,
                    user_input=prompt,
                )
                if up_outcome is not None and up_outcome.blocked:
                    cmd = up_outcome.hook.command if up_outcome.hook else ""
                    console.print(f"[red]⊘ blocked by UserPromptSubmit hook: {cmd}[/]")
                    end_reason = "hook_blocked"
                    return
                session_state.update_from_user_input(prompt)
                run_turn(
                    prompt, messages, client, registry, renderer, permissions,
                    tracer=tracer, repo_map_provider=repo_map_provider,
                    hooks_config=hooks_config,
                    rule_set=rule_set,
                    chat_files_provider=_chat_files_provider,
                    checkpointer=checkpointer,
                    architect=architect,
                )
                # P3.3: status line after the one-shot turn so the user
                # sees the post-completion summary even when there's no
                # REPL prompt to follow. Errors here are non-fatal.
                try:
                    _emit_status_line()
                except Exception:
                    pass
            except KeyboardInterrupt:
                end_reason = "interrupt"
            return

        # Update status is shown inside the banner title now (folded from
        # the previous separate `maybe_print_notice` line).
        _render_banner(
            console, model_cfg, yolo, registry,
            plan_mode=current_mode() == "plan",
            output_style=current_output_style(),
            sandbox_mode=current_sandbox_mode(),
            approval_mode=permissions.approval_mode,
            mcp_session=mcp_session,
        )

        # Shift+Tab keybinding (P2.2). prompt_toolkit's KeyBindings table
        # captures `mode_state` and the tracer/console; pressing the
        # combination cycles plan ↔ act and emits a `mode_change` event.
        kb = KeyBindings()

        @kb.add("s-tab")
        def _toggle_mode_keybinding(event) -> None:
            # No scrollback echo — the bottom toolbar repaints with the
            # new mode within `refresh_interval`. Calling `console.print`
            # while prompt_toolkit owns the screen leaves residue from
            # the prompt + toolbar repaint when the key is mashed.
            old = current_mode()
            new: Mode = "plan" if old == "act" else "act"
            mode_state[0] = new
            tracer.event("mode_change", payload={
                "from": old, "to": new, "source": "keybind",
            })
            event.app.invalidate()

        # Persistent bottom toolbar: model · mode · turn · total · hotkeys.
        # The earlier rev disabled bottom_toolbar because returning None
        # left a stray white bar on macOS Terminal.app (the toolbar Window
        # allocates a row regardless of content). `Renderer.footer_text`
        # is contractually non-empty, which sidesteps that bug.
        # `refresh_interval=0.5` keeps the bar live so mode toggles
        # (shift+tab, /pro, etc.) reflect within half a second.
        def _bottom_toolbar() -> str:
            hotkeys = (
                "shift+tab plan" if current_mode() == "act" else "shift+tab act"
            )
            hotkeys += " · /exit"
            try:
                return renderer.footer_text(
                    model_cfg=model_cfg_box[0],
                    mode=current_mode(),
                    hotkey_hint=hotkeys,
                )
            except Exception:
                # Never let a formatter exception kill the input loop —
                # fall back to a static string so the bar still renders.
                return f"fred · {current_mode()} · {hotkeys}"

        # Override prompt_toolkit's default `bottom-toolbar` class so the
        # bar is dim text on the terminal background instead of the
        # default reverse-video white block. `noreverse` cancels the
        # `reverse` flag baked into prompt_toolkit's stock style.
        ptk_style = PTKStyle.from_dict({
            "bottom-toolbar": "noreverse fg:#8a8a8a bg:default",
            "bottom-toolbar.text": "noreverse fg:#8a8a8a bg:default",
        })
        session_input = PromptSession(
            message=HTML("<ansicyan>› </ansicyan>"),
            key_bindings=kb,
            completer=SlashCommandCompleter(
                on_open=lambda count: tracer.event(
                    "slash_dropdown_open", payload={"count": count}
                ),
            ),
            complete_while_typing=True,
            complete_style=CompleteStyle.COLUMN,
            reserve_space_for_menu=MENU_RESERVED_LINES,
            bottom_toolbar=_bottom_toolbar,
            refresh_interval=0.5,
            style=ptk_style,
        )
        while True:
            try:
                line = session_input.prompt()
            except EOFError:
                end_reason = "eof"
                console.print("\n[dim]bye.[/]")
                return
            except KeyboardInterrupt:
                end_reason = "interrupt"
                console.print("\n[dim]bye.[/]")
                return
            line = line.strip()
            if not line:
                continue
            if line.startswith("/"):
                parts = line.split(maxsplit=1)
                cmd = parts[0].lower()
                arg = parts[1] if len(parts) > 1 else None
                handler = SLASH_DISPATCH.get(cmd)
                if handler is None:
                    tracer.event("slash_command", payload={
                        "cmd": cmd, "unknown": True,
                    })
                    console.print(
                        f"[red]unknown command: {line}[/]  (try /help)"
                    )
                    continue
                slash_ctx = SlashContext(
                    arg=arg,
                    line=line,
                    cmd=cmd,
                    console=console,
                    renderer=renderer,
                    tracer=tracer,
                    client=client,
                    permissions=permissions,
                    registry_box=registry_box,
                    hooks_config=hooks_config,
                    rule_set=rule_set,
                    repo_map_obj=repo_map_obj,
                    repo_map_provider=repo_map_provider,
                    mcp_session=mcp_session,
                    checkpointer=checkpointer,
                    messages_box=messages_box,
                    model_cfg_box=model_cfg_box,
                    mode_state=mode_state,
                    output_style_state=output_style_state,
                    sandbox_token_box=sandbox_token_box,
                    session_state=session_state,
                    chat_files_provider=_chat_files_provider,
                )
                outcome = handler(slash_ctx)
                if outcome == "exit":
                    end_reason = "exit_cmd"
                    return
                continue
            if line.startswith("!"):
                replacement, raw_cmd, rc = expand_bang(line)
                console.print(f"[cyan]$ {raw_cmd}[/]")
                console.print(replacement)
                tracer.event("input_bang", payload={
                    "cmd": (raw_cmd or "")[:200],
                    "exit": rc,
                    "out_len": len(replacement),
                })
                line = replacement
            mention_count = count_mentions(line) if "@" in line else 0
            if mention_count:
                expanded = expand_mentions(line)
                tracer.event("input_mentions", payload={
                    "count": mention_count,
                    "in_len": len(line),
                    "out_len": len(expanded),
                })
                line = expanded

            # UserPromptSubmit hook (P2.4): exit-2 cancels the turn before
            # any model call. We print a brief banner and continue the REPL
            # so the user can edit + retry.
            up_outcome = run_hooks(
                "UserPromptSubmit",
                hooks_config,
                tracer=tracer,
                user_input=line,
            )
            if up_outcome is not None and up_outcome.blocked:
                cmd_short = up_outcome.hook.command if up_outcome.hook else ""
                console.print(f"[red]⊘ blocked by UserPromptSubmit hook: {cmd_short}[/]")
                continue

            session_state.update_from_user_input(line)
            # Read messages + registry through the boxes — /clear may
            # have rebound them since the loop iteration started, and
            # /compact may have spliced messages in place.
            run_turn(
                line, messages_box[0], client, registry_box[0],
                renderer, permissions,
                tracer=tracer, repo_map_provider=repo_map_provider,
                hooks_config=hooks_config,
                rule_set=rule_set,
                chat_files_provider=_chat_files_provider,
                checkpointer=checkpointer,
                architect=architect,
            )
            # Path tracking for the repo map's personalization vector
            # is driven by the tools themselves (`view`, `create_file`,
            # `str_replace` call `mark_tracked` on success via the
            # `_session_files` ContextVar installed at session start).
            # No post-turn sweep is needed — it would over-count
            # against the P1.4 prior-Read enforcement contract.
            #
            # show_todos() is intentionally NOT called here — every
            # exit path inside run_turn (natural_stop / attempt_completion /
            # runaway_guard / todo_write success) already prints todos.
            # A second call here produced two stacked Todos panels with
            # nothing between them on natural-stop turns.
            # P3.3: status line after each turn finishes. The line is
            # mutually exclusive with the assistant Live region (already
            # exited above by `run_turn`), so this is the right
            # integration seam. Defense-in-depth: never let a bad status
            # render kill the REPL.
            try:
                _emit_status_line()
            except Exception:
                pass
    except Exception as e:
        end_reason = "crash"
        tracer.event("api_error", payload={"type": type(e).__name__, "message": str(e)[:500]})
        raise
    finally:
        # P3.4: terminate any still-running background bash procs BEFORE
        # the Stop hook fires so the tracer event order is sensible
        # (bash_bg_kill before Stop). The ContextVar is still installed
        # at this point; cleanup() walks the session-scoped procs dict.
        try:
            _bash_bg.cleanup()
        except Exception:
            pass
        # P4.2: SIGTERM every MCP server with a brief grace period so
        # the tracer's `mcp_server_disconnect` events land before the
        # Stop hook fires. Graceful failures are swallowed; cleanup is
        # idempotent so a re-run during shutdown is safe.
        if mcp_session is not None:
            try:
                def _mcp_emit(kind: str, payload: dict) -> None:
                    try:
                        tracer.event(kind, payload=payload)
                    except Exception:
                        pass
                mcp_cleanup_servers(mcp_session, on_event=_mcp_emit)
            except Exception:
                pass
        # Stop hook (P2.4): best-effort, exit codes are advisory. We swallow
        # all exceptions because nothing in the shutdown path can recover
        # from a hook failure.
        try:
            run_hooks(
                "Stop",
                hooks_config,
                tracer=tracer,
                reason=end_reason,
            )
        except Exception:
            pass
        _bash_bg.reset_event_emitter(_bash_bg_emit_token)
        _bash_bg.reset_session_state(_bash_bg_state_token)
        reset_tracked_files(_tracked_files_token)
        reset_mode_state(_mode_state_token)
        _reset_todos(_todos_token)
        # Read the sandbox token through the box so /sandbox swaps
        # reset the *current* token (the one set most recently by a
        # slash handler), not the original.
        reset_sandbox_mode(sandbox_token_box[0])
        tracer.end_session(reason=end_reason)
        # 5s drain — gives the remote-writer path time to flush an
        # in-flight POST when the upstream is slow (5xx + retries).
        # Local Postgres writes are sub-second; this only matters for
        # the centralized telemetry path.
        tracer.drain(timeout=5.0)
