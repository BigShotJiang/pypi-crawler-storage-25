"""Model-slot routing helpers + `/model` and `/flash` / `/pro` topology."""
from __future__ import annotations

import os

from rich.console import Console

from fred.client import DSClient
from fred.config import ModelConfig


# Multi-model routing slots. Single source of truth for the slot
# vocabulary used by `/model`, `tracer.event("model_routed", ...)`, and
# the banner formatter.
_MODEL_SLOTS = ("main", "editor", "weak", "subagent_main")


# Architect mode pairs a heavy main model with a cheap editor pass that
# reviews/repairs file-edit tool_calls. `/pro` enables the topology
# (main=pro, editor+weak+subagent_main=flash); the dispatch itself
# lives in `fred.editor_pass` and runs from `session.run_session`.
class _RunMode(str):
    NORMAL = "normal"
    ARCHITECT = "architect"


def _format_model_line(model_cfg: ModelConfig) -> str:
    """Render the banner's `model:` value, expanding only when slots differ.

    When all four slots resolve to the same name we collapse to one
    label (`deepseek-v4-flash`) — the dominant case for users who haven't
    customized routing. When any slot diverges from main we tack on the
    differing ones so the banner makes the architect/editor topology
    visible:
      `deepseek-v4-pro (editor: …-flash, weak: …-flash, subagent_main: …-flash)`
    """
    main = model_cfg.main_model
    extras: list[str] = []
    if model_cfg.editor_model != main:
        extras.append(f"editor: {model_cfg.editor_model}")
    if model_cfg.weak_model != main:
        extras.append(f"weak: {model_cfg.weak_model}")
    if model_cfg.subagent_main_model != main:
        extras.append(f"subagent_main: {model_cfg.subagent_main_model}")
    if not extras:
        return main
    return f"{main} ({', '.join(extras)})"


def _persist_model_prefs(model_cfg: ModelConfig) -> None:
    """Mirror the live ModelConfig into ~/.config/fred/preferences.json so
    `/model` mutations survive across CLI restarts. Called after every
    successful model change.

    Best-effort: a write failure logs but does not abort the slash command.
    """
    from fred.preferences import load_preferences, save_preferences

    prefs = load_preferences()
    prefs.main_model = model_cfg.main_model
    prefs.editor_model = model_cfg.editor_model
    prefs.weak_model = model_cfg.weak_model
    prefs.subagent_main_model = model_cfg.subagent_main_model
    prefs.preset = _infer_preset_label(model_cfg)
    save_preferences(prefs)


def _infer_preset_label(model_cfg: ModelConfig) -> str | None:
    """Tag the active topology with an audit label.

    Returns one of:
      - ``"flash"`` if every slot is `deepseek-v4-flash`.
      - ``"architect"`` if main is `deepseek-v4-pro` and editor / weak /
        subagent_main are all `deepseek-v4-flash` (the `/pro` shape).
      - ``"premium"`` if every slot is `deepseek-v4-pro`.
      - ``None`` otherwise (custom shape).

    The label is purely informational — the canonical truth is the
    per-slot field. `_format_model_line` continues to render from those
    fields directly.
    """
    main = model_cfg.main_model
    others = (
        model_cfg.editor_model,
        model_cfg.weak_model,
        model_cfg.subagent_main_model,
    )
    if main == "deepseek-v4-flash" and all(o == "deepseek-v4-flash" for o in others):
        return "flash"
    if main == "deepseek-v4-pro" and all(o == "deepseek-v4-flash" for o in others):
        return "architect"
    if main == "deepseek-v4-pro" and all(o == "deepseek-v4-pro" for o in others):
        return "premium"
    return None


def _confirm_pro_switch(console: Console) -> bool:
    """Prompt the user to confirm enabling architect mode. Returns True
    if confirmed (or skipped via FRED_NO_CONFIRM_PRO).

    `/pro` enables architect topology: main runs deepseek-v4-pro for
    reasoning, while editor / weak / subagent_main stay on flash for
    cheap auxiliary work. The editor pass adds ~one extra flash call
    per file-edit tool_call. The first time a user flips to it, we
    want them to see that fact and acknowledge it. The persistent flag
    in preferences.json silences subsequent prompts.
    """
    if os.environ.get("FRED_NO_CONFIRM_PRO"):
        return True
    from fred.preferences import load_preferences, save_preferences

    prefs = load_preferences()
    if prefs.warned_about_architect:
        return True
    console.print(
        "[yellow]Enabling architect mode.[/]\n"
        "  main           = deepseek-v4-pro    "
        "(~12× output cost vs flash)\n"
        "  editor         = deepseek-v4-flash  "
        "(one extra call per file-edit tool_call)\n"
        "  weak           = deepseek-v4-flash  (compaction)\n"
        "  subagent_main  = deepseek-v4-flash  (subagents)\n"
        "  Typical mixed-coding turn: ~$0.012 vs ~$0.007 on flash-only.\n"
        "  Set FRED_NO_CONFIRM_PRO=1 to silence this prompt for scripts."
    )
    try:
        answer = input("Continue? [Y/n] ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        console.print("[dim]cancelled.[/]")
        return False
    if answer in ("", "y", "yes"):
        prefs.warned_about_architect = True
        save_preferences(prefs)
        return True
    console.print("[dim]cancelled.[/]")
    return False


def _handle_model_slash(
    arg: str | None,
    *,
    client: DSClient,
    model_cfg: ModelConfig,
    console: Console,
    tracer,
) -> ModelConfig:
    """Handle `/model [...]` invocations. Returns the (possibly updated) config.

    Three forms:
      - `/model`               — print all four slots; no mutation.
      - `/model <name>`        — backwards compat: swap main slot.
      - `/model <slot> <name>` — slot-aware: swap one of
        main|editor|weak|subagent_main.

    `client.model` is kept in sync with the main slot so the existing
    `client.model` direct-assignment path used by the agent loop still
    routes correctly. Editor, weak, and subagent_main slots live on
    `model_cfg`; the callsites that want them call
    `client.with_model(model_cfg.editor_model)` at dispatch time.

    Side-effects:
      - tracer event `slash_command` always fires.
      - tracer event `model_routed` fires only on actual change, with
        `{slot, model, reason: "user_/model"}`.
    """
    if not arg:
        # No-arg form: print all four slots, regardless of whether they
        # match. Telemetry records `changed=False` for analysis parity.
        from fred.preferences import load_preferences

        prefs_preset = load_preferences().preset
        preset_line = f"\npreset: {prefs_preset}" if prefs_preset else ""
        console.print(
            f"[dim]main:           {model_cfg.main_model}\n"
            f"editor:         {model_cfg.editor_model}\n"
            f"weak:           {model_cfg.weak_model}\n"
            f"subagent_main:  {model_cfg.subagent_main_model}{preset_line}[/]"
        )
        tracer.event("slash_command", payload={
            "cmd": "/model",
            "main": model_cfg.main_model,
            "editor": model_cfg.editor_model,
            "weak": model_cfg.weak_model,
            "subagent_main": model_cfg.subagent_main_model,
            "changed": False,
        })
        return model_cfg

    parts = arg.strip().split(maxsplit=1)
    first = parts[0]
    if first in _MODEL_SLOTS and len(parts) == 2:
        # Slot-aware form: `/model <slot> <name>`.
        slot = first
        new_name = parts[1].strip()
        old_name = model_cfg.for_slot(slot)
        if slot == "main":
            client.model = new_name
        model_cfg = _replace_slot(model_cfg, slot, new_name)
        changed = new_name != old_name
        console.print(f"[dim]{slot} → {new_name}[/]")
        # When the user pins main but leaves the others alone, surface
        # the routing so the user sees the divergence at swap time.
        if slot == "main" and (
            model_cfg.editor_model != new_name
            or model_cfg.weak_model != new_name
            or model_cfg.subagent_main_model != new_name
        ):
            console.print(
                f"[dim]  (editor: {model_cfg.editor_model}, "
                f"weak: {model_cfg.weak_model}, "
                f"subagent_main: {model_cfg.subagent_main_model})[/]"
            )
        tracer.event("slash_command", payload={
            "cmd": "/model",
            "slot": slot,
            "model": new_name,
            "previous": old_name,
            "changed": changed,
        })
        if changed:
            tracer.event("model_routed", payload={
                "slot": slot,
                "model": new_name,
                "reason": "user_/model",
            })
            _persist_model_prefs(model_cfg)
        return model_cfg

    if first in _MODEL_SLOTS and len(parts) == 1:
        # `/model main` etc. without a name — likely a typo; show usage
        # and don't mutate.
        console.print(
            "[red]usage: /model <slot> <name>  "
            "(slot in main|editor|weak|subagent_main)[/]"
        )
        tracer.event("slash_command", payload={
            "cmd": "/model", "slot": first, "error": "missing_name",
        })
        return model_cfg

    # Backwards-compat: `/model <name>` (single token, not a slot keyword)
    # swaps the main slot.
    new_name = arg.strip()
    old_main = client.model
    client.model = new_name
    model_cfg = _replace_slot(model_cfg, "main", new_name)
    changed = new_name != old_main
    console.print(f"[dim]model → {new_name}[/]")
    if changed and (
        model_cfg.editor_model != new_name
        or model_cfg.weak_model != new_name
        or model_cfg.subagent_main_model != new_name
    ):
        console.print(
            f"[dim]  (editor: {model_cfg.editor_model}, "
            f"weak: {model_cfg.weak_model}, "
            f"subagent_main: {model_cfg.subagent_main_model})[/]"
        )
    tracer.event("slash_command", payload={
        "cmd": "/model",
        "model": new_name,
        "previous": old_main,
        "changed": changed,
    })
    if changed:
        tracer.event("model_routed", payload={
            "slot": "main",
            "model": new_name,
            "reason": "user_/model",
        })
        _persist_model_prefs(model_cfg)
    return model_cfg


def _replace_slot(model_cfg: ModelConfig, slot: str, new_name: str) -> ModelConfig:
    """Return a new ModelConfig with one slot swapped, preserving the rest."""
    return ModelConfig(
        main_model=new_name if slot == "main" else model_cfg.main_model,
        editor_model=new_name if slot == "editor" else model_cfg.editor_model,
        weak_model=new_name if slot == "weak" else model_cfg.weak_model,
        subagent_main_model=(
            new_name if slot == "subagent_main" else model_cfg.subagent_main_model
        ),
    )


def _apply_topology(
    cmd: str,
    *,
    client: DSClient,
    model_cfg: ModelConfig,
    console: Console,
    tracer,
) -> ModelConfig:
    """Apply a named topology preset (`/flash` or `/pro`) to all four slots.

    `/flash` collapses every slot to deepseek-v4-flash. `/pro` enables
    architect topology: main=deepseek-v4-pro, others=deepseek-v4-flash.

    Side effects (per slot that actually changed):
      - tracer event `model_routed` with `reason="user_<cmd>"`.
      - one combined `slash_command` event with the resulting topology.
    Persistence is a single `_persist_model_prefs` call after all slot
    swaps so the JSON file stays consistent.
    """
    flash = "deepseek-v4-flash"
    pro = "deepseek-v4-pro"
    if cmd == "/flash":
        target = ModelConfig(
            main_model=flash,
            editor_model=flash,
            weak_model=flash,
            subagent_main_model=flash,
        )
    else:  # /pro
        target = ModelConfig(
            main_model=pro,
            editor_model=flash,
            weak_model=flash,
            subagent_main_model=flash,
        )

    # Keep client.model in sync with the main slot (the agent loop
    # reads this directly when constructing each iteration's request).
    client.model = target.main_model

    reason = f"user_{cmd}"
    changed: list[tuple[str, str, str]] = []
    for slot in _MODEL_SLOTS:
        old = model_cfg.for_slot(slot)
        new = target.for_slot(slot)
        if old != new:
            changed.append((slot, old, new))
            tracer.event("model_routed", payload={
                "slot": slot,
                "model": new,
                "previous": old,
                "reason": reason,
            })

    tracer.event("slash_command", payload={
        "cmd": cmd,
        "main": target.main_model,
        "editor": target.editor_model,
        "weak": target.weak_model,
        "subagent_main": target.subagent_main_model,
        "changed": bool(changed),
    })

    if changed:
        _persist_model_prefs(target)
        console.print(f"[dim]{cmd} → {_format_model_line(target)}[/]")
    else:
        console.print(f"[dim]{cmd} (already active)[/]")

    return target
