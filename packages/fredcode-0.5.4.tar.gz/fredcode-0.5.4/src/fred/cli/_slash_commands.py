"""Slash command dispatcher table + 27 per-command handlers (PR-12).

Per-handler ``tracer.event("slash_command", payload={...})`` calls stay
inside each handler — payload shapes vary per command and the analytics
pipeline depends on them being byte-identical to the prior if/elif chain.

Box-list pattern: state that the chain previously rebound via lexical
scope (registry, messages, model_cfg, _sandbox_mode_token) lives behind
a one-element list so handlers can mutate the slot and downstream
consumers — including the post-turn ``run_turn(...)`` call — read through
the box. Without this, /clear would silently leave run_turn pointing at
the pre-clear registry.
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Literal

from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from fred.checkpoints import Checkpointer
from fred.cli._init import _handle_init_slash
from fred.cli._main import Mode, OutputStyle
from fred.cli._models import (
    _apply_topology,
    _confirm_pro_switch,
    _handle_model_slash,
)
from fred.cli._session_state import _SessionState, _build_initial_messages
from fred.cli._telemetry import _handle_telemetry_slash, _print_server_cost
from fred.client import DSClient
from fred.config import ModelConfig, load_model_config
from fred.hooks import VALID_EVENTS
from fred.mcp import summarize_servers as mcp_summarize_servers
from fred.permissions import (
    PermissionPolicy,
    add_rule as add_permission_rule,
    list_active_rules,
    normalize_approval_mode,
    remove_rule as remove_permission_rule,
)
from fred.render import Renderer
from fred.repomap import RepoMap
from fred.rules import RuleSet
from fred.tools._sandbox import (
    current_sandbox_mode,
    normalize_mode as normalize_sandbox_mode,
    reset_sandbox_mode,
    set_sandbox_mode,
)
from fred.tools.registry import Registry


SLASH_HELP = """\
Slash commands:
  /help                       show this help
  /clear                      reset conversation (keeps system prompt)
  /tools                      list registered tools
  /todos                      show current todo list
  /yolo                       toggle permission bypass
  /sandbox [mode|approval m]  show or set sandbox/approval mode (P4.1)
  /cost                       show running session cost
  /think on|off               toggle thinking display
  /think show                 reprint last turn's thinking
  /save [path]                dump transcript as JSONL
  /init                       generate AGENTS.md by scanning the repo
  /model                      show all four model slots (main/editor/weak/subagent_main)
  /model <name>               swap the main slot (backwards compat)
  /model <slot> <n>           swap one of main|editor|weak|subagent_main
  /flash                      collapse all four slots to deepseek-v4-flash
  /pro                        enable architect: main=pro, editor+weak+subagent_main=flash
  /last [n]                   reprint Nth-most-recent tool result (default 1)
  /repomap                    print the current rendered repo map (debug)
  /rules                      list active + available rules (.fred/rules/*.md)
  /hooks                      list active hooks per event (.fred/settings.json)
  /perms                      list active permission rules (allow/ask/deny)
  /perms add <rule> <list>    append rule to local file (list: allow|ask|deny)
  /perms remove <rule>        remove rule from any list in local file
  /mcp                        list connected MCP servers + their tool counts
  /subagents                  list subagent profiles + their tool subsets
  /mode plan|act|toggle       switch between plan and act mode (Shift+Tab cycles)
  /style concise|explanatory  flip output style for the next turn
  /compact [focus]            summarize older history (focus hint optional)
  /checkpoints                list recent shadow-git checkpoints (last 20)
  /restore <sha>              restore workspace to a checkpoint (with confirm)
  /telemetry                  show telemetry routing (default sends to fredcode.net)
  /telemetry on               clear opt-out (effective next session)
  /telemetry off              opt out of behavioral telemetry (effective next session)
  /exit                       quit
"""


@dataclass
class SlashContext:
    """All state a slash handler may read or rebind.

    Plain values (`arg`, `line`, `cmd`, `console`, `renderer`, `tracer`,
    `client`, `permissions`, `hooks_config`, `rule_set`, `repo_map_obj`,
    `repo_map_provider`, `mcp_session`, `checkpointer`, `mode_state`,
    `output_style_state`, `session_state`, `chat_files_provider`) are
    references — handlers mutate them in place where the original
    if/elif chain did.

    Box-lists (`registry_box`, `messages_box`, `model_cfg_box`,
    `sandbox_token_box`) replace the prior closure-rebind contract so
    /clear, /compact, /sandbox, /model, /flash, /pro can swap the
    pointer and have the post-turn `run_turn(...)` call see the new
    value.
    """

    arg: str | None
    line: str
    cmd: str
    console: Console
    renderer: Renderer
    tracer: Any
    client: DSClient
    permissions: PermissionPolicy
    registry_box: list[Registry]
    hooks_config: dict
    rule_set: RuleSet | None
    repo_map_obj: RepoMap | None
    repo_map_provider: Callable[[], str] | None
    mcp_session: Any
    checkpointer: Checkpointer | None
    messages_box: list[list[dict]]
    model_cfg_box: list[ModelConfig]
    mode_state: list[str]
    output_style_state: list[str]
    sandbox_token_box: list[Any]
    session_state: "_SessionState"
    chat_files_provider: Callable[[], set[Path]]


def _ctx_current_mode(ctx: SlashContext) -> "Mode":
    return "plan" if ctx.mode_state[0] == "plan" else "act"


def _ctx_current_output_style(ctx: SlashContext) -> "OutputStyle":
    v = ctx.output_style_state[0]
    return "explanatory" if v == "explanatory" else "concise"


def _handle_exit(ctx: SlashContext) -> Literal["continue", "exit"]:
    ctx.tracer.event("slash_command", payload={"cmd": ctx.cmd})
    return "exit"


def _handle_help(ctx: SlashContext) -> Literal["continue", "exit"]:
    ctx.tracer.event("slash_command", payload={"cmd": ctx.cmd})
    ctx.console.print(SLASH_HELP)
    return "continue"


def _handle_clear(ctx: SlashContext) -> Literal["continue", "exit"]:
    ctx.tracer.event("slash_command", payload={"cmd": ctx.cmd})
    # /clear rebuilds the system prompt; carry the live mode AND the
    # live output style through so the prompt template matches the
    # post-clear contract (act vs plan, concise vs explanatory).
    new_messages, new_registry = _build_initial_messages(
        mode=_ctx_current_mode(ctx),
        output_style=_ctx_current_output_style(ctx),
    )
    ctx.messages_box[0] = new_messages
    ctx.registry_box[0] = new_registry
    ctx.console.print("[dim]conversation cleared.[/]")
    return "continue"


def _handle_tools(ctx: SlashContext) -> Literal["continue", "exit"]:
    ctx.tracer.event("slash_command", payload={"cmd": ctx.cmd})
    registry = ctx.registry_box[0]
    for name in registry.names():
        desc = (registry.get(name).description or "").splitlines()[0]
        ctx.console.print(f"  [bold]{name}[/]  [dim]{desc}[/]")
    return "continue"


def _handle_todos(ctx: SlashContext) -> Literal["continue", "exit"]:
    # Between-turn inspection; same render path as the post-turn
    # show_todos() — empty list still prints a one-line note so the
    # user gets feedback either way.
    ctx.tracer.event("slash_command", payload={"cmd": ctx.cmd})
    from fred.tools.todo import get_todos
    if get_todos():
        ctx.renderer.show_todos()
    else:
        ctx.console.print("[dim]no todos.[/]")
    return "continue"


def _handle_yolo(ctx: SlashContext) -> Literal["continue", "exit"]:
    ctx.permissions.yolo = not ctx.permissions.yolo
    ctx.tracer.event("slash_command", payload={
        "cmd": ctx.cmd, "yolo": ctx.permissions.yolo,
    })
    ctx.console.print(
        f"[dim]YOLO {'on' if ctx.permissions.yolo else 'off'}.[/]"
    )
    return "continue"


def _handle_sandbox(ctx: SlashContext) -> Literal["continue", "exit"]:
    # P4.1: print current sandbox + approval modes, with an optional
    # inline mode swap (`/sandbox ro` etc).
    cmd = ctx.cmd
    arg = ctx.arg
    sub = (arg or "").strip().lower()
    if not sub:
        cur_sb = current_sandbox_mode()
        cur_app = ctx.permissions.approval_mode
        ctx.tracer.event("slash_command", payload={
            "cmd": cmd, "sandbox": cur_sb, "approval": cur_app,
        })
        ctx.console.print(
            f"[dim]sandbox:  {cur_sb}\n"
            f"approval: {cur_app}\n"
            f"\n"
            f"usage: /sandbox <mode>          "
            f"(mode: ro|workspace-write|full)\n"
            f"       /sandbox approval <mode> "
            f"(mode: untrusted|on_request|never)[/]"
        )
        return "continue"
    parts2 = sub.split(maxsplit=1)
    if parts2[0] == "approval" and len(parts2) == 2:
        new_app = normalize_approval_mode(parts2[1])
        if new_app is None:
            ctx.tracer.event("slash_command", payload={
                "cmd": cmd, "axis": "approval",
                "arg": parts2[1], "error": "invalid_mode",
            })
            ctx.console.print(
                "[red]usage: /sandbox approval "
                "untrusted|on_request|never[/]"
            )
            return "continue"
        old_app = ctx.permissions.approval_mode
        ctx.permissions.approval_mode = new_app
        ctx.tracer.event("slash_command", payload={
            "cmd": cmd, "axis": "approval",
            "from": old_app, "to": new_app,
        })
        ctx.console.print(f"[dim]approval → {new_app}[/]")
        return "continue"
    new_sb = normalize_sandbox_mode(parts2[0])
    if new_sb is None:
        ctx.tracer.event("slash_command", payload={
            "cmd": cmd, "axis": "sandbox",
            "arg": sub, "error": "invalid_mode",
        })
        ctx.console.print(
            "[red]usage: /sandbox <mode>  "
            "(mode: ro|workspace-write|full) | "
            "/sandbox approval <mode>[/]"
        )
        return "continue"
    old_sb = current_sandbox_mode()
    # Re-install the ContextVar with the new mode. Token must be reset
    # via the box-list so the outer finally: block sees the *current*
    # token (not the original one) when it calls reset_sandbox_mode.
    reset_sandbox_mode(ctx.sandbox_token_box[0])
    ctx.sandbox_token_box[0] = set_sandbox_mode(new_sb)
    ctx.tracer.event("slash_command", payload={
        "cmd": cmd, "axis": "sandbox",
        "from": old_sb, "to": new_sb,
    })
    ctx.console.print(f"[dim]sandbox → {new_sb}[/]")
    return "continue"


def _handle_cost(ctx: SlashContext) -> Literal["continue", "exit"]:
    ctx.tracer.event("slash_command", payload={"cmd": ctx.cmd})
    ctx.console.print(ctx.renderer.cost_summary())
    _print_server_cost(ctx.console)
    return "continue"


def _handle_think(ctx: SlashContext) -> Literal["continue", "exit"]:
    ctx.tracer.event("slash_command", payload={
        "cmd": ctx.cmd, "arg": ctx.arg,
    })
    sub = (ctx.arg or "").strip().lower()
    if sub in ("on", "off"):
        ctx.renderer.show_thinking = (sub == "on")
        ctx.console.print(f"[dim]thinking display {sub}.[/]")
    elif sub == "show":
        if ctx.renderer.last_reasoning:
            ctx.console.print(Panel(
                ctx.renderer.last_reasoning,
                title="thinking (last turn)",
                title_align="left",
                border_style="grey50",
                expand=False,
            ))
        else:
            ctx.console.print("[dim]no recent reasoning.[/]")
    else:
        ctx.console.print("[red]usage: /think on|off|show[/]")
    return "continue"


def _handle_save(ctx: SlashContext) -> Literal["continue", "exit"]:
    arg = ctx.arg
    cmd = ctx.cmd
    messages = ctx.messages_box[0]
    path = arg.strip() if arg else f"fred-transcript-{int(time.time())}.jsonl"
    saved = False
    error = None
    try:
        with open(path, "w") as f:
            for m in messages:
                f.write(json.dumps(m) + "\n")
        saved = True
        ctx.console.print(
            f"[dim]saved {len(messages)} messages to {path}[/]"
        )
    except OSError as e:
        error = f"{type(e).__name__}: {e}"
        ctx.console.print(f"[red]save failed: {e}[/]")
    ctx.tracer.event("slash_command", payload={
        "cmd": cmd, "path": path, "messages": len(messages),
        "saved": saved, "error": error,
    })
    return "continue"


def _handle_init(ctx: SlashContext) -> Literal["continue", "exit"]:
    outcome = _handle_init_slash(
        client=ctx.client,
        registry=ctx.registry_box[0],
        permissions=ctx.permissions,
        renderer=ctx.renderer,
        console=ctx.console,
        tracer=ctx.tracer,
        repo_map_provider=ctx.repo_map_provider,
    )
    ctx.tracer.event("slash_command", payload={
        "cmd": ctx.cmd, "outcome": outcome,
    })
    return "continue"


def _handle_model(ctx: SlashContext) -> Literal["continue", "exit"]:
    ctx.model_cfg_box[0] = _handle_model_slash(
        ctx.arg,
        client=ctx.client,
        model_cfg=ctx.model_cfg_box[0],
        console=ctx.console,
        tracer=ctx.tracer,
    )
    return "continue"


def _handle_telemetry(ctx: SlashContext) -> Literal["continue", "exit"]:
    _handle_telemetry_slash(
        ctx.arg, console=ctx.console, tracer=ctx.tracer,
    )
    return "continue"


def _handle_topology(ctx: SlashContext) -> Literal["continue", "exit"]:
    """Shared handler for `/flash` and `/pro` (both apply a topology preset)."""
    cmd = ctx.cmd
    if cmd == "/pro" and not _confirm_pro_switch(ctx.console):
        ctx.tracer.event("slash_command", payload={
            "cmd": cmd, "cancelled": True,
        })
        return "continue"
    ctx.model_cfg_box[0] = _apply_topology(
        cmd,
        client=ctx.client,
        model_cfg=ctx.model_cfg_box[0],
        console=ctx.console,
        tracer=ctx.tracer,
    )
    return "continue"


def _handle_repomap(ctx: SlashContext) -> Literal["continue", "exit"]:
    ctx.tracer.event("slash_command", payload={"cmd": ctx.cmd})
    if ctx.repo_map_obj is None:
        ctx.console.print("[dim]repo map disabled or scan failed.[/]")
        return "continue"
    rendered = ctx.repo_map_obj.get_repo_map(
        chat_files=set(),
        mentioned_idents=set(ctx.session_state.mentioned_idents),
        viewed_files=set(ctx.session_state.viewed_files),
        mentioned_files=set(ctx.session_state.mentioned_files),
    )
    if not rendered:
        ctx.console.print("[dim](repo map empty)[/]")
    else:
        # Print as a Panel so the user can see exactly what the model
        # is being shown each turn.
        ctx.console.print(Panel(
            rendered,
            title="repo map",
            title_align="left",
            border_style="dim",
            expand=False,
        ))
    return "continue"


def _handle_rules(ctx: SlashContext) -> Literal["continue", "exit"]:
    # P3.2: list active + available rules. "Active" = rules that
    # would render in THIS moment's block given current chat_files +
    # the (session-scoped) explicit set. We can't reach the explicit
    # set from outside `run_session` cleanly; the live set is owned
    # by the loop. Between turns, the explicit set is whatever the
    # most recent run_session mutated — exposed via
    # `request_rule_tool`'s `get_request_rule_context()` ContextVar
    # reader.
    cmd = ctx.cmd
    ctx.tracer.event("slash_command", payload={"cmd": cmd})
    rule_set = ctx.rule_set
    if rule_set is None or not rule_set.rules:
        ctx.console.print(
            "[dim]no rules loaded. Add `.fred/rules/*.md` "
            "(or `~/.fred/rules/*.md`) to enable.[/]"
        )
        return "continue"
    from fred.tools.request_rule import get_request_rule_context
    rrc = get_request_rule_context()
    explicit = set(rrc.explicit) if rrc is not None else set()
    active_rules = rule_set.applicable_for(
        chat_files=ctx.chat_files_provider(),
        explicit=explicit,
    )
    active_names = {r.name for r in active_rules}
    available_rules = rule_set.available_descriptions(
        active_names=active_names
    )
    body = Text()
    body.append("active\n", style="bold")
    if active_rules:
        for r in active_rules:
            tag = (
                "always" if r.always_apply
                else "requested" if r.name in explicit
                else "glob"
            )
            body.append(
                f"  • {r.name}  ", style=""
            )
            body.append(f"[{tag}]", style="dim")
            if r.description:
                desc = r.description.splitlines()[0]
                body.append(f"  {desc}\n", style="dim")
            else:
                body.append("\n")
    else:
        body.append("  (none)\n", style="dim")
    body.append("\navailable (request via request_rule)\n", style="bold")
    if available_rules:
        for r in available_rules:
            body.append(f"  • {r.name}  ", style="")
            desc = (
                r.description.splitlines()[0]
                if r.description else ""
            )
            body.append(f"{desc}\n", style="dim")
    else:
        body.append("  (none)\n", style="dim")
    ctx.console.print(Panel(
        body,
        title="rules",
        title_align="left",
        border_style="dim",
        expand=False,
    ))
    return "continue"


def _handle_subagents(ctx: SlashContext) -> Literal["continue", "exit"]:
    # P2.1: surface the active agent profiles. `general` resolves
    # dynamically from the parent registry, so its concrete tool set
    # varies as new tools land.
    ctx.tracer.event("slash_command", payload={"cmd": ctx.cmd})
    from fred.tools.agent_tool import AGENT_PROFILES, subset_for  # noqa: F401
    registry = ctx.registry_box[0]
    rows: list[str] = []
    for label in ("explore", "plan", "general"):
        try:
            tools_in = sorted(subset_for(label, registry))
        except ValueError:
            tools_in = []
        rows.append(
            f"  [bold]{label}[/]  [dim]({len(tools_in)} tools)[/]  "
            f"{', '.join(tools_in) if tools_in else '(none)'}"
        )
    ctx.console.print(Panel(
        "\n".join(rows),
        title="subagent profiles",
        title_align="left",
        border_style="dim",
        expand=False,
    ))
    return "continue"


def _handle_mode(ctx: SlashContext) -> Literal["continue", "exit"]:
    cmd = ctx.cmd
    arg = ctx.arg
    sub = (arg or "").strip().lower()
    old = _ctx_current_mode(ctx)
    new: "Mode | None" = None
    if sub in ("plan", "act"):
        new = "plan" if sub == "plan" else "act"
    elif sub in ("toggle", ""):
        new = "plan" if old == "act" else "act"
    else:
        ctx.tracer.event("slash_command", payload={
            "cmd": cmd, "arg": arg, "error": "invalid_mode",
        })
        ctx.console.print("[red]usage: /mode plan|act|toggle[/]")
        return "continue"
    ctx.tracer.event("slash_command", payload={
        "cmd": cmd, "arg": sub or "toggle", "from": old, "to": new,
    })
    if new == old:
        ctx.console.print(f"[dim]mode: {new} (unchanged)[/]")
        return "continue"
    ctx.mode_state[0] = new
    ctx.tracer.event("mode_change", payload={
        "from": old, "to": new, "source": "slash",
    })
    ctx.console.print(f"[dim]mode → {new}[/]")
    return "continue"


def _handle_style(ctx: SlashContext) -> Literal["continue", "exit"]:
    # P3.3: flip the output style for the next turn. The in-flight
    # system prompt isn't rebuilt here — `/clear` rebuilds the prompt,
    # and the next /clear after a /style change picks up the new
    # fragment. We do update the `output_style_state` so subsequent
    # banner re-renders, status lines, and telemetry snapshots reflect
    # the choice immediately.
    cmd = ctx.cmd
    arg = ctx.arg
    sub = (arg or "").strip().lower()
    old_style = _ctx_current_output_style(ctx)
    new_style: "OutputStyle | None" = None
    if sub in ("concise", "explanatory"):
        new_style = "concise" if sub == "concise" else "explanatory"
    elif sub in ("toggle", ""):
        new_style = (
            "explanatory" if old_style == "concise" else "concise"
        )
    else:
        ctx.tracer.event("slash_command", payload={
            "cmd": cmd, "arg": arg, "error": "invalid_style",
        })
        ctx.console.print(
            "[red]usage: /style concise|explanatory|toggle[/]"
        )
        return "continue"
    ctx.tracer.event("slash_command", payload={
        "cmd": cmd,
        "arg": sub or "toggle",
        "from": old_style,
        "to": new_style,
    })
    if new_style == old_style:
        ctx.console.print(
            f"[dim]output style: {new_style} (unchanged)[/]"
        )
        return "continue"
    ctx.output_style_state[0] = new_style
    # The system-prompt fragment for `explanatory` lands in the prefix
    # on the next /clear (or the next session). Document the lag in
    # the user-facing line so they know to /clear if they want it
    # active for the very next call.
    ctx.tracer.event("output_style_change", payload={
        "from": old_style,
        "to": new_style,
        "source": "slash",
    })
    ctx.console.print(
        f"[dim]output style → {new_style} "
        f"(/clear to apply to current conversation)[/]"
    )
    return "continue"


def _handle_compact(ctx: SlashContext) -> Literal["continue", "exit"]:
    # Manual compaction (P2.5). The optional `arg` becomes the focus
    # hint passed to the weak-model summary.
    cmd = ctx.cmd
    arg = ctx.arg
    focus = arg.strip() if arg else None
    ctx.tracer.event("slash_command", payload={
        "cmd": cmd, "focus": focus,
    })
    weak_cfg = load_model_config()
    weak_client = ctx.client.with_model(weak_cfg.weak_model)
    messages = ctx.messages_box[0]
    # WHY: tests monkeypatch via fred.cli — keep this resolution path.
    # `tests/test_compaction.py` does
    # `monkeypatch.setattr("fred.cli.compact_messages", ...)`. Resolving
    # via the ``fred.cli`` package shim here lets the patch take effect
    # without forcing the test to know about the new module split.
    import fred.cli as _cli_module
    compact_messages = _cli_module.compact_messages
    try:
        new_messages, stats = compact_messages(
            messages, weak_client, focus=focus,
            tracer=ctx.tracer, turn=0,
        )
    except Exception as exc:
        ctx.console.print(
            f"[red]compaction failed:[/] {type(exc).__name__}: {exc}"
        )
        ctx.tracer.event("compaction_run", payload={
            "trigger": "manual",
            "before_tokens": 0,
            "after_tokens": 0,
            "summary_chars": 0,
            "focus": focus,
            "elapsed_ms": 0,
            "error_type": type(exc).__name__,
        })
        return "continue"
    messages[:] = new_messages
    ctx.tracer.event("compaction_run", payload={
        "trigger": "manual",
        "before_tokens": stats["before_tokens"],
        "after_tokens": stats["after_tokens"],
        "summary_chars": stats["summary_chars"],
        "focus": focus,
        "elapsed_ms": stats["elapsed_ms"],
        "usage": stats.get("usage"),
        "cost_billed_microcents": stats.get(
            "cost_billed_microcents", 0,
        ),
    })
    ctx.renderer.compaction_notification(
        stats["before_tokens"], stats["after_tokens"], focus,
    )
    if stats.get("usage"):
        ctx.renderer.show_usage(
            stats["usage"],
            weak_cfg.weak_model,
            slot="weak",
        )
    return "continue"


def _handle_last(ctx: SlashContext) -> Literal["continue", "exit"]:
    arg = ctx.arg
    cmd = ctx.cmd
    try:
        n = int(arg) if arg else 1
    except ValueError:
        ctx.tracer.event("slash_command", payload={
            "cmd": cmd, "arg": arg, "error": "invalid_int",
        })
        ctx.console.print(
            f"[red]/last expects an integer (got {arg!r})[/]"
        )
        return "continue"
    items = list(ctx.renderer.recent_results)
    idx = len(items) - n
    found = bool(items) and 0 <= idx < len(items) and n > 0
    ctx.tracer.event("slash_command", payload={
        "cmd": cmd, "n": n, "found": found,
        "available": len(items),
    })
    if not found:
        ctx.console.print("[dim]no recent result at that position.[/]")
        return "continue"
    title, full = items[idx]
    ctx.console.print(Panel(
        full or "(empty)",
        title=title,
        title_align="left",
        border_style="dim",
        expand=False,
    ))
    return "continue"


def _handle_mcp(ctx: SlashContext) -> Literal["continue", "exit"]:
    # P4.2: list connected MCP servers + tool counts.
    cmd = ctx.cmd
    rows = (
        mcp_summarize_servers(ctx.mcp_session) if ctx.mcp_session else []
    )
    ctx.tracer.event("slash_command", payload={
        "cmd": cmd, "total": len(rows),
    })
    if not rows:
        ctx.console.print(
            "[dim]no MCP servers configured. Add them to "
            ".fred/settings.json under `mcp`.[/]"
        )
        return "continue"
    body = Text()
    for row in rows:
        # Status colour: green/yellow/red. The status vocabulary
        # mirrors `mcp.lifecycle` constants.
        status = row["status"]
        colour = (
            "green" if status == "connected"
            else "red" if status == "crashed"
            else "dim"
        )
        body.append(f"{row['name']}", style="bold")
        body.append(f"  [{status}]", style=colour)
        body.append(
            f"  · {row['transport']}"
            f"  · {row['tool_count']} tool"
            f"{'s' if row['tool_count'] != 1 else ''}"
            f"  · {row['init_ms']}ms\n",
            style="dim",
        )
        if row["error"]:
            err_short = (
                row["error"] if len(row["error"]) <= 80
                else row["error"][:80] + "…"
            )
            body.append(f"  error: {err_short}\n", style="red")
        for tool_name in row["tools"][:8]:
            body.append(
                f"  • mcp__{row['name']}__{tool_name}\n",
                style="dim",
            )
        if len(row["tools"]) > 8:
            body.append(
                f"  …and {len(row['tools']) - 8} more\n",
                style="dim",
            )
    ctx.console.print(Panel(
        body,
        title="MCP servers",
        title_align="left",
        border_style="cyan",
        expand=False,
    ))
    return "continue"


def _handle_hooks(ctx: SlashContext) -> Literal["continue", "exit"]:
    cmd = ctx.cmd
    hooks_config = ctx.hooks_config
    total = sum(len(hooks_config.get(ev, [])) for ev in VALID_EVENTS)
    ctx.tracer.event("slash_command", payload={
        "cmd": cmd, "total": total,
    })
    if total == 0:
        ctx.console.print(
            "[dim]no hooks configured. Add them to "
            ".fred/settings.json or ~/.fred/settings.json.[/]"
        )
        return "continue"
    body = Text()
    for ev in VALID_EVENTS:
        entries = hooks_config.get(ev, [])
        if not entries:
            continue
        body.append(f"{ev}\n", style="bold")
        for h in entries:
            cmd_short = (
                h.command if len(h.command) <= 60
                else h.command[:60] + "…"
            )
            matcher_str = h.matcher or "*"
            body.append(
                f"  • [{matcher_str}]  {cmd_short}  "
                f"(timeout {h.timeout}s)\n",
                style="dim",
            )
    ctx.console.print(Panel(
        body,
        title="active hooks",
        title_align="left",
        border_style="cyan",
        expand=False,
    ))
    return "continue"


def _handle_perms(ctx: SlashContext) -> Literal["continue", "exit"]:
    # P3.1 permission rules. Three forms:
    #   /perms                          → list active rules
    #   /perms add <rule> <list>        → append to local file
    #   /perms remove <rule>            → remove from any list
    cmd = ctx.cmd
    arg = ctx.arg
    permissions = ctx.permissions
    sub = (arg or "").strip()
    if not sub:
        # List form: read live rules off the policy so the user sees
        # what was loaded at session start PLUS any [a]llow picks they
        # made this session (the Panel writes through to
        # permissions.rules).
        active = list(list_active_rules(permissions.rules))
        ctx.tracer.event("slash_command", payload={
            "cmd": cmd, "action": "list",
            "total": len(active),
        })
        if not active:
            ctx.console.print(
                "[dim]no permission rules. Add them to "
                ".fred/settings.json (project) or "
                ".fred/settings.local.json (local, "
                "gitignored).[/]"
            )
            return "continue"
        body = Text()
        # Group by list_name for a clean read; the helper already
        # yields in deny → ask → allow order.
        current_list: str | None = None
        for list_name, rule in active:
            if list_name != current_list:
                body.append(f"{list_name}\n", style="bold")
                current_list = list_name
            body.append(f"  • {rule}\n", style="dim")
        ctx.console.print(Panel(
            body,
            title="permission rules",
            title_align="left",
            border_style="cyan",
            expand=False,
        ))
        return "continue"
    parts2 = sub.split()
    action = parts2[0].lower()
    if action == "add":
        # Expect: add <rule...> <list_name>. The list name is the
        # LAST whitespace-separated token so a rule containing spaces
        # (e.g. "Bash(git status *)") round-trips cleanly.
        if len(parts2) < 3:
            ctx.tracer.event("slash_command", payload={
                "cmd": cmd, "action": "add",
                "error": "missing_args",
            })
            ctx.console.print(
                "[red]usage: /perms add <rule> <list>  "
                "(list: allow|ask|deny)[/]"
            )
            return "continue"
        list_name = parts2[-1].lower()
        rule_str = " ".join(parts2[1:-1]).strip()
        if list_name not in ("allow", "ask", "deny") or not rule_str:
            ctx.tracer.event("slash_command", payload={
                "cmd": cmd, "action": "add",
                "error": "invalid_args",
                "list": list_name,
            })
            ctx.console.print(
                "[red]usage: /perms add <rule> <list>  "
                "(list: allow|ask|deny)[/]"
            )
            return "continue"
        try:
            added = add_permission_rule(rule_str, list_name)
        except ValueError as e:
            ctx.tracer.event("slash_command", payload={
                "cmd": cmd, "action": "add",
                "error": str(e),
            })
            ctx.console.print(f"[red]/perms add: {e}[/]")
            return "continue"
        # Mirror the addition into the live engine so the rule takes
        # effect this session without a reload.
        if added:
            getattr(permissions.rules, list_name).append(rule_str)
        ctx.tracer.event("slash_command", payload={
            "cmd": cmd, "action": "add",
            "list": list_name, "rule": rule_str,
            "added": bool(added),
        })
        if added:
            ctx.console.print(
                f"[dim]added {list_name}: {rule_str}[/]"
            )
        else:
            ctx.console.print(
                f"[dim]rule already in {list_name}: "
                f"{rule_str}[/]"
            )
        return "continue"
    if action == "remove":
        if len(parts2) < 2:
            ctx.tracer.event("slash_command", payload={
                "cmd": cmd, "action": "remove",
                "error": "missing_args",
            })
            ctx.console.print(
                "[red]usage: /perms remove <rule>[/]"
            )
            return "continue"
        rule_str = " ".join(parts2[1:]).strip()
        removed = remove_permission_rule(rule_str)
        # Live engine cleanup so the rule stops firing this session
        # even before the next reload.
        if removed:
            for bucket_name in ("allow", "ask", "deny"):
                bucket = getattr(permissions.rules, bucket_name)
                while rule_str in bucket:
                    bucket.remove(rule_str)
        ctx.tracer.event("slash_command", payload={
            "cmd": cmd, "action": "remove",
            "rule": rule_str, "removed": bool(removed),
        })
        if removed:
            ctx.console.print(f"[dim]removed: {rule_str}[/]")
        else:
            ctx.console.print(
                f"[dim]not found in any list: {rule_str}[/]"
            )
        return "continue"
    ctx.tracer.event("slash_command", payload={
        "cmd": cmd, "action": action, "error": "unknown_action",
    })
    ctx.console.print(
        "[red]usage: /perms | /perms add <rule> <list> | "
        "/perms remove <rule>[/]"
    )
    return "continue"


def _handle_checkpoints(ctx: SlashContext) -> Literal["continue", "exit"]:
    # P4.3: list the most-recent shadow-git checkpoints taken in this
    # workspace. Empty list when the checkpointer is disabled, the
    # bare repo doesn't exist yet (no write tools have run this
    # session), or git failed to read.
    ctx.tracer.event("slash_command", payload={"cmd": ctx.cmd})
    checkpointer = ctx.checkpointer
    if checkpointer is None:
        ctx.console.print(
            "[dim]checkpoints disabled "
            "(set FRED_CHECKPOINTS=1 to enable).[/]"
        )
        return "continue"
    entries = checkpointer.list(limit=20)
    if not entries:
        ctx.console.print(
            "[dim]no checkpoints yet. "
            "They land after each successful write tool.[/]"
        )
        return "continue"
    body = Text()
    for entry in entries:
        ts = entry.ts.astimezone().strftime("%H:%M:%S")
        body.append(f"  {entry.sha[:7]}  ", style="cyan")
        body.append(f"{ts}  ", style="dim")
        msg = entry.message
        if len(msg) > 80:
            msg = msg[:80] + "…"
        body.append(f"{msg}\n")
    ctx.console.print(Panel(
        body,
        title=f"checkpoints (last {len(entries)})",
        title_align="left",
        border_style="dim",
        expand=False,
    ))
    return "continue"


def _handle_restore(ctx: SlashContext) -> Literal["continue", "exit"]:
    # P4.3: rewind the workspace to a specific checkpoint SHA.
    # Requires explicit `y/n` confirmation because this OVERWRITES
    # files on disk — defense in depth for an interactive
    # `Live`-region-quiet REPL where an accidental enter could
    # otherwise nuke work.
    cmd = ctx.cmd
    arg = ctx.arg
    target_sha = (arg or "").strip()
    checkpointer = ctx.checkpointer
    if checkpointer is None:
        ctx.tracer.event("slash_command", payload={
            "cmd": cmd, "error": "disabled",
        })
        ctx.console.print(
            "[dim]checkpoints disabled "
            "(set FRED_CHECKPOINTS=1 to enable).[/]"
        )
        return "continue"
    if not target_sha:
        ctx.tracer.event("slash_command", payload={
            "cmd": cmd, "error": "missing_sha",
        })
        ctx.console.print(
            "[red]usage: /restore <sha>  "
            "(use /checkpoints to find one)[/]"
        )
        return "continue"
    # Confirm before mutating the worktree. The default answer is
    # `n`; only an explicit `y` proceeds.
    ctx.console.print(
        f"[yellow]restore workspace to {target_sha[:7]}? "
        "this overwrites files on disk.[/]"
    )
    try:
        answer = input("  proceed? (y/N): ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        answer = ""
    if answer != "y":
        ctx.tracer.event("slash_command", payload={
            "cmd": cmd, "sha": target_sha,
            "confirmed": False,
        })
        ctx.console.print("[dim]restore cancelled.[/]")
        return "continue"
    stats = checkpointer.restore(target_sha)
    ctx.tracer.event("slash_command", payload={
        "cmd": cmd, "sha": target_sha,
        "confirmed": True,
        "files_changed": stats.get("files_changed"),
    })
    ctx.tracer.event("checkpoint_restore", payload={
        "sha": target_sha,
        "files_changed": stats.get("files_changed"),
        "files_only": stats.get("files_only", False),
    })
    ctx.console.print(
        f"[dim]restored {target_sha[:7]} "
        f"({stats.get('files_changed', 0)} file(s) "
        f"checked out).[/]"
    )
    return "continue"


# Dispatcher table. /quit is a hidden alias for /exit (not in
# slash_commands.SLASH_COMMANDS — the parity assert below excludes it).
SLASH_DISPATCH: dict[str, Callable[[SlashContext], Literal["continue", "exit"]]] = {
    "/exit": _handle_exit,
    "/quit": _handle_exit,
    "/help": _handle_help,
    "/clear": _handle_clear,
    "/tools": _handle_tools,
    "/todos": _handle_todos,
    "/yolo": _handle_yolo,
    "/sandbox": _handle_sandbox,
    "/cost": _handle_cost,
    "/think": _handle_think,
    "/save": _handle_save,
    "/init": _handle_init,
    "/model": _handle_model,
    "/telemetry": _handle_telemetry,
    "/flash": _handle_topology,
    "/pro": _handle_topology,
    "/repomap": _handle_repomap,
    "/rules": _handle_rules,
    "/subagents": _handle_subagents,
    "/mode": _handle_mode,
    "/style": _handle_style,
    "/compact": _handle_compact,
    "/last": _handle_last,
    "/mcp": _handle_mcp,
    "/hooks": _handle_hooks,
    "/perms": _handle_perms,
    "/checkpoints": _handle_checkpoints,
    "/restore": _handle_restore,
}


# Completer parity guard: every dispatched command (except the hidden
# /quit alias) must appear in slash_commands.SLASH_COMMANDS so the
# prompt-toolkit menu surfaces it. /init is dispatched but
# intentionally omitted from the completer list (advanced/rare); we
# allowlist that as well.
_COMPLETER_OPTIONAL = {"/quit", "/init"}


def _check_dispatch_completer_parity() -> None:
    from fred.slash_commands import SLASH_COMMANDS

    completer_names = {c.name for c in SLASH_COMMANDS}
    dispatch_names = set(SLASH_DISPATCH.keys()) - _COMPLETER_OPTIONAL
    missing = dispatch_names - completer_names
    assert not missing, (
        "SLASH_DISPATCH has commands not in slash_commands.SLASH_COMMANDS: "
        f"{sorted(missing)}. Add them to the completer tuple so users can "
        "tab-complete them, or add to _COMPLETER_OPTIONAL if they should "
        "stay hidden."
    )


_check_dispatch_completer_parity()
