"""Public surface of the cli package. Internal layout lives in `_*` modules.

Tests import these names directly from `fred.cli`. Keep this list in sync.

The internal modules import each other lazily where needed (see e.g.
``_banner._render_banner`` deferring its ``_format_model_line`` import,
and ``_main._run`` deferring ``_repl.run_repl``) to avoid a hard cycle
through this shim.
"""
from fred.cli._main import app, main, Mode, OutputStyle
from fred.cli._banner import _render_banner, mcp_summarize_servers  # noqa: F401
from fred.cli._slash_commands import SLASH_HELP
from fred.cli._init import _handle_init_slash
from fred.cli._models import (
    _apply_topology,
    _format_model_line,
    _handle_model_slash,
    _infer_preset_label,
)
from fred.cli._session_state import _build_initial_messages
from fred.context import compact_messages  # noqa: F401  test_compaction monkeypatches "fred.cli.compact_messages"

# Import side-effect: `_subcommands` and `_telemetry` register their
# `@app.command` decorators against the typer ``app`` instance. We
# import them here (rather than inside ``main()``) so any caller that
# does ``import fred.cli`` and then invokes ``app`` — or that imports
# the symbols by name — sees a fully-populated CLI.
from fred.cli import _subcommands as _subcommands  # noqa: F401
from fred.cli import _telemetry as _telemetry  # noqa: F401

__all__ = [
    "app",
    "main",
    "Mode",
    "OutputStyle",
    "_render_banner",
    "mcp_summarize_servers",
    "SLASH_HELP",
    "_handle_init_slash",
    "_apply_topology",
    "_format_model_line",
    "_handle_model_slash",
    "_infer_preset_label",
    "_build_initial_messages",
    "compact_messages",
]
