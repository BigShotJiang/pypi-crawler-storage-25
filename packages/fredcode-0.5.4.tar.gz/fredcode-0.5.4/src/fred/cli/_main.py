"""fred CLI: REPL by default, -p for one-shot.

Hosts the typer ``app`` instance, the ``_run`` callback, and the ``main``
PyPI entry point. The bulk of the REPL implementation lives in
``_repl.run_repl`` — this module is deliberately thin so other ``cli``
sub-modules can import ``app``/``Mode``/``OutputStyle`` without dragging
in the entire REPL dependency graph.
"""
from __future__ import annotations

from typing import Literal, Optional

import typer

from fred import __version__
from fred.client import DEFAULT_MODEL


Mode = Literal["act", "plan"]
OutputStyle = Literal["concise", "explanatory"]


app = typer.Typer(add_completion=False, help="fred — DeepSeek-powered agentic coding CLI")


@app.callback(invoke_without_command=True)
def _run(
    ctx: typer.Context,
    prompt: Optional[str] = typer.Option(
        None, "-p", "--prompt", help="One-shot mode: run this prompt and exit."
    ),
    yolo: bool = typer.Option(
        False, "--yolo", help="Skip permission prompts. Dangerous."
    ),
    plan: bool = typer.Option(
        False, "--plan",
        help="Start in plan mode: read-only, produce a plan, call ExitPlanMode to switch.",
    ),
    no_stream: bool = typer.Option(
        False, "--no-stream", help="Disable rich.Live streaming (use on tmux/Windows Terminal if it flickers)."
    ),
    model: str = typer.Option(
        DEFAULT_MODEL, "--model", help="DeepSeek model to use."
    ),
    architect: bool = typer.Option(
        False, "--architect",
        help="Force the editor pass even when editor_model == main_model "
             "(useful for evaluation runs).",
    ),
    output_style: str = typer.Option(
        "concise", "--output-style",
        help="Output style: concise (default, terse) or explanatory "
             "(short paragraph of reasoning per significant change).",
    ),
    sandbox: Optional[str] = typer.Option(
        None, "--sandbox",
        help="macOS sandbox mode: ro|workspace-write|full. Overrides "
             "FRED_SANDBOX_MODE and .fred/settings.json. Default workspace-write.",
    ),
    approval: Optional[str] = typer.Option(
        None, "--approval",
        help="Approval mode for permission prompts: untrusted|on_request|never. "
             "Overrides FRED_APPROVAL_MODE. Default on_request. 'never' skips "
             "the y/n/a/d Panel entirely (subset of YOLO; sandbox is the defense).",
    ),
    no_telemetry: bool = typer.Option(
        False, "--no-telemetry",
        help="Disable telemetry for THIS session only. Doesn't change your "
             "persisted opt-out preference. To opt out persistently, run "
             "/telemetry off in the REPL or `fred telemetry off`.",
    ),
    show_version: bool = typer.Option(
        False, "--version", help="Print version and exit."
    ),
) -> None:
    if show_version:
        typer.echo(f"fred {__version__}")
        raise typer.Exit()

    # If a subcommand (login/logout/whoami) was invoked, let it run instead.
    if ctx.invoked_subcommand is not None:
        return

    # Defer the heavy import until we know we're running the REPL — this
    # keeps `fred --version` and `fred login --help` snappy.
    from fred.cli._repl import run_repl

    run_repl(
        prompt=prompt,
        yolo=yolo,
        plan=plan,
        no_stream=no_stream,
        model=model,
        architect=architect,
        output_style=output_style,
        sandbox=sandbox,
        approval=approval,
        no_telemetry=no_telemetry,
    )


def main() -> None:
    app()


if __name__ == "__main__":
    main()
