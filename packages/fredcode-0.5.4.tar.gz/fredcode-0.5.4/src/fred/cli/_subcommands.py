"""Top-level typer subcommands: login, logout, whoami, update."""
from __future__ import annotations

import typer
from rich.console import Console

from fred import auth as _auth
from fred import update_check
from fred.cli._main import app


@app.command(name="login")
def cmd_login(
    device_code: bool = typer.Option(
        False,
        "--device-code",
        help="Headless flow — print a URL + code, poll until approved. Use on SSH boxes.",
    ),
) -> None:
    """Authenticate with Fred and store a credential locally."""
    console = Console()
    flow = _auth.LoginFlow()
    try:
        creds = flow.login_device_code() if device_code else flow.login_browser()
    except _auth.LoginError as e:
        console.print(f"[red]Login failed:[/] {e}")
        raise typer.Exit(code=1)
    _auth.save_credentials(creds)
    who = creds.email or "(unknown email)"
    console.print(f"[green]✓[/] Logged in as [bold]{who}[/]")
    console.print(f"  base_url: {creds.base_url}")
    console.print(f"  saved to: {_auth.DEFAULT_CRED_PATH}")


@app.command(name="logout")
def cmd_logout() -> None:
    """Revoke the stored credential and remove it from disk."""
    console = Console()
    creds = _auth.load_credentials()
    if not creds:
        console.print("[dim]Already logged out.[/]")
        return
    revoked = _auth.revoke_remote(creds)
    _auth.delete_credentials()
    if revoked:
        console.print(f"[green]✓[/] Logged out and revoked the active key for {creds.email}.")
    else:
        console.print(
            f"[yellow]![/] Removed local credentials for {creds.email}, but couldn't reach the "
            "server to revoke. The key will continue to work until it expires."
        )


@app.command(name="whoami")
def cmd_whoami() -> None:
    """Print the active account email + balance + key prefix."""
    import httpx

    console = Console()
    creds = _auth.load_credentials()
    if not creds:
        console.print("[dim]Not logged in. Run `fred login`.[/]")
        raise typer.Exit(code=1)
    auth_base = _auth.DEFAULT_AUTH_BASE_URL.rstrip("/")
    try:
        with httpx.Client(timeout=10.0) as client:
            resp = client.get(
                f"{auth_base}/api/cli/whoami",
                headers={"Authorization": f"Bearer {creds.api_key}"},
            )
    except httpx.HTTPError as e:
        console.print(f"[red]Could not reach Fred:[/] {e}")
        raise typer.Exit(code=1)
    if resp.status_code == 401:
        console.print("[red]Credential rejected.[/] Run `fred logout` then `fred login` again.")
        raise typer.Exit(code=1)
    if resp.status_code != 200:
        console.print(f"[red]Server error {resp.status_code}:[/] {resp.text[:200]}")
        raise typer.Exit(code=1)
    body = resp.json()
    bal = body.get("balanceMicrocents", 0)
    bal_dollars = bal / 1_000_000
    bal_str = f"${bal_dollars:.4f}" if abs(bal_dollars) < 0.01 else f"${bal_dollars:.2f}"
    is_internal = body.get("isInternal")
    prefix = body.get("keyPrefix") or creds.api_key[:13]
    console.print(f"  email   : {body.get('email') or creds.email}")
    console.print(
        f"  balance : {bal_str}{' [dim](internal — billing disabled)[/]' if is_internal else ''}"
    )
    console.print(f"  key     : [dim]{prefix}…[/]")
    last = body.get("keyLastUsedAt")
    if last:
        console.print(f"  last use: [dim]{last}[/]")


@app.command(name="update")
def cmd_update(
    yes: bool = typer.Option(
        False, "--yes", "-y",
        help="Skip the y/N confirmation and run the upgrade immediately.",
    ),
    no_run: bool = typer.Option(
        False, "--no",
        help="Print the upgrade command and exit without running it.",
    ),
    check: bool = typer.Option(
        False, "--check",
        help="Force a fresh PyPI fetch instead of reading the cache.",
    ),
) -> None:
    """Check for and apply Fred updates."""
    console = Console()
    method = update_check.detect_install_method()
    latest = update_check.fetch_latest(force=check)
    rc = update_check.prompt_and_run_upgrade(
        method, latest, assume_yes=yes, no_run=no_run, console=console,
    )
    raise typer.Exit(code=rc)
