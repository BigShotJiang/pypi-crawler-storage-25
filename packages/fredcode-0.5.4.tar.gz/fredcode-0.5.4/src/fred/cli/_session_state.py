"""REPL-scoped session state and message-bootstrap helpers."""
from __future__ import annotations

import re
import sys
from datetime import date
from pathlib import Path

import typer

from fred.cli._main import Mode, OutputStyle
from fred.prompt_cache import PromptsUnavailableError
from fred.repomap import RepoMap
from fred.repomap.repo_map import build_repo_map_message
from fred.system_prompt import build as build_system_prompt
from fred.tools.registry import default_registry


# Match @-prefixed paths the user may have referenced in their message.
# Mirrors the lighter pattern in input_parse so the cli can extract
# them for repo-map personalization without doing a full expansion.
_AT_MENTION_RE = re.compile(r"(?:^|\s)@([\w./\-]+)")


class _SessionState:
    """REPL-scoped state surfaced to the per-turn repo map provider.

    Tracks the files the agent has touched this session (via `view`,
    `str_replace`, etc.) and the @-mentions / identifiers from the
    most recent user input. Both feed the repo map's personalization
    vector so the model sees symbols related to where it's working.

    `plan_file_path` (P2.2) is the conventional scratchpad path the
    model can write to during plan mode. Always set; the file is only
    materialized if the model chooses to write to it.

    Kept deliberately small — anything more elaborate belongs in the
    `SessionState` dataclass that lands with P1.4.
    """

    def __init__(self) -> None:
        self.viewed_files: set[Path] = set()
        self.mentioned_files: set[Path] = set()
        self.mentioned_idents: set[str] = set()
        self.plan_file_path: Path | None = None

    def update_from_user_input(self, line: str) -> None:
        """Pull @-paths and naked identifiers out of `line` for next turn.

        We're conservative: identifiers must be at least 4 chars and
        contain a letter, so common words like "the" or "and" don't
        flood the personalization vector. Anything more sophisticated
        gets in the way of the simple "model said `Foo` -> show me Foo"
        signal we're after.
        """
        self.mentioned_files.clear()
        self.mentioned_idents.clear()
        for m in _AT_MENTION_RE.finditer(line):
            path = Path(m.group(1)).resolve() if m.group(1) else None
            if path is not None and path.exists():
                self.mentioned_files.add(path)
        # Pick out CamelCase / snake_case names as candidate idents.
        for tok in re.findall(r"[A-Za-z_][A-Za-z0-9_]{3,}", line):
            if any(c.isalpha() for c in tok):
                self.mentioned_idents.add(tok)


def _make_repo_map_provider(
    repo_map: RepoMap | None, state: _SessionState,
):
    """Build the zero-arg callable plumbed into `run_session`.

    Returns "" when `repo_map` is None (feature disabled, scan failed,
    etc.) — `run_session` treats empty as "skip injection." Catches
    exceptions broadly because the repo map must NOT take down a turn.
    """
    if repo_map is None:
        return None

    def provider() -> str:
        try:
            rendered = repo_map.get_repo_map(
                chat_files=set(),
                mentioned_idents=set(state.mentioned_idents),
                viewed_files=set(state.viewed_files),
                mentioned_files=set(state.mentioned_files),
            )
            return build_repo_map_message(rendered)
        except Exception:
            return ""

    return provider


def _build_initial_messages(
    mode: Mode = "act",
    *,
    output_style: OutputStyle = "concise",
) -> tuple[list[dict], "object"]:
    from fred.config import load_project_memory
    registry = default_registry()
    memory = load_project_memory()
    # Capture `today` once per REPL session / /clear so the system-prompt
    # bytes don't shift at midnight and break DeepSeek's prefix cache.
    today = date.today().isoformat()
    try:
        sys_prompt = build_system_prompt(
            registry, project_memory=memory, today=today, mode=mode,
            output_style=output_style,
        )
    except PromptsUnavailableError as e:
        # The wheel ships zero prompt text; the active prompts come from
        # FredWeb and are cached locally after `fred login`. If we got
        # here without a cache, exit cleanly rather than crashing the
        # user with a stack trace.
        print(f"fred: {e}", file=sys.stderr)
        raise typer.Exit(code=3) from None
    return [{"role": "system", "content": sys_prompt}], registry
