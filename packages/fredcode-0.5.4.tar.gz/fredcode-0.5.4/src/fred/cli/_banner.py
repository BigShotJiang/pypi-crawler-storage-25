"""Launch banner: wolf logo, status rows, no-credentials prompt."""
from __future__ import annotations

import os
import subprocess
from pathlib import Path

from rich.align import Align
from rich.console import Console, Group
from rich.panel import Panel
from rich.text import Text

from fred import __version__
from fred.cli._main import OutputStyle
from fred.config import ModelConfig
from fred.mcp import summarize_servers as mcp_summarize_servers  # noqa: F401  re-exported for tests
from fred.tools.registry import Registry


def _git_status_short() -> str | None:
    """Return 'branch · N modified' or None if not a git repo / git missing."""
    try:
        branch = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True, text=True, timeout=2,
        )
        if branch.returncode != 0:
            return None
        st = subprocess.run(
            ["git", "status", "--porcelain"],
            capture_output=True, text=True, timeout=2,
        )
        modified = len([l for l in st.stdout.splitlines() if l.strip()])
        suffix = f" · {modified} modified" if modified else " · clean"
        return branch.stdout.strip() + suffix
    except (subprocess.SubprocessError, FileNotFoundError, OSError):
        return None


# ASCII rendition of the wolf logo from FredWeb's marketing site.
# Same silhouette: pointed ears, narrow squinting eyes, smiling muzzle.
# Drawn so a violet→fuchsia→amber gradient (matching the web hero) flows
# diagonally across the lines. Suppressed via NO_COLOR or FRED_NO_BANNER.
_WOLF_ART = (
    "    ╱╲     ╱╲    ",
    "   ╱  ╲___╱  ╲   ",
    "  │  ◜     ◝  │  ",
    "  │  ◕  ▽  ◕  │  ",
    "   ╲   \\─/   ╱   ",
    "    ╲___╲╱___╱   ",
)
_WOLF_GRADIENT = (
    "violet1",
    "magenta",
    "magenta1",
    "deep_pink2",
    "orange1",
    "yellow1",
)


def _wolf_renderable() -> Text:
    """Gradient-colored wolf art as a single Text block. Centered as a
    unit by ``Align.center`` at the call site so the relative alignment
    of each row is preserved (per-line centering would skew rows whose
    visible width differs due to wide Unicode glyphs)."""
    txt = Text()
    last = len(_WOLF_ART) - 1
    for i, (line, color) in enumerate(zip(_WOLF_ART, _WOLF_GRADIENT)):
        suffix = "\n" if i < last else ""
        txt.append(line + suffix, style=f"bold {color}")
    return txt


def _should_show_wolf(console: Console, *, width: int, height: int) -> bool:
    """Skip on NO_COLOR / FRED_NO_BANNER, when the console isn't a TTY,
    when the terminal is too narrow for the wolf to read, or too short
    to absorb 8+ extra rows without pushing content off-screen."""
    if os.environ.get("NO_COLOR") or os.environ.get("FRED_NO_BANNER"):
        return False
    if not console.is_terminal:
        return False
    if width < 60 or height < 24:
        return False
    return True


def _format_mcp_line(mcp_session) -> str | None:
    """One-line summary of connected MCP servers, or None when 0 connected.
    Truncates to first two names + `+N more` so the row stays single-line."""
    if mcp_session is None:
        return None
    # WHY: tests monkeypatch via fred.cli — keep this resolution path.
    # `tests/test_banner.py` does `from fred import cli; cli.mcp_summarize_servers = ...`
    # to fake the connected-server list. Importing the parent package
    # lazily here forces the lookup to go through the package shim, so
    # the monkeypatch is honored without a test-only seam.
    import fred.cli as _cli_module
    summarize = getattr(_cli_module, "mcp_summarize_servers", mcp_summarize_servers)
    try:
        rows = summarize(mcp_session)
    except Exception:
        return None
    connected = [r for r in rows if r.get("status") == "connected"]
    if not connected:
        return None
    if len(connected) <= 2:
        return " · ".join(r["name"] for r in connected)
    visible = " · ".join(r["name"] for r in connected[:2])
    return f"{visible} · +{len(connected) - 2} more"


def _banner_update_status() -> str | None:
    """Return the latest PyPI version when an update is available; else None.
    Reads the existing update_check cache — never blocks on network."""
    try:
        from fred.update_check import _is_newer, _load_cache
    except ImportError:
        return None
    try:
        cache = _load_cache() or {}
    except Exception:
        return None
    latest = cache.get("latest")
    current_at_fetch = cache.get("current_at_fetch")
    if not isinstance(latest, str) or not isinstance(current_at_fetch, str):
        return None
    if current_at_fetch != __version__:
        return None
    try:
        if not _is_newer(latest, __version__):
            return None
    except Exception:
        return None
    return latest


def _render_no_credentials_panel(console: Console | None = None) -> None:
    """Print a friendly sign-in panel when the CLI runs without credentials.

    Replaces the previous bare typer.echo, which dumped a single-sentence
    error to stderr that buried the three real onramps. A first-time
    user shouldn't have to grep for `FRED_API_KEY` to figure out how to
    authenticate.

    Layout: command on its own line, indented description on the next.
    Two-line block per option scans cleanly at any terminal width and
    avoids the wrap-jaggies of inline `cmd → description`.
    """
    console = console or Console(stderr=True)
    body = Text()
    body.append("No credentials yet — pick the option that fits.\n\n", style="dim")
    body.append("fred login", style="bold cyan")
    body.append("\n  Browser flow. Fastest path. ")
    body.append("$1 in free credits on signup.\n\n", style="bold green")
    body.append("fred login --device-code", style="bold cyan")
    body.append("\n  Headless / SSH / containers without a browser.\n\n")
    body.append('export FRED_API_KEY="fred_live_…"', style="bold cyan")
    body.append("\n  CI scripts. Skip the login flow entirely.\n\n")
    body.append("Already paying DeepSeek directly? Set ", style="dim")
    body.append("DEEPSEEK_API_KEY", style="dim italic")
    body.append(" to bypass the proxy.", style="dim")
    console.print(
        Panel(
            body,
            title="[bold cyan]Sign in to Fred[/]",
            title_align="left",
            border_style="cyan",
            padding=(1, 2),
            expand=False,
        )
    )
    console.print(
        "[dim]docs · app.fredcode.net/docs/getting-started[/]",
        style="dim",
        highlight=False,
    )


def _render_banner(
    console: Console, model: str | ModelConfig, yolo: bool, registry: Registry,
    *, plan_mode: bool = False, output_style: OutputStyle = "concise",
    sandbox_mode: str | None = None, approval_mode: str | None = None,
    mcp_session=None,
) -> None:
    """Render the launch banner: a centered panel with the wolf logo at top
    and metadata rows below. The panel border + title color shift with
    state (yolo / plan / update-available / normal). Falls back to a
    one-line summary on very narrow terminals.

    `model` accepts either a string (legacy) or a `ModelConfig` (full
    four-slot routing). The wolf is suppressed via NO_COLOR or
    FRED_NO_BANNER, on non-TTY consoles, or when the terminal is too
    narrow / short to comfortably absorb ~8 extra rows.
    """
    # Local import to avoid a hard cycle: _models.py imports from this
    # module; pulling in `_format_model_line` at import time would create
    # ``_banner -> _models -> ...`` chains.
    from fred.cli._models import _format_model_line

    if isinstance(model, ModelConfig):
        model_cfg = model
    else:
        model_cfg = ModelConfig(
            main_model=model,
            editor_model=model,
            weak_model=model,
            subagent_main_model=model,
        )

    cwd = str(Path.cwd())
    home = str(Path.home())
    if cwd.startswith(home):
        cwd = "~" + cwd[len(home):]
    git = _git_status_short()
    perm = "[red]YOLO[/]" if yolo else "ask-permission"
    mode_badge = "[red]PLAN[/]" if plan_mode else "[dim]act[/]"
    mcp_line = _format_mcp_line(mcp_session)
    update_latest = _banner_update_status()

    size = console.size
    width = size.width if size.width else 80
    height = size.height if size.height else 24

    # Very narrow terminals (tmux splits, phone shells): fall back to one
    # line. Substring assertions for "fred", model name, "ask-permission"
    # / "YOLO" still hold.
    if width < 40:
        perm_short = "[red]YOLO[/]" if yolo else "ask-permission"
        line = (
            f"[bold magenta]fred[/] {__version__} · "
            f"{_format_model_line(model_cfg)} · {perm_short}"
        )
        console.print(Text.from_markup(line))
        if update_latest:
            console.print(
                f"[dim orange1]↑ {update_latest} available[/]",
            )
        console.print(
            "[dim]/help for commands · @path to embed · "
            "!cmd for shell · /exit[/]"
        )
        return

    body = Text()

    def row(label: str, value: str) -> None:
        body.append(f"  {label:<8}", style="bold")
        # `value` may carry Rich markup like "[dim]act[/]" — interpret it.
        body.append_text(Text.from_markup(value))
        body.append("\n")

    row("model", _format_model_line(model_cfg))
    row("cwd", cwd)
    if git:
        row("branch", git)
    row("perm", f"{perm} · {len(registry.names())} tools")
    row("mode", mode_badge)
    if output_style != "concise":
        row("style", output_style)
    # Surface sandbox + approval only when non-default. Keeps the banner
    # identical for the dominant case (workspace-write + on_request).
    if sandbox_mode is not None and sandbox_mode != "workspace-write":
        row("sandbox", sandbox_mode)
    if approval_mode is not None and approval_mode != "on_request":
        if approval_mode == "never":
            row("approval", f"[red]{approval_mode}[/]")
        else:
            row("approval", approval_mode)
    if mcp_line:
        row("mcp", mcp_line)
    body.append(
        "\n  /help for commands · @path to embed · "
        "!cmd for shell · /exit",
        style="dim",
    )

    # Compose contents: wolf (centered as a block) above rows when room
    # allows. ``Align.center`` treats the multi-line wolf as one unit so
    # per-line alignment within the art is preserved.
    if _should_show_wolf(console, width=width, height=height):
        contents = Group(Align.center(_wolf_renderable()), Text(""), body)
    else:
        contents = body

    if update_latest:
        title = (
            f"[bold magenta]fred[/] {__version__} "
            f"[bold orange1]· ↑ {update_latest} available[/]"
        )
    else:
        title = (
            f"[bold magenta]fred[/] {__version__} "
            f"[green]· ✓ up to date[/]"
        )

    if yolo:
        border = "bold red"
    elif plan_mode:
        border = "bold yellow"
    elif update_latest:
        border = "bold orange1"
    else:
        border = "bold magenta"

    panel_width = min(72, max(40, width - 4))
    panel = Panel(
        contents,
        title=title,
        title_align="left",
        border_style=border,
        padding=(0, 1),
        width=panel_width,
    )
    console.print(Align.center(panel))
