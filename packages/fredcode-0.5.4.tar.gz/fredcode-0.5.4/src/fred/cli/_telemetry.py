"""Telemetry status + the `/telemetry` slash and `fred telemetry` command."""
from __future__ import annotations

import typer
from rich.console import Console

from fred import auth as _auth
from fred.cli._main import app


def _telemetry_status_line() -> str:
    """Compose a one-line description of where telemetry is going right now."""
    import os

    from fred.auth import load_credentials
    from fred.preferences import load_preferences

    if os.environ.get("FRED_TELEMETRY_DB_URL"):
        return "self-hosted (FRED_TELEMETRY_DB_URL set)"
    prefs = load_preferences()
    if prefs.telemetry_opted_out:
        return "off (you have opted out)"
    if load_credentials() is None:
        return "off (not logged in — run `fred login`)"
    return "on → api.fredcode.net (default)"


def _maybe_show_first_run_notice(tracer, console: Console) -> None:
    """Print the one-time telemetry disclosure on first non-Null session.

    Idempotent: persisted via `telemetry_first_run_shown` in
    preferences.json. Quiet for opted-out users (NullTracer skips
    this) and for self-hosted users (their data goes to their own DB,
    no central disclosure needed). Only fires when the central
    RemoteWriter is actually about to send.
    """
    import os

    # Don't disclose self-hosted users — their data isn't going to us.
    if os.environ.get("FRED_TELEMETRY_DB_URL"):
        return
    # Don't disclose if telemetry is off (NullTracer's session_id is "").
    if not getattr(tracer, "session_id", None):
        return
    from fred.preferences import load_preferences, save_preferences

    prefs = load_preferences()
    if prefs.telemetry_first_run_shown:
        return
    console.print(
        "[dim]Fred sends anonymized behavioral telemetry to improve the product. "
        "Run [bold]/telemetry off[/bold] to opt out. Details: "
        "https://app.fredcode.net/docs/telemetry[/dim]"
    )
    prefs.telemetry_first_run_shown = True
    save_preferences(prefs)


def _handle_telemetry_slash(arg: str | None, *, console: Console, tracer) -> None:
    """Handle `/telemetry [...]` invocations.

    Forms:
      - `/telemetry`             — print current routing
      - `/telemetry on`          — clear opt-out (effective next session)
      - `/telemetry off`         — set opt-out (effective next session)
      - `/telemetry status`      — alias for the no-arg form
    """
    from fred.preferences import load_preferences, save_preferences

    sub = (arg or "").strip().lower() or "status"
    if sub == "status":
        console.print(f"[dim]telemetry: {_telemetry_status_line()}[/]")
        tracer.event("slash_command", payload={"cmd": "/telemetry", "sub": "status"})
        return
    if sub == "on":
        prefs = load_preferences()
        was = prefs.telemetry_opted_out
        prefs.telemetry_opted_out = False
        save_preferences(prefs)
        if was:
            console.print(
                "[dim]telemetry will resume next session. "
                "(Restart fred to apply now.)[/]"
            )
        else:
            console.print("[dim]telemetry was already on.[/]")
        tracer.event("slash_command", payload={
            "cmd": "/telemetry", "sub": "on", "changed": was,
        })
        return
    if sub == "off":
        prefs = load_preferences()
        was_off = prefs.telemetry_opted_out
        prefs.telemetry_opted_out = True
        save_preferences(prefs)
        if was_off:
            console.print("[dim]telemetry was already off.[/]")
        else:
            console.print(
                "[dim]telemetry will stop sending next session. "
                "Current session continues until you /exit.[/]"
            )
        tracer.event("slash_command", payload={
            "cmd": "/telemetry", "sub": "off", "changed": not was_off,
        })
        return
    console.print(
        f"[red]usage: /telemetry [status|on|off]  (got {sub!r})[/]"
    )


def _print_server_cost(console: Console) -> None:
    """Append a single line with server-authoritative balance + last-hour
    spend. Silent fallback on any error so /cost stays robust."""
    creds = _auth.load_credentials()
    if not creds:
        return
    try:
        import httpx

        auth_base = _auth.DEFAULT_AUTH_BASE_URL.rstrip("/")
        with httpx.Client(timeout=2.5) as client:
            resp = client.get(
                f"{auth_base}/api/cli/whoami",
                headers={"Authorization": f"Bearer {creds.api_key}"},
            )
        if resp.status_code != 200:
            return
        body = resp.json()
        bal = body.get("balanceMicrocents", 0) / 1_000_000
        bal_str = f"${bal:.4f}" if abs(bal) < 0.01 else f"${bal:.2f}"
        if body.get("isInternal"):
            console.print("[dim]server  : balance ∞ (internal account)[/]")
        else:
            console.print(f"[dim]server  : balance {bal_str}[/]")
    except Exception:
        # Server unreachable, no creds, etc — silently skip.
        return


@app.command(name="telemetry")
def cmd_telemetry(
    action: str = typer.Argument(
        "status",
        help="One of: status, on, off. Default: status.",
    ),
) -> None:
    """Manage behavioral telemetry routing (status, on, off)."""
    from fred.preferences import load_preferences, save_preferences

    console = Console()
    sub = action.strip().lower()
    if sub == "status":
        console.print(f"telemetry: {_telemetry_status_line()}")
        raise typer.Exit()
    if sub == "on":
        prefs = load_preferences()
        was = prefs.telemetry_opted_out
        prefs.telemetry_opted_out = False
        save_preferences(prefs)
        console.print(
            "telemetry: on (default routing to api.fredcode.net)"
            if was
            else "telemetry was already on."
        )
        raise typer.Exit()
    if sub == "off":
        prefs = load_preferences()
        was_off = prefs.telemetry_opted_out
        prefs.telemetry_opted_out = True
        save_preferences(prefs)
        console.print(
            "telemetry: off (opted out)"
            if not was_off
            else "telemetry was already off."
        )
        raise typer.Exit()
    console.print(f"[red]unknown action {action!r}; expected status, on, or off[/]")
    raise typer.Exit(code=2)
