"""`/init` flow: scan the repo and generate AGENTS.md."""
from __future__ import annotations

from rich.console import Console
from rich.panel import Panel

from fred.client import DSClient
from fred.render import Renderer


def _render_init_diff(old: str, new: str, console: Console) -> None:
    """Print a colorized unified diff between an existing and new AGENTS.md.

    Stdlib `difflib` only — no new deps. Green for additions, red for
    deletions, dim for context.
    """
    import difflib

    diff = list(difflib.unified_diff(
        old.splitlines(keepends=False),
        new.splitlines(keepends=False),
        fromfile="AGENTS.md (current)",
        tofile="AGENTS.md (proposed)",
        lineterm="",
    ))
    if not diff:
        console.print("[dim](proposed content is identical to current AGENTS.md)[/]")
        return
    for line in diff:
        if line.startswith("+++") or line.startswith("---"):
            console.print(f"[bold]{line}[/]")
        elif line.startswith("@@"):
            console.print(f"[cyan]{line}[/]")
        elif line.startswith("+"):
            console.print(f"[green]{line}[/]", highlight=False)
        elif line.startswith("-"):
            console.print(f"[red]{line}[/]", highlight=False)
        else:
            console.print(f"[dim]{line}[/]", highlight=False)


def _handle_init_slash(
    *,
    client: DSClient,
    registry,
    permissions,
    renderer: Renderer,
    console: Console,
    tracer,
    repo_map_provider,
) -> str:
    """Run the `/init` flow and return one of:
    ``"wrote_fresh" / "wrote_improve" / "wrote_migrate" / "cancelled" / "error"``.

    The slash handler (caller) emits a single ``slash_command`` event with
    that outcome. Per-step detail (mode, regenerations, draft size, token
    cost) lands in a structured ``init_run`` event we emit here.
    """
    import time as _time
    from pathlib import Path
    from rich.markdown import Markdown
    from fred.init_prompt import (
        detect_init_mode,
        directive_for_mode,
        init_system_prompt,
    )
    from fred.session import run_session
    from fred.tools.agent_tool import AGENT_PROFILES

    cwd = Path.cwd()
    mode, existing_path = detect_init_mode(cwd)
    target_path = cwd / "AGENTS.md"

    # Build the constrained read-only registry. `init` profile = {view,
    # grep, glob, repo_map} ∩ parent registry — same shape as `explore`.
    available = AGENT_PROFILES["init"] & set(registry.names())
    sub_registry = registry.subset(available)

    # Headless renderer so the subagent's streaming UI doesn't pollute
    # the parent transcript. We'll render a clean preview Panel from the
    # captured `final_text` instead.
    headless = Renderer(
        console=renderer.console,
        stream=False,
        show_thinking=False,
        headless=True,
    )

    existing_text = ""
    if mode == "improve" and existing_path is not None:
        try:
            existing_text = existing_path.read_text(encoding="utf-8", errors="replace")
        except OSError as e:
            console.print(f"[red]could not read {existing_path}: {e}[/]")
            return "error"

    console.print(
        f"[dim]/init: scanning repo at {cwd} ({mode} mode)…[/]"
    )

    regenerations = 0
    started = _time.perf_counter()

    while True:
        directive = directive_for_mode(mode)
        if regenerations > 0:
            directive = (
                directive
                + "\n\nThe previous draft was rejected by the user. Try again "
                "with a different angle or more depth, addressing whatever "
                "made the prior version less useful."
            )
        initial = [
            {"role": "system", "content": init_system_prompt()},
            {"role": "user", "content": directive},
        ]
        try:
            result = run_session(
                initial,
                client,
                sub_registry,
                permissions=permissions,
                max_iters=15,
                mode="act",
                tracer=tracer,
                renderer=headless,
                repo_map_provider=repo_map_provider,
                iteration_slot="subagent_main",
            )
        except KeyboardInterrupt:
            console.print("[dim]/init cancelled.[/]")
            tracer.event("init_run", payload={
                "outcome": "cancelled", "mode": mode, "path": str(target_path),
                "regenerations": regenerations, "elapsed_s": round(
                    _time.perf_counter() - started, 3,
                ),
            })
            return "cancelled"
        draft = (result.final_text or "").strip()
        if not draft:
            console.print(
                "[red]/init: subagent returned no draft. "
                "Try again or check API status.[/]"
            )
            tracer.event("init_run", payload={
                "outcome": "error", "mode": mode, "path": str(target_path),
                "regenerations": regenerations, "error": "empty_draft",
            })
            return "error"

        # Strip a stray fenced wrapper if the model added one despite the
        # system prompt asking it not to. Cheap and safe.
        if draft.startswith("```markdown\n") and draft.endswith("\n```"):
            draft = draft[len("```markdown\n"):-len("\n```")]
        elif draft.startswith("```\n") and draft.endswith("\n```"):
            draft = draft[len("```\n"):-len("\n```")]

        # Preview Panel (uses Markdown rendering so the user sees the
        # actual structure, not raw bytes). Title carries the line count.
        line_count = draft.count("\n") + 1
        console.print(Panel(
            Markdown(draft),
            title=f"[bold]AGENTS.md draft[/]  ([dim]{line_count} lines · "
                  f"{mode} mode[/])",
            title_align="left",
            border_style="cyan",
            padding=(1, 2),
            expand=False,
        ))

        # Mode-specific menu. Improve mode adds [d]iff to the choices.
        if mode == "improve":
            prompt_str = "  [w]rite (overwrite), [d]iff, [r]egenerate, [c]ancel? "
            allowed = {"w", "d", "r", "c"}
        else:
            prompt_str = "  [w]rite, [r]egenerate, [c]ancel? "
            allowed = {"w", "r", "c"}
        try:
            answer = input(prompt_str).strip().lower()
        except (EOFError, KeyboardInterrupt):
            answer = "c"
        if answer not in allowed:
            answer = "c"

        if answer == "c":
            console.print("[dim]/init cancelled. No file written.[/]")
            tracer.event("init_run", payload={
                "outcome": "cancelled", "mode": mode, "path": str(target_path),
                "regenerations": regenerations,
                "draft_lines": line_count,
                "iterations_used": _count_assistant(result.messages),
                "total_tokens": result.total_tokens_in + result.total_tokens_out,
                "elapsed_s": round(_time.perf_counter() - started, 3),
            })
            return "cancelled"
        if answer == "r":
            regenerations += 1
            continue
        if answer == "d":
            _render_init_diff(existing_text, draft, console)
            try:
                follow = input(
                    "  [w]rite (overwrite), [r]egenerate, [c]ancel? "
                ).strip().lower()
            except (EOFError, KeyboardInterrupt):
                follow = "c"
            if follow == "r":
                regenerations += 1
                continue
            if follow != "w":
                console.print("[dim]/init cancelled. No file written.[/]")
                tracer.event("init_run", payload={
                    "outcome": "cancelled", "mode": mode,
                    "path": str(target_path),
                    "regenerations": regenerations,
                    "draft_lines": line_count,
                    "iterations_used": _count_assistant(result.messages),
                    "total_tokens": result.total_tokens_in + result.total_tokens_out,
                    "elapsed_s": round(_time.perf_counter() - started, 3),
                })
                return "cancelled"
            answer = "w"

        # Write path. Fresh mode uses O_EXCL so a concurrent file-creation
        # race doesn't silently overwrite. Improve / migrate already
        # confirmed an overwrite via the explicit menu choice.
        try:
            if mode == "fresh":
                with open(target_path, "x", encoding="utf-8") as f:
                    f.write(draft if draft.endswith("\n") else draft + "\n")
            else:
                target_path.write_text(
                    draft if draft.endswith("\n") else draft + "\n",
                    encoding="utf-8",
                )
        except FileExistsError:
            # Race: AGENTS.md appeared between detect and write.
            console.print(
                "[red]/init: AGENTS.md was created by something else "
                "while you were reviewing. Run /init again to enter improve "
                "mode against the new file.[/]"
            )
            tracer.event("init_run", payload={
                "outcome": "error", "mode": mode, "path": str(target_path),
                "regenerations": regenerations, "error": "race_create",
            })
            return "error"
        except OSError as e:
            console.print(f"[red]/init: could not write {target_path}: {e}[/]")
            tracer.event("init_run", payload={
                "outcome": "error", "mode": mode, "path": str(target_path),
                "regenerations": regenerations,
                "error": f"{type(e).__name__}: {e}",
            })
            return "error"

        outcome = f"wrote_{mode}"
        console.print(
            f"[green]✓ wrote {target_path.relative_to(cwd) if target_path.is_relative_to(cwd) else target_path} "
            f"({line_count} lines)[/]"
        )

        # In migrate mode, offer to symlink CLAUDE.md → AGENTS.md so both
        # names continue to resolve. Default no — silent symlinking would
        # surprise users who deliberately maintain CLAUDE.md.
        if mode == "migrate" and existing_path is not None:
            try:
                offer = input(
                    f"  symlink {existing_path.name} → AGENTS.md? (y/N) "
                ).strip().lower()
            except (EOFError, KeyboardInterrupt):
                offer = ""
            if offer == "y":
                try:
                    existing_path.unlink()
                    existing_path.symlink_to("AGENTS.md")
                    console.print(
                        f"[dim]✓ {existing_path.name} → AGENTS.md (symlink)[/]"
                    )
                except OSError as e:
                    console.print(
                        f"[red]symlink failed: {e}. "
                        f"AGENTS.md was still written; you may delete or "
                        f"replace {existing_path.name} manually.[/]"
                    )

        tracer.event("init_run", payload={
            "outcome": outcome, "mode": mode, "path": str(target_path),
            "draft_lines": line_count,
            "draft_chars": len(draft),
            "regenerations": regenerations,
            "iterations_used": _count_assistant(result.messages),
            "total_tokens": result.total_tokens_in + result.total_tokens_out,
            "elapsed_s": round(_time.perf_counter() - started, 3),
        })
        return outcome


def _count_assistant(messages) -> int:
    """Count assistant messages — proxy for iteration count."""
    return sum(1 for m in messages if m.get("role") == "assistant")
