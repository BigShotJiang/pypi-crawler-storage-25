"""Session-scoped agent loop.

`run_session` is the reusable inner loop: stream model responses, dispatch
tools, repeat until the model stops or the iteration cap is hit. It does
NOT mutate the caller's `initial_messages` list — it operates on a local
working copy and returns a `SessionResult`.

`agent.run_turn` is a thin wrapper around `run_session` that preserves
the existing in-place mutation contract for the REPL/cli path. Future
callers (subagents, plan mode, multi-model architect/editor) will use
`run_session` directly.

Design notes:
- The function signature mirrors what subagents (P2.1) need: a fully
  formed `initial_messages` list (system + user + any prior context),
  a client, a registry (possibly a `Registry.subset(...)`), and the
  same renderer/permissions/tracer wiring.
- `parent_session_id` and `mode` are passthrough fields for now —
  `run_session` doesn't consult them yet, but the schema (P0.1) and
  tracer events (later picks) will.
- Telemetry events fire in the same order as the previous `run_turn`
  to keep behavior identical at the REPL level.
"""
from __future__ import annotations

import os
import time
from dataclasses import dataclass, field
from typing import Callable, Literal

from fred._constants import BASH_PROGRESS_SAMPLE
from fred.cache_segments import cacheable_prefix_size_estimate
from fred.checkpoints import READ_ONLY_TOOLS, Checkpointer
from fred.client import DSClient, StreamResult, ToolCall
from fred.config import load_model_config
from fred.context import (
    budget_status,
    compact_messages,
    prune_messages,
)
from fred.editor_pass import (
    EDITOR_REVIEWED_TOOLS,
    MAX_EDITOR_CALLS_PER_ITERATION,
    maybe_editor_repair,
)
from fred.hooks import HookConfig, run_hooks
from fred.mode import Mode, current_mode, reset_mode_state, set_mode_state
from fred.permissions import PermissionPolicy
from fred.render import Renderer
from fred.telemetry import NullTracer, Tracer, TurnHandle
from fred.todo_inject import (
    inject_todo_block,
    is_todo_block_message,
    todos_state_payload,
)
from fred.rules import RuleSet, build_rules_message
from fred.tools import agent_tool, bash as bash_tool, request_rule as request_rule_tool
from fred.tools.todo import get_todos
from fred.tools.registry import PreHookDecision, Registry
from fred.turn_state import CallStatus

MAX_ITERS = 50


def _build_iteration_messages(
    base_messages: list[dict],
    repo_map_text: str,
    rules_text: str = "",
) -> list[dict]:
    """Return a per-iteration message list with repo map + rules injected.

    Wire shape (volatile system tail layered on the cacheable prefix)::

        [system, repo_map, rules, todos, ...conversation]

    `base_messages` already contains the todo block (if any) at index 1
    via ``inject_todo_block``. This function inserts the repo map BEFORE
    the todo block (right after the leading system prompt) and the rules
    block right after the repo map — matching the order spec in plan
    §P3.2.

    The cacheable prefix bytes (leading system message) stay byte-stable
    across turns; the repo map, rules, and todo segments are volatile but
    sit AFTER the cacheable boundary so prefix-cache hit rate is preserved.

    `base_messages` is left untouched; the result is a fresh shallow list.
    When all volatile segments are empty we return `base_messages` as-is
    (no allocation) — useful when the project is empty or the feature
    is disabled.
    """
    if not repo_map_text and not rules_text:
        return base_messages
    extra: list[dict] = []
    if repo_map_text:
        extra.append({"role": "system", "content": repo_map_text})
    if rules_text:
        extra.append({"role": "system", "content": rules_text})
    if base_messages and base_messages[0].get("role") == "system":
        return [base_messages[0]] + extra + list(base_messages[1:])
    return extra + list(base_messages)


@dataclass
class SessionResult:
    """The aggregate output of `run_session`.

    `final_text` is the assistant text from the last iteration that
    didn't dispatch tool calls (i.e. the natural stop). Token totals
    sum across all iterations. `tool_calls` is the flattened list in
    dispatch order.
    """

    final_text: str = ""
    total_tokens_in: int = 0
    total_tokens_out: int = 0
    total_cached: int = 0
    tool_calls: list[ToolCall] = field(default_factory=list)
    finish_reason: str | None = None
    ended_at: float = 0.0
    # Working messages list — the wrapper (`run_turn`) mirrors this back
    # to the caller for backwards compatibility with the REPL.
    messages: list[dict] = field(default_factory=list)


def _assistant_message(text: str, reasoning: str, tool_calls: list[ToolCall]) -> dict:
    msg: dict = {"role": "assistant", "content": text or None}
    if reasoning:
        # DeepSeek thinking-mode round-trip: server requires reasoning_content back
        msg["reasoning_content"] = reasoning
    if tool_calls:
        msg["tool_calls"] = [
            {
                "id": tc.id,
                "type": "function",
                "function": {"name": tc.name, "arguments": tc.raw_arguments},
            }
            for tc in tool_calls
        ]
    return msg


def _tally_usage(usage: dict | None) -> tuple[int, int, int]:
    if not usage:
        return 0, 0, 0
    in_tok = int(usage.get("prompt_tokens") or 0)
    out_tok = int(usage.get("completion_tokens") or 0)
    cached = int(((usage.get("prompt_tokens_details") or {}).get("cached_tokens")) or 0)
    return in_tok, out_tok, cached


def _short_args_preview(arguments: dict | None, *, limit: int = 60) -> str:
    """Compact one-line repr of a tool's arguments for checkpoint subjects.

    Picks the most-informative single arg (path / file_path / command /
    pattern) and trims to ``limit`` chars; falls back to the first
    string-valued arg, then to nothing. Used for the checkpoint commit
    subject so ``git log`` reads as ``after str_replace: src/foo.py``
    rather than the full JSON dump.
    """
    if not arguments:
        return ""
    for key in ("path", "file_path", "command", "pattern", "cmd", "name"):
        val = arguments.get(key)
        if isinstance(val, str) and val:
            v = val.strip().splitlines()[0] if val.strip() else val
            return v[:limit] + ("…" if len(v) > limit else "")
    # Fallback: first short string-valued arg.
    for v in arguments.values():
        if isinstance(v, str) and v:
            v2 = v.strip().splitlines()[0] if v.strip() else v
            return v2[:limit] + ("…" if len(v2) > limit else "")
    return ""


def _strip_injected_todo_blocks(messages: list[dict]) -> list[dict]:
    """Return a copy of `messages` with synthetic todo-block messages removed.

    The injected todo block is a wire-format detail used only for the model
    call — it must not bleed into the caller's persisted history (the cli.py
    REPL list, telemetry transcript dumps, /save output). Strip them as the
    last step before handing `result.messages` back.
    """
    return [m for m in messages if not is_todo_block_message(m)]


def _build_pre_tool_hook(
    hooks_config: dict[str, list[HookConfig]],
    *,
    tracer: Tracer,
    turn: TurnHandle | None,
) -> Callable[[str, dict], PreHookDecision | None] | None:
    """Construct the closure passed as ``pre_handler_hook`` to dispatch.

    Returns ``None`` when no PreToolUse hooks are configured — the registry
    treats ``None`` as "no hook" and skips the lookup entirely. When hooks
    are present we build a closure that, on each tool call, fires the
    matching PreToolUse hooks via ``run_hooks`` and translates the outcome
    into a ``PreHookDecision`` the registry consumes.
    """
    pre_entries = hooks_config.get("PreToolUse") or []
    if not pre_entries:
        return None

    def _pre(tool_name: str, args: dict) -> PreHookDecision | None:
        outcome = run_hooks(
            "PreToolUse",
            hooks_config,
            tracer=tracer,
            turn=turn,
            tool_name=tool_name,
            tool_input=args,
        )
        if outcome is None:
            return None
        if outcome.blocked:
            cmd = outcome.hook.command if outcome.hook else ""
            return PreHookDecision(
                block_message=f"Error: PreToolUse hook blocked: {cmd}",
                outcome="hook_blocked",
                permission_outcome_override="hook_blocked",
            )
        if outcome.updated_input is not None:
            return PreHookDecision(updated_args=outcome.updated_input)
        return None

    return _pre


def _emit_rules_loaded(
    tracer: Tracer,
    turn: TurnHandle | None,
    *,
    applicable: list,
    explicit_set: set[str],
    chat_files: set,
    total_chars: int,
) -> None:
    """Emit the per-turn `rules_loaded` event (P3.2).

    Each rule is attributed to a single source category in priority
    order: explicit (model-requested) > always > glob. We don't break
    out a rule that "would have matched globs anyway after being
    explicitly requested" — the explicit attribution is the more
    interesting signal.
    """
    if not applicable:
        return
    names: list[str] = []
    explicit_names: list[str] = []
    always_names: list[str] = []
    glob_names: list[str] = []
    has_chat_files = bool(chat_files)
    for rule in applicable:
        names.append(rule.name)
        if rule.name in explicit_set:
            explicit_names.append(rule.name)
        elif rule.always_apply:
            always_names.append(rule.name)
        elif rule.globs and has_chat_files:
            glob_names.append(rule.name)
        else:
            # Defensive: shouldn't hit (applicable_for wouldn't include
            # it) but classify as "always" for telemetry continuity.
            always_names.append(rule.name)
    # Source label: the dominant category. When more than one is in
    # play, return a stable composite string sorted alphabetically so
    # downstream queries can match cleanly.
    sources = []
    if always_names:
        sources.append("always")
    if glob_names:
        sources.append("glob")
    if explicit_names:
        sources.append("requested")
    source = "+".join(sources) if sources else "always"
    tracer.event(
        "rules_loaded",
        payload={
            "names": names,
            "total_chars": total_chars,
            "source": source,
            "always": always_names,
            "glob": glob_names,
            "requested": explicit_names,
        },
        turn=turn,
    )


def _emit_cache_stats(
    tracer: Tracer, turn: TurnHandle | None, *, usage: dict | None, prefix_size_est: int
) -> None:
    """Emit a per-iteration `cache_stats` event from the parsed usage dict.

    Non-blocking: tracer.event is fanned out onto the daemon writer queue.
    """
    if not usage:
        return
    in_tok = int(usage.get("prompt_tokens") or 0)
    cached = int((usage.get("prompt_tokens_details") or {}).get("cached_tokens") or 0)
    non_cached = max(0, in_tok - cached)
    hit_rate = (cached / in_tok) if in_tok > 0 else 0.0
    tracer.event(
        "cache_stats",
        payload={
            "cached": cached,
            "non_cached": non_cached,
            "hit_rate": round(hit_rate, 4),
            "prefix_size_est": prefix_size_est,
        },
        turn=turn,
    )


def run_session(
    initial_messages: list[dict],
    client: DSClient,
    registry: Registry,
    *,
    permissions: PermissionPolicy,
    max_iters: int = MAX_ITERS,
    mode: Mode | None = None,
    mode_state: list[str] | None = None,
    parent_session_id: str | None = None,
    tracer: Tracer | None = None,
    renderer: Renderer | None = None,
    turn: TurnHandle | None = None,
    repo_map_provider: Callable[[], str] | None = None,
    hooks_config: dict[str, list[HookConfig]] | None = None,
    rule_set: RuleSet | None = None,
    chat_files_provider: Callable[[], set] | None = None,
    checkpointer: Checkpointer | None = None,
    iteration_slot: str = "main",
    architect: bool = False,
) -> SessionResult:
    """Run the agentic loop until natural stop or `max_iters` is hit.

    Does NOT mutate `initial_messages`. The working messages list is a
    shallow copy; callers can read it back from `SessionResult.messages`.

    `mode` is the starting mode for this session — ``"act"`` (default,
    full registry) or ``"plan"`` (read-only allowlist; the model must
    call ``exit_plan_mode`` to switch). When ``mode_state`` is supplied
    the caller's list is reused, so external state (cli.py / slash
    commands / keybindings) and the in-loop mode flip stay in sync;
    otherwise a private list is installed for the duration of the call.
    Either way, the `fred.mode` ContextVar machinery keeps
    `Registry.dispatch`'s signature stable.

    `parent_session_id` is accepted but not yet consulted in the loop —
    forward-compat with subagents (P2.1).

    `turn` is the `TurnHandle` for the parent turn (only relevant when
    invoked from `run_turn`). When None, a new turn handle is minted via
    `tracer.start_turn(user_input=None)` so the loop can still record
    iteration rows correctly.

    `repo_map_provider` is an optional zero-arg callable returning the
    rendered repo map for the current iteration. Called once per
    iteration before the model call; the result is injected as a
    non-cacheable system segment immediately after the leading system
    prompt (which is the cacheable prefix). Returning "" means "no
    repo map this turn" — useful when the project is empty or the
    feature is disabled. The provider is the integration seam used by
    P1.1; subagents in P2.1 will pass their own provider or None.

    `hooks_config` is the user's configured hook table loaded from
    ``.fred/settings.json`` (see ``fred.hooks.load_hooks_config``).
    ``PreToolUse`` hooks fire between permission grant and tool dispatch
    and may block or rewrite tool args; ``PostToolUse`` hooks fire after
    the handler returns and before the result is appended to the model
    conversation. ``None`` (the default) disables hooks entirely.

    `rule_set` is the loaded ``.fred/rules/*.md`` set (P3.2). When supplied,
    the loop renders the applicable subset (alwaysApply + glob-matched +
    explicitly requested) into a system segment positioned after the repo
    map and before the todo block on each iteration. ``None`` disables
    rule injection (and the ``request_rule`` tool returns an error if the
    model calls it). ``chat_files_provider`` is a zero-arg callable used
    for glob matching: a fresh ``set[Path]`` of files referenced this
    turn (typically ``viewed_files | mentioned_files`` from the cli's
    session state). When ``None`` the rule set sees an empty chat_files
    set, so only ``alwaysApply`` and explicitly-requested rules render.
    """
    hooks_config = hooks_config or {}
    if tracer is None:
        tracer = NullTracer()
    if turn is None:
        turn = tracer.start_turn(user_input=None)

    # Mode wiring (P2.2). Three cases:
    # 1. caller passed `mode_state` (a shared list) — install it so the
    #    in-loop dispatcher reads the same object the cli.py slash
    #    command / keybinding mutates. The list lifecycle is the
    #    caller's; we just point the ContextVar at it for the duration.
    # 2. caller passed `mode` (a string) — install a private
    #    one-element list with that starting value. Used by subagents
    #    and one-shot tests that don't need external mutation.
    # 3. neither passed — DO NOT touch the ContextVar; whatever the
    #    parent context already has (cli.py installed one at REPL
    #    startup) stays in effect. This is the default path for
    #    `run_turn` invocations.
    mode_token = None
    if mode_state is not None:
        mode_token = set_mode_state(mode_state)
    elif mode is not None:
        starting_mode: Mode = mode if mode in ("act", "plan") else "act"
        mode_token = set_mode_state([starting_mode])
    # P3.2 rule wiring. The `request_rule` tool reads a ContextVar to
    # find the loaded set + the per-session "explicit" set it mutates on
    # success. We install both here so the tool handler — which has the
    # same `(args) -> str` signature as every other tool — can reach
    # them without changing the registry's dispatch surface.
    #
    # Subagents (P2.1) call run_session with rule_set=None — we install
    # a None-masked context so a subagent can't accidentally inherit
    # the parent's RuleSet via the ContextVar lookup.
    explicit_rules: set[str] = set()
    if rule_set is not None:
        request_rule_token = request_rule_tool.set_request_rule_context(
            request_rule_tool.RuleRequestContext(
                rule_set=rule_set, explicit=explicit_rules,
            )
        )
    else:
        request_rule_token = request_rule_tool.set_request_rule_context(None)

    # 0.3.0: web research tools call into the proxy via DSClient.web_call.
    # Tool handlers don't get the client passed in, so install it on a
    # session-scoped ContextVar that web_search/web_fetch read.
    from fred.tools._web_client import set_active_client, reset_active_client

    web_client_token = set_active_client(client)

    try:
        return _run_loop(
            initial_messages=initial_messages,
            client=client,
            registry=registry,
            permissions=permissions,
            max_iters=max_iters,
            tracer=tracer,
            renderer=renderer,
            turn=turn,
            repo_map_provider=repo_map_provider,
            hooks_config=hooks_config,
            rule_set=rule_set,
            chat_files_provider=chat_files_provider,
            explicit_rules=explicit_rules,
            checkpointer=checkpointer,
            iteration_slot=iteration_slot,
            architect=architect,
        )
    finally:
        if mode_token is not None:
            reset_mode_state(mode_token)
        if request_rule_token is not None:
            request_rule_tool.reset_request_rule_context(request_rule_token)
        reset_active_client(web_client_token)


def _handle_budget_pressure(
    messages: list[dict],
    *,
    client: DSClient,
    tracer: Tracer,
    turn: TurnHandle,
    renderer: Renderer | None,
    compacted_this_turn: bool,
    iteration: int,
) -> tuple[bool, bool, int, str]:
    """Compute budget, run auto-compaction once if needed, and emit warn.

    Returns `(hard_exit, compaction_ran, used, status)`:
      - `hard_exit` is True when the budget is in the "hard" tier (caller
        finalizes + returns).
      - `compaction_ran` flips True when this call performed compaction
        (caller updates its `compacted_this_turn` accumulator).
      - `(used, status)` is the budget tuple after any compaction.

    Mutates `messages` in place via `[:] =` when compaction succeeds — the
    same shape the inline code used. Tracer call sites are byte-identical
    with the previous inline implementation.
    """
    used, status = budget_status(messages)
    if status == "hard":
        tracer.event("budget_hard", payload={"used": used}, turn=turn)
        if renderer is not None:
            renderer.error(
                f"Context budget exhausted ({used:,} tokens estimated). "
                "Use /clear to reset the conversation."
            )
        return True, False, used, status
    compaction_ran = False
    if status == "compact" and not compacted_this_turn:
        # Auto-compaction (P2.5). Runs the older half through the weak
        # model and replaces it with a structured summary. Fired once
        # per turn — `compacted_this_turn` guards against re-trigger
        # in case the post-summary budget is still "compact" because
        # the recent half alone is huge.
        compaction_ran = True
        t0 = time.perf_counter()
        try:
            weak_cfg = load_model_config()
            weak_client = client.with_model(weak_cfg.weak_model)
            new_messages, stats = compact_messages(
                messages, weak_client, tracer=tracer, turn=turn,
            )
        except Exception as exc:
            # Compaction is best-effort. If it dies we keep going
            # rather than stranding the user mid-task.
            tracer.event("compaction_run", payload={
                "trigger": "auto",
                "before_tokens": used,
                "after_tokens": used,
                "summary_chars": 0,
                "focus": None,
                "elapsed_ms": int((time.perf_counter() - t0) * 1000),
                "error_type": type(exc).__name__,
            }, turn=turn)
        else:
            messages[:] = new_messages
            tracer.event("compaction_run", payload={
                "trigger": "auto",
                "before_tokens": stats["before_tokens"],
                "after_tokens": stats["after_tokens"],
                "summary_chars": stats["summary_chars"],
                "focus": None,
                "elapsed_ms": stats["elapsed_ms"],
                "usage": stats.get("usage"),
                "cost_billed_microcents": stats.get(
                    "cost_billed_microcents", 0,
                ),
            }, turn=turn)
            if renderer is not None:
                renderer.compaction_notification(
                    stats["before_tokens"], stats["after_tokens"], None,
                )
                if stats.get("usage"):
                    renderer.show_usage(
                        stats["usage"],
                        weak_cfg.weak_model,
                        slot="weak",
                    )
            # Re-evaluate budget after compaction so the iteration
            # row records the post-summary value.
            used, status = budget_status(messages)
    if status == "warn" and iteration == 0:
        tracer.event("budget_warn", payload={"used": used}, turn=turn)
        if renderer is not None:
            renderer.info(f"context: ~{used:,} tokens used (warning at 70%)")
    return False, compaction_ran, used, status


def _inject_iteration_systems(
    messages: list[dict],
    *,
    repo_map_provider: Callable[[], str] | None,
    rule_set: RuleSet | None,
    chat_files_provider: Callable[[], set] | None,
    explicit_rules: set[str] | None,
    tracer: Tracer,
    turn: TurnHandle,
    iteration: int,
) -> tuple[list[dict], int, int]:
    """Build the per-iteration messages list with repo map + rules layered.

    Returns `(iteration_messages, prefix_size_est, repo_map_render_ms)`.

    The caller's `messages` list is read-only here — todo block injection
    has already mutated it before this helper runs (todo block lives at
    index 1). This function:
      - resolves the repo map text (with timing + telemetry),
      - resolves the active rules block,
      - composes the per-iteration wire shape: [system, repo_map, rules,
        todos, ...conversation],
      - estimates the cacheable prefix size.

    Tracer call sites are byte-identical with the previous inline code.
    """
    repo_map_text = ""
    repo_map_render_ms = 0
    if repo_map_provider is not None:
        t0 = time.perf_counter()
        try:
            repo_map_text = repo_map_provider() or ""
        except Exception:
            # The repo map is a hint, not a contract. A failure
            # here must not stop the agent loop.
            repo_map_text = ""
        repo_map_render_ms = int((time.perf_counter() - t0) * 1000)
        if repo_map_text:
            tracer.event(
                "repo_map_render",
                payload={
                    "render_ms": repo_map_render_ms,
                    "char_len": len(repo_map_text),
                    "iteration": iteration,
                },
                turn=turn,
            )

    # Rules injection (P3.2). Sits between repo map and todo block
    # in the wire shape. `applicable_for` selects on every iteration
    # so a model `request_rule(...)` call this turn shows up in the
    # NEXT iteration's active block (the explicit set was mutated
    # by the handler).
    rules_text = ""
    if rule_set is not None:
        try:
            chat_files = (
                chat_files_provider() if chat_files_provider is not None else set()
            ) or set()
        except Exception:
            # A buggy provider must not stop the loop.
            chat_files = set()
        try:
            applicable = rule_set.applicable_for(
                chat_files=chat_files,
                explicit=explicit_rules or set(),
            )
            rules_text = rule_set.render_block(applicable)
            rules_text = build_rules_message(rules_text)
        except Exception:
            # Rules are a hint, not a contract.
            rules_text = ""
            applicable = []
        # Telemetry: a `rules_loaded` event per iteration (only when
        # at least one rule was active this turn — keeps event volume
        # bounded for projects with no rules).
        if applicable:
            _emit_rules_loaded(
                tracer, turn,
                applicable=applicable,
                explicit_set=explicit_rules or set(),
                chat_files=chat_files,
                total_chars=len(rules_text),
            )
    iteration_messages = _build_iteration_messages(
        messages, repo_map_text, rules_text,
    )
    prefix_size_est = cacheable_prefix_size_estimate(iteration_messages)
    return iteration_messages, prefix_size_est, repo_map_render_ms


def _stream_iteration(
    client: DSClient,
    iteration_messages: list[dict],
    registry: Registry,
    *,
    renderer: Renderer | None,
    tracer: Tracer,
    turn: TurnHandle,
    iteration: int,
    max_iters: int,
    iteration_slot: str,
) -> tuple[StreamResult, BaseException | None, int | None, int | None]:
    """Stream one iteration and capture TTFT metrics.

    Returns `(stream_result, api_err, ttft_reasoning_ms, ttft_text_ms)`.
    Emits the `ttft_recorded` event verbatim with the previous inline
    code; the call site is byte-identical.

    KeyboardInterrupt is NOT caught here — it propagates to `_run_loop`
    which owns the iteration-end + finalize semantics for an interrupt
    (see `it.terminator_kind = "interrupt"` block in the caller).
    """
    ttft_reasoning_ms: int | None = None
    ttft_text_ms: int | None = None
    stream_open_perf: float | None = None
    stream_session = None
    api_err: BaseException | None = None
    try:
        if renderer is not None:
            with renderer.assistant_turn(iteration=iteration, max_iters=max_iters) as buf:
                stream_open_perf = time.perf_counter()
                stream_session = client.stream_chat(
                    iteration_messages, tools=registry.openai_tools(),
                )
                for ev_type, payload in stream_session:
                    if ev_type == "reasoning" and ttft_reasoning_ms is None:
                        ttft_reasoning_ms = int(
                            (time.perf_counter() - stream_open_perf) * 1000
                        )
                    elif ev_type == "text" and ttft_text_ms is None:
                        ttft_text_ms = int(
                            (time.perf_counter() - stream_open_perf) * 1000
                        )
                    buf.handle(ev_type, payload)
        else:
            # Headless path — drive the stream without a Live region.
            # Reserved for subagents (P2.1); current `run_turn` callers
            # always pass a renderer.
            stream_open_perf = time.perf_counter()
            stream_session = client.stream_chat(
                iteration_messages, tools=registry.openai_tools(),
            )
            for ev_type, _payload in stream_session:
                if ev_type == "reasoning" and ttft_reasoning_ms is None:
                    ttft_reasoning_ms = int(
                        (time.perf_counter() - stream_open_perf) * 1000
                    )
                elif ev_type == "text" and ttft_text_ms is None:
                    ttft_text_ms = int(
                        (time.perf_counter() - stream_open_perf) * 1000
                    )
    except Exception as e:
        api_err = e

    stream_result = (
        stream_session.result() if (stream_session is not None and api_err is None)
        else StreamResult()
    )
    # Fire TTFT telemetry after the stream completes (or aborts). One
    # tiny event per iteration onto the same non-blocking daemon-thread
    # queue used by `api_retry` / `model_routed`. The fields are NULL
    # when the model didn't emit that channel (e.g. a flash response
    # with no reasoning_content) — the consumer handles missing values.
    if stream_open_perf is not None:
        tracer.event("ttft_recorded", payload={
            "slot": iteration_slot,
            "model": client.model,
            "ttft_reasoning_ms": ttft_reasoning_ms,
            "ttft_text_ms": ttft_text_ms,
            "had_api_error": api_err is not None,
        }, turn=turn)
    return stream_result, api_err, ttft_reasoning_ms, ttft_text_ms


def _dispatch_one_tool_call(
    tc: ToolCall,
    *,
    call_idx: int,
    it: TurnHandle,
    messages: list[dict],
    result: SessionResult,
    registry: Registry,
    permissions: PermissionPolicy,
    hooks_config: dict[str, list[HookConfig]],
    tracer: Tracer,
    turn: TurnHandle,
    renderer: Renderer | None,
    client: DSClient,
    checkpointer: Checkpointer | None,
    editor_model_cfg,
    last_user_msg: str,
    stream_result: StreamResult,
    architect: bool,
    editor_calls_this_iteration: int,
    research_chain_buf: list[tuple[str, dict]],
    session_start_perf: float,
    pre_hook: Callable[[str, dict], PreHookDecision | None] | None,
) -> tuple[Literal["continue", "terminate"], int]:
    """Dispatch a single tool call from the iteration's tool_calls list.

    Returns `(control, new_editor_calls_count)`:
      - `"continue"` — keep iterating through the rest of the iteration's
        tool calls.
      - `"terminate"` — `attempt_completion` succeeded; caller should
        finalize and return. `result.final_text` + `result.finish_reason`
        have already been set by this helper, and the completion panel
        + todos have already been rendered.

    `research_chain_buf` is mutated in place — append on web_search /
    web_fetch — and `messages` / `result` are mutated for the
    tool-result message and tool_calls log respectively. Tracer call
    sites are byte-identical with the previous inline code.
    """
    cs = renderer.find_call(tc.id) if renderer is not None else None
    on_line_token = None
    agent_ctx_token = None
    if tc.name == "bash" and renderer is not None:
        # Build a per-line callback the bash drain thread will fire.
        # Both `cs` and `tracer` references are captured by closure;
        # the closure runs on the daemon thread, so it must stay
        # non-blocking and exception-safe (bash.py wraps it in a
        # try/except as belt-and-suspenders).
        line_count = [0]

        def _on_line(_line: str, _cs=cs, _t=tracer, _tu=turn,
                     _counter=line_count) -> None:
            _counter[0] += 1
            n = _counter[0]
            # The renderer Live region has already exited; this is
            # bookkeeping for the final result-card header. No I/O.
            renderer.tool_status(_cs, CallStatus.RUNNING, lines=n)
            if n % BASH_PROGRESS_SAMPLE == 0:
                _t.event(
                    "bash_stream_progress",
                    payload={
                        "lines_so_far": n,
                        "bytes_so_far": len(_line),
                        "elapsed_ms": int(
                            (time.perf_counter() - session_start_perf) * 1000
                        ),
                    },
                    turn=_tu,
                )

        on_line_token = bash_tool.set_on_line(_on_line)
    elif tc.name == "agent" and renderer is not None:
        # P2.1: install the parent-context bag the agent tool's
        # handler reads to spawn a subagent. Mirrors the bash
        # `set_on_line` ContextVar precedent. We only set this
        # for the main session — subagents never get the agent
        # tool in their constrained registry, so their dispatch
        # loop's `tc.name == "agent"` branch is unreachable.
        ctx = agent_tool.AgentDispatchContext(
            client=client,
            registry=registry,
            permissions=permissions,
            tracer=tracer,
            renderer=renderer,
            parent_session_id=getattr(tracer, "session_id", None) or None,
            parent_iteration_id=getattr(it, "turn_id", None) or None,
        )
        agent_ctx_token = agent_tool.set_dispatch_context(ctx)

    # Architect/editor split: when the editor slot diverges from
    # main (or `--architect` was passed), route file-edit calls
    # through `maybe_editor_repair` first. The editor verifies
    # / repairs args against the current file contents and
    # returns a (possibly mutated) ToolCall with the same id and
    # name. Failures swallow inside the helper.
    if (
        editor_model_cfg is not None
        and tc.name in EDITOR_REVIEWED_TOOLS
        and editor_calls_this_iteration < MAX_EDITOR_CALLS_PER_ITERATION
    ):
        # Surface the editor pass to the user. It blocks the main
        # thread for the duration of an entire editor stream (no
        # incremental UI), so without this the user sees silence
        # between architect output and tool dispatch — which on a
        # slow editor model reads as a hang. Pair: starting line
        # before the call, done line with timing after.
        _editor_started_perf = time.perf_counter()
        if renderer is not None:
            renderer.editor_pass_starting(tc.name)
        tc = maybe_editor_repair(
            tc,
            client=client,
            model_cfg=editor_model_cfg,
            registry=registry,
            user_message=last_user_msg,
            architect_text=stream_result.text,
            architect_reasoning=stream_result.reasoning,
            tracer=tracer,
            turn=turn,
            renderer=renderer,
            architect_flag=architect,
        )
        if renderer is not None:
            renderer.editor_pass_done(
                tc.name, time.perf_counter() - _editor_started_perf,
            )
        editor_calls_this_iteration += 1
    elif (
        editor_model_cfg is not None
        and tc.name in EDITOR_REVIEWED_TOOLS
        and editor_calls_this_iteration >= MAX_EDITOR_CALLS_PER_ITERATION
    ):
        tracer.event("editor_skipped", payload={
            "tool": tc.name,
            "reason": "iteration_cap",
            "cap": MAX_EDITOR_CALLS_PER_ITERATION,
        }, turn=turn)
    mode_before = current_mode()
    try:
        output, meta = registry.dispatch(
            tc,
            permissions=permissions,
            status_cb=(
                (lambda s, _cs=cs: renderer.tool_status(_cs, s))
                if renderer is not None else None
            ),
            pre_handler_hook=pre_hook,
        )
    finally:
        if on_line_token is not None:
            bash_tool.reset_on_line(on_line_token)
        if agent_ctx_token is not None:
            agent_tool.reset_dispatch_context(agent_ctx_token)
    mode_after = current_mode()
    if mode_after != mode_before:
        # P2.2: a tool flipped the mode mid-dispatch (the only
        # tool that does this today is `exit_plan_mode`). Emit
        # a structured `mode_change` event with source set to
        # the tool name so analytics can attribute it.
        tracer.event(
            "mode_change",
            payload={
                "from": mode_before,
                "to": mode_after,
                "source": f"{tc.name}_tool",
            },
            turn=turn,
        )

    # P3.1: when a rule fired, emit a structured event so the
    # `fred_events` table captures the matched_rule alongside
    # the tool_call row (the `fred_tool_calls` schema has no
    # JSONB payload column; events are the additive pathway).
    # The event runs only on a rule-driven outcome — yolo /
    # always_allow / user_y/n/a paths skip it.
    if meta.get("matched_rule"):
        tracer.event(
            "permission_rule_match",
            payload={
                "tool_name": tc.name,
                "matched_rule": meta["matched_rule"],
                "verdict": (
                    "allow"
                    if meta["permission_outcome"] == "rule_allow"
                    else "deny"
                    if meta["permission_outcome"] == "rule_deny"
                    else meta["permission_outcome"]
                ),
                "call_index": call_idx,
            },
            turn=turn,
        )

    # Bash-specific telemetry payload (extends additively via
    # `fred_events` rather than touching the tool_calls schema).
    bash_exit_code: int | None = None
    if tc.name == "bash":
        stats = bash_tool.consume_last_stats()
        if stats is not None:
            tracer.event("bash_complete", payload=stats, turn=turn)
            bash_exit_code = stats.get("exit_code")
    # 0.3.0: web research telemetry. Drain the per-tool stats
    # ContextVar and emit a kind-specific event; also append to
    # the per-iteration buffer so we can summarize chains.
    elif tc.name == "web_search":
        from fred.tools import web_search as _ws

        ws_stats = _ws.consume_last_stats()
        if ws_stats is not None:
            tracer.event("web_search", payload=ws_stats, turn=turn)
            research_chain_buf.append(("search", ws_stats))
    elif tc.name == "web_fetch":
        from fred.tools import web_fetch as _wf

        wf_stats = _wf.consume_last_stats()
        if wf_stats is not None:
            tracer.event("web_fetch", payload=wf_stats, turn=turn)
            research_chain_buf.append(("fetch", wf_stats))
    # P4.1: a `sandbox_invoked` event for any tool that wraps a
    # cmd in sandbox-exec. Both `bash` and `bash_bg` write the
    # ContextVar; we read + clear it here. The event records the
    # axis pair (sandbox + approval) so analytics can correlate
    # mode choice with downstream tool failures. Non-blocking —
    # the tracer fans out to the daemon writer.
    if tc.name in ("bash", "bash_bg"):
        from fred.tools._sandbox import last_stats_payload as _sb_last
        sb_stats = _sb_last()
        if sb_stats is not None:
            tracer.event(
                "sandbox_invoked",
                payload={
                    "tool": tc.name,
                    "mode": sb_stats.get("mode"),
                    "wrapped": sb_stats.get("wrapped"),
                    "command_chars": sb_stats.get("command_chars"),
                    "approval_mode": getattr(
                        permissions, "approval_mode", None,
                    ),
                    "exit_code": bash_exit_code,
                },
                turn=turn,
            )

    # PostToolUse hook (P2.4). The handler has already run; a
    # blocking exit cannot un-run it but it surfaces an error to
    # the model so the next turn knows the post-check failed.
    if meta["outcome"] not in ("hook_blocked", "denied"):
        post_outcome = run_hooks(
            "PostToolUse",
            hooks_config,
            tracer=tracer,
            turn=turn,
            tool_name=tc.name,
            tool_input=tc.arguments,
            tool_output=output,
        )
        if post_outcome is not None and post_outcome.blocked:
            output = (
                f"Error: PostToolUse hook blocked tool result for "
                f"{tc.name}: {post_outcome.hook.command if post_outcome.hook else ''}\n\n"
                f"--- original tool output ---\n{output}"
            )
            # The handler already ran, so we don't change the
            # outcome to hook_blocked — just annotate the wire
            # text. We do flip the renderer glyph to error.
            meta = dict(meta)
            meta["outcome"] = (
                meta["outcome"] if meta["outcome"] != "ok"
                else "post_hook_warning"
            )

    tracer.record_tool_call(
        it, call=tc, call_index=call_idx,
        outcome=meta["outcome"],
        permission_outcome=meta["permission_outcome"],
        permission_prompt_ms=meta["permission_prompt_ms"],
        result=output,
        duration_ms=meta["duration_ms"],
        started_at=meta["started_at"],
        ended_at=meta["ended_at"],
        handler_exception_type=meta["handler_exception_type"],
    )

    # P4.3: shadow-git checkpoint after each successful, write-
    # flavored tool dispatch. Skipped on read-only tools (saves
    # disk + git churn for view/grep/glob/repo_map/request_rule)
    # and on any non-ok outcome (denied / mode_blocked /
    # handler_error / etc — there's nothing meaningful to snap
    # in those cases). The SHA flows into meta and is forwarded
    # to the renderer so the result-card can print an inline
    # ``↶ checkpoint <sha>`` marker the user can later reference
    # from /restore. All errors are best-effort: a checkpoint
    # failure must NOT take down the agent loop.
    checkpoint_sha: str | None = None
    if (
        checkpointer is not None
        and meta["outcome"] == "ok"
        and tc.name not in READ_ONLY_TOOLS
    ):
        snap_t0 = time.perf_counter()
        try:
            short_args = _short_args_preview(tc.arguments)
            msg = f"after {tc.name}: {short_args}" if short_args else f"after {tc.name}"
            checkpoint_sha = checkpointer.snapshot(msg)
        except Exception:
            checkpoint_sha = None
        snap_ms = int((time.perf_counter() - snap_t0) * 1000)
        if checkpoint_sha is not None:
            meta = dict(meta)
            meta["checkpoint_sha"] = checkpoint_sha
            tracer.event(
                "checkpoint_snapshot",
                payload={
                    "tool_name": tc.name,
                    "sha": checkpoint_sha,
                    # files_changed is best-known via the
                    # checkpointer's last-list call, but we
                    # don't want a second git invocation
                    # per-tool just for telemetry. Leave it
                    # null — the SHA itself is the join key
                    # for any deeper analysis off `git log`.
                    "files_changed": None,
                    "snapshot_ms": snap_ms,
                },
                turn=turn,
            )

    final = (
        CallStatus.DONE_OK if meta["outcome"] == "ok"
        else CallStatus.DENIED if meta["outcome"] in ("denied", "hook_blocked")
        else CallStatus.MODE_BLOCKED if meta["outcome"] == "mode_blocked"
        else CallStatus.DONE_ERROR
    )
    if renderer is not None:
        renderer.tool_done(cs, final, tc, output, checkpoint_sha=checkpoint_sha)
        # PR-D1: surface todo state changes immediately. The
        # tool-result panel already shows the formatted list,
        # but show_todos() prints a consistently-styled summary
        # block whose glyphs match the injected prompt exactly
        # — the user, the model, and the slash readback all
        # see the same characters in lockstep.
        if tc.name == "todo_write" and meta["outcome"] == "ok":
            renderer.show_todos()
    messages.append(
        {"role": "tool", "tool_call_id": tc.id, "content": output}
    )
    result.tool_calls.append(tc)

    # PR-B2: explicit terminator. attempt_completion ends the
    # turn by calling a tool. We break out of the dispatch loop
    # AND the iteration loop here so that any subsequent tool
    # calls in this assistant turn are silently dropped (the
    # model committed to ending; trailing tools after the
    # terminator are noise). Only fires when validation passed
    # (meta["outcome"] == "ok"); empty/whitespace results return
    # an Error from the handler and the loop continues normally
    # so the model can self-correct.
    #
    # Auto-lint reflect (Aider's pattern, future P1): when that
    # ships, this is the seam — replace the early return with a
    # `if lint_failed: continue` branch that synthesizes a
    # "lint failed: ..." user message into `messages` for the
    # next iteration, otherwise return as today.
    if tc.name == "attempt_completion" and meta["outcome"] == "ok":
        result.final_text = output
        result.finish_reason = "attempt_completion"
        if renderer is not None:
            renderer.completion_panel(output)
            renderer.show_todos()
        return "terminate", editor_calls_this_iteration
    return "continue", editor_calls_this_iteration


def _run_loop(
    *,
    initial_messages: list[dict],
    client: DSClient,
    registry: Registry,
    permissions: PermissionPolicy,
    max_iters: int,
    tracer: Tracer,
    renderer: Renderer | None,
    turn: TurnHandle,
    repo_map_provider: Callable[[], str] | None,
    hooks_config: dict[str, list[HookConfig]],
    rule_set: RuleSet | None = None,
    chat_files_provider: Callable[[], set] | None = None,
    explicit_rules: set[str] | None = None,
    checkpointer: Checkpointer | None = None,
    iteration_slot: str = "main",
    architect: bool = False,
) -> SessionResult:
    """The streaming + dispatch loop body; mode wiring lives in `run_session`."""
    # Defensive shallow copy: never mutate caller's list.
    messages: list[dict] = list(initial_messages)
    # `result.messages` is the externally-visible message log; the synthetic
    # todo-block system message we inject every turn is wire-format-only and
    # gets stripped before this list is returned (see `_finalize_messages`).
    result = SessionResult(messages=list(messages))

    # PR-C1: install AskFollowupContext so ask_followup_question handlers
    # see the yolo flag, hook config, tracer, and a per-turn call counter.
    # The counter resets every run_session call (one per user-visible turn);
    # subagents get their own context with calls_this_turn=0 because each
    # subagent dispatch invokes run_session afresh.
    from fred.tools._ask_prompt import (
        AskFollowupContext,
        set_ask_followup_context,
        reset_ask_followup_context,
    )
    ask_ctx = AskFollowupContext(
        yolo=getattr(permissions, "yolo", False),
        hooks_config=hooks_config,
        tracer=tracer,
        turn=turn,
        console=getattr(renderer, "console", None) if renderer is not None else None,
    )
    ask_ctx_token = set_ask_followup_context(ask_ctx)

    def _finalize_messages() -> None:
        result.messages = _strip_injected_todo_blocks(messages)
        # Reset the ask_followup context here so every return path of
        # _run_loop (each calls _finalize_messages first) cleanly tears
        # down the per-turn ContextVar. Cross-invocation leaks would
        # otherwise carry a stale calls_this_turn counter and stale
        # tracer reference.
        reset_ask_followup_context(ask_ctx_token)

    session_start_perf = time.perf_counter()
    # P2.5: ensure auto-compaction fires at most once per turn so a
    # post-summary budget that's still in the "compact" tier doesn't
    # spawn a tight loop. Reset across turns by living on a per-call
    # local; subagents and other run_session callers each get their
    # own flag.
    compacted_this_turn = False

    for iteration in range(max_iters):
        hard_exit, compaction_ran, used, status = _handle_budget_pressure(
            messages,
            client=client,
            tracer=tracer,
            turn=turn,
            renderer=renderer,
            compacted_this_turn=compacted_this_turn,
            iteration=iteration,
        )
        if hard_exit:
            _finalize_messages()
            result.ended_at = time.perf_counter()
            return result
        if compaction_ran:
            compacted_this_turn = True

        # Pruning (P2.5): cheap and idempotent — runs every iteration so
        # verbose tool results older than the active reasoning window
        # collapse to elision markers before they re-enter the model
        # call. Tracks elided byte count for telemetry.
        pruned_messages, chars_elided = prune_messages(messages)
        if chars_elided > 0:
            blocks = sum(
                1 for a, b in zip(messages, pruned_messages)
                if a.get("content") != b.get("content")
            )
            messages[:] = pruned_messages
            tracer.event("prune_run", payload={
                "messages_walked": len(messages),
                "blocks_elided": blocks,
                "tokens_freed": max(1, chars_elided // 4),
            }, turn=turn)

        it = tracer.start_iteration(
            turn,
            iteration_index=iteration,
            context_used_est=used,
            budget_status=status,
            mode=current_mode(),
            slot=iteration_slot,
            model=client.model,
        )
        if iteration > 0 and renderer is not None:
            elapsed = time.perf_counter() - session_start_perf
            renderer.info(f"step {iteration + 1}/{max_iters} · {elapsed:0.1f}s elapsed")

        # Persistent todo-list injection. Mutates `messages` to put the
        # todo block at index 1 (right after the cacheable leading system
        # prompt). Prior injections are stripped first so the messages
        # list stays bounded. Always-on per PR-D1 — there's no longer an
        # env gate or content heuristic; the empty-state placeholder is
        # one stable line whether the model has seeded todos or not.
        current_todos = get_todos()
        messages, injected_chars = inject_todo_block(
            messages, todos=current_todos,
        )
        # Stash on the IterationHandle so end_iteration writes the
        # snapshot to fred_turns.todos_snapshot (PR-D2 denorm); the
        # event row is still emitted for streaming/grep workflows.
        _todos_payload = todos_state_payload(current_todos, injected_chars)
        it.todos_snapshot = _todos_payload
        tracer.event(
            "todos_state",
            payload=_todos_payload,
            turn=turn,
        )

        # Repo map + rules injection (P1.1, P3.2). Layered on top of
        # `messages` (which already contains a todo block at index 1)
        # into a fresh per-iteration list. Final wire shape:
        # [system, repo_map, rules, todo_block, ...conversation]. The
        # cacheable prefix bytes (system at index 0) stay byte-stable
        # across turns; the repo map / rules / todo segments are
        # volatile but non-overlapping with the cacheable prefix.
        iteration_messages, prefix_size_est, repo_map_render_ms = (
            _inject_iteration_systems(
                messages,
                repo_map_provider=repo_map_provider,
                rule_set=rule_set,
                chat_files_provider=chat_files_provider,
                explicit_rules=explicit_rules,
                tracer=tracer,
                turn=turn,
                iteration=iteration,
            )
        )
        # Emit `model_routed` per iteration. The slot value is set by
        # the caller via `iteration_slot` so subagent dispatches show
        # up as `subagent_main` rather than masquerading as the parent's
        # `main` slot. Editor and weak slot dispatches fire from their
        # own callsites (editor_pass / compact_messages).
        tracer.event(
            "model_routed",
            payload={
                "slot": iteration_slot,
                "model": client.model,
                "reason": "iteration",
            },
            turn=turn,
        )
        # Stream the iteration (including TTFT capture) via the helper.
        # KeyboardInterrupt propagates back to this caller — the helper
        # never swallows it — because the tracer book-keeping for an
        # interrupt (terminator_kind, end_iteration, keyboard_interrupt
        # event) must fire from the same scope that owns finalize.
        try:
            stream_result, api_err, ttft_reasoning_ms, ttft_text_ms = (
                _stream_iteration(
                    client,
                    iteration_messages,
                    registry,
                    renderer=renderer,
                    tracer=tracer,
                    turn=turn,
                    iteration=iteration,
                    max_iters=max_iters,
                    iteration_slot=iteration_slot,
                )
            )
        except KeyboardInterrupt as e:
            it.terminator_kind = "interrupt"
            tracer.end_iteration(
                it, assistant_text="", tool_calls=[],
                finish_reason=None, usage=None, api_error=e,
            )
            tracer.event("keyboard_interrupt", turn=turn)
            if renderer is not None:
                renderer.error("\n[interrupted]")
            _finalize_messages()
            result.ended_at = time.perf_counter()
            return result
        # Pre-set terminator_kind before end_iteration writes the row. We
        # know at this point whether the model emitted no tool calls
        # (natural_stop), erred (error_abort), or scheduled an explicit
        # terminator (attempt_completion). Dispatching attempt_completion
        # later validates the result and (almost always) succeeds; the
        # corner case where Pydantic rejects an empty result is rare
        # enough that the optimistic tag is acceptable for analytics.
        if api_err is not None:
            it.terminator_kind = "error_abort"
        elif not stream_result.tool_calls:
            it.terminator_kind = "natural_stop"
        elif any(tc.name == "attempt_completion" for tc in stream_result.tool_calls):
            it.terminator_kind = "attempt_completion"
        tracer.end_iteration(
            it,
            assistant_text=stream_result.text,
            tool_calls=stream_result.tool_calls,
            finish_reason=stream_result.finish_reason,
            usage=stream_result.usage,
            api_error=api_err,
        )
        if api_err is not None:
            tracer.event("api_error", payload={
                "type": type(api_err).__name__, "message": str(api_err)[:500],
            }, turn=turn)
            if renderer is not None:
                renderer.error(f"API error: {type(api_err).__name__}: {api_err}")
            _finalize_messages()
            result.ended_at = time.perf_counter()
            return result

        if renderer is not None:
            renderer.show_usage(
                stream_result.usage, client.model, slot=iteration_slot,
            )
        _emit_cache_stats(
            tracer, turn, usage=stream_result.usage, prefix_size_est=prefix_size_est,
        )

        in_tok, out_tok, cached = _tally_usage(stream_result.usage)
        result.total_tokens_in += in_tok
        result.total_tokens_out += out_tok
        result.total_cached += cached

        messages.append(_assistant_message(
            stream_result.text, stream_result.reasoning, stream_result.tool_calls,
        ))

        result.finish_reason = stream_result.finish_reason

        if not stream_result.tool_calls:
            result.final_text = stream_result.text
            if renderer is not None:
                # Surface a dim "stopped without acting" notice when the
                # model produced no tool_calls AND the response text is
                # too short to be a substantive answer. Without this the
                # cost line is the only signal that the iteration ended,
                # which reads as a hang for /pro architects that emit
                # reasoning + a stub like "Let me do this." with no call.
                if len((stream_result.text or "").strip()) < 200 and api_err is None:
                    renderer.natural_stop_notice()
                renderer.show_todos()
            _finalize_messages()
            result.ended_at = time.perf_counter()
            return result

        # 0.3.0: per-iteration buffer for `web_research_chain` event so we
        # can capture how the model used search→fetch within a single turn.
        _research_chain_buf: list[tuple[str, dict]] = []

        # Editor pass bookkeeping. Only resolve the model config / last
        # user message when at least one tool_call this iteration is a
        # candidate, to keep the no-op path free of work.
        editor_calls_this_iteration = 0
        _editor_model_cfg = None
        _last_user_msg = ""
        if any(t.name in EDITOR_REVIEWED_TOOLS for t in stream_result.tool_calls):
            _editor_model_cfg = load_model_config()
            for _m in reversed(messages):
                if _m.get("role") == "user":
                    _content = _m.get("content", "")
                    _last_user_msg = (
                        _content if isinstance(_content, str) else str(_content)
                    )
                    break

        # Hoist pre-hook closure construction out of the inner per-tc
        # loop. The hook is stable across an iteration's tool calls
        # (it captures hooks_config + tracer + turn, none of which
        # change during dispatch); allocating a fresh closure per tool
        # was wasted work.
        pre_hook = _build_pre_tool_hook(
            hooks_config, tracer=tracer, turn=turn,
        )

        terminate_iteration = False
        for call_idx, tc in enumerate(stream_result.tool_calls):
            control, editor_calls_this_iteration = _dispatch_one_tool_call(
                tc,
                call_idx=call_idx,
                it=it,
                messages=messages,
                result=result,
                registry=registry,
                permissions=permissions,
                hooks_config=hooks_config,
                tracer=tracer,
                turn=turn,
                renderer=renderer,
                client=client,
                checkpointer=checkpointer,
                editor_model_cfg=_editor_model_cfg,
                last_user_msg=_last_user_msg,
                stream_result=stream_result,
                architect=architect,
                editor_calls_this_iteration=editor_calls_this_iteration,
                research_chain_buf=_research_chain_buf,
                session_start_perf=session_start_perf,
                pre_hook=pre_hook,
            )
            if control == "terminate":
                terminate_iteration = True
                break

        if terminate_iteration:
            _finalize_messages()
            result.ended_at = time.perf_counter()
            return result

        # 0.3.0: emit `web_research_chain` once per iteration that contained
        # ≥1 web call. Captures search→fetch shape + summed billing for
        # cost-per-task analysis. Skipped silently when no web calls fired.
        if _research_chain_buf:
            searches = [s for k, s in _research_chain_buf if k == "search"]
            fetches = [s for k, s in _research_chain_buf if k == "fetch"]
            iter_cost = sum(
                (s.get("cost_billed_microcents") or 0)
                for _, s in _research_chain_buf
            )
            tracer.event(
                "web_research_chain",
                payload={
                    "iteration": iteration,
                    "search_count": len(searches),
                    "fetch_count": len(fetches),
                    "fetch_urls_total": sum(
                        s.get("urls_requested", 0) for s in fetches
                    ),
                    "search_top_domains": [
                        s.get("top_domain") for s in searches if s.get("top_domain")
                    ],
                    "ordered": [k for k, _ in _research_chain_buf],
                    "iteration_cost_billed_microcents": iter_cost,
                },
                turn=turn,
            )

    tracer.event("runaway_guard", turn=turn)
    if renderer is not None:
        renderer.error(f"hit {max_iters}-iteration runaway guard; stopping")
        renderer.show_todos()
    _finalize_messages()
    result.ended_at = time.perf_counter()
    return result
