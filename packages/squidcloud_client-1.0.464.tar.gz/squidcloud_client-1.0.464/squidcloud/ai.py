"""AI client — agents, knowledge base, audio, image.

Covers all /squid-api/v1/ai/* endpoints from the OpenAPI spec.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from squidcloud.http import HttpTransport
    from squidcloud.types import (
        AiAudioCreateSpeechOptions,
        AiChatModelSelection,
        AiChatOptions,
        AiConnectedAgentMetadata,
        AiKnowledgeBaseMetadataField,
        AiQueryOptions,
        ContextRequest,
        GuardrailsOptions,
        ImageGenerateOptions,
        KnowledgeBaseSearchOptions,
    )


class AiClient:
    """Entry point for AI operations: agents, knowledge base, audio, image.

    Obtained via :meth:`Squid.ai()`.

    Example::

        ai = squid.ai()
        agent = ai.agent("my-agent")
        kb = ai.knowledge_base("my-kb")
        image_url = await ai.image().generate("a cat in space")
    """

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def agent(self, agent_id: str) -> AgentClient:
        """Get a client for a specific AI agent.

        Args:
            agent_id: The unique agent identifier.

        Returns:
            An :class:`AgentClient` bound to the given agent ID.
        """
        return AgentClient(self._http, agent_id)

    def knowledge_base(self, knowledge_base_id: str) -> KnowledgeBaseClient:
        """Get a client for a specific knowledge base.

        Args:
            knowledge_base_id: The unique knowledge base identifier.

        Returns:
            A :class:`KnowledgeBaseClient` bound to the given knowledge base ID.
        """
        return KnowledgeBaseClient(self._http, knowledge_base_id)

    def image(self) -> ImageClient:
        """Get a client for image generation and processing.

        Returns:
            An :class:`ImageClient` instance.
        """
        return ImageClient(self._http)

    def audio(self) -> AudioClient:
        """Get a client for audio transcription and speech synthesis.

        Returns:
            An :class:`AudioClient` instance.
        """
        return AudioClient(self._http)


# ---------------------------------------------------------------------------
# Agent
# ---------------------------------------------------------------------------


class AgentClient:
    """Operations on a single AI agent.

    Provides methods for chatting with an agent, managing its configuration,
    updating guardrails, and working with revisions.

    Obtained via :meth:`AiClient.agent`.

    Example::

        agent = squid.ai().agent("my-agent")
        response = await agent.ask("What is the weather?", options={"temperature": 0.7})
        await agent.update_instructions("Always respond in haiku format.")
    """

    def __init__(self, http: HttpTransport, agent_id: str) -> None:
        self._http = http
        self._agent_id = agent_id

    # --- Chat ---

    async def ask(
        self,
        prompt: str,
        options: AiChatOptions | None = None,
    ) -> str:
        """Ask the agent a question and get a text response.

        Args:
            prompt: The user's question or instruction.
            options: Chat options controlling model, temperature, memory,
                functions, guardrails, and more. See :class:`AiChatOptions`.

        Returns:
            The agent's response as a string.

        Raises:
            SquidHttpError: If the agent is not found or the request fails.

        Example::

            response = await agent.ask(
                "Summarize this document",
                options={
                    "model": "gemini-3-flash",
                    "temperature": 0.3,
                    "memoryOptions": {"memoryId": "session-1", "memoryMode": "read-write"},
                },
            )
        """
        result = await self._http.post(
            "squid-api/v1/ai/agent/ask",
            {"agentId": self._agent_id, "prompt": prompt, "options": options or {}},
        )
        return result.get("responseString", "") if result else ""

    async def ask_with_annotations(
        self,
        prompt: str,
        options: AiChatOptions | None = None,
    ) -> dict:
        """Ask the agent and get a response with annotations.

        Annotations include file references, citations, and other metadata
        the agent may attach to its response.

        Args:
            prompt: The user's question or instruction.
            options: Chat options. See :class:`AiChatOptions`.

        Returns:
            A dict with:
                - ``responseString`` (str): The text response.
                - ``annotations`` (dict): Annotation metadata keyed by ID.

        Example::

            result = await agent.ask_with_annotations("Find relevant docs")
            print(result["responseString"])
            for ann_id, ann in result.get("annotations", {}).items():
                print(f"  Annotation: {ann}")
        """
        return await self._http.post(
            "squid-api/v1/ai/agent/askWithAnnotations",
            {"agentId": self._agent_id, "prompt": prompt, "options": options or {}},
        )

    # --- Management ---

    async def get(self) -> dict | None:
        """Get the agent's configuration.

        Returns:
            An ``AiAgent`` dict with keys: ``id``, ``createdAt``, ``updatedAt``,
            ``description``, ``isPublic``, ``auditLog``, ``options``, ``apiKey``.
            Returns ``None`` if the agent does not exist.
        """
        return await self._http.get(f"squid-api/v1/ai/agent/get/{self._agent_id}")

    async def upsert(
        self,
        *,
        description: str | None = None,
        is_public: bool | None = None,
        audit_log: bool | None = None,
        api_key: str | None = None,
        options: AiChatOptions | None = None,
    ) -> None:
        """Create or update the agent.

        If the agent does not exist, it is created. If it exists, the provided
        fields are updated (fields set to ``None`` are left unchanged).

        Args:
            description: A description of the agent's purpose or capabilities.
            is_public: Whether the agent is publicly accessible (default ``False``).
            audit_log: Enable audit logging for the agent's activities.
            api_key: Optional API key used specifically for this agent.
            options: Default chat options applied to every request unless
                overridden per-call. See :class:`AiChatOptions`.

        Example::

            await agent.upsert(
                description="Customer support agent",
                options={"model": "gemini-3-flash", "temperature": 0.5},
            )
        """
        body: dict[str, Any] = {"id": self._agent_id}
        if description is not None:
            body["description"] = description
        if is_public is not None:
            body["isPublic"] = is_public
        if audit_log is not None:
            body["auditLog"] = audit_log
        if api_key is not None:
            body["apiKey"] = api_key
        if options is not None:
            body["options"] = options
        await self._http.post("squid-api/v1/ai/agent/upsert", body)

    async def delete(self) -> None:
        """Delete the agent permanently."""
        await self._http.post("squid-api/v1/ai/agent/delete", {"agentId": self._agent_id})

    async def update_instructions(self, instructions: str) -> None:
        """Update the agent's system instructions.

        Args:
            instructions: The new system prompt / instructions text.
        """
        await self._http.post(
            "squid-api/v1/ai/agent/updateInstructions",
            {"agentId": self._agent_id, "instructions": instructions},
        )

    async def update_model(self, model: AiChatModelSelection) -> None:
        """Update the agent's default LLM model.

        Args:
            model: A model name string (e.g., ``'gemini-3-flash'``) or an
                ``IntegrationModelSpec`` dict (``{'integrationId': str, 'model': str}``).
        """
        await self._http.post(
            "squid-api/v1/ai/agent/updateModel",
            {"agentId": self._agent_id, "model": model},
        )

    async def update_connected_agents(
        self, connected_agents: list[AiConnectedAgentMetadata]
    ) -> None:
        """Update the list of connected agents.

        Connected agents can be called by this agent during conversations.

        Args:
            connected_agents: List of ``{'agentId': str, 'description': str}`` dicts.
        """
        await self._http.post(
            "squid-api/v1/ai/agent/updateConnectedAgents",
            {"agentId": self._agent_id, "connectedAgents": connected_agents},
        )

    async def update_guardrails(self, guardrails: GuardrailsOptions) -> None:
        """Update the agent's guardrail settings.

        Args:
            guardrails: A :class:`GuardrailsOptions` dict with optional keys:
                ``custom``, ``disablePii``, ``professionalTone``,
                ``offTopicAnswers``, ``disableProfanity``.

        Example::

            await agent.update_guardrails(
                {
                    "professionalTone": True,
                    "disableProfanity": True,
                }
            )
        """
        await self._http.post(
            "squid-api/v1/ai/agent/updateGuardrails",
            {"agentId": self._agent_id, "guardrails": guardrails},
        )

    async def update_custom_guardrails(self, custom_guardrail: str) -> None:
        """Update the custom guardrail instruction text.

        Args:
            custom_guardrail: Free-form guardrail instruction string.
        """
        await self._http.post(
            "squid-api/v1/ai/agent/updateCustomGuardrails",
            {"agentId": self._agent_id, "customGuardrail": custom_guardrail},
        )

    async def delete_custom_guardrails(self) -> None:
        """Delete the custom guardrail, reverting to defaults."""
        await self._http.post(
            "squid-api/v1/ai/agent/deleteCustomGuardrails",
            {"agentId": self._agent_id},
        )

    # --- Revisions ---

    async def list_revisions(self) -> list[dict]:
        """List all revisions of this agent.

        Returns:
            A list of ``AiAgentRevision`` dicts, each containing:
            ``agentId``, ``revisionNumber``, ``action``, ``createdAt``,
            ``agentSnapshot``.
        """
        result = await self._http.get(f"squid-api/v1/ai/agent/revisions/{self._agent_id}")
        return result.get("revisions", []) if result else []

    async def restore_revision(self, revision_number: int) -> None:
        """Restore the agent to a previous revision.

        Args:
            revision_number: The revision number to restore.
        """
        await self._http.post(
            "squid-api/v1/ai/agent/restoreRevision",
            {"agentId": self._agent_id, "revisionNumber": revision_number},
        )

    async def delete_revision(self, revision_number: int) -> None:
        """Delete a specific revision.

        Args:
            revision_number: The revision number to delete.
        """
        await self._http.post(
            "squid-api/v1/ai/agent/deleteRevision",
            {"agentId": self._agent_id, "revisionNumber": revision_number},
        )


# ---------------------------------------------------------------------------
# Knowledge Base
# ---------------------------------------------------------------------------


class KnowledgeBaseClient:
    """Operations on a single knowledge base.

    Provides methods for managing knowledge base configuration, upserting
    and searching text/file contexts, and retrieving individual contexts.

    Obtained via :meth:`AiClient.knowledge_base`.

    Example::

        kb = squid.ai().knowledge_base("my-kb")
        await kb.upsert(description="Product documentation")
        await kb.upsert_contexts(
            [
                {
                    "contextId": "doc-1",
                    "type": "text",
                    "title": "Getting Started",
                    "text": "Welcome to our product...",
                }
            ]
        )
        results = await kb.search("How do I get started?")
    """

    def __init__(self, http: HttpTransport, kb_id: str) -> None:
        self._http = http
        self._kb_id = kb_id

    async def get(self) -> dict | None:
        """Get the knowledge base details.

        Returns:
            An ``AiKnowledgeBase`` dict with keys: ``id``, ``appId``,
            ``description``, ``metadataFields``, ``embeddingModel``,
            ``chatModel``, ``updatedAt``. Returns ``None`` if not found.
        """
        return await self._http.get(f"squid-api/v1/ai/knowledge-base/get/{self._kb_id}")

    async def upsert(
        self,
        *,
        description: str | None = None,
        metadata_fields: list[AiKnowledgeBaseMetadataField] | None = None,
        embedding_model: str | None = None,
        chat_model: AiChatModelSelection | None = None,
        name: str | None = None,
    ) -> None:
        """Create or update the knowledge base.

        Args:
            description: Description of the knowledge base's content.
            metadata_fields: Schema for metadata fields used in filtering.
                Each field: ``{'name': str, 'dataType': str, 'required': bool, 'description'?: str}``.
            embedding_model: The embedding model name for vectorization.
            chat_model: The LLM model for answering questions over this KB.
            name: Display name for the knowledge base.
        """
        kb: dict[str, Any] = {"id": self._kb_id}
        if description is not None:
            kb["description"] = description
        if metadata_fields is not None:
            kb["metadataFields"] = metadata_fields
        if embedding_model is not None:
            kb["embeddingModel"] = embedding_model
        if chat_model is not None:
            kb["chatModel"] = chat_model
        if name is not None:
            kb["name"] = name
        await self._http.post("squid-api/v1/ai/knowledge-base/upsert", {"knowledgeBase": kb})

    async def delete(self) -> None:
        """Delete the knowledge base and all its contexts permanently."""
        await self._http.post("squid-api/v1/ai/knowledge-base/delete", {"id": self._kb_id})

    # --- Contexts ---

    async def get_context(self, context_id: str) -> dict | None:
        """Get a specific context entry.

        Args:
            context_id: The unique context identifier.

        Returns:
            An ``AiKnowledgeBaseContext`` dict with keys: ``id``, ``appId``,
            ``knowledgeBaseId``, ``createdAt``, ``updatedAt``, ``type``,
            ``title``, ``text``, ``preview``, ``sizeBytes``, ``metadata``,
            ``requestConfig``. Returns ``None`` if not found.
        """
        return await self._http.get(
            f"squid-api/v1/ai/knowledge-base/getContext/{self._kb_id}/{context_id}"
        )

    async def list_contexts(self) -> list[dict]:
        """List all contexts in the knowledge base.

        Returns:
            A list of ``AiKnowledgeBaseContext`` dicts.
        """
        result = await self._http.get(f"squid-api/v1/ai/knowledge-base/listContexts/{self._kb_id}")
        return result.get("contexts", []) if result else []

    async def upsert_contexts(
        self,
        contexts: list[ContextRequest],
        files: list[tuple[str, bytes, str]] | None = None,
    ) -> dict:
        """Add or update contexts in the knowledge base.

        Args:
            contexts: A list of context request objects. Each must be either:
                - A :class:`TextContextRequest`: ``{'contextId', 'type': 'text', 'title', 'text', ...}``
                - A :class:`FileContextRequest`: ``{'contextId', 'type': 'file', ...}``
            files: For file contexts, provide the actual file data as a list of
                ``(filename, data_bytes, content_type)`` tuples. Must match the
                order of file contexts in the ``contexts`` list.

        Returns:
            A dict with ``failures``: a list of ``UpsertContextStatusError`` dicts
            for any contexts that failed to upsert.

        Example::

            await kb.upsert_contexts(
                [
                    {"contextId": "doc-1", "type": "text", "title": "FAQ", "text": "..."},
                    {"contextId": "doc-2", "type": "file"},
                ],
                files=[
                    ("manual.pdf", pdf_bytes, "application/pdf"),
                ],
            )
        """
        form_data = {
            "knowledgeBaseId": self._kb_id,
            "contexts": json.dumps(contexts),
        }
        file_tuples: list[tuple[str, tuple[str, bytes, str]]] = []
        if files:
            for fname, fdata, ftype in files:
                file_tuples.append(("files", (fname, fdata, ftype)))
        return await self._http.post_form(
            "squid-api/v1/ai/knowledge-base/upsertContexts",
            data=form_data,
            files=file_tuples,
        )

    async def delete_contexts(self, context_ids: list[str]) -> None:
        """Delete contexts by their IDs.

        Args:
            context_ids: List of context IDs to delete.
        """
        await self._http.post(
            "squid-api/v1/ai/knowledge-base/deleteContexts",
            {"knowledgeBaseId": self._kb_id, "contextIds": context_ids},
        )

    # --- Search ---

    async def search(
        self,
        prompt: str,
        options: KnowledgeBaseSearchOptions | None = None,
    ) -> list[dict]:
        """Search the knowledge base using semantic search.

        Args:
            prompt: The search query in natural language.
            options: Search options. See :class:`KnowledgeBaseSearchOptions`.
                Supports: ``limit``, ``chunkLimit``, ``rerankProvider``, ``chatModel``.

        Returns:
            A list of ``AiKnowledgeBaseSearchResultChunk`` dicts, each with:
            ``contextId``, ``data``, ``metadata``, ``score``.

        Example::

            chunks = await kb.search(
                "How do I reset my password?",
                options={
                    "limit": 5,
                    "chatModel": "gemini-3-flash",
                },
            )
            for chunk in chunks:
                print(f"Score: {chunk['score']}, Data: {chunk['data'][:100]}")
        """
        search_options: dict[str, Any] = {"prompt": prompt, **(options or {})}
        result = await self._http.post(
            "squid-api/v1/ai/knowledge-base/search",
            {
                "knowledgeBaseId": self._kb_id,
                "prompt": prompt,
                "options": search_options,
            },
        )
        return result.get("chunks", []) if result else []


# ---------------------------------------------------------------------------
# Image
# ---------------------------------------------------------------------------


class ImageClient:
    """Image generation and processing.

    Supports DALL-E, Stable Diffusion Core, and Flux models.

    Obtained via :meth:`AiClient.image`.

    Example::

        image_url = (
            await squid.ai()
            .image()
            .generate(
                "a cat astronaut on the moon",
                options={"modelName": "gpt-image-1", "quality": "high"},
            )
        )
    """

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    async def generate(
        self,
        prompt: str,
        options: ImageGenerateOptions | None = None,
    ) -> str:
        """Generate an image from a text prompt.

        Args:
            prompt: A text description of the image to generate.
            options: Provider-specific generation options. Use one of:
                - :class:`GptImageOptions`: ``{'modelName': 'gpt-image-1', 'quality': 'high', 'size': '1024x1024'}``
                - :class:`FluxOptions`: ``{'modelName': 'flux-pro-1.1', 'width': 1024, 'height': 768}``
                - :class:`StableDiffusionOptions`: ``{'modelName': 'stable-diffusion-core', 'aspectRatio': '16:9'}``

        Returns:
            The URL of the generated image.
        """
        result = await self._http.post(
            "squid-api/v1/ai/image/generate",
            {"prompt": prompt, "options": options or {}},
        )
        return result if isinstance(result, str) else str(result)

    async def remove_background(
        self,
        image_data: bytes,
        filename: str = "image.png",
        content_type: str = "image/png",
    ) -> str:
        """Remove the background from an image.

        Args:
            image_data: The image file content as bytes.
            filename: The filename (used in the multipart upload).
            content_type: The MIME type of the image.

        Returns:
            The URL of the processed image with the background removed.
        """
        result = await self._http.post_form(
            "squid-api/v1/ai/image/removeBackground",
            data={},
            files=[("file", (filename, image_data, content_type))],
        )
        return result if isinstance(result, str) else str(result)


# ---------------------------------------------------------------------------
# Audio
# ---------------------------------------------------------------------------


class AudioClient:
    """Audio transcription and speech synthesis.

    Obtained via :meth:`AiClient.audio`.

    Example::

        text = await squid.ai().audio().transcribe(audio_bytes)
        speech = await squid.ai().audio().create_speech("Hello!", options={"voice": "nova"})
    """

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    async def transcribe(
        self,
        audio_data: bytes,
        filename: str = "audio.wav",
        content_type: str = "audio/wav",
        *,
        options: dict[str, Any] | None = None,
    ) -> str:
        """Transcribe audio to text.

        Args:
            audio_data: The audio file content as bytes.
            filename: The filename (used in the multipart upload).
            content_type: The MIME type of the audio file.
            options: Provider-specific transcription options.

        Returns:
            The transcribed text.
        """
        form_data: dict[str, str] = {
            "optionsJson": json.dumps(options or {}),
        }
        result = await self._http.post_form(
            "squid-api/v1/ai/audio/transcribe",
            data=form_data,
            files=[("file", (filename, audio_data, content_type))],
        )
        return result if isinstance(result, str) else str(result)

    async def create_speech(
        self,
        text: str,
        options: AiAudioCreateSpeechOptions,
    ) -> bytes:
        """Generate speech audio from text.

        Args:
            text: The text to convert to speech.
            options: Speech generation options. See :class:`AiAudioCreateSpeechOptions`.
                Required keys: ``modelName`` (e.g., ``'tts-1'``), ``voice``
                (e.g., ``'nova'``, ``'alloy'``).

        Returns:
            Raw audio file bytes (e.g., MP3 format by default).

        Example::

            audio_data = (
                await squid.ai()
                .audio()
                .create_speech(
                    "Hello!",
                    options={
                        "modelName": "tts-1",
                        "voice": "nova",
                    },
                )
            )
            with open("speech.mp3", "wb") as f:
                f.write(audio_data)
        """
        return await self._http.post(
            "squid-api/v1/ai/audio/createSpeech",
            {"input": text, "options": options},
        )


# ---------------------------------------------------------------------------
# AI Query
# ---------------------------------------------------------------------------


async def execute_ai_query(
    http: HttpTransport,
    integration_id: str,
    prompt: str,
    *,
    options: AiQueryOptions | None = None,
    response_format: dict[str, Any] | None = None,
) -> dict:
    """Execute an AI-powered database query.

    Uses AI to interpret a natural language prompt, generate appropriate
    database queries, execute them, and return an answer.

    Args:
        http: The HTTP transport instance.
        integration_id: The database integration ID to query.
        prompt: A natural language description of the data to retrieve.
        options: Optional :class:`AiQueryOptions` controlling collection
            selection, query generation (including ``allowClarification``),
            result analysis (including ``enableCodeInterpreter``), memory,
            AI validation, per-stage model overrides via ``aiOptions``,
            and custom instructions.
        response_format: Optional structured output format:
            ``{'type': 'json_schema', 'schema': {...}}``.

    Returns:
        An ``AiQueryResponse`` dict with keys: ``answer``, ``explanation``,
        ``executedQueries``, ``success``, ``usedCodeInterpreter``,
        ``clarificationQuestion``.
    """
    body: dict[str, Any] = {
        "integrationId": integration_id,
        "prompt": prompt,
    }
    if options is not None:
        body["options"] = options
    if response_format is not None:
        body["responseFormat"] = response_format
    return await http.post("squid-api/v1/db/executeAiQuery", body)
