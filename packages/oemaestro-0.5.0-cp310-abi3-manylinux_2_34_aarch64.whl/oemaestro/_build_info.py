# Auto-generated build information - do not edit
OPENEYE_BUILD_VERSION = "2025.2.1"
OPENEYE_LIBRARY_TYPE = "SHARED"
OPENEYE_EXPECTED_LIBS = ["liboechem-4.3.0.1.so", "liboesystem-4.3.0.1.so", "liboeplatform-4.3.0.1.so", "liboemath-2.9.1.1.so", "libzstd_static.a", "liboegrid-4.3.0.1.so", "liboefizzchem-1.2.5.so"]
