"""models.dev catalog client — capability lookups for known models.

opencode uses the public registry at https://models.dev as the source
of truth for tool-calling support, context windows, and pricing. We
do the same: fetch once, cache to disk, and consult before falling
back to caudate's hardcoded heuristics in `llm/models.py`.

Design:
  - Single-shot fetch of `https://models.dev/api.json` on first use.
  - Disk cache at `~/.caudate/cache/models_dev.json` with a 24-hour TTL.
  - Stale cache is returned immediately (fast startup); a background
    refresh is fired and writes the new cache for next time.
  - Match strategy: try the model id verbatim, then normalize the
    `ollama/` prefix and `:tag` suffix off of local-model ids.
  - All network access is best-effort. Any failure returns None and
    the caller falls through to the hardcoded heuristics.
"""

from __future__ import annotations

import json
import logging
import threading
import time
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


_CATALOG_URL = "https://models.dev/api.json"
_CACHE_PATH = Path.home() / ".caudate" / "cache" / "models_dev.json"
_CACHE_TTL_SECONDS = 24 * 60 * 60  # 24 hours

_memory_cache: dict[str, Any] | None = None
_flat_index: dict[str, dict[str, Any]] | None = None
_refresh_in_flight = False
_refresh_lock = threading.Lock()


def _build_flat_index(catalog: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Flatten `{provider: {models: {id: entry}}}` into `{id: entry}`.

    When the same model id shows up under multiple providers (e.g. a
    cloud relay carrying gpt-4o-mini AND OpenAI's native entry), the
    first encounter wins. We sort providers so the result is stable.
    """
    flat: dict[str, dict[str, Any]] = {}
    for prov_key in sorted(catalog.keys()):
        prov = catalog.get(prov_key) or {}
        models = prov.get("models") if isinstance(prov, dict) else None
        if not isinstance(models, dict):
            continue
        for mid, entry in models.items():
            if mid not in flat and isinstance(entry, dict):
                flat[mid] = entry
    return flat


def lookup(model_id: str) -> dict[str, Any] | None:
    """Return the models.dev entry for `model_id`, or None if unknown.

    Loads / triggers refresh of the catalog as a side-effect. Caller
    should treat None as "fall back to hardcoded heuristics."
    """
    global _flat_index
    catalog = _load_catalog()
    if not catalog:
        return None
    if _flat_index is None:
        _flat_index = _build_flat_index(catalog)
    # Try a few common id normalizations.
    for candidate in _id_candidates(model_id):
        entry = _flat_index.get(candidate)
        if entry is not None:
            return entry
    return None


def _id_candidates(model_id: str) -> list[str]:
    """Generate plausible models.dev ids for a caudate model id.

    Caudate ids look like:
      - "anthropic/claude-haiku-4-5"   → try "claude-haiku-4-5"
      - "ollama/qwen3-coder:30b"       → try "qwen3-coder:30b", "qwen3-coder"
      - "openai/gpt-4o-mini"           → try "gpt-4o-mini"
    """
    out: list[str] = []
    out.append(model_id)
    if "/" in model_id:
        _, _, after = model_id.partition("/")
        out.append(after)
        if ":" in after:
            head, _, _ = after.partition(":")
            out.append(head)
    elif ":" in model_id:
        head, _, _ = model_id.partition(":")
        out.append(head)
    # Dedup while preserving order
    seen: set[str] = set()
    deduped: list[str] = []
    for c in out:
        if c not in seen:
            seen.add(c)
            deduped.append(c)
    return deduped


def _load_catalog() -> dict[str, Any] | None:
    """Return the in-memory catalog, loading from disk if needed.

    Triggers a background refresh when the on-disk cache is older
    than the TTL — the stale cache is still returned to the caller so
    startup is never blocked on the network.
    """
    global _memory_cache
    if _memory_cache is not None:
        return _memory_cache
    on_disk = _read_disk_cache()
    if on_disk is not None:
        _memory_cache = on_disk["catalog"]
        # Stale? Kick off a background refresh.
        age = time.time() - on_disk.get("ts", 0)
        if age > _CACHE_TTL_SECONDS:
            _trigger_refresh()
        return _memory_cache
    # No cache yet — fetch synchronously this once.
    fetched = _fetch_now()
    if fetched is not None:
        _memory_cache = fetched
        _write_disk_cache(fetched)
        return _memory_cache
    return None


def _read_disk_cache() -> dict[str, Any] | None:
    if not _CACHE_PATH.exists():
        return None
    try:
        data = json.loads(_CACHE_PATH.read_text())
        if not isinstance(data, dict) or "catalog" not in data:
            return None
        return data
    except Exception as e:
        logger.debug(f"failed to read models.dev cache: {e}")
        return None


def _write_disk_cache(catalog: dict[str, Any]) -> None:
    try:
        _CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
        payload = {"ts": time.time(), "catalog": catalog}
        _CACHE_PATH.write_text(json.dumps(payload))
    except Exception as e:
        logger.debug(f"failed to write models.dev cache: {e}")


def _fetch_now(timeout_s: float = 5.0) -> dict[str, Any] | None:
    """Synchronously fetch the catalog. Returns None on any failure.

    Uses httpx if available (already a caudate dep), falls back to
    stdlib urllib so this module stays usable in stripped-down envs.
    """
    try:
        import httpx
        r = httpx.get(_CATALOG_URL, timeout=timeout_s,
                      headers={"User-Agent": "caudate-cli/models.dev-client"})
        r.raise_for_status()
        return r.json()
    except Exception as e:
        logger.debug(f"models.dev httpx fetch failed: {e}")
    # Fallback: stdlib.
    try:
        import urllib.request
        req = urllib.request.Request(
            _CATALOG_URL,
            headers={"User-Agent": "caudate-cli/models.dev-client"},
        )
        with urllib.request.urlopen(req, timeout=timeout_s) as resp:
            return json.load(resp)
    except Exception as e:
        logger.debug(f"models.dev stdlib fetch failed: {e}")
        return None


def _trigger_refresh() -> None:
    """Fire a background fetch if one isn't already running."""
    global _refresh_in_flight
    with _refresh_lock:
        if _refresh_in_flight:
            return
        _refresh_in_flight = True

    def _worker():
        global _memory_cache, _flat_index, _refresh_in_flight
        try:
            fresh = _fetch_now()
            if fresh is not None:
                _memory_cache = fresh
                _flat_index = None  # rebuild on next lookup
                _write_disk_cache(fresh)
        finally:
            with _refresh_lock:
                _refresh_in_flight = False

    threading.Thread(target=_worker, daemon=True, name="models-dev-refresh").start()


def force_refresh() -> bool:
    """Synchronously refresh the catalog. Returns True on success.

    Exposed for the `/models-refresh` slash command.
    """
    global _memory_cache, _flat_index
    fresh = _fetch_now()
    if fresh is None:
        return False
    _memory_cache = fresh
    _flat_index = None  # rebuild on next lookup
    _write_disk_cache(fresh)
    return True
