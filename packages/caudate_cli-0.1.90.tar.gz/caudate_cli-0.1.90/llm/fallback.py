"""FallbackLLMProvider — try a chain of providers in order on failure.

Wraps a primary provider plus an ordered list of fallbacks. On a
*retryable* failure (network blip, timeout, model overloaded, 5xx) it
moves to the next provider. On a deterministic failure (bad request,
model not found) it raises immediately — falling back wouldn't help.

Maintains the same surface as `LLMProvider` so anywhere that takes one
will also take this. The router (`DualLLMProvider`) is orthogonal and
can sit on top of fallbacks (each tier becomes a fallback chain).
"""

from __future__ import annotations

import logging
from typing import Any, AsyncIterator

from pydantic import BaseModel

from core.schemas import StreamEvent
from llm.provider import LLMProvider, LLMResponse, _is_retryable

logger = logging.getLogger(__name__)


class FallbackLLMProvider:
    """LLMProvider with an ordered fallback chain.

    The first provider's `model` is exposed via `.model` so existing
    code that treats this as an LLMProvider still gets a sensible value
    for logging / status lines.
    """

    def __init__(self, primary: LLMProvider, fallbacks: list[LLMProvider]):
        if not isinstance(primary, LLMProvider):
            raise TypeError("primary must be an LLMProvider")
        self._chain: list[LLMProvider] = [primary, *fallbacks]
        self._active_idx = 0

    @property
    def model(self) -> str:
        return self._chain[self._active_idx].model

    @property
    def temperature(self) -> float:
        return self._chain[self._active_idx].temperature

    @property
    def max_tokens(self) -> int:
        return self._chain[self._active_idx].max_tokens

    def switch_model(self, model: str) -> None:
        """Switch the *primary* provider's model. Fallbacks are unchanged."""
        self._chain[0].switch_model(model)

    # ------------------------------------------------------------------

    async def chat(self, *args: Any, **kwargs: Any) -> LLMResponse:
        return await self._call("chat", *args, **kwargs)

    async def complete(self, *args: Any, **kwargs: Any) -> LLMResponse:
        return await self._call("complete", *args, **kwargs)

    async def structured_output(self, *args: Any, **kwargs: Any) -> Any:
        return await self._call("structured_output", *args, **kwargs)

    async def stream(
        self, *args: Any, **kwargs: Any,
    ) -> AsyncIterator[StreamEvent]:
        last_err: BaseException | None = None
        for i, provider in enumerate(self._chain):
            try:
                async for evt in provider.stream(*args, **kwargs):
                    yield evt
                self._active_idx = i
                return
            except Exception as e:
                last_err = e
                if not _is_retryable(e) or i == len(self._chain) - 1:
                    raise
                logger.warning(
                    f"Stream via {provider.model!r} failed ({e}); "
                    f"falling back to {self._chain[i + 1].model!r}"
                )
        if last_err:
            raise last_err

    async def _call(self, method: str, *args: Any, **kwargs: Any) -> Any:
        last_err: BaseException | None = None
        for i, provider in enumerate(self._chain):
            try:
                fn = getattr(provider, method)
                result = await fn(*args, **kwargs)
                self._active_idx = i
                return result
            except Exception as e:
                last_err = e
                if not _is_retryable(e) or i == len(self._chain) - 1:
                    raise
                logger.warning(
                    f"{method} via {provider.model!r} failed ({e}); "
                    f"falling back to {self._chain[i + 1].model!r}"
                )
        if last_err:
            raise last_err


def build_fallback(
    primary: LLMProvider,
    fallback_models: list[str],
) -> LLMProvider | FallbackLLMProvider:
    """Construct a FallbackLLMProvider, or return primary if no fallbacks."""
    if not fallback_models:
        return primary
    fallbacks = [LLMProvider(model=m) for m in fallback_models]
    return FallbackLLMProvider(primary=primary, fallbacks=fallbacks)
