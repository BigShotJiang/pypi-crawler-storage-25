"""Tests for `core.usage.UsageTracker`."""

from __future__ import annotations

import pytest

from core.usage import ModelUsage, UsageTracker


def test_record_accumulates_per_model():
    tr = UsageTracker()
    tr.record("modelA", {"prompt_tokens": 100, "completion_tokens": 50})
    tr.record("modelA", {"prompt_tokens": 200, "completion_tokens": 75})
    tr.record("modelB", {"prompt_tokens": 10, "completion_tokens": 5})

    assert tr.by_model["modelA"].prompt_tokens == 300
    assert tr.by_model["modelA"].completion_tokens == 125
    assert tr.by_model["modelA"].requests == 2
    assert tr.by_model["modelA"].total_tokens == 425

    assert tr.by_model["modelB"].prompt_tokens == 10
    assert tr.by_model["modelB"].requests == 1


def test_record_handles_missing_keys_as_zero():
    tr = UsageTracker()
    tr.record("m", {})  # both fields missing
    assert tr.by_model["m"].prompt_tokens == 0
    assert tr.by_model["m"].completion_tokens == 0
    assert tr.by_model["m"].requests == 1


def test_record_handles_none_values_as_zero():
    tr = UsageTracker()
    tr.record("m", {"prompt_tokens": None, "completion_tokens": 5})
    assert tr.by_model["m"].prompt_tokens == 0
    assert tr.by_model["m"].completion_tokens == 5


def test_total_tokens_sums_across_models():
    tr = UsageTracker()
    tr.record("a", {"prompt_tokens": 100, "completion_tokens": 50})
    tr.record("b", {"prompt_tokens": 200, "completion_tokens": 100})
    assert tr.total_tokens() == 450


def test_total_cost_with_known_pricing():
    tr = UsageTracker(prices={"gpt-test": (1.0, 2.0)})  # $1/M in, $2/M out
    tr.record("gpt-test", {"prompt_tokens": 1_000_000, "completion_tokens": 1_000_000})
    # 1M * $1 + 1M * $2 = $3.00
    assert tr.total_cost() == pytest.approx(3.0)


def test_total_cost_unknown_model_is_zero():
    tr = UsageTracker(prices={})  # no pricing for any model
    tr.record("mystery", {"prompt_tokens": 1_000, "completion_tokens": 500})
    assert tr.total_cost() == pytest.approx(0.0)


def test_total_cost_partial_pricing():
    tr = UsageTracker(prices={"a": (5.0, 10.0)})
    tr.record("a", {"prompt_tokens": 200_000, "completion_tokens": 100_000})
    # 0.2M * $5 + 0.1M * $10 = $1.00 + $1.00 = $2.00
    assert tr.total_cost() == pytest.approx(2.0)


def test_report_shape():
    tr = UsageTracker(prices={"x": (1.0, 1.0)})
    tr.record("x", {"prompt_tokens": 1_000_000, "completion_tokens": 500_000})
    rpt = tr.report()
    assert rpt["total_tokens"] == 1_500_000
    assert rpt["total_cost_usd"] == pytest.approx(1.5)
    assert "x" in rpt["by_model"]
    assert rpt["by_model"]["x"]["prompt_tokens"] == 1_000_000
    assert rpt["by_model"]["x"]["completion_tokens"] == 500_000
    assert rpt["by_model"]["x"]["requests"] == 1


def test_modelusage_total_tokens_property():
    u = ModelUsage(prompt_tokens=10, completion_tokens=20, requests=3)
    assert u.total_tokens == 30


def test_empty_tracker_totals_are_zero():
    tr = UsageTracker()
    assert tr.total_tokens() == 0
    assert tr.total_cost() == 0.0
    assert tr.report()["total_tokens"] == 0
    assert tr.report()["by_model"] == {}
