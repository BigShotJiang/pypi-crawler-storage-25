"""Tests for llm/models.py VRAM estimator (ported from LocalForge)."""

from __future__ import annotations

from llm.models import (
    compare_to_available,
    estimate_vram,
    pick_best_fit,
)


def test_parses_param_count_from_ollama_id():
    e = estimate_vram("ollama/qwen2.5:14b")
    assert e is not None
    assert e.params_b == 14
    assert e.vram_mb == 10500


def test_parses_param_count_from_huggingface_id():
    e = estimate_vram("ollama/google/gemma-4-31b")
    assert e is not None
    assert e.params_b == 31
    assert e.vram_mb == 21000


def test_decimal_params_supported():
    e = estimate_vram("ollama/llama3.2:3.2b")
    assert e is not None
    assert e.params_b == 3.2


def test_cloud_id_returns_none():
    assert estimate_vram("anthropic/claude-haiku-4-5") is None
    assert estimate_vram("claude-opus-4-7") is None


def test_compare_thresholds():
    # 70% boundary
    assert compare_to_available(7000, 10000) == "fits"
    assert compare_to_available(7001, 10000) == "tight"
    assert compare_to_available(10001, 10000) == "wont-fit"


def test_pick_best_fit_prefers_largest_comfortable():
    candidates = ["ollama/a:7b", "ollama/b:14b", "ollama/c:70b"]
    pick = pick_best_fit(candidates, 16000)
    assert pick is not None
    mid, est, status = pick
    assert mid == "ollama/b:14b"  # 14B fits @70% of 16GB; 7B is smaller
    assert status == "fits"


def test_pick_best_fit_falls_back_to_tight():
    """No comfortable fit exists → return the largest tight one."""
    candidates = ["ollama/a:24b", "ollama/b:35b"]
    pick = pick_best_fit(candidates, 16000)
    assert pick is not None
    mid, _, status = pick
    assert mid == "ollama/a:24b"
    assert status == "tight"


def test_pick_best_fit_returns_none_when_nothing_fits():
    pick = pick_best_fit(["ollama/big:200b"], 8000)
    assert pick is None
