"""Tests for `llm.fallback.FallbackLLMProvider` — retry-on-failure semantics.

We don't talk to a real LLM. Instead we build fake providers that
inherit from LLMProvider but override the methods to raise specific
exceptions or return canned responses. This exercises the chain
behaviour deterministically.
"""

from __future__ import annotations

import asyncio
from typing import Any
from unittest.mock import patch

import pytest

from llm.fallback import FallbackLLMProvider, build_fallback
from llm.provider import LLMProvider, LLMResponse


# ---- helpers ----------------------------------------------------------


class _Stub(LLMProvider):
    """LLMProvider whose `chat` either raises or returns a canned response.

    `mode` controls the behaviour:
      - "ok"        : return a stock LLMResponse with the model name in content
      - "retryable" : raise a TimeoutError (matches `_is_retryable`)
      - "fatal"     : raise a ValueError (does NOT match `_is_retryable`)
    """

    def __init__(self, model: str, mode: str = "ok"):
        super().__init__(model=model)
        self._mode = mode
        self.call_count = 0

    async def chat(self, *args: Any, **kwargs: Any) -> LLMResponse:
        self.call_count += 1
        if self._mode == "retryable":
            raise TimeoutError("upstream timed out")
        if self._mode == "fatal":
            raise ValueError("model not found: bad request")
        return LLMResponse(content=f"hello from {self.model}", model=self.model)


def _run(coro):
    """Sync-driver for an async coroutine — keeps tests simple without
    needing pytest-asyncio."""
    return asyncio.run(coro)


# ---- chain construction -----------------------------------------------


def test_init_rejects_non_provider_primary():
    with pytest.raises(TypeError):
        FallbackLLMProvider(primary="not-a-provider", fallbacks=[])  # type: ignore[arg-type]


def test_model_property_reflects_active_provider():
    a = _Stub("model-a")
    b = _Stub("model-b")
    chain = FallbackLLMProvider(primary=a, fallbacks=[b])
    # Initially active = primary
    assert chain.model == "model-a"


def test_build_fallback_returns_primary_when_no_fallbacks():
    primary = _Stub("only")
    out = build_fallback(primary, [])
    assert out is primary


# ---- retry behaviour --------------------------------------------------


def test_first_provider_succeeds_no_retry():
    a = _Stub("a", mode="ok")
    b = _Stub("b", mode="ok")
    chain = FallbackLLMProvider(primary=a, fallbacks=[b])

    resp = _run(chain.chat(messages=[]))
    assert resp.content == "hello from a"
    assert a.call_count == 1
    assert b.call_count == 0


def test_retryable_failure_falls_through_to_next():
    a = _Stub("a", mode="retryable")
    b = _Stub("b", mode="ok")
    chain = FallbackLLMProvider(primary=a, fallbacks=[b])

    resp = _run(chain.chat(messages=[]))
    assert resp.content == "hello from b"
    assert a.call_count == 1
    assert b.call_count == 1
    # active_idx now points at the successful fallback so .model
    # returns the live one
    assert chain.model == "b"


def test_chain_walks_through_multiple_failures():
    a = _Stub("a", mode="retryable")
    b = _Stub("b", mode="retryable")
    c = _Stub("c", mode="ok")
    chain = FallbackLLMProvider(primary=a, fallbacks=[b, c])

    resp = _run(chain.chat(messages=[]))
    assert resp.content == "hello from c"
    assert (a.call_count, b.call_count, c.call_count) == (1, 1, 1)


def test_fatal_error_does_not_fall_through():
    """Non-retryable errors (e.g. 400 bad request, model not found)
    should propagate immediately — falling back wouldn't help and
    just wastes more API calls."""
    a = _Stub("a", mode="fatal")
    b = _Stub("b", mode="ok")
    chain = FallbackLLMProvider(primary=a, fallbacks=[b])

    with pytest.raises(ValueError, match="model not found"):
        _run(chain.chat(messages=[]))
    assert a.call_count == 1
    assert b.call_count == 0   # never reached


def test_all_providers_fail_raises_last_error():
    a = _Stub("a", mode="retryable")
    b = _Stub("b", mode="retryable")
    chain = FallbackLLMProvider(primary=a, fallbacks=[b])

    with pytest.raises(TimeoutError):
        _run(chain.chat(messages=[]))
    assert a.call_count == 1
    assert b.call_count == 1


def test_complete_uses_same_fallback_machinery():
    """`complete` should follow the same chain semantics as `chat`."""
    class _CompleteStub(_Stub):
        async def complete(self, *args, **kwargs):
            return await self.chat(*args, **kwargs)

    a = _CompleteStub("a", mode="retryable")
    b = _CompleteStub("b", mode="ok")
    chain = FallbackLLMProvider(primary=a, fallbacks=[b])

    resp = _run(chain.complete(prompt="hi"))
    assert resp.content == "hello from b"


# ---- _is_retryable classification --------------------------------------


def test_is_retryable_classifies_known_substrings():
    from llm.provider import _is_retryable
    # Substring matches
    assert _is_retryable(Exception("upstream returned 503")) is True
    assert _is_retryable(Exception("rate limit hit")) is True
    assert _is_retryable(Exception("Read error: peer closed")) is True
    # Type matches
    assert _is_retryable(TimeoutError("idle")) is True
    assert _is_retryable(ConnectionError("nope")) is True


def test_is_retryable_rejects_deterministic_errors():
    from llm.provider import _is_retryable
    assert _is_retryable(ValueError("model not found")) is False
    assert _is_retryable(KeyError("missing field")) is False
    assert _is_retryable(Exception("bad request: invalid schema")) is False
