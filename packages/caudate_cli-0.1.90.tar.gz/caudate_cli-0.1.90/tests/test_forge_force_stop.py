"""Force-stop semantics: stop_session must demote the feature to backlog,
mark the session terminated, and emit a status event."""

from __future__ import annotations

import asyncio
from pathlib import Path

import pytest


@pytest.fixture
def tmp_forge_db(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    db = tmp_path / "forge_test.db"
    import planning.forge_models as fm
    monkeypatch.setattr(fm, "SQLITE_PATH", str(db), raising=False)
    if getattr(fm, "_engine", None) is not None:
        try:
            fm._engine.dispose()
        except Exception:
            pass
        fm._engine = None
    fm.init()
    yield fm
    try:
        fm._engine.dispose()
    except Exception:
        pass
    fm._engine = None


def test_stop_session_returns_feature_to_backlog(tmp_forge_db):
    """A running session that's force-stopped must:
       - mark its session row as 'terminated'
       - flip its feature back to 'backlog'
    """
    asyncio.run(_run_force_stop(tmp_forge_db))


async def _run_force_stop(tmp_forge_db):
    fm = tmp_forge_db
    pid = fm.create_project("stoptest", None, "/tmp/stoptest")
    fid = fm.create_feature(project_id=pid, title="long-running task")

    # Build a fake session row + manually flip feature to in_progress
    # to simulate what start_orchestrator would do.
    with fm.session_scope() as sess:
        sess.get(fm.ForgeFeature, fid).status = "in_progress"
        srow = fm.ForgeSession(
            project_id=pid, feature_id=fid,
            session_type="coding", status="in_progress",
        )
        sess.add(srow)
        sess.flush()
        sid = srow.id

    # Inject a fake running task into the orchestrator state so stop_session
    # finds something to cancel.
    import planning.orchestrator as orch

    async def _never_returns():
        await asyncio.sleep(60)

    task = asyncio.create_task(_never_returns())
    # Use a duck-typed stand-in so we don't track the orchestrator's
    # private dataclass shape (started_at etc) in the test.
    from types import SimpleNamespace
    rs = SimpleNamespace(
        session_id=sid, project_id=pid, feature_id=fid, task=task,
        started_at=__import__("time").time(),
    )
    orch._state().running[sid] = rs

    # Force-stop. stop_session() returns True when it cancels a live task.
    cancelled = orch.stop_session(sid)
    assert cancelled is True

    # finalize_session does not run automatically here (the task was a stub),
    # so call it explicitly to mirror what _run_session_with_watchdog does.
    orch.finalize_session(sid, "terminated", "test")

    # Check DB state
    with fm.session_scope() as sess:
        srow = sess.get(fm.ForgeSession, sid)
        assert srow.status == "terminated"
        feat = sess.get(fm.ForgeFeature, fid)
        assert feat.status == "backlog", (
            f"feature should be back in backlog, got {feat.status!r}"
        )
    task.cancel()


def test_stop_session_idempotent_after_exit(tmp_forge_db):
    """stop_session on a finished session should be safe (returns False)."""
    fm = tmp_forge_db
    pid = fm.create_project("idem", None, "/tmp/idem")
    fid = fm.create_feature(project_id=pid, title="t")
    with fm.session_scope() as sess:
        srow = fm.ForgeSession(
            project_id=pid, feature_id=fid,
            session_type="coding", status="in_progress",
        )
        sess.add(srow)
        sess.flush()
        sid = srow.id

    import planning.orchestrator as orch
    # No entry in running map → stop returns False but still finalises.
    assert orch.stop_session(sid) is False
    with fm.session_scope() as sess:
        assert sess.get(fm.ForgeSession, sid).status == "terminated"
