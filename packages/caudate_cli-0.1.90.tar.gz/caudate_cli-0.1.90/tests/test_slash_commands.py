"""Tests for `core.slash_commands.dispatch` (and `is_slash`).

Uses a Mock agent — most slash handlers reach into agent attributes,
so individual handler behaviour is out of scope here. We verify the
dispatch *protocol*: slash detection, fall-through for plain text,
and the unknown-command path.
"""

from __future__ import annotations

from unittest.mock import MagicMock

from rich.console import Console

from core.slash_commands import SlashContext, dispatch, is_slash


def _ctx() -> SlashContext:
    """Minimal SlashContext with a Mock agent that any handler can poke."""
    return SlashContext(
        agent=MagicMock(),
        console=Console(quiet=True),
        settings=None,
    )


# ---- is_slash ---------------------------------------------------------


def test_is_slash_true_for_leading_slash():
    assert is_slash("/help") is True
    assert is_slash("/help args") is True


def test_is_slash_false_with_leading_whitespace():
    # Concrete: actual rule is `startswith("/")`, so leading
    # whitespace breaks it.
    assert is_slash("  /help") is False
    assert is_slash("\t/help") is False


def test_is_slash_false_for_plain_text():
    assert is_slash("plain text") is False
    assert is_slash("not /a/slash") is False
    assert is_slash("") is False


def test_is_slash_false_for_double_slash_comment():
    # Comment-style `//foo` shouldn't trip slash detection
    assert is_slash("//comment") is False


def test_is_slash_false_for_just_a_slash_alone():
    # `/` alone (length 1) doesn't pass the `len > 1` check
    assert is_slash("/") is False
    # And dispatch on it returns None — falls through like plain text
    assert dispatch("/", _ctx()) is None


# ---- dispatch — non-slash pass-through --------------------------------


def test_dispatch_returns_none_for_plain_text():
    """When the input isn't a slash command, dispatch returns None
    so the caller can fall through to normal chat."""
    assert dispatch("hi how are you", _ctx()) is None
    assert dispatch("just words", _ctx()) is None


# ---- dispatch — unknown command ---------------------------------------


def test_dispatch_unknown_command_reports_unknown():
    result = dispatch("/totallymadeupcommand", _ctx())
    assert isinstance(result, str)
    # The handler returns a rich-markup string mentioning "/help"
    assert "totallymadeupcommand" in result
    assert "/help" in result


def test_dispatch_unknown_command_with_args():
    result = dispatch("/nope some args here", _ctx())
    assert isinstance(result, str)
    assert "nope" in result


# ---- dispatch — known commands smoke -----------------------------------


def test_dispatch_help_returns_string():
    """`/help` is the cheapest known handler that has no agent dependency
    beyond the registry. Verify it returns *something* non-None — full
    help text validation is its own concern."""
    result = dispatch("/help", _ctx())
    # /help renders a Rich table to ctx.console; the function itself
    # may return either the rendered string or an empty string + the
    # printed table. Accept any non-None result.
    assert result is not None


def test_dispatch_lone_slash_falls_through_to_chat():
    """`/` (one char) doesn't pass `is_slash`, so dispatch returns None
    and the caller falls through to normal chat. Concrete behaviour
    based on the `len > 1` check in `is_slash`."""
    result = dispatch("/", _ctx())
    assert result is None


# ---- dispatch — handler error doesn't crash ----------------------------


def test_dispatch_handler_exception_returns_error_string(monkeypatch):
    """If a handler raises, dispatch should catch it and return a
    user-visible error string rather than propagating."""
    from core import slash_commands as sc

    # Inject a deliberately-broken handler under a unique name
    def _explode(ctx, args):
        raise RuntimeError("kaboom")

    monkeypatch.setitem(sc.REGISTRY, "boomtest", _explode)
    result = dispatch("/boomtest", _ctx())
    assert isinstance(result, str)
    assert "boomtest" in result
    assert "failed" in result.lower() or "kaboom" in result.lower()
