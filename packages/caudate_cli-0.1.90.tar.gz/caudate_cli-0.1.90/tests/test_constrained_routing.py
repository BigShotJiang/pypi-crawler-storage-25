"""Tests for ADR-0007 constrained routing in
`AgenticLoop._caudate_constrained_tools`.

We unit-test the helper in isolation — there's no LLM call here, no
training, no real Caudate. The helper looks at:

  - caudate.can_advise() / can_whisper()
  - caudate._last_prediction (a `Prediction` dataclass)
  - caudate.cfg.advisor_min_confidence / advisor_top_k / advisor_top_k_floor

That's all stubbable with `SimpleNamespace`. We instantiate AgenticLoop
via `object.__new__` and stick a fake `caudate` on it, since
`AgenticLoop.__init__` would pull in MiniLM, the executor, etc.
"""

from __future__ import annotations

from types import SimpleNamespace

from core.agentic_loop import AgenticLoop
from nn.runtime import Prediction


# Canonical 6-tool OAI-style tool list — what the executor would emit.
TOOLS = [
    {"type": "function", "function": {"name": "Bash"}},
    {"type": "function", "function": {"name": "Read"}},
    {"type": "function", "function": {"name": "Edit"}},
    {"type": "function", "function": {"name": "WebSearch"}},
    {"type": "function", "function": {"name": "PythonExec"}},
    {"type": "function", "function": {"name": "Calculator"}},
]


def _fresh_loop():
    """An AgenticLoop bypassing __init__ — we only test the helper."""
    return object.__new__(AgenticLoop)


def _cfg(min_conf=0.55, top_k=5, floor=3):
    return SimpleNamespace(
        advisor_min_confidence=min_conf,
        advisor_top_k=top_k,
        advisor_top_k_floor=floor,
    )


def _caudate(
    *,
    can_advise: bool,
    pred: Prediction | None,
    cfg=None,
):
    return SimpleNamespace(
        can_advise=lambda: can_advise,
        _last_prediction=pred,
        cfg=cfg or _cfg(),
    )


def _pred(tool: str, conf: float, top_k: list[tuple[str, float]]) -> Prediction:
    return Prediction(
        tool=tool, tool_confidence=conf,
        tier="fast", tier_confidence=1.0,
        think=0.0, value=0.0,
        tool_top_k=top_k,
    )


# ---------------------------------------------------------------- no-op paths


def test_no_caudate_returns_full_list():
    loop = _fresh_loop()
    loop.caudate = None
    assert loop._caudate_constrained_tools(TOOLS) == TOOLS


def test_below_advisor_returns_full_list():
    loop = _fresh_loop()
    loop.caudate = _caudate(can_advise=False, pred=_pred("Bash", 0.99, [("Bash", 0.99)]))
    assert loop._caudate_constrained_tools(TOOLS) == TOOLS


def test_no_prediction_returns_full_list():
    loop = _fresh_loop()
    loop.caudate = _caudate(can_advise=True, pred=None)
    assert loop._caudate_constrained_tools(TOOLS) == TOOLS


def test_no_tool_prediction_returns_full_list():
    """ADR-0007 explicitly chose soft-suggest for <no_tool>."""
    loop = _fresh_loop()
    loop.caudate = _caudate(
        can_advise=True,
        pred=_pred("<no_tool>", 0.99, [("Bash", 0.5)]),
    )
    assert loop._caudate_constrained_tools(TOOLS) == TOOLS


def test_unk_prediction_returns_full_list():
    loop = _fresh_loop()
    loop.caudate = _caudate(
        can_advise=True,
        pred=_pred("<unk>", 0.99, [("Bash", 0.5)]),
    )
    assert loop._caudate_constrained_tools(TOOLS) == TOOLS


def test_low_confidence_returns_full_list():
    loop = _fresh_loop()
    loop.caudate = _caudate(
        can_advise=True,
        pred=_pred("Bash", 0.40, [("Bash", 0.40)]),
        cfg=_cfg(min_conf=0.55),
    )
    assert loop._caudate_constrained_tools(TOOLS) == TOOLS


def test_empty_top_k_returns_full_list():
    """Pre-top-K checkpoint compat — old Prediction objects had no top-K."""
    loop = _fresh_loop()
    loop.caudate = _caudate(
        can_advise=True,
        pred=_pred("Bash", 0.99, []),
    )
    assert loop._caudate_constrained_tools(TOOLS) == TOOLS


# ---------------------------------------------------------------- happy path


def test_prunes_to_top_k_when_confident_and_advisor():
    loop = _fresh_loop()
    loop.caudate = _caudate(
        can_advise=True,
        pred=_pred("Bash", 0.85, [
            ("Bash", 0.85), ("Read", 0.06), ("Edit", 0.04),
        ]),
        cfg=_cfg(top_k=3, floor=3),
    )
    out = loop._caudate_constrained_tools(TOOLS)
    names = {t["function"]["name"] for t in out}
    assert names == {"Bash", "Read", "Edit"}


def test_predicted_tool_always_included_even_if_outside_top_k_slice():
    """Belt-and-braces: predicted tool is forced in, even if a tighter
    cfg.advisor_top_k cuts it out of the slice (shouldn't happen in
    practice since it's slot 0, but we want the contract to hold)."""
    loop = _fresh_loop()
    # Top-K slot 0 is *not* the predicted tool here — synthetic
    # adversarial top_k where the predicted tool sneaks in via the
    # explicit pred.tool field.
    loop.caudate = _caudate(
        can_advise=True,
        pred=_pred("Calculator", 0.80, [
            ("Bash", 0.30), ("Read", 0.20), ("Edit", 0.10),
        ]),
        cfg=_cfg(top_k=3, floor=3),
    )
    out = loop._caudate_constrained_tools(TOOLS)
    names = {t["function"]["name"] for t in out}
    assert "Calculator" in names  # always-include contract
    # And the top 3 from top_k are also there.
    assert {"Bash", "Read", "Edit"}.issubset(names)


def test_bails_to_full_list_when_floor_violated():
    """If filtering yields fewer than `advisor_top_k_floor` tools (e.g.
    top-K names don't exist in the executor's actual list), bail rather
    than ship a 1-tool list to the LLM."""
    loop = _fresh_loop()
    loop.caudate = _caudate(
        can_advise=True,
        pred=_pred("Bash", 0.99, [
            ("Bash", 0.99), ("GhostToolA", 0.0), ("GhostToolB", 0.0),
        ]),
        cfg=_cfg(top_k=3, floor=3),
    )
    # Only "Bash" actually exists in TOOLS → 1 survivor, below floor=3.
    assert loop._caudate_constrained_tools(TOOLS) == TOOLS


def test_advisor_top_k_floor_respected_when_top_k_smaller():
    """`max(top_k, floor)` ensures the floor wins when configured top-K
    is tighter than the safety floor."""
    loop = _fresh_loop()
    loop.caudate = _caudate(
        can_advise=True,
        pred=_pred("Bash", 0.90, [
            ("Bash", 0.50), ("Read", 0.20), ("Edit", 0.15), ("WebSearch", 0.10),
        ]),
        cfg=_cfg(top_k=1, floor=3),
    )
    out = loop._caudate_constrained_tools(TOOLS)
    names = {t["function"]["name"] for t in out}
    # floor=3 wins over top_k=1, so 3 tools (plus always-include) survive.
    assert "Bash" in names
    assert len(names) >= 3
