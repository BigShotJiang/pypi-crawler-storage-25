"""ADR-0006 Phase A — feature_success head, corpus loader, and the
forge_advisor wiring that prefers a trained head over the heuristic.

These tests do NOT require a trained checkpoint on disk. The
checkpoint-detection path is exercised via a hand-built CaudateAdvisor
whose feature_success head bias is either zero (untrained) or non-zero
(trained), since that's the signal `predict_feature_success` uses to
decide whether to return None or a real prediction.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest


def test_feature_success_head_registered_in_specs():
    """The head must appear in EXTENDED_HEADS so Caudate builds it."""
    from nn.heads import ALL_HEADS
    names = [s.name for s in ALL_HEADS]
    assert "feature_success" in names
    spec = next(s for s in ALL_HEADS if s.name == "feature_success")
    assert spec.loss_type == "bce"
    assert spec.optional_target is True
    assert spec.out_dim == 1
    assert spec.output_key == "feature_success_logit"


def test_corpus_loader_dedupes_retries_by_feature_id(tmp_path: Path):
    """A feature that retried 50 times before parking must contribute
    one sample (the final outcome), not 50 — otherwise stuck features
    dominate the corpus and the head learns 'always predict fail'."""
    from nn.data import load_corpus_from_feature_outcomes
    path = tmp_path / "feature_outcomes.jsonl"
    # Feature 7 retried 4 times: 3 fails then a success
    retries = [
        {"ts": float(i), "feature_text": "stubborn feature",
         "model_used": "m", "success": i == 3, "project_id": 1,
         "feature_id": 7}
        for i in range(4)
    ]
    # Feature 8 retried 2 times and ended in failure (parked)
    parked = [
        {"ts": 10.0, "feature_text": "broken feature",
         "model_used": "m", "success": False, "project_id": 1,
         "feature_id": 8},
        {"ts": 11.0, "feature_text": "broken feature",
         "model_used": "m", "success": False, "project_id": 1,
         "feature_id": 8},
    ]
    path.write_text("\n".join(json.dumps(r) for r in retries + parked))

    corpus = load_corpus_from_feature_outcomes(path)
    assert len(corpus) == 2, (
        "expected dedup to collapse retries to 2 samples (one per "
        f"feature_id), got {len(corpus)}"
    )
    # Stubborn feature ended in success — keyed by the feature text
    # which now lives in conversation[0].content.
    by_text = {s.conversation[0].content: s for s in corpus}
    assert by_text["stubborn feature"].target_feature_success == 1.0
    assert by_text["broken feature"].target_feature_success == 0.0


def test_corpus_loader_no_dedupe_keeps_every_row(tmp_path: Path):
    """Opt-out mode preserves per-session granularity for retry analysis."""
    from nn.data import load_corpus_from_feature_outcomes
    path = tmp_path / "feature_outcomes.jsonl"
    retries = [
        {"ts": float(i), "feature_text": "stubborn",
         "model_used": "m", "success": i == 3, "project_id": 1,
         "feature_id": 7}
        for i in range(4)
    ]
    path.write_text("\n".join(json.dumps(r) for r in retries))
    corpus = load_corpus_from_feature_outcomes(path, dedupe_by_feature=False)
    assert len(corpus) == 4


def test_corpus_loader_parses_real_schema(tmp_path: Path):
    """Loader must accept the schema the orchestrator actually writes."""
    from nn.data import load_corpus_from_feature_outcomes
    path = tmp_path / "feature_outcomes.jsonl"
    rows = [
        {"ts": 1.0, "feature_text": "add /healthz endpoint",
         "model_used": "ollama/glm-5.1:cloud", "n_turns": 4,
         "n_tool_calls": 3, "success": True, "duration_s": 42.5},
        {"ts": 2.0, "feature_text": "implement oauth flow",
         "model_used": "anthropic/claude-haiku-4-5", "n_turns": 12,
         "n_tool_calls": 12, "success": False, "duration_s": 800.0},
        # Garbage row — must be skipped, not crash the loader
        {"junk": "no feature_text or success"},
        # Empty feature_text — skip
        {"feature_text": "", "model_used": "m", "success": True},
    ]
    path.write_text("\n".join(json.dumps(r) for r in rows))

    corpus = load_corpus_from_feature_outcomes(path)
    assert len(corpus) == 2
    # Order isn't guaranteed by dedupe (dict iteration), so look up by text
    by_text = {s.conversation[0].content: s for s in corpus}
    s_ok = by_text["add /healthz endpoint"]
    assert s_ok.conversation[0].role == "user"
    assert s_ok.model_source == "ollama/glm-5.1:cloud"
    assert s_ok.target_feature_success == 1.0
    # target_tool defaulted to <no_tool> so collate doesn't trip
    assert s_ok.target_tool == "<no_tool>"
    s_fail = by_text["implement oauth flow"]
    assert s_fail.target_feature_success == 0.0
    assert s_fail.model_source == "anthropic/claude-haiku-4-5"


def test_collate_emits_feature_success_target_when_present():
    """When all batch samples carry the label, collate must surface it."""
    from nn.data import ConversationSample, ToolVocab, collate
    from nn.format import ChatMessage
    from nn.config import NNConfig
    samples = [
        ConversationSample(
            conversation=[ChatMessage(role="user", content="add a healthcheck route")],
            tools=[], mood=[0.5]*4,
            target_tool="<no_tool>", target_value=1.0,
            target_feature_success=1.0,
        ),
        ConversationSample(
            conversation=[ChatMessage(role="user", content="implement consensus protocol")],
            tools=[], mood=[0.5]*4,
            target_tool="<no_tool>", target_value=0.0,
            target_feature_success=0.0,
        ),
    ]
    batch = collate(samples, NNConfig(), ToolVocab())
    assert "target_feature_success" in batch
    vals = batch["target_feature_success"].tolist()
    assert vals == [1.0, 0.0]


def test_collate_drops_target_when_any_sample_missing():
    """Mixed batches drop the label so optional_target skips the head."""
    from nn.data import ConversationSample, ToolVocab, collate
    from nn.format import ChatMessage
    from nn.config import NNConfig
    samples = [
        ConversationSample(
            conversation=[ChatMessage(role="user", content="m1")],
            tools=[], mood=[0.5]*4,
            target_tool="<no_tool>", target_value=1.0,
            target_feature_success=1.0,
        ),
        ConversationSample(
            conversation=[ChatMessage(role="user", content="m2")],
            tools=[], mood=[0.5]*4,
            target_tool="<no_tool>", target_value=0.0,
            target_feature_success=None,  # missing label
        ),
    ]
    batch = collate(samples, NNConfig(), ToolVocab())
    assert "target_feature_success" not in batch


def test_advisor_returns_none_when_head_untrained():
    """predict_feature_success must return None when the head bias is
    at its zero-init — otherwise the orchestrator would treat noise
    as a real Caudate signal."""
    import torch
    from nn.config import NNConfig
    from nn.caudate import Caudate
    from nn.data import ToolVocab, SourceVocab
    from nn.runtime import CaudateAdvisor

    cfg = NNConfig()
    model = Caudate(cfg)
    # Confirm the head exists and its bias is zero (Xavier init)
    head_mod = model.heads.feature_success
    assert torch.allclose(head_mod[-1].bias, torch.zeros_like(head_mod[-1].bias))

    adv = CaudateAdvisor(cfg=cfg, model=model, vocab=ToolVocab(),
                        source_vocab=SourceVocab())
    result = adv.predict_feature_success("anything", "some-model")
    assert result is None, (
        "untrained head must report None so forge_advisor falls back "
        "to the baseline; otherwise the orchestrator will be biased "
        "by random Xavier weights."
    )


def test_advisor_returns_dict_when_head_appears_trained():
    """Tweak the head's bias and verify predict_feature_success returns
    a sane dict with success_prob in [0,1]."""
    import torch
    from nn.config import NNConfig
    from nn.caudate import Caudate
    from nn.data import ToolVocab, SourceVocab
    from nn.runtime import CaudateAdvisor

    cfg = NNConfig()
    model = Caudate(cfg)
    # Move the bias off zero to simulate "trained". Value is small so
    # the resulting probability stays mid-range.
    with torch.no_grad():
        model.heads.feature_success[-1].bias.fill_(0.1)

    adv = CaudateAdvisor(cfg=cfg, model=model, vocab=ToolVocab(),
                        source_vocab=SourceVocab())
    result = adv.predict_feature_success("add /healthz route", "m1")
    assert isinstance(result, dict)
    assert 0.0 <= result["success_prob"] <= 1.0
    assert "reason" in result


def test_forge_advisor_picks_caudate_over_baseline(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
):
    """When the trained head is available, forge_advisor must use it
    instead of the heuristic — that's the whole point of Phase A."""
    import nn.forge_advisor as fa
    # Make the advisor cache forget any prior advisor (other tests may
    # have populated it).
    fa.reset_advisor_cache()

    # Hand-build a fake advisor whose predict_feature_success returns
    # a known value. Monkeypatch _get_advisor so we don't need a real
    # checkpoint on disk.
    class FakeAdvisor:
        def predict_feature_success(self, feature_text, model_id=None):
            return {"success_prob": 0.83, "reason": "fake trained head"}

    monkeypatch.setattr(fa, "_get_advisor", lambda: FakeAdvisor())

    # Also point the heuristic at an empty outcomes file so we'd otherwise
    # be in the fallback path. The trained head should win regardless.
    outcomes = tmp_path / "feature_outcomes.jsonl"
    monkeypatch.setattr(fa, "_OUTCOMES_PATH", outcomes, raising=False)
    monkeypatch.setattr(fa, "_AUDIT_PATH", tmp_path / "audit.jsonl",
                        raising=False)

    pred = fa.predict_feature_difficulty("anything", "some-model")
    assert pred.source == "caudate"
    assert pred.success_prob == pytest.approx(0.83, abs=1e-6)


def test_forge_advisor_falls_back_when_advisor_returns_none(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
):
    """If the cached advisor exists but its head is untrained (returns
    None), forge_advisor must fall back to the baseline — not crash
    and not report source='caudate'."""
    import nn.forge_advisor as fa
    fa.reset_advisor_cache()

    class FakeAdvisorUntrained:
        def predict_feature_success(self, feature_text, model_id=None):
            return None

    monkeypatch.setattr(fa, "_get_advisor", lambda: FakeAdvisorUntrained())
    outcomes = tmp_path / "feature_outcomes.jsonl"
    monkeypatch.setattr(fa, "_OUTCOMES_PATH", outcomes, raising=False)
    monkeypatch.setattr(fa, "_AUDIT_PATH", tmp_path / "audit.jsonl",
                        raising=False)

    pred = fa.predict_feature_difficulty("anything", "m")
    assert pred.source in {"fallback", "baseline"}
