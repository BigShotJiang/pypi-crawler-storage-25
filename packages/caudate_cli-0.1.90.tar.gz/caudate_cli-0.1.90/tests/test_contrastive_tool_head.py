"""Tests for the Phase-2 contrastive tool head + collate/trainer wiring."""

from __future__ import annotations

import pytest
import torch


def test_collate_prepends_no_tool_slot():
    """First candidate slot must always be <no_tool> so 'answer
    directly' is a real predictable class, not an absence."""
    from nn.config import NNConfig
    from nn.data import ConversationSample, ToolVocab, collate
    from nn.format import ChatMessage, ToolDef
    samples = [
        ConversationSample(
            conversation=[ChatMessage(role="user", content="hi")],
            tools=[ToolDef(name="a"), ToolDef(name="b")],
            target_tool="a",
        ),
    ]
    batch = collate(samples, NNConfig(), ToolVocab())
    assert batch["tool_specs"][0][0].startswith("<no_tool>:")
    assert "a:" in batch["tool_specs"][0][1] or batch["tool_specs"][0][1] == "a"
    # target_tool "a" → slot 1 (after the <no_tool> prefix)
    assert int(batch["target_tool_idx"][0].item()) == 1
    assert bool(batch["tool_target_valid"][0].item()) is True


def test_collate_marks_invalid_when_target_not_in_candidates():
    """If the called tool isn't in the candidate list, this sample
    must be marked invalid so the trainer skips its contribution to
    the tool loss instead of training the head against noise."""
    from nn.config import NNConfig
    from nn.data import ConversationSample, ToolVocab, collate
    from nn.format import ChatMessage, ToolDef
    samples = [
        ConversationSample(
            conversation=[ChatMessage(role="user", content="hi")],
            tools=[ToolDef(name="a")],
            target_tool="z",  # not in tools[]
        ),
    ]
    batch = collate(samples, NNConfig(), ToolVocab())
    assert int(batch["target_tool_idx"][0].item()) == -1
    assert bool(batch["tool_target_valid"][0].item()) is False


def test_collate_no_tool_target_maps_to_slot_zero():
    """When target_tool == '<no_tool>', it must point at the synthetic
    no_tool slot (index 0)."""
    from nn.config import NNConfig
    from nn.data import ConversationSample, ToolVocab, collate
    from nn.format import ChatMessage, ToolDef
    samples = [
        ConversationSample(
            conversation=[ChatMessage(role="user", content="hi")],
            tools=[ToolDef(name="a"), ToolDef(name="b")],
            target_tool="<no_tool>",
        ),
    ]
    batch = collate(samples, NNConfig(), ToolVocab())
    assert int(batch["target_tool_idx"][0].item()) == 0
    assert bool(batch["tool_target_valid"][0].item()) is True


def test_forward_emits_tool_logits_and_mask():
    """Caudate.forward must surface tool_logits + tool_mask when
    candidates are supplied. Mask must be true for valid slots only."""
    from nn.config import NNConfig
    from nn.caudate import Caudate
    from nn.data import ConversationSample, ToolVocab, SourceVocab, collate
    from nn.format import ChatMessage, ToolDef
    cfg = NNConfig()
    model = Caudate(cfg)
    samples = [
        ConversationSample(
            conversation=[ChatMessage(role="user", content="search python")],
            tools=[ToolDef(name="web_search", description="search the web"),
                   ToolDef(name="read_file", description="read a file")],
            target_tool="web_search",
        ),
    ]
    batch = collate(samples, cfg, ToolVocab(), source_vocab=SourceVocab())
    out = model(
        messages=batch["messages"],
        tool_ids=batch["tool_ids"],
        mood=batch["mood"],
        image_paths=batch.get("image_paths"),
        source_id=batch.get("source_id"),
        tool_specs=batch.get("tool_specs"),
    )
    assert "tool_logits" in out
    assert "tool_mask" in out
    K = cfg.max_tools_per_sample
    assert out["tool_logits"].shape == (1, K)
    # Three valid candidates (<no_tool>, web_search, read_file)
    assert int(out["tool_mask"][0].sum().item()) == 3
    # Invalid slots in the logits are -inf-ish (≤ -1e8)
    invalid = out["tool_logits"][0][~out["tool_mask"][0]]
    assert (invalid <= -1e8).all()


def test_contrastive_loss_skips_invalid_rows():
    """contrastive_loss must contribute zero gradient when no row in
    the batch has a valid target — otherwise mostly-invalid batches
    would crash on cross_entropy with empty input."""
    from nn.heads import ContrastiveToolHead
    logits = torch.randn(4, 8, requires_grad=True)
    target = torch.full((4,), -1, dtype=torch.long)
    valid = torch.zeros(4, dtype=torch.bool)
    loss = ContrastiveToolHead.contrastive_loss(logits, target, valid)
    # Backward should run and produce zero grad on the input
    loss.backward()
    assert loss.item() == 0.0


def test_contrastive_loss_trains_when_some_rows_valid():
    """When half the rows are valid, loss must be real (non-zero) and
    flow gradient only through those rows."""
    from nn.heads import ContrastiveToolHead
    logits = torch.randn(4, 8, requires_grad=True)
    target = torch.tensor([2, -1, 5, -1], dtype=torch.long)
    valid = torch.tensor([True, False, True, False])
    loss = ContrastiveToolHead.contrastive_loss(logits, target, valid)
    assert loss.item() > 0.0


def test_trainer_runs_with_tool_candidates():
    """Trainer.fit must complete a few steps on a tiny corpus and
    surface loss_tool + tool_acc in the metrics."""
    from nn.config import NNConfig
    from nn.trainer import build_fresh
    from nn.data import ConversationSample
    from nn.format import ChatMessage, ToolDef
    cfg = NNConfig()
    cfg.max_steps = 4
    cfg.batch_size = 4
    trainer = build_fresh(cfg)
    samples = [
        ConversationSample(
            conversation=[ChatMessage(role="user", content=f"query {i}")],
            tools=[ToolDef(name="ws", description="web search"),
                   ToolDef(name="rf", description="read file")],
            target_tool="ws" if i % 2 else "rf",
            target_tier=0, target_think=0.0, target_value=0.5,
        )
        for i in range(16)
    ]
    history = trainer.fit(samples)
    assert history, "trainer produced no history"
    # The metrics dict must have loss_tool present
    assert hasattr(history[-1], "loss_tool")


def test_advisor_predict_with_available_tools(tmp_path):
    """advisor.predict(..., available_tools=...) must return a tool
    name from the supplied list (or '<no_tool>')."""
    from nn.config import NNConfig
    from nn.caudate import Caudate
    from nn.runtime import CaudateAdvisor
    from nn.data import ToolVocab, SourceVocab
    from nn.format import ToolDef
    cfg = NNConfig()
    model = Caudate(cfg)
    adv = CaudateAdvisor(cfg=cfg, model=model, vocab=ToolVocab(),
                         source_vocab=SourceVocab())
    pred = adv.predict(
        messages=["user: read foo.txt please"],
        tool_history=[],
        mood=[0.5]*4,
        available_tools=[
            ToolDef(name="read_file", description="read a local file"),
            ToolDef(name="web_search", description="search the web"),
        ],
    )
    assert pred.tool in ("<no_tool>", "read_file", "web_search")
    assert 0.0 <= pred.tool_confidence <= 1.0


def test_advisor_predict_without_tools_returns_no_tool():
    """No candidates → tool='<no_tool>' with zero confidence (not
    a fabricated guess)."""
    from nn.config import NNConfig
    from nn.caudate import Caudate
    from nn.runtime import CaudateAdvisor
    from nn.data import ToolVocab, SourceVocab
    cfg = NNConfig()
    model = Caudate(cfg)
    adv = CaudateAdvisor(cfg=cfg, model=model, vocab=ToolVocab(),
                         source_vocab=SourceVocab())
    pred = adv.predict(
        messages=["user: hi"],
        tool_history=[],
        mood=[0.5]*4,
        available_tools=None,
    )
    # With no available_tools the head's <no_tool> slot is the only
    # candidate, so the head will always pick it (or the head sits
    # out and we default to <no_tool>).
    assert pred.tool == "<no_tool>"
