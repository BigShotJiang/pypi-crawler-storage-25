"""Tests for Caudate's standard chat-tool-call format (nn/format.py)
and the ConversationSample pipeline (nn/data.py).

These tests pin the exact schema we're committing to so future changes
that break OpenAI compatibility get caught immediately.
"""

from __future__ import annotations

import json
from pathlib import Path


def test_spec_example_round_trip():
    """The reference example from the user's spec must round-trip
    through Conversation.from_dict → to_dict cleanly."""
    from nn.format import Conversation

    spec = {
        "messages": [
            {"role": "system",
             "content": "You are a helpful assistant with access to tools..."},
            {"role": "user", "content": "Search for Python tutorials"},
            {"role": "assistant", "content": "",
             "tool_calls": [
                 {"type": "function",
                  "function": {"name": "web_search",
                               "arguments": '{"query": "Python tutorials"}'}}
             ]},
            {"role": "tool", "name": "web_search",
             "content": "Results: ..."},
            {"role": "assistant",
             "content": "Here are some Python tutorials..."},
        ],
        "tools": [
            {"type": "function",
             "function": {"name": "web_search",
                          "description": "Search the web",
                          "parameters": {"type": "object"}}}
        ],
    }
    conv = Conversation.from_dict(spec)
    assert len(conv.messages) == 5
    assert conv.messages[0].role == "system"
    assert conv.messages[2].tool_calls[0].name == "web_search"
    assert conv.messages[3].name == "web_search"
    assert len(conv.tools) == 1
    assert conv.tools[0].name == "web_search"

    # Round-trip: to_dict should produce a structure we can re-parse
    # into an equivalent Conversation.
    again = Conversation.from_dict(conv.to_dict())
    assert again.messages[2].tool_calls[0].name == "web_search"
    assert again.tools[0].description == "Search the web"


def test_legacy_conversations_field_accepted():
    """Some datasets use ``conversations`` instead of ``messages``.
    The loader must accept both so xLAM and ToolBench files parse."""
    from nn.format import Conversation
    legacy = {
        "conversations": [
            {"role": "user", "content": "hi"},
            {"role": "assistant", "content": "hello"},
        ],
        "tools": [],
    }
    conv = Conversation.from_dict(legacy)
    assert len(conv.messages) == 2
    assert conv.messages[0].content == "hi"


def test_tool_call_accepts_dict_arguments():
    """Some datasets emit `arguments` as a dict instead of a JSON string.
    ToolCall.from_dict must normalise both to a JSON string so the
    downstream collate path sees one shape."""
    from nn.format import ToolCall
    tc = ToolCall.from_dict({
        "function": {"name": "search", "arguments": {"query": "foo"}},
    })
    assert tc.name == "search"
    # Arguments comes back as JSON-encoded string
    parsed = json.loads(tc.arguments)
    assert parsed == {"query": "foo"}


def test_content_blocks_flatten_to_text():
    """OpenAI vision-style content blocks (list of dicts with `text`)
    must flatten to a single string. The encoder consumes text; vision
    flows through image_paths on ConversationSample, not here."""
    from nn.format import ChatMessage
    msg = ChatMessage.from_dict({
        "role": "user",
        "content": [
            {"type": "text", "text": "what's in this image?"},
            {"type": "image_url", "image_url": {"url": "..."}},
        ],
    })
    assert "what's in this image?" in msg.content


def test_iter_assistant_tool_calls_yields_one_per_call():
    """Multi-call assistant turns must yield one (msg_idx, ToolCall)
    pair per call so the loader can emit one training sample per call."""
    from nn.format import Conversation, iter_assistant_tool_calls
    conv = Conversation.from_dict({
        "messages": [
            {"role": "user", "content": "do two things"},
            {"role": "assistant", "content": "", "tool_calls": [
                {"type": "function",
                 "function": {"name": "a", "arguments": "{}"}},
                {"type": "function",
                 "function": {"name": "b", "arguments": "{}"}},
            ]},
        ],
        "tools": [],
    })
    pairs = iter_assistant_tool_calls(conv)
    assert len(pairs) == 2
    assert [tc.name for _, tc in pairs] == ["a", "b"]


def test_oai_loader_emits_one_sample_per_tool_call(tmp_path: Path):
    """The xLAM-style JSONL loader emits one ConversationSample per
    assistant tool_call, with the message-prefix as context."""
    from nn.data import load_corpus_from_oai_jsonl
    p = tmp_path / "tool_corpus.jsonl"
    rows = [
        {
            "messages": [
                {"role": "user", "content": "find python tutorials"},
                {"role": "assistant", "content": "", "tool_calls": [
                    {"type": "function",
                     "function": {"name": "web_search",
                                  "arguments": '{"query": "python tutorials"}'}}
                ]},
                {"role": "tool", "name": "web_search",
                 "content": "Results..."},
                {"role": "assistant", "content": "Here you go..."},
            ],
            "tools": [
                {"type": "function",
                 "function": {"name": "web_search",
                              "description": "Search the web",
                              "parameters": {"type": "object"}}}
            ],
        },
        # A second conversation with two tool calls in one turn
        {
            "messages": [
                {"role": "user", "content": "do two things"},
                {"role": "assistant", "content": "", "tool_calls": [
                    {"type": "function",
                     "function": {"name": "a", "arguments": "{}"}},
                    {"type": "function",
                     "function": {"name": "b", "arguments": "{}"}},
                ]},
            ],
            "tools": [],
        },
        # A malformed row — loader must skip it without crashing
        "this is not JSON",
    ]
    with p.open("w") as f:
        for r in rows:
            if isinstance(r, str):
                f.write(r + "\n")
            else:
                f.write(json.dumps(r) + "\n")

    samples = load_corpus_from_oai_jsonl(p, model_source="test-corpus")
    # 1 call from row 1, 2 calls from row 2, 0 from the malformed
    assert len(samples) == 3
    # Each sample has model_source pinned to the loader arg
    assert all(s.model_source == "test-corpus" for s in samples)
    # The first sample's context is everything before the assistant
    # message that emitted the call — just the user message.
    s0 = samples[0]
    assert len(s0.conversation) == 1
    assert s0.conversation[0].role == "user"
    assert s0.target_tool == "web_search"
    # And the available tools are carried through
    assert any(t.name == "web_search" for t in s0.tools)


def test_oai_loader_max_rows(tmp_path: Path):
    """max_rows caps how many conversations get read."""
    from nn.data import load_corpus_from_oai_jsonl
    p = tmp_path / "tool_corpus.jsonl"
    with p.open("w") as f:
        for i in range(5):
            f.write(json.dumps({
                "messages": [
                    {"role": "user", "content": f"q{i}"},
                    {"role": "assistant", "content": "", "tool_calls": [
                        {"type": "function",
                         "function": {"name": "t", "arguments": "{}"}}
                    ]},
                ],
                "tools": [],
            }) + "\n")
    # Cap at 2 rows → 2 samples
    samples = load_corpus_from_oai_jsonl(p, max_rows=2)
    assert len(samples) == 2


def test_session_loader_v2_emits_conversation_samples(tmp_path: Path):
    """The v2 Cognos-session loader produces ConversationSamples in
    the same standard shape as the OAI loader."""
    from nn.data import load_corpus_from_sessions
    sd = tmp_path / "sessions"
    sd.mkdir()
    # One session, one tool call
    (sd / "001.json").write_text(json.dumps({
        "messages": [
            {"role": "user", "content": "read file foo.txt"},
            {"role": "assistant", "content": "", "tool_calls": [
                {"id": "call_1", "type": "function",
                 "function": {"name": "read_file",
                              "arguments": '{"path": "foo.txt"}'}}
            ]},
            {"role": "tool", "tool_call_id": "call_1", "name": "read_file",
             "content": "file contents"},
            {"role": "assistant", "content": "done"},
        ],
        "metadata": {
            "reflection_scores": {"call_1": 0.9},
            "last_tier": 1,
            "thinking_used": 1.0,
            "model_source": "ollama/glm-5.1:cloud",
        },
    }))
    samples = load_corpus_from_sessions(sd)
    assert len(samples) == 1
    s = samples[0]
    assert s.target_tool == "read_file"
    assert s.target_value == 0.9
    assert s.target_tier == 1
    assert s.target_think == 1.0
    assert s.model_source == "ollama/glm-5.1:cloud"
    # The prefix is everything before the assistant tool-call turn
    assert s.conversation[0].role == "user"


def test_conversation_sample_from_conversation_takes_correct_prefix():
    """ConversationSample.from_conversation must slice the prefix at
    the message BEFORE the assistant-with-tool-call. Off-by-one here
    means the model sees its own future tool call as input."""
    from nn.data import ConversationSample
    from nn.format import Conversation
    conv = Conversation.from_dict({
        "messages": [
            {"role": "system", "content": "system msg"},
            {"role": "user", "content": "user msg"},
            {"role": "assistant", "content": "", "tool_calls": [
                {"type": "function",
                 "function": {"name": "t", "arguments": "{}"}}
            ]},
        ],
        "tools": [],
    })
    target = conv.messages[2].tool_calls[0]
    s = ConversationSample.from_conversation(
        conv=conv, prefix_len=2, tool_call=target,
    )
    # Two messages of context (system + user) — NOT the assistant turn
    assert len(s.conversation) == 2
    assert s.conversation[1].role == "user"
    assert s.target_tool == "t"
