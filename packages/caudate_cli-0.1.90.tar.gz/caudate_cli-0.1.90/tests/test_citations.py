"""Tests for `core.citations.parse_citations`."""

from __future__ import annotations

import pytest

from core.citations import CitationBlock, Document, parse_citations


def _doc(id_: str, text: str, title: str = "") -> Document:
    return Document(id=id_, title=title, text=text)


def test_parse_citations_no_markers_returns_text_unchanged():
    docs = [_doc("foo", "alpha\nbeta\ngamma")]
    clean, cites = parse_citations("hello world", docs)
    assert clean == "hello world"
    assert cites == []


def test_parse_citations_whole_document_marker():
    docs = [_doc("foo", "the body", title="My Doc")]
    clean, cites = parse_citations(
        "the answer is 42 [[cite:foo]] (per docs)", docs,
    )
    assert clean == "the answer is 42 [1] (per docs)"
    assert len(cites) == 1
    assert cites[0].doc_id == "foo"
    assert cites[0].doc_title == "My Doc"
    assert cites[0].start_line is None
    assert cites[0].end_line is None
    assert cites[0].quoted_text == ""


def test_parse_citations_single_line():
    docs = [_doc("manual", "L0 ignored\nthe key fact\nL2 trailing")]
    clean, cites = parse_citations("see [[cite:manual:L2]]", docs)
    assert clean == "see [1]"
    assert cites[0].start_line == 2
    assert cites[0].end_line == 2
    assert cites[0].quoted_text == "the key fact"


def test_parse_citations_line_range():
    body = "first\nsecond\nthird\nfourth\nfifth"
    docs = [_doc("d1", body)]
    clean, cites = parse_citations("from [[cite:d1:L2-L4]]", docs)
    assert clean == "from [1]"
    assert cites[0].start_line == 2
    assert cites[0].end_line == 4
    assert cites[0].quoted_text == "second\nthird\nfourth"


def test_parse_citations_dedupes_repeated_marker():
    docs = [_doc("d", "alpha\nbeta\ngamma")]
    clean, cites = parse_citations(
        "first [[cite:d:L2]] then again [[cite:d:L2]] then different [[cite:d:L3]]",
        docs,
    )
    # Two distinct citations → indices [1] and [2], with the repeat
    # of the L2 cite reusing index [1].
    assert clean == "first [1] then again [1] then different [2]"
    assert len(cites) == 2
    assert cites[0].start_line == 2
    assert cites[1].start_line == 3


def test_parse_citations_unknown_doc_id_still_records_block():
    # The marker references a doc the caller didn't provide. We still
    # produce a CitationBlock (with empty title + no quote) rather
    # than dropping it silently — caller can decide how to surface.
    clean, cites = parse_citations("here [[cite:missing:L1]]", documents=[])
    assert clean == "here [1]"
    assert cites[0].doc_id == "missing"
    assert cites[0].quoted_text == ""


def test_parse_citations_multiple_distinct_docs():
    docs = [_doc("a", "a-line"), _doc("b", "b-line")]
    clean, cites = parse_citations(
        "[[cite:a:L1]] vs [[cite:b:L1]]", docs,
    )
    assert clean == "[1] vs [2]"
    assert {c.doc_id for c in cites} == {"a", "b"}
