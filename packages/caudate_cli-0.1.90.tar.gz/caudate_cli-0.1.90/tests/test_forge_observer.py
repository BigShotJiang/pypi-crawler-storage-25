"""Test the Caudate feature-outcome observer hook."""

from __future__ import annotations

import json
from pathlib import Path

import pytest


@pytest.fixture
def isolated_outcome_log(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    log_path = tmp_path / "feature_outcomes.jsonl"
    import nn.observer as obs
    monkeypatch.setattr(obs, "_FEATURE_OUTCOMES_PATH", log_path, raising=False)
    return obs, log_path


def test_observe_writes_jsonl_record(isolated_outcome_log):
    obs, log_path = isolated_outcome_log
    obs.observe_feature_outcome(
        feature_text="add a /healthz endpoint",
        model_used="ollama/glm-5.1:cloud",
        n_turns=4, n_tool_calls=3,
        success=True, duration_s=12.5,
        project_id=1, feature_id=99, session_id=42,
        extras={"origin": "unittest"},
    )
    lines = log_path.read_text().splitlines()
    assert len(lines) == 1
    rec = json.loads(lines[0])
    assert rec["feature_text"] == "add a /healthz endpoint"
    assert rec["model_used"] == "ollama/glm-5.1:cloud"
    assert rec["success"] is True
    assert rec["n_turns"] == 4
    assert rec["duration_s"] == 12.5
    assert rec["extras"]["origin"] == "unittest"


def test_observe_appends_records(isolated_outcome_log):
    obs, log_path = isolated_outcome_log
    for i in range(3):
        obs.observe_feature_outcome(
            feature_text=f"feat-{i}",
            model_used="x",
            n_turns=1, n_tool_calls=1,
            success=(i % 2 == 0), duration_s=0.0,
        )
    lines = log_path.read_text().splitlines()
    assert len(lines) == 3
    assert json.loads(lines[1])["feature_text"] == "feat-1"


def test_observe_swallows_io_errors(isolated_outcome_log, monkeypatch):
    obs, log_path = isolated_outcome_log
    # Make the directory un-writable by pointing at a child of a regular file
    bad = log_path.parent / "blocker"
    bad.write_text("not a dir")
    monkeypatch.setattr(obs, "_FEATURE_OUTCOMES_PATH",
                        bad / "child.jsonl", raising=False)
    # Should NOT raise
    obs.observe_feature_outcome(
        feature_text="x", model_used="x",
        n_turns=0, n_tool_calls=0, success=False, duration_s=0.0,
    )
