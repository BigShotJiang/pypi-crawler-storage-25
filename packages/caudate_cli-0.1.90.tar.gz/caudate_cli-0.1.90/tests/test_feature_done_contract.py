"""Tests for ADR 0001: Feature 'done' requires verify pass AND
agent attestation.

The orchestrator must reject a feature as done when the agent
emits a give-up phrase, even if the verify_command passes.
"""

from __future__ import annotations

import pytest

from planning.orchestrator import _detect_give_up


@pytest.mark.parametrize("phrase", [
    "I couldn't create the file because permissions were denied.",
    "I gave up after the third attempt.",
    "Once permissions are restored, I can try again.",
    "All file-writing tools are being denied by a permissions policy.",
    "Max iterations reached",
    "I was unable to complete the task.",
    "I can't write to the filesystem in this session.",
])
def test_detect_give_up_catches_failure_phrases(phrase):
    assert _detect_give_up(phrase) is not None


@pytest.mark.parametrize("phrase", [
    "Created app/main.py with a /api/health endpoint that returns 200.",
    "All acceptance criteria verified. Server starts, health endpoint works.",
    "Feature implemented: see app/main.py and requirements.txt.",
    "Done. Wrote 5 files and ran the verify_command (exit 0).",
])
def test_detect_give_up_does_not_fire_on_clean_completion(phrase):
    assert _detect_give_up(phrase) is None


def test_detect_give_up_handles_empty():
    """Empty agent response is itself a give-up signal."""
    assert _detect_give_up("") == "(empty agent response)"
    assert _detect_give_up(None) == "(empty agent response)"


def test_detect_give_up_is_case_insensitive():
    """Match works regardless of casing."""
    assert _detect_give_up("MAX ITERATIONS REACHED") is not None
    assert _detect_give_up("I Couldn't.") is not None


def test_detect_give_up_substring_inside_normal_text():
    """A give-up phrase buried in normal narration still trips —
    intentional. Agent finishing cleanly should never write this."""
    msg = ("I implemented the search endpoint with rate limiting. "
           "Note: in the future, if you i can't predict the volume…")
    # Even though the phrase is mentioned in passing, it's still a
    # signal we should investigate — better to be strict than miss
    # a real give-up.
    assert _detect_give_up(msg) is not None
