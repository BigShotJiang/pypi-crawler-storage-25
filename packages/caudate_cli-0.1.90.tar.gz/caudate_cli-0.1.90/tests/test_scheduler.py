"""Tests for `core.scheduler._parse_schedule`."""

from __future__ import annotations

from datetime import datetime, timedelta

import pytest

from core.scheduler import _parse_schedule


# Fixed reference point: Wednesday 2026-04-29 at 10:00:00
NOW = datetime(2026, 4, 29, 10, 0, 0)


# ---- "every <n><unit>" -------------------------------------------------


def test_every_seconds():
    nxt = _parse_schedule("every 30s", NOW)
    assert nxt == NOW + timedelta(seconds=30)


def test_every_minutes_long_form():
    assert _parse_schedule("every 5min", NOW) == NOW + timedelta(minutes=5)


def test_every_minutes_short_form():
    assert _parse_schedule("every 5m", NOW) == NOW + timedelta(minutes=5)


def test_every_hours():
    assert _parse_schedule("every 2h", NOW) == NOW + timedelta(hours=2)


def test_every_days():
    assert _parse_schedule("every 1d", NOW) == NOW + timedelta(days=1)
    assert _parse_schedule("every 7day", NOW) == NOW + timedelta(days=7)
    assert _parse_schedule("every 7days", NOW) == NOW + timedelta(days=7)


# ---- "daily HH:MM" -----------------------------------------------------


def test_daily_in_future_today():
    # NOW = 10:00. Daily 14:30 today → 14:30 same day.
    nxt = _parse_schedule("daily 14:30", NOW)
    assert nxt == datetime(2026, 4, 29, 14, 30, 0)


def test_daily_already_passed_rolls_to_tomorrow():
    # NOW = 10:00. Daily 09:00 → already past, so tomorrow at 09:00.
    nxt = _parse_schedule("daily 09:00", NOW)
    assert nxt == datetime(2026, 4, 30, 9, 0, 0)


# ---- "weekly <dow> HH:MM" ---------------------------------------------


def test_weekly_future_day_this_week():
    # NOW is Wednesday. Friday 09:00 → Friday 2026-05-01.
    nxt = _parse_schedule("weekly fri 09:00", NOW)
    assert nxt == datetime(2026, 5, 1, 9, 0, 0)


def test_weekly_past_day_rolls_one_week():
    # NOW is Wednesday 10:00. Monday 09:00 → next Monday (2026-05-04).
    nxt = _parse_schedule("weekly mon 09:00", NOW)
    assert nxt == datetime(2026, 5, 4, 9, 0, 0)


def test_weekly_today_but_past_rolls_one_week():
    # NOW is Wed 10:00. Wed 09:00 has already passed today → next Wed.
    nxt = _parse_schedule("weekly wed 09:00", NOW)
    assert nxt == datetime(2026, 5, 6, 9, 0, 0)


# ---- "at YYYY-MM-DD HH:MM" --------------------------------------------


def test_at_one_shot_specific_datetime():
    nxt = _parse_schedule("at 2026-12-25 09:30", NOW)
    assert nxt == datetime(2026, 12, 25, 9, 30, 0)


def test_at_invalid_date_returns_none():
    assert _parse_schedule("at 2026-13-01 09:00", NOW) is None


# ---- unrecognised ------------------------------------------------------


def test_unrecognised_returns_none():
    assert _parse_schedule("eventually maybe", NOW) is None
    assert _parse_schedule("", NOW) is None


def test_case_insensitive():
    assert _parse_schedule("EVERY 5 MIN", NOW) == NOW + timedelta(minutes=5)
    assert _parse_schedule("Daily 14:30", NOW) == datetime(2026, 4, 29, 14, 30)
