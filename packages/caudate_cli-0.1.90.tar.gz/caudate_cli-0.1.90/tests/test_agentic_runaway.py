"""Tests for the runaway-tool-call detector in
`api/openai_compat._run_agentic_loop`.

Strategy: build a fake LLMProvider that always returns the same tool
call, and a fake Executor whose `execute_tool` always errors. Drive
the loop and assert:

  - The same tool gets retried at the start (correct baseline)
  - After 3 failed identical calls, a synthetic "[system nudge]"
    user message is injected into the history that the LLM sees on
    the next iteration
  - The nudge is injected exactly once (not on every subsequent
    iteration)

Pure logic test — no real LLM, no quota, deterministic.
"""

from __future__ import annotations

import asyncio
from types import SimpleNamespace
from unittest.mock import MagicMock

from api.openai_compat import _run_agentic_loop
from core.schemas import ToolUseBlock
from llm.provider import LLMResponse


class _AlwaysFailingLLM:
    """Stubbed LLMProvider that records what messages it sees and
    always returns the same tool call. Stops if a `done!` token
    appears in the most recent user message — lets the test cleanly
    end the loop after the nudge has been injected."""

    def __init__(self, tool_name: str = "Bash",
                 tool_input: dict | None = None):
        self.model = "fake-runaway-llm"
        self.tool_name = tool_name
        self.tool_input = tool_input or {"command": "find / -name foo"}
        self.received_message_lists: list[list[dict]] = []
        self.call_count = 0

    async def chat(self, *, messages, **kwargs):
        self.call_count += 1
        # Snapshot what the loop is feeding us — so the test can
        # inspect whether the nudge ever got into the message list.
        self.received_message_lists.append(list(messages))

        # If the most recent user message contains the nudge, stop
        # by returning a "done" final text instead of yet another
        # tool call. This simulates an LLM that *did* notice the
        # nudge and chose to surface to the user.
        for m in reversed(messages):
            if m.get("role") == "user":
                content = m.get("content", "") or ""
                if isinstance(content, list):
                    content = " ".join(
                        b.get("text", "") for b in content if isinstance(b, dict)
                    )
                if "[system nudge]" in content:
                    return LLMResponse(
                        content="OK, I'll stop and ask the user.",
                        model=self.model,
                        tool_calls=[],
                        stop_reason="stop",
                    )
                break

        # Otherwise, keep returning the same failing tool call
        return LLMResponse(
            content="",
            model=self.model,
            tool_calls=[ToolUseBlock(
                id=f"call_{self.call_count}",
                name=self.tool_name,
                input=dict(self.tool_input),
            )],
            stop_reason="tool_use",
        )


class _AlwaysErrorExecutor:
    """Executor whose every tool call returns an error result."""

    def __init__(self):
        self.exec_log: list[tuple[str, dict]] = []

    def tool_definitions(self):
        return [{
            "type": "function",
            "function": {
                "name": "Bash",
                "description": "shell commands",
                "parameters": {
                    "type": "object",
                    "properties": {"command": {"type": "string"}},
                    "required": ["command"],
                },
            },
        }]

    async def execute_tool(self, name: str, args: dict):
        self.exec_log.append((name, dict(args or {})))
        return SimpleNamespace(
            output="",
            error="permission denied",
            tool_name=name,
            status="error",
        )


def _run(coro):
    return asyncio.run(coro)


def test_runaway_detector_injects_nudge_after_three_failed_calls():
    """Same tool, same args, all errored, 3+ times in a row → nudge fires."""
    llm = _AlwaysFailingLLM()
    executor = _AlwaysErrorExecutor()
    middleware = MagicMock()

    resp = _run(_run_agentic_loop(
        llm=llm,
        executor=executor,
        messages=[{"role": "user", "content": "find me something"}],
        middleware=middleware,
        turn_ctx=None,
        max_tokens=100,
        temperature=None,
    ))

    # Find the FIRST message-list passed to the LLM that contains
    # the synthetic nudge. If it's missing entirely, the detector
    # didn't fire.
    nudged_iteration = None
    for i, msgs in enumerate(llm.received_message_lists):
        for m in msgs:
            content = m.get("content", "") or ""
            if isinstance(content, str) and "[system nudge]" in content:
                nudged_iteration = i
                break
        if nudged_iteration is not None:
            break
    assert nudged_iteration is not None, (
        "runaway detector did not inject the nudge after 3 failed "
        f"identical calls. Received {len(llm.received_message_lists)} "
        f"LLM calls in total. exec_log={executor.exec_log}"
    )

    # The nudge should appear no earlier than the call AFTER the 3rd
    # tool failure (so the LLM sees it on its next chance to choose).
    # Iteration indexing: call 0 = first chat with no tool history.
    assert nudged_iteration >= 3, (
        f"nudge fired too early — at LLM call {nudged_iteration}. "
        "Should fire only after 3 errored same-tool calls."
    )


def test_runaway_nudge_includes_actionable_guidance():
    """The injected nudge isn't just a flag — it tells the LLM what
    options it has (ask the user, try a different approach)."""
    llm = _AlwaysFailingLLM()
    executor = _AlwaysErrorExecutor()
    middleware = MagicMock()

    _run(_run_agentic_loop(
        llm=llm, executor=executor,
        messages=[{"role": "user", "content": "find something"}],
        middleware=middleware, turn_ctx=None,
        max_tokens=100, temperature=None,
    ))

    # Pull the nudge text out of the message list
    nudge_text = ""
    for msgs in llm.received_message_lists:
        for m in msgs:
            c = m.get("content", "") or ""
            if isinstance(c, str) and "[system nudge]" in c:
                nudge_text = c
                break
        if nudge_text:
            break
    assert nudge_text, "no nudge captured"
    # The nudge should name the stuck tool, give 2 options, and forbid
    # another call to the same tool. Two valid branches now (same-args
    # vs all-errored) — accept either's wording for the "options" check.
    assert "Bash" in nudge_text
    assert "ask me" in nudge_text.lower() or "ask the user" in nudge_text.lower()
    assert (
        "different" in nudge_text.lower()
        or "next action" in nudge_text.lower()
        or "write" in nudge_text.lower()
    )
    assert "do not call" in nudge_text.lower() or "don't call" in nudge_text.lower()


def test_runaway_nudge_injected_exactly_once_not_per_iteration():
    """Even if the LLM kept ignoring the nudge and kept failing, we
    only inject the synthetic message once — otherwise the history
    would balloon with duplicates."""

    class _IgnoresNudgeLLM(_AlwaysFailingLLM):
        """Like _AlwaysFailingLLM but never stops, even after seeing
        the nudge — simulates the worst case."""
        async def chat(self, *, messages, **kwargs):
            self.call_count += 1
            self.received_message_lists.append(list(messages))
            return LLMResponse(
                content="",
                model=self.model,
                tool_calls=[ToolUseBlock(
                    id=f"call_{self.call_count}",
                    name=self.tool_name,
                    input=dict(self.tool_input),
                )],
                stop_reason="tool_use",
            )

    llm = _IgnoresNudgeLLM()
    executor = _AlwaysErrorExecutor()
    middleware = MagicMock()

    _run(_run_agentic_loop(
        llm=llm, executor=executor,
        messages=[{"role": "user", "content": "find"}],
        middleware=middleware, turn_ctx=None,
        max_tokens=100, temperature=None,
    ))

    # Count distinct nudge messages across all snapshots — should
    # always be exactly 1, no matter how many iterations we ran.
    final_msgs = llm.received_message_lists[-1] if llm.received_message_lists else []
    nudge_count = sum(
        1 for m in final_msgs
        if isinstance(m.get("content", ""), str)
           and "[system nudge]" in m.get("content", "")
    )
    assert nudge_count == 1, (
        f"expected exactly 1 nudge in final history, got {nudge_count}. "
        f"Total LLM calls: {llm.call_count}."
    )


def test_runaway_detector_does_not_fire_on_three_different_tools():
    """Calling 3 different tools (all failing) shouldn't trigger the
    nudge — the detector specifically targets *same-tool* loops."""

    class _RotatingLLM(_AlwaysFailingLLM):
        """Cycles through 3 different tool names, each call errored."""
        TOOLS = ["Bash", "Read", "Grep"]
        async def chat(self, *, messages, **kwargs):
            self.call_count += 1
            self.received_message_lists.append(list(messages))
            # Stop after 6 iterations so the test doesn't hit the
            # max-iter cap — emit a final text response.
            if self.call_count > 6:
                return LLMResponse(content="done", model=self.model,
                                   tool_calls=[], stop_reason="stop")
            return LLMResponse(
                content="", model=self.model,
                tool_calls=[ToolUseBlock(
                    id=f"call_{self.call_count}",
                    name=self.TOOLS[(self.call_count - 1) % 3],
                    input={"x": self.call_count},
                )],
                stop_reason="tool_use",
            )

    class _MultiToolExecutor(_AlwaysErrorExecutor):
        def tool_definitions(self):
            return [
                {"type": "function", "function": {"name": n,
                                                   "description": "",
                                                   "parameters": {"type": "object"}}}
                for n in ("Bash", "Read", "Grep")
            ]

    llm = _RotatingLLM()
    executor = _MultiToolExecutor()
    _run(_run_agentic_loop(
        llm=llm, executor=executor,
        messages=[{"role": "user", "content": "x"}],
        middleware=MagicMock(), turn_ctx=None,
        max_tokens=100, temperature=None,
    ))

    # No nudge should appear — different tools, even though all fail
    found_nudge = any(
        isinstance(m.get("content", ""), str)
        and "[system nudge]" in m.get("content", "")
        for snap in llm.received_message_lists
        for m in snap
    )
    assert not found_nudge, (
        "false positive: detector fired despite tools rotating"
    )


def test_runaway_detector_fires_on_same_args_even_when_successful():
    """If the same (tool, args) pair is called 3+ times in a row, the
    detector fires — even when every call succeeds. This catches the
    read-loop pattern where the LLM keeps reading the same file (each
    Read succeeds) while saying it'll write, but never calls Write.

    Distinct from the all-errored detector: this one cares about
    *progress*, not error state. Same args twice means no new info,
    same args three times means stuck."""

    class _SuccessExecutor:
        def tool_definitions(self):
            return [{"type": "function",
                     "function": {"name": "Read", "description": "",
                                  "parameters": {"type": "object"}}}]

        async def execute_tool(self, name, args):
            # Plain success result — no `error` attribute set
            return SimpleNamespace(output="file contents...", error=None,
                                   tool_name=name, status="success")

    class _StuckReadingLLM(_AlwaysFailingLLM):
        """Like the haiku-4-5 read-loop: keeps Read'ing the same path,
        keeps saying it'll write, never actually calls Write."""
        async def chat(self, *, messages, **kwargs):
            self.call_count += 1
            self.received_message_lists.append(list(messages))
            for m in reversed(messages):
                if m.get("role") == "user":
                    c = m.get("content", "") or ""
                    if isinstance(c, str) and "[system nudge]" in c:
                        return LLMResponse(
                            content="OK, I'll write it now.",
                            model=self.model, tool_calls=[],
                            stop_reason="stop",
                        )
                    break
            return LLMResponse(
                content="Let me read the file first.",
                model=self.model,
                tool_calls=[ToolUseBlock(
                    id=f"call_{self.call_count}",
                    name="Read", input={"path": "/tmp/foo.py"},
                )],
                stop_reason="tool_use",
            )

    llm = _StuckReadingLLM()
    executor = _SuccessExecutor()
    _run(_run_agentic_loop(
        llm=llm, executor=executor,
        messages=[{"role": "user", "content": "update the file"}],
        middleware=MagicMock(), turn_ctx=None,
        max_tokens=100, temperature=None,
    ))

    found_nudge = any(
        isinstance(m.get("content", ""), str)
        and "[system nudge]" in m.get("content", "")
        for snap in llm.received_message_lists
        for m in snap
    )
    assert found_nudge, (
        "detector failed to fire on same (tool, args) repeated 3+ times. "
        f"Total LLM calls: {llm.call_count}"
    )


def test_runaway_detector_does_not_fire_on_same_tool_different_args():
    """Same tool with *different* args 3+ times is normal multi-step
    work (e.g. reading three different files). Detector must not fire."""

    class _SuccessExecutor:
        def tool_definitions(self):
            return [{"type": "function",
                     "function": {"name": "Read", "description": "",
                                  "parameters": {"type": "object"}}}]

        async def execute_tool(self, name, args):
            return SimpleNamespace(output="ok", error=None,
                                   tool_name=name, status="success")

    class _RotatingPathLLM(_AlwaysFailingLLM):
        """Reads a different file each iteration, then stops."""
        async def chat(self, *, messages, **kwargs):
            self.call_count += 1
            self.received_message_lists.append(list(messages))
            if self.call_count > 4:
                return LLMResponse(content="all done", model=self.model,
                                   tool_calls=[], stop_reason="stop")
            return LLMResponse(
                content="", model=self.model,
                tool_calls=[ToolUseBlock(
                    id=f"call_{self.call_count}",
                    name="Read",
                    input={"path": f"/tmp/file_{self.call_count}.py"},
                )],
                stop_reason="tool_use",
            )

    llm = _RotatingPathLLM()
    executor = _SuccessExecutor()
    _run(_run_agentic_loop(
        llm=llm, executor=executor,
        messages=[{"role": "user", "content": "x"}],
        middleware=MagicMock(), turn_ctx=None,
        max_tokens=100, temperature=None,
    ))

    found_nudge = any(
        isinstance(m.get("content", ""), str)
        and "[system nudge]" in m.get("content", "")
        for snap in llm.received_message_lists
        for m in snap
    )
    assert not found_nudge, (
        "false positive: detector fired on same tool with different args"
    )
