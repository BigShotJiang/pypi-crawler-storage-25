"""Tests for `core.settings` — load + merge across user / project layers.

Uses monkeypatch to redirect `_user_settings_path` and
`_project_settings_path` to tmp_path so the real `~/.cognos/` and
`./.cognos/` files on disk are never read or written.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from core import settings as st


@pytest.fixture
def isolated_paths(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    """Redirect both settings layers to per-test temp files."""
    user_path = tmp_path / "user" / "settings.json"
    proj_path = tmp_path / "project" / "settings.json"
    user_path.parent.mkdir(parents=True, exist_ok=True)
    proj_path.parent.mkdir(parents=True, exist_ok=True)

    monkeypatch.setattr(st, "_user_settings_path", lambda: user_path)
    monkeypatch.setattr(st, "_project_settings_path", lambda: proj_path)
    return user_path, proj_path


def test_load_with_no_files_returns_defaults(isolated_paths):
    s = st.Settings.load()
    # Every default key is present
    for key in st.DEFAULTS:
        assert key in s
    # No source files contributed
    assert s.sources() == []


def test_load_user_settings_overrides_default(isolated_paths):
    user_path, _ = isolated_paths
    user_path.write_text(json.dumps({"model": "user-pick"}))

    s = st.Settings.load()
    assert s.get("model") == "user-pick"
    assert user_path in s.sources()


def test_load_project_settings_overrides_user(isolated_paths):
    user_path, proj_path = isolated_paths
    user_path.write_text(json.dumps({"model": "user-pick", "stream": False}))
    proj_path.write_text(json.dumps({"model": "project-pick"}))

    s = st.Settings.load()
    # Project layer wins for model
    assert s.get("model") == "project-pick"
    # User layer's stream-override survives because project didn't
    # touch it
    assert s.get("stream") is False
    assert s.sources() == [user_path, proj_path]


def test_deep_merge_recurses_into_nested_dicts():
    """Deep-merge must combine nested dicts rather than replacing them
    wholesale — important for `permissions.allow/deny` and similar."""
    base = {
        "permissions": {"allow": ["a"], "deny": ["d1"]},
        "other": 1,
    }
    over = {
        "permissions": {"allow": ["b"]},  # no `deny` key — should keep base's
    }
    out = st._deep_merge(base, over)
    assert out["permissions"]["allow"] == ["b"]   # override wins for the key it set
    assert out["permissions"]["deny"] == ["d1"]   # untouched key preserved
    assert out["other"] == 1


def test_deep_merge_replaces_non_dict_value():
    """If the override is a non-dict and the base is a dict, the
    override replaces wholesale (no deep merge possible)."""
    out = st._deep_merge({"x": {"a": 1}}, {"x": "scalar"})
    assert out["x"] == "scalar"


def test_load_invalid_json_falls_back_to_defaults(isolated_paths):
    """A malformed settings file must not crash the whole load — the
    layer is skipped, defaults still apply."""
    user_path, _ = isolated_paths
    user_path.write_text("not json {{{")
    s = st.Settings.load()
    # Defaults survive
    assert s.get("permission_mode") == st.DEFAULTS["permission_mode"]
    # User file existed (so it was attempted) — it should still be
    # listed as a source even though parsing failed silently
    assert user_path in s.sources()


def test_settings_dict_view():
    """`as_dict()` returns a copy, mutation doesn't affect the merged data."""
    s = st.Settings({"a": 1}, sources=[])
    d = s.as_dict()
    d["a"] = 999
    assert s.get("a") == 1


def test_settings_contains_and_getitem():
    s = st.Settings({"a": 1, "b": 2}, sources=[])
    assert "a" in s
    assert "missing" not in s
    assert s["a"] == 1


def test_write_user_setting_persists(isolated_paths):
    user_path, _ = isolated_paths
    st.write_user_setting("custom", {"nested": True})
    written = json.loads(user_path.read_text())
    assert written["custom"] == {"nested": True}


def test_write_user_setting_preserves_existing_keys(isolated_paths):
    user_path, _ = isolated_paths
    user_path.write_text(json.dumps({"existing": "keep me"}))
    st.write_user_setting("new", "added")
    written = json.loads(user_path.read_text())
    assert written["existing"] == "keep me"
    assert written["new"] == "added"
