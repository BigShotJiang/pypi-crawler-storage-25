"""Tests for core/skills.py lockfile (lock/verify drift detection)."""

from __future__ import annotations

import json
from pathlib import Path

import pytest


def _seed_skill(root: Path, name: str, body: str) -> Path:
    d = root / name
    d.mkdir(parents=True)
    md = d / "SKILL.md"
    md.write_text(
        f'---\nname: {name}\ndescription: test skill {name}\n---\n\n{body}\n'
    )
    return md


@pytest.fixture
def fake_skills(tmp_path: Path):
    """Reload core.skills with DEFAULT_SKILL_DIRS pointing at tmp."""
    skills_dir = tmp_path / "skills"
    skills_dir.mkdir()
    _seed_skill(skills_dir, "alpha", "alpha body")
    _seed_skill(skills_dir, "beta", "beta body")

    import core.skills as cs
    # Patch the default scan dirs and force a fresh registry.
    cs.DEFAULT_SKILL_DIRS = (skills_dir,)
    cs._registry = None
    return cs, skills_dir, tmp_path


def test_lock_then_verify_clean(fake_skills, tmp_path: Path):
    cs, skills_dir, _ = fake_skills
    lock_path = tmp_path / "skills.lock.json"
    payload = cs.lock_skills(lock_path=lock_path, dirs=(skills_dir,))
    assert payload["count"] == 2
    assert lock_path.exists()
    rep = cs.verify_skills(lock_path, dirs=(skills_dir,))
    assert rep["ok"] is True
    assert rep["unchanged"] == 2


def test_verify_detects_changed_skill(fake_skills, tmp_path: Path):
    cs, skills_dir, _ = fake_skills
    lock_path = tmp_path / "skills.lock.json"
    cs.lock_skills(lock_path=lock_path, dirs=(skills_dir,))

    # Mutate alpha
    alpha_md = skills_dir / "alpha" / "SKILL.md"
    alpha_md.write_text(alpha_md.read_text() + "\nadded line\n")
    cs._registry = None

    rep = cs.verify_skills(lock_path, dirs=(skills_dir,))
    assert rep["ok"] is False
    assert rep["changed"] == ["alpha"]
    assert rep["missing"] == []
    assert rep["added"] == []


def test_verify_detects_added_skill(fake_skills, tmp_path: Path):
    cs, skills_dir, _ = fake_skills
    lock_path = tmp_path / "skills.lock.json"
    cs.lock_skills(lock_path=lock_path, dirs=(skills_dir,))

    _seed_skill(skills_dir, "gamma", "fresh body")
    cs._registry = None

    rep = cs.verify_skills(lock_path, dirs=(skills_dir,))
    assert rep["ok"] is False
    assert "gamma" in rep["added"]


def test_verify_detects_removed_skill(fake_skills, tmp_path: Path):
    cs, skills_dir, _ = fake_skills
    lock_path = tmp_path / "skills.lock.json"
    cs.lock_skills(lock_path=lock_path, dirs=(skills_dir,))

    # Remove beta
    import shutil
    shutil.rmtree(skills_dir / "beta")
    cs._registry = None

    rep = cs.verify_skills(lock_path, dirs=(skills_dir,))
    assert rep["ok"] is False
    assert rep["missing"] == ["beta"]


def test_verify_returns_error_when_lockfile_missing(fake_skills, tmp_path: Path):
    cs, _, _ = fake_skills
    rep = cs.verify_skills(tmp_path / "nope.json")
    assert rep["ok"] is False
    assert "not found" in rep["error"]
