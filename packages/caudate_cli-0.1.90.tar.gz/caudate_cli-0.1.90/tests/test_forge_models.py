"""Tests for planning/forge_models.py — schema, FK cascades, helpers.

Each test runs against a temporary SQLite file injected via
``forge_models._engine`` overrides. Keeps the real ``data/cognos.db``
untouched.
"""

from __future__ import annotations

import os
from pathlib import Path

import pytest


@pytest.fixture
def tmp_forge_db(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    """Point forge_models at a fresh SQLite file for the duration of one test."""
    db = tmp_path / "forge_test.db"
    import planning.forge_models as fm
    monkeypatch.setattr(fm, "SQLITE_PATH", str(db), raising=False)
    # Reset cached engine so the next get_engine() picks up the new path.
    if getattr(fm, "_engine", None) is not None:
        try:
            fm._engine.dispose()
        except Exception:
            pass
        fm._engine = None
    fm.init()
    yield fm
    # Restore the global engine to None so subsequent tests/imports don't
    # see a closed handle pointing at a deleted tmp file.
    try:
        fm._engine.dispose()
    except Exception:
        pass
    fm._engine = None


def test_create_and_list_project(tmp_forge_db):
    fm = tmp_forge_db
    pid = fm.create_project("alpha", "first project", "/tmp/forge-alpha")
    assert pid > 0
    rows = fm.list_projects()
    assert len(rows) == 1
    assert rows[0]["name"] == "alpha"
    assert rows[0]["folder_path"] == "/tmp/forge-alpha"


def test_feature_creation_and_listing(tmp_forge_db):
    fm = tmp_forge_db
    pid = fm.create_project("p", None, "/tmp/p")
    fid = fm.create_feature(
        project_id=pid, title="t", description="d",
        acceptance_criteria="ok", priority=3,
    )
    assert fid > 0
    feats = fm.list_features(pid)
    assert len(feats) == 1
    assert feats[0]["title"] == "t"
    assert feats[0]["priority"] == 3
    assert feats[0]["status"] == "backlog"


def test_feature_status_constraint(tmp_forge_db):
    fm = tmp_forge_db
    pid = fm.create_project("p", None, "/tmp/p")
    with pytest.raises(ValueError):
        fm.create_feature(project_id=pid, title="t", category="bogus")


def test_dependency_links_features(tmp_forge_db):
    fm = tmp_forge_db
    pid = fm.create_project("p", None, "/tmp/p")
    a = fm.create_feature(project_id=pid, title="A")
    b = fm.create_feature(project_id=pid, title="B")
    fm.add_dependency(b, a)  # B depends on A
    with fm.session_scope() as sess:
        rows = sess.query(fm.ForgeFeatureDep).all()
        assert len(rows) == 1
        assert rows[0].feature_id == b
        assert rows[0].depends_on_feature_id == a


def test_add_dependency_rejects_cycle(tmp_forge_db):
    fm = tmp_forge_db
    pid = fm.create_project("p", None, "/tmp/p")
    a = fm.create_feature(project_id=pid, title="A")
    b = fm.create_feature(project_id=pid, title="B")
    c = fm.create_feature(project_id=pid, title="C")
    fm.add_dependency(b, a)
    fm.add_dependency(c, b)
    with pytest.raises(ValueError, match="cycle"):
        fm.add_dependency(a, c)


def test_set_dependencies_rejects_cycle(tmp_forge_db):
    """Regression: bulk-replace must also reject cycles. Audit caught this."""
    fm = tmp_forge_db
    pid = fm.create_project("p", None, "/tmp/p")
    a = fm.create_feature(project_id=pid, title="A")
    b = fm.create_feature(project_id=pid, title="B")
    c = fm.create_feature(project_id=pid, title="C")
    fm.set_dependencies(b, [a])
    fm.set_dependencies(c, [b])
    with pytest.raises(ValueError, match="cycle"):
        fm.set_dependencies(a, [c])
    # Confirm the graph is still acyclic — failed call must not partially apply
    with fm.session_scope() as sess:
        edges_from_a = sess.query(fm.ForgeFeatureDep).filter_by(feature_id=a).count()
        assert edges_from_a == 0


def test_cascade_delete_removes_features(tmp_forge_db):
    """PRAGMA foreign_keys=ON → deleting a project must cascade to features."""
    fm = tmp_forge_db
    pid = fm.create_project("p", None, "/tmp/p")
    fm.create_feature(project_id=pid, title="A")
    fm.create_feature(project_id=pid, title="B")
    with fm.session_scope() as sess:
        sess.delete(sess.get(fm.ForgeProject, pid))
    assert fm.list_features(pid) == []
