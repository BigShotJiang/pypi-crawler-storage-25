"""Real exercise of the orchestrator's _run_feature path.

The earlier force-stop test stubbed the asyncio task with a
SimpleNamespace. That was enough to verify cancellation bookkeeping
but it never actually invoked CognosAgent — so the signature mismatch
in agent.chat() slipped through to a real Forge run.

This test patches CognosAgent itself with a hermetic stand-in that
records the kwargs it received. If the orchestrator ever calls
agent.chat() with an unsupported kwarg again, this test fails before
the user does.
"""

from __future__ import annotations

import asyncio
import inspect
from pathlib import Path

import pytest


@pytest.fixture
def tmp_forge_db(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    db = tmp_path / "forge_runner_test.db"
    import planning.forge_models as fm
    monkeypatch.setattr(fm, "SQLITE_PATH", str(db), raising=False)
    if getattr(fm, "_engine", None) is not None:
        try:
            fm._engine.dispose()
        except Exception:
            pass
        fm._engine = None
    fm.init()
    yield fm
    try:
        fm._engine.dispose()
    except Exception:
        pass
    fm._engine = None


def test_orchestrator_calls_agent_chat_with_supported_signature(
    tmp_forge_db, monkeypatch,
):
    """The orchestrator must call agent.chat with kwargs that
    CognosAgent.chat actually accepts. This is a static-signature
    check executed via a recording stub — no real LLM is hit."""
    fm = tmp_forge_db
    pid = fm.create_project("runner-test", None, "/tmp/runner-test")
    fid = fm.create_feature(
        project_id=pid, title="dummy",
        description="exercise the runner", priority=0,
    )

    # Snapshot the real CognosAgent.__init__ signature BEFORE the
    # monkeypatch lands. After the patch lands the FakeAgent's
    # signature is just (*args, **kwargs) which is useless for the
    # "orchestrator passed accepted kwargs" check.
    from core.agent import CognosAgent as _RealCA
    real_init_sig = inspect.signature(_RealCA.__init__)
    real_init_allowed = set(real_init_sig.parameters.keys()) - {"self"}

    # Stub CognosAgent. start() is awaitable; chat() records its
    # call kwargs and returns a fixed string. The whole point is to
    # land in _run_feature so any signature mismatch crashes here.
    seen: dict = {"chat_kwargs": None, "chat_args": None}

    class FakeAgent:
        def __init__(self, *args, **kwargs):
            seen["init_kwargs"] = kwargs
        async def start(self): pass
        async def stop(self): pass
        async def chat(self, *args, **kwargs):
            seen["chat_args"] = args
            seen["chat_kwargs"] = kwargs
            return "task complete"

    monkeypatch.setattr("core.agent.CognosAgent", FakeAgent)

    # Now run _run_feature directly.
    import planning.orchestrator as orch
    feature = {
        "id": fid, "project_id": pid, "title": "dummy",
        "description": "exercise the runner",
        "acceptance_criteria": "", "priority": 0,
        "category": "functional", "verify_command": None,
    }

    # Create the session row so _persist_log has somewhere to land.
    with fm.session_scope() as sess:
        srow = fm.ForgeSession(
            project_id=pid, feature_id=fid,
            session_type="coding", status="in_progress",
        )
        sess.add(srow); sess.flush()
        sid = srow.id

    outcome, reason = asyncio.run(orch._run_feature(
        session_id=sid, feature=feature,
        project_dir="/tmp/runner-test",
    ))
    assert outcome == "success", f"expected success, got {outcome}/{reason}"
    assert seen["chat_args"], "agent.chat was never called"
    # Verify the kwargs passed are a subset of what CognosAgent.chat accepts.
    from core.agent import CognosAgent
    sig = inspect.signature(CognosAgent.chat)
    allowed = set(sig.parameters.keys())
    used = set(seen["chat_kwargs"].keys())
    assert used.issubset(allowed), (
        f"orchestrator passed kwargs {used - allowed} that "
        f"CognosAgent.chat does not accept. Allowed: {allowed}"
    )

    # The orchestrator MUST construct CognosAgent with a non-interactive
    # permission mode (ADR 0004). Accept "bypass" or "accept_edits".
    # The kwargs may also include "model" (ADR 0006 Phase B) when
    # Caudate biased the choice — that's fine, just inspect what's
    # there without insisting on the absence of optional fields.
    init_kwargs = seen.get("init_kwargs", {})
    init_pm = init_kwargs.get("permission_mode")
    assert init_pm in ("bypass", "accept_edits"), (
        f"orchestrator built CognosAgent with permission_mode={init_pm!r}; "
        f"that mode prompts the user and will hang inside an autonomous run."
    )
    # Any extra kwargs must be ones the real CognosAgent.__init__
    # accepts. We captured the real signature before the monkeypatch.
    used_init = set(init_kwargs.keys())
    assert used_init.issubset(real_init_allowed), (
        f"orchestrator passed init kwargs {used_init - real_init_allowed} "
        f"that CognosAgent does not accept. Allowed: {real_init_allowed}"
    )
