"""Tests for `core.file_refs.find_refs` and `core.file_refs.expand_inline`."""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from core.file_refs import expand_inline, find_refs


# ---- find_refs ---------------------------------------------------------


def test_find_refs_single_unquoted():
    assert find_refs("look at @README.md please") == ["README.md"]


def test_find_refs_quoted_path_with_spaces():
    assert find_refs('check @"my notes/today.txt" pls') == ["my notes/today.txt"]


def test_find_refs_strips_trailing_punctuation():
    # `@file.py.` should resolve to `file.py` — not `file.py.`
    assert find_refs("see @core/foo.py.") == ["core/foo.py"]
    assert find_refs("@a.md, @b.md.") == ["a.md", "b.md"]


def test_find_refs_preserves_order_and_dedupes():
    text = "look at @a.txt then @b.txt and again @a.txt"
    assert find_refs(text) == ["a.txt", "b.txt"]


def test_find_refs_empty_text():
    assert find_refs("") == []
    assert find_refs("no refs here") == []


def test_find_refs_keeps_intact_paths_inside_quotes():
    # The dot inside the quoted path is part of the path
    assert find_refs('@"weird name.with.dots"') == ["weird name.with.dots"]


# ---- expand_inline -----------------------------------------------------


def test_expand_inline_replaces_with_fenced_block(tmp_path: Path,
                                                   monkeypatch: pytest.MonkeyPatch):
    # Write a file in a temp dir + cd there so the relative @-resolution
    # finds it.
    target = tmp_path / "hello.py"
    target.write_text("print('hi')\n")
    monkeypatch.chdir(tmp_path)

    result = expand_inline("see @hello.py")
    # Should contain a fenced block with the language tag and the file body
    assert "```py hello.py" in result
    assert "print('hi')" in result
    # The original `@hello.py` token is gone (replaced)
    assert "@hello.py" not in result


def test_expand_inline_truncates_at_max_chars(tmp_path: Path,
                                              monkeypatch: pytest.MonkeyPatch):
    target = tmp_path / "big.txt"
    target.write_text("x" * 1000)
    monkeypatch.chdir(tmp_path)

    out = expand_inline("@big.txt", max_chars_per_file=100)
    assert "truncated at 100 chars" in out
    # Body capped to 100 x's, plus the truncation note
    assert out.count("x") <= 100 + 5   # +slack for "100" digits in note


def test_expand_inline_leaves_missing_file_token_alone(tmp_path: Path,
                                                       monkeypatch: pytest.MonkeyPatch):
    monkeypatch.chdir(tmp_path)
    text = "missing @does_not_exist.txt here"
    out = expand_inline(text)
    # No file → original token is left in place
    assert "@does_not_exist.txt" in out


def test_expand_inline_preserves_trailing_punctuation(tmp_path: Path,
                                                      monkeypatch: pytest.MonkeyPatch):
    target = tmp_path / "ok.md"
    target.write_text("hi\n")
    monkeypatch.chdir(tmp_path)

    out = expand_inline("@ok.md.")
    # Trailing dot should still be in the output (after the fence)
    assert "```md ok.md" in out
    assert out.rstrip().endswith(".")


def test_expand_inline_no_refs_returns_text_unchanged():
    assert expand_inline("plain text, no @-refs") == "plain text, no @-refs"
