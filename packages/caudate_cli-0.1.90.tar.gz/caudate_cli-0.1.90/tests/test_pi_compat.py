"""Smoke test for the Pi-Agent compat shim.

Goal: a call sequence identical to LocalForge's
``generate-features`` flow (createPiModelRuntime → createAgentSession
→ session.prompt) should run on Cognos and (a) invoke the custom
tool, (b) emit the right Pi-shaped events, (c) terminate cleanly.

The LLM call is mocked so the test is hermetic and fast.
"""

from __future__ import annotations

import asyncio

import pytest


@pytest.fixture(autouse=True)
def mocked_llm_chat(monkeypatch):
    """Patch ``LLMProvider.chat`` to emit a scripted sequence:
       turn 1: a tool call to our fake tool
       turn 2: a final assistant message and no further tool calls
    """
    from llm import provider as prov

    call_count = {"n": 0}

    class FakeResp:
        def __init__(self, content="", tool_calls=None):
            self.content = content
            self.tool_calls = tool_calls or []

    async def fake_chat(self, messages, tools=None, tool_choice=None,
                        **kwargs):
        call_count["n"] += 1
        if call_count["n"] == 1:
            return FakeResp(
                content="",
                tool_calls=[{
                    "id": "tc_0",
                    "name": "echo",
                    "arguments": {"text": "hello-pi"},
                }],
            )
        return FakeResp(content="all done", tool_calls=[])

    monkeypatch.setattr(prov.LLMProvider, "chat", fake_chat)
    return call_count


def test_pi_compat_session_runs_tool_and_emits_events(mocked_llm_chat):
    """One full turn: tool gets executed, events fire, final text returned."""
    asyncio.run(_run_pi_session(mocked_llm_chat))


async def _run_pi_session(call_count):
    from cognos_pi_compat import (
        AuthStorage, ModelRegistry, DefaultResourceLoader,
        SessionManager, defineTool, createAgentSession,
        createPiModelRuntime, createPiResourceLoader,
    )

    # 1. createPiModelRuntime — convenience port of pi-runtime.ts
    rt = createPiModelRuntime(
        provider="ollama",
        baseUrl="http://127.0.0.1:11434",
        model="glm-5.1:cloud",
    )
    assert isinstance(rt["authStorage"], AuthStorage)
    assert isinstance(rt["modelRegistry"], ModelRegistry)
    assert rt["model"].id == "glm-5.1:cloud"

    # 2. defineTool — Pi-shaped tool definition
    seen_args: dict = {}

    async def echo_execute(tool_call_id, args):
        seen_args["args"] = args
        seen_args["tc_id"] = tool_call_id
        return {
            "content": [{"type": "text", "text": f"echoed: {args.get('text', '')}"}],
            "details": args,
        }

    echo_tool = defineTool(
        name="echo",
        description="echo the input back",
        parameters={
            "type": "object",
            "properties": {"text": {"type": "string"}},
            "required": ["text"],
        },
        execute=echo_execute,
    )

    # 3. createPiResourceLoader + SessionManager
    loader = await createPiResourceLoader(
        cwd="/tmp", systemPrompt="you are a test agent",
    )
    assert loader._loaded
    sm = SessionManager.inMemory("/tmp")
    assert sm.cwd.as_posix() == "/tmp"

    # 4. createAgentSession + subscribe
    events: list[dict] = []

    out = await createAgentSession(
        cwd="/tmp",
        authStorage=rt["authStorage"],
        modelRegistry=rt["modelRegistry"],
        model=rt["model"],
        thinkingLevel="off",
        sessionManager=sm,
        resourceLoader=loader,
        noTools="builtin",
        customTools=[echo_tool],
    )
    session = out["session"]
    unsubscribe = session.subscribe(lambda e: events.append(e))

    # 5. prompt → tool runs → final text returned
    final = await session.prompt("please echo hello-pi")
    assert "all done" in final

    # Tool ran
    assert seen_args.get("args", {}).get("text") == "hello-pi"
    assert seen_args.get("tc_id") == "tc_0"

    # Pi-shaped events emitted
    event_types = [e["type"] for e in events]
    assert "tool_execution_start" in event_types
    assert "message_update" in event_types
    assert event_types.count("turn_end") >= 2

    # tool_execution_start carries toolName + args
    tex = next(e for e in events if e["type"] == "tool_execution_start")
    assert tex["toolName"] == "echo"
    assert tex["args"]["text"] == "hello-pi"

    # text_delta event surfaces the assistant content
    md = next(e for e in events if e["type"] == "message_update")
    assert md["assistantMessageEvent"]["type"] == "text_delta"
    assert "all done" in md["assistantMessageEvent"]["delta"]

    unsubscribe()
    session.dispose()

    # Exactly two LLM round trips: tool call, then final text
    assert call_count["n"] == 2


def test_define_tool_returns_expected_shape():
    from cognos_pi_compat import defineTool

    async def noop(_id, _args):
        return "ok"

    t = defineTool(
        name="t1", description="d", parameters={"type": "object"},
        execute=noop, label="T1", promptSnippet="hint",
    )
    assert t.name == "t1"
    assert t.description == "d"
    assert t.label == "T1"
    assert t.prompt_snippet == "hint"
    assert callable(t.execute)


def test_model_registry_find():
    from cognos_pi_compat import AuthStorage, ModelRegistry
    auth = AuthStorage.inMemory()
    reg = ModelRegistry.inMemory(auth)
    reg.registerProvider("ollama", {
        "baseUrl": "http://x/v1", "apiKey": "k", "api": "openai-completions",
        "models": [{"id": "qwen:14b", "name": "qwen:14b"}],
    })
    m = reg.find("ollama", "qwen:14b")
    assert m is not None
    assert m.id == "qwen:14b"
    assert m.provider == "ollama"
    assert reg.find("ollama", "missing") is None


def test_get_agent_dir_creates_dir(tmp_path, monkeypatch):
    """getAgentDir() returns a Path and ensures it exists."""
    import cognos_pi_compat
    monkeypatch.setenv("HOME", str(tmp_path))
    # Force a fresh resolution by accessing via the module
    p = cognos_pi_compat.getAgentDir()
    assert p.exists()
    assert "pi-compat" in p.as_posix()
