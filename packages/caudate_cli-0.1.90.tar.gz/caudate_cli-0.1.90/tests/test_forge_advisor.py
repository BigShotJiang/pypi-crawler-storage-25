"""Tests for ADR 0006's forge_advisor — heuristic baseline + audit.

The trained Caudate head doesn't exist yet, so every call should
take the baseline path. Verifies:
  - shape of the returned FeaturePrediction
  - per-model success rate read from JSONL
  - keyword bias bumps successful tokens up and failing ones down
  - audit trail lands in data/nn/forge_predictions.jsonl
  - predict_failure_repeats compounds prior failures
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest


@pytest.fixture
def isolated_advisor(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    """Point the advisor at a temporary outcomes/audit dir AND force
    the trained Caudate head off so the baseline path is exercised.
    Phase-A landed a real trained head, so without disabling it these
    tests would silently shift to source='caudate' and stop testing
    the baseline at all."""
    import nn.forge_advisor as fa
    outcomes = tmp_path / "feature_outcomes.jsonl"
    audit = tmp_path / "forge_predictions.jsonl"
    monkeypatch.setattr(fa, "_OUTCOMES_PATH", outcomes, raising=False)
    monkeypatch.setattr(fa, "_AUDIT_PATH", audit, raising=False)
    # Block the trained-head path so we exercise the heuristic baseline
    monkeypatch.setattr(fa, "_get_advisor", lambda: None)
    fa.reset_advisor_cache()
    return fa, outcomes, audit


def _write_outcomes(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as f:
        for r in rows:
            f.write(json.dumps(r) + "\n")


def test_baseline_returns_default_when_no_history(isolated_advisor):
    fa, _, _ = isolated_advisor
    pred = fa.predict_feature_difficulty("add a /healthz endpoint")
    assert 0.0 <= pred.success_prob <= 1.0
    assert pred.source == "fallback"
    assert "no feature-outcome history yet" in pred.reason


def test_baseline_uses_per_model_success_rate(isolated_advisor):
    fa, outcomes, _ = isolated_advisor
    _write_outcomes(outcomes, [
        {"feature_text": f"task {i}", "model_used": "ollama/glm-5.1:cloud",
         "success": True, "n_turns": 4, "n_tool_calls": 4}
        for i in range(8)
    ] + [
        {"feature_text": f"hard {i}", "model_used": "anthropic/claude-haiku-4-5",
         "success": False, "n_turns": 12, "n_tool_calls": 12}
        for i in range(5)
    ])
    p_good = fa.predict_feature_difficulty("new task", "ollama/glm-5.1:cloud")
    p_bad = fa.predict_feature_difficulty("new task", "anthropic/claude-haiku-4-5")
    assert p_good.source == "baseline"
    assert p_bad.source == "baseline"
    assert p_good.success_prob > p_bad.success_prob


def test_keyword_bias_favours_words_seen_in_successes(isolated_advisor):
    fa, outcomes, _ = isolated_advisor
    _write_outcomes(outcomes, [
        {"feature_text": "build static homepage with navigation",
         "model_used": "m", "success": True, "n_turns": 1, "n_tool_calls": 1}
        for _ in range(5)
    ] + [
        {"feature_text": "implement complex distributed consensus protocol",
         "model_used": "m", "success": False, "n_turns": 1, "n_tool_calls": 1}
        for _ in range(5)
    ])
    p_easy = fa.predict_feature_difficulty(
        "build static landing page with navigation", "m",
    )
    p_hard = fa.predict_feature_difficulty(
        "implement distributed consensus", "m",
    )
    assert p_easy.success_prob >= p_hard.success_prob


def test_audit_row_written_for_every_call(isolated_advisor):
    fa, outcomes, audit = isolated_advisor
    _write_outcomes(outcomes, [
        {"feature_text": "x", "model_used": "m", "success": True,
         "n_turns": 1, "n_tool_calls": 1},
    ])
    fa.predict_feature_difficulty("anything", "m")
    fa.predict_feature_difficulty("else", "m")
    lines = audit.read_text().splitlines()
    assert len(lines) == 2
    rec = json.loads(lines[0])
    assert "success_prob" in rec
    assert rec["source"] in {"baseline", "fallback", "caudate"}


def test_failure_repeats_compounds_prior_failures(isolated_advisor):
    fa, outcomes, _ = isolated_advisor
    _write_outcomes(outcomes, [
        {"feature_text": "t", "model_used": "m", "success": True,
         "n_turns": 1, "n_tool_calls": 1},
    ])
    p0 = fa.predict_failure_repeats("anything", n_prior_failures=0)
    p1 = fa.predict_failure_repeats("anything", n_prior_failures=1)
    p2 = fa.predict_failure_repeats("anything", n_prior_failures=2)
    # Monotonic increase: each prior failure makes the next more likely
    assert p0 < p1 < p2
    assert all(0.0 <= p <= 1.0 for p in (p0, p1, p2))


def test_orchestrator_uses_advisor_when_priorities_tie(
    isolated_advisor, monkeypatch, tmp_path,
):
    """ADR 0006 Phase C — find_next_ready_feature should let Caudate
    break ties when multiple features share the lowest priority."""
    fa, outcomes, _ = isolated_advisor
    _write_outcomes(outcomes, [
        # "easy" features succeeded historically
        {"feature_text": "wire static homepage", "model_used": "m",
         "success": True, "n_turns": 1, "n_tool_calls": 1}
        for _ in range(5)
    ] + [
        # "complex" failed historically
        {"feature_text": "wire complex authentication oauth flow",
         "model_used": "m", "success": False, "n_turns": 1, "n_tool_calls": 1}
        for _ in range(5)
    ])

    # Isolated forge DB
    import planning.forge_models as fm
    db = tmp_path / "forge.db"
    monkeypatch.setattr(fm, "SQLITE_PATH", str(db), raising=False)
    if getattr(fm, "_engine", None) is not None:
        fm._engine.dispose()
        fm._engine = None
    fm.init()

    pid = fm.create_project("tiebreak-test", None, "/tmp/tb")
    # Both at priority 0; one easy-keyword, one complex-keyword
    fm.create_feature(
        project_id=pid, title="wire complex authentication oauth flow",
        priority=0,
    )
    fm.create_feature(
        project_id=pid, title="wire static homepage", priority=0,
    )

    from planning import orchestrator as orch
    nxt = orch.find_next_ready_feature(pid)
    assert nxt is not None
    # Caudate-easy-first default should pick the homepage
    assert "homepage" in nxt["title"].lower()
    fm._engine.dispose(); fm._engine = None
