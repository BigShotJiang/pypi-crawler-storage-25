"""Salvage paths for noisy / truncated LLM JSON responses.

Three scenarios:
  1. Cheap salvage — prose framing, trailing commas, smart quotes.
  2. Truncation repair — response cut off mid-string (max_tokens).
  3. Combined — truncated AND has trailing commas.
"""

from __future__ import annotations

import json

import pytest

from llm.provider import _salvage_json, _repair_truncated_json


# ─── Cheap salvage ─────────────────────────────────────────────────────


def test_cheap_strips_prose_framing():
    raw = 'Sure! Here is the JSON:\n\n{"a": 1, "b": [1,2,3]}\n\nLet me know if you want changes.'
    out = _salvage_json(raw)
    assert out is not None
    assert json.loads(out) == {"a": 1, "b": [1, 2, 3]}


def test_cheap_strips_trailing_commas():
    raw = '{"a": 1, "b": [1,2,3,],}'
    out = _salvage_json(raw)
    assert out is not None
    assert json.loads(out) == {"a": 1, "b": [1, 2, 3]}


def test_cheap_replaces_smart_quotes():
    raw = '{“a”: 1}'
    out = _salvage_json(raw)
    assert out is not None
    assert json.loads(out) == {"a": 1}


def test_cheap_returns_none_when_no_braces():
    assert _salvage_json("just a string") is None
    assert _salvage_json("") is None


# ─── Truncation repair ─────────────────────────────────────────────────


def test_repair_truncated_mid_string_in_array():
    """Real-world shape: response cut off inside a string value mid-array.

    The repair walks to the *deepest* clean boundary, which means the
    partial third object keeps any complete fields and only the broken
    one is dropped. With this input we keep {title:f1}, {title:f2}, and
    {title:f3} (the broken verify_command is gone)."""
    raw = (
        '{"reasoning": "ok",\n'
        ' "features": [\n'
        '   {"title": "f1", "priority": 0},\n'
        '   {"title": "f2", "priority": 1},\n'
        '   {"title": "f3", "verify_command": "youtube.com/embed/{video'
    )
    repaired = _repair_truncated_json(raw)
    assert repaired is not None
    parsed = json.loads(repaired)
    assert [f["title"] for f in parsed["features"]] == ["f1", "f2", "f3"]
    # The third object's clean fields survive; the broken verify_command is gone.
    assert "verify_command" not in parsed["features"][2]


def test_repair_drops_object_with_no_clean_fields():
    """If the truncation hits *before* any field finished in the innermost
    object, the whole object is dropped (no clean boundary inside it)."""
    raw = (
        '{"features": [\n'
        '   {"title": "f1"},\n'
        '   {"title": "f2-broken'
    )
    repaired = _repair_truncated_json(raw)
    assert repaired is not None
    parsed = json.loads(repaired)
    assert [f["title"] for f in parsed["features"]] == ["f1"]


def test_repair_truncated_after_key_no_value():
    raw = '{"a": 1, "b":'
    repaired = _repair_truncated_json(raw)
    assert repaired is not None
    parsed = json.loads(repaired)
    # Only the complete `"a": 1` pair survives.
    assert parsed == {"a": 1}


def test_repair_truncated_inside_nested_array():
    """Truncation inside a nested array — clean elements before the
    break survive, the broken array gets closed."""
    raw = (
        '{"features": [\n'
        '  {"title": "first", "deps": []},\n'
        '  {"title": "second", "deps": [1, 2, 3'
    )
    repaired = _repair_truncated_json(raw)
    assert repaired is not None
    parsed = json.loads(repaired)
    # Both features land. second's deps array recovers up to the last
    # confirmed element before truncation. The repair only treats a
    # value as "complete" once a delimiter (comma or closer) follows
    # it — so a trailing `3` with no comma after it is considered
    # potentially partial (could have been `35`, `3.14`, etc) and
    # dropped. That's the conservative-safe choice.
    assert [f["title"] for f in parsed["features"]] == ["first", "second"]
    assert parsed["features"][1]["deps"] == [1, 2]


def test_repair_returns_none_on_garbage():
    assert _repair_truncated_json("") is None
    assert _repair_truncated_json("no braces here") is None


def test_repair_no_op_on_well_formed_json():
    """If the input is already balanced, repair returns None — caller
    falls through to the cheap path or the original parse."""
    raw = '{"a": 1, "b": [1, 2]}'
    assert _repair_truncated_json(raw) is None


# ─── Combined: structured_output integration ──────────────────────────


def test_structured_output_recovers_from_truncated_response(monkeypatch):
    """End-to-end: structured_output should salvage a truncated response
    and return a validated Pydantic instance."""
    import asyncio
    from pydantic import BaseModel
    from llm.provider import LLMProvider

    class Item(BaseModel):
        title: str
        priority: int = 0

    class Backlog(BaseModel):
        reasoning: str
        features: list[Item]

    truncated = (
        '{"reasoning": "test plan",\n'
        ' "features": [\n'
        '   {"title": "alpha", "priority": 0},\n'
        '   {"title": "beta", "priority": 1},\n'
        '   {"title": "gamma", "verify_command": "youtube.com/embed/{video'
    )

    class FakeResp:
        def __init__(self, content):
            self.content = content

    async def fake_complete(self, prompt, system=None, max_tokens=None, **_):
        return FakeResp(truncated)

    monkeypatch.setattr(LLMProvider, "complete", fake_complete)

    llm = LLMProvider(model="ollama/test")
    result = asyncio.run(
        llm.structured_output(
            prompt="bootstrap",
            response_model=Backlog,
        )
    )
    assert isinstance(result, Backlog)
    # alpha + beta are complete; gamma's title is clean before the
    # broken verify_command, so gamma survives too (without the broken field).
    titles = {f.title for f in result.features}
    assert {"alpha", "beta"} <= titles
    assert "gamma" in titles or len(result.features) == 2
