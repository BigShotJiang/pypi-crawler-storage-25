"""Speech-to-text backends.

Pluggable transcription. Two backends ship out of the box:

  - **MoonshineSTT** (default) — Useful Sensors' Moonshine via ONNX
    Runtime. Designed explicitly as a Whisper alternative for edge
    devices: ~27M params, very low first-word latency, no GPU
    required. `pip install useful-moonshine-onnx`.

  - **WhisperSTT** (fallback / kept for compat) — faster-whisper.
    Heavier, more accurate, supports many languages. `pip install
    faster-whisper`.

Both expose the same interface: `.transcribe(wav_bytes) -> str`. The
listener is unaware of which is in use.

Pick a backend with `make_stt(name)`. Unknown names raise so a typo
fails loudly instead of silently picking the wrong engine.
"""

from __future__ import annotations

import io
import logging
import wave
from typing import Protocol

logger = logging.getLogger(__name__)


class STT(Protocol):
    """Speech-to-text protocol. Implementations are stateful and lazy."""

    def transcribe(self, wav_bytes: bytes) -> str:
        ...


class MoonshineSTT:
    """Moonshine via ONNX. Loads on first transcribe() call."""

    def __init__(self, model: str = "moonshine/base"):
        self._model_name = model
        self._model = None

    def _ensure_loaded(self) -> None:
        if self._model is not None:
            return
        try:
            import moonshine_onnx as moonshine
        except ImportError:
            try:
                import moonshine_onnx as moonshine  # alt package name
            except ImportError as e:
                raise RuntimeError(
                    "Moonshine STT requested but `useful-moonshine-onnx` "
                    "is not installed. Run: pip install useful-moonshine-onnx"
                ) from e
        logger.info(f"Loading Moonshine '{self._model_name}'...")
        self._model = moonshine
        logger.info("Moonshine loaded.")

    def transcribe(self, wav_bytes: bytes) -> str:
        self._ensure_loaded()
        # Moonshine's API takes a numpy float32 array at 16k.
        import numpy as np
        with wave.open(io.BytesIO(wav_bytes), "rb") as wf:
            rate = wf.getframerate()
            n = wf.getnframes()
            raw = wf.readframes(n)
        audio = np.frombuffer(raw, dtype=np.int16).astype("float32") / 32768.0
        if rate != 16000:
            # Cheap linear resample; Moonshine expects 16k.
            ratio = 16000 / rate
            new_len = int(len(audio) * ratio)
            audio = np.interp(
                np.linspace(0, len(audio), new_len, endpoint=False),
                np.arange(len(audio)),
                audio,
            ).astype("float32")
        result = self._model.transcribe(audio, self._model_name)
        # API returns either a list[str] (per-segment) or a single str.
        if isinstance(result, (list, tuple)):
            return " ".join(s for s in result if s).strip()
        return str(result).strip()


class WhisperSTT:
    """faster-whisper. Heavier but more accurate, kept as fallback."""

    def __init__(self, model: str = "base", device: str = "cuda"):
        self._model_name = model
        self._device = device
        self._model = None

    def _ensure_loaded(self) -> None:
        if self._model is not None:
            return
        try:
            from faster_whisper import WhisperModel
        except ImportError as e:
            raise RuntimeError(
                "Whisper STT requested but `faster-whisper` is not "
                "installed. Run: pip install faster-whisper"
            ) from e
        logger.info(f"Loading Whisper '{self._model_name}' on {self._device}...")
        self._model = WhisperModel(
            self._model_name,
            device=self._device,
            compute_type="float16" if self._device == "cuda" else "int8",
        )
        logger.info("Whisper loaded.")

    def transcribe(self, wav_bytes: bytes) -> str:
        self._ensure_loaded()
        segments, _ = self._model.transcribe(io.BytesIO(wav_bytes), language="en")
        return " ".join(seg.text for seg in segments).strip()


def make_stt(name: str = "moonshine", **kwargs) -> STT:
    """Factory for STT backends. Names: 'moonshine', 'whisper'."""
    n = name.lower()
    if n == "moonshine":
        return MoonshineSTT(**kwargs)
    if n == "whisper":
        return WhisperSTT(**kwargs)
    raise ValueError(f"Unknown STT backend: {name!r} (try 'moonshine' or 'whisper')")
