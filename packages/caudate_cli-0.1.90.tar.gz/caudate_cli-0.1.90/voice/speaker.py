"""Speaker — plays synthesized audio through the system output.

Thin wrapper around a TTS backend (`voice.tts.TTS`). The backend turns
text into PCM samples; this class plays them via `sounddevice`.

Defaults to Kokoro for natural human-sounding speech. Pass `tts="piper"`
for the lightweight legacy backend, or `tts=<your TTS instance>` to plug
something custom.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import sounddevice as sd

from voice.tts import TTS, make_tts

logger = logging.getLogger(__name__)


class Speaker:
    """Speaks text aloud using a pluggable TTS backend."""

    def __init__(
        self,
        tts: TTS | str = "kokoro",
        voice_path: str | Path | None = None,
        voice: str | None = None,
        **tts_kwargs: Any,
    ):
        # Backwards-compat: if voice_path is set we assume Piper since
        # Piper is the only backend that takes a file path.
        if isinstance(tts, str):
            backend = tts
            kwargs: dict[str, Any] = dict(tts_kwargs)
            if backend == "piper" and voice_path is not None:
                kwargs["voice_path"] = voice_path
            elif backend == "kokoro" and voice:
                kwargs["voice"] = voice
            self._tts = make_tts(backend, **kwargs)
        else:
            self._tts = tts

    def speak(self, text: str) -> None:
        """Synthesize and play text. No-op for empty text."""
        if not text:
            return
        try:
            audio, sample_rate = self._tts.synthesize(text)
        except Exception as e:
            logger.warning(f"TTS synthesis failed: {e}")
            return
        if audio.size == 0:
            return
        sd.play(audio, samplerate=sample_rate)
        sd.wait()
