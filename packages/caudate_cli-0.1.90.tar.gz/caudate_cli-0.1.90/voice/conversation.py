"""Voice conversation — full listen-think-speak loop wired into CognosAgent.

This is the post-Phase-2 rewrite. The old loop bypassed the agent and
talked to `LLMProvider` directly, which meant no personality, no memory,
no tools, no permissions. Now it goes through `CognosAgent.chat()` so
voice mode is just the same agentic loop with a different I/O surface.

Voice-mode wisdom is injected via a system-prompt addendum rather than
forking the personality engine: the agent stays itself, it just speaks
shorter and avoids markdown.

Interruption is handled with a Ctrl+C inside `speaker.speak()` — the
playback aborts, the user starts talking, and we resume listening. No
duplex audio (that's Moshi territory) but enough to feel responsive.
"""

from __future__ import annotations

import logging

import sounddevice as sd

from core.agent import CognosAgent
from voice.listener import Listener
from voice.speaker import Speaker
from voice.stt import STT, make_stt

logger = logging.getLogger(__name__)


VOICE_INSTRUCTIONS = """You are speaking, not writing. Apply these rules:

- Reply in 1-3 short sentences. Conversational, not lecturing.
- No markdown, bullet points, headings, code blocks, or URLs.
- If the user asks for code or a list, summarize it in prose and offer to send the full version to text mode.
- Spell out symbols when they matter ('greater than' not '>').
- Never say "as an AI" or "I am an AI". You are Cognos.
- If you didn't catch what was said, ask once for it to be repeated."""


_EXIT_PHRASES = {
    "goodbye", "good bye", "bye", "bye bye", "exit", "quit", "stop",
    "end conversation", "shut down", "shut up", "that's all",
}


class VoiceConversation:
    """Full conversational voice loop: listen → agent.chat → speak."""

    def __init__(
        self,
        agent: CognosAgent,
        stt: STT | str = "moonshine",
        tts: str = "kokoro",
        voice: str | None = None,
        voice_path: str | None = None,
        **stt_kwargs,
    ):
        self.agent = agent
        self.listener = Listener(stt=stt, **stt_kwargs)
        # Speaker picks the right TTS keyword: Piper takes a file path,
        # Kokoro takes a voice id. Speaker handles the dispatch.
        self.speaker = Speaker(tts=tts, voice=voice, voice_path=voice_path)
        self._inject_voice_instructions()

    def _inject_voice_instructions(self) -> None:
        """Add the voice-mode prompt addendum to the agent's system prompt.

        Personality wraps the system prompt at every turn, so we extend
        its augmentation chain rather than mutating any stored prompt.
        """
        existing = self.agent.agentic.system_prompt_provider

        def voice_wrap(base: str) -> str:
            wrapped = existing(base) if existing else base
            return f"{wrapped}\n\n{VOICE_INSTRUCTIONS}"

        self.agent.agentic.system_prompt_provider = voice_wrap

    async def run(self, greeting: bool = True) -> None:
        await self.agent.start()  # MCP servers, hooks, etc.

        if greeting:
            opening = "Hi. I'm Cognos. What's on your mind?"
            print(f"\nCognos: {opening}")
            self._speak_safely(opening)

        while True:
            print("\n[listening]", end="", flush=True)
            try:
                text = self.listener.listen()
            except KeyboardInterrupt:
                print("\n[interrupted while listening — exiting]")
                break

            if text is None:
                print(" (no speech)")
                continue

            print(f"\rYou: {text}                    ")

            normalized = text.lower().strip().rstrip(".!?")
            if normalized in _EXIT_PHRASES:
                farewell = "Talk soon."
                print(f"Cognos: {farewell}")
                self._speak_safely(farewell)
                break

            print("[thinking]", end="", flush=True)
            try:
                reply = await self.agent.chat(text)
            except Exception as e:
                logger.exception("agent.chat failed in voice loop")
                reply = f"Something went wrong on my end. {e}"

            print(f"\rCognos: {reply}                    ")
            self._speak_safely(reply)

    def _speak_safely(self, text: str) -> None:
        """Speak with Ctrl+C aborting playback so the user can interrupt."""
        try:
            self.speaker.speak(text)
        except KeyboardInterrupt:
            sd.stop()
            print("\n[interrupted]")
