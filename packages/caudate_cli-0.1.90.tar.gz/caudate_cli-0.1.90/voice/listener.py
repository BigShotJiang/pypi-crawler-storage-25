"""Voice listener — VAD-gated mic capture + pluggable STT.

Captures audio from the microphone using `webrtcvad` for voice activity
detection, then hands the recorded WAV bytes off to a pluggable STT
backend (`voice.stt.STT`). The listener has no opinion on which engine
runs the transcription — caller picks.
"""

from __future__ import annotations

import io
import logging
import struct
import wave
from collections import deque

import numpy as np
import sounddevice as sd
import webrtcvad

from voice.stt import STT, make_stt

logger = logging.getLogger(__name__)

# Audio config — webrtcvad mandates 16k mono with 10/20/30ms frames.
SAMPLE_RATE = 16000
FRAME_DURATION_MS = 30
FRAME_SIZE = int(SAMPLE_RATE * FRAME_DURATION_MS / 1000)
CHANNELS = 1


class Listener:
    """VAD-gated microphone capture with delegated transcription."""

    def __init__(
        self,
        stt: STT | str = "moonshine",
        vad_aggressiveness: int = 2,
        **stt_kwargs,
    ):
        self.vad = webrtcvad.Vad(vad_aggressiveness)
        self._stt: STT = stt if not isinstance(stt, str) else make_stt(stt, **stt_kwargs)

    def listen(
        self,
        silence_timeout: float = 1.5,
        max_duration: float = 30.0,
    ) -> str | None:
        """Block until speech, record until silence, return transcription.

        Args:
            silence_timeout: Seconds of silence after speech to stop.
            max_duration: Hard cap on recording length.

        Returns:
            Transcribed text, or None if nothing was said.
        """
        frames_per_timeout = int(silence_timeout * 1000 / FRAME_DURATION_MS)
        max_frames = int(max_duration * 1000 / FRAME_DURATION_MS)

        audio_frames: list[bytes] = []
        ring_buffer: deque = deque(maxlen=frames_per_timeout)
        triggered = False
        silent_frames = 0

        def _frame_to_bytes(frame: np.ndarray) -> bytes:
            pcm = (frame * 32767).astype(np.int16)
            return struct.pack(f"{len(pcm)}h", *pcm)

        with sd.InputStream(
            samplerate=SAMPLE_RATE,
            channels=CHANNELS,
            dtype="float32",
            blocksize=FRAME_SIZE,
        ) as stream:
            for _ in range(max_frames):
                data, _ = stream.read(FRAME_SIZE)
                frame = data[:, 0]
                raw = _frame_to_bytes(frame)
                is_speech = self.vad.is_speech(raw, SAMPLE_RATE)

                if not triggered:
                    ring_buffer.append((raw, is_speech))
                    voiced = sum(1 for _, s in ring_buffer if s)
                    if voiced > 0.8 * (ring_buffer.maxlen or 1):
                        triggered = True
                        audio_frames.extend(f for f, _ in ring_buffer)
                        ring_buffer.clear()
                else:
                    audio_frames.append(raw)
                    if not is_speech:
                        silent_frames += 1
                        if silent_frames >= frames_per_timeout:
                            break
                    else:
                        silent_frames = 0

        if not audio_frames:
            return None

        wav_buffer = io.BytesIO()
        with wave.open(wav_buffer, "wb") as wf:
            wf.setnchannels(CHANNELS)
            wf.setsampwidth(2)
            wf.setframerate(SAMPLE_RATE)
            wf.writeframes(b"".join(audio_frames))

        text = self._stt.transcribe(wav_buffer.getvalue())
        if text:
            logger.info(f"Transcribed: {text}")
        return text or None
