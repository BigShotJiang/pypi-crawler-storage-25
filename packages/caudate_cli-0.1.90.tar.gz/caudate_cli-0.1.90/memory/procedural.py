"""Procedural Memory — stores learned strategies and heuristics in SQLite."""

from __future__ import annotations

import json
import logging
from datetime import datetime

import sqlalchemy as sa
from sqlalchemy import create_engine, Column, String, Float, Integer, DateTime, Text
from sqlalchemy.orm import declarative_base, Session

from config import SQLITE_PATH
from core.schemas import Strategy

logger = logging.getLogger(__name__)

Base = declarative_base()


class StrategyRow(Base):
    __tablename__ = "strategies"

    id = Column(String, primary_key=True)
    name = Column(String, nullable=False)
    description = Column(Text, nullable=False)
    conditions = Column(Text, nullable=False)
    actions = Column(Text, nullable=False)
    confidence = Column(Float, default=0.5)
    times_used = Column(Integer, default=0)
    times_succeeded = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)


class PerformanceLogRow(Base):
    __tablename__ = "performance_log"

    id = Column(Integer, primary_key=True, autoincrement=True)
    goal_id = Column(String, nullable=False)
    score = Column(Float, nullable=False)
    lesson = Column(Text, default="")
    strategy_ids = Column(Text, default="[]")  # JSON list
    timestamp = Column(DateTime, default=datetime.utcnow)


class ProceduralMemory:
    """SQLite-backed store for learned strategies and performance history."""

    def __init__(self, db_path: str | None = None):
        path = db_path or str(SQLITE_PATH)
        self._engine = create_engine(f"sqlite:///{path}")
        Base.metadata.create_all(self._engine)

    def store_strategy(self, strategy: Strategy) -> None:
        """Store or update a strategy."""
        with Session(self._engine) as session:
            row = session.get(StrategyRow, strategy.id)
            if row:
                row.name = strategy.name
                row.description = strategy.description
                row.conditions = strategy.conditions
                row.actions = strategy.actions
                row.confidence = strategy.confidence
                row.times_used = strategy.times_used
                row.times_succeeded = strategy.times_succeeded
                row.updated_at = datetime.utcnow()
            else:
                row = StrategyRow(
                    id=strategy.id,
                    name=strategy.name,
                    description=strategy.description,
                    conditions=strategy.conditions,
                    actions=strategy.actions,
                    confidence=strategy.confidence,
                    times_used=strategy.times_used,
                    times_succeeded=strategy.times_succeeded,
                )
                session.add(row)
            session.commit()

    def get_strategies(self, min_confidence: float = 0.0) -> list[Strategy]:
        """Retrieve all strategies above a confidence threshold."""
        with Session(self._engine) as session:
            rows = session.query(StrategyRow).filter(
                StrategyRow.confidence >= min_confidence
            ).order_by(StrategyRow.confidence.desc()).all()

            return [
                Strategy(
                    id=r.id,
                    name=r.name,
                    description=r.description,
                    conditions=r.conditions,
                    actions=r.actions,
                    confidence=r.confidence,
                    times_used=r.times_used,
                    times_succeeded=r.times_succeeded,
                    created_at=r.created_at,
                    updated_at=r.updated_at,
                )
                for r in rows
            ]

    def update_strategy_stats(self, strategy_id: str, succeeded: bool) -> None:
        """Update usage stats for a strategy after it's been applied."""
        with Session(self._engine) as session:
            row = session.get(StrategyRow, strategy_id)
            if row:
                row.times_used += 1
                if succeeded:
                    row.times_succeeded += 1
                # Recalculate confidence as success rate with Bayesian smoothing
                row.confidence = (row.times_succeeded + 1) / (row.times_used + 2)
                row.updated_at = datetime.utcnow()
                session.commit()

    def log_performance(self, goal_id: str, score: float, lesson: str, strategy_ids: list[str]) -> None:
        """Log a performance entry."""
        with Session(self._engine) as session:
            session.add(PerformanceLogRow(
                goal_id=goal_id,
                score=score,
                lesson=lesson,
                strategy_ids=json.dumps(strategy_ids),
            ))
            session.commit()

    def get_performance_history(self, limit: int = 20) -> list[dict]:
        """Get recent performance entries."""
        with Session(self._engine) as session:
            rows = session.query(PerformanceLogRow).order_by(
                PerformanceLogRow.timestamp.desc()
            ).limit(limit).all()

            return [
                {
                    "goal_id": r.goal_id,
                    "score": r.score,
                    "lesson": r.lesson,
                    "strategy_ids": json.loads(r.strategy_ids),
                    "timestamp": r.timestamp.isoformat(),
                }
                for r in rows
            ]
