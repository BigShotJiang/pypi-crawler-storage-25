"""Working Memory — short-term scratchpad for the current cognitive cycle."""

from __future__ import annotations

import logging
from collections import OrderedDict
from typing import Any

from config import WORKING_MEMORY_CAPACITY

logger = logging.getLogger(__name__)


class WorkingMemory:
    """Fixed-capacity short-term memory. Oldest items are evicted when full."""

    def __init__(self, capacity: int = WORKING_MEMORY_CAPACITY):
        self.capacity = capacity
        self._store: OrderedDict[str, Any] = OrderedDict()

    def store(self, key: str, value: Any) -> None:
        """Store an item. Evicts oldest if at capacity."""
        if key in self._store:
            self._store.move_to_end(key)
        self._store[key] = value
        while len(self._store) > self.capacity:
            evicted_key, _ = self._store.popitem(last=False)
            logger.debug(f"Working memory evicted: {evicted_key}")

    def recall(self, key: str) -> Any | None:
        """Recall an item by key."""
        if key in self._store:
            self._store.move_to_end(key)
            return self._store[key]
        return None

    def recall_all(self) -> dict[str, Any]:
        """Return all items in working memory."""
        return dict(self._store)

    def remove(self, key: str) -> None:
        """Remove an item."""
        self._store.pop(key, None)

    def clear(self) -> None:
        """Clear all working memory."""
        self._store.clear()

    def contains(self, key: str) -> bool:
        return key in self._store

    @property
    def size(self) -> int:
        return len(self._store)

    def summary(self) -> str:
        """Return a text summary of working memory contents."""
        if not self._store:
            return "Working memory is empty."
        lines = [f"Working memory ({self.size}/{self.capacity}):"]
        for key, value in self._store.items():
            val_str = str(value)[:100]
            lines.append(f"  - {key}: {val_str}")
        return "\n".join(lines)
