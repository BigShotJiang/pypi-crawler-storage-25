"""Semantic Memory — long-term knowledge base using vector similarity."""

from __future__ import annotations

import logging

import chromadb

from config import CHROMA_DIR, SEMANTIC_RECALL_LIMIT

logger = logging.getLogger(__name__)


class SemanticMemory:
    """Vector-based knowledge store.

    Stores facts, concepts, and learned information that persists across goals.
    Unlike episodic memory (what happened), semantic memory stores what is known.
    """

    def __init__(self, persist_dir: str | None = None):
        path = persist_dir or str(CHROMA_DIR)
        self._client = chromadb.PersistentClient(path=path)
        self._collection = self._client.get_or_create_collection(
            name="semantic_memory",
            metadata={"hnsw:space": "cosine"},
        )

    def store(self, knowledge_id: str, content: str, category: str = "general") -> None:
        """Store a piece of knowledge."""
        self._collection.upsert(
            ids=[knowledge_id],
            documents=[content],
            metadatas=[{"category": category}],
        )
        logger.debug(f"Stored knowledge: {knowledge_id}")

    def recall(
        self,
        query: str,
        limit: int = SEMANTIC_RECALL_LIMIT,
        category: str | None = None,
    ) -> list[dict[str, str]]:
        """Retrieve relevant knowledge."""
        where = {"category": category} if category else None
        results = self._collection.query(
            query_texts=[query],
            n_results=limit,
            where=where,
        )

        knowledge = []
        if results["documents"]:
            for i, doc in enumerate(results["documents"][0]):
                meta = results["metadatas"][0][i] if results["metadatas"] else {}
                knowledge.append({
                    "id": results["ids"][0][i],
                    "content": doc,
                    "category": meta.get("category", "general"),
                })
        return knowledge

    def forget(self, knowledge_id: str) -> None:
        """Remove a piece of knowledge."""
        try:
            self._collection.delete(ids=[knowledge_id])
        except Exception:
            pass

    def count(self) -> int:
        return self._collection.count()
