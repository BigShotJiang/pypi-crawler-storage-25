"""Strategy library (Phase 1.8) — ChromaDB-backed store of past
successful turn traces.

When a turn ends with `outcome_reward >= STORE_THRESHOLD`, the user's
prompt + the sequence of tool calls + the reward + metadata get
indexed. At the start of the next turn, we query the library for
the top-K most similar past successes and inject them into the
system prompt as a `### Past experience` block. The model gets
"here's what worked last time on a similar request" as context.

Negative outcomes are intentionally **NOT** stored — we don't want
Caudate's recall to surface "this is how I failed last time." The
NN value head (Phase 1.4) handles the negative-signal learning; the
strategy library is the positive-signal recall channel.

Decay policy: traces older than `DECAY_DAYS` get a multiplicative
weight reduction in retrieval scoring. Useful so old patterns fade
when new approaches replace them.
"""

from __future__ import annotations

import json
import logging
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Only store traces with outcome_reward at or above this threshold.
# +0.3 ≈ verify-passed alone, or +1 user-feedback alone — strong enough
# to be considered a "successful" pattern.
STORE_THRESHOLD = 0.30

# Default retrieval count when caller doesn't specify.
DEFAULT_RECALL_K = 3

# Traces older than this lose 50% of their similarity weight.
DECAY_DAYS = 60


@dataclass
class StrategyTrace:
    """A single past-success trace. Stored in ChromaDB; the
    `prompt_text` is the embedded document, everything else lives in
    metadata."""

    id: str
    prompt_text: str
    tool_sequence: list[str]      # ordered tool names called in the turn
    outcome_reward: float
    timestamp: float              # unix epoch seconds
    model_source: str = "unknown"
    goal_id: str | None = None    # links to Phase 2 goals when present
    notes: str = ""

    def to_metadata(self) -> dict[str, Any]:
        """ChromaDB metadata must be primitive scalars only — lists go
        as JSON strings."""
        return {
            "tool_sequence": json.dumps(self.tool_sequence),
            "outcome_reward": float(self.outcome_reward),
            "timestamp": float(self.timestamp),
            "model_source": self.model_source,
            "goal_id": self.goal_id or "",
            "notes": self.notes,
        }

    @classmethod
    def from_metadata(cls, doc_id: str, doc: str, meta: dict[str, Any]) -> "StrategyTrace":
        try:
            tool_seq = json.loads(meta.get("tool_sequence", "[]"))
        except (TypeError, ValueError):
            tool_seq = []
        return cls(
            id=doc_id,
            prompt_text=doc,
            tool_sequence=tool_seq,
            outcome_reward=float(meta.get("outcome_reward", 0.0)),
            timestamp=float(meta.get("timestamp", 0.0)),
            model_source=str(meta.get("model_source", "unknown")),
            goal_id=meta.get("goal_id") or None,
            notes=str(meta.get("notes", "")),
        )

    def one_liner(self) -> str:
        """Compact form for prompt injection."""
        prompt = self.prompt_text[:120].replace("\n", " ")
        tools = " → ".join(self.tool_sequence[:8]) if self.tool_sequence else "(no tools)"
        age_days = max(0, (time.time() - self.timestamp) / 86400.0)
        if age_days < 1:
            age = "today"
        elif age_days < 30:
            age = f"{int(age_days)}d ago"
        else:
            age = f"{int(age_days/30)}mo ago"
        return f"[{age}, reward={self.outcome_reward:+.2f}] {prompt!r} → {tools}"


class StrategyLibrary:
    """Vector-indexed store of past-success traces.

    Backed by ChromaDB so retrieval is embedding-similarity over the
    user prompt. Only stores traces with outcome_reward >= STORE_THRESHOLD.
    """

    COLLECTION_NAME = "caudate_strategies"

    def __init__(self, persist_dir: str | Path | None = None):
        # Defer the chromadb import so the module can be imported in
        # environments where chromadb isn't available (tests, slim builds).
        from config import CHROMA_DIR  # type: ignore
        import chromadb

        path = str(persist_dir or CHROMA_DIR)
        self._client = chromadb.PersistentClient(path=path)
        self._collection = self._client.get_or_create_collection(
            name=self.COLLECTION_NAME,
            metadata={"hnsw:space": "cosine"},
        )

    # ─── Write ─────────────────────────────────────────────────────

    def store(self, trace: StrategyTrace) -> bool:
        """Index a trace. Returns True if stored, False if rejected
        (e.g. reward below threshold, empty prompt)."""
        if trace.outcome_reward < STORE_THRESHOLD:
            return False
        if not trace.prompt_text.strip():
            return False
        try:
            self._collection.add(
                ids=[trace.id],
                documents=[trace.prompt_text],
                metadatas=[trace.to_metadata()],
            )
            logger.debug(
                f"strategy stored {trace.id} reward={trace.outcome_reward:+.2f} "
                f"tools={trace.tool_sequence[:5]}"
            )
            return True
        except Exception as e:
            logger.warning(f"strategy store failed: {e}")
            return False

    # ─── Read ──────────────────────────────────────────────────────

    def recall(
        self,
        query: str,
        k: int = DEFAULT_RECALL_K,
        min_age_seconds: float = 60.0,
    ) -> list[StrategyTrace]:
        """Return top-K most similar past successes.

        `min_age_seconds` filters out traces from the current session
        (default: 60s) so the model doesn't recall "itself doing the
        same thing 30 seconds ago" — that adds noise without learning.
        """
        if not query.strip() or k <= 0:
            return []
        try:
            results = self._collection.query(
                query_texts=[query],
                n_results=max(k * 3, k),  # over-fetch then filter
            )
        except Exception as e:
            logger.debug(f"strategy recall failed: {e}")
            return []

        now = time.time()
        out: list[tuple[float, StrategyTrace]] = []
        ids = (results.get("ids") or [[]])[0]
        docs = (results.get("documents") or [[]])[0]
        metas = (results.get("metadatas") or [[]])[0]
        distances = (results.get("distances") or [[]])[0]
        for i, doc_id in enumerate(ids):
            doc = docs[i] if i < len(docs) else ""
            meta = metas[i] if i < len(metas) else {}
            dist = distances[i] if i < len(distances) else 1.0
            trace = StrategyTrace.from_metadata(doc_id, doc, meta)
            # Filter session-fresh entries.
            if now - trace.timestamp < min_age_seconds:
                continue
            # Apply age decay to the similarity score (smaller dist = better).
            age_days = (now - trace.timestamp) / 86400.0
            decay_mult = 1.0 + (age_days / DECAY_DAYS) * 0.5  # ~50% by DECAY_DAYS
            adjusted_dist = float(dist) * decay_mult
            out.append((adjusted_dist, trace))

        out.sort(key=lambda t: t[0])
        return [t for _, t in out[:k]]

    # ─── Maintenance ───────────────────────────────────────────────

    def count(self) -> int:
        try:
            return int(self._collection.count())
        except Exception:
            return 0

    def delete(self, trace_id: str) -> bool:
        try:
            self._collection.delete(ids=[trace_id])
            return True
        except Exception:
            return False

    def prune(self, max_age_days: float = 365.0) -> int:
        """Drop traces older than `max_age_days`. Returns count pruned."""
        cutoff = time.time() - max_age_days * 86400.0
        try:
            all_records = self._collection.get(include=["metadatas"])
            to_delete = []
            for i, meta in enumerate(all_records.get("metadatas") or []):
                if float(meta.get("timestamp", 0)) < cutoff:
                    to_delete.append(all_records["ids"][i])
            if to_delete:
                self._collection.delete(ids=to_delete)
            return len(to_delete)
        except Exception as e:
            logger.debug(f"strategy prune failed: {e}")
            return 0


# ─── Module-level singleton + safe accessors ──────────────────────

_library: StrategyLibrary | None = None


def get_library() -> StrategyLibrary | None:
    """Lazy-init the singleton. Returns None if chromadb isn't
    available so callers can no-op gracefully."""
    global _library
    if _library is not None:
        return _library
    try:
        _library = StrategyLibrary()
        return _library
    except Exception as e:
        logger.debug(f"StrategyLibrary unavailable: {e}")
        return None


def store_if_successful(
    prompt_text: str,
    tool_sequence: list[str],
    outcome_reward: float,
    model_source: str = "unknown",
    goal_id: str | None = None,
    notes: str = "",
) -> bool:
    """Top-level convenience: build a trace + try to store. Safe to
    call unconditionally — does nothing if reward below threshold or
    library unavailable."""
    if outcome_reward < STORE_THRESHOLD:
        return False
    lib = get_library()
    if lib is None:
        return False
    trace = StrategyTrace(
        id=str(uuid.uuid4()),
        prompt_text=prompt_text,
        tool_sequence=list(tool_sequence),
        outcome_reward=float(outcome_reward),
        timestamp=time.time(),
        model_source=model_source,
        goal_id=goal_id,
        notes=notes,
    )
    return lib.store(trace)


def recall_for_prompt(
    prompt_text: str, k: int = DEFAULT_RECALL_K,
) -> list[StrategyTrace]:
    """Top-level convenience: query the library, returning an empty
    list if unavailable."""
    lib = get_library()
    if lib is None:
        return []
    return lib.recall(prompt_text, k=k)
