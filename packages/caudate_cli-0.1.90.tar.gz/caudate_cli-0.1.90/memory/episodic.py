"""Episodic Memory — stores and retrieves past experiences using vector similarity."""

from __future__ import annotations

import json
import logging
from typing import Any

import chromadb

from config import CHROMA_DIR, EPISODIC_RECALL_LIMIT
from core.schemas import Episode

logger = logging.getLogger(__name__)


class EpisodicMemory:
    """Vector-based store of past episodes (experiences).

    Each episode records what the agent did, what happened, and in what context.
    Retrieval is by semantic similarity to a query.
    """

    def __init__(self, persist_dir: str | None = None):
        path = persist_dir or str(CHROMA_DIR)
        self._client = chromadb.PersistentClient(path=path)
        self._collection = self._client.get_or_create_collection(
            name="episodic_memory",
            metadata={"hnsw:space": "cosine"},
        )

    def store(self, episode: Episode) -> None:
        """Store an episode."""
        text = self._episode_to_text(episode)
        metadata = {
            "goal_id": episode.goal_id,
            "task_id": episode.task_id,
            "tool_name": episode.tool_name or "",
            "timestamp": episode.timestamp.isoformat(),
        }
        if episode.result:
            metadata["result_status"] = episode.result.status.value

        self._collection.add(
            ids=[episode.id],
            documents=[text],
            metadatas=[metadata],
        )
        logger.debug(f"Stored episode {episode.id}")

    def recall(
        self,
        query: str,
        limit: int = EPISODIC_RECALL_LIMIT,
        goal_id: str | None = None,
    ) -> list[Episode]:
        """Retrieve similar episodes."""
        where = {"goal_id": goal_id} if goal_id else None
        results = self._collection.query(
            query_texts=[query],
            n_results=limit,
            where=where,
        )

        episodes = []
        if results["documents"]:
            for i, doc in enumerate(results["documents"][0]):
                meta = results["metadatas"][0][i] if results["metadatas"] else {}
                kwargs = {
                    "id": results["ids"][0][i],
                    "goal_id": meta.get("goal_id", ""),
                    "task_id": meta.get("task_id", ""),
                    "action": doc,
                    "tool_name": meta.get("tool_name") or None,
                }
                ts = meta.get("timestamp")
                if ts:
                    kwargs["timestamp"] = ts
                episode = Episode(**kwargs)
                episodes.append(episode)
        return episodes

    def count(self) -> int:
        return self._collection.count()

    def _episode_to_text(self, episode: Episode) -> str:
        """Convert episode to searchable text."""
        parts = [f"Action: {episode.action}"]
        if episode.tool_name:
            parts.append(f"Tool: {episode.tool_name}")
        if episode.tool_args:
            parts.append(f"Args: {json.dumps(episode.tool_args)}")
        if episode.result:
            parts.append(f"Result: {episode.result.status.value}")
            if episode.result.output:
                parts.append(f"Output: {str(episode.result.output)[:500]}")
            if episode.result.error:
                parts.append(f"Error: {episode.result.error}")
        return " | ".join(parts)
