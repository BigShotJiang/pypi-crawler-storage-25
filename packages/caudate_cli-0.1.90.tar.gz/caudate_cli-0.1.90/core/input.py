"""REPL input — multi-line, history search, Claude-style slash palette.

Wraps prompt_toolkit if available, falls back to console.input if not.

Three enhancements over the bare console prompt:

  - **Multi-line**: Enter submits; Ctrl+J inserts a newline. Starting a
    line with a triple-quote submits everything up to the matching
    closing triple-quote.
  - **History**: up/down scroll prior inputs, Ctrl+R reverse-searches.
    Persisted to ~/.caudate/history so it spans sessions.
  - **Slash palette**: typing `/<word>` opens an inline two-column
    menu rendered directly under the input line (not pinned to the
    bottom of the terminal) — command (cyan, padded) + wrapped
    description (gray), highlighted selection. ↑/↓ move; Enter
    inserts+submits; Tab inserts; Esc clears.

We build a custom `Application` with an `HSplit` layout for the slash
palette so the menu Window sits directly below the input — that's the
only way to get Claude Code's inline placement; PromptSession's
bottom_toolbar always anchors to the screen bottom.

The fallback path is plain input() so the REPL still works on a
machine without prompt_toolkit installed.
"""

from __future__ import annotations

import logging
import shutil
from pathlib import Path

from rich.console import Console

logger = logging.getLogger(__name__)


def _history_path() -> Path:
    p = Path.home() / ".caudate" / "history"
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


_PREFERRED = {"quit", "clear", "help", "permissions", "voice"}


def _canonical_names() -> list[str]:
    from core.slash_commands import REGISTRY, description_for

    canonical: dict = {}
    for name, handler in REGISTRY.items():
        has_desc = bool(description_for(name))
        is_preferred = name in _PREFERRED
        cur = canonical.get(handler)
        if cur is None:
            canonical[handler] = name
            continue
        cur_preferred = cur in _PREFERRED
        if is_preferred and not cur_preferred:
            canonical[handler] = name
            continue
        if cur_preferred and not is_preferred:
            continue
        cur_has_desc = bool(description_for(cur))
        if has_desc and not cur_has_desc:
            canonical[handler] = name
            continue
        if cur_has_desc and not has_desc:
            continue
        if len(name) > len(cur) or (len(name) == len(cur) and name < cur):
            canonical[handler] = name
    names = set(canonical.values())

    # Discover user/project markdown commands and add them to the
    # palette so `/` autocompletes them too.
    try:
        from core.custom_commands import discover
        for cmd_name in discover().keys():
            names.add(cmd_name)
    except Exception:
        pass

    return sorted(names)


def _grab_clipboard_image() -> str | None:
    """If the system clipboard holds an image, save it to a temp file
    and return the absolute path. Returns None otherwise.

    Tries the platform-appropriate clipboard tool:
      - Linux/X11:    xclip
      - Linux/Wayland: wl-paste
      - macOS:        pbpaste
    """
    import os as _os
    import platform as _platform
    import subprocess as _subprocess
    import tempfile as _tempfile
    from pathlib import Path as _Path

    system = _platform.system()
    candidates: list[tuple[list[str], str]] = []

    if system == "Linux":
        if _os.environ.get("WAYLAND_DISPLAY"):
            candidates.append((["wl-paste", "--type", "image/png"], "png"))
            candidates.append((["wl-paste", "--type", "image/jpeg"], "jpg"))
        candidates.append((["xclip", "-selection", "clipboard", "-t", "image/png", "-o"], "png"))
        candidates.append((["xclip", "-selection", "clipboard", "-t", "image/jpeg", "-o"], "jpg"))
    elif system == "Darwin":
        candidates.append((["pbpaste", "-Prefer", "image"], "png"))

    for argv, ext in candidates:
        try:
            proc = _subprocess.run(
                argv, capture_output=True, timeout=2, check=False,
            )
        except (FileNotFoundError, _subprocess.TimeoutExpired):
            continue
        if proc.returncode != 0 or not proc.stdout:
            continue
        data = proc.stdout
        # PNG magic 0x89 0x50 0x4E 0x47 ; JPEG starts 0xFF 0xD8 0xFF.
        if not (data[:4] == b"\x89PNG" or data[:3] == b"\xff\xd8\xff"):
            continue
        tmpdir = _Path(_tempfile.gettempdir()) / "caudate-paste"
        tmpdir.mkdir(parents=True, exist_ok=True)
        import time as _time
        path = tmpdir / f"paste-{int(_time.time() * 1000)}.{ext}"
        try:
            path.write_bytes(data)
        except Exception:
            return None
        return str(path)

    return None


def _wrap(s: str, width: int) -> list[str]:
    if not s:
        return [""]
    words = s.split()
    lines: list[str] = []
    cur = ""
    for w in words:
        if not cur:
            cur = w
        elif len(cur) + 1 + len(w) <= width:
            cur += " " + w
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines


class CognosPrompt:
    """Adaptive prompt — custom prompt_toolkit Application or plain input."""

    def __init__(self, console: Console):
        self.console = console
        self._available = False
        self._sel = 0
        self._first = 0  # viewport scroll position
        self._names = _canonical_names()
        self._history = None
        self._label = "You> "
        self._statusline_fn: callable | None = None
        self._mode_cycler: callable | None = None
        try:
            from prompt_toolkit.history import FileHistory
            self._history = FileHistory(str(_history_path()))
            self._available = True
        except Exception as e:
            logger.debug(f"prompt_toolkit unavailable: {e}")

    def set_mode_cycler(self, fn) -> None:
        """Register a callable that advances permission mode. Invoked
        when the user presses Shift-Tab. Should return the new mode
        name (string) so we can show a toast or update statusline."""
        self._mode_cycler = fn

    def set_statusline(self, fn) -> None:
        """Register a callable returning the statusline text. Renders
        as a footer line below the bordered input box."""
        self._statusline_fn = fn

    def ask(self, label: str = "You> ") -> str:
        if self._available:
            try:
                return self._ask_pt(label)
            except (EOFError, KeyboardInterrupt):
                raise
            except Exception as e:
                logger.debug(f"prompt_toolkit failed mid-call: {e}")
        first = self.console.input(label)
        if first.startswith('"""'):
            buf = [first[3:]]
            while True:
                line = self.console.input("... ")
                if line.endswith('"""'):
                    buf.append(line[:-3])
                    break
                buf.append(line)
            return "\n".join(buf)
        return first

    # -----------------------------------------------------------------
    # prompt_toolkit branch — custom Application with inline slash menu
    # -----------------------------------------------------------------
    def _ask_pt(self, label: str) -> str:
        # Reset per-prompt viewport state
        self._sel = 0
        self._first = 0
        # Per-prompt clipboard-image register. Keys are integer indices
        # starting at 1; values are absolute paths. Placeholders like
        # `[Image #1]` in the buffer are expanded to these paths before
        # the prompt returns.
        self._paste_register: dict[int, str] = {}
        # Per-prompt text-paste register for multi-line / large pastes.
        # The buffer shows `[Pasted #1 (N lines)]`; we substitute the
        # real text back in before returning. Matches Claude Code UX.
        self._text_paste_register: dict[int, str] = {}
        from prompt_toolkit.application import Application
        from prompt_toolkit.buffer import Buffer
        from prompt_toolkit.document import Document
        from prompt_toolkit.layout import Layout
        from prompt_toolkit.layout.containers import (
            ConditionalContainer, HSplit, VSplit, Window, WindowAlign,
        )
        from prompt_toolkit.widgets import Frame
        from prompt_toolkit.layout.controls import BufferControl, FormattedTextControl
        from prompt_toolkit.layout.dimension import Dimension as D
        from prompt_toolkit.layout.processors import BeforeInput
        from prompt_toolkit.key_binding import KeyBindings, merge_key_bindings
        from prompt_toolkit.key_binding.bindings.basic import load_basic_bindings
        from prompt_toolkit.key_binding.bindings.emacs import load_emacs_bindings
        from prompt_toolkit.filters import Condition
        from prompt_toolkit.formatted_text import FormattedText
        from prompt_toolkit.styles import Style
        from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
        from core.slash_commands import description_for

        result: dict[str, str | None] = {"value": None}
        self._sel = 0

        # Input buffer
        input_buffer = Buffer(
            multiline=False,
            history=self._history,
            auto_suggest=AutoSuggestFromHistory(),
            accept_handler=lambda buf: self._on_accept(buf, result),
        )

        # ----- helpers
        def _term_cols() -> int:
            try:
                return shutil.get_terminal_size().columns
            except Exception:
                return 100

        def _is_slash_input(text: str) -> bool:
            if not text.startswith("/") or len(text) > 30:
                return False
            for ch in text[1:]:
                if not (ch.isalnum() or ch in "-_?"):
                    return False
            return True

        def _filtered() -> list[str]:
            text = input_buffer.text
            if not _is_slash_input(text):
                return []
            query = text[1:].lower()
            return [n for n in self._names if not query or query in n.lower()]

        def _menu_visible() -> bool:
            return len(_filtered()) > 0

        def _term_rows() -> int:
            try:
                return shutil.get_terminal_size().lines
            except Exception:
                return 30

        def _menu_text() -> FormattedText:
            visible = _filtered()
            if not visible:
                return FormattedText([])
            self._sel = max(0, min(self._sel, len(visible) - 1))

            cols = max(60, _term_cols())
            name_col_w = 18
            gap = 2
            desc_col_w = max(20, cols - name_col_w - gap - 1)

            # Viewport — dynamic, based on what actually fits in the
            # terminal. Reserve ~6 rows for banner+statusline+input.
            # Cap at 15 so a tall terminal doesn't print 49 rows at once.
            viewport_rows = max(5, min(15, _term_rows() - 6))

            # Slide window so selection stays inside it.
            if self._sel < self._first:
                self._first = self._sel
            elif self._sel >= self._first + viewport_rows:
                self._first = self._sel - viewport_rows + 1
            self._first = max(0, min(self._first, max(0, len(visible) - viewport_rows)))

            window = visible[self._first : self._first + viewport_rows]

            out: list[tuple[str, str]] = []
            for offset, name in enumerate(window):
                i = self._first + offset
                selected = (i == self._sel)
                style_cmd = "class:slash.cmd.cur" if selected else "class:slash.cmd"
                style_desc = "class:slash.desc.cur" if selected else "class:slash.desc"
                desc = description_for(name) or ""
                if len(desc) > desc_col_w:
                    desc = desc[: desc_col_w - 1] + "…"
                cmd_cell = f"/{name}".ljust(name_col_w)
                desc_cell = " " * gap + desc.ljust(desc_col_w)
                out.append((style_cmd, cmd_cell))
                out.append((style_desc, desc_cell))
                out.append(("", "\n"))
            return FormattedText(out)

        # ----- layout
        input_window = Window(
            content=BufferControl(
                buffer=input_buffer,
                input_processors=[BeforeInput(label)],
            ),
            height=D(min=1, max=1),
            dont_extend_height=True,
            wrap_lines=False,
        )
        # Wrap the input in a rounded Frame so it renders as a bordered
        # box (matches Claude Code's input area).
        input_frame = Frame(
            body=input_window,
            style="class:input.frame",
        )
        menu_window = ConditionalContainer(
            Window(
                content=FormattedTextControl(_menu_text, focusable=False),
                height=D(min=1, max=15, preferred=15),
                dont_extend_height=True,
                always_hide_cursor=True,
            ),
            filter=Condition(_menu_visible),
        )

        # Bottom statusline — renders below the input frame, dim, single
        # line. Calls back into the user-supplied function each render
        # so token/cost values update live.
        def _statusline_text() -> str:
            if self._statusline_fn is None:
                return ""
            try:
                return self._statusline_fn() or ""
            except Exception:
                return ""

        status_window = ConditionalContainer(
            Window(
                content=FormattedTextControl(
                    lambda: [("class:statusline", _statusline_text())],
                    focusable=False,
                ),
                height=D.exact(1),
                always_hide_cursor=True,
            ),
            filter=Condition(lambda: bool(self._statusline_fn)),
        )

        root = HSplit([input_frame, menu_window, status_window])

        # ----- key bindings
        kb = KeyBindings()

        @kb.add("c-c")
        def _(event):
            event.app.exit(exception=KeyboardInterrupt)

        @kb.add("c-d")
        def _(event):
            if not input_buffer.text:
                event.app.exit(exception=EOFError)

        @kb.add("c-j")
        def _(event):
            input_buffer.insert_text("\n")

        @kb.add("up", filter=Condition(_menu_visible))
        def _(event):
            self._sel = max(0, self._sel - 1)
            event.app.invalidate()

        @kb.add("down", filter=Condition(_menu_visible))
        def _(event):
            self._sel = min(len(_filtered()) - 1, self._sel + 1)
            event.app.invalidate()

        @kb.add("up", filter=~Condition(_menu_visible))
        def _(event):
            input_buffer.history_backward()

        @kb.add("down", filter=~Condition(_menu_visible))
        def _(event):
            input_buffer.history_forward()

        @kb.add("tab", filter=Condition(_menu_visible))
        def _(event):
            visible = _filtered()
            if not visible:
                return
            picked = "/" + visible[self._sel]
            input_buffer.text = picked + " "
            input_buffer.cursor_position = len(input_buffer.text)
            self._sel = 0

        @kb.add("enter", filter=Condition(_menu_visible))
        def _(event):
            visible = _filtered()
            if not visible:
                input_buffer.validate_and_handle()
                return
            picked = "/" + visible[self._sel]
            input_buffer.text = picked
            input_buffer.cursor_position = len(picked)
            input_buffer.validate_and_handle()

        @kb.add("enter", filter=~Condition(_menu_visible))
        def _(event):
            input_buffer.validate_and_handle()

        @kb.add("escape", filter=Condition(_menu_visible))
        def _(event):
            input_buffer.text = ""
            self._sel = 0

        @kb.add("/")
        def _(event):
            input_buffer.insert_text("/")
            self._sel = 0
            self._first = 0

        @kb.add("s-tab")  # Shift-Tab
        def _(event):
            """Cycle permission mode: default → plan → accept_edits → bypass → default."""
            if self._mode_cycler is None:
                return
            try:
                new_mode = self._mode_cycler()
            except Exception:
                return
            # Force a redraw so the statusline picks up the new mode.
            event.app.invalidate()

        @kb.add("c-v")
        def _(event):
            """Ctrl-V paste — if the clipboard holds an image, save it
            to a temp file, register it, and insert a `[Image #N]`
            placeholder (Claude-Code-style). The full path is hidden
            from the user but expanded before the prompt returns so
            downstream attachment handling still sees it."""
            path = _grab_clipboard_image()
            if path is not None:
                idx = len(self._paste_register) + 1
                self._paste_register[idx] = path
                token = f"[Image #{idx}]"
                if input_buffer.text and not input_buffer.text.endswith(" "):
                    token = " " + token
                input_buffer.insert_text(token)
                return
            # No image — fall back to default clipboard text paste.
            try:
                data = event.app.clipboard.get_data()
                input_buffer.paste_clipboard_data(data)
            except Exception:
                pass

        # ----- bracketed paste (right-click / middle-click in terminal)
        # Terminal-driven pastes arrive as a single BracketedPaste key
        # event containing the full pasted string. We intercept long
        # / multi-line pastes and replace them with a placeholder so
        # the single-line input box doesn't hide content from view.
        from prompt_toolkit.keys import Keys as _Keys

        def _insert_text_paste(text: str) -> None:
            """Insert pasted text. Long/multi-line pastes become a
            `[Pasted #N (X lines)]` placeholder; short single-line
            pastes are inserted verbatim."""
            n_lines = text.count("\n") + 1
            n_chars = len(text)
            is_big = ("\n" in text) or n_chars > 200
            if is_big:
                idx = len(self._text_paste_register) + 1
                self._text_paste_register[idx] = text
                lines_label = f"{n_lines} lines" if n_lines > 1 else f"{n_chars} chars"
                token = f"[Pasted #{idx} ({lines_label})]"
                if input_buffer.text and not input_buffer.text.endswith(" "):
                    token = " " + token
                input_buffer.insert_text(token)
            else:
                input_buffer.insert_text(text)

        @kb.add(_Keys.BracketedPaste)
        def _(event):
            text = event.data or ""
            _insert_text_paste(text)

        # ----- style
        style = Style.from_dict({
            "slash.cmd":       "fg:#5fafff",
            "slash.cmd.cur":   "fg:#ffffff bg:#005f87 bold",
            "slash.desc":      "fg:#8a8a8a",
            "slash.desc.cur":  "fg:#d0d0d0 bg:#005f87",
            "slash.footer":    "fg:#5f5f87 italic",
            # Frame border stays dim, but the input content + statusline
            # render in plain white so the user's typed text is fully
            # legible against the terminal background.
            "frame.border":    "fg:#5f5f87",
            "input.frame":     "fg:#ffffff",
            "statusline":      "fg:#ffffff",
        })

        # Merge our slash-palette bindings *on top of* the default
        # emacs+basic bindings so arrow keys, history nav, line editing
        # (Home/End/Ctrl-A/Ctrl-E etc.) still work outside the menu.
        merged_kb = merge_key_bindings([
            load_basic_bindings(),
            load_emacs_bindings(),
            kb,
        ])

        app = Application(
            layout=Layout(root, focused_element=input_window),
            key_bindings=merged_kb,
            style=style,
            full_screen=False,
            erase_when_done=True,
        )
        app.run()

        if result["value"] is None:
            raise EOFError
        text = result["value"]
        # Expand `[Image #N]` placeholders back to their saved paths
        # so detect_paste() (in main.py) can upload them as attachments.
        if self._paste_register:
            import re as _re
            def _sub(m):
                idx = int(m.group(1))
                return self._paste_register.get(idx, m.group(0))
            text = _re.sub(r"\[Image #(\d+)\]", _sub, text)
        # Same trick for `[Pasted #N (…)]` text-paste placeholders.
        if self._text_paste_register:
            import re as _re2
            def _sub_paste(m):
                idx = int(m.group(1))
                return self._text_paste_register.get(idx, m.group(0))
            text = _re2.sub(r"\[Pasted #(\d+) \([^)]+\)\]", _sub_paste, text)
        # Echo the submitted prompt as a transcript line. erase_when_done
        # wipes the bordered input box on submit (so the Frame doesn't
        # linger), so we reprint the user's text here in a Claude-Code
        # style `> …` block. Multi-line input is preserved.
        if text.strip():
            try:
                for i, line in enumerate(text.splitlines() or [""]):
                    prefix = "[bold cyan]>[/bold cyan] " if i == 0 else "  "
                    self.console.print(f"{prefix}{line}")
            except Exception:
                self.console.file.write(f"> {text}\n")
                self.console.file.flush()

        return text

    def _on_accept(self, buf, result: dict) -> bool:
        result["value"] = buf.text
        from prompt_toolkit.application.current import get_app
        get_app().exit(result=buf.text)
        return False
