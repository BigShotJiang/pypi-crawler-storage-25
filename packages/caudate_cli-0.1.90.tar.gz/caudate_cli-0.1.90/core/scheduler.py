"""Cron-style scheduler for recurring agent prompts.

Persistent jobs are stored as JSON in `data/cron.json`. Each job has:

  id, prompt, schedule, enabled, last_run, next_run

`schedule` accepts a tiny subset of cron syntax that's enough for the
common cases without dragging in a full cron parser:

  - `every 30s` / `every 5m` / `every 2h`     → fixed interval
  - `daily 09:30`                             → every day at 09:30 local
  - `weekly mon 09:30`                        → mon/tue/.../sun
  - `at 2026-05-01 14:00`                     → one-shot

The runtime is `cognos cron run` — a foreground daemon that loops over
all enabled jobs, fires any whose `next_run <= now`, and reschedules.
That's deliberately simple: a real `cron` /systemd timer is the right
tool for production; this is for quick "remind me / re-check" loops a
single user wants alongside the REPL.
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
import uuid
from dataclasses import dataclass, field
from datetime import datetime, time as dtime, timedelta
from pathlib import Path
from typing import Any, Awaitable, Callable

logger = logging.getLogger(__name__)


_DAYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]


@dataclass
class CronJob:
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])
    prompt: str = ""
    schedule: str = ""
    enabled: bool = True
    last_run: str | None = None
    next_run: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


def _parse_schedule(schedule: str, now: datetime) -> datetime | None:
    """Compute the next firing time for `schedule` after `now`."""
    s = schedule.strip().lower()

    # every <N><unit>
    m = re.fullmatch(r"every\s+(\d+)\s*(s|sec|m|min|h|hr|d|day)s?", s)
    if m:
        n = int(m.group(1))
        unit = m.group(2)
        delta = {
            "s": timedelta(seconds=n),
            "sec": timedelta(seconds=n),
            "m": timedelta(minutes=n),
            "min": timedelta(minutes=n),
            "h": timedelta(hours=n),
            "hr": timedelta(hours=n),
            "d": timedelta(days=n),
            "day": timedelta(days=n),
        }[unit]
        return now + delta

    # daily HH:MM
    m = re.fullmatch(r"daily\s+(\d{1,2}):(\d{2})", s)
    if m:
        target = dtime(int(m.group(1)), int(m.group(2)))
        nxt = now.replace(hour=target.hour, minute=target.minute, second=0, microsecond=0)
        if nxt <= now:
            nxt += timedelta(days=1)
        return nxt

    # weekly <dow> HH:MM
    m = re.fullmatch(r"weekly\s+(mon|tue|wed|thu|fri|sat|sun)\s+(\d{1,2}):(\d{2})", s)
    if m:
        dow = _DAYS.index(m.group(1))
        target = dtime(int(m.group(2)), int(m.group(3)))
        nxt = now.replace(hour=target.hour, minute=target.minute, second=0, microsecond=0)
        days_ahead = (dow - nxt.weekday()) % 7
        if days_ahead == 0 and nxt <= now:
            days_ahead = 7
        return nxt + timedelta(days=days_ahead)

    # at YYYY-MM-DD HH:MM (one-shot)
    m = re.fullmatch(r"at\s+(\d{4}-\d{2}-\d{2})\s+(\d{1,2}):(\d{2})", s)
    if m:
        try:
            return datetime.fromisoformat(f"{m.group(1)}T{int(m.group(2)):02d}:{int(m.group(3)):02d}:00")
        except ValueError:
            return None

    return None


class CronStore:
    """Load/save persistence for CronJob entries."""

    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._jobs: dict[str, CronJob] = {}
        self._load()

    def _load(self) -> None:
        if not self.path.exists():
            return
        try:
            raw = json.loads(self.path.read_text())
        except Exception as e:
            logger.warning(f"Failed to load cron jobs: {e}")
            return
        for entry in raw.get("jobs", []):
            try:
                self._jobs[entry["id"]] = CronJob(**entry)
            except Exception as e:
                logger.debug(f"Skipping bad cron entry {entry}: {e}")

    def _save(self) -> None:
        payload = {"jobs": [j.__dict__ for j in self._jobs.values()]}
        self.path.write_text(json.dumps(payload, indent=2))

    def add(self, prompt: str, schedule: str, **metadata: Any) -> CronJob:
        nxt = _parse_schedule(schedule, datetime.now())
        if nxt is None:
            raise ValueError(f"Unrecognized schedule: {schedule}")
        job = CronJob(
            prompt=prompt,
            schedule=schedule,
            next_run=nxt.isoformat(timespec="seconds"),
            metadata=metadata,
        )
        self._jobs[job.id] = job
        self._save()
        return job

    def remove(self, job_id: str) -> bool:
        if job_id not in self._jobs:
            return False
        del self._jobs[job_id]
        self._save()
        return True

    def list(self) -> list[CronJob]:
        return sorted(self._jobs.values(), key=lambda j: j.id)

    def get(self, job_id: str) -> CronJob | None:
        return self._jobs.get(job_id)

    def mark_run(self, job_id: str, ran_at: datetime) -> None:
        job = self._jobs.get(job_id)
        if job is None:
            return
        job.last_run = ran_at.isoformat(timespec="seconds")
        nxt = _parse_schedule(job.schedule, ran_at)
        # one-shot 'at' schedules can return a time in the past — disable
        if nxt is None or (job.schedule.lower().startswith("at ") and nxt <= ran_at):
            job.enabled = False
            job.next_run = None
        else:
            job.next_run = nxt.isoformat(timespec="seconds")
        self._save()


async def run_scheduler(
    store: CronStore,
    fire: Callable[[CronJob], Awaitable[None]],
    poll_seconds: float = 5.0,
) -> None:
    """Loop forever, firing jobs whose next_run has passed."""
    logger.info(f"Cron scheduler started: {len(store.list())} jobs")
    while True:
        now = datetime.now()
        for job in store.list():
            if not job.enabled or not job.next_run:
                continue
            try:
                nxt = datetime.fromisoformat(job.next_run)
            except ValueError:
                continue
            if nxt > now:
                continue
            try:
                await fire(job)
            except Exception as e:
                logger.warning(f"Cron job {job.id} fire failed: {e}")
            store.mark_run(job.id, now)
        await asyncio.sleep(poll_seconds)
