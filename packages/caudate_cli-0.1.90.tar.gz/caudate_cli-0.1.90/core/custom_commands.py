"""Custom command files — markdown files that become slash commands.

Drop a file at `~/.config/caudate/commands/foo.md` and it becomes
invokable as `/foo`. Subdirectories nest into the name with `:` —
`git/commit.md` becomes `/git:commit`. Project-local commands live
under `./.caudate/commands/` and override user commands of the same
name.

The file body is the prompt template. It supports placeholders in
the form `$VAR_NAME` (uppercase letters, digits, underscores; must
start with a letter). When the user invokes the command, Caudate
prompts for each unique placeholder, substitutes the values into
the template, and sends the result as a normal chat message.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

logger = logging.getLogger(__name__)


# $VAR_NAME — first char must be a letter, rest letters/digits/underscores.
_PLACEHOLDER_RE = re.compile(r"\$([A-Z][A-Z0-9_]*)")


@dataclass
class CustomCommand:
    name: str                 # e.g. "prime-context" or "git:commit"
    source: str               # "user" | "project"
    path: Path                # absolute path to the .md file
    body: str = field(default="", repr=False)
    description: str = ""     # first non-blank line if it looks like a comment

    def placeholders(self) -> list[str]:
        """Return placeholder names in the order they first appear."""
        seen: list[str] = []
        for m in _PLACEHOLDER_RE.finditer(self.body):
            name = m.group(1)
            if name not in seen:
                seen.append(name)
        return seen

    def render(self, values: dict[str, str]) -> str:
        """Substitute placeholders. Missing keys are left as literal `$NAME`."""
        def _sub(m: re.Match) -> str:
            return values.get(m.group(1), m.group(0))
        return _PLACEHOLDER_RE.sub(_sub, self.body)


def _user_dirs() -> list[Path]:
    """User-level command directories, in priority order."""
    import os
    xdg = os.environ.get("XDG_CONFIG_HOME")
    base = Path(xdg) if xdg else Path.home() / ".config"
    return [
        base / "caudate" / "commands",
        Path.home() / ".caudate" / "commands",
    ]


def _project_dirs() -> list[Path]:
    return [Path.cwd() / ".caudate" / "commands"]


def _walk(root: Path) -> Iterable[Path]:
    if not root.exists() or not root.is_dir():
        return
    for p in root.rglob("*.md"):
        if p.is_file():
            yield p


def _name_from_path(root: Path, file: Path) -> str:
    rel = file.relative_to(root).with_suffix("")
    parts = rel.parts
    return ":".join(parts)


def _first_description(body: str) -> str:
    for raw in body.splitlines():
        line = raw.strip()
        if not line:
            continue
        # Strip leading `# ` so headings render cleanly in /help.
        if line.startswith("#"):
            line = line.lstrip("#").strip()
        if line.startswith("<!--"):
            continue
        return line[:80]
    return ""


_CACHE: tuple[float, dict[str, CustomCommand]] | None = None
_CACHE_TTL_SECONDS = 2.0


def discover(force_refresh: bool = False) -> dict[str, CustomCommand]:
    """Walk both project and user command dirs.

    Project-local commands shadow user commands of the same name —
    project-overriding behaviour matches opencode + Claude Code.

    Results are cached for ~2 seconds so that the prompt completer
    can call this on every keystroke without hammering the disk.
    """
    import time
    global _CACHE
    now = time.time()
    if not force_refresh and _CACHE is not None:
        ts, cached = _CACHE
        if now - ts < _CACHE_TTL_SECONDS:
            return cached

    found: dict[str, CustomCommand] = {}

    # User first so project entries can overwrite them.
    for root in _user_dirs():
        for file in _walk(root):
            name = _name_from_path(root, file)
            try:
                body = file.read_text(encoding="utf-8")
            except Exception as e:
                logger.debug(f"skipped {file}: {e}")
                continue
            found[name] = CustomCommand(
                name=name, source="user", path=file,
                body=body, description=_first_description(body),
            )

    for root in _project_dirs():
        for file in _walk(root):
            name = _name_from_path(root, file)
            try:
                body = file.read_text(encoding="utf-8")
            except Exception as e:
                logger.debug(f"skipped {file}: {e}")
                continue
            found[name] = CustomCommand(
                name=name, source="project", path=file,
                body=body, description=_first_description(body),
            )

    _CACHE = (now, found)
    return found
