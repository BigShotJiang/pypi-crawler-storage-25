"""Files API — store, reference, and extract content from uploaded files.

Local equivalent of Anthropic's Files API. A file is registered in the
FileStore (copied to `data/files/`), gets a stable `file_id`, and can be
referenced in subsequent `chat()` calls. At LLM call time, the attachment
is materialized:

  - PDFs  → text extraction via pypdf, prepended as a block
  - Text  → read as UTF-8, prepended as a block
  - Images → base64-encoded into a multimodal content block (the model must
             be vision-capable, else the image is represented as a path ref)

The store is intentionally simple — flat directory, JSON manifest. No
multi-tenancy, no TTL, no cleanup job. Delete the file to remove it.
"""

from __future__ import annotations

import base64
import hashlib
import json
import logging
import mimetypes
import shutil
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


# Kinds the store recognizes. Anything else is "binary" and rendered as a
# file-path reference (agents can still `Read` or run tools against it).
KIND_TEXT = "text"
KIND_PDF = "pdf"
KIND_IMAGE = "image"
KIND_AUDIO = "audio"
KIND_BINARY = "binary"


IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"}
TEXT_EXTS = {".txt", ".md", ".py", ".js", ".ts", ".json", ".yaml", ".yml",
             ".toml", ".csv", ".html", ".xml", ".rst", ".log"}
AUDIO_EXTS = {".wav", ".mp3", ".ogg", ".flac", ".m4a"}


def _classify(path: Path) -> str:
    ext = path.suffix.lower()
    if ext == ".pdf":
        return KIND_PDF
    if ext in IMAGE_EXTS:
        return KIND_IMAGE
    if ext in AUDIO_EXTS:
        return KIND_AUDIO
    if ext in TEXT_EXTS:
        return KIND_TEXT
    return KIND_BINARY


class FileRecord(BaseModel):
    id: str
    filename: str
    path: str  # absolute path under FILES_DIR
    kind: str
    mime_type: str = ""
    size_bytes: int = 0
    sha256: str = ""
    created_at: datetime = Field(default_factory=datetime.utcnow)
    metadata: dict[str, Any] = Field(default_factory=dict)


class FileStore:
    """Local file store with stable IDs and a manifest."""

    def __init__(self, root: Path):
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)
        self._manifest_path = self.root / "manifest.json"
        self._records: dict[str, FileRecord] = {}
        self._load()

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------

    def upload(self, source_path: Path, filename: str | None = None) -> FileRecord:
        """Copy a file into the store, return its FileRecord."""
        src = Path(source_path).expanduser().resolve()
        if not src.exists() or not src.is_file():
            raise FileNotFoundError(f"Not a file: {src}")

        name = filename or src.name
        file_id = str(uuid.uuid4())
        dest = self.root / f"{file_id}{src.suffix}"
        shutil.copy2(src, dest)

        data = dest.read_bytes()
        record = FileRecord(
            id=file_id,
            filename=name,
            path=str(dest),
            kind=_classify(dest),
            mime_type=mimetypes.guess_type(src.name)[0] or "application/octet-stream",
            size_bytes=len(data),
            sha256=hashlib.sha256(data).hexdigest(),
        )
        self._records[file_id] = record
        self._save()
        logger.info(f"FileStore upload: {name} ({record.kind}, {record.size_bytes}B) → {file_id}")
        return record

    def get(self, file_id: str) -> FileRecord | None:
        return self._records.get(file_id)

    def delete(self, file_id: str) -> bool:
        rec = self._records.pop(file_id, None)
        if rec is None:
            return False
        Path(rec.path).unlink(missing_ok=True)
        self._save()
        return True

    def list(self) -> list[FileRecord]:
        return sorted(self._records.values(), key=lambda r: r.created_at, reverse=True)

    # ------------------------------------------------------------------
    # Content extraction
    # ------------------------------------------------------------------

    def extract_text(self, file_id: str, max_chars: int = 100_000) -> str:
        """Return the textual content of a file (empty string for images etc.)."""
        rec = self.get(file_id)
        if rec is None:
            return ""
        path = Path(rec.path)

        if rec.kind == KIND_TEXT:
            return path.read_text(errors="ignore")[:max_chars]

        if rec.kind == KIND_PDF:
            try:
                import pypdf
            except ImportError:
                logger.warning("pypdf not installed — PDF extraction unavailable")
                return f"[PDF file at {path} — install pypdf to extract text]"
            try:
                reader = pypdf.PdfReader(str(path))
                pages = [p.extract_text() or "" for p in reader.pages]
                text = "\n\n".join(pages)
                return text[:max_chars]
            except Exception as e:
                logger.warning(f"PDF extraction failed for {path}: {e}")
                return f"[PDF extraction failed: {e}]"

        return ""  # images/audio/binary handled separately

    def to_image_content(self, file_id: str) -> dict[str, Any] | None:
        """Return a multimodal image content block ready for a chat message.

        Shape matches OpenAI/LiteLLM multimodal format; Anthropic receives
        equivalent via LiteLLM translation.
        """
        rec = self.get(file_id)
        if rec is None or rec.kind != KIND_IMAGE:
            return None
        data = Path(rec.path).read_bytes()
        b64 = base64.b64encode(data).decode("ascii")
        return {
            "type": "image_url",
            "image_url": {
                "url": f"data:{rec.mime_type};base64,{b64}",
            },
        }

    # ------------------------------------------------------------------
    # Manifest persistence
    # ------------------------------------------------------------------

    def _load(self) -> None:
        if not self._manifest_path.exists():
            return
        try:
            raw = json.loads(self._manifest_path.read_text())
        except Exception as e:
            logger.warning(f"Failed to load file manifest: {e}")
            return
        for entry in raw.get("files", []):
            try:
                rec = FileRecord.model_validate(entry)
                self._records[rec.id] = rec
            except Exception as e:
                logger.debug(f"Skipping bad manifest entry {entry}: {e}")

    def _save(self) -> None:
        payload = {"files": [r.model_dump(mode="json") for r in self._records.values()]}
        self._manifest_path.write_text(json.dumps(payload, indent=2, default=str))
