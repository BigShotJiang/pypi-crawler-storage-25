"""Usage tracking — token counts and rough cost across an agent session.

`UsageTracker` accumulates per-model token counts (prompt + completion)
and computes cost from a static price table. Local Ollama models are
priced at $0 by default. Cloud models use approximate prices that match
their published rates as of early 2026 — adjust freely; the tracker just
multiplies tokens × $/Mtok.

The tracker is mutable shared state — `LLMProvider` calls `record()` on
every successful response, so any consumer (status line, /cost slash
command, end-of-session report) sees the live total.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


# Price per 1M tokens, USD. Best-effort, intentionally conservative.
# Anything not listed defaults to 0 (treated as local/free).
DEFAULT_PRICES: dict[str, tuple[float, float]] = {
    # Anthropic
    "anthropic/claude-opus-4-7":      (15.0, 75.0),
    "anthropic/claude-sonnet-4-6":    (3.0, 15.0),
    "anthropic/claude-haiku-4-5":     (0.80, 4.0),
    "claude-opus-4-7":                (15.0, 75.0),
    "claude-sonnet-4-6":              (3.0, 15.0),
    "claude-haiku-4-5":               (0.80, 4.0),
    # OpenAI rough rates
    "openai/gpt-4o":                  (2.5, 10.0),
    "openai/gpt-4o-mini":             (0.15, 0.6),
    "gpt-4o":                         (2.5, 10.0),
    "gpt-4o-mini":                    (0.15, 0.6),
}


@dataclass
class ModelUsage:
    prompt_tokens: int = 0
    completion_tokens: int = 0
    requests: int = 0

    @property
    def total_tokens(self) -> int:
        return self.prompt_tokens + self.completion_tokens


@dataclass
class UsageTracker:
    """Accumulates usage across a session."""

    by_model: dict[str, ModelUsage] = field(default_factory=dict)
    prices: dict[str, tuple[float, float]] = field(
        default_factory=lambda: dict(DEFAULT_PRICES),
    )

    def record(self, model: str, usage: dict[str, Any]) -> None:
        """Record a single LLM call.

        `usage` is the dict shape LLMProvider returns: {prompt_tokens,
        completion_tokens, total_tokens}. Missing keys are treated as 0.
        """
        slot = self.by_model.setdefault(model, ModelUsage())
        slot.prompt_tokens += int(usage.get("prompt_tokens") or 0)
        slot.completion_tokens += int(usage.get("completion_tokens") or 0)
        slot.requests += 1

    def total_tokens(self) -> int:
        return sum(u.total_tokens for u in self.by_model.values())

    def total_cost(self) -> float:
        total = 0.0
        for model, u in self.by_model.items():
            in_price, out_price = self.prices.get(model, (0.0, 0.0))
            total += (u.prompt_tokens / 1_000_000) * in_price
            total += (u.completion_tokens / 1_000_000) * out_price
        return total

    def report(self) -> dict[str, Any]:
        return {
            "total_tokens": self.total_tokens(),
            "total_cost_usd": round(self.total_cost(), 6),
            "by_model": {
                m: {
                    "prompt_tokens": u.prompt_tokens,
                    "completion_tokens": u.completion_tokens,
                    "requests": u.requests,
                }
                for m, u in self.by_model.items()
            },
        }


# Process-wide tracker. Shared by LLMProvider so any agent in the process
# accumulates into the same totals. Tests can replace this if isolation
# matters.
_GLOBAL = UsageTracker()


def get_global_tracker() -> UsageTracker:
    return _GLOBAL


def reset_global_tracker() -> None:
    _GLOBAL.by_model.clear()
