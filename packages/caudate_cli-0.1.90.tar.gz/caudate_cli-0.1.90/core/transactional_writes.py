"""Transactional Write batches (Phase 3.4) — git-stash safety net.

When `transactional_writes` is enabled, the agent's first buildable
Write of a turn triggers `git stash push -u` to snapshot the current
working tree to a recovery point. If the user later realises the
agent's changes broke something, `/rollback` restores the pre-turn
state.

Design choices:
- **Off by default** (`transactional_writes: false`). Opt-in via
  `~/.caudate/settings.json` because stashing has side effects and
  surprises power users who manage their own git state.
- **Stash is keyed per-turn** via a unique label so we can find +
  pop it explicitly, even if the user did other stashes in the
  meantime.
- **Rollback is user-triggered**, not automatic. Never silently
  undoes work — the user types `/rollback`.
- **Successful-turn cleanup**: when a turn ends without rollback,
  the stash is dropped so it doesn't accumulate.
- **Best-effort everywhere**: git not installed, not in a git
  repo, dirty index → silent skip, never crash the loop.

Cross-link with Phase 3.3: if the verifier fails and the user wants
to abandon the turn's changes, they type `/rollback` immediately.
The verifier feedback's "[verifier] FAIL" message is the trigger.
"""

from __future__ import annotations

import logging
import subprocess
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)


STASH_LABEL_PREFIX = "caudate-tx-"


@dataclass
class TurnTransaction:
    """State of one turn's transactional checkpoint."""

    cwd: str
    label: str                              # the stash message we'll grep for
    created_at: float = field(default_factory=time.time)
    stashed: bool = False                   # did we actually create a stash?
    rolled_back: bool = False               # did the user rollback?
    files_touched: list[str] = field(default_factory=list)

    def short_label(self) -> str:
        return self.label[len(STASH_LABEL_PREFIX):][:8]


def _git_available() -> bool:
    """True if `git` is on PATH."""
    try:
        r = subprocess.run(
            ["git", "--version"], capture_output=True, timeout=2.0,
        )
        return r.returncode == 0
    except Exception:
        return False


def _in_git_repo(cwd: str | Path) -> bool:
    """True if cwd is inside a git work tree."""
    try:
        r = subprocess.run(
            ["git", "-C", str(cwd), "rev-parse", "--is-inside-work-tree"],
            capture_output=True, text=True, timeout=3.0,
        )
        return r.returncode == 0 and (r.stdout or "").strip() == "true"
    except Exception:
        return False


def _is_enabled() -> bool:
    """Read settings.json. Default: off."""
    try:
        from core.settings import Settings
        return bool(Settings.load().get("transactional_writes", False))
    except Exception:
        return False


def start_turn(cwd: str | Path) -> TurnTransaction | None:
    """Build a transaction handle for this turn.

    Returns None if:
      - feature disabled
      - git missing
      - not in a git repo

    The stash itself isn't created here — that happens lazily on
    the first buildable Write via `stash_if_needed()`.
    """
    if not _is_enabled():
        return None
    if not _git_available():
        return None
    if not _in_git_repo(cwd):
        return None
    label = f"{STASH_LABEL_PREFIX}{uuid.uuid4().hex[:12]}"
    return TurnTransaction(cwd=str(cwd), label=label)


def stash_if_needed(tx: TurnTransaction | None, file_path: str = "") -> bool:
    """Create the stash if we haven't already this turn.

    Returns True on success (stash exists for this turn), False on
    skip / error. Records `file_path` in the turn's touched list."""
    if tx is None:
        return False
    if file_path:
        tx.files_touched.append(file_path)
    if tx.stashed:
        return True   # already stashed; nothing more to do

    try:
        # Check whether there's anything to stash — if the tree is
        # already clean, skip (nothing to roll back from).
        r = subprocess.run(
            ["git", "-C", tx.cwd, "status", "--porcelain"],
            capture_output=True, text=True, timeout=5.0,
        )
        has_changes = bool((r.stdout or "").strip())
        if not has_changes:
            # Empty stash is harmless but pointless; still set
            # stashed=True so we don't re-check every Write.
            tx.stashed = True
            return False
        r = subprocess.run(
            ["git", "-C", tx.cwd, "stash", "push", "-u", "-m", tx.label],
            capture_output=True, text=True, timeout=10.0,
        )
        if r.returncode != 0:
            logger.debug(f"transactional stash failed: {r.stderr[:200]}")
            return False
        tx.stashed = True
        logger.info(
            f"transactional stash created (label={tx.short_label()}); "
            f"/rollback restores pre-turn state"
        )
        return True
    except Exception as e:
        logger.debug(f"stash_if_needed crashed: {e}")
        return False


def commit_turn(tx: TurnTransaction | None) -> bool:
    """Drop the stash — turn ended successfully, no rollback needed.

    Returns True if cleanup happened, False otherwise. Safe to call
    when no stash was created (tx is None or tx.stashed False)."""
    if tx is None or not tx.stashed or tx.rolled_back:
        return False
    # Find the stash by label and drop it
    try:
        ref = _find_stash_ref(tx.cwd, tx.label)
        if ref is None:
            return False
        r = subprocess.run(
            ["git", "-C", tx.cwd, "stash", "drop", ref],
            capture_output=True, text=True, timeout=5.0,
        )
        if r.returncode != 0:
            logger.debug(f"stash drop failed: {r.stderr[:200]}")
            return False
        logger.debug(f"transactional stash dropped (label={tx.short_label()})")
        return True
    except Exception as e:
        logger.debug(f"commit_turn crashed: {e}")
        return False


def rollback(tx: TurnTransaction | None) -> tuple[bool, str]:
    """Restore the pre-turn state.

    Strategy:
      1. `git reset --hard HEAD` — discard all current changes
      2. Remove untracked files written during this turn (specifically
         the ones we recorded in `files_touched`, NOT a blanket clean)
      3. `git stash pop <ref>` — restore the pre-turn state we saved

    Returns (success, message).
    """
    if tx is None:
        return False, "no active transaction"
    if not tx.stashed:
        return False, "no stash to restore (transaction never wrote)"
    if tx.rolled_back:
        return False, "already rolled back"

    try:
        ref = _find_stash_ref(tx.cwd, tx.label)
        if ref is None:
            return False, f"stash {tx.short_label()} not found (was it dropped manually?)"

        # Step 1: discard current changes
        r = subprocess.run(
            ["git", "-C", tx.cwd, "reset", "--hard", "HEAD"],
            capture_output=True, text=True, timeout=10.0,
        )
        if r.returncode != 0:
            return False, f"git reset failed: {r.stderr[:200]}"

        # Step 2: remove the agent's untracked file additions explicitly.
        # We only delete files the agent recorded touching — safer than
        # a blanket `git clean -fd` which could nuke unrelated work.
        from pathlib import Path as _P
        cleaned = 0
        for path in tx.files_touched:
            try:
                p = _P(path)
                if not p.is_absolute():
                    p = _P(tx.cwd) / p
                if p.exists() and p.is_file():
                    # Only remove if NOT tracked by git (untracked = agent-created)
                    chk = subprocess.run(
                        ["git", "-C", tx.cwd, "ls-files", "--error-unmatch", str(p)],
                        capture_output=True, text=True, timeout=3.0,
                    )
                    if chk.returncode != 0:
                        p.unlink()
                        cleaned += 1
            except Exception:
                continue

        # Step 3: pop the stash
        r = subprocess.run(
            ["git", "-C", tx.cwd, "stash", "pop", ref],
            capture_output=True, text=True, timeout=10.0,
        )
        if r.returncode != 0:
            # Stash conflict — leave it for the user to resolve manually
            return False, (
                f"git stash pop conflicted ({r.stderr[:120]}); "
                f"stash is still at {ref}, resolve manually with "
                f"`git stash list` + `git stash pop {ref}`"
            )

        tx.rolled_back = True
        return True, (
            f"rolled back to pre-turn state. "
            f"Removed {cleaned} agent-created file(s); "
            f"restored {len(tx.files_touched)} touched path(s)."
        )
    except Exception as e:
        logger.debug(f"rollback crashed: {e}")
        return False, f"rollback crashed: {e}"


def _find_stash_ref(cwd: str, label: str) -> str | None:
    """Find `stash@{N}` whose message matches our label."""
    try:
        r = subprocess.run(
            ["git", "-C", cwd, "stash", "list"],
            capture_output=True, text=True, timeout=5.0,
        )
        if r.returncode != 0:
            return None
        for line in (r.stdout or "").splitlines():
            # Format: stash@{N}: On <branch>: <message>
            if label in line:
                ref, _, _ = line.partition(":")
                return ref.strip()
    except Exception:
        pass
    return None
