"""Hooks system — event-driven extensibility for the agentic loop.

Events are fired at key points in the loop (see HookEvent). Each event can
have zero or more handlers. Handlers are either Python callables or shell
commands loaded from a JSON config file.

Handler signature: async def handler(event: str, payload: dict) -> dict | None
  - Return a dict with "block": True to short-circuit (e.g. PRE_TOOL_USE)
  - Return a dict with "modified_args": {...} to mutate tool args (PRE_TOOL_USE)
  - Return None for pure side-effect handlers (logging, audit, etc.)

Shell-command handlers receive the payload via stdin as JSON and may emit
the same response dict as JSON on stdout.
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
from enum import Enum
from pathlib import Path
from typing import Any, Awaitable, Callable

logger = logging.getLogger(__name__)


class HookEvent(str, Enum):
    PRE_TOOL_USE = "pre_tool_use"
    POST_TOOL_USE = "post_tool_use"
    POST_TOOL_USE_FAILURE = "post_tool_use_failure"
    USER_PROMPT_SUBMIT = "user_prompt_submit"
    STOP = "stop"
    SUBAGENT_START = "subagent_start"
    SUBAGENT_STOP = "subagent_stop"
    PRE_COMPACT = "pre_compact"
    NOTIFICATION = "notification"


HookHandler = Callable[[str, dict[str, Any]], Awaitable[dict[str, Any] | None] | dict[str, Any] | None]


class HookMatcher:
    """A matcher selects which tool/payloads a handler fires on."""

    def __init__(
        self,
        tool: str | None = None,
        pattern: str | None = None,
    ):
        self.tool = tool
        self.pattern = re.compile(pattern) if pattern else None

    def matches(self, payload: dict[str, Any]) -> bool:
        if self.tool:
            tool = payload.get("tool") or payload.get("tool_name")
            if tool != self.tool and self.tool != "*":
                return False
        if self.pattern:
            try:
                serialized = json.dumps(payload, ensure_ascii=False, default=str)
            except Exception:
                serialized = str(payload)
            return bool(self.pattern.search(serialized))
        return True


class HookManager:
    """Registers and dispatches hook handlers."""

    def __init__(self):
        self._handlers: dict[HookEvent, list[tuple[HookMatcher, HookHandler]]] = {
            e: [] for e in HookEvent
        }

    def register(
        self,
        event: HookEvent,
        handler: HookHandler,
        matcher: HookMatcher | None = None,
    ) -> None:
        """Register a handler for an event."""
        self._handlers[event].append((matcher or HookMatcher(), handler))

    def register_shell(
        self,
        event: HookEvent,
        command: str,
        matcher: HookMatcher | None = None,
    ) -> None:
        """Register a shell command as a hook handler."""
        async def _shell_handler(evt: str, payload: dict[str, Any]):
            return await _run_shell_hook(command, evt, payload)

        self.register(event, _shell_handler, matcher)

    async def emit(self, event: HookEvent, payload: dict[str, Any]) -> dict[str, Any]:
        """Fire all handlers for an event. Returns the aggregated response dict.

        If any handler returns {"block": True}, subsequent handlers still run
        (for audit), but the combined response will preserve block=True.
        If any handler returns {"modified_args": ...}, the latest such value
        wins (later handlers override earlier ones).
        """
        combined: dict[str, Any] = {}
        for matcher, handler in self._handlers.get(event, []):
            if not matcher.matches(payload):
                continue
            try:
                result = handler(event.value, payload)
                if asyncio.iscoroutine(result):
                    result = await result
            except Exception as e:
                logger.warning(f"Hook {event.value} handler failed: {e}")
                continue
            if isinstance(result, dict):
                if result.get("block"):
                    combined["block"] = True
                    if "reason" in result:
                        combined["reason"] = result["reason"]
                if "modified_args" in result:
                    combined["modified_args"] = result["modified_args"]
        return combined

    # ------------------------------------------------------------------
    # Config loading
    # ------------------------------------------------------------------

    def load_from_file(self, path: Path) -> int:
        """Load hook definitions from a JSON config file. Returns count loaded.

        Format:
        {
          "hooks": [
            {
              "event": "pre_tool_use",
              "command": "/path/to/script.sh",
              "matcher": {"tool": "Bash", "pattern": "rm "}
            }
          ]
        }
        """
        if not path.exists():
            return 0
        try:
            data = json.loads(path.read_text())
        except Exception as e:
            logger.warning(f"Failed to load hooks from {path}: {e}")
            return 0

        count = 0
        for h in data.get("hooks", []):
            try:
                event = HookEvent(h["event"])
            except (KeyError, ValueError):
                logger.warning(f"Invalid hook event: {h.get('event')}")
                continue
            matcher_cfg = h.get("matcher") or {}
            matcher = HookMatcher(
                tool=matcher_cfg.get("tool"),
                pattern=matcher_cfg.get("pattern"),
            )
            if "command" in h:
                self.register_shell(event, h["command"], matcher)
                count += 1
            # Python-callable hooks can't be declared in JSON; would require
            # an import path. For now, only shell hooks are supported via file.
        return count


async def _run_shell_hook(
    command: str,
    event: str,
    payload: dict[str, Any],
) -> dict[str, Any] | None:
    """Run a shell hook, piping the payload as JSON on stdin."""
    try:
        payload_json = json.dumps({"event": event, **payload}, default=str)
    except Exception:
        payload_json = json.dumps({"event": event})

    try:
        proc = await asyncio.create_subprocess_shell(
            command,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await asyncio.wait_for(
            proc.communicate(payload_json.encode()),
            timeout=30,
        )
    except Exception as e:
        logger.warning(f"Shell hook {command!r} failed: {e}")
        return None

    if proc.returncode != 0:
        logger.debug(f"Shell hook {command!r} exit={proc.returncode}: {stderr.decode(errors='ignore')[:200]}")
        return None

    out = stdout.decode(errors="ignore").strip()
    if not out:
        return None
    try:
        return json.loads(out)
    except json.JSONDecodeError:
        logger.debug(f"Shell hook {command!r} returned non-JSON output")
        return None
