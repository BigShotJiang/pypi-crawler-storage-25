"""Sandbox-awareness system prompt injection.

Both API endpoints (`/v1/chat/completions` for Open WebUI and
`/v1/messages` for Claude Code CLI) call `inject_sandbox_hint` on
their internal-shape message list. The helper appends a short hint
to an existing system message, or prepends a new system message if
none exists, telling the LLM to scaffold new files into
`/home/raveuk/cognos/sandbox/` by default.

Single source of truth so the chat and CLI paths stay consistent.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

# Resolve once at import — repository-relative so it follows the user's
# checkout. Kept for the optional sandbox workspace_mode (see below).
SANDBOX_DIR = (Path(__file__).resolve().parent.parent / "sandbox").resolve()


def _cwd_hint() -> str:
    """Workspace section for the default cwd-based mode (Claude Code parity).

    Resolved at injection time, not import time, so the directive
    reflects the directory caudate was launched from on this turn.
    """
    cwd = Path.cwd().resolve()
    return f"""- **Read access is unrestricted.** Use `Read`, `Grep`, `Glob`,
  `FindAnywhere`, and read-only `Bash` (`ls`, `cat`, `df`, `nvidia-smi`,
  `free`, `uname`, `ps`, `git status`, etc.) anywhere on the system
  the user has access to. If they ask "what GPU do you have?" or
  "what's in /etc/hosts?" — just look. The `SystemInfo` tool gives
  you a one-call summary (CPU/RAM/GPU/disk/Python/CUDA).

- **The workspace is exactly `{cwd}`.** This is the directory the
  user launched caudate in. Treat it as the project root, the same
  way Claude Code + opencode do. When the user says "create",
  "build", "make", "write", "scaffold", or "save" something without
  specifying a path:
    - Write directly INTO `{cwd}/`.
    - You may create sub-directories under it (e.g.
      `{cwd}/app/`, `{cwd}/src/`, `{cwd}/templates/`).
    - **DO NOT create a sibling folder next to the cwd.** If the
      cwd is `{cwd}`, never write to `{cwd.parent}/some_other_name/`.
    - **Spaces in the cwd name are fine** — quote the path
      (`"like this/"`) or escape spaces (`like\\ this/`) when
      passing to `Bash`. Do NOT silently rewrite a spaced name
      into an underscore variant.

- **Forbidden default paths.** Never write into any of these unless
  the user explicitly names the path in their message:
    - `~/cognos/sandbox/` or any subdirectory thereof
    - `/tmp/`, `/var/tmp/`, `/dev/shm/`
    - The caudate install directory (`~/.local/lib/`, `~/.caudate/`)
  These were legacy staging locations and the user can no longer
  see what lands there. The cwd is the only sanctioned write target.

- **Do not probe `~/cognos/sandbox/projects/` "just in case."**
  It's not a project registry. Skip it unless the user references
  it explicitly. Look for existing work under the cwd first
  (`ls`, `Glob('**/*')`), then ask the user if uncertain.

- **Writes outside the cwd** are allowed only when the user
  explicitly references those files (e.g. "edit my .bashrc", "fix
  the bug in /etc/nginx/nginx.conf"). Don't reach outside the cwd
  for tidiness reasons."""


def _sandbox_hint() -> str:
    """Workspace section for the legacy sandbox-first mode.

    Selected by setting `workspace_mode = "sandbox"` in
    `~/.caudate/settings.json`. Kept so users who built their
    workflow around the sandbox can opt back in.
    """
    return f"""- **Read access is unrestricted.** Use `Read`, `Grep`, `Glob`,
  `FindAnywhere`, and read-only `Bash` (`ls`, `cat`, `df`, `nvidia-smi`,
  `free`, `uname`, `ps`, `git status`, etc.) anywhere on the system
  the user has access to.
- **Writes default to the sandbox.** When the user asks you to
  *create*, *build*, *make*, *write*, or *scaffold* something new
  and doesn't specify a path, write into:
    - `{SANDBOX_DIR}/projects/<name>/`  for multi-file apps
    - `{SANDBOX_DIR}/scripts/`           for one-off scripts/helpers
    - `{SANDBOX_DIR}/notes/`             for plain-text notes
  The sandbox is its own 50GB filesystem (loopback ext4) — fill it
  freely. Treat it as scratch space.
- **Writes outside the sandbox** are allowed when the user explicitly
  references those files. Don't write outside the sandbox just because
  it would be tidier; only when asked."""


def _workspace_section() -> str:
    """Pick the workspace block based on settings.

    Default mode is `cwd` (matches Claude Code + opencode). Users who
    want the legacy behavior can set `workspace_mode = "sandbox"` in
    their settings file.
    """
    mode = "cwd"
    try:
        from core.settings import Settings
        mode = (Settings.load().get("workspace_mode") or "cwd").lower()
    except Exception:
        pass
    if mode == "sandbox":
        return _sandbox_hint()
    return _cwd_hint()


SANDBOX_HINT_HEAD = """## System access and workspace conventions

You are running on the user's own machine and have full inspection
access to it. Use the tools you have:

### Questions about your own internals

When the user asks where your system prompt lives, what your
configuration is, "which file is it", "what's in your prompt", or
anything about your own runtime composition — **call `CognosCard`
first** (try `CognosCard(section="architecture")` for the file list).
**Do NOT** run `find` / `grep` / `Bash` to hunt for "the system prompt
file" — there isn't one single file. The system prompt is composed
at runtime from several sources, all listed in the Cognos card. If
`CognosCard` doesn't have what you need, read `data/COGNOS_CARD.md`
directly with `Read`. After two attempts, if you still don't have an
answer, surface the question to the user — don't keep searching.

"""

SANDBOX_HINT_TAIL = ""


_PLAN_MODE_BLOCK = """

### Plan mode — IMPORTANT

You are currently in **plan mode**. Mutating tools (Bash with writes,
Write, Edit, etc.) are blocked. Your job in this state:

1. **Gather context.** Use read-only tools (Read, Grep, Glob, Bash
   for `ls`/`cat`/`git status`/etc.) to understand the codebase and
   what the user is asking for.
2. **Build a complete plan.** Write a markdown document with these
   sections:
   - `## Overview` — one short paragraph on what you'll build/change
   - `## Files` — bulleted list of every file you'll create or modify,
     with a one-line purpose each
   - `## Steps` — numbered ordered list of the implementation steps
   - `## Verification` — how the user can test the result
3. **Call `ExitPlanMode(plan="...")`** passing the markdown plan as
   the `plan` argument. The user sees the plan in a bordered panel
   and approves or rejects.
4. If approved → plan mode turns off and you can execute the steps.
   If rejected → refine the plan based on the feedback the tool
   returns and call `ExitPlanMode` again with the new version.

**Do NOT attempt any mutating tool calls in plan mode** — they'll be
refused. Plan, present, then act."""


_RUN_AND_VERIFY_BLOCK = """

### Build completion — IMPORTANT, end-of-turn checklist

Writing one file is **not the same as shipping a working app**. When
the user asks you to *build* / *create* / *scaffold* a runnable thing
(a Flask app, an HTTP server, a CLI, a script), you must follow
through to **all referenced files + launching + verifying**. Matches
Claude Code + opencode behavior. "How to use it" docs at the end are
not a delivery.

#### Rule 1 — Complete every TodoWrite item before ending the turn

If the most recent `TodoWrite` call shows items in `pending` or
`in_progress` status, **the turn is not done**. Keep calling tools
until every item is `completed`. Don't emit a final assistant text
("Here's how to use it…") with todos still open — that's a stop
short. Bigger models grind through; you must too.

#### Rule 2 — Verify referenced files exist

Code you write often references other files:
- `render_template("index.html")` requires `templates/index.html`
- `<link href="/static/style.css">` requires `static/style.css`
- `from utils import foo` requires `utils.py`
- `<script src="app.js">` requires the JS file

**Before declaring the build complete**, mentally walk through your
written code and confirm every referenced file you'd need at runtime
has been Write'n. If `app.py` calls `render_template("index.html")`
and you have NOT written `templates/index.html`, that's a broken
build — do not stop until you've Write'n it.

#### Rule 3 — Install, launch, verify, AND smoke-test the response

After all files are written:

1. **Install missing deps** — `Bash(command="pip install ...")`,
   `npm install`, `cargo build`, etc. Skip if already installed.
2. **Start in background** — `Bash(command='cd "/path" && python app.py',
   run_in_background=true, timeout=5)`. Note the returned `pid` +
   `log file` so you can read the log if step 3 fails.
3. **Verify it's listening** — `Bash(command='sleep 1 && curl -sS
   -o /dev/null -w "%{http_code}" http://127.0.0.1:<port>/')`. A
   `200/302/304` confirms the server is up. On connection-refused,
   read the log file from step 2.
4. **Smoke-test the response.** A 200 on `/` isn't enough — broken
   HTML still returns 200. Do the following:
   a. `curl -s http://127.0.0.1:<port>/ > /tmp/_page.html` — fetch
      the actual page.
   b. **Extract every static asset referenced in the HTML** —
      `grep -oE 'src="[^"]+"|href="[^"]+"' /tmp/_page.html` will
      list all of them.
   c. **For every internal `static/...` reference**, curl it and
      confirm 200. Example pipeline:
          `for u in $(grep -oE '/static/[^"]+' /tmp/_page.html); do
              code=$(curl -sS -o /dev/null -w '%{http_code}' http://127.0.0.1:<port>$u);
              echo "$code $u";
           done`
      Any non-200 means the HTML references a file that doesn't
      exist at that path. **Fix it before declaring done** — either
      move the file, or update the HTML reference. This catches
      the classic subdir/path mismatch where a `<script src="x.js">`
      was written to `static/js/x.js` (or similar) and the browser
      silently 404s, killing all interactivity.
   d. **Test one real API endpoint** if the app has them — e.g.
      `curl -s http://127.0.0.1:<port>/api/search?q=test` and
      confirm a sane JSON response, not a 500 or empty body.
5. **Report the URL** the user can click. Include any test creds,
   admin paths, etc.

For libraries / modules without a runnable entry point, you can skip
the launch — but still verify by `python -c "import yourmodule"` or
running its tests.

**Never** end a "build me X" turn while:
- Any TodoWrite item is still pending or in-progress
- A file your written code references doesn't exist on disk
- The server hasn't been launched + verified
- Any `<script>` or `<link>` in the rendered HTML returns 404
- The main API endpoint returns 500 / empty / wrong shape"""


def _plan_mode_active() -> bool:
    """True if plan mode is on via either the in-process flag or the
    permission_mode setting."""
    try:
        from core.plan_mode import is_active
        if is_active():
            return True
    except Exception:
        pass
    try:
        from core.settings import Settings
        mode = (Settings.load().get("permission_mode") or "default").lower()
        if mode == "plan":
            return True
    except Exception:
        pass
    return False


def _build_workspace_hint() -> str:
    plan_block = _PLAN_MODE_BLOCK if _plan_mode_active() else ""
    # Run-and-verify is always present in non-plan turns — plan mode
    # already covers the workflow shape, so we don't duplicate it there.
    run_block = "" if _plan_mode_active() else _RUN_AND_VERIFY_BLOCK
    return f"""{SANDBOX_HINT_HEAD}
{_workspace_section()}{plan_block}{run_block}{SANDBOX_HINT_TAIL}"""


# Backward-compat alias: legacy code reads SANDBOX_HINT at import time.
# We build it lazily through a module-level __getattr__ so the cwd
# captured in the hint reflects the cwd at the time of injection, not
# at import.
def __getattr__(name: str):
    if name == "SANDBOX_HINT":
        return _build_workspace_hint() + _IMAGES_RULES
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


_IMAGES_RULES = """

### Uploaded images / files — **READ THIS, IT IS NOT A SUGGESTION**

When the user attaches an image (or any file) in the chat, the API
auto-saves it to the FileStore (`/home/raveuk/cognos/data/files/`)
and injects a marker into the user message:

    [uploaded image: files/<id>]

**`files/<id>` is a fully accessible local-filesystem reference.**
It is NOT cloud storage, NOT chat-only, NOT a placeholder. Every
local Cognos tool can read it. The image already exists on disk at
`/home/raveuk/cognos/data/files/<id>.<ext>` — it was saved before
you saw the message.

**ABSOLUTE RULES — no exceptions, no "but maybe":**

1. If you see `[uploaded image: files/<id>]` in the user's message,
   **ALWAYS pass that string directly to EditImage / DescribeImage**.
   No path conversion, no path lookup, no "save it first" — just use
   the handle as-is.
2. **NEVER tell the user "save it to a local path"** or "the upload
   isn't reaching my tool" or "it's in chat cloud storage". These
   statements are false. The file IS local. Saying any of them is a
   bug — if you find yourself about to type one, STOP and call the
   tool with the file handle instead.
3. **NEVER preface or follow a successful tool result with disclaimers
   like "if this isn't your photo…"**. If EditImage returned a
   markdown image link, the edit happened. Trust the tool. Show the
   result without second-guessing.
4. If the tool returns an actual error (status=error), surface that
   exact error to the user. Do NOT substitute it with a fabricated
   "save to a path" explanation.
"""


def inject_sandbox_hint(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Return a new messages list with the sandbox hint applied.

    Also folds in the durable memory.md contents so the LLM has access
    to cross-session context every turn.

    - Appends to an existing leading system message
    - Otherwise prepends a fresh system message
    - Idempotent: if the hint marker is already present, returns input
      unchanged so multi-turn calls don't accumulate copies.
    """
    marker = "## System access and workspace conventions"

    # Pull the durable memory file (empty string if no entries yet)
    memory_block = ""
    try:
        from core.memory_md import get_memory
        memory_block = get_memory().render_for_system_prompt()
    except Exception:
        pass

    # Pull installed-skills TOC + auto-activate any skills whose
    # name/description overlaps the user's prompt. The TOC keeps the
    # LLM aware of all installed skills; the auto-activated FULL bodies
    # live below so the LLM doesn't have to round-trip via LoadSkill
    # when a skill is obviously relevant.
    skills_toc = ""
    skills_active = ""
    try:
        from core.skills import get_skills
        registry = get_skills()
        skills_toc = registry.render_toc()
        # Find the most-recent user message to score skills against
        latest_user = ""
        for m in reversed(messages or []):
            if m.get("role") == "user":
                c = m.get("content", "")
                if isinstance(c, list):
                    c = " ".join(b.get("text", "") for b in c
                                 if isinstance(b, dict))
                latest_user = c or ""
                break
        if latest_user:
            skills_active = registry.render_active_skills(latest_user, top_k=2)
    except Exception:
        pass

    # Cognos self-spec card reference — short pointer + reminder that
    # the LLM should call `CognosCard` when it's unsure about Cognos's
    # capabilities or boundaries.
    cognos_card_block = ""
    try:
        from execution.tools.cognos_card_tool import render_cognos_card_short
        cognos_card_block = render_cognos_card_short()
    except Exception:
        pass

    # Phase 1.8 — strategy library recall. Find the most recent
    # user message and look up similar past successful turn traces.
    # The model gets a "Past experience" block as concrete examples
    # of what worked on similar prompts before. No-op if the library
    # is empty / chromadb unavailable.
    strategy_block = ""
    try:
        latest_user = ""
        for m in reversed(messages or []):
            if m.get("role") == "user":
                c = m.get("content", "")
                if isinstance(c, list):
                    c = " ".join(
                        b.get("text", "") for b in c
                        if isinstance(b, dict)
                    )
                latest_user = (c or "").strip()
                break
        if latest_user:
            from memory.strategies import recall_for_prompt
            traces = recall_for_prompt(latest_user, k=3)
            if traces:
                lines = ["### Past experience — similar tasks that worked"]
                lines.append(
                    "Use these as inspiration for tool sequencing; you can "
                    "deviate when the request differs."
                )
                lines.append("")
                for t in traces:
                    lines.append(f"  • {t.one_liner()}")
                strategy_block = "\n".join(lines)
    except Exception:
        pass

    full_hint = _build_workspace_hint() + _IMAGES_RULES
    if cognos_card_block:
        full_hint = f"{full_hint}\n\n{cognos_card_block}"
    if skills_toc:
        full_hint = f"{full_hint}\n\n{skills_toc}"
    if skills_active:
        full_hint = f"{full_hint}\n\n{skills_active}"
    if strategy_block:
        full_hint = f"{full_hint}\n\n{strategy_block}"
    if memory_block:
        full_hint = f"{full_hint}\n\n{memory_block}"

    if not messages:
        return [{"role": "system", "content": full_hint}]

    # Already applied? leave alone (chat clients replay the system msg
    # on every turn; we don't want N copies after N turns). The memory
    # block lives next to the marker so re-injecting it is also gated
    # by the same idempotency check.
    if messages and messages[0].get("role") == "system":
        head = messages[0].get("content", "")
        if isinstance(head, list):
            head_text = " ".join(
                b.get("text", "") for b in head if isinstance(b, dict)
            )
        else:
            head_text = head or ""
        if marker in head_text:
            return messages
        out = list(messages)
        out[0] = {"role": "system", "content": f"{head_text}\n\n{full_hint}"}
        return out

    # No system message — prepend one
    return [{"role": "system", "content": full_hint}, *messages]
