"""Outcome signals for Caudate's learning loop (Phase 1.1).

Each agent turn produces an `OutcomeSignals` record that captures
both auto-detected indicators (did Bash fail, did Verify pass, did
the model loop on TodoWrite) and explicit user feedback (/feedback
good|bad). The signals are composed into a single scalar
`outcome_reward ∈ [-1, +1]` that downstream Phase 1 steps consume:

  - 1.2 wires `outcome_reward` into the Caudate replay buffer
  - 1.3 uses it to weight the per-sample training loss
  - 1.4 trains the value head to predict P(success)

The design favors **conservative signals** over speculative ones.
A turn that erred should have negative reward; a turn the user
praised should have positive reward; turns that just "happened"
default to neutral (None / 0.0) so they don't dilute the signal.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Iterable

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------
# Signal weights — tunable. Each value contributes a delta to the
# final reward in [-1, +1]. Defaults bias toward "ambiguous / neutral"
# unless multiple signals agree.
# ---------------------------------------------------------------------

# Auto signals — observed by the agent loop / Verifier
_W_VERIFY_PASSED = 0.40           # Run-and-verify succeeded → +0.4
_W_VERIFY_FAILED = -0.30          # explicit verify failure → -0.3
_W_TOOL_ERROR_EACH = -0.10        # each failed tool result up to a cap
_W_TOOL_ERROR_CAP = -0.40         # max accumulated penalty from errors
_W_REPLAN_LOOP_EACH = -0.10       # each consecutive TodoWrite-only iter
_W_REPLAN_LOOP_CAP = -0.30        # cap on replan-loop penalty
_W_HIT_MAX_ITER = -0.40           # blown past max_iterations
_W_STATIC_404_EACH = -0.15        # per 404 in rendered HTML
_W_STATIC_404_CAP = -0.40
_W_TURN_ABORTED_BY_USER = -0.20   # user picked "No" on a permission prompt

# Explicit signals — user-supplied via /feedback
_W_EXPLICIT_FEEDBACK = 0.60       # multiplier on /feedback +1/-1


@dataclass
class OutcomeSignals:
    """Per-turn signals. All fields default to "neutral" — only set
    them when the corresponding event actually fires."""

    # Auto signals
    verify_passed: bool | None = None       # True/False/None (verify not run)
    tool_errors: int = 0                    # count of failed tool results
    replan_loops: int = 0                   # consecutive TodoWrites with no Write/Bash
    hit_max_iterations: bool = False
    static_assets_404: int = 0              # set by Verifier (Phase 3)
    turn_aborted_by_user: bool = False

    # Explicit signals
    explicit_feedback: int = 0              # -1, 0, +1
    explicit_reason: str = ""

    # Derived metadata (useful for debugging the reward)
    contributions: list[tuple[str, float]] = field(default_factory=list, repr=False)

    def reward(self) -> float:
        """Compose signals into a single scalar in [-1, +1].

        Records each non-zero contribution so callers can inspect why
        the reward landed where it did (handy for debugging the
        learning loop)."""
        self.contributions = []
        r = 0.0

        if self.verify_passed is True:
            r += _W_VERIFY_PASSED
            self.contributions.append(("verify_passed", _W_VERIFY_PASSED))
        elif self.verify_passed is False:
            r += _W_VERIFY_FAILED
            self.contributions.append(("verify_failed", _W_VERIFY_FAILED))

        if self.tool_errors > 0:
            delta = max(_W_TOOL_ERROR_CAP, _W_TOOL_ERROR_EACH * self.tool_errors)
            r += delta
            self.contributions.append((f"tool_errors={self.tool_errors}", delta))

        if self.replan_loops > 0:
            delta = max(_W_REPLAN_LOOP_CAP, _W_REPLAN_LOOP_EACH * self.replan_loops)
            r += delta
            self.contributions.append((f"replan_loops={self.replan_loops}", delta))

        if self.hit_max_iterations:
            r += _W_HIT_MAX_ITER
            self.contributions.append(("hit_max_iterations", _W_HIT_MAX_ITER))

        if self.static_assets_404 > 0:
            delta = max(_W_STATIC_404_CAP, _W_STATIC_404_EACH * self.static_assets_404)
            r += delta
            self.contributions.append((f"static_404={self.static_assets_404}", delta))

        if self.turn_aborted_by_user:
            r += _W_TURN_ABORTED_BY_USER
            self.contributions.append(("turn_aborted_by_user", _W_TURN_ABORTED_BY_USER))

        if self.explicit_feedback != 0:
            delta = _W_EXPLICIT_FEEDBACK * self.explicit_feedback
            r += delta
            self.contributions.append((f"explicit_feedback={self.explicit_feedback}", delta))

        # Clamp to [-1, +1] so the downstream loss-weight math stays bounded.
        if r > 1.0:
            r = 1.0
        elif r < -1.0:
            r = -1.0
        return r

    def is_informative(self) -> bool:
        """True if ANY signal fired. A turn with all-neutral signals
        contributes no learning signal (caller stores None for reward)."""
        return any([
            self.verify_passed is not None,
            self.tool_errors > 0,
            self.replan_loops > 0,
            self.hit_max_iterations,
            self.static_assets_404 > 0,
            self.turn_aborted_by_user,
            self.explicit_feedback != 0,
        ])

    def summary(self) -> str:
        """Human-readable summary, useful for logs + /feedback display."""
        if not self.is_informative():
            return "neutral (no signals)"
        # Reward must run first so it populates self.contributions.
        r = self.reward()
        bits = [f"{name}{'+' if delta >= 0 else ''}{delta:.2f}"
                for name, delta in self.contributions]
        return f"reward={r:+.2f}  [{', '.join(bits)}]"


# ---------------------------------------------------------------------
# Collector — assembles signals over the course of a single turn.
# The agentic loop calls these as events happen. At turn end, it
# finalises and produces an OutcomeSignals snapshot.
# ---------------------------------------------------------------------

class OutcomeCollector:
    """Accumulates per-turn signals as events happen.

    Usage:
        coll = OutcomeCollector()
        coll.on_tool_result(name="Bash", ok=False)
        coll.on_todo_write(had_other_tool_calls_since_last=False)
        ...
        sig = coll.finalize()
        reward = sig.reward()
    """

    def __init__(self):
        self._verify_passed: bool | None = None
        self._tool_errors = 0
        self._replan_loops = 0
        self._consecutive_todo_writes = 0
        self._hit_max_iterations = False
        self._static_404 = 0
        self._turn_aborted_by_user = False
        self._explicit_feedback = 0
        self._explicit_reason = ""

    # ─── auto signals ─────────────────────────────────────────────

    def on_tool_result(self, name: str, ok: bool) -> None:
        """Record a tool result. `name` is the tool name; `ok` is True
        when status==success."""
        if not ok:
            self._tool_errors += 1
        if name == "TodoWrite":
            self._consecutive_todo_writes += 1
            # If we've seen ≥2 consecutive TodoWrites with no other
            # tool in between, count it as a replan loop iteration.
            if self._consecutive_todo_writes >= 2:
                self._replan_loops += 1
        else:
            self._consecutive_todo_writes = 0

    def on_verify_result(self, passed: bool) -> None:
        """Record the outcome of the Verifier (Phase 3)."""
        self._verify_passed = passed

    def on_static_404(self, count: int = 1) -> None:
        """Record that the Verifier found N static-asset 404s."""
        self._static_404 += count

    def on_hit_max_iterations(self) -> None:
        self._hit_max_iterations = True

    def on_turn_aborted_by_user(self) -> None:
        self._turn_aborted_by_user = True

    # ─── explicit signals ─────────────────────────────────────────

    def set_explicit_feedback(self, value: int, reason: str = "") -> None:
        """Set user feedback. value in {-1, 0, +1}. Called by the
        /feedback slash command (1.6)."""
        if value not in (-1, 0, 1):
            raise ValueError(f"explicit_feedback must be -1, 0, or +1; got {value!r}")
        self._explicit_feedback = value
        self._explicit_reason = reason

    # ─── finalize ─────────────────────────────────────────────────

    def finalize(self) -> OutcomeSignals:
        return OutcomeSignals(
            verify_passed=self._verify_passed,
            tool_errors=self._tool_errors,
            replan_loops=self._replan_loops,
            hit_max_iterations=self._hit_max_iterations,
            static_assets_404=self._static_404,
            turn_aborted_by_user=self._turn_aborted_by_user,
            explicit_feedback=self._explicit_feedback,
            explicit_reason=self._explicit_reason,
        )


# ---------------------------------------------------------------------
# Helpers — convenience constructors for common scenarios. Useful in
# tests and for callers that already know the full state.
# ---------------------------------------------------------------------

def positive(reason: str = "user marked good") -> OutcomeSignals:
    """A turn the user explicitly approved."""
    return OutcomeSignals(explicit_feedback=+1, explicit_reason=reason)


def negative(reason: str = "user marked bad") -> OutcomeSignals:
    """A turn the user explicitly rejected."""
    return OutcomeSignals(explicit_feedback=-1, explicit_reason=reason)


def neutral() -> OutcomeSignals:
    """A turn that produced no signal."""
    return OutcomeSignals()
