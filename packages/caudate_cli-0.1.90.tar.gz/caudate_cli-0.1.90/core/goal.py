"""Agent-state Goal model (Phase 2.1).

A `Goal` is the persistent intent the agent is working toward across
turns and sessions. Unlike `planning.forge_models.ForgeProject` (which
is the SQLAlchemy project-management surface), `Goal` here is the
agent's working memory of "what we're ultimately trying to build /
fix / explore."

The schema is deliberately lean — JSON-serializable so it can live
under `~/.caudate/goals/<id>.json` without a database dependency.

A goal is the unit of resumption:
    caudate --goal <id>              ← reboot into the goal
    /goal resume <id>                ← swap to a different goal mid-session
    /goal status                     ← see current subtask tree
    /goal complete                   ← mark done (positive Phase 1 signal)
    /goal abandon                    ← mark abandoned (negative signal)

Subsequent Phase 2 sub-steps wire this in:
    2.2 GoalStore (file persistence)
    2.3 slash commands
    2.4 system-prompt injection
    2.5 sub-task decomposition tool
    2.6 compaction-aware goal context
    2.7 CLI flag
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Any


# ---------------------------------------------------------------------
# Status enums — string-valued so they round-trip through JSON cleanly.
# ---------------------------------------------------------------------

class GoalStatus(str, Enum):
    ACTIVE     = "active"
    PAUSED     = "paused"
    COMPLETED  = "completed"
    ABANDONED  = "abandoned"


class SubtaskStatus(str, Enum):
    PENDING     = "pending"
    IN_PROGRESS = "in_progress"
    DONE        = "done"
    BLOCKED     = "blocked"


class AttemptResult(str, Enum):
    SUCCESS = "success"
    PARTIAL = "partial"
    ERROR   = "error"


# ---------------------------------------------------------------------
# Subtask — one step in the goal's decomposition.
# ---------------------------------------------------------------------

@dataclass
class Subtask:
    """A single step in the goal's decomposition tree."""

    id: str
    description: str
    status: SubtaskStatus = SubtaskStatus.PENDING
    # IDs of other subtasks that must complete before this one can start.
    # Empty list = independently dispatchable (Phase 6 sub-agents will
    # parallelize these).
    depends_on: list[str] = field(default_factory=list)
    # AttemptLog ids that targeted this subtask.
    attempts: list[str] = field(default_factory=list)

    @classmethod
    def new(cls, description: str, depends_on: list[str] | None = None) -> "Subtask":
        return cls(
            id=str(uuid.uuid4()),
            description=description,
            depends_on=list(depends_on or []),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "description": self.description,
            "status": self.status.value,
            "depends_on": list(self.depends_on),
            "attempts": list(self.attempts),
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Subtask":
        return cls(
            id=str(d.get("id") or uuid.uuid4()),
            description=str(d.get("description", "")),
            status=SubtaskStatus(d.get("status", "pending")),
            depends_on=list(d.get("depends_on") or []),
            attempts=list(d.get("attempts") or []),
        )


# ---------------------------------------------------------------------
# AttemptLog — a turn-by-turn record of work toward the goal.
# Links into Phase 1's outcome signal: `reward` is the same scalar
# `outcome_reward` Phase 1.1+1.2 produce.
# ---------------------------------------------------------------------

@dataclass
class AttemptLog:
    """One turn's worth of work toward the goal."""

    id: str
    turn_index: int                     # ordinal across the goal's lifetime
    timestamp: str                       # ISO 8601 UTC
    subtask_id: str | None = None        # which subtask was being worked on
    tool_calls: list[str] = field(default_factory=list)  # tool names in order
    result: AttemptResult | None = None
    reward: float | None = None          # outcome_reward ∈ [-1, +1] from Phase 1
    note: str = ""                       # one-liner from agent: "added Flask routes"

    @classmethod
    def new(
        cls,
        turn_index: int,
        subtask_id: str | None = None,
        tool_calls: list[str] | None = None,
        result: AttemptResult | None = None,
        reward: float | None = None,
        note: str = "",
    ) -> "AttemptLog":
        return cls(
            id=str(uuid.uuid4()),
            turn_index=turn_index,
            timestamp=datetime.now(timezone.utc).isoformat(),
            subtask_id=subtask_id,
            tool_calls=list(tool_calls or []),
            result=result,
            reward=reward,
            note=note,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "turn_index": self.turn_index,
            "timestamp": self.timestamp,
            "subtask_id": self.subtask_id,
            "tool_calls": list(self.tool_calls),
            "result": self.result.value if self.result else None,
            "reward": self.reward,
            "note": self.note,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "AttemptLog":
        return cls(
            id=str(d.get("id") or uuid.uuid4()),
            turn_index=int(d.get("turn_index") or 0),
            timestamp=str(d.get("timestamp") or datetime.now(timezone.utc).isoformat()),
            subtask_id=d.get("subtask_id"),
            tool_calls=list(d.get("tool_calls") or []),
            result=AttemptResult(d["result"]) if d.get("result") else None,
            reward=d.get("reward"),
            note=str(d.get("note", "")),
        )


# ---------------------------------------------------------------------
# Goal — the top-level persistent intent.
# ---------------------------------------------------------------------

@dataclass
class Goal:
    """Persistent agent-state intent. The unit of resumption."""

    id: str
    intent: str                            # user's original ask
    cwd: str                               # workspace path
    status: GoalStatus = GoalStatus.ACTIVE
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    subtasks: list[Subtask] = field(default_factory=list)
    attempts: list[AttemptLog] = field(default_factory=list)
    # Cross-link to a forge project if the user spun one up alongside
    # this goal (planning/forge_models.ForgeProject). Optional —
    # most goals won't have one.
    forge_project_id: int | None = None
    notes: str = ""

    @classmethod
    def new(cls, intent: str, cwd: str) -> "Goal":
        return cls(
            id=str(uuid.uuid4()),
            intent=intent,
            cwd=cwd,
        )

    # ── State queries ──────────────────────────────────────────────

    def is_active(self) -> bool:
        return self.status == GoalStatus.ACTIVE

    def short_id(self) -> str:
        """First 8 chars of the UUID — what we show in the statusline / picker."""
        return self.id[:8]

    def subtask_counts(self) -> dict[str, int]:
        """{status: count} across all subtasks."""
        out = {s.value: 0 for s in SubtaskStatus}
        for st in self.subtasks:
            out[st.status.value] = out.get(st.status.value, 0) + 1
        return out

    def progress_fraction(self) -> float:
        """Fraction of subtasks marked done. 0.0 if none."""
        if not self.subtasks:
            return 0.0
        done = sum(1 for st in self.subtasks if st.status == SubtaskStatus.DONE)
        return done / len(self.subtasks)

    def next_dispatchable(self) -> list[Subtask]:
        """Subtasks that are pending AND all their dependencies are done.
        Phase 6 sub-agents will dispatch from this list in parallel."""
        done_ids = {st.id for st in self.subtasks if st.status == SubtaskStatus.DONE}
        return [
            st for st in self.subtasks
            if st.status == SubtaskStatus.PENDING
            and all(dep in done_ids for dep in st.depends_on)
        ]

    # ── Mutation helpers ───────────────────────────────────────────

    def touch(self) -> None:
        self.updated_at = datetime.now(timezone.utc).isoformat()

    def add_subtask(self, description: str, depends_on: list[str] | None = None) -> Subtask:
        st = Subtask.new(description, depends_on)
        self.subtasks.append(st)
        self.touch()
        return st

    def find_subtask(self, subtask_id: str) -> Subtask | None:
        for st in self.subtasks:
            if st.id == subtask_id or st.id.startswith(subtask_id):
                return st
        return None

    def set_subtask_status(self, subtask_id: str, status: SubtaskStatus) -> bool:
        st = self.find_subtask(subtask_id)
        if st is None:
            return False
        st.status = status
        self.touch()
        return True

    def add_attempt(self, attempt: AttemptLog) -> None:
        self.attempts.append(attempt)
        if attempt.subtask_id:
            st = self.find_subtask(attempt.subtask_id)
            if st is not None and attempt.id not in st.attempts:
                st.attempts.append(attempt.id)
        self.touch()

    def complete(self) -> None:
        self.status = GoalStatus.COMPLETED
        self.touch()

    def abandon(self, reason: str = "") -> None:
        self.status = GoalStatus.ABANDONED
        if reason:
            self.notes = (self.notes + f"\nabandoned: {reason}").strip()
        self.touch()

    # ── Serialization ──────────────────────────────────────────────

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "intent": self.intent,
            "cwd": self.cwd,
            "status": self.status.value,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "subtasks": [st.to_dict() for st in self.subtasks],
            "attempts": [a.to_dict() for a in self.attempts],
            "forge_project_id": self.forge_project_id,
            "notes": self.notes,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Goal":
        return cls(
            id=str(d.get("id") or uuid.uuid4()),
            intent=str(d.get("intent", "")),
            cwd=str(d.get("cwd", "")),
            status=GoalStatus(d.get("status", "active")),
            created_at=str(d.get("created_at") or datetime.now(timezone.utc).isoformat()),
            updated_at=str(d.get("updated_at") or datetime.now(timezone.utc).isoformat()),
            subtasks=[Subtask.from_dict(s) for s in (d.get("subtasks") or [])],
            attempts=[AttemptLog.from_dict(a) for a in (d.get("attempts") or [])],
            forge_project_id=d.get("forge_project_id"),
            notes=str(d.get("notes", "")),
        )

    # ── Display ────────────────────────────────────────────────────

    def summary_line(self) -> str:
        """One-liner for the picker / statusline."""
        counts = self.subtask_counts()
        n_done = counts.get("done", 0)
        n_total = len(self.subtasks)
        progress = f"{n_done}/{n_total}" if n_total else "—"
        intent_short = self.intent[:60].replace("\n", " ")
        return (
            f"[{self.short_id()}] {self.status.value:9}  "
            f"{progress:>5}  {intent_short!r}"
        )

    def render_for_prompt(self) -> str:
        """Block injected into the system prompt by Phase 2.4. Compact
        so it doesn't blow context."""
        lines = [
            "### Active goal",
            f"  ID: {self.short_id()}",
            f"  Intent: {self.intent}",
            f"  Cwd: {self.cwd}",
        ]
        if self.subtasks:
            n_done = sum(1 for s in self.subtasks if s.status == SubtaskStatus.DONE)
            lines.append(f"  Subtasks ({n_done}/{len(self.subtasks)} done):")
            glyph = {
                SubtaskStatus.DONE:        "✓",
                SubtaskStatus.IN_PROGRESS: "◐",
                SubtaskStatus.PENDING:     "☐",
                SubtaskStatus.BLOCKED:     "⊘",
            }
            for st in self.subtasks:
                lines.append(f"    {glyph[st.status]} {st.description}")
        else:
            # Phase 2.5 nudge — agent's first move on a fresh goal
            # should be DecomposeGoal so the tree persists.
            lines.append("  Subtasks: none yet.")
            lines.append(
                "  → As your FIRST tool call, call DecomposeGoal with the "
                "subtask breakdown. That persists the plan across turns "
                "and sessions (unlike TodoWrite which is per-turn)."
            )
        if self.attempts:
            recent_reward = next(
                (a.reward for a in reversed(self.attempts) if a.reward is not None),
                None,
            )
            if recent_reward is not None:
                lines.append(f"  Last attempt reward: {recent_reward:+.2f}")
        lines.append("  Pick up where the last turn left off — don't restart the plan.")
        return "\n".join(lines)
