"""Constitutional AI for Cognos — post-response critique loop.

Implements the Anthropic Constitutional AI pattern, scoped to Cognos:

  1. LLM generates a response (normal flow)
  2. A critic call evaluates the response against `COGNOS_CONSTITUTION.md`
  3. If any rule is violated, the LLM is asked to revise the response
     with the violation cited
  4. The revised response is returned to the user

Wired into the `cognos-strict` model alias (and anywhere else that
imports `run_critique`). The default `cognos` / `cognos-haiku` /
`cognos-kimi` paths skip critique to keep latency low; opt in
explicitly when you want the guardrail.

Cost: roughly 2× LLM calls per turn (one for the answer, one for the
critique). When the answer passes, no revision call. When it fails,
add a third call.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


_CONSTITUTION_PATH = Path("/home/raveuk/cognos/data/COGNOS_CONSTITUTION.md")
_MAX_RESPONSE_FOR_CRITIQUE = 8000   # chars — cap so critique is fast
_MIN_RESPONSE_FOR_CRITIQUE = 60     # don't critique trivial replies ("ok", "done")


def _load_constitution() -> str:
    """Read the constitution markdown. Returns empty string if missing."""
    try:
        return _CONSTITUTION_PATH.read_text()
    except OSError as e:
        logger.warning(f"constitution missing: {e}")
        return ""


def _build_critique_prompt(
    user_message: str,
    response: str,
    constitution: str,
) -> str:
    """Build the prompt the critic LLM sees.

    Asks for strict JSON: a list of violated rule-ids + cited spans.
    Empty list = response is OK.
    """
    return (
        "You are evaluating a Cognos response against the Cognos "
        "Constitution. Your job is to identify rules the response "
        "VIOLATES — not to suggest improvements, not to rate quality.\n\n"
        "## Constitution\n\n"
        f"{constitution}\n\n"
        "---\n\n"
        "## What the user asked\n\n"
        f"{user_message[:2000]}\n\n"
        "## What the response said\n\n"
        f"{response[:_MAX_RESPONSE_FOR_CRITIQUE]}\n\n"
        "---\n\n"
        "Output a JSON object with a single key `violations`, whose "
        "value is a list. Each violation is an object with:\n"
        '  - `rule`: the rule ID (e.g. "R2")\n'
        '  - `quote`: a short span from the response that violates the rule\n'
        '  - `why`:  one sentence on why this is a violation\n\n'
        "If the response is clean, return `{\"violations\": []}`.\n\n"
        "Be strict. False positives are fine — the LLM will revise. "
        "False negatives let bad responses through. Output ONLY the "
        "JSON object, no markdown, no prose."
    )


def _build_revision_prompt(
    user_message: str,
    original_response: str,
    violations: list[dict],
) -> str:
    """Prompt the LLM to revise its response, citing violations."""
    violation_block = "\n".join(
        f"  - **{v.get('rule', '?')}**: {v.get('why', '?')} "
        f"(quote: {(v.get('quote') or '')[:120]!r})"
        for v in violations
    )
    return (
        "Your previous response to the user violated the Cognos "
        "Constitution. Revise it to fix the violations below while "
        "still answering the user's question. Don't apologise; just "
        "produce a corrected response.\n\n"
        f"## User asked\n\n{user_message[:2000]}\n\n"
        f"## Your previous response\n\n{original_response[:_MAX_RESPONSE_FOR_CRITIQUE]}\n\n"
        f"## Violations to fix\n\n{violation_block}\n\n"
        "Produce ONLY the revised response — no preamble, no "
        "'here's the revised version', just the new answer."
    )


async def run_critique(
    llm: Any,                       # LLMProvider — same one that produced the response
    user_message: str,
    response: str,
    *,
    max_revision_loops: int = 1,
) -> tuple[str, list[dict]]:
    """Run constitutional critique on a response. Returns (final_text, violations).

    - If the response is clean, returns (response, []).
    - If violations are found, asks the LLM to revise and returns
      the revised text (+ the violations that triggered the revision).
    - Trivial responses (under _MIN_RESPONSE_FOR_CRITIQUE chars) are
      skipped — not worth the round-trip for "ok" / "done".
    - `max_revision_loops`: if a revision still violates the
      constitution, retry up to N times before giving up. Default 1
      revision loop (so worst case = 3 LLM calls).
    """
    if not response or len(response.strip()) < _MIN_RESPONSE_FOR_CRITIQUE:
        return response, []

    constitution = _load_constitution()
    if not constitution:
        return response, []

    current_response = response
    all_violations: list[dict] = []
    for loop in range(max_revision_loops + 1):
        # Critique
        try:
            critique_resp = await llm.complete(
                prompt=_build_critique_prompt(
                    user_message, current_response, constitution
                ),
                max_tokens=2048,
                temperature=0.0,
            )
        except Exception as e:
            logger.warning(f"critique call failed: {e}")
            return current_response, all_violations

        # Parse violations
        violations = _parse_violations(critique_resp.content or "")
        if not violations:
            return current_response, all_violations
        all_violations.extend(violations)
        logger.info(
            f"constitution: loop={loop} found {len(violations)} "
            f"violation(s): {[v.get('rule') for v in violations]}"
        )

        # Last loop and still violating? Return what we have with the
        # violations attached so the caller can decide.
        if loop >= max_revision_loops:
            break

        # Revise
        try:
            revision_resp = await llm.complete(
                prompt=_build_revision_prompt(
                    user_message, current_response, violations
                ),
                max_tokens=4096,
                temperature=0.2,
            )
            current_response = revision_resp.content or current_response
        except Exception as e:
            logger.warning(f"revision call failed: {e}")
            break

    return current_response, all_violations


def _parse_violations(text: str) -> list[dict]:
    """Parse the critic's JSON output. Tolerant of code-fenced output."""
    if not text:
        return []
    s = text.strip()
    if s.startswith("```"):
        # ```json\n...\n```
        s = s.split("\n", 1)[1] if "\n" in s else s
        if s.endswith("```"):
            s = s.rsplit("```", 1)[0]
        s = s.strip()
    try:
        parsed = json.loads(s)
    except json.JSONDecodeError as e:
        logger.debug(f"critique JSON parse failed: {e!s:.100}")
        return []
    if not isinstance(parsed, dict):
        return []
    violations = parsed.get("violations") or []
    if not isinstance(violations, list):
        return []
    # Filter: each entry must be a dict
    return [v for v in violations if isinstance(v, dict)]
