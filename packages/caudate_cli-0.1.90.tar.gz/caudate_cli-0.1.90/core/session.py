"""Session persistence — save and resume agentic loop conversations.

Sessions are stored as JSON files in data/sessions/<session_id>.json. Each
file contains the message history, creation timestamp, and metadata
(title, model, tag).
"""

from __future__ import annotations

import json
import logging
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


class Session(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    title: str = ""
    tag: str = ""
    model: str = ""
    messages: list[dict[str, Any]] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    metadata: dict[str, Any] = Field(default_factory=dict)


class SessionManager:
    """Save/load/list sessions from a local directory."""

    def __init__(self, sessions_dir: Path):
        self.sessions_dir = sessions_dir
        self.sessions_dir.mkdir(parents=True, exist_ok=True)

    def _path(self, session_id: str) -> Path:
        return self.sessions_dir / f"{session_id}.json"

    def save(self, session: Session) -> None:
        session.updated_at = datetime.utcnow()
        path = self._path(session.id)
        path.write_text(session.model_dump_json(indent=2))

    def load(self, session_id: str) -> Session | None:
        path = self._path(session_id)
        if not path.exists():
            return None
        try:
            return Session.model_validate_json(path.read_text())
        except Exception as e:
            logger.warning(f"Failed to load session {session_id}: {e}")
            return None

    def delete(self, session_id: str) -> bool:
        path = self._path(session_id)
        if path.exists():
            path.unlink()
            return True
        return False

    def list(self) -> list[Session]:
        """Return all sessions, newest first."""
        sessions: list[Session] = []
        for path in self.sessions_dir.glob("*.json"):
            try:
                sessions.append(Session.model_validate_json(path.read_text()))
            except Exception as e:
                logger.debug(f"Skipping unreadable session {path}: {e}")
        sessions.sort(key=lambda s: s.updated_at, reverse=True)
        return sessions

    def rename(self, session_id: str, title: str) -> bool:
        session = self.load(session_id)
        if session is None:
            return False
        session.title = title
        self.save(session)
        return True

    def tag(self, session_id: str, tag: str) -> bool:
        session = self.load(session_id)
        if session is None:
            return False
        session.tag = tag
        self.save(session)
        return True
