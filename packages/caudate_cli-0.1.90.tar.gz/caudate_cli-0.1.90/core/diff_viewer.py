"""Diff viewer — render unified diffs for proposed file edits.

Used by the agentic loop's permission prompt: before applying an `Edit`
or `Write` tool call under DEFAULT permission mode, we render a diff so
the user knows exactly what they're approving. Built on `difflib` +
`rich` so it works without external deps.

`render_proposed_change(tool, args)` is the entry point — it dispatches
on the tool name (`Edit` shows old→new on a specific block, `Write`
shows whole-file before/after) and prints a syntax-highlighted diff to
the supplied console.
"""

from __future__ import annotations

import difflib
import logging
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.syntax import Syntax

logger = logging.getLogger(__name__)


def _read_existing(path: Path) -> str:
    if not path.exists():
        return ""
    try:
        return path.read_text(errors="ignore")
    except Exception as e:
        logger.debug(f"diff_viewer: cannot read {path}: {e}")
        return ""


def render_unified_diff(
    before: str,
    after: str,
    label_before: str = "before",
    label_after: str = "after",
    console: Console | None = None,
    context: int = 3,
) -> None:
    console = console or Console()
    diff_lines = list(difflib.unified_diff(
        before.splitlines(keepends=False),
        after.splitlines(keepends=False),
        fromfile=label_before,
        tofile=label_after,
        n=context,
        lineterm="",
    ))
    if not diff_lines:
        console.print("[dim](no textual change)[/dim]")
        return
    console.print(Syntax("\n".join(diff_lines), "diff", theme="ansi_dark"))


def render_proposed_change(
    tool: str,
    args: dict[str, Any],
    console: Console | None = None,
) -> None:
    """Print a preview for an Edit/Write tool call. No-op for other tools."""
    console = console or Console()
    if tool == "Edit":
        path = Path(args.get("file_path") or args.get("path") or "")
        old = args.get("old_string", "")
        new = args.get("new_string", "")
        if not path:
            return
        before = _read_existing(path)
        if old and old in before:
            after = before.replace(old, new, 1) if not args.get("replace_all") else before.replace(old, new)
        else:
            after = before  # fall through; the tool itself will error
        console.print(f"[bold yellow]Proposed Edit[/bold yellow] {path}")
        render_unified_diff(before, after, str(path), str(path), console=console)
    elif tool == "Write":
        path = Path(args.get("file_path") or args.get("path") or "")
        new = args.get("content", "")
        if not path:
            return
        before = _read_existing(path)
        console.print(f"[bold yellow]Proposed Write[/bold yellow] {path}")
        render_unified_diff(before, new, str(path), str(path), console=console)
