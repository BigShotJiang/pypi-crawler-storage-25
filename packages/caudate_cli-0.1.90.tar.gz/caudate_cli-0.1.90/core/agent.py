"""Agent — the top-level orchestrator for the Cognos cognitive architecture.

Supports two modes:
  - "agentic" (default): real-time tool-calling loop (Claude SDK style)
  - "plan": DAG-based planner + executor (the original Phase 1 loop)
"""

from __future__ import annotations

import logging

from core.schemas import Goal
from core.loop import CognitiveLoop
from core.agentic_loop import AgenticLoop
from core.citations import CitationBlock, Document
from core.compaction import ContextCompactor
from core.files import FileStore
from core.hooks import HookManager
from core.permissions import (
    PermissionManager, PermissionMode,
    default_cli_prompt, rules_from_settings,
)
from core.settings import Settings
from core.session import Session, SessionManager
from core.subagent import SubagentManager
from cognos_mcp.bridge import MCPToolBridge
from cognos_mcp.client import MCPClient
from cognos_mcp.config import load_servers
from llm.router import DualLLMProvider, RoutingPolicy
from personality import PersonalityEngine


def _resolve_preset_sync(name_or_preset: str) -> str:
    """Resolve a preset like 'fast'/'balanced'/'powerful' to a concrete model id.

    Returns the input unchanged if it's not a known preset. Uses subprocess
    synchronously to avoid issues when called from inside an async context.
    """
    preset = name_or_preset.lower()
    if preset not in ("fast", "balanced", "powerful"):
        return name_or_preset

    import subprocess
    from llm.models import ModelInfo, ModelRegistry, _classify, _parse_size

    try:
        out = subprocess.run(
            ["ollama", "list"],
            capture_output=True, text=True, timeout=10,
        ).stdout
    except Exception:
        return name_or_preset

    reg = ModelRegistry()
    for line in out.splitlines()[1:]:
        parts = line.split()
        if len(parts) < 3:
            continue
        name = parts[0]
        size_str = parts[2] + " " + parts[3] if len(parts) >= 4 else "0 MB"
        tool_calling, json_mode, context = _classify(name)
        reg._models[f"ollama/{name}"] = ModelInfo(
            id=f"ollama/{name}",
            name=name,
            provider="ollama",
            supports_tool_calling=tool_calling,
            supports_json_mode=json_mode,
            context_window=context,
            size_bytes=_parse_size(size_str),
        )
    return reg.resolve(name_or_preset)
from execution.executor import Executor
from llm.provider import LLMProvider
from memory.working import WorkingMemory
from memory.episodic import EpisodicMemory
from memory.semantic import SemanticMemory

logger = logging.getLogger(__name__)


class CognosAgent:
    """Top-level agent that manages goals and runs the cognitive loop."""

    def __init__(
        self,
        model: str | None = None,
        mode: str = "agentic",
        thinking: bool = False,
        on_thinking=None,
        permission_mode: str | None = None,
        prompt_fn=None,
        session_id: str | None = None,
        personality: bool = True,
        verbose_personality: bool = False,
        on_inner_voice=None,
        system1: str | None = None,
        system2: str | None = None,
    ):
        from config import (
            LLM_MODEL, PERMISSION_MODE, AUDIT_LOG_PATH, HOOKS_CONFIG_PATH,
            SESSIONS_DIR, CONTEXT_WINDOW_SIZE, COMPACT_THRESHOLD, COMPACT_KEEP_RECENT,
            DATA_DIR, SYSTEM_1_MODEL, SYSTEM_2_MODEL, ROUTER_COMPLEXITY_THRESHOLD,
            FILES_DIR,
        )
        # Layered config — settings file < explicit kwargs.
        settings = Settings.load()
        raw_model = model or settings.get("model") or LLM_MODEL
        resolved = _resolve_preset_sync(raw_model)
        primary_llm = LLMProvider(model=resolved)

        # Optional fallback chain — wraps the primary so any retryable
        # failure transparently falls through to the next model.
        fallback_models = settings.get("fallback_models") or []
        if fallback_models:
            from llm.fallback import build_fallback
            primary_llm = build_fallback(primary_llm, list(fallback_models))

        # Dual-process brain — if System 1 and System 2 are both configured,
        # wrap them in a DualLLMProvider that routes per call. Settings file
        # values participate in the same priority chain as `model`.
        s1 = (system1 if system1 is not None
              else settings.get("system1") or SYSTEM_1_MODEL)
        s2 = (system2 if system2 is not None
              else settings.get("system2") or SYSTEM_2_MODEL)
        if s1 and s2:
            self.llm_fast = LLMProvider(model=_resolve_preset_sync(s1))
            self.llm_slow = LLMProvider(model=_resolve_preset_sync(s2))
            policy = RoutingPolicy(complexity_threshold=ROUTER_COMPLEXITY_THRESHOLD)
            self.llm = DualLLMProvider(
                fast=self.llm_fast, slow=self.llm_slow, policy=policy,
            )
            logger.info(
                f"Dual-brain routing enabled: fast={self.llm_fast.model}, "
                f"slow={self.llm_slow.model}"
            )
        else:
            self.llm_fast = primary_llm
            self.llm_slow = primary_llm
            self.llm = primary_llm

        self.mode = mode
        self._goal_history: list[Goal] = []

        # Plan mode uses the full Phase 1 loop. Its planner/reflector/
        # meta-learner always want slow-tier — pass the router, which will
        # route them via their caller tags. (If no router, llm_slow IS llm.)
        self.loop = CognitiveLoop(self.llm)

        # Build permission manager — allow/deny rules come from settings.
        pm_value = permission_mode or settings.get("permission_mode") or PERMISSION_MODE
        perms_cfg = settings.get("permissions") or {}

        # Auto-mode classifier closure — tries slow tier first (better
        # JSON reliability), falls back to fast tier if slow tier
        # auth/network fails. Returns None only when BOTH tiers fail
        # so PermissionManager falls back to the manual picker.
        auto_timeout = float(settings.get("auto_mode_timeout_s") or 2.0)
        slow_llm = getattr(self, "llm_slow", None)
        fast_llm = getattr(self, "llm_fast", None) or self.llm

        async def _auto_classify(tool, args):
            try:
                from core.permissions_auto import classify_with_llm
            except Exception:
                return None
            # Try slow tier first if configured. Auth errors come back
            # as None from classify_with_llm (it swallows exceptions),
            # so we can re-try on fast tier without ever bubbling up.
            if slow_llm is not None:
                verdict = await classify_with_llm(
                    slow_llm, tool, args, timeout_s=auto_timeout,
                )
                if verdict is not None:
                    return verdict
            # Fall back to fast tier — important for local-first users
            # without an Anthropic key. Same classifier prompt, less
            # JSON discipline but still usable.
            return await classify_with_llm(
                fast_llm, tool, args, timeout_s=auto_timeout,
            )

        permissions = PermissionManager(
            mode=PermissionMode(pm_value),
            allow=rules_from_settings(perms_cfg.get("allow")),
            deny=rules_from_settings(perms_cfg.get("deny")),
            audit_log=AUDIT_LOG_PATH,
            prompt=prompt_fn or default_cli_prompt,
            classifier=_auto_classify,
        )

        # Build hook manager and load any configured hooks
        hooks = HookManager()
        loaded = hooks.load_from_file(HOOKS_CONFIG_PATH)
        if loaded:
            logger.info(f"Loaded {loaded} hooks from {HOOKS_CONFIG_PATH}")

        # Context compaction
        compactor = ContextCompactor(
            llm=self.llm,
            context_window=CONTEXT_WINDOW_SIZE,
            compact_threshold=COMPACT_THRESHOLD,
            keep_recent=COMPACT_KEEP_RECENT,
        )

        # Session management — load existing session or prepare a new one
        self.sessions = SessionManager(SESSIONS_DIR)
        self.session: Session
        if session_id:
            loaded_session = self.sessions.load(session_id)
            if loaded_session is None:
                logger.warning(f"Session {session_id} not found — starting new")
                self.session = Session(id=session_id, model=self.llm.model)
            else:
                self.session = loaded_session
        else:
            self.session = Session(model=self.llm.model)

        # Agentic mode shares the same executor + memory but drives them
        # via a real-time tool-calling loop
        # Personality — identity + mood + inner voice
        self.personality: PersonalityEngine | None = None
        if personality:
            self.personality = PersonalityEngine.load(
                data_dir=DATA_DIR,
                verbose_thinking=verbose_personality,
                on_thinking_display=on_inner_voice,
            )
            self.personality.register_with(hooks)
            # Give the router access to mood so frustration escalates to System 2
            if isinstance(self.llm, DualLLMProvider):
                self.llm.set_mood(self.personality.mood)

        # Wrap personality's system_prompt provider with goal-injection.
        # Legacy `self._goal` (free-text string) is preserved for
        # backward-compat. Phase 2 introduces the structured
        # `self.active_goal: Goal | None` — managed by the new
        # /goal slash commands + core.goal_store, persists across
        # sessions. 2.4 will inject its `render_for_prompt()` block.
        self._goal: str = ""
        try:
            from core.goal import Goal as _Goal  # noqa: F401 (type hint only)
        except Exception:
            pass
        self.active_goal = None  # type: "Goal | None"
        # Auto-resume: if a previous session set an active goal pointer,
        # load it so caudate boots back into that goal's context. Best-
        # effort; missing / unreadable goals are silently ignored.
        try:
            from core.goal_store import get_store
            self.active_goal = get_store().active()
        except Exception as e:
            logger.debug(f"active goal auto-resume failed: {e}")
        _personality_wrap = (
            self.personality.wrap_system_prompt if self.personality else None
        )

        def system_prompt_provider(base: str) -> str:
            wrapped = _personality_wrap(base) if _personality_wrap else base
            # Phase 2.4: prefer the structured active_goal's render_for_prompt
            # block when present — it carries the subtask tree, progress
            # counts, and a "don't restart the plan" nudge that single-
            # string goal injection can't express. Falls back to the
            # legacy free-text string for users who set /goal <text>
            # without going through `/goal new`.
            ag = getattr(self, "active_goal", None)
            if ag is not None:
                try:
                    block = ag.render_for_prompt()
                    return f"{block}\n\n{wrapped}"
                except Exception as e:
                    logger.debug(f"active_goal render failed: {e}")
            goal = (self._goal or "").strip()
            if not goal:
                return wrapped
            return f"## Active session goal\n{goal}\n\n{wrapped}"
        thinking_instruction_wrapper = (
            self.personality.augment_thinking_instruction if self.personality else None
        )
        on_thinking_combined = on_thinking
        if self.personality is not None:
            inner_on_thinking = self.personality.inner_voice.on_thinking
            if on_thinking is None:
                on_thinking_combined = inner_on_thinking
            else:
                # Chain both callbacks
                def _combined(blocks, _ot=on_thinking, _iv=inner_on_thinking):
                    _iv(blocks)
                    _ot(blocks)
                on_thinking_combined = _combined

        # File store (attachments / Files-API equivalent)
        self.files = FileStore(root=FILES_DIR)

        self.agentic = AgenticLoop(
            llm=self.llm,
            executor=self.loop.executor,
            episodic=self.loop.episodic,
            semantic=self.loop.semantic,
            working=self.loop.working,
            thinking=thinking,
            on_thinking=on_thinking_combined,
            permissions=permissions,
            hooks=hooks,
            compactor=compactor,
            session_id=self.session.id,
            system_prompt_provider=system_prompt_provider,
            thinking_instruction_wrapper=thinking_instruction_wrapper,
            file_store=self.files,
        )
        self.permissions = permissions
        self.hooks = hooks
        self.compactor = compactor

        # Subagent support — wire the AgentTool's manager reference
        self.subagents = SubagentManager(
            llm=self.llm,
            parent_executor=self.loop.executor,
            episodic=self.loop.episodic,
            semantic=self.loop.semantic,
            permissions=permissions,
            hooks=hooks,
        )
        agent_tool = self.loop.executor.get_tool("Agent")
        if agent_tool is not None and hasattr(agent_tool, "set_manager"):
            agent_tool.set_manager(self.subagents)

        # Wire the Draw tool to the FileStore so generated images get
        # persisted and referenceable. Settings can override the
        # backend (default: diffusers/SDXL-Turbo).
        draw_tool = self.loop.executor.get_tool("Draw")
        if draw_tool is not None and hasattr(draw_tool, "set_file_store"):
            draw_tool.set_file_store(self.files)
            img_cfg = settings.get("image") or {}
            if img_cfg.get("backend"):
                draw_tool._backend_name = img_cfg["backend"]
            if img_cfg.get("backend_kwargs"):
                draw_tool._backend_kwargs = dict(img_cfg["backend_kwargs"])

        # Wire the Artifact tool to the same FileStore so artifact panes
        # (HTML, SVG, markdown, code) get persisted under /files/ for the
        # chat UI to fetch.
        artifact_tool = self.loop.executor.get_tool("Artifact")
        if artifact_tool is not None and hasattr(artifact_tool, "set_file_store"):
            artifact_tool.set_file_store(self.files)

        # Wire the Speak tool too — synthesized audio is persisted as
        # WAV under /files/ and surfaced to the chat UI as a markdown
        # audio link the LLM echoes verbatim.
        speak_tool = self.loop.executor.get_tool("Speak")
        if speak_tool is not None and hasattr(speak_tool, "set_file_store"):
            speak_tool.set_file_store(self.files)

        # Wire EditImage to the FileStore so it can resolve `files/<id>`
        # references from prior Draw / DescribeImage tool outputs and
        # save edited images back to the same store.
        edit_image_tool = self.loop.executor.get_tool("EditImage")
        if edit_image_tool is not None and hasattr(edit_image_tool, "set_file_store"):
            edit_image_tool.set_file_store(self.files)

        # Wire LongCat Avatar — needs the FileStore to resolve input
        # ref_image / audio FileStore ids AND to persist the output video.
        # Also wire the Speak tool so the agent can pass `text` instead
        # of an `audio` clip — LongCatAvatar will synthesize via Kokoro
        # TTS internally and feed the result into the WAN-S2V graph.
        longcat_avatar_tool = self.loop.executor.get_tool("LongCatAvatar")
        if longcat_avatar_tool is not None and hasattr(longcat_avatar_tool, "set_file_store"):
            longcat_avatar_tool.set_file_store(self.files)
            speak_for_avatar = self.loop.executor.get_tool("Speak")
            if speak_for_avatar is not None and hasattr(longcat_avatar_tool, "set_speak_tool"):
                longcat_avatar_tool.set_speak_tool(speak_for_avatar)

        # Wire Storyboard — it needs the FileStore to persist panels
        # AND the live LLM (for beat breakdown). It also reuses the
        # already-instantiated image backends from Draw / EditImage so
        # we don't pay the FLUX-schnell + Kontext load cost twice.
        storyboard_tool = self.loop.executor.get_tool("Storyboard")
        if storyboard_tool is not None:
            storyboard_tool.set_file_store(self.files)
            try:
                if draw_tool is not None and hasattr(draw_tool, "_get_backend"):
                    storyboard_tool.set_image_gen(draw_tool._get_backend())
            except Exception as e:
                logger.warning(f"Storyboard: could not share Draw backend: {e}")
            try:
                if edit_image_tool is not None and hasattr(edit_image_tool, "_get_backend"):
                    storyboard_tool.set_image_edit(edit_image_tool._get_backend())
            except Exception as e:
                logger.warning(f"Storyboard: could not share EditImage backend: {e}")

        # MCP clients (optional) — lazily connected in `start()`
        self._mcp_clients: list[MCPClient] = []

        # Wire TaskCreate + MCPListServers to this live agent so they
        # can spawn sub-prompts and inspect the MCP roster respectively.
        for late_wire_name in ("TaskCreate", "MCPListServers"):
            t = self.loop.executor.get_tool(late_wire_name)
            if t is not None and hasattr(t, "set_agent"):
                t.set_agent(self)

        # Caudate — the action-selection neural net. Loaded if a checkpoint
        # exists; the agent works fine if not. The observer also captures
        # live (state, action, reward) into a replay buffer and triggers
        # auto-training in the background.
        self.caudate = None
        try:
            from nn.observer import CaudateObserver
            self.caudate = CaudateObserver()
            self.agentic.caudate = self.caudate
            # Hand Caudate to the router so she can override tier
            # selection once she earns the ADVISOR trust level.
            if isinstance(self.llm, DualLLMProvider):
                try:
                    self.llm.router.set_caudate(self.caudate)
                except Exception:
                    pass
            if self.caudate.advisor is not None:
                level = self.caudate.policy.level.label
                logger.info(f"Caudate loaded — trust level: {level}")
            else:
                logger.info(
                    "Caudate has no checkpoint yet — observing only. "
                    f"After {self.caudate.cfg.min_episodes_to_train} "
                    "samples she'll auto-train and start predicting."
                )
        except Exception as e:
            logger.warning(f"Caudate init failed (continuing without): {e}")

        # Restore any prior messages from the loaded session
        if self.session.messages:
            self.agentic.load_messages(self.session.messages)

    async def pursue_goal(
        self,
        description: str,
        success_criteria: list[str] | None = None,
        verbose: bool = True,
    ) -> Goal:
        """Create and pursue a goal through the cognitive loop.

        Always uses plan mode (DAG-based) regardless of agent mode — use
        `chat()` for the agentic conversational loop.
        """
        goal = Goal(
            description=description,
            success_criteria=success_criteria or [],
        )
        self._goal_history.append(goal)

        result = await self.loop.run(goal, verbose=verbose)
        return result

    async def start(self) -> None:
        """Connect to configured MCP servers and register their tools.

        Safe to call multiple times — a no-op after the first successful
        connection for each server.
        """
        from config import MCP_CONFIG_PATH
        if self._mcp_clients:
            return

        for cfg in load_servers(MCP_CONFIG_PATH):
            client = MCPClient(
                name=cfg.name,
                command=cfg.command,
                args=cfg.args,
                env=cfg.env,
            )
            try:
                await client.connect()
            except Exception as e:
                logger.warning(f"MCP server {cfg.name!r} connect failed: {e}")
                continue
            self._mcp_clients.append(client)
            for remote in client.tools:
                bridged = MCPToolBridge(client, remote)
                self.loop.executor.register_tool(bridged)
                logger.info(f"Registered MCP tool: {bridged.name}")

    async def stop(self) -> None:
        """Disconnect any open MCP clients."""
        for c in self._mcp_clients:
            try:
                await c.close()
            except Exception as e:
                logger.debug(f"MCP close failed for {c.name}: {e}")
        self._mcp_clients = []

    async def chat(
        self,
        message: str,
        attachments: list[str] | None = None,
        documents: list[Document] | None = None,
    ) -> str:
        """Multi-turn conversational entry point (agentic loop).

        `attachments` is a list of file_ids previously registered with
        `self.files.upload()`. `documents` is an optional list of Document
        objects the model may cite; structured citation blocks are
        available on `self.agentic.last_citations` after each call.

        Persists the conversation to the current session after each turn.
        """
        await self.start()
        reply = await self.agentic.run(
            message, attachments=attachments, documents=documents,
        )
        self.session.messages = list(self.agentic.messages)
        self.session.model = self.llm.model
        if not self.session.title and message:
            self.session.title = message[:80]
        self.sessions.save(self.session)
        return reply

    def reset_conversation(self) -> None:
        """Clear the agentic loop's conversation history (starts a new session)."""
        self.agentic.reset()
        self.session = Session(model=self.llm.model)
        self.agentic.session_id = self.session.id

    def register_tool(self, tool) -> None:
        """Register a custom tool with the executor."""
        self.loop.executor.register_tool(tool)

    def switch_model(self, model: str) -> None:
        """Switch the underlying LLM model."""
        self.llm.switch_model(model)

    @property
    def goal_history(self) -> list[Goal]:
        return self._goal_history

    @property
    def strategies(self):
        return self.loop.procedural.get_strategies()

    @property
    def performance_history(self):
        return self.loop.procedural.get_performance_history()
