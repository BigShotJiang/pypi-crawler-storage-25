"""Ownership — Cognos's hard authority lock.

A single owner is configured. Every override / freeze / kill action is
checked against this identity. Caudate's predictions are gated through
a killswitch that the system itself cannot disable — only the owner,
through the REPL or the file system, can flip it back.

Three layers of authority:

  1. **Owner identity** — `data/owner.json` records who's in charge.
     Set on first run, kept across restarts. Only manual file editing
     or `/owner set` can change it.

  2. **Killswitch** — `data/nn/.killed` (a file marker). When present,
     Caudate's `predict`, `auto_evolve`, and `promote` paths all return
     None / no-op. Defensive: every Caudate code path checks this before
     acting.

  3. **Audit log** — `data/audit/owner.jsonl`, append-only. Every
     attempt to disable the killswitch, change ownership, or override
     a Caudate freeze lands here.

The killswitch is a *file*, not just a Python flag — so a runaway
process can't undo it. The file persists across restarts. Even if
Caudate were somehow code-modified, removing the file requires
filesystem write access which is the user's domain.
"""

from __future__ import annotations

import json
import logging
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


_OWNER_PATH = Path("data/owner.json")
_KILLSWITCH = Path("data/nn/.killed")
_AUDIT_PATH = Path("data/audit/owner.jsonl")
_DEFAULT_OWNER = "Rave"


@dataclass
class Owner:
    name: str = _DEFAULT_OWNER
    set_at: str = ""
    note: str = "primary user; ultimate authority over Caudate and the agent"


# ---- Owner identity ------------------------------------------------


def get_owner() -> Owner:
    if _OWNER_PATH.exists():
        try:
            data = json.loads(_OWNER_PATH.read_text())
            return Owner(**data)
        except Exception:
            pass
    # Initialize on first read
    o = Owner(name=_DEFAULT_OWNER,
              set_at=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))
    save_owner(o)
    return o


def save_owner(owner: Owner) -> None:
    _OWNER_PATH.parent.mkdir(parents=True, exist_ok=True)
    _OWNER_PATH.write_text(json.dumps({
        "name": owner.name,
        "set_at": owner.set_at,
        "note": owner.note,
    }, indent=2))


def set_owner(name: str, note: str = "") -> Owner:
    """Owner reassignment. Audit-logged."""
    prev = get_owner()
    new = Owner(
        name=name,
        set_at=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        note=note or prev.note,
    )
    save_owner(new)
    audit("owner_changed", from_=prev.name, to=name)
    return new


# ---- Killswitch ---------------------------------------------------


def is_killed() -> bool:
    """Returns True if Caudate is in killed state.

    Every Caudate code path that can affect agent behavior should
    check this and bail-soft when True.
    """
    return _KILLSWITCH.exists()


def kill(reason: str = "owner stop") -> None:
    """Activate the killswitch. Caudate goes silent immediately."""
    _KILLSWITCH.parent.mkdir(parents=True, exist_ok=True)
    _KILLSWITCH.write_text(json.dumps({
        "killed_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "reason": reason,
        "owner": get_owner().name,
    }, indent=2))
    audit("killed", reason=reason)
    logger.warning(f"Caudate killed by owner: {reason}")


def resume() -> None:
    """Lift the killswitch. Caudate resumes observing."""
    if _KILLSWITCH.exists():
        try:
            data = json.loads(_KILLSWITCH.read_text())
        except Exception:
            data = {}
        _KILLSWITCH.unlink()
        audit("resumed", was_killed_at=data.get("killed_at"))
        logger.info("Caudate killswitch lifted")


def killswitch_status() -> dict[str, Any]:
    if not _KILLSWITCH.exists():
        return {"killed": False}
    try:
        data = json.loads(_KILLSWITCH.read_text())
    except Exception:
        data = {}
    data["killed"] = True
    return data


# ---- Audit log ----------------------------------------------------


def audit(action: str, **kwargs: Any) -> None:
    """Append-only log of authority-related events."""
    try:
        _AUDIT_PATH.parent.mkdir(parents=True, exist_ok=True)
        with _AUDIT_PATH.open("a") as f:
            f.write(json.dumps({
                "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "action": action,
                "owner": get_owner().name,
                **kwargs,
            }) + "\n")
    except Exception as e:
        logger.debug(f"audit log write failed: {e}")


def audit_tail(lines: int = 50) -> list[dict[str, Any]]:
    if not _AUDIT_PATH.exists():
        return []
    out: list[dict[str, Any]] = []
    for line in _AUDIT_PATH.read_text().splitlines()[-lines:]:
        try:
            out.append(json.loads(line))
        except Exception:
            continue
    return out


# ---- Decision gate ------------------------------------------------


def caudate_may_act() -> bool:
    """The single gate Caudate's code paths should check.

    Returns False if:
      - the killswitch is active
    True otherwise.
    """
    return not is_killed()
