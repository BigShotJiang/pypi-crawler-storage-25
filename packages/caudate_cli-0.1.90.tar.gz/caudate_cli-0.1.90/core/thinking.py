"""ThinkingManager — chain-of-thought reasoning before actions.

Mirrors the Claude SDK "thinking" feature using a prompt-based protocol:
the model is instructed to emit <thinking>...</thinking> blocks before any
visible output or tool call. The manager strips those blocks from the
user-facing content and exposes them separately so the UI can render them
in a dimmed panel (or ignore them silently by default).
"""

from __future__ import annotations

import re

from core.schemas import ThinkingBlock

THINKING_INSTRUCTION = (
    "Before responding or calling any tool, you may reason step-by-step "
    "inside a <thinking>...</thinking> block. Use it to plan your approach, "
    "weigh options, and catch mistakes. Everything inside the block is "
    "internal and will not be shown to the user. Keep it brief — one short "
    "paragraph is usually enough. After the thinking block, either call a "
    "tool or emit your final answer."
)

_THINKING_RE = re.compile(
    r"<thinking>(.*?)</thinking>",
    re.DOTALL | re.IGNORECASE,
)


class ThinkingManager:
    """Injects thinking instructions into the system prompt and parses blocks."""

    def __init__(self, enabled: bool = False):
        self.enabled = enabled

    def augment_system_prompt(self, system: str) -> str:
        """Append the thinking instruction to a system prompt."""
        if not self.enabled:
            return system
        return f"{system}\n\n{THINKING_INSTRUCTION}"

    def parse(self, text: str) -> tuple[list[ThinkingBlock], str]:
        """Extract thinking blocks from text. Returns (blocks, stripped_text)."""
        blocks = [
            ThinkingBlock(thinking=m.group(1).strip())
            for m in _THINKING_RE.finditer(text)
        ]
        stripped = _THINKING_RE.sub("", text).strip()
        return blocks, stripped
