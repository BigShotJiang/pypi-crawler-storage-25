"""Subscription-OAuth helper for Cognos's web UI calls to Anthropic.

Background
----------
Claude Code (the CLI) authenticates to Anthropic with an OAuth Bearer
token stored at ``~/.claude/.credentials.json``. The Cognos passthrough
proxy at ``/v1/messages`` already forwards that token verbatim from
incoming Claude Code requests — it never has to read the file itself.

The web UI is a different story: it calls Cognos's own ``/chat`` endpoint,
which goes through ``LLMProvider`` → LiteLLM → Anthropic. LiteLLM expects
``ANTHROPIC_API_KEY`` in the environment. The user has a subscription, not
an API key — so without help, the web UI silently fails on Opus.

Scope
-----
This helper is intentionally **scoped to the web UI only**. It uses a
``ContextVar`` set by the ``/chat`` and ``/chat/stream`` endpoints, so
that the same ``LLMProvider`` instance behaves normally for every other
caller (background agentic loops, voice, MCP). Other code paths that hit
Anthropic without a real API key will still fail with the original auth
error — that's the desired blast radius.

Token freshness
---------------
We read the credentials file on every call rather than caching, since
Claude Code may rotate the access token. The file is ~470 bytes; the
parse cost is negligible next to the network round-trip to Anthropic.
"""

from __future__ import annotations

import json
import logging
from contextlib import contextmanager
from contextvars import ContextVar
from pathlib import Path
from typing import Iterator

logger = logging.getLogger(__name__)


_CREDENTIALS_PATH = Path.home() / ".claude" / ".credentials.json"

# Set by web-UI endpoints during their request scope. LLMProvider checks
# this; if False (the default), behaviour is identical to before.
_use_subscription: ContextVar[bool] = ContextVar(
    "cognos_use_subscription_auth", default=False,
)


def is_active() -> bool:
    """True if the current async-context is allowed to use the subscription."""
    return _use_subscription.get()


@contextmanager
def subscription_auth_scope() -> Iterator[None]:
    """Enable subscription-OAuth auth for the duration of the ``with`` block.

    Usage (inside a request handler)::

        with subscription_auth_scope():
            reply = await agent.chat(...)
    """
    token = _use_subscription.set(True)
    try:
        yield
    finally:
        _use_subscription.reset(token)


def read_subscription_token() -> str | None:
    """Read the current Claude Code OAuth access token, or None if missing.

    Returns None on any failure (file missing, bad JSON, missing key) so
    callers can fall through gracefully rather than crash.
    """
    try:
        with _CREDENTIALS_PATH.open() as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        logger.debug(f"could not read {_CREDENTIALS_PATH}: {e}")
        return None
    oauth = data.get("claudeAiOauth")
    if not isinstance(oauth, dict):
        return None
    token = oauth.get("accessToken")
    if not isinstance(token, str) or not token:
        return None
    return token
