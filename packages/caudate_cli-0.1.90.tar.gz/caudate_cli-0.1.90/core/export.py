"""Conversation export — dump a session to markdown / JSON / HTML.

Markdown is the default — readable, paste-friendly, diffs cleanly. JSON
is the lossless option (every field round-trips). HTML wraps the markdown
in a minimal, self-contained page so an export can be opened in a
browser without a server.
"""

from __future__ import annotations

import json
from html import escape
from pathlib import Path
from typing import Any

from core.session import Session


def to_markdown(session: Session) -> str:
    out: list[str] = [
        f"# {session.title or 'Cognos session'}",
        f"_id_: `{session.id}` · _model_: `{session.model}` · "
        f"_updated_: {session.updated_at.isoformat(timespec='seconds')}",
        "",
    ]
    for msg in session.messages:
        role = msg.get("role", "?")
        out.append(f"## {role}")
        out.append("")
        content = msg.get("content")
        if isinstance(content, str):
            out.append(content)
        elif isinstance(content, list):
            for block in content:
                if isinstance(block, dict):
                    if block.get("type") == "text":
                        out.append(block.get("text", ""))
                    elif block.get("type") == "image_url":
                        out.append("`<image attachment>`")
                    else:
                        out.append(f"```json\n{json.dumps(block, indent=2)}\n```")
        if msg.get("tool_calls"):
            out.append("")
            out.append("**Tool calls:**")
            for tc in msg["tool_calls"]:
                fn = tc.get("function", {})
                out.append(f"- `{fn.get('name')}({fn.get('arguments', '')})`")
        if msg.get("name") and msg.get("role") == "tool":
            out.append(f"_tool: {msg['name']}_")
        out.append("")
    return "\n".join(out)


def to_json(session: Session) -> str:
    return session.model_dump_json(indent=2)


def to_html(session: Session) -> str:
    md = to_markdown(session)
    body = escape(md).replace("\n", "<br>")
    return (
        "<!doctype html><html><head><meta charset='utf-8'>"
        f"<title>{escape(session.title or session.id)}</title>"
        "<style>body{font-family:ui-monospace,monospace;max-width:880px;"
        "margin:2rem auto;padding:0 1rem;line-height:1.55;color:#eee;"
        "background:#111}h1,h2{color:#fff}code{background:#222;padding:0 .3em;"
        "border-radius:3px}</style></head><body>"
        f"{body}</body></html>"
    )


def export_session(session: Session, path: Path, format: str = "markdown") -> Path:
    """Write the session to `path` in the chosen format. Returns `path`."""
    fmt = format.lower()
    if fmt in ("md", "markdown"):
        text = to_markdown(session)
    elif fmt == "json":
        text = to_json(session)
    elif fmt == "html":
        text = to_html(session)
    else:
        raise ValueError(f"Unknown export format: {format}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return path
