"""Image generation — pluggable backends behind a common interface.

Mirrors `voice/stt.py`'s pattern: a small `ImageGen` protocol, three
concrete backends, and a `make_image_gen(name)` factory. Whichever
backend is in use, the result is the same: a PNG file written to
`data/files/` via the FileStore, returning a `FileRecord` the agent
can reference in subsequent turns.

Backends:

  - **DiffusersImageGen** (default, local) — Hugging Face `diffusers`
    library. Default model is `stabilityai/sdxl-turbo` because it's
    a single-step model that runs on a 6-8GB GPU. Swap to
    `black-forest-labs/FLUX.1-schnell` if you have 24GB+.

  - **ComfyUIImageGen** — HTTP proxy to a running ComfyUI server.
    Uses ComfyUI's `/prompt` API. Good if you already run ComfyUI
    with custom workflows.

  - **LiteLLMImageGen** — cloud APIs via `litellm.aimage_generation`.
    Works with `openai/gpt-image-1`, `dall-e-3`, Stability, etc.
    Requires the relevant API key.

Backends are lazy-loaded — importing this module is cheap; the heavy
torch/diffusers deps only load when you actually call `.generate()`.
"""

from __future__ import annotations

import asyncio
import base64
import io
import json
import logging
import tempfile
import urllib.parse
import urllib.request
import uuid
from pathlib import Path
from typing import Any, Protocol

logger = logging.getLogger(__name__)


class ImageGen(Protocol):
    """Common shape for any image generator."""

    async def generate(
        self,
        prompt: str,
        size: str = "1024x1024",
        negative_prompt: str = "",
        seed: int | None = None,
        steps: int | None = None,
        guidance_scale: float | None = None,
    ) -> bytes:
        """Return PNG bytes for the prompt. Raises on failure."""
        ...


def _parse_size(size: str) -> tuple[int, int]:
    try:
        w, h = size.lower().split("x")
        return int(w), int(h)
    except Exception:
        return 1024, 1024


# --------------------------------------------------------------------
# Diffusers (local)
# --------------------------------------------------------------------


class DiffusersImageGen:
    """Hugging Face diffusers backend.

    Lazy-loads the pipeline on first call. Picks a sensible scheduler
    for the chosen model. Defaults to fp16 on CUDA, fp32 on CPU.
    """

    def __init__(
        self,
        model: str = "stabilityai/sdxl-turbo",
        device: str | None = None,
        dtype: str | None = None,
    ):
        self.model = model
        self._device = device
        self._dtype = dtype
        self._pipe = None

    def _ensure_loaded(self) -> None:
        if self._pipe is not None:
            return
        # Skip transformers' opportunistic TF import — TF is broken/unused
        # here and its import chain corrupts the FluxPipeline class load.
        import os
        os.environ.setdefault("USE_TF", "0")
        os.environ.setdefault("TRANSFORMERS_NO_TF", "1")
        try:
            import torch
            from diffusers import AutoPipelineForText2Image
        except ImportError as e:
            raise RuntimeError(
                "Diffusers backend requested but `diffusers` / `torch` "
                "are not installed. Run: pip install diffusers transformers torch accelerate"
            ) from e

        device = self._device or ("cuda" if torch.cuda.is_available() else "cpu")
        is_flux = "flux" in self.model.lower()
        # FLUX is bf16-native — fp16 produces black/garbled outputs.
        # Other SDXL-class models default to fp16 on CUDA.
        if self._dtype:
            dtype_name = self._dtype
        elif is_flux and device == "cuda":
            dtype_name = "bfloat16"
        elif device == "cuda":
            dtype_name = "float16"
        else:
            dtype_name = "float32"
        torch_dtype = getattr(torch, dtype_name)

        logger.info(f"Loading diffusers pipeline {self.model!r} on {device} ({dtype_name})...")
        # FLUX has no `variant="fp16"` weights on HF — only bf16 / fp32.
        pipe_kwargs: dict[str, Any] = {"torch_dtype": torch_dtype}
        if dtype_name == "float16" and not is_flux:
            pipe_kwargs["variant"] = "fp16"
        pipe = AutoPipelineForText2Image.from_pretrained(self.model, **pipe_kwargs)

        # FLUX-schnell at bf16 nominally needs ~22 GB; in practice
        # `enable_model_cpu_offload()` (component-level offload) still
        # OOMs on a 24 GB 3090 because the transformer + T5 + VAE all
        # peak together. `enable_sequential_cpu_offload()` offloads at
        # the layer/module level — VRAM peak drops to ~12 GB, at the
        # cost of 2-3x slower inference. The only way to run FLUX on
        # this card without OOM until we move to a 32 GB+ GPU.
        if is_flux and device == "cuda":
            pipe.enable_sequential_cpu_offload()
        else:
            pipe = pipe.to(device)
        # SDXL-Turbo and SD-Turbo benefit from disabling the safety checker
        # (rejects too aggressively at single-step) and CFG.
        if "turbo" in self.model.lower():
            pipe.set_progress_bar_config(disable=True)
        self._pipe = pipe
        self._torch_device = device
        logger.info("Diffusers pipeline loaded.")

    async def generate(
        self,
        prompt: str,
        size: str = "1024x1024",
        negative_prompt: str = "",
        seed: int | None = None,
        steps: int | None = None,
        guidance_scale: float | None = None,
    ) -> bytes:
        # Heavy CPU/GPU work — push off the event loop.
        return await asyncio.to_thread(
            self._sync_generate,
            prompt, size, negative_prompt, seed, steps, guidance_scale,
        )

    def _sync_generate(
        self, prompt: str, size: str, negative_prompt: str,
        seed: int | None, steps: int | None, guidance_scale: float | None,
    ) -> bytes:
        import torch
        self._ensure_loaded()
        w, h = _parse_size(size)

        # Defaults tuned per-model family.
        is_turbo = "turbo" in self.model.lower()
        is_flux_schnell = "flux.1-schnell" in self.model.lower()
        if steps is None:
            steps = 1 if is_turbo else (4 if is_flux_schnell else 25)
        if guidance_scale is None:
            guidance_scale = 0.0 if (is_turbo or is_flux_schnell) else 7.5

        kwargs: dict[str, Any] = {
            "prompt": prompt,
            "width": w, "height": h,
            "num_inference_steps": steps,
            "guidance_scale": guidance_scale,
        }
        if negative_prompt and not is_turbo:
            kwargs["negative_prompt"] = negative_prompt
        if seed is not None:
            generator = torch.Generator(device=self._torch_device).manual_seed(int(seed))
            kwargs["generator"] = generator

        result = self._pipe(**kwargs)
        image = result.images[0]
        buf = io.BytesIO()
        image.save(buf, format="PNG")
        return buf.getvalue()


# --------------------------------------------------------------------
# ComfyUI (HTTP proxy)
# --------------------------------------------------------------------


class ComfyUIImageGen:
    """Calls a running ComfyUI server's `/prompt` API.

    Uses a minimal text-to-image workflow: CLIPTextEncode → KSampler →
    VAEDecode → SaveImage. The user can override the workflow JSON via
    `workflow=` for custom checkpoints / LoRAs / ControlNet.
    """

    def __init__(
        self,
        host: str = "http://127.0.0.1:8188",
        checkpoint: str = "sd_xl_base_1.0.safetensors",
        workflow: dict | None = None,
    ):
        self.host = host.rstrip("/")
        self.checkpoint = checkpoint
        self.workflow = workflow

    async def generate(
        self,
        prompt: str,
        size: str = "1024x1024",
        negative_prompt: str = "",
        seed: int | None = None,
        steps: int | None = None,
        guidance_scale: float | None = None,
    ) -> bytes:
        return await asyncio.to_thread(
            self._sync_generate, prompt, size, negative_prompt, seed, steps, guidance_scale,
        )

    def _sync_generate(
        self, prompt: str, size: str, negative_prompt: str,
        seed: int | None, steps: int | None, guidance_scale: float | None,
    ) -> bytes:
        w, h = _parse_size(size)
        seed = seed if seed is not None else int.from_bytes(uuid.uuid4().bytes[:4], "big")
        steps = steps or 20
        guidance_scale = guidance_scale or 7.0

        wf = self.workflow or self._default_workflow(
            prompt, negative_prompt, w, h, seed, steps, guidance_scale, self.checkpoint,
        )
        client_id = uuid.uuid4().hex
        prompt_id = self._post_prompt(wf, client_id)
        return self._fetch_result(prompt_id)

    def _default_workflow(
        self, prompt: str, negative: str, w: int, h: int,
        seed: int, steps: int, cfg: float, checkpoint: str,
    ) -> dict:
        # Standard text-to-image graph in ComfyUI's prompt API format.
        return {
            "3": {"inputs": {"seed": seed, "steps": steps, "cfg": cfg,
                              "sampler_name": "euler", "scheduler": "normal",
                              "denoise": 1, "model": ["4", 0],
                              "positive": ["6", 0], "negative": ["7", 0],
                              "latent_image": ["5", 0]},
                  "class_type": "KSampler"},
            "4": {"inputs": {"ckpt_name": checkpoint},
                  "class_type": "CheckpointLoaderSimple"},
            "5": {"inputs": {"width": w, "height": h, "batch_size": 1},
                  "class_type": "EmptyLatentImage"},
            "6": {"inputs": {"text": prompt, "clip": ["4", 1]},
                  "class_type": "CLIPTextEncode"},
            "7": {"inputs": {"text": negative or "blurry, low quality", "clip": ["4", 1]},
                  "class_type": "CLIPTextEncode"},
            "8": {"inputs": {"samples": ["3", 0], "vae": ["4", 2]},
                  "class_type": "VAEDecode"},
            "9": {"inputs": {"filename_prefix": "cognos", "images": ["8", 0]},
                  "class_type": "SaveImage"},
        }

    def _post_prompt(self, workflow: dict, client_id: str) -> str:
        body = json.dumps({"prompt": workflow, "client_id": client_id}).encode()
        req = urllib.request.Request(
            f"{self.host}/prompt",
            data=body, headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read())
        return data["prompt_id"]

    def _fetch_result(self, prompt_id: str) -> bytes:
        # Poll history endpoint until the run finishes.
        import time
        for _ in range(120):
            time.sleep(0.5)
            with urllib.request.urlopen(
                f"{self.host}/history/{prompt_id}", timeout=10,
            ) as resp:
                data = json.loads(resp.read())
            if not data:
                continue
            run = data.get(prompt_id)
            if not run or "outputs" not in run:
                continue
            for node_out in run["outputs"].values():
                for img in node_out.get("images", []):
                    qs = urllib.parse.urlencode({
                        "filename": img["filename"],
                        "subfolder": img.get("subfolder", ""),
                        "type": img.get("type", "output"),
                    })
                    with urllib.request.urlopen(
                        f"{self.host}/view?{qs}", timeout=30,
                    ) as iresp:
                        return iresp.read()
        raise RuntimeError(f"ComfyUI run {prompt_id} timed out")


# --------------------------------------------------------------------
# LiteLLM cloud
# --------------------------------------------------------------------


class LiteLLMImageGen:
    """Cloud image gen via LiteLLM's image-generation interface.

    Works with model ids like `openai/gpt-image-1`, `dall-e-3`,
    `stability-ai/stable-diffusion-3-large`, etc. The API key for the
    chosen provider must be in the environment.
    """

    def __init__(self, model: str = "openai/gpt-image-1"):
        self.model = model

    async def generate(
        self,
        prompt: str,
        size: str = "1024x1024",
        negative_prompt: str = "",
        seed: int | None = None,
        steps: int | None = None,
        guidance_scale: float | None = None,
    ) -> bytes:
        try:
            import litellm
        except ImportError as e:
            raise RuntimeError("LiteLLM backend requires litellm") from e

        kwargs: dict[str, Any] = {"model": self.model, "prompt": prompt, "size": size}
        if seed is not None:
            kwargs["seed"] = seed
        resp = await litellm.aimage_generation(**kwargs)

        data = resp.data[0]
        if getattr(data, "b64_json", None):
            return base64.b64decode(data.b64_json)
        url = getattr(data, "url", None)
        if url:
            with urllib.request.urlopen(url, timeout=30) as r:
                return r.read()
        raise RuntimeError(f"LiteLLM returned no image bytes or URL: {data}")


# --------------------------------------------------------------------
# Image edit (img2img + instruction)
# --------------------------------------------------------------------


class ImageEdit(Protocol):
    """Common shape for any image editor. Two modes:

    - `reimagine`: img2img — preserves composition, restyles content.
      Strength controls how much to deviate (0=identity, 1=full new).
    - `edit`: instruction — "make the wings blue", "remove the cat",
      etc. The model rewrites only what the instruction describes.
    """

    async def edit(
        self,
        image_bytes: bytes,
        prompt: str,
        mode: str = "reimagine",
        strength: float = 0.75,
        size: str = "1024x1024",
        seed: int | None = None,
        steps: int | None = None,
        guidance_scale: float | None = None,
    ) -> bytes:
        ...


class DiffusersImageEdit:
    """Two-mode FLUX image editor: img2img (FLUX-schnell) + Kontext.

    Each mode lazy-loads its pipeline on first use. They share the
    same `transformer` weights only when both run img2img-style; in
    practice we keep them separate for clarity.
    """

    def __init__(
        self,
        img2img_model: str = "black-forest-labs/FLUX.1-schnell",
        kontext_model: str = "black-forest-labs/FLUX.1-Kontext-dev",
        device: str | None = None,
        dtype: str | None = None,
    ):
        self.img2img_model = img2img_model
        self.kontext_model = kontext_model
        self._device = device
        self._dtype = dtype
        self._img2img_pipe = None
        self._kontext_pipe = None
        self._torch_device: str | None = None

    def _ensure_loaded(self, mode: str) -> Any:
        # Same TF-skip dance as DiffusersImageGen.
        import os
        os.environ.setdefault("USE_TF", "0")
        os.environ.setdefault("TRANSFORMERS_NO_TF", "1")
        import torch

        if mode == "reimagine" and self._img2img_pipe is not None:
            return self._img2img_pipe
        if mode == "edit" and self._kontext_pipe is not None:
            return self._kontext_pipe

        device = self._device or ("cuda" if torch.cuda.is_available() else "cpu")
        # FLUX is bf16-native (fp16 produces black/garbled outputs).
        dtype_name = self._dtype or ("bfloat16" if device == "cuda" else "float32")
        torch_dtype = getattr(torch, dtype_name)
        self._torch_device = device

        if mode == "reimagine":
            from diffusers import FluxImg2ImgPipeline
            logger.info(
                f"Loading FluxImg2ImgPipeline {self.img2img_model!r} "
                f"on {device} ({dtype_name})..."
            )
            pipe = FluxImg2ImgPipeline.from_pretrained(
                self.img2img_model, torch_dtype=torch_dtype,
            )
        elif mode == "edit":
            from diffusers import FluxKontextPipeline
            logger.info(
                f"Loading FluxKontextPipeline {self.kontext_model!r} "
                f"on {device} ({dtype_name})..."
            )
            pipe = FluxKontextPipeline.from_pretrained(
                self.kontext_model, torch_dtype=torch_dtype,
            )
        else:
            raise ValueError(f"Unknown image-edit mode: {mode!r}")

        # Same sequential-CPU-offload as DiffusersImageGen — required
        # for FLUX on a 24 GB 3090 (model_cpu_offload OOMs).
        if device == "cuda":
            pipe.enable_sequential_cpu_offload()
        else:
            pipe = pipe.to(device)

        if mode == "reimagine":
            self._img2img_pipe = pipe
        else:
            self._kontext_pipe = pipe
        logger.info(f"FLUX {mode} pipeline loaded.")
        return pipe

    async def edit(
        self,
        image_bytes: bytes,
        prompt: str,
        mode: str = "reimagine",
        strength: float = 0.75,
        size: str = "1024x1024",
        seed: int | None = None,
        steps: int | None = None,
        guidance_scale: float | None = None,
    ) -> bytes:
        return await asyncio.to_thread(
            self._sync_edit, image_bytes, prompt, mode, strength,
            size, seed, steps, guidance_scale,
        )

    def _sync_edit(
        self, image_bytes: bytes, prompt: str, mode: str,
        strength: float, size: str, seed: int | None,
        steps: int | None, guidance_scale: float | None,
    ) -> bytes:
        import torch
        from PIL import Image

        pipe = self._ensure_loaded(mode)
        w, h = _parse_size(size)
        src = Image.open(io.BytesIO(image_bytes)).convert("RGB")
        # Resize source to target dims; FLUX expects multiples of 8.
        src = src.resize((w - w % 8, h - h % 8), Image.LANCZOS)

        # FLUX-schnell defaults: 4 steps, cfg=0.0. Kontext-dev
        # is non-distilled — needs ~28 steps and cfg=2.5.
        if steps is None:
            steps = 4 if mode == "reimagine" else 28
        if guidance_scale is None:
            guidance_scale = 0.0 if mode == "reimagine" else 2.5

        kwargs: dict[str, Any] = {
            "image": src,
            "prompt": prompt,
            "num_inference_steps": steps,
            "guidance_scale": guidance_scale,
        }
        if mode == "reimagine":
            # img2img has explicit strength
            kwargs["strength"] = max(0.0, min(1.0, float(strength)))
            kwargs["width"] = src.width
            kwargs["height"] = src.height
        # Kontext doesn't take strength — it edits by instruction
        # against the source. Width/height come from the source.

        if seed is not None:
            kwargs["generator"] = torch.Generator(
                device=self._torch_device,
            ).manual_seed(int(seed))

        result = pipe(**kwargs)
        image = result.images[0]
        buf = io.BytesIO()
        image.save(buf, format="PNG")
        return buf.getvalue()


# --------------------------------------------------------------------
# Factory
# --------------------------------------------------------------------


def make_image_gen(name: str = "diffusers", **kwargs: Any) -> ImageGen:
    n = name.lower()
    if n == "diffusers":
        return DiffusersImageGen(**kwargs)
    if n in ("comfyui", "comfy"):
        return ComfyUIImageGen(**kwargs)
    if n in ("litellm", "openai", "cloud"):
        return LiteLLMImageGen(**kwargs)
    raise ValueError(
        f"Unknown image backend: {name!r} "
        "(try 'diffusers', 'comfyui', or 'litellm')"
    )


def make_image_edit(name: str = "diffusers", **kwargs: Any) -> ImageEdit:
    """Construct an image-editor backend. Currently only `diffusers`
    is implemented (FLUX img2img + Kontext)."""
    n = name.lower()
    if n == "diffusers":
        return DiffusersImageEdit(**kwargs)
    raise ValueError(
        f"Unknown image-edit backend: {name!r} (try 'diffusers')"
    )


async def generate_to_file_store(
    backend: ImageGen,
    file_store: Any,
    prompt: str,
    size: str = "1024x1024",
    **kwargs: Any,
) -> Any:
    """Generate an image and persist it via FileStore. Returns FileRecord."""
    png = await backend.generate(prompt, size=size, **kwargs)
    # Hand off to FileStore by writing to a tempfile first; FileStore
    # owns the canonical path under data/files/.
    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
        tmp.write(png)
        tmp_path = Path(tmp.name)
    try:
        slug = "".join(c for c in prompt[:40] if c.isalnum() or c in " _-").strip()
        slug = slug.replace(" ", "_") or "image"
        record = file_store.upload(tmp_path, filename=f"{slug}.png")
    finally:
        tmp_path.unlink(missing_ok=True)
    return record


async def edit_to_file_store(
    backend: ImageEdit,
    file_store: Any,
    image_bytes: bytes,
    prompt: str,
    mode: str = "reimagine",
    **kwargs: Any,
) -> Any:
    """Run an edit and persist the result via FileStore."""
    png = await backend.edit(image_bytes, prompt, mode=mode, **kwargs)
    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
        tmp.write(png)
        tmp_path = Path(tmp.name)
    try:
        slug = "".join(c for c in prompt[:40] if c.isalnum() or c in " _-").strip()
        slug = slug.replace(" ", "_") or "edited"
        record = file_store.upload(tmp_path, filename=f"{slug}_{mode}.png")
    finally:
        tmp_path.unlink(missing_ok=True)
    return record
