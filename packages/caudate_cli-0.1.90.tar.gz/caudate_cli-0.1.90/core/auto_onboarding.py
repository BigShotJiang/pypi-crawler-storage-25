"""Auto-mode first-run onboarding — Claude-Code-style explainer modal.

Shown the first time a user transitions into `PermissionMode.AUTO`
(either via Shift-Tab, `/permissions auto`, or boot-time setting). The
modal explains what auto mode does, warns about cost + safety, and
collects one of four choices matching Claude Code's UX:

  1. Yes, and make it my default mode
  2. Yes, enable auto mode
  3. No, go back
  4. No, don't ask again

The caller decides what to do with the choice (write settings, revert
mode, etc.) — this module is purely the picker.
"""

from __future__ import annotations

import logging
import os
from enum import Enum

logger = logging.getLogger(__name__)

os.environ.setdefault("PROMPT_TOOLKIT_NO_CPR", "1")


class AutoChoice(str, Enum):
    MAKE_DEFAULT = "make_default"
    THIS_SESSION = "this_session"
    GO_BACK      = "go_back"
    NEVER        = "never"


_HEADER_LINES = [
    "  ⏵⏵ Enable auto mode?",
    "",
    "  Caudate will use an LLM classifier to judge each tool call instead",
    "  of asking you. Safe calls run automatically; risky ones are denied",
    "  with a reason so the agent can try a different approach.",
    "",
    "  Cost note: each tool call adds ~1 fast-tier LLM completion. Use only",
    "  in isolated environments — classifiers can make mistakes.",
    "",
]


_OPTIONS = [
    ("Yes, and make it my default mode", AutoChoice.MAKE_DEFAULT),
    ("Yes, enable auto mode",            AutoChoice.THIS_SESSION),
    ("No, go back",                      AutoChoice.GO_BACK),
    ("No, don't ask again",              AutoChoice.NEVER),
]


async def show_auto_onboarding() -> AutoChoice:
    """Render the onboarding modal and return the user's choice.

    Uses prompt_toolkit if the terminal supports it; falls back to
    rich.Prompt on non-TTY or if prompt_toolkit fails. Defaults to
    GO_BACK on Esc / Ctrl-C so an accidental escape never commits the
    user to auto mode.
    """
    import sys

    # Pause the active StreamDisplay so its tickers don't clobber the modal.
    display = None
    try:
        from ui.display import get_active_display
        display = get_active_display()
    except Exception:
        display = None
    if display is not None:
        display.pause()

    try:
        if sys.stdin.isatty():
            try:
                return await _ptk_modal()
            except Exception as e:
                logger.debug(f"auto-onboarding ptk failed: {e}; falling back")
        return _rich_fallback()
    finally:
        if display is not None:
            display.resume()


async def _ptk_modal() -> AutoChoice:
    from prompt_toolkit.application import Application
    from prompt_toolkit.key_binding import KeyBindings
    from prompt_toolkit.layout import HSplit, Layout, Window
    from prompt_toolkit.layout.controls import FormattedTextControl
    from prompt_toolkit.layout.dimension import Dimension as D
    from prompt_toolkit.styles import Style
    from prompt_toolkit.widgets import Frame

    state = {"cursor": 0, "result": None}

    def header_text():
        return [("class:dim", line + "\n") for line in _HEADER_LINES]

    def menu_text():
        out = []
        for i, (label, _) in enumerate(_OPTIONS):
            if i == state["cursor"]:
                out.append(("class:selected", f"  ❯ {i+1}. {label}\n"))
            else:
                out.append(("class:option", f"    {i+1}. {label}\n"))
        return out

    kb = KeyBindings()

    @kb.add("up")
    @kb.add("k")
    def _(event):
        state["cursor"] = (state["cursor"] - 1) % len(_OPTIONS)
        event.app.invalidate()

    @kb.add("down")
    @kb.add("j")
    def _(event):
        state["cursor"] = (state["cursor"] + 1) % len(_OPTIONS)
        event.app.invalidate()

    @kb.add("enter")
    def _(event):
        state["result"] = _OPTIONS[state["cursor"]][1]
        event.app.exit()

    @kb.add("escape")
    @kb.add("c-c")
    def _(event):
        state["result"] = AutoChoice.GO_BACK
        event.app.exit()

    for n, idx in (("1", 0), ("2", 1), ("3", 2), ("4", 3)):
        def make(i):
            def _(event):
                state["result"] = _OPTIONS[i][1]
                event.app.exit()
            return _
        kb.add(n)(make(idx))

    style = Style.from_dict({
        "frame.border": "fg:#5fafff",
        "dim":          "fg:#8a8a8a",
        "selected":     "bold",
        "option":       "",
    })

    body = HSplit([
        Window(FormattedTextControl(header_text),
               height=D(min=len(_HEADER_LINES), max=len(_HEADER_LINES))),
        Window(FormattedTextControl(menu_text),
               height=D(min=len(_OPTIONS), max=len(_OPTIONS))),
    ])
    layout = Layout(Frame(body=body, title="Auto mode"))

    app: Application[None] = Application(
        layout=layout,
        key_bindings=kb,
        style=style,
        full_screen=False,
        mouse_support=False,
    )
    await app.run_async()
    return state["result"] or AutoChoice.GO_BACK


def _rich_fallback() -> AutoChoice:
    """Plain-text fallback for non-TTY or when prompt_toolkit fails."""
    from rich.console import Console
    from rich.prompt import Prompt
    console = Console()
    for line in _HEADER_LINES:
        console.print(line)
    for i, (label, _) in enumerate(_OPTIONS):
        console.print(f"    {i+1}. {label}")
    ans = Prompt.ask(
        "\n  [bold]Pick[/bold]",
        choices=["1", "2", "3", "4"],
        default="3",
    )
    return _OPTIONS[int(ans) - 1][1]
