"""Durable cross-session memory in `data/memory.md`.

A single markdown file the agent (and the user) can both read and write.
Caudate's `memory_write` head predicts whether a turn is memory-worthy;
when she predicts above threshold, the turn's user prompt + a short
summary of the response is appended here. The file's contents get
injected into the system prompt on every turn so the LLM has access
to durable context.

Format: append-only timestamped sections. Lines outside ``...`` blocks
are user-readable; the agent can also be asked to clean it up via the
`update_memory` tool.

Why a flat markdown file (not a vector store):
  - Human-editable: open in a text editor, prune by hand
  - Easy backup / version control
  - Predictable size (capped — newest entries kept, oldest evicted)
  - No reranker / embedding-quality concerns
"""

from __future__ import annotations

import logging
import threading
from datetime import datetime
from pathlib import Path

logger = logging.getLogger(__name__)


_DEFAULT_PATH = Path("data/memory.md")
_MAX_BYTES = 64 * 1024            # ~16K tokens — keep the system-prompt cost bounded
_INJECTION_HEADER = "# Durable memory (from prior sessions)"


class MemoryMd:
    """Thread-safe append + read of memory.md.

    Multiple agent turns / observers can call write() concurrently; an
    internal lock + atomic rename keeps the file consistent.
    """

    def __init__(self, path: Path | str = _DEFAULT_PATH, max_bytes: int = _MAX_BYTES):
        self.path = Path(path)
        self.max_bytes = max_bytes
        self._lock = threading.Lock()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self._write_atomic(
                "# Cognos memory\n\n"
                "_This file is durable across sessions. Caudate appends "
                "high-reward turns here; the agent may also call "
                "`update_memory` to record explicit notes. Edit by hand "
                "to prune._\n\n"
            )

    def read(self) -> str:
        with self._lock:
            try:
                return self.path.read_text()
            except OSError:
                return ""

    def append(self, body: str, *, source: str = "auto", title: str = "") -> None:
        """Append a new memory entry. Trims oldest entries if size cap is hit."""
        if not body or not body.strip():
            return
        ts = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
        title = f" — {title}" if title else ""
        block = f"\n## {ts} ({source}){title}\n\n{body.strip()}\n"

        with self._lock:
            current = ""
            try:
                current = self.path.read_text()
            except OSError:
                pass
            new = current + block
            new = self._trim_to_cap(new)
            self._write_atomic(new)

    def replace(self, content: str) -> None:
        """Wholesale replace — used by the `update_memory` tool when the
        user/LLM wants to re-curate the file."""
        with self._lock:
            self._write_atomic(self._trim_to_cap(content))

    def _trim_to_cap(self, text: str) -> str:
        """Keep newest entries when the file exceeds size cap. Splits on
        section headers so we don't truncate mid-entry."""
        if len(text.encode("utf-8")) <= self.max_bytes:
            return text
        # Split on section headers; keep header + entries from newest end
        # until the cap is satisfied. Always preserve the file preamble
        # (everything before the first `## ` heading).
        marker = "\n## "
        idx = text.find(marker)
        if idx < 0:
            return text[-self.max_bytes:]    # no entries, just truncate raw
        preamble = text[: idx]
        entries = ("## " + part for part in text[idx + 1:].split(marker))
        kept: list[str] = []
        running = len(preamble.encode("utf-8"))
        for entry in reversed(list(entries)):
            blen = len(entry.encode("utf-8"))
            if running + blen > self.max_bytes:
                break
            kept.append(entry)
            running += blen
        return preamble + "\n".join(reversed(kept))

    def _write_atomic(self, content: str) -> None:
        tmp = self.path.with_suffix(".tmp")
        try:
            tmp.write_text(content)
            tmp.replace(self.path)
        except OSError as e:
            logger.warning(f"memory.md write failed: {e}")

    def render_for_system_prompt(self) -> str:
        """Format the whole file for injection into the LLM's system prompt.

        Returns empty string if the file is essentially empty (preamble
        only, no actual entries) so we don't inject useless boilerplate.
        """
        text = self.read()
        if "## " not in text:
            return ""   # only preamble, no real entries yet
        # Strip the preamble's italic blurb — it's only useful to humans
        # opening the file. The LLM just needs the entries.
        idx = text.find("\n## ")
        body = text[idx + 1:] if idx >= 0 else text
        return f"{_INJECTION_HEADER}\n\n{body}".strip()


# ---------------------------------------------------------------------
# Module-level singleton — most callers just want one shared instance
# ---------------------------------------------------------------------

_singleton: MemoryMd | None = None


def get_memory() -> MemoryMd:
    global _singleton
    if _singleton is None:
        _singleton = MemoryMd()
    return _singleton
