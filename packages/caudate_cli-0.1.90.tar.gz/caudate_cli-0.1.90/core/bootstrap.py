"""First-run bootstrap + health checks.

A stranger who runs `pip install caudate-cli` shouldn't have to know
about Ollama, HuggingFace, Anthropic keys, or `data/nn/caudate.pt`.
This module covers the cold-start path:

- `caudate init`   — interactive wizard: picks system1/system2, downloads
                     Caudate weights, writes `~/.caudate/settings.json`,
                     creates a starter sandbox directory.
- `caudate doctor` — read-only diagnostic: which dependencies are wired,
                     which are missing, exact one-line fixes per gap.

Caudate weights live on HuggingFace as a public model repo (set via the
`CAUDATE_HF_REPO` env var, defaulting to `raveuk/cognos-caudate`). The
repo is expected to contain `caudate.pt` and `caudate.meta.json`.
"""

from __future__ import annotations

import json
import os
import shutil
import socket
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm, Prompt
from rich.table import Table


_DEFAULT_HF_REPO = "raveuk/cognos-caudate"
_CAUDATE_FILES = ("caudate.pt", "caudate.meta.json")

# Pinned HuggingFace revision per caudate-cli release. `None` means
# "main branch latest" — bump this to a specific commit SHA or tag when
# you ship a retrain to lock end users to the weights this code was
# tested against. End users can override via `caudate update-caudate
# --revision <sha>` or via the CAUDATE_HF_REVISION env var.
_PINNED_REVISION: str | None = None


# ---------------------------------------------------------------------
# Locations
# ---------------------------------------------------------------------
def cognos_home() -> Path:
    """`~/.caudate`. Created on demand.

    Auto-migrates from the historical `~/.cognos` directory the first
    time the new path is requested — keeps existing users' settings,
    sandbox, and downloaded weights intact across the rebrand.
    """
    home = Path(os.path.expanduser("~"))
    new = home / ".caudate"
    old = home / ".cognos"
    if old.exists() and not new.exists():
        try:
            old.rename(new)
        except Exception:
            new.mkdir(parents=True, exist_ok=True)
    else:
        new.mkdir(parents=True, exist_ok=True)
    return new


def settings_path() -> Path:
    return cognos_home() / "settings.json"


def caudate_dir() -> Path:
    """Where Caudate weights live for an installed caudate-cli.

    Repo checkouts have `<repo>/data/nn/caudate.pt`; pip-installed users
    get `~/.caudate/nn/caudate.pt`.
    """
    p = cognos_home() / "nn"
    p.mkdir(parents=True, exist_ok=True)
    return p


def is_first_run() -> bool:
    return not settings_path().exists()


# ---------------------------------------------------------------------
# Checks
# ---------------------------------------------------------------------
@dataclass
class CheckResult:
    name: str
    ok: bool
    detail: str
    fix: str | None = None


def check_ollama() -> CheckResult:
    """Is Ollama reachable on the default port?"""
    host = os.environ.get("OLLAMA_HOST", "127.0.0.1:11434")
    if "://" in host:
        host = host.split("://", 1)[1]
    h, _, port = host.partition(":")
    port = int(port or "11434")
    try:
        with socket.create_connection((h, port), timeout=1.5):
            pass
        return CheckResult("ollama", True, f"reachable at {h}:{port}")
    except Exception:
        return CheckResult(
            "ollama", False, f"not reachable at {h}:{port}",
            fix="install from https://ollama.com and run `ollama serve`",
        )


def check_caudate() -> CheckResult:
    """Are Caudate weights present *and* loadable?

    Tries the local repo path first, then `~/.caudate/nn/`. Beyond
    presence, it tries to parse `caudate.meta.json` and confirm the
    weight file's shape matches what the installed code expects — a
    "skew guard" so a stale checkpoint after a `pip install -U` gets
    surfaced rather than silently producing garbage predictions.
    """
    repo_pt = Path.cwd() / "data" / "nn" / "caudate.pt"
    user_pt = caudate_dir() / "caudate.pt"
    for pt_path in (repo_pt, user_pt):
        if pt_path.exists():
            meta_path = pt_path.with_suffix(".meta.json")
            mb = pt_path.stat().st_size / 1e6
            # Fresh-init (~40 MB), trained (~62 MB). Anything tiny is
            # almost certainly a corrupt or partial download.
            if mb < 5:
                return CheckResult(
                    "caudate", False, f"{pt_path} is only {mb:.1f} MB — looks corrupt",
                    fix="run `caudate update-caudate` to redownload",
                )
            if not meta_path.exists():
                return CheckResult(
                    "caudate", False, f"{pt_path} present but no caudate.meta.json sidecar",
                    fix="run `caudate update-caudate` to fetch the matching meta",
                )
            # Skew guard: parse meta + try a structural load probe.
            try:
                import json
                meta = json.loads(meta_path.read_text())
                step = meta.get("step")
                arch = meta.get("config") or {}
                d_model = arch.get("d_model", "?")
                n_layers = arch.get("n_layers", "?")
                vocab_sz = arch.get("tool_vocab_size", "?")
                return CheckResult(
                    "caudate", True,
                    f"{pt_path.name} step={step} d_model={d_model} "
                    f"n_layers={n_layers} tool_vocab={vocab_sz} ({mb:.1f} MB)",
                )
            except Exception as e:
                return CheckResult(
                    "caudate", False, f"meta unreadable: {e}",
                    fix="run `caudate update-caudate` to redownload",
                )
    return CheckResult(
        "caudate", False, "no caudate.pt found",
        fix="run `caudate init` (downloads weights from HuggingFace)",
    )


def check_anthropic_key() -> CheckResult:
    if os.environ.get("ANTHROPIC_API_KEY"):
        return CheckResult("anthropic_key", True, "ANTHROPIC_API_KEY set in env")
    return CheckResult(
        "anthropic_key", False, "ANTHROPIC_API_KEY not set",
        fix="export ANTHROPIC_API_KEY=sk-ant-... (only needed if "
            "system1 or system2 is an `anthropic/...` model)",
    )


def check_comfyui() -> CheckResult:
    """Is ComfyUI running? Only needed for the LongCat avatar tool —
    optional, so a failure here is informational not blocking."""
    url = os.environ.get("COGNOS_COMFYUI_URL", "http://127.0.0.1:8188")
    host_port = url.split("://", 1)[1] if "://" in url else url
    host, _, port = host_port.partition(":")
    port = int((port or "8188").split("/")[0])
    try:
        with socket.create_connection((host, port), timeout=1.0):
            pass
        return CheckResult("comfyui", True, f"reachable at {url}  (LongCat backend)")
    except Exception:
        return CheckResult(
            "comfyui", False, f"not running at {url}  (only needed for LongCatAvatar)",
            fix="optional — only matters if you use the `caudate draw`-style "
                "avatar tool. Start ComfyUI separately if you need it.",
        )


def check_settings() -> CheckResult:
    p = settings_path()
    if not p.exists():
        return CheckResult(
            "settings", False, f"{p} missing",
            fix="run `caudate init`",
        )
    try:
        data = json.loads(p.read_text())
        s1 = data.get("system1") or "?"
        s2 = data.get("system2") or "?"
        return CheckResult("settings", True, f"system1={s1}, system2={s2}")
    except Exception as e:
        return CheckResult(
            "settings", False, f"{p} unreadable ({e})",
            fix="delete the file and re-run `caudate init`",
        )


def run_checks() -> list[CheckResult]:
    return [
        check_settings(),
        check_ollama(),
        check_caudate(),
        check_anthropic_key(),
        check_comfyui(),
    ]


# ---------------------------------------------------------------------
# Doctor — read-only diagnostic
# ---------------------------------------------------------------------
def cmd_doctor(console: Console) -> int:
    """Print a status table + fix hints. Returns 0 if all green."""
    results = run_checks()
    table = Table(show_header=True, header_style="bold", expand=False)
    table.add_column("check", style="cyan")
    table.add_column("status")
    table.add_column("detail", style="dim")
    for r in results:
        mark = "[green]✓[/green]" if r.ok else "[red]✗[/red]"
        table.add_row(r.name, mark, r.detail)
    console.print(Panel(table, title="caudate doctor", border_style="cyan"))

    missing = [r for r in results if not r.ok]
    if missing:
        console.print()
        console.print("[bold]fixes:[/bold]")
        for r in missing:
            if r.fix:
                console.print(f"  [yellow]{r.name}[/yellow]: {r.fix}")
        return 1
    console.print("[green]all checks passed[/green]")
    return 0


# ---------------------------------------------------------------------
# Init — interactive wizard
# ---------------------------------------------------------------------
_MODEL_PRESETS = [
    ("local-only",
     "ollama/glm-5.1:cloud", "ollama/qwen3.6:35b",
     "fully local; both brains run on Ollama"),
    ("hybrid",
     "ollama/glm-5.1:cloud", "anthropic/claude-haiku-4-5",
     "local fast, hosted slow (recommended)"),
    ("hosted-only",
     "anthropic/claude-haiku-4-5", "anthropic/claude-opus-4-7",
     "no Ollama needed; requires ANTHROPIC_API_KEY"),
]


def _download_caudate(
    console: Console, repo: str, revision: str | None = None,
) -> bool:
    """Pull caudate.pt + caudate.meta.json from a HF repo into ~/.caudate/nn/.

    `revision` pins to a specific commit SHA or git tag on the HF repo;
    `None` means HEAD of main. Each caudate-cli release sets a pin in
    `_PINNED_REVISION` so a stale install gets the weights it was
    tested with rather than whatever's latest.

    Returns True on success. Best-effort: if `huggingface_hub` isn't
    installed we fall back to printing the manual download URLs.
    """
    target = caudate_dir()
    rev_label = revision or "main"
    try:
        from huggingface_hub import hf_hub_download
    except ImportError:
        console.print(
            f"[yellow]huggingface_hub not installed.[/yellow] Download "
            f"these two files into {target}:"
        )
        for fname in _CAUDATE_FILES:
            console.print(
                f"  https://huggingface.co/{repo}/resolve/{rev_label}/{fname}"
            )
        return False
    try:
        for fname in _CAUDATE_FILES:
            console.print(
                f"  fetching [cyan]{fname}[/cyan] from {repo}@{rev_label}…"
            )
            src = hf_hub_download(
                repo_id=repo, filename=fname, revision=revision,
            )
            shutil.copy2(src, target / fname)
        console.print(f"[green]caudate weights ready at {target}[/green]")
        return True
    except Exception as e:
        console.print(f"[red]download failed:[/red] {e}")
        console.print(
            f"manual fallback — get the files from "
            f"https://huggingface.co/{repo}/tree/{rev_label} and drop them in {target}"
        )
        return False


def cmd_init(console: Console, *, force: bool = False) -> int:
    """Interactive first-run setup."""
    console.print(Panel(
        "[bold]caudate init[/bold] — first-run setup\n"
        "Picks your fast/slow models, downloads Caudate, "
        "writes ~/.caudate/settings.json",
        border_style="cyan",
    ))

    sp = settings_path()
    if sp.exists() and not force:
        if not Confirm.ask(
            f"settings already exist at {sp} — overwrite?", default=False,
        ):
            console.print("[dim]aborted — existing settings preserved[/dim]")
            return 1

    # --- model preset
    console.print("\n[bold]model preset[/bold]")
    table = Table(show_header=True, header_style="bold")
    table.add_column("#", style="cyan")
    table.add_column("name")
    table.add_column("system1 (fast)")
    table.add_column("system2 (slow)")
    table.add_column("notes", style="dim")
    for i, (name, s1, s2, note) in enumerate(_MODEL_PRESETS, 1):
        table.add_row(str(i), name, s1, s2, note)
    console.print(table)
    choice = Prompt.ask(
        "pick a preset (1-3) or [c]ustom", choices=["1", "2", "3", "c"], default="2",
    )
    if choice == "c":
        s1 = Prompt.ask("system1 (fast model)", default="ollama/glm-5.1:cloud")
        s2 = Prompt.ask("system2 (slow model)", default="anthropic/claude-haiku-4-5")
    else:
        _, s1, s2, _ = _MODEL_PRESETS[int(choice) - 1]

    # --- caudate download
    download = Confirm.ask(
        "\ndownload caudate weights (~62 MB) from HuggingFace?", default=True,
    )
    if download:
        repo = os.environ.get("CAUDATE_HF_REPO") or os.environ.get(
            "COGNOS_CAUDATE_HF_REPO", _DEFAULT_HF_REPO,
        )
        revision = os.environ.get("CAUDATE_HF_REVISION") or _PINNED_REVISION
        _download_caudate(console, repo, revision=revision)

    # --- write settings
    settings: dict[str, object] = {"system1": s1, "system2": s2}
    if sp.exists():
        try:
            existing = json.loads(sp.read_text())
            existing.update(settings)
            settings = existing
        except Exception:
            pass
    sp.write_text(json.dumps(settings, indent=2) + "\n")
    console.print(f"\n[green]wrote {sp}[/green]")

    # --- key reminder
    if any("anthropic" in m for m in (s1, s2)) and not os.environ.get("ANTHROPIC_API_KEY"):
        console.print(
            "\n[yellow]heads up:[/yellow] you picked an anthropic model. "
            "set [bold]ANTHROPIC_API_KEY[/bold] in your shell before running."
        )

    console.print("\n[bold]done.[/bold] try `caudate doctor` to verify, then `caudate`.")
    return 0
