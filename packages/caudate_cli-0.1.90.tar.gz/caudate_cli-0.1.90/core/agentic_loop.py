"""Agentic Loop — real-time tool-calling cognitive loop.

The LLM decides which tools to call as it reasons, rather than pre-planning
a DAG. This is the Claude SDK style of agent loop.

Flow:
  1. Append user message to history
  2. Call LLM with tools + history
  3. If response contains tool_calls: execute each, append tool_results, loop
  4. If response contains text only: return final text

Memory systems (episodic/semantic) are consulted once at the start of a turn
and injected as context into the system prompt.
"""

from __future__ import annotations

import logging
from typing import Any, AsyncIterator, Callable

from core.citations import CitationBlock, Document, parse_citations, render_documents_block
from core.compaction import ContextCompactor
from core.failure_patterns import suggest_fix_with_label
from core.files import KIND_IMAGE, FileStore
from core.hooks import HookEvent, HookManager
from core.permissions import PermissionManager
from core.schemas import (
    Episode,
    StreamEvent,
    ThinkingBlock,
    ToolResultBlock,
    ToolResultStatus,
    ToolUseBlock,
)
from core.thinking import ThinkingManager
from execution.executor import Executor
from llm.provider import LLMProvider


def _maybe_prefix_workspace_marker(user_text: str) -> str:
    """Prepend `[Workspace: <cwd>]` to the user message when in cwd
    mode. Keeps the model anchored on the launch directory instead of
    falling back to trained-in defaults like ~/cognos/sandbox/.

    The marker is idempotent — if already present, leave the message
    alone. Skipped when workspace_mode != "cwd" so legacy sandbox
    workflows don't get the marker.
    """
    if not user_text or user_text.startswith("[Workspace: "):
        return user_text
    try:
        from core.settings import Settings
        if (Settings.load().get("workspace_mode") or "cwd").lower() != "cwd":
            return user_text
    except Exception:
        return user_text
    from pathlib import Path as _P
    return f"[Workspace: {_P.cwd()}]\n\n{user_text}"

logger = logging.getLogger(__name__)

MAX_ITERATIONS = 25
MAX_CONSECUTIVE_ERRORS = 3

DEFAULT_SYSTEM_PROMPT = """You are Cognos — a local-first cognitive assistant.

You have access to tools for reading/writing files, running shell commands,
executing Python, searching the web, and thinking. Use them proactively to
accomplish the user's goal. When you have enough information, respond with a
final answer as plain text (no tool call).

Be direct and concise. Do not narrate what you are about to do — just do it.
Prefer the most specific tool for each subtask (e.g. Read over Bash cat).
"""


class AgenticLoop:
    """Real-time tool-calling agent loop."""

    def __init__(
        self,
        llm: LLMProvider,
        executor: Executor,
        episodic=None,
        semantic=None,
        working=None,
        system_prompt: str = DEFAULT_SYSTEM_PROMPT,
        max_iterations: int = MAX_ITERATIONS,
        thinking: bool = False,
        on_thinking=None,
        permissions: PermissionManager | None = None,
        hooks: HookManager | None = None,
        compactor: ContextCompactor | None = None,
        session_id: str | None = None,
        system_prompt_provider: "Callable[[str], str] | None" = None,
        thinking_instruction_wrapper: "Callable[[str], str] | None" = None,
        file_store: FileStore | None = None,
    ):
        self.llm = llm
        self.executor = executor
        self.episodic = episodic
        self.semantic = semantic
        self.working = working
        self.system_prompt = system_prompt
        self.max_iterations = max_iterations
        self.thinking_manager = ThinkingManager(enabled=thinking)
        self.on_thinking = on_thinking  # optional callback(list[ThinkingBlock])
        self.permissions = permissions
        self.hooks = hooks or HookManager()
        self.compactor = compactor
        self.session_id = session_id
        self.system_prompt_provider = system_prompt_provider
        self.thinking_instruction_wrapper = thinking_instruction_wrapper
        self.file_store = file_store
        self.documents: list[Document] = []
        self.last_citations: list[CitationBlock] = []
        self.messages: list[dict[str, Any]] = []
        self._episodes: list[Episode] = []
        self._thinking_log: list[ThinkingBlock] = []
        # Caudate observer — set by CognosAgent if the NN subsystem is
        # available. Stays None for code paths that build AgenticLoop
        # directly (subagents, tests).
        self.caudate = None

    @property
    def thinking(self) -> bool:
        return self.thinking_manager.enabled

    @thinking.setter
    def thinking(self, value: bool) -> None:
        self.thinking_manager.enabled = value

    # ------------------------------------------------------------------
    # Public entry points
    # ------------------------------------------------------------------

    async def run(
        self,
        user_message: str,
        attachments: list[str] | None = None,
        documents: list[Document] | None = None,
    ) -> str:
        """Run the loop to completion and return the final text response.

        `attachments` is a list of file_ids previously registered with
        the FileStore; they are materialized into the user message.

        `documents` is a list of Document objects the model may cite from;
        they are injected into the system prompt and their citation markers
        are parsed out of the response (see self.last_citations).
        """
        self.documents = documents or []
        self.last_citations = []
        self._turn_aborted_by_user = False
        # Phase 1.2: accumulate outcome signals across the turn so we
        # can pass a real reward to Caudate at turn end instead of the
        # success/failure heuristic.
        from core.outcomes import OutcomeCollector
        self._outcome_collector = OutcomeCollector()
        # Phase 3.1: track consecutive errors per tool so a single
        # broken tool can't loop the agent forever. State resets on
        # success of the same tool.
        self._consecutive_errors_by_tool: dict[str, int] = {}
        self._turn_stuck_on_tool: str | None = None
        # Phase 3.2: track consecutive TodoWrites with no real action
        # in between (no Write/Edit/Bash). High count = the model is
        # in a "replanning loop" without producing work. State resets
        # to 0 whenever any non-TodoWrite tool fires.
        self._consecutive_replans: int = 0
        self._turn_stalled: bool = False
        # Phase 3.3: verify-loop state. Track build-relevant Writes
        # + Bash commands so we know when + where to verify. Single-
        # shot per turn — if verify runs and fails, the agent gets
        # one more iteration to fix; on the second verify attempt
        # we don't loop.
        self._turn_wrote_buildable: bool = False
        self._turn_bash_commands: list[str] = []
        self._verifier_attempted: bool = False
        # Phase 3.4: transactional Write snapshot. None when feature
        # is disabled / not in a git repo. Otherwise a TurnTransaction
        # handle that the buildable-write hook stashes against.
        # If a previous turn left a stash hanging, drop it now —
        # /rollback only protects the MOST RECENT turn.
        try:
            from core.transactional_writes import (
                start_turn as _tx_start, commit_turn as _tx_commit,
            )
            import os as _os
            prev_tx = getattr(self, "_tx", None)
            if prev_tx is not None:
                _tx_commit(prev_tx)   # drop the prior stash silently
            self._tx = _tx_start(_os.getcwd())
        except Exception:
            self._tx = None
        await self.hooks.emit(HookEvent.USER_PROMPT_SUBMIT, {"message": user_message})
        self._start_turn(user_message, attachments=attachments or [])
        consecutive_errors = 0
        # Notify Caudate *first* so her top-K is populated before we
        # build the tool list (ADR-0007 constrained routing reads
        # _last_prediction).
        self._notify_caudate_turn_start(user_message)
        tools = self._caudate_constrained_tools(self.executor.tool_definitions())

        for iteration in range(self.max_iterations):
            await self._maybe_compact()
            self._refresh_system_prompt()
            try:
                response = await self.llm.chat(self.messages, tools=tools)
                consecutive_errors = 0
            except Exception as e:
                consecutive_errors += 1
                logger.error(
                    f"LLM error at iteration {iteration} "
                    f"(consecutive={consecutive_errors}): {e}"
                )
                if consecutive_errors >= MAX_CONSECUTIVE_ERRORS:
                    msg = f"(giving up after {consecutive_errors} consecutive LLM errors: {e})"
                    await self.hooks.emit(HookEvent.STOP, {"text": msg, "error": str(e)})
                    return msg
                continue

            # Extract thinking blocks from text
            content, _ = self._extract_thinking(response.content)

            # Append assistant message (use the stripped content)
            self._append_assistant_message(content, response.tool_calls)

            if not response.tool_calls:
                # Phase 3.3: before declaring the turn done, run the
                # verifier if a buildable file was written. If it
                # finds problems, inject feedback as a user message
                # and continue the loop so the model can fix it.
                verifier_feedback = await self._maybe_run_verifier()
                if verifier_feedback is not None:
                    self._inject_verifier_feedback(verifier_feedback)
                    continue
                if self.documents:
                    content, self.last_citations = parse_citations(
                        content, self.documents,
                    )
                await self.hooks.emit(HookEvent.STOP, {"text": content})
                self._notify_caudate_turn_end()
                return content

            # Execute tool calls
            for call in response.tool_calls:
                result_block = await self._execute_call(call)
                # Phase 3.1: track consecutive same-tool errors and
                # augment / abort accordingly. Done BEFORE append so
                # the augmented content is what lands in history.
                result_block = self._apply_error_recovery(call, result_block)
                # Phase 3.2: stall detection (TodoWrite-only loops).
                result_block = self._apply_stall_detection(call, result_block)
                # Phase 3.3: track build activity for the verifier.
                self._track_build_activity(call, result_block)
                self._append_tool_result(result_block)
                self._notify_caudate_tool_use(call.name, was_error=result_block.is_error)
                # Phase 1.2: feed each tool result into the outcome collector
                try:
                    self._outcome_collector.on_tool_result(
                        name=call.name, ok=not result_block.is_error,
                    )
                except Exception:
                    pass
                if self._turn_aborted_by_user:
                    break
                if self._turn_stuck_on_tool is not None:
                    break
                if self._turn_stalled:
                    break

            if self._turn_aborted_by_user:
                try:
                    self._outcome_collector.on_turn_aborted_by_user()
                except Exception:
                    pass
                msg = "(turn aborted: user denied a tool call)"
                await self.hooks.emit(HookEvent.STOP, {"text": msg})
                self._notify_caudate_turn_end()
                return msg

            if self._turn_stuck_on_tool is not None:
                # Phase 3.1: same tool errored 3× in a row. End the
                # turn with a visible message rather than letting the
                # loop drain max_iterations on a broken tool.
                stuck = self._turn_stuck_on_tool
                msg = (
                    f"(turn ended: {stuck} failed 3× consecutively — "
                    "investigate the tool/args before retrying)"
                )
                logger.warning(msg)
                await self.hooks.emit(HookEvent.STOP, {"text": msg})
                self._notify_caudate_turn_end()
                return msg

            if self._turn_stalled:
                # Phase 3.2: model is replanning without producing work.
                msg = (
                    f"(turn ended: {self._consecutive_replans} consecutive "
                    f"TodoWrite calls without any real action — the model "
                    f"was stuck in a planning loop)"
                )
                logger.warning(msg)
                await self.hooks.emit(HookEvent.STOP, {"text": msg})
                self._notify_caudate_turn_end()
                return msg

        logger.warning(f"Agentic loop hit max_iterations={self.max_iterations}")
        try:
            self._outcome_collector.on_hit_max_iterations()
        except Exception:
            pass
        self._notify_caudate_turn_end()  # outcome_collector now drives the reward
        return "(max iterations reached)"

    async def run_streaming(self, user_message: str) -> AsyncIterator[StreamEvent]:
        """Run the loop streaming tokens/events as they arrive."""
        self._turn_aborted_by_user = False
        # Phase 1.2: outcome collector for the streaming path too.
        from core.outcomes import OutcomeCollector
        self._outcome_collector = OutcomeCollector()
        # Phase 3.1: per-tool error counter, same as run() path.
        self._consecutive_errors_by_tool: dict[str, int] = {}
        self._turn_stuck_on_tool: str | None = None
        # Phase 3.2: consecutive-replan counter (TodoWrites without
        # intervening Write/Edit/Bash).
        self._consecutive_replans: int = 0
        self._turn_stalled: bool = False
        # Phase 3.3: verify-loop state (matches run() path).
        self._turn_wrote_buildable: bool = False
        self._turn_bash_commands: list[str] = []
        self._verifier_attempted: bool = False
        # Phase 3.4: same transactional handle as run() path.
        try:
            from core.transactional_writes import (
                start_turn as _tx_start, commit_turn as _tx_commit,
            )
            import os as _os
            prev_tx = getattr(self, "_tx", None)
            if prev_tx is not None:
                _tx_commit(prev_tx)
            self._tx = _tx_start(_os.getcwd())
        except Exception:
            self._tx = None
        self._start_turn(user_message)
        self._notify_caudate_turn_start(user_message)
        tools = self._caudate_constrained_tools(self.executor.tool_definitions())

        for iteration in range(self.max_iterations):
            await self._maybe_compact()
            self._refresh_system_prompt()

            collected_text = ""
            collected_calls: list[ToolUseBlock] = []
            stop_reason: str | None = None

            async for event in self.llm.stream(self.messages, tools=tools):
                if event.type == "text_delta" and event.delta:
                    collected_text += event.delta
                elif event.type == "tool_use_end":
                    collected_calls.append(ToolUseBlock(
                        id=event.tool_use_id or "",
                        name=event.tool_name or "",
                        input=event.tool_input or {},
                    ))
                elif event.type == "message_stop":
                    stop_reason = event.stop_reason
                yield event

            # Strip thinking blocks before persisting to history
            collected_text, _ = self._extract_thinking(collected_text)

            # Append assistant message
            self._append_assistant_message(collected_text, collected_calls)

            if not collected_calls:
                # Phase 3.3: same verifier-injection branch as the
                # non-streaming path. If it returns feedback, append
                # a user-role message and loop again instead of
                # closing the turn.
                verifier_feedback = await self._maybe_run_verifier()
                if verifier_feedback is not None:
                    self._inject_verifier_feedback(verifier_feedback)
                    continue
                self._notify_caudate_turn_end()
                return

            for call in collected_calls:
                result_block = await self._execute_call(call)
                # Phase 3.1: augment/abort on consecutive same-tool errors
                result_block = self._apply_error_recovery(call, result_block)
                # Phase 3.2: stall detection
                result_block = self._apply_stall_detection(call, result_block)
                # Phase 3.3: track build activity
                self._track_build_activity(call, result_block)
                self._append_tool_result(result_block)
                self._notify_caudate_tool_use(call.name, was_error=result_block.is_error)
                try:
                    self._outcome_collector.on_tool_result(
                        name=call.name, ok=not result_block.is_error,
                    )
                except Exception:
                    pass
                yield StreamEvent(
                    type="tool_result",
                    tool_use_id=call.id,
                    delta=str(result_block.content)[:500],
                )
                if self._turn_aborted_by_user:
                    break
                if self._turn_stuck_on_tool is not None:
                    break
                if self._turn_stalled:
                    break

            if self._turn_aborted_by_user:
                try:
                    self._outcome_collector.on_turn_aborted_by_user()
                except Exception:
                    pass
                self._notify_caudate_turn_end()
                yield StreamEvent(
                    type="message_stop",
                    stop_reason="user_aborted",
                )
                return

            if self._turn_stuck_on_tool is not None:
                stuck = self._turn_stuck_on_tool
                logger.warning(
                    f"streaming turn ended: {stuck} failed 3× consecutively"
                )
                self._notify_caudate_turn_end()
                yield StreamEvent(
                    type="message_stop",
                    stop_reason="stuck_on_tool",
                )
                return

            if self._turn_stalled:
                logger.warning(
                    f"streaming turn ended: {self._consecutive_replans} "
                    f"consecutive TodoWrites with no real action"
                )
                self._notify_caudate_turn_end()
                yield StreamEvent(
                    type="message_stop",
                    stop_reason="stalled_on_replan",
                )
                return

        logger.warning(f"Agentic loop (stream) hit max_iterations={self.max_iterations}")
        try:
            self._outcome_collector.on_hit_max_iterations()
        except Exception:
            pass
        self._notify_caudate_turn_end()

    def reset(self) -> None:
        """Clear conversation history (new session)."""
        self.messages = []
        self._episodes = []

    async def _maybe_compact(self) -> None:
        """Run context compaction if enabled and threshold reached."""
        if self.compactor is None:
            return
        if not self.compactor.should_compact(self.messages):
            return
        await self.hooks.emit(HookEvent.PRE_COMPACT, {"count": len(self.messages)})
        self.messages = await self.compactor.compact(self.messages)

    def load_messages(self, messages: list[dict[str, Any]]) -> None:
        """Restore a conversation (e.g. from a saved session)."""
        self.messages = list(messages)

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _start_turn(
        self,
        user_message: str,
        attachments: list[str] | None = None,
    ) -> None:
        """Ensure system prompt is present and append the user message."""
        if not self.messages:
            self.messages.append({
                "role": "system",
                "content": self._build_system_prompt(user_message),
            })

        # Prepend a tiny workspace marker so the model sees the cwd
        # right next to the user's request and doesn't fall back to
        # trained-in default paths (e.g. ~/cognos/sandbox/). Same trick
        # Claude Code uses. Only fires when workspace_mode is cwd.
        prefixed = _maybe_prefix_workspace_marker(user_message)
        user_payload = self._build_user_message(prefixed, attachments or [])
        self.messages.append({"role": "user", "content": user_payload})

    def _build_user_message(
        self,
        text: str,
        attachments: list[str],
    ) -> str | list[dict[str, Any]]:
        """Render the user turn, materializing attachments.

        Returns a plain string if no attachments (or the store is missing),
        otherwise a multimodal content-block list with:
          - extracted text for PDFs / text files (inlined as a text block)
          - image_url blocks for images
          - a final text block with the user's actual message
        """
        if not attachments or self.file_store is None:
            return text

        blocks: list[dict[str, Any]] = []
        for file_id in attachments:
            rec = self.file_store.get(file_id)
            if rec is None:
                blocks.append({
                    "type": "text",
                    "text": f"[attachment {file_id} not found]",
                })
                continue

            if rec.kind == KIND_IMAGE:
                content = self.file_store.to_image_content(file_id)
                if content is not None:
                    blocks.append({
                        "type": "text",
                        "text": f"[image: {rec.filename}]",
                    })
                    blocks.append(content)
                continue

            extracted = self.file_store.extract_text(file_id)
            if extracted:
                blocks.append({
                    "type": "text",
                    "text": f"--- file: {rec.filename} ({rec.kind}) ---\n{extracted}",
                })
            else:
                blocks.append({
                    "type": "text",
                    "text": f"[binary file: {rec.filename} at {rec.path}]",
                })

        blocks.append({"type": "text", "text": text})
        return blocks

    def _build_system_prompt(self, user_message: str) -> str:
        """Compose the full system prompt — base + personality + memory + docs + thinking."""
        base = self.system_prompt
        if self.system_prompt_provider is not None:
            try:
                base = self.system_prompt_provider(base)
            except Exception as e:
                logger.debug(f"system_prompt_provider failed: {e}")

        context = self._memory_context(user_message)
        if context:
            base = f"{base}\n\n# Relevant context\n{context}"

        if self.documents:
            base = f"{base}\n\n{render_documents_block(self.documents)}"

        base = self.thinking_manager.augment_system_prompt(base)
        if self.thinking_manager.enabled and self.thinking_instruction_wrapper is not None:
            try:
                base = self.thinking_instruction_wrapper(base)
            except Exception as e:
                logger.debug(f"thinking_instruction_wrapper failed: {e}")

        # Caudate hint injection — only at WHISPER level or above.
        # Earlier levels stay silent so untrained predictions don't
        # poison the LLM's prompt.
        hint = self._caudate_prompt_hint()
        if hint:
            base = f"{base}\n\n{hint}"
        return base

    def _caudate_prompt_hint(self) -> str:
        """Return a hint block to splice into the system prompt, or empty."""
        if self.caudate is None or not self.caudate.can_whisper():
            return ""
        pred = self.caudate._last_prediction
        if pred is None:
            return ""
        # Don't whisper unless reasonably confident.
        if pred.tool_confidence < self.caudate.cfg.advisor_min_confidence:
            return ""
        level = self.caudate.policy.level.label
        # Tone scales with trust. Whisper = soft hint. Advisor = stronger.
        if self.caudate.can_control():
            preface = (
                "## Caudate (your trained action-selection net) recommends:"
            )
        elif self.caudate.can_advise():
            preface = (
                "## Caudate (advisor) suggests, based on prior sessions:"
            )
        else:
            preface = (
                "## Caudate (whispering — still learning) thinks you might want:"
            )
        return (
            f"{preface}\n"
            f"  next tool:  {pred.tool}      (confidence {pred.tool_confidence:.2f})\n"
            f"  routing:    {pred.tier}      (confidence {pred.tier_confidence:.2f})\n"
            f"  thinking:   {'helpful' if pred.think >= 0.5 else 'not needed'} "
            f"(p={pred.think:.2f})\n"
            f"  expected reward: {pred.value:.2f}\n"
            f"You are free to disagree — Caudate ({level}) has not seen "
            f"this exact context, only patterns from past turns."
        )

    def _refresh_system_prompt(self) -> None:
        """Regenerate the system prompt so dynamic state (mood) stays current."""
        if self.system_prompt_provider is None:
            return
        if not self.messages or self.messages[0].get("role") != "system":
            return
        last_user = next(
            (m.get("content", "") for m in reversed(self.messages) if m.get("role") == "user"),
            "",
        )
        self.messages[0] = {
            "role": "system",
            "content": self._build_system_prompt(last_user),
        }

    def _extract_thinking(self, text: str) -> tuple[str, list[ThinkingBlock]]:
        """Strip <thinking>…</thinking> blocks out of text.

        Logs them to self._thinking_log and fires the on_thinking callback.
        Returns (stripped_text, blocks).
        """
        if not self.thinking_manager.enabled or not text:
            return text, []
        blocks, stripped = self.thinking_manager.parse(text)
        if blocks:
            self._thinking_log.extend(blocks)
            if self.on_thinking:
                try:
                    self.on_thinking(blocks)
                except Exception as e:
                    logger.debug(f"on_thinking callback failed: {e}")
        return stripped, blocks

    @property
    def thinking_log(self) -> list[ThinkingBlock]:
        return list(self._thinking_log)

    def _memory_context(self, query: str) -> str:
        """Pull relevant episodes/knowledge into the system prompt."""
        parts: list[str] = []
        if self.episodic:
            try:
                episodes = self.episodic.recall(query)
                if episodes:
                    parts.append("Past episodes:")
                    for ep in episodes[:3]:
                        outcome = (
                            ep.result.status.value
                            if ep.result else "unknown"
                        )
                        parts.append(f"  - {ep.action} -> {outcome}")
            except Exception as e:
                logger.debug(f"Episodic recall failed: {e}")

        if self.semantic:
            try:
                knowledge = self.semantic.recall(query)
                if knowledge:
                    parts.append("Known facts:")
                    for k in knowledge[:3]:
                        parts.append(f"  - {k.get('content', '')}")
            except Exception as e:
                logger.debug(f"Semantic recall failed: {e}")
        return "\n".join(parts)

    def _append_assistant_message(
        self,
        content: str,
        tool_calls: list[ToolUseBlock],
    ) -> None:
        """Append an assistant message (text + optional tool_calls) to history."""
        msg: dict[str, Any] = {"role": "assistant", "content": content or ""}
        if tool_calls:
            msg["tool_calls"] = [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {
                        "name": tc.name,
                        "arguments": _json_dump(tc.input),
                    },
                }
                for tc in tool_calls
            ]
        self.messages.append(msg)

    def _append_tool_result(self, block: ToolResultBlock) -> None:
        """Append a tool_result message in LiteLLM/OpenAI format."""
        self.messages.append({
            "role": "tool",
            "tool_call_id": block.tool_use_id,
            "content": str(block.content),
        })

    async def _execute_call(self, call: ToolUseBlock) -> ToolResultBlock:
        """Execute one tool call and return a ToolResultBlock."""
        logger.info(f"Tool call: {call.name}({call.input})")

        # PRE_TOOL_USE hook — can block or mutate args
        pre_response = await self.hooks.emit(
            HookEvent.PRE_TOOL_USE,
            {"tool": call.name, "tool_name": call.name, "args": call.input},
        )
        if pre_response.get("block"):
            reason = pre_response.get("reason", "blocked by hook")
            return ToolResultBlock(
                tool_use_id=call.id,
                content=f"Blocked by pre_tool_use hook: {reason}",
                is_error=True,
            )
        if "modified_args" in pre_response:
            call.input = pre_response["modified_args"]

        if self.permissions is not None:
            allowed, reason = await self.permissions.check(call.name, call.input)
            if not allowed:
                # User-driven denial (and ONLY that) aborts the whole
                # turn. Policy / workspace / rule-driven denials still
                # return an error result so the model can recover and
                # retry with a different path.
                if reason.startswith("deny (user)") or reason == "deny (user)":
                    self._turn_aborted_by_user = True
                return ToolResultBlock(
                    tool_use_id=call.id,
                    content=f"Permission denied ({reason})",
                    is_error=True,
                )

        result = await self.executor.execute_tool(call.name, call.input)

        hook_event = (
            HookEvent.POST_TOOL_USE
            if result.status == ToolResultStatus.SUCCESS
            else HookEvent.POST_TOOL_USE_FAILURE
        )
        await self.hooks.emit(hook_event, {
            "tool": call.name,
            "tool_name": call.name,
            "args": call.input,
            "status": result.status.value,
            "output": str(result.output)[:500] if result.output else None,
            "error": result.error,
        })

        is_error = result.status != ToolResultStatus.SUCCESS
        content = result.error if is_error else result.output

        if self.working:
            try:
                self.working.store(f"tool_{call.name}_last", content)
            except Exception:
                pass

        return ToolResultBlock(
            tool_use_id=call.id,
            content=content,
            is_error=is_error,
        )

    # ------------------------------------------------------------------
    # Caudate observer hooks — silent no-ops if caudate is None.
    # The observer is the bridge between this loop and the NN subsystem;
    # see nn/observer.py.
    # ------------------------------------------------------------------

    def _notify_caudate_turn_start(self, user_message: str) -> None:
        if self.caudate is None:
            return
        try:
            recent = []
            for m in self.messages[-self.caudate.cfg.msg_window:]:
                role = m.get("role", "?")
                c = m.get("content")
                if isinstance(c, list):
                    c = " ".join(b.get("text", "") for b in c if isinstance(b, dict))
                if c:
                    recent.append(f"{role}: {str(c)[:400]}")

            # Vision channel: scan recent messages for [file:<id>] markers
            # and resolve any that are images via the FileStore.
            image_paths = self._collect_recent_image_paths()

            # Hand the executor's current tool registry to Caudate so
            # the contrastive tool head has real candidates to score.
            # Without this the head only sees the synthetic <no_tool>
            # slot and the trained discrimination weights stay dormant.
            available_tools = self._caudate_available_tools()

            pred = self.caudate.on_turn_start(
                recent_messages=recent,
                image_paths=image_paths,
                available_tools=available_tools,
            )
            # CONTROLLER level: Caudate gates thinking. If she predicts
            # thinking won't help with high confidence, save the tokens.
            if pred is not None and self.caudate.can_control():
                if pred.think < 0.3 and self.thinking:
                    self.thinking = False
                    logger.info("Caudate disabled thinking for this turn (controller)")
                elif pred.think > 0.7 and not self.thinking:
                    self.thinking = True
                    logger.info("Caudate enabled thinking for this turn (controller)")
        except Exception as e:
            logger.debug(f"caudate.on_turn_start failed: {e}")

    def _collect_recent_image_paths(self) -> list[str]:
        """Pull image-kind file paths off recent messages.

        Two sources:
          1. Multimodal user content blocks of type 'image_url' — these
             carry data: URLs we can't pass to CLIP, so we skip them.
          2. `[file:<uuid>]` markers in either user or assistant text.
             We resolve each id via the FileStore and keep only ones
             whose kind is 'image'.
        """
        if self.file_store is None:
            return []
        import re as _re
        paths: list[str] = []
        seen: set[str] = set()
        marker_re = _re.compile(r"\[file:([a-f0-9-]+)(?:\s+[^\]]+)?\]")
        for m in self.messages[-self.caudate.cfg.msg_window:] if self.caudate else []:
            content = m.get("content")
            if isinstance(content, list):
                content = " ".join(
                    b.get("text", "") for b in content if isinstance(b, dict)
                )
            if not isinstance(content, str):
                continue
            for fid in marker_re.findall(content):
                if fid in seen:
                    continue
                seen.add(fid)
                rec = self.file_store.get(fid)
                if rec is not None and rec.kind == "image":
                    paths.append(rec.path)
        # Cap to image_window so the encoder doesn't pad uselessly.
        if self.caudate is not None:
            paths = paths[-self.caudate.cfg.image_window:]
        return paths

    def _caudate_constrained_tools(self, all_tools: list) -> list:
        """ADR-0007: prune the LLM's tool list to Caudate's top-K when she's
        graduated to ADVISOR+ and is confident about a real tool.

        No-ops (returns ``all_tools`` unchanged) when:
          - Caudate is absent or below ADVISOR
          - No prediction this turn
          - Predicted tool is ``<no_tool>`` or ``<unk>`` (soft-suggest only)
          - Confidence is below ``advisor_min_confidence``
          - Top-K is empty (e.g. checkpoint pre-dates top-K capture)
          - After filtering, fewer than ``advisor_top_k_floor`` tools survive
            (pathological — bail rather than cripple the LLM)
        """
        if self.caudate is None or not self.caudate.can_advise():
            return all_tools
        pred = self.caudate._last_prediction
        if pred is None:
            return all_tools
        if pred.tool in ("<no_tool>", "<unk>"):
            return all_tools
        if pred.tool_confidence < self.caudate.cfg.advisor_min_confidence:
            return all_tools
        if not pred.tool_top_k:
            return all_tools

        cfg = self.caudate.cfg
        k = max(cfg.advisor_top_k, cfg.advisor_top_k_floor)
        keep_names: set[str] = {
            name for name, _ in pred.tool_top_k[:k]
            if name not in ("<no_tool>", "<unk>")
        }
        keep_names.add(pred.tool)  # predicted tool is always visible

        def _tool_name(t: Any) -> str:
            if isinstance(t, dict):
                fn = t.get("function") or {}
                return fn.get("name") or t.get("name") or ""
            return getattr(t, "name", "") or ""

        filtered = [t for t in all_tools if _tool_name(t) in keep_names]
        if len(filtered) < cfg.advisor_top_k_floor:
            logger.debug(
                "Caudate constrained-routing bail: only %d/%d tools survived",
                len(filtered), len(all_tools),
            )
            return all_tools
        logger.info(
            "Caudate pruned tools %d -> %d (pred=%s conf=%.2f)",
            len(all_tools), len(filtered), pred.tool, pred.tool_confidence,
        )
        return filtered

    def _caudate_available_tools(self) -> list:
        """Build the candidate-tool list Caudate scores against.

        Each entry is a ``nn.format.ToolDef`` carrying the tool's name
        plus its human-readable description. The description is what the
        contrastive head's text embedder ingests, so a vague description
        hurts discrimination. Importing ToolDef lazily so an import
        failure on the nn stack doesn't break the agent path.
        """
        try:
            from nn.format import ToolDef
        except Exception:
            return []
        out: list = []
        for tool in self.executor._tools.values():
            try:
                out.append(ToolDef(
                    name=tool.name,
                    description=tool.description or "",
                ))
            except Exception:
                continue
        return out

    # Phase 3.1/3.2: error-recovery + stall-detection thresholds ----
    _ERROR_RETRY_THRESHOLD = 3   # 3.1: after N same-tool errors, end turn
    _STALL_NUDGE_THRESHOLD = 3   # 3.2: after N consecutive replans, nudge
    _STALL_ABORT_THRESHOLD = 6   # 3.2: after M consecutive replans, end turn

    # Tools that count as "real progress" — non-empty TodoWrite resets
    # the stall counter to zero whenever any of these fires.
    _PROGRESS_TOOLS = frozenset({
        "Write", "Edit", "NotebookEdit", "Bash", "PowerShell",
        "PythonExec", "HttpRequest", "Sandbox",
    })

    # Phase 3.3: file extensions that mark a turn as "buildable" so
    # the verifier runs after. Conservative — only fires when the
    # agent wrote runnable code, not docs.
    _BUILDABLE_EXTS = (".py", ".html", ".js", ".ts", ".jsx", ".tsx", ".vue")

    def _track_build_activity(self, call, result_block) -> None:
        """Phase 3.3 + 3.4 bookkeeping: record build-relevant Writes
        and Bash commands so the verifier knows whether to fire + where
        to probe. Also lazily creates the transactional stash on the
        first buildable Write of the turn. Called BEFORE the result
        hits the message history.
        """
        tool_name = getattr(call, "name", "") or ""
        if tool_name in ("Write", "Edit", "NotebookEdit"):
            args = getattr(call, "input", {}) or {}
            path = str(args.get("path") or args.get("file_path") or "")
            if any(path.endswith(ext) for ext in self._BUILDABLE_EXTS):
                self._turn_wrote_buildable = True
                # Phase 3.4: stash on first buildable Write (no-op if
                # feature disabled or not in a git repo).
                try:
                    from core.transactional_writes import stash_if_needed
                    stash_if_needed(self._tx, file_path=path)
                except Exception as e:
                    logger.debug(f"transactional stash hook failed: {e}")
        elif tool_name in ("Bash", "PowerShell"):
            cmd = (getattr(call, "input", {}) or {}).get("command", "")
            if cmd:
                self._turn_bash_commands.append(str(cmd)[:500])

    async def _maybe_run_verifier(self) -> str | None:
        """Phase 3.3: if a buildable file was written this turn AND
        the agent has stopped issuing tool calls (the "I'm done" signal)
        AND we haven't already verified, run the Verifier. Returns:
          - None: verifier skipped / passed → caller proceeds to end
          - str:  failure summary → caller injects + continues loop
        """
        if self._verifier_attempted:
            return None
        if not self._turn_wrote_buildable:
            return None
        # Settings gate (opt-out)
        try:
            from core.settings import Settings
            if not bool(Settings.load().get("auto_verify_after_build", True)):
                return None
        except Exception:
            pass

        self._verifier_attempted = True
        try:
            from core.verifier import Verifier
            from pathlib import Path
            import os
            v = Verifier(cwd=os.getcwd())
            result = v.run(recent_bash_commands=self._turn_bash_commands)
        except Exception as e:
            logger.debug(f"verifier crashed: {e}")
            return None

        # Phase 1.1 cross-link: feed result into the outcome collector
        try:
            if result.ran:
                self._outcome_collector.on_verify_result(passed=result.passed())
                if result.static_404s:
                    self._outcome_collector.on_static_404(count=len(result.static_404s))
        except Exception:
            pass

        if not result.ran:
            logger.debug(f"verifier skipped: {result.skipped_reason}")
            return None
        if result.passed():
            logger.info(f"verifier passed: {result.summary()}")
            return None
        logger.warning(f"verifier failed: {result.summary()}")
        return result.summary()

    def _inject_verifier_feedback(self, summary: str) -> None:
        """Append a synthetic user-role message so the model gets one
        more iteration to address the verifier finding. Uses user role
        because there's no tool_call_id to reply to (the model had
        already emitted a no-tool-calls final message)."""
        self.messages.append({
            "role": "user",
            "content": (
                f"[verifier] Automated post-build check found issues:\n\n"
                f"{summary}\n\n"
                f"Fix the problem(s) above, then confirm the app works."
            ),
        })

    def _apply_stall_detection(self, call, result_block):
        """Phase 3.2: detect TodoWrite-only loops (model replanning
        without producing work) and either nudge or end the turn.

        Reset condition: any tool in _PROGRESS_TOOLS fires.
        Bump condition: TodoWrite fires.
        Everything else (Read, Glob, Grep, AskUserQuestion, etc.)
        leaves the counter unchanged — exploration is OK, replanning-
        without-execution is the bad pattern.
        """
        tool_name = getattr(call, "name", "") or "<unknown>"
        if tool_name in self._PROGRESS_TOOLS:
            self._consecutive_replans = 0
            return result_block
        if tool_name != "TodoWrite":
            # Other read-only / introspection calls don't break the
            # stall pattern but also don't extend it.
            return result_block

        self._consecutive_replans += 1
        n = self._consecutive_replans

        if n >= self._STALL_ABORT_THRESHOLD:
            # End-of-line: the model has replanned this many times
            # with zero actual progress. Surface and stop.
            self._turn_stalled = True
            try:
                orig = str(result_block.content or "")
                result_block.content = (
                    f"{orig}\n\n"
                    f"[STALLED] {n} consecutive TodoWrite calls with no "
                    f"Write/Edit/Bash in between. Ending the turn so "
                    f"the user can redirect."
                )
            except Exception:
                pass
        elif n >= self._STALL_NUDGE_THRESHOLD:
            try:
                orig = str(result_block.content or "")
                result_block.content = (
                    f"{orig}\n\n"
                    f"[stall warning] You've called TodoWrite {n} times in "
                    f"a row without any Write/Edit/Bash. Stop revising "
                    f"the plan — pick the first subtask and START WORKING "
                    f"with a real action (Write a file, run a Bash command). "
                    f"If you genuinely don't know what to do next, "
                    f"surface that to the user."
                )
            except Exception:
                pass
        return result_block

    def _apply_error_recovery(self, call, result_block):
        """Inspect a freshly-executed tool result.

        Mutates the result's content to add a "try-different-approach"
        nudge on the 2nd same-tool error, and sets `_turn_stuck_on_tool`
        on the 3rd so the outer loop ends the turn cleanly.

        Successful results reset the counter for that tool.
        """
        tool_name = getattr(call, "name", "") or "<unknown>"
        if not result_block.is_error:
            # Success — reset counter for this tool
            self._consecutive_errors_by_tool.pop(tool_name, None)
            return result_block

        # Error path: bump counter
        n = self._consecutive_errors_by_tool.get(tool_name, 0) + 1
        self._consecutive_errors_by_tool[tool_name] = n

        # Phase 3.6: known-error → known-fix suggestion. Applied on
        # every error (not just retries) — surfaces the hint as early
        # as the 1st failure so the model can fix on the next call
        # instead of waiting for the retry-guidance threshold.
        try:
            err_text = str(result_block.content or "")
            hit = suggest_fix_with_label(err_text)
            if hit is not None:
                label, hint = hit
                result_block.content = (
                    f"{err_text}\n\n"
                    f"<auto-fix-suggestion category=\"{label}\">\n"
                    f"{hint}\n"
                    f"</auto-fix-suggestion>"
                )
        except Exception as e:
            logger.debug(f"failure-pattern hint failed: {e}")

        if n >= self._ERROR_RETRY_THRESHOLD:
            # End-of-line: surface to user, end turn after this iteration
            self._turn_stuck_on_tool = tool_name
            # Augment content so the conversation history shows why we stopped
            try:
                orig = str(result_block.content or "")
                result_block.content = (
                    f"{orig}\n\n"
                    f"[STUCK] This tool has failed {n} times in a row. "
                    f"Ending the turn so the user can investigate."
                )
            except Exception:
                pass
        elif n >= 2:
            # 2nd error — augment with a "try differently" hint
            try:
                orig = str(result_block.content or "")
                result_block.content = (
                    f"{orig}\n\n"
                    f"[retry guidance] {tool_name} has now failed {n} "
                    f"times in this turn. Don't repeat the same call "
                    f"verbatim — try a different approach: change args, "
                    f"use a different tool, or ask the user."
                )
            except Exception:
                pass
        return result_block

    def _notify_caudate_tool_use(self, tool_name: str, was_error: bool) -> None:
        if self.caudate is None:
            return
        try:
            self.caudate.on_tool_use(tool_name, thinking_used=self.thinking)
        except Exception as e:
            logger.debug(f"caudate.on_tool_use failed: {e}")
        # Per-tool reward signal: a failure now reduces this turn's
        # observed reward when the turn ends.
        if was_error and self.caudate is not None and self.caudate._pending is not None:
            self.caudate._pending.tier_used = self.caudate._pending.tier_used  # noop
            # mark a transient failure so on_turn_end can read it
            setattr(self.caudate._pending, "_had_error", True)

    def _notify_caudate_turn_end(self, reward: float | None = None) -> None:
        if self.caudate is None:
            return
        # Phase 1.2: drain the outcome collector. When signals fired,
        # pass `outcome_reward ∈ [-1, +1]` and let the observer derive
        # its native [0, 1] reward. When no signals fired (e.g. plain
        # chat turn), fall back to the legacy heuristic.
        outcome_reward = None
        try:
            coll = getattr(self, "_outcome_collector", None)
            if coll is not None:
                sig = coll.finalize()
                if sig.is_informative():
                    outcome_reward = sig.reward()
                    logger.debug(f"caudate outcome signal: {sig.summary()}")
        except Exception as e:
            logger.debug(f"outcome collector finalize failed: {e}")

        try:
            if outcome_reward is None and reward is None and self.caudate._pending is not None:
                # Legacy heuristic if neither outcome signals nor an
                # explicit reward are available: 0.7 default, 0.3 if
                # any tool errored mid-turn.
                had_err = getattr(self.caudate._pending, "_had_error", False)
                reward = 0.3 if had_err else 0.7
            self.caudate.on_turn_end(reward=reward, outcome_reward=outcome_reward)
        except Exception as e:
            logger.debug(f"caudate.on_turn_end failed: {e}")


def _json_dump(obj: Any) -> str:
    import json
    try:
        return json.dumps(obj)
    except (TypeError, ValueError):
        return json.dumps(str(obj))
