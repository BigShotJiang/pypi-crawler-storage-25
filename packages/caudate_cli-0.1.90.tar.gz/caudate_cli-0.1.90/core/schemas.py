"""Core data schemas for the Cognos cognitive architecture."""

from __future__ import annotations

import uuid
from datetime import datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


def _uuid() -> str:
    return str(uuid.uuid4())


def _now() -> datetime:
    return datetime.utcnow()


# --- Enums ---

class TaskStatus(str, Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    BLOCKED = "blocked"


class GoalStatus(str, Enum):
    ACTIVE = "active"
    ACHIEVED = "achieved"
    FAILED = "failed"
    ABANDONED = "abandoned"


class ToolResultStatus(str, Enum):
    SUCCESS = "success"
    ERROR = "error"
    TIMEOUT = "timeout"


# --- Core Models ---

class Goal(BaseModel):
    """A high-level objective the agent is trying to achieve."""
    id: str = Field(default_factory=_uuid)
    description: str
    success_criteria: list[str] = Field(default_factory=list)
    status: GoalStatus = GoalStatus.ACTIVE
    created_at: datetime = Field(default_factory=_now)
    context: dict[str, Any] = Field(default_factory=dict)


class Task(BaseModel):
    """A concrete, executable step within a plan."""
    id: str = Field(default_factory=_uuid)
    goal_id: str
    description: str
    tool_name: str | None = None
    tool_args: dict[str, Any] = Field(default_factory=dict)
    dependencies: list[str] = Field(default_factory=list)  # task IDs
    status: TaskStatus = TaskStatus.PENDING
    result: Any = None
    error: str | None = None
    attempts: int = 0
    created_at: datetime = Field(default_factory=_now)


class Plan(BaseModel):
    """A structured plan: a DAG of tasks to achieve a goal."""
    id: str = Field(default_factory=_uuid)
    goal_id: str
    tasks: list[Task] = Field(default_factory=list)
    reasoning: str = ""
    version: int = 1
    created_at: datetime = Field(default_factory=_now)

    def get_ready_tasks(self) -> list[Task]:
        """Return tasks whose dependencies are all completed."""
        completed_ids = {t.id for t in self.tasks if t.status == TaskStatus.COMPLETED}
        return [
            t for t in self.tasks
            if t.status == TaskStatus.PENDING
            and all(dep in completed_ids for dep in t.dependencies)
        ]

    def is_complete(self) -> bool:
        return all(t.status == TaskStatus.COMPLETED for t in self.tasks)

    def has_failed(self) -> bool:
        return any(t.status == TaskStatus.FAILED for t in self.tasks)


class ToolResult(BaseModel):
    """Result of executing a tool."""
    tool_name: str
    status: ToolResultStatus
    output: Any = None
    error: str | None = None
    duration_ms: float = 0


class Episode(BaseModel):
    """A recorded experience: what happened when the agent did something."""
    id: str = Field(default_factory=_uuid)
    goal_id: str
    task_id: str
    action: str
    tool_name: str | None = None
    tool_args: dict[str, Any] = Field(default_factory=dict)
    result: ToolResult | None = None
    context: dict[str, Any] = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=_now)


class Reflection(BaseModel):
    """Agent's self-evaluation of an action or plan."""
    id: str = Field(default_factory=_uuid)
    episode_id: str | None = None
    goal_id: str
    score: float = 0.0  # 0.0 to 1.0
    what_happened: str = ""
    what_worked: str = ""
    what_failed: str = ""
    lesson: str = ""
    should_replan: bool = False
    replan_reason: str = ""
    timestamp: datetime = Field(default_factory=_now)


class Strategy(BaseModel):
    """A learned strategy or heuristic from past experience."""
    id: str = Field(default_factory=_uuid)
    name: str
    description: str
    conditions: str  # when to apply this strategy
    actions: str  # what to do
    confidence: float = 0.5  # 0.0 to 1.0
    times_used: int = 0
    times_succeeded: int = 0
    created_at: datetime = Field(default_factory=_now)
    updated_at: datetime = Field(default_factory=_now)


class Perception(BaseModel):
    """The agent's current understanding of its situation."""
    goal: Goal
    plan: Plan | None = None
    working_memory: dict[str, Any] = Field(default_factory=dict)
    relevant_episodes: list[Episode] = Field(default_factory=list)
    relevant_knowledge: list[str] = Field(default_factory=list)
    active_strategies: list[Strategy] = Field(default_factory=list)


# --- Message Content Blocks (Claude SDK style) ---

class TextBlock(BaseModel):
    """A plain text block from the model."""
    type: str = "text"
    text: str


class ThinkingBlock(BaseModel):
    """A thinking/reasoning block — internal chain-of-thought."""
    type: str = "thinking"
    thinking: str


class ToolUseBlock(BaseModel):
    """The model's request to invoke a tool."""
    type: str = "tool_use"
    id: str = Field(default_factory=_uuid)
    name: str
    input: dict[str, Any] = Field(default_factory=dict)


class ToolResultBlock(BaseModel):
    """The result of a tool execution, sent back to the model."""
    type: str = "tool_result"
    tool_use_id: str
    content: Any = None
    is_error: bool = False


# --- Stream Events (for async streaming) ---

class StreamEvent(BaseModel):
    """An event emitted during streaming LLM output.

    type: one of "text_delta", "thinking_delta", "tool_use_start",
          "tool_use_delta", "tool_use_end", "message_start", "message_stop"
    """
    type: str
    delta: str | None = None
    block_index: int | None = None
    tool_use_id: str | None = None
    tool_name: str | None = None
    tool_input: dict[str, Any] | None = None
    stop_reason: str | None = None
    raw: dict[str, Any] = Field(default_factory=dict)
