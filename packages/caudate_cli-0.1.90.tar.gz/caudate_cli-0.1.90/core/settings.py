"""Settings hierarchy — defaults < user (~/.cognos/settings.json) < project (.cognos/settings.json).

Each layer is a JSON object. Later layers shallow-merge over earlier ones.
The merged result is exposed as a `Settings` mapping that the rest of the
codebase can consult without caring where a value came from.

This intentionally mirrors Claude Code's settings model: project-level
overrides are committed to a repo so a team shares them; user-level
overrides are per-machine. Defaults are baked in here so a brand-new
clone with no settings files still works.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


# Built-in defaults. Anything here can be overridden by a settings file.
DEFAULTS: dict[str, Any] = {
    "model": None,                          # falls back to config.LLM_MODEL
    "permission_mode": "default",
    "permissions": {                        # rule lists for /permissions
        "allow": [],                        # [{"tool": "Bash", "pattern": "^ls"}]
        "deny": [],
    },
    "statusline": "{model} | {mode} | session={session_short} | tok={tokens} | ${cost:.4f}",
    "personality": True,
    "thinking": False,
    "stream": True,
    "system1": "ollama/glm-5.1:cloud",
    "system2": "anthropic/claude-haiku-4-5",
    "fallback_models": [],                  # ordered list, tried on failure
    "notifications": {
        "enabled": True,
        "on_long_task_seconds": 30,         # notify if a tool/turn exceeds this
        "on_permission_ask": True,
    },
    "cron_jobs_path": "data/cron.json",
    "background_tasks_path": "data/bg_tasks.json",
    "ide_api_url": "http://127.0.0.1:8000",
}


def _user_settings_path() -> Path:
    """Prefer `~/.caudate/settings.json`; fall back to legacy `~/.cognos/`
    only when the new path doesn't exist."""
    new = Path.home() / ".caudate" / "settings.json"
    if new.exists():
        return new
    old = Path.home() / ".cognos" / "settings.json"
    if old.exists():
        return old
    return new


def _project_settings_path() -> Path:
    # We anchor on the cwd so each project can have its own settings.
    new = Path.cwd() / ".caudate" / "settings.json"
    if new.exists():
        return new
    old = Path.cwd() / ".cognos" / "settings.json"
    if old.exists():
        return old
    return new


def _read(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text())
    except Exception as e:
        logger.warning(f"Failed to read settings at {path}: {e}")
        return {}


def _deep_merge(base: dict[str, Any], over: dict[str, Any]) -> dict[str, Any]:
    """Shallow-merge top-level keys; recursively merge nested dicts."""
    out = dict(base)
    for key, value in over.items():
        if (
            key in out
            and isinstance(out[key], dict)
            and isinstance(value, dict)
        ):
            out[key] = _deep_merge(out[key], value)
        else:
            out[key] = value
    return out


class Settings:
    """Read-only view of the merged settings hierarchy."""

    def __init__(self, data: dict[str, Any], sources: list[Path]):
        self._data = data
        self._sources = sources

    def get(self, key: str, default: Any = None) -> Any:
        return self._data.get(key, default)

    def __getitem__(self, key: str) -> Any:
        return self._data[key]

    def __contains__(self, key: str) -> bool:
        return key in self._data

    def as_dict(self) -> dict[str, Any]:
        return dict(self._data)

    def sources(self) -> list[Path]:
        """Files that contributed (in merge order)."""
        return list(self._sources)

    @classmethod
    def load(cls) -> "Settings":
        sources: list[Path] = []
        merged = dict(DEFAULTS)
        for path in (_user_settings_path(), _project_settings_path()):
            if path.exists():
                merged = _deep_merge(merged, _read(path))
                sources.append(path)
        return cls(merged, sources)


def write_user_setting(key: str, value: Any) -> None:
    """Persist a single key to the user-level settings file."""
    path = _user_settings_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    current = _read(path)
    current[key] = value
    path.write_text(json.dumps(current, indent=2))


def write_project_setting(key: str, value: Any) -> None:
    """Persist a single key to the project-level settings file."""
    path = _project_settings_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    current = _read(path)
    current[key] = value
    path.write_text(json.dumps(current, indent=2))


def append_allow_rule(rule: dict[str, Any]) -> None:
    """Append a permission allow-rule to the user settings file, dedup'd."""
    path = _user_settings_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    current = _read(path)
    perms = current.setdefault("permissions", {})
    allow = perms.setdefault("allow", [])
    if rule not in allow:
        allow.append(rule)
        path.write_text(json.dumps(current, indent=2))


def append_deny_rule(rule: dict[str, Any]) -> None:
    """Append a permission deny-rule to the user settings file, dedup'd."""
    path = _user_settings_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    current = _read(path)
    perms = current.setdefault("permissions", {})
    deny = perms.setdefault("deny", [])
    if rule not in deny:
        deny.append(rule)
        path.write_text(json.dumps(current, indent=2))
