"""Permission system — control tool execution with modes and rules.

Modes:
  - DEFAULT: prompt the user before executing destructive or sensitive tools
  - PLAN: read-only — reject any tool that mutates state
  - ACCEPT_EDITS: auto-approve file writes/edits but still prompt for Bash
  - BYPASS: skip every check (dangerous; for trusted contexts)

Rules:
  - allow: tool+regex-on-args patterns that auto-approve
  - deny: tool+regex-on-args patterns that auto-reject

All decisions are written to an audit log (JSONL).
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Callable

# Suppress prompt_toolkit's "your terminal doesn't support CPR" line.
# Must be set BEFORE any prompt_toolkit Output is constructed; importing
# this module early in main.py guarantees that.
os.environ.setdefault("PROMPT_TOOLKIT_NO_CPR", "1")

logger = logging.getLogger(__name__)


class PermissionMode(str, Enum):
    DEFAULT = "default"
    AUTO = "auto"           # LLM classifier decides safe/risky per call
    PLAN = "plan"
    ACCEPT_EDITS = "accept_edits"
    BYPASS = "bypass"


class PermissionDecision(str, Enum):
    ALLOW = "allow"
    DENY = "deny"
    ASK = "ask"


# Which tools are considered mutating / sensitive / safe.
_SENSITIVE = {"Bash", "PythonExec"}
_MUTATING = {"Write", "Edit"}
_READONLY = {
    "Read", "Glob", "Grep", "WebSearch", "WebFetch", "Think", "Respond",
    # Agent-internal / UI-only tools with no FS or network side effects.
    "TodoWrite", "AskUserQuestion", "ExitPlanMode",
}


# Bash commands that are pure reads / introspection. Matches Claude
# Code + opencode behavior: the user shouldn't be prompted for benign
# lookups like `which yt-dlp` or `git status`.
_SAFE_BASH_BINARIES = frozenset({
    "cd", "pushd", "popd", "export", "unset", "set",  # shell-local, no FS write
    "which", "command", "type", "hash",
    "ls", "ll", "la", "tree",
    "cat", "head", "tail", "less", "more", "tac", "nl",
    "wc", "file", "stat", "readlink", "realpath", "basename", "dirname",
    "pwd", "echo", "printf", "true", "false", "yes", "test", "[", "[[",
    "whoami", "id", "uname", "hostname", "date", "uptime", "tty",
    "env", "printenv", "locale",
    "ps", "pgrep", "pidof", "df", "du", "free", "lscpu", "lsblk", "lsof",
    "grep", "egrep", "fgrep", "rg", "ack",
    "find", "fd", "locate",
    "diff", "cmp", "sort", "uniq", "cut", "awk", "sed", "tr", "tee",
    "jq", "yq", "xmllint",
    "git",          # gated below — only read-only subcommands
    "pip", "pip3",  # gated below — only show/list/search
    "npm", "pnpm", "yarn",  # gated below — only list/view
    "cargo",        # gated below — only metadata
    "python", "python3", "node",  # gated — only --version / -V
})

# git subcommands that are read-only.
_SAFE_GIT_SUBCMDS = frozenset({
    "status", "log", "diff", "show", "branch", "tag",
    "ls-files", "ls-tree", "ls-remote", "rev-parse", "rev-list",
    "config", "remote", "describe", "blame", "reflog", "shortlog",
    "stash",  # stash list/show ok; stash pop is mutating — gated further below
    "for-each-ref", "cat-file", "name-rev", "merge-base", "symbolic-ref",
    "help", "version", "fetch",  # fetch is network-read; safe enough
})

# Package-manager subcommands that don't mutate state.
_SAFE_PIP_SUBCMDS = frozenset({"show", "list", "search", "freeze", "config", "check", "--version"})
_SAFE_NPM_SUBCMDS = frozenset({"list", "ls", "view", "info", "show", "outdated", "--version", "-v"})
_SAFE_CARGO_SUBCMDS = frozenset({"metadata", "tree", "search", "info", "--version", "-V"})


def _is_safe_bash(command: str) -> bool:
    """Return True if a shell command is provably read-only / introspective.

    The check is intentionally conservative: any segment we can't classify
    causes us to fall back to ASK. We split on `;`, `&&`, `||`, `|`, newlines
    and inspect the binary at the start of each segment.
    """
    if not command or not isinstance(command, str):
        return False

    # Block anything that could write files via redirection, command
    # substitution, or process substitution. `2>/dev/null` and `1>&2`
    # are common in read-only commands, so we allow those specifically.
    stripped = command
    # Strip safe stderr redirections.
    import re as _re
    stripped = _re.sub(r"2>\s*/dev/null", "", stripped)
    stripped = _re.sub(r"2>&1", "", stripped)
    stripped = _re.sub(r"1>&2", "", stripped)
    stripped = _re.sub(r"</?dev/null", "", stripped)

    forbidden = ["$(", "`", ">>", " > ", ">/", "<(", ">(", " tee ", "sudo "]
    # Leading `sudo` always asks — that's a power escalation.
    for marker in forbidden:
        if marker in stripped:
            return False
    # A trailing `>` at end of string is also a write.
    if stripped.rstrip().endswith(">"):
        return False

    # Mask quoted substrings so operator chars (`|`, `;`, `&`) inside
    # them aren't treated as segment separators. e.g.
    #   grep -iE "yt-dlp|youtube|flask"
    # should split into a single segment, not three.
    def _mask_quoted(s: str) -> str:
        out = []
        i = 0
        while i < len(s):
            ch = s[i]
            if ch in ("'", '"'):
                quote = ch
                j = i + 1
                while j < len(s) and s[j] != quote:
                    if s[j] == "\\" and j + 1 < len(s):
                        j += 2
                        continue
                    j += 1
                # Replace the quoted region (including quotes) with an
                # equal-length string of placeholder chars to keep
                # offsets stable.
                out.append(quote)
                out.append("X" * max(0, j - i - 1))
                if j < len(s):
                    out.append(quote)
                i = j + 1
            else:
                out.append(ch)
                i += 1
        return "".join(out)

    masked = _mask_quoted(stripped)
    segments = _re.split(r"(?:\|\||&&|;|\||\n)", masked)
    for seg in segments:
        seg = seg.strip()
        if not seg:
            continue
        # First whitespace-separated token is the binary (after stripping
        # env-var prefixes like `FOO=bar baz`).
        tokens = seg.split()
        i = 0
        while i < len(tokens) and "=" in tokens[i] and not tokens[i].startswith("-"):
            # Skip env assignments like `KEY=val`.
            i += 1
        if i >= len(tokens):
            return False
        binary = tokens[i]
        # Strip a leading path: /usr/bin/which → which.
        binary_name = binary.rsplit("/", 1)[-1]
        if binary_name not in _SAFE_BASH_BINARIES:
            return False

        # Gate multi-purpose binaries on their subcommand.
        sub = tokens[i + 1] if i + 1 < len(tokens) else ""
        if binary_name == "git":
            if sub not in _SAFE_GIT_SUBCMDS:
                return False
            # Block `git stash pop|apply|drop|clear`.
            if sub == "stash":
                next_arg = tokens[i + 2] if i + 2 < len(tokens) else "list"
                if next_arg not in ("list", "show"):
                    return False
        elif binary_name in ("pip", "pip3"):
            if sub not in _SAFE_PIP_SUBCMDS:
                return False
        elif binary_name in ("npm", "pnpm", "yarn"):
            if sub not in _SAFE_NPM_SUBCMDS:
                return False
        elif binary_name == "cargo":
            if sub not in _SAFE_CARGO_SUBCMDS:
                return False
        elif binary_name in ("python", "python3", "node"):
            # Only allow version checks; `python -c '…'` could do anything.
            if sub not in ("--version", "-V", "-v"):
                return False
        elif binary_name == "find":
            # Block `find -delete` and `find -exec …`.
            joined = " ".join(tokens[i + 1 :])
            if "-delete" in joined or "-exec" in joined or "-execdir" in joined or "-ok" in joined:
                return False
        elif binary_name in ("sed", "awk"):
            # In-place edits write files.
            joined = " ".join(tokens[i + 1 :])
            if "-i" in tokens[i + 1 :] or "--in-place" in joined:
                return False
        elif binary_name == "tee":
            # tee always writes — only allowed if redirected to /dev/null,
            # which we'd never see in agent calls. Treat as unsafe.
            return False

    return True


class PermissionRule:
    """A single allow/deny rule. Matches a tool name + optional arg pattern.

    Pattern is a regex string. Bash patterns are commonly of the form
    `^pip\\b`, `^git status\\b` etc. — anchored at the start of the
    command. The serialized form mirrors Claude Code's syntax:
    `Bash(pip:*)` -> tool="Bash", pattern="^pip\\b".
    """

    def __init__(self, tool: str, pattern: str | None = None):
        self.tool = tool
        self.pattern_src = pattern
        self.pattern = re.compile(pattern) if pattern else None

    def matches(self, tool: str, args: dict[str, Any]) -> bool:
        if tool != self.tool and self.tool != "*":
            return False
        if self.pattern is None:
            return True
        # Bash and shell-like tools: match against the `command` string.
        # Other tools: match against a representative arg value (path).
        haystack = _haystack_for(tool, args)
        return bool(self.pattern.search(haystack))

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {"tool": self.tool}
        if self.pattern_src is not None:
            out["pattern"] = self.pattern_src
        return out

    def display(self) -> str:
        """Claude-Code-style display string: `Bash(pip:*)`, `Read(/foo)`."""
        if not self.pattern_src:
            return self.tool
        p = self.pattern_src
        # `^head\b`  -> `head:*`
        # `^head\s+sub\b` -> `head sub:*`
        # `^/some/path$` -> `/some/path`
        if p.startswith("^") and p.endswith(r"\b"):
            inner = p[1:-2]
            inner = inner.replace(r"\s+", " ").replace("\\", "")
            return f"{self.tool}({inner}:*)"
        if p.startswith("^") and p.endswith("$"):
            inner = p[1:-1].replace("\\", "")
            return f"{self.tool}({inner})"
        return f"{self.tool}({p})"


_FORBIDDEN_WORKSPACE_FRAGMENTS = ("/cognos/sandbox/",)


def _workspace_mode_cached() -> str:
    try:
        from core.settings import Settings
        return (Settings.load().get("workspace_mode") or "cwd").lower()
    except Exception:
        return "cwd"


def _violates_workspace_at_permission_layer(tool: str, args: dict[str, Any]) -> bool:
    """Return True if this tool call writes into a forbidden default
    path under workspace_mode=cwd. Read-only tools are never blocked.
    """
    if _workspace_mode_cached() != "cwd":
        return False

    if tool in ("Write", "Edit"):
        path = ""
        for k in ("file_path", "path", "filename"):
            if k in args and isinstance(args[k], str):
                path = args[k]
                break
        norm = path.replace("\\", "/")
        return any(frag in norm for frag in _FORBIDDEN_WORKSPACE_FRAGMENTS)

    if tool in ("Bash", "PowerShell"):
        cmd = str(args.get("command", ""))
        if not any(frag in cmd for frag in _FORBIDDEN_WORKSPACE_FRAGMENTS):
            return False
        # Only block write-intent commands; reads are fine.
        write_markers = ("mkdir", "touch", "cp ", " mv ", "rm ", " tee ", ">", ">>", "ln ")
        return any(m in cmd for m in write_markers)

    return False


def _haystack_for(tool: str, args: dict[str, Any]) -> str:
    """Build the string a rule's regex matches against."""
    if tool in ("Bash", "PowerShell", "PythonExec"):
        return str(args.get("command", "") or args.get("code", ""))
    # File tools: match against the path so `Read(/tmp/.env)` works.
    for k in ("file_path", "path", "filename"):
        if k in args:
            return str(args[k])
    # Fallback: JSON of all args.
    try:
        return json.dumps(args, ensure_ascii=False)
    except (TypeError, ValueError):
        return str(args)


def derive_always_rule(tool: str, args: dict[str, Any]) -> PermissionRule:
    """Derive a scoped allow rule from a single tool call.

    For Bash, key on the UNSAFE binary in the command — i.e. the
    binary that's causing the prompt. If `pip list | grep … ; python -c …`
    is being asked about, the dangerous one is `python -c`, so we
    scope the rule to `python:*` rather than the first binary `pip`.
    This matches user intent: "yes to this kind of thing" should
    actually cover the thing that triggered the ask.

    For file tools, key on the exact path.
    For everything else, fall back to a tool-wide rule.
    """
    if tool in ("Bash", "PowerShell"):
        command = str(args.get("command", "")).lstrip()
        if not command:
            return PermissionRule(tool=tool)
        head, sub = _unsafe_head_and_sub(command)
        if head is None:
            head = command.split()[0].rsplit("/", 1)[-1]
            sub = None
        if head in ("git", "pip", "pip3", "npm", "pnpm", "yarn", "cargo", "docker", "kubectl") and sub:
            pat = rf"^{re.escape(head)}\s+{re.escape(sub)}\b"
            return PermissionRule(tool=tool, pattern=pat)
        pat = rf"^{re.escape(head)}\b"
        return PermissionRule(tool=tool, pattern=pat)

    # Write / Edit: "don't ask again" is tool-wide, matching Claude
    # Code's UX. When a user is in build-a-project mode, prompting on
    # every new file is the wrong cost/benefit — they're saying "let
    # the agent write things." If they want path-scoped allow, the
    # /allow slash command is explicit.
    if tool in ("Write", "Edit"):
        return PermissionRule(tool=tool)

    # Read: scope to the exact path (reading sensitive files like
    # ~/.ssh/id_rsa shouldn't broaden across all Read calls).
    if tool == "Read":
        for k in ("file_path", "path", "filename"):
            if k in args and isinstance(args[k], str):
                pat = rf"^{re.escape(args[k])}$"
                return PermissionRule(tool=tool, pattern=pat)

    return PermissionRule(tool=tool)


def _unsafe_head_and_sub(command: str) -> tuple[str | None, str | None]:
    """Walk the command's segments and return the FIRST binary that
    would NOT pass the safe-bash allowlist — i.e. the binary that's
    actually causing the prompt.

    Returns (None, None) if every segment is safe (in which case the
    caller will fall back to the first binary).
    """
    import re as _re
    s = command
    s = _re.sub(r"2>\s*/dev/null", "", s)
    s = _re.sub(r"2>&1", "", s)
    s = _re.sub(r"1>&2", "", s)
    s = _re.sub(r"</?dev/null", "", s)

    # Mask quoted regions so operator chars inside them don't split.
    out = []
    i = 0
    while i < len(s):
        ch = s[i]
        if ch in ("'", '"'):
            quote = ch
            j = i + 1
            while j < len(s) and s[j] != quote:
                if s[j] == "\\" and j + 1 < len(s):
                    j += 2
                    continue
                j += 1
            out.append(quote)
            out.append("X" * max(0, j - i - 1))
            if j < len(s):
                out.append(quote)
            i = j + 1
        else:
            out.append(ch)
            i += 1
    masked = "".join(out)

    segments = _re.split(r"(?:\|\||&&|;|\||\n)", masked)
    for seg in segments:
        seg = seg.strip()
        if not seg:
            continue
        toks = seg.split()
        ti = 0
        while ti < len(toks) and "=" in toks[ti] and not toks[ti].startswith("-"):
            ti += 1
        if ti >= len(toks):
            continue
        head = toks[ti].rsplit("/", 1)[-1]
        sub = toks[ti + 1] if ti + 1 < len(toks) else None

        if head not in _SAFE_BASH_BINARIES:
            return head, sub

        if head == "git" and sub not in _SAFE_GIT_SUBCMDS:
            return head, sub
        if head in ("pip", "pip3") and sub not in _SAFE_PIP_SUBCMDS:
            return head, sub
        if head in ("npm", "pnpm", "yarn") and sub not in _SAFE_NPM_SUBCMDS:
            return head, sub
        if head == "cargo" and sub not in _SAFE_CARGO_SUBCMDS:
            return head, sub
        if head in ("python", "python3", "node") and sub not in ("--version", "-V", "-v"):
            return head, sub

    return None, None


class PermissionManager:
    """Evaluates tool calls against permission modes and rules, prompts when needed."""

    def __init__(
        self,
        mode: PermissionMode = PermissionMode.DEFAULT,
        allow: list[PermissionRule] | None = None,
        deny: list[PermissionRule] | None = None,
        audit_log: Path | None = None,
        prompt: Callable[[str, dict[str, Any]], bool] | None = None,
        classifier: Callable[..., Any] | None = None,
    ):
        self.mode = mode
        self.allow = allow or []
        self.deny = deny or []
        self.audit_log = audit_log
        self._prompt_fn = prompt
        # Async (tool, args) -> AutoDecision | None — see permissions_auto.
        # Used when self.mode == AUTO and the pre-checks fell through to ASK.
        self._classifier = classifier

    # ------------------------------------------------------------------

    def _classify(self, tool: str) -> str:
        if tool in _MUTATING:
            return "mutating"
        if tool in _SENSITIVE:
            return "sensitive"
        if tool in _READONLY:
            return "readonly"
        return "unknown"

    def _decide(self, tool: str, args: dict[str, Any]) -> PermissionDecision:
        # Explicit deny rules win
        if any(r.matches(tool, args) for r in self.deny):
            return PermissionDecision.DENY

        # Workspace guard (workspace_mode=cwd): refuse writes into
        # legacy sandbox paths before the user is even prompted. The
        # model gets a clear error and can retry under the cwd.
        if _violates_workspace_at_permission_layer(tool, args):
            return PermissionDecision.DENY

        # Mode-level overrides
        if self.mode == PermissionMode.BYPASS:
            return PermissionDecision.ALLOW

        # Explicit allow rules
        if any(r.matches(tool, args) for r in self.allow):
            return PermissionDecision.ALLOW

        # Builtin allowlist: Bash invocations that are provably
        # read-only (`which`, `ls`, `git status`, …) don't prompt.
        # Matches Claude Code + opencode behavior.
        if tool == "Bash" and _is_safe_bash(args.get("command", "")):
            return PermissionDecision.ALLOW

        kind = self._classify(tool)

        if self.mode == PermissionMode.PLAN:
            # Plan mode: only readonly tools allowed
            return PermissionDecision.ALLOW if kind == "readonly" else PermissionDecision.DENY

        if self.mode == PermissionMode.ACCEPT_EDITS:
            if kind in ("readonly", "mutating"):
                return PermissionDecision.ALLOW
            return PermissionDecision.ASK  # sensitive/unknown still prompts

        # DEFAULT and AUTO share the same pre-check logic; AUTO only
        # differs in how an ASK is resolved (classifier vs. picker),
        # handled in check() below.
        if kind == "readonly":
            return PermissionDecision.ALLOW
        return PermissionDecision.ASK  # mutating / sensitive / unknown

    async def check(self, tool: str, args: dict[str, Any]) -> tuple[bool, str]:
        """Check whether a tool call is permitted.

        Returns (allowed, reason).
        """
        decision = self._decide(tool, args)

        if decision == PermissionDecision.ASK:
            # Auto mode: route the question through the LLM classifier
            # instead of the manual picker. Any classifier failure
            # falls through to the picker — never silently auto-allow.
            if self.mode == PermissionMode.AUTO and self._classifier is not None:
                verdict = None
                try:
                    verdict = await self._classifier(tool, args)
                except Exception as e:
                    logger.warning(f"auto-classifier raised: {e}")
                if verdict is not None:
                    allowed = verdict.decision == "allow"
                    final = (
                        f"auto-allow: {verdict.reason}" if allowed
                        else f"auto-deny: {verdict.reason}"
                    )
                    self._audit(tool, args, final)
                    return allowed, final
                # Fall through to manual ask on classifier failure.

            approved = await self._ask_user(tool, args)
            final = "allow (user)" if approved else "deny (user)"
            self._audit(tool, args, final)
            return approved, final

        final = decision.value
        # Workspace violations get a descriptive reason so the model
        # knows what went wrong and can retry under the cwd.
        if decision == PermissionDecision.DENY and \
           _violates_workspace_at_permission_layer(tool, args):
            from pathlib import Path
            cwd = Path.cwd()
            final = (
                "workspace_violation: refusing to write into "
                "~/cognos/sandbox/. The workspace is the cwd "
                f"({cwd}). Retry using a path inside that directory "
                "(e.g. a sub-folder of the cwd) or ask the user."
            )
        self._audit(tool, args, final)
        return decision == PermissionDecision.ALLOW, final

    # ------------------------------------------------------------------

    async def _ask_user(self, tool: str, args: dict[str, Any]) -> bool:
        if self._prompt_fn is None:
            # No prompt wired: conservative default is deny
            logger.warning(
                f"Permission ASK for {tool} but no prompt configured; denying"
            )
            return False
        result = self._prompt_fn(tool, args)
        if asyncio.iscoroutine(result):
            result = await result
        # Richer return values: prompts may signal "always allow" so the
        # user isn't asked again. The rule is scoped to the current call
        # pattern (e.g. `Bash(python:*)`), not the whole tool — matches
        # Claude Code + opencode behavior.
        if result == "always":
            rule = derive_always_rule(tool, args)
            self.allow.append(rule)
            try:
                from core.settings import append_allow_rule
                append_allow_rule(rule.to_dict())
            except Exception as e:
                logger.debug(f"failed to persist allow rule: {e}")
            return True
        return bool(result)

    def _audit(self, tool: str, args: dict[str, Any], decision: str) -> None:
        if self.audit_log is None:
            return
        try:
            self.audit_log.parent.mkdir(parents=True, exist_ok=True)
            entry = {
                "ts": datetime.utcnow().isoformat(),
                "tool": tool,
                "args": args,
                "decision": decision,
                "mode": self.mode.value,
            }
            with self.audit_log.open("a") as f:
                f.write(json.dumps(entry) + "\n")
        except Exception as e:
            logger.debug(f"Audit log write failed: {e}")


def rules_from_settings(entries: list[dict[str, Any]] | None) -> list[PermissionRule]:
    """Build PermissionRule objects from a settings list.

    Each entry: {"tool": "<name or '*'>", "pattern": "<regex|None>"}.
    Bad entries are dropped with a warning, not raised — settings are
    user-editable and a typo shouldn't crash the agent.
    """
    out: list[PermissionRule] = []
    for entry in entries or []:
        try:
            tool = entry["tool"] if "tool" in entry else "*"
            pattern = entry.get("pattern")
            out.append(PermissionRule(tool=tool, pattern=pattern))
        except Exception as e:
            logger.warning(f"Skipping invalid permission rule {entry!r}: {e}")
    return out


def _summarize_args_for_prompt(args: dict[str, Any], width: int = 76) -> str:
    """Render args as `key="value", key2=N` — mirrors the agentic-loop
    display so the user sees the same shape they see for completed
    tool calls. Falls back to JSON for non-dict args.

    Capped to a single visual line of `width` chars (default ~76 to fit
    inside an 80-col terminal with margins). Values are first shortened
    individually, then the final joined string is hard-truncated.
    """
    if not isinstance(args, dict) or not args:
        try:
            s = json.dumps(args, ensure_ascii=False)
        except (TypeError, ValueError):
            s = str(args)
        return (s[: width - 1] + "…") if len(s) > width else s

    parts: list[str] = []
    per_value = max(20, width // max(1, len(args)))
    for k, v in args.items():
        if isinstance(v, str):
            short = v if len(v) <= per_value else v[: per_value - 1] + "…"
            short = short.replace("\n", " ")
            parts.append(f'{k}="{short}"')
        elif isinstance(v, (int, float, bool)) or v is None:
            parts.append(f"{k}={v}")
        else:
            try:
                rendered = json.dumps(v, ensure_ascii=False) if isinstance(v, (list, dict)) else str(v)
            except (TypeError, ValueError):
                rendered = str(v)
            if len(rendered) > per_value:
                rendered = rendered[: per_value - 1] + "…"
            parts.append(f"{k}={rendered}")
    s = ", ".join(parts)
    if len(s) > width:
        s = s[: width - 1] + "…"
    return s


_TOOL_ICONS_FOR_PROMPT: dict[str, str] = {
    "Bash": "⚡", "PowerShell": "⚡",
    "Read": "📄", "Write": "📝", "Edit": "✏️", "NotebookEdit": "📒",
    "FillInMiddle": "🧩",
    "Glob": "📂", "Grep": "🔍", "FindAnywhere": "🔍",
    "SemanticSearch": "🧠",
    "WebSearch": "🌐", "WebFetch": "🌐", "HttpRequest": "🌐",
    "PythonExec": "🐍", "Think": "💭", "Respond": "💬",
    "Agent": "🤝", "Draw": "🎨", "EditImage": "🖌️",
    "DescribeImage": "👁️", "Storyboard": "🎬", "LongCatAvatar": "🎭",
    "TranscribeAudio": "🎙️", "Speak": "🔊",
    "Calculator": "🧮", "DateTime": "📅", "SystemInfo": "🖥️",
    "Sandbox": "📦", "EnterWorktree": "🌿", "ExitWorktree": "🌿",
    "EnterPlanMode": "📋", "ExitPlanMode": "📋",
    "TaskCreate": "✅", "TaskList": "✅", "TaskGet": "✅",
    "TaskUpdate": "✅", "TaskStop": "✅", "TaskOutput": "✅",
    "CronCreate": "⏰", "CronList": "⏰", "CronDelete": "⏰",
    "PushNotification": "🔔", "AskUserQuestion": "❓",
    "UpdateMemory": "🧠", "LoadSkill": "📚",
}


async def _ptk_select_async(
    tool: str,
    pretty_args: str,
    icon: str,
    always_label: str | None = None,
) -> int:
    """prompt_toolkit-driven 3-option selector.

    Returns 0 (Yes), 1 (Always), 2 (No), or -1 (cancelled / Esc).
    Uses the same Application machinery as the slash palette so arrow
    keys are consumed instead of echoed. The menu is wrapped in a
    Frame so it reads as a bounded panel rather than free text on the
    scrollback.
    """
    # Suppress prompt_toolkit's "your terminal doesn't support CPR" line
    # — it's emitted unconditionally on terminals that don't reply to
    # cursor-position queries and adds nothing the user can act on.
    import os
    os.environ.setdefault("PROMPT_TOOLKIT_NO_CPR", "1")

    from prompt_toolkit.application import Application
    from prompt_toolkit.key_binding import KeyBindings
    from prompt_toolkit.layout import HSplit, Layout, Window
    from prompt_toolkit.layout.controls import FormattedTextControl
    from prompt_toolkit.layout.dimension import Dimension as D
    from prompt_toolkit.styles import Style
    from prompt_toolkit.widgets import Frame

    options = [
        ("Yes", "green"),
        (f"Yes, and don't ask again for {always_label or tool}", "white"),
        ("No  (esc)", "white"),
    ]
    state = {"cursor": 0, "result": None}

    def header_text():
        return [
            ("class:prompt", f"  Run "),
            ("class:tool", f"{icon}  {tool}"),
            ("class:prompt", "?\n"),
            ("class:dim", f"  {pretty_args}\n"),
            ("", "\n"),
        ]

    def menu_text():
        out = []
        for i, (label, _color) in enumerate(options):
            if i == state["cursor"]:
                out.append(("class:selected", f"  ❯ {i+1}. {label}\n"))
            else:
                out.append(("class:option", f"    {i+1}. {label}\n"))
        return out

    # No background highlight on the active row — the `❯` arrow alone
    # marks the selection (Claude-Code parity).

    kb = KeyBindings()

    @kb.add("up")
    def _(event):
        state["cursor"] = (state["cursor"] - 1) % len(options)
        event.app.invalidate()

    @kb.add("down")
    def _(event):
        state["cursor"] = (state["cursor"] + 1) % len(options)
        event.app.invalidate()

    @kb.add("enter")
    def _(event):
        state["result"] = state["cursor"]
        event.app.exit()

    @kb.add("escape")
    @kb.add("c-c")
    def _(event):
        state["result"] = -1
        event.app.exit()

    for digit, idx in (("1", 0), ("2", 1), ("3", 2)):
        @kb.add(digit)
        def _(event, _idx=idx):
            state["result"] = _idx
            event.app.exit()

    @kb.add("y")
    def _(event):
        state["result"] = 0
        event.app.exit()

    @kb.add("a")
    def _(event):
        state["result"] = 1
        event.app.exit()

    @kb.add("n")
    def _(event):
        state["result"] = 2
        event.app.exit()

    body = HSplit(
        [
            Window(
                FormattedTextControl(header_text),
                height=D(min=3, max=4, preferred=3),
            ),
            Window(
                FormattedTextControl(menu_text),
                height=D(min=len(options), max=len(options), preferred=len(options)),
            ),
        ]
    )
    layout = Layout(
        Frame(body, title="Permission required", style="class:frame")
    )

    style = Style.from_dict(
        {
            "prompt": "",
            "tool": "bold cyan",
            "dim": "#888888",
            # No background — selection is indicated by `❯` only.
            "selected": "bold",
            "option": "",
            "frame.border": "#5f5f87",
            "frame.label": "bold #87afff",
        }
    )

    app: Application[None] = Application(
        layout=layout,
        key_bindings=kb,
        style=style,
        full_screen=False,
        mouse_support=False,
    )

    await app.run_async()
    return state["result"] if state["result"] is not None else -1


async def default_cli_prompt(tool: str, args: dict[str, Any]):
    """Claude-Code-style permission prompt — prompt_toolkit-driven inline menu.

    Returns:
      - True     → allow this call once
      - "always" → allow + register a permanent allow rule
      - False    → deny

    Awaitable because the underlying prompt_toolkit Application runs
    inside the agent's event loop. PermissionManager.`_ask_user`
    already awaits coroutine results.
    """
    import sys
    from rich.console import Console
    console = Console()

    # Diff preview for file mutations (Claude Code parity).
    if tool in ("Edit", "Write"):
        try:
            from core.diff_viewer import render_proposed_change
            render_proposed_change(tool, args, console=console)
        except Exception as e:
            logger.debug(f"diff preview failed: {e}")

    pretty_args = _summarize_args_for_prompt(args)
    icon = _TOOL_ICONS_FOR_PROMPT.get(tool, "🔧")

    # Pause the StreamDisplay tickers (active tool elapsed-time, thinking
    # status) so they don't clobber the prompt_toolkit menu by repainting
    # `\r\033[2K` on top of it.
    display = None
    try:
        from ui.display import get_active_display
        display = get_active_display()
    except Exception:
        display = None
    if display is not None:
        # Finalize the active tool line with a newline so the menu prints
        # cleanly below it rather than on the same row as the ticker.
        try:
            console.file.write("\n")
            console.file.flush()
        except Exception:
            pass
        display.pause()

    # Compute the scope label so the user sees what "don't ask again"
    # will actually allow (e.g. `Bash(python:*)` not just `Bash`).
    always_label = derive_always_rule(tool, args).display()

    try:
        if sys.stdin.isatty():
            try:
                idx = await _ptk_select_async(tool, pretty_args, icon, always_label=always_label)
            except Exception as e:
                logger.debug(f"ptk selector failed, falling back: {e}")
                idx = -2

            if idx == 0:
                return True
            if idx == 1:
                return "always"
            if idx == 2 or idx == -1:
                return False
            # idx == -2 → fall through to text prompt fallback
    finally:
        if display is not None:
            display.resume()

    # Fallback: plain text input (non-TTY or ptk selector failed).
    console.print()
    console.print(f"  Do you want to run [bold cyan]{icon}  {tool}[/bold cyan]?")
    console.print(f"  [dim]{tool}({pretty_args})[/dim]")
    console.print()
    console.print("  [bold green]❯ 1.[/bold green] [bold]Yes[/bold]")
    console.print(
        f"    [bold]2.[/bold] Yes, and don't ask again for [cyan]{always_label}[/cyan]"
    )
    console.print("    [bold]3.[/bold] No  [dim](esc)[/dim]")
    console.print()

    try:
        answer = console.input("  ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        return False

    if answer in ("", "1", "y", "yes"):
        return True
    if answer in ("2", "a", "always"):
        return "always"
    return False
