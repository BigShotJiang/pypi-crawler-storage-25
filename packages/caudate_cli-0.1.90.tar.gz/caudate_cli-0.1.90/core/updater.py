"""Auto-update — `cognos update` checks for and applies new versions.

Two install modes are detected automatically:

  1. **Git checkout** (the common case for a cloned repo) — runs
     `git fetch && git pull --ff-only` on the project root. If the local
     branch has diverged, refuses to merge and tells the user.

  2. **Pip install** (if `cognos` was installed as a package) — runs
     `pip install --upgrade cognos`. We detect this by looking for an
     installed distribution metadata entry; absent → assume git mode.

Returns a small report describing what changed, or why nothing did.
"""

from __future__ import annotations

import logging
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass
class UpdateResult:
    mode: str                # "git" | "pip" | "unknown"
    changed: bool
    summary: str
    details: str = ""


def _is_git_repo(path: Path) -> bool:
    return (path / ".git").exists()


def _pip_installed() -> bool:
    try:
        from importlib.metadata import distribution
        distribution("cognos")
        return True
    except Exception:
        return False


def _run(cmd: list[str], cwd: Path | None = None, timeout: int = 120) -> tuple[int, str, str]:
    proc = subprocess.run(
        cmd,
        cwd=cwd,
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    return proc.returncode, proc.stdout.strip(), proc.stderr.strip()


def update_via_git(repo: Path) -> UpdateResult:
    if shutil.which("git") is None:
        return UpdateResult(mode="git", changed=False, summary="git not installed")

    rc, before, _ = _run(["git", "rev-parse", "HEAD"], cwd=repo)
    if rc != 0:
        return UpdateResult(mode="git", changed=False, summary="not a git checkout")

    rc, _, err = _run(["git", "fetch"], cwd=repo)
    if rc != 0:
        return UpdateResult(mode="git", changed=False, summary="fetch failed", details=err)

    rc, out, err = _run(["git", "pull", "--ff-only"], cwd=repo)
    if rc != 0:
        return UpdateResult(
            mode="git",
            changed=False,
            summary="local branch has diverged — resolve manually",
            details=err or out,
        )

    rc, after, _ = _run(["git", "rev-parse", "HEAD"], cwd=repo)
    if before == after:
        return UpdateResult(mode="git", changed=False, summary="already up to date")
    rc, log, _ = _run(
        ["git", "log", "--oneline", f"{before}..{after}"], cwd=repo,
    )
    return UpdateResult(
        mode="git",
        changed=True,
        summary=f"updated {before[:7]} → {after[:7]}",
        details=log,
    )


def update_via_pip() -> UpdateResult:
    rc, out, err = _run(
        [sys.executable, "-m", "pip", "install", "--upgrade", "cognos"],
        timeout=300,
    )
    if rc != 0:
        return UpdateResult(mode="pip", changed=False, summary="pip upgrade failed", details=err or out)
    changed = "already satisfied" not in (out + err).lower()
    return UpdateResult(
        mode="pip",
        changed=changed,
        summary="pip upgrade ok" if changed else "already up to date",
        details=out,
    )


def update(project_root: Path | None = None) -> UpdateResult:
    """Detect install mode and update accordingly."""
    root = project_root or Path(__file__).resolve().parent.parent
    if _is_git_repo(root):
        return update_via_git(root)
    if _pip_installed():
        return update_via_pip()
    return UpdateResult(
        mode="unknown",
        changed=False,
        summary="not a git checkout and not pip-installed — cannot self-update",
    )
