"""Branded boot banner for the Cognos CLI.

Lands on stdout when `cognos` (or `cognos interactive`) starts so the
launch feels like a real CLI tool — ASCII logo, brain status, a one-
line tip on slash commands. Replaces the prior ad-hoc `console.print`
blob in `main.py:interactive`.

The banner is plain Rich — no Textual, no full-screen takeover — so
piping (`cognos -p ...`) and non-TTY contexts still work cleanly.
"""

from __future__ import annotations

from typing import Any

from rich.align import Align
from rich.console import Console, Group
from rich.panel import Panel
from rich.text import Text


_LOGO = r"""
  ____                _       _
 / ___|__ _ _   _  __| | __ _| |_ ___
| |   / _` | | | |/ _` |/ _` | __/ _ \
| |__| (_| | |_| | (_| | (_| | ||  __/
 \____\__,_|\__,_|\__,_|\__,_|\__\___|
""".rstrip("\n").lstrip("\n")


def _version() -> str:
    """Read the installed package version. Tries the new distribution
    name first, falls back to the legacy one, then a hard-coded default."""
    try:
        from importlib.metadata import version
        try:
            return version("caudate-cli")
        except Exception:
            return version("cognos-cli")
    except Exception:
        return "0.1.0"


def _brain_summary(agent: Any) -> Text:
    """Two-line summary of which models are wired in."""
    from llm.router import DualLLMProvider
    t = Text()
    if isinstance(agent.llm, DualLLMProvider):
        t.append("S1 ", style="bold cyan")
        t.append(getattr(agent.llm_fast, "model", "?"), style="white")
        t.append("   S2 ", style="bold magenta")
        t.append(getattr(agent.llm_slow, "model", "?"), style="white")
    else:
        t.append("model ", style="bold")
        t.append(getattr(agent.llm, "model", "?"), style="white")
    return t


def _caudate_summary(agent: Any) -> Text | None:
    """Caudate router trust + active model — only if she's loaded."""
    t = Text()
    try:
        caudate = getattr(agent, "caudate", None)
        if caudate is None:
            return None
        trust = getattr(caudate, "trust_level", None) or getattr(caudate, "trust", None) or "whisper"
        params = getattr(caudate, "n_params", None)
        t.append("caudate ", style="bold green")
        t.append(str(trust).lower(), style="white")
        if params:
            t.append(f"  {params/1e6:.2f}M params", style="dim")
        return t
    except Exception:
        return None


def _session_summary(agent: Any, resumed: bool) -> Text:
    t = Text()
    try:
        sid = agent.session.id
        n = len(agent.session.messages)
    except Exception:
        sid, n = "?", 0
    if resumed:
        t.append("resumed ", style="yellow")
        t.append(f"{sid[:8]} · {n} messages", style="dim")
    else:
        t.append("new session ", style="green")
        t.append(sid[:8], style="dim")
    return t


def print_startup_banner(
    agent: Any,
    console: Console,
    *,
    resumed: bool = False,
    extras: list[str] | None = None,
) -> None:
    """Render the boot screen.

    `extras` is a list of mode flags shown as a footer (e.g. ["streaming",
    "thinking"]). Empty list / None hides that line.
    """
    logo = Text(_LOGO, style="bold cyan")
    version_line = Text()
    version_line.append(f"v{_version()}", style="dim")
    version_line.append("  ·  ", style="dim")
    version_line.append("local-first cognitive agent", style="italic dim")

    rows: list[Any] = [
        Align.center(logo),
        Align.center(version_line),
        Text(""),
        _brain_summary(agent),
    ]
    caudate = _caudate_summary(agent)
    if caudate is not None:
        rows.append(caudate)
    rows.append(_session_summary(agent, resumed))
    if extras:
        flags = Text("  ".join(extras), style="dim italic")
        rows.append(flags)
    rows.append(Text(""))

    tip = Text()
    tip.append("type ", style="dim")
    tip.append("/", style="bold")
    tip.append(" for the command palette  ·  ", style="dim")
    tip.append("/quit", style="bold")
    tip.append(" to exit", style="dim")
    rows.append(tip)

    console.print(Panel(
        Group(*rows),
        border_style="cyan",
        padding=(1, 2),
    ))
