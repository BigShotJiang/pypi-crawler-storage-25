"""Failure-pattern library (Phase 3.6).

Maps recurring tool-error messages to concrete remediation hints. When
a Bash / Write / Edit tool returns an error matching one of these
patterns, the loop injects an `<auto-fix-suggestion>...</...>` block
into the tool_result content so the model's next iteration has a
ready-made fix to try.

This is a data-driven library — append to `FAILURE_PATTERNS` to grow
coverage. Each entry pairs a regex with a Python format template; the
template can reference any regex group via `{1}`, `{2}`, … and a few
named placeholders like `{port}`.

The library does **not** auto-execute suggestions — it only surfaces
them as text the model sees on the next turn. The model decides
whether to take the suggested action.

Cross-link with Phase 3.1: error recovery (3.1) bumps a per-tool
counter and gives "try differently" guidance. 3.6 layers more
specific guidance ON TOP — "try differently, AND specifically: run
`pip install foo`." Phase 3.1's bounded retry still applies; if the
suggestion doesn't work, the turn still ends on the third failure.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from typing import Pattern

logger = logging.getLogger(__name__)


@dataclass
class FailurePattern:
    """One known-error → known-fix mapping."""

    regex: Pattern
    fix_template: str
    label: str = ""  # human-readable, surfaced in the suggestion

    def match(self, text: str) -> str | None:
        """If `text` matches, return the rendered fix; else None."""
        m = self.regex.search(text)
        if m is None:
            return None
        # Pass full match as {0} and capture groups as {1}, {2}, … so
        # templates can reference numbered positional fields directly.
        try:
            return self.fix_template.format(m.group(0), *m.groups())
        except (KeyError, IndexError) as e:
            logger.debug(f"failure pattern format failed: {e}")
            return None


# Patterns are checked in order; first match wins. Be specific →
# general so a narrow match isn't shadowed by a broad one.
FAILURE_PATTERNS: list[FailurePattern] = [
    # Python module missing
    FailurePattern(
        regex=re.compile(r"ModuleNotFoundError: No module named ['\"]([^'\"]+)['\"]"),
        fix_template="Run `pip install {1}` (or add it to requirements.txt + reinstall).",
        label="missing python module",
    ),
    FailurePattern(
        regex=re.compile(r"ImportError: cannot import name ['\"]([^'\"]+)['\"]"),
        fix_template=(
            "The name `{1}` doesn't exist in the imported module. Check "
            "the module's actual exports (e.g. `python -c 'import x; "
            "print(dir(x))'`) — the API may have changed across versions."
        ),
        label="import name mismatch",
    ),
    # Shell command missing — `bash: <cmd>: command not found`
    FailurePattern(
        regex=re.compile(r"(\w+): command not found"),
        fix_template=(
            "`{1}` isn't installed. Try `which {1}` to confirm, then install "
            "via the appropriate package manager (`apt-get install {1}` / "
            "`brew install {1}` / `pip install {1}`)."
        ),
        label="command not found (bash shape)",
    ),
    # `/bin/sh: <n>: <cmd>: not found` (dash / busybox shape)
    FailurePattern(
        regex=re.compile(r"(?:^|\s)(\w+): not found"),
        fix_template=(
            "`{1}` isn't installed. Try `which {1}` to confirm, then install "
            "via the appropriate package manager."
        ),
        label="command not found",
    ),
    # Port in use — with port number captured
    FailurePattern(
        regex=re.compile(
            r"(?:Address already in use|EADDRINUSE).*?(?:port )?(\d{2,5})"
        ),
        fix_template=(
            "Port {1} is held by another process. Either:\n"
            "  (a) free it: `lsof -ti:{1} | xargs -r kill -9`, OR\n"
            "  (b) pick a different port (e.g. {1}+1) and update the launcher."
        ),
        label="port in use",
    ),
    # Port in use — fallback when no number could be parsed
    FailurePattern(
        regex=re.compile(r"(?:Address already in use|EADDRINUSE)"),
        fix_template=(
            "A port is held by another process (number not in the error "
            "text). Find it: `ss -ltnp` or `lsof -i -P -n | grep LISTEN`, "
            "then `kill -9 <pid>` or pick a different port."
        ),
        label="port in use (no number)",
    ),
    # Permission denied — try chmod or sudo
    FailurePattern(
        regex=re.compile(r"Permission denied[:\s]+([^\s]+)"),
        fix_template=(
            "Permission denied on `{1}`. If you own the file, `chmod +x {1}` "
            "or `chmod u+w {1}`. If it's a system path, the agent shouldn't "
            "be writing there — ask the user."
        ),
        label="permission denied",
    ),
    # File / directory missing
    FailurePattern(
        regex=re.compile(
            r"(?:No such file or directory|FileNotFoundError)"
            r".*?[:'\"]([^\s'\":]+)"
        ),
        fix_template=(
            "`{1}` doesn't exist at that path. Verify with `ls -la <parent-dir>`. "
            "If the parent doesn't exist either, `mkdir -p` it first. If the "
            "filename should match an existing file, fix the typo."
        ),
        label="file/dir missing",
    ),
    # Disk full
    FailurePattern(
        regex=re.compile(r"No space left on device"),
        fix_template=(
            "Disk is full. Run `df -h` to see which mount is exhausted, then "
            "clean up (`du -sh */ | sort -h` to find the biggest dirs)."
        ),
        label="disk full",
    ),
    # Git: nothing to commit
    FailurePattern(
        regex=re.compile(r"nothing to commit, working tree clean"),
        fix_template=(
            "The tree is clean — there's nothing staged to commit. If you "
            "intended to commit changes, `git status` to see what's actually "
            "modified, then `git add` the right files first."
        ),
        label="git nothing to commit",
    ),
    # Git: not a repository
    FailurePattern(
        regex=re.compile(r"(?:not a git repository|fatal: not a git repository)"),
        fix_template=(
            "Cwd isn't a git repo. Run `git init` first, OR change directory "
            "to one that is a repo. Verify with `git rev-parse --is-inside-work-tree`."
        ),
        label="not a git repo",
    ),
    # Network / DNS
    FailurePattern(
        regex=re.compile(
            r"(?:Name or service not known|Could not resolve host|"
            r"Temporary failure in name resolution)"
        ),
        fix_template=(
            "DNS lookup failed. Likely causes: no network, firewall, or wrong "
            "hostname. Try `curl -v ...` for the verbose output, or `dig` / "
            "`nslookup` to check resolution."
        ),
        label="dns failure",
    ),
    # SSL / cert
    FailurePattern(
        regex=re.compile(r"SSL.*verif(?:y|ication) failed"),
        fix_template=(
            "TLS verification failed. Likely causes: clock skew, missing CA "
            "bundle, or self-signed cert on the target. For dev use only, "
            "`curl -k` skips verification. Don't disable in production code."
        ),
        label="ssl verify failed",
    ),
    # pip — package not found on index
    FailurePattern(
        regex=re.compile(
            r"(?:Could not find a version that satisfies(?: the requirement)?"
            r"|No matching distribution found for) ([A-Za-z0-9_.\-]+)"
        ),
        fix_template=(
            "PyPI doesn't have `{1}`. Check spelling, or it may need an "
            "extras spec (`pkg[extra]`), or you're on a Python version it "
            "doesn't ship a wheel for. `pip install --pre {1}` for prereleases."
        ),
        label="pip pkg not found",
    ),
    # JSON parse error (frequent in tool args)
    FailurePattern(
        regex=re.compile(
            r"(?:json\.JSONDecodeError|JSON parse error|"
            r"Expecting value: line \d+ column \d+)"
        ),
        fix_template=(
            "Malformed JSON. Common causes: trailing comma, single-quote "
            "strings instead of double, unescaped newline in a string. Use "
            "a JSON linter (`python -m json.tool`) or `jq .` to spot the "
            "exact column."
        ),
        label="json parse error",
    ),
]


def suggest_fix(error_text: str) -> str | None:
    """Return a remediation hint string for `error_text`, or None.

    First match wins; patterns are ordered specific-to-general at the
    top of the module.
    """
    if not error_text:
        return None
    for pat in FAILURE_PATTERNS:
        hint = pat.match(error_text)
        if hint is not None:
            return hint
    return None


def suggest_fix_with_label(error_text: str) -> tuple[str, str] | None:
    """Same as suggest_fix but also returns the matched pattern's label."""
    if not error_text:
        return None
    for pat in FAILURE_PATTERNS:
        hint = pat.match(error_text)
        if hint is not None:
            return pat.label, hint
    return None
