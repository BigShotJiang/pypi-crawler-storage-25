"""Cognitive Loop — the main perceive-plan-act-reflect-remember cycle."""

from __future__ import annotations

import logging
from typing import Any

from config import MAX_REPLAN_ATTEMPTS, MAX_TASK_FAILURES
from core.schemas import (
    Goal, GoalStatus, Plan, Task, TaskStatus, Perception,
    Episode, Reflection, ToolResultStatus,
)
from execution.executor import Executor
from llm.provider import LLMProvider
from memory.working import WorkingMemory
from memory.episodic import EpisodicMemory
from memory.semantic import SemanticMemory
from memory.procedural import ProceduralMemory
from planning.planner import Planner
from reflection.reflector import Reflector
from reflection.meta_learner import MetaLearner

logger = logging.getLogger(__name__)


class CognitiveLoop:
    """The main cognitive cycle: Perceive → Plan → Act → Reflect → Remember."""

    def __init__(self, llm: LLMProvider):
        self.llm = llm
        self.executor = Executor(llm=llm)
        self.planner = Planner(llm)
        self.reflector = Reflector(llm)

        # Memory systems
        self.working = WorkingMemory()
        self.episodic = EpisodicMemory()
        self.semantic = SemanticMemory()
        self.procedural = ProceduralMemory()

        # Meta-learning
        self.meta_learner = MetaLearner(llm, self.procedural)

        # State
        self._cycle_count = 0

    async def run(self, goal: Goal, verbose: bool = True) -> Goal:
        """Run the full cognitive loop until goal is achieved or abandoned."""
        logger.info(f"Starting cognitive loop for goal: {goal.description}")

        if verbose:
            print(f"\n{'='*60}")
            print(f"GOAL: {goal.description}")
            print(f"{'='*60}\n")

        # Phase 1: PERCEIVE
        perception = await self._perceive(goal)

        # Phase 2: PLAN
        plan = await self.planner.create_plan(
            goal, perception, self.executor.list_tools()
        )
        self.working.store("current_plan", plan.reasoning)

        if verbose:
            print(f"PLAN (v{plan.version}): {plan.reasoning}")
            for i, t in enumerate(plan.tasks):
                print(f"  {i+1}. {t.description} [tool: {t.tool_name or 'reasoning'}]")
            print()

        replan_count = 0
        # Per-task failure budget — keyed by task description so it
        # survives a replan that re-issues the same logical task with a
        # fresh id. When a task description hits MAX_TASK_FAILURES we
        # force a replan instead of letting the executor try it again.
        task_failures: dict[str, int] = {}
        while not plan.is_complete() and goal.status == GoalStatus.ACTIVE:
            self._cycle_count += 1
            ready_tasks = plan.get_ready_tasks()

            if not ready_tasks:
                if plan.has_failed():
                    # Phase: REPLAN
                    if replan_count >= MAX_REPLAN_ATTEMPTS:
                        goal.status = GoalStatus.FAILED
                        logger.warning("Max replan attempts reached. Goal failed.")
                        break

                    failed = [t for t in plan.tasks if t.status == TaskStatus.FAILED]
                    last_reflection = self.working.recall("last_reflection")
                    if last_reflection:
                        new_plan = await self.planner.replan(
                            goal, plan, last_reflection, self.executor.list_tools()
                        )
                        if new_plan:
                            plan = new_plan
                            replan_count += 1
                            if verbose:
                                print(f"\nREPLAN (v{plan.version}): {plan.reasoning}\n")
                            continue
                    goal.status = GoalStatus.FAILED
                    break
                else:
                    # Deadlock — no ready tasks but not complete
                    goal.status = GoalStatus.FAILED
                    logger.error("Deadlock: no ready tasks and plan not complete")
                    break

            for task in ready_tasks:
                task.status = TaskStatus.IN_PROGRESS

                # Inject results from completed dependency tasks into this task
                self._inject_dependency_results(task, plan)

                if verbose:
                    print(f"  EXEC: {task.description}", end=" ... ")

                # Phase 3: ACT
                result, episode = await self.executor.execute_task(task)

                if result.status == ToolResultStatus.SUCCESS:
                    task.status = TaskStatus.COMPLETED
                    task.result = result.output
                    if verbose:
                        print(f"OK")
                else:
                    task.status = TaskStatus.FAILED
                    task.error = result.error
                    fails = task_failures.get(task.description, 0) + 1
                    task_failures[task.description] = fails
                    if verbose:
                        print(f"FAILED ({fails}/{MAX_TASK_FAILURES}): {result.error}")

                # Phase 4: REFLECT
                reflection = await self.reflector.reflect(episode, goal, task)
                self.working.store("last_reflection", reflection)
                self.working.store(f"task_{task.id}_result", result.output or result.error)

                if verbose and reflection.lesson:
                    print(f"    REFLECT: {reflection.lesson} (score: {reflection.score:.2f})")

                # Phase 5: REMEMBER
                self.episodic.store(episode)
                self.meta_learner.add_reflection(reflection)

                if reflection.lesson:
                    self.semantic.store(
                        knowledge_id=f"lesson_{episode.id}",
                        content=reflection.lesson,
                        category="lesson",
                    )

                # Check if we should replan (reflector says so, or this
                # task has exhausted its per-task failure budget).
                if (
                    self.reflector.needs_replan(reflection)
                    or task_failures.get(task.description, 0) >= MAX_TASK_FAILURES
                ):
                    break  # break inner loop to trigger replan

            # Meta-learning: periodically extract strategies
            new_strategies = await self.meta_learner.maybe_update_strategies()
            if new_strategies and verbose:
                for s in new_strategies:
                    print(f"    LEARNED: Strategy '{s.name}' (confidence: {s.confidence:.2f})")

        # Final meta-learning pass
        final_strategies = await self.meta_learner.force_update()

        if plan.is_complete():
            goal.status = GoalStatus.ACHIEVED
            if verbose:
                print(f"\nGOAL ACHIEVED: {goal.description}")

        # Memory consolidation
        self._consolidate(goal)

        if verbose:
            print(f"\nStats: {self._cycle_count} cycles, "
                  f"{self.episodic.count()} episodes stored, "
                  f"{len(self.procedural.get_strategies())} strategies learned")
            print(f"{'='*60}\n")

        return goal

    async def _perceive(self, goal: Goal) -> Perception:
        """Build a perception of the current situation."""
        # Recall relevant episodes
        relevant_episodes = self.episodic.recall(goal.description)

        # Recall relevant knowledge
        knowledge = self.semantic.recall(goal.description)
        knowledge_texts = [k["content"] for k in knowledge]

        # Get applicable strategies
        strategies = self.meta_learner.get_applicable_strategies(goal.description)

        return Perception(
            goal=goal,
            working_memory=self.working.recall_all(),
            relevant_episodes=relevant_episodes,
            relevant_knowledge=knowledge_texts,
            active_strategies=strategies,
        )

    def _inject_dependency_results(self, task: Task, plan: Plan) -> None:
        """Inject results from completed dependency tasks into this task's args.

        If the task uses the 'respond' tool and has no message, synthesize one
        from all prior completed task results.
        """
        # Collect results from all completed tasks
        prior_results = []
        for t in plan.tasks:
            if t.status == TaskStatus.COMPLETED and t.result:
                prior_results.append(f"[{t.description}]: {str(t.result)[:1000]}")

        # Store collected context in working memory
        if prior_results:
            context = "\n".join(prior_results)
            self.working.store("prior_task_results", context)

        # For respond tasks: always build message from actual prior results
        if task.tool_name in ("respond", "Respond") and prior_results:
            task.tool_args["message"] = "\n\n".join(prior_results)

    def _consolidate(self, goal: Goal) -> None:
        """Consolidate short-term memory into long-term storage."""
        score = 1.0 if goal.status == GoalStatus.ACHIEVED else 0.0
        self.procedural.log_performance(
            goal_id=goal.id,
            score=score,
            lesson=f"Goal {'achieved' if score > 0 else 'failed'}: {goal.description}",
            strategy_ids=[s.id for s in self.meta_learner.get_applicable_strategies("")],
        )

        # Clear working memory for next goal
        self.working.clear()
