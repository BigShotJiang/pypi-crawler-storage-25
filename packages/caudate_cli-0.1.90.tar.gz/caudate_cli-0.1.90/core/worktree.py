"""Worktree isolation — give a subagent its own checkout to mutate.

A worktree is a separate working copy backed by the same `.git/` repo,
created with `git worktree add`. The subagent gets full read/write
access to its own copy without touching the parent's working tree. When
the subagent finishes, the worktree is either kept (if it produced
changes) or cleaned up (if it didn't), mirroring the SDK's contract.

Two failure modes are handled gracefully:
  - The repo is dirty in a way that blocks `worktree add` → return
    `None`, caller should fall back to the shared tree.
  - `git` isn't installed or the cwd isn't a git repo → same.

Callers should treat worktree creation as best-effort: a failure is
not an error, just a missed optimization.
"""

from __future__ import annotations

import asyncio
import logging
import shutil
import tempfile
import uuid
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass
class Worktree:
    path: Path
    branch: str
    parent_repo: Path

    async def has_changes(self) -> bool:
        """Did the subagent write anything?"""
        rc, out, _ = await _git(self.path, "status", "--porcelain")
        return rc == 0 and bool(out.strip())

    async def cleanup(self, force: bool = False) -> None:
        """Remove the worktree. Skips if it has uncommitted changes (unless force)."""
        if not force and await self.has_changes():
            logger.info(
                f"Keeping worktree {self.path} — has uncommitted changes"
            )
            return
        rc, _, err = await _git(
            self.parent_repo, "worktree", "remove", "--force", str(self.path),
        )
        if rc != 0:
            logger.debug(f"worktree remove failed: {err}")
            shutil.rmtree(self.path, ignore_errors=True)
        # Best-effort branch delete
        await _git(self.parent_repo, "branch", "-D", self.branch)


async def create_worktree(
    parent_repo: Path | None = None,
    base_branch: str = "HEAD",
) -> Worktree | None:
    """Create a fresh worktree off `base_branch`. Returns None on any failure."""
    repo = parent_repo or Path.cwd()
    if shutil.which("git") is None:
        return None

    rc, out, _ = await _git(repo, "rev-parse", "--show-toplevel")
    if rc != 0:
        return None
    repo = Path(out.strip())

    branch = f"cognos/agent-{uuid.uuid4().hex[:8]}"
    tmp = Path(tempfile.mkdtemp(prefix="cognos-wt-"))
    rc, _, err = await _git(
        repo, "worktree", "add", "-b", branch, str(tmp), base_branch,
    )
    if rc != 0:
        logger.debug(f"worktree add failed: {err}")
        shutil.rmtree(tmp, ignore_errors=True)
        return None
    return Worktree(path=tmp, branch=branch, parent_repo=repo)


async def _git(cwd: Path, *args: str) -> tuple[int, str, str]:
    proc = await asyncio.create_subprocess_exec(
        "git", *args,
        cwd=str(cwd),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    out, err = await proc.communicate()
    return proc.returncode or 0, out.decode(errors="ignore"), err.decode(errors="ignore")
