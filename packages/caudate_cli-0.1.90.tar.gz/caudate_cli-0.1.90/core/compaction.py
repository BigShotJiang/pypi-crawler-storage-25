"""Context compaction — summarize old messages when hitting a token budget.

Keeps the most recent `keep_recent` messages verbatim and replaces the older
prefix with a single LLM-generated summary, formatted as a system message.
The first message (original system prompt) is always preserved.
"""

from __future__ import annotations

import logging
from typing import Any

import litellm

from llm.provider import LLMProvider

logger = logging.getLogger(__name__)


COMPACT_PROMPT = """Summarize the following conversation so that a future agent
can continue the task without losing important context. Include: what the user
asked for, what tools were used and their key results, any decisions made, and
any open threads. Be concise (300 words max) but include concrete facts (file
paths, values, names). Do NOT add commentary — just the summary.

{goal_context}Conversation:
{conversation}"""


# Phase 2.6: when an active goal exists, prepend its block to the
# compaction prompt so the summarizer LLM knows what context matters
# most. Subtask transitions and attempt outcomes are easy to lose in
# a generic "summarize this" pass; this nudge keeps them anchored.
_GOAL_CONTEXT_HEADER = """The agent is working on this active goal:
{goal_block}

When summarizing, EXPLICITLY preserve:
- Any subtask status transitions (which moved from pending → in_progress → done)
- Any subtask that was blocked + why
- Attempt outcomes that mattered (rewards, errors, unexpected results)
- Decisions made about the goal's scope or approach

"""


class ContextCompactor:
    """Summarizes older messages to fit a token budget."""

    def __init__(
        self,
        llm: LLMProvider,
        context_window: int = 32000,
        compact_threshold: float = 0.8,
        keep_recent: int = 6,
    ):
        self.llm = llm
        self.context_window = context_window
        self.compact_threshold = compact_threshold
        self.keep_recent = keep_recent

    def should_compact(self, messages: list[dict[str, Any]]) -> bool:
        """True if message count hits the threshold (token-based check below)."""
        try:
            total = litellm.token_counter(
                model=self.llm.model,
                messages=messages,
            )
        except Exception:
            # Fallback: approx 4 chars per token
            total = sum(len(str(m.get("content", ""))) for m in messages) // 4

        return total >= int(self.context_window * self.compact_threshold)

    async def compact(self, messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Return a shorter message list with older history summarized."""
        if len(messages) <= self.keep_recent + 1:
            return messages

        first = messages[0] if messages[0].get("role") == "system" else None
        start_idx = 1 if first else 0

        to_summarize = messages[start_idx:-self.keep_recent]
        tail = messages[-self.keep_recent:]

        if not to_summarize:
            return messages

        conversation = "\n\n".join(
            f"[{m.get('role')}]: {_content_str(m)}" for m in to_summarize
        )
        # Phase 2.6: pull the active goal context (if any) into the
        # compactor's prompt so the LLM-driven summary preserves
        # subtask transitions + outcomes instead of dropping them as
        # "implementation noise".
        goal_context = ""
        try:
            from core.goal_store import get_store
            active = get_store().active()
            if active is not None:
                goal_block = active.render_for_prompt()
                goal_context = _GOAL_CONTEXT_HEADER.format(goal_block=goal_block)
        except Exception as e:
            logger.debug(f"compaction goal-context lookup failed: {e}")
        prompt = COMPACT_PROMPT.format(
            conversation=conversation[:12000],
            goal_context=goal_context,
        )

        try:
            response = await self.llm.complete(prompt=prompt, caller="compaction")
            summary = response.content
        except Exception as e:
            logger.warning(f"Compaction failed: {e}")
            return messages

        summary_msg = {
            "role": "system",
            "content": f"[previous conversation summary]\n{summary}",
        }

        result: list[dict[str, Any]] = []
        if first:
            result.append(first)
        result.append(summary_msg)
        result.extend(tail)
        logger.info(
            f"Compacted: {len(messages)} -> {len(result)} messages"
        )
        return result


def _content_str(message: dict[str, Any]) -> str:
    """Convert a message's content + tool_calls to a single string for summary."""
    parts: list[str] = []
    content = message.get("content")
    if content:
        parts.append(str(content))
    for tc in message.get("tool_calls", []) or []:
        fn = tc.get("function", {})
        parts.append(f"<tool_call name={fn.get('name')} args={fn.get('arguments')}>")
    return " ".join(parts)
