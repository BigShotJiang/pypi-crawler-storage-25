"""GoalStore (Phase 2.2) — JSON file persistence for `core.goal.Goal`.

Each goal lives in its own file under `~/.caudate/goals/<id>.json`.
An `active` symlink (or fallback marker file) points to the most
recently activated goal so the REPL can resume into it on next launch.

Design choices:
  - **One file per goal** so loading + listing are cheap.
  - **No DB.** JSON keeps the data inspectable + grep-able with
    standard tools.
  - **Active goal is a soft pointer** (symlink → falls back to a
    `<id>.json` marker if the OS doesn't support symlinks).
  - **Best-effort everywhere.** Missing files / bad JSON returns None,
    not an exception, so the agent never crashes because the goals
    dir went weird.
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime
from pathlib import Path

from core.goal import Goal, GoalStatus

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------
# Paths — overridable via env var for tests.
# ---------------------------------------------------------------------

def _default_root() -> Path:
    override = os.environ.get("CAUDATE_GOALS_DIR")
    if override:
        return Path(override).expanduser()
    return Path.home() / ".caudate" / "goals"


# ---------------------------------------------------------------------
# Store
# ---------------------------------------------------------------------

class GoalStore:
    """File-backed persistence for Goal objects.

    Thread-safety: not thread-safe. Caudate's REPL is single-threaded
    per session; background tasks (subagents) get their own store
    instances pointed at the same directory.
    """

    def __init__(self, root: Path | str | None = None):
        self.root = Path(root) if root else _default_root()
        try:
            self.root.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            logger.warning(f"goals dir create failed: {e}")

    # ── Write ──────────────────────────────────────────────────────

    def save(self, goal: Goal) -> bool:
        """Persist a goal. Returns True on success, False on I/O error.
        Updates the goal's `updated_at` as a side effect."""
        goal.touch()
        path = self._path_for(goal.id)
        try:
            tmp = path.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(goal.to_dict(), indent=2))
            tmp.replace(path)
            logger.debug(f"goal saved: {goal.id[:8]} ({goal.status.value})")
            return True
        except Exception as e:
            logger.warning(f"goal save failed for {goal.id[:8]}: {e}")
            return False

    # ── Read ───────────────────────────────────────────────────────

    def load(self, goal_id: str) -> Goal | None:
        """Load by full ID or short-prefix (≥4 chars). Returns None
        if not found or unreadable."""
        path = self._resolve_id(goal_id)
        if path is None:
            return None
        try:
            data = json.loads(path.read_text())
            return Goal.from_dict(data)
        except Exception as e:
            logger.warning(f"goal load failed for {goal_id!r}: {e}")
            return None

    def list(self, status: GoalStatus | None = None, limit: int = 20) -> list[Goal]:
        """Return goals sorted by `updated_at` descending.

        `status` filters; `None` returns all. `limit` caps the result —
        use `limit=0` for unlimited."""
        out: list[Goal] = []
        try:
            for p in self.root.glob("*.json"):
                if p.name.startswith("."):
                    continue
                try:
                    data = json.loads(p.read_text())
                except Exception:
                    continue
                g = Goal.from_dict(data)
                if status is not None and g.status != status:
                    continue
                out.append(g)
        except Exception as e:
            logger.debug(f"goal list failed: {e}")
        out.sort(key=lambda g: g.updated_at, reverse=True)
        if limit > 0:
            out = out[:limit]
        return out

    def exists(self, goal_id: str) -> bool:
        return self._resolve_id(goal_id) is not None

    # ── Active goal pointer ────────────────────────────────────────

    @property
    def active_pointer(self) -> Path:
        return self.root / ".active"

    def set_active(self, goal_id: str | None) -> bool:
        """Mark `goal_id` as the active goal (resumed on next launch).
        Pass `None` to clear the pointer."""
        try:
            if goal_id is None:
                if self.active_pointer.exists():
                    self.active_pointer.unlink()
                return True
            if not self.exists(goal_id):
                return False
            # Write the resolved (full) id so the pointer is unambiguous.
            full_id = self._resolve_id(goal_id).stem
            self.active_pointer.write_text(full_id.strip())
            return True
        except Exception as e:
            logger.debug(f"set_active failed: {e}")
            return False

    def active(self) -> Goal | None:
        """Return the current active goal, or None if none set / missing."""
        try:
            if not self.active_pointer.exists():
                return None
            full_id = self.active_pointer.read_text().strip()
            if not full_id:
                return None
            return self.load(full_id)
        except Exception as e:
            logger.debug(f"active() failed: {e}")
            return None

    # ── Maintenance ────────────────────────────────────────────────

    def archive(self, goal_id: str) -> bool:
        """Move a goal's file to `<root>/archive/`. Useful for
        `/goal abandon` so the active list stays manageable."""
        path = self._resolve_id(goal_id)
        if path is None:
            return False
        try:
            archive_dir = self.root / "archive"
            archive_dir.mkdir(exist_ok=True)
            path.replace(archive_dir / path.name)
            # Clear the active pointer if it pointed here.
            if self.active_pointer.exists():
                try:
                    if self.active_pointer.read_text().strip() == path.stem:
                        self.active_pointer.unlink()
                except Exception:
                    pass
            return True
        except Exception as e:
            logger.debug(f"archive failed for {goal_id!r}: {e}")
            return False

    def count(self, status: GoalStatus | None = None) -> int:
        """Total goals matching the status filter."""
        n = 0
        try:
            for p in self.root.glob("*.json"):
                if p.name.startswith("."):
                    continue
                if status is None:
                    n += 1
                    continue
                try:
                    data = json.loads(p.read_text())
                    if Goal.from_dict(data).status == status:
                        n += 1
                except Exception:
                    continue
        except Exception:
            pass
        return n

    # ── Internals ──────────────────────────────────────────────────

    def _path_for(self, goal_id: str) -> Path:
        return self.root / f"{goal_id}.json"

    def _resolve_id(self, goal_id: str) -> Path | None:
        """Accept either a full UUID or a short prefix (≥4 chars).
        Returns the path of the matching goal file or None.
        Ambiguous prefixes return None and log a warning."""
        if not goal_id:
            return None
        # Direct hit
        direct = self._path_for(goal_id)
        if direct.exists():
            return direct
        # Prefix match
        if len(goal_id) < 4:
            return None
        try:
            matches = [p for p in self.root.glob(f"{goal_id}*.json") if not p.name.startswith(".")]
            if len(matches) == 1:
                return matches[0]
            if len(matches) > 1:
                logger.warning(
                    f"ambiguous goal prefix {goal_id!r} matches {len(matches)} goals; "
                    f"specify more characters"
                )
        except Exception:
            pass
        return None


# ---------------------------------------------------------------------
# Module-level singleton — agent code can just `from core.goal_store
# import get_store` and skip threading the instance around.
# ---------------------------------------------------------------------

_store: GoalStore | None = None


def get_store() -> GoalStore:
    """Return the process-wide singleton GoalStore."""
    global _store
    if _store is None:
        _store = GoalStore()
    return _store


def reset_store_for_test(root: Path | str) -> GoalStore:
    """Test-only: swap the singleton to point at `root`. Returns the
    new store."""
    global _store
    _store = GoalStore(root=root)
    return _store
