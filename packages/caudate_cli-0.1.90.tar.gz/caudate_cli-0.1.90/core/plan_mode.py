"""Plan Mode + system FSM — read-only flag and explicit phase tracking.

Two layers sharing one module-level state:

1. **Bool API** (`is_active`, `enter`, `exit_mode`) — the historical
   plan-mode toggle. When ON, the executor refuses any tool whose
   `mutates = True` (Bash, Write, Edit, PythonExec, HttpRequest, …).
   Read-only tools (Read, Grep, Glob, SystemInfo, …) still work.

2. **Phase FSM** (`SystemState`, `current_state`, `transition_to`,
   `can_write`, `handle_validation_failure`) — formal 5-state machine
   mirroring /home/raveuk/src/orchestrator/state_machine.py. Adds
   explicit PLAN / EXEC / VALIDATION / RECOVERY / TERMINATED phases
   with allowed-transition guards, a per-state write-lock matrix, and
   a failure counter that auto-escalates to RECOVERY after
   `MAX_TASK_FAILURES` strikes.

The two layers are coupled: `is_active()` returns True iff the
current state does **not** allow writes. So `enter()` puts us in
PLAN_MODE, `exit_mode()` returns us to EXEC_MODE, and the FSM can
also flip the bool implicitly by transitioning to VALIDATION_MODE
or RECOVERY_MODE.

Use case for the bool API: the user asks for a complex change, the
agent plans the edits, the user reviews, then exits plan mode to
actually make the changes. Mirrors Claude Code's Plan Mode UX.

Use case for the FSM: the cognitive loop drives explicit phase
transitions so write-blocking has rigor (only EXEC writes) and
repeated validation failures route to a recovery handler.

Process-global state — Cognos is single-user, simple is better than
per-session here.
"""

from __future__ import annotations

import enum
import logging
import threading

try:
    from config import MAX_TASK_FAILURES as _DEFAULT_MAX_FAILURES
except Exception:  # config import failure shouldn't crash plan_mode
    _DEFAULT_MAX_FAILURES = 2

logger = logging.getLogger(__name__)


class SystemState(str, enum.Enum):
    """Phase of the cognitive loop. Mirrors src/orchestrator FSM."""
    PLAN_MODE = "PLAN_MODE"
    EXEC_MODE = "EXEC_MODE"
    VALIDATION_MODE = "VALIDATION_MODE"
    RECOVERY_MODE = "RECOVERY_MODE"
    TERMINATED = "TERMINATED"


class StateMachineError(Exception):
    """Raised on illegal state transitions."""


# Only EXEC_MODE may write. Everything else is read-only — this is the
# write-lock matrix from the dual-brain spec.
_WRITES_ALLOWED: dict[SystemState, bool] = {
    SystemState.PLAN_MODE: False,
    SystemState.EXEC_MODE: True,
    SystemState.VALIDATION_MODE: False,
    SystemState.RECOVERY_MODE: False,
    SystemState.TERMINATED: False,
}

_ALLOWED_TRANSITIONS: dict[SystemState, list[SystemState]] = {
    SystemState.PLAN_MODE: [SystemState.EXEC_MODE, SystemState.TERMINATED],
    SystemState.EXEC_MODE: [SystemState.VALIDATION_MODE, SystemState.PLAN_MODE,
                            SystemState.TERMINATED],
    SystemState.VALIDATION_MODE: [SystemState.PLAN_MODE, SystemState.EXEC_MODE,
                                  SystemState.RECOVERY_MODE, SystemState.TERMINATED],
    SystemState.RECOVERY_MODE: [SystemState.PLAN_MODE, SystemState.TERMINATED],
    SystemState.TERMINATED: [],
}


class _PlanState:
    """Wraps the FSM in a class so swaps are atomic and observable."""

    def __init__(self) -> None:
        # Default phase is EXEC_MODE — writes allowed, plan-mode bool OFF.
        self._state: SystemState = SystemState.EXEC_MODE
        self._failure_counter: int = 0
        self._max_failures: int = int(_DEFAULT_MAX_FAILURES)
        self._lock = threading.Lock()

    # ---- bool API ----
    def is_active(self) -> bool:
        """True iff writes are currently blocked (any non-EXEC state)."""
        return not _WRITES_ALLOWED[self._state]

    def enter(self) -> bool:
        """Force PLAN_MODE. Returns True if state changed."""
        with self._lock:
            if self._state == SystemState.PLAN_MODE:
                return False
            self._state = SystemState.PLAN_MODE
            logger.info("Plan mode: ON (state=PLAN_MODE, writes blocked)")
            return True

    def exit(self) -> bool:
        """Force EXEC_MODE. Returns True if state changed."""
        with self._lock:
            if self._state == SystemState.EXEC_MODE:
                return False
            self._state = SystemState.EXEC_MODE
            self._failure_counter = 0  # fresh exec scope
            logger.info("Plan mode: OFF (state=EXEC_MODE, writes allowed)")
            return True

    # ---- FSM API ----
    def current_state(self) -> SystemState:
        return self._state

    def can_write(self) -> bool:
        return _WRITES_ALLOWED[self._state]

    def transition_to(self, target: SystemState, reason: str = "") -> None:
        with self._lock:
            allowed = _ALLOWED_TRANSITIONS[self._state]
            if target not in allowed:
                raise StateMachineError(
                    f"Illegal transition {self._state.value} -> {target.value}"
                    + (f" (reason: {reason})" if reason else "")
                )
            logger.info(
                f"FSM: {self._state.value} -> {target.value}"
                + (f" ({reason})" if reason else "")
            )
            self._state = target
            if target == SystemState.EXEC_MODE:
                self._failure_counter = 0  # exec scope resets counter

    def handle_validation_failure(self, error_trace: str = "") -> SystemState:
        """Increment failure counter; escalate to RECOVERY past threshold.

        Returns the new state. Counter resets when EXEC_MODE is next
        entered (either via `exit()` or `transition_to(EXEC_MODE, ...)`).
        """
        with self._lock:
            self._failure_counter += 1
            if self._failure_counter >= self._max_failures:
                if SystemState.RECOVERY_MODE in _ALLOWED_TRANSITIONS[self._state]:
                    self._state = SystemState.RECOVERY_MODE
                    logger.warning(
                        f"FSM: validation failure threshold "
                        f"({self._failure_counter}/{self._max_failures}) "
                        f"-> RECOVERY_MODE. trace={error_trace[:200]}"
                    )
                else:
                    logger.warning(
                        f"FSM: failure threshold met but RECOVERY not "
                        f"reachable from {self._state.value}; staying put"
                    )
            else:
                logger.info(
                    f"FSM: validation failure "
                    f"{self._failure_counter}/{self._max_failures}"
                )
            return self._state

    def failure_count(self) -> int:
        return self._failure_counter

    def set_max_failures(self, n: int) -> None:
        with self._lock:
            self._max_failures = max(1, int(n))


_STATE = _PlanState()


# ---- bool API (back-compat) ----
def is_active() -> bool:
    return _STATE.is_active()


def enter() -> bool:
    return _STATE.enter()


def exit_mode() -> bool:
    return _STATE.exit()


# ---- FSM API ----
def current_state() -> SystemState:
    return _STATE.current_state()


def can_write() -> bool:
    return _STATE.can_write()


def transition_to(target: SystemState, reason: str = "") -> None:
    _STATE.transition_to(target, reason)


def handle_validation_failure(error_trace: str = "") -> SystemState:
    return _STATE.handle_validation_failure(error_trace)


def failure_count() -> int:
    return _STATE.failure_count()


def set_max_failures(n: int) -> None:
    _STATE.set_max_failures(n)
