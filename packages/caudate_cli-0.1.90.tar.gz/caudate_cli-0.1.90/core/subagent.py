"""Subagent manager — spawn, track, and collect isolated child agents.

A subagent is a child AgenticLoop with its own message history, its own
system prompt, and a restricted tool subset. It shares the parent's
long-term memory (episodic/semantic) but in read-only mode — the subagent
does not consolidate lessons back.

Subagents can run sequentially or in parallel. Parallel execution is
bounded by `max_concurrent` to avoid overloading local LLMs.
"""

from __future__ import annotations

import asyncio
import logging
import uuid
from dataclasses import dataclass, field
from typing import Any

from core.agentic_loop import AgenticLoop
from core.hooks import HookEvent, HookManager
from core.permissions import PermissionManager
from core.worktree import Worktree, create_worktree
from execution.executor import Executor
from llm.provider import LLMProvider

logger = logging.getLogger(__name__)


SUBAGENT_PROFILES: dict[str, dict[str, Any]] = {
    "general-purpose": {
        "tools": ["Read", "Write", "Edit", "Glob", "Grep", "Bash", "PythonExec",
                  "WebSearch", "WebFetch", "Think", "Respond"],
        "system": (
            "You are a general-purpose subagent. Focus narrowly on the task you "
            "were given. Use tools as needed. When done, respond with a concise "
            "summary — that summary is returned to your parent agent."
        ),
    },
    "research": {
        "tools": ["WebSearch", "WebFetch", "Think", "Respond"],
        "system": (
            "You are a research subagent. Search the web, fetch and read pages, "
            "then synthesize findings. Cite sources. End with a concise summary."
        ),
    },
    "code-review": {
        "tools": ["Read", "Glob", "Grep", "Think", "Respond"],
        "system": (
            "You are a code-review subagent. Read the specified files, identify "
            "bugs/smells/risks, and report a prioritized list with file:line "
            "references. Do NOT modify files — review only."
        ),
    },
    # Dual-brain roles — mirror /home/raveuk/src/prompts/system_prompts.json.
    # `executor_brain_01` runs linear plans; on twice-failed validation
    # it dispatches context to `critic_brain_02` through the inter-agent
    # bus and waits for a reply. `critic_brain_02` reviews structural
    # problems and outputs fixes exclusively as diff patches.
    "executor_brain": {
        "tools": ["Read", "Write", "Edit", "Glob", "Grep", "Bash", "PythonExec",
                  "Think", "Respond", "Agent"],
        "system": (
            "ROLE: You are 'executor_brain_01'. Run tasks linearly. If "
            "validation fails twice, escalate via inter_agent_bus to "
            "critic_brain_02 with the failing context attached. Wait for "
            "the critic's reply before retrying."
        ),
    },
    "critic_brain": {
        "tools": ["Read", "Glob", "Grep", "Think", "Respond"],
        "system": (
            "ROLE: You are 'critic_brain_02'. You review structural "
            "problems and output fixes exclusively as diff patches. "
            "Read the failing context, identify the root cause, and "
            "emit a unified diff (`---/+++` headers, `@@` hunks) that "
            "the executor can apply directly. Do not modify files "
            "yourself — review only."
        ),
    },
}


# ---------------------------------------------------------------------------
# Inter-agent bus — async queue channels between named agents.
#
# Mirrors /home/raveuk/src/communication/bus.py: one queue per registered
# agent id, plus a futures dict for request/reply when the sender wants
# to suspend until the recipient replies. Lives inline (no new file)
# because it's tiny and only the SubagentManager wires it.
# ---------------------------------------------------------------------------


class InterAgentBus:
    """Async message bus keyed by agent id (e.g. executor_brain_01)."""

    def __init__(self, agent_ids: list[str] | None = None):
        ids = agent_ids or ["executor_brain_01", "critic_brain_02"]
        self.channels: dict[str, asyncio.Queue] = {a: asyncio.Queue() for a in ids}
        self.pending: dict[str, asyncio.Future] = {}

    def register(self, agent_id: str) -> None:
        self.channels.setdefault(agent_id, asyncio.Queue())

    async def send(
        self,
        sender_id: str,
        recipient_id: str,
        context: str,
        suspend_sender: bool = False,
    ) -> Any | None:
        if recipient_id not in self.channels:
            raise ValueError(f"Bus address '{recipient_id}' is not registered.")
        payload: dict[str, Any] = {
            "sender_id": sender_id,
            "context": context,
            "requires_reply": suspend_sender,
        }
        if suspend_sender:
            loop = asyncio.get_event_loop()
            fut: asyncio.Future = loop.create_future()
            corr_id = f"{sender_id}->{recipient_id}:{id(fut)}"
            payload["correlation_id"] = corr_id
            self.pending[corr_id] = fut
            await self.channels[recipient_id].put(payload)
            try:
                return await fut
            finally:
                self.pending.pop(corr_id, None)
        await self.channels[recipient_id].put(payload)
        return None

    async def recv(self, agent_id: str) -> dict[str, Any]:
        if agent_id not in self.channels:
            raise ValueError(f"Bus address '{agent_id}' is not registered.")
        return await self.channels[agent_id].get()

    def reply(self, correlation_id: str, result: Any) -> bool:
        fut = self.pending.get(correlation_id)
        if fut is None or fut.done():
            return False
        fut.set_result(result)
        return True


@dataclass
class SubagentRun:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    subagent_type: str = "general-purpose"
    task: str = ""
    result: str | None = None
    error: str | None = None
    worktree_path: str | None = None
    worktree_branch: str | None = None


class SubagentManager:
    """Spawns child agents with restricted tool sets."""

    def __init__(
        self,
        llm: LLMProvider,
        parent_executor: Executor,
        episodic=None,
        semantic=None,
        permissions: PermissionManager | None = None,
        hooks: HookManager | None = None,
        max_concurrent: int = 3,
        max_iterations: int = 10,
    ):
        self.llm = llm
        self.parent_executor = parent_executor
        self.episodic = episodic
        self.semantic = semantic
        self.permissions = permissions
        self.hooks = hooks or HookManager()
        self.max_concurrent = max_concurrent
        self.max_iterations = max_iterations
        self._semaphore = asyncio.Semaphore(max_concurrent)
        # Inter-agent bus — pre-registers the two dual-brain addresses.
        # Additional ids can be added via `self.bus.register(...)`.
        self.bus = InterAgentBus()

    async def dispatch(
        self,
        sender_id: str,
        recipient_id: str,
        context: str,
        suspend_sender: bool = False,
    ) -> Any | None:
        """Send a message on the inter-agent bus.

        When `suspend_sender` is True, awaits a reply from the recipient
        and returns it. Otherwise fire-and-forget.
        """
        return await self.bus.send(sender_id, recipient_id, context, suspend_sender)

    async def run_one(
        self,
        task: str,
        subagent_type: str = "general-purpose",
        isolation: str | None = None,
    ) -> SubagentRun:
        """Run a single subagent to completion.

        `isolation="worktree"` creates a temporary git worktree the
        subagent operates in. The worktree path is returned on the run
        so the caller can review or discard it. If creation fails, the
        run continues in the parent's working tree (best-effort).
        """
        profile = SUBAGENT_PROFILES.get(subagent_type, SUBAGENT_PROFILES["general-purpose"])
        run = SubagentRun(subagent_type=subagent_type, task=task)

        await self.hooks.emit(HookEvent.SUBAGENT_START, {
            "subagent_id": run.id,
            "subagent_type": subagent_type,
            "task": task,
            "isolation": isolation,
        })

        wt: Worktree | None = None
        if isolation == "worktree":
            wt = await create_worktree()
            if wt is not None:
                run.worktree_path = str(wt.path)
                run.worktree_branch = wt.branch
                logger.info(f"Subagent {run.id} running in worktree {wt.path}")

        async with self._semaphore:
            try:
                child_executor = _restricted_executor(
                    self.parent_executor, profile["tools"], self.llm,
                )
                child = AgenticLoop(
                    llm=self.llm,
                    executor=child_executor,
                    episodic=self.episodic,
                    semantic=self.semantic,
                    system_prompt=profile["system"],
                    max_iterations=self.max_iterations,
                    permissions=self.permissions,
                )
                if wt is not None:
                    # Tell tools the new working directory by chdir-ing
                    # for the duration of this run. AgenticLoop is async
                    # but we keep this call boundary serialized via the
                    # semaphore, so a process-level chdir is OK here.
                    import os
                    prev_cwd = os.getcwd()
                    os.chdir(wt.path)
                    try:
                        run.result = await child.run(task)
                    finally:
                        os.chdir(prev_cwd)
                else:
                    run.result = await child.run(task)
            except Exception as e:
                logger.warning(f"Subagent {run.id} failed: {e}")
                run.error = str(e)
            finally:
                if wt is not None:
                    await wt.cleanup(force=False)

        await self.hooks.emit(HookEvent.SUBAGENT_STOP, {
            "subagent_id": run.id,
            "result": run.result,
            "error": run.error,
            "worktree_path": run.worktree_path,
        })
        return run

    async def run_parallel(
        self,
        tasks: list[tuple[str, str]],
        isolation: str | None = None,
    ) -> list[SubagentRun]:
        """Run multiple subagents concurrently. Each tuple = (task, subagent_type)."""
        return await asyncio.gather(*(
            self.run_one(task, t, isolation=isolation) for task, t in tasks
        ))


def _restricted_executor(
    parent: Executor,
    allowed_tools: list[str],
    llm: LLMProvider,
) -> Executor:
    """Create a new executor exposing only the allowed tools.

    Rather than deep-copying the parent, build a fresh Executor with the
    allowed subset. This keeps the restriction airtight.
    """
    child = Executor.__new__(Executor)
    child._tools = {}
    child._llm = llm
    for name in allowed_tools:
        tool = parent.get_tool(name)
        if tool is not None:
            child._tools[tool.name] = tool
    return child
