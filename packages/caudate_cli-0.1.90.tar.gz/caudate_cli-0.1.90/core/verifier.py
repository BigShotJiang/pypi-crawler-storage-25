"""Verifier (Phase 3.3) — programmatic post-build sanity checks.

When the agent finishes a "build me X" turn that wrote files matching
a web-app pattern, the Verifier:

1. Reads the recent turn's tool calls to discover what port + entry
   point the agent launched
2. Curls `/` on that port to confirm the server actually responds
3. Parses the HTML response for `static/...` references; curls each
   and reports any 404s
4. Returns a structured `VerifyResult` that the loop converts into a
   synthetic tool_result the agent sees on the NEXT iteration —
   giving it one programmatic chance to fix what's broken before
   the turn closes

What the Verifier does NOT do (intentional scope cuts):
- Launch the app itself. The model handles that via the existing
  Run-and-verify system-prompt rule. We just check the result.
- pip install. Same — leave to the model.
- API-endpoint smoke. Out of scope for this sub-step; the static-
  asset check is the highest-leverage one (catches the path-mismatch
  bug we hit during the YouTube downloader build).
- Anything beyond cwd. Scoped strictly to the active workspace.

Phase 1.1 cross-link: when the Verifier runs, it calls
`OutcomeCollector.on_verify_result(passed=…)` and `.on_static_404(n)`
so the learning loop sees the same signal.
"""

from __future__ import annotations

import logging
import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)


# Common dev-server ports the agent might launch. Order matters —
# checked in this order until one responds.
_LIKELY_PORTS = (5555, 5000, 8000, 8080, 3000, 4000, 5173)

# Project markers — if any of these are present in the cwd, the
# project "looks like a web app" and verification is worthwhile.
_WEB_PROJECT_MARKERS = (
    "app.py", "main.py", "server.py", "index.js", "server.js",
    "package.json", "next.config.js", "requirements.txt",
    "templates", "static",
)


@dataclass
class VerifyResult:
    """What the Verifier observed."""

    ran: bool = False                  # did we even attempt?
    skipped_reason: str = ""           # why ran=False
    server_url: str = ""               # the URL we actually probed
    server_status: int | None = None   # HTTP code (200/4xx/5xx)
    static_refs: list[str] = field(default_factory=list)
    static_404s: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)

    def passed(self) -> bool:
        """True iff we ran AND the response was 200 AND no static 404s."""
        return (
            self.ran
            and self.server_status is not None
            and 200 <= self.server_status < 400
            and not self.static_404s
        )

    def summary(self) -> str:
        """One-paragraph synthesis suitable for injecting into a
        tool_result the agent will see on the next iteration."""
        if not self.ran:
            return f"[verifier] skipped: {self.skipped_reason}"
        if self.server_status is None:
            return (
                "[verifier] FAIL: could not reach the launched server. "
                "Check the background launch — process may have crashed. "
                f"Probed: {self.server_url}. " + " ".join(self.notes)
            )
        bits = [
            f"[verifier] {self.server_url} → HTTP {self.server_status}",
        ]
        if self.static_404s:
            bits.append(
                f"FAIL: {len(self.static_404s)} static asset(s) referenced "
                f"in HTML returned 404: {', '.join(self.static_404s[:5])}. "
                f"FIX: move the files or update the HTML refs."
            )
        elif self.passed():
            bits.append(
                f"PASS: {len(self.static_refs)} static asset(s) all loaded. "
                f"App is responding correctly."
            )
        return "  ".join(bits)


class Verifier:
    """Post-build sanity checker.

    Stateless per call — pass it the cwd + a list of recent Bash
    commands the agent issued (so it can pick the right port) and
    it returns a `VerifyResult`.
    """

    def __init__(self, cwd: str | Path):
        self.cwd = Path(cwd)

    # ─── Top-level entry point ────────────────────────────────────

    def run(self, recent_bash_commands: list[str] | None = None) -> VerifyResult:
        """Run the verification suite. Best-effort; never raises."""
        result = VerifyResult()

        if not self._looks_like_web_project():
            result.skipped_reason = (
                f"cwd {self.cwd} doesn't look like a web app "
                f"(no app.py / package.json / templates / static)"
            )
            return result

        # Find the port the agent probably launched on.
        port = self._discover_port(recent_bash_commands or [])
        if port is None:
            result.skipped_reason = (
                "could not discover a port — the agent didn't appear to "
                "launch a server. Skipping verify."
            )
            return result

        result.ran = True
        url = f"http://127.0.0.1:{port}/"
        result.server_url = url

        # Step 1: GET / and capture body
        body, status = self._http_get(url, timeout=8.0)
        result.server_status = status
        if status is None:
            result.notes.append("connection refused / timeout")
            return result
        if not (200 <= status < 400):
            return result  # bad status; don't bother with static refs

        # Step 2: extract `/static/...` references from the body
        refs = self._extract_static_refs(body or "")
        result.static_refs = refs
        # Step 3: curl each, record 404s
        for ref in refs:
            ref_url = f"http://127.0.0.1:{port}{ref}"
            _, ref_status = self._http_get(ref_url, timeout=3.0, head_only=True)
            if ref_status is None or not (200 <= ref_status < 400):
                result.static_404s.append(ref)

        return result

    # ─── Helpers ──────────────────────────────────────────────────

    def _looks_like_web_project(self) -> bool:
        if not self.cwd.exists() or not self.cwd.is_dir():
            return False
        for marker in _WEB_PROJECT_MARKERS:
            if (self.cwd / marker).exists():
                return True
        return False

    def _discover_port(self, recent_bash_commands: list[str]) -> int | None:
        """Inspect recent Bash commands for a port pattern. Common
        shapes: `app.run(port=5555)`, `--port 8080`, `:5000`."""
        candidates: list[int] = []
        for cmd in recent_bash_commands:
            # Explicit --port N
            m = re.search(r"--port[=\s]+(\d{2,5})", cmd)
            if m:
                candidates.append(int(m.group(1)))
            # Common :PORT in URLs or args
            for m in re.finditer(r"[:\s](\d{4,5})\b", cmd):
                p = int(m.group(1))
                if 1024 <= p <= 65535:
                    candidates.append(p)
        # Fallback: check which of the likely ports is actually listening
        for p in candidates + list(_LIKELY_PORTS):
            if self._port_listening(p):
                return p
        return None

    def _port_listening(self, port: int) -> bool:
        try:
            r = subprocess.run(
                ["ss", "-tln", f"sport = :{port}"],
                capture_output=True, text=True, timeout=3.0,
            )
            return f":{port}" in (r.stdout or "")
        except Exception:
            return False

    def _http_get(
        self,
        url: str,
        timeout: float = 5.0,
        head_only: bool = False,
    ) -> tuple[str | None, int | None]:
        """Return (body, status). Body may be None for HEAD-style /
        connection failures."""
        try:
            args = [
                "curl", "-sS",
                "--max-time", str(int(timeout)),
                "-o", "-" if not head_only else "/dev/null",
                "-w", "\n__STATUS__%{http_code}",
                url,
            ]
            r = subprocess.run(args, capture_output=True, text=True, timeout=timeout + 2)
            out = r.stdout or ""
            if "__STATUS__" not in out:
                return None, None
            body, _, status_str = out.rpartition("__STATUS__")
            try:
                status = int(status_str.strip())
            except (TypeError, ValueError):
                return body or None, None
            if status == 0:  # curl couldn't connect
                return None, None
            return body or None, status
        except Exception as e:
            logger.debug(f"http_get {url} failed: {e}")
            return None, None

    def _extract_static_refs(self, body: str) -> list[str]:
        """Pull out unique `/static/...` URL paths referenced in src/href."""
        if not body:
            return []
        seen: set[str] = set()
        out: list[str] = []
        # match src="..." href="..." with /static prefix (relative or absolute)
        for m in re.finditer(
            r'''(?:src|href)\s*=\s*['"](\s*/static/[^'"\s]+)['"]''',
            body,
        ):
            ref = m.group(1).strip()
            if ref not in seen:
                seen.add(ref)
                out.append(ref)
        return out
