"""Status line — single-line status above the input prompt.

The format is a Python `str.format` template pulled from settings
(`statusline` key). Available placeholders:

  {model}          active model id
  {mood}           personality mood label or 'n/a'
  {session}        full session id
  {session_short}  first 8 chars of session id
  {tokens}         total tokens this session
  {cost}           total $ cost this session
  {turn}           message count

Missing fields render as the literal placeholder so a malformed template
doesn't crash the prompt — render once, decide it's wrong, re-render.
"""

from __future__ import annotations

from typing import Any


class _SafeMap(dict):
    def __missing__(self, key: str) -> str:
        return "{" + key + "}"


def render_statusline(template: str, values: dict[str, Any]) -> str:
    """Format `template` using {placeholders}; missing keys are kept literal."""
    try:
        return template.format_map(_SafeMap(values))
    except Exception:
        return template


def build_status_values(agent: Any) -> dict[str, Any]:
    """Pull every documented placeholder value off a CognosAgent."""
    from core.usage import get_global_tracker
    tracker = get_global_tracker()
    mood = "n/a"
    try:
        if agent.personality is not None:
            mood = agent.personality.mood.label()
    except Exception:
        pass
    session_id = ""
    turn = 0
    try:
        session_id = agent.session.id
        turn = len(agent.session.messages)
    except Exception:
        pass
    perm_mode = "default"
    try:
        if agent.permissions is not None:
            perm_mode = getattr(agent.permissions, "mode", None)
            if hasattr(perm_mode, "value"):
                perm_mode = perm_mode.value
    except Exception:
        pass
    # Decorate non-default modes so the bar reads at a glance.
    _MODE_LABELS = {
        "auto":         "⏵⏵ auto",
        "bypass":       "⏵ bypass",
        "plan":         "▣ plan",
        "accept_edits": "✎ accept_edits",
    }
    display_mode = _MODE_LABELS.get(perm_mode, perm_mode)
    return {
        "model": getattr(agent.llm, "model", "?"),
        "mood": mood,
        "session": session_id,
        "session_short": session_id[:8],
        "tokens": tracker.total_tokens(),
        "cost": tracker.total_cost(),
        "turn": turn,
        "mode": display_mode,
        "mode_raw": perm_mode,
    }
