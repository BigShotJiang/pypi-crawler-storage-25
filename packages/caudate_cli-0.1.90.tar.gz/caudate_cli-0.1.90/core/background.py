"""Background task management — run agent turns asynchronously.

A background task is a CognosAgent.chat call that's been kicked off
without blocking the REPL. The pool tracks each task by id, exposes
status (pending/running/done/failed), and stores the final reply so the
user can `watch` it later.

This is intentionally process-local: when the CLI exits, in-flight
tasks are abandoned. Persistence would require a separate worker
process or supervisor — outside scope of a UX feature.
"""

from __future__ import annotations

import asyncio
import logging
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

logger = logging.getLogger(__name__)


@dataclass
class BackgroundTask:
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])
    label: str = ""
    status: str = "pending"          # pending | running | done | failed | cancelled
    started_at: float = 0.0
    finished_at: float = 0.0
    result: str | None = None
    error: str | None = None
    _task: asyncio.Task | None = field(default=None, repr=False)

    @property
    def duration(self) -> float:
        if not self.started_at:
            return 0.0
        end = self.finished_at or time.time()
        return end - self.started_at


class BackgroundTaskPool:
    """In-process pool of CognosAgent invocations."""

    def __init__(self) -> None:
        self._tasks: dict[str, BackgroundTask] = {}

    def submit(
        self,
        coro_factory: Callable[[], Awaitable[Any]],
        label: str = "",
    ) -> BackgroundTask:
        """Schedule `coro_factory()` on the running loop.

        Must be called from within a running asyncio loop. The factory
        is invoked once, immediately, and the resulting awaitable is
        wrapped in a Task. The BackgroundTask handle is returned
        synchronously so the caller can show an id.
        """
        bg = BackgroundTask(label=label)
        bg.status = "running"
        bg.started_at = time.time()
        loop = asyncio.get_running_loop()

        async def _runner() -> None:
            try:
                result = await coro_factory()
                bg.result = str(result) if result is not None else ""
                bg.status = "done"
            except asyncio.CancelledError:
                bg.status = "cancelled"
                raise
            except Exception as e:
                bg.error = str(e)
                bg.status = "failed"
                logger.exception(f"Background task {bg.id} failed: {e}")
            finally:
                bg.finished_at = time.time()

        bg._task = loop.create_task(_runner(), name=f"cognos-bg-{bg.id}")
        self._tasks[bg.id] = bg
        return bg

    def get(self, task_id: str) -> BackgroundTask | None:
        return self._tasks.get(task_id)

    def list(self) -> list[BackgroundTask]:
        return sorted(self._tasks.values(), key=lambda t: t.started_at, reverse=True)

    def cancel(self, task_id: str) -> bool:
        bg = self._tasks.get(task_id)
        if bg is None or bg._task is None or bg._task.done():
            return False
        bg._task.cancel()
        return True

    def prune_finished(self) -> int:
        before = len(self._tasks)
        self._tasks = {
            tid: t for tid, t in self._tasks.items()
            if t.status in ("pending", "running")
        }
        return before - len(self._tasks)


# Process-wide pool — mirrors usage tracker.
_GLOBAL = BackgroundTaskPool()


def get_global_pool() -> BackgroundTaskPool:
    return _GLOBAL
