"""@file references — inline or attach files mentioned in user prompts.

Two modes, picked per call site:

  1. **Inline** (default for short prompts) — the file is read and pasted
     into the message inside a fenced code block. Preserves the user's
     literal text but expands the @path token to file contents.

  2. **Attach** (when `file_store` is provided) — the file is uploaded
     to the FileStore and the @path token is replaced with a small
     `[file:<id>]` marker. The returned attachment list goes through
     the same multimodal path as `chat(attachments=...)` so PDFs and
     images work end-to-end.

Tokens follow this grammar:
  - `@path/to/file.py`              — relative or absolute, no spaces
  - `@"path with spaces.txt"`        — quoted form for paths with spaces
  - `@./local.md`, `@~/home.md`      — both supported

Globs (`@src/**/*.py`) are NOT auto-expanded — too easy to flood the
context window. The user can use the Glob tool if they need that.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


# Match either `@"quoted path"` or `@unquoted_path`. The unquoted form
# stops at whitespace; we strip a trailing punctuation char (.,;:!?) so
# `@README.md.` resolves to README.md without the trailing period.
_REF_RE = re.compile(
    r'@(?:"([^"]+)"|([^\s"]+))'
)
_TRAILING_PUNCT = ".,;:!?)]}"


def find_refs(text: str) -> list[str]:
    """Return all @-referenced paths in `text`, preserving order, deduped."""
    seen: dict[str, None] = {}
    for match in _REF_RE.finditer(text):
        raw = match.group(1) or match.group(2) or ""
        if not match.group(1):
            while raw and raw[-1] in _TRAILING_PUNCT:
                raw = raw[:-1]
        if raw:
            seen.setdefault(raw, None)
    return list(seen.keys())


def _resolve(path_str: str) -> Path | None:
    p = Path(path_str).expanduser()
    if not p.is_absolute():
        p = Path.cwd() / p
    return p if p.exists() and p.is_file() else None


def expand_inline(text: str, max_chars_per_file: int = 8000) -> str:
    """Replace each @path with the file's contents in a fenced block."""
    def _sub(match: re.Match) -> str:
        raw = match.group(1) or match.group(2) or ""
        trailing = ""
        if not match.group(1):
            while raw and raw[-1] in _TRAILING_PUNCT:
                trailing = raw[-1] + trailing
                raw = raw[:-1]
        path = _resolve(raw)
        if path is None:
            return match.group(0)  # leave the original token in place
        try:
            content = path.read_text(errors="ignore")
        except Exception as e:
            logger.debug(f"@file read failed for {path}: {e}")
            return match.group(0)
        truncated = content[:max_chars_per_file]
        suffix = ""
        if len(content) > max_chars_per_file:
            suffix = f"\n... (truncated at {max_chars_per_file} chars)"
        lang = path.suffix.lstrip(".") or ""
        return f"\n\n```{lang} {raw}\n{truncated}{suffix}\n```\n" + trailing
    return _REF_RE.sub(_sub, text)


def expand_with_attachments(
    text: str,
    file_store: Any,
) -> tuple[str, list[str]]:
    """Upload each @path to `file_store` and replace with [file:<id>] markers.

    Returns (rewritten_text, [file_id, ...]). The returned list is
    intended to be passed straight to `agent.chat(..., attachments=...)`.
    """
    attachments: list[str] = []

    def _sub(match: re.Match) -> str:
        raw = match.group(1) or match.group(2) or ""
        trailing = ""
        if not match.group(1):
            while raw and raw[-1] in _TRAILING_PUNCT:
                trailing = raw[-1] + trailing
                raw = raw[:-1]
        path = _resolve(raw)
        if path is None:
            return match.group(0)
        try:
            record = file_store.upload(path, filename=path.name)
        except Exception as e:
            logger.debug(f"@file upload failed for {path}: {e}")
            return match.group(0)
        attachments.append(record.id)
        return f"[file:{record.id} {path.name}]" + trailing

    rewritten = _REF_RE.sub(_sub, text)
    return rewritten, attachments
