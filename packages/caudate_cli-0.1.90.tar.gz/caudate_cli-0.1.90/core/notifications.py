"""Cross-platform desktop notifications.

Picks the best available backend on the host:
  - Linux: notify-send (libnotify)
  - macOS: osascript with display notification
  - Windows: powershell BurntToast / win10toast / fall-through

If nothing's available, falls through to the terminal bell + a printed
line so a tmux/ssh user still gets *something*.
"""

from __future__ import annotations

import logging
import shutil
import subprocess
import sys
from typing import Any

logger = logging.getLogger(__name__)


def _notify_linux(title: str, body: str) -> bool:
    if shutil.which("notify-send") is None:
        return False
    try:
        subprocess.run(
            ["notify-send", title, body],
            check=False, timeout=5,
        )
        return True
    except Exception as e:
        logger.debug(f"notify-send failed: {e}")
        return False


def _notify_macos(title: str, body: str) -> bool:
    if shutil.which("osascript") is None:
        return False
    safe_title = title.replace('"', '\\"')
    safe_body = body.replace('"', '\\"')
    script = f'display notification "{safe_body}" with title "{safe_title}"'
    try:
        subprocess.run(
            ["osascript", "-e", script],
            check=False, timeout=5,
        )
        return True
    except Exception as e:
        logger.debug(f"osascript failed: {e}")
        return False


def _notify_windows(title: str, body: str) -> bool:
    # Best-effort: prefer BurntToast if present; fall back to balloon.
    pwsh = shutil.which("powershell") or shutil.which("pwsh")
    if pwsh is None:
        return False
    safe_title = title.replace("'", "''")
    safe_body = body.replace("'", "''")
    script = (
        "if (Get-Module -ListAvailable -Name BurntToast) {"
        f"  New-BurntToastNotification -Text '{safe_title}', '{safe_body}'"
        "} else {"
        "  Add-Type -AssemblyName System.Windows.Forms;"
        "  $b = New-Object System.Windows.Forms.NotifyIcon;"
        "  $b.Icon = [System.Drawing.SystemIcons]::Information;"
        f"  $b.BalloonTipTitle = '{safe_title}';"
        f"  $b.BalloonTipText = '{safe_body}';"
        "  $b.Visible = $true;"
        "  $b.ShowBalloonTip(5000)"
        "}"
    )
    try:
        subprocess.run(
            [pwsh, "-NoProfile", "-Command", script],
            check=False, timeout=10,
        )
        return True
    except Exception as e:
        logger.debug(f"PowerShell notify failed: {e}")
        return False


def notify(title: str, body: str = "", **_: Any) -> bool:
    """Show a desktop notification. Returns True if a backend handled it."""
    if sys.platform.startswith("linux"):
        if _notify_linux(title, body):
            return True
    elif sys.platform == "darwin":
        if _notify_macos(title, body):
            return True
    elif sys.platform.startswith("win"):
        if _notify_windows(title, body):
            return True

    # Fallthrough — terminal bell so the user notices.
    print(f"\a[notify] {title}: {body}", flush=True)
    return False
