"""Image / PDF paste detection.

Most terminals don't paste binary content directly. What you actually
get when dragging an image or a PDF into the prompt is the *path* to
that file, often quoted (macOS Terminal, iTerm, Alacritty, kitty all
behave this way). This module scans an input line for those bare paths,
uploads anything that's an image or a PDF to the FileStore, and returns
the cleaned text plus a list of attachment ids ready for `chat()`.

Distinct from `core.file_refs.expand_with_attachments`:
  - `file_refs` requires an explicit `@` prefix (intentional).
  - `paste` is heuristic — it triggers on any quoted path or any token
    that's an existing image/PDF file in cwd. Useful for drag-drop UX.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


# Image / PDF extensions we auto-attach.
_PASTE_EXTS = {
    ".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp",
    ".pdf",
}

# Match either a quoted path ('...' or "...") or a bare unquoted token.
_PATH_RE = re.compile(
    r"""(?P<quoted>'[^']+'|"[^"]+")|(?P<bare>\S+)"""
)


def _looks_like_paste_path(token: str) -> Path | None:
    """Return a resolved Path if the token points to an existing image/PDF."""
    raw = token.strip().strip("'\"")
    if not raw:
        return None
    p = Path(raw).expanduser()
    if not p.is_absolute():
        p = Path.cwd() / p
    if not p.exists() or not p.is_file():
        return None
    if p.suffix.lower() not in _PASTE_EXTS:
        return None
    return p


def detect_paste(text: str, file_store: Any) -> tuple[str, list[str]]:
    """Strip image/PDF paths from `text` and upload them via `file_store`.

    Returns (rewritten_text, [file_id, ...]). Order is preserved. Tokens
    that don't resolve to an existing image/PDF are left untouched.
    """
    attachments: list[str] = []
    parts: list[str] = []
    last = 0

    for match in _PATH_RE.finditer(text):
        token = match.group(0)
        path = _looks_like_paste_path(token)
        if path is None:
            continue
        try:
            record = file_store.upload(path, filename=path.name)
        except Exception as e:
            logger.debug(f"paste upload failed for {path}: {e}")
            continue
        attachments.append(record.id)
        parts.append(text[last:match.start()])
        parts.append(f"[attached: {path.name}]")
        last = match.end()

    if not attachments:
        return text, []
    parts.append(text[last:])
    return "".join(parts), attachments
