"""Citations — synthetic document citations for local models.

Mirrors Anthropic's citation blocks with a prompt-based protocol:

  1. Documents are injected into the system prompt as tagged blocks:
        <doc id="foo" title="User Manual">
            line 1
            line 2
            ...
        </doc>

  2. The model is instructed to cite sources inline using markers:
        [[cite:foo:L3]]          # single line
        [[cite:foo:L3-L7]]       # range
        [[cite:foo]]             # whole document

  3. Post-processing strips the markers from the user-visible text and
     returns structured `CitationBlock` objects alongside it.

Works against any model. Models that consistently emit the markers
produce cleaner citations; models that don't degrade to plain text —
the document is still in the prompt, the response just won't have
structured citation blocks.
"""

from __future__ import annotations

import logging
import re
from typing import Any

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


class Document(BaseModel):
    """A document the agent can cite from."""
    id: str
    title: str = ""
    text: str = ""
    metadata: dict[str, Any] = Field(default_factory=dict)


class CitationBlock(BaseModel):
    """A parsed citation pointing back to a document range."""
    doc_id: str
    doc_title: str = ""
    start_line: int | None = None
    end_line: int | None = None
    quoted_text: str = ""


CITATION_INSTRUCTION = (
    "You have access to the following reference documents. When you use "
    "information from them in your reply, cite them inline using this "
    "exact syntax:\n"
    "  [[cite:<doc_id>]]              # whole document\n"
    "  [[cite:<doc_id>:L<n>]]         # specific line\n"
    "  [[cite:<doc_id>:L<a>-L<b>]]    # range of lines (inclusive)\n"
    "Always place the marker directly after the fact it supports. If a "
    "claim is not in the documents, either say so explicitly or omit it."
)


_CITATION_RE = re.compile(
    r"\[\[cite:([a-zA-Z0-9_\-]+)(?::L(\d+)(?:-L(\d+))?)?\]\]"
)


def render_documents_block(documents: list[Document]) -> str:
    """Render a set of documents into a system-prompt fragment."""
    if not documents:
        return ""
    out: list[str] = ["# Reference documents"]
    for doc in documents:
        # Include line numbers so citations are meaningful
        numbered = "\n".join(
            f"L{i+1}: {line}"
            for i, line in enumerate(doc.text.splitlines())
        )
        title = doc.title or doc.id
        out.append(f'<doc id="{doc.id}" title="{title}">\n{numbered}\n</doc>')
    out.append(CITATION_INSTRUCTION)
    return "\n\n".join(out)


def parse_citations(
    text: str,
    documents: list[Document],
) -> tuple[str, list[CitationBlock]]:
    """Extract citation markers from `text`. Returns (clean_text, citations).

    The returned text has markers stripped (replaced by a small superscript
    index like "[1]") so the reply stays readable. Callers can render the
    full CitationBlock list alongside.
    """
    docs_by_id = {d.id: d for d in documents}
    citations: list[CitationBlock] = []
    seen: dict[tuple, int] = {}  # dedupe identical citations

    def _replace(match: re.Match) -> str:
        doc_id = match.group(1)
        start = int(match.group(2)) if match.group(2) else None
        end = int(match.group(3)) if match.group(3) else start

        key = (doc_id, start, end)
        if key in seen:
            return f"[{seen[key]}]"

        doc = docs_by_id.get(doc_id)
        quoted = ""
        if doc and start is not None:
            lines = doc.text.splitlines()
            lo = max(0, (start or 1) - 1)
            hi = min(len(lines), end or start)
            quoted = "\n".join(lines[lo:hi])

        citations.append(CitationBlock(
            doc_id=doc_id,
            doc_title=doc.title if doc else "",
            start_line=start,
            end_line=end,
            quoted_text=quoted,
        ))
        idx = len(citations)
        seen[key] = idx
        return f"[{idx}]"

    clean = _CITATION_RE.sub(_replace, text)
    return clean, citations
