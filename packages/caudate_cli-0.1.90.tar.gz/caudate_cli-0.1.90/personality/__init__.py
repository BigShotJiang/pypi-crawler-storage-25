"""Cognos personality layer.

Three components work together to give the agent a consistent character:

- Identity (stable): traits, values, base voice — the "who Cognos is" that
  doesn't change mid-conversation. Configurable, persistent.
- Mood (dynamic): confidence/curiosity/frustration that shift with outcomes.
  Confidence rises on tool successes, frustration builds on repeated
  failures, curiosity spikes on novel problems.
- InnerVoice (expression): blends identity + mood into the agent's
  thinking-block voice and system-prompt tone.

The PersonalityEngine aggregates all three and exposes the one thing the
agentic loop cares about: a `system_prompt_fragment()` string to splice
into the system prompt each turn, plus event handlers to wire into hooks.
"""

from personality.engine import PersonalityEngine
from personality.identity import Identity
from personality.inner_voice import InnerVoice
from personality.mood import MoodState

__all__ = ["PersonalityEngine", "Identity", "MoodState", "InnerVoice"]
