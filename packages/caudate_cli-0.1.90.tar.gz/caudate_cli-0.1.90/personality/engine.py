"""PersonalityEngine — aggregates identity, mood, and inner voice.

This is the single object the agent wires in. It:

  - Composes the personality's system-prompt fragment each turn (identity +
    current mood + voice-shaped thinking instructions).
  - Exposes event callbacks compatible with the Phase 2 HookManager events
    so mood updates happen automatically as tools succeed/fail.
  - Persists state: identity under `data/identity.json`, mood under
    `data/mood.json`.

Usage (handled by CognosAgent):

    engine = PersonalityEngine.load(config_dir)
    engine.register_with(hooks)          # auto-updates mood on events
    agentic_loop.system_prompt = engine.wrap_system_prompt(base_prompt)
    agentic_loop.on_thinking = engine.inner_voice.on_thinking
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from core.hooks import HookEvent, HookManager
from core.schemas import ThinkingBlock
from personality.identity import Identity
from personality.inner_voice import InnerVoice, InnerVoiceEntry
from personality.mood import MoodState

logger = logging.getLogger(__name__)


class PersonalityEngine:
    """Top-level personality layer — owns identity, mood, inner voice."""

    def __init__(
        self,
        identity: Identity,
        mood: MoodState,
        data_dir: Path,
        verbose_thinking: bool = False,
        on_thinking_display: Callable[[InnerVoiceEntry], None] | None = None,
    ):
        self.identity = identity
        self.mood = mood
        self.data_dir = data_dir
        self.inner_voice = InnerVoice(
            identity=identity,
            mood=mood,
            verbose=verbose_thinking,
            on_display=on_thinking_display,
        )

    # ------------------------------------------------------------------
    # Factories / persistence
    # ------------------------------------------------------------------

    @classmethod
    def load(
        cls,
        data_dir: Path,
        verbose_thinking: bool = False,
        on_thinking_display: Callable[[InnerVoiceEntry], None] | None = None,
    ) -> "PersonalityEngine":
        """Load identity + mood from disk (creating defaults if absent)."""
        identity = Identity.load(data_dir / "identity.json")
        mood = MoodState.load(data_dir / "mood.json")
        return cls(
            identity=identity,
            mood=mood,
            data_dir=data_dir,
            verbose_thinking=verbose_thinking,
            on_thinking_display=on_thinking_display,
        )

    def save(self) -> None:
        try:
            self.identity.save(self.data_dir / "identity.json")
            self.mood.save(self.data_dir / "mood.json")
        except Exception as e:
            logger.warning(f"Failed to save personality state: {e}")

    # ------------------------------------------------------------------
    # Prompt composition
    # ------------------------------------------------------------------

    def wrap_system_prompt(self, base: str) -> str:
        """Prepend identity + mood fragments to a base system prompt."""
        identity_fragment = self.identity.system_prompt_fragment()
        mood_fragment = self.mood.system_prompt_fragment()
        return (
            f"{identity_fragment}\n\n"
            f"{mood_fragment}\n\n"
            f"{base}"
        )

    def augment_thinking_instruction(self, base: str) -> str:
        return self.inner_voice.augment_thinking_instruction(base)

    # ------------------------------------------------------------------
    # Hook registration — wires mood to the agentic loop's events
    # ------------------------------------------------------------------

    def register_with(self, hooks: HookManager) -> None:
        """Attach mood-updating handlers to the agent's HookManager."""

        async def _on_success(event: str, payload: dict[str, Any]) -> None:
            tool = payload.get("tool") or payload.get("tool_name") or ""
            self.mood.on_tool_success(tool)

        async def _on_failure(event: str, payload: dict[str, Any]) -> None:
            tool = payload.get("tool") or payload.get("tool_name") or ""
            self.mood.on_tool_failure(tool)

        async def _on_user(event: str, payload: dict[str, Any]) -> None:
            self.mood.on_user_message(payload.get("message", ""))

        async def _on_stop(event: str, payload: dict[str, Any]) -> None:
            # Turn tick — decay transient state slightly toward baseline
            self.mood.on_turn_tick()
            self.save()

        hooks.register(HookEvent.POST_TOOL_USE, _on_success)
        hooks.register(HookEvent.POST_TOOL_USE_FAILURE, _on_failure)
        hooks.register(HookEvent.USER_PROMPT_SUBMIT, _on_user)
        hooks.register(HookEvent.STOP, _on_stop)
