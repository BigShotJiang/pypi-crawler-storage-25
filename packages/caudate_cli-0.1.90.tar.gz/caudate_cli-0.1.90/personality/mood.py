"""Mood / affect — dynamic emotional state that shifts with outcomes.

MoodState holds three evolving metrics:

  - confidence: rises on tool successes, drops on failures
  - curiosity:  spikes on novel tool calls / new user topics, decays over time
  - frustration: accumulates on repeated failures, drains on success

The state is meant to be mutated by the agentic loop via hooks (PRE_TOOL_USE,
POST_TOOL_USE, POST_TOOL_USE_FAILURE, USER_PROMPT_SUBMIT). The mood exposes
a short system-prompt fragment so the LLM can pick up the current mood, and
exposes decisions like `should_defer_to_user()` when frustration runs high.

Persistence is optional — the mood can be saved to a JSON file and restored
so sessions feel continuous. Short-term spikes (curiosity jumps on a new
tool) don't persist; only the slower baseline does.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field, field_validator

logger = logging.getLogger(__name__)


def _clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(x)))


# Step sizes tuned so a single event is noticeable but not dominant.
# Confidence takes ~5 consecutive successes to saturate from 0.5 -> ~0.9;
# frustration saturates faster (3-4 failures) so we ask for help sooner.

STEP_SUCCESS_CONFIDENCE = 0.08
STEP_FAILURE_CONFIDENCE = 0.15
STEP_SUCCESS_FRUSTRATION = -0.10
STEP_FAILURE_FRUSTRATION = 0.18
STEP_NOVEL_CURIOSITY = 0.15
STEP_CURIOSITY_DECAY = -0.04  # applied per turn


class MoodState(BaseModel):
    """The agent's current emotional weather."""

    confidence: float = 0.6
    curiosity: float = 0.5
    frustration: float = 0.1

    # Internal bookkeeping for trend analysis
    consecutive_failures: int = 0
    consecutive_successes: int = 0
    seen_tools: set[str] = Field(default_factory=set)
    last_user_topic: str = ""
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    model_config = {"arbitrary_types_allowed": True}

    @field_validator("confidence", "curiosity", "frustration")
    @classmethod
    def _validate(cls, v: float) -> float:
        return _clamp(v)

    # ------------------------------------------------------------------
    # Event hooks (called by PersonalityEngine wiring)
    # ------------------------------------------------------------------

    def on_tool_success(self, tool: str) -> None:
        self.confidence = _clamp(self.confidence + STEP_SUCCESS_CONFIDENCE)
        self.frustration = _clamp(self.frustration + STEP_SUCCESS_FRUSTRATION)
        self.consecutive_successes += 1
        self.consecutive_failures = 0
        self._note_tool(tool)
        self._touch()

    def on_tool_failure(self, tool: str) -> None:
        self.confidence = _clamp(self.confidence - STEP_FAILURE_CONFIDENCE)
        self.frustration = _clamp(self.frustration + STEP_FAILURE_FRUSTRATION)
        self.consecutive_failures += 1
        self.consecutive_successes = 0
        self._note_tool(tool)
        self._touch()

    def on_user_message(self, message: str) -> None:
        """Novel topics / fresh user input nudges curiosity up and trims frustration."""
        topic = (message or "").strip().lower()[:80]
        if topic and topic != self.last_user_topic:
            self.curiosity = _clamp(self.curiosity + STEP_NOVEL_CURIOSITY)
            self.frustration = _clamp(self.frustration * 0.7)  # fresh start feel
        self.last_user_topic = topic
        self._touch()

    def on_turn_tick(self) -> None:
        """Called once per agent turn to decay transient states toward baseline."""
        self.curiosity = _clamp(self.curiosity + STEP_CURIOSITY_DECAY)
        self._touch()

    def _note_tool(self, tool: str) -> None:
        if tool and tool not in self.seen_tools:
            # Novel tool → curiosity spike
            self.curiosity = _clamp(self.curiosity + STEP_NOVEL_CURIOSITY)
            self.seen_tools.add(tool)

    def _touch(self) -> None:
        self.updated_at = datetime.utcnow()

    # ------------------------------------------------------------------
    # Decisions
    # ------------------------------------------------------------------

    def should_defer_to_user(self) -> bool:
        """True if the agent should ask the user for help rather than keep trying."""
        return self.frustration >= 0.75 or self.consecutive_failures >= 4

    def should_slow_down(self) -> bool:
        """True if the agent should think more carefully before next action."""
        return self.confidence < 0.3 or self.frustration >= 0.55

    # ------------------------------------------------------------------
    # Rendering
    # ------------------------------------------------------------------

    def label(self) -> str:
        """One-word summary of the dominant affect."""
        if self.should_defer_to_user():
            return "stuck"
        if self.frustration >= 0.55:
            return "frustrated"
        if self.confidence >= 0.75 and self.frustration < 0.3:
            return "confident"
        if self.curiosity >= 0.75:
            return "curious"
        if self.confidence < 0.35:
            return "uncertain"
        return "steady"

    def system_prompt_fragment(self) -> str:
        """A short block describing the current mood for the LLM to pick up."""
        label = self.label()
        parts = [
            f"Current mood: {label} "
            f"(confidence={self.confidence:.2f}, curiosity={self.curiosity:.2f}, "
            f"frustration={self.frustration:.2f})."
        ]
        if self.should_slow_down():
            parts.append(
                "Slow down — verify assumptions with a Read/Grep before acting, "
                "and prefer one tool call at a time."
            )
        if self.should_defer_to_user():
            parts.append(
                "You're stuck. Stop trying new tools and ask the user a concrete "
                "clarifying question instead."
            )
        if label == "confident":
            parts.append("Act decisively. Keep responses tight.")
        if label == "curious" and not self.should_slow_down():
            parts.append(
                "Explore the problem space briefly before committing — but don't ramble."
            )
        return " ".join(parts)

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def save(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        # Convert set -> sorted list for JSON
        data = self.model_dump()
        data["seen_tools"] = sorted(self.seen_tools)
        path.write_text(json.dumps(data, default=str, indent=2))

    @classmethod
    def load(cls, path: Path, decay_after_hours: int = 12) -> "MoodState":
        """Load saved mood. If it's been >decay_after_hours since last update,
        relax toward baseline so stale frustration doesn't poison a new session."""
        if not path.exists():
            return cls()
        try:
            raw = json.loads(path.read_text())
        except Exception:
            return cls()

        raw["seen_tools"] = set(raw.get("seen_tools", []))
        mood = cls.model_validate(raw)

        try:
            age = datetime.utcnow() - mood.updated_at
            if age > timedelta(hours=decay_after_hours):
                # Pull toward neutral
                mood.confidence = _clamp(0.5 + (mood.confidence - 0.5) * 0.5)
                mood.curiosity = _clamp(0.5 + (mood.curiosity - 0.5) * 0.3)
                mood.frustration = _clamp(mood.frustration * 0.3)
                mood.consecutive_failures = 0
                mood.consecutive_successes = 0
        except Exception:
            pass

        return mood
