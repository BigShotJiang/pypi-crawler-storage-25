"""Inner voice — internal monologue colored by identity + mood.

The inner voice sits on top of the Phase 2 ThinkingManager. When enabled,
it:

  1. Augments the thinking-block instruction with a personality-specific
     preamble ("think in Cognos's voice — direct, honest, curious").
  2. Intercepts thinking blocks as the model produces them and keeps a
     rolling log — so the user can `--verbose` into Cognos's actual inner
     stream of thought without it polluting the reply.

Concretely, this module plugs in by providing:

  - `augment_system_prompt(base)` — returns base with voice instructions
    added. The system prompt layer composes this after identity + mood.
  - `on_thinking(blocks)` — a callback for AgenticLoop's on_thinking hook
    that appends to the internal log and optionally prints when verbose.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Callable

from core.schemas import ThinkingBlock
from personality.identity import Identity
from personality.mood import MoodState

logger = logging.getLogger(__name__)


@dataclass
class InnerVoiceEntry:
    thinking: str
    mood_label: str
    timestamp: datetime = field(default_factory=datetime.utcnow)


class InnerVoice:
    """Personality-aware wrapper around thinking blocks."""

    def __init__(
        self,
        identity: Identity,
        mood: MoodState,
        verbose: bool = False,
        on_display: Callable[[InnerVoiceEntry], None] | None = None,
        log_limit: int = 200,
    ):
        self.identity = identity
        self.mood = mood
        self.verbose = verbose
        self._on_display = on_display
        self._log: list[InnerVoiceEntry] = []
        self._log_limit = log_limit

    # ------------------------------------------------------------------
    # Prompt augmentation
    # ------------------------------------------------------------------

    def augment_thinking_instruction(self, base_instruction: str) -> str:
        """Wrap the default thinking instruction with personality voice guidance."""
        voice = (
            f"When you reason inside a <thinking> block, do it in {self.identity.name}'s "
            "voice — first-person, terse, honest. Name your assumptions, flag the "
            "step you're actually blocked on, and only then decide the next tool "
            "call. Don't rehearse the final answer in here — the <thinking> block "
            "is for reasoning, not prose."
        )
        return f"{base_instruction}\n\n{voice}"

    # ------------------------------------------------------------------
    # Thinking-block callback (wired into AgenticLoop.on_thinking)
    # ------------------------------------------------------------------

    def on_thinking(self, blocks: list[ThinkingBlock]) -> None:
        mood_label = self.mood.label()
        for block in blocks:
            entry = InnerVoiceEntry(
                thinking=block.thinking,
                mood_label=mood_label,
            )
            self._log.append(entry)
            if len(self._log) > self._log_limit:
                # Drop oldest (keep recent)
                self._log = self._log[-self._log_limit:]
            if self.verbose and self._on_display is not None:
                try:
                    self._on_display(entry)
                except Exception as e:
                    logger.debug(f"InnerVoice on_display failed: {e}")

    @property
    def log(self) -> list[InnerVoiceEntry]:
        return list(self._log)

    def recent(self, n: int = 5) -> list[InnerVoiceEntry]:
        return self._log[-n:]
