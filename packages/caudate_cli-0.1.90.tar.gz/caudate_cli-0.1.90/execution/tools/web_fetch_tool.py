"""WebFetch tool — fetch a URL and return cleaned text."""

from __future__ import annotations

import asyncio
import html
import re
from typing import Any

from core.schemas import ToolResult
from execution.tools.base import BaseTool


class WebFetchTool(BaseTool):
    name = "WebFetch"
    description = (
        "Fetch a web page and return its text content with HTML stripped. "
        "Use for reading documentation, articles, or any web resource."
    )

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "The URL to fetch (must start with http:// or https://)",
                },
                "max_chars": {
                    "type": "integer",
                    "description": "Max characters to return (default 20000)",
                    "default": 20000,
                },
            },
            "required": ["url"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        url = kwargs.get("url", "")
        if not url:
            return self._error("No url provided")
        if not url.startswith(("http://", "https://")):
            return self._error(f"Invalid URL scheme: {url}")

        max_chars = int(kwargs.get("max_chars", 20000))

        cmd = f'curl -sSL --max-time 30 -A "cognos-agent/1.0" "{url}"'
        try:
            proc = await asyncio.create_subprocess_shell(
                cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=35)
        except asyncio.TimeoutError:
            return self._error("Fetch timed out")
        except Exception as e:
            return self._error(str(e))

        if proc.returncode != 0:
            return self._error(f"curl failed: {stderr.decode(errors='ignore')[:200]}")

        raw = stdout.decode(errors="ignore")
        text = _strip_html(raw)
        if len(text) > max_chars:
            text = text[:max_chars] + f"\n\n... (truncated at {max_chars} chars)"
        return self._success(text)


_SCRIPT_STYLE_RE = re.compile(r"<(script|style)[^>]*>.*?</\1>", re.DOTALL | re.IGNORECASE)
_TAG_RE = re.compile(r"<[^>]+>")
_WS_RE = re.compile(r"\n\s*\n+")


def _strip_html(raw: str) -> str:
    """Very basic HTML → text conversion (no external deps)."""
    raw = _SCRIPT_STYLE_RE.sub("", raw)
    raw = _TAG_RE.sub("", raw)
    raw = html.unescape(raw)
    raw = _WS_RE.sub("\n\n", raw)
    return raw.strip()
