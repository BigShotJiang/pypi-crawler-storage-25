"""Plan Mode tools — toggle the read-only execution mode.

Two tools:

  - **`EnterPlanMode`** — switch ON. Mutating tools (Bash, Write,
    Edit, NotebookEdit, PythonExec, HttpRequest, Sandbox, etc.)
    will refuse to run; read-only tools (Read, Grep, Glob,
    SystemInfo, Calculator, …) keep working. Use when the user
    wants the agent to *plan* a change and present it before
    actually applying anything.
  - **`ExitPlanMode`** — switch OFF. Mutating tools are allowed
    again. The agent should call this once the user has reviewed
    and approved the plan.

These are status-flip tools, not blocking prompts — the agent can
toggle plan mode mid-conversation and the executor's dispatch
refuses mutators until the next ExitPlanMode.
"""

from __future__ import annotations

from typing import Any

from core.plan_mode import enter, exit_mode, is_active
from core.schemas import ToolResult
from execution.tools.base import BaseTool


class EnterPlanModeTool(BaseTool):
    name = "EnterPlanMode"
    description = (
        "Enter plan mode — the executor will refuse any side-effect "
        "tool (Bash, Write, Edit, NotebookEdit, PythonExec, "
        "HttpRequest, Sandbox, UpdateMemory, Cron*, Task*, Worktree*, "
        "Draw, EditImage, Storyboard, Speak, Artifact) until "
        "ExitPlanMode is called. Read-only tools (Read, Grep, Glob, "
        "FindAnywhere, SystemInfo, Calculator, DateTime, "
        "SemanticSearch, DescribeImage, TranscribeAudio, WebSearch, "
        "WebFetch, CognosCard, Think, AskUserQuestion, "
        "MCPListServers, TaskList/Get/Output, CronList) keep "
        "working. Use this when the user wants you to plan first "
        "and apply changes only after review."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {"type": "object", "properties": {}}

    async def execute(self, **_: Any) -> ToolResult:
        if is_active():
            return ToolResult(
                tool_name=self.name, status="success",
                output="Plan mode is already ON.",
                metadata={"plan_mode": True, "changed": False},
            )
        enter()
        return ToolResult(
            tool_name=self.name, status="success",
            output=(
                "Plan mode is now ON. Mutating tools are blocked; "
                "read-only tools still work. Use ExitPlanMode to "
                "return to normal operation."
            ),
            metadata={"plan_mode": True, "changed": True},
        )


class ExitPlanModeTool(BaseTool):
    name = "ExitPlanMode"
    description = (
        "Present a finalized plan to the user and ask whether to "
        "execute it. Required argument `plan`: a markdown-formatted "
        "description of what you will do (sections: Overview, Files "
        "to create/modify, Steps, Verification). The user sees the "
        "plan in a bordered panel and picks Yes (proceed) or No "
        "(stay in plan mode for refinement). On Yes, plan mode turns "
        "off and you can run mutating tools. On No, plan mode stays "
        "on and the user's feedback is returned as the tool result."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "plan": {
                    "type": "string",
                    "description": (
                        "Markdown plan to present to the user. Use "
                        "headings like ## Overview, ## Files, ## Steps."
                    ),
                },
            },
            "required": ["plan"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        plan = str(kwargs.get("plan", "")).strip()
        if not plan:
            return ToolResult(
                tool_name=self.name, status="error",
                error=(
                    "ExitPlanMode requires a `plan` argument — a "
                    "markdown description of what you plan to do."
                ),
            )

        approved, feedback = await _present_plan_and_prompt(plan)
        if approved:
            if is_active():
                exit_mode()
            return ToolResult(
                tool_name=self.name, status="success",
                output=(
                    "User approved the plan. Plan mode is now OFF — "
                    "proceed with the steps you described."
                ),
                metadata={"plan_mode": False, "changed": True, "approved": True},
            )
        # Rejected: stay in plan mode, hand the user's feedback back
        # so the model can refine and re-present.
        msg = "User rejected the plan."
        if feedback:
            msg += f" Their feedback: {feedback}"
        msg += " Refine the plan based on this and call ExitPlanMode again."
        return ToolResult(
            tool_name=self.name, status="success",
            output=msg,
            metadata={"plan_mode": True, "changed": False, "approved": False},
        )


async def _present_plan_and_prompt(plan_md: str) -> tuple[bool, str]:
    """Render the plan in a bordered panel and prompt for approval.

    Returns (approved, feedback_text).
    """
    import sys
    from rich.console import Console
    from rich.markdown import Markdown
    from rich.panel import Panel
    console = Console()

    # Pause any active StreamDisplay tickers so they don't paint over
    # the plan panel.
    display = None
    try:
        from ui.display import get_active_display
        display = get_active_display()
    except Exception:
        display = None
    if display is not None:
        try:
            console.file.write("\n")
            console.file.flush()
        except Exception:
            pass
        display.pause()

    try:
        console.print()
        console.print(Panel(
            Markdown(plan_md),
            title="[bold cyan]Proposed plan[/bold cyan]",
            border_style="cyan",
            padding=(1, 2),
        ))

        if sys.stdin.isatty():
            try:
                idx = await _ptk_plan_select()
            except Exception:
                idx = -2
            if idx == 0:
                return True, ""
            if idx == 1 or idx == -1:
                # No → fall through to a brief feedback prompt below.
                pass
            elif idx == -2:
                # ptk failed; fall through to text prompt.
                pass

        # Text-prompt fallback (and the "tell me why" prompt after a No).
        from rich.prompt import Prompt
        ans = Prompt.ask(
            "\n  [bold]Proceed with this plan?[/bold]",
            choices=["y", "n"], default="y",
        )
        if ans.lower().startswith("y"):
            return True, ""
        feedback = Prompt.ask(
            "  [dim]Optional: feedback for the model (Enter to skip)[/dim]",
            default="",
        ).strip()
        return False, feedback
    finally:
        if display is not None:
            display.resume()


async def _ptk_plan_select() -> int:
    """prompt_toolkit selector — Yes / No (with feedback)."""
    import os
    os.environ.setdefault("PROMPT_TOOLKIT_NO_CPR", "1")

    from prompt_toolkit.application import Application
    from prompt_toolkit.key_binding import KeyBindings
    from prompt_toolkit.layout import HSplit, Layout, Window
    from prompt_toolkit.layout.controls import FormattedTextControl
    from prompt_toolkit.layout.dimension import Dimension as D
    from prompt_toolkit.styles import Style
    from prompt_toolkit.widgets import Frame

    options = [
        ("Yes, proceed with this plan", "green"),
        ("No, refine the plan",         "white"),
    ]
    state = {"cursor": 0, "result": None}

    def menu_text():
        out = []
        for i, (label, _color) in enumerate(options):
            if i == state["cursor"]:
                out.append(("class:selected", f"  ❯ {i+1}. {label}\n"))
            else:
                out.append(("class:option", f"    {i+1}. {label}\n"))
        return out

    kb = KeyBindings()

    @kb.add("up")
    @kb.add("k")
    def _(event):
        state["cursor"] = (state["cursor"] - 1) % len(options)
        event.app.invalidate()

    @kb.add("down")
    @kb.add("j")
    def _(event):
        state["cursor"] = (state["cursor"] + 1) % len(options)
        event.app.invalidate()

    @kb.add("enter")
    def _(event):
        state["result"] = state["cursor"]
        event.app.exit()

    @kb.add("escape")
    @kb.add("c-c")
    def _(event):
        state["result"] = -1
        event.app.exit()

    for n, idx in (("1", 0), ("2", 1)):
        def make_handler(i):
            def _(event):
                state["result"] = i
                event.app.exit()
            return _
        kb.add(n)(make_handler(idx))

    style = Style.from_dict({
        "frame.border": "fg:#5fafff",
        "selected":     "bold",
        "option":       "",
    })

    layout = Layout(Frame(
        body=Window(FormattedTextControl(menu_text), height=D(min=2, max=2)),
        title="Approve plan?",
    ))

    app: Application[None] = Application(
        layout=layout,
        key_bindings=kb,
        style=style,
        full_screen=False,
        mouse_support=False,
    )
    await app.run_async()
    return state["result"] if state["result"] is not None else -1
