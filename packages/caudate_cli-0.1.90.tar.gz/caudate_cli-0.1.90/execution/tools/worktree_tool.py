"""Worktree tools — git worktree isolation for agent work.

`git worktree` creates a separate working copy backed by the same
`.git/` repo. Useful when you want the agent to try a risky change
without touching the live working tree, or to work on multiple
branches in parallel.

Two tools (matching Claude Code's surface):

  - **`EnterWorktree`** — create a fresh worktree off HEAD (or a given
    base branch) and remember it as the "active" worktree. Returns
    its path + branch name. Subsequent file operations should be
    targeted at that path explicitly (these tools are advisory; they
    don't reroute Edit/Write to the worktree automatically).
  - **`ExitWorktree`** — clean up the active worktree. By default
    keeps it if there are uncommitted changes (so work isn't lost);
    pass `force=true` to delete regardless.

Process-local: the active worktree handle lives in this module. Not
persisted; restart wipes it.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from core.schemas import ToolResult
from core.worktree import Worktree, create_worktree
from execution.tools.base import BaseTool

logger = logging.getLogger(__name__)


# Process-wide active worktree. Multiple tools share this so the
# `ExitWorktree` call doesn't need an id.
_ACTIVE: Worktree | None = None


class EnterWorktreeTool(BaseTool):
    mutates = True
    name = "EnterWorktree"
    description = (
        "Create a temporary git worktree (separate working copy backed "
        "by the same `.git/` repo) so changes can be tried in "
        "isolation. Optional `base_branch` (default HEAD). Returns the "
        "worktree path and a fresh branch name. Use `ExitWorktree` "
        "afterwards to clean up. Note: file-modifying tools (Edit, "
        "Write, Bash) don't auto-route to the worktree — pass the "
        "returned path explicitly when running them."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "base_branch": {
                    "type": "string",
                    "description": "Branch or commit to base the worktree on. Default 'HEAD'.",
                    "default": "HEAD",
                },
                "parent_repo": {
                    "type": "string",
                    "description": "Path to the parent repo. Default = current working dir.",
                },
            },
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        global _ACTIVE
        if _ACTIVE is not None:
            return ToolResult(
                tool_name=self.name, status="error",
                error=(
                    f"a worktree is already active at {_ACTIVE.path}. "
                    "Call ExitWorktree first."
                ),
            )
        base = (kwargs.get("base_branch") or "HEAD").strip()
        parent_str = (kwargs.get("parent_repo") or "").strip()
        parent = Path(parent_str).expanduser().resolve() if parent_str else None
        wt = await create_worktree(parent_repo=parent, base_branch=base)
        if wt is None:
            return ToolResult(
                tool_name=self.name, status="error",
                error=(
                    "git worktree creation failed. Check that the cwd "
                    "is a git repo, git is installed, and the working "
                    "tree isn't blocked by uncommitted submodule state."
                ),
            )
        _ACTIVE = wt
        return ToolResult(
            tool_name=self.name, status="success",
            output=(
                f"Worktree created.\n"
                f"  path:    {wt.path}\n"
                f"  branch:  {wt.branch}\n"
                f"  parent:  {wt.parent_repo}\n"
                "Use this path explicitly when running file-modifying "
                "tools. Call ExitWorktree to clean up."
            ),
            metadata={
                "path":   str(wt.path),
                "branch": wt.branch,
                "parent": str(wt.parent_repo),
            },
        )


class ExitWorktreeTool(BaseTool):
    mutates = True
    name = "ExitWorktree"
    description = (
        "Clean up the active worktree created by EnterWorktree. By "
        "default it's KEPT if there are uncommitted changes (work "
        "isn't silently lost). Pass `force: true` to delete anyway. "
        "Returns whether it was removed or kept, plus the path so you "
        "can inspect it manually."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "force": {
                    "type": "boolean",
                    "description": (
                        "If true, delete even if there are uncommitted "
                        "changes (DESTRUCTIVE). Default false."
                    ),
                    "default": False,
                },
            },
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        global _ACTIVE
        if _ACTIVE is None:
            return ToolResult(
                tool_name=self.name, status="error",
                error="no active worktree (call EnterWorktree first)",
            )
        force = bool(kwargs.get("force", False))
        path = _ACTIVE.path
        had_changes = await _ACTIVE.has_changes()
        kept = had_changes and not force
        try:
            await _ACTIVE.cleanup(force=force)
        except Exception as e:
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"cleanup failed: {e}",
            )
        _ACTIVE = None
        if kept:
            return ToolResult(
                tool_name=self.name, status="success",
                output=(
                    f"Worktree kept (uncommitted changes present).\n"
                    f"  path: {path}\n"
                    "Pass force=true to delete anyway, or commit/push "
                    "the changes before exiting."
                ),
                metadata={"path": str(path), "kept": True},
            )
        return ToolResult(
            tool_name=self.name, status="success",
            output=f"Worktree removed: {path}",
            metadata={"path": str(path), "kept": False},
        )
