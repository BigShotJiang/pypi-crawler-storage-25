"""Draw tool — generate an image from a text prompt.

The agent calls `Draw(prompt=..., size=...)`, the tool runs the
configured image-gen backend, persists the result via FileStore, and
returns a markdown image link the agent can paste directly into the
chat reply so the user's UI (Open WebUI / Claude Code) renders the
image inline.

Backends:
  - "diffusers" (default, local)
  - "comfyui" (HTTP proxy)
  - "litellm" (cloud)

Backend choice + model id come from settings (`image.backend`,
`image.model`) so a project can override the default without touching
code. Backend instances are cached per-tool so the diffusers pipeline
loads once and stays in VRAM.
"""

from __future__ import annotations

import logging
import os
from typing import Any

from core.image import ImageGen, generate_to_file_store, make_image_gen
from core.schemas import ToolResult
from execution.tools.base import BaseTool

logger = logging.getLogger(__name__)


def _public_base_url() -> str:
    """Where files served at /files/{id}/content are reachable from.

    Defaults to http://127.0.0.1:8000 (same-host browser). Override via
    COGNOS_PUBLIC_URL when Cognos is being accessed remotely (mobile,
    LAN), so generated images render in the remote browser too.
    """
    return os.environ.get("COGNOS_PUBLIC_URL", "http://127.0.0.1:8000").rstrip("/")


class DrawTool(BaseTool):
    mutates = True
    name = "Draw"
    description = (
        "Generate an image from a text description. Use when the user "
        "asks for a drawing, illustration, diagram, picture, or visual "
        "concept. The tool returns a `markdown` field — copy that "
        "string VERBATIM into your reply (looks like "
        "`![alt](http://.../files/<id>/content)`) so the user's chat "
        "UI renders the image inline. Be specific in the prompt: "
        "subject, composition, style (e.g. 'watercolor', 'pixel art', "
        "'photorealistic'), lighting, mood. Don't include text-in-"
        "image instructions; image models render text poorly."
    )

    def __init__(
        self,
        file_store: Any | None = None,
        backend: str = "diffusers",
        backend_kwargs: dict | None = None,
    ):
        self._file_store = file_store
        self._backend_name = backend
        self._backend_kwargs = backend_kwargs or {}
        self._backend: ImageGen | None = None

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "prompt": {
                    "type": "string",
                    "description": "Text description of the image to generate.",
                },
                "size": {
                    "type": "string",
                    "description": "Pixel dimensions. Common: 1024x1024 (square), 1024x768 (4:3), 768x1024 (3:4), 1280x720 (16:9). Default 1024x1024.",
                    "default": "1024x1024",
                },
                "negative_prompt": {
                    "type": "string",
                    "description": "Things to avoid (e.g. 'blurry, deformed, text'). Optional.",
                },
                "seed": {
                    "type": "integer",
                    "description": "Random seed for reproducibility. Omit for random.",
                },
                "steps": {
                    "type": "integer",
                    "description": "Inference steps. Defaults vary by model; only set if you know the model.",
                },
                "style": {
                    "type": "string",
                    "description": "Optional style hint, prepended to the prompt (e.g. 'watercolor', 'photorealistic', 'oil painting').",
                },
            },
            "required": ["prompt"],
        }

    def set_file_store(self, file_store: Any) -> None:
        self._file_store = file_store

    def _get_backend(self) -> ImageGen:
        if self._backend is None:
            self._backend = make_image_gen(self._backend_name, **self._backend_kwargs)
        return self._backend

    async def execute(self, **kwargs: Any) -> ToolResult:
        prompt = (kwargs.get("prompt") or "").strip()
        if not prompt:
            return self._error("No prompt provided")
        if self._file_store is None:
            return self._error("Draw is not wired to a FileStore. Configure one on the tool.")

        size = kwargs.get("size") or "1024x1024"
        style = (kwargs.get("style") or "").strip()
        if style:
            prompt = f"{style}, {prompt}"

        gen_kwargs: dict[str, Any] = {}
        if "negative_prompt" in kwargs and kwargs["negative_prompt"]:
            gen_kwargs["negative_prompt"] = kwargs["negative_prompt"]
        if kwargs.get("seed") is not None:
            gen_kwargs["seed"] = int(kwargs["seed"])
        if kwargs.get("steps") is not None:
            gen_kwargs["steps"] = int(kwargs["steps"])

        try:
            backend = self._get_backend()
            record = await generate_to_file_store(
                backend, self._file_store, prompt, size=size, **gen_kwargs,
            )
        except Exception as e:
            logger.exception("Draw failed")
            return self._error(f"Image generation failed: {e}")

        # Build URLs:
        #  - raw bytes URL drives the inline `![alt](url)` markdown so
        #    chat UIs render the image directly in the conversation
        #  - viewer URL (Phase 1 of COGNOS_UI_ROADMAP.md) gives a
        #    polished standalone page with download + larger view
        url = f"{_public_base_url()}/files/{record.id}/content"
        viewer_url = f"{_public_base_url()}/artifact/{record.id}"
        alt = (prompt or record.filename)[:120].replace("]", "")
        # Inline image first (so it shows in chat), then a small
        # "open in viewer" link for download / full-size.
        markdown = f"![{alt}]({url})\n\n[📄 Open in viewer]({viewer_url})"

        return self._success({
            "file_id": record.id,
            "filename": record.filename,
            "path": record.path,
            "url": url,
            "markdown": markdown,
            "size_bytes": record.size_bytes,
            "kind": record.kind,
            "note": (
                "Image generated. Paste the `markdown` field above into "
                "your reply VERBATIM — the chat UI will render it inline."
            ),
        })
