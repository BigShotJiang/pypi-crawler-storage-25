"""FindAnywhere — unified filesystem search.

Combines glob (filename matching), grep (content matching), and
metadata filtering (size / mtime) into one tool. Replaces the common
"chain three tools to find that file" pattern.

Returns a ranked list of matches: each match has the file path plus
optional snippet showing the content match (when `content` was given).
"""

from __future__ import annotations

import os
import re
import time
from pathlib import Path
from typing import Any

from core.schemas import ToolResult
from execution.tools.base import BaseTool


_DEFAULT_IGNORE_DIRS: frozenset[str] = frozenset({
    ".git", ".hg", ".svn", "__pycache__", "node_modules", ".venv",
    "venv", ".tox", ".mypy_cache", ".pytest_cache", "dist", "build",
    ".cache", ".idea", ".vscode",
})

_MAX_FILE_BYTES = 5 * 1024 * 1024   # skip files >5MB for content match
_MAX_RESULTS_DEFAULT = 50
_DEFAULT_ROOT = "/home/raveuk/cognos"


def _parse_age(value: str | None) -> float | None:
    """Parse a human age string like '7d', '24h', '30m' → seconds."""
    if not value:
        return None
    s = value.strip().lower()
    if not s:
        return None
    try:
        if s.endswith("d"):
            return float(s[:-1]) * 86400
        if s.endswith("h"):
            return float(s[:-1]) * 3600
        if s.endswith("m"):
            return float(s[:-1]) * 60
        if s.endswith("s"):
            return float(s[:-1])
        return float(s)   # bare seconds
    except ValueError:
        return None


def _parse_size(value: str | int | None) -> int | None:
    """Parse a size like '1MB', '50KB', '1024' → bytes."""
    if value is None:
        return None
    if isinstance(value, int):
        return value
    s = str(value).strip().upper()
    try:
        if s.endswith("KB") or s.endswith("K"):
            return int(float(s.rstrip("KB").rstrip("K")) * 1024)
        if s.endswith("MB") or s.endswith("M"):
            return int(float(s.rstrip("MB").rstrip("M")) * 1024 * 1024)
        if s.endswith("GB") or s.endswith("G"):
            return int(float(s.rstrip("GB").rstrip("G")) * 1024 * 1024 * 1024)
        if s.endswith("B"):
            return int(s.rstrip("B"))
        return int(s)
    except ValueError:
        return None


class FindAnywhereTool(BaseTool):
    name = "FindAnywhere"
    description = (
        "Unified filesystem search: combine filename pattern (glob), "
        "content match (regex), and metadata filters (size, age) in one "
        "call. Returns ranked matches with optional content snippets. "
        "Use this when you'd otherwise chain Glob + Grep + ls."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": (
                        "Filename pattern (glob, e.g. '*.py', '**/main.*'). "
                        "Optional — omit to search all files."
                    ),
                },
                "content": {
                    "type": "string",
                    "description": (
                        "Regex to match inside file contents. Optional. "
                        "Files are matched if their content matches."
                    ),
                },
                "path": {
                    "type": "string",
                    "description": (
                        f"Root directory to search. Defaults to {_DEFAULT_ROOT}."
                    ),
                },
                "ignore_case": {
                    "type": "boolean",
                    "description": "Case-insensitive content matching. Default true.",
                    "default": True,
                },
                "max_size": {
                    "type": "string",
                    "description": "Skip files larger than this (e.g. '1MB', '500KB').",
                },
                "modified_within": {
                    "type": "string",
                    "description": "Only include files modified within this age (e.g. '7d', '24h').",
                },
                "max_results": {
                    "type": "integer",
                    "description": f"Cap on results (default {_MAX_RESULTS_DEFAULT}).",
                    "default": _MAX_RESULTS_DEFAULT,
                },
            },
            "required": [],
        }

    async def execute(
        self,
        name: str = "",
        content: str = "",
        path: str = _DEFAULT_ROOT,
        ignore_case: bool = True,
        max_size: str | None = None,
        modified_within: str | None = None,
        max_results: int = _MAX_RESULTS_DEFAULT,
        **_: Any,
    ) -> ToolResult:
        try:
            return self._run(
                name_pattern=name or None,
                content_pattern=content or None,
                root=path or _DEFAULT_ROOT,
                ignore_case=bool(ignore_case),
                max_size_bytes=_parse_size(max_size),
                modified_within_seconds=_parse_age(modified_within),
                max_results=max(1, int(max_results)),
            )
        except Exception as e:
            return ToolResult(tool_name=self.name, status="error", error=str(e))

    def _run(
        self, *,
        name_pattern: str | None,
        content_pattern: str | None,
        root: str,
        ignore_case: bool,
        max_size_bytes: int | None,
        modified_within_seconds: float | None,
        max_results: int,
    ) -> ToolResult:
        root_path = Path(root).expanduser().resolve()
        if not root_path.exists():
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"path does not exist: {root_path}",
            )

        flags = re.IGNORECASE if ignore_case else 0
        content_re = re.compile(content_pattern, flags) if content_pattern else None
        cutoff_mtime = (time.time() - modified_within_seconds
                        if modified_within_seconds else None)

        results: list[dict[str, Any]] = []
        for candidate in self._walk(root_path):
            if len(results) >= max_results:
                break

            # Filename pattern
            if name_pattern:
                if not candidate.match(name_pattern):
                    continue

            # Metadata
            try:
                stat = candidate.stat()
            except OSError:
                continue
            if max_size_bytes is not None and stat.st_size > max_size_bytes:
                continue
            if cutoff_mtime is not None and stat.st_mtime < cutoff_mtime:
                continue

            entry: dict[str, Any] = {
                "path": str(candidate),
                "size_bytes": stat.st_size,
                "modified_iso": time.strftime(
                    "%Y-%m-%dT%H:%M:%SZ", time.gmtime(stat.st_mtime)
                ),
            }

            # Content match
            if content_re is not None:
                if stat.st_size > _MAX_FILE_BYTES:
                    continue
                snippet = self._first_match(candidate, content_re)
                if snippet is None:
                    continue
                entry["snippet"] = snippet
            results.append(entry)

        # Format human-readable output
        if not results:
            return ToolResult(
                tool_name=self.name, status="success",
                output=f"No matches under {root_path}",
            )

        lines = [f"Found {len(results)} match(es) under {root_path}:"]
        for r in results:
            line = f"  {r['path']}  ({r['size_bytes']}B  {r['modified_iso']})"
            if "snippet" in r:
                line += f"\n    > {r['snippet']}"
            lines.append(line)
        return ToolResult(
            tool_name=self.name, status="success",
            output="\n".join(lines),
            metadata={"matches": results},
        )

    @staticmethod
    def _walk(root: Path):
        for dirpath, dirnames, filenames in os.walk(root):
            # Prune ignored dirs in place
            dirnames[:] = [d for d in dirnames if d not in _DEFAULT_IGNORE_DIRS]
            for fn in filenames:
                yield Path(dirpath) / fn

    @staticmethod
    def _first_match(file: Path, regex: re.Pattern) -> str | None:
        try:
            with file.open("r", errors="replace") as f:
                for i, line in enumerate(f, start=1):
                    if regex.search(line):
                        snippet = line.rstrip()
                        if len(snippet) > 200:
                            snippet = snippet[:200] + "…"
                        return f"L{i}: {snippet}"
        except (OSError, UnicodeDecodeError):
            return None
        return None
