"""Sandbox — unified lifecycle + snapshot tool for the local sandbox.

Inspired by Vercel Sandbox's API (`Sandbox.create`, `runCommand`,
`snapshot`, `stop`, source-from-snapshot). Applied to our LOCAL 50GB
ext4 loopback at `/home/raveuk/cognos/sandbox/` — no cloud dependency,
no billing, no Vercel account.

Modes the LLM can use:

  status            — mount state, free space, snapshot count
  run               — execute a shell command with cwd locked to sandbox/
  snapshot [label]  — tar+zstd the current sandbox state into a snapshot
  list_snapshots    — show all snapshots with size + age + label
  restore <id>      — wipe sandbox + extract a snapshot (auto-checkpoints
                      the pre-restore state first, so restores are
                      reversible)
  delete_snapshot <id> — remove a snapshot artifact

Snapshots live at `~/.cognos/sandbox-snapshots/<id>.tar.zst` with a
sidecar `.meta.json`. Each `restore` auto-creates an
`auto-pre-restore-<src>` snapshot first, so a bad restore is just
another restore away.

The `run` mode is the key isolation primitive: it locks `cwd` to the
sandbox dir and uses a constrained env, so the LLM can't accidentally
mutate the rest of the filesystem via this tool. (For full freedom
the LLM still has the `Bash` tool.)
"""

from __future__ import annotations

import asyncio
import logging
import os
import shutil
import subprocess
from pathlib import Path
from typing import Any

from core.schemas import ToolResult
from execution.tools.base import BaseTool

logger = logging.getLogger(__name__)


_SANDBOX_DIR = Path("/home/raveuk/cognos/sandbox")
_SNAPSHOT_DIR = Path.home() / ".cognos" / "sandbox-snapshots"
_BIN_DIR = Path("/home/raveuk/cognos/bin")
_RUN_TIMEOUT_S = 60.0


def _fmt_bytes(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.1f}{unit}" if unit != "B" else f"{n}B"
        n /= 1024
    return f"{n}TB"


def _is_mounted() -> bool:
    if not _SANDBOX_DIR.exists():
        return False
    # /proc/mounts is fastest + always accurate
    try:
        with open("/proc/mounts") as f:
            return any(str(_SANDBOX_DIR) in line for line in f)
    except OSError:
        return False


def _disk_usage() -> tuple[int, int, int]:
    """Return (total, used, avail) bytes for the sandbox FS."""
    s = shutil.disk_usage(_SANDBOX_DIR)
    return s.total, s.used, s.free


def _list_snapshots() -> list[dict[str, Any]]:
    if not _SNAPSHOT_DIR.exists():
        return []
    out: list[dict[str, Any]] = []
    for archive in sorted(_SNAPSHOT_DIR.glob("*.tar.zst")):
        sid = archive.stem
        meta_path = _SNAPSHOT_DIR / f"{sid}.meta.json"
        meta: dict[str, Any] = {}
        if meta_path.exists():
            try:
                import json
                meta = json.loads(meta_path.read_text())
            except Exception:
                pass
        out.append({
            "id":        sid,
            "label":     meta.get("label", "-"),
            "created":   meta.get("created_utc", ""),
            "size_bytes": archive.stat().st_size,
            "path":      str(archive),
        })
    return out


class SandboxTool(BaseTool):
    mutates = True
    name = "Sandbox"
    description = (
        "Unified sandbox lifecycle + snapshot tool. The sandbox is a "
        "50GB ext4 loopback at /home/raveuk/cognos/sandbox/. Modes: "
        "'status' (mount + disk + snapshot summary), 'run' (execute a "
        "shell command with cwd locked to the sandbox), 'snapshot' "
        "(tar+zstd current state to ~/.cognos/sandbox-snapshots/), "
        "'restore' (wipe + extract a snapshot — auto-checkpoints first "
        "so it's reversible), 'list_snapshots', 'delete_snapshot'. "
        "Use 'snapshot' before letting the LLM rewrite a project so "
        "you can roll back. 'run' for sandbox-scoped commands; for "
        "full-system commands use the Bash tool instead."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": [
                        "status", "run", "snapshot",
                        "list_snapshots", "restore", "delete_snapshot",
                    ],
                    "description": "What to do.",
                },
                "cmd": {
                    "type": "string",
                    "description": "For 'run' mode: shell command to execute (cwd locked to sandbox).",
                },
                "label": {
                    "type": "string",
                    "description": "For 'snapshot' mode: short label for the snapshot.",
                },
                "id": {
                    "type": "string",
                    "description": "For 'restore' / 'delete_snapshot' mode: snapshot id.",
                },
                "timeout_s": {
                    "type": "number",
                    "description": "For 'run' mode: timeout in seconds (default 60, max 300).",
                },
            },
            "required": ["action"],
        }

    # -- mode dispatch ---------------------------------------------------

    async def execute(self, **kwargs: Any) -> ToolResult:
        action = (kwargs.get("action") or "").lower().strip()
        try:
            if action == "status":
                return self._status()
            if action == "run":
                return await self._run(kwargs)
            if action == "snapshot":
                return self._snapshot(kwargs)
            if action == "list_snapshots":
                return self._list_snapshots()
            if action == "restore":
                return self._restore(kwargs)
            if action == "delete_snapshot":
                return self._delete_snapshot(kwargs)
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"unknown action {action!r}; expected one of: status, run, snapshot, list_snapshots, restore, delete_snapshot",
            )
        except Exception as e:
            logger.exception("Sandbox tool failed")
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"{type(e).__name__}: {e}",
            )

    # -- modes -----------------------------------------------------------

    def _status(self) -> ToolResult:
        mounted = _is_mounted()
        snapshots = _list_snapshots()
        out_lines = [f"sandbox path:  {_SANDBOX_DIR}"]
        out_lines.append(f"  mounted:     {mounted}")
        if mounted:
            total, used, avail = _disk_usage()
            out_lines.append(
                f"  disk usage:  {_fmt_bytes(used)} used / {_fmt_bytes(total)} total "
                f"({_fmt_bytes(avail)} free)"
            )
        out_lines.append(f"snapshots:    {len(snapshots)} stored at {_SNAPSHOT_DIR}")
        if snapshots:
            recent = snapshots[-3:]
            for s in recent:
                out_lines.append(
                    f"  - {s['id']}  ({_fmt_bytes(s['size_bytes'])})  {s['label']}"
                )
            if len(snapshots) > 3:
                out_lines.append(f"  ... and {len(snapshots) - 3} more (use list_snapshots)")
        return ToolResult(
            tool_name=self.name, status="success",
            output="\n".join(out_lines),
            metadata={
                "mounted":   mounted,
                "snapshot_count": len(snapshots),
            },
        )

    async def _run(self, kwargs: dict) -> ToolResult:
        cmd = (kwargs.get("cmd") or "").strip()
        if not cmd:
            return ToolResult(
                tool_name=self.name, status="error",
                error="`cmd` is required for run mode",
            )
        if not _is_mounted():
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"sandbox not mounted at {_SANDBOX_DIR}",
            )
        timeout = max(1.0, min(300.0, float(kwargs.get("timeout_s") or _RUN_TIMEOUT_S)))

        # cwd locked to the sandbox; env minimal so commands don't pick
        # up the user's full shell setup
        env = {
            "HOME":     str(_SANDBOX_DIR),
            "PATH":     "/usr/local/bin:/usr/bin:/bin",
            "USER":     os.environ.get("USER", "raveuk"),
            "LANG":     "C.UTF-8",
            "TMPDIR":   str(_SANDBOX_DIR / ".tmp"),
        }
        (_SANDBOX_DIR / ".tmp").mkdir(exist_ok=True)

        try:
            proc = await asyncio.create_subprocess_shell(
                cmd,
                cwd=str(_SANDBOX_DIR),
                env=env,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout_b, stderr_b = await asyncio.wait_for(
                proc.communicate(), timeout=timeout
            )
        except asyncio.TimeoutError:
            try: proc.kill()
            except Exception: pass
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"command timed out after {timeout}s",
            )

        stdout = stdout_b.decode("utf-8", errors="replace")
        stderr = stderr_b.decode("utf-8", errors="replace")
        rc = proc.returncode if proc.returncode is not None else -1

        out = (
            f"$ {cmd}\n"
            f"  cwd:  {_SANDBOX_DIR}\n"
            f"  exit: {rc}\n"
        )
        if stdout:
            out += f"--- stdout ---\n{stdout[:4000]}"
            if len(stdout) > 4000:
                out += f"\n... ({len(stdout) - 4000} more chars)"
        if stderr:
            out += f"\n--- stderr ---\n{stderr[:2000]}"
        return ToolResult(
            tool_name=self.name,
            status="success" if rc == 0 else "error",
            output=out.rstrip(),
            error=None if rc == 0 else f"exit code {rc}",
            metadata={
                "exit_code": rc,
                "stdout":    stdout,
                "stderr":    stderr,
            },
        )

    def _snapshot(self, kwargs: dict) -> ToolResult:
        label = (kwargs.get("label") or "snapshot").strip()
        script = _BIN_DIR / "cognos-sandbox-snapshot"
        if not script.exists():
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"helper script missing: {script}",
            )
        try:
            result = subprocess.run(
                [str(script), label],
                capture_output=True, text=True, timeout=300,
            )
        except subprocess.TimeoutExpired:
            return ToolResult(
                tool_name=self.name, status="error",
                error="snapshot timed out (>5 min)",
            )
        if result.returncode != 0:
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"snapshot failed: {result.stderr or result.stdout}",
            )
        return ToolResult(
            tool_name=self.name, status="success",
            output=result.stdout.strip(),
            metadata={"label": label},
        )

    def _list_snapshots(self) -> ToolResult:
        snapshots = _list_snapshots()
        if not snapshots:
            return ToolResult(
                tool_name=self.name, status="success",
                output="no snapshots yet — use action='snapshot' to create one",
                metadata={"snapshots": []},
            )
        lines = [f"{len(snapshots)} snapshot(s):"]
        for s in snapshots:
            lines.append(
                f"  {s['id']}  {_fmt_bytes(s['size_bytes']):>10}  "
                f"{s['created']}  {s['label']}"
            )
        return ToolResult(
            tool_name=self.name, status="success",
            output="\n".join(lines),
            metadata={"snapshots": snapshots},
        )

    def _restore(self, kwargs: dict) -> ToolResult:
        sid = (kwargs.get("id") or "").strip()
        if not sid:
            return ToolResult(
                tool_name=self.name, status="error",
                error="`id` is required for restore mode",
            )
        script = _BIN_DIR / "cognos-sandbox-restore"
        try:
            result = subprocess.run(
                [str(script), sid, "-y"],
                capture_output=True, text=True, timeout=300,
            )
        except subprocess.TimeoutExpired:
            return ToolResult(
                tool_name=self.name, status="error",
                error="restore timed out (>5 min)",
            )
        if result.returncode != 0:
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"restore failed: {result.stderr or result.stdout}",
            )
        return ToolResult(
            tool_name=self.name, status="success",
            output=result.stdout.strip(),
            metadata={"restored_id": sid},
        )

    def _delete_snapshot(self, kwargs: dict) -> ToolResult:
        sid = (kwargs.get("id") or "").strip()
        if not sid:
            return ToolResult(
                tool_name=self.name, status="error",
                error="`id` is required for delete_snapshot mode",
            )
        archive = _SNAPSHOT_DIR / f"{sid}.tar.zst"
        meta = _SNAPSHOT_DIR / f"{sid}.meta.json"
        if not archive.exists():
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"snapshot not found: {sid}",
            )
        archive.unlink()
        meta.unlink(missing_ok=True)
        return ToolResult(
            tool_name=self.name, status="success",
            output=f"deleted snapshot {sid}",
            metadata={"deleted_id": sid},
        )
