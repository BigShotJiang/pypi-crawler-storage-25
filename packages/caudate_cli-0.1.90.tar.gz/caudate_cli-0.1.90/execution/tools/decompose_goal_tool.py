"""DecomposeGoal (Phase 2.5) — break the active goal into a richer
subtask tree than TodoWrite can express.

When `/goal new` creates a fresh Goal with zero subtasks, the agent's
first move should be to call this tool with the breakdown:

    DecomposeGoal(subtasks=[
      {"description": "scaffold project layout"},
      {"description": "write Flask backend",         "depends_on": [0]},
      {"description": "build HTML/CSS/JS frontend",  "depends_on": [0]},
      {"description": "test end-to-end",             "depends_on": [1, 2]},
    ])

Differences from TodoWrite:
- **Persistent across turns** — stored in the Goal at
  ~/.caudate/goals/<id>.json; survives quit/relaunch
- **Cross-session** — resume into a goal and the subtasks are still
  there with their current statuses
- **Dependencies** — each subtask can declare which earlier ones
  must be done first; Phase 6 sub-agents will dispatch independent
  ones in parallel
- **Linked to attempts** — each tool call that targets a subtask
  records an AttemptLog with outcome_reward (Phase 1 cross-link)

TodoWrite is still the right call for *per-turn* checklists ("I'll do
A then B then C in this turn"). DecomposeGoal is the *project-level*
tree that spans multiple turns and sessions.
"""

from __future__ import annotations

import logging
from typing import Any

from core.schemas import ToolResult, ToolResultStatus
from execution.tools.base import BaseTool

logger = logging.getLogger(__name__)


class DecomposeGoalTool(BaseTool):
    name = "DecomposeGoal"
    description = (
        "Decompose the ACTIVE GOAL into a structured subtask tree. "
        "Call this once at the start of a fresh goal (when "
        "render_for_prompt shows zero subtasks) to lay out the work. "
        "Each subtask gets a description and optional `depends_on` "
        "(a list of integer indices into THIS call's subtasks array). "
        "Subtasks with no dependencies are independently dispatchable. "
        "The tree persists across turns and sessions — UNLIKE "
        "TodoWrite, which is per-turn. Use TodoWrite for in-turn "
        "checklists, DecomposeGoal for the project-level plan."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "subtasks": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "description": {
                                "type": "string",
                                "description": (
                                    "One-line imperative description of "
                                    "this subtask (e.g. 'write Flask backend')."
                                ),
                            },
                            "depends_on": {
                                "type": "array",
                                "items": {"type": "integer"},
                                "description": (
                                    "Optional list of integer indices into "
                                    "the same subtasks array — subtasks "
                                    "that must complete before this one. "
                                    "Empty / omitted = no dependencies."
                                ),
                            },
                        },
                        "required": ["description"],
                    },
                    "description": (
                        "Ordered list of subtasks. Index-based deps refer "
                        "to positions in THIS array."
                    ),
                },
                "replace": {
                    "type": "boolean",
                    "description": (
                        "If true, replace the existing subtasks. Default "
                        "false: append to whatever the goal already has."
                    ),
                    "default": False,
                },
            },
            "required": ["subtasks"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        # Resolve active goal — best-effort, no crash if absent.
        try:
            from core.goal_store import get_store
            from core.goal import SubtaskStatus
        except Exception as e:
            return ToolResult(
                tool_name=self.name, status=ToolResultStatus.ERROR,
                error=f"goal subsystem unavailable: {e}",
            )

        store = get_store()
        goal = store.active()
        if goal is None:
            return ToolResult(
                tool_name=self.name, status=ToolResultStatus.ERROR,
                error=(
                    "No active goal. Create one first with /goal new "
                    '"<intent>" — DecomposeGoal acts on the active goal.'
                ),
            )

        subtasks_arg = kwargs.get("subtasks") or []
        # Tolerate JSON-string shape (same Kimi quirk as TodoWrite)
        if isinstance(subtasks_arg, str):
            import json as _json
            try:
                subtasks_arg = _json.loads(subtasks_arg)
            except _json.JSONDecodeError:
                return ToolResult(
                    tool_name=self.name, status=ToolResultStatus.ERROR,
                    error="`subtasks` must be a list (or JSON-encoded list)",
                )
        if not isinstance(subtasks_arg, list) or not subtasks_arg:
            return ToolResult(
                tool_name=self.name, status=ToolResultStatus.ERROR,
                error="`subtasks` must be a non-empty list",
            )

        replace = bool(kwargs.get("replace", False))
        if replace:
            goal.subtasks = []

        # Two-pass build: create subtasks first (so we have stable IDs),
        # then resolve `depends_on` indices to those IDs.
        created_ids: list[str] = []
        descriptions: list[str] = []
        for i, raw in enumerate(subtasks_arg):
            if not isinstance(raw, dict):
                continue
            desc = str(raw.get("description", "")).strip()
            if not desc:
                continue
            descriptions.append(desc)
            st = goal.add_subtask(description=desc)
            created_ids.append(st.id)

        if not created_ids:
            return ToolResult(
                tool_name=self.name, status=ToolResultStatus.ERROR,
                error="all subtasks were empty / malformed; nothing added",
            )

        # Second pass — wire depends_on from indices to actual IDs.
        for i, raw in enumerate(subtasks_arg):
            if not isinstance(raw, dict) or not raw.get("description"):
                continue
            if i >= len(created_ids):
                break
            deps = raw.get("depends_on") or []
            if not isinstance(deps, list):
                continue
            dep_ids: list[str] = []
            for d in deps:
                try:
                    idx = int(d)
                except (TypeError, ValueError):
                    continue
                # Self-deps and forward-deps are nonsense — quietly drop
                if idx < 0 or idx >= len(created_ids) or idx == i:
                    continue
                dep_ids.append(created_ids[idx])
            # Find the just-created subtask by id (preserves any
            # pre-existing subtasks from append mode)
            for st in goal.subtasks:
                if st.id == created_ids[i]:
                    st.depends_on = dep_ids
                    break

        if not store.save(goal):
            return ToolResult(
                tool_name=self.name, status=ToolResultStatus.ERROR,
                error="failed to persist goal to disk",
            )

        n = len(created_ids)
        n_with_deps = sum(
            1 for st in goal.subtasks
            if st.id in created_ids and st.depends_on
        )
        action = "replaced" if replace else "added"
        summary = (
            f"{action} {n} subtask(s); "
            f"{n_with_deps} have dependencies. "
            f"Goal {goal.short_id()} now has {len(goal.subtasks)} subtask(s) total."
        )
        return ToolResult(
            tool_name=self.name, status=ToolResultStatus.SUCCESS,
            output=summary,
            metadata={
                "goal_id": goal.id,
                "subtask_ids": created_ids,
                "descriptions": descriptions,
                "total_subtasks": len(goal.subtasks),
            },
        )
