"""Grep tool — regex content search across files."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from core.schemas import ToolResult
from execution.tools.base import BaseTool


class GrepTool(BaseTool):
    name = "Grep"
    description = (
        "Search for a regex pattern across files. Returns matching lines "
        "with file:line:text. Supports include-glob filtering."
    )

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "pattern": {
                    "type": "string",
                    "description": "Regex pattern to search for",
                },
                "path": {
                    "type": "string",
                    "description": "Root directory to search. Defaults to cwd.",
                },
                "include": {
                    "type": "string",
                    "description": "Glob to restrict files, e.g. '**/*.py'",
                    "default": "**/*",
                },
                "case_insensitive": {
                    "type": "boolean",
                    "description": "If true, ignore case. Default false.",
                    "default": False,
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum matching lines to return (default 200)",
                    "default": 200,
                },
            },
            "required": ["pattern"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        pattern = kwargs.get("pattern", "")
        if not pattern:
            return self._error("No pattern provided")

        root = Path(kwargs.get("path") or ".").resolve()
        include = kwargs.get("include", "**/*")
        flags = re.IGNORECASE if kwargs.get("case_insensitive") else 0
        limit = int(kwargs.get("limit", 200))

        try:
            regex = re.compile(pattern, flags)
        except re.error as e:
            return self._error(f"Invalid regex: {e}")

        matches: list[str] = []
        try:
            for path in root.glob(include):
                if not path.is_file():
                    continue
                try:
                    # Skip obviously binary files
                    text = path.read_text(errors="ignore")
                except Exception:
                    continue
                for i, line in enumerate(text.splitlines(), 1):
                    if regex.search(line):
                        matches.append(f"{path}:{i}: {line.rstrip()}")
                        if len(matches) >= limit:
                            break
                if len(matches) >= limit:
                    break
        except Exception as e:
            return self._error(str(e))

        if not matches:
            return self._success(f"No matches for /{pattern}/ in {root}/{include}")
        return self._success("\n".join(matches))
