"""Respond tool — present information back to the user."""

from __future__ import annotations

from typing import Any

from rich.console import Console
from rich.panel import Panel

from core.schemas import ToolResult
from execution.tools.base import BaseTool

console = Console()


class RespondTool(BaseTool):
    name = "Respond"
    description = "Present a response or answer to the user. Use this to communicate results, explanations, or any information."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "message": {
                    "type": "string",
                    "description": "The message to show the user",
                },
            },
            "required": ["message"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        message = kwargs.get("message", "")
        if not message:
            return self._error("No message provided")

        console.print(Panel(message, title="Cognos", border_style="green"))
        preview = message[:100] + "..." if len(message) > 100 else message
        return self._success(f"Responded to user: {preview}")
