"""CognosCard — read the Cognos self-spec card.

Mirrors the structure of the Anthropic Opus self-card the user
showed: confirmable facts / architecture / training / capabilities /
**what we can't honestly tell you**. The card lives at
`data/COGNOS_CARD.md` and is human-edited (not auto-generated).

The LLM can call this tool to:
  - Answer "what is Cognos?" / "what can you do?" honestly
  - Self-introspect before claiming a capability ("can I do X?")
  - Anchor on the explicit boundaries section before responding
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from core.schemas import ToolResult
from execution.tools.base import BaseTool

logger = logging.getLogger(__name__)


_CARD_PATH = Path("/home/raveuk/cognos/data/COGNOS_CARD.md")


def render_cognos_card_short() -> str:
    """One-paragraph reference to the card, suitable for system-prompt
    injection. Tells the LLM the card exists + how to read it; doesn't
    bloat the prompt with the full card body.
    """
    return (
        "## About Cognos\n\n"
        "You are running inside **Cognos** — a local-first cognitive "
        "agent on the user's own machine. The full structured "
        "self-spec lives at `data/COGNOS_CARD.md` and is also "
        "available via the `CognosCard` tool: confirmable facts, "
        "architecture, capabilities, and an explicit list of what "
        "Cognos cannot honestly tell you. **Call CognosCard before "
        "claiming a capability you're unsure about** — the card is "
        "the source of truth, not your model's training defaults."
    )


class CognosCardTool(BaseTool):
    name = "CognosCard"
    description = (
        "Read the Cognos self-spec card — verifiable facts about the "
        "agent you're running inside, its architecture, what it can "
        "do, and (importantly) what it CANNOT honestly tell you. "
        "Call this whenever the user asks 'what are you', 'what can "
        "you do', or whenever you'd otherwise speculate about Cognos "
        "internals. Returns the full markdown card."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "section": {
                    "type": "string",
                    "enum": [
                        "all",
                        "confirm",
                        "architecture",
                        "training",
                        "capabilities",
                        "boundaries",
                    ],
                    "description": "Which section to return. 'all' returns the full card; the others return only that section.",
                },
            },
            "required": [],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        if not _CARD_PATH.exists():
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"card not found at {_CARD_PATH}",
            )
        text = _CARD_PATH.read_text()
        section = (kwargs.get("section") or "all").lower().strip()
        if section == "all":
            return ToolResult(
                tool_name=self.name, status="success",
                output=text,
                metadata={"path": str(_CARD_PATH), "section": "all"},
            )

        # Section extraction — find the relevant H2 heading and return
        # everything until the next H2.
        section_headings = {
            "confirm":      "## What I can publicly confirm",
            "architecture": "## Architecture (publicly known shape)",
            "training":     "## Caudate training pipeline (general shape)",
            "capabilities": "## Capabilities at inference",
            "boundaries":   "## What I cannot honestly tell you",
        }
        marker = section_headings.get(section)
        if not marker:
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"unknown section {section!r}",
            )
        idx = text.find(marker)
        if idx < 0:
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"section heading not found: {marker!r}",
            )
        # Slice from the heading to the next H2 (or end of file)
        end = text.find("\n## ", idx + len(marker))
        if end < 0:
            end = len(text)
        body = text[idx:end].rstrip()
        return ToolResult(
            tool_name=self.name, status="success",
            output=body,
            metadata={"path": str(_CARD_PATH), "section": section},
        )
