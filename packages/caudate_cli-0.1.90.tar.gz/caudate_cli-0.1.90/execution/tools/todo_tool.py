"""TodoWrite — agentic checklist the user sees update live.

Mirrors Claude Code's TodoWrite tool. The agent passes the full
current state of the checklist on every call; we render it in the
terminal as a bordered list and update in place as items tick from
pending → in_progress → completed.

Single-source-of-truth: the latest call wins; the agent doesn't have
to track diffs. Empty list clears the display.
"""

from __future__ import annotations

from typing import Any

from core.schemas import ToolResult
from execution.tools.base import BaseTool


_VALID_STATUSES = {"pending", "in_progress", "completed"}


class TodoWriteTool(BaseTool):
    name = "TodoWrite"
    description = (
        "Write the agent's task checklist. Call this when you start a "
        "multi-step job, set the full list with each item's status, "
        "and re-call as items progress. The user sees the list update "
        "live. Each item: {content: <imperative>, status: pending | "
        "in_progress | completed, activeForm: <present-continuous>}. "
        "Exactly one item should be `in_progress` at a time."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "todos": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "content": {"type": "string"},
                            "status": {
                                "type": "string",
                                "enum": ["pending", "in_progress", "completed"],
                            },
                            "activeForm": {"type": "string"},
                        },
                        "required": ["content", "status"],
                    },
                    "description": "Full checklist state.",
                },
            },
            "required": ["todos"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        todos = kwargs.get("todos") or []
        # Smaller models sometimes emit `todos` as a JSON-encoded string
        # instead of an array. Parse on the fly so a tool call doesn't
        # get burned on a stringification mistake.
        if isinstance(todos, str):
            import json as _json
            try:
                todos = _json.loads(todos)
            except _json.JSONDecodeError:
                return ToolResult(
                    tool_name=self.name, status="error",
                    error="`todos` must be a list (or a JSON-encoded list string)",
                )
        if not isinstance(todos, list):
            return ToolResult(
                tool_name=self.name, status="error",
                error="`todos` must be a list",
            )

        clean: list[dict[str, str]] = []
        for t in todos:
            if not isinstance(t, dict):
                continue
            content = str(t.get("content", "")).strip()
            status = str(t.get("status", "pending")).strip()
            active = str(t.get("activeForm", "")).strip()
            if not content:
                continue
            if status not in _VALID_STATUSES:
                status = "pending"
            clean.append(
                {"content": content, "status": status, "activeForm": active}
            )

        # Push to the live display if one is wired (interactive REPL).
        try:
            from ui.display import get_active_display
            d = get_active_display()
            if d is not None:
                d.on_todo_write(clean)
        except Exception:
            pass

        # Summarise for the LLM response so it sees the confirmed state.
        pend = sum(1 for t in clean if t["status"] == "pending")
        prog = sum(1 for t in clean if t["status"] == "in_progress")
        done = sum(1 for t in clean if t["status"] == "completed")
        summary = f"todos: {done} done, {prog} in_progress, {pend} pending"
        return ToolResult(
            tool_name=self.name, status="success",
            output=summary,
            metadata={"todos": clean},
        )
