"""Glob tool — find files by glob pattern."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from core.schemas import ToolResult
from execution.tools.base import BaseTool


class GlobTool(BaseTool):
    name = "Glob"
    description = (
        "Find files matching a glob pattern (e.g. '**/*.py', 'src/**/*.ts'). "
        "Returns a newline-separated list of paths, sorted by modification time."
    )

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "pattern": {
                    "type": "string",
                    "description": "Glob pattern, e.g. '**/*.py'",
                },
                "path": {
                    "type": "string",
                    "description": "Root directory to search in. Defaults to cwd.",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum results (default 200)",
                    "default": 200,
                },
            },
            "required": ["pattern"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        pattern = kwargs.get("pattern", "")
        if not pattern:
            return self._error("No pattern provided")

        root = Path(kwargs.get("path") or ".").resolve()
        limit = int(kwargs.get("limit", 200))

        try:
            matches = [p for p in root.glob(pattern) if p.is_file()]
        except Exception as e:
            return self._error(str(e))

        if not matches:
            return self._success(f"No matches for {pattern} in {root}")

        matches.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        matches = matches[:limit]
        return self._success("\n".join(str(p) for p in matches))
