"""File tools — read and write files."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from core.schemas import ToolResult
from execution.tools.base import BaseTool


class FileReadTool(BaseTool):
    name = "Read"
    description = "Read the contents of a file. Returns the file text. Supports offset and limit for large files."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Absolute or relative path to the file to read",
                },
                "offset": {
                    "type": "integer",
                    "description": "Line number to start reading from (1-based)",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of lines to read",
                },
            },
            "required": ["path"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        path = kwargs.get("path", "")
        if not path:
            return self._error("No path provided")
        offset = kwargs.get("offset")
        limit = kwargs.get("limit")
        try:
            content = Path(path).read_text()
            if offset or limit:
                lines = content.splitlines(keepends=True)
                start = (offset - 1) if offset and offset > 0 else 0
                end = (start + limit) if limit else len(lines)
                content = "".join(lines[start:end])
            return self._success(content)
        except FileNotFoundError:
            return self._error(f"File not found: {path}")
        except Exception as e:
            return self._error(str(e))


_FORBIDDEN_WRITE_PATH_FRAGMENTS = ("/cognos/sandbox/",)


def _violates_workspace(path: str) -> str | None:
    """Refuse writes to forbidden default paths when workspace_mode=cwd."""
    try:
        from core.settings import Settings
        mode = (Settings.load().get("workspace_mode") or "cwd").lower()
    except Exception:
        mode = "cwd"
    if mode != "cwd":
        return None
    norm = path.replace("\\", "/")
    for frag in _FORBIDDEN_WRITE_PATH_FRAGMENTS:
        if frag in norm:
            return (
                "Refusing to write into the legacy sandbox path. The "
                "workspace is the cwd — use the directory the user "
                "launched caudate from. If a different path is needed, "
                "ask the user."
            )
    return None


class FileWriteTool(BaseTool):
    mutates = True
    name = "Write"
    description = "Write content to a file. Creates parent directories if needed. Overwrites existing content."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path to the file to write",
                },
                "content": {
                    "type": "string",
                    "description": "Content to write to the file",
                },
            },
            "required": ["path", "content"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        path = kwargs.get("path", "")
        content = kwargs.get("content", "")
        if not path:
            return self._error("No path provided")
        ws_reason = _violates_workspace(path)
        if ws_reason is not None:
            return self._error(ws_reason)
        try:
            p = Path(path)
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(content)
            return self._success(f"Written {len(content)} chars to {path}")
        except Exception as e:
            return self._error(str(e))
