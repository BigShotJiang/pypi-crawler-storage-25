"""SemanticSearch — vector-similarity recall over the SemanticMemory store.

Cognos's `memory/semantic.py` keeps a chromadb collection of durable
facts/concepts the agent has learned. Stuff goes in via `.store()`
calls (currently from a few places in the agent loop); this tool is
the read side, exposed to the LLM so it can ask "have I seen this
topic before?" without the user having to type the answer.

Complements `UpdateMemory` (which writes a flat markdown file): this
one handles the *vector-indexed* knowledge — semantic similarity
beats string match for paraphrased recall.
"""

from __future__ import annotations

import logging
from typing import Any

from core.schemas import ToolResult
from execution.tools.base import BaseTool

logger = logging.getLogger(__name__)


class SemanticSearchTool(BaseTool):
    name = "SemanticSearch"
    description = (
        "Vector-similarity search over Cognos's long-term semantic "
        "memory (durable facts the agent has learned). Use this when "
        "the user asks 'do you remember anything about X?', when "
        "you'd benefit from prior context on a topic, or when "
        "answering a question that might have been answered before. "
        "Complements UpdateMemory (which is for the flat markdown "
        "memory file): use this for fuzzy/semantic recall, "
        "UpdateMemory for explicit append/replace."
    )

    def __init__(self):
        # Lazy-initialise the store so cold-start of the executor
        # doesn't pay the chromadb load cost. First call materialises.
        self._store: Any | None = None

    def _get_store(self):
        if self._store is None:
            from memory.semantic import SemanticMemory
            self._store = SemanticMemory()
        return self._store

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Natural-language query — paraphrasing is fine, the search uses semantic similarity.",
                },
                "limit": {
                    "type": "integer",
                    "description": "Max results to return. Default 5.",
                    "default": 5,
                },
                "category": {
                    "type": "string",
                    "description": "Optional category filter (e.g. 'preferences', 'project').",
                },
            },
            "required": ["query"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        query = (kwargs.get("query") or "").strip()
        if not query:
            return ToolResult(
                tool_name=self.name, status="error",
                error="empty query",
            )
        limit = max(1, int(kwargs.get("limit") or 5))
        category = kwargs.get("category") or None

        try:
            store = self._get_store()
            hits = store.recall(query=query, limit=limit, category=category)
        except Exception as e:
            logger.exception("SemanticSearch failed")
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"{type(e).__name__}: {e}",
            )

        if not hits:
            return ToolResult(
                tool_name=self.name, status="success",
                output=f"No semantic matches for: {query!r}",
                metadata={"query": query, "hits": []},
            )
        lines = [f"Found {len(hits)} semantic match(es) for: {query!r}"]
        for i, h in enumerate(hits, 1):
            cat = h.get("category", "general")
            content = h.get("content", "")[:300]
            lines.append(f"  {i}. [{cat}] {content}")
        return ToolResult(
            tool_name=self.name, status="success",
            output="\n".join(lines),
            metadata={"query": query, "hits": hits},
        )
