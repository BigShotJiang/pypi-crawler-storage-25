"""WebSearch tool — real web search via DuckDuckGo HTML.

Uses the no-JS HTML endpoint (`html.duckduckgo.com`) which returns a list
of titled results without needing an API key. Falls back to the instant-
answer JSON API if the HTML scrape fails (some networks block it).
"""

from __future__ import annotations

import asyncio
import html as html_lib
import json
import re
import urllib.parse
from typing import Any

from core.schemas import ToolResult
from execution.tools.base import BaseTool


# Loose patterns over the rendered HTML. DuckDuckGo's HTML layout is
# stable enough that these have held for years; if they break, the JSON
# fallback below still returns *something*.
_RESULT_BLOCK_RE = re.compile(
    r'<a[^>]*class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>'
    r'(?:.*?<a[^>]*class="result__snippet"[^>]*>(.*?)</a>)?',
    re.DOTALL,
)
_TAG_RE = re.compile(r"<[^>]+>")


class WebSearchTool(BaseTool):
    name = "WebSearch"
    description = (
        "Search the web with DuckDuckGo and return ranked results "
        "(title, URL, snippet). Use to find current information, docs, "
        "or sources before fetching a specific page with WebFetch."
    )

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "The search query",
                },
                "max_results": {
                    "type": "integer",
                    "description": "Max results to return (default 8)",
                    "default": 8,
                },
            },
            "required": ["query"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        query = (kwargs.get("query") or "").strip()
        if not query:
            return self._error("No query provided")
        max_results = max(1, int(kwargs.get("max_results", 8)))

        # 1. Real HTML results
        try:
            html = await _curl(
                f"https://html.duckduckgo.com/html/?q={urllib.parse.quote(query)}",
                method="POST",
                data=f"q={urllib.parse.quote(query)}",
            )
        except Exception as e:
            html = ""

        results = _parse_html_results(html, max_results) if html else []

        # 2. Fallback to instant-answer JSON if HTML scrape produced nothing
        if not results:
            try:
                raw = await _curl(
                    f"https://api.duckduckgo.com/?q={urllib.parse.quote(query)}"
                    f"&format=json&no_html=1",
                )
                data = json.loads(raw) if raw else {}
            except Exception:
                data = {}
            if data.get("Abstract"):
                results.append({
                    "title": data.get("AbstractSource", "Summary"),
                    "url": data.get("AbstractURL", ""),
                    "snippet": data["Abstract"],
                })
            for topic in data.get("RelatedTopics", [])[:max_results]:
                if isinstance(topic, dict) and topic.get("Text"):
                    results.append({
                        "title": topic.get("Text", "")[:80],
                        "url": topic.get("FirstURL", ""),
                        "snippet": topic.get("Text", ""),
                    })

        if not results:
            return self._success(f"No results found for: {query}")

        lines = [f"# Search results for: {query}", ""]
        for i, r in enumerate(results, 1):
            lines.append(f"{i}. **{r['title']}**")
            if r.get("url"):
                lines.append(f"   {r['url']}")
            if r.get("snippet"):
                lines.append(f"   {r['snippet']}")
            lines.append("")
        return self._success("\n".join(lines))


async def _curl(
    url: str, method: str = "GET", data: str | None = None,
) -> str:
    """Run curl in a subprocess, return decoded body (best effort)."""
    args = [
        "curl", "-sSL", "--max-time", "20",
        "-A", "Mozilla/5.0 (cognos)",
    ]
    if method == "POST":
        args += ["-X", "POST"]
    if data:
        args += ["--data", data]
    args.append(url)
    proc = await asyncio.create_subprocess_exec(
        *args,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=22)
    return stdout.decode(errors="ignore")


def _parse_html_results(html: str, limit: int) -> list[dict[str, str]]:
    out: list[dict[str, str]] = []
    for match in _RESULT_BLOCK_RE.finditer(html):
        url = match.group(1)
        # DDG wraps real urls in /l/?uddg=<encoded>
        if "uddg=" in url:
            try:
                qs = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
                url = qs.get("uddg", [url])[0]
            except Exception:
                pass
        title = html_lib.unescape(_TAG_RE.sub("", match.group(2) or "")).strip()
        snippet = html_lib.unescape(_TAG_RE.sub("", match.group(3) or "")).strip()
        if title and url:
            out.append({"title": title, "url": url, "snippet": snippet})
        if len(out) >= limit:
            break
    return out
