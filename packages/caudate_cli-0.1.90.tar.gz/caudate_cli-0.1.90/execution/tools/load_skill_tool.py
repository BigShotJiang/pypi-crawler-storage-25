"""LoadSkill — fetch the full body of an installed skill.

Skills are listed in the system prompt as a TOC (just name +
description) to keep prompt size bounded. When the LLM decides a
skill is relevant for the current turn, it calls this tool to get
the full markdown instructions for that skill.

Companion to `core/skills.py`. Reload via `RescanSkills` after the
user runs `npx skills add ...`.
"""

from __future__ import annotations

import logging
from typing import Any

from core.schemas import ToolResult
from core.skills import get_skills, reload_skills
from execution.tools.base import BaseTool

logger = logging.getLogger(__name__)


class LoadSkillTool(BaseTool):
    name = "LoadSkill"
    description = (
        "Fetch the full instructions for an installed skill. The system "
        "prompt lists skills as a table of contents (name + one-line "
        "description); call this tool to read the actual markdown body "
        "of a skill that looks relevant to the current turn. Use the "
        "exact `name` from the TOC."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": "Skill name (exact, from the TOC).",
                },
            },
            "required": ["name"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        name = (kwargs.get("name") or "").strip()
        if not name:
            return ToolResult(
                tool_name=self.name, status="error",
                error="`name` is required",
            )
        registry = get_skills()
        skill = registry.get(name)
        if skill is None:
            close = [n for n in registry.list_names()
                     if name.lower() in n.lower() or n.lower() in name.lower()]
            hint = (f" did you mean: {close[:5]}?" if close else
                    f" available: {registry.list_names()[:10]}")
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"skill {name!r} not found.{hint}",
            )
        return ToolResult(
            tool_name=self.name, status="success",
            output=(
                f"# {skill.name}\n"
                f"{skill.description}\n"
                f"\n---\n\n{skill.body}"
            ),
            metadata={
                "name":        skill.name,
                "description": skill.description,
                "path":        str(skill.path),
                "source_dir":  str(skill.source_dir),
            },
        )


class RescanSkillsTool(BaseTool):
    name = "RescanSkills"
    description = (
        "Re-scan the skill directories after running `npx skills add` "
        "or manually adding/removing a skill. Returns the new count + "
        "list of names."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {"type": "object", "properties": {}, "required": []}

    async def execute(self, **_: Any) -> ToolResult:
        registry = reload_skills()
        names = registry.list_names()
        return ToolResult(
            tool_name=self.name, status="success",
            output=(
                f"Rescanned. Found {len(names)} skill(s):\n"
                + "\n".join(f"  - {n}" for n in names)
                if names else "Rescanned. No skills found."
            ),
            metadata={"count": len(names), "names": names},
        )
