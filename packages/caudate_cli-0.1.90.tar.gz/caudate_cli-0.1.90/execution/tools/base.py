"""Base tool interface — Claude SDK compatible tool protocol."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from core.schemas import ToolResult, ToolResultStatus


class BaseTool(ABC):
    """Abstract base class for all tools.

    Tools define their interface via `input_schema` (JSON Schema),
    matching the Claude SDK tool definition format.

    Plan-mode contract: subclasses that perform any side-effect
    (writing files, running shell commands, mutating external state)
    set `mutates = True`. The executor refuses to run mutating tools
    while plan mode is on. Read-only tools (Read, Grep, Glob,
    SystemInfo, Calculator, etc.) leave `mutates = False`.
    """

    # Whether this tool produces side effects. Default False — every
    # subclass that writes files / runs commands / sends network
    # requests / changes durable state should override to True.
    mutates: bool = False

    @property
    @abstractmethod
    def name(self) -> str:
        """Unique tool name."""
        ...

    @property
    @abstractmethod
    def description(self) -> str:
        """Human-readable description of what the tool does."""
        ...

    @property
    def input_schema(self) -> dict[str, Any]:
        """JSON Schema defining the tool's input parameters.

        Override this in subclasses. Default returns empty object schema.
        """
        return {"type": "object", "properties": {}, "required": []}

    @property
    def parameters(self) -> dict[str, str]:
        """Legacy parameter descriptions for LLM planning.

        Auto-generated from input_schema for backward compatibility.
        """
        props = self.input_schema.get("properties", {})
        return {k: v.get("description", "") for k, v in props.items()}

    def to_tool_definition(self) -> dict[str, Any]:
        """Return LiteLLM-compatible tool definition.

        Format: {"type": "function", "function": {"name", "description", "parameters"}}
        """
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.input_schema,
            },
        }

    @abstractmethod
    async def execute(self, **kwargs: Any) -> ToolResult:
        """Execute the tool with given arguments."""
        ...

    def _success(self, output: Any) -> ToolResult:
        return ToolResult(tool_name=self.name, status=ToolResultStatus.SUCCESS, output=output)

    def _error(self, error: str) -> ToolResult:
        return ToolResult(tool_name=self.name, status=ToolResultStatus.ERROR, error=error)
