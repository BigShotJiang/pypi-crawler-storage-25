"""DateTime — current time, parse, format, relative dates.

LLMs always have a stale "today" because their training cut-off is
in the past, and even if they hold a notion of "now" it drifts
through a long conversation. This tool gives them an accurate
single source of truth for time-related questions.

Modes:
  - now:     return the current datetime (UTC + local + ISO).
  - parse:   parse a string into a datetime, return its components.
  - format:  format a datetime string to a different layout.
  - delta:   compute time elapsed between two datetimes, OR add/
             subtract a duration from a base datetime.

Pure stdlib. No timezone DB beyond what Python ships with.
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Any

from core.schemas import ToolResult
from execution.tools.base import BaseTool

logger = logging.getLogger(__name__)


def _now_block() -> dict[str, str]:
    now_utc = datetime.now(timezone.utc)
    now_local = datetime.now().astimezone()
    return {
        "iso_utc":   now_utc.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "iso_local": now_local.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "weekday":   now_local.strftime("%A"),
        "human":     now_local.strftime("%Y-%m-%d %H:%M:%S %Z"),
    }


def _parse_datetime(s: str) -> datetime:
    """Best-effort datetime parse. Tries ISO 8601 first, then a few
    common human formats."""
    s = s.strip()
    # ISO 8601 (most common LLM output)
    try:
        # Replace trailing Z with +00:00 for fromisoformat
        return datetime.fromisoformat(s.replace("Z", "+00:00"))
    except ValueError:
        pass
    # Common human formats
    for fmt in (
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%Y-%m-%d",
        "%d/%m/%Y",
        "%d-%m-%Y",
        "%m/%d/%Y",
        "%Y/%m/%d",
        "%A, %d %B %Y %H:%M:%S",
    ):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    raise ValueError(f"could not parse datetime: {s!r}")


def _parse_duration(s: str) -> timedelta:
    """Parse '3d', '24h', '90m', '60s', or signed combos like '-7d', '+30m'."""
    s = s.strip().lower()
    if not s:
        raise ValueError("empty duration")
    sign = 1
    if s[0] in "+-":
        sign = -1 if s[0] == "-" else 1
        s = s[1:]
    if s.endswith("d"):
        return sign * timedelta(days=float(s[:-1]))
    if s.endswith("h"):
        return sign * timedelta(hours=float(s[:-1]))
    if s.endswith("m"):
        return sign * timedelta(minutes=float(s[:-1]))
    if s.endswith("s"):
        return sign * timedelta(seconds=float(s[:-1]))
    if s.endswith("w"):
        return sign * timedelta(weeks=float(s[:-1]))
    raise ValueError(f"could not parse duration: {s!r}")


class DateTimeTool(BaseTool):
    name = "DateTime"
    description = (
        "Authoritative time tool. Use whenever the user asks 'what time "
        "is it', 'what's today's date', 'how long ago was X', or "
        "anything time-relative. Modes: 'now' (current time), 'parse' "
        "(parse a string), 'format' (re-format a date), 'delta' "
        "(compute elapsed time, or add/subtract duration). "
        "Don't compute dates in your head — call this; you'll be wrong."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "mode": {
                    "type": "string",
                    "enum": ["now", "parse", "format", "delta"],
                    "description": "What to do.",
                },
                "input": {
                    "type": "string",
                    "description": "For parse: the date string. For format: the date to re-format. For delta: the base datetime.",
                },
                "format": {
                    "type": "string",
                    "description": "strftime format for 'format' mode (e.g. '%Y-%m-%d').",
                },
                "duration": {
                    "type": "string",
                    "description": "For delta mode: a duration like '3d', '-24h', '+90m' to add to `input`.",
                },
                "until": {
                    "type": "string",
                    "description": "For delta mode: a second datetime to compute (until - input).",
                },
            },
            "required": ["mode"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        mode = (kwargs.get("mode") or "").lower().strip()
        try:
            if mode == "now":
                return ToolResult(
                    tool_name=self.name, status="success",
                    output="\n".join(f"{k}: {v}" for k, v in _now_block().items()),
                    metadata=_now_block(),
                )

            if mode == "parse":
                s = kwargs.get("input") or ""
                dt = _parse_datetime(s)
                meta = {
                    "iso":       dt.isoformat(),
                    "year":      dt.year, "month": dt.month, "day": dt.day,
                    "hour":      dt.hour, "minute": dt.minute, "second": dt.second,
                    "weekday":   dt.strftime("%A"),
                    "tz":        str(dt.tzinfo) if dt.tzinfo else "naive",
                }
                return ToolResult(
                    tool_name=self.name, status="success",
                    output="\n".join(f"{k}: {v}" for k, v in meta.items()),
                    metadata=meta,
                )

            if mode == "format":
                s = kwargs.get("input") or ""
                fmt = kwargs.get("format") or "%Y-%m-%d"
                dt = _parse_datetime(s)
                formatted = dt.strftime(fmt)
                return ToolResult(
                    tool_name=self.name, status="success",
                    output=formatted,
                    metadata={"formatted": formatted},
                )

            if mode == "delta":
                base = _parse_datetime(kwargs.get("input") or "")
                # Two sub-modes: until (compute elapsed) OR duration (add/subtract)
                until = kwargs.get("until")
                duration = kwargs.get("duration")
                if until and duration:
                    return ToolResult(
                        tool_name=self.name, status="error",
                        error="provide either 'until' or 'duration', not both",
                    )
                if until:
                    other = _parse_datetime(until)
                    delta = other - base
                    return ToolResult(
                        tool_name=self.name, status="success",
                        output=f"{base.isoformat()} → {other.isoformat()}: "
                               f"{delta.total_seconds():.0f}s "
                               f"({delta.days}d {delta.seconds//3600}h)",
                        metadata={
                            "from": base.isoformat(),
                            "to":   other.isoformat(),
                            "seconds": delta.total_seconds(),
                            "days":  delta.days,
                        },
                    )
                if duration:
                    delta = _parse_duration(duration)
                    target = base + delta
                    return ToolResult(
                        tool_name=self.name, status="success",
                        output=f"{base.isoformat()} {duration} → {target.isoformat()}",
                        metadata={"result": target.isoformat()},
                    )
                return ToolResult(
                    tool_name=self.name, status="error",
                    error="delta mode needs either 'until' or 'duration'",
                )

            return ToolResult(
                tool_name=self.name, status="error",
                error=f"unknown mode {mode!r}; expected now/parse/format/delta",
            )
        except Exception as e:
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"{type(e).__name__}: {e}",
            )
