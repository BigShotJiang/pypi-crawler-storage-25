"""Speak — text-to-speech, returns a markdown audio link.

Uses Cognos's existing Kokoro TTS backend (`voice/tts.py`). The
synthesized audio is saved to FileStore so the chat UI can play it
back via the `/files/{id}/content` endpoint, just like images.

Returns a `markdown` field with `[🔊 alt](url)` that the LLM should
echo verbatim in its reply — Open WebUI renders the link as a
playable audio control.
"""

from __future__ import annotations

import logging
import os
import tempfile
import wave
from typing import Any

from core.schemas import ToolResult
from execution.tools.base import BaseTool

logger = logging.getLogger(__name__)


def _public_base_url() -> str:
    return os.environ.get("COGNOS_PUBLIC_URL", "http://127.0.0.1:8000").rstrip("/")


class SpeakTool(BaseTool):
    mutates = True
    name = "Speak"
    description = (
        "Synthesize text into speech via Kokoro TTS, save the audio "
        "to FileStore, and return a markdown audio link the chat UI "
        "can play. Use when the user asks you to read something aloud, "
        "produce a voice clip, or generate a TTS preview. Returns a "
        "`markdown` field — paste it VERBATIM into your reply."
    )

    def __init__(self, file_store: Any | None = None):
        self._file_store = file_store
        self._tts: Any | None = None

    def set_file_store(self, file_store: Any) -> None:
        self._file_store = file_store

    def _get_tts(self):
        if self._tts is None:
            from voice.tts import make_tts
            self._tts = make_tts(name="kokoro")
        return self._tts

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "text": {
                    "type": "string",
                    "description": "What to speak. Keep under ~500 chars for fast synthesis.",
                },
                "title": {
                    "type": "string",
                    "description": "Optional short label (used as audio link text).",
                },
            },
            "required": ["text"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        text = (kwargs.get("text") or "").strip()
        title = (kwargs.get("title") or "Audio clip").strip()
        if not text:
            return ToolResult(
                tool_name=self.name, status="error",
                error="empty text",
            )
        if self._file_store is None:
            return ToolResult(
                tool_name=self.name, status="error",
                error="Speak tool not wired to a FileStore",
            )

        try:
            tts = self._get_tts()
            audio, sr = tts.synthesize(text)
        except Exception as e:
            logger.exception("Speak: synthesis failed")
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"synthesis failed: {e}",
            )

        # Persist as 16-bit PCM WAV
        try:
            with tempfile.NamedTemporaryFile(
                "wb", suffix=".wav", delete=False
            ) as tmp:
                tmp_path = tmp.name
            with wave.open(tmp_path, "wb") as wav:
                wav.setnchannels(1)
                wav.setsampwidth(2)
                wav.setframerate(int(sr))
                wav.writeframes(audio.tobytes())
            safe_title = "".join(
                c if c.isalnum() or c in "-_" else "_" for c in title
            )[:40] or "speech"
            stored_name = f"{safe_title}.wav"
            record = self._file_store.upload(tmp_path, filename=stored_name)
        except Exception as e:
            logger.exception("Speak: persist failed")
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"persist failed: {e}",
            )

        url = f"{_public_base_url()}/files/{record.id}/content"
        markdown = f"[🔊 {title}]({url})"
        return ToolResult(
            tool_name=self.name, status="success",
            output=(
                f"Speech synthesized.\n"
                f"  text:     {text[:80]}{'...' if len(text) > 80 else ''}\n"
                f"  duration: ~{len(audio) / int(sr):.1f}s\n"
                f"  url:      {url}\n\n"
                f"Paste in your reply VERBATIM:\n"
                f"  {markdown}"
            ),
            metadata={
                "file_id": record.id, "url": url, "markdown": markdown,
                "duration_s": len(audio) / int(sr),
            },
        )
