"""Artifact — create an interactive content pane (HTML / SVG / markdown / code).

The LLM uses this when it wants to produce a substantive piece of
content the user should view as a *thing* rather than as inline chat
text. Examples: a small standalone web page, a flowchart SVG, a
multi-paragraph design doc, a self-contained Python module.

How it shows up in the UI:
  - The tool saves content to FileStore with the right MIME type
  - Returns a `markdown` field with a link the LLM pastes verbatim
  - Open WebUI / chat UI renders the link inline:
      * HTML / SVG / images  → opens in a new tab on click
      * Markdown / text      → preview shown by the chat client
      * Code                 → can be downloaded or viewed raw

This is the substrate for "artifact panes." The full Anthropic-style
side-pane experience requires UI work in the chat client; what we
ship here is the server side: a clean, addressable URL per artifact
and a generated markdown link the LLM can echo. The chat client
decides how to render it.
"""

from __future__ import annotations

import logging
import os
import tempfile
from typing import Any

from core.schemas import ToolResult
from execution.tools.base import BaseTool

logger = logging.getLogger(__name__)


# Map artifact kind → file suffix (drives MIME via mimetypes.guess_type)
_KIND_SUFFIX: dict[str, str] = {
    "html":     ".html",
    "svg":      ".svg",
    "markdown": ".md",
    "md":       ".md",
    "json":     ".json",
    "css":      ".css",
    "js":       ".js",
    "javascript": ".js",
    "python":   ".py",
    "py":       ".py",
    "yaml":     ".yaml",
    "yml":      ".yaml",
    "xml":      ".xml",
    "txt":      ".txt",
    "text":     ".txt",
}

# Kinds the chat UI tends to render inline as a preview vs. open in
# a new tab. Used to choose the right markdown shape: image-syntax
# `![alt](url)` for inline-renderables, link-syntax `[alt](url)` for
# new-tab-on-click ones.
_INLINE_RENDER = frozenset({"svg"})


def _public_base_url() -> str:
    return os.environ.get("COGNOS_PUBLIC_URL", "http://127.0.0.1:8000").rstrip("/")


class ArtifactTool(BaseTool):
    mutates = True
    name = "Artifact"
    description = (
        "Create a substantive piece of content the user should view "
        "as an artifact (a standalone HTML page, SVG diagram, design "
        "doc, code module, etc.) rather than as inline chat text. "
        "Returns a `markdown` field — paste it VERBATIM into your "
        "reply, the chat UI renders it as a link/preview. "
        "Use this when:\n"
        "  - The output is >30 lines AND meaningful as a unit\n"
        "  - The user asks to see something visually (SVG, web page)\n"
        "  - The output should be saveable / downloadable\n"
        "Don't use it for short answers, short code snippets, or "
        "chat-flow text — those go in your reply directly."
    )

    def __init__(self, file_store: Any | None = None):
        self._file_store = file_store

    def set_file_store(self, file_store: Any) -> None:
        self._file_store = file_store

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "kind": {
                    "type": "string",
                    "enum": list(_KIND_SUFFIX.keys()),
                    "description": "Content type — drives the MIME type and how the UI renders it.",
                },
                "content": {
                    "type": "string",
                    "description": "The artifact body (HTML, SVG, markdown, code, etc.).",
                },
                "title": {
                    "type": "string",
                    "description": "Short title used as the link label and stored filename.",
                },
            },
            "required": ["kind", "content"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        kind = (kwargs.get("kind") or "").lower().strip()
        content = kwargs.get("content") or ""
        title = (kwargs.get("title") or "artifact").strip()

        if kind not in _KIND_SUFFIX:
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"unknown kind {kind!r}. supported: "
                      f"{sorted(_KIND_SUFFIX.keys())}",
            )
        if not content.strip():
            return ToolResult(
                tool_name=self.name, status="error",
                error="content is empty",
            )
        if self._file_store is None:
            return ToolResult(
                tool_name=self.name, status="error",
                error="Artifact tool not wired to a FileStore",
            )

        suffix = _KIND_SUFFIX[kind]

        # Write content to a tempfile with the right suffix, hand to
        # FileStore (same pattern Draw uses).
        try:
            with tempfile.NamedTemporaryFile(
                "w", suffix=suffix, delete=False
            ) as tmp:
                tmp.write(content)
                tmp_path = tmp.name
            # Friendly stored filename — title + suffix, sanitised
            safe_title = "".join(
                c if c.isalnum() or c in "-_." else "_" for c in title
            )[:60] or "artifact"
            stored_name = f"{safe_title}{suffix}"
            record = self._file_store.upload(tmp_path, filename=stored_name)
        except Exception as e:
            logger.exception("Artifact tool failed")
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"failed to store artifact: {e}",
            )

        # The /artifact/{id} route is the polished viewer (Phase 1 of
        # COGNOS_UI_ROADMAP.md) — HTML preview / source toggle /
        # download. Use it for the user-facing link. The raw-bytes
        # /files/{id}/content URL stays available for inline-image
        # rendering when the chat UI needs the binary directly.
        viewer_url = f"{_public_base_url()}/artifact/{record.id}"
        raw_url = f"{_public_base_url()}/files/{record.id}/content"
        if kind in _INLINE_RENDER:
            # Inline-renderables (SVG) use the raw URL so the image
            # shows directly in chat. Add a viewer link below for
            # source/download access.
            markdown = f"![{title}]({raw_url})\n\n[📄 Open in viewer]({viewer_url})"
        else:
            markdown = f"[📄 {title}]({viewer_url})"
        url = viewer_url   # what the metadata reports as the primary URL

        return ToolResult(
            tool_name=self.name, status="success",
            output=(
                f"Artifact created.\n"
                f"  kind:     {kind}\n"
                f"  filename: {record.filename}\n"
                f"  size:     {record.size_bytes} bytes\n"
                f"  url:      {url}\n\n"
                f"Paste the markdown into your reply VERBATIM:\n"
                f"  {markdown}"
            ),
            metadata={
                "file_id": record.id,
                "filename": record.filename,
                "url": url,
                "markdown": markdown,
                "kind": kind,
                "size_bytes": record.size_bytes,
            },
        )
