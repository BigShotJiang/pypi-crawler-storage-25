"""Edit tool — surgical string replacement in a file.

Two modes:

  - **Normal:** `old_string` → `new_string`, single or all occurrences.

  - **FIM gap-fill:** when `new_string` contains the literal marker
    `<|FIM|>`, the tool splits `new_string` on the marker, calls the
    project's FIM model with the surrounding file context, and fills
    the gap before applying the replacement. Lets the agent write
    half a function and let a code-model fill the body without
    re-emitting the whole edit.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from core.schemas import ToolResult
from execution.tools.base import BaseTool


FIM_MARKER = "<|FIM|>"


class EditTool(BaseTool):
    mutates = True
    name = "Edit"
    description = (
        "Replace an exact string in a file with a new string. The old_string "
        "must appear EXACTLY once in the file unless replace_all is true. "
        "Preserves all surrounding content.\n\n"
        f"FIM mode: include the literal marker `{FIM_MARKER}` once in "
        "new_string to have a code-model fill that gap using the "
        "surrounding file context. Pass `fim_model` to override the "
        "default (qwen2.5-coder:1.5b)."
    )

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path to the file to edit",
                },
                "old_string": {
                    "type": "string",
                    "description": "Exact text to replace",
                },
                "new_string": {
                    "type": "string",
                    "description": (
                        "Replacement text (must differ from old_string). "
                        f"Include `{FIM_MARKER}` once to trigger FIM gap-fill."
                    ),
                },
                "replace_all": {
                    "type": "boolean",
                    "description": "If true, replace every occurrence. Default false.",
                    "default": False,
                },
                "fim_model": {
                    "type": "string",
                    "description": (
                        "Override FIM model id (e.g. ollama/qwen3-coder-next:q4_K_M). "
                        "Only used when new_string contains the FIM marker."
                    ),
                },
                "fim_max_tokens": {
                    "type": "integer",
                    "description": "Max tokens for the FIM completion (default 128).",
                },
            },
            "required": ["path", "old_string", "new_string"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        path = kwargs.get("path", "")
        old = kwargs.get("old_string", "")
        new = kwargs.get("new_string", "")
        replace_all = kwargs.get("replace_all", False)
        try:
            from execution.tools.file_tool import _violates_workspace
            ws_reason = _violates_workspace(path)
            if ws_reason is not None:
                return self._error(ws_reason)
        except Exception:
            pass
        fim_model = kwargs.get("fim_model")
        fim_max_tokens = kwargs.get("fim_max_tokens")

        if not path:
            return self._error("No path provided")
        if not old:
            return self._error("old_string cannot be empty")

        try:
            p = Path(path)
            content = p.read_text()
        except FileNotFoundError:
            return self._error(f"File not found: {path}")
        except Exception as e:
            return self._error(str(e))

        count = content.count(old)
        if count == 0:
            return self._error(f"old_string not found in {path}")
        if count > 1 and not replace_all:
            return self._error(
                f"old_string matches {count} places in {path}; "
                "set replace_all=true or provide a more specific string"
            )

        # FIM gap-fill mode: marker in new_string → call code-model
        # with the surrounding file context, splice the result in.
        # Only one marker supported per call; replace_all+FIM is
        # rejected because filling the same gap N times would loop the
        # same completion into every spot.
        fim_used = False
        if FIM_MARKER in new:
            if new.count(FIM_MARKER) > 1:
                return self._error(
                    f"new_string contains {new.count(FIM_MARKER)} FIM "
                    "markers; only one is supported per call"
                )
            if replace_all:
                return self._error(
                    "replace_all=true is incompatible with FIM gap-fill"
                )
            local_prefix, local_suffix = new.split(FIM_MARKER, 1)
            # Locate the first occurrence in the file (we've verified count >= 1).
            idx = content.find(old)
            file_before = content[:idx]
            file_after = content[idx + len(old):]
            fim_prefix = file_before + local_prefix
            fim_suffix = local_suffix + file_after
            try:
                from llm.provider import fim_complete, DEFAULT_FIM_MODEL
                gap = await fim_complete(
                    prefix=fim_prefix,
                    suffix=fim_suffix,
                    model=fim_model or DEFAULT_FIM_MODEL,
                    max_tokens=fim_max_tokens,
                )
            except ValueError as e:
                return self._error(f"FIM model rejected: {e}")
            except Exception as e:
                return self._error(f"FIM call failed: {e}")
            if old == local_prefix + gap + local_suffix:
                return self._error(
                    "FIM produced text identical to old_string — nothing to change"
                )
            new = local_prefix + gap + local_suffix
            fim_used = True

        if old == new:
            return self._error("old_string and new_string are identical")

        new_content = content.replace(old, new) if replace_all else content.replace(old, new, 1)

        try:
            p.write_text(new_content)
        except Exception as e:
            return self._error(str(e))

        n = count if replace_all else 1
        msg = f"Replaced {n} occurrence(s) in {path}"
        if fim_used:
            msg += " (FIM gap-fill)"
        return self._success(msg)


class FillInMiddleTool(BaseTool):
    """Standalone FIM tool — routable target for Caudate's tool head.

    Edit already supports FIM via the marker mode, but exposing FIM as
    its own named tool lets Caudate's contrastive head learn to route
    to it directly (e.g. for cases where the agent just wants the
    completion string without applying an edit). Read-only: returns
    the generated text, doesn't touch the filesystem.
    """

    mutates = False
    name = "FillInMiddle"
    description = (
        "Generate the text that should fill the gap between `prefix` "
        "and `suffix` using a FIM-trained code model. Returns the "
        "completion string only — does not write to any file. Use for "
        "code-completion lookups, structural gap-fills, or when you "
        "want to inspect the model's suggestion before applying it. "
        "Default model: qwen2.5-coder:1.5b (low-latency); override "
        "with `model` for heavier completions."
    )

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "prefix": {
                    "type": "string",
                    "description": "Text before the gap.",
                },
                "suffix": {
                    "type": "string",
                    "description": "Text after the gap.",
                    "default": "",
                },
                "model": {
                    "type": "string",
                    "description": (
                        "Override model id (e.g. ollama/qwen3-coder-next:q4_K_M). "
                        "Must be a FIM-trained code model on Ollama."
                    ),
                },
                "max_tokens": {
                    "type": "integer",
                    "description": "Max tokens for the completion (default 128).",
                },
                "temperature": {
                    "type": "number",
                    "description": "Sampling temperature (default 0.1).",
                },
            },
            "required": ["prefix"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        prefix = kwargs.get("prefix", "")
        if not prefix:
            return self._error("prefix is required")
        suffix = kwargs.get("suffix", "")
        model = kwargs.get("model")
        max_tokens = kwargs.get("max_tokens")
        temperature = kwargs.get("temperature")
        try:
            from llm.provider import fim_complete, DEFAULT_FIM_MODEL
            completion = await fim_complete(
                prefix=prefix,
                suffix=suffix,
                model=model or DEFAULT_FIM_MODEL,
                max_tokens=max_tokens,
                temperature=temperature,
            )
        except ValueError as e:
            return self._error(str(e))
        except Exception as e:
            return self._error(f"FIM call failed: {e}")
        return self._success(completion)
