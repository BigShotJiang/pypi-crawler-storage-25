"""Forge feature-CRUD tools — let the agent manage its own backlog mid-run.

Ported from LocalForge's ``lib/agent/feature-crud-tools.ts``. Seven
tools (list / create / update / delete / add_dependency /
remove_dependency / set_dependencies) all scoped to whichever Forge
project the orchestrator has bound for this session.

Project binding uses a ``ContextVar`` set by ``planning/orchestrator.py``
before it calls ``agent.chat(prompt)``. Outside of a forge session the
context var is unset and the tools refuse — they have no business
running in a regular chat.
"""

from __future__ import annotations

import logging
from contextlib import contextmanager
from contextvars import ContextVar
from typing import Any, Iterator

from core.schemas import ToolResult
from execution.tools.base import BaseTool

logger = logging.getLogger(__name__)


_active_project: ContextVar[int | None] = ContextVar(
    "forge_active_project_id", default=None,
)


@contextmanager
def forge_project_scope(project_id: int) -> Iterator[None]:
    """Bind ``project_id`` for any Forge tool calls inside the block."""
    token = _active_project.set(project_id)
    try:
        yield
    finally:
        _active_project.reset(token)


def _current_project_id() -> int | None:
    return _active_project.get()


# ────────────────────────── Helpers ─────────────────────────────────


def _assert_in_project(feature_id: int, project_id: int) -> None:
    """Raise ValueError if feature does not belong to project."""
    from planning.forge_models import get_feature
    row = get_feature(feature_id)
    if row is None:
        raise ValueError(f"Feature {feature_id} not found")
    if row["project_id"] != project_id:
        raise ValueError(
            f"Feature {feature_id} belongs to a different project"
        )


def _no_project_error(tool_name: str) -> ToolResult:
    return ToolResult(
        tool_name=tool_name, status="error",
        error="no Forge project bound for this session — this tool is "
              "only callable when the orchestrator runs the agent on a "
              "feature.",
    )


# ────────────────────────── Tools ───────────────────────────────────


class ForgeListFeaturesTool(BaseTool):
    name = "forge_list_features"
    description = (
        "List every feature in this Forge project's backlog. Call this "
        "FIRST so you know which features already exist, what ids they "
        "have, and so you do not create duplicates."
    )
    mutates = False

    @property
    def input_schema(self) -> dict[str, Any]:
        return {"type": "object", "properties": {}, "required": []}

    async def execute(self, **_: Any) -> ToolResult:
        pid = _current_project_id()
        if pid is None:
            return _no_project_error(self.name)
        try:
            from planning.forge_models import list_features
            rows = list_features(pid)
        except Exception as e:
            return self._error(f"{type(e).__name__}: {e}")
        # Slim payload — agent doesn't need acceptance_criteria etc here
        slim = [
            {
                "id": r["id"],
                "title": r["title"],
                "description": r["description"],
                "category": r["category"],
                "status": r["status"],
                "priority": r["priority"],
                "depends_on": r.get("depends_on", []),
            }
            for r in rows
        ]
        return self._success(slim)


class ForgeCreateFeatureTool(BaseTool):
    name = "forge_create_feature"
    description = (
        "Create a new feature in this Forge project. Returns the new id; "
        "use it with forge_add_dependency / forge_set_dependencies to wire "
        "prerequisites."
    )
    mutates = True

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "title": {
                    "type": "string", "minLength": 1, "maxLength": 200,
                    "description": "Short imperative title.",
                },
                "description": {
                    "type": "string",
                    "description": "What done looks like for this feature.",
                },
                "acceptance_criteria": {
                    "type": "string",
                    "description": "Bullet list of testable conditions.",
                },
                "category": {
                    "type": "string", "enum": ["functional", "style"],
                    "default": "functional",
                },
                "priority": {"type": "integer", "default": 0},
                "verify_command": {"type": "string"},
                "depends_on": {
                    "type": "array", "items": {"type": "integer"},
                    "description": "Optional ids of prerequisites.",
                },
            },
            "required": ["title"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        pid = _current_project_id()
        if pid is None:
            return _no_project_error(self.name)
        try:
            from planning.forge_models import (
                create_feature, add_dependency, get_feature,
            )
            fid = create_feature(
                project_id=pid,
                title=kwargs["title"],
                description=kwargs.get("description"),
                acceptance_criteria=kwargs.get("acceptance_criteria"),
                priority=int(kwargs.get("priority", 0)),
                category=kwargs.get("category", "functional"),
                verify_command=kwargs.get("verify_command"),
            )
            linked: list[int] = []
            skipped: list[dict[str, Any]] = []
            for dep in (kwargs.get("depends_on") or []):
                try:
                    _assert_in_project(int(dep), pid)
                    add_dependency(fid, int(dep))
                    linked.append(int(dep))
                except Exception as e:
                    skipped.append({"id": int(dep), "reason": str(e)})
            row = get_feature(fid) or {}
            return self._success({
                "id": fid,
                "title": row.get("title"),
                "linked_dependencies": linked,
                "skipped_dependencies": skipped,
            })
        except Exception as e:
            return self._error(f"{type(e).__name__}: {e}")


class ForgeUpdateFeatureTool(BaseTool):
    name = "forge_update_feature"
    description = (
        "Edit fields of an existing feature in this project. Pass only the "
        "fields you want to change."
    )
    mutates = True

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "id": {"type": "integer", "minimum": 1},
                "title": {"type": "string", "minLength": 1, "maxLength": 200},
                "description": {"type": "string"},
                "acceptance_criteria": {"type": "string"},
                "category": {"type": "string", "enum": ["functional", "style"]},
                "priority": {
                    "type": "integer",
                    "description": "Lower = higher up in backlog. 0 = top.",
                },
                "verify_command": {"type": "string"},
            },
            "required": ["id"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        pid = _current_project_id()
        if pid is None:
            return _no_project_error(self.name)
        try:
            fid = int(kwargs.pop("id"))
            _assert_in_project(fid, pid)
            from planning.forge_models import update_feature
            row = update_feature(fid, **kwargs)
            if row is None:
                return self._error(f"Feature {fid} not found.")
            return self._success({
                "id": row["id"], "title": row["title"],
                "priority": row["priority"], "category": row["category"],
                "status": row["status"],
            })
        except Exception as e:
            return self._error(f"{type(e).__name__}: {e}")


class ForgeDeleteFeatureTool(BaseTool):
    name = "forge_delete_feature"
    description = "Remove a feature from this project's backlog."
    mutates = True

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {"id": {"type": "integer", "minimum": 1}},
            "required": ["id"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        pid = _current_project_id()
        if pid is None:
            return _no_project_error(self.name)
        try:
            fid = int(kwargs["id"])
            _assert_in_project(fid, pid)
            from planning.forge_models import delete_feature
            ok = delete_feature(fid)
            return self._success(f"Deleted feature {fid}." if ok
                                 else f"Feature {fid} not found.")
        except Exception as e:
            return self._error(f"{type(e).__name__}: {e}")


class ForgeAddDependencyTool(BaseTool):
    name = "forge_add_dependency"
    description = (
        "Declare that one feature depends on another. Both must belong "
        "to this project. Rejected if it would create a cycle."
    )
    mutates = True

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "feature_id": {"type": "integer", "minimum": 1},
                "depends_on_feature_id": {"type": "integer", "minimum": 1},
            },
            "required": ["feature_id", "depends_on_feature_id"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        pid = _current_project_id()
        if pid is None:
            return _no_project_error(self.name)
        try:
            fid = int(kwargs["feature_id"])
            did = int(kwargs["depends_on_feature_id"])
            _assert_in_project(fid, pid)
            _assert_in_project(did, pid)
            from planning.forge_models import add_dependency
            add_dependency(fid, did)
            return self._success(f"Feature {fid} now depends on {did}.")
        except Exception as e:
            return self._error(f"{type(e).__name__}: {e}")


class ForgeRemoveDependencyTool(BaseTool):
    name = "forge_remove_dependency"
    description = "Remove a dependency edge between two features."
    mutates = True

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "feature_id": {"type": "integer", "minimum": 1},
                "depends_on_feature_id": {"type": "integer", "minimum": 1},
            },
            "required": ["feature_id", "depends_on_feature_id"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        pid = _current_project_id()
        if pid is None:
            return _no_project_error(self.name)
        try:
            fid = int(kwargs["feature_id"])
            did = int(kwargs["depends_on_feature_id"])
            _assert_in_project(fid, pid)
            from planning.forge_models import remove_dependency
            ok = remove_dependency(fid, did)
            return self._success(
                f"Removed {fid} -> {did}." if ok else "No such dependency."
            )
        except Exception as e:
            return self._error(f"{type(e).__name__}: {e}")


class ForgeSetDependenciesTool(BaseTool):
    name = "forge_set_dependencies"
    description = (
        "Replace the full dependency list for a feature in one call. "
        "Pass depends_on=[] to clear all dependencies."
    )
    mutates = True

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "feature_id": {"type": "integer", "minimum": 1},
                "depends_on": {
                    "type": "array", "items": {"type": "integer"},
                },
            },
            "required": ["feature_id", "depends_on"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        pid = _current_project_id()
        if pid is None:
            return _no_project_error(self.name)
        try:
            fid = int(kwargs["feature_id"])
            deps = [int(x) for x in (kwargs.get("depends_on") or [])]
            _assert_in_project(fid, pid)
            for d in deps:
                _assert_in_project(d, pid)
            from planning.forge_models import set_dependencies
            out = set_dependencies(fid, deps)
            return self._success(out)
        except Exception as e:
            return self._error(f"{type(e).__name__}: {e}")


FORGE_FEATURE_TOOLS: list[type[BaseTool]] = [
    ForgeListFeaturesTool,
    ForgeCreateFeatureTool,
    ForgeUpdateFeatureTool,
    ForgeDeleteFeatureTool,
    ForgeAddDependencyTool,
    ForgeRemoveDependencyTool,
    ForgeSetDependenciesTool,
]
