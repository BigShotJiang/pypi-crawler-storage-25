"""Calculator — exact arithmetic and symbolic math.

LLMs hallucinate digits past ~10-digit precision and get basic
multi-step arithmetic wrong surprisingly often. This tool does the
computation deterministically using Python's expression evaluator,
then optionally falls through to `sympy` for symbolic ops if the
expression contains symbolic markers.

Safety: uses a strict allowlist of names + AST validation. No
imports, no attribute access, no comprehensions, no function calls
except a curated math whitelist. Untrusted expressions can't escape
the sandbox.
"""

from __future__ import annotations

import ast
import logging
import math
from typing import Any

from core.schemas import ToolResult
from execution.tools.base import BaseTool

logger = logging.getLogger(__name__)


# Allowed top-level names — math constants and a curated set of
# functions. Anything not in this dict raises NameError.
_ALLOWED_NAMES: dict[str, Any] = {
    # constants
    "pi": math.pi, "e": math.e, "tau": math.tau, "inf": math.inf,
    # safe scalar functions
    "abs": abs, "round": round, "min": min, "max": max,
    "sum": sum, "pow": pow,
    # math module
    "sqrt": math.sqrt, "log": math.log, "log2": math.log2,
    "log10": math.log10, "exp": math.exp,
    "sin": math.sin, "cos": math.cos, "tan": math.tan,
    "asin": math.asin, "acos": math.acos, "atan": math.atan, "atan2": math.atan2,
    "sinh": math.sinh, "cosh": math.cosh, "tanh": math.tanh,
    "ceil": math.ceil, "floor": math.floor, "trunc": math.trunc,
    "factorial": math.factorial, "gcd": math.gcd, "lcm": math.lcm,
    "degrees": math.degrees, "radians": math.radians,
    "hypot": math.hypot, "fabs": math.fabs,
    "fmod": math.fmod, "modf": math.modf,
    "isclose": math.isclose, "isfinite": math.isfinite, "isnan": math.isnan,
}


# AST node types that are NOT allowed in the expression. We allow
# arithmetic, comparisons, conditionals, name lookups (gated by the
# allowlist above), and function calls (also gated).
_FORBIDDEN_NODES = (
    ast.Import, ast.ImportFrom,
    ast.Lambda, ast.FunctionDef, ast.ClassDef,
    ast.Attribute,                    # no x.y access — blocks os.system etc
    ast.Subscript,                    # no list/dict subscripting
    ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp,
    ast.Yield, ast.YieldFrom,
    ast.Await,
    ast.Assign, ast.AugAssign, ast.AnnAssign,
    ast.Delete,
    ast.Global, ast.Nonlocal,
    ast.Try,
    ast.With, ast.AsyncWith, ast.AsyncFor, ast.AsyncFunctionDef,
)


def _validate_ast(tree: ast.AST) -> None:
    """Raise ValueError if tree contains forbidden nodes."""
    for node in ast.walk(tree):
        if isinstance(node, _FORBIDDEN_NODES):
            raise ValueError(
                f"forbidden expression element: {type(node).__name__}"
            )
        # Function calls must use names from the allowlist
        if isinstance(node, ast.Call):
            func = node.func
            if not isinstance(func, ast.Name):
                raise ValueError("function calls must be on bare names")
            if func.id not in _ALLOWED_NAMES:
                raise ValueError(f"function not allowed: {func.id}")


def _eval_safe(expr: str) -> Any:
    """Parse + validate + eval an arithmetic expression."""
    tree = ast.parse(expr, mode="eval")
    _validate_ast(tree)
    return eval(compile(tree, "<calculator>", "eval"),
                {"__builtins__": {}}, _ALLOWED_NAMES)


class CalculatorTool(BaseTool):
    name = "Calculator"
    description = (
        "Evaluate an arithmetic or scalar-math expression exactly. "
        "Use this whenever the user asks for arithmetic, percentages, "
        "unit conversions, or anything where digits past ~10 places "
        "matter. Supports +, -, *, /, **, math constants (pi, e), and "
        "common math functions (sqrt, log, sin, cos, factorial, etc.). "
        "No variables, no imports — pure expressions."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "expression": {
                    "type": "string",
                    "description": "Expression to evaluate, e.g. "
                                   "'2 ** 32 - 1' or 'sqrt(2) * 5'.",
                },
            },
            "required": ["expression"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        expr = (kwargs.get("expression") or "").strip()
        if not expr:
            return ToolResult(
                tool_name=self.name, status="error",
                error="empty expression",
            )
        try:
            result = _eval_safe(expr)
        except Exception as e:
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"{type(e).__name__}: {e}",
            )
        return ToolResult(
            tool_name=self.name, status="success",
            output=f"{expr} = {result}",
            metadata={"expression": expr, "result": result},
        )
