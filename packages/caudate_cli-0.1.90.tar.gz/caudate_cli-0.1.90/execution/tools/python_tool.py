"""Python execution tool — run Python code in a subprocess."""

from __future__ import annotations

import asyncio
import tempfile
from pathlib import Path
from typing import Any

from core.schemas import ToolResult
from execution.tools.base import BaseTool


class PythonExecTool(BaseTool):
    mutates = True
    name = "PythonExec"
    description = "Execute Python code in an isolated subprocess and return stdout. Use for calculations, data processing, or testing code snippets."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "code": {
                    "type": "string",
                    "description": "Python code to execute",
                },
            },
            "required": ["code"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        code = kwargs.get("code", "")
        if not code:
            return self._error("No code provided")

        # Write to temp file and execute in subprocess for isolation
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
            f.write(code)
            tmp_path = f.name

        try:
            proc = await asyncio.create_subprocess_exec(
                "python3", tmp_path,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=30)
            output = stdout.decode().strip()
            errors = stderr.decode().strip()

            if proc.returncode == 0:
                return self._success(output or "(no output)")
            else:
                return self._error(f"Exit code {proc.returncode}: {errors}")
        except asyncio.TimeoutError:
            return self._error("Execution timed out after 30s")
        except Exception as e:
            return self._error(str(e))
        finally:
            Path(tmp_path).unlink(missing_ok=True)
