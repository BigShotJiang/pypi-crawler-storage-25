"""Cron tools — schedule, list, and delete recurring agent prompts.

Three thin wrappers on top of `core/scheduler.py::CronStore`:

  - **`CronCreate`** — register a new recurring prompt.
  - **`CronList`**   — show all registered jobs (with status).
  - **`CronDelete`** — remove a job by id.

Schedule syntax (matching `core/scheduler.py::_parse_schedule`):

  - `every 30s` / `every 5m` / `every 2h` / `every 1d`
  - `daily HH:MM`                  (e.g. `daily 09:30`)
  - `weekly mon HH:MM`             (mon|tue|wed|thu|fri|sat|sun)
  - `at YYYY-MM-DD HH:MM`          (one-shot)

Persistence: jobs live in `data/cron.json`. The runtime fires them
when `cognos cron run` is active (a separate daemon process). These
tools just manage the registry — they don't fire anything immediately.
"""

from __future__ import annotations

from typing import Any

from core.schemas import ToolResult
from execution.tools.base import BaseTool


def _store():
    """Lazy-init the CronStore against the configured data dir."""
    from pathlib import Path
    from config import DATA_DIR
    from core.scheduler import CronStore
    return CronStore(Path(DATA_DIR) / "cron.json")


def _format_job(job) -> str:
    status = "enabled " if job.enabled else "disabled"
    nxt = job.next_run or "—"
    last = job.last_run or "never"
    return (
        f"  {job.id}  [{status}]  schedule={job.schedule!r}\n"
        f"    next:   {nxt}\n"
        f"    last:   {last}\n"
        f"    prompt: {job.prompt[:80]}{'…' if len(job.prompt) > 80 else ''}"
    )


class CronCreateTool(BaseTool):
    mutates = True
    name = "CronCreate"
    description = (
        "Schedule a recurring prompt that Cognos will run automatically "
        "when the cron daemon is active. Pass a `prompt` (what the agent "
        "should do each fire) and a `schedule` string. Schedule syntax: "
        "`every 30s|5m|2h|1d`, `daily HH:MM`, `weekly mon HH:MM`, or "
        "`at YYYY-MM-DD HH:MM` for one-shot. Returns the new job id. "
        "Note: the daemon runs separately via `cognos cron run`; this "
        "tool only registers the job."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "prompt": {
                    "type": "string",
                    "description": "What the agent should do each fire (e.g. 'Summarize today's storyboard runs').",
                },
                "schedule": {
                    "type": "string",
                    "description": (
                        "When to fire. Examples: 'every 5m', 'daily "
                        "09:30', 'weekly mon 09:00', 'at 2026-12-25 08:00'."
                    ),
                },
            },
            "required": ["prompt", "schedule"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        prompt = (kwargs.get("prompt") or "").strip()
        schedule = (kwargs.get("schedule") or "").strip()
        if not prompt or not schedule:
            return ToolResult(
                tool_name=self.name, status="error",
                error="`prompt` and `schedule` are both required",
            )
        try:
            store = _store()
            job = store.add(prompt, schedule)
        except ValueError as e:
            return ToolResult(
                tool_name=self.name, status="error",
                error=(
                    f"{e}. Valid schedules: 'every 5m', 'daily 09:30', "
                    "'weekly mon 09:00', 'at YYYY-MM-DD HH:MM'."
                ),
            )
        except Exception as e:
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"failed to create cron job: {e}",
            )
        return ToolResult(
            tool_name=self.name, status="success",
            output=(
                f"Cron job created.\n"
                f"  id:        {job.id}\n"
                f"  schedule:  {job.schedule}\n"
                f"  next run:  {job.next_run}\n"
                f"  prompt:    {job.prompt[:100]}"
            ),
            metadata={
                "job_id": job.id,
                "schedule": job.schedule,
                "next_run": job.next_run,
            },
        )


class CronListTool(BaseTool):
    name = "CronList"
    description = (
        "List all registered cron jobs with their schedule, next run "
        "time, last run time, and the prompt. No arguments. Returns a "
        "human-readable list; the metadata field has the structured "
        "version."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {"type": "object", "properties": {}}

    async def execute(self, **_: Any) -> ToolResult:
        try:
            jobs = _store().list()
        except Exception as e:
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"failed to read cron store: {e}",
            )
        if not jobs:
            return ToolResult(
                tool_name=self.name, status="success",
                output="No cron jobs registered.",
                metadata={"jobs": []},
            )
        lines = [f"{len(jobs)} cron job(s):", ""]
        lines.extend(_format_job(j) for j in jobs)
        return ToolResult(
            tool_name=self.name, status="success",
            output="\n".join(lines),
            metadata={
                "jobs": [
                    {
                        "id":       j.id,
                        "schedule": j.schedule,
                        "enabled":  j.enabled,
                        "next_run": j.next_run,
                        "last_run": j.last_run,
                        "prompt":   j.prompt,
                    }
                    for j in jobs
                ],
            },
        )


class CronDeleteTool(BaseTool):
    mutates = True
    name = "CronDelete"
    description = (
        "Delete a cron job by its id. Use `CronList` first to find the "
        "id. Returns success or 'not found'."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "job_id": {
                    "type": "string",
                    "description": "Cron job id from CronList.",
                },
            },
            "required": ["job_id"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        job_id = (kwargs.get("job_id") or "").strip()
        if not job_id:
            return ToolResult(
                tool_name=self.name, status="error",
                error="`job_id` is required",
            )
        try:
            ok = _store().remove(job_id)
        except Exception as e:
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"failed to delete cron job: {e}",
            )
        if not ok:
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"no cron job with id {job_id!r}",
            )
        return ToolResult(
            tool_name=self.name, status="success",
            output=f"Deleted cron job {job_id}.",
            metadata={"job_id": job_id},
        )
