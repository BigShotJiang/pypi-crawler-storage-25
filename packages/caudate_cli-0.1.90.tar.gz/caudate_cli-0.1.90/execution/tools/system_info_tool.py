"""SystemInfo — one-call summary of host hardware + software state.

Saves the LLM from chaining Bash calls (`uname`, `nvidia-smi`, `df`,
`free`, …) just to answer "what hardware do you have?". Intentionally
read-only; everything is via well-known commands.

The output is a structured text block that's easy for the LLM to
quote back to the user verbatim or summarise. Sections that are
unavailable (e.g. no NVIDIA GPU) are simply omitted.
"""

from __future__ import annotations

import asyncio
import os
import platform
import shutil
import subprocess
from typing import Any

from core.schemas import ToolResult
from execution.tools.base import BaseTool


_SECTION_TIMEOUT_S = 5   # per subprocess; SystemInfo isn't worth blocking on


def _run(cmd: list[str]) -> str:
    """Run a command and return stdout (or empty on failure)."""
    try:
        out = subprocess.run(
            cmd, capture_output=True, text=True,
            timeout=_SECTION_TIMEOUT_S,
        )
        return (out.stdout or out.stderr or "").strip()
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return ""


def _section_kernel() -> str:
    bits = []
    bits.append(f"OS:           {platform.system()} {platform.release()}")
    if platform.system() == "Linux":
        # Distro name from /etc/os-release
        os_release = ""
        try:
            with open("/etc/os-release") as f:
                kv = dict(
                    line.strip().split("=", 1)
                    for line in f if "=" in line
                )
            os_release = kv.get("PRETTY_NAME", "").strip('"')
        except OSError:
            pass
        if os_release:
            bits.append(f"Distribution: {os_release}")
    bits.append(f"Architecture: {platform.machine()}")
    bits.append(f"Hostname:     {platform.node()}")
    return "\n".join(bits)


def _section_cpu_ram() -> str:
    bits = []
    cpu_count = os.cpu_count() or 0
    bits.append(f"CPUs:         {cpu_count} logical")
    # CPU model from /proc/cpuinfo on Linux
    try:
        with open("/proc/cpuinfo") as f:
            for line in f:
                if line.startswith("model name"):
                    bits.append(f"CPU model:    {line.split(':',1)[1].strip()}")
                    break
    except OSError:
        pass
    # Memory from /proc/meminfo
    try:
        mem = {}
        with open("/proc/meminfo") as f:
            for line in f:
                k, _, v = line.partition(":")
                mem[k.strip()] = v.strip()
        total_kb = int(mem.get("MemTotal", "0 kB").split()[0] or "0")
        avail_kb = int(mem.get("MemAvailable", "0 kB").split()[0] or "0")
        gb = lambda x: x / 1024 / 1024
        bits.append(
            f"Memory:       {gb(total_kb):.1f} GB total, "
            f"{gb(avail_kb):.1f} GB available"
        )
    except (OSError, ValueError):
        pass
    return "\n".join(bits)


def _section_gpu() -> str:
    if not shutil.which("nvidia-smi"):
        return "GPU:          (no nvidia-smi found)"
    raw = _run([
        "nvidia-smi",
        "--query-gpu=name,memory.total,memory.used,utilization.gpu,driver_version",
        "--format=csv,noheader,nounits",
    ])
    if not raw:
        return "GPU:          nvidia-smi present but no GPU info"
    lines = ["GPUs:"]
    for entry in raw.splitlines():
        parts = [p.strip() for p in entry.split(",")]
        if len(parts) < 5:
            continue
        name, mem_total, mem_used, util, driver = parts
        lines.append(
            f"  - {name}  ({mem_used}/{mem_total} MB used, "
            f"{util}% util, driver {driver})"
        )
    return "\n".join(lines)


def _section_disk() -> str:
    raw = _run(["df", "-h", "--output=source,size,used,avail,pcent,target"])
    if not raw:
        return ""
    lines = raw.splitlines()
    # Filter to interesting mounts: skip squashfs, snap, tmpfs, etc.
    keep = []
    header = lines[0] if lines else ""
    keep.append(header)
    for ln in lines[1:]:
        if any(k in ln for k in ("/snap/", "tmpfs", "udev", "squashfs", "overlay")):
            continue
        keep.append(ln)
    return "Disks:\n" + "\n".join(f"  {l}" for l in keep[:12])


def _section_python_cuda() -> str:
    bits = [f"Python:       {platform.python_version()}"]
    # PyTorch + CUDA detection — best-effort, doesn't fail if torch missing
    try:
        import torch
        bits.append(f"PyTorch:      {torch.__version__}")
        if torch.cuda.is_available():
            bits.append(
                f"CUDA:         {torch.version.cuda} "
                f"({torch.cuda.device_count()} device(s) visible to torch)"
            )
        else:
            bits.append("CUDA:         not available to torch")
    except Exception as e:
        bits.append(f"PyTorch:      not importable ({e!s:.60})")
    return "\n".join(bits)


def _section_uptime_load() -> str:
    bits = []
    try:
        with open("/proc/uptime") as f:
            up = float(f.read().split()[0])
        days, rem = divmod(up, 86400)
        hours, rem = divmod(rem, 3600)
        mins = rem // 60
        bits.append(
            f"Uptime:       {int(days)}d {int(hours)}h {int(mins)}m"
        )
    except OSError:
        pass
    try:
        with open("/proc/loadavg") as f:
            la = f.read().strip().split()[:3]
        bits.append(f"Load avg:     {' / '.join(la)} (1/5/15 min)")
    except OSError:
        pass
    return "\n".join(bits)


class SystemInfoTool(BaseTool):
    name = "SystemInfo"
    description = (
        "Read-only one-call summary of the host machine: OS, CPU, RAM, "
        "GPU (incl. NVIDIA), disk usage, Python/PyTorch/CUDA versions, "
        "uptime. Use this when the user asks about the hardware/software "
        "Cognos is running on, instead of chaining several Bash calls."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {"type": "object", "properties": {}, "required": []}

    async def execute(self, **_: Any) -> ToolResult:
        # Run sections in a thread so we don't block the event loop on
        # subprocesses (nvidia-smi can take a second or two).
        loop = asyncio.get_event_loop()
        sections = await loop.run_in_executor(None, self._collect_all)
        return ToolResult(
            tool_name=self.name, status="success", output=sections
        )

    @staticmethod
    def _collect_all() -> str:
        parts: list[str] = []
        for fn in (
            _section_kernel,
            _section_cpu_ram,
            _section_gpu,
            _section_disk,
            _section_python_cuda,
            _section_uptime_load,
        ):
            try:
                out = fn()
                if out:
                    parts.append(out)
            except Exception as e:
                parts.append(f"({fn.__name__} failed: {e!s:.80})")
        return "\n\n".join(parts)
