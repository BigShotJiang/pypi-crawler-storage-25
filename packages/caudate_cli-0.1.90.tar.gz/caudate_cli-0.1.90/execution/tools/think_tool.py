"""Think tool — use the LLM to reason, generate knowledge, or synthesize information."""

from __future__ import annotations

from typing import Any

from core.schemas import ToolResult
from execution.tools.base import BaseTool


class ThinkTool(BaseTool):
    name = "Think"
    description = "Use the LLM to reason about a topic, answer a question, or synthesize information. Use this for knowledge questions, analysis, explanations, and any task that requires thinking rather than external tools."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "question": {
                    "type": "string",
                    "description": "The question or topic to think about",
                },
            },
            "required": ["question"],
        }

    def __init__(self, llm=None):
        self._llm = llm

    def set_llm(self, llm) -> None:
        self._llm = llm

    async def execute(self, **kwargs: Any) -> ToolResult:
        question = kwargs.get("question", "")
        if not question:
            return self._error("No question provided")

        if not self._llm:
            return self._error("LLM not configured for think tool")

        try:
            response = await self._llm.complete(
                prompt=question,
                system="You are a knowledgeable assistant. Provide clear, accurate, and helpful responses. Be thorough but concise.",
            )
            return self._success(response.content)
        except Exception as e:
            return self._error(f"Thinking failed: {e}")
