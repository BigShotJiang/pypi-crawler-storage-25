"""UpdateMemory — write to the durable cross-session memory.md.

Three modes:
  - `append`  : add a new entry to the bottom of memory.md
  - `replace` : wholesale rewrite (use sparingly — destructive)
  - `read`    : return current contents (the LLM doesn't normally need
                this since memory.md is auto-injected into the system
                prompt every turn, but it's useful when the user asks
                "what do you remember?")

Caudate's `memory_write` head also writes to this file automatically
when she predicts a turn is memory-worthy (above threshold) — that
path goes through `nn/observer.py` and bypasses this tool. The tool
exists for *explicit* memory updates the LLM (or user) wants to make.
"""

from __future__ import annotations

from typing import Any

from core.memory_md import get_memory
from core.schemas import ToolResult
from execution.tools.base import BaseTool


class UpdateMemoryTool(BaseTool):
    mutates = True
    name = "UpdateMemory"
    description = (
        "Manage Cognos's durable cross-session memory file. "
        "Use this when the user says 'remember X', 'note that...', or "
        "you want to record an important fact for future sessions. "
        "Modes: 'append' (add a new entry), 'replace' (rewrite the whole "
        "file — destructive, only use when explicitly asked to clean up), "
        "'read' (return current contents). Memory is automatically "
        "injected into your system prompt every turn — you don't need to "
        "call 'read' to access it under normal flow."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "mode": {
                    "type": "string",
                    "enum": ["append", "replace", "read"],
                    "description": "What to do with memory.md.",
                },
                "content": {
                    "type": "string",
                    "description": "For 'append' or 'replace': the text to write.",
                },
                "title": {
                    "type": "string",
                    "description": "Optional short title for an 'append' entry.",
                },
            },
            "required": ["mode"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        mode = (kwargs.get("mode") or "").lower()
        memory = get_memory()
        if mode == "read":
            text = memory.read()
            return ToolResult(
                tool_name=self.name, status="success",
                output=text or "(memory.md is empty)",
            )
        content = (kwargs.get("content") or "").strip()
        if not content:
            return ToolResult(
                tool_name=self.name, status="error",
                error="content is required for append/replace mode",
            )
        if mode == "append":
            memory.append(content, source="explicit", title=kwargs.get("title", ""))
            return ToolResult(
                tool_name=self.name, status="success",
                output=f"Appended to memory.md ({len(content)} chars)",
            )
        if mode == "replace":
            memory.replace(content)
            return ToolResult(
                tool_name=self.name, status="success",
                output=f"Replaced memory.md ({len(content)} chars)",
            )
        return ToolResult(
            tool_name=self.name, status="error",
            error=f"unknown mode {mode!r}; expected append/replace/read",
        )
