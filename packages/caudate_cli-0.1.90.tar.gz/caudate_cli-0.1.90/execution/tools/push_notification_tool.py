"""PushNotification — desktop notification when a long job completes.

Sends an OS-level desktop notification so the user sees it even if
they've alt-tabbed away from the browser/terminal. Tries `notify-send`
on Linux first (which works under the user's XFCE/GNOME/KDE setup),
falls back to a terminal bell (BEL char) for headless sessions, and
returns a clear status either way.

Use cases:
  - Storyboard finished generating (15-40 min jobs)
  - Phase-N retrain completed
  - FLUX-Kontext panel rendered
  - Anything that takes long enough that the user's attention has
    drifted elsewhere

Not for chat-turn updates — those go in the response text directly.
"""

from __future__ import annotations

import asyncio
import shutil
import sys
from typing import Any

from core.schemas import ToolResult
from execution.tools.base import BaseTool


# Urgency mapping to notify-send levels. Same vocabulary FreeDesktop
# uses, exposed as plain string for clarity.
_URGENCY_MAP = {
    "low":      "low",
    "normal":   "normal",
    "high":     "critical",   # notify-send calls it "critical"
    "critical": "critical",
}


class PushNotificationTool(BaseTool):
    mutates = True
    name = "PushNotification"
    description = (
        "Send a desktop notification to the user. Useful when a "
        "long-running job (storyboard, FLUX edit, retrain) finishes "
        "and the user has switched away from the chat. Provide a "
        "short `title` and optional `message` + `urgency` "
        "(`low` / `normal` / `high`). Uses `notify-send` on Linux; "
        "falls back to a terminal bell if no notification daemon is "
        "available. Don't spam — one notification per completed job."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "title": {
                    "type": "string",
                    "description": "Notification headline. Keep under 60 chars.",
                },
                "message": {
                    "type": "string",
                    "description": (
                        "Body text. Keep under 200 chars. Optional; "
                        "if omitted only the title appears."
                    ),
                },
                "urgency": {
                    "type": "string",
                    "enum": list(_URGENCY_MAP.keys()),
                    "description": "low / normal / high (default normal).",
                    "default": "normal",
                },
                "timeout_ms": {
                    "type": "integer",
                    "description": (
                        "Auto-dismiss after N ms. Default 5000. Set "
                        "0 for sticky."
                    ),
                    "default": 5000,
                },
            },
            "required": ["title"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        title = (kwargs.get("title") or "").strip()
        if not title:
            return ToolResult(
                tool_name=self.name, status="error",
                error="`title` is required",
            )
        message = (kwargs.get("message") or "").strip()
        urgency = (kwargs.get("urgency") or "normal").lower()
        urgency = _URGENCY_MAP.get(urgency, "normal")
        try:
            timeout_ms = int(kwargs.get("timeout_ms", 5000))
        except (TypeError, ValueError):
            timeout_ms = 5000

        # Channel 1: notify-send (Linux desktop)
        notify = shutil.which("notify-send")
        if notify is not None:
            argv = [
                notify,
                "--app-name", "Cognos",
                "--urgency", urgency,
                "--expire-time", str(max(0, timeout_ms)),
                title,
            ]
            if message:
                argv.append(message)
            try:
                proc = await asyncio.create_subprocess_exec(
                    *argv,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                _, stderr = await asyncio.wait_for(
                    proc.communicate(), timeout=5,
                )
                if proc.returncode == 0:
                    return ToolResult(
                        tool_name=self.name, status="success",
                        output=f"Notification sent via notify-send: {title!r}",
                        metadata={
                            "channel": "notify-send",
                            "title": title,
                            "urgency": urgency,
                        },
                    )
                # notify-send returned non-zero — fall through to bell
            except (asyncio.TimeoutError, OSError):
                pass

        # Channel 2: terminal bell (works in any TTY)
        try:
            sys.stderr.write("\a")
            sys.stderr.flush()
            return ToolResult(
                tool_name=self.name, status="success",
                output=(
                    f"Notification sent via terminal bell (no desktop "
                    f"notifier available): {title!r}"
                ),
                metadata={
                    "channel": "bell",
                    "title": title,
                    "fallback_reason": "notify-send unavailable",
                },
            )
        except Exception as e:
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"could not deliver notification: {e}",
            )
