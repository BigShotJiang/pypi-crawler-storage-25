"""Agent tool — the Respond-like primitive that lets the parent spawn subagents."""

from __future__ import annotations

from typing import Any

from core.schemas import ToolResult
from execution.tools.base import BaseTool


class AgentTool(BaseTool):
    name = "Agent"
    description = (
        "Spawn a subagent OR dispatch a message on the inter-agent bus.\n\n"
        "Spawn mode (default): supply `task` (+ optional `subagent_type`, "
        "`isolation`) to spawn a child agent and wait for its summary. "
        "Available subagent_types: general-purpose, research, code-review, "
        "executor_brain, critic_brain.\n\n"
        "Bus mode: supply `recipient_agent_id` "
        "(executor_brain_01 or critic_brain_02) plus `payload_context`. "
        "Set `suspend_sender_state=true` to wait for the recipient's "
        "reply; otherwise fire-and-forget."
    )

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "task": {
                    "type": "string",
                    "description": "Spawn mode: what the subagent should accomplish. Be specific — the subagent does not see your context.",
                },
                "subagent_type": {
                    "type": "string",
                    "description": "Spawn mode preset",
                    "enum": ["general-purpose", "research", "code-review",
                            "executor_brain", "critic_brain"],
                    "default": "general-purpose",
                },
                "isolation": {
                    "type": "string",
                    "description": "Spawn mode: set 'worktree' for an isolated working copy. Best-effort.",
                    "enum": ["worktree"],
                },
                "recipient_agent_id": {
                    "type": "string",
                    "description": "Bus mode: which agent to message.",
                    "enum": ["executor_brain_01", "critic_brain_02"],
                },
                "payload_context": {
                    "type": "string",
                    "description": "Bus mode: message body delivered to the recipient.",
                },
                "suspend_sender_state": {
                    "type": "boolean",
                    "description": "Bus mode: if true, await the recipient's reply before returning.",
                    "default": False,
                },
            },
        }

    def __init__(self, manager=None):
        self._manager = manager

    def set_manager(self, manager) -> None:
        self._manager = manager

    async def execute(self, **kwargs: Any) -> ToolResult:
        if self._manager is None:
            return self._error("SubagentManager not configured")

        recipient = kwargs.get("recipient_agent_id")
        if recipient:
            payload = kwargs.get("payload_context", "")
            if not payload:
                return self._error("payload_context required in bus mode")
            suspend = bool(kwargs.get("suspend_sender_state", False))
            try:
                reply = await self._manager.dispatch(
                    sender_id="agent_tool",
                    recipient_id=recipient,
                    context=payload,
                    suspend_sender=suspend,
                )
            except Exception as e:
                return self._error(f"Bus dispatch failed: {e}")
            if suspend:
                return self._success(str(reply) if reply is not None else "(no reply)")
            return self._success(f"Message queued for {recipient}.")

        task = kwargs.get("task", "")
        subagent_type = kwargs.get("subagent_type", "general-purpose")
        isolation = kwargs.get("isolation")

        if not task:
            return self._error("No task provided (and no recipient_agent_id for bus mode)")

        run = await self._manager.run_one(
            task, subagent_type=subagent_type, isolation=isolation,
        )
        if run.error:
            return self._error(f"Subagent {run.id} failed: {run.error}")
        result = run.result or "(no output)"
        if run.worktree_path:
            result += f"\n\n[worktree: {run.worktree_path} branch={run.worktree_branch}]"
        return self._success(result)
