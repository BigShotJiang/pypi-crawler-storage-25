"""AskUserQuestion — structured disambiguation prompt for the user.

The agent uses this when it needs the user to pick between several
options before continuing. The tool returns a markdown-formatted
prompt that the LLM is expected to echo verbatim as its turn-end
response. The user's next chat reply provides the answer; there's
no real "blocking wait" because Cognos is chat-driven, not REPL.

Output shape (what the LLM sees back from the tool):
  ## <question>

  - **A.** <choice 1>
  - **B.** <choice 2>
  - **C.** <choice 3>

  *Reply with the letter (or the choice text) to continue.*

Why a dedicated tool instead of just typing the question?
  1. Gives Caudate a clear "I am asking the user" signal in the
     replay record so she can learn the disambiguation pattern.
  2. Standardises the format so the WebUI could later detect the
     marker and render real radio buttons.
  3. Keeps the LLM honest: when there are concrete choices, present
     them — don't ramble open-endedly.
"""

from __future__ import annotations

import logging
import os
import string
import sys
from typing import Any

from core.schemas import ToolResult
from execution.tools.base import BaseTool

logger = logging.getLogger(__name__)

# Sentinel marker the WebUI / chat-front-end can detect to render a
# nicer choice picker once that hook is added. Plain text below it
# stays human-readable in any UI.
_MARKER = "<!-- cognos:ask_user_question -->"


async def _interactive_pick(
    question: str, choices: list[str], context: str,
) -> int | None:
    """Show a prompt_toolkit Frame with the question + choices and let
    the user pick with arrows / 1-6 / Enter. Returns the chosen index,
    or None if cancelled (Esc / Ctrl-C)."""
    os.environ.setdefault("PROMPT_TOOLKIT_NO_CPR", "1")

    from prompt_toolkit.application import Application
    from prompt_toolkit.key_binding import KeyBindings
    from prompt_toolkit.layout import HSplit, Layout, Window
    from prompt_toolkit.layout.controls import FormattedTextControl
    from prompt_toolkit.layout.dimension import Dimension as D
    from prompt_toolkit.styles import Style
    from prompt_toolkit.widgets import Frame

    state = {"cursor": 0, "result": None}

    def header_text():
        out = []
        if context:
            out.append(("class:dim", f"  {context}\n"))
        out.append(("class:question", f"  {question}\n"))
        out.append(("", "\n"))
        return out

    def menu_text():
        out = []
        for i, choice in enumerate(choices):
            if i == state["cursor"]:
                out.append(("class:selected", f"  ❯ {i+1}. {choice}\n"))
            else:
                out.append(("class:option", f"    {i+1}. {choice}\n"))
        return out

    kb = KeyBindings()

    @kb.add("up")
    def _(event):
        state["cursor"] = (state["cursor"] - 1) % len(choices)
        event.app.invalidate()

    @kb.add("down")
    def _(event):
        state["cursor"] = (state["cursor"] + 1) % len(choices)
        event.app.invalidate()

    @kb.add("enter")
    def _(event):
        state["result"] = state["cursor"]
        event.app.exit()

    @kb.add("escape")
    @kb.add("c-c")
    def _(event):
        state["result"] = None
        event.app.exit()

    for i in range(min(len(choices), 9)):
        @kb.add(str(i + 1))
        def _(event, _idx=i):
            state["result"] = _idx
            event.app.exit()

    body = HSplit(
        [
            Window(
                FormattedTextControl(header_text),
                height=D(min=2 if not context else 3, max=4, preferred=3),
            ),
            Window(
                FormattedTextControl(menu_text),
                height=D(min=len(choices), max=len(choices), preferred=len(choices)),
            ),
        ]
    )
    layout = Layout(Frame(body, title="Question", style="class:frame"))
    style = Style.from_dict(
        {
            "question": "bold",
            "dim": "#888888",
            "selected": "bold",
            "option": "",
            "frame.border": "#5f5f87",
            "frame.label": "bold #87afff",
        }
    )

    app: Application[None] = Application(
        layout=layout, key_bindings=kb, style=style,
        full_screen=False, mouse_support=False,
    )

    # Pause StreamDisplay tickers so they don't repaint over the menu.
    display = None
    try:
        from ui.display import get_active_display
        display = get_active_display()
    except Exception:
        display = None
    if display is not None:
        display.pause()
    try:
        await app.run_async()
    finally:
        if display is not None:
            display.resume()

    return state["result"]


class AskUserQuestionTool(BaseTool):
    name = "AskUserQuestion"
    description = (
        "Ask the user a multiple-choice question to disambiguate "
        "before proceeding. Provide a clear `question` and 2-6 "
        "`choices`. The tool returns a markdown prompt the LLM "
        "should surface verbatim as its turn-end response; the "
        "user's next reply (a letter A/B/C... or the choice text) "
        "is the answer. Use this whenever the work depends on a "
        "decision the user can make in one tap — file path, "
        "destination, model variant, scope, etc. Don't use it for "
        "open-ended questions; just ask those directly."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "question": {
                    "type": "string",
                    "description": "The question to ask the user. One sentence ideally.",
                },
                "choices": {
                    "type": "array",
                    "items": {"type": "string"},
                    "minItems": 2,
                    "maxItems": 6,
                    "description": (
                        "Between 2 and 6 distinct options. Each is a "
                        "single phrase or short sentence."
                    ),
                },
                "context": {
                    "type": "string",
                    "description": (
                        "Optional one-line context shown above the "
                        "question (e.g. why you're asking)."
                    ),
                },
            },
            "required": ["question", "choices"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        question = (kwargs.get("question") or "").strip()
        choices = kwargs.get("choices") or []
        context = (kwargs.get("context") or "").strip()

        if not question:
            return ToolResult(
                tool_name=self.name, status="error",
                error="`question` is required",
            )
        if not isinstance(choices, list) or len(choices) < 2:
            return ToolResult(
                tool_name=self.name, status="error",
                error="provide at least 2 choices",
            )
        if len(choices) > 6:
            return ToolResult(
                tool_name=self.name, status="error",
                error="too many choices (max 6)",
            )

        clean_choices = [str(c).strip() for c in choices if str(c).strip()]
        if len(clean_choices) < 2:
            return ToolResult(
                tool_name=self.name, status="error",
                error="need at least 2 non-empty choices",
            )

        letters = string.ascii_uppercase[: len(clean_choices)]

        # Interactive TTY → pop a real picker (Claude-Code-style).
        # The tool's "output" is the chosen text, so the LLM sees the
        # user's decision directly and continues without echoing the
        # menu as plain text.
        if sys.stdin.isatty():
            try:
                idx = await _interactive_pick(question, clean_choices, context)
            except Exception as e:
                logger.debug(f"interactive picker failed, falling back to text: {e}")
                idx = "_FAILED"
            if idx is None:
                return ToolResult(
                    tool_name=self.name, status="success",
                    output="(user cancelled — no choice made)",
                    metadata={
                        "question": question,
                        "choices": clean_choices,
                        "letters": list(letters),
                        "context": context,
                        "cancelled": True,
                    },
                )
            if idx != "_FAILED":
                picked = clean_choices[idx]
                return ToolResult(
                    tool_name=self.name, status="success",
                    output=f"User picked: {picked}",
                    metadata={
                        "question": question,
                        "choices": clean_choices,
                        "letters": list(letters),
                        "context": context,
                        "picked_index": idx,
                        "picked": picked,
                    },
                )
            # Fall through to text rendering on selector failure.

        # Non-TTY (WebUI, piped input) or selector failed → emit the
        # markdown so the front-end can render its own picker.
        lines: list[str] = [_MARKER, ""]
        if context:
            lines.append(f"_{context}_")
            lines.append("")
        lines.append(f"## {question}")
        lines.append("")
        for letter, choice in zip(letters, clean_choices):
            lines.append(f"- **{letter}.** {choice}")
        lines.append("")
        lines.append(
            "*Reply with the letter (or the choice text) to continue.*"
        )

        return ToolResult(
            tool_name=self.name, status="success",
            output="\n".join(lines),
            metadata={
                "question": question,
                "choices": clean_choices,
                "letters": list(letters),
                "context": context,
            },
        )
