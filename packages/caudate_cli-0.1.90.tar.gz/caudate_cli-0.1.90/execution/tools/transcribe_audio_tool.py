"""TranscribeAudio — speech-to-text for a local audio file.

Uses Cognos's existing Whisper STT backend from `voice/stt.py`.
Loaded lazily on first call.

Accepts wav/mp3/flac/ogg/m4a — anything Whisper can read. Returns
the transcript as a single text block.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from core.schemas import ToolResult
from execution.tools.base import BaseTool

logger = logging.getLogger(__name__)


class TranscribeAudioTool(BaseTool):
    name = "TranscribeAudio"
    description = (
        "Convert a local audio file to text via Whisper. Use for "
        "voice notes, meeting recordings, podcasts, voicemails, or "
        "any 'what does this audio say?' request. Path must be a "
        "local file (wav/mp3/flac/ogg/m4a/etc.). Returns the full "
        "transcript."
    )

    def __init__(self):
        self._stt: Any | None = None

    def _get_stt(self):
        if self._stt is None:
            from voice.stt import make_stt
            self._stt = make_stt(name="whisper")
        return self._stt

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path to a local audio file.",
                },
            },
            "required": ["path"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        path = (kwargs.get("path") or "").strip()
        p = Path(path).expanduser().resolve()
        if not p.exists() or not p.is_file():
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"audio file not found: {p}",
            )

        try:
            audio_bytes = p.read_bytes()
            stt = self._get_stt()
            transcript = stt.transcribe(audio_bytes)
        except Exception as e:
            logger.exception("TranscribeAudio failed")
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"{type(e).__name__}: {e}",
            )

        if not transcript or not transcript.strip():
            return ToolResult(
                tool_name=self.name, status="success",
                output="(empty transcript — no speech detected)",
                metadata={"path": str(p), "transcript": ""},
            )
        return ToolResult(
            tool_name=self.name, status="success",
            output=transcript,
            metadata={"path": str(p),
                      "transcript": transcript,
                      "char_count": len(transcript)},
        )
