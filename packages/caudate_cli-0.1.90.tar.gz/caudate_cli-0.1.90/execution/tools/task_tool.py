"""Task tools — durable tracking for long-running async work.

Wraps `core/background.py::BackgroundTaskPool` so the LLM can spawn
fire-and-forget agent turns and check on them later. Useful when the
user asks for something that takes minutes (e.g. "generate a 12-panel
storyboard, I'll come back later") — the agent kicks off the work,
hands back a task id, and the next chat turn can `TaskGet` to surface
the result.

Five tools:

  - **`TaskCreate`** — spawn a sub-prompt as a background task. The
    agent runs the prompt in the same process; the user's chat turn
    returns immediately with the task id.
  - **`TaskList`**   — show all tasks in the pool with status.
  - **`TaskGet`**    — fetch a single task by id (status, duration, result).
  - **`TaskOutput`** — same as TaskGet but returns just the result text.
  - **`TaskStop`**   — cancel a running task by id.

Persistence: in-process only. When the Cognos server restarts, all
running tasks are lost (per the upstream BackgroundTaskPool design).
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from core.background import BackgroundTask, get_global_pool
from core.schemas import ToolResult
from execution.tools.base import BaseTool

logger = logging.getLogger(__name__)


def _format_task(t: BackgroundTask, *, brief: bool = False) -> str:
    head = (
        f"  {t.id}  [{t.status:>9}]  duration={t.duration:6.1f}s\n"
        f"    label: {t.label[:80]}"
    )
    if brief:
        return head
    extra = []
    if t.error:
        extra.append(f"    error: {t.error[:200]}")
    if t.result:
        extra.append(f"    result (head): {t.result[:160]}")
    return head + ("\n" + "\n".join(extra) if extra else "")


class TaskCreateTool(BaseTool):
    mutates = True
    name = "TaskCreate"
    description = (
        "Spawn a sub-prompt as a background task. The agent runs the "
        "given `prompt` in the same Cognos process but doesn't block "
        "the current chat turn — you get a task id back immediately. "
        "Use this when the work will take longer than ~30 seconds and "
        "the user doesn't want to wait. Use `TaskGet` / `TaskOutput` "
        "later to fetch the result. Limitation: tasks run in-process, "
        "so they die if the Cognos server restarts."
    )

    def __init__(self, agent: Any | None = None):
        self._agent = agent

    def set_agent(self, agent: Any) -> None:
        self._agent = agent

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "prompt": {
                    "type": "string",
                    "description": "What the background agent turn should do.",
                },
                "label": {
                    "type": "string",
                    "description": "Short human-readable label shown in TaskList.",
                },
            },
            "required": ["prompt"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        prompt = (kwargs.get("prompt") or "").strip()
        label = (kwargs.get("label") or prompt[:60]).strip()
        if not prompt:
            return ToolResult(
                tool_name=self.name, status="error",
                error="`prompt` is required",
            )
        if self._agent is None or not hasattr(self._agent, "chat"):
            return ToolResult(
                tool_name=self.name, status="error",
                error=(
                    "TaskCreate is not wired to a CognosAgent. The "
                    "agent must call set_agent() at startup."
                ),
            )

        pool = get_global_pool()
        agent = self._agent

        async def _run() -> str:
            return await agent.chat(prompt)

        bg = pool.submit(_run, label=label)
        return ToolResult(
            tool_name=self.name, status="success",
            output=(
                f"Background task started.\n"
                f"  task_id:  {bg.id}\n"
                f"  label:    {bg.label}\n"
                f"Use TaskGet({bg.id!r}) or TaskOutput({bg.id!r}) to "
                f"check on it. Use TaskStop({bg.id!r}) to cancel."
            ),
            metadata={"task_id": bg.id, "label": bg.label, "status": bg.status},
        )


class TaskListTool(BaseTool):
    name = "TaskList"
    description = (
        "List all background tasks in this process with their status, "
        "duration, label, and (for finished ones) the result-head or "
        "error. No arguments. Tasks are sorted newest-first."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {"type": "object", "properties": {}}

    async def execute(self, **_: Any) -> ToolResult:
        tasks = get_global_pool().list()
        if not tasks:
            return ToolResult(
                tool_name=self.name, status="success",
                output="No background tasks.",
                metadata={"tasks": []},
            )
        lines = [f"{len(tasks)} background task(s):", ""]
        lines.extend(_format_task(t) for t in tasks)
        return ToolResult(
            tool_name=self.name, status="success",
            output="\n".join(lines),
            metadata={
                "tasks": [
                    {
                        "id":          t.id,
                        "status":      t.status,
                        "label":       t.label,
                        "duration_s":  t.duration,
                        "started_at":  t.started_at,
                        "finished_at": t.finished_at or None,
                        "error":       t.error,
                    }
                    for t in tasks
                ],
            },
        )


class TaskGetTool(BaseTool):
    name = "TaskGet"
    description = (
        "Fetch one background task by id. Returns its status, duration, "
        "label, error (if any), and the full result text (if done). Use "
        "this to check on work spawned via TaskCreate."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "task_id": {
                    "type": "string",
                    "description": "Task id from TaskCreate / TaskList.",
                },
            },
            "required": ["task_id"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        task_id = (kwargs.get("task_id") or "").strip()
        if not task_id:
            return ToolResult(
                tool_name=self.name, status="error",
                error="`task_id` is required",
            )
        bg = get_global_pool().get(task_id)
        if bg is None:
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"no task with id {task_id!r}",
            )
        lines = [
            f"task {bg.id}",
            f"  status:    {bg.status}",
            f"  label:     {bg.label}",
            f"  duration:  {bg.duration:.1f}s",
        ]
        if bg.error:
            lines.append(f"  error:     {bg.error[:400]}")
        if bg.result:
            lines.append(f"  result:")
            lines.append(bg.result)
        return ToolResult(
            tool_name=self.name, status="success",
            output="\n".join(lines),
            metadata={
                "id":         bg.id,
                "status":     bg.status,
                "label":      bg.label,
                "duration_s": bg.duration,
                "error":      bg.error,
                "result":     bg.result,
            },
        )


class TaskOutputTool(BaseTool):
    name = "TaskOutput"
    description = (
        "Return only the final output (result text) of a finished "
        "background task. Errors if the task is still running, has "
        "no output yet, or doesn't exist. Use this when you just "
        "want the answer and don't care about metadata."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "task_id": {
                    "type": "string",
                    "description": "Task id from TaskCreate / TaskList.",
                },
            },
            "required": ["task_id"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        task_id = (kwargs.get("task_id") or "").strip()
        if not task_id:
            return ToolResult(
                tool_name=self.name, status="error",
                error="`task_id` is required",
            )
        bg = get_global_pool().get(task_id)
        if bg is None:
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"no task with id {task_id!r}",
            )
        if bg.status in ("pending", "running"):
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"task {task_id} is still {bg.status} ({bg.duration:.1f}s elapsed)",
            )
        if bg.status == "failed":
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"task {task_id} failed: {bg.error}",
            )
        return ToolResult(
            tool_name=self.name, status="success",
            output=bg.result or "(empty)",
            metadata={"id": bg.id, "status": bg.status},
        )


class TaskStopTool(BaseTool):
    mutates = True
    name = "TaskStop"
    description = (
        "Cancel a running background task by id. No-op if the task is "
        "already finished or doesn't exist. Returns success or 'not "
        "cancellable'."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "task_id": {
                    "type": "string",
                    "description": "Task id from TaskList.",
                },
            },
            "required": ["task_id"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        task_id = (kwargs.get("task_id") or "").strip()
        if not task_id:
            return ToolResult(
                tool_name=self.name, status="error",
                error="`task_id` is required",
            )
        ok = get_global_pool().cancel(task_id)
        if not ok:
            bg = get_global_pool().get(task_id)
            if bg is None:
                return ToolResult(
                    tool_name=self.name, status="error",
                    error=f"no task with id {task_id!r}",
                )
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"task {task_id} is {bg.status} — not cancellable",
            )
        return ToolResult(
            tool_name=self.name, status="success",
            output=f"Cancellation requested for task {task_id}.",
            metadata={"task_id": task_id},
        )
