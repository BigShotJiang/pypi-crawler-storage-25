"""DescribeImage — caption / OCR / Q&A about a local image file.

Uses the chat LLM (typically Haiku via system2) with a multimodal
message — base64-encoded image + a text question. Both Haiku and Opus
natively support image input via the OpenAI-compat content-blocks
shape that LiteLLM forwards to Anthropic.

Earlier versions tried to reach into Cognos's `InternVLVisionEncoder`
for a `.chat()` method that doesn't exist (that encoder only produces
4096-D embeddings, not natural-language output). This version uses
the chat LLM the user already has configured — costs a small per-call
quota burn but works against any multimodal provider.
"""

from __future__ import annotations

import base64
import json
import logging
import mimetypes
import os
from pathlib import Path
from typing import Any

from core.schemas import ToolResult
from execution.tools.base import BaseTool

logger = logging.getLogger(__name__)


def _guess_mime(path: Path) -> str:
    mime, _ = mimetypes.guess_type(str(path))
    if mime and mime.startswith("image/"):
        return mime
    suffix = path.suffix.lower().lstrip(".")
    return f"image/{suffix}" if suffix in ("png", "jpeg", "jpg", "webp", "gif") else "image/png"


def _read_settings_model() -> str:
    """Pick the LLM to ask. Prefer system2 (smarter, multimodal) so
    the description quality is good. Fall back to system1 or a
    sensible default."""
    settings_path = Path.home() / ".cognos" / "settings.json"
    try:
        d = json.loads(settings_path.read_text())
        return (d.get("system2")
                or d.get("system1")
                or "anthropic/claude-haiku-4-5")
    except Exception:
        return "anthropic/claude-haiku-4-5"


class DescribeImageTool(BaseTool):
    name = "DescribeImage"
    description = (
        "Describe / OCR / answer questions about a local image file. "
        "Supports PNG, JPG, WEBP, GIF. Sends the image to the chat LLM "
        "(Haiku / Opus / whichever multimodal provider is configured) "
        "via a multimodal message. Use for screenshots, photos, "
        "diagrams, OCR-style text extraction, or any 'what does this "
        "image show?' question. Path must be a local file; use "
        "WebFetch first if you need to pull a URL."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path to a local image file (png/jpg/webp/gif/...).",
                },
                "prompt": {
                    "type": "string",
                    "description": "Optional question or framing (default: 'Describe this image in detail.')",
                    "default": "Describe this image in detail.",
                },
                "model": {
                    "type": "string",
                    "description": "Override the LLM model id. Default: settings.json system2.",
                },
            },
            "required": ["path"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        path_str = (kwargs.get("path") or "").strip()
        prompt = (kwargs.get("prompt") or "Describe this image in detail.").strip()
        model = (kwargs.get("model") or "").strip() or _read_settings_model()

        path = Path(path_str).expanduser().resolve()
        if not path.exists() or not path.is_file():
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"image file not found: {path}",
            )

        # Bound the body — multimodal messages with > a few MB of base64
        # are wasteful and may hit provider limits.
        try:
            raw = path.read_bytes()
        except OSError as e:
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"failed to read image: {e}",
            )
        if len(raw) > 8 * 1024 * 1024:
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"image too large ({len(raw)/1024/1024:.1f}MB) "
                      "— max 8MB; resize first",
            )

        mime = _guess_mime(path)
        b64 = base64.b64encode(raw).decode("ascii")
        data_url = f"data:{mime};base64,{b64}"

        # Build multimodal message — OpenAI-compat content blocks shape
        # that LiteLLM translates per provider (Anthropic uses its own
        # `image` block; OpenAI uses `image_url`; the SDK handles both).
        messages = [{
            "role": "user",
            "content": [
                {"type": "text", "text": prompt},
                {"type": "image_url", "image_url": {"url": data_url}},
            ],
        }]

        try:
            from llm.provider import LLMProvider
            from core.anthropic_auth import subscription_auth_scope
            llm = LLMProvider(model=model)
            # Subscription-auth scope so anthropic/* models work without
            # an API key (mirrors the chat path's behavior).
            with subscription_auth_scope():
                resp = await llm.chat(messages=messages, max_tokens=2048)
        except Exception as e:
            logger.exception("DescribeImage LLM call failed")
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"LLM call failed: {e}",
            )

        description = (resp.content or "").strip()
        if not description:
            return ToolResult(
                tool_name=self.name, status="error",
                error="LLM returned empty content",
            )
        return ToolResult(
            tool_name=self.name, status="success",
            output=description,
            metadata={
                "path": str(path),
                "mime": mime,
                "size_bytes": len(raw),
                "model": model,
                "prompt": prompt,
            },
        )
