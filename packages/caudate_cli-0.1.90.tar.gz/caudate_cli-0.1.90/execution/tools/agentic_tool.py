"""Agentic — bridge to the Agentic marketplace (https://agentic.so).

Lifts hosted LLM tools from the Agentic platform into Cognos's tool
palette via plain HTTP — no Node.js bridge, no `@agentic/platform-tool-
client` dependency, just the same wire protocol the TypeScript SDK
uses underneath.

Two endpoints (extracted from `@agentic/platform-tool-client/dist/`):
  - GET  https://api.agentic.so/v1/projects/public/by-identifier
    Returns the project + its `lastPublishedDeployment.tools` array
    with name/description/inputSchema for each tool.
  - POST https://gateway.agentic.so/<deploymentIdentifier>/<toolName>
    Executes the tool. JSON body in, JSON out.

Auth: optional `Authorization: Bearer <AGENTIC_API_KEY>` from env.

Two Cognos tools ship from this module:
  - `Agentic`        — execute a tool by (identifier, tool_name, args)
  - `AgenticBrowse`  — list the tools published in a project
"""

from __future__ import annotations

import json
import logging
import os
import time
from typing import Any

import httpx

from core.schemas import ToolResult
from execution.tools.base import BaseTool

logger = logging.getLogger(__name__)


_API_BASE = os.environ.get("AGENTIC_API_BASE", "https://api.agentic.so")
_GATEWAY_BASE = os.environ.get("AGENTIC_GATEWAY_BASE", "https://gateway.agentic.so")
_DEFAULT_TIMEOUT_S = 30.0
_DEPLOYMENT_CACHE_TTL_S = 600.0   # re-fetch deployment metadata every 10 min


def _api_key() -> str | None:
    return os.environ.get("AGENTIC_API_KEY") or None


def _auth_headers() -> dict[str, str]:
    key = _api_key()
    return {"Authorization": f"Bearer {key}"} if key else {}


# ---------------------------------------------------------------------
# Cached deployment-metadata fetch.
#
# `AgenticTool` and `AgenticBrowseTool` share this cache so that two
# back-to-back calls to e.g. '@agentic/search' don't both hit the
# /v1/projects/public/by-identifier endpoint.
# ---------------------------------------------------------------------

_CACHE: dict[str, tuple[float, dict[str, Any]]] = {}


async def _resolve_deployment(identifier: str) -> dict[str, Any]:
    """Look up a project by identifier and return its latest deployment.

    Returns the deployment dict, which has at minimum:
        - identifier (string, used in the gateway URL)
        - tools (list of {name, description, inputSchema, ...})
    """
    now = time.time()
    cached = _CACHE.get(identifier)
    if cached and (now - cached[0]) < _DEPLOYMENT_CACHE_TTL_S:
        return cached[1]

    url = f"{_API_BASE}/v1/projects/public/by-identifier"
    params = {
        "projectIdentifier": identifier,
        "populate[]":        "lastPublishedDeployment",
    }
    async with httpx.AsyncClient(timeout=_DEFAULT_TIMEOUT_S) as client:
        resp = await client.get(url, params=params, headers=_auth_headers())
    if resp.status_code == 404:
        raise ValueError(f"Agentic project not found: {identifier!r}")
    resp.raise_for_status()
    project = resp.json()
    deployment = project.get("lastPublishedDeployment")
    if not deployment:
        raise ValueError(
            f"Agentic project {identifier!r} has no published deployment"
        )
    _CACHE[identifier] = (now, deployment)
    return deployment


# ---------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------


class AgenticTool(BaseTool):
    name = "Agentic"
    description = (
        "[CURRENTLY DORMANT — agentic.so service is suspended] "
        "Bridge to the Agentic marketplace. Pass `identifier` "
        "('@agentic/search'), `tool_name`, and `args`. Calls go to "
        "https://gateway.agentic.so but that endpoint returns "
        "'Service Suspended' as of 2026-05-03. Will start working "
        "again automatically if the service comes back, or set "
        "AGENTIC_API_BASE/AGENTIC_GATEWAY_BASE env vars to a self-"
        "hosted compatible gateway. Don't reach for this tool by "
        "default — use OpenAPI for any REST API instead."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "identifier": {
                    "type": "string",
                    "description": "Agentic project identifier, e.g. '@agentic/search'.",
                },
                "tool_name": {
                    "type": "string",
                    "description": "Name of the specific tool within the project. Use AgenticBrowse to list tools first.",
                },
                "args": {
                    "type": "object",
                    "description": "Arguments to pass to the tool (JSON object).",
                },
                "timeout_s": {
                    "type": "number",
                    "description": "Override timeout in seconds (default 30).",
                },
            },
            "required": ["identifier", "tool_name"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        identifier = (kwargs.get("identifier") or "").strip()
        tool_name = (kwargs.get("tool_name") or "").strip()
        args = kwargs.get("args") or {}
        timeout = float(kwargs.get("timeout_s") or _DEFAULT_TIMEOUT_S)

        if not identifier or not tool_name:
            return ToolResult(
                tool_name=self.name, status="error",
                error="`identifier` and `tool_name` are both required",
            )

        # Resolve deployment + validate the tool exists locally before
        # we send a request — cheaper to fail early than to get a 404
        # from the gateway with an opaque message.
        try:
            deployment = await _resolve_deployment(identifier)
        except (httpx.HTTPError, ValueError) as e:
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"resolve failed: {e}",
            )

        tool_specs = deployment.get("tools") or []
        names = [t.get("name") for t in tool_specs]
        if tool_name not in names:
            return ToolResult(
                tool_name=self.name, status="error",
                error=(f"tool {tool_name!r} not in {identifier!r}; "
                       f"available: {names}"),
            )

        deployment_id = (deployment.get("identifier")
                         or deployment.get("deploymentIdentifier")
                         or identifier)
        url = f"{_GATEWAY_BASE}/{deployment_id}/{tool_name}"

        try:
            async with httpx.AsyncClient(timeout=timeout) as client:
                resp = await client.post(
                    url, json=args, headers=_auth_headers()
                )
        except httpx.TimeoutException:
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"timed out after {timeout}s calling {tool_name}",
            )
        except httpx.RequestError as e:
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"network error: {e}",
            )

        if resp.status_code >= 400:
            return ToolResult(
                tool_name=self.name, status="error",
                error=(f"{resp.status_code} from gateway: "
                       f"{resp.text[:300]}"),
            )

        # Try to parse JSON, fall back to text
        ctype = resp.headers.get("content-type", "")
        if "json" in ctype:
            try:
                body = resp.json()
                output = json.dumps(body, indent=2)
            except Exception:
                output = resp.text
                body = None
        else:
            output = resp.text
            body = None

        return ToolResult(
            tool_name=self.name, status="success",
            output=output[:4000] + (
                f"\n\n... ({len(output) - 4000} more chars truncated)"
                if len(output) > 4000 else ""
            ),
            metadata={
                "identifier":    identifier,
                "tool_name":     tool_name,
                "deployment_id": deployment_id,
                "response":      body,
            },
        )


class AgenticBrowseTool(BaseTool):
    name = "AgenticBrowse"
    description = (
        "[CURRENTLY DORMANT — agentic.so suspended] List tools in an "
        "Agentic project. Calls api.agentic.so/v1/projects/public; "
        "currently returns 'Service Suspended'. Will start working "
        "again if the service returns, or point AGENTIC_API_BASE at "
        "a self-hosted gateway."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "identifier": {
                    "type": "string",
                    "description": "Agentic project identifier, e.g. '@agentic/search'.",
                },
            },
            "required": ["identifier"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        identifier = (kwargs.get("identifier") or "").strip()
        if not identifier:
            return ToolResult(
                tool_name=self.name, status="error",
                error="`identifier` is required",
            )

        try:
            deployment = await _resolve_deployment(identifier)
        except (httpx.HTTPError, ValueError) as e:
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"resolve failed: {e}",
            )

        tool_specs = deployment.get("tools") or []
        if not tool_specs:
            return ToolResult(
                tool_name=self.name, status="success",
                output=f"{identifier}: no tools published",
                metadata={"identifier": identifier, "tools": []},
            )

        lines = [f"{identifier} — {len(tool_specs)} tool(s):"]
        for t in tool_specs:
            n = t.get("name") or "?"
            desc = (t.get("description") or "").strip().splitlines()[0:1]
            desc_line = desc[0] if desc else ""
            lines.append(f"  - {n}: {desc_line[:160]}")
            schema = t.get("inputSchema") or {}
            props = (schema.get("properties") or {})
            if props:
                for pn, pdef in list(props.items())[:6]:
                    ptype = pdef.get("type", "?")
                    pdesc = (pdef.get("description") or "")[:80]
                    lines.append(f"      {pn} ({ptype}): {pdesc}")

        return ToolResult(
            tool_name=self.name, status="success",
            output="\n".join(lines),
            metadata={
                "identifier":   identifier,
                "tools":        tool_specs,
                "deployment":   deployment.get("identifier"),
            },
        )
