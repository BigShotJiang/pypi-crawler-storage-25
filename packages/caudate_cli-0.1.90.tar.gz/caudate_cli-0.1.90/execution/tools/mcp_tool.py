"""MCP visibility tool — list connected Model Context Protocol servers.

Cognos already supports MCP at runtime: each `CognosAgent` keeps a
`_mcp_clients` list of connected `MCPClient`s, and the tools they
expose are merged into the executor's tool palette. This tool just
makes that surface visible from chat — the agent can ask "which MCP
servers are connected and what do they expose?" and get a clear
answer instead of having to dig through config files.

Configuration lives at `data/mcp_servers.json` (see the example in
the same dir for shape).
"""

from __future__ import annotations

import logging
from typing import Any

from core.schemas import ToolResult
from execution.tools.base import BaseTool

logger = logging.getLogger(__name__)


class MCPListServersTool(BaseTool):
    name = "MCPListServers"
    description = (
        "List all Model Context Protocol (MCP) servers currently "
        "connected to this Cognos agent, plus the tools each one "
        "exposes. Useful when the user asks 'what MCP servers do I "
        "have' or 'why isn't tool X working' — this surfaces what's "
        "actually wired vs. only configured. No arguments. Configure "
        "MCP servers in `data/mcp_servers.json`."
    )

    def __init__(self, agent: Any | None = None):
        self._agent = agent

    def set_agent(self, agent: Any) -> None:
        self._agent = agent

    @property
    def input_schema(self) -> dict[str, Any]:
        return {"type": "object", "properties": {}}

    async def execute(self, **_: Any) -> ToolResult:
        if self._agent is None:
            return ToolResult(
                tool_name=self.name, status="error",
                error=(
                    "MCPListServers is not wired to a CognosAgent. "
                    "The agent must call set_agent() at startup."
                ),
            )
        clients = getattr(self._agent, "_mcp_clients", None)
        if clients is None:
            return ToolResult(
                tool_name=self.name, status="success",
                output="MCP support is not active in this agent.",
                metadata={"clients": []},
            )
        if not clients:
            return ToolResult(
                tool_name=self.name, status="success",
                output=(
                    "No MCP servers connected.\n"
                    "Configure one at `data/mcp_servers.json` (see "
                    "`data/mcp_servers.json.example` for the shape) "
                    "and restart Cognos."
                ),
                metadata={"clients": []},
            )

        lines = [f"{len(clients)} MCP server(s) connected:", ""]
        client_meta: list[dict[str, Any]] = []
        for c in clients:
            name = getattr(c, "name", None) or repr(c)
            tools = []
            try:
                tools = c.tools() or []
            except Exception as e:
                logger.debug(f"MCP {name}: tools() failed: {e}")
            tool_names = [
                getattr(t, "name", None) or t.get("name", "?")
                if isinstance(t, dict) else str(t)
                for t in tools
            ]
            lines.append(f"  {name}  ({len(tool_names)} tool(s))")
            for tn in tool_names[:12]:
                lines.append(f"    - {tn}")
            if len(tool_names) > 12:
                lines.append(f"    ... and {len(tool_names) - 12} more")
            client_meta.append({"name": name, "tool_count": len(tool_names),
                                "tools": tool_names})

        return ToolResult(
            tool_name=self.name, status="success",
            output="\n".join(lines),
            metadata={"clients": client_meta},
        )
