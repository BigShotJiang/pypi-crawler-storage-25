"""EditImage — modify an existing image with FLUX img2img or Kontext.

Two modes selected by the LLM (or auto-routed):

  - **`reimagine`** (FLUX-schnell img2img): preserves composition,
    restyles content. Use for "watercolor version", "anime style",
    "more vibrant colors", "blurry photo of the same scene".
    Strength controls how much to deviate (0=identity, 1=fresh).

  - **`edit`** (FLUX.1-Kontext-dev): instruction-driven editing.
    Use for "make the wings blue", "remove the flower", "add a
    forest behind", "change the time to sunset". The model edits
    only what the instruction names; the rest of the image stays.

  - **`auto`** (default): keyword heuristic picks one.
    Imperative-edit verbs ("change", "make", "remove", "add",
    "replace", "turn") → `edit`. Otherwise → `reimagine`.

Source can be a local path, a `file://` URI, or a `files/<id>` /
`/files/<id>/content` reference resolved via FileStore. The output
is persisted to FileStore exactly like Draw — returns a markdown
image link the chat UI renders inline.
"""

from __future__ import annotations

import logging
import re
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

from core.image import ImageEdit, edit_to_file_store, make_image_edit
from core.schemas import ToolResult
from execution.tools.base import BaseTool

logger = logging.getLogger(__name__)


# Keyword sets for the auto-routing heuristic. Brittle by design —
# the LLM can override by passing `mode` explicitly. We bias toward
# `edit` (Kontext) because in practice it preserves source content
# far better than FLUX-schnell img2img, even for stylistic prompts.
_EDIT_VERBS = {
    "change", "make", "remove", "add", "replace", "turn",
    "delete", "erase", "swap", "convert", "transform", "recolor",
    "set", "put", "insert", "give", "fix", "edit",
}
_STYLE_KEYWORDS = {
    "cartoon", "comic", "anime", "manga", "watercolor", "oil painting",
    "pencil sketch", "pixel art", "cel shaded", "ghibli", "pop art",
    "vintage", "noir",
}
# Only reach for img2img when the prompt is a *very mild* tweak —
# Kontext doesn't lose source identity at high stylization strength.
_REIMAGINE_HINTS_STRONG = {"slightly", "subtle", "soft tweak", "minor"}


def _detect_mode(prompt: str) -> str:
    p = prompt.lower().strip()
    if any(h in p for h in _REIMAGINE_HINTS_STRONG):
        return "reimagine"
    # Style-transfer keywords or imperative-edit verbs both go to
    # Kontext — it handles photos-with-faces correctly.
    if any(k in p for k in _STYLE_KEYWORDS):
        return "edit"
    first = re.split(r"\s+", p, maxsplit=1)[0]
    if first in _EDIT_VERBS:
        return "edit"
    return "edit"  # default — Kontext is safer than FLUX-schnell img2img


class EditImageTool(BaseTool):
    mutates = True
    name = "EditImage"
    description = (
        "Modify an existing image. Two modes: `reimagine` (FLUX-schnell "
        "img2img — restyle/transform while preserving composition; pass "
        "`strength` 0-1) or `edit` (FLUX.1-Kontext — instruction edit "
        "like 'make the wings blue' or 'remove the flower'). Use `mode` "
        "to pick explicitly; default `auto` routes by prompt verbs. "
        "Source: local path or 'files/<id>' from a previous Draw / "
        "DescribeImage / upload. Output: markdown image link the chat "
        "UI renders inline.\n\n"
        "STRONGLY PREFER `mode=edit` (Kontext) when:\n"
        "  - The source contains people/faces you want to preserve\n"
        "  - You want a STRONG style change (cartoon/anime/watercolor/oil-painting/comic) on a photo\n"
        "  - You want a targeted change ('make X blue', 'remove Y')\n"
        "Use `mode=reimagine` only for mild stylistic tweaks where some "
        "drift is OK. FLUX-schnell img2img has a narrow strength sweet "
        "spot; on photos with faces it usually fabricates rather than "
        "transforming.\n\n"
        "NOTE: Kontext is non-commercial license — for commercial use, "
        "fall back to `mode=reimagine`."
    )

    def __init__(
        self,
        file_store: Any | None = None,
        backend: str = "diffusers",
        backend_kwargs: dict | None = None,
    ):
        self._file_store = file_store
        self._backend_name = backend
        self._backend_kwargs = backend_kwargs or {}
        self._backend: ImageEdit | None = None

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "image": {
                    "type": "string",
                    "description": (
                        "Source image: absolute path, 'files/<file_id>', "
                        "or a /files/<id>/content URL from a prior tool."
                    ),
                },
                "prompt": {
                    "type": "string",
                    "description": (
                        "Instruction or restyling prompt. Examples: "
                        "'make the butterfly wings blue' (edit), "
                        "'watercolor version of this scene' (reimagine)."
                    ),
                },
                "mode": {
                    "type": "string",
                    "enum": ["auto", "reimagine", "edit"],
                    "description": (
                        "auto = keyword heuristic; reimagine = "
                        "FLUX-schnell img2img; edit = FLUX-Kontext "
                        "instruction edit. Default auto."
                    ),
                    "default": "auto",
                },
                "strength": {
                    "type": "number",
                    "description": (
                        "img2img only (mode=reimagine): how much to "
                        "deviate from source. 0=identity, 1=fresh. "
                        "Default 0.75."
                    ),
                    "default": 0.75,
                },
                "size": {
                    "type": "string",
                    "description": "Output dims, e.g. '1024x1024'. Default uses source size.",
                },
                "seed": {
                    "type": "integer",
                    "description": "Seed for reproducibility. Omit for random.",
                },
                "steps": {
                    "type": "integer",
                    "description": "Override inference steps. Defaults: 4 for reimagine, 28 for edit.",
                },
            },
            "required": ["image", "prompt"],
        }

    def set_file_store(self, file_store: Any) -> None:
        self._file_store = file_store

    def _get_backend(self) -> ImageEdit:
        if self._backend is None:
            self._backend = make_image_edit(self._backend_name, **self._backend_kwargs)
        return self._backend

    def _resolve_image(self, ref: str) -> bytes:
        """Resolve an image reference to raw bytes."""
        ref = ref.strip()
        # /files/<id>/content URL or files/<id> shorthand
        m = re.search(r"/?files/([0-9a-f-]{8,})(?:/content)?(?:[?#].*)?$", ref)
        if m and self._file_store is not None:
            rec = self._file_store.get(m.group(1))
            if rec is None:
                raise FileNotFoundError(f"file not found in store: {m.group(1)}")
            return Path(rec.path).read_bytes()
        # http(s) URL — fetch
        if ref.startswith(("http://", "https://")):
            with urllib.request.urlopen(ref, timeout=30) as r:
                return r.read()
        # file:// URI
        if ref.startswith("file://"):
            ref = urllib.parse.urlparse(ref).path
        # Plain path
        path = Path(ref).expanduser().resolve()
        if not path.exists() or not path.is_file():
            raise FileNotFoundError(f"image file not found: {path}")
        return path.read_bytes()

    async def execute(self, **kwargs: Any) -> ToolResult:
        image_ref = (kwargs.get("image") or "").strip()
        prompt = (kwargs.get("prompt") or "").strip()
        if not image_ref or not prompt:
            return ToolResult(
                tool_name=self.name, status="error",
                error="`image` and `prompt` are both required",
            )
        if self._file_store is None:
            return ToolResult(
                tool_name=self.name, status="error",
                error="EditImage is not wired to a FileStore.",
            )

        mode = (kwargs.get("mode") or "auto").lower()
        if mode == "auto":
            mode = _detect_mode(prompt)
            logger.info(f"EditImage auto-routed to mode={mode!r}")
        if mode not in ("reimagine", "edit"):
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"unknown mode {mode!r}; use 'auto' / 'reimagine' / 'edit'",
            )

        try:
            image_bytes = self._resolve_image(image_ref)
        except (FileNotFoundError, OSError, urllib.error.URLError) as e:
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"could not read source image: {e}",
            )

        edit_kwargs: dict[str, Any] = {}
        if "strength" in kwargs and kwargs["strength"] is not None:
            edit_kwargs["strength"] = float(kwargs["strength"])
        if kwargs.get("size"):
            edit_kwargs["size"] = kwargs["size"]
        if kwargs.get("seed") is not None:
            edit_kwargs["seed"] = int(kwargs["seed"])
        if kwargs.get("steps") is not None:
            edit_kwargs["steps"] = int(kwargs["steps"])

        try:
            backend = self._get_backend()
            record = await edit_to_file_store(
                backend, self._file_store, image_bytes, prompt,
                mode=mode, **edit_kwargs,
            )
        except Exception as e:
            logger.exception("EditImage failed")
            return ToolResult(
                tool_name=self.name, status="error",
                error=f"edit failed: {e}",
            )

        url = f"http://127.0.0.1:8000/files/{record.id}/content"
        viewer = f"http://127.0.0.1:8000/artifact/{record.id}"
        md = f"![{prompt[:120]}]({url})\n\n[📄 Open in viewer]({viewer})"
        return ToolResult(
            tool_name=self.name, status="success",
            output=md,
            metadata={
                "file_id": record.id,
                "filename": record.filename,
                "mode": mode,
                "prompt": prompt,
            },
        )
