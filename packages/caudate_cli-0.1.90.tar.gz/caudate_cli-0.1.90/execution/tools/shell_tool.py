"""Shell tools — synchronous + background execution.

Two tools live here:

  - **`Bash`** runs a command via `/bin/sh -c` (or `bash -c`). When
    `run_in_background: true` the process is detached, its output is
    redirected to a temp log file, and the tool returns the PID + log
    path immediately so the LLM can keep going while the job runs.
  - **`PowerShell`** invokes PowerShell Core (`pwsh`) with the same
    `run_in_background` semantics. Useful for cross-platform scripts
    that target Windows / .NET-flavoured tooling.
"""

from __future__ import annotations

import asyncio
import os
import re
import shutil
import shlex
import tempfile
import time
import uuid
from pathlib import Path
from typing import Any

from core.schemas import ToolResult
from execution.tools.base import BaseTool


# Where background-job logs live. Tucked under tempdir so they're
# auto-cleaned by OS housekeeping; the path is returned to the caller
# so they can `Read` it any time before then.
_BG_LOG_DIR = Path(tempfile.gettempdir()) / "cognos-bg-jobs"
_BG_LOG_DIR.mkdir(parents=True, exist_ok=True)

# Patterns we never run, regardless of mode.
#
# These match a destructive *invocation* — the binary appearing at the
# start of a shell segment (after `;`, `&&`, `||`, `|`, newline, or
# beginning of string), optionally preceded by `sudo`. Substring matches
# would block harmless lookups like `which mkfs.ext4` or `echo "dd if="`.
_SEGMENT_SEPARATORS = re.compile(r"[;&|]+|\n")

_BLOCKED_PATTERNS = (
    # `rm -rf /` or `rm -rf /<anything>` — but allow `rm -rf ./foo`
    re.compile(r"^\s*(sudo\s+)?rm\s+-[rRf]+\s+/(?!home/|tmp/|var/tmp/)"),
    # mkfs invocation (mkfs.ext4, mkfs xfs, etc.)
    re.compile(r"^\s*(sudo\s+)?mkfs(\.|\s)"),
    # dd writing to a device or to a critical system path. We check
    # `of=/dev/*` or `of=/(etc|boot|sbin|usr)/...` regardless of where
    # in the command line `of=` appears — order-independent. Excludes
    # the harmless write-to-null/zero/random sinks.
    re.compile(
        r"\bof=/(?:"
        r"dev/(?!null\b|zero\b|random\b|urandom\b)"
        r"|etc/|boot/|sbin/|usr/[^t]"
        r")"
    ),
)

# Fork-bomb pattern. Checked against the WHOLE command (not per
# segment) because the segment splitter `[;&|]+` would otherwise
# fragment `:(){ :|:& };:` into pieces and let it through. The
# canonical bomb uses `:` as the function name — which isn't in
# `\w` — so we match any non-whitespace identifier. The pattern
# allows the function body to use the same name as a self-pipe.
_FORK_BOMB_PATTERN = re.compile(
    r"([:\w]+)\(\)\s*\{\s*\1\s*\|\s*\1\s*&\s*\}\s*;"
)


def _is_blocked(cmd: str) -> bool:
    # Whole-string check first — fork bombs MUST be evaluated before
    # segment splitting destroys their `:|:` shape.
    if _FORK_BOMB_PATTERN.search(cmd):
        return True
    for segment in _SEGMENT_SEPARATORS.split(cmd):
        for pattern in _BLOCKED_PATTERNS:
            if pattern.search(segment):
                return True
    return False


# ---------------------------------------------------------------------
# Phase 3.5 — destructive-but-legitimate command warnings.
#
# Unlike `_BLOCKED_PATTERNS`, these are NOT auto-rejected. They fire a
# yellow `⚠` banner before the command runs so the user sees the
# risk even in `accept_edits` or auto-mode (where they wouldn't see
# the normal permission picker). Purely informational.
#
# Each entry: (compiled-regex, human-readable label).
# ---------------------------------------------------------------------

_WARN_PATTERNS: list[tuple[re.Pattern, str]] = [
    # `rm -rf ./<dir>` or `rm -rf <path>` (already-blocked / vs root)
    # We warn on ANY `rm -rf ...` even with a relative path — losing
    # an entire subtree by accident is a common pain point. Pattern
    # requires `r`/`R` in the flag chars so `docker rm -f X`
    # (no `r` in flags) doesn't false-trigger.
    (re.compile(r"\brm\s+-[a-zA-Z]*[rR][a-zA-Z]*\b"),
     "rm -rf — recursive force-delete; check the path"),
    # `chmod -R 777` (or 666, 755 — but 777 is the dangerous one)
    (re.compile(r"\bchmod\s+(-R\s+)?(777|666)\b"),
     "chmod world-writable — opens permissions for everyone"),
    # `chown -R` to anything other than the current user — uncommon
    # but pretty visible footprint.
    (re.compile(r"\bchown\s+-R\b"),
     "chown -R — changes ownership across a tree"),
    # `truncate` (file content erase)
    (re.compile(r"\btruncate\s+(-s\s+)?0\b"),
     "truncate -s 0 — erases the file's contents in place"),
    # `> /existing/file` redirection (we can't easily know if it
    # exists without stat, so warn on absolute-path redirections).
    (re.compile(r">\s*/(?!dev/null|tmp/|var/tmp/)[^\s]+"),
     "shell redirection to an absolute path — overwrites the file"),
    # `find ... -delete` (the catch from earlier safe-bash design)
    (re.compile(r"\bfind\b.*\s-delete\b"),
     "find -delete — bulk recursive deletion"),
    # `find ... -exec rm` or similar
    (re.compile(r"\bfind\b.*\s-exec\s+rm\b"),
     "find -exec rm — bulk recursive deletion via exec"),
    # `dd of=` (writing to device or file at offset)
    (re.compile(r"\bdd\b.*\bof="),
     "dd of= — raw write; can corrupt devices or files"),
    # `git push --force` / `-f`
    (re.compile(r"\bgit\s+push\s+(.*-f|--force)\b"),
     "git push --force — overwrites remote history"),
    # `git reset --hard` (destroys local work)
    (re.compile(r"\bgit\s+reset\s+--hard\b"),
     "git reset --hard — discards uncommitted changes"),
    # `git clean -f` (delete untracked files)
    (re.compile(r"\bgit\s+clean\s+-[fdx]+\b"),
     "git clean -f — deletes untracked files"),
    # `curl | sh` / `wget | sh` patterns (remote-code-execution)
    (re.compile(r"\b(curl|wget)\b[^|]*\|\s*(sh|bash|zsh|fish)\b"),
     "curl|sh — pipes remote content to a shell; trust the source"),
    # `npm publish` / `pip upload` (mistaken publishes)
    (re.compile(r"\bnpm\s+publish\b"),
     "npm publish — releases the package publicly"),
    (re.compile(r"\btwine\s+upload\b"),
     "twine upload — releases to PyPI publicly"),
    # `kubectl delete` / `docker rm` cluster-wide
    (re.compile(r"\bkubectl\s+delete\s+(ns|namespace|deployment|pod|svc|service)\b"),
     "kubectl delete — removes cluster resources"),
    (re.compile(r"\bdocker\s+(system\s+)?(prune|rm\s+-f)\b"),
     "docker prune / rm -f — removes containers or images"),
]


def _emit_risk_warnings(cmd: str) -> None:
    """Print `⚠ <label>` for each risk detected in `cmd`.

    Routes through the active StreamDisplay when available (so the
    yellow banner appears inline with the agent's tool output);
    falls back to a bare rich.Console print otherwise.
    """
    warnings = risk_warnings(cmd)
    if not warnings:
        return
    try:
        from ui.display import get_active_display
        display = get_active_display()
    except Exception:
        display = None
    try:
        if display is not None and hasattr(display, "console"):
            for w in warnings:
                display.console.print(f"  [yellow]⚠[/yellow] [yellow]{w}[/yellow]")
            return
    except Exception:
        pass
    # Fallback: standalone Console (CLI / non-interactive paths).
    try:
        from rich.console import Console
        c = Console()
        for w in warnings:
            c.print(f"  [yellow]⚠[/yellow] [yellow]{w}[/yellow]")
    except Exception:
        for w in warnings:
            print(f"  ⚠ {w}")


def risk_warnings(cmd: str) -> list[str]:
    """Return a list of human-readable risk warnings for `cmd`.

    Empty list = no risks detected. Each label is shown to the user
    as a `⚠ <label>` banner before the command runs. Purely
    informational — never blocks.

    Note: `cmd` may contain multiple statements (`;`, `&&`, `||`, `|`).
    We scan the WHOLE string rather than splitting, because some
    patterns (e.g. `curl | sh`) span segments by design.
    """
    if not cmd:
        return []
    seen: set[str] = set()
    out: list[str] = []
    for pattern, label in _WARN_PATTERNS:
        if pattern.search(cmd) and label not in seen:
            seen.add(label)
            out.append(label)
    return out


# ---------------------------------------------------------------------
# Workspace guard — refuse Bash writes to "forbidden default" paths
# (e.g. ~/cognos/sandbox/projects/) when the workspace_mode is `cwd`.
# The system prompt already tells the model not to use these paths,
# but instruction-following is unreliable on smaller models, so we
# enforce at the tool level too.
# ---------------------------------------------------------------------

# Substrings that, if present in a write-context, get rejected.
_FORBIDDEN_WRITE_PATH_FRAGMENTS = (
    "/cognos/sandbox/",
)

# Write-intent verbs / operators we look for in the command. Read-only
# `ls`/`cat`/`stat` against these paths is fine — only writes are blocked.
_WRITE_INTENT_PATTERNS = (
    re.compile(r"\bmkdir\b"),
    re.compile(r"\btouch\b"),
    re.compile(r"\bcp\b"),
    re.compile(r"\bmv\b"),
    re.compile(r"\brm\b"),
    re.compile(r"\bln\b"),
    re.compile(r"\btee\b"),
    re.compile(r">"),     # redirection
    re.compile(r">>"),    # append
)


def _workspace_mode() -> str:
    try:
        from core.settings import Settings
        return (Settings.load().get("workspace_mode") or "cwd").lower()
    except Exception:
        return "cwd"


def _violates_workspace(cmd: str) -> str | None:
    """Return a human-readable reason if `cmd` writes to a forbidden
    path under `workspace_mode=cwd`. Returns None if the command is
    fine (or workspace_mode is `sandbox`).
    """
    if _workspace_mode() != "cwd":
        return None
    # Quick filter: skip the heavy regex check unless the command
    # mentions a forbidden path at all.
    lowered = cmd
    if not any(frag in lowered for frag in _FORBIDDEN_WRITE_PATH_FRAGMENTS):
        return None
    has_write_intent = any(p.search(cmd) for p in _WRITE_INTENT_PATTERNS)
    if not has_write_intent:
        return None
    return (
        "Refusing to write into the legacy sandbox path. Workspace is "
        "the cwd — use the directory the user launched caudate from. "
        "If you really need a different path, ask the user."
    )


# ---------------------------------------------------------------------
# Interactive sudo support — Claude-Code-style password prompt.
#
# When the agent issues `sudo X`, instead of failing (DEVNULL stdin) or
# hanging (inherited TTY), we:
#   1. Pop a secure password prompt via prompt_toolkit
#   2. Cache the password in process memory for the session
#   3. Rewrite each `sudo` invocation in the command to `sudo -S`
#   4. Pipe the cached password to the subprocess on stdin
# ---------------------------------------------------------------------
_SUDO_AT_START = re.compile(r"(?:^|(?<=[;&|\n]))(\s*)sudo(?!\s+-[nSA])(\s)")
_SUDO_PASSWORD_CACHE: str | None = None


def _needs_sudo_password(cmd: str) -> bool:
    return bool(_SUDO_AT_START.search(cmd))


def _rewrite_sudo_to_S(cmd: str) -> str:
    return _SUDO_AT_START.sub(r"\1sudo -S\2", cmd)


def _invalidate_sudo_password() -> None:
    global _SUDO_PASSWORD_CACHE
    _SUDO_PASSWORD_CACHE = None


async def _get_sudo_password() -> str | None:
    """Return the cached sudo password, or prompt for one.

    The prompt is rendered via prompt_toolkit so arrow keys, backspace,
    and is_password masking all work. StreamDisplay tickers are paused
    while the prompt is up so they don't clobber the input.
    Returns None if the user cancels (Ctrl-C / Esc).
    """
    global _SUDO_PASSWORD_CACHE
    if _SUDO_PASSWORD_CACHE is not None:
        return _SUDO_PASSWORD_CACHE

    # Pause ticker repaints so they don't fight the password prompt.
    display = None
    try:
        from ui.display import get_active_display
        display = get_active_display()
    except Exception:
        display = None
    if display is not None:
        display.pause()

    try:
        from prompt_toolkit import PromptSession
        from rich.console import Console
        console = Console()
        console.print()
        console.print("  [yellow]🔐 sudo password required[/yellow]")
        try:
            session: PromptSession = PromptSession()
            pw = await session.prompt_async(
                "  Password: ", is_password=True,
            )
        except (KeyboardInterrupt, EOFError):
            return None
        if not pw:
            return None
        _SUDO_PASSWORD_CACHE = pw
        return pw
    except Exception as e:
        # Falls back to "no password" — the subprocess will then fail
        # with sudo's usual "no password was provided" / "no tty" error.
        import logging
        logging.getLogger(__name__).debug(f"sudo prompt failed: {e}")
        return None
    finally:
        if display is not None:
            display.resume()




async def _stream_lines(
    proc: asyncio.subprocess.Process, on_line,
) -> tuple[str, str]:
    """Concurrently read stdout/stderr line-by-line, invoking on_line
    for each. Returns the full collected (stdout, stderr) at the end.
    """
    out_lines: list[str] = []
    err_lines: list[str] = []

    async def _drain(stream, sink: list[str], kind: str) -> None:
        if stream is None:
            return
        while True:
            try:
                raw = await stream.readline()
            except (ValueError, RuntimeError):
                return
            if not raw:
                return
            line = raw.decode("utf-8", errors="replace").rstrip("\n")
            sink.append(line)
            try:
                on_line(kind, line)
            except Exception:
                pass

    await asyncio.gather(
        _drain(proc.stdout, out_lines, "stdout"),
        _drain(proc.stderr, err_lines, "stderr"),
    )
    return "\n".join(out_lines), "\n".join(err_lines)


async def _run_foreground(
    argv: list[str] | str, *, shell: bool, timeout: int,
    env: dict[str, str] | None = None,
    sudo_password: str | None = None,
    on_line=None,
) -> tuple[int, str, str, bool]:
    """Run a command foreground; returns (returncode, stdout, stderr, timed_out).

    When sudo_password is None, stdin is /dev/null so any process that
    tries to read input (interactive sudo, `read`, `apt` prompts) fails
    fast instead of hanging.

    When sudo_password is supplied, stdin is a pipe and the password is
    written followed by a newline — sudo's `-S` flag will consume it.
    """
    stdin_setting = (
        asyncio.subprocess.PIPE if sudo_password is not None
        else asyncio.subprocess.DEVNULL
    )
    if shell:
        proc = await asyncio.create_subprocess_shell(
            argv if isinstance(argv, str) else " ".join(argv),
            stdin=stdin_setting,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=env,
        )
    else:
        proc = await asyncio.create_subprocess_exec(
            *(argv if isinstance(argv, list) else shlex.split(argv)),
            stdin=stdin_setting,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=env,
        )
    # Sudo password: write to stdin and close it before reading output,
    # otherwise communicate() and the streaming reader would race.
    if sudo_password is not None and proc.stdin is not None:
        try:
            proc.stdin.write((sudo_password + "\n").encode("utf-8"))
            await proc.stdin.drain()
            proc.stdin.close()
        except Exception:
            pass

    async def _runner():
        if on_line is not None:
            stdout, stderr = await _stream_lines(proc, on_line)
        else:
            out, err = await proc.communicate()
            stdout = out.decode("utf-8", errors="replace")
            stderr = err.decode("utf-8", errors="replace")
        await proc.wait()
        return stdout.strip(), stderr.strip()

    try:
        stdout, stderr = await asyncio.wait_for(_runner(), timeout=timeout)
        return (
            proc.returncode or 0,
            stdout,
            stderr,
            False,
        )
    except asyncio.TimeoutError:
        try:
            proc.kill()
        except Exception:
            pass
        return (-1, "", f"command timed out after {timeout}s", True)


def _spawn_background(
    argv: list[str] | str, *, shell: bool,
    label: str, env: dict[str, str] | None = None,
) -> tuple[int, Path]:
    """Detach a long-running process; returns (pid, log_path).

    Stdout + stderr are merged into a single log file under
    `_BG_LOG_DIR` so the caller can read it incrementally with `Read`
    or `Grep` and decide when to consider the job done.
    """
    job_id = f"{int(time.time())}-{uuid.uuid4().hex[:6]}-{label}"
    log_path = _BG_LOG_DIR / f"{job_id}.log"
    log_fh = open(log_path, "wb", buffering=0)

    # `setsid` so the child gets its own session and outlives us if we
    # exit. `start_new_session=True` is the Python equivalent.
    if shell:
        cmd_str = argv if isinstance(argv, str) else " ".join(argv)
        proc = asyncio.subprocess.subprocess.Popen(  # type: ignore[attr-defined]
            cmd_str, shell=True,
            stdout=log_fh, stderr=log_fh,
            stdin=asyncio.subprocess.subprocess.DEVNULL,  # type: ignore[attr-defined]
            start_new_session=True,
            env=env,
        )
    else:
        proc = asyncio.subprocess.subprocess.Popen(  # type: ignore[attr-defined]
            argv if isinstance(argv, list) else shlex.split(argv),
            stdout=log_fh, stderr=log_fh,
            stdin=asyncio.subprocess.subprocess.DEVNULL,  # type: ignore[attr-defined]
            start_new_session=True,
            env=env,
        )
    log_fh.close()  # the subprocess holds the fd; we don't need ours
    return proc.pid, log_path


class ShellTool(BaseTool):
    mutates = True
    name = "Bash"
    description = (
        "Execute a shell command and return its output. Use for system "
        "commands, file operations, git, and any CLI tool. Set "
        "`run_in_background: true` for long-running commands — Cognos "
        "spawns the process detached, returns the PID + log path "
        "immediately, and you can `Read` the log file to track "
        "progress without blocking the conversation."
    )

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "The shell command to execute (passed to sh -c).",
                },
                "timeout": {
                    "type": "integer",
                    "description": "Timeout in seconds (default 30, foreground only).",
                    "default": 30,
                },
                "run_in_background": {
                    "type": "boolean",
                    "description": (
                        "If true, the command is spawned detached. "
                        "Returns the PID + path to a log file capturing "
                        "stdout+stderr; the tool returns immediately "
                        "without waiting for the process to finish."
                    ),
                    "default": False,
                },
            },
            "required": ["command"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        command = kwargs.get("command", "")
        if not command:
            return self._error("No command provided")
        if _is_blocked(command):
            return self._error(f"Blocked dangerous command: {command}")
        ws_reason = _violates_workspace(command)
        if ws_reason is not None:
            return self._error(ws_reason)
        # Phase 3.5: surface risk warnings to the user even in modes
        # that auto-allow this command (accept_edits, auto, bypass).
        # Never blocks — purely informational.
        _emit_risk_warnings(command)

        if kwargs.get("run_in_background"):
            try:
                pid, log_path = _spawn_background(
                    command, shell=True, label="bash",
                )
            except Exception as e:
                return self._error(f"failed to spawn background job: {e}")
            return self._success(
                f"Background job started.\n"
                f"  pid:       {pid}\n"
                f"  log file:  {log_path}\n"
                f"Use `Read` on the log path to inspect output. The "
                f"process continues to run after this turn finishes."
            )

        timeout = int(kwargs.get("timeout", 30))

        # Interactive sudo: prompt for password (cached for the session),
        # rewrite `sudo` → `sudo -S`, and pipe the password via stdin.
        sudo_password: str | None = None
        run_command = command
        if _needs_sudo_password(command):
            sudo_password = await _get_sudo_password()
            if sudo_password is None:
                return self._error(
                    "sudo password not provided (prompt cancelled). "
                    "Re-run the command and enter the password, or "
                    "configure passwordless sudo in /etc/sudoers."
                )
            run_command = _rewrite_sudo_to_S(command)

        # Stream output line-by-line via the active StreamDisplay so the
        # user sees long-running commands progress in real time. Falls
        # back silently if no display is wired (e.g. headless API mode).
        on_line = None
        try:
            from ui.display import get_active_display
            _d = get_active_display()
            if _d is not None:
                on_line = _d.on_bash_line
        except Exception:
            on_line = None

        try:
            rc, stdout, stderr, timed_out = await _run_foreground(
                run_command, shell=True, timeout=timeout,
                sudo_password=sudo_password,
                on_line=on_line,
            )
        except Exception as e:
            return self._error(str(e))
        finally:
            try:
                if on_line is not None:
                    from ui.display import get_active_display
                    _d = get_active_display()
                    if _d is not None:
                        _d.on_bash_done()
            except Exception:
                pass

        # Wrong sudo password: clear cache so the next call re-prompts.
        if sudo_password is not None and rc != 0 and (
            "Sorry, try again" in stderr
            or "incorrect password" in stderr.lower()
        ):
            _invalidate_sudo_password()

        if timed_out:
            return self._error(f"Command timed out after {timeout}s")
        if rc == 0:
            return self._success(stdout or "(no output)")
        return self._error(f"Exit code {rc}: {stderr or stdout}")


class PowerShellTool(BaseTool):
    mutates = True
    name = "PowerShell"
    description = (
        "Execute a PowerShell Core (`pwsh`) command. Same semantics as "
        "Bash but runs in a PowerShell session — useful for "
        "cross-platform scripts targeting Windows tooling, .NET "
        "objects, or PowerShell modules. Set `run_in_background: true` "
        "for long-running commands."
    )

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": (
                        "PowerShell command or script. Equivalent to "
                        "running `pwsh -NoProfile -Command \"<command>\"`."
                    ),
                },
                "timeout": {
                    "type": "integer",
                    "description": "Timeout in seconds (default 30, foreground only).",
                    "default": 30,
                },
                "run_in_background": {
                    "type": "boolean",
                    "description": (
                        "If true, spawn detached and return the PID + "
                        "log path immediately. See Bash for details."
                    ),
                    "default": False,
                },
            },
            "required": ["command"],
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        command = kwargs.get("command", "")
        if not command:
            return self._error("No command provided")

        pwsh_path = shutil.which("pwsh") or shutil.which("powershell")
        if not pwsh_path:
            return self._error(
                "PowerShell Core (`pwsh`) is not installed. Install it "
                "via `snap install powershell --classic` (Linux) or "
                "from https://github.com/PowerShell/PowerShell."
            )

        # Refuse the blocked set on the underlying string too — easy to
        # try `Invoke-Expression "rm -rf /"` from PowerShell.
        if _is_blocked(command):
            return self._error(f"Blocked dangerous command: {command}")
        ws_reason = _violates_workspace(command)
        if ws_reason is not None:
            return self._error(ws_reason)

        argv = [pwsh_path, "-NoProfile", "-NonInteractive",
                "-Command", command]

        if kwargs.get("run_in_background"):
            try:
                pid, log_path = _spawn_background(
                    argv, shell=False, label="pwsh",
                )
            except Exception as e:
                return self._error(f"failed to spawn background pwsh job: {e}")
            return self._success(
                f"Background PowerShell job started.\n"
                f"  pid:       {pid}\n"
                f"  log file:  {log_path}\n"
                f"Use `Read` on the log path to inspect output."
            )

        timeout = int(kwargs.get("timeout", 30))
        try:
            rc, stdout, stderr, timed_out = await _run_foreground(
                argv, shell=False, timeout=timeout,
            )
        except Exception as e:
            return self._error(str(e))

        if timed_out:
            return self._error(f"Command timed out after {timeout}s")
        if rc == 0:
            return self._success(stdout or "(no output)")
        return self._error(f"Exit code {rc}: {stderr or stdout}")
