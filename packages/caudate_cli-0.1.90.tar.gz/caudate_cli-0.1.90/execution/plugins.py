"""Plugin loader — discover and register community tools from a directory.

Each plugin is a Python file in the plugins directory that exposes ONE of:

  1. A module-level variable `PLUGIN` assigned to a BaseTool subclass instance:
        from execution.tools.base import BaseTool
        class Hello(BaseTool):
            ...
        PLUGIN = Hello()

  2. A module-level `register(executor)` callable that registers tools itself:
        def register(executor):
            executor.register_tool(MyToolA())
            executor.register_tool(MyToolB())

Plugins are discovered from `plugins/*.py` (skipping files whose names start
with `_`) and `plugins/*/plugin.py` for package-style plugins.

Failures in one plugin never prevent loading the others — they're logged
and skipped.
"""

from __future__ import annotations

import importlib.util
import logging
import sys
from pathlib import Path
from typing import Any

from execution.tools.base import BaseTool

logger = logging.getLogger(__name__)


def load_plugins(plugin_dir: Path, executor: Any) -> int:
    """Discover and register every plugin in `plugin_dir`. Returns count registered."""
    if not plugin_dir.exists():
        return 0

    count = 0
    for path in _discover(plugin_dir):
        try:
            registered = _load_one(path, executor)
        except Exception as e:
            logger.warning(f"Plugin {path} failed to load: {e}")
            continue
        count += registered
    return count


def _discover(plugin_dir: Path) -> list[Path]:
    """Return every plugin entry point under `plugin_dir`.

    - Top-level files: plugin_dir/*.py (skipping _-prefixed and __init__)
    - Package style: plugin_dir/<name>/plugin.py
    """
    entries: list[Path] = []
    for path in sorted(plugin_dir.glob("*.py")):
        name = path.stem
        if name.startswith("_"):
            continue
        entries.append(path)
    for path in sorted(plugin_dir.glob("*/plugin.py")):
        entries.append(path)
    return entries


def _load_one(path: Path, executor: Any) -> int:
    """Import `path` as a module and register whatever it exposes."""
    module_name = f"cognos_plugin_{path.parent.name}_{path.stem}"
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load spec for {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)

    registered = 0

    # Preferred: explicit register() callable
    register_fn = getattr(module, "register", None)
    if callable(register_fn):
        before = len(executor.list_tools())
        register_fn(executor)
        registered = len(executor.list_tools()) - before
        logger.info(f"Plugin {path.name}: register() added {registered} tool(s)")
        return registered

    # Alternative: a PLUGIN variable pointing to a BaseTool instance (or list)
    plugin_obj = getattr(module, "PLUGIN", None)
    if plugin_obj is None:
        logger.warning(
            f"Plugin {path.name} has neither PLUGIN nor register() — skipping"
        )
        return 0

    candidates = plugin_obj if isinstance(plugin_obj, (list, tuple)) else [plugin_obj]
    for obj in candidates:
        if not isinstance(obj, BaseTool):
            logger.warning(
                f"Plugin {path.name} PLUGIN entry {obj!r} is not a BaseTool instance"
            )
            continue
        executor.register_tool(obj)
        registered += 1
    logger.info(f"Plugin {path.name}: registered {registered} tool(s)")
    return registered
