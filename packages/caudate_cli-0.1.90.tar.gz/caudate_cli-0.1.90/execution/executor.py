"""Executor — manages tool registry and executes tasks."""

from __future__ import annotations

import logging
import os
import time
from typing import Any

from core.schemas import Task, ToolResult, ToolResultStatus, Episode
from execution.tools.base import BaseTool
from execution.tools.shell_tool import PowerShellTool, ShellTool
from execution.tools.file_tool import FileReadTool, FileWriteTool
from execution.tools.edit_tool import EditTool, FillInMiddleTool
from execution.tools.glob_tool import GlobTool
from execution.tools.grep_tool import GrepTool
from execution.tools.notebook_tool import NotebookEditTool
from execution.tools.ask_user_question_tool import AskUserQuestionTool
from execution.tools.todo_tool import TodoWriteTool
from execution.tools.decompose_goal_tool import DecomposeGoalTool
from execution.tools.push_notification_tool import PushNotificationTool
from execution.tools.cron_tool import CronCreateTool, CronDeleteTool, CronListTool
from execution.tools.task_tool import (
    TaskCreateTool, TaskGetTool, TaskListTool, TaskOutputTool, TaskStopTool,
)
from execution.tools.worktree_tool import EnterWorktreeTool, ExitWorktreeTool
from execution.tools.mcp_tool import MCPListServersTool
from execution.tools.plan_mode_tool import EnterPlanModeTool, ExitPlanModeTool
from execution.tools.find_anywhere_tool import FindAnywhereTool
from execution.tools.system_info_tool import SystemInfoTool
from execution.tools.update_memory_tool import UpdateMemoryTool
from execution.tools.artifact_tool import ArtifactTool
from execution.tools.calculator_tool import CalculatorTool
from execution.tools.datetime_tool import DateTimeTool
from execution.tools.semantic_search_tool import SemanticSearchTool
from execution.tools.describe_image_tool import DescribeImageTool
from execution.tools.transcribe_audio_tool import TranscribeAudioTool
from execution.tools.speak_tool import SpeakTool
from execution.tools.http_request_tool import HttpRequestTool
from execution.tools.sandbox_tool import SandboxTool
from execution.tools.agentic_tool import AgenticTool, AgenticBrowseTool
from execution.tools.openapi_tool import OpenAPITool
from execution.tools.load_skill_tool import LoadSkillTool, RescanSkillsTool
from execution.tools.cognos_card_tool import CognosCardTool
from execution.tools.search_tool import WebSearchTool
from execution.tools.web_fetch_tool import WebFetchTool
from execution.tools.python_tool import PythonExecTool
from execution.tools.respond_tool import RespondTool
from execution.tools.think_tool import ThinkTool
from execution.tools.agent_tool import AgentTool
from execution.tools.draw_tool import DrawTool
from execution.tools.edit_image_tool import EditImageTool
from execution.tools.longcat_avatar_tool import LongCatAvatarTool
from execution.tools.storyboard_tool import StoryboardTool


# Legacy tool names mapped to their current canonical names. Kept for
# backward-compat with plans/strategies stored from Phase 1.
_LEGACY_ALIASES = {
    "shell": "Bash",
    "file_read": "Read",
    "file_write": "Write",
    "web_search": "WebSearch",
    "python_exec": "PythonExec",
    "respond": "Respond",
    "think": "Think",
}

logger = logging.getLogger(__name__)


class Executor:
    """Tool registry and task execution engine."""

    def __init__(self, llm=None, load_plugins: bool = True):
        self._tools: dict[str, BaseTool] = {}
        self._llm = llm
        self._register_defaults()
        if load_plugins:
            self._load_plugins()

    def _load_plugins(self) -> None:
        """Auto-load community plugins from PLUGINS_DIR."""
        try:
            from config import PLUGINS_DIR
            from execution.plugins import load_plugins as _load
            count = _load(PLUGINS_DIR, self)
            if count:
                logger.info(f"Loaded {count} plugin tool(s) from {PLUGINS_DIR}")
        except Exception as e:
            logger.warning(f"Plugin loader failed: {e}")

    def _register_defaults(self) -> None:
        """Register built-in tools."""
        think_tool = ThinkTool(llm=self._llm)
        agent_tool = AgentTool()       # manager wired later by CognosAgent
        # Read image-gen config from settings so users can swap model
        # (e.g. FLUX.1-schnell vs SDXL-Turbo) without code changes.
        # Falls back to DrawTool's own defaults if no `image` block.
        try:
            from core.settings import Settings
            _img_cfg = Settings.load().get("image", {}) or {}
        except Exception as e:
            logger.warning(f"Failed to load image settings: {e}")
            _img_cfg = {}
        _img_backend = _img_cfg.get("backend", "diffusers")
        _img_kwargs = {k: v for k, v in _img_cfg.items() if k != "backend"}
        draw_tool = DrawTool(
            backend=_img_backend, backend_kwargs=_img_kwargs,
        )         # file_store wired later by CognosAgent
        # Image-edit (img2img + Kontext). Reads `image_edit` settings
        # block; falls back to defaults baked into DiffusersImageEdit.
        try:
            from core.settings import Settings
            _edit_cfg = Settings.load().get("image_edit", {}) or {}
        except Exception:
            _edit_cfg = {}
        _edit_backend = _edit_cfg.get("backend", "diffusers")
        _edit_kwargs = {k: v for k, v in _edit_cfg.items() if k != "backend"}
        edit_image_tool = EditImageTool(
            backend=_edit_backend, backend_kwargs=_edit_kwargs,
        )         # file_store wired later by CognosAgent
        storyboard_tool = StoryboardTool(
            llm=self._llm,
        )         # file_store + image backends wired later by CognosAgent
        # LongCat Avatar (WAN-S2V talking-head video) — drives a local
        # ComfyUI server. URL overridable via COGNOS_COMFYUI_URL.
        longcat_avatar_tool = LongCatAvatarTool(
            comfyui_url=os.environ.get(
                "COGNOS_COMFYUI_URL", "http://127.0.0.1:8188",
            ),
        )         # file_store wired later by CognosAgent
        artifact_tool = ArtifactTool() # file_store wired later by CognosAgent
        speak_tool = SpeakTool()       # file_store wired later by CognosAgent
        for tool in [
            ShellTool(),
            PowerShellTool(),
            FileReadTool(),
            FileWriteTool(),
            EditTool(),
            FillInMiddleTool(),
            GlobTool(),
            GrepTool(),
            NotebookEditTool(),
            AskUserQuestionTool(),
            PushNotificationTool(),
            TodoWriteTool(),
            DecomposeGoalTool(),
            # Cron registry (read/create/delete)
            CronListTool(),
            CronCreateTool(),
            CronDeleteTool(),
            # Background task pool (TaskCreate needs the live agent —
            # wired by CognosAgent.__init__ via set_agent())
            TaskCreateTool(),
            TaskListTool(),
            TaskGetTool(),
            TaskOutputTool(),
            TaskStopTool(),
            # MCP server visibility (needs the live agent)
            MCPListServersTool(),
            # Git worktrees
            EnterWorktreeTool(),
            ExitWorktreeTool(),
            # Plan mode
            EnterPlanModeTool(),
            ExitPlanModeTool(),
            FindAnywhereTool(),
            SystemInfoTool(),
            UpdateMemoryTool(),
            CalculatorTool(),
            DateTimeTool(),
            SemanticSearchTool(),
            DescribeImageTool(),
            TranscribeAudioTool(),
            HttpRequestTool(),
            SandboxTool(),
            AgenticTool(),
            AgenticBrowseTool(),
            OpenAPITool(),
            LoadSkillTool(),
            RescanSkillsTool(),
            CognosCardTool(),
            WebSearchTool(),
            WebFetchTool(),
            PythonExecTool(),
            RespondTool(),
            think_tool,
            agent_tool,
            draw_tool,
            edit_image_tool,
            longcat_avatar_tool,
            storyboard_tool,
            artifact_tool,
            speak_tool,
        ]:
            self.register_tool(tool)

        # Forge feature-CRUD tools — let the agent manage its own
        # backlog when the orchestrator binds a project context.
        # Outside of a forge run they refuse politely.
        try:
            from execution.tools.forge_feature_tools import FORGE_FEATURE_TOOLS
            for cls in FORGE_FEATURE_TOOLS:
                self.register_tool(cls())
        except Exception as e:
            logger.warning(f"Forge tool registration failed: {e}")

    def set_llm(self, llm) -> None:
        """Set or update the LLM for tools that need it."""
        self._llm = llm
        think = self.get_tool("think")
        if think and hasattr(think, "set_llm"):
            think.set_llm(llm)

    def register_tool(self, tool: BaseTool) -> None:
        """Register a tool."""
        self._tools[tool.name] = tool
        logger.debug(f"Registered tool: {tool.name}")

    def get_tool(self, name: str) -> BaseTool | None:
        if name in self._tools:
            return self._tools[name]
        # Fall back to legacy aliases
        alias = _LEGACY_ALIASES.get(name)
        if alias and alias in self._tools:
            return self._tools[alias]
        return None

    def list_tools(self) -> list[str]:
        return list(self._tools.keys())

    def tool_definitions(self) -> list[dict]:
        """Get LiteLLM-compatible tool definitions for tool calling."""
        return [tool.to_tool_definition() for tool in self._tools.values()]

    def tool_descriptions(self) -> str:
        """Get descriptions for LLM context (legacy/display use)."""
        lines = []
        for name, tool in self._tools.items():
            params = ", ".join(f"{k}: {v}" for k, v in tool.parameters.items())
            lines.append(f"- {name}: {tool.description} ({params})")
        return "\n".join(lines)

    async def execute_tool(self, name: str, args: dict) -> ToolResult:
        """Execute a tool by name with raw args (for agentic loop).

        Unlike execute_task(), this takes raw name+args without a Task object.
        """
        tool = self.get_tool(name)
        if tool is None:
            return ToolResult(
                tool_name=name,
                status=ToolResultStatus.ERROR,
                error=f"Unknown tool: {name}",
            )
        # Plan-mode gate: refuse any tool that mutates state. The two
        # exceptions are EnterPlanMode/ExitPlanMode themselves so the
        # agent can always toggle out.
        try:
            from core.plan_mode import is_active as _plan_active
            if (
                _plan_active()
                and getattr(tool, "mutates", False)
                and name not in ("EnterPlanMode", "ExitPlanMode")
            ):
                return ToolResult(
                    tool_name=name,
                    status=ToolResultStatus.ERROR,
                    error=(
                        f"Plan mode is ON — `{name}` mutates state "
                        "and is blocked. Read-only tools still work. "
                        "Call ExitPlanMode to allow mutations."
                    ),
                )
        except Exception:
            pass  # plan_mode module missing → behave as if mode is off
        try:
            return await tool.execute(**args)
        except Exception as e:
            return ToolResult(
                tool_name=name,
                status=ToolResultStatus.ERROR,
                error=str(e),
            )

    async def execute_task(self, task: Task) -> tuple[ToolResult, Episode]:
        """Execute a single task and return result + episode record."""
        task.attempts += 1
        start = time.time()

        # Normalize "null"/"none" strings to actual None
        if task.tool_name and task.tool_name.lower() in ("null", "none", "reasoning"):
            task.tool_name = None

        if not task.tool_name:
            # Pure reasoning task — no tool to execute
            result = ToolResult(
                tool_name="reasoning",
                status=ToolResultStatus.SUCCESS,
                output=task.description,
            )
        else:
            tool = self.get_tool(task.tool_name)
            if tool is None:
                result = ToolResult(
                    tool_name=task.tool_name,
                    status=ToolResultStatus.ERROR,
                    error=f"Unknown tool: {task.tool_name}",
                )
            else:
                try:
                    result = await tool.execute(**task.tool_args)
                except Exception as e:
                    result = ToolResult(
                        tool_name=task.tool_name,
                        status=ToolResultStatus.ERROR,
                        error=str(e),
                    )

        result.duration_ms = (time.time() - start) * 1000

        episode = Episode(
            goal_id=task.goal_id,
            task_id=task.id,
            action=task.description,
            tool_name=task.tool_name,
            tool_args=task.tool_args,
            result=result,
        )

        logger.info(f"Executed task '{task.description}': {result.status.value} ({result.duration_ms:.0f}ms)")
        return result, episode
