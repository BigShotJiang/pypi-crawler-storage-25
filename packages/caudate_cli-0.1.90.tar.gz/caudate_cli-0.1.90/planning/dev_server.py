"""Per-project dev-server lifecycle.

Ports LocalForge's ``lib/dev-server.ts``. Each project can declare a
``dev_server_command`` + ``dev_server_port`` in its forge_settings. The
panel in the web UI calls these helpers to start/stop/status the
configured command. Output is best-effort streamed to the project's
log via the orchestrator's existing log infra.

Design choices:
  - One subprocess per project, tracked in an in-memory map
    (so a server restart loses all running dev-servers — that's fine,
    they're meant to be ephemeral).
  - Default command is ``npm run dev -- --port <port>`` (LocalForge
    parity); user can override via forge_settings.dev_server_command.
  - ``port`` defaults to 3000; can be overridden per-project.
  - We optionally pre-kill anything listening on the port (mirrors
    LocalForge's killProcessOnPort).
"""

from __future__ import annotations

import logging
import os
import shlex
import shutil
import signal
import subprocess
import time
from collections import deque
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


# {project_id: entry-dict}
_servers: dict[int, dict[str, Any]] = {}


def _kill_listeners_on_port(port: int) -> None:
    """Best-effort: kill anything currently listening on ``port``.

    Posix only — uses lsof. Failures are silent (probably nothing
    listening, which is the normal case).
    """
    if shutil.which("lsof") is None:
        return
    try:
        out = subprocess.check_output(
            ["lsof", "-ti", f":{port}"],
            stderr=subprocess.DEVNULL, timeout=3,
        ).decode().strip()
    except subprocess.SubprocessError:
        return
    for pid_s in out.splitlines():
        try:
            pid = int(pid_s)
            os.kill(pid, signal.SIGKILL)
        except (ValueError, ProcessLookupError, PermissionError):
            pass


def status(project_id: int) -> dict[str, Any]:
    """Return current status for the project's dev server (if any)."""
    entry = _servers.get(project_id)
    if entry is None:
        return {"running": False}
    proc: subprocess.Popen = entry["process"]
    if proc.poll() is not None:
        # Already exited
        err = entry.get("last_error") or f"process exited (rc={proc.returncode})"
        _servers.pop(project_id, None)
        return {"running": False, "error": err}
    return {
        "running": True,
        "pid": proc.pid,
        "port": entry["port"],
        "url": f"http://localhost:{entry['port']}",
        "command": entry["command"],
        "started_at": entry["started_at"],
        "last_log": list(entry["log_buffer"])[-20:],
    }


def start(
    project_id: int,
    folder_path: str,
    *,
    command: str | None = None,
    port: int = 3000,
) -> dict[str, Any]:
    """Start the dev server for a project. Idempotent: returns the
    existing entry if one is already running."""
    existing = status(project_id)
    if existing.get("running"):
        return existing

    folder = Path(folder_path).resolve()
    if not folder.exists():
        return {
            "running": False,
            "error": f"project folder not found: {folder}",
        }

    cmd_str = (command or "").strip() or f"npm run dev -- --port {port}"
    # Sanity check: if it's the default npm command, require a package.json
    if cmd_str.startswith("npm ") and not (folder / "package.json").exists():
        return {
            "running": False,
            "error": (
                "no package.json — set forge_settings.dev_server_command "
                "to the right command (e.g. 'python -m http.server 8000') "
                "or have the agent set up the project first."
            ),
        }

    _kill_listeners_on_port(port)

    args = shlex.split(cmd_str)
    try:
        proc = subprocess.Popen(
            args,
            cwd=str(folder),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            start_new_session=True,  # so signal goes to whole tree
        )
    except FileNotFoundError as e:
        return {
            "running": False,
            "error": f"command not found: {args[0]} ({e})",
        }
    except Exception as e:
        return {
            "running": False,
            "error": f"failed to spawn: {e}",
        }

    log_buffer: deque = deque(maxlen=200)
    entry: dict[str, Any] = {
        "process": proc,
        "port": port,
        "command": cmd_str,
        "started_at": time.time(),
        "log_buffer": log_buffer,
        "last_error": None,
    }

    # Background reader thread to drain stdout/stderr (combined).
    import threading

    def _reader() -> None:
        try:
            assert proc.stdout is not None
            for line in proc.stdout:
                line = line.rstrip()
                if line:
                    log_buffer.append(line)
        except Exception as e:
            entry["last_error"] = f"reader error: {e}"
        finally:
            rc = proc.poll()
            if rc not in (None, 0):
                entry["last_error"] = (
                    entry.get("last_error")
                    or f"exited rc={rc}"
                )

    t = threading.Thread(target=_reader, daemon=True)
    t.start()
    entry["reader"] = t

    _servers[project_id] = entry

    return {
        "running": True,
        "pid": proc.pid,
        "port": port,
        "url": f"http://localhost:{port}",
        "command": cmd_str,
        "started_at": entry["started_at"],
    }


def stop(project_id: int) -> bool:
    """Terminate the dev server for the project."""
    entry = _servers.pop(project_id, None)
    if entry is None:
        return False
    proc: subprocess.Popen = entry["process"]
    try:
        # Kill the whole process group — npm spawns child processes
        # (next.js, vite, etc.) that need to die with it.
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
        except (ProcessLookupError, PermissionError):
            pass
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
            except (ProcessLookupError, PermissionError):
                pass
    except Exception as e:
        logger.warning(f"stop dev server failed: {e}")
    return True


def stop_all() -> int:
    """Shut down every running dev server. Called by api.server's shutdown
    hook so we don't orphan dev processes when cognos-serve restarts."""
    n = 0
    for pid in list(_servers):
        if stop(pid):
            n += 1
    return n


__all__ = ["start", "stop", "stop_all", "status"]
