"""Task Graph — DAG-based task dependency management."""

from __future__ import annotations

from typing import Any

from core.schemas import Task, TaskStatus


class TaskGraph:
    """Directed Acyclic Graph of tasks with dependency tracking."""

    def __init__(self, tasks: list[Task] | None = None):
        self._tasks: dict[str, Task] = {}
        if tasks:
            for task in tasks:
                self._tasks[task.id] = task

    def add_task(self, task: Task) -> None:
        self._tasks[task.id] = task

    def get_task(self, task_id: str) -> Task | None:
        return self._tasks.get(task_id)

    def get_ready_tasks(self) -> list[Task]:
        """Return tasks whose dependencies are all completed."""
        completed = {tid for tid, t in self._tasks.items() if t.status == TaskStatus.COMPLETED}
        return [
            t for t in self._tasks.values()
            if t.status == TaskStatus.PENDING
            and all(dep in completed for dep in t.dependencies)
        ]

    def mark_completed(self, task_id: str, result: Any = None) -> None:
        if task_id in self._tasks:
            self._tasks[task_id].status = TaskStatus.COMPLETED
            self._tasks[task_id].result = result

    def mark_failed(self, task_id: str, error: str) -> None:
        if task_id in self._tasks:
            self._tasks[task_id].status = TaskStatus.FAILED
            self._tasks[task_id].error = error

    def is_complete(self) -> bool:
        return all(t.status == TaskStatus.COMPLETED for t in self._tasks.values())

    def has_failed(self) -> bool:
        return any(t.status == TaskStatus.FAILED for t in self._tasks.values())

    def failed_tasks(self) -> list[Task]:
        return [t for t in self._tasks.values() if t.status == TaskStatus.FAILED]

    def all_tasks(self) -> list[Task]:
        return list(self._tasks.values())

    def summary(self) -> str:
        lines = []
        for t in self._tasks.values():
            deps = f" (deps: {t.dependencies})" if t.dependencies else ""
            lines.append(f"  [{t.status.value}] {t.description}{deps}")
        return "\n".join(lines)
