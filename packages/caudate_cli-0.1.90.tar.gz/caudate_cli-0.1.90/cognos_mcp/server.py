"""Cognos MCP Server — expose all Cognos tools to external MCP clients.

Runs over stdio by default, matching the Claude Desktop / Claude Code
MCP conventions. Start with: `python3 -m cognos_mcp.server`.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from mcp.server.fastmcp import FastMCP

from execution.executor import Executor

logger = logging.getLogger(__name__)


def build_server() -> FastMCP:
    """Build a FastMCP server wrapping all Cognos tools."""
    server = FastMCP("cognos")
    executor = Executor()

    for name in executor.list_tools():
        tool = executor.get_tool(name)
        if tool is None:
            continue
        _register_tool(server, executor, tool)

    return server


def _register_tool(server: FastMCP, executor: Executor, tool) -> None:
    """Register a single Cognos tool with FastMCP.

    FastMCP infers the MCP tool schema from the Python function signature.
    We wrap each tool in an async shim that accepts **kwargs and delegates
    to the executor, then we manually attach the tool's input_schema via
    FastMCP's lower-level add_tool API.
    """
    name = tool.name
    description = tool.description

    async def _run(**kwargs: Any) -> str:
        result = await executor.execute_tool(name, kwargs)
        if result.status.value != "success":
            raise RuntimeError(result.error or "tool error")
        return str(result.output)

    _run.__name__ = name
    _run.__doc__ = description

    # FastMCP tool() decorator handles both registration and schema
    server.tool(name=name, description=description)(_run)


async def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    server = build_server()
    # FastMCP's default run() uses stdio
    await server.run_stdio_async()


if __name__ == "__main__":
    asyncio.run(main())
