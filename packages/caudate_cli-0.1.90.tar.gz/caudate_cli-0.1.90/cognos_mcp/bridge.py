"""MCP bridge — wrap a remote MCP tool as a local Cognos BaseTool."""

from __future__ import annotations

from typing import Any

from core.schemas import ToolResult
from execution.tools.base import BaseTool
from cognos_mcp.client import MCPClient


class MCPToolBridge(BaseTool):
    """Adapter: presents a remote MCP tool as a Cognos BaseTool."""

    def __init__(self, client: MCPClient, remote_tool: Any):
        self._client = client
        self._remote = remote_tool
        # Prefix name with server to avoid collisions
        self._name = f"{client.name}__{remote_tool.name}"
        self._description = remote_tool.description or f"MCP tool from {client.name}"
        # MCP tool objects expose input_schema as a dict
        self._schema = dict(remote_tool.inputSchema or {"type": "object", "properties": {}})

    @property
    def name(self) -> str:
        return self._name

    @property
    def description(self) -> str:
        return self._description

    @property
    def input_schema(self) -> dict[str, Any]:
        return self._schema

    async def execute(self, **kwargs: Any) -> ToolResult:
        try:
            output = await self._client.call(self._remote.name, kwargs)
            return self._success(output)
        except Exception as e:
            return self._error(str(e))
