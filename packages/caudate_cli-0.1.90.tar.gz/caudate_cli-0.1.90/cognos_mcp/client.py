"""MCP Client — connect to external MCP servers and list/call their tools."""

from __future__ import annotations

import logging
from contextlib import AsyncExitStack
from typing import Any

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

logger = logging.getLogger(__name__)


class MCPClient:
    """A single connection to one MCP server over stdio."""

    def __init__(
        self,
        name: str,
        command: str,
        args: list[str] | None = None,
        env: dict[str, str] | None = None,
    ):
        self.name = name
        self.command = command
        self.args = args or []
        self.env = env or {}
        self._session: ClientSession | None = None
        self._stack: AsyncExitStack | None = None
        self._tools: list[Any] = []

    async def connect(self) -> None:
        """Open the stdio connection and initialize the MCP session."""
        params = StdioServerParameters(
            command=self.command,
            args=self.args,
            env=self.env or None,
        )
        self._stack = AsyncExitStack()
        read, write = await self._stack.enter_async_context(stdio_client(params))
        self._session = await self._stack.enter_async_context(
            ClientSession(read, write)
        )
        await self._session.initialize()
        result = await self._session.list_tools()
        self._tools = list(result.tools)
        logger.info(f"MCP[{self.name}] connected with {len(self._tools)} tools")

    async def close(self) -> None:
        if self._stack is not None:
            await self._stack.aclose()
            self._stack = None
            self._session = None

    @property
    def tools(self) -> list[Any]:
        return self._tools

    async def call(self, tool_name: str, arguments: dict[str, Any]) -> str:
        if self._session is None:
            raise RuntimeError(f"MCP client {self.name!r} not connected")
        result = await self._session.call_tool(tool_name, arguments)
        # Extract text from MCP content blocks
        out_parts: list[str] = []
        for block in result.content or []:
            text = getattr(block, "text", None)
            if text:
                out_parts.append(text)
        return "\n".join(out_parts) if out_parts else "(no output)"
