"""Cognos MCP integration — server (exposes Cognos tools) and client (connects to external MCP servers).

Named `cognos_mcp` to avoid shadowing the installed `mcp` package.
"""
