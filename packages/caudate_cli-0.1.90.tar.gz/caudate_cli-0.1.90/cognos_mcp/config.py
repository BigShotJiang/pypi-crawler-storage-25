"""Load MCP server definitions from data/mcp_servers.json.

Format:
{
  "servers": [
    {
      "name": "filesystem",
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-filesystem", "/tmp"],
      "env": {"KEY": "value"}
    }
  ]
}
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


class MCPServerConfig(BaseModel):
    name: str
    command: str
    args: list[str] = Field(default_factory=list)
    env: dict[str, str] = Field(default_factory=dict)


def load_servers(path: Path) -> list[MCPServerConfig]:
    """Load MCP server configs from a JSON file, returning an empty list on miss."""
    if not path.exists():
        return []
    try:
        raw = json.loads(path.read_text())
    except Exception as e:
        logger.warning(f"Failed to parse MCP server config {path}: {e}")
        return []
    servers: list[MCPServerConfig] = []
    for entry in raw.get("servers", []):
        try:
            servers.append(MCPServerConfig.model_validate(entry))
        except Exception as e:
            logger.warning(f"Invalid MCP server entry {entry}: {e}")
    return servers
