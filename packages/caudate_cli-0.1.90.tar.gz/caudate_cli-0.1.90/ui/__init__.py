"""Cognos UI layer — rich-based terminal rendering."""

from ui.display import StreamDisplay

__all__ = ["StreamDisplay"]
