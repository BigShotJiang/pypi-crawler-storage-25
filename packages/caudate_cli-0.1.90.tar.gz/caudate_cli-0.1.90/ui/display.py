"""StreamDisplay — render agentic-loop stream events as clean inline text.

The thinking-block uses Claude-Code-style rotating verbs ("Brewing",
"Pondering", "Crunching", …) with a live elapsed-seconds counter,
flipping to past tense when the block closes ("Brewed for 7s").

Goals:
  - text_delta events stream tokens directly to stdout, no surrounding box
  - tool calls show as Claude-Code-style icon + name + summarised args:
      ⚡ Bash(ls /tmp)
      📄 Read(/etc/hosts)
      🔍 Grep("function" in src/)
  - while a tool is running, the line updates in place with elapsed
    time and a cancel hint, e.g. `⚡ Bash(ls /tmp)  (4s · ctrl+c to cancel)`.
    Once the tool result arrives the line is finalised and the result
    preview prints underneath.
  - no panels, no border lines, no live re-render flicker

Anything that wants pretty boxes can wrap the output itself.
"""

from __future__ import annotations

import asyncio
import json
import random
import sys
import time
from typing import Any

from rich.console import Console

from core.schemas import StreamEvent


# Rotating thinking verbs — Claude-Code-style fun gerunds with a
# matching past tense + a category-driven color. Categories:
#   warm   — cooking/heat verbs, rendered in yellow/orange
#   cool   — abstract reasoning verbs, rendered in cyan
#   purple — creative/synthesis verbs, rendered in magenta
# Each spin picks a verb at random and renders the live line in its
# category color; the past-tense finalize switches to dim grey so
# completed thoughts visibly recede into the scrollback.
_THINKING_VERBS: tuple[tuple[str, str, str], ...] = (
    # warm — food / heat metaphors
    ("Simmering",    "Simmered",    "warm"),
    ("Brewing",      "Brewed",      "warm"),
    ("Marinating",   "Marinated",   "warm"),
    ("Bubbling",     "Bubbled",     "warm"),
    ("Cooking",      "Cooked",      "warm"),
    ("Stewing",      "Stewed",      "warm"),
    ("Cooking up",   "Cooked up",   "warm"),
    ("Whisking",     "Whisked",     "warm"),
    ("Percolating",  "Percolated",  "warm"),
    # cool — pure reasoning
    ("Pondering",    "Pondered",    "cool"),
    ("Ruminating",   "Ruminated",   "cool"),
    ("Crunching",    "Crunched",    "cool"),
    ("Cogitating",   "Cogitated",   "cool"),
    ("Musing",       "Mused",       "cool"),
    ("Reasoning",    "Reasoned",    "cool"),
    ("Reflecting",   "Reflected",   "cool"),
    # purple — creative / synthesis
    ("Mulling",      "Mulled",      "purple"),
    ("Noodling",     "Noodled",     "purple"),
    ("Untangling",   "Untangled",   "purple"),
    ("Synthesizing", "Synthesized", "purple"),
)

# Category → rich-markup style for the LIVE (gerund) line.
_THINKING_LIVE_STYLE = {
    "warm":   "italic yellow",
    "cool":   "italic cyan",
    "purple": "italic magenta",
}

# Style applied to the past-tense finalization line — Claude-Code-style
# dim grey so completed thoughts recede.
_THINKING_DONE_STYLE = "dim italic"


# Tool → emoji icon. Anything not listed falls back to the generic "→"
# so unknown / plugin tools still get a clean rendering.
_TOOL_ICONS: dict[str, str] = {
    "Bash": "⚡",
    "PowerShell": "⚡",
    "Read": "📄",
    "Write": "📝",
    "Edit": "✏️",
    "NotebookEdit": "📒",
    "FillInMiddle": "🧩",
    "Glob": "📂",
    "Grep": "🔍",
    "FindAnywhere": "🔍",
    "SemanticSearch": "🧠",
    "WebSearch": "🌐",
    "WebFetch": "🌐",
    "HttpRequest": "🌐",
    "PythonExec": "🐍",
    "Think": "💭",
    "Respond": "💬",
    "Agent": "🤝",
    "Subagent": "🤝",
    "Draw": "🎨",
    "EditImage": "🖌️",
    "DescribeImage": "👁️",
    "Storyboard": "🎬",
    "LongCatAvatar": "🎭",
    "TranscribeAudio": "🎙️",
    "Speak": "🔊",
    "Calculator": "🧮",
    "DateTime": "📅",
    "SystemInfo": "🖥️",
    "Sandbox": "📦",
    "EnterWorktree": "🌿",
    "ExitWorktree": "🌿",
    "EnterPlanMode": "📋",
    "ExitPlanMode": "📋",
    "TaskCreate": "✅",
    "TaskList": "✅",
    "TaskGet": "✅",
    "TaskUpdate": "✅",
    "TaskStop": "✅",
    "TaskOutput": "✅",
    "CronCreate": "⏰",
    "CronList": "⏰",
    "CronDelete": "⏰",
    "PushNotification": "🔔",
    "AskUserQuestion": "❓",
    "MCPListServers": "🔌",
    "UpdateMemory": "🧠",
    "LoadSkill": "📚",
    "RescanSkills": "📚",
    "CognosCard": "💳",
    "Artifact": "📎",
    "OpenAPI": "🔧",
    "Agentic": "🤖",
    "AgenticBrowse": "🤖",
}

# Tool-name colours so the eye can scan a long transcript and group at
# a glance. Greenish family = filesystem & code; bluish = network &
# search; purplish = LLM/think; orange = exec & shell.
_TOOL_COLORS: dict[str, str] = {
    "Bash": "yellow",
    "PowerShell": "yellow",
    "Read": "green",
    "Write": "green",
    "Edit": "green",
    "FillInMiddle": "green",
    "Glob": "cyan",
    "Grep": "cyan",
    "FindAnywhere": "cyan",
    "WebSearch": "cyan",
    "WebFetch": "cyan",
    "HttpRequest": "cyan",
    "PythonExec": "yellow",
    "Think": "magenta",
    "Respond": "magenta",
    "Draw": "magenta",
    "EditImage": "magenta",
}


class StreamDisplay:
    """Consumes StreamEvents from AgenticLoop.run_streaming and prints them.

    Thinking tokens are buffered and rendered as a single continuous
    "thinking" block (✻ Thinking… header + dim italic body) instead of
    being spat out one-token-per-line. The block ends as soon as a
    text or tool event arrives, mirroring Claude Code's behaviour.
    """

    def __init__(self, console: Console | None = None):
        self.console = console or Console()
        self._text: list[str] = []
        self._wrote_text = False
        # Thinking-block state
        self._thinking_open = False
        self._thinking_verb: tuple[str, str, str] | None = None
        self._thinking_start_ts: float | None = None
        self._thinking_tick_task: asyncio.Task | None = None
        self._thinking_effort: str | None = None  # "low" | "medium" | "high"
        # Live-running tool state
        self._active_tool: tuple[str, str, str] | None = None  # (icon, name, args)
        self._tool_start_ts: float | None = None
        self._tool_line_printed: bool = False
        self._tick_task: asyncio.Task | None = None
        # When paused, ticker loops skip repaints — used by the
        # permission prompt to stop the live ticker from clobbering
        # the prompt_toolkit Application that draws the menu.
        self._paused: bool = False
        # Effort source — caller can register a getter so the long-
        # thinking suffix can mention "with X effort".
        self._effort_getter = None
        # Register as the active display so the permission prompt can
        # find us to pause tickers while it's drawing.
        _set_active_display(self)

    def pause(self) -> None:
        """Stop ticker repaints. Existing `_active_tool` state is
        preserved; resume() picks up where we left off."""
        self._paused = True

    def resume(self) -> None:
        self._paused = False

    # ------------------------------------------------------------------
    # Bash line streaming — called by execution/tools/shell_tool.py for
    # each stdout/stderr line so the user sees long-running commands
    # (apt, make, tests) progress in real time.
    # ------------------------------------------------------------------
    def on_bash_line(self, kind: str, line: str) -> None:
        # First streamed line for this Bash call: pause the elapsed-time
        # ticker (otherwise it would repaint on top of our streamed
        # output) and drop down to a fresh line.
        if not getattr(self, "_bash_streaming", False):
            self._bash_streaming = True
            self._paused = True
            self.console.file.write("\n")
        try:
            self.console.print(f"  [dim]│[/dim] {line}")
        except Exception:
            self.console.file.write(f"  | {line}\n")
        self.console.file.flush()

    def on_bash_done(self) -> None:
        # Resume tickers and finalize the active tool line so the next
        # status update appears below the streamed output.
        if getattr(self, "_bash_streaming", False):
            self._bash_streaming = False
            self._paused = False
            if self._active_tool is not None:
                self._finalize_active_tool()

    # ------------------------------------------------------------------
    # Live todo checklist — TodoWriteTool calls this on each update.
    #
    # Earlier versions tried to re-render the full block in place via
    # ANSI cursor moves, but the active-tool ticker + finalize lines
    # interleave between consecutive TodoWrite calls, so the rewind
    # erased the wrong region and the blocks stacked. We now print the
    # full checklist only once per turn (the first call), and emit a
    # compact one-line delta on subsequent calls. The tool result line
    # already carries the aggregate counts.
    # ------------------------------------------------------------------
    def reset_todo_state(self) -> None:
        """Called by the agent loop at the start of each user turn."""
        self._todo_first_shown = False
        self._todo_last_active = None

    def on_todo_write(self, todos: list[dict]) -> None:
        if not todos:
            return

        glyphs = {
            "pending":     "[dim]☐[/dim]",
            "in_progress": "[bold yellow]◐[/bold yellow]",
            "completed":   "[green]☑[/green]",
        }
        styles = {
            "pending":     "dim",
            "in_progress": "bold",
            "completed":   "dim strike",
        }

        first_shown = getattr(self, "_todo_first_shown", False)

        if not first_shown:
            self.console.print("  [bold]Todos[/bold]")
            for t in todos:
                status = t.get("status", "pending")
                glyph = glyphs.get(status, "·")
                style = styles.get(status, "")
                label = t["content"]
                if status == "in_progress" and t.get("activeForm"):
                    label = t["activeForm"]
                self.console.print(f"    {glyph} [{style}]{label}[/{style}]")
            self._todo_first_shown = True
            # Snapshot the status of each item, keyed by the stable
            # `content` field (the immutable description). `activeForm`
            # wording wobbles between LLM calls — comparing on that
            # would spam the screen.
            self._todo_status_by_content = {
                t["content"]: t.get("status", "pending") for t in todos
            }
            return

        # Subsequent calls: print only real status transitions. The
        # LLM sometimes paraphrases the entire todo list between
        # calls (different content strings, same semantic plan), so
        # we count items first: if the in_progress count is unchanged
        # and exactly ONE item is in_progress in both old and new
        # state, treat it as a paraphrase and stay silent. Real
        # changes are detected by *count* shifts (a completion turns
        # an in_progress into a done) — those still print.
        prev: dict[str, str] = getattr(self, "_todo_status_by_content", {})
        new_status = {t["content"]: t.get("status", "pending") for t in todos}

        def _counts(d: dict[str, str]) -> tuple[int, int, int]:
            done = sum(1 for v in d.values() if v == "completed")
            inp  = sum(1 for v in d.values() if v == "in_progress")
            pen  = sum(1 for v in d.values() if v == "pending")
            return done, inp, pen

        if _counts(prev) == _counts(new_status):
            # Counts unchanged — likely a paraphrase. Skip entirely.
            self._todo_status_by_content = new_status
            return

        # Counts changed — something real transitioned. Print the
        # delta. To handle paraphrasing, transitions are detected by
        # status COUNT changes per bucket, not per-content match.
        prev_done = {c for c, s in prev.items() if s == "completed"}
        new_done  = {c for c, s in new_status.items() if s == "completed"}
        prev_inp  = {c for c, s in prev.items() if s == "in_progress"}
        new_inp   = {c for c, s in new_status.items() if s == "in_progress"}

        # Newly completed items.
        for content in new_done - prev_done:
            self.console.print(
                f"    [green]☑[/green] [dim strike]{content}[/dim strike]"
            )
        # Newly in-progress items.
        for t in todos:
            if t.get("status") != "in_progress":
                continue
            if t["content"] in prev_inp:
                continue
            label = t.get("activeForm") or t["content"]
            self.console.print(
                f"    [bold yellow]◐[/bold yellow] [bold]{label}[/bold]"
            )
        self._todo_status_by_content = new_status

    def set_effort_getter(self, fn) -> None:
        """Register a callable returning the current effort level
        ('low' | 'medium' | 'high'). Used in the >=15s thinking
        suffix."""
        self._effort_getter = fn

    async def render(self, stream) -> str:
        self._text = []
        self._wrote_text = False
        self._thinking_open = False
        self._thinking_started_header = False
        # Heartbeat: if the model hasn't sent any event within ~1.2s,
        # show a "waiting for model" ticker so the user can tell
        # "slow LLM" from "process hung." Cancels on first event.
        self._waiting_tick_task = asyncio.create_task(self._waiting_tick_loop())
        self._waiting_line_printed = False
        self._waiting_start_ts = time.monotonic()

        try:
            async for event in stream:
                self._cancel_waiting_tick()
                self._handle(event)
        finally:
            # Make sure any live ticker / open block is properly torn
            # down even if the stream raised mid-flight.
            self._cancel_waiting_tick()
            self._stop_tick()
            if self._active_tool is not None:
                self._finalize_active_tool()
            self._close_thinking()
        if self._wrote_text:
            streamed = "".join(self._text)
            # If the streamed text contains markdown features that don't
            # render well as plain text (fenced code, headers, bold,
            # links), erase the streamed lines and re-render with Rich.
            # Plain prose is left alone (already looked fine).
            if _has_renderable_markdown(streamed):
                self._erase_streamed_text(streamed)
                try:
                    from rich.markdown import Markdown
                    self.console.print(Markdown(streamed))
                except Exception:
                    # If rendering fails for any reason, fall back to
                    # the raw streamed text — better than nothing.
                    self.console.file.write(streamed + "\n")
                    self.console.file.flush()
            else:
                self.console.file.write("\n")
                self.console.file.flush()
        return "".join(self._text)

    def _erase_streamed_text(self, streamed: str) -> None:
        """ANSI-erase the just-streamed text so we can re-render it.

        Counts newlines as a proxy for visual lines. Wrapped lines may
        leave a small remnant; acceptable for the typical case.
        """
        newlines = streamed.count("\n")
        self.console.file.write("\r")
        if newlines > 0:
            self.console.file.write(f"\033[{newlines}A")
        self.console.file.write("\033[J")  # clear to end of screen
        self.console.file.flush()

    # ------------------------------------------------------------------

    def _handle(self, event: StreamEvent) -> None:
        t = event.type
        if t == "text_delta" and event.delta:
            self._close_thinking()
            self._text.append(event.delta)
            self.console.file.write(event.delta)
            self.console.file.flush()
            self._wrote_text = True
        elif t == "tool_use_end":
            # The LLM has finished asking for this tool — actual exec
            # is about to begin. Print the tool line, start an in-place
            # elapsed-time ticker, and remember the start time so we
            # can finalise on tool_result.
            self._close_thinking()
            self._flush_newline()
            args = _summarize_args(event.tool_input or {})
            name = event.tool_name or ""
            icon = _TOOL_ICONS.get(name, "→")
            color = _TOOL_COLORS.get(name, "white")
            self._active_tool = (icon, name, args)
            self._tool_start_ts = time.time()
            self._render_active_tool(elapsed=0, first=True)
            # Spawn a background ticker that rewrites the line each
            # second. Cancelled when tool_result arrives.
            try:
                self._tick_task = asyncio.create_task(self._tick_loop())
            except RuntimeError:
                # Not in an async context — skip the live ticker, the
                # static line is good enough.
                self._tick_task = None
        elif t == "tool_result":
            self._close_thinking()
            self._stop_tick()
            self._finalize_active_tool()
            preview = (event.delta or "").strip().splitlines()[0] if event.delta else ""
            if len(preview) > 160:
                preview = preview[:157] + "…"
            if preview:
                self.console.print(f"  [dim]↳ {preview}[/dim]")
        elif t == "thinking_delta" and event.delta:
            # We *don't* render thinking tokens directly anymore —
            # Claude Code shows a status line with elapsed time only,
            # not the raw chain-of-thought. The first delta opens the
            # block (which starts the timer); subsequent deltas just
            # keep the timer ticking.
            self._open_thinking()
        # message_start / message_stop: nothing to render

    def _open_thinking(self) -> None:
        if self._thinking_open:
            return
        self._flush_newline()
        self._thinking_verb = random.choice(_THINKING_VERBS)
        self._thinking_start_ts = time.time()
        self._thinking_open = True
        self._render_thinking_line(elapsed=0, first=True)
        try:
            self._thinking_tick_task = asyncio.create_task(self._thinking_tick_loop())
        except RuntimeError:
            self._thinking_tick_task = None

    def _close_thinking(self) -> None:
        if not self._thinking_open:
            return
        # Cancel ticker
        if self._thinking_tick_task is not None:
            self._thinking_tick_task.cancel()
            self._thinking_tick_task = None
        elapsed_f = time.time() - (self._thinking_start_ts or time.time())
        # If thinking was effectively instant (<1s), just erase the
        # live line — printing "Cooked for 0s" reads as noise.
        if elapsed_f < 1:
            self.console.file.write("\r\033[2K")
            self.console.file.flush()
        else:
            self._rewrite_thinking_line_finalised(int(elapsed_f))
        self._thinking_open = False
        self._thinking_verb = None
        self._thinking_start_ts = None

    def _render_thinking_line(self, elapsed: int, first: bool = False) -> None:
        """Print the live thinking-status line (gerund + elapsed).

        The line is rendered in the verb's category color (warm/cool/
        purple) so successive thinking blocks feel visually varied.
        """
        if self._thinking_verb is None:
            return
        gerund = self._thinking_verb[0]
        category = self._thinking_verb[2] if len(self._thinking_verb) > 2 else "cool"
        style = _THINKING_LIVE_STYLE.get(category, "italic cyan")
        # Build the colored line:
        #   ✦ Simmering… (3s)
        # or after a while:
        #   ✦ Simmering… (18s · still thinking with high effort)
        suffix = f"({elapsed}s)"
        if elapsed >= 15:
            effort = None
            if self._effort_getter is not None:
                try:
                    effort = self._effort_getter()
                except Exception:
                    effort = None
            if effort and effort != "medium":
                suffix = f"({elapsed}s · still thinking with {effort} effort)"
            else:
                suffix = f"({elapsed}s · still thinking)"
        line = f"[{style}]✦ {gerund}… {suffix}[/{style}]"
        if not first:
            # Repaint same row
            self.console.file.write("\r\033[2K")
            self.console.file.flush()
        # Print without newline so we can keep overwriting in place.
        self.console.print(line, end="")

    def _rewrite_thinking_line_finalised(self, elapsed: int) -> None:
        """Replace the live line with the past-tense final version.

        Past-tense is always dim grey so completed thoughts visibly
        recede into the scrollback — only the live "in motion" line
        gets the eye-catching category color.
        """
        if self._thinking_verb is None:
            return
        past = self._thinking_verb[1]
        self.console.file.write("\r\033[2K")
        self.console.file.flush()
        line = (
            f"[{_THINKING_DONE_STYLE}]✦ {past} for {elapsed}s[/{_THINKING_DONE_STYLE}]"
        )
        self.console.print(line)  # adds newline

    async def _thinking_tick_loop(self) -> None:
        try:
            while self._thinking_open and self._thinking_start_ts is not None:
                await asyncio.sleep(1.0)
                if not self._thinking_open:
                    return
                if self._paused:
                    continue
                elapsed = int(time.time() - self._thinking_start_ts)
                self._render_thinking_line(elapsed=elapsed, first=False)
        except asyncio.CancelledError:
            pass

    def _flush_newline(self) -> None:
        if self._wrote_text:
            self.console.file.write("\n")
            self.console.file.flush()
            self._wrote_text = False

    # ------------------------------------------------------------------
    # Live tool-execution rendering
    # ------------------------------------------------------------------
    def _render_active_tool(self, elapsed: int, first: bool = False) -> None:
        """Print or rewrite the active tool line.

        `first=True` prints on a fresh line; subsequent calls use ANSI
        `\\r\\033[2K` to return to column 0 and clear the row before
        re-rendering — gives the in-place updating effect without
        Rich's Live() machinery.

        The visible string is hard-truncated to one terminal row so
        wrapped lines don't accumulate every tick (each wrap would
        leave a stale row that `\\r\\033[2K` can't reach).
        """
        if self._active_tool is None:
            return
        icon, name, args = self._active_tool
        color = _TOOL_COLORS.get(name, "white")

        # Width budget — fall back to 80 if size detection fails.
        try:
            term_w = max(40, self.console.size.width)
        except Exception:
            term_w = 80

        # Build the suffix first so we know how much room args have.
        suffix_plain = f"  ({elapsed}s · ctrl+c to cancel)" if elapsed >= 1 else ""
        # Visible-char budget for the args (icon + 2sp + name + parens + suffix).
        # icon is roughly 2 cols, plus 2 spaces, plus name, plus "(...)" wrappers.
        head = f"{icon}  {name}("
        tail = f"){suffix_plain}"
        budget = term_w - len(head) - len(tail) - 1
        if budget < 8:
            args_short = ""
        elif len(args) > budget:
            args_short = args[: budget - 1] + "…"
        else:
            args_short = args

        suffix_markup = f"  [dim]({elapsed}s · ctrl+c to cancel)[/dim]" if elapsed >= 1 else ""
        if not first:
            # \r → start of line, \033[2K → clear entire line. Works
            # only when the row hasn't wrapped — which is why we
            # truncated above.
            self.console.file.write("\r\033[2K")
            self.console.file.flush()
        self.console.print(
            f"{icon}  [bold {color}]{name}[/bold {color}]"
            f"[dim]({args_short})[/dim]{suffix_markup}",
            end=("" if elapsed >= 1 else "\n"),
            soft_wrap=True,
            overflow="ignore",
            crop=False,
            highlight=False,
        )
        self._tool_line_printed = True

    def _finalize_active_tool(self) -> None:
        """Tool finished — make sure the line ends with a newline so
        subsequent output starts on a clean row."""
        if self._active_tool is not None:
            # If we never updated past the initial print, we already
            # emitted a newline. Otherwise the line is "hot" and we
            # need to terminate it.
            if self._tool_start_ts and (time.time() - self._tool_start_ts) >= 1:
                self.console.file.write("\n")
                self.console.file.flush()
        self._active_tool = None
        self._tool_start_ts = None
        self._tool_line_printed = False

    async def _tick_loop(self) -> None:
        """Update the active tool line once a second while running."""
        try:
            while self._active_tool is not None and self._tool_start_ts is not None:
                await asyncio.sleep(1.0)
                if self._active_tool is None:
                    return
                if self._paused:
                    continue
                elapsed = int(time.time() - self._tool_start_ts)
                self._render_active_tool(elapsed=elapsed, first=False)
        except asyncio.CancelledError:
            pass

    def _stop_tick(self) -> None:
        if self._tick_task is not None:
            self._tick_task.cancel()
            self._tick_task = None

    async def _waiting_tick_loop(self) -> None:
        """Show 'waiting for model...' if no events arrive within 1.2s.

        Repaints once per second with elapsed time so the user knows
        the agent isn't hung — it's just waiting on the LLM.
        """
        try:
            await asyncio.sleep(1.2)
            # Still waiting? Print the initial line via console so the
            # rich markup ([dim]…[/dim]) renders correctly. Subsequent
            # repaints use raw ANSI for in-place rewrite.
            self.console.print("  [dim]✦ waiting for model… (1s)[/dim]")
            self._waiting_line_printed = True
            while True:
                await asyncio.sleep(1.0)
                if self._paused:
                    continue
                elapsed = int(time.monotonic() - self._waiting_start_ts)
                # Erase prior line + reprint with new elapsed time.
                self.console.file.write("\033[1A\r\033[2K")
                self.console.file.write(
                    f"  \033[2m✦ waiting for model… ({elapsed}s)\033[0m\n"
                )
                self.console.file.flush()
        except asyncio.CancelledError:
            # On cancel, erase the waiting line entirely so it doesn't
            # linger above the first real event.
            if self._waiting_line_printed:
                try:
                    self.console.file.write("\033[1A\r\033[2K")
                    self.console.file.flush()
                except Exception:
                    pass
                self._waiting_line_printed = False

    def _cancel_waiting_tick(self) -> None:
        task = getattr(self, "_waiting_tick_task", None)
        if task is not None and not task.done():
            task.cancel()
        self._waiting_tick_task = None


def _summarize_args(args: dict[str, Any]) -> str:
    """Render tool args as `key="value", key2=N` — Claude-Code-style.

    Strings are double-quoted and shortened; lists/dicts shrink to a
    truncated repr. Falls back to JSON if the dict is weird.
    """
    if not isinstance(args, dict) or not args:
        try:
            return json.dumps(args, ensure_ascii=False)
        except (TypeError, ValueError):
            return str(args)
    parts: list[str] = []
    for k, v in args.items():
        if isinstance(v, str):
            short = v if len(v) <= 60 else v[:57] + "…"
            parts.append(f'{k}="{short}"')
        elif isinstance(v, (int, float, bool)) or v is None:
            parts.append(f"{k}={v}")
        else:
            try:
                rendered = json.dumps(v, ensure_ascii=False)
            except (TypeError, ValueError):
                rendered = str(v)
            if len(rendered) > 60:
                rendered = rendered[:57] + "…"
            parts.append(f"{k}={rendered}")
    s = ", ".join(parts)
    if len(s) > 180:
        s = s[:177] + "…"
    return s


# ---------------------------------------------------------------------
# Module-level registry so the permission prompt (which lives outside
# this module) can find the active StreamDisplay to pause its tickers
# while the prompt_toolkit menu is drawn.
# ---------------------------------------------------------------------
_active_display: "StreamDisplay | None" = None


def _set_active_display(display: "StreamDisplay") -> None:
    global _active_display
    _active_display = display


def get_active_display() -> "StreamDisplay | None":
    return _active_display


# Markdown-feature detection: returns True if the text contains
# constructs that don't render legibly as plain text.
_MD_HEADING = __import__("re").compile(r"(^|\n)#{1,6}\s")
_MD_BOLD = __import__("re").compile(r"\*\*[^\s*][^*]*\*\*")
_MD_LINK = __import__("re").compile(r"\[[^\]]+\]\([^)]+\)")


def _has_renderable_markdown(text: str) -> bool:
    if not text:
        return False
    if text.startswith("```") or "\n```" in text:
        return True
    if _MD_HEADING.search(text):
        return True
    if _MD_BOLD.search(text):
        return True
    if _MD_LINK.search(text):
        return True
    return False
