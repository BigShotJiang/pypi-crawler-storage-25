"""Training loop for Caudate.

Multi-task loss across the four heads, weighted by `cfg.w_*`. Uses Adam
with weight decay, gradient clipping, and a step-LR scheduler. Eval split
is held-out from the corpus and run every `cfg.eval_every` steps.

Checkpoint format: a single `.pt` file containing model state, optimizer
state, scheduler state, training step, and the tool vocab. Sidecar
`.meta.json` records the active config so loaders can reject mismatched
architectures.
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import torch
import torch.nn as nn
from torch.optim import AdamW
from torch.optim.lr_scheduler import StepLR

from nn.config import NNConfig
from nn.caudate import Caudate
from nn.data import (
    ConversationSample, ReplayBuffer, SourceVocab, ToolVocab,
    collate, iter_batches, load_corpus_from_sessions, split_train_eval,
)
from nn.format import ChatMessage
from nn.heads import head_accuracy, head_loss

logger = logging.getLogger(__name__)


@dataclass
class TrainMetrics:
    step: int = 0
    loss_total: float = 0.0
    loss_tool: float = 0.0
    loss_tier: float = 0.0
    loss_think: float = 0.0
    loss_value: float = 0.0
    tool_acc: float = 0.0
    tier_acc: float = 0.0
    think_acc: float = 0.0
    elapsed_s: float = 0.0


@dataclass
class Trainer:
    cfg: NNConfig
    model: Caudate
    vocab: ToolVocab
    source_vocab: SourceVocab = field(default_factory=lambda: SourceVocab())
    optimizer: AdamW = field(init=False)
    scheduler: StepLR = field(init=False)
    device: torch.device = field(init=False)
    step: int = 0
    history: list[TrainMetrics] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model.to(self.device)
        self.optimizer = AdamW(
            self.model.parameters(),
            lr=self.cfg.learning_rate,
            weight_decay=self.cfg.weight_decay,
            betas=(0.9, 0.95),
        )
        self.scheduler = StepLR(self.optimizer, step_size=1000, gamma=0.5)
        torch.manual_seed(self.cfg.seed)

    # ------------------------------------------------------------------
    # Forward + loss
    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # Tier 3 — self-supervised auxiliary loss
    # ------------------------------------------------------------------
    # Mask one of the recent messages in 30% of samples and require the
    # trunk to produce a pooled CLS close to the unmasked version. This
    # is "masked context reconstruction" — the standard self-supervised
    # pre-training pattern (BERT-style masking, but applied at the
    # message granularity instead of the token granularity, since
    # Caudate's encoder works on whole messages not tokens).
    #
    # No external labels needed — the unmasked CLS is the label.
    # Effect: the trunk learns representations that are robust to
    # partial context, which lifts every downstream head's accuracy.
    _AUX_MASK_PROB = 0.30
    _AUX_LOSS_WEIGHT = 0.05

    def _aux_masked_message_loss(
        self,
        batch: dict[str, Any],
        full_pooled: torch.Tensor,
    ) -> torch.Tensor | None:
        """Self-supervised auxiliary: re-encode batch with one message
        zeroed, return cosine-distance between masked and unmasked
        pooled CLS. Returns None when there are no messages to mask
        (so loss isn't applied to that batch).
        """
        import random
        messages = batch.get("messages") or []
        if not messages:
            return None

        # Mask out one random message per sample (in-place would mutate
        # the batch; copy first).
        masked: list[list[str]] = []
        any_masked = False
        for msg_window in messages:
            if not msg_window:
                masked.append(list(msg_window))
                continue
            # Find non-empty positions (skip pad-empty strings) and
            # only fire the mask probabilistically.
            non_empty = [i for i, m in enumerate(msg_window) if m]
            if non_empty and random.random() < self._AUX_MASK_PROB:
                copy = list(msg_window)
                copy[random.choice(non_empty)] = ""
                masked.append(copy)
                any_masked = True
            else:
                masked.append(list(msg_window))
        if not any_masked:
            return None

        masked_out = self.model(
            messages=masked,
            tool_ids=batch["tool_ids"].to(self.device),
            mood=batch["mood"].to(self.device),
            image_paths=batch.get("image_paths"),
            source_id=(batch.get("source_id").to(self.device)
                       if batch.get("source_id") is not None else None),
        )
        masked_pooled = masked_out["pooled"]
        # Cosine-distance loss: 1 - cos(sim) so it's ≥ 0 and 0 means
        # identical representation.
        cos = nn.functional.cosine_similarity(
            full_pooled, masked_pooled, dim=-1
        )
        return (1.0 - cos).mean()

    # Loss weight for the contrastive tool head. Roughly matches the
    # old fixed-vocab tool head's weight (1.0) so its gradient
    # contribution to the trunk stays similar after the migration.
    _W_TOOL_CONTRASTIVE = 1.0

    def _forward_with_loss(self, batch: dict[str, Any]) -> tuple[torch.Tensor, dict[str, float]]:
        out = self.model(
            messages=batch["messages"],
            tool_ids=batch["tool_ids"].to(self.device),
            mood=batch["mood"].to(self.device),
            image_paths=batch.get("image_paths"),
            source_id=(batch.get("source_id").to(self.device)
                       if batch.get("source_id") is not None else None),
            tool_specs=batch.get("tool_specs"),
        )

        # Iterate registered heads — each head computes its own loss
        # using the spec's `loss_type` and `loss_weight`. Heads marked
        # `optional_target` whose target is missing from the batch are
        # silently skipped, so adding new heads doesn't require
        # backfilling labels for the old corpus.
        total = torch.zeros((), device=self.device)
        metrics: dict[str, float] = {}

        # Custom path: contrastive tool head. Only runs when the model
        # actually produced tool_logits (i.e. at least one sample had
        # candidate tools). Per-sample skipping handled by the valid
        # mask — samples whose target_tool isn't in their candidate
        # list contribute zero to the loss.
        if "tool_logits" in out:
            from nn.heads import ContrastiveToolHead as _CTH
            tool_logits = out["tool_logits"]                 # (B, K)
            target_idx = batch["target_tool_idx"].to(self.device)
            valid = batch["tool_target_valid"].to(self.device)
            # Phase 1.3: outcome-weighted loss. Per-sample weight is
            # `1 + strength × outcome_reward`. With strength=0.5 (default)
            # and outcome_reward∈[-1,+1], weight∈[0.5, 1.5] — modest
            # amplification of good turns / dampening of bad ones.
            # Samples without an outcome signal (outcome_valid=False)
            # get weight 1.0 — same as before.
            outcome_strength = float(getattr(self.cfg, "outcome_weight_strength", 0.5))
            sample_weight = None
            if outcome_strength > 0.0:
                oc_reward = batch.get("outcome_reward")
                oc_valid = batch.get("outcome_valid")
                if oc_reward is not None and oc_valid is not None:
                    oc_reward = oc_reward.to(self.device)
                    oc_valid = oc_valid.to(self.device)
                    if bool(oc_valid.any()):
                        # weight = 1 where invalid (neutral), else 1 + s·r
                        sample_weight = torch.ones_like(oc_reward)
                        sample_weight = torch.where(
                            oc_valid,
                            1.0 + outcome_strength * oc_reward,
                            sample_weight,
                        ).clamp_min(0.0)
                        metrics["outcome_weighted_rows"] = float(oc_valid.sum().item())
            tool_loss = _CTH.contrastive_loss(
                tool_logits, target_idx, valid,
                slot_0_weight=getattr(self.cfg, "tool_no_tool_class_weight", 1.0),
                sample_weight=sample_weight,
            )
            total = total + self._W_TOOL_CONTRASTIVE * tool_loss
            metrics["loss_tool"] = tool_loss.item()
            # Top-1 accuracy on rows that had a valid target
            if bool(valid.any()):
                preds = tool_logits.argmax(dim=-1)
                correct = (preds == target_idx)[valid].float().mean().item()
                metrics["tool_acc"] = correct
            else:
                metrics["tool_acc"] = 0.0
        else:
            # No tool candidates in this batch — tool head sits out.
            metrics["loss_tool"] = 0.0
            metrics["tool_acc"] = 0.0

        for spec in self.model.head_specs:
            # The next_prompt head uses a special path (cosine alignment
            # with the next message's embedding). Skip the generic loss
            # iteration for it; it gets handled by the aux loss path.
            if spec.name == "next_prompt":
                continue
            target = batch.get(spec.target)
            if target is None:
                if spec.optional_target:
                    continue
                raise KeyError(
                    f"head {spec.name!r} requires target field {spec.target!r} "
                    f"but it is missing from batch"
                )
            target = target.to(self.device)
            output = out[spec.output_key]
            loss = head_loss(spec, output, target)
            total = total + spec.loss_weight * loss
            metrics[f"loss_{spec.name}"] = loss.item()
            acc = head_accuracy(spec, output, target)
            if acc is not None:
                metrics[f"{spec.name}_acc"] = acc

        # Tier 3 — masked-message self-supervised auxiliary
        if self.model.training:
            aux = self._aux_masked_message_loss(batch, out["pooled"])
            if aux is not None:
                total = total + self._AUX_LOSS_WEIGHT * aux
                metrics["aux_masked_msg"] = aux.item()

        metrics["loss_total"] = total.item()
        return total, metrics

    # ------------------------------------------------------------------
    # Train / eval
    # ------------------------------------------------------------------

    def train_step(self, batch: dict[str, Any]) -> dict[str, float]:
        self.model.train()
        loss, metrics = self._forward_with_loss(batch)
        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.cfg.grad_clip)
        self.optimizer.step()
        self.scheduler.step()
        self.step += 1
        return metrics

    @torch.no_grad()
    def evaluate(self, samples: list[ConversationSample]) -> dict[str, float]:
        self.model.eval()
        if not samples:
            return {}
        agg: dict[str, float] = {}
        n_batches = 0
        for batch in iter_batches(samples, self.cfg.batch_size, self.cfg, self.vocab, shuffle=False, source_vocab=self.source_vocab):
            _, m = self._forward_with_loss(batch)
            for k, v in m.items():
                agg[k] = agg.get(k, 0.0) + v
            n_batches += 1
        for k in list(agg):
            agg[k] /= max(1, n_batches)
        return agg

    # ------------------------------------------------------------------
    # Top-level fit
    # ------------------------------------------------------------------

    def fit(
        self,
        corpus: list[ConversationSample],
        replay: ReplayBuffer | None = None,
    ) -> list[TrainMetrics]:
        # Register every tool name in the corpus into the vocab BEFORE
        # we touch collate. Without this, `vocab.get(target_tool)`
        # returns the <unk> slot for every unregistered tool, every
        # training sample collapses to the same target, and the model
        # learns "always predict <unk>". This was a silent failure
        # mode for several training cycles before being caught — the
        # eval metric reported high accuracy because eval targets were
        # all <unk> too. End-to-end predict() smoke test is the only
        # way to catch it.
        before = len(self.vocab)
        for s in corpus:
            if s.target_tool:
                self.vocab.add(s.target_tool)
        if replay is not None:
            for s in replay.all():
                if s.target_tool:
                    self.vocab.add(s.target_tool)
        added = len(self.vocab) - before
        if added > 0:
            logger.info(
                f"vocab registered {added} new tool(s); now size={len(self.vocab)}"
            )

        train, evaluation = split_train_eval(
            corpus, self.cfg.eval_split, self.cfg.seed,
        )
        if not train and (replay is None or len(replay) == 0):
            logger.warning("No training samples — fit() is a no-op")
            return self.history

        logger.info(
            f"fit: model_params={self.model.num_parameters():,}  "
            f"train={len(train)}  eval={len(evaluation)}  "
            f"replay={len(replay) if replay else 0}  device={self.device}"
        )

        start = time.time()
        train_iter = iter([])
        last_eval: dict[str, float] = {}

        while self.step < self.cfg.max_steps:
            batch = self._next_batch(train, replay, train_iter)
            if batch is None:
                # restart epoch
                train_iter = iter_batches(train, self.cfg.batch_size, self.cfg, self.vocab, source_vocab=self.source_vocab)
                batch = next(train_iter, None)
                if batch is None:
                    break

            m = self.train_step(batch)

            if self.step % 10 == 0:
                logger.debug(
                    f"step={self.step}  loss={m['loss_total']:.4f}  "
                    f"tool_acc={m['tool_acc']:.2f}  tier_acc={m['tier_acc']:.2f}"
                )

            if self.step % self.cfg.eval_every == 0 and evaluation:
                # During training: cap eval to a fixed subset for speed.
                # Full eval landed at end of fit() (line below).
                cap = self.cfg.eval_max_batches_intra * self.cfg.batch_size
                eval_subset = evaluation[:cap] if cap > 0 else evaluation
                last_eval = self.evaluate(eval_subset)
                logger.info(
                    f"[eval @ {self.step}] loss={last_eval.get('loss_total', 0):.4f}  "
                    f"tool_acc={last_eval.get('tool_acc', 0):.2f}  "
                    f"tier_acc={last_eval.get('tier_acc', 0):.2f}  "
                    f"think_acc={last_eval.get('think_acc', 0):.2f}  "
                    f"(eval n={len(eval_subset)})"
                )

            if self.step % self.cfg.save_every == 0:
                self.save()

            self.history.append(TrainMetrics(
                step=self.step,
                loss_total=m["loss_total"], loss_tool=m["loss_tool"],
                loss_tier=m["loss_tier"], loss_think=m["loss_think"],
                loss_value=m["loss_value"],
                tool_acc=m["tool_acc"], tier_acc=m["tier_acc"], think_acc=m["think_acc"],
                elapsed_s=time.time() - start,
            ))

        self.save()
        if evaluation:
            last_eval = self.evaluate(evaluation)
            logger.info(f"[final eval] {last_eval}")
        return self.history

    def _next_batch(
        self,
        train: list[ConversationSample],
        replay: ReplayBuffer | None,
        train_iter: Any,
    ) -> dict[str, Any] | None:
        # Mix offline corpus (train) with online replay if both exist.
        if replay is not None and len(replay) >= self.cfg.batch_size and train:
            half = self.cfg.batch_size // 2
            samples = replay.sample(half)
            corpus_batch = next(iter_batches(train[:half * 2], half, self.cfg, self.vocab, source_vocab=self.source_vocab), None)
            if corpus_batch is not None:
                samples.extend(self._uncollate(corpus_batch))
            return collate(samples[: self.cfg.batch_size], self.cfg, self.vocab, source_vocab=self.source_vocab)
        if replay is not None and len(replay) >= self.cfg.batch_size:
            return collate(replay.sample(self.cfg.batch_size), self.cfg, self.vocab, source_vocab=self.source_vocab)
        return next(train_iter, None)

    def _uncollate(self, batch: dict[str, Any]) -> list[ConversationSample]:
        # Best-effort reverse — only used by _next_batch when mixing sources.
        out: list[ConversationSample] = []
        B = len(batch["messages"])
        for i in range(B):
            # Best-effort reverse: rebuild a ConversationSample from
            # the encoder-shaped batch. The conversation here is lossy —
            # we only have the post-encoder string view, so we
            # reconstruct ChatMessages by splitting the role prefix.
            msg_strs = batch["messages"][i]
            conv: list[ChatMessage] = []
            for s in msg_strs:
                if not s:
                    continue
                role, sep, content = s.partition(": ")
                if not sep:
                    role, content = "user", s
                conv.append(ChatMessage(role=role, content=content))
            # Recover the target tool name from the contrastive head's
            # target index + candidate list. The candidate list lives in
            # batch["tool_specs"][i], with slot 0 being <no_tool>. The
            # original ToolDef objects are gone (only the rendered
            # "{name}: {desc}" string remains), so we reconstruct the
            # name from the leading "{name}:" segment.
            tgt_idx = int(batch["target_tool_idx"][i].item())
            tool_name = "<no_tool>"
            if tgt_idx >= 0 and tgt_idx < len(batch["tool_specs"][i]):
                spec_str = batch["tool_specs"][i][tgt_idx]
                tool_name = spec_str.split(":", 1)[0].strip() or "<no_tool>"
            out.append(ConversationSample(
                conversation=conv,
                tools=[],
                mood=batch["mood"][i].tolist(),
                target_tool=tool_name,
                target_tier=int(batch["target_tier"][i].item()),
                target_think=float(batch["target_think"][i].item()),
                target_value=float(batch["target_value"][i].item()),
            ))
        return out

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def save(self) -> Path:
        self.cfg.ensure_dirs()
        ckpt_path = Path(self.cfg.checkpoint_path)
        meta_path = Path(self.cfg.metadata_path)

        torch.save({
            "model": self.model.state_dict(),
            "optimizer": self.optimizer.state_dict(),
            "scheduler": self.scheduler.state_dict(),
            "step": self.step,
            "vocab": self.vocab.to_dict(),
            "source_vocab": self.source_vocab.to_dict(),
        }, ckpt_path)

        meta_path.write_text(json.dumps({
            "config": self.cfg.model_dump(),
            "step": self.step,
            "saved_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "n_params": self.model.num_parameters(),
        }, indent=2))
        logger.info(f"saved checkpoint → {ckpt_path}  (step {self.step})")
        return ckpt_path

    @classmethod
    def load(cls, cfg: NNConfig) -> "Trainer":
        ckpt_path = Path(cfg.checkpoint_path)
        if not ckpt_path.exists():
            raise FileNotFoundError(f"No checkpoint at {ckpt_path}")
        ckpt = torch.load(ckpt_path, map_location="cpu", weights_only=False)

        # Apply meta-file arch override so a checkpoint trained at a
        # different scale (Phase-5 retrain at d_model=192 etc.) rebuilds
        # at the right shape. Without this the rebuild uses default
        # NNConfig and every saved tensor mismatches. Same logic as
        # nn.runtime.load_advisor — kept in one place would be nicer,
        # but inlining keeps Trainer's import graph leaner.
        meta_path = Path(getattr(cfg, "metadata_path", "data/nn/caudate.meta.json"))
        if meta_path.exists():
            try:
                meta = json.loads(meta_path.read_text())
                arch = meta.get("config") or {}
                arch_keys = (
                    "d_model", "n_heads", "n_layers", "d_ff", "dropout",
                    "n_tools_out", "source_vocab_size", "tool_vocab_size",
                    "tool_embed_dim", "mood_dim", "history_window",
                    "msg_window", "image_window", "use_vision",
                    "vision_backend", "vision_embed_dim", "vision_dtype",
                    "vision_encoder_name", "text_embed_dim",
                )
                overrides = {k: arch[k] for k in arch_keys if k in arch}
                if overrides:
                    cfg = cfg.model_copy(update=overrides)
                    logger.info(
                        f"Trainer.load: applied meta arch override "
                        f"d_model={cfg.d_model} n_layers={cfg.n_layers}"
                    )
            except Exception as e:
                logger.warning(f"Trainer.load meta override failed: {e}")

        vocab = ToolVocab.from_dict(ckpt.get("vocab", {}))
        source_vocab = SourceVocab.from_dict(
            ckpt.get("source_vocab", {}),
            cap=getattr(cfg, "source_vocab_size", SourceVocab.DEFAULT_CAP),
        )
        model = Caudate(cfg)
        # strict=False so a pre-Phase-2 checkpoint (no source_embed
        # weights) loads cleanly; the new source_embed stays at its
        # zero init, which matches the unconditioned baseline of the
        # old model. The next training cycle then learns it.
        missing, unexpected = model.load_state_dict(ckpt["model"], strict=False)
        if missing or unexpected:
            logger.info(
                f"checkpoint loaded with strict=False  "
                f"missing={list(missing)}  unexpected={list(unexpected)}"
            )
        trainer = cls(cfg=cfg, model=model, vocab=vocab, source_vocab=source_vocab)
        if "optimizer" in ckpt:
            try: trainer.optimizer.load_state_dict(ckpt["optimizer"])
            except Exception: pass
        if "scheduler" in ckpt:
            try: trainer.scheduler.load_state_dict(ckpt["scheduler"])
            except Exception: pass
        trainer.step = ckpt.get("step", 0)
        return trainer


def build_fresh(cfg: NNConfig) -> Trainer:
    """Convenience constructor for a brand-new trainer."""
    model = Caudate(cfg)
    return Trainer(cfg=cfg, model=model, vocab=ToolVocab(),
                   source_vocab=SourceVocab(cap=getattr(cfg, "source_vocab_size", 16)))
