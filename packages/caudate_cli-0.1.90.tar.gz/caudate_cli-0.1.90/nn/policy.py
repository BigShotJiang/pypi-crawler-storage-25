"""Graduation policy — when does Caudate get to influence the agent?

Five trust levels. Promotion needs both *enough samples* and
*good-enough accuracy*; demotion is symmetric so a regression after a
bad retrain doesn't keep her in a level she no longer earns.

    SILENT        no checkpoint loaded                  no predictions
    OBSERVER      checkpoint loaded                     predicts but ignored
    WHISPER       accuracy ≥ 0.50, ≥ 50 predictions     prediction → prompt hint
    ADVISOR       accuracy ≥ 0.70, ≥ 200 predictions    prediction → constrained tool list  (ADR 0007)
    CONTROLLER    accuracy ≥ 0.80, ≥ 500 predictions    prediction → constrained list + thinking gate

The accuracy used is `composite()` from the scorer — a weighted blend
of tool / tier / think accuracy, matching the training loss weights.

Persistence: the *current* level is saved alongside the scorecard so a
restart doesn't reset her to OBSERVER. Re-promotion still requires the
sample/accuracy gates so a forced demotion (e.g. via /caudate demote)
holds until earned back.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from enum import IntEnum
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


class TrustLevel(IntEnum):
    SILENT = 0
    OBSERVER = 1
    WHISPER = 2
    ADVISOR = 3
    CONTROLLER = 4

    @property
    def label(self) -> str:
        return self.name.lower()


@dataclass
class _Gate:
    level: TrustLevel
    min_samples: int
    min_accuracy: float


# Promotion thresholds. Demotion uses the previous gate's threshold
# minus a small hysteresis to avoid flapping.
_GATES: list[_Gate] = [
    _Gate(TrustLevel.OBSERVER,   min_samples=0,   min_accuracy=0.0),
    _Gate(TrustLevel.WHISPER,    min_samples=50,  min_accuracy=0.50),
    _Gate(TrustLevel.ADVISOR,    min_samples=200, min_accuracy=0.70),
    _Gate(TrustLevel.CONTROLLER, min_samples=500, min_accuracy=0.80),
]
_HYSTERESIS = 0.05  # accuracy must drop this much below a gate to demote


class GraduationPolicy:
    """Owns the current trust level. Reads scorer + advisor state to update."""

    def __init__(self, state_path: Path | str = "data/nn/policy.json"):
        self.state_path = Path(state_path)
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        self._level: TrustLevel = TrustLevel.SILENT
        self._frozen: bool = False  # /caudate freeze pins the level
        self._load()

    # ------------------------------------------------------------------

    @property
    def level(self) -> TrustLevel:
        return self._level

    @property
    def frozen(self) -> bool:
        return self._frozen

    def can_predict(self) -> bool:
        return self._level >= TrustLevel.OBSERVER

    def can_whisper(self) -> bool:
        return self._level >= TrustLevel.WHISPER

    def can_advise(self) -> bool:
        return self._level >= TrustLevel.ADVISOR

    def can_control(self) -> bool:
        return self._level >= TrustLevel.CONTROLLER

    # ------------------------------------------------------------------
    # Updates
    # ------------------------------------------------------------------

    def update(self, samples: int, composite_acc: float, advisor_loaded: bool) -> TrustLevel:
        """Recompute the trust level from observed performance.

        Called by the observer after every turn. No-op if frozen.
        """
        if self._frozen:
            return self._level

        if not advisor_loaded:
            new_level = TrustLevel.SILENT
        else:
            new_level = self._level_for(samples, composite_acc, current=self._level)

        if new_level != self._level:
            old = self._level
            self._level = new_level
            self._save()
            arrow = "↑" if new_level > old else "↓"
            logger.info(
                f"Caudate trust level {arrow} {old.label} → {new_level.label} "
                f"(samples={samples}, composite={composite_acc:.3f})"
            )
        return self._level

    def freeze(self, level: TrustLevel | None = None) -> None:
        """Pin the level (useful for testing or rolling back a bad retrain)."""
        if level is not None:
            self._level = level
        self._frozen = True
        self._save()

    def thaw(self) -> None:
        self._frozen = False
        self._save()

    def force(self, level: TrustLevel) -> None:
        """Manually set the level. Doesn't freeze — next update can change it."""
        self._level = level
        self._save()

    # ------------------------------------------------------------------
    # Inspection
    # ------------------------------------------------------------------

    def next_gate(self) -> _Gate | None:
        """The next promotion gate (or None if already at top)."""
        for gate in _GATES:
            if gate.level > self._level:
                return gate
        return None

    def progress_to_next(self, samples: int, composite_acc: float) -> dict[str, Any]:
        """How close is she to the next promotion?"""
        gate = self.next_gate()
        if gate is None:
            return {"at_top": True}
        return {
            "next_level": gate.level.label,
            "samples_needed": max(0, gate.min_samples - samples),
            "current_samples": samples,
            "samples_progress": min(1.0, samples / max(1, gate.min_samples)),
            "accuracy_needed": gate.min_accuracy,
            "current_accuracy": composite_acc,
            "accuracy_progress": min(1.0, composite_acc / max(1e-8, gate.min_accuracy)),
        }

    def report(self, samples: int, composite_acc: float) -> dict[str, Any]:
        return {
            "level": self._level.label,
            "level_int": int(self._level),
            "frozen": self._frozen,
            "next": self.progress_to_next(samples, composite_acc),
        }

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _level_for(
        self, samples: int, composite_acc: float, current: TrustLevel,
    ) -> TrustLevel:
        # Promote: highest gate she clears
        target = TrustLevel.OBSERVER
        for gate in _GATES:
            if samples >= gate.min_samples and composite_acc >= gate.min_accuracy:
                target = gate.level

        # Demote with hysteresis: she only loses the current level if
        # accuracy has fallen *below the entry threshold minus hysteresis*.
        if target < current:
            current_gate = next((g for g in _GATES if g.level == current), None)
            if current_gate is not None:
                if (composite_acc >= current_gate.min_accuracy - _HYSTERESIS
                        and samples >= current_gate.min_samples):
                    target = current
        return target

    def _load(self) -> None:
        if not self.state_path.exists():
            return
        try:
            data = json.loads(self.state_path.read_text())
            self._level = TrustLevel(int(data.get("level", 0)))
            self._frozen = bool(data.get("frozen", False))
        except Exception as e:
            logger.debug(f"policy load failed: {e}")

    def _save(self) -> None:
        try:
            self.state_path.write_text(json.dumps({
                "level": int(self._level),
                "frozen": self._frozen,
            }, indent=2))
        except Exception as e:
            logger.debug(f"policy save failed: {e}")
