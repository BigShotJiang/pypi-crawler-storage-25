"""Auto-evolve — Caudate fires her own NAS runs.

Wired into `CaudateObserver._kick_auto_train`. After each background
training cycle, this module decides whether to launch a NAS run:

  1. Was the latest training improvement small? (PlateauScheduler)
  2. Has the cooldown passed? (default 6h between NAS runs)
  3. Is there enough VRAM headroom?
  4. Is no NAS run already in flight?

If all four pass, picks a strategy (rotating through evolutionary →
random → rl), runs the search asynchronously, and if a new champion
beats the current Caudate by a margin, promotes it and hot-swaps the
advisor.

Every decision (fire / skip / promote / reject) lands in
`data/nn/nas/auto_log.jsonl` for inspection.
"""

from __future__ import annotations

import asyncio
import json
import logging
import shutil
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


# Strategies cycled through across firings. Evolutionary first because
# it's most sample-efficient; random as a sanity check; RL once enough
# trials accumulated to learn from.
_ROTATION = ["evolutionary", "random", "rl", "evolutionary", "hyperband"]


@dataclass
class AutoEvolveConfig:
    enabled: bool = True
    min_vram_gb: float = 3.0           # skip NAS if less than this is free
    cooldown_seconds: float = 6 * 3600  # don't fire more often than this
    n_trials_per_run: int = 8
    train_steps_per_trial: int = 150
    promote_margin: float = 0.005       # new champion must beat by this much
    rotation: list[str] = None          # strategies to cycle through


def _free_vram_gb() -> float:
    try:
        out = subprocess.run(
            ["nvidia-smi", "--query-gpu=memory.free",
             "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=2,
        ).stdout.strip().splitlines()[0]
        return float(out) / 1024.0
    except Exception:
        return float("inf")  # if we can't check, assume OK


class AutoEvolver:
    """Decides + drives autonomous NAS runs from the observer."""

    def __init__(self, observer: Any, cfg: AutoEvolveConfig | None = None):
        self.observer = observer
        self.cfg = cfg or AutoEvolveConfig()
        if self.cfg.rotation is None:
            self.cfg.rotation = list(_ROTATION)
        self._nas_in_flight: asyncio.Task | None = None
        self._n_fires = 0
        self._last_fire_at: float = 0.0
        self._auto_log = Path(self.observer.cfg.data_dir) / "nas" / "auto_log.jsonl"
        self._auto_log.parent.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------

    def maybe_fire(self) -> None:
        """Called from CaudateObserver after each auto-train cycle."""
        if not self.cfg.enabled:
            return
        # Owner killswitch — overrides everything else.
        try:
            from core.ownership import caudate_may_act
            if not caudate_may_act():
                self._log("skip", reason="owner_killswitch_active")
                return
        except Exception:
            pass
        if self._nas_in_flight is not None and not self._nas_in_flight.done():
            self._log("skip", reason="already_in_flight")
            return
        if time.time() - self._last_fire_at < self.cfg.cooldown_seconds:
            self._log("skip", reason="cooldown")
            return

        # Plateau check via the existing scheduler
        try:
            from nn.nas.scheduler import PlateauScheduler
            sched = PlateauScheduler()
            if not sched.should_fire():
                self._log("skip", reason="not_plateaued",
                          stalled_for=sched.status().get("stalled_for"))
                return
        except Exception as e:
            logger.debug(f"plateau check failed: {e}")
            return

        # VRAM check
        free_gb = _free_vram_gb()
        if free_gb < self.cfg.min_vram_gb:
            self._log("skip", reason="vram_low", free_gb=round(free_gb, 1))
            return

        # All gates passed — schedule a background NAS run.
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            self._log("skip", reason="no_running_loop")
            return

        strategy = self.cfg.rotation[self._n_fires % len(self.cfg.rotation)]
        self._n_fires += 1
        self._last_fire_at = time.time()
        self._log("fire", strategy=strategy, n_fire=self._n_fires,
                  free_vram_gb=round(free_gb, 1))
        self._nas_in_flight = loop.create_task(
            self._run_async(strategy)
        )

    # ------------------------------------------------------------------

    async def _run_async(self, strategy_name: str) -> None:
        """Run NAS in a thread (heavy CPU/GPU work) and post-process."""
        try:
            result = await asyncio.to_thread(self._run_sync, strategy_name)
            self._log("complete", strategy=strategy_name, result=result)
            # Hot-swap the advisor in case champion was promoted
            self.observer.reload_advisor()
            try:
                from nn.nas.scheduler import PlateauScheduler
                PlateauScheduler().mark_fired()
            except Exception:
                pass
        except Exception as e:
            self._log("error", strategy=strategy_name, error=str(e))
            logger.warning(f"auto-NAS [{strategy_name}] failed: {e}")

    def _run_sync(self, strategy_name: str) -> dict[str, Any]:
        from nn.nas import Searcher
        from nn.nas.searcher import SearcherConfig
        from nn.nas.strategies import make_strategy
        from nn.nas.strategies.base import StrategyConfig

        scfg = StrategyConfig(
            n_trials=self.cfg.n_trials_per_run,
            train_steps_per_trial=self.cfg.train_steps_per_trial,
            seed=int(time.time()) % 10000,
        )
        if strategy_name == "hyperband":
            base = make_strategy("random", config=scfg)
            strategy = make_strategy("hyperband", config=scfg, base=base)
        elif strategy_name == "darts":
            strategy = make_strategy("darts", config=scfg, epochs=3, n_layers=4)
        else:
            strategy = make_strategy(strategy_name, config=scfg)

        searcher = Searcher(
            cfg=SearcherConfig(
                n_trials=self.cfg.n_trials_per_run,
                train_steps_per_trial=self.cfg.train_steps_per_trial,
                seed=scfg.seed,
                cost_cap=8.0,
                min_corpus_size=64,
                promote_margin=self.cfg.promote_margin,
            ),
            strategy=strategy,
        )
        summary = searcher.search()

        # If a new champion exists, promote it over the current Caudate
        if summary.get("status") == "complete" and summary.get("champion"):
            self._maybe_promote_to_main()

        return {
            "status": summary.get("status"),
            "n_trials": summary.get("n_trials"),
            "champion": summary.get("champion"),
        }

    def _maybe_promote_to_main(self) -> None:
        """Copy NAS champion → main caudate.pt if it beats current."""
        try:
            from nn.nas.store import NASStore
            store = NASStore()
            champ = store.champion()
            if not champ:
                return
            # Get champion fitness
            champ_fit = float(champ.get("result", {}).get("fitness", 0.0))
            # We promote unconditionally — Searcher already gated on the
            # margin against the previous champion. The Searcher's own
            # save_champion step already wrote champion.pt. Now copy to
            # the main slot so the live observer picks it up.
            ok = store.promote_to_main(self.observer.cfg.checkpoint_path)
            if ok:
                logger.info(
                    f"auto-NAS promoted champion → main caudate "
                    f"(fitness={champ_fit:.3f})"
                )
                self._log("promote", fitness=champ_fit)
        except Exception as e:
            logger.debug(f"auto-NAS promotion failed: {e}")

    # ------------------------------------------------------------------

    def status(self) -> dict[str, Any]:
        return {
            "enabled": self.cfg.enabled,
            "n_fires": self._n_fires,
            "in_flight": (
                self._nas_in_flight is not None
                and not self._nas_in_flight.done()
            ),
            "seconds_since_last_fire": (
                int(time.time() - self._last_fire_at)
                if self._last_fire_at else None
            ),
            "cooldown_seconds": self.cfg.cooldown_seconds,
            "min_vram_gb": self.cfg.min_vram_gb,
            "rotation": list(self.cfg.rotation),
        }

    def _log(self, action: str, **kwargs: Any) -> None:
        try:
            with self._auto_log.open("a") as f:
                f.write(json.dumps({
                    "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                    "action": action,
                    **kwargs,
                }) + "\n")
        except Exception as e:
            logger.debug(f"auto_log write failed: {e}")
