"""Memory consolidator — periodic offline replay → training pairs.

Loosely modeled on hippocampal-cortical consolidation: while Cognos is
idle (or on demand), it walks recent episodic memories, distills them
into ConversationSample rows, and pushes them into the replay buffer.
The trainer can then run additional gradient steps without needing
fresh data from a live session.
"""

from __future__ import annotations

import json
import logging
from typing import Any

from nn.config import NNConfig
from nn.data import ConversationSample, ReplayBuffer
from nn.format import ChatMessage, ToolCall

logger = logging.getLogger(__name__)


def consolidate_from_episodic(
    episodic: Any,
    replay: ReplayBuffer,
    cfg: NNConfig,
    limit: int = 128,
) -> int:
    """Pull up to `limit` episodes from episodic memory into the replay buffer.

    Returns number of samples added. If episodic memory exposes a
    `recall_recent(limit)` method we use that; otherwise we degrade to
    `recall("", limit=...)` which most stores accept.
    """
    if episodic is None:
        return 0
    try:
        if hasattr(episodic, "recall_recent"):
            episodes = episodic.recall_recent(limit=limit)
        else:
            episodes = episodic.recall("", limit=limit)
    except Exception as e:
        logger.warning(f"consolidator: episodic recall failed: {e}")
        return 0

    added = 0
    for ep in episodes or []:
        try:
            tool = getattr(ep, "tool_name", None) or "unknown"
            args = getattr(ep, "tool_args", {}) or {}
            result = getattr(ep, "result", None)
            success = (
                getattr(result, "status", None)
                and str(getattr(result, "status").value if hasattr(getattr(result, "status"), "value") else getattr(result, "status")) == "success"
            )
            action_text = (getattr(ep, "action", "") or "")[:400]
            try:
                args_str = json.dumps(args) if args else ""
            except Exception:
                args_str = ""
            sample = ConversationSample(
                # One episodic memory → a 2-turn conversation: the
                # action description as a user turn, followed by the
                # assistant calling the tool that was actually invoked.
                conversation=[
                    ChatMessage(role="user", content=action_text),
                    ChatMessage(
                        role="assistant", content="",
                        tool_calls=[ToolCall(name=tool, arguments=args_str)],
                    ),
                ],
                tools=[],
                mood=[0.5, 0.5, 0.5, 0.5],
                target_tool=tool,
                target_value=(0.7 if success else 0.3),
            )
            replay.push(sample)
            added += 1
        except Exception as e:
            logger.debug(f"consolidator: skipped episode: {e}")
    return added
