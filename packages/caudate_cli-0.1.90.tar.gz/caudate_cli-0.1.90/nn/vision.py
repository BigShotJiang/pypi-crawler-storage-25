"""Vision backends for Caudate.

Two embedders ship, dispatched via `make_vision_encoder(backend, ...)`:

  - **CLIP** (default) — `clip-ViT-B-32` via sentence-transformers.
    512-D, ~150M params, ~600MB. Fast, light, semantically aligned to
    text. Good default.

  - **InternVL2** — OpenGVLab/InternVL2-{8B,26B}. Extracts the vision
    tower's projected features (4096-D for 8B). Way richer than CLIP
    — can pick up text in screenshots, code structure, diagrams. But
    loading the model takes ~16GB VRAM (8B) or ~50GB (26B in bf16).

Both expose the same `encode_paths(paths) -> (N, embed_dim) tensor`
interface, so the rest of Cognos doesn't care which one's running.

To swap backends, edit `nn/config.py::vision_backend` and bump
`vision_embed_dim` to match (CLIP=512, InternVL2-8B=4096). The new
checkpoint will then need fresh training — old weights have a
different vision_proj input dim.
"""

from __future__ import annotations

import hashlib
import logging
import os
from pathlib import Path
from typing import Any, Protocol

# Block transformers' TF integration before sentence-transformers loads.
os.environ.setdefault("USE_TF", "0")

import numpy as np
import torch

logger = logging.getLogger(__name__)

DEFAULT_CLIP_MODEL = "clip-ViT-B-32"
CLIP_EMBED_DIM = 512
INTERNVL_DEFAULT_MODEL = "OpenGVLab/InternVL2-8B"
INTERNVL_EMBED_DIM = 4096
INTERNVL_IMAGE_SIZE = 448

# IMAGENET / InternViT normalization
_INTERNVL_MEAN = (0.485, 0.456, 0.406)
_INTERNVL_STD = (0.229, 0.224, 0.225)


# --- Protocol --------------------------------------------------------


class BaseVisionEncoder(Protocol):
    """Common shape: paths in, fixed-dim tensor out."""

    embed_dim: int

    def encode_paths(self, paths: list[str]) -> torch.Tensor:
        ...


# --- CLIP (light, default) ------------------------------------------


class CLIPVisionEncoder:
    """CLIP wrapper. Lazy. Batched. Cached per-path."""

    embed_dim = CLIP_EMBED_DIM

    def __init__(self, model_name: str = DEFAULT_CLIP_MODEL):
        self.model_name = model_name
        self._model = None
        self._fake = False
        self._cache: dict[str, torch.Tensor] = {}

    def _load(self) -> None:
        if self._model is not None or self._fake:
            return
        try:
            from sentence_transformers import SentenceTransformer
            from PIL import Image  # noqa: F401
            self._model = SentenceTransformer(self.model_name)
            real_dim = self._model.get_sentence_embedding_dimension()
            if isinstance(real_dim, int) and real_dim != self.embed_dim:
                logger.warning(
                    f"CLIP dim {real_dim} != configured {self.embed_dim} — "
                    "retrain Caudate if you swap models"
                )
        except Exception as e:
            logger.warning(
                f"CLIP unavailable ({e}); vision channel will use deterministic "
                "hash embeddings — Caudate's vision will be degraded but the "
                "pipeline keeps running."
            )
            self._fake = True

    def encode_paths(self, paths: list[str]) -> torch.Tensor:
        self._load()
        result_slots: list[torch.Tensor | None] = [None] * len(paths)
        to_load: list[tuple[int, str]] = []

        for i, p in enumerate(paths):
            if not p:
                result_slots[i] = torch.zeros(self.embed_dim, dtype=torch.float32)
                continue
            cached = self._cache.get(p)
            if cached is not None:
                result_slots[i] = cached
            else:
                to_load.append((i, p))

        if to_load:
            if self._fake or self._model is None:
                for i, p in to_load:
                    vec = _hash_embed(p, self.embed_dim)
                    self._cache[p] = vec
                    result_slots[i] = vec
            else:
                from PIL import Image
                images: list[Any] = []
                valid: list[int] = []
                for i, p in to_load:
                    try:
                        img = Image.open(p).convert("RGB")
                        images.append(img)
                        valid.append(i)
                    except Exception as e:
                        logger.debug(f"image open failed for {p}: {e}")
                        result_slots[i] = torch.zeros(self.embed_dim, dtype=torch.float32)
                if images:
                    with torch.no_grad():
                        arr = self._model.encode(
                            images, convert_to_numpy=True, normalize_embeddings=True,
                        )
                    for j, idx in enumerate(valid):
                        vec = torch.from_numpy(arr[j]).float()
                        path = paths[idx]
                        self._cache[path] = vec
                        result_slots[idx] = vec

        out = [
            v if v is not None else torch.zeros(self.embed_dim, dtype=torch.float32)
            for v in result_slots
        ]
        return torch.stack(out, dim=0)


# --- InternVL2 (rich, heavier) --------------------------------------


class InternVLVisionEncoder:
    """OpenGVLab/InternVL2-{8B,26B} vision tower as a feature extractor.

    Loads the full InternVL2 model (the vision tower isn't packaged
    separately) but only ever runs forward through the vision encoder
    + MLP projector — the LLM half never gets a forward pass. Output
    is the projected vision features, mean-pooled across patches into
    a single vector per image (4096-D for the 8B variant).

    First call is slow (~30s to load + 16GB VRAM for 8B in bf16). After
    that, encoding is fast and per-image embeddings are cached.
    """

    def __init__(
        self,
        model_name: str = INTERNVL_DEFAULT_MODEL,
        embed_dim: int = INTERNVL_EMBED_DIM,
        device: str | None = None,
        dtype: str = "bfloat16",
    ):
        self.model_name = model_name
        self.embed_dim = embed_dim
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.dtype_name = dtype
        self._model = None
        self._cache: dict[str, torch.Tensor] = {}

    def _load(self) -> None:
        if self._model is not None:
            return
        try:
            from transformers import AutoModel
        except ImportError as e:
            raise RuntimeError(
                "InternVL backend needs `transformers`. Install it first."
            ) from e

        torch_dtype = getattr(torch, self.dtype_name)
        logger.info(
            f"Loading {self.model_name} (vision tower + projector only). "
            f"~16GB VRAM in bf16 for InternVL2-8B."
        )
        self._model = AutoModel.from_pretrained(
            self.model_name,
            torch_dtype=torch_dtype,
            low_cpu_mem_usage=True,
            trust_remote_code=True,
        ).eval()
        self._model.to(self.device)
        logger.info(f"InternVL vision encoder ready on {self.device}.")

    def _preprocess(self, paths: list[str]) -> tuple[torch.Tensor, list[int]]:
        """Resize+normalize to (N, 3, 448, 448). Returns (tensor, valid_indices)."""
        from PIL import Image
        from torchvision import transforms

        tfm = transforms.Compose([
            transforms.Resize(
                (INTERNVL_IMAGE_SIZE, INTERNVL_IMAGE_SIZE),
                interpolation=transforms.InterpolationMode.BICUBIC,
            ),
            transforms.ToTensor(),
            transforms.Normalize(mean=_INTERNVL_MEAN, std=_INTERNVL_STD),
        ])
        tensors: list[torch.Tensor] = []
        valid: list[int] = []
        for i, p in enumerate(paths):
            try:
                img = Image.open(p).convert("RGB")
                tensors.append(tfm(img))
                valid.append(i)
            except Exception as e:
                logger.debug(f"image open failed for {p}: {e}")
        if not tensors:
            return torch.empty(0), []
        batch = torch.stack(tensors, dim=0)
        return batch, valid

    @torch.no_grad()
    def encode_paths(self, paths: list[str]) -> torch.Tensor:
        result_slots: list[torch.Tensor | None] = [None] * len(paths)
        to_load: list[tuple[int, str]] = []

        for i, p in enumerate(paths):
            if not p:
                result_slots[i] = torch.zeros(self.embed_dim, dtype=torch.float32)
                continue
            cached = self._cache.get(p)
            if cached is not None:
                result_slots[i] = cached
            else:
                to_load.append((i, p))

        if to_load:
            self._load()
            assert self._model is not None
            # Just the paths we need to embed
            paths_to_load = [p for _, p in to_load]
            pixel, valid_local = self._preprocess(paths_to_load)
            for k, (orig_idx, _) in enumerate(to_load):
                if k not in valid_local:
                    result_slots[orig_idx] = torch.zeros(self.embed_dim, dtype=torch.float32)
            if pixel.numel() > 0:
                pixel = pixel.to(self.device, dtype=getattr(torch, self.dtype_name))
                # InternVL2 exposes `extract_feature` which returns the
                # post-projector vision features (B, num_patches, 4096).
                # If unavailable, fall back to the raw vision_model output
                # and project ourselves via the model's mlp1.
                try:
                    feats = self._model.extract_feature(pixel)
                except AttributeError:
                    out = self._model.vision_model(pixel_values=pixel)
                    feats = out.last_hidden_state
                    if hasattr(self._model, "mlp1"):
                        feats = self._model.mlp1(feats)
                # Mean-pool across patches → (B, embed_dim)
                pooled = feats.mean(dim=1).float().cpu()
                # L2-normalize for stable training
                pooled = pooled / pooled.norm(dim=-1, keepdim=True).clamp(min=1e-8)
                # Map back to result slots
                vi = 0
                for k, (orig_idx, p) in enumerate(to_load):
                    if k in valid_local:
                        vec = pooled[vi]
                        self._cache[p] = vec
                        result_slots[orig_idx] = vec
                        vi += 1

        out_list = [
            v if v is not None else torch.zeros(self.embed_dim, dtype=torch.float32)
            for v in result_slots
        ]
        return torch.stack(out_list, dim=0)


# --- Factory --------------------------------------------------------


def make_vision_encoder(
    backend: str = "clip",
    model_name: str | None = None,
    **kwargs: Any,
) -> BaseVisionEncoder:
    """Pick a vision backend by name.

    backend = 'clip'      → CLIPVisionEncoder
    backend = 'internvl'  → InternVLVisionEncoder
    backend = 'auto'      → infer from model_name
    """
    if backend == "auto":
        if model_name and "intern" in model_name.lower():
            backend = "internvl"
        else:
            backend = "clip"

    b = backend.lower()
    if b == "clip":
        return CLIPVisionEncoder(model_name=model_name or DEFAULT_CLIP_MODEL)
    if b in ("internvl", "internvl2"):
        return InternVLVisionEncoder(
            model_name=model_name or INTERNVL_DEFAULT_MODEL,
            **kwargs,
        )
    raise ValueError(f"Unknown vision backend: {backend!r}")


# --- Backward compat: the StateEncoder still imports `VisionEncoder` -


class VisionEncoder:
    """Public facade — dispatches to the configured backend.

    Behavior preserved for older code that imported this class directly:
    constructing `VisionEncoder(model_name)` keeps using CLIP unless
    you pass `backend="internvl"`.
    """

    def __init__(
        self,
        model_name: str = DEFAULT_CLIP_MODEL,
        backend: str = "auto",
        **kwargs: Any,
    ):
        self._impl = make_vision_encoder(
            backend=backend, model_name=model_name, **kwargs,
        )
        self.embed_dim = self._impl.embed_dim

    def encode_paths(self, paths: list[str]) -> torch.Tensor:
        return self._impl.encode_paths(paths)


def _hash_embed(text: str, dim: int) -> torch.Tensor:
    """Deterministic per-path hash → fixed-dim vector. Not semantic."""
    digest = hashlib.sha256(text.encode("utf-8")).digest()
    repeated = (digest * ((dim // len(digest)) + 1))[:dim]
    arr = np.frombuffer(repeated, dtype=np.uint8).astype(np.float32) / 255.0
    arr -= arr.mean()
    norm = float(np.linalg.norm(arr))
    if norm > 1e-8:
        arr = arr / norm
    return torch.from_numpy(arr.copy())
