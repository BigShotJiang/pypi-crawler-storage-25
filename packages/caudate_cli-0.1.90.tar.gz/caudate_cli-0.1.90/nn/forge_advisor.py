"""Forge feature-level advisor — Caudate's two-way loop with the
orchestrator.

ADR 0006 calls for a single predictor `predict_feature_difficulty`
that drives four orchestrator behaviours:
  B. Model selection per feature (system1 vs system2)
  C. Backlog ordering when priorities tie
  D. Early revision when a retry looks doomed

This module exports the prediction surface and falls back to a
**heuristic baseline** when no trained Caudate head is available yet.
The baseline is computed from the rolling history in
``data/nn/feature_outcomes.jsonl``:

  - per-model success rate (global)
  - per-model average n_turns on success vs failure
  - keyword bias on the feature text (the agent succeeded on these
    kinds of feature before / didn't)

A swap to a real trained head changes only the body of
``_predict_via_caudate``; the public functions and orchestrator
call-sites stay identical.
"""

from __future__ import annotations

import json
import logging
import math
import re
import time
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


_OUTCOMES_PATH = Path("data/nn/feature_outcomes.jsonl")
_AUDIT_PATH = Path("data/nn/forge_predictions.jsonl")

# Cache the loaded advisor so we don't reload Caudate's weights on
# every feature decision. Cleared by reset_advisor_cache() in tests.
_advisor_cache: object | None = None
_advisor_cache_attempted: bool = False

# Heuristic-baseline knobs. Reasonable defaults; tuned later from
# real data when Caudate's head is trained.
_DEFAULT_SUCCESS_PROB = 0.55
_MAX_FEATURES_FOR_BASELINE = 2000  # bound the rolling window read


@dataclass
class FeaturePrediction:
    """Result of ``predict_feature_difficulty``."""
    success_prob: float          # [0, 1]
    difficulty: float            # 1 - success_prob (convenience)
    source: str                  # 'caudate' | 'baseline' | 'fallback'
    reason: str                  # short human-readable explanation


# ─── Public surface ───────────────────────────────────────────────────


def predict_feature_difficulty(
    feature_text: str,
    model_id: str | None = None,
) -> FeaturePrediction:
    """Best-effort P(success | feature, model). Used by the orchestrator
    to decide whether to promote a feature to system2, order the
    backlog by predicted difficulty, or trigger early revision."""
    pred = _predict_via_caudate(feature_text, model_id)
    if pred is not None:
        _audit(feature_text, model_id, pred)
        return pred
    pred = _predict_via_baseline(feature_text, model_id)
    _audit(feature_text, model_id, pred)
    return pred


def predict_failure_repeats(
    feature_text: str,
    n_prior_failures: int,
    model_id: str | None = None,
) -> float:
    """P(next retry also fails | this feature has already failed
    ``n_prior_failures`` times). Used by ADR-0006 Phase D to decide
    whether to skip straight to revision rather than burn more
    sessions."""
    base = predict_feature_difficulty(feature_text, model_id)
    # Conditional on already failing N times, P(next fail) rises
    # quickly. A simple Bayesian-flavoured update — each prior failure
    # halves the remaining success probability.
    success_left = base.success_prob * (0.5 ** max(0, n_prior_failures))
    return float(min(0.99, 1.0 - success_left))


# ─── Caudate path (real head — TODO: wire when trained) ──────────────


def reset_advisor_cache() -> None:
    """Drop the cached CaudateAdvisor — used by tests that swap weights."""
    global _advisor_cache, _advisor_cache_attempted
    _advisor_cache = None
    _advisor_cache_attempted = False


def _get_advisor():
    """Load the CaudateAdvisor once and cache it. None means we tried
    and the checkpoint isn't available — don't re-try every call."""
    global _advisor_cache, _advisor_cache_attempted
    if _advisor_cache_attempted:
        return _advisor_cache
    _advisor_cache_attempted = True
    try:
        from nn.runtime import load_advisor  # type: ignore
    except Exception as e:
        logger.debug(f"nn.runtime unavailable: {e}")
        return None
    try:
        _advisor_cache = load_advisor()
    except Exception as e:
        logger.debug(f"load_advisor failed: {e}")
        _advisor_cache = None
    return _advisor_cache


def _predict_via_caudate(
    feature_text: str, model_id: str | None,
) -> FeaturePrediction | None:
    """Trained Caudate path. Returns None when:
      - the checkpoint is missing,
      - the feature_success head exists but is at its init weights
        (predict_feature_success itself returns None in that case),
      - inference raises.

    The advisor instance is cached so we don't reload weights every
    feature decision."""
    advisor = _get_advisor()
    if advisor is None:
        return None
    head_fn = getattr(advisor, "predict_feature_success", None)
    if head_fn is None:
        return None
    try:
        result = head_fn(feature_text=feature_text, model_id=model_id)
    except Exception as e:
        logger.debug(f"caudate feature head call raised: {e}")
        return None
    if not isinstance(result, dict) or "success_prob" not in result:
        return None
    p = float(max(0.0, min(1.0, result["success_prob"])))
    return FeaturePrediction(
        success_prob=p, difficulty=1 - p,
        source="caudate",
        reason=str(result.get("reason", "trained head")),
    )


# ─── Heuristic baseline ───────────────────────────────────────────────


def _predict_via_baseline(
    feature_text: str, model_id: str | None,
) -> FeaturePrediction:
    """Fall back to a corpus-driven heuristic. Reads feature_outcomes
    JSONL, computes per-model success rate + keyword-weighted prior
    on the feature text. Defaults to ``_DEFAULT_SUCCESS_PROB`` when no
    history exists."""
    history = _load_recent_outcomes()
    if not history:
        return FeaturePrediction(
            success_prob=_DEFAULT_SUCCESS_PROB,
            difficulty=1 - _DEFAULT_SUCCESS_PROB,
            source="fallback",
            reason="no feature-outcome history yet",
        )

    # Per-model success rate
    by_model: dict[str, list[bool]] = defaultdict(list)
    for h in history:
        by_model[h.get("model_used", "unknown")].append(bool(h.get("success")))
    model_rates = {
        m: (sum(v) / len(v)) for m, v in by_model.items() if v
    }

    # Pick the rate that matches the requested model. Fall back to
    # the global success rate if the model has no history.
    rate = None
    reason_parts: list[str] = []
    if model_id and model_id in model_rates and len(by_model[model_id]) >= 3:
        rate = model_rates[model_id]
        reason_parts.append(
            f"model={model_id} n={len(by_model[model_id])} rate={rate:.2f}"
        )
    if rate is None:
        flat = [h for v in by_model.values() for h in v]
        rate = sum(flat) / max(1, len(flat))
        reason_parts.append(f"global n={len(flat)} rate={rate:.2f}")

    # Keyword bias on the feature text. Tokens that appear in
    # successful features more often than failed → bonus; reverse → penalty.
    bias = _keyword_bias(feature_text, history)
    if bias != 0.0:
        reason_parts.append(f"kw_bias={bias:+.3f}")

    p = max(0.05, min(0.95, rate + bias))
    return FeaturePrediction(
        success_prob=p,
        difficulty=1 - p,
        source="baseline",
        reason=" · ".join(reason_parts),
    )


def _load_recent_outcomes() -> list[dict[str, Any]]:
    """Read the most recent feature_outcomes rows. Skips garbage lines."""
    if not _OUTCOMES_PATH.exists():
        return []
    try:
        with _OUTCOMES_PATH.open() as f:
            lines = f.readlines()
    except OSError:
        return []
    rows: list[dict[str, Any]] = []
    for line in lines[-_MAX_FEATURES_FOR_BASELINE:]:
        try:
            rows.append(json.loads(line))
        except Exception:
            continue
    return rows


_WORD_RE = re.compile(r"[a-zA-Z][a-zA-Z0-9]{3,}")
_STOPWORDS = frozenset({
    "feature", "implement", "create", "build", "with", "from", "that",
    "this", "they", "their", "have", "will", "should", "would", "could",
    "must", "needs", "need", "want", "wants", "make", "made", "makes",
    "into", "onto", "over", "under", "between", "where", "when", "what",
    "which", "while", "during", "before", "after", "above", "below",
    "page", "pages", "user", "users", "data", "code", "test", "tests",
})


def _keyword_bias(feature_text: str, history: list[dict]) -> float:
    """Compute a small additive bias [-0.15, +0.15] from the feature
    text's distinctive tokens. Tokens that appear disproportionately
    in past successes shift the prediction up; failures shift it
    down. Bounded to keep heuristic noise from dominating."""
    text = (feature_text or "").lower()
    tokens = {t for t in _WORD_RE.findall(text) if t not in _STOPWORDS}
    if not tokens:
        return 0.0

    # Build per-token success/fail counts on history
    success_counts: Counter = Counter()
    failure_counts: Counter = Counter()
    for h in history:
        h_text = (h.get("feature_text") or "").lower()
        h_tokens = {
            t for t in _WORD_RE.findall(h_text) if t not in _STOPWORDS
        }
        target = success_counts if h.get("success") else failure_counts
        for tok in h_tokens:
            target[tok] += 1

    score = 0.0
    for tok in tokens:
        s, f = success_counts.get(tok, 0), failure_counts.get(tok, 0)
        if s + f < 3:
            continue
        score += (s - f) / (s + f)
    # Squash to [-0.15, +0.15] via tanh
    return 0.15 * math.tanh(score / max(1, len(tokens)))


def _audit(
    feature_text: str, model_id: str | None, pred: FeaturePrediction,
) -> None:
    """Append a row to data/nn/forge_predictions.jsonl so we can later
    correlate predictions with actual outcomes."""
    try:
        _AUDIT_PATH.parent.mkdir(parents=True, exist_ok=True)
        with _AUDIT_PATH.open("a", encoding="utf-8") as f:
            f.write(json.dumps({
                "ts": time.time(),
                "feature_text": feature_text[:200],
                "model_id": model_id,
                "success_prob": pred.success_prob,
                "source": pred.source,
                "reason": pred.reason,
            }) + "\n")
    except Exception as e:
        logger.debug(f"forge_advisor audit write failed: {e}")


__all__ = [
    "FeaturePrediction",
    "predict_feature_difficulty",
    "predict_failure_repeats",
    "reset_advisor_cache",
]
