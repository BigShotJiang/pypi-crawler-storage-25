"""Caudate — Cognos's neural-network brain.

A 4.6M-parameter transformer with text/vision/tool embedders, four
attention layers, and a registry of output heads. The trunk is shared;
each head specialises one routing job (which tool, which tier, should-
think, expected-reward, plus growth slots for memory-write, cache,
permission). Adding a new routing job means appending one HeadSpec to
the registry — see `nn/heads.py`. Caudate is *not* a router; routing
is the family of jobs the brain currently does.

Stack:
    StateEncoder ─► TransformerEncoder (4 layers, pre-norm) ─► CLS pool
                                                              │
                                                       + source_embed bias
                                                              │
                                                       HeadRegistry → {head_name: tensor}

PyTorch's stock TransformerEncoder is used so the architecture stays
inspectable: multi-head self-attention, feed-forward, residual,
LayerNorm. Xavier init on the heads so the early loss isn't dominated
by random output scale.

Caudate runs as an *advisor* alongside the agent — predictions are
logged but don't override the LLM's choices until trust is established.
"""

from __future__ import annotations

import torch
import torch.nn as nn

from nn.config import NNConfig
from nn.encoder import StateEncoder
from nn.heads import ALL_HEADS, ContrastiveToolHead, HeadRegistry, HeadSpec


class Caudate(nn.Module):
    """End-to-end neural network. Forward: state → registered head outputs."""

    name: str = "Caudate"

    def __init__(self, cfg: NNConfig, head_specs: tuple[HeadSpec, ...] | None = None):
        super().__init__()
        self.cfg = cfg
        self.encoder = StateEncoder(cfg)

        layer = nn.TransformerEncoderLayer(
            d_model=cfg.d_model,
            nhead=cfg.n_heads,
            dim_feedforward=cfg.d_ff,
            dropout=cfg.dropout,
            activation="gelu",
            batch_first=True,
            norm_first=True,           # pre-norm — more stable on small data
        )
        self.transformer = nn.TransformerEncoder(layer, num_layers=cfg.n_layers)
        self.norm = nn.LayerNorm(cfg.d_model)

        # Standard heads (tier/think/value + extended D-heads). The
        # tool head was removed from this registry in Phase 2 of the
        # format migration and replaced with `self.tool_head`, a
        # contrastive open-vocab predictor that takes per-sample
        # candidate tool definitions. The registry pattern still
        # drives every OTHER head (uniform loss path in the trainer).
        if head_specs is None:
            specs = ALL_HEADS
        else:
            specs = head_specs
        self.heads = HeadRegistry(cfg.d_model, cfg.dropout, specs)

        # Phase-2 open-vocab tool predictor. Shares the state encoder's
        # text embedder so we don't double-load sentence-transformers.
        self.tool_head = ContrastiveToolHead(cfg, self.encoder.text_embedder)

        # Phase 2 of CAUDATE_EVOLUTION.md: source-conditioned predictions.
        # A learned per-teacher-model bias added to the pooled CLS token
        # before the heads. Initialized to zero so legacy checkpoints
        # loaded with strict=False (no source_embed in state_dict) keep
        # their original behaviour until the next retrain.
        n_sources = max(1, int(getattr(cfg, "source_vocab_size", 16)))
        self.source_embed = nn.Embedding(n_sources, cfg.d_model)
        nn.init.zeros_(self.source_embed.weight)

    def forward(
        self,
        messages: list[list[str]],
        tool_ids: torch.Tensor,
        mood: torch.Tensor,
        image_paths: list[list[str]] | None = None,
        source_id: torch.Tensor | None = None,
        tool_specs: list[list[str]] | None = None,
    ) -> dict[str, torch.Tensor]:
        """tool_specs: per-sample list of "{name}: {description}"
        strings. When supplied, the contrastive tool head runs and
        emits `tool_logits` + `tool_mask` in the output dict. When
        omitted or empty, those keys are absent (the trainer/advisor
        treats that as "no tool prediction available for this sample").
        """
        x = self.encoder(messages, tool_ids, mood, image_paths)  # (B, L, d)
        h = self.transformer(x)                           # (B, L, d)
        cls = self.norm(h[:, 0])                          # (B, d)

        # Source-conditioning: add a learned bias keyed on which model
        # produced this turn's response. Default to slot 0 (<unknown>)
        # which is initialized to zero — i.e. unconditioned baseline.
        if source_id is None:
            source_id = torch.zeros(cls.shape[0], dtype=torch.long, device=cls.device)
        else:
            source_id = source_id.to(device=cls.device, dtype=torch.long)
            # Clamp out-of-range ids back to <unknown> rather than crash
            n_sources = self.source_embed.num_embeddings
            source_id = source_id.clamp(min=0, max=n_sources - 1)
        cls = cls + self.source_embed(source_id)

        head_out = self.heads(cls)            # dict of {output_key: tensor}
        head_out["pooled"] = cls              # (B, d) — for inspection

        # Contrastive tool head — runs only when candidates are
        # supplied. Empty/missing → no tool prediction for this batch.
        if tool_specs is not None and any(ts for ts in tool_specs):
            tool_emb, tool_mask = self.tool_head.embed_tools(tool_specs)
            head_out["tool_logits"] = self.tool_head(cls, tool_emb, tool_mask)
            head_out["tool_mask"] = tool_mask

        return head_out

    @property
    def head_specs(self) -> tuple[HeadSpec, ...]:
        return self.heads.specs

    def num_parameters(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)


# Backward-compat alias — old code that imported CognosController still works.
CognosController = Caudate
