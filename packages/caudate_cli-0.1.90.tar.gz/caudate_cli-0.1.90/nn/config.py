"""Neural-network hyperparameters.

Single source of truth for the controller's shape, training schedule,
and runtime behavior. Persisted alongside checkpoints so loaded weights
always match the matching architecture.
"""

from __future__ import annotations

from pathlib import Path

from pydantic import BaseModel, Field


class NNConfig(BaseModel):
    """Hyperparameters + paths for the cognitive controller."""

    # ----- Architecture -----
    text_embed_dim: int = 384         # sentence-transformers MiniLM dim
    # Phase-2: bumped 64 → 4096 to accommodate public tool-use corpora
    # (xLAM has ~10K unique tool names; ToolBench similar). Tool ids
    # that still overflow this cap are clamped at collate time so the
    # embedding lookup never crashes — the cap is a hard ceiling.
    tool_vocab_size: int = 4096       # max distinct tools we'll embed
    tool_embed_dim: int = 64
    # Phase 2 of CAUDATE_EVOLUTION.md: source-conditioned predictions.
    # Each ConversationSample is tagged with the model that produced it;
    # we look that name up in a small SourceVocab and bias the encoder's
    # pooled state with a learned per-source embedding. Slot 0 is
    # reserved for "<unknown>" so legacy untagged samples (and any
    # model id we haven't seen before) get the zero baseline.
    source_vocab_size: int = 16       # cap on distinct teacher-model ids
    mood_dim: int = 4                 # confidence, curiosity, frustration, satisfaction
    history_window: int = 16          # last N tool calls fed to encoder
    # Phase-2 format migration: bumped 4 → 12 so multi-turn ToolBench-
    # /xLAM-style conversations fit in the encoder window. Pos-embed
    # shape changes with this, so any pre-Phase-2 checkpoint is
    # incompatible — fresh retrain required.
    msg_window: int = 12              # last N messages fed to encoder

    # Vision channel — frozen image embedder.
    use_vision: bool = True
    image_window: int = 4             # last N images fed to encoder
    # Backend = "clip" (light, 512-D) or "internvl" (rich, 4096-D).
    # Match `vision_embed_dim` to whichever you pick.
    vision_backend: str = "internvl"
    vision_embed_dim: int = 4096
    vision_encoder_name: str = "OpenGVLab/InternVL2-8B"
    # InternVL only: the dtype to load with. bfloat16 needs ~16GB
    # for InternVL2-8B on bf16-capable GPUs; float16 is similar; if
    # you only have CPU set this to "float32".
    vision_dtype: str = "bfloat16"

    d_model: int = 256                # transformer hidden size
    n_heads: int = 8
    n_layers: int = 4
    d_ff: int = 1024
    dropout: float = 0.1

    # ----- Output heads -----
    # Phase-2 tool head is contrastive (open-vocab) — at inference the
    # set of "tools the assistant can call right now" is supplied, and
    # the model scores each candidate against the pooled CLS via a
    # learned projection. n_tools_out is the projection's output
    # dimension (= tool description embedding dim). 256 is roomy
    # enough to cleanly separate the function-calling tool vocab in
    # ToolBench / xLAM (~10K unique names) without ballooning params.
    n_tools_out: int = 256
    # Max tools considered per turn. Datasets typically expose 1-20;
    # we pad to this cap with zero embeddings + a mask so the batch
    # tensor shape is fixed.
    max_tools_per_sample: int = 32
    # value head outputs a single scalar; tier head outputs 2 logits;
    # think head outputs 1 logit (sigmoid).

    # ----- Training -----
    batch_size: int = 32
    learning_rate: float = 3e-4
    weight_decay: float = 1e-2
    grad_clip: float = 1.0
    max_steps: int = 5000
    eval_every: int = 200
    save_every: int = 500
    eval_split: float = 0.15
    # Cap eval batches during training so the intra-fit eval ticks
    # stay cheap on big public corpora. 100 batches × default 16 =
    # 1600 samples — enough for a stable loss estimate, fast enough
    # to not dominate the training loop. The end-of-fit final eval
    # ignores this cap and runs over the full held-out split.
    eval_max_batches_intra: int = 100
    seed: int = 42

    # Loss weights — controller has 4 heads, balance them so no one
    # signal dominates training.
    w_tool: float = 1.0
    w_tier: float = 0.5
    w_think: float = 0.2
    w_value: float = 0.5

    # Class weight on the contrastive tool head's slot-0 (<no_tool>).
    # Cognos-toolbox is ~63% <no_tool>, which biased R3 step-11000 to
    # argmax slot-0 on 100% of real-tool turns (target-in-top-5 was
    # 52.5%, but slot-0 always won). 1.0 = unweighted (original
    # behavior). 0.5 = moderate downweight; 0.3 = aggressive.
    tool_no_tool_class_weight: float = 1.0

    # ----- Outcome-weighted loss (Phase 1.3) -----
    # Per-sample weight = 1 + strength × outcome_reward, where
    # outcome_reward ∈ [-1, +1]. With strength=0.5 (default) the
    # effective weight is in [0.5, 1.5] — modest. 0.0 disables the
    # mechanism entirely (samples train at uniform weight). Higher
    # values (e.g. 1.0 → range [0, 2]) make Caudate increasingly
    # avoid learning from bad-outcome turns.
    outcome_weight_strength: float = 0.5

    # ----- Value-head thresholds (Phase 1.4 → consumed by 1.5) -----
    # value_threshold_block: P(success) below this → router blocks the
    # tool pick and forces the model to recover (returns error).
    # value_threshold_escalate: below this but above block → router
    # escalates to S2 instead of using S1's pick.
    # 0.0 for both disables value-gating entirely (router behaves
    # exactly as before the value head was active).
    value_threshold_block: float = 0.15
    value_threshold_escalate: float = 0.30

    # ----- Replay buffer -----
    replay_capacity: int = 8192
    min_episodes_to_train: int = 64

    # ----- Runtime -----
    advisor_min_confidence: float = 0.55  # below this, advisor stays silent
    # ADR-0007 constrained routing — at ADVISOR+, when tool_confidence
    # clears `advisor_min_confidence` and the prediction is a real tool
    # (not <no_tool>), the LLM's tool list is pruned to this many of
    # Caudate's top picks. The predicted tool itself is always included,
    # and `advisor_top_k_floor` is enforced so the LLM never sees fewer
    # than that many options (mitigates "confident wrong hides the right
    # tool" per ADR-0007 Consequences).
    advisor_top_k: int = 5
    advisor_top_k_floor: int = 3
    advisor_log_path: str = "data/nn/predictions.jsonl"

    # ----- Paths -----
    data_dir: str = "data/nn"
    checkpoint_path: str = "data/nn/caudate.pt"
    metadata_path: str = "data/nn/caudate.meta.json"
    text_encoder_name: str = "sentence-transformers/all-MiniLM-L6-v2"

    # Special tokens for the tool history channel
    tool_pad_token: int = 0
    tool_unk_token: int = 1
    tool_bos_token: int = 2

    @property
    def total_input_dim(self) -> int:
        return self.text_embed_dim + self.tool_embed_dim + self.mood_dim

    def ensure_dirs(self) -> None:
        Path(self.data_dir).mkdir(parents=True, exist_ok=True)
        Path(self.advisor_log_path).parent.mkdir(parents=True, exist_ok=True)
