"""State encoder — turns Cognos's per-turn state into a tensor.

Three channels are fused into a sequence the controller can attend over:

    1. Text channel — recent N messages embedded with sentence-transformers.
       Frozen during training (kept lightweight) — we learn on top of it
       rather than fine-tuning the embedder.

    2. Tool history channel — the last K tool calls as integer ids,
       embedded with a learned `nn.Embedding`.

    3. Mood channel — 4 continuous floats projected into d_model space.

The output of the encoder is a (B, L, d_model) tensor that flows into the
transformer controller. L = msg_window + history_window + 1 (mood token).
A single learned [CLS] token is prepended so heads can read off a fixed
position regardless of how the channels are weighted at attention time.
"""

from __future__ import annotations

import logging
import os
from typing import Any

# Defensive — block transformers' TF import path before sentence-transformers loads.
os.environ.setdefault("USE_TF", "0")

import torch
import torch.nn as nn

from nn.config import NNConfig
from nn.vision import VisionEncoder

logger = logging.getLogger(__name__)


class _SentenceEmbedder:
    """Lazy wrapper around sentence-transformers. Falls back to a deterministic
    hash-based fake embedder if the lib isn't installed — so the rest of the
    pipeline (data loading, training loop wiring) still exercises end-to-end
    in an offline test environment."""

    def __init__(self, model_name: str, embed_dim: int):
        self.model_name = model_name
        self.embed_dim = embed_dim
        self._model = None
        self._fake = False

    def _load(self) -> None:
        if self._model is not None or self._fake:
            return
        try:
            from sentence_transformers import SentenceTransformer
            # Place the embedder on CUDA when available. Without this the
            # MiniLM forward runs on CPU and the numpy round-trip dominates
            # step time (was ~3 s/step with a 5.5M trunk on a 3090).
            device = "cuda" if torch.cuda.is_available() else "cpu"
            self._model = SentenceTransformer(self.model_name, device=device)
            self._device = device
            real_dim = self._model.get_sentence_embedding_dimension()
            if real_dim != self.embed_dim:
                logger.warning(
                    f"Embedder dim {real_dim} != configured {self.embed_dim} — "
                    "you'll need to retrain if you change models"
                )
        except Exception as e:
            logger.warning(
                f"sentence-transformers unavailable ({e}); "
                "falling back to deterministic hash embedder"
            )
            self._fake = True

    def encode(self, texts: list[str]) -> torch.Tensor:
        self._load()
        if self._fake or self._model is None:
            return _hash_embed(texts, self.embed_dim)
        with torch.no_grad():
            # Keep the output as a tensor on the embedder's device — no
            # CPU/numpy round-trip. Caller (.to(self.device) in encoder.py)
            # handles any final placement if devices differ.
            t = self._model.encode(
                texts,
                convert_to_tensor=True,
                normalize_embeddings=True,
            )
        # sentence-transformers runs encode() under torch.inference_mode().
        # The returned tensor is an "inference tensor" that autograd refuses
        # to use downstream (the old numpy round-trip detached this flag
        # accidentally). Clone strips it.
        return t.clone().float()


def _hash_embed(texts: list[str], dim: int) -> torch.Tensor:
    """Deterministic per-character hash → fixed-dim vector. NOT semantically
    meaningful; only useful as a placeholder so the pipeline runs offline."""
    out = torch.zeros((len(texts), dim), dtype=torch.float32)
    for i, t in enumerate(texts):
        for j, ch in enumerate((t or "")[: dim * 2]):
            out[i, (j * 16807 + ord(ch)) % dim] += (ord(ch) % 17) / 17.0
    norm = out.norm(dim=-1, keepdim=True).clamp(min=1e-8)
    return out / norm


class StateEncoder(nn.Module):
    """Encode (messages, tool_history, mood, images) → (B, L, d_model)."""

    def __init__(self, cfg: NNConfig):
        super().__init__()
        self.cfg = cfg

        # Sentence-transformer is frozen — we project its output instead.
        self.text_embedder = _SentenceEmbedder(cfg.text_encoder_name, cfg.text_embed_dim)
        self.text_proj = nn.Linear(cfg.text_embed_dim, cfg.d_model)

        # Learned tool-id embedding for the history channel.
        self.tool_embed = nn.Embedding(
            cfg.tool_vocab_size, cfg.tool_embed_dim,
            padding_idx=cfg.tool_pad_token,
        )
        self.tool_proj = nn.Linear(cfg.tool_embed_dim, cfg.d_model)

        # Mood is 4 floats — project up to d_model.
        self.mood_proj = nn.Sequential(
            nn.Linear(cfg.mood_dim, cfg.d_model),
            nn.GELU(),
            nn.Linear(cfg.d_model, cfg.d_model),
        )

        # Vision channel — frozen image embedder, projected to d_model.
        # Backend is chosen at config time (CLIP for light, InternVL2
        # for rich semantic features). Caudate learns on top of these.
        if cfg.use_vision:
            from nn.vision import make_vision_encoder
            self.vision_encoder = make_vision_encoder(
                backend=cfg.vision_backend,
                model_name=cfg.vision_encoder_name,
                dtype=getattr(cfg, "vision_dtype", "bfloat16"),
            )
            self.vision_proj = nn.Sequential(
                nn.Linear(cfg.vision_embed_dim, cfg.d_model),
                nn.GELU(),
                nn.Linear(cfg.d_model, cfg.d_model),
            )
        else:
            self.vision_encoder = None
            self.vision_proj = None

        # Channel-type embedding so the transformer knows which kind of
        # token it's looking at (cls=0, text=1, tool=2, mood=3, image=4).
        n_channel_types = 5 if cfg.use_vision else 4
        self.type_embed = nn.Embedding(n_channel_types, cfg.d_model)
        self.cls_token = nn.Parameter(torch.zeros(1, 1, cfg.d_model))
        nn.init.normal_(self.cls_token, std=0.02)

        # Position embedding across the fused sequence.
        max_len = (
            1 + cfg.msg_window + cfg.history_window + 1
            + (cfg.image_window if cfg.use_vision else 0)
        )
        self.pos_embed = nn.Embedding(max_len, cfg.d_model)
        self.dropout = nn.Dropout(cfg.dropout)

    @property
    def device(self) -> torch.device:
        return next(self.parameters()).device

    def encode_messages(self, messages: list[list[str]]) -> torch.Tensor:
        """Embed a batch of message lists. messages[b] is a list of strings.

        Pads / truncates to msg_window on the right.
        """
        B = len(messages)
        W = self.cfg.msg_window
        padded: list[list[str]] = []
        for batch in messages:
            batch = list(batch)[-W:]
            if len(batch) < W:
                batch = [""] * (W - len(batch)) + batch
            padded.append(batch)

        flat = [m for batch in padded for m in batch]
        emb = self.text_embedder.encode(flat).to(self.device)  # (B*W, text_embed_dim)
        emb = emb.view(B, W, self.cfg.text_embed_dim)
        return emb

    def encode_images(
        self, image_paths: list[list[str]],
    ) -> torch.Tensor:
        """Embed a batch of per-sample image-path lists.

        image_paths[b] is a list of paths to images attached at this
        turn. Pads / truncates to image_window on the right. Returns
        (B, image_window, vision_embed_dim) float.
        """
        if not self.cfg.use_vision or self.vision_encoder is None:
            return torch.zeros(0)
        B = len(image_paths)
        W = self.cfg.image_window
        flat: list[str] = []
        for paths in image_paths:
            paths = list(paths)[-W:]
            if len(paths) < W:
                paths = [""] * (W - len(paths)) + paths
            flat.extend(paths)
        emb = self.vision_encoder.encode_paths(flat).to(self.device)
        return emb.view(B, W, self.cfg.vision_embed_dim)

    def forward(
        self,
        messages: list[list[str]],
        tool_ids: torch.Tensor,         # (B, history_window) long
        mood: torch.Tensor,             # (B, mood_dim) float
        image_paths: list[list[str]] | None = None,  # (B,) list of paths
    ) -> torch.Tensor:
        B = len(messages)
        W_msg = self.cfg.msg_window
        W_tool = self.cfg.history_window
        W_img = self.cfg.image_window if self.cfg.use_vision else 0

        # 1. text channel
        text_emb = self.encode_messages(messages)
        text_proj = self.text_proj(text_emb)                            # (B, W_msg, d)

        # 2. tool channel
        tool_emb = self.tool_embed(tool_ids.to(self.device))            # (B, W_tool, te)
        tool_proj = self.tool_proj(tool_emb)                            # (B, W_tool, d)

        # 3. mood channel — single token
        mood_proj = self.mood_proj(mood.to(self.device)).unsqueeze(1)   # (B, 1, d)

        # 4. vision channel (optional)
        cls = self.cls_token.expand(B, -1, -1)
        chunks = [cls, text_proj, tool_proj, mood_proj]
        if self.cfg.use_vision:
            paths_in = image_paths if image_paths is not None else [[] for _ in range(B)]
            img_emb = self.encode_images(paths_in)                       # (B, W_img, ve)
            img_proj = self.vision_proj(img_emb)                         # (B, W_img, d)
            chunks.append(img_proj)
        x = torch.cat(chunks, dim=1)                                     # (B, L, d)

        # 5. add type + positional embeddings
        L = x.size(1)
        type_ids = torch.zeros(L, dtype=torch.long, device=self.device)
        # 0=cls, 1=text, 2=tool, 3=mood, 4=image
        type_ids[1:1 + W_msg] = 1
        type_ids[1 + W_msg:1 + W_msg + W_tool] = 2
        type_ids[1 + W_msg + W_tool] = 3                                 # mood (1 token)
        if self.cfg.use_vision:
            start = 2 + W_msg + W_tool
            type_ids[start:start + W_img] = 4
        type_embedding = self.type_embed(type_ids).unsqueeze(0)          # (1, L, d)

        pos_ids = torch.arange(L, device=self.device)
        pos_embedding = self.pos_embed(pos_ids).unsqueeze(0)             # (1, L, d)

        x = x + type_embedding + pos_embedding
        return self.dropout(x)
