"""PredictionScorer — was Caudate right?

Each turn the observer captures both Caudate's prediction (`predicted_*`)
and what actually happened (`actual_*`). The scorer compares them and
maintains rolling accuracy over the last N predictions. Persists to
`data/nn/scorecard.json` so the trust level survives restarts.

Three head-level accuracies tracked:

    tool_acc   : did Caudate name the tool the LLM ended up calling?
    tier_acc   : was the routing tier right? (fast vs slow)
    think_acc  : was the thinking-helps prediction right?

Plus a derived `composite` score (weighted sum) that the graduation
policy reads. Weights match the loss weights in NNConfig so training
and graduation pull in the same direction.
"""

from __future__ import annotations

import collections
import json
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class ScoreRecord:
    """One (predicted, actual) comparison."""

    ts: float
    predicted_tool: str
    actual_tool: str
    predicted_tool_conf: float
    predicted_tier: str               # "fast" | "slow"
    actual_tier: str
    predicted_think: float            # in [0, 1]
    actual_think: bool
    predicted_value: float            # in [0, 1]
    actual_reward: float              # in [0, 1]


class PredictionScorer:
    """Rolling accuracy + persistence."""

    def __init__(
        self,
        window: int = 200,
        path: Path | str = "data/nn/scorecard.json",
        weight_tool: float = 1.0,
        weight_tier: float = 0.5,
        weight_think: float = 0.2,
    ):
        self.window = window
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._records: collections.deque[ScoreRecord] = collections.deque(maxlen=window)
        self._lifetime_total = 0
        self._lifetime_correct_tool = 0
        self._load()

    # ------------------------------------------------------------------

    def add(self, record: ScoreRecord) -> None:
        self._records.append(record)
        self._lifetime_total += 1
        if record.predicted_tool == record.actual_tool:
            self._lifetime_correct_tool += 1
        # Throttled save — every 8 records to keep disk pressure low.
        if self._lifetime_total % 8 == 0:
            self._save()

    def __len__(self) -> int:
        return len(self._records)

    @property
    def lifetime_predictions(self) -> int:
        return self._lifetime_total

    # ------------------------------------------------------------------
    # Metrics
    # ------------------------------------------------------------------

    def tool_acc(self) -> float:
        if not self._records:
            return 0.0
        hits = sum(1 for r in self._records if r.predicted_tool == r.actual_tool)
        return hits / len(self._records)

    def tier_acc(self) -> float:
        if not self._records:
            return 0.0
        hits = sum(1 for r in self._records if r.predicted_tier == r.actual_tier)
        return hits / len(self._records)

    def think_acc(self) -> float:
        if not self._records:
            return 0.0
        hits = sum(1 for r in self._records if (r.predicted_think >= 0.5) == r.actual_think)
        return hits / len(self._records)

    def value_mae(self) -> float:
        """Mean absolute error of value predictions (lower is better)."""
        if not self._records:
            return 1.0
        return sum(abs(r.predicted_value - r.actual_reward) for r in self._records) / len(self._records)

    def composite(
        self,
        weight_tool: float = 1.0,
        weight_tier: float = 0.5,
        weight_think: float = 0.2,
    ) -> float:
        """Weighted accuracy across heads, normalized to [0, 1]."""
        total_w = weight_tool + weight_tier + weight_think
        return (
            self.tool_acc() * weight_tool
            + self.tier_acc() * weight_tier
            + self.think_acc() * weight_think
        ) / max(1e-8, total_w)

    def lifetime_tool_acc(self) -> float:
        if self._lifetime_total == 0:
            return 0.0
        return self._lifetime_correct_tool / self._lifetime_total

    def report(self) -> dict[str, Any]:
        return {
            "window": self.window,
            "samples_in_window": len(self._records),
            "lifetime_predictions": self._lifetime_total,
            "tool_acc": round(self.tool_acc(), 4),
            "tier_acc": round(self.tier_acc(), 4),
            "think_acc": round(self.think_acc(), 4),
            "value_mae": round(self.value_mae(), 4),
            "composite": round(self.composite(), 4),
            "lifetime_tool_acc": round(self.lifetime_tool_acc(), 4),
        }

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def _load(self) -> None:
        if not self.path.exists():
            return
        try:
            data = json.loads(self.path.read_text())
        except Exception as e:
            logger.warning(f"scorer load failed: {e}")
            return
        self._lifetime_total = int(data.get("lifetime_total", 0))
        self._lifetime_correct_tool = int(data.get("lifetime_correct_tool", 0))
        for d in data.get("records", []):
            try:
                self._records.append(ScoreRecord(**d))
            except Exception:
                continue

    def _save(self) -> None:
        try:
            payload = {
                "lifetime_total": self._lifetime_total,
                "lifetime_correct_tool": self._lifetime_correct_tool,
                "saved_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "records": [r.__dict__ for r in self._records],
            }
            self.path.write_text(json.dumps(payload, indent=2))
        except Exception as e:
            logger.debug(f"scorer save failed: {e}")
