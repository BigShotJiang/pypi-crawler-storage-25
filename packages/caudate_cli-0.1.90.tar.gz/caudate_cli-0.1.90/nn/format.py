"""Standard chat-conversation schema for Caudate.

The on-disk and in-memory training format mirrors the OpenAI tool-call
JSON shape that every public tool-use dataset uses (xLAM, ToolBench,
ToolAlpaca, Gorilla, API-Bank). This lets Caudate train directly on
external corpora without an adapter step.

Schema (one training example):

    {
      "conversations": [
        {"role": "system" | "user" | "assistant" | "tool",
         "content": str,
         "tool_calls"?: [
            {"type": "function",
             "function": {"name": str, "arguments": str (JSON)}}
         ],
         "name"?: str,            # required when role == "tool"
         "tool_call_id"?: str},   # links a tool result back to the call
        ...
      ],
      "tools": [
        {"type": "function",
         "function": {"name": str, "description": str,
                      "parameters": dict (JSON schema)}}
      ]
    }

These dataclasses are deliberately thin — no validation beyond what
parsing needs. The trainer treats malformed rows as skip-and-continue
rather than raising, because external datasets are noisy.

Cognos-specific signals (mood, the 14 optional heads, model_source,
images) live on ConversationSample in nn/data.py, NOT in this schema —
that's the boundary that keeps external data ingestible.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any


# ─── Tool call (assistant → tool) ─────────────────────────────────────


@dataclass
class ToolCall:
    """One function call inside an assistant message."""

    name: str
    arguments: str = ""        # JSON-encoded string per OpenAI spec
    id: str | None = None      # tool_call_id; optional in some datasets

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "ToolCall":
        # OpenAI shape: {"type": "function", "function": {"name", "arguments"}}
        # Some datasets flatten: {"name", "arguments"}. Accept both.
        fn = d.get("function") if isinstance(d.get("function"), dict) else d
        args = fn.get("arguments", "")
        # Arguments can be a dict in some datasets — normalise to JSON string
        # so downstream consumers don't have to handle both shapes.
        if isinstance(args, dict):
            args = json.dumps(args)
        return cls(
            name=str(fn.get("name") or ""),
            arguments=str(args or ""),
            id=d.get("id") or d.get("tool_call_id"),
        )

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "type": "function",
            "function": {"name": self.name, "arguments": self.arguments},
        }
        if self.id is not None:
            out["id"] = self.id
        return out


# ─── Chat message ─────────────────────────────────────────────────────


@dataclass
class ChatMessage:
    """One conversation turn. Roles: system | user | assistant | tool."""

    role: str
    content: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)
    name: str | None = None          # tool name when role == "tool"
    tool_call_id: str | None = None  # links tool result to the call

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "ChatMessage":
        # `content` is sometimes a list of content-blocks (OpenAI vision
        # shape). Flatten to text — Caudate's encoder doesn't currently
        # consume content-block structure, only the text. Vision still
        # works through image_paths on ConversationSample.
        content = d.get("content")
        if isinstance(content, list):
            chunks: list[str] = []
            for blk in content:
                if isinstance(blk, dict):
                    txt = blk.get("text") or blk.get("content") or ""
                    if txt:
                        chunks.append(str(txt))
                elif isinstance(blk, str):
                    chunks.append(blk)
            content = " ".join(chunks)
        elif content is None:
            content = ""
        raw_calls = d.get("tool_calls") or []
        calls = [ToolCall.from_dict(c) for c in raw_calls if isinstance(c, dict)]
        return cls(
            role=str(d.get("role") or ""),
            content=str(content),
            tool_calls=calls,
            name=d.get("name"),
            tool_call_id=d.get("tool_call_id"),
        )

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {"role": self.role, "content": self.content}
        if self.tool_calls:
            out["tool_calls"] = [tc.to_dict() for tc in self.tool_calls]
        if self.name is not None:
            out["name"] = self.name
        if self.tool_call_id is not None:
            out["tool_call_id"] = self.tool_call_id
        return out


# ─── Tool definition (what's available for the assistant to call) ─────


@dataclass
class ToolDef:
    """One tool entry in the `tools` field of a training example."""

    name: str
    description: str = ""
    parameters: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "ToolDef":
        fn = d.get("function") if isinstance(d.get("function"), dict) else d
        params = fn.get("parameters") or {}
        if not isinstance(params, dict):
            params = {}
        return cls(
            name=str(fn.get("name") or ""),
            description=str(fn.get("description") or ""),
            parameters=params,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }


# ─── Conversation (one training example, schema-side only) ───────────


@dataclass
class Conversation:
    """A single training example in standard chat-tool-call shape.

    This is the disk/serialization view. The training-time view —
    Conversation plus Cognos-specific signals (mood, model_source,
    image_paths, optional head targets) — is ConversationSample in
    nn/data.py."""

    messages: list[ChatMessage] = field(default_factory=list)
    tools: list[ToolDef] = field(default_factory=list)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Conversation":
        # Accept both "messages" (modern) and "conversations" (some legacy
        # datasets) as the field name for the turn list.
        raw_msgs = d.get("messages")
        if raw_msgs is None:
            raw_msgs = d.get("conversations") or []
        raw_tools = d.get("tools") or []
        return cls(
            messages=[
                ChatMessage.from_dict(m) for m in raw_msgs if isinstance(m, dict)
            ],
            tools=[
                ToolDef.from_dict(t) for t in raw_tools if isinstance(t, dict)
            ],
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "messages": [m.to_dict() for m in self.messages],
            "tools": [t.to_dict() for t in self.tools],
        }


# ─── Iteration helpers used by ConversationSample & loaders ──────────


def iter_assistant_tool_calls(
    conv: Conversation,
) -> list[tuple[int, ToolCall]]:
    """Yield (message_index, ToolCall) for every assistant tool call.

    Used by loaders that need to emit one training sample *per tool
    call* — the canonical Caudate training granularity is "given this
    prefix, what tool gets called next?". Each tool call inside an
    assistant message is one training row."""
    out: list[tuple[int, ToolCall]] = []
    for i, msg in enumerate(conv.messages):
        if msg.role != "assistant":
            continue
        for tc in msg.tool_calls:
            out.append((i, tc))
    return out


__all__ = [
    "ChatMessage",
    "ToolCall",
    "ToolDef",
    "Conversation",
    "iter_assistant_tool_calls",
]
