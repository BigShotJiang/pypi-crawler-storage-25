"""Cognos neural-network subsystem — home of Caudate.

Caudate is Cognos's action-selection brain — a small PyTorch transformer
named for the caudate nucleus, the basal-ganglia structure that learns
from outcomes to bias which action a real brain takes next. She trains
on Cognos's own session history to predict, per turn:

    1. which tool to call next
    2. which routing tier (System 1 / System 2) is appropriate
    3. whether engaging chain-of-thought helps
    4. an expected reward / value estimate

Caudate does NOT replace the LLM cortex. She runs alongside as an
*advisor*: every inference is logged, and (later) optionally biases the
agent's prompt. Bad predictions don't break the agent.

Module layout:

    nn/config.py        hyperparameters
    nn/encoder.py       state encoder (text + tool history + mood)
    nn/caudate.py       Caudate — transformer + 4 output heads
    nn/data.py          dataset + replay buffer
    nn/trainer.py       optimizer / loss / eval / checkpointing
    nn/consolidator.py  offline replay → training pairs
    nn/runtime.py       inference loader + CaudateAdvisor

Persistent state lives at `data/nn/`.
"""

from nn.caudate import Caudate, CognosController  # alias kept for compat
from nn.config import NNConfig
from nn.encoder import StateEncoder
from nn.runtime import CaudateAdvisor, NNAdvisor, load_advisor

__all__ = [
    "NNConfig",
    "Caudate",
    "CognosController",
    "StateEncoder",
    "CaudateAdvisor",
    "NNAdvisor",
    "load_advisor",
]
