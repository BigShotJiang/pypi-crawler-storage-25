"""Cognos configuration."""

from pathlib import Path

# Paths
BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
LOGS_DIR = BASE_DIR / "logs"
CHROMA_DIR = DATA_DIR / "chroma"
SQLITE_PATH = DATA_DIR / "cognos.db"

# Ensure dirs exist
DATA_DIR.mkdir(exist_ok=True)
LOGS_DIR.mkdir(exist_ok=True)

# LLM settings
LLM_PROVIDER = "ollama"  # "ollama", "anthropic", "openai"
LLM_MODEL = "ollama/gemma3:27b"  # primary fallback if no `model` in ~/.cognos/settings.json
LLM_TEMPERATURE = 0.7
LLM_MAX_TOKENS = 4096

# Memory settings
WORKING_MEMORY_CAPACITY = 20  # max items in working memory
EPISODIC_RECALL_LIMIT = 5  # max episodes to recall
SEMANTIC_RECALL_LIMIT = 5  # max knowledge items to recall

# Planning settings
MAX_PLAN_DEPTH = 5  # max depth of task decomposition
MAX_REPLAN_ATTEMPTS = 3  # max re-planning attempts before giving up
# Per-task failure budget within a single plan. Mirrors the dual-brain
# escalation rule: when the same task fails this many times, stop
# retrying it and force a replan that avoids that approach. Prevents
# burning replan attempts on a task the planner keeps re-issuing.
MAX_TASK_FAILURES = 2

# Reflection settings
SUCCESS_THRESHOLD = 0.7  # minimum score to consider a step successful
STRATEGY_UPDATE_INTERVAL = 5  # update strategies every N reflections

# Permissions
PERMISSION_MODE = "default"  # "default" | "plan" | "accept_edits" | "bypass"
AUDIT_LOG_PATH = DATA_DIR / "audit.jsonl"

# Hooks
HOOKS_CONFIG_PATH = DATA_DIR / "hooks.json"

# Sessions & compaction
SESSIONS_DIR = DATA_DIR / "sessions"
CONTEXT_WINDOW_SIZE = 32000  # approximate token budget
COMPACT_THRESHOLD = 0.8  # fraction of context window before compaction kicks in
COMPACT_KEEP_RECENT = 6  # recent messages preserved verbatim

# MCP
MCP_CONFIG_PATH = DATA_DIR / "mcp_servers.json"

# Personality
IDENTITY_PATH = DATA_DIR / "identity.json"
MOOD_PATH = DATA_DIR / "mood.json"
PERSONALITY_ENABLED = True  # set False for a sterile, voice-less agent

# Plugins (Phase 5B)
PLUGINS_DIR = BASE_DIR / "plugins"

# Dual-process brain (Phase 4)
# When both are set, Cognos routes calls between System 1 (fast) and System 2
# (slow). Set either to empty string or None to disable routing and use the
# primary LLM_MODEL for everything.
# Kept in sync with ~/.cognos/settings.json (system1/system2 keys).
# settings.json wins at runtime if it sets these — these are the fallback
# defaults so a fresh clone with no settings file behaves the same.
SYSTEM_1_MODEL = "ollama/glm-5.1:cloud"
SYSTEM_2_MODEL = "anthropic/claude-haiku-4-5"
ROUTER_COMPLEXITY_THRESHOLD = 0.40

# Prompt caching hints (Anthropic provider only)
# When True, Cognos wraps the system prompt + tool definitions in cache_control
# content blocks so Anthropic caches them across turns. Ignored by Ollama/others.
# Safe to leave on — adds a tiny amount of overhead on non-Anthropic providers.
PROMPT_CACHING = True

# Files API (data/files/)
FILES_DIR = DATA_DIR / "files"
