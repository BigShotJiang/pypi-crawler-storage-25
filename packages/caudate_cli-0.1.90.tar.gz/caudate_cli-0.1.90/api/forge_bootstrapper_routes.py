"""Bootstrapper chat-session routes — back-and-forth before committing.

Mirrors LocalForge's
  GET/POST /api/projects/:id/bootstrapper-session
  GET/POST /api/agent-sessions/:id/messages
  POST     /api/agent-sessions/:id/generate-features
  POST     /api/agent-sessions/:id/close

In Cognos, we reuse:
  - ``forge_sessions`` rows where ``session_type="bootstrapper"``
  - ``forge_chat_messages`` for the conversation
  - ``LLMProvider.stream`` for the SSE response
  - ``ForgeFeatureTools`` for agent-driven feature creation in
    /generate-features (the agent already has these tools registered;
    we just bind the project context with ``forge_project_scope``).
"""

from __future__ import annotations

import asyncio
import json
import logging
from datetime import datetime
from typing import Any, AsyncIterator

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

logger = logging.getLogger(__name__)


# Steering prompt for the conversational stage.
BOOTSTRAPPER_CHAT_SYSTEM_PROMPT = (
    "You are Cognos Forge's AI bootstrapper. You help the user describe an "
    "app they want to build. You are friendly, concise, and speak in 2-4 "
    "sentences per reply. Ask one or two follow-up questions at a time "
    "about the app's users, core features, data, and UI. When the user "
    "seems satisfied with the plan, say so and invite them to click "
    "'Generate feature list' to commit. Never produce code, markdown "
    "tables, or long bullet walls — keep replies conversational."
)

# Steering prompt for the structured-output commit stage.
FEATURE_GEN_SYSTEM_PROMPT = (
    "You are Cognos Forge's feature-generation agent.\n\n"
    "You are given a user/assistant chat describing an app. Your job is "
    "to turn that conversation into a complete backlog of 6-15 features "
    "by calling the provided forge_* tools.\n\n"
    "Workflow:\n"
    "1. Call forge_list_features to see what (if anything) is already "
    "in the backlog.\n"
    "2. Plan the build in dependency order: foundational work first "
    "(schema, app shell, core data model), then behaviour, then polish.\n"
    "3. Call forge_create_feature for each item, in order. Pass "
    "depends_on with the ids of earlier features that must complete "
    "first. Depends_on must ONLY reference features that already exist.\n"
    "4. Make sure the backlog covers persistence, UI, and at least one "
    "polish/style feature.\n"
    "5. When you are done creating features, STOP calling tools and "
    "reply with a single short sentence summarising how many features "
    "you created.\n\n"
    "Rules:\n"
    "- Title: short imperative sentence under 100 characters.\n"
    "- Description: one paragraph describing what 'done' looks like.\n"
    "- category: 'functional' or 'style' (default functional).\n\n"
    "Do NOT output code, markdown fences, or JSON in your replies — "
    "all structured output goes through the tools."
)


class ChatMessageIn(BaseModel):
    content: str


class CloseSessionIn(BaseModel):
    status: str | None = None  # completed | failed | terminated


# ─────────────────────────── Helpers ────────────────────────────────


def _lazy():
    from planning import forge_models as fm
    return fm


def _get_active_bootstrapper(project_id: int) -> dict[str, Any] | None:
    fm = _lazy()
    with fm.session_scope() as sess:
        row = (
            sess.query(fm.ForgeSession)
            .filter_by(
                project_id=project_id,
                session_type="bootstrapper",
                status="in_progress",
            )
            .order_by(fm.ForgeSession.id.desc())
            .first()
        )
        if row is None:
            return None
        return _session_dict(row)


def _session_dict(row) -> dict[str, Any]:
    return {
        "id": row.id,
        "project_id": row.project_id,
        "feature_id": row.feature_id,
        "session_type": row.session_type,
        "status": row.status,
        "started_at": row.started_at.isoformat() if row.started_at else None,
        "ended_at": row.ended_at.isoformat() if row.ended_at else None,
    }


def _list_messages(session_id: int) -> list[dict[str, Any]]:
    fm = _lazy()
    with fm.session_scope() as sess:
        rows = (
            sess.query(fm.ForgeChatMessage)
            .filter_by(session_id=session_id)
            .order_by(fm.ForgeChatMessage.id.asc())
            .all()
        )
        return [
            {
                "id": r.id,
                "session_id": r.session_id,
                "role": r.role,
                "content": r.content,
                "created_at": r.created_at.isoformat() if r.created_at else None,
            }
            for r in rows
        ]


def _append_message(
    session_id: int, role: str, content: str,
) -> dict[str, Any]:
    fm = _lazy()
    with fm.session_scope() as sess:
        row = fm.ForgeChatMessage(
            session_id=session_id, role=role, content=content,
        )
        sess.add(row)
        sess.flush()
        return {
            "id": row.id, "session_id": row.session_id,
            "role": row.role, "content": row.content,
            "created_at": row.created_at.isoformat() if row.created_at else None,
        }


def _close_session(session_id: int, status: str) -> dict[str, Any] | None:
    fm = _lazy()
    valid = {"completed", "failed", "terminated"}
    if status not in valid:
        status = "completed"
    with fm.session_scope() as sess:
        row = sess.get(fm.ForgeSession, session_id)
        if row is None:
            return None
        if row.status == "in_progress":
            row.status = status
            row.ended_at = datetime.utcnow()
        return _session_dict(row)


# ─────────────────────────── Router ─────────────────────────────────


def build_router() -> APIRouter:
    router = APIRouter(prefix="/forge", tags=["forge-bootstrapper"])

    # ── Session create / fetch ──────────────────────────────────────

    @router.get("/projects/{project_id}/bootstrapper-session")
    async def get_bootstrapper(project_id: int) -> dict[str, Any]:
        fm = _lazy()
        if fm.get_project(project_id) is None:
            raise HTTPException(404, "project not found")
        return {"session": _get_active_bootstrapper(project_id)}

    @router.post("/projects/{project_id}/bootstrapper-session")
    async def post_bootstrapper(project_id: int) -> dict[str, Any]:
        fm = _lazy()
        if fm.get_project(project_id) is None:
            raise HTTPException(404, "project not found")
        existing = _get_active_bootstrapper(project_id)
        if existing is not None:
            return {"session": existing, "reused": True}
        with fm.session_scope() as sess:
            row = fm.ForgeSession(
                project_id=project_id,
                session_type="bootstrapper",
                status="in_progress",
            )
            sess.add(row)
            sess.flush()
            return {"session": _session_dict(row), "reused": False}

    # ── Messages ────────────────────────────────────────────────────

    @router.get("/agent-sessions/{session_id}/messages")
    async def list_messages(session_id: int) -> dict[str, Any]:
        fm = _lazy()
        with fm.session_scope() as sess:
            row = sess.get(fm.ForgeSession, session_id)
            if row is None:
                raise HTTPException(404, "session not found")
        return {"messages": _list_messages(session_id)}

    @router.post("/agent-sessions/{session_id}/messages")
    async def post_message(
        session_id: int, body: ChatMessageIn,
    ) -> StreamingResponse:
        fm = _lazy()
        with fm.session_scope() as sess:
            srow = sess.get(fm.ForgeSession, session_id)
            if srow is None:
                raise HTTPException(404, "session not found")
            if srow.status != "in_progress":
                raise HTTPException(
                    409, "this session is closed; start a new conversation",
                )
            project_id = srow.project_id

        content = (body.content or "").strip()
        if not content:
            raise HTTPException(400, "field 'content' is required")

        # Persist user message immediately so it survives downstream errors.
        user_msg = _append_message(session_id, "user", content)
        history = _list_messages(session_id)

        async def gen() -> AsyncIterator[bytes]:
            yield f"data: {json.dumps({'type': 'user', 'message': user_msg})}\n\n".encode()
            from llm.provider import LLMProvider
            from core.settings import Settings
            from config import SYSTEM_1_MODEL, SYSTEM_2_MODEL, LLM_MODEL
            from core.anthropic_auth import subscription_auth_scope

            s = Settings.load()
            chosen = (
                s.get("system1") or SYSTEM_1_MODEL
                or s.get("system2") or SYSTEM_2_MODEL
                or LLM_MODEL
            )
            llm = LLMProvider(model=chosen)
            messages = [
                {"role": "system", "content": BOOTSTRAPPER_CHAT_SYSTEM_PROMPT},
            ] + [
                {"role": m["role"], "content": m["content"]}
                for m in history
            ]
            full = ""
            errored = False
            try:
                with subscription_auth_scope():
                    async for ev in llm.stream(messages):
                        et = getattr(ev, "type", None)
                        if et == "text_delta":
                            # core.schemas.StreamEvent uses .delta for text
                            delta = (
                                getattr(ev, "delta", None)
                                or getattr(ev, "text", "")
                                or ""
                            )
                            if delta:
                                full += delta
                                yield (
                                    f"data: {json.dumps({'type': 'delta', 'content': delta})}\n\n"
                                ).encode()
                        elif et in ("message_stop", "message_end"):
                            break
            except asyncio.CancelledError:
                raise
            except Exception as e:
                errored = True
                yield (
                    f"data: {json.dumps({'type': 'error', 'message': str(e)})}\n\n"
                ).encode()

            if not errored:
                assistant_msg = _append_message(
                    session_id, "assistant",
                    full.strip() or "(empty response)",
                )
                yield (
                    f"data: {json.dumps({'type': 'assistant', 'message': assistant_msg})}\n\n"
                ).encode()
                yield b'data: {"type": "done"}\n\n'

        return StreamingResponse(gen(), media_type="text/event-stream")

    # ── Close session ───────────────────────────────────────────────

    @router.post("/agent-sessions/{session_id}/close")
    async def close_session(
        session_id: int, body: CloseSessionIn | None = None,
    ) -> dict[str, Any]:
        fm = _lazy()
        with fm.session_scope() as sess:
            row = sess.get(fm.ForgeSession, session_id)
            if row is None:
                raise HTTPException(404, "session not found")
            if row.status != "in_progress":
                return {"session": _session_dict(row), "closed": False}
        status = (body.status if body else None) or "completed"
        updated = _close_session(session_id, status)
        return {"session": updated, "closed": True}

    # ── Generate features (commit transcript → backlog) ─────────────

    @router.post("/agent-sessions/{session_id}/generate-features")
    async def generate_features(session_id: int) -> dict[str, Any]:
        fm = _lazy()
        with fm.session_scope() as sess:
            srow = sess.get(fm.ForgeSession, session_id)
            if srow is None:
                raise HTTPException(404, "session not found")
            if srow.session_type != "bootstrapper":
                raise HTTPException(400, "not a bootstrapper session")
            project_id = srow.project_id
        history = _list_messages(session_id)
        if not history:
            raise HTTPException(
                400, "no conversation yet — send a message first",
            )

        # Prefix the transcript so the agent has the context.
        transcript = "\n\n".join(
            f"{m['role'].upper()}: {m['content']}" for m in history
        )

        # Snapshot existing features so we can compute what was created.
        existing_before = len(fm.list_features(project_id))

        from core.agent import CognosAgent
        from execution.tools.forge_feature_tools import forge_project_scope
        from core.anthropic_auth import subscription_auth_scope

        prompt = (
            f"{FEATURE_GEN_SYSTEM_PROMPT}\n\n"
            f"The bootstrapper chat transcript follows. Generate the "
            f"backlog now via tool calls.\n\n{transcript}"
        )

        try:
            agent = CognosAgent()
            with subscription_auth_scope(), forge_project_scope(project_id):
                resp = await agent.chat(prompt, stream=False)
        except Exception as e:
            logger.exception("generate-features agent failed")
            raise HTTPException(502, f"agent failed: {e}")

        summary = str(getattr(resp, "content", resp) or "")[:500]
        features_after = fm.list_features(project_id)
        created = len(features_after) - existing_before
        if created <= 0:
            raise HTTPException(
                502,
                "agent finished without creating any features. Try again "
                "with a clearer description.",
            )
        # Auto-close the bootstrapper session
        _close_session(session_id, "completed")
        return {
            "count": created,
            "total": len(features_after),
            "project_id": project_id,
            "summary": summary,
        }

    return router
