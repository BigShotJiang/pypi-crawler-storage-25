"""Forge HTTP routes — REST API for the autonomous coding harness.

Mirrors LocalForge's /api/projects, /api/features, /api/agent-sessions
surface, ported to Cognos's FastAPI server. All state lives in
data/cognos.db (planning/forge_models.py); execution is driven by
planning/orchestrator.py.

Endpoints:
  GET    /forge/projects                        list projects (with feature counts)
  POST   /forge/projects                        create project
  GET    /forge/projects/{id}                   kanban state (project + features + running)
  DELETE /forge/projects/{id}                   delete project
  POST   /forge/projects/{id}/features          create feature
  POST   /forge/projects/{id}/bootstrap         NL → backlog (calls bootstrapper)
  POST   /forge/projects/{id}/start             start orchestrator (next ready feature)
  POST   /forge/projects/{id}/stop              stop all sessions for project
  GET    /forge/features/{id}                   one feature
  PATCH  /forge/features/{id}                   update feature fields
  DELETE /forge/features/{id}                   delete feature
  POST   /forge/features/{id}/dependencies      bulk-replace deps (LocalForge semantics)
  POST   /forge/sessions/{id}/stop              stop one session
  GET    /forge/sessions/{id}/events            SSE stream of one session's events
  GET    /forge/events                          SSE stream of all events
  GET    /forge/sessions/{id}/messages          chat messages for a bootstrapper session

Same SSE format LocalForge uses (`data: <json>\n\n`); the kanban UI
in ui/web/app.js consumes both endpoints.
"""

from __future__ import annotations

import asyncio
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


# ───────────────────────── Pydantic schemas ───────────────────────────


class CreateProjectIn(BaseModel):
    name: str
    description: str | None = None
    folder_path: str | None = None  # default: sandbox/projects/<slug>


class CreateFeatureIn(BaseModel):
    title: str
    description: str | None = None
    acceptance_criteria: str | None = None
    priority: int = 0
    category: str = "functional"
    verify_command: str | None = None


class UpdateFeatureIn(BaseModel):
    title: str | None = None
    description: str | None = None
    acceptance_criteria: str | None = None
    status: str | None = None
    priority: int | None = None
    category: str | None = None
    verify_command: str | None = None


class BootstrapIn(BaseModel):
    goal: str
    stack_hints: list[str] = Field(default_factory=list)
    max_features: int = 15
    dry_run: bool = False


class DependenciesIn(BaseModel):
    depends_on: list[int] = Field(default_factory=list)


class ProjectSettingsIn(BaseModel):
    """Per-project setting overrides. Empty string / None clears."""
    provider: str | None = None
    ollama_url: str | None = None
    lm_studio_url: str | None = None
    model: str | None = None
    coder_prompt: str | None = None
    dev_server_command: str | None = None
    dev_server_port: int | None = None
    max_concurrent_agents: int | None = None
    playwright_enabled: bool | None = None
    playwright_headed: bool | None = None


class LoadExampleIn(BaseModel):
    example: str
    name: str | None = None


# ──────────────────────────── Router ─────────────────────────────────


def build_router() -> APIRouter:
    router = APIRouter(prefix="/forge", tags=["forge"])

    # Lazy imports — keep server import time tight if forge isn't used.
    def _lazy():
        from planning import forge_models as fm
        from planning import orchestrator as orch
        return fm, orch

    # ── Projects ───────────────────────────────────────────────────────

    @router.get("/projects")
    async def list_projects() -> list[dict[str, Any]]:
        fm, _ = _lazy()
        fm.init()
        projects = fm.list_projects()
        # decorate with feature counts for the sidebar
        for p in projects:
            with fm.session_scope() as sess:
                feats = (
                    sess.query(fm.ForgeFeature)
                    .filter_by(project_id=p["id"])
                    .all()
                )
                counts = {"backlog": 0, "in_progress": 0, "completed": 0}
                for f in feats:
                    counts[f.status] = counts.get(f.status, 0) + 1
                p["feature_counts"] = counts
        return projects

    @router.post("/projects")
    async def create_project(body: CreateProjectIn) -> dict[str, Any]:
        fm, _ = _lazy()
        fm.init()
        import re
        folder = body.folder_path or str(
            Path("sandbox/projects") /
            re.sub(r"[^a-zA-Z0-9_-]+", "-", body.name.lower()).strip("-")
        )
        Path(folder).mkdir(parents=True, exist_ok=True)
        try:
            pid = fm.create_project(body.name, body.description, folder)
        except Exception as e:
            raise HTTPException(409, str(e))
        return fm.get_project(pid) or {}

    @router.get("/projects/{project_id}")
    async def get_kanban(project_id: int) -> dict[str, Any]:
        _, orch = _lazy()
        try:
            return orch.get_kanban_state(project_id)
        except Exception as e:
            status = getattr(e, "status", 500)
            raise HTTPException(status, str(e))

    @router.delete("/projects/{project_id}")
    async def delete_project(project_id: int) -> dict[str, str]:
        fm, orch = _lazy()
        # Stop any running sessions first
        orch.stop_all_for_project(project_id)
        with fm.session_scope() as sess:
            row = sess.get(fm.ForgeProject, project_id)
            if row is None:
                raise HTTPException(404, "project not found")
            sess.delete(row)
        return {"status": "deleted"}

    @router.post("/projects/{project_id}/features")
    async def add_feature(
        project_id: int, body: CreateFeatureIn,
    ) -> dict[str, Any]:
        fm, _ = _lazy()
        try:
            fid = fm.create_feature(
                project_id=project_id,
                title=body.title,
                description=body.description,
                acceptance_criteria=body.acceptance_criteria,
                priority=body.priority,
                category=body.category,
                verify_command=body.verify_command,
            )
        except ValueError as e:
            raise HTTPException(400, str(e))
        return {"id": fid}

    @router.post("/projects/{project_id}/bootstrap")
    async def bootstrap(project_id: int, body: BootstrapIn) -> dict[str, Any]:
        """Decompose a goal into features. Writes to DB unless dry_run."""
        fm, _ = _lazy()
        from planning.planner import Planner
        from llm.provider import LLMProvider
        from core.settings import Settings
        from config import SYSTEM_1_MODEL, SYSTEM_2_MODEL, LLM_MODEL

        proj = fm.get_project(project_id)
        if not proj:
            raise HTTPException(404, "project not found")

        # Local-first: prefer the user's System-1 Ollama model for the
        # bootstrap (a structured-output task GLM-class models handle
        # well). Falls back to System-2 only if no System-1 is set.
        settings = Settings.load()
        chosen = (
            settings.get("system1") or SYSTEM_1_MODEL
            or settings.get("system2") or SYSTEM_2_MODEL
            or LLM_MODEL
        )
        logger.info(f"forge bootstrap model: {chosen}")
        llm = LLMProvider(model=chosen)
        planner = Planner(llm)
        # Anthropic models authenticate via the user's Claude Code OAuth
        # token (~/.claude/.credentials.json) instead of ANTHROPIC_API_KEY.
        # subscription_auth_scope() flips a ContextVar that LLMProvider
        # reads on every call.
        from core.anthropic_auth import subscription_auth_scope
        try:
            with subscription_auth_scope():
                features = await planner.decompose_to_features(
                    goal=body.goal,
                    stack_hints=list(body.stack_hints),
                    max_features=body.max_features,
                )
        except Exception as e:
            raise HTTPException(500, f"bootstrapper failed: {e}")

        out = [f.model_dump() for f in features]
        if body.dry_run:
            return {"features": out, "written": False}

        idx_to_id: dict[int, int] = {}
        for idx, f in enumerate(features):
            cat = f.category if f.category in ("functional", "style") \
                  else "functional"
            fid = fm.create_feature(
                project_id=project_id,
                title=f.title,
                description=f.description,
                acceptance_criteria=f.acceptance_criteria,
                priority=f.priority,
                category=cat,
                verify_command=f.verify_command,
            )
            idx_to_id[idx] = fid
        for idx, f in enumerate(features):
            for dep_idx in f.depends_on:
                if dep_idx in idx_to_id and dep_idx != idx:
                    try:
                        fm.add_dependency(idx_to_id[idx], idx_to_id[dep_idx])
                    except Exception as e:
                        logger.warning(f"dep wire failed: {e}")
        return {"features": out, "written": True, "ids": list(idx_to_id.values())}

    # ── Features ───────────────────────────────────────────────────────

    @router.get("/features/{feature_id}")
    async def get_feature(feature_id: int) -> dict[str, Any]:
        fm, _ = _lazy()
        with fm.session_scope() as sess:
            row = sess.get(fm.ForgeFeature, feature_id)
            if row is None:
                raise HTTPException(404, "feature not found")
            deps = (
                sess.query(fm.ForgeFeatureDep.depends_on_feature_id)
                .filter_by(feature_id=feature_id)
                .all()
            )
            return {
                "id": row.id, "project_id": row.project_id,
                "title": row.title, "description": row.description,
                "acceptance_criteria": row.acceptance_criteria,
                "status": row.status, "priority": row.priority,
                "category": row.category,
                "verify_command": row.verify_command,
                "depends_on": [d[0] for d in deps],
            }

    @router.patch("/features/{feature_id}")
    async def update_feature(
        feature_id: int, body: UpdateFeatureIn,
    ) -> dict[str, Any]:
        """Patch a feature. Routes through forge_models.update_feature
        so the project-completion side effect (auto-promote
        project.status when every feature lands at 'completed') fires."""
        fm, _ = _lazy()
        updates = body.model_dump(exclude_unset=True)
        try:
            row = fm.update_feature(feature_id, **updates)
        except ValueError as e:
            raise HTTPException(400, str(e))
        if row is None:
            raise HTTPException(404, "feature not found")
        return await get_feature(feature_id)

    @router.delete("/features/{feature_id}")
    async def delete_feature(feature_id: int) -> dict[str, str]:
        fm, _ = _lazy()
        with fm.session_scope() as sess:
            row = sess.get(fm.ForgeFeature, feature_id)
            if row is None:
                raise HTTPException(404, "feature not found")
            sess.delete(row)
        return {"status": "deleted"}

    @router.post("/features/{feature_id}/dependencies")
    async def set_deps(
        feature_id: int, body: DependenciesIn,
    ) -> dict[str, Any]:
        """Bulk-replace deps for a feature (matches LocalForge semantics).
        Routes through ``forge_models.set_dependencies`` so cycle
        detection is enforced — a request that would create a cycle is
        rejected wholesale (400)."""
        fm, _ = _lazy()
        if fm.get_feature(feature_id) is None:
            raise HTTPException(404, "feature not found")
        try:
            fm.set_dependencies(feature_id, list(body.depends_on))
        except ValueError as e:
            raise HTTPException(400, str(e))
        return {"status": "ok", "depends_on": body.depends_on}

    # ── Orchestrator control ───────────────────────────────────────────

    @router.post("/projects/{project_id}/start")
    async def start_project(project_id: int) -> dict[str, Any]:
        _, orch = _lazy()
        try:
            return await orch.start_orchestrator(project_id)
        except Exception as e:
            status = getattr(e, "status", 500)
            raise HTTPException(status, str(e))

    @router.post("/projects/{project_id}/stop")
    async def stop_project(project_id: int) -> dict[str, int]:
        _, orch = _lazy()
        n = orch.stop_all_for_project(project_id)
        return {"stopped": n}

    @router.post("/sessions/{session_id}/stop")
    async def stop_session_endpoint(session_id: int) -> dict[str, bool]:
        _, orch = _lazy()
        return {"stopped": orch.stop_session(session_id)}

    # ── Per-project settings (forge_settings table) ────────────────────

    _INT_KEYS = {"dev_server_port", "max_concurrent_agents"}
    _BOOL_KEYS = {"playwright_enabled", "playwright_headed"}

    def _coerce(key: str, raw: str) -> Any:
        if key in _INT_KEYS:
            try:
                return int(raw)
            except ValueError:
                return raw
        if key in _BOOL_KEYS:
            return raw.lower() in ("true", "1", "yes")
        return raw

    def _read_overrides(project_id: int) -> dict[str, Any]:
        fm, _ = _lazy()
        with fm.session_scope() as sess:
            rows = (
                sess.query(fm.ForgeSetting)
                .filter_by(project_id=project_id)
                .all()
            )
            return {r.key: _coerce(r.key, r.value) for r in rows}

    def _global_defaults() -> dict[str, Any]:
        from core.settings import Settings
        from config import SYSTEM_1_MODEL, SYSTEM_2_MODEL, LLM_MODEL
        s = Settings.load()
        return {
            "provider": "ollama",
            "ollama_url": "http://127.0.0.1:11434",
            "lm_studio_url": "http://127.0.0.1:1234",
            "model": (s.get("system1") or SYSTEM_1_MODEL or LLM_MODEL),
            "coder_prompt": "",
            "dev_server_command": "",
            "dev_server_port": 3000,
            "max_concurrent_agents": 3,
            "playwright_enabled": False,
            "playwright_headed": False,
        }

    @router.get("/projects/{project_id}/settings")
    async def get_project_settings(project_id: int) -> dict[str, Any]:
        fm, _ = _lazy()
        if fm.get_project(project_id) is None:
            raise HTTPException(404, "project not found")
        overrides = _read_overrides(project_id)
        defaults = _global_defaults()
        effective = {**defaults, **{k: v for k, v in overrides.items() if v not in (None, "")}}
        return {
            "overrides": overrides,
            "effective": effective,
            "defaults": defaults,
        }

    @router.put("/projects/{project_id}/settings")
    async def put_project_settings(
        project_id: int, body: ProjectSettingsIn,
    ) -> dict[str, Any]:
        fm, _ = _lazy()
        if fm.get_project(project_id) is None:
            raise HTTPException(404, "project not found")
        updates = body.model_dump(exclude_unset=True)
        with fm.session_scope() as sess:
            for k, v in updates.items():
                # Empty string / None clears the override; non-empty sets it.
                row = (
                    sess.query(fm.ForgeSetting)
                    .filter_by(project_id=project_id, key=k)
                    .first()
                )
                if v in (None, ""):
                    if row is not None:
                        sess.delete(row)
                else:
                    if row is None:
                        sess.add(fm.ForgeSetting(
                            project_id=project_id, key=k,
                            value=str(v),
                        ))
                    else:
                        row.value = str(v)
        return await get_project_settings(project_id)

    # ── Completion stats (celebration screen) ──────────────────────────

    @router.get("/projects/{project_id}/completion")
    async def get_completion(project_id: int) -> dict[str, Any]:
        fm, orch = _lazy()
        proj = fm.get_project(project_id)
        if proj is None:
            raise HTTPException(404, "project not found")
        with fm.session_scope() as sess:
            feats = (
                sess.query(fm.ForgeFeature)
                .filter_by(project_id=project_id)
                .all()
            )
            total = len(feats)
            done = sum(1 for f in feats if f.status == "completed")
            sessions = (
                sess.query(fm.ForgeSession)
                .filter_by(project_id=project_id, session_type="coding")
                .all()
            )
            tests_passed = 0
            total_runtime_s = 0.0
            for s in sessions:
                if s.started_at and s.ended_at:
                    total_runtime_s += (s.ended_at - s.started_at).total_seconds()
            # Tests passed: count log rows with message_type='test_result' and "verify" in message
            test_logs = (
                sess.query(fm.ForgeLog)
                .filter(
                    fm.ForgeLog.session_id.in_([s.id for s in sessions]),
                    fm.ForgeLog.message_type == "test_result",
                )
                .all()
            )
            tests_passed = len(test_logs)
            project_started = (
                sess.query(fm.ForgeProject.created_at)
                .filter_by(id=project_id)
                .scalar()
            )
            project_completed_at = max(
                (f.updated_at for f in feats
                 if f.status == "completed" and f.updated_at),
                default=None,
            )
            wallclock_s = (
                (project_completed_at - project_started).total_seconds()
                if project_completed_at and project_started else None
            )
        return {
            "completion": {
                "project_id": project_id,
                "name": proj["name"],
                "status": proj["status"],
                "features_total": total,
                "features_completed": done,
                "tests_passed": tests_passed,
                "agent_runtime_s": total_runtime_s,
                "wallclock_s": wallclock_s,
                "completed_at": (
                    project_completed_at.isoformat()
                    if project_completed_at else None
                ),
            }
        }

    # ── Load example project (seed) ────────────────────────────────────

    @router.post("/projects/load-example")
    async def load_example(body: LoadExampleIn) -> dict[str, Any]:
        from pathlib import Path as _Path
        import json as _json
        slug = (body.example or "").strip()
        if not slug:
            raise HTTPException(400, "field 'example' is required")
        example_path = (_Path(__file__).resolve().parents[1]
                        / "data" / "examples" / f"{slug}.json")
        if not example_path.exists():
            raise HTTPException(404, f"example {slug!r} not found")
        try:
            data = _json.loads(example_path.read_text())
        except Exception as e:
            raise HTTPException(500, f"failed to load example: {e}")

        fm, _ = _lazy()
        fm.init()
        import re as _re
        proj_name = (body.name or data.get("name") or "Example").strip()
        folder = str(
            _Path("sandbox/projects")
            / _re.sub(r"[^a-zA-Z0-9_-]+", "-", proj_name.lower()).strip("-")
        )
        _Path(folder).mkdir(parents=True, exist_ok=True)
        pid = fm.create_project(
            proj_name, data.get("description"), folder,
        )
        feats = data.get("features") or []
        # Pass 1: create rows, remember per-index id
        idx_to_id: list[int] = []
        for f in feats:
            cat = f.get("category") or "functional"
            if cat not in ("functional", "style"):
                cat = "functional"
            fid = fm.create_feature(
                project_id=pid,
                title=f.get("title") or "(untitled)",
                description=f.get("description"),
                acceptance_criteria=f.get("acceptanceCriteria"),
                category=cat,
                priority=int(f.get("priority", 0)),
            )
            idx_to_id.append(fid)
        # Pass 2: wire deps
        deps_wired = 0
        for i, f in enumerate(feats):
            d_idx = f.get("dependsOnIndices") or []
            d_ids = [
                idx_to_id[j] for j in d_idx
                if 0 <= int(j) < len(idx_to_id)
            ]
            if d_ids:
                try:
                    fm.set_dependencies(idx_to_id[i], d_ids)
                    deps_wired += 1
                except Exception as e:
                    logger.warning(f"dep wire failed for feature {i}: {e}")
        return {
            "project": fm.get_project(pid),
            "features_created": len(idx_to_id),
            "dependencies_wired": deps_wired,
        }

    # ── Dev-server panel ───────────────────────────────────────────────

    @router.get("/projects/{project_id}/dev-server")
    async def get_dev_server(project_id: int) -> dict[str, Any]:
        from planning import dev_server as _ds
        return _ds.status(project_id)

    @router.post("/projects/{project_id}/dev-server")
    async def start_dev_server(project_id: int) -> dict[str, Any]:
        fm, _ = _lazy()
        proj = fm.get_project(project_id)
        if proj is None:
            raise HTTPException(404, "project not found")
        # Pull command + port from per-project settings, with fallbacks.
        overrides = _read_overrides(project_id)
        defaults = _global_defaults()
        cmd = overrides.get("dev_server_command") or defaults.get("dev_server_command") or ""
        port_raw = overrides.get("dev_server_port") or defaults.get("dev_server_port") or 3000
        try:
            port = int(port_raw)
        except (TypeError, ValueError):
            port = 3000
        from planning import dev_server as _ds
        result = _ds.start(
            project_id, proj["folder_path"],
            command=cmd or None, port=port,
        )
        if not result.get("running"):
            raise HTTPException(400, result.get("error", "failed to start"))
        return result

    @router.delete("/projects/{project_id}/dev-server")
    async def stop_dev_server(project_id: int) -> dict[str, Any]:
        from planning import dev_server as _ds
        return {"stopped": _ds.stop(project_id)}

    # ── SSE streams ────────────────────────────────────────────────────

    async def _sse_iter(gen):
        """Convert an async-iter of dicts to text/event-stream chunks."""
        try:
            async for ev in gen:
                yield f"data: {json.dumps(ev)}\n\n"
        except asyncio.CancelledError:
            return

    @router.get("/sessions/{session_id}/events")
    async def session_events(session_id: int) -> StreamingResponse:
        _, orch = _lazy()
        return StreamingResponse(
            _sse_iter(orch.subscribe_session(session_id)),
            media_type="text/event-stream",
        )

    @router.get("/events")
    async def all_events() -> StreamingResponse:
        _, orch = _lazy()
        return StreamingResponse(
            _sse_iter(orch.subscribe_global()),
            media_type="text/event-stream",
        )

    return router
