"""Cognos HTTP API — FastAPI app exposing chat, sessions, tools, models."""

from api.server import create_app

__all__ = ["create_app"]
