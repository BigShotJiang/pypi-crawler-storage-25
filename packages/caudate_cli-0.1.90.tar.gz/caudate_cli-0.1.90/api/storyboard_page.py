"""Storyboard — single-page HTML app.

Served at `GET /storyboard`. Talks to `POST /storyboard/generate` over
Server-Sent Events for live progress as each panel renders.

Self-contained: no build step, no npm, no React. All deps come from
CDN at runtime (JSZip for ZIP export). IndexedDB persists run history
client-side.

This file produces the HTML as a single string. Loaded once on app
boot and cached.
"""

from __future__ import annotations


def render_storyboard_page() -> str:
    return _PAGE


_PAGE = r"""<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Storyboard — Cognos</title>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
  <style>
    :root {
      --bg:           #0f1115;
      --bg-elev:      #181b21;
      --bg-pre:       #0c0e12;
      --bg-hover:     #232730;
      --text:         #e6e7eb;
      --text-dim:     #8a8e98;
      --border:       #262a32;
      --accent:       #7aa2f7;
      --accent-strong:#5b87ff;
      --green:        #6cba6c;
      --red:          #e57373;
      --yellow:       #d8b65a;
    }
    [data-theme="light"] {
      --bg:        #f5f6f8;
      --bg-elev:   #ffffff;
      --bg-pre:    #ebedf1;
      --bg-hover:  #e6e9ee;
      --text:      #1c1f24;
      --text-dim:  #5b6068;
      --border:    #d0d5dc;
      --accent:    #2c63d6;
      --accent-strong: #1a4cba;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body { height: 100%; }
    body {
      background: var(--bg);
      color: var(--text);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      font-size: 14px;
      line-height: 1.5;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }
    header {
      display: flex; align-items: center; gap: 16px;
      padding: 12px 20px;
      background: var(--bg-elev);
      border-bottom: 1px solid var(--border);
    }
    header h1 { font-size: 16px; font-weight: 600; }
    header .meta { color: var(--text-dim); font-size: 12px; }
    header .controls { margin-left: auto; display: flex; gap: 8px; }
    main {
      flex: 1; display: flex; gap: 16px;
      padding: 16px 20px; max-width: 1600px;
      width: 100%; margin: 0 auto;
    }
    .panel {
      background: var(--bg-elev);
      border: 1px solid var(--border);
      border-radius: 6px;
      padding: 16px;
    }
    .left { flex: 0 0 380px; display: flex; flex-direction: column; gap: 12px; }
    .right { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 12px; }

    label { display: block; color: var(--text-dim); font-size: 12px; margin-bottom: 4px; }
    textarea, input[type="text"], input[type="number"], select {
      width: 100%;
      background: var(--bg);
      color: var(--text);
      border: 1px solid var(--border);
      border-radius: 4px;
      padding: 8px 10px;
      font-family: inherit; font-size: 13px;
      resize: vertical;
    }
    textarea { min-height: 180px; line-height: 1.5; }
    input:focus, textarea:focus, select:focus {
      outline: none; border-color: var(--accent);
    }
    .row { display: flex; gap: 8px; }
    .row > * { flex: 1; }
    .form-grid {
      display: grid; grid-template-columns: 1fr 1fr; gap: 8px;
    }
    .form-grid > .full { grid-column: 1 / -1; }

    button, .btn {
      background: var(--accent);
      color: white;
      border: 1px solid var(--accent-strong);
      padding: 8px 16px;
      font-size: 13px; font-weight: 500;
      border-radius: 4px; cursor: pointer;
      font-family: inherit;
    }
    button:hover { background: var(--accent-strong); }
    button:disabled {
      background: var(--bg-pre); color: var(--text-dim);
      border-color: var(--border); cursor: not-allowed;
    }
    button.secondary {
      background: var(--bg);
      color: var(--text);
      border: 1px solid var(--border);
    }
    button.secondary:hover { background: var(--bg-hover); }

    .progress-strip {
      padding: 8px 12px;
      background: var(--bg-pre);
      border-radius: 4px;
      font-size: 12px; color: var(--text-dim);
      font-family: ui-monospace, "SF Mono", Consolas, monospace;
      max-height: 140px; overflow-y: auto;
    }
    .progress-strip .ev { padding: 2px 0; }
    .progress-strip .ev.error { color: var(--red); }
    .progress-strip .ev.done { color: var(--green); }
    .progress-strip .ev.breakdown { color: var(--accent); }
    .progress-strip .ev.panel { color: var(--text); }

    .grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
      gap: 12px;
    }
    .card {
      background: var(--bg-elev);
      border: 1px solid var(--border);
      border-radius: 6px;
      overflow: hidden;
      display: flex; flex-direction: column;
      transition: border-color 0.15s;
    }
    .card:hover { border-color: var(--accent); }
    .card .img-wrap {
      aspect-ratio: 1 / 1;
      background: var(--bg-pre);
      display: flex; align-items: center; justify-content: center;
      cursor: pointer; overflow: hidden;
    }
    .card .img-wrap img {
      width: 100%; height: 100%; object-fit: cover;
    }
    .card .img-wrap.placeholder {
      color: var(--text-dim); font-size: 11px;
    }
    .card .body {
      padding: 10px 12px; font-size: 12px;
    }
    .card .body .panel-num {
      color: var(--accent); font-weight: 600; font-size: 11px;
      text-transform: uppercase; letter-spacing: 0.5px;
    }
    .card .body .scene {
      margin-top: 4px; line-height: 1.4;
      display: -webkit-box; -webkit-line-clamp: 3;
      -webkit-box-orient: vertical; overflow: hidden;
    }

    .modal-bg {
      position: fixed; inset: 0;
      background: rgba(0,0,0,0.85);
      display: none; z-index: 100;
      padding: 24px;
      align-items: center; justify-content: center;
      flex-direction: column; gap: 16px;
    }
    .modal-bg.show { display: flex; }
    .modal-bg img { max-width: 95vw; max-height: 80vh; border-radius: 4px; }
    .modal-bg .modal-caption {
      max-width: 800px; text-align: center;
      color: white; font-size: 13px; line-height: 1.5;
    }
    .modal-bg .close {
      position: absolute; top: 16px; right: 20px;
      background: transparent; border: none;
      color: white; font-size: 24px; cursor: pointer;
    }

    .history h3 { font-size: 12px; color: var(--text-dim); margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.5px; }
    .history-list { display: flex; flex-direction: column; gap: 4px; }
    .history-item {
      padding: 6px 10px; background: var(--bg-pre); border-radius: 4px;
      cursor: pointer; font-size: 12px;
      display: flex; justify-content: space-between;
      align-items: center; gap: 8px;
    }
    .history-item:hover { background: var(--bg-hover); }
    .history-item .meta { color: var(--text-dim); font-size: 10px; }
    .history-item .delete {
      background: transparent; border: none;
      color: var(--text-dim); cursor: pointer;
      padding: 2px 4px; font-size: 14px;
    }
    .history-item .delete:hover { color: var(--red); }
    .empty-msg { color: var(--text-dim); font-size: 12px; font-style: italic; padding: 8px 0; }

    .characters {
      background: var(--bg-pre);
      border: 1px solid var(--border);
      border-radius: 4px; padding: 10px 12px;
      font-size: 12px;
    }
    .characters .label { color: var(--accent); font-weight: 600; margin-bottom: 4px; }
    .characters .char { margin: 4px 0; }
    .characters .char .name { font-weight: 600; color: var(--text); }
    .characters .char .desc { color: var(--text-dim); }

    @media (max-width: 800px) {
      main { flex-direction: column; }
      .left { flex: 1 1 auto; }
    }
  </style>
</head>
<body>
<header>
  <h1>Storyboard — Cognos</h1>
  <span class="meta">FLUX-schnell + FLUX.1-Kontext-dev</span>
  <div class="controls">
    <button class="secondary" id="theme-toggle" title="Toggle theme">🌓</button>
    <a class="btn secondary" href="/healthz" target="_blank">Server</a>
  </div>
</header>

<main>
  <aside class="left">
    <div class="panel">
      <label for="script">Script</label>
      <textarea id="script" placeholder="Paste a story, scene description, or short script. Name your characters; describe their look once and reuse the names. Example: 'A small ginger cat named Rust, with a white chest and bright green eyes, wakes in a cozy attic, climbs out a moonlit window, leaps across rooftops chasing fireflies, then sleeps on a mossy chimney as the sun rises.'"></textarea>

      <div class="form-grid" style="margin-top: 12px;">
        <div>
          <label for="panels">Panels (1–12)</label>
          <input type="number" id="panels" min="1" max="12" value="6">
        </div>
        <div>
          <label for="aspect">Aspect</label>
          <select id="aspect">
            <option value="1024x1024">1:1 (square)</option>
            <option value="1280x720">16:9</option>
            <option value="768x1024">3:4</option>
          </select>
        </div>
        <div class="full">
          <label for="style">Style hint</label>
          <input type="text" id="style" value="warm storybook illustration, soft lighting" placeholder="e.g. comic book panels, watercolor, anime, noir film stills">
        </div>
        <div>
          <label for="seed">Seed (optional)</label>
          <input type="number" id="seed" placeholder="random">
        </div>
        <div>
          <label>&nbsp;</label>
          <button id="generate">Generate</button>
        </div>
      </div>
      <div id="progress" class="progress-strip" style="margin-top: 12px; display: none;"></div>
    </div>

    <div class="panel history">
      <h3>History</h3>
      <div id="history-list" class="history-list"></div>
    </div>
  </aside>

  <section class="right">
    <div id="characters-card" class="characters" style="display: none;">
      <div class="label">Cast</div>
      <div id="characters-body"></div>
      <div style="margin-top: 8px; color: var(--text-dim); font-size: 11px;">
        Style: <span id="art-style-text"></span>
      </div>
    </div>

    <div id="grid" class="grid"></div>

    <div id="actions" class="panel" style="display: none;">
      <div class="row">
        <button id="download-zip" class="secondary">Download ZIP</button>
        <button id="copy-links" class="secondary">Copy markdown gallery</button>
        <button id="open-in-chat" class="secondary">Open in chat</button>
      </div>
    </div>
  </section>
</main>

<div class="modal-bg" id="modal" tabindex="-1">
  <button class="close" id="modal-close">×</button>
  <img id="modal-img" src="" alt="">
  <div class="modal-caption" id="modal-caption"></div>
</div>

<script>
// -------------------------------------------------------------------
// Theme
// -------------------------------------------------------------------
const themeBtn = document.getElementById('theme-toggle');
function applyTheme() {
  const t = localStorage.getItem('cognos-storyboard-theme') || 'dark';
  document.documentElement.setAttribute('data-theme', t);
}
applyTheme();
themeBtn.addEventListener('click', () => {
  const cur = document.documentElement.getAttribute('data-theme');
  const next = cur === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  localStorage.setItem('cognos-storyboard-theme', next);
});

// -------------------------------------------------------------------
// IndexedDB history
// -------------------------------------------------------------------
const DB_NAME = 'cognos-storyboard';
const STORE = 'runs';
const dbReady = new Promise((resolve, reject) => {
  const req = indexedDB.open(DB_NAME, 1);
  req.onupgradeneeded = (ev) => {
    const db = ev.target.result;
    if (!db.objectStoreNames.contains(STORE)) {
      const os = db.createObjectStore(STORE, { keyPath: 'id', autoIncrement: true });
      os.createIndex('created_at', 'created_at');
    }
  };
  req.onsuccess = () => resolve(req.result);
  req.onerror = () => reject(req.error);
});
async function dbAdd(rec) {
  const db = await dbReady;
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    const r = tx.objectStore(STORE).add(rec);
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
}
async function dbAll() {
  const db = await dbReady;
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readonly');
    const r = tx.objectStore(STORE).getAll();
    r.onsuccess = () => resolve((r.result || []).sort((a, b) => b.created_at - a.created_at));
    r.onerror = () => reject(r.error);
  });
}
async function dbDelete(id) {
  const db = await dbReady;
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    const r = tx.objectStore(STORE).delete(id);
    r.onsuccess = () => resolve();
    r.onerror = () => reject(r.error);
  });
}

// -------------------------------------------------------------------
// State + DOM refs
// -------------------------------------------------------------------
const $ = (id) => document.getElementById(id);
const grid = $('grid');
const progress = $('progress');
const charactersCard = $('characters-card');
const charactersBody = $('characters-body');
const artStyleText = $('art-style-text');
const actions = $('actions');
const historyList = $('history-list');

let currentRun = null;       // { plan, panels: [{file_id, scene_action, ...}] }
let isGenerating = false;

function logProgress(msg, kind) {
  const ev = document.createElement('div');
  ev.className = 'ev ' + (kind || '');
  ev.textContent = `[${new Date().toLocaleTimeString()}] ${msg}`;
  progress.appendChild(ev);
  progress.scrollTop = progress.scrollHeight;
}

function renderPlaceholders(n) {
  grid.innerHTML = '';
  for (let i = 0; i < n; i++) {
    const card = document.createElement('div');
    card.className = 'card';
    card.id = `card-${i + 1}`;
    card.innerHTML = `
      <div class="img-wrap placeholder">Panel ${i + 1} — pending</div>
      <div class="body">
        <div class="panel-num">Panel ${i + 1}</div>
        <div class="scene"></div>
      </div>
    `;
    grid.appendChild(card);
  }
}
function fillCard(i, panel) {
  const card = $(`card-${i}`);
  if (!card) return;
  const wrap = card.querySelector('.img-wrap');
  const url = `/files/${panel.file_id}/content`;
  wrap.classList.remove('placeholder');
  wrap.innerHTML = `<img src="${url}" alt="Panel ${i}">`;
  wrap.addEventListener('click', () => openModal(url, panel.scene_action || ''));
  card.querySelector('.scene').textContent = panel.scene_action || panel.panel_text || '';
}
function fillBreakdown(plan) {
  charactersCard.style.display = 'block';
  artStyleText.textContent = plan.art_style || '';
  charactersBody.innerHTML = '';
  (plan.characters || []).forEach((c) => {
    const row = document.createElement('div');
    row.className = 'char';
    row.innerHTML = `<span class="name">${escapeHtml(c.name)}:</span> <span class="desc">${escapeHtml(c.visual_description)}</span>`;
    charactersBody.appendChild(row);
  });
  if (!(plan.characters || []).length) {
    charactersBody.innerHTML = '<div class="empty-msg">No named cast — story used a generic narrator.</div>';
  }
  // Update placeholder scene text to match the plan's panels so users
  // see where each panel is going before pixels arrive.
  (plan.panels || []).forEach((p, idx) => {
    const card = $(`card-${idx + 1}`);
    if (card) card.querySelector('.scene').textContent = p.scene_action || '';
  });
}
function escapeHtml(s) {
  return String(s || '').replace(/[&<>"']/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// -------------------------------------------------------------------
// Modal
// -------------------------------------------------------------------
const modal = $('modal');
$('modal-close').addEventListener('click', () => modal.classList.remove('show'));
modal.addEventListener('click', (e) => { if (e.target === modal) modal.classList.remove('show'); });
window.addEventListener('keydown', (e) => { if (e.key === 'Escape') modal.classList.remove('show'); });
function openModal(url, caption) {
  $('modal-img').src = url;
  $('modal-caption').textContent = caption || '';
  modal.classList.add('show');
}

// -------------------------------------------------------------------
// Generate (SSE)
// -------------------------------------------------------------------
$('generate').addEventListener('click', async () => {
  if (isGenerating) return;
  const story = $('script').value.trim();
  if (!story) return alert('Paste a story or script first.');

  const panels = parseInt($('panels').value, 10) || 6;
  const size = $('aspect').value;
  const style = $('style').value.trim();
  const seedRaw = $('seed').value.trim();
  const seed = seedRaw ? parseInt(seedRaw, 10) : null;

  isGenerating = true;
  $('generate').disabled = true;
  $('generate').textContent = 'Generating…';
  actions.style.display = 'none';
  charactersCard.style.display = 'none';
  progress.style.display = 'block';
  progress.innerHTML = '';
  renderPlaceholders(panels);
  currentRun = { plan: null, panels: [] };

  logProgress(`Starting ${panels}-panel storyboard…`, 'breakdown');
  let resp;
  try {
    resp = await fetch('/storyboard/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ story, panels, style, size, seed }),
    });
  } catch (e) {
    logProgress('network error: ' + e.message, 'error');
    finishGeneration(false);
    return;
  }
  if (!resp.ok || !resp.body) {
    logProgress(`HTTP ${resp.status}`, 'error');
    finishGeneration(false);
    return;
  }
  const reader = resp.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  let aborted = false;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    let idx;
    while ((idx = buffer.indexOf('\n\n')) >= 0) {
      const chunk = buffer.slice(0, idx);
      buffer = buffer.slice(idx + 2);
      const lines = chunk.split('\n');
      let dataLine = '';
      for (const ln of lines) {
        if (ln.startsWith('data:')) dataLine += ln.slice(5).trim();
      }
      if (!dataLine) continue;
      let ev;
      try { ev = JSON.parse(dataLine); } catch { continue; }
      handleEvent(ev);
      if (ev.type === 'error') aborted = true;
    }
  }
  finishGeneration(!aborted && currentRun.panels.length > 0);
});

function handleEvent(ev) {
  if (ev.type === 'breakdown') {
    currentRun.plan = ev.plan;
    fillBreakdown(ev.plan);
    logProgress(`Got breakdown: ${(ev.plan.characters || []).length} character(s), ${(ev.plan.panels || []).length} panel(s)`, 'breakdown');
  } else if (ev.type === 'panel') {
    currentRun.panels.push(ev);
    fillCard(ev.index, ev);
    logProgress(`Panel ${ev.index} done — ${ev.scene_action.slice(0, 60)}`, 'panel');
  } else if (ev.type === 'done') {
    logProgress(`Done. ${ev.panel_count} panel(s) saved.`, 'done');
  } else if (ev.type === 'error') {
    logProgress('error: ' + ev.message, 'error');
  }
}

async function finishGeneration(success) {
  isGenerating = false;
  $('generate').disabled = false;
  $('generate').textContent = 'Generate';
  if (success && currentRun && currentRun.panels.length > 0) {
    actions.style.display = 'block';
    // Persist
    try {
      await dbAdd({
        created_at: Date.now(),
        story: $('script').value.trim(),
        plan: currentRun.plan,
        panels: currentRun.panels,
        size: $('aspect').value,
        style_hint: $('style').value.trim(),
        panel_count: $('panels').value,
      });
      refreshHistory();
    } catch (e) {
      console.warn('history save failed', e);
    }
  }
}

// -------------------------------------------------------------------
// Actions: ZIP, copy markdown, open in chat
// -------------------------------------------------------------------
$('download-zip').addEventListener('click', async () => {
  if (!currentRun || !currentRun.panels.length) return;
  const zip = new JSZip();
  const folder = zip.folder('storyboard');
  for (const p of currentRun.panels) {
    const blob = await fetch(`/files/${p.file_id}/content`).then(r => r.blob());
    folder.file(`panel_${String(p.index).padStart(2, '0')}.png`, blob);
  }
  if (currentRun.plan) {
    folder.file('plan.json', JSON.stringify({
      art_style: currentRun.plan.art_style,
      characters: currentRun.plan.characters,
      panels: currentRun.panels,
    }, null, 2));
  }
  const out = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(out);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'storyboard.zip';
  a.click();
  URL.revokeObjectURL(url);
});

$('copy-links').addEventListener('click', async () => {
  if (!currentRun || !currentRun.panels.length) return;
  const lines = [];
  if (currentRun.plan) {
    lines.push(`**Style:** ${currentRun.plan.art_style}`);
    lines.push('');
  }
  currentRun.panels.forEach((p) => {
    const url = `${window.location.origin}/files/${p.file_id}/content`;
    lines.push(`**Panel ${p.index}.** ${p.scene_action || ''}`);
    lines.push(`![${escapeHtml(p.scene_action || '')}](${url})`);
    lines.push('');
  });
  await navigator.clipboard.writeText(lines.join('\n'));
  alert('Copied markdown gallery to clipboard.');
});

$('open-in-chat').addEventListener('click', () => {
  // Open WebUI in a new tab — assumes default port 8080.
  window.open('http://127.0.0.1:8080', '_blank');
});

// -------------------------------------------------------------------
// History
// -------------------------------------------------------------------
async function refreshHistory() {
  const runs = await dbAll();
  historyList.innerHTML = '';
  if (!runs.length) {
    historyList.innerHTML = '<div class="empty-msg">No past runs yet.</div>';
    return;
  }
  runs.slice(0, 30).forEach((r) => {
    const item = document.createElement('div');
    item.className = 'history-item';
    const dt = new Date(r.created_at).toLocaleString();
    const story = (r.story || '').slice(0, 60) + (r.story && r.story.length > 60 ? '…' : '');
    item.innerHTML = `
      <div style="flex:1; min-width:0;">
        <div style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${escapeHtml(story)}</div>
        <div class="meta">${r.panel_count} panel(s) · ${dt}</div>
      </div>
      <button class="delete" data-id="${r.id}" title="Delete">×</button>
    `;
    item.addEventListener('click', (e) => {
      if (e.target.classList.contains('delete')) return;
      restoreRun(r);
    });
    item.querySelector('.delete').addEventListener('click', async (e) => {
      e.stopPropagation();
      await dbDelete(r.id);
      refreshHistory();
    });
    historyList.appendChild(item);
  });
}
function restoreRun(r) {
  currentRun = { plan: r.plan, panels: r.panels };
  $('script').value = r.story || '';
  $('panels').value = r.panel_count || 6;
  if (r.size) $('aspect').value = r.size;
  if (r.style_hint) $('style').value = r.style_hint;

  if (r.plan) fillBreakdown(r.plan);
  renderPlaceholders((r.panels || []).length);
  (r.panels || []).forEach((p) => fillCard(p.index, p));
  actions.style.display = 'block';
  progress.style.display = 'none';
  window.scrollTo(0, 0);
}
refreshHistory();
</script>
</body>
</html>
"""
