"""Reflector — evaluates outcomes and extracts lessons."""

from __future__ import annotations

import logging
from typing import Any

from pydantic import BaseModel, Field

from config import SUCCESS_THRESHOLD
from core.schemas import (
    Episode, Goal, Reflection, Task, ToolResultStatus,
)
from llm.provider import LLMProvider

logger = logging.getLogger(__name__)


class ReflectionOutput(BaseModel):
    """LLM-emitted reflection structure."""
    score: float = Field(ge=0.0, le=1.0)
    what_happened: str = ""
    what_worked: str = ""
    what_failed: str = ""
    lesson: str = ""
    should_replan: bool = False
    replan_reason: str = ""

REFLECT_PROMPT = """You are the reflection module of a cognitive architecture.
Evaluate what just happened and extract lessons.

Goal: {goal}
Task attempted: {task}
Action taken: {action}
Tool used: {tool}
Result status: {status}
Result output: {output}
Error (if any): {error}

Respond with JSON:
{{
  "score": 0.0 to 1.0 (how successful was this action),
  "what_happened": "brief description",
  "what_worked": "what went well",
  "what_failed": "what went wrong",
  "lesson": "key takeaway for future actions",
  "should_replan": true/false,
  "replan_reason": "why replanning is needed (if applicable)"
}}"""


class Reflector:
    """Evaluates action outcomes and produces structured reflections."""

    def __init__(self, llm: LLMProvider):
        self.llm = llm

    async def reflect(
        self,
        episode: Episode,
        goal: Goal,
        task: Task,
    ) -> Reflection:
        """Reflect on an episode and produce a structured evaluation."""
        result = episode.result

        # Fast path: clear success → skip LLM. Originally only no-tool
        # reasoning steps short-circuited; now any clean tool success
        # does too, saving an LLM round-trip per successful step. The
        # meta-learner's value still comes mainly from failure-reflections
        # and the periodic strategy pass, so dropping prose reflections
        # on routine successes costs nothing observable.
        if result and result.status == ToolResultStatus.SUCCESS:
            tool = task.tool_name or "Reasoning"
            return Reflection(
                episode_id=episode.id,
                goal_id=goal.id,
                score=0.85,
                what_happened=f"{tool} step completed: {task.description}",
                what_worked=f"{tool} executed without error",
                lesson="",
            )

        # Use LLM for nuanced reflection
        prompt = REFLECT_PROMPT.format(
            goal=goal.description,
            task=task.description,
            action=episode.action,
            tool=episode.tool_name or "none",
            status=result.status.value if result else "unknown",
            output=str(result.output)[:500] if result and result.output else "none",
            error=result.error or "none" if result else "unknown",
        )

        try:
            data = await self.llm.structured_output(
                prompt=prompt, response_model=ReflectionOutput,
                caller="reflection",
            )
            return Reflection(
                episode_id=episode.id,
                goal_id=goal.id,
                score=data.score,
                what_happened=data.what_happened,
                what_worked=data.what_worked,
                what_failed=data.what_failed,
                lesson=data.lesson,
                should_replan=data.should_replan,
                replan_reason=data.replan_reason,
            )
        except Exception as e:
            logger.error(f"Reflection failed: {e}")
            # Fallback: score based on result status
            score = 0.8 if result and result.status == ToolResultStatus.SUCCESS else 0.2
            return Reflection(
                episode_id=episode.id,
                goal_id=goal.id,
                score=score,
                what_happened=f"Action {'succeeded' if score > 0.5 else 'failed'}",
                lesson=f"Reflection generation failed: {e}",
                should_replan=score < SUCCESS_THRESHOLD,
                replan_reason="Action failed" if score < SUCCESS_THRESHOLD else "",
            )

    def needs_replan(self, reflection: Reflection) -> bool:
        """Determine if a reflection warrants re-planning."""
        return reflection.should_replan or reflection.score < SUCCESS_THRESHOLD
