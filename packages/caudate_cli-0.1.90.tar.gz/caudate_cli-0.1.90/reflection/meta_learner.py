"""Meta-Learner — adapts strategies based on reflection history (self-improvement)."""

from __future__ import annotations

import logging
from typing import Any

from pydantic import BaseModel, Field

from config import STRATEGY_UPDATE_INTERVAL
from core.schemas import Reflection, Strategy
from llm.provider import LLMProvider
from memory.procedural import ProceduralMemory

logger = logging.getLogger(__name__)


class NewStrategyOutput(BaseModel):
    name: str
    description: str
    conditions: str
    actions: str
    confidence: float = Field(default=0.5, ge=0.0, le=1.0)


class StrategyUpdateOutput(BaseModel):
    id: str
    confidence_delta: float = Field(default=0.0, ge=-1.0, le=1.0)
    reason: str = ""


class StrategyOutput(BaseModel):
    """LLM-emitted strategy extraction result."""
    new_strategies: list[NewStrategyOutput] = Field(default_factory=list)
    strategy_updates: list[StrategyUpdateOutput] = Field(default_factory=list)

STRATEGY_PROMPT = """You are the meta-learning module of a cognitive architecture.
Analyze recent performance and extract or update strategies.

Recent reflections:
{reflections}

Existing strategies:
{strategies}

Based on the patterns in these reflections, suggest new strategies or updates.
Each strategy should capture a reusable heuristic.

Respond with JSON:
{{
  "new_strategies": [
    {{
      "name": "short name",
      "description": "what this strategy does",
      "conditions": "when to apply it",
      "actions": "what to do",
      "confidence": 0.0 to 1.0
    }}
  ],
  "strategy_updates": [
    {{
      "id": "existing strategy id",
      "confidence_delta": -0.1 to 0.1,
      "reason": "why update"
    }}
  ]
}}"""


class MetaLearner:
    """Learns from reflection history to adapt agent strategies over time."""

    def __init__(self, llm: LLMProvider, procedural_memory: ProceduralMemory):
        self.llm = llm
        self.procedural = procedural_memory
        self._reflection_buffer: list[Reflection] = []

    def add_reflection(self, reflection: Reflection) -> None:
        """Buffer a reflection for periodic strategy updates."""
        self._reflection_buffer.append(reflection)

    async def maybe_update_strategies(self) -> list[Strategy]:
        """Update strategies if enough reflections have accumulated."""
        if len(self._reflection_buffer) < STRATEGY_UPDATE_INTERVAL:
            return []

        new_strategies = await self._extract_strategies()
        self._reflection_buffer.clear()
        return new_strategies

    async def force_update(self) -> list[Strategy]:
        """Force a strategy update regardless of buffer size."""
        if not self._reflection_buffer:
            return []
        new_strategies = await self._extract_strategies()
        self._reflection_buffer.clear()
        return new_strategies

    async def _extract_strategies(self) -> list[Strategy]:
        """Use LLM to extract strategies from reflection buffer."""
        reflections_text = "\n".join(
            f"- Score: {r.score}, Lesson: {r.lesson}, Worked: {r.what_worked}, Failed: {r.what_failed}"
            for r in self._reflection_buffer
        )

        existing = self.procedural.get_strategies()
        strategies_text = "\n".join(
            f"- [{s.id}] {s.name} (confidence: {s.confidence:.2f}): {s.description}"
            for s in existing
        ) or "No existing strategies."

        prompt = STRATEGY_PROMPT.format(
            reflections=reflections_text,
            strategies=strategies_text,
        )

        try:
            data = await self.llm.structured_output(
                prompt=prompt, response_model=StrategyOutput,
                caller="meta",
            )

            new_strategies = []
            for raw in data.new_strategies:
                strategy = Strategy(
                    name=raw.name,
                    description=raw.description,
                    conditions=raw.conditions,
                    actions=raw.actions,
                    confidence=raw.confidence,
                )
                self.procedural.store_strategy(strategy)
                new_strategies.append(strategy)
                logger.info(f"Learned new strategy: {strategy.name}")

            # Apply updates to existing strategies
            for update in data.strategy_updates:
                for s in existing:
                    if s.id == update.id:
                        s.confidence = max(0.0, min(1.0, s.confidence + update.confidence_delta))
                        self.procedural.store_strategy(s)
                        logger.info(f"Updated strategy {s.name}: confidence {s.confidence:.2f}")

            return new_strategies

        except Exception as e:
            logger.error(f"Meta-learning failed: {e}")
            return []

    def get_applicable_strategies(self, context: str) -> list[Strategy]:
        """Get strategies that might apply to the current context.

        For now, returns all strategies above minimum confidence.
        Future: use embedding similarity on conditions.
        """
        return self.procedural.get_strategies(min_confidence=0.3)
