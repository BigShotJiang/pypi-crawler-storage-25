"""
缓存模块（跨子模块复用）

设计目标：
- 本地磁盘缓存（文件实体为主）
- 每个模块/region 独立缓存目录 + 独立 SQLite 索引（跨进程一致性）
- 保存 metadata / query_metadata / 规范化查询元数据目录
"""

from .cache_region import CacheRegion

__all__ = ["CacheRegion"]
