from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path  # noqa: TC003
import sqlite3
import time
from typing import Any, Optional

from soulshell_base.core import get_logger

from .exceptions import CacheCorruptionError, CacheIOError

logger = get_logger(__name__)


@dataclass(frozen=True)
class CacheEntryRow:
    """cache_entries 表的一行记录"""

    id: int
    module: str
    region: str
    raw_key: str
    norm_key: str
    file_key: str
    blob_relpath: str
    metadata_json: str
    query_metadata_json: str
    query_meta_norm_relpath: Optional[str]
    created_at: float  # 使用浮点秒级时间戳
    updated_at: float
    expires_at: Optional[float]
    etag: Optional[str]


def _connect(db_path: Path) -> sqlite3.Connection:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(
        str(db_path), timeout=30.0, isolation_level=None
    )  # autocommit mode
    conn.row_factory = sqlite3.Row

    # 并发与可靠性：WAL + busy_timeout，适用于多进程读多写少场景
    try:
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA synchronous=NORMAL;")
        conn.execute("PRAGMA foreign_keys=ON;")
        conn.execute("PRAGMA busy_timeout=30000;")
    except sqlite3.DatabaseError as e:
        raise CacheCorruptionError(f"SQLite PRAGMA 配置失败: {e}") from e

    return conn


def _init_schema(conn: sqlite3.Connection) -> None:
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS cache_entries (
          id INTEGER PRIMARY KEY,
          module TEXT NOT NULL,
          region TEXT NOT NULL,
          raw_key TEXT NOT NULL,
          norm_key TEXT NOT NULL,
          file_key TEXT NOT NULL UNIQUE,
          blob_relpath TEXT NOT NULL,
          metadata_json TEXT NOT NULL,
          query_metadata_json TEXT NOT NULL,
          query_meta_norm_relpath TEXT,
          created_at REAL NOT NULL,
          updated_at REAL NOT NULL,
          expires_at REAL,
          etag TEXT
        );
        """
    )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_cache_entries_module_region
        ON cache_entries(module, region);
        """
    )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_cache_entries_expires_at
        ON cache_entries(expires_at);
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS cache_query_kv (
          entry_id INTEGER NOT NULL REFERENCES cache_entries(id) ON DELETE CASCADE,
          k TEXT NOT NULL,
          v TEXT NOT NULL,
          PRIMARY KEY(entry_id, k)
        );
        """
    )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_cache_query_kv_kv
        ON cache_query_kv(k, v);
        """
    )


class SQLiteIndex:
    def __init__(self, db_path: Path, *, module: str, region: str):
        self.db_path = db_path
        self.module = module
        self.region = region

        try:
            with _connect(self.db_path) as conn:
                _init_schema(conn)
        except sqlite3.DatabaseError as e:
            raise CacheCorruptionError(f"初始化 SQLite 索引失败: {e}") from e

    def upsert_entry(
        self,
        *,
        raw_key: str,
        norm_key: str,
        file_key: str,
        blob_relpath: str,
        metadata: dict[str, Any],
        query_metadata: dict[str, Any],
        query_meta_norm_relpath: Optional[str],
        expires_at: Optional[float],
        etag: Optional[str],
    ) -> int:
        # 使用浮点秒级时间戳，避免整秒截断导致 TTL 边界问题
        now = float(time.time())
        metadata_json = json.dumps(metadata, ensure_ascii=False, separators=(",", ":"))
        query_metadata_json = json.dumps(
            query_metadata, ensure_ascii=False, separators=(",", ":")
        )

        try:
            with _connect(self.db_path) as conn:
                conn.execute("BEGIN IMMEDIATE;")
                try:
                    conn.execute(
                        """
                        INSERT INTO cache_entries (
                          module, region, raw_key, norm_key, file_key,
                          blob_relpath, metadata_json, query_metadata_json,
                          query_meta_norm_relpath, created_at, updated_at, expires_at, etag
                        ) VALUES (
                          ?,?,?,?,?,?,?,?,?,?,?,?,?
                        )
                        ON CONFLICT(file_key) DO UPDATE SET
                          raw_key=excluded.raw_key,
                          norm_key=excluded.norm_key,
                          blob_relpath=excluded.blob_relpath,
                          metadata_json=excluded.metadata_json,
                          query_metadata_json=excluded.query_metadata_json,
                          query_meta_norm_relpath=excluded.query_meta_norm_relpath,
                          updated_at=excluded.updated_at,
                          expires_at=excluded.expires_at,
                          etag=excluded.etag
                        ;
                        """,
                        (
                            self.module,
                            self.region,
                            raw_key,
                            norm_key,
                            file_key,
                            blob_relpath,
                            metadata_json,
                            query_metadata_json,
                            query_meta_norm_relpath,
                            now,
                            now,
                            expires_at,
                            etag,
                        ),
                    )

                    row = conn.execute(
                        "SELECT id FROM cache_entries WHERE file_key=?;",
                        (file_key,),
                    ).fetchone()
                    if row is None:
                        raise CacheIOError("写入后未找到 cache_entries 记录")
                    entry_id = int(row["id"])

                    # 维护 query_kv（以 query_metadata 为准）
                    conn.execute(
                        "DELETE FROM cache_query_kv WHERE entry_id=?;", (entry_id,)
                    )
                    kv_rows: list[tuple[int, str, str]] = []
                    for k, v in query_metadata.items():
                        if v is None:
                            continue
                        kv_rows.append((entry_id, str(k), str(v)))
                    if kv_rows:
                        conn.executemany(
                            "INSERT INTO cache_query_kv(entry_id, k, v) VALUES (?,?,?);",
                            kv_rows,
                        )

                    conn.execute("COMMIT;")
                    return entry_id
                except Exception:
                    conn.execute("ROLLBACK;")
                    raise
        except sqlite3.DatabaseError as e:
            raise CacheIOError(f"SQLite upsert 失败: {e}") from e

    def get_by_norm_key(self, norm_key: str) -> Optional[CacheEntryRow]:
        try:
            with _connect(self.db_path) as conn:
                row = conn.execute(
                    """
                    SELECT * FROM cache_entries
                    WHERE module=? AND region=? AND norm_key=?;
                    """,
                    (self.module, self.region, norm_key),
                ).fetchone()
                if row is None:
                    return None
                return CacheEntryRow(**dict(row))
        except sqlite3.DatabaseError as e:
            raise CacheIOError(f"SQLite 查询失败: {e}") from e

    def get_by_file_key(self, file_key: str) -> Optional[CacheEntryRow]:
        try:
            with _connect(self.db_path) as conn:
                row = conn.execute(
                    """
                    SELECT * FROM cache_entries
                    WHERE module=? AND region=? AND file_key=?;
                    """,
                    (self.module, self.region, file_key),
                ).fetchone()
                if row is None:
                    return None
                return CacheEntryRow(**dict(row))
        except sqlite3.DatabaseError as e:
            raise CacheIOError(f"SQLite 查询失败: {e}") from e

    def delete_by_file_key(self, file_key: str) -> bool:
        try:
            with _connect(self.db_path) as conn:
                conn.execute("BEGIN IMMEDIATE;")
                try:
                    cur = conn.execute(
                        "DELETE FROM cache_entries WHERE module=? AND region=? AND file_key=?;",
                        (self.module, self.region, file_key),
                    )
                    conn.execute("COMMIT;")
                    return cur.rowcount > 0
                except Exception:
                    conn.execute("ROLLBACK;")
                    raise
        except sqlite3.DatabaseError as e:
            raise CacheIOError(f"SQLite 删除失败: {e}") from e

    def find_by_query_kv(
        self, query: dict[str, str], *, limit: int = 100
    ) -> list[CacheEntryRow]:
        """
        通过 query_metadata 的 KV 精确匹配过滤（AND 语义）。
        """

        if not query:
            return []

        # 通过 JOIN + GROUP BY 实现 AND 匹配：
        # 命中 N 个 (k,v) 的 entry 才返回。
        pairs: list[tuple[str, str]] = [
            (str(k), str(v)) for k, v in query.items() if v is not None
        ]
        if not pairs:
            return []

        placeholders = ",".join(["(?,?)"] * len(pairs))
        params: list[Any] = [self.module, self.region]
        for k, v in pairs:
            params.extend([k, v])
        params.append(len(pairs))
        params.append(limit)

        sql = f"""
        SELECT e.*
        FROM cache_entries e
        JOIN cache_query_kv q ON q.entry_id = e.id
        WHERE e.module=? AND e.region=?
          AND (q.k, q.v) IN ({placeholders})
        GROUP BY e.id
        HAVING COUNT(*) = ?
        ORDER BY e.updated_at DESC
        LIMIT ?;
        """

        try:
            with _connect(self.db_path) as conn:
                rows = conn.execute(sql, params).fetchall()
                return [CacheEntryRow(**dict(r)) for r in rows]
        except sqlite3.DatabaseError as e:
            raise CacheIOError(f"SQLite 查询失败: {e}") from e

    def purge_expired(self, *, now_ts: Optional[float] = None) -> list[CacheEntryRow]:
        """
        返回被判定为过期的条目列表（由调用方决定是否删除文件/目录），并删除索引记录。
        """

        now = float(time.time()) if now_ts is None else float(now_ts)
        try:
            with _connect(self.db_path) as conn:
                rows = conn.execute(
                    """
                    SELECT * FROM cache_entries
                    WHERE module=? AND region=?
                      AND expires_at IS NOT NULL AND expires_at <= ?;
                    """,
                    (self.module, self.region, now),
                ).fetchall()
                entries = [CacheEntryRow(**dict(r)) for r in rows]

                if not entries:
                    return []

                conn.execute("BEGIN IMMEDIATE;")
                try:
                    conn.execute(
                        """
                        DELETE FROM cache_entries
                        WHERE module=? AND region=?
                          AND expires_at IS NOT NULL AND expires_at <= ?;
                        """,
                        (self.module, self.region, now),
                    )
                    conn.execute("COMMIT;")
                except Exception:
                    conn.execute("ROLLBACK;")
                    raise

                return entries
        except sqlite3.DatabaseError as e:
            raise CacheIOError(f"SQLite 清理失败: {e}") from e
