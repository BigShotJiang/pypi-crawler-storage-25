from __future__ import annotations

import json
import os
from pathlib import Path  # noqa: TC003
from typing import Any


def atomic_write_bytes(path: Path, data: bytes) -> None:
    """
    原子写入二进制文件：先写临时文件，再 replace。
    """

    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    tmp.replace(path)


def atomic_write_text(path: Path, text: str, *, encoding: str = "utf-8") -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding=encoding) as f:
        f.write(text)
        f.flush()
        os.fsync(f.fileno())
    tmp.replace(path)


def atomic_write_json(path: Path, obj: Any, *, encoding: str = "utf-8") -> None:
    atomic_write_text(
        path,
        json.dumps(obj, ensure_ascii=False, separators=(",", ":")),
        encoding=encoding,
    )
