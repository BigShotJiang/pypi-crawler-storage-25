class CacheError(Exception):
    """缓存模块通用异常"""


class CacheConfigError(CacheError):
    """缓存配置错误"""


class CacheCorruptionError(CacheError):
    """缓存索引/数据损坏"""


class CacheIOError(CacheError):
    """缓存读写错误"""
