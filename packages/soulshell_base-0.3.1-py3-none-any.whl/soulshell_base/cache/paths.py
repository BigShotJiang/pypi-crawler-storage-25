from __future__ import annotations

from pathlib import Path


def default_cache_root_dir() -> Path:
    """
    默认缓存根目录。

    约定与 RuntimeStateManager 的 ~/.soulshell/runtime 同一用户目录体系：
    ~/.soulshell/cache
    """

    return Path.home() / ".soulshell" / "cache"


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path
