from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
import time
from typing import Any, Optional

from soulshell_base.core import get_logger

from .atomic_io import atomic_write_bytes, atomic_write_json
from .exceptions import CacheConfigError, CacheIOError
from .index_sqlite import SQLiteIndex
from .keying import CacheKey, make_cache_key
from .paths import default_cache_root_dir, ensure_dir

logger = get_logger(__name__)


@dataclass(frozen=True)
class CacheHit:
    """
    缓存命中结果对象。

    一个 CacheHit 表示一次完整的「索引 + 文件」命中，包含：
    - raw_key / norm_key / file_key：用于调试与追踪
    - blob_path：实际文件路径（调用方可自行读取 bytes）
    - metadata：原始元数据（记录这条缓存的上下文信息）
    - query_metadata：用于检索的元数据子集（会同步存入 cache_query_kv）
    - query_meta_norm_dir：规范化查询元数据所在目录（如有）
    - created_at / updated_at / expires_at / etag：生命周期与版本信息
    """

    raw_key: str
    norm_key: str
    file_key: str
    blob_path: Path
    metadata: dict[str, Any]
    query_metadata: dict[str, Any]
    query_meta_norm_dir: Optional[Path]
    created_at: int
    updated_at: int
    expires_at: Optional[int]
    etag: Optional[str]


class CacheRegion:
    """
    一个可复用的缓存 region（模块内按用途隔离）。

    关键约束（与你的关注点对齐）：
    - 每个 module/region 独立目录、独立 index.sqlite
    - 每条缓存保存 metadata / query_metadata / 规范化查询元数据目录
    - key 由 cache 模块规范化并映射为安全文件名，同时保留 raw_key
    - SQLite 作为跨进程一致性基础（事务写索引）
    """

    def __init__(
        self,
        *,
        module: str,
        region: str,
        root_dir: Optional[str | Path] = None,
    ) -> None:
        self.module = module.strip()
        self.region = region.strip()
        if not self.module:
            raise CacheConfigError("module 不能为空")
        if not self.region:
            raise CacheConfigError("region 不能为空")

        root = Path(root_dir) if root_dir is not None else default_cache_root_dir()
        self.root_dir = root

        # 目录布局
        self.cache_dir = ensure_dir(self.root_dir / "cache")
        self.region_dir = ensure_dir(self.cache_dir / self.module / self.region)
        self.blobs_dir = ensure_dir(self.region_dir / "blobs")
        self.meta_dir = ensure_dir(self.region_dir / "meta")
        self.query_meta_norm_dir = ensure_dir(self.region_dir / "query_meta_norm")

        self.db_path = self.region_dir / "index.sqlite"
        self.index = SQLiteIndex(self.db_path, module=self.module, region=self.region)

    def _blob_path(self, file_key: str, *, suffix: str = ".bin") -> Path:
        # suffix 由调用方控制（如 .mp3/.json/.pkl），默认二进制 .bin
        if not suffix.startswith("."):
            suffix = "." + suffix
        return self.blobs_dir / f"{file_key}{suffix}"

    def _norm_dir_for_file_key(self, file_key: str) -> Path:
        return self.query_meta_norm_dir / file_key

    def set_blob(
        self,
        raw_key: Any,
        *,
        blob: bytes,
        blob_suffix: str = ".bin",
        metadata: dict[str, Any],
        query_metadata: Optional[dict[str, Any]] = None,
        normalized_query_artifacts: Optional[dict[str, Any]] = None,
        ttl_seconds: Optional[int] = None,
        etag: Optional[str] = None,
    ) -> CacheKey:
        """
        写入二进制文件缓存（强一致流程）。

        适用场景：音频文件、图片、视频片段等需要持久化到磁盘的二进制数据。
        如需缓存纯数据（配置、API 响应等），请使用 set_value() 方法。

        参数语义说明（与 README 中的设计对齐）：
        - raw_key:
            业务侧传入的原始 key，用于标识「这一条缓存对应的请求」。
            可以是字符串，也可以是任意可 JSON 序列化的结构（如 dict）。
            内部会基于 raw_key 生成 norm_key 与 file_key，并同时写入索引。
        - blob:
            实际要缓存的二进制内容（如 mp3 / wav / 中间产物等）。
        - blob_suffix:
            保存到 blobs 目录时使用的扩展名，例如 ".mp3" / ".wav" / ".bin"。
        - metadata:
            原始元数据，用于「回看 / 调试」。
            一般包含：所有关键请求参数 + 响应中的关键信息（如 duration、text_length 等）。
            完整 JSON 会写入 cache_entries.metadata_json。
        - query_metadata:
            可用于检索的元数据子集（例如 provider / voice_id / language / encoding 等）。
            除了整体存入 cache_entries.query_metadata_json，还会拆成多行 (entry_id, k, v)
            写入 cache_query_kv，用于 find_by_query_metadata 做 AND 过滤查询。
            如果 query_metadata 为空，则默认使用 metadata 作为 query_metadata。
        - normalized_query_artifacts:
            调用方「可选」传入的规范化查询产物，用于后续复用/排障。
            典型场景：
              * 已经做了比较重的预处理（清洗/分句/分词/embedding 前处理等），希望命中缓存时直接复用
              * 希望记录系统内部真正用于匹配/检索的规范化视图，方便日后分析“为什么命中/没命中”
            如果传入：
              * 会落盘到 query_meta_norm/<file_key>/norm.json，不进入 SQLite 索引
              * 之后通过 CacheHit.query_meta_norm_dir 能够拿到对应目录，自行读取使用
            如果不传：
              * 不会创建 query_meta_norm 目录
              * CacheHit.query_meta_norm_dir 将为 None，表示这条缓存没有额外的规范化产物
        - ttl_seconds:
            可选的过期时间（秒）。
            * None 或 <= 1 表示「永久有效」（不设置 expires_at，不参与过期判断），
              上层配置中可以统一归一到 -1 作为“永久”的标志值。
            * > 1 时会计算 expires_at，并在后续读取 / purge 时生效。
        - etag:
            可选的版本标记（如内容哈希、用户自定义版本号），
            方便后续进行幂等更新或一致性校验。

        写入步骤（出错即失败，不提交索引）：
        1) 原子写 blobs
        2) 原子写规范化查询元数据产物（可选）
        3) 事务 upsert SQLite 索引（失败不提交）
        """

        ck = make_cache_key(raw_key)
        expires_at: Optional[float] = None
        if ttl_seconds is not None:
            ttl = float(ttl_seconds)
            if ttl > 1:
                # 浮点秒级 TTL，避免整秒截断导致「刚写完就过期」的问题
                expires_at = float(time.time()) + ttl

        blob_path = self._blob_path(ck.file_key, suffix=blob_suffix)

        # 1) 写文件实体
        try:
            atomic_write_bytes(blob_path, blob)
        except OSError as e:
            raise CacheIOError(f"写入 blob 失败: {e}") from e

        # 2) 写规范化查询元数据产物目录（可选）
        norm_relpath: Optional[str] = None
        if normalized_query_artifacts is not None:
            norm_dir = ensure_dir(self._norm_dir_for_file_key(ck.file_key))
            norm_file = norm_dir / "norm.json"
            try:
                atomic_write_json(norm_file, normalized_query_artifacts)
            except OSError as e:
                # 规范化产物失败：为避免半成品，尝试清理并抛错（索引不会被写入）
                try:
                    if norm_file.exists():
                        norm_file.unlink()
                except Exception:
                    pass
                raise CacheIOError(f"写入规范化查询元数据失败: {e}") from e

            norm_relpath = str(norm_dir.relative_to(self.region_dir)).replace("\\", "/")

        # 3) 写索引（事务）
        blob_relpath = str(blob_path.relative_to(self.region_dir)).replace("\\", "/")
        self.index.upsert_entry(
            raw_key=ck.raw_key,
            norm_key=ck.norm_key,
            file_key=ck.file_key,
            blob_relpath=blob_relpath,
            metadata=metadata,
            query_metadata=query_metadata or metadata,
            query_meta_norm_relpath=norm_relpath,
            expires_at=expires_at,
            etag=etag,
        )
        return ck

    def set_value(
        self,
        raw_key: Any,
        *,
        value: Any,
        metadata: Optional[dict[str, Any]] = None,
        query_metadata: Optional[dict[str, Any]] = None,
        ttl_seconds: Optional[int] = None,
        etag: Optional[str] = None,
    ) -> CacheKey:
        """
        写入纯数据缓存（不写独立文件，数据存储在 SQLite 中）。

        适用场景：
        - 配置缓存（几 KB）
        - API 响应缓存（几十 KB）
        - 计算结果缓存（中等大小 JSON）
        - 任意可 JSON 序列化的轻量数据

        参数：
        - raw_key:
            业务侧传入的原始 key，用于标识「这一条缓存对应的请求」。
            可以是字符串，也可以是任意可 JSON 序列化的结构（如 dict）。
        - value:
            要缓存的数据，必须可 JSON 序列化（dict / list / str / int / float / bool / None）。
            内部会自动序列化为 JSON 并存储。
        - metadata:
            可选的原始元数据，用于「回看 / 调试」。
            如果不传，会自动生成包含 value_type 的基础元数据。
        - query_metadata:
            可用于检索的元数据子集（例如 category / user_id / version 等）。
            如果不传，默认使用 metadata。
        - ttl_seconds:
            可选的过期时间（秒）。
            * None 或 <= 1 表示「永久有效」
            * > 1 时会计算 expires_at，并在后续读取 / purge 时生效
        - etag:
            可选的版本标记（如内容哈希、用户自定义版本号）

        返回：
            CacheKey 对象（包含 raw_key / norm_key / file_key）

        示例：
            cache = CacheRegion(module="api", region="config")

            # 存储配置
            cache.set_value(
                raw_key="user_settings",
                value={"theme": "dark", "language": "zh-CN"},
                ttl_seconds=3600,
            )

            # 存储 API 响应
            cache.set_value(
                raw_key={"endpoint": "/api/users", "user_id": 123},
                value={"name": "Alice", "email": "alice@example.com"},
                query_metadata={"endpoint": "/api/users", "user_id": 123},
                ttl_seconds=300,
            )
        """
        # 序列化 value 为 JSON bytes
        try:
            value_json = json.dumps(value, ensure_ascii=False, indent=None)
            blob = value_json.encode("utf-8")
        except (TypeError, ValueError) as e:
            raise CacheIOError(f"value 无法序列化为 JSON: {e}") from e

        # 自动生成 metadata（如果未提供）
        if metadata is None:
            metadata = {
                "value_type": type(value).__name__,
                "is_value_cache": True,  # 标记为纯数据缓存
            }
        else:
            # 确保 metadata 中包含标记
            metadata = {**metadata, "is_value_cache": True}

        # 使用 .json 后缀标记为纯数据缓存
        return self.set_blob(
            raw_key=raw_key,
            blob=blob,
            blob_suffix=".json",
            metadata=metadata,
            query_metadata=query_metadata,
            ttl_seconds=ttl_seconds,
            etag=etag,
        )

    def get_blob(self, raw_key: Any) -> Optional[CacheHit]:
        """
        根据 raw_key 获取二进制文件缓存命中结果（不直接读取文件内容）。

        适用场景：需要获取文件路径或元数据，但不立即读取文件内容。
        如需直接获取文件内容，请使用 get_blob_bytes() 方法。
        如需获取纯数据缓存，请使用 get_value() 方法。

        处理流程：
        1. 基于 raw_key 重新构造 CacheKey（raw_key/norm_key/file_key）
        2. 使用 norm_key 在 SQLite 中查找对应记录（module + region 作用于命名空间）
        3. 对命中的记录做过期检查（expires_at）
        4. 检查 blob 文件是否存在，不存在则视为未命中

        返回：
            - 命中时返回 CacheHit 对象（包含路径与元数据）
            - 未命中 / 过期 / 文件缺失时返回 None
        """
        ck = make_cache_key(raw_key)
        row = self.index.get_by_norm_key(ck.norm_key)
        if row is None:
            return None

        # 过期检查（P0：读取时拦截；清理由 purge_expired 完成）
        if row.expires_at is not None and row.expires_at <= float(time.time()):
            return None

        blob_path = (self.region_dir / row.blob_relpath).resolve()
        if not blob_path.exists():
            # 索引命中但文件丢失：视为 miss（由 validate 清理）
            return None

        try:
            metadata = json.loads(row.metadata_json)
        except Exception:
            metadata = {}
        try:
            query_metadata = json.loads(row.query_metadata_json)
        except Exception:
            query_metadata = {}

        qnorm_dir = None
        if row.query_meta_norm_relpath:
            qnorm_dir = (self.region_dir / row.query_meta_norm_relpath).resolve()

        return CacheHit(
            raw_key=row.raw_key,
            norm_key=row.norm_key,
            file_key=row.file_key,
            blob_path=blob_path,
            metadata=metadata,
            query_metadata=query_metadata,
            query_meta_norm_dir=qnorm_dir,
            created_at=row.created_at,
            updated_at=row.updated_at,
            expires_at=row.expires_at,
            etag=row.etag,
        )

    def get_value(self, raw_key: Any) -> Optional[Any]:
        """
        根据 raw_key 直接获取纯数据缓存的内容。

        适用场景：读取通过 set_value() 存储的配置、API 响应、计算结果等。

        返回：
            - 命中时返回反序列化后的 Python 对象（dict / list / str / int / float / bool / None）
            - 未命中 / 过期时返回 None
            - 反序列化失败时抛出 CacheIOError

        示例：
            cache = CacheRegion(module="api", region="config")
            settings = cache.get_value("user_settings")
            if settings:
                print(settings["theme"])  # "dark"
        """
        blob = self.get_blob_bytes(raw_key)
        if blob is None:
            return None
        try:
            return json.loads(blob.decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError) as e:
            raise CacheIOError(f"反序列化缓存数据失败: {e}") from e

    def get_blob_bytes(self, raw_key: Any) -> Optional[bytes]:
        """
        根据 raw_key 直接获取缓存的二进制内容（同时适用于二进制文件缓存和纯数据缓存）。

        适用场景：
        - 二进制文件缓存：返回文件内容的 bytes
        - 纯数据缓存：返回 JSON 序列化后的 bytes

        建议：
        - 读取纯数据缓存：优先使用 get() 方法（自动反序列化为 Python 对象）
        - 读取二进制文件缓存：使用 get() 获取 CacheHit 后读取 blob_path，或直接使用本方法

        返回：
            - 命中且文件可读时返回 bytes
            - 未命中 / 过期时返回 None
            - 读取失败时抛出 CacheIOError
        """
        # 使用 get_blob() 而不是 get()，确保返回 CacheHit 对象
        hit = self.get_blob(raw_key)
        if not hit:
            return None
        try:
            return hit.blob_path.read_bytes()
        except OSError as e:
            raise CacheIOError(f"读取 blob 失败: {e}") from e

    # ========== 统一 API（自动适配不同缓存类型） ==========

    def set(
        self,
        raw_key: Any,
        *,
        value: Optional[Any] = None,
        blob: Optional[bytes] = None,
        blob_suffix: str = ".bin",
        metadata: Optional[dict[str, Any]] = None,
        query_metadata: Optional[dict[str, Any]] = None,
        normalized_query_artifacts: Optional[dict[str, Any]] = None,
        ttl_seconds: Optional[int] = None,
        etag: Optional[str] = None,
    ) -> CacheKey:
        """
        统一的缓存写入方法（自动适配二进制文件缓存和纯数据缓存）。

        使用方式：
        1. 传入 `value` 参数 → 存储纯数据缓存（自动 JSON 序列化）
        2. 传入 `blob` 参数 → 存储二进制文件缓存
        3. 同时传入 `value` 和 `blob` → 抛出错误（不允许）

        参数：
        - raw_key: 原始 key（字符串或可 JSON 序列化的对象）
        - value: 纯数据（dict / list / str / int / float / bool / None），与 blob 互斥
        - blob: 二进制数据（bytes），与 value 互斥
        - blob_suffix: blob 文件后缀（仅在传入 blob 时有效，默认 ".bin"）
        - metadata: 原始元数据（可选）
        - query_metadata: 查询元数据（可选）
        - normalized_query_artifacts: 规范化查询产物（可选）
        - ttl_seconds: 过期时间（秒，None 或 <= 1 表示永久有效）
        - etag: 版本标记（可选）

        返回：
            CacheKey 对象

        示例：
            # 存储纯数据
            cache.set(raw_key="config", value={"theme": "dark"})

            # 存储二进制文件
            cache.set(raw_key="audio", blob=audio_bytes, blob_suffix=".mp3")
        """
        # 参数校验
        if value is not None and blob is not None:
            raise CacheConfigError("不能同时传入 value 和 blob 参数，请选择其一")
        if value is None and blob is None:
            raise CacheConfigError("必须传入 value 或 blob 参数之一")

        # 根据参数类型自动路由
        if value is not None:
            # 纯数据缓存
            return self.set_value(
                raw_key=raw_key,
                value=value,
                metadata=metadata,
                query_metadata=query_metadata,
                ttl_seconds=ttl_seconds,
                etag=etag,
            )
        else:
            # 二进制文件缓存
            if metadata is None:
                raise CacheConfigError("存储二进制文件缓存时必须提供 metadata 参数")
            return self.set_blob(
                raw_key=raw_key,
                blob=blob,
                blob_suffix=blob_suffix,
                metadata=metadata,
                query_metadata=query_metadata,
                normalized_query_artifacts=normalized_query_artifacts,
                ttl_seconds=ttl_seconds,
                etag=etag,
            )

    def get(self, raw_key: Any) -> Optional[Any]:
        """
        统一的缓存读取方法（自动适配不同缓存类型）。

        工作流程：
        1. 查询索引获取缓存记录
        2. 检查 metadata 中的 is_value_cache 标记
        3. 如果是纯数据缓存 → 返回反序列化后的 Python 对象
        4. 如果是二进制文件缓存 → 返回 CacheHit 对象（包含文件路径和元数据）

        返回：
            - 纯数据缓存：返回 Python 对象（dict / list / str / int / float / bool / None）
            - 二进制文件缓存：返回 CacheHit 对象
            - 未命中 / 过期：返回 None

        示例：
            # 读取纯数据缓存
            config = cache.get("config")
            if config:
                print(config["theme"])  # "dark"

            # 读取二进制文件缓存
            hit = cache.get("audio")
            if hit:
                audio_bytes = hit.blob_path.read_bytes()
                print(f"Duration: {hit.metadata['duration']}")
        """
        # 统一查询入口
        hit = self.get_blob(raw_key)
        if hit is None:
            return None

        # 根据缓存类型自动返回对应数据
        is_value_cache = hit.metadata.get("is_value_cache", False)
        if is_value_cache:
            # 纯数据缓存：自动反序列化
            try:
                blob = hit.blob_path.read_bytes()
                return json.loads(blob.decode("utf-8"))
            except (json.JSONDecodeError, UnicodeDecodeError, OSError) as e:
                raise CacheIOError(f"读取纯数据缓存失败: {e}") from e
        else:
            # 二进制文件缓存：返回 CacheHit 对象
            return hit

    def get_bytes(self, raw_key: Any) -> Optional[bytes]:
        """
        直接获取缓存的二进制内容（兼容方法）。

        适用场景：
        - 纯数据缓存：返回 JSON 序列化后的 bytes（通常不需要）
        - 二进制文件缓存：返回文件内容的 bytes

        建议：
        - 读取纯数据缓存：使用 get() 方法（自动反序列化）
        - 读取二进制文件缓存：使用 get() 获取 CacheHit 后读取 blob_path

        返回：
            - 命中时返回 bytes
            - 未命中 / 过期时返回 None
        """
        return self.get_blob_bytes(raw_key)

    # ========== 通用方法（适用于所有缓存类型） ==========

    def delete(self, raw_key: Any, *, delete_files: bool = True) -> bool:
        """
        删除缓存记录（同时适用于二进制文件缓存和纯数据缓存）。

        参数：
        - raw_key: 原始 key
        - delete_files: 是否同时删除文件（默认 True）

        返回：
            - True: 删除成功
            - False: 未找到对应记录
        """
        ck = make_cache_key(raw_key)
        row = self.index.get_by_norm_key(ck.norm_key)
        if row is None:
            return False

        # 先删索引（事务），再删文件：避免“文件删了但索引还在”的窗口期扩大
        deleted = self.index.delete_by_file_key(row.file_key)
        if not deleted:
            return False

        if not delete_files:
            return True

        # best-effort 清理文件与规范化目录
        try:
            blob_path = self.region_dir / row.blob_relpath
            if blob_path.exists():
                blob_path.unlink()
        except Exception:
            pass

        if row.query_meta_norm_relpath:
            try:
                norm_dir = self.region_dir / row.query_meta_norm_relpath
                if norm_dir.exists() and norm_dir.is_dir():
                    for p in norm_dir.rglob("*"):
                        if p.is_file():
                            p.unlink()
                    # 删除空目录（从深到浅）
                    for p in sorted(norm_dir.rglob("*"), reverse=True):
                        if p.is_dir():
                            try:
                                p.rmdir()
                            except Exception:
                                pass
                    try:
                        norm_dir.rmdir()
                    except Exception:
                        pass
            except Exception:
                pass

        return True

    def find_by_query_metadata(
        self, query: dict[str, Any], *, limit: int = 100
    ) -> list[CacheHit]:
        """
        根据 query_metadata 的 KV 做精确 AND 匹配查询（同时适用于二进制文件缓存和纯数据缓存）。

        说明：
        - query 中的键值会统一转为字符串，映射到 cache_query_kv(k, v)
        - 多个 (k, v) 条件使用 AND 语义：必须全部命中同一条 entry 才会返回
        - 仅在当前 module + region 命名空间内查找

        过滤逻辑：
        - 返回前会再次检查 expires_at（过期条目直接过滤）
        - 会验证 blob 是否存在，缺失则跳过（视为不可用）

        返回：
            - CacheHit 列表，按 updated_at 倒序，最多 limit 条

        示例：
            # 查找特定 provider 和 voice_id 的 TTS 缓存
            hits = cache.find_by_query_metadata({
                "provider": "azure",
                "voice_id": "zh-CN-XiaoxiaoNeural"
            })

            # 查找特定 endpoint 的 API 响应缓存
            hits = cache.find_by_query_metadata({
                "endpoint": "/api/users",
                "user_id": "123"
            })
        """
        # P0：仅支持 query_metadata 的精确 KV AND 匹配（统一转 str）
        q = {str(k): str(v) for k, v in query.items() if v is not None}
        rows = self.index.find_by_query_kv(q, limit=limit)
        hits: list[CacheHit] = []
        for row in rows:
            # 过期过滤
            if row.expires_at is not None and row.expires_at <= float(time.time()):
                continue

            blob_path = (self.region_dir / row.blob_relpath).resolve()
            if not blob_path.exists():
                continue

            try:
                metadata = json.loads(row.metadata_json)
            except Exception:
                metadata = {}
            try:
                query_metadata = json.loads(row.query_metadata_json)
            except Exception:
                query_metadata = {}

            qnorm_dir = None
            if row.query_meta_norm_relpath:
                qnorm_dir = (self.region_dir / row.query_meta_norm_relpath).resolve()

            hits.append(
                CacheHit(
                    raw_key=row.raw_key,
                    norm_key=row.norm_key,
                    file_key=row.file_key,
                    blob_path=blob_path,
                    metadata=metadata,
                    query_metadata=query_metadata,
                    query_meta_norm_dir=qnorm_dir,
                    created_at=row.created_at,
                    updated_at=row.updated_at,
                    expires_at=row.expires_at,
                    etag=row.etag,
                )
            )
        return hits

    def purge_expired(self, *, delete_files: bool = True) -> int:
        """
        删除已过期的索引记录，并（可选）删除对应文件与规范化目录（同时适用于二进制文件缓存和纯数据缓存）。

        参数：
        - delete_files: 是否同时删除文件（默认 True）

        返回：
            删除的记录数量
        """

        expired = self.index.purge_expired()
        if not expired:
            return 0

        if delete_files:
            for row in expired:
                # best-effort
                try:
                    blob = self.region_dir / row.blob_relpath
                    if blob.exists():
                        blob.unlink()
                except Exception:
                    pass
                if row.query_meta_norm_relpath:
                    try:
                        norm_dir = self.region_dir / row.query_meta_norm_relpath
                        if norm_dir.exists() and norm_dir.is_dir():
                            for p in norm_dir.rglob("*"):
                                if p.is_file():
                                    p.unlink()
                            for p in sorted(norm_dir.rglob("*"), reverse=True):
                                if p.is_dir():
                                    try:
                                        p.rmdir()
                                    except Exception:
                                        pass
                            try:
                                norm_dir.rmdir()
                            except Exception:
                                pass
                    except Exception:
                        pass
        return len(expired)

    def validate(self, *, _delete_orphans: bool = False) -> dict[str, int]:
        """
        验证索引与文件一致性（同时适用于二进制文件缓存和纯数据缓存）。

        P0：只做最小验证：索引命中但 blob 不存在的计数（可选删除索引）。

        参数：
        - _delete_orphans: 是否删除孤立索引（默认 False）

        返回：
            验证统计信息字典
        """

        # P0：没有提供全表扫描 API（避免引入额外复杂度）。
        # 这里先用一个简化策略：依赖业务的 “get/find_by_query_metadata” 主要路径；
        # 真正的全量 validate/cleanup 留到 P1/P2 扩展（可加分页扫描）。
        #
        # 仍返回结构以便未来兼容。
        return {"checked": 0, "missing_blob": 0, "deleted_orphans": 0}
