from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import re
from typing import Any
import unicodedata

_SPACE_RE = re.compile(r"\s+")


@dataclass(frozen=True)
class CacheKey:
    """
    缓存 key 三态：
    - raw_key: 调用方原始 key（必须可回放/排障）
    - norm_key: cache 模块规范化后的 key（用于一致性匹配）
    - file_key: 安全文件名 key（用于目录/文件名）
    """

    raw_key: str
    norm_key: str
    file_key: str


def normalize_key(raw_key: str) -> str:
    """
    将 raw_key 规范化为可稳定比较的字符串。

    说明：
    - 仅做“通用且可解释”的规范化：Unicode NFKC、去首尾空白、折叠空白。
    - 不默认 lower()，避免对大小写敏感的业务 key 产生歧义；如需大小写不敏感，可在上层构造 key 时控制。
    """

    k = unicodedata.normalize("NFKC", raw_key)
    k = k.strip()
    return _SPACE_RE.sub(" ", k)


def file_key_from_norm_key(norm_key: str) -> str:
    """
    将 norm_key 映射为安全文件名 key。
    使用 sha256，避免特殊字符/超长路径；同时兼容跨平台文件系统。
    """

    return hashlib.sha256(norm_key.encode("utf-8")).hexdigest()


def make_cache_key(raw_key: Any) -> CacheKey:
    """
    将任意可序列化输入转换为 CacheKey。

    约束：
    - raw_key 最终必须是字符串；若传入非字符串，会做 JSON 序列化（稳定排序）后作为 raw_key。
    """

    if isinstance(raw_key, str):
        raw = raw_key
    else:
        raw = json.dumps(
            raw_key, ensure_ascii=False, sort_keys=True, separators=(",", ":")
        )

    norm = normalize_key(raw)
    file_key = file_key_from_norm_key(norm)
    return CacheKey(raw_key=raw, norm_key=norm, file_key=file_key)
