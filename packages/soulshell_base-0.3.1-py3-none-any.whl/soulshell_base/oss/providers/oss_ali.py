"""
阿里引擎 oss 提供商实现
文档: https://help.aliyun.com/zh/oss/developer-reference/2-0-manual-preview-version/?spm=a2c4g.11186623.help-menu-31815.d_1_1_2.16c03954rnMPn9
"""

import asyncio
from datetime import datetime, timedelta
from email.utils import parsedate_to_datetime
import os
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, ClassVar, Dict, List, Optional
from urllib.parse import quote

try:
    import alibabacloud_oss_v2 as oss
    from alibabacloud_oss_v2.credentials import StaticCredentialsProvider
except ImportError:
    raise ImportError("阿里oss模块未安装， 运行 pip install alibabacloud-oss-v2")


from soulshell_base.core import get_logger
from soulshell_base.core.retry import async_retry

from ..base import BaseOSS
from ..exceptions import (
    OSSAuthenticationError,
    OSSException,
    OSSInvalidParameterError,
    OSSNetworkError,
    OSSServiceUnavailableError,
    OSSUploadError,
)
from ..models import (
    OSSAcl,
    OSSFileMetadata,
    OSSListResponse,
    OSSUploadOptions,
    OSSUploadRequest,
    OSSUploadResponse,
    OSSUrlType,
)

# 为避免循环导入，使用字符串类型注解
if TYPE_CHECKING:
    from ..models import OSSMultipartUploadRequest

logger = get_logger(__name__)


class BytesReadAtReader:
    """
    字节数据读取器，实现 ReadAtReader 接口
    用于支持字节数据的分片上传
    """

    def __init__(self, data: bytes):
        """
        初始化字节数据读取器

        Args:
            data: 字节数据
        """
        self.data = data
        self.size = len(data)

    def readat(self, offset: int, length: int) -> bytes:
        """
        从指定偏移量读取指定长度的数据

        Args:
            offset: 偏移量
            length: 读取长度

        Returns:
            bytes: 读取的数据
        """
        end = min(offset + length, self.size)
        return self.data[offset:end]


class FileStreamReader:
    """
    文件流读取器，用于支持大文件的流式读取
    避免将整个文件加载到内存中
    """

    def __init__(self, file_path: str):
        """
        初始化文件流读取器

        Args:
            file_path: 文件路径
        """
        self.file_path = file_path

    def read_chunk(self, offset: int, length: int) -> bytes:
        """
        从指定偏移量读取指定长度的数据块

        Args:
            offset: 偏移量
            length: 读取长度

        Returns:
            bytes: 读取的数据块
        """
        with open(self.file_path, "rb") as f:
            f.seek(offset)
            return f.read(length)


class OSSProviderALi(BaseOSS):
    """阿里 oss 提供商"""

    # 定义必需配置和可选配置
    REQUIRED_CONFIG: ClassVar[List[str]] = [
        "access_key_id",
        "access_key_secret",
        "bucket",
    ]
    OPTIONAL_CONFIG: ClassVar[Dict[str, Any]] = {
        "region": "cn-hangzhou",
        "endpoint": "https://oss-cn-hangzhou.aliyuncs.com",
    }

    def __init__(self, **kwargs):
        """
        初始化阿里 OSS 提供商

        Args:
            **kwargs: 配置参数
                - access_key_id: 访问密钥ID（必需）
                - access_key_secret: 访问密钥Secret（必需）
                - bucket: 存储桶名称（必需）
                - region: 区域（可选，默认 cn-hangzhou）
                - endpoint: 端点URL（可选，默认 https://oss-cn-hangzhou.aliyuncs.com）
        """

        super().__init__(**kwargs)

        # 验证配置
        if not self.validate_config():
            self.logger.error("初始化阿里引擎 OSS 失败, 参数缺失")
            return

        # 从配置获取参数
        self.credentials_provider = StaticCredentialsProvider(
            access_key_id=self.config["access_key_id"],
            access_key_secret=self.config["access_key_secret"],
        )
        self.bucket = self.config["bucket"]
        self.region = self.config.get("region", "cn-hangzhou")
        self.endpoint = self.config.get(
            "endpoint", "https://oss-cn-hangzhou.aliyuncs.com"
        )

        # 客户端懒加载
        self._client: Optional[oss.Client] = None

        self.logger.info("初始化阿里引擎 OSS 成功")

    @property
    def client(self) -> "oss.Client":
        """
        获取 OSS 客户端（懒加载）

        Returns:
            oss.Client: OSS 客户端实例
        """
        if self._client is None:
            cfg = oss.config.load_default()
            cfg.credentials_provider = self.credentials_provider
            cfg.region = self.region
            cfg.endpoint = self.endpoint
            self._client = oss.Client(cfg)
        return self._client

    def get_provider_name(self) -> str:
        """获取提供商名称"""
        return "oss_ali"

    @classmethod
    def describe(cls) -> Dict[str, Any]:
        """获取提供商描述信息"""
        return {
            "provider_name": "oss_ali",
            "display_name": "阿里云 OSS",
            "description": "阿里云对象存储服务",
            "required_init_params": {
                "access_key_id": {
                    "type": "str",
                    "description": "阿里云 Access Key ID",
                    "env_var": "OSS_ALI_ACCESS_KEY_ID",
                },
                "access_key_secret": {
                    "type": "str",
                    "description": "阿里云 Access Key Secret",
                    "env_var": "OSS_ALI_ACCESS_KEY_SECRET",
                },
                "bucket": {
                    "type": "str",
                    "description": "OSS Bucket 名称",
                    "env_var": "OSS_ALI_BUCKET",
                },
            },
            "optional_init_params": {
                "region": {
                    "type": "str",
                    "description": "OSS 区域（如 cn-hangzhou）",
                    "default": None,
                },
                "endpoint": {
                    "type": "str",
                    "description": "OSS 服务端点",
                    "default": None,
                },
                "timeout": {
                    "type": "int",
                    "description": "请求超时时间（秒）",
                    "default": 30,
                },
            },
            "supported_features": [
                "upload_bytes: 上传字节数据",
                "upload_file: 上传本地文件",
                "upload_request: 使用请求对象上传",
                "download: 下载文件",
                "delete: 删除文件",
                "exists: 判断文件是否存在",
                "get_metadata: 获取文件元数据",
                "list_files: 列出文件",
                "generate_presigned_url: 生成预签名 URL",
                "multipart_upload: 分片上传",
            ],
            "example": """oss = OSSFactory.create(
    provider_name="oss_ali",
    access_key_id="your_access_key_id",
    access_key_secret="your_access_key_secret",
    bucket="your_bucket",
    region="cn-hangzhou"
)""",
        }

    def validate_config(self) -> bool:
        """
        验证配置参数

        Returns:
            bool: 配置是否有效
        """
        return super().validate_config()

    def _handle_oss_exception(self, e: Exception, operation: str) -> None:
        """
        处理 OSS 异常并转换为模块异常

        Args:
            e: 原始异常
            operation: 操作名称

        Raises:
            OSSException: 转换后的异常
        """
        error_msg = str(e)
        error_code = None

        # 尝试从异常中提取错误代码
        if hasattr(e, "code"):
            error_code = e.code
        elif hasattr(e, "status_code"):
            error_code = str(e.status_code)

        # 根据错误类型转换异常
        if (
            "401" in error_msg
            or "403" in error_msg
            or "InvalidAccessKeyId" in error_msg
        ):
            raise OSSAuthenticationError(
                f"{operation}失败: {error_msg}", error_code
            ) from e
        if "404" in error_msg or "NoSuchKey" in error_msg:
            raise OSSInvalidParameterError(
                f"{operation}失败（文件不存在或token等信息错误）: {error_msg}",
                error_code,
            ) from e
        if "503" in error_msg or "ServiceUnavailable" in error_msg:
            raise OSSServiceUnavailableError(
                f"{operation}失败（服务不可用）: {error_msg}", error_code
            ) from e
        if "Network" in error_msg or "Connection" in error_msg:
            raise OSSNetworkError(f"{operation}失败: 网络错误", error_code) from e
        raise OSSUploadError(f"{operation}失败: {error_msg}", error_code) from e

    def _get_progress_callback(
        self,
        callback: Optional[Callable[[int, int], None]] = None,
        total: int = 0,  # noqa: ARG002
    ) -> Optional[Callable[[int, int, int], None]]:
        """
        获取进度回调函数

        Args:
            callback: 自定义进度回调函数 (written, total)
            total: 文件总大小（未使用，保留以兼容接口）

        Returns:
            Optional[Callable]: 进度回调函数 (n, written, total)
        """
        if callback is None:
            # 默认使用 logger
            def default_callback(_n: int, written: int, total_size: int):
                rate = (
                    int(100 * (float(written) / float(total_size)))
                    if total_size > 0
                    else 0
                )
                self.logger.info(f"上传进度: {rate}% ({written}/{total_size} bytes)")

            return default_callback

        # 包装自定义回调
        def wrapped_callback(_n: int, written: int, total_size: int):
            callback(written, total_size)

        return wrapped_callback

    def _convert_acl(self, acl: Optional[OSSAcl | str]) -> Optional[str]:
        """
        转换 ACL 枚举为字符串

        Args:
            acl: ACL 枚举或字符串

        Returns:
            Optional[str]: ACL 字符串
        """
        if acl is None:
            return None
        if isinstance(acl, OSSAcl):
            return acl.value
        return str(acl)

    def _generate_permanent_url(self, file_name: str) -> str:
        """
        生成永久链接（适用于公共读的桶）

        Args:
            file_name: 文件名称

        Returns:
            str: 永久链接
        """

        # URL编码文件名称
        encoded_key = quote(file_name, safe="/")

        # 解析endpoint
        endpoint = self.endpoint
        if endpoint.startswith("http://"):
            endpoint = endpoint[7:]
        elif endpoint.startswith("https://"):
            endpoint = endpoint[8:]

        # 移除末尾的斜杠
        endpoint = endpoint.rstrip("/")

        # 生成永久链接：https://{bucket}.{endpoint}/{key}
        # 例如：https://my-bucket.oss-cn-hangzhou.aliyuncs.com/folder/file.txt
        return f"https://{self.bucket}.{endpoint}/{encoded_key}"

    def _generate_presigned_url(
        self, file_name: str, expires: int = 3600
    ) -> tuple[str, datetime]:
        """
        生成预签名URL（临时链接）

        Args:
            file_name: 文件名称
            expires: 过期时间（秒，默认3600）

        Returns:
            tuple[str, datetime]: 预签名URL和过期时间
        """
        client = self.client

        # 生成预签名 URL
        pre_result = client.presign(
            oss.GetObjectRequest(
                bucket=self.bucket,
                key=file_name,
            ),
            expires=timedelta(seconds=expires),
        )

        return pre_result.url, pre_result.expiration

    async def upload_request(
        self, request: OSSUploadRequest, options: Optional[OSSUploadOptions] = None
    ) -> OSSUploadResponse:
        """
        上传文件（核心API，使用 Request 对象）

        Args:
            request: 上传请求参数
            options: 上传选项配置

        Returns:
            OSSUploadResponse: 上传响应

        Raises:
            OSSException: 上传失败时抛出
        """
        try:
            # 验证请求
            self.validate_request(request)

            # 使用默认选项
            options = options or OSSUploadOptions()

            # 判断是否需要使用分片上传
            file_size = 0
            file_path: Optional[Path] = None
            data_bytes: Optional[bytes] = None

            if isinstance(request.data, bytes):
                data_bytes = request.data
                file_size = len(data_bytes)
            elif isinstance(request.data, str | Path):
                file_path = Path(request.data)
                file_size = file_path.stat().st_size
            else:
                raise OSSInvalidParameterError(
                    f"不支持的数据类型: {type(request.data)}"
                )

            # 判断是否使用分片上传
            # 如果文件大小超过阈值且启用了自动分片，使用分片上传
            use_multipart = (
                options.auto_choose_multipart
                and file_size > options.multipart_threshold
            )

            # 执行上传
            if use_multipart:
                # 使用分片上传（适用于大文件，支持字节数据和文件路径）
                upload_result = await self._upload_multipart_internal(
                    file_name=request.file_name,
                    request=request,
                    options=options,
                    file_path=file_path,
                    data_bytes=data_bytes,
                    file_size=file_size,
                )
            else:
                # 使用普通上传（适用于小文件或未启用自动分片的情况）
                upload_result = await self._upload_single_internal(
                    request=request,
                    options=options,
                    file_size=file_size,
                    file_path=file_path,
                    data_bytes=data_bytes,
                )

            # 根据 URL 类型生成链接
            url_type = options.url_type
            expires_at = None

            if url_type == OSSUrlType.PRESIGNED:
                # 生成预签名 URL（临时链接）
                expires = options.presign_expires
                url, expires_at = self._generate_presigned_url(
                    request.file_name, expires=expires
                )
                self.logger.debug(f"生成预签名URL: {url}, 过期时间: {expires_at}")
            else:
                # 生成永久链接（默认）
                url = self._generate_permanent_url(request.file_name)
                self.logger.debug(f"生成永久链接: {url}")

            # 构建响应
            return OSSUploadResponse(
                url=url,
                file_name=request.file_name,
                etag=upload_result.get("etag"),
                size=file_size,
                content_type=request.content_type,
                metadata=request.metadata,
                expires_at=expires_at,
                request_id=upload_result.get("request_id"),
            )

        except OSSException:
            raise
        except Exception as e:
            self._handle_oss_exception(e, "上传文件")

    async def _upload_single_internal(
        self,
        request: OSSUploadRequest,
        options: OSSUploadOptions,
        file_size: int,
        file_path: Optional[Path] = None,
        data_bytes: Optional[bytes] = None,
    ) -> Dict[str, Any]:
        """
        执行普通上传（内部方法，支持重试）

        Args:
            request: 上传请求参数
            options: 上传选项配置
            file_size: 文件大小
            file_path: 文件路径（如果数据来自文件）
            data_bytes: 字节数据（如果数据来自字节）

        Returns:
            Dict[str, Any]: 上传结果（包含 etag、request_id、status_code）
        """

        # 内部上传方法（不带重试）
        async def _do_upload() -> Dict[str, Any]:
            client = self.client

            # 获取数据
            if data_bytes is not None:
                data = data_bytes
            elif file_path:
                # 对于文件路径，直接读取（如果文件较小）
                data = file_path.read_bytes()
            else:
                raise OSSInvalidParameterError(
                    f"不支持的数据类型: {type(request.data)}"
                )

            # 构建上传请求参数
            put_request_params: Dict[str, Any] = {
                "bucket": self.bucket,
                "key": request.file_name,
                "body": data,
            }

            # 设置 Content-Type
            if request.content_type:
                put_request_params["content_type"] = request.content_type

            # 设置 ACL
            if request.acl:
                put_request_params["acl"] = self._convert_acl(request.acl)

            # 设置缓存控制
            if request.cache_control:
                put_request_params["cache_control"] = request.cache_control

            # 设置 Content-Disposition
            if request.content_disposition:
                put_request_params["content_disposition"] = request.content_disposition

            # 设置元数据
            if request.metadata:
                put_request_params["metadata"] = request.metadata

            # 设置进度回调
            if options.progress_callback:
                progress_fn = self._get_progress_callback(
                    callback=options.progress_callback, total=file_size
                )
                put_request_params["progress_fn"] = progress_fn

            try:
                # 上传文件
                result = client.put_object(oss.PutObjectRequest(**put_request_params))

                self.logger.debug(
                    f"上传成功: status_code={result.status_code}, "
                    f"request_id={result.request_id}, etag={result.etag}"
                )

                return {
                    "etag": result.etag,
                    "request_id": result.request_id,
                    "status_code": result.status_code,
                }
            except Exception as e:
                # 转换为模块异常
                self._handle_oss_exception(e, "上传文件")

        # 根据选项决定是否使用重试
        if options.enable_retry:
            # 可重试的异常类型
            retryable_exceptions = (OSSNetworkError, OSSServiceUnavailableError)
            # 使用重试装饰器
            retry_decorator = async_retry(
                max_attempts=options.max_retries + 1,  # +1 因为包含首次尝试
                delay=options.retry_delay,
                backoff=options.retry_backoff,
                exceptions=retryable_exceptions,
            )
            return await retry_decorator(_do_upload)()
        # 不使用重试
        return await _do_upload()

    async def _upload_multipart_internal(
        self,
        file_name: str,
        request: OSSUploadRequest,
        options: OSSUploadOptions,
        file_path: Optional[Path] = None,
        data_bytes: Optional[bytes] = None,
        file_size: int = 0,  # noqa: ARG002
    ) -> Dict[str, Any]:
        """
        执行分片上传（内部方法，支持并发上传和重试）

        Args:
            file_name: 文件名称
            request: 上传请求参数
            options: 上传选项配置
            file_path: 文件路径（如果数据来自文件）
            data_bytes: 字节数据（如果数据来自字节）
            file_size: 文件大小（用于日志记录，实际从数据源获取）

        Returns:
            Dict[str, Any]: 上传结果（包含 etag、request_id、status_code）
        """
        client = self.client

        # 使用配置的分片大小
        part_size = options.part_size

        # 初始化分片上传请求
        init_request = oss.InitiateMultipartUploadRequest(
            bucket=self.bucket,
            key=file_name,
        )

        # 设置 Content-Type
        if request.content_type:
            init_request.content_type = request.content_type

        # 设置 ACL
        if request.acl:
            init_request.acl = self._convert_acl(request.acl)

        # 设置缓存控制
        if request.cache_control:
            init_request.cache_control = request.cache_control

        # 设置 Content-Disposition
        if request.content_disposition:
            init_request.content_disposition = request.content_disposition

        # 设置元数据
        if request.metadata:
            init_request.metadata = request.metadata

        init_result = client.initiate_multipart_upload(init_request)
        upload_id = init_result.upload_id

        try:
            # 准备分片信息
            if data_bytes is not None:
                data_size = len(data_bytes)
                bytes_reader = BytesReadAtReader(data_bytes)
                file_reader = None
            elif file_path:
                file_path_str = str(file_path)
                # 使用文件流读取器避免将整个文件加载到内存
                file_reader = FileStreamReader(file_path_str)
                data_size = os.path.getsize(file_path_str)
                bytes_reader = None
            else:
                raise OSSInvalidParameterError("必须提供 file_path 或 data_bytes")

            # 计算分片数量
            total_parts = (data_size + part_size - 1) // part_size
            self.logger.info(
                f"开始分片上传: 文件大小={data_size}, 分片大小={part_size}, "
                f"分片数量={total_parts}, 并发数={options.concurrent_upload_count}"
            )

            # 创建分片任务列表
            part_tasks: List[Dict[str, Any]] = []
            for part_number in range(1, total_parts + 1):
                start = (part_number - 1) * part_size
                n = min(part_size, data_size - start)
                part_tasks.append(
                    {
                        "part_number": part_number,
                        "start": start,
                        "size": n,
                    }
                )

            # 并发上传分片
            semaphore = asyncio.Semaphore(options.concurrent_upload_count)

            async def upload_part_task(part_info: Dict[str, Any]) -> oss.UploadPart:
                """上传单个分片（支持重试）"""
                part_number = part_info["part_number"]
                start = part_info["start"]
                n = part_info["size"]

                async def _do_upload_part() -> oss.UploadPart:
                    """执行单个分片上传（支持并发控制）"""
                    async with semaphore:
                        try:
                            # 准备分片数据（在获取信号量后准备，避免并发读取文件）
                            # 根据数据来源选择不同的读取方式
                            if bytes_reader is not None:
                                # 从字节数据中读取
                                part_data = bytes_reader.readat(start, n)
                            elif file_reader is not None:
                                # 从文件中读取指定范围的数据，避免将整个文件加载到内存
                                part_data = file_reader.read_chunk(start, n)
                            else:
                                raise OSSInvalidParameterError(
                                    "必须提供 file_path 或 data_bytes"
                                )
                            body_data = part_data

                            # 在线程池中执行同步的上传操作（避免阻塞事件循环）
                            def _sync_upload_part() -> oss.UploadPart:
                                """同步上传分片（在线程池中执行）"""
                                up_result = client.upload_part(
                                    oss.UploadPartRequest(
                                        bucket=self.bucket,
                                        key=file_name,
                                        upload_id=upload_id,
                                        part_number=part_number,
                                        body=body_data,
                                    )
                                )
                                return oss.UploadPart(
                                    part_number=part_number, etag=up_result.etag
                                )

                            # 在线程池中执行同步操作（避免阻塞事件循环）
                            # 使用 run_in_executor 兼容所有 Python 版本
                            loop = asyncio.get_event_loop()
                            upload_part_obj = await loop.run_in_executor(
                                None, _sync_upload_part
                            )

                            self.logger.debug(
                                f"分片 {part_number}/{total_parts} 上传成功: "
                                f"etag={upload_part_obj.etag}, size={n}"
                            )

                            return upload_part_obj
                        except Exception as e:
                            # 转换为模块异常
                            self._handle_oss_exception(e, f"上传分片 {part_number}")

                # 根据选项决定是否使用重试
                if options.enable_retry:
                    retryable_exceptions = (OSSNetworkError, OSSServiceUnavailableError)
                    retry_decorator = async_retry(
                        max_attempts=options.max_retries + 1,
                        delay=options.retry_delay,
                        backoff=options.retry_backoff,
                        exceptions=retryable_exceptions,
                    )
                    return await retry_decorator(_do_upload_part)()
                return await _do_upload_part()

            # 并发执行所有分片上传任务
            upload_parts = await asyncio.gather(
                *[upload_part_task(task) for task in part_tasks]
            )

            # 对上传的分片按照分片编号排序
            parts = sorted(upload_parts, key=lambda p: p.part_number)

            # 完成分片上传
            result = client.complete_multipart_upload(
                oss.CompleteMultipartUploadRequest(
                    bucket=self.bucket,
                    key=file_name,
                    upload_id=upload_id,
                    complete_multipart_upload=oss.CompleteMultipartUpload(parts=parts),
                )
            )

            self.logger.info(
                f"分片上传完成: status_code={result.status_code}, "
                f"request_id={result.request_id}, etag={result.etag}"
            )

            return {
                "etag": result.etag,
                "request_id": result.request_id,
                "status_code": result.status_code,
            }

        except Exception as e:
            # 如果上传失败，尝试取消分片上传
            try:
                client.abort_multipart_upload(
                    oss.AbortMultipartUploadRequest(
                        bucket=self.bucket,
                        key=file_name,
                        upload_id=upload_id,
                    )
                )
                self.logger.warning(f"已取消分片上传: upload_id={upload_id}")
            except Exception as abort_error:
                self.logger.error(f"取消分片上传失败: {abort_error}")

            # 重新抛出原始异常
            if isinstance(e, OSSException):
                raise
            self._handle_oss_exception(e, "分片上传")

    async def multipart_upload(
        self,
        request: "OSSMultipartUploadRequest",
        options: Optional[OSSUploadOptions] = None,
    ) -> str:
        """
        分片上传文件（专用接口）

        Args:
            request: 分片上传请求参数
            options: 上传选项配置

        Returns:
            str: upload_id 用于后续分片上传

        Raises:
            OSSException: 上传失败时抛出
        """
        try:
            # 使用默认选项
            options = options or OSSUploadOptions()

            # 保存请求对象以便后续使用
            options._request = request

            # 初始化分片上传
            upload_id = await self.init_multipart_upload(request.file_name, options)

            # 这里返回upload_id，实际的分片上传需要调用方通过upload_part等方法完成
            # 在实际使用中，调用方需要自己管理分片上传过程
            return upload_id  # noqa: RET504

        except Exception as e:
            self._handle_oss_exception(e, "分片上传初始化")

    async def init_multipart_upload(
        self, file_name: str, options: Optional[OSSUploadOptions] = None
    ) -> str:
        """
        初始化分片上传（分片上传使用）

        Args:
            file_name: 文件名称
            options: 上传选项配置

        Returns:
            str: upload_id 用于后续分片上传

        Raises:
            OSSException: 初始化失败时抛出
        """
        try:
            client = self.client
            options = options or OSSUploadOptions()

            # 初始化分片上传请求
            init_request = oss.InitiateMultipartUploadRequest(
                bucket=self.bucket,
                key=file_name,
            )

            # 从请求对象获取文件属性（如果存在）
            if hasattr(options, "_request"):
                request = options._request

                # 设置 Content-Type
                if request.content_type:
                    init_request.content_type = request.content_type
                    # self.logger.debug(f"设置 Content-Type: {request.content_type}")

                # 设置 ACL
                if request.acl:
                    init_request.acl = self._convert_acl(request.acl)
                    # self.logger.debug(f"设置 ACL: {request.acl}")

                # 设置缓存控制
                if request.cache_control:
                    init_request.cache_control = request.cache_control
                    # self.logger.debug(f"设置 Cache-Control: {request.cache_control}")

                # 设置 Content-Disposition
                if request.content_disposition:
                    init_request.content_disposition = request.content_disposition
                    # self.logger.debug(f"设置 Content-Disposition: {request.content_disposition}")

                # # # 设置元数据(实测，外部分片的上传时，设置metadata 会导致 The request signature we calculated does not match the signature you provided. Check your key and signing method.. 报错，不带就ok)
                # if request.metadata:
                #     init_request.metadata = request.metadata
                #     self.logger.debug(f"设置元数据: {request.metadata}")

            # 执行初始化分片上传
            init_result = client.initiate_multipart_upload(init_request)
            self.logger.debug(
                f"初始化分片上传file_name={file_name} 向 OSS bucket={self.bucket} 成功: upload_id={init_result.upload_id}"
            )
            return init_result.upload_id

        except Exception as e:
            self._handle_oss_exception(e, "初始化分片上传")

    async def upload_part(
        self,
        file_name: str,
        upload_id: str,
        part_number: int,
        part_data: bytes,
        options: Optional[OSSUploadOptions] = None,
    ) -> str:
        """
        上传单个分片（分片上传使用）

        Args:
            file_name: 文件名称
            upload_id: 上传ID
            part_number: 分片编号
            part_data: 分片数据
            options: 上传选项配置

        Returns:
            str: 分片ETag

        Raises:
            OSSException: 上传失败时抛出
        """
        try:
            client = self.client
            options = options or OSSUploadOptions()

            # 上传分片
            up_result = client.upload_part(
                oss.UploadPartRequest(
                    bucket=self.bucket,
                    key=file_name,
                    upload_id=upload_id,
                    part_number=part_number,
                    body=part_data,
                )
            )

            return up_result.etag

        except Exception as e:
            self._handle_oss_exception(e, f"上传分片 {part_number}")

    async def complete_multipart_upload(
        self,
        file_name: str,
        upload_id: str,
        part_etags: List[str],
        options: Optional[OSSUploadOptions] = None,
    ) -> OSSUploadResponse:
        """
        完成分片上传（分片上传使用）

        Args:
            file_name: 文件名称
            upload_id: 上传ID
            part_etags: 所有分片的ETag列表
            options: 上传选项配置

        Returns:
            OSSUploadResponse: 上传响应

        Raises:
            OSSException: 完成失败时抛出
        """
        try:
            client = self.client
            options = options or OSSUploadOptions()

            # 构造分片列表
            parts = [
                oss.UploadPart(part_number=i + 1, etag=etag)
                for i, etag in enumerate(part_etags)
            ]

            # 完成分片上传
            result = client.complete_multipart_upload(
                oss.CompleteMultipartUploadRequest(
                    bucket=self.bucket,
                    key=file_name,
                    upload_id=upload_id,
                    complete_multipart_upload=oss.CompleteMultipartUpload(parts=parts),
                )
            )

            # 获取文件属性
            content_type = None
            metadata = {}
            total_size = None

            # 如果有请求对象，使用请求对象中的属性
            if hasattr(options, "_request"):
                request = options._request
                if hasattr(request, "content_type") and request.content_type:
                    content_type = request.content_type
                if hasattr(request, "metadata") and request.metadata:
                    metadata = request.metadata
                if hasattr(request, "total_size") and request.total_size is not None:
                    total_size = request.total_size

            # 根据 URL 类型生成链接
            url_type = options.url_type
            expires_at = None

            if url_type == OSSUrlType.PRESIGNED:
                # 生成预签名 URL（临时链接）
                expires = options.presign_expires
                url, expires_at = self._generate_presigned_url(
                    file_name, expires=expires
                )
                self.logger.debug(f"生成预签名URL: {url}, 过期时间: {expires_at}")
            else:
                # 生成永久链接（默认）
                url = self._generate_permanent_url(file_name)
                self.logger.debug(f"生成永久链接: {url}")

            # 构建响应
            return OSSUploadResponse(
                url=url,
                file_name=file_name,
                etag=result.etag,
                size=total_size,
                content_type=content_type,
                metadata=metadata,
                expires_at=expires_at,
                request_id=result.request_id,
            )

        except Exception as e:
            self._handle_oss_exception(e, "完成分片上传")

    async def abort_multipart_upload(
        self, file_name: str, upload_id: str, options: Optional[OSSUploadOptions] = None
    ) -> bool:
        """
        取消分片上传（分片上传使用）

        Args:
            file_name: 文件名称
            upload_id: 上传ID
            options: 上传选项配置

        Returns:
            bool: 是否取消成功

        Raises:
            OSSException: 取消失败时抛出
        """
        try:
            client = self.client
            options = options or OSSUploadOptions()

            # 取消分片上传
            client.abort_multipart_upload(
                oss.AbortMultipartUploadRequest(
                    bucket=self.bucket,
                    key=file_name,
                    upload_id=upload_id,
                )
            )

            self.logger.warning(f"已取消分片上传: upload_id={upload_id}")
            return True

        except Exception as e:
            self._handle_oss_exception(e, "取消分片上传")

    async def download(
        self, file_name: str, local_path: Optional[str | Path] = None
    ) -> bytes:
        """
        下载文件

        Args:
            file_name: 文件名称
            local_path: 本地保存路径（可选，如果提供则保存到文件）

        Returns:
            bytes: 文件数据

        Raises:
            OSSException: 下载失败时抛出
        """
        try:
            client = self.client

            # 下载文件
            result = client.get_object(
                oss.GetObjectRequest(
                    bucket=self.bucket,
                    key=file_name,
                )
            )

            # 读取文件数据
            data = result.body.read()

            # 如果提供了本地路径，保存到文件
            if local_path:
                local_file = Path(local_path)
                local_file.parent.mkdir(parents=True, exist_ok=True)
                local_file.write_bytes(data)
                self.logger.debug(f"文件已保存到: {local_file}")

            return data

        except Exception as e:
            self._handle_oss_exception(e, "下载文件")

    async def delete(self, file_name: str) -> bool:
        """
        删除文件

        Args:
            file_name: 文件名称

        Returns:
            bool: 是否删除成功

        Raises:
            OSSException: 删除失败时抛出
        """
        try:
            client = self.client

            # 删除文件
            result = client.delete_object(
                oss.DeleteObjectRequest(
                    bucket=self.bucket,
                    key=file_name,
                )
            )

            self.logger.debug(
                f"删除成功: status_code={result.status_code}, "
                f"request_id={result.request_id}"
            )

            return result.status_code == 204

        except Exception as e:
            self._handle_oss_exception(e, "删除文件")

    async def exists(self, file_name: str) -> bool:
        """
        检查文件是否存在

        Args:
            file_name: 文件名称

        Returns:
            bool: 文件是否存在

        Raises:
            OSSException: 检查失败时抛出
        """
        try:
            client = self.client

            # 检查文件是否存在
            result = client.head_object(
                oss.HeadObjectRequest(
                    bucket=self.bucket,
                    key=file_name,
                )
            )

            # 如果状态码是 200，文件存在
            return result.status_code == 200

        except Exception as e:
            # 如果文件不存在，返回 False
            error_msg = str(e)
            if (
                "404" in error_msg
                or "NoSuchKey" in error_msg
                or "Not Found" in error_msg
            ):
                return False
            # 其他错误则抛出异常
            self._handle_oss_exception(e, "检查文件存在")

    async def get_metadata(self, file_name: str) -> OSSFileMetadata:
        """
        获取文件元数据

        Args:
            file_name: 文件名称

        Returns:
            OSSFileMetadata: 文件元数据

        Raises:
            OSSException: 获取失败时抛出
        """
        try:
            client = self.client

            # 获取文件元数据
            result = client.head_object(
                oss.HeadObjectRequest(
                    bucket=self.bucket,
                    key=file_name,
                )
            )

            # 解析 Last-Modified 时间
            last_modified = None
            if hasattr(result, "last_modified"):
                last_modified = result.last_modified
            elif hasattr(result, "headers"):
                last_modified_str = result.headers.get("Last-Modified")
                if last_modified_str:
                    try:
                        # 尝试解析 RFC 1123 格式的时间字符串

                        last_modified = parsedate_to_datetime(last_modified_str)
                    except Exception:
                        self.logger.warning(
                            f"无法解析 Last-Modified: {last_modified_str}"
                        )

            # 提取元数据
            metadata_dict = {}
            if hasattr(result, "headers"):
                headers = result.headers
                # 提取 x-oss-meta- 开头的元数据
                for key, value in headers.items():
                    if key.lower().startswith("x-oss-meta-"):
                        metadata_dict[key[11:]] = value  # 移除 "x-oss-meta-" 前缀

            # 构建元数据对象并返回
            return OSSFileMetadata(
                file_name=file_name,
                size=getattr(result, "content_length", 0)
                or int(getattr(result, "headers", {}).get("Content-Length", 0) or 0),
                content_type=getattr(result, "content_type", None)
                or getattr(result, "headers", {}).get("Content-Type"),
                etag=getattr(result, "etag", None)
                or getattr(result, "headers", {}).get("ETag", "").strip('"'),
                last_modified=last_modified,
                metadata=metadata_dict,
                acl=getattr(result, "headers", {}).get("x-oss-object-acl"),
                storage_class=getattr(result, "headers", {}).get("x-oss-storage-class"),
            )

        except Exception as e:
            self._handle_oss_exception(e, "获取文件元数据")

    async def list_files(
        self, prefix: str = "", max_keys: int = 100
    ) -> OSSListResponse:
        """
        列出文件

        Args:
            prefix: 文件前缀（可选，用于过滤）
            max_keys: 返回的最大数量（默认100）

        Returns:
            OSSListResponse: 文件列表响应

        Raises:
            OSSException: 列出失败时抛出
        """
        try:
            client = self.client

            # 列出文件
            result = client.list_objects_v2(
                oss.ListObjectsV2Request(
                    bucket=self.bucket,
                    prefix=prefix,
                    max_keys=max_keys,
                )
            )

            # 提取文件列表和前缀列表
            files = [obj.key for obj in result.contents] if result.contents else []
            prefixes = (
                [prefix_obj.prefix for prefix_obj in result.common_prefixes]
                if result.common_prefixes
                else []
            )

            # 构建响应
            return OSSListResponse(
                files=files,
                prefixes=prefixes,
                is_truncated=result.is_truncated,
                next_marker=result.next_continuation_token,
                max_keys=max_keys,
            )

        except Exception as e:
            self._handle_oss_exception(e, "列出文件")

    async def generate_presigned_url(
        self,
        file_name: str,
        method: str = "GET",
        expires: int = 3600,
        content_type: Optional[str] = None,
    ) -> str:
        """
        生成预签名 URL

        Args:
            file_name: 文件名称
            method: HTTP 方法（GET/PUT/DELETE，默认GET）
            expires: 过期时间（秒，默认3600）
            content_type: Content-Type（可选，用于PUT方法）

        Returns:
            str: 预签名 URL

        Raises:
            OSSException: 生成失败时抛出
        """
        try:
            client = self.client

            # 根据方法构建请求
            if method.upper() == "GET":
                request = oss.GetObjectRequest(
                    bucket=self.bucket,
                    key=file_name,
                )
            elif method.upper() == "PUT":
                request = oss.PutObjectRequest(
                    bucket=self.bucket,
                    key=file_name,
                )
                if content_type:
                    request.content_type = content_type
            elif method.upper() == "DELETE":
                request = oss.DeleteObjectRequest(
                    bucket=self.bucket,
                    key=file_name,
                )
            else:
                raise OSSInvalidParameterError(f"不支持的方法: {method}")

            # 生成预签名 URL
            pre_result = client.presign(request, expires=timedelta(seconds=expires))
        except OSSException:
            raise
        except Exception as e:
            self._handle_oss_exception(e, "生成预签名URL")
        return pre_result.url
