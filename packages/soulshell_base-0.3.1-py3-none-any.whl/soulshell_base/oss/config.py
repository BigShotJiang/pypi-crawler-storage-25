"""
OSS 配置管理
支持从环境变量、配置文件等加载配置
"""

from dataclasses import dataclass, field
import os
from typing import Any, Dict, Optional

from soulshell_base.core import get_logger

logger = get_logger(__name__, level="DEBUG")


@dataclass
class OSSProviderConfig:
    """OSS 提供商配置"""

    provider_name: str
    access_key_id: str
    access_key_secret: str
    bucket: str
    extra_params: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_env(cls, provider_name: str, prefix: str = "OSS") -> "OSSProviderConfig":
        """
        从环境变量加载配置

        Args:
            provider_name: 提供商名称
            prefix: 环境变量前缀

        Returns:
            OSSProviderConfig: 配置对象

        Example:
            # 环境变量: OSS_ALI_ACCESS_KEY_ID, OSS_ALI_ACCESS_KEY_SECRET, OSS_ALI_BUCKET
            config = OSSProviderConfig.from_env("ali")
        """
        env_prefix = f"{prefix}_{provider_name.upper()}_"
        access_key_id = os.getenv(f"{env_prefix}ACCESS_KEY_ID")
        access_key_secret = os.getenv(f"{env_prefix}ACCESS_KEY_SECRET")
        bucket = os.getenv(f"{env_prefix}BUCKET")

        if not access_key_id:
            raise ValueError(f"未找到环境变量: {env_prefix}ACCESS_KEY_ID")
        if not access_key_secret:
            raise ValueError(f"未找到环境变量: {env_prefix}ACCESS_KEY_SECRET")
        if not bucket:
            raise ValueError(f"未找到环境变量: {env_prefix}BUCKET")

        # 收集其他以该前缀开头的环境变量
        extra_params = {}
        for key, value in os.environ.items():
            if key.startswith(env_prefix) and key not in [
                f"{env_prefix}ACCESS_KEY_ID",
                f"{env_prefix}ACCESS_KEY_SECRET",
                f"{env_prefix}BUCKET",
            ]:
                # 移除前缀并转为小写
                param_key = key[len(env_prefix) :].lower()
                extra_params[param_key] = value

        logger.debug(f"从环境变量加载 {provider_name} 配置: {extra_params}")
        return cls(
            provider_name=provider_name,
            access_key_id=access_key_id,
            access_key_secret=access_key_secret,
            bucket=bucket,
            extra_params=extra_params,
        )

    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> "OSSProviderConfig":
        """
        从字典加载配置

        Args:
            config_dict: 配置字典

        Returns:
            OSSProviderConfig: 配置对象
        """
        provider_name = config_dict.get("provider_name")
        access_key_id = config_dict.get("access_key_id")
        access_key_secret = config_dict.get("access_key_secret")
        bucket = config_dict.get("bucket")

        if not provider_name:
            raise ValueError("配置字典必须包含 provider_name")
        if not access_key_id:
            raise ValueError("配置字典必须包含 access_key_id")
        if not access_key_secret:
            raise ValueError("配置字典必须包含 access_key_secret")
        if not bucket:
            raise ValueError("配置字典必须包含 bucket")

        # 其他参数都作为 extra_params（例如 region、endpoint 等）
        extra_params = {
            k: v
            for k, v in config_dict.items()
            if k
            not in ["provider_name", "access_key_id", "access_key_secret", "bucket"]
        }

        return cls(
            provider_name=provider_name,
            access_key_id=access_key_id,
            access_key_secret=access_key_secret,
            bucket=bucket,
            extra_params=extra_params,
        )

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        result = {
            "access_key_id": self.access_key_id,
            "access_key_secret": self.access_key_secret,
            "bucket": self.bucket,
        }
        result.update(self.extra_params)
        return result


class OSSConfigManager:
    """OSS 配置管理器"""

    def __init__(self):
        self._configs: Dict[str, OSSProviderConfig] = {}

    def add_config(self, provider_name: str, config: OSSProviderConfig) -> None:
        """
        添加配置

        Args:
            provider_name: 提供商名称
            config: 配置对象
        """
        self._configs[provider_name] = config
        logger.info(f"添加 {provider_name} 配置")

    def get_config(self, provider_name: str) -> Optional[OSSProviderConfig]:
        """
        获取配置

        Args:
            provider_name: 提供商名称

        Returns:
            Optional[OSSProviderConfig]: 配置对象，如果不存在返回 None
        """
        return self._configs.get(provider_name)

    def load_from_env(self, provider_name: str, prefix: str = "OSS") -> None:
        """
        从环境变量加载配置

        Args:
            provider_name: 提供商名称
            prefix: 环境变量前缀
        """
        config = OSSProviderConfig.from_env(provider_name, prefix)
        self.add_config(provider_name, config)

    def has_config(self, provider_name: str) -> bool:
        """
        检查是否有指定提供商的配置

        Args:
            provider_name: 提供商名称

        Returns:
            bool: 是否存在配置
        """
        return provider_name in self._configs
