"""
OSS 数据模型
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import mimetypes
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional


class OSSAcl(str, Enum):
    """对象访问权限"""

    PRIVATE = "private"  # 私有
    PUBLIC_READ = "public-read"  # 公共读
    PUBLIC_READ_WRITE = "public-read-write"  # 公共读写


class OSSUrlType(str, Enum):
    """OSS URL 类型"""

    PERMANENT = "permanent"  # 永久链接（适用于公共读的桶）
    PRESIGNED = "presigned"  # 预签名URL（临时链接）


@dataclass
class OSSBaseUploadRequest:
    """OSS 上传请求基类"""

    file_name: str  # 文件名称（可包含路径前缀，如 "folder/file.txt"）
    content_type: Optional[str] = None  # Content-Type（如 "image/jpeg"）
    metadata: Dict[str, str] = field(default_factory=dict)  # 元数据
    acl: Optional[OSSAcl | str] = None  # 访问权限（private/public-read等）
    cache_control: Optional[str] = None  # 缓存控制（如 "max-age=3600"）
    content_disposition: Optional[str] = (
        None  # 下载时文件名（如 "attachment; filename=file.txt"）
    )
    expires: Optional[int] = None  # 过期时间（秒，Unix 时间戳）
    extra_params: Dict[str, Any] = field(default_factory=dict)  # 扩展参数

    def __post_init__(self):
        """参数验证和类型转换"""
        if not self.file_name:
            raise ValueError("file_name 不能为空")

        # 转换 acl 字符串为枚举
        if isinstance(self.acl, str):
            try:
                self.acl = OSSAcl(self.acl.lower())
            except ValueError:
                # 如果不是预定义的 acl，保持原值
                pass


@dataclass
class OSSUploadRequest(OSSBaseUploadRequest):
    """OSS 上传请求参数"""

    data: None | bytes | str | Path = (
        None  # 文件数据（支持 bytes、文件路径或 Path 对象）
    )

    def __post_init__(self):
        """参数验证和类型转换"""
        # 调用父类的 __post_init__
        super().__post_init__()

        if not self.data:
            raise ValueError("data 不能为空")

        # 验证文件路径（如果是路径类型）
        if isinstance(self.data, str | Path):
            data_path = Path(self.data)
            if not data_path.exists():
                raise ValueError(f"文件不存在: {data_path}")
            # 如果未指定 content_type，尝试从文件扩展名推断
            if not self.content_type:
                self.content_type = self._infer_content_type(data_path)

    @staticmethod
    def _infer_content_type(file_path: Path) -> str:
        """
        从文件扩展名推断 Content-Type

        优先使用 Python 标准库 mimetypes 模块，
        对于特殊类型使用自定义映射作为补充。
        """
        # 使用 mimetypes 模块推断
        content_type, _ = mimetypes.guess_type(str(file_path))
        if content_type:
            return content_type

        # 自定义映射作为补充（mimetypes 可能不支持的类型）
        extension = file_path.suffix.lower()
        custom_content_type_map = {
            ".wav": "audio/wav",
            ".mp3": "audio/mpeg",
            ".m4a": "audio/mp4",
            ".flac": "audio/flac",
            ".ogg": "audio/ogg",
            ".webm": "video/webm",
            ".mkv": "video/x-matroska",
            ".mov": "video/quicktime",
            ".avi": "video/x-msvideo",
            ".flv": "video/x-flv",
            ".woff": "font/woff",
            ".woff2": "font/woff2",
            ".ttf": "font/ttf",
            ".eot": "application/vnd.ms-fontobject",
            ".otf": "font/otf",
            ".svg": "image/svg+xml",
            ".webp": "image/webp",
            ".ico": "image/x-icon",
            ".json": "application/json",
            ".xml": "application/xml",
            ".yaml": "application/x-yaml",
            ".yml": "application/x-yaml",
            ".csv": "text/csv",
            ".ts": "application/typescript",
            ".tsx": "application/typescript",
            ".jsx": "text/javascript",
        }
        return custom_content_type_map.get(extension, "application/octet-stream")


@dataclass
class OSSUploadOptions:
    """OSS 基于路径或整理文件bytes，整体上传选项配置"""

    multipart_threshold: int = 100 * 1024 * 1024  # 分片上传阈值（默认100MB）
    auto_choose_multipart: bool = True  # 是否自动选择分片上传（大于阈值时）
    part_size: int = (
        5 * 1024 * 1024
    )  # 整体上传时，使用自动分片时，单分片大小（默认5MB）
    concurrent_upload_count: int = 5  # 分片上传并发数（默认5个）
    url_type: OSSUrlType = OSSUrlType.PERMANENT  # URL类型（默认永久链接）
    presign_expires: int = 3600  # 预签名URL过期时间（秒，默认1小时）
    progress_callback: Optional[Callable[[int, int], None]] = (
        None  # 进度回调 (written, total)
    )
    enable_retry: bool = True  # 是否启用重试
    max_retries: int = 3  # 最大重试次数
    retry_delay: float = 1.0  # 重试延迟时间（秒，默认1秒）
    retry_backoff: float = 2.0  # 重试退避倍数（默认2倍）
    timeout: Optional[int] = None  # 超时时间（秒）

    def __post_init__(self):
        """参数验证"""
        if self.part_size <= 0:
            raise ValueError("part_size 必须大于 0")
        if self.presign_expires <= 0:
            raise ValueError("presign_expires 必须大于 0")
        if self.max_retries < 0:
            raise ValueError("max_retries 必须大于等于 0")
        if self.retry_delay <= 0:
            raise ValueError("retry_delay 必须大于 0")
        if self.retry_backoff <= 0:
            raise ValueError("retry_backoff 必须大于 0")
        if self.concurrent_upload_count <= 0:
            raise ValueError("concurrent_upload_count 必须大于 0")
        # 转换 url_type 字符串为枚举
        if isinstance(self.url_type, str):
            try:
                self.url_type = OSSUrlType(self.url_type.lower())
            except ValueError:
                # 如果不是预定义的类型，保持原值
                pass


@dataclass
class OSSUploadResponse:
    """OSS 上传响应"""

    url: str  # 文件访问 URL
    file_name: str  # 文件名称
    etag: Optional[str] = None  # 文件 ETag
    size: Optional[int] = None  # 文件大小（字节）
    content_type: Optional[str] = None  # Content-Type
    metadata: Dict[str, Any] = field(default_factory=dict)  # 元数据
    expires_at: Optional[datetime] = None  # 过期时间（如果是预签名URL）
    request_id: Optional[str] = None  # 请求 ID（用于调试）

    @property
    def is_presigned(self) -> bool:
        """是否为预签名 URL"""
        return self.expires_at is not None

    @property
    def is_expired(self) -> bool:
        """是否已过期（仅对预签名URL有效）"""
        if self.expires_at is None:
            return False
        # 解决 can't compare offset-naive and offset-aware datetimes
        now = (
            datetime.now(tz=self.expires_at.tzinfo)
            if self.expires_at.tzinfo
            else datetime.now()
        )
        return now > self.expires_at


@dataclass
class OSSFileMetadata:
    """OSS 文件元数据"""

    file_name: str  # 文件名称
    size: int  # 文件大小（字节）
    content_type: Optional[str] = None  # Content-Type
    etag: Optional[str] = None  # 文件 ETag
    last_modified: Optional[datetime] = None  # 最后修改时间
    metadata: Dict[str, str] = field(default_factory=dict)  # 元数据
    acl: Optional[str] = None  # 访问权限
    storage_class: Optional[str] = None  # 存储类型


@dataclass
class OSSListResponse:
    """OSS 文件列表响应"""

    files: List[str]  # 文件名称列表
    prefixes: List[str] = field(default_factory=list)  # 前缀列表（目录）
    is_truncated: bool = False  # 是否还有更多文件
    next_marker: Optional[str] = None  # 下次查询的标记
    max_keys: int = 100  # 返回的最大数量


@dataclass
class OSSMultipartUploadRequest(OSSBaseUploadRequest):
    """OSS 分片上传请求参数
    专门用于分片上传，与整体上传请求对象区分开来
    """

    total_size: Optional[int] = None  # 文件总大小（字节，可选）

    def __post_init__(self):
        """参数验证和类型转换"""
        # 调用父类的 __post_init__
        super().__post_init__()

        # 如果提供了 total_size，验证它必须大于 0
        if self.total_size is not None and self.total_size <= 0:
            raise ValueError("total_size 必须大于 0")
