"""
OSS 模块自定义异常
"""

from typing import Optional


class OSSException(Exception):  # noqa: N818
    """OSS 基础异常"""

    def __init__(self, message: str, error_code: Optional[str] = None):
        self.message = message
        self.error_code = error_code
        super().__init__(self.message)


class OSSProviderNotFoundError(OSSException):
    """OSS 提供商未找到"""


class OSSAuthenticationError(OSSException):
    """OSS 认证失败"""


class OSSRateLimitError(OSSException):
    """OSS 限流错误"""


class OSSInvalidParameterError(OSSException):
    """OSS 参数错误"""


class OSSServiceUnavailableError(OSSException):
    """OSS 服务不可用"""


class OSSNetworkError(OSSException):
    """OSS 网络错误"""


class OSSUploadError(OSSException):
    """OSS 上传失败"""
