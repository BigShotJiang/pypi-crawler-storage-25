"""
OSS (Object Storage Service) 模块
支持多平台的对象存储服务
"""

# 导入核心类
from .base import BaseOSS
from .config import OSSConfigManager, OSSProviderConfig
from .exceptions import (
    OSSAuthenticationError,
    OSSException,
    OSSInvalidParameterError,
    OSSNetworkError,
    OSSProviderNotFoundError,
    OSSRateLimitError,
    OSSServiceUnavailableError,
    OSSUploadError,
)
from .factory import OSSFactory
from .models import (
    OSSAcl,
    OSSFileMetadata,
    OSSListResponse,
    OSSMultipartUploadRequest,  # 添加分片上传请求对象
    OSSUploadOptions,
    OSSUploadRequest,
    OSSUploadResponse,
    OSSUrlType,
)

__version__ = "0.3.1"

__all__ = [
    # 核心类
    "BaseOSS",
    "OSSFactory",
    "OSSProviderConfig",
    "OSSConfigManager",
    # 模型类
    "OSSUploadRequest",
    "OSSMultipartUploadRequest",  # 导出分片上传请求对象
    "OSSUploadResponse",
    "OSSUploadOptions",
    "OSSFileMetadata",
    "OSSListResponse",
    "OSSAcl",
    "OSSUrlType",
    # 异常类
    "OSSException",
    "OSSProviderNotFoundError",
    "OSSAuthenticationError",
    "OSSRateLimitError",
    "OSSInvalidParameterError",
    "OSSServiceUnavailableError",
    "OSSNetworkError",
    "OSSUploadError",
]
