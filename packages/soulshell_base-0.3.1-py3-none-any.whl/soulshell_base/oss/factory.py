"""
OSS 工厂类
"""

from typing import Any, ClassVar, Dict, List, Tuple, Type

from soulshell_base.core import get_logger

from .base import BaseOSS
from .exceptions import OSSProviderNotFoundError

logger = get_logger(__name__)


class OSSFactory:
    """OSS 工厂类 - 支持延迟加载提供商"""

    # 提供商映射：名称 -> (模块路径, 类名)
    _PROVIDER_MAP: ClassVar[Dict[str, Tuple[str, str]]] = {
        "oss_ali": ("soulshell_base.oss.providers.oss_ali", "OSSProviderALi"),
    }

    # 依赖提示信息
    _DEPENDENCY_HINTS: ClassVar[Dict[str, str]] = {
        "oss_ali": "alibabacloud-oss-v2 (安装: pip install alibabacloud-oss-v2 或 uv sync --extra oss-aliyun)",
    }

    _providers: ClassVar[Dict[str, Type[BaseOSS]]] = {}

    @classmethod
    def register(cls, name: str, provider_class: Type[BaseOSS]) -> None:
        """
        注册 OSS 提供商

        Args:
            name: 提供商名称
            provider_class: 提供商类

        Raises:
            TypeError: 如果 provider_class 不是 BaseOSS 的子类
        """
        if not issubclass(provider_class, BaseOSS):
            raise TypeError(f"{provider_class} 必须继承自 BaseOSS")
        cls._providers[name] = provider_class
        logger.debug(f"已注册 OSS 提供商: {name}")

    @classmethod
    def unregister(cls, name: str) -> None:
        """
        取消注册 OSS 提供商

        Args:
            name: 提供商名称
        """
        if name in cls._providers:
            del cls._providers[name]
            logger.debug(f"已取消注册 OSS 提供商: {name}")

    @classmethod
    def get_providers(cls) -> List[str]:
        """
        获取已注册的提供商列表

        Returns:
            list[str]: 提供商名称列表
        """
        return list(cls._providers.keys())

    @classmethod
    def list_available_providers(cls) -> List[str]:
        """
        列出所有可用的提供商（包括未加载的）

        Returns:
            list[str]: 提供商名称列表
        """
        return list(cls._PROVIDER_MAP.keys())

    @classmethod
    def describe(cls, provider_name: str) -> Dict[str, Any]:
        """获取提供商描述信息（自描述能力）

        Args:
            provider_name: 提供商名称

        Returns:
            包含必填/可选参数、示例的描述信息

        Raises:
            OSSProviderNotFoundError: 提供商不存在

        Example:
            >>> from soulshell_base.oss import OSSFactory
            >>> info = OSSFactory.describe("oss_ali")
            >>> print(info['required_init_params'])
            {'access_key_id': {'type': 'str', 'description': 'Access Key ID', ...}}
        """
        if provider_name not in cls._PROVIDER_MAP:
            available = cls.list_available_providers()
            raise OSSProviderNotFoundError(
                f"未知的 OSS 提供商: {provider_name}. 可用提供商: {available}"
            )

        # 延迟加载 Provider 类
        if provider_name not in cls._providers:
            cls._lazy_load_provider(provider_name)

        provider_class = cls._providers[provider_name]
        return provider_class.describe()

    @classmethod
    def _lazy_load_provider(cls, provider_name: str) -> None:
        """
        延迟加载提供商

        Args:
            provider_name: 提供商名称

        Raises:
            OSSProviderNotFoundError: 提供商不存在
            ImportError: 缺少必要的依赖包
        """
        if provider_name not in cls._PROVIDER_MAP:
            available = cls.list_available_providers()
            raise OSSProviderNotFoundError(
                f"未知的 OSS 提供商: {provider_name}. 可用提供商: {available}"
            )

        module_path, class_name = cls._PROVIDER_MAP[provider_name]
        try:
            module = __import__(module_path, fromlist=[class_name])
        except ImportError as e:
            raise ImportError(
                f"缺少必要的依赖包: {cls._DEPENDENCY_HINTS.get(provider_name, '')}"
            ) from e

        provider_class = getattr(module, class_name)
        cls._providers[provider_name] = provider_class
        logger.debug(f"成功延迟加载 OSS 提供商: {provider_name}")

    @classmethod
    def create(cls, provider_name: str, **kwargs) -> BaseOSS:
        """
        创建 OSS 提供商实例（支持延迟加载）

        Args:
            provider_name: 提供商名称
            **kwargs: 配置参数（例如 access_key_id、access_key_secret、bucket、endpoint 等）

        Returns:
            BaseOSS: OSS 提供商实例

        Raises:
            OSSProviderNotFoundError: 提供商不存在
            ImportError: 缺少必要的依赖包
            ValueError: 配置无效
        """
        # 如果提供商未缓存，则延迟加载
        if provider_name not in cls._providers:
            cls._lazy_load_provider(provider_name)

        provider_class = cls._providers[provider_name]
        instance = provider_class(**kwargs)

        # 验证配置
        if not instance.validate_config():
            raise ValueError(f"OSS 提供商 {provider_name} 配置无效")

        logger.debug(f"成功创建 OSS 提供商实例: {provider_name}")
        return instance

    @classmethod
    def create_from_config(cls, provider_name: str, config: Dict[str, Any]) -> BaseOSS:
        """
        从配置字典创建实例

        Args:
            provider_name: 提供商名称
            config: 配置字典，所需参数按提供商要求传入（例如 access_key_id、access_key_secret、bucket 等）

        Returns:
            BaseOSS: OSS 提供商实例
        """
        return cls.create(provider_name, **config)
