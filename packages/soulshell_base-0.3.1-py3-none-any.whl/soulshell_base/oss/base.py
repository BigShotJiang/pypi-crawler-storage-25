"""
OSS 抽象基类
"""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import TYPE_CHECKING, Any, ClassVar, Dict, List, Optional

from soulshell_base.core import get_logger

from .exceptions import OSSInvalidParameterError
from .models import (
    OSSFileMetadata,
    OSSListResponse,
    OSSMultipartUploadRequest,
    OSSUploadOptions,
    OSSUploadRequest,
    OSSUploadResponse,
)

# 为避免循环导入，使用字符串类型注解
if TYPE_CHECKING:
    from .models import OSSMultipartUploadRequest


class BaseOSS(ABC):
    """OSS 抽象基类"""

    # 子类可以定义必需配置和可选配置
    REQUIRED_CONFIG: ClassVar[List[str]] = []  # 必需配置项
    OPTIONAL_CONFIG: ClassVar[Dict[str, Any]] = {}  # 可选配置项及默认值

    def __init__(self, **kwargs):
        """
        初始化 OSS 提供商

        Args:
            **kwargs: 配置参数（例如 access_key_id、access_key_secret、bucket 等）
        """
        self.config = kwargs
        self.logger = get_logger(
            f"{self.__class__.__module__}.{self.__class__.__name__}",
            level=self.config.get("log_level", "INFO"),
        )

    @abstractmethod
    def get_provider_name(self) -> str:
        """
        获取供应商名称

        Returns:
            str: 供应商名称
        """

    @abstractmethod
    async def upload_request(
        self, request: OSSUploadRequest, options: Optional[OSSUploadOptions] = None
    ) -> OSSUploadResponse:
        """
        上传文件（核心API，使用 Request 对象）

        Args:
            request: 上传请求参数
            options: 上传选项配置

        Returns:
            OSSUploadResponse: 上传响应

        Raises:
            OSSException: 上传失败时抛出
        """

    async def init_multipart_upload(
        self, file_name: str, options: Optional[OSSUploadOptions] = None
    ) -> str:
        """
        初始化分片上传（分片上传使用）

        Args:
            file_name: 文件名称
            options: 上传选项配置

        Returns:
            str: upload_id 用于后续分片上传

        Raises:
            OSSException: 初始化失败时抛出
        """
        raise NotImplementedError(f"{self.get_provider_name()} 不支持分片上传")

    async def upload_part(
        self,
        file_name: str,
        upload_id: str,
        part_number: int,
        part_data: bytes,
        options: Optional[OSSUploadOptions] = None,
    ) -> str:
        """
        上传单个分片（分片上传使用）

        Args:
            file_name: 文件名称
            upload_id: 上传ID
            part_number: 分片编号
            part_data: 分片数据
            options: 上传选项配置

        Returns:
            str: 分片ETag

        Raises:
            OSSException: 上传失败时抛出
        """
        raise NotImplementedError(f"{self.get_provider_name()} 不支持分片上传")

    async def complete_multipart_upload(
        self,
        file_name: str,
        upload_id: str,
        part_etags: List[str],
        options: Optional[OSSUploadOptions] = None,
    ) -> OSSUploadResponse:
        """
        完成分片上传（分片上传使用）

        Args:
            file_name: 文件名称
            upload_id: 上传ID
            part_etags: 所有分片的ETag列表
            options: 上传选项配置

        Returns:
            OSSUploadResponse: 上传响应

        Raises:
            OSSException: 完成失败时抛出
        """
        raise NotImplementedError(f"{self.get_provider_name()} 不支持分片上传")

    async def abort_multipart_upload(
        self, file_name: str, upload_id: str, options: Optional[OSSUploadOptions] = None
    ) -> bool:
        """
        取消分片上传（分片上传使用）

        Args:
            file_name: 文件名称
            upload_id: 上传ID
            options: 上传选项配置

        Returns:
            bool: 是否取消成功

        Raises:
            OSSException: 取消失败时抛出
        """
        raise NotImplementedError(f"{self.get_provider_name()} 不支持分片上传")

    async def multipart_upload(
        self,
        request: "OSSMultipartUploadRequest",
        options: Optional[OSSUploadOptions] = None,
    ) -> str:
        """
        分片上传文件（专用接口）

        Args:
            request: 分片上传请求参数
            options: 上传选项配置

        Returns:
            str: upload_id 用于后续分片上传

        Raises:
            OSSException: 上传失败时抛出
        """
        raise NotImplementedError(f"{self.get_provider_name()} 不支持分片上传")

    async def upload(self, data: bytes, file_name: str) -> str:
        """
        上传文件数据（便捷方法，向后兼容）

        Args:
            data: 文件数据（字节）
            file_name: 文件名称

        Returns:
            str: 文件访问 URL

        Raises:
            OSSException: 上传失败时抛出
        """
        # 便捷方法：内部调用 upload_request
        request = OSSUploadRequest(data=data, file_name=file_name)
        options = OSSUploadOptions()  # 使用默认选项（永久链接）
        response = await self.upload_request(request, options)
        return response.url

    async def upload_multipart(self, file_path: str, file_name: str) -> str:
        """
        分片上传文件（便捷方法，向后兼容）

        Args:
            file_path: 本地文件路径
            file_name: 文件名称

        Returns:
            str: 文件访问 URL

        Raises:
            OSSException: 上传失败时抛出
        """
        # 便捷方法：内部调用 upload_request
        request = OSSUploadRequest(data=file_path, file_name=file_name)
        options = OSSUploadOptions()  # 使用默认选项（永久链接，自动分片）
        response = await self.upload_request(request, options)
        return response.url

    async def upload_file(
        self,
        file_path: str | Path,
        file_name: Optional[str] = None,
        content_type: Optional[str] = None,
        metadata: Optional[Dict[str, str]] = None,
        options: Optional[OSSUploadOptions] = None,
    ) -> OSSUploadResponse:
        """
        便捷方法：从文件路径上传

        Args:
            file_path: 本地文件路径
            file_name: 文件名称（可选，默认使用文件原名）
            content_type: Content-Type（可选，自动推断）
            metadata: 元数据（可选）
            options: 上传选项配置（可选）

        Returns:
            OSSUploadResponse: 上传响应

        Raises:
            OSSException: 上传失败时抛出
        """
        file_path = Path(file_path)
        if not file_path.exists():
            raise OSSInvalidParameterError(f"文件不存在: {file_path}")

        file_name = file_name or file_path.name
        metadata = metadata or {}

        request = OSSUploadRequest(
            data=file_path,
            file_name=file_name,
            content_type=content_type,
            metadata=metadata,
        )

        options = options or OSSUploadOptions()

        # 总是使用 Request API，让子类实现来处理URL类型选择和自动分片上传
        # 这样可以确保 options.url_type 等选项能够正确应用
        return await self.upload_request(request, options)

    async def upload_bytes(
        self,
        data: bytes,
        file_name: str,
        content_type: Optional[str] = None,
        metadata: Optional[Dict[str, str]] = None,
        options: Optional[OSSUploadOptions] = None,
    ) -> OSSUploadResponse:
        """
        便捷方法：上传字节数据

        Args:
            data: 文件数据（字节）
            file_name: 文件名称
            content_type: Content-Type（可选）
            metadata: 元数据（可选）
            options: 上传选项配置（可选）

        Returns:
            OSSUploadResponse: 上传响应

        Raises:
            OSSException: 上传失败时抛出
        """
        request = OSSUploadRequest(
            data=data,
            file_name=file_name,
            content_type=content_type,
            metadata=metadata or {},
        )
        return await self.upload_request(request, options)

    async def download(
        self, file_name: str, local_path: Optional[str | Path] = None
    ) -> bytes:
        """
        下载文件（可选实现）

        Args:
            file_name: 文件名称
            local_path: 本地保存路径（可选，如果提供则保存到文件）

        Returns:
            bytes: 文件数据

        Raises:
            OSSException: 下载失败时抛出
            NotImplementedError: 如果提供商不支持下载
        """
        raise NotImplementedError(f"{self.get_provider_name()} 不支持下载文件")

    async def delete(self, file_name: str) -> bool:
        """
        删除文件（可选实现）

        Args:
            file_name: 文件名称

        Returns:
            bool: 是否删除成功

        Raises:
            OSSException: 删除失败时抛出
            NotImplementedError: 如果提供商不支持删除
        """
        raise NotImplementedError(f"{self.get_provider_name()} 不支持删除文件")

    async def exists(self, file_name: str) -> bool:
        """
        检查文件是否存在（可选实现）

        Args:
            file_name: 文件名称

        Returns:
            bool: 文件是否存在

        Raises:
            OSSException: 检查失败时抛出
            NotImplementedError: 如果提供商不支持检查文件存在
        """
        raise NotImplementedError(f"{self.get_provider_name()} 不支持检查文件存在")

    async def get_metadata(self, file_name: str) -> OSSFileMetadata:
        """
        获取文件元数据（可选实现）

        Args:
            file_name: 文件名称

        Returns:
            OSSFileMetadata: 文件元数据

        Raises:
            OSSException: 获取失败时抛出
            NotImplementedError: 如果提供商不支持获取元数据
        """
        raise NotImplementedError(f"{self.get_provider_name()} 不支持获取文件元数据")

    async def list_files(
        self, prefix: str = "", max_keys: int = 100
    ) -> OSSListResponse:
        """
        列出文件（可选实现）

        Args:
            prefix: 文件前缀（可选，用于过滤）
            max_keys: 返回的最大数量（默认100）

        Returns:
            OSSListResponse: 文件列表响应

        Raises:
            OSSException: 列出失败时抛出
            NotImplementedError: 如果提供商不支持列出文件
        """
        raise NotImplementedError(f"{self.get_provider_name()} 不支持列出文件")

    async def generate_presigned_url(
        self,
        file_name: str,
        method: str = "GET",
        expires: int = 3600,
        content_type: Optional[str] = None,
    ) -> str:
        """
        生成预签名 URL（可选实现）

        Args:
            file_name: 文件名称
            method: HTTP 方法（GET/PUT/DELETE，默认GET）
            expires: 过期时间（秒，默认3600）
            content_type: Content-Type（可选，用于PUT方法）

        Returns:
            str: 预签名 URL

        Raises:
            OSSException: 生成失败时抛出
            NotImplementedError: 如果提供商不支持预签名URL
        """
        raise NotImplementedError(f"{self.get_provider_name()} 不支持生成预签名URL")

    @classmethod
    @abstractmethod
    def describe(cls) -> Dict[str, Any]:
        """获取提供商描述信息（自描述能力）

        Returns:
            包含以下字段的字典：
            - provider_name: 提供商名称
            - display_name: 显示名称
            - description: 描述
            - required_init_params: 必填创建参数 {参数名: {type, description, env_var?, example?}}
            - optional_init_params: 可选创建参数 {参数名: {type, description, default}}
            - supported_features: 支持的功能列表
            - example: 完整示例

        Example:
            >>> from soulshell_base.oss.providers.oss_ali import OSSProviderALi
            >>> info = OSSProviderALi.describe()
            >>> print(info['required_init_params'])
            {'access_key_id': {'type': 'str', 'description': 'Access Key ID', ...}}
        """

    def validate_config(self) -> bool:
        """
        验证配置参数（可重写）

        Returns:
            bool: 配置是否有效
        """
        # 检查必需配置
        for key in self.REQUIRED_CONFIG:
            if key not in self.config or not self.config[key]:
                self.logger.error(f"缺少必需配置: {key}")
                return False

        # 设置可选配置的默认值
        for key, default_value in self.OPTIONAL_CONFIG.items():
            if key not in self.config:
                self.config[key] = default_value

        return True

    def validate_request(self, request: OSSUploadRequest) -> None:
        """
        验证请求参数（可重写）

        Args:
            request: 上传请求参数

        Raises:
            OSSInvalidParameterError: 参数无效
        """
        if not request.file_name:
            raise OSSInvalidParameterError("file_name 不能为空")
        # 对于OSSUploadRequest，还需要检查data字段
        if isinstance(request, OSSUploadRequest) and not request.data:
            raise OSSInvalidParameterError("data 不能为空")
