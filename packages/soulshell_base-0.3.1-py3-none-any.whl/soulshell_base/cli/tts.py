"""
TTS 批量测试脚本

从指定的 txt 文件和配置文件中读取内容，批量生成音频并输出统计 CSV。

使用方法:
    # 模块调用
    python -m soulshell_base.cli.tts --text-file texts.txt --config tts_config.json

    # 指定输出目录
    python -m soulshell_base.cli.tts --text-file texts.txt --config tts_config.json --output-dir ./my_output

    # 显示详细日志
    python -m soulshell_base.cli.tts --text-file texts.txt --config tts_config.json -v

配置文件格式 (JSON):
{
    "provider_name": "volcengine_v1",
    "appid": "${VOLCENGINE_V1_APPID}",
    "token": "${VOLCENGINE_V1_TOKEN}",
    "voice_id": "BV700_streaming",
    "encoding": "mp3",
    "sample_rate": 24000
}

文本文件格式 (每行一条文本):
    你好，这是第一条测试文本。
    欢迎使用语音合成服务。
    这是第三条测试内容。
"""

import argparse
import asyncio
import csv
from dataclasses import dataclass
import json
import logging
import os
from pathlib import Path
import re
import sys
import time
from typing import Any

from dotenv import load_dotenv

from soulshell_base.tts import (
    AudioEncoding,
    TTSException,
    TTSFactory,
    TTSSynthesizeRequest,
)

# 加载环境变量
load_dotenv(Path.cwd() / ".env")

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


# =============================================================================
# 数据模型
# =============================================================================


@dataclass
class TTSTestResult:
    """TTS 测试结果"""

    recognized_text: str
    audio_file: str
    duration: float  # 音频时长（秒）
    file_size: int  # 文件大小（字节）
    synthesis_time: float  # 合成耗时（秒）
    success: bool
    error_message: str = ""


@dataclass
class TTSTaskItem:
    """TTS 任务项，记录文本顺序和执行结果"""

    index: int  # 原始顺序（从 1 开始）
    text: str  # 待合成文本
    result: TTSTestResult | None = None  # 执行结果（执行前为 None）

    @property
    def text_preview(self) -> str:
        """文本预览（前30字符）"""
        if len(self.text) > 30:
            return self.text[:30] + "..."
        return self.text

    @property
    def is_completed(self) -> bool:
        """是否已完成"""
        return self.result is not None


# =============================================================================
# 工具函数
# =============================================================================


def resolve_env_var(value: str) -> str | None:
    """
    解析环境变量引用

    支持格式:
    - ${VAR_NAME} - 必需的环境变量
    - ${VAR_NAME:default_value} - 可选的环境变量，带默认值
    """
    if not isinstance(value, str):
        return value

    # 使用字符类 [$] 匹配美元符号，避免转义问题
    pattern = r"[$][{]([^:}]+)(?::([^}]*))?[}]"
    match = re.match(pattern, value)

    if match:
        var_name = match.group(1)
        default_value = match.group(2)

        env_value = os.getenv(var_name)
        if env_value:
            return env_value
        if default_value is not None:
            return default_value
        return None

    return value


def resolve_dict(data: dict[str, Any]) -> dict[str, Any]:
    """递归解析字典中的所有环境变量"""
    result = {}
    for key, value in data.items():
        if isinstance(value, dict):
            result[key] = resolve_dict(value)
        elif isinstance(value, list):
            result[key] = [
                resolve_env_var(v) if isinstance(v, str) else v for v in value
            ]
        elif isinstance(value, str):
            resolved = resolve_env_var(value)
            if resolved is not None:
                result[key] = resolved
        else:
            result[key] = value
    return result


def load_config(config_path: Path) -> dict[str, Any]:
    """加载并解析配置文件"""
    if not config_path.exists():
        raise FileNotFoundError(f"配置文件不存在: {config_path}")

    with open(config_path, encoding="utf-8") as f:
        config = json.load(f)

    # 解析环境变量
    return resolve_dict(config)


def load_texts(text_file: Path) -> list[str]:
    """加载文本文件，每行一条文本"""
    if not text_file.exists():
        raise FileNotFoundError(f"文本文件不存在: {text_file}")

    with open(text_file, encoding="utf-8") as f:
        lines = f.readlines()

    # 过滤空行和注释行
    texts = []
    for _line in lines:
        line = _line.strip()
        if line and not line.startswith("#"):
            texts.append(line)

    return texts


def get_audio_duration(audio_data: bytes, encoding: str) -> float:
    """
    估算音频时长

    注意: 这是一个简化的估算方法。对于精确的时长，
    建议使用专业的音频处理库如 pydub 或 mutagen。
    """
    # 如果 TTS 响应中包含时长，优先使用
    # 这里提供一个基于文件大小的粗略估算
    # MP3: 约 128kbps = 16KB/s
    # WAV: 约 16000Hz * 16bit * 1ch = 32KB/s
    size_kb = len(audio_data) / 1024

    if encoding.lower() == "mp3":
        return size_kb / 16  # 粗略估算
    if encoding.lower() == "wav":
        return size_kb / 32
    return size_kb / 16  # 默认按 MP3 估算


def write_csv_report(
    task_items: list[TTSTaskItem],
    output_path: Path,
    config: dict[str, Any],
) -> None:
    """写入 CSV 统计报告"""
    with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)

        # 写入配置信息作为注释
        writer.writerow(["# TTS 测试报告"])
        writer.writerow([f"# 供应商: {config.get('provider_name', 'unknown')}"])
        writer.writerow([f"# 生成时间: {time.strftime('%Y-%m-%d %H:%M:%S')}"])
        writer.writerow([])

        # 写入表头
        writer.writerow(
            [
                "序号",
                "文本内容",
                "音频文件",
                "音频时长(秒)",
                "文件大小(字节)",
                "合成耗时(秒)",
                "状态",
                "错误信息",
            ]
        )

        # 写入数据（按 index 顺序）
        for task in task_items:
            result = task.result
            if result:
                writer.writerow(
                    [
                        task.index,
                        task.text,
                        result.audio_file,
                        f"{result.duration:.2f}",
                        result.file_size,
                        f"{result.synthesis_time:.2f}",
                        "成功" if result.success else "失败",
                        result.error_message,
                    ]
                )
            else:
                writer.writerow(
                    [
                        task.index,
                        task.text,
                        "",
                        "",
                        "",
                        "",
                        "未执行",
                        "",
                    ]
                )

        # 写入统计摘要
        writer.writerow([])
        completed_tasks = [t for t in task_items if t.result]
        success_count = sum(1 for t in completed_tasks if t.result and t.result.success)
        total_count = len(task_items)
        total_duration = sum(
            t.result.duration for t in completed_tasks if t.result and t.result.success
        )
        total_size = sum(
            t.result.file_size for t in completed_tasks if t.result and t.result.success
        )
        total_time = sum(t.result.synthesis_time for t in completed_tasks if t.result)

        writer.writerow(["# 统计摘要"])
        writer.writerow([f"# 总数: {total_count}"])
        writer.writerow([f"# 成功: {success_count}"])
        writer.writerow([f"# 失败: {total_count - success_count}"])
        writer.writerow([f"# 总音频时长: {total_duration:.2f} 秒"])
        writer.writerow([f"# 总文件大小: {total_size:,} 字节"])
        writer.writerow([f"# 总合成耗时: {total_time:.2f} 秒"])


# =============================================================================
# TTS 测试核心
# =============================================================================


async def synthesize_single(
    tts,
    task: TTSTaskItem,
    request_params: dict[str, Any],
    output_dir: Path,
    encoding: str,
) -> TTSTestResult:
    """合成单条文本"""
    start_time = time.time()

    try:
        # 创建请求
        request = TTSSynthesizeRequest(text=task.text, **request_params)

        # 执行合成
        response = await tts.synthesize(request)
        synthesis_time = time.time() - start_time

        if not response.is_success:
            return TTSTestResult(
                recognized_text=task.text,
                audio_file="",
                duration=0,
                file_size=0,
                synthesis_time=synthesis_time,
                success=False,
                error_message=response.error_message or "未知错误",
            )

        # 保存音频文件
        audio_filename = f"{task.index:04d}.{encoding}"
        audio_path = output_dir / audio_filename
        audio_path.write_bytes(response.audio_data)

        # 获取音频时长
        duration = response.duration or get_audio_duration(
            response.audio_data, encoding
        )

        return TTSTestResult(
            recognized_text=task.text,
            audio_file=audio_filename,
            duration=duration,
            file_size=len(response.audio_data),
            synthesis_time=synthesis_time,
            success=True,
        )

    except Exception as e:
        synthesis_time = time.time() - start_time
        return TTSTestResult(
            recognized_text=task.text,
            audio_file="",
            duration=0,
            file_size=0,
            synthesis_time=synthesis_time,
            success=False,
            error_message=str(e),
        )


async def run_tts_test(
    texts: list[str],
    config: dict[str, Any],
    output_dir: Path,
    concurrency: int = 5,
) -> list[TTSTaskItem]:
    """运行 TTS 批量测试（并行执行，控制并发数）"""
    # 提取 TTS 创建参数
    provider_name = config.pop("provider_name")

    # 提取请求参数
    request_params = {"extra_params": {}}
    for key in ["voice_id", "language", "speed", "pitch", "volume", "sample_rate"]:
        if key in config:
            request_params[key] = config.pop(key)
    # 特殊字段
    for key in ["emotion_scale", "context_texts"]:
        request_params["extra_params"][key] = config.pop(key)
    # 处理 encoding
    encoding_str = config.pop("encoding", "mp3")
    if isinstance(encoding_str, str):
        request_params["encoding"] = getattr(
            AudioEncoding, encoding_str.upper(), AudioEncoding.MP3
        )
        encoding = encoding_str.lower()
    else:
        encoding = "mp3"

    # 创建 TTS 实例
    logger.info(f"创建 TTS 实例: {provider_name}")
    tts = TTSFactory.create(provider_name=provider_name, **config)

    # 创建输出目录
    output_dir.mkdir(parents=True, exist_ok=True)

    # 创建任务列表，记录原始顺序
    task_items = [TTSTaskItem(index=i, text=text) for i, text in enumerate(texts, 1)]

    # 并行批量合成（使用信号量控制并发数）
    total = len(task_items)
    logger.info(f"开始并行合成 {total} 条文本（并发数: {concurrency}）...")

    semaphore = asyncio.Semaphore(concurrency)

    async def synthesize_with_limit(task: TTSTaskItem) -> TTSTaskItem:
        async with semaphore:
            result = await synthesize_single(
                tts=tts,
                task=task,
                request_params=request_params,
                output_dir=output_dir,
                encoding=encoding,
            )
            task.result = result

            # 每完成一条立即打印日志
            if result.success:
                logger.info(
                    f"[{task.index}/{total}] ✓ {task.text_preview} - "
                    f"时长: {result.duration:.2f}s, 大小: {result.file_size:,} bytes"
                )
            else:
                logger.error(
                    f"[{task.index}/{total}] ✗ {task.text_preview} - {result.error_message}"
                )

            return task

    # 创建所有合成任务
    tasks = [synthesize_with_limit(task) for task in task_items]

    # 并行执行所有任务
    await asyncio.gather(*tasks)

    # 按 index 排序，保持原始文件顺序（返回结果用于报告）
    task_items.sort(key=lambda t: t.index)

    return task_items


# =============================================================================
# 主程序
# =============================================================================


def main():
    """主函数"""
    parser = argparse.ArgumentParser(
        description="TTS 批量测试脚本",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python -m soulshell_base.cli.tts --text-file texts.txt --config tts_config.json
  python -m soulshell_base.cli.tts --text-file texts.txt --config tts_config.json --output-dir ./output
  python -m soulshell_base.cli.tts --text-file texts.txt --config tts_config.json -v
        """,
    )

    parser.add_argument(
        "--text-file",
        type=Path,
        required=True,
        help="文本文件路径，每行一条待合成的文本",
    )
    parser.add_argument(
        "--config",
        type=Path,
        required=True,
        help="TTS 配置文件路径 (JSON 格式)",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("output"),
        help="输出目录 (默认: ./output)",
    )
    parser.add_argument(
        "--csv-output",
        type=Path,
        help="CSV 报告输出路径 (默认: <output-dir>/report.csv)",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="显示详细日志",
    )
    parser.add_argument(
        "-c",
        "--concurrency",
        type=int,
        default=5,
        help="并发数 (默认: 5)",
    )

    args = parser.parse_args()

    # 设置日志级别
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    # 加载配置和文本
    try:
        config = load_config(args.config)
        texts = load_texts(args.text_file)
    except FileNotFoundError as e:
        logger.error(str(e))
        sys.exit(1)

    if not texts:
        logger.error("文本文件为空")
        sys.exit(1)

    logger.info(f"加载了 {len(texts)} 条文本")
    logger.info(f"供应商: {config.get('provider_name', 'unknown')}")
    logger.info(f"输出目录: {args.output_dir.absolute()}")

    # 运行测试
    async def _run():
        try:
            task_items = await run_tts_test(
                texts=texts,
                config=config.copy(),
                output_dir=args.output_dir,
                concurrency=args.concurrency,
            )
        except TTSException as e:
            logger.error(f"TTS 错误: {e}")
            sys.exit(1)
        except ImportError as e:
            logger.error(f"导入错误: {e}")
            logger.error("请确保已安装对应的 TTS 供应商依赖")
            sys.exit(1)

        # 生成报告
        csv_path = args.csv_output or (args.output_dir / "report.csv")
        write_csv_report(task_items, csv_path, config)
        logger.info(f"CSV 报告已保存: {csv_path.absolute()}")

        # 打印摘要
        completed_tasks = [t for t in task_items if t.result]
        success_count = sum(1 for t in completed_tasks if t.result and t.result.success)
        total_count = len(task_items)
        total_duration = sum(
            t.result.duration for t in completed_tasks if t.result and t.result.success
        )
        total_size = sum(
            t.result.file_size for t in completed_tasks if t.result and t.result.success
        )

        print("\n" + "=" * 60)
        print("TTS 测试完成")
        print("=" * 60)
        print(f"  总数: {total_count}")
        print(f"  成功: {success_count}")
        print(f"  失败: {total_count - success_count}")
        print(f"  总音频时长: {total_duration:.2f} 秒")
        print(f"  总文件大小: {total_size:,} 字节 ({total_size / 1024:.1f} KB)")
        print(f"  输出目录: {args.output_dir.absolute()}")
        print(f"  CSV 报告: {csv_path.absolute()}")
        print("=" * 60)

    asyncio.run(_run())


if __name__ == "__main__":
    main()
