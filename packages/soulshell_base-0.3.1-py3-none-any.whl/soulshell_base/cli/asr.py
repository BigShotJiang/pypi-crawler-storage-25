"""
ASR 批量测试脚本

从指定目录读取所有音频文件，使用配置的 ASR 供应商进行识别，输出结果到 CSV 文件。

使用方法:
    # 模块调用
    python -m soulshell_base.cli.asr --audio-dir ./audio_files --config asr_config.json

    # 指定输出 CSV 文件
    python -m soulshell_base.cli.asr --audio-dir ./audio_files --config asr_config.json --output result.csv

    # 显示详细日志
    python -m soulshell_base.cli.asr --audio-dir ./audio_files --config asr_config.json -v

配置文件格式 (JSON):
{
    "provider_name": "volcengine",
    "token": "${VOLCENGINE_ASR_TOKEN}",
    "appid": "${VOLCENGINE_ASR_APPID}",
    "cluster": "volcengine_streaming_common",
    "sample_rate": 16000
}

支持的音频格式:
    - .wav
    - .mp3
    - .pcm
    - .ogg
"""

import argparse
import asyncio
import csv
from dataclasses import dataclass
import json
import logging
import os
from pathlib import Path
import re
import sys
import time
from typing import Any

from dotenv import load_dotenv

from soulshell_base.asr import (
    ASRException,
    ASRFactory,
    ASRRecognizeRequest,
    AudioFormat,
)

# 加载环境变量
load_dotenv(Path.cwd() / ".env")

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

# 支持的音频格式映射
AUDIO_FORMAT_MAP = {
    ".wav": AudioFormat.WAV,
    ".mp3": AudioFormat.MP3,
    ".pcm": AudioFormat.PCM,
    ".ogg": AudioFormat.OGG,
}


# =============================================================================
# 数据模型
# =============================================================================


@dataclass
class ASRTestResult:
    """ASR 测试结果"""

    recognized_text: str
    confidence: float | None
    recognition_time: float  # 识别耗时（秒）
    audio_duration: float | None  # 音频时长（秒）
    success: bool
    error_message: str = ""


@dataclass
class ASRTaskItem:
    """ASR 任务项，记录文件顺序和执行结果"""

    index: int  # 原始顺序（从 1 开始）
    audio_file: Path  # 音频文件路径
    result: ASRTestResult | None = None  # 执行结果（执行前为 None）

    @property
    def audio_name(self) -> str:
        """音频文件名"""
        return self.audio_file.name

    @property
    def is_completed(self) -> bool:
        """是否已完成"""
        return self.result is not None


# =============================================================================
# 工具函数
# =============================================================================


def resolve_env_var(value: str) -> str | None:
    """
    解析环境变量引用

    支持格式:
    - ${VAR_NAME} - 必需的环境变量
    - ${VAR_NAME:default_value} - 可选的环境变量，带默认值
    """
    if not isinstance(value, str):
        return value

    # 使用字符类 [$] 匹配美元符号，避免转义问题
    pattern = r"[$][{]([^:}]+)(?::([^}]*))?[}]"
    match = re.match(pattern, value)

    if match:
        var_name = match.group(1)
        default_value = match.group(2)

        env_value = os.getenv(var_name)
        if env_value:
            return env_value
        if default_value is not None:
            return default_value
        return None

    return value


def resolve_dict(data: dict[str, Any]) -> dict[str, Any]:
    """递归解析字典中的所有环境变量"""
    result = {}
    for key, value in data.items():
        if isinstance(value, dict):
            result[key] = resolve_dict(value)
        elif isinstance(value, list):
            result[key] = [
                resolve_env_var(v) if isinstance(v, str) else v for v in value
            ]
        elif isinstance(value, str):
            resolved = resolve_env_var(value)
            if resolved is not None:
                result[key] = resolved
        else:
            result[key] = value
    return result


def load_config(config_path: Path) -> dict[str, Any]:
    """加载并解析配置文件"""
    if not config_path.exists():
        raise FileNotFoundError(f"配置文件不存在: {config_path}")

    with open(config_path, encoding="utf-8") as f:
        config = json.load(f)

    # 解析环境变量
    return resolve_dict(config)


def find_audio_files(audio_dir: Path) -> list[Path]:
    """查找目录中的所有音频文件"""
    if not audio_dir.exists():
        raise FileNotFoundError(f"音频目录不存在: {audio_dir}")

    audio_files = []
    for ext in AUDIO_FORMAT_MAP:
        audio_files.extend(audio_dir.glob(f"*{ext}"))

    # 按文件名排序
    audio_files.sort(key=lambda p: p.name)
    return audio_files


def get_audio_format(file_path: Path) -> AudioFormat:
    """根据文件扩展名获取音频格式"""
    ext = file_path.suffix.lower()
    if ext in AUDIO_FORMAT_MAP:
        return AUDIO_FORMAT_MAP[ext]
    raise ValueError(f"不支持的音频格式: {ext}")

def _format_ext(fmt: AudioFormat) -> str:
    m = {
        AudioFormat.WAV: "wav",
        AudioFormat.MP3: "mp3",
        AudioFormat.PCM: "pcm",
        AudioFormat.OGG: "ogg",
    }
    return m.get(fmt, str(fmt).lower())

def _extract_task_id(metadata: dict[str, Any] | None) -> str:
    return metadata.get("task_id", f"local-{int(time.time()*1000)}")

def _save_audio(
    audio_bytes: bytes,
    fmt: AudioFormat,
    task_id: str,
    sample_rate: int | None = None,
    channels: int | None = None,
    bits: int | None = None,
) -> Path:
    base_dir = Path("output") / "asr_result"
    base_dir.mkdir(parents=True, exist_ok=True)
    ext = _format_ext(fmt)
    out_path = base_dir / f"{task_id}.{ext}"
    if fmt == AudioFormat.WAV:
        import wave
        sr = sample_rate or 16000
        ch = channels or 1
        bw = (bits or 16) // 8
        with wave.open(str(out_path), "wb") as wf:
            wf.setnchannels(ch)
            wf.setsampwidth(bw)
            wf.setframerate(sr)
            wf.writeframes(audio_bytes)
    else:
        out_path.write_bytes(audio_bytes)
    return out_path


def write_csv_report(
    task_items: list[ASRTaskItem],
    output_path: Path,
    config: dict[str, Any],
) -> None:
    """写入 CSV 统计报告"""
    with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)

        # 写入配置信息作为注释
        writer.writerow(["# ASR 测试报告"])
        writer.writerow([f"# 供应商: {config.get('provider_name', 'unknown')}"])
        writer.writerow([f"# 生成时间: {time.strftime('%Y-%m-%d %H:%M:%S')}"])
        writer.writerow([])

        # 写入表头
        writer.writerow(
            [
                "序号",
                "音频文件",
                "识别结果",
                "置信度",
                "识别耗时(秒)",
                "音频时长(秒)",
                "状态",
                "错误信息",
            ]
        )

        # 写入数据（按 index 顺序）
        for task in task_items:
            result = task.result
            if result:
                writer.writerow(
                    [
                        task.index,
                        task.audio_name,
                        result.recognized_text,
                        f"{result.confidence:.2f}" if result.confidence else "",
                        f"{result.recognition_time:.2f}",
                        f"{result.audio_duration:.2f}" if result.audio_duration else "",
                        "成功" if result.success else "失败",
                        result.error_message,
                    ]
                )
            else:
                writer.writerow(
                    [
                        task.index,
                        task.audio_name,
                        "",
                        "",
                        "",
                        "",
                        "未执行",
                        "",
                    ]
                )

        # 写入统计摘要
        writer.writerow([])
        completed_tasks = [t for t in task_items if t.result]
        success_count = sum(1 for t in completed_tasks if t.result and t.result.success)
        total_count = len(task_items)
        total_time = sum(t.result.recognition_time for t in completed_tasks if t.result)
        total_audio_duration = sum(
            t.result.audio_duration
            for t in completed_tasks
            if t.result and t.result.success and t.result.audio_duration
        )

        writer.writerow(["# 统计摘要"])
        writer.writerow([f"# 总数: {total_count}"])
        writer.writerow([f"# 成功: {success_count}"])
        writer.writerow([f"# 失败: {total_count - success_count}"])
        writer.writerow([f"# 总音频时长: {total_audio_duration:.2f} 秒"])
        writer.writerow([f"# 总识别耗时: {total_time:.2f} 秒"])


# =============================================================================
# ASR 测试核心
# =============================================================================


async def recognize_single(
    asr,
    task: ASRTaskItem,
    request_params: dict[str, Any],
) -> ASRTestResult:
    """识别单个音频文件"""
    start_time = time.time()

    try:
        # 读取音频数据
        audio_data = task.audio_file.read_bytes()

        # 获取音频格式
        audio_format = get_audio_format(task.audio_file)

        # 创建请求
        request = ASRRecognizeRequest(
            audio_data=audio_data,
            audio_format=audio_format,
            **request_params,
        )

        # 执行识别
        response = await asr.recognize(request)
        recognition_time = time.time() - start_time

        if not response.is_success:
            return ASRTestResult(
                recognized_text="",
                confidence=None,
                recognition_time=recognition_time,
                audio_duration=None,
                success=False,
                error_message=response.error_message or "未知错误",
            )

        return ASRTestResult(
            recognized_text=response.text or "",
            confidence=response.confidence,
            recognition_time=recognition_time,
            audio_duration=response.duration,
            success=True,
        )

    except Exception as e:
        recognition_time = time.time() - start_time
        return ASRTestResult(
            recognized_text="",
            confidence=None,
            recognition_time=recognition_time,
            audio_duration=None,
            success=False,
            error_message=str(e),
        )


async def run_asr_test(
    audio_files: list[Path],
    config: dict[str, Any],
    concurrency: int = 5,
) -> list[ASRTaskItem]:
    """运行 ASR 批量测试（并行执行，控制并发数）"""
    # 提取 ASR 创建参数
    provider_name = config.pop("provider_name")

    # 提取请求参数
    request_params = {}
    for key in ["language", "sample_rate", "bits", "channel"]:
        if key in config:
            request_params[key] = config.pop(key)

    # 创建 ASR 实例
    logger.info(f"创建 ASR 实例: {provider_name}")
    asr = ASRFactory.create(provider_name=provider_name, **config)

    # 创建任务列表，记录原始顺序
    task_items = [
        ASRTaskItem(index=i, audio_file=audio_file)
        for i, audio_file in enumerate(audio_files, 1)
    ]

    # 并行批量识别（使用信号量控制并发数）
    total = len(task_items)
    logger.info(f"开始并行识别 {total} 个音频文件（并发数: {concurrency}）...")

    semaphore = asyncio.Semaphore(concurrency)

    async def recognize_with_limit(task: ASRTaskItem) -> ASRTaskItem:
        async with semaphore:
            result = await recognize_single(
                asr=asr,
                task=task,
                request_params=request_params,
            )
            task.result = result

            # 每完成一条立即打印日志
            if result.success:
                text_preview = result.recognized_text[:50]
                if len(result.recognized_text) > 50:
                    text_preview += "..."
                logger.info(
                    f"[{task.index}/{total}] ✓ {task.audio_name} - {text_preview}"
                )
            else:
                logger.error(
                    f"[{task.index}/{total}] ✗ {task.audio_name} - {result.error_message}"
                )

            return task

    # 创建所有识别任务
    tasks = [recognize_with_limit(task) for task in task_items]

    # 并行执行所有任务
    await asyncio.gather(*tasks)

    # 按 index 排序，保持原始文件顺序（返回结果用于报告）
    task_items.sort(key=lambda t: t.index)

    return task_items


# =============================================================================
# 主程序
# =============================================================================


def main():
    """主函数"""
    parser = argparse.ArgumentParser(
        description="ASR 批量测试脚本",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python -m soulshell_base.cli.test_asr --audio-dir ./audio_files --config asr_config.json
  python -m soulshell_base.cli.test_asr --audio-dir ./audio_files --config asr_config.json --output result.csv
  python -m soulshell_base.cli.test_asr --audio-dir ./audio_files --config asr_config.json -v
        """,
    )

    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument(
        "--audio-dir",
        type=Path,
        help="包含音频文件的目录路径",
    )
    group.add_argument(
        "--mic",
        action="store_true",
        help="使用麦克风进行流式识别",
    )
    parser.add_argument(
        "--config",
        type=Path,
        required=True,
        help="ASR 配置文件路径 (JSON 格式)",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("asr_result.csv"),
        help="CSV 输出文件路径 (默认: ./asr_result.csv)",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="显示详细日志",
    )
    parser.add_argument(
        "-c",
        "--concurrency",
        type=int,
        default=5,
        help="并发数 (默认: 5)",
    )

    args = parser.parse_args()

    # 设置日志级别
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    # 加载配置
    try:
        config = load_config(args.config)
    except FileNotFoundError as e:
        logger.error(str(e))
        sys.exit(1)

    if args.mic:
        async def _run_mic():
            provider_name = config.pop("provider_name")
            sample_rate = int(config.pop("sample_rate", 16000))
            bits = int(config.pop("bits", 16)) if "bits" in config else None
            channel = int(config.pop("channel", 1)) if "channel" in config else None
            logger.info(f"创建 ASR 实例: {provider_name}")
            asr = ASRFactory.create(provider_name=provider_name, **config)

            recorded_chunks: list[bytes] = []
            async def microphone_stream():
                try:
                    from collections import deque
                    import threading
                    import sounddevice as sd
                except Exception as e:
                    raise ImportError("需要安装 sounddevice 库以使用麦克风流式识别") from e

                audio_queue = deque()
                queue_lock = threading.Lock()
                stop_event = threading.Event()

                def _callback(indata, frames, time_info, status):  # noqa: ARG001
                    with queue_lock:
                        audio_queue.append(indata.tobytes())

                stream = sd.InputStream(
                    samplerate=sample_rate,
                    channels=channel or 1,
                    dtype="int16",
                    blocksize=1024,
                    callback=_callback,
                )
                stream.start()
                try:
                    while not stop_event.is_set():
                        chunk = None
                        with queue_lock:
                            if audio_queue:
                                chunk = audio_queue.popleft()
                        if chunk:
                            recorded_chunks.append(chunk)
                            yield chunk
                        else:
                            await asyncio.sleep(0.01)
                finally:
                    try:
                        stream.stop()
                        stream.close()
                    except Exception:
                        pass

            request_kwargs = {
            }
            if bits is not None:
                request_kwargs["bits"] = bits
            if channel is not None:
                request_kwargs["channel"] = channel
            if "enable_voice_detection" in config:
                request_kwargs["enable_voice_detection"] = bool(
                    config.pop("enable_voice_detection")
                )
            enable_intermediate_result = bool(
                config.pop("enable_intermediate_result", True)
            )

            request = ASRRecognizeRequest(
                audio_stream=microphone_stream(),
                audio_format=AudioFormat.WAV,
                sample_rate=sample_rate,
                enable_intermediate_result=enable_intermediate_result,
                enable_voice_detection=request_kwargs.get("enable_voice_detection", True),
                max_end_silence=2000,
                **request_kwargs,
            )

            try:
                logger.info("开始麦克风流式识别，按 Ctrl+C 结束")
                final_resp = None
                async for result in asr.recognize_stream(request):
                    if result.is_success:
                        print(f"[最终] {result.text}")
                        final_resp = result
                    else:
                        print(f"[中间] {result.text}")
                if final_resp:
                    try:
                        task_id = _extract_task_id(final_resp.metadata)
                        out_path = _save_audio(
                            b"".join(recorded_chunks),
                            AudioFormat.WAV,
                            task_id,
                            sample_rate=sample_rate,
                            channels=channel or 1,
                            bits=bits or 16,
                        )
                        logger.info(f"音频已保存: {out_path}")
                    except Exception as e:
                        logger.warning(f"保存麦克风音频失败: {e}")
            except KeyboardInterrupt:
                logger.info("已停止麦克风识别")
            except ImportError as e:
                logger.error(str(e))
                logger.error("请安装: uv pip install sounddevice 或安装 asr-aliyun/asr-xunfei 分组依赖")
                sys.exit(1)
            except ASRException as e:
                logger.error(f"ASR 错误: {e}")
                sys.exit(1)

        asyncio.run(_run_mic())
        return

    try:
        audio_files = find_audio_files(args.audio_dir)
    except FileNotFoundError as e:
        logger.error(str(e))
        sys.exit(1)

    if not audio_files:
        logger.error(f"在目录 {args.audio_dir} 中未找到音频文件")
        logger.info(f"支持的格式: {', '.join(AUDIO_FORMAT_MAP.keys())}")
        sys.exit(1)

    logger.info(f"找到 {len(audio_files)} 个音频文件")
    logger.info(f"供应商: {config.get('provider_name', 'unknown')}")

    # 运行测试
    async def _run():
        try:
            task_items = await run_asr_test(
                audio_files=audio_files,
                config=config.copy(),
                concurrency=args.concurrency,
            )
        except ASRException as e:
            logger.error(f"ASR 错误: {e}")
            sys.exit(1)
        except ImportError as e:
            logger.error(f"导入错误: {e}")
            logger.error("请确保已安装对应的 ASR 供应商依赖")
            sys.exit(1)

        # 生成报告
        write_csv_report(task_items, args.output, config)
        logger.info(f"CSV 报告已保存: {args.output.absolute()}")

        # 打印摘要
        completed_tasks = [t for t in task_items if t.result]
        success_count = sum(1 for t in completed_tasks if t.result and t.result.success)
        total_count = len(task_items)
        total_time = sum(t.result.recognition_time for t in completed_tasks if t.result)
        total_audio_duration = sum(
            t.result.audio_duration
            for t in completed_tasks
            if t.result and t.result.success and t.result.audio_duration
        )

        print("\n" + "=" * 60)
        print("ASR 测试完成")
        print("=" * 60)
        print(f"  总数: {total_count}")
        print(f"  成功: {success_count}")
        print(f"  失败: {total_count - success_count}")
        print(f"  总音频时长: {total_audio_duration:.2f} 秒")
        print(f"  总识别耗时: {total_time:.2f} 秒")
        print(f"  CSV 报告: {args.output.absolute()}")
        print("=" * 60)

    asyncio.run(_run())


if __name__ == "__main__":
    main()
