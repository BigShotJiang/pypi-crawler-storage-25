"""
CLI 工具模块

提供命令行工具用于批量测试 ASR 和 TTS 服务。

使用方法:
    python -m soulshell_base.cli.asr --audio-dir ./audio --config config.json
    python -m soulshell_base.cli.tts --text-file texts.txt --config config.json
    python -m soulshell_base.cli.tts_wakegen --config config.json
"""

__all__ = ["asr_main", "tts_main", "tts_wakegen_main"]


def __getattr__(name: str):
    if name == "asr_main":
        from .asr import main  # noqa: PLC0415

        return main
    if name == "tts_main":
        from .tts import main  # noqa: PLC0415

        return main
    if name == "tts_wakegen_main":
        from .tts_wakegen import main  # noqa: PLC0415

        return main
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
