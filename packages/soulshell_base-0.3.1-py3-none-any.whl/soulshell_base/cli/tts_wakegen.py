"""
唤醒词音频批量生成脚本

为每个唤醒词文本生成多种语速和语调的变体音频文件。

使用方法:
    # 模块调用
    python -m soulshell_base.cli.tts_wakegen --config config.json

    # 指定输出目录
    python -m soulshell_base.cli.tts_wakegen --config config.json --output-dir ./wakewords

    # 使用自定义唤醒词文件
    python -m soulshell_base.cli.tts_wakegen --config config.json --words-file words.txt

配置文件格式 (JSON):
{
    "provider_name": "volcengine_v3",
    "appid": "${VOLCENGINE_V3_APPID}",
    "token": "${VOLCENGINE_V3_TOKEN}",
    "voice_id": "ICL_zh_female_xingganyujie_tob"
}

唤醒词文件格式 (每行一个唤醒词):
    ANSIN
    hello ANSIN
    hey ansin
"""

import argparse
import asyncio
import csv
from dataclasses import dataclass
from itertools import product
import json
import logging
import os
from pathlib import Path
import re
import sys
import time
from typing import Any

from dotenv import load_dotenv

from soulshell_base.tts import (
    AudioEncoding,
    TTSFactory,
    TTSSynthesizeRequest,
)

# 加载环境变量
load_dotenv(Path.cwd() / ".env")

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

# 默认唤醒词
DEFAULT_WAKEWORDS = [
    "ANSIN",
    "hello ANSIN",
    "hey ansin",
]

# 默认语速变体
DEFAULT_SPEEDS = [1.0, 1.1, 1.2]

# 默认语调变体
DEFAULT_PITCHES = [-2, 0, 2]


# =============================================================================
# 数据模型
# =============================================================================


@dataclass
class GenerationResult:
    """生成结果"""

    text: str
    speed: float
    pitch: float
    filename: str
    file_size: int
    duration: float
    synthesis_time: float
    success: bool
    error_message: str = ""


@dataclass
class WakewordTaskItem:
    """唤醒词任务项，记录顺序和执行结果"""

    index: int  # 原始顺序（从 1 开始）
    text: str  # 唤醒词文本
    speed: float  # 语速
    pitch: float  # 音调
    result: GenerationResult | None = None  # 执行结果

    @property
    def is_completed(self) -> bool:
        """是否已完成"""
        return self.result is not None

    def get_filename(self) -> str:
        """生成文件名"""
        safe_text = (
            self.text.replace(" ", "_")
            .replace("你好", "nihao")
            .replace("安芯", "ansin")
        )
        return f"{self.index:04d}_{safe_text}_s{self.speed}_p{self.pitch}.wav"


# =============================================================================
# 工具函数
# =============================================================================


def resolve_env_var(value: str) -> str | None:
    """解析环境变量引用"""
    if not isinstance(value, str):
        return value

    pattern = r"[$][{]([^:}]+)(?::([^}]*))?[}]"
    match = re.match(pattern, value)

    if match:
        var_name = match.group(1)
        default_value = match.group(2)

        env_value = os.getenv(var_name)
        if env_value:
            return env_value
        if default_value is not None:
            return default_value
        return None

    return value


def resolve_dict(data: dict[str, Any]) -> dict[str, Any]:
    """递归解析字典中的所有环境变量"""
    result = {}
    for key, value in data.items():
        if isinstance(value, dict):
            result[key] = resolve_dict(value)
        elif isinstance(value, list):
            result[key] = [
                resolve_env_var(v) if isinstance(v, str) else v for v in value
            ]
        elif isinstance(value, str):
            resolved = resolve_env_var(value)
            if resolved is not None:
                result[key] = resolved
        else:
            result[key] = value
    return result


def load_config(config_path: Path) -> dict[str, Any]:
    """加载并解析配置文件"""
    if not config_path.exists():
        raise FileNotFoundError(f"配置文件不存在: {config_path}")

    with open(config_path, encoding="utf-8") as f:
        config = json.load(f)

    return resolve_dict(config)


def load_wakewords(words_file: Path) -> list[str]:
    """加载唤醒词文件"""
    if not words_file.exists():
        raise FileNotFoundError(f"唤醒词文件不存在: {words_file}")

    with open(words_file, encoding="utf-8") as f:
        lines = f.readlines()

    words = []
    for _line in lines:
        line = _line.strip()
        if line and not line.startswith("#"):
            words.append(line)

    return words


def parse_float_list(value: str) -> list[float]:
    """解析逗号分隔的浮点数列表"""
    return [float(x.strip()) for x in value.split(",")]


def write_csv_report(
    task_items: list[WakewordTaskItem],
    output_path: Path,
    config: dict[str, Any],
) -> None:
    """写入 CSV 报告"""
    with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)

        # 写入表头注释
        writer.writerow(["# 唤醒词音频生成报告"])
        writer.writerow([f"# 供应商: {config.get('provider_name', 'unknown')}"])
        writer.writerow([f"# 生成时间: {time.strftime('%Y-%m-%d %H:%M:%S')}"])
        writer.writerow([])

        # 写入表头
        writer.writerow(
            [
                "序号",
                "文本内容",
                "语速",
                "音调",
                "音频文件",
                "音频时长(秒)",
                "文件大小(字节)",
                "合成耗时(秒)",
                "状态",
                "错误信息",
            ]
        )

        # 写入数据
        for task in task_items:
            result = task.result
            if result:
                writer.writerow(
                    [
                        task.index,
                        task.text,
                        task.speed,
                        task.pitch,
                        result.filename,
                        f"{result.duration:.2f}",
                        result.file_size,
                        f"{result.synthesis_time:.2f}",
                        "成功" if result.success else "失败",
                        result.error_message,
                    ]
                )
            else:
                writer.writerow(
                    [
                        task.index,
                        task.text,
                        task.speed,
                        task.pitch,
                        "",
                        "",
                        "",
                        "",
                        "未执行",
                        "",
                    ]
                )

        # 写入统计摘要
        writer.writerow([])
        completed_tasks = [t for t in task_items if t.result]
        success_count = sum(1 for t in completed_tasks if t.result and t.result.success)
        total_count = len(task_items)
        total_duration = sum(
            t.result.duration for t in completed_tasks if t.result and t.result.success
        )
        total_size = sum(
            t.result.file_size for t in completed_tasks if t.result and t.result.success
        )
        total_time = sum(t.result.synthesis_time for t in completed_tasks if t.result)

        writer.writerow(["# 统计摘要"])
        writer.writerow([f"# 总数: {total_count}"])
        writer.writerow([f"# 成功: {success_count}"])
        writer.writerow([f"# 失败: {total_count - success_count}"])
        writer.writerow([f"# 总音频时长: {total_duration:.2f} 秒"])
        writer.writerow([f"# 总文件大小: {total_size:,} 字节"])
        writer.writerow([f"# 总合成耗时: {total_time:.2f} 秒"])


# =============================================================================
# 唤醒词生成核心
# =============================================================================


async def generate_single(
    tts,
    task: WakewordTaskItem,
    request_params: dict[str, Any],
    output_dir: Path,
) -> GenerationResult:
    """生成单个唤醒词音频"""
    start_time = time.time()
    filename = task.get_filename()
    filepath = output_dir / filename

    try:
        request = TTSSynthesizeRequest(
            text=task.text,
            encoding=AudioEncoding.WAV,
            speed=task.speed,
            pitch=task.pitch,
            **request_params,
        )

        response = await tts.synthesize(request)
        synthesis_time = time.time() - start_time

        if not response.is_success:
            return GenerationResult(
                text=task.text,
                speed=task.speed,
                pitch=task.pitch,
                filename="",
                file_size=0,
                duration=0,
                synthesis_time=synthesis_time,
                success=False,
                error_message=response.error_message or "未知错误",
            )

        # 保存音频文件
        filepath.write_bytes(response.audio_data)
        file_size = len(response.audio_data)
        duration = response.duration or (file_size / (16000 * 2))  # 估算时长

        return GenerationResult(
            text=task.text,
            speed=task.speed,
            pitch=task.pitch,
            filename=filename,
            file_size=file_size,
            duration=duration,
            synthesis_time=synthesis_time,
            success=True,
        )

    except Exception as e:
        synthesis_time = time.time() - start_time
        return GenerationResult(
            text=task.text,
            speed=task.speed,
            pitch=task.pitch,
            filename="",
            file_size=0,
            duration=0,
            synthesis_time=synthesis_time,
            success=False,
            error_message=str(e),
        )


async def run_wakeword_generation(
    wakewords: list[str],
    speeds: list[float],
    pitches: list[float],
    config: dict[str, Any],
    output_dir: Path,
    concurrency: int = 5,
) -> list[WakewordTaskItem]:
    """运行唤醒词批量生成（并行执行，控制并发数）"""
    # 提取 TTS 创建参数
    provider_name = config.pop("provider_name")

    # 提取请求参数
    request_params = {}
    for key in ["voice_id", "sample_rate", "volume"]:
        if key in config:
            request_params[key] = config.pop(key)

    # 设置默认采样率
    if "sample_rate" not in request_params:
        request_params["sample_rate"] = 16000

    # 创建 TTS 实例
    logger.info(f"创建 TTS 实例: {provider_name}")
    tts = TTSFactory.create(provider_name=provider_name, **config)

    # 创建输出目录
    output_dir.mkdir(parents=True, exist_ok=True)

    # 生成所有组合
    combinations = list(product(wakewords, speeds, pitches))
    task_items = [
        WakewordTaskItem(index=i, text=text, speed=speed, pitch=pitch)
        for i, (text, speed, pitch) in enumerate(combinations, 1)
    ]

    # 并行批量生成（使用信号量控制并发数）
    total = len(task_items)
    logger.info(f"开始并行生成 {total} 个音频文件（并发数: {concurrency}）...")

    semaphore = asyncio.Semaphore(concurrency)

    async def generate_with_limit(task: WakewordTaskItem) -> WakewordTaskItem:
        async with semaphore:
            result = await generate_single(
                tts=tts,
                task=task,
                request_params=request_params,
                output_dir=output_dir,
            )
            task.result = result

            # 每完成一条立即打印日志
            if result.success:
                logger.info(
                    f"[{task.index}/{total}] ✓ {task.text} (s={task.speed}, p={task.pitch}) - "
                    f"{result.file_size:,} bytes, {result.duration:.2f}s"
                )
            else:
                logger.error(
                    f"[{task.index}/{total}] ✗ {task.text} (s={task.speed}, p={task.pitch}) - "
                    f"{result.error_message}"
                )

            return task

    # 创建所有生成任务
    tasks = [generate_with_limit(task) for task in task_items]

    # 并行执行所有任务
    await asyncio.gather(*tasks)

    # 按 index 排序
    task_items.sort(key=lambda t: t.index)

    return task_items


# =============================================================================
# 主程序
# =============================================================================


def main():
    """主函数"""
    parser = argparse.ArgumentParser(
        description="唤醒词音频批量生成脚本",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python -m soulshell_base.cli.tts_wakegen --config tts_config.json
  python -m soulshell_base.cli.tts_wakegen --config tts_config.json --output-dir ./wakewords
  python -m soulshell_base.cli.tts_wakegen --config tts_config.json --words-file words.txt
  python -m soulshell_base.cli.tts_wakegen --config tts_config.json --speeds 1.0,1.1,1.2 --pitches -2,0,2
        """,
    )

    parser.add_argument(
        "--config",
        type=Path,
        required=True,
        help="TTS 配置文件路径 (JSON 格式)",
    )
    parser.add_argument(
        "--words-file",
        type=Path,
        help="唤醒词文件路径，每行一个唤醒词（不指定则使用默认唤醒词）",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("output_wakewords"),
        help="输出目录 (默认: ./output_wakewords)",
    )
    parser.add_argument(
        "--speeds",
        type=str,
        default="1.0,1.1,1.2",
        help="语速变体，逗号分隔 (默认: 1.0,1.1,1.2)",
    )
    parser.add_argument(
        "--pitches",
        type=str,
        default="-2,0,2",
        help="音调变体，逗号分隔 (默认: -2,0,2)",
    )
    parser.add_argument(
        "-c",
        "--concurrency",
        type=int,
        default=5,
        help="并发数 (默认: 5)",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="显示详细日志",
    )

    args = parser.parse_args()

    # 设置日志级别
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    # 加载配置
    try:
        config = load_config(args.config)
    except FileNotFoundError as e:
        logger.error(str(e))
        sys.exit(1)

    # 加载唤醒词
    if args.words_file:
        try:
            wakewords = load_wakewords(args.words_file)
        except FileNotFoundError as e:
            logger.error(str(e))
            sys.exit(1)
    else:
        wakewords = DEFAULT_WAKEWORDS

    if not wakewords:
        logger.error("唤醒词列表为空")
        sys.exit(1)

    # 解析语速和音调
    try:
        speeds = parse_float_list(args.speeds)
        pitches = parse_float_list(args.pitches)
    except ValueError as e:
        logger.error(f"解析参数失败: {e}")
        sys.exit(1)

    total_combinations = len(wakewords) * len(speeds) * len(pitches)
    logger.info(f"唤醒词: {len(wakewords)} 个")
    logger.info(f"语速变体: {speeds}")
    logger.info(f"音调变体: {pitches}")
    logger.info(f"总计将生成: {total_combinations} 个音频文件")

    # 运行生成
    async def _run():
        try:
            task_items = await run_wakeword_generation(
                wakewords=wakewords,
                speeds=speeds,
                pitches=pitches,
                config=config.copy(),
                output_dir=args.output_dir,
                concurrency=args.concurrency,
            )
        except Exception as e:
            logger.error(f"生成错误: {e}")
            sys.exit(1)

        # 生成报告
        csv_path = args.output_dir / "report.csv"
        write_csv_report(task_items, csv_path, config)
        logger.info(f"CSV 报告已保存: {csv_path.absolute()}")

        # 打印摘要
        completed_tasks = [t for t in task_items if t.result]
        success_count = sum(1 for t in completed_tasks if t.result and t.result.success)
        total_count = len(task_items)
        total_duration = sum(
            t.result.duration for t in completed_tasks if t.result and t.result.success
        )
        total_size = sum(
            t.result.file_size for t in completed_tasks if t.result and t.result.success
        )

        print("\n" + "=" * 60)
        print("唤醒词音频生成完成")
        print("=" * 60)
        print(f"  总数: {total_count}")
        print(f"  成功: {success_count}")
        print(f"  失败: {total_count - success_count}")
        print(f"  总音频时长: {total_duration:.2f} 秒")
        print(f"  总文件大小: {total_size:,} 字节 ({total_size / 1024 / 1024:.2f} MB)")
        print(f"  输出目录: {args.output_dir.absolute()}")
        print(f"  CSV 报告: {csv_path.absolute()}")
        print("=" * 60)

    asyncio.run(_run())


if __name__ == "__main__":
    main()
