"""
RAG 数据模型
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

# ============ 请求模型 ============


@dataclass
class ChatRequest:
    """对话请求"""

    message: str
    session_id: Optional[str] = None
    stream: bool = False

    # 可覆盖的参数（优先级高于创建阶段的默认值）
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    top_k: Optional[int] = None

    # 业务上下文
    metadata_condition: Optional[Dict[str, Any]] = None
    extra_params: Dict[str, Any] = field(default_factory=dict)


@dataclass
class SearchRequest:
    """检索请求"""

    query: str
    dataset_ids: Optional[List[str]] = None
    document_ids: Optional[List[str]] = None

    top_k: int = 5
    similarity_threshold: float = 0.2
    vector_similarity_weight: float = 0.3

    keyword: bool = False
    highlight: bool = False
    metadata_condition: Optional[Dict[str, Any]] = None


@dataclass
class LLMConfig:
    """LLM 配置"""

    model_name: Optional[str] = None
    temperature: float = 0.1
    top_p: float = 0.3
    presence_penalty: float = 0.4
    frequency_penalty: float = 0.7


@dataclass
class PromptVariable:
    """Prompt 变量"""

    key: str
    optional: bool = True


@dataclass
class PromptConfig:
    """Prompt 配置"""

    similarity_threshold: float = 0.2
    keywords_similarity_weight: float = 0.7
    top_n: int = 6
    variables: List[PromptVariable] = field(
        default_factory=lambda: [PromptVariable(key="knowledge", optional=True)]
    )
    rerank_model: Optional[str] = None
    top_k: int = 1024
    empty_response: Optional[str] = None
    opener: str = "Hi! I am your assistant, can I help you?"
    show_quote: bool = True
    prompt: Optional[str] = None


@dataclass
class AssistantConfig:
    """助手配置
    支持两种用法：
    1. 简单用法：直接传递 LLM 和 Prompt 参数，如 AssistantConfig(name="test", temperature=0.7)
    2. 高级用法：传递完整的配置对象，如 AssistantConfig(name="test", llm=LLMConfig(temperature=0.7))
    """

    name: str
    description: Optional[str] = None
    avatar: Optional[str] = None
    dataset_ids: List[str] = field(default_factory=list)

    # LLM 配置（支持直接传递参数或完整对象）
    llm: Optional[LLMConfig] = None
    model_name: Optional[str] = None
    temperature: Optional[float] = None
    top_p: Optional[float] = None
    presence_penalty: Optional[float] = None
    frequency_penalty: Optional[float] = None

    # Prompt 配置（支持直接传递参数或完整对象）
    prompt: Optional[PromptConfig] = None
    similarity_threshold: Optional[float] = None
    keywords_similarity_weight: Optional[float] = None
    top_n: Optional[int] = None
    variables: Optional[List[PromptVariable]] = None
    rerank_model: Optional[str] = None
    top_k: Optional[int] = None
    empty_response: Optional[str] = None
    opener: Optional[str] = None
    show_quote: Optional[bool] = None
    prompt_text: Optional[str] = None

    def __post_init__(self):
        """初始化后处理：自动构建 LLM 和 Prompt 配置对象"""
        # 构建 LLM 配置
        llm_params = {
            "model_name": self.model_name,
            "temperature": self.temperature,
            "top_p": self.top_p,
            "presence_penalty": self.presence_penalty,
            "frequency_penalty": self.frequency_penalty,
        }
        # 如果传入了任何 LLM 参数，构建 LLMConfig 对象
        if any(v is not None for v in llm_params.values()):
            if self.llm is None:
                self.llm = LLMConfig(
                    **{k: v for k, v in llm_params.items() if v is not None}
                )
            else:
                # 如果已有 llm 对象，合并参数
                for k, v in llm_params.items():
                    if v is not None:
                        setattr(self.llm, k, v)

        # 构建 Prompt 配置
        prompt_params = {
            "similarity_threshold": self.similarity_threshold,
            "keywords_similarity_weight": self.keywords_similarity_weight,
            "top_n": self.top_n,
            "variables": self.variables,
            "rerank_model": self.rerank_model,
            "top_k": self.top_k,
            "empty_response": self.empty_response,
            "opener": self.opener,
            "show_quote": self.show_quote,
            "prompt": self.prompt_text,
        }
        # 如果传入了任何 Prompt 参数，构建 PromptConfig 对象
        if any(v is not None for v in prompt_params.values()):
            if self.prompt is None:
                self.prompt = PromptConfig(
                    **{k: v for k, v in prompt_params.items() if v is not None}
                )
            else:
                # 如果已有 prompt 对象，合并参数
                for k, v in prompt_params.items():
                    if v is not None:
                        setattr(self.prompt, k, v)


# ============ 响应模型 ============


@dataclass
class SourceInfo:
    """来源信息"""

    content: str
    similarity: float
    document_id: str
    chunk_id: str
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class UsageInfo:
    """使用情况"""

    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


@dataclass
class ChatResponse:
    """对话响应"""

    content: str
    session_id: str
    message_id: str

    sources: List[SourceInfo] = field(default_factory=list)
    usage: Optional[UsageInfo] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class SearchResult:
    """检索结果"""

    content: str
    score: float
    document_id: str
    chunk_id: str
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Assistant:
    """助手信息"""

    id: str
    name: str
    description: Optional[str]
    dataset_ids: List[str]
    created_at: str


@dataclass
class Session:
    """会话信息"""

    id: str
    name: str
    assistant_id: str
    user_id: Optional[str]
    created_at: str


@dataclass
class DatasetConfig:
    """数据集配置"""

    name: str
    description: Optional[str] = None
    avatar: Optional[str] = None
    embedding_model: Optional[str] = None
    permission: Optional[str] = None
    chunk_method: Optional[str] = None
    parser_config: Optional[Dict[str, Any]] = None
    parse_type: Optional[int] = None
    pipeline_id: Optional[str] = None


@dataclass
class Dataset:
    """数据集信息"""

    id: str
    name: str
    description: Optional[str]
    chunk_method: Optional[str]
    chunk_count: int
    document_count: int
    embedding_model: Optional[str]
    created_at: str


@dataclass
class DatasetUpdateConfig:
    """数据集更新配置"""

    name: Optional[str] = None
    description: Optional[str] = None
    avatar: Optional[str] = None
    permission: Optional[str] = None
    chunk_method: Optional[str] = None
    parser_config: Optional[Dict[str, Any]] = None


@dataclass
class Document:
    """文档信息"""

    id: str
    name: str
    dataset_id: str
    chunk_method: Optional[str]
    size: int
    status: str
    created_at: str


@dataclass
class DocumentUpdateConfig:
    """文档更新配置"""

    name: Optional[str] = None
    meta_fields: Optional[Dict[str, Any]] = None
    chunk_method: Optional[str] = None
    parser_config: Optional[Dict[str, Any]] = None
    enabled: Optional[int] = None


@dataclass
class AssistantUpdateConfig:
    """助手更新配置
    支持两种用法：
    1. 简单用法：直接传递 LLM 和 Prompt 参数，如 AssistantUpdateConfig(temperature=0.7)
    2. 高级用法：传递完整的配置对象，如 AssistantUpdateConfig(llm=LLMConfig(temperature=0.7))
    """

    name: Optional[str] = None
    description: Optional[str] = None
    avatar: Optional[str] = None
    dataset_ids: Optional[List[str]] = None

    # LLM 配置（支持直接传递参数或完整对象）
    llm: Optional[LLMConfig] = None
    model_name: Optional[str] = None
    temperature: Optional[float] = None
    top_p: Optional[float] = None
    presence_penalty: Optional[float] = None
    frequency_penalty: Optional[float] = None

    # Prompt 配置（支持直接传递参数或完整对象）
    prompt: Optional[PromptConfig] = None
    similarity_threshold: Optional[float] = None
    keywords_similarity_weight: Optional[float] = None
    top_n: Optional[int] = None
    variables: Optional[List[PromptVariable]] = None
    rerank_model: Optional[str] = None
    top_k: Optional[int] = None
    empty_response: Optional[str] = None
    opener: Optional[str] = None
    show_quote: Optional[bool] = None
    prompt_text: Optional[str] = None

    def __post_init__(self):
        """初始化后处理：自动构建 LLM 和 Prompt 配置对象"""
        # 构建 LLM 配置
        llm_params = {
            "model_name": self.model_name,
            "temperature": self.temperature,
            "top_p": self.top_p,
            "presence_penalty": self.presence_penalty,
            "frequency_penalty": self.frequency_penalty,
        }
        # 如果传入了任何 LLM 参数，构建 LLMConfig 对象
        if any(v is not None for v in llm_params.values()):
            if self.llm is None:
                self.llm = LLMConfig(
                    **{k: v for k, v in llm_params.items() if v is not None}
                )
            else:
                # 如果已有 llm 对象，合并参数
                for k, v in llm_params.items():
                    if v is not None:
                        setattr(self.llm, k, v)

        # 构建 Prompt 配置
        prompt_params = {
            "similarity_threshold": self.similarity_threshold,
            "keywords_similarity_weight": self.keywords_similarity_weight,
            "top_n": self.top_n,
            "variables": self.variables,
            "rerank_model": self.rerank_model,
            "top_k": self.top_k,
            "empty_response": self.empty_response,
            "opener": self.opener,
            "show_quote": self.show_quote,
            "prompt": self.prompt_text,
        }
        # 如果传入了任何 Prompt 参数，构建 PromptConfig 对象
        if any(v is not None for v in prompt_params.values()):
            if self.prompt is None:
                self.prompt = PromptConfig(
                    **{k: v for k, v in prompt_params.items() if v is not None}
                )
            else:
                # 如果已有 prompt 对象，合并参数
                for k, v in prompt_params.items():
                    if v is not None:
                        setattr(self.prompt, k, v)


@dataclass
class SessionUpdateConfig:
    """会话更新配置"""

    name: Optional[str] = None
    user_id: Optional[str] = None
