"""
RAG 模块 - 统一的知识库检索与对话服务
"""

from .base import BaseRAG
from .config import RAGProviderConfig
from .exceptions import (
    RAGAuthenticationError,
    RAGError,
    RAGInvalidParameterError,
    RAGNetworkError,
    RAGProviderNotFoundError,
    RAGServiceUnavailableError,
)
from .factory import RAGFactory
from .models import (
    Assistant,
    AssistantConfig,
    AssistantUpdateConfig,
    ChatRequest,
    ChatResponse,
    Dataset,
    DatasetConfig,
    DatasetUpdateConfig,
    DocumentUpdateConfig,
    LLMConfig,
    PromptConfig,
    PromptVariable,
    SearchRequest,
    SearchResult,
    Session,
    SessionUpdateConfig,
    SourceInfo,
    UsageInfo,
)

__all__ = [
    # 核心类
    "BaseRAG",
    "RAGFactory",
    "RAGProviderConfig",
    # 数据模型
    "ChatRequest",
    "ChatResponse",
    "SearchRequest",
    "SearchResult",
    "AssistantConfig",
    "AssistantUpdateConfig",
    "Assistant",
    "DatasetConfig",
    "DatasetUpdateConfig",
    "Dataset",
    "DocumentUpdateConfig",
    "Session",
    "SessionUpdateConfig",
    "SourceInfo",
    "UsageInfo",
    "LLMConfig",
    "PromptConfig",
    "PromptVariable",
    # 异常
    "RAGError",
    "RAGProviderNotFoundError",
    "RAGAuthenticationError",
    "RAGInvalidParameterError",
    "RAGNetworkError",
    "RAGServiceUnavailableError",
]
