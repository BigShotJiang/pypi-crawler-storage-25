"""
RAG 异常定义
"""

from typing import Optional


class RAGError(Exception):
    """RAG 基础异常"""

    def __init__(self, message: str, error_code: Optional[str] = None):
        self.message = message
        self.error_code = error_code
        super().__init__(self.message)


class RAGProviderNotFoundError(RAGError):
    """RAG 提供商未找到"""


class RAGAuthenticationError(RAGError):
    """RAG 认证失败"""


class RAGInvalidParameterError(RAGError):
    """RAG 参数错误"""


class RAGNetworkError(RAGError):
    """RAG 网络错误"""


class RAGServiceUnavailableError(RAGError):
    """RAG 服务不可用"""
