"""
RAG 抽象基类
"""

from abc import ABC, abstractmethod
from typing import Any, AsyncIterator, Dict, Iterator, List, Optional

from soulshell_base.core import get_logger

from .exceptions import RAGInvalidParameterError
from .models import (
    Assistant,
    AssistantConfig,
    ChatRequest,
    ChatResponse,
    SearchRequest,
    SearchResult,
    Session,
)


class BaseRAG(ABC):
    """RAG 抽象基类"""

    def __init__(self, **kwargs):
        """初始化 RAG 提供商

        Args:
            **kwargs: 配置参数，由具体 Provider 自行约定
        """
        self.config = kwargs
        self.logger = get_logger(
            f"{self.__class__.__module__}.{self.__class__.__name__}",
            level=self.config.get("log_level", "INFO"),
        )

    @abstractmethod
    def get_provider_name(self) -> str:
        """获取供应商名称"""

    @classmethod
    @abstractmethod
    def describe(cls) -> Dict[str, Any]:
        """获取提供商描述信息（自描述能力）

        Returns:
            包含以下字段的字典：
            - provider_name: 提供商名称
            - display_name: 显示名称
            - description: 描述
            - required_init_params: 必填创建参数 {参数名: {type, description, env_var?, example?}}
            - optional_init_params: 可选创建参数 {参数名: {type, description, default}}
            - example: 完整示例
        """

    # ============ 同步接口 ============

    def chat_sync(self, request: ChatRequest, chat_id: str) -> ChatResponse:
        """同步对话（可选实现）

        Args:
            request: 对话请求对象，包含以下主要字段：
                - message: 用户消息内容（必填）
                - session_id: 会话ID（可选），用于保持对话上下文
                - stream: 是否流式返回（可选），默认为 False
                - temperature: 温度参数（可选），覆盖创建阶段的默认值
                - metadata_condition: 元数据过滤条件（可选）
            chat_id: 聊天助手ID，用于指定使用哪个助手进行对话

        Returns:
            对话响应，包含：
                - content: 助手生成的回答内容
                - session_id: 会话ID
                - message_id: 消息ID
                - sources: 来源信息列表（检索到的相关文档片段）
                - usage: Token 使用情况（如果支持）

        Raises:
            NotImplementedError: 如果提供商不支持同步接口
            RAGInvalidParameterError: 参数无效（如消息为空）
            RAGAuthenticationError: 认证失败
            RAGError: 对话失败
            RAGNetworkError: 网络错误
        """
        raise NotImplementedError(f"{self.get_provider_name()} 不支持同步对话接口")

    def chat_stream_sync(
        self, request: ChatRequest, chat_id: str
    ) -> Iterator[ChatResponse]:  # noqa: ARG002
        """同步流式对话（可选实现）

        Args:
            request: 对话请求（stream=True）
            chat_id: 聊天助手ID

        Yields:
            对话响应片段

        Raises:
            NotImplementedError: 如果提供商不支持同步流式接口
        """
        raise NotImplementedError(f"{self.get_provider_name()} 不支持同步流式对话接口")
        yield  # for type hints

    def search_sync(self, request: SearchRequest) -> List[SearchResult]:
        """同步检索（可选实现）

        从知识库中检索与查询相关的文档片段，不生成回答。

        Args:
            request: 检索请求对象，包含以下主要字段：
                - query: 搜索查询文本（必填）
                - dataset_ids: 数据集ID列表（可选），限定检索范围
                - document_ids: 文档ID列表（可选），限定检索范围
                - top_k: 返回结果数量（可选），覆盖创建阶段的默认值
                - similarity_threshold: 相似度阈值（可选），低于此值的结果不返回
                - vector_similarity_weight: 向量相似度权重（可选）
                - keyword: 是否启用关键词匹配（可选）
                - highlight: 是否高亮匹配内容（可选）
                - metadata_condition: 元数据过滤条件（可选）

        Returns:
            检索结果列表，每个结果包含：
                - content: 文档片段内容
                - score: 相似度分数（0-1，越高越相关）
                - document_id: 所属文档ID
                - chunk_id: 分块ID
                - metadata: 元数据信息

        Raises:
            NotImplementedError: 如果提供商不支持同步接口
            RAGInvalidParameterError: 参数无效（如查询为空）
            RAGError: 检索失败
            RAGNetworkError: 网络错误

        Note:
            检索功能只返回相关的文档片段，不包含 LLM 生成的回答。
            如果需要生成回答，请使用 chat_sync() 方法。
        """
        raise NotImplementedError(f"{self.get_provider_name()} 不支持同步检索接口")

    # ============ 异步接口 ============

    @abstractmethod
    async def chat(self, request: ChatRequest, chat_id: str) -> ChatResponse:
        """异步对话

        Args:
            request: 对话请求对象，包含以下主要字段：
                - message: 用户消息内容（必填）
                - session_id: 会话ID（可选），用于保持对话上下文
                - stream: 是否流式返回（可选），默认为 False
                - temperature: 温度参数（可选），覆盖创建阶段的默认值
                - metadata_condition: 元数据过滤条件（可选）
            chat_id: 聊天助手ID，用于指定使用哪个助手进行对话

        Returns:
            对话响应，包含：
                - content: 助手生成的回答内容
                - session_id: 会话ID
                - message_id: 消息ID
                - sources: 来源信息列表（检索到的相关文档片段）
                - usage: Token 使用情况（如果支持）

        Raises:
            RAGInvalidParameterError: 参数无效（如消息为空）
            RAGAuthenticationError: 认证失败
            RAGError: 对话失败
            RAGNetworkError: 网络错误
        """

    async def chat_stream(
        self, request: ChatRequest, chat_id: str
    ) -> AsyncIterator[ChatResponse]:  # noqa: ARG002
        """异步流式对话（可选实现）

        Args:
            request: 对话请求（stream=True）
            chat_id: 聊天助手ID

        Yields:
            对话响应片段

        Raises:
            NotImplementedError: 如果提供商不支持异步流式接口
        """
        raise NotImplementedError(f"{self.get_provider_name()} 不支持异步流式对话接口")
        yield  # for type hints

    @abstractmethod
    async def search(self, request: SearchRequest) -> List[SearchResult]:
        """异步检索

        从知识库中检索与查询相关的文档片段，不生成回答。

        Args:
            request: 检索请求对象，包含以下主要字段：
                - query: 搜索查询文本（必填）
                - dataset_ids: 数据集ID列表（可选），限定检索范围
                - document_ids: 文档ID列表（可选），限定检索范围
                - top_k: 返回结果数量（可选），覆盖创建阶段的默认值
                - similarity_threshold: 相似度阈值（可选），低于此值的结果不返回
                - vector_similarity_weight: 向量相似度权重（可选）
                - keyword: 是否启用关键词匹配（可选）
                - highlight: 是否高亮匹配内容（可选）
                - metadata_condition: 元数据过滤条件（可选）

        Returns:
            检索结果列表，每个结果包含：
                - content: 文档片段内容
                - score: 相似度分数（0-1，越高越相关）
                - document_id: 所属文档ID
                - chunk_id: 分块ID
                - metadata: 元数据信息

        Raises:
            RAGInvalidParameterError: 参数无效（如查询为空）
            RAGError: 检索失败
            RAGNetworkError: 网络错误

        Note:
            检索功能只返回相关的文档片段，不包含 LLM 生成的回答。
            如果需要生成回答，请使用 chat() 方法。
        """

    @abstractmethod
    async def create_assistant(self, config: AssistantConfig) -> Assistant:
        """创建助手

        创建一个新的聊天助手，用于后续的对话和会话管理。

        Args:
            config: 助手配置对象，包含以下主要字段：
                - name: 助手名称（必填）
                - description: 助手描述（可选）
                - dataset_ids: 关联的数据集ID列表（可选），用于知识库检索
                - model: LLM 模型名称（可选）
                - temperature: 温度参数（可选），控制回答的随机性，默认 0.7
                - system_prompt: 系统提示词（可选），定义助手的行为和风格
                - top_n: 检索文档数量（可选），默认 6

        Returns:
            助手信息，包含：
                - id: 助手ID（后续对话需要使用此ID）
                - name: 助手名称
                - description: 助手描述
                - dataset_ids: 关联的数据集ID列表
                - created_at: 创建时间

        Raises:
            RAGError: 创建助手失败（如名称重复、参数无效等）
            RAGAuthenticationError: 认证失败
            RAGNetworkError: 网络错误

        Note:
            创建助手后，需要先创建会话（create_session），然后才能进行对话。
        """

    @abstractmethod
    async def create_session(
        self,
        chat_id: str,
        name: str = "New session",
        user_id: Optional[str] = None,
    ) -> Session:
        """创建会话

        Args:
            chat_id: 聊天助手ID，用于标识该会话属于哪个助手
            name: 会话名称，用于标识和区分不同的会话，默认为 "New session"
            user_id: 用户ID（可选），用于标识会话的归属用户。
                在多用户场景下，用于实现会话隔离和管理。
                如果不提供，会话将属于当前 API Key 的所有者。
                可以是任意格式的用户标识（如 UUID、邮箱、用户名等）。

        Returns:
            会话信息，包含会话ID、名称、助手ID、用户ID和创建时间

        Example:
            >>> # 单用户场景（不传 user_id）
            >>> session = await rag.create_session(
            ...     chat_id="assistant-id",
            ...     name="我的学习会话"
            ... )
            >>>
            >>> # 多用户场景（传入 user_id）
            >>> session = await rag.create_session(
            ...     chat_id="assistant-id",
            ...     name="用户的学习会话",
            ...     user_id="user-123"
            ... )
        """

    @abstractmethod
    async def list_assistants(
        self,
        page: int = 1,
        page_size: int = 30,
        orderby: str = "create_time",
        desc: bool = True,
        chat_id: Optional[str] = None,
        name: Optional[str] = None,
    ) -> List[Assistant]:
        """异步列出助手

        Args:
            page: 页码，从 1 开始，默认为 1
            page_size: 每页返回的助手数量，默认为 30
            orderby: 排序字段，可选值：
                - "create_time": 按创建时间排序（默认）
                - "update_time": 按更新时间排序
            desc: 是否降序排列，默认为 True（最新的在前）
            chat_id: 按助手ID精确过滤（可选），如果提供则只返回匹配的助手
            name: 按助手名称过滤（可选），支持模糊匹配

        Returns:
            助手列表，每个助手包含ID、名称、描述、关联的数据集ID和创建时间

        Example:
            >>> # 列出所有助手（第一页）
            >>> assistants = await rag.list_assistants(page=1, page_size=10)
            >>>
            >>> # 按名称过滤
            >>> assistants = await rag.list_assistants(name="AI助手")
            >>>
            >>> # 按ID精确查找
            >>> assistants = await rag.list_assistants(chat_id="specific-id")
        """

    @abstractmethod
    async def list_sessions(
        self,
        chat_id: str,
        page: int = 1,
        page_size: int = 30,
        orderby: str = "create_time",
        desc: bool = True,
        session_id: Optional[str] = None,
        name: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> List[Session]:
        """异步列出会话

        Args:
            chat_id: 聊天助手ID，必需参数，用于指定要查询哪个助手下的会话
            page: 页码，从 1 开始，默认为 1
            page_size: 每页返回的会话数量，默认为 30
            orderby: 排序字段，可选值：
                - "create_time": 按创建时间排序（默认）
                - "update_time": 按更新时间排序
            desc: 是否降序排列，默认为 True（最新的在前）
            session_id: 按会话ID精确过滤（可选），如果提供则只返回匹配的会话
            name: 按会话名称过滤（可选），支持模糊匹配
            user_id: 按用户ID过滤（可选），用于在多用户场景下只返回特定用户的会话。
                如果不提供，则返回该助手下的所有会话（不区分用户）。
                常用于实现用户会话隔离和权限控制。

        Returns:
            会话列表，每个会话包含ID、名称、助手ID、用户ID和创建时间

        Example:
            >>> # 列出助手下的所有会话
            >>> sessions = await rag.list_sessions(
            ...     chat_id="assistant-id",
            ...     page=1,
            ...     page_size=20
            ... )
            >>>
            >>> # 只列出特定用户的会话（多用户场景）
            >>> user_sessions = await rag.list_sessions(
            ...     chat_id="assistant-id",
            ...     user_id="user-123"
            ... )
            >>>
            >>> # 按名称过滤
            >>> sessions = await rag.list_sessions(
            ...     chat_id="assistant-id",
            ...     name="学习"
            ... )
        """

    def create_assistant_sync(self, config: AssistantConfig) -> Assistant:
        """同步创建助手（可选实现）

        创建一个新的聊天助手，用于后续的对话和会话管理。

        Args:
            config: 助手配置对象，包含以下主要字段：
                - name: 助手名称（必填）
                - description: 助手描述（可选）
                - dataset_ids: 关联的数据集ID列表（可选），用于知识库检索
                - model: LLM 模型名称（可选）
                - temperature: 温度参数（可选），控制回答的随机性，默认 0.7
                - system_prompt: 系统提示词（可选），定义助手的行为和风格
                - top_n: 检索文档数量（可选），默认 6

        Returns:
            助手信息，包含：
                - id: 助手ID（后续对话需要使用此ID）
                - name: 助手名称
                - description: 助手描述
                - dataset_ids: 关联的数据集ID列表
                - created_at: 创建时间

        Raises:
            NotImplementedError: 如果提供商不支持同步接口
            RAGError: 创建助手失败（如名称重复、参数无效等）
            RAGAuthenticationError: 认证失败
            RAGNetworkError: 网络错误

        Note:
            创建助手后，需要先创建会话（create_session_sync），然后才能进行对话。
        """
        raise NotImplementedError(f"{self.get_provider_name()} 不支持同步创建助手接口")

    def create_session_sync(
        self,
        chat_id: str,
        name: str = "New session",
        user_id: Optional[str] = None,
    ) -> Session:
        """同步创建会话（可选实现）

        Args:
            chat_id: 聊天助手ID，用于标识该会话属于哪个助手
            name: 会话名称，用于标识和区分不同的会话，默认为 "New session"
            user_id: 用户ID（可选），用于标识会话的归属用户。
                在多用户场景下，用于实现会话隔离和管理。
                如果不提供，会话将属于当前 API Key 的所有者。
                可以是任意格式的用户标识（如 UUID、邮箱、用户名等）。

        Returns:
            会话信息，包含会话ID、名称、助手ID、用户ID和创建时间

        Raises:
            NotImplementedError: 如果提供商不支持同步接口

        Example:
            >>> # 单用户场景（不传 user_id）
            >>> session = rag.create_session_sync(
            ...     chat_id="assistant-id",
            ...     name="我的学习会话"
            ... )
            >>>
            >>> # 多用户场景（传入 user_id）
            >>> session = rag.create_session_sync(
            ...     chat_id="assistant-id",
            ...     name="用户的学习会话",
            ...     user_id="user-123"
            ... )
        """
        raise NotImplementedError(f"{self.get_provider_name()} 不支持同步创建会话接口")

    def list_assistants_sync(
        self,
        page: int = 1,
        page_size: int = 30,
        orderby: str = "create_time",
        desc: bool = True,
        chat_id: Optional[str] = None,
        name: Optional[str] = None,
    ) -> List[Assistant]:
        """同步列出助手（可选实现）

        Args:
            page: 页码，从 1 开始，默认为 1
            page_size: 每页返回的助手数量，默认为 30
            orderby: 排序字段，可选值：
                - "create_time": 按创建时间排序（默认）
                - "update_time": 按更新时间排序
            desc: 是否降序排列，默认为 True（最新的在前）
            chat_id: 按助手ID精确过滤（可选），如果提供则只返回匹配的助手
            name: 按助手名称过滤（可选），支持模糊匹配

        Returns:
            助手列表，每个助手包含ID、名称、描述、关联的数据集ID和创建时间

        Raises:
            NotImplementedError: 如果提供商不支持同步接口

        Example:
            >>> # 列出所有助手（第一页）
            >>> assistants = rag.list_assistants_sync(page=1, page_size=10)
            >>>
            >>> # 按名称过滤
            >>> assistants = rag.list_assistants_sync(name="AI助手")
        """
        raise NotImplementedError(f"{self.get_provider_name()} 不支持同步列出助手接口")

    def list_sessions_sync(
        self,
        chat_id: str,
        page: int = 1,
        page_size: int = 30,
        orderby: str = "create_time",
        desc: bool = True,
        session_id: Optional[str] = None,
        name: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> List[Session]:
        """同步列出会话（可选实现）

        Args:
            chat_id: 聊天助手ID，必需参数，用于指定要查询哪个助手下的会话
            page: 页码，从 1 开始，默认为 1
            page_size: 每页返回的会话数量，默认为 30
            orderby: 排序字段，可选值：
                - "create_time": 按创建时间排序（默认）
                - "update_time": 按更新时间排序
            desc: 是否降序排列，默认为 True（最新的在前）
            session_id: 按会话ID精确过滤（可选），如果提供则只返回匹配的会话
            name: 按会话名称过滤（可选），支持模糊匹配
            user_id: 按用户ID过滤（可选），用于在多用户场景下只返回特定用户的会话。
                如果不提供，则返回该助手下的所有会话（不区分用户）。
                常用于实现用户会话隔离和权限控制。

        Returns:
            会话列表，每个会话包含ID、名称、助手ID、用户ID和创建时间

        Raises:
            NotImplementedError: 如果提供商不支持同步接口

        Example:
            >>> # 列出助手下的所有会话
            >>> sessions = rag.list_sessions_sync(
            ...     chat_id="assistant-id",
            ...     page=1,
            ...     page_size=20
            ... )
            >>>
            >>> # 只列出特定用户的会话（多用户场景）
            >>> user_sessions = rag.list_sessions_sync(
            ...     chat_id="assistant-id",
            ...     user_id="user-123"
            ... )
        """
        raise NotImplementedError(f"{self.get_provider_name()} 不支持同步列出会话接口")

    # ============ 验证方法 ============

    @abstractmethod
    def validate_config(self) -> bool:
        """验证配置参数

        Returns:
            配置是否有效
        """

    def validate_request(self, request: ChatRequest | SearchRequest) -> None:
        """验证请求参数（可重写）

        Args:
            request: 请求对象

        Raises:
            RAGInvalidParameterError: 参数无效
        """
        if isinstance(request, ChatRequest):
            if not request.message:
                raise RAGInvalidParameterError("消息不能为空")
        elif isinstance(request, SearchRequest):
            if not request.query:
                raise RAGInvalidParameterError("查询不能为空")
