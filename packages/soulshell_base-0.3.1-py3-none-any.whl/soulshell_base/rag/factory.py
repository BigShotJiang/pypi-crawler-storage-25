"""
RAG 工厂类
"""

import importlib
from typing import Any, ClassVar, Dict, List, Tuple, Type

from soulshell_base.core import get_logger

from .base import BaseRAG
from .exceptions import RAGProviderNotFoundError

logger = get_logger(__name__)


class RAGFactory:
    """RAG 工厂类 - 支持延迟加载提供商"""

    # 提供商映射：名称 -> (模块路径, 类名)
    _PROVIDER_MAP: ClassVar[Dict[str, Tuple[str, str]]] = {
        "ragflow": (
            "soulshell_base.rag.providers.ragflow_provider",
            "RAGFlowProvider",
        ),
        # 未来扩展
        # "chroma": ("soulshell_base.rag.providers.chroma_provider", "ChromaProvider"),
        # "elasticsearch": ("soulshell_base.rag.providers.es_provider", "ESProvider"),
    }

    # 别名映射（向后兼容）
    _PROVIDER_ALIASES: ClassVar[Dict[str, str]] = {
        # "es": "elasticsearch",  # 简写
    }

    # 依赖提示信息
    _DEPENDENCY_HINTS: ClassVar[Dict[str, str]] = {
        "ragflow": "httpx (安装: pip install httpx 或 uv sync --extra rag-ragflow)",
    }

    _providers: ClassVar[Dict[str, Type[BaseRAG]]] = {}

    @classmethod
    def _resolve_provider_name(cls, name: str) -> str:
        """解析提供商名称（处理别名）

        Args:
            name: 提供商名称或别名

        Returns:
            主名称
        """
        return cls._PROVIDER_ALIASES.get(name, name)

    @classmethod
    def _lazy_load_provider(cls, name: str) -> Type[BaseRAG]:
        """延迟加载提供商类

        Args:
            name: 提供商名称

        Returns:
            提供商类

        Raises:
            RAGProviderNotFoundError: 提供商不存在
            ImportError: 缺少必要的依赖包
        """
        # 解析别名
        name = cls._resolve_provider_name(name)

        if name not in cls._PROVIDER_MAP:
            available = cls.list_available_providers()
            raise RAGProviderNotFoundError(
                f"未知的 RAG 提供商: {name}. 可用提供商: {available}"
            )

        module_path, class_name = cls._PROVIDER_MAP[name]

        try:
            # 动态导入模块
            module = importlib.import_module(module_path)
            provider_class = getattr(module, class_name)

            # 缓存已加载的提供商
            cls._providers[name] = provider_class
            logger.debug(f"已延迟加载 RAG 提供商: {name}")
            return provider_class

        except ImportError as e:
            # 提供友好的错误提示
            hint = cls._DEPENDENCY_HINTS.get(name, "未知依赖")
            raise ImportError(
                f"无法加载 RAG 提供商 '{name}'，缺少必要的依赖包。\n"
                f"需要安装: {hint}\n"
                f"原始错误: {e}"
            ) from e

    @classmethod
    def list_available_providers(cls) -> List[str]:
        """列出所有可用的提供商（仅主名称）

        Returns:
            提供商名称列表
        """
        return list(cls._PROVIDER_MAP.keys())

    @classmethod
    def list_all_names(cls) -> Dict[str, List[str]]:
        """列出所有名称（包括别名）

        Returns:
            {"ragflow": ["ragflow"], ...}
        """
        result = {name: [name] for name in cls._PROVIDER_MAP}
        for alias, main_name in cls._PROVIDER_ALIASES.items():
            if main_name in result:
                result[main_name].append(alias)
        return result

    @classmethod
    def describe(cls, provider_name: str) -> Dict[str, Any]:
        """获取提供商描述信息（自描述能力）

        Args:
            provider_name: 提供商名称

        Returns:
            包含必填/可选参数、示例的描述信息

        Example:
            >>> RAGFactory.describe("ragflow")
            {
                "provider_name": "ragflow",
                "required_init_params": {...},
                "optional_init_params": {...},
                "example": {...}
            }
        """
        # 解析别名
        provider_name = cls._resolve_provider_name(provider_name)

        if provider_name not in cls._PROVIDER_MAP:
            available = cls.list_available_providers()
            raise RAGProviderNotFoundError(
                f"未知的 RAG 提供商: {provider_name}. 可用提供商: {available}"
            )

        # 延迟加载 Provider 类
        if provider_name not in cls._providers:
            cls._lazy_load_provider(provider_name)

        provider_class = cls._providers[provider_name]
        return provider_class.describe()

    @classmethod
    def create(cls, provider_name: str, **kwargs) -> BaseRAG:
        """创建 RAG 提供商实例（支持延迟加载）

        Args:
            provider_name: 提供商名称
            **kwargs: 配置参数，将透传给具体 Provider 的 __init__

        Returns:
            RAG 提供商实例

        Raises:
            RAGProviderNotFoundError: 提供商不存在
            ImportError: 缺少必要的依赖包
            ValueError: 配置无效

        Example:
            >>> rag = RAGFactory.create(
            ...     "ragflow",
            ...     api_key="ragflow-xxx",
            ...     base_url="http://localhost:9380"
            ... )
        """
        # 解析别名
        provider_name = cls._resolve_provider_name(provider_name)

        # 如果提供商未缓存，则延迟加载
        if provider_name not in cls._providers:
            cls._lazy_load_provider(provider_name)

        provider_class = cls._providers[provider_name]
        instance = provider_class(**kwargs)

        # 验证配置
        if not instance.validate_config():
            raise ValueError(f"RAG 提供商 {provider_name} 配置无效")

        logger.debug(f"成功创建 RAG 提供商实例: {provider_name}")
        return instance

    @classmethod
    def create_from_config(cls, provider_name: str, config: Dict[str, Any]) -> BaseRAG:
        """从配置字典创建实例

        Args:
            provider_name: 提供商名称
            config: 配置字典

        Returns:
            RAG 提供商实例
        """
        return cls.create(provider_name, **config)
