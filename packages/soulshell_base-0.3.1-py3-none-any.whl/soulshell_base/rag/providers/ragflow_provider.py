"""
RAGFlow 提供商实现（支持同步和异步）
"""

import json
import time
from typing import Any, AsyncIterator, Dict, Iterator, List, Optional

import httpx

from soulshell_base.core.utils import is_valid_url

from ..base import BaseRAG
from ..exceptions import (
    RAGAuthenticationError,
    RAGError,
    RAGNetworkError,
)
from ..models import (
    Assistant,
    AssistantConfig,
    AssistantUpdateConfig,
    ChatRequest,
    ChatResponse,
    Dataset,
    DatasetConfig,
    DatasetUpdateConfig,
    Document,
    DocumentUpdateConfig,
    SearchRequest,
    SearchResult,
    Session,
    SessionUpdateConfig,
    SourceInfo,
    UsageInfo,
)


class RAGFlowProvider(BaseRAG):
    """RAGFlow 提供商实现"""

    def __init__(
        self,
        api_key: str,
        base_url: str,
        timeout: int = 30,
        max_retries: int = 3,
        # 默认策略（可被调用阶段覆盖）
        default_temperature: float = 0.7,
        default_top_k: int = 5,
        **kwargs,
    ):
        """初始化 RAGFlow 提供商

        Args:
            api_key: RAGFlow API Key
            base_url: RAGFlow 服务地址
            timeout: 请求超时时间（秒）
            max_retries: 最大重试次数
            default_temperature: 默认温度参数
            default_top_k: 默认检索数量
            **kwargs: 其他参数
        """
        super().__init__(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
            default_temperature=default_temperature,
            default_top_k=default_top_k,
            **kwargs,
        )

        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries

        # 默认策略
        self.default_temperature = default_temperature
        self.default_top_k = default_top_k

        # HTTP 客户端（延迟初始化）
        self._async_client: Optional[httpx.AsyncClient] = None
        self._sync_client: Optional[httpx.Client] = None

    def get_provider_name(self) -> str:
        return "ragflow"

    @classmethod
    def describe(cls) -> Dict[str, Any]:
        """获取提供商描述信息"""
        return {
            "provider_name": "ragflow",
            "display_name": "RAGFlow",
            "description": "RAGFlow 知识库检索与对话服务",
            "required_init_params": {
                "api_key": {
                    "type": "str",
                    "description": "RAGFlow API Key",
                    "env_var": "RAG_RAGFLOW_API_KEY",
                },
                "base_url": {
                    "type": "str",
                    "description": "RAGFlow 服务地址",
                    "example": "http://localhost:9380",
                },
            },
            "optional_init_params": {
                "timeout": {
                    "type": "int",
                    "description": "请求超时时间（秒）",
                    "default": 30,
                },
                "max_retries": {
                    "type": "int",
                    "description": "最大重试次数",
                    "default": 3,
                },
                "default_temperature": {
                    "type": "float",
                    "description": "默认温度参数",
                    "default": 0.7,
                },
                "default_top_k": {
                    "type": "int",
                    "description": "默认检索数量",
                    "default": 5,
                },
            },
            "example": {
                "api_key": "ragflow-xxxxxxxx",
                "base_url": "http://localhost:9380",
                "timeout": 30,
                "max_retries": 3,
            },
        }

    def validate_config(self) -> bool:
        """验证配置"""
        if not self.api_key or not self.api_key.strip():
            self.logger.error("api_key 不能为空")
            return False
        if not self.base_url or not self.base_url.strip():
            self.logger.error("base_url 不能为空")
            return False

        # 验证 URL 格式
        if not is_valid_url(self.base_url):
            self.logger.error(f"base_url 格式无效: {self.base_url}")
            return False

        # 验证数值参数
        if self.timeout <= 0:
            self.logger.error(f"timeout 必须大于 0: {self.timeout}")
            return False
        if self.max_retries < 0:
            self.logger.error(f"max_retries 不能为负数: {self.max_retries}")
            return False

        self.logger.debug(f"RAGFlow 配置验证通过: base_url={self.base_url}")
        return True

    def _get_sync_client(self) -> httpx.Client:
        """获取或创建同步 HTTP 客户端"""
        if self._sync_client is None or self._sync_client.is_closed:
            self._sync_client = httpx.Client(
                timeout=self.timeout,
                headers={"Authorization": f"Bearer {self.api_key}"},
                transport=httpx.HTTPTransport(retries=self.max_retries),
            )
        return self._sync_client

    async def _get_async_client(self) -> httpx.AsyncClient:
        """获取或创建异步 HTTP 客户端"""
        if self._async_client is None or self._async_client.is_closed:
            self._async_client = httpx.AsyncClient(
                timeout=self.timeout,
                headers={"Authorization": f"Bearer {self.api_key}"},
                transport=httpx.AsyncHTTPTransport(retries=self.max_retries),
            )
        return self._async_client

    def _build_chat_payload(self, request: ChatRequest) -> Dict[str, Any]:
        """构建对话请求负载"""
        payload = {
            "question": request.message,
            "stream": request.stream,
        }

        if request.session_id:
            payload["session_id"] = request.session_id

        # 参数覆盖：调用阶段优先
        if request.temperature is not None:
            payload["temperature"] = request.temperature
        elif self.default_temperature is not None:
            payload["temperature"] = self.default_temperature

        if request.metadata_condition:
            payload["metadata_condition"] = request.metadata_condition

        # 合并额外参数
        payload.update(request.extra_params)

        return payload

    def _build_search_payload(self, request: SearchRequest) -> Dict[str, Any]:
        """构建检索请求负载"""
        payload = {
            "question": request.query,
            "top_k": request.top_k or self.default_top_k,
            "similarity_threshold": request.similarity_threshold,
            "vector_similarity_weight": request.vector_similarity_weight,
            "keyword": request.keyword,
            "highlight": request.highlight,
        }

        if request.dataset_ids:
            payload["dataset_ids"] = request.dataset_ids
        if request.document_ids:
            payload["document_ids"] = request.document_ids
        if request.metadata_condition:
            payload["metadata_condition"] = request.metadata_condition

        return payload

    def _parse_sources(self, reference: Dict[str, Any]) -> List[SourceInfo]:
        """解析来源信息"""
        sources = []
        for chunk in reference.get("chunks", []):
            sources.append(
                SourceInfo(
                    content=chunk.get("content", ""),
                    similarity=chunk.get("similarity", 0.0),
                    document_id=chunk.get("document_id", ""),
                    chunk_id=chunk.get("id", ""),
                    metadata=chunk.get("metadata", {}),
                )
            )
        return sources

    def _parse_usage(self, usage_data: Optional[Dict[str, Any]]) -> Optional[UsageInfo]:
        """解析使用情况"""
        if not usage_data:
            return None
        return UsageInfo(
            prompt_tokens=usage_data.get("prompt_tokens", 0),
            completion_tokens=usage_data.get("completion_tokens", 0),
            total_tokens=usage_data.get("total_tokens", 0),
        )

    # ============ 同步接口实现 ============

    def create_dataset_sync(self, config: DatasetConfig) -> Dataset:
        """同步创建数据集"""
        client = self._get_sync_client()

        payload = {
            "name": config.name,
        }

        if config.description:
            payload["description"] = config.description
        if config.avatar:
            payload["avatar"] = config.avatar
        if config.embedding_model:
            payload["embedding_model"] = config.embedding_model
        if config.permission:
            payload["permission"] = config.permission
        if config.chunk_method:
            payload["chunk_method"] = config.chunk_method
        if config.parser_config:
            payload["parser_config"] = config.parser_config
        if config.parse_type:
            payload["parse_type"] = config.parse_type
        if config.pipeline_id:
            payload["pipeline_id"] = config.pipeline_id

        url = f"{self.base_url}/api/v1/datasets"

        try:
            response = client.post(url, json=payload)

            if response.status_code == 401:
                raise RAGAuthenticationError("认证失败，请检查 API Key")
            if response.status_code != 200:
                raise RAGError(f"创建数据集失败: HTTP {response.status_code}")

            data = response.json()

            if data.get("code") != 0:
                raise RAGError(f"创建数据集失败: {data}")

            dataset_data = data.get("data", {})
            return Dataset(
                id=dataset_data.get("id", ""),
                name=dataset_data.get("name", ""),
                description=dataset_data.get("description"),
                chunk_method=dataset_data.get("chunk_method"),
                chunk_count=dataset_data.get("chunk_count", 0),
                document_count=dataset_data.get("document_count", 0),
                embedding_model=dataset_data.get("embedding_model"),
                created_at=dataset_data.get("create_time", ""),
            )

        except httpx.HTTPError as e:
            raise RAGNetworkError(f"网络错误: {e}") from e

    def update_dataset_sync(self, dataset_id: str, config: DatasetUpdateConfig) -> bool:
        """同步更新数据集"""
        client = self._get_sync_client()

        payload = {}
        if config.name:
            payload["name"] = config.name
        if config.description:
            payload["description"] = config.description
        if config.avatar:
            payload["avatar"] = config.avatar
        if config.permission:
            payload["permission"] = config.permission
        if config.chunk_method:
            payload["chunk_method"] = config.chunk_method
        if config.parser_config:
            payload["parser_config"] = config.parser_config

        url = f"{self.base_url}/api/v1/datasets/{dataset_id}"

        try:
            response = client.put(url, json=payload)

            if response.status_code == 401:
                raise RAGAuthenticationError("认证失败，请检查 API Key")
            if response.status_code != 200:
                raise RAGError(f"更新数据集失败: HTTP {response.status_code}")

            data = response.json()

            if data.get("code") != 0:
                raise RAGError(f"更新数据集失败: {data}")

            return True

        except httpx.HTTPError as e:
            raise RAGNetworkError(f"网络错误: {e}") from e

    def delete_dataset_sync(self, dataset_ids: Optional[List[str]] = None) -> bool:
        """同步删除数据集

        Args:
            dataset_ids: 数据集ID列表，None 表示删除所有，空列表表示不删除

        Raises:
            NotImplementedError: httpx 不支持在 DELETE 请求中包含请求体
        """
        raise NotImplementedError(
            "httpx 不支持在 DELETE 请求中包含请求体。"
            "RAGFlow API 需要在 DELETE 请求中包含 JSON 数据，这与 HTTP 标准冲突。"
        )

    def list_datasets_sync(
        self,
        page: int = 1,
        page_size: int = 30,
        orderby: str = "create_time",
        desc: bool = True,
        name: Optional[str] = None,
        dataset_id: Optional[str] = None,
    ) -> List[Dataset]:
        """同步列出数据集"""
        client = self._get_sync_client()

        params = {
            "page": page,
            "page_size": page_size,
            "orderby": orderby,
            "desc": "true" if desc else "false",
        }

        if name:
            params["name"] = name
        if dataset_id:
            params["id"] = dataset_id

        url = f"{self.base_url}/api/v1/datasets"

        try:
            response = client.get(url, params=params)

            if response.status_code == 401:
                raise RAGAuthenticationError("认证失败，请检查 API Key")
            if response.status_code != 200:
                raise RAGError(f"列出数据集失败: HTTP {response.status_code}")

            data = response.json()

            if data.get("code") != 0:
                raise RAGError(f"列出数据集失败: {data}")

            datasets = []
            for dataset_data in data.get("data", []):
                datasets.append(
                    Dataset(
                        id=dataset_data.get("id", ""),
                        name=dataset_data.get("name", ""),
                        description=dataset_data.get("description"),
                        chunk_method=dataset_data.get("chunk_method"),
                        chunk_count=dataset_data.get("chunk_count", 0),
                        document_count=dataset_data.get("document_count", 0),
                        embedding_model=dataset_data.get("embedding_model"),
                        created_at=dataset_data.get("create_time", ""),
                    )
                )

            return datasets

        except httpx.HTTPError as e:
            raise RAGNetworkError(f"网络错误: {e}") from e

    def upload_document_sync(self, dataset_id: str, file_path: str) -> Document:
        """同步上传文档到数据集

        Args:
            dataset_id: 数据集ID
            file_path: 文件路径

        Returns:
            上传的文档信息
        """
        client = self._get_sync_client()

        url = f"{self.base_url}/api/v1/datasets/{dataset_id}/documents"

        try:
            with open(file_path, "rb") as f:
                files = {"file": f}
                response = client.post(url, files=files)

            if response.status_code == 401:
                raise RAGAuthenticationError("认证失败，请检查 API Key")
            if response.status_code != 200:
                raise RAGError(f"上传文档失败: HTTP {response.status_code}")

            data = response.json()

            if data.get("code") != 0:
                raise RAGError(f"上传文档失败: {data}")

            doc_data = data.get("data", [{}])[0]
            return Document(
                id=doc_data.get("id", ""),
                name=doc_data.get("name", ""),
                dataset_id=dataset_id,
                chunk_method=doc_data.get("chunk_method"),
                size=doc_data.get("size", 0),
                status=doc_data.get("run", "UNSTART"),
                created_at=doc_data.get("create_time", ""),
            )

        except FileNotFoundError:
            raise RAGError(f"文件不存在: {file_path}") from None
        except httpx.HTTPError as e:
            raise RAGNetworkError(f"网络错误: {e}") from e

    def update_document_sync(
        self, dataset_id: str, document_id: str, config: DocumentUpdateConfig
    ) -> bool:
        """同步更新文档

        Args:
            dataset_id: 数据集ID
            document_id: 文档ID
            config: 文档更新配置

        Returns:
            是否成功
        """
        client = self._get_sync_client()

        payload = {}

        if config.name:
            payload["name"] = config.name
        if config.meta_fields:
            payload["meta_fields"] = config.meta_fields
        if config.chunk_method:
            payload["chunk_method"] = config.chunk_method
        if config.parser_config:
            payload["parser_config"] = config.parser_config
        if config.enabled is not None:
            payload["enabled"] = config.enabled

        url = f"{self.base_url}/api/v1/datasets/{dataset_id}/documents/{document_id}"

        try:
            response = client.put(url, json=payload)

            if response.status_code == 401:
                raise RAGAuthenticationError("认证失败，请检查 API Key")
            if response.status_code != 200:
                raise RAGError(f"更新文档失败: HTTP {response.status_code}")

            data = response.json()

            if data.get("code") != 0:
                raise RAGError(f"更新文档失败: {data}")

            return True

        except httpx.HTTPError as e:
            raise RAGNetworkError(f"网络错误: {e}") from e

    def download_document_sync(
        self, dataset_id: str, document_id: str, output_path: str
    ) -> bool:
        """同步下载文档

        Args:
            dataset_id: 数据集ID
            document_id: 文档ID
            output_path: 输出文件路径

        Returns:
            是否成功
        """
        client = self._get_sync_client()

        url = f"{self.base_url}/api/v1/datasets/{dataset_id}/documents/{document_id}"

        try:
            response = client.get(url)

            if response.status_code == 401:
                raise RAGAuthenticationError("认证失败，请检查 API Key")
            if response.status_code != 200:
                raise RAGError(f"下载文档失败: HTTP {response.status_code}")

            with open(output_path, "wb") as f:
                f.write(response.content)

            return True

        except httpx.HTTPError as e:
            raise RAGNetworkError(f"网络错误: {e}") from e

    def list_documents_sync(
        self,
        dataset_id: str,
        page: int = 1,
        page_size: int = 30,
        orderby: str = "create_time",
        desc: bool = True,
        keywords: Optional[str] = None,
        document_id: Optional[str] = None,
        name: Optional[str] = None,
        suffix: Optional[str] = None,
        run: Optional[str] = None,
    ) -> List[Document]:
        """同步列出数据集中的文档

        Args:
            dataset_id: 数据集ID
            page: 页码
            page_size: 每页数量
            orderby: 排序字段
            desc: 是否降序
            keywords: 关键词
            document_id: 文档ID
            name: 文档名称
            suffix: 文件后缀
            run: 运行状态（UNSTART/RUNNING/SUCCESS/FAILED）

        Returns:
            文档列表
        """
        client = self._get_sync_client()

        params = {
            "page": page,
            "page_size": page_size,
            "orderby": orderby,
            "desc": "true" if desc else "false",
        }

        if keywords:
            params["keywords"] = keywords
        if document_id:
            params["id"] = document_id
        if name:
            params["name"] = name
        if suffix:
            params["suffix"] = suffix
        if run:
            params["run"] = run

        url = f"{self.base_url}/api/v1/datasets/{dataset_id}/documents"

        try:
            response = client.get(url, params=params)

            if response.status_code == 401:
                raise RAGAuthenticationError("认证失败，请检查 API Key")
            if response.status_code != 200:
                raise RAGError(f"列出文档失败: HTTP {response.status_code}")

            data = response.json()

            if data.get("code") != 0:
                raise RAGError(f"列出文档失败: {data}")

            documents = []
            doc_list = data.get("data", [])

            if isinstance(doc_list, list):
                for doc_data in doc_list:
                    if isinstance(doc_data, dict):
                        documents.append(
                            Document(
                                id=doc_data.get("id", ""),
                                name=doc_data.get("name", ""),
                                dataset_id=dataset_id,
                                chunk_method=doc_data.get("chunk_method"),
                                size=doc_data.get("size", 0),
                                status=doc_data.get("run", "UNSTART"),
                                created_at=doc_data.get("create_time", ""),
                            )
                        )

            return documents

        except httpx.HTTPError as e:
            raise RAGNetworkError(f"网络错误: {e}") from e

    def delete_documents_sync(
        self, dataset_id: str, document_ids: Optional[List[str]] = None
    ) -> bool:
        """同步删除文档

        Args:
            dataset_id: 数据集ID
            document_ids: 文档ID列表，None 表示删除所有

        Raises:
            NotImplementedError: httpx 不支持在 DELETE 请求中包含请求体
        """
        raise NotImplementedError(
            "httpx 不支持在 DELETE 请求中包含请求体。"
            "RAGFlow API 需要在 DELETE 请求中包含 JSON 数据，这与 HTTP 标准冲突。"
        )

    def parse_documents_sync(self, dataset_id: str, document_ids: List[str]) -> bool:
        """同步解析文档（将文档切分成分块）

        Args:
            dataset_id: 数据集ID
            document_ids: 文档ID列表

        Returns:
            是否成功
        """
        client = self._get_sync_client()

        payload = {"document_ids": document_ids}

        url = f"{self.base_url}/api/v1/datasets/{dataset_id}/chunks"

        try:
            response = client.post(url, json=payload)

            if response.status_code == 401:
                raise RAGAuthenticationError("认证失败，请检查 API Key")
            if response.status_code != 200:
                raise RAGError(f"解析文档失败: HTTP {response.status_code}")

            data = response.json()

            if data.get("code") != 0:
                raise RAGError(f"解析文档失败: {data}")

            return True

        except httpx.HTTPError as e:
            raise RAGNetworkError(f"网络错误: {e}") from e

    def stop_parsing_sync(self, dataset_id: str, document_ids: List[str]) -> bool:
        """同步停止解析文档

        Args:
            dataset_id: 数据集ID
            document_ids: 文档ID列表

        Returns:
            是否成功
        """
        client = self._get_sync_client()

        payload = {"document_ids": document_ids}

        url = f"{self.base_url}/api/v1/datasets/{dataset_id}/chunks"

        try:
            response = client.delete(url, json=payload)

            if response.status_code == 401:
                raise RAGAuthenticationError("认证失败，请检查 API Key")
            if response.status_code != 200:
                raise RAGError(f"停止解析失败: HTTP {response.status_code}")

            data = response.json()

            if data.get("code") != 0:
                raise RAGError(f"停止解析失败: {data}")

            return True

        except httpx.HTTPError as e:
            raise RAGNetworkError(f"网络错误: {e}") from e

    def create_assistant_sync(self, config: AssistantConfig) -> Assistant:
        """同步创建助手"""
        client = self._get_sync_client()

        payload = {
            "name": config.name,
        }

        if config.description:
            payload["description"] = config.description

        if config.avatar:
            payload["avatar"] = config.avatar

        # 数据集ID
        if config.dataset_ids:
            payload["dataset_ids"] = config.dataset_ids

        # LLM 配置
        if config.llm:
            llm_config = {}
            if config.llm.model_name:
                llm_config["model_name"] = config.llm.model_name
            if config.llm.temperature is not None:
                llm_config["temperature"] = config.llm.temperature
            if config.llm.top_p is not None:
                llm_config["top_p"] = config.llm.top_p
            if config.llm.presence_penalty is not None:
                llm_config["presence_penalty"] = config.llm.presence_penalty
            if config.llm.frequency_penalty is not None:
                llm_config["frequency_penalty"] = config.llm.frequency_penalty
            if llm_config:
                payload["llm"] = llm_config

        # Prompt 配置
        if config.prompt:
            prompt_config = {}
            if config.prompt.similarity_threshold is not None:
                prompt_config["similarity_threshold"] = (
                    config.prompt.similarity_threshold
                )
            if config.prompt.keywords_similarity_weight is not None:
                prompt_config["keywords_similarity_weight"] = (
                    config.prompt.keywords_similarity_weight
                )
            if config.prompt.top_n is not None:
                prompt_config["top_n"] = config.prompt.top_n
            if config.prompt.variables is not None:
                prompt_config["variables"] = [
                    {"key": v.key, "optional": v.optional}
                    for v in config.prompt.variables
                ]
            if config.prompt.rerank_model:
                prompt_config["rerank_model"] = config.prompt.rerank_model
            if config.prompt.top_k is not None:
                prompt_config["top_k"] = config.prompt.top_k
            if config.prompt.empty_response is not None:
                prompt_config["empty_response"] = config.prompt.empty_response
            if config.prompt.opener is not None:
                prompt_config["opener"] = config.prompt.opener
            if config.prompt.show_quote is not None:
                prompt_config["show_quote"] = config.prompt.show_quote
            if config.prompt.prompt:
                # 如果 prompt 不包含 {knowledge}，自动添加
                if "{knowledge}" not in config.prompt.prompt:
                    prompt_config["prompt"] = f"{config.prompt.prompt}\n\n{{knowledge}}"
                else:
                    prompt_config["prompt"] = config.prompt.prompt
            if prompt_config:
                payload["prompt"] = prompt_config

        url = f"{self.base_url}/api/v1/chats"

        try:
            response = client.post(url, json=payload)

            if response.status_code == 401:
                raise RAGAuthenticationError("认证失败，请检查 API Key")
            if response.status_code != 200:
                raise RAGError(f"创建助手失败: HTTP {response.status_code}")

            data = response.json()

            if data.get("code") != 0:
                raise RAGError(f"创建助手失败: {data}")

            result = data.get("data", {})

            return Assistant(
                id=result.get("id", ""),
                name=result.get("name", ""),
                description=result.get("description"),
                dataset_ids=result.get("dataset_ids", []),
                created_at=result.get("create_time", ""),
            )

        except httpx.HTTPError as e:
            raise RAGNetworkError(f"网络错误: {e}") from e

    def update_session_sync(
        self,
        chat_id: str,
        session_id: str,
        config: SessionUpdateConfig,
    ) -> bool:
        """同步更新会话"""
        client = self._get_sync_client()

        payload = {}
        if config.name:
            payload["name"] = config.name
        if config.user_id:
            payload["user_id"] = config.user_id

        url = f"{self.base_url}/api/v1/chats/{chat_id}/sessions/{session_id}"

        try:
            response = client.put(url, json=payload)

            if response.status_code == 401:
                raise RAGAuthenticationError("认证失败，请检查 API Key")
            if response.status_code != 200:
                raise RAGError(f"更新会话失败: HTTP {response.status_code}")

            data = response.json()

            if data.get("code") != 0:
                raise RAGError(f"更新会话失败: {data}")

            return True

        except httpx.HTTPError as e:
            raise RAGNetworkError(f"网络错误: {e}") from e

    def delete_session_sync(
        self, chat_id: str, session_ids: Optional[List[str]] = None
    ) -> bool:
        """同步删除会话

        Args:
            chat_id: 聊天助手ID
            session_ids: 会话ID列表，None 表示删除所有，空列表表示不删除

        Raises:
            NotImplementedError: httpx 不支持在 DELETE 请求中包含请求体
        """
        raise NotImplementedError(
            "httpx 不支持在 DELETE 请求中包含请求体。"
            "RAGFlow API 需要在 DELETE 请求中包含 JSON 数据，这与 HTTP 标准冲突。"
        )

    def create_session_sync(
        self,
        chat_id: str,
        name: str = "New session",
        user_id: Optional[str] = None,
    ) -> Session:
        """同步创建会话

        Args:
            chat_id: 聊天助手ID，用于标识该会话属于哪个助手
            name: 会话名称，用于标识和区分不同的会话，默认为 "New session"
            user_id: 用户ID（可选），用于标识会话的归属用户。
                在多用户场景下，用于实现会话隔离和管理。
                如果不提供，会话将属于当前 API Key 的所有者。
                可以是任意格式的用户标识（如 UUID、邮箱、用户名等）。

        Returns:
            会话信息，包含会话ID、名称、助手ID、用户ID和创建时间

        Raises:
            RAGAuthenticationError: 认证失败
            RAGException: 创建会话失败
            RAGNetworkError: 网络错误

        Example:
            >>> # 单用户场景（不传 user_id）
            >>> session = rag.create_session_sync(
            ...     chat_id="assistant-id",
            ...     name="我的学习会话"
            ... )
            >>>
            >>> # 多用户场景（传入 user_id）
            >>> session = rag.create_session_sync(
            ...     chat_id="assistant-id",
            ...     name="用户的学习会话",
            ...     user_id="user-123"
            ... )
        """
        client = self._get_sync_client()

        payload = {"name": name}
        if user_id:
            payload["user_id"] = user_id

        url = f"{self.base_url}/api/v1/chats/{chat_id}/sessions"

        try:
            response = client.post(url, json=payload)

            if response.status_code == 401:
                raise RAGAuthenticationError("认证失败，请检查 API Key")
            if response.status_code != 200:
                raise RAGError(f"创建会话失败: HTTP {response.status_code}")

            data = response.json()

            if data.get("code") != 0:
                raise RAGError(f"创建会话失败: {data}")

            result = data.get("data", {})

            return Session(
                id=result.get("id", ""),
                name=result.get("name", ""),
                assistant_id=chat_id,
                user_id=result.get("user_id"),
                created_at=result.get("create_time", ""),
            )

        except httpx.HTTPError as e:
            raise RAGNetworkError(f"网络错误: {e}") from e

    def update_assistant_sync(
        self, chat_id: str, config: AssistantUpdateConfig
    ) -> bool:
        """同步更新助手"""
        client = self._get_sync_client()

        payload = {}

        if config.name:
            payload["name"] = config.name
        if config.description:
            payload["description"] = config.description
        if config.avatar:
            payload["avatar"] = config.avatar
        if config.dataset_ids:
            payload["dataset_ids"] = config.dataset_ids

        if config.llm:
            llm_config = {}
            if config.llm.model_name:
                llm_config["model_name"] = config.llm.model_name
            if config.llm.temperature is not None:
                llm_config["temperature"] = config.llm.temperature
            if config.llm.top_p is not None:
                llm_config["top_p"] = config.llm.top_p
            if config.llm.presence_penalty is not None:
                llm_config["presence_penalty"] = config.llm.presence_penalty
            if config.llm.frequency_penalty is not None:
                llm_config["frequency_penalty"] = config.llm.frequency_penalty
            if llm_config:
                payload["llm"] = llm_config

        if config.prompt:
            prompt_config = {}
            if config.prompt.similarity_threshold is not None:
                prompt_config["similarity_threshold"] = (
                    config.prompt.similarity_threshold
                )
            if config.prompt.keywords_similarity_weight is not None:
                prompt_config["keywords_similarity_weight"] = (
                    config.prompt.keywords_similarity_weight
                )
            if config.prompt.top_n is not None:
                prompt_config["top_n"] = config.prompt.top_n
            if config.prompt.variables is not None:
                prompt_config["variables"] = [
                    {"key": v.key, "optional": v.optional}
                    for v in config.prompt.variables
                ]
            if config.prompt.rerank_model is not None:
                prompt_config["rerank_model"] = config.prompt.rerank_model
            if config.prompt.top_k is not None:
                prompt_config["top_k"] = config.prompt.top_k
            if config.prompt.empty_response is not None:
                prompt_config["empty_response"] = config.prompt.empty_response
            if config.prompt.opener is not None:
                prompt_config["opener"] = config.prompt.opener
            if config.prompt.show_quote is not None:
                prompt_config["show_quote"] = config.prompt.show_quote
            if config.prompt.prompt is not None:
                if "{knowledge}" not in config.prompt.prompt:
                    prompt_config["prompt"] = f"{config.prompt.prompt}\n\n{{knowledge}}"
                else:
                    prompt_config["prompt"] = config.prompt.prompt
            if prompt_config:
                payload["prompt"] = prompt_config

        url = f"{self.base_url}/api/v1/chats/{chat_id}"

        try:
            response = client.put(url, json=payload)

            if response.status_code == 401:
                raise RAGAuthenticationError("认证失败，请检查 API Key")
            if response.status_code != 200:
                raise RAGError(f"更新助手失败: HTTP {response.status_code}")

            data = response.json()

            if data.get("code") != 0:
                raise RAGError(f"更新助手失败: {data}")

            return True

        except httpx.HTTPError as e:
            raise RAGNetworkError(f"网络错误: {e}") from e

    def delete_assistant_sync(self, chat_ids: Optional[List[str]] = None) -> bool:
        """同步删除助手

        Args:
            chat_ids: 助手ID列表，None 表示删除所有，空列表表示不删除

        Raises:
            NotImplementedError: httpx 不支持在 DELETE 请求中包含请求体
        """
        raise NotImplementedError(
            "httpx 不支持在 DELETE 请求中包含请求体。"
            "RAGFlow API 需要在 DELETE 请求中包含 JSON 数据，这与 HTTP 标准冲突。"
        )

    def list_assistants_sync(
        self,
        page: int = 1,
        page_size: int = 30,
        orderby: str = "create_time",
        desc: bool = True,
        chat_id: Optional[str] = None,
        name: Optional[str] = None,
    ) -> List[Assistant]:
        """同步列出助手

        Args:
            page: 页码，从 1 开始，默认为 1
            page_size: 每页返回的助手数量，默认为 30
            orderby: 排序字段，可选值：
                - "create_time": 按创建时间排序（默认）
                - "update_time": 按更新时间排序
            desc: 是否降序排列，默认为 True（最新的在前）
            chat_id: 按助手ID精确过滤（可选），如果提供则只返回匹配的助手
            name: 按助手名称过滤（可选），支持模糊匹配

        Returns:
            助手列表，每个助手包含ID、名称、描述、关联的数据集ID和创建时间

        Raises:
            RAGAuthenticationError: 认证失败
            RAGException: 列出助手失败
            RAGNetworkError: 网络错误

        Example:
            >>> # 列出所有助手（第一页）
            >>> assistants = rag.list_assistants_sync(page=1, page_size=10)
            >>>
            >>> # 按名称过滤
            >>> assistants = rag.list_assistants_sync(name="AI助手")
        """
        client = self._get_sync_client()

        params = {
            "page": page,
            "page_size": page_size,
            "orderby": orderby,
            "desc": "true" if desc else "false",
        }

        if chat_id:
            params["id"] = chat_id
        if name:
            params["name"] = name

        url = f"{self.base_url}/api/v1/chats"

        try:
            response = client.get(url, params=params)

            if response.status_code == 401:
                raise RAGAuthenticationError("认证失败，请检查 API Key")
            if response.status_code != 200:
                raise RAGError(f"列出助手失败: HTTP {response.status_code}")

            data = response.json()

            results = []
            if data.get("code") != 0:
                return results

            for item in data.get("data", []):
                results.append(
                    Assistant(
                        id=item.get("id", ""),
                        name=item.get("name", ""),
                        description=item.get("description"),
                        dataset_ids=item.get("dataset_ids", []),
                        created_at=item.get("create_time", ""),
                    )
                )

            return results

        except httpx.HTTPError as e:
            raise RAGNetworkError(f"网络错误: {e}") from e

    def list_sessions_sync(
        self,
        chat_id: str,
        page: int = 1,
        page_size: int = 30,
        orderby: str = "create_time",
        desc: bool = True,
        session_id: Optional[str] = None,
        name: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> List[Session]:
        """同步列出会话

        Args:
            chat_id: 聊天助手ID，必需参数，用于指定要查询哪个助手下的会话
            page: 页码，从 1 开始，默认为 1
            page_size: 每页返回的会话数量，默认为 30
            orderby: 排序字段，可选值：
                - "create_time": 按创建时间排序（默认）
                - "update_time": 按更新时间排序
            desc: 是否降序排列，默认为 True（最新的在前）
            session_id: 按会话ID精确过滤（可选），如果提供则只返回匹配的会话
            name: 按会话名称过滤（可选），支持模糊匹配
            user_id: 按用户ID过滤（可选），用于在多用户场景下只返回特定用户的会话。
                如果不提供，则返回该助手下的所有会话（不区分用户）。
                常用于实现用户会话隔离和权限控制。

        Returns:
            会话列表，每个会话包含ID、名称、助手ID、用户ID和创建时间

        Raises:
            RAGAuthenticationError: 认证失败
            RAGException: 列出会话失败
            RAGNetworkError: 网络错误

        Example:
            >>> # 列出助手下的所有会话
            >>> sessions = rag.list_sessions_sync(
            ...     chat_id="assistant-id",
            ...     page=1,
            ...     page_size=20
            ... )
            >>>
            >>> # 只列出特定用户的会话（多用户场景）
            >>> user_sessions = rag.list_sessions_sync(
            ...     chat_id="assistant-id",
            ...     user_id="user-123"
            ... )
        """
        client = self._get_sync_client()

        params = {
            "page": page,
            "page_size": page_size,
            "orderby": orderby,
            "desc": "true" if desc else "false",
        }

        if session_id:
            params["id"] = session_id
        if name:
            params["name"] = name
        if user_id:
            params["user_id"] = user_id

        url = f"{self.base_url}/api/v1/chats/{chat_id}/sessions"

        try:
            response = client.get(url, params=params)

            if response.status_code == 401:
                raise RAGAuthenticationError("认证失败，请检查 API Key")
            if response.status_code != 200:
                raise RAGError(f"列出会话失败: HTTP {response.status_code}")

            data = response.json()

            if data.get("code") != 0:
                raise RAGError(f"列出会话失败: {data}")

            results = []
            for item in data.get("data", []):
                results.append(
                    Session(
                        id=item.get("id", ""),
                        name=item.get("name", ""),
                        assistant_id=chat_id,
                        user_id=item.get("user_id"),
                        created_at=item.get("create_time", ""),
                    )
                )

            return results

        except httpx.HTTPError as e:
            raise RAGNetworkError(f"网络错误: {e}") from e

    def chat_sync(self, request: ChatRequest, chat_id: str) -> ChatResponse:
        """同步对话实现"""
        start_time = time.perf_counter()
        try:
            self.validate_request(request)

            if request.stream:
                raise RAGError("流式模式请使用 chat_stream_sync 方法")

            client = self._get_sync_client()
            payload = self._build_chat_payload(request)

            url = f"{self.base_url}/api/v1/chats/{chat_id}/completions"

            try:
                response = client.post(url, json=payload)

                if response.status_code == 401:
                    raise RAGAuthenticationError("认证失败，请检查 API Key")
                if response.status_code != 200:
                    raise RAGError(f"对话失败: HTTP {response.status_code}")

                try:
                    data = response.json()
                except json.JSONDecodeError as e:
                    raise RAGError(f"响应数据解析失败: {e}") from e

                if data.get("code") != 0:
                    raise RAGError(f"对话失败: {data}")

                result = data.get("data", {})

                return ChatResponse(
                    content=result.get("content", "") or result.get("answer", ""),
                    session_id=request.session_id or result.get("session_id", ""),
                    message_id=result.get("id", ""),
                    sources=self._parse_sources(result.get("reference", {})),
                    usage=self._parse_usage(result.get("usage")),
                )

            except httpx.HTTPError as e:
                raise RAGNetworkError(f"网络错误: {e}") from e
        finally:
            duration = time.perf_counter() - start_time
            self.logger.info("chat_sync 总耗时 %.4f s", duration)

    def chat_stream_sync(
        self, request: ChatRequest, chat_id: str
    ) -> Iterator[ChatResponse]:
        """同步流式对话实现"""
        self.logger.info(f"开始流式对话: 对话消息: {request.message[:100]}...")
        self.validate_request(request)

        client = self._get_sync_client()
        payload = self._build_chat_payload(request)
        payload["stream"] = True

        url = f"{self.base_url}/api/v1/chats/{chat_id}/completions"

        start_time = time.perf_counter()
        try:
            with client.stream("POST", url, json=payload) as response:
                if response.status_code != 200:
                    self.logger.error(f"流式对话失败: HTTP {response.status_code}")
                    raise RAGError(f"流式对话失败: HTTP {response.status_code}")

                content = ""
                sources = []
                chunk_count = 0
                for line in response.iter_lines():
                    if line.startswith("data:"):
                        try:
                            json_str = line[5:].strip()
                            resp_dict = json.loads(json_str)
                            data = resp_dict.get("data")
                            if isinstance(data, dict):
                                new_content = data.get("answer")
                                if new_content:
                                    content += new_content
                                    chunk_count += 1
                                    yield ChatResponse(
                                        content=new_content,
                                        session_id=request.session_id or "",
                                        message_id=data.get("id", ""),
                                        sources=sources,
                                    )
                                    if data.get("reference"):
                                        sources = self._parse_sources(data["reference"])
                        except json.JSONDecodeError as e:
                            self.logger.warning(f"JSON解析错误: {e}")
                            continue
                    elif line.strip() == "[DONE]":
                        self.logger.info(
                            f"流式对话完成: 总长度={len(content)}, 分片数={chunk_count}"
                        )
                        break

        except httpx.HTTPError as e:
            self.logger.error(f"网络错误: {e}")
            raise RAGNetworkError(f"网络错误: {e}") from e
        finally:
            duration = time.perf_counter() - start_time
            self.logger.info("chat_stream_sync 总耗时 %.4f s", duration)

    def search_sync(self, request: SearchRequest) -> List[SearchResult]:
        """同步检索实现"""
        self.validate_request(request)

        client = self._get_sync_client()
        payload = self._build_search_payload(request)

        url = f"{self.base_url}/api/v1/retrieval"

        try:
            response = client.post(url, json=payload)

            if response.status_code != 200:
                raise RAGError(f"检索失败: HTTP {response.status_code}")

            data = response.json()

            if data.get("code") != 0:
                raise RAGError(f"检索失败: {data}")

            results = []
            for chunk_data in data.get("data", {}).get("chunks", []):
                results.append(
                    SearchResult(
                        content=chunk_data.get("content", ""),
                        score=chunk_data.get("similarity", 0.0),
                        document_id=chunk_data.get("document_id", ""),
                        chunk_id=chunk_data.get("id", ""),
                        metadata=chunk_data.get("metadata", {}),
                    )
                )

            return results

        except httpx.HTTPError as e:
            raise RAGNetworkError(f"网络错误: {e}") from e

    # ============ 异步接口实现 ============

    async def create_dataset(self, config: DatasetConfig) -> Dataset:
        """异步创建数据集"""
        client = await self._get_async_client()

        payload = {
            "name": config.name,
        }

        if config.description:
            payload["description"] = config.description
        if config.avatar:
            payload["avatar"] = config.avatar
        if config.embedding_model:
            payload["embedding_model"] = config.embedding_model
        if config.permission:
            payload["permission"] = config.permission
        if config.chunk_method:
            payload["chunk_method"] = config.chunk_method
        if config.parser_config:
            payload["parser_config"] = config.parser_config
        if config.parse_type:
            payload["parse_type"] = config.parse_type
        if config.pipeline_id:
            payload["pipeline_id"] = config.pipeline_id

        url = f"{self.base_url}/api/v1/datasets"

        try:
            response = await client.post(url, json=payload)

            if response.status_code == 401:
                raise RAGAuthenticationError("认证失败，请检查 API Key")
            if response.status_code != 200:
                raise RAGError(f"创建数据集失败: HTTP {response.status_code}")

            data = response.json()

            if data.get("code") != 0:
                raise RAGError(f"创建数据集失败: {data}")

            dataset_data = data.get("data", {})
            return Dataset(
                id=dataset_data.get("id", ""),
                name=dataset_data.get("name", ""),
                description=dataset_data.get("description"),
                chunk_method=dataset_data.get("chunk_method"),
                chunk_count=dataset_data.get("chunk_count", 0),
                document_count=dataset_data.get("document_count", 0),
                embedding_model=dataset_data.get("embedding_model"),
                created_at=dataset_data.get("create_time", ""),
            )

        except httpx.HTTPError as e:
            raise RAGNetworkError(f"网络错误: {e}") from e

    async def update_dataset(
        self, dataset_id: str, config: DatasetUpdateConfig
    ) -> bool:
        """异步更新数据集"""
        client = await self._get_async_client()

        payload = {}
        if config.name:
            payload["name"] = config.name
        if config.description:
            payload["description"] = config.description
        if config.avatar:
            payload["avatar"] = config.avatar
        if config.permission:
            payload["permission"] = config.permission
        if config.chunk_method:
            payload["chunk_method"] = config.chunk_method
        if config.parser_config:
            payload["parser_config"] = config.parser_config

        url = f"{self.base_url}/api/v1/datasets/{dataset_id}"

        try:
            response = await client.put(url, json=payload)

            if response.status_code == 401:
                raise RAGAuthenticationError("认证失败，请检查 API Key")
            if response.status_code != 200:
                raise RAGError(f"更新数据集失败: HTTP {response.status_code}")

            data = response.json()

            if data.get("code") != 0:
                raise RAGError(f"更新数据集失败: {data}")

            return True

        except httpx.HTTPError as e:
            raise RAGNetworkError(f"网络错误: {e}") from e

    async def delete_dataset(self, dataset_ids: Optional[List[str]] = None) -> bool:
        """异步删除数据集

        Args:
            dataset_ids: 数据集ID列表，None 表示删除所有，空列表表示不删除

        Raises:
            NotImplementedError: 暂不支持异步删除数据集，请使用同步方法 delete_dataset_sync
        """
        raise NotImplementedError(
            "httpx 不支持在 DELETE 请求中包含请求体。"
            "RAGFlow API 需要在 DELETE 请求中包含 JSON 数据，这与 HTTP 标准冲突。"
            "请使用同步方法 delete_dataset_sync 代替。"
        )

    async def upload_document(self, dataset_id: str, file_path: str) -> Document:
        """异步上传文档到数据集

        Args:
            dataset_id: 数据集ID
            file_path: 文件路径

        Returns:
            上传的文档信息
        """
        client = await self._get_async_client()

        url = f"{self.base_url}/api/v1/datasets/{dataset_id}/documents"

        try:
            with open(file_path, "rb") as f:
                files = {"file": f}
                response = await client.post(url, files=files)

            if response.status_code == 401:
                raise RAGAuthenticationError("认证失败，请检查 API Key")
            if response.status_code != 200:
                raise RAGError(f"上传文档失败: HTTP {response.status_code}")

            data = response.json()

            if data.get("code") != 0:
                raise RAGError(f"上传文档失败: {data}")

            doc_data = data.get("data", [{}])[0]
            return Document(
                id=doc_data.get("id", ""),
                name=doc_data.get("name", ""),
                dataset_id=dataset_id,
                chunk_method=doc_data.get("chunk_method"),
                size=doc_data.get("size", 0),
                status=doc_data.get("run", "UNSTART"),
                created_at=doc_data.get("create_time", ""),
            )

        except FileNotFoundError:
            raise RAGError(f"文件不存在: {file_path}") from None
        except httpx.HTTPError as e:
            raise RAGNetworkError(f"网络错误: {e}") from e

    async def update_document(
        self, dataset_id: str, document_id: str, config: DocumentUpdateConfig
    ) -> bool:
        """异步更新文档

        Args:
            dataset_id: 数据集ID
            document_id: 文档ID
            config: 文档更新配置

        Returns:
            是否成功
        """
        client = await self._get_async_client()

        payload = {}

        if config.name:
            payload["name"] = config.name
        if config.meta_fields:
            payload["meta_fields"] = config.meta_fields
        if config.chunk_method:
            payload["chunk_method"] = config.chunk_method
        if config.parser_config:
            payload["parser_config"] = config.parser_config
        if config.enabled is not None:
            payload["enabled"] = config.enabled

        url = f"{self.base_url}/api/v1/datasets/{dataset_id}/documents/{document_id}"

        try:
            response = await client.put(url, json=payload)

            if response.status_code == 401:
                raise RAGAuthenticationError("认证失败，请检查 API Key")
            if response.status_code != 200:
                raise RAGError(f"更新文档失败: HTTP {response.status_code}")

            data = response.json()

            if data.get("code") != 0:
                raise RAGError(f"更新文档失败: {data}")

            return True

        except httpx.HTTPError as e:
            raise RAGNetworkError(f"网络错误: {e}") from e

    async def download_document(
        self, dataset_id: str, document_id: str, output_path: str
    ) -> bool:
        """异步下载文档

        Args:
            dataset_id: 数据集ID
            document_id: 文档ID
            output_path: 输出文件路径

        Returns:
            是否成功
        """
        client = await self._get_async_client()

        url = f"{self.base_url}/api/v1/datasets/{dataset_id}/documents/{document_id}"

        try:
            response = await client.get(url)

            if response.status_code == 401:
                raise RAGAuthenticationError("认证失败，请检查 API Key")
            if response.status_code != 200:
                raise RAGError(f"下载文档失败: HTTP {response.status_code}")

            with open(output_path, "wb") as f:
                f.write(response.content)

            return True

        except httpx.HTTPError as e:
            raise RAGNetworkError(f"网络错误: {e}") from e

    async def list_documents(
        self,
        dataset_id: str,
        page: int = 1,
        page_size: int = 30,
        orderby: str = "create_time",
        desc: bool = True,
        keywords: Optional[str] = None,
        document_id: Optional[str] = None,
        name: Optional[str] = None,
        suffix: Optional[str] = None,
        run: Optional[str] = None,
    ) -> List[Document]:
        """异步列出数据集中的文档

        Args:
            dataset_id: 数据集ID
            page: 页码
            page_size: 每页数量
            orderby: 排序字段
            desc: 是否降序
            keywords: 关键词
            document_id: 文档ID
            name: 文档名称
            suffix: 文件后缀
            run: 运行状态（UNSTART/RUNNING/SUCCESS/FAILED）

        Returns:
            文档列表
        """
        client = await self._get_async_client()

        params = {
            "page": page,
            "page_size": page_size,
            "orderby": orderby,
            "desc": "true" if desc else "false",
        }

        if keywords:
            params["keywords"] = keywords
        if document_id:
            params["id"] = document_id
        if name:
            params["name"] = name
        if suffix:
            params["suffix"] = suffix
        if run:
            params["run"] = run

        url = f"{self.base_url}/api/v1/datasets/{dataset_id}/documents"

        try:
            response = await client.get(url, params=params)

            if response.status_code == 401:
                raise RAGAuthenticationError("认证失败，请检查 API Key")
            if response.status_code != 200:
                raise RAGError(f"列出文档失败: HTTP {response.status_code}")

            data = response.json()

            if data.get("code") != 0:
                raise RAGError(f"列出文档失败: {data}")

            documents = []
            doc_list = data.get("data", [])

            if isinstance(doc_list, list):
                for doc_data in doc_list:
                    if isinstance(doc_data, dict):
                        documents.append(
                            Document(
                                id=doc_data.get("id", ""),
                                name=doc_data.get("name", ""),
                                dataset_id=dataset_id,
                                chunk_method=doc_data.get("chunk_method"),
                                size=doc_data.get("size", 0),
                                status=doc_data.get("run", "UNSTART"),
                                created_at=doc_data.get("create_time", ""),
                            )
                        )

            return documents

        except httpx.HTTPError as e:
            raise RAGNetworkError(f"网络错误: {e}") from e

    async def delete_documents(
        self, dataset_id: str, document_ids: Optional[List[str]] = None
    ) -> bool:
        """异步删除文档

        Args:
            dataset_id: 数据集ID
            document_ids: 文档ID列表，None 表示删除所有

        Returns:
            是否成功

        Raises:
            NotImplementedError: 暂不支持异步删除文档，请使用同步方法 delete_documents_sync
        """
        raise NotImplementedError(
            "httpx 不支持在 DELETE 请求中包含请求体。"
            "RAGFlow API 需要在 DELETE 请求中包含 JSON 数据，这与 HTTP 标准冲突。"
            "请使用同步方法 delete_documents_sync 代替。"
        )

    async def parse_documents(self, dataset_id: str, document_ids: List[str]) -> bool:
        """异步解析文档（将文档切分成分块）

        Args:
            dataset_id: 数据集ID
            document_ids: 文档ID列表

        Returns:
            是否成功
        """
        client = await self._get_async_client()

        payload = {"document_ids": document_ids}

        url = f"{self.base_url}/api/v1/datasets/{dataset_id}/chunks"

        try:
            response = await client.post(url, json=payload)

            if response.status_code == 401:
                raise RAGAuthenticationError("认证失败，请检查 API Key")
            if response.status_code != 200:
                raise RAGError(f"解析文档失败: HTTP {response.status_code}")

            data = response.json()

            if data.get("code") != 0:
                raise RAGError(f"解析文档失败: {data}")

            return True

        except httpx.HTTPError as e:
            raise RAGNetworkError(f"网络错误: {e}") from e

    async def stop_parsing(self, dataset_id: str, document_ids: List[str]) -> bool:
        """异步停止解析文档

        Args:
            dataset_id: 数据集ID
            document_ids: 文档ID列表

        Returns:
            是否成功
        """
        client = await self._get_async_client()

        payload = {"document_ids": document_ids}

        url = f"{self.base_url}/api/v1/datasets/{dataset_id}/chunks"

        try:
            response = await client.delete(url, json=payload)

            if response.status_code == 401:
                raise RAGAuthenticationError("认证失败，请检查 API Key")
            if response.status_code != 200:
                raise RAGError(f"停止解析失败: HTTP {response.status_code}")

            data = response.json()

            if data.get("code") != 0:
                raise RAGError(f"停止解析失败: {data}")

            return True

        except httpx.HTTPError as e:
            raise RAGNetworkError(f"网络错误: {e}") from e

    async def list_datasets(
        self,
        page: int = 1,
        page_size: int = 30,
        orderby: str = "create_time",
        desc: bool = True,
        dataset_id: Optional[str] = None,
        name: Optional[str] = None,
    ) -> List[Dataset]:
        """异步列出数据集

        Args:
            page: 页码，从 1 开始，默认为 1
            page_size: 每页返回的数据集数量，默认为 30
            orderby: 排序字段，可选值：
                - "create_time": 按创建时间排序（默认）
                - "update_time": 按更新时间排序
            desc: 是否降序排列，默认为 True（最新的在前）
            dataset_id: 按数据集ID精确过滤（可选），如果提供则只返回匹配的数据集
            name: 按数据集名称过滤（可选），支持模糊匹配

        Returns:
            数据集列表，每个数据集包含ID、名称、描述、分块方法、分块数量、文档数量、嵌入模型和创建时间

        Raises:
            RAGAuthenticationError: 认证失败
            RAGException: 列出数据集失败
            RAGNetworkError: 网络错误

        Example:
            >>> # 列出所有数据集（第一页）
            >>> datasets = await rag.list_datasets(page=1, page_size=10)
            >>>
            >>> # 按名称过滤
            >>> datasets = await rag.list_datasets(name="知识库")
        """
        client = await self._get_async_client()

        params = {
            "page": page,
            "page_size": page_size,
            "orderby": orderby,
            "desc": "true" if desc else "false",
        }

        if dataset_id:
            params["id"] = dataset_id
        if name:
            params["name"] = name

        url = f"{self.base_url}/api/v1/datasets"

        try:
            response = await client.get(url, params=params)

            if response.status_code == 401:
                raise RAGAuthenticationError("认证失败，请检查 API Key")
            if response.status_code != 200:
                raise RAGError(f"列出数据集失败: HTTP {response.status_code}")

            data = response.json()

            results = []
            if data.get("code") != 0:
                return results

            for item in data.get("data", []):
                results.append(
                    Dataset(
                        id=item.get("id", ""),
                        name=item.get("name", ""),
                        description=item.get("description"),
                        chunk_method=item.get("chunk_method"),
                        chunk_count=item.get("chunk_count", 0),
                        document_count=item.get("document_count", 0),
                        embedding_model=item.get("embedding_model"),
                        created_at=item.get("create_time", ""),
                    )
                )

            return results

        except httpx.HTTPError as e:
            raise RAGNetworkError(f"网络错误: {e}") from e

    async def create_assistant(self, config: AssistantConfig) -> Assistant:
        """异步创建助手"""
        client = await self._get_async_client()

        payload = {
            "name": config.name,
        }

        if config.description:
            payload["description"] = config.description

        if config.avatar:
            payload["avatar"] = config.avatar

        # 数据集ID
        if config.dataset_ids:
            payload["dataset_ids"] = config.dataset_ids

        # LLM 配置
        if config.llm:
            llm_config = {}
            if config.llm.model_name:
                llm_config["model_name"] = config.llm.model_name
            if config.llm.temperature is not None:
                llm_config["temperature"] = config.llm.temperature
            if config.llm.top_p is not None:
                llm_config["top_p"] = config.llm.top_p
            if config.llm.presence_penalty is not None:
                llm_config["presence_penalty"] = config.llm.presence_penalty
            if config.llm.frequency_penalty is not None:
                llm_config["frequency_penalty"] = config.llm.frequency_penalty
            if llm_config:
                payload["llm"] = llm_config

        # Prompt 配置
        if config.prompt:
            prompt_config = {}
            if config.prompt.similarity_threshold is not None:
                prompt_config["similarity_threshold"] = (
                    config.prompt.similarity_threshold
                )
            if config.prompt.keywords_similarity_weight is not None:
                prompt_config["keywords_similarity_weight"] = (
                    config.prompt.keywords_similarity_weight
                )
            if config.prompt.top_n is not None:
                prompt_config["top_n"] = config.prompt.top_n
            if config.prompt.variables is not None:
                prompt_config["variables"] = [
                    {"key": v.key, "optional": v.optional}
                    for v in config.prompt.variables
                ]
            if config.prompt.rerank_model:
                prompt_config["rerank_model"] = config.prompt.rerank_model
            if config.prompt.top_k is not None:
                prompt_config["top_k"] = config.prompt.top_k
            if config.prompt.empty_response is not None:
                prompt_config["empty_response"] = config.prompt.empty_response
            if config.prompt.opener is not None:
                prompt_config["opener"] = config.prompt.opener
            if config.prompt.show_quote is not None:
                prompt_config["show_quote"] = config.prompt.show_quote
            if config.prompt.prompt:
                # 如果 prompt 不包含 {knowledge}，自动添加
                if "{knowledge}" not in config.prompt.prompt:
                    prompt_config["prompt"] = f"{config.prompt.prompt}\n\n{{knowledge}}"
                else:
                    prompt_config["prompt"] = config.prompt.prompt
            if prompt_config:
                payload["prompt"] = prompt_config

        url = f"{self.base_url}/api/v1/chats"

        try:
            response = await client.post(url, json=payload)

            if response.status_code == 401:
                raise RAGAuthenticationError("认证失败，请检查 API Key")
            if response.status_code != 200:
                raise RAGError(f"创建助手失败: HTTP {response.status_code}")

            data = response.json()

            if data.get("code") != 0:
                raise RAGError(f"创建助手失败: {data}")

            result = data.get("data", {})

            return Assistant(
                id=result.get("id", ""),
                name=result.get("name", ""),
                description=result.get("description"),
                dataset_ids=result.get("dataset_ids", []),
                created_at=result.get("create_time", ""),
            )

        except httpx.HTTPError as e:
            raise RAGNetworkError(f"网络错误: {e}") from e

    async def create_session(
        self,
        chat_id: str,
        name: str = "New session",
        user_id: Optional[str] = None,
    ) -> Session:
        """异步创建会话

        Args:
            chat_id: 聊天助手ID，用于标识该会话属于哪个助手
            name: 会话名称，用于标识和区分不同的会话，默认为 "New session"
            user_id: 用户ID（可选），用于标识会话的归属用户。
                在多用户场景下，用于实现会话隔离和管理。
                如果不提供，会话将属于当前 API Key 的所有者。
                可以是任意格式的用户标识（如 UUID、邮箱、用户名等）。

        Returns:
            会话信息，包含会话ID、名称、助手ID、用户ID和创建时间

        Raises:
            RAGAuthenticationError: 认证失败
            RAGException: 创建会话失败
            RAGNetworkError: 网络错误

        Example:
            >>> # 单用户场景（不传 user_id）
            >>> session = await rag.create_session(
            ...     chat_id="assistant-id",
            ...     name="我的学习会话"
            ... )
            >>>
            >>> # 多用户场景（传入 user_id）
            >>> session = await rag.create_session(
            ...     chat_id="assistant-id",
            ...     name="用户的学习会话",
            ...     user_id="user-123"
            ... )
        """
        client = await self._get_async_client()

        payload = {"name": name}
        if user_id:
            payload["user_id"] = user_id

        url = f"{self.base_url}/api/v1/chats/{chat_id}/sessions"

        try:
            response = await client.post(url, json=payload)

            if response.status_code == 401:
                raise RAGAuthenticationError("认证失败，请检查 API Key")
            if response.status_code != 200:
                raise RAGError(f"创建会话失败: HTTP {response.status_code}")

            data = response.json()

            if data.get("code") != 0:
                raise RAGError(f"创建会话失败: {data}")

            result = data.get("data", {})

            return Session(
                id=result.get("id", ""),
                name=result.get("name", ""),
                assistant_id=chat_id,
                user_id=result.get("user_id"),
                created_at=result.get("create_time", ""),
            )

        except httpx.HTTPError as e:
            raise RAGNetworkError(f"网络错误: {e}") from e

    async def update_assistant(
        self, chat_id: str, config: AssistantUpdateConfig
    ) -> bool:
        """异步更新助手"""
        client = await self._get_async_client()

        payload = {}

        if config.name:
            payload["name"] = config.name
        if config.description:
            payload["description"] = config.description
        if config.avatar:
            payload["avatar"] = config.avatar
        if config.dataset_ids:
            payload["dataset_ids"] = config.dataset_ids

        if config.llm:
            llm_config = {}
            if config.llm.model_name:
                llm_config["model_name"] = config.llm.model_name
            if config.llm.temperature is not None:
                llm_config["temperature"] = config.llm.temperature
            if config.llm.top_p is not None:
                llm_config["top_p"] = config.llm.top_p
            if config.llm.presence_penalty is not None:
                llm_config["presence_penalty"] = config.llm.presence_penalty
            if config.llm.frequency_penalty is not None:
                llm_config["frequency_penalty"] = config.llm.frequency_penalty
            if llm_config:
                payload["llm"] = llm_config

        if config.prompt:
            prompt_config = {}
            if config.prompt.similarity_threshold is not None:
                prompt_config["similarity_threshold"] = (
                    config.prompt.similarity_threshold
                )
            if config.prompt.keywords_similarity_weight is not None:
                prompt_config["keywords_similarity_weight"] = (
                    config.prompt.keywords_similarity_weight
                )
            if config.prompt.top_n is not None:
                prompt_config["top_n"] = config.prompt.top_n
            if config.prompt.variables is not None:
                prompt_config["variables"] = [
                    {"key": v.key, "optional": v.optional}
                    for v in config.prompt.variables
                ]
            if config.prompt.rerank_model is not None:
                prompt_config["rerank_model"] = config.prompt.rerank_model
            if config.prompt.top_k is not None:
                prompt_config["top_k"] = config.prompt.top_k
            if config.prompt.empty_response is not None:
                prompt_config["empty_response"] = config.prompt.empty_response
            if config.prompt.opener is not None:
                prompt_config["opener"] = config.prompt.opener
            if config.prompt.show_quote is not None:
                prompt_config["show_quote"] = config.prompt.show_quote
            if config.prompt.prompt is not None:
                if "{knowledge}" not in config.prompt.prompt:
                    prompt_config["prompt"] = f"{config.prompt.prompt}\n\n{{knowledge}}"
                else:
                    prompt_config["prompt"] = config.prompt.prompt
            if prompt_config:
                payload["prompt"] = prompt_config

        url = f"{self.base_url}/api/v1/chats/{chat_id}"

        try:
            response = await client.put(url, json=payload)

            if response.status_code == 401:
                raise RAGAuthenticationError("认证失败，请检查 API Key")
            if response.status_code != 200:
                raise RAGError(f"更新助手失败: HTTP {response.status_code}")

            data = response.json()

            if data.get("code") != 0:
                raise RAGError(f"更新助手失败: {data}")

            return True

        except httpx.HTTPError as e:
            raise RAGNetworkError(f"网络错误: {e}") from e

    async def delete_assistant(self, chat_ids: Optional[List[str]] = None) -> bool:
        """异步删除助手

        Args:
            chat_ids: 助手ID列表，None 表示删除所有，空列表表示不删除

        Raises:
            NotImplementedError: 暂不支持异步删除助手，请使用同步方法 delete_assistant_sync
        """
        raise NotImplementedError(
            "httpx 不支持在 DELETE 请求中包含请求体。"
            "RAGFlow API 需要在 DELETE 请求中包含 JSON 数据，这与 HTTP 标准冲突。"
            "请使用同步方法 delete_assistant_sync 代替。"
        )

    async def list_assistants(
        self,
        page: int = 1,
        page_size: int = 30,
        orderby: str = "create_time",
        desc: bool = True,
        chat_id: Optional[str] = None,
        name: Optional[str] = None,
    ) -> List[Assistant]:
        """异步列出助手

        Args:
            page: 页码，从 1 开始，默认为 1
            page_size: 每页返回的助手数量，默认为 30
            orderby: 排序字段，可选值：
                - "create_time": 按创建时间排序（默认）
                - "update_time": 按更新时间排序
            desc: 是否降序排列，默认为 True（最新的在前）
            chat_id: 按助手ID精确过滤（可选），如果提供则只返回匹配的助手
            name: 按助手名称过滤（可选），支持模糊匹配

        Returns:
            助手列表，每个助手包含ID、名称、描述、关联的数据集ID和创建时间

        Raises:
            RAGAuthenticationError: 认证失败
            RAGException: 列出助手失败
            RAGNetworkError: 网络错误

        Example:
            >>> # 列出所有助手（第一页）
            >>> assistants = await rag.list_assistants(page=1, page_size=10)
            >>>
            >>> # 按名称过滤
            >>> assistants = await rag.list_assistants(name="AI助手")
            >>>
            >>> # 按ID精确查找
            >>> assistants = await rag.list_assistants(chat_id="specific-id")
        """
        client = await self._get_async_client()

        params = {
            "page": page,
            "page_size": page_size,
            "orderby": orderby,
            "desc": "true" if desc else "false",
        }

        if chat_id:
            params["id"] = chat_id
        if name:
            params["name"] = name

        url = f"{self.base_url}/api/v1/chats"

        try:
            response = await client.get(url, params=params)

            if response.status_code == 401:
                raise RAGAuthenticationError("认证失败，请检查 API Key")
            if response.status_code != 200:
                raise RAGError(f"列出助手失败: HTTP {response.status_code}")

            data = response.json()

            results = []
            if data.get("code") != 0:
                return results

            for item in data.get("data", []):
                results.append(
                    Assistant(
                        id=item.get("id", ""),
                        name=item.get("name", ""),
                        description=item.get("description"),
                        dataset_ids=item.get("dataset_ids", []),
                        created_at=item.get("create_time", ""),
                    )
                )

            return results

        except httpx.HTTPError as e:
            raise RAGNetworkError(f"网络错误: {e}") from e

    async def update_session(
        self, chat_id: str, session_id: str, config: SessionUpdateConfig
    ) -> bool:
        """异步更新会话"""
        client = await self._get_async_client()

        payload = {}

        if config.name:
            payload["name"] = config.name
        if config.user_id:
            payload["user_id"] = config.user_id

        url = f"{self.base_url}/api/v1/chats/{chat_id}/sessions/{session_id}"

        try:
            response = await client.put(url, json=payload)

            if response.status_code == 401:
                raise RAGAuthenticationError("认证失败，请检查 API Key")
            if response.status_code != 200:
                raise RAGError(f"更新会话失败: HTTP {response.status_code}")

            data = response.json()

            if data.get("code") != 0:
                raise RAGError(f"更新会话失败: {data}")

            return True

        except httpx.HTTPError as e:
            raise RAGNetworkError(f"网络错误: {e}") from e

    async def delete_sessions(
        self, chat_id: str, session_ids: Optional[List[str]] = None
    ) -> bool:
        """异步删除会话

        Args:
            chat_id: 助手ID
            session_ids: 会话ID列表，None 表示删除所有，空列表表示不删除

        Raises:
            NotImplementedError: httpx 不支持在 DELETE 请求中包含请求体
        """
        raise NotImplementedError(
            "httpx 不支持在 DELETE 请求中包含请求体。"
            "RAGFlow API 需要在 DELETE 请求中包含 JSON 数据，这与 HTTP 标准冲突。"
        )

    async def list_sessions(
        self,
        chat_id: str,
        page: int = 1,
        page_size: int = 30,
        orderby: str = "create_time",
        desc: bool = True,
        session_id: Optional[str] = None,
        name: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> List[Session]:
        """异步列出会话

        Args:
            chat_id: 聊天助手ID，必需参数，用于指定要查询哪个助手下的会话
            page: 页码，从 1 开始，默认为 1
            page_size: 每页返回的会话数量，默认为 30
            orderby: 排序字段，可选值：
                - "create_time": 按创建时间排序（默认）
                - "update_time": 按更新时间排序
            desc: 是否降序排列，默认为 True（最新的在前）
            session_id: 按会话ID精确过滤（可选），如果提供则只返回匹配的会话
            name: 按会话名称过滤（可选），支持模糊匹配
            user_id: 按用户ID过滤（可选），用于在多用户场景下只返回特定用户的会话。
                如果不提供，则返回该助手下的所有会话（不区分用户）。
                常用于实现用户会话隔离和权限控制。

        Returns:
            会话列表，每个会话包含ID、名称、助手ID、用户ID和创建时间

        Raises:
            RAGAuthenticationError: 认证失败
            RAGException: 列出会话失败
            RAGNetworkError: 网络错误

        Example:
            >>> # 列出助手下的所有会话
            >>> sessions = await rag.list_sessions(
            ...     chat_id="assistant-id",
            ...     page=1,
            ...     page_size=20
            ... )
            >>>
            >>> # 只列出特定用户的会话（多用户场景）
            >>> user_sessions = await rag.list_sessions(
            ...     chat_id="assistant-id",
            ...     user_id="user-123"
            ... )
            >>>
            >>> # 按名称过滤
            >>> sessions = await rag.list_sessions(
            ...     chat_id="assistant-id",
            ...     name="学习"
            ... )
        """
        client = await self._get_async_client()

        params = {
            "page": page,
            "page_size": page_size,
            "orderby": orderby,
            "desc": "true" if desc else "false",
        }

        if session_id:
            params["id"] = session_id
        if name:
            params["name"] = name
        if user_id:
            params["user_id"] = user_id

        url = f"{self.base_url}/api/v1/chats/{chat_id}/sessions"

        try:
            response = await client.get(url, params=params)

            if response.status_code == 401:
                raise RAGAuthenticationError("认证失败，请检查 API Key")
            if response.status_code != 200:
                raise RAGError(f"列出会话失败: HTTP {response.status_code}")

            data = response.json()

            if data.get("code") != 0:
                raise RAGError(f"列出会话失败: {data}")

            results = []
            for item in data.get("data", []):
                results.append(
                    Session(
                        id=item.get("id", ""),
                        name=item.get("name", ""),
                        assistant_id=chat_id,
                        user_id=item.get("user_id"),
                        created_at=item.get("create_time", ""),
                    )
                )

            return results

        except httpx.HTTPError as e:
            raise RAGNetworkError(f"网络错误: {e}") from e

    async def chat(self, request: ChatRequest, chat_id: str) -> ChatResponse:
        """异步对话实现"""
        total_start = time.perf_counter()
        try:
            self.validate_request(request)
            if request.stream:
                raise RAGError("流式模式请使用 chat_stream 方法")

            client = await self._get_async_client()
            payload = self._build_chat_payload(request)
            url = f"{self.base_url}/api/v1/chats/{chat_id}/completions"

            try:
                start_time = time.perf_counter()
                response = await client.post(url, json=payload)
                post_duration = time.perf_counter() - start_time
                self.logger.debug(f"post_request_time: {post_duration:.4f} s")
                if response.status_code == 401:
                    raise RAGAuthenticationError("认证失败，请检查 API Key")
                if response.status_code != 200:
                    raise RAGError(f"对话失败: HTTP {response.status_code}")

                try:
                    data = response.json()
                except json.JSONDecodeError as e:
                    raise RAGError(f"响应数据解析失败: {e}") from e

                if data.get("code") != 0:
                    raise RAGError(f"对话失败: {data}")
                result = data.get("data", {})
                return ChatResponse(
                    content=result.get("content", "") or result.get("answer", ""),
                    session_id=request.session_id or result.get("session_id", ""),
                    message_id=result.get("id", ""),
                    sources=self._parse_sources(result.get("reference", {})),
                    usage=self._parse_usage(result.get("usage")),
                )

            except httpx.HTTPError as e:
                raise RAGNetworkError(f"网络错误: {e}") from e
        finally:
            duration = time.perf_counter() - total_start
            self.logger.info("chat 异步总耗时 %.4f s", duration)

    async def chat_stream(
        self, request: ChatRequest, chat_id: str
    ) -> AsyncIterator[ChatResponse]:
        """异步流式对话实现"""
        self.logger.debug(f"开始异步流式对话：对话消息: {request.message[:100]}...")
        self.validate_request(request)

        client = await self._get_async_client()
        payload = self._build_chat_payload(request)
        payload["stream"] = True

        url = f"{self.base_url}/api/v1/chats/{chat_id}/completions"

        try:
            start_time = time.perf_counter()
            async with client.stream("POST", url, json=payload) as response:
                if response.status_code != 200:
                    self.logger.error(f"流式对话失败: HTTP {response.status_code}")
                    raise RAGError(f"流式对话失败: HTTP {response.status_code}")

                content = ""
                sources = []
                chunk_count = 0
                # print(response.__dict__)

                async for line in response.aiter_lines():
                    # print(f"{line=}")
                    if line.startswith("data:"):
                        try:
                            json_str = line[5:].strip()
                            resp_dict = json.loads(json_str)
                            data = resp_dict.get("data")
                            if isinstance(data, dict):
                                new_content = data.get("answer")
                                if new_content:
                                    content += new_content
                                    chunk_count += 1
                                    yield ChatResponse(
                                        content=new_content,
                                        session_id=request.session_id or "",
                                        message_id=data.get("id", ""),
                                        sources=sources,
                                    )
                                if data.get("reference"):
                                    sources = self._parse_sources(data["reference"])
                        except json.JSONDecodeError as e:
                            self.logger.warning(f"JSON解析错误: {e}")
                            continue
                    elif line.strip() == "[DONE]":
                        self.logger.info(
                            f"异步流式对话完成: 总长度={len(content)}, 分片数={chunk_count}"
                        )
                        break
                    elif line.startswith('{"code":'):
                        self.logger.error(f"流式对话错误: {line}")
                        raise RAGError(f"流式对话错误: {line}")
            duration = time.perf_counter() - start_time
            self.logger.debug(f"chat_stream_time: {duration:.4f} s")
        except httpx.HTTPError as e:
            self.logger.error(f"网络错误: {e}")
            raise RAGNetworkError(f"网络错误: {e}") from e

    async def search(self, request: SearchRequest) -> List[SearchResult]:
        """异步检索实现"""
        self.logger.info(
            f"开始异步检索: query={request.query[:50]}..., top_k={request.top_k}"
        )

        self.validate_request(request)

        client = await self._get_async_client()
        payload = self._build_search_payload(request)

        url = f"{self.base_url}/api/v1/retrieval"

        try:
            self.logger.debug(f"发送异步检索请求: {url}")
            start_time = time.perf_counter()
            response = await client.post(url, json=payload)
            post_duration = time.perf_counter() - start_time
            self.logger.debug(f"post_request_time: {post_duration:.4f} s")
            if response.status_code != 200:
                self.logger.error(f"检索失败: HTTP {response.status_code}")
                raise RAGError(f"检索失败: HTTP {response.status_code}")

            try:
                data = response.json()
            except json.JSONDecodeError as e:
                raise RAGError(f"响应数据解析失败: {e}") from e

            if data.get("code") != 0:
                self.logger.error(f"检索失败: {data}")
                raise RAGError(f"检索失败: {data}")

            results = []
            for chunk_data in data.get("data", {}).get("chunks", []):
                results.append(
                    SearchResult(
                        content=chunk_data.get("content", ""),
                        score=chunk_data.get("similarity", 0.0),
                        document_id=chunk_data.get("document_id", ""),
                        chunk_id=chunk_data.get("id", ""),
                        metadata=chunk_data.get("metadata", {}),
                    )
                )

            self.logger.info(f"异步检索成功: 返回 {len(results)} 个结果")
            return results

        except httpx.HTTPError as e:
            self.logger.error(f"网络错误: {e}")
            raise RAGNetworkError(f"网络错误: {e}") from e

    def close(self):
        """同步关闭资源"""
        if self._sync_client and not self._sync_client.is_closed:
            self._sync_client.close()
            self.logger.debug("同步 HTTP 客户端已关闭")

    async def aclose(self):
        """异步关闭资源"""
        if self._async_client and not self._async_client.is_closed:
            await self._async_client.aclose()
            self.logger.debug("异步 HTTP 客户端已关闭")

    def __del__(self):
        """清理资源（析构函数）"""
        # 注意：__del__ 中不能 await，所以异步客户端无法在这里关闭
        # 建议使用 close() 或 aclose() 方法显式关闭
        if self._sync_client and not self._sync_client.is_closed:
            try:
                self._sync_client.close()
            except Exception as e:
                self.logger.warning(f"析构时关闭同步客户端失败: {e}")
