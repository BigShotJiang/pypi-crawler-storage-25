"""
RAG 配置管理
"""

from dataclasses import dataclass, field
import os
from typing import Any, Dict

from soulshell_base.core import get_logger

logger = get_logger(__name__)


@dataclass
class RAGProviderConfig:
    """RAG 提供商配置"""

    provider_name: str
    extra_params: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_env(cls, provider_name: str, prefix: str = "RAG") -> "RAGProviderConfig":
        """从环境变量加载配置

        Args:
            provider_name: 提供商名称
            prefix: 环境变量前缀

        Returns:
            配置对象

        Example:
            # 环境变量: RAG_RAGFLOW_API_KEY, RAG_RAGFLOW_BASE_URL
            config = RAGProviderConfig.from_env("ragflow")
        """
        env_prefix = f"{prefix}_{provider_name.upper()}_"

        extra_params: Dict[str, Any] = {}
        for key, value in os.environ.items():
            if key.startswith(env_prefix):
                param_key = key[len(env_prefix) :].lower()
                extra_params[param_key] = value

        if not extra_params:
            raise ValueError(f"未找到以 {env_prefix} 开头的任何环境变量")

        logger.debug(f"从环境变量加载 {provider_name} 配置")
        return cls(provider_name=provider_name, extra_params=extra_params)

    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> "RAGProviderConfig":
        """从字典加载配置

        Args:
            config_dict: 配置字典

        Returns:
            配置对象
        """
        provider_name = config_dict.pop("provider_name", None)
        if not provider_name:
            raise ValueError("provider_name 不能为空")

        return cls(provider_name=provider_name, extra_params=config_dict)

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {"provider_name": self.provider_name, **self.extra_params}
