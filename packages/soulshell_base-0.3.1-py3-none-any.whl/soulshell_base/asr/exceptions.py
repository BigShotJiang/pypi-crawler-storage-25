"""
ASR 模块自定义异常
"""

from typing import Optional


class ASRException(Exception):  # noqa: N818
    """ASR 基础异常"""

    def __init__(self, message: str, error_code: Optional[str] = None):
        self.message = message
        self.error_code = error_code
        super().__init__(self.message)


class ASRProviderNotFoundError(ASRException):
    """ASR 提供商未找到"""


class ASRAuthenticationError(ASRException):
    """ASR 认证失败"""


class ASRRateLimitError(ASRException):
    """ASR 限流错误"""


class ASRInvalidParameterError(ASRException):
    """ASR 参数错误"""


class ASRServiceUnavailableError(ASRException):
    """ASR 服务不可用"""


class ASRNetworkError(ASRException):
    """ASR 网络错误"""


class ASRSynthesisError(ASRException):
    """ASR 合成失败"""


class ASRRecognitionError(ASRException):
    """ASR 识别失败"""
