"""
ASR 抽象基类
"""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, AsyncIterator, Dict, List

from soulshell_base.core import get_logger

from .exceptions import ASRInvalidParameterError
from .models import (
    ASRErrorCallback,
    ASRRecognizeRequest,
    ASRResponse,
    ASRResultCallback,
    ASRSimpleCallback,
    AudioCodec,
    AudioFormat,
)


class BaseASR(ABC):
    """ASR 抽象基类"""

    def __init__(self, **kwargs):
        """初始化 ASR 提供商

        Args:
            **kwargs: 配置参数（例如 api_key、appid、cluster 等），由具体 Provider 自行约定
        """
        self.config = kwargs
        self.logger = get_logger(
            f"{self.__class__.__module__}.{self.__class__.__name__}",
            level=self.config.get("log_level", "INFO"),
        )

        # 回调列表
        self._on_start_callbacks: List[ASRSimpleCallback] = []
        self._on_partial_callbacks: List[ASRResultCallback] = []
        self._on_final_callbacks: List[ASRResultCallback] = []
        self._on_error_callbacks: List[ASRErrorCallback] = []
        self._on_close_callbacks: List[ASRSimpleCallback] = []

        # 流式状态
        self._stream_started: bool = False

    # ============ 回调注册（链式调用） ============

    def on_start(self, callback: ASRSimpleCallback) -> "BaseASR":
        """注册开始回调

        Args:
            callback: 回调函数，无参数

        Returns:
            self，支持链式调用
        """
        self._on_start_callbacks.append(callback)
        return self

    def on_partial(self, callback: ASRResultCallback) -> "BaseASR":
        """注册中间结果回调

        Args:
            callback: 回调函数，参数为 ASRResponse

        Returns:
            self，支持链式调用
        """
        self._on_partial_callbacks.append(callback)
        return self

    def on_final(self, callback: ASRResultCallback) -> "BaseASR":
        """注册最终结果回调

        Args:
            callback: 回调函数，参数为 ASRResponse

        Returns:
            self，支持链式调用
        """
        self._on_final_callbacks.append(callback)
        return self

    def on_error(self, callback: ASRErrorCallback) -> "BaseASR":
        """注册错误回调

        Args:
            callback: 回调函数，参数为 Exception

        Returns:
            self，支持链式调用
        """
        self._on_error_callbacks.append(callback)
        return self

    def on_close(self, callback: ASRSimpleCallback) -> "BaseASR":
        """注册关闭回调

        Args:
            callback: 回调函数，无参数

        Returns:
            self，支持链式调用
        """
        self._on_close_callbacks.append(callback)
        return self

    def clear_callbacks(self) -> None:
        """清空所有回调"""
        self._on_start_callbacks.clear()
        self._on_partial_callbacks.clear()
        self._on_final_callbacks.clear()
        self._on_error_callbacks.clear()
        self._on_close_callbacks.clear()

    # ============ 内部触发方法 ============

    def _emit_start(self) -> None:
        """触发开始回调"""
        for cb in self._on_start_callbacks:
            try:
                cb()
            except Exception as e:
                self.logger.error(f"on_start 回调执行失败: {e}")

    def _emit_partial(self, response: ASRResponse) -> None:
        """触发中间结果回调"""
        for cb in self._on_partial_callbacks:
            try:
                cb(response)
            except Exception as e:
                self.logger.error(f"on_partial 回调执行失败: {e}")

    def _emit_final(self, response: ASRResponse) -> None:
        """触发最终结果回调"""
        for cb in self._on_final_callbacks:
            try:
                cb(response)
            except Exception as e:
                self.logger.error(f"on_final 回调执行失败: {e}")

    def _emit_error(self, error: Exception) -> None:
        """触发错误回调"""
        for cb in self._on_error_callbacks:
            try:
                cb(error)
            except Exception as e:
                self.logger.error(f"on_error 回调执行失败: {e}")

    def _emit_close(self) -> None:
        """触发关闭回调"""
        for cb in self._on_close_callbacks:
            try:
                cb()
            except Exception as e:
                self.logger.error(f"on_close 回调执行失败: {e}")

    # ============ 流式接口 ============

    def start_stream(self, request: ASRRecognizeRequest) -> None:
        """启动流式识别会话

        Args:
            request: 识别参数配置（streaming_mode 应为 True）

        Raises:
            NotImplementedError: 如果提供商不支持流式接口
        """
        raise NotImplementedError(f"{self.get_provider_name()} 不支持流式接口")

    def feed_audio_chunk(self, pcm_chunk: bytes) -> None:
        """推送音频数据块

        Args:
            pcm_chunk: PCM 格式音频数据

        Raises:
            NotImplementedError: 如果提供商不支持流式接口
        """
        raise NotImplementedError(f"{self.get_provider_name()} 不支持流式接口")

    def stop_stream(self) -> None:
        """停止流式识别会话

        Raises:
            NotImplementedError: 如果提供商不支持流式接口
        """
        raise NotImplementedError(f"{self.get_provider_name()} 不支持流式接口")

    @property
    def is_streaming(self) -> bool:
        """当前是否处于流式识别状态"""
        return self._stream_started

    # ============ 原有接口 ============

    @abstractmethod
    def get_provider_name(self) -> str:
        """
        获取供应商名称

        Returns:
            str: 供应商名称
        """

    def recognize_sync(self, request: ASRRecognizeRequest) -> ASRResponse:
        """
        同步语音识别（可选实现）

        Args:
            request: 识别请求参数（ASRRecognizeRequest）

        Returns:
            ASRResponse: 识别结果

        Raises:
            NotImplementedError: 如果提供商不支持同步接口
        """
        raise NotImplementedError(f"{self.get_provider_name()} 不支持同步接口")

    @abstractmethod
    async def recognize(self, request: ASRRecognizeRequest) -> ASRResponse:
        """
        异步语音识别

        Args:
            request: 识别请求参数（ASRRecognizeRequest）

        Returns:
            ASRResponse: 识别结果
        """
        raise NotImplementedError(f"{self.get_provider_name()} 不支持异步接口")

    async def recognize_stream(
        self,
        request: ASRRecognizeRequest,  # noqa:ARG002
    ) -> AsyncIterator[ASRResponse]:
        """
        流式语音识别（可选实现）

        Args:
            request: 识别请求参数（ASRRecognizeRequest）

        Yields:
            ASRResponse: 识别结果

        Raises:
            NotImplementedError: 如果提供商不支持流式接口
        """
        raise NotImplementedError(f"{self.get_provider_name()} 不支持流式接口")
        yield  # for type hints

    @classmethod
    @abstractmethod
    def describe(cls) -> Dict[str, Any]:
        """获取提供商描述信息（自描述能力）

        Returns:
            包含以下字段的字典：
            - provider_name: 提供商名称
            - display_name: 显示名称
            - description: 描述
            - required_init_params: 必填创建参数 {参数名: {type, description, env_var?, example?}}
            - optional_init_params: 可选创建参数 {参数名: {type, description, default}}
            - supported_methods: 支持的识别方式列表
            - example: 完整示例

        Example:
            >>> from soulshell_base.asr.providers.asr_volcengine import VolcengineASRProvider
            >>> info = VolcengineASRProvider.describe()
            >>> print(info['required_init_params'])
            {'token': {'type': 'str', 'description': '访问令牌', ...}}
        """

    @abstractmethod
    def validate_config(self) -> bool:
        """
        验证配置参数（可重写）

        Returns:
            bool: 配置是否有效
        """
        return True

    def validate_request(self, request: ASRRecognizeRequest) -> None:
        """
        验证请求参数（可重写）

        Args:
            request: 识别请求参数

        Raises:
            ASRInvalidParameterError: 参数无效
        """
        # 流式模式下跳过音频数据验证
        if not request.streaming_mode:
            if not request.audio_data and not request.audio_stream:
                raise ASRInvalidParameterError("音频数据不能为空")
        if not request.language:
            raise ASRInvalidParameterError("语言不能为空")

    async def recognize_file(
        self,
        file_path: str | Path,
        language: str = "zh-CN",
        audio_format: AudioFormat = AudioFormat.WAV,
        sample_rate: int = 16000,
        bits: int = 16,
        channel: int = 1,
        codec: AudioCodec = AudioCodec.RAW,
        **extra_params,
    ) -> ASRResponse:
        """便捷方法：从文件读取并识别

        Args:
            file_path: 音频文件路径
            language: 语言
            audio_format: 音频格式（与 ASRRecognizeRequest.audio_format 对应）
            sample_rate: 采样率
            bits: 位深
            channel: 声道数
            codec: 编解码类型
            **extra_params: 额外参数
        """
        p = Path(file_path)
        if not p.exists():
            raise ASRInvalidParameterError(f"音频文件不存在: {p}")
        audio_data = p.read_bytes()
        request = ASRRecognizeRequest(
            audio_data=audio_data,
            language=language,
            audio_format=audio_format,
            sample_rate=sample_rate,
            bits=bits,
            channel=channel,
            codec=codec,
            extra_params=extra_params,
        )
        return await self.recognize(request)
