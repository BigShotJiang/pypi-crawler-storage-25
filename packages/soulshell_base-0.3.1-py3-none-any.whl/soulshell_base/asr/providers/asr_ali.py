"""
阿里引擎 ASR 提供商实现
文档: https://help.aliyun.com/zh/isi/developer-reference/sdk-for-python?spm=a2c4g.11186623.0.i9
"""

import asyncio
import json
import time
from typing import Any, AsyncIterator

try:
    import aiohttp

    AIOHTTP_AVAILABLE = True
except ImportError:
    AIOHTTP_AVAILABLE = False
    aiohttp = None

try:
    import websockets

    WEBSOCKETS_AVAILABLE = True
except ImportError:
    WEBSOCKETS_AVAILABLE = False
    websockets = None

from aliyunsdkcore.client import AcsClient
from aliyunsdkcore.request import CommonRequest
import nls

from soulshell_base.core import RuntimeStateManager, get_logger

from ..base import BaseASR
from ..config import ASRConfigManager
from ..exceptions import (
    ASRRecognitionError,
)
from ..models import ASRRecognizeRequest, ASRResponse

logger = get_logger(__name__)


class ASRProviderALi(BaseASR):
    """阿里 ASR 提供商"""

    def __init__(
        self,
        api_key: str,
        ak: str,
        sk: str,
        **kwargs,
    ):
        super().__init__(**kwargs)

        if not WEBSOCKETS_AVAILABLE:
            raise ImportError(
                "需要安装 websockets 库才能使用阿里引擎 ASR。"
                "请运行: pip install websockets"
            )

        # 使用ASR模块的配置管理器获取默认配置
        self.asr_config_manager = ASRConfigManager()
        self.api_key = api_key
        self.ak = ak
        self.sk = sk

        # 从kwargs或默认配置获取参数
        self.region_id = kwargs.get(
            "region_id",
            self.asr_config_manager.get_default_config(
                "asr_ali", "REGION_ID", "cn-shanghai"
            ),
        )
        self.token_domain = kwargs.get(
            "token_domain",
            self.asr_config_manager.get_default_config(
                "asr_ali", "TOKEN_DOMAIN", "nls-meta.cn-shanghai.aliyuncs.com"
            ),
        )
        self.token_version = kwargs.get(
            "token_version",
            self.asr_config_manager.get_default_config(
                "asr_ali", "TOKEN_VERSION", "2019-02-28"
            ),
        )

        # 使用RuntimeStateManager进行token持久化
        self.state_manager = RuntimeStateManager.get_instance()
        self.module_name = "asr_ali"

        # 流式识别相关属性
        self._stream_recognizer = None
        self._stream_request = None
        self._last_partial_text = ""
        self.started = False

        self.logger.info("初始化阿里引擎 ASR")

    def get_provider_name(self) -> str:
        """获取提供商名称"""
        return "asr_ali"

    @classmethod
    def describe(cls) -> dict[str, Any]:
        """获取提供商描述信息（自描述能力）"""
        return {
            "provider_name": "asr_ali",
            "display_name": "阿里 ASR",
            "description": "阿里云智能语音交互 ASR 服务",
            "required_init_params": {
                "api_key": {
                    "type": "str",
                    "description": "API Key",
                },
                "ak": {
                    "type": "str",
                    "description": "AccessKey ID",
                },
                "sk": {
                    "type": "str",
                    "description": "AccessKey Secret",
                },
            },
            "optional_init_params": {
                "region_id": {
                    "type": "str",
                    "description": "地域 ID",
                    "default": "cn-shanghai",
                },
                "token_domain": {
                    "type": "str",
                    "description": "Token 域名",
                    "default": "nls-meta.cn-shanghai.aliyuncs.com",
                },
                "token_version": {
                    "type": "str",
                    "description": "Token 版本",
                    "default": "2019-02-28",
                },
            },
            "supported_methods": [
                "recognize: 同步识别",
                "recognize_stream: 流式识别",
            ],
        }

    def validate_config(self) -> bool:
        """验证配置"""
        if not self.sk:
            self.logger.error("缺少 sk")
            return False
        if not self.ak:
            self.logger.error("缺少 ak")
            return False
        return True

    def validate_request(self, request: ASRRecognizeRequest) -> None:
        """请求参数校验"""
        # 复用基类的基础校验
        super().validate_request(request)
        # 额外校验：编码与格式基本可用
        if not hasattr(request.audio_format, "value"):
            raise ASRRecognitionError("音频格式无效")
        if not hasattr(request.codec, "value"):
            raise ASRRecognitionError("音频编解码标识无效")

    async def recognize(self, request: ASRRecognizeRequest) -> ASRResponse:
        """
        异步识别音频

        Args:
            request: ASR 识别请求

        Returns:
            ASRResponse: 识别响应
        """
        try:
            # 验证请求
            self.validate_request(request)

            # 执行识别
            return await self._on_start_recognize(request)

        except Exception as e:
            self.logger.error(f"阿里引擎 ASR 识别失败: {e}")
            return ASRResponse.failed(error_message=f"阿里引擎 ASR 识别失败: {e!s}")

    def _ensure_token(self) -> str:
        """确保有效的token，如果过期则刷新（使用持久化缓存）"""
        # 尝试从持久化缓存获取token
        cached_token = self.state_manager.get_state(
            self.module_name, f"{self.api_key}_token", default=""
        )

        if cached_token:
            logger.info(f"使用持久化缓存的token: {cached_token[:20]}...")
            return cached_token

        # 缓存中没有token或已过期，从API获取新token
        logger.info("持久化缓存中没有有效token，从API获取新token")
        try:
            if AcsClient is None or CommonRequest is None:
                logger.error("Aliyun ASR: AcsClient or CommonRequest is None")
                return ""

            client = AcsClient(self.ak, self.sk, self.region_id)
            req = CommonRequest()
            req.set_method("POST")
            req.set_domain(self.token_domain)
            req.set_version(self.token_version)
            req.set_action_name("CreateToken")
            resp = client.do_action_with_exception(req)
            logger.info(f"Aliyun token API响应: {resp}")

            data = json.loads(resp)
            token = data.get("Token", {}).get("Id", "")
            expire = float(data.get("Token", {}).get("ExpireTime", 0))

            if token and expire > 0:
                # 计算TTL（提前1小时过期以确保安全）
                ttl = int(expire - time.time() - 3600)
                if ttl > 0:
                    # 保存到持久化缓存
                    self.state_manager.set_state(
                        self.module_name, f"{self.api_key}_token", token, ttl=ttl
                    )
                    logger.info(
                        f"新token已保存到持久化缓存，TTL: {ttl}秒 (~{ttl / 3600:.1f}小时)"
                    )
                    logger.info(f"Token: {token[:20]}..., 过期时间: {expire}")
                else:
                    logger.warning(f"Token即将过期，TTL={ttl}，不进行缓存")
                return token

            logger.error(f"Aliyun token refresh failed: {resp}")
        except Exception as e:
            logger.error(f"Refresh Aliyun token failed: {e}")
        return ""

    async def recognize_stream(
        self,
        request: ASRRecognizeRequest,
    ) -> AsyncIterator[ASRResponse]:
        """
        流式语音识别 - 用于麦克风实时识别，会持续一段时间或到1分钟时，由平台强制断开，业务需要，请手动重连

        Args:
            request: 识别请求参数

        Yields:
            ASRResponse: 流式识别结果

        Raises:
            ASRRecognitionError: 如果识别过程中出现错误
        """
        try:
            # 验证请求参数
            self.validate_request(request)

            # 检查是否提供了音频流
            if not hasattr(request, "audio_stream") or request.audio_stream is None:
                raise ASRRecognitionError("流式识别需要提供 audio_stream 参数")

            future = asyncio.Future()
            self._stream_future = future

            # 存储中间结果
            self._intermediate_results = []

            # 初始化流式识别状态
            self._stream_stopped = False
            self._stream_started = False

            def on_result_changed_callback(message, *args):  # noqa: ARG001
                """中间结果回调"""
                try:
                    if isinstance(message, str):
                        message = json.loads(message)

                    # 获取中间识别结果
                    payload = message.get("payload", {})
                    if "result" in payload:
                        text = payload.get("result", "")
                        duration = payload.get("duration", 0)

                        # 创建中间响应
                        intermediate_response = ASRResponse.partial(
                            text=text,
                            duration=duration,
                        )
                        self._intermediate_results.append(intermediate_response)

                except Exception as e:
                    self.logger.error(f"处理中间结果失败: {e}")

            def on_completed_callback(message, *args):  # noqa: ARG001
                """识别完成回调"""
                try:
                    self.logger.info(f"流式识别完成: {message}")
                    ret = self._parse_asr_result(message)
                    if not future.done():
                        future.set_result(ret)
                except Exception as e:
                    if not future.done():
                        future.set_exception(e)

            def on_error_callback(message):
                """错误回调"""
                error_msg = f"流式 ASR Error: {message}"
                if "SILENT_SPEECH" in str(message):
                    logger.warning("检测到静音，语音识别被中断")
                else:
                    self.logger.error(error_msg)

                # 检查是否为静音检测错误
                if "SILENT_SPEECH" in str(message):
                    self.logger.warning("检测到静音，语音识别被中断")
                    # 对于静音错误，可以返回一个空的成功结果而不是异常
                    if not future.done():
                        future.set_result(ASRResponse.success(text="", duration=0))
                else:
                    # 标记流式识别失败，停止音频流处理
                    self._stream_stopped = True

                    # 设置异常到 future
                    if not future.done():
                        future.set_exception(ASRRecognitionError(error_msg))

            # 创建识别器
            sr = nls.NlsSpeechRecognizer(
                token=self._ensure_token(),
                appkey=self.api_key,
                on_start=self._sdk_on_start,
                on_result_changed=on_result_changed_callback,
                on_completed=on_completed_callback,
                on_error=on_error_callback,
                on_close=self._sdk_on_close,
            )

            self._stream_recognizer = sr

            # 启动识别器
            sr.start(
                aformat=request.audio_format,
                sample_rate=request.sample_rate,
                enable_intermediate_result=request.enable_intermediate_result,
                enable_punctuation_prediction=request.enable_punctuation_prediction,
                ex={
                    "enable_voice_detection": request.enable_voice_detection,
                    "max_start_silence": request.max_start_silence,
                    "max_end_silence": request.max_end_silence,
                    "enable_multi_thresh_mode": request.enable_multi_thresh_mode,
                },
            )
            for _ in range(100):
                await asyncio.sleep(0.1)
                print(f"wait for started: {getattr(self, 'started', False)}")
                if getattr(self, "started", False):
                    self._stream_started = True
                    break
            if not getattr(self, "started", False):
                raise ASRRecognitionError("流式识别启动失败")

            # 创建任务来处理音频流和中间结果
            async def process_audio_stream():
                """处理音频流数据"""
                try:
                    async for chunk in request.audio_stream:
                        # 检查是否应该停止发送音频
                        if (
                            (hasattr(self, "_stream_stopped") and self._stream_stopped)
                            or future.done()
                            or not getattr(self, "started", False)
                        ):
                            self.logger.info("音频流处理被停止")
                            break

                        # 只有在识别器处于正确状态时才发送音频
                        if (
                            hasattr(self, "_stream_recognizer")
                            and self._stream_recognizer
                        ):
                            try:
                                sr.send_audio(chunk)
                            except Exception as send_error:
                                self.logger.error(f"发送音频数据失败: {send_error}")
                                self._stream_stopped = True
                                break
                        else:
                            self.logger.warning("识别器未就绪，跳过音频发送")
                            break

                    # 只有在没有错误的情况下才调用 stop
                    if (
                        not (hasattr(self, "_stream_stopped") and self._stream_stopped)
                        and not future.done()
                        and hasattr(self, "_stream_recognizer")
                        and self._stream_recognizer
                    ):
                        try:
                            sr.stop()
                        except Exception as stop_error:
                            self.logger.warning(f"停止识别器失败: {stop_error}")

                except Exception as e:
                    self.logger.error(f"处理音频流失败: {e}")
                    self._stream_stopped = True
                    if not future.done():
                        future.set_exception(e)

            async def yield_intermediate_results():
                """产生中间结果"""
                last_index = 0
                while not future.done():
                    # 检查是否有新的中间结果
                    if last_index < len(self._intermediate_results):
                        for i in range(last_index, len(self._intermediate_results)):
                            yield self._intermediate_results[i]
                        last_index = len(self._intermediate_results)

                    await asyncio.sleep(0.1)  # 每100ms检查一次新结果

                # 确保返回最终结果
                try:
                    final_result = await future
                    yield final_result
                except Exception as e:
                    yield ASRResponse.failed(error_message=f"识别失败: {e!s}")

            # 启动音频流处理任务
            stream_task = asyncio.create_task(process_audio_stream())

            try:
                # 产生中间结果和最终结果
                async for result in yield_intermediate_results():
                    yield result

            finally:
                # 清理
                if not stream_task.done():
                    stream_task.cancel()

        except Exception as e:
            self.logger.error(f"流式识别失败: {e}")
            yield ASRResponse.failed(error_message=f"流式识别失败: {e!s}")

    async def _on_start_recognize(self, request: ASRRecognizeRequest) -> ASRResponse:
        # 创建Future对象来等待结果
        future = asyncio.Future()

        # 存储future以便在回调中设置结果
        self._current_future = future
        self._asr_result = None
        self._asr_error = None

        def on_completed_callback(message, *args):
            try:
                # 解析结果
                self.logger.info(f"on_completed:args=>{args} message=>{message}")

                ret = self._parse_asr_result(message)

                if not future.done():
                    future.set_result(ret)
            except Exception as e:
                if not future.done():
                    future.set_exception(e)

        def on_error_callback(message):
            error_msg = f"ASR Error: {message}"
            if not future.done():
                future.set_exception(Exception(error_msg))

        sr = nls.NlsSpeechRecognizer(
            token=self._ensure_token(),
            appkey=self.api_key,
            on_start=self._sdk_on_start,
            on_result_changed=self.on_result_chg,
            on_completed=on_completed_callback,  # 使用新的回调
            on_error=on_error_callback,  # 使用新的错误回调
            on_close=self._sdk_on_close,
        )

        try:
            sr.start(
                aformat=request.audio_format,
                sample_rate=request.sample_rate,
                enable_intermediate_result=True,
                enable_punctuation_prediction=True,
            )

            # 发送音频数据
            for chunk in self.__stream_file_data(request):
                sr.send_audio(chunk)
                await asyncio.sleep(0.01)  # 使用异步sleep

            sr.stop()

            # 等待结果
            return await future

        except Exception as e:
            if not future.done():
                future.set_exception(e)
            raise
        finally:
            # 清理
            if hasattr(self, "_current_future"):
                del self._current_future

    @staticmethod
    def __stream_file_data(request: ASRRecognizeRequest):
        audio_data = request.audio_data

        # 处理 bytes 类型数据
        if isinstance(audio_data, bytes):
            # 将 bytes 数据按640字节分块
            for i in range(0, len(audio_data), 640):
                chunk = audio_data[i : i + 640]
                yield chunk
            return

        # 处理 str 或 Path 类型（文件路径）
        file_path = audio_data
        with open(file_path, "rb") as f:
            while True:
                chunk = f.read(640)
                if not chunk:
                    break
                yield chunk

    def _sdk_on_start(self, message, *args):
        """SDK 开始回调（内部使用）"""
        self.logger.info(f"on_start:args=>{args} message=>{message}")
        self.started = True
        # 标记流式识别已开始
        if hasattr(self, "_stream_started"):
            self._stream_started = True
        # 触发用户注册的回调
        self._emit_start()

    def _sdk_on_close(self, *args):
        """SDK 关闭回调（内部使用）"""
        self.logger.info(f"on_close: args=>{args}")
        # 只有在流式识别器关闭时才重置状态
        if hasattr(self, "_stream_recognizer") and self._stream_recognizer:
            self.started = False
            self._stream_recognizer = None
        # 触发用户注册的回调
        self._emit_close()

    def on_result_chg(self, message, *args):
        pass
        # self.logger.info(f"on_result_chg:args=>{args} message=>{message}")

    @staticmethod
    def _parse_asr_result(message) -> ASRResponse:
        try:
            # 如果message是字符串，先解析为JSON
            if isinstance(message, str):
                message = json.loads(message)
            # 安全地获取数据
            payload = message.get("payload", {})
            metadata = message.get("header", {})
            text = payload.get("result", "")
            duration = payload.get("duration", 0)
            
            return ASRResponse.success(
                text=text,
                duration=duration,
                metadata=metadata,
            )

        except Exception as e:
            # 错误处理
            return ASRResponse.failed(
                error_message=f"解析ASR结果失败: {e!s}",
                metadata={"raw_response": message},
            )

    # ============ 流式接口实现 ============

    def start_stream(self, request: ASRRecognizeRequest) -> None:
        """启动流式识别会话

        Args:
            request: 识别参数配置（streaming_mode 应为 True）

        Raises:
            ASRRecognitionError: 启动失败
        """
        if self._stream_started:
            self.logger.warning("流式识别已在运行中")
            return

        # 验证请求（流式模式）
        self.validate_request(request)

        # 保存请求配置
        self._stream_request = request
        self._last_partial_text = ""

        # 创建识别器
        self._stream_recognizer = nls.NlsSpeechRecognizer(
            token=self._ensure_token(),
            appkey=self.api_key,
            on_start=self._sdk_on_start,
            on_result_changed=self._sdk_on_result_changed,
            on_completed=self._sdk_on_completed,
            on_error=self._sdk_on_error,
            on_close=self._sdk_on_close,
        )

        # 启动识别器
        try:
            self._stream_recognizer.start(
                aformat="pcm",
                sample_rate=request.sample_rate,
                ch=request.channel,
                enable_intermediate_result=request.enable_intermediate_result,
                enable_punctuation_prediction=request.enable_punctuation_prediction,
                enable_inverse_text_normalization=request.enable_inverse_text_normalization,
                ex={
                    "enable_voice_detection": request.enable_voice_detection,
                    "max_start_silence": request.max_start_silence,
                    "max_end_silence": request.max_end_silence,
                    "enable_multi_thresh_mode": request.enable_multi_thresh_mode,
                    "disfluency": request.disfluency,
                },
            )
            self._stream_started = True
            self.logger.info("阿里 ASR 流式识别已启动")
        except Exception as e:
            self._stream_recognizer = None
            self._stream_started = False
            error = ASRRecognitionError(f"启动流式识别失败: {e}")
            self._emit_error(error)
            raise error

    def feed_audio_chunk(self, pcm_chunk: bytes) -> None:
        """推送音频数据块

        Args:
            pcm_chunk: PCM 格式音频数据

        Raises:
            ASRRecognitionError: 会话未启动或发送失败
        """
        if not self._stream_started:
            raise ASRRecognitionError("流式识别会话未启动")

        if not pcm_chunk:
            return

        if not self._stream_recognizer:
            raise ASRRecognitionError("识别器未就绪")

        try:
            self._stream_recognizer.send_audio(pcm_chunk)
        except Exception as e:
            error = ASRRecognitionError(f"发送音频数据失败: {e}")
            self._emit_error(error)
            raise error

    def stop_stream(self) -> None:
        """停止流式识别会话"""
        if not self._stream_started:
            return

        self.logger.info("停止阿里 ASR 流式识别")

        if self._stream_recognizer:
            try:
                self._stream_recognizer.stop()
            except Exception as e:
                self.logger.warning(f"停止识别器失败: {e}")

        self._stream_started = False
        self._stream_recognizer = None
        self._last_partial_text = ""

    # ============ 流式接口的 SDK 回调 ============

    def _sdk_on_result_changed(self, message, *args):  # noqa: ARG002
        """SDK 中间结果回调"""
        try:
            if isinstance(message, str):
                message = json.loads(message)

            payload = message.get("payload", {})
            text = payload.get("result", "")

            # 只有文本变化时才触发回调
            if text and text != self._last_partial_text:
                self._last_partial_text = text
                response = ASRResponse.partial(
                    text=text,
                    duration=payload.get("duration", 0),
                )
                self._emit_partial(response)

        except Exception as e:
            self.logger.error(f"处理中间结果失败: {e}")

    def _sdk_on_completed(self, message, *args):  # noqa: ARG002
        """SDK 识别完成回调"""
        try:
            if isinstance(message, str):
                message = json.loads(message)

            payload = message.get("payload", {})
            text = payload.get("result", "")

            self.logger.info(f"阿里 ASR 识别完成: {text}")

            response = ASRResponse.success(
                text=text,
                duration=payload.get("duration", 0),
            )
            self._emit_final(response)
            self._last_partial_text = ""

        except Exception as e:
            self.logger.error(f"处理识别完成回调失败: {e}")
            self._emit_error(e)

    def _sdk_on_error(self, message, *args):  # noqa: ARG002
        """SDK 错误回调"""
        try:
            if isinstance(message, str):
                data = json.loads(message)
            else:
                data = message

            header = data.get("header", {}) if isinstance(data, dict) else {}
            status_text = header.get("status_text", "")
            status_code = header.get("status", 0)

            # 特殊处理 SILENT_SPEECH 错误
            if status_text == "SILENT_SPEECH" or status_code == 41010105:
                self.logger.warning(f"ASR识别内容为空(SILENT_SPEECH): {data}")
                # 触发空识别结果
                response = ASRResponse.success(text="", duration=0)
                self._emit_final(response)
            # 如果已有中间识别结果，使用已有内容
            elif self._last_partial_text:
                self.logger.warning(
                    f"ASR发生错误(code={status_code}, text={status_text})，"
                    f"使用已有结果: {self._last_partial_text}"
                )
                response = ASRResponse.success(
                    text=self._last_partial_text,
                    duration=0,
                )
                self._emit_final(response)
                self._last_partial_text = ""
            else:
                error = ASRRecognitionError(f"阿里 ASR 错误: {message}")
                self.logger.error(str(error))
                self._emit_error(error)

        except Exception:
            # JSON 解析失败时的处理
            if self._last_partial_text:
                self.logger.warning(
                    f"ASR异常但已有结果，使用: {self._last_partial_text}"
                )
                response = ASRResponse.success(
                    text=self._last_partial_text,
                    duration=0,
                )
                self._emit_final(response)
                self._last_partial_text = ""
            else:
                error = ASRRecognitionError(f"阿里 ASR 错误: {message}")
                self.logger.error(str(error))
                self._emit_error(error)
