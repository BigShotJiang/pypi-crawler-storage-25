"""
阿里云实时 ASR 提供商（WebSocket）
将外部项目中的实时识别逻辑重写为本底层包 Provider，适配 BaseASR 与 CLI。
"""

import asyncio
import json
import time
from typing import Any, AsyncIterator

try:
    import nls
except ImportError:
    nls = None

try:
    from aliyunsdkcore.client import AcsClient
    from aliyunsdkcore.request import CommonRequest
except ImportError:
    AcsClient = None
    CommonRequest = None

from soulshell_base.core import RuntimeStateManager, get_logger

from ..base import BaseASR
from ..config import ASRConfigManager
from ..exceptions import ASRRecognitionError
from ..models import ASRRecognizeRequest, ASRResponse

logger = get_logger(__name__)


class ASRProviderALiRealtime(BaseASR):
    """阿里云实时 ASR 提供商"""

    def __init__(self, **kwargs):
        """
        Args:
            **kwargs: 所有配置均从配置字典传入（支持 ASR_ALI.APPKEY/AK/SK 或 appkey/ak/sk）
        """
        super().__init__(**kwargs)
        if nls is None:
            raise ImportError(
                "需要安装 alibabacloud-nls-python-sdk 才能使用阿里云实时 ASR。"
                "请运行: pip install alibabacloud-nls-python-sdk"
            )

        # 配置管理与凭据
        self.asr_config_manager = ASRConfigManager()
        # 兼容两套键名：appkey/ak/sk 与 ASR_ALI.APPKEY/AK/SK
        self.appkey = kwargs.get("appkey") or kwargs.get("ASR_ALI.APPKEY") or ""
        self.ak = kwargs.get("ak") or kwargs.get("ASR_ALI.AK") or ""
        self.sk = kwargs.get("sk") or kwargs.get("ASR_ALI.SK") or ""

        # Token 相关配置（从 kwargs 或默认配置读取）
        self.region_id = kwargs.get(
            "region_id",
            self.asr_config_manager.get_default_config("asr_ali", "REGION_ID", "cn-shanghai"),
        )
        self.token_domain = kwargs.get(
            "token_domain",
            self.asr_config_manager.get_default_config(
                "asr_ali", "TOKEN_DOMAIN", "nls-meta.cn-shanghai.aliyuncs.com"
            ),
        )
        self.token_version = kwargs.get(
            "token_version",
            self.asr_config_manager.get_default_config("asr_ali", "TOKEN_VERSION", "2019-02-28"),
        )

        # 运行时状态与缓存
        self.state_manager = RuntimeStateManager.get_instance()
        self.module_name = "asr_ali_realtime"


        # 流式识别状态
        self._stream_recognizer = None
        self._last_partial_text = ""
        self._last_voice_ts = None
        self._last_chunk_ts = None
        self._last_rc_ts = None
        self._last_final_text = ""
        self._stream_start_ts = 0.0
        self._has_sentence_begin = False
        self._timer_task = None
        self.started = False

        self.logger.info("初始化阿里云实时 ASR")

    def get_provider_name(self) -> str:
        """获取提供商名称"""
        return "asr_ali_realtime"

    @classmethod
    def describe(cls) -> dict[str, Any]:
        """提供商自描述"""
        return {
            "provider_name": "asr_ali_realtime",
            "display_name": "阿里云实时 ASR",
            "description": "阿里云 NLS WebSocket 实时语音识别",
            "required_init_params": {
                "appkey": {"type": "str", "description": "NLS 应用 AppKey"},
                "ak": {"type": "str", "description": "AccessKey ID"},
                "sk": {"type": "str", "description": "AccessKey Secret"},
            },
            "optional_init_params": {
                "region_id": {"type": "str", "description": "地域 ID", "default": "cn-shanghai"},
                "token_domain": {
                    "type": "str",
                    "description": "Token 域名",
                    "default": "nls-meta.cn-shanghai.aliyuncs.com",
                },
                "token_version": {
                    "type": "str",
                    "description": "Token 版本",
                    "default": "2019-02-28",
                },
            },
            "supported_methods": [
                "recognize: 异步识别（文件/字节）",
                "recognize_stream: 流式识别（麦克风/实时流）",
            ],
        }

    def validate_config(self) -> bool:
        """验证配置有效性"""
        ok = True
        if not self.sk:
            self.logger.error("缺少 sk")
            ok = False
        if not self.ak:
            self.logger.error("缺少 ak")
            ok = False
        if not self.appkey:
            self.logger.error("缺少 appkey")
            ok = False
        return ok

    def validate_request(self, request: ASRRecognizeRequest) -> None:
        """校验请求参数"""
        super().validate_request(request)
        if not hasattr(request.audio_format, "value"):
            raise ASRRecognitionError("音频格式无效")
        if not hasattr(request.codec, "value"):
            raise ASRRecognitionError("音频编解码标识无效")

    def _ensure_token(self) -> str:
        """获取或刷新 Token（持久化缓存）"""
        cached_token = self.state_manager.get_state(self.module_name, f"{self.appkey}_token", default="")
        if cached_token:
            self.logger.info(f"使用持久化缓存的 token: {cached_token[:20]}...")
            return cached_token
        try:
            if AcsClient is None or CommonRequest is None:
                self.logger.error("Aliyun ASR: AcsClient 或 CommonRequest 不可用")
                return ""
            client = AcsClient(self.ak, self.sk, self.region_id)
            req = CommonRequest()
            req.set_method("POST")
            req.set_domain(self.token_domain)
            req.set_version(self.token_version)
            req.set_action_name("CreateToken")
            resp = client.do_action_with_exception(req)
            self.logger.info(f"Aliyun Token API 响应: {resp}")
            data = json.loads(resp)
            token = data.get("Token", {}).get("Id", "")
            expire = float(data.get("Token", {}).get("ExpireTime", 0))
            if token and expire > 0:
                ttl = int(expire - time.time() - 3600)
                if ttl > 0:
                    self.state_manager.set_state(self.module_name, f"{self.appkey}_token", token, ttl=ttl)
                    self.logger.info(f"新 token 已缓存，TTL: {ttl} 秒 (~{ttl / 3600:.1f} 小时)")
                else:
                    self.logger.warning(f"Token TTL={ttl}，不进行缓存")
                return token
            self.logger.error(f"Aliyun Token 刷新失败: {resp}")
        except Exception as e:
            self.logger.error(f"刷新 Aliyun Token 失败: {e}")
        return ""

    @staticmethod
    def _parse_asr_result(message) -> ASRResponse:
        """将 SDK 返回的 message 解析为 ASRResponse"""
        try:
            if isinstance(message, str):
                message = json.loads(message)
            payload = message.get("payload", {})
            metadata = message.get("header", {})
            text = payload.get("result", "")
            duration = payload.get("duration", 0)
            return ASRResponse.success(text=text, duration=duration, metadata=metadata)
        except Exception as e:
            return ASRResponse.failed(error_message=f"解析ASR结果失败: {e!s}", metadata={"raw_response": message})

    async def recognize(self, request: ASRRecognizeRequest) -> ASRResponse:
        """异步识别（文件/字节）"""
        try:
            self.validate_request(request)
            future = asyncio.Future()

            def on_completed_callback(message, *args):  # noqa: ARG001
                try:
                    ret = self._parse_asr_result(message)
                    if not future.done():
                        future.set_result(ret)
                except Exception as e:
                    if not future.done():
                        future.set_exception(e)

            def on_error_callback(message):
                if not future.done():
                    future.set_exception(ASRRecognitionError(f"ASR Error: {message}"))

            sr = nls.NlsSpeechRecognizer(
                token=self._ensure_token(),
                appkey=self.appkey,
                on_start=self._sdk_on_start,
                on_result_changed=self._sdk_on_result_changed,
                on_completed=on_completed_callback,
                on_error=on_error_callback,
                on_close=self._sdk_on_close,
            )

            try:
                sr.start(
                    aformat=request.audio_format,
                    sample_rate=request.sample_rate,
                    enable_intermediate_result=request.enable_intermediate_result,
                    enable_punctuation_prediction=request.enable_punctuation_prediction,
                )
                for chunk in self.__stream_file_data(request):
                    sr.send_audio(chunk)
                    await asyncio.sleep(0.01)
                return await future
            except Exception as e:
                if not future.done():
                    future.set_exception(e)
                raise
        except Exception as e:
            self.logger.error(f"阿里云实时 ASR 识别失败: {e}")
            return ASRResponse.failed(error_message=f"阿里云实时 ASR 识别失败: {e!s}")

    async def recognize_stream(self, request: ASRRecognizeRequest) -> AsyncIterator[ASRResponse]:
        """流式识别（音频异步生成器）"""
        try:
            # 可选功能开关（从配置读取）
            self.enable_words = True
            self.max_sentence_silence = int(request.max_end_silence)
            self.customization_id = request.customization_id
            self.vocabulary_id = request.vocabulary_id

            self.validate_request(request)
            if not hasattr(request, "audio_stream") or request.audio_stream is None:
                yield ASRResponse.failed(error_message="流式识别需要提供 audio_stream")
                return

            future = asyncio.Future()
            self._intermediate_results = []
            self._stream_stopped = False
            self._stream_started = False

            def on_result_changed_callback(message, *args):  # noqa: ARG001
                try:
                    if isinstance(message, str):
                        message = json.loads(message)
                    # 任意中间事件到达都视为“有进展”，刷新计时基准
                    self._last_rc_ts = time.monotonic()
                    payload = message.get("payload", {})
                    header = message.get("header", {})
                    name = header.get("name", "")
                    if "result" in payload:
                        text = payload.get("result", "")
                        duration = payload.get("duration", 0)
                        resp = ASRResponse.partial(text=text, duration=duration)
                        self._intermediate_results.append(resp)
                        try:
                            self._emit_partial(resp)
                        except Exception:
                            pass
                        self.logger.info(f"on_result_changed: text={text}")
                        if text:
                            self._last_voice_ts = time.monotonic()
                            # 若服务端已给出句末（SentenceEnd），直接产出最终结果，避免 TranscriptionCompleted 无 payload 的情况
                            if name == "SentenceEnd":
                                self.logger.info(f"on_sentence_end: text={text}")
                                self._last_final_text = text
                                if not future.done():
                                    future.set_result(ASRResponse.success(text=text, duration=duration, metadata=header))
                        elif name == "SentenceBegin":
                            # 句子开始也视为检测到语音，更新静音计时参考
                            self._has_sentence_begin = True
                            self._last_voice_ts = time.monotonic()
                            self._last_rc_ts = self._last_voice_ts
                except Exception as e:
                    self.logger.error(f"处理中间结果失败: {e}")

            def on_completed_callback(message, *args):  # noqa: ARG001
                try:
                    if isinstance(message, str):
                        message = json.loads(message)
                    payload = message.get("payload", {})
                    header = message.get("header", {})
                    name = header.get("name", "")
                    text = ""
                    duration = 0
                    if isinstance(payload, dict):
                        text = payload.get("result", "") or ""
                        duration = payload.get("duration", 0) or 0
                    if name == "SentenceEnd":
                        # 句末事件携带最终文本，直接产出
                        if not future.done():
                            future.set_result(ASRResponse.success(text=text, duration=duration, metadata=header))
                        self._last_final_text = text or self._last_final_text
                    elif name == "SentenceBegin":
                        self._has_sentence_begin = True
                        self._last_voice_ts = time.monotonic()
                    elif name == "TranscriptionCompleted":
                        # 完成事件可能不含 payload；若之前已记录句末文本，则用作最终文本
                        final_text = text or self._last_final_text or (self._intermediate_results[-1].text if self._intermediate_results else "")
                        if not future.done():
                            future.set_result(ASRResponse.success(text=final_text, duration=duration, metadata=header))
                except Exception as e:
                    if not future.done():
                        future.set_exception(e)

            def on_error_callback(message):
                msg = f"流式 ASR Error: {message}"
                if "SILENT_SPEECH" in str(message):
                    self.logger.warning("检测到静音，语音识别被中断")
                    if not future.done():
                        future.set_result(ASRResponse.success(text="", duration=0))
                else:
                    self._stream_stopped = True
                    if not future.done():
                        future.set_exception(ASRRecognitionError(msg))

            ts = nls.NlsSpeechTranscriber(
                token=self._ensure_token(),
                appkey=self.appkey,
                on_start=self._sdk_on_start,
                on_result_changed=on_result_changed_callback,
                on_completed=on_completed_callback,
                on_error=on_error_callback,
                on_close=self._sdk_on_close,
            )
            self._stream_recognizer = ts

            ts.start(
                aformat="pcm",
                sample_rate=request.sample_rate,
                enable_intermediate_result=request.enable_intermediate_result,
                enable_punctuation_prediction=request.enable_punctuation_prediction,
                enable_inverse_text_normalization=request.enable_inverse_text_normalization,
                ex={
                    "max_sentence_silence": request.max_end_silence,
                    "disfluency": request.disfluency,
                    "enable_words": self.enable_words,
                },
            )
            start_wait_ts = time.monotonic()
            start_timeout_s = max(0, int(self.max_sentence_silence)) / 1000.0
            for _ in range(100):
                await asyncio.sleep(0.1)
                if getattr(self, "started", False):
                    self._stream_started = True
                    if not self._stream_start_ts:
                        self._stream_start_ts = time.monotonic()
                    if not self._last_rc_ts:
                        self._last_rc_ts = self._stream_start_ts
                    break
                if start_timeout_s > 0 and (time.monotonic() - start_wait_ts) >= start_timeout_s:
                    self.logger.info("等待 on_start 超时，主动断开连接")
                    try:
                        ts.shutdown()
                    except Exception:
                        pass
                    self._stream_stopped = True
                    break

            if not getattr(self, "started", False):
                yield ASRResponse.failed(error_message="流式识别启动失败")
                return

            async def _watchdog():
                timeout_s = max(0, int(self.max_sentence_silence)) / 1000.0
                if timeout_s <= 0:
                    return
                while True:
                    if self._stream_stopped or future.done():
                        break
                    now = time.monotonic()
                    last_event_ts = self._last_rc_ts or self._stream_start_ts
                    if (now - last_event_ts) >= timeout_s:
                        self.logger.info("句子静音计时器超时，主动断开连接")
                        self._stream_stopped = True
                        try:
                            ts.stop()
                        except Exception:
                            pass
                        break
                    await asyncio.sleep(0.1)

            self._timer_task = asyncio.create_task(_watchdog())

            async def process_audio_stream():
                try:
                    async for chunk in request.audio_stream:
                        if self._stream_stopped or future.done() or not getattr(self, "started", False):
                            break
                        try:
                            ts.send_audio(chunk)
                            self._last_chunk_ts = time.monotonic()
                        except Exception as send_error:
                            self.logger.error(f"发送音频数据失败: {send_error}")
                            self._stream_stopped = True
                            break
                    if not self._stream_stopped and not future.done() and self._stream_recognizer:
                        try:
                            ts.stop()
                        except Exception as stop_error:
                            self.logger.warning(f"停止识别器失败: {stop_error}")
                except Exception as e:
                    self.logger.error(f"处理音频流失败: {e}")
                    self._stream_stopped = True
                    if not future.done():
                        future.set_exception(e)

            async def yield_results():
                last = 0
                while not future.done():
                    if last < len(self._intermediate_results):
                        for i in range(last, len(self._intermediate_results)):
                            yield self._intermediate_results[i]
                        last = len(self._intermediate_results)
                    await asyncio.sleep(0.1)
                try:
                    final_result = await future
                    yield final_result
                except Exception as e:
                    yield ASRResponse.failed(error_message=f"识别失败: {e!s}")

            stream_task = asyncio.create_task(process_audio_stream())
            try:
                async for res in yield_results():
                    yield res
            finally:
                if not stream_task.done():
                    stream_task.cancel()
                if self._timer_task and not self._timer_task.done():
                    self._timer_task.cancel()

        except Exception as e:
            self.logger.error(f"流式识别失败: {e}")
            yield ASRResponse.failed(error_message=f"流式识别失败: {e!s}")

    def start_stream(self, request: ASRRecognizeRequest) -> None:
        """启动三段式流式识别会话"""
        if self._stream_started:
            self.logger.warning("流式识别已在运行中")
            return
        self.validate_request(request)
        self._stream_request = request
        self._last_partial_text = ""
        self._stream_recognizer = nls.NlsSpeechTranscriber(
            token=self._ensure_token(),
            appkey=self.appkey,
            on_start=self._sdk_on_start,
            on_result_changed=self._sdk_on_result_changed,
            on_completed=self._sdk_on_completed,
            on_error=self._sdk_on_error,
            on_close=self._sdk_on_close,
        )
        try:
            self._stream_recognizer.start(
                aformat="pcm",
                sample_rate=request.sample_rate,
                enable_intermediate_result=request.enable_intermediate_result,
                enable_punctuation_prediction=request.enable_punctuation_prediction,
                enable_inverse_text_normalization=request.enable_inverse_text_normalization,
                ex={
                    "enable_voice_detection": request.enable_voice_detection,
                    "max_start_silence": request.max_start_silence,
                    "max_end_silence": request.max_end_silence,
                    "disfluency": request.disfluency,
                    "enable_words": self.enable_words,
                    "max_sentence_silence": self.max_sentence_silence,
                },
            )
            self._stream_started = True
            self.logger.info("阿里云实时 ASR 三段式会话已启动")
        except Exception as e:
            self._stream_recognizer = None
            self._stream_started = False
            error = ASRRecognitionError(f"启动流式识别失败: {e}")
            self._emit_error(error)
            raise error

    def feed_audio_chunk(self, pcm_chunk: bytes) -> None:
        """三段式推送音频数据块"""
        if not self._stream_started:
            raise ASRRecognitionError("流式识别会话未启动")
        if not pcm_chunk:
            return
        if not self._stream_recognizer:
            raise ASRRecognitionError("识别器未就绪")
        try:
            self._stream_recognizer.send_audio(pcm_chunk)
        except Exception as e:
            error = ASRRecognitionError(f"发送音频数据失败: {e}")
            self._emit_error(error)
            raise error

    def stop_stream(self) -> None:
        """停止三段式流式识别会话"""
        if not self._stream_started:
            return
        self.logger.info("停止阿里云实时 ASR 流式识别")
        if self._stream_recognizer:
            try:
                self._stream_recognizer.stop()
            except Exception as e:
                self.logger.warning(f"停止识别器失败: {e}")
        self._stream_started = False
        self._stream_recognizer = None
        self._last_partial_text = ""

    # ====== SDK 回调（统一触发基类回调） ======
    def _sdk_on_start(self, message, *args):
        self.logger.info(f"on_start: args={args} message={message}")
        self.started = True
        if hasattr(self, "_stream_started"):
            self._stream_started = True
        try:
            now = time.monotonic()
            self._last_rc_ts = now
            if not self._stream_start_ts:
                self._stream_start_ts = now
        except Exception:
            pass
        self._emit_start()

    def _sdk_on_close(self, *args):
        self.logger.info(f"on_close: args={args}")
        if hasattr(self, "_stream_recognizer") and self._stream_recognizer:
            self.started = False
            self._stream_recognizer = None
        self._emit_close()

    def _sdk_on_result_changed(self, message, *args):
        try:
            if isinstance(message, str):
                message = json.loads(message)
            payload = message.get("payload", {})
            text = payload.get("result", "")
            try:
                self._last_rc_ts = time.monotonic()
            except Exception:
                pass
            if text and text != self._last_partial_text:
                self._last_partial_text = text
                resp = ASRResponse.partial(text=text, duration=payload.get("duration", 0))
                self._emit_partial(resp)
                self._last_voice_ts = time.monotonic()
        except Exception as e:
            self.logger.error(f"处理中间结果失败: {e}")

    def _sdk_on_completed(self, message, *args):
        try:
            if isinstance(message, str):
                message = json.loads(message)
            payload = message.get("payload", {})
            text = payload.get("result", "")
            self.logger.info(f"阿里云实时 ASR 识别完成: {text}")
            resp = ASRResponse.success(text=text, duration=payload.get("duration", 0))
            self._emit_final(resp)
            self._last_partial_text = ""
        except Exception as e:
            self.logger.error(f"处理识别完成回调失败: {e}")
            self._emit_error(e)

    def _sdk_on_error(self, message, *args):
        try:
            data = json.loads(message) if isinstance(message, str) else message
            header = data.get("header", {}) if isinstance(data, dict) else {}
            status_text = header.get("status_text", "")
            status_code = header.get("status", 0)
            if status_text == "SILENT_SPEECH" or status_code == 41010105:
                self.logger.warning(f"ASR识别内容为空(SILENT_SPEECH): {data}")
                resp = ASRResponse.success(text="", duration=0)
                self._emit_final(resp)
            elif self._last_partial_text:
                self.logger.warning(
                    f"ASR发生错误(code={status_code}, text={status_text})，使用已有结果: {self._last_partial_text}"
                )
                resp = ASRResponse.success(text=self._last_partial_text, duration=0)
                self._emit_final(resp)
                self._last_partial_text = ""
            else:
                err = ASRRecognitionError(f"阿里 ASR 错误: {message}")
                self.logger.error(str(err))
                self._emit_error(err)
        except Exception:
            if self._last_partial_text:
                self.logger.warning(f"ASR异常但已有结果，使用: {self._last_partial_text}")
                resp = ASRResponse.success(text=self._last_partial_text, duration=0)
                self._emit_final(resp)
                self._last_partial_text = ""
            else:
                err = ASRRecognitionError(f"阿里 ASR 错误: {message}")
                self.logger.error(str(err))
                self._emit_error(err)

    # ====== 工具方法 ======
    @staticmethod
    def __stream_file_data(request: ASRRecognizeRequest):
        """将文件/字节流分片为 640B 发送"""
        audio_data = request.audio_data
        if isinstance(audio_data, bytes):
            for i in range(0, len(audio_data), 640):
                yield audio_data[i : i + 640]
            return
        file_path = audio_data
        with open(file_path, "rb") as f:
            while True:
                chunk = f.read(640)
                if not chunk:
                    break
                yield chunk
