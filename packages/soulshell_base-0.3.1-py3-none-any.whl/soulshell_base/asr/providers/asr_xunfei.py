"""
讯飞ASR执行器
将讯飞语音听写流式WebAPI适配到BaseASRRecognizer接口
"""

import asyncio
import base64
from dataclasses import dataclass
from datetime import datetime
import hashlib
import hmac
import json
import queue
import ssl
import threading
import time
from typing import Any, AsyncIterator, Optional
from urllib.parse import urlencode

import numpy as np
import websocket

from soulshell_base.core import get_logger

from ..base import BaseASR
from ..config import ASRConfigManager
from ..exceptions import ASRRecognitionError
from ..models import ASRRecognizeRequest, ASRResponse

logger = get_logger(__name__)


@dataclass
class RecognitionConfig:
    """识别配置类"""

    domain: str = "iat"
    language: str = "zh_cn"
    accent: str = "mandarin"
    vinfo: int = 1
    vad_eos: int = 2000
    dwa: str = ""  # 动态修正功能，设为 "wpgs" 可实时返回中间结果
    format: str = "audio/L16;rate=16000"
    encoding: str = "raw"
    frame_size: int = 8000
    interval: float = 0.04


@dataclass
class RecognitionResult:
    """识别结果封装"""

    success: bool
    data: list[dict]
    text: str
    sid: str = ""
    error_code: int = 0
    error_message: str = ""
    confidence: float = 0.0

    def __post_init__(self):
        if self.data:
            self.confidence = self._calculate_confidence()

    def _calculate_confidence(self) -> float:
        """计算置信度"""
        if not self.data:
            return 0.0
        total_words = 0
        total_confidence = 0.0
        for item in self.data:
            for word_info in item.get("cw", []):
                total_words += 1
                total_confidence += word_info.get("sc", 0)
        return total_confidence / total_words if total_words > 0 else 0.0


class ASRProviderXunFei(BaseASR):
    """讯飞ASR执行器 - 支持流式语音识别"""

    def get_provider_name(self) -> str:
        """获取提供商名称"""
        return "xunfei"

    @classmethod
    def describe(cls) -> dict[str, Any]:
        """获取提供商描述信息（自描述能力）"""
        return {
            "provider_name": "xunfei",
            "display_name": "讯飞 ASR",
            "description": "讯飞语音听写流式识别服务",
            "required_init_params": {
                "api_key": {
                    "type": "str",
                    "description": "API Key",
                },
                "app_id": {
                    "type": "str",
                    "description": "应用 ID",
                },
                "api_secret": {
                    "type": "str",
                    "description": "API Secret",
                },
            },
            "optional_init_params": {
                "input_frame_size": {
                    "type": "int",
                    "description": "输入帧大小",
                    "default": 512,
                },
                "input_sample_rate": {
                    "type": "int",
                    "description": "输入采样率",
                    "default": 16000,
                },
                "language": {
                    "type": "str",
                    "description": "识别语言",
                    "default": "zh_cn",
                },
            },
            "supported_methods": [
                "recognize: 异步识别",
                "recognize_stream: 流式识别",
            ],
        }

    STATUS_FIRST_FRAME = 0
    STATUS_CONTINUE_FRAME = 1
    STATUS_LAST_FRAME = 2

    def __init__(self, api_key: str, app_id: str, api_secret: str, **kwargs):
        super().__init__(**kwargs)

        # 使用ASR模块的配置管理器获取默认配置
        self.asr_config_manager = ASRConfigManager()
        self._enabled = False

        self.input_frame_size = kwargs.get("input_frame_size", 512)
        self.input_sample_rate = kwargs.get("input_sample_rate", 16000)

        # 讯飞API配置
        self.app_id = app_id
        self.api_secret = api_secret
        self.api_key = api_key
        self.ws_url = "wss://ws-api.xfyun.cn/v2/iat"

        # 识别配置 - 从kwargs或默认配置获取
        self.recognition_config = RecognitionConfig()
        self.recognition_config.language = kwargs.get(
            "language",
            self.asr_config_manager.get_default_config(
                "asr_xunfei", "LANGUAGE", "zh_cn"
            ),
        )
        self.recognition_config.accent = kwargs.get(
            "accent",
            self.asr_config_manager.get_default_config(
                "asr_xunfei", "ACCENT", "mandarin"
            ),
        )
        self.recognition_config.vad_eos = kwargs.get(
            "vad_eos",
            self.asr_config_manager.get_default_config("asr_xunfei", "VAD_EOS", 2000),
        )
        self.recognition_config.dwa = kwargs.get(
            "dwa",
            self.asr_config_manager.get_default_config("asr_xunfei", "DWA", ""),
        )

        # 状态变量
        self.ws = None
        self.ws_thread = None
        self.result_text = ""
        self.is_recording = False
        self.temp_data_list = []
        self.temp_result_list = []
        self.final_result = RecognitionResult(success=False, data=[], text="")
        self._lock = threading.Lock()

        # 流式识别 - 从kwargs或默认配置获取参数
        self._stream_lock = threading.Lock()
        self._stream_buffer = bytearray()
        self._stream_in_speech = False
        self._stream_silence_frames = 0
        self._stream_speech_frames = 0
        self._silence_threshold = float(
            kwargs.get(
                "silence_threshold",
                self.asr_config_manager.get_default_config(
                    "asr_xunfei", "SILENCE_THRESHOLD", 600
                ),
            )
        )
        self._max_silence_frames = int(
            kwargs.get(
                "max_silence_frames",
                self.asr_config_manager.get_default_config(
                    "asr_xunfei", "MAX_SILENCE_FRAMES", 30
                ),
            )
        )
        self._min_speech_frames = int(
            kwargs.get(
                "min_speech_frames",
                self.asr_config_manager.get_default_config(
                    "asr_xunfei", "MIN_SPEECH_FRAMES", 10
                ),
            )
        )
        self._max_stream_seconds = float(
            kwargs.get(
                "max_stream_seconds",
                self.asr_config_manager.get_default_config(
                    "asr_xunfei", "MAX_STREAM_SECONDS", 15.0
                ),
            )
        )
        frame_step = max(1, self.input_frame_size)
        frames_per_second = max(1, int(round(self.input_sample_rate / frame_step)))  # noqa: RUF046
        self._max_stream_duration_frames = max(
            1, int(self._max_stream_seconds * frames_per_second)
        )
        self._enabled = True

        # ============ 推送式流式接口状态（start/feed/stop） ============
        self._push_stream_ws: Optional[websocket.WebSocketApp] = None
        self._push_stream_thread: Optional[threading.Thread] = None
        self._push_stream_audio_queue: queue.Queue[Optional[bytes]] = queue.Queue()
        self._push_stream_connected = threading.Event()
        self._push_stream_finished = threading.Event()
        self._push_stream_request: Optional[ASRRecognizeRequest] = None
        self._push_stream_first_frame_sent = False
        self._last_partial_text: str = ""
        self._push_stream_connect_timeout = float(
            kwargs.get("stream_connect_timeout", 10)
        )
        self._push_stream_stop_timeout = float(kwargs.get("stream_stop_timeout", 10))

    def _create_url(self) -> str:
        """创建带签名的WebSocket URL"""
        url = "wss://ws-api.xfyun.cn/v2/iat"
        now = datetime.now()
        date = self._format_date(now)

        # 构建签名
        signature_origin = "host: ws-api.xfyun.cn\n"
        signature_origin += f"date: {date}\n"
        signature_origin += "GET /v2/iat HTTP/1.1"

        signature_sha = hmac.new(
            self.api_secret.encode("utf-8"),
            signature_origin.encode("utf-8"),
            digestmod=hashlib.sha256,
        ).digest()
        signature_sha = base64.b64encode(signature_sha).decode("utf-8")

        authorization_origin = (
            f'api_key="{self.api_key}", '
            f'algorithm="hmac-sha256", '
            f'headers="host date request-line", '
            f'signature="{signature_sha}"'
        )
        authorization = base64.b64encode(authorization_origin.encode("utf-8")).decode(
            "utf-8"
        )

        params = {
            "authorization": authorization,
            "date": date,
            "host": "ws-api.xfyun.cn",
        }

        return url + "?" + urlencode(params)

    @staticmethod
    def _format_date(dt: datetime) -> str:
        """格式化日期为RFC格式"""
        return dt.strftime("%a, %d %b %Y %H:%M:%S GMT")

    def _build_business_params(self) -> dict:
        """构建 business 参数"""
        business = {
            "domain": self.recognition_config.domain,
            "language": self.recognition_config.language,
            "accent": self.recognition_config.accent,
            "vinfo": self.recognition_config.vinfo,
        }
        _vad_eos = self.recognition_config.vad_eos
        if isinstance(_vad_eos, int) and _vad_eos >= 0:
            business["vad_eos"] = _vad_eos
        # 动态修正功能（开启后可实时返回中间结果）
        if self.recognition_config.dwa:
            business["dwa"] = self.recognition_config.dwa
        return business

    def _on_message(self, _ws, message: str):
        """处理WebSocket消息"""
        try:
            response = json.loads(message)
            code = response.get("code", -1)
            sid = response.get("sid", "")

            if code != 0:
                error_msg = response.get("message", "未知错误")
                logger.error(
                    f"讯飞识别错误 - sid: {sid}, code: {code}, message: {error_msg}"
                )
                with self._lock:
                    self.final_result.success = False
                    self.final_result.error_code = code
                    self.final_result.error_message = error_msg
                    self.final_result.sid = sid
            else:
                data = response.get("data", {}).get("result", {}).get("ws", [])
                if data:
                    self.temp_data_list.extend(data)

                    # 构建文本结果
                    text = ""
                    for item in data:
                        for word_info in item.get("cw", []):
                            text += word_info.get("w", "")

                    self.temp_result_list.append(text)
                    logger.info(f"识别成功 - sid: {sid}, text: {text}")
                    with self._lock:
                        self.final_result.data = self.temp_data_list
                        self.final_result.text = "".join(self.temp_result_list)
                        self.final_result.success = True
                        self.final_result.sid = sid

                    logger.debug(f"讯飞识别结果 - sid: {sid}, text: {text}")

        except json.JSONDecodeError as e:
            logger.error(f"JSON解析错误: {e}")
            with self._lock:
                self.final_result.success = False
                self.final_result.error_message = f"JSON解析错误: {e}"
        except Exception as e:
            logger.error(f"消息处理异常: {e}")
            with self._lock:
                self.final_result.success = False
                self.final_result.error_message = str(e)

    def _on_error(self, _ws, error):
        """处理WebSocket错误"""
        logger.error(f"WebSocket错误: {error}")
        with self._lock:
            self.final_result.success = False
            self.final_result.error_message = str(error)

    def _on_close(self, _ws, close_status_code, close_msg):
        """处理WebSocket关闭"""
        logger.info(
            f"WebSocket连接关闭 - code: {close_status_code}, message: {close_msg}"
        )

    def _on_open(self, ws, pcm_data: bytes):
        """处理WebSocket连接建立"""

        def run():
            logger.info(f"讯飞ASR连接建立，PCM数据长度: {len(pcm_data)}字节")
            try:
                if not pcm_data:
                    raise ValueError("PCM数据为空")

                status = self.STATUS_FIRST_FRAME
                offset = 0

                while offset < len(pcm_data) or status == self.STATUS_LAST_FRAME:
                    if status == self.STATUS_LAST_FRAME:
                        buf = b""  # 最后一帧发送空数据
                    else:
                        buf = pcm_data[
                            offset : offset + self.recognition_config.frame_size
                        ]
                        offset += self.recognition_config.frame_size

                    # 检查是否到达数据末尾
                    if offset >= len(pcm_data) and status != self.STATUS_LAST_FRAME:
                        status = self.STATUS_LAST_FRAME

                    if status == self.STATUS_FIRST_FRAME:
                        data = {
                            "common": {"app_id": self.app_id},
                            "business": self._build_business_params(),
                            "data": {
                                "status": self.STATUS_FIRST_FRAME,
                                "format": self.recognition_config.format,
                                "audio": base64.b64encode(buf).decode("utf-8"),
                                "encoding": self.recognition_config.encoding,
                            },
                        }
                        ws.send(json.dumps(data))
                        status = self.STATUS_CONTINUE_FRAME

                    elif status == self.STATUS_CONTINUE_FRAME:
                        data = {
                            "data": {
                                "status": self.STATUS_CONTINUE_FRAME,
                                "format": self.recognition_config.format,
                                "audio": base64.b64encode(buf).decode("utf-8"),
                                "encoding": self.recognition_config.encoding,
                            }
                        }
                        ws.send(json.dumps(data))

                    elif status == self.STATUS_LAST_FRAME:
                        data = {
                            "data": {
                                "status": self.STATUS_LAST_FRAME,
                                "format": self.recognition_config.format,
                                "audio": base64.b64encode(buf).decode("utf-8"),
                                "encoding": self.recognition_config.encoding,
                            }
                        }
                        ws.send(json.dumps(data))
                        time.sleep(1)
                        break

                    time.sleep(self.recognition_config.interval)

            except Exception as e:
                logger.error(f"音频处理异常: {e}")
                with self._lock:
                    self.final_result.success = False
                    self.final_result.error_message = str(e)
            finally:
                ws.close()

        # 使用线程处理音频发送
        self.ws_thread = threading.Thread(target=run)
        self.ws_thread.daemon = True
        self.ws_thread.start()

    def validate_config(self) -> bool:
        """验证配置"""
        if not self.app_id:
            self.logger.error("缺少 app_id")
            return False
        if not self.api_secret:
            self.logger.error("缺少 api_secret")
            return False
        return True

    def validate_request(self, request: ASRRecognizeRequest) -> None:
        """请求参数校验"""
        # 复用基类的基础校验
        super().validate_request(request)
        # 额外校验：编码与格式基本可用
        if not hasattr(request.audio_format, "value"):
            raise ASRRecognitionError("音频格式无效")
        if not hasattr(request.codec, "value"):
            raise ASRRecognitionError("音频编解码标识无效")

    async def recognize(self, request: ASRRecognizeRequest) -> ASRResponse:
        """整段语音识别"""
        if not self._enabled:
            return ASRResponse.failed(error_message="流式识别失败: enable = False")

        try:
            # 验证请求参数
            self.validate_request(request)

            future = asyncio.Future()
            self._stream_future = future

            try:
                self._reset()

                # 创建WebSocket连接
                websocket.enableTrace(False)
                ws_url = self._create_url()
                self.ws = websocket.WebSocketApp(
                    ws_url,
                    on_message=self._on_message,
                    on_error=self._on_error,
                    on_close=self._on_close,
                )

                audio_data = request.audio_data
                if not isinstance(audio_data, bytes):
                    with open(request.audio_data, "rb") as f:
                        audio_data = f.read()
                self.ws.on_open = lambda ws: self._on_open(ws, audio_data)

                # 运行WebSocket连接
                self.ws.run_forever(
                    sslopt={"cert_reqs": ssl.CERT_NONE}, ping_timeout=30
                )

                # 等待线程完成
                if self.ws_thread and self.ws_thread.is_alive():
                    self.ws_thread.join(timeout=10)

                if not future.done():
                    future.set_result(self._parse_asr_result(self.final_result.text))

            except Exception as e:
                logger.error(f"讯飞ASR识别失败: {e}")
                if not future.done():
                    future.set_exception(e)
            finally:
                # 确保WebSocket连接和线程被正确关闭
                self._cleanup_websocket()

            return await future
        except Exception as e:
            self.logger.error(f"流式识别失败: {e}")
            return ASRResponse.failed(error_message=f"流式识别失败: {e!s}")

    async def recognize_stream(
        self,
        request: ASRRecognizeRequest,
    ) -> AsyncIterator[ASRResponse]:
        """
        流式语音识别 - 用于麦克风实时识别，会持续一段时间或到1分钟时，由平台强制断开，业务需要，请手动重连

        Args:
            request: 识别请求参数

        Yields:
            ASRResponse: 流式识别结果

        Raises:
            ASRRecognitionError: 如果识别过程中出现错误
        """
        if not self._enabled:
            yield ASRResponse.failed(error_message="讯飞ASR未启用")
            return

        try:
            # 验证请求参数
            self.validate_request(request)

            # 检查是否提供了音频流
            if not hasattr(request, "audio_stream") or request.audio_stream is None:
                raise ASRRecognitionError("流式识别需要提供 audio_stream 参数")

            # 创建Future对象来等待最终结果
            future: asyncio.Future[ASRResponse] = asyncio.Future()
            self._stream_future = future

            # 用于追踪中间结果文本，避免重复触发
            last_partial_text = ""

            # 存储中间结果
            self._intermediate_results: list[ASRResponse] = []

            def on_message_callback(_ws, message):
                """WebSocket消息回调"""
                nonlocal last_partial_text
                try:
                    response = json.loads(message)
                    code = response.get("code", -1)

                    if code != 0:
                        error_msg = response.get("message", "未知错误")
                        error_response = ASRResponse.failed(
                            error_message=f"讯飞ASR错误: {error_msg}"
                        )
                        self._intermediate_results.append(error_response)
                        self._emit_error(ASRRecognitionError(error_msg))
                        if not future.done():
                            future.set_exception(ASRRecognitionError(error_msg))
                        return

                    # 处理识别结果
                    data_obj = response.get("data", {})
                    result_data = data_obj.get("result", {})
                    ws_list = result_data.get("ws", [])
                    status = data_obj.get("status", 0)

                    if ws_list:
                        # 构建文本结果
                        text = ""
                        for item in ws_list:
                            for word_info in item.get("cw", []):
                                text += word_info.get("w", "")

                        if status == 2:
                            # 最终结果：无论文本是否与上次相同，都触发
                            final_text = text if text else last_partial_text
                            final_response = ASRResponse.success(text=final_text)
                            self._intermediate_results.append(final_response)
                            self._emit_final(final_response)
                            last_partial_text = ""
                            if not future.done():
                                future.set_result(final_response)
                        elif text and text != last_partial_text:
                            # 中间结果：只有文本变化时才触发
                            last_partial_text = text
                            intermediate_response = ASRResponse.partial(text=text)
                            self._intermediate_results.append(intermediate_response)
                            self._emit_partial(intermediate_response)
                    elif status == 2:
                        # 无文本的最终结果
                        final_text = last_partial_text or ""
                        final_response = ASRResponse.success(text=final_text)
                        self._intermediate_results.append(final_response)
                        self._emit_final(final_response)
                        last_partial_text = ""
                        if not future.done():
                            future.set_result(final_response)

                except Exception as e:
                    self.logger.error(f"处理讯飞ASR消息失败: {e}")
                    self._emit_error(e)
                    if not future.done():
                        future.set_exception(e)

            def on_error_callback(_ws, error):
                """错误回调"""
                error_msg = f"WebSocket错误: {error}"
                self.logger.error(error_msg)
                self._emit_error(ASRRecognitionError(error_msg))
                if not future.done():
                    future.set_exception(ASRRecognitionError(error_msg))

            def on_close_callback(_ws, close_status_code, close_msg):
                """连接关闭回调"""
                self.logger.info(f"WebSocket连接关闭: {close_status_code}, {close_msg}")
                self._emit_close()

            # 创建WebSocket连接
            websocket.enableTrace(False)
            ws_url = self._create_url()

            # 使用适配器模式将同步WebSocket包装为异步
            self.ws = websocket.WebSocketApp(
                ws_url,
                on_message=on_message_callback,
                on_error=on_error_callback,
                on_close=on_close_callback,
            )

            # 设置连接建立回调
            def on_open_callback(_ws):
                """连接建立回调"""
                self.logger.info("讯飞ASR WebSocket连接已建立")
                self._emit_start()

            self.ws.on_open = on_open_callback

            # 启动WebSocket连接（在新线程中运行）
            ws_thread = threading.Thread(
                target=lambda: self.ws.run_forever(
                    sslopt={"cert_reqs": ssl.CERT_NONE}, ping_timeout=30
                )
            )
            ws_thread.daemon = True
            ws_thread.start()

            # 等待连接建立
            await asyncio.sleep(0.1)

            # 发送初始帧
            try:
                first_data = {
                    "common": {"app_id": self.app_id},
                    "business": self._build_business_params(),
                    "data": {
                        "status": self.STATUS_FIRST_FRAME,
                        "format": self.recognition_config.format,
                        "encoding": self.recognition_config.encoding,
                    },
                }
                self.ws.send(json.dumps(first_data))
            except Exception as e:
                self.logger.error(f"发送初始帧失败: {e}")
                self._emit_error(e)
                yield ASRResponse.failed(error_message=f"发送初始帧失败: {e!s}")
                return

            async def process_audio_stream():
                """处理音频流数据"""
                try:
                    async for chunk in request.audio_stream:
                        if hasattr(self, "_stream_stopped") and self._stream_stopped:
                            break

                        # 发送继续帧
                        data = {
                            "data": {
                                "status": self.STATUS_CONTINUE_FRAME,
                                "format": self.recognition_config.format,
                                "audio": base64.b64encode(chunk).decode("utf-8"),
                                "encoding": self.recognition_config.encoding,
                            }
                        }
                        self.ws.send(json.dumps(data))
                        await asyncio.sleep(self.recognition_config.interval)

                    # 发送最后一帧
                    last_data = {
                        "data": {
                            "status": self.STATUS_LAST_FRAME,
                            "format": self.recognition_config.format,
                            "audio": base64.b64encode(b"").decode("utf-8"),
                            "encoding": self.recognition_config.encoding,
                        }
                    }
                    self.ws.send(json.dumps(last_data))

                except Exception as e:
                    self.logger.error(f"处理音频流失败: {e}")
                    self._emit_error(e)
                    if not future.done():
                        future.set_exception(e)

            async def yield_intermediate_results():
                """产生中间结果"""
                last_index = 0
                while not future.done():
                    # 检查是否有新的中间结果
                    if last_index < len(self._intermediate_results):
                        for i in range(last_index, len(self._intermediate_results)):
                            yield self._intermediate_results[i]
                        last_index = len(self._intermediate_results)

                    await asyncio.sleep(0.1)

                # 返回最终结果（如果还没有被 yield）
                if last_index < len(self._intermediate_results):
                    for i in range(last_index, len(self._intermediate_results)):
                        yield self._intermediate_results[i]

            # 启动音频流处理任务
            stream_task = asyncio.create_task(process_audio_stream())

            try:
                # 产生中间结果和最终结果
                async for result in yield_intermediate_results():
                    yield result

            finally:
                # 清理
                if not stream_task.done():
                    stream_task.cancel()

                # 关闭WebSocket连接
                if self.ws:
                    self.ws.close()

        except Exception as e:
            self.logger.error(f"流式识别失败: {e}")
            self._emit_error(e)
            yield ASRResponse.failed(error_message=f"流式识别失败: {e!s}")

    # ============ 推送式流式接口实现（start/feed/stop） ============

    def start_stream(self, request: ASRRecognizeRequest) -> None:
        """启动推送式流式识别会话（配合 `feed_audio_chunk` 使用）

        Args:
            request: 识别参数配置（streaming_mode 应为 True）

        Raises:
            ASRRecognitionError: 启动失败
        """
        if self._stream_started:
            self.logger.warning("流式识别已在运行中")
            return

        if not self._enabled:
            raise ASRRecognitionError("讯飞ASR未启用")

        # 允许调用方不显式设置 streaming_mode
        if not request.streaming_mode:
            request.streaming_mode = True

        self.validate_request(request)

        # 重置状态
        self._push_stream_request = request
        self._push_stream_first_frame_sent = False
        self._last_partial_text = ""
        self._push_stream_connected.clear()
        self._push_stream_finished.clear()
        self._push_stream_audio_queue = queue.Queue()

        def _ws_thread_main() -> None:
            """WebSocket 线程主函数"""
            try:
                ws_url = self._create_url()
                self._push_stream_ws = websocket.WebSocketApp(
                    ws_url,
                    on_message=self._push_on_message,
                    on_error=self._push_on_error,
                    on_close=self._push_on_close,
                    on_open=self._push_on_open,
                )
                self._push_stream_ws.run_forever(
                    sslopt={"cert_reqs": ssl.CERT_NONE}, ping_timeout=30
                )
            except Exception as e:
                self.logger.error(f"WebSocket线程异常: {e}")
                self._emit_error(e)
            finally:
                self._push_stream_finished.set()

        # 启动 WebSocket 线程
        self._push_stream_thread = threading.Thread(
            target=_ws_thread_main, name="xunfei-asr-push-stream", daemon=True
        )
        self._push_stream_thread.start()

        # 等待连接建立
        if not self._push_stream_connected.wait(
            timeout=self._push_stream_connect_timeout
        ):
            self.stop_stream()
            raise ASRRecognitionError("启动流式识别超时，未能建立 WebSocket 连接")

        self._stream_started = True
        self._emit_start()
        self.logger.info("讯飞 ASR 推送式流式识别已启动")

    def feed_audio_chunk(self, pcm_chunk: bytes) -> None:
        """推送音频数据块

        Args:
            pcm_chunk: PCM 格式音频数据

        Raises:
            ASRRecognitionError: 会话未启动或发送失败
        """
        if not self._stream_started:
            raise ASRRecognitionError("流式识别会话未启动")

        if not pcm_chunk:
            return

        if not self._push_stream_ws:
            raise ASRRecognitionError("WebSocket 连接未就绪")

        try:
            # 将音频放入队列，由发送线程处理
            self._push_stream_audio_queue.put(pcm_chunk)
        except Exception as e:
            error = ASRRecognitionError(f"发送音频数据失败: {e}")
            self._emit_error(error)
            raise error

    def stop_stream(self) -> None:
        """停止推送式流式识别会话"""
        if not self._stream_started:
            # 清理可能残留的资源
            self._cleanup_push_stream()
            return

        self.logger.info("停止讯飞 ASR 推送式流式识别")

        # 发送结束信号
        try:
            self._push_stream_audio_queue.put(None)
        except Exception:
            pass

        # 等待会话结束
        if not self._push_stream_finished.wait(timeout=self._push_stream_stop_timeout):
            self.logger.warning("等待流式会话结束超时")

        self._cleanup_push_stream()

    def _cleanup_push_stream(self) -> None:
        """清理推送式流式识别资源"""
        if self._push_stream_ws:
            try:
                self._push_stream_ws.close()
            except Exception:
                pass
            self._push_stream_ws = None

        if self._push_stream_thread and self._push_stream_thread.is_alive():
            self._push_stream_thread.join(timeout=2)
        self._push_stream_thread = None

        self._stream_started = False
        self._push_stream_first_frame_sent = False
        self._push_stream_request = None
        self._last_partial_text = ""
        # 清空队列
        while not self._push_stream_audio_queue.empty():
            try:
                self._push_stream_audio_queue.get_nowait()
            except queue.Empty:
                break

    def _push_on_open(self, ws) -> None:
        """推送式流式识别 WebSocket 连接建立回调"""
        self.logger.info("讯飞 ASR WebSocket 连接已建立")
        self._push_stream_connected.set()

        def _send_audio_thread():
            """音频发送线程"""
            try:
                while True:
                    try:
                        chunk = self._push_stream_audio_queue.get(timeout=0.1)
                    except queue.Empty:
                        continue

                    if chunk is None:
                        # 发送结束帧
                        self._send_last_frame(ws)
                        break

                    # 发送音频帧
                    self._send_audio_frame(ws, chunk)

            except Exception as e:
                self.logger.error(f"音频发送线程异常: {e}")
                self._emit_error(e)

        # 启动音频发送线程
        send_thread = threading.Thread(
            target=_send_audio_thread, name="xunfei-asr-send", daemon=True
        )
        send_thread.start()

    def _send_audio_frame(self, ws, chunk: bytes) -> None:
        """发送音频帧"""
        try:
            if not self._push_stream_first_frame_sent:
                # 发送首帧（包含 common 和 business）
                data = {
                    "common": {"app_id": self.app_id},
                    "business": self._build_business_params(),
                    "data": {
                        "status": self.STATUS_FIRST_FRAME,
                        "format": self.recognition_config.format,
                        "audio": base64.b64encode(chunk).decode("utf-8"),
                        "encoding": self.recognition_config.encoding,
                    },
                }
                ws.send(json.dumps(data))
                self._push_stream_first_frame_sent = True
            else:
                # 发送中间帧
                data = {
                    "data": {
                        "status": self.STATUS_CONTINUE_FRAME,
                        "format": self.recognition_config.format,
                        "audio": base64.b64encode(chunk).decode("utf-8"),
                        "encoding": self.recognition_config.encoding,
                    }
                }
                ws.send(json.dumps(data))
        except Exception as e:
            self.logger.error(f"发送音频帧失败: {e}")
            raise

    def _send_last_frame(self, ws) -> None:
        """发送结束帧"""
        try:
            if not self._push_stream_first_frame_sent:
                # 如果还没发送过首帧，需要先发送首帧
                data = {
                    "common": {"app_id": self.app_id},
                    "business": self._build_business_params(),
                    "data": {
                        "status": self.STATUS_LAST_FRAME,
                        "format": self.recognition_config.format,
                        "audio": base64.b64encode(b"").decode("utf-8"),
                        "encoding": self.recognition_config.encoding,
                    },
                }
            else:
                data = {
                    "data": {
                        "status": self.STATUS_LAST_FRAME,
                        "format": self.recognition_config.format,
                        "audio": base64.b64encode(b"").decode("utf-8"),
                        "encoding": self.recognition_config.encoding,
                    }
                }
            ws.send(json.dumps(data))
            self.logger.info("讯飞 ASR 发送结束帧")
        except Exception as e:
            self.logger.error(f"发送结束帧失败: {e}")

    def _push_on_message(self, _ws, message: str) -> None:
        """推送式流式识别消息回调"""
        try:
            response = json.loads(message)
            code = response.get("code", -1)
            sid = response.get("sid", "")

            if code != 0:
                error_msg = response.get("message", "未知错误")
                self.logger.error(
                    f"讯飞ASR错误 - sid: {sid}, code: {code}, message: {error_msg}"
                )
                error = ASRRecognitionError(f"讯飞ASR错误(code={code}): {error_msg}")
                self._emit_error(error)
                return

            # 解析识别结果
            data = response.get("data", {})
            result_data = data.get("result", {})
            ws_list = result_data.get("ws", [])
            status = data.get("status", 0)
            # 动态修正模式 (dwa=wpgs) 的 pgs 字段：rpl=替换, apd=追加
            pgs = result_data.get("pgs", "")

            if ws_list:
                # 构建当前片段文本
                segment_text = ""
                for item in ws_list:
                    for word_info in item.get("cw", []):
                        segment_text += word_info.get("w", "")

                # 处理动态修正模式
                if pgs == "rpl":
                    # 替换模式：用当前片段替换（这里简化处理，直接更新）
                    current_text = segment_text
                elif pgs == "apd":
                    # 追加模式：追加到之前的文本
                    current_text = self._last_partial_text + segment_text
                else:
                    # 非动态修正模式：直接使用当前文本
                    current_text = segment_text

                if status == 2:
                    # 最终结果：使用累积的文本
                    final_text = (
                        current_text if current_text else self._last_partial_text
                    )
                    resp = ASRResponse.success(text=final_text)
                    self._emit_final(resp)
                    self._last_partial_text = ""
                    self.logger.info(f"讯飞 ASR 最终识别结果: {final_text}")
                    # 收到最终结果后标记完成，避免 stop_stream 等待超时
                    self._push_stream_finished.set()
                elif current_text and current_text != self._last_partial_text:
                    # 中间结果（只有文本变化时才触发）
                    self._last_partial_text = current_text
                    resp = ASRResponse.partial(text=current_text)
                    self._emit_partial(resp)
                    self.logger.debug(f"讯飞 ASR 中间识别结果: {current_text}")
            elif status == 2:
                # 无文本的最终结果
                final_text = self._last_partial_text or ""
                resp = ASRResponse.success(text=final_text)
                self._emit_final(resp)
                self._last_partial_text = ""
                # 收到最终结果后标记完成
                self._push_stream_finished.set()

        except json.JSONDecodeError as e:
            self.logger.error(f"JSON解析错误: {e}")
            self._emit_error(ASRRecognitionError(f"JSON解析错误: {e}"))
        except Exception as e:
            self.logger.error(f"消息处理异常: {e}")
            self._emit_error(e)

    def _push_on_error(self, _ws, error) -> None:
        """推送式流式识别错误回调"""
        self.logger.error(f"讯飞 ASR WebSocket错误: {error}")
        self._emit_error(ASRRecognitionError(str(error)))

    def _push_on_close(self, _ws, close_status_code, close_msg) -> None:
        """推送式流式识别关闭回调"""
        self.logger.info(
            f"讯飞 ASR WebSocket关闭 - code: {close_status_code}, msg: {close_msg}"
        )
        self._push_stream_finished.set()
        self._emit_close()

    @staticmethod
    def _parse_asr_result(message) -> ASRResponse:
        try:
            return ASRResponse.success(
                text=message,
            )
        except Exception as e:
            # 错误处理
            return ASRResponse.failed(
                error_message=f"解析ASR结果失败: {e!s}",
                metadata={"raw_response": message},
            )

    def _cleanup_websocket(self):
        """清理WebSocket连接和相关资源"""
        try:
            if self.ws:
                self.ws.close()
                self.ws = None

            # 等待线程结束
            if self.ws_thread and self.ws_thread.is_alive():
                self.ws_thread.join(timeout=1)
                self.ws_thread = None

        except Exception as e:
            logger.warning(f"WebSocket清理异常: {e}")

    def recognize_streaming(self, pcm_chunk: bytes) -> str | None:
        """流式识别"""
        if not self._enabled or not pcm_chunk:
            return None

        try:
            audio_np = np.frombuffer(pcm_chunk, dtype=np.int16)
        except Exception as exc:
            logger.error(f"流式识别异常: {exc}")
            return None

        if audio_np.size == 0:
            return None

        rms = float(np.sqrt(np.mean(audio_np.astype(np.float32) ** 2)))
        is_voice_frame = rms >= self._silence_threshold

        buffer_bytes = b""
        finalize = False
        enough_speech = False

        with self._stream_lock:
            if not self._stream_in_speech:
                if not is_voice_frame:
                    return None
                self._stream_in_speech = True
                self._stream_buffer = bytearray()
                self._stream_silence_frames = 0
                self._stream_speech_frames = 0

            self._stream_buffer.extend(pcm_chunk)
            self._stream_speech_frames += 1

            if is_voice_frame:
                self._stream_silence_frames = 0
            else:
                self._stream_silence_frames += 1

            if self._stream_silence_frames >= self._max_silence_frames:
                finalize = True
                enough_speech = self._stream_speech_frames >= self._min_speech_frames
            elif self._stream_speech_frames >= self._max_stream_duration_frames:
                finalize = True
                enough_speech = True

            if finalize:
                buffer_bytes = bytes(self._stream_buffer)
                self._stream_buffer = bytearray()
                self._stream_in_speech = False
                self._stream_silence_frames = 0
                self._stream_speech_frames = 0

        if not finalize:
            return None

        if not enough_speech or not buffer_bytes:
            logger.debug("流式识别结束")
            return None

        result = self.recognize(buffer_bytes).strip()
        if result:
            logger.debug(f"流式识别结果: {result}")
            return result
        return None

    def set_silence_threshold(self, threshold: int) -> None:
        """设置静音阈值"""
        # 讯飞使用vad_eos参数控制静音检测（毫秒）
        self.recognition_config.vad_eos = threshold * 1000

    def get_config(self) -> dict[str, Any]:
        """获取当前配置"""
        return {
            "app_id": self.app_id,
            "language": self.recognition_config.language,
            "accent": self.recognition_config.accent,
            "vad_eos": self.recognition_config.vad_eos,
            "frame_size": self.recognition_config.frame_size,
            "enabled": self._enabled,
            **self._config_dict,
        }

    def _reset(self) -> None:
        """重置识别器状态"""
        with self._lock:
            self.result_text = ""
            self.temp_data_list = []
            self.temp_result_list = []
            self.final_result = RecognitionResult(success=False, data=[], text="")

        with self._stream_lock:
            self._stream_buffer = bytearray()
            self._stream_in_speech = False
            self._stream_silence_frames = 0
            self._stream_speech_frames = 0

    def reset(self) -> None:
        """重置识别器状态"""
        self._reset()
        # 清理WebSocket连接
        self._cleanup_websocket()

    def close(self) -> None:
        """关闭连接"""
        self._cleanup_websocket()
        self.reset()

    def is_available(self) -> bool:
        """检查服务是否可用"""
        return self._enabled and all([self.app_id, self.api_key, self.api_secret])
