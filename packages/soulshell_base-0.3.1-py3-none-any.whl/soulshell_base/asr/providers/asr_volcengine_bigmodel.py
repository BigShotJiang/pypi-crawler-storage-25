"""
火山引擎大模型流式语音识别 (SAUC BigModel) 提供商实现
基于源代码: examples/source/volcengine_bigmodel_asr.py
文档: https://www.volcengine.com/docs/6561/1354869

支持两种模式:
1. 双向流式模式 (bigmodel): wss://openspeech.bytedance.com/api/v3/sauc/bigmodel
2. 流式输入模式 (bigmodel_nostream): wss://openspeech.bytedance.com/api/v3/sauc/bigmodel_nostream
"""

import asyncio
import gzip
from io import BytesIO
import json
import struct
from typing import Any, AsyncIterator, Iterator, Optional
import uuid
import wave

try:
    import aiohttp

    AIOHTTP_AVAILABLE = True
except ImportError:
    AIOHTTP_AVAILABLE = False
    aiohttp = None

from soulshell_base.core import get_logger

from ..base import BaseASR
from ..exceptions import ASRRecognitionError
from ..models import ASRRecognizeRequest, ASRResponse, AudioFormat

logger = get_logger(__name__)

# ========== V3 协议常量 ==========
PROTOCOL_VERSION = 0b0001
DEFAULT_HEADER_SIZE = 0b0001

# 消息类型
CLIENT_FULL_REQUEST = 0b0001
CLIENT_AUDIO_ONLY_REQUEST = 0b0010
SERVER_FULL_RESPONSE = 0b1001
SERVER_ERROR_RESPONSE = 0b1111

# 消息类型特定标志
NO_SEQUENCE = 0b0000
POS_SEQUENCE = 0b0001
NEG_SEQUENCE = 0b0010
NEG_WITH_SEQUENCE = 0b0011

# 序列化方法
NO_SERIALIZATION = 0b0000
JSON = 0b0001

# 压缩方法
NO_COMPRESSION = 0b0000
GZIP = 0b0001

# ========== 错误码定义 ==========
ERROR_CODES = {
    20000000: "成功",
    45000001: "请求参数无效 - 请求参数缺失必需字段/字段值无效/重复请求",
    45000002: "空音频",
    45000081: "等包超时",
    45000151: "音频格式不正确",
    55000031: "服务器繁忙 - 服务过载，无法处理当前请求",
}

# 错误码分类
ERROR_CODE_PARAM = [45000001, 45000002, 45000151]  # 参数错误
ERROR_CODE_TIMEOUT = [45000081]  # 超时错误
ERROR_CODE_SERVER = [55000031]  # 服务器错误

# ========== 默认配置常量 ==========
DEFAULT_SEGMENT_SIZE = 6400  # 默认音频分段大小(字节)
DEFAULT_SEG_DURATION = 200  # 默认分段时长(毫秒)
DEFAULT_WS_TIMEOUT = 30.0  # WebSocket 操作超时(秒)
DEFAULT_RECEIVE_TIMEOUT = 180.0  # 接收消息超时(秒)


class VolcengineBigModelResource:
    """
    豆包流式语音识别模型1.0

    小时版：volc.bigasr.sauc.duration
    并发版：volc.bigasr.sauc.concurrent
    豆包流式语音识别模型2.0

    小时版：volc.seedasr.sauc.duration
    并发版：volc.seedasr.sauc.concurrent
    """

    __slots__ = ()


class VolcengineBigModelASRProvider(BaseASR):
    """火山引擎 SAUC 大模型 ASR 提供商"""

    def __init__(
        self,
        app_key: str,
        access_key: str,
        ws_url: str = "wss://openspeech.bytedance.com/api/v3/sauc/bigmodel",
        **kwargs,
    ):
        super().__init__(**kwargs)

        if not AIOHTTP_AVAILABLE:
            raise ImportError("需要安装 aiohttp 库。请运行: pip install aiohttp")

        self.app_key = app_key
        self.access_key = access_key
        self.ws_url = ws_url
        self.seg_duration = int(kwargs.get("seg_duration", DEFAULT_SEG_DURATION))
        self.uid = kwargs.get("uid", "sauc_asr_demo")
        # 调用服务的资源信息 ID：VolcengineBigModelResource
        self.resource_id = kwargs.get("resource_id", "volc.bigasr.sauc.duration")
        self.ws_timeout = float(kwargs.get("ws_timeout", DEFAULT_WS_TIMEOUT))
        self.receive_timeout = float(
            kwargs.get("receive_timeout", DEFAULT_RECEIVE_TIMEOUT)
        )

        # 连接池：复用 ClientSession
        self._session: Optional[aiohttp.ClientSession] = None
        self._session_lock = asyncio.Lock()

        # 当前请求上下文（用于异常信息增强）
        self._current_reqid: Optional[str] = None

        self.logger.info(
            f"初始化火山引擎 SAUC 大模型 ASR: url={self.ws_url}, "
            f"seg_duration={self.seg_duration}ms, ws_timeout={self.ws_timeout}s"
        )

    def get_provider_name(self) -> str:
        return "volcengine_bigmodel"

    async def _get_session(self) -> aiohttp.ClientSession:
        """获取或创建 ClientSession（连接池）

        使用单例模式复用 ClientSession，避免频繁创建和销毁连接。
        使用锁确保线程安全。

        Returns:
            ClientSession 实例
        """
        async with self._session_lock:
            if self._session is None or self._session.closed:
                timeout = aiohttp.ClientTimeout(total=self.ws_timeout)
                self._session = aiohttp.ClientSession(timeout=timeout)
                self.logger.debug("创建新的 ClientSession")
            return self._session

    async def close(self) -> None:
        """关闭 ClientSession 并释放资源

        应在提供商不再使用时调用，通常在应用关闭时。
        """
        async with self._session_lock:
            if self._session and not self._session.closed:
                await self._session.close()
                self.logger.info("ClientSession 已关闭")
                self._session = None

    async def __aenter__(self):
        """支持异步上下文管理器"""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """退出上下文时自动关闭连接"""
        await self.close()

    @classmethod
    def describe(cls) -> dict[str, Any]:
        return {
            "provider_name": "volcengine_bigmodel",
            "display_name": "火山引擎 SAUC 大模型 ASR",
            "description": "火山引擎 SAUC 大模型流式语音识别服务 (V3 协议)",
            "required_init_params": {
                "app_key": {
                    "type": "str",
                    "description": "应用密钥",
                    "env_var": "ASR_VOLCENGINE_APP_KEY",
                },
                "access_key": {
                    "type": "str",
                    "description": "访问密钥",
                    "env_var": "ASR_VOLCENGINE_ACCESS_KEY",
                },
            },
            "optional_init_params": {
                "ws_url": {
                    "type": "str",
                    "description": "WebSocket URL",
                    "default": "wss://openspeech.bytedance.com/api/v3/sauc/bigmodel",
                },
                "seg_duration": {
                    "type": "int",
                    "description": "音频分段时长(毫秒)",
                    "default": DEFAULT_SEG_DURATION,
                },
                "ws_timeout": {
                    "type": "float",
                    "description": "WebSocket连接超时(秒)",
                    "default": DEFAULT_WS_TIMEOUT,
                },
                "receive_timeout": {
                    "type": "float",
                    "description": "接收消息超时(秒)",
                    "default": DEFAULT_RECEIVE_TIMEOUT,
                },
            },
            "supported_methods": [
                "recognize: 流式识别(返回最终结果)",
                "recognize_stream: 流式识别(返回中间结果)",
            ],
        }

    def validate_config(self) -> bool:
        if not self.app_key:
            self.logger.error("缺少 app_key")
            return False
        if not self.access_key:
            self.logger.error("缺少 access_key")
            return False
        return True

    def validate_request(self, request: ASRRecognizeRequest) -> None:
        """请求参数校验"""
        super().validate_request(request)
        if not hasattr(request.audio_format, "value"):
            raise ASRRecognitionError("音频格式无效")

    async def recognize(self, request: ASRRecognizeRequest) -> ASRResponse:
        """异步识别音频(等待最终结果)"""
        try:
            self.validate_request(request)

            # 统一使用流式处理,只返回最终结果
            last_response = None
            async for response in self._execute_recognition(request):
                if response.is_success:
                    return response
                last_response = response

            # 如果没有成功响应,返回最后一个响应或失败
            if last_response:
                return last_response
            return ASRResponse.failed(error_message="未收到识别结果")

        except Exception as e:
            self.logger.error(f"识别失败: {e}")
            return ASRResponse.failed(error_message=f"识别失败: {e!s}")

    async def recognize_stream(
        self, request: ASRRecognizeRequest
    ) -> AsyncIterator[ASRResponse]:
        """流式识别(返回所有中间结果和最终结果)"""
        self.validate_request(request)

        if not hasattr(request, "audio_stream") or request.audio_stream is None:
            yield ASRResponse.failed(error_message="流式识别需要提供 audio_stream")
            return

        async for response in self._execute_recognition(request):
            yield response

    async def _execute_recognition(
        self, request: ASRRecognizeRequest
    ) -> AsyncIterator[ASRResponse]:
        """统一的识别执别逻辑(流式处理,有数据时返回)"""
        reqid = str(uuid.uuid4())
        self._current_reqid = reqid  # 保存当前请求ID用于异常信息增强

        request_params = self._construct_request(reqid, request)
        payload_bytes = gzip.compress(json.dumps(request_params).encode("utf-8"))

        seq = 1
        full_request = self._build_full_request(payload_bytes, seq)
        auth_headers = self._build_auth_headers()

        # 判断音频源类型
        is_bytes_audio = isinstance(request.audio_data, bytes)
        audio_source = request.audio_data if is_bytes_audio else request.audio_stream

        # 计算分段大小(仅字节音频需要)
        segment_size = None
        audio_size = 0
        if is_bytes_audio:
            audio_size = len(request.audio_data)
            segment_size = self._calculate_segment_size(
                request.audio_data, request.audio_format
            )

        ws = None
        try:
            # 使用连接池获取 session
            session = await self._get_session()
            ws = await session.ws_connect(self.ws_url, headers=auth_headers)
            self.logger.info(
                f"WebSocket连接成功 (reqid={reqid}, url={self.ws_url}, "
                f"audio_size={audio_size if is_bytes_audio else 'stream'})"
            )

            # 发送完整请求
            await ws.send_bytes(full_request)
            self.logger.info(f"已发送完整请求 (reqid={reqid})")

            # 接收初始响应
            try:
                msg = await asyncio.wait_for(ws.receive(), timeout=self.receive_timeout)
            except TimeoutError:
                error_msg = (
                    f"接收初始响应超时 (reqid={reqid}, timeout={self.receive_timeout}s)"
                )
                self.logger.error(error_msg)
                yield ASRResponse.failed(error_message=error_msg)
                return

            if msg.type != aiohttp.WSMsgType.BINARY:
                error_msg = f"初始响应类型错误 (reqid={reqid}, type={msg.type})"
                self.logger.error(error_msg)
                yield ASRResponse.failed(error_message=error_msg)
                return

            response = self._parse_response(msg.data)

            # 检查错误响应
            error_response = self._handle_error_response(response)
            if error_response:
                yield error_response
                return

            self.logger.debug(
                f"初始响应 (reqid={reqid}): {response.get('payload_msg')}"
            )

            # 序列号递增,音频包从2开始
            seq += 1

            # 启动发送和接收任务
            if is_bytes_audio:
                async for resp in self._process_bytes_audio(
                    ws, audio_source, segment_size, seq
                ):
                    yield resp
            else:
                async for resp in self._process_stream_audio(ws, audio_source, seq):
                    yield resp

        except aiohttp.ClientError as e:
            error_msg = (
                f"WebSocket连接错误 (reqid={reqid}, url={self.ws_url}): "
                f"{type(e).__name__}: {e!s}"
            )
            self.logger.error(error_msg, exc_info=True)
            yield ASRResponse.failed(error_message=error_msg)
        except TimeoutError as e:
            error_msg = f"连接超时 (reqid={reqid}, timeout={self.ws_timeout}s): {e!s}"
            self.logger.error(error_msg)
            yield ASRResponse.failed(error_message=error_msg)
        except Exception as e:
            error_msg = f"识别过程异常 (reqid={reqid}): {type(e).__name__}: {e!s}"
            self.logger.error(error_msg, exc_info=True)
            yield ASRResponse.failed(error_message=error_msg)
        finally:
            # 清理 WebSocket 连接（但保留 session 用于连接池）
            await self._cleanup_websocket(ws)
            self._current_reqid = None  # 清除请求上下文

    async def _process_bytes_audio(
        self, ws, audio_data: bytes, segment_size: int, seq: int
    ) -> AsyncIterator[ASRResponse]:
        """处理字节音频(分段发送)"""
        last_text = ""
        last_payload = None
        total_segments = (len(audio_data) + segment_size - 1) // segment_size

        try:
            for chunk, is_last in self._slice_data(audio_data, segment_size):
                # 构建并发送音频请求
                audio_request = self._build_audio_request(seq, chunk, is_last)
                await ws.send_bytes(audio_request)
                self.logger.debug(
                    f"已发送音频分段 (reqid={self._current_reqid}, seq={seq}/{total_segments}, "
                    f"size={len(chunk)}, last={is_last})"
                )

                # 接收响应(带超时)
                try:
                    msg = await asyncio.wait_for(
                        ws.receive(), timeout=self.receive_timeout
                    )
                except TimeoutError:
                    error_msg = (
                        f"接收响应超时 (reqid={self._current_reqid}, seq={seq}, "
                        f"timeout={self.receive_timeout}s)"
                    )
                    self.logger.error(error_msg)
                    yield ASRResponse.failed(error_message=error_msg)
                    return

                if msg.type != aiohttp.WSMsgType.BINARY:
                    self.logger.warning(
                        f"收到非二进制消息 (reqid={self._current_reqid}, seq={seq}, type={msg.type})"
                    )
                    continue

                response = self._parse_response(msg.data)

                # 检查错误响应
                error_response = self._handle_error_response(response)
                if error_response:
                    yield error_response
                    return

                # 处理识别结果
                result_response = self._handle_recognition_result(
                    response, last_text, last_payload
                )
                if result_response:
                    text, payload, asr_response = result_response
                    if text:
                        last_text = text
                        last_payload = payload
                    if asr_response:
                        yield asr_response
                        if asr_response.is_success:
                            return

                if not is_last:
                    seq += 1

                await asyncio.sleep(self.seg_duration / 1000)

            # 如果循环结束还没有返回最终结果,返回最后一次的文本
            if last_text:
                self.logger.info(
                    f"识别完成(循环结束) (reqid={self._current_reqid}): {last_text}"
                )
                yield ASRResponse.success(
                    text=last_text,
                    duration=self._extract_duration(last_payload),
                    metadata={"raw_response": last_payload},
                )
        except Exception as e:
            error_msg = (
                f"字节音频处理异常 (reqid={self._current_reqid}, seq={seq}): "
                f"{type(e).__name__}: {e!s}"
            )
            self.logger.error(error_msg, exc_info=True)
            yield ASRResponse.failed(error_message=error_msg)

    async def _process_stream_audio(
        self, ws, audio_stream: AsyncIterator[bytes], seq: int
    ) -> AsyncIterator[ASRResponse]:
        """处理流式音频(异步生成器)

        当收到 definite=True 时，表示服务端识别已结束，立即发送最后一帧并关闭连接。
        """
        last_partial_text = ""
        send_task = None
        early_stop_event = asyncio.Event()

        async def sender() -> None:
            """发送音频数据；收到 early_stop_event 时立即发送结束帧"""
            current_seq = seq
            it = audio_stream.__aiter__()
            get_next_task: Optional[asyncio.Task] = None
            try:
                while True:
                    # 并发等待：下一块音频 或 提前结束信号
                    if get_next_task is None:
                        get_next_task = asyncio.create_task(it.__anext__())
                    wait_stop = asyncio.create_task(early_stop_event.wait())

                    done, pending = await asyncio.wait(
                        [get_next_task, wait_stop],
                        return_when=asyncio.FIRST_COMPLETED,
                    )

                    if wait_stop in done:
                        # definite=True：提前结束，取消取块任务
                        for t in pending:
                            t.cancel()
                        try:
                            await get_next_task
                        except (asyncio.CancelledError, StopAsyncIteration):
                            pass
                        self.logger.info(
                            "收到 definite=True，提前发送结束帧 "
                            f"(reqid={self._current_reqid})"
                        )
                        break

                    if get_next_task in done:
                        try:
                            chunk = get_next_task.result()
                        except StopAsyncIteration:
                            break
                        get_next_task = None

                        if not chunk:
                            continue
                        audio_request = self._build_audio_request(
                            current_seq, chunk, False
                        )
                        await ws.send_bytes(audio_request)
                        self.logger.debug(
                            f"已发送音频分段 (reqid={self._current_reqid}, seq={current_seq})"
                        )
                        current_seq += 1
                        await asyncio.sleep(self.seg_duration / 1000)

                # 发送结束帧（自然结束或 definite 提前结束）
                audio_request = self._build_audio_request(current_seq, b"", True)
                await ws.send_bytes(audio_request)
                self.logger.info(
                    f"已发送结束帧 (reqid={self._current_reqid}, seq={current_seq})"
                )

            except asyncio.CancelledError:
                self.logger.debug("发送任务被取消")
                raise
            except Exception as e:
                self.logger.error(
                    f"发送任务异常: {type(e).__name__}: {e!s}", exc_info=True
                )
                raise

        try:
            # 记录开始日志
            self.logger.info(f"开始流式识别 (reqid={self._current_reqid})")

            # 启动发送任务
            send_task = asyncio.create_task(sender())

            # 接收响应
            async for msg in ws:
                if msg.type != aiohttp.WSMsgType.BINARY:
                    if msg.type == aiohttp.WSMsgType.ERROR:
                        error_msg = (
                            f"WebSocket错误 (reqid={self._current_reqid}): {msg.data}"
                        )
                        self.logger.error(error_msg)
                        yield ASRResponse.failed(error_message=error_msg)
                        break
                    elif msg.type == aiohttp.WSMsgType.CLOSED:
                        self.logger.info(
                            f"WebSocket连接已关闭 (reqid={self._current_reqid})"
                        )
                        break
                    else:
                        self.logger.debug(
                            f"收到非二进制消息 (reqid={self._current_reqid}, type={msg.type})"
                        )
                    continue

                response = self._parse_response(msg.data)

                # 检查错误响应
                error_response = self._handle_error_response(response)
                if error_response:
                    yield error_response
                    break

                payload_msg = response.get("payload_msg")
                # 检查 definite=True：服务端表示识别已结束，立即发送最后一帧并关闭
                if isinstance(payload_msg, dict) and self._is_definite_response(
                    payload_msg
                ):
                    early_stop_event.set()
                    self.logger.info(
                        f"检测到 definite=True，触发提前结束 (reqid={self._current_reqid})"
                    )

                # 处理识别结果
                result_response = self._handle_recognition_result(
                    response, last_partial_text, None
                )
                if result_response:
                    text, _, asr_response = result_response
                    if text:
                        last_partial_text = text
                    if asr_response:
                        yield asr_response
                        if asr_response.is_success:
                            break

        except Exception as e:
            error_msg = (
                f"流式音频处理异常 (reqid={self._current_reqid}): "
                f"{type(e).__name__}: {e!s}"
            )
            self.logger.error(error_msg, exc_info=True)
            yield ASRResponse.failed(error_message=error_msg)
        finally:
            # 清理发送任务：优先等待 sender 发送结束帧（definite 场景），超时则取消
            if send_task and not send_task.done():
                try:
                    await asyncio.wait_for(send_task, timeout=5.0)
                except TimeoutError:
                    send_task.cancel()
                    try:
                        await send_task
                    except asyncio.CancelledError:
                        self.logger.debug("发送任务已取消")
                    except Exception as e:
                        self.logger.error(f"取消发送任务时出错: {e}")
                except asyncio.CancelledError:
                    raise
                except Exception as e:
                    self.logger.error(f"等待发送任务时出错: {e}")

    async def _cleanup_websocket(self, ws) -> None:
        """清理 WebSocket 连接

        注意：不清理 ClientSession，因为它由连接池管理

        Args:
            ws: WebSocket 连接对象
        """
        try:
            if ws and not ws.closed:
                await ws.close()
                self.logger.debug(f"WebSocket连接已关闭 (reqid={self._current_reqid})")
        except Exception as e:
            self.logger.warning(
                f"关闭WebSocket时出错 (reqid={self._current_reqid}): {e}"
            )

    def _handle_error_response(self, response: dict[str, Any]) -> Optional[ASRResponse]:
        """处理错误响应

        Args:
            response: 解析后的响应字典

        Returns:
            如果是错误响应则返回 ASRResponse.failed，否则返回 None
        """
        if response.get("message_type") == SERVER_ERROR_RESPONSE:
            error_code = response.get("code", 0)
            error_msg = response.get("error_message", "未知错误")
            self.logger.error(
                f"服务器返回错误 (reqid={self._current_reqid}, code={error_code}): {error_msg}"
            )
            return ASRResponse.failed(
                error_code=str(error_code), error_message=error_msg
            )
        return None

    def _handle_recognition_result(
        self,
        response: dict[str, Any],
        last_text: str,
        last_payload: Optional[dict],  # noqa: ARG002
    ) -> Optional[tuple[str, Optional[dict], Optional[ASRResponse]]]:
        """处理识别结果响应

        Args:
            response: 解析后的响应字典
            last_text: 上一次的文本结果
            last_payload: 上一次的 payload (保留参数以保持接口一致性)

        Returns:
            (text, payload, asr_response) 元组，如果没有有效结果则返回 None
            - text: 提取的文本
            - payload: payload_msg 字典
            - asr_response: 如果需要返回则为 ASRResponse 对象，否则为 None
        """
        payload_msg = response.get("payload_msg")

        if not isinstance(payload_msg, dict):
            # 非字典响应，记录日志
            self.logger.debug(f"收到非字典响应: {response}")
            return None

        text = self._extract_text(payload_msg)
        is_final = response.get("is_last_package", False)

        # 只在有文本数据时返回结果对象
        if not text:
            # 空文本响应，记录日志
            self.logger.debug(f"收到空文本响应: {payload_msg}")
            return None

        if is_final:
            # 最终结果
            self.logger.info(f"识别完成: {text}")
            asr_response = ASRResponse.success(
                text=text,
                duration=self._extract_duration(payload_msg),
                metadata={"raw_response": payload_msg},
            )
            return text, payload_msg, asr_response

        if text != last_text:
            # 中间结果（去重）
            self.logger.debug(f"中间结果: {text}")
            asr_response = ASRResponse.partial(
                text=text,
                duration=self._extract_duration(payload_msg),
                metadata={"raw_response": payload_msg},
            )
            return text, payload_msg, asr_response

        # 文本未变化，不返回响应
        return text, payload_msg, None

    def _build_auth_headers(self) -> dict[str, str]:
        """构建认证请求头"""
        reqid = str(uuid.uuid4())
        return {
            "X-Api-Resource-Id": self.resource_id,
            "X-Api-Request-Id": reqid,
            "X-Api-Access-Key": self.access_key,
            "X-Api-App-Key": self.app_key,
        }

    def _construct_request(self, reqid: str, request: ASRRecognizeRequest) -> dict:
        """构建请求参数"""
        end_window_size = request.max_end_silence
        if end_window_size > 1500:
            end_window_size = 1500
            logger.warning(
                "火山ASR大模型最大VAD结束窗口 max_end_silence 最大支持 1500, 已设置为 1500, 请检查配置"
            )
        reqdata = {
            "user": {"uid": self.uid},
            "audio": {
                "format": request.audio_format.value,
                "codec": request.codec.value,
                "rate": request.sample_rate,
                "bits": request.bits,
                "channel": request.channel,
            },
            "request": {
                "reqid": reqid,
                "model_name": "bigmodel",
                "enable_itn": True,
                "enable_punc": True,
                "enable_ddc": True,
                "show_utterances": True,
                "enable_nonstream": "nostream" in self.ws_url,
                "result_type": "single",  # 增量返回
                "force_to_speech_time": request.max_start_silence,
                "end_window_size": end_window_size,
            },
        }
        corpus = {}
        if request.extra_params.get("boosting_table_id"):
            corpus["boosting_table_id"] = request.extra_params.get("boosting_table_id")
        if corpus:
            reqdata["request"]["corpus"] = corpus
        return reqdata

    def _build_full_request(self, payload_bytes: bytes, seq: int) -> bytes:
        """构建完整请求帧"""
        header = self._generate_header(
            message_type=CLIENT_FULL_REQUEST,
            message_type_specific_flags=POS_SEQUENCE,
            serial_method=JSON,
            compression_type=GZIP,
        )

        request = bytearray(header)
        request.extend(struct.pack(">i", seq))
        request.extend(struct.pack(">I", len(payload_bytes)))
        request.extend(payload_bytes)

        return bytes(request)

    def _build_audio_request(self, seq: int, chunk: bytes, is_last: bool) -> bytes:
        """构建音频请求帧"""
        compressed_chunk = gzip.compress(chunk)

        if is_last:
            header = self._generate_header(
                message_type=CLIENT_AUDIO_ONLY_REQUEST,
                message_type_specific_flags=NEG_WITH_SEQUENCE,
                serial_method=NO_SERIALIZATION,
                compression_type=GZIP,
            )
            seq = -seq
        else:
            header = self._generate_header(
                message_type=CLIENT_AUDIO_ONLY_REQUEST,
                message_type_specific_flags=POS_SEQUENCE,
                serial_method=NO_SERIALIZATION,
                compression_type=GZIP,
            )

        request = bytearray(header)
        request.extend(struct.pack(">i", seq))
        request.extend(struct.pack(">I", len(compressed_chunk)))
        request.extend(compressed_chunk)

        return bytes(request)

    def _generate_header(
        self,
        version: int = PROTOCOL_VERSION,
        message_type: int = CLIENT_FULL_REQUEST,
        message_type_specific_flags: int = NO_SEQUENCE,
        serial_method: int = JSON,
        compression_type: int = GZIP,
        reserved_data: bytes = bytes([0x00]),
    ) -> bytes:
        """生成协议头部

        Args:
            version: 协议版本
            message_type: 消息类型
            message_type_specific_flags: 消息类型特定标志
            serial_method: 序列化方法
            compression_type: 压缩类型
            reserved_data: 保留数据

        Returns:
            协议头部字节数据
        """
        header = bytearray()
        header.append((version << 4) | DEFAULT_HEADER_SIZE)
        header.append((message_type << 4) | message_type_specific_flags)
        header.append((serial_method << 4) | compression_type)
        header.extend(reserved_data)
        return bytes(header)

    def _parse_response(self, msg: bytes) -> dict[str, Any]:
        """解析服务器响应

        Args:
            msg: 服务器返回的二进制消息

        Returns:
            解析后的响应字典，包含 message_type, payload_msg 等字段
        """
        header_size = msg[0] & 0x0F
        message_type = msg[1] >> 4
        message_type_specific_flags = msg[1] & 0x0F
        serialization_method = msg[2] >> 4
        message_compression = msg[2] & 0x0F

        payload = msg[header_size * 4 :]

        result: dict[str, Any] = {
            "message_type": message_type,
            "message_type_specific_flags": message_type_specific_flags,
        }

        # 解析标志
        if message_type_specific_flags & 0x01:
            result["sequence"] = struct.unpack(">i", payload[:4])[0]
            payload = payload[4:]
        if message_type_specific_flags & 0x02:
            result["is_last_package"] = True
        if message_type_specific_flags & 0x04:
            result["event"] = struct.unpack(">i", payload[:4])[0]
            payload = payload[4:]

        # 解析消息类型
        if message_type == SERVER_FULL_RESPONSE:
            result["payload_size"] = struct.unpack(">I", payload[:4])[0]
            payload = payload[4:]
        elif message_type == SERVER_ERROR_RESPONSE:
            # 错误响应
            error_code = struct.unpack(">i", payload[:4])[0]
            result["code"] = error_code
            result["payload_size"] = struct.unpack(">I", payload[4:8])[0]
            payload = payload[8:]

            # 记录错误信息
            error_msg = ERROR_CODES.get(error_code, f"未知错误码: {error_code}")
            result["error_message"] = error_msg

        if not payload:
            return result

        # 解压缩
        if message_compression == GZIP:
            try:
                payload = gzip.decompress(payload)
            except gzip.BadGzipFile as e:
                self.logger.error(f"GZIP解压缩失败: {e}")
                return result
            except Exception as e:
                self.logger.error(f"解压缩失败: {e}")
                return result

        # 反序列化
        if serialization_method == JSON:
            try:
                result["payload_msg"] = json.loads(payload.decode("utf-8"))
            except json.JSONDecodeError as e:
                self.logger.error(f"JSON解析失败: {e}")
            except Exception as e:
                self.logger.error(f"反序列化失败: {e}")
        else:
            result["payload_msg"] = payload.decode("utf-8", errors="replace")

        return result

    def _is_definite_response(self, payload_msg: dict[str, Any]) -> bool:
        """检查响应是否表示本次识别已结束（utterances 中任一 definite=True）

        当 definite=True 时，服务端表示当前 WS 连接识别已完成，客户端应发送最后一帧并关闭连接。

        Args:
            payload_msg: 解析后的 payload_msg 字典

        Returns:
            若 utterances 中任一项 definite 为 True 则返回 True，否则 False
        """
        if not isinstance(payload_msg, dict):
            return False
        result = payload_msg.get("result") or payload_msg.get("results")
        if not isinstance(result, dict):
            return False
        utterances = result.get("utterances")
        if not isinstance(utterances, list):
            return False
        return any(
            isinstance(u, dict) and u.get("definite") is True for u in utterances
        )

    def _extract_text(self, payload_msg: dict[str, Any]) -> str:
        """从响应中提取文本

        Args:
            payload_msg: 响应的 payload 字典

        Returns:
            提取的文本内容，如果没有则返回空字符串
        """
        result = payload_msg.get("result") or payload_msg.get("results")
        if isinstance(result, dict):
            return result.get("text", "")
        if isinstance(result, list) and result:
            return result[0].get("text", "") if isinstance(result[0], dict) else ""
        return payload_msg.get("text", "")

    def _extract_duration(
        self, payload_msg: Optional[dict[str, Any]]
    ) -> Optional[float]:
        """提取时长(秒)

        Args:
            payload_msg: 响应的 payload 字典

        Returns:
            时长(秒)，如果无法提取则返回 None
        """
        if not payload_msg:
            return None
        additions = payload_msg.get("additions") or {}
        duration_ms = additions.get("duration")
        if duration_ms:
            try:
                return float(duration_ms) / 1000.0
            except (ValueError, TypeError):
                self.logger.warning(f"无法解析时长: {duration_ms}")
        return None

    def _calculate_segment_size(
        self, audio_data: bytes, audio_format: AudioFormat
    ) -> int:
        """计算音频分段大小

        Args:
            audio_data: 音频数据
            audio_format: 音频格式

        Returns:
            分段大小(字节)
        """
        if audio_format == AudioFormat.WAV:
            try:
                nchannels, sampwidth, framerate, _, _ = self._read_wav_info(audio_data)
                size_per_sec = nchannels * sampwidth * framerate
                return int(size_per_sec * self.seg_duration / 1000)
            except Exception as e:
                self.logger.warning(
                    f"解析WAV失败: {e}, 使用默认分段大小 {DEFAULT_SEGMENT_SIZE}"
                )
                return DEFAULT_SEGMENT_SIZE
        return DEFAULT_SEGMENT_SIZE

    @staticmethod
    def _read_wav_info(data: bytes) -> tuple[int, int, int, int, int]:
        """读取WAV文件信息

        Args:
            data: WAV 文件的字节数据

        Returns:
            (nchannels, sampwidth, framerate, nframes, wave_bytes_len) 元组
        """
        with BytesIO(data) as _f:
            with wave.open(_f, "rb") as wave_fp:
                nchannels = wave_fp.getnchannels()
                sampwidth = wave_fp.getsampwidth()
                framerate = wave_fp.getframerate()
                nframes = wave_fp.getnframes()
                wave_bytes = wave_fp.readframes(nframes)
        return nchannels, sampwidth, framerate, nframes, len(wave_bytes)

    @staticmethod
    def _slice_data(data: bytes, chunk_size: int) -> Iterator[tuple[bytes, bool]]:
        """将数据分片

        Args:
            data: 要分片的数据
            chunk_size: 每片的大小

        Yields:
            (chunk, is_last) 元组，chunk 为数据片段，is_last 表示是否为最后一片
        """
        data_len = len(data)
        offset = 0
        while offset + chunk_size < data_len:
            yield data[offset : offset + chunk_size], False
            offset += chunk_size
        yield data[offset:data_len], True
