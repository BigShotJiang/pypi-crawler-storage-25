"""
火山引擎 ASR 提供商实现
使用流式语音识别 WebSocket V2 协议
文档: https://www.volcengine.com/docs/6561/80816?lang=zh
"""

import asyncio
import concurrent.futures
import gzip
from io import BytesIO
import json
import threading
import time
from typing import Any, AsyncIterator, Optional
import uuid
import wave

try:
    import aiohttp

    AIOHTTP_AVAILABLE = True
except ImportError:
    AIOHTTP_AVAILABLE = False
    aiohttp = None

try:
    import websockets

    WEBSOCKETS_AVAILABLE = True
except ImportError:
    WEBSOCKETS_AVAILABLE = False
    websockets = None

from soulshell_base.core import get_logger

from ..base import BaseASR
from ..exceptions import (
    ASRAuthenticationError,
    ASRException,
    ASRRecognitionError,
)
from ..models import ASRRecognizeRequest, ASRResponse, ASRResult, AudioFormat

logger = get_logger(__name__)

# ========== WebSocket V2 协议常量 ==========

PROTOCOL_VERSION = 0b0001
DEFAULT_HEADER_SIZE = 0b0001

# 消息类型
CLIENT_FULL_REQUEST = 0b0001
CLIENT_AUDIO_ONLY_REQUEST = 0b0010
SERVER_FULL_RESPONSE = 0b1001
SERVER_ACK = 0b1011
SERVER_ERROR_RESPONSE = 0b1111

# 消息类型特定标志
NO_SEQUENCE = 0b0000
POS_SEQUENCE = 0b0001
NEG_SEQUENCE = 0b0010
NEG_SEQUENCE_1 = 0b0011

# 消息序列化方法
NO_SERIALIZATION = 0b0000
JSON = 0b0001
THRIFT = 0b0011

# 消息压缩方法
NO_COMPRESSION = 0b0000
GZIP = 0b0001


class VolcengineASRProvider(BaseASR):
    """火山引擎 ASR 提供商"""

    def __init__(
        self,
        token: str,
        appid: str,
        cluster: str = "volcengine_streaming_common",
        url_cluster: str = "volc_auc_common_flash",
        ws_url: str = "wss://openspeech.bytedance.com/api/v2/asr",
        **kwargs,
    ):
        """初始化火山引擎 ASR 提供商

        Args:
            token: 访问令牌 (token)
            appid: 应用 ID
            cluster: 集群标识
            url_cluster: 通过 TOS 的 URL 极速版集群标识
            ws_url: WebSocket URL
            **kwargs: 其他配置参数
        """
        super().__init__(**kwargs)

        if not WEBSOCKETS_AVAILABLE:
            raise ImportError(
                "需要安装 websockets 库才能使用火山引擎 ASR。"
                "请运行: pip install websockets"
            )

        self.appid = appid
        self.cluster = cluster
        self.url_cluster = url_cluster
        self.ws_url = ws_url
        self.auc_url = "https://openspeech.bytedance.com/api/v1/auc"  # 极速版 API
        self.token = token

        # 配置参数
        self.success_code = 1000
        self.seg_duration = int(kwargs.get("seg_duration", 15000))  # 分段时长（毫秒）
        self.nbest = int(kwargs.get("nbest", 1))
        self.uid = kwargs.get("uid", "streaming_asr_demo")
        self.workflow = kwargs.get(
            "workflow", "audio_in,resample,partition,vad,fe,decode,itn,nlu_punctuate"
        )
        self.mp3_seg_size = int(kwargs.get("mp3_seg_size", 10000))

        # ============ 流式（推送式 start/feed/stop）状态 ============
        self._stream_loop: Optional[asyncio.AbstractEventLoop] = None
        self._stream_thread: Optional[threading.Thread] = None
        self._stream_audio_queue: Optional[asyncio.Queue[Optional[bytes]]] = None
        self._stream_connected = threading.Event()
        self._stream_main_future: Optional[concurrent.futures.Future] = None

        self._last_partial_text: str = ""
        self._stream_connect_timeout = float(kwargs.get("stream_connect_timeout", 10))
        self._stream_stop_timeout = float(kwargs.get("stream_stop_timeout", 10))

        self.logger.info(
            f"初始化火山引擎 ASR: cluster={self.cluster}, appid={self.appid}"
        )

    def get_provider_name(self) -> str:
        """获取提供商名称"""
        return "volcengine"

    @classmethod
    def describe(cls) -> dict[str, Any]:
        """获取提供商描述信息"""
        return {
            "provider_name": "volcengine",
            "display_name": "火山引擎 ASR",
            "description": "火山引擎语音识别服务（支持流式识别和极速版识别）",
            "required_init_params": {
                "token": {
                    "type": "str",
                    "description": "火山引擎访问令牌",
                    "env_var": "ASR_VOLCENGINE_TOKEN",
                },
                "appid": {
                    "type": "str",
                    "description": "火山引擎应用 ID",
                    "env_var": "ASR_VOLCENGINE_APPID",
                },
                "cluster": {
                    "type": "str",
                    "description": "集群标识（如 volcengine_streaming_common）",
                    "env_var": "ASR_VOLCENGINE_CLUSTER",
                },
            },
            "optional_init_params": {
                "url_cluster": {
                    "type": "str",
                    "description": "极速版集群标识",
                    "default": "volc_auc_common_flash",
                },
                "ws_url": {
                    "type": "str",
                    "description": "WebSocket 服务地址",
                    "default": "wss://openspeech.bytedance.com/api/v2/asr",
                },
            },
            "supported_methods": [
                "recognize: 流式识别（音频字节流）",
                "recognize_by_url: 极速版识别（音频 URL）",
                "recognize_file: 便捷方法（本地文件识别）",
            ],
            "example": """asr = ASRFactory.create(
    provider_name="volcengine",
    token="your_access_token",
    appid="your_appid",
    cluster="volcengine_streaming_common"
)""",
        }

    def validate_config(self) -> bool:
        """验证配置"""
        if not self.token:
            self.logger.error("缺少 token")
            return False
        if not self.appid:
            self.logger.error("缺少 appid")
            return False
        return True

    def validate_request(self, request: ASRRecognizeRequest) -> None:
        """请求参数校验"""
        # 复用基类的基础校验
        super().validate_request(request)
        # 额外校验：编码与格式基本可用
        if not hasattr(request.audio_format, "value"):
            raise ASRRecognitionError("音频格式无效")
        if not hasattr(request.codec, "value"):
            raise ASRRecognitionError("音频编解码标识无效")

    async def recognize(self, request: ASRRecognizeRequest) -> ASRResponse:
        """
        异步识别音频

        Args:
            request: ASR 识别请求

        Returns:
            ASRResponse: 识别响应
        """
        try:
            # 验证请求
            self.validate_request(request)

            # 执行识别
            return await self._recognize_streaming(request)

        except Exception as e:
            self.logger.error(f"火山引擎 ASR 识别失败: {e}")
            return ASRResponse.failed(error_message=f"火山引擎 ASR 识别失败: {e!s}")

    async def _recognize_streaming(self, request: ASRRecognizeRequest) -> ASRResponse:
        """
        使用流式 WebSocket 协议识别音频

        Args:
            request: ASR 识别请求

        Returns:
            ASRResponse: 识别响应
        """
        reqid = str(uuid.uuid4())

        # 构建请求参数
        request_params = self._construct_request(reqid=reqid, request=request)

        # 序列化并压缩
        payload_bytes = str.encode(json.dumps(request_params))
        payload_bytes = gzip.compress(payload_bytes)

        # 构建完整客户端请求
        full_client_request = bytearray(
            self._generate_header(
                message_type=CLIENT_FULL_REQUEST,
                message_type_specific_flags=NO_SEQUENCE,
                serial_method=JSON,
                compression_type=GZIP,
            )
        )
        full_client_request.extend((len(payload_bytes)).to_bytes(4, "big"))
        full_client_request.extend(payload_bytes)

        # 准备鉴权头
        auth_header = {"Authorization": f"Bearer; {self.token}"}

        # 计算分段大小
        segment_size = self._calculate_segment_size(
            request.audio_data, request.audio_format
        )

        try:
            async with websockets.connect(
                self.ws_url, additional_headers=auth_header, max_size=1000000000
            ) as ws:
                # 发送完整请求
                await ws.send(full_client_request)
                # 读取初始响应（鉴权/参数校验结果）
                initial = await ws.recv()
                result = self._parse_response(initial)

                # 检查初始响应
                payload_msg = result.get("payload_msg") or {}
                code = (
                    payload_msg.get("code") if isinstance(payload_msg, dict) else None
                )
                if code is not None and code != self.success_code:
                    raise ASRAuthenticationError(f"初始请求失败: {result}")

                self.logger.info("WebSocket 连接建立成功，开始发送音频数据")

                # 分段发送音频数据
                last_payload: dict[str, Any] | None = None
                for seq, (chunk, last) in enumerate(
                    self._slice_data(request.audio_data, segment_size), 1
                ):
                    # 压缩音频块
                    payload_bytes = gzip.compress(chunk)

                    # 构建音频请求
                    if last:
                        audio_header = self._generate_header(
                            message_type=CLIENT_AUDIO_ONLY_REQUEST,
                            message_type_specific_flags=NEG_SEQUENCE,
                            compression_type=GZIP,
                        )
                    else:
                        audio_header = self._generate_header(
                            message_type=CLIENT_AUDIO_ONLY_REQUEST,
                            compression_type=GZIP,
                        )

                    audio_only_request = bytearray(audio_header)
                    audio_only_request.extend((len(payload_bytes)).to_bytes(4, "big"))
                    audio_only_request.extend(payload_bytes)

                    # 发送音频数据
                    await ws.send(audio_only_request)
                    res = await ws.recv()
                    result = self._parse_response(res)

                    payload_msg = result.get("payload_msg")
                    if isinstance(payload_msg, dict):
                        code = payload_msg.get("code")
                        if code is not None and code != self.success_code:
                            raise ASRRecognitionError(f"识别失败: {result}")

                        # 如果返回了识别文本，则记录并尝试触发中间结果（避免重复）
                        text, _, _, is_final = self._extract_text(payload_msg, result)
                        if text:
                            last_payload = payload_msg
                            if text != self._last_partial_text and not is_final:
                                self._last_partial_text = text
                                self._emit_partial(
                                    ASRResponse.partial(
                                        text=text,
                                        duration=self._extract_duration(payload_msg),
                                        metadata={"raw_response": payload_msg},
                                    )
                                )

                    if seq % 10 == 0 or last:
                        self.logger.debug(f"已发送 {seq} 个音频分段，last={last}")

                # 最后一片发送完后，继续等待最终结果（服务端可能会额外推送最终 FullResponse）
                final_result = await self._recv_until_final(
                    ws,
                    last_payload=last_payload,
                    timeout=self._stream_stop_timeout,
                )
                self._last_partial_text = ""
                return final_result

        except websockets.exceptions.WebSocketException as e:
            self.logger.error(f"WebSocket 连接错误: {e}")
            raise ASRException(f"WebSocket 连接错误: {e!s}")
        except Exception as e:
            self.logger.error(f"识别过程出错: {e}")
            raise

    async def recognize_stream(
        self,
        request: ASRRecognizeRequest,
    ) -> AsyncIterator[ASRResponse]:
        """流式语音识别（异步生成器）

        适用于“麦克风实时识别”等场景，通过 `request.audio_stream` 持续推送音频数据。

        约定：
        - `request.audio_stream` 为异步生成器，逐块产出音频字节（通常为 PCM）。
        - 若需要中间结果，建议设置 `request.enable_intermediate_result=True` 或显式设置 `request.result_type`。
        """
        # 验证请求参数
        self.validate_request(request)

        if not hasattr(request, "audio_stream") or request.audio_stream is None:
            yield ASRResponse.failed(error_message="流式识别需要提供 audio_stream 参数")
            return

        reqid = str(uuid.uuid4())
        request_params = self._construct_request(reqid=reqid, request=request)
        full_req_bytes = self._build_full_request_bytes(request_params)
        auth_header = {"Authorization": f"Bearer; {self.token}"}

        queue: asyncio.Queue[ASRResponse] = asyncio.Queue()
        done = asyncio.Event()
        last_partial_text = ""

        async def receiver(ws) -> None:
            nonlocal last_partial_text
            try:
                while True:
                    res = await ws.recv()
                    parsed = self._parse_response(res)

                    # 服务器错误帧
                    if parsed.get("message_type") == SERVER_ERROR_RESPONSE:
                        code = parsed.get("code")
                        raise ASRRecognitionError(
                            f"服务器错误响应(code={code}): {parsed}"
                        )

                    payload_msg = parsed.get("payload_msg")
                    if not isinstance(payload_msg, dict):
                        continue

                    code = payload_msg.get("code")
                    if code is not None and code != self.success_code:
                        raise ASRRecognitionError(f"识别失败: {payload_msg}")

                    text, results, duration, is_final = self._extract_text(
                        payload_msg, parsed
                    )

                    if is_final:
                        # 最终结果：无论文本是否与上次相同，都放入队列
                        resp = ASRResponse.success(
                            text=text,
                            results=results,
                            duration=duration,
                            metadata={"raw_response": payload_msg},
                        )
                        await queue.put(resp)
                        done.set()
                        return
                    if text and text != last_partial_text:
                        # 中间结果：只有文本变化时才放入队列
                        last_partial_text = text
                        resp = ASRResponse.partial(
                            text=text,
                            results=results,
                            duration=duration,
                            metadata={"raw_response": payload_msg},
                        )
                        await queue.put(resp)

            except websockets.exceptions.ConnectionClosed:
                # 若服务端先关闭连接：尽量输出最后一次中间结果作为最终结果
                if last_partial_text:
                    await queue.put(ASRResponse.success(text=last_partial_text))
                done.set()
            except Exception as e:
                await queue.put(
                    ASRResponse.failed(error_message=f"流式识别失败: {e!s}")
                )
                done.set()

        async def sender(ws) -> None:
            try:
                async for chunk in request.audio_stream:
                    if not chunk:
                        continue
                    await ws.send(
                        self._build_audio_request_bytes(chunk=chunk, last=False)
                    )
                # 发送结束帧
                await ws.send(self._build_audio_request_bytes(chunk=b"", last=True))
            except Exception as e:
                await queue.put(
                    ASRResponse.failed(error_message=f"发送音频流失败: {e!s}")
                )
                done.set()

        try:
            async with websockets.connect(
                self.ws_url, additional_headers=auth_header, max_size=1000000000
            ) as ws:
                await ws.send(full_req_bytes)
                # 读取初始响应（鉴权/参数校验结果），确保会话可用后再开始推流
                initial = await ws.recv()
                parsed = self._parse_response(initial)
                payload_msg = parsed.get("payload_msg") or {}
                if isinstance(payload_msg, dict):
                    code = payload_msg.get("code")
                    if code is not None and code != self.success_code:
                        yield ASRResponse.failed(
                            error_message=f"初始请求失败: {payload_msg}"
                        )
                        return

                self._emit_start()

                recv_task = asyncio.create_task(receiver(ws))
                send_task = asyncio.create_task(sender(ws))

                try:
                    while not done.is_set() or not queue.empty():
                        try:
                            resp = await asyncio.wait_for(queue.get(), timeout=0.2)
                            if resp.is_failed:
                                self._emit_error(
                                    ASRRecognitionError(
                                        resp.error_message or "流式识别失败"
                                    )
                                )
                            elif resp.status == "partial":
                                self._emit_partial(resp)
                            elif resp.is_success:
                                self._emit_final(resp)
                            yield resp
                            if resp.is_success:
                                done.set()
                        except TimeoutError:
                            continue
                finally:
                    for task in (recv_task, send_task):
                        if not task.done():
                            task.cancel()

        except Exception as e:
            yield ASRResponse.failed(error_message=f"流式识别失败: {e!s}")

    # ============ 推送式流式接口实现（start/feed/stop） ============

    def start_stream(self, request: ASRRecognizeRequest) -> None:
        """启动推送式流式识别会话（配合 `feed_audio_chunk` 使用）"""
        if self._stream_started:
            self.logger.warning("流式识别已在运行中")
            return

        # 允许调用方不显式设置 streaming_mode
        if not request.streaming_mode:
            request.streaming_mode = True

        self.validate_request(request)

        self._last_partial_text = ""
        self._stream_connected.clear()

        loop = asyncio.new_event_loop()
        self._stream_loop = loop

        def _thread_main() -> None:
            asyncio.set_event_loop(loop)
            try:
                # 必须在目标 event loop 线程中创建 asyncio.Queue，避免跨 loop 绑定问题
                self._stream_audio_queue = asyncio.Queue()

                self._stream_main_future = concurrent.futures.Future()
                try:
                    loop.run_until_complete(self._run_push_streaming_session(request))
                    if not self._stream_main_future.done():
                        self._stream_main_future.set_result(True)
                except Exception as e:
                    if not self._stream_main_future.done():
                        self._stream_main_future.set_exception(e)
                    self._emit_error(e)
            finally:
                loop.close()

        t = threading.Thread(
            target=_thread_main, name="volcengine-asr-stream", daemon=True
        )
        self._stream_thread = t
        t.start()

        if not self._stream_connected.wait(timeout=self._stream_connect_timeout):
            self.stop_stream()
            raise ASRRecognitionError("启动流式识别超时，未能建立 WebSocket 连接")

        self._stream_started = True
        self._emit_start()

    def feed_audio_chunk(self, pcm_chunk: bytes) -> None:
        """推送音频数据块（通常为 PCM）"""
        if (
            not self._stream_started
            or not self._stream_loop
            or not self._stream_audio_queue
        ):
            raise ASRRecognitionError("流式识别会话未启动")
        if not pcm_chunk:
            return

        asyncio.run_coroutine_threadsafe(
            self._stream_audio_queue.put(pcm_chunk),
            self._stream_loop,
        )

    def stop_stream(self) -> None:
        """停止推送式流式识别会话"""
        # 允许在“尚未完全启动”场景下清理线程/loop（例如启动超时）
        if not self._stream_started:
            if self._stream_thread and self._stream_thread.is_alive():
                self._stream_thread.join(timeout=self._stream_stop_timeout)
            self._stream_loop = None
            self._stream_thread = None
            self._stream_audio_queue = None
            self._stream_main_future = None
            self._last_partial_text = ""
            return

        loop = self._stream_loop
        queue = self._stream_audio_queue

        if loop and queue:
            asyncio.run_coroutine_threadsafe(queue.put(None), loop)

        # 等待会话收尾（尽量拿到最终结果并触发回调）
        if self._stream_main_future:
            try:
                self._stream_main_future.result(timeout=self._stream_stop_timeout)
            except Exception as e:
                self.logger.warning(f"等待流式会话结束失败: {e}")
                if loop:
                    try:
                        loop.call_soon_threadsafe(loop.stop)
                    except Exception:
                        pass

        if self._stream_thread and self._stream_thread.is_alive():
            self._stream_thread.join(timeout=self._stream_stop_timeout)

        self._stream_started = False
        self._stream_loop = None
        self._stream_thread = None
        self._stream_audio_queue = None
        self._stream_main_future = None
        self._last_partial_text = ""

    def _construct_request(self, reqid: str, request: ASRRecognizeRequest) -> dict:
        """构建请求参数"""
        result_type = request.result_type
        # 与阿里侧保持一致：显式开启中间结果时，尽量请求服务端返回中间识别结果
        if request.enable_intermediate_result and result_type == "full":
            result_type = "partial"

        return {
            "app": {
                "appid": self.appid,
                "cluster": self.cluster,
                "token": self.token,
            },
            "user": {"uid": self.uid},
            "request": {
                "reqid": reqid,
                "nbest": self.nbest,
                "workflow": self.workflow,
                "show_language": request.show_language,
                "show_utterances": request.show_utterances,
                "result_type": result_type,
                "sequence": 1,
            },
            "audio": {
                "format": request.audio_format.value,
                "rate": request.sample_rate,
                "language": request.language,
                "bits": request.bits,
                "channel": request.channel,
                "codec": request.codec.value,
            },
        }

    def _generate_header(
        self,
        version=PROTOCOL_VERSION,
        message_type=CLIENT_FULL_REQUEST,
        message_type_specific_flags=NO_SEQUENCE,
        serial_method=JSON,
        compression_type=GZIP,
        reserved_data=0x00,
        extension_header=b"",
    ) -> bytes:
        """
        生成协议头部

        协议格式:
        - protocol_version (4 bits)
        - header_size (4 bits)
        - message_type (4 bits)
        - message_type_specific_flags (4 bits)
        - serialization_method (4 bits)
        - message_compression (4 bits)
        - reserved (8 bits)
        - header_extensions (可选)
        """
        header = bytearray()
        header_size = int(len(extension_header) / 4) + 1
        header.append((version << 4) | header_size)
        header.append((message_type << 4) | message_type_specific_flags)
        header.append((serial_method << 4) | compression_type)
        header.append(reserved_data)
        header.extend(extension_header)
        return bytes(header)

    def _parse_response(self, res: bytes) -> dict:
        """
        解析服务器响应

        Args:
            res: 响应字节流

        Returns:
            dict: 解析后的响应字典
        """
        # header_size = res[0] & 0x0F
        # message_type = res[1] >> 4
        # serialization_method = res[2] >> 4
        # message_compression = res[2] & 0x0F

        # 解析头部与 payload
        header_size = res[0] & 0x0F
        message_type = res[1] >> 4
        message_type_specific_flags = res[1] & 0x0F
        serialization_method = res[2] >> 4
        message_compression = res[2] & 0x0F

        payload = res[header_size * 4 :]
        result = {}
        payload_msg = None
        payload_size = 0
        result["message_type"] = message_type
        result["message_type_specific_flags"] = message_type_specific_flags

        if message_type == SERVER_FULL_RESPONSE:
            payload_size = int.from_bytes(payload[:4], "big", signed=True)
            payload_msg = payload[4:]
        elif message_type == SERVER_ACK:
            seq = int.from_bytes(payload[:4], "big", signed=True)
            result["seq"] = seq
            if len(payload) >= 8:
                payload_size = int.from_bytes(payload[4:8], "big", signed=False)
                payload_msg = payload[8:]
        elif message_type == SERVER_ERROR_RESPONSE:
            code = int.from_bytes(payload[:4], "big", signed=False)
            result["code"] = code
            payload_size = int.from_bytes(payload[4:8], "big", signed=False)
            payload_msg = payload[8:]

        if payload_msg is None:
            return result

        # 解压缩
        if message_compression == GZIP:
            try:
                payload_msg = gzip.decompress(payload_msg)
            except Exception:
                # 某些情况下服务端可能没有压缩 payload（或返回 ACK 无 payload）
                pass

        # 反序列化
        if serialization_method == JSON:
            payload_msg = json.loads(str(payload_msg, "utf-8"))
        elif serialization_method != NO_SERIALIZATION:
            payload_msg = str(payload_msg, "utf-8")

        result["payload_msg"] = payload_msg
        result["payload_size"] = payload_size
        return result

    def _build_full_request_bytes(self, request_params: dict) -> bytes:
        """构建 FullRequest 二进制帧"""
        payload_bytes = gzip.compress(str.encode(json.dumps(request_params)))
        full_client_request = bytearray(
            self._generate_header(
                message_type=CLIENT_FULL_REQUEST,
                message_type_specific_flags=NO_SEQUENCE,
                serial_method=JSON,
                compression_type=GZIP,
            )
        )
        full_client_request.extend((len(payload_bytes)).to_bytes(4, "big"))
        full_client_request.extend(payload_bytes)
        return bytes(full_client_request)

    def _build_audio_request_bytes(self, chunk: bytes, last: bool) -> bytes:
        """构建 AudioOnlyRequest 二进制帧"""
        payload_bytes = gzip.compress(chunk or b"")
        audio_header = self._generate_header(
            message_type=CLIENT_AUDIO_ONLY_REQUEST,
            message_type_specific_flags=NEG_SEQUENCE if last else NO_SEQUENCE,
            compression_type=GZIP,
        )
        audio_only_request = bytearray(audio_header)
        audio_only_request.extend((len(payload_bytes)).to_bytes(4, "big"))
        audio_only_request.extend(payload_bytes)
        return bytes(audio_only_request)

    def _is_final_payload(self, payload_msg: dict, parsed: dict) -> bool:
        """尽量从 payload/flags 推断是否为最终结果（协议字段存在差异，做兼容判断）"""
        flags = parsed.get("message_type_specific_flags")
        if flags in (NEG_SEQUENCE, NEG_SEQUENCE_1):
            return True

        for key in ("is_final", "final", "end", "is_end", "speech_end", "sentence_end"):
            if payload_msg.get(key) is True:
                return True

        sequence = payload_msg.get("sequence")
        if isinstance(sequence, int) and sequence < 0:
            return True

        # 有些返回会在 additions/ addition 中携带结束标记
        additions = payload_msg.get("additions") or payload_msg.get("addition") or {}
        if isinstance(additions, dict):
            if additions.get("is_final") is True or additions.get("final") is True:
                return True

        return False

    def _extract_duration(self, payload_msg: dict) -> Optional[float]:
        """提取时长（秒）"""
        additions = payload_msg.get("addition") or payload_msg.get("additions") or {}
        if isinstance(additions, dict):
            duration_ms = additions.get("duration")
            if duration_ms is not None:
                try:
                    return float(duration_ms) / 1000.0
                except Exception:
                    return None
        return None

    def _extract_text(
        self, payload_msg: dict, parsed: dict
    ) -> tuple[str, list[ASRResult] | None, Optional[float], bool]:
        """从 payload 中尽量抽取文本/候选/时长，并推断是否最终结果"""
        duration = self._extract_duration(payload_msg)
        results: list[ASRResult] = []

        text = ""
        raw_results = payload_msg.get("result") or payload_msg.get("results")
        if isinstance(raw_results, list):
            for item in raw_results:
                if not isinstance(item, dict):
                    continue
                item_text = item.get("text") or ""
                if not text and item_text:
                    text = item_text
                results.append(
                    ASRResult(
                        text=item_text,
                        confidence=item.get("confidence"),
                    )
                )
        elif isinstance(raw_results, dict):
            text = raw_results.get("text") or ""

        if not text:
            text = payload_msg.get("text") or ""

        is_final = self._is_final_payload(payload_msg, parsed)
        return text, (results or None), duration, is_final

    async def _recv_until_final(
        self,
        ws,
        last_payload: dict[str, Any] | None,
        timeout: float,
    ) -> ASRResponse:
        """持续接收直到拿到最终结果；若超时则回退到最后一次 payload"""
        deadline = time.time() + timeout
        last_text = ""
        last_results: list[ASRResult] | None = None
        last_duration: Optional[float] = None

        if last_payload:
            try:
                last_text, last_results, last_duration, _ = self._extract_text(
                    last_payload, {}
                )
            except Exception:
                pass

        while time.time() < deadline:
            try:
                res = await asyncio.wait_for(ws.recv(), timeout=0.5)
            except TimeoutError:
                continue

            parsed = self._parse_response(res)
            payload_msg = parsed.get("payload_msg")
            if not isinstance(payload_msg, dict):
                continue

            code = payload_msg.get("code")
            if code is not None and code != self.success_code:
                return ASRResponse.failed(error_message=f"识别失败: {payload_msg}")

            text, results, duration, is_final = self._extract_text(payload_msg, parsed)
            if text:
                last_text, last_results, last_duration = text, results, duration
            if is_final and text is not None:
                return ASRResponse.success(
                    text=text or "",
                    results=results,
                    duration=duration,
                    metadata={"raw_response": payload_msg},
                )

        # 超时回退
        if last_text or last_payload is not None:
            return ASRResponse.success(
                text=last_text or "",
                results=last_results,
                duration=last_duration,
                metadata={"raw_response": last_payload} if last_payload else None,
            )

        return ASRResponse.failed(error_message="等待最终识别结果超时")

    async def _run_push_streaming_session(self, request: ASRRecognizeRequest) -> None:
        """推送式会话主协程：建立连接、消费音频队列、接收并触发回调"""
        assert self._stream_audio_queue is not None
        auth_header = {"Authorization": f"Bearer; {self.token}"}
        reqid = str(uuid.uuid4())
        request_params = self._construct_request(reqid=reqid, request=request)
        full_req_bytes = self._build_full_request_bytes(request_params)

        async with websockets.connect(
            self.ws_url, additional_headers=auth_header, max_size=1000000000
        ) as ws:
            await ws.send(full_req_bytes)

            # 初始响应
            try:
                initial = await ws.recv()
                parsed = self._parse_response(initial)
                payload_msg = parsed.get("payload_msg") or {}
                if isinstance(payload_msg, dict):
                    code = payload_msg.get("code")
                    if code is not None and code != self.success_code:
                        raise ASRAuthenticationError(f"初始请求失败: {payload_msg}")
            finally:
                self._stream_connected.set()

            async def receiver() -> None:
                while True:
                    res = await ws.recv()
                    parsed = self._parse_response(res)
                    payload_msg = parsed.get("payload_msg")
                    if not isinstance(payload_msg, dict):
                        continue
                    code = payload_msg.get("code")
                    if code is not None and code != self.success_code:
                        self._emit_error(
                            ASRRecognitionError(f"识别失败: {payload_msg}")
                        )
                        return

                    text, results, duration, is_final = self._extract_text(
                        payload_msg, parsed
                    )

                    if is_final:
                        # 最终结果：无论文本是否与上次相同，都触发 _emit_final
                        resp = ASRResponse.success(
                            text=text,
                            results=results,
                            duration=duration,
                            metadata={"raw_response": payload_msg},
                        )
                        self._emit_final(resp)
                        self._last_partial_text = ""
                        return
                    if text and text != self._last_partial_text:
                        # 中间结果：只有文本变化时才触发 _emit_partial
                        self._last_partial_text = text
                        resp = ASRResponse.partial(
                            text=text,
                            results=results,
                            duration=duration,
                            metadata={"raw_response": payload_msg},
                        )
                        self._emit_partial(resp)

            async def sender() -> None:
                while True:
                    chunk = await self._stream_audio_queue.get()
                    if chunk is None:
                        await ws.send(
                            self._build_audio_request_bytes(chunk=b"", last=True)
                        )
                        return
                    await ws.send(
                        self._build_audio_request_bytes(chunk=chunk, last=False)
                    )

            recv_task = asyncio.create_task(receiver())
            send_task = asyncio.create_task(sender())
            try:
                done, _pending = await asyncio.wait(
                    {recv_task, send_task}, return_when=asyncio.FIRST_COMPLETED
                )

                # 先完成的是接收端：说明已拿到最终结果或出错，取消发送端并退出
                if recv_task in done:
                    if not send_task.done():
                        send_task.cancel()
                    return

                # 先完成的是发送端：等待接收端拿到最终结果（否则回退到最后一次中间结果）
                try:
                    await asyncio.wait_for(recv_task, timeout=self._stream_stop_timeout)
                except TimeoutError:
                    if self._last_partial_text:
                        self._emit_final(
                            ASRResponse.success(text=self._last_partial_text)
                        )
            finally:
                for task in (recv_task, send_task):
                    if not task.done():
                        task.cancel()
                self._emit_close()

    def _calculate_segment_size(
        self, audio_data: bytes, audio_format: AudioFormat
    ) -> int:
        """计算音频分段大小"""
        if audio_format == AudioFormat.MP3:
            return self.mp3_seg_size
        if audio_format == AudioFormat.WAV:
            try:
                nchannels, sampwidth, framerate, _, _ = self._read_wav_info(audio_data)
                size_per_sec = nchannels * sampwidth * framerate
                return int(size_per_sec * self.seg_duration / 1000)
            except Exception as e:
                self.logger.warning(f"解析 WAV 信息失败: {e}，使用默认分段大小")
                return 32000  # 默认 2 秒的 16kHz 16bit 单声道音频
        else:
            # 其他格式使用默认值
            return 32000

    @staticmethod
    def _read_wav_info(data: bytes) -> tuple:
        """读取 WAV 文件信息"""
        with BytesIO(data) as _f:
            with wave.open(_f, "rb") as wave_fp:
                nchannels, sampwidth, framerate, nframes = wave_fp.getparams()[:4]
                wave_bytes = wave_fp.readframes(nframes)
        return nchannels, sampwidth, framerate, nframes, len(wave_bytes)

    @staticmethod
    def _slice_data(data: bytes, chunk_size: int):
        """
        将数据分片

        Args:
            data: 音频数据
            chunk_size: 分片大小

        Yields:
            tuple: (分片数据, 是否最后一片)
        """
        data_len = len(data)
        offset = 0
        while offset + chunk_size < data_len:
            yield data[offset : offset + chunk_size], False
            offset += chunk_size
        yield data[offset:data_len], True

    def _extract_result(self, result: dict) -> ASRResponse:
        """
        从响应中提取识别结果

        Args:
            result: 解析后的响应字典

        Returns:
            ASRResponse: 识别响应
        """
        try:
            payload_msg = result.get("payload_msg", {})

            # 提取文本结果
            text = payload_msg.get("result", [{}])[0].get("text", "")

            # 提取时长
            duration = payload_msg.get("addition", {}).get("duration")
            if duration:
                duration = float(duration) / 1000.0  # 转换为秒

            # 提取详细结果
            results = []
            for item in payload_msg.get("result", []):
                asr_result = ASRResult(
                    text=item.get("text", ""), confidence=item.get("confidence")
                )
                results.append(asr_result)

            return ASRResponse.success(
                text=text,
                results=results,
                duration=duration,
                metadata={"raw_response": payload_msg},
            )

        except Exception as e:
            self.logger.error(f"解析识别结果失败: {e}, result={result}")
            return ASRResponse.failed(error_message=f"解析识别结果失败: {e!s}")

    async def recognize_by_url(
        self,
        audio_url: str,
        audio_format: str | None = None,
        poll_interval: int = 2,
        timeout: int = 300,
        with_speaker_info: bool = False,
    ) -> ASRResponse:
        """
        通过音频 URL 进行极速识别 (录音文件识别极速版)

        Args:
            audio_url: 音频文件的 URL
            audio_format: 音频格式,如果为 None 则从 URL 自动推断
            poll_interval: 查询间隔 (秒)
            timeout: 最大等待时间 (秒)
            with_speaker_info: 是否包含说话人信息

        Returns:
            ASRResponse: 识别响应
        """
        if not AIOHTTP_AVAILABLE:
            return ASRResponse.failed(
                error_message="需要安装 aiohttp 库才能使用极速版识别。请运行: pip install aiohttp"
            )

        # 如果未指定格式，从 URL 中推断
        if audio_format is None:
            audio_format = audio_url.split("?")[0].split(".")[-1]

        try:
            async with aiohttp.ClientSession() as session:
                # 提交任务
                task_id = await self._submit_task(
                    session, audio_url, audio_format, with_speaker_info
                )
                if not task_id:
                    return ASRResponse.failed(error_message="提交识别任务失败")

                self.logger.info(f"极速版识别任务已提交，任务ID: {task_id}")

                # 轮询查询结果
                start_time = time.time()
                while True:
                    # 检查超时
                    if time.time() - start_time > timeout:
                        return ASRResponse.failed(
                            error_message=f"识别超时 (>{timeout}秒)"
                        )

                    # 等待一段时间再查询
                    await asyncio.sleep(poll_interval)

                    # 查询任务状态
                    resp_dic = await self._query_task(session, task_id)
                    if not resp_dic or "resp" not in resp_dic:
                        self.logger.warning("无效的响应，继续重试...")
                        continue

                    resp_code = resp_dic["resp"].get("code")

                    # 任务完成
                    if resp_code == self.success_code:
                        result_text = resp_dic.get("resp", {}).get("text", "")
                        duration_ms = (
                            resp_dic.get("resp", {})
                            .get("additions", {})
                            .get("duration", "0")
                        )
                        duration = float(duration_ms) / 1000.0

                        elapsed_time = time.time() - start_time
                        self.logger.info(
                            f"识别成功，耗时：{elapsed_time:.2f}秒，音频时长：{duration:.2f}秒"
                        )

                        return ASRResponse.success(
                            text=result_text,
                            duration=duration,
                            metadata={"raw_response": resp_dic, "task_id": task_id},
                        )

                    # 任务失败
                    if resp_code is not None and resp_code < 2000:
                        return ASRResponse.failed(
                            error_message=f"识别失败，响应码: {resp_code}, 响应: {resp_dic}"
                        )

                    # 任务仍在处理中，继续轮询
                    self.logger.debug(f"任务 {task_id} 仍在处理中...")

        except Exception as e:
            self.logger.error(f"极速版识别失败: {e}")
            return ASRResponse.failed(error_message=f"极速版识别失败: {e!s}")

    async def _submit_task(
        self,
        session: "aiohttp.ClientSession",
        audio_url: str,
        audio_format: str,
        with_speaker_info: bool,
    ) -> str | None:
        """
        提交识别任务

        Args:
            session: aiohttp 客户端会话
            audio_url: 音频文件 URL
            audio_format: 音频格式
            with_speaker_info: 是否包含说话人信息

        Returns:
            str | None: 任务 ID，失败返回 None
        """
        request_body = {
            "app": {
                "appid": self.appid,
                "token": self.token,
                "cluster": self.url_cluster,
            },
            "user": {"uid": self.uid},
            "audio": {"format": audio_format, "url": audio_url},
            "additions": {"with_speaker_info": str(with_speaker_info)},
        }

        try:
            async with session.post(
                f"{self.auc_url}/submit",
                data=json.dumps(request_body),
                headers={"Authorization": f"Bearer; {self.token}"},
                timeout=10,
            ) as response:
                response.raise_for_status()
                resp_dic = await response.json()

                task_id = resp_dic.get("resp", {}).get("id")
                if not task_id:
                    self.logger.error(f"提交任务失败，响应: {resp_dic}")
                    return None

                return task_id

        except aiohttp.ClientError as e:
            self.logger.error(f"提交任务时网络错误: {e}")
            return None
        except json.JSONDecodeError as e:
            self.logger.error(f"解码JSON响应失败: {e}")
            return None
        except Exception as e:
            self.logger.error(f"提交任务时发生错误: {e}")
            return None

    async def _query_task(
        self, session: "aiohttp.ClientSession", task_id: str
    ) -> dict | None:
        """
        查询任务状态

        Args:
            session: aiohttp 客户端会话
            task_id: 任务 ID

        Returns:
            dict | None: 响应字典，失败返回 None
        """
        query_payload = {
            "appid": self.appid,
            "token": self.token,
            "id": task_id,
            "cluster": self.url_cluster,
        }

        try:
            async with session.post(
                f"{self.auc_url}/query",
                data=json.dumps(query_payload),
                headers={"Authorization": f"Bearer; {self.token}"},
                timeout=10,
            ) as response:
                response.raise_for_status()
                return await response.json()

        except aiohttp.ClientError as e:
            self.logger.error(f"查询任务时网络错误: {e}")
            return None
        except json.JSONDecodeError as e:
            self.logger.error(f"解码JSON响应失败: {e}")
            return None
        except Exception as e:
            self.logger.error(f"查询任务时发生错误: {e}")
            return None
