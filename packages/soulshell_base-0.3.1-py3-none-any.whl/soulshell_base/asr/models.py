"""
ASR 数据模型
"""

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, AsyncGenerator, Callable, Dict, Optional

# ============ 回调类型定义 ============

# 简单回调（无参数）：用于 on_start, on_close
ASRSimpleCallback = Callable[[], None]

# 结果回调：用于 on_partial, on_final
ASRResultCallback = Callable[["ASRResponse"], None]

# 错误回调：用于 on_error
ASRErrorCallback = Callable[[Exception], None]


class ASRStatus(str, Enum):
    """ASR 状态"""

    SUCCESS = "success"
    FAILED = "failed"
    PARTIAL = "partial"


class AudioFormat(str, Enum):
    """音频编码格式"""

    MP3 = "mp3"
    WAV = "wav"
    PCM = "pcm"
    OGG = "ogg"
    OPUS = "opus"


class AudioCodec(str, Enum):
    """音频编解码标识（供 Provider 读取 value）"""

    RAW = "raw"
    PCM = "pcm"
    AAC = "aac"
    OPUS = "opus"


@dataclass
class ASRRecognizeRequest:
    """ASR 识别请求（供 Provider 使用）"""

    audio_data: bytes | str | Path = None
    audio_stream: AsyncGenerator[bytes, None] = None
    audio_format: AudioFormat = AudioFormat.WAV
    sample_rate: int = 16000
    language: str = "zh-CN"
    bits: int = 16
    channel: int = 1
    codec: AudioCodec = AudioCodec.RAW
    seg_duration: int = 15000
    # 供 provider 直接读取的字段（带默认值，避免属性缺失）
    show_language: bool = False
    show_utterances: bool = False
    result_type: str = "full"
    extra_params: Dict[str, Any] = field(default_factory=dict)

    # 阿里配置：
    # 是否启用中间结果返回
    enable_intermediate_result: bool = False

    # 自定义模型ID
    customization_id: str = ""
    # 自定义热词ID
    vocabulary_id: str = ""

    # 过滤语气词
    disfluency: bool = True
    # 是否启用语音检测
    enable_voice_detection: bool = False
    # 最大开始静音时间（毫秒）
    max_start_silence: int = 3000
    # 最大结束静音时间（毫秒）
    max_end_silence: int = 3000
    # 防止vad断句切割过长
    enable_multi_thresh_mode: bool = False
    # 中文数据转阿拉伯数字
    enable_inverse_text_normalization: bool = False
    # 是否启用标点预测
    enable_punctuation_prediction: bool = False

    # 流式模式标志：当为 True 时，允许 audio_data 和 audio_stream 都为空
    streaming_mode: bool = False

    def __post_init__(self):
        # 流式模式下跳过音频数据验证
        if not self.streaming_mode:
            # 验证 audio_data 和 audio_stream 有且仅有一个有数据
            self._validate_audio_inputs()

            # 验证 audio_data 文件是否存在（只有当 audio_data 不为 None 且不是 bytes 时才检查）
            if self.audio_data is not None and not isinstance(self.audio_data, bytes):
                try:
                    audio_path = Path(self.audio_data)
                    if not audio_path.exists():
                        raise ValueError(f"audio_data 文件不存在: {self.audio_data}")
                except (TypeError, ValueError):
                    # 如果无法转换为 Path，可能是无效的路径格式
                    raise ValueError(f"audio_data 路径格式无效: {self.audio_data}")

        if isinstance(self.sample_rate, str):
            self.sample_rate = int(self.sample_rate)

    def _validate_audio_inputs(self):
        """验证 audio_data 和 audio_stream 有且仅有一个有数据"""
        has_audio_data = self.audio_data is not None
        has_audio_stream = self.audio_stream is not None

        if not has_audio_data and not has_audio_stream:
            raise ValueError("audio_data 和 audio_stream 不能同时为空")

        if has_audio_data and has_audio_stream:
            raise ValueError(
                "audio_data 和 audio_stream 不能同时有数据，只能选择其中一种输入方式"
            )

        # 如果 audio_data 是空字节，也视为无数据
        if (
            has_audio_data
            and isinstance(self.audio_data, bytes)
            and len(self.audio_data) == 0
        ):
            if not has_audio_stream:
                raise ValueError("audio_data 为空字节且 audio_stream 为空")

        # 如果 audio_data 是空字符串或无效路径，也视为无数据
        if (
            has_audio_data
            and isinstance(self.audio_data, str)
            and not self.audio_data.strip()
        ):
            if not has_audio_stream:
                raise ValueError("audio_data 为空字符串且 audio_stream 为空")


@dataclass
class ASRResult:
    """识别候选结果"""

    text: str
    confidence: Optional[float] = None


@dataclass
class ASRResponse:
    """ASR识别 响应"""

    status: ASRStatus
    text: Optional[str] = None
    confidence: Optional[float] = None
    results: Optional[list[ASRResult]] = None
    duration: Optional[float] = None
    error_code: Optional[str] = None
    error_message: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None

    @property
    def is_success(self) -> bool:
        """是否成功"""
        return self.status == ASRStatus.SUCCESS

    @property
    def is_failed(self) -> bool:
        """是否失败"""
        return self.status == ASRStatus.FAILED

    @classmethod
    def partial(
        cls,
        text: str,
        confidence: Optional[float] = None,
        results: Optional[list[ASRResult]] = None,
        duration: Optional[float] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> "ASRResponse":
        return cls(
            status=ASRStatus.PARTIAL,
            text=text,
            confidence=confidence,
            results=results,
            duration=duration,
            metadata=metadata,
        )

    @classmethod
    def success(
        cls,
        text: str,
        confidence: Optional[float] = None,
        results: Optional[list[ASRResult]] = None,
        duration: Optional[float] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> "ASRResponse":
        """创建成功响应"""
        return cls(
            status=ASRStatus.SUCCESS,
            text=text,
            confidence=confidence,
            results=results,
            duration=duration,
            metadata=metadata,
        )

    @classmethod
    def failed(
        cls,
        error_message: str,
        error_code: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> "ASRResponse":
        """创建失败响应"""
        return cls(
            status=ASRStatus.FAILED,
            error_code=error_code,
            error_message=error_message,
            metadata=metadata,
        )
