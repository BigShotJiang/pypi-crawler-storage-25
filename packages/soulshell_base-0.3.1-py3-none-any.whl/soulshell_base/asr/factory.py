"""
ASR 工厂类
"""

import importlib
from typing import Any, ClassVar, Dict, List, Tuple, Type

from soulshell_base.core import get_logger

from .base import BaseASR
from .exceptions import ASRProviderNotFoundError

logger = get_logger(__name__)


class ASRFactory:
    """ASR 工厂类 - 支持延迟加载提供商"""

    # 提供商映射：名称 -> (模块路径, 类名)
    _PROVIDER_MAP: ClassVar[Dict[str, Tuple[str, str]]] = {
        "volcengine": (
            "soulshell_base.asr.providers.asr_volcengine",
            "VolcengineASRProvider",
        ),
        "volcengine_bigmodel": (
            "soulshell_base.asr.providers.asr_volcengine_bigmodel",
            "VolcengineBigModelASRProvider",
        ),
        "asr_ali": ("soulshell_base.asr.providers.asr_ali", "ASRProviderALi"),
        "asr_xunfei": (
            "soulshell_base.asr.providers.asr_xunfei",
            "ASRProviderXunFei",
        ),
        "asr_ali_realtime": (
            "soulshell_base.asr.providers.asr_ali_realtime",
            "ASRProviderALiRealtime",
        ),
    }

    # 依赖提示信息
    _DEPENDENCY_HINTS: ClassVar[Dict[str, str]] = {
        "volcengine": "websockets, aiohttp (安装: pip install websockets aiohttp 或 uv sync --extra asr-volcengine)",
        "volcengine_bigmodel": "aiohttp (安装: pip install aiohttp 或 uv sync --extra asr-volcengine)",
        "asr_ali": "alibabacloud-nls-python-sdk (安装: pip install alibabacloud-nls-python-sdk 或 uv sync --extra asr-aliyun)",
        "asr_xunfei": "websocket-client (安装: pip install websocket-client 或 uv sync --extra asr-xunfei)",
        "asr_ali_realtime": "alibabacloud-nls-python-sdk (安装: pip install alibabacloud-nls-python-sdk 或 uv sync --extra asr-aliyun)",
    }

    _providers: ClassVar[Dict[str, Type[BaseASR]]] = {}

    @classmethod
    def _lazy_load_provider(cls, name: str) -> Type[BaseASR]:
        """
        延迟加载提供商类

        Args:
            name: 提供商名称

        Returns:
            Type[BaseASR]: 提供商类

        Raises:
            ASRProviderNotFoundError: 提供商不存在
            ImportError: 缺少必要的依赖包
        """
        if name not in cls._PROVIDER_MAP:
            available = cls.list_available_providers()
            raise ASRProviderNotFoundError(
                f"未知的 ASR 提供商: {name}. 可用提供商: {available}"
            )

        module_path, class_name = cls._PROVIDER_MAP[name]

        try:
            module = importlib.import_module(module_path)
            provider_class = getattr(module, class_name)

            # 缓存已加载的提供商
            cls._providers[name] = provider_class
            logger.debug(f"已延迟加载 ASR 提供商: {name}")
            return provider_class

        except ImportError as e:
            # 提供友好的错误提示
            hint = cls._DEPENDENCY_HINTS.get(name, "未知依赖")
            raise ImportError(
                f"无法加载 ASR 提供商 '{name}'，缺少必要的依赖包。\n"
                f"需要安装: {hint}\n"
                f"原始错误: {e}"
            ) from e

    @classmethod
    def list_available_providers(cls) -> List[str]:
        """
        列出所有可用的提供商（包括未加载的）

        Returns:
            list[str]: 提供商名称列表
        """
        return list(cls._PROVIDER_MAP.keys())

    @classmethod
    def register(cls, name: str, provider_class: Type[BaseASR]) -> None:
        """
        注册 ASR 提供商

        Args:
            name: 提供商名称
            provider_class: 提供商类

        Raises:
            TypeError: 如果 provider_class 不是 BaseASR 的子类
        """
        if not issubclass(provider_class, BaseASR):
            raise TypeError(f"{provider_class} 必须继承自 BaseASR")
        cls._providers[name] = provider_class
        logger.debug(f"已注册 ASR 提供商: {name}")

    @classmethod
    def unregister(cls, name: str) -> None:
        """
        取消注册 ASR 提供商

        Args:
            name: 提供商名称
        """
        if name in cls._providers:
            del cls._providers[name]
            logger.debug(f"已取消注册 ASR 提供商: {name}")

    @classmethod
    def get_providers(cls) -> List[str]:
        """
        获取已注册的提供商列表

        Returns:
            list[str]: 提供商名称列表
        """
        return list(cls._providers.keys())

    @classmethod
    def describe(cls, provider_name: str) -> Dict[str, Any]:
        """获取提供商描述信息（自描述能力）

        Args:
            provider_name: 提供商名称

        Returns:
            包含必填/可选参数、示例的描述信息

        Raises:
            ASRProviderNotFoundError: 提供商不存在

        Example:
            >>> from soulshell_base.asr import ASRFactory
            >>> info = ASRFactory.describe("volcengine")
            >>> print(info['required_init_params'])
            {'token': {'type': 'str', 'description': '访问令牌', ...}}
        """
        if provider_name not in cls._PROVIDER_MAP:
            available = cls.list_available_providers()
            raise ASRProviderNotFoundError(
                f"未知的 ASR 提供商: {provider_name}. 可用提供商: {available}"
            )

        # 延迟加载 Provider 类
        if provider_name not in cls._providers:
            cls._lazy_load_provider(provider_name)

        provider_class = cls._providers[provider_name]
        return provider_class.describe()

    @classmethod
    def create(cls, provider_name: str, **kwargs) -> BaseASR:
        """创建 ASR 提供商实例（支持延迟加载）

        Args:
            provider_name: 提供商名称
            **kwargs: 配置参数（例如 api_key、appid、cluster、ws_url 等），将透传给具体 Provider 的 __init__

        Returns:
            BaseASR: ASR 提供商实例

        Raises:
            ASRProviderNotFoundError: 提供商不存在
            ImportError: 缺少必要的依赖包
            ValueError: 配置无效
        """
        # 如果提供商未缓存，则延迟加载
        if provider_name not in cls._providers:
            cls._lazy_load_provider(provider_name)

        provider_class = cls._providers[provider_name]
        instance = provider_class(**kwargs)

        # 验证配置
        if not instance.validate_config():
            raise ValueError(f"ASR 提供商 {provider_name} 配置无效")

        logger.debug(f"成功创建 ASR 提供商实例: {provider_name}")
        return instance

    @classmethod
    def create_from_config(cls, provider_name: str, config: Dict[str, Any]) -> BaseASR:
        """
        从配置字典创建实例

        Args:
            provider_name: 提供商名称
            config: 配置字典，所需参数按提供商要求传入（例如 api_key、appid、cluster 等）

        Returns:
            BaseASR: ASR 提供商实例
        """
        return cls.create(provider_name, **config)
