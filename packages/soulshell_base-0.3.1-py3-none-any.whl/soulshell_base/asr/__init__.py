"""
ASR (Automatic Speech Recognition) 模块
支持多平台的语音识别服务
"""

# 导入核心类
from .base import BaseASR
from .config import ASRConfigManager, ASRProviderConfig

# 导入异常类
from .exceptions import (
    ASRAuthenticationError,
    ASRException,
    ASRInvalidParameterError,
    ASRNetworkError,
    ASRProviderNotFoundError,
    ASRRateLimitError,
    ASRRecognitionError,
    ASRServiceUnavailableError,
    ASRSynthesisError,
)
from .factory import ASRFactory

# 导入数据模型
from .models import (
    ASRRecognizeRequest,
    ASRResponse,
    ASRResult,
    ASRStatus,
    AudioCodec,
    AudioFormat,
)

__version__ = "0.3.1"

__all__ = [
    # 核心类
    "BaseASR",
    "ASRFactory",
    "ASRProviderConfig",
    "ASRConfigManager",
    # 数据模型
    "ASRRecognizeRequest",
    "ASRResponse",
    "ASRResult",
    "ASRStatus",
    "AudioFormat",
    "AudioCodec",
    # 异常类
    "ASRException",
    "ASRProviderNotFoundError",
    "ASRAuthenticationError",
    "ASRRateLimitError",
    "ASRInvalidParameterError",
    "ASRServiceUnavailableError",
    "ASRNetworkError",
    "ASRSynthesisError",
    "ASRRecognitionError",
]
