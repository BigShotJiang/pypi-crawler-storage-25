"""
ASR 配置管理
支持从环境变量、配置文件等加载配置
"""

from dataclasses import dataclass, field
import os
from typing import Any, ClassVar, Dict, Optional

from soulshell_base.core import get_logger

logger = get_logger(__name__)


@dataclass
class ASRProviderConfig:
    """ASR 提供商配置"""

    provider_name: str
    extra_params: Dict[str, Any] = field(default_factory=dict)

    # 运行时状态存储（如token缓存等）
    runtime_state: Dict[str, Any] = field(default_factory=dict)

    def get_runtime_state(self, key: str, default: Any = None) -> Any:
        """获取运行时状态"""
        return self.runtime_state.get(key, default)

    def set_runtime_state(self, key: str, value: Any) -> None:
        """设置运行时状态"""
        self.runtime_state[key] = value

    @classmethod
    def from_env(cls, provider_name: str, prefix: str = "ASR") -> "ASRProviderConfig":
        """
        从环境变量加载配置

        provider_name: 提供商名称
        prefix: 环境变量前缀

        Returns:
            ASRProviderConfig: 配置对象
        Example:
            # 环境变量: ASR_AZURE_API_KEY, ASR_AZURE_ENDPOINT
            config = ASRProviderConfig.from_env("azure")
        """
        env_prefix = f"{prefix}_{provider_name.upper()}_"

        # 收集所有以该前缀开头的环境变量（包含 API_KEY 在内）
        extra_params: Dict[str, Any] = {}
        for key, value in os.environ.items():
            if key.startswith(env_prefix):
                # 移除前缀并转为小写，例如 ASR_VOLCENGINE_API_KEY -> api_key
                param_key = key[len(env_prefix) :].lower()
                extra_params[param_key] = value

        if not extra_params:
            raise ValueError(f"未找到以 {env_prefix} 开头的任何环境变量")

        logger.debug(f"从环境变量加载 {provider_name} 配置: {extra_params}")
        return cls(
            provider_name=provider_name,
            extra_params=extra_params,
        )

    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> "ASRProviderConfig":
        """
        从字典加载配置

        Args:
            config_dict: 配置字典

        Returns:
            ASRProviderConfig: 配置对象
        """
        provider_name = config_dict.pop("provider_name", None)
        if not provider_name:
            raise ValueError("provider_name 不能为空")

        # 其余所有字段都视为该 Provider 的配置参数（例如 api_key、appid、cluster 等）
        return cls(
            provider_name=provider_name,
            extra_params=config_dict,
        )

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "provider_name": self.provider_name,
            **self.extra_params,
        }


class ASRConfigManager:
    """ASR配置管理器"""

    # 各提供商的默认配置
    DEFAULT_CONFIGS: ClassVar[Dict[str, Dict[str, Any]]] = {
        "asr_xunfei": {
            "SILENCE_THRESHOLD": 600,
            "MAX_SILENCE_FRAMES": 30,
            "MIN_SPEECH_FRAMES": 10,
            "MAX_STREAM_SECONDS": 15.0,
            "LANGUAGE": "zh_cn",
            "ACCENT": "mandarin",
            "VAD_EOS": 2000,
        },
        "asr_ali": {
            "REGION_ID": "cn-shanghai",
            "TOKEN_DOMAIN": "nls-meta.cn-shanghai.aliyuncs.com",
            "TOKEN_VERSION": "2019-02-28",
            "MAX_SILENCE_FRAMES": 30,
            "MIN_SPEECH_FRAMES": 30,
            "MAX_STREAM_SECONDS": 15.0,
            "ENABLE_INTERMEDIATE_RESULT": False,
            "ENABLE_PUNCTUATION_PREDICTION": True,
            "ENABLE_INVERSE_TEXT_NORMALIZATION": True,
        },
        "volcengine": {
            "WS_URL": "wss://openspeech.bytedance.com/api/v2/asr",
            "CLUSTER": "volcengine_streaming_common",
        },
    }

    def __init__(self):
        self._configs: Dict[str, ASRProviderConfig] = {}

    def add_config(self, provider_name: str, config: ASRProviderConfig) -> None:
        """
        添加配置

        Args:
            provider_name: 提供商名称
            config: 配置对象
        """
        self._configs[provider_name] = config
        logger.info(f"添加 {provider_name} 配置")

    def get_config(self, provider_name: str) -> Optional[ASRProviderConfig]:
        """
        获取配置

        Args:
            provider_name: 提供商名称

        Returns:
            Optional[ASRProviderConfig]: 配置对象，如果不存在返回 None
        """
        return self._configs.get(provider_name)

    def has_config(self, provider_name: str) -> bool:
        """
        检查是否有指定提供商的配置

        Args:
            provider_name: 提供商名称

        Returns:
            bool: 是否存在配置
        """
        return provider_name in self._configs

    def load_from_env(self, provider_name: str, prefix: str = "ASR") -> None:
        """
        从环境变量加载配置

        Args:
            provider_name: 提供商名称
            prefix: 环境变量前缀
        """
        config = ASRProviderConfig.from_env(provider_name, prefix)
        self.add_config(provider_name, config)

    def load_from_dict(self, provider_name: str, config_dict: Dict[str, Any]) -> None:
        """
        从字典加载配置

        Args:
            provider_name: 提供商名称
            config_dict: 配置字典
        """
        config = ASRProviderConfig.from_dict(config_dict)
        self.add_config(provider_name, config)

    def get_default_config(
        self, provider_name: str, key: str, default: Any = None
    ) -> Any:
        """
        获取提供商的默认配置

        Args:
            provider_name: 提供商名称
            key: 配置键名
            default: 默认值

        Returns:
            配置值，如果不存在返回default
        """
        provider_defaults = self.DEFAULT_CONFIGS.get(provider_name, {})
        return provider_defaults.get(key, default)

    def get_all_default_configs(self, provider_name: str) -> Dict[str, Any]:
        """
        获取提供商的所有默认配置

        Args:
            provider_name: 提供商名称

        Returns:
            配置字典
        """
        return self.DEFAULT_CONFIGS.get(provider_name, {}).copy()
