"""
运行时状态管理器
负责持久化运行时数据（如token、缓存等）到用户目录
"""

import json
import os
from pathlib import Path
import threading
import time
from typing import Any, Dict, Optional

from soulshell_base.core import get_logger

logger = get_logger(__name__)


class RuntimeStateManager:
    """
    运行时状态管理器

    用于管理需要持久化的运行时状态（如token、缓存等）
    数据保存在用户目录：~/.soulshell/runtime/

    特性：
    - 线程安全
    - 支持TTL过期时间
    - 自动清理过期数据
    - 按模块隔离存储
    """

    # 运行时状态目录
    RUNTIME_DIR = Path.home() / ".soulshell" / "runtime"

    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        """单例模式"""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        """初始化运行时状态管理器"""
        if hasattr(self, "_initialized"):
            return

        self._initialized = True
        self._states: Dict[str, Dict[str, Any]] = {}
        self._locks: Dict[str, threading.Lock] = {}

        # 确保运行时目录存在
        self.RUNTIME_DIR.mkdir(parents=True, exist_ok=True)

        # 设置目录权限（仅当前用户可访问）
        try:
            if hasattr(os, "chmod"):
                os.chmod(self.RUNTIME_DIR, 0o700)
        except Exception as e:
            logger.warning(f"无法设置运行时目录权限: {e}")

        logger.debug(f"运行时状态管理器初始化完成，目录: {self.RUNTIME_DIR}")

    @classmethod
    def get_instance(cls) -> "RuntimeStateManager":
        """获取单例实例"""
        return cls()

    def _get_module_lock(self, module: str) -> threading.Lock:
        """获取模块锁"""
        if module not in self._locks:
            self._locks[module] = threading.Lock()
        return self._locks[module]

    def _get_state_file(self, module: str) -> Path:
        """获取模块的状态文件路径"""
        return self.RUNTIME_DIR / f"{module}.json"

    def _load_module_state(self, module: str) -> Dict[str, Any]:
        """从文件加载模块状态"""
        state_file = self._get_state_file(module)

        if not state_file.exists():
            return {}

        try:
            with open(state_file, encoding="utf-8") as f:
                state = json.load(f)
            logger.debug(f"加载模块 {module} 的运行时状态")
            return state
        except Exception as e:
            logger.error(f"加载模块 {module} 状态失败: {e}")
            return {}

    def _save_module_state(self, module: str, state: Dict[str, Any]) -> None:
        """保存模块状态到文件"""
        state_file = self._get_state_file(module)

        try:
            # 写入临时文件，然后原子性重命名
            temp_file = state_file.with_suffix(".json.tmp")
            with open(temp_file, "w", encoding="utf-8") as f:
                json.dump(state, f, indent=2, ensure_ascii=False)

            # 原子性重命名
            temp_file.replace(state_file)

            # 设置文件权限（仅当前用户可访问）
            try:
                if hasattr(os, "chmod"):
                    os.chmod(state_file, 0o600)
            except Exception:
                pass

            logger.debug(f"保存模块 {module} 的运行时状态")
        except Exception as e:
            logger.error(f"保存模块 {module} 状态失败: {e}")

    def get_state(self, module: str, key: str, default: Any = None) -> Any:
        """
        获取运行时状态

        Args:
            module: 模块名称（如 "asr_ali", "asr_xunfei"）
            key: 状态键名
            default: 默认值

        Returns:
            状态值，如果不存在或已过期返回default
        """
        lock = self._get_module_lock(module)

        with lock:
            # 如果内存中没有，从文件加载
            if module not in self._states:
                self._states[module] = self._load_module_state(module)

            state = self._states[module].get(key)

            if state is None:
                return default

            # 检查是否有过期时间
            if isinstance(state, dict) and "expire_time" in state:
                expire_time = state.get("expire_time", 0)
                if expire_time > 0 and time.time() > expire_time:
                    # 已过期，删除并返回默认值
                    logger.debug(f"状态 {module}.{key} 已过期")
                    del self._states[module][key]
                    self._save_module_state(module, self._states[module])
                    return default

                # 返回实际值
                return state.get("value")

            # 简单值直接返回
            return state

    def set_state(
        self, module: str, key: str, value: Any, ttl: Optional[int] = None
    ) -> None:
        """
        设置运行时状态

        Args:
            module: 模块名称（如 "asr_ali", "asr_xunfei"）
            key: 状态键名
            value: 状态值
            ttl: 生存时间（秒），None表示永不过期
        """
        lock = self._get_module_lock(module)

        with lock:
            # 如果内存中没有，从文件加载
            if module not in self._states:
                self._states[module] = self._load_module_state(module)

            # 构造状态数据
            if ttl is not None:
                state_data = {
                    "value": value,
                    "expire_time": time.time() + ttl,
                    "created_at": time.time(),
                }
            else:
                state_data = value

            # 保存到内存和文件
            self._states[module][key] = state_data
            self._save_module_state(module, self._states[module])

            logger.debug(
                f"设置状态 {module}.{key}" + (f" (TTL: {ttl}s)" if ttl else "")
            )

    def delete_state(self, module: str, key: str) -> None:
        """
        删除运行时状态

        Args:
            module: 模块名称
            key: 状态键名
        """
        lock = self._get_module_lock(module)

        with lock:
            if module not in self._states:
                self._states[module] = self._load_module_state(module)

            if key in self._states[module]:
                del self._states[module][key]
                self._save_module_state(module, self._states[module])
                logger.debug(f"删除状态 {module}.{key}")

    def clear_module(self, module: str) -> None:
        """
        清空模块的所有状态

        Args:
            module: 模块名称
        """
        lock = self._get_module_lock(module)

        with lock:
            self._states[module] = {}
            self._save_module_state(module, {})
            logger.info(f"清空模块 {module} 的所有状态")

    def clear_expired(self, module: Optional[str] = None) -> int:
        """
        清理过期状态

        Args:
            module: 模块名称，None表示清理所有模块

        Returns:
            清理的状态数量
        """
        count = 0
        modules = [module] if module else self._states.keys()

        for mod in modules:
            lock = self._get_module_lock(mod)
            with lock:
                if mod not in self._states:
                    self._states[mod] = self._load_module_state(mod)

                state = self._states[mod]
                expired_keys = []

                for key, value in state.items():
                    if isinstance(value, dict) and "expire_time" in value:
                        expire_time = value.get("expire_time", 0)
                        if expire_time > 0 and time.time() > expire_time:
                            expired_keys.append(key)

                # 删除过期项
                for key in expired_keys:
                    del state[key]
                    count += 1

                if expired_keys:
                    self._save_module_state(mod, state)
                    logger.info(f"清理模块 {mod} 的 {len(expired_keys)} 个过期状态")

        return count

    def get_all_states(self, module: str) -> Dict[str, Any]:
        """
        获取模块的所有状态（不包括已过期的）

        Args:
            module: 模块名称

        Returns:
            状态字典
        """
        lock = self._get_module_lock(module)

        with lock:
            if module not in self._states:
                self._states[module] = self._load_module_state(module)

            # 清理过期项并返回有效状态
            valid_states = {}
            current_time = time.time()

            for key, value in self._states[module].items():
                if isinstance(value, dict) and "expire_time" in value:
                    expire_time = value.get("expire_time", 0)
                    if expire_time > 0 and current_time > expire_time:
                        continue  # 跳过过期项
                    valid_states[key] = value.get("value")
                else:
                    valid_states[key] = value

            return valid_states
