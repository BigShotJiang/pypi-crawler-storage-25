"""
通用工具函数
提供项目中常用的工具函数
"""

from datetime import datetime, timedelta
import functools
import hashlib
from pathlib import Path
import re
import time
from typing import Any, Dict, List, Optional
import uuid

from .logging import get_logger

# ========== 时间工具 ==========


def get_timestamp() -> int:
    """
    获取当前时间戳（秒）

    Returns:
        int: Unix 时间戳
    """
    return int(time.time())


def get_timestamp_ms() -> int:
    """
    获取当前时间戳（毫秒）

    Returns:
        int: Unix 时间戳（毫秒）
    """
    return int(time.time() * 1000)


def format_datetime(
    dt: Optional[datetime] = None, format_str: str = "%Y-%m-%d %H:%M:%S"
) -> str:
    """
    格式化日期时间

    Args:
        dt: 日期时间对象，None 表示当前时间
        format_str: 格式化字符串

    Returns:
        str: 格式化后的日期时间字符串
    """
    if dt is None:
        dt = datetime.now()
    return dt.strftime(format_str)


def parse_duration(duration_str: str) -> timedelta:
    """
    解析时长字符串为 timedelta 对象

    Args:
        duration_str: 时长字符串，如 "1h", "30m", "10s"

    Returns:
        timedelta: 时长对象

    Example:
        >>> parse_duration("1h")
        timedelta(hours=1)
        >>> parse_duration("30m")
        timedelta(minutes=30)
    """

    pattern = r"(\d+)([smhd])"
    match = re.match(pattern, duration_str.lower())

    if not match:
        raise ValueError(f"无效的时长格式: {duration_str}")

    value, unit = match.groups()
    value = int(value)

    unit_map = {"s": "seconds", "m": "minutes", "h": "hours", "d": "days"}

    return timedelta(**{unit_map[unit]: value})


# ========== 字符串工具 ==========


def generate_uuid() -> str:
    """
    生成 UUID 字符串

    Returns:
        str: UUID 字符串
    """
    return str(uuid.uuid4())


def generate_short_id(length: int = 8) -> str:
    """
    生成短 ID（基于 UUID）

    Args:
        length: ID 长度

    Returns:
        str: 短 ID
    """
    return uuid.uuid4().hex[:length]


def calculate_md5(content: bytes) -> str:
    """
    计算内容的 MD5 哈希值

    Args:
        content: 字节内容

    Returns:
        str: MD5 哈希值（十六进制）
    """
    return hashlib.md5(content).hexdigest()


def calculate_sha256(content: bytes) -> str:
    """
    计算内容的 SHA256 哈希值

    Args:
        content: 字节内容

    Returns:
        str: SHA256 哈希值（十六进制）
    """
    return hashlib.sha256(content).hexdigest()


def truncate_string(text: str, max_length: int = 50, suffix: str = "...") -> str:
    """
    截断字符串

    Args:
        text: 原始文本
        max_length: 最大长度
        suffix: 截断后缀

    Returns:
        str: 截断后的字符串
    """
    if len(text) <= max_length:
        return text
    return text[: max_length - len(suffix)] + suffix


# ========== 文件工具 ==========


def ensure_dir(path: str) -> Path:
    """
    确保目录存在，不存在则创建

    Args:
        path: 目录路径

    Returns:
        Path: 目录 Path 对象
    """
    dir_path = Path(path)
    dir_path.mkdir(parents=True, exist_ok=True)
    return dir_path


def get_file_size(file_path: str) -> int:
    """
    获取文件大小（字节）

    Args:
        file_path: 文件路径

    Returns:
        int: 文件大小
    """
    return Path(file_path).stat().st_size


def format_file_size(size_bytes: int) -> str:
    """
    格式化文件大小为人类可读格式

    Args:
        size_bytes: 字节大小

    Returns:
        str: 格式化后的大小字符串

    Example:
        >>> format_file_size(1024)
        '1.0 KB'
        >>> format_file_size(1048576)
        '1.0 MB'
    """
    units = ["B", "KB", "MB", "GB", "TB"]
    size = float(size_bytes)
    unit_index = 0

    while size >= 1024 and unit_index < len(units) - 1:
        size /= 1024
        unit_index += 1

    return f"{size:.1f} {units[unit_index]}"


# ========== 数据处理工具 ==========


def safe_get(data: Dict[str, Any], key: str, default: Any = None) -> Any:
    """
    安全获取字典值

    Args:
        data: 字典
        key: 键（支持点号分隔的嵌套键）
        default: 默认值

    Returns:
        Any: 值或默认值

    Example:
        >>> data = {"a": {"b": {"c": 1}}}
        >>> safe_get(data, "a.b.c")
        1
        >>> safe_get(data, "a.b.d", "not found")
        'not found'
    """
    keys = key.split(".")
    value = data

    for k in keys:
        if isinstance(value, dict) and k in value:
            value = value[k]
        else:
            return default

    return value


def merge_dicts(*dicts: Dict[str, Any]) -> Dict[str, Any]:
    """
    合并多个字典

    Args:
        *dicts: 要合并的字典

    Returns:
        Dict[str, Any]: 合并后的字典
    """
    result = {}
    for d in dicts:
        if d:
            result.update(d)
    return result


def chunk_list(lst: List[Any], chunk_size: int) -> List[List[Any]]:
    """
    将列表分块

    Args:
        lst: 列表
        chunk_size: 每块大小

    Returns:
        list: 分块后的列表

    Example:
        >>> chunk_list([1, 2, 3, 4, 5], 2)
        [[1, 2], [3, 4], [5]]
    """
    return [lst[i : i + chunk_size] for i in range(0, len(lst), chunk_size)]


# ========== 验证工具 ==========


def is_valid_url(url: str) -> bool:
    """
    验证 URL 是否有效

    Args:
        url: URL 字符串

    Returns:
        bool: 是否有效
    """
    pattern = re.compile(
        r"^https?://"  # http:// or https://
        r"(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+[A-Z]{2,6}\.?|"  # domain...
        r"localhost|"  # localhost...
        r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})"  # ...or ip
        r"(?::\d+)?"  # optional port
        r"(?:/?|[/?]\S+)$",
        re.IGNORECASE,
    )
    return pattern.match(url) is not None


def clamp(value: float, min_value: float, max_value: float) -> float:
    """
    将值限制在指定范围内

    Args:
        value: 原始值
        min_value: 最小值
        max_value: 最大值

    Returns:
        float: 限制后的值
    """
    return max(min_value, min(value, max_value))


# ========== 装饰器工具 ==========

_perf_logger = get_logger(__name__)


def timeit(func):
    """
    函数运行计时装饰器

    支持用于：
    - 普通函数
    - 实例方法
    - 类方法（@classmethod）
    - 静态方法（@staticmethod）

    计时结果会通过项目统一日志输出，日志名称为当前模块名。

    Example:
        >>> @timeit
        ... def foo():
        ...     time.sleep(0.1)
        ...
        >>> class Bar:
        ...     @timeit
        ...     def instance_method(self):
        ...         time.sleep(0.1)
        ...
        ...     @timeit
        ...     @classmethod
        ...     def cls_method(cls):
        ...         time.sleep(0.1)
        ...
        ...     @timeit
        ...     @staticmethod
        ...     def static_method():
        ...         time.sleep(0.1)
    """

    def _wrap(f):
        @functools.wraps(f)
        def wrapper(*args, **kwargs):
            start = time.perf_counter()
            try:
                return f(*args, **kwargs)
            finally:
                duration = (time.perf_counter() - start) * 1000  # ms
                _perf_logger.info("函数 %s 执行耗时 %.2f ms", f.__qualname__, duration)

        return wrapper

    # 兼容 @timeit 放在 @staticmethod/@classmethod 外层的写法
    if isinstance(func, staticmethod):
        original = func.__func__
        return staticmethod(_wrap(original))
    if isinstance(func, classmethod):
        original = func.__func__
        return classmethod(_wrap(original))

    return _wrap(func)
