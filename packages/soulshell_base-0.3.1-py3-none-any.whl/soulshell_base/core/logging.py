"""
统一日志配置模块
提供全项目统一的日志记录功能
"""

import logging
from pathlib import Path
import sys
from typing import ClassVar, Optional, Set


class LoggerFactory:
    """日志工厂类，用于创建和配置日志记录器"""

    # 默认日志格式
    DEFAULT_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    DEFAULT_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

    # 已配置的日志记录器缓存
    _configured_loggers: ClassVar[Set[str]] = set()

    @classmethod
    def get_logger(
        cls,
        name: str,
        level: str = "INFO",
        log_file: Optional[str] = None,
        format_string: Optional[str] = None,
        date_format: Optional[str] = None,
    ) -> logging.Logger:
        """
        获取配置好的日志记录器

        Args:
            name: 日志记录器名称（通常使用 __name__）
            level: 日志级别 (DEBUG, INFO, WARNING, ERROR, CRITICAL)
            log_file: 日志文件路径（可选）
            format_string: 自定义日志格式（可选）
            date_format: 自定义日期格式（可选）

        Returns:
            logging.Logger: 配置好的日志记录器

        Example:
            >>> from soulshell_base.core.logging import LoggerFactory
            >>> logger = LoggerFactory.get_logger(__name__)
            >>> logger.info("这是一条日志")
        """
        logger = logging.getLogger(name)

        # 如果已经配置过，直接返回
        if name in cls._configured_loggers:
            return logger

        # 设置日志级别
        logger.setLevel(getattr(logging, level.upper()))

        # 创建格式化器
        formatter = logging.Formatter(
            fmt=format_string or cls.DEFAULT_FORMAT,
            datefmt=date_format or cls.DEFAULT_DATE_FORMAT,
        )

        # 添加控制台处理器
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)

        # 添加文件处理器（如果指定了日志文件）
        if log_file:
            log_path = Path(log_file)
            log_path.parent.mkdir(parents=True, exist_ok=True)

            file_handler = logging.FileHandler(log_file, encoding="utf-8")
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)

        # 避免日志传播到父记录器（防止重复输出）
        logger.propagate = False

        # 标记为已配置
        cls._configured_loggers.add(name)

        return logger

    @classmethod
    def configure_root_logger(
        cls,
        level: str = "INFO",
        format_string: Optional[str] = None,
        date_format: Optional[str] = None,
    ) -> None:
        """
        配置根日志记录器

        Args:
            level: 日志级别
            format_string: 自定义日志格式
            date_format: 自定义日期格式
        """
        logging.basicConfig(
            level=getattr(logging, level.upper()),
            format=format_string or cls.DEFAULT_FORMAT,
            datefmt=date_format or cls.DEFAULT_DATE_FORMAT,
            stream=sys.stdout,
        )

    @classmethod
    def reset_logger(cls, name: str) -> None:
        """
        重置日志记录器配置

        Args:
            name: 日志记录器名称
        """
        logger = logging.getLogger(name)
        logger.handlers.clear()
        logger.setLevel(logging.NOTSET)
        cls._configured_loggers.discard(name)


def get_logger(
    name: str, level: str = "INFO", log_file: Optional[str] = None
) -> logging.Logger:
    """
    快捷函数：获取日志记录器

    这是 LoggerFactory.get_logger 的便捷封装

    Args:
        name: 日志记录器名称
        level: 日志级别
        log_file: 日志文件路径

    Returns:
        logging.Logger: 配置好的日志记录器

    Example:
        >>> from soulshell_base.core.logging import get_logger
        >>> logger = get_logger(__name__)
        >>> logger.info("简单使用")
    """
    return LoggerFactory.get_logger(name, level, log_file)
