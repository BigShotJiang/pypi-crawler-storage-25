"""
重试装饰器和工具
提供统一的重试机制
"""

import asyncio
from functools import wraps
import logging
import time
from typing import Callable, Optional, Tuple, Type

logger = logging.getLogger(__name__)


def retry(
    max_attempts: int = 3,
    delay: float = 1.0,
    backoff: float = 2.0,
    exceptions: Tuple[Type[Exception], ...] = (Exception,),
    on_retry: Optional[Callable] = None,
):
    """
    同步函数重试装饰器

    Args:
        max_attempts: 最大重试次数
        delay: 初始延迟时间（秒）
        backoff: 退避倍数（每次重试延迟时间乘以此倍数）
        exceptions: 需要重试的异常类型元组
        on_retry: 重试时的回调函数

    Example:
        >>> @retry(max_attempts=3, delay=1.0, backoff=2.0)
        ... def risky_operation():
        ...     # 可能失败的操作
        ...     pass
    """

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            attempt = 0
            current_delay = delay

            while attempt < max_attempts:
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    attempt += 1
                    if attempt >= max_attempts:
                        logger.error(
                            f"{func.__name__} 失败，已达到最大重试次数 {max_attempts}"
                        )
                        raise

                    logger.warning(
                        f"{func.__name__} 第 {attempt} 次尝试失败: {e!s}, "
                        f"{current_delay:.1f}秒后重试..."
                    )

                    if on_retry:
                        on_retry(attempt, e)

                    time.sleep(current_delay)
                    current_delay *= backoff

            return None

        return wrapper

    return decorator


def async_retry(
    max_attempts: int = 3,
    delay: float = 1.0,
    backoff: float = 2.0,
    exceptions: Tuple[Type[Exception], ...] = (Exception,),
    on_retry: Optional[Callable] = None,
):
    """
    异步函数重试装饰器

    Args:
        max_attempts: 最大重试次数
        delay: 初始延迟时间（秒）
        backoff: 退避倍数
        exceptions: 需要重试的异常类型元组
        on_retry: 重试时的回调函数（可以是异步函数）

    Example:
        >>> @async_retry(max_attempts=3, delay=1.0)
        ... async def risky_async_operation():
        ...     # 可能失败的异步操作
        ...     pass
    """

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def wrapper(*args, **kwargs):
            attempt = 0
            current_delay = delay

            while attempt < max_attempts:
                try:
                    return await func(*args, **kwargs)
                except exceptions as e:
                    attempt += 1
                    if attempt >= max_attempts:
                        logger.error(
                            f"{func.__name__} 失败，已达到最大重试次数 {max_attempts}"
                        )
                        raise

                    logger.warning(
                        f"{func.__name__} 第 {attempt} 次尝试失败: {e!s}, "
                        f"{current_delay:.1f}秒后重试..."
                    )

                    if on_retry:
                        if asyncio.iscoroutinefunction(on_retry):
                            await on_retry(attempt, e)
                        else:
                            on_retry(attempt, e)

                    await asyncio.sleep(current_delay)
                    current_delay *= backoff

            return None

        return wrapper

    return decorator


class RetryConfig:
    """重试配置类"""

    def __init__(
        self,
        max_attempts: int = 3,
        delay: float = 1.0,
        backoff: float = 2.0,
        max_delay: float = 60.0,
        exceptions: Tuple[Type[Exception], ...] = (Exception,),
    ):
        """
        初始化重试配置

        Args:
            max_attempts: 最大重试次数
            delay: 初始延迟时间
            backoff: 退避倍数
            max_delay: 最大延迟时间
            exceptions: 需要重试的异常类型
        """
        self.max_attempts = max_attempts
        self.delay = delay
        self.backoff = backoff
        self.max_delay = max_delay
        self.exceptions = exceptions

    def get_delay(self, attempt: int) -> float:
        """
        计算指定尝试次数的延迟时间

        Args:
            attempt: 当前尝试次数（从1开始）

        Returns:
            float: 延迟时间（秒）
        """
        delay = self.delay * (self.backoff ** (attempt - 1))
        return min(delay, self.max_delay)
