"""SoulShell 多云服务聚合包。"""

__version__ = "0.3.1"

__all__ = ["__version__"]
