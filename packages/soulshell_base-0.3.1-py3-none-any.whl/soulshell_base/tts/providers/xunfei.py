"""
讯飞 TTS 提供商实现
文档: https://www.xfyun.cn/doc/tts/online_tts/API.html
"""

import _thread as thread
import asyncio
import base64
from datetime import datetime
import hashlib
import hmac
import json
import ssl
import threading
from time import mktime
from typing import Any, Optional
from urllib.parse import urlencode
from wsgiref.handlers import format_date_time

try:
    import websocket

    WEBSOCKET_AVAILABLE = True
except ImportError:
    WEBSOCKET_AVAILABLE = False
    websocket = None

from soulshell_base.core import get_logger

from .. import exceptions as tts_exc
from ..base import BaseTTS, pcm_to_wav
from ..models import AudioEncoding, TTSResponse, TTSSynthesizeRequest

logger = get_logger(__name__)


class XunFeiTTSProvider(BaseTTS):
    """讯飞 TTS 提供商 - 使用 WebSocket 方式"""

    def __init__(
        self,
        app_id: str,
        api_key: str,
        api_secret: str,
        ws_url: str = "wss://tts-api.xfyun.cn/v2/tts",
        **kwargs,
    ):
        """
        初始化讯飞 TTS 提供商

        Args:
            app_id: 应用 ID (从讯飞开放平台获取)
            api_key: API Key
            api_secret: API Secret
            ws_url: WebSocket 接口地址
            **kwargs: 其他配置参数
        """
        if not WEBSOCKET_AVAILABLE:
            raise ImportError(
                "需要安装 websocket-client 才能使用讯飞 TTS。"
                "请运行: pip install websocket-client"
            )

        super().__init__(**kwargs)

        self.app_id = app_id
        self.api_key = api_key
        self.api_secret = api_secret
        self.ws_url = ws_url

        # 默认音色配置
        self.default_voice = kwargs.get("default_voice", "xiaoyan")

        # 默认采样率 (8000 或 16000)
        self.default_sample_rate = kwargs.get("default_sample_rate", 16000)

        # 文本编码方式
        self.text_encoding = kwargs.get("text_encoding", "utf8")

        self.logger.debug(f"初始化讯飞 TTS: app_id={self.app_id}")

    def get_provider_name(self) -> str:
        """获取提供商名称"""
        return "xunfei"

    @classmethod
    def describe(cls) -> dict[str, Any]:
        """获取提供商描述信息（自描述能力）"""
        return {
            "provider_name": "xunfei",
            "display_name": "讯飞 TTS",
            "description": "讯飞语音合成服务（WebSocket 方式）",
            "required_init_params": {
                "app_id": {
                    "type": "str",
                    "description": "应用 ID",
                },
                "api_key": {
                    "type": "str",
                    "description": "API Key",
                },
                "api_secret": {
                    "type": "str",
                    "description": "API Secret",
                },
            },
            "optional_init_params": {
                "ws_url": {
                    "type": "str",
                    "description": "WebSocket 接口地址",
                    "default": "wss://tts-api.xfyun.cn/v2/tts",
                },
                "default_voice": {
                    "type": "str",
                    "description": "默认音色",
                    "default": "xiaoyan",
                },
            },
            "supported_methods": [
                "synthesize: 异步语音合成",
            ],
        }

    def validate_config(self) -> bool:
        """验证配置"""
        if not self.app_id:
            self.logger.error("缺少 app_id")
            return False
        if not self.api_key:
            self.logger.error("缺少 api_key")
            return False
        if not self.api_secret:
            self.logger.error("缺少 api_secret")
            return False
        return True

    def validate_request(self, request: TTSSynthesizeRequest) -> None:
        """验证请求参数"""
        if not request.text:
            raise tts_exc.TTSInvalidParameterError("文本不能为空")

        # 讯飞 TTS 文本长度限制 (base64编码后不超过 8000 字节)
        text_bytes = request.text.encode("utf-8")
        encoded_length = len(base64.b64encode(text_bytes))
        if encoded_length > 8000:
            raise tts_exc.TTSTextTooLongError(
                f"合成文本过长，base64编码后 {encoded_length} 字节，超过 8000 字节限制"
            )

        # 如果没有指定 voice_id，使用默认音色
        if not request.voice_id:
            request.voice_id = self.default_voice

    def _map_xunfei_error(self, error_code: int, error_msg: str) -> tuple:
        """
        映射讯飞错误码到具体异常类型
        参考文档: https://www.xfyun.cn/doc/tts/online_tts/API.html#%E9%94%99%E8%AF%AF%E7%A0%81

        Args:
            error_code: 错误码
            error_msg: 错误消息

        Returns:
            (exception_class, formatted_message)
        """
        # 10105: appid不存在
        if error_code == 10105:
            return (
                tts_exc.TTSAuthenticationError,
                f"[错误码 10105] AppID不存在: {error_msg}",
            )

        # 10106: appid授权类型不匹配
        if error_code == 10106:
            return (
                tts_exc.TTSAuthenticationError,
                f"[错误码 10106] AppID授权类型不匹配: {error_msg}",
            )

        # 10107: 请求IP不在白名单
        if error_code == 10107:
            return (
                tts_exc.TTSAuthenticationError,
                f"[错误码 10107] IP地址不在白名单: {error_msg}",
            )

        # 10110: 无权限访问该功能
        if error_code == 10110:
            return (
                tts_exc.TTSAuthenticationError,
                f"[错误码 10110] 无权限访问: {error_msg}",
            )

        # 10700: 引擎授权错误
        if error_code == 10700:
            return (
                tts_exc.TTSAuthenticationError,
                f"[错误码 10700] 引擎授权错误: {error_msg}",
            )

        # 10163: 合成失败（通常是参数错误）
        if error_code == 10163:
            return (
                tts_exc.TTSInvalidParameterError,
                f"[错误码 10163] 参数错误导致合成失败: {error_msg}",
            )

        # 10160: 音色不存在或无权限
        if error_code == 10160:
            return (
                tts_exc.TTSVoiceNotFoundError,
                f"[错误码 10160] 音色不存在或无权限: {error_msg}",
            )

        # 10222: 文本长度超限
        if error_code == 10222:
            return (
                tts_exc.TTSTextTooLongError,
                f"[错误码 10222] 文本长度超限: {error_msg}",
            )

        # 10907: 并发超限
        if error_code == 10907:
            return (
                tts_exc.TTSConcurrencyExceededError,
                f"[错误码 10907] 并发连接数超限: {error_msg}",
            )

        # 10019: 调用次数超限
        if error_code == 10019:
            return (
                tts_exc.TTSRateLimitError,
                f"[错误码 10019] 调用次数超限: {error_msg}",
            )

        # 11200: 授权错误（欠费或停用）
        if error_code == 11200:
            return (
                tts_exc.TTSAuthenticationError,
                f"[错误码 11200] 账号欠费或已停用: {error_msg}",
            )

        # 11201: 日调用量超限
        if error_code == 11201:
            return (
                tts_exc.TTSRateLimitError,
                f"[错误码 11201] 日调用量超限: {error_msg}",
            )

        # 10114-10119: 签名验证失败
        if 10114 <= error_code <= 10119:
            return (
                tts_exc.TTSAuthenticationError,
                f"[错误码 {error_code}] 签名验证失败: {error_msg}",
            )

        # 10161: 文本为空
        if error_code == 10161:
            return (
                tts_exc.TTSTextInvalidError,
                f"[错误码 10161] 文本为空: {error_msg}",
            )

        # 10162: 文本编码格式错误
        if error_code == 10162:
            return (
                tts_exc.TTSTextInvalidError,
                f"[错误码 {error_code}] 文本编码格式错误: {error_msg}",
            )

        # 10213: 音频格式不支持
        if error_code == 10213:
            return (
                tts_exc.TTSInvalidParameterError,
                f"[错误码 10213] 音频格式不支持: {error_msg}",
            )

        # 1xxxx: 客户端参数错误
        if 10000 <= error_code < 20000:
            return (
                tts_exc.TTSInvalidParameterError,
                f"[错误码 {error_code}] 参数错误: {error_msg}",
            )

        # 2xxxx: 服务端错误
        if 20000 <= error_code < 30000:
            return (
                tts_exc.TTSServiceUnavailableError,
                f"[错误码 {error_code}] 服务端错误: {error_msg}",
            )

        # 默认：通用合成错误
        return (tts_exc.TTSSynthesisError, f"[讯飞错误 {error_code}] {error_msg}")

    def _create_url(self) -> str:
        """创建带签名的 WebSocket URL（按照官方示例实现）"""
        # 生成 RFC1123 格式的时间戳
        now = datetime.now()
        date = format_date_time(mktime(now.timetuple()))

        # 拼接签名字符串（官方示例要求 host 为 ws-api.xfyun.cn）
        signature_origin = "host: " + "ws-api.xfyun.cn" + "\n"
        signature_origin += "date: " + date + "\n"
        signature_origin += "GET " + "/v2/tts " + "HTTP/1.1"

        # HMAC-SHA256 加密
        signature_sha = hmac.new(
            self.api_secret.encode("utf-8"),
            signature_origin.encode("utf-8"),
            digestmod=hashlib.sha256,
        ).digest()
        signature_sha = base64.b64encode(signature_sha).decode(encoding="utf-8")

        # 构建授权字符串
        authorization_origin = (
            f'api_key="{self.api_key}", '
            f'algorithm="hmac-sha256", '
            f'headers="host date request-line", '
            f'signature="{signature_sha}"'
        )
        authorization = base64.b64encode(authorization_origin.encode("utf-8")).decode(
            encoding="utf-8"
        )

        # 构建 URL 参数（host 必须与签名中一致）
        v = {
            "authorization": authorization,
            "date": date,
            "host": "ws-api.xfyun.cn",
        }

        url = self.ws_url + "?" + urlencode(v)
        self.logger.debug("讯飞 TTS WebSocket URL 已生成")
        return url

    def _convert_params(self, request: TTSSynthesizeRequest) -> dict:
        """
        转换参数范围

        框架标准范围 -> 讯飞范围:
        - speed: 0.1~2.0 -> 0~100 (默认50, 简单线性映射: speed*50)
        - pitch: -12~12 -> 0~100 (默认50)
        - volume: 0.1~2.0 -> 0~100 (默认50, 简单线性映射: volume*50)

        支持的编码格式:
        - WAV: 请求 PCM (raw)，合成后添加 WAV 头
        - PCM: 直接使用 raw 格式
        - MP3: 使用 lame 格式
        """
        # speed: 0.1~2.0 -> 0~100 (简单线性映射: speed*50)
        speed = int(request.speed * 50)
        speed = max(0, min(100, speed))

        # pitch: -12~12 -> 0~100
        # 公式: 50 + (pitch / 12) * 50
        pitch = int(50 + (request.pitch / 12) * 50)
        pitch = max(0, min(100, pitch))

        # volume: 0.1~2.0 -> 0~100 (简单线性映射: volume*50)
        volume = int(request.volume * 50)
        volume = max(0, min(100, volume))

        # 音频格式映射
        # WAV 和 PCM 都请求 raw 格式，WAV 在后处理时添加头
        # MP3 使用 lame 格式
        format_map = {
            AudioEncoding.WAV: "raw",  # PCM -> 后处理转 WAV
            AudioEncoding.PCM: "raw",  # 直接返回 PCM
            AudioEncoding.MP3: "lame",  # MP3 格式
        }
        aue = format_map.get(request.encoding, "raw")

        # 采样率固定为 16000（讯飞支持 8000 和 16000）
        sample_rate = 16000
        auf = f"audio/L16;rate={sample_rate}"

        return {
            "aue": aue,
            "auf": auf,
            "vcn": request.voice_id,
            "speed": speed,
            "pitch": pitch,
            "volume": volume,
            "tte": self.text_encoding,
        }

    def _build_request_data(self, request: TTSSynthesizeRequest, params: dict) -> dict:
        """构建 WebSocket 请求数据"""
        # 文本 base64 编码（按照官方示例）
        text_encoded = str(base64.b64encode(request.text.encode("utf-8")), "UTF8")

        return {
            "common": {"app_id": self.app_id},
            "business": params,
            "data": {"status": 2, "text": text_encoded},
        }

    def _build_cache_key_payload(self, request: TTSSynthesizeRequest) -> dict[str, Any]:
        """构建缓存键负载（讯飞特定实现：固定采样率16000）"""
        encoding = (
            request.encoding.value
            if hasattr(request.encoding, "value")
            else str(request.encoding)
        )
        sample_rate = 16000  # 讯飞固定采样率
        return {
            "provider": "xunfei",
            "text": request.text,
            "voice_id": request.voice_id,
            "language": request.language,
            "speed": request.speed,
            "pitch": request.pitch,
            "volume": request.volume,
            "encoding": encoding,
            "sample_rate": sample_rate,
            "tte": self.text_encoding,
        }

    def _build_cache_hit_response(
        self,
        *,
        request: TTSSynthesizeRequest,
        cached_bytes: bytes,
        cached_metadata: dict[str, Any] | None = None,
    ) -> TTSResponse:
        """构建缓存命中响应（讯飞特定：固定采样率16000）"""
        audio_format = (
            request.encoding.value
            if hasattr(request.encoding, "value")
            else str(request.encoding)
        )

        # 从缓存元数据中恢复响应字段
        duration = None
        sample_rate = 16000  # 讯飞固定采样率
        original_metadata = {}

        if cached_metadata:
            duration = cached_metadata.get("duration")
            sample_rate = cached_metadata.get("sample_rate", 16000)
            original_metadata = cached_metadata.get("original_metadata", {})

        # 合并元数据
        response_metadata = {
            "provider": "xunfei",
            "voice_id": request.voice_id,
            "from_cache": True,
            "cache_region": "tts/xunfei",
            **original_metadata,
        }

        return TTSResponse.success(
            audio_data=cached_bytes,
            duration=duration,
            audio_format=audio_format,
            sample_rate=sample_rate,
            metadata=response_metadata,
        )

    def _build_cache_normalized_artifacts(
        self, request: TTSSynthesizeRequest
    ) -> dict[str, Any]:
        """构建缓存规范化产物"""
        return {"text_norm": request.text.strip()}

    async def synthesize(self, request: TTSSynthesizeRequest) -> TTSResponse:
        """
        异步语音合成（支持可选缓存与重置缓存）

        使用方式：
        - Provider 级默认：
            * default_use_cache: 是否默认启用缓存（bool，默认 False）
            * default_cache_ttl: 默认缓存 TTL（float，默认 -1 表示永久）
        - 请求级覆盖（优先级更高，通过 TTSSynthesizeRequest 顶层字段）：
            * use_cache: Optional[bool] - 本次请求是否使用缓存
            * reset_cache: bool - 是否重置缓存（删除旧缓存后重新生成）
            * cache_ttl: Optional[float] - 本次请求的 TTL（<=1 统一视为永久）
        """
        # 在线程池中执行同步方法
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self.synthesize_sync, request)

    def _synthesize_sync_impl(self, request: TTSSynthesizeRequest) -> TTSResponse:
        """同步合成的核心实现（不含缓存逻辑）"""
        try:
            audio_data = bytearray()
            error_msg: Optional[str] = None
            error_exception: Optional[Exception] = None  # 保存需要抛出的异常
            completed = threading.Event()
            sid: Optional[str] = None
            ws_instance: Optional[websocket.WebSocketApp] = None

            # 预先构建请求数据
            params = self._convert_params(request)
            request_data = self._build_request_data(request, params)
            request_json = json.dumps(request_data)
            self.logger.debug(f"讯飞 TTS 开始合成: {request_json}")

            # 回调函数（按照官方示例）
            def on_message(ws, message):
                nonlocal error_msg, error_exception, sid
                try:
                    message = json.loads(message)
                    code = message.get("code")
                    sid = message.get("sid")

                    # 检查是否包含 data 字段
                    if "data" not in message:
                        self.logger.warning(
                            f"讯飞 TTS 收到无 data 字段的消息: {message}"
                        )
                        if code != 0:
                            # 使用错误映射
                            msg_text = message.get("message", f"未知错误 (code={code})")
                            exc_class, exc_msg = self._map_xunfei_error(code, msg_text)
                            error_msg = exc_msg
                            error_exception = exc_class(exc_msg)  # 保存异常对象
                            self.logger.error(f"讯飞 TTS 错误: {error_msg}")
                            ws.close()
                            completed.set()
                        return

                    data = message["data"]
                    audio = data.get("audio", "")
                    status = data.get("status", 0)

                    # 解码音频数据
                    audio_bytes = base64.b64decode(audio) if audio else b""

                    # self.logger.debug(
                    #     f"讯飞 TTS 收到消息: code={code}, status={status}, audio_len={len(audio_bytes)}"
                    # )

                    if status == 2:
                        self.logger.debug(f"讯飞 TTS 合成完成, sid={sid}")
                        ws.close()

                    if code != 0:
                        # 使用错误映射
                        msg_text = message.get("message", f"未知错误 (code={code})")
                        exc_class, exc_msg = self._map_xunfei_error(code, msg_text)
                        error_msg = exc_msg
                        error_exception = exc_class(exc_msg)  # 保存异常对象
                        self.logger.error(f"讯飞 TTS 错误: sid={sid}, {error_msg}")
                        ws.close()
                        completed.set()
                    elif audio_bytes:
                        audio_data.extend(audio_bytes)

                except Exception as e:
                    self.logger.error(f"讯飞 TTS 消息处理异常: {e}", exc_info=True)
                    error_msg = str(e)
                    completed.set()

            def on_error(_ws, error):
                nonlocal error_msg
                error_msg = str(error)
                self.logger.error(f"讯飞 TTS WebSocket 错误: {error}")
                completed.set()

            def on_close(_ws, close_status_code, close_msg):
                self.logger.debug(
                    f"讯飞 TTS WebSocket 关闭: {close_status_code}, {close_msg}"
                )
                completed.set()

            def on_open(ws):
                # 使用 _thread.start_new_thread（官方示例方式）
                def run():
                    self.logger.debug("------>开始发送文本数据")
                    ws.send(request_json)
                    self.logger.debug("讯飞 TTS 已发送合成请求")

                thread.start_new_thread(run, ())

            # 创建 WebSocket 连接
            ws_url = self._create_url()
            self.logger.debug("讯飞 TTS 开始连接 WebSocket")

            ws_instance = websocket.WebSocketApp(
                ws_url,
                on_message=on_message,
                on_error=on_error,
                on_close=on_close,
            )
            ws_instance.on_open = on_open

            # 在新线程中运行 WebSocket
            ws_thread = threading.Thread(
                target=lambda: ws_instance.run_forever(
                    sslopt={"cert_reqs": ssl.CERT_NONE}
                ),
                daemon=True,
            )
            ws_thread.start()

            # 等待完成
            timeout = request.extra_params.get("timeout", 30)
            if not completed.wait(timeout=timeout):
                self.logger.error(f"讯飞 TTS 合成超时 ({timeout}秒)")
                return TTSResponse.failed(f"合成超时 ({timeout}秒)")

            # 处理结果
            if error_exception:
                # 抛出保存的异常对象
                raise error_exception

            if error_msg:
                # 如果有错误消息但没有异常对象，抛出通用异常
                raise tts_exc.TTSSynthesisError(f"讯飞 TTS 错误: {error_msg}")

            if not audio_data:
                return TTSResponse.failed("音频数据为空")

            # 采样率固定为 16000
            actual_sample_rate = 16000
            # aue = params.get("aue", "raw")
            requested_encoding = request.encoding

            # 根据请求的编码格式处理音频数据
            audio_format = "pcm"
            duration = None

            if requested_encoding == AudioEncoding.WAV:
                # WAV: PCM 数据添加 WAV 头
                self.logger.debug(f"将 PCM 转换为 WAV，采样率: {actual_sample_rate}")
                wav_data = pcm_to_wav(bytes(audio_data), sample_rate=actual_sample_rate)
                audio_data = bytearray(wav_data)
                audio_format = "wav"
                # 计算时长（WAV 头 44 字节）
                pcm_len = len(audio_data) - 44
                duration = pcm_len / (actual_sample_rate * 2)  # 16bit = 2 bytes

            elif requested_encoding == AudioEncoding.PCM:
                # PCM: 直接返回原始数据
                audio_format = "pcm"
                duration = len(audio_data) / (actual_sample_rate * 2)

            elif requested_encoding == AudioEncoding.MP3:
                # MP3: 讯飞直接返回 MP3 格式
                audio_format = "mp3"
                # MP3 时长无法简单计算，设为 None
                duration = None

            else:
                # 默认当作 WAV 处理
                self.logger.debug(f"未知编码 {requested_encoding}，默认转换为 WAV")
                wav_data = pcm_to_wav(bytes(audio_data), sample_rate=actual_sample_rate)
                audio_data = bytearray(wav_data)
                audio_format = "wav"
                pcm_len = len(audio_data) - 44
                duration = pcm_len / (actual_sample_rate * 2)

            self.logger.debug(
                f"讯飞 TTS 合成成功，文本长度: {len(request.text)}, "
                f"音频大小: {len(audio_data)} bytes, 格式: {audio_format}"
            )

            return TTSResponse.success(
                audio_data=bytes(audio_data),
                duration=duration,
                audio_format=audio_format,
                sample_rate=actual_sample_rate,
                metadata={
                    "provider": "xunfei",
                    "voice_id": request.voice_id,
                    "text_length": len(request.text),
                    "sid": sid,
                },
            )

        except tts_exc.TTSException:
            # 重新抛出所有 TTS 异常
            raise
        except Exception as e:
            self.logger.error(f"讯飞 TTS 同步合成异常: {e!s}", exc_info=True)
            return TTSResponse.failed(f"合成过程中发生错误: {e!s}")

    def synthesize_sync(self, request: TTSSynthesizeRequest) -> TTSResponse:
        """
        同步语音合成（支持可选缓存与重置缓存）

        使用方式：
        - Provider 级默认：
            * default_use_cache: 是否默认启用缓存（bool，默认 False）
            * default_cache_ttl: 默认缓存 TTL（float，默认 -1 表示永久）
        - 请求级覆盖（优先级更高，通过 TTSSynthesizeRequest 顶层字段）：
            * use_cache: Optional[bool] - 本次请求是否使用缓存
            * reset_cache: bool - 是否重置缓存（删除旧缓存后重新生成）
            * cache_ttl: Optional[float] - 本次请求的 TTL（<=1 统一视为永久）
        """
        return self._run_with_cache_policy_sync(
            request=request,
            compute=lambda: self._synthesize_sync_impl(request),
        )
