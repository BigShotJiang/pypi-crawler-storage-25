"""
Azure TTS 提供商实现
# https://github.com/Azure-Samples/cognitive-services-speech-sdk
# https://learn.microsoft.com/zh-cn/python/api/azure-cognitiveservices-speech/azure.cognitiveservices.speech?view=azure-python
# https://learn.microsoft.com/zh-cn/azure/ai-services/speech-service/speech-synthesis-markup-voice
"""

import asyncio
import concurrent.futures
import html
from typing import Any, Optional

try:
    import azure.cognitiveservices.speech as speechsdk

    AZURE_AVAILABLE = True
except ImportError:
    AZURE_AVAILABLE = False
    speechsdk = None

from soulshell_base.core import get_logger

from .. import exceptions as tts_exc
from ..base import BaseTTS
from ..models import TTSResponse, TTSSynthesizeRequest

logger = get_logger(__name__)


class AzureTTSProvider(BaseTTS):
    """Azure TTS 提供商"""

    def __init__(
        self, api_key: str, endpoint: str, region: Optional[str] = None, **kwargs
    ):
        """
        初始化 Azure TTS 提供商

        Args:
            api_key: Azure Speech Service 密钥
            endpoint: Azure Speech Service 端点
            region: Azure 区域（可选）
            **kwargs: 其他配置参数
        """
        if not AZURE_AVAILABLE:
            raise ImportError(
                "Azure Speech SDK 未安装。请运行: pip install azure-cognitiveservices-speech"
            )

        super().__init__(**kwargs)
        self.api_key = api_key
        self.endpoint = endpoint
        self.region = region
        self.name = "azure"

    def get_provider_name(self) -> str:
        """获取提供商名称"""
        return self.name

    @classmethod
    def describe(cls) -> dict[str, Any]:
        """获取提供商描述信息（自描述能力）"""
        return {
            "provider_name": "azure",
            "display_name": "Azure TTS",
            "description": "Azure 认知服务语音合成",
            "required_init_params": {
                "api_key": {
                    "type": "str",
                    "description": "Azure Speech Service 密钥",
                },
                "endpoint": {
                    "type": "str",
                    "description": "Azure Speech Service 端点",
                },
            },
            "optional_init_params": {
                "region": {
                    "type": "str",
                    "description": "Azure 区域",
                    "default": None,
                },
            },
            "supported_methods": [
                "synthesize: 异步语音合成",
            ],
        }

    def validate_config(self) -> bool:
        """验证配置"""
        if not super().validate_config():
            return False
        if not self.endpoint:
            self.logger.error("Azure endpoint 不能为空")
            return False
        return True

    def _map_azure_error(self, error_details: str) -> tuple:
        """
        映射 Azure 错误到具体异常类型
        参考文档: https://learn.microsoft.com/zh-cn/azure/ai-services/speech-service/

        Args:
            error_details: Azure 错误详情字符串

        Returns:
            (exception_class, formatted_message)
        """
        error_lower = error_details.lower()

        # 认证失败
        if (
            "authentication" in error_lower
            or "unauthorized" in error_lower
            or "forbidden" in error_lower
        ):
            return (tts_exc.TTSAuthenticationError, f"Azure 认证失败: {error_details}")

        # 文本过长（音频超过10分钟限制）
        if (
            "maximum media duration" in error_lower
            or "audio has exceeded" in error_lower
            or "10 minutes" in error_lower
        ):
            return (
                tts_exc.TTSTextTooLongError,
                f"文本过长导致音频超过10分钟限制: {error_details}",
            )

        # 超时错误
        if "timeout" in error_lower:
            return (tts_exc.TTSTimeoutError, f"Azure 请求超时: {error_details}")

        # 音色不存在 - 必须在网络错误检查之前，因为音色错误消息中也可能包含 "connection"
        if "voice" in error_lower and (
            "not found" in error_lower
            or "invalid" in error_lower
            or "does not exist" in error_lower
            or "unsupported" in error_lower
        ):
            return (
                tts_exc.TTSVoiceNotFoundError,
                f"Azure 音色不存在或不可用: {error_details}",
            )

        # 网络错误
        if "network" in error_lower or "connection" in error_lower:
            return (tts_exc.TTSNetworkError, f"Azure 网络错误: {error_details}")

        # 限流错误
        if "rate" in error_lower or "throttl" in error_lower or "quota" in error_lower:
            return (tts_exc.TTSRateLimitError, f"Azure 请求频率限制: {error_details}")

        # 服务不可用
        if "service" in error_lower and (
            "unavailable" in error_lower or "error" in error_lower
        ):
            return (
                tts_exc.TTSServiceUnavailableError,
                f"Azure 服务不可用: {error_details}",
            )

        # SSML 格式错误
        if "ssml" in error_lower or "xml" in error_lower:
            return (tts_exc.TTSResourceError, f"Azure SSML 格式错误: {error_details}")

        # 参数错误
        if (
            "parameter" in error_lower
            or "argument" in error_lower
            or "invalid" in error_lower
        ):
            return (
                tts_exc.TTSInvalidParameterError,
                f"Azure 参数错误: {error_details}",
            )

        # 默认：合成失败
        return (tts_exc.TTSSynthesisError, f"Azure 合成失败: {error_details}")

    def _create_ssml_string(
        self, text: str, voice_id: str, speed: float, pitch: float, volume: float
    ) -> str:
        """
        创建 SSML 字符串

        Args:
            text: 要合成的文本
            voice_id: 音色ID
            speed: 语速倍率 (0.1~2.0)
            pitch: 音调半音 (-12~12)
            volume: 音量 (0.1~2.0)

        Returns:
            str: SSML 字符串
        """
        # 语速：兜底到 [0.5, 2.0]，转换为百分比字符串
        speed = max(0.5, min(2.0, speed))
        rate_percentage = 100 * (speed - 1)
        ssml_rate_string = f"{rate_percentage:+.2f}%"

        # 音调：直接使用半音值，转换为半音字符串
        ssml_pitch_string = f"{pitch:+.1f}st"

        # 音量：转换为百分比字符串 (0.1~2.0 -> 10~200, 1.0 = 100%)
        volume_percentage = volume * 100
        ssml_volume_string = f"{volume_percentage:.1f}"

        # 转义 XML 特殊字符
        escaped_text = html.escape(text)

        # 提取语言代码
        try:
            lang = "-".join(voice_id.split("-")[:2])
        except Exception:
            lang = "en-US"

        # 构建 SSML
        ssml_string = f"""
<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='{lang}'>
    <voice name='{voice_id}'>
        <prosody rate='{ssml_rate_string}' pitch='{ssml_pitch_string}' volume='{ssml_volume_string}'>
            {escaped_text}
        </prosody>
    </voice>
</speak>
        """.strip()

        return ssml_string  # noqa: RET504

    async def _synthesize_impl(self, request: TTSSynthesizeRequest) -> TTSResponse:
        """
        Azure TTS 合成的核心实现（不含缓存逻辑）

        Args:
            request: 合成请求参数

        Returns:
            TTSResponse: 合成结果
        """
        try:
            # 验证请求
            self.validate_request(request)

            # Azure TTS 文本长度验证
            # Azure 限制音频时长为10分钟，粗略估算中文约5000字符
            if len(request.text) > 5000:
                raise tts_exc.TTSTextTooLongError(
                    f"文本长度 {len(request.text)} 字符可能超过Azure 10分钟音频限制，建议不超过5000字符"
                )

            # 创建语音配置
            speech_config = speechsdk.SpeechConfig(
                subscription=self.api_key, endpoint=self.endpoint
            )
            speech_config.speech_synthesis_voice_name = request.voice_id

            # 设置输出格式
            if request.encoding.value == "mp3":
                speech_config.set_speech_synthesis_output_format(
                    speechsdk.SpeechSynthesisOutputFormat.Audio16Khz32KBitRateMonoMp3
                )
            elif request.encoding.value == "wav":
                speech_config.set_speech_synthesis_output_format(
                    speechsdk.SpeechSynthesisOutputFormat.Riff16Khz16BitMonoPcm
                )
            else:
                # 默认使用 MP3
                speech_config.set_speech_synthesis_output_format(
                    speechsdk.SpeechSynthesisOutputFormat.Audio16Khz32KBitRateMonoMp3
                )

            # 创建语音合成器
            speech_synthesizer = speechsdk.SpeechSynthesizer(
                speech_config=speech_config, audio_config=None
            )

            # 创建 SSML 字符串
            ssml_string = self._create_ssml_string(
                request.text,
                request.voice_id,
                request.speed,
                request.pitch,
                request.volume,
            )
            self.logger.debug(f"Azure TTS 开始合成:ssml={ssml_string}")
            # 执行语音合成
            result = speech_synthesizer.speak_ssml_async(ssml_string).get()

            # 检查结果
            if result is None:
                return TTSResponse.failed("Azure 语音合成失败：返回结果为空")

            if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
                # 获取音频数据
                audio_data = result.audio_data

                # 估算音频时长（Azure SDK 不直接提供）
                # 16kHz 16bit mono: 1秒 = 32000 字节
                duration = len(audio_data) / 32000.0 if audio_data else 0

                self.logger.info(
                    f"Azure TTS 合成成功，文本长度: {len(request.text)}, "
                    f"音频大小: {len(audio_data)} bytes"
                )

                return TTSResponse.success(
                    audio_data=audio_data,
                    duration=duration,
                    audio_format=request.encoding.value,
                    sample_rate=16000,
                    metadata={"voice_id": request.voice_id, "provider": "azure"},
                )

            if result.reason == speechsdk.ResultReason.Canceled:
                cancellation_details = result.cancellation_details

                if cancellation_details.reason == speechsdk.CancellationReason.Error:
                    error_details = cancellation_details.error_details
                    self.logger.error(f"Azure TTS 合成失败: {error_details}")

                    # 使用错误映射方法
                    exc_class, exc_msg = self._map_azure_error(error_details)
                    raise exc_class(exc_msg)

                return TTSResponse.failed(
                    f"语音合成取消: {cancellation_details.reason}"
                )

            return TTSResponse.failed(f"语音合成失败: {result.reason}")

        except tts_exc.TTSException:
            # 重新抛出自定义异常
            raise
        except Exception as e:
            self.logger.error(f"Azure TTS 合成异常: {e!s}", exc_info=True)
            return TTSResponse.failed(error_message=f"处理过程中发生错误: {e!s}")

    async def synthesize(self, request: TTSSynthesizeRequest) -> TTSResponse:
        """
        Azure TTS 合成（支持可选缓存与重置缓存）

        Args:
            request: 合成请求参数

        Returns:
            TTSResponse: 合成结果

        使用方式：
        - Provider 级默认：
            * default_use_cache: 是否默认启用缓存（bool，默认 False）
            * default_cache_ttl: 默认缓存 TTL（float，默认 -1 表示永久）
        - 请求级覆盖（优先级更高，通过 TTSSynthesizeRequest 顶层字段）：
            * use_cache: Optional[bool] - 本次请求是否使用缓存
            * reset_cache: bool - 是否重置缓存（删除旧缓存后重新生成）
            * cache_ttl: Optional[float] - 本次请求的 TTL（<=1 统一视为永久）
        """
        return await self._run_with_cache_policy_async(
            request=request,
            compute=lambda: self._synthesize_impl(request),
        )

    def synthesize_sync(self, request: TTSSynthesizeRequest) -> TTSResponse:
        """
        同步语音合成（封装异步实现）

        Args:
            request: 合成请求参数

        Returns:
            TTSResponse: 合成结果
        """
        try:
            # 尝试获取当前事件循环
            asyncio.get_running_loop()
        except RuntimeError:
            # 没有运行中的事件循环，创建新的
            return asyncio.run(self.synthesize(request))
        else:
            # 已有运行中的事件循环，使用 run_in_executor
            with concurrent.futures.ThreadPoolExecutor() as executor:
                future = executor.submit(asyncio.run, self.synthesize(request))
                return future.result()
