"""
Volcengine (火山引擎) TTS 提供商实现
使用 WebSocket V3 协议
文档: https://www.volcengine.com/docs/6561/1257584
"""

import asyncio
import concurrent.futures
import gzip
import json
from typing import Any, AsyncIterator
import uuid

from .protocols import (
    MsgType,
    full_client_request,
    receive_message,
)

try:
    import websockets

    WEBSOCKETS_AVAILABLE = True
except ImportError:
    WEBSOCKETS_AVAILABLE = False
    websockets = None

try:
    import httpx

    HTTPX_AVAILABLE = True
except ImportError:
    HTTPX_AVAILABLE = False
    httpx = None
from pathlib import Path

from soulshell_base.core import get_logger
from soulshell_base.tts import exceptions as tts_exc
from soulshell_base.tts.base import BaseTTS
from soulshell_base.tts.models import (
    TTSCloneVoiceRequest,
    TTSResponse,
    TTSStatus,
    TTSSynthesizeRequest,
)

logger = get_logger(__name__)


# ========== Provider 实现 ==========
class VolcengineTTSProviderV1(BaseTTS):
    """火山引擎 TTS 提供商_V1"""

    def __init__(
        self,
        **kwargs,
    ):
        super().__init__(**kwargs)
        if not WEBSOCKETS_AVAILABLE:
            raise ImportError("websockets 未安装。请运行: pip install websockets")
        if not HTTPX_AVAILABLE:
            raise ImportError("httpx 未安装。请运行: pip install httpx")
        self.config = kwargs

        self.appid = kwargs.get("appid")
        self.token = kwargs.get("token")
        self.voice_type = kwargs.get("voice_type")
        self.cluster = kwargs.get("cluster", "volcano_tts")
        self.ws_url = kwargs.get(
            "ws_url", "wss://openspeech.bytedance.com/api/v1/tts/ws_binary"
        )
        self.name = "volcengine_v1"

    def get_provider_name(self) -> str:
        """获取提供商名称"""
        return self.name

    @classmethod
    def describe(cls) -> dict[str, Any]:
        """获取提供商描述信息（自描述能力）"""
        return {
            "provider_name": "volcengine_v1",
            "display_name": "火山引擎 TTS V1",
            "description": "火山引擎语音合成服务（WebSocket V1 协议）",
            "required_init_params": {
                "appid": {
                    "type": "str",
                    "description": "应用 ID",
                },
                "token": {
                    "type": "str",
                    "description": "Access Token",
                },
                "voice_type": {
                    "type": "str",
                    "description": "音色类型",
                },
            },
            "optional_init_params": {
                "cluster": {
                    "type": "str",
                    "description": "集群",
                    "default": "volcano_tts",
                },
                "ws_url": {
                    "type": "str",
                    "description": "WebSocket URL",
                    "default": "wss://openspeech.bytedance.com/api/v1/tts/ws_binary",
                },
            },
            "supported_methods": [
                "synthesize: 异步语音合成",
            ],
        }

    def validate_config(self) -> bool:
        """验证配置"""
        if not (self.appid and self.token):
            self.logger.error("Volcengine appid 或 token 不能为空")
            return False
        if self.voice_type is None:
            self.logger.error("tts音色 voice_type 不能为空")
            return False
        return True

    def validate_request(self, request: TTSSynthesizeRequest) -> None:
        if not request.text:
            raise tts_exc.TTSInvalidParameterError("文本不能为空")

        # 火山引擎 V1 文本长度限制：单次请求不超过 5000 字符
        # 参考: https://www.volcengine.com/docs/6561/79823
        if len(request.text) >= 5000:
            raise tts_exc.TTSTextTooLongError(
                f"文本长度 {len(request.text)} 字符超过限制，火山引擎单次合成不得超过 5000 字符"
            )

    # ========== 火山引擎 V1 特定：无需覆盖基类方法 ==========

    def _map_volcengine_error(self, error_code: int, error_msg: str) -> tuple:
        """
        映射火山引擎错误码到具体异常类型
        参考错误码范围: 3001-3050, 45000xxx

        Args:
            error_code: 错误码
            error_msg: 错误消息

        Returns:
            (exception_class, formatted_message)
        """
        # 45000010: Token/Grant 错误
        if error_code == 45000010:
            return (
                tts_exc.TTSAuthenticationError,
                f"[错误码 45000010] Token 无效或已过期: {error_msg}",
            )

        # 45000030: 资源未授权（通常是音色不存在或无权限）
        if error_code == 45000030:
            return (
                tts_exc.TTSVoiceNotFoundError,
                f"[错误码 45000030] 音色不存在或无权限: {error_msg}",
            )

        # 45000xxx: 其他认证相关错误
        if 45000000 <= error_code < 45001000:
            return (
                tts_exc.TTSAuthenticationError,
                f"[错误码 {error_code}] 认证失败: {error_msg}",
            )

        # 3001: 请求参数错误
        if error_code == 3001:
            return (
                tts_exc.TTSInvalidParameterError,
                f"[错误码 3001] 请求参数错误: {error_msg}",
            )

        # 3002: 音色不存在
        if error_code == 3002:
            return (
                tts_exc.TTSVoiceNotFoundError,
                f"[错误码 3002] 音色不存在: {error_msg}",
            )

        # 3003: 文本为空或不合法
        if error_code == 3003:
            return (tts_exc.TTSTextInvalidError, f"[错误码 3003] 文本无效: {error_msg}")

        # 3004: 文本过长
        if error_code == 3004:
            return (tts_exc.TTSTextTooLongError, f"[错误码 3004] 文本过长: {error_msg}")

        # 3005-3010: 认证相关
        if 3005 <= error_code <= 3010:
            return (
                tts_exc.TTSAuthenticationError,
                f"[错误码 {error_code}] 认证失败: {error_msg}",
            )

        # 3011-3015: 限流相关
        if 3011 <= error_code <= 3015:
            return (
                tts_exc.TTSRateLimitError,
                f"[错误码 {error_code}] 请求限流: {error_msg}",
            )

        # 3016-3020: 并发相关
        if 3016 <= error_code <= 3020:
            return (
                tts_exc.TTSConcurrencyExceededError,
                f"[错误码 {error_code}] 并发超限: {error_msg}",
            )

        # 3021-3030: 超时相关
        if 3021 <= error_code <= 3030:
            return (
                tts_exc.TTSTimeoutError,
                f"[错误码 {error_code}] 请求超时: {error_msg}",
            )

        # 3031-3040: 服务端错误
        if 3031 <= error_code <= 3040:
            return (
                tts_exc.TTSServiceUnavailableError,
                f"[错误码 {error_code}] 服务不可用: {error_msg}",
            )

        # 3041-3050: 资源相关
        if 3041 <= error_code <= 3050:
            return (
                tts_exc.TTSResourceError,
                f"[错误码 {error_code}] 资源错误: {error_msg}",
            )

        # 默认: 通用合成错误
        return (tts_exc.TTSSynthesisError, f"[火山引擎错误 {error_code}] {error_msg}")

    async def _synthesize(self, request: TTSSynthesizeRequest, stream: bool = False):
        """内部合成实现

        - 当 ``stream=False`` 时，返回完整的 ``TTSResponse``
        - 当 ``stream=True`` 时，返回 ``AsyncIterator[TTSResponse]``，输出事件流
        """
        duration: float | None = None
        meta_data: dict | None = None
        req_id: str = str(uuid.uuid4())

        async def _generator() -> AsyncIterator[TTSResponse]:
            nonlocal duration
            nonlocal meta_data
            nonlocal req_id
            nonlocal stream
            websocket = None
            websocket_request = None
            req_audio = None
            audio_data = bytearray()
            old_sequence = 0
            try:
                # 验证请求
                self.validate_request(request)

                headers = {
                    "Authorization": f"Bearer;{self.token}",
                }
                websocket = await websockets.connect(
                    self.ws_url,
                    additional_headers=headers,
                    max_size=10 * 1024 * 1024,
                )
                pitch_ratio = 2 ** (request.pitch / 12)
                # 组装请求
                websocket_request = {
                    "app": {
                        "appid": self.appid,
                        "token": self.token,
                        "cluster": self.cluster,
                    },
                    "user": {
                        "uid": str(uuid.uuid4()),
                    },
                    "audio": {
                        "voice_type": request.voice_id,
                        "encoding": request.encoding,
                        "rate": 16000,
                        # 语速：兜底到 [0.2, 2.0]，保留1位小数
                        "speed_ratio": round(max(0.2, min(2.0, request.speed)), 1),
                        # 音量：兜底到 [0.1, 2.0]，保留1位小数
                        "volume_ratio": round(max(0.1, min(2.0, request.volume)), 1),
                        "loudness_ratio": round(max(0.1, min(2.0, request.volume)), 1),
                        # 音高：-12~12 转换为倍率，兜底到 [0.1, 2.0]
                        "pitch_ratio": round(max(0.1, min(2.0, pitch_ratio)), 1),
                    },
                    "request": {
                        "reqid": req_id,
                        "text": request.text,
                        "operation": "submit",
                        "with_timestamp": "1",
                        "extra_param": json.dumps(
                            {
                                "disable_markdown_filter": False,
                            }
                        ),
                    },
                }
                req_audio = websocket_request.get("audio")

                yield TTSResponse(
                    status=TTSStatus.START,
                    audio_format=request.encoding,
                    sample_rate=request.sample_rate,
                    metadata={
                        "req_id": req_id,
                        "provider": self.name,
                        "audio_meta": None,
                        "req_audio": req_audio,
                    },
                )

                # 发送请求
                await full_client_request(
                    websocket,
                    json.dumps(websocket_request).encode(),
                )

                # 读取返回
                while True:
                    msg = await receive_message(websocket)

                    if msg.type == MsgType.FrontEndResultServer:
                        # 解析 JSON 元信息（包含 duration 等）
                        if hasattr(msg, "payload") and msg.payload:
                            try:
                                payload_data = json.loads(msg.payload)
                                if "duration" in payload_data:
                                    duration = float(payload_data["duration"]) / 1000
                                    self.logger.info("Duration: %s", duration)
                                else:
                                    yield TTSResponse(
                                        status=TTSStatus.PARTIAL,
                                        audio_data=msg.payload,
                                        duration=duration,
                                        audio_format=request.encoding,
                                        sample_rate=request.sample_rate,
                                        metadata={
                                            "req_id": req_id,
                                            "chunk_index": msg.sequence,
                                            "provider": self.name,
                                            "audio_meta": payload_data,
                                            "req_audio": req_audio,
                                        },
                                    )
                            except json.JSONDecodeError as e:
                                self.logger.error("JSON 解析错误: %s", e)
                        continue

                    if msg.type == MsgType.AudioOnlyServer:
                        self.logger.debug("audio_data: %s", msg)
                        if msg.sequence < 0:
                            # sequence < 0 表示最后一包
                            last_sequence = old_sequence + 1
                        if msg.sequence != 1:
                            meta_data = None
                        if msg.payload:
                            audio_data.extend(msg.payload)
                            yield TTSResponse(
                                status=TTSStatus.PARTIAL,
                                audio_data=msg.payload,
                                duration=duration,
                                audio_format=request.encoding,
                                sample_rate=request.sample_rate,
                                metadata={
                                    "req_id": req_id,
                                    "chunk_index": last_sequence
                                    if msg.sequence < 0
                                    else msg.sequence,
                                    "provider": self.name,
                                    "audio_meta": meta_data,
                                    "req_audio": req_audio,
                                },
                            )

                        if msg.sequence < 0:
                            break
                        old_sequence = msg.sequence
                        continue

                    if msg.type == MsgType.Error:
                        # 处理错误消息
                        error_code = msg.error_code if hasattr(msg, "error_code") else 0
                        error_payload = msg.payload if hasattr(msg, "payload") else b""

                        # 尝试解析 JSON 错误消息
                        error_msg = ""
                        try:
                            if error_payload:
                                error_data = json.loads(error_payload.decode("utf-8"))
                                error_msg = error_data.get(
                                    "message", str(error_payload)
                                )
                                # 优先使用 JSON 中的 backend_code
                                if "backend_code" in error_data:
                                    error_code = error_data["backend_code"]
                        except (json.JSONDecodeError, UnicodeDecodeError):
                            error_msg = str(error_payload)

                        self.logger.error(
                            f"火山引擎 V1 错误: code={error_code}, message={error_msg}"
                        )

                        # 使用错误映射
                        exc_class, exc_msg = self._map_volcengine_error(
                            error_code, error_msg
                        )
                        raise exc_class(exc_msg)

                    # 其它类型一律视为错误
                    raise RuntimeError(f"TTS conversion failed: {msg}")

            except tts_exc.TTSException:
                # TTS 相关异常直接抛出，不包装
                raise
            except Exception as e:
                yield TTSResponse(
                    status=TTSStatus.FAILED,
                    error_message=str(e),
                    metadata={
                        "req_id": req_id,
                        "provider": self.name,
                        "audio_meta": meta_data,
                        "req_audio": req_audio,
                    },
                )
                return

            finally:
                if websocket:
                    await websocket.close()
                self.logger.info("Connection closed")

            if not audio_data:
                yield TTSResponse(
                    status=TTSStatus.FAILED,
                    error_message="No audio data received",
                    metadata={
                        "req_id": req_id,
                        "provider": self.name,
                        "audio_meta": meta_data,
                        "req_audio": req_audio,
                    },
                )
                return
            yield TTSResponse(
                status=TTSStatus.SUCCESS,
                audio_data=None if stream else bytes(audio_data),
                duration=duration,
                audio_format=request.encoding,
                sample_rate=request.sample_rate,
                metadata={
                    "req_id": req_id,
                    "provider": self.name,
                    "audio_meta": meta_data,
                    "req_audio": req_audio,
                },
            )

        # 流式：直接把内部 async generator 返回给调用方
        if stream:
            return _generator()

        # 非流式：消费事件流，返回最终 SUCCESS/FAILED 事件
        last_event: TTSResponse | None = None
        async for event in _generator():
            last_event = event
        if last_event is None:
            return TTSResponse(
                status=TTSStatus.FAILED,
                error_message="No events received",
                metadata={
                    "req_id": req_id,
                    "provider": self.name,
                    "audio_meta": meta_data,
                    "req_audio": None,
                },
            )
        return last_event

    async def _synthesize_impl(self, request: TTSSynthesizeRequest) -> TTSResponse:
        """非流式合成的核心实现（不含缓存逻辑）"""
        result = await self._synthesize(request, stream=False)
        assert isinstance(result, TTSResponse)
        return result

    async def synthesize(self, request: TTSSynthesizeRequest) -> TTSResponse:
        """
        非流式接口：直接返回完整音频（支持可选缓存与重置缓存）

        使用方式：
        - Provider 级默认：
            * default_use_cache: 是否默认启用缓存（bool，默认 False）
            * default_cache_ttl: 默认缓存 TTL（float，默认 -1 表示永久）
        - 请求级覆盖（优先级更高，通过 TTSSynthesizeRequest 顶层字段）：
            * use_cache: Optional[bool] - 本次请求是否使用缓存
            * reset_cache: bool - 是否重置缓存（删除旧缓存后重新生成）
            * cache_ttl: Optional[float] - 本次请求的 TTL（<=1 统一视为永久）
        """
        return await self._run_with_cache_policy_async(
            request=request,
            compute=lambda: self._synthesize_impl(request),
        )

    def synthesize_sync(self, request: TTSSynthesizeRequest) -> TTSResponse:
        """
        同步语音合成（封装异步实现）

        Args:
            request: 合成请求参数

        Returns:
            TTSResponse: 合成结果
        """

        try:
            # 尝试获取当前事件循环
            asyncio.get_running_loop()
        except RuntimeError:
            # 没有运行中的事件循环，创建新的
            return asyncio.run(self.synthesize(request))
        else:
            # 已有运行中的事件循环，使用 run_in_executor

            with concurrent.futures.ThreadPoolExecutor() as executor:
                future = executor.submit(asyncio.run, self.synthesize(request))
                return future.result()

    async def synthesize_stream(
        self, request: TTSSynthesizeRequest
    ) -> AsyncIterator[TTSResponse]:
        """流式接口：返回事件流"""
        stream_iter = await self._synthesize(request, stream=True)
        # 为了类型友好，这里再包装一层 async generator
        async for event in stream_iter:
            yield event

    async def submit_clone_voice_http(self, request: TTSCloneVoiceRequest) -> dict:
        """推荐使用HTTP API提交克隆音色请求，ws首次提交会错误，用http不报错
        参考volcengine_voicecopy_uploadAndStatus.py的train函数实现
        https://www.volcengine.com/docs/6561/1305191?lang=zh

        Args:
            request: TTSCloneVoiceRequest对象，包含speaker_id和clone_auido_path

        Returns:
            克隆生成的新音色响应数据
        """
        self.logger.info(
            "开始发起HTTP训练请求, appid=%s, speaker_id=%s, audio_path=%s, resource_id=%s",
            self.appid,
            request.speaker_id,
            request.clone_auido_path,
            "seed-icl-2.0",
        )

        clone_url = "https://openspeech.bytedance.com/api/v1/mega_tts/audio/upload"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer;{self.token}",
            "Resource-Id": "seed-icl-2.0",
        }

        # 编码音频文件
        encoded_data, audio_format = self._encode_audio_file(request.clone_auido_path)
        audios = [{"audio_bytes": encoded_data, "audio_format": audio_format}]
        data = {
            "appid": self.appid,
            "speaker_id": request.speaker_id,
            "audios": audios,
            "source": request.source,
            "language": request.language,
            "model_type": request.model_type,
        }

        # 额外参数
        if hasattr(request, "extra_params") and request.extra_params:
            data["extra_params"] = json.dumps(request.extra_params)

        self.logger.info("开始向 %s 发送训练请求", clone_url)

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(clone_url, json=data, headers=headers)

                self.logger.info("训练请求返回状态码=%s", response.status_code)
                if response.status_code != 200:
                    self.logger.error(
                        "训练接口返回非200, status=%s, body=%s",
                        response.status_code,
                        response.text,
                    )
                    raise RuntimeError(f"训练请求错误: {response.text}")

                result = response.json()
                self.logger.info("训练接口返回JSON=%s", result)
                self.logger.info("训练接口返回头部信息=%s", response.headers)
                if "'StatusCode': 0" in str(result):
                    self.logger.info("训练接口返回StatusCode为0, 训练成功")
                else:
                    err = f"训练错误，接口返回StatusCode非0, resp={result} 请求头={response.headers}, 请检查"
                    self.logger.error(err)
                    raise RuntimeError(err)
                return result

        except httpx.RequestError as e:
            self.logger.error("训练请求发送失败, 错误=%s", str(e))
            raise
        except Exception as e:
            self.logger.error("训练请求处理失败: %s", str(e))
            raise

    async def query_clone_voice_http(self, request: TTSCloneVoiceRequest) -> dict:
        """使用HTTP API查询克隆音色状态
        参考volcengine_voicecopy_uploadAndStatus.py的get_status函数实现
        Args:
            request: TTSCloneVoiceRequest对象，包含speaker_id
        Returns:
            包含克隆状态信息的字典
        """
        self.logger.info(
            "开始查询HTTP训练状态, appid=%s, speaker_id=%s",
            self.appid,
            request.speaker_id,
        )
        clone_status_url = "https://openspeech.bytedance.com/api/v1/mega_tts/status"

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer;{self.token}",
            "Resource-Id": "seed-icl-2.0",
        }

        body = {"appid": self.appid, "speaker_id": request.speaker_id}
        self.logger.info("开始向 %s 发送状态查询请求", clone_status_url)

        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.post(
                    clone_status_url, headers=headers, json=body
                )

                self.logger.info("状态查询接口返回状态码=%s", response.status_code)
                if response.status_code != 200:
                    self.logger.error(
                        "状态查询接口返回非200, status=%s, body=%s",
                        response.status_code,
                        response.text,
                    )
                    raise RuntimeError(f"状态查询请求错误: {response.text}")

                res_json = response.json()
                self.logger.info("状态查询接口返回JSON=%s", res_json)

                status = res_json.get("status") if isinstance(res_json, dict) else None
                if status is not None:
                    self.logger.info("当前训练状态=%s", status)

                return res_json

        except httpx.RequestError as e:
            self.logger.error("状态查询请求发送失败, 错误=%s", str(e))
            raise
        except Exception as e:
            self.logger.error("状态查询请求处理失败: %s", str(e))
            raise

    def _parse_ws_response(self, res: bytes) -> bytes:
        """解析WebSocket响应，基于tts_websocket_demo.py的parse_response函数
        Args:
            res: WebSocket响应字节数据
        Returns:
            解析后的响应数据字典
        """
        # 解析响应头部
        protocol_version = res[0] >> 4  # noqa: F841
        header_size = res[0] & 0x0F
        message_type = res[1] >> 4
        message_type_specific_flags = res[1] & 0x0F
        serialization_method = res[2] >> 4  # noqa: F841
        message_compression = res[2] & 0x0F

        # 跳过头部，获取payload
        payload = res[header_size * 4 :]

        # 处理不同类型的消息
        if message_type == 0xC:  # 0xc = 12, frontend server response
            # msg_size = int.from_bytes(payload[:4], "big", signed=False)
            payload_content = payload[4:]
            if message_compression == 1:  # gzip压缩
                payload_content = gzip.decompress(payload_content)
                self.logger.info(f"收到前端响应数据: {payload_content=}")
            # 解析JSON响应
            try:
                response_data = json.loads(payload_content.decode("utf-8"))
                self.logger.info(f"收到前端响应数据: {response_data=}")
            except json.JSONDecodeError as e:
                self.logger.error(f"JSON解析错误: {e}")

        elif message_type == 0xF:  # 0xf = 15, error message
            code = int.from_bytes(payload[:4], "big", signed=False)
            # msg_size = int.from_bytes(payload[4:8], "big", signed=False)
            error_msg = payload[8:]
            if message_compression == 1:
                error_msg = gzip.decompress(error_msg)
            error_msg_str = error_msg.decode("utf-8")
            self.logger.error(f"错误消息: code={code}, message={error_msg_str}")

            # 使用错误映射
            exc_class, exc_msg = self._map_volcengine_error(code, error_msg_str)
            raise exc_class(exc_msg)

        elif message_type == 0xB:  # 0xb = 11, audio-only server response
            # 音频数据，返回空字典
            self.logger.info("收到音频响应数据")
            if message_type_specific_flags == 0:  # no sequence number as ACK
                return b""
            # sequence_number = int.from_bytes(payload[:4], "big", signed=True)
            payload_size = int.from_bytes(payload[4:8], "big", signed=False)
            payload = payload[8:]
            self.logger.info(f"                Payload size: {payload_size} bytes")
            return payload

        else:
            self.logger.warning(f"未定义的消息类型: {message_type}")
        return b""

    async def submit_clone_voice_ws(self, request: TTSCloneVoiceRequest) -> dict:
        """通过websockets提交克隆音色请求，返回克隆响应数据，但
        https://www.volcengine.com/docs/6561/1305191?lang=zh

        Args:
            request: TTSCloneVoiceRequest对象，包含speaker_id和clone_auido_path

        Returns:
            克隆生成的新音色响应数据
        """
        self.logger.info(
            f"提交克隆音色请求, speaker_id={request.speaker_id}, audio_path={request.clone_auido_path}"
        )
        default_header = bytearray(b"\x11\x10\x11\x00")

        # 准备请求数据
        submit_request_json = {
            "app": {"appid": self.appid, "token": self.token, "cluster": self.cluster},
            "user": {"uid": str(uuid.uuid4())},
            "audio": {
                "voice_type": request.speaker_id,
                "encoding": Path(request.clone_auido_path).suffix[1:].lower(),
            },
            "request": {
                "reqid": str(uuid.uuid4()),
                "text": "这是克隆音色的首次测试输出，请检查确认音色是否符合条件，如果不符合，请参考官方文档，优化输入音频后重新训练",
                "text_type": "plain",
                "operation": "submit",
            },
        }
        # 序列化和压缩
        payload_bytes = str.encode(json.dumps(submit_request_json))
        payload_bytes = gzip.compress(payload_bytes)

        # 构建完整请求
        full_client_request = bytearray(default_header)
        full_client_request.extend(
            (len(payload_bytes)).to_bytes(4, "big")
        )  # payload size(4 bytes)
        full_client_request.extend(payload_bytes)  # payload

        # 设置请求头
        headers = {"Authorization": f"Bearer; {self.token}"}

        try:
            async with websockets.connect(
                self.ws_url, additional_headers=headers, ping_interval=None
            ) as ws:
                await ws.send(full_client_request)

                # 使用_parse_response处理响应，而不是自己实现解析逻辑
                while True:
                    res = await ws.recv()
                    response_data = self._parse_ws_response(res)

                    # 如果收到了前端响应，返回数据
                    if response_data:
                        return response_data

                    # 如果收到错误消息，_parse_response会抛出异常
                    # 如果收到音频数据，继续等待下一个响应

        except Exception as e:
            self.logger.error(f"提交克隆音色请求失败: {e!s}")
            raise

    async def query_clone_voice_ws(self, request: TTSCloneVoiceRequest) -> bytes:
        """查询克隆音色状态
        参考tts_websocket_demo.py中的test_query函数实现
        Args:
            request: TTSCloneVoiceRequest对象，包含speaker_id
        Returns:
            包含克隆状态信息的字典
        """
        self.logger.info(f"查询克隆音色状态, speaker_id={request.speaker_id}")

        # 使用与tts_websocket_demo.py相同的协议格式
        default_header = bytearray(b"\x11\x10\x11\x00")

        # 准备请求数据
        submit_request_json = {
            "app": {"appid": self.appid, "token": self.token, "cluster": self.cluster},
            "user": {"uid": str(uuid.uuid4())},
            "audio": {
                "voice_type": request.speaker_id,
                "encoding": Path(request.clone_auido_path).suffix[1:].lower(),
            },
            "request": {
                "reqid": str(uuid.uuid4()),
                "text": "这是克隆音色的首次测试输出，请检查确认音色是否符合条件，如果不符合，请参考官方文档，优化输入音频后重新训练",
                "text_type": "plain",
                "operation": "query",
            },
        }

        # 序列化和压缩
        payload_bytes = str.encode(json.dumps(submit_request_json))
        payload_bytes = gzip.compress(payload_bytes)

        # 构建完整请求
        full_client_request = bytearray(default_header)
        full_client_request.extend(
            (len(payload_bytes)).to_bytes(4, "big")
        )  # payload size(4 bytes)
        full_client_request.extend(payload_bytes)  # payload

        # 设置请求头
        headers = {"Authorization": f"Bearer; {self.token}"}

        try:
            async with websockets.connect(
                self.ws_url, additional_headers=headers, ping_interval=None
            ) as ws:
                await ws.send(full_client_request)

                # 接收响应并使用_parse_response处理
                res = await ws.recv()
                return self._parse_ws_response(res)

        except Exception as e:
            self.logger.error(f"查询克隆音色状态失败: {e!s}")
            raise
