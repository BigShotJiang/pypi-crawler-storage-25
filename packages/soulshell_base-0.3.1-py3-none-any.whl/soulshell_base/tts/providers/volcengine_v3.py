"""
Volcengine (火山引擎) TTS 提供商实现
使用 WebSocket V3 协议

注意: 根据火山引擎文档 https://www.volcengine.com/docs/6561/1329505?lang=zh
在流式场景下传入 wav 会多次返回 wav header，因此 WAV 格式请求时使用 pcm，
返回前再添加 wav header。其他格式（mp3/pcm/ogg）直接请求原格式。
"""

import asyncio
import concurrent.futures
import json
from typing import Any, AsyncIterator
from typing import Optional as TypingOptional
import uuid

from soulshell_base.core import get_logger

try:
    import websockets
    from websockets.asyncio.client import ClientConnection

    WEBSOCKETS_AVAILABLE = True
except ImportError:
    WEBSOCKETS_AVAILABLE = False
    websockets = None
    ClientConnection = None


from .. import exceptions as tts_exc
from ..base import BaseTTS, pcm_to_wav
from ..models import AudioEncoding, TTSResponse, TTSStatus, TTSSynthesizeRequest

logger = get_logger(__name__)


# "豆包语音合成模型2.0" 音色列表 音色列表  https://www.volcengine.com/docs/6561/1257544?lang=zh
TTS_V2_VOICES = {
    "zh_female_vv_uranus_bigtts",
    "zh_female_xiaohe_uranus_bigtts",
    "zh_male_m191_uranus_bigtts",
    "zh_male_taocheng_uranus_bigtts",
}

# "精品克隆音色" 音色列表  https://www.volcengine.com/docs/6561/1257544?lang=zh
ICL_V2_VOICES = {
    "saturn_zh_female_cancan_tob",
    "saturn_zh_male_tiancaitongzhuo_tob",
    "saturn_zh_male_shuanglangshaonian_tob",
    "saturn_zh_female_tiaopigongzhu_tob",
    "saturn_zh_female_keainvsheng_tob",
    "zh_male_ruyayichen_saturn_bigtts",
    "zh_female_santongyongns_saturn_bigtts",
    "zh_female_meilinvyou_saturn_bigtts",
    "zh_female_jitangnv_saturn_bigtts",
    "zh_female_mizai_saturn_bigtts",
    "zh_male_dayi_saturn_bigtts",
    "zh_female_xueayi_saturn_bigtts",
}


def get_volc_resource_id_by_voice(voice_id: str, concurrent: bool = False) -> str:
    v = voice_id.strip()
    if v in ICL_V2_VOICES:
        return "seed-icl-2.0"
    if v.startswith("saturn_"):
        return "seed-icl-1.0-concurr" if concurrent else "seed-icl-1.0"
    if v in TTS_V2_VOICES:
        return "seed-tts-2.0"
    return "seed-tts-1.0-concurr" if concurrent else "seed-tts-1.0"


# ========== WebSocket V3 协议常量 ==========
PROTOCOL_VERSION = 0b0001
DEFAULT_HEADER_SIZE = 0b0001

# 消息类型
FULL_CLIENT_REQUEST = 0b0001
AUDIO_ONLY_RESPONSE = 0b1011
FULL_SERVER_RESPONSE = 0b1001
ERROR_INFORMATION = 0b1111

# 消息标志位
MsgTypeFlagWithEvent = 0b100

# 序列化方法
NO_SERIALIZATION = 0b0000
JSON = 0b0001

# 压缩方法
COMPRESSION_NO = 0b0000

# 事件代码
EVENT_NONE = 0
EVENT_Start_Connection = 1
EVENT_FinishConnection = 2
EVENT_ConnectionStarted = 50
EVENT_ConnectionFailed = 51
EVENT_StartSession = 100
EVENT_FinishSession = 102
EVENT_SessionStarted = 150
EVENT_SessionFinished = 152
EVENT_SessionFailed = 153
EVENT_TaskRequest = 200
EVENT_TTSSentenceStart = 350
EVENT_TTSSentenceEnd = 351
EVENT_TTSResponse = 352


# ========== 协议辅助类 ==========
class Header:
    """WebSocket V3 协议头部"""

    def __init__(
        self,
        protocol_version=PROTOCOL_VERSION,
        header_size=DEFAULT_HEADER_SIZE,
        message_type: int = 0,
        message_type_specific_flags: int = 0,
        serial_method: int = NO_SERIALIZATION,
        compression_type: int = COMPRESSION_NO,
        reserved_data=0,
    ):
        self.protocol_version = protocol_version
        self.header_size = header_size
        self.message_type = message_type
        self.message_type_specific_flags = message_type_specific_flags
        self.serial_method = serial_method
        self.compression_type = compression_type
        self.reserved_data = reserved_data

    def as_bytes(self) -> bytes:
        """转换为字节"""
        byte1 = (self.protocol_version << 4) | self.header_size
        byte2 = (self.message_type << 4) | self.message_type_specific_flags
        byte3 = (self.serial_method << 4) | self.compression_type
        byte4 = self.reserved_data
        return bytes([byte1, byte2, byte3, byte4])


class Optional:
    """WebSocket V3 协议可选部分"""

    def __init__(
        self,
        event: int = EVENT_NONE,
        sessionid: TypingOptional[str] = None,
        sequence: TypingOptional[int] = None,
    ):
        self.event = event
        self.sessionid = sessionid
        self.sequence = sequence
        self.errorCode: int = 0
        self.connectionId: str = None
        self.response_meta_json: str = None

    def as_bytes(self) -> bytes:
        """转换为字节"""
        option_bytes = bytearray()

        if self.event != EVENT_NONE:
            option_bytes.extend(self.event.to_bytes(4, "big", signed=True))

        if self.sessionid is not None:
            session_id_bytes = str.encode(self.sessionid)
            size = len(session_id_bytes)
            option_bytes.extend(size.to_bytes(4, "big", signed=True))
            option_bytes.extend(session_id_bytes)

        if self.sequence is not None:
            option_bytes.extend(self.sequence.to_bytes(4, "big", signed=True))

        return bytes(option_bytes)


class Response:
    """WebSocket V3 响应"""

    def __init__(self, header: Header, optional: Optional):
        self.header = header
        self.optional = optional
        self.payload: TypingOptional[bytes] = None
        self.payload_json: TypingOptional[str] = None


# ========== 协议辅助函数 ==========
def get_payload_bytes(
    uid="1234",
    event=EVENT_NONE,
    text="",
    speaker="",
    audio_format="mp3",
    audio_sample_rate=24000,
    **kwargs,
) -> bytes:
    """构建 JSON Payload

    参数转换：
    - voice_speech_rate: 0.1~2.0 -> -50~100（兜底到0.5~2.0）
    - voice_loudness_rate: 0.1~2.0 -> -50~100（兜底到0.5~2.0）
    - voice_pitch: -12~12 -> -12~12（直接使用）
    """
    # 转换语速: 兜底到 0.5~2.0，然后转换为 -50~100
    voice_speech_rate = kwargs.get("voice_speech_rate", 1.0)
    voice_speech_rate = max(0.5, min(2.0, voice_speech_rate))
    voice_speech_rate = int(100 * (voice_speech_rate - 1))

    # 转换音量: 兜底到 0.5~2.0，然后转换为 -50~100
    voice_loudness_rate = kwargs.get("voice_loudness_rate", 1.0)
    voice_loudness_rate = max(0.5, min(2.0, voice_loudness_rate))
    voice_loudness_rate = int(100 * (voice_loudness_rate - 1))

    # 构建 audio_params
    audio_params = {
        "format": audio_format,
        "sample_rate": audio_sample_rate,
        "speech_rate": voice_speech_rate,
        "loudness_rate": voice_loudness_rate,
    }

    # 添加 emotion_scale（如果提供）
    emotion_scale = kwargs.get("emotion_scale")
    if emotion_scale is not None:
        # 类型转换：确保是数字类型
        try:
            emotion_scale = float(emotion_scale)
        except (TypeError, ValueError):
            logger.warning(
                f"emotion_scale 参数 {emotion_scale} 无法转换为数字，忽略该参数"
            )
            emotion_scale = None

        # 兜底到 [1, 5] 并转换为整型
        if emotion_scale is not None:
            if emotion_scale < 1:
                logger.warning(
                    f"emotion_scale 参数 {emotion_scale} 小于最小值1，已调整为1"
                )
                emotion_scale = 1
            elif emotion_scale > 5:
                logger.warning(
                    f"emotion_scale 参数 {emotion_scale} 大于最大值5，已调整为5"
                )
                emotion_scale = 5

            # 转换为整型并添加到参数
            audio_params["emotion_scale"] = int(emotion_scale)

    # 构建 req_params
    req_params = {
        "text": text,
        "speaker": speaker,
        "audio_params": audio_params,
    }

    # 构建 additions（包含 context_texts 和 post_process）
    additions = {}

    # 添加 context_texts（如果提供且不为空）
    context_texts = kwargs.get("context_texts")
    if context_texts:
        if not isinstance(context_texts, list):
            context_texts = [context_texts]
        additions["context_texts"] = context_texts

    # 添加 post_process.pitch（如果提供）
    voice_pitch = kwargs.get("voice_pitch")
    if voice_pitch is not None:
        # 兜底到 [-12, 12]
        voice_pitch = max(-12, min(12, voice_pitch))
        additions["post_process"] = {"pitch": int(voice_pitch)}

    # 如果有 additions，添加到 req_params
    if additions:
        req_params["additions"] = json.dumps(additions)

    payload_dict = {
        "user": {"uid": uid},
        "event": event,
        "namespace": "BidirectionalTTS",
        "req_params": req_params,
    }
    return str.encode(json.dumps(payload_dict))


async def send_event(
    ws: ClientConnection,
    header: bytes,
    optional: TypingOptional[bytes] = None,
    payload: TypingOptional[bytes] = None,
):
    """发送事件到 WebSocket"""
    full_client_request = bytearray(header)

    if optional is not None:
        full_client_request.extend(optional)

    if payload is not None:
        payload_size = len(payload)
        full_client_request.extend(payload_size.to_bytes(4, "big", signed=True))
        full_client_request.extend(payload)

    await ws.send(full_client_request)


def parser_response(res: bytes) -> Response:
    """解析 WebSocket 响应"""
    if isinstance(res, str):
        raise RuntimeError(f"收到字符串消息，期望字节: {res}")

    if len(res) < 4:
        raise ValueError(f"响应太短，无法包含头部。长度: {len(res)}")

    response = Response(Header(), Optional())
    header = response.header
    num_mask = 0b00001111

    # 解析 Header
    header.protocol_version = (res[0] >> 4) & num_mask
    header.header_size = res[0] & num_mask
    header.message_type = (res[1] >> 4) & num_mask
    header.message_type_specific_flags = res[1] & num_mask
    header.serial_method = (res[2] >> 4) & num_mask
    header.compression_type = res[2] & num_mask
    header.reserved_data = res[3]

    offset = 4
    optional = response.optional

    # 解析 Optional 和 Payload
    if header.message_type in [FULL_SERVER_RESPONSE, AUDIO_ONLY_RESPONSE]:
        if header.message_type_specific_flags & MsgTypeFlagWithEvent:
            if offset + 4 <= len(res):
                optional.event = int.from_bytes(
                    res[offset : offset + 4], "big", signed=True
                )
                offset += 4

                # 根据事件类型解析不同字段
                if optional.event == EVENT_ConnectionStarted:
                    # 读取 ConnectionId
                    content_size = int.from_bytes(res[offset : offset + 4], "big")
                    offset += 4
                    optional.connectionId = res[offset : offset + content_size].decode(
                        "utf8"
                    )
                    offset += content_size

                elif optional.event in [
                    EVENT_SessionStarted,
                    EVENT_SessionFailed,
                    EVENT_SessionFinished,
                ]:
                    # 读取 SessionId
                    content_size = int.from_bytes(res[offset : offset + 4], "big")
                    offset += 4
                    optional.sessionid = res[offset : offset + content_size].decode(
                        "utf8"
                    )
                    offset += content_size

                    # 读取 response_meta_json
                    if offset + 4 <= len(res):
                        content_size = int.from_bytes(res[offset : offset + 4], "big")
                        offset += 4
                        optional.response_meta_json = res[
                            offset : offset + content_size
                        ].decode("utf8")
                        offset += content_size

                elif optional.event == EVENT_TTSResponse:
                    # 读取 SessionId
                    content_size = int.from_bytes(res[offset : offset + 4], "big")
                    offset += 4
                    optional.sessionid = res[offset : offset + content_size].decode(
                        "utf8"
                    )
                    offset += content_size

                    # 读取 Payload (音频)
                    if offset + 4 <= len(res):
                        payload_size = int.from_bytes(res[offset : offset + 4], "big")
                        offset += 4
                        response.payload = res[offset : offset + payload_size]
                        offset += payload_size

        # 处理 AUDIO_ONLY_RESPONSE
        if header.message_type == AUDIO_ONLY_RESPONSE and offset + 4 <= len(res):
            if response.payload is None:
                payload_size = int.from_bytes(res[offset : offset + 4], "big")
                offset += 4
                response.payload = res[offset : offset + payload_size]

    elif header.message_type == ERROR_INFORMATION:
        if offset + 4 <= len(res):
            optional.errorCode = int.from_bytes(
                res[offset : offset + 4], "big", signed=True
            )
            offset += 4

            if offset + 4 <= len(res):
                payload_size = int.from_bytes(res[offset : offset + 4], "big")
                offset += 4
                response.payload = res[offset : offset + payload_size]

    return response


# ========== Provider 实现 ==========
class VolcengineTTSProviderV3(BaseTTS):
    """火山引擎 TTS 提供商_V3"""

    @staticmethod
    def get_volc_resource_id_by_voice(voice_id: str, concurrent: bool = False) -> str:
        """
        根据音色ID获取火山引擎资源ID
        Args:
            voice_id: 音色ID
            concurrent: 是否并发

        Returns:
            str: 资源ID
        """

        return get_volc_resource_id_by_voice(voice_id, concurrent)

    def __init__(
        self,
        appid: str,
        token: str,
        ws_url: str,
        resource_id: str = "volc.service_type.10029",
        **kwargs,
    ):
        """
        初始化火山引擎 TTS 提供商

        Args:
            appid: App ID (应用ID)
            token: Access Token (火山引擎访问令牌)
            ws_url: WebSocket URL
            resource_id: 资源ID
            **kwargs: 其他配置参数
        """
        if not WEBSOCKETS_AVAILABLE:
            raise ImportError("websockets 未安装。请运行: pip install websockets")

        super().__init__(**kwargs)
        self.appid = appid
        self.token = token
        self.ws_url = ws_url
        self.resource_id = resource_id
        self.name = "volcengine_v3"

    def get_provider_name(self) -> str:
        """获取提供商名称"""
        return self.name

    @classmethod
    def describe(cls) -> dict[str, Any]:
        """获取提供商描述信息（自描述能力）"""
        return {
            "provider_name": "volcengine_v3",
            "display_name": "火山引擎 TTS V3",
            "description": "火山引擎语音合成服务（WebSocket V3 协议）",
            "required_init_params": {
                "appid": {
                    "type": "str",
                    "description": "应用 ID",
                },
                "token": {
                    "type": "str",
                    "description": "Access Token",
                },
                "ws_url": {
                    "type": "str",
                    "description": "WebSocket URL",
                },
            },
            "optional_init_params": {
                "resource_id": {
                    "type": "str",
                    "description": "资源 ID",
                    "default": "volc.service_type.10029",
                },
            },
            "supported_methods": [
                "synthesize: 异步语音合成",
            ],
        }

    def validate_config(self) -> bool:
        """验证配置"""
        if not super().validate_config():
            return False
        if not (self.appid and self.token):
            self.logger.error("Volcengine appid 和 token 不能为空")
            return False
        if not self.ws_url:
            self.logger.error("Volcengine ws_url 不能为空")
            return False
        return True

    def validate_request(self, request: TTSSynthesizeRequest) -> None:
        """验证请求参数"""
        if not request.text:
            raise tts_exc.TTSInvalidParameterError("文本不能为空")

        # 火山引擎 TTS V3 文本长度限制：单次请求不超过 5000 字符
        # 参考: https://www.volcengine.com/docs/6561/97465
        if len(request.text) >= 5000:
            raise tts_exc.TTSTextTooLongError(
                f"文本长度 {len(request.text)} 字符超过限制，火山引擎单次合成不得超过 5000 字符"
            )

    # ========== 火山引擎 V3 特定：无需覆盖基类方法 ==========

    def _map_volcengine_error(self, error_code: int, error_msg: str) -> tuple:
        """
        映射火山引擎 V3 错误码到具体异常类型
        参考文档: https://www.volcengine.com/docs/6561/80818

        Args:
            error_code: 错误码
            error_msg: 错误消息

        Returns:
            (exception_class, formatted_message)
        """
        # 1000x: 参数相关错误
        if error_code == 10001:
            return (
                tts_exc.TTSInvalidParameterError,
                f"[错误码 10001] 缺少必要参数: {error_msg}",
            )
        if error_code == 10002:
            return (
                tts_exc.TTSInvalidParameterError,
                f"[错误码 10002] 参数格式错误: {error_msg}",
            )
        if error_code == 10003:
            return (
                tts_exc.TTSTextInvalidError,
                f"[错误码 10003] 文本内容无效: {error_msg}",
            )
        if error_code == 10004:
            return (
                tts_exc.TTSTextTooLongError,
                f"[错误码 10004] 文本长度超限: {error_msg}",
            )
        if error_code == 10005:
            return (
                tts_exc.TTSVoiceNotFoundError,
                f"[错误码 10005] 音色不存在: {error_msg}",
            )

        # 1001x-1002x: 认证相关错误
        if 10010 <= error_code <= 10029:
            return (
                tts_exc.TTSAuthenticationError,
                f"[错误码 {error_code}] 认证失败: {error_msg}",
            )

        # 1003x: 限流相关错误
        if error_code == 10030:
            return (tts_exc.TTSRateLimitError, f"[错误码 10030] QPS 超限: {error_msg}")
        if error_code == 10031:
            return (
                tts_exc.TTSConcurrencyExceededError,
                f"[错误码 10031] 并发连接数超限: {error_msg}",
            )

        # 1004x: 资源相关错误
        if 10040 <= error_code <= 10049:
            return (
                tts_exc.TTSResourceError,
                f"[错误码 {error_code}] 资源错误: {error_msg}",
            )

        # 1005x: 超时错误
        if 10050 <= error_code <= 10059:
            return (
                tts_exc.TTSTimeoutError,
                f"[错误码 {error_code}] 请求超时: {error_msg}",
            )

        # 2000x: 服务端错误
        if 20000 <= error_code <= 29999:
            return (
                tts_exc.TTSServiceUnavailableError,
                f"[错误码 {error_code}] 服务端错误: {error_msg}",
            )

        # 3000x: 网络错误
        if 30000 <= error_code <= 39999:
            return (
                tts_exc.TTSNetworkError,
                f"[错误码 {error_code}] 网络错误: {error_msg}",
            )

        # 55000000: 音色资源不匹配
        if error_code == 55000000:
            return (
                tts_exc.TTSVoiceNotFoundError,
                f"[错误码 55000000] 音色资源不匹配: {error_msg}",
            )

        # 默认：通用合成错误
        return (
            tts_exc.TTSSynthesisError,
            f"[火山引擎 V3 错误 {error_code}] {error_msg}",
        )

    async def _synthesize(self, request: TTSSynthesizeRequest, stream: bool = False):
        """内部合成实现

        - 当 ``stream=False`` 时，返回完整的 ``TTSResponse``
        - 当 ``stream=True`` 时，返回 ``AsyncIterator[TTSResponse]``，输出事件流
        """
        req_id = str(uuid.uuid4())
        duration: float | None = None

        async def _generator() -> AsyncIterator[TTSResponse]:
            nonlocal duration
            audio_data = bytearray()
            session_id = None

            try:
                # 验证请求
                self.validate_request(request)

                # 依据音色选择资源ID：优先使用传入resource_id，其次按音色映射
                concurrent = bool(request.extra_params.get("concurrent", False))
                auto_res_id = get_volc_resource_id_by_voice(
                    request.voice_id, concurrent
                )
                selected_res_id = (
                    request.extra_params.get("resource_id")
                    or auto_res_id
                    or self.resource_id
                )

                # WebSocket headers
                ws_header = {
                    "X-Api-App-Key": self.appid,
                    "X-Api-Access-Key": self.token,
                    "X-Api-Resource-Id": selected_res_id,
                    "X-Api-Connect-Id": req_id,
                }

                async with websockets.connect(
                    self.ws_url, additional_headers=ws_header, max_size=1000000000
                ) as ws:
                    # 发送 START 事件
                    yield TTSResponse(
                        status=TTSStatus.START,
                        audio_format=request.encoding.value,
                        sample_rate=request.sample_rate,
                        metadata={
                            "req_id": req_id,
                            "provider": self.name,
                            "voice_id": request.voice_id,
                        },
                    )

                    # 1. Start Connection
                    await self._start_connection(ws)
                    res = parser_response(await ws.recv())
                    if res.optional.event != EVENT_ConnectionStarted:
                        yield TTSResponse(
                            status=TTSStatus.FAILED,
                            error_message="连接失败",
                            metadata={"req_id": req_id, "provider": self.name},
                        )
                        return

                    # 2. Start Session
                    session_id = uuid.uuid4().hex
                    await self._start_session(ws, session_id, request)
                    res = parser_response(await ws.recv())
                    if res.optional.event != EVENT_SessionStarted:
                        yield TTSResponse(
                            status=TTSStatus.FAILED,
                            error_message="会话启动失败",
                            metadata={"req_id": req_id, "provider": self.name},
                        )
                        return

                    # 3. Send Text
                    await self._send_text(ws, session_id, request)

                    # 4. Finish Session
                    await self._finish_session(ws, session_id)

                    # 5. Receive Audio (流式模式下实时发送)
                    chunk_index = 0
                    while True:
                        res_bytes = await ws.recv()
                        res = parser_response(res_bytes)
                        # V3版本没有V1版本类似的时间轴信息
                        if (
                            res.optional.event == EVENT_TTSResponse
                            and res.header.message_type == AUDIO_ONLY_RESPONSE
                        ):
                            if res.payload:
                                audio_data.extend(res.payload)

                                # 流式模式下发送 PARTIAL 事件
                                if stream:
                                    yield TTSResponse(
                                        status=TTSStatus.PARTIAL,
                                        audio_data=res.payload,
                                        duration=duration,
                                        audio_format=request.encoding.value,
                                        sample_rate=request.sample_rate,
                                        metadata={
                                            "req_id": req_id,
                                            "chunk_index": chunk_index,
                                            "provider": self.name,
                                            "voice_id": request.voice_id,
                                        },
                                    )
                                    chunk_index += 1

                        elif res.optional.event == EVENT_SessionFinished:
                            self.logger.debug("会话结束")
                            break

                        elif res.optional.event == EVENT_SessionFailed:
                            error_msg = res.optional.response_meta_json or "未知错误"
                            # 尝试解析错误信息获取错误码
                            error_code = 0
                            try:
                                error_data = (
                                    json.loads(error_msg)
                                    if error_msg.startswith("{")
                                    else {}
                                )
                                error_code = error_data.get("code", 0)
                            except (json.JSONDecodeError, AttributeError):
                                pass

                            # 使用错误映射
                            if error_code:
                                exc_class, exc_msg = self._map_volcengine_error(
                                    error_code, error_msg
                                )
                                raise exc_class(exc_msg)

                            yield TTSResponse(
                                status=TTSStatus.FAILED,
                                error_message=f"会话失败: {error_msg}",
                                metadata={"req_id": req_id, "provider": self.name},
                            )
                            return

                        elif res.header.message_type == ERROR_INFORMATION:
                            error_desc = (
                                res.payload.decode("utf-8")
                                if res.payload
                                else "未知错误"
                            )
                            # 使用错误映射
                            if res.optional.errorCode:
                                exc_class, exc_msg = self._map_volcengine_error(
                                    res.optional.errorCode, error_desc
                                )
                                raise exc_class(exc_msg)

                            yield TTSResponse(
                                status=TTSStatus.FAILED,
                                error_message=f"错误码: {res.optional.errorCode}, 描述: {error_desc}",
                                metadata={"req_id": req_id, "provider": self.name},
                            )
                            return

                    # 6. Finish Connection
                    await self._finish_connection(ws)
                    await ws.recv()  # 接收最后响应

                if not audio_data:
                    yield TTSResponse(
                        status=TTSStatus.FAILED,
                        error_message="音频数据为空",
                        metadata={"req_id": req_id, "provider": self.name},
                    )
                    return

                # 处理最终音频数据
                sample_rate = request.sample_rate
                duration = len(audio_data) / (sample_rate * 2) if sample_rate else 0

                final_audio_data = bytes(audio_data)
                output_format = request.encoding.value

                # 仅 WAV 格式需要转换（API 返回的是 PCM）
                if request.encoding == AudioEncoding.WAV:
                    final_audio_data = pcm_to_wav(final_audio_data, sample_rate)
                    self.logger.debug("已将 PCM 转换为 WAV 格式")

                # 发送 SUCCESS 事件
                yield TTSResponse(
                    status=TTSStatus.SUCCESS,
                    audio_data=None if stream else final_audio_data,
                    duration=duration,
                    audio_format=output_format,
                    sample_rate=sample_rate,
                    metadata={
                        "req_id": req_id,
                        "provider": self.name,
                        "voice_id": request.voice_id,
                    },
                )

            except tts_exc.TTSException:
                # TTS 相关异常直接抛出，不包装
                raise
            except Exception as e:
                yield TTSResponse(
                    status=TTSStatus.FAILED,
                    error_message=f"处理过程中发生错误: {e!s}",
                    metadata={"req_id": req_id, "provider": self.name},
                )

        # 流式：直接把内部 async generator 返回给调用方
        if stream:
            return _generator()

        # 非流式：消费事件流，返回最终 SUCCESS/FAILED 事件
        last_event: TTSResponse | None = None
        async for event in _generator():
            last_event = event
        if last_event is None:
            return TTSResponse(
                status=TTSStatus.FAILED,
                error_message="No events received",
                metadata={"req_id": req_id, "provider": self.name},
            )
        return last_event

    async def _synthesize_impl(self, request: TTSSynthesizeRequest) -> TTSResponse:
        """非流式合成的核心实现（不含缓存逻辑）"""
        result = await self._synthesize(request, stream=False)
        assert isinstance(result, TTSResponse)
        return result

    async def synthesize(self, request: TTSSynthesizeRequest) -> TTSResponse:
        """
        非流式接口：直接返回完整音频（支持可选缓存与重置缓存）

        使用方式：
        - Provider 级默认：
            * default_use_cache: 是否默认启用缓存（bool，默认 False）
            * default_cache_ttl: 默认缓存 TTL（float，默认 3600）
        - 请求级覆盖（优先级更高，通过 TTSSynthesizeRequest 顶层字段）：
            * use_cache: Optional[bool] - 本次请求是否使用缓存
            * reset_cache: bool - 是否重置缓存（删除旧缓存后重新生成）
            * cache_ttl: Optional[float] - 本次请求的 TTL
        """
        return await self._run_with_cache_policy_async(
            request=request,
            compute=lambda: self._synthesize_impl(request),
        )

    def synthesize_sync(self, request: TTSSynthesizeRequest) -> TTSResponse:
        """
        同步语音合成（封装异步实现）

        Args:
            request: 合成请求参数

        Returns:
            TTSResponse: 合成结果
        """
        try:
            # 尝试获取当前事件循环
            asyncio.get_running_loop()
        except RuntimeError:
            # 没有运行中的事件循环，创建新的
            return asyncio.run(self.synthesize(request))
        else:
            # 已有运行中的事件循环，使用 run_in_executor
            with concurrent.futures.ThreadPoolExecutor() as executor:
                future = executor.submit(asyncio.run, self.synthesize(request))
                return future.result()

    async def synthesize_stream(
        self, request: TTSSynthesizeRequest
    ) -> AsyncIterator[TTSResponse]:
        """流式接口：返回事件流"""
        stream_iter = await self._synthesize(request, stream=True)
        # 为了类型友好，这里再包装一层 async generator
        async for event in stream_iter:
            yield event

    async def _start_connection(self, ws: ClientConnection):
        """发送 Start Connection 事件"""
        header = Header(
            message_type=FULL_CLIENT_REQUEST,
            message_type_specific_flags=MsgTypeFlagWithEvent,
        ).as_bytes()
        optional = Optional(event=EVENT_Start_Connection).as_bytes()
        payload = str.encode("{}")
        await send_event(ws, header, optional, payload)

    async def _start_session(
        self, ws: ClientConnection, session_id: str, request: TTSSynthesizeRequest
    ):
        """发送 Start Session 事件

        注意：WAV 格式请求 pcm，避免流式场景下多次返回 wav header 的问题
        其他格式（mp3/pcm/ogg）直接请求原格式
        """
        header = Header(
            message_type=FULL_CLIENT_REQUEST,
            message_type_specific_flags=MsgTypeFlagWithEvent,
            serial_method=JSON,
        ).as_bytes()
        optional = Optional(event=EVENT_StartSession, sessionid=session_id).as_bytes()

        # WAV 格式请求 pcm 后转换，其他格式直接请求
        if request.encoding == AudioEncoding.WAV:
            api_format = "pcm"
        else:
            api_format = request.encoding.value

        payload = get_payload_bytes(
            event=EVENT_StartSession,
            speaker=request.voice_id,
            audio_format=api_format,
            audio_sample_rate=request.sample_rate,
            voice_speech_rate=request.speed,
            voice_loudness_rate=request.volume,
            voice_pitch=request.pitch,
            emotion_scale=request.extra_params.get("emotion_scale"),
            context_texts=request.extra_params.get("context_texts"),
        )
        self.logger.debug(f"发送 Start Session 事件: {payload}")
        await send_event(ws, header, optional, payload)

    async def _send_text(
        self, ws: ClientConnection, session_id: str, request: TTSSynthesizeRequest
    ):
        """发送文本"""
        header = Header(
            message_type=FULL_CLIENT_REQUEST,
            message_type_specific_flags=MsgTypeFlagWithEvent,
            serial_method=JSON,
        ).as_bytes()
        optional = Optional(event=EVENT_TaskRequest, sessionid=session_id).as_bytes()
        payload = get_payload_bytes(
            event=EVENT_TaskRequest, text=request.text, speaker=request.voice_id
        )
        await send_event(ws, header, optional, payload)

    async def _finish_session(self, ws: ClientConnection, session_id: str):
        """发送 Finish Session 事件"""
        header = Header(
            message_type=FULL_CLIENT_REQUEST,
            message_type_specific_flags=MsgTypeFlagWithEvent,
            serial_method=JSON,
        ).as_bytes()
        optional = Optional(event=EVENT_FinishSession, sessionid=session_id).as_bytes()
        payload = str.encode("{}")
        await send_event(ws, header, optional, payload)

    async def _finish_connection(self, ws: ClientConnection):
        """发送 Finish Connection 事件"""
        header = Header(
            message_type=FULL_CLIENT_REQUEST,
            message_type_specific_flags=MsgTypeFlagWithEvent,
            serial_method=JSON,
        ).as_bytes()
        optional = Optional(event=EVENT_FinishConnection).as_bytes()
        payload = str.encode("{}")
        await send_event(ws, header, optional, payload)
