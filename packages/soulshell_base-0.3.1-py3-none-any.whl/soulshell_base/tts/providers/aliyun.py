"""
阿里云 TTS 提供商实现
文档: https://help.aliyun.com/zh/isi/developer-reference/sdk-for-python-1
"""

import asyncio
import json
import threading
import time
from typing import Any, Dict, Optional

try:
    import nls

    NLS_AVAILABLE = True
except ImportError:
    NLS_AVAILABLE = False
    nls = None

try:
    from aliyunsdkcore.client import AcsClient
    from aliyunsdkcore.request import CommonRequest

    ALIYUN_SDK_AVAILABLE = True
except ImportError:
    ALIYUN_SDK_AVAILABLE = False
    AcsClient = None
    CommonRequest = None

from soulshell_base.core import RuntimeStateManager, get_logger

from .. import exceptions as tts_exc
from ..base import BaseTTS
from ..models import AudioEncoding, TTSResponse, TTSSynthesizeRequest

logger = get_logger(__name__)


class AliyunTTSProvider(BaseTTS):
    """阿里云 TTS 提供商 - 使用 WebSocket 方式"""

    def __init__(
        self,
        appkey: str,
        ak: str,
        sk: str,
        endpoint: str = "nls-gateway.aliyuncs.com",
        region_id: str = "cn-shanghai",
        **kwargs,
    ):
        """
        初始化阿里云 TTS 提供商

        Args:
            appkey: 应用密钥 (从阿里云控制台获取)
            ak: AccessKey ID
            sk: AccessKey Secret
            endpoint: WebSocket 网关地址
            region_id: 区域 ID
            **kwargs: 其他配置参数
            default_use_cache: 是否默认启用缓存（bool，默认 False）
            default_cache_ttl: 默认缓存 TTL（float，默认 -1表示永久缓存）
        """
        if not NLS_AVAILABLE:
            raise ImportError(
                "需要安装 nls SDK 才能使用阿里云 TTS。"
                "请运行: pip install alibabacloud-nls-python-sdk"
            )

        if not ALIYUN_SDK_AVAILABLE:
            raise ImportError(
                "需要安装 aliyunsdkcore 才能使用阿里云 TTS。"
                "请运行: pip install aliyun-python-sdk-core"
            )

        super().__init__(**kwargs)

        self.appkey = appkey
        self.ak = ak
        self.sk = sk
        self.endpoint = endpoint
        self.region_id = region_id

        # Token 相关配置
        self.token_domain = kwargs.get(
            "token_domain", f"nls-meta.{region_id}.aliyuncs.com"
        )
        self.token_version = kwargs.get("token_version", "2019-02-28")

        # 默认音色配置
        self.default_voice = kwargs.get("default_voice", "xiaoyun")

        # 使用 RuntimeStateManager 进行 token 持久化
        self.state_manager = RuntimeStateManager.get_instance()
        self.module_name = "tts_aliyun"

        self.logger.info(
            f"初始化阿里云 TTS: endpoint={self.endpoint}, region_id={self.region_id}"
        )

    def get_provider_name(self) -> str:
        """获取提供商名称"""
        return "aliyun"

    @classmethod
    def describe(cls) -> Dict[str, Any]:
        """获取提供商描述信息"""
        return {
            "provider_name": "aliyun",
            "display_name": "阿里云 TTS",
            "description": "阿里云语音合成服务（使用 WebSocket 方式）",
            "required_init_params": {
                "appkey": {
                    "type": "str",
                    "description": "应用密钥（从阿里云控制台获取）",
                    "env_var": "TTS_ALIYUN_APPKEY",
                },
                "ak": {
                    "type": "str",
                    "description": "AccessKey ID",
                    "env_var": "TTS_ALIYUN_AK",
                },
                "sk": {
                    "type": "str",
                    "description": "AccessKey Secret",
                    "env_var": "TTS_ALIYUN_SK",
                },
            },
            "optional_init_params": {
                "endpoint": {
                    "type": "str",
                    "description": "WebSocket 网关地址",
                    "default": "nls-gateway.aliyuncs.com",
                },
                "region_id": {
                    "type": "str",
                    "description": "区域 ID",
                    "default": "cn-shanghai",
                },
                "default_voice": {
                    "type": "str",
                    "description": "默认音色",
                    "default": "xiaoyun",
                },
                "default_use_cache": {
                    "type": "bool",
                    "description": "是否默认启用缓存",
                    "default": False,
                },
                "default_cache_ttl": {
                    "type": "float",
                    "description": "默认缓存 TTL（秒，-1 表示永久）",
                    "default": -1,
                },
            },
            "supported_features": [
                "同步合成（synthesize_sync）",
                "异步合成（synthesize）",
                "缓存支持",
                "多种音频格式（MP3/WAV/PCM）",
                "语速/音调/音量调节",
                "字级别时间戳（通过 ex 参数）",
            ],
            "example": {
                "appkey": "your-appkey",
                "ak": "your-access-key-id",
                "sk": "your-access-key-secret",
                "endpoint": "nls-gateway.aliyuncs.com",
                "region_id": "cn-shanghai",
                "default_voice": "xiaoyun",
                "default_use_cache": True,
                "default_cache_ttl": 3600,
            },
        }

    def validate_config(self) -> bool:
        """验证配置"""
        if not self.appkey:
            self.logger.error("缺少 appkey")
            return False
        if not self.ak:
            self.logger.error("缺少 ak (AccessKey ID)")
            return False
        if not self.sk:
            self.logger.error("缺少 sk (AccessKey Secret)")
            return False
        return True

    # ========== 缓存辅助方法（仅供本 provider 使用） ==========

    # ========== 阿里云特定：覆盖缓存键构建（支持 ex 参数） ==========

    def _build_cache_key_payload(self, request: TTSSynthesizeRequest) -> dict:
        """构建缓存键负载（阿里云特定：支持 ex 参数）"""
        payload = super()._build_cache_key_payload(request)

        # 添加阿里云特定的 ex 参数
        ex = request.extra_params.get("ex")
        if ex is not None:
            payload["ex"] = ex

        return payload

    def validate_request(self, request: TTSSynthesizeRequest) -> None:
        """验证请求参数"""
        if not request.text:
            raise tts_exc.TTSInvalidParameterError("文本不能为空")

        # 阿里云 TTS 文本长度限制（短文本模式最大 300 字符，长文本模式更多）
        if len(request.text) > 2000:
            raise tts_exc.TTSTextTooLongError("合成文本长度不能超过 2000 字符")

        # 如果没有指定 voice_id，使用默认音色
        if not request.voice_id:
            request.voice_id = self.default_voice

    def _ensure_token(self) -> str:
        """确保有效的 token，如果过期则刷新（使用持久化缓存）"""
        # 尝试从持久化缓存获取 token
        cached_token = self.state_manager.get_state(
            self.module_name, f"{self.appkey}_token", default=""
        )

        if cached_token:
            self.logger.debug(f"使用持久化缓存的 token: {cached_token[:20]}...")
            return cached_token

        # 缓存中没有 token 或已过期，从 API 获取新 token
        self.logger.info("持久化缓存中没有有效 token，从 API 获取新 token")

        try:
            client = AcsClient(self.ak, self.sk, self.region_id)
            req = CommonRequest()
            req.set_method("POST")
            req.set_domain(self.token_domain)
            req.set_version(self.token_version)
            req.set_action_name("CreateToken")
            resp = client.do_action_with_exception(req)

            self.logger.debug(f"阿里云 token API 响应: {resp}")

            data = json.loads(resp)
            token = data.get("Token", {}).get("Id", "")
            expire = float(data.get("Token", {}).get("ExpireTime", 0))

            if token and expire > 0:
                # 计算 TTL（提前 1 小时过期以确保安全）
                ttl = int(expire - time.time() - 3600)
                if ttl > 0:
                    # 保存到持久化缓存
                    self.state_manager.set_state(
                        self.module_name, f"{self.appkey}_token", token, ttl=ttl
                    )
                    self.logger.info(
                        f"新 token 已保存到持久化缓存，TTL: {ttl}秒 (~{ttl / 3600:.1f}小时)"
                    )
                else:
                    self.logger.warning(f"Token 即将过期，TTL={ttl}，不进行缓存")
                return token

            self.logger.error(f"阿里云 token 刷新失败: {resp}")

        except Exception as e:
            self.logger.error(f"刷新阿里云 token 失败: {e}")

        return ""

    def _convert_params(self, request: TTSSynthesizeRequest) -> dict:
        """
        转换参数范围

        框架标准范围 -> 阿里云范围:
        - speed: 0.1~2.0 -> speech_rate: -500~500
        - pitch: -12~12 -> pitch_rate: -500~500
        - volume: 0.1~2.0 -> volume: 0~100
        """
        # speed: 0.1~2.0 -> speech_rate: -500~500
        # 公式: (speed - 1) * 500，兜底到 [-500, 500]
        speech_rate = int((request.speed - 1) * 500)
        speech_rate = max(-500, min(500, speech_rate))

        # pitch: -12~12 -> pitch_rate: -500~500
        # 公式: (pitch / 12) * 500，兜底到 [-500, 500]
        pitch_rate = int((request.pitch / 12) * 500)
        pitch_rate = max(-500, min(500, pitch_rate))

        # volume: 0.1~2.0 -> volume: 0~100
        # 公式: volume * 50，兜底到 [0, 100]
        volume = int(request.volume * 50)
        volume = max(0, min(100, volume))

        # encoding -> aformat
        format_map = {
            AudioEncoding.MP3: "mp3",
            AudioEncoding.WAV: "wav",
            AudioEncoding.PCM: "pcm",
        }
        aformat = format_map.get(request.encoding, "mp3")

        return {
            "voice": request.voice_id,
            "aformat": aformat,
            "sample_rate": request.sample_rate,
            "speech_rate": speech_rate,
            "pitch_rate": pitch_rate,
            "volume": volume,
        }

    def _parse_error_to_exception_info(self, error_msg: str) -> tuple:
        """
        解析阿里云错误消息，返回异常类型和错误消息
        基于官方文档: https://help.aliyun.com/zh/isi/developer-reference/sdk-reference-11

        Args:
            error_msg: 错误消息JSON字符串

        Returns:
            (exception_class, formatted_message)
        """
        try:
            error_data = json.loads(error_msg) if error_msg.startswith("{") else {}
            status_code = str(error_data.get("header", {}).get("status", ""))
            status_text = error_data.get("header", {}).get("status_text", "")

            # 组合错误信息用于日志
            error_detail = (
                f"[阿里云错误 {status_code}] {status_text}"
                if status_code
                else status_text
            )

            # 418: 音色不存在
            if "418" in status_code or "418" in status_text:
                return (
                    tts_exc.TTSVoiceNotFoundError,
                    f"[错误码 418] 音色不存在: {status_text}",
                )

            # 413: SSML格式错误
            if "413" in status_code:
                return (
                    tts_exc.TTSResourceError,
                    f"[错误码 413] SSML格式错误: {status_text}",
                )

            # 424: 背景音乐格式错误
            if "424" in status_code:
                return (
                    tts_exc.TTSResourceError,
                    f"[错误码 424] 背景音乐格式错误: {status_text}",
                )

            # 文本过长
            if "length should be less than" in status_text.lower():
                return (tts_exc.TTSTextTooLongError, f"文本长度超限: {status_text}")

            # 40000001: Token过期/无效
            if status_code == "40000001" or (
                "token" in status_text.lower()
                and (
                    "expired" in status_text.lower() or "invalid" in status_text.lower()
                )
            ):
                return (
                    tts_exc.TTSAuthenticationError,
                    f"[错误码 40000001] Token过期或无效: {status_text}",
                )

            # 40000005: 并发限流
            if status_code == "40000005":
                return (
                    tts_exc.TTSConcurrencyExceededError,
                    f"[错误码 40000005] 并发连接数超限: {status_text}",
                )

            # 40000010: 试用期结束
            if status_code == "40000010":
                return (
                    tts_exc.TTSAuthenticationError,
                    f"[错误码 40000010] 试用期已结束: {status_text}",
                )

            # 40010003: 无有效文本
            if status_code == "40010003" or "no text specified" in status_text.lower():
                return (
                    tts_exc.TTSTextInvalidError,
                    f"[错误码 40010003] 未设置有效文本: {status_text}",
                )

            # QPS限流相关
            if (
                "qps" in status_text.lower()
                or "rate limit" in status_text.lower()
                or "too many requests" in status_text.lower()
            ):
                return (tts_exc.TTSRateLimitError, f"请求频率超限: {status_text}")

            # 超时相关
            if "timeout" in status_text.lower() or "timed out" in status_text.lower():
                return (tts_exc.TTSTimeoutError, f"请求超时: {status_text}")

            # 网络错误
            if "connection" in status_text.lower() or "network" in status_text.lower():
                return (tts_exc.TTSNetworkError, f"网络错误: {status_text}")

            # 5xxx: 服务端错误
            if status_code and status_code.startswith("5"):
                return (
                    tts_exc.TTSServiceUnavailableError,
                    f"[错误码 {status_code}] 服务不可用: {status_text}",
                )

            # 4xxx: 客户端参数错误
            if (
                status_code
                and status_code.startswith("4")
                and status_code not in ["418", "413", "424"]
            ):
                return (
                    tts_exc.TTSInvalidParameterError,
                    f"[错误码 {status_code}] 参数错误: {status_text}",
                )

            # 默认
            return (tts_exc.TTSSynthesisError, error_detail or error_msg)

        except (json.JSONDecodeError, KeyError, AttributeError):
            return (tts_exc.TTSSynthesisError, f"阿里云错误: {error_msg}")

    def _synthesize_async_impl(self, request: TTSSynthesizeRequest) -> TTSResponse:
        """异步合成的核心实现（不含缓存逻辑）"""
        # 状态变量
        audio_data = bytearray()
        error_msg: Optional[str] = None
        completed = threading.Event()

        # 回调函数
        def on_metainfo(message: str, *_):
            """元信息回调"""
            self.logger.info(f"阿里云 TTS 元信息: {message}")

        def on_data(data: bytes, *_):
            """音频数据回调"""
            if data:
                audio_data.extend(data)

        def on_completed(message: str, *_):
            """合成完成回调"""
            self.logger.info(f"阿里云 TTS 合成完成: {message} {_}")
            completed.set()

        def on_error(message: str, *_):
            """错误回调"""
            nonlocal error_msg
            error_msg = message
            # 解析错误并记录详细信息
            try:
                _exc_class, exc_msg = self._parse_error_to_exception_info(message)
                self.logger.error(f"阿里云 TTS 错误: {exc_msg}")
            except Exception as e:
                self.logger.error(
                    f"阿里云 TTS 错误（解析失败）: {message}, 解析异常: {e}"
                )
            completed.set()

        def on_close(*_):
            """连接关闭回调"""
            self.logger.debug("阿里云 TTS 连接关闭")
            completed.set()

        # 获取 token
        token = self._ensure_token()
        if not token:
            return TTSResponse.failed("获取阿里云 token 失败")

        # 创建 TTS 实例
        url = f"wss://{self.endpoint}/ws/v1"
        tts = nls.NlsSpeechSynthesizer(
            url=url,
            token=token,
            appkey=self.appkey,
            on_metainfo=on_metainfo,
            on_data=on_data,
            on_completed=on_completed,
            on_error=on_error,
            on_close=on_close,
        )

        # 转换参数
        params = self._convert_params(request)

        # 添加额外参数（如 ex 字级别时间戳等）
        ex = request.extra_params.get("ex")
        if ex is not None:
            params["ex"] = ex

        try:
            self.logger.debug(
                f"阿里云 TTS 开始合成:params={json.dumps(params, ensure_ascii=False)}"
            )
            tts.start(request.text, **params)
        except Exception as e:
            error_msg = str(e)
            completed.set()

        # 等待完成（带超时）
        timeout = request.extra_params.get("timeout", 30)
        if not completed.wait(timeout=timeout):
            return TTSResponse.failed(f"合成超时 ({timeout}秒)")

        # 清理资源
        try:
            tts.shutdown()
        except Exception as e:
            self.logger.warning(f"清理 TTS 资源时出错: {e}")

        # 处理结果 - 解析错误并抛出异常
        if error_msg:
            exc_class, exc_msg = self._parse_error_to_exception_info(error_msg)
            raise exc_class(exc_msg)

        if not audio_data:
            return TTSResponse.failed("音频数据为空")

        # 估算时长
        sample_rate = request.sample_rate
        bits_per_sample = 16
        channels = 1

        # 根据格式估算时长
        if request.encoding == AudioEncoding.PCM:
            duration = len(audio_data) / (sample_rate * bits_per_sample / 8 * channels)
        else:
            # MP3/WAV 等压缩格式，时长估算不准确，设为 None
            duration = None

        self.logger.info(
            f"阿里云 TTS 合成成功，文本长度: {len(request.text)}, "
            f"音频大小: {len(audio_data)} bytes, 格式: {request.encoding.value}"
        )

        return TTSResponse.success(
            audio_data=bytes(audio_data),
            duration=duration,
            audio_format=request.encoding.value,
            sample_rate=sample_rate,
            metadata={
                "provider": "aliyun",
                "voice_id": request.voice_id,
                "text_length": len(request.text),
            },
        )

    async def synthesize(self, request: TTSSynthesizeRequest) -> TTSResponse:
        """
        异步语音合成（支持可选缓存与重置缓存）

        Args:
            request: 合成请求参数

        Returns:
            TTSResponse: 合成结果
        """
        # 使用同步方法在线程池中执行
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self.synthesize_sync, request)

    def _synthesize_sync_impl(self, request: TTSSynthesizeRequest) -> TTSResponse:
        """同步合成的核心实现（不含缓存逻辑）"""
        # 状态变量
        audio_data = bytearray()
        error_msg: Optional[str] = None
        completed = threading.Event()

        # 回调函数
        def on_data(data: bytes, *_):
            if data:
                audio_data.extend(data)

        def on_completed(message: str, *_):
            self.logger.info(f"阿里云 TTS 合成完成: {message}")
            completed.set()

        def on_error(message: str, *_):
            """错误回调 - 解析错误并记录详细信息"""
            nonlocal error_msg
            error_msg = message
            # 解析错误并记录详细信息
            try:
                _exc_class, exc_msg = self._parse_error_to_exception_info(message)
                self.logger.error(f"阿里云 TTS 错误: {exc_msg}")
            except Exception as e:
                self.logger.error(
                    f"阿里云 TTS 错误（解析失败）: {message}, 解析异常: {e}"
                )
            completed.set()

        def on_close(*_):
            completed.set()

        # 获取 token
        token = self._ensure_token()
        if not token:
            return TTSResponse.failed("获取阿里云 token 失败")

        # 创建 TTS 实例
        url = f"wss://{self.endpoint}/ws/v1"
        tts = nls.NlsSpeechSynthesizer(
            url=url,
            token=token,
            appkey=self.appkey,
            on_data=on_data,
            on_completed=on_completed,
            on_error=on_error,
            on_close=on_close,
        )

        # 转换参数并启动合成
        params = self._convert_params(request)
        tts.start(request.text, **params)

        # 等待完成
        timeout = request.extra_params.get("timeout", 30)
        if not completed.wait(timeout=timeout):
            return TTSResponse.failed(f"合成超时 ({timeout}秒)")

        # 清理
        try:
            tts.shutdown()
        except Exception:
            pass

        # 处理结果
        if error_msg:
            exc_class, exc_msg = self._parse_error_to_exception_info(error_msg)
            raise exc_class(exc_msg)

        if not audio_data:
            return TTSResponse.failed("音频数据为空")

        return TTSResponse.success(
            audio_data=bytes(audio_data),
            audio_format=request.encoding.value,
            sample_rate=request.sample_rate,
            metadata={
                "provider": "aliyun",
                "voice_id": request.voice_id,
            },
        )

    def synthesize_sync(self, request: TTSSynthesizeRequest) -> TTSResponse:
        """
        同步语音合成（支持可选缓存与重置缓存）

        Args:
            request: 合成请求参数

        Returns:
            TTSResponse: 合成结果
        使用方式：
        - Provider 级默认：
            * default_use_cache: 是否默认启用缓存（bool，默认 False）
            * default_cache_ttl: 默认缓存 TTL（float，默认 -1表示永久缓存）
        - 请求级覆盖（优先级更高，通过 TTSSynthesizeRequest 顶层字段）：
            * use_cache: Optional[bool] - 本次请求是否使用缓存
            * reset_cache: bool - 是否重置缓存（删除旧缓存后重新生成）
            * cache_ttl: Optional[float] - 本次请求的 TTL
        """
        return self._run_with_cache_policy_sync(
            request=request,
            compute=lambda: self._synthesize_sync_impl(request),
        )
