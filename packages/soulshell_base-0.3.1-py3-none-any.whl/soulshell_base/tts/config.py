"""
TTS 配置管理
支持从环境变量、配置文件等加载配置
"""

from dataclasses import dataclass, field
import os
from typing import Any, Dict, Optional

from soulshell_base.core import get_logger

logger = get_logger(__name__, level="DEBUG")


@dataclass
class TTSProviderConfig:
    """TTS 提供商配置"""

    provider_name: str
    extra_params: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_env(cls, provider_name: str, prefix: str = "TTS") -> "TTSProviderConfig":
        """
        从环境变量加载配置

        Args:
            provider_name: 提供商名称
            prefix: 环境变量前缀

        Returns:
            TTSProviderConfig: 配置对象

        Example:
            # 环境变量: TTS_VOLCENGINE_V1_ENDPOINT
            config = TTSProviderConfig.from_env("volcengine_v1")
        """
        env_prefix = f"{prefix}_{provider_name.upper()}_"

        # 收集其他以该前缀开头的环境变量
        extra_params = {}
        for key, value in os.environ.items():
            if key.startswith(env_prefix):
                # 移除前缀并转为小写
                param_key = key[len(env_prefix) :].lower()
                extra_params[param_key] = value

        logger.debug(f"从环境变量加载 {provider_name} 配置: {extra_params}")
        return cls(
            provider_name=provider_name,
            extra_params=extra_params,
        )

    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> "TTSProviderConfig":
        """
        从字典加载配置

        Args:
            config_dict: 配置字典

        Returns:
            TTSProviderConfig: 配置对象
        """
        provider_name = config_dict.get("provider_name")

        if not provider_name:
            raise ValueError("配置字典必须包含 provider_name")

        # 其他参数都作为 extra_params（例如 appid、endpoint、ws_url 等）
        extra_params = {
            k: v for k, v in config_dict.items() if k not in ["provider_name"]
        }

        return cls(
            provider_name=provider_name,
            extra_params=extra_params,
        )

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        result = {"provider_name": self.provider_name}
        result.update(self.extra_params)
        return result


class TTSConfigManager:
    """TTS 配置管理器"""

    def __init__(self):
        self._configs: Dict[str, TTSProviderConfig] = {}

    def add_config(self, provider_name: str, config: TTSProviderConfig) -> None:
        """
        添加配置

        Args:
            provider_name: 提供商名称
            config: 配置对象
        """
        self._configs[provider_name] = config
        logger.info(f"添加 {provider_name} 配置")

    def get_config(self, provider_name: str) -> Optional[TTSProviderConfig]:
        """
        获取配置

        Args:
            provider_name: 提供商名称

        Returns:
            Optional[TTSProviderConfig]: 配置对象，如果不存在返回 None
        """
        return self._configs.get(provider_name)

    def load_from_env(self, provider_name: str, prefix: str = "TTS") -> None:
        """
        从环境变量加载配置

        Args:
            provider_name: 提供商名称
            prefix: 环境变量前缀
        """
        config = TTSProviderConfig.from_env(provider_name, prefix)
        self.add_config(provider_name, config)

    def has_config(self, provider_name: str) -> bool:
        """
        检查是否有指定提供商的配置

        Args:
            provider_name: 提供商名称

        Returns:
            bool: 是否存在配置
        """
        return provider_name in self._configs
