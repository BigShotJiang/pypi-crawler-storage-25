"""
TTS 工厂类
"""

from typing import Any, ClassVar, Dict, List, Tuple, Type

from soulshell_base.core import get_logger

from .base import BaseTTS
from .exceptions import TTSProviderNotFoundError

logger = get_logger(__name__)


class TTSFactory:
    """TTS 工厂类 - 支持延迟加载提供商"""

    # 提供商映射：名称 -> (模块路径, 类名)
    _PROVIDER_MAP: ClassVar[Dict[str, Tuple[str, str]]] = {
        "azure": ("soulshell_base.tts.providers.azure", "AzureTTSProvider"),
        "volcengine_v3": (
            "soulshell_base.tts.providers.volcengine_v3",
            "VolcengineTTSProviderV3",
        ),
        "volcengine_v1": (
            "soulshell_base.tts.providers.volcengine_v1.volcengine_v1",
            "VolcengineTTSProviderV1",
        ),
        "aliyun": (
            "soulshell_base.tts.providers.aliyun",
            "AliyunTTSProvider",
        ),
        "xunfei": (
            "soulshell_base.tts.providers.xunfei",
            "XunFeiTTSProvider",
        ),
    }

    # 依赖提示信息
    _DEPENDENCY_HINTS: ClassVar[Dict[str, str]] = {
        "azure": "azure-cognitiveservices-speech (安装: pip install azure-cognitiveservices-speech 或 uv sync --extra tts-azure)",
        "volcengine_v3": "websockets (安装: pip install websockets 或 uv sync --extra tts-volcengine_v3)",
        "volcengine_v1": "websockets (安装: pip install websockets 或 uv sync --extra tts-volcengine_v1)",
        "aliyun": "alibabacloud-nls-python-sdk (安装: pip install alibabacloud-nls-python-sdk 或 uv sync --extra tts-aliyun)",
        "xunfei": "websocket-client (安装: pip install websocket-client 或 uv sync --extra tts-xunfei)",
    }

    _providers: ClassVar[Dict[str, Type[BaseTTS]]] = {}

    @classmethod
    def register(cls, name: str, provider_class: Type[BaseTTS]) -> None:
        """
        注册 TTS 提供商

        Args:
            name: 提供商名称
            provider_class: 提供商类

        Raises:
            TypeError: 如果 provider_class 不是 BaseTTS 的子类
        """
        if not issubclass(provider_class, BaseTTS):
            raise TypeError(f"{provider_class} 必须继承自 BaseTTS")
        cls._providers[name] = provider_class
        logger.debug(f"已注册 TTS 提供商: {name}")

    @classmethod
    def unregister(cls, name: str) -> None:
        """
        取消注册 TTS 提供商

        Args:
            name: 提供商名称
        """
        if name in cls._providers:
            del cls._providers[name]
            logger.debug(f"已取消注册 TTS 提供商: {name}")

    @classmethod
    def get_providers(cls) -> List[str]:
        """
        获取已注册的提供商列表

        Returns:
            list[str]: 提供商名称列表
        """
        return list(cls._providers.keys())

    @classmethod
    def list_available_providers(cls) -> List[str]:
        """
        列出所有可用的提供商（包括未加载的）

        Returns:
            list[str]: 提供商名称列表
        """
        return list(cls._PROVIDER_MAP.keys())

    @classmethod
    def describe(cls, provider_name: str) -> Dict[str, Any]:
        """获取提供商描述信息（自描述能力）

        Args:
            provider_name: 提供商名称

        Returns:
            包含必填/可选参数、示例的描述信息

        Raises:
            TTSProviderNotFoundError: 提供商不存在

        Example:
            >>> from soulshell_base.tts import TTSFactory
            >>> info = TTSFactory.describe("aliyun")
            >>> print(info['required_init_params'])
            {'appkey': {'type': 'str', 'description': '应用密钥', ...}}
        """
        if provider_name not in cls._PROVIDER_MAP:
            available = cls.list_available_providers()
            raise TTSProviderNotFoundError(
                f"未知的 TTS 提供商: {provider_name}. 可用提供商: {available}"
            )

        # 延迟加载 Provider 类
        if provider_name not in cls._providers:
            cls._lazy_load_provider(provider_name)

        provider_class = cls._providers[provider_name]
        return provider_class.describe()

    @classmethod
    def _lazy_load_provider(cls, provider_name: str) -> None:
        """
        延迟加载提供商

        Args:
            provider_name: 提供商名称
        """
        if provider_name not in cls._PROVIDER_MAP:
            raise TTSProviderNotFoundError(
                f"未找到 TTS 提供商: {provider_name}. 可用提供商: {list(cls._PROVIDER_MAP.keys())}"
            )

        module_path, class_name = cls._PROVIDER_MAP[provider_name]
        try:
            module = __import__(module_path, fromlist=[class_name])
        except ImportError as e:
            raise ImportError(
                f"缺少必要的依赖包：{cls._DEPENDENCY_HINTS.get(provider_name, '未知')}. "
                f"详细错误信息：{e}"
            )

        provider_class = getattr(module, class_name)
        cls._providers[provider_name] = provider_class
        logger.debug(f"成功延迟加载 TTS 提供商: {provider_name}")

    @classmethod
    def create(cls, provider_name: str, **kwargs) -> BaseTTS:
        """
        创建 TTS 提供商实例（支持延迟加载）

        Args:
            provider_name: 提供商名称
            **kwargs: 其他配置参数（例如 appid、endpoint、ws_url 等）

        Returns:
            BaseTTS: TTS 提供商实例

        Raises:
            TTSProviderNotFoundError: 提供商不存在
            ImportError: 缺少必要的依赖包
            ValueError: 配置无效
        """
        # 如果提供商未缓存，则延迟加载
        if provider_name not in cls._providers:
            cls._lazy_load_provider(provider_name)

        provider_class = cls._providers[provider_name]
        instance = provider_class(**kwargs)

        # 验证配置
        if not instance.validate_config():
            raise ValueError(f"TTS 提供商 {provider_name} 配置无效")

        logger.debug(f"成功创建 TTS 提供商实例: {provider_name}")
        return instance

    @classmethod
    def create_from_config(cls, provider_name: str, config: Dict[str, Any]) -> BaseTTS:
        """
        从配置字典创建实例

        Args:
            provider_name: 提供商名称
            config: 配置字典

        Returns:
            BaseTTS: TTS 提供商实例
        """
        return cls.create(provider_name, **config)
