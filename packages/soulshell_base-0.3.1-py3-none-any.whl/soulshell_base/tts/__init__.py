"""
TTS (Text-to-Speech) 模块
支持多平台的语音合成服务
"""

# 导入核心类
from .base import BaseTTS
from .config import TTSConfigManager, TTSProviderConfig

# 导入异常类
from .exceptions import (
    TTSAuthenticationError,
    TTSConcurrencyExceededError,
    TTSException,
    TTSInvalidParameterError,
    TTSNetworkError,
    TTSProviderNotFoundError,
    TTSRateLimitError,
    TTSResourceError,
    TTSServiceUnavailableError,
    TTSSynthesisError,
    TTSTextInvalidError,
    TTSTextTooLongError,
    TTSTimeoutError,
    TTSVoiceNotFoundError,
)
from .factory import TTSFactory

# 导入数据模型
from .models import (
    AudioEncoding,
    TTSCloneVoiceRequest,
    TTSResponse,
    TTSStatus,
    TTSSynthesizeRequest,
    Voice,
    VoiceGender,
)

__version__ = "0.3.1"

__all__ = [
    # 核心类
    "BaseTTS",
    "TTSFactory",
    "TTSProviderConfig",
    "TTSConfigManager",
    # 数据模型
    "TTSCloneVoiceRequest",
    "TTSSynthesizeRequest",
    "TTSResponse",
    "TTSStatus",
    "Voice",
    "VoiceGender",
    "AudioEncoding",
    # 异常类
    "TTSException",
    "TTSProviderNotFoundError",
    "TTSAuthenticationError",
    "TTSConcurrencyExceededError",
    "TTSInvalidParameterError",
    "TTSNetworkError",
    "TTSRateLimitError",
    "TTSResourceError",
    "TTSServiceUnavailableError",
    "TTSSynthesisError",
    "TTSTextInvalidError",
    "TTSTextTooLongError",
    "TTSTimeoutError",
    "TTSVoiceNotFoundError",
]
