"""
TTS 模块自定义异常
"""

from typing import Optional


class TTSException(Exception):  # noqa: N818
    """TTS 基础异常"""

    def __init__(self, message: str, error_code: Optional[str] = None):
        self.message = message
        self.error_code = error_code
        super().__init__(self.message)


class TTSProviderNotFoundError(TTSException):
    """TTS 提供商未找到"""


class TTSAuthenticationError(TTSException):
    """TTS 认证失败"""


class TTSRateLimitError(TTSException):
    """TTS 限流错误"""


class TTSInvalidParameterError(TTSException):
    """TTS 参数错误"""


class TTSServiceUnavailableError(TTSException):
    """TTS 服务不可用"""


class TTSNetworkError(TTSException):
    """TTS 网络错误"""


class TTSSynthesisError(TTSException):
    """TTS 合成失败"""


class TTSVoiceNotFoundError(TTSInvalidParameterError):
    """音色不存在或不支持"""


class TTSTextInvalidError(TTSInvalidParameterError):
    """文本无效（空文本、格式错误、与语种不匹配等）"""


class TTSTextTooLongError(TTSInvalidParameterError):
    """文本长度超限"""


class TTSConcurrencyExceededError(TTSRateLimitError):
    """并发超限"""


class TTSTimeoutError(TTSException):
    """处理超时"""


class TTSResourceError(TTSException):
    """资源相关错误（如SSML格式错误、背景音乐格式错误）"""
