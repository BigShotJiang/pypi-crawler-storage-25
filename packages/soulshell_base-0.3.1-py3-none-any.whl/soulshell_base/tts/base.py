"""
TTS 抽象基类
"""

from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
from pathlib import Path
import struct
from typing import Any, Callable, Dict, List, Optional

from soulshell_base.cache import CacheRegion
from soulshell_base.core import get_logger

from .exceptions import TTSInvalidParameterError
from .models import AudioEncoding, TTSResponse, TTSSynthesizeRequest, Voice


def pcm_to_wav(
    pcm_data: bytes,
    sample_rate: int = 16000,
    channels: int = 1,
    bits_per_sample: int = 16,
) -> bytes:
    """
    将 PCM 原始数据转换为 WAV 格式（添加 WAV header）

    Args:
        pcm_data: 原始 PCM 音频数据
        sample_rate: 采样率（默认 16000）
        channels: 声道数（默认 1 = 单声道）
        bits_per_sample: 每个采样的位数（默认 16）

    Returns:
        bytes: 带有 WAV header 的音频数据
    """
    byte_rate = sample_rate * channels * bits_per_sample // 8
    block_align = channels * bits_per_sample // 8
    data_size = len(pcm_data)
    file_size = data_size + 36  # 44 - 8 (RIFF header size)

    # 构建 WAV header (44 bytes)
    wav_header = struct.pack(
        "<4sI4s4sIHHIIHH4sI",
        b"RIFF",  # ChunkID
        file_size,  # ChunkSize (file size - 8)
        b"WAVE",  # Format
        b"fmt ",  # Subchunk1ID
        16,  # Subchunk1Size (PCM = 16)
        1,  # AudioFormat (PCM = 1)
        channels,  # NumChannels
        sample_rate,  # SampleRate
        byte_rate,  # ByteRate
        block_align,  # BlockAlign
        bits_per_sample,  # BitsPerSample
        b"data",  # Subchunk2ID
        data_size,  # Subchunk2Size
    )

    return wav_header + pcm_data


class BaseTTS(ABC):
    """TTS 抽象基类"""

    def __init__(self, **kwargs):
        """
        初始化 TTS 提供商

        Args:
            **kwargs: 其他配置参数
        """

        self.config = kwargs
        self.logger = get_logger(
            f"{self.__class__.__module__}.{self.__class__.__name__}",
            level=self.config.get("log_level", "INFO"),
        )

    @abstractmethod
    def get_provider_name(self) -> str:
        """
        获取供应商名称

        Returns:
            str: 供应商名称
        """

    @classmethod
    @abstractmethod
    def describe(cls) -> Dict[str, Any]:
        """获取提供商描述信息（自描述能力）

        Returns:
            包含以下字段的字典：
            - provider_name: 提供商名称
            - display_name: 显示名称
            - description: 描述
            - required_init_params: 必填创建参数 {参数名: {type, description, env_var?, example?}}
            - optional_init_params: 可选创建参数 {参数名: {type, description, default}}
            - supported_features: 支持的功能列表
            - example: 完整示例

        Example:
            >>> from soulshell_base.tts.providers.aliyun import AliyunTTSProvider
            >>> info = AliyunTTSProvider.describe()
            >>> print(info['required_init_params'])
            {'appkey': {'type': 'str', 'description': '应用密钥', ...}}
        """

    @abstractmethod
    def validate_config(self) -> bool:
        """
        验证配置参数（可重写）

        Returns:
            bool: 配置是否有效
        """
        return True

    @abstractmethod
    async def synthesize(self, request: TTSSynthesizeRequest) -> TTSResponse:
        """
        异步语音合成

        Args:
            request: 合成请求参数，包含以下主要字段：
                - text: 要合成的文本（必填）
                - voice_id: 音色ID（必填）
                - language: 语言代码（可选），如 "zh-CN"
                - speed: 语速倍率（可选），范围 0.1~2.0，默认 1.0
                - pitch: 音调半音（可选），范围 -12~12，默认 0
                - volume: 音量倍率（可选），范围 0.1~2.0，默认 1.0
                - encoding: 音频编码格式（可选），默认 MP3
                - sample_rate: 采样率（可选），默认 16000
                - use_cache: 是否使用缓存（可选），覆盖 Provider 级默认值
                - reset_cache: 是否重置缓存（可选），删除旧缓存后重新生成
                - cache_ttl: 缓存 TTL（可选），覆盖 Provider 级默认值
                - extra_params: 提供商特定的额外参数（可选）

        Returns:
            TTSResponse: 合成结果，包含：
                - status: 合成状态（SUCCESS/FAILED）
                - audio_data: 音频数据（bytes）
                - duration: 音频时长（秒）
                - audio_format: 音频格式
                - sample_rate: 采样率
                - metadata: 元数据信息

        Raises:
            TTSInvalidParameterError: 参数无效（如文本为空）
            TTSAuthenticationError: 认证失败
            TTSTextTooLongError: 文本过长
            TTSVoiceNotFoundError: 音色不存在
            TTSError: 合成失败
            TTSNetworkError: 网络错误

        Example:
            >>> request = TTSSynthesizeRequest(
            ...     text="你好，世界",
            ...     voice_id="xiaoyun",
            ...     speed=1.2,
            ...     encoding=AudioEncoding.MP3
            ... )
            >>> response = await tts.synthesize(request)
            >>> if response.is_success:
            ...     with open("output.mp3", "wb") as f:
            ...         f.write(response.audio_data)
        """

    def synthesize_sync(self, request: TTSSynthesizeRequest) -> TTSResponse:
        """
        同步语音合成（可选实现）

        Args:
            request: 合成请求参数，包含以下主要字段：
                - text: 要合成的文本（必填）
                - voice_id: 音色ID（必填）
                - language: 语言代码（可选），如 "zh-CN"
                - speed: 语速倍率（可选），范围 0.1~2.0，默认 1.0
                - pitch: 音调半音（可选），范围 -12~12，默认 0
                - volume: 音量倍率（可选），范围 0.1~2.0，默认 1.0
                - encoding: 音频编码格式（可选），默认 MP3
                - sample_rate: 采样率（可选），默认 16000
                - use_cache: 是否使用缓存（可选），覆盖 Provider 级默认值
                - reset_cache: 是否重置缓存（可选），删除旧缓存后重新生成
                - cache_ttl: 缓存 TTL（可选），覆盖 Provider 级默认值
                - extra_params: 提供商特定的额外参数（可选）

        Returns:
            TTSResponse: 合成结果，包含：
                - status: 合成状态（SUCCESS/FAILED）
                - audio_data: 音频数据（bytes）
                - duration: 音频时长（秒）
                - audio_format: 音频格式
                - sample_rate: 采样率
                - metadata: 元数据信息

        Raises:
            NotImplementedError: 如果提供商不支持同步接口
            TTSInvalidParameterError: 参数无效（如文本为空）
            TTSAuthenticationError: 认证失败
            TTSTextTooLongError: 文本过长
            TTSVoiceNotFoundError: 音色不存在
            TTSError: 合成失败
            TTSNetworkError: 网络错误

        Example:
            >>> request = TTSSynthesizeRequest(
            ...     text="你好，世界",
            ...     voice_id="xiaoyun",
            ...     speed=1.2,
            ...     encoding=AudioEncoding.MP3
            ... )
            >>> response = tts.synthesize_sync(request)
            >>> if response.is_success:
            ...     with open("output.mp3", "wb") as f:
            ...         f.write(response.audio_data)
        """
        raise NotImplementedError(f"{self.get_provider_name()} 不支持同步接口")

    async def synthesize_stream(
        self, _request: TTSSynthesizeRequest
    ) -> AsyncIterator[TTSResponse]:
        """
        流式语音合成（可选实现）

        Args:
            request: 合成请求参数，包含以下主要字段：
                - text: 要合成的文本（必填）
                - voice_id: 音色ID（必填）
                - language: 语言代码（可选）
                - speed: 语速倍率（可选）
                - pitch: 音调半音（可选）
                - volume: 音量倍率（可选）
                - encoding: 音频编码格式（可选）
                - sample_rate: 采样率（可选）
                - extra_params: 提供商特定的额外参数（可选）

        Yields:
            TTSResponse: 流式事件，包含：
                - START 事件：合成开始
                - PARTIAL 事件：音频数据片段（audio_data 包含部分音频）
                - SUCCESS 事件：合成完成（最后一个事件）
                - FAILED 事件：合成失败

        Raises:
            NotImplementedError: 如果提供商不支持流式接口
            TTSInvalidParameterError: 参数无效
            TTSError: 合成失败

        Example:
            >>> request = TTSSynthesizeRequest(
            ...     text="你好，世界",
            ...     voice_id="xiaoyun"
            ... )
            >>> async for event in tts.synthesize_stream(request):
            ...     if event.status == TTSStatus.PARTIAL:
            ...         # 处理音频片段
            ...         process_audio_chunk(event.audio_data)
            ...     elif event.status == TTSStatus.SUCCESS:
            ...         print("合成完成")
        """
        raise NotImplementedError(f"{self.get_provider_name()} 不支持流式接口")
        yield TTSResponse.failed(error_message="")  # for type hints

    async def list_voices(self, language: Optional[str] = None) -> List[Voice]:
        """
        列出可用音色（可选实现）

        Args:
            language: 语言过滤（可选）

        Returns:
            List[Voice]: 音色列表

        Raises:
            NotImplementedError: 如果提供商不支持列出音色
        """
        raise NotImplementedError(f"{self.get_provider_name()} 不支持列出音色")

    def validate_request(self, request: TTSSynthesizeRequest) -> None:
        """
        验证请求参数（可重写）

        Args:
            request: 合成请求参数

        Raises:
            TTSInvalidParameterError: 参数无效
        """
        if not request.text:
            raise TTSInvalidParameterError("文本不能为空")
        if not request.voice_id:
            raise TTSInvalidParameterError("音色ID不能为空")

    async def synthesize_to_file(
        self,
        text: str,
        voice_id: str,
        output_path: str | Path,
        language: str = "zh-CN",
        speed: float = 1.0,
        pitch: float = 0.0,
        volume: float = 1.0,
        encoding: AudioEncoding = AudioEncoding.MP3,
        sample_rate: int = 16000,
        **extra_params,
    ) -> TTSResponse:
        """便捷方法：合成语音并保存到文件

        Args:
            text: 要合成的文本
            voice_id: 音色ID
            output_path: 输出文件路径
            language: 语言
            speed: 语速
            pitch: 音调
            volume: 音量
            encoding: 音频编码格式
            sample_rate: 采样率
            **extra_params: 额外参数

        Returns:
            TTSResponse: 合成响应
        """
        request = TTSSynthesizeRequest(
            text=text,
            voice_id=voice_id,
            language=language,
            speed=speed,
            pitch=pitch,
            volume=volume,
            encoding=encoding,
            sample_rate=sample_rate,
            extra_params=extra_params,
        )
        response = await self.synthesize(request)

        if response.is_success and response.audio_data:
            output_file = Path(output_path)
            output_file.parent.mkdir(parents=True, exist_ok=True)
            output_file.write_bytes(response.audio_data)
            self.logger.info(f"音频已保存到: {output_file}")

        return response

    # ========== 缓存相关方法（通用实现） ==========

    def _resolve_cache_policy(
        self, request: TTSSynthesizeRequest
    ) -> tuple[bool, bool, float]:
        """
        解析缓存策略（Provider级默认 + 请求级覆盖）

        Args:
            request: 合成请求参数

        Returns:
            tuple[bool, bool, float]: (use_cache, reset_cache, ttl_seconds)
        """
        default_use_cache = bool(self.config.get("default_use_cache", False))
        default_ttl_raw = self.config.get("default_cache_ttl", -1)
        default_ttl = float(default_ttl_raw) if default_ttl_raw is not None else -1.0

        # 从 request 顶层字段读取缓存参数（优先级高于 Provider 默认值）
        use_cache = (
            request.use_cache if request.use_cache is not None else default_use_cache
        )
        reset_cache = request.reset_cache

        ttl_raw = request.cache_ttl if request.cache_ttl is not None else default_ttl
        ttl_val = float(ttl_raw) if ttl_raw is not None else -1.0
        ttl_seconds = ttl_val if ttl_val > 1.0 else -1.0
        return use_cache, reset_cache, ttl_seconds

    def _get_cache_region(self) -> CacheRegion:
        """
        获取缓存区域

        Returns:
            CacheRegion: 缓存区域实例
        """
        return CacheRegion(module="tts", region=self.get_provider_name())

    def _build_cache_key_payload(self, request: TTSSynthesizeRequest) -> dict[str, Any]:
        """
        构建缓存键负载（子类可覆盖以添加额外字段）

        Args:
            request: 合成请求参数

        Returns:
            dict[str, Any]: 缓存键负载
        """
        encoding = (
            request.encoding.value
            if hasattr(request.encoding, "value")
            else str(request.encoding)
        )
        return {
            "provider": self.get_provider_name(),
            "text": request.text,
            "voice_id": request.voice_id,
            "language": request.language,
            "speed": request.speed,
            "pitch": request.pitch,
            "volume": request.volume,
            "encoding": encoding,
            "sample_rate": request.sample_rate,
        }

    def _build_cache_query_metadata(
        self, cache_key_payload: dict[str, Any]
    ) -> dict[str, Any]:
        """
        构建查询元数据（子类可覆盖）

        Args:
            cache_key_payload: 缓存键负载

        Returns:
            dict[str, Any]: 查询元数据
        """
        return cache_key_payload

    def _build_cache_hit_response(
        self,
        *,
        request: TTSSynthesizeRequest,
        cached_bytes: bytes,
        cached_metadata: dict[str, Any] | None = None,
    ) -> TTSResponse:
        """
        构建缓存命中响应

        Args:
            request: 合成请求参数
            cached_bytes: 缓存的音频数据
            cached_metadata: 缓存的元数据（包含 duration 等信息）

        Returns:
            TTSResponse: 合成响应
        """
        audio_format = (
            request.encoding.value
            if hasattr(request.encoding, "value")
            else str(request.encoding)
        )

        # 从缓存元数据中恢复响应字段
        duration = None
        sample_rate = request.sample_rate
        original_metadata = {}

        if cached_metadata:
            duration = cached_metadata.get("duration")
            sample_rate = cached_metadata.get("sample_rate", request.sample_rate)
            original_metadata = cached_metadata.get("original_metadata", {})

        # 合并元数据
        response_metadata = {
            "provider": self.get_provider_name(),
            "voice_id": request.voice_id,
            "from_cache": True,
            "cache_region": f"tts/{self.get_provider_name()}",
            **original_metadata,
        }

        return TTSResponse.success(
            audio_data=cached_bytes,
            duration=duration,
            audio_format=audio_format,
            sample_rate=sample_rate,
            metadata=response_metadata,
        )

    def _run_with_cache_policy_sync(
        self,
        *,
        request: TTSSynthesizeRequest,
        compute: Callable[[], TTSResponse],
    ) -> TTSResponse:
        """
        通用的缓存策略包装器（同步版本）

        Args:
            request: 合成请求参数
            compute: 实际合成的计算函数

        Returns:
            TTSResponse: 合成响应
        """
        self.validate_request(request)

        use_cache, reset_cache, ttl_seconds = self._resolve_cache_policy(request)
        if not use_cache:
            return compute()

        cache_region = self._get_cache_region()
        cache_key_payload = self._build_cache_key_payload(request)

        try:
            if reset_cache:
                cache_region.delete(cache_key_payload)
                self.logger.info(
                    f"【TTS/缓存重置】{self.get_provider_name()} 同步合成，已删除旧缓存后重新合成 "
                    f"(text_len={len(request.text)})"
                )
            else:
                cache_hit = cache_region.get(cache_key_payload)
                if cache_hit is not None:
                    cached_bytes = cache_hit.blob_path.read_bytes()
                    cached_metadata = cache_hit.metadata.get("response_meta")
                    self.logger.info(
                        f"【TTS/缓存命中】{self.get_provider_name()} 同步合成，直接返回缓存结果 "
                        f"({cached_metadata})"
                    )
                    return self._build_cache_hit_response(
                        request=request,
                        cached_bytes=cached_bytes,
                        cached_metadata=cached_metadata,
                    )
        except Exception as e:
            self.logger.warning(
                f"【TTS/缓存】{self.get_provider_name()} 同步合成缓存读取/重置失败，忽略: {e!s}"
            )

        response = compute()
        if not response.is_success or not response.audio_data:
            return response

        try:
            query_metadata = self._build_cache_query_metadata(cache_key_payload)
            # 构建缓存元数据（包含响应字段）
            cache_metadata = {
                **cache_key_payload,
                "response_meta": {
                    "duration": response.duration,
                    "audio_format": response.audio_format,
                    "sample_rate": response.sample_rate,
                    "original_metadata": response.metadata or {},
                },
            }
            cache_region.set(
                raw_key=cache_key_payload,
                blob=response.audio_data,
                blob_suffix=f".{response.audio_format or 'bin'}",
                metadata=cache_metadata,
                query_metadata=query_metadata,
                ttl_seconds=ttl_seconds,
            )
            self.logger.info(
                f"【TTS/缓存写入】{self.get_provider_name()} 同步合成结果已写入缓存 "
                f"(text_len={len(request.text)}, encoding={response.audio_format}, "
                f"sample_rate={response.sample_rate}, duration={response.duration})"
            )
        except Exception as e:
            self.logger.warning(
                f"【TTS/缓存】{self.get_provider_name()} 写入缓存失败，忽略: {e!s}"
            )

        return response

    def _run_with_cache_policy_async(
        self,
        *,
        request: TTSSynthesizeRequest,
        compute,
    ):
        """
        通用的缓存策略包装器（异步版本）

        Args:
            request: 合成请求参数
            compute: 实际合成的计算函数（异步）

        Returns:
            异步生成器，返回 TTSResponse
        """

        async def _wrapper():
            self.validate_request(request)

            use_cache, reset_cache, ttl_seconds = self._resolve_cache_policy(request)
            if not use_cache:
                return await compute()

            cache_region = self._get_cache_region()
            cache_key_payload = self._build_cache_key_payload(request)

            try:
                if reset_cache:
                    cache_region.delete(cache_key_payload)
                    self.logger.info(
                        f"【TTS/缓存重置】{self.get_provider_name()} 异步合成，已删除旧缓存后重新合成 "
                        f"(text_len={len(request.text)})"
                    )
                else:
                    cache_hit = cache_region.get(cache_key_payload)
                    if cache_hit is not None:
                        cached_bytes = cache_hit.blob_path.read_bytes()
                        cached_metadata = cache_hit.metadata.get("response_meta")
                        self.logger.info(
                            f"【TTS/缓存命中】{self.get_provider_name()} ，直接返回缓存结果 "
                            f"({cached_metadata})"
                        )
                        return self._build_cache_hit_response(
                            request=request,
                            cached_bytes=cached_bytes,
                            cached_metadata=cached_metadata,
                        )
            except Exception as e:
                self.logger.warning(
                    f"【TTS/缓存】{self.get_provider_name()} 缓存读取/重置失败，忽略: {e!s}"
                )

            response = await compute()
            if not response.is_success or not response.audio_data:
                return response

            try:
                query_metadata = self._build_cache_query_metadata(cache_key_payload)
                # 构建缓存元数据（包含响应字段）
                cache_metadata = {
                    **cache_key_payload,
                    "response_meta": {
                        "duration": response.duration,
                        "audio_format": response.audio_format,
                        "sample_rate": response.sample_rate,
                        "original_metadata": response.metadata or {},
                    },
                }
                cache_region.set(
                    raw_key=cache_key_payload,
                    blob=response.audio_data,
                    blob_suffix=f".{response.audio_format or 'bin'}",
                    metadata=cache_metadata,
                    query_metadata=query_metadata,
                    ttl_seconds=ttl_seconds,
                )
                self.logger.info(
                    f"【TTS/缓存写入】{self.get_provider_name()} 异步合成结果已写入缓存 "
                    f"(text_len={len(request.text)}, encoding={response.audio_format}, "
                    f"sample_rate={response.sample_rate}, duration={response.duration})"
                )
            except Exception as e:
                self.logger.warning(
                    f"【TTS/缓存】{self.get_provider_name()} 写入缓存失败，忽略: {e!s}"
                )

            return response

        return _wrapper()
