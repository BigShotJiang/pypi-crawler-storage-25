"""
TTS 数据模型
"""

from dataclasses import dataclass, field
from enum import Enum
import logging
from pathlib import Path
from typing import Any, Dict, Optional


class TTSStatus(str, Enum):
    """TTS 状态"""

    START = "start"
    PARTIAL = "partial"
    SUCCESS = "success"
    FAILED = "failed"


class VoiceGender(str, Enum):
    """音色性别"""

    MALE = "male"
    FEMALE = "female"
    NEUTRAL = "neutral"


class AudioEncoding(str, Enum):
    """音频编码格式"""

    MP3 = "mp3"
    WAV = "wav"
    PCM = "pcm"
    OGG = "ogg"
    OPUS = "opus"


@dataclass
class TTSSynthesizeRequest:
    """TTS 合成请求参数"""

    text: str
    voice_id: str = None
    language: str = "zh-CN"
    speed: float = 1.0  # 0.1 - 2.0
    pitch: float = 0.0  # -12.0 to 12.0
    volume: float = 1.0  # 0.1 - 2.0
    encoding: AudioEncoding = AudioEncoding.MP3
    sample_rate: int = 16000

    # 缓存相关参数
    use_cache: Optional[bool] = None  # 是否使用缓存（None 表示使用 Provider 默认值）
    reset_cache: bool = False  # 是否重置缓存（删除旧缓存后重新生成）
    cache_ttl: Optional[float] = None  # 缓存 TTL（None 表示使用 Provider 默认值）

    extra_params: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """参数验证"""
        logger = logging.getLogger(__name__)

        if not self.text:
            raise ValueError("text 不能为空")
        # 音色id根据语种, 从provider中获取
        # if not self.voice_id:
        #     raise ValueError("voice_id 不能为空")

        # 兜底：确保 speed 在 0.1-2.0 范围内
        if self.speed < 0.1:
            logger.warning(f"speed参数 {self.speed} 小于最小值0.1，已调整为0.1")
            self.speed = 0.1
        elif self.speed > 2.0:
            logger.warning(f"speed参数 {self.speed} 大于最大值2.0，已调整为2.0")
            self.speed = 2.0

        # 兜底：确保 pitch 在 -12.0 到 12.0 范围内
        if self.pitch < -12.0:
            logger.warning(f"pitch参数 {self.pitch} 小于最小值-12.0，已调整为-12.0")
            self.pitch = -12.0
        elif self.pitch > 12.0:
            logger.warning(f"pitch参数 {self.pitch} 大于最大值12.0，已调整为12.0")
            self.pitch = 12.0

        # 兜底：确保 volume 在 0.1-2.0 范围内
        if self.volume < 0.1:
            logger.warning(f"volume参数 {self.volume} 小于最小值0.1，已调整为0.1")
            self.volume = 0.1
        elif self.volume > 2.0:
            logger.warning(f"volume参数 {self.volume} 大于最大值2.0，已调整为2.0")
            self.volume = 2.0

        # 转换 encoding 字符串为枚举
        if isinstance(self.encoding, str):
            self.encoding = AudioEncoding(self.encoding.lower())


@dataclass
class TTSResponse:
    """TTS 合成响应"""

    status: TTSStatus
    audio_data: Optional[bytes] = None
    duration: Optional[float] = None  # 秒，可能为None，标识响应无法直接获取时长
    audio_format: Optional[str] = None
    sample_rate: Optional[int] = None
    error_code: Optional[str] = None
    error_message: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None

    @property
    def is_success(self) -> bool:
        """是否成功"""
        return self.status == TTSStatus.SUCCESS

    @property
    def is_failed(self) -> bool:
        """是否失败"""
        return self.status == TTSStatus.FAILED

    @classmethod
    def success(
        cls,
        audio_data: bytes,
        duration: Optional[float] = None,
        audio_format: str = "mp3",
        sample_rate: Optional[int] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> "TTSResponse":
        """创建成功响应"""
        return cls(
            status=TTSStatus.SUCCESS,
            audio_data=audio_data,
            duration=duration,
            audio_format=audio_format,
            sample_rate=sample_rate,
            metadata=metadata,
        )

    @classmethod
    def failed(
        cls,
        error_message: str,
        error_code: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> "TTSResponse":
        """创建失败响应"""
        return cls(
            status=TTSStatus.FAILED,
            error_code=error_code,
            error_message=error_message,
            metadata=metadata,
        )


@dataclass
class Voice:
    """音色信息"""

    voice_id: str
    name: str
    language: str
    gender: VoiceGender
    description: Optional[str] = None
    sample_rate: Optional[int] = None
    extra_info: Optional[Dict[str, Any]] = None

    def __post_init__(self):
        """类型转换"""
        if isinstance(self.gender, str):
            self.gender = VoiceGender(self.gender.lower())


@dataclass
class TTSCloneVoiceRequest:
    """TTS 克隆音色请求参数
    https://www.volcengine.com/docs/6561/1305191?lang=zh#%E4%B8%8A%E4%BC%A0%E8%AE%AD%E7%BB%83%E9%9F%B3%E8%89%B2
    """

    speaker_id: str
    clone_auido_path: str | Path
    language: int = 0
    source: int = 2
    model_type: int = 4
    extra_params: Optional[Dict[str, Any]] = None

    def __post_init__(self):
        """类型转换"""
        if not self.speaker_id:
            raise ValueError("speaker_id 不能为空")
        if not Path(self.clone_auido_path).exists():
            raise ValueError("clone_auido_path 必须是一个存在的wav文件路径")
