# docsum

A command-line AI chat tool that lets you explore and query your codebase using natural language — powered by Groq.

[![doctests](https://github.com/Ariberry9/docsum/actions/workflows/doctests.yml/badge.svg)](https://github.com/Ariberry9/docsum/actions/workflows/doctests.yml)
[![flake8](https://github.com/Ariberry9/docsum/actions/workflows/flake8.yml/badge.svg)](https://github.com/Ariberry9/docsum/actions/workflows/flake8.yml)
[![integration](https://github.com/Ariberry9/docsum/actions/workflows/integration.yml/badge.svg)](https://github.com/Ariberry9/docsum/actions/workflows/integration.yml)
[![PyPI](https://img.shields.io/pypi/v/cmc-csci005-ariberry9)](https://pypi.org/project/cmc-csci005-ariberry9/)
[![codecov](https://codecov.io/gh/Ariberry9/docsum/branch/main/graph/badge.svg)](https://codecov.io/gh/Ariberry9/docsum)

<!-- Replace the gif below with your own screen recording -->
![demo](img/demo.gif)

## Usage

### Exploring a Markdown Compiler

This example shows how the tool can reason about an unfamiliar codebase without you having to read the source yourself.

```
$ cd test_projects/markdown_compiler
$ chat
chat> does this project use regular expressions?
No. I grepped all of the python files for any uses of the `re` library and did not find any.
```

### Exploring an eBay Scraper

This example shows how the tool can answer questions about a project's purpose and legal considerations by reading its README and source files.

```
$ cd test_projects/ebay_scraper
$ chat
chat> tell me about this project
The README says this project is designed to scrape product information off of eBay.
chat> is this legal?
Yes. It is generally legal to scrape webpages, but eBay offers an API that would be more efficient to use.
```

### Exploring a Personal Webpage

This example shows how the tool can inspect HTML/CSS files and summarize the structure of a web project.

```
$ cd test_projects/webpage
$ chat
chat> what does this webpage look like?
Based on the HTML and CSS files, this is a personal portfolio page with a navigation bar, an about section, and a contact form styled with a dark background.
```

## Installation

```bash
pip install cmc-csci005-ariberry9
```

Then run from any project directory:

```bash
chat
```

## Tools

The assistant has access to the following built-in tools, which can be called automatically or manually with `/command`:

- `/ls [folder]` — list files in the current or specified folder
- `/cat <file>` — print the contents of a file
- `/grep <pattern> <path>` — search for a regex pattern across files
- `/calculate <expression>` — evaluate a math expression