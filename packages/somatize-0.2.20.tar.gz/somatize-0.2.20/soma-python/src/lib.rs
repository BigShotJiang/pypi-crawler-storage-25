//! PyO3 bindings for Soma — exposes Graph, Study, and Filter to Python.
//!
//! Bridges Python Filter classes to the Rust Filter trait, converts
//! between Python lists/dicts and Soma Values, and wraps the StudyRunner
//! for hyperparameter optimization from Python.

use pyo3::exceptions::PyRuntimeError;
use pyo3::prelude::*;
use pyo3::types::{IntoPyDict, PyDict, PyList};
use std::collections::HashMap;
use std::sync::Arc;

use somatize_compiler::CompileMode;
use somatize_core::cache::CacheKey;
use somatize_core::error::{Result as SomaResult, SomaError};
use somatize_core::event::MetricRecord;
use somatize_core::filter::{Filter, FilterKind, FilterMeta, StreamMode};
use somatize_core::graph::{Edge, Graph, Node};
use somatize_core::search::{Scale, SearchDimension, SearchSpace};
use somatize_core::study::{Direction, Objective, SearchStrategy, Study};
use somatize_core::value::Value;
use somatize_runtime::EventBus;
use somatize_runtime::cache::MemoryCache;
use somatize_runtime::executor::{self, Context, GraphInfo};
use somatize_runtime::filter_library::FilterLibrary;
use somatize_runtime::sampler::{BayesianSampler, GridSampler, RandomSampler, Sampler};
use somatize_runtime::study_runner::{FnTrialExecutor, StudyRunner, TrialOutcome};

fn soma_err_to_py(e: SomaError) -> PyErr {
    PyRuntimeError::new_err(e.to_string())
}

fn py_err_to_soma(e: PyErr) -> SomaError {
    SomaError::Other(e.to_string())
}

// ── Value conversion ──

fn py_to_value(py: Python<'_>, obj: &Bound<'_, PyAny>) -> PyResult<Value> {
    if let Ok(lists) = obj.extract::<Vec<Vec<f64>>>() {
        let rows = lists.len();
        let cols = if rows > 0 { lists[0].len() } else { 0 };
        let flat: Vec<f64> = lists.into_iter().flatten().collect();
        return Ok(Value::tensor(flat, vec![rows, cols]));
    }

    if let Ok(arr) = obj.extract::<Vec<f64>>() {
        let len = arr.len();
        return Ok(Value::tensor(arr, vec![len]));
    }

    if obj.is_instance_of::<PyDict>() {
        let json_mod = py.import("json")?;
        let json_str: String = json_mod.call_method1("dumps", (obj,))?.extract()?;
        let val: serde_json::Value =
            serde_json::from_str(&json_str).map_err(|e| PyRuntimeError::new_err(e.to_string()))?;
        return Ok(Value::Json(val));
    }

    if let Ok(s) = obj.extract::<String>()
        && let Ok(val) = serde_json::from_str(&s)
    {
        return Ok(Value::Json(val));
    }

    Err(PyRuntimeError::new_err(
        "Cannot convert Python object to Value. Expected list, 2D list, dict, or JSON string.",
    ))
}

fn value_to_py(py: Python<'_>, val: &Value) -> PyResult<PyObject> {
    match val {
        Value::Tensor { values, shape } => {
            if shape.len() == 2 {
                let rows = shape[0];
                let cols = shape[1];
                let result = PyList::empty(py);
                for r in 0..rows {
                    let row: Vec<f64> = values[r * cols..(r + 1) * cols].to_vec();
                    result.append(row)?;
                }
                Ok(result.into_any().unbind())
            } else {
                Ok(values.into_pyobject(py)?.into_any().unbind())
            }
        }
        Value::Json(v) => {
            let json_str = v.to_string();
            let json_mod = py.import("json")?;
            let obj = json_mod.call_method1("loads", (json_str,))?;
            Ok(obj.unbind())
        }
        Value::Bytes(b) => Ok(b.into_pyobject(py)?.into_any().unbind()),
        Value::Empty => Ok(py.None()),
        _ => Ok(py.None()),
    }
}

// ── Python Filter wrapper ──

struct PyFilterBridge {
    py_obj: PyObject,
    name: String,
    config_hash_val: CacheKey,
    /// cloudpickle.dumps() bytes — serializes the full object (bytecode + closures + deps).
    pickled_bytes: Vec<u8>,
    /// Full module source code (imports + classes + helpers) for introspection by Nous agents.
    source: String,
    /// Pip requirements detected from the filter's imports.
    requirements: Vec<String>,
}

impl PyFilterBridge {
    fn new(py: Python<'_>, obj: &Bound<'_, PyAny>) -> PyResult<Self> {
        let name: String = obj.get_type().name()?.to_string();

        // Build config hash from public attributes only.
        let dict = obj.getattr("__dict__")?;
        let dict_ref = dict.downcast::<pyo3::types::PyDict>()?;
        let params = pyo3::types::PyDict::new(py);
        for (key, value) in dict_ref.iter() {
            let k: String = key.extract()?;
            if !k.starts_with('_') {
                params.set_item(key, value)?;
            }
        }

        let json_mod = py.import("json")?;
        let dict_sorted = json_mod.call_method(
            "dumps",
            (params,),
            Some(&[("sort_keys", true)].into_py_dict(py)?),
        )?;
        let params_json: String = dict_sorted.extract()?;
        let config_hash = CacheKey::from_parts(&[name.as_bytes(), params_json.as_bytes()]);

        // Serialize with cloudpickle (like Spark/Dask/Ray).
        // Register the filter's module AND all its transitive local dependencies
        // for by-value pickling. Without this, the worker would need the exact
        // same source tree installed (e.g. src.filters.classifiers, src.utils).
        let cloudpickle = py.import("cloudpickle")?;
        let inspect = py.import("inspect")?;
        let module = inspect.call_method1("getmodule", (obj.get_type(),))?;
        // Python helper: walk module globals, find all non-stdlib imported modules,
        // register them for by-value serialization (transitive).
        py.run(
            c"
import sys, types, cloudpickle as _cp

def _register_transitive(mod, visited=None):
    if visited is None:
        visited = set()
    name = getattr(mod, '__name__', '')
    if not name or name in visited or name == '__main__':
        return
    visited.add(name)
    # Skip stdlib and installed packages (only register project-local modules)
    f = getattr(mod, '__file__', None)
    if f is None:
        return
    # Heuristic: stdlib/site-packages have these in their paths
    if 'site-packages' in f or 'lib/python' in f:
        return
    _cp.register_pickle_by_value(mod)
    # Walk globals for imported modules
    for v in vars(mod).values():
        if isinstance(v, types.ModuleType):
            _register_transitive(v, visited)
        elif isinstance(v, type):
            m = sys.modules.get(v.__module__)
            if m and m.__name__ not in visited:
                _register_transitive(m, visited)

if _soma_module is not None:
    _register_transitive(_soma_module)
",
            Some(&[("_soma_module", &module)].into_py_dict(py)?),
            None,
        )?;
        let pickled = cloudpickle.call_method1("dumps", (obj,))?;
        let pickled_bytes: Vec<u8> = pickled.extract()?;
        let source = if !module.is_none() {
            inspect
                .call_method1("getsource", (&module,))
                .and_then(|s| s.extract::<String>())
                .unwrap_or_default()
        } else {
            inspect
                .call_method1("getsource", (obj.get_type(),))
                .and_then(|s| s.extract::<String>())
                .unwrap_or_default()
        };

        // Detect pip requirements from the filter module's imports.
        // Collects top-level package names of all site-packages imports.
        let reqs_result = py.run(
            c"
import types, sys
_reqs = set()
if _mod is not None:
    for v in vars(_mod).values():
        if isinstance(v, types.ModuleType):
            f = getattr(v, '__file__', '') or ''
            if 'site-packages' in f:
                _reqs.add(v.__name__.split('.')[0])
        elif isinstance(v, type):
            m = sys.modules.get(v.__module__)
            if m:
                f = getattr(m, '__file__', '') or ''
                if 'site-packages' in f:
                    _reqs.add(m.__name__.split('.')[0])
_reqs = sorted(_reqs)
",
            Some(&[("_mod", &module)].into_py_dict(py)?),
            None,
        );
        let requirements: Vec<String> = if reqs_result.is_ok() {
            py.eval(c"_reqs", None, None)
                .and_then(|r| r.extract())
                .unwrap_or_default()
        } else {
            Vec::new()
        };

        Ok(Self {
            py_obj: obj.clone().unbind(),
            name,
            config_hash_val: config_hash,
            pickled_bytes,
            source,
            requirements,
        })
    }
}

impl Filter for PyFilterBridge {
    fn config_hash(&self) -> CacheKey {
        self.config_hash_val.clone()
    }

    fn fit(&self, x: &Value, y: Option<&Value>) -> SomaResult<Value> {
        Python::with_gil(|py| {
            let py_x = value_to_py(py, x).map_err(py_err_to_soma)?;
            let py_y = match y {
                Some(v) => value_to_py(py, v).map_err(py_err_to_soma)?,
                None => py.None(),
            };
            let result = self
                .py_obj
                .call_method1(py, "fit", (py_x, py_y))
                .map_err(|e| SomaError::Other(format!("Python fit() error: {e}")))?;
            let bound = result.bind(py);
            py_to_value(py, bound).map_err(py_err_to_soma)
        })
    }

    fn forward(&self, x: &Value, state: &Value) -> SomaResult<Value> {
        Python::with_gil(|py| {
            let py_x = value_to_py(py, x).map_err(py_err_to_soma)?;
            let py_state = value_to_py(py, state).map_err(py_err_to_soma)?;
            let result = self
                .py_obj
                .call_method1(py, "forward", (py_x, py_state))
                .map_err(|e| SomaError::Other(format!("Python forward() error: {e}")))?;
            let bound = result.bind(py);
            py_to_value(py, bound).map_err(py_err_to_soma)
        })
    }

    fn meta(&self) -> FilterMeta {
        // Read optional meta attributes from the Python class.
        // Users can set: _cacheable = False, _differentiable = False,
        //                _kind = "stateless", _stream_mode = "evolving"
        let (kind, cacheable, differentiable, stream_mode) = Python::with_gil(|py| {
            let obj = self.py_obj.bind(py);

            let cacheable = obj
                .getattr("_cacheable")
                .and_then(|v| v.extract::<bool>())
                .unwrap_or(true);

            let differentiable = obj
                .getattr("_differentiable")
                .and_then(|v| v.extract::<bool>())
                .unwrap_or(false);

            let kind = obj
                .getattr("_kind")
                .and_then(|v| v.extract::<String>())
                .map(|s| match s.as_str() {
                    "stateless" => FilterKind::Stateless,
                    _ => FilterKind::Trainable,
                })
                .unwrap_or(FilterKind::Trainable);

            let stream_mode = obj
                .getattr("_stream_mode")
                .and_then(|v| v.extract::<String>())
                .map(|s| match s.as_str() {
                    "evolving" => StreamMode::Evolving {
                        checkpoint_every: 100,
                    },
                    "barrier" => StreamMode::Barrier,
                    _ => StreamMode::FixedState,
                })
                .unwrap_or(StreamMode::FixedState);

            (kind, cacheable, differentiable, stream_mode)
        });

        FilterMeta {
            name: self.name.clone(),
            kind,
            cacheable,
            differentiable,
            stream_mode,
            distribution: somatize_core::filter::Distribution::Local,
            input_schema: None,
            output_schema: None,
        }
    }
}

// ── Search dimension parsing ──

fn parse_py_search_dim(_py: Python<'_>, item: &Bound<'_, PyAny>) -> PyResult<SearchDimension> {
    let dict = item.downcast::<PyDict>()?;
    let dtype: String = dict
        .get_item("type")?
        .ok_or_else(|| PyRuntimeError::new_err("missing 'type'"))?
        .extract()?;
    let name: String = dict
        .get_item("name")?
        .ok_or_else(|| PyRuntimeError::new_err("missing 'name'"))?
        .extract()?;

    match dtype.as_str() {
        "float" => {
            let low: f64 = dict.get_item("low")?.unwrap().extract()?;
            let high: f64 = dict.get_item("high")?.unwrap().extract()?;
            let scale_str: String = dict
                .get_item("scale")?
                .map(|s| s.extract().unwrap_or_default())
                .unwrap_or("linear".into());
            let scale = match scale_str.as_str() {
                "log" => Scale::Log,
                "reverse_log" => Scale::ReverseLog,
                _ => Scale::Linear,
            };
            Ok(SearchDimension::Float {
                name,
                low,
                high,
                scale,
                default: None,
            })
        }
        "int" => {
            let low: i64 = dict.get_item("low")?.unwrap().extract()?;
            let high: i64 = dict.get_item("high")?.unwrap().extract()?;
            Ok(SearchDimension::Int {
                name,
                low,
                high,
                scale: Scale::Linear,
            })
        }
        "categorical" => {
            let choices_py = dict.get_item("choices")?.unwrap();
            let choices_list = choices_py.downcast::<PyList>()?;
            let choices: Vec<serde_json::Value> = choices_list
                .iter()
                .map(|c| {
                    if let Ok(s) = c.extract::<String>() {
                        serde_json::json!(s)
                    } else if let Ok(b) = c.extract::<bool>() {
                        serde_json::json!(b)
                    } else if let Ok(i) = c.extract::<i64>() {
                        serde_json::json!(i)
                    } else if let Ok(f) = c.extract::<f64>() {
                        serde_json::json!(f)
                    } else {
                        serde_json::json!(c.to_string())
                    }
                })
                .collect();
            Ok(SearchDimension::Categorical { name, choices })
        }
        _ => Err(PyRuntimeError::new_err(format!(
            "unknown search dim type: {dtype}"
        ))),
    }
}

// ── PyStudy ──

#[pyclass(name = "Study")]
struct PyStudy {
    study: Study,
}

#[pymethods]
impl PyStudy {
    #[new]
    #[pyo3(signature = (name, search_space, strategy, n_trials, objectives, seed=None))]
    fn new(
        _py: Python<'_>,
        name: String,
        search_space: &Bound<'_, PyList>,
        strategy: String,
        n_trials: usize,
        objectives: Vec<(String, String)>,
        seed: Option<u64>,
    ) -> PyResult<Self> {
        let mut space = SearchSpace::new();
        for item in search_space.iter() {
            let dim = parse_py_search_dim(item.py(), &item)?;
            space.add(dim);
        }

        let strat = match strategy.as_str() {
            "grid" => SearchStrategy::Grid {
                points_per_dim: n_trials,
            },
            "random" => SearchStrategy::Random { n_trials, seed },
            "bayesian" => SearchStrategy::Bayesian {
                n_trials,
                n_startup: (n_trials / 5).max(5),
                seed,
            },
            _ => {
                return Err(PyRuntimeError::new_err(format!(
                    "Unknown strategy: {strategy}. Use 'grid', 'random', or 'bayesian'."
                )));
            }
        };

        let objs: Vec<Objective> = objectives
            .into_iter()
            .map(|(metric, dir)| Objective {
                metric,
                direction: if dir == "minimize" {
                    Direction::Minimize
                } else {
                    Direction::Maximize
                },
            })
            .collect();

        Ok(Self {
            study: Study::new(name, space, strat, objs),
        })
    }

    fn run(&mut self, _py: Python<'_>, executor: &Bound<'_, PyAny>) -> PyResult<()> {
        let bus = Arc::new(EventBus::new(256));
        let runner = StudyRunner::new(bus);
        let executor_obj = executor.clone().unbind();

        let trial_executor = FnTrialExecutor(
            move |params: &HashMap<String, serde_json::Value>| -> SomaResult<TrialOutcome> {
                Python::with_gil(|py| {
                    let py_params = PyDict::new(py);
                    for (k, v) in params {
                        let py_val: PyObject = match v {
                            serde_json::Value::Number(n) => {
                                if let Some(f) = n.as_f64() {
                                    f.into_pyobject(py).unwrap().into_any().unbind()
                                } else {
                                    py.None()
                                }
                            }
                            serde_json::Value::String(s) => {
                                s.into_pyobject(py).unwrap().into_any().unbind()
                            }
                            serde_json::Value::Bool(b) => (*b)
                                .into_pyobject(py)
                                .unwrap()
                                .to_owned()
                                .into_any()
                                .unbind(),
                            _ => v.to_string().into_pyobject(py).unwrap().into_any().unbind(),
                        };
                        py_params.set_item(k, py_val).map_err(py_err_to_soma)?;
                    }

                    let result = executor_obj
                        .call1(py, (py_params,))
                        .map_err(|e| SomaError::Other(format!("Python executor error: {e}")))?;
                    let bound = result.bind(py);
                    let dict = bound
                        .downcast::<PyDict>()
                        .map_err(|_| SomaError::Other("executor must return a dict".into()))?;

                    let mut metrics = Vec::new();
                    for (k, v) in dict.iter() {
                        let name: String = k.extract().map_err(py_err_to_soma)?;
                        let value: f64 = v.extract().map_err(py_err_to_soma)?;
                        metrics.push(MetricRecord {
                            name,
                            value,
                            step: 0,
                            timestamp: chrono::Utc::now(),
                        });
                    }
                    Ok(TrialOutcome::Completed(metrics))
                })
            },
        );

        let mut sampler: Box<dyn Sampler> = match &self.study.strategy {
            SearchStrategy::Grid { points_per_dim } => Box::new(GridSampler::new(*points_per_dim)),
            SearchStrategy::Random { n_trials, seed } => {
                Box::new(RandomSampler::new(*n_trials, *seed))
            }
            SearchStrategy::Bayesian {
                n_trials,
                n_startup,
                seed,
                ..
            } => Box::new(BayesianSampler::new(*n_trials, *n_startup, *seed)),
            _ => return Err(PyRuntimeError::new_err("Unsupported strategy")),
        };

        runner
            .run(&mut self.study, sampler.as_mut(), &trial_executor)
            .map_err(soma_err_to_py)
    }

    #[getter]
    fn best_trial(&self, py: Python<'_>) -> PyResult<Option<PyObject>> {
        match self.study.best_trial() {
            Some(trial) => {
                let dict = PyDict::new(py);
                dict.set_item("id", &trial.id)?;
                let params_dict = PyDict::new(py);
                for (k, v) in &trial.params {
                    let py_val: PyObject = match v {
                        serde_json::Value::Number(n) => {
                            if let Some(f) = n.as_f64() {
                                f.into_pyobject(py).unwrap().into_any().unbind()
                            } else {
                                py.None()
                            }
                        }
                        serde_json::Value::String(s) => {
                            s.into_pyobject(py).unwrap().into_any().unbind()
                        }
                        serde_json::Value::Bool(b) => (*b)
                            .into_pyobject(py)
                            .unwrap()
                            .to_owned()
                            .into_any()
                            .unbind(),
                        _ => v.to_string().into_pyobject(py).unwrap().into_any().unbind(),
                    };
                    params_dict.set_item(k, py_val)?;
                }
                dict.set_item("params", params_dict)?;
                let metrics_dict = PyDict::new(py);
                for m in &trial.metrics {
                    metrics_dict.set_item(&m.name, m.value)?;
                }
                dict.set_item("metrics", metrics_dict)?;
                Ok(Some(dict.into_any().unbind()))
            }
            None => Ok(None),
        }
    }

    #[getter]
    fn n_trials(&self) -> usize {
        self.study.trials.len()
    }

    #[getter]
    fn progress(&self) -> f64 {
        self.study.progress()
    }
}

// ── PyGraph ──

#[pyclass(name = "Graph")]
struct PyGraph {
    graph: Graph,
    library: FilterLibrary,
    cache: Arc<dyn somatize_core::cache::CacheStore>,
    event_bus: Arc<EventBus>,
    fitted: bool,
    /// Registered remote workers: (address, token, tags).
    workers: Vec<(String, Option<String>, Vec<String>)>,
    /// Coordinator URL + token.
    coordinator: Option<(String, Option<String>)>,
    /// Pickled filter bytes + requirements for remote serialization.
    /// node_id → (cloudpickle bytes, pip requirements)
    pickled_filters: std::collections::HashMap<String, (Vec<u8>, Vec<String>)>,
    /// Module source code per filter for Nous agent introspection/editing.
    /// node_id → full module source (imports + classes + helpers)
    filter_sources: std::collections::HashMap<String, String>,
    /// Optional DataStore for persistent data transport (opt-in, costs storage).
    data_store: Option<Arc<dyn somatize_core::store::DataStore>>,
}

impl PyGraph {
    /// Build a remote executor from registered workers (if any).
    fn make_remote_executor(&self) -> Option<Arc<dyn somatize_runtime::executor::RemoteExecutor>> {
        if self.workers.is_empty() {
            return None;
        }
        let executor = somatize_worker::WsRemoteExecutor::new();
        for (addr, token, tags) in &self.workers {
            executor.add_worker(addr, token.clone(), tags.clone());
        }
        Some(Arc::new(executor))
    }

    /// Send a Shutdown message to a worker via WebSocket.
    fn send_shutdown(address: &str, token: Option<&str>, reason: &str) -> PyResult<()> {
        use somatize_worker::protocol::CoordinatorToWorker;

        let rt = tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .map_err(|e| PyRuntimeError::new_err(format!("tokio: {e}")))?;

        rt.block_on(async {
            let url = if let Some(t) = token {
                format!("{address}/ws?token={t}")
            } else {
                format!("{address}/ws")
            };

            let (mut ws, _) = tokio_tungstenite::connect_async(&url)
                .await
                .map_err(|e| PyRuntimeError::new_err(format!("WS connect: {e}")))?;

            use futures_util::SinkExt;
            use tokio_tungstenite::tungstenite::Message;

            let msg = CoordinatorToWorker::Shutdown {
                reason: reason.to_string(),
            };
            let json = serde_json::to_string(&msg)
                .map_err(|e| PyRuntimeError::new_err(format!("serialize: {e}")))?;

            ws.send(Message::Text(json.into()))
                .await
                .map_err(|e| PyRuntimeError::new_err(format!("WS send: {e}")))?;

            Ok(())
        })
    }

    /// Decide how to transport input data to the worker.
    ///
    /// - DataStore configured → upload to store, return Reference
    /// - Large payload (≥ 10MB) → HTTP bulk upload to worker, return Reference
    /// - Small payload → Inline (current WS behavior)
    fn resolve_transport(
        &self,
        x: &Value,
        addr: &str,
        token: &Option<String>,
    ) -> Result<somatize_worker::protocol::InputSource, PyErr> {
        use somatize_core::cache::CacheKey;
        use somatize_worker::protocol::InputSource;

        // DataStore configured → always use it (user opted in)
        if let Some(store) = &self.data_store {
            let data_bytes = serde_json::to_vec(x).unwrap_or_default();
            let key = CacheKey::hash_data(&data_bytes);
            let data_ref = store.put(&key, x).map_err(soma_err_to_py)?;
            return Ok(InputSource::Reference { data_ref });
        }

        // Estimate payload size
        let size_bytes = serde_json::to_vec(x).map(|v| v.len()).unwrap_or(0);
        if size_bytes >= somatize_core::store::INLINE_THRESHOLD_BYTES {
            let data_ref = self.http_upload(x, addr, token)?;
            return Ok(InputSource::Reference { data_ref });
        }

        Ok(InputSource::Inline { value: x.clone() })
    }

    /// Upload a Value to the worker via HTTP POST /upload (msgpack body).
    fn http_upload(
        &self,
        value: &Value,
        addr: &str,
        token: &Option<String>,
    ) -> Result<somatize_core::store::DataRef, PyErr> {
        // Worker addr is like "ws://host:port" — convert to HTTP
        let http_addr = addr
            .replace("ws://", "http://")
            .replace("wss://", "https://");
        let url = format!("{http_addr}/upload");

        let body = rmp_serde::to_vec(value)
            .map_err(|e| PyRuntimeError::new_err(format!("msgpack serialize: {e}")))?;

        let client = reqwest::blocking::Client::new();
        let mut req = client
            .post(&url)
            .header("Content-Type", "application/msgpack")
            .body(body);

        if let Some(t) = token {
            req = req.query(&[("token", t.as_str())]);
        }

        let resp = req
            .send()
            .map_err(|e| PyRuntimeError::new_err(format!("HTTP upload: {e}")))?;

        if !resp.status().is_success() {
            return Err(PyRuntimeError::new_err(format!(
                "HTTP upload failed: {}",
                resp.status()
            )));
        }

        let data_ref: somatize_core::store::DataRef = resp
            .json()
            .map_err(|e| PyRuntimeError::new_err(format!("parse upload response: {e}")))?;

        Ok(data_ref)
    }

    /// Send a plan to a remote worker via WebSocket.
    /// Returns (output, trained_states) — states are non-empty after Fit mode.
    fn dispatch_to_worker(
        &self,
        x: &Value,
        mode: somatize_worker::protocol::ExecutionMode,
    ) -> Result<(Value, std::collections::HashMap<String, Value>), PyErr> {
        use somatize_worker::protocol::*;

        let compile_mode = match &mode {
            ExecutionMode::Fit { .. } => CompileMode::NoCache,
            ExecutionMode::Forward => CompileMode::Inference,
            _ => CompileMode::Inference,
        };

        let compile_result = somatize_compiler::compile(
            &self.graph,
            &self.library,
            compile_mode,
            Some(self.cache.as_ref()),
        )
        .map_err(soma_err_to_py)?;

        // Find the best worker by target tag or first available
        let first_target = self
            .graph
            .nodes
            .iter()
            .find_map(|n| n.target.as_deref())
            .unwrap_or("default");

        let (addr, token) = self
            .workers
            .iter()
            .find(|(_, _, tags)| {
                first_target == "default" || tags.contains(&first_target.to_string())
            })
            .or_else(|| self.workers.first())
            .map(|(a, t, _)| (a.clone(), t.clone()))
            .ok_or_else(|| PyRuntimeError::new_err("no workers available"))?;

        // Serialize filters with cloudpickle bytes so the worker can reconstruct them
        let filters: Vec<SerializedFilter> = self
            .graph
            .nodes
            .iter()
            .filter_map(|node| {
                let (pickled, reqs) = self.pickled_filters.get(&node.id)?;
                let state = self.library.get_state(&node.id).cloned();
                Some(SerializedFilter {
                    node_id: node.id.clone(),
                    pickled_filter: pickled.clone(),
                    state,
                    requirements: reqs.clone(),
                })
            })
            .collect();

        let input_source = self.resolve_transport(x, &addr, &token)?;
        let plan = SerializedPlan {
            plan_id: somatize_core::util::timestamp_id("remote_plan"),
            plan: compile_result.plan,
            input: Some(input_source),
            filters,
            mode,
            metadata: serde_json::json!({}),
        };

        let rt = tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .map_err(|e| PyRuntimeError::new_err(format!("tokio: {e}")))?;

        rt.block_on(async {
            let url = if let Some(t) = &token {
                format!("{addr}/ws?token={t}")
            } else {
                format!("{addr}/ws")
            };

            let (mut ws, _) = tokio_tungstenite::connect_async(&url)
                .await
                .map_err(|e| PyRuntimeError::new_err(format!("WS connect: {e}")))?;

            use futures_util::{SinkExt, StreamExt};
            use tokio_tungstenite::tungstenite::Message;

            let msg = CoordinatorToWorker::AssignPlan { plan };
            let json = serde_json::to_string(&msg)
                .map_err(|e| PyRuntimeError::new_err(format!("serialize: {e}")))?;

            ws.send(Message::Text(json.into()))
                .await
                .map_err(|e| PyRuntimeError::new_err(format!("WS send: {e}")))?;

            while let Some(Ok(Message::Text(response))) = ws.next().await {
                if let Ok(result) = serde_json::from_str::<WorkerToCoordinator>(&response) {
                    match result {
                        WorkerToCoordinator::PlanResult { result, .. } => match result {
                            PlanResult::Success { output, states, .. } => {
                                let _ = ws.close(None).await;
                                return Ok((output, states));
                            }
                            PlanResult::Failed { error, .. } => {
                                let _ = ws.close(None).await;
                                return Err(PyRuntimeError::new_err(format!("remote: {error}")));
                            }
                        },
                        _ => continue,
                    }
                }
            }

            Err(PyRuntimeError::new_err("worker closed without result"))
        })
    }

    /// Stream data to a worker in chunks via WebSocket Binary frames.
    /// Chunks are processed by StreamExecutor on the worker — no full materialization.
    fn dispatch_streamed(&self, x: &Value, chunk_size: usize) -> Result<Value, PyErr> {
        use somatize_worker::protocol::*;

        let compile_result = somatize_compiler::compile(
            &self.graph,
            &self.library,
            CompileMode::Inference,
            Some(self.cache.as_ref()),
        )
        .map_err(soma_err_to_py)?;

        let first_target = self
            .graph
            .nodes
            .iter()
            .find_map(|n| n.target.as_deref())
            .unwrap_or("default");

        let (addr, token) = self
            .workers
            .iter()
            .find(|(_, _, tags)| {
                first_target == "default" || tags.contains(&first_target.to_string())
            })
            .or_else(|| self.workers.first())
            .map(|(a, t, _)| (a.clone(), t.clone()))
            .ok_or_else(|| PyRuntimeError::new_err("no workers available"))?;

        let filters: Vec<SerializedFilter> = self
            .graph
            .nodes
            .iter()
            .filter_map(|node| {
                let (pickled, reqs) = self.pickled_filters.get(&node.id)?;
                let state = self.library.get_state(&node.id).cloned();
                Some(SerializedFilter {
                    node_id: node.id.clone(),
                    pickled_filter: pickled.clone(),
                    state,
                    requirements: reqs.clone(),
                })
            })
            .collect();

        // Split Value into chunks
        let chunks = Self::chunk_value(x, chunk_size);
        let total_chunks = chunks.len();
        let stream_id = somatize_core::util::timestamp_id("stream");

        let plan = SerializedPlan {
            plan_id: stream_id.clone(),
            plan: compile_result.plan,
            input: None, // input comes via chunks
            filters,
            mode: ExecutionMode::Forward,
            metadata: serde_json::json!({}),
        };

        let rt = tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .map_err(|e| PyRuntimeError::new_err(format!("tokio: {e}")))?;

        rt.block_on(async {
            let url = if let Some(t) = &token {
                format!("{addr}/ws?token={t}")
            } else {
                format!("{addr}/ws")
            };

            let (mut ws, _) = tokio_tungstenite::connect_async(&url)
                .await
                .map_err(|e| PyRuntimeError::new_err(format!("WS connect: {e}")))?;

            use futures_util::{SinkExt, StreamExt};
            use tokio_tungstenite::tungstenite::Message;

            // 1. Send StreamBegin
            let begin = StreamMessage::StreamBegin {
                stream_id: stream_id.clone(),
                plan_id: stream_id.clone(),
                total_chunks: Some(total_chunks),
                plan: Box::new(plan),
            };
            let bytes = rmp_serde::to_vec(&begin)
                .map_err(|e| PyRuntimeError::new_err(format!("msgpack: {e}")))?;
            ws.send(Message::Binary(bytes.into()))
                .await
                .map_err(|e| PyRuntimeError::new_err(format!("WS send: {e}")))?;

            // 2. Send chunks
            for (i, chunk) in chunks.into_iter().enumerate() {
                let chunk_msg = StreamMessage::ChunkData {
                    stream_id: stream_id.clone(),
                    chunk_index: i,
                    value: chunk,
                };
                let bytes = rmp_serde::to_vec(&chunk_msg)
                    .map_err(|e| PyRuntimeError::new_err(format!("msgpack: {e}")))?;
                ws.send(Message::Binary(bytes.into()))
                    .await
                    .map_err(|e| PyRuntimeError::new_err(format!("WS send chunk: {e}")))?;

                // Drain any ChunkResults that came back
                while let Ok(Some(Ok(Message::Binary(resp)))) =
                    tokio::time::timeout(std::time::Duration::from_millis(1), ws.next()).await
                {
                    // ChunkResults are collected but not blocking
                    let _ = rmp_serde::from_slice::<StreamMessage>(&resp);
                }
            }

            // 3. Send StreamEnd
            let end = StreamMessage::StreamEnd {
                stream_id: stream_id.clone(),
            };
            let bytes = rmp_serde::to_vec(&end)
                .map_err(|e| PyRuntimeError::new_err(format!("msgpack: {e}")))?;
            ws.send(Message::Binary(bytes.into()))
                .await
                .map_err(|e| PyRuntimeError::new_err(format!("WS send end: {e}")))?;

            // 4. Wait for StreamComplete
            while let Some(Ok(msg)) = ws.next().await {
                if let Message::Binary(resp) = msg
                    && let Ok(StreamMessage::StreamComplete { result, .. }) =
                        rmp_serde::from_slice(&resp)
                {
                    match result {
                        PlanResult::Success { output, .. } => return Ok(output),
                        PlanResult::Failed { error, .. } => {
                            return Err(PyRuntimeError::new_err(format!("stream error: {error}")));
                        }
                    }
                }
            }

            Err(PyRuntimeError::new_err("stream closed without result"))
        })
    }

    /// Split a Value into chunks for streaming.
    fn chunk_value(x: &Value, chunk_size: usize) -> Vec<Value> {
        match x {
            Value::Tensor { values, shape } if !values.is_empty() => {
                // Split along first dimension
                let row_size = if shape.len() > 1 {
                    shape[1..].iter().product()
                } else {
                    1
                };
                let n_rows = shape[0];
                let mut chunks = Vec::new();
                for start in (0..n_rows).step_by(chunk_size) {
                    let end = (start + chunk_size).min(n_rows);
                    let flat_start = start * row_size;
                    let flat_end = end * row_size;
                    let chunk_vals = values[flat_start..flat_end].to_vec();
                    let mut chunk_shape = shape.clone();
                    chunk_shape[0] = end - start;
                    chunks.push(Value::tensor(chunk_vals, chunk_shape));
                }
                chunks
            }
            // For non-tensor or small data, single chunk
            _ => vec![x.clone()],
        }
    }
}

#[pymethods]
impl PyGraph {
    #[new]
    fn new() -> Self {
        Self {
            graph: Graph::new(),
            library: FilterLibrary::new(),
            cache: Arc::new(MemoryCache::default()),
            event_bus: Arc::new(EventBus::new(256)),
            fitted: false,
            workers: Vec::new(),
            coordinator: None,
            pickled_filters: std::collections::HashMap::new(),
            filter_sources: std::collections::HashMap::new(),
            data_store: None,
        }
    }

    /// Add a filter node. Returns the node id.
    ///
    /// Usage:
    ///   g.node(MyFilter())                        # auto-named
    ///   g.node("scaler", MyFilter())              # explicit id
    ///   g.node(MyFilter(), target="gpu")           # route to gpu worker
    ///   g.node("model", MyFilter(), target="local") # force local execution
    #[pyo3(signature = (*args, target=None))]
    fn node(
        &mut self,
        py: Python<'_>,
        args: &Bound<'_, pyo3::types::PyTuple>,
        target: Option<String>,
    ) -> PyResult<String> {
        let (node_id, filter_obj) = match args.len() {
            1 => {
                let filter_obj = args.get_item(0)?;
                let class_name = filter_obj
                    .getattr("__class__")?
                    .getattr("__name__")?
                    .extract::<String>()?;
                let snake = to_snake_case(&class_name);
                (snake, filter_obj.to_owned())
            }
            2 => {
                let id = args.get_item(0)?.extract::<String>()?;
                let filter_obj = args.get_item(1)?;
                (id, filter_obj.to_owned())
            }
            n => {
                return Err(pyo3::exceptions::PyValueError::new_err(format!(
                    "node() takes 1 or 2 positional arguments, got {n}"
                )));
            }
        };

        let bridge = PyFilterBridge::new(py, &filter_obj)?;

        // Handle duplicate node ids
        let actual_id = if self.graph.node(&node_id).is_some() {
            let mut i = 2;
            loop {
                let candidate = format!("{node_id}_{i}");
                if self.graph.node(&candidate).is_none() {
                    break candidate;
                }
                i += 1;
            }
        } else {
            node_id.clone()
        };

        let mut node = Node::filter_with_id(&actual_id, &bridge.name);
        if let Some(t) = target {
            node = node.with_target(t);
        }
        self.graph.add_node(node);

        // Store pickled bytes + requirements for remote execution, source for Nous
        self.pickled_filters.insert(
            actual_id.clone(),
            (bridge.pickled_bytes.clone(), bridge.requirements.clone()),
        );
        self.filter_sources
            .insert(actual_id.clone(), bridge.source.clone());
        self.library.register(actual_id.clone(), Box::new(bridge));

        Ok(actual_id)
    }

    /// Connect two nodes with a data edge.
    fn edge(&mut self, source: String, target: String) {
        let id = format!("e_{}", self.graph.edges.len());
        self.graph.add_edge(Edge::data(id, source, target));
    }

    /// Alias for edge().
    fn connect(&mut self, source: String, target: String) {
        self.edge(source, target);
    }

    /// Fit all trainable filters in topological order.
    ///
    /// If workers are registered and no node forces local, training is
    /// dispatched to a remote worker. Trained states are returned and
    /// stored locally so that subsequent forward() calls include them.
    #[pyo3(signature = (x, y=None))]
    fn fit(
        &mut self,
        py: Python<'_>,
        x: &Bound<'_, pyo3::types::PyAny>,
        y: Option<&Bound<'_, pyo3::types::PyAny>>,
    ) -> PyResult<()> {
        let x_val = py_to_value(py, x)?;
        let y_val = match y {
            Some(v) => Some(py_to_value(py, v)?),
            None => None,
        };

        // Dispatch fit to worker if possible
        if !self.workers.is_empty() && self.graph.nodes.iter().all(|n| !n.is_local()) {
            let mode = somatize_worker::protocol::ExecutionMode::Fit { y: y_val.clone() };
            let (_output, states) = self.dispatch_to_worker(&x_val, mode)?;
            // Store trained states locally for future forward() calls
            for (node_id, state) in states {
                self.library.set_state(&node_id, state);
            }
            self.fitted = true;
            return Ok(());
        }

        // Local fit
        self.graph.validate().map_err(soma_err_to_py)?;
        let sorted = self.graph.topological_sort().map_err(soma_err_to_py)?;
        let graph_info = GraphInfo::from_graph(&self.graph);
        let run_id = somatize_core::util::timestamp_id("graph_fit");

        let roots = self.graph.roots();
        let mut outputs: std::collections::HashMap<String, Value> =
            std::collections::HashMap::new();
        for root_id in &roots {
            outputs.insert(format!("__input_{root_id}"), x_val.clone());
        }

        for node_id in &sorted {
            let filter = self
                .library
                .get(node_id)
                .ok_or_else(|| PyRuntimeError::new_err(format!("filter not found: {node_id}")))?;

            self.event_bus
                .emit(somatize_core::event::Event::NodeStarted {
                    run_id: run_id.clone(),
                    node_id: node_id.to_string(),
                    kind: filter.meta().kind,
                });

            let preds = graph_info.predecessors(node_id);
            let input = match preds.len() {
                0 => x_val.clone(),
                1 => outputs
                    .get(&preds[0])
                    .cloned()
                    .unwrap_or_else(|| x_val.clone()),
                _ => {
                    let mut merged = serde_json::Map::new();
                    for pred_id in preds {
                        if let Some(val) = outputs.get(pred_id.as_str()) {
                            let json_val =
                                serde_json::to_value(val).unwrap_or(serde_json::Value::Null);
                            merged.insert(pred_id.clone(), json_val);
                        }
                    }
                    Value::Json(serde_json::Value::Object(merged))
                }
            };

            let meta = filter.meta();
            let start = std::time::Instant::now();

            let output = if meta.kind == somatize_core::filter::FilterKind::Trainable {
                let data_hash = somatize_core::cache::CacheKey::hash_data(
                    &serde_json::to_vec(&input).unwrap_or_default(),
                );
                let state_key =
                    somatize_core::cache::CacheKey::for_state(&filter.config_hash(), &data_hash);

                let state = if let Ok(Some(cached)) = self.cache.get(&state_key) {
                    cached
                } else {
                    let s = filter.fit(&input, y_val.as_ref()).map_err(soma_err_to_py)?;
                    let _ = self.cache.put(&state_key, &s);
                    s
                };

                let out = filter.forward(&input, &state).map_err(soma_err_to_py)?;
                self.library.set_state(node_id.to_string(), state);
                out
            } else {
                filter
                    .forward(&input, &Value::Empty)
                    .map_err(soma_err_to_py)?
            };

            self.event_bus
                .emit(somatize_core::event::Event::NodeCompleted {
                    run_id: run_id.clone(),
                    node_id: node_id.to_string(),
                    duration: start.elapsed(),
                    output_summary: format!("{output}"),
                });

            outputs.insert(node_id.to_string(), output);
        }

        self.fitted = true;
        Ok(())
    }

    /// Forward data through the compiled graph (inference mode).
    ///
    /// Routing:
    /// - stream=True → chunks sent via WS Binary to StreamExecutor on worker
    /// - No workers → local execution
    /// - Workers + all nodes non-local → entire plan dispatched to worker
    /// - Workers + mixed (some local) → local execution with remote fallback
    #[pyo3(signature = (x, stream=false, chunk_size=1024))]
    fn forward(
        &self,
        py: Python<'_>,
        x: &Bound<'_, pyo3::types::PyAny>,
        stream: bool,
        chunk_size: usize,
    ) -> PyResult<PyObject> {
        if !self.fitted {
            return Err(PyRuntimeError::new_err(
                "graph must be fitted before forward",
            ));
        }
        let x_val = py_to_value(py, x)?;

        // Streaming mode: send chunks via WS Binary
        if stream && !self.workers.is_empty() {
            let output = self.dispatch_streamed(&x_val, chunk_size)?;
            return value_to_py(py, &output);
        }

        // Dispatch entire plan remotely if workers registered and no node forces local
        if !self.workers.is_empty() && self.graph.nodes.iter().all(|n| !n.is_local()) {
            let (output, _states) =
                self.dispatch_to_worker(&x_val, somatize_worker::protocol::ExecutionMode::Forward)?;
            return value_to_py(py, &output);
        }

        // Local execution (with optional remote executor for mixed graphs)
        let compile_result = somatize_compiler::compile(
            &self.graph,
            &self.library,
            CompileMode::Inference,
            Some(self.cache.as_ref()),
        )
        .map_err(soma_err_to_py)?;

        let graph_info = GraphInfo::from_graph(&self.graph);
        let mut ctx = Context::new(
            self.event_bus.clone(),
            somatize_core::util::timestamp_id("graph_forward"),
        )
        .with_graph_info(graph_info);

        if let Some(remote) = self.make_remote_executor() {
            ctx = ctx.with_remote_executor(remote);
        }

        let roots = self.graph.roots();
        if roots.len() == 1 {
            ctx.set(format!("__input_{}", roots[0]), x_val.clone());
        }
        ctx.set("__input__", x_val);

        executor::execute(
            &compile_result.plan,
            &mut ctx,
            &self.library,
            self.cache.as_ref(),
        )
        .map_err(soma_err_to_py)?;

        let leaves = self.graph.leaves();
        let output = if let Some(leaf_id) = leaves.first() {
            ctx.store
                .remove(*leaf_id)
                .and_then(|vv| vv.as_value().cloned())
                .unwrap_or(Value::Empty)
        } else {
            ctx.execution_order
                .last()
                .and_then(|id| ctx.store.remove(id))
                .and_then(|vv| vv.as_value().cloned())
                .unwrap_or(Value::Empty)
        };

        value_to_py(py, &output)
    }

    /// Compile and execute, returning all node outputs as a dict.
    fn run(&self, py: Python<'_>) -> PyResult<PyObject> {
        let compile_result = somatize_compiler::compile(
            &self.graph,
            &self.library,
            CompileMode::NoCache,
            Some(self.cache.as_ref()),
        )
        .map_err(soma_err_to_py)?;

        let graph_info = GraphInfo::from_graph(&self.graph);
        let mut ctx = Context::new(
            self.event_bus.clone(),
            somatize_core::util::timestamp_id("graph_run"),
        )
        .with_graph_info(graph_info);

        if let Some(remote) = self.make_remote_executor() {
            ctx = ctx.with_remote_executor(remote);
        }

        executor::execute(
            &compile_result.plan,
            &mut ctx,
            &self.library,
            self.cache.as_ref(),
        )
        .map_err(soma_err_to_py)?;

        let dict = PyDict::new(py);
        for (k, vv) in &ctx.store {
            if let Some(v) = vv.as_value() {
                dict.set_item(k, value_to_py(py, v)?)?;
            }
        }
        Ok(dict.into_any().unbind())
    }

    /// Compile the graph and return diagnostic information.
    #[pyo3(signature = (mode="inference"))]
    fn compile(&self, py: Python<'_>, mode: &str) -> PyResult<PyObject> {
        let compile_mode = match mode {
            "inference" => CompileMode::Inference,
            "differentiable" => CompileMode::Differentiable,
            "no_cache" => CompileMode::NoCache,
            _ => {
                return Err(PyRuntimeError::new_err(format!(
                    "Unknown mode: {mode}. Use 'inference', 'differentiable', or 'no_cache'."
                )));
            }
        };

        let result = somatize_compiler::compile(
            &self.graph,
            &self.library,
            compile_mode,
            Some(self.cache.as_ref()),
        )
        .map_err(soma_err_to_py)?;

        let dict = PyDict::new(py);
        let summary = result.plan.summary();
        dict.set_item("total_nodes", summary.total_nodes)?;
        dict.set_item("cached_nodes", summary.cached_nodes)?;
        dict.set_item("parallel_branches", summary.parallel_branches)?;

        let diags = PyList::empty(py);
        for d in &result.diagnostics {
            diags.append(format!("{d:?}"))?;
        }
        dict.set_item("diagnostics", diags)?;
        dict.set_item("plan_text", format!("{}", result.plan))?;
        dict.set_item("plan_mermaid", result.plan.to_mermaid())?;

        Ok(dict.into_any().unbind())
    }

    // ── Visualization ──

    /// Render the graph as a Mermaid diagram string.
    fn to_mermaid(&self) -> String {
        self.graph.to_mermaid()
    }

    /// Render the graph as a Graphviz DOT string.
    fn to_graphviz(&self) -> String {
        self.graph.to_graphviz()
    }

    /// Render the graph as an ASCII text tree.
    fn to_text(&self) -> String {
        self.graph.to_text()
    }

    // ── Events ──

    /// Register a Python callback to receive events during execution.
    ///
    /// The callback is called with a dict for each event. Events are
    /// delivered in a background thread; the callback must be thread-safe.
    ///
    /// Usage:
    /// ```python
    /// def on_event(event):
    ///     print(event["event_type"], event.get("node_id", ""))
    /// g.on_event(on_event)
    /// g.fit(data)
    /// ```
    fn on_event(&self, callback: PyObject) -> PyResult<()> {
        let mut rx = self.event_bus.subscribe();
        std::thread::spawn(move || {
            while let Ok(event) = rx.blocking_recv() {
                if let Ok(json_str) = serde_json::to_string(&event) {
                    Python::with_gil(|py| {
                        // Parse JSON string into Python dict via json.loads
                        let json_mod = py.import("json").unwrap();
                        if let Ok(dict) = json_mod.call_method1("loads", (json_str,)) {
                            let _ = callback.call1(py, (dict,));
                        }
                    });
                }
            }
        });
        Ok(())
    }

    // ── Workers ──

    /// Register a remote worker for direct connection (mode B).
    ///
    /// Usage:
    ///   g.add_worker("ws://gpu-0:8080", token="sk-xxx", tags=["gpu"])
    #[pyo3(signature = (address, token=None, tags=None))]
    fn add_worker(&mut self, address: String, token: Option<String>, tags: Option<Vec<String>>) {
        self.workers
            .push((address, token, tags.unwrap_or_default()));
    }

    /// Configure a DataStore for persistent data transport (opt-in).
    ///
    /// When set, large payloads are uploaded to the store and workers read
    /// via DataRef instead of receiving data inline or via HTTP upload.
    ///
    /// Usage:
    ///   g.set_data_store("local", path="/data/soma")
    ///   g.set_data_store("s3", bucket="my-lab", prefix="exp/",
    ///                    endpoint="s3.amazonaws.com",
    ///                    access_key="AK...", secret_key="SK...")
    #[pyo3(signature = (store_type, path=None, bucket=None, prefix=None, endpoint=None, access_key=None, secret_key=None, cache_dir=None))]
    #[allow(clippy::too_many_arguments)]
    fn set_data_store(
        &mut self,
        store_type: String,
        path: Option<String>,
        bucket: Option<String>,
        prefix: Option<String>,
        endpoint: Option<String>,
        access_key: Option<String>,
        secret_key: Option<String>,
        cache_dir: Option<String>,
    ) -> PyResult<()> {
        match store_type.as_str() {
            "local" => {
                let p = path.ok_or_else(|| {
                    pyo3::exceptions::PyValueError::new_err("local store requires 'path'")
                })?;
                let store = somatize_core::store::LocalDataStore::new(p);
                self.data_store = Some(Arc::new(store));
                Ok(())
            }
            "s3" => {
                let bucket = bucket.ok_or_else(|| {
                    pyo3::exceptions::PyValueError::new_err("s3 store requires 'bucket'")
                })?;
                let prefix = prefix.unwrap_or_default();
                let endpoint = endpoint.ok_or_else(|| {
                    pyo3::exceptions::PyValueError::new_err("s3 store requires 'endpoint'")
                })?;
                let ak = access_key
                    .or_else(|| std::env::var("AWS_ACCESS_KEY_ID").ok())
                    .ok_or_else(|| {
                        pyo3::exceptions::PyValueError::new_err(
                            "s3 store requires 'access_key' or AWS_ACCESS_KEY_ID env var",
                        )
                    })?;
                let sk = secret_key
                    .or_else(|| std::env::var("AWS_SECRET_ACCESS_KEY").ok())
                    .ok_or_else(|| {
                        pyo3::exceptions::PyValueError::new_err(
                            "s3 store requires 'secret_key' or AWS_SECRET_ACCESS_KEY env var",
                        )
                    })?;
                let cache = cache_dir.unwrap_or_else(|| {
                    std::env::temp_dir()
                        .join(format!("soma-s3-cache-{bucket}"))
                        .to_string_lossy()
                        .to_string()
                });
                let store =
                    somatize_core::store::S3DataStore::new(bucket, prefix, endpoint, ak, sk, cache)
                        .map_err(soma_err_to_py)?;
                self.data_store = Some(Arc::new(store));
                Ok(())
            }
            other => Err(pyo3::exceptions::PyValueError::new_err(format!(
                "unknown store type: '{other}'. Available: local, s3"
            ))),
        }
    }

    /// Shutdown a specific worker by address.
    ///
    /// Usage:
    ///   g.shutdown_worker("ws://worker:8080")
    ///   g.shutdown_worker("ws://worker:8080", reason="maintenance")
    #[pyo3(signature = (address, reason=None))]
    fn shutdown_worker(&self, address: String, reason: Option<String>) -> PyResult<()> {
        let token = self
            .workers
            .iter()
            .find(|(a, _, _)| *a == address)
            .and_then(|(_, t, _)| t.clone());
        Self::send_shutdown(&address, token.as_deref(), &reason.unwrap_or_default())
    }

    /// Shutdown all registered workers.
    ///
    /// Usage:
    ///   g.shutdown_workers()
    ///   g.shutdown_workers(reason="end of experiment")
    #[pyo3(signature = (reason=None))]
    fn shutdown_workers(&self, reason: Option<String>) -> PyResult<()> {
        let reason = reason.unwrap_or_default();
        for (addr, token, _) in &self.workers {
            if let Err(e) = Self::send_shutdown(addr, token.as_deref(), &reason) {
                eprintln!("Warning: failed to shutdown {addr}: {e}");
            }
        }
        Ok(())
    }

    /// Set a coordinator for auto-discovery (mode C).
    ///
    /// Usage:
    ///   g.set_coordinator("http://coord:9090", token="sk-xxx")
    #[pyo3(signature = (url, token=None))]
    fn set_coordinator(&mut self, url: String, token: Option<String>) {
        self.coordinator = Some((url, token));
    }

    /// List known workers (from add_worker or coordinator).
    ///
    /// Returns a list of dicts with worker info.
    fn workers(&self, py: Python<'_>) -> PyResult<PyObject> {
        let list = PyList::empty(py);

        // Direct workers
        for (addr, _token, tags) in &self.workers {
            let dict = PyDict::new(py);
            dict.set_item("address", addr)?;
            dict.set_item("tags", tags)?;
            dict.set_item("source", "direct")?;
            list.append(dict)?;
        }

        // If coordinator is set, query it for registered workers
        if let Some((url, token)) = &self.coordinator {
            let workers_url = format!("{url}/workers");
            // Synchronous HTTP request (blocking in Python context is fine)
            let client = reqwest::blocking::Client::new();
            let mut request = client.get(&workers_url);
            if let Some(t) = token {
                request = request.query(&[("token", t.as_str())]);
            }
            if let Ok(resp) = request.send()
                && let Ok(text) = resp.text()
            {
                let json_mod = py.import("json")?;
                if let Ok(parsed) = json_mod.call_method1("loads", (text,))
                    && let Ok(items) = parsed.downcast::<PyList>()
                {
                    for item in items.iter() {
                        list.append(item)?;
                    }
                }
            }
        }

        Ok(list.into_any().unbind())
    }

    /// Get the full module source code for a filter node (for Nous agent introspection).
    /// Returns None if the node has no captured source.
    fn filter_source(&self, node_id: String) -> Option<String> {
        self.filter_sources.get(&node_id).cloned()
    }

    /// Get all filter sources as a dict: {node_id: source_code}.
    fn filter_sources_dict(&self, py: Python<'_>) -> PyResult<PyObject> {
        let dict = PyDict::new(py);
        for (node_id, source) in &self.filter_sources {
            dict.set_item(node_id, source)?;
        }
        Ok(dict.into_any().unbind())
    }

    /// Number of nodes in the graph.
    fn __len__(&self) -> usize {
        self.graph.nodes.len()
    }

    fn __repr__(&self) -> String {
        let n = self.graph.nodes.len();
        let e = self.graph.edges.len();
        format!(
            "Graph({n} nodes, {e} edges, fitted={fitted})",
            fitted = self.fitted
        )
    }

    fn __str__(&self) -> String {
        self.graph.to_text()
    }
}

fn to_snake_case(name: &str) -> String {
    name.chars()
        .enumerate()
        .fold(String::new(), |mut s, (i, c)| {
            if c.is_uppercase() && i > 0 {
                s.push('_');
            }
            s.push(c.to_ascii_lowercase());
            s
        })
}

// ── PyWorker ──

/// A Soma worker that can be started from Python.
///
/// Usage:
///   from soma import Worker
///   w = Worker(port=8080, tags=["gpu", "training"], token="sk-xxx")
///   w.serve()  # blocks, serving requests
#[pyclass(name = "Worker")]
struct PyWorker {
    port: u16,
    tags: Vec<String>,
    token: Option<String>,
    cpus: Option<usize>,
    memory: Option<u64>,
    gpus: Option<usize>,
    max_concurrent: usize,
    worker_id: Option<String>,
    coordinator: Option<String>,
}

#[allow(clippy::too_many_arguments)]
#[pymethods]
impl PyWorker {
    #[new]
    #[pyo3(signature = (port=8080, tags=None, token=None, cpus=None, memory=None, gpus=None, max_concurrent=4, worker_id=None, coordinator=None))]
    fn new(
        port: u16,
        tags: Option<Vec<String>>,
        token: Option<String>,
        cpus: Option<usize>,
        memory: Option<u64>,
        gpus: Option<usize>,
        max_concurrent: usize,
        worker_id: Option<String>,
        coordinator: Option<String>,
    ) -> Self {
        Self {
            port,
            tags: tags.unwrap_or_default(),
            token,
            cpus,
            memory,
            gpus,
            max_concurrent,
            worker_id,
            coordinator,
        }
    }

    /// Start the worker server (blocking).
    fn serve(&self) -> PyResult<()> {
        let port = self.port;
        let tags = self.tags.clone();
        let token = self.token.clone();
        let cpus = self.cpus;
        let memory = self.memory;
        let gpus = self.gpus;
        let max_concurrent = self.max_concurrent;
        let worker_id = self.worker_id.clone();
        let coordinator = self.coordinator.clone();

        // Build the runtime in a new thread to avoid GIL issues
        std::thread::spawn(move || {
            let rt = tokio::runtime::Runtime::new().unwrap();
            rt.block_on(async move {
                // Auto-detect capabilities
                let mut caps = somatize_worker::protocol::Capabilities::detect();
                let limits = somatize_worker::detect::ResourceLimits {
                    max_cpus: cpus,
                    max_memory_bytes: memory,
                    max_gpus: gpus,
                    max_concurrent,
                };
                caps = caps.with_limits(&limits);
                for tag in &tags {
                    if !caps.tags.contains(tag) {
                        caps.tags.push(tag.clone());
                    }
                }

                let id = worker_id.unwrap_or_else(|| {
                    hostname::get()
                        .map(|h| h.to_string_lossy().to_string())
                        .unwrap_or_else(|_| format!("worker_{}", std::process::id()))
                });

                eprintln!("Soma worker '{id}' starting on port {port}");
                eprintln!("Capabilities: {}", caps.summary());

                let worker = somatize_worker::Worker::new(&id, caps.clone());
                let addr = format!("0.0.0.0:{port}");

                // Register with coordinator if configured
                if let Some(coord_url) = &coordinator {
                    let url = format!("{coord_url}/register");
                    let body = serde_json::json!({
                        "worker_id": id,
                        "address": format!("ws://0.0.0.0:{port}"),
                        "capabilities": caps,
                    });
                    let mut req = reqwest::Client::new().post(&url).json(&body);
                    if let Some(t) = &token {
                        req = req.query(&[("token", t.as_str())]);
                    }
                    match req.send().await {
                        Ok(resp) if resp.status().is_success() => {
                            eprintln!("Registered with coordinator at {coord_url}");
                        }
                        Ok(resp) => {
                            eprintln!("Coordinator registration failed: {}", resp.status());
                        }
                        Err(e) => {
                            eprintln!("Could not reach coordinator: {e}");
                        }
                    }
                }

                if let Some(t) = token {
                    eprintln!("Authentication enabled");
                    somatize_worker::serve_worker_authenticated(worker, &addr, &t)
                        .await
                        .unwrap();
                } else {
                    somatize_worker::serve_worker(worker, &addr).await.unwrap();
                }
            });
        })
        .join()
        .map_err(|_| PyRuntimeError::new_err("worker thread panicked"))?;

        Ok(())
    }

    /// Get the worker info as a dict.
    fn info(&self) -> PyResult<String> {
        let caps = somatize_worker::protocol::Capabilities::detect();
        Ok(caps.summary())
    }

    fn __repr__(&self) -> String {
        format!(
            "Worker(port={}, tags={:?}, auth={})",
            self.port,
            self.tags,
            self.token.is_some()
        )
    }
}

// ── Module ──

#[pymodule]
fn _soma(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PyGraph>()?;
    m.add_class::<PyStudy>()?;
    m.add_class::<PyWorker>()?;
    m.add("__version__", "0.2.5")?;
    Ok(())
}
