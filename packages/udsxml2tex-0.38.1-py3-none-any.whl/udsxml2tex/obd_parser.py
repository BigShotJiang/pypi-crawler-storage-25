"""OBD (ISO 15031) and WWH-OBD (ISO 27145) ARXML parser and model classes."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


# ---------------------------------------------------------------------------
# Module-level constant: well-known OBD mode/PID names
# ---------------------------------------------------------------------------

OBD_STANDARD_PIDS: dict[tuple[int, int], str] = {
    (1, 0x00): "PIDs supported [01-20]",
    (1, 0x01): "Monitor status since DTCs cleared",
    (1, 0x04): "Calculated engine load",
    (1, 0x05): "Engine coolant temperature",
    (1, 0x0C): "Engine speed",
    (1, 0x0D): "Vehicle speed",
    (1, 0x1C): "OBD standards this vehicle conforms to",
    (2, 0x02): "DTC that caused freeze frame",
    (3, 0x00): "Fuel system status",
    (9, 0x02): "Vehicle Identification Number (VIN)",
}


# ---------------------------------------------------------------------------
# Model classes
# ---------------------------------------------------------------------------


@dataclass
class ObdPid:
    """OBD Parameter ID (PID) definition."""

    short_name: str
    mode: int = 1       # OBD mode (1-9)
    pid: int = 0        # Parameter ID
    description: str = ""
    formula: str = ""
    unit: str = ""
    min_value: float = 0.0
    max_value: float = 0.0
    byte_size: int = 1

    @property
    def pid_hex(self) -> str:
        return f"0x{self.pid:02X}"

    @property
    def mode_str(self) -> str:
        return f"Mode 0{self.mode:X}"


@dataclass
class ObdConfig:
    """OBD / WWH-OBD configuration extracted from ARXML."""

    pids: list[ObdPid] = field(default_factory=list)
    supported_modes: list[int] = field(default_factory=list)   # 1..9
    wwh_obd_enabled: bool = False
    obd_mid_count: int = 0
    obd_dtc_availability_mask: int = 0


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------


class ObdParser:
    """Parse OBD / WWH-OBD configuration from DCM and DEM ARXML elements."""

    _AR_NS_URI = "http://autosar.org/schema/r4.0"

    # ---- helpers -----------------------------------------------------------

    @staticmethod
    def _build_ns(ns: str) -> dict[str, str]:
        if ns:
            return {"ar": ObdParser._AR_NS_URI}
        return {}

    @staticmethod
    def _xpath_text(el, path: str, ns: str, default: str = "") -> str:
        ns_map = ObdParser._build_ns(ns)
        try:
            if ns_map:
                results = el.xpath(path, namespaces=ns_map)
            else:
                import re as _re
                results = el.xpath(_re.sub(r"ar:", "", path))
        except Exception:
            return default
        if results:
            from lxml import etree as _etree
            first = results[0]
            if isinstance(first, _etree._Element):
                return (first.text or "").strip() or default
            return str(first).strip() or default
        return default

    @staticmethod
    def _xpath_int(el, path: str, ns: str, default: int = 0) -> int:
        text = ObdParser._xpath_text(el, path, ns, "")
        if text:
            try:
                return int(text, 0)
            except (ValueError, TypeError):
                pass
        return default

    @staticmethod
    def _xpath_float(el, path: str, ns: str, default: float = 0.0) -> float:
        text = ObdParser._xpath_text(el, path, ns, "")
        if text:
            try:
                return float(text)
            except ValueError:
                pass
        return default

    @staticmethod
    def _xpath_els(el, path: str, ns: str) -> list:
        ns_map = ObdParser._build_ns(ns)
        try:
            if ns_map:
                return el.xpath(path, namespaces=ns_map)
            import re as _re
            return el.xpath(_re.sub(r"ar:", "", path))
        except Exception:
            return []

    # ---- OBD DID range: DCM DID IDs 0xF400-0xF4FF are OBD PIDs --------------

    def _parse_obd_dids(self, root, ns: str, config: ObdConfig) -> None:
        """Extract OBD PIDs from DcmDspDid containers with DID IDs in 0xF400-0xF4FF."""
        did_containers = self._xpath_els(
            root,
            f".//{ns}DcmDspDid | .//{ns}DCM-DSP-DID",
            ns,
        )
        for did_el in did_containers:
            # Read the DID identifier value
            id_text = (
                self._xpath_text(did_el, f"{ns}DcmDspDidIdentifier", ns)
                or self._xpath_text(did_el, f"{ns}DCM-DSP-DID-IDENTIFIER", ns)
            )
            if not id_text:
                continue
            try:
                did_id = int(id_text, 0)
            except (ValueError, TypeError):
                continue

            # OBD PID range: 0xF400-0xF4FF
            if not (0xF400 <= did_id <= 0xF4FF):
                continue

            sn = (
                self._xpath_text(did_el, f"{ns}SHORT-NAME", ns)
                or self._xpath_text(did_el, f"{ns}ShortName", ns)
            )
            if not sn:
                sn = f"OBD_DID_{did_id:04X}"

            pid_byte = did_id & 0xFF
            # Mode is encoded in bits 8-11 (nibble), but convention varies;
            # default to mode 1 for the 0xF4xx range (OBD mode 1 / current data).
            mode = 1

            description = (
                self._xpath_text(did_el, f"{ns}DcmDspDidDesc/{ns}L-2", ns)
                or self._xpath_text(did_el, f"{ns}LONG-NAME", ns)
                or OBD_STANDARD_PIDS.get((mode, pid_byte), "")
            )

            config.pids.append(
                ObdPid(
                    short_name=sn,
                    mode=mode,
                    pid=pid_byte,
                    description=description,
                )
            )

            if mode not in config.supported_modes:
                config.supported_modes.append(mode)

    # ---- WWH-OBD: DEM ObdInfoGroup / OBD-INFO-GROUP containers -------------

    def _parse_obd_info_groups(self, root, ns: str, config: ObdConfig) -> None:
        """Look for ObdInfoGroup or OBD-INFO-GROUP containers to detect WWH-OBD."""
        obd_groups = self._xpath_els(
            root,
            f".//{ns}ObdInfoGroup | .//{ns}OBD-INFO-GROUP",
            ns,
        )
        if obd_groups:
            config.wwh_obd_enabled = True

        # Count OBD MIDs (monitoring identifiers)
        mid_containers = self._xpath_els(
            root,
            f".//{ns}DcmDspObdMid | .//{ns}DCM-DSP-OBD-MID",
            ns,
        )
        config.obd_mid_count = len(mid_containers)

        # DTC availability mask from DEM general or DCM general
        mask_text = (
            self._xpath_text(root, f".//{ns}DemObdDtcAvailabilityMask", ns)
            or self._xpath_text(root, f".//{ns}DEM-OBD-DTC-AVAILABILITY-MASK", ns)
            or self._xpath_text(root, f".//{ns}DcmObdDtcAvailabilityMask", ns)
        )
        if mask_text:
            try:
                config.obd_dtc_availability_mask = int(mask_text, 0)
            except (ValueError, TypeError):
                pass

    # ---- public API --------------------------------------------------------

    def parse(self, root, ns: str = "") -> ObdConfig:
        """Parse OBD / WWH-OBD configuration from lxml root element.

        Args:
            root: lxml etree element (root of ARXML document).
            ns:   Namespace prefix with colon, e.g. ``""`` or ``"ar:"``.

        Returns:
            Populated :class:`ObdConfig`.
        """
        config = ObdConfig()
        self._parse_obd_dids(root, ns, config)
        self._parse_obd_info_groups(root, ns, config)
        # Sort supported modes for consistent output
        config.supported_modes.sort()
        return config


__all__ = [
    "OBD_STANDARD_PIDS",
    "ObdConfig",
    "ObdParser",
    "ObdPid",
]
