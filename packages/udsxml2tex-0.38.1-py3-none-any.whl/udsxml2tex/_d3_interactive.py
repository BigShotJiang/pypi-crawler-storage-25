"""D3.js-based interactive visualizations for the HTML ZIP output.

Produces a self-contained HTML page (`interactive.html`) embedding a D3 v7
force-directed graph of the UDS specification's Sessions, Services, DIDs, and
Routines, with click-through filtering and a sidebar inspector panel.

The D3 library is loaded from a CDN (no bundling) — works offline once the
page has been visited once and the asset is cached, but does require initial
network access. To bundle D3 instead, drop `d3.v7.min.js` into the ZIP and
swap the <script src="..."> URL.

Public API:
    render_interactive_page(spec, ecu_name) -> str   # full HTML page
    spec_to_d3_json(spec) -> dict                     # serialisable graph data
"""

from __future__ import annotations

import json
from typing import Any


def spec_to_d3_json(spec: Any) -> dict:
    """Convert a UdsSpecification into a {nodes, links} dict for D3."""
    nodes: list[dict] = []
    links: list[dict] = []

    # Nodes
    for s in (spec.sessions or []):
        nodes.append({
            "id": f"sess:{s.session_id}",
            "label": s.short_name,
            "type": "session",
            "hex": f"0x{s.session_id:02X}",
        })
    for sec in (spec.security_levels or []):
        nodes.append({
            "id": f"sec:{sec.security_level}",
            "label": sec.short_name,
            "type": "security",
            "hex": f"0x{sec.security_level:02X}",
        })
    for svc in (spec.services or []):
        nodes.append({
            "id": f"svc:{svc.service_id}",
            "label": svc.short_name,
            "type": "service",
            "hex": f"0x{svc.service_id:02X}",
            "sub_funcs": len(svc.sub_functions or []),
            "nrcs": len(svc.nrc_list or []),
        })
    for did in (spec.dids or []):
        nodes.append({
            "id": f"did:{did.did_id}",
            "label": did.short_name,
            "type": "did",
            "hex": f"0x{did.did_id:04X}",
            "read": bool(did.read_access),
            "write": bool(did.write_access),
        })
    for rt in (spec.routines or []):
        nodes.append({
            "id": f"rid:{rt.routine_id}",
            "label": rt.short_name,
            "type": "routine",
            "hex": f"0x{rt.routine_id:04X}",
            "ops": (
                ("S" if rt.start_supported else "")
                + ("X" if rt.stop_supported else "")
                + ("R" if rt.result_supported else "")
            ),
        })

    # Index by short name for cross-references
    sess_by_name = {s.short_name: f"sess:{s.session_id}"
                    for s in (spec.sessions or [])}
    sec_by_name = {s.short_name: f"sec:{s.security_level}"
                   for s in (spec.security_levels or [])}

    # Service → session links
    for svc in (spec.services or []):
        for sname in (svc.supported_sessions or []):
            target = sess_by_name.get(sname)
            if target:
                links.append({"source": f"svc:{svc.service_id}",
                              "target": target, "kind": "supports"})
        for sname in (svc.required_security_levels or []):
            target = sec_by_name.get(sname)
            if target:
                links.append({"source": f"svc:{svc.service_id}",
                              "target": target, "kind": "requires-sec"})

    # DID → session / security
    for did in (spec.dids or []):
        for sname in (did.supported_sessions or []):
            target = sess_by_name.get(sname)
            if target:
                links.append({"source": f"did:{did.did_id}",
                              "target": target, "kind": "supports"})
        for sname in (did.required_security_levels or []):
            target = sec_by_name.get(sname)
            if target:
                links.append({"source": f"did:{did.did_id}",
                              "target": target, "kind": "requires-sec"})
        # DIDs are operated on by 0x22 (read) and 0x2E (write)
        if did.read_access:
            for svc in (spec.services or []):
                if svc.service_id == 0x22:
                    links.append({"source": f"svc:{svc.service_id}",
                                  "target": f"did:{did.did_id}",
                                  "kind": "reads"})
                    break
        if did.write_access:
            for svc in (spec.services or []):
                if svc.service_id == 0x2E:
                    links.append({"source": f"svc:{svc.service_id}",
                                  "target": f"did:{did.did_id}",
                                  "kind": "writes"})
                    break

    # Routine → session / security; RoutineControl 0x31 → routines
    for rt in (spec.routines or []):
        for sname in (rt.supported_sessions or []):
            target = sess_by_name.get(sname)
            if target:
                links.append({"source": f"rid:{rt.routine_id}",
                              "target": target, "kind": "supports"})
        for sname in (rt.required_security_levels or []):
            target = sec_by_name.get(sname)
            if target:
                links.append({"source": f"rid:{rt.routine_id}",
                              "target": target, "kind": "requires-sec"})
        for svc in (spec.services or []):
            if svc.service_id == 0x31:
                links.append({"source": f"svc:{svc.service_id}",
                              "target": f"rid:{rt.routine_id}",
                              "kind": "controls"})
                break

    return {"nodes": nodes, "links": links}


def render_interactive_page(spec: Any, ecu_name: str = "") -> str:
    """Return a full self-contained HTML page with D3 force-directed graph."""
    data = spec_to_d3_json(spec)
    json_blob = json.dumps(data, ensure_ascii=False)

    return r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>UDS Spec — Interactive Graph (""" + ecu_name + r""")</title>
<script src="https://d3js.org/d3.v7.min.js"></script>
<style>
* { box-sizing: border-box; }
body { margin: 0; font-family: Georgia, serif; background: #f4f3ef; color: #111; }
#container { display: flex; height: 100vh; }
#graph { flex: 1; background: #ffffff; }
#panel { width: 320px; padding: 1.2em; background: #fafafa; border-left: 1px solid #c8c8c4;
         font-family: Arial, sans-serif; font-size: 13px; overflow-y: auto; }
#panel h1 { font-family: Georgia, serif; font-size: 1.2em; margin-top: 0;
            border-bottom: 2px solid #111; padding-bottom: 0.3em; }
#panel h2 { font-family: Georgia, serif; font-size: 1em; margin-top: 1.2em;
            border-bottom: 1px solid #999; padding-bottom: 0.15em; }
#panel .hex { font-family: 'Courier New', monospace; background: #ebebea; padding: 1px 5px; }
#legend span { display: inline-block; width: 12px; height: 12px; margin-right: 4px;
               border-radius: 50%; vertical-align: middle; }
#legend li { margin: 3px 0; list-style: none; }
.toolbar { padding: 6px 12px; background: #3a3a3a; color: #ddd; font-size: 12px; font-family: Arial, sans-serif; }
.toolbar button { background: #555; color: #eee; border: 1px solid #444; padding: 3px 10px;
                  margin-right: 6px; cursor: pointer; font-family: inherit; }
.toolbar button:hover { background: #666; }
.toolbar input[type=text] { padding: 3px 6px; background: #444; color: #eee; border: 1px solid #555; }
.node { stroke: #fff; stroke-width: 1px; cursor: pointer; }
.node.dim { opacity: 0.15; }
.link { stroke: #aaa; stroke-opacity: 0.4; fill: none; }
.link.highlight { stroke: #cc4400; stroke-opacity: 0.9; stroke-width: 2px; }
.label { font-size: 9px; font-family: Arial, sans-serif; pointer-events: none; fill: #222; }
</style>
</head>
<body>
<div id="container">
  <div style="flex:1; display:flex; flex-direction:column;">
    <div class="toolbar">
      <button id="btn-reset">Reset</button>
      <input type="text" id="search" placeholder="Search by name…" size="20">
      <label style="margin-left:1em"><input type="checkbox" id="show-labels" checked> Labels</label>
      <span style="margin-left:1em">""" + ecu_name + r"""</span>
    </div>
    <svg id="graph"></svg>
  </div>
  <aside id="panel">
    <h1>UDS Spec Inspector</h1>
    <div id="info">
      <p>Click a node to inspect. Drag nodes to reposition. Search to highlight.</p>
    </div>
    <h2>Legend</h2>
    <ul id="legend">
      <li><span style="background:#2a6e2a"></span>Session</li>
      <li><span style="background:#996600"></span>Security level</li>
      <li><span style="background:#334466"></span>Service</li>
      <li><span style="background:#aa2222"></span>DID</li>
      <li><span style="background:#664488"></span>Routine</li>
    </ul>
    <h2>Statistics</h2>
    <div id="stats"></div>
  </aside>
</div>
<script>
const data = """ + json_blob + r""";

const colorMap = {
  session: '#2a6e2a',
  security: '#996600',
  service: '#334466',
  did: '#aa2222',
  routine: '#664488',
};
const radiusMap = { session: 10, security: 10, service: 9, did: 7, routine: 7 };

const svg = d3.select('#graph');
let width = window.innerWidth - 320;
let height = window.innerHeight - 36;
svg.attr('viewBox', [0, 0, width, height]);

const g = svg.append('g');
const linkSel = g.append('g').selectAll('line').data(data.links).enter()
  .append('line').attr('class', 'link');
const nodeSel = g.append('g').selectAll('circle').data(data.nodes).enter()
  .append('circle').attr('class', 'node')
  .attr('r', d => radiusMap[d.type] || 6)
  .attr('fill', d => colorMap[d.type] || '#888')
  .on('click', (e, d) => inspect(d));
const labelSel = g.append('g').selectAll('text').data(data.nodes).enter()
  .append('text').attr('class', 'label')
  .text(d => d.hex)
  .attr('dx', 8).attr('dy', 3);

const sim = d3.forceSimulation(data.nodes)
  .force('link', d3.forceLink(data.links).id(d => d.id).distance(60))
  .force('charge', d3.forceManyBody().strength(-180))
  .force('center', d3.forceCenter(width / 2, height / 2))
  .force('collide', d3.forceCollide().radius(d => (radiusMap[d.type] || 6) + 4))
  .on('tick', () => {
    linkSel.attr('x1', d => d.source.x).attr('y1', d => d.source.y)
           .attr('x2', d => d.target.x).attr('y2', d => d.target.y);
    nodeSel.attr('cx', d => d.x).attr('cy', d => d.y);
    labelSel.attr('x', d => d.x).attr('y', d => d.y);
  });

nodeSel.call(d3.drag()
  .on('start', (e, d) => { if (!e.active) sim.alphaTarget(0.3).restart(); d.fx = d.x; d.fy = d.y; })
  .on('drag',  (e, d) => { d.fx = e.x; d.fy = e.y; })
  .on('end',   (e, d) => { if (!e.active) sim.alphaTarget(0); d.fx = null; d.fy = null; })
);

svg.call(d3.zoom().scaleExtent([0.3, 4]).on('zoom', e => g.attr('transform', e.transform)));

function inspect(d) {
  const neighbors = new Set([d.id]);
  data.links.forEach(l => {
    const sId = l.source.id || l.source;
    const tId = l.target.id || l.target;
    if (sId === d.id) neighbors.add(tId);
    if (tId === d.id) neighbors.add(sId);
  });
  nodeSel.classed('dim', n => !neighbors.has(n.id));
  linkSel.classed('highlight', l => {
    const sId = l.source.id || l.source;
    const tId = l.target.id || l.target;
    return sId === d.id || tId === d.id;
  });
  let html = '<h2>' + escapeHtml(d.label) + '</h2>';
  html += '<p><strong>Type:</strong> ' + d.type + '</p>';
  html += '<p><strong>ID:</strong> <span class="hex">' + d.hex + '</span></p>';
  if (d.sub_funcs !== undefined) html += '<p><strong>Sub-functions:</strong> ' + d.sub_funcs + '</p>';
  if (d.nrcs !== undefined) html += '<p><strong>NRCs:</strong> ' + d.nrcs + '</p>';
  if (d.read !== undefined) html += '<p><strong>Read:</strong> ' + (d.read ? '✓' : '—') + '</p>';
  if (d.write !== undefined) html += '<p><strong>Write:</strong> ' + (d.write ? '✓' : '—') + '</p>';
  if (d.ops) html += '<p><strong>Ops:</strong> ' + d.ops + '</p>';
  document.getElementById('info').innerHTML = html;
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}

document.getElementById('btn-reset').onclick = () => {
  nodeSel.classed('dim', false);
  linkSel.classed('highlight', false);
  document.getElementById('info').innerHTML = '<p>Click a node to inspect.</p>';
};
document.getElementById('search').oninput = e => {
  const q = e.target.value.toLowerCase().trim();
  if (!q) {
    nodeSel.classed('dim', false);
    return;
  }
  nodeSel.classed('dim', n => !(n.label.toLowerCase().includes(q) || n.hex.toLowerCase().includes(q)));
};
document.getElementById('show-labels').onchange = e => {
  labelSel.style('display', e.target.checked ? 'block' : 'none');
};

// Stats
const counts = {};
data.nodes.forEach(n => counts[n.type] = (counts[n.type] || 0) + 1);
document.getElementById('stats').innerHTML =
  '<ul style="padding-left:1em;list-style:disc;">' +
  Object.entries(counts).map(([k, v]) =>
    '<li><strong>' + k + ':</strong> ' + v + '</li>'
  ).join('') +
  '<li><strong>links:</strong> ' + data.links.length + '</li></ul>';

window.addEventListener('resize', () => {
  width = window.innerWidth - 320;
  height = window.innerHeight - 36;
  svg.attr('viewBox', [0, 0, width, height]);
  sim.force('center', d3.forceCenter(width / 2, height / 2)).alpha(0.3).restart();
});
</script>
</body>
</html>
"""
