"""Optional rich-based CLI output formatting.

Provides colored, tabular CLI output for --validate, --diff and --dry-run.
Falls back gracefully to plain text when the `rich` package is not installed.

Public helpers:
    use_rich() -> bool                    — True when rich is available
    print_validation(result)              — colored validation summary + issue table
    print_dry_run(spec, parser_warnings)  — formatted dry-run summary tables
    print_diff_markdown(diff_md, fallback) — render markdown diff with rich, or print plaintext
"""

from __future__ import annotations

from typing import Any, Iterable

try:  # pragma: no cover - optional dependency probe
    from rich.console import Console
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text

    _RICH_AVAILABLE = True
except ImportError:  # pragma: no cover - tested via runtime path
    _RICH_AVAILABLE = False


def use_rich() -> bool:
    """Return True when the optional `rich` package is importable."""
    return _RICH_AVAILABLE


_SEVERITY_STYLE = {
    "error":   ("ERROR", "bold red"),
    "warning": ("WARN ", "bold yellow"),
    "info":    ("INFO ", "cyan"),
}


def print_validation(result: Any) -> None:
    """Print a validation result with colored severities and a summary panel."""
    if not _RICH_AVAILABLE:
        # Fallback — plain text identical to the legacy formatter.
        print(f"\n{'=' * 60}")
        print(f"  Validation Result: {result.summary()}")
        print(f"{'=' * 60}")
        for issue in result.issues:
            prefix = _SEVERITY_STYLE.get(issue.severity, (issue.severity.upper(), ""))[0]
            item = f" [{issue.item_id}]" if issue.item_id else ""
            print(f"  [{prefix}] [{issue.category}]{item} {issue.message}")
        print(f"{'=' * 60}\n")
        return

    console = Console()
    has_errors = result.has_errors()
    title_style = "bold red" if has_errors else "bold green"
    console.print(Panel.fit(
        Text(f"Validation Result: {result.summary()}", style=title_style),
        title="udsxml2tex --validate",
        border_style=title_style,
    ))

    if not result.issues:
        console.print("[green]✓ No issues found.[/green]\n")
        return

    table = Table(show_header=True, header_style="bold", border_style="dim")
    table.add_column("Severity", width=8)
    table.add_column("Category", width=18)
    table.add_column("ID", width=14)
    table.add_column("Message", overflow="fold")
    for issue in result.issues:
        prefix, style = _SEVERITY_STYLE.get(issue.severity, (issue.severity.upper(), ""))
        table.add_row(
            Text(prefix.strip(), style=style),
            issue.category,
            issue.item_id or "—",
            issue.message,
        )
    console.print(table)
    console.print()


def print_dry_run(spec: Any, parser_warnings: Iterable[Any] = ()) -> None:
    """Print a dry-run parsed-summary in rich tables."""
    from udsxml2tex.models import UDS_SERVICE_NAMES

    if not _RICH_AVAILABLE:
        return _print_dry_run_plain(spec, parser_warnings)

    console = Console()
    console.print(Panel.fit(
        Text(f"ECU: {spec.ecu_name}    Protocol: {spec.protocol_name}", style="bold cyan"),
        title="udsxml2tex --dry-run",
        border_style="cyan",
    ))

    counts = Table(title="Inventory", show_header=False, border_style="dim", expand=False)
    counts.add_column("Item", style="bold")
    counts.add_column("Count", justify="right", style="cyan")
    items = [
        ("Diagnostic Sessions",   len(spec.sessions)),
        ("Security Levels",       len(spec.security_levels)),
        ("UDS Services",          len(spec.services)),
        ("DIDs",                  len(spec.dids)),
        ("Routines",              len(spec.routines)),
        ("DTCs",                  len(spec.dtcs)),
        ("Memory Ranges",         len(spec.memory_ranges)),
        ("IO Control DIDs",       len(spec.io_control_dids)),
        ("Periodic DIDs",         len(spec.periodic_dids)),
        ("DID Ranges",            len(spec.did_ranges)),
        ("Dynamic DIDs",          len(spec.dynamic_dids)),
    ]
    for label, n in items:
        counts.add_row(label, str(n))
    console.print(counts)

    if spec.sessions:
        sess = Table(title="Sessions", border_style="dim")
        sess.add_column("ID")
        sess.add_column("Name")
        sess.add_column("P2 (s)", justify="right")
        sess.add_column("P2* (s)", justify="right")
        for s in sorted(spec.sessions, key=lambda x: x.session_id):
            sess.add_row(
                f"0x{s.session_id:02X}", s.short_name,
                f"{s.p2_server_max}", f"{s.p2_star_server_max}",
            )
        console.print(sess)

    if spec.services:
        svc = Table(title="Services", border_style="dim")
        svc.add_column("SID")
        svc.add_column("Name")
        svc.add_column("Sub-funcs", justify="right")
        svc.add_column("NRCs", justify="right")
        for s in sorted(spec.services, key=lambda x: x.service_id):
            name = UDS_SERVICE_NAMES.get(s.service_id, s.short_name)
            svc.add_row(
                f"0x{s.service_id:02X}", name,
                str(len(s.sub_functions)), str(len(s.nrc_list)),
            )
        console.print(svc)

    warnings = list(parser_warnings)
    if warnings:
        warn_t = Table(title="Parser Warnings", border_style="yellow")
        warn_t.add_column("Section", style="yellow")
        warn_t.add_column("Message", overflow="fold")
        for w in warnings:
            warn_t.add_row(w.section, w.message)
        console.print(warn_t)


def _print_dry_run_plain(spec: Any, parser_warnings: Iterable[Any]) -> None:
    """Plain text dry-run summary used when rich is unavailable."""
    from udsxml2tex.models import UDS_SERVICE_NAMES

    print(f"\n{'=' * 60}")
    print(f"  udsxml2tex -- Dry Run Summary")
    print(f"{'=' * 60}")
    print(f"  ECU Name:          {spec.ecu_name}")
    print(f"  Protocol:          {spec.protocol_name}")
    if spec.protocol_type:
        print(f"  Protocol Type:     {spec.protocol_type}")
    print(f"  S3 Server Timeout: {spec.s3_server} s")
    print()
    print(f"  Sessions:          {len(spec.sessions)}")
    for s in sorted(spec.sessions, key=lambda x: x.session_id):
        print(f"    0x{s.session_id:02X} - {s.short_name} "
              f"(P2={s.p2_server_max}s, P2*={s.p2_star_server_max}s)")
    print(f"  Security Levels:   {len(spec.security_levels)}")
    for s in sorted(spec.security_levels, key=lambda x: x.security_level):
        print(f"    Level {s.security_level} - {s.short_name} "
              f"(seed={s.seed_size}B, key={s.key_size}B)")
    print(f"  Services:          {len(spec.services)}")
    for s in sorted(spec.services, key=lambda x: x.service_id):
        name = UDS_SERVICE_NAMES.get(s.service_id, s.short_name)
        print(f"    0x{s.service_id:02X} - {name} "
              f"({len(s.sub_functions)} sub-functions, {len(s.nrc_list)} NRCs)")
    print(f"  DIDs:              {len(spec.dids)}")
    print(f"  Routines:          {len(spec.routines)}")
    print(f"  DTCs:              {len(spec.dtcs)}")
    print(f"  Memory Ranges:     {len(spec.memory_ranges)}")
    print(f"  IO Control DIDs:   {len(spec.io_control_dids)}")
    print(f"  Periodic DIDs:     {len(spec.periodic_dids)}")
    print(f"  DID Ranges:        {len(spec.did_ranges)}")
    print(f"  Dynamic DIDs:      {len(spec.dynamic_dids)}")
    if spec.transport_config:
        print(f"  CanTp Channels:    {len(spec.transport_config.channels)}")
        print(f"  CAN-FD:            {'Yes' if spec.transport_config.can_fd_enabled else 'No'}")
    warnings = list(parser_warnings)
    if warnings:
        print(f"\n  Warnings:          {len(warnings)}")
        for w in warnings:
            print(f"    [{w.section}] {w.message}")
    print(f"\n{'=' * 60}")


def print_diff_markdown(diff_md: str) -> None:
    """Render a Markdown diff report with rich, or fall back to plain output."""
    if not _RICH_AVAILABLE:
        print(diff_md)
        return
    console = Console()
    console.print(Markdown(diff_md))
