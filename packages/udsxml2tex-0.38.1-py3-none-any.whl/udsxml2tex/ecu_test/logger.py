"""Test result serialization — JSON, CSV, HTML, JUnit XML, and coverage HTML."""

from __future__ import annotations

import csv
import json
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Optional

from .models import StepResult, TestCaseResult, TestSuiteResult

if TYPE_CHECKING:
    from .coverage import CoverageReport

# ---------------------------------------------------------------------------
# JSON
# ---------------------------------------------------------------------------

def _step_to_dict(sr: StepResult) -> dict:
    return {
        "step": sr.step.name,
        "description": sr.step.description,
        "request_hex": sr.step.request_hex,
        "expected_response": sr.step.expected_response,
        "expected_nrc": (
            f"0x{sr.step.expected_nrc:02X}" if sr.step.expected_nrc is not None else None
        ),
        "passed": sr.passed,
        "actual_response_hex": sr.actual_response_hex or None,
        "actual_nrc": (
            f"0x{sr.actual_nrc:02X}" if sr.actual_nrc is not None else None
        ),
        "elapsed_ms": round(sr.elapsed_ms, 2),
        "error": sr.error,
    }


def _case_to_dict(r: TestCaseResult) -> dict:
    return {
        "tc_id": r.tc.tc_id,
        "category": r.tc.category,
        "title": r.tc.title,
        "description": r.tc.description,
        "verdict": r.verdict,
        "elapsed_ms": round(r.elapsed_ms, 2),
        "started_at": r.started_at.isoformat(),
        "error_message": r.error_message,
        "steps": [_step_to_dict(sr) for sr in r.step_results],
    }


def write_json(suite: TestSuiteResult, path: "str | Path") -> None:
    """Write a full JSON report to *path*."""
    data = {
        "spec_name": suite.spec_name,
        "interface": suite.interface,
        "channel": suite.channel,
        "started_at": suite.started_at.isoformat(),
        "elapsed_ms": round(suite.elapsed_ms, 2),
        "summary": {
            "total": suite.total,
            "passed": suite.passed,
            "failed": suite.failed,
            "errors": suite.errors,
            "skipped": suite.skipped,
            "pass_rate_pct": round(suite.pass_rate, 1),
        },
        "results": [_case_to_dict(r) for r in suite.results],
    }
    Path(path).write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


# ---------------------------------------------------------------------------
# CSV
# ---------------------------------------------------------------------------

_CSV_FIELDS = [
    "tc_id", "category", "title", "verdict",
    "elapsed_ms", "error_message", "started_at",
]


def write_csv(suite: TestSuiteResult, path: "str | Path") -> None:
    """Write a one-row-per-test-case CSV summary to *path*."""
    with open(path, "w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=_CSV_FIELDS)
        writer.writeheader()
        for r in suite.results:
            writer.writerow({
                "tc_id": r.tc.tc_id,
                "category": r.tc.category,
                "title": r.tc.title,
                "verdict": r.verdict,
                "elapsed_ms": round(r.elapsed_ms, 2),
                "error_message": r.error_message or "",
                "started_at": r.started_at.isoformat(),
            })


# ---------------------------------------------------------------------------
# HTML
# ---------------------------------------------------------------------------

_VERDICT_COLOR = {
    "PASS":  "#28a745",
    "FAIL":  "#dc3545",
    "ERROR": "#fd7e14",
    "SKIP":  "#6c757d",
}

_HTML_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>UDS ECU Test Report — {spec_name}</title>
<style>
  body {{font-family: Georgia, serif; margin: 2rem; color: #212529; background: #f8f9fa;}}
  h1 {{font-size: 1.6rem; margin-bottom: 0.25rem;}}
  .meta {{color: #6c757d; font-size: 0.85rem; margin-bottom: 1.5rem;}}
  .summary {{display: flex; gap: 1.5rem; margin-bottom: 2rem; flex-wrap: wrap;}}
  .kpi {{background: #fff; border: 1px solid #dee2e6; border-radius: 6px;
          padding: 0.75rem 1.25rem; min-width: 100px; text-align: center;}}
  .kpi .val {{font-size: 1.8rem; font-weight: bold;}}
  .kpi .lbl {{font-size: 0.75rem; color: #6c757d; text-transform: uppercase;}}
  table {{width: 100%; border-collapse: collapse; background: #fff;
          box-shadow: 0 1px 3px rgba(0,0,0,.08);}}
  th {{background: #343a40; color: #fff; padding: 0.6rem 0.75rem; text-align: left;
       font-size: 0.82rem;}}
  td {{padding: 0.55rem 0.75rem; border-bottom: 1px solid #dee2e6; font-size: 0.83rem;
       vertical-align: top;}}
  tr:hover td {{background: #f1f3f5;}}
  .badge {{display: inline-block; padding: 0.2em 0.55em; border-radius: 3px;
            font-size: 0.75rem; font-weight: bold; color: #fff;}}
  details summary {{cursor: pointer; color: #0d6efd;}}
  .step-table {{width: 100%; margin-top: 0.4rem; border-collapse: collapse;}}
  .step-table td {{font-size: 0.78rem; padding: 0.3rem 0.5rem;
                   border-bottom: 1px solid #e9ecef;}}
  code {{background: #e9ecef; padding: 0.1em 0.35em; border-radius: 3px; font-size: 0.85em;}}
</style>
</head>
<body>
<h1>UDS ECU Test Report</h1>
<div class="meta">
  <strong>ECU / Spec:</strong> {spec_name} &nbsp;|&nbsp;
  <strong>Interface:</strong> {interface} &nbsp;|&nbsp;
  <strong>Channel:</strong> {channel} &nbsp;|&nbsp;
  <strong>Started:</strong> {started_at} &nbsp;|&nbsp;
  <strong>Duration:</strong> {elapsed_s:.1f} s
</div>
<div class="summary">
  <div class="kpi"><div class="val">{total}</div><div class="lbl">Total</div></div>
  <div class="kpi" style="border-color:#28a745">
    <div class="val" style="color:#28a745">{passed}</div><div class="lbl">Passed</div>
  </div>
  <div class="kpi" style="border-color:#dc3545">
    <div class="val" style="color:#dc3545">{failed}</div><div class="lbl">Failed</div>
  </div>
  <div class="kpi" style="border-color:#fd7e14">
    <div class="val" style="color:#fd7e14">{errors}</div><div class="lbl">Errors</div>
  </div>
  <div class="kpi" style="border-color:#6c757d">
    <div class="val" style="color:#6c757d">{skipped}</div><div class="lbl">Skipped</div>
  </div>
  <div class="kpi"><div class="val">{pass_rate:.0f}%</div><div class="lbl">Pass Rate</div></div>
</div>
<table>
  <thead>
    <tr>
      <th>#</th><th>ID</th><th>Category</th><th>Title</th>
      <th>Verdict</th><th>Time (ms)</th><th>Steps</th>
    </tr>
  </thead>
  <tbody>
{rows}
  </tbody>
</table>
</body>
</html>
"""

_ROW_TEMPLATE = """\
    <tr>
      <td>{idx}</td>
      <td><code>{tc_id}</code></td>
      <td>{category}</td>
      <td>{title}{rationale_cell}</td>
      <td><span class="badge" style="background:{color}">{verdict}</span></td>
      <td style="text-align:right">{elapsed_ms:.0f}</td>
      <td>
        <details>
          <summary>{step_count} step(s){error_note}</summary>
          <table class="step-table">
            <tr><th>Step</th><th>Request</th><th>OK?</th><th>Response</th><th>Note</th></tr>
            {step_rows}
          </table>
        </details>
      </td>
    </tr>"""

_STEP_ROW = (
    "<tr><td><code>{name}</code></td>"
    "<td><code>{req}</code></td>"
    "<td>{ok}</td>"
    "<td><code>{resp}</code></td>"
    "<td>{note}</td></tr>"
)


def _escape(s: str) -> str:
    return (
        s.replace("&", "&amp;")
         .replace("<", "&lt;")
         .replace(">", "&gt;")
         .replace('"', "&quot;")
    )


def _render_step_rows(step_results: list[StepResult]) -> str:
    parts = []
    for sr in step_results:
        parts.append(_STEP_ROW.format(
            name=_escape(sr.step.name),
            req=_escape(sr.step.request_hex[:40]),
            ok="✓" if sr.passed else "✗",
            resp=_escape((sr.actual_response_hex or "")[:40]),
            note=_escape(sr.error or ""),
        ))
    return "\n            ".join(parts)


def write_html(
    suite: TestSuiteResult,
    path: "str | Path",
    rationales: Optional[dict] = None,
) -> None:
    """Write a self-contained HTML report to *path*.

    Args:
        suite: Completed test suite result.
        path: Destination file path.
        rationales: Optional dict mapping ``tc_id`` → rationale string from
            ``llm_integration.generate_test_rationale()``.  When supplied, each
            row shows an italicised WHY-note beneath the title.
    """
    rows_html = []
    for i, r in enumerate(suite.results, start=1):
        color = _VERDICT_COLOR.get(r.verdict, "#6c757d")
        error_note = f" — {_escape(r.error_message)}" if r.error_message else ""
        rat = (rationales or {}).get(r.tc.tc_id, "")
        rationale_cell = (
            f"<br><small style='color:#6c757d;font-style:italic'>{_escape(rat)}</small>"
            if rat else ""
        )
        rows_html.append(_ROW_TEMPLATE.format(
            idx=i,
            tc_id=_escape(r.tc.tc_id),
            category=_escape(r.tc.category),
            title=_escape(r.tc.title),
            rationale_cell=rationale_cell,
            color=color,
            verdict=r.verdict,
            elapsed_ms=r.elapsed_ms,
            step_count=len(r.step_results),
            error_note=error_note,
            step_rows=_render_step_rows(r.step_results),
        ))

    html = _HTML_TEMPLATE.format(
        spec_name=_escape(suite.spec_name),
        interface=_escape(suite.interface),
        channel=_escape(suite.channel),
        started_at=suite.started_at.strftime("%Y-%m-%d %H:%M:%S"),
        elapsed_s=suite.elapsed_ms / 1000.0,
        total=suite.total,
        passed=suite.passed,
        failed=suite.failed,
        errors=suite.errors,
        skipped=suite.skipped,
        pass_rate=suite.pass_rate,
        rows="\n".join(rows_html),
    )
    Path(path).write_text(html, encoding="utf-8")


# ---------------------------------------------------------------------------
# JUnit XML
# ---------------------------------------------------------------------------

def write_junit_xml(suite: TestSuiteResult, path: "str | Path") -> None:
    """Write a JUnit-compatible XML report to *path* for CI integration."""
    # Group by category for separate <testsuite> elements
    by_cat: dict[str, list[TestCaseResult]] = {}
    for r in suite.results:
        by_cat.setdefault(r.tc.category, []).append(r)

    root = ET.Element("testsuites", {
        "name": suite.spec_name or "UDS ECU Test",
        "tests": str(suite.total),
        "failures": str(suite.failed),
        "errors": str(suite.errors),
        "skipped": str(suite.skipped),
        "time": f"{suite.elapsed_ms / 1000.0:.3f}",
    })

    for cat, results in by_cat.items():
        cat_failed = sum(1 for r in results if r.verdict == "FAIL")
        cat_errors  = sum(1 for r in results if r.verdict == "ERROR")
        cat_skipped = sum(1 for r in results if r.verdict == "SKIP")
        cat_time    = sum(r.elapsed_ms for r in results) / 1000.0

        ts_el = ET.SubElement(root, "testsuite", {
            "name": cat,
            "tests": str(len(results)),
            "failures": str(cat_failed),
            "errors": str(cat_errors),
            "skipped": str(cat_skipped),
            "time": f"{cat_time:.3f}",
        })

        for r in results:
            tc_el = ET.SubElement(ts_el, "testcase", {
                "classname": r.tc.category,
                "name": r.tc.tc_id,
                "time": f"{r.elapsed_ms / 1000.0:.3f}",
            })
            if r.verdict == "FAIL":
                msg = r.error_message or _first_failure_message(r)
                fail_el = ET.SubElement(tc_el, "failure", {
                    "message": msg,
                    "type": "AssertionError",
                })
                fail_el.text = msg
            elif r.verdict == "ERROR":
                err_el = ET.SubElement(tc_el, "error", {
                    "message": r.error_message or "Unknown error",
                    "type": "RuntimeError",
                })
                err_el.text = r.error_message or ""
            elif r.verdict == "SKIP":
                ET.SubElement(tc_el, "skipped")

    tree = ET.ElementTree(root)
    ET.indent(tree, space="  ")
    Path(path).write_bytes(
        b'<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(root, encoding="unicode").encode()
    )


def _first_failure_message(r: TestCaseResult) -> str:
    for sr in r.step_results:
        if not sr.passed and sr.error:
            return sr.error
    return "Test failed"


# ---------------------------------------------------------------------------
# Coverage HTML
# ---------------------------------------------------------------------------

_COVERAGE_HTML = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>UDS Test Coverage — {spec_name}</title>
<style>
  body {{font-family: Georgia, serif; margin: 2rem; color: #212529; background: #f8f9fa;}}
  h1 {{font-size: 1.5rem; margin-bottom: 0.25rem;}}
  h2 {{font-size: 1.1rem; margin-top: 2rem; margin-bottom: 0.5rem;
       color: #343a40; border-bottom: 2px solid #dee2e6; padding-bottom: 0.25rem;}}
  .meta {{color: #6c757d; font-size: 0.85rem; margin-bottom: 1.5rem;}}
  .summary {{display: flex; gap: 1.5rem; margin-bottom: 2rem; flex-wrap: wrap;}}
  .kpi {{background: #fff; border: 1px solid #dee2e6; border-radius: 6px;
          padding: 0.75rem 1.25rem; min-width: 110px; text-align: center;}}
  .kpi .val {{font-size: 1.8rem; font-weight: bold;}}
  .kpi .lbl {{font-size: 0.75rem; color: #6c757d; text-transform: uppercase;}}
  .bar-wrap {{background: #e9ecef; border-radius: 4px; height: 10px; margin-bottom: 1rem;}}
  .bar {{height: 10px; border-radius: 4px; background: #28a745;}}
  table {{width: 100%; border-collapse: collapse; background: #fff;
          box-shadow: 0 1px 3px rgba(0,0,0,.08); margin-bottom: 2rem;}}
  th {{background: #343a40; color: #fff; padding: 0.5rem 0.75rem; text-align: left;
       font-size: 0.82rem;}}
  td {{padding: 0.45rem 0.75rem; border-bottom: 1px solid #dee2e6; font-size: 0.82rem;}}
  .cov  {{color: #28a745; font-weight: bold;}}
  .uncov{{color: #dc3545; font-weight: bold;}}
  code {{background: #e9ecef; padding: 0.1em 0.35em; border-radius: 3px; font-size: 0.85em;}}
</style>
</head>
<body>
<h1>UDS Test Coverage Report</h1>
<div class="meta">
  <strong>ECU / Spec:</strong> {spec_name} &nbsp;|&nbsp;
  <strong>Generated:</strong> {generated_at}
</div>
<div class="summary">
  <div class="kpi"><div class="val">{total}</div><div class="lbl">Total Items</div></div>
  <div class="kpi" style="border-color:#28a745">
    <div class="val" style="color:#28a745">{covered}</div><div class="lbl">Covered</div>
  </div>
  <div class="kpi" style="border-color:#dc3545">
    <div class="val" style="color:#dc3545">{uncovered}</div><div class="lbl">Uncovered</div>
  </div>
  <div class="kpi"><div class="val">{pct:.0f}%</div><div class="lbl">Coverage</div></div>
</div>
<div class="bar-wrap"><div class="bar" style="width:{pct:.1f}%"></div></div>
{sections}
</body>
</html>
"""

_COV_SECTION = """\
<h2>{cat_label} — {cat_pct:.0f}% ({cat_covered}/{cat_total})</h2>
<table>
  <thead><tr><th>Item</th><th>Description</th><th>Covered?</th><th>Test Cases</th></tr></thead>
  <tbody>
{rows}  </tbody>
</table>"""

_COV_ROW = (
    "    <tr>"
    "<td><code>{item_id}</code></td>"
    "<td>{description}</td>"
    "<td class=\"{cls}\">{status}</td>"
    "<td>{tc_ids}</td>"
    "</tr>\n"
)

_CAT_LABELS = {
    "session":  "Sessions",
    "security": "Security Levels",
    "did_read": "Readable DIDs",
    "did_write": "Writable DIDs",
    "routine":  "Routines",
    "dtc":      "DTC Operations",
}


def write_coverage_html(report: "CoverageReport", path: "str | Path") -> None:
    """Write a self-contained HTML coverage report to *path*."""
    sections_html: list[str] = []
    for cat, items in report.by_category().items():
        cat_covered = sum(1 for i in items if i.covered)
        cat_pct = cat_covered / len(items) * 100.0 if items else 0.0
        rows = ""
        for item in items:
            cls = "cov" if item.covered else "uncov"
            status = "✓ Yes" if item.covered else "✗ No"
            tc_text = ", ".join(f"<code>{_escape(t)}</code>" for t in item.test_case_ids) or "—"
            rows += _COV_ROW.format(
                item_id=_escape(item.item_id),
                description=_escape(item.description),
                cls=cls,
                status=status,
                tc_ids=tc_text,
            )
        sections_html.append(_COV_SECTION.format(
            cat_label=_CAT_LABELS.get(cat, cat),
            cat_pct=cat_pct,
            cat_covered=cat_covered,
            cat_total=len(items),
            rows=rows,
        ))

    html = _COVERAGE_HTML.format(
        spec_name=_escape(report.spec_name),
        generated_at=report.generated_at.strftime("%Y-%m-%d %H:%M:%S"),
        total=report.total,
        covered=report.covered_count,
        uncovered=report.uncovered_count,
        pct=report.coverage_pct(),
        sections="\n".join(sections_html),
    )
    Path(path).write_text(html, encoding="utf-8")


# ---------------------------------------------------------------------------
# Convenience: write all formats at once
# ---------------------------------------------------------------------------

def write_reports(
    suite: TestSuiteResult,
    out_dir: "str | Path" = ".",
    stem: Optional[str] = None,
    coverage: Optional["CoverageReport"] = None,
    rationales: Optional[dict] = None,
) -> dict[str, Path]:
    """Write JSON + CSV + HTML + JUnit XML reports into *out_dir*.

    Args:
        suite:      Completed test suite result.
        out_dir:    Directory to write reports into (created if absent).
        stem:       Base filename stem; auto-generated from spec name + timestamp
                    when not provided.
        coverage:   Optional coverage report; when supplied a coverage HTML is
                    also written.
        rationales: Optional dict mapping ``tc_id`` → LLM rationale string from
                    ``llm_integration.generate_test_rationale()``.  When supplied,
                    rationale notes are embedded in the HTML report.

    Returns:
        Dict with keys ``"json"``, ``"csv"``, ``"html"``, ``"junit"`` (and
        ``"coverage"`` when *coverage* is provided) pointing to written paths.
    """
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    if stem is None:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in suite.spec_name)
        stem = f"ecu_test_{safe}_{ts}" if safe else f"ecu_test_{ts}"

    paths: dict[str, Path] = {
        "json":  out / f"{stem}.json",
        "csv":   out / f"{stem}.csv",
        "html":  out / f"{stem}.html",
        "junit": out / f"{stem}.xml",
    }
    write_json(suite, paths["json"])
    write_csv(suite, paths["csv"])
    write_html(suite, paths["html"], rationales=rationales)
    write_junit_xml(suite, paths["junit"])

    if coverage is not None:
        cov_path = out / f"{stem}_coverage.html"
        write_coverage_html(coverage, cov_path)
        paths["coverage"] = cov_path

    return paths
