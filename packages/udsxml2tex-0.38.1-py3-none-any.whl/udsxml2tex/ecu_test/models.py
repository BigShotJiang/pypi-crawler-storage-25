"""Data models for ECU hardware test cases and results."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass
class TestStep:
    """A single UDS request/response exchange within a test case."""

    name: str
    service_id: int
    request: bytes
    # "positive" | "negative" | "any"
    expected_response: str = "positive"
    expected_nrc: Optional[int] = None
    # If set, the total byte length of the positive response (including SID
    # byte) must exactly match.  Used for RDBI payload-length validation.
    expected_response_length: Optional[int] = None
    timeout: float = 2.0
    description: str = ""

    @property
    def request_hex(self) -> str:
        return self.request.hex(" ").upper()


@dataclass
class TestCase:
    """A complete, self-contained UDS test case.

    Attributes:
        tc_id:       Unique identifier, e.g. "TC_DID_READ_0x1234_ExtSession".
        category:    One of "session", "security", "did_read", "did_write",
                     "routine", "dtc".
        title:       Short human-readable title.
        description: Longer explanation of what is being tested.
        setup:       Steps executed before the test body (e.g. enter session,
                     unlock security). Failures abort the test case.
        steps:       The actual test steps that determine PASS / FAIL.
        teardown:    Steps executed after the test body regardless of verdict
                     (e.g. return to default session).
    """

    tc_id: str
    category: str
    title: str
    description: str = ""
    setup: list[TestStep] = field(default_factory=list)
    steps: list[TestStep] = field(default_factory=list)
    teardown: list[TestStep] = field(default_factory=list)


@dataclass
class StepResult:
    """Execution result for a single TestStep."""

    step: TestStep
    passed: bool
    actual_response: Optional[bytes] = None
    actual_nrc: Optional[int] = None
    elapsed_ms: float = 0.0
    error: Optional[str] = None

    @property
    def actual_response_hex(self) -> str:
        if self.actual_response is None:
            return ""
        return self.actual_response.hex(" ").upper()


@dataclass
class TestCaseResult:
    """Execution result for a complete TestCase."""

    tc: TestCase
    # "PASS" | "FAIL" | "ERROR" | "SKIP"
    verdict: str
    step_results: list[StepResult] = field(default_factory=list)
    started_at: datetime = field(default_factory=datetime.now)
    elapsed_ms: float = 0.0
    error_message: Optional[str] = None


@dataclass
class TestSuiteResult:
    """Aggregated results for a full test run."""

    spec_name: str
    interface: str
    channel: str
    started_at: datetime = field(default_factory=datetime.now)
    elapsed_ms: float = 0.0
    results: list[TestCaseResult] = field(default_factory=list)

    @property
    def total(self) -> int:
        return len(self.results)

    @property
    def passed(self) -> int:
        return sum(1 for r in self.results if r.verdict == "PASS")

    @property
    def failed(self) -> int:
        return sum(1 for r in self.results if r.verdict == "FAIL")

    @property
    def errors(self) -> int:
        return sum(1 for r in self.results if r.verdict == "ERROR")

    @property
    def skipped(self) -> int:
        return sum(1 for r in self.results if r.verdict == "SKIP")

    @property
    def pass_rate(self) -> float:
        if self.total == 0:
            return 0.0
        return self.passed / self.total * 100
