"""Coverage analysis: which spec items are exercised by the generated test suite.

Usage::

    from udsxml2tex.ecu_test.coverage import analyze_coverage
    from udsxml2tex.ecu_test.generator import generate_test_suite

    spec = ArxmlParser().parse("ecu.arxml")
    cases = generate_test_suite(spec)
    report = analyze_coverage(spec, cases)
    print(f"Overall: {report.coverage_pct():.0f}%")
    for cat, items in report.by_category().items():
        covered = sum(1 for i in items if i.covered)
        print(f"  {cat}: {covered}/{len(items)}")
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from udsxml2tex.models import UdsSpecification

from .models import TestCase

# UDS service IDs (same constants as generator.py — no import to avoid circular)
_SID_DSC   = 0x10
_SID_SA    = 0x27
_SID_RDBI  = 0x22
_SID_WDBI  = 0x2E
_SID_RC    = 0x31
_SID_RDTCI = 0x19
_SID_CDTCI = 0x14


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class CoverageItem:
    """A single trackable spec item and whether any test case exercises it."""

    category: str
    item_id: str
    description: str
    covered: bool
    test_case_ids: list[str] = field(default_factory=list)


@dataclass
class CoverageReport:
    """Aggregated coverage across all spec items."""

    spec_name: str
    generated_at: datetime
    items: list[CoverageItem] = field(default_factory=list)

    def by_category(self) -> dict[str, list[CoverageItem]]:
        """Return items grouped by category (insertion-order preserved)."""
        result: dict[str, list[CoverageItem]] = {}
        for item in self.items:
            result.setdefault(item.category, []).append(item)
        return result

    def coverage_pct(self, category: Optional[str] = None) -> float:
        """Return covered-item percentage for *category* (or overall if None)."""
        items = [i for i in self.items if category is None or i.category == category]
        if not items:
            return 0.0
        return sum(1 for i in items if i.covered) / len(items) * 100.0

    @property
    def total(self) -> int:
        return len(self.items)

    @property
    def covered_count(self) -> int:
        return sum(1 for i in self.items if i.covered)

    @property
    def uncovered_count(self) -> int:
        return self.total - self.covered_count


# ---------------------------------------------------------------------------
# Analysis
# ---------------------------------------------------------------------------

def analyze_coverage(
    spec: "UdsSpecification",
    cases: list[TestCase],
) -> CoverageReport:
    """Analyze which spec items are exercised by *cases*.

    Inspects all steps (setup, main, teardown) in each test case and maps the
    requests to spec items.  Returns a CoverageReport listing each item with
    ``covered=True`` when at least one test case exercises it.
    """
    # Build index: (category, item_id) → list[tc_id]
    index: dict[tuple[str, str], list[str]] = {}

    def _record(cat: str, item_id: str, tc_id: str) -> None:
        key = (cat, item_id)
        if key not in index:
            index[key] = []
        if tc_id not in index[key]:
            index[key].append(tc_id)

    for tc in cases:
        all_steps = list(tc.setup) + list(tc.steps) + list(tc.teardown)
        for step in all_steps:
            sid = step.service_id
            req = step.request
            if sid == _SID_DSC and len(req) >= 2:
                _record("session", f"session_0x{req[1]:02X}", tc.tc_id)
            elif sid == _SID_SA and len(req) >= 2 and req[1] % 2 == 1:
                # Odd sub-function = seed request; level = (sub + 1) / 2
                level = (req[1] + 1) // 2
                _record("security", f"security_L{level}", tc.tc_id)
            elif sid == _SID_RDBI and len(req) >= 3:
                did_id = (req[1] << 8) | req[2]
                _record("did_read", f"did_0x{did_id:04X}", tc.tc_id)
            elif sid == _SID_WDBI and len(req) >= 3:
                did_id = (req[1] << 8) | req[2]
                _record("did_write", f"did_0x{did_id:04X}", tc.tc_id)
            elif sid == _SID_RC and len(req) >= 4:
                rid_id = (req[2] << 8) | req[3]
                _record("routine", f"routine_0x{rid_id:04X}", tc.tc_id)
            elif sid == _SID_RDTCI and len(req) >= 2:
                _record("dtc", f"rdtci_sub_0x{req[1]:02X}", tc.tc_id)
            elif sid == _SID_CDTCI:
                _record("dtc", "cdtci_clear_all", tc.tc_id)

    # Build CoverageItem list from spec items
    items: list[CoverageItem] = []

    # Sessions
    for sess in spec.sessions:
        key = f"session_0x{sess.session_id:02X}"
        tc_ids = index.get(("session", key), [])
        items.append(CoverageItem(
            category="session",
            item_id=key,
            description=f"DSC 0x{sess.session_id:02X} ({sess.short_name})",
            covered=bool(tc_ids),
            test_case_ids=tc_ids,
        ))

    # Security levels
    for lvl in spec.security_levels:
        key = f"security_L{lvl.security_level}"
        tc_ids = index.get(("security", key), [])
        items.append(CoverageItem(
            category="security",
            item_id=key,
            description=f"SA level {lvl.security_level} ({lvl.short_name})",
            covered=bool(tc_ids),
            test_case_ids=tc_ids,
        ))

    # Readable DIDs
    for did in spec.dids:
        if not did.read_access:
            continue
        key = f"did_0x{did.did_id:04X}"
        tc_ids = index.get(("did_read", key), [])
        items.append(CoverageItem(
            category="did_read",
            item_id=key,
            description=f"RDBI 0x{did.did_id:04X} ({did.short_name})",
            covered=bool(tc_ids),
            test_case_ids=tc_ids,
        ))

    # Writable DIDs
    for did in spec.dids:
        if not did.write_access:
            continue
        key = f"did_0x{did.did_id:04X}"
        tc_ids = index.get(("did_write", key), [])
        items.append(CoverageItem(
            category="did_write",
            item_id=key,
            description=f"WDBI 0x{did.did_id:04X} ({did.short_name})",
            covered=bool(tc_ids),
            test_case_ids=tc_ids,
        ))

    # Routines
    for routine in spec.routines:
        key = f"routine_0x{routine.routine_id:04X}"
        tc_ids = index.get(("routine", key), [])
        items.append(CoverageItem(
            category="routine",
            item_id=key,
            description=f"RC 0x{routine.routine_id:04X} ({routine.short_name})",
            covered=bool(tc_ids),
            test_case_ids=tc_ids,
        ))

    # DTC operations
    for sub_byte, description in [
        (0x02, "reportDTCByStatusMask (active DTCs)"),
        (0x0A, "reportSupportedDTCs"),
    ]:
        key = f"rdtci_sub_0x{sub_byte:02X}"
        tc_ids = index.get(("dtc", key), [])
        items.append(CoverageItem(
            category="dtc",
            item_id=key,
            description=f"RDTCI sub=0x{sub_byte:02X}: {description}",
            covered=bool(tc_ids),
            test_case_ids=tc_ids,
        ))

    tc_ids_clear = index.get(("dtc", "cdtci_clear_all"), [])
    items.append(CoverageItem(
        category="dtc",
        item_id="cdtci_clear_all",
        description="ClearDiagnosticInformation group 0xFFFFFF",
        covered=bool(tc_ids_clear),
        test_case_ids=tc_ids_clear,
    ))

    return CoverageReport(
        spec_name=getattr(spec, "ecu_name", "") or "",
        generated_at=datetime.now(),
        items=items,
    )
