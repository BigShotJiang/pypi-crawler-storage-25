"""Formal UDS state machine — complete model of ECU diagnostic state.

The ECU state is the pair (session_id, unlocked_security_levels).  Starting
from the initial state (DefaultSession, no security) a BFS enumerates every
reachable (state, service_call) pair and the expected ECU response.

This provides the theoretical foundation for all-transitions coverage:

    State space  S = Sessions × 2^SecurityLevels
    Alphabet     Σ = {DSC, SA_Unlock, RDBI, WDBI, RC, RDTCI, CDTCI} × parameters
    Transitions  δ ⊆ S × Σ × S  (with expected_response annotation)

All reachable states and transitions are enumerated via BFS from the
initial state.  Both positive (state-changing) and negative (NRC-expected,
state-preserving) edges are recorded.

Covered properties after full transition-tour execution
--------------------------------------------------------
* Every session is entered from every reachable predecessor state.
* Every security level is unlocked in every session that supports it.
* Every DID/routine is accessed from every legal (session, security) state.
* Every DID/routine is accessed from every ILLEGAL state, with the correct NRC.
* No (state, service) combination is left untested.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from udsxml2tex.models import UdsSpecification, Did, Routine, SecurityLevel

# UDS Service IDs
SID_DSC   = 0x10
SID_SA    = 0x27
SID_RDBI  = 0x22
SID_WDBI  = 0x2E
SID_RC    = 0x31
SID_RDTCI = 0x19
SID_CDTCI = 0x14

DEFAULT_SESSION = 0x01

# UDS NRCs
NRC_CONDITIONS_NOT_CORRECT  = 0x22
NRC_REQUEST_SEQUENCE_ERROR  = 0x24
NRC_REQUEST_OUT_OF_RANGE    = 0x31
NRC_SECURITY_ACCESS_DENIED  = 0x33


# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class UdsState:
    """Fully-qualified ECU diagnostic state.

    Attributes:
        session_id: Active diagnostic session (0x01 = Default, 0x02 = Programming,
                    0x03 = Extended, …).
        unlocked:   Frozenset of security access levels that have been
                    successfully unlocked in this session.
    """
    session_id: int
    unlocked: frozenset  # frozenset[int]

    def __str__(self) -> str:
        sa = f"+SA{sorted(self.unlocked)}" if self.unlocked else ""
        return f"(0x{self.session_id:02X}{sa})"


# ---------------------------------------------------------------------------
# Edge (transition)
# ---------------------------------------------------------------------------

@dataclass
class UdsEdge:
    """One possible UDS service call from *from_state* and its expected result.

    An edge is either:
    * Positive  — ECU responds with positive response; may change state.
    * Negative  — ECU responds with NRC; state is preserved.

    The *request* bytes are the raw UDS PDU sent to the ECU.  For SA Unlock
    edges the request contains the seed sub-function; the key sub-function
    and computed key bytes are appended by the executor at runtime.
    """
    from_state: UdsState
    to_state: UdsState           # same as from_state for NRC edges
    request: bytes
    expected_response: str       # "positive" | "negative"
    expected_nrc: Optional[int]
    expected_response_length: Optional[int]
    category: str                # mirrors generator.py category names
    description: str
    # SA-specific: when this edge is an SA Unlock (seed+key), key_sub carries
    # the even sub-function so the test case can emit two steps.
    sa_key_sub: Optional[int] = field(default=None)


# ---------------------------------------------------------------------------
# FSM
# ---------------------------------------------------------------------------

class UdsFsm:
    """Formal UDS state machine constructed from a parsed *UdsSpecification*.

    Construction performs a BFS over the state space.  After construction:

        fsm.states   — all reachable UdsState objects
        fsm.edges    — all UdsEdge objects (positive + negative)
        fsm.initial_state — UdsState(DEFAULT_SESSION, frozenset())
    """

    def __init__(self, spec: "UdsSpecification") -> None:
        self.spec = spec
        self.initial_state = UdsState(session_id=DEFAULT_SESSION, unlocked=frozenset())
        self.states: set[UdsState] = set()
        self.edges: list[UdsEdge] = []
        self._build()

    # ------------------------------------------------------------------
    # BFS construction
    # ------------------------------------------------------------------

    def _build(self) -> None:
        queue: deque[UdsState] = deque([self.initial_state])
        visited: set[UdsState] = {self.initial_state}

        while queue:
            state = queue.popleft()
            self.states.add(state)

            for edge in self._edges_from(state):
                self.edges.append(edge)
                if edge.to_state not in visited and edge.to_state != state:
                    visited.add(edge.to_state)
                    queue.append(edge.to_state)

    def _edges_from(self, state: UdsState) -> list[UdsEdge]:
        edges: list[UdsEdge] = []
        edges.extend(self._dsc_edges(state))
        edges.extend(self._sa_edges(state))
        edges.extend(self._rdbi_edges(state))
        edges.extend(self._wdbi_edges(state))
        edges.extend(self._rc_edges(state))
        edges.extend(self._dtc_edges(state))
        return edges

    # ------------------------------------------------------------------
    # DSC edges — one per defined session from every state
    # ------------------------------------------------------------------

    def _dsc_edges(self, state: UdsState) -> list[UdsEdge]:
        edges = []
        for sess in self.spec.sessions:
            # Entering any valid session always succeeds (simplified; ECU-specific
            # restrictions such as "only enter programming from extended" are
            # not captured in the ARXML model).
            next_state = UdsState(session_id=sess.session_id, unlocked=frozenset())
            edges.append(UdsEdge(
                from_state=state,
                to_state=next_state,
                request=bytes([SID_DSC, sess.session_id]),
                expected_response="positive",
                expected_nrc=None,
                expected_response_length=None,
                category="session",
                description=(
                    f"DSC 0x{sess.session_id:02X} ({sess.short_name}) "
                    f"from {state}"
                ),
            ))
        return edges

    # ------------------------------------------------------------------
    # SA edges — atomic seed+key unlock per level
    # ------------------------------------------------------------------

    def _sa_edges(self, state: UdsState) -> list[UdsEdge]:
        edges = []
        for lvl in self.spec.security_levels:
            level    = lvl.security_level
            seed_sub = level * 2 - 1   # odd sub-function
            key_sub  = level * 2       # even sub-function
            seed_req = bytes([SID_SA, seed_sub])

            sa_sessions = self._sa_sessions_for_level(lvl)

            if state.session_id in sa_sessions:
                if level not in state.unlocked:
                    # Happy path: unlock level (two-step seed+key, modelled as one edge)
                    next_unlocked = frozenset(state.unlocked | {level})
                    next_state = UdsState(
                        session_id=state.session_id, unlocked=next_unlocked
                    )
                    edges.append(UdsEdge(
                        from_state=state,
                        to_state=next_state,
                        request=seed_req,
                        expected_response="positive",
                        expected_nrc=None,
                        expected_response_length=None,
                        category="security",
                        description=(
                            f"SA Unlock L{level} (sub 0x{seed_sub:02X}→"
                            f"0x{key_sub:02X}) from {state}"
                        ),
                        sa_key_sub=key_sub,
                    ))
                else:
                    # Already unlocked → seed request returns NRC 0x24
                    edges.append(UdsEdge(
                        from_state=state,
                        to_state=state,
                        request=seed_req,
                        expected_response="negative",
                        expected_nrc=NRC_REQUEST_SEQUENCE_ERROR,
                        expected_response_length=None,
                        category="security",
                        description=(
                            f"SA RequestSeed L{level} already unlocked "
                            f"in {state} → NRC 0x{NRC_REQUEST_SEQUENCE_ERROR:02X}"
                        ),
                    ))
            else:
                # SA not supported in current session
                edges.append(UdsEdge(
                    from_state=state,
                    to_state=state,
                    request=seed_req,
                    expected_response="negative",
                    expected_nrc=NRC_REQUEST_OUT_OF_RANGE,
                    expected_response_length=None,
                    category="security",
                    description=(
                        f"SA RequestSeed L{level} in unsupported session "
                        f"{state} → NRC 0x{NRC_REQUEST_OUT_OF_RANGE:02X}"
                    ),
                ))
        return edges

    def _sa_sessions_for_level(self, lvl: "SecurityLevel") -> set[int]:
        """Derive which session IDs allow SecurityAccess for *lvl*."""
        sessions: set[int] = set()

        # 1. Check spec.services for a SecurityAccess service entry
        for svc in self.spec.services:
            svc_id = getattr(svc, "service_id", None)
            if svc_id is not None and svc_id != SID_SA:
                continue
            for sname in (svc.supported_sessions or []):
                sess = next(
                    (s for s in self.spec.sessions if s.short_name == sname), None
                )
                if sess:
                    sessions.add(sess.session_id)

        # 2. Any session referenced by a DID/routine that requires this level
        for did in self.spec.dids:
            if lvl.short_name not in (did.required_security_levels or []):
                continue
            for sname in (did.supported_sessions or []):
                sess = next(
                    (s for s in self.spec.sessions if s.short_name == sname), None
                )
                if sess:
                    sessions.add(sess.session_id)

        for routine in self.spec.routines:
            if lvl.short_name not in (routine.required_security_levels or []):
                continue
            for sname in (routine.supported_sessions or []):
                sess = next(
                    (s for s in self.spec.sessions if s.short_name == sname), None
                )
                if sess:
                    sessions.add(sess.session_id)

        # 3. Fallback: SA available in all non-default sessions
        if not sessions:
            sessions = {
                s.session_id
                for s in self.spec.sessions
                if s.session_id != DEFAULT_SESSION
            }

        return sessions

    # ------------------------------------------------------------------
    # RDBI / WDBI / RC helpers
    # ------------------------------------------------------------------

    def _did_access(self, did: "Did", state: UdsState) -> tuple[bool, bool]:
        """Return (session_ok, security_ok) for *did* in *state*."""
        sess_ids: set[int] = set()
        for sname in (did.supported_sessions or []):
            sess = next(
                (s for s in self.spec.sessions if s.short_name == sname), None
            )
            if sess:
                sess_ids.add(sess.session_id)

        req_levels: set[int] = set()
        for lname in (did.required_security_levels or []):
            lvl = next(
                (l for l in self.spec.security_levels if l.short_name == lname), None
            )
            if lvl:
                req_levels.add(lvl.security_level)

        sess_ok = (not sess_ids) or (state.session_id in sess_ids)
        sec_ok  = req_levels.issubset(state.unlocked)
        return sess_ok, sec_ok

    def _routine_access(self, routine: "Routine", state: UdsState) -> tuple[bool, bool]:
        sess_ids: set[int] = set()
        for sname in (routine.supported_sessions or []):
            sess = next(
                (s for s in self.spec.sessions if s.short_name == sname), None
            )
            if sess:
                sess_ids.add(sess.session_id)

        req_levels: set[int] = set()
        for lname in (routine.required_security_levels or []):
            lvl = next(
                (l for l in self.spec.security_levels if l.short_name == lname), None
            )
            if lvl:
                req_levels.add(lvl.security_level)

        sess_ok = (not sess_ids) or (state.session_id in sess_ids)
        sec_ok  = req_levels.issubset(state.unlocked)
        return sess_ok, sec_ok

    # ------------------------------------------------------------------
    # RDBI edges
    # ------------------------------------------------------------------

    def _rdbi_edges(self, state: UdsState) -> list[UdsEdge]:
        edges = []
        for did in self.spec.dids:
            if not did.read_access:
                continue
            did_hi  = (did.did_id >> 8) & 0xFF
            did_lo  = did.did_id & 0xFF
            request = bytes([SID_RDBI, did_hi, did_lo])
            resp_len = 3 + did.total_byte_length if did.total_byte_length > 0 else None

            sess_ok, sec_ok = self._did_access(did, state)

            if sess_ok and sec_ok:
                edges.append(UdsEdge(
                    from_state=state, to_state=state,
                    request=request,
                    expected_response="positive",
                    expected_nrc=None,
                    expected_response_length=resp_len,
                    category="did_read",
                    description=(
                        f"RDBI {did.did_id_hex} ({did.short_name}) from {state}"
                    ),
                ))
            elif not sess_ok:
                edges.append(UdsEdge(
                    from_state=state, to_state=state,
                    request=request,
                    expected_response="negative",
                    expected_nrc=NRC_REQUEST_OUT_OF_RANGE,
                    expected_response_length=None,
                    category="did_read",
                    description=(
                        f"RDBI {did.did_id_hex} wrong session {state} "
                        f"→ NRC 0x{NRC_REQUEST_OUT_OF_RANGE:02X}"
                    ),
                ))
            else:
                edges.append(UdsEdge(
                    from_state=state, to_state=state,
                    request=request,
                    expected_response="negative",
                    expected_nrc=NRC_SECURITY_ACCESS_DENIED,
                    expected_response_length=None,
                    category="did_read",
                    description=(
                        f"RDBI {did.did_id_hex} security locked {state} "
                        f"→ NRC 0x{NRC_SECURITY_ACCESS_DENIED:02X}"
                    ),
                ))
        return edges

    # ------------------------------------------------------------------
    # WDBI edges
    # ------------------------------------------------------------------

    def _wdbi_edges(self, state: UdsState) -> list[UdsEdge]:
        edges = []
        for did in self.spec.dids:
            if not did.write_access:
                continue
            did_hi  = (did.did_id >> 8) & 0xFF
            did_lo  = did.did_id & 0xFF
            payload = (
                bytes(did.total_byte_length)
                if did.total_byte_length > 0
                else b"\x00"
            )
            request = bytes([SID_WDBI, did_hi, did_lo]) + payload

            sess_ok, sec_ok = self._did_access(did, state)

            if sess_ok and sec_ok:
                edges.append(UdsEdge(
                    from_state=state, to_state=state,
                    request=request,
                    expected_response="positive",
                    expected_nrc=None,
                    expected_response_length=None,
                    category="did_write",
                    description=(
                        f"WDBI {did.did_id_hex} ({did.short_name}) from {state}"
                    ),
                ))
            elif not sess_ok:
                edges.append(UdsEdge(
                    from_state=state, to_state=state,
                    request=request,
                    expected_response="negative",
                    expected_nrc=NRC_REQUEST_OUT_OF_RANGE,
                    expected_response_length=None,
                    category="did_write",
                    description=(
                        f"WDBI {did.did_id_hex} wrong session {state} "
                        f"→ NRC 0x{NRC_REQUEST_OUT_OF_RANGE:02X}"
                    ),
                ))
            else:
                edges.append(UdsEdge(
                    from_state=state, to_state=state,
                    request=request,
                    expected_response="negative",
                    expected_nrc=NRC_SECURITY_ACCESS_DENIED,
                    expected_response_length=None,
                    category="did_write",
                    description=(
                        f"WDBI {did.did_id_hex} security locked {state} "
                        f"→ NRC 0x{NRC_SECURITY_ACCESS_DENIED:02X}"
                    ),
                ))
        return edges

    # ------------------------------------------------------------------
    # RC edges
    # ------------------------------------------------------------------

    def _rc_edges(self, state: UdsState) -> list[UdsEdge]:
        edges = []
        for routine in self.spec.routines:
            if not routine.start_supported:
                continue
            rid_hi  = (routine.routine_id >> 8) & 0xFF
            rid_lo  = routine.routine_id & 0xFF
            in_pay  = b""
            if routine.in_parameters:
                total_bits = sum(p.bit_size for p in routine.in_parameters)
                in_pay = bytes((total_bits + 7) // 8)
            request = bytes([SID_RC, 0x01, rid_hi, rid_lo]) + in_pay

            sess_ok, sec_ok = self._routine_access(routine, state)

            if sess_ok and sec_ok:
                edges.append(UdsEdge(
                    from_state=state, to_state=state,
                    request=request,
                    expected_response="positive",
                    expected_nrc=None,
                    expected_response_length=None,
                    category="routine",
                    description=(
                        f"RC Start {routine.routine_id_hex} "
                        f"({routine.short_name}) from {state}"
                    ),
                ))
            elif not sess_ok:
                edges.append(UdsEdge(
                    from_state=state, to_state=state,
                    request=request,
                    expected_response="negative",
                    expected_nrc=NRC_REQUEST_OUT_OF_RANGE,
                    expected_response_length=None,
                    category="routine",
                    description=(
                        f"RC Start {routine.routine_id_hex} wrong session "
                        f"{state} → NRC 0x{NRC_REQUEST_OUT_OF_RANGE:02X}"
                    ),
                ))
            else:
                edges.append(UdsEdge(
                    from_state=state, to_state=state,
                    request=request,
                    expected_response="negative",
                    expected_nrc=NRC_SECURITY_ACCESS_DENIED,
                    expected_response_length=None,
                    category="routine",
                    description=(
                        f"RC Start {routine.routine_id_hex} security locked "
                        f"{state} → NRC 0x{NRC_SECURITY_ACCESS_DENIED:02X}"
                    ),
                ))
        return edges

    # ------------------------------------------------------------------
    # DTC edges
    # ------------------------------------------------------------------

    def _dtc_edges(self, state: UdsState) -> list[UdsEdge]:
        edges = []
        # RDTCI sub=0x02 and sub=0x0A — available in all sessions
        for sub, desc in [(0x02, "reportDTCByStatusMask"), (0x0A, "reportSupportedDTCs")]:
            req = bytes([SID_RDTCI, sub]) + (b"\xFF" if sub == 0x02 else b"")
            edges.append(UdsEdge(
                from_state=state, to_state=state,
                request=req,
                expected_response="positive",
                expected_nrc=None,
                expected_response_length=None,
                category="dtc",
                description=f"RDTCI {desc} from {state}",
            ))

        # CDTCI — requires extended (0x03) or programming (0x02) session
        extended_prog = {
            s.session_id
            for s in self.spec.sessions
            if s.session_id in (0x02, 0x03)
        }
        cdtci_req = bytes([SID_CDTCI, 0xFF, 0xFF, 0xFF])
        if state.session_id in extended_prog or not extended_prog:
            edges.append(UdsEdge(
                from_state=state, to_state=state,
                request=cdtci_req,
                expected_response="positive",
                expected_nrc=None,
                expected_response_length=None,
                category="dtc",
                description=f"CDTCI ClearAll from {state}",
            ))
        else:
            edges.append(UdsEdge(
                from_state=state, to_state=state,
                request=cdtci_req,
                expected_response="negative",
                expected_nrc=NRC_CONDITIONS_NOT_CORRECT,
                expected_response_length=None,
                category="dtc",
                description=(
                    f"CDTCI ClearAll in default session {state} "
                    f"→ NRC 0x{NRC_CONDITIONS_NOT_CORRECT:02X}"
                ),
            ))
        return edges
