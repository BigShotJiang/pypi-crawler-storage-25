"""CAN / ISO-TP transport layer abstraction for UDS ECU testing.

Wraps python-can + python-isotp + python-udsoncan into a single convenience
class.  A mock loopback transport is provided for offline unit testing.

Install hardware support:
    pip install udsxml2tex[ecu-test]

Supported python-can interfaces (selected via `interface` parameter):
    "vector"    — Vector VN/VX series (VN1610 etc.), requires Vector XL Driver
    "socketcan" — Linux SocketCAN (vcan, real CAN device)
    "pcan"      — PEAK PCAN USB adapters
    "kvaser"    — Kvaser adapters
    "virtual"   — python-can virtual bus (loopback, no hardware required)
"""

from __future__ import annotations

import time
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from udsxml2tex.models import UdsSpecification


class UdsConnection(ABC):
    """Minimal send/recv interface consumed by EcuTestExecutor."""

    @abstractmethod
    def open(self) -> None: ...

    @abstractmethod
    def close(self) -> None: ...

    @abstractmethod
    def send(self, data: bytes) -> None: ...

    @abstractmethod
    def recv(self, timeout: float = 2.0) -> Optional[bytes]:
        """Return the next available UDS PDU or None on timeout."""
        ...

    def __enter__(self) -> "UdsConnection":
        self.open()
        return self

    def __exit__(self, *_: object) -> None:
        self.close()


class PythonCanIsoTpConnection(UdsConnection):
    """UDS connection backed by python-can + python-isotp.

    Args:
        interface:  python-can interface name (e.g. "vector", "socketcan").
        channel:    Channel identifier (e.g. 0 for VN1610 channel 1, "vcan0").
        rx_id:      CAN ID for incoming frames (ECU → tester).
        tx_id:      CAN ID for outgoing frames (tester → ECU).
        bitrate:    CAN bus bitrate in bps (default 500_000).
        fd:         Enable CAN FD (default False).
        padding:    ISO-TP padding byte (default 0xCC).  None = no padding.
        block_size: ISO-TP block size sent in FC frames (default 0 = no limit).
        stmin:      ISO-TP STmin in milliseconds (default 0).
        kwargs:     Extra keyword arguments forwarded to can.Bus().
    """

    def __init__(
        self,
        interface: str,
        channel: "str | int",
        rx_id: int,
        tx_id: int,
        bitrate: int = 500_000,
        fd: bool = False,
        padding: Optional[int] = 0xCC,
        block_size: int = 0,
        stmin: int = 0,
        **kwargs: object,
    ) -> None:
        self._interface = interface
        self._channel = channel
        self._rx_id = rx_id
        self._tx_id = tx_id
        self._bitrate = bitrate
        self._fd = fd
        self._padding = padding
        self._block_size = block_size
        self._stmin = stmin
        self._extra = kwargs
        self._bus: object = None
        self._stack: object = None

    def open(self) -> None:
        try:
            import can
            import isotp
        except ImportError as exc:
            raise ImportError(
                "python-can and python-isotp are required for hardware testing. "
                "Install with: pip install udsxml2tex[ecu-test]"
            ) from exc

        bus_kwargs: dict = {
            "interface": self._interface,
            "channel": self._channel,
            "bitrate": self._bitrate,
            **self._extra,
        }
        if self._fd:
            bus_kwargs["fd"] = True

        self._bus = can.Bus(**bus_kwargs)

        addr = isotp.Address(
            isotp.AddressingMode.Normal_11bits,
            rxid=self._rx_id,
            txid=self._tx_id,
        )
        params = isotp.params.Params(
            blocksize=self._block_size,
            stmin=self._stmin,
            tx_padding=self._padding,
        )
        self._stack = isotp.CanStack(bus=self._bus, address=addr, params=params)

    def close(self) -> None:
        if self._bus is not None:
            self._bus.shutdown()
            self._bus = None
            self._stack = None

    def send(self, data: bytes) -> None:
        if self._stack is None:
            raise RuntimeError("Connection not open")
        self._stack.send(data)
        # Pump the stack to flush FC / CF frames
        deadline = time.monotonic() + 2.0
        while self._stack.transmitting and time.monotonic() < deadline:
            self._stack.process()
            time.sleep(0.001)

    def recv(self, timeout: float = 2.0) -> Optional[bytes]:
        if self._stack is None:
            raise RuntimeError("Connection not open")
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            self._stack.process()
            if self._stack.available():
                return self._stack.recv()
            time.sleep(0.001)
        return None


class MockConnection(UdsConnection):
    """Deterministic loopback mock for offline testing.

    *response_map* maps request bytes (hex string or bytes) to response bytes.
    Unmatched requests return a generic NRC 0x11 (serviceNotSupported) response.
    """

    def __init__(
        self,
        response_map: Optional[dict] = None,
        latency_ms: float = 10.0,
    ) -> None:
        self._map: dict[bytes, bytes] = {}
        self._latency = latency_ms / 1000.0
        for k, v in (response_map or {}).items():
            key = bytes.fromhex(k) if isinstance(k, str) else bytes(k)
            val = bytes.fromhex(v) if isinstance(v, str) else bytes(v)
            self._map[key] = val
        self._last_request: Optional[bytes] = None

    def open(self) -> None:
        pass

    def close(self) -> None:
        pass

    def send(self, data: bytes) -> None:
        self._last_request = data

    def recv(self, timeout: float = 2.0) -> Optional[bytes]:
        time.sleep(min(self._latency, timeout))
        if self._last_request is None:
            return None
        req = self._last_request
        self._last_request = None
        if req in self._map:
            return self._map[req]
        # Generic positive echo: positive SID (req[0] | 0x40) + echo
        if req:
            return bytes([req[0] | 0x40]) + req[1:]
        return None


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

def make_connection(
    spec: "UdsSpecification",
    interface: str,
    channel: "str | int",
    bitrate: int = 500_000,
    fd: bool = False,
    rx_id: Optional[int] = None,
    tx_id: Optional[int] = None,
    **kwargs: object,
) -> PythonCanIsoTpConnection:
    """Build a PythonCanIsoTpConnection, defaulting CAN IDs from *spec*.

    If *rx_id* / *tx_id* are not supplied, they are read from
    ``spec.can_rx_id`` / ``spec.can_tx_id`` (hex strings stored in the spec).
    """
    if rx_id is None:
        raw = spec.can_rx_id.strip()
        if not raw:
            raise ValueError(
                "rx_id not supplied and spec.can_rx_id is empty. "
                "Pass --ecu-rx-id explicitly."
            )
        rx_id = int(raw, 16)
    if tx_id is None:
        raw = spec.can_tx_id.strip()
        if not raw:
            raise ValueError(
                "tx_id not supplied and spec.can_tx_id is empty. "
                "Pass --ecu-tx-id explicitly."
            )
        tx_id = int(raw, 16)

    padding: Optional[int] = 0xCC
    block_size = 0
    stmin = 0
    if spec.transport_config and spec.transport_config.channels:
        ch = spec.transport_config.channels[0]
        stmin = int(ch.stmin)
        block_size = ch.bs
        if ch.padding_activation:
            padding = ch.padding_byte
        else:
            padding = None

    return PythonCanIsoTpConnection(
        interface=interface,
        channel=channel,
        rx_id=rx_id,
        tx_id=tx_id,
        bitrate=bitrate,
        fd=fd,
        padding=padding,
        block_size=block_size,
        stmin=stmin,
        **kwargs,
    )
