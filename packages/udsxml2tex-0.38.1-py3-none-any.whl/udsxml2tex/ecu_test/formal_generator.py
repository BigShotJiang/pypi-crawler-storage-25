"""All-transitions test case generation via formal model checking.

This module converts the UDS state machine (UdsFsm) into executable TestCase
objects.  The key guarantee is **all-transitions coverage**: every reachable
(ECU_state, service_call) pair in the formal model is exercised by exactly one
test case.

Compared with the heuristic generator (generator.py)
------------------------------------------------------
generator.py produces one test case per spec item (happy path + two negative
variants per DID).  This module produces test cases for *all* (state × item)
combinations — for a spec with 4 sessions, 2 security levels and 10 DIDs the
number of test cases grows from ~12 to ~80, covering interactions the heuristic
generator misses entirely (e.g. "DID readable in Extended but not Programming",
"DID accessible after unlocking level 1 but not level 2").

Algorithm
---------
1. Build UdsFsm from spec via BFS (states + edges).
2. BFS over positive edges only → shortest setup path for every reachable state.
3. For each edge: emit one TestCase whose setup steps encode the shortest path
   from initial_state to edge.from_state, then the edge request as the main
   step, then a return-to-default teardown.
4. Deduplicate by (from_state, request, expected_response, expected_nrc) so
   the same physical check never appears twice even if the BFS yields duplicate
   transitions.

Coverage guarantee
------------------
After a full run with zero skips the test suite satisfies:

    ∀ s ∈ reachable_states, ∀ a ∈ alphabet(s):
        ∃ tc ∈ test_suite s.t. tc sets up state s and sends action a

This is equivalent to all-transitions (T1) coverage on the UDS protocol FSM,
which subsumes all-states (S0) coverage.
"""

from __future__ import annotations

from collections import deque
from typing import TYPE_CHECKING, Optional

from .fsm import (
    UdsFsm, UdsState, UdsEdge,
    DEFAULT_SESSION, SID_DSC, SID_SA,
)
from .models import TestCase, TestStep

if TYPE_CHECKING:
    from udsxml2tex.models import UdsSpecification

_TIMEOUT = 2.0

_SID_NAMES = {
    0x10: "DSC",
    0x27: "SA",
    0x22: "RDBI",
    0x2E: "WDBI",
    0x31: "RC",
    0x19: "RDTCI",
    0x14: "CDTCI",
}


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def generate_formal_test_suite(
    spec: "UdsSpecification",
    categories: Optional[list[str]] = None,
) -> list[TestCase]:
    """Generate test cases using BFS all-transitions model checking.

    Each test case exercises exactly one (ECU_state, service_call) transition.
    Setup steps are the shortest path from DefaultSession to the target state.

    Args:
        spec:       Parsed UdsSpecification.
        categories: Filter by category (same names as generator.py).  Defaults
                    to all categories.

    Returns:
        Ordered list of TestCase objects.  Positive tests precede negative
        tests within each category.
    """
    fsm = UdsFsm(spec)
    setup_paths = _bfs_setup_paths(fsm)

    seen: set[tuple] = set()
    cases: list[TestCase] = []

    # Order: positive edges first, then negative — better for CI readability
    ordered = sorted(
        fsm.edges,
        key=lambda e: (e.category, 0 if e.expected_response == "positive" else 1),
    )

    idx = 0
    for edge in ordered:
        if categories and edge.category not in categories:
            continue

        key = (
            edge.from_state,
            edge.request,
            edge.expected_response,
            edge.expected_nrc,
        )
        if key in seen:
            continue
        seen.add(key)

        if edge.from_state not in setup_paths:
            continue  # state not reachable via positive transitions

        idx += 1
        tc = _edge_to_testcase(edge, setup_paths, idx)
        if tc is not None:
            cases.append(tc)

    return cases


# ---------------------------------------------------------------------------
# BFS shortest-path computation (positive transitions only)
# ---------------------------------------------------------------------------

def _bfs_setup_paths(fsm: UdsFsm) -> dict[UdsState, list[UdsEdge]]:
    """Return shortest setup-path (positive edges only) from initial_state to each state."""
    paths: dict[UdsState, list[UdsEdge]] = {fsm.initial_state: []}
    queue: deque[UdsState] = deque([fsm.initial_state])

    # Adjacency list restricted to positive, state-changing edges
    adj: dict[UdsState, list[UdsEdge]] = {}
    for edge in fsm.edges:
        if edge.expected_response == "positive" and edge.to_state != edge.from_state:
            adj.setdefault(edge.from_state, []).append(edge)

    while queue:
        state = queue.popleft()
        for edge in adj.get(state, []):
            if edge.to_state not in paths:
                paths[edge.to_state] = paths[state] + [edge]
                queue.append(edge.to_state)

    return paths


# ---------------------------------------------------------------------------
# Edge → TestCase
# ---------------------------------------------------------------------------

def _edge_to_testcase(
    edge: UdsEdge,
    setup_paths: dict[UdsState, list[UdsEdge]],
    idx: int,
) -> Optional[TestCase]:
    setup_edges = setup_paths[edge.from_state]
    setup_steps = _setup_steps(setup_edges)

    verdict_tag = (
        "PASS"
        if edge.expected_response == "positive"
        else f"NRC{edge.expected_nrc:02X}" if edge.expected_nrc is not None
        else "NEG"
    )
    category_up = edge.category.upper().replace("_", "")
    tc_id = f"TC_FSM_{idx:04d}_{category_up}_{verdict_tag}"

    # Build main test step(s)
    sid = edge.request[0] if edge.request else 0
    step_name = _SID_NAMES.get(sid, f"SID_{sid:02X}")

    if edge.sa_key_sub is not None:
        # SA Unlock: emit RequestSeed + SendKey as two main steps
        seed_sub = edge.request[1]
        level = (seed_sub + 1) // 2
        key_sub = edge.sa_key_sub
        main_steps: list[TestStep] = [
            TestStep(
                name=f"SA_RequestSeed_L{level}",
                service_id=SID_SA,
                request=edge.request,
                expected_response="positive",
                expected_nrc=None,
                expected_response_length=None,
                timeout=_TIMEOUT,
                description=f"SA RequestSeed sub=0x{seed_sub:02X}",
            ),
            TestStep(
                name=f"SA_SendKey_L{level}",
                service_id=SID_SA,
                request=bytes([SID_SA, key_sub]),
                expected_response="positive",
                expected_nrc=None,
                expected_response_length=None,
                timeout=_TIMEOUT,
                description=(
                    f"SA SendKey sub=0x{key_sub:02X} — key computed at runtime"
                ),
            ),
        ]
    else:
        main_steps = [
            TestStep(
                name=step_name,
                service_id=sid,
                request=edge.request,
                expected_response=edge.expected_response,
                expected_nrc=edge.expected_nrc,
                expected_response_length=edge.expected_response_length,
                timeout=_TIMEOUT,
                description=edge.description,
            )
        ]

    # Teardown: return to DefaultSession if we entered another session
    teardown: list[TestStep] = []
    if edge.from_state.session_id != DEFAULT_SESSION:
        teardown.append(TestStep(
            name="ReturnToDefault",
            service_id=SID_DSC,
            request=bytes([SID_DSC, 0x01]),
            expected_response="positive",
            timeout=_TIMEOUT,
            description="Return to DefaultSession (teardown)",
        ))

    nrc_str = (
        f" → NRC 0x{edge.expected_nrc:02X}" if edge.expected_nrc is not None else ""
    )
    title = (
        f"[FSM] {edge.description}{nrc_str}"
        if edge.expected_response == "negative"
        else f"[FSM] {edge.description}"
    )

    return TestCase(
        tc_id=tc_id,
        category=edge.category,
        title=title[:120],
        description=edge.description,
        setup=setup_steps,
        steps=main_steps,
        teardown=teardown,
    )


# ---------------------------------------------------------------------------
# Setup path edges → TestStep list
# ---------------------------------------------------------------------------

def _setup_steps(edges: list[UdsEdge]) -> list[TestStep]:
    """Convert the BFS setup-path edges into TestStep objects.

    SA Unlock edges expand to two steps: RequestSeed then SendKey.
    """
    steps: list[TestStep] = []
    for edge in edges:
        sid = edge.request[0] if edge.request else 0

        if edge.sa_key_sub is not None:
            # Expand SA unlock into RequestSeed + SendKey
            seed_sub = edge.request[1]
            level = (seed_sub + 1) // 2
            key_sub = edge.sa_key_sub
            steps.append(TestStep(
                name=f"SA_RequestSeed_L{level}",
                service_id=SID_SA,
                request=edge.request,
                expected_response="positive",
                timeout=_TIMEOUT,
                description=f"SA RequestSeed L{level} (setup)",
            ))
            steps.append(TestStep(
                name=f"SA_SendKey_L{level}",
                service_id=SID_SA,
                request=bytes([SID_SA, key_sub]),
                expected_response="positive",
                timeout=_TIMEOUT,
                description=f"SA SendKey L{level} — key computed at runtime (setup)",
            ))
        else:
            steps.append(TestStep(
                name=_SID_NAMES.get(sid, f"SID_{sid:02X}") + "_setup",
                service_id=sid,
                request=edge.request,
                expected_response="positive",
                timeout=_TIMEOUT,
                description=edge.description + " (setup)",
            ))
    return steps
