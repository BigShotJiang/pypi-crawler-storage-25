"""Heuristic UDS test case generator — one test per spec item.

Each public ``generate_*`` function produces a list of :class:`TestCase`
objects derived from the parsed ARXML data.  Every test case carries
fully-formed UDS request bytes so the executor can run without any
additional spec knowledge.

Design decisions
----------------
* **One positive test per item** — each session, DID, routine, etc. gets
  exactly one "happy path" test case with the correct session/security setup.
* **Negative variants** — ``generate_negative_tests`` adds wrong-session
  (NRC 0x31) and no-security (NRC 0x33) tests for applicable DIDs.
* **Response length validation** — RDBI steps set
  ``expected_response_length = 3 + did.total_byte_length``; the executor
  fails the step on a length mismatch.
* **Security access** — key computation is ECU-specific and not in ARXML.
  Key-send steps are included as placeholders; the executor substitutes
  the computed key at runtime when ``key_functions`` are provided, or
  marks the step SKIP when they are absent.

For exhaustive all-transitions coverage (every reachable state × every
service call) use :func:`udsxml2tex.ecu_test.formal_generator.generate_formal_test_suite`
instead.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional

from .models import TestCase, TestStep

if TYPE_CHECKING:
    from udsxml2tex.models import UdsSpecification

# ---------------------------------------------------------------------------
# UDS service IDs
# ---------------------------------------------------------------------------
SID_DSC = 0x10   # DiagnosticSessionControl
SID_ER  = 0x11   # ECUReset
SID_SA  = 0x27   # SecurityAccess
SID_RDBI = 0x22  # ReadDataByIdentifier
SID_WDBI = 0x2E  # WriteDataByIdentifier
SID_RC  = 0x31   # RoutineControl
SID_RDTCI = 0x19 # ReadDTCInformation
SID_CDTCI = 0x14 # ClearDiagnosticInformation

_DEFAULT_TIMEOUT = 2.0


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _dsc_step(session_id: int, session_name: str) -> TestStep:
    return TestStep(
        name=f"EnterSession_{session_name}",
        service_id=SID_DSC,
        request=bytes([SID_DSC, session_id]),
        expected_response="positive",
        timeout=_DEFAULT_TIMEOUT,
        description=f"Switch to session 0x{session_id:02X} ({session_name})",
    )


def _return_to_default() -> TestStep:
    return TestStep(
        name="ReturnToDefaultSession",
        service_id=SID_DSC,
        request=bytes([SID_DSC, 0x01]),
        expected_response="positive",
        timeout=_DEFAULT_TIMEOUT,
        description="Return to DefaultSession (0x01)",
    )


def _sa_seed_step(level: int) -> TestStep:
    seed_sub = (level * 2) - 1  # odd sub-function = request seed
    return TestStep(
        name=f"SA_RequestSeed_L{level}",
        service_id=SID_SA,
        request=bytes([SID_SA, seed_sub]),
        expected_response="positive",
        timeout=_DEFAULT_TIMEOUT,
        description=f"SecurityAccess: request seed for level {level} "
                    f"(sub=0x{seed_sub:02X})",
    )


def _setup_for_did(
    did: "Any",
    spec: "UdsSpecification",
) -> list[TestStep]:
    """Return setup steps (session + optional security unlock) for a DID."""
    steps: list[TestStep] = []

    # Pick the first non-default session if any, else default
    target_session = None
    for sname in (did.supported_sessions or []):
        sess = next((s for s in spec.sessions if s.short_name == sname), None)
        if sess and sess.session_id != 0x01:
            target_session = sess
            break

    if target_session:
        steps.append(_dsc_step(target_session.session_id, target_session.short_name))

    # If security is required, at least request the seed
    for lname in (did.required_security_levels or []):
        lvl = next((l for l in spec.security_levels if l.short_name == lname), None)
        if lvl:
            steps.append(_sa_seed_step(lvl.security_level))
            # Key send step is a placeholder — executor replaces it if a key
            # function is supplied.  We include it so the test structure is
            # complete; the executor marks it SKIP when no key function exists.
            key_sub = lvl.security_level * 2  # even sub-function
            steps.append(TestStep(
                name=f"SA_SendKey_L{lvl.security_level}",
                service_id=SID_SA,
                request=bytes([SID_SA, key_sub]),  # payload appended by executor
                expected_response="positive",
                timeout=_DEFAULT_TIMEOUT,
                description=f"SecurityAccess: send key for level {lvl.security_level} "
                            f"(sub=0x{key_sub:02X}) — key computed at runtime",
            ))
            break  # one security level unlock is enough

    return steps


# ---------------------------------------------------------------------------
# Per-category generators
# ---------------------------------------------------------------------------

def generate_session_tests(spec: "UdsSpecification") -> list[TestCase]:
    """Generate one DiagnosticSessionControl test per session defined in *spec*.

    Each test sends a single DSC 0x10 request and expects a positive response.
    The teardown returns to DefaultSession (0x01) so subsequent tests always
    start from a known state.

    Args:
        spec: Parsed ``UdsSpecification`` containing ``spec.sessions``.

    Returns:
        One ``TestCase`` per session.  Empty list when ``spec.sessions`` is empty.
    """
    cases: list[TestCase] = []
    for sess in spec.sessions:
        tc = TestCase(
            tc_id=f"TC_SESSION_{sess.short_name}",
            category="session",
            title=f"Enter session {sess.short_name} (0x{sess.session_id:02X})",
            description=f"Verify that DiagnosticSessionControl 0x{sess.session_id:02X} "
                        f"returns a positive response.",
            setup=[],
            steps=[
                TestStep(
                    name="DSC_Request",
                    service_id=SID_DSC,
                    request=bytes([SID_DSC, sess.session_id]),
                    expected_response="positive",
                    timeout=max(_DEFAULT_TIMEOUT, sess.p2_star_server_max),
                    description=f"DiagnosticSessionControl 0x{sess.session_id:02X}",
                )
            ],
            teardown=[_return_to_default()],
        )
        cases.append(tc)
    return cases


def generate_security_tests(spec: "UdsSpecification") -> list[TestCase]:
    """Generate SecurityAccess (0x27) tests for every level defined in *spec*.

    Each test case has two steps:

    1. ``SA_RequestSeed`` — odd sub-function ``(level * 2 - 1)``; expects positive
       response containing the seed bytes.
    2. ``SA_SendKey`` — even sub-function ``(level * 2)``; key bytes are appended
       at runtime by the executor using the caller-supplied ``key_functions`` dict.
       If no key function is registered the step is marked SKIP.

    The test enters the first non-default session that requires this security level
    (derived by scanning ``spec.services``) and returns to DefaultSession on teardown.

    Args:
        spec: Parsed ``UdsSpecification`` containing ``spec.security_levels``.

    Returns:
        One ``TestCase`` per security level.
    """
    cases: list[TestCase] = []
    for lvl in spec.security_levels:
        seed_sub = (lvl.security_level * 2) - 1
        key_sub  = lvl.security_level * 2

        # Enter the first session that requires this security level (if any)
        required_session: Optional["DiagSession"] = None
        for svc in spec.services:
            for lname in (svc.required_security_levels or []):
                if lname == lvl.short_name:
                    for sname in (svc.supported_sessions or []):
                        sess = next(
                            (s for s in spec.sessions if s.short_name == sname), None
                        )
                        if sess and sess.session_id != 0x01:
                            required_session = sess
                            break
                if required_session:
                    break
            if required_session:
                break

        setup = []
        if required_session:
            setup.append(_dsc_step(required_session.session_id, required_session.short_name))

        tc = TestCase(
            tc_id=f"TC_SECURITY_L{lvl.security_level}_{lvl.short_name}",
            category="security",
            title=f"SecurityAccess level {lvl.security_level} ({lvl.short_name})",
            description=(
                f"Verify seed request returns positive response. "
                f"Key send (sub=0x{key_sub:02X}) requires a key function supplied at "
                f"runtime via --ecu-key-plugin."
            ),
            setup=setup,
            steps=[
                TestStep(
                    name="SA_RequestSeed",
                    service_id=SID_SA,
                    request=bytes([SID_SA, seed_sub]),
                    expected_response="positive",
                    timeout=_DEFAULT_TIMEOUT,
                    description=f"Request seed, sub=0x{seed_sub:02X}",
                ),
                TestStep(
                    name="SA_SendKey",
                    service_id=SID_SA,
                    request=bytes([SID_SA, key_sub]),
                    expected_response="positive",
                    timeout=_DEFAULT_TIMEOUT,
                    description=f"Send key, sub=0x{key_sub:02X} — key computed at runtime",
                ),
            ],
            teardown=[_return_to_default()],
        )
        cases.append(tc)
    return cases


def generate_did_read_tests(spec: "UdsSpecification") -> list[TestCase]:
    """Generate ReadDataByIdentifier (0x22) tests for every readable DID in *spec*.

    For each DID with ``read_access=True``:

    * **Setup** — enters the required session (first non-default session from
      ``did.supported_sessions``) and performs the SecurityAccess seed+key
      handshake when ``did.required_security_levels`` is non-empty.
    * **Step** — sends ``0x22 DID_HI DID_LO`` and expects a positive response.
      ``expected_response_length`` is set to ``3 + did.total_byte_length``
      (SID 0x62 + two DID bytes + data payload) so the executor validates the
      exact payload size.
    * **Teardown** — returns to DefaultSession.

    Args:
        spec: Parsed ``UdsSpecification`` containing ``spec.dids``.

    Returns:
        One ``TestCase`` per readable DID.
    """
    cases: list[TestCase] = []
    for did in spec.dids:
        if not did.read_access:
            continue
        did_hi = (did.did_id >> 8) & 0xFF
        did_lo = did.did_id & 0xFF

        # Positive RDBI response: 0x62 DID_HI DID_LO data... → known length
        resp_len = 3 + did.total_byte_length if did.total_byte_length > 0 else None

        setup = _setup_for_did(did, spec)
        tc = TestCase(
            tc_id=f"TC_DID_READ_{did.did_id_hex}_{did.short_name}",
            category="did_read",
            title=f"ReadDataByIdentifier {did.did_id_hex} ({did.short_name})",
            description=(
                f"Verify that 0x22 {did.did_id_hex} returns a positive response "
                f"with the expected payload length ({did.total_byte_length} bytes)."
            ),
            setup=setup,
            steps=[
                TestStep(
                    name="RDBI_Request",
                    service_id=SID_RDBI,
                    request=bytes([SID_RDBI, did_hi, did_lo]),
                    expected_response="positive",
                    expected_response_length=resp_len,
                    timeout=_DEFAULT_TIMEOUT,
                    description=f"ReadDataByIdentifier {did.did_id_hex}",
                )
            ],
            teardown=[_return_to_default()],
        )
        cases.append(tc)
    return cases


def generate_did_write_tests(spec: "UdsSpecification") -> list[TestCase]:
    """Generate WriteDataByIdentifier (0x2E) tests for every writable DID.

    Payload is zero-filled to ``did.total_byte_length`` bytes.  This tests
    that the ECU accepts (or rejects with a known NRC) a structurally valid
    write request; callers who need real write values should override the
    generated ``TestStep.request`` bytes before running.

    ``expected_response`` is set to ``"any"`` because zero-filled data may
    legitimately trigger an application-level NRC (e.g. 0x22
    conditionsNotCorrect) on some ECUs while passing on others.

    Args:
        spec: Parsed ``UdsSpecification`` containing ``spec.dids``.

    Returns:
        One ``TestCase`` per writable DID.
    """
    cases: list[TestCase] = []
    for did in spec.dids:
        if not did.write_access:
            continue
        did_hi = (did.did_id >> 8) & 0xFF
        did_lo = did.did_id & 0xFF
        # Zero-filled payload — real values require application knowledge
        payload = bytes(did.total_byte_length) if did.total_byte_length > 0 else b"\x00"

        setup = _setup_for_did(did, spec)
        tc = TestCase(
            tc_id=f"TC_DID_WRITE_{did.did_id_hex}_{did.short_name}",
            category="did_write",
            title=f"WriteDataByIdentifier {did.did_id_hex} ({did.short_name})",
            description=(
                f"Send 0x2E {did.did_id_hex} with a zero-filled {len(payload)}-byte "
                f"payload and verify the ECU responds (positive or application-specific NRC)."
            ),
            setup=setup,
            steps=[
                TestStep(
                    name="WDBI_Request",
                    service_id=SID_WDBI,
                    request=bytes([SID_WDBI, did_hi, did_lo]) + payload,
                    expected_response="any",
                    timeout=_DEFAULT_TIMEOUT,
                    description=f"WriteDataByIdentifier {did.did_id_hex} "
                                f"(zero-filled {len(payload)} bytes)",
                )
            ],
            teardown=[_return_to_default()],
        )
        cases.append(tc)
    return cases


def generate_routine_tests(spec: "UdsSpecification") -> list[TestCase]:
    """Generate RoutineControl (0x31) tests for every routine in *spec*.

    Emits Start (sub=0x01), Stop (sub=0x02, if ``routine.stop_supported``), and
    RequestResults (sub=0x03, if ``routine.result_supported``) steps within a
    single test case per routine.  In-parameter payload is zero-filled to the
    total bit-size of ``routine.in_parameters``.

    Args:
        spec: Parsed ``UdsSpecification`` containing ``spec.routines``.

    Returns:
        One ``TestCase`` per routine that has at least one supported sub-function.
        Routines with no supported sub-function are silently skipped.
    """
    cases: list[TestCase] = []
    for routine in spec.routines:
        rid_hi = (routine.routine_id >> 8) & 0xFF
        rid_lo = routine.routine_id & 0xFF

        # Build in-parameters (zero-filled)
        in_payload = b""
        if routine.in_parameters:
            total_bits = sum(p.bit_size for p in routine.in_parameters)
            in_payload = bytes((total_bits + 7) // 8)

        setup: list[TestStep] = []
        # Enter required session
        for sname in (routine.supported_sessions or []):
            sess = next((s for s in spec.sessions if s.short_name == sname), None)
            if sess and sess.session_id != 0x01:
                setup.append(_dsc_step(sess.session_id, sess.short_name))
                break
        # Unlock security if required
        for lname in (routine.required_security_levels or []):
            lvl = next((l for l in spec.security_levels if l.short_name == lname), None)
            if lvl:
                setup.append(_sa_seed_step(lvl.security_level))
                key_sub = lvl.security_level * 2
                setup.append(TestStep(
                    name=f"SA_SendKey_L{lvl.security_level}",
                    service_id=SID_SA,
                    request=bytes([SID_SA, key_sub]),
                    expected_response="positive",
                    timeout=_DEFAULT_TIMEOUT,
                    description=f"Send key for level {lvl.security_level}",
                ))
                break

        steps = []
        if routine.start_supported:
            steps.append(TestStep(
                name="RC_Start",
                service_id=SID_RC,
                request=bytes([SID_RC, 0x01, rid_hi, rid_lo]) + in_payload,
                expected_response="positive",
                timeout=_DEFAULT_TIMEOUT,
                description=f"RoutineControl Start {routine.routine_id_hex}",
            ))
        if routine.stop_supported:
            steps.append(TestStep(
                name="RC_Stop",
                service_id=SID_RC,
                request=bytes([SID_RC, 0x02, rid_hi, rid_lo]),
                expected_response="positive",
                timeout=_DEFAULT_TIMEOUT,
                description=f"RoutineControl Stop {routine.routine_id_hex}",
            ))
        if routine.result_supported:
            steps.append(TestStep(
                name="RC_Result",
                service_id=SID_RC,
                request=bytes([SID_RC, 0x03, rid_hi, rid_lo]),
                expected_response="positive",
                timeout=_DEFAULT_TIMEOUT,
                description=f"RoutineControl RequestResults {routine.routine_id_hex}",
            ))

        if not steps:
            continue

        tc = TestCase(
            tc_id=f"TC_ROUTINE_{routine.routine_id_hex}_{routine.short_name}",
            category="routine",
            title=f"RoutineControl {routine.routine_id_hex} ({routine.short_name})",
            description=f"Verify routine {routine.short_name} responds to "
                        f"Start/Stop/Result as configured in the spec.",
            setup=setup,
            steps=steps,
            teardown=[_return_to_default()],
        )
        cases.append(tc)
    return cases


def generate_dtc_tests(spec: "UdsSpecification") -> list[TestCase]:
    """Generate DTC read and clear test cases.

    Always produces exactly three test cases regardless of how many DTCs are
    defined in the spec:

    1. ``TC_DTC_READ_ALL`` — RDTCI 0x19 sub=0x02 (reportDTCByStatusMask) with
       mask 0xFF; expects positive response; valid in all sessions.
    2. ``TC_DTC_READ_SUPPORTED`` — RDTCI 0x19 sub=0x0A (reportSupportedDTCs);
       expects positive response; valid in all sessions.
    3. ``TC_DTC_CLEAR_ALL`` — CDTCI 0x14 group=0xFFFFFF; enters Extended session
       (0x03) first if it is defined in the spec; expects positive response.

    Args:
        spec: Parsed ``UdsSpecification``.  ``spec.sessions`` is checked to
              determine whether an Extended session exists for the clear test.

    Returns:
        List of three ``TestCase`` objects.
    """
    cases: list[TestCase] = []

    # 0x19 02 FF — read all active DTCs (status mask 0xFF)
    cases.append(TestCase(
        tc_id="TC_DTC_READ_ALL",
        category="dtc",
        title="ReadDTCInformation — all active DTCs (0x19 0x02 0xFF)",
        description="Verify that ReadDTCInformation sub=0x02 (reportDTCByStatusMask) "
                    "with mask 0xFF returns a positive response.",
        setup=[],
        steps=[
            TestStep(
                name="RDTCI_AllActive",
                service_id=SID_RDTCI,
                request=bytes([SID_RDTCI, 0x02, 0xFF]),
                expected_response="positive",
                timeout=_DEFAULT_TIMEOUT,
                description="ReadDTCInformation reportDTCByStatusMask 0xFF",
            )
        ],
        teardown=[],
    ))

    # 0x19 0A — read supported DTCs
    cases.append(TestCase(
        tc_id="TC_DTC_READ_SUPPORTED",
        category="dtc",
        title="ReadDTCInformation — supported DTCs (0x19 0x0A)",
        description="Verify that ReadDTCInformation sub=0x0A (reportSupportedDTCs) "
                    "returns a positive response.",
        setup=[],
        steps=[
            TestStep(
                name="RDTCI_Supported",
                service_id=SID_RDTCI,
                request=bytes([SID_RDTCI, 0x0A]),
                expected_response="positive",
                timeout=_DEFAULT_TIMEOUT,
                description="ReadDTCInformation reportSupportedDTCs",
            )
        ],
        teardown=[],
    ))

    # 0x14 FF FF FF — clear all DTCs (extended session only; add setup if needed)
    extended = next(
        (s for s in spec.sessions if s.session_id == 0x03), None
    )
    setup = [_dsc_step(0x03, extended.short_name)] if extended else []
    cases.append(TestCase(
        tc_id="TC_DTC_CLEAR_ALL",
        category="dtc",
        title="ClearDiagnosticInformation — all DTCs (0x14 0xFF 0xFF 0xFF)",
        description="Verify that ClearDiagnosticInformation with group 0xFFFFFF "
                    "returns a positive response (may require extended session).",
        setup=setup,
        steps=[
            TestStep(
                name="CDTCI_ClearAll",
                service_id=SID_CDTCI,
                request=bytes([SID_CDTCI, 0xFF, 0xFF, 0xFF]),
                expected_response="positive",
                timeout=_DEFAULT_TIMEOUT,
                description="ClearDiagnosticInformation group 0xFFFFFF",
            )
        ],
        teardown=[_return_to_default()],
    ))

    return cases


def generate_negative_tests(spec: "UdsSpecification") -> list[TestCase]:
    """Generate negative (NRC-expected) test cases for RDBI access violations.

    Two families are produced for each applicable DID:

    **wrong_session** — Send RDBI while remaining in DefaultSession for a DID
    whose ``supported_sessions`` list contains only non-default sessions.
    Expected: NRC 0x31 (requestOutOfRange).  A wrong-session test is generated
    only when ``did.supported_sessions`` is non-empty and does NOT include the
    default session (0x01); DIDs with no session restriction are skipped.

    **no_security** — Enter the required session but skip the SecurityAccess
    handshake, then send RDBI for a DID that has ``required_security_levels``.
    Expected: NRC 0x33 (securityAccessDenied).

    These two families complement ``generate_did_read_tests`` (happy path) to
    provide basic boundary testing.  For exhaustive coverage of all
    (state, service) pairs — including DIDs that behave differently across
    multiple non-default sessions — use
    :func:`udsxml2tex.ecu_test.formal_generator.generate_formal_test_suite`.

    Args:
        spec: Parsed ``UdsSpecification`` containing ``spec.dids``.

    Returns:
        List of ``TestCase`` objects in category ``"negative"``.
    """
    cases: list[TestCase] = []

    for did in spec.dids:
        if not did.read_access:
            continue
        did_hi = (did.did_id >> 8) & 0xFF
        did_lo = did.did_id & 0xFF

        # --- Wrong-session test ---
        # Gather session IDs listed for this DID; skip when list is empty or
        # the default session (0x01) is explicitly included.
        session_ids: list[int] = []
        for sname in (did.supported_sessions or []):
            sess = next((s for s in spec.sessions if s.short_name == sname), None)
            if sess is not None:
                session_ids.append(sess.session_id)

        if session_ids and 0x01 not in session_ids:
            cases.append(TestCase(
                tc_id=f"TC_NEG_WRONG_SESSION_{did.did_id_hex}_{did.short_name}",
                category="negative",
                title=f"[Negative] RDBI {did.did_id_hex} in wrong session",
                description=(
                    f"Verify that RDBI {did.did_id_hex} issued in DefaultSession "
                    f"returns NRC 0x31 (requestOutOfRange); the DID is only "
                    f"accessible in a non-default session."
                ),
                setup=[],  # remain in DefaultSession
                steps=[
                    TestStep(
                        name="RDBI_WrongSession",
                        service_id=SID_RDBI,
                        request=bytes([SID_RDBI, did_hi, did_lo]),
                        expected_response="negative",
                        expected_nrc=0x31,
                        timeout=_DEFAULT_TIMEOUT,
                        description=f"RDBI {did.did_id_hex} — expect NRC 0x31",
                    )
                ],
                teardown=[],
            ))

        # --- No-security test ---
        if not did.required_security_levels:
            continue

        # Enter required session but skip security unlock
        setup_nosec: list[TestStep] = []
        for sname in (did.supported_sessions or []):
            sess = next((s for s in spec.sessions if s.short_name == sname), None)
            if sess and sess.session_id != 0x01:
                setup_nosec.append(_dsc_step(sess.session_id, sess.short_name))
                break

        cases.append(TestCase(
            tc_id=f"TC_NEG_NO_SECURITY_{did.did_id_hex}_{did.short_name}",
            category="negative",
            title=f"[Negative] RDBI {did.did_id_hex} without security unlock",
            description=(
                f"Verify that RDBI {did.did_id_hex} issued without prior "
                f"SecurityAccess unlock returns NRC 0x33 (securityAccessDenied)."
            ),
            setup=setup_nosec,
            steps=[
                TestStep(
                    name="RDBI_NoSecurity",
                    service_id=SID_RDBI,
                    request=bytes([SID_RDBI, did_hi, did_lo]),
                    expected_response="negative",
                    expected_nrc=0x33,
                    timeout=_DEFAULT_TIMEOUT,
                    description=f"RDBI {did.did_id_hex} — expect NRC 0x33",
                )
            ],
            teardown=[_return_to_default()],
        ))

    return cases


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

CATEGORY_GENERATORS = {
    "session":   generate_session_tests,
    "security":  generate_security_tests,
    "did_read":  generate_did_read_tests,
    "did_write": generate_did_write_tests,
    "routine":   generate_routine_tests,
    "dtc":       generate_dtc_tests,
    "negative":  generate_negative_tests,
}


def generate_test_suite(
    spec: "UdsSpecification",
    categories: Optional[list[str]] = None,
) -> list[TestCase]:
    """Generate a full test suite from *spec*.

    Args:
        spec:       Parsed UdsSpecification.
        categories: Subset of categories to generate.  Defaults to all.
                    Valid values: session, security, did_read, did_write,
                    routine, dtc, negative.

    Returns:
        Ordered list of TestCase objects.
    """
    selected = categories or list(CATEGORY_GENERATORS)
    cases: list[TestCase] = []
    for cat in selected:
        if cat not in CATEGORY_GENERATORS:
            raise ValueError(
                f"Unknown test category {cat!r}. "
                f"Valid: {list(CATEGORY_GENERATORS)}"
            )
        cases.extend(CATEGORY_GENERATORS[cat](spec))
    return cases
