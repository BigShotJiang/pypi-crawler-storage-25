"""Test execution engine — runs TestCase objects against a live ECU.

Usage example::

    from udsxml2tex import ArxmlParser
    from udsxml2tex.ecu_test.generator import generate_test_suite
    from udsxml2tex.ecu_test.transport import make_connection
    from udsxml2tex.ecu_test.executor import EcuTestExecutor
    from udsxml2tex.ecu_test.logger import write_reports

    spec = ArxmlParser().parse("ecu.arxml")
    conn = make_connection(spec, interface="vector", channel=0)
    cases = generate_test_suite(spec)

    with EcuTestExecutor(conn) as exe:
        suite = exe.run(cases)

    write_reports(suite, out_dir="test_results/")

Security access key functions
------------------------------
For security levels where you have the algorithm, pass a dict::

    def my_key(seed: bytes, level: int) -> bytes:
        return bytes(b ^ 0xAA for b in seed)   # example

    exe = EcuTestExecutor(conn, key_functions={1: my_key, 3: my_key})

Steps named ``SA_SendKey_L<n>`` are automatically fed the seed from the
preceding ``SA_RequestSeed_L<n>`` step and the key function is called to
compute the key.  If no key function is registered for a level the step is
marked SKIP (the rest of the test case still runs, but security-gated steps
will typically respond with NRC 0x24 securityAccessDenied).
"""

from __future__ import annotations

import time
from datetime import datetime
from typing import Callable, Optional

from .models import (
    StepResult,
    TestCase,
    TestCaseResult,
    TestStep,
    TestSuiteResult,
)
from .transport import UdsConnection

# NRC for "service not supported" and "conditions not correct"
_NRC_PREFIX = 0x7F
_NRC_SNS    = 0x11  # serviceNotSupported
_NRC_SAD    = 0x24  # securityAccessDenied

KeyFunction = Callable[[bytes, int], bytes]


def _parse_response(raw: Optional[bytes]) -> tuple[bool, Optional[int], Optional[bytes]]:
    """Return (is_positive, nrc_or_None, payload_without_sid)."""
    if raw is None:
        return False, None, None
    if len(raw) >= 3 and raw[0] == _NRC_PREFIX:
        return False, raw[2], raw
    return True, None, raw[1:] if len(raw) > 1 else b""


def _extract_security_level(step: TestStep) -> Optional[int]:
    """Parse the security level from a step named SA_SendKey_L<n>."""
    name = step.name
    if "SA_SendKey_L" in name:
        try:
            return int(name.split("SA_SendKey_L", 1)[1])
        except (ValueError, IndexError):
            pass
    return None


def _extract_seed_level(step: TestStep) -> Optional[int]:
    """Parse the security level from a step named SA_RequestSeed_L<n> / SA_RequestSeed."""
    name = step.name
    for prefix in ("SA_RequestSeed_L", "SA_RequestSeed"):
        if name.startswith(prefix):
            suffix = name[len(prefix):]
            if suffix.isdigit():
                return int(suffix)
    # Fall back: derive from sub-function byte (odd sub = seed request)
    if len(step.request) >= 2:
        sub = step.request[1]
        if sub % 2 == 1:
            return (sub + 1) // 2
    return None


class EcuTestExecutor:
    """Runs TestCase objects against a UDS ECU via *connection*.

    Args:
        connection:    An open (or not-yet-open) UdsConnection.
        key_functions: Dict mapping security_level (int) → callable(seed, level) → key.
        default_timeout: Fallback timeout in seconds when a step does not specify one.
    """

    def __init__(
        self,
        connection: UdsConnection,
        key_functions: Optional[dict[int, KeyFunction]] = None,
        default_timeout: float = 2.0,
    ) -> None:
        self._conn = connection
        self._keys: dict[int, KeyFunction] = key_functions or {}
        self._default_timeout = default_timeout
        # Track seeds received in this run so SA_SendKey steps can use them
        self._seeds: dict[int, bytes] = {}

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    def __enter__(self) -> "EcuTestExecutor":
        self._conn.open()
        return self

    def __exit__(self, *_: object) -> None:
        self._conn.close()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run(
        self,
        cases: list[TestCase],
        spec_name: str = "",
        interface: str = "",
        channel: str = "",
    ) -> TestSuiteResult:
        """Execute all test cases and return a TestSuiteResult."""
        suite = TestSuiteResult(
            spec_name=spec_name,
            interface=interface,
            channel=str(channel),
            started_at=datetime.now(),
        )
        t0 = time.monotonic()
        for tc in cases:
            suite.results.append(self._run_case(tc))
        suite.elapsed_ms = (time.monotonic() - t0) * 1000.0
        return suite

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _run_case(self, tc: TestCase) -> TestCaseResult:
        result = TestCaseResult(tc=tc, verdict="PASS", started_at=datetime.now())
        self._seeds.clear()
        t0 = time.monotonic()

        # --- Setup phase: abort on failure ---
        for step in tc.setup:
            sr = self._run_step(step)
            result.step_results.append(sr)
            if not sr.passed:
                result.verdict = "ERROR"
                result.error_message = (
                    f"Setup step '{step.name}' failed: {sr.error or sr.actual_nrc}"
                )
                result.elapsed_ms = (time.monotonic() - t0) * 1000.0
                self._try_teardown(tc, result)
                return result

        # --- Test phase ---
        for step in tc.steps:
            sr = self._run_step(step)
            result.step_results.append(sr)
            if not sr.passed and result.verdict == "PASS":
                result.verdict = "FAIL"

        # --- Teardown (best-effort) ---
        self._try_teardown(tc, result)
        result.elapsed_ms = (time.monotonic() - t0) * 1000.0
        return result

    def _try_teardown(self, tc: TestCase, result: TestCaseResult) -> None:
        for step in tc.teardown:
            sr = self._run_step(step)
            result.step_results.append(sr)

    def _run_step(self, step: TestStep) -> StepResult:
        # --- Security access key injection ---
        level = _extract_security_level(step)
        if level is not None:
            seed = self._seeds.get(level)
            if seed is None or level not in self._keys:
                # No key available — mark SKIP
                return StepResult(
                    step=step,
                    passed=True,  # SKIP counts as passed (not a failure)
                    actual_response=None,
                    error=f"SKIP: no key function for security level {level}",
                    elapsed_ms=0.0,
                )
            key_bytes = self._keys[level](seed, level)
            # Replace request: [SA, even_sub] + key_bytes
            request = step.request[:2] + key_bytes
        else:
            request = step.request

        # --- Send and receive ---
        t0 = time.monotonic()
        try:
            self._conn.send(request)
            raw = self._conn.recv(
                timeout=step.timeout if step.timeout > 0 else self._default_timeout
            )
        except Exception as exc:  # noqa: BLE001
            elapsed = (time.monotonic() - t0) * 1000.0
            return StepResult(
                step=step,
                passed=False,
                error=f"Transport error: {exc}",
                elapsed_ms=elapsed,
            )

        elapsed = (time.monotonic() - t0) * 1000.0
        is_positive, nrc, payload = _parse_response(raw)

        # --- Store seed if this was a seed request ---
        seed_level = _extract_seed_level(step)
        if seed_level is not None and is_positive and payload:
            # positive SA response: [0x67, sub, seed_bytes...]
            # payload here is raw[1:] = [sub, seed_bytes...]
            if len(payload) >= 2:
                self._seeds[seed_level] = payload[1:]

        # --- Verdict ---
        passed = self._check_verdict(step, is_positive, nrc, raw)
        return StepResult(
            step=step,
            passed=passed,
            actual_response=raw,
            actual_nrc=nrc,
            elapsed_ms=elapsed,
            error=None if passed else self._describe_failure(step, is_positive, nrc, raw),
        )

    @staticmethod
    def _check_verdict(
        step: TestStep,
        is_positive: bool,
        nrc: Optional[int],
        raw: Optional[bytes],
    ) -> bool:
        if raw is None:
            return False  # timeout
        exp = step.expected_response
        if exp == "any":
            return True
        if exp == "positive":
            if not is_positive:
                return False
            # Validate response payload length when expected length is known
            if step.expected_response_length is not None:
                return len(raw) == step.expected_response_length
            return True
        if exp == "negative":
            if not is_positive and step.expected_nrc is not None:
                return nrc == step.expected_nrc
            return not is_positive
        return False

    @staticmethod
    def _describe_failure(
        step: TestStep,
        is_positive: bool,
        nrc: Optional[int],
        raw: Optional[bytes],
    ) -> str:
        if raw is None:
            return "Timeout — no response received"
        if step.expected_response == "positive":
            if not is_positive:
                nrc_s = f"0x{nrc:02X}" if nrc is not None else "?"
                return f"Expected positive response, got NRC {nrc_s}"
            # positive but still failed → length mismatch
            if step.expected_response_length is not None:
                return (
                    f"Response length mismatch: expected "
                    f"{step.expected_response_length} bytes, got {len(raw)} bytes"
                )
        if step.expected_response == "negative" and is_positive:
            return "Expected negative response, got positive"
        if step.expected_nrc is not None and nrc != step.expected_nrc:
            got = f"0x{nrc:02X}" if nrc is not None else "?"
            return f"Expected NRC 0x{step.expected_nrc:02X}, got {got}"
        return f"Unexpected response: {raw.hex(' ').upper()}"
