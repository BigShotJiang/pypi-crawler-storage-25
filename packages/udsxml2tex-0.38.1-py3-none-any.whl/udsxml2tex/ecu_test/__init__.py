"""udsxml2tex.ecu_test — ECU hardware testing via CAN/ISO-TP/UDS.

Quick-start::

    pip install udsxml2tex[ecu-test]

    from udsxml2tex import ArxmlParser
    from udsxml2tex.ecu_test import generate_test_suite, make_connection
    from udsxml2tex.ecu_test import EcuTestExecutor, write_reports

    spec = ArxmlParser().parse("my_ecu.arxml")
    conn = make_connection(spec, interface="vector", channel=0)
    cases = generate_test_suite(spec)

    with EcuTestExecutor(conn) as exe:
        suite = exe.run(cases, spec_name=spec.ecu_name, interface="vector", channel="0")

    paths = write_reports(suite, out_dir="results/")
    print(f"HTML report: {paths['html']}")
"""

from .executor import EcuTestExecutor
from .generator import generate_test_suite, generate_negative_tests, CATEGORY_GENERATORS
from .formal_generator import generate_formal_test_suite
from .fsm import UdsFsm, UdsState, UdsEdge
from .logger import (
    write_reports,
    write_json,
    write_csv,
    write_html,
    write_junit_xml,
    write_coverage_html,
)
from .coverage import CoverageItem, CoverageReport, analyze_coverage
from .models import (
    TestCase,
    TestCaseResult,
    TestStep,
    StepResult,
    TestSuiteResult,
)
from .transport import (
    MockConnection,
    PythonCanIsoTpConnection,
    UdsConnection,
    make_connection,
)

__all__ = [
    # executor
    "EcuTestExecutor",
    # generator (heuristic)
    "generate_test_suite",
    "generate_negative_tests",
    "CATEGORY_GENERATORS",
    # generator (formal / model-checking)
    "generate_formal_test_suite",
    # FSM
    "UdsFsm",
    "UdsState",
    "UdsEdge",
    # logger
    "write_reports",
    "write_json",
    "write_csv",
    "write_html",
    "write_junit_xml",
    "write_coverage_html",
    # coverage
    "CoverageItem",
    "CoverageReport",
    "analyze_coverage",
    # models
    "TestCase",
    "TestCaseResult",
    "TestStep",
    "StepResult",
    "TestSuiteResult",
    # transport
    "MockConnection",
    "PythonCanIsoTpConnection",
    "UdsConnection",
    "make_connection",
]
