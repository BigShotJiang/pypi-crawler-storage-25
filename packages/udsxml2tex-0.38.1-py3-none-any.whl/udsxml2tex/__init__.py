"""udsxml2tex - Convert AUTOSAR DCM/CanTp/DEM arxml to UDS specification documents and ISO 22901-1 ODX/PDX."""

__version__ = "0.38.1"

from udsxml2tex.cantp_parser import CanTpParser
from udsxml2tex.config import GenerationConfig
from udsxml2tex.dem_parser import DemParser
from udsxml2tex.generator import TexGenerator
from udsxml2tex.interactive import InteractiveSession
from udsxml2tex.models import (
    AccessTimingRow,
    AuthenticationConfig,
    CanTpChannel,
    CanTpConfig,
    DataElement,
    DemCombinedDtcEntry,
    DemDebounceConfig,
    DemDtcEntry,
    DemEnableCondition,
    DemEventMemoryConfig,
    DemEventParameter,
    DemExtendedDataClass,
    DemFreezeFrameClass,
    DemGeneralConfig,
    DemIndicatorConfig,
    DemOperationCycle,
    DemStorageCondition,
    DiagSession,
    Did,
    DslConnection,
    DtcGroup,
    LinkControlBaudrateEntry,
    NrcEntry,
    ProtocolRow,
    Routine,
    RoutineParameter,
    SecurityLevel,
    SubFunction,
    UdsService,
    UdsSpecification,
)
from udsxml2tex.c_scanner import scan_did_variables, scan_rid_variables
from udsxml2tex.parser import ArxmlParser, ArxmlValidationError, ArxmlValidationWarning
from udsxml2tex.validator import UdsValidator, ValidationIssue, ValidationResult, validate
from udsxml2tex.diff import SpecDiffer, SpecDiff, DiffEntry, DiffKind, diff_specs
from udsxml2tex.plugin import ParserPlugin, GeneratorPlugin, PluginRegistry, registry
from udsxml2tex.i18n import Translator, SUPPORTED_LANGS, t as translate
from udsxml2tex.visualizations import (
    generate_session_service_heatmap,
    generate_security_did_heatmap,
    generate_timing_diagram,
    generate_all_visualizations,
)

# LLM features — submodule import fails fast if anthropic is missing only when
# its functions are actually called.
from udsxml2tex import llm_integration  # noqa: F401
from udsxml2tex.models import (
    DoIpConfig,
    DoIpLogicalAddress,
    DoIpRoutingActivation,
    ObdConfig,
    ObdPid,
    CommunicationConfig,
    Frame,
    FrameSignal,
    ISignal,
    Pdu,
    EcuInstance,
    NetworkTopology,
    ApConfig,
    ApServiceInterface,
    ApMethod,
    ApEvent,
    ApField,
    ApDiagnosticService,
)
from udsxml2tex.doip_parser import DoIpParser
from udsxml2tex.obd_parser import ObdParser
from udsxml2tex.comm_arxml_parser import CommArxmlParser
from udsxml2tex.ap_parser import ApParser
from udsxml2tex.schema import generate_json_schema, save_json_schema, generate_pydantic_models
from udsxml2tex import ecu_test  # noqa: F401
from udsxml2tex.odx import (
    OdxCategory,
    OdxDocument,
    empty_supplement,
    load_supplement,
    map_ecu_system_to_odx,
    map_spec_to_odx,
)
from udsxml2tex.boot_overlay import (
    BootOverlay,
    BootloaderInfo,
    DomainCanIds,
    DomainMap,
    FlashSegment,
    apply_to_spec as apply_boot_overlay,
    empty_overlay,
    load_overlay,
)

__all__ = [
    "ecu_test",
    "AccessTimingRow",
    "ArxmlParser",
    "ArxmlValidationError",
    "ArxmlValidationWarning",
    "AuthenticationConfig",
    "CanTpParser",
    "DemCombinedDtcEntry",
    "DemDebounceConfig",
    "DemDtcEntry",
    "DemEnableCondition",
    "DemEventMemoryConfig",
    "DemEventParameter",
    "DemExtendedDataClass",
    "DemFreezeFrameClass",
    "DemGeneralConfig",
    "DemIndicatorConfig",
    "DemOperationCycle",
    "DemParser",
    "DemStorageCondition",
    "DslConnection",
    "DtcGroup",
    "GenerationConfig",
    "InteractiveSession",
    "LinkControlBaudrateEntry",
    "ProtocolRow",
    "TexGenerator",
    "UdsSpecification",
    "UdsService",
    "DiagSession",
    "SecurityLevel",
    "Did",
    "DataElement",
    "Routine",
    "RoutineParameter",
    "SubFunction",
    "NrcEntry",
    "CanTpChannel",
    "CanTpConfig",
    "scan_did_variables",
    "scan_rid_variables",
    # Validation
    "UdsValidator",
    "ValidationIssue",
    "ValidationResult",
    "validate",
    # Diff
    "SpecDiffer",
    "SpecDiff",
    "DiffEntry",
    "DiffKind",
    "diff_specs",
    # Plugin system
    "ParserPlugin",
    "GeneratorPlugin",
    "PluginRegistry",
    "registry",
    # i18n
    "Translator",
    "SUPPORTED_LANGS",
    "translate",
    # DoIP (ISO 13400)
    "DoIpConfig",
    "DoIpLogicalAddress",
    "DoIpRoutingActivation",
    "DoIpParser",
    # OBD (ISO 15031 / WWH-OBD)
    "ObdConfig",
    "ObdPid",
    "ObdParser",
    # Communication ARXML
    "CommunicationConfig",
    "Frame",
    "FrameSignal",
    "ISignal",
    "Pdu",
    "EcuInstance",
    "NetworkTopology",
    "CommArxmlParser",
    # Adaptive Platform
    "ApConfig",
    "ApServiceInterface",
    "ApMethod",
    "ApEvent",
    "ApField",
    "ApDiagnosticService",
    "ApParser",
    # JSON Schema / Pydantic export
    "generate_json_schema",
    "save_json_schema",
    "generate_pydantic_models",
    # ODX / PDX (ISO 22901-1)
    "OdxCategory",
    "OdxDocument",
    "empty_supplement",
    "load_supplement",
    "map_ecu_system_to_odx",
    "map_spec_to_odx",
    # Bootloader-domain overlay
    "BootOverlay",
    "BootloaderInfo",
    "DomainCanIds",
    "DomainMap",
    "FlashSegment",
    "apply_boot_overlay",
    "empty_overlay",
    "load_overlay",
]

# ----------------------------------------------------------------------------
# Agent D — Style preset system (0.38)
# Generic-only presets (no OEM / vendor branding). Append below to keep
# merge conflicts with Agent E's reconciliation obvious.
# TODO (Agent E): fold these imports + names into the main import block
# and the literal ``__all__`` list once all agents have landed.
# ----------------------------------------------------------------------------
from udsxml2tex._style_presets import (  # noqa: F401, E402
    HeaderConfig,
    StylePreset,
    empty_header_config,
    get_preset,
    list_presets,
    load_header_config,
    register_preset,
)

__all__ += [
    # Style preset system
    "HeaderConfig",
    "StylePreset",
    "empty_header_config",
    "get_preset",
    "list_presets",
    "load_header_config",
    "register_preset",
]
