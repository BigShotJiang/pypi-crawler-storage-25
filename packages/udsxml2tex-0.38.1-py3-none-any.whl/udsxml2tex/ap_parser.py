"""AUTOSAR Adaptive Platform (AP) ARXML parser and model classes."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


# ---------------------------------------------------------------------------
# Model classes
# ---------------------------------------------------------------------------


@dataclass
class ApMethod:
    """Service interface method definition (AP)."""

    short_name: str
    method_type: str = ""   # FIRE-AND-FORGET, REQUEST-RESPONSE
    input_params: list[str] = field(default_factory=list)
    return_params: list[str] = field(default_factory=list)


@dataclass
class ApEvent:
    """Service interface event definition (AP)."""

    short_name: str
    event_type: str = ""
    data_type_ref: str = ""


@dataclass
class ApField:
    """Service interface field definition (AP)."""

    short_name: str
    data_type_ref: str = ""
    getter: bool = True
    setter: bool = False
    notifier: bool = False


@dataclass
class ApServiceInterface:
    """AUTOSAR Adaptive Platform service interface."""

    short_name: str
    namespace: str = ""     # AUTOSAR AP namespace
    version: str = ""
    category: str = ""
    methods: list[ApMethod] = field(default_factory=list)
    events: list[ApEvent] = field(default_factory=list)
    fields: list[ApField] = field(default_factory=list)


@dataclass
class ApDiagnosticService:
    """AP diagnostic service instance linked to a UDS service."""

    short_name: str
    uds_service_ref: str = ""   # reference to UDS service
    diag_event_refs: list[str] = field(default_factory=list)


@dataclass
class ApConfig:
    """AUTOSAR Adaptive Platform configuration parsed from ARXML."""

    service_interfaces: list[ApServiceInterface] = field(default_factory=list)
    diag_services: list[ApDiagnosticService] = field(default_factory=list)
    ap_version: str = "R19-11"   # Detected AP version


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------


class ApParser:
    """Parse AUTOSAR Adaptive Platform configuration from ARXML."""

    _AR_NS_URI = "http://autosar.org/schema/r4.0"

    # Known AP schema category strings that indicate an AP artefact
    _AP_CATEGORIES = frozenset(
        {
            "ADAPTIVE",
            "ADAPTIVE_PLATFORM",
            "AP",
            "SERVICE_INTERFACE",
            "ADAPTIVE_APPLICATION_SW_COMPONENT_TYPE",
        }
    )

    # ---- helpers -----------------------------------------------------------

    @staticmethod
    def _build_ns(ns: str) -> dict[str, str]:
        if ns:
            return {"ar": ApParser._AR_NS_URI}
        return {}

    @staticmethod
    def _xpath_text(el, path: str, ns: str, default: str = "") -> str:
        ns_map = ApParser._build_ns(ns)
        try:
            if ns_map:
                results = el.xpath(path, namespaces=ns_map)
            else:
                import re as _re
                results = el.xpath(_re.sub(r"ar:", "", path))
        except Exception:
            return default
        if results:
            from lxml import etree as _etree
            first = results[0]
            if isinstance(first, _etree._Element):
                return (first.text or "").strip() or default
            return str(first).strip() or default
        return default

    @staticmethod
    def _xpath_bool(el, path: str, ns: str, default: bool = False) -> bool:
        text = ApParser._xpath_text(el, path, ns, "").upper()
        if text in ("TRUE", "1", "YES"):
            return True
        if text in ("FALSE", "0", "NO"):
            return False
        return default

    @staticmethod
    def _xpath_els(el, path: str, ns: str) -> list:
        ns_map = ApParser._build_ns(ns)
        try:
            if ns_map:
                return el.xpath(path, namespaces=ns_map)
            import re as _re
            return el.xpath(_re.sub(r"ar:", "", path))
        except Exception:
            return []

    # ---- AP version detection ----------------------------------------------

    def _detect_version(self, root, ns: str) -> str:
        """Try to detect the AP version from admin data or schema attributes."""
        # Check schema version attribute on root element
        for attr_name, attr_val in root.attrib.items():
            if "schema-version" in attr_name.lower() or "schemaversion" in attr_name.lower():
                return attr_val.strip()

        # Look for ADMIN-DATA/SDGS with version information
        sdg_text = self._xpath_text(
            root,
            f".//{ns}ADMIN-DATA/{ns}SDGS/{ns}SDG/{ns}SD[@GID='DocumentRevision']",
            ns,
        )
        if sdg_text:
            return sdg_text.strip()

        # Fall back: look for AUTOSAR-VERSION element
        ver = (
            self._xpath_text(root, f".//{ns}AUTOSAR-VERSION", ns)
            or self._xpath_text(root, f".//{ns}AutosarVersion", ns)
        )
        if ver:
            return ver

        return "R19-11"

    # ---- method/event/field parsing ----------------------------------------

    def _parse_methods(self, iface_el, ns: str) -> list[ApMethod]:
        """Parse METHODS sub-container of a service interface."""
        methods: list[ApMethod] = []

        # R4 uses METHODS/METHOD (or variant elements)
        method_patterns = (
            f".//{ns}METHODS/{ns}METHOD"
            f" | .//{ns}METHODS/{ns}FIRE-AND-FORGET-METHOD"
            f" | .//{ns}METHODS/{ns}REQUEST-RESPONSE-METHOD"
            f" | .//Methods/FireAndForgetMethod"
            f" | .//Methods/RequestResponseMethod"
        )
        method_els = self._xpath_els(iface_el, method_patterns, ns)

        for meth_el in method_els:
            sn = self._xpath_text(meth_el, f"{ns}SHORT-NAME", ns)
            if not sn:
                continue

            # Derive method type from element tag
            from lxml import etree as _etree
            tag = _etree.QName(meth_el.tag).localname if hasattr(_etree, "QName") else meth_el.tag
            tag_upper = tag.upper()
            if "FIRE" in tag_upper or "FORGET" in tag_upper:
                method_type = "FIRE-AND-FORGET"
            elif "REQUEST" in tag_upper or "RESPONSE" in tag_upper:
                method_type = "REQUEST-RESPONSE"
            else:
                method_type = self._xpath_text(meth_el, f"{ns}CATEGORY", ns)

            # Input parameters (argument short names)
            in_param_els = self._xpath_els(
                meth_el,
                f".//{ns}IN-ARGUMENTS/{ns}ARGUMENT-DATA-PROTOTYPE/{ns}SHORT-NAME"
                f" | .//InArguments/ArgumentDataPrototype/SHORT-NAME",
                ns,
            )
            input_params = [
                (el.text or "").strip() for el in in_param_els if (el.text or "").strip()
            ]

            # Return / out parameters
            out_param_els = self._xpath_els(
                meth_el,
                f".//{ns}OUT-ARGUMENTS/{ns}ARGUMENT-DATA-PROTOTYPE/{ns}SHORT-NAME"
                f" | .//{ns}RETURN-VALUE/{ns}ARGUMENT-DATA-PROTOTYPE/{ns}SHORT-NAME"
                f" | .//OutArguments/ArgumentDataPrototype/SHORT-NAME",
                ns,
            )
            return_params = [
                (el.text or "").strip() for el in out_param_els if (el.text or "").strip()
            ]

            methods.append(
                ApMethod(
                    short_name=sn,
                    method_type=method_type,
                    input_params=input_params,
                    return_params=return_params,
                )
            )

        return methods

    def _parse_events(self, iface_el, ns: str) -> list[ApEvent]:
        """Parse EVENTS sub-container of a service interface."""
        events: list[ApEvent] = []
        event_els = self._xpath_els(
            iface_el,
            f".//{ns}EVENTS/{ns}VARIABLE-DATA-PROTOTYPE"
            f" | .//{ns}EVENTS/{ns}EVENT"
            f" | .//Events/VariableDataPrototype",
            ns,
        )
        for evt_el in event_els:
            sn = self._xpath_text(evt_el, f"{ns}SHORT-NAME", ns)
            if not sn:
                continue
            event_type = self._xpath_text(evt_el, f"{ns}CATEGORY", ns)
            data_type_ref = (
                self._xpath_text(evt_el, f"{ns}TYPE-TREF", ns)
                or self._xpath_text(evt_el, f"{ns}DATA-TYPE-REF", ns)
            )
            if data_type_ref and "/" in data_type_ref:
                data_type_ref = data_type_ref.rsplit("/", 1)[-1]
            events.append(
                ApEvent(short_name=sn, event_type=event_type, data_type_ref=data_type_ref)
            )
        return events

    def _parse_fields(self, iface_el, ns: str) -> list[ApField]:
        """Parse FIELDS sub-container of a service interface."""
        fields_list: list[ApField] = []
        field_els = self._xpath_els(
            iface_el,
            f".//{ns}FIELDS/{ns}FIELD"
            f" | .//{ns}FIELDS/{ns}VARIABLE-DATA-PROTOTYPE"
            f" | .//Fields/Field",
            ns,
        )
        for fld_el in field_els:
            sn = self._xpath_text(fld_el, f"{ns}SHORT-NAME", ns)
            if not sn:
                continue
            data_type_ref = (
                self._xpath_text(fld_el, f"{ns}TYPE-TREF", ns)
                or self._xpath_text(fld_el, f"{ns}DATA-TYPE-REF", ns)
            )
            if data_type_ref and "/" in data_type_ref:
                data_type_ref = data_type_ref.rsplit("/", 1)[-1]
            getter = self._xpath_bool(fld_el, f"{ns}HAS-GETTER", ns, default=True)
            setter = self._xpath_bool(fld_el, f"{ns}HAS-SETTER", ns, default=False)
            notifier = self._xpath_bool(fld_el, f"{ns}HAS-NOTIFIER", ns, default=False)
            fields_list.append(
                ApField(
                    short_name=sn,
                    data_type_ref=data_type_ref,
                    getter=getter,
                    setter=setter,
                    notifier=notifier,
                )
            )
        return fields_list

    # ---- service interface parsing -----------------------------------------

    def _parse_service_interfaces(self, root, ns: str, config: ApConfig) -> None:
        """Parse SERVICE-INTERFACE containers."""
        si_patterns = (
            f".//{ns}SERVICE-INTERFACE"
            f" | .//{ns}ServiceInterface"
            f" | .//{ns}ADAPTIVE-APPLICATION-SW-COMPONENT-TYPE"
            f" | .//{ns}AdaptiveApplicationSwComponentType"
        )
        si_els = self._xpath_els(root, si_patterns, ns)

        for si_el in si_els:
            sn = self._xpath_text(si_el, f"{ns}SHORT-NAME", ns)
            if not sn:
                continue

            category = self._xpath_text(si_el, f"{ns}CATEGORY", ns)
            version = (
                self._xpath_text(si_el, f"{ns}SERVICE-INTERFACE-VERSION", ns)
                or self._xpath_text(si_el, f"{ns}MAJOR-VERSION", ns)
            )
            namespace = self._xpath_text(
                si_el, f"{ns}NAMESPACE-BLOBS/{ns}NAMESPACE-BLOB/{ns}VALUE", ns
            )

            methods = self._parse_methods(si_el, ns)
            events = self._parse_events(si_el, ns)
            fields = self._parse_fields(si_el, ns)

            config.service_interfaces.append(
                ApServiceInterface(
                    short_name=sn,
                    namespace=namespace,
                    version=version,
                    category=category,
                    methods=methods,
                    events=events,
                    fields=fields,
                )
            )

    # ---- AP diagnostic service parsing ------------------------------------

    def _parse_diag_services(self, root, ns: str, config: ApConfig) -> None:
        """Parse DIAGNOSTIC-SERVICE-INSTANCE containers for AP diagnostics."""
        diag_patterns = (
            f".//{ns}DIAGNOSTIC-SERVICE-INSTANCE"
            f" | .//{ns}DiagnosticServiceInstance"
            f" | .//{ns}ADAPTIVE-DIAGNOSTIC-INTERFACE"
            f" | .//{ns}AdaptiveDiagnosticInterface"
        )
        diag_els = self._xpath_els(root, diag_patterns, ns)

        for diag_el in diag_els:
            sn = self._xpath_text(diag_el, f"{ns}SHORT-NAME", ns)
            if not sn:
                continue

            uds_service_ref = (
                self._xpath_text(diag_el, f"{ns}UDS-SERVICE-REF", ns)
                or self._xpath_text(diag_el, f"{ns}DIAGNOSTIC-SERVICE-REF", ns)
            )
            if uds_service_ref and "/" in uds_service_ref:
                uds_service_ref = uds_service_ref.rsplit("/", 1)[-1]

            # Diagnostic event references
            event_ref_els = self._xpath_els(
                diag_el,
                f".//{ns}DIAG-EVENT-REFS/{ns}DIAG-EVENT-REF"
                f" | .//DiagEventRefs/DiagEventRef",
                ns,
            )
            diag_event_refs = [
                (el.text or "").strip().rsplit("/", 1)[-1]
                for el in event_ref_els
                if (el.text or "").strip()
            ]

            config.diag_services.append(
                ApDiagnosticService(
                    short_name=sn,
                    uds_service_ref=uds_service_ref,
                    diag_event_refs=diag_event_refs,
                )
            )

    # ---- public API --------------------------------------------------------

    def parse(self, root, ns: str = "") -> ApConfig:
        """Parse AUTOSAR Adaptive Platform configuration from lxml root element.

        Args:
            root: lxml etree element (root of ARXML document).
            ns:   Namespace prefix with colon, e.g. ``""`` or ``"ar:"``.

        Returns:
            Populated :class:`ApConfig`.
        """
        config = ApConfig()
        config.ap_version = self._detect_version(root, ns)
        self._parse_service_interfaces(root, ns, config)
        self._parse_diag_services(root, ns, config)
        return config


__all__ = [
    "ApConfig",
    "ApDiagnosticService",
    "ApEvent",
    "ApField",
    "ApMethod",
    "ApParser",
    "ApServiceInterface",
]
