"""Bootloader-domain overlay for :class:`UdsSpecification`.

A single UDS specification often needs to describe both the application /
drive domain and the bootloader / programming domain. Application-side ARXML
cannot supply bootloader information by itself, so an external YAML overlay
adds:

* Which sessions / SIDs / DIDs / RIDs apply to the bootloader domain.
* Bootloader-only DIDs and routines that don't exist in the application ARXML.
* Bootloader-specific configuration: flash layout, programming sequence,
  reset address, download block size, checksum algorithm.
* Optional drive- and boot-domain CAN ID overrides.

The overlay is then applied to a :class:`UdsSpecification` via
:func:`apply_to_spec`, which writes the ``domain`` attribute on each
session / service / DID / routine to one of ``"drive"`` (the default),
``"boot"``, or ``"both"``.

YAML schema (version 1)
-----------------------

.. code-block:: yaml

    # boot_overlay.yaml — bootloader-domain overlay
    ecu_name: ExampleECU
    default_domain: drive  # "drive" | "boot" | "both" — unmatched items get this

    domains:
      sessions:
        boot_only:  [PROGRAMMING_SESSION]
        both:       [DEFAULT_SESSION, EXTENDED_DIAGNOSTIC_SESSION]
        drive_only: []
      sids:
        boot_only:  [0x34, 0x36, 0x37]
        both:       [0x10, 0x11, 0x27, 0x3E, 0x85]
        drive_only: [0x14, 0x19, 0x22, 0x28, 0x2E]
      dids:
        boot_only:  [0xF180, 0xF184]
        both:       [0xF100, 0xF101, 0xF186]
        drive_only: []
      rids:
        boot_only:  [0xFF00, 0xFF01]
        both:       []
        drive_only: []

    bootloader:
      reset_address: 0x00080000
      download_block_size: 4090
      checksum_algorithm: CRC32
      flash_segments:
        - {name: AppCode, start: 0x00100000, end: 0x001FFFFF, description: "Main app code"}
      programming_sequence:
        - "Tester sends DiagnosticSessionControl(0x02 programmingSession)"

    can_ids:
      drive:
        physical:   "0x18DA00E0"
        functional: "0x18DBEFE0"
      boot:
        physical:   "0x18DA00F0"

    boot_only_dids:
      - {did_id: 0xF180, short_name: BootSwIdentification, description: "..."}
    boot_only_rids:
      - {rid_id: 0xFF00, short_name: FlashErase, description: "..."}

Both integer and ``0x``-prefixed hex string IDs are accepted everywhere.
Within each category, the three lists ``boot_only``, ``both`` and
``drive_only`` are mutually exclusive — an ID appearing in more than one
list raises :class:`ValueError` at load time.

PyYAML is required (declare the ``yaml`` extra).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from udsxml2tex.models import UdsSpecification

__all__ = [
    "FlashSegment",
    "DomainCanIds",
    "BootloaderInfo",
    "DomainMap",
    "BootOverlay",
    "load_overlay",
    "empty_overlay",
    "apply_to_spec",
]

# Valid domain markers used throughout this module.
_VALID_DOMAINS: frozenset[str] = frozenset({"drive", "boot", "both"})


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------


@dataclass
class FlashSegment:
    """One contiguous flash range described by the overlay."""

    name: str
    start: int
    end: int
    description: str = ""


@dataclass
class DomainCanIds:
    """Per-domain CAN identifier overrides.

    Any field left empty (the default) means "fall back to the value parsed
    from the ARXML / supplement". Documentation generators decide how to
    render unset fields.
    """

    physical: str = ""
    functional: str = ""
    telematics: str = ""


@dataclass
class BootloaderInfo:
    """Bootloader-specific data not derivable from application ARXML."""

    flash_segments: list[FlashSegment] = field(default_factory=list)
    programming_sequence: list[str] = field(default_factory=list)
    reset_address: int | None = None
    download_block_size: int | None = None  # bytes
    checksum_algorithm: str = ""  # e.g. "CRC32", "SHA-256"


@dataclass
class DomainMap:
    """Per-category lookup tables built from the overlay YAML.

    Each dict maps the item's identifier (session ``short_name`` for sessions,
    integer service / DID / routine id otherwise) to its resolved domain
    marker — one of ``"drive"``, ``"boot"`` or ``"both"``.
    """

    sessions: dict[str, str] = field(default_factory=dict)
    sids: dict[int, str] = field(default_factory=dict)
    dids: dict[int, str] = field(default_factory=dict)
    rids: dict[int, str] = field(default_factory=dict)


@dataclass
class BootOverlay:
    """In-memory representation of ``boot_overlay.yaml``."""

    ecu_name: str = ""
    default_domain: str = "drive"
    domain_map: DomainMap = field(default_factory=DomainMap)
    bootloader: BootloaderInfo | None = None
    can_ids_drive: DomainCanIds | None = None
    can_ids_boot: DomainCanIds | None = None
    # Bootloader-only DIDs / RIDs that are absent from the application ARXML.
    # Each entry is left as a plain dict so the documentation generator can
    # synthesise display rows without depending on the full
    # :class:`udsxml2tex.models.Did` constructor surface.
    boot_only_dids: list[dict] = field(default_factory=list)
    boot_only_rids: list[dict] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _coerce_int(value: Any) -> int:
    """Coerce ``value`` to an int.

    Accepts integers as-is and decodes ``0x``-prefixed strings (any base via
    :func:`int` with base 0). Raises :class:`ValueError` on anything else.
    """
    if isinstance(value, bool):
        # ``bool`` is a subclass of ``int``; reject it explicitly so True/False
        # tokens in YAML don't silently become 1/0 IDs.
        raise ValueError(f"expected integer or hex string, got bool {value!r}")
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        s = value.strip()
        if not s:
            raise ValueError("expected integer or hex string, got empty string")
        return int(s, 0)
    raise ValueError(f"expected integer or hex string, got {type(value).__name__}")


def _coerce_int_list(values: Any) -> list[int]:
    """Coerce a sequence of YAML scalars to a list of ints. ``None`` -> []."""
    if values is None:
        return []
    if not isinstance(values, (list, tuple)):
        raise ValueError(
            f"expected a list of integers, got {type(values).__name__}"
        )
    return [_coerce_int(v) for v in values]


def _coerce_str_list(values: Any) -> list[str]:
    """Coerce a YAML sequence to a list of strings. ``None`` -> []."""
    if values is None:
        return []
    if isinstance(values, str):
        return [values]
    if not isinstance(values, (list, tuple)):
        raise ValueError(
            f"expected a list of strings, got {type(values).__name__}"
        )
    return [str(v) for v in values]


def _validate_domain(value: str, *, where: str) -> str:
    """Validate a domain marker and return it unchanged. Raises ValueError."""
    if value not in _VALID_DOMAINS:
        raise ValueError(
            f"invalid domain {value!r} for {where}; "
            f"expected one of {sorted(_VALID_DOMAINS)}"
        )
    return value


def _build_category_map(
    category: str,
    data: Any,
    *,
    coerce: Any,
) -> dict:
    """Build a {id: domain} mapping for one category (sessions / sids / dids / rids).

    ``coerce`` is a callable applied to every list element before insertion;
    this lets sessions use ``str`` while sids/dids/rids use :func:`_coerce_int`.
    Raises :class:`ValueError` if any identifier appears in more than one of
    the three lists.
    """
    if data is None:
        return {}
    if not isinstance(data, dict):
        raise ValueError(
            f"'domains.{category}' must be a mapping, got {type(data).__name__}"
        )

    buckets: dict[str, list] = {
        "boot_only": [coerce(v) for v in _maybe_list(data.get("boot_only"))],
        "both": [coerce(v) for v in _maybe_list(data.get("both"))],
        "drive_only": [coerce(v) for v in _maybe_list(data.get("drive_only"))],
    }

    result: dict = {}
    sources: dict = {}  # id -> first bucket name where it was seen
    bucket_to_domain = {
        "boot_only": "boot",
        "both": "both",
        "drive_only": "drive",
    }
    for bucket_name, items in buckets.items():
        for ident in items:
            if ident in sources and sources[ident] != bucket_name:
                raise ValueError(
                    f"overlay conflict: {category} id {ident!r} appears in both "
                    f"'{sources[ident]}' and '{bucket_name}'; each id may appear "
                    f"in only one of boot_only / both / drive_only"
                )
            sources[ident] = bucket_name
            result[ident] = bucket_to_domain[bucket_name]
    return result


def _maybe_list(value: Any) -> list:
    """Return ``value`` unchanged if it is already a list, else [] for None."""
    if value is None:
        return []
    if isinstance(value, list):
        return value
    raise ValueError(f"expected a list, got {type(value).__name__}")


def _parse_can_ids(data: Any, *, where: str) -> DomainCanIds | None:
    """Parse one of the ``can_ids.drive`` / ``can_ids.boot`` sub-sections."""
    if data is None:
        return None
    if not isinstance(data, dict):
        raise ValueError(
            f"'{where}' must be a mapping, got {type(data).__name__}"
        )
    return DomainCanIds(
        physical=str(data.get("physical", "")) if data.get("physical") is not None else "",
        functional=(
            str(data.get("functional", "")) if data.get("functional") is not None else ""
        ),
        telematics=(
            str(data.get("telematics", "")) if data.get("telematics") is not None else ""
        ),
    )


def _parse_flash_segments(data: Any) -> list[FlashSegment]:
    if data is None:
        return []
    if not isinstance(data, list):
        raise ValueError(
            f"'bootloader.flash_segments' must be a list, got {type(data).__name__}"
        )
    out: list[FlashSegment] = []
    for i, seg in enumerate(data):
        if not isinstance(seg, dict):
            raise ValueError(
                f"'bootloader.flash_segments[{i}]' must be a mapping, "
                f"got {type(seg).__name__}"
            )
        out.append(
            FlashSegment(
                name=str(seg.get("name", "")),
                start=_coerce_int(seg.get("start", 0)),
                end=_coerce_int(seg.get("end", 0)),
                description=str(seg.get("description", "")),
            )
        )
    return out


def _parse_bootloader(data: Any) -> BootloaderInfo | None:
    if data is None:
        return None
    if not isinstance(data, dict):
        raise ValueError(
            f"'bootloader' must be a mapping, got {type(data).__name__}"
        )
    reset_address = data.get("reset_address")
    download_block_size = data.get("download_block_size")
    return BootloaderInfo(
        flash_segments=_parse_flash_segments(data.get("flash_segments")),
        programming_sequence=_coerce_str_list(data.get("programming_sequence")),
        reset_address=(
            _coerce_int(reset_address) if reset_address is not None else None
        ),
        download_block_size=(
            _coerce_int(download_block_size)
            if download_block_size is not None
            else None
        ),
        checksum_algorithm=str(data.get("checksum_algorithm", "")),
    )


def _parse_boot_only_did(entry: Any, *, idx: int) -> dict:
    if not isinstance(entry, dict):
        raise ValueError(
            f"'boot_only_dids[{idx}]' must be a mapping, got {type(entry).__name__}"
        )
    out = dict(entry)
    if "did_id" in out:
        out["did_id"] = _coerce_int(out["did_id"])
    return out


def _parse_boot_only_rid(entry: Any, *, idx: int) -> dict:
    if not isinstance(entry, dict):
        raise ValueError(
            f"'boot_only_rids[{idx}]' must be a mapping, got {type(entry).__name__}"
        )
    out = dict(entry)
    if "rid_id" in out:
        out["rid_id"] = _coerce_int(out["rid_id"])
    return out


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def empty_overlay() -> BootOverlay:
    """Return an :class:`BootOverlay` with all defaults (empty domain map)."""
    return BootOverlay()


def load_overlay(path: str | Path) -> BootOverlay:
    """Load a ``boot_overlay.yaml`` file from disk.

    :param path: path to the YAML file.
    :returns: populated :class:`BootOverlay`.
    :raises ImportError: if PyYAML is not installed (install via
        ``pip install udsxml2tex[yaml]``).
    :raises FileNotFoundError: when ``path`` does not exist.
    :raises ValueError: if the YAML is malformed (e.g. top-level is not a
        mapping) or contains a conflict (same id in multiple bucket lists).
    """
    try:
        import yaml  # lazy import; PyYAML is in the [yaml] / [web] extras
    except ImportError as exc:  # pragma: no cover - exercised only without PyYAML
        raise ImportError(
            "PyYAML is required to load a boot overlay. "
            "Install it via `pip install udsxml2tex[yaml]`."
        ) from exc

    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"boot overlay YAML not found: {p}")

    with p.open("r", encoding="utf-8") as fh:
        raw = yaml.safe_load(fh) or {}

    if not isinstance(raw, dict):
        raise ValueError(
            "boot overlay YAML must be a mapping at the top level, "
            f"got {type(raw).__name__}"
        )

    default_domain = str(raw.get("default_domain", "drive"))
    _validate_domain(default_domain, where="default_domain")

    domains_data = raw.get("domains") or {}
    if not isinstance(domains_data, dict):
        raise ValueError(
            f"'domains' must be a mapping, got {type(domains_data).__name__}"
        )

    domain_map = DomainMap(
        sessions=_build_category_map(
            "sessions", domains_data.get("sessions"), coerce=str
        ),
        sids=_build_category_map(
            "sids", domains_data.get("sids"), coerce=_coerce_int
        ),
        dids=_build_category_map(
            "dids", domains_data.get("dids"), coerce=_coerce_int
        ),
        rids=_build_category_map(
            "rids", domains_data.get("rids"), coerce=_coerce_int
        ),
    )

    can_ids_data = raw.get("can_ids") or {}
    if not isinstance(can_ids_data, dict):
        raise ValueError(
            f"'can_ids' must be a mapping, got {type(can_ids_data).__name__}"
        )
    can_ids_drive = _parse_can_ids(can_ids_data.get("drive"), where="can_ids.drive")
    can_ids_boot = _parse_can_ids(can_ids_data.get("boot"), where="can_ids.boot")

    boot_only_dids = [
        _parse_boot_only_did(d, idx=i)
        for i, d in enumerate(raw.get("boot_only_dids") or [])
    ]
    boot_only_rids = [
        _parse_boot_only_rid(r, idx=i)
        for i, r in enumerate(raw.get("boot_only_rids") or [])
    ]

    return BootOverlay(
        ecu_name=str(raw.get("ecu_name", "")),
        default_domain=default_domain,
        domain_map=domain_map,
        bootloader=_parse_bootloader(raw.get("bootloader")),
        can_ids_drive=can_ids_drive,
        can_ids_boot=can_ids_boot,
        boot_only_dids=boot_only_dids,
        boot_only_rids=boot_only_rids,
    )


def apply_to_spec(spec: UdsSpecification, overlay: BootOverlay) -> UdsSpecification:
    """Mark domain fields on ``spec`` according to ``overlay`` (in place).

    For each session, service, DID and routine, the function looks up its
    identifier in the matching domain map and writes that domain marker into
    the item's ``domain`` attribute. Items not present in the overlay are
    left at their existing value (which is ``"drive"`` for freshly parsed
    specs). ``overlay.default_domain`` is **not** broadcast — the caller can
    explicitly populate the lists to do that.

    The mutation is in-place and the same ``spec`` is returned for chaining.

    :param spec: the specification produced by :class:`ArxmlParser`.
    :param overlay: previously loaded overlay (see :func:`load_overlay`).
    :returns: ``spec`` (mutated in place).
    """
    sessions_map = overlay.domain_map.sessions
    for session in spec.sessions:
        if session.short_name in sessions_map:
            session.domain = sessions_map[session.short_name]

    sids_map = overlay.domain_map.sids
    for service in spec.services:
        if service.service_id in sids_map:
            service.domain = sids_map[service.service_id]

    dids_map = overlay.domain_map.dids
    for did in spec.dids:
        if did.did_id in dids_map:
            did.domain = dids_map[did.did_id]

    rids_map = overlay.domain_map.rids
    for routine in spec.routines:
        if routine.routine_id in rids_map:
            routine.domain = rids_map[routine.routine_id]

    return spec
