"""Plugin system ABCs for custom parsers and generators."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional

from udsxml2tex.models import UdsSpecification

__all__ = [
    "ParserPlugin",
    "GeneratorPlugin",
    "PluginRegistry",
    "registry",
]


class ParserPlugin(ABC):
    """Abstract base class for custom ARXML parser plugins."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Unique plugin name."""

    @abstractmethod
    def can_parse(self, path: Path) -> bool:
        """Return True if this plugin can parse the given file."""

    @abstractmethod
    def parse(self, path: Path, spec: UdsSpecification) -> None:
        """Parse *path* and merge data into *spec* (in-place)."""


class GeneratorPlugin(ABC):
    """Abstract base class for custom output generator plugins."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Unique plugin name."""

    @property
    @abstractmethod
    def format_name(self) -> str:
        """Format identifier used with ``--format`` (e.g. ``'a2l'``, ``'xlsx'``)."""

    @abstractmethod
    def generate(self, spec: UdsSpecification, output_path: Path) -> Path:
        """Generate output from *spec* and return the path to the generated file."""


class PluginRegistry:
    """Registry for parser and generator plugins."""

    def __init__(self) -> None:
        self._parser_plugins: list[ParserPlugin] = []
        self._generator_plugins: list[GeneratorPlugin] = []

    def register_parser(self, plugin: ParserPlugin) -> None:
        """Register a parser plugin.

        Args:
            plugin: A :class:`ParserPlugin` instance to register.
        """
        self._parser_plugins.append(plugin)

    def register_generator(self, plugin: GeneratorPlugin) -> None:
        """Register a generator plugin.

        Args:
            plugin: A :class:`GeneratorPlugin` instance to register.
        """
        self._generator_plugins.append(plugin)

    def get_parser_for(self, path: Path) -> Optional[ParserPlugin]:
        """Return the first registered parser that can handle *path*, or ``None``.

        Args:
            path: Path to the file that needs to be parsed.

        Returns:
            A :class:`ParserPlugin` instance if one is found, otherwise ``None``.
        """
        for plugin in self._parser_plugins:
            if plugin.can_parse(path):
                return plugin
        return None

    def get_generator_for(self, format_name: str) -> Optional[GeneratorPlugin]:
        """Return the registered generator for *format_name*, or ``None``.

        Args:
            format_name: The format identifier string (e.g. ``'a2l'``).

        Returns:
            A :class:`GeneratorPlugin` instance if one is found, otherwise ``None``.
        """
        for plugin in self._generator_plugins:
            if plugin.format_name == format_name:
                return plugin
        return None

    def list_formats(self) -> list[str]:
        """Return a list of all registered generator format names."""
        return [plugin.format_name for plugin in self._generator_plugins]


#: Module-level default plugin registry.
registry = PluginRegistry()
