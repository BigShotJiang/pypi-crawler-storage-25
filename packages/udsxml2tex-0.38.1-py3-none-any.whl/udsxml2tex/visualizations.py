"""Visualization generators: heatmaps, timing diagrams, network topology.

All generators emit standalone TikZ (.tex) files by default so they have
zero runtime dependencies beyond LaTeX. matplotlib-based PNG variants are
provided when matplotlib is importable; otherwise the matplotlib helpers
return None and only the TikZ files are produced.

Public API:
    generate_session_service_heatmap(spec, out_dir, format='tikz')
    generate_security_did_heatmap(spec, out_dir, format='tikz')
    generate_timing_diagram(spec, out_dir, format='tikz')
    generate_all_visualizations(spec, out_dir)
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Optional

try:  # pragma: no cover - probe optional dep
    import matplotlib  # type: ignore[import-not-found]
    matplotlib.use("Agg")  # headless / CI
    import matplotlib.pyplot as plt  # type: ignore[import-not-found]
    import numpy as np  # type: ignore[import-not-found]

    _MPL = True
except ImportError:  # pragma: no cover - tested via runtime path
    _MPL = False
    plt = None  # type: ignore[assignment]
    np = None  # type: ignore[assignment]


# ---------- TikZ helpers ----------

_TIKZ_PREAMBLE = r"""\documentclass[tikz, border=4pt]{standalone}
\usepackage{tikz}
\usepackage{xcolor}
\usetikzlibrary{matrix, positioning, shapes, arrows.meta, calc}
\definecolor{cellgreen}{HTML}{2A6E2A}
\definecolor{cellamber}{HTML}{C68A00}
\definecolor{cellred}{HTML}{AA2222}
\definecolor{cellgrey}{HTML}{DDDDDD}
\begin{document}
"""

_TIKZ_POSTAMBLE = r"""\end{document}
"""


def _latex_escape(s: str) -> str:
    """Escape LaTeX special characters in a short label."""
    return (
        s.replace("\\", r"\textbackslash{}")
         .replace("&", r"\&")
         .replace("%", r"\%")
         .replace("#", r"\#")
         .replace("_", r"\_")
         .replace("$", r"\$")
         .replace("{", r"\{")
         .replace("}", r"\}")
         .replace("^", r"\^{}")
         .replace("~", r"\~{}")
    )


def _heat_color(supported: bool) -> str:
    return "cellgreen" if supported else "cellgrey"


# ---------- Session × Service heatmap ----------

def _tikz_session_service_heatmap(spec: Any) -> str:
    """Build a TikZ heatmap of session × service support."""
    sessions = list(spec.sessions or [])
    services = list(spec.services or [])
    if not sessions or not services:
        return _TIKZ_PREAMBLE + r"\node{No sessions or services configured.};" + _TIKZ_POSTAMBLE

    cell_w, cell_h = 0.95, 0.55
    rows = len(services)
    cols = len(sessions)

    lines = [
        _TIKZ_PREAMBLE,
        r"\begin{tikzpicture}[font=\footnotesize, x=" + f"{cell_w}cm" + r", y=" + f"{cell_h}cm" + "]",
        r"\node[anchor=south west, font=\bfseries] at (0, " + f"{rows + 1.0:.2f}" + r") {Session $\times$ Service support matrix};",
    ]

    # Column headers (sessions)
    for j, s in enumerate(sessions):
        lines.append(
            f"\\node[rotate=45, anchor=west, font=\\scriptsize] at "
            f"({j + 1.5:.2f}, {rows + 0.2:.2f}) "
            f"{{{_latex_escape(s.short_name)}}};"
        )

    # Row labels (services)
    for i, svc in enumerate(services):
        y = rows - i
        lines.append(
            f"\\node[anchor=east, font=\\scriptsize] at "
            f"(0.9, {y - 0.5:.2f}) "
            f"{{0x{svc.service_id:02X} {_latex_escape(svc.short_name[:24])}}};"
        )

    # Cells
    for i, svc in enumerate(services):
        y = rows - i
        for j, sess in enumerate(sessions):
            supported = sess.short_name in (svc.supported_sessions or [])
            color = _heat_color(supported)
            lines.append(
                f"\\fill[{color}, draw=black!40] "
                f"({j + 1.0:.2f}, {y - 1.0:.2f}) rectangle "
                f"({j + 2.0:.2f}, {y:.2f});"
            )
            if supported:
                lines.append(
                    f"\\node[font=\\tiny, white] at "
                    f"({j + 1.5:.2f}, {y - 0.5:.2f}) {{$\\bullet$}};"
                )

    lines.append(r"\end{tikzpicture}")
    lines.append(_TIKZ_POSTAMBLE)
    return "\n".join(lines)


def _png_session_service_heatmap(spec: Any, out_path: Path) -> Optional[Path]:
    if not _MPL:
        return None
    sessions = list(spec.sessions or [])
    services = list(spec.services or [])
    if not sessions or not services:
        return None
    matrix = np.array([
        [1 if s.short_name in (svc.supported_sessions or []) else 0
         for s in sessions]
        for svc in services
    ])
    fig, ax = plt.subplots(figsize=(max(4, 1.2 * len(sessions)),
                                    max(3, 0.35 * len(services))))
    ax.imshow(matrix, cmap="Greens", aspect="auto", vmin=0, vmax=1)
    ax.set_xticks(range(len(sessions)))
    ax.set_xticklabels([s.short_name for s in sessions], rotation=45,
                       ha="right", fontsize=8)
    ax.set_yticks(range(len(services)))
    ax.set_yticklabels([f"0x{s.service_id:02X} {s.short_name}"
                        for s in services], fontsize=8)
    ax.set_title("Session × Service support matrix", fontsize=10,
                 fontweight="bold")
    for i in range(matrix.shape[0]):
        for j in range(matrix.shape[1]):
            if matrix[i, j]:
                ax.text(j, i, "✓", ha="center", va="center",
                        color="white", fontsize=9)
    fig.tight_layout()
    fig.savefig(out_path, dpi=140, bbox_inches="tight")
    plt.close(fig)
    return out_path


# ---------- Security × DID heatmap ----------

def _tikz_security_did_heatmap(spec: Any) -> str:
    sec_levels = list(spec.security_levels or [])
    dids = list(spec.dids or [])
    if not dids:
        return _TIKZ_PREAMBLE + r"\node{No DIDs configured.};" + _TIKZ_POSTAMBLE

    rows = len(dids)
    # Columns: read-default, read-each-security-level, write-default, write-each-security-level
    col_labels = ["Read", "Write"] + [
        f"Sec L{s.security_level}" for s in sec_levels
    ]
    cols = len(col_labels)

    cell_w, cell_h = 1.4, 0.55
    lines = [
        _TIKZ_PREAMBLE,
        r"\begin{tikzpicture}[font=\footnotesize, x=" + f"{cell_w}cm" + r", y=" + f"{cell_h}cm" + "]",
        r"\node[anchor=south west, font=\bfseries] at (0, " + f"{rows + 1.0:.2f}" + r") {Security level $\times$ DID access matrix};",
    ]
    for j, label in enumerate(col_labels):
        lines.append(
            f"\\node[rotate=45, anchor=west, font=\\scriptsize] at "
            f"({j + 1.5:.2f}, {rows + 0.2:.2f}) "
            f"{{{_latex_escape(label)}}};"
        )
    for i, did in enumerate(dids):
        y = rows - i
        lines.append(
            f"\\node[anchor=east, font=\\scriptsize] at "
            f"(0.9, {y - 0.5:.2f}) "
            f"{{0x{did.did_id:04X} {_latex_escape(did.short_name[:24])}}};"
        )
        # Read / Write columns
        for j, key in enumerate(("read_access", "write_access")):
            val = bool(getattr(did, key, False))
            color = _heat_color(val)
            lines.append(
                f"\\fill[{color}, draw=black!40] "
                f"({j + 1.0:.2f}, {y - 1.0:.2f}) rectangle "
                f"({j + 2.0:.2f}, {y:.2f});"
            )
        # Security level columns — DID requires that security level if listed
        req = list(did.required_security_levels or [])
        for k, sec in enumerate(sec_levels):
            j = 2 + k
            req_match = sec.short_name in req
            color = "cellamber" if req_match else "cellgrey"
            lines.append(
                f"\\fill[{color}, draw=black!40] "
                f"({j + 1.0:.2f}, {y - 1.0:.2f}) rectangle "
                f"({j + 2.0:.2f}, {y:.2f});"
            )

    lines.append(r"\end{tikzpicture}")
    lines.append(_TIKZ_POSTAMBLE)
    return "\n".join(lines)


def _png_security_did_heatmap(spec: Any, out_path: Path) -> Optional[Path]:
    if not _MPL:
        return None
    sec_levels = list(spec.security_levels or [])
    dids = list(spec.dids or [])
    if not dids:
        return None
    col_labels = ["Read", "Write"] + [
        f"Sec L{s.security_level}" for s in sec_levels
    ]
    matrix = np.zeros((len(dids), len(col_labels)))
    for i, did in enumerate(dids):
        matrix[i, 0] = 1 if did.read_access else 0
        matrix[i, 1] = 1 if did.write_access else 0
        req = list(did.required_security_levels or [])
        for k, sec in enumerate(sec_levels):
            if sec.short_name in req:
                matrix[i, 2 + k] = 0.6  # amber
    fig, ax = plt.subplots(figsize=(max(4, 1.0 * len(col_labels)),
                                    max(3, 0.35 * len(dids))))
    ax.imshow(matrix, cmap="YlOrBr", aspect="auto", vmin=0, vmax=1)
    ax.set_xticks(range(len(col_labels)))
    ax.set_xticklabels(col_labels, rotation=45, ha="right", fontsize=8)
    ax.set_yticks(range(len(dids)))
    ax.set_yticklabels([f"0x{d.did_id:04X} {d.short_name}" for d in dids],
                       fontsize=8)
    ax.set_title("Security level × DID access matrix", fontsize=10,
                 fontweight="bold")
    fig.tight_layout()
    fig.savefig(out_path, dpi=140, bbox_inches="tight")
    plt.close(fig)
    return out_path


# ---------- Timing diagram ----------

def _tikz_timing_diagram(spec: Any) -> str:
    """Visual timing chart of P2 / P2* / S3 / N_Bs / N_Cr on a shared axis (ms)."""
    sessions = list(spec.sessions or [])
    s3 = getattr(spec, "s3_server", None)

    # Collect timer values in ms, with synthesized labels
    bars: list[tuple[str, float]] = []
    if sessions:
        first = sessions[0]
        if getattr(first, "p2_server_max", None) is not None:
            bars.append(("P2 (server max)", float(first.p2_server_max) * 1000.0))
        if getattr(first, "p2_star_server_max", None) is not None:
            bars.append(("P2* (server max)", float(first.p2_star_server_max) * 1000.0))
    if s3 is not None:
        try:
            bars.append(("S3 (session keep-alive)", float(s3) * 1000.0))
        except (TypeError, ValueError):
            pass

    # CanTp timing
    tp = getattr(spec, "transport_config", None)
    if tp and getattr(tp, "channels", None):
        ch = tp.channels[0]
        for fld, label in (
            ("n_bs", "N_Bs (FF→FC wait)"),
            ("n_cr", "N_Cr (CF interval)"),
            ("n_as", "N_As (sender PDU)"),
            ("n_ar", "N_Ar (receiver PDU)"),
        ):
            v = getattr(ch, fld, None)
            if v is not None:
                try:
                    bars.append((label, float(v) * 1000.0))
                except (TypeError, ValueError):
                    pass

    if not bars:
        return _TIKZ_PREAMBLE + r"\node{No timing parameters configured.};" + _TIKZ_POSTAMBLE

    max_ms = max(v for _, v in bars) or 1.0
    scale = 12.0 / max_ms  # cm per ms

    lines = [
        _TIKZ_PREAMBLE,
        r"\begin{tikzpicture}[font=\footnotesize]",
        r"\node[anchor=south west, font=\bfseries] at (0, " + f"{len(bars) + 0.6:.2f}" + r") {Timing parameters (ms)};",
    ]
    for i, (label, ms) in enumerate(reversed(bars)):
        y = i + 0.5
        lines.append(
            f"\\node[anchor=east, font=\\scriptsize] at (0, {y:.2f}) "
            f"{{{_latex_escape(label)}}};"
        )
        lines.append(
            f"\\fill[blue!40, draw=blue!70] (0, {y - 0.2:.2f}) rectangle "
            f"({ms * scale:.3f}, {y + 0.2:.2f});"
        )
        lines.append(
            f"\\node[anchor=west, font=\\scriptsize] at "
            f"({ms * scale:.3f}, {y:.2f}) {{ {ms:g}\\,ms}};"
        )
    # Axis line
    lines.append(f"\\draw[->] (0, 0) -- ({max_ms * scale + 1.0:.3f}, 0) "
                 f"node[anchor=west] {{time (ms)}};")
    # Tick marks
    n_ticks = 5
    for k in range(n_ticks + 1):
        v = max_ms * k / n_ticks
        x = v * scale
        lines.append(f"\\draw ({x:.3f}, -0.05) -- ({x:.3f}, 0.05) "
                     f"node[anchor=north, font=\\tiny] at ({x:.3f}, -0.05) {{ {v:g} }};")

    lines.append(r"\end{tikzpicture}")
    lines.append(_TIKZ_POSTAMBLE)
    return "\n".join(lines)


def _png_timing_diagram(spec: Any, out_path: Path) -> Optional[Path]:
    if not _MPL:
        return None
    bars: list[tuple[str, float]] = []
    if spec.sessions:
        s = spec.sessions[0]
        if s.p2_server_max is not None:
            bars.append(("P2 (server max)", float(s.p2_server_max) * 1000))
        if s.p2_star_server_max is not None:
            bars.append(("P2* (server max)", float(s.p2_star_server_max) * 1000))
    if spec.s3_server is not None:
        try:
            bars.append(("S3 (session keep-alive)", float(spec.s3_server) * 1000))
        except (TypeError, ValueError):
            pass
    tp = getattr(spec, "transport_config", None)
    if tp and tp.channels:
        ch = tp.channels[0]
        for fld, label in (("n_bs", "N_Bs"), ("n_cr", "N_Cr"),
                            ("n_as", "N_As"), ("n_ar", "N_Ar")):
            v = getattr(ch, fld, None)
            if v is not None:
                try:
                    bars.append((label, float(v) * 1000))
                except (TypeError, ValueError):
                    pass
    if not bars:
        return None
    fig, ax = plt.subplots(figsize=(8, max(2.5, 0.5 * len(bars))))
    labels = [b[0] for b in bars]
    values = [b[1] for b in bars]
    ax.barh(labels, values, color="#4a6fa5")
    for i, v in enumerate(values):
        ax.text(v, i, f"  {v:g} ms", va="center", fontsize=8)
    ax.set_xlabel("time (ms)")
    ax.set_title("UDS timing parameters", fontsize=10, fontweight="bold")
    ax.invert_yaxis()
    fig.tight_layout()
    fig.savefig(out_path, dpi=140, bbox_inches="tight")
    plt.close(fig)
    return out_path


# ---------- Public API ----------

def generate_session_service_heatmap(
    spec: Any, out_dir: "str | Path", format: str = "tikz"
) -> Path:
    """Write a session × service support heatmap.

    Args:
        spec: Parsed UdsSpecification.
        out_dir: Output directory (created if needed).
        format: 'tikz' (default), 'png', or 'both'.

    Returns:
        Path to the primary generated file (TikZ if format='both').
    """
    out_dir_p = Path(out_dir)
    out_dir_p.mkdir(parents=True, exist_ok=True)
    tikz_path = out_dir_p / "heatmap_session_service.tex"
    png_path = out_dir_p / "heatmap_session_service.png"
    if format in ("tikz", "both"):
        tikz_path.write_text(_tikz_session_service_heatmap(spec), encoding="utf-8")
    if format in ("png", "both"):
        _png_session_service_heatmap(spec, png_path)
    return tikz_path if format != "png" else png_path


def generate_security_did_heatmap(
    spec: Any, out_dir: "str | Path", format: str = "tikz"
) -> Path:
    out_dir_p = Path(out_dir)
    out_dir_p.mkdir(parents=True, exist_ok=True)
    tikz_path = out_dir_p / "heatmap_security_did.tex"
    png_path = out_dir_p / "heatmap_security_did.png"
    if format in ("tikz", "both"):
        tikz_path.write_text(_tikz_security_did_heatmap(spec), encoding="utf-8")
    if format in ("png", "both"):
        _png_security_did_heatmap(spec, png_path)
    return tikz_path if format != "png" else png_path


def generate_timing_diagram(
    spec: Any, out_dir: "str | Path", format: str = "tikz"
) -> Path:
    out_dir_p = Path(out_dir)
    out_dir_p.mkdir(parents=True, exist_ok=True)
    tikz_path = out_dir_p / "timing_diagram.tex"
    png_path = out_dir_p / "timing_diagram.png"
    if format in ("tikz", "both"):
        tikz_path.write_text(_tikz_timing_diagram(spec), encoding="utf-8")
    if format in ("png", "both"):
        _png_timing_diagram(spec, png_path)
    return tikz_path if format != "png" else png_path


def generate_all_visualizations(
    spec: Any, out_dir: "str | Path", format: str = "both"
) -> list[Path]:
    """Generate all available visualizations into out_dir.

    Returns the list of files actually produced.
    """
    out_dir_p = Path(out_dir)
    out_dir_p.mkdir(parents=True, exist_ok=True)
    paths: list[Path] = []
    fmt = format if (_MPL or format != "both") else "tikz"
    for fn in (generate_session_service_heatmap,
               generate_security_did_heatmap,
               generate_timing_diagram):
        try:
            paths.append(fn(spec, out_dir_p, format=fmt))
        except Exception:  # noqa: BLE001
            continue
    return paths
