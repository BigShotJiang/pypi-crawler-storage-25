"""Loader for multi-ECU system configuration.

Reads a YAML or JSON file describing the ECUs, their ARXML inputs, and the
routing relationships between them; parses each ECU's ARXML files into a
`UdsSpecification`; and optionally runs ARXML-based routing inference.

Config file schema (YAML):

    name: MyVehicle
    description: 1+1 redundant MCU pair
    ecus:
      primary:
        role: gateway
        arxml_files:
          - primary/dcm.arxml
          - primary/cantp.arxml
        dem_arxml: primary/dem.arxml
        description: Tester-facing MCU
      secondary:
        role: endpoint
        arxml_files:
          - secondary/dcm.arxml
        description: Forwarded-only MCU

    routing:
      - from: primary
        to: secondary
        match:
          sids: [0x22, 0x2E]
          did_range: [0x2000, 0x2FFF]
        via: internal_can
        description: ADAS calibration DIDs

    topology:
      connections:
        - from: primary
          to: secondary
          medium: CAN
          description: 500 kbit/s internal CAN

Public API:
    load_system_config(path, *, parse_arxml=True, infer_routing=True) -> EcuSystem
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

from udsxml2tex.dem_parser import DemParser
from udsxml2tex.models import UdsSpecification
from udsxml2tex.multi_ecu.models import EcuConfig, EcuSystem
from udsxml2tex.parser import ArxmlParser

logger = logging.getLogger(__name__)


def load_system_config(
    path: "str | Path",
    *,
    parse_arxml: bool = True,
    infer_routing: bool = True,
) -> EcuSystem:
    """Load a system config and return a fully-populated `EcuSystem`.

    Args:
        path: Path to a YAML (.yaml/.yml) or JSON (.json) system config file.
        parse_arxml: When True, parse each ECU's ARXML files into a
                     `UdsSpecification` and store on `EcuConfig.spec`.
        infer_routing: When True (and parse_arxml is True), run ARXML-based
                       routing inference and append inferred rules to
                       `system.routing_rules`. Explicit rules from the config
                       are kept verbatim — inference only adds new rules.

    Returns:
        EcuSystem with `EcuConfig.spec` populated for each ECU.

    Raises:
        ImportError: If the file is YAML and PyYAML is not installed.
        FileNotFoundError: If the config file or any referenced ARXML is missing.
        ValueError: For unsupported file extensions or malformed configs.
    """
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"System config not found: {p}")

    suffix = p.suffix.lower()
    if suffix in {".yaml", ".yml"}:
        try:
            import yaml  # type: ignore[import-not-found]
        except ImportError as e:
            raise ImportError(
                "PyYAML is required to load .yaml multi-ECU system configs. "
                "Install with: pip install udsxml2tex[yaml]"
            ) from e
        data = yaml.safe_load(p.read_text(encoding="utf-8"))
    elif suffix == ".json":
        data = json.loads(p.read_text(encoding="utf-8"))
    else:
        raise ValueError(
            f"Unsupported config format: {suffix!r}. Use .yaml/.yml/.json"
        )

    if not isinstance(data, dict):
        raise ValueError(
            f"System config root must be a mapping, got {type(data).__name__}"
        )

    system = EcuSystem.from_dict(data, base_dir=p.parent)

    if parse_arxml:
        for ecu in system.ecus.values():
            try:
                ecu.spec = _parse_ecu(ecu)
                _scan_c_sources(ecu)
            except Exception as e:  # noqa: BLE001
                logger.error("Failed to parse ECU %r: %s", ecu.name, e)
                raise

    if infer_routing and parse_arxml:
        from udsxml2tex.multi_ecu.inference import infer_routing_rules
        inferred = infer_routing_rules(system)
        # Inferred rules are appended; explicit rules in the config take
        # precedence (we never remove or modify explicit rules).
        if inferred:
            logger.info(
                "Inferred %d routing rule(s) from ARXML coverage gaps",
                len(inferred),
            )
            system.routing_rules.extend(inferred)

    return system


def _parse_ecu(ecu: EcuConfig) -> UdsSpecification:
    """Parse one ECU's ARXML files (and optional DEM) into a UdsSpecification."""
    if not ecu.arxml_files:
        raise ValueError(
            f"ECU {ecu.name!r}: no arxml_files configured — cannot parse"
        )
    for arxml in ecu.arxml_files:
        if not arxml.exists():
            raise FileNotFoundError(
                f"ECU {ecu.name!r}: ARXML not found: {arxml}"
            )
    parser = ArxmlParser()
    if len(ecu.arxml_files) == 1:
        spec = parser.parse(ecu.arxml_files[0])
    else:
        spec = parser.parse_multi(ecu.arxml_files)

    if ecu.dem_arxml:
        if not ecu.dem_arxml.exists():
            raise FileNotFoundError(
                f"ECU {ecu.name!r}: DEM ARXML not found: {ecu.dem_arxml}"
            )
        DemParser().parse(ecu.dem_arxml, spec)

    # Ensure the spec's ECU name matches the system's logical name; this drives
    # cross-references in the system integration document.
    if not spec.ecu_name or spec.ecu_name == "UnnamedECU":
        spec.ecu_name = ecu.name
    return spec


def _scan_c_sources(ecu: EcuConfig) -> None:
    """Run the DID/RID C scanners against `ecu.spec` if C files are configured.

    Mirrors the single-ECU flow in cli.py: enriches DataElement.global_variables
    and Routine.global_variables in-place. Missing files surface as
    FileNotFoundError so the loader's per-ECU error handling reports them
    against the right ECU.
    """
    if ecu.spec is None:
        return
    if ecu.did_c_files:
        for p in ecu.did_c_files:
            if not p.exists():
                raise FileNotFoundError(
                    f"ECU {ecu.name!r}: DID C source not found: {p}"
                )
        from udsxml2tex.c_scanner import scan_did_variables
        scan_did_variables(list(ecu.did_c_files), ecu.spec.dids)
        logger.info("ECU %r: scanned %d DID C source(s)",
                    ecu.name, len(ecu.did_c_files))
    if ecu.rid_c_files:
        for p in ecu.rid_c_files:
            if not p.exists():
                raise FileNotFoundError(
                    f"ECU {ecu.name!r}: RID C source not found: {p}"
                )
        from udsxml2tex.c_scanner import scan_rid_variables
        scan_rid_variables(list(ecu.rid_c_files), ecu.spec.routines)
        logger.info("ECU %r: scanned %d RID C source(s)",
                    ecu.name, len(ecu.rid_c_files))
