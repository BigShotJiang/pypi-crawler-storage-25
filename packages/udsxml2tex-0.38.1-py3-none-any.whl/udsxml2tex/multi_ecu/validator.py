"""Cross-ECU consistency validation for multi-ECU systems.

Reuses the `ValidationIssue` / `ValidationResult` types from `udsxml2tex.validator`
so output formatting (rich tables, etc.) works uniformly for both single-ECU
and multi-ECU validation.

Checks performed:
  1. Routing-rule references (from_ecu / to_ecu) point to known ECUs
  2. No self-loops (rule with from_ecu == to_ecu)
  3. No cycles in the routing graph
  4. Forwarded DIDs exist on the target ECU
  5. Forwarded RIDs exist on the target ECU
  6. Forwarded SIDs are supported on the target ECU
  7. Security level required by the target is supported by the gateway
     (so the gateway can pass authenticated requests through)
  8. Sessions on the target are reachable from the gateway's session set

Public API:
    validate_system(system) -> ValidationResult
"""

from __future__ import annotations

from typing import Any

from udsxml2tex.multi_ecu.models import EcuSystem, RoutingRule
from udsxml2tex.validator import ValidationIssue, ValidationResult


def validate_system(system: EcuSystem) -> ValidationResult:
    """Run all cross-ECU checks and return a `ValidationResult`."""
    issues: list[ValidationIssue] = []
    issues.extend(_check_routing_endpoints(system))
    issues.extend(_check_routing_cycles(system))
    issues.extend(_check_forwarded_items_exist(system))
    issues.extend(_check_security_compatibility(system))
    issues.extend(_check_session_compatibility(system))
    return ValidationResult(issues=issues)


def _check_routing_endpoints(system: EcuSystem) -> list[ValidationIssue]:
    """Verify each routing rule references known ECUs and is not a self-loop."""
    issues: list[ValidationIssue] = []
    known = set(system.ecus.keys())
    for rule in system.routing_rules:
        rid = f"{rule.from_ecu} -> {rule.to_ecu}"
        if rule.from_ecu not in known:
            issues.append(ValidationIssue(
                severity="error", category="routing", item_id=rid,
                message=f"Routing rule references unknown source ECU: {rule.from_ecu!r}",
            ))
        if rule.to_ecu not in known:
            issues.append(ValidationIssue(
                severity="error", category="routing", item_id=rid,
                message=f"Routing rule references unknown target ECU: {rule.to_ecu!r}",
            ))
        if rule.from_ecu == rule.to_ecu:
            issues.append(ValidationIssue(
                severity="error", category="routing", item_id=rid,
                message=f"Routing rule is a self-loop on ECU {rule.from_ecu!r}",
            ))
    return issues


def _check_routing_cycles(system: EcuSystem) -> list[ValidationIssue]:
    """Detect cycles in the routing graph via depth-first search."""
    graph: dict[str, set[str]] = {n: set() for n in system.ecus}
    for rule in system.routing_rules:
        if rule.from_ecu in graph and rule.to_ecu in graph and rule.from_ecu != rule.to_ecu:
            graph[rule.from_ecu].add(rule.to_ecu)

    issues: list[ValidationIssue] = []
    WHITE, GRAY, BLACK = 0, 1, 2
    color: dict[str, int] = {n: WHITE for n in graph}

    def dfs(node: str, path: list[str]) -> None:
        color[node] = GRAY
        for nxt in graph[node]:
            if color[nxt] == GRAY:
                cycle = path[path.index(nxt):] + [nxt] if nxt in path else [node, nxt]
                issues.append(ValidationIssue(
                    severity="error", category="routing",
                    item_id=" -> ".join(cycle),
                    message=f"Routing cycle detected: {' -> '.join(cycle)}",
                ))
            elif color[nxt] == WHITE:
                dfs(nxt, path + [nxt])
        color[node] = BLACK

    for node in graph:
        if color[node] == WHITE:
            dfs(node, [node])
    return issues


def _check_forwarded_items_exist(system: EcuSystem) -> list[ValidationIssue]:
    """For each routing rule, check that forwarded DIDs/RIDs/SIDs exist on the target."""
    issues: list[ValidationIssue] = []
    for rule in system.routing_rules:
        target = system.ecus.get(rule.to_ecu)
        if not target or not target.spec:
            continue

        # DIDs
        target_did_ids = {d.did_id for d in (target.spec.dids or [])}
        for did_id in rule.match.dids:
            if did_id not in target_did_ids:
                issues.append(ValidationIssue(
                    severity="warning", category="routing",
                    item_id=f"DID 0x{did_id:04X}",
                    message=(
                        f"{rule.from_ecu} -> {rule.to_ecu}: forwarded DID "
                        f"0x{did_id:04X} is not defined on {rule.to_ecu!r}"
                    ),
                ))
        if rule.match.did_range:
            lo, hi = rule.match.did_range
            covered = [d for d in target_did_ids if lo <= d <= hi]
            if not covered:
                issues.append(ValidationIssue(
                    severity="warning", category="routing",
                    item_id=f"DID 0x{lo:04X}..0x{hi:04X}",
                    message=(
                        f"{rule.from_ecu} -> {rule.to_ecu}: forwarded DID "
                        f"range 0x{lo:04X}..0x{hi:04X} matches no DID on "
                        f"{rule.to_ecu!r}"
                    ),
                ))

        # RIDs
        target_rid_ids = {r.routine_id for r in (target.spec.routines or [])}
        for rid in rule.match.rids:
            if rid not in target_rid_ids:
                issues.append(ValidationIssue(
                    severity="warning", category="routing",
                    item_id=f"RID 0x{rid:04X}",
                    message=(
                        f"{rule.from_ecu} -> {rule.to_ecu}: forwarded RID "
                        f"0x{rid:04X} is not defined on {rule.to_ecu!r}"
                    ),
                ))

        # SIDs
        target_sid_ids = {s.service_id for s in (target.spec.services or [])}
        for sid in rule.match.sids:
            if sid not in target_sid_ids:
                issues.append(ValidationIssue(
                    severity="warning", category="routing",
                    item_id=f"SID 0x{sid:02X}",
                    message=(
                        f"{rule.from_ecu} -> {rule.to_ecu}: forwarded SID "
                        f"0x{sid:02X} is not supported on {rule.to_ecu!r}"
                    ),
                ))
    return issues


def _check_security_compatibility(system: EcuSystem) -> list[ValidationIssue]:
    """For each routing rule, verify the gateway can serve the target's security needs."""
    issues: list[ValidationIssue] = []
    for rule in system.routing_rules:
        source = system.ecus.get(rule.from_ecu)
        target = system.ecus.get(rule.to_ecu)
        if not source or not target or not source.spec or not target.spec:
            continue

        src_levels = {s.security_level for s in (source.spec.security_levels or [])}
        tgt_levels = {s.security_level for s in (target.spec.security_levels or [])}
        missing = tgt_levels - src_levels
        if missing:
            for lvl in sorted(missing):
                issues.append(ValidationIssue(
                    severity="info", category="routing",
                    item_id=f"SecurityLevel 0x{lvl:02X}",
                    message=(
                        f"{rule.from_ecu} -> {rule.to_ecu}: target requires "
                        f"security level 0x{lvl:02X} but gateway "
                        f"{rule.from_ecu!r} doesn't define it. The gateway "
                        f"should pass through SecurityAccess (0x27) requests "
                        f"to the target ECU rather than handling them locally."
                    ),
                ))
    return issues


def _check_session_compatibility(system: EcuSystem) -> list[ValidationIssue]:
    """Sessions present on the target should be reachable from the gateway."""
    issues: list[ValidationIssue] = []
    for rule in system.routing_rules:
        source = system.ecus.get(rule.from_ecu)
        target = system.ecus.get(rule.to_ecu)
        if not source or not target or not source.spec or not target.spec:
            continue

        src_sessions = {s.short_name for s in (source.spec.sessions or [])}
        tgt_sessions = {s.short_name for s in (target.spec.sessions or [])}
        unique_to_target = tgt_sessions - src_sessions
        if unique_to_target:
            issues.append(ValidationIssue(
                severity="info", category="routing",
                item_id=f"{rule.from_ecu} -> {rule.to_ecu}",
                message=(
                    f"Target {rule.to_ecu!r} defines session(s) "
                    f"{sorted(unique_to_target)!r} that are not configured "
                    f"on gateway {rule.from_ecu!r}; tester cannot enter "
                    f"these sessions on the target via the gateway"
                ),
            ))
    return issues
