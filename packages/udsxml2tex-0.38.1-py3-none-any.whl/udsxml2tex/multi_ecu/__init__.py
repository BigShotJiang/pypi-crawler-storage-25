"""Multi-ECU diagnostic system support.

Models a diagnostic system composed of multiple AUTOSAR ECUs (each with its own
DCM/CanTp/DEM ARXML configuration) plus the routing relationships that describe
how diagnostic requests flow between them. Typical use case: a primary
"gateway" MCU that receives requests from the tester and forwards a subset to
a secondary "endpoint" MCU.

Quick start:

    from udsxml2tex.multi_ecu import load_system_config, generate_system_markdown

    system = load_system_config("system.yaml")
    md = generate_system_markdown(system)
    print(md)

For per-ECU details, each ECU's parsed `UdsSpecification` is available on
`system.ecus[name].spec` and can be passed to the existing single-ECU
`TexGenerator`.
"""

from udsxml2tex.multi_ecu.generator import (
    generate_system_html,
    generate_system_html_zip,
    generate_system_latex,
    generate_system_markdown,
    generate_system_structured_tex_zip,
)
from udsxml2tex.multi_ecu.inference import infer_routing_rules
from udsxml2tex.multi_ecu.loader import load_system_config
from udsxml2tex.multi_ecu.models import (
    EcuConfig,
    EcuConnection,
    EcuRole,
    EcuSystem,
    RoutingMatch,
    RoutingRule,
    SystemTopology,
)
from udsxml2tex.multi_ecu.validator import validate_system
from udsxml2tex.multi_ecu.visualizations import (
    generate_routing_sequence_tikz,
    generate_topology_html,
    generate_topology_tikz,
)

__all__ = [
    # Models
    "EcuConfig", "EcuConnection", "EcuRole", "EcuSystem",
    "RoutingMatch", "RoutingRule", "SystemTopology",
    # Loader / inference / validator
    "load_system_config", "infer_routing_rules", "validate_system",
    # Generators
    "generate_system_markdown", "generate_system_latex", "generate_system_html",
    "generate_system_html_zip", "generate_system_structured_tex_zip",
    # Visualizations
    "generate_topology_tikz", "generate_routing_sequence_tikz",
    "generate_topology_html",
]
