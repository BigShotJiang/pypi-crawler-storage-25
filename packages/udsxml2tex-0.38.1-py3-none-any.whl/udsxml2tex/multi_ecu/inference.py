"""ARXML-based routing inference for multi-ECU systems.

The library cannot fully infer inter-MCU diagnostic forwarding from ARXML alone
(typically PduR routing tables and application-layer code carry that semantic).
This module implements the cases that *are* recoverable from the parsed specs:

  1. **Coverage-gap heuristic** (1+1 redundant case):
     If one ECU plays the GATEWAY role and another plays ENDPOINT, any
     DID/RID/SID present on the endpoint but absent from the gateway is
     likely forwarded by the gateway. Emitted as a single inferred
     `RoutingRule` per category.

  2. **Shared CAN ID heuristic**:
     If two ECUs in the system advertise the same CAN diagnostic Rx ID, the
     gateway is likely intercepting and forwarding. Currently logged as a
     low-confidence note (no rule emitted) — extending in Phase C+ would
     mean parsing PduR routing tables.

The user can always override the inferred result by writing the rule
explicitly in the system config; explicit rules are kept and inferred rules
are merely appended.

Public API:
    infer_routing_rules(system) -> list[RoutingRule]
"""

from __future__ import annotations

import logging
from typing import Any

from udsxml2tex.multi_ecu.models import (
    EcuRole,
    EcuSystem,
    RoutingMatch,
    RoutingRule,
)

logger = logging.getLogger(__name__)


def infer_routing_rules(system: EcuSystem) -> list[RoutingRule]:
    """Return routing rules inferred from the parsed specs.

    Currently implements the 1+1 coverage-gap heuristic. Returns an empty
    list when the system layout is not amenable to inference (e.g., no
    GATEWAY/ENDPOINT pair, or specs not yet parsed).
    """
    gateway = system.primary
    endpoint = system.secondary
    if not gateway or not endpoint or gateway.name == endpoint.name:
        return []
    if gateway.spec is None or endpoint.spec is None:
        return []
    # The heuristic only makes sense for a deliberately tagged 1+1 layout —
    # for PEER configurations we don't infer forwarding, since no forwarding
    # is conceptually happening.
    if gateway.role != EcuRole.GATEWAY or endpoint.role != EcuRole.ENDPOINT:
        return []

    rules: list[RoutingRule] = []
    rules.extend(_infer_coverage_gap(gateway, endpoint, "dids"))
    rules.extend(_infer_coverage_gap(gateway, endpoint, "rids"))
    rules.extend(_infer_coverage_gap(gateway, endpoint, "sids"))
    return rules


def _infer_coverage_gap(
    gateway: Any, endpoint: Any, kind: str,
) -> list[RoutingRule]:
    """Emit a rule for items present only on the endpoint."""
    if kind == "dids":
        gw_ids = {d.did_id for d in (gateway.spec.dids or [])}
        ep_ids = {d.did_id for d in (endpoint.spec.dids or [])}
        match_field = "dids"
        label = "DIDs"
    elif kind == "rids":
        gw_ids = {r.routine_id for r in (gateway.spec.routines or [])}
        ep_ids = {r.routine_id for r in (endpoint.spec.routines or [])}
        match_field = "rids"
        label = "RIDs"
    elif kind == "sids":
        gw_ids = {s.service_id for s in (gateway.spec.services or [])}
        ep_ids = {s.service_id for s in (endpoint.spec.services or [])}
        match_field = "sids"
        label = "SIDs"
    else:
        return []

    forwarded = sorted(ep_ids - gw_ids)
    if not forwarded:
        return []

    match = RoutingMatch(**{match_field: forwarded})
    return [RoutingRule(
        from_ecu=gateway.name,
        to_ecu=endpoint.name,
        match=match,
        description=(
            f"{label} present on '{endpoint.name}' but not on '{gateway.name}' "
            f"(coverage-gap heuristic — {len(forwarded)} item(s))"
        ),
        inferred=True,
    )]
