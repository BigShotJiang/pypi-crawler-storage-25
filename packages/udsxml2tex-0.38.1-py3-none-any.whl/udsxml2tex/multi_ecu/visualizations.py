"""Multi-ECU topology and routing flow visualizations.

Produces standalone TikZ files (zero-runtime-deps beyond LaTeX). The same
diagrams are also rendered inline in the HTML system page via SVG-style
TikZ → SVG offline conversion is not done here; HTML uses a separate D3
helper.

Public API:
    generate_topology_tikz(system) -> str
    generate_routing_sequence_tikz(system, rule) -> str
    generate_topology_html(system) -> str        # inline SVG via simple boxes
"""

from __future__ import annotations

from udsxml2tex.multi_ecu.models import EcuSystem, RoutingRule


_TIKZ_PREAMBLE = r"""\documentclass[tikz, border=4pt]{standalone}
\usepackage{tikz}
\usepackage{xcolor}
\usetikzlibrary{positioning, arrows.meta, shapes.geometric, calc}
\definecolor{ecugw}{HTML}{334466}
\definecolor{ecuep}{HTML}{2A6E2A}
\definecolor{ecupeer}{HTML}{996600}
\begin{document}
"""

_TIKZ_POSTAMBLE = r"""\end{document}
"""


def _tex_escape(s: str) -> str:
    """Escape LaTeX specials in a label."""
    return (
        s.replace("\\", r"\textbackslash{}")
         .replace("&", r"\&")
         .replace("%", r"\%")
         .replace("#", r"\#")
         .replace("_", r"\_")
         .replace("$", r"\$")
         .replace("{", r"\{")
         .replace("}", r"\}")
         .replace("^", r"\^{}")
         .replace("~", r"\~{}")
    )


def _ecu_color(role: str) -> str:
    return {"gateway": "ecugw", "endpoint": "ecuep"}.get(role, "ecupeer")


def generate_topology_tikz(system: EcuSystem) -> str:
    """Standalone TikZ figure showing all ECUs and their physical connections.

    Layout: gateway centered top, endpoints arranged horizontally below.
    Routing rules render as labeled arrows; physical-only connections as
    plain edges. Single-ECU systems render a stub note.
    """
    lines: list[str] = [_TIKZ_PREAMBLE]
    lines.append(r"\begin{tikzpicture}[font=\small, node distance=2.5cm]")
    lines.append(r"\node[anchor=south west, font=\bfseries] at (0, 4.0) "
                 r"{System topology: " + _tex_escape(system.name) + "};")

    if not system.ecus:
        lines.append(r"\node at (0, 0) {(no ECUs configured)};")
        lines.append(r"\end{tikzpicture}")
        lines.append(_TIKZ_POSTAMBLE)
        return "\n".join(lines)

    # Tester node (only when there's at least one gateway-or-peer)
    has_external = any(
        e.role.value in ("gateway", "peer") for e in system.ecus.values()
    )
    if has_external:
        lines.append(r"\node[draw, dashed, rounded corners, minimum width=2.5cm,"
                     r" minimum height=1cm] (tester) at (-4, 2) {Tester};")

    # Place ECUs: gateways at y=2, endpoints/peers at y=-1.5
    gateways = [e for e in system.ecus.values() if e.role.value == "gateway"]
    endpoints = [e for e in system.ecus.values() if e.role.value == "endpoint"]
    peers = [e for e in system.ecus.values() if e.role.value == "peer"]

    # Position gateways
    for i, ecu in enumerate(gateways):
        x = i * 4.0
        color = _ecu_color(ecu.role.value)
        lines.append(
            f"\\node[draw, fill={color}!20, rounded corners, "
            f"minimum width=3cm, minimum height=1.2cm, align=center] "
            f"(gw_{_safe(ecu.name)}) at ({x:.1f}, 2) "
            f"{{\\textbf{{{_tex_escape(ecu.name)}}}}};"
        )

    # Position endpoints
    for i, ecu in enumerate(endpoints):
        x = i * 4.0
        color = _ecu_color(ecu.role.value)
        lines.append(
            f"\\node[draw, fill={color}!20, rounded corners, "
            f"minimum width=3cm, minimum height=1.2cm, align=center] "
            f"(ep_{_safe(ecu.name)}) at ({x:.1f}, -1.5) "
            f"{{\\textbf{{{_tex_escape(ecu.name)}}}}};"
        )

    # Position peers (above the gateway row when no gateway, beside it otherwise)
    for i, ecu in enumerate(peers):
        x = (len(gateways) + i) * 4.0
        color = _ecu_color(ecu.role.value)
        lines.append(
            f"\\node[draw, fill={color}!20, rounded corners, "
            f"minimum width=3cm, minimum height=1.2cm, align=center] "
            f"(pr_{_safe(ecu.name)}) at ({x:.1f}, 2) "
            f"{{\\textbf{{{_tex_escape(ecu.name)}}}}};"
        )

    # Tester → gateway/peer edges
    if has_external:
        for ecu in gateways:
            lines.append(
                f"\\draw[->, thick] (tester) -- (gw_{_safe(ecu.name)});"
            )
        for ecu in peers:
            lines.append(
                f"\\draw[->, thick] (tester) -- (pr_{_safe(ecu.name)});"
            )

    # Routing rules → labeled forwarding arrows
    rule_index = 0
    for rule in system.routing_rules:
        from_id = _node_id(system, rule.from_ecu)
        to_id = _node_id(system, rule.to_ecu)
        if not from_id or not to_id:
            continue
        rule_index += 1
        label = _tex_escape(rule.match.description() or "all")
        bend = "bend right" if rule_index % 2 == 0 else "bend left"
        suffix = " (inferred)" if rule.inferred else ""
        lines.append(
            f"\\draw[->, thick, blue!70] ({from_id}) to[{bend}=15] "
            f"node[midway, font=\\scriptsize, fill=white, inner sep=1pt] "
            f"{{{label}{suffix}}} ({to_id});"
        )

    # Physical connections (dashed, no arrow)
    for conn in system.topology.connections:
        from_id = _node_id(system, conn.from_ecu)
        to_id = _node_id(system, conn.to_ecu)
        if not from_id or not to_id:
            continue
        lines.append(
            f"\\draw[dashed, gray] ({from_id}) -- ({to_id}) "
            f"node[midway, fill=white, inner sep=1pt, font=\\tiny] "
            f"{{{_tex_escape(conn.medium)}}};"
        )

    lines.append(r"\end{tikzpicture}")
    lines.append(_TIKZ_POSTAMBLE)
    return "\n".join(lines)


def generate_routing_sequence_tikz(system: EcuSystem, rule: RoutingRule) -> str:
    """TikZ sequence diagram: tester → from_ecu → to_ecu → response back."""
    from_name = _tex_escape(rule.from_ecu)
    to_name = _tex_escape(rule.to_ecu)
    label = _tex_escape(rule.match.description() or "request")

    return _TIKZ_PREAMBLE + r"""
\begin{tikzpicture}[font=\small,
    actor/.style={draw, fill=gray!10, minimum width=2.5cm, minimum height=0.7cm},
    msg/.style={->, thick}]
\node[actor] (t)  at (0, 5)   {Tester};
\node[actor] (a)  at (5, 5)   {""" + from_name + r"""};
\node[actor] (b)  at (10, 5)  {""" + to_name + r"""};

\draw[dashed, gray] (t) -- (0, 0);
\draw[dashed, gray] (a) -- (5, 0);
\draw[dashed, gray] (b) -- (10, 0);

\draw[msg] (0, 4) -- node[above, font=\scriptsize] {Request: """ + label + r"""} (5, 4);
\draw[msg] (5, 3.3) -- node[above, font=\scriptsize] {forward (PduR / app routing)} (10, 3.3);
\draw[msg, blue!70] (10, 2.5) -- node[above, font=\scriptsize] {Positive Response} (5, 2.5);
\draw[msg, blue!70] (5, 1.8)  -- node[above, font=\scriptsize] {Positive Response} (0, 1.8);

\node[font=\bfseries, anchor=south west] at (0, 5.6) {Routing flow: """ + from_name + r""" $\to$ """ + to_name + r"""};
\end{tikzpicture}
""" + _TIKZ_POSTAMBLE


def _node_id(system: EcuSystem, name: str) -> str:
    """Return the TikZ node identifier for a given ECU name based on its role."""
    cfg = system.ecus.get(name)
    if not cfg:
        return ""
    safe = _safe(name)
    return {
        "gateway":  f"gw_{safe}",
        "endpoint": f"ep_{safe}",
        "peer":     f"pr_{safe}",
    }.get(cfg.role.value, f"pr_{safe}")


def _safe(name: str) -> str:
    """Sanitize an ECU name for use as a TikZ node identifier."""
    return "".join(c if c.isalnum() else "_" for c in name)


def generate_topology_svg_from_tikz(system: EcuSystem) -> str | None:
    """Compile the TikZ topology to inline SVG via ``xelatex`` + ``pdftocairo``.

    Returns the SVG markup as a string ready to embed in HTML, or ``None``
    when the LaTeX toolchain isn't available or the conversion fails. The
    HTML renderer falls back to :func:`generate_topology_html` (the
    hand-rolled SVG) in that case, so no functional regression on hosts
    without TeX Live.

    Uses ``xelatex → PDF → pdftocairo -svg`` rather than ``dvisvgm`` because
    the XeTeX XDV format does not carry an accurate page bounding box for
    ``standalone`` documents (dvisvgm reports a near-zero height).
    """
    import shutil
    if not (shutil.which("xelatex") and shutil.which("pdftocairo")):
        return None
    import re
    import subprocess
    import tempfile
    from pathlib import Path

    tex_source = generate_topology_tikz(system)
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp = Path(tmpdir)
            (tmp / "topo.tex").write_text(tex_source, encoding="utf-8")
            r1 = subprocess.run(
                ["xelatex", "-interaction=batchmode", "-halt-on-error",
                 "topo.tex"],
                cwd=tmp, capture_output=True, timeout=90,
            )
            if r1.returncode != 0:
                return None
            pdf = tmp / "topo.pdf"
            if not pdf.exists():
                return None
            r2 = subprocess.run(
                ["pdftocairo", "-svg", "topo.pdf", "topo.svg"],
                cwd=tmp, capture_output=True, timeout=60,
            )
            if r2.returncode != 0:
                return None
            svg = tmp / "topo.svg"
            if not svg.exists():
                return None
            content = svg.read_text(encoding="utf-8")
    except Exception:
        return None

    # Strip the XML prolog (HTML doesn't need it for inline SVG) and inject a
    # class hook for CSS sizing.
    content = re.sub(r"<\?xml[^?]*\?>", "", content).strip()
    content = re.sub(
        r"<svg(\s[^>]*)?>",
        lambda m: f'<svg class="system-topology-svg"{m.group(1) or ""}>',
        content, count=1,
    )
    return content


def generate_topology_html(system: EcuSystem) -> str:
    """Inline HTML/SVG-ish topology fragment for the system integration page.

    Renders ECUs as styled boxes with arrows between them. Pure CSS + a tiny
    inline SVG so no JS / external assets are required.
    """
    width = max(400, 240 * max(len(system.ecus), 1))
    height = 320
    boxes: list[str] = []
    arrows: list[str] = []

    role_color = {"gateway": "#334466", "endpoint": "#2A6E2A", "peer": "#996600"}
    coords: dict[str, tuple[int, int, int, int]] = {}  # name -> (x, y, w, h)

    gateways = [e for e in system.ecus.values() if e.role.value == "gateway"]
    endpoints = [e for e in system.ecus.values() if e.role.value == "endpoint"]
    peers = [e for e in system.ecus.values() if e.role.value == "peer"]

    box_w, box_h = 180, 70
    pad_x = 40

    def _layout_row(items: list, y: int, x_start: int) -> int:
        x = x_start
        for ecu in items:
            coords[ecu.name] = (x, y, box_w, box_h)
            color = role_color.get(ecu.role.value, "#888")
            boxes.append(
                f'<rect x="{x}" y="{y}" width="{box_w}" height="{box_h}" '
                f'rx="6" ry="6" fill="{color}" fill-opacity="0.18" '
                f'stroke="{color}" stroke-width="2"/>'
                f'<text x="{x + box_w // 2}" y="{y + box_h // 2 + 5}" text-anchor="middle" '
                f'font-family="Georgia, serif" font-weight="bold" font-size="14" '
                f'fill="{color}">{_html_escape(ecu.name)}</text>'
            )
            x += box_w + pad_x
        return x

    _layout_row(gateways, 60, pad_x)
    _layout_row(peers, 60, pad_x + (box_w + pad_x) * len(gateways))
    _layout_row(endpoints, 200, pad_x)

    # Tester box (left of gateway/peer)
    if gateways or peers:
        boxes.append(
            f'<rect x="{pad_x // 2}" y="60" width="60" height="{box_h}" '
            f'rx="6" ry="6" fill="#fafafa" stroke="#666" stroke-dasharray="4,2"/>'
            f'<text x="{pad_x // 2 + 30}" y="100" text-anchor="middle" '
            f'font-family="Georgia, serif" font-size="12">Tester</text>'
        )

    # Routing arrows: group rules by (from, to) pair so multiple rules
    # between the same ECU pair share a single arrow with a stacked,
    # readable multi-line label (instead of overlapping on top of each other).
    grouped: dict[tuple[str, str], list] = {}
    for rule in system.routing_rules:
        if rule.from_ecu not in coords or rule.to_ecu not in coords:
            continue
        grouped.setdefault((rule.from_ecu, rule.to_ecu), []).append(rule)

    line_h = 12  # px between stacked label lines
    char_w = 5.5  # rough average char width at font-size=10
    for (src, dst), rules in grouped.items():
        fx, fy, fw, fh = coords[src]
        tx, ty, tw, th = coords[dst]
        x1, y1 = fx + fw // 2, fy + fh
        x2, y2 = tx + tw // 2, ty
        mx, my = (x1 + x2) // 2, (y1 + y2) // 2

        labels = [
            (rule.match.description() or "all")
            + (" (inferred)" if rule.inferred else "")
            for rule in rules
        ]
        # Stack labels vertically centered around midpoint
        total_h = line_h * len(labels)
        top_y = my - total_h // 2 + line_h - 2
        max_w = int(max(len(s) for s in labels) * char_w) + 12
        bg_x = mx - max_w // 2
        bg_y = my - total_h // 2 - 2

        arrows.append(
            f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" '
            f'stroke="#3366cc" stroke-width="2" marker-end="url(#arrow)"/>'
            f'<rect x="{bg_x}" y="{bg_y}" width="{max_w}" height="{total_h + 4}" '
            f'fill="#ffffff" fill-opacity="0.85" stroke="none"/>'
        )
        tspans = "".join(
            f'<tspan x="{mx}" dy="{0 if i == 0 else line_h}">'
            f'{_html_escape(lbl)}</tspan>'
            for i, lbl in enumerate(labels)
        )
        arrows.append(
            f'<text x="{mx}" y="{top_y}" text-anchor="middle" '
            f'font-size="10" font-family="Arial, sans-serif" '
            f'fill="#3366cc">{tspans}</text>'
        )

    return (
        f'<svg width="{width}" height="{height}" xmlns="http://www.w3.org/2000/svg" '
        f'style="background:#fdfdfd; border:1px solid #ccc;">'
        f'<defs><marker id="arrow" markerWidth="10" markerHeight="10" '
        f'refX="8" refY="3" orient="auto"><path d="M 0 0 L 8 3 L 0 6 Z" '
        f'fill="#3366cc"/></marker></defs>'
        + "".join(boxes) + "".join(arrows) +
        "</svg>"
    )


def _html_escape(s: str) -> str:
    return (
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
         .replace('"', "&quot;").replace("'", "&#39;")
    )
