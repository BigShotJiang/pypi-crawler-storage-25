"""Scan AUTOSAR application-layer C/C++ source files for global variables used in DID read/write functions."""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Optional

from udsxml2tex.models import Did, Routine

logger = logging.getLogger(__name__)

# Source file extensions scanned by default
_C_EXTENSIONS: tuple[str, ...] = (".c", ".cpp", ".cc", ".cxx")

# C keywords and common AUTOSAR/MISRA type names to exclude from variable candidates
_EXCLUDE_IDENTS: frozenset[str] = frozenset({
    # C keywords
    "if", "else", "for", "while", "do", "return", "break", "continue",
    "switch", "case", "default", "sizeof", "typedef", "struct", "enum",
    "union", "static", "const", "volatile", "extern", "auto", "register",
    "goto", "inline",
    # Common AUTOSAR / MISRA constants
    "NULL", "TRUE", "FALSE", "E_OK", "E_NOT_OK",
    # Integer types
    "uint8", "uint16", "uint32", "uint64",
    "int8", "int16", "int32", "int64",
    "uint8_t", "uint16_t", "uint32_t", "uint64_t",
    "int8_t", "int16_t", "int32_t", "int64_t",
    "int", "char", "short", "long", "unsigned", "signed", "void",
    "float", "double", "bool",
    "boolean", "Std_ReturnType",
    # Numeric literals that slip through the identifier regex
    "u", "U", "ul", "UL", "ull", "ULL",
})

# Types whose appearance signals a local variable declaration that follows
_DECL_TYPES: tuple[str, ...] = (
    "uint8", "uint16", "uint32", "uint64",
    "int8", "int16", "int32", "int64",
    "uint8_t", "uint16_t", "uint32_t", "uint64_t",
    "int8_t", "int16_t", "int32_t", "int64_t",
    "int", "char", "short", "long", "unsigned", "signed", "void",
    "float", "double", "bool", "boolean",
    "Std_ReturnType",
)
_DECL_TYPE_RE = re.compile(
    r"\b(?:" + "|".join(re.escape(t) for t in _DECL_TYPES) + r")\s+\*{0,2}(\w+)"
)

# Matches a C identifier not immediately followed by '(' (i.e., not a function call)
_IDENT_RE = re.compile(r"\b([A-Za-z_]\w*)\b(?!\s*\()")

# Strip C-style comments and string/char literals before analysis
_BLOCK_COMMENT_RE = re.compile(r"/\*.*?\*/", re.DOTALL)
_LINE_COMMENT_RE = re.compile(r"//[^\n]*")
_STRING_LITERAL_RE = re.compile(r'"(?:[^"\\]|\\.)*"')
_CHAR_LITERAL_RE = re.compile(r"'(?:[^'\\]|\\.)'")


def _strip_comments_and_literals(src: str) -> str:
    src = _BLOCK_COMMENT_RE.sub(" ", src)
    src = _LINE_COMMENT_RE.sub(" ", src)
    src = _STRING_LITERAL_RE.sub('""', src)
    src = _CHAR_LITERAL_RE.sub("''", src)
    return src


# ---------------------------------------------------------------------------
# Macro expansion
# ---------------------------------------------------------------------------

_DEFINE_RE = re.compile(
    r"^\s*#\s*define\s+(\w+)(?:\([^)]*\))?\s+(.+?)(?:\s*//.*)?$",
    re.MULTILINE,
)


def _extract_macros(src: str) -> dict[str, str]:
    """Return a dict of {macro_name: expansion} for object-like #defines."""
    macros: dict[str, str] = {}
    for m in _DEFINE_RE.finditer(src):
        name, expansion = m.group(1), m.group(2).strip()
        # Skip function-like macros (already excluded by the regex guard above)
        # and macros whose expansion is just a number or string literal
        if re.fullmatch(r'[A-Za-z_]\w*', expansion):
            macros[name] = expansion
    return macros


def _extract_function_body(src: str, func_name: str) -> tuple[str, list[str]] | None:
    """Return (body_text, param_names) for the first definition of func_name, or None."""
    # Match: [return_type] func_name ( params ) { ...
    # We accept any characters before func_name as the return type.
    pattern = re.compile(
        r"\b" + re.escape(func_name) + r"\s*\(([^)]*)\)\s*\{",
        re.MULTILINE,
    )
    m = pattern.search(src)
    if not m:
        return None

    # Extract parameter names (strip type qualifiers, pointer stars, etc.)
    params_raw = m.group(1)
    param_names: list[str] = []
    for part in params_raw.split(","):
        part = part.strip()
        if not part:
            continue
        # Last word is the parameter name (may be preceded by * for pointer)
        words = re.split(r"[\s*\[\]]+", part)
        words = [w for w in words if w and re.match(r"^[A-Za-z_]\w*$", w)]
        if words:
            param_names.append(words[-1])

    # Find matching closing brace
    start = m.end() - 1  # position of opening '{'
    depth = 0
    i = start
    while i < len(src):
        if src[i] == "{":
            depth += 1
        elif src[i] == "}":
            depth -= 1
            if depth == 0:
                break
        i += 1

    body = src[start + 1 : i]
    return body, param_names


def _find_global_variables(
    body: str,
    param_names: list[str],
    macros: Optional[dict[str, str]] = None,
) -> list[str]:
    """Heuristically extract global variable names referenced in a function body.

    If *macros* is provided, object-like #define aliases are transparently
    resolved so that a macro that aliases a global variable is also reported.
    """
    clean = _strip_comments_and_literals(body)

    locals_: set[str] = set(re.findall(_DECL_TYPE_RE, clean))
    exclude = _EXCLUDE_IDENTS | locals_ | set(param_names)

    candidates: list[str] = []
    seen: set[str] = set()
    for ident in re.findall(_IDENT_RE, clean):
        if ident in exclude or ident in seen:
            continue
        candidates.append(ident)
        seen.add(ident)
        # Resolve macro alias → also add the aliased identifier
        if macros and ident in macros:
            alias = macros[ident]
            if alias not in exclude and alias not in seen:
                candidates.append(alias)
                seen.add(alias)

    return candidates


def _load_sources(
    paths: list[Path],
    include_headers: bool = True,
) -> list[tuple[Path, str]]:
    """Load C/C++ source (and optionally header) files, expanding directories recursively."""
    extensions = set(_C_EXTENSIONS)
    if include_headers:
        extensions.update({".h", ".hpp", ".hxx"})

    sources: list[tuple[Path, str]] = []
    for p in paths:
        if p.is_dir():
            for src_file in sorted(f for ext in extensions for f in p.rglob(f"*{ext}")):
                try:
                    sources.append((src_file, src_file.read_text(encoding="utf-8", errors="replace")))
                except OSError as e:
                    logger.warning("Cannot read %s: %s", src_file, e)
        elif p.is_file():
            try:
                sources.append((p, p.read_text(encoding="utf-8", errors="replace")))
            except OSError as e:
                logger.warning("Cannot read %s: %s", p, e)
        else:
            logger.warning("C source path not found: %s", p)
    return sources


def _collect_called_functions(body: str) -> list[str]:
    """Return identifiers immediately followed by '(' (i.e., function calls) in body."""
    call_re = re.compile(r"\b([A-Za-z_]\w*)\s*\(")
    return list(dict.fromkeys(call_re.findall(body)))  # ordered unique


def _vars_for_func_impl(
    sources: list[tuple[Path, str]],
    macros: dict[str, str],
    func_name: str,
    transitive_depth: int,
    visited: set[str],
) -> list[str]:
    """Recursively collect global variables for *func_name* up to *transitive_depth* levels.

    Args:
        sources:          Pre-loaded list of (path, source_text) pairs.
        macros:           Pre-extracted macro alias dict from _extract_macros().
        func_name:        C function name to search for.
        transitive_depth: Remaining recursion depth.
        visited:          Set of function names already processed (mutated in-place).
    """
    if func_name in visited:
        return []
    visited.add(func_name)
    all_vars: list[str] = []
    for src_path, src_text in sources:
        result = _extract_function_body(src_text, func_name)
        if result is None:
            continue
        body, params = result
        variables = _find_global_variables(body, params, macros)
        logger.debug(
            "  %s: found in %s → %d candidate(s)%s",
            func_name, src_path.name, len(variables),
            f" (depth={transitive_depth})" if transitive_depth > 0 else "",
        )
        all_vars.extend(variables)
        # Transitive: follow called functions
        if transitive_depth > 0:
            for called in _collect_called_functions(body):
                if called not in visited and called not in _EXCLUDE_IDENTS:
                    all_vars.extend(
                        _vars_for_func_impl(sources, macros, called, transitive_depth - 1, visited)
                    )
        break  # stop at first file defining the function
    return all_vars


def scan_did_variables(
    c_paths: list[Path],
    dids: list[Did],
    *,
    include_headers: bool = True,
    transitive_depth: int = 0,
) -> None:
    """Populate DataElement.global_variables by scanning C/C++ source files.

    For each DataElement that has a read_function (or write_function), this
    function searches the source files for that function's definition and
    extracts identifiers that are likely global variables.

    Args:
        c_paths:          C source files or directories to search.
        dids:             Did objects whose DataElement.global_variables to fill.
        include_headers:  Also scan .h / .hpp header files (default True).
        transitive_depth: Follow function calls up to this many levels deep
                          (0 = only the direct read/write function body).
                          Values > 3 are clamped to 3 to bound runtime.
    """
    if not c_paths or not dids:
        return

    transitive_depth = min(max(transitive_depth, 0), 3)

    sources = _load_sources(c_paths, include_headers=include_headers)
    if not sources:
        logger.warning("No C/C++ source files found in the provided paths.")
        return

    logger.info("C scanner: loaded %d source file(s)", len(sources))

    # Build a combined source text for global macro extraction
    combined_src = "\n".join(src for _, src in sources)
    macros = _extract_macros(combined_src)
    if macros:
        logger.debug("C scanner: extracted %d macro alias(es)", len(macros))

    # Collect all function names we need to find
    func_to_elements: dict[str, list] = {}
    for did in dids:
        for de in did.data_elements:
            for fnc in (de.read_function, de.write_function):
                if fnc:
                    func_to_elements.setdefault(fnc, []).append(de)

    if not func_to_elements:
        logger.info("C scanner: no DID read/write functions found in parsed ARXML.")
        return

    logger.info("C scanner: searching for %d function(s) (transitive depth=%d)",
                len(func_to_elements), transitive_depth)

    for func_name, elements in func_to_elements.items():
        variables = _vars_for_func_impl(sources, macros, func_name, transitive_depth, set())
        if not variables:
            logger.debug("  %s: not found in any source file", func_name)
            continue
        for de in elements:
            existing = set(de.global_variables)
            de.global_variables.extend(v for v in variables if v not in existing)
            existing.update(variables)


def scan_rid_variables(
    c_paths: list[Path],
    routines: list[Routine],
    *,
    include_headers: bool = True,
    transitive_depth: int = 0,
) -> None:
    """Populate Routine.global_variables by scanning C/C++ source files.

    For each Routine that has a start_function, stop_function, or result_function,
    this function searches the source files for that function's definition and
    extracts identifiers that are likely global variables. If no function names
    are set, falls back to searching for functions whose name contains the routine
    ID hex string (e.g. a routine with ID 0x0200 matches functions containing "0200").

    Args:
        c_paths:          C source files or directories to search.
        routines:         Routine objects whose global_variables to fill.
        include_headers:  Also scan .h / .hpp header files (default True).
        transitive_depth: Follow function calls up to this many levels deep.
    """
    if not c_paths or not routines:
        return

    transitive_depth = min(max(transitive_depth, 0), 3)

    sources = _load_sources(c_paths, include_headers=include_headers)
    if not sources:
        logger.warning("No C/C++ source files found in the provided paths.")
        return

    logger.info("C scanner (RID): loaded %d source file(s)", len(sources))

    # Build a combined source text for global macro extraction
    combined_src = "\n".join(src for _, src in sources)
    macros = _extract_macros(combined_src)
    if macros:
        logger.debug("C scanner (RID): extracted %d macro alias(es)", len(macros))

    # Regex to extract function names from source files (for fallback pattern search)
    _func_name_re = re.compile(r"\b([A-Za-z_]\w*)\s*\(")

    for routine in routines:
        # Gather explicit function names if available
        func_names: list[str] = [
            fnc for fnc in (routine.start_function, routine.stop_function, routine.result_function)
            if fnc
        ]

        # Fallback: find functions whose name contains the routine ID hex string
        if not func_names:
            rid_pattern = f"{routine.routine_id:04X}"
            for _src_path, src_text in sources:
                stripped = _strip_comments_and_literals(src_text)
                for m in _func_name_re.finditer(stripped):
                    candidate = m.group(1)
                    if rid_pattern.lower() in candidate.lower() or rid_pattern.upper() in candidate:
                        if candidate not in func_names and candidate not in _EXCLUDE_IDENTS:
                            func_names.append(candidate)

        if not func_names:
            logger.debug("  Routine %s: no function names found, skipping", routine.routine_id_hex)
            continue

        logger.info(
            "C scanner (RID): routine %s — scanning %d function(s) (transitive depth=%d)",
            routine.routine_id_hex, len(func_names), transitive_depth,
        )

        all_variables: list[str] = []
        seen: set[str] = set()
        for func_name in func_names:
            variables = _vars_for_func_impl(sources, macros, func_name, transitive_depth, set())
            if not variables:
                logger.debug("  %s: not found in any source file", func_name)
                continue
            for v in variables:
                if v not in seen:
                    all_variables.append(v)
                    seen.add(v)

        if all_variables:
            existing = set(routine.global_variables)
            routine.global_variables.extend(v for v in all_variables if v not in existing)
