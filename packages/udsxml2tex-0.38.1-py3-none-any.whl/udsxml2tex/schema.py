"""JSON Schema and Pydantic v2 model export for UDS specifications."""

from __future__ import annotations

import json
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    pass

__all__ = ["generate_json_schema", "save_json_schema", "generate_pydantic_models"]


def generate_json_schema(spec_class=None) -> dict:
    """Generate a JSON Schema draft-07 dict for UdsSpecification."""
    from udsxml2tex.models import UdsSpecification

    if spec_class is None:
        spec_class = UdsSpecification

    schema = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "$id": "https://github.com/YutaroNakagama/udsxml2tex/schemas/uds-specification.json",
        "title": "UdsSpecification",
        "description": "AUTOSAR UDS specification extracted from ARXML",
        "type": "object",
        "properties": {
            "ecu_name": {"type": "string", "description": "ECU name"},
            "description": {"type": "string"},
            "sessions": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "short_name": {"type": "string"},
                        "session_id": {"type": "integer"},
                        "p2_server_max": {"type": "number"},
                        "p2_star_server_max": {"type": "number"},
                    },
                    "required": ["short_name", "session_id"],
                },
            },
            "security_levels": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "short_name": {"type": "string"},
                        "security_level": {"type": "integer"},
                        "key_size": {"type": "integer"},
                        "seed_size": {"type": "integer"},
                        "num_max_attempts": {"type": "integer"},
                    },
                    "required": ["short_name", "security_level"],
                },
            },
            "services": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "short_name": {"type": "string"},
                        "service_id": {"type": "integer"},
                        "description": {"type": "string"},
                        "supported_sessions": {
                            "type": "array",
                            "items": {"type": "string"},
                        },
                        "required_security_levels": {
                            "type": "array",
                            "items": {"type": "string"},
                        },
                    },
                    "required": ["short_name", "service_id"],
                },
            },
            "dids": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "short_name": {"type": "string"},
                        "did_id": {"type": "integer"},
                        "description": {"type": "string"},
                        "read_access": {"type": "boolean"},
                        "write_access": {"type": "boolean"},
                        "total_byte_length": {"type": "integer"},
                        "data_elements": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "short_name": {"type": "string"},
                                    "byte_position": {"type": "integer"},
                                    "bit_size": {"type": "integer"},
                                    "data_type": {"type": "string"},
                                },
                            },
                        },
                    },
                    "required": ["short_name", "did_id"],
                },
            },
            "routines": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "short_name": {"type": "string"},
                        "routine_id": {"type": "integer"},
                        "description": {"type": "string"},
                    },
                    "required": ["short_name", "routine_id"],
                },
            },
            "dtcs": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "short_name": {"type": "string"},
                        "dtc_id": {"type": "integer"},
                        "description": {"type": "string"},
                        "severity": {"type": "string"},
                    },
                    "required": ["short_name", "dtc_id"],
                },
            },
            "memory_ranges": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "short_name": {"type": "string"},
                        "start_address": {"type": "integer"},
                        "end_address": {"type": "integer"},
                        "read_access": {"type": "boolean"},
                        "write_access": {"type": "boolean"},
                    },
                },
            },
        },
        "required": ["ecu_name"],
    }
    return schema


def save_json_schema(path: "str | Path") -> Path:
    """Save the JSON Schema to a file.

    Parameters
    ----------
    path:
        Destination file path. Parent directories are created if needed.

    Returns
    -------
    Path
        The path that was written.
    """
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    schema = generate_json_schema()
    p.write_text(json.dumps(schema, indent=2, ensure_ascii=False), encoding="utf-8")
    return p


def generate_pydantic_models() -> str:
    """Return Pydantic v2 model definitions as a Python source code string."""
    return '''"""
Auto-generated Pydantic v2 models for UDS specification.
Generated by udsxml2tex.schema.generate_pydantic_models()
"""

from __future__ import annotations
from typing import Optional, List
from pydantic import BaseModel, Field


class DataElementModel(BaseModel):
    short_name: str
    byte_position: int = 0
    bit_position: int = 0
    bit_size: int = 8
    description: str = ""
    data_type: str = "uint8"
    min_value: Optional[float] = None
    max_value: Optional[float] = None
    unit: str = ""


class DidModel(BaseModel):
    short_name: str
    did_id: int
    description: str = ""
    data_elements: List[DataElementModel] = Field(default_factory=list)
    read_access: bool = True
    write_access: bool = False
    total_byte_length: int = 0
    supported_sessions: List[str] = Field(default_factory=list)
    required_security_levels: List[str] = Field(default_factory=list)


class DiagSessionModel(BaseModel):
    short_name: str
    session_id: int
    p2_server_max: float = 0.05
    p2_star_server_max: float = 5.0


class SecurityLevelModel(BaseModel):
    short_name: str
    security_level: int
    key_size: int = 0
    seed_size: int = 0
    num_max_attempts: int = 3
    delay_time_on_boot: float = 0.0


class SubFunctionModel(BaseModel):
    short_name: str
    sub_function_id: int
    description: str = ""


class NrcEntryModel(BaseModel):
    nrc_code: int
    nrc_name: str
    description: str = ""


class UdsServiceModel(BaseModel):
    short_name: str
    service_id: int
    description: str = ""
    sub_functions: List[SubFunctionModel] = Field(default_factory=list)
    supported_sessions: List[str] = Field(default_factory=list)
    required_security_levels: List[str] = Field(default_factory=list)
    nrc_list: List[NrcEntryModel] = Field(default_factory=list)


class RoutineParameterModel(BaseModel):
    short_name: str
    direction: str = "in"
    byte_position: int = 0
    bit_size: int = 8
    data_type: str = "uint8"


class RoutineModel(BaseModel):
    short_name: str
    routine_id: int
    description: str = ""
    in_parameters: List[RoutineParameterModel] = Field(default_factory=list)
    out_parameters: List[RoutineParameterModel] = Field(default_factory=list)
    supported_sessions: List[str] = Field(default_factory=list)


class DtcDefinitionModel(BaseModel):
    short_name: str
    dtc_id: int
    description: str = ""
    severity: str = ""
    functional_unit: str = ""


class MemoryRangeModel(BaseModel):
    short_name: str
    start_address: int = 0
    end_address: int = 0
    read_access: bool = False
    write_access: bool = False


class UdsSpecificationModel(BaseModel):
    ecu_name: str = "ECU"
    description: str = ""
    sessions: List[DiagSessionModel] = Field(default_factory=list)
    security_levels: List[SecurityLevelModel] = Field(default_factory=list)
    services: List[UdsServiceModel] = Field(default_factory=list)
    dids: List[DidModel] = Field(default_factory=list)
    routines: List[RoutineModel] = Field(default_factory=list)
    dtcs: List[DtcDefinitionModel] = Field(default_factory=list)
    memory_ranges: List[MemoryRangeModel] = Field(default_factory=list)
'''
