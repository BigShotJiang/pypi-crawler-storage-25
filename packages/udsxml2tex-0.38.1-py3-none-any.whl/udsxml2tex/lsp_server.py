"""Language Server Protocol server for ARXML UDS specification files.

Provides completion, hover, and go-to-definition for ARXML editors.

Usage:
    python -m udsxml2tex.lsp_server --stdio
    python -m udsxml2tex.lsp_server --tcp --port 2087

Requires: pip install udsxml2tex[lsp]  (pygls)
"""

from __future__ import annotations

from typing import Dict, List, Optional

try:
    from pygls.server import LanguageServer  # type: ignore[import]
    from lsprotocol import types as lsp  # type: ignore[import]

    _HAS_PYGLS = True
except ImportError:
    _HAS_PYGLS = False

    class LanguageServer:  # type: ignore[no-redef]
        """Stub for when pygls is not installed."""

        def __init__(self, *args, **kwargs) -> None:
            raise ImportError(
                "pygls is required for LSP support. "
                "Install it with: pip install udsxml2tex[lsp]"
            )

        def feature(self, *args, **kwargs):
            def decorator(func):
                return func

            return decorator

        def start_io(self):
            raise ImportError(
                "pygls is required for LSP support. "
                "Install it with: pip install udsxml2tex[lsp]"
            )

        def start_tcp(self, host, port):
            raise ImportError(
                "pygls is required for LSP support. "
                "Install it with: pip install udsxml2tex[lsp]"
            )


__all__ = ["UdsArxmlLanguageServer", "server", "main"]

# ---------------------------------------------------------------------------
# Known ARXML element names and their documentation strings
# ---------------------------------------------------------------------------

ARXML_COMPLETIONS: List[str] = [
    "DcmDspDid",
    "DcmDspDidData",
    "DcmDspDtcDid",
    "DcmDspSecurity",
    "DcmDspSession",
    "DcmDslProtocolRow",
    "DcmDslConnection",
    "DemDTC",
    "DemEventParameter",
    "DemDTCAttributes",
    "CanTpChannel",
    "CanTpRxNPdu",
    "CanTpTxNPdu",
    "SHORT-NAME",
    "LONG-NAME",
    "CATEGORY",
    "ADMIN-DATA",
]

ARXML_ELEMENT_DOCS: Dict[str, str] = {
    "DcmDspDid": (
        "DcmDspDid — Data Identifier (DID) container in the DCM (Diagnostic Communication Manager). "
        "Defines a DID for ReadDataByIdentifier (0x22) and WriteDataByIdentifier (0x2E) services. "
        "ISO 14229-1 §10.2/10.7."
    ),
    "DcmDspDidData": (
        "DcmDspDidData — Data element within a DID. Specifies the data type, byte offset, "
        "read/write function references, and scaling information."
    ),
    "DcmDspDtcDid": (
        "DcmDspDtcDid — DID associated with a DTC freeze-frame record. "
        "Referenced from DcmDspDtcAttributes."
    ),
    "DcmDspSecurity": (
        "DcmDspSecurity — Security level definition for SecurityAccess (0x27). "
        "Configures seed/key sizes, attempt counters, and delay times. ISO 14229-1 §9.4."
    ),
    "DcmDspSession": (
        "DcmDspSession — Diagnostic session definition for DiagnosticSessionControl (0x10). "
        "Configures P2ServerMax and P2*ServerMax timing parameters. ISO 14229-1 §9.2."
    ),
    "DcmDslProtocolRow": (
        "DcmDslProtocolRow — DSL (Diagnostic Service Layer) protocol row. "
        "Groups a protocol type with its connection configuration."
    ),
    "DcmDslConnection": (
        "DcmDslConnection — A single client connection within a DcmDslProtocolRow. "
        "Specifies the physical and functional addressing PDUs."
    ),
    "DemDTC": (
        "DemDTC — Diagnostic Trouble Code definition in the DEM (Diagnostic Event Manager). "
        "Contains the 24-bit DTC value and attributes per ISO 14229-1 §11."
    ),
    "DemEventParameter": (
        "DemEventParameter — Links a diagnostic event to its DTC and debounce configuration. "
        "Each event maps to one DemDTC."
    ),
    "DemDTCAttributes": (
        "DemDTCAttributes — Attributes of a DTC: severity, priority, kind (emission/non-emission), "
        "aging configuration."
    ),
    "CanTpChannel": (
        "CanTpChannel — CAN Transport Protocol channel (ISO 15765-2). "
        "Configures BS, STmin, N_Ar/N_Br/N_Cr/N_As/N_Bs/N_Cs timeouts, and addressing format."
    ),
    "CanTpRxNPdu": (
        "CanTpRxNPdu — CAN TP receive N-PDU (Network Protocol Data Unit). "
        "Defines the CAN identifier used for reception."
    ),
    "CanTpTxNPdu": (
        "CanTpTxNPdu — CAN TP transmit N-PDU. "
        "Defines the CAN identifier used for transmission."
    ),
    "SHORT-NAME": (
        "SHORT-NAME — Mandatory identifier element present in all AUTOSAR containers. "
        "Must be unique within its parent scope."
    ),
    "LONG-NAME": (
        "LONG-NAME — Optional human-readable name element. "
        "May contain a language attribute (xml:lang)."
    ),
    "CATEGORY": (
        "CATEGORY — Optional category string classifying the element. "
        "Semantics depend on the enclosing container."
    ),
    "ADMIN-DATA": (
        "ADMIN-DATA — Administrative metadata block. "
        "Contains versioning, documentation, and language annotations."
    ),
}

# ---------------------------------------------------------------------------
# Document state cache
# ---------------------------------------------------------------------------

_document_cache: Dict[str, Optional[object]] = {}


# ---------------------------------------------------------------------------
# Language server class
# ---------------------------------------------------------------------------


class UdsArxmlLanguageServer(LanguageServer):
    """LSP server that provides ARXML/UDS-aware completions and hover info."""

    def __init__(self) -> None:
        if not _HAS_PYGLS:
            raise ImportError(
                "pygls is required for LSP support. "
                "Install it with: pip install udsxml2tex[lsp]"
            )
        super().__init__("udsxml2tex-lsp", "v1.0")


if _HAS_PYGLS:
    server = UdsArxmlLanguageServer()

    # ------------------------------------------------------------------
    # Text document event handlers
    # ------------------------------------------------------------------

    @server.feature(lsp.TEXT_DOCUMENT_DID_OPEN)
    def did_open(ls: UdsArxmlLanguageServer, params: lsp.DidOpenTextDocumentParams) -> None:
        """Parse the opened ARXML file and cache the result."""
        uri = params.text_document.uri
        text = params.text_document.text
        _parse_and_cache(ls, uri, text)

    @server.feature(lsp.TEXT_DOCUMENT_DID_CHANGE)
    def did_change(ls: UdsArxmlLanguageServer, params: lsp.DidChangeTextDocumentParams) -> None:
        """Re-parse the changed ARXML file and update the cache."""
        uri = params.text_document.uri
        for change in params.content_changes:
            text = change.text
        _parse_and_cache(ls, uri, text)

    @server.feature(
        lsp.TEXT_DOCUMENT_COMPLETION,
        lsp.CompletionOptions(trigger_characters=["<", " ", "\n"]),
    )
    def completions(
        ls: UdsArxmlLanguageServer,
        params: lsp.CompletionParams,
    ) -> lsp.CompletionList:
        """Return ARXML element name completions."""
        items = [
            lsp.CompletionItem(
                label=name,
                kind=lsp.CompletionItemKind.Keyword,
                detail="ARXML element",
                documentation=ARXML_ELEMENT_DOCS.get(name, ""),
            )
            for name in ARXML_COMPLETIONS
        ]
        return lsp.CompletionList(is_incomplete=False, items=items)

    @server.feature(lsp.TEXT_DOCUMENT_HOVER)
    def hover(
        ls: UdsArxmlLanguageServer,
        params: lsp.HoverParams,
    ) -> Optional[lsp.Hover]:
        """Show documentation for a known ARXML element under the cursor."""
        uri = params.text_document.uri
        doc = ls.workspace.get_text_document(uri)
        line_text = doc.lines[params.position.line] if doc.lines else ""
        word = _word_at_position(line_text, params.position.character)
        doc_string = ARXML_ELEMENT_DOCS.get(word)
        if doc_string is None:
            return None
        return lsp.Hover(
            contents=lsp.MarkupContent(
                kind=lsp.MarkupKind.Markdown,
                value=f"**{word}**\n\n{doc_string}",
            )
        )

else:
    # Provide a module-level stub so imports don't raise at import time.
    server = None  # type: ignore[assignment]


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _parse_and_cache(ls: object, uri: str, text: str) -> None:
    """Attempt to parse *text* as a UDS ARXML document and store in cache."""
    try:
        from udsxml2tex.parser import parse_arxml_string  # type: ignore[import]

        spec = parse_arxml_string(text)
        _document_cache[uri] = spec
    except Exception:
        # Partial/invalid ARXML is expected during editing; store None.
        _document_cache[uri] = None


def _word_at_position(line: str, character: int) -> str:
    """Extract the identifier word that spans *character* in *line*."""
    start = character
    while start > 0 and (line[start - 1].isalnum() or line[start - 1] in "-_"):
        start -= 1
    end = character
    while end < len(line) and (line[end].isalnum() or line[end] in "-_"):
        end += 1
    return line[start:end]


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main(args: Optional[List[str]] = None) -> int:
    """Start the udsxml2tex LSP server.

    Parameters
    ----------
    args:
        Command-line arguments. Defaults to sys.argv[1:].

    Returns
    -------
    int
        Exit code (0 = success, 1 = error).
    """
    import argparse

    parser = argparse.ArgumentParser(description="udsxml2tex LSP server")
    parser.add_argument("--stdio", action="store_true", default=True)
    parser.add_argument("--tcp", action="store_true")
    parser.add_argument("--port", type=int, default=2087)
    parsed = parser.parse_args(args)

    if not _HAS_PYGLS:
        print("pygls is required: pip install udsxml2tex[lsp]")
        return 1

    if parsed.tcp:
        server.start_tcp("127.0.0.1", parsed.port)
    else:
        server.start_io()

    return 0


if __name__ == "__main__":
    import sys

    sys.exit(main())
