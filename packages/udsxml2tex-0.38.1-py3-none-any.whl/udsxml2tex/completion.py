"""Shell completion script generation for udsxml2tex."""

from __future__ import annotations

__all__ = [
    "generate_bash_completion",
    "generate_zsh_completion",
    "generate_fish_completion",
    "print_completion",
]


def generate_bash_completion() -> str:
    """Return a complete bash completion script for the udsxml2tex command."""
    return r"""# bash completion for udsxml2tex
# Source this file or place it in /etc/bash_completion.d/udsxml2tex
# or ~/.bash_completion.d/udsxml2tex

_udsxml2tex() {
    local cur prev words cword
    _init_completion || return

    local boolean_flags=(
        --pdf --html --dry-run --verbose --interactive --watch
        --validate --serve -v -I
    )

    case "${prev}" in
        -o|--output)
            # Complete .tex, .html, and .md files
            COMPREPLY=( $(compgen -f -X '!*.@(tex|html|md)' -- "${cur}") )
            compopt -o plusdirs 2>/dev/null
            return
            ;;
        --template-dir)
            # Complete directories only
            COMPREPLY=( $(compgen -d -- "${cur}") )
            compopt -o nospace 2>/dev/null
            return
            ;;
        --template)
            # Suggest known template names
            COMPREPLY=( $(compgen -W 'uds_spec.tex.j2 uds_spec.html.j2' -- "${cur}") )
            return
            ;;
        --dem)
            # Complete .arxml files
            COMPREPLY=( $(compgen -f -X '!*.arxml' -- "${cur}") )
            compopt -o plusdirs 2>/dev/null
            return
            ;;
        --c-source)
            # Complete C files or directories
            COMPREPLY=( $(compgen -f -X '!*.@(c|h|cpp|cc)' -- "${cur}") )
            compopt -o plusdirs 2>/dev/null
            return
            ;;
        --format)
            COMPREPLY=( $(compgen -W 'tex html md rst csv yaml json' -- "${cur}") )
            return
            ;;
        --lang)
            COMPREPLY=( $(compgen -W 'en ja' -- "${cur}") )
            return
            ;;
        --filter-dids|--filter-services|--filter-dtcs)
            # Free text — no completion
            return
            ;;
        --generate-completion)
            COMPREPLY=( $(compgen -W 'bash zsh fish' -- "${cur}") )
            return
            ;;
        --config)
            COMPREPLY=( $(compgen -f -X '!*.json' -- "${cur}") )
            compopt -o plusdirs 2>/dev/null
            return
            ;;
        --ecu-name)
            # Free text — no completion
            return
            ;;
    esac

    if [[ "${cur}" == -* ]]; then
        local opts=(
            -o --output
            --ecu-name
            --template-dir
            --template
            --pdf
            --html
            --dem
            --c-source
            --dry-run
            --verbose --version
            --interactive
            --config
            --format
            --lang
            --filter-dids
            --filter-services
            --filter-dtcs
            --generate-completion
            --watch
            --validate
            --serve
            -v -I
        )
        COMPREPLY=( $(compgen -W "${opts[*]}" -- "${cur}") )
        return
    fi

    # Default: complete positional arguments as .arxml files
    COMPREPLY=( $(compgen -f -X '!*.arxml' -- "${cur}") )
    compopt -o plusdirs 2>/dev/null
}

complete -F _udsxml2tex udsxml2tex
"""


def generate_zsh_completion() -> str:
    """Return a complete zsh completion script (_udsxml2tex style)."""
    return r"""#compdef udsxml2tex
# zsh completion for udsxml2tex
# Place this file as _udsxml2tex somewhere on your $fpath, e.g.:
#   ~/.zsh/completions/_udsxml2tex
# Then run: autoload -Uz compinit && compinit

_udsxml2tex() {
    local context state state_descr line
    typeset -A opt_args

    _arguments -C \
        '(-I --interactive)'{-I,--interactive}'[Launch interactive mode]' \
        '--config[Load a JSON config file]:config file:_files -g "*.json"' \
        '(-o --output)'{-o,--output}'[Output file path]:output file:_files -g "*.{tex,html,md}"' \
        '--ecu-name[Override ECU name in document]:ECU name:' \
        '--template-dir[Directory with custom Jinja2 templates]:template directory:_directories' \
        '--template[Template file name]:template name:(uds_spec.tex.j2 uds_spec.html.j2)' \
        '--pdf[Compile generated .tex to PDF]' \
        '--html[Generate HTML output]' \
        '--dem[Path to DEM ARXML file]:DEM arxml file:_files -g "*.arxml"' \
        '*--c-source[C source file or directory for DID variable scanning]:C source:_files -g "*.{c,h,cpp,cc}"' \
        '--dry-run[Parse ARXML and print summary without generating files]' \
        '(-v --verbose)'{-v,--verbose}'[Enable verbose logging output]' \
        '--version[Show version and exit]' \
        '--format[Output format]:format:(tex html md rst csv yaml json)' \
        '--lang[Output language]:language:(en ja)' \
        '--filter-dids[Filter DIDs by pattern]:DID filter pattern:' \
        '--filter-services[Filter services by pattern]:service filter pattern:' \
        '--filter-dtcs[Filter DTCs by pattern]:DTC filter pattern:' \
        '--generate-completion[Generate shell completion script]:shell:(bash zsh fish)' \
        '--watch[Watch input files for changes and regenerate]' \
        '--validate[Validate ARXML without generating output]' \
        '--serve[Start a local HTTP server to preview HTML output]' \
        '*:input ARXML file:_files -g "*.arxml"'
}

_udsxml2tex "$@"
"""


def generate_fish_completion() -> str:
    """Return a fish shell completion script for udsxml2tex."""
    return """\
# fish completion for udsxml2tex
# Place this file as ~/.config/fish/completions/udsxml2tex.fish

# Positional arguments: .arxml files
complete -c udsxml2tex -n '__fish_no_arguments' -F -a '*.arxml'

# -I / --interactive
complete -c udsxml2tex -s I -l interactive -d 'Launch interactive mode'

# --config
complete -c udsxml2tex -l config -d 'Load a JSON config file' -F -a '*.json'

# -o / --output
complete -c udsxml2tex -s o -l output -d 'Output file path (.tex/.html/.md)' -F -a '*.tex' -a '*.html' -a '*.md'

# --ecu-name
complete -c udsxml2tex -l ecu-name -d 'Override ECU name in generated document' -x

# --template-dir
complete -c udsxml2tex -l template-dir -d 'Directory containing custom Jinja2 templates' -F

# --template
complete -c udsxml2tex -l template -d 'Template file name' -x -a 'uds_spec.tex.j2\tuds_spec.html.j2'

# --pdf
complete -c udsxml2tex -l pdf -d 'Compile generated .tex to PDF'

# --html
complete -c udsxml2tex -l html -d 'Generate HTML output'

# --dem
complete -c udsxml2tex -l dem -d 'Path to DEM ARXML file' -F -a '*.arxml'

# --c-source
complete -c udsxml2tex -l c-source -d 'C source file or directory for DID variable scanning' -F -a '*.c' -a '*.h' -a '*.cpp' -a '*.cc'

# --dry-run
complete -c udsxml2tex -l dry-run -d 'Parse ARXML and print summary without generating files'

# -v / --verbose
complete -c udsxml2tex -s v -l verbose -d 'Enable verbose logging output'

# --version
complete -c udsxml2tex -l version -d 'Show version and exit'

# --format
complete -c udsxml2tex -l format -d 'Output format' -x -a 'tex\tLaTeX html\tHTML md\tMarkdown rst\treStructuredText csv\tCSV yaml\tYAML json\tJSON'

# --lang
complete -c udsxml2tex -l lang -d 'Output language' -x -a 'en\tEnglish ja\tJapanese'

# --filter-dids
complete -c udsxml2tex -l filter-dids -d 'Filter DIDs by pattern' -x

# --filter-services
complete -c udsxml2tex -l filter-services -d 'Filter services by pattern' -x

# --filter-dtcs
complete -c udsxml2tex -l filter-dtcs -d 'Filter DTCs by pattern' -x

# --generate-completion
complete -c udsxml2tex -l generate-completion -d 'Generate shell completion script' -x -a 'bash\tBash completion zsh\tZsh completion fish\tFish completion'

# --watch
complete -c udsxml2tex -l watch -d 'Watch input files for changes and regenerate'

# --validate
complete -c udsxml2tex -l validate -d 'Validate ARXML without generating output'

# --serve
complete -c udsxml2tex -l serve -d 'Start a local HTTP server to preview HTML output'
"""


def print_completion(shell: str) -> None:
    """Print the shell completion script for *shell* to stdout.

    Args:
        shell: One of ``"bash"``, ``"zsh"``, or ``"fish"``.

    Raises:
        ValueError: If *shell* is not a recognised shell name.
    """
    generators = {
        "bash": generate_bash_completion,
        "zsh": generate_zsh_completion,
        "fish": generate_fish_completion,
    }
    if shell not in generators:
        raise ValueError(
            f"Unknown shell {shell!r}. Supported shells: {', '.join(sorted(generators))}"
        )
    print(generators[shell](), end="")
