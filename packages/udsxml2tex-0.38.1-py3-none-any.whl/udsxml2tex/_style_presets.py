"""Document style preset registry.

A "style preset" is a named bundle of presentation parameters that the
LaTeX/HTML generator consults when rendering: header layout, title-page
elements, color scheme, optional approval/signature box, optional logo,
and similar customisation knobs that do NOT affect the diagnostic data.

All bundled presets are generic — no vendor/OEM branding. Users supply
their own logo, company name, and similar identity bits through a YAML
config (:func:`load_header_config`).

YAML schema (header config)
---------------------------

.. code-block:: yaml

    # header_config_sample.yaml
    company_name: ExampleManufacturer
    document_title: UDS Specification
    document_title_secondary: ""
    author: Author Name
    department: Department / Team Label
    issue_number: "1.0"
    date: ""                            # empty -> \\today
    document_number: "DOC-2026-001"
    show_approval_box: true
    show_logo: false
    logo_path: ""                       # e.g. "your_logo.pdf"
    footer_text: "Internal use only"
    vehicle_program: ExampleVehicle Program
    system_label: ExampleECU

Bundled presets
---------------

* ``minimal`` — minimal one-page-style, no header, no logo, no approval
  box; useful for quick previews.
* ``formal`` — formal engineering doc with a boxed header showing issue,
  date, page, and responsible department; optional logo and approval
  box drawn from :class:`HeaderConfig`.
* ``detailed`` — formal style plus landscape big tables and change
  tracking macros (``\\SpecUpdate``, ``\\ImpleMatch``, ``\\TypoFix``).

Public API
----------

* :func:`list_presets` — names of registered presets.
* :func:`get_preset` — fetch a preset by name (``KeyError`` on miss).
* :func:`register_preset` — add or replace a preset.
* :func:`load_header_config` — read a YAML header config from disk.
* :func:`empty_header_config` — return defaults (no logo, no approval
  box, no company name).
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

__all__ = [
    "HeaderConfig",
    "StylePreset",
    "list_presets",
    "get_preset",
    "register_preset",
    "load_header_config",
    "empty_header_config",
]


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------


@dataclass
class HeaderConfig:
    """User-configurable header / title page details.

    All defaults are generic placeholders — the bundled package contains
    no OEM / vendor branding. A user customises these via a YAML config
    loaded with :func:`load_header_config`.
    """

    company_name: str = ""
    """Display name of the issuing company, e.g. ``"ExampleManufacturer"``."""

    document_title: str = "UDS Specification"
    """Main document title shown on the title page and header."""

    document_title_secondary: str = ""
    """Optional secondary title for bilingual rendering (e.g. JP/EN)."""

    author: str = ""
    """Document author display name. Used in the boxed header and the
    optional approval box."""

    department: str = ""
    """Issuing department / team label. Rendered as "Responsible" in the
    boxed header."""

    issue_number: str = "1.0"
    """Document issue / amendment number, e.g. ``"1.0"``."""

    date: str = ""
    """Document date. Empty -> ``\\today`` at compile time."""

    document_number: str = ""
    """Optional OEM document tracking number."""

    show_approval_box: bool = False
    """Render a 3-column "Approval / Check / Author" sign-off table on the
    title page."""

    show_logo: bool = False
    """Render the logo (if a valid :attr:`logo_path` is supplied)."""

    logo_path: str = ""
    """Relative or absolute path to a logo file (``.pdf`` / ``.png``). If
    empty while :attr:`show_logo` is ``True``, the logo is silently
    skipped."""

    footer_text: str = ""
    """Tiny footer string, e.g. ``"Internal use only"``."""

    vehicle_program: str = ""
    """Optional vehicle / platform programme label."""

    system_label: str = ""
    """Optional system / ECU label rendered on the title page."""


@dataclass
class StylePreset:
    """A complete style preset bundle.

    Holds the rendering knobs that the LaTeX / HTML generator consults
    when laying out the document. Pairs with :class:`HeaderConfig`,
    which carries the *content* of the header (the preset chooses the
    *layout*).
    """

    name: str
    """Unique preset name (registry key)."""

    description: str
    """One-line human-readable description."""

    page_layout: str = "a4paper"
    """LaTeX paper size, e.g. ``"a4paper"``, ``"letterpaper"``."""

    font_family: str = "default"
    """Font family hint: ``"default"`` | ``"serif"`` | ``"sans"``."""

    color_scheme: str = "default"
    """Color scheme hint: ``"default"`` | ``"gray"`` | ``"blue"``."""

    header_style: str = "simple"
    """Header layout: ``"simple"`` | ``"boxed"`` | ``"custom"``."""

    use_landscape_tables: bool = True
    """Render very wide tables (e.g. SID / DID overviews) in landscape."""

    show_revision_history: bool = True
    """Include a revision history section."""

    show_table_of_contents: bool = True
    """Render a table of contents."""

    enable_change_tracking_macros: bool = False
    """Emit / activate the change-tracking macros ``\\SpecUpdate``,
    ``\\ImpleMatch``, ``\\TypoFix`` for inline diff annotations."""


# ---------------------------------------------------------------------------
# Bundled preset registry
# ---------------------------------------------------------------------------


_PRESETS: dict[str, StylePreset] = {
    "minimal": StylePreset(
        name="minimal",
        description=(
            "Minimal one-page-style — no header, no logo, no approval box"
        ),
        header_style="simple",
        show_revision_history=False,
        enable_change_tracking_macros=False,
    ),
    "formal": StylePreset(
        name="formal",
        description=(
            "Formal engineering doc — header with issue/date/page, "
            "optional logo and approval box"
        ),
        header_style="boxed",
        enable_change_tracking_macros=True,
    ),
    "detailed": StylePreset(
        name="detailed",
        description=(
            "Detailed spec — formal style plus landscape big tables and "
            "change tracking macros enabled"
        ),
        header_style="boxed",
        use_landscape_tables=True,
        enable_change_tracking_macros=True,
    ),
}


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def list_presets() -> list[str]:
    """Return the names of all registered presets in registration order."""
    return list(_PRESETS.keys())


def get_preset(name: str) -> StylePreset:
    """Return the named preset.

    :param name: registry key (e.g. ``"minimal"``).
    :raises KeyError: if ``name`` is not registered.
    """
    if name not in _PRESETS:
        raise KeyError(
            f"unknown style preset {name!r}; "
            f"registered: {sorted(_PRESETS.keys())}"
        )
    return _PRESETS[name]


def register_preset(preset: StylePreset) -> None:
    """Add or replace a preset by name.

    :param preset: a :class:`StylePreset` to register; overwrites any
        existing entry with the same :attr:`StylePreset.name`.
    """
    if not isinstance(preset, StylePreset):
        raise TypeError(
            f"expected StylePreset, got {type(preset).__name__}"
        )
    if not preset.name:
        raise ValueError("preset.name must be a non-empty string")
    _PRESETS[preset.name] = preset


def empty_header_config() -> HeaderConfig:
    """Return a :class:`HeaderConfig` with all defaults.

    No logo, no approval box, no company name — safe to feed to the
    generator when the user has not customised anything yet.
    """
    return HeaderConfig()


def load_header_config(path: str | Path) -> HeaderConfig:
    """Load a YAML header config from ``path``.

    :param path: filesystem path to the YAML file.
    :returns: populated :class:`HeaderConfig`.
    :raises ImportError: if PyYAML is not installed (install via
        ``pip install udsxml2tex[yaml]``).
    :raises FileNotFoundError: when ``path`` does not exist.
    :raises ValueError: if the YAML top level is not a mapping.
    """
    try:
        import yaml  # lazy import; PyYAML lives in the [yaml] / [web] extras
    except ImportError as exc:  # pragma: no cover - exercised only without PyYAML
        raise ImportError(
            "PyYAML is required to load a header config. "
            "Install it via `pip install udsxml2tex[yaml]`."
        ) from exc

    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"header config YAML not found: {p}")

    with p.open("r", encoding="utf-8") as fh:
        raw = yaml.safe_load(fh) or {}

    if not isinstance(raw, dict):
        raise ValueError(
            "header config YAML must be a mapping at the top level, "
            f"got {type(raw).__name__}"
        )

    return HeaderConfig(
        company_name=str(raw.get("company_name", "") or ""),
        document_title=str(raw.get("document_title", "UDS Specification") or "UDS Specification"),
        document_title_secondary=str(raw.get("document_title_secondary", "") or ""),
        author=str(raw.get("author", "") or ""),
        department=str(raw.get("department", "") or ""),
        issue_number=str(raw.get("issue_number", "1.0") or "1.0"),
        date=str(raw.get("date", "") or ""),
        document_number=str(raw.get("document_number", "") or ""),
        show_approval_box=bool(raw.get("show_approval_box", False)),
        show_logo=bool(raw.get("show_logo", False)),
        logo_path=str(raw.get("logo_path", "") or ""),
        footer_text=str(raw.get("footer_text", "") or ""),
        vehicle_program=str(raw.get("vehicle_program", "") or ""),
        system_label=str(raw.get("system_label", "") or ""),
    )


# ---------------------------------------------------------------------------
# Internal helper for the generator
# ---------------------------------------------------------------------------


def _resolve_preset(value: str | StylePreset | None) -> StylePreset | None:
    """Return a :class:`StylePreset` from a name or pass-through an object.

    Returns ``None`` if ``value`` is ``None``. Used by
    :class:`udsxml2tex.generator.TexGenerator` to accept both forms.
    """
    if value is None:
        return None
    if isinstance(value, StylePreset):
        return value
    if isinstance(value, str):
        return get_preset(value)
    raise TypeError(
        f"style_preset must be str | StylePreset | None, got {type(value).__name__}"
    )
