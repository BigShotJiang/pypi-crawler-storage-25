"""ISO 14229-1 consistency validation for UDS specifications."""

from __future__ import annotations

from dataclasses import dataclass, field

from udsxml2tex.models import UdsSpecification


@dataclass
class ValidationIssue:
    """A single validation finding."""

    severity: str  # "error" | "warning" | "info"
    category: str
    message: str
    item_id: str = ""


@dataclass
class ValidationResult:
    """Collection of validation findings for a UdsSpecification."""

    issues: list[ValidationIssue] = field(default_factory=list)

    def has_errors(self) -> bool:
        """Return True if any issue has severity 'error'."""
        return any(i.severity == "error" for i in self.issues)

    def has_warnings(self) -> bool:
        """Return True if any issue has severity 'warning'."""
        return any(i.severity == "warning" for i in self.issues)

    def summary(self) -> str:
        """Return a human-readable count string, e.g. '3 errors, 2 warnings, 1 info'."""
        errors = sum(1 for i in self.issues if i.severity == "error")
        warnings = sum(1 for i in self.issues if i.severity == "warning")
        infos = sum(1 for i in self.issues if i.severity == "info")
        parts = []
        if errors:
            parts.append(f"{errors} error{'s' if errors != 1 else ''}")
        if warnings:
            parts.append(f"{warnings} warning{'s' if warnings != 1 else ''}")
        if infos:
            parts.append(f"{infos} info")
        return ", ".join(parts) if parts else "no issues"

    def __len__(self) -> int:
        return len(self.issues)


MANDATORY_NRCS: dict[int, list[int]] = {
    0x10: [0x12, 0x13, 0x7F],       # DiagnosticSessionControl
    0x11: [0x12, 0x13, 0x7F],       # ECUReset
    0x14: [0x13, 0x22, 0x31],       # ClearDiagnosticInformation
    0x19: [0x12, 0x13, 0x31],       # ReadDTCInformation
    0x22: [0x13, 0x22, 0x31],       # ReadDataByIdentifier
    0x27: [0x12, 0x13, 0x24, 0x35, 0x36, 0x37],  # SecurityAccess
    0x28: [0x12, 0x13, 0x22],       # CommunicationControl
    0x2E: [0x13, 0x22, 0x31, 0x33], # WriteDataByIdentifier
    0x31: [0x12, 0x13, 0x22, 0x31], # RoutineControl
    0x34: [0x13, 0x22, 0x31],       # RequestDownload
    0x35: [0x13, 0x22, 0x31],       # RequestUpload
    0x36: [0x13, 0x24, 0x72, 0x73], # TransferData
    0x37: [0x13, 0x24],             # RequestTransferExit
    0x3E: [0x12, 0x13],             # TesterPresent
    0x85: [0x12, 0x13, 0x22],       # ControlDTCSetting
}


class UdsValidator:
    """Validates a UdsSpecification for ISO 14229-1 consistency."""

    def validate(self, spec: UdsSpecification) -> ValidationResult:
        """Run all checks and return the combined ValidationResult."""
        result = ValidationResult()
        issues = result.issues

        # Build lookup sets used by several checks
        session_names: set[str] = {s.short_name for s in spec.sessions}
        security_level_names: set[str] = {sl.short_name for sl in spec.security_levels}

        self._check_duplicate_did_ids(spec, issues)
        self._check_duplicate_dtc_ids(spec, issues)
        self._check_duplicate_routine_ids(spec, issues)
        self._check_duplicate_session_ids(spec, issues)
        self._check_duplicate_security_levels(spec, issues)
        self._check_did_byte_overlap(spec, issues)
        self._check_unknown_session_refs(spec, issues, session_names)
        self._check_unknown_security_level_refs(spec, issues, security_level_names)
        self._check_security_access_level_parity(spec, issues)
        self._check_missing_dtc_descriptions(spec, issues)
        self._check_p2_timeout_sanity(spec, issues)
        self._check_empty_did_list(spec, issues)
        self._check_service_without_session(spec, issues)
        self._check_did_total_length_mismatch(spec, issues)
        self._check_dcm_dem_consistency(spec, issues)
        self._check_nrc_completeness(spec, issues)
        self._check_memory_range_overlap(spec, issues)

        return result

    # ------------------------------------------------------------------
    # Individual check helpers
    # ------------------------------------------------------------------

    def _check_duplicate_did_ids(
        self, spec: UdsSpecification, issues: list[ValidationIssue]
    ) -> None:
        seen: dict[int, str] = {}
        for did in spec.dids:
            if did.did_id in seen:
                issues.append(ValidationIssue(
                    severity="error",
                    category="dids",
                    message=(
                        f"Duplicate DID ID 0x{did.did_id:04X}: "
                        f"'{seen[did.did_id]}' and '{did.short_name}'"
                    ),
                    item_id=f"0x{did.did_id:04X}",
                ))
            else:
                seen[did.did_id] = did.short_name

    def _check_duplicate_dtc_ids(
        self, spec: UdsSpecification, issues: list[ValidationIssue]
    ) -> None:
        seen: dict[int, str] = {}
        for dtc in spec.dtcs:
            if dtc.dtc_id in seen:
                issues.append(ValidationIssue(
                    severity="error",
                    category="dtcs",
                    message=(
                        f"Duplicate DTC ID 0x{dtc.dtc_id:06X}: "
                        f"'{seen[dtc.dtc_id]}' and '{dtc.short_name}'"
                    ),
                    item_id=f"0x{dtc.dtc_id:06X}",
                ))
            else:
                seen[dtc.dtc_id] = dtc.short_name

    def _check_duplicate_routine_ids(
        self, spec: UdsSpecification, issues: list[ValidationIssue]
    ) -> None:
        seen: dict[int, str] = {}
        for routine in spec.routines:
            if routine.routine_id in seen:
                issues.append(ValidationIssue(
                    severity="error",
                    category="routines",
                    message=(
                        f"Duplicate Routine ID 0x{routine.routine_id:04X}: "
                        f"'{seen[routine.routine_id]}' and '{routine.short_name}'"
                    ),
                    item_id=f"0x{routine.routine_id:04X}",
                ))
            else:
                seen[routine.routine_id] = routine.short_name

    def _check_duplicate_session_ids(
        self, spec: UdsSpecification, issues: list[ValidationIssue]
    ) -> None:
        seen: dict[int, str] = {}
        for session in spec.sessions:
            if session.session_id in seen:
                issues.append(ValidationIssue(
                    severity="error",
                    category="sessions",
                    message=(
                        f"Duplicate Session ID 0x{session.session_id:02X}: "
                        f"'{seen[session.session_id]}' and '{session.short_name}'"
                    ),
                    item_id=f"0x{session.session_id:02X}",
                ))
            else:
                seen[session.session_id] = session.short_name

    def _check_duplicate_security_levels(
        self, spec: UdsSpecification, issues: list[ValidationIssue]
    ) -> None:
        seen: dict[int, str] = {}
        for sl in spec.security_levels:
            if sl.security_level in seen:
                issues.append(ValidationIssue(
                    severity="error",
                    category="security_levels",
                    message=(
                        f"Duplicate Security Level 0x{sl.security_level:02X}: "
                        f"'{seen[sl.security_level]}' and '{sl.short_name}'"
                    ),
                    item_id=f"0x{sl.security_level:02X}",
                ))
            else:
                seen[sl.security_level] = sl.short_name

    def _check_did_byte_overlap(
        self, spec: UdsSpecification, issues: list[ValidationIssue]
    ) -> None:
        for did in spec.dids:
            elements = did.data_elements
            if len(elements) < 2:
                continue
            # Build list of (start_byte, end_byte_exclusive, name) for each element
            ranges: list[tuple[int, int, str]] = []
            for elem in elements:
                start = elem.byte_position
                size_bytes = max(1, (elem.bit_size + 7) // 8)
                end = start + size_bytes  # exclusive
                ranges.append((start, end, elem.short_name))

            # Check all pairs
            for i in range(len(ranges)):
                for j in range(i + 1, len(ranges)):
                    s1, e1, n1 = ranges[i]
                    s2, e2, n2 = ranges[j]
                    if s1 < e2 and s2 < e1:
                        issues.append(ValidationIssue(
                            severity="warning",
                            category="dids",
                            message=(
                                f"DID '{did.short_name}' (0x{did.did_id:04X}): "
                                f"data elements '{n1}' (bytes {s1}–{e1 - 1}) and "
                                f"'{n2}' (bytes {s2}–{e2 - 1}) overlap"
                            ),
                            item_id=f"0x{did.did_id:04X}",
                        ))

    def _check_unknown_session_refs(
        self,
        spec: UdsSpecification,
        issues: list[ValidationIssue],
        session_names: set[str],
    ) -> None:
        for service in spec.services:
            for ref in service.supported_sessions:
                if ref not in session_names:
                    issues.append(ValidationIssue(
                        severity="warning",
                        category="services",
                        message=(
                            f"Service '{service.short_name}' references unknown session "
                            f"'{ref}'"
                        ),
                        item_id=f"0x{service.service_id:02X}",
                    ))

    def _check_unknown_security_level_refs(
        self,
        spec: UdsSpecification,
        issues: list[ValidationIssue],
        security_level_names: set[str],
    ) -> None:
        for service in spec.services:
            for ref in service.required_security_levels:
                if ref not in security_level_names:
                    issues.append(ValidationIssue(
                        severity="warning",
                        category="services",
                        message=(
                            f"Service '{service.short_name}' references unknown security "
                            f"level '{ref}'"
                        ),
                        item_id=f"0x{service.service_id:02X}",
                    ))

    def _check_security_access_level_parity(
        self, spec: UdsSpecification, issues: list[ValidationIssue]
    ) -> None:
        """ISO 14229-1 §9.4.2: requestSeed sub-function IDs must be odd."""
        for sl in spec.security_levels:
            if sl.security_level % 2 == 0:
                issues.append(ValidationIssue(
                    severity="info",
                    category="security_levels",
                    message=(
                        f"Security level '{sl.short_name}' has an even security_level value "
                        f"(0x{sl.security_level:02X}); ISO 14229-1 §9.4.2 requires odd values "
                        f"for requestSeed sub-function IDs"
                    ),
                    item_id=f"0x{sl.security_level:02X}",
                ))

    def _check_missing_dtc_descriptions(
        self, spec: UdsSpecification, issues: list[ValidationIssue]
    ) -> None:
        for dtc in spec.dtcs:
            if not dtc.description:
                issues.append(ValidationIssue(
                    severity="info",
                    category="dtcs",
                    message=(
                        f"DTC '{dtc.short_name}' (0x{dtc.dtc_id:06X}) has no description"
                    ),
                    item_id=f"0x{dtc.dtc_id:06X}",
                ))

    def _check_p2_timeout_sanity(
        self, spec: UdsSpecification, issues: list[ValidationIssue]
    ) -> None:
        """ISO 14229-2: p2_server_max should be less than p2_star_server_max."""
        for session in spec.sessions:
            if session.p2_server_max > session.p2_star_server_max:
                issues.append(ValidationIssue(
                    severity="warning",
                    category="sessions",
                    message=(
                        f"Session '{session.short_name}': p2_server_max "
                        f"({session.p2_server_max}s) > p2_star_server_max "
                        f"({session.p2_star_server_max}s); expected p2 < p2*"
                    ),
                    item_id=f"0x{session.session_id:02X}",
                ))

    def _check_empty_did_list(
        self, spec: UdsSpecification, issues: list[ValidationIssue]
    ) -> None:
        if not spec.dids:
            issues.append(ValidationIssue(
                severity="warning",
                category="dids",
                message="No DIDs are defined in the specification",
            ))

    def _check_service_without_session(
        self, spec: UdsSpecification, issues: list[ValidationIssue]
    ) -> None:
        for service in spec.services:
            if not service.supported_sessions:
                issues.append(ValidationIssue(
                    severity="warning",
                    category="services",
                    message=(
                        f"Service '{service.short_name}' (0x{service.service_id:02X}) "
                        f"has no supported sessions defined"
                    ),
                    item_id=f"0x{service.service_id:02X}",
                ))

    def _check_did_total_length_mismatch(
        self, spec: UdsSpecification, issues: list[ValidationIssue]
    ) -> None:
        for did in spec.dids:
            if did.total_byte_length <= 0 or not did.data_elements:
                continue
            computed = sum(max(1, (e.bit_size + 7) // 8) for e in did.data_elements)
            if computed != did.total_byte_length:
                issues.append(ValidationIssue(
                    severity="warning",
                    category="dids",
                    message=(
                        f"DID '{did.short_name}' (0x{did.did_id:04X}): "
                        f"total_byte_length={did.total_byte_length} but sum of "
                        f"data element sizes={computed}"
                    ),
                    item_id=f"0x{did.did_id:04X}",
                ))

    def _check_dcm_dem_consistency(
        self, spec: UdsSpecification, issues: list[ValidationIssue]
    ) -> None:
        """Check 5-1: DCM DtcDefinition list vs DEM DemDtcEntry list consistency."""
        if not spec.dtcs or not spec.dem_dtcs:
            return

        dem_values: set[int] = {dem_dtc.dtc_value for dem_dtc in spec.dem_dtcs}
        dcm_ids: set[int] = {dtc.dtc_id for dtc in spec.dtcs}

        for dtc in spec.dtcs:
            if dtc.dtc_id not in dem_values:
                issues.append(ValidationIssue(
                    severity="warning",
                    category="dtcs",
                    message=(
                        f"DCM DTC '{dtc.short_name}' (0x{dtc.dtc_id:06X}) "
                        f"has no matching DEM DemDTC entry"
                    ),
                ))

        for dem_dtc in spec.dem_dtcs:
            if dem_dtc.dtc_value not in dcm_ids:
                issues.append(ValidationIssue(
                    severity="info",
                    category="dtcs",
                    message=(
                        f"DEM DTC '{dem_dtc.short_name}' (0x{dem_dtc.dtc_value:06X}) "
                        f"has no corresponding DCM DtcDefinition"
                    ),
                ))

    def _check_nrc_completeness(
        self, spec: UdsSpecification, issues: list[ValidationIssue]
    ) -> None:
        """Check 5-3: ISO 14229-1 mandatory NRC codes per service."""
        for service in spec.services:
            if service.service_id not in MANDATORY_NRCS:
                continue
            if not service.nrc_list:
                continue
            configured: set[int] = {n.nrc_code for n in service.nrc_list}
            for nrc in MANDATORY_NRCS[service.service_id]:
                if nrc not in configured:
                    issues.append(ValidationIssue(
                        severity="info",
                        category="services",
                        item_id=f"0x{service.service_id:02X}",
                        message=(
                            f"Service '{service.short_name}' (0x{service.service_id:02X}) "
                            f"is missing mandatory NRC 0x{nrc:02X} per ISO 14229-1"
                        ),
                    ))

    def _check_memory_range_overlap(
        self, spec: UdsSpecification, issues: list[ValidationIssue]
    ) -> None:
        """Check 5-5: Overlapping memory ranges."""
        ranges = spec.memory_ranges
        for i in range(len(ranges)):
            r1 = ranges[i]
            if not (r1.end_address > r1.start_address):
                continue
            for j in range(i + 1, len(ranges)):
                r2 = ranges[j]
                if not (r2.end_address > r2.start_address):
                    continue
                if r1.start_address < r2.end_address and r2.start_address < r1.end_address:
                    issues.append(ValidationIssue(
                        severity="warning",
                        category="memory",
                        item_id=f"0x{r1.start_address:08X}",
                        message=(
                            f"Memory range '{r1.short_name}' "
                            f"(0x{r1.start_address:08X}–0x{r1.end_address:08X}) "
                            f"overlaps with '{r2.short_name}' "
                            f"(0x{r2.start_address:08X}–0x{r2.end_address:08X})"
                        ),
                    ))


def validate(spec: UdsSpecification) -> ValidationResult:
    """Convenience function: validate a UdsSpecification and return the result."""
    return UdsValidator().validate(spec)


__all__ = [
    "ValidationIssue",
    "ValidationResult",
    "UdsValidator",
    "validate",
]
