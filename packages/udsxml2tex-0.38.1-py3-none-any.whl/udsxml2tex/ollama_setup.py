"""Bootstrap a working local Ollama install for the Chat tab.

`udsxml2tex --bootstrap-ollama` runs the four-step pipeline that every user
otherwise has to perform by hand the first time they touch the Chat feature:

    1. Locate or download the Ollama binary (no sudo, no systemd).
    2. Start `ollama serve` if nothing is already listening on the target host.
    3. Pull the requested model unless it is already present.
    4. Print an LLM-config snippet the browser UI / CLI can use immediately.

The module deliberately avoids root, package managers, and the official
install.sh. We extract Ollama's released tarball under `~/.local/share/ollama`
and symlink the binary into `~/.local/bin/ollama` (already on PATH on most
Linux/macOS installs).

Linux and macOS only. Windows users see a pointer to the official installer.
"""

from __future__ import annotations

import json
import logging
import os
import platform
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Optional

logger = logging.getLogger(__name__)


# Default model and context. Both can be overridden from the CLI.
DEFAULT_MODEL = "qwen2.5:7b"
DEFAULT_CTX = 24576

# Pinned fallback when the GitHub API is unreachable. Bump occasionally.
_FALLBACK_VERSION = "v0.23.2"

_GITHUB_LATEST_API = "https://api.github.com/repos/ollama/ollama/releases/latest"
_GITHUB_RELEASE_BASE = "https://github.com/ollama/ollama/releases/download"

# Map (os, arch) -> archive filename inside a release.
_ARCHIVE_BY_PLATFORM = {
    ("linux", "x86_64"):  "ollama-linux-amd64.tar.zst",
    ("linux", "aarch64"): "ollama-linux-arm64.tar.zst",
    ("darwin", "x86_64"): "ollama-darwin.tgz",
    ("darwin", "arm64"):  "ollama-darwin.tgz",
}


@dataclass
class BootstrapResult:
    """Outcome of `bootstrap()`. Designed for both human and machine use."""

    ollama_path: Path
    serve_pid: Optional[int]
    serve_already_running: bool
    model: str
    model_already_present: bool
    ctx_length: int
    host: str
    port: int

    @property
    def base_url(self) -> str:
        return f"http://{self.host}:{self.port}/v1"


# ---------------------------------------------------------------------------
# Platform detection
# ---------------------------------------------------------------------------

def detect_platform() -> tuple[str, str]:
    """Return (os, arch). Raises RuntimeError on unsupported combinations.

    'os' is lowercased ('linux', 'darwin'). 'arch' is normalized to one of
    'x86_64', 'aarch64', 'arm64'. Windows is intentionally rejected — Ollama
    on Windows ships an .exe installer that needs admin and a different
    layout, so we'd rather direct users to https://ollama.com/download.
    """
    os_name = platform.system().lower()
    if os_name == "windows":
        raise RuntimeError(
            "Windows is not supported by --bootstrap-ollama. "
            "Install Ollama from https://ollama.com/download, then run "
            "`udsxml2tex --bootstrap-ollama` again to pull the model only."
        )
    if os_name not in ("linux", "darwin"):
        raise RuntimeError(f"Unsupported OS: {os_name!r}")

    machine = platform.machine().lower()
    # Normalize ARM aliases per OS.
    if os_name == "linux":
        if machine in ("amd64", "x86_64"):
            arch = "x86_64"
        elif machine in ("aarch64", "arm64"):
            arch = "aarch64"
        else:
            raise RuntimeError(f"Unsupported Linux arch: {machine!r}")
    else:  # darwin
        if machine in ("x86_64", "amd64"):
            arch = "x86_64"
        elif machine in ("arm64", "aarch64"):
            arch = "arm64"
        else:
            raise RuntimeError(f"Unsupported macOS arch: {machine!r}")
    return os_name, arch


# ---------------------------------------------------------------------------
# Binary detection / download
# ---------------------------------------------------------------------------

def find_ollama() -> Optional[Path]:
    """Return path to an existing `ollama` binary, or None."""
    found = shutil.which("ollama")
    return Path(found) if found else None


def _resolve_release_version() -> str:
    """Latest Ollama release tag, or the pinned fallback on network failure."""
    try:
        with urllib.request.urlopen(_GITHUB_LATEST_API, timeout=5) as resp:
            data = json.load(resp)
            tag = data.get("tag_name")
            if isinstance(tag, str) and tag.startswith("v"):
                return tag
    except (urllib.error.URLError, json.JSONDecodeError, TimeoutError) as exc:
        logger.warning(
            "Could not reach GitHub for latest release (%s); using pinned %s",
            exc, _FALLBACK_VERSION,
        )
    return _FALLBACK_VERSION


def _download(url: str, dest: Path) -> None:
    """Stream a URL to a file with a single rewriting progress line."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    logger.info("Downloading %s", url)
    with urllib.request.urlopen(url, timeout=30) as resp:
        total = int(resp.headers.get("Content-Length") or 0)
        chunk = 1 << 16
        written = 0
        last_print = 0.0
        with open(dest, "wb") as f:
            while True:
                buf = resp.read(chunk)
                if not buf:
                    break
                f.write(buf)
                written += len(buf)
                now = time.monotonic()
                if total and now - last_print > 0.5:
                    pct = written * 100 / total
                    sys.stderr.write(
                        f"\r  {written/1e6:7.1f} / {total/1e6:7.1f} MB "
                        f"({pct:5.1f}%)"
                    )
                    sys.stderr.flush()
                    last_print = now
        if total:
            sys.stderr.write("\n")
            sys.stderr.flush()


def _extract_archive(archive: Path, dest_dir: Path) -> None:
    """Extract Ollama's release archive into `dest_dir`.

    Handles `.tar.zst` (Linux releases) and `.tgz` (macOS releases).
    """
    dest_dir.mkdir(parents=True, exist_ok=True)
    suffixes = "".join(archive.suffixes[-2:])

    if suffixes.endswith(".tar.zst") or archive.name.endswith(".tar.zst"):
        _extract_tar_zst(archive, dest_dir)
        return
    if suffixes in (".tar.gz", ".tgz") or archive.name.endswith((".tgz", ".tar.gz")):
        import tarfile  # stdlib
        with tarfile.open(archive, "r:gz") as tar:
            tar.extractall(path=dest_dir)
        return
    raise RuntimeError(f"Unrecognized archive format: {archive.name}")


def _extract_tar_zst(archive: Path, dest_dir: Path) -> None:
    """Decompress a .tar.zst — system `zstd` first, Python fallback second."""
    if shutil.which("zstd"):
        # `tar --use-compress-program=zstd -xf <archive> -C <dest>`
        subprocess.run(
            ["tar", "--use-compress-program=zstd", "-xf",
             str(archive), "-C", str(dest_dir)],
            check=True,
        )
        return
    try:
        import tarfile
        import zstandard  # type: ignore[import-not-found]
    except ImportError as exc:
        raise RuntimeError(
            "Need either the `zstd` system utility or the Python "
            "`zstandard` package to extract Ollama's tar.zst archive. "
            "Install one of:\n"
            "  apt install zstd            (Debian/Ubuntu)\n"
            "  brew install zstd           (macOS)\n"
            "  pip install zstandard       (any platform)"
        ) from exc
    dctx = zstandard.ZstdDecompressor()
    with open(archive, "rb") as f, dctx.stream_reader(f) as reader:
        with tarfile.open(fileobj=reader, mode="r|") as tar:
            tar.extractall(path=dest_dir)


def install_ollama(install_root: Optional[Path] = None) -> Path:
    """Download and extract the Ollama release; symlink into PATH.

    Returns the resolved path of the new `ollama` binary. No-ops (and warns)
    if `ollama` is already on PATH — call `find_ollama()` first if you want
    to skip the side effect entirely.
    """
    existing = find_ollama()
    if existing is not None:
        logger.info("Ollama already on PATH at %s — skipping install", existing)
        return existing

    os_name, arch = detect_platform()
    archive_name = _ARCHIVE_BY_PLATFORM[(os_name, arch)]
    version = _resolve_release_version()
    url = f"{_GITHUB_RELEASE_BASE}/{version}/{archive_name}"

    install_root = install_root or (Path.home() / ".local" / "share" / "ollama")
    cache_dir = Path.home() / ".cache" / "udsxml2tex" / "ollama-install"
    archive_path = cache_dir / archive_name

    if not archive_path.exists():
        _download(url, archive_path)
    else:
        logger.info("Reusing cached archive at %s", archive_path)

    logger.info("Extracting %s into %s", archive_name, install_root)
    _extract_archive(archive_path, install_root)

    binary = _locate_extracted_binary(install_root)
    bin_dir = Path.home() / ".local" / "bin"
    bin_dir.mkdir(parents=True, exist_ok=True)
    link = bin_dir / "ollama"
    if link.exists() or link.is_symlink():
        link.unlink()
    link.symlink_to(binary)
    logger.info("Symlinked %s -> %s", link, binary)

    if str(bin_dir) not in os.environ.get("PATH", "").split(os.pathsep):
        logger.warning(
            "%s is not on PATH. Add it to your shell rc, or invoke ollama "
            "via the absolute path: %s", bin_dir, binary,
        )
    return link


def _locate_extracted_binary(install_root: Path) -> Path:
    """Find the `ollama` binary somewhere under `install_root`."""
    for candidate in (
        install_root / "bin" / "ollama",   # Linux release layout
        install_root / "ollama",           # macOS release layout (sometimes)
        install_root / "Ollama.app" / "Contents" / "Resources" / "ollama",
    ):
        if candidate.exists() and os.access(candidate, os.X_OK):
            return candidate
    # Last-resort recursive search.
    for path in install_root.rglob("ollama"):
        if path.is_file() and os.access(path, os.X_OK):
            return path
    raise RuntimeError(f"No ollama binary found under {install_root}")


# ---------------------------------------------------------------------------
# Daemon control
# ---------------------------------------------------------------------------

def is_serve_running(host: str, port: int, timeout: float = 1.5) -> bool:
    """True if `http://host:port/api/tags` answers."""
    url = f"http://{host}:{port}/api/tags"
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            return resp.status == 200
    except (urllib.error.URLError, TimeoutError, ConnectionError):
        return False


def start_serve(
    *,
    host: str,
    port: int,
    ctx_length: int,
    log_path: Optional[Path] = None,
    keep_alive: str = "10m",
) -> int:
    """Spawn `ollama serve` in a detached subprocess and wait for /api/tags.

    Returns the child PID. The child is detached via `start_new_session` so
    it survives this Python process — closer in spirit to running it from
    the user's shell. Logs go to `log_path` (default
    `~/.cache/udsxml2tex/ollama.log`).
    """
    log_path = log_path or (
        Path.home() / ".cache" / "udsxml2tex" / "ollama.log"
    )
    log_path.parent.mkdir(parents=True, exist_ok=True)

    env = {
        **os.environ,
        "OLLAMA_HOST": f"{host}:{port}",
        "OLLAMA_CONTEXT_LENGTH": str(ctx_length),
        "OLLAMA_KEEP_ALIVE": keep_alive,
    }
    logger.info(
        "Starting `ollama serve` on %s:%s (ctx=%d, log=%s)",
        host, port, ctx_length, log_path,
    )
    log_file = open(log_path, "ab")
    try:
        proc = subprocess.Popen(  # noqa: S603 — caller-controlled args
            ["ollama", "serve"],
            stdout=log_file,
            stderr=subprocess.STDOUT,
            env=env,
            start_new_session=True,
            close_fds=True,
        )
    finally:
        # The subprocess owns its end of the fd; we don't need ours.
        log_file.close()

    deadline = time.monotonic() + 30.0
    while time.monotonic() < deadline:
        if is_serve_running(host, port):
            return proc.pid
        if proc.poll() is not None:
            raise RuntimeError(
                f"`ollama serve` exited early (code {proc.returncode}). "
                f"See {log_path} for details."
            )
        time.sleep(0.3)
    raise RuntimeError(
        f"`ollama serve` did not start listening on {host}:{port} within 30s. "
        f"See {log_path}."
    )


# ---------------------------------------------------------------------------
# Model management
# ---------------------------------------------------------------------------

def list_models(host: str, port: int) -> list[str]:
    """Names of locally-pulled models on the given Ollama instance."""
    url = f"http://{host}:{port}/api/tags"
    try:
        with urllib.request.urlopen(url, timeout=5) as resp:
            data = json.load(resp)
    except (urllib.error.URLError, json.JSONDecodeError, TimeoutError):
        return []
    return [m.get("name", "") for m in data.get("models", []) if m.get("name")]


def pull_model(model: str, *, host: str, port: int) -> None:
    """Pull `model` via the `ollama` CLI; progress is shown to the user.

    Streams Ollama's own progress UI to stderr — no extra wrapper.
    """
    env = {**os.environ, "OLLAMA_HOST": f"{host}:{port}"}
    logger.info("Pulling model %s …", model)
    subprocess.run(["ollama", "pull", model], env=env, check=True)


# ---------------------------------------------------------------------------
# Orchestrator
# ---------------------------------------------------------------------------

def bootstrap(
    *,
    model: str = DEFAULT_MODEL,
    ctx_length: int = DEFAULT_CTX,
    host: str = "127.0.0.1",
    port: int = 11434,
    install_root: Optional[Path] = None,
) -> BootstrapResult:
    """End-to-end setup. Idempotent — safe to re-run."""
    ollama_path = find_ollama() or install_ollama(install_root)

    serve_already = is_serve_running(host, port)
    serve_pid: Optional[int] = None
    if serve_already:
        logger.info("`ollama serve` already running on %s:%s", host, port)
    else:
        serve_pid = start_serve(host=host, port=port, ctx_length=ctx_length)

    present = list_models(host, port)
    model_present = model in present
    if model_present:
        logger.info("Model %s already pulled", model)
    else:
        pull_model(model, host=host, port=port)

    return BootstrapResult(
        ollama_path=ollama_path,
        serve_pid=serve_pid,
        serve_already_running=serve_already,
        model=model,
        model_already_present=model_present,
        ctx_length=ctx_length,
        host=host,
        port=port,
    )


def print_summary(result: BootstrapResult, *, stream=None) -> None:
    """Human-friendly post-bootstrap report and a ready-to-paste config."""
    out = stream or sys.stderr
    sn = "skipped (already running)" if result.serve_already_running else "started"
    pn = "skipped (already present)" if result.model_already_present else "pulled"
    print("", file=out)
    print("Ollama bootstrap complete:", file=out)
    print(f"  binary  : {result.ollama_path}", file=out)
    print(f"  serve   : {sn}"
          + (f" pid={result.serve_pid}" if result.serve_pid else ""),
          file=out)
    print(f"  model   : {result.model} ({pn})", file=out)
    print(f"  endpoint: {result.base_url}  (num_ctx={result.ctx_length})",
          file=out)
    print("", file=out)
    print("Drop the snippet below into `~/.udsxml2tex/llm.json` to make every "
          "udsxml2tex LLM call default to this Ollama instance:", file=out)
    cfg = {
        "provider": "openai",
        "base_url": result.base_url,
        "model": result.model,
        "api_key": "ollama",
        "structured_mode": "json_object",
        "timeout": 180.0,
    }
    print(json.dumps(cfg, indent=2), file=out)
    print("", file=out)
    print("Then start the browser UI:", file=out)
    print("  udsxml2tex --serve", file=out)


# ---------------------------------------------------------------------------
# Public façade for the CLI
# ---------------------------------------------------------------------------

def run_from_cli(
    *,
    model: Optional[str],
    ctx: Optional[int],
    host: Optional[str],
    port: Optional[int],
) -> int:
    """Entry point used by `udsxml2tex --bootstrap-ollama`."""
    try:
        result = bootstrap(
            model=model or DEFAULT_MODEL,
            ctx_length=ctx or DEFAULT_CTX,
            host=host or "127.0.0.1",
            port=port or 11434,
        )
    except (RuntimeError, subprocess.CalledProcessError, OSError) as exc:
        logger.error("Bootstrap failed: %s", exc)
        return 1
    print_summary(result)
    return 0
