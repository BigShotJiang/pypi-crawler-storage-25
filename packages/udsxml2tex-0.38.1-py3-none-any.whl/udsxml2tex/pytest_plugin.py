"""pytest plugin for udsxml2tex — provides UDS spec fixtures and assertions.

Register in conftest.py with:
    pytest_plugins = ["udsxml2tex.pytest_plugin"]

Or install as entry-point plugin via setuptools by adding to pyproject.toml::

    [project.entry-points."pytest11"]
    udsxml2tex = "udsxml2tex.pytest_plugin"

Available fixtures:
    uds_spec_factory  — factory for custom UdsSpecification instances
    uds_spec          — a ready-made minimal UdsSpecification
    uds_spec_from_json — callable that builds a spec from a JSON string

Available marks:
    @pytest.mark.uds_spec_id(sid)  — tag tests by UDS service ID (e.g. 0x22)

Custom assertion mixin:
    UdsSpecAssertions  — inherit in test classes for helper assertions
"""

from __future__ import annotations

import json
from typing import Callable

import pytest

from udsxml2tex.models import (
    DataElement,
    Did,
    DiagSession,
    DtcDefinition,
    Routine,
    SecurityLevel,
    UdsService,
    UdsSpecification,
)

__all__ = [
    "UdsSpecAssertions",
    "uds_spec",
    "uds_spec_factory",
    "uds_spec_from_json",
]


# ---------------------------------------------------------------------------
# Custom assertions mixin
# ---------------------------------------------------------------------------


class UdsSpecAssertions:
    """Mixin providing helper assertion methods for UdsSpecification tests."""

    def assert_did_present(self, spec: UdsSpecification, did_id: int) -> None:
        """Assert that a DID with the given ID exists in *spec*."""
        ids = [d.did_id for d in spec.dids]
        assert did_id in ids, (
            f"DID 0x{did_id:04X} not found in spec. Present DIDs: "
            + ", ".join(f"0x{i:04X}" for i in ids)
        )

    def assert_dtc_present(self, spec: UdsSpecification, dtc_id: int) -> None:
        """Assert that a DTC with the given ID exists in *spec*."""
        ids = [d.dtc_id for d in spec.dtcs]
        assert dtc_id in ids, (
            f"DTC 0x{dtc_id:06X} not found in spec. Present DTCs: "
            + ", ".join(f"0x{i:06X}" for i in ids)
        )

    def assert_session_present(self, spec: UdsSpecification, session_id: int) -> None:
        """Assert that a session with the given ID exists in *spec*."""
        ids = [s.session_id for s in spec.sessions]
        assert session_id in ids, (
            f"Session 0x{session_id:02X} not found in spec. Present sessions: "
            + ", ".join(f"0x{i:02X}" for i in ids)
        )

    def assert_service_present(self, spec: UdsSpecification, service_id: int) -> None:
        """Assert that a service with the given ID exists in *spec*."""
        ids = [s.service_id for s in spec.services]
        assert service_id in ids, (
            f"Service 0x{service_id:02X} not found in spec. Present services: "
            + ", ".join(f"0x{i:02X}" for i in ids)
        )

    def assert_valid(self, spec: UdsSpecification) -> None:
        """Assert that validate(spec) returns no errors."""
        from udsxml2tex.validator import validate

        result = validate(spec)
        if result.has_errors():
            raise AssertionError(f"Spec has validation errors: {result.issues}")


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def uds_spec_factory() -> Callable[..., UdsSpecification]:
    """Factory fixture for creating test UdsSpecification instances.

    Usage::

        def test_something(uds_spec_factory):
            spec = uds_spec_factory(ecu_name="MyECU", num_dids=5)
    """

    def _factory(
        ecu_name: str = "TestECU",
        num_sessions: int = 2,
        num_dids: int = 3,
        num_dtcs: int = 2,
        num_services: int = 2,
    ) -> UdsSpecification:
        sessions = []
        for i in range(num_sessions):
            session_id = 0x01 + i
            sessions.append(
                DiagSession(
                    short_name=f"Session_{i + 1:02X}",
                    session_id=session_id,
                    p2_server_max=0.05,
                    p2_star_server_max=5.0,
                )
            )

        dids = []
        for i in range(num_dids):
            did_id = 0x1000 + i
            dids.append(
                Did(
                    short_name=f"Did_{did_id:04X}",
                    did_id=did_id,
                    description=f"Test DID {i + 1}",
                    data_elements=[
                        DataElement(
                            short_name="DataByte",
                            byte_position=0,
                            bit_size=8,
                            data_type="uint8",
                        )
                    ],
                    read_access=True,
                    write_access=False,
                    total_byte_length=1,
                )
            )

        dtcs = []
        for i in range(num_dtcs):
            dtc_id = 0x010000 * (i + 1)
            dtcs.append(
                DtcDefinition(
                    short_name=f"DTC_{dtc_id:06X}",
                    dtc_id=dtc_id,
                    description=f"Test DTC {i + 1}",
                )
            )

        session_names = [s.short_name for s in sessions]
        services = []
        service_ids = [0x22, 0x2E, 0x31, 0x27, 0x14]
        service_names = [
            "ReadDataByIdentifier",
            "WriteDataByIdentifier",
            "RoutineControl",
            "SecurityAccess",
            "ClearDiagnosticInformation",
        ]
        for i in range(min(num_services, len(service_ids))):
            services.append(
                UdsService(
                    short_name=service_names[i],
                    service_id=service_ids[i],
                    supported_sessions=list(session_names),
                )
            )

        return UdsSpecification(
            ecu_name=ecu_name,
            sessions=sessions,
            dids=dids,
            dtcs=dtcs,
            services=services,
        )

    return _factory


@pytest.fixture
def uds_spec() -> UdsSpecification:
    """A ready-made minimal UdsSpecification for use in tests.

    Includes:
      - Default session (0x01) and extended session (0x03)
      - SecurityAccess (0x27) and ReadDataByIdentifier (0x22) services
      - 2 sample DIDs: 0x1234 and 0x1235
      - 1 routine: 0xFF01
      - 2 sample DTCs: 0x010000 and 0x020000
    """
    sessions = [
        DiagSession(
            short_name="DefaultSession",
            session_id=0x01,
            p2_server_max=0.05,
            p2_star_server_max=5.0,
        ),
        DiagSession(
            short_name="ExtendedSession",
            session_id=0x03,
            p2_server_max=0.05,
            p2_star_server_max=5.0,
        ),
    ]

    security_levels = [
        SecurityLevel(
            short_name="Level01",
            security_level=0x01,
            key_size=4,
            seed_size=4,
            num_max_attempts=3,
        ),
    ]

    session_names = [s.short_name for s in sessions]

    services = [
        UdsService(
            short_name="SecurityAccess",
            service_id=0x27,
            description="Security Access service",
            supported_sessions=session_names,
        ),
        UdsService(
            short_name="ReadDataByIdentifier",
            service_id=0x22,
            description="Read Data By Identifier service",
            supported_sessions=session_names,
        ),
    ]

    dids = [
        Did(
            short_name="Did_1234",
            did_id=0x1234,
            description="Sample DID 0x1234",
            data_elements=[
                DataElement(
                    short_name="DataByte",
                    byte_position=0,
                    bit_size=8,
                    data_type="uint8",
                )
            ],
            read_access=True,
            write_access=False,
            total_byte_length=1,
            supported_sessions=session_names,
        ),
        Did(
            short_name="Did_1235",
            did_id=0x1235,
            description="Sample DID 0x1235",
            data_elements=[
                DataElement(
                    short_name="DataWord",
                    byte_position=0,
                    bit_size=16,
                    data_type="uint16",
                )
            ],
            read_access=True,
            write_access=True,
            total_byte_length=2,
            supported_sessions=session_names,
        ),
    ]

    routines = [
        Routine(
            short_name="Routine_FF01",
            routine_id=0xFF01,
            description="Sample routine 0xFF01",
            start_supported=True,
            stop_supported=False,
            result_supported=True,
            supported_sessions=session_names,
        ),
    ]

    dtcs = [
        DtcDefinition(
            short_name="DTC_010000",
            dtc_id=0x010000,
            description="Sample DTC 0x010000",
        ),
        DtcDefinition(
            short_name="DTC_020000",
            dtc_id=0x020000,
            description="Sample DTC 0x020000",
        ),
    ]

    return UdsSpecification(
        ecu_name="TestECU",
        description="Minimal test specification",
        sessions=sessions,
        security_levels=security_levels,
        services=services,
        dids=dids,
        routines=routines,
        dtcs=dtcs,
    )


@pytest.fixture
def uds_spec_from_json(tmp_path: "pytest.TempPathFactory") -> Callable[[str], UdsSpecification]:
    """Fixture that provides a callable to build a UdsSpecification from a JSON string.

    Usage::

        def test_roundtrip(uds_spec, uds_spec_from_json):
            json_str = uds_spec.to_json()
            spec2 = uds_spec_from_json(json_str)
            assert spec2.ecu_name == uds_spec.ecu_name
    """

    def _load(json_str: str) -> UdsSpecification:
        json_path = tmp_path / "spec.json"
        json_path.write_text(json_str, encoding="utf-8")
        return UdsSpecification.load_json(json_path)

    return _load


# ---------------------------------------------------------------------------
# Custom marks
# ---------------------------------------------------------------------------


def pytest_configure(config: "pytest.Config") -> None:
    """Register the uds_spec_id mark to avoid PytestUnknownMarkWarning."""
    config.addinivalue_line(
        "markers",
        "uds_spec_id(sid): mark test with the UDS service ID under test "
        "(e.g. @pytest.mark.uds_spec_id(0x22))",
    )
