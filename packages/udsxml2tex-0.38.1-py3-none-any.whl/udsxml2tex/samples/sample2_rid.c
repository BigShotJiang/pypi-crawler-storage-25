/**
 * sample_rid.c — Example RID (Routine Control) implementation
 *
 * This file demonstrates how udsxml2tex extracts global variable references
 * from RID service handler functions.  The tool scans for variables declared
 * at file scope (or extern-linked) that are accessed inside each RID function
 * matched by the ARXML DcmDspRoutine StartFnc / StopFnc / RequestResultsFnc.
 */

#include <stdint.h>
#include <string.h>
#include <stdbool.h>

/* --------------------------------------------------------------------- */
/* Global state variables referenced by RID handlers                      */
/* --------------------------------------------------------------------- */

bool     g_sec_erase_memory_in_progress;
uint32_t g_sec_erase_memory_address;
uint32_t g_sec_erase_memory_length;
uint8_t  g_sec_erase_memory_result;

bool     g_sec_check_prog_conditions_passed;
uint8_t  g_prog_condition_flags;

uint8_t  g_reset_sequence_step;
bool     g_reset_requested;

/* --------------------------------------------------------------------- */
/* RID 0x0203 — EraseMemory                                              */
/* --------------------------------------------------------------------- */

Std_ReturnType Rid_0x0203_Start(
    uint32_t address,
    uint32_t length,
    uint8_t *errorCode)
{
    if (g_sec_erase_memory_in_progress) {
        *errorCode = 0x22U; /* conditionsNotCorrect */
        return E_NOT_OK;
    }
    g_sec_erase_memory_address     = address;
    g_sec_erase_memory_length      = length;
    g_sec_erase_memory_in_progress = true;
    g_sec_erase_memory_result      = 0x00U; /* pending */
    return E_OK;
}

Std_ReturnType Rid_0x0203_RequestResults(uint8_t *statusRecord, uint8_t *errorCode)
{
    if (g_sec_erase_memory_in_progress) {
        *statusRecord = 0x01U; /* routineAbortedWithResults — still running */
        return E_PENDING;
    }
    *statusRecord = g_sec_erase_memory_result;
    return E_OK;
}

/* --------------------------------------------------------------------- */
/* RID 0x0202 — CheckProgrammingConditions                               */
/* --------------------------------------------------------------------- */

Std_ReturnType Rid_0x0202_Start(uint8_t *errorCode)
{
    uint8_t flags = g_prog_condition_flags;

    /* Bit 0: voltage OK, Bit 1: ignition on, Bit 2: vehicle stationary */
    g_sec_check_prog_conditions_passed = ((flags & 0x07U) == 0x07U);
    if (!g_sec_check_prog_conditions_passed) {
        *errorCode = 0x22U;
        return E_NOT_OK;
    }
    return E_OK;
}

Std_ReturnType Rid_0x0202_RequestResults(uint8_t *statusRecord, uint8_t *errorCode)
{
    *statusRecord = g_sec_check_prog_conditions_passed ? 0x10U : 0x00U;
    return E_OK;
}

/* --------------------------------------------------------------------- */
/* RID 0xFF01 — ECUReset sequence                                         */
/* --------------------------------------------------------------------- */

Std_ReturnType Rid_0xFF01_Start(uint8_t resetType, uint8_t *errorCode)
{
    g_reset_sequence_step = resetType;
    g_reset_requested     = true;
    return E_OK;
}

Std_ReturnType Rid_0xFF01_Stop(uint8_t *errorCode)
{
    g_reset_requested     = false;
    g_reset_sequence_step = 0U;
    return E_OK;
}

Std_ReturnType Rid_0xFF01_RequestResults(uint8_t *statusRecord, uint8_t *errorCode)
{
    *statusRecord = g_reset_requested ? g_reset_sequence_step : 0x00U;
    return E_OK;
}
