"""AUTOSAR version compatibility reporting.

Builds on the existing version detection in `parser._detect_arxml_version()`
to produce a structured compatibility report that flags ARXML elements which
behave differently across AUTOSAR releases (R3.2, R4.0–R4.7, R20-11, R21-11,
R22-11). Useful when migrating a model between AUTOSAR releases or when
reviewing whether parsed parameters were interpreted with the right semantics.

Public API:
    autosar_compat_report(spec, parser=None) -> CompatReport
    CompatReport.to_markdown() -> str
    CompatReport.to_dict() -> dict
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

# Mapping from R-release labels to AUTOSAR Classic Platform release names.
# These align with the AR_NAMESPACES table in parser.py.
_R_TO_NAME = {
    "R3.0": "Classic R3.0", "R3.1": "Classic R3.1", "R3.2": "Classic R3.2",
    "R4.0": "Classic R4.0", "R4.1": "Classic R4.1", "R4.2": "Classic R4.2",
    "R4.3": "Classic R4.3", "R4.4": "Classic R4.4", "R4.5": "Classic R4.5",
    "R4.6": "Classic R4.6", "R4.7": "Classic R4.7",
    "R20-11": "Classic R20-11", "R21-11": "Classic R21-11",
    "R22-11": "Classic R22-11",
}


# Per-feature AUTOSAR version availability — short_label → minimum release
# where the feature is available in the spec parser. Used to flag features
# present in the spec that wouldn't have existed in the ARXML's nominal version.
_FEATURE_MIN_VERSION = {
    "DcmDspAuthentication":   "R20-11",  # Authentication (0x29) added 2020
    "DcmDspRequestFileTransfer": "R4.2",  # File transfer service
    "DcmDspLinkControl":      "R4.0",
    "DcmDspDidRange":         "R4.2",
    "DcmDspDynamicDid":       "R4.2",
    "DcmDspPeriodicDid":      "R4.0",
    "DcmDspDidControl":       "R4.0",
    "DemDTCKindWWHOBD":       "R4.4",
    "DemCombinedDTC":         "R4.4",
    "DemFreezeFrameClass":    "R4.0",
    "DemExtendedDataClass":   "R4.0",
    "DoIpConfig":             "R4.2",
    "ApDiagnosticService":    "R20-11",  # Adaptive Platform diagnostics
}


# Total ordering of AUTOSAR releases for comparison.
_VERSION_ORDER = [
    "R3.0", "R3.1", "R3.2",
    "R4.0", "R4.1", "R4.2", "R4.3", "R4.4", "R4.5", "R4.6", "R4.7",
    "R20-11", "R21-11", "R22-11",
]


def _version_lt(a: str, b: str) -> bool:
    """True if AUTOSAR release `a` is older than `b` (per _VERSION_ORDER)."""
    if a not in _VERSION_ORDER or b not in _VERSION_ORDER:
        return False
    return _VERSION_ORDER.index(a) < _VERSION_ORDER.index(b)


@dataclass
class CompatFinding:
    severity: str             # "info" | "warning" | "error"
    feature: str              # e.g. "DcmDspAuthentication"
    detected_version: str     # e.g. "R4.2"
    min_required_version: str # e.g. "R20-11"
    detail: str

    def to_dict(self) -> dict:
        return {
            "severity": self.severity,
            "feature": self.feature,
            "detected_version": self.detected_version,
            "min_required_version": self.min_required_version,
            "detail": self.detail,
        }


@dataclass
class CompatReport:
    detected_version: str
    detected_label: str
    findings: list[CompatFinding] = field(default_factory=list)

    @property
    def has_warnings(self) -> bool:
        return any(f.severity in ("warning", "error") for f in self.findings)

    def to_dict(self) -> dict:
        return {
            "detected_version": self.detected_version,
            "detected_label": self.detected_label,
            "findings": [f.to_dict() for f in self.findings],
            "has_warnings": self.has_warnings,
        }

    def to_markdown(self) -> str:
        lines = [
            "# AUTOSAR Version Compatibility Report",
            "",
            f"**Detected AUTOSAR release:** {self.detected_label} "
            f"(`{self.detected_version}`)",
            "",
        ]
        if not self.findings:
            lines.append("✓ No compatibility issues detected.")
            return "\n".join(lines)

        lines.append("## Findings")
        lines.append("")
        lines.append("| Severity | Feature | Detected | Min. Required | Detail |")
        lines.append("|---|---|---|---|---|")
        for f in self.findings:
            lines.append(
                f"| {f.severity} | `{f.feature}` | {f.detected_version} | "
                f"{f.min_required_version} | {f.detail} |"
            )
        return "\n".join(lines)


def autosar_compat_report(spec: Any, parser: Optional[Any] = None) -> CompatReport:
    """Generate an AUTOSAR version compatibility report for a parsed spec.

    Args:
        spec: Parsed UdsSpecification.
        parser: Optional ArxmlParser instance (used to read `arxml_version`).
                If omitted, the report falls back to "unknown" version
                detection and only flags features by presence/absence.

    Returns:
        CompatReport with severity-tagged findings.
    """
    detected = getattr(parser, "arxml_version", None) if parser else None
    if not detected:
        detected = "unknown"
    label = _R_TO_NAME.get(detected, detected)

    findings: list[CompatFinding] = []

    # Feature presence checks
    feature_present = {
        "DcmDspAuthentication": getattr(spec, "authentication_config", None) is not None,
        "DcmDspRequestFileTransfer": bool(getattr(spec, "request_file_transfer", [])),
        "DcmDspLinkControl": bool(getattr(spec, "link_control_baudrates", [])),
        "DcmDspDidRange": bool(getattr(spec, "did_ranges", [])),
        "DcmDspDynamicDid": bool(getattr(spec, "dynamic_dids", [])),
        "DcmDspPeriodicDid": bool(getattr(spec, "periodic_dids", [])),
        "DcmDspDidControl": bool(getattr(spec, "io_control_dids", [])),
        "DemDTCKindWWHOBD": any(
            getattr(d, "wwh_obd_dtc_class", None) for d in getattr(spec, "dem_dtcs", [])
        ),
        "DemCombinedDTC": bool(getattr(spec, "dem_combined_dtcs", [])),
        "DemFreezeFrameClass": bool(getattr(spec, "dem_freeze_frame_classes", [])),
        "DemExtendedDataClass": bool(getattr(spec, "dem_extended_data_classes", [])),
        "DoIpConfig": getattr(spec, "doip_config", None) is not None,
        "ApDiagnosticService": getattr(spec, "ap_config", None) is not None,
    }

    for feat, present in feature_present.items():
        if not present:
            continue
        min_ver = _FEATURE_MIN_VERSION.get(feat)
        if not min_ver:
            continue
        if detected == "unknown":
            findings.append(CompatFinding(
                severity="info",
                feature=feat,
                detected_version="unknown",
                min_required_version=min_ver,
                detail=(
                    f"Feature is configured in the spec; AUTOSAR release was "
                    f"not detected so compatibility cannot be verified."
                ),
            ))
            continue
        if _version_lt(detected, min_ver):
            findings.append(CompatFinding(
                severity="warning",
                feature=feat,
                detected_version=detected,
                min_required_version=min_ver,
                detail=(
                    f"Feature appears in the spec but is not standard until "
                    f"AUTOSAR {min_ver}. Verify the parameters were "
                    f"interpreted correctly for the older release."
                ),
            ))
        else:
            findings.append(CompatFinding(
                severity="info",
                feature=feat,
                detected_version=detected,
                min_required_version=min_ver,
                detail="Feature is supported in the detected AUTOSAR release.",
            ))

    return CompatReport(
        detected_version=detected,
        detected_label=label,
        findings=findings,
    )
