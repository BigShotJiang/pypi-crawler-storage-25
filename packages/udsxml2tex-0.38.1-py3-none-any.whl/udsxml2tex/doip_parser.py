"""DoIP (ISO 13400) ARXML configuration parser and model classes."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


# ---------------------------------------------------------------------------
# Model classes
# ---------------------------------------------------------------------------


@dataclass
class DoIpLogicalAddress:
    """DoIP logical address entry."""

    short_name: str
    address: int = 0
    ecu_ref: str = ""

    @property
    def address_hex(self) -> str:
        return f"0x{self.address:04X}"


@dataclass
class DoIpRoutingActivation:
    """DoIP routing activation definition."""

    short_name: str
    activation_number: int = 0
    activation_type: str = ""

    @property
    def activation_number_hex(self) -> str:
        return f"0x{self.activation_number:02X}"


@dataclass
class DoIpConfig:
    """DoIP (ISO 13400) configuration parsed from ARXML."""

    short_name: str = ""
    vehicle_identification_response_time: float = 0.0   # seconds
    initial_vehicle_announcement_time: float = 0.0
    vehicle_announcement_interval: float = 0.0
    vehicle_announcement_count: int = 0
    max_udp_request_per_message: int = 1
    max_tcp_payload_len: int = 0
    eid: str = ""   # Entity ID (6 bytes hex)
    gid: str = ""   # Group ID (6 bytes hex)
    vins: list[str] = field(default_factory=list)
    activation_type: str = ""   # Default, Operational, etc.
    logical_addresses: list[DoIpLogicalAddress] = field(default_factory=list)
    routing_activations: list[DoIpRoutingActivation] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------


class DoIpParser:
    """Parse DoIP ARXML configuration from DoIP container elements."""

    # AUTOSAR R4 namespace URI used when namespace is present
    _AR_NS_URI = "http://autosar.org/schema/r4.0"

    # ---- helpers -----------------------------------------------------------

    @staticmethod
    def _build_ns(ns: str) -> dict[str, str]:
        """Return lxml namespace dict for use in xpath calls."""
        if ns:
            return {"ar": DoIpParser._AR_NS_URI}
        return {}

    @staticmethod
    def _xpath_text(el, path: str, ns: str, default: str = "") -> str:
        """Return text of the first element matching *path*, or *default*."""
        ns_map = DoIpParser._build_ns(ns)
        try:
            if ns_map:
                results = el.xpath(path, namespaces=ns_map)
            else:
                import re as _re
                clean = _re.sub(r"ar:", "", path)
                results = el.xpath(clean)
        except Exception:
            return default
        if results:
            from lxml import etree as _etree  # local import — already a dep
            first = results[0]
            if isinstance(first, _etree._Element):
                return (first.text or "").strip() or default
            return str(first).strip() or default
        return default

    @staticmethod
    def _xpath_float(el, path: str, ns: str, default: float = 0.0) -> float:
        """Return float value from XPath, silently falling back to *default*."""
        text = DoIpParser._xpath_text(el, path, ns, "")
        if text:
            try:
                return float(text)
            except ValueError:
                pass
        return default

    @staticmethod
    def _xpath_int(el, path: str, ns: str, default: int = 0) -> int:
        """Return int value from XPath, silently falling back to *default*."""
        text = DoIpParser._xpath_text(el, path, ns, "")
        if text:
            try:
                # Support hex literals (0x…) that may appear in ARXML
                return int(text, 0)
            except (ValueError, TypeError):
                pass
        return default

    # ---- public API --------------------------------------------------------

    def parse(self, root, ns: str = "") -> DoIpConfig:
        """Parse DoIP config from lxml root element.

        Args:
            root: lxml etree element (root of ARXML document).
            ns:   Namespace prefix with colon, e.g. ``""`` or ``"ar:"``.
                  Pass ``"ar:"`` for AUTOSAR R4 ARXML files that carry the
                  ``http://autosar.org/schema/r4.0`` namespace.

        Returns:
            Populated :class:`DoIpConfig`.  All fields fall back to their
            defaults when the corresponding XML elements are absent.
        """
        config = DoIpConfig()
        ns_map = self._build_ns(ns)

        # Locate the DoIpConfig/DOIP-CONFIG container.  AUTOSAR uses both
        # CamelCase (R3) and UPPER-KEBAB-CASE (R4) element names.
        try:
            if ns_map:
                doip_els = root.xpath(
                    f".//{ns}DoIpConfig | .//{ns}DOIP-CONFIG",
                    namespaces=ns_map,
                )
            else:
                doip_els = root.xpath(".//DoIpConfig | .//DOIP-CONFIG")
        except Exception:
            doip_els = []

        if not doip_els:
            return config

        cfg = doip_els[0]

        # SHORT-NAME
        config.short_name = self._xpath_text(
            cfg, f"{ns}SHORT-NAME", ns
        )

        # Timing parameters
        config.vehicle_identification_response_time = self._xpath_float(
            cfg, f"{ns}DOIP-TP-CONFIG/{ns}VEHICLE-IDENTIFICATION-RESPONSE-TIME", ns
        ) or self._xpath_float(
            cfg, f"{ns}VehicleIdentificationResponseTime", ns
        )
        config.initial_vehicle_announcement_time = self._xpath_float(
            cfg, f"{ns}DOIP-TP-CONFIG/{ns}INITIAL-VEHICLE-ANNOUNCEMENT-TIME", ns
        ) or self._xpath_float(
            cfg, f"{ns}InitialVehicleAnnouncementTime", ns
        )
        config.vehicle_announcement_interval = self._xpath_float(
            cfg, f"{ns}DOIP-TP-CONFIG/{ns}VEHICLE-ANNOUNCEMENT-INTERVAL", ns
        ) or self._xpath_float(
            cfg, f"{ns}VehicleAnnouncementInterval", ns
        )
        config.vehicle_announcement_count = self._xpath_int(
            cfg, f"{ns}DOIP-TP-CONFIG/{ns}VEHICLE-ANNOUNCEMENT-COUNT", ns
        ) or self._xpath_int(
            cfg, f"{ns}VehicleAnnouncementCount", ns
        )

        # Payload / request limits
        config.max_udp_request_per_message = self._xpath_int(
            cfg, f"{ns}MAX-UDP-REQUEST-PER-MESSAGE", ns
        ) or self._xpath_int(
            cfg, f"{ns}MaxUdpRequestPerMessage", ns
        ) or 1
        config.max_tcp_payload_len = self._xpath_int(
            cfg, f"{ns}MAX-TCP-PAYLOAD-LEN", ns
        ) or self._xpath_int(
            cfg, f"{ns}MaxTcpPayloadLen", ns
        )

        # Entity / Group IDs
        config.eid = self._xpath_text(cfg, f"{ns}EID", ns) or self._xpath_text(
            cfg, f"{ns}EntityId", ns
        )
        config.gid = self._xpath_text(cfg, f"{ns}GID", ns) or self._xpath_text(
            cfg, f"{ns}GroupId", ns
        )

        # VINs
        try:
            if ns_map:
                vin_els = cfg.xpath(
                    f".//{ns}VIN | .//{ns}VEHICLE-IDENTIFICATION-NUMBERS/{ns}VEHICLE-IDENTIFICATION-NUMBER",
                    namespaces=ns_map,
                )
            else:
                vin_els = cfg.xpath(
                    ".//VIN | .//VEHICLE-IDENTIFICATION-NUMBERS/VEHICLE-IDENTIFICATION-NUMBER"
                )
            config.vins = [
                (el.text or "").strip() for el in vin_els if (el.text or "").strip()
            ]
        except Exception:
            pass

        # Activation type (top-level)
        config.activation_type = self._xpath_text(
            cfg, f"{ns}ACTIVATION-TYPE", ns
        ) or self._xpath_text(cfg, f"{ns}ActivationType", ns)

        # Logical addresses
        try:
            if ns_map:
                la_containers = cfg.xpath(
                    f".//{ns}DoIpLogicalAddress | .//{ns}DOIP-LOGICAL-ADDRESS",
                    namespaces=ns_map,
                )
            else:
                la_containers = cfg.xpath(
                    ".//DoIpLogicalAddress | .//DOIP-LOGICAL-ADDRESS"
                )
        except Exception:
            la_containers = []

        for la_el in la_containers:
            sn = self._xpath_text(la_el, f"{ns}SHORT-NAME", ns)
            if not sn:
                continue
            addr = self._xpath_int(la_el, f"{ns}ADDRESS", ns) or self._xpath_int(
                la_el, f"{ns}LOGICAL-ADDRESS", ns
            )
            ecu_ref = self._xpath_text(
                la_el, f"{ns}ECU-REF", ns
            ) or self._xpath_text(la_el, f"{ns}EcuRef", ns)
            config.logical_addresses.append(
                DoIpLogicalAddress(short_name=sn, address=addr, ecu_ref=ecu_ref)
            )

        # Routing activations
        try:
            if ns_map:
                ra_containers = cfg.xpath(
                    f".//{ns}DoIpRoutingActivation | .//{ns}DOIP-ROUTING-ACTIVATION",
                    namespaces=ns_map,
                )
            else:
                ra_containers = cfg.xpath(
                    ".//DoIpRoutingActivation | .//DOIP-ROUTING-ACTIVATION"
                )
        except Exception:
            ra_containers = []

        for ra_el in ra_containers:
            sn = self._xpath_text(ra_el, f"{ns}SHORT-NAME", ns)
            if not sn:
                continue
            act_num = self._xpath_int(
                ra_el, f"{ns}ACTIVATION-NUMBER", ns
            ) or self._xpath_int(ra_el, f"{ns}RoutingActivationNumber", ns)
            act_type = self._xpath_text(
                ra_el, f"{ns}ACTIVATION-TYPE", ns
            ) or self._xpath_text(ra_el, f"{ns}ActivationType", ns)
            config.routing_activations.append(
                DoIpRoutingActivation(
                    short_name=sn,
                    activation_number=act_num,
                    activation_type=act_type,
                )
            )

        return config


__all__ = [
    "DoIpConfig",
    "DoIpLogicalAddress",
    "DoIpRoutingActivation",
    "DoIpParser",
]
