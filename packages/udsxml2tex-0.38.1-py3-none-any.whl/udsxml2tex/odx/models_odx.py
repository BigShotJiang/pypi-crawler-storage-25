"""ODX 2.2.0 intermediate representation (ISO 22901-1 / ASAM MCD-2 D).

This module declares the dataclasses that mirror the ODX 2.2.0 XML schema
groups used by the ``udsxml2tex`` ODX/PDX exporters. It is intentionally
self-contained: no ARXML, generator or serialization logic lives here.

Eight ODX top-level categories are modelled:

* ODX-D   — Diagnostic data (DIAG-LAYER-CONTAINER and contents)
* ODX-CS  — Comparam subset
* ODX-C   — Comparam spec
* ODX-V   — Vehicle information
* ODX-E   — ECU shared data (re-uses DiagLayerBase)
* ODX-F   — Flash
* ODX-FD  — Function dictionary
* ODX-M   — Multiple ECU job spec

Each top-level category is materialised through :class:`OdxDocument`. The
dataclasses below carry only the fields the rest of the pipeline (mapper,
serializer, generator) actually consumes — there is no attempt to model the
full ODX schema exhaustively. Where ODX 2.2.0 distinguishes attributes such
as ``ID-REF``/``SNREF`` we expose two parallel optional fields (``dop_ref``
and ``dop_snref``) so writers can pick whichever form the target file uses.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------


class OdxCategory(str, Enum):
    """Top-level ODX 2.2.0 document categories (one .odx-* file per value)."""

    DIAG_LAYER = "DIAG_LAYER"          # .odx-d
    COMPARAM_SPEC = "COMPARAM_SPEC"    # .odx-c
    COMPARAM_SUBSET = "COMPARAM_SUBSET"  # .odx-cs
    VEHICLE_INFO = "VEHICLE_INFO"      # .odx-v
    ECU_SHARED_DATA = "ECU_SHARED_DATA"  # .odx-e (DiagLayerContainer of ECU-SHARED-DATA)
    FLASH = "FLASH"                     # .odx-f
    FUNCTION_DICTIONARY = "FUNCTION_DICTIONARY"  # .odx-fd
    MULTIPLE_ECU_JOB_SPEC = "MULTIPLE_ECU_JOB_SPEC"  # .odx-m


# Suffix per category (used by file writers to derive filenames).
ODX_CATEGORY_SUFFIX: dict[OdxCategory, str] = {
    OdxCategory.DIAG_LAYER: "odx-d",
    OdxCategory.COMPARAM_SPEC: "odx-c",
    OdxCategory.COMPARAM_SUBSET: "odx-cs",
    OdxCategory.VEHICLE_INFO: "odx-v",
    OdxCategory.ECU_SHARED_DATA: "odx-e",
    OdxCategory.FLASH: "odx-f",
    OdxCategory.FUNCTION_DICTIONARY: "odx-fd",
    OdxCategory.MULTIPLE_ECU_JOB_SPEC: "odx-m",
}


# ---------------------------------------------------------------------------
# Common building blocks (used by every category)
# ---------------------------------------------------------------------------


@dataclass
class OdxRef:
    """ODX 2.2.0 reference by OID (ID-REF / IDREF).

    Carries the optional ``DOCREF``/``DOCREF-TYPE`` cross-document attributes
    introduced in ODX 2.2.0 so writers can emit inter-file links.
    """

    id_ref: str
    docref: str | None = None
    docref_type: str | None = None  # e.g. "CONTAINER", "LAYER", "FLASH"


@dataclass
class SnRef:
    """ODX 2.2.0 reference by SHORT-NAME path (SNREF / SNPATHREF)."""

    short_name: str
    docref: str | None = None
    docref_type: str | None = None


@dataclass
class OdxId:
    """Identity bundle shared by virtually every ODX element."""

    oid: str
    short_name: str
    long_name: str | None = None
    description: str | None = None


@dataclass
class OdxDocFragment:
    """One document fragment inside a PDX archive (a single .odx-* member)."""

    category: OdxCategory
    pdx_member_path: str  # e.g. "ECU.odx-d"
    content: list[Any] = field(default_factory=list)


@dataclass
class DocRevision:
    """ADMIN-DATA / DOC-REVISIONS entry."""

    team_member_ref: str = ""
    revision_label: str = ""
    state: str = ""
    date: str = ""
    tool: str | None = None


@dataclass
class CompanyData:
    """ADMIN-DATA / COMPANY-DATAS / COMPANY-DATA element."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    roles: list[str] = field(default_factory=list)


@dataclass
class AdminData:
    """ADMIN-DATA block as it appears at the head of every ODX root."""

    language: str = "en-US"
    company_doc_infos: list[CompanyData] = field(default_factory=list)
    doc_revisions: list[DocRevision] = field(default_factory=list)


@dataclass
class SpecialDataGroup:
    """SDG — ODX's escape hatch for OEM/vendor-specific data (id+value pairs)."""

    caption: str = ""
    sd_items: list[tuple[str, str]] = field(default_factory=list)  # (SI, value)


# ---------------------------------------------------------------------------
# ODX-D: Diagnostic data
# ---------------------------------------------------------------------------


@dataclass
class Audience:
    """AUDIENCE element (per-service access control flags)."""

    enabled_audiences: list[str] = field(default_factory=list)
    disabled_audiences: list[str] = field(default_factory=list)
    is_supplier: bool = True
    is_development: bool = True
    is_manufacturing: bool = True
    is_aftersales: bool = True
    is_aftermarket: bool = True


@dataclass
class FunctionalClass:
    """FUNCT-CLASS — diagnostic service grouping marker."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None


@dataclass
class DiagCodedType:
    """DIAG-CODED-TYPE — wire-side coding (bits, byte order, base type)."""

    base_data_type: str = "A_UINT32"
    # subtype: STANDARD-LENGTH-TYPE | LEADING-LENGTH-INFO-TYPE
    #          | MIN-MAX-LENGTH-TYPE | PARAM-LENGTH-INFO-TYPE
    coded_type: str = "STANDARD-LENGTH-TYPE"
    bit_length: int | None = None
    min_length: int | None = None
    max_length: int | None = None
    termination: str | None = None  # END-OF-PDU / ZERO / HEX-FF
    is_highlow_byte_order: bool = True


@dataclass
class PhysicalType:
    """PHYSICAL-TYPE — application-facing representation of a value."""

    base_data_type: str = "A_UINT32"
    display_radix: str | None = None  # DEC / HEX / BIN / OCT
    precision: int | None = None


@dataclass
class CompuScale:
    """One COMPU-SCALE inside a COMPU-METHOD."""

    short_label: str | None = None
    lower_limit: str | None = None
    upper_limit: str | None = None
    compu_inverse_value: str | None = None
    compu_const: str | None = None  # text/value for TEXTTABLE entries
    compu_rational_coeffs: tuple[list[float], list[float]] | None = None
    # ``compu_rational_coeffs = (numerator, denominator)`` per ODX 2.2.0.


@dataclass
class CompuMethod:
    """COMPU-METHOD — internal ↔ physical conversion rule."""

    category: str = "IDENTICAL"
    # IDENTICAL / LINEAR / SCALE-LINEAR / TEXTTABLE / TAB-INTP /
    # RAT-FUNC / COMPUCODE
    compu_internal_to_phys: list[CompuScale] = field(default_factory=list)
    compu_phys_to_internal: list[CompuScale] = field(default_factory=list)
    compu_scales: list[CompuScale] = field(default_factory=list)


@dataclass
class Unit:
    """UNIT element."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    display_name: str = ""
    factor_si_to_unit: float | None = None
    offset_si_to_unit: float | None = None
    physical_dimension_ref: OdxRef | None = None


@dataclass
class UnitGroup:
    """UNIT-GROUP element."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    category: str = "COUNTRY"
    unit_refs: list[OdxRef] = field(default_factory=list)


@dataclass
class UnitSpec:
    """UNIT-SPEC — declares units, unit groups and physical dimensions."""

    units: list[Unit] = field(default_factory=list)
    unit_groups: list[UnitGroup] = field(default_factory=list)
    physical_dimensions: list[OdxId] = field(default_factory=list)


@dataclass
class DataObjectProp:
    """DATA-OBJECT-PROP (DOP) — value coding + scaling for one signal."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    description: str | None = None
    compu_method: CompuMethod = field(default_factory=CompuMethod)
    diag_coded_type: DiagCodedType = field(default_factory=DiagCodedType)
    physical_type: PhysicalType = field(default_factory=PhysicalType)
    internal_constr: tuple[str, str] | None = None  # (lower, upper)
    unit_ref: OdxRef | None = None
    sdgs: list[SpecialDataGroup] = field(default_factory=list)


@dataclass
class Dtc:
    """One DTC under a DTC-DOP."""

    oid: str = ""
    short_name: str = ""
    trouble_code: int = 0
    display_trouble_code: str = ""
    text: str = ""
    level: int | None = None
    is_temporary: bool = False
    sdgs: list[SpecialDataGroup] = field(default_factory=list)


@dataclass
class DtcDop:
    """DTC-DOP — DOP specialised for DTC tables."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    description: str | None = None
    diag_coded_type: DiagCodedType = field(default_factory=DiagCodedType)
    compu_method: CompuMethod = field(default_factory=CompuMethod)
    physical_type: PhysicalType = field(default_factory=PhysicalType)
    dtcs: list[Dtc] = field(default_factory=list)
    is_visible: bool = True


@dataclass
class Param:
    """PARAM — one byte/bit field inside a REQUEST or RESPONSE."""

    oid: str = ""
    short_name: str = ""
    byte_position: int = 0
    bit_position: int | None = None
    bit_length: int | None = None
    dop_ref: OdxRef | None = None
    dop_snref: SnRef | None = None
    semantic: str = ""  # "DATA", "SUBFUNCTION", "SERVICE-ID", ...
    param_kind: str = "VALUE"
    # VALUE / PHYS-CONST / CODED-CONST / RESERVED /
    # MATCHING-REQUEST-PARAM / TABLE-KEY / TABLE-STRUCT /
    # TABLE-ENTRY / NRC-CONST / LENGTH-KEY
    coded_value: int | None = None
    phys_constant_value: str | None = None
    request_byte_pos: int | None = None
    description: str | None = None


@dataclass
class Request:
    """REQUEST — the bytes a tester sends on the wire."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    params: list[Param] = field(default_factory=list)


@dataclass
class Response:
    """RESPONSE — positive, negative or global negative response."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    response_type: str = "POS-RESPONSE"  # POS-RESPONSE / NEG-RESPONSE / GLOBAL-NEG-RESPONSE
    params: list[Param] = field(default_factory=list)


@dataclass
class DiagService:
    """DIAG-SERVICE — one diagnostic service definition (request+response refs)."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    description: str | None = None
    semantic: str = ""  # "SERVICE" / "ROUTINECONTROL" / "DATA" / "DTC" / "OBD" / ...
    audience: Audience | None = None
    request_ref: OdxRef | None = None
    pos_response_refs: list[OdxRef] = field(default_factory=list)
    neg_response_refs: list[OdxRef] = field(default_factory=list)
    comparam_refs: list[OdxRef] = field(default_factory=list)
    functional_class_refs: list[OdxRef] = field(default_factory=list)
    sdgs: list[SpecialDataGroup] = field(default_factory=list)
    is_executable: bool = True
    addressing: str = "PHYSICAL"
    # PHYSICAL / FUNCTIONAL / PHYSICAL-AND-FUNCTIONAL
    transmission_mode: str = "SEND-AND-RECEIVE"
    # SEND-ONLY / RECEIVE-ONLY / SEND-AND-RECEIVE / SEND-OR-RECEIVE


@dataclass
class Structure:
    """STRUCTURE — composite DOP made of several params."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    byte_size: int | None = None
    params: list[Param] = field(default_factory=list)


@dataclass
class EndOfPduField:
    """END-OF-PDU-FIELD — a structure repeated until the end of the PDU."""

    oid: str = ""
    short_name: str = ""
    structure_ref: OdxRef | None = None
    min_number_of_items: int = 0
    max_number_of_items: int | None = None


@dataclass
class StaticField:
    """STATIC-FIELD — fixed-count repeating structure."""

    oid: str = ""
    short_name: str = ""
    structure_ref: OdxRef | None = None
    fixed_number_of_items: int = 1
    item_byte_size: int | None = None


@dataclass
class DynamicEndmarkerField:
    """DYNAMIC-ENDMARKER-FIELD — structure terminated by an endmarker pattern."""

    oid: str = ""
    short_name: str = ""
    structure_ref: OdxRef | None = None
    termination_value: str | None = None


@dataclass
class TableRow:
    """TABLE-ROW — one (key, structure-ref) entry in a TABLE."""

    oid: str = ""
    short_name: str = ""
    key: int | None = None
    structure_ref: OdxRef | None = None
    dop_ref: OdxRef | None = None
    description: str | None = None


@dataclass
class Table:
    """TABLE — lookup keyed by a DOP value (session table, security table, ...)."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    key_dop_ref: OdxRef | None = None
    table_rows: list[TableRow] = field(default_factory=list)


@dataclass
class MuxCase:
    """One MUX-CASE inside a MUX."""

    short_name: str = ""
    lower_limit: str | None = None
    upper_limit: str | None = None
    structure_ref: OdxRef | None = None


@dataclass
class Mux:
    """MUX — switched-payload data object."""

    oid: str = ""
    short_name: str = ""
    byte_position: int = 0
    switch_key: Param | None = None
    default_case: MuxCase | None = None
    cases: list[MuxCase] = field(default_factory=list)


@dataclass
class EnvDataDesc:
    """ENV-DATA-DESC — descriptor of an environment-data block."""

    oid: str = ""
    short_name: str = ""
    param_snref: SnRef | None = None
    env_data_refs: list[OdxRef] = field(default_factory=list)


@dataclass
class EnvData:
    """ENV-DATA — one env-data instance."""

    oid: str = ""
    short_name: str = ""
    params: list[Param] = field(default_factory=list)


@dataclass
class DiagDataDictionarySpec:
    """DIAG-DATA-DICTIONARY-SPEC — pool of DOPs / structures / tables / units."""

    data_object_props: list[DataObjectProp] = field(default_factory=list)
    dtc_dops: list[DtcDop] = field(default_factory=list)
    structures: list[Structure] = field(default_factory=list)
    end_of_pdu_fields: list[EndOfPduField] = field(default_factory=list)
    dynamic_endmarker_fields: list[DynamicEndmarkerField] = field(default_factory=list)
    static_fields: list[StaticField] = field(default_factory=list)
    env_data_descs: list[EnvDataDesc] = field(default_factory=list)
    env_datas: list[EnvData] = field(default_factory=list)
    muxes: list[Mux] = field(default_factory=list)
    tables: list[Table] = field(default_factory=list)
    unit_spec: UnitSpec | None = None


@dataclass
class EcuVariantPattern:
    """ECU-VARIANT-PATTERN — pattern that selects an EcuVariant at runtime."""

    matching_parameters: list[tuple[str, str]] = field(default_factory=list)
    # (dop_ref_or_snref, expected_value)


@dataclass
class DiagLayerBase:
    """Common base for every DIAG-LAYER (BASE-VARIANT, ECU-VARIANT, ...).

    ODX 2.2.0 defines BASE-VARIANT, ECU-VARIANT, PROTOCOL, FUNCTIONAL-GROUP
    and ECU-SHARED-DATA as DIAG-LAYER specialisations that all share the
    same content groups (admin data, DOP dictionary, diag-comms, ...).
    The mapper builds these by populating this dataclass and then wrapping
    it in the appropriate specialisation below.
    """

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    description: str | None = None
    admin_data: AdminData | None = None
    company_datas: list[CompanyData] = field(default_factory=list)
    sdgs: list[SpecialDataGroup] = field(default_factory=list)
    functional_classes: list[FunctionalClass] = field(default_factory=list)
    audience: Audience | None = None
    diag_data_dictionary_spec: DiagDataDictionarySpec | None = None
    diag_comms: list[DiagService] = field(default_factory=list)
    requests: list[Request] = field(default_factory=list)
    pos_responses: list[Response] = field(default_factory=list)
    neg_responses: list[Response] = field(default_factory=list)
    global_neg_responses: list[Response] = field(default_factory=list)
    import_refs: list[OdxRef] = field(default_factory=list)
    parent_refs: list[OdxRef] = field(default_factory=list)
    comparam_refs: list[OdxRef] = field(default_factory=list)
    ecu_variant_patterns: list[EcuVariantPattern] = field(default_factory=list)


@dataclass
class BaseVariant(DiagLayerBase):
    """BASE-VARIANT — variant-independent layer (shared services and DOPs)."""

    base_variant_pattern: EcuVariantPattern | None = None


@dataclass
class EcuVariant(DiagLayerBase):
    """ECU-VARIANT — concrete ECU variant; inherits a BASE-VARIANT."""

    base_variant_ref: OdxRef | None = None


@dataclass
class Protocol(DiagLayerBase):
    """PROTOCOL — protocol-layer variant (UDS-on-CAN, UDS-on-IP, ...)."""

    pass


@dataclass
class FunctionalGroup(DiagLayerBase):
    """FUNCTIONAL-GROUP — non-physical grouping for cross-ECU services."""

    pass


@dataclass
class EcuSharedData(DiagLayerBase):
    """ECU-SHARED-DATA — DOPs/services shared across multiple ECUs."""

    pass


@dataclass
class DiagLayerContainer:
    """DIAG-LAYER-CONTAINER — the root of an ODX-D document."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    description: str | None = None
    admin_data: AdminData | None = None
    company_datas: list[CompanyData] = field(default_factory=list)
    ecu_shared_datas: list[EcuSharedData] = field(default_factory=list)
    protocols: list[Protocol] = field(default_factory=list)
    functional_groups: list[FunctionalGroup] = field(default_factory=list)
    base_variants: list[BaseVariant] = field(default_factory=list)
    ecu_variants: list[EcuVariant] = field(default_factory=list)
    ecu_shared_data_refs: list[OdxRef] = field(default_factory=list)
    protocol_refs: list[OdxRef] = field(default_factory=list)
    functional_group_refs: list[OdxRef] = field(default_factory=list)


# ---------------------------------------------------------------------------
# ODX-C / ODX-CS: Comparam spec / subset
# ---------------------------------------------------------------------------


@dataclass
class Comparam:
    """COMPARAM — one communication parameter (timing, flow-control, ...)."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    description: str | None = None
    param_class: str = ""        # e.g. "TIMING", "FUNCTIONAL"
    cptype: str = "STANDARD"      # STANDARD / OPTIONAL / SYSTEM
    physical_default_value: str | None = None
    dop_ref: OdxRef | None = None


@dataclass
class ComplexComparam:
    """COMPLEX-COMPARAM — comparam composed of nested comparams."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    cptype: str = "STANDARD"
    sub_comparams: list[Comparam] = field(default_factory=list)


@dataclass
class ProtocolStack:
    """PROTOCOL-STACK — physical/link layer definition referenced by Protocol."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    pdu_protocol_type: str = ""    # e.g. "ISO_15765_2"
    physical_link_type: str = ""    # e.g. "ISO_11898_2_DWCAN"


@dataclass
class ComparamSubset:
    """COMPARAM-SUBSET — concrete subset (e.g. ISO_15765_2 timing params)."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    description: str | None = None
    category: str = ""       # subset name like "ISO_15765_2"
    comparams: list[Comparam] = field(default_factory=list)
    complex_comparams: list[ComplexComparam] = field(default_factory=list)
    data_object_props: list[DataObjectProp] = field(default_factory=list)
    unit_spec: UnitSpec | None = None


@dataclass
class ComparamSpec:
    """COMPARAM-SPEC — the root of an ODX-C document."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    description: str | None = None
    comparams: list[Comparam] = field(default_factory=list)
    comparam_subsets: list[ComparamSubset] = field(default_factory=list)
    protocol_stacks: list[ProtocolStack] = field(default_factory=list)


# ---------------------------------------------------------------------------
# ODX-V: Vehicle information
# ---------------------------------------------------------------------------


@dataclass
class VehicleConnector:
    """VEHICLE-CONNECTOR — physical socket on the vehicle (e.g. OBD-II)."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    connector_type: str = ""  # e.g. "ISO-15031-3"
    pins: list[tuple[int, str]] = field(default_factory=list)  # (pin_no, signal)


@dataclass
class PhysicalVehicleLink:
    """PHYSICAL-VEHICLE-LINK — physical bus connecting tester to ECU."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    vehicle_connector_ref: OdxRef | None = None
    link_type: str = ""
    # ISO-13400-2-DoIP / ISO-15765-2-on-ISO-11898-2-DWCAN / ISO-14230-2-K-Line / ...


@dataclass
class ComparamRefValuePair:
    """One (comparam-ref, physical-value) override on a logical link."""

    comparam_ref: OdxRef
    value: str


@dataclass
class LogicalLink:
    """LOGICAL-LINK — testers communicate with an ECU through a logical link."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    link_type: str = "MEMBER-LOGICAL-LINK"
    physical_vehicle_link_ref: OdxRef | None = None
    base_variant_ref: OdxRef | None = None
    protocol_ref: OdxRef | None = None
    comparam_ref_value_pairs: list[ComparamRefValuePair] = field(default_factory=list)


@dataclass
class VehicleInformation:
    """VEHICLE-INFORMATION — a vehicle's diagnostic logical link map."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    logical_links: list[LogicalLink] = field(default_factory=list)


@dataclass
class Vehicle:
    """VEHICLE — a specific vehicle (VIN, model year, ...)."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    model_year: int | None = None
    vin: str | None = None
    model: str | None = None
    manufacturer: str | None = None
    vehicle_connectors: list[VehicleConnector] = field(default_factory=list)
    vehicle_information_refs: list[OdxRef] = field(default_factory=list)


@dataclass
class OemVersion:
    """OEM-VERSION — OEM-specific version stamp inside ODX-V."""

    oid: str = ""
    short_name: str = ""
    label: str = ""
    value: str = ""


@dataclass
class InfoComponent:
    """INFO-COMPONENT — vehicle metadata such as model/version/year."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    category: str = ""
    value: str = ""


@dataclass
class VehicleInfoSpec:
    """VEHICLE-INFO-SPEC — the root of an ODX-V document."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    description: str | None = None
    info_components: list[InfoComponent] = field(default_factory=list)
    vehicle_informations: list[VehicleInformation] = field(default_factory=list)
    vehicles: list[Vehicle] = field(default_factory=list)
    physical_vehicle_links: list[PhysicalVehicleLink] = field(default_factory=list)
    oem_versions: list[OemVersion] = field(default_factory=list)


# ---------------------------------------------------------------------------
# ODX-F: Flash
# ---------------------------------------------------------------------------


@dataclass
class Segment:
    """SEGMENT — one address range inside a FLASHDATA / ECU-MEM."""

    oid: str = ""
    short_name: str = ""
    source_start_address: int = 0
    source_end_address: int = 0
    target_start_address: int = 0
    target_end_address: int = 0
    size_length: int = 4
    encrypt_compress_method: str = ""


@dataclass
class Flashdata:
    """FLASHDATA — the data block flashed to an ECU."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    format_id: str = ""           # INTEL-HEX / MOTOROLA-S / BINARY
    encryption_type: str = ""
    compression_type: str = ""
    encrypt_compress_method: str = ""
    datafile: str | None = None


@dataclass
class EcuMem:
    """ECU-MEM — declared memory layout of an ECU (segments)."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    segments: list[Segment] = field(default_factory=list)


@dataclass
class EcuMemConnector:
    """ECU-MEM-CONNECTOR — maps an ECU-MEM into a DIAG-LAYER."""

    oid: str = ""
    short_name: str = ""
    ecu_mem_ref: OdxRef | None = None
    diag_layer_refs: list[OdxRef] = field(default_factory=list)


@dataclass
class FlashSession:
    """SESSION (under FLASH) — one bootloader programming session."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    security_method: str = ""        # e.g. "SEED_KEY"
    expected_idents: list[str] = field(default_factory=list)
    segment_refs: list[OdxRef] = field(default_factory=list)
    source_starts_at: int | None = None


@dataclass
class FlashClass:
    """FLASH-CLASS — root of an ODX-F document."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    description: str | None = None
    ecu_mems: list[EcuMem] = field(default_factory=list)
    ecu_mem_connectors: list[EcuMemConnector] = field(default_factory=list)
    flashdatas: list[Flashdata] = field(default_factory=list)
    sessions: list[FlashSession] = field(default_factory=list)
    download_id_codes: list[str] = field(default_factory=list)
    ecu_mem_ref: OdxRef | None = None


# ---------------------------------------------------------------------------
# ODX-FD: Function dictionary
# ---------------------------------------------------------------------------


@dataclass
class FunctionNode:
    """FUNCTION-NODE — one diagnostic function inside a FUNCTION-GROUP."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    description: str | None = None
    service_refs: list[OdxRef] = field(default_factory=list)


@dataclass
class FunctionGroup:
    """FUNCTION-GROUP — collection of diagnostic FunctionNodes."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    description: str | None = None
    function_nodes: list[FunctionNode] = field(default_factory=list)


@dataclass
class AudienceGroup:
    """AUDIENCE-GROUP — collection of audiences used by function nodes."""

    oid: str = ""
    short_name: str = ""
    audiences: list[Audience] = field(default_factory=list)


@dataclass
class FunctionDictionarySpec:
    """FUNCTION-DICTIONARY-SPEC — root of an ODX-FD document."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    description: str | None = None
    function_groups: list[FunctionGroup] = field(default_factory=list)
    audience_groups: list[AudienceGroup] = field(default_factory=list)


# ---------------------------------------------------------------------------
# ODX-M: Multiple ECU job spec
# ---------------------------------------------------------------------------


@dataclass
class EcuState:
    """ECU-STATE — one named state inside an ECU-STATE-CHART."""

    oid: str = ""
    short_name: str = ""
    description: str | None = None


@dataclass
class ProgCode:
    """PROG-CODE — script payload executed by a MultipleEcuJob."""

    oid: str = ""
    short_name: str = ""
    code_file: str = ""
    encryption: str = ""
    syntax: str = ""              # e.g. "JAVA", "PYTHON"
    revision: str = ""


@dataclass
class ProgrammingStep:
    """One programming step inside a multiple-ECU job."""

    oid: str = ""
    short_name: str = ""
    description: str | None = None
    prog_code_ref: OdxRef | None = None
    target_ecu_refs: list[OdxRef] = field(default_factory=list)


@dataclass
class MultipleEcuJob:
    """MULTIPLE-ECU-JOB — one cross-ECU diagnostic procedure."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    description: str | None = None
    programming_steps: list[ProgrammingStep] = field(default_factory=list)


@dataclass
class MultipleEcuJobSpec:
    """MULTIPLE-ECU-JOB-SPEC — root of an ODX-M document."""

    oid: str = ""
    short_name: str = ""
    long_name: str | None = None
    description: str | None = None
    ecu_states: list[EcuState] = field(default_factory=list)
    multiple_ecu_jobs: list[MultipleEcuJob] = field(default_factory=list)
    prog_codes: list[ProgCode] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Top-level document
# ---------------------------------------------------------------------------


@dataclass
class OdxDocument:
    """One ODX 2.2.0 document (== one .odx-* file inside a PDX archive)."""

    category: OdxCategory = OdxCategory.DIAG_LAYER
    model_version: str = "2.2.0"
    # exactly one of the *_content fields below is set, depending on `category`:
    diag_layer_container: DiagLayerContainer | None = None
    comparam_spec: ComparamSpec | None = None
    comparam_subset: ComparamSubset | None = None
    vehicle_info_spec: VehicleInfoSpec | None = None
    flash_class: FlashClass | None = None
    function_dictionary_spec: FunctionDictionarySpec | None = None
    multiple_ecu_job_spec: MultipleEcuJobSpec | None = None
    # convenience meta:
    pdx_member_path: str = ""    # filename inside a PDX archive
    admin_data: AdminData | None = None

    @property
    def file_suffix(self) -> str:
        """Return the .odx-* file suffix for this document's category."""
        return ODX_CATEGORY_SUFFIX[self.category]

    @property
    def content(self) -> Any:
        """Return the populated category-specific root element (or None)."""
        return (
            self.diag_layer_container
            or self.comparam_spec
            or self.comparam_subset
            or self.vehicle_info_spec
            or self.flash_class
            or self.function_dictionary_spec
            or self.multiple_ecu_job_spec
        )
