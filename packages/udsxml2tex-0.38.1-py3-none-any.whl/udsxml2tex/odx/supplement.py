"""YAML supplement loader for ODX/PDX data not derivable from ARXML.

ARXML cannot supply every piece of information required by an ODX/PDX
archive (e.g. VIN, vehicle model year, flash-segment addresses, function
groups). This module defines a small dataclass tree that captures those
extras plus a YAML loader.

YAML schema (top-level keys are all optional):

.. code-block:: yaml

    vehicle:
      vin: "WAUZZZ8K0XA000001"
      model_year: 2025
      model: "ExampleCar"
      manufacturer: "ExampleOEM"
      vehicle_connectors:
        - short_name: "OBD2_Connector"
          type: "ISO-15031-3"

    flash:
      ecu_mem:
        short_name: "MainMemory"
        segments:
          - short_name: "ApplSeg1"
            source_start_address: 0x00100000
            source_end_address:   0x001FFFFF
            target_start_address: 0x00100000
            target_end_address:   0x001FFFFF
      sessions:
        - short_name: "ProgrammingSession"
          security_method: "SEED_KEY"
          expected_idents: ["SW_VERSION_X.Y"]

    functional_groups:
      - short_name: "Powertrain"
        ecus: ["EngineECU", "TransmissionECU"]

    company_data:
      short_name: "ExampleOEM"
      long_name: "Example OEM Corporation"
      roles: ["MANUFACTURER"]

    physical_vehicle_links:
      - short_name: "ISOTP_500K"
        link_type: "ISO-15765-2-on-ISO-11898-2-DWCAN"
        bitrate: 500000

Both integer and ``0x``-prefixed string addresses are accepted for any
``*_address`` field. ``load_supplement`` raises :class:`ImportError`
with a clear message when PyYAML is not installed; the rest of the
``udsxml2tex.odx`` package keeps working in that case.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Supplement dataclasses
# ---------------------------------------------------------------------------


@dataclass
class VehicleConnectorSupplement:
    """Vehicle connector entry coming from the supplement YAML."""

    short_name: str
    connector_type: str = ""
    long_name: str | None = None


@dataclass
class VehicleSupplement:
    """``vehicle:`` section of the supplement YAML."""

    vin: str | None = None
    model_year: int | None = None
    model: str | None = None
    manufacturer: str | None = None
    short_name: str | None = None  # explicit ODX short-name override
    vehicle_connectors: list[VehicleConnectorSupplement] = field(default_factory=list)


@dataclass
class FlashSegmentSupplement:
    """One segment under ``flash.ecu_mem.segments``."""

    short_name: str
    source_start_address: int = 0
    source_end_address: int = 0
    target_start_address: int = 0
    target_end_address: int = 0
    size_length: int = 4
    encrypt_compress_method: str = ""


@dataclass
class EcuMemSupplement:
    """``flash.ecu_mem`` section of the supplement YAML."""

    short_name: str = "EcuMem"
    long_name: str | None = None
    segments: list[FlashSegmentSupplement] = field(default_factory=list)


@dataclass
class FlashSessionSupplement:
    """One entry under ``flash.sessions``."""

    short_name: str
    security_method: str = ""
    expected_idents: list[str] = field(default_factory=list)


@dataclass
class FlashSupplement:
    """``flash:`` section of the supplement YAML."""

    ecu_mem: EcuMemSupplement | None = None
    sessions: list[FlashSessionSupplement] = field(default_factory=list)


@dataclass
class FunctionalGroupSupplement:
    """One entry under ``functional_groups`` (cross-ECU function grouping)."""

    short_name: str
    long_name: str | None = None
    description: str | None = None
    ecus: list[str] = field(default_factory=list)


@dataclass
class CompanyDataSupplement:
    """``company_data:`` section — ODX ADMIN-DATA / COMPANY-DATA entry."""

    short_name: str = "Unknown"
    long_name: str | None = None
    roles: list[str] = field(default_factory=list)


@dataclass
class PhysicalVehicleLinkSupplement:
    """One entry under ``physical_vehicle_links``."""

    short_name: str
    link_type: str = "ISO-15765-2-on-ISO-11898-2-DWCAN"
    bitrate: int | None = None
    vehicle_connector_ref: str | None = None


@dataclass
class OdxSupplement:
    """Aggregate supplement loaded from a single YAML file.

    All fields default to None/empty so that the mapper can simply consult
    them and skip whatever the user did not specify. Use
    :func:`empty_supplement` when no YAML is given on the CLI.
    """

    vehicle: VehicleSupplement | None = None
    flash: FlashSupplement | None = None
    functional_groups: list[FunctionalGroupSupplement] = field(default_factory=list)
    company_data: CompanyDataSupplement | None = None
    physical_vehicle_links: list[PhysicalVehicleLinkSupplement] = field(default_factory=list)


# ---------------------------------------------------------------------------
# YAML loader
# ---------------------------------------------------------------------------


def empty_supplement() -> OdxSupplement:
    """Return an :class:`OdxSupplement` with every section unset.

    Used by the mapper when ``--odx-supplement`` is not given on the CLI.
    """
    return OdxSupplement()


def _to_int(value: Any, default: int = 0) -> int:
    """Coerce a YAML scalar (int or '0x..'/'0o..' string) to int."""
    if value is None:
        return default
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        s = value.strip()
        if not s:
            return default
        return int(s, 0)
    return int(value)


def _to_str_list(value: Any) -> list[str]:
    """Normalise a list-of-strings YAML field."""
    if not value:
        return []
    if isinstance(value, str):
        return [value]
    return [str(v) for v in value]


def _parse_vehicle(data: dict | None) -> VehicleSupplement | None:
    if not data:
        return None
    connectors = [
        VehicleConnectorSupplement(
            short_name=str(c.get("short_name", "")),
            connector_type=str(c.get("type", c.get("connector_type", ""))),
            long_name=c.get("long_name"),
        )
        for c in (data.get("vehicle_connectors") or [])
    ]
    return VehicleSupplement(
        vin=data.get("vin"),
        model_year=(int(data["model_year"]) if data.get("model_year") is not None else None),
        model=data.get("model"),
        manufacturer=data.get("manufacturer"),
        short_name=data.get("short_name"),
        vehicle_connectors=connectors,
    )


def _parse_segment(data: dict) -> FlashSegmentSupplement:
    return FlashSegmentSupplement(
        short_name=str(data.get("short_name", "")),
        source_start_address=_to_int(data.get("source_start_address")),
        source_end_address=_to_int(data.get("source_end_address")),
        target_start_address=_to_int(
            data.get("target_start_address", data.get("source_start_address"))
        ),
        target_end_address=_to_int(
            data.get("target_end_address", data.get("source_end_address"))
        ),
        size_length=_to_int(data.get("size_length"), 4),
        encrypt_compress_method=str(data.get("encrypt_compress_method", "")),
    )


def _parse_flash(data: dict | None) -> FlashSupplement | None:
    if not data:
        return None
    ecu_mem_data = data.get("ecu_mem")
    ecu_mem = None
    if ecu_mem_data:
        segs = [_parse_segment(s) for s in (ecu_mem_data.get("segments") or [])]
        ecu_mem = EcuMemSupplement(
            short_name=str(ecu_mem_data.get("short_name", "EcuMem")),
            long_name=ecu_mem_data.get("long_name"),
            segments=segs,
        )
    sessions = [
        FlashSessionSupplement(
            short_name=str(s.get("short_name", "")),
            security_method=str(s.get("security_method", "")),
            expected_idents=_to_str_list(s.get("expected_idents")),
        )
        for s in (data.get("sessions") or [])
    ]
    return FlashSupplement(ecu_mem=ecu_mem, sessions=sessions)


def _parse_functional_groups(data: Any) -> list[FunctionalGroupSupplement]:
    return [
        FunctionalGroupSupplement(
            short_name=str(g.get("short_name", "")),
            long_name=g.get("long_name"),
            description=g.get("description"),
            ecus=_to_str_list(g.get("ecus")),
        )
        for g in (data or [])
    ]


def _parse_company_data(data: dict | None) -> CompanyDataSupplement | None:
    if not data:
        return None
    return CompanyDataSupplement(
        short_name=str(data.get("short_name", "Unknown")),
        long_name=data.get("long_name"),
        roles=_to_str_list(data.get("roles")),
    )


def _parse_physical_vehicle_links(data: Any) -> list[PhysicalVehicleLinkSupplement]:
    out: list[PhysicalVehicleLinkSupplement] = []
    for ln in (data or []):
        bitrate = ln.get("bitrate")
        out.append(
            PhysicalVehicleLinkSupplement(
                short_name=str(ln.get("short_name", "")),
                link_type=str(ln.get("link_type", "ISO-15765-2-on-ISO-11898-2-DWCAN")),
                bitrate=(_to_int(bitrate) if bitrate is not None else None),
                vehicle_connector_ref=ln.get("vehicle_connector_ref"),
            )
        )
    return out


def load_supplement(path: str | Path) -> OdxSupplement:
    """Load an :class:`OdxSupplement` from a YAML file.

    :param path: path to the YAML file.
    :returns: populated :class:`OdxSupplement`. Missing top-level keys are
        kept as ``None`` / empty list so the mapper can skip them silently.
    :raises ImportError: if PyYAML is not installed (declare the ``yaml``
        or ``web`` extra to enable this functionality).
    :raises FileNotFoundError: when ``path`` does not exist.
    """
    try:
        import yaml  # lazy import; PyYAML is in the [yaml] / [web] extras
    except ImportError as exc:  # pragma: no cover - exercised by environment-specific tests
        raise ImportError(
            "PyYAML is required to load an ODX supplement. "
            "Install it via `pip install udsxml2tex[yaml]`."
        ) from exc

    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"ODX supplement YAML not found: {p}")

    with p.open("r", encoding="utf-8") as fh:
        raw = yaml.safe_load(fh) or {}

    if not isinstance(raw, dict):
        raise ValueError(
            f"ODX supplement YAML must be a mapping at the top level, got {type(raw).__name__}"
        )

    return OdxSupplement(
        vehicle=_parse_vehicle(raw.get("vehicle")),
        flash=_parse_flash(raw.get("flash")),
        functional_groups=_parse_functional_groups(raw.get("functional_groups")),
        company_data=_parse_company_data(raw.get("company_data")),
        physical_vehicle_links=_parse_physical_vehicle_links(raw.get("physical_vehicle_links")),
    )
