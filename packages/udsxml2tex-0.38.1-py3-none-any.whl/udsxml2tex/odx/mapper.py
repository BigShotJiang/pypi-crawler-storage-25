"""Mapper from ``UdsSpecification`` to the ODX 2.2.0 intermediate representation.

This module is the bridge between the existing ``udsxml2tex`` ARXML-derived
data model (``UdsSpecification`` and friends) and the ODX dataclasses in
:mod:`udsxml2tex.odx.models_odx`. It produces one or more
:class:`OdxDocument` instances keyed by the .odx-* filename they would
occupy inside a PDX archive. Downstream agents are responsible for
serialising the IR to XML.

Design points worth knowing:

* The mapper is **pure** — no I/O, no global state. Reruns produce
  byte-identical OIDs and short names for the same input.
* Every ODX short name is sanitised: ``[A-Za-z][A-Za-z0-9_]*``, capped at
  128 chars. Names that start with a digit gain an ``ECU_`` prefix.
* The mapper is **tolerant** — every input collection on
  ``UdsSpecification`` defaults to empty, so an almost-empty spec still
  produces a valid (if sparse) ODX-D document. Missing optional
  configuration (CanTp / DoIP / OBD / Comm / AP) is silently skipped.
* Multi-ECU support: :func:`map_ecu_system_to_odx` accepts an
  ``EcuSystem`` and emits one ``EcuVariant`` per ECU under a single
  ``DiagLayerContainer`` (plus shared comparam/vehicle docs).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from udsxml2tex.models import (
    CanTpChannel,
    CanTpConfig,
    DemDtcEntry,
    DiagSession,
    Did,
    DoIpConfig,
    DtcDefinition,
    MemoryRange,
    NrcEntry,
    Routine,
    SecurityLevel,
    UdsService,
    UdsSpecification,
)
from udsxml2tex.odx.models_odx import (
    AdminData,
    BaseVariant,
    CompanyData,
    Comparam,
    ComparamSubset,
    CompuMethod,
    DataObjectProp,
    DiagCodedType,
    DiagDataDictionarySpec,
    DiagLayerContainer,
    DiagService,
    DocRevision,
    Dtc,
    DtcDop,
    EcuMem,
    EcuVariant,
    FlashClass,
    FlashSession,
    FunctionalClass,
    FunctionDictionarySpec,
    FunctionGroup,
    FunctionNode,
    LogicalLink,
    OdxCategory,
    OdxDocument,
    OdxRef,
    Param,
    PhysicalType,
    PhysicalVehicleLink,
    Protocol,
    Request,
    Response,
    Segment,
    SpecialDataGroup,
    Structure,
    Table,
    TableRow,
    Unit,
    UnitSpec,
    Vehicle,
    VehicleConnector,
    VehicleInformation,
    VehicleInfoSpec,
)
from udsxml2tex.odx.supplement import (
    OdxSupplement,
    empty_supplement,
)

try:  # pragma: no cover - optional dependency
    from udsxml2tex.multi_ecu.models import EcuSystem
except Exception:  # pragma: no cover
    EcuSystem = None  # type: ignore[misc, assignment]


# ---------------------------------------------------------------------------
# Constants and lookup tables
# ---------------------------------------------------------------------------

_VALID_SHORT_NAME = re.compile(r"^[A-Za-z][A-Za-z0-9_]*$")
_INVALID_CHARS = re.compile(r"[^A-Za-z0-9_]")
ODX_SHORT_NAME_MAX_LENGTH = 128

# UdsSpecification.data_type → ODX base_data_type
_BASE_DATA_TYPE_MAP: dict[str, str] = {
    "uint8": "A_UINT32",
    "uint16": "A_UINT32",
    "uint32": "A_UINT32",
    "uint64": "A_UINT32",
    "int8": "A_INT32",
    "int16": "A_INT32",
    "int32": "A_INT32",
    "int64": "A_INT32",
    "float32": "A_FLOAT32",
    "float": "A_FLOAT32",
    "float64": "A_FLOAT64",
    "double": "A_FLOAT64",
    "string": "A_ASCIISTRING",
    "ascii": "A_ASCIISTRING",
    "utf16": "A_UNICODE2STRING",
    "unicode": "A_UNICODE2STRING",
    "bytes": "A_BYTEFIELD",
    "raw": "A_BYTEFIELD",
    "bool": "A_UINT32",
    "boolean": "A_UINT32",
}

# bit length per data type (when not derivable from DataElement.bit_size)
_BIT_LENGTH_HINT: dict[str, int] = {
    "uint8": 8, "int8": 8, "bool": 1, "boolean": 1,
    "uint16": 16, "int16": 16,
    "uint32": 32, "int32": 32, "float32": 32, "float": 32,
    "uint64": 64, "int64": 64, "float64": 64, "double": 64,
}

# ISO 14229-1 SID → ODX semantic
_UDS_SID_TO_SEMANTIC: dict[int, str] = {
    0x10: "SESSION",
    0x11: "RESET",
    0x14: "CLEARDTC",
    0x19: "DTC",
    0x22: "DATA",
    0x23: "MEMORY",
    0x24: "DATA",
    0x27: "SECURITY",
    0x28: "COMMUNICATIONCTRL",
    0x29: "AUTHENTICATION",
    0x2A: "DATA",
    0x2C: "DATA",
    0x2E: "DATA",
    0x2F: "IOCTRL",
    0x31: "ROUTINECONTROL",
    0x34: "DOWNLOAD",
    0x35: "UPLOAD",
    0x36: "TRANSFERDATA",
    0x37: "TRANSFEREXIT",
    0x38: "FILETRANSFER",
    0x3D: "MEMORY",
    0x3E: "TESTERPRESENT",
    0x84: "SECUREDDATATRANSMISSION",
    0x85: "DTCSETTING",
    0x86: "ROE",
    0x87: "LINKCONTROL",
}


# ---------------------------------------------------------------------------
# Helpers (public so other agents can reuse them)
# ---------------------------------------------------------------------------


def sanitize_short_name(value: str | None, fallback: str = "Unnamed") -> str:
    """Coerce ``value`` into an ODX 2.2.0-compliant short name.

    Rules enforced (per ODX 2.2.0 §H.2.4):

    * pattern ``[A-Za-z][A-Za-z0-9_]*``
    * maximum length 128 characters
    * empty / None / numeric-leading inputs receive an ``ECU_`` or
      ``fallback`` prefix
    """
    if not value or not str(value).strip():
        return fallback

    s = str(value).strip()
    # Replace runs of invalid characters with single underscore.
    cleaned = _INVALID_CHARS.sub("_", s)
    # Collapse runs of underscores so we don't accidentally produce names
    # like ``A__B__C``.
    cleaned = re.sub(r"_+", "_", cleaned).strip("_")
    if not cleaned:
        return fallback
    if not cleaned[0].isalpha():
        cleaned = "ECU_" + cleaned
    if len(cleaned) > ODX_SHORT_NAME_MAX_LENGTH:
        cleaned = cleaned[:ODX_SHORT_NAME_MAX_LENGTH]
    # Final guard: if truncation broke the leading-letter rule, restore it.
    if not _VALID_SHORT_NAME.match(cleaned):
        return fallback
    return cleaned


def make_oid(category: str, kind: str, short_name: str) -> str:
    """Build a deterministic ODX OID string.

    OIDs are stable across reruns because every component is derived from
    ``UdsSpecification`` content with no use of random IDs, timestamps or
    object addresses.
    """
    safe = sanitize_short_name(short_name)
    return f"udsxml2tex.odx.{category}.{kind}.{safe}"


def dop_key(data_type: str, unit: str, coding: str) -> str:
    """Stable dedupe key for DOPs sharing data_type/unit/coding.

    DOPs are interned per (type, unit, coding) tuple so a spec with hundreds
    of DIDs reusing ``uint16/rpm`` produces a single DOP rather than one
    per element.
    """
    return f"{(data_type or 'uint8').lower()}|{(unit or '').lower()}|{(coding or '').lower()}"


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _format_int_hex(value: int, width: int = 2) -> str:
    return f"0x{value:0{width}X}"


def _coded_value_const_param(
    name: str,
    byte_position: int,
    coded_value: int,
    semantic: str,
    bit_length: int = 8,
) -> Param:
    """Build a CODED-CONST PARAM (used for SID and sub-function bytes)."""
    return Param(
        oid=make_oid("d", "param", f"{name}_const_{coded_value}"),
        short_name=sanitize_short_name(name),
        byte_position=byte_position,
        bit_length=bit_length,
        semantic=semantic,
        param_kind="CODED-CONST",
        coded_value=coded_value,
    )


def _value_param(
    name: str,
    byte_position: int,
    dop_ref_oid: str,
    *,
    bit_position: int | None = None,
    bit_length: int | None = None,
    semantic: str = "DATA",
    description: str | None = None,
) -> Param:
    """Build a VALUE PARAM that points at a DOP via OID."""
    return Param(
        oid=make_oid("d", "param", f"{name}_v{byte_position}"),
        short_name=sanitize_short_name(name),
        byte_position=byte_position,
        bit_position=bit_position,
        bit_length=bit_length,
        dop_ref=OdxRef(id_ref=dop_ref_oid),
        semantic=semantic,
        param_kind="VALUE",
        description=description,
    )


@dataclass
class _DopRegistry:
    """Per-mapper interning table for DOPs (dedupe by data_type/unit/coding)."""

    by_key: dict[str, DataObjectProp] = field(default_factory=dict)

    def get_or_create(self, data_type: str, unit: str, coding: str,
                      bit_length: int | None = None) -> DataObjectProp:
        key = dop_key(data_type, unit, coding)
        if key in self.by_key:
            return self.by_key[key]

        base = _BASE_DATA_TYPE_MAP.get((data_type or "uint8").lower(), "A_UINT32")
        bits = bit_length or _BIT_LENGTH_HINT.get((data_type or "uint8").lower(), 8)
        unit_tag = sanitize_short_name(unit or "raw", fallback="raw")
        coding_tag = sanitize_short_name(coding or "ident", fallback="ident")
        short_name = sanitize_short_name(f"DOP_{data_type}_{unit_tag}_{coding_tag}")
        dop = DataObjectProp(
            oid=make_oid("d", "dop", short_name),
            short_name=short_name,
            long_name=f"DOP for {data_type} ({unit or 'no unit'})",
            description=f"Auto-generated DOP. coding={coding or 'identical'}",
            diag_coded_type=DiagCodedType(
                base_data_type=base,
                coded_type="STANDARD-LENGTH-TYPE",
                bit_length=bits,
            ),
            physical_type=PhysicalType(base_data_type=base),
            compu_method=CompuMethod(category="IDENTICAL"),
            unit_ref=(OdxRef(id_ref=make_oid("d", "unit", unit)) if unit else None),
        )
        self.by_key[key] = dop
        return dop


# ---------------------------------------------------------------------------
# Per-element converters
# ---------------------------------------------------------------------------


def _build_unit_spec(spec: UdsSpecification) -> UnitSpec:
    """Build a UNIT-SPEC from every distinct unit string in the spec."""
    seen: dict[str, Unit] = {}

    def _add(unit_label: str | None) -> None:
        if not unit_label:
            return
        key = unit_label.strip()
        if not key or key in seen:
            return
        sn = sanitize_short_name(f"Unit_{key}", fallback=f"Unit_{len(seen)}")
        seen[key] = Unit(
            oid=make_oid("d", "unit", key),
            short_name=sn,
            display_name=key,
        )

    for did in spec.dids:
        for el in did.data_elements:
            _add(el.unit)
    return UnitSpec(units=list(seen.values()))


def _build_did_service(did: Did, registry: _DopRegistry, *, is_write: bool) -> tuple[
    DiagService, Request, Response,
]:
    """Build (service, request, positive-response) for one DID + R/WDBI."""
    kind = "WDBI" if is_write else "RDBI"
    sid = 0x2E if is_write else 0x22
    service_short = sanitize_short_name(f"{kind}_{did.short_name}")
    request_short = sanitize_short_name(f"RQ_{kind}_{did.short_name}")
    response_short = sanitize_short_name(f"PR_{kind}_{did.short_name}")

    # ------ Request --------------------------------------------------------
    req_params: list[Param] = [
        _coded_value_const_param(
            f"SID_{kind}", 0, sid, semantic="SERVICE-ID", bit_length=8,
        ),
        Param(
            oid=make_oid("d", "param", f"DID_{did.short_name}"),
            short_name=sanitize_short_name(f"DID_{did.short_name}"),
            byte_position=1,
            bit_length=16,
            semantic="ID",
            param_kind="CODED-CONST",
            coded_value=did.did_id,
        ),
    ]

    if is_write:
        # WDBI: include the data record in the request
        byte_pos = 3
        for el in did.data_elements:
            dop = registry.get_or_create(
                el.data_type, el.unit, el.coding, bit_length=el.bit_size,
            )
            req_params.append(
                _value_param(
                    el.short_name or f"elem_{byte_pos}", byte_pos, dop.oid,
                    bit_position=el.bit_position or None,
                    bit_length=el.bit_size or None,
                    semantic="DATA",
                    description=el.description or None,
                )
            )
            byte_pos += max(1, (el.bit_size or 8) // 8)

    request = Request(
        oid=make_oid("d", "rq", request_short),
        short_name=request_short,
        long_name=f"Request for {kind} of DID {did.did_id_hex}",
        params=req_params,
    )

    # ------ Positive response ---------------------------------------------
    if is_write:
        # 6E + DID hi + DID lo
        resp_params = [
            _coded_value_const_param(
                f"SID_PR_{kind}", 0, sid + 0x40, semantic="SERVICE-ID", bit_length=8,
            ),
            Param(
                oid=make_oid("d", "param", f"DID_PR_{did.short_name}_w"),
                short_name=sanitize_short_name(f"DID_PR_{did.short_name}"),
                byte_position=1,
                bit_length=16,
                semantic="ID",
                param_kind="MATCHING-REQUEST-PARAM",
                request_byte_pos=1,
            ),
        ]
    else:
        # RDBI: 62 + DID + dataRecord
        byte_pos = 3
        resp_params = [
            _coded_value_const_param(
                f"SID_PR_{kind}", 0, sid + 0x40, semantic="SERVICE-ID", bit_length=8,
            ),
            Param(
                oid=make_oid("d", "param", f"DID_PR_{did.short_name}_r"),
                short_name=sanitize_short_name(f"DID_PR_{did.short_name}"),
                byte_position=1,
                bit_length=16,
                semantic="ID",
                param_kind="MATCHING-REQUEST-PARAM",
                request_byte_pos=1,
            ),
        ]
        for el in did.data_elements:
            dop = registry.get_or_create(
                el.data_type, el.unit, el.coding, bit_length=el.bit_size,
            )
            resp_params.append(
                _value_param(
                    el.short_name or f"elem_{byte_pos}", byte_pos, dop.oid,
                    bit_position=el.bit_position or None,
                    bit_length=el.bit_size or None,
                    semantic="DATA",
                    description=el.description or None,
                )
            )
            byte_pos += max(1, (el.bit_size or 8) // 8)

    response = Response(
        oid=make_oid("d", "pr", response_short),
        short_name=response_short,
        long_name=f"Positive response for {kind} of DID {did.did_id_hex}",
        response_type="POS-RESPONSE",
        params=resp_params,
    )

    # ------ Service --------------------------------------------------------
    service = DiagService(
        oid=make_oid("d", "service", service_short),
        short_name=service_short,
        long_name=f"{'Write' if is_write else 'Read'} DID {did.did_id_hex} - {did.short_name}",
        description=did.description or None,
        semantic="DATA",
        request_ref=OdxRef(id_ref=request.oid),
        pos_response_refs=[OdxRef(id_ref=response.oid)],
        addressing="PHYSICAL",
        transmission_mode="SEND-AND-RECEIVE",
    )
    return service, request, response


def _build_routine_services(
    routine: Routine, registry: _DopRegistry,
) -> tuple[list[DiagService], list[Request], list[Response]]:
    """Build start / stop / requestResults services for a routine."""
    services: list[DiagService] = []
    requests: list[Request] = []
    responses: list[Response] = []

    sub_specs: list[tuple[int, str, bool]] = []  # (sub_id, kind, supported)
    if routine.start_supported:
        sub_specs.append((0x01, "Start", True))
    if routine.stop_supported:
        sub_specs.append((0x02, "Stop", True))
    if routine.result_supported:
        sub_specs.append((0x03, "Results", True))
    if not sub_specs:
        sub_specs.append((0x01, "Start", True))

    for sub_id, kind, _ in sub_specs:
        base = sanitize_short_name(f"RC_{kind}_{routine.short_name}")
        req_short = sanitize_short_name(f"RQ_{kind}_{routine.short_name}")
        resp_short = sanitize_short_name(f"PR_{kind}_{routine.short_name}")

        req_params: list[Param] = [
            _coded_value_const_param("SID_RC", 0, 0x31, semantic="SERVICE-ID", bit_length=8),
            Param(
                oid=make_oid("d", "param", f"RT_subfn_{routine.short_name}_{sub_id}"),
                short_name=sanitize_short_name(f"SubFn_{kind}"),
                byte_position=1,
                bit_length=8,
                semantic="SUBFUNCTION",
                param_kind="CODED-CONST",
                coded_value=sub_id,
            ),
            Param(
                oid=make_oid("d", "param", f"RID_{routine.short_name}"),
                short_name=sanitize_short_name(f"RID_{routine.short_name}"),
                byte_position=2,
                bit_length=16,
                semantic="ID",
                param_kind="CODED-CONST",
                coded_value=routine.routine_id,
            ),
        ]
        if sub_id == 0x01:
            byte_pos = 4
            for p in routine.in_parameters:
                dop = registry.get_or_create(
                    p.data_type, "", "", bit_length=p.bit_size,
                )
                req_params.append(
                    _value_param(
                        p.short_name or f"in_{byte_pos}", byte_pos, dop.oid,
                        bit_length=p.bit_size or None,
                        semantic="DATA",
                        description=p.description or None,
                    )
                )
                byte_pos += max(1, (p.bit_size or 8) // 8)

        request = Request(
            oid=make_oid("d", "rq", req_short),
            short_name=req_short,
            long_name=f"Routine {kind} - {routine.short_name}",
            params=req_params,
        )

        # Positive response
        resp_params: list[Param] = [
            _coded_value_const_param(
                "SID_PR_RC", 0, 0x71, semantic="SERVICE-ID", bit_length=8,
            ),
            Param(
                oid=make_oid("d", "param", f"RT_subfn_pr_{routine.short_name}_{sub_id}"),
                short_name=sanitize_short_name(f"SubFn_PR_{kind}"),
                byte_position=1,
                bit_length=8,
                semantic="SUBFUNCTION",
                param_kind="MATCHING-REQUEST-PARAM",
                request_byte_pos=1,
            ),
            Param(
                oid=make_oid("d", "param", f"RID_PR_{routine.short_name}_{sub_id}"),
                short_name=sanitize_short_name(f"RID_PR_{routine.short_name}"),
                byte_position=2,
                bit_length=16,
                semantic="ID",
                param_kind="MATCHING-REQUEST-PARAM",
                request_byte_pos=2,
            ),
        ]
        if sub_id in (0x01, 0x03):
            byte_pos = 4
            for p in routine.out_parameters:
                dop = registry.get_or_create(
                    p.data_type, "", "", bit_length=p.bit_size,
                )
                resp_params.append(
                    _value_param(
                        p.short_name or f"out_{byte_pos}", byte_pos, dop.oid,
                        bit_length=p.bit_size or None,
                        semantic="DATA",
                        description=p.description or None,
                    )
                )
                byte_pos += max(1, (p.bit_size or 8) // 8)

        response = Response(
            oid=make_oid("d", "pr", resp_short),
            short_name=resp_short,
            long_name=f"Positive response for routine {kind} {routine.short_name}",
            response_type="POS-RESPONSE",
            params=resp_params,
        )

        service = DiagService(
            oid=make_oid("d", "service", base),
            short_name=base,
            long_name=f"RoutineControl {kind} - {routine.short_name}",
            description=routine.description or None,
            semantic="ROUTINECONTROL",
            request_ref=OdxRef(id_ref=request.oid),
            pos_response_refs=[OdxRef(id_ref=response.oid)],
            addressing="PHYSICAL",
        )
        services.append(service)
        requests.append(request)
        responses.append(response)

    return services, requests, responses


def _build_uds_service(svc: UdsService) -> tuple[DiagService, Request, Response]:
    """Build a generic DiagService (+request+positive-response) for a UDS service."""
    short_name = sanitize_short_name(svc.short_name or f"SID_{svc.service_id:02X}")
    req_short = sanitize_short_name(f"RQ_{short_name}")
    resp_short = sanitize_short_name(f"PR_{short_name}")
    semantic = _UDS_SID_TO_SEMANTIC.get(svc.service_id, "SERVICE")

    req_params: list[Param] = [
        _coded_value_const_param(
            f"SID_{short_name}", 0, svc.service_id, semantic="SERVICE-ID", bit_length=8,
        ),
    ]
    if svc.sub_functions:
        # Add a placeholder sub-function byte (VALUE so different sub-functions
        # can be expressed by the tester). A future agent may wish to expand
        # each sub-function into its own DiagService — we keep it compact here.
        req_params.append(
            Param(
                oid=make_oid("d", "param", f"{short_name}_subfn"),
                short_name=sanitize_short_name(f"SubFn_{short_name}"),
                byte_position=1,
                bit_length=8,
                semantic="SUBFUNCTION",
                param_kind="VALUE",
            )
        )

    request = Request(
        oid=make_oid("d", "rq", req_short),
        short_name=req_short,
        long_name=f"Request for {svc.short_name}",
        params=req_params,
    )

    resp_params: list[Param] = [
        _coded_value_const_param(
            f"SID_PR_{short_name}", 0, svc.positive_response_id,
            semantic="SERVICE-ID", bit_length=8,
        ),
    ]
    if svc.sub_functions:
        resp_params.append(
            Param(
                oid=make_oid("d", "param", f"{short_name}_subfn_pr"),
                short_name=sanitize_short_name(f"SubFn_PR_{short_name}"),
                byte_position=1,
                bit_length=8,
                semantic="SUBFUNCTION",
                param_kind="MATCHING-REQUEST-PARAM",
                request_byte_pos=1,
            )
        )
    response = Response(
        oid=make_oid("d", "pr", resp_short),
        short_name=resp_short,
        long_name=f"Positive response for {svc.short_name}",
        response_type="POS-RESPONSE",
        params=resp_params,
    )

    # Addressing
    addressing = "PHYSICAL"
    if "physical" in svc.addressing_modes and "functional" in svc.addressing_modes:
        addressing = "PHYSICAL-AND-FUNCTIONAL"
    elif svc.addressing_modes == ["functional"]:
        addressing = "FUNCTIONAL"

    service = DiagService(
        oid=make_oid("d", "service", short_name),
        short_name=short_name,
        long_name=svc.short_name,
        description=svc.description or None,
        semantic=semantic,
        request_ref=OdxRef(id_ref=request.oid),
        pos_response_refs=[OdxRef(id_ref=response.oid)],
        addressing=addressing,
    )
    return service, request, response


def _build_session_table(sessions: list[DiagSession]) -> Table | None:
    """Map DiagSession entries to a SESSION TABLE."""
    if not sessions:
        return None
    rows: list[TableRow] = []
    for s in sessions:
        rows.append(
            TableRow(
                oid=make_oid("d", "tr", f"session_{s.short_name}"),
                short_name=sanitize_short_name(f"Session_{s.short_name}"),
                key=s.session_id,
                description=(
                    f"P2={s.p2_server_max*1000:.0f}ms "
                    f"P2*={s.p2_star_server_max*1000:.0f}ms"
                ),
            )
        )
    return Table(
        oid=make_oid("d", "tbl", "SessionTable"),
        short_name="SessionTable",
        long_name="Diagnostic Session Table",
        table_rows=rows,
    )


def _build_security_table(levels: list[SecurityLevel]) -> Table | None:
    """Map SecurityLevel entries to a SECURITY-LEVEL TABLE."""
    if not levels:
        return None
    rows: list[TableRow] = []
    for lv in levels:
        rows.append(
            TableRow(
                oid=make_oid("d", "tr", f"sec_{lv.short_name}"),
                short_name=sanitize_short_name(f"Sec_{lv.short_name}"),
                key=lv.security_level,
                description=(
                    f"seed_size={lv.seed_size}B key_size={lv.key_size}B "
                    f"max_attempts={lv.num_max_attempts}"
                ),
            )
        )
    return Table(
        oid=make_oid("d", "tbl", "SecurityLevelTable"),
        short_name="SecurityLevelTable",
        long_name="Security Access Level Table",
        table_rows=rows,
    )


def _build_dtc_dop(
    dtcs: list[DtcDefinition], dem_dtcs: list[DemDtcEntry],
) -> DtcDop | None:
    """Aggregate DCM DTCs and DEM DTCs into a single DTC-DOP."""
    if not dtcs and not dem_dtcs:
        return None
    items: list[Dtc] = []
    seen_codes: set[int] = set()

    for d in dtcs:
        if d.dtc_id in seen_codes:
            continue
        seen_codes.add(d.dtc_id)
        items.append(
            Dtc(
                oid=make_oid("d", "dtc", d.short_name),
                short_name=sanitize_short_name(f"DTC_{d.short_name}"),
                trouble_code=d.dtc_id,
                display_trouble_code=d.dtc_id_hex,
                text=d.description or d.short_name,
                level=None,
            )
        )

    severity_map = {
        "DEM_SEVERITY_NO_SEVERITY": 0x00,
        "DEM_SEVERITY_MAINTENANCE_ONLY": 0x20,
        "DEM_SEVERITY_CHECK_AT_NEXT_HALT": 0x40,
        "DEM_SEVERITY_CHECK_IMMEDIATELY": 0x80,
    }
    for d in dem_dtcs:
        if d.dtc_value in seen_codes:
            continue
        seen_codes.add(d.dtc_value)
        items.append(
            Dtc(
                oid=make_oid("d", "dtc", d.short_name),
                short_name=sanitize_short_name(f"DTC_{d.short_name}"),
                trouble_code=d.dtc_value,
                display_trouble_code=d.dtc_value_hex,
                text=d.short_name,
                level=severity_map.get(d.severity),
            )
        )

    return DtcDop(
        oid=make_oid("d", "dop", "DtcDop"),
        short_name="DtcDop",
        long_name="DTC Data Object Property",
        diag_coded_type=DiagCodedType(
            base_data_type="A_UINT32",
            coded_type="STANDARD-LENGTH-TYPE",
            bit_length=24,
        ),
        physical_type=PhysicalType(base_data_type="A_UINT32", display_radix="HEX"),
        compu_method=CompuMethod(category="IDENTICAL"),
        dtcs=items,
    )


def _build_memory_structures(memory_ranges: list[MemoryRange]) -> list[Structure]:
    """Map MemoryRange entries to ODX STRUCTURE definitions."""
    structures: list[Structure] = []
    for m in memory_ranges:
        struct = Structure(
            oid=make_oid("d", "struct", f"MemRange_{m.short_name}"),
            short_name=sanitize_short_name(f"MemRange_{m.short_name}"),
            long_name=(
                f"Memory range {m.start_address_hex}..{m.end_address_hex}"
            ),
            byte_size=max(1, (m.end_address - m.start_address) + 1)
            if m.end_address >= m.start_address else None,
            params=[
                Param(
                    oid=make_oid("d", "param", f"MemRange_start_{m.short_name}"),
                    short_name=sanitize_short_name(f"start_{m.short_name}"),
                    byte_position=0,
                    bit_length=32,
                    semantic="ADDRESS",
                    param_kind="VALUE",
                ),
                Param(
                    oid=make_oid("d", "param", f"MemRange_end_{m.short_name}"),
                    short_name=sanitize_short_name(f"end_{m.short_name}"),
                    byte_position=4,
                    bit_length=32,
                    semantic="ADDRESS",
                    param_kind="VALUE",
                ),
            ],
        )
        structures.append(struct)
    return structures


def _nrc_response(nrcs: list[NrcEntry]) -> Response | None:
    """Build a single global NEG-RESPONSE that enumerates every NRC."""
    if not nrcs:
        return None
    params: list[Param] = [
        _coded_value_const_param(
            "SID_NR", 0, 0x7F, semantic="SERVICE-ID", bit_length=8,
        ),
        Param(
            oid=make_oid("d", "param", "nrc_origSid"),
            short_name="originalServiceId",
            byte_position=1,
            bit_length=8,
            semantic="SERVICE-ID",
            param_kind="VALUE",
        ),
    ]
    # Append one constant per NRC at byte 2 (only one is actually emitted per
    # response — they enumerate the allowed values).
    for n in nrcs:
        params.append(
            Param(
                oid=make_oid("d", "param", f"nrc_{n.nrc_code:02X}"),
                short_name=sanitize_short_name(f"NRC_{n.nrc_name}"),
                byte_position=2,
                bit_length=8,
                semantic="NRC",
                param_kind="NRC-CONST",
                coded_value=n.nrc_code,
                description=n.description or n.nrc_name,
            )
        )
    return Response(
        oid=make_oid("d", "nr", "GlobalNegativeResponse"),
        short_name="GlobalNegativeResponse",
        long_name="Global negative response (NRCs)",
        response_type="GLOBAL-NEG-RESPONSE",
        params=params,
    )


# ---------------------------------------------------------------------------
# Comparam / vehicle / flash / function dictionary builders
# ---------------------------------------------------------------------------


def _cantp_to_comparam_subset(cantp: CanTpConfig) -> ComparamSubset:
    """Translate CanTpConfig timing parameters to an ISO_15765_2 subset."""
    comparams: list[Comparam] = []

    def _add(name: str, value: Any, klass: str = "TIMING") -> None:
        comparams.append(
            Comparam(
                oid=make_oid("cs", "cp", name),
                short_name=sanitize_short_name(name),
                long_name=name,
                param_class=klass,
                cptype="STANDARD",
                physical_default_value=str(value),
            )
        )

    # If the spec has explicit channels, take the timing from the first one.
    ch: CanTpChannel | None = cantp.channels[0] if cantp.channels else None
    _add("CP_P2_SERVER_MAX", (ch.n_bs if ch else 0.05) * 1000 if ch and ch.n_bs else 50)
    _add("CP_P2_STAR_SERVER_MAX", (ch.n_cs if ch else 5.0) * 1000 if ch and ch.n_cs else 5000)
    _add("CP_S3_SERVER", 5000)
    _add("CP_STMIN", ch.stmin if ch else 0.0)
    _add("CP_BLOCK_SIZE", ch.bs if ch else 0)
    _add("CP_N_AS", ch.n_as if ch else 0.0)
    _add("CP_N_AR", ch.n_ar if ch else 0.0)
    _add("CP_N_BR", ch.n_br if ch else 0.0)
    _add("CP_N_CR", ch.n_cr if ch else 0.0)
    _add(
        "CP_PADDING",
        f"0x{(ch.padding_byte if ch else cantp.padding_byte):02X}",
        klass="FUNCTIONAL",
    )

    return ComparamSubset(
        oid=make_oid("cs", "subset", "ISO_15765_2"),
        short_name="ISO_15765_2",
        long_name="ISO 15765-2 Comparam subset",
        description="Auto-generated from CanTp ARXML configuration",
        category="ISO_15765_2",
        comparams=comparams,
    )


def _doip_to_physical_link(doip: DoIpConfig) -> PhysicalVehicleLink | None:
    """Translate DoIpConfig to a PHYSICAL-VEHICLE-LINK entry."""
    if not doip or not (doip.short_name or doip.vins or doip.logical_addresses):
        return None
    sn = sanitize_short_name(doip.short_name or "DoIP_Link", fallback="DoIP_Link")
    return PhysicalVehicleLink(
        oid=make_oid("v", "physlink", sn),
        short_name=sn,
        long_name="DoIP physical vehicle link",
        link_type="ISO-13400-2-DoIP",
    )


def _supplement_to_admin_data(sup: OdxSupplement) -> AdminData:
    """Construct ADMIN-DATA from the supplement (or default values)."""
    revisions = [
        DocRevision(
            revision_label="0.1",
            state="DRAFT",
            date="",
            tool="udsxml2tex",
        )
    ]
    companies: list[CompanyData] = []
    if sup.company_data:
        companies.append(
            CompanyData(
                oid=make_oid("d", "company", sup.company_data.short_name),
                short_name=sanitize_short_name(sup.company_data.short_name),
                long_name=sup.company_data.long_name,
                roles=list(sup.company_data.roles),
            )
        )
    return AdminData(
        language="en-US",
        company_doc_infos=companies,
        doc_revisions=revisions,
    )


def _build_vehicle_info_spec(
    spec: UdsSpecification,
    sup: OdxSupplement,
    base_variant_oid: str,
) -> OdxDocument | None:
    """Build an ODX-V document when DoIP config or vehicle supplement is present."""
    if not sup.vehicle and not spec.doip_config and not sup.physical_vehicle_links:
        return None
    veh: Vehicle | None = None
    physical_links: list[PhysicalVehicleLink] = []

    if sup.physical_vehicle_links:
        for ln in sup.physical_vehicle_links:
            sn = sanitize_short_name(ln.short_name, fallback="VehicleLink")
            physical_links.append(
                PhysicalVehicleLink(
                    oid=make_oid("v", "physlink", sn),
                    short_name=sn,
                    link_type=ln.link_type,
                    vehicle_connector_ref=(
                        OdxRef(id_ref=make_oid("v", "connector", ln.vehicle_connector_ref))
                        if ln.vehicle_connector_ref else None
                    ),
                )
            )
    doip_link = _doip_to_physical_link(spec.doip_config) if spec.doip_config else None
    if doip_link is not None:
        physical_links.append(doip_link)

    if sup.vehicle:
        connectors: list[VehicleConnector] = []
        for c in sup.vehicle.vehicle_connectors:
            sn = sanitize_short_name(c.short_name, fallback="Connector")
            connectors.append(
                VehicleConnector(
                    oid=make_oid("v", "connector", c.short_name),
                    short_name=sn,
                    long_name=c.long_name,
                    connector_type=c.connector_type,
                )
            )
        veh_sn = sanitize_short_name(
            sup.vehicle.short_name or sup.vehicle.model or "Vehicle",
            fallback="Vehicle",
        )
        veh = Vehicle(
            oid=make_oid("v", "vehicle", veh_sn),
            short_name=veh_sn,
            model_year=sup.vehicle.model_year,
            vin=sup.vehicle.vin,
            model=sup.vehicle.model,
            manufacturer=sup.vehicle.manufacturer,
            vehicle_connectors=connectors,
        )

    logical_links: list[LogicalLink] = []
    if physical_links:
        for pl in physical_links:
            logical_links.append(
                LogicalLink(
                    oid=make_oid("v", "llink", pl.short_name),
                    short_name=sanitize_short_name(f"LL_{pl.short_name}"),
                    physical_vehicle_link_ref=OdxRef(id_ref=pl.oid),
                    base_variant_ref=OdxRef(id_ref=base_variant_oid),
                )
            )
    vehicle_information = (
        VehicleInformation(
            oid=make_oid("v", "vinfo", veh.short_name if veh else "Default"),
            short_name=sanitize_short_name(
                veh.short_name if veh else "DefaultVehicleInformation"
            ),
            logical_links=logical_links,
        )
        if logical_links or veh else None
    )

    spec_root = VehicleInfoSpec(
        oid=make_oid("v", "spec", "VehicleInfoSpec"),
        short_name="VehicleInfoSpec",
        long_name="Vehicle information",
        info_components=[],
        vehicle_informations=([vehicle_information] if vehicle_information else []),
        vehicles=([veh] if veh else []),
        physical_vehicle_links=physical_links,
    )
    return OdxDocument(
        category=OdxCategory.VEHICLE_INFO,
        vehicle_info_spec=spec_root,
        pdx_member_path="VehicleInfo.odx-v",
    )


def _build_flash_class(
    spec: UdsSpecification, sup: OdxSupplement, ecu_short_name: str,
) -> OdxDocument | None:
    """Build an ODX-F document when supplement.flash.ecu_mem is present."""
    if not sup.flash or not sup.flash.ecu_mem:
        return None
    ecu_mem_sup = sup.flash.ecu_mem
    segments = [
        Segment(
            oid=make_oid("f", "segment", s.short_name),
            short_name=sanitize_short_name(s.short_name, fallback=f"Seg{idx}"),
            source_start_address=s.source_start_address,
            source_end_address=s.source_end_address,
            target_start_address=s.target_start_address,
            target_end_address=s.target_end_address,
            size_length=s.size_length,
            encrypt_compress_method=s.encrypt_compress_method,
        )
        for idx, s in enumerate(ecu_mem_sup.segments)
    ]
    ecu_mem = EcuMem(
        oid=make_oid("f", "ecumem", ecu_mem_sup.short_name),
        short_name=sanitize_short_name(ecu_mem_sup.short_name, fallback="EcuMem"),
        long_name=ecu_mem_sup.long_name,
        segments=segments,
    )
    sessions = [
        FlashSession(
            oid=make_oid("f", "fsession", s.short_name),
            short_name=sanitize_short_name(s.short_name, fallback="FlashSession"),
            security_method=s.security_method,
            expected_idents=list(s.expected_idents),
        )
        for s in sup.flash.sessions
    ]
    flash_class = FlashClass(
        oid=make_oid("f", "flashclass", ecu_short_name),
        short_name=sanitize_short_name(f"Flash_{ecu_short_name}"),
        long_name=f"Flash class for {ecu_short_name}",
        ecu_mems=[ecu_mem],
        sessions=sessions,
    )
    return OdxDocument(
        category=OdxCategory.FLASH,
        flash_class=flash_class,
        pdx_member_path="Flash.odx-f",
    )


def _build_function_dictionary(
    sup: OdxSupplement, service_oids_by_short_name: dict[str, str],
) -> OdxDocument | None:
    """Build an ODX-FD document from the supplement's functional_groups."""
    if not sup.functional_groups:
        return None
    groups: list[FunctionGroup] = []
    for g in sup.functional_groups:
        nodes = [
            FunctionNode(
                oid=make_oid("fd", "fnode", f"{g.short_name}_{ecu}"),
                short_name=sanitize_short_name(f"Fn_{ecu}"),
                long_name=f"Function node for ECU {ecu}",
                description=f"Functional grouping for {ecu}",
            )
            for ecu in g.ecus
        ]
        groups.append(
            FunctionGroup(
                oid=make_oid("fd", "fgroup", g.short_name),
                short_name=sanitize_short_name(g.short_name),
                long_name=g.long_name,
                description=g.description,
                function_nodes=nodes,
            )
        )
    spec_root = FunctionDictionarySpec(
        oid=make_oid("fd", "spec", "FunctionDictionary"),
        short_name="FunctionDictionarySpec",
        long_name="Function dictionary",
        function_groups=groups,
    )
    return OdxDocument(
        category=OdxCategory.FUNCTION_DICTIONARY,
        function_dictionary_spec=spec_root,
        pdx_member_path="FunctionDictionary.odx-fd",
    )


# ---------------------------------------------------------------------------
# Single-ECU mapper (the public entry point)
# ---------------------------------------------------------------------------


def _build_base_variant(
    spec: UdsSpecification,
    sup: OdxSupplement,
    ecu_short_name: str,
    *,
    is_variant: bool = False,
) -> tuple[BaseVariant, list[FunctionalClass]]:
    """Build a populated DiagLayerBase (as BaseVariant or basis for EcuVariant)."""
    registry = _DopRegistry()
    services: list[DiagService] = []
    requests: list[Request] = []
    pos_responses: list[Response] = []

    # 1. DIDs → RDBI + WDBI
    for did in spec.dids:
        rd_service, rd_request, rd_response = _build_did_service(
            did, registry, is_write=False,
        )
        services.append(rd_service)
        requests.append(rd_request)
        pos_responses.append(rd_response)
        if did.write_access:
            wr_service, wr_request, wr_response = _build_did_service(
                did, registry, is_write=True,
            )
            services.append(wr_service)
            requests.append(wr_request)
            pos_responses.append(wr_response)

    # 2. Routines → RoutineControl services
    for r in spec.routines:
        r_services, r_requests, r_responses = _build_routine_services(r, registry)
        services.extend(r_services)
        requests.extend(r_requests)
        pos_responses.extend(r_responses)

    # 3. Generic UDS services (sessions / security / etc.)
    for svc in spec.services:
        s_service, s_request, s_response = _build_uds_service(svc)
        services.append(s_service)
        requests.append(s_request)
        pos_responses.append(s_response)

    # 4. Tables for sessions / security levels
    tables: list[Table] = []
    sess_table = _build_session_table(spec.sessions)
    if sess_table:
        tables.append(sess_table)
    sec_table = _build_security_table(spec.security_levels)
    if sec_table:
        tables.append(sec_table)

    # 5. DTC DOP (DCM + DEM)
    dtc_dop = _build_dtc_dop(spec.dtcs, spec.dem_dtcs)

    # 6. Memory ranges → structures
    structures = _build_memory_structures(spec.memory_ranges)

    # 7. Aggregate NRC into a single global negative response
    nrc_pool: dict[int, NrcEntry] = {}
    for svc in spec.services:
        for n in svc.nrc_list:
            nrc_pool.setdefault(n.nrc_code, n)
    global_neg = _nrc_response(list(nrc_pool.values()))
    global_neg_list = [global_neg] if global_neg else []

    # 8. Functional class taxonomy (one per SID family)
    fclasses: list[FunctionalClass] = []
    semantics_seen: set[str] = set()
    for s in services:
        if s.semantic and s.semantic not in semantics_seen:
            semantics_seen.add(s.semantic)
            fclasses.append(
                FunctionalClass(
                    oid=make_oid("d", "fclass", s.semantic),
                    short_name=sanitize_short_name(f"FC_{s.semantic}"),
                    long_name=f"Functional class for {s.semantic}",
                )
            )

    # 9. SDGs to preserve non-ODX-native data (Comm/AP)
    sdgs: list[SpecialDataGroup] = []
    if spec.comm_config:
        sdg = SpecialDataGroup(caption="CommunicationConfig")
        for fr in spec.comm_config.frames:
            sdg.sd_items.append(("frame", f"{fr.short_name} ({fr.frame_length}B)"))
        for ecu_inst in spec.comm_config.ecu_instances:
            sdg.sd_items.append(("ecu_instance", ecu_inst.short_name))
        sdgs.append(sdg)
    if spec.ap_config:
        sdg = SpecialDataGroup(caption="ApConfig")
        for iface in (spec.ap_config.service_interfaces or []):
            sdg.sd_items.append(("ap_interface", iface.short_name))
        sdgs.append(sdg)
    if spec.obd_config:
        sdg = SpecialDataGroup(caption="ObdConfig")
        for pid in spec.obd_config.pids:
            sdg.sd_items.append((f"pid_{pid.pid_hex}", pid.short_name))
        sdgs.append(sdg)

    layer = BaseVariant(
        oid=make_oid("d", "basevariant", ecu_short_name),
        short_name=ecu_short_name,
        long_name=spec.ecu_name,
        description=spec.description or None,
        admin_data=_supplement_to_admin_data(sup),
        company_datas=([] if not sup.company_data else [
            CompanyData(
                oid=make_oid("d", "company", sup.company_data.short_name),
                short_name=sanitize_short_name(sup.company_data.short_name),
                long_name=sup.company_data.long_name,
                roles=list(sup.company_data.roles),
            )
        ]),
        sdgs=sdgs,
        functional_classes=fclasses,
        diag_data_dictionary_spec=DiagDataDictionarySpec(
            data_object_props=list(registry.by_key.values()),
            dtc_dops=([dtc_dop] if dtc_dop else []),
            structures=structures,
            tables=tables,
            unit_spec=_build_unit_spec(spec),
        ),
        diag_comms=services,
        requests=requests,
        pos_responses=pos_responses,
        global_neg_responses=global_neg_list,
    )
    return layer, fclasses


def map_spec_to_odx(
    spec: UdsSpecification,
    supplement: OdxSupplement | None = None,
    *,
    ecu_name: str | None = None,
    short_name_prefix: str = "",
) -> dict[str, OdxDocument]:
    """Map a single :class:`UdsSpecification` to a set of ODX documents.

    :param spec: ARXML-derived UDS specification.
    :param supplement: optional :class:`OdxSupplement` carrying data ARXML
        cannot supply (vehicle / flash / functional groups / ...). When None
        an empty supplement is used.
    :param ecu_name: override the ECU short name (defaults to ``spec.ecu_name``).
    :param short_name_prefix: optional prefix prepended to every top-level
        short name (useful when emitting several ECUs side-by-side).
    :returns: dict keyed by .odx-* member filename → :class:`OdxDocument`.
        The dict always contains at least one entry under
        ``"<ECU>.odx-d"``; comparam/vehicle/flash/function-dictionary
        documents are added only when their source data is present.
    """
    sup = supplement if supplement is not None else empty_supplement()
    raw_name = ecu_name or spec.ecu_name or "ECU"
    ecu_sn = sanitize_short_name(f"{short_name_prefix}{raw_name}", fallback="ECU")

    base_variant, _ = _build_base_variant(spec, sup, ecu_sn)

    protocol = Protocol(
        oid=make_oid("d", "protocol", "UDS"),
        short_name="UDS_on_CAN",
        long_name="UDS protocol (ISO 14229)",
        description=spec.protocol_name or "UDS-on-CAN",
    )
    dlc = DiagLayerContainer(
        oid=make_oid("d", "container", ecu_sn),
        short_name=sanitize_short_name(f"DLC_{ecu_sn}"),
        long_name=f"DiagLayerContainer for {ecu_sn}",
        admin_data=_supplement_to_admin_data(sup),
        protocols=[protocol],
        base_variants=[base_variant],
    )
    odx_d = OdxDocument(
        category=OdxCategory.DIAG_LAYER,
        diag_layer_container=dlc,
        pdx_member_path=f"{ecu_sn}.odx-d",
        admin_data=_supplement_to_admin_data(sup),
    )

    out: dict[str, OdxDocument] = {odx_d.pdx_member_path: odx_d}

    # Comparam subset (ODX-CS) — emitted only when CanTp config is present.
    if spec.transport_config and (spec.transport_config.channels
                                   or spec.transport_config.padding_byte):
        cs_subset = _cantp_to_comparam_subset(spec.transport_config)
        odx_cs = OdxDocument(
            category=OdxCategory.COMPARAM_SUBSET,
            comparam_subset=cs_subset,
            pdx_member_path="ISO_15765_2.odx-cs",
        )
        out[odx_cs.pdx_member_path] = odx_cs

    # Vehicle info (ODX-V) — present when DoIP or vehicle supplement exists.
    odx_v = _build_vehicle_info_spec(spec, sup, base_variant.oid)
    if odx_v is not None:
        out[odx_v.pdx_member_path] = odx_v

    # Flash (ODX-F) — present when supplement.flash is provided.
    odx_f = _build_flash_class(spec, sup, ecu_sn)
    if odx_f is not None:
        out[odx_f.pdx_member_path] = odx_f

    # Function dictionary (ODX-FD) — present when supplement.functional_groups exists.
    service_oids = {s.short_name: s.oid for s in base_variant.diag_comms}
    odx_fd = _build_function_dictionary(sup, service_oids)
    if odx_fd is not None:
        out[odx_fd.pdx_member_path] = odx_fd

    return out


# ---------------------------------------------------------------------------
# Multi-ECU mapper
# ---------------------------------------------------------------------------


def map_ecu_system_to_odx(
    system: EcuSystem,
    supplement: OdxSupplement | None = None,
) -> dict[str, OdxDocument]:
    """Map a multi-ECU :class:`EcuSystem` to a set of ODX documents.

    Emits one :class:`EcuVariant` per ECU under a shared
    :class:`DiagLayerContainer`. Routing rules and topology are preserved
    inside SDGs on the container's admin data so no information is lost.
    """
    if EcuSystem is None:
        raise ImportError("multi-ECU support requires udsxml2tex.multi_ecu")
    sup = supplement if supplement is not None else empty_supplement()
    out: dict[str, OdxDocument] = {}

    ecu_variants: list[EcuVariant] = []
    aggregated_services: list[DiagService] = []
    aggregated_requests: list[Request] = []
    aggregated_pos_responses: list[Response] = []
    aggregated_global_negs: list[Response] = []

    for ecu_name, ecu_cfg in system.ecus.items():
        if ecu_cfg.spec is None:
            continue
        ecu_sn = sanitize_short_name(ecu_name, fallback="ECU")
        base, _ = _build_base_variant(ecu_cfg.spec, sup, ecu_sn, is_variant=True)

        variant = EcuVariant(
            oid=make_oid("d", "ecuvariant", ecu_sn),
            short_name=ecu_sn,
            long_name=ecu_cfg.spec.ecu_name,
            description=ecu_cfg.description or ecu_cfg.spec.description or None,
            admin_data=base.admin_data,
            company_datas=base.company_datas,
            sdgs=base.sdgs,
            functional_classes=base.functional_classes,
            diag_data_dictionary_spec=base.diag_data_dictionary_spec,
            diag_comms=base.diag_comms,
            requests=base.requests,
            pos_responses=base.pos_responses,
            neg_responses=base.neg_responses,
            global_neg_responses=base.global_neg_responses,
        )
        ecu_variants.append(variant)
        aggregated_services.extend(base.diag_comms)
        aggregated_requests.extend(base.requests)
        aggregated_pos_responses.extend(base.pos_responses)
        aggregated_global_negs.extend(base.global_neg_responses)

    # Routing rules → SDGs on the container.
    routing_sdgs: list[SpecialDataGroup] = []
    if getattr(system, "routing_rules", None):
        rule_sdg = SpecialDataGroup(caption="RoutingRules")
        for r in system.routing_rules:
            rule_sdg.sd_items.append((
                f"{r.from_ecu}->{r.to_ecu}",
                r.match.description() if hasattr(r.match, "description") else "",
            ))
        routing_sdgs.append(rule_sdg)
    if getattr(system, "topology", None) and getattr(system.topology, "connections", None):
        topo_sdg = SpecialDataGroup(caption="SystemTopology")
        for c in system.topology.connections:
            topo_sdg.sd_items.append((f"{c.from_ecu}-{c.to_ecu}", c.medium))
        routing_sdgs.append(topo_sdg)

    container_sn = sanitize_short_name(system.name or "DLC_System", fallback="DLC_System")
    container = DiagLayerContainer(
        oid=make_oid("d", "container", container_sn),
        short_name=container_sn,
        long_name=container_sn,
        description=system.description or None,
        admin_data=_supplement_to_admin_data(sup),
        ecu_variants=ecu_variants,
    )

    # Move routing SDGs onto the first variant when present (containers do
    # not carry SDGs in ODX 2.2.0). Failing that, attach to the admin data
    # via a no-op CompanyData entry — but keeping it on the first variant
    # is faithful and simple.
    if routing_sdgs and ecu_variants:
        ecu_variants[0].sdgs.extend(routing_sdgs)

    odx_d = OdxDocument(
        category=OdxCategory.DIAG_LAYER,
        diag_layer_container=container,
        pdx_member_path=f"{container_sn}.odx-d",
        admin_data=container.admin_data,
    )
    out[odx_d.pdx_member_path] = odx_d

    # Add supplement-derived documents at the system level.
    if sup.functional_groups:
        services_by_short: dict[str, str] = {}
        for v in ecu_variants:
            services_by_short.update({s.short_name: s.oid for s in v.diag_comms})
        odx_fd = _build_function_dictionary(sup, services_by_short)
        if odx_fd:
            out[odx_fd.pdx_member_path] = odx_fd
    if sup.vehicle or sup.physical_vehicle_links:
        first_oid = ecu_variants[0].oid if ecu_variants else make_oid("d", "fallback", "ECU")
        odx_v = _build_vehicle_info_spec(
            UdsSpecification(),  # vehicle info is supplement-driven
            sup, first_oid,
        )
        if odx_v:
            out[odx_v.pdx_member_path] = odx_v
    if sup.flash and sup.flash.ecu_mem:
        anchor = ecu_variants[0].short_name if ecu_variants else "ECU"
        odx_f = _build_flash_class(UdsSpecification(), sup, anchor)
        if odx_f:
            out[odx_f.pdx_member_path] = odx_f

    return out
