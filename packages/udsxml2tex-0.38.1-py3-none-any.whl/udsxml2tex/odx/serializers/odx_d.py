"""ODX-D (Diagnostic Data) XML serializer for ODX 2.2.0 / ISO 22901-1.

This module converts a :class:`udsxml2tex.odx.models_odx.OdxDocument` of
category :class:`OdxCategory.DIAG_LAYER` into a well-formed ODX 2.2.0 XML
document encoded as UTF-8 bytes.

Conventions
-----------

* No default XML namespace is declared; element names are unqualified
  UPPER-KEBAB-CASE as ASAM ODX requires in practice.
* The ``xsi`` namespace is declared on the root for ``xsi:type``
  discriminators used by ``DIAG-CODED-TYPE`` and ``PARAM``.
* Optional fields that are ``None`` or empty strings are omitted entirely
  — no ``<LONG-NAME/>`` placeholder elements are emitted.
* Empty lists do not produce a wrapping element (e.g. no empty
  ``<PARAMS/>``).
* Validation against the ODX 2.2.0 XSD is left to the PDX packager; this
  module only guarantees well-formed XML matching the ODX 2.2.0 element
  grammar.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any

from lxml import etree

from udsxml2tex.odx.models_odx import (
    AdminData,
    Audience,
    BaseVariant,
    CompanyData,
    CompuMethod,
    CompuScale,
    DataObjectProp,
    DiagCodedType,
    DiagDataDictionarySpec,
    DiagLayerBase,
    DiagLayerContainer,
    DiagService,
    DocRevision,
    Dtc,
    DtcDop,
    DynamicEndmarkerField,
    EcuSharedData,
    EcuVariant,
    EcuVariantPattern,
    EndOfPduField,
    EnvData,
    EnvDataDesc,
    FunctionalClass,
    FunctionalGroup,
    Mux,
    MuxCase,
    OdxCategory,
    OdxDocument,
    OdxRef,
    Param,
    PhysicalType,
    Protocol,
    Request,
    Response,
    SnRef,
    SpecialDataGroup,
    StaticField,
    Structure,
    Table,
    TableRow,
    Unit,
    UnitGroup,
    UnitSpec,
)

XSI_NS = "http://www.w3.org/2001/XMLSchema-instance"
NSMAP = {"xsi": XSI_NS}
_XSI_TYPE = f"{{{XSI_NS}}}type"


# ---------------------------------------------------------------------------
# Low-level XML helpers
# ---------------------------------------------------------------------------


def _add_text_child(parent: etree._Element, tag: str, value: Any) -> etree._Element | None:
    """Append ``<tag>str(value)</tag>`` to ``parent`` if ``value`` is non-empty.

    Returns the created element or ``None`` when the value was omitted.
    """
    if value is None:
        return None
    text = str(value)
    if text == "":
        return None
    el = etree.SubElement(parent, tag)
    el.text = text
    return el


def _add_desc(parent: etree._Element, description: str | None) -> None:
    """Append ODX ``<DESC><p>...</p></DESC>`` when ``description`` is set."""
    if not description:
        return
    desc = etree.SubElement(parent, "DESC")
    p = etree.SubElement(desc, "p")
    p.text = description


def _add_identity(parent: etree._Element, oid: str, short_name: str,
                  long_name: str | None = None, description: str | None = None) -> None:
    """Attach ``ID``, ``<SHORT-NAME>``, optional ``<LONG-NAME>``, ``<DESC>``.

    ``ID`` is only set when ``oid`` is non-empty; ``SHORT-NAME`` is always
    written (empty string falls back to the element's tag).
    """
    if oid:
        parent.set("ID", oid)
    sn = etree.SubElement(parent, "SHORT-NAME")
    sn.text = short_name or ""
    if long_name:
        ln = etree.SubElement(parent, "LONG-NAME")
        ln.text = long_name
    _add_desc(parent, description)


def _ref_attrs(ref: OdxRef) -> dict[str, str]:
    """Build the attribute dict for an ``ID-REF`` element (with DOCREFs)."""
    attrs: dict[str, str] = {"ID-REF": ref.id_ref}
    if ref.docref:
        attrs["DOCREF"] = ref.docref
    if ref.docref_type:
        attrs["DOCREF-TYPE"] = ref.docref_type
    return attrs


def _snref_attrs(ref: SnRef) -> dict[str, str]:
    """Build the attribute dict for a ``SHORT-NAME``-style reference."""
    attrs: dict[str, str] = {"SHORT-NAME": ref.short_name}
    if ref.docref:
        attrs["DOCREF"] = ref.docref
    if ref.docref_type:
        attrs["DOCREF-TYPE"] = ref.docref_type
    return attrs


def _add_ref_element(parent: etree._Element, tag: str, ref: OdxRef | None) -> None:
    """Append ``<tag ID-REF="..."/>`` if ``ref`` is set."""
    if ref is None:
        return
    etree.SubElement(parent, tag, _ref_attrs(ref))


def _add_ref_list(parent: etree._Element, container_tag: str, item_tag: str,
                  refs: list[OdxRef]) -> None:
    """Append ``<container_tag><item_tag .../></container_tag>`` when non-empty."""
    if not refs:
        return
    container = etree.SubElement(parent, container_tag)
    for ref in refs:
        etree.SubElement(container, item_tag, _ref_attrs(ref))


def _format_date(value: Any) -> str:
    """Convert a date value (str / datetime) to an ISO 8601 ``Z``-suffixed string."""
    if value is None or value == "":
        return ""
    if isinstance(value, datetime):
        return value.strftime("%Y-%m-%dT%H:%M:%SZ")
    return str(value)


# ---------------------------------------------------------------------------
# Identity-bearing leaf elements
# ---------------------------------------------------------------------------


def _doc_revision_to_xml(rev: DocRevision) -> etree._Element:
    """Serialize a single ``DOC-REVISION`` element."""
    el = etree.Element("DOC-REVISION")
    if rev.team_member_ref:
        etree.SubElement(el, "TEAM-MEMBER-REF", {"ID-REF": rev.team_member_ref})
    _add_text_child(el, "REVISION-LABEL", rev.revision_label)
    _add_text_child(el, "STATE", rev.state)
    date_str = _format_date(rev.date)
    if date_str:
        _add_text_child(el, "DATE", date_str)
    _add_text_child(el, "TOOL", rev.tool)
    return el


def _company_data_to_xml(cd: CompanyData) -> etree._Element:
    """Serialize one ``COMPANY-DATA`` element (under ADMIN-DATA / DiagLayer)."""
    el = etree.Element("COMPANY-DATA")
    _add_identity(el, cd.oid, cd.short_name, cd.long_name)
    if cd.roles:
        roles = etree.SubElement(el, "ROLES")
        for r in cd.roles:
            _add_text_child(roles, "ROLE", r)
    return el


def _admin_data_to_xml(ad: AdminData | None) -> etree._Element | None:
    """Serialize an ``ADMIN-DATA`` block (or ``None`` when ``ad`` is None)."""
    if ad is None:
        return None
    el = etree.Element("ADMIN-DATA")
    if ad.language:
        _add_text_child(el, "LANGUAGE", ad.language)
    if ad.company_doc_infos:
        cdi = etree.SubElement(el, "COMPANY-DOC-INFOS")
        for c in ad.company_doc_infos:
            wrap = etree.SubElement(cdi, "COMPANY-DOC-INFO")
            if c.oid:
                etree.SubElement(wrap, "COMPANY-DATA-REF", {"ID-REF": c.oid})
    if ad.doc_revisions:
        revs = etree.SubElement(el, "DOC-REVISIONS")
        for rev in ad.doc_revisions:
            revs.append(_doc_revision_to_xml(rev))
    return el


def _sdg_to_xml(sdg: SpecialDataGroup) -> etree._Element:
    """Serialize one ``SDG`` element."""
    el = etree.Element("SDG")
    if sdg.caption:
        cap = etree.SubElement(el, "SDG-CAPTION")
        _add_text_child(cap, "SHORT-NAME", sdg.caption)
    for si, value in sdg.sd_items:
        sd = etree.SubElement(el, "SD", {"SI": si})
        sd.text = value
    return el


def _sdgs_to_xml(parent: etree._Element, sdgs: list[SpecialDataGroup]) -> None:
    """Append a ``<SDGS><SDG>...</SDG></SDGS>`` block when non-empty."""
    if not sdgs:
        return
    sdgs_el = etree.SubElement(parent, "SDGS")
    for sdg in sdgs:
        sdgs_el.append(_sdg_to_xml(sdg))


def _audience_to_xml(a: Audience) -> etree._Element:
    """Serialize an ``AUDIENCE`` element (with the 5 standard booleans)."""
    attrs = {
        "IS-SUPPLIER": "true" if a.is_supplier else "false",
        "IS-DEVELOPMENT": "true" if a.is_development else "false",
        "IS-MANUFACTURING": "true" if a.is_manufacturing else "false",
        "IS-AFTERSALES": "true" if a.is_aftersales else "false",
        "IS-AFTERMARKET": "true" if a.is_aftermarket else "false",
    }
    el = etree.Element("AUDIENCE", attrs)
    if a.enabled_audiences:
        en = etree.SubElement(el, "ENABLED-AUDIENCE-REFS")
        for label in a.enabled_audiences:
            etree.SubElement(en, "ENABLED-AUDIENCE-REF", {"ID-REF": label})
    if a.disabled_audiences:
        dis = etree.SubElement(el, "DISABLED-AUDIENCE-REFS")
        for label in a.disabled_audiences:
            etree.SubElement(dis, "DISABLED-AUDIENCE-REF", {"ID-REF": label})
    return el


def _func_class_to_xml(fc: FunctionalClass) -> etree._Element:
    """Serialize one ``FUNCT-CLASS`` element."""
    el = etree.Element("FUNCT-CLASS")
    _add_identity(el, fc.oid, fc.short_name, fc.long_name)
    return el


# ---------------------------------------------------------------------------
# DOP-side elements
# ---------------------------------------------------------------------------


def _diag_coded_type_to_xml(dct: DiagCodedType) -> etree._Element:
    """Serialize a ``DIAG-CODED-TYPE`` element with xsi:type discriminator."""
    attrs = {"BASE-DATA-TYPE": dct.base_data_type}
    if not dct.is_highlow_byte_order:
        attrs["IS-HIGHLOW-BYTE-ORDER"] = "false"
    el = etree.Element("DIAG-CODED-TYPE", attrs)
    el.set(_XSI_TYPE, dct.coded_type)
    if dct.bit_length is not None:
        _add_text_child(el, "BIT-LENGTH", dct.bit_length)
    if dct.min_length is not None:
        _add_text_child(el, "MIN-LENGTH", dct.min_length)
    if dct.max_length is not None:
        _add_text_child(el, "MAX-LENGTH", dct.max_length)
    if dct.termination:
        _add_text_child(el, "TERMINATION", dct.termination)
    return el


def _physical_type_to_xml(pt: PhysicalType) -> etree._Element:
    """Serialize a ``PHYSICAL-TYPE`` element."""
    attrs = {"BASE-DATA-TYPE": pt.base_data_type}
    if pt.display_radix:
        attrs["DISPLAY-RADIX"] = pt.display_radix
    el = etree.Element("PHYSICAL-TYPE", attrs)
    if pt.precision is not None:
        _add_text_child(el, "PRECISION", pt.precision)
    return el


def _compu_scale_to_xml(cs: CompuScale) -> etree._Element:
    """Serialize a single ``COMPU-SCALE`` element."""
    el = etree.Element("COMPU-SCALE")
    if cs.short_label:
        _add_text_child(el, "SHORT-LABEL", cs.short_label)
    if cs.lower_limit is not None:
        _add_text_child(el, "LOWER-LIMIT", cs.lower_limit)
    if cs.upper_limit is not None:
        _add_text_child(el, "UPPER-LIMIT", cs.upper_limit)
    if cs.compu_inverse_value is not None:
        inv = etree.SubElement(el, "COMPU-INVERSE-VALUE")
        _add_text_child(inv, "V", cs.compu_inverse_value)
    if cs.compu_const is not None:
        const = etree.SubElement(el, "COMPU-CONST")
        # Heuristic: numeric strings are emitted as <V>, otherwise <VT>.
        text = str(cs.compu_const)
        try:
            float(text)
            _add_text_child(const, "V", text)
        except ValueError:
            _add_text_child(const, "VT", text)
    if cs.compu_rational_coeffs is not None:
        num, den = cs.compu_rational_coeffs
        rc = etree.SubElement(el, "COMPU-RATIONAL-COEFFS")
        if num:
            num_el = etree.SubElement(rc, "COMPU-NUMERATOR")
            for v in num:
                _add_text_child(num_el, "V", v)
        if den:
            den_el = etree.SubElement(rc, "COMPU-DENOMINATOR")
            for v in den:
                _add_text_child(den_el, "V", v)
    return el


def _compu_method_to_xml(cm: CompuMethod) -> etree._Element:
    """Serialize a ``COMPU-METHOD`` element."""
    el = etree.Element("COMPU-METHOD")
    _add_text_child(el, "CATEGORY", cm.category)
    if cm.compu_internal_to_phys:
        wrap = etree.SubElement(el, "COMPU-INTERNAL-TO-PHYS")
        scales = etree.SubElement(wrap, "COMPU-SCALES")
        for s in cm.compu_internal_to_phys:
            scales.append(_compu_scale_to_xml(s))
    if cm.compu_phys_to_internal:
        wrap = etree.SubElement(el, "COMPU-PHYS-TO-INTERNAL")
        scales = etree.SubElement(wrap, "COMPU-SCALES")
        for s in cm.compu_phys_to_internal:
            scales.append(_compu_scale_to_xml(s))
    return el


def _dop_to_xml(dop: DataObjectProp) -> etree._Element:
    """Serialize a ``DATA-OBJECT-PROP`` element."""
    el = etree.Element("DATA-OBJECT-PROP")
    _add_identity(el, dop.oid, dop.short_name, dop.long_name, dop.description)
    el.append(_compu_method_to_xml(dop.compu_method))
    el.append(_diag_coded_type_to_xml(dop.diag_coded_type))
    el.append(_physical_type_to_xml(dop.physical_type))
    if dop.internal_constr is not None:
        ic = etree.SubElement(el, "INTERNAL-CONSTR")
        lower, upper = dop.internal_constr
        _add_text_child(ic, "LOWER-LIMIT", lower)
        _add_text_child(ic, "UPPER-LIMIT", upper)
    if dop.unit_ref is not None:
        etree.SubElement(el, "UNIT-REF", _ref_attrs(dop.unit_ref))
    _sdgs_to_xml(el, dop.sdgs)
    return el


def _dtc_to_xml(dtc: Dtc) -> etree._Element:
    """Serialize a ``DTC`` element."""
    el = etree.Element("DTC")
    _add_identity(el, dtc.oid, dtc.short_name)
    _add_text_child(el, "TROUBLE-CODE", dtc.trouble_code)
    if dtc.display_trouble_code:
        _add_text_child(el, "DISPLAY-TROUBLE-CODE", dtc.display_trouble_code)
    if dtc.text:
        text = etree.SubElement(el, "TEXT")
        text.text = dtc.text
    if dtc.level is not None:
        _add_text_child(el, "LEVEL", dtc.level)
    if dtc.is_temporary:
        _add_text_child(el, "IS-TEMPORARY", "true")
    _sdgs_to_xml(el, dtc.sdgs)
    return el


def _dtc_dop_to_xml(d: DtcDop) -> etree._Element:
    """Serialize a ``DTC-DOP`` element."""
    el = etree.Element("DTC-DOP")
    _add_identity(el, d.oid, d.short_name, d.long_name, d.description)
    el.append(_diag_coded_type_to_xml(d.diag_coded_type))
    el.append(_physical_type_to_xml(d.physical_type))
    el.append(_compu_method_to_xml(d.compu_method))
    if d.dtcs:
        dtcs = etree.SubElement(el, "DTCS")
        for dtc in d.dtcs:
            dtcs.append(_dtc_to_xml(dtc))
    if not d.is_visible:
        _add_text_child(el, "IS-VISIBLE", "false")
    return el


# ---------------------------------------------------------------------------
# Structures / fields / tables / muxes / env data
# ---------------------------------------------------------------------------


def _param_to_xml(param: Param) -> etree._Element:
    """Serialize one ``PARAM`` element (with xsi:type and optional DOP ref)."""
    attrs: dict[str, str] = {}
    if param.semantic:
        attrs["SEMANTIC"] = param.semantic
    el = etree.Element("PARAM", attrs)
    el.set(_XSI_TYPE, param.param_kind or "VALUE")
    _add_identity(el, param.oid, param.short_name)
    if param.description:
        _add_desc(el, param.description)
    _add_text_child(el, "BYTE-POSITION", param.byte_position)
    if param.bit_position is not None:
        _add_text_child(el, "BIT-POSITION", param.bit_position)
    if param.coded_value is not None:
        _add_text_child(el, "CODED-VALUE", param.coded_value)
    if param.phys_constant_value is not None:
        pcv = etree.SubElement(el, "PHYS-CONSTANT-VALUE")
        _add_text_child(pcv, "V", param.phys_constant_value)
    if param.request_byte_pos is not None:
        _add_text_child(el, "REQUEST-BYTE-POS", param.request_byte_pos)
    # DOP reference: prefer id_ref when both are present (per spec).
    if param.dop_ref is not None:
        etree.SubElement(el, "DOP-REF", _ref_attrs(param.dop_ref))
    elif param.dop_snref is not None:
        etree.SubElement(el, "DOP-SNREF", _snref_attrs(param.dop_snref))
    # Inline diag-coded type for CODED-CONST / RESERVED / NRC-CONST when no DOP
    # is referenced — ODX requires either a DOP ref or an inline coding.
    if (param.dop_ref is None and param.dop_snref is None
            and param.bit_length is not None
            and param.param_kind in {
                "CODED-CONST", "RESERVED", "NRC-CONST",
                "PHYS-CONST", "MATCHING-REQUEST-PARAM",
            }):
        inline = etree.SubElement(
            el, "DIAG-CODED-TYPE",
            {"BASE-DATA-TYPE": "A_UINT32"},
        )
        inline.set(_XSI_TYPE, "STANDARD-LENGTH-TYPE")
        _add_text_child(inline, "BIT-LENGTH", param.bit_length)
    return el


def _params_block(parent: etree._Element, params: list[Param]) -> None:
    """Append ``<PARAMS><PARAM .../></PARAMS>`` to ``parent`` when non-empty."""
    if not params:
        return
    block = etree.SubElement(parent, "PARAMS")
    for p in params:
        block.append(_param_to_xml(p))


def _structure_to_xml(s: Structure) -> etree._Element:
    """Serialize a ``STRUCTURE`` element."""
    el = etree.Element("STRUCTURE")
    _add_identity(el, s.oid, s.short_name, s.long_name)
    if s.byte_size is not None:
        _add_text_child(el, "BYTE-SIZE", s.byte_size)
    _params_block(el, s.params)
    return el


def _end_of_pdu_field_to_xml(f: EndOfPduField) -> etree._Element:
    el = etree.Element("END-OF-PDU-FIELD")
    _add_identity(el, f.oid, f.short_name)
    if f.structure_ref is not None:
        etree.SubElement(el, "BASIC-STRUCTURE-REF", _ref_attrs(f.structure_ref))
    _add_text_child(el, "MIN-NUMBER-OF-ITEMS", f.min_number_of_items)
    if f.max_number_of_items is not None:
        _add_text_child(el, "MAX-NUMBER-OF-ITEMS", f.max_number_of_items)
    return el


def _static_field_to_xml(f: StaticField) -> etree._Element:
    el = etree.Element("STATIC-FIELD")
    _add_identity(el, f.oid, f.short_name)
    if f.structure_ref is not None:
        etree.SubElement(el, "BASIC-STRUCTURE-REF", _ref_attrs(f.structure_ref))
    _add_text_child(el, "FIXED-NUMBER-OF-ITEMS", f.fixed_number_of_items)
    if f.item_byte_size is not None:
        _add_text_child(el, "ITEM-BYTE-SIZE", f.item_byte_size)
    return el


def _dynamic_endmarker_field_to_xml(f: DynamicEndmarkerField) -> etree._Element:
    el = etree.Element("DYNAMIC-ENDMARKER-FIELD")
    _add_identity(el, f.oid, f.short_name)
    if f.structure_ref is not None:
        etree.SubElement(el, "BASIC-STRUCTURE-REF", _ref_attrs(f.structure_ref))
    if f.termination_value is not None:
        _add_text_child(el, "TERMINATION-VALUE", f.termination_value)
    return el


def _table_row_to_xml(row: TableRow) -> etree._Element:
    el = etree.Element("TABLE-ROW")
    _add_identity(el, row.oid, row.short_name, description=row.description)
    if row.key is not None:
        _add_text_child(el, "KEY", row.key)
    if row.structure_ref is not None:
        etree.SubElement(el, "STRUCTURE-REF", _ref_attrs(row.structure_ref))
    if row.dop_ref is not None:
        etree.SubElement(el, "DATA-OBJECT-PROP-REF", _ref_attrs(row.dop_ref))
    return el


def _table_to_xml(t: Table) -> etree._Element:
    el = etree.Element("TABLE")
    _add_identity(el, t.oid, t.short_name, t.long_name)
    if t.key_dop_ref is not None:
        etree.SubElement(el, "KEY-DOP-REF", _ref_attrs(t.key_dop_ref))
    if t.table_rows:
        rows = etree.SubElement(el, "TABLE-ROWS")
        for r in t.table_rows:
            rows.append(_table_row_to_xml(r))
    return el


def _mux_case_to_xml(c: MuxCase) -> etree._Element:
    el = etree.Element("CASE")
    if c.short_name:
        _add_text_child(el, "SHORT-NAME", c.short_name)
    if c.lower_limit is not None:
        _add_text_child(el, "LOWER-LIMIT", c.lower_limit)
    if c.upper_limit is not None:
        _add_text_child(el, "UPPER-LIMIT", c.upper_limit)
    if c.structure_ref is not None:
        etree.SubElement(el, "STRUCTURE-REF", _ref_attrs(c.structure_ref))
    return el


def _mux_to_xml(m: Mux) -> etree._Element:
    el = etree.Element("MUX")
    _add_identity(el, m.oid, m.short_name)
    _add_text_child(el, "BYTE-POSITION", m.byte_position)
    if m.switch_key is not None:
        sk = etree.SubElement(el, "SWITCH-KEY")
        sk.append(_param_to_xml(m.switch_key))
    if m.default_case is not None:
        dc = etree.SubElement(el, "DEFAULT-CASE")
        dc.append(_mux_case_to_xml(m.default_case))
    if m.cases:
        cases = etree.SubElement(el, "CASES")
        for case in m.cases:
            cases.append(_mux_case_to_xml(case))
    return el


def _env_data_desc_to_xml(d: EnvDataDesc) -> etree._Element:
    el = etree.Element("ENV-DATA-DESC")
    _add_identity(el, d.oid, d.short_name)
    if d.param_snref is not None:
        etree.SubElement(el, "PARAM-SNREF", _snref_attrs(d.param_snref))
    if d.env_data_refs:
        wrap = etree.SubElement(el, "ENV-DATA-REFS")
        for r in d.env_data_refs:
            etree.SubElement(wrap, "ENV-DATA-REF", _ref_attrs(r))
    return el


def _env_data_to_xml(d: EnvData) -> etree._Element:
    el = etree.Element("ENV-DATA")
    _add_identity(el, d.oid, d.short_name)
    _params_block(el, d.params)
    return el


# ---------------------------------------------------------------------------
# Unit spec
# ---------------------------------------------------------------------------


def _unit_to_xml(u: Unit) -> etree._Element:
    el = etree.Element("UNIT")
    _add_identity(el, u.oid, u.short_name, u.long_name)
    if u.display_name:
        _add_text_child(el, "DISPLAY-NAME", u.display_name)
    if u.factor_si_to_unit is not None:
        _add_text_child(el, "FACTOR-SI-TO-UNIT", u.factor_si_to_unit)
    if u.offset_si_to_unit is not None:
        _add_text_child(el, "OFFSET-SI-TO-UNIT", u.offset_si_to_unit)
    if u.physical_dimension_ref is not None:
        etree.SubElement(el, "PHYSICAL-DIMENSION-REF",
                         _ref_attrs(u.physical_dimension_ref))
    return el


def _unit_group_to_xml(g: UnitGroup) -> etree._Element:
    el = etree.Element("UNIT-GROUP")
    _add_identity(el, g.oid, g.short_name, g.long_name)
    if g.category:
        _add_text_child(el, "CATEGORY", g.category)
    if g.unit_refs:
        wrap = etree.SubElement(el, "UNIT-REFS")
        for r in g.unit_refs:
            etree.SubElement(wrap, "UNIT-REF", _ref_attrs(r))
    return el


def _physical_dimension_to_xml(dim_id: Any) -> etree._Element:
    el = etree.Element("PHYSICAL-DIMENSION")
    _add_identity(el, dim_id.oid, dim_id.short_name,
                  dim_id.long_name, dim_id.description)
    return el


def _unit_spec_to_xml(us: UnitSpec) -> etree._Element:
    el = etree.Element("UNIT-SPEC")
    if us.units:
        units = etree.SubElement(el, "UNITS")
        for u in us.units:
            units.append(_unit_to_xml(u))
    if us.unit_groups:
        groups = etree.SubElement(el, "UNIT-GROUPS")
        for g in us.unit_groups:
            groups.append(_unit_group_to_xml(g))
    if us.physical_dimensions:
        dims = etree.SubElement(el, "PHYSICAL-DIMENSIONS")
        for d in us.physical_dimensions:
            dims.append(_physical_dimension_to_xml(d))
    return el


# ---------------------------------------------------------------------------
# Diag-comms / requests / responses
# ---------------------------------------------------------------------------


def _diag_service_to_xml(svc: DiagService) -> etree._Element:
    """Serialize a single ``DIAG-SERVICE`` element."""
    attrs: dict[str, str] = {}
    if svc.semantic:
        attrs["SEMANTIC"] = svc.semantic
    if svc.addressing:
        attrs["ADDRESSING"] = svc.addressing
    attrs["IS-EXECUTABLE"] = "true" if svc.is_executable else "false"
    if svc.transmission_mode:
        attrs["TRANSMISSION-MODE"] = svc.transmission_mode
    el = etree.Element("DIAG-SERVICE", attrs)
    _add_identity(el, svc.oid, svc.short_name, svc.long_name, svc.description)
    if svc.audience is not None:
        el.append(_audience_to_xml(svc.audience))
    _add_ref_list(el, "FUNCT-CLASS-REFS", "FUNCT-CLASS-REF",
                  svc.functional_class_refs)
    _add_ref_element(el, "REQUEST-REF", svc.request_ref)
    _add_ref_list(el, "POS-RESPONSE-REFS", "POS-RESPONSE-REF",
                  svc.pos_response_refs)
    _add_ref_list(el, "NEG-RESPONSE-REFS", "NEG-RESPONSE-REF",
                  svc.neg_response_refs)
    _add_ref_list(el, "COMPARAM-REFS", "COMPARAM-REF", svc.comparam_refs)
    _sdgs_to_xml(el, svc.sdgs)
    return el


def _request_to_xml(req: Request) -> etree._Element:
    """Serialize a ``REQUEST`` element."""
    el = etree.Element("REQUEST")
    _add_identity(el, req.oid, req.short_name, req.long_name)
    _params_block(el, req.params)
    return el


def _response_to_xml(resp: Response) -> etree._Element:
    """Serialize a ``POS-RESPONSE``, ``NEG-RESPONSE`` or ``GLOBAL-NEG-RESPONSE``.

    The tag name is derived from ``resp.response_type``; the IR ships the
    response_type as the literal element name to keep the writer trivial.
    """
    tag = resp.response_type or "POS-RESPONSE"
    el = etree.Element(tag)
    _add_identity(el, resp.oid, resp.short_name, resp.long_name)
    _params_block(el, resp.params)
    return el


# ---------------------------------------------------------------------------
# Diag-layer family
# ---------------------------------------------------------------------------


def _ddds_to_xml(ddds: DiagDataDictionarySpec) -> etree._Element:
    """Serialize a ``DIAG-DATA-DICTIONARY-SPEC`` element."""
    el = etree.Element("DIAG-DATA-DICTIONARY-SPEC")
    if ddds.dtc_dops:
        wrap = etree.SubElement(el, "DTC-DOPS")
        for d in ddds.dtc_dops:
            wrap.append(_dtc_dop_to_xml(d))
    if ddds.env_data_descs:
        wrap = etree.SubElement(el, "ENV-DATA-DESCS")
        for d in ddds.env_data_descs:
            wrap.append(_env_data_desc_to_xml(d))
    if ddds.data_object_props:
        wrap = etree.SubElement(el, "DATA-OBJECT-PROPS")
        for d in ddds.data_object_props:
            wrap.append(_dop_to_xml(d))
    if ddds.structures:
        wrap = etree.SubElement(el, "STRUCTURES")
        for s in ddds.structures:
            wrap.append(_structure_to_xml(s))
    if ddds.static_fields:
        wrap = etree.SubElement(el, "STATIC-FIELDS")
        for s in ddds.static_fields:
            wrap.append(_static_field_to_xml(s))
    if ddds.end_of_pdu_fields:
        wrap = etree.SubElement(el, "END-OF-PDU-FIELDS")
        for f in ddds.end_of_pdu_fields:
            wrap.append(_end_of_pdu_field_to_xml(f))
    if ddds.dynamic_endmarker_fields:
        wrap = etree.SubElement(el, "DYNAMIC-ENDMARKER-FIELDS")
        for f in ddds.dynamic_endmarker_fields:
            wrap.append(_dynamic_endmarker_field_to_xml(f))
    if ddds.muxes:
        wrap = etree.SubElement(el, "MUXS")
        for m in ddds.muxes:
            wrap.append(_mux_to_xml(m))
    if ddds.env_datas:
        wrap = etree.SubElement(el, "ENV-DATAS")
        for d in ddds.env_datas:
            wrap.append(_env_data_to_xml(d))
    if ddds.tables:
        wrap = etree.SubElement(el, "TABLES")
        for t in ddds.tables:
            wrap.append(_table_to_xml(t))
    if ddds.unit_spec is not None:
        el.append(_unit_spec_to_xml(ddds.unit_spec))
    return el


def _ecu_variant_pattern_to_xml(pattern: EcuVariantPattern) -> etree._Element:
    """Serialize an ``ECU-VARIANT-PATTERN`` element."""
    el = etree.Element("ECU-VARIANT-PATTERN")
    if pattern.matching_parameters:
        wrap = etree.SubElement(el, "MATCHING-PARAMETERS")
        for ref, expected in pattern.matching_parameters:
            mp = etree.SubElement(wrap, "MATCHING-PARAMETER")
            _add_text_child(mp, "EXPECTED-VALUE", expected)
            etree.SubElement(mp, "DIAG-COMM-SNREF", {"SHORT-NAME": ref})
    return el


def _layer_common(parent: etree._Element, layer: DiagLayerBase) -> None:
    """Populate the common DIAG-LAYER child elements onto ``parent``.

    Used by BASE-VARIANT, ECU-VARIANT, PROTOCOL, FUNCTIONAL-GROUP and
    ECU-SHARED-DATA — they all share the same content groups.
    """
    _add_identity(parent, layer.oid, layer.short_name, layer.long_name,
                  layer.description)
    admin = _admin_data_to_xml(layer.admin_data)
    if admin is not None:
        parent.append(admin)
    if layer.company_datas:
        wrap = etree.SubElement(parent, "COMPANY-DATAS")
        for c in layer.company_datas:
            wrap.append(_company_data_to_xml(c))
    if layer.functional_classes:
        wrap = etree.SubElement(parent, "FUNCT-CLASSS")
        for fc in layer.functional_classes:
            wrap.append(_func_class_to_xml(fc))
    if layer.audience is not None:
        parent.append(_audience_to_xml(layer.audience))
    if layer.diag_data_dictionary_spec is not None:
        parent.append(_ddds_to_xml(layer.diag_data_dictionary_spec))
    if layer.diag_comms:
        wrap = etree.SubElement(parent, "DIAG-COMMS")
        for s in layer.diag_comms:
            wrap.append(_diag_service_to_xml(s))
    if layer.requests:
        wrap = etree.SubElement(parent, "REQUESTS")
        for r in layer.requests:
            wrap.append(_request_to_xml(r))
    if layer.pos_responses:
        wrap = etree.SubElement(parent, "POS-RESPONSES")
        for r in layer.pos_responses:
            wrap.append(_response_to_xml(r))
    if layer.neg_responses:
        wrap = etree.SubElement(parent, "NEG-RESPONSES")
        for r in layer.neg_responses:
            wrap.append(_response_to_xml(r))
    if layer.global_neg_responses:
        wrap = etree.SubElement(parent, "GLOBAL-NEG-RESPONSES")
        for r in layer.global_neg_responses:
            wrap.append(_response_to_xml(r))
    _add_ref_list(parent, "IMPORT-REFS", "IMPORT-REF", layer.import_refs)
    _add_ref_list(parent, "PARENT-REFS", "PARENT-REF", layer.parent_refs)
    _add_ref_list(parent, "COMPARAM-REFS", "COMPARAM-REF", layer.comparam_refs)
    if layer.ecu_variant_patterns:
        wrap = etree.SubElement(parent, "ECU-VARIANT-PATTERNS")
        for p in layer.ecu_variant_patterns:
            wrap.append(_ecu_variant_pattern_to_xml(p))
    _sdgs_to_xml(parent, layer.sdgs)


def _base_variant_to_xml(bv: BaseVariant) -> etree._Element:
    el = etree.Element("BASE-VARIANT")
    _layer_common(el, bv)
    if bv.base_variant_pattern is not None:
        wrap = etree.SubElement(el, "BASE-VARIANT-PATTERN")
        wrap.append(_ecu_variant_pattern_to_xml(bv.base_variant_pattern))
    return el


def _ecu_variant_to_xml(ev: EcuVariant) -> etree._Element:
    el = etree.Element("ECU-VARIANT")
    _layer_common(el, ev)
    if ev.base_variant_ref is not None:
        etree.SubElement(el, "BASE-VARIANT-REF", _ref_attrs(ev.base_variant_ref))
    return el


def _protocol_to_xml(p: Protocol) -> etree._Element:
    el = etree.Element("PROTOCOL")
    _layer_common(el, p)
    return el


def _functional_group_to_xml(g: FunctionalGroup) -> etree._Element:
    el = etree.Element("FUNCTIONAL-GROUP")
    _layer_common(el, g)
    return el


def _ecu_shared_data_to_xml(esd: EcuSharedData) -> etree._Element:
    el = etree.Element("ECU-SHARED-DATA")
    _layer_common(el, esd)
    return el


def _diag_layer_container_to_xml(dlc: DiagLayerContainer) -> etree._Element:
    """Serialize the ``DIAG-LAYER-CONTAINER`` root child."""
    el = etree.Element("DIAG-LAYER-CONTAINER")
    _add_identity(el, dlc.oid, dlc.short_name, dlc.long_name, dlc.description)
    admin = _admin_data_to_xml(dlc.admin_data)
    if admin is not None:
        el.append(admin)
    if dlc.company_datas:
        wrap = etree.SubElement(el, "COMPANY-DATAS")
        for c in dlc.company_datas:
            wrap.append(_company_data_to_xml(c))
    if dlc.ecu_shared_datas:
        wrap = etree.SubElement(el, "ECU-SHARED-DATAS")
        for esd in dlc.ecu_shared_datas:
            wrap.append(_ecu_shared_data_to_xml(esd))
    if dlc.protocols:
        wrap = etree.SubElement(el, "PROTOCOLS")
        for p in dlc.protocols:
            wrap.append(_protocol_to_xml(p))
    if dlc.functional_groups:
        wrap = etree.SubElement(el, "FUNCTIONAL-GROUPS")
        for g in dlc.functional_groups:
            wrap.append(_functional_group_to_xml(g))
    if dlc.base_variants:
        wrap = etree.SubElement(el, "BASE-VARIANTS")
        for bv in dlc.base_variants:
            wrap.append(_base_variant_to_xml(bv))
    if dlc.ecu_variants:
        wrap = etree.SubElement(el, "ECU-VARIANTS")
        for ev in dlc.ecu_variants:
            wrap.append(_ecu_variant_to_xml(ev))
    _add_ref_list(el, "ECU-SHARED-DATA-REFS", "ECU-SHARED-DATA-REF",
                  dlc.ecu_shared_data_refs)
    _add_ref_list(el, "PROTOCOL-REFS", "PROTOCOL-REF", dlc.protocol_refs)
    _add_ref_list(el, "FUNCTIONAL-GROUP-REFS", "FUNCTIONAL-GROUP-REF",
                  dlc.functional_group_refs)
    return el


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def serialize_odx_d(doc: OdxDocument) -> bytes:
    """Serialize an :class:`OdxDocument` to UTF-8 XML bytes.

    The document must be of category :class:`OdxCategory.DIAG_LAYER` and
    expose a populated :class:`DiagLayerContainer` via ``doc.content``.

    :raises ValueError: if ``doc.category`` is not ``DIAG_LAYER`` or
        ``doc.content`` is ``None``.
    """
    if doc.category != OdxCategory.DIAG_LAYER:
        raise ValueError(
            f"serialize_odx_d() requires category=DIAG_LAYER, got {doc.category!r}"
        )
    dlc = doc.content
    if dlc is None or not isinstance(dlc, DiagLayerContainer):
        raise ValueError(
            "serialize_odx_d() requires doc.content to be a DiagLayerContainer; "
            f"got {type(dlc).__name__}"
        )

    root = etree.Element(
        "ODX",
        {"MODEL-VERSION": doc.model_version or "2.2.0"},
        nsmap=NSMAP,
    )
    root.append(_diag_layer_container_to_xml(dlc))

    return etree.tostring(
        root,
        xml_declaration=True,
        encoding="UTF-8",
        pretty_print=True,
        standalone=False,
    )


def write_odx_d(doc: OdxDocument, out_path: Path) -> Path:
    """Serialize ``doc`` to disk at ``out_path`` (creating parent dirs).

    Returns the resolved path on success.
    """
    payload = serialize_odx_d(doc)
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(payload)
    return out_path


__all__ = ["serialize_odx_d", "write_odx_d"]
