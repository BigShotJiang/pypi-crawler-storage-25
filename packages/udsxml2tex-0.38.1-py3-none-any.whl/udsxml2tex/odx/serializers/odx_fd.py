"""ODX-FD (Function Dictionary) XML serializer.

This module turns an :class:`OdxDocument` whose
``category == OdxCategory.FUNCTION_DICTIONARY`` into the corresponding
ODX 2.2.0 ``.odx-fd`` XML document. The shape follows ISO 22901-1 § 10
(``FUNCTION-DICTIONARY-SPEC`` content group): ``FUNCTION-GROUPS``
containing ``FUNCTION-NODE`` lists plus optional ``AUDIENCE-GROUPS``.

The serializer is non-destructive: it never mutates the IR. Helpers
shared with other ODX writers live in
:mod:`udsxml2tex.odx.serializers._shared`.
"""

from __future__ import annotations

from pathlib import Path

from lxml import etree

from udsxml2tex.odx.models_odx import (
    AudienceGroup,
    FunctionDictionarySpec,
    FunctionGroup,
    FunctionNode,
    OdxCategory,
    OdxDocument,
)
from udsxml2tex.odx.serializers._shared import (
    add_admin_data,
    add_audience,
    add_company_datas,
    add_description,
    add_long_name,
    add_sdgs,
    add_text_child,
    make_root,
    serialize_element,
    set_ref_attrs,
)


def _add_function_node(parent: etree._Element, node: FunctionNode) -> None:
    """Emit one ``<FUNCTION-NODE ID="...">`` child."""
    elem = etree.SubElement(parent, "FUNCTION-NODE")
    if node.oid:
        elem.set("ID", node.oid)
    add_text_child(elem, "SHORT-NAME", node.short_name)
    add_long_name(elem, node.long_name)
    add_description(elem, node.description)
    if node.service_refs:
        wrap = etree.SubElement(elem, "DIAG-COMM-REFS")
        for ref in node.service_refs:
            ref_el = etree.SubElement(wrap, "DIAG-COMM-REF")
            set_ref_attrs(ref_el, ref)


def _add_function_group(parent: etree._Element, group: FunctionGroup) -> None:
    """Emit one ``<FUNCTION-GROUP ID="...">`` child with its nodes."""
    elem = etree.SubElement(parent, "FUNCTION-GROUP")
    if group.oid:
        elem.set("ID", group.oid)
    add_text_child(elem, "SHORT-NAME", group.short_name)
    add_long_name(elem, group.long_name)
    add_description(elem, group.description)
    if group.function_nodes:
        wrap = etree.SubElement(elem, "FUNCTION-NODES")
        for node in group.function_nodes:
            _add_function_node(wrap, node)


def _add_audience_group(parent: etree._Element, ag: AudienceGroup) -> None:
    """Emit one ``<AUDIENCE-GROUP ID="...">`` child."""
    elem = etree.SubElement(parent, "AUDIENCE-GROUP")
    if ag.oid:
        elem.set("ID", ag.oid)
    add_text_child(elem, "SHORT-NAME", ag.short_name)
    if ag.audiences:
        wrap = etree.SubElement(elem, "AUDIENCES")
        for aud in ag.audiences:
            add_audience(wrap, aud)


def _build_fd_element(spec: FunctionDictionarySpec) -> etree._Element:
    """Materialise the ``<FUNCTION-DICTIONARY-SPEC>`` element under ``<ODX>``."""
    root = make_root()
    elem = etree.SubElement(root, "FUNCTION-DICTIONARY-SPEC")
    if spec.oid:
        elem.set("ID", spec.oid)
    add_text_child(elem, "SHORT-NAME", spec.short_name)
    add_long_name(elem, spec.long_name)
    add_description(elem, spec.description)
    if spec.function_groups:
        wrap = etree.SubElement(elem, "FUNCTION-GROUPS")
        for g in spec.function_groups:
            _add_function_group(wrap, g)
    if spec.audience_groups:
        wrap = etree.SubElement(elem, "AUDIENCE-GROUPS")
        for ag in spec.audience_groups:
            _add_audience_group(wrap, ag)
    return root


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def serialize_odx_fd(doc: OdxDocument) -> bytes:
    """Serialize an ``OdxDocument(category=FUNCTION_DICTIONARY)`` to UTF-8 XML bytes.

    Raises
    ------
    ValueError
        If ``doc.category`` is not :attr:`OdxCategory.FUNCTION_DICTIONARY`
        or ``doc.function_dictionary_spec`` is ``None``.
    """
    if doc.category != OdxCategory.FUNCTION_DICTIONARY:
        raise ValueError(
            "serialize_odx_fd requires FUNCTION_DICTIONARY, "
            f"got {doc.category.value}"
        )
    spec = doc.function_dictionary_spec
    if spec is None:
        raise ValueError(
            "OdxDocument.function_dictionary_spec is None; nothing to serialize"
        )
    root = _build_fd_element(spec)
    fd_elem = root[0]
    # ADMIN-DATA / COMPANY-DATAS get placed just after SHORT-NAME / LONG-NAME / DESC.
    insert_at = 0
    for idx, child in enumerate(fd_elem):
        if child.tag in {"SHORT-NAME", "LONG-NAME", "DESC"}:
            insert_at = idx + 1
        else:
            break
    if doc.admin_data is not None:
        tmp = etree.Element("TMP")
        add_admin_data(tmp, doc.admin_data)
        ad = tmp.find("ADMIN-DATA")
        if ad is not None:
            fd_elem.insert(insert_at, ad)
            insert_at += 1
    if doc.admin_data is not None and doc.admin_data.company_doc_infos:
        tmp = etree.Element("TMP")
        add_company_datas(tmp, doc.admin_data.company_doc_infos)
        cds = tmp.find("COMPANY-DATAS")
        if cds is not None:
            fd_elem.insert(insert_at, cds)
    # SDGs at end. The IR does not carry FD-level SDGs directly today; the
    # call is kept so that future SDG attachments flow through this writer
    # without requiring a code change.
    add_sdgs(fd_elem, [])
    return serialize_element(root)


def write_odx_fd(doc: OdxDocument, out_path: Path) -> Path:
    """Serialize ``doc`` and write the bytes to ``out_path``.

    The parent directory is created when missing. Returns the resolved
    output path for convenience.
    """
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(serialize_odx_fd(doc))
    return out_path


__all__ = ["serialize_odx_fd", "write_odx_fd"]
