"""ODX XML serializers — one module per ODX 2.2.0 category.

This subpackage centralises the eight category-specific XML emitters that
materialise an :class:`udsxml2tex.odx.models_odx.OdxDocument` into ISO
22901-1 / ODX 2.2.0 XML bytes. The dispatch table :data:`_SERIALIZERS`
maps each :class:`OdxCategory` to its dedicated ``serialize_odx_*``
function; the convenience wrapper :func:`serialize` looks up the right
function for a given document at runtime.

Each ``serialize_odx_*`` returns ``bytes`` (UTF-8 XML); each
``write_odx_*`` writes the same bytes to a :class:`pathlib.Path`.
"""

from __future__ import annotations

from udsxml2tex.odx.models_odx import OdxCategory, OdxDocument
from udsxml2tex.odx.serializers.odx_c import serialize_odx_c, write_odx_c
from udsxml2tex.odx.serializers.odx_cs import serialize_odx_cs, write_odx_cs
from udsxml2tex.odx.serializers.odx_d import serialize_odx_d, write_odx_d
from udsxml2tex.odx.serializers.odx_e import serialize_odx_e, write_odx_e  # Agent 4 provides this
from udsxml2tex.odx.serializers.odx_f import serialize_odx_f, write_odx_f
from udsxml2tex.odx.serializers.odx_fd import serialize_odx_fd, write_odx_fd
from udsxml2tex.odx.serializers.odx_m import serialize_odx_m, write_odx_m
from udsxml2tex.odx.serializers.odx_v import serialize_odx_v, write_odx_v  # Agent 4 provides this

_SERIALIZERS = {
    OdxCategory.DIAG_LAYER: serialize_odx_d,
    OdxCategory.COMPARAM_SPEC: serialize_odx_c,
    OdxCategory.COMPARAM_SUBSET: serialize_odx_cs,
    OdxCategory.VEHICLE_INFO: serialize_odx_v,
    OdxCategory.ECU_SHARED_DATA: serialize_odx_e,
    OdxCategory.FLASH: serialize_odx_f,
    OdxCategory.FUNCTION_DICTIONARY: serialize_odx_fd,
    OdxCategory.MULTIPLE_ECU_JOB_SPEC: serialize_odx_m,
}


def serialize(doc: OdxDocument) -> bytes:
    """Dispatch an :class:`OdxDocument` to its category-specific serializer.

    Parameters
    ----------
    doc:
        The intermediate-representation document produced by
        :func:`udsxml2tex.odx.map_spec_to_odx` (or hand-built).

    Returns
    -------
    bytes
        Well-formed ODX 2.2.0 XML, UTF-8 encoded.

    Raises
    ------
    ValueError
        If the document's category does not have a registered serializer.
    """
    try:
        return _SERIALIZERS[doc.category](doc)
    except KeyError as exc:
        raise ValueError(f"No serializer for ODX category {doc.category!r}") from exc


__all__ = [
    "serialize",
    "_SERIALIZERS",
    "serialize_odx_d",
    "serialize_odx_c",
    "serialize_odx_cs",
    "serialize_odx_v",
    "serialize_odx_e",
    "serialize_odx_f",
    "serialize_odx_fd",
    "serialize_odx_m",
    "write_odx_d",
    "write_odx_c",
    "write_odx_cs",
    "write_odx_v",
    "write_odx_e",
    "write_odx_f",
    "write_odx_fd",
    "write_odx_m",
]
