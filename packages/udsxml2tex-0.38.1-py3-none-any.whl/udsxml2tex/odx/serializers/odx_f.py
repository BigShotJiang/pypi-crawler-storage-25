"""ODX-F (Flash) XML serializer.

This module turns an :class:`OdxDocument` whose
``category == OdxCategory.FLASH`` into the corresponding ODX 2.2.0
``.odx-f`` XML document. The shape follows ISO 22901-1 § 9
(``FLASH`` content group): ``ECU-MEMS`` carrying ``MEM`` blocks with
``SESSIONS``, ``DATABLOCKS`` and ``FLASHDATAS`` sub-lists.

The serializer is non-destructive: it never mutates the IR. Helpers
shared with other ODX writers live in
:mod:`udsxml2tex.odx.serializers._shared`.
"""

from __future__ import annotations

from pathlib import Path

from lxml import etree

from udsxml2tex.odx.models_odx import (
    EcuMem,
    FlashClass,
    Flashdata,
    FlashSession,
    OdxCategory,
    OdxDocument,
    Segment,
)
from udsxml2tex.odx.serializers._shared import (
    XSI_TYPE_ATTR,
    add_admin_data,
    add_company_datas,
    add_description,
    add_long_name,
    add_sdgs,
    add_text_child,
    make_root,
    serialize_element,
    set_ref_attrs,
)

# ---------------------------------------------------------------------------
# xsi:type discriminator for FLASHDATA (per ODX 2.2.0).
# ---------------------------------------------------------------------------

# The ODX 2.2.0 schema models FLASHDATA as an abstract type with two
# concrete subclasses, distinguished by xsi:type:
#
# * ``INTERN-FLASHDATA``: the data block is embedded (``DATA`` element).
# * ``EXTERN-FLASHDATA``: the data block is stored in a separate file
#   referenced via ``DATAFILE``.
#
# Without a ``datafile`` attribute we emit ``INTERN-FLASHDATA``; with it,
# ``EXTERN-FLASHDATA``.


def _flashdata_xsi_type(fd: Flashdata) -> str:
    """Return the xsi:type value for a :class:`Flashdata`."""
    return "EXTERN-FLASHDATA" if fd.datafile else "INTERN-FLASHDATA"


# ---------------------------------------------------------------------------
# Element builders
# ---------------------------------------------------------------------------


def _add_segment(parent: etree._Element, seg: Segment) -> None:
    """Emit one ``<SEGMENT ID="...">`` child with addresses."""
    elem = etree.SubElement(parent, "SEGMENT")
    if seg.oid:
        elem.set("ID", seg.oid)
    add_text_child(elem, "SHORT-NAME", seg.short_name)
    add_text_child(elem, "SOURCE-START-ADDRESS", seg.source_start_address)
    add_text_child(elem, "SOURCE-END-ADDRESS", seg.source_end_address)
    add_text_child(elem, "TARGET-START-ADDRESS", seg.target_start_address)
    add_text_child(elem, "TARGET-END-ADDRESS", seg.target_end_address)
    if seg.size_length is not None and seg.size_length != 0:
        add_text_child(elem, "SIZE-LENGTH", seg.size_length)
    if seg.encrypt_compress_method:
        add_text_child(
            elem,
            "COMPRESSION-ENCRYPTION-METHOD",
            seg.encrypt_compress_method,
        )


def _add_flashdata(parent: etree._Element, fd: Flashdata) -> None:
    """Emit one ``<FLASHDATA xsi:type="...">`` child."""
    elem = etree.SubElement(parent, "FLASHDATA")
    if fd.oid:
        elem.set("ID", fd.oid)
    elem.set(XSI_TYPE_ATTR, _flashdata_xsi_type(fd))
    add_text_child(elem, "SHORT-NAME", fd.short_name)
    add_long_name(elem, fd.long_name)
    if fd.format_id:
        add_text_child(elem, "DATA-FORMAT", fd.format_id)
    # Encrypt/compress method: always emitted (possibly empty) so consumers
    # can recognise the field even when not configured.
    if fd.encrypt_compress_method:
        add_text_child(elem, "ENCRYPT-COMPRESS-METHOD", fd.encrypt_compress_method)
    else:
        etree.SubElement(elem, "ENCRYPT-COMPRESS-METHOD")
    if fd.encryption_type:
        add_text_child(elem, "ENCRYPTION", fd.encryption_type)
    if fd.compression_type:
        add_text_child(elem, "COMPRESSION", fd.compression_type)
    if fd.datafile:
        add_text_child(elem, "DATAFILE", fd.datafile)


def _add_session(parent: etree._Element, sess: FlashSession) -> None:
    """Emit one ``<SESSION ID="...">`` child."""
    elem = etree.SubElement(parent, "SESSION")
    if sess.oid:
        elem.set("ID", sess.oid)
    add_text_child(elem, "SHORT-NAME", sess.short_name)
    add_long_name(elem, sess.long_name)
    if sess.security_method:
        add_text_child(elem, "SECURITY-METHOD", sess.security_method)
    if sess.expected_idents:
        wrap = etree.SubElement(elem, "EXPECTED-IDENTS")
        for ident in sess.expected_idents:
            ei = etree.SubElement(wrap, "EXPECTED-IDENT")
            add_text_child(ei, "SHORT-NAME", ident)
    if sess.segment_refs:
        wrap = etree.SubElement(elem, "SEGMENT-REFS")
        for ref in sess.segment_refs:
            ref_el = etree.SubElement(wrap, "SEGMENT-REF")
            set_ref_attrs(ref_el, ref)
    if sess.source_starts_at is not None:
        add_text_child(elem, "SOURCE-STARTS-AT", sess.source_starts_at)


def _add_ecu_mem(parent: etree._Element, mem: EcuMem) -> None:
    """Emit one ``<ECU-MEM ID="...">`` child with its ``<MEM>`` block."""
    elem = etree.SubElement(parent, "ECU-MEM")
    if mem.oid:
        elem.set("ID", mem.oid)
    add_text_child(elem, "SHORT-NAME", mem.short_name)
    add_long_name(elem, mem.long_name)
    mem_block = etree.SubElement(elem, "MEM")
    # ODX 2.2.0 places SESSIONS before DATABLOCKS / FLASHDATAS inside MEM.
    # The IR does not model DATABLOCKS separately, but a single DATABLOCK is
    # synthesised so that SEGMENTS can be expressed under MEM as required by
    # the schema.
    # SEGMENTS belong on DATABLOCK / SESSION but the IR carries them on EcuMem,
    # so we emit them under a synthetic DATABLOCK if needed.
    if mem.segments:
        datablocks = etree.SubElement(mem_block, "DATABLOCKS")
        block = etree.SubElement(datablocks, "DATABLOCK")
        block_id = f"{mem.oid}.datablock" if mem.oid else ""
        if block_id:
            block.set("ID", block_id)
        block.set("TYPE", "FLASH-DATA")
        add_text_child(block, "SHORT-NAME", f"{mem.short_name}_Datablock")
        segs = etree.SubElement(block, "SEGMENTS")
        for seg in mem.segments:
            _add_segment(segs, seg)


def _build_flash_element(fc: FlashClass) -> etree._Element:
    """Materialise the ``<FLASH>`` element under a fresh ``<ODX>`` root."""
    root = make_root()
    elem = etree.SubElement(root, "FLASH")
    if fc.oid:
        elem.set("ID", fc.oid)
    add_text_child(elem, "SHORT-NAME", fc.short_name)
    add_long_name(elem, fc.long_name)
    add_description(elem, fc.description)
    if fc.ecu_mems:
        wrap = etree.SubElement(elem, "ECU-MEMS")
        for mem in fc.ecu_mems:
            _add_ecu_mem(wrap, mem)
    # Sessions are emitted at the FLASH level to match the skeleton from the
    # task spec (one bootloader session per FlashClass is the common case).
    if fc.sessions:
        wrap = etree.SubElement(elem, "SESSIONS")
        for sess in fc.sessions:
            _add_session(wrap, sess)
    if fc.flashdatas:
        wrap = etree.SubElement(elem, "FLASHDATAS")
        for fd in fc.flashdatas:
            _add_flashdata(wrap, fd)
    if fc.download_id_codes:
        wrap = etree.SubElement(elem, "DOWNLOAD-ID-CODES")
        for code in fc.download_id_codes:
            add_text_child(wrap, "DOWNLOAD-ID-CODE", code)
    if fc.ecu_mem_ref is not None:
        ref_el = etree.SubElement(elem, "ECU-MEM-REF")
        set_ref_attrs(ref_el, fc.ecu_mem_ref)
    return root


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def serialize_odx_f(doc: OdxDocument) -> bytes:
    """Serialize an ``OdxDocument(category=FLASH)`` to UTF-8 XML bytes.

    Raises
    ------
    ValueError
        If ``doc.category`` is not :attr:`OdxCategory.FLASH` or
        ``doc.flash_class`` is ``None``.
    """
    if doc.category != OdxCategory.FLASH:
        raise ValueError(
            f"serialize_odx_f requires FLASH, got {doc.category.value}"
        )
    fc = doc.flash_class
    if fc is None:
        raise ValueError(
            "OdxDocument.flash_class is None; nothing to serialize"
        )
    root = _build_flash_element(fc)
    flash_elem = root[0]
    # Insert ADMIN-DATA / COMPANY-DATAS / SDGS in their canonical positions.
    # ADMIN-DATA goes immediately after SHORT-NAME / LONG-NAME / DESC.
    insert_at = 0
    for idx, child in enumerate(flash_elem):
        if child.tag in {"SHORT-NAME", "LONG-NAME", "DESC"}:
            insert_at = idx + 1
        else:
            break
    if doc.admin_data is not None:
        tmp = etree.Element("TMP")
        add_admin_data(tmp, doc.admin_data)
        ad = tmp.find("ADMIN-DATA")
        if ad is not None:
            flash_elem.insert(insert_at, ad)
            insert_at += 1
    # COMPANY-DATAS sourced from admin_data.company_doc_infos.
    if doc.admin_data is not None and doc.admin_data.company_doc_infos:
        tmp = etree.Element("TMP")
        add_company_datas(tmp, doc.admin_data.company_doc_infos)
        cds = tmp.find("COMPANY-DATAS")
        if cds is not None:
            flash_elem.insert(insert_at, cds)
    # SDGs are emitted last under the FLASH element. The IR does not carry
    # FLASH-level SDGs directly, so we surface them from admin_data when the
    # mapper has stashed any (none today, but reserved for future use).
    add_sdgs(flash_elem, [])
    return serialize_element(root)


def write_odx_f(doc: OdxDocument, out_path: Path) -> Path:
    """Serialize ``doc`` and write the bytes to ``out_path``.

    The parent directory is created when missing. Returns the resolved
    output path for convenience.
    """
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(serialize_odx_f(doc))
    return out_path


__all__ = ["serialize_odx_f", "write_odx_f"]
