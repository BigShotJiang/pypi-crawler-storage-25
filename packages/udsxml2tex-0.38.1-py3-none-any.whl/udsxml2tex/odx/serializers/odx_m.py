"""ODX-M (Multiple ECU Job) XML serializer.

This module turns an :class:`OdxDocument` whose
``category == OdxCategory.MULTIPLE_ECU_JOB_SPEC`` into the corresponding
ODX 2.2.0 ``.odx-m`` XML document. The shape follows ISO 22901-1 § 11
(``MULTIPLE-ECU-JOB-SPEC`` content group): ``ECU-STATES``,
``MULTIPLE-ECU-JOBS`` (with their ``PROGRAMMING-STEPS``) and
``PROG-CODES``.

The serializer is non-destructive: it never mutates the IR. Helpers
shared with other ODX writers live in
:mod:`udsxml2tex.odx.serializers._shared`.
"""

from __future__ import annotations

from pathlib import Path

from lxml import etree

from udsxml2tex.odx.models_odx import (
    EcuState,
    MultipleEcuJob,
    MultipleEcuJobSpec,
    OdxCategory,
    OdxDocument,
    ProgCode,
    ProgrammingStep,
)
from udsxml2tex.odx.serializers._shared import (
    add_admin_data,
    add_company_datas,
    add_description,
    add_long_name,
    add_sdgs,
    add_text_child,
    make_root,
    serialize_element,
    set_ref_attrs,
)


def _add_ecu_state(parent: etree._Element, state: EcuState) -> None:
    """Emit one ``<ECU-STATE ID="...">`` child."""
    elem = etree.SubElement(parent, "ECU-STATE")
    if state.oid:
        elem.set("ID", state.oid)
    add_text_child(elem, "SHORT-NAME", state.short_name)
    add_description(elem, state.description)


def _add_programming_step(parent: etree._Element, step: ProgrammingStep) -> None:
    """Emit one ``<PROGRAMMING-STEP ID="...">`` child."""
    elem = etree.SubElement(parent, "PROGRAMMING-STEP")
    if step.oid:
        elem.set("ID", step.oid)
    add_text_child(elem, "SHORT-NAME", step.short_name)
    add_description(elem, step.description)
    if step.prog_code_ref is not None:
        ref_el = etree.SubElement(elem, "PROG-CODE-REF")
        set_ref_attrs(ref_el, step.prog_code_ref)
    if step.target_ecu_refs:
        wrap = etree.SubElement(elem, "TARGET-ECU-REFS")
        for ref in step.target_ecu_refs:
            ref_el = etree.SubElement(wrap, "TARGET-ECU-REF")
            set_ref_attrs(ref_el, ref)


def _add_multiple_ecu_job(parent: etree._Element, job: MultipleEcuJob) -> None:
    """Emit one ``<MULTIPLE-ECU-JOB ID="...">`` child."""
    elem = etree.SubElement(parent, "MULTIPLE-ECU-JOB")
    if job.oid:
        elem.set("ID", job.oid)
    add_text_child(elem, "SHORT-NAME", job.short_name)
    add_long_name(elem, job.long_name)
    add_description(elem, job.description)
    if job.programming_steps:
        wrap = etree.SubElement(elem, "PROGRAMMING-STEPS")
        for step in job.programming_steps:
            _add_programming_step(wrap, step)


def _add_prog_code(parent: etree._Element, pc: ProgCode) -> None:
    """Emit one ``<PROG-CODE ID="...">`` child."""
    elem = etree.SubElement(parent, "PROG-CODE")
    if pc.oid:
        elem.set("ID", pc.oid)
    add_text_child(elem, "SHORT-NAME", pc.short_name)
    if pc.code_file:
        add_text_child(elem, "CODE-FILE", pc.code_file)
    if pc.encryption:
        add_text_child(elem, "ENCRYPTION", pc.encryption)
    if pc.syntax:
        add_text_child(elem, "SYNTAX", pc.syntax)
    if pc.revision:
        add_text_child(elem, "REVISION", pc.revision)


def _build_m_element(spec: MultipleEcuJobSpec) -> etree._Element:
    """Materialise the ``<MULTIPLE-ECU-JOB-SPEC>`` element under ``<ODX>``."""
    root = make_root()
    elem = etree.SubElement(root, "MULTIPLE-ECU-JOB-SPEC")
    if spec.oid:
        elem.set("ID", spec.oid)
    add_text_child(elem, "SHORT-NAME", spec.short_name)
    add_long_name(elem, spec.long_name)
    add_description(elem, spec.description)
    if spec.ecu_states:
        wrap = etree.SubElement(elem, "ECU-STATES")
        for s in spec.ecu_states:
            _add_ecu_state(wrap, s)
    if spec.multiple_ecu_jobs:
        wrap = etree.SubElement(elem, "MULTIPLE-ECU-JOBS")
        for job in spec.multiple_ecu_jobs:
            _add_multiple_ecu_job(wrap, job)
    if spec.prog_codes:
        wrap = etree.SubElement(elem, "PROG-CODES")
        for pc in spec.prog_codes:
            _add_prog_code(wrap, pc)
    return root


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def serialize_odx_m(doc: OdxDocument) -> bytes:
    """Serialize an ``OdxDocument(category=MULTIPLE_ECU_JOB_SPEC)`` to UTF-8 XML bytes.

    Raises
    ------
    ValueError
        If ``doc.category`` is not :attr:`OdxCategory.MULTIPLE_ECU_JOB_SPEC`
        or ``doc.multiple_ecu_job_spec`` is ``None``.
    """
    if doc.category != OdxCategory.MULTIPLE_ECU_JOB_SPEC:
        raise ValueError(
            "serialize_odx_m requires MULTIPLE_ECU_JOB_SPEC, "
            f"got {doc.category.value}"
        )
    spec = doc.multiple_ecu_job_spec
    if spec is None:
        raise ValueError(
            "OdxDocument.multiple_ecu_job_spec is None; nothing to serialize"
        )
    root = _build_m_element(spec)
    m_elem = root[0]
    # ADMIN-DATA / COMPANY-DATAS go after SHORT-NAME / LONG-NAME / DESC.
    insert_at = 0
    for idx, child in enumerate(m_elem):
        if child.tag in {"SHORT-NAME", "LONG-NAME", "DESC"}:
            insert_at = idx + 1
        else:
            break
    if doc.admin_data is not None:
        tmp = etree.Element("TMP")
        add_admin_data(tmp, doc.admin_data)
        ad = tmp.find("ADMIN-DATA")
        if ad is not None:
            m_elem.insert(insert_at, ad)
            insert_at += 1
    if doc.admin_data is not None and doc.admin_data.company_doc_infos:
        tmp = etree.Element("TMP")
        add_company_datas(tmp, doc.admin_data.company_doc_infos)
        cds = tmp.find("COMPANY-DATAS")
        if cds is not None:
            m_elem.insert(insert_at, cds)
    # SDGs at end. The IR does not currently surface ODX-M-level SDGs; the
    # call is kept so future attachments flow through this writer.
    add_sdgs(m_elem, [])
    return serialize_element(root)


def write_odx_m(doc: OdxDocument, out_path: Path) -> Path:
    """Serialize ``doc`` and write the bytes to ``out_path``.

    The parent directory is created when missing. Returns the resolved
    output path for convenience.
    """
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(serialize_odx_m(doc))
    return out_path


__all__ = ["serialize_odx_m", "write_odx_m"]
