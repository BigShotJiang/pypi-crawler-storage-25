"""Serializer for ODX-V (VEHICLE-INFO-SPEC) documents.

Converts an :class:`OdxDocument` carrying a populated
:class:`VehicleInfoSpec` into the canonical ISO 22901-1 / ASAM MCD-2 D
vehicle-information XML grammar.

Public API
----------

* :func:`serialize_odx_v` — :class:`OdxDocument` → ``bytes``.
* :func:`write_odx_v`     — :class:`OdxDocument` → on-disk ``.odx-v`` file.

The output mirrors the ``odx-v`` reference layout::

    <ODX MODEL-VERSION="2.2.0" xmlns:xsi="...">
      <VEHICLE-INFO-SPEC ID="...">
        <SHORT-NAME>...</SHORT-NAME>
        <LONG-NAME>...</LONG-NAME>
        <ADMIN-DATA>...</ADMIN-DATA>
        <COMPANY-DATAS>...</COMPANY-DATAS>
        <INFO-COMPONENTS>...</INFO-COMPONENTS>
        <VEHICLE-INFORMATIONS>
          <VEHICLE-INFORMATION ID="...">
            <SHORT-NAME>...</SHORT-NAME>
            <INFO-COMPONENT-REFS>...</INFO-COMPONENT-REFS>
            <VEHICLE-CONNECTORS>...</VEHICLE-CONNECTORS>
            <LOGICAL-LINKS>...</LOGICAL-LINKS>
            <PHYSICAL-VEHICLE-LINKS>...</PHYSICAL-VEHICLE-LINKS>
          </VEHICLE-INFORMATION>
        </VEHICLE-INFORMATIONS>
        <OEM-VERSIONS>...</OEM-VERSIONS>
        <SDGS>...</SDGS>
      </VEHICLE-INFO-SPEC>
    </ODX>
"""

from __future__ import annotations

from pathlib import Path

from lxml import etree

from udsxml2tex.odx.models_odx import (
    AdminData,
    InfoComponent,
    LogicalLink,
    OdxCategory,
    OdxDocument,
    OemVersion,
    PhysicalVehicleLink,
    Vehicle,
    VehicleConnector,
    VehicleInformation,
    VehicleInfoSpec,
)
from udsxml2tex.odx.serializers._shared import (
    XSI_TYPE_ATTR,
    add_admin_data,
    add_company_datas,
    add_description,
    add_long_name,
    add_ref_child,
    add_sdgs,
    add_text_child,
    make_root,
    serialize_element,
)

# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def serialize_odx_v(doc: OdxDocument) -> bytes:
    """Serialize ``doc`` (``category == VEHICLE_INFO``) to UTF-8 XML bytes.

    :raises ValueError: when ``doc.category`` is not ``VEHICLE_INFO`` or
        ``doc.vehicle_info_spec`` is ``None``.
    """
    if doc.category != OdxCategory.VEHICLE_INFO:
        raise ValueError(
            f"serialize_odx_v expects OdxCategory.VEHICLE_INFO, got {doc.category!r}"
        )
    if doc.vehicle_info_spec is None:
        raise ValueError(
            "serialize_odx_v requires doc.vehicle_info_spec to be set"
        )
    root = make_root()
    _add_vehicle_info_spec(root, doc.vehicle_info_spec, doc.admin_data)
    return serialize_element(root)


def write_odx_v(doc: OdxDocument, out_path: Path) -> Path:
    """Serialize ``doc`` and write it to ``out_path``; return the path."""
    payload = serialize_odx_v(doc)
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(payload)
    return out_path


# ---------------------------------------------------------------------------
# VEHICLE-INFO-SPEC
# ---------------------------------------------------------------------------


def _add_vehicle_info_spec(
    parent: etree._Element,
    spec: VehicleInfoSpec,
    admin_data: AdminData | None,
) -> None:
    """Append ``<VEHICLE-INFO-SPEC>`` to ``parent``.

    ``admin_data`` comes from ``OdxDocument.admin_data`` (the spec itself has
    no dedicated ADMIN-DATA field in the current IR). Company data attached
    to that admin record is also surfaced as a top-level ``<COMPANY-DATAS>``
    block, mirroring the canonical ODX-V skeleton.
    """
    elem = etree.SubElement(parent, "VEHICLE-INFO-SPEC")
    if spec.oid:
        elem.set("ID", spec.oid)
    add_text_child(elem, "SHORT-NAME", spec.short_name)
    add_long_name(elem, spec.long_name)
    add_description(elem, spec.description)
    add_admin_data(elem, admin_data)
    if admin_data is not None and admin_data.company_doc_infos:
        add_company_datas(elem, admin_data.company_doc_infos)
    info_components = list(spec.info_components) + _synthesise_info_components(spec)
    _add_info_components(elem, info_components)
    _add_vehicle_informations(elem, spec, info_components)
    _add_oem_versions(elem, spec.oem_versions)
    # SDGS sit at the tail of every ODX root in the reference skeleton; the
    # current IR does not expose a dedicated SDG list on VehicleInfoSpec,
    # so this remains a documented extension point.
    add_sdgs(elem, [])


# ---------------------------------------------------------------------------
# INFO-COMPONENTS
# ---------------------------------------------------------------------------


# Maps an InfoComponent.category (or short_name) to the ODX 2.2.0 xsi:type.
_INFO_COMPONENT_TYPES: dict[str, str] = {
    "MANUFACTURER": "MANUFACTURER",
    "MODEL-YEAR": "MODEL-YEAR",
    "MODELYEAR": "MODEL-YEAR",
    "MODEL_YEAR": "MODEL-YEAR",
    "MODEL": "MODEL",
    "VIN": "VEHICLE-MODEL",
    "VEHICLE-MODEL": "VEHICLE-MODEL",
    "OEM-VARIANT": "OEM-VARIANT",
    "COUNTRY": "COUNTRY",
    "EU-VEHICLE-CATEGORY": "EU-VEHICLE-CATEGORY",
}


def _info_component_xsi_type(ic: InfoComponent) -> str:
    """Derive the ``xsi:type`` for one ``InfoComponent``.

    Falls back to ``"INFO-COMPONENT"`` when no recognised category is given.
    """
    key = (ic.category or ic.short_name or "").upper().replace(" ", "-")
    return _INFO_COMPONENT_TYPES.get(key, "INFO-COMPONENT")


def _synthesise_info_components(spec: VehicleInfoSpec) -> list[InfoComponent]:
    """Auto-generate INFO-COMPONENTs from each Vehicle's flat fields.

    The mapper does not always populate ``spec.info_components``: vehicle
    metadata such as VIN / model_year / model / manufacturer lives directly
    on the ``Vehicle`` dataclass. We surface those here so the ODX-V output
    always contains the canonical entries.
    """
    out: list[InfoComponent] = []
    seen_categories: set[str] = {
        (ic.category or ic.short_name or "").upper()
        for ic in spec.info_components
    }
    for veh in spec.vehicles:
        for category, value in (
            ("MANUFACTURER", veh.manufacturer),
            ("MODEL-YEAR", str(veh.model_year) if veh.model_year is not None else None),
            ("MODEL", veh.model),
            ("VIN", veh.vin),
        ):
            if not value:
                continue
            if category in seen_categories:
                continue
            short_name = category.replace("-", "_")
            ic = InfoComponent(
                oid=f"udsxml2tex.odx.v.ic.{short_name}",
                short_name=short_name,
                category=category,
                value=str(value),
            )
            out.append(ic)
            seen_categories.add(category)
    return out


def _add_info_components(
    parent: etree._Element, info_components: list[InfoComponent]
) -> None:
    """Emit ``<INFO-COMPONENTS>`` block (no-op when empty)."""
    if not info_components:
        return
    wrap = etree.SubElement(parent, "INFO-COMPONENTS")
    for ic in info_components:
        _add_info_component(wrap, ic)


def _add_info_component(parent: etree._Element, ic: InfoComponent) -> None:
    """Emit one ``<INFO-COMPONENT>`` element with ``xsi:type`` discriminator."""
    elem = etree.SubElement(parent, "INFO-COMPONENT")
    elem.set(XSI_TYPE_ATTR, _info_component_xsi_type(ic))
    if ic.oid:
        elem.set("ID", ic.oid)
    add_text_child(elem, "SHORT-NAME", ic.short_name)
    add_long_name(elem, ic.long_name)
    add_text_child(elem, "VALUE", ic.value)


# ---------------------------------------------------------------------------
# VEHICLE-INFORMATIONS / VEHICLE-INFORMATION
# ---------------------------------------------------------------------------


def _add_vehicle_informations(
    parent: etree._Element,
    spec: VehicleInfoSpec,
    info_components: list[InfoComponent],
) -> None:
    """Emit the ``<VEHICLE-INFORMATIONS>`` wrapper."""
    if not spec.vehicle_informations and not spec.vehicles:
        return
    wrap = etree.SubElement(parent, "VEHICLE-INFORMATIONS")
    # Pair Vehicle metadata with VehicleInformation entries when available.
    # We always emit at least one VEHICLE-INFORMATION when vehicles exist.
    vehicle_infos = list(spec.vehicle_informations)
    if not vehicle_infos and spec.vehicles:
        # Synthesise a placeholder when none was provided.
        veh = spec.vehicles[0]
        vehicle_infos = [
            VehicleInformation(
                oid=f"udsxml2tex.odx.v.vinfo.{veh.short_name or 'Default'}",
                short_name=veh.short_name or "DefaultVehicleInformation",
                long_name=veh.long_name,
            )
        ]
    for idx, vi in enumerate(vehicle_infos):
        veh = spec.vehicles[idx] if idx < len(spec.vehicles) else None
        _add_vehicle_information(wrap, vi, veh, spec, info_components)


def _add_vehicle_information(
    parent: etree._Element,
    vi: VehicleInformation,
    veh: Vehicle | None,
    spec: VehicleInfoSpec,
    info_components: list[InfoComponent],
) -> None:
    """Emit one ``<VEHICLE-INFORMATION>`` element."""
    elem = etree.SubElement(parent, "VEHICLE-INFORMATION")
    if vi.oid:
        elem.set("ID", vi.oid)
    add_text_child(elem, "SHORT-NAME", vi.short_name)
    add_long_name(elem, vi.long_name)
    if info_components:
        wrap = etree.SubElement(elem, "INFO-COMPONENT-REFS")
        for ic in info_components:
            ref = etree.SubElement(wrap, "INFO-COMPONENT-REF")
            ref.set("ID-REF", ic.oid)
    # Vehicle-level connectors / physical links are emitted from the parent
    # spec because they are global to a VEHICLE-INFORMATION in ODX 2.2.0.
    connectors: list[VehicleConnector] = []
    if veh is not None:
        connectors = list(veh.vehicle_connectors)
    _add_vehicle_connectors(elem, connectors)
    _add_logical_links(elem, vi.logical_links)
    _add_physical_vehicle_links(elem, spec.physical_vehicle_links)


# ---------------------------------------------------------------------------
# VEHICLE-CONNECTORS
# ---------------------------------------------------------------------------


def _add_vehicle_connectors(
    parent: etree._Element, connectors: list[VehicleConnector]
) -> None:
    """Emit ``<VEHICLE-CONNECTORS>`` block."""
    if not connectors:
        return
    wrap = etree.SubElement(parent, "VEHICLE-CONNECTORS")
    for c in connectors:
        _add_vehicle_connector(wrap, c)


def _add_vehicle_connector(parent: etree._Element, c: VehicleConnector) -> None:
    """Emit one ``<VEHICLE-CONNECTOR>`` element with its pin infos."""
    elem = etree.SubElement(parent, "VEHICLE-CONNECTOR")
    if c.oid:
        elem.set("ID", c.oid)
    add_text_child(elem, "SHORT-NAME", c.short_name)
    add_long_name(elem, c.long_name)
    if c.connector_type:
        add_text_child(elem, "VEHICLE-CONNECTOR-TYPE", c.connector_type)
    if c.pins:
        pins_wrap = etree.SubElement(elem, "VEHICLE-CONNECTOR-PIN-INFOS")
        for pin_number, signal in c.pins:
            info = etree.SubElement(pins_wrap, "VEHICLE-CONNECTOR-PIN-INFO")
            add_text_child(info, "PIN-NUMBER", pin_number)
            if signal:
                add_text_child(info, "SIGNAL", signal)


# ---------------------------------------------------------------------------
# LOGICAL-LINKS
# ---------------------------------------------------------------------------


# Allowed ODX 2.2.0 LOGICAL-LINK xsi:type values.
_VALID_LOGICAL_LINK_TYPES: set[str] = {
    "MEMBER-LOGICAL-LINK",
    "PROTOCOL-LOGICAL-LINK",
}


def _logical_link_xsi_type(link: LogicalLink) -> str:
    """Return the ODX-valid ``xsi:type`` for ``link.link_type``."""
    if link.link_type in _VALID_LOGICAL_LINK_TYPES:
        return link.link_type
    return "MEMBER-LOGICAL-LINK"


def _add_logical_links(parent: etree._Element, links: list[LogicalLink]) -> None:
    """Emit ``<LOGICAL-LINKS>`` block."""
    if not links:
        return
    wrap = etree.SubElement(parent, "LOGICAL-LINKS")
    for link in links:
        _add_logical_link(wrap, link)


def _add_logical_link(parent: etree._Element, link: LogicalLink) -> None:
    """Emit one ``<LOGICAL-LINK>`` element with ``xsi:type``."""
    elem = etree.SubElement(parent, "LOGICAL-LINK")
    elem.set(XSI_TYPE_ATTR, _logical_link_xsi_type(link))
    if link.oid:
        elem.set("ID", link.oid)
    add_text_child(elem, "SHORT-NAME", link.short_name)
    add_long_name(elem, link.long_name)
    add_ref_child(elem, "PHYSICAL-VEHICLE-LINK-REF", link.physical_vehicle_link_ref)
    add_ref_child(elem, "BASE-VARIANT-REF", link.base_variant_ref)
    add_ref_child(elem, "PROTOCOL-REF", link.protocol_ref)
    if link.comparam_ref_value_pairs:
        wrap = etree.SubElement(elem, "COMPARAM-REF-VALUE-PAIRS")
        for pair in link.comparam_ref_value_pairs:
            pair_elem = etree.SubElement(wrap, "COMPARAM-REF-VALUE-PAIR")
            add_ref_child(pair_elem, "COMPARAM-REF", pair.comparam_ref)
            value_elem = etree.SubElement(pair_elem, "VALUE")
            value_elem.text = pair.value


# ---------------------------------------------------------------------------
# PHYSICAL-VEHICLE-LINKS
# ---------------------------------------------------------------------------


def _normalise_link_type(link_type: str) -> str:
    """Translate dash-separated link types to the ODX underscore form."""
    return (link_type or "").replace("-", "_")


def _add_physical_vehicle_links(
    parent: etree._Element, links: list[PhysicalVehicleLink]
) -> None:
    """Emit ``<PHYSICAL-VEHICLE-LINKS>`` block."""
    if not links:
        return
    wrap = etree.SubElement(parent, "PHYSICAL-VEHICLE-LINKS")
    for pl in links:
        _add_physical_vehicle_link(wrap, pl)


def _add_physical_vehicle_link(
    parent: etree._Element, pl: PhysicalVehicleLink
) -> None:
    """Emit one ``<PHYSICAL-VEHICLE-LINK>`` element."""
    elem = etree.SubElement(parent, "PHYSICAL-VEHICLE-LINK")
    if pl.oid:
        elem.set("ID", pl.oid)
    if pl.link_type:
        elem.set("TYPE", _normalise_link_type(pl.link_type))
    add_text_child(elem, "SHORT-NAME", pl.short_name)
    add_long_name(elem, pl.long_name)
    add_ref_child(elem, "VEHICLE-CONNECTOR-REF", pl.vehicle_connector_ref)


# ---------------------------------------------------------------------------
# OEM-VERSIONS
# ---------------------------------------------------------------------------


def _add_oem_versions(parent: etree._Element, versions: list[OemVersion]) -> None:
    """Emit ``<OEM-VERSIONS>`` block."""
    if not versions:
        return
    wrap = etree.SubElement(parent, "OEM-VERSIONS")
    for ov in versions:
        _add_oem_version(wrap, ov)


def _add_oem_version(parent: etree._Element, ov: OemVersion) -> None:
    """Emit one ``<OEM-VERSION>`` element."""
    elem = etree.SubElement(parent, "OEM-VERSION")
    if ov.oid:
        elem.set("ID", ov.oid)
    add_text_child(elem, "SHORT-NAME", ov.short_name)
    add_text_child(elem, "LABEL", ov.label)
    add_text_child(elem, "VALUE", ov.value)


__all__ = [
    "serialize_odx_v",
    "write_odx_v",
]
