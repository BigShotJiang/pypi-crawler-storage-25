"""ODX-CS (Comparam Subset) XML serializer.

This module turns an :class:`OdxDocument` whose
``category == OdxCategory.COMPARAM_SUBSET`` into the corresponding ODX
2.2.0 ``.odx-cs`` XML document. The shape follows ISO 22901-1 § 7
(``COMPARAM-SUBSET`` content group) and matches the skeleton documented
inside the multi-agent task spec.

The serializer is non-destructive: it never mutates the IR. Helpers shared
with the ODX-C writer live in :mod:`udsxml2tex.odx.serializers._shared`.
"""

from __future__ import annotations

from pathlib import Path

from lxml import etree

from udsxml2tex.odx.models_odx import (
    Comparam,
    ComparamSubset,
    ComplexComparam,
    OdxCategory,
    OdxDocument,
)
from udsxml2tex.odx.serializers._shared import (
    add_admin_data,
    add_description,
    add_dop,
    add_long_name,
    add_text_child,
    add_unit_spec,
    make_root,
    serialize_element,
    set_ref_attrs,
)


def _add_comparam(parent: etree._Element, cp: Comparam) -> None:
    """Emit one ``<COMPARAM>`` child with ID/PARAM-CLASS/CPTYPE attributes."""
    elem = etree.SubElement(parent, "COMPARAM")
    if cp.oid:
        elem.set("ID", cp.oid)
    if cp.param_class:
        elem.set("PARAM-CLASS", cp.param_class)
    if cp.cptype:
        elem.set("CPTYPE", cp.cptype)
    add_text_child(elem, "SHORT-NAME", cp.short_name)
    add_long_name(elem, cp.long_name)
    add_description(elem, cp.description)
    add_text_child(elem, "PHYSICAL-DEFAULT-VALUE", cp.physical_default_value)
    if cp.dop_ref is not None:
        ref = etree.SubElement(elem, "DATA-OBJECT-PROP-REF")
        set_ref_attrs(ref, cp.dop_ref)


def _add_complex_comparam(
    parent: etree._Element,
    ccp: ComplexComparam,
) -> None:
    """Emit one ``<COMPLEX-COMPARAM>`` child with its nested ``<COMPARAM>`` list."""
    elem = etree.SubElement(parent, "COMPLEX-COMPARAM")
    if ccp.oid:
        elem.set("ID", ccp.oid)
    if ccp.cptype:
        elem.set("CPTYPE", ccp.cptype)
    add_text_child(elem, "SHORT-NAME", ccp.short_name)
    add_long_name(elem, ccp.long_name)
    if ccp.sub_comparams:
        wrap = etree.SubElement(elem, "COMPARAMS")
        for sub in ccp.sub_comparams:
            _add_comparam(wrap, sub)


def _build_comparam_subset_element(
    subset: ComparamSubset,
    admin_data: object | None = None,
) -> etree._Element:
    """Materialise the ``<COMPARAM-SUBSET>`` element under a fresh ``<ODX>`` root.

    ``admin_data`` is the optional :class:`AdminData` carried at the
    :class:`OdxDocument` level. It is rendered just after SHORT-NAME /
    LONG-NAME / DESC so the serialised document matches the canonical ODX
    2.2.0 ordering.
    """
    root = make_root()
    elem = etree.SubElement(root, "COMPARAM-SUBSET")
    if subset.oid:
        elem.set("ID", subset.oid)
    if subset.category:
        elem.set("CATEGORY", subset.category)
    add_text_child(elem, "SHORT-NAME", subset.short_name)
    add_long_name(elem, subset.long_name)
    add_description(elem, subset.description)
    add_admin_data(elem, admin_data)  # type: ignore[arg-type]
    if subset.comparams:
        wrap = etree.SubElement(elem, "COMPARAMS")
        for cp in subset.comparams:
            _add_comparam(wrap, cp)
    if subset.complex_comparams:
        wrap = etree.SubElement(elem, "COMPLEX-COMPARAMS")
        for ccp in subset.complex_comparams:
            _add_complex_comparam(wrap, ccp)
    if subset.data_object_props:
        wrap = etree.SubElement(elem, "DATA-OBJECT-PROPS")
        for dop in subset.data_object_props:
            add_dop(wrap, dop)
    add_unit_spec(elem, subset.unit_spec)
    return root


def serialize_odx_cs(doc: OdxDocument) -> bytes:
    """Serialize an ``OdxDocument(category=COMPARAM_SUBSET)`` to UTF-8 XML bytes.

    Raises
    ------
    ValueError
        If ``doc.category`` is not :attr:`OdxCategory.COMPARAM_SUBSET`
        or if ``doc.content`` is ``None``.
    """
    if doc.category != OdxCategory.COMPARAM_SUBSET:
        raise ValueError(
            f"serialize_odx_cs requires COMPARAM_SUBSET, got {doc.category.value}"
        )
    subset = doc.comparam_subset
    if subset is None:
        raise ValueError(
            "OdxDocument.comparam_subset is None; nothing to serialize"
        )
    root = _build_comparam_subset_element(subset, admin_data=doc.admin_data)
    return serialize_element(root)


def write_odx_cs(doc: OdxDocument, out_path: Path) -> Path:
    """Serialize ``doc`` and write the bytes to ``out_path``.

    The parent directory is created when missing. Returns the resolved
    output path for convenience.
    """
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(serialize_odx_cs(doc))
    return out_path
