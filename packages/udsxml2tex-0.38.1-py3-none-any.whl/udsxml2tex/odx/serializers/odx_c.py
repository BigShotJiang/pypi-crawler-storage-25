"""ODX-C (Comparam Spec) XML serializer.

Materialises an :class:`OdxDocument` whose
``category == OdxCategory.COMPARAM_SPEC`` as an ODX 2.2.0 ``.odx-c`` XML
file. A Comparam Spec is the protocol-stack-level document that ties
together Comparam Subsets, individual Comparams and Protocol Stacks
(``PDU-PROTOCOL-TYPE`` / ``PHYSICAL-LINK-TYPE``).

Helpers shared with :mod:`udsxml2tex.odx.serializers.odx_cs` live in
:mod:`udsxml2tex.odx.serializers._shared`.
"""

from __future__ import annotations

from pathlib import Path

from lxml import etree

from udsxml2tex.odx.models_odx import (
    ComparamRefValuePair,
    ComparamSpec,
    OdxCategory,
    OdxDocument,
    ProtocolStack,
)
from udsxml2tex.odx.serializers._shared import (
    add_admin_data,
    add_description,
    add_long_name,
    add_text_child,
    make_root,
    serialize_element,
    set_ref_attrs,
)
from udsxml2tex.odx.serializers.odx_cs import _add_comparam


def _add_comparam_subset_refs(
    parent: etree._Element,
    spec: ComparamSpec,
) -> None:
    """Emit ``<COMPARAM-SUBSET-REFS>`` block referencing each declared subset."""
    if not spec.comparam_subsets:
        return
    wrap = etree.SubElement(parent, "COMPARAM-SUBSET-REFS")
    for subset in spec.comparam_subsets:
        ref = etree.SubElement(wrap, "COMPARAM-SUBSET-REF")
        ref.set("ID-REF", subset.oid)
        if subset.category:
            ref.set("DOCREF", subset.category)
        ref.set("DOCTYPE", "COMPARAM-SUBSET")


def _add_comparam_ref_value_pair(
    parent: etree._Element,
    pair: ComparamRefValuePair,
) -> None:
    """Emit one ``<COMPARAM-REF-VALUE-PAIR>`` with ref + override value."""
    elem = etree.SubElement(parent, "COMPARAM-REF-VALUE-PAIR")
    ref = etree.SubElement(elem, "COMPARAM-REF")
    set_ref_attrs(ref, pair.comparam_ref)
    if pair.value is not None and pair.value != "":
        add_text_child(elem, "PHYSICAL-DEFAULT-VALUE", pair.value)


def _add_protocol_stack(parent: etree._Element, stack: ProtocolStack) -> None:
    """Emit one ``<PROTOCOL-STACK>`` block."""
    elem = etree.SubElement(parent, "PROTOCOL-STACK")
    if stack.oid:
        elem.set("ID", stack.oid)
    if stack.pdu_protocol_type:
        elem.set("PDU-PROTOCOL-TYPE", stack.pdu_protocol_type)
    if stack.physical_link_type:
        elem.set("PHYSICAL-LINK-TYPE", stack.physical_link_type)
    add_text_child(elem, "SHORT-NAME", stack.short_name)
    add_long_name(elem, stack.long_name)


def _build_comparam_spec_element(
    spec: ComparamSpec,
    admin_data: object | None,
) -> etree._Element:
    """Materialise the ``<COMPARAM-SPEC>`` element under a fresh ``<ODX>`` root.

    ``admin_data`` is :class:`AdminData` or ``None``. It is rendered via the
    shared helper which already handles the empty/no-op cases.
    """
    root = make_root()
    elem = etree.SubElement(root, "COMPARAM-SPEC")
    if spec.oid:
        elem.set("ID", spec.oid)
    add_text_child(elem, "SHORT-NAME", spec.short_name)
    add_long_name(elem, spec.long_name)
    add_description(elem, spec.description)
    add_admin_data(elem, admin_data)  # type: ignore[arg-type]
    if spec.comparams:
        wrap = etree.SubElement(elem, "COMPARAMS")
        for cp in spec.comparams:
            _add_comparam(wrap, cp)
    _add_comparam_subset_refs(elem, spec)
    if spec.protocol_stacks:
        wrap = etree.SubElement(elem, "PROTOCOL-STACKS")
        for stack in spec.protocol_stacks:
            _add_protocol_stack(wrap, stack)
    return root


def _attach_protocol_stack_value_pairs(
    root: etree._Element,
    pairs_by_stack_oid: dict[str, list[ComparamRefValuePair]],
) -> None:
    """Attach ``<COMPARAM-REF-VALUE-PAIRS>`` to each emitted ``<PROTOCOL-STACK>``.

    This is invoked separately so that the public API can accept a parallel
    mapping from stack OID to override pairs without expanding the
    :class:`ProtocolStack` IR dataclass.
    """
    if not pairs_by_stack_oid:
        return
    stacks_elem = root.find(".//PROTOCOL-STACKS")
    if stacks_elem is None:
        return
    for stack_elem in stacks_elem.findall("PROTOCOL-STACK"):
        stack_oid = stack_elem.get("ID", "")
        pairs = pairs_by_stack_oid.get(stack_oid)
        if not pairs:
            continue
        wrap = etree.SubElement(stack_elem, "COMPARAM-REF-VALUE-PAIRS")
        for pair in pairs:
            _add_comparam_ref_value_pair(wrap, pair)


def serialize_odx_c(
    doc: OdxDocument,
    *,
    protocol_stack_overrides: dict[str, list[ComparamRefValuePair]] | None = None,
) -> bytes:
    """Serialize an ``OdxDocument(category=COMPARAM_SPEC)`` to UTF-8 XML bytes.

    Parameters
    ----------
    doc
        The ODX document to serialize.
    protocol_stack_overrides
        Optional mapping from ``ProtocolStack.oid`` to a list of
        :class:`ComparamRefValuePair` overrides. Each list is rendered as a
        ``<COMPARAM-REF-VALUE-PAIRS>`` block inside its protocol stack. The
        mapping is keyed by OID because the :class:`ProtocolStack` IR does
        not carry its own list of overrides.

    Raises
    ------
    ValueError
        If ``doc.category`` is not :attr:`OdxCategory.COMPARAM_SPEC` or
        if ``doc.comparam_spec`` is ``None``.
    """
    if doc.category != OdxCategory.COMPARAM_SPEC:
        raise ValueError(
            f"serialize_odx_c requires COMPARAM_SPEC, got {doc.category.value}"
        )
    spec = doc.comparam_spec
    if spec is None:
        raise ValueError(
            "OdxDocument.comparam_spec is None; nothing to serialize"
        )
    root = _build_comparam_spec_element(spec, doc.admin_data)
    if protocol_stack_overrides:
        _attach_protocol_stack_value_pairs(root, protocol_stack_overrides)
    return serialize_element(root)


def write_odx_c(
    doc: OdxDocument,
    out_path: Path,
    *,
    protocol_stack_overrides: dict[str, list[ComparamRefValuePair]] | None = None,
) -> Path:
    """Serialize ``doc`` and write the bytes to ``out_path``.

    The parent directory is created when missing. Returns the resolved
    output path for convenience.
    """
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(
        serialize_odx_c(doc, protocol_stack_overrides=protocol_stack_overrides)
    )
    return out_path
