"""Serializer for ODX-E (ECU-SHARED-DATA) documents.

ECU-SHARED-DATA carries DOPs, DTC-DOPs, structures, diag-services and the
associated requests/responses that are inherited by several base- or
ECU-variants. The XML body therefore shares ~80% of its grammar with a
BASE-VARIANT in ODX-D; the helpers in :mod:`udsxml2tex.odx.serializers._shared`
take care of the common idioms.

Public API
----------

* :func:`serialize_odx_e` — :class:`OdxDocument` → ``bytes``.
* :func:`write_odx_e`     — :class:`OdxDocument` → on-disk ``.odx-e`` file.

The output mirrors the ``odx-e`` reference layout::

    <ODX MODEL-VERSION="2.2.0" xmlns:xsi="...">
      <ECU-SHARED-DATA ID="...">
        <SHORT-NAME>...</SHORT-NAME>
        <LONG-NAME>...</LONG-NAME>
        <ADMIN-DATA>...</ADMIN-DATA>
        <COMPANY-DATAS>...</COMPANY-DATAS>
        <FUNCT-CLASSES>...</FUNCT-CLASSES>
        <DIAG-DATA-DICTIONARY-SPEC>...</DIAG-DATA-DICTIONARY-SPEC>
        <DIAG-COMMS>
          <DIAG-SERVICE ID="...">...</DIAG-SERVICE>
        </DIAG-COMMS>
        <REQUESTS>...</REQUESTS>
        <POS-RESPONSES>...</POS-RESPONSES>
        <NEG-RESPONSES>...</NEG-RESPONSES>
        <IMPORT-REFS>...</IMPORT-REFS>
        <SDGS>...</SDGS>
      </ECU-SHARED-DATA>
    </ODX>
"""

from __future__ import annotations

from pathlib import Path

from lxml import etree

from udsxml2tex.odx.models_odx import (
    EcuSharedData,
    FunctionalClass,
    OdxCategory,
    OdxDocument,
    OdxRef,
    Response,
)
from udsxml2tex.odx.serializers._shared import (
    add_admin_data,
    add_audience,
    add_company_datas,
    add_description,
    add_diag_data_dictionary_spec,
    add_diag_service,
    add_long_name,
    add_ref_child,
    add_request,
    add_response,
    add_sdgs,
    add_text_child,
    make_root,
    serialize_element,
)

# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def serialize_odx_e(doc: OdxDocument) -> bytes:
    """Serialize ``doc`` (``category == ECU_SHARED_DATA``) to UTF-8 XML bytes.

    :raises ValueError: when ``doc.category`` is not ``ECU_SHARED_DATA`` or
        the diag-layer container is missing an ``EcuSharedData`` payload.
    """
    if doc.category != OdxCategory.ECU_SHARED_DATA:
        raise ValueError(
            f"serialize_odx_e expects OdxCategory.ECU_SHARED_DATA, got {doc.category!r}"
        )
    shared = _resolve_ecu_shared_data(doc)
    if shared is None:
        raise ValueError(
            "serialize_odx_e requires doc to carry an EcuSharedData payload"
        )
    root = make_root()
    _add_ecu_shared_data(root, shared)
    return serialize_element(root)


def write_odx_e(doc: OdxDocument, out_path: Path) -> Path:
    """Serialize ``doc`` and write it to ``out_path``; return the path."""
    payload = serialize_odx_e(doc)
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(payload)
    return out_path


# ---------------------------------------------------------------------------
# Document → EcuSharedData resolver
# ---------------------------------------------------------------------------


def _resolve_ecu_shared_data(doc: OdxDocument) -> EcuSharedData | None:
    """Find the ``EcuSharedData`` payload inside ``doc``.

    ECU-SHARED-DATA may live either directly (when an exporter sets
    ``doc.vehicle_info_spec`` to ``None`` and stores the EcuSharedData as
    the first entry of a transient holder) or wrapped inside a
    ``DiagLayerContainer.ecu_shared_datas`` list. We accept both and return
    the first usable payload.
    """
    # Convention: ECU-SHARED-DATA wrapped in DiagLayerContainer
    if doc.diag_layer_container and doc.diag_layer_container.ecu_shared_datas:
        return doc.diag_layer_container.ecu_shared_datas[0]
    # Fallback: the mapper may store the EcuSharedData directly on the
    # untyped ``content`` slot used for ODX-* variants without a dedicated
    # field. We probe each known carrier in order.
    content = doc.content
    if isinstance(content, EcuSharedData):
        return content
    return None


# ---------------------------------------------------------------------------
# ECU-SHARED-DATA root
# ---------------------------------------------------------------------------


def _add_ecu_shared_data(
    parent: etree._Element, shared: EcuSharedData
) -> None:
    """Append ``<ECU-SHARED-DATA>`` to ``parent``."""
    elem = etree.SubElement(parent, "ECU-SHARED-DATA")
    if shared.oid:
        elem.set("ID", shared.oid)
    add_text_child(elem, "SHORT-NAME", shared.short_name)
    add_long_name(elem, shared.long_name)
    add_description(elem, shared.description)
    add_admin_data(elem, shared.admin_data)
    add_company_datas(elem, shared.company_datas)
    _add_functional_classes(elem, shared.functional_classes)
    add_audience(elem, shared.audience)
    add_diag_data_dictionary_spec(elem, shared.diag_data_dictionary_spec)
    _add_diag_comms(elem, shared.diag_comms)
    _add_requests(elem, shared.requests)
    _add_pos_responses(elem, shared.pos_responses)
    _add_neg_responses(elem, shared.neg_responses)
    _add_global_neg_responses(elem, shared.global_neg_responses)
    _add_import_refs(elem, shared.import_refs)
    add_sdgs(elem, shared.sdgs)


# ---------------------------------------------------------------------------
# FUNCT-CLASSES
# ---------------------------------------------------------------------------


def _add_functional_classes(
    parent: etree._Element, fc_list: list[FunctionalClass]
) -> None:
    """Emit ``<FUNCT-CLASSES>`` block."""
    if not fc_list:
        return
    wrap = etree.SubElement(parent, "FUNCT-CLASSES")
    for fc in fc_list:
        _add_functional_class(wrap, fc)


def _add_functional_class(parent: etree._Element, fc: FunctionalClass) -> None:
    """Emit one ``<FUNCT-CLASS>`` element."""
    elem = etree.SubElement(parent, "FUNCT-CLASS")
    if fc.oid:
        elem.set("ID", fc.oid)
    add_text_child(elem, "SHORT-NAME", fc.short_name)
    add_long_name(elem, fc.long_name)


# ---------------------------------------------------------------------------
# DIAG-COMMS / REQUESTS / RESPONSES
# ---------------------------------------------------------------------------


def _add_diag_comms(parent: etree._Element, services: list) -> None:
    """Emit ``<DIAG-COMMS>`` block."""
    if not services:
        return
    wrap = etree.SubElement(parent, "DIAG-COMMS")
    for svc in services:
        add_diag_service(wrap, svc)


def _add_requests(parent: etree._Element, requests: list) -> None:
    """Emit ``<REQUESTS>`` block."""
    if not requests:
        return
    wrap = etree.SubElement(parent, "REQUESTS")
    for r in requests:
        add_request(wrap, r)


def _add_pos_responses(parent: etree._Element, responses: list[Response]) -> None:
    """Emit ``<POS-RESPONSES>`` block."""
    if not responses:
        return
    wrap = etree.SubElement(parent, "POS-RESPONSES")
    for r in responses:
        # Force POS-RESPONSE tag here regardless of stored response_type so
        # that callers can pass a mixed list without worrying about state.
        previous = r.response_type
        r.response_type = "POS-RESPONSE"
        try:
            add_response(wrap, r)
        finally:
            r.response_type = previous


def _add_neg_responses(parent: etree._Element, responses: list[Response]) -> None:
    """Emit ``<NEG-RESPONSES>`` block."""
    if not responses:
        return
    wrap = etree.SubElement(parent, "NEG-RESPONSES")
    for r in responses:
        previous = r.response_type
        r.response_type = "NEG-RESPONSE"
        try:
            add_response(wrap, r)
        finally:
            r.response_type = previous


def _add_global_neg_responses(
    parent: etree._Element, responses: list[Response]
) -> None:
    """Emit ``<GLOBAL-NEG-RESPONSES>`` block."""
    if not responses:
        return
    wrap = etree.SubElement(parent, "GLOBAL-NEG-RESPONSES")
    for r in responses:
        previous = r.response_type
        r.response_type = "GLOBAL-NEG-RESPONSE"
        try:
            add_response(wrap, r)
        finally:
            r.response_type = previous


# ---------------------------------------------------------------------------
# IMPORT-REFS
# ---------------------------------------------------------------------------


def _add_import_refs(parent: etree._Element, refs: list[OdxRef]) -> None:
    """Emit ``<IMPORT-REFS>`` block."""
    if not refs:
        return
    wrap = etree.SubElement(parent, "IMPORT-REFS")
    for ref in refs:
        add_ref_child(wrap, "IMPORT-REF", ref)


__all__ = [
    "serialize_odx_e",
    "write_odx_e",
]
