"""Shared XML serialization helpers for the ODX 2.2.0 writers.

This module is consumed by sibling serializer modules (``odx_c``,
``odx_cs`` and, optionally, ODX-V/E/F/FD/M and PDX writers). It centralises
the XML idioms that recur across categories so that every writer emits a
consistent shape: same root attributes, same indentation, same ordering of
ADMIN-DATA / DATA-OBJECT-PROPS / UNIT-SPEC / SDGS blocks.

Public API
----------

The following functions are stable and may be imported by other ODX
serializers. All helpers are side-effect free apart from mutating their
``parent`` argument by appending children.

* ``make_root() -> etree.Element``
    Build ``<ODX MODEL-VERSION="2.2.0" xmlns:xsi="...">`` with the
    canonical attributes used by every category. Returns the root element.

* ``serialize_element(root: etree.Element) -> bytes``
    Run ``etree.tostring`` with the project's standard options
    (``xml_declaration=True``, ``encoding="UTF-8"``,
    ``pretty_print=True``, ``standalone=False``) and return UTF-8 bytes.

* ``add_text_child(parent, tag, value) -> etree.Element | None``
    Append ``<TAG>value</TAG>`` to ``parent`` when ``value`` is not None
    and not an empty string. Returns the new element (or ``None`` when
    nothing was appended). ``value`` may be any object convertible via
    ``str``; bools serialise as ``"true"``/``"false"``.

* ``add_long_name(parent, value)`` / ``add_description(parent, value)``
    Convenience wrappers emitting ``<LONG-NAME>`` and ``<DESC>``
    respectively. ``<DESC>`` wraps the raw text in a single ``<p>`` element
    so consumers that expect XHTML descriptions still parse correctly.

* ``add_admin_data(parent, admin_data)``
    Append ``<ADMIN-DATA>`` with the language tag, ``<COMPANY-DOC-INFOS>``
    block and ``<DOC-REVISIONS>`` block. No-op when ``admin_data`` is
    ``None``.

* ``add_company_datas(parent, cd_list)``
    Append ``<COMPANY-DATAS>`` block containing one
    ``<COMPANY-DATA ID="...">`` per entry. No-op when the list is empty.

* ``add_sdgs(parent, sdg_list)``
    Append ``<SDGS>`` block of ``<SDG>`` entries. Skipped when empty.

* ``add_audience(parent, audience)``
    Append ``<AUDIENCE>`` with the five required boolean attributes.
    Emits inner ``<ENABLED-AUDIENCE-REFS>`` / ``<DISABLED-AUDIENCE-REFS>``
    only when the corresponding list is non-empty. No-op when ``audience``
    is ``None``.

* ``add_diag_coded_type(parent, dct)``
    Append ``<DIAG-CODED-TYPE>`` carrying the ODX 2.2.0 ``xsi:type``
    attribute and either a ``<BIT-LENGTH>`` or ``<MIN-LENGTH>/<MAX-LENGTH>``
    block depending on the coded sub-type.

* ``add_physical_type(parent, pt)``
    Append ``<PHYSICAL-TYPE>``. The ``BASE-DATA-TYPE`` attribute is
    mandatory; ``DISPLAY-RADIX`` and ``PRECISION`` are emitted only when
    present.

* ``add_compu_method(parent, cm)``
    Append ``<COMPU-METHOD>`` carrying ``<CATEGORY>`` and either an
    internal-to-phys scale list (``LINEAR``, ``SCALE-LINEAR``,
    ``TEXTTABLE``, ``TAB-INTP``, ``RAT-FUNC``, ``COMPUCODE``) or no scales
    when the category is ``IDENTICAL``.

* ``add_unit_spec(parent, unit_spec)``
    Append ``<UNIT-SPEC>`` with ``<UNITS>``, ``<UNIT-GROUPS>`` and
    ``<PHYSICAL-DIMENSIONS>`` sub-blocks. No-op when ``unit_spec`` is
    ``None`` or fully empty.

* ``add_dop(parent_props, dop)``
    Append a single ``<DATA-OBJECT-PROP>`` under a
    ``<DATA-OBJECT-PROPS>`` parent. Emits ID/SHORT-NAME/LONG-NAME/DESC
    followed by ``<COMPU-METHOD>``, ``<DIAG-CODED-TYPE>``,
    ``<PHYSICAL-TYPE>``, ``<INTERNAL-CONSTR>``, ``<UNIT-REF>``, ``<SDGS>``.

* ``set_ref_attrs(elem, ref)``
    Copy ``id_ref`` / ``docref`` / ``docref_type`` from an :class:`OdxRef`
    onto ``ID-REF`` / ``DOCREF`` / ``DOCTYPE`` attributes of ``elem``.

Additional helpers (ODX-D / ODX-E)
----------------------------------

These helpers extend the public API for diagnostic-data serializers and
are imported by Agent 2's ODX-D writer (and Agents 4-5 may also reuse them).

* ``add_ref_child(parent, tag, ref)`` — append ``<TAG ID-REF="..."/>`` when
  ``ref`` is not ``None``. Returns the new element (or ``None``).
* ``add_dtc(parent, dtc)`` — emit ``<DTC>`` under a ``<DTCS>`` parent.
* ``add_dtc_dop(parent, dop)`` — emit ``<DTC-DOP>`` under a ``<DTC-DOPS>``
  parent.
* ``add_param(parent, param)`` — emit ``<PARAM>`` carrying ``xsi:type``
  (the ``param_kind``) and BYTE-POSITION / DOP-REF / coded-value attributes.
* ``add_structure(parent, struct)`` — emit ``<STRUCTURE>`` with optional
  ``<BYTE-SIZE>`` and ``<PARAMS>``.
* ``add_request(parent, req)`` — emit ``<REQUEST>``.
* ``add_response(parent, resp)`` — emit one of
  ``<POS-RESPONSE>``/``<NEG-RESPONSE>``/``<GLOBAL-NEG-RESPONSE>`` using
  ``resp.response_type`` as the wrapping tag.
* ``add_diag_service(parent, svc)`` — emit ``<DIAG-SERVICE>`` with all
  attribute/element groups (SEMANTIC, ADDRESSING, audience, request-ref,
  response-refs, comparam-refs, SDGs).
* ``add_diag_data_dictionary_spec(parent, dds)`` — emit
  ``<DIAG-DATA-DICTIONARY-SPEC>`` with DTC-DOPS, DATA-OBJECT-PROPS,
  STRUCTURES and UNIT-SPEC sub-blocks. No-op when ``dds`` is ``None`` or
  fully empty.
"""

from __future__ import annotations

from typing import Any

from lxml import etree

from udsxml2tex.odx.models_odx import (
    AdminData,
    Audience,
    CompanyData,
    CompuMethod,
    CompuScale,
    DataObjectProp,
    DiagCodedType,
    DiagDataDictionarySpec,
    DiagService,
    Dtc,
    DtcDop,
    OdxRef,
    Param,
    PhysicalType,
    Request,
    Response,
    SpecialDataGroup,
    Structure,
    UnitSpec,
)

XSI_NS = "http://www.w3.org/2001/XMLSchema-instance"
XSI_TYPE_ATTR = f"{{{XSI_NS}}}type"


def make_root() -> etree._Element:
    """Create the canonical ``<ODX>`` root with namespace declarations."""
    return etree.Element(
        "ODX",
        attrib={"MODEL-VERSION": "2.2.0"},
        nsmap={"xsi": XSI_NS},
    )


def serialize_element(root: etree._Element) -> bytes:
    """Serialise ``root`` to UTF-8 bytes with the project's XML settings."""
    return etree.tostring(
        root,
        xml_declaration=True,
        encoding="UTF-8",
        pretty_print=True,
        standalone=False,
    )


def add_text_child(
    parent: etree._Element,
    tag: str,
    value: Any,
) -> etree._Element | None:
    """Append ``<TAG>value</TAG>`` when ``value`` is meaningful.

    ``None`` and empty strings produce no element. Booleans are emitted as
    lowercase ``"true"`` / ``"false"``. All other values are serialised
    through ``str``.
    """
    if value is None:
        return None
    text = ("true" if value else "false") if isinstance(value, bool) else str(value)
    if text == "":
        return None
    child = etree.SubElement(parent, tag)
    child.text = text
    return child


def add_long_name(parent: etree._Element, value: str | None) -> None:
    """Append ``<LONG-NAME>`` when ``value`` is non-empty."""
    add_text_child(parent, "LONG-NAME", value)


def add_description(parent: etree._Element, value: str | None) -> None:
    """Append ``<DESC><p>value</p></DESC>`` when ``value`` is non-empty."""
    if value is None or value == "":
        return
    desc = etree.SubElement(parent, "DESC")
    p = etree.SubElement(desc, "p")
    p.text = value


def set_ref_attrs(elem: etree._Element, ref: OdxRef) -> None:
    """Mirror ``OdxRef`` fields onto ``ID-REF``/``DOCREF``/``DOCTYPE`` attrs."""
    elem.set("ID-REF", ref.id_ref)
    if ref.docref:
        elem.set("DOCREF", ref.docref)
    if ref.docref_type:
        elem.set("DOCTYPE", ref.docref_type)


def add_admin_data(parent: etree._Element, admin_data: AdminData | None) -> None:
    """Emit ``<ADMIN-DATA>`` carrying language, company info and revisions."""
    if admin_data is None:
        return
    if (
        not admin_data.language
        and not admin_data.company_doc_infos
        and not admin_data.doc_revisions
    ):
        return
    ad = etree.SubElement(parent, "ADMIN-DATA")
    add_text_child(ad, "LANGUAGE", admin_data.language)
    if admin_data.company_doc_infos:
        cdis = etree.SubElement(ad, "COMPANY-DOC-INFOS")
        for cd in admin_data.company_doc_infos:
            cdi = etree.SubElement(cdis, "COMPANY-DOC-INFO")
            ref = etree.SubElement(cdi, "COMPANY-DATA-REF")
            ref.set("ID-REF", cd.oid)
    if admin_data.doc_revisions:
        revs = etree.SubElement(ad, "DOC-REVISIONS")
        for rev in admin_data.doc_revisions:
            r = etree.SubElement(revs, "DOC-REVISION")
            add_text_child(r, "TEAM-MEMBER-REF", rev.team_member_ref)
            add_text_child(r, "REVISION-LABEL", rev.revision_label)
            add_text_child(r, "STATE", rev.state)
            add_text_child(r, "DATE", rev.date)
            if rev.tool:
                modifications = etree.SubElement(r, "MODIFICATIONS")
                mod = etree.SubElement(modifications, "MODIFICATION")
                add_text_child(mod, "CHANGE", rev.tool)


def add_company_datas(
    parent: etree._Element,
    cd_list: list[CompanyData],
) -> None:
    """Emit ``<COMPANY-DATAS>`` block listing each ``CompanyData``."""
    if not cd_list:
        return
    cds = etree.SubElement(parent, "COMPANY-DATAS")
    for cd in cd_list:
        elem = etree.SubElement(cds, "COMPANY-DATA")
        if cd.oid:
            elem.set("ID", cd.oid)
        add_text_child(elem, "SHORT-NAME", cd.short_name)
        add_long_name(elem, cd.long_name)
        if cd.roles:
            roles = etree.SubElement(elem, "ROLES")
            for role in cd.roles:
                add_text_child(roles, "ROLE", role)


def add_sdgs(
    parent: etree._Element,
    sdg_list: list[SpecialDataGroup],
) -> None:
    """Emit ``<SDGS>`` block of ``<SDG>`` entries."""
    if not sdg_list:
        return
    sdgs = etree.SubElement(parent, "SDGS")
    for sdg in sdg_list:
        sdg_elem = etree.SubElement(sdgs, "SDG")
        if sdg.caption:
            caption = etree.SubElement(sdg_elem, "SDG-CAPTION")
            add_text_child(caption, "SHORT-NAME", sdg.caption)
        for si, val in sdg.sd_items:
            sd = etree.SubElement(sdg_elem, "SD")
            if si:
                sd.set("SI", si)
            sd.text = val


def add_audience(parent: etree._Element, audience: Audience | None) -> None:
    """Emit ``<AUDIENCE>`` with the standard five boolean attributes."""
    if audience is None:
        return
    a = etree.SubElement(
        parent,
        "AUDIENCE",
        attrib={
            "IS-SUPPLIER": "true" if audience.is_supplier else "false",
            "IS-DEVELOPMENT": "true" if audience.is_development else "false",
            "IS-MANUFACTURING": "true" if audience.is_manufacturing else "false",
            "IS-AFTERSALES": "true" if audience.is_aftersales else "false",
            "IS-AFTERMARKET": "true" if audience.is_aftermarket else "false",
        },
    )
    if audience.enabled_audiences:
        wrap = etree.SubElement(a, "ENABLED-AUDIENCE-REFS")
        for r in audience.enabled_audiences:
            ref = etree.SubElement(wrap, "ENABLED-AUDIENCE-REF")
            ref.set("ID-REF", r)
    if audience.disabled_audiences:
        wrap = etree.SubElement(a, "DISABLED-AUDIENCE-REFS")
        for r in audience.disabled_audiences:
            ref = etree.SubElement(wrap, "DISABLED-AUDIENCE-REF")
            ref.set("ID-REF", r)


def add_diag_coded_type(
    parent: etree._Element,
    dct: DiagCodedType,
) -> None:
    """Emit ``<DIAG-CODED-TYPE>`` with ``xsi:type`` and length attributes."""
    elem = etree.SubElement(parent, "DIAG-CODED-TYPE")
    elem.set("BASE-DATA-TYPE", dct.base_data_type)
    elem.set(XSI_TYPE_ATTR, dct.coded_type)
    elem.set(
        "IS-HIGHLOW-BYTE-ORDER",
        "true" if dct.is_highlow_byte_order else "false",
    )
    if dct.bit_length is not None:
        add_text_child(elem, "BIT-LENGTH", dct.bit_length)
    if dct.min_length is not None:
        add_text_child(elem, "MIN-LENGTH", dct.min_length)
    if dct.max_length is not None:
        add_text_child(elem, "MAX-LENGTH", dct.max_length)
    if dct.termination:
        add_text_child(elem, "TERMINATION", dct.termination)


def add_physical_type(parent: etree._Element, pt: PhysicalType) -> None:
    """Emit ``<PHYSICAL-TYPE>``."""
    elem = etree.SubElement(parent, "PHYSICAL-TYPE")
    elem.set("BASE-DATA-TYPE", pt.base_data_type)
    if pt.display_radix:
        elem.set("DISPLAY-RADIX", pt.display_radix)
    if pt.precision is not None:
        add_text_child(elem, "PRECISION", pt.precision)


def _add_compu_scale(parent: etree._Element, scale: CompuScale) -> None:
    """Emit one ``<COMPU-SCALE>`` inside ``<COMPU-INTERNAL-TO-PHYS>``."""
    cs = etree.SubElement(parent, "COMPU-SCALE")
    add_text_child(cs, "SHORT-LABEL", scale.short_label)
    add_text_child(cs, "LOWER-LIMIT", scale.lower_limit)
    add_text_child(cs, "UPPER-LIMIT", scale.upper_limit)
    if scale.compu_inverse_value is not None and scale.compu_inverse_value != "":
        civ = etree.SubElement(cs, "COMPU-INVERSE-VALUE")
        add_text_child(civ, "V", scale.compu_inverse_value)
    if scale.compu_const is not None and scale.compu_const != "":
        cc = etree.SubElement(cs, "COMPU-CONST")
        add_text_child(cc, "VT", scale.compu_const)
    if scale.compu_rational_coeffs:
        numerator, denominator = scale.compu_rational_coeffs
        rc = etree.SubElement(cs, "COMPU-RATIONAL-COEFFS")
        num = etree.SubElement(rc, "COMPU-NUMERATOR")
        for v in numerator:
            add_text_child(num, "V", v)
        if denominator:
            den = etree.SubElement(rc, "COMPU-DENOMINATOR")
            for v in denominator:
                add_text_child(den, "V", v)


def add_compu_method(parent: etree._Element, cm: CompuMethod) -> None:
    """Emit ``<COMPU-METHOD>`` with category and scale list."""
    elem = etree.SubElement(parent, "COMPU-METHOD")
    add_text_child(elem, "CATEGORY", cm.category)
    scales: list[CompuScale] = []
    if cm.compu_internal_to_phys:
        scales = cm.compu_internal_to_phys
    elif cm.compu_scales:
        scales = cm.compu_scales
    if scales:
        itp = etree.SubElement(elem, "COMPU-INTERNAL-TO-PHYS")
        wrap = etree.SubElement(itp, "COMPU-SCALES")
        for scale in scales:
            _add_compu_scale(wrap, scale)
    if cm.compu_phys_to_internal:
        pti = etree.SubElement(elem, "COMPU-PHYS-TO-INTERNAL")
        wrap = etree.SubElement(pti, "COMPU-SCALES")
        for scale in cm.compu_phys_to_internal:
            _add_compu_scale(wrap, scale)


def add_unit_spec(parent: etree._Element, unit_spec: UnitSpec | None) -> None:
    """Emit ``<UNIT-SPEC>`` containing units, unit groups and dimensions."""
    if unit_spec is None:
        return
    if (
        not unit_spec.units
        and not unit_spec.unit_groups
        and not unit_spec.physical_dimensions
    ):
        return
    us = etree.SubElement(parent, "UNIT-SPEC")
    if unit_spec.unit_groups:
        groups = etree.SubElement(us, "UNIT-GROUPS")
        for g in unit_spec.unit_groups:
            ug = etree.SubElement(groups, "UNIT-GROUP")
            if g.oid:
                ug.set("ID", g.oid)
            add_text_child(ug, "SHORT-NAME", g.short_name)
            add_long_name(ug, g.long_name)
            add_text_child(ug, "CATEGORY", g.category)
            if g.unit_refs:
                refs = etree.SubElement(ug, "UNIT-REFS")
                for r in g.unit_refs:
                    ref_el = etree.SubElement(refs, "UNIT-REF")
                    set_ref_attrs(ref_el, r)
    if unit_spec.units:
        units = etree.SubElement(us, "UNITS")
        for u in unit_spec.units:
            ue = etree.SubElement(units, "UNIT")
            if u.oid:
                ue.set("ID", u.oid)
            add_text_child(ue, "SHORT-NAME", u.short_name)
            add_long_name(ue, u.long_name)
            add_text_child(ue, "DISPLAY-NAME", u.display_name)
            if u.factor_si_to_unit is not None:
                add_text_child(ue, "FACTOR-SI-TO-UNIT", u.factor_si_to_unit)
            if u.offset_si_to_unit is not None:
                add_text_child(ue, "OFFSET-SI-TO-UNIT", u.offset_si_to_unit)
            if u.physical_dimension_ref is not None:
                ref = etree.SubElement(ue, "PHYSICAL-DIMENSION-REF")
                set_ref_attrs(ref, u.physical_dimension_ref)
    if unit_spec.physical_dimensions:
        dims = etree.SubElement(us, "PHYSICAL-DIMENSIONS")
        for d in unit_spec.physical_dimensions:
            pd = etree.SubElement(dims, "PHYSICAL-DIMENSION")
            if d.oid:
                pd.set("ID", d.oid)
            add_text_child(pd, "SHORT-NAME", d.short_name)
            add_long_name(pd, d.long_name)
            add_description(pd, d.description)


def add_dop(
    parent_props: etree._Element,
    dop: DataObjectProp,
) -> None:
    """Emit one ``<DATA-OBJECT-PROP>`` under a ``<DATA-OBJECT-PROPS>`` parent."""
    elem = etree.SubElement(parent_props, "DATA-OBJECT-PROP")
    if dop.oid:
        elem.set("ID", dop.oid)
    add_text_child(elem, "SHORT-NAME", dop.short_name)
    add_long_name(elem, dop.long_name)
    add_description(elem, dop.description)
    add_compu_method(elem, dop.compu_method)
    add_diag_coded_type(elem, dop.diag_coded_type)
    add_physical_type(elem, dop.physical_type)
    if dop.internal_constr is not None:
        lower, upper = dop.internal_constr
        ic = etree.SubElement(elem, "INTERNAL-CONSTR")
        add_text_child(ic, "LOWER-LIMIT", lower)
        add_text_child(ic, "UPPER-LIMIT", upper)
    if dop.unit_ref is not None:
        ref = etree.SubElement(elem, "UNIT-REF")
        set_ref_attrs(ref, dop.unit_ref)
    add_sdgs(elem, dop.sdgs)


# ---------------------------------------------------------------------------
# Additional helpers for ODX-D / ODX-E (DTC-DOPs, structures, params,
# requests, responses, diag-services, diag-data-dictionary-spec).
# ---------------------------------------------------------------------------


def add_ref_child(
    parent: etree._Element,
    tag: str,
    ref: OdxRef | None,
) -> etree._Element | None:
    """Append ``<TAG ID-REF="...">`` to ``parent`` when ``ref`` is not None."""
    if ref is None:
        return None
    child = etree.SubElement(parent, tag)
    set_ref_attrs(child, ref)
    return child


def add_dtc(parent: etree._Element, dtc: Dtc) -> None:
    """Emit one ``<DTC>`` element under a ``<DTCS>`` parent."""
    elem = etree.SubElement(parent, "DTC")
    if dtc.oid:
        elem.set("ID", dtc.oid)
    add_text_child(elem, "SHORT-NAME", dtc.short_name)
    add_text_child(elem, "TROUBLE-CODE", dtc.trouble_code)
    add_text_child(elem, "DISPLAY-TROUBLE-CODE", dtc.display_trouble_code)
    add_text_child(elem, "TEXT", dtc.text)
    if dtc.level is not None:
        add_text_child(elem, "LEVEL", dtc.level)
    elem.set("IS-TEMPORARY", "true" if dtc.is_temporary else "false")
    add_sdgs(elem, dtc.sdgs)


def add_dtc_dop(parent: etree._Element, dop: DtcDop) -> None:
    """Emit one ``<DTC-DOP>`` element under a ``<DTC-DOPS>`` parent."""
    elem = etree.SubElement(parent, "DTC-DOP")
    if dop.oid:
        elem.set("ID", dop.oid)
    elem.set("IS-VISIBLE", "true" if dop.is_visible else "false")
    add_text_child(elem, "SHORT-NAME", dop.short_name)
    add_long_name(elem, dop.long_name)
    add_description(elem, dop.description)
    add_diag_coded_type(elem, dop.diag_coded_type)
    add_physical_type(elem, dop.physical_type)
    add_compu_method(elem, dop.compu_method)
    if dop.dtcs:
        wrap = etree.SubElement(elem, "DTCS")
        for d in dop.dtcs:
            add_dtc(wrap, d)


def add_param(parent: etree._Element, param: Param) -> None:
    """Emit one ``<PARAM>`` element under a ``<PARAMS>`` parent.

    The wire-side discriminator ``xsi:type`` is taken from ``param.param_kind``
    (e.g. ``VALUE``, ``CODED-CONST``, ``NRC-CONST``, ``RESERVED``).
    """
    elem = etree.SubElement(parent, "PARAM")
    elem.set(XSI_TYPE_ATTR, param.param_kind)
    if param.oid:
        elem.set("ID", param.oid)
    if param.semantic:
        elem.set("SEMANTIC", param.semantic)
    add_text_child(elem, "SHORT-NAME", param.short_name)
    add_description(elem, param.description)
    if param.byte_position is not None:
        add_text_child(elem, "BYTE-POSITION", param.byte_position)
    if param.bit_position is not None:
        add_text_child(elem, "BIT-POSITION", param.bit_position)
    if param.bit_length is not None:
        add_text_child(elem, "BIT-LENGTH", param.bit_length)
    if param.coded_value is not None:
        add_text_child(elem, "CODED-VALUE", param.coded_value)
    if param.phys_constant_value is not None:
        pcv = etree.SubElement(elem, "PHYS-CONSTANT-VALUE")
        add_text_child(pcv, "V", param.phys_constant_value)
    if param.request_byte_pos is not None:
        add_text_child(elem, "REQUEST-BYTE-POS", param.request_byte_pos)
    add_ref_child(elem, "DOP-REF", param.dop_ref)
    if param.dop_snref is not None:
        sn = etree.SubElement(elem, "DOP-SNREF")
        sn.set("SHORT-NAME", param.dop_snref.short_name)


def add_structure(parent: etree._Element, struct: Structure) -> None:
    """Emit one ``<STRUCTURE>`` element under a ``<STRUCTURES>`` parent."""
    elem = etree.SubElement(parent, "STRUCTURE")
    if struct.oid:
        elem.set("ID", struct.oid)
    add_text_child(elem, "SHORT-NAME", struct.short_name)
    add_long_name(elem, struct.long_name)
    if struct.byte_size is not None:
        add_text_child(elem, "BYTE-SIZE", struct.byte_size)
    if struct.params:
        wrap = etree.SubElement(elem, "PARAMS")
        for p in struct.params:
            add_param(wrap, p)


def add_request(parent: etree._Element, req: Request) -> None:
    """Emit one ``<REQUEST>`` element under a ``<REQUESTS>`` parent."""
    elem = etree.SubElement(parent, "REQUEST")
    if req.oid:
        elem.set("ID", req.oid)
    add_text_child(elem, "SHORT-NAME", req.short_name)
    add_long_name(elem, req.long_name)
    if req.params:
        wrap = etree.SubElement(elem, "PARAMS")
        for p in req.params:
            add_param(wrap, p)


def add_response(parent: etree._Element, resp: Response) -> None:
    """Emit one response element using ``resp.response_type`` as the tag.

    The wrapping tag is one of ``POS-RESPONSE``, ``NEG-RESPONSE`` or
    ``GLOBAL-NEG-RESPONSE`` — the caller decides which ``*-RESPONSES`` block
    the element belongs to.
    """
    tag = resp.response_type or "POS-RESPONSE"
    elem = etree.SubElement(parent, tag)
    if resp.oid:
        elem.set("ID", resp.oid)
    add_text_child(elem, "SHORT-NAME", resp.short_name)
    add_long_name(elem, resp.long_name)
    if resp.params:
        wrap = etree.SubElement(elem, "PARAMS")
        for p in resp.params:
            add_param(wrap, p)


def add_diag_service(parent: etree._Element, svc: DiagService) -> None:
    """Emit one ``<DIAG-SERVICE>`` element under a ``<DIAG-COMMS>`` parent."""
    elem = etree.SubElement(parent, "DIAG-SERVICE")
    if svc.oid:
        elem.set("ID", svc.oid)
    if svc.semantic:
        elem.set("SEMANTIC", svc.semantic)
    elem.set("ADDRESSING", svc.addressing)
    elem.set("IS-EXECUTABLE", "true" if svc.is_executable else "false")
    elem.set("TRANSMISSION-MODE", svc.transmission_mode)
    add_text_child(elem, "SHORT-NAME", svc.short_name)
    add_long_name(elem, svc.long_name)
    add_description(elem, svc.description)
    if svc.functional_class_refs:
        wrap = etree.SubElement(elem, "FUNCT-CLASS-REFS")
        for r in svc.functional_class_refs:
            add_ref_child(wrap, "FUNCT-CLASS-REF", r)
    add_audience(elem, svc.audience)
    add_ref_child(elem, "REQUEST-REF", svc.request_ref)
    if svc.pos_response_refs:
        wrap = etree.SubElement(elem, "POS-RESPONSE-REFS")
        for r in svc.pos_response_refs:
            add_ref_child(wrap, "POS-RESPONSE-REF", r)
    if svc.neg_response_refs:
        wrap = etree.SubElement(elem, "NEG-RESPONSE-REFS")
        for r in svc.neg_response_refs:
            add_ref_child(wrap, "NEG-RESPONSE-REF", r)
    if svc.comparam_refs:
        wrap = etree.SubElement(elem, "COMPARAM-REFS")
        for r in svc.comparam_refs:
            add_ref_child(wrap, "COMPARAM-REF", r)
    add_sdgs(elem, svc.sdgs)


def add_diag_data_dictionary_spec(
    parent: etree._Element,
    dds: DiagDataDictionarySpec | None,
) -> None:
    """Emit ``<DIAG-DATA-DICTIONARY-SPEC>``; no-op when ``dds`` is None/empty."""
    if dds is None:
        return
    if not any(
        (
            dds.data_object_props,
            dds.dtc_dops,
            dds.structures,
            dds.end_of_pdu_fields,
            dds.dynamic_endmarker_fields,
            dds.static_fields,
            dds.env_data_descs,
            dds.env_datas,
            dds.muxes,
            dds.tables,
            dds.unit_spec,
        )
    ):
        return
    elem = etree.SubElement(parent, "DIAG-DATA-DICTIONARY-SPEC")
    if dds.dtc_dops:
        wrap = etree.SubElement(elem, "DTC-DOPS")
        for d in dds.dtc_dops:
            add_dtc_dop(wrap, d)
    if dds.data_object_props:
        wrap = etree.SubElement(elem, "DATA-OBJECT-PROPS")
        for d in dds.data_object_props:
            add_dop(wrap, d)
    if dds.structures:
        wrap = etree.SubElement(elem, "STRUCTURES")
        for s in dds.structures:
            add_structure(wrap, s)
    add_unit_spec(elem, dds.unit_spec)
