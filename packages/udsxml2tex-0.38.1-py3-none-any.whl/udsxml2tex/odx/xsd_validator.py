"""XSD validation wrapper for ODX 2.2.0 / PDX outputs.

This module validates serialized ODX XML bytes (or whole PDX archives)
against the schema files bundled under :mod:`udsxml2tex.odx.xsd`.

Validation scope
----------------

The bundled XSDs are **lenient structural schemas** (see
``udsxml2tex/odx/xsd/LICENSE``): they check only that the document has an
``<ODX>`` root containing the correct top-level child element for the
category. They do *not* enforce the full ODX 2.2.0 grammar. This is enough
to catch:

* Wrong category dispatched to the wrong writer.
* Missing or misspelled top-level element (e.g. ``<DIAG-LAYER-CONT>``).
* Malformed XML / encoding errors.

For full grammar enforcement, replace the bundled XSDs with the official
ASAM ODX 2.2.0 schema set (review the ASAM licence terms first). The
validator discovers schemas purely by filename, so no Python changes are
required after dropping in the official XSDs.

TODO(strict mode)
-----------------

When ASAM-licensed XSDs become available, drop them into
``src/udsxml2tex/odx/xsd/`` (alongside any imports they reference) and
update ``xsd/LICENSE`` accordingly. The ``get_xsd_path``,
``validate_odx`` and ``validate_pdx`` functions below already locate
schemas by category and require no further changes.
"""

from __future__ import annotations

import zipfile
from dataclasses import dataclass, field
from pathlib import Path

from lxml import etree

from udsxml2tex.odx.models_odx import ODX_CATEGORY_SUFFIX, OdxCategory

__all__ = [
    "ValidationResult",
    "get_xsd_path",
    "validate_odx",
    "validate_pdx",
    "xsd_dir",
]


@dataclass
class ValidationResult:
    """Outcome of a single XSD validation call."""

    is_valid: bool = True
    errors: list[str] = field(default_factory=list)
    schema_used: str = ""


def xsd_dir() -> Path:
    """Return the path to the bundled XSD directory."""
    return Path(__file__).resolve().parent / "xsd"


def get_xsd_path(category: OdxCategory) -> Path | None:
    """Return the absolute path to the XSD for ``category``.

    :returns: the XSD :class:`Path` if it exists on disk, otherwise
        ``None``. The filename is derived from
        :data:`ODX_CATEGORY_SUFFIX` so ``DIAG_LAYER`` resolves to
        ``odx-d.xsd``.
    """
    suffix = ODX_CATEGORY_SUFFIX.get(category)
    if not suffix:
        return None
    path = xsd_dir() / f"{suffix}.xsd"
    return path if path.is_file() else None


def _load_schema(path: Path) -> etree.XMLSchema:
    """Parse and compile an XSD into an ``etree.XMLSchema`` validator."""
    schema_doc = etree.parse(str(path))
    return etree.XMLSchema(schema_doc)


def _format_error(err: etree._LogEntry) -> str:
    """Render an lxml validation error into a human-friendly string."""
    line = getattr(err, "line", 0) or 0
    col = getattr(err, "column", 0) or 0
    msg = getattr(err, "message", "") or str(err)
    return f"{line}:{col}: {msg}"


def validate_odx(
    xml_bytes: bytes,
    category: OdxCategory,
) -> ValidationResult:
    """Validate ``xml_bytes`` against the bundled XSD for ``category``.

    :param xml_bytes: UTF-8 encoded ODX XML document (typically the output
        of one of the category serializers).
    :param category: which ODX category the bytes are expected to conform to.
    :returns: a :class:`ValidationResult`. When the XML is structurally
        invalid (parse error or schema mismatch) ``is_valid`` is ``False``
        and :attr:`ValidationResult.errors` contains one entry per error.
    :raises FileNotFoundError: if no XSD is available for ``category``.
    """
    xsd_path = get_xsd_path(category)
    if xsd_path is None:
        raise FileNotFoundError(
            f"No XSD bundled for ODX category {category!r}; "
            f"expected file under {xsd_dir()}"
        )
    schema = _load_schema(xsd_path)
    try:
        doc = etree.fromstring(xml_bytes)
    except etree.XMLSyntaxError as exc:
        return ValidationResult(
            is_valid=False,
            errors=[f"XML parse error: {exc}"],
            schema_used=xsd_path.name,
        )
    is_valid = schema.validate(doc)
    errors: list[str] = [] if is_valid else [
        _format_error(e) for e in schema.error_log
    ]
    return ValidationResult(
        is_valid=is_valid,
        errors=errors,
        schema_used=xsd_path.name,
    )


def _category_from_filename(name: str) -> OdxCategory | None:
    """Reverse-lookup of an ODX category from a member filename.

    Matches the file extension (``.odx-d``, ``.odx-cs``, ...) against the
    :data:`ODX_CATEGORY_SUFFIX` table. Returns ``None`` for unknown
    extensions so callers can skip ``index.xml`` and ancillary files.
    """
    lower = name.lower()
    for cat, suffix in ODX_CATEGORY_SUFFIX.items():
        if lower.endswith("." + suffix):
            return cat
    return None


def validate_pdx(
    pdx_path: str | Path,
) -> dict[str, ValidationResult]:
    """Validate every ``.odx-*`` member of a PDX archive.

    :param pdx_path: filesystem path to a PDX (ZIP) archive.
    :returns: a dict keyed by member filename → :class:`ValidationResult`.
        ``index.xml`` and any non-ODX member (e.g. binary blobs added via
        ``pack_pdx(extra_files=...)``) are skipped.
    :raises FileNotFoundError: if ``pdx_path`` does not exist.
    :raises zipfile.BadZipFile: if ``pdx_path`` is not a valid ZIP archive.
    """
    pdx_path = Path(pdx_path)
    if not pdx_path.is_file():
        raise FileNotFoundError(f"PDX archive not found: {pdx_path}")
    results: dict[str, ValidationResult] = {}
    with zipfile.ZipFile(pdx_path, "r") as zf:
        for member in zf.namelist():
            category = _category_from_filename(member)
            if category is None:
                continue
            data = zf.read(member)
            try:
                results[member] = validate_odx(data, category)
            except FileNotFoundError as exc:
                results[member] = ValidationResult(
                    is_valid=False,
                    errors=[str(exc)],
                    schema_used="",
                )
    return results
