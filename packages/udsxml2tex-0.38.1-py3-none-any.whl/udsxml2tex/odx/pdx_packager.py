"""PDX (ZIP) packager for ODX 2.2.0 / ISO 22901-1 deliverables.

A PDX archive is a ZIP file containing one ``index.xml`` plus one or more
``.odx-*`` member files (one per ODX top-level category). This module bundles
:class:`~udsxml2tex.odx.models_odx.OdxDocument` instances into such a ZIP
archive using the category-specific serializers from
:mod:`udsxml2tex.odx.serializers`.

Design notes:

* **Reproducible builds.** All ZIP entries are written with a fixed timestamp
  (``REPRODUCIBLE_TIMESTAMP``) so two runs with identical inputs produce
  byte-identical PDX archives. This makes it possible to track checksums of
  PDX outputs in version control or CI.
* **Lazy imports.** Per-category serializers are imported inside ``_serialize``
  on demand so this module loads even when only a subset of agents'
  serializers are present. Adding new categories requires only one branch
  in ``_serialize`` and one row in ``_PDX_MIME_TYPE``.
* **Validation is opt-in.** Validation against the bundled XSDs is disabled by
  default (``validate=False``). When enabled it never aborts packaging — any
  errors are surfaced via :attr:`PdxPackResult.validation_errors` so callers
  can decide whether to fail the build.
* **Extras.** Flash binary blobs, company logos or supplementary files may be
  embedded alongside the .odx-* members through the ``extra_files`` mapping.

Usage::

    from udsxml2tex.odx.pdx_packager import pack_pdx
    result = pack_pdx(documents, "/tmp/ECU.pdx", validate=True)
    print(result.members, result.validation_errors)
"""

from __future__ import annotations

import io
import zipfile
from collections.abc import Iterable
from dataclasses import dataclass, field
from pathlib import Path

from lxml import etree

from udsxml2tex.odx.models_odx import OdxCategory, OdxDocument

__all__ = [
    "PdxPackResult",
    "REPRODUCIBLE_TIMESTAMP",
    "pack_pdx",
    "write_loose_odx",
]


# Fixed timestamp used for every ZIP entry to keep the archive byte-identical
# across re-runs. (Year, month, day, hour, minute, second) tuple compatible
# with ``ZipInfo.date_time``.
REPRODUCIBLE_TIMESTAMP: tuple[int, int, int, int, int, int] = (2026, 5, 14, 0, 0, 0)

# ASAM-aligned MIME type per category. The ``application/vnd.iso.odx-*+xml``
# convention is in widespread use among ODX tools even though ISO 22901-1
# does not assign an IANA-registered type.
_PDX_MIME_TYPE: dict[OdxCategory, str] = {
    OdxCategory.DIAG_LAYER: "application/vnd.iso.odx-d+xml",
    OdxCategory.COMPARAM_SPEC: "application/vnd.iso.odx-c+xml",
    OdxCategory.COMPARAM_SUBSET: "application/vnd.iso.odx-cs+xml",
    OdxCategory.VEHICLE_INFO: "application/vnd.iso.odx-v+xml",
    OdxCategory.ECU_SHARED_DATA: "application/vnd.iso.odx-e+xml",
    OdxCategory.FLASH: "application/vnd.iso.odx-f+xml",
    OdxCategory.FUNCTION_DICTIONARY: "application/vnd.iso.odx-fd+xml",
    OdxCategory.MULTIPLE_ECU_JOB_SPEC: "application/vnd.iso.odx-m+xml",
}

# index.xml uses the dashed form of each enum (DIAG-LAYER, COMPARAM-SUBSET, ...)
_INDEX_CATEGORY_LABEL: dict[OdxCategory, str] = {
    OdxCategory.DIAG_LAYER: "DIAG-LAYER",
    OdxCategory.COMPARAM_SPEC: "COMPARAM-SPEC",
    OdxCategory.COMPARAM_SUBSET: "COMPARAM-SUBSET",
    OdxCategory.VEHICLE_INFO: "VEHICLE-INFO",
    OdxCategory.ECU_SHARED_DATA: "ECU-SHARED-DATA",
    OdxCategory.FLASH: "FLASH",
    OdxCategory.FUNCTION_DICTIONARY: "FUNCTION-DICTIONARY",
    OdxCategory.MULTIPLE_ECU_JOB_SPEC: "MULTIPLE-ECU-JOB-SPEC",
}

# Fixed generation timestamp used in index.xml so the bytes are stable
# across re-runs. Adjust when bumping ``REPRODUCIBLE_TIMESTAMP``.
_INDEX_GENERATED_DATE = "2026-05-14T00:00:00Z"


@dataclass
class PdxPackResult:
    """Result returned by :func:`pack_pdx`."""

    path: Path
    members: list[str] = field(default_factory=list)
    index_xml: bytes = b""
    validation_errors: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _normalise_documents(
    documents: dict[str, OdxDocument] | Iterable[OdxDocument],
) -> list[tuple[str, OdxDocument]]:
    """Return a stable, ordered list of (member_path, document) pairs.

    Accepts either a dict (the canonical ``map_spec_to_odx`` output) or any
    iterable of :class:`OdxDocument` instances. Documents that lack a
    ``pdx_member_path`` fall back to ``<SHORT-NAME>.odx-<suffix>``; if a
    short name is unavailable a synthetic ``Doc<N>.odx-<suffix>`` is used.
    """
    items: list[tuple[str, OdxDocument]] = []
    if isinstance(documents, dict):
        for key, doc in documents.items():
            member = key if key else _fallback_member_name(doc, len(items))
            items.append((member, doc))
    else:
        for idx, doc in enumerate(documents):
            member = doc.pdx_member_path or _fallback_member_name(doc, idx)
            items.append((member, doc))
    return items


def _fallback_member_name(doc: OdxDocument, idx: int) -> str:
    """Generate a member filename when the document does not declare one."""
    short_name = ""
    content = doc.content
    if content is not None:
        short_name = getattr(content, "short_name", "") or ""
    if not short_name:
        short_name = f"Doc{idx + 1}"
    return f"{short_name}.{doc.file_suffix}"


def _short_name_for_index(doc: OdxDocument, member: str) -> str:
    """Pick the short-name used in ``index.xml``.

    Prefers the content object's ``short_name``, falling back to the bare
    filename stem of the PDX member path.
    """
    content = doc.content
    if content is not None:
        sn = getattr(content, "short_name", "") or ""
        if sn:
            return sn
    return Path(member).stem


def _serialize(doc: OdxDocument) -> bytes:
    """Dispatch ``doc`` to the right category serializer and return XML bytes.

    Imports are deferred to keep this module importable even when a sibling
    agent has not yet committed their serializer module.
    """
    cat = doc.category
    if cat == OdxCategory.DIAG_LAYER:
        from udsxml2tex.odx.serializers.odx_d import serialize_odx_d
        return serialize_odx_d(doc)
    if cat == OdxCategory.COMPARAM_SPEC:
        from udsxml2tex.odx.serializers.odx_c import serialize_odx_c
        return serialize_odx_c(doc)
    if cat == OdxCategory.COMPARAM_SUBSET:
        from udsxml2tex.odx.serializers.odx_cs import serialize_odx_cs
        return serialize_odx_cs(doc)
    if cat == OdxCategory.VEHICLE_INFO:
        from udsxml2tex.odx.serializers.odx_v import serialize_odx_v
        return serialize_odx_v(doc)
    if cat == OdxCategory.ECU_SHARED_DATA:
        from udsxml2tex.odx.serializers.odx_e import serialize_odx_e
        return serialize_odx_e(doc)
    if cat == OdxCategory.FLASH:
        from udsxml2tex.odx.serializers.odx_f import serialize_odx_f
        return serialize_odx_f(doc)
    if cat == OdxCategory.FUNCTION_DICTIONARY:
        from udsxml2tex.odx.serializers.odx_fd import serialize_odx_fd
        return serialize_odx_fd(doc)
    if cat == OdxCategory.MULTIPLE_ECU_JOB_SPEC:
        from udsxml2tex.odx.serializers.odx_m import serialize_odx_m
        return serialize_odx_m(doc)
    raise ValueError(f"Unsupported ODX category: {cat!r}")


def _build_index_xml(
    entries: list[tuple[str, OdxDocument]],
    *,
    tool_version: str,
) -> bytes:
    """Build the ``index.xml`` payload listing every PDX member.

    The schema is the conventional ASAM PDX index used by commercial ODX
    tooling: one ``<ENTRY>`` per .odx-* member carrying the short name,
    category label, filename and PDX MIME type, plus a ``<GENERATED>``
    block recording the tool that produced the archive.
    """
    root = etree.Element("ODX-INDEX", attrib={"MODEL-VERSION": "2.2.0"})
    entries_el = etree.SubElement(root, "ENTRIES")
    for member, doc in entries:
        e = etree.SubElement(entries_el, "ENTRY")
        sn = etree.SubElement(e, "SHORT-NAME")
        sn.text = _short_name_for_index(doc, member)
        cat = etree.SubElement(e, "CATEGORY")
        cat.text = _INDEX_CATEGORY_LABEL.get(doc.category, doc.category.value)
        fn = etree.SubElement(e, "FILE-NAME")
        fn.text = member
        mt = etree.SubElement(e, "PDX-MIME-TYPE")
        mt.text = _PDX_MIME_TYPE.get(doc.category, "application/octet-stream")
    gen = etree.SubElement(root, "GENERATED")
    tool = etree.SubElement(gen, "TOOL")
    tool.text = tool_version
    date = etree.SubElement(gen, "DATE")
    date.text = _INDEX_GENERATED_DATE
    return etree.tostring(
        root,
        xml_declaration=True,
        encoding="UTF-8",
        pretty_print=True,
        standalone=False,
    )


def _write_zip_entry(
    zf: zipfile.ZipFile,
    arcname: str,
    payload: bytes,
) -> None:
    """Write ``payload`` into ``zf`` under ``arcname`` with a fixed timestamp.

    Using ``ZipInfo`` (instead of ``writestr`` with a string) gives us full
    control over the entry's date/time and compression so the resulting
    archive is bit-for-bit reproducible.
    """
    info = zipfile.ZipInfo(filename=arcname, date_time=REPRODUCIBLE_TIMESTAMP)
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = 0o644 << 16  # rw-r--r-- file permissions
    zf.writestr(info, payload)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def pack_pdx(
    documents: dict[str, OdxDocument] | Iterable[OdxDocument],
    out_path: str | Path,
    *,
    validate: bool = False,
    extra_files: dict[str, bytes] | None = None,
    tool_version: str = "udsxml2tex",
) -> PdxPackResult:
    """Pack a set of ODX documents into a PDX (ZIP) archive.

    :param documents: either a ``dict`` keyed by PDX member filename (the
        canonical shape returned by :func:`map_spec_to_odx`) or any iterable
        of :class:`OdxDocument` instances. When a dict is supplied the keys
        are used as archive paths verbatim; for iterables the
        ``pdx_member_path`` attribute is consulted (with a deterministic
        fallback when empty).
    :param out_path: filesystem path where the resulting ``.pdx`` ZIP file
        should be written. Parent directories are created when missing.
    :param validate: when ``True`` each serialized member is validated
        against the bundled XSD via
        :mod:`udsxml2tex.odx.xsd_validator`. Errors are aggregated into
        :attr:`PdxPackResult.validation_errors` but do **not** abort the
        packaging step (warning mode).
    :param extra_files: optional ``{archive_path: bytes}`` mapping; these
        entries are written after the .odx-* members so the index.xml never
        references them. Use this for flash blobs, supplementary docs or
        company artwork.
    :param tool_version: string recorded under ``<TOOL>`` in ``index.xml``;
        typically the udsxml2tex version (``"udsxml2tex/0.36.0"``).
    :returns: a :class:`PdxPackResult` describing the resulting archive.
    """
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    entries = _normalise_documents(documents)
    index_xml = _build_index_xml(entries, tool_version=tool_version)

    validation_errors: list[str] = []
    serialized: list[tuple[str, bytes]] = []
    for member, doc in entries:
        payload = _serialize(doc)
        serialized.append((member, payload))
        if validate:
            try:
                from udsxml2tex.odx.xsd_validator import validate_odx
            except ImportError as exc:  # pragma: no cover - validator ships with this module
                validation_errors.append(f"{member}: validator unavailable ({exc})")
                continue
            result = validate_odx(payload, doc.category)
            if not result.is_valid:
                validation_errors.extend(f"{member}: {e}" for e in result.errors)

    # Build the archive in-memory first, then atomically replace the target.
    # This avoids partial files on disk if something fails partway through.
    buffer = io.BytesIO()
    members: list[str] = []
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        _write_zip_entry(zf, "index.xml", index_xml)
        members.append("index.xml")
        for member, payload in serialized:
            _write_zip_entry(zf, member, payload)
            members.append(member)
        if extra_files:
            # Deterministic ordering for reproducibility.
            for extra_name in sorted(extra_files.keys()):
                _write_zip_entry(zf, extra_name, extra_files[extra_name])
                members.append(extra_name)

    out_path.write_bytes(buffer.getvalue())
    return PdxPackResult(
        path=out_path,
        members=members,
        index_xml=index_xml,
        validation_errors=validation_errors,
    )


def write_loose_odx(
    documents: dict[str, OdxDocument] | Iterable[OdxDocument],
    out_dir: str | Path,
) -> list[Path]:
    """Write each document as a standalone ``.odx-*`` file (no ZIP).

    This is the "exploded" counterpart to :func:`pack_pdx`: useful for diffs
    and human review during development, or when downstream tooling expects
    individual files rather than an archive.

    :param documents: same shape as accepted by :func:`pack_pdx`.
    :param out_dir: directory to write into; created when missing. Files are
        named after each document's ``pdx_member_path``.
    :returns: list of absolute :class:`Path` objects, one per written file,
        in the same order as the documents were supplied.
    """
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    paths: list[Path] = []
    for member, doc in _normalise_documents(documents):
        payload = _serialize(doc)
        target = out_dir / member
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(payload)
        paths.append(target.resolve())
    return paths
