"""Communication ARXML parser — I-SIGNAL, FRAME, PDU and system topology."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


# ---------------------------------------------------------------------------
# Model classes
# ---------------------------------------------------------------------------


@dataclass
class FrameSignal:
    """I-SIGNAL placement within a FRAME or PDU."""

    signal_ref: str = ""    # I-SIGNAL SHORT-NAME
    start_bit: int = 0
    bit_length: int = 0
    update_bit: int = -1    # -1 = no update bit


@dataclass
class ISignal:
    """I-SIGNAL definition (physical signal on the bus)."""

    short_name: str
    length: int = 0         # bits
    start_bit: int = 0
    byte_order: str = "MOST-SIGNIFICANT-BYTE-FIRST"   # or LAST
    init_value: Optional[float] = None
    data_type: str = ""


@dataclass
class Frame:
    """Communication FRAME definition."""

    short_name: str
    frame_length: int = 0   # bytes
    byte_length: int = 0
    signals: list[FrameSignal] = field(default_factory=list)

    @property
    def frame_length_bits(self) -> int:
        return self.frame_length * 8


@dataclass
class Pdu:
    """PDU (Protocol Data Unit) definition."""

    short_name: str
    pdu_type: str = ""      # I-PDU, N-PDU, etc.
    length: int = 0         # bytes
    signals: list[FrameSignal] = field(default_factory=list)


@dataclass
class EcuInstance:
    """ECU instance in the system topology."""

    short_name: str
    category: str = ""
    connectors: list[str] = field(default_factory=list)       # connector short names
    comm_controllers: list[str] = field(default_factory=list)


@dataclass
class NetworkTopology:
    """Communication network / cluster topology entry."""

    short_name: str
    cluster_name: str = ""
    baudrate: int = 0
    channel_name: str = ""
    protocol: str = "CAN"   # CAN, LIN, FlexRay, Ethernet
    ecus: list[str] = field(default_factory=list)   # ECU instance names


@dataclass
class CommunicationConfig:
    """Complete communication configuration parsed from ARXML."""

    frames: list[Frame] = field(default_factory=list)
    pdus: list[Pdu] = field(default_factory=list)
    isignals: list[ISignal] = field(default_factory=list)
    ecu_instances: list[EcuInstance] = field(default_factory=list)
    networks: list[NetworkTopology] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------


class CommArxmlParser:
    """Parse communication topology from AUTOSAR ARXML (System Extract)."""

    _AR_NS_URI = "http://autosar.org/schema/r4.0"

    # ---- helpers -----------------------------------------------------------

    @staticmethod
    def _build_ns(ns: str) -> dict[str, str]:
        if ns:
            return {"ar": CommArxmlParser._AR_NS_URI}
        return {}

    @staticmethod
    def _xpath_text(el, path: str, ns: str, default: str = "") -> str:
        ns_map = CommArxmlParser._build_ns(ns)
        try:
            if ns_map:
                results = el.xpath(path, namespaces=ns_map)
            else:
                import re as _re
                results = el.xpath(_re.sub(r"ar:", "", path))
        except Exception:
            return default
        if results:
            from lxml import etree as _etree
            first = results[0]
            if isinstance(first, _etree._Element):
                return (first.text or "").strip() or default
            return str(first).strip() or default
        return default

    @staticmethod
    def _xpath_int(el, path: str, ns: str, default: int = 0) -> int:
        text = CommArxmlParser._xpath_text(el, path, ns, "")
        if text:
            try:
                return int(text, 0)
            except (ValueError, TypeError):
                pass
        return default

    @staticmethod
    def _xpath_float(el, path: str, ns: str, default: float = 0.0) -> float:
        text = CommArxmlParser._xpath_text(el, path, ns, "")
        if text:
            try:
                return float(text)
            except ValueError:
                pass
        return default

    @staticmethod
    def _xpath_els(el, path: str, ns: str) -> list:
        ns_map = CommArxmlParser._build_ns(ns)
        try:
            if ns_map:
                return el.xpath(path, namespaces=ns_map)
            import re as _re
            return el.xpath(_re.sub(r"ar:", "", path))
        except Exception:
            return []

    # ---- sub-parsers -------------------------------------------------------

    def _parse_isignals(self, root, ns: str, config: CommunicationConfig) -> None:
        """Parse I-SIGNAL containers."""
        signal_els = self._xpath_els(
            root,
            f".//{ns}I-SIGNAL | .//{ns}ISignal",
            ns,
        )
        for sig_el in signal_els:
            sn = self._xpath_text(sig_el, f"{ns}SHORT-NAME", ns)
            if not sn:
                continue

            length = self._xpath_int(sig_el, f"{ns}LENGTH", ns)
            start_bit = self._xpath_int(
                sig_el, f"{ns}START-POSITION", ns
            ) or self._xpath_int(sig_el, f"{ns}StartPosition", ns)
            byte_order = (
                self._xpath_text(sig_el, f"{ns}PACKING-BYTE-ORDER", ns)
                or self._xpath_text(sig_el, f"{ns}PackingByteOrder", ns)
                or "MOST-SIGNIFICANT-BYTE-FIRST"
            )
            data_type = (
                self._xpath_text(sig_el, f"{ns}DATA-TYPE-REF", ns)
                or self._xpath_text(sig_el, f"{ns}DataTypeRef", ns)
            )

            # Optional init value
            init_text = (
                self._xpath_text(sig_el, f"{ns}INIT-VALUE/{ns}NUMERICAL-OR-TEXT/{ns}VALUE", ns)
                or self._xpath_text(sig_el, f"{ns}InitValue", ns)
            )
            init_value: Optional[float] = None
            if init_text:
                try:
                    init_value = float(init_text)
                except ValueError:
                    pass

            config.isignals.append(
                ISignal(
                    short_name=sn,
                    length=length,
                    start_bit=start_bit,
                    byte_order=byte_order,
                    init_value=init_value,
                    data_type=data_type,
                )
            )

    def _parse_frame_signals(self, frame_el, ns: str) -> list[FrameSignal]:
        """Extract I-SIGNAL-TO-I-PDU-MAPPING / PDU-TO-FRAME-MAPPING entries."""
        placements: list[FrameSignal] = []
        mapping_els = self._xpath_els(
            frame_el,
            (
                f".//{ns}I-SIGNAL-TO-PDU-MAPPINGS/{ns}I-SIGNAL-TO-I-PDU-MAPPING"
                f" | .//{ns}I-SIGNAL-TO-PDU-MAPPINGS/{ns}ISignalToIPduMapping"
                f" | .//{ns}PDU-TO-FRAME-MAPPINGS/{ns}PDU-TO-FRAME-MAPPING"
                f" | .//{ns}PduToFrameMappings/{ns}PduToFrameMapping"
            ),
            ns,
        )
        for mapping in mapping_els:
            sig_ref = (
                self._xpath_text(mapping, f"{ns}I-SIGNAL-REF", ns)
                or self._xpath_text(mapping, f"{ns}ISignalRef", ns)
                or self._xpath_text(mapping, f"{ns}PDU-REF", ns)
                or self._xpath_text(mapping, f"{ns}PduRef", ns)
            )
            # Resolve short name from the last path segment
            if sig_ref and "/" in sig_ref:
                sig_ref = sig_ref.rsplit("/", 1)[-1]

            start_bit = self._xpath_int(mapping, f"{ns}START-POSITION", ns) or self._xpath_int(
                mapping, f"{ns}StartPosition", ns
            )
            bit_length = self._xpath_int(mapping, f"{ns}BIT-LENGTH", ns) or self._xpath_int(
                mapping, f"{ns}BitLength", ns
            )
            update_bit_text = self._xpath_text(mapping, f"{ns}UPDATE-INDICATION-BIT-POSITION", ns)
            update_bit = int(update_bit_text, 0) if update_bit_text else -1

            placements.append(
                FrameSignal(
                    signal_ref=sig_ref,
                    start_bit=start_bit,
                    bit_length=bit_length,
                    update_bit=update_bit,
                )
            )
        return placements

    def _parse_frames(self, root, ns: str, config: CommunicationConfig) -> None:
        """Parse FRAME containers."""
        frame_els = self._xpath_els(
            root,
            f".//{ns}FRAME | .//{ns}Frame",
            ns,
        )
        for frame_el in frame_els:
            sn = self._xpath_text(frame_el, f"{ns}SHORT-NAME", ns)
            if not sn:
                continue

            frame_length = (
                self._xpath_int(frame_el, f"{ns}FRAME-LENGTH", ns)
                or self._xpath_int(frame_el, f"{ns}FrameLength", ns)
            )
            byte_length = (
                self._xpath_int(frame_el, f"{ns}BYTE-LENGTH", ns)
                or self._xpath_int(frame_el, f"{ns}ByteLength", ns)
                or frame_length
            )
            signals = self._parse_frame_signals(frame_el, ns)

            config.frames.append(
                Frame(
                    short_name=sn,
                    frame_length=frame_length,
                    byte_length=byte_length,
                    signals=signals,
                )
            )

    def _parse_pdus(self, root, ns: str, config: CommunicationConfig) -> None:
        """Parse I-PDU / N-PDU containers."""
        pdu_els = self._xpath_els(
            root,
            (
                f".//{ns}I-PDU | .//{ns}IPdu"
                f" | .//{ns}N-PDU | .//{ns}NPdu"
                f" | .//{ns}DCM-I-PDU | .//{ns}DcmIPdu"
                f" | .//{ns}COM-I-PDU-GROUP | .//{ns}ComIPduGroup"
            ),
            ns,
        )
        for pdu_el in pdu_els:
            sn = self._xpath_text(pdu_el, f"{ns}SHORT-NAME", ns)
            if not sn:
                continue

            # Derive PDU type from element tag
            from lxml import etree as _etree
            tag = _etree.QName(pdu_el.tag).localname if hasattr(_etree, "QName") else pdu_el.tag
            pdu_type = tag.upper().replace("-", "_")

            length = (
                self._xpath_int(pdu_el, f"{ns}LENGTH", ns)
                or self._xpath_int(pdu_el, f"{ns}PDU-LENGTH", ns)
                or self._xpath_int(pdu_el, f"{ns}PduLength", ns)
            )
            signals = self._parse_frame_signals(pdu_el, ns)

            config.pdus.append(
                Pdu(
                    short_name=sn,
                    pdu_type=pdu_type,
                    length=length,
                    signals=signals,
                )
            )

    def _parse_ecu_instances(self, root, ns: str, config: CommunicationConfig) -> None:
        """Parse ECU-INSTANCE containers."""
        ecu_els = self._xpath_els(
            root,
            f".//{ns}ECU-INSTANCE | .//{ns}EcuInstance",
            ns,
        )
        for ecu_el in ecu_els:
            sn = self._xpath_text(ecu_el, f"{ns}SHORT-NAME", ns)
            if not sn:
                continue

            category = (
                self._xpath_text(ecu_el, f"{ns}CATEGORY", ns)
                or self._xpath_text(ecu_el, f"{ns}Category", ns)
            )

            connector_els = self._xpath_els(
                ecu_el,
                f".//{ns}COMMUNICATION-CONNECTOR/{ns}SHORT-NAME"
                f" | .//{ns}CommunicationConnector/{ns}SHORT-NAME",
                ns,
            )
            connectors = [
                (el.text or "").strip() for el in connector_els if (el.text or "").strip()
            ]

            ctrl_els = self._xpath_els(
                ecu_el,
                f".//{ns}COM-CONTROLLER/{ns}SHORT-NAME"
                f" | .//{ns}ComController/{ns}SHORT-NAME",
                ns,
            )
            controllers = [
                (el.text or "").strip() for el in ctrl_els if (el.text or "").strip()
            ]

            config.ecu_instances.append(
                EcuInstance(
                    short_name=sn,
                    category=category,
                    connectors=connectors,
                    comm_controllers=controllers,
                )
            )

    def _parse_networks(self, root, ns: str, config: CommunicationConfig) -> None:
        """Parse COM-CLUSTER / communication channel containers."""
        # AUTOSAR uses typed cluster elements: CAN-CLUSTER, LIN-CLUSTER, etc.
        cluster_patterns = (
            f".//{ns}CAN-CLUSTER | .//{ns}CanCluster"
            f" | .//{ns}LIN-CLUSTER | .//{ns}LinCluster"
            f" | .//{ns}FLEXRAY-CLUSTER | .//{ns}FlexrayCluster"
            f" | .//{ns}ETHERNET-CLUSTER | .//{ns}EthernetCluster"
            f" | .//{ns}COM-CLUSTER | .//{ns}ComCluster"
        )
        cluster_els = self._xpath_els(root, cluster_patterns, ns)

        for cluster_el in cluster_els:
            sn = self._xpath_text(cluster_el, f"{ns}SHORT-NAME", ns)
            if not sn:
                continue

            # Detect protocol from tag name
            from lxml import etree as _etree
            tag = _etree.QName(cluster_el.tag).localname if hasattr(_etree, "QName") else cluster_el.tag
            tag_upper = tag.upper()
            if "LIN" in tag_upper:
                protocol = "LIN"
            elif "FLEXRAY" in tag_upper or "FLEX-RAY" in tag_upper:
                protocol = "FlexRay"
            elif "ETHERNET" in tag_upper:
                protocol = "Ethernet"
            else:
                protocol = "CAN"

            baudrate = (
                self._xpath_int(cluster_el, f"{ns}SPEED", ns)
                or self._xpath_int(cluster_el, f"{ns}Speed", ns)
                or self._xpath_int(cluster_el, f"{ns}BAUDRATE", ns)
                or self._xpath_int(cluster_el, f"{ns}Baudrate", ns)
                or self._xpath_int(cluster_el, f"{ns}CAN-CLUSTER-VARIANTS/{ns}CAN-CLUSTER-CONDITIONAL/{ns}SPEED", ns)
            )

            # Channel name from first physical channel
            channel_name = (
                self._xpath_text(
                    cluster_el,
                    f".//{ns}PHYSICAL-CHANNELS/{ns}CAN-PHYSICAL-CHANNEL/{ns}SHORT-NAME",
                    ns,
                )
                or self._xpath_text(
                    cluster_el,
                    f".//{ns}PHYSICAL-CHANNELS/{ns}LIN-PHYSICAL-CHANNEL/{ns}SHORT-NAME",
                    ns,
                )
                or self._xpath_text(
                    cluster_el,
                    f".//{ns}PHYSICAL-CHANNELS/{ns}ETHERNET-PHYSICAL-CHANNEL/{ns}SHORT-NAME",
                    ns,
                )
            )

            # Collect ECU refs
            ecu_ref_els = self._xpath_els(
                cluster_el,
                f".//{ns}ECU-COMM-PORT-INSTANCES/{ns}I-PDU-PORT/{ns}ECU-REF"
                f" | .//{ns}COMMUNICATION-CONNECTORS/{ns}COMMUNICATION-CONNECTOR/{ns}SHORT-NAME",
                ns,
            )
            ecus = [
                (el.text or "").strip().rsplit("/", 1)[-1]
                for el in ecu_ref_els
                if (el.text or "").strip()
            ]

            config.networks.append(
                NetworkTopology(
                    short_name=sn,
                    cluster_name=sn,
                    baudrate=baudrate,
                    channel_name=channel_name,
                    protocol=protocol,
                    ecus=ecus,
                )
            )

    # ---- public API --------------------------------------------------------

    def parse(self, root, ns: str = "") -> CommunicationConfig:
        """Parse communication ARXML from lxml root element.

        Args:
            root: lxml etree element (root of ARXML document).
            ns:   Namespace prefix with colon, e.g. ``""`` or ``"ar:"``.

        Returns:
            Populated :class:`CommunicationConfig`.
        """
        config = CommunicationConfig()
        self._parse_isignals(root, ns, config)
        self._parse_frames(root, ns, config)
        self._parse_pdus(root, ns, config)
        self._parse_ecu_instances(root, ns, config)
        self._parse_networks(root, ns, config)
        return config


__all__ = [
    "CommunicationConfig",
    "CommArxmlParser",
    "EcuInstance",
    "Frame",
    "FrameSignal",
    "ISignal",
    "NetworkTopology",
    "Pdu",
]
