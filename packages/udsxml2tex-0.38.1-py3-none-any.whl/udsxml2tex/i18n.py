"""Internationalization (i18n) support for udsxml2tex templates.

This module exposes translation tables and a :class:`Translator` helper used
throughout the generator to localize headings, captions, and table column
labels. Three monolingual languages are supported out of the box: ``en``,
``ja``, and ``de``.

Bilingual mode
--------------
For specifications that need to render two languages side-by-side (a common
practice in industrial UDS / reprogramming documents that emit ``"<JP> /
<EN>"`` style headings), the :class:`Translator` also accepts *bilingual*
language codes of the form ``"<primary>+<secondary>"`` — for example
``"ja+en"``. Any of the separators ``+``, ``,``, ``-``, and ``/`` are
accepted between two :data:`MONOLINGUAL_LANGS` codes.

In bilingual mode, :meth:`Translator.t` returns the primary language's
translation joined with the secondary language's translation by a
configurable ``separator`` (default ``" / "``)::

    >>> Translator("ja+en").t("sessions")
    '診断セッション / Sessions'
    >>> Translator("ja+en", separator=" | ").t("sessions")
    '診断セッション | Sessions'

Use :meth:`Translator.t_pair` to obtain the ``(primary, secondary)`` tuple
without joining, which is convenient when assembling custom TeX macros such
as ``\\AutoNewLine{<JP>}{<EN>}``.
"""

from __future__ import annotations

__all__ = [
    "MONOLINGUAL_LANGS",
    "SUPPORTED_LANGS",
    "TRANSLATIONS",
    "Translator",
    "is_bilingual_lang",
    "parse_bilingual_lang",
    "t",
    "t_csv",
    "t_tex",
]

#: Monolingual language codes (the only codes that key into :data:`TRANSLATIONS`).
MONOLINGUAL_LANGS: list[str] = ["en", "ja", "de"]

#: Supported language codes, including bilingual combinations.
#:
#: Bilingual codes are written as ``"<primary>+<secondary>"`` and resolve to
#: ``"<primary translation> / <secondary translation>"`` at lookup time.
SUPPORTED_LANGS: list[str] = [
    "en",
    "ja",
    "de",
    "ja+en",
    "en+ja",
    "de+en",
    "en+de",
    "ja+de",
    "de+ja",
]

#: Accepted separators between two monolingual codes in a bilingual code.
_BILINGUAL_SEPARATORS: tuple[str, ...] = ("+", ",", "-", "/")

#: Translation dictionary: ``TRANSLATIONS[lang][key] = translated_string``.
TRANSLATIONS: dict[str, dict[str, str]] = {
    "en": {
        "sessions": "Sessions",
        "security_levels": "Security Levels",
        "services": "Diagnostic Services",
        "dids": "Data Identifiers (DIDs)",
        "routines": "Routine Controls",
        "dtcs": "Diagnostic Trouble Codes (DTCs)",
        "memory_ranges": "Memory Ranges",
        "transport": "Transport Layer (CanTp)",
        "dem": "Diagnostic Event Manager (DEM)",
        "session_id": "Session ID",
        "security_level": "Security Level",
        "service_id": "Service ID",
        "sub_function": "Sub-Function",
        "description": "Description",
        "supported_sessions": "Supported Sessions",
        "required_security": "Required Security",
        "nrc": "Negative Response Codes",
        "did_id": "DID ID",
        "data_elements": "Data Elements",
        "byte_position": "Byte Position",
        "bit_size": "Bit Size",
        "data_type": "Data Type",
        "read_access": "Read Access",
        "write_access": "Write Access",
        "dtc_id": "DTC ID",
        "severity": "Severity",
        "ecu_name": "ECU Name",
        "protocol": "Protocol",
        "can_rx_id": "CAN RX ID",
        "can_tx_id": "CAN TX ID",
        "yes": "Yes",
        "no": "No",
        "table_of_contents": "Table of Contents",
        "introduction": "Introduction",
        "revision_history": "Revision History",
        "change_history": "Change History",
        "version": "Version",
        "date": "Date",
        "author": "Author",
        "change_description": "Change Description",
        "added": "Added",
        "removed": "Removed",
        "changed": "Changed",
        # Domain / reprogramming keys (Agents A and C consume these).
        "domain": "Domain",
        "domain_drive": "App",
        "domain_boot": "Boot",
        "domain_both": "Both",
        "domain_column_header": "Domain",
        "application_domain": "Application Domain",
        "bootloader_domain": "Bootloader Domain",
        "reprogramming_sequence": "Reprogramming Sequence",
        "flash_segments": "Flash Memory Segments",
        "programming_session": "Programming Session",
        "memory_map": "Memory Map",
        "bootloader": "Bootloader",
        "boot_only": "Boot only",
        "drive_only": "App only",
        "start_address": "Start address",
        "end_address": "End address",
    },
    "de": {
        "sessions": "Diagnosesitzungen",
        "security_levels": "Sicherheitsstufen",
        "services": "Diagnosedienste",
        "dids": "Datenkennungen (DIDs)",
        "routines": "Routinesteuerungen",
        "dtcs": "Diagnosefehlercode (DTCs)",
        "memory_ranges": "Speicherbereiche",
        "transport": "Transportschicht (CanTp)",
        "dem": "Diagnoseereignis-Manager (DEM)",
        "session_id": "Sitzungs-ID",
        "security_level": "Sicherheitsstufe",
        "service_id": "Dienst-ID",
        "sub_function": "Unterfunktion",
        "description": "Beschreibung",
        "supported_sessions": "Unterstützte Sitzungen",
        "required_security": "Erforderliche Sicherheit",
        "nrc": "Negative Antwortcodes",
        "did_id": "DID-ID",
        "data_elements": "Datenelemente",
        "byte_position": "Byte-Position",
        "bit_size": "Bit-Größe",
        "data_type": "Datentyp",
        "read_access": "Lesezugriff",
        "write_access": "Schreibzugriff",
        "dtc_id": "DTC-Code",
        "severity": "Schweregrad",
        "ecu_name": "ECU-Name",
        "protocol": "Protokoll",
        "can_rx_id": "CAN-Empfangs-ID",
        "can_tx_id": "CAN-Sende-ID",
        "yes": "Ja",
        "no": "Nein",
        "table_of_contents": "Inhaltsverzeichnis",
        "introduction": "Einleitung",
        "revision_history": "Revisionshistorie",
        "change_history": "Änderungshistorie",
        "version": "Version",
        "date": "Datum",
        "author": "Autor",
        "change_description": "Änderungsbeschreibung",
        "added": "Hinzugefügt",
        "removed": "Entfernt",
        "changed": "Geändert",
        # Domain / reprogramming keys.
        "domain": "Domäne",
        "domain_drive": "App",
        "domain_boot": "Boot",
        "domain_both": "Beide",
        "domain_column_header": "Domäne",
        "application_domain": "Anwendungsdomäne",
        "bootloader_domain": "Bootloader-Domäne",
        "reprogramming_sequence": "Reprogrammiersequenz",
        "flash_segments": "Flash-Speichersegmente",
        "programming_session": "Programmiersitzung",
        "memory_map": "Speicherabbildung",
        "bootloader": "Bootloader",
        "boot_only": "Nur Bootloader",
        "drive_only": "Nur App",
        "start_address": "Startadresse",
        "end_address": "Endadresse",
    },
    "ja": {
        "sessions": "診断セッション",
        "security_levels": "セキュリティレベル",
        "services": "診断サービス",
        "dids": "データ識別子 (DID)",
        "routines": "ルーティン制御",
        "dtcs": "故障診断コード (DTC)",
        "memory_ranges": "メモリアドレス範囲",
        "transport": "トランスポート層 (CanTp)",
        "dem": "診断イベントマネージャ (DEM)",
        "session_id": "セッション ID",
        "security_level": "セキュリティレベル",
        "service_id": "サービス ID",
        "sub_function": "サブファンクション",
        "description": "説明",
        "supported_sessions": "対応セッション",
        "required_security": "必要セキュリティ",
        "nrc": "否定応答コード",
        "did_id": "DID ID",
        "data_elements": "データ要素",
        "byte_position": "バイト位置",
        "bit_size": "ビットサイズ",
        "data_type": "データ型",
        "read_access": "読み取りアクセス",
        "write_access": "書き込みアクセス",
        "dtc_id": "DTC コード",
        "severity": "重大度",
        "ecu_name": "ECU 名",
        "protocol": "プロトコル",
        "can_rx_id": "CAN 受信 ID",
        "can_tx_id": "CAN 送信 ID",
        "yes": "あり",
        "no": "なし",
        "table_of_contents": "目次",
        "introduction": "はじめに",
        "revision_history": "改訂履歴",
        "change_history": "変更履歴",
        "version": "バージョン",
        "date": "日付",
        "author": "担当者",
        "change_description": "変更内容",
        "added": "追加",
        "removed": "削除",
        "changed": "変更",
        # Domain / reprogramming keys.
        "domain": "ドメイン",
        "domain_drive": "App",
        "domain_boot": "Boot",
        "domain_both": "両方",
        "domain_column_header": "ドメイン",
        "application_domain": "アプリケーションドメイン",
        "bootloader_domain": "ブートローダドメイン",
        "reprogramming_sequence": "リプログラミングシーケンス",
        "flash_segments": "フラッシュメモリセグメント",
        "programming_session": "プログラミングセッション",
        "memory_map": "メモリマップ",
        "bootloader": "ブートローダ",
        "boot_only": "ブートローダのみ",
        "drive_only": "アプリのみ",
        "start_address": "開始アドレス",
        "end_address": "終了アドレス",
    },
}


def is_bilingual_lang(lang: str) -> bool:
    """Return ``True`` when *lang* looks like a bilingual code.

    A bilingual code is two :data:`MONOLINGUAL_LANGS` codes joined by one of
    the separators in :data:`_BILINGUAL_SEPARATORS` — for example ``"ja+en"``,
    ``"en,ja"``, ``"ja-en"``, or ``"ja/en"``. Unknown codes (``"xx+yy"``) and
    monolingual codes (``"en"``) both return ``False``.

    Args:
        lang: A language code string.

    Returns:
        ``True`` if *lang* parses as a bilingual pair, ``False`` otherwise.
    """
    return parse_bilingual_lang(lang) is not None


def parse_bilingual_lang(lang: str) -> tuple[str, str] | None:
    """Split a bilingual code into ``(primary, secondary)``.

    Accepts the separators ``+``, ``,``, ``-``, and ``/``. The two halves must
    both be present in :data:`MONOLINGUAL_LANGS` for the parse to succeed;
    otherwise ``None`` is returned.

    Args:
        lang: A language code such as ``"ja+en"``.

    Returns:
        A ``(primary, secondary)`` tuple, or ``None`` when *lang* is not a
        valid bilingual code.
    """
    if not lang or not isinstance(lang, str):
        return None
    for sep in _BILINGUAL_SEPARATORS:
        if sep in lang:
            parts = lang.split(sep)
            if len(parts) != 2:
                continue
            primary, secondary = parts[0].strip(), parts[1].strip()
            if (
                primary in MONOLINGUAL_LANGS
                and secondary in MONOLINGUAL_LANGS
                and primary != secondary
            ):
                return primary, secondary
            return None
    return None


def _lookup(lang: str, key: str) -> str | None:
    """Return the translation for *key* in *lang*, or ``None`` when absent."""
    lang_map = TRANSLATIONS.get(lang, {})
    return lang_map.get(key)


class Translator:
    """Translates keys to strings for a given language.

    The language code may be either a monolingual code (``"en"``, ``"ja"``,
    ``"de"``) or a bilingual code (``"ja+en"``, ``"de+en"``, ...). See the
    module docstring for the bilingual semantics.

    Examples::

        tr = Translator("ja")
        tr.t("sessions")            # "診断セッション"

        bi = Translator("ja+en")
        bi.t("sessions")            # "診断セッション / Sessions"
        bi.t_pair("sessions")       # ("診断セッション", "Sessions")

        macro = Translator("ja+en", separator="\\n")
        macro.t("sessions")         # "診断セッション\\nSessions"
    """

    def __init__(self, lang: str = "en", separator: str = " / ") -> None:
        """Create a translator.

        Args:
            lang: A monolingual or bilingual language code (see
                :data:`SUPPORTED_LANGS`).
            separator: Joiner used between the primary and secondary halves in
                bilingual mode. Ignored in monolingual mode.
        """
        self._lang = lang
        self._separator = separator
        self._bilingual = parse_bilingual_lang(lang)

    @property
    def lang(self) -> str:
        """The active language code (possibly bilingual)."""
        return self._lang

    @property
    def separator(self) -> str:
        """The separator used between primary and secondary in bilingual mode."""
        return self._separator

    @property
    def is_bilingual(self) -> bool:
        """``True`` when this translator operates in bilingual mode."""
        return self._bilingual is not None

    def set_lang(self, lang: str) -> None:
        """Change the active language.

        Args:
            lang: A monolingual or bilingual language code.
        """
        self._lang = lang
        self._bilingual = parse_bilingual_lang(lang)

    def t(self, key: str, fallback: str = "") -> str:
        """Translate *key* to the active language.

        In monolingual mode the behavior is identical to the historical
        :class:`Translator`: the value from :data:`TRANSLATIONS` is returned,
        falling back to the English translation and finally to *fallback*
        (or the *key* itself when *fallback* is empty).

        In bilingual mode the primary and secondary translations are joined
        with :attr:`separator`. If the secondary language lacks the key, the
        primary translation is used for both halves; if neither language has
        the key, the raw *key* is used for both halves.

        Args:
            key: The translation key to look up.
            fallback: Value returned when *key* is not found in monolingual
                mode. Unused in bilingual mode.

        Returns:
            The translated string.
        """
        if self._bilingual is None:
            return self._mono_lookup(self._lang, key, fallback)
        primary_lang, secondary_lang = self._bilingual
        primary, secondary = self._bilingual_pair(primary_lang, secondary_lang, key)
        return f"{primary}{self._separator}{secondary}"

    def t_pair(self, key: str) -> tuple[str, str]:
        """Return ``(primary, secondary)`` translations for *key*.

        In monolingual mode both elements are identical and equal to
        :meth:`t` for the same key. In bilingual mode the elements are the
        primary and secondary translations respectively, with the same
        fallback rules as :meth:`t`.

        Args:
            key: The translation key to look up.

        Returns:
            A ``(primary, secondary)`` tuple.
        """
        if self._bilingual is None:
            value = self._mono_lookup(self._lang, key, "")
            return value, value
        primary_lang, secondary_lang = self._bilingual
        return self._bilingual_pair(primary_lang, secondary_lang, key)

    @staticmethod
    def _mono_lookup(lang: str, key: str, fallback: str) -> str:
        """Resolve *key* in monolingual *lang* with English-then-key fallback."""
        value = _lookup(lang, key)
        if value is not None:
            return value
        if lang != "en":
            value = _lookup("en", key)
            if value is not None:
                return value
        return fallback if fallback else key

    @staticmethod
    def _bilingual_pair(
        primary_lang: str, secondary_lang: str, key: str
    ) -> tuple[str, str]:
        """Look up *key* for a bilingual pair with graceful fallback."""
        primary = _lookup(primary_lang, key)
        secondary = _lookup(secondary_lang, key)
        if primary is None and secondary is None:
            return key, key
        if primary is None:
            # Secondary present, primary missing — mirror secondary into primary.
            assert secondary is not None  # for type-checkers
            return secondary, secondary
        if secondary is None:
            # Standard "fall back to primary for secondary half" rule.
            return primary, primary
        return primary, secondary


#: Module-level default :class:`Translator` (English).
_default_translator = Translator("en")


def t(key: str, lang: str = "en", fallback: str = "") -> str:
    """Module-level convenience translation function.

    Accepts both monolingual codes (``"en"``, ``"ja"``, ``"de"``) and
    bilingual codes (``"ja+en"`` and friends; see
    :func:`parse_bilingual_lang`). Bilingual lookups always join with the
    default separator ``" / "`` — instantiate a :class:`Translator` directly
    when a custom separator is needed.

    Args:
        key: The translation key to look up.
        lang: Language code. Defaults to ``"en"``.
        fallback: Value returned when *key* is not found in monolingual mode.

    Returns:
        The translated string for *lang*.
    """
    if is_bilingual_lang(lang):
        return Translator(lang).t(key)
    lang_map = TRANSLATIONS.get(lang, {})
    if key in lang_map:
        return lang_map[key]
    en_map = TRANSLATIONS.get("en", {})
    if key in en_map and lang != "en":
        return en_map[key]
    return fallback if fallback else key


def t_tex(key: str, lang: str, *, force_inline: bool = False) -> str:
    """TeX-safe variant of :func:`t`.

    In bilingual mode this convenience returns ``"primary~/~secondary"``,
    using ``~`` (TeX non-breaking space) around the slash so the pair stays
    on the same line. For paragraph-style layout (e.g. an ``\\AutoNewLine``
    macro), use :meth:`Translator.t_pair` to obtain the two halves and
    assemble the macro in the template.

    Args:
        key: The translation key to look up.
        lang: A monolingual or bilingual language code.
        force_inline: Reserved for future per-call overrides. Currently has
            no effect — the inline ``"~/~"`` separator is always used in
            bilingual mode.

    Returns:
        A TeX-friendly translated string.
    """
    _ = force_inline  # accepted but not currently distinguished
    if is_bilingual_lang(lang):
        primary, secondary = Translator(lang).t_pair(key)
        return f"{primary}~/~{secondary}"
    return t(key, lang)


def t_csv(key: str, lang: str) -> str:
    """CSV-safe variant of :func:`t`.

    In bilingual mode this returns *only* the primary language's translation
    — joining two languages with a separator inside a CSV cell tends to
    confuse readers and tooling. In monolingual mode the behavior is
    identical to :func:`t`.

    Args:
        key: The translation key to look up.
        lang: A monolingual or bilingual language code.

    Returns:
        A label suitable for use as a CSV column header or cell value.
    """
    parsed = parse_bilingual_lang(lang)
    if parsed is not None:
        primary_lang, _secondary_lang = parsed
        return t(key, primary_lang)
    return t(key, lang)
