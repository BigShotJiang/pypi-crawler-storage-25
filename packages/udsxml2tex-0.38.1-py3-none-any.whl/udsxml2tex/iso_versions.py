"""ISO 14229-1 standard-version-aware NRC and SID/sub-function tables.

Different revisions of ISO 14229-1 (2006, 2013, 2020) define different
sets of services, sub-functions, and Negative Response Codes. This module
exposes the per-version data + a `filter_spec_by_iso_version()` helper
that drops items the chosen standard does not include and reports them
as warnings.

Public API:
    SUPPORTED_ISO_VERSIONS = ("2006", "2013", "2020")
    iso_nrcs(version)        -> dict[int, str]
    iso_sub_functions(version, sid) -> dict[int, str]
    iso_services(version)    -> set[int]
    filter_spec_by_iso_version(spec, version, *, mode='warn') -> list[str]
"""

from __future__ import annotations

from typing import Any

SUPPORTED_ISO_VERSIONS: tuple[str, ...] = ("2006", "2013", "2020")
DEFAULT_ISO_VERSION = "2020"


# ---- Service set per version ------------------------------------------------
# Subset only — services added or modified across revisions. Carried-over
# services (e.g. 0x10 DiagnosticSessionControl) are listed once and shared.

# Services that exist in ALL listed versions
_BASE_SERVICES = frozenset({
    0x10, 0x11, 0x14, 0x19, 0x22, 0x23, 0x24, 0x27, 0x28, 0x2A,
    0x2C, 0x2E, 0x2F, 0x31, 0x34, 0x35, 0x36, 0x37, 0x38,
    0x3D, 0x3E, 0x83, 0x84, 0x85, 0x86, 0x87,
})

_SERVICES_BY_VERSION: dict[str, frozenset[int]] = {
    # ISO 14229-1:2006 — Authentication (0x29) was added in 2020
    "2006": _BASE_SERVICES,
    # ISO 14229-1:2013 — adds nothing service-id-wise vs 2006
    "2013": _BASE_SERVICES,
    # ISO 14229-1:2020 — adds Authentication (0x29) and SecuredDataTransmission
    # response handling refinements; 0x84 SecuredDataTransmission was already
    # present in earlier versions.
    "2020": _BASE_SERVICES | {0x29},
}


# ---- NRC sets per version ---------------------------------------------------
# Format: {nrc_code: short_name}. `_NRC_BASE_2006` is the foundation;
# 2013/2020 layer additions on top.

_NRC_BASE_2006: dict[int, str] = {
    0x10: "generalReject",
    0x11: "serviceNotSupported",
    0x12: "subFunctionNotSupported",
    0x13: "incorrectMessageLengthOrInvalidFormat",
    0x14: "responseTooLong",
    0x21: "busyRepeatRequest",
    0x22: "conditionsNotCorrect",
    0x24: "requestSequenceError",
    0x31: "requestOutOfRange",
    0x33: "securityAccessDenied",
    0x35: "invalidKey",
    0x36: "exceededNumberOfAttempts",
    0x37: "requiredTimeDelayNotExpired",
    0x70: "uploadDownloadNotAccepted",
    0x71: "transferDataSuspended",
    0x72: "generalProgrammingFailure",
    0x73: "wrongBlockSequenceCounter",
    0x78: "requestCorrectlyReceivedResponsePending",
    0x7E: "subFunctionNotSupportedInActiveSession",
    0x7F: "serviceNotSupportedInActiveSession",
}

_NRC_ADDED_2013: dict[int, str] = {
    0x25: "noResponseFromSubnetComponent",
    0x26: "failurePreventsExecutionOfRequestedAction",
    0x81: "rpmTooHigh",
    0x82: "rpmTooLow",
    0x83: "engineIsRunning",
    0x84: "engineIsNotRunning",
    0x85: "engineRunTimeTooLow",
    0x86: "temperatureTooHigh",
    0x87: "temperatureTooLow",
    0x88: "vehicleSpeedTooHigh",
    0x89: "vehicleSpeedTooLow",
    0x8A: "throttle/PedalTooHigh",
    0x8B: "throttle/PedalTooLow",
    0x8C: "transmissionRangeNotInNeutral",
    0x8D: "transmissionRangeNotInGear",
    0x8F: "brakeSwitch(es)NotClosed",
    0x90: "shifterLeverNotInPark",
    0x91: "torqueConverterClutchLocked",
    0x92: "voltageTooHigh",
    0x93: "voltageTooLow",
}

# 2020 adds Authentication-related NRCs and a couple of clarifications.
_NRC_ADDED_2020: dict[int, str] = {
    0x34: "authenticationRequired",       # ISO 14229-1:2020 §9.6
    0x50: "certificateVerificationFailed-InvalidTimePeriod",
    0x51: "certificateVerificationFailed-InvalidSignature",
    0x52: "certificateVerificationFailed-InvalidChainOfTrust",
    0x53: "certificateVerificationFailed-InvalidType",
    0x54: "certificateVerificationFailed-InvalidFormat",
    0x55: "certificateVerificationFailed-InvalidContent",
    0x56: "certificateVerificationFailed-InvalidScope",
    0x57: "certificateVerificationFailed-InvalidCertificate",
    0x58: "ownershipVerificationFailed",
    0x59: "challengeCalculationFailed",
    0x5A: "settingAccessRightsFailed",
    0x5B: "sessionKeyCreation/DerivationFailed",
    0x5C: "configurationDataUsageFailed",
    0x5D: "deAuthenticationFailed",
}

_NRCS_BY_VERSION: dict[str, dict[int, str]] = {
    "2006": dict(_NRC_BASE_2006),
    "2013": {**_NRC_BASE_2006, **_NRC_ADDED_2013},
    "2020": {**_NRC_BASE_2006, **_NRC_ADDED_2013, **_NRC_ADDED_2020},
}


# ---- Sub-function additions for ReadDTCInformation (0x19) -------------------
# 2020 expanded 0x19 to 24 sub-functions; 2013 had a smaller set.

_SID19_2006: dict[int, str] = {
    0x01: "reportNumberOfDTCByStatusMask",
    0x02: "reportDTCByStatusMask",
    0x03: "reportDTCSnapshotIdentification",
    0x04: "reportDTCSnapshotRecordByDTCNumber",
    0x05: "reportDTCStoredDataByRecordNumber",
    0x06: "reportDTCExtDataRecordByDTCNumber",
    0x07: "reportNumberOfDTCBySeverityMaskRecord",
    0x08: "reportDTCBySeverityMaskRecord",
    0x09: "reportSeverityInformationOfDTC",
    0x0A: "reportSupportedDTC",
    0x0B: "reportFirstTestFailedDTC",
    0x0C: "reportFirstConfirmedDTC",
    0x0D: "reportMostRecentTestFailedDTC",
    0x0E: "reportMostRecentConfirmedDTC",
    0x0F: "reportMirrorMemoryDTCByStatusMask",
    0x10: "reportMirrorMemoryDTCExtDataRecordByDTCNumber",
    0x11: "reportNumberOfMirrorMemoryDTCByStatusMask",
    0x12: "reportNumberOfEmissionsRelatedOBDDTCByStatusMask",
    0x13: "reportEmissionsRelatedOBDDTCByStatusMask",
    0x14: "reportDTCFaultDetectionCounter",
    0x15: "reportDTCWithPermanentStatus",
}

_SID19_ADDED_2020: dict[int, str] = {
    0x16: "reportDTCExtDataRecordByRecordNumber",
    0x17: "reportUserDefMemoryDTCByStatusMask",
    0x18: "reportUserDefMemoryDTCSnapshotRecordByDTCNumber",
    0x19: "reportUserDefMemoryDTCExtDataRecordByDTCNumber",
    0x1A: "reportSupportedDTCExtDataRecord",
    0x42: "reportWWHOBDDTCByMaskRecord",
    0x55: "reportWWHOBDDTCWithPermanentStatus",
    0x56: "reportDTCInformationByDTCReadinessGroupIdentifier",
}

_SUB_FUNCTIONS_BY_VERSION_AND_SID: dict[str, dict[int, dict[int, str]]] = {
    "2006": {0x19: dict(_SID19_2006)},
    "2013": {0x19: dict(_SID19_2006)},
    "2020": {0x19: {**_SID19_2006, **_SID19_ADDED_2020}},
}


# ---- Public API -------------------------------------------------------------

def iso_nrcs(version: str) -> dict[int, str]:
    """Return the {code: name} NRC table for the given ISO 14229-1 version."""
    if version not in _NRCS_BY_VERSION:
        raise ValueError(
            f"Unsupported ISO version: {version!r}. "
            f"Supported: {SUPPORTED_ISO_VERSIONS}"
        )
    return dict(_NRCS_BY_VERSION[version])


def iso_services(version: str) -> frozenset[int]:
    """Return the set of service IDs defined in the given ISO 14229-1 version."""
    if version not in _SERVICES_BY_VERSION:
        raise ValueError(
            f"Unsupported ISO version: {version!r}. "
            f"Supported: {SUPPORTED_ISO_VERSIONS}"
        )
    return _SERVICES_BY_VERSION[version]


def iso_sub_functions(version: str, sid: int) -> dict[int, str]:
    """Return {sub_function_id: name} for the given ISO version and SID.

    Returns an empty dict if no version-specific sub-function data is tracked
    for that SID (the spec parser then falls back to whatever the ARXML
    declares).
    """
    if version not in _SUB_FUNCTIONS_BY_VERSION_AND_SID:
        raise ValueError(
            f"Unsupported ISO version: {version!r}. "
            f"Supported: {SUPPORTED_ISO_VERSIONS}"
        )
    return dict(_SUB_FUNCTIONS_BY_VERSION_AND_SID[version].get(sid, {}))


def filter_spec_by_iso_version(
    spec: Any, version: str, *, mode: str = "warn"
) -> list[str]:
    """Drop spec entries the chosen ISO version does not define.

    Args:
        spec: Parsed UdsSpecification (mutated in place).
        version: One of '2006', '2013', '2020'.
        mode: 'warn' (default) — log warnings, do not modify spec.
              'strict' — drop unsupported entries from the spec.

    Returns:
        List of human-readable strings describing each filtered/flagged item,
        suitable for logging or report inclusion.
    """
    if version not in SUPPORTED_ISO_VERSIONS:
        raise ValueError(
            f"Unsupported ISO version: {version!r}. "
            f"Supported: {SUPPORTED_ISO_VERSIONS}"
        )

    allowed_sids = iso_services(version)
    allowed_nrcs = iso_nrcs(version)

    notes: list[str] = []

    # Services
    services = list(getattr(spec, "services", []) or [])
    keep_services = []
    for svc in services:
        if svc.service_id in allowed_sids:
            keep_services.append(svc)
            continue
        notes.append(
            f"SID 0x{svc.service_id:02X} ({svc.short_name}) is not defined "
            f"in ISO 14229-1:{version}"
        )
    if mode == "strict":
        spec.services = keep_services

    # NRCs (per service)
    for svc in keep_services if mode == "strict" else services:
        if svc.service_id not in allowed_sids:
            continue
        kept_nrcs = []
        for nrc in (svc.nrc_list or []):
            if nrc.nrc_code in allowed_nrcs:
                kept_nrcs.append(nrc)
                continue
            notes.append(
                f"NRC 0x{nrc.nrc_code:02X} on SID 0x{svc.service_id:02X} "
                f"is not defined in ISO 14229-1:{version}"
            )
        if mode == "strict":
            svc.nrc_list = kept_nrcs

    # Sub-functions for ReadDTCInformation 0x19
    for svc in keep_services if mode == "strict" else services:
        if svc.service_id != 0x19:
            continue
        sf_table = iso_sub_functions(version, 0x19)
        if not sf_table:
            continue
        kept_sfs = []
        for sf in (svc.sub_functions or []):
            if sf.sub_function_id in sf_table:
                kept_sfs.append(sf)
                continue
            notes.append(
                f"Sub-function 0x{sf.sub_function_id:02X} on SID 0x19 "
                f"is not defined in ISO 14229-1:{version}"
            )
        if mode == "strict":
            svc.sub_functions = kept_sfs

    return notes
