# Vigil Python SDK

Send logs, traces, and metrics to a running Vigil server from Python.

## Install

From PyPI:

```sh
pip install vigil-observability
```

From this repository during development:

```sh
pip install -e sdk/python
```

## Configure

Run `vigil init` in your app directory first. It writes the SDK environment values to `.env`:

```env
VIGIL_BASE_URL=http://localhost:8080
VIGIL_PROJECT_ID=proj_...
VIGIL_INGEST_KEY=vigil_...
```

Load those values into your process, then create a client:

```python
from vigil_sdk import VigilClient

vigil = VigilClient.from_env()
```

## Send Events

```python
vigil.log("request.completed", message="request completed", attrs={"route": "/health"})

vigil.trace(
    "llm.completed",
    trace_id="trace-123",
    span_id="span-1",
    attrs={"total_tokens": 42, "cost_usd": 0.0021},
)

vigil.metric("queue.depth", value=7, unit="count", attrs={"queue": "jobs"})
```

Use `VigilClient(base_url=..., project_id=..., ingest_key=...)` if you do not want to configure through environment variables.