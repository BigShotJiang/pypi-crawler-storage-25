import requests

# Change this to your Render URL after deployment
BASE_URL = "https://xhline.vercel.app"

def read(prompt):
    try:
        r = requests.post(f"{BASE_URL}/generate", json={"prompt": prompt})
        return r.json().get("code", "# No code found")
    except Exception as e:
        return f"# Error: {e}"
