# sbenchmark-dependency-test-one

Minimal library exposing three functions:

- `name() -> str`
- `version_number() -> str`
- `version() -> str`

## Usage

```python
from sbenchmark_dependency_test_one import name, version_number, version

print(name())          # "sbenchmark-dependency-test-one"
print(version_number()) # "1.0.4"
print(version())       # "sbenchmark-dependency-test-one,1.0.4"
