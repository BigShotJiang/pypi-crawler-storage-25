"""Cocodex release scenario tests."""
