Here is the complete, first-principles mathematical formulation of **Mixed Hamiltonian Monte Carlo (M-HMC)**. 

This formulation assumes a generalized model containing both continuous variables and non-binary categorical variables.

### 1. The Target and the Hybrid State Space
We want to sample from a joint probability distribution over continuous variables $c \in \mathbb{R}^{D_c}$ and discrete categorical variables $x \in \{1, \dots, K\}^{D_x}$.
The target distribution is:
$$ P(c, x) \propto \exp(-U(c, x)) $$
where $U(c, x)$ is the potential energy.

To simulate this using Hamiltonian mechanics, M-HMC creates a **hybrid continuous-discrete state space**. We introduce three new components:
1.  **Continuous Momenta for $c$**: $v_c \in \mathbb{R}^{D_c}$, drawn from a Gaussian prior $\mathcal{N}(0, I)$.
2.  **Continuous "Clocks" for $x$**: $z \in [0, \tau]^{D_x}$, one independent clock for each discrete variable, drawn from a Uniform prior over a torus (a circle of circumference $\tau$).
3.  **Laplace Momenta for $z$**: $v_z \in \mathbb{R}^{D_x}$, drawn from a Laplace prior $\text{Laplace}(0, 1)$.

The total Hamiltonian (Energy) of this augmented system is:
$$ H(c, x, z, v_c, v_z) = U(c, x) + \frac{1}{2}v_c^T v_c + \sum_{i=1}^{D_x} |v_{z,i}| $$

Notice that **$z$ is absent from the Hamiltonian**. Because the prior on $z$ is uniform, it contributes $0$ potential energy.

### 2. The Physics Between Alarms
Because $H$ is fully defined, we can derive the continuous equations of motion using standard Hamiltonian gradients.

**For the continuous variables ($c$):**
*   Velocity: $\frac{dc}{dt} = \nabla_{v_c} H = v_c$
*   Acceleration: $\frac{dv_c}{dt} = -\nabla_c H = -\nabla_c U(c, x)$
*(This is standard continuous HMC. $c$ glides smoothly through space, pulled by the gradient).*

**For the discrete variables ($x$) and their clocks ($z$):**
*   Clock Velocity: $\frac{dz}{dt} = \nabla_{v_z} H = \text{sign}(v_z)$
*   Clock Acceleration: $\frac{dv_z}{dt} = -\nabla_z H = 0$
*(Because $z$ has no gradient, the clocks tick constantly at a locked speed of $\pm 1$. The discrete state $x$ does not change between alarms).*

### 3. The Boundary (The Alarm)
The clock variable $z_i$ lives on a torus $[0, \tau]$. When $z_i$ hits $0$ or $\tau$, an "alarm" goes off.
At this exact moment, we attempt to change the discrete state $x_i$ using a user-defined proposal distribution $Q(\tilde{x}_i \mid x_i)$ (e.g., uniformly picking a new category).

If we jump from $x_i$ to $\tilde{x}_i$, the potential energy of the system will instantly jump. To cross the boundary, the clock's kinetic energy ($|v_z|$) must pay the toll:
$$ \Delta U_i = U(c, x_{\text{new}}) - U(c, x_{\text{old}}) + \log \frac{Q(x_{i, \text{old}} \mid \tilde{x}_{i, \text{new}})}{Q(\tilde{x}_{i, \text{new}} \mid x_{i, \text{old}})} $$
$$ |v_{z, i, \text{new}}| = |v_{z, i, \text{old}}| - \Delta U_i $$

*   **Refraction (Accept)**: If $|v_{z,i}| > \Delta U_i$, the toll is paid. $x_i$ is updated to $\tilde{x}_i$. The clock wraps around the torus ($0 \to \tau$, or $\tau \to 0$) and continues ticking in the same direction.
*   **Reflection (Reject)**: If $|v_{z,i}| \le \Delta U_i$, the toll cannot be paid. $x_i$ remains unchanged. The clock bounces off the boundary ($v_{z,i} \leftarrow -v_{z,i}$) and ticks backward.

### 4. The Mixed HMC Leapfrog Algorithm
Because the clock speeds are permanently locked at $\pm 1$ and are entirely unaffected by the continuous variable $c$, **we know exactly when every alarm will go off before the step even begins**. 

Given the current state $(c, x, z, v_c, v_z)$ and step size $\epsilon$:

**Phase A: Upfront Vectorized Event Calculation**
1.  For all dimensions $i \in \{1 \dots D_x\}$, calculate the time until the alarm:
    *   If $v_{z,i} > 0$: $t_i = \tau - z_i$
    *   If $v_{z,i} < 0$: $t_i = z_i$
2.  Filter for alarms that will ring during this step ($t_i \le \epsilon$).
3.  Sort these events chronologically into an event queue: $E = [(t_1, j_1), (t_2, j_2), \dots]$.

**Phase B: The Leapfrog Integration**
1.  **Half-Step Momentum:** $v_c \leftarrow v_c - \frac{\epsilon}{2} \nabla_c U(c, x)$
2.  **Position Integration with Interrupts:**
    *   Set $t_{\text{current}} = 0$.
    *   **For each** event $(t_{\text{event}}, j)$ in $E$:
        *   Calculate time elapsed since last stop: $\delta t = t_{\text{event}} - t_{\text{current}}$
        *   Advance continuous positions: $c \leftarrow c + \delta t \cdot v_c$
        *   Advance all clocks: $z \leftarrow z + \delta t \cdot \text{sign}(v_z)$
        *   **Process the Alarm for $x_j$:**
            *   Sample proposal $\tilde{x}_j \sim Q(\cdot \mid x_j)$
            *   Calculate $\Delta U_j$ at the *exact current continuous position* $c$.
            *   **If** $|v_{z,j}| > \Delta U_j$ **(Refract):**
                *   $x_j \leftarrow \tilde{x}_j$
                *   $v_{z,j} \leftarrow \text{sign}(v_{z,j}) \big(|v_{z,j}| - \Delta U_j\big)$
                *   $z_j \leftarrow (\tau - z_j)$ *(Wrap around torus)*
            *   **Else (Reflect):**
                *   $v_{z,j} \leftarrow -v_{z,j}$
        *   Update $t_{\text{current}} = t_{\text{event}}$
    *   Advance remaining time: $\delta t = \epsilon - t_{\text{current}}$
    *   $c \leftarrow c + \delta t \cdot v_c$
    *   $z \leftarrow z + \delta t \cdot \text{sign}(v_z)$
3.  **Half-Step Momentum:** $v_c \leftarrow v_c - \frac{\epsilon}{2} \nabla_c U(c, x)$

**Phase C: Final Accept/Reject**
After $L$ leapfrog steps, apply a standard Metropolis-Hastings check on the total hybrid Hamiltonian $H(c, x, z, v_c, v_z)$ to correct for $\epsilon$ discretization errors in the continuous $c$ variables.

### The Grand Conclusion
By treating the discrete problem as a Piecewise Deterministic Markov Process (where gradient-free continuous clocks trigger discrete jumps), Mixed HMC completely eliminates the need for "exact continuous embeddings" or numerical root-finding [^1]. 

You calculate all collision times instantly in Phase A. The only reason Phase B has a loop is to ensure that when variable $x_j$ evaluates its energy jump $\Delta U_j$, the continuous variable $c$ has moved to the exact correct position for that split second in time.

[^1]: [How to build a Metropolis-Within-Gibbs sampler? - GitHub Pages](https://blackjax-devs.github.io/blackjax/examples/howto_metropolis_within_gibbs.html) (100%)