**2026.04.20:** Fix vfor bug, add unicode DAG printing, bump to 0.0.3.

**2026.04.15:** Published to PyPi. Start version numbering at 0.0.1, bump to 0.0.2.

**2026.03.30:** Add `vfor` as an alternative to `vmap`.

**2026.03.17:** Jax backend and blackjax now support auto-constrained continuous variables

**2026.03.11:** Rename "autoregressive" to more sensible "scan".

**2026.01.06:** Bump Python requirement to 3.12, make VMap, Composite, Autoregressive generic for your OCD `x: RV[AutoRegressive[Composite[VMap[Normal]]]]` type-hinting pleasure.

**2025.12.22:** Much less magical scalar Op generation in IR and somewhat less magical scalar function generation in interface.

**2025.12.18:** Add Wishart

**2025.12.16:** Improve typing + API docs, clear interface+docs for user-configuration of broadcasting 

**2025.12.12:** Update API docs to use Sphinx, be somewhat less chaotic.

**2025.12.05:** Update Pangolin logo (h/t Bob), update demos, update install instructions.

**2025.10.31:** Add experimental Torch backend

**2025.10.24:** Drop NumPyro (NumPyro is too unstable), replace with Blackjax backend. Create options for no / simple / numpy style broadcasting.

**2025.08.01:** Add notebooks demonstrating IR and interface.

**2025.07.31:** Various cleanup, improve printing.

**2024.10.25:** Deploy auto-generated API docs.

**2024.10.25:** Try to prevent users from using Loop variables are part of slices. (Throw a meaningful exception instead of just failing.)

**2024.10.16:** Fix bug introduced by previous update. (Old commit re-used plate names between different variables, which (apparently) has serious consequences in NumPyro.)

**2024.10.15:** Revamped NumPyro backend to try to deal better with discrete variables. Now, vmap uses `numpyro.plate` where possible. (Which it often isn't due to limitations in how NumPyro works.)  