"""Format inbound Lyriel dispatches as human-readable text + push them
into wherever the user is talking to Hermes.

Two surface modes, tried in this order:

  1. **CLI mode** — `ctx.inject_message(text, "user")` drops the
     formatted dispatch into the active CLI conversation. If the agent
     is mid-turn the message interrupts; if idle it queues as the next
     input. Either way the next thing the user sees is the surfaced
     dispatch. Returns False (logs nothing) when not in CLI mode, so
     this is safe to attempt unconditionally.

  2. **Gateway / Telegram mode** — falls through to `_send_to_platform`
     against the gateway's configured Telegram adapter. Inherits
     chunking + UTF-16 length safety + the user's existing bot
     connection (no second bot to create).

If neither surface works (CLI agent not running AND Telegram not
configured), the dispatch is logged as skipped. The inbox poll still
claims it from Lyriel (preventing pile-up server-side); the user can
re-fetch the response state via the `lyriel_reply` tool's diagnostic
output or directly via the API.

Chat ID resolution (Telegram path only):
  1. plugins.entries.lyriel.telegram_chat_id in ~/.hermes/config.yaml
  2. gateway.telegram.home_chat_id (Hermes's main home chat)
"""

from __future__ import annotations

import logging
import re
from typing import Any

logger = logging.getLogger(__name__)


# Sealed-envelope parsers — match the templates in
# web/src/lib/server/agents/prompt.ts so we extract the salient bits
# rather than dumping the whole multi-paragraph prompt on the user.
_RE_INITIATOR = re.compile(
    r"This message is NOT from your human — it is from\s+(.+?)'s agent",
    re.DOTALL,
)
_RE_ASK_TEXT = re.compile(r'The ask:\s*"""\s*(.+?)\s*"""', re.DOTALL)
_RE_RESPONSE_TEXT = re.compile(
    r'agent has responded:\s*"""\s*(.+?)\s*"""', re.DOTALL
)
_RE_ORIGINAL_PROMPT = re.compile(
    r'on behalf of your human \(@\S+\):\s*"""\s*(.+?)\s*"""', re.DOTALL
)
_RE_RECIPIENT_NAME = re.compile(r"(.+?)'s agent has responded")

# Plan envelope parsers
_RE_PLAN_INITIATOR = re.compile(r"plan initiated by\s+(.+?)'s agent", re.DOTALL)
_RE_PLAN_DESCRIPTION = re.compile(r'THE PLAN:\s*"""\s*(.+?)\s*"""', re.DOTALL)
_RE_PLAN_PARTICIPANTS = re.compile(r"PARTICIPANTS \(\d+ agents[^)]*\):\s*\n(.+?)\n\n", re.DOTALL)
_RE_PLAN_CONVERSATION = re.compile(
    r"CONVERSATION SO FAR:\s*\n+(.+?)\n+WHAT TO DO RIGHT NOW", re.DOTALL
)
_RE_PLAN_LOCKED_SUMMARY = re.compile(r'LOCKED OUTCOME:\s*"""\s*(.+?)\s*"""', re.DOTALL)
_RE_PLAN_LOCKED_PROPOSER = re.compile(r"locked\. (.+?)'s agent proposed it", re.DOTALL)


def format_dispatch(d: dict[str, Any]) -> str:
    """Render a dispatch as the Telegram message body to send the user."""
    direction = d.get("direction", "?")
    ask_id = d.get("ask_id", "?")
    plan_id = d.get("plan_id")
    prompt = d.get("prompt", "") or ""

    if direction == "plan" and plan_id:
        return _format_plan_dispatch(plan_id, prompt)

    if direction == "dispatch":
        sender_m = _RE_INITIATOR.search(prompt)
        sender = sender_m.group(1).strip() if sender_m else "someone"
        ask_m = _RE_ASK_TEXT.search(prompt)
        ask_text = ask_m.group(1).strip() if ask_m else "<could not parse ask>"
        return (
            f"🪶 Lyriel ask from {sender}:\n\n"
            f'"{ask_text}"\n\n'
            f"To reply, say something like: "
            f"reply to Lyriel ask {ask_id} with <your response>"
        )

    if direction == "forward":
        resp_m = _RE_RESPONSE_TEXT.search(prompt)
        resp_text = resp_m.group(1).strip() if resp_m else "<could not parse response>"
        original_m = _RE_ORIGINAL_PROMPT.search(prompt)
        original = original_m.group(1).strip() if original_m else "<your earlier ask>"
        sender_m = _RE_RECIPIENT_NAME.search(prompt)
        sender = sender_m.group(1).strip() if sender_m else "someone"
        return (
            f"🪶 Lyriel reply from {sender}:\n\n"
            f'(in reply to: "{original}")\n\n'
            f"{resp_text}"
        )

    return f"🪶 Lyriel: {direction}\n{prompt[:500]}"


def _format_plan_dispatch(plan_id: str, prompt: str) -> str:
    """Format a plan envelope (initial / message / locked) into a single
    surface message for the user. We deliberately surface the FULL plan
    context (description, participants, current conversation) on every
    round so the user — and the LLM that's about to respond on their
    behalf — sees the whole state without polling.
    """
    is_locked = "[Lyriel group plan — LOCKED]" in prompt
    is_initial = "[Lyriel group plan — round 1" in prompt

    desc_m = _RE_PLAN_DESCRIPTION.search(prompt)
    description = desc_m.group(1).strip() if desc_m else "<could not parse plan>"

    parts_m = _RE_PLAN_PARTICIPANTS.search(prompt)
    participants = parts_m.group(1).strip() if parts_m else "<participants unknown>"

    if is_locked:
        summary_m = _RE_PLAN_LOCKED_SUMMARY.search(prompt)
        summary = summary_m.group(1).strip() if summary_m else "<could not parse outcome>"
        proposer_m = _RE_PLAN_LOCKED_PROPOSER.search(prompt)
        proposer = proposer_m.group(1).strip() if proposer_m else "someone"
        return (
            f"🪶 Lyriel group plan LOCKED (plan_id {plan_id})\n\n"
            f'Plan: "{description}"\n\n'
            f"Outcome (proposed by {proposer}):\n"
            f"  → {summary}\n\n"
            f"Participants: {participants}\n\n"
            f"This is final. No further responses needed."
        )

    if is_initial:
        initiator_m = _RE_PLAN_INITIATOR.search(prompt)
        initiator = initiator_m.group(1).strip() if initiator_m else "someone"
        return (
            f"🪶 Lyriel group plan from {initiator} (plan_id {plan_id})\n\n"
            f'Plan: "{description}"\n\n'
            f"Participants: {participants}\n\n"
            f"Round 1 — your agent is being asked to contribute. To reply, "
            f"say something like: 'reply to Lyriel plan {plan_id} saying "
            f"<your thoughts/constraints>'. To skip this round, say: "
            f"'stay silent on plan {plan_id}'."
        )

    # plan_message (refinement round)
    conv_m = _RE_PLAN_CONVERSATION.search(prompt)
    conversation = conv_m.group(1).strip() if conv_m else "<conversation unavailable>"
    return (
        f"🪶 Lyriel plan update (plan_id {plan_id})\n\n"
        f'Plan: "{description}"\n\n'
        f"Conversation so far:\n{conversation}\n\n"
        f"Refinement round — respond if you have something new to add. "
        f"To reply: 'reply to Lyriel plan {plan_id} saying <your update>'. "
        f"To pass: 'stay silent on plan {plan_id}'."
    )


def resolve_telegram_chat_id() -> str | None:
    """Read the Telegram chat id Lyriel surfaces into. Returns None when
    nothing is configured (callers should log + skip).
    """
    try:
        from hermes_cli.config import cfg_get, load_config
    except ImportError:
        logger.warning("hermes_cli.config not importable; can't resolve chat id")
        return None

    cfg = load_config()
    chat_id = cfg_get(cfg, "plugins", "entries", "lyriel", "telegram_chat_id")
    if not chat_id:
        chat_id = cfg_get(cfg, "gateway", "telegram", "home_chat_id")
    if chat_id is None:
        return None
    return str(chat_id)


def surface_to_cli(ctx, text: str) -> bool:
    """Queue the dispatch text as the user's NEXT input in the CLI
    conversation. The current in-flight turn (if any) completes first;
    the dispatch is processed as a fresh turn after.

    We deliberately bypass `ctx.inject_message(...)` because its
    "interrupt mid-turn if agent is running" semantic produces a
    surprising ordering for our use case: when the user types "ping
    @lyriel saying yo", the plugin's poll loop can claim the welcome
    forward (system_responder is in-process, ~500ms round trip) BEFORE
    Hermes finishes rendering "Ping sent." The interrupt then surfaces
    the reply before the ack, which looks backwards from the user's
    perspective.

    Writing directly to `_pending_input` preserves the natural ordering:
      1. User typed input is processed (tool call, ack rendered)
      2. Turn finishes, agent returns to idle
      3. Pending input from this function is consumed as the next turn
      4. Dispatch is surfaced as a fresh agent turn

    Returns True if the message was queued (CLI mode), False if the
    plugin is running under the gateway (no _cli_ref). Safe from any
    thread — `_pending_input` is a thread-safe queue.
    """
    try:
        cli = ctx._manager._cli_ref
    except AttributeError:
        logger.debug("PluginContext shape doesn't expose _cli_ref; not CLI mode")
        return False
    if cli is None:
        return False
    try:
        cli._pending_input.put(text)
        return True
    except Exception as e:  # noqa: BLE001
        logger.error("could not queue surface text to CLI: %s", e)
        return False


def send_telegram(chat_id: str, text: str) -> None:
    """Push `text` to Telegram chat `chat_id` via Hermes's gateway pipeline.

    Uses `_send_to_platform` so we inherit chunking + length safety. Runs the
    coroutine via `model_tools._run_async` which handles sync/async bridging
    correctly whether we're in a worker thread, the main thread, or inside
    an already-running loop.

    On failure, logs and swallows — surfacing is best-effort; we'd rather
    drop one Telegram message than crash the poll loop.
    """
    try:
        from gateway.config import Platform, load_gateway_config
        from model_tools import _run_async
        from tools.send_message_tool import _send_to_platform
    except ImportError as e:
        logger.error("Hermes gateway internals not importable: %s", e)
        return

    try:
        gw_cfg = load_gateway_config()
    except Exception as e:  # noqa: BLE001
        logger.error("load_gateway_config failed: %s", e)
        return

    pconfig = gw_cfg.platforms.get(Platform.TELEGRAM)
    if not pconfig or not pconfig.enabled:
        logger.warning(
            "Telegram platform not configured in gateway; skipping Lyriel surface"
        )
        return

    try:
        result = _run_async(
            _send_to_platform(Platform.TELEGRAM, pconfig, chat_id, text)
        )
        if isinstance(result, dict) and result.get("error"):
            logger.warning("Lyriel Telegram send returned error: %s", result["error"])
    except Exception as e:  # noqa: BLE001
        logger.error("Lyriel Telegram send raised: %s", e)
