"""Background poll loop: long-polls Lyriel /api/inbox, surfaces each
dispatch into wherever the user is talking to Hermes (CLI conversation
via inject_message, OR Telegram via the gateway send pipeline), and
remembers callback tokens for the LLM's reply tool.

Runs on a daemon thread spawned from `register(ctx)`. The captured
PluginContext is used for the CLI surface path; the Telegram chat id
comes from config (resolved lazily so a config change doesn't require
a restart for the chat lookup itself, though chat-config changes still
need a restart to be visible to the surfacing code on next dispatch).
"""

from __future__ import annotations

import logging
import threading
import time

from . import api, pending, surfacing

logger = logging.getLogger(__name__)

_RECONNECT_BACKOFF_S = 5
_INBOX_TIMEOUT_S = 30
_POLL_INTERVAL_AFTER_BATCH = 0.5  # the GET above already long-polled


def _poll_forever(ctx) -> None:
    """Main poll loop. ctx is the PluginContext captured at register()."""
    logger.info("lyriel inbox poll loop started (base=%s)", api.base_url())

    while True:
        try:
            dispatches = api.long_poll_inbox(timeout=_INBOX_TIMEOUT_S)
        except api.LyrielApiError as e:
            logger.warning("inbox poll error: %s", e)
            time.sleep(_RECONNECT_BACKOFF_S)
            continue
        except Exception as e:  # noqa: BLE001
            logger.warning("inbox poll unexpected error: %s", e)
            time.sleep(_RECONNECT_BACKOFF_S)
            continue

        for d in dispatches:
            ask_id = d.get("ask_id")
            plan_id = d.get("plan_id")
            direction = d.get("direction", "?")
            prompt_text = d.get("prompt", "") or ""
            correlation = plan_id or ask_id or "?"

            # Remember the callback BEFORE surfacing so the LLM tool can
            # find it even if the surface call races.
            if direction == "dispatch" and ask_id:
                if not pending.remember(ask_id, prompt_text):
                    logger.warning(
                        "could not extract callback URL/token for ask %s — "
                        "user replies via the LLM tool will fail",
                        ask_id,
                    )

            if direction == "plan" and plan_id:
                if not pending.remember_plan(plan_id, prompt_text):
                    # Plans go through multiple rounds; if it's a terminal
                    # locked envelope, there's no callback to extract and
                    # this is expected. Only warn on non-locked envelopes.
                    is_locked = "[Lyriel group plan — LOCKED]" in prompt_text
                    if not is_locked:
                        logger.warning(
                            "could not extract callback for plan %s — "
                            "user contributions via the LLM tool will fail",
                            plan_id,
                        )
                    else:
                        # Plan locked — drop any prior pending entry.
                        pending.forget_plan(plan_id)

            # Synchronous-completion suppression: if the lyriel_send_ask
            # tool already inlined this ask's response into its own tool
            # result (system_responder case — @lyriel responds instantly),
            # the user has already seen the reply via the LLM's
            # confirmation turn. Skip surfacing to avoid duplicate.
            if direction == "forward" and ask_id and pending.was_absorbed(ask_id):
                logger.info(
                    "skipped forward ask_id=%s (already absorbed by tool)",
                    ask_id,
                )
                continue

            surface_text = surfacing.format_dispatch(d)

            # Try CLI surface first. inject_message returns True iff the
            # plugin is running under a CLI session (not under the
            # gateway). Cheap to attempt either way.
            cli_ok = surfacing.surface_to_cli(ctx, surface_text)

            if cli_ok:
                logger.info(
                    "surfaced %s id=%s via CLI inject_message",
                    direction,
                    correlation,
                )
                continue

            # Not in CLI mode — try Telegram via the gateway's adapter.
            chat_id = surfacing.resolve_telegram_chat_id()
            if not chat_id:
                logger.warning(
                    "no surface available for %s id=%s — neither "
                    "CLI inject_message nor a configured Telegram chat. "
                    "Dispatch claimed from Lyriel but user won't see it "
                    "until they query manually.",
                    direction,
                    correlation,
                )
                continue

            try:
                surfacing.send_telegram(chat_id, surface_text)
                logger.info(
                    "surfaced %s id=%s via Telegram chat %s",
                    direction,
                    correlation,
                    chat_id,
                )
            except Exception as e:  # noqa: BLE001
                logger.error(
                    "surfacing dispatch %s via Telegram failed: %s",
                    correlation,
                    e,
                )

        # If the GET already long-polled but returned empty, loop straight
        # back. If it returned data, brief pause so we batch tightly without
        # tight-looping a hot CPU.
        if dispatches:
            time.sleep(_POLL_INTERVAL_AFTER_BATCH)


def start(ctx) -> threading.Thread:
    """Spawn the poll loop on a daemon thread. Caller (register) holds
    a reference if it wants to introspect; the thread is daemon so the
    Hermes process can exit cleanly without joining.
    """
    t = threading.Thread(
        target=_poll_forever,
        args=(ctx,),
        daemon=True,
        name="lyriel-inbox",
    )
    t.start()
    return t
