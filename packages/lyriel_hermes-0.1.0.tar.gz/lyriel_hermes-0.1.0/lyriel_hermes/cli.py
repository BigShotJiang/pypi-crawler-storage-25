"""Console script: `lyriel-hermes`.

Subcommands:
  lyriel-hermes install [--copy] [--target PATH]
      Symlink (default) or copy the installed lyriel_hermes package
      into ~/.hermes/plugins/lyriel/ so Hermes discovers it on next
      boot. Idempotent — overwrites any existing entry at that path.

  lyriel-hermes uninstall
      Remove ~/.hermes/plugins/lyriel/.

  lyriel-hermes path
      Print the absolute path of the installed lyriel_hermes package
      (useful for debugging or manual symlinks).

The wire-up Hermes expects:
  ~/.hermes/plugins/lyriel/
      __init__.py     — defines register(ctx)
      plugin.yaml     — Hermes-side metadata (name, kind, tools, env)
      *.py            — implementation modules

Symlink is default because reinstalling the pip package (`pip install
--upgrade lyriel-hermes`) then transparently updates the plugin —
no need to re-run `lyriel-hermes install`. Copy mode is the fallback
for environments where symlinks aren't supported.
"""

from __future__ import annotations

import argparse
import os
import shutil
import sys
from pathlib import Path


HERMES_PLUGINS_DIR = Path.home() / ".hermes" / "plugins"
PLUGIN_NAME = "lyriel"


def _package_root() -> Path:
    """Absolute path to the installed lyriel_hermes package directory."""
    return Path(__file__).resolve().parent


def _resolve_target(target: str | None) -> Path:
    if target:
        return Path(target).expanduser().resolve()
    return HERMES_PLUGINS_DIR / PLUGIN_NAME


def cmd_install(args: argparse.Namespace) -> int:
    src = _package_root()
    dst = _resolve_target(args.target)

    dst.parent.mkdir(parents=True, exist_ok=True)

    if dst.exists() or dst.is_symlink():
        if dst.is_symlink():
            dst.unlink()
        elif dst.is_dir():
            shutil.rmtree(dst)
        else:
            dst.unlink()

    if args.copy:
        shutil.copytree(src, dst)
        mode = "copied"
    else:
        try:
            os.symlink(src, dst, target_is_directory=True)
            mode = "symlinked"
        except OSError as e:
            print(
                f"lyriel-hermes: symlink failed ({e}); falling back to copy.",
                file=sys.stderr,
            )
            shutil.copytree(src, dst)
            mode = "copied"

    print(f"Lyriel plugin {mode} to {dst}.")
    print("Enable it in ~/.hermes/config.yaml under plugins.enabled, then")
    print("restart Hermes. The plugin reads LYRIEL_API_KEY from the env.")
    return 0


def cmd_uninstall(_: argparse.Namespace) -> int:
    dst = HERMES_PLUGINS_DIR / PLUGIN_NAME
    if not dst.exists() and not dst.is_symlink():
        print(f"Lyriel plugin not installed at {dst}.")
        return 0
    if dst.is_symlink():
        dst.unlink()
    elif dst.is_dir():
        shutil.rmtree(dst)
    else:
        dst.unlink()
    print(f"Lyriel plugin removed from {dst}.")
    return 0


def cmd_path(_: argparse.Namespace) -> int:
    print(_package_root())
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="lyriel-hermes",
        description="Install / uninstall the Lyriel plugin for Hermes.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_install = sub.add_parser("install", help="Wire the plugin into Hermes.")
    p_install.add_argument(
        "--copy",
        action="store_true",
        help="Copy files instead of symlinking (use if symlinks aren't supported).",
    )
    p_install.add_argument(
        "--target",
        default=None,
        help=f"Override install path (default: {HERMES_PLUGINS_DIR / PLUGIN_NAME}).",
    )
    p_install.set_defaults(func=cmd_install)

    p_uninstall = sub.add_parser("uninstall", help="Remove the plugin from Hermes.")
    p_uninstall.set_defaults(func=cmd_uninstall)

    p_path = sub.add_parser("path", help="Print the installed package path.")
    p_path.set_defaults(func=cmd_path)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
