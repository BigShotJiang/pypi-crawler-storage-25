"""Two LLM tools the Lyriel plugin exposes:

  lyriel_send_ask(to, prompt)
      Initiate a new ask. POSTs /api/asks. Returns the ask_id so the
      LLM can mention it to the user; the response will arrive later
      as an inbound 'forward' dispatch (surfaced into Telegram by the
      poll loop, no further action required by the LLM).

  lyriel_reply(ask_id, response)
      Reply to a pending inbound ask. Looks up the callback URL +
      token from the in-process pending map (populated by the poll
      loop when it surfaced the original dispatch), POSTs the
      callback, returns success/failure.

Schemas follow OpenAI function-calling shape, matching Hermes's
existing convention (see plugins/google_meet/tools.py for examples).

Handlers return JSON-encoded strings. Errors are returned as
{"error": "..."} rather than raising — Hermes's tool dispatch surfaces
the JSON content back to the LLM, which can then explain the failure
to the user.
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any
from urllib import error as urllib_error
from urllib import request as urllib_request

from . import api, pending
from .primer import SUBSTRATE_PRIMER

logger = logging.getLogger(__name__)

# Synchronous-completion absorption window. When the ask is to an
# in-process system agent (today: @lyriel), the response is written
# to the ask row BEFORE POST /api/asks returns. We do a brief poll on
# GET /api/asks/:id after the POST so the response shows up inline in
# the LLM's tool result, AND we mark the ask "absorbed" so the inbox
# poll's forward-surface path skips the duplicate.
#
# 2.5 seconds at 250ms intervals = 10 attempts. Generous for in-process
# completion; short enough that real cross-user asks (which take
# seconds to minutes) fall through to the normal "dispatched, reply
# arrives later" path without delaying the user's tool call meaningfully.
_ABSORB_WINDOW_S = 2.5
_ABSORB_POLL_INTERVAL_S = 0.25


LYRIEL_SEND_ASK_SCHEMA: dict[str, Any] = {
    "name": "lyriel_send_ask",
    # The substrate primer is prepended here so it loads into the LLM's
    # bound-tool context. Tool-specific instructions follow after a
    # blank line. The other Lyriel tools have shorter, tool-specific
    # descriptions; the primer in this one description is enough to
    # frame the whole toolset.
    "description": (
        SUBSTRATE_PRIMER
        + "\n\n"
        + "Tool — send a 1:1 ask. Use this when your user wants to ping "
        "exactly one other Lyriel user by handle. Returns an ask_id; the "
        "recipient's response arrives later as a 'reply' dispatch in the "
        "inbox, surfaced into this chat automatically — you do not need "
        "to poll. For multi-party coordination, use lyriel_plan_send "
        "instead."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "to": {
                "type": "string",
                "description": (
                    "Recipient's Lyriel handle, with or without leading @. "
                    "Examples: 'noor', '@charlie', 'lyriel' (for the system "
                    "welcome agent)."
                ),
            },
            "prompt": {
                "type": "string",
                "description": (
                    "The message body to send. Plain text. The recipient's "
                    "agent will surface this to their human."
                ),
            },
        },
        "required": ["to", "prompt"],
    },
}


LYRIEL_REPLY_SCHEMA: dict[str, Any] = {
    "name": "lyriel_reply",
    "description": (
        "Reply to a pending inbound Lyriel ask. Use this when the user "
        "wants to respond to a Lyriel ask that was previously surfaced "
        "into the chat (you'll see a message like '🪶 Lyriel ask from X' "
        "with an ask_id). The ask_id is a UUID shown in the surface "
        "message — extract it exactly. If the user replies without "
        "naming a specific ask_id and there's only one pending, use "
        "that one."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "ask_id": {
                "type": "string",
                "description": "The UUID of the pending ask to reply to.",
            },
            "response": {
                "type": "string",
                "description": "The user's reply, paraphrased or verbatim.",
            },
        },
        "required": ["ask_id", "response"],
    },
}


def handle_lyriel_send_ask(args: dict[str, Any], **_kwargs: Any) -> str:
    to = (args.get("to") or "").strip()
    prompt = (args.get("prompt") or "").strip()
    if not to or not prompt:
        return json.dumps({"error": "Both 'to' and 'prompt' are required"})

    try:
        result = api.send_ask(to=to, prompt=prompt)
    except api.LyrielApiError as e:
        return json.dumps({"error": str(e), "status": e.status})
    except Exception as e:  # noqa: BLE001
        logger.exception("lyriel_send_ask unexpected failure")
        return json.dumps({"error": f"unexpected error: {e}"})

    ask_id = result.get("ask_id", "?")

    # Synchronous-completion absorption. If the ask completed before POST
    # /api/asks returned (system_responder case — @lyriel responds inline),
    # inline the response in the tool result so the LLM's confirmation turn
    # naturally surfaces it instead of arriving after the inbox-poll
    # surface. Also mark the ask absorbed so the poll loop skips the
    # duplicate when it claims the forward.
    absorbed = _absorb_if_quick(ask_id)
    if absorbed is not None:
        pending.mark_absorbed(ask_id)
        return json.dumps(
            {
                "success": True,
                "ask_id": ask_id,
                "recipient": result.get("recipient", to),
                "status": "completed",
                "completed_inline": True,
                "response": absorbed,
                "note": (
                    f"{to} responded instantly (in-process system agent). "
                    f"The response is inlined below. Summarize or paraphrase "
                    f"the response to the user — do NOT also wait for a "
                    f"separate Lyriel reply message; the response is the "
                    f"whole thing."
                ),
            }
        )

    return json.dumps(
        {
            "success": True,
            "ask_id": ask_id,
            "recipient": result.get("recipient", to),
            "status": result.get("status", "dispatched"),
            "note": (
                f"Ask dispatched to {to}. The recipient's reply will arrive "
                f"in this chat as a 🪶 Lyriel reply (ask_id {ask_id}) when "
                f"their agent responds. Acknowledge briefly — do NOT promise "
                f"or paraphrase the reply yourself; the surfacing layer will "
                f"deliver it directly when it lands."
            ),
        }
    )


def _absorb_if_quick(ask_id: str) -> str | None:
    """Poll GET /api/asks/:id for up to ~2.5s. If the ask reaches
    status='completed' within the window, return the response text.
    None otherwise (the ask is still in flight; let the regular
    inbox poll surface the reply when it arrives).

    Uses urllib directly (not api.py) so we don't need a new client
    method just for this auxiliary endpoint.
    """
    url = f"{api.base_url()}/api/asks/{ask_id}"
    deadline = time.time() + _ABSORB_WINDOW_S
    headers = {"authorization": f"Bearer {api.api_key()}"}

    while time.time() < deadline:
        try:
            req = urllib_request.Request(url, headers=headers, method="GET")
            with urllib_request.urlopen(req, timeout=2) as resp:
                if resp.status != 200:
                    return None
                body = resp.read().decode("utf-8")
        except (urllib_error.URLError, urllib_error.HTTPError) as e:
            logger.debug("_absorb_if_quick GET failed: %s", e)
            return None
        except Exception as e:  # noqa: BLE001
            logger.debug("_absorb_if_quick unexpected: %s", e)
            return None

        try:
            data = json.loads(body)
        except json.JSONDecodeError:
            return None

        if data.get("status") == "completed":
            response_text = data.get("response")
            if isinstance(response_text, str) and response_text:
                return response_text
            return None
        if data.get("status") == "failed":
            return None
        # status='dispatched' — keep polling until deadline
        time.sleep(_ABSORB_POLL_INTERVAL_S)

    return None


LYRIEL_PLAN_SEND_SCHEMA: dict[str, Any] = {
    "name": "lyriel_plan_send",
    "description": (
        "Start a group plan through Lyriel. Each participant's agent will "
        "negotiate on their human's behalf to converge on an outcome (e.g. "
        "a dinner spot, a meeting time, an option set everyone agrees to). "
        "Use this when the user wants to coordinate something across "
        "multiple verified Lyriel handles — NOT for single 1:1 asks "
        "(use lyriel_send_ask for those). Returns a plan_id; further "
        "rounds arrive in this chat as 🪶 Lyriel plan updates."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "participants": {
                "type": "array",
                "items": {"type": "string"},
                "description": (
                    "Lyriel handles of the OTHER participants (not the user "
                    "themselves — they're added automatically as initiator). "
                    "Each may be with or without leading @. Examples: "
                    "['noor', '@maya']."
                ),
            },
            "description": {
                "type": "string",
                "description": (
                    "Free-form description of what the group is coordinating. "
                    "Include constraints the user already knows (e.g. "
                    "'dinner next Thursday or Friday, low-key, near "
                    "Mission'). Be specific — every participant's agent "
                    "reads this verbatim."
                ),
            },
            "max_messages": {
                "type": "integer",
                "description": (
                    "Optional cap on conversation length (default 20). "
                    "If the agents can't converge within this many turns, "
                    "the plan auto-fails."
                ),
            },
        },
        "required": ["participants", "description"],
    },
}


LYRIEL_PLAN_REPLY_SCHEMA: dict[str, Any] = {
    "name": "lyriel_plan_reply",
    "description": (
        "Contribute to an ongoing Lyriel group plan. Use when the user has "
        "received a 🪶 Lyriel plan message and wants to add their context "
        "(availability, preferences, constraints, proposed times, etc.) "
        "to the group conversation. To explicitly opt out of a round "
        "without adding anything, pass stay_silent=true."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "plan_id": {
                "type": "string",
                "description": "The plan_id shown in the surface message.",
            },
            "content": {
                "type": "string",
                "description": (
                    "The user's contribution to the plan conversation. "
                    "Speak as the user's agent representing them — "
                    "include the constraints/preferences/context the "
                    "user shared. Pass empty string if stay_silent=true."
                ),
            },
            "stay_silent": {
                "type": "boolean",
                "description": (
                    "Set to true to opt out of this round without adding "
                    "anything. Lets the plan progress without blocking on "
                    "this participant. Default false."
                ),
            },
        },
        "required": ["plan_id", "content"],
    },
}


LYRIEL_PLAN_LOCK_SCHEMA: dict[str, Any] = {
    "name": "lyriel_plan_lock",
    "description": (
        "Lock a Lyriel group plan with a final outcome. Only the plan's "
        "initiator can lock (Lyriel will return 403 otherwise). Use when "
        "the user (as initiator) wants to declare the plan resolved — "
        "the locked outcome is broadcast as a terminal message to every "
        "participant's agent, who then surfaces it to their human."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "plan_id": {
                "type": "string",
                "description": "The plan_id to lock.",
            },
            "summary": {
                "type": "string",
                "description": (
                    "Short, human-readable description of the locked "
                    "outcome (e.g. 'Thursday 7pm at Mission Cantina', "
                    "'Tuesday 11am, video, 30min'). This is what every "
                    "participant's agent will surface to their human."
                ),
            },
        },
        "required": ["plan_id", "summary"],
    },
}


def handle_lyriel_plan_send(args: dict[str, Any], **_kwargs: Any) -> str:
    participants = args.get("participants") or []
    description = (args.get("description") or "").strip()
    max_messages = args.get("max_messages")
    if not participants or not description:
        return json.dumps({"error": "Both 'participants' and 'description' are required"})
    if not isinstance(participants, list) or not all(isinstance(p, str) for p in participants):
        return json.dumps({"error": "'participants' must be a list of strings"})

    try:
        result = api.send_plan(
            participants=participants,
            description=description,
            max_messages=int(max_messages) if max_messages else None,
        )
    except api.LyrielApiError as e:
        return json.dumps({"error": str(e), "status": e.status})
    except Exception as e:  # noqa: BLE001
        logger.exception("lyriel_plan_send unexpected failure")
        return json.dumps({"error": f"unexpected error: {e}"})

    plan_id = result.get("plan_id", "?")
    return json.dumps(
        {
            "success": True,
            "plan_id": plan_id,
            "participants": result.get("participants", []),
            "status": result.get("status", "open"),
            "note": (
                f"Group plan {plan_id} broadcast to participants. Their "
                f"agents will negotiate. Refinement updates and the final "
                f"locked outcome will arrive in this chat as 🪶 Lyriel "
                f"plan updates — acknowledge briefly and let the user "
                f"know they'll see progress as it comes in. When the "
                f"user wants to lock the plan with a final decision, use "
                f"lyriel_plan_lock with that summary."
            ),
        }
    )


def handle_lyriel_plan_reply(args: dict[str, Any], **_kwargs: Any) -> str:
    plan_id = (args.get("plan_id") or "").strip()
    content = (args.get("content") or "").strip()
    stay_silent = bool(args.get("stay_silent", False))
    if not plan_id:
        return json.dumps({"error": "'plan_id' is required"})
    if not stay_silent and not content:
        return json.dumps({"error": "'content' is required unless stay_silent=true"})

    entry = pending.take_plan(plan_id)
    if not entry:
        snapshot = pending.list_pending_plans()
        if not snapshot:
            return json.dumps(
                {
                    "error": (
                        f"No pending plan callbacks. plan_id={plan_id} either "
                        f"already had a contribution sent this round, OR the "
                        f"plan locked, OR the envelope wasn't received. "
                        f"Check for a 🪶 Lyriel plan update in the chat."
                    )
                }
            )
        return json.dumps(
            {
                "error": (
                    f"No pending callback for plan {plan_id}. Currently "
                    f"pending plans: {list(snapshot.keys())}"
                ),
                "pending_plan_ids": list(snapshot.keys()),
            }
        )

    try:
        result = api.send_plan_callback(
            callback_url=entry.callback_url,
            callback_token=entry.callback_token,
            content=content,
            stay_silent=stay_silent,
        )
    except api.LyrielApiError as e:
        # Put it back so the user can retry if it was a transient failure.
        pending._pending_plans[plan_id] = entry  # noqa: SLF001
        return json.dumps({"error": str(e), "status": e.status, "retryable": True})
    except Exception as e:  # noqa: BLE001
        pending._pending_plans[plan_id] = entry  # noqa: SLF001
        logger.exception("lyriel_plan_reply unexpected failure")
        return json.dumps({"error": f"unexpected error: {e}", "retryable": True})

    return json.dumps(
        {
            "success": True,
            "plan_id": plan_id,
            "silent": stay_silent,
            "note": (
                "Contribution sent. The other participants' agents will "
                "now consider it in their next response. Acknowledge "
                "briefly — further refinement rounds and the locked "
                "outcome will arrive as 🪶 Lyriel plan updates."
            ),
        }
    )


def handle_lyriel_plan_lock(args: dict[str, Any], **_kwargs: Any) -> str:
    plan_id = (args.get("plan_id") or "").strip()
    summary = (args.get("summary") or "").strip()
    if not plan_id or not summary:
        return json.dumps({"error": "Both 'plan_id' and 'summary' are required"})

    try:
        result = api.lock_plan(plan_id=plan_id, summary=summary)
    except api.LyrielApiError as e:
        return json.dumps({"error": str(e), "status": e.status})
    except Exception as e:  # noqa: BLE001
        logger.exception("lyriel_plan_lock unexpected failure")
        return json.dumps({"error": f"unexpected error: {e}"})

    pending.forget_plan(plan_id)
    return json.dumps(
        {
            "success": True,
            "plan_id": plan_id,
            "status": result.get("status", "locked"),
            "locked_at": result.get("locked_at"),
            "note": (
                f"Plan {plan_id} locked: {summary}. Every participant's "
                f"agent has been notified and will surface the final "
                f"outcome to their human."
            ),
        }
    )


def handle_lyriel_reply(args: dict[str, Any], **_kwargs: Any) -> str:
    ask_id = (args.get("ask_id") or "").strip()
    response = (args.get("response") or "").strip()
    if not ask_id or not response:
        return json.dumps({"error": "Both 'ask_id' and 'response' are required"})

    entry = pending.take(ask_id)
    if not entry:
        snapshot = pending.list_pending()
        if not snapshot:
            return json.dumps(
                {
                    "error": (
                        f"No pending Lyriel asks. ask_id={ask_id} either "
                        f"already had a reply sent OR was never received "
                        f"(check the chat for a surface message)."
                    )
                }
            )
        return json.dumps(
            {
                "error": (
                    f"No pending ask with id {ask_id}. Currently pending: "
                    f"{list(snapshot.keys())}"
                ),
                "pending_ids": list(snapshot.keys()),
            }
        )

    try:
        result = api.send_callback(
            callback_url=entry.callback_url,
            callback_token=entry.callback_token,
            response=response,
        )
    except api.LyrielApiError as e:
        # Put it back so the user can retry.
        pending.restore(ask_id, entry)
        return json.dumps({"error": str(e), "status": e.status, "retryable": True})
    except Exception as e:  # noqa: BLE001
        pending.restore(ask_id, entry)
        logger.exception("lyriel_reply unexpected failure")
        return json.dumps({"error": f"unexpected error: {e}", "retryable": True})

    return json.dumps(
        {
            "success": True,
            "ask_id": ask_id,
            "callback_status": result.get("status", "ok"),
            "idempotent": result.get("idempotent", False),
            "note": "Reply sent through Lyriel.",
        }
    )
