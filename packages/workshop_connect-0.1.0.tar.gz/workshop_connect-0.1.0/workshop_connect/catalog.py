"""Catalog loader for workshop-connect.

Loads ``_catalog.json`` (shipped with the package) and provides
lookup helpers used by the CLI and SDK.
"""

from __future__ import annotations

import json
import sys
from importlib.resources import files
from pathlib import Path
from typing import Any

from .errors import CatalogError


def _resolve_catalog_path() -> Path:
    """Resolve ``_catalog.json``, handling bundled/frozen executables."""
    # importlib.resources works in both standard and bundled Python.
    try:
        ref = files("workshop_connect").joinpath("_catalog.json")
        p = Path(str(ref))
        if p.is_file():
            return p
    except (TypeError, FileNotFoundError):
        pass

    # Fallback: __file__-relative (dev, editable installs).
    p = Path(__file__).parent / "_catalog.json"
    if p.is_file():
        return p

    # Last resort for frozen/bundled executables (sys._MEIPASS).
    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        p = Path(meipass) / "workshop_connect" / "_catalog.json"
        if p.is_file():
            return p

    return Path(__file__).parent / "_catalog.json"  # let load_catalog raise


_CATALOG_PATH = _resolve_catalog_path()

_catalog_cache: dict[str, Any] | None = None


def load_catalog(path: Path | None = None) -> dict[str, Any]:
    """Load and cache the action catalog.

    Returns
    -------
    dict
        Full catalog with ``version`` and ``toolkits`` keys.
    """
    global _catalog_cache
    if _catalog_cache is not None:
        return _catalog_cache

    p = path or _CATALOG_PATH
    if not p.is_file():
        raise CatalogError(
            f"Catalog not found at {p}. "
            "Ensure the package was installed correctly."
        )
    result: dict[str, Any] = json.loads(p.read_text(encoding="utf-8"))
    _catalog_cache = result
    return result


def get_toolkit(slug: str) -> dict[str, Any]:
    """Get a single toolkit entry by slug."""
    catalog = load_catalog()
    toolkits = catalog.get("toolkits", {})
    # Try exact match, then with hyphens→underscores
    normalized = slug.lower().replace("-", "_")
    for key, val in toolkits.items():
        if key == normalized or key.replace("-", "_") == normalized:
            result: dict[str, Any] = val
            return result
    raise CatalogError(
        f"Toolkit {slug!r} not found in catalog. "
        f"Available: {', '.join(sorted(toolkits.keys()))}"
    )


def get_action(toolkit_slug: str, action_name: str) -> dict[str, str]:
    """Get a specific action from a toolkit."""
    tk = get_toolkit(toolkit_slug)
    name_upper = action_name.upper()
    for action in tk.get("actions", []):
        if action["name"] == name_upper:
            result: dict[str, str] = action
            return result
    available = [a["name"] for a in tk.get("actions", [])]
    raise CatalogError(
        f"Action {action_name!r} not found in toolkit {toolkit_slug!r}. "
        f"Available: {', '.join(available[:10])}{'...' if len(available) > 10 else ''}"
    )


def list_toolkits() -> list[dict[str, Any]]:
    """Return summary of all toolkits."""
    catalog = load_catalog()
    result = []
    for slug, tk in sorted(catalog.get("toolkits", {}).items()):
        result.append(
            {
                "slug": slug,
                "toolkit": tk.get("toolkit", slug),
                "actions": len(tk.get("actions", [])),
                "triggers": len(tk.get("triggers", [])),
            }
        )
    return result
