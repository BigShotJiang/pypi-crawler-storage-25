import numpy as np

class DotDict(dict):
    """dot.notation access to dictionary attributes"""

    __getattr__ = dict.get
    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__

    def __getstate__(self):
        return self.__dict__

    def __setstate__(self, d):
        return self.__dict__.update(d)

# Return dictionary containing MPI and layout information for use with hdfio and 
# pympiutils functions
def make_mpi_info(n, MPI, isGlobal=True):
  # Collective
  if MPI is not None:
     mpiinfo=DotDict()
     mpiinfo.MPI=MPI
     comm = MPI.COMM_WORLD
     mpiinfo.comm=comm
     mpiinfo.rank=comm.Get_rank()
     mpiinfo.size=comm.Get_size()
     if isGlobal:
       mpiinfo.layout=generate_mpi_layout(nglob=n, nprocs=mpiinfo.size, MPI=MPI)
     else:
       mpiinfo.layout=generate_mpi_layout(nloc=n, MPI=MPI)
  else:
    mpiinfo=None

  return mpiinfo

# Create a dictionary containing layout (partitioning) information
def generate_mpi_layout(nglob=None, nprocs=None, nlocal_sizes=None, nloc=None, MPI=None):
  if MPI is not None:
    comm = MPI.COMM_WORLD
    rank = comm.Get_rank()
    size = comm.Get_size()

  if (nloc is not None) and (MPI is not None):
    sz=np.array([nloc],dtype=int)
    szg=np.empty(size,dtype=int)
    comm.Barrier()
    comm.Allgather([sz, MPI.INT], [szg, MPI.INT])
    if np.sum(szg)>0:
      section_sizes,displ=generate_mpi_layout(nlocal_sizes=szg)
      comm.Barrier()
      layout=DotDict()
      layout.n=np.sum(section_sizes)
      layout.nloc=nloc
      layout.nlocal_sizes=section_sizes
      layout.displ=displ
    else:
      layout=None
    return layout
  elif nlocal_sizes is not None:
    section_sizes=nlocal_sizes
    displ=np.insert(np.cumsum(section_sizes),0,0)[0:-1]
    if MPI is not None:
      layout=DotDict()
      layout.n=np.sum(section_sizes)
      layout.nloc=section_sizes[rank]
      layout.nlocal_sizes=section_sizes
      layout.displ=displ
      return layout
    else:
      return section_sizes, displ
  elif (nglob is not None) and (nprocs is not None):
    if nglob>0:
      quotient, remainder = divmod(nglob, nprocs)
      section_sizes = (
                     remainder * [quotient+1] +
                     (nprocs - remainder) * [quotient])
      displ=np.insert(np.cumsum(section_sizes),0,0)[0:-1]
      if MPI is not None:
        layout=DotDict()
        layout.n=np.sum(section_sizes)
        layout.nloc=section_sizes[rank]
        layout.nlocal_sizes=section_sizes
        layout.displ=displ
        return layout
      else:
        return section_sizes, displ
    else:
      layout=None
      return layout
  else:
    layout=None
    return layout

# layout should be a dictionary containing n, nloc, nlocal_sizes, displ
def xglob2loc(xg,layout=None, MPI=None):
# Collective
# Note: We cannot check if xg is None to return xl=None because xg=None is a valid 
# input for rank != 0. Hopefully, checking layout below will catch the situation when 
# xg really is None.
  if layout is not None and MPI is not None:
    comm = MPI.COMM_WORLD
    rank = comm.Get_rank()
    size = comm.Get_size()
    if rank==0 and xg is None:
      raise RuntimeError("ERROR: xg is None on rank 0. We should not have reached this point!")
    xl = np.zeros(layout.nloc)
    # Scatter global xg to local xl
    comm.Barrier()
    comm.Scatterv([xg,layout.nlocal_sizes,layout.displ,MPI.DOUBLE],xl)
    comm.Barrier()
  else:
    xl=xg
  return xl

def xloc2glob(xl,layout=None, MPI=None):
# Collective
  if layout is not None and MPI is not None:
    comm = MPI.COMM_WORLD
    rank = comm.Get_rank()
    size = comm.Get_size()
    if xl is None:
      raise RuntimeError("ERROR: xl is None. We should not have reached this point!")
    if rank==0:
      xg = np.zeros(layout.n)
    else:
      xg = None
    # Gather the local xl's to the root rank
    comm.Barrier()
    comm.Gatherv(xl,[xg,layout.nlocal_sizes,layout.displ,MPI.DOUBLE])
    comm.Barrier()
  else:
    xg=xl
  return xg

def norm(x,mpi=None):
  if mpi is None:
    return np.sqrt(np.dot(x,x)) # linalg.norm(x)
  else:
    dotl = np.dot(x,x)
    mpi.comm.Barrier()
    dotg=mpi.comm.allreduce(dotl, op=mpi.MPI.SUM)
    return np.sqrt(dotg)

def dot(x,y,mpi=None):
  if mpi is None:
    return np.dot(x,y)
  else:
    dotl = np.dot(x,y)
    mpi.comm.Barrier()
    dotg=mpi.comm.allreduce(dotl, op=mpi.MPI.SUM)
    return dotg

def multtranspose(A,x,mpi=None):
# y = A^T x = (x^T A)^T
  if mpi is None:
    y = np.matmul(x.transpose(),A).transpose()
    return y
  else:
    n=A.shape[1] # number of columns
    y=np.zeros(n) # output vector
    for j in range(n):
      dotl = np.dot(x,A[:,j])
      mpi.comm.Barrier()
      y[j]=mpi.comm.allreduce(dotl, op=mpi.MPI.SUM)
      mpi.comm.Barrier()
    return y

def mmin(x,mpi=None):
  if mpi is None:
    return np.min(x)
  else:
    minl = np.min(x)
    mpi.comm.Barrier()
    ming=mpi.comm.allreduce(minl, op=mpi.MPI.MIN)
    return ming

def mmax(x,mpi=None):
  if mpi is None:
    return np.max(x)
  else:
    maxl = np.max(x)
    mpi.comm.Barrier()
    maxg=mpi.comm.allreduce(maxl, op=mpi.MPI.MAX)
    return maxg

def many(x,mpi=None):
  if mpi is None:
    return np.any(x)
  else:
    anyl = np.any(x)
    mpi.comm.Barrier()
    anyg=mpi.comm.allreduce(anyl, op=mpi.MPI.LOR)
    return anyg

def mallclose(x, y, rtol=1e-05, atol=1e-08, equal_nan=False, mpi=None):
  if mpi is None:
    return np.allclose(x, y, rtol=rtol, atol=atol, equal_nan=equal_nan)
  else:
    allclosel = np.allclose(x, y, rtol=rtol, atol=atol, equal_nan=equal_nan)
    mpi.comm.Barrier()
    allcloseg=mpi.comm.allreduce(allclosel, op=mpi.MPI.LAND)
    return allcloseg
