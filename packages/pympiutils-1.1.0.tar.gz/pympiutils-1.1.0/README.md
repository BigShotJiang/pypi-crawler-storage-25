This repository contains parallelized versions of some common NumPy functions and high-level wrapper functions for scatter/gather operations on NumPy arrays. Parallelization is performed with MPI via [`mpi4py`](https://mpi4py.readthedocs.io/). The functions are specifically designed to work with my [`pyioutils`](https://github.com/samarkhatiwala/pyioutils), [`tmm4py`](https://github.com/samarkhatiwala/tmm) and [`AndersonAcceleration`](https://github.com/samarkhatiwala/AndersonAcceleration) packages, but they can be more generally applied.

**IMPORTANT**: Please do NOT post this code on your own github or other website. See LICENSE.txt for licensing information.

Feel free to email if you have any questions: <samkat6@gmail.com>

------------------------------------------------------------------------------------------------

**Installation**

```bash
pip install pympiutils
```
**Usage**

See the examples/ directory for how to use this code.