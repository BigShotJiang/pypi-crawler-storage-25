"""Demo output renderers."""
