"""Built-in demo scenarios."""
