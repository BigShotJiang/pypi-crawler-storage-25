"""Demo mode handlers."""
