#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author: qicongsheng
import json
from urllib.parse import urlencode

import requests
from knify import dateutil
from knify import listutil
from knify import logger
from knify import objutil
from requests.auth import HTTPBasicAuth

from forex_mcp import constant
from forex_mcp.models import Ohlc


def _normalize_date(date_str):
    return date_str.replace('-', '').replace(' ', '').replace(':', '')


def get_symbols():
    try:
        url = f'{constant.MT5_API_DOMAIN}{constant.MT5_API_GET_SYMBOLS_URL}'
        logger.info(url)
        resp = requests.get(url, auth=HTTPBasicAuth(constant.MT5_API_USER, constant.MT5_API_PASSWD), timeout=60 * 5)
        return [objutil.dic_to_obj(symbol) for symbol in json.loads(resp.text)]
    except:
        return get_symbols()


def copy_rates_from(symbol, time_frame, date_from, count):
    try:
        date_from = _normalize_date(date_from)
        date_from = dateutil.str_to_date(date_from, dateutil.FORMAT_YYMMDDHMS)
        date_from = dateutil.add_hours(date_from, 8)
        date_from = dateutil.date_to_str(date_from, dateutil.FORMAT_YYMMDDHMS_STRICT)
        params = urlencode({"symbol": symbol, "time_frame": time_frame, "date_from": date_from, "count": count})
        url = f'{constant.MT5_API_DOMAIN}{constant.MT5_API_COPY_RATES_FROM_URL}?{params}'
        logger.info(url)
        resp = requests.get(url, auth=HTTPBasicAuth(constant.MT5_API_USER, constant.MT5_API_PASSWD), timeout=60 * 5)
        return [objutil.dic_to_obj(ohlc, Ohlc()) for ohlc in json.loads(resp.text)]
    except:
        return copy_rates_from(symbol, time_frame, date_from, count)


def copy_rates_range(symbol, time_frame, date_from, date_to):
    try:
        date_from = _normalize_date(date_from)
        date_from = dateutil.str_to_date(date_from, dateutil.FORMAT_YYMMDDHMS)
        date_from = dateutil.add_hours(date_from, 8)
        date_from = dateutil.date_to_str(date_from, dateutil.FORMAT_YYMMDDHMS_STRICT)
        date_to = _normalize_date(date_to)
        date_to = dateutil.str_to_date(date_to, dateutil.FORMAT_YYMMDDHMS)
        date_to = dateutil.add_hours(date_to, 8)
        date_to = dateutil.date_to_str(date_to, dateutil.FORMAT_YYMMDDHMS_STRICT)
        params = urlencode({"symbol": symbol, "time_frame": time_frame, "date_from": date_from, "date_to": date_to})
        url = f'{constant.MT5_API_DOMAIN}{constant.MT5_API_COPY_RATES_RANGE_URL}?{params}'
        logger.info(url)
        resp = requests.get(url, auth=HTTPBasicAuth(constant.MT5_API_USER, constant.MT5_API_PASSWD), timeout=60 * 5)
        return [objutil.dic_to_obj(ohlc, Ohlc()) for ohlc in json.loads(resp.text)]
    except:
        return copy_rates_range(symbol, time_frame, date_from, date_to)


def get_all_bars(symbol, time_frame):
    params = urlencode({"symbol": symbol, "time_frame": time_frame})
    url = f'{constant.MT5_API_DOMAIN}{constant.MT5_API_GET_ALL_BARS_URL}?{params}'
    logger.info(url)
    resp = requests.get(url, auth=HTTPBasicAuth(constant.MT5_API_USER, constant.MT5_API_PASSWD), timeout=60 * 5)
    return [objutil.dic_to_obj(ohlc, Ohlc()) for ohlc in json.loads(resp.text)]


def get_min_date(symbol, time_frame):
    try:
        date_from = '1970060100000'
        date_to = '1970120100000'
        params = urlencode({"symbol": symbol, "time_frame": time_frame, "date_from": date_from, "date_to": date_to})
        url = f'{constant.MT5_API_DOMAIN}{constant.MT5_API_COPY_RATES_RANGE_URL}?{params}'
        logger.info(url)
        resp = requests.get(url, auth=HTTPBasicAuth(constant.MT5_API_USER, constant.MT5_API_PASSWD), timeout=60 * 5)
        return listutil.find_first(json.loads(resp.text))['bar_time']
    except:
        return get_min_date(symbol, time_frame)
