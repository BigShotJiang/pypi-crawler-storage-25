#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author: qicongsheng
import argparse
import os

from forex_mcp.mcp_server import create_mcp


def main():
    parser = argparse.ArgumentParser(description="Forex MCP Server")
    parser.add_argument("--host", type=str, default=os.getenv("HOST", "0.0.0.0"), help="Server host (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=int(os.getenv("PORT", "3000")), help="Server port (default: 3000)")
    parser.add_argument("--mt5-api-user", type=str, default=os.getenv("MT5_API_USER", "admin"), help="MT5 API username")
    parser.add_argument("--mt5-api-password", type=str, default=os.getenv("MT5_API_PASSWORD", "password"), help="MT5 API password")
    parser.add_argument("--mt5-api-domain", type=str, default=os.getenv("MT5_API_DOMAIN", "http://124.221.161.150:8082"), help="MT5 API domain URL")
    parser.add_argument("--transport", type=str, default=os.getenv("TRANSPORT", "streamable-http"), choices=["sse", "streamable-http", "stdio"], help="Transport protocol (default: streamable-http)")
    args = parser.parse_args()

    os.environ["HOST"] = args.host
    os.environ["PORT"] = str(args.port)
    os.environ["MT5_API_USER"] = args.mt5_api_user
    os.environ["MT5_API_PASSWORD"] = args.mt5_api_password
    os.environ["MT5_API_DOMAIN"] = args.mt5_api_domain

    mcp = create_mcp()
    mcp.run(transport=args.transport)


if __name__ == "__main__":
    main()
