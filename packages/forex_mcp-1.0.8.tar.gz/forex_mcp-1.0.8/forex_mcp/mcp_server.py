#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author: qicongsheng
import os

from mcp.server.fastmcp import FastMCP

from forex_mcp import http_api


def create_mcp():
    mcp = FastMCP(
        name="forex",
        host=os.environ.get("HOST", "0.0.0.0"),
        port=int(os.environ.get("PORT", "3000")),
    )

    @mcp.tool(description="Get available forex symbol list. Returns symbols with symbol_name, min_point, comment, status.")
    def get_symbols() -> list[dict]:
        symbols = http_api.get_symbols()
        return [s.__dict__ for s in symbols]

    @mcp.tool(description="Get N bars of OHLC data starting from a given date. time_frame options: M1, M5, M15, M30, H1, H4, D1, W1, MN1. date_from format: YYYYMMDDHHmmss or YYYY-MM-DD HH:mm:ss")
    def copy_rates_from(symbol: str, time_frame: str, date_from: str, count: int) -> list[dict]:
        bars = http_api.copy_rates_from(symbol, time_frame, date_from, count)
        return [b.__dict__ for b in bars]

    @mcp.tool(description="Get OHLC bars within a date range. time_frame options: M1, M5, M15, M30, H1, H4, D1, W1, MN1. date_from and date_to format: YYYYMMDDHHmmss or YYYY-MM-DD HH:mm:ss")
    def copy_rates_range(symbol: str, time_frame: str, date_from: str, date_to: str) -> list[dict]:
        bars = http_api.copy_rates_range(symbol, time_frame, date_from, date_to)
        return [b.__dict__ for b in bars]

    @mcp.tool(description="Get all available OHLC bars for a symbol and timeframe. time_frame options: M1, M5, M15, M30, H1, H4, D1, W1, MN1.")
    def get_all_bars(symbol: str, time_frame: str) -> list[dict]:
        bars = http_api.get_all_bars(symbol, time_frame)
        return [b.__dict__ for b in bars]

    return mcp


mcp = create_mcp()

if __name__ == "__main__":
    mcp.run(transport="streamable-http")
