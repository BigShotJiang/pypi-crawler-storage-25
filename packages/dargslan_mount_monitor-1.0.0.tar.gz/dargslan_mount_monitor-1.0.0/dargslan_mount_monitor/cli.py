"""CLI interface for dargslan-mount-monitor."""

import sys
from dargslan_mount_monitor import generate_report, get_mounts, get_network_mounts, check_stale_mounts, get_mount_usage


def main():
    args = sys.argv[1:]
    cmd = args[0] if args else "report"

    if cmd == "report":
        print(generate_report())
    elif cmd == "list":
        for m in get_mounts():
            print(f"{m['mountpoint']:30s} {m['fstype']:10s} {m['device']}")
    elif cmd == "network":
        mounts = get_network_mounts()
        if mounts:
            for m in mounts:
                print(f"{m['mountpoint']:30s} {m['fstype']:10s} {m['device']}")
        else:
            print("No network mounts found.")
    elif cmd == "stale":
        stale = check_stale_mounts()
        if stale:
            for m in stale:
                print(f"[STALE] {m['mountpoint']} ({m['device']})")
        else:
            print("No stale mounts detected.")
    elif cmd == "usage":
        for u in get_mount_usage():
            print(f"{u['mountpoint']:30s} {u['use_percent']:>5s} ({u['used']}/{u['size']})")
    elif cmd in ("help", "--help", "-h"):
        print("dargslan-mount — Linux mount point monitor")
        print("Usage: dargslan-mount [command]")
        print("Commands: report, list, network, stale, usage")
        print("More: https://dargslan.com")
    else:
        print(f"Unknown command: {cmd}. Use --help for usage.")
        sys.exit(1)


if __name__ == "__main__":
    main()
