"""dargslan-mount-monitor — Linux mount point monitor.

Monitor filesystem mounts, bind mounts, NFS/CIFS status, and detect stale mounts.
Part of the Dargslan Linux Sysadmin Toolkit: https://dargslan.com
"""

__version__ = "1.0.0"

import subprocess
import os


def get_mounts():
    """Get all current mount points with filesystem type and options."""
    mounts = []
    try:
        with open("/proc/mounts", "r") as f:
            for line in f:
                parts = line.strip().split()
                if len(parts) >= 4:
                    mounts.append({
                        "device": parts[0],
                        "mountpoint": parts[1],
                        "fstype": parts[2],
                        "options": parts[3],
                    })
    except (IOError, OSError):
        pass
    return mounts


def get_bind_mounts():
    """Find bind mounts from mount list."""
    mounts = get_mounts()
    return [m for m in mounts if "bind" in m.get("options", "")]


def get_network_mounts():
    """Find NFS/CIFS/SMB network mounts."""
    mounts = get_mounts()
    net_types = {"nfs", "nfs4", "cifs", "smbfs", "glusterfs", "fuse.sshfs"}
    return [m for m in mounts if m["fstype"] in net_types]


def check_stale_mounts():
    """Detect stale/hung mount points."""
    stale = []
    mounts = get_mounts()
    for m in mounts:
        mp = m["mountpoint"]
        try:
            os.stat(mp)
        except (OSError, IOError):
            stale.append(m)
    return stale


def get_fstab_entries():
    """Parse /etc/fstab for configured mounts."""
    entries = []
    try:
        with open("/etc/fstab", "r") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                parts = line.split()
                if len(parts) >= 4:
                    entries.append({
                        "device": parts[0],
                        "mountpoint": parts[1],
                        "fstype": parts[2],
                        "options": parts[3],
                    })
    except (IOError, OSError):
        pass
    return entries


def get_mount_usage():
    """Get disk usage for each mount point."""
    usage = []
    try:
        result = subprocess.run(["df", "-h", "--output=source,target,fstype,size,used,avail,pcent"],
                                capture_output=True, text=True, timeout=10)
        lines = result.stdout.strip().split("\n")
        if len(lines) > 1:
            for line in lines[1:]:
                parts = line.split()
                if len(parts) >= 7:
                    usage.append({
                        "device": parts[0],
                        "mountpoint": parts[1],
                        "fstype": parts[2],
                        "size": parts[3],
                        "used": parts[4],
                        "available": parts[5],
                        "use_percent": parts[6],
                    })
    except (subprocess.SubprocessError, OSError):
        pass
    return usage


def generate_report():
    """Generate a comprehensive mount point report."""
    mounts = get_mounts()
    network = get_network_mounts()
    stale = check_stale_mounts()
    usage = get_mount_usage()

    lines = []
    lines.append("=" * 60)
    lines.append("MOUNT POINT MONITOR REPORT")
    lines.append("=" * 60)
    lines.append(f"\nTotal mounts: {len(mounts)}")
    lines.append(f"Network mounts: {len(network)}")
    lines.append(f"Stale mounts: {len(stale)}")

    lines.append("\n--- Active Mounts ---")
    for m in mounts:
        if m["fstype"] not in ("proc", "sysfs", "devtmpfs", "tmpfs", "cgroup", "cgroup2",
                                "pstore", "debugfs", "securityfs", "configfs", "devpts",
                                "hugetlbfs", "mqueue", "fusectl", "binfmt_misc", "tracefs"):
            lines.append(f"  {m['mountpoint']:30s} {m['fstype']:10s} {m['device']}")

    if network:
        lines.append("\n--- Network Mounts ---")
        for m in network:
            lines.append(f"  {m['mountpoint']:30s} {m['fstype']:10s} {m['device']}")

    if stale:
        lines.append("\n--- STALE MOUNTS (WARNING) ---")
        for m in stale:
            lines.append(f"  [STALE] {m['mountpoint']} ({m['device']})")

    if usage:
        lines.append("\n--- Disk Usage ---")
        for u in usage:
            lines.append(f"  {u['mountpoint']:30s} {u['use_percent']:>5s} used ({u['used']}/{u['size']})")

    lines.append("\n" + "=" * 60)
    lines.append("More tools: https://dargslan.com | pip install dargslan-toolkit")
    lines.append("=" * 60)
    return "\n".join(lines)
