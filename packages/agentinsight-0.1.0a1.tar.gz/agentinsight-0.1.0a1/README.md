# AgentInsight Python SDK

Drop-in observability for agentic systems. The SDK records agent, LLM, tool,
retrieval, orchestration, and custom spans, then exports them locally or to an
AgentInsight backend.

## Install

```bash
pip install agentinsight
```

For local development from this repository:

```bash
pip install -e sdk
```

## Quick Start

```python
import agentinsight
import openai

agentinsight.init(
    service_name="support-agent",
    exporter="cloud",
    endpoint="https://your-agentinsight-app.vercel.app",
    api_key="ai_...",
)

client = openai.OpenAI()
response = client.chat.completions.create(
    model="gpt-4o-mini",
    messages=[{"role": "user", "content": "Hello"}],
)
```

OpenAI and Anthropic calls are automatically traced when those packages are
installed. Use `@observe` and `trace_context` for custom agent logic.

## Local Export

```python
import agentinsight
from agentinsight import observe

agentinsight.init(exporter="local", local_path="agentinsight-spans.jsonl")

@observe(kind="agent")
def run_agent(task: str):
    return {"answer": task.upper()}

run_agent("triage this incident")
```

## Manual Spans

```python
from agentinsight import trace_context

with trace_context("plan_trip", kind="agent", attributes={"agent.name": "planner"}) as span:
    span.set_attribute("agent.step", "plan")
```

## LangChain / LangGraph

```python
from agentinsight.integrations.langchain import AgentInsightCallbackHandler

handler = AgentInsightCallbackHandler()
chain.invoke({"input": "hello"}, config={"callbacks": [handler]})
```

LangGraph uses LangChain callbacks, so the same handler works for many LangGraph
apps.
