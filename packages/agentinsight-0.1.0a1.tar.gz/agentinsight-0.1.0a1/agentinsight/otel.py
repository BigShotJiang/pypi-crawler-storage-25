from __future__ import annotations

from typing import Any


class OTelSpan:
    def __init__(self, span: Any = None):
        self.span = span

    @classmethod
    def start(cls, name: str, attributes: dict[str, Any], *, enabled: bool) -> "OTelSpan | None":
        if not enabled:
            return None
        try:
            from opentelemetry import trace
        except Exception:
            return None
        tracer = trace.get_tracer("agentinsight")
        span = tracer.start_span(name)
        wrapper = cls(span)
        for key, value in attributes.items():
            wrapper.set_attribute(key, value)
        return wrapper

    def set_attribute(self, key: str, value: Any) -> None:
        if self.span is None:
            return
        if isinstance(value, (str, bool, int, float)) or value is None:
            self.span.set_attribute(key, value)
        else:
            self.span.set_attribute(key, str(value))

    def end(self, status: str, error: str | None) -> None:
        if self.span is None:
            return
        try:
            from opentelemetry.trace import Status, StatusCode
            if status == "error":
                self.span.set_status(Status(StatusCode.ERROR, error or "error"))
            else:
                self.span.set_status(Status(StatusCode.OK))
        except Exception:
            pass
        self.span.end()
