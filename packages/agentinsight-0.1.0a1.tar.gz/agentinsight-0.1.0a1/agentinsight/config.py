from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Literal


ExporterMode = Literal["local", "cloud", "both", "none"]


@dataclass
class AgentInsightConfig:
    service_name: str = "agentinsight-app"
    exporter: ExporterMode = "local"
    endpoint: str = "http://127.0.0.1:8010"
    api_key: str = ""
    local_path: Path = Path("agentinsight-spans.jsonl")
    enabled: bool = True
    batch_size: int = 25
    flush_interval: float = 2.0
    timeout: float = 10.0
    auto_instrument_openai: bool = True
    auto_instrument_anthropic: bool = True
    opentelemetry: bool = True

    @classmethod
    def from_env(cls, **overrides) -> "AgentInsightConfig":
        exporter = overrides.pop("exporter", None) or os.getenv("AGENTINSIGHT_EXPORTER", "local")
        return cls(
            service_name=overrides.pop("service_name", None) or os.getenv("AGENTINSIGHT_SERVICE_NAME", "agentinsight-app"),
            exporter=exporter,
            endpoint=overrides.pop("endpoint", None) or os.getenv("AGENTINSIGHT_ENDPOINT", "http://127.0.0.1:8010"),
            api_key=overrides.pop("api_key", None) or os.getenv("AGENTINSIGHT_API_KEY", ""),
            local_path=Path(overrides.pop("local_path", None) or os.getenv("AGENTINSIGHT_LOCAL_PATH", "agentinsight-spans.jsonl")),
            enabled=overrides.pop("enabled", None) if "enabled" in overrides else os.getenv("AGENTINSIGHT_DISABLED", "").lower() not in {"1", "true", "yes"},
            batch_size=int(overrides.pop("batch_size", None) or os.getenv("AGENTINSIGHT_BATCH_SIZE", "25")),
            flush_interval=float(overrides.pop("flush_interval", None) or os.getenv("AGENTINSIGHT_FLUSH_INTERVAL", "2.0")),
            timeout=float(overrides.pop("timeout", None) or os.getenv("AGENTINSIGHT_TIMEOUT", "10.0")),
            auto_instrument_openai=overrides.pop("auto_instrument_openai", True),
            auto_instrument_anthropic=overrides.pop("auto_instrument_anthropic", True),
            opentelemetry=overrides.pop("opentelemetry", True),
        )
