from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Literal


SpanKind = Literal[
    "agent",
    "llm",
    "retrieval",
    "tool",
    "agent_state",
    "orchestration",
    "service",
    "database",
    "api_call",
    "http_request",
    "message_queue",
    "system",
    "auth",
    "cache",
]
SpanStatus = Literal["ok", "error", "timeout"]


def new_trace_id() -> str:
    return uuid.uuid4().hex


def new_span_id() -> str:
    return uuid.uuid4().hex[:16]


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def safe_json(value: Any, max_chars: int = 8000) -> str | None:
    if value is None:
        return None
    try:
        text = json.dumps(value, ensure_ascii=True, default=str)
    except TypeError:
        text = repr(value)
    return text[:max_chars]


@dataclass
class SpanRecord:
    span_id: str
    trace_id: str
    parent_span_id: str | None
    name: str
    kind: SpanKind
    start_time: datetime
    end_time: datetime
    duration_ms: float
    status: SpanStatus = "ok"
    attributes: dict[str, Any] = field(default_factory=dict)
    input: str | None = None
    output: str | None = None
    error: str | None = None
    service_name: str = "agentinsight-app"

    def to_dict(self) -> dict[str, Any]:
        return {
            "span_id": self.span_id,
            "trace_id": self.trace_id,
            "parent_span_id": self.parent_span_id,
            "name": self.name,
            "kind": self.kind,
            "start_time": self.start_time.isoformat(),
            "end_time": self.end_time.isoformat(),
            "duration_ms": self.duration_ms,
            "status": self.status,
            "attributes": self.attributes,
            "input": self.input,
            "output": self.output,
            "error": self.error,
            "service_name": self.service_name,
        }


def monotonic_ms() -> float:
    return time.perf_counter() * 1000
