from __future__ import annotations

import atexit
import json
import queue
import threading
import time
from pathlib import Path
from typing import Iterable, Protocol
from urllib import error, request

from .config import AgentInsightConfig
from .models import SpanRecord


class Exporter(Protocol):
    def export(self, spans: list[SpanRecord]) -> None:
        ...

    def flush(self) -> None:
        ...

    def shutdown(self) -> None:
        ...


class NullExporter:
    def export(self, spans: list[SpanRecord]) -> None:
        return

    def flush(self) -> None:
        return

    def shutdown(self) -> None:
        return


class LocalJsonlExporter:
    def __init__(self, path: Path):
        self.path = path
        self._lock = threading.Lock()
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def export(self, spans: list[SpanRecord]) -> None:
        if not spans:
            return
        with self._lock:
            with self.path.open("a", encoding="utf-8") as handle:
                for span in spans:
                    handle.write(json.dumps(span.to_dict(), ensure_ascii=True, default=str))
                    handle.write("\n")

    def flush(self) -> None:
        return

    def shutdown(self) -> None:
        return


class CloudExporter:
    def __init__(self, config: AgentInsightConfig):
        self.config = config
        self._queue: queue.Queue[SpanRecord | None] = queue.Queue()
        self._closed = False
        self._thread = threading.Thread(target=self._worker, name="agentinsight-exporter", daemon=True)
        self._thread.start()
        atexit.register(self.shutdown)

    def export(self, spans: list[SpanRecord]) -> None:
        if self._closed:
            return
        for span in spans:
            self._queue.put(span)

    def flush(self) -> None:
        self._queue.join()

    def shutdown(self) -> None:
        if self._closed:
            return
        self._closed = True
        self._queue.put(None)
        self._thread.join(timeout=max(self.config.timeout, 1.0))

    def _worker(self) -> None:
        batch: list[SpanRecord] = []
        last_flush = time.monotonic()
        while True:
            timeout = max(self.config.flush_interval - (time.monotonic() - last_flush), 0.1)
            try:
                item = self._queue.get(timeout=timeout)
            except queue.Empty:
                if batch:
                    self._send_batch(batch)
                    for _ in batch:
                        self._queue.task_done()
                    batch = []
                    last_flush = time.monotonic()
                continue
            if item is None:
                self._send_batch(batch)
                for _ in batch:
                    self._queue.task_done()
                self._queue.task_done()
                return
            batch.append(item)
            should_flush = len(batch) >= self.config.batch_size or (time.monotonic() - last_flush) >= self.config.flush_interval
            if should_flush:
                self._send_batch(batch)
                for _ in batch:
                    self._queue.task_done()
                batch = []
                last_flush = time.monotonic()

    def _send_batch(self, batch: list[SpanRecord]) -> None:
        if not batch:
            return
        payload = json.dumps({"spans": [span.to_dict() for span in batch]}, ensure_ascii=True, default=str).encode()
        req = request.Request(
            _ingest_url(self.config.endpoint),
            data=payload,
            method="POST",
            headers={
                "Content-Type": "application/json",
                "User-Agent": "agentinsight-python/0.1.0",
                **_auth_headers(self.config.api_key),
            },
        )
        for attempt in range(3):
            try:
                with request.urlopen(req, timeout=self.config.timeout) as response:
                    if 200 <= response.status < 300:
                        return
            except error.HTTPError as exc:
                if 400 <= exc.code < 500 and exc.code != 429:
                    return
            except OSError:
                pass
            time.sleep(0.25 * (2 ** attempt))


class CompositeExporter:
    def __init__(self, exporters: Iterable[Exporter]):
        self.exporters = list(exporters)

    def export(self, spans: list[SpanRecord]) -> None:
        for exporter in self.exporters:
            exporter.export(spans)

    def flush(self) -> None:
        for exporter in self.exporters:
            exporter.flush()

    def shutdown(self) -> None:
        for exporter in self.exporters:
            exporter.shutdown()


def build_exporter(config: AgentInsightConfig) -> Exporter:
    if not config.enabled or config.exporter == "none":
        return NullExporter()
    if config.exporter == "local":
        return LocalJsonlExporter(config.local_path)
    if config.exporter == "cloud":
        return CloudExporter(config)
    if config.exporter == "both":
        return CompositeExporter([LocalJsonlExporter(config.local_path), CloudExporter(config)])
    raise ValueError(f"Unsupported AgentInsight exporter: {config.exporter}")


def _ingest_url(endpoint: str) -> str:
    endpoint = endpoint.rstrip("/")
    if endpoint.endswith("/api/v1/traces/ingest"):
        return endpoint
    return f"{endpoint}/api/v1/traces/ingest"


def _auth_headers(api_key: str) -> dict[str, str]:
    if not api_key:
        return {}
    return {
        "Authorization": f"Bearer {api_key}",
        "X-AgentInsight-API-Key": api_key,
    }
