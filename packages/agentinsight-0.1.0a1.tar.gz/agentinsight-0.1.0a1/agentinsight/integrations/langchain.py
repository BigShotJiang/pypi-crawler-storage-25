from __future__ import annotations

from typing import Any

from agentinsight.api import SpanHandle


try:
    from langchain_core.callbacks import BaseCallbackHandler
except Exception:
    class BaseCallbackHandler:  # type: ignore[no-redef]
        pass


class AgentInsightCallbackHandler(BaseCallbackHandler):
    """LangChain/LangGraph callback handler.

    Pass this handler in `callbacks` or LangGraph runnable config.
    """

    def __init__(self):
        self._runs: dict[str, SpanHandle] = {}

    def on_chain_start(self, serialized: dict[str, Any], inputs: dict[str, Any], *, run_id, parent_run_id=None, **kwargs) -> None:
        self._start(run_id, parent_run_id, _name(serialized, "langchain.chain"), "agent", inputs)

    def on_chain_end(self, outputs: dict[str, Any], *, run_id, **kwargs) -> None:
        self._end(run_id, output=outputs)

    def on_chain_error(self, error: BaseException, *, run_id, **kwargs) -> None:
        self._end(run_id, error=str(error))

    def on_llm_start(self, serialized: dict[str, Any], prompts: list[str], *, run_id, parent_run_id=None, **kwargs) -> None:
        self._start(run_id, parent_run_id, _name(serialized, "langchain.llm"), "llm", {"prompts": prompts})

    def on_llm_end(self, response: Any, *, run_id, **kwargs) -> None:
        self._end(run_id, output=response)

    def on_llm_error(self, error: BaseException, *, run_id, **kwargs) -> None:
        self._end(run_id, error=str(error))

    def on_tool_start(self, serialized: dict[str, Any], input_str: str, *, run_id, parent_run_id=None, **kwargs) -> None:
        self._start(run_id, parent_run_id, _name(serialized, "langchain.tool"), "tool", input_str)

    def on_tool_end(self, output: Any, *, run_id, **kwargs) -> None:
        self._end(run_id, output=output)

    def on_tool_error(self, error: BaseException, *, run_id, **kwargs) -> None:
        self._end(run_id, error=str(error))

    def _start(self, run_id, parent_run_id, name: str, kind: str, input_value: Any) -> None:
        parent = self._runs.get(str(parent_run_id)) if parent_run_id else None
        span = SpanHandle(
            name,
            kind=kind,  # type: ignore[arg-type]
            input=input_value,
            parent_span_id=parent.span_id if parent else None,
            trace_id=parent.trace_id if parent else None,
        )
        span.__enter__()
        self._runs[str(run_id)] = span

    def _end(self, run_id, output: Any = None, error: str | None = None) -> None:
        span = self._runs.pop(str(run_id), None)
        if not span:
            return
        if output is not None:
            span.set_output(output)
        if error:
            span.end(error=error)
        span.__exit__(None, None, None)


def _name(serialized: dict[str, Any], fallback: str) -> str:
    return serialized.get("name") or serialized.get("id", [fallback])[-1] if serialized else fallback
