from __future__ import annotations

from typing import Any

from agentinsight.api import trace_context


_instrumented = False


def instrument_openai() -> bool:
    global _instrumented
    if _instrumented:
        return True
    try:
        from openai.resources.chat.completions import AsyncCompletions, Completions
    except Exception:
        return False

    Completions.create = _wrap_sync(Completions.create)  # type: ignore[method-assign]
    AsyncCompletions.create = _wrap_async(AsyncCompletions.create)  # type: ignore[method-assign]
    _instrumented = True
    return True


def _attrs(kwargs: dict[str, Any]) -> dict[str, Any]:
    return {
        "llm.provider": "openai",
        "llm.model": kwargs.get("model"),
        "llm.stream": bool(kwargs.get("stream", False)),
        "llm.temperature": kwargs.get("temperature"),
    }


def _record_usage(span, response: Any) -> None:
    usage = getattr(response, "usage", None)
    if not usage:
        return
    for attr_name, key in [
        ("prompt_tokens", "llm.tokens.prompt"),
        ("completion_tokens", "llm.tokens.completion"),
        ("total_tokens", "llm.tokens.total"),
    ]:
        value = getattr(usage, attr_name, None)
        if value is not None:
            span.set_attribute(key, value)


def _wrap_sync(original):
    def wrapped(self, *args, **kwargs):
        with trace_context(
            "openai.chat.completions.create",
            kind="llm",
            attributes=_attrs(kwargs),
            input={"messages": kwargs.get("messages"), "model": kwargs.get("model")},
        ) as span:
            response = original(self, *args, **kwargs)
            _record_usage(span, response)
            return response
    wrapped.__agentinsight_wrapped__ = True
    return wrapped


def _wrap_async(original):
    async def wrapped(self, *args, **kwargs):
        with trace_context(
            "openai.chat.completions.create",
            kind="llm",
            attributes=_attrs(kwargs),
            input={"messages": kwargs.get("messages"), "model": kwargs.get("model")},
        ) as span:
            response = await original(self, *args, **kwargs)
            _record_usage(span, response)
            return response
    wrapped.__agentinsight_wrapped__ = True
    return wrapped
