from __future__ import annotations

from typing import Any

from agentinsight.api import trace_context


_instrumented = False


def instrument_anthropic() -> bool:
    global _instrumented
    if _instrumented:
        return True
    try:
        from anthropic.resources.messages import AsyncMessages, Messages
    except Exception:
        return False

    Messages.create = _wrap_sync(Messages.create)  # type: ignore[method-assign]
    AsyncMessages.create = _wrap_async(AsyncMessages.create)  # type: ignore[method-assign]
    _instrumented = True
    return True


def _attrs(kwargs: dict[str, Any]) -> dict[str, Any]:
    return {
        "llm.provider": "anthropic",
        "llm.model": kwargs.get("model"),
        "llm.stream": bool(kwargs.get("stream", False)),
        "llm.max_tokens": kwargs.get("max_tokens"),
    }


def _record_usage(span, response: Any) -> None:
    usage = getattr(response, "usage", None)
    if not usage:
        return
    input_tokens = getattr(usage, "input_tokens", None)
    output_tokens = getattr(usage, "output_tokens", None)
    if input_tokens is not None:
        span.set_attribute("llm.tokens.prompt", input_tokens)
    if output_tokens is not None:
        span.set_attribute("llm.tokens.completion", output_tokens)
    if input_tokens is not None and output_tokens is not None:
        span.set_attribute("llm.tokens.total", input_tokens + output_tokens)


def _wrap_sync(original):
    def wrapped(self, *args, **kwargs):
        with trace_context(
            "anthropic.messages.create",
            kind="llm",
            attributes=_attrs(kwargs),
            input={"messages": kwargs.get("messages"), "model": kwargs.get("model")},
        ) as span:
            response = original(self, *args, **kwargs)
            _record_usage(span, response)
            return response
    return wrapped


def _wrap_async(original):
    async def wrapped(self, *args, **kwargs):
        with trace_context(
            "anthropic.messages.create",
            kind="llm",
            attributes=_attrs(kwargs),
            input={"messages": kwargs.get("messages"), "model": kwargs.get("model")},
        ) as span:
            response = await original(self, *args, **kwargs)
            _record_usage(span, response)
            return response
    return wrapped
