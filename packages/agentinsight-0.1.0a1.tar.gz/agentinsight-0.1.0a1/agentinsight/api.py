from __future__ import annotations

import asyncio
import contextvars
import functools
import traceback
from collections.abc import Callable
from typing import Any, TypeVar

from .config import AgentInsightConfig
from .exporters import Exporter, NullExporter, build_exporter
from .models import SpanKind, SpanRecord, SpanStatus, monotonic_ms, new_span_id, new_trace_id, safe_json, utc_now
from .otel import OTelSpan


F = TypeVar("F", bound=Callable[..., Any])

_config = AgentInsightConfig()
_exporter: Exporter = NullExporter()
_trace_id_var: contextvars.ContextVar[str | None] = contextvars.ContextVar("agentinsight_trace_id", default=None)
_span_id_var: contextvars.ContextVar[str | None] = contextvars.ContextVar("agentinsight_span_id", default=None)


def init(**kwargs) -> AgentInsightConfig:
    global _config, _exporter
    _config = AgentInsightConfig.from_env(**kwargs)
    _exporter.shutdown()
    _exporter = build_exporter(_config)
    if _config.auto_instrument_openai:
        _try_instrument_openai()
    if _config.auto_instrument_anthropic:
        _try_instrument_anthropic()
    return _config


def init_observability(**kwargs) -> AgentInsightConfig:
    return init(**kwargs)


class SpanHandle:
    def __init__(
        self,
        name: str,
        *,
        kind: SpanKind = "agent",
        attributes: dict[str, Any] | None = None,
        input: Any = None,
        trace_id: str | None = None,
        parent_span_id: str | None = None,
    ):
        self.name = name
        self.kind = kind
        self.attributes = dict(attributes or {})
        self.input = safe_json(input)
        self.trace_id = trace_id or _trace_id_var.get() or new_trace_id()
        self.parent_span_id = parent_span_id if parent_span_id is not None else _span_id_var.get()
        self.span_id = new_span_id()
        self.output: str | None = None
        self.error: str | None = None
        self.status: SpanStatus = "ok"
        self.start_time = utc_now()
        self.end_time = self.start_time
        self._start_ms = monotonic_ms()
        self._trace_token = None
        self._span_token = None
        self._otel_span: OTelSpan | None = None
        self._ended = False

    def __enter__(self) -> "SpanHandle":
        self._trace_token = _trace_id_var.set(self.trace_id)
        self._span_token = _span_id_var.set(self.span_id)
        self._otel_span = OTelSpan.start(self.name, self.attributes, enabled=_config.opentelemetry)
        return self

    def __exit__(self, exc_type, exc, tb) -> bool:
        if exc:
            self.status = "error"
            self.error = "".join(traceback.format_exception_only(exc_type, exc)).strip()
            self.attributes["exception.type"] = exc_type.__name__ if exc_type else "Exception"
            self.attributes["exception.message"] = str(exc)
        if not self._ended:
            self.end()
        if self._span_token is not None:
            _span_id_var.reset(self._span_token)
        if self._trace_token is not None:
            _trace_id_var.reset(self._trace_token)
        if self._otel_span:
            self._otel_span.end(self.status, self.error)
        return False

    def set_attribute(self, key: str, value: Any) -> None:
        self.attributes[key] = value
        if self._otel_span:
            self._otel_span.set_attribute(key, value)

    def set_output(self, value: Any) -> None:
        self.output = safe_json(value)

    def end(self, *, output: Any = None, status: SpanStatus | None = None, error: str | None = None) -> None:
        if self._ended:
            return
        if output is not None:
            self.output = safe_json(output)
        if status:
            self.status = status
        if error:
            self.error = error
            self.status = "error"
        self.end_time = utc_now()
        duration_ms = max(monotonic_ms() - self._start_ms, 0)
        record = SpanRecord(
            span_id=self.span_id,
            trace_id=self.trace_id,
            parent_span_id=self.parent_span_id,
            name=self.name,
            kind=self.kind,
            start_time=self.start_time,
            end_time=self.end_time,
            duration_ms=duration_ms,
            status=self.status,
            attributes=self.attributes,
            input=self.input,
            output=self.output,
            error=self.error,
            service_name=_config.service_name,
        )
        _exporter.export([record])
        self._ended = True


def trace_context(
    name: str,
    *,
    kind: SpanKind = "agent",
    attributes: dict[str, Any] | None = None,
    input: Any = None,
    trace_id: str | None = None,
    parent_span_id: str | None = None,
) -> SpanHandle:
    return SpanHandle(
        name,
        kind=kind,
        attributes=attributes,
        input=input,
        trace_id=trace_id,
        parent_span_id=parent_span_id,
    )


def observe(
    func: F | None = None,
    *,
    name: str | None = None,
    kind: SpanKind = "agent",
    attributes: dict[str, Any] | None = None,
    capture_input: bool = False,
    capture_output: bool = False,
) -> F | Callable[[F], F]:
    def decorator(target: F) -> F:
        span_name = name or f"{target.__module__}.{target.__name__}"

        if asyncio.iscoroutinefunction(target):
            @functools.wraps(target)
            async def async_wrapper(*args, **kwargs):
                span_input = {"args": args, "kwargs": kwargs} if capture_input else None
                with trace_context(span_name, kind=kind, attributes=attributes, input=span_input) as span:
                    result = await target(*args, **kwargs)
                    if capture_output:
                        span.set_output(result)
                    return result
            return async_wrapper  # type: ignore[return-value]

        @functools.wraps(target)
        def wrapper(*args, **kwargs):
            span_input = {"args": args, "kwargs": kwargs} if capture_input else None
            with trace_context(span_name, kind=kind, attributes=attributes, input=span_input) as span:
                result = target(*args, **kwargs)
                if capture_output:
                    span.set_output(result)
                return result
        return wrapper  # type: ignore[return-value]

    if func is None:
        return decorator
    return decorator(func)


def record_span(
    name: str,
    *,
    kind: SpanKind = "agent",
    status: SpanStatus = "ok",
    attributes: dict[str, Any] | None = None,
    input: Any = None,
    output: Any = None,
    error: str | None = None,
    trace_id: str | None = None,
    parent_span_id: str | None = None,
) -> None:
    now = utc_now()
    record = SpanRecord(
        span_id=new_span_id(),
        trace_id=trace_id or _trace_id_var.get() or new_trace_id(),
        parent_span_id=parent_span_id if parent_span_id is not None else _span_id_var.get(),
        name=name,
        kind=kind,
        start_time=now,
        end_time=now,
        duration_ms=0,
        status=status,
        attributes=dict(attributes or {}),
        input=safe_json(input),
        output=safe_json(output),
        error=error,
        service_name=_config.service_name,
    )
    _exporter.export([record])


def flush() -> None:
    _exporter.flush()


def shutdown() -> None:
    _exporter.shutdown()


def _try_instrument_openai() -> None:
    try:
        from .instrumentation.openai import instrument_openai
        instrument_openai()
    except Exception:
        return


def _try_instrument_anthropic() -> None:
    try:
        from .instrumentation.anthropic import instrument_anthropic
        instrument_anthropic()
    except Exception:
        return
