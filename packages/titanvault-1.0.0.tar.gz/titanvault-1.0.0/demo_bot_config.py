import sys
import getpass
from titanvault import Vault, TitanModel

# 1. กำหนดหน้าตาข้อมูลที่เราอยากเก็บ (เหมือนออกแบบตารางใน Excel)
class BotConfig(TitanModel):
    bot_name: str
    line_token: str
    admin_user_id: str

def main():
    print("=== โปรแกรมจัดการความลับของบอท ===")
    
    # 2. ให้ผู้ใช้พิมพ์รหัสผ่าน (รหัสนี้จะไม่มีการเซฟลงไฟล์ใดๆ ทั้งสิ้น มันอยู่ในหัวคุณเท่านั้น)
    master_password = input("กรุณาใส่รหัสผ่าน Master Password เพื่อเปิดตู้เซฟ: ")
    
    try:
        # 3. พยายามเปิดตู้เซฟด้วยรหัสผ่านนั้น
        vault = Vault("bot_secrets.db", secret_key=master_password)
    except Exception as e:
        print("\n❌ รหัสผ่านผิด! หรือตู้เซฟถูกทำลาย")
        sys.exit(1)

    while True:
        print("\nเมนู:")
        print("1. บันทึกข้อมูลบอทใหม่")
        print("2. ดูข้อมูลบอทที่มีอยู่")
        print("3. ออกจากโปรแกรม")
        choice = input("เลือกเมนู (1-3): ")

        if choice == '1':
            name = input("ชื่อบอท: ")
            token = input("LINE Token ลับ: ")
            admin_id = input("LINE UserID ของแอดมิน: ")
            
            # 4. โยนข้อมูลใส่ตู้เซฟ (มันจะเข้ารหัสข้อมูลทั้งหมดทันที!)
            config = BotConfig(bot_name=name, line_token=token, admin_user_id=admin_id)
            vault.save(config)
            print("✅ บันทึกและเข้ารหัสลงตู้เซฟเรียบร้อย!")

        elif choice == '2':
            name_to_search = input("ป้อนชื่อบอทที่ต้องการดูข้อมูล: ")
            
            # 5. ค้นหาข้อมูล (ตู้เซฟจะถอดรหัสให้เฉพาะตอนที่เราสั่งดึงข้อมูล)
            result = vault.query(BotConfig).filter(bot_name=name_to_search).first()
            
            if result:
                print("\n🔓 ข้อมูลที่ถอดรหัสแล้ว:")
                print(f"ชื่อบอท: {result.bot_name}")
                print(f"Token: {result.line_token}")
                print(f"Admin ID: {result.admin_user_id}")
            else:
                print("\n❌ ไม่พบข้อมูลบอทชื่อนี้")

        elif choice == '3':
            vault.close()
            print("ปิดตู้เซฟเรียบร้อย ลาก่อน!")
            break
        else:
            print("เลือกเมนูไม่ถูกต้อง")

if __name__ == "__main__":
    main()
