"""
Tests for Encrypted Blob Storage in TitanVault.
"""

from __future__ import annotations

import os
import pytest
from titanvault import Vault, RecordNotFoundError

@pytest.fixture
def tmp_db(tmp_path) -> str:
    return str(tmp_path / "blob_test.db")

def test_blob_roundtrip_bytes(tmp_db):
    password = "test-password"
    data = b"Hello, this is a small blob test."
    metadata = {"name": "test.txt", "type": "text/plain"}
    
    with Vault(tmp_db, secret_key=password) as vault:
        blob_id = vault.put_blob(data, metadata=metadata)
        assert blob_id is not None
        
        # Verify metadata
        retrieved_meta = vault.get_blob_metadata(blob_id)
        assert retrieved_meta == metadata
        
        # Verify data
        retrieved_data = b"".join(vault.get_blob(blob_id))
        assert retrieved_data == data

def test_blob_large_roundtrip(tmp_db):
    password = "test-password"
    # Create a 2.5MB blob (should be 3 chunks with 1MB chunk size)
    data = os.urandom(int(2.5 * 1024 * 1024))
    
    with Vault(tmp_db, secret_key=password) as vault:
        blob_id = vault.put_blob(data)
        
        # Verify data integrity
        retrieved_data = b"".join(vault.get_blob(blob_id))
        assert len(retrieved_data) == len(data)
        assert retrieved_data == data

def test_blob_streaming_iterator(tmp_db):
    password = "test-password"
    
    def data_gen():
        yield b"chunk1-"
        yield b"chunk2-"
        yield b"chunk3"
        
    with Vault(tmp_db, secret_key=password) as vault:
        blob_id = vault.put_blob(data_gen())
        
        retrieved_data = b"".join(vault.get_blob(blob_id))
        assert retrieved_data == b"chunk1-chunk2-chunk3"

def test_blob_delete(tmp_db):
    password = "test-password"
    data = b"to be deleted"
    
    with Vault(tmp_db, secret_key=password) as vault:
        blob_id = vault.put_blob(data)
        assert vault.delete_blob(blob_id) is True
        
        with pytest.raises(RecordNotFoundError):
            vault.get_blob_metadata(blob_id)
            
        with pytest.raises(RecordNotFoundError):
            list(vault.get_blob(blob_id))

def test_blob_not_found(tmp_db):
    with Vault(tmp_db, secret_key="password") as vault:
        with pytest.raises(RecordNotFoundError):
            vault.get_blob_metadata("non-existent-id")
        
        with pytest.raises(RecordNotFoundError):
            next(vault.get_blob("non-existent-id"))

def test_blob_data_not_in_plaintext(tmp_db):
    password = "password"
    secret_message = b"THIS_IS_A_VERY_SECRET_MESSAGE_IN_A_BLOB"
    
    with Vault(tmp_db, secret_key=password) as vault:
        vault.put_blob(secret_message)
        
    with open(tmp_db, "rb") as f:
        raw = f.read()
        
    assert secret_message not in raw
