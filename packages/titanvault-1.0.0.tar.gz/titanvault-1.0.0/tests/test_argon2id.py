"""
Tests for Argon2id Key Derivation in TitanVault.
"""

from __future__ import annotations

import pytest
from titanvault import Vault, TitanModel, DecryptionError

class Secret(TitanModel):
    name: str
    value: str

def test_argon2id_round_trip(tmp_path):
    db_path = str(tmp_path / "argon2.db")
    password = "argon2-password"
    
    # Create vault with Argon2id
    with Vault(db_path, secret_key=password, kdf_type="argon2id") as vault:
        vault.save(Secret(name="my-secret", value="top-secret-data"))
    
    # Reopen vault and verify
    with Vault(db_path, secret_key=password, kdf_type="argon2id") as vault:
        result = vault.query(Secret).filter(name="my-secret").first()
        assert result is not None
        assert result.value == "top-secret-data"

def test_argon2id_wrong_password(tmp_path):
    db_path = str(tmp_path / "argon2_wrong.db")
    password = "correct-password"
    
    # Create vault with Argon2id
    with Vault(db_path, secret_key=password, kdf_type="argon2id") as vault:
        vault.save(Secret(name="test", value="data"))
    
    # Try to open with wrong password
    # Note: Vault.__init__ calls _init_vault which calls derive_key.
    # It doesn't fail during init because derive_key just produces a key.
    # It fails when trying to decrypt data.
    with Vault(db_path, secret_key="wrong-password", kdf_type="argon2id") as vault:
        with pytest.raises(DecryptionError):
            vault.query(Secret).all()

def test_argon2id_persistence(tmp_path):
    """Ensure that kdf_type is persisted in the vault meta."""
    db_path = str(tmp_path / "argon2_persist.db")
    password = "password"
    
    with Vault(db_path, secret_key=password, kdf_type="argon2id") as vault:
        vault.save(Secret(name="test", value="data"))
        
    # Reopen WITHOUT specifying kdf_type, it should load from meta
    with Vault(db_path, secret_key=password) as vault:
        assert vault._kdf_type == "argon2id"
        result = vault.query(Secret).first()
        assert result.value == "data"
