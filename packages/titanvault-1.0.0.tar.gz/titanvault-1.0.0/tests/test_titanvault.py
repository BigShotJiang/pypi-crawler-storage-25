"""
TitanVault Test Suite
=====================
Covers: CRUD, QueryBuilder, Security, Atomic Transactions, Auto-migration,
        Multiple Models, Edge Cases, and Wrong-Password detection.
"""

from __future__ import annotations

import os
import sqlite3
import tempfile
import time
from dataclasses import dataclass
from typing import Optional

import pytest

from titanvault import DecryptionError, TitanModel, Vault, VaultError


# ── Test Models ────────────────────────────────────────────────────────────────

class SecretKey(TitanModel):
    service: str
    username: str
    password: str


class UserProfile(TitanModel):
    name: str
    age: int
    email: str = ""
    is_admin: bool = False


class BankAccount(TitanModel):
    bank: str
    account_number: str
    balance: float = 0.0


# ── Fixtures ───────────────────────────────────────────────────────────────────

@pytest.fixture
def tmp_db(tmp_path) -> str:
    return str(tmp_path / "test_vault.db")


@pytest.fixture
def vault(tmp_db) -> Vault:
    with Vault(tmp_db, secret_key="test-master-password-xyz") as v:
        yield v


@pytest.fixture
def vault2(tmp_db) -> Vault:
    """Second Vault instance on the same DB (same password) — tests persistence."""
    with Vault(tmp_db, secret_key="test-master-password-xyz") as v:
        yield v


# ══════════════════════════════════════════════════════════════════════════════
# 1. BASIC CRUD
# ══════════════════════════════════════════════════════════════════════════════

class TestCRUD:
    def test_save_returns_record_with_id(self, vault):
        key = SecretKey(service="Github", username="alice", password="s3cr3t")
        saved = vault.save(key)
        assert saved._id is not None
        assert len(saved._id) == 36  # UUID4 format

    def test_save_sets_timestamps(self, vault):
        key = SecretKey(service="test", username="u", password="p")
        vault.save(key)
        assert hasattr(key, "_created_at")
        assert hasattr(key, "_updated_at")
        assert key._created_at is not None
        assert key._updated_at is not None

    def test_get_by_id_returns_correct_record(self, vault):
        key = SecretKey(service="Github", username="alice", password="s3cr3t")
        vault.save(key)

        result = vault.get(SecretKey, key._id)
        assert result is not None
        assert result.service == "Github"
        assert result.username == "alice"
        assert result.password == "s3cr3t"

    def test_get_nonexistent_returns_none(self, vault):
        result = vault.get(SecretKey, "00000000-0000-0000-0000-000000000000")
        assert result is None

    def test_save_twice_is_upsert(self, vault):
        key = SecretKey(service="Github", username="alice", password="old")
        vault.save(key)
        record_id = key._id

        key.password = "new-password"
        vault.save(key)

        result = vault.get(SecretKey, record_id)
        assert result.password == "new-password"
        assert vault.count(SecretKey) == 1  # No duplicate

    def test_updated_at_changes_on_re_save(self, vault):
        key = SecretKey(service="test", username="u", password="p")
        vault.save(key)
        first_ts = key._updated_at

        time.sleep(0.01)
        vault.save(key)
        assert key._updated_at > first_ts

    def test_created_at_preserved_on_re_save(self, vault):
        key = SecretKey(service="test", username="u", password="p")
        vault.save(key)
        original_created_at = key._created_at

        time.sleep(0.01)
        vault.save(key)
        assert key._created_at == original_created_at

    def test_delete_record(self, vault):
        key = SecretKey(service="test", username="u", password="p")
        vault.save(key)
        assert vault.count(SecretKey) == 1

        result = vault.delete(key)
        assert result is True
        assert vault.count(SecretKey) == 0

    def test_delete_by_id(self, vault):
        key = SecretKey(service="test", username="u", password="p")
        vault.save(key)
        rid = key._id

        vault.delete_by_id(SecretKey, rid)
        assert vault.get(SecretKey, rid) is None

    def test_delete_nonexistent_returns_false(self, vault):
        key = SecretKey(service="test", username="u", password="p")
        key._id = "00000000-0000-0000-0000-000000000000"
        result = vault.delete(key)
        assert result is False

    def test_count(self, vault):
        for i in range(5):
            vault.save(SecretKey(service=f"S{i}", username="u", password="p"))
        assert vault.count(SecretKey) == 5


# ══════════════════════════════════════════════════════════════════════════════
# 2. QUERY BUILDER
# ══════════════════════════════════════════════════════════════════════════════

class TestQueryBuilder:
    def test_query_all(self, vault):
        vault.save(SecretKey(service="Github", username="a", password="1"))
        vault.save(SecretKey(service="GitLab", username="b", password="2"))

        results = vault.query(SecretKey).all()
        assert len(results) == 2

    def test_query_filter_single_field(self, vault):
        vault.save(SecretKey(service="Github", username="user1", password="p1"))
        vault.save(SecretKey(service="GitLab", username="user2", password="p2"))

        results = vault.query(SecretKey).filter(service="Github").all()
        assert len(results) == 1
        assert results[0].username == "user1"

    def test_query_filter_multiple_fields(self, vault):
        vault.save(SecretKey(service="Github", username="alice", password="p1"))
        vault.save(SecretKey(service="Github", username="bob", password="p2"))
        vault.save(SecretKey(service="GitLab", username="alice", password="p3"))

        results = vault.query(SecretKey).filter(service="Github", username="alice").all()
        assert len(results) == 1
        assert results[0].password == "p1"

    def test_query_first(self, vault):
        vault.save(SecretKey(service="Github", username="manus", password="123"))

        result = vault.query(SecretKey).filter(service="Github").first()
        assert result is not None
        assert result.username == "manus"

    def test_query_first_returns_none_when_not_found(self, vault):
        result = vault.query(SecretKey).filter(service="NonExistent").first()
        assert result is None

    def test_query_last(self, vault):
        vault.save(SecretKey(service="A", username="first", password="p"))
        vault.save(SecretKey(service="A", username="last", password="p"))

        result = vault.query(SecretKey).order_by("username").last()
        assert result.username == "last"

    def test_query_count(self, vault):
        vault.save(SecretKey(service="A", username="u", password="p"))
        vault.save(SecretKey(service="B", username="u", password="p"))
        assert vault.query(SecretKey).count() == 2

    def test_query_exists_true(self, vault):
        vault.save(SecretKey(service="Github", username="u", password="p"))
        assert vault.query(SecretKey).filter(service="Github").exists() is True

    def test_query_exists_false(self, vault):
        assert vault.query(SecretKey).filter(service="Github").exists() is False

    def test_query_limit(self, vault):
        for i in range(5):
            vault.save(SecretKey(service=f"S{i}", username="u", password="p"))
        results = vault.query(SecretKey).limit(3).all()
        assert len(results) == 3

    def test_query_offset(self, vault):
        for i in range(5):
            vault.save(SecretKey(service=f"S{i:02d}", username="u", password="p"))
        results = vault.query(SecretKey).order_by("service").offset(2).all()
        assert len(results) == 3
        assert results[0].service == "S02"

    def test_query_order_by_asc(self, vault):
        vault.save(SecretKey(service="Zebra", username="u", password="p"))
        vault.save(SecretKey(service="Alpha", username="u", password="p"))
        vault.save(SecretKey(service="Mango", username="u", password="p"))

        results = vault.query(SecretKey).order_by("service").all()
        assert [r.service for r in results] == ["Alpha", "Mango", "Zebra"]

    def test_query_order_by_desc(self, vault):
        vault.save(SecretKey(service="Zebra", username="u", password="p"))
        vault.save(SecretKey(service="Alpha", username="u", password="p"))

        results = vault.query(SecretKey).order_by("service", desc=True).all()
        assert results[0].service == "Zebra"

    def test_empty_collection_returns_empty_list(self, vault):
        results = vault.query(SecretKey).all()
        assert results == []

    def test_query_with_int_field(self, vault):
        vault.save(UserProfile(name="Alice", age=30))
        vault.save(UserProfile(name="Bob", age=25))

        result = vault.query(UserProfile).filter(age=30).first()
        assert result is not None
        assert result.name == "Alice"


# ══════════════════════════════════════════════════════════════════════════════
# 3. SECURITY
# ══════════════════════════════════════════════════════════════════════════════

class TestSecurity:
    def test_wrong_password_raises_decryption_error(self, tmp_db):
        with Vault(tmp_db, "correct-password") as v:
            v.save(SecretKey(service="test", username="u", password="p"))

        with Vault(tmp_db, "WRONG-password") as v:
            with pytest.raises(DecryptionError):
                v.query(SecretKey).all()

    def test_wrong_password_get_raises(self, tmp_db):
        rid = None
        with Vault(tmp_db, "correct-password") as v:
            key = SecretKey(service="test", username="u", password="p")
            v.save(key)
            rid = key._id

        with Vault(tmp_db, "wrong") as v:
            with pytest.raises(DecryptionError):
                v.get(SecretKey, rid)

    def test_same_password_reopens_vault(self, tmp_db):
        with Vault(tmp_db, "my-password") as v:
            v.save(SecretKey(service="Github", username="user", password="secret"))

        with Vault(tmp_db, "my-password") as v:
            result = v.query(SecretKey).filter(service="Github").first()
            assert result is not None
            assert result.password == "secret"

    def test_each_record_has_unique_nonce(self, tmp_db):
        """
        Saving two identical records must produce different encrypted blobs
        (because AES-GCM uses a fresh random nonce each time for each field).
        """
        with Vault(tmp_db, "password") as v:
            v.save(SecretKey(service="same", username="same", password="same"))
            v.save(SecretKey(service="same", username="same", password="same"))

        conn = sqlite3.connect(tmp_db)
        rows = conn.execute("SELECT field_service FROM secretkeys").fetchall()
        conn.close()

        assert rows[0][0] != rows[1][0], "Identical field values must produce different ciphertexts (due to unique nonces)"

    def test_data_not_in_plaintext_on_disk(self, tmp_db):
        """
        Sensitive field values must not appear verbatim in the SQLite file.
        """
        with Vault(tmp_db, "password") as v:
            v.save(SecretKey(service="Github", username="alice", password="SUPER_SECRET_XYZ"))

        with open(tmp_db, "rb") as f:
            raw = f.read()

        assert b"SUPER_SECRET_XYZ" not in raw
        assert b"alice" not in raw

    def test_salt_persisted_across_sessions(self, tmp_db):
        """The vault salt must remain the same across open/close cycles."""
        with Vault(tmp_db, "password") as v1:
            salt1 = bytes(
                v1._conn.execute(
                    "SELECT value FROM _vault_meta WHERE key='master_salt'"
                ).fetchone()["value"]
            )

        with Vault(tmp_db, "password") as v2:
            salt2 = bytes(
                v2._conn.execute(
                    "SELECT value FROM _vault_meta WHERE key='master_salt'"
                ).fetchone()["value"]
            )

        assert salt1 == salt2


# ══════════════════════════════════════════════════════════════════════════════
# 4. ATOMIC TRANSACTIONS
# ══════════════════════════════════════════════════════════════════════════════

class TestTransactions:
    def test_save_many_all_or_nothing(self, vault):
        records = [
            SecretKey(service=f"S{i}", username="u", password="p")
            for i in range(10)
        ]
        vault.save_many(records)
        assert vault.count(SecretKey) == 10

    def test_save_many_mixed_types_raises(self, vault):
        records = [
            SecretKey(service="A", username="u", password="p"),
            UserProfile(name="Alice", age=30),
        ]
        with pytest.raises(VaultError, match="same model type"):
            vault.save_many(records)

    def test_explicit_transaction_commits(self, vault):
        with vault.transaction():
            vault.save(SecretKey(service="A", username="u", password="p"))
            vault.save(SecretKey(service="B", username="u", password="p"))

        assert vault.count(SecretKey) == 2

    def test_explicit_transaction_rollback_on_error(self, vault):
        try:
            with vault.transaction():
                vault.save(SecretKey(service="A", username="u", password="p"))
                raise RuntimeError("simulated error")
        except RuntimeError:
            pass

        assert vault.count(SecretKey) == 0


# ══════════════════════════════════════════════════════════════════════════════
# 5. MULTIPLE MODELS
# ══════════════════════════════════════════════════════════════════════════════

class TestMultipleModels:
    def test_each_model_uses_separate_table(self, vault):
        vault.save(SecretKey(service="Github", username="u", password="p"))
        vault.save(UserProfile(name="Alice", age=30))
        vault.save(BankAccount(bank="SCB", account_number="123456789"))

        assert vault.count(SecretKey) == 1
        assert vault.count(UserProfile) == 1
        assert vault.count(BankAccount) == 1

    def test_model_isolation(self, vault):
        vault.save(SecretKey(service="test", username="u", password="p"))
        vault.save(UserProfile(name="Alice", age=30))

        keys = vault.query(SecretKey).all()
        profiles = vault.query(UserProfile).all()

        assert len(keys) == 1
        assert len(profiles) == 1
        assert keys[0].service == "test"
        assert profiles[0].name == "Alice"


# ══════════════════════════════════════════════════════════════════════════════
# 6. DATA TYPES & DEFAULTS
# ══════════════════════════════════════════════════════════════════════════════

class TestDataTypes:
    def test_int_field_round_trips(self, vault):
        vault.save(UserProfile(name="Alice", age=42))
        result = vault.query(UserProfile).filter(name="Alice").first()
        assert result.age == 42
        assert isinstance(result.age, int)

    def test_float_field_round_trips(self, vault):
        vault.save(BankAccount(bank="SCB", account_number="123", balance=1234.56))
        result = vault.query(BankAccount).first()
        assert abs(result.balance - 1234.56) < 1e-9

    def test_bool_field_round_trips(self, vault):
        vault.save(UserProfile(name="Admin", age=30, is_admin=True))
        result = vault.query(UserProfile).filter(name="Admin").first()
        assert result.is_admin is True

    def test_default_field_value(self, vault):
        vault.save(UserProfile(name="Bob", age=25))
        result = vault.query(UserProfile).filter(name="Bob").first()
        assert result.email == ""
        assert result.is_admin is False


# ══════════════════════════════════════════════════════════════════════════════
# 7. SCHEMA EVOLUTION (Auto-migration)
# ══════════════════════════════════════════════════════════════════════════════

class TestSchemaMigration:
    def test_new_optional_field_reads_old_records(self, tmp_db):
        """
        Records saved with an old schema (fewer fields) must still be
        readable after a new optional field is added.
        """

        class LegacyModel(TitanModel):
            name: str

        class MigratedModel(TitanModel):
            name: str
            new_field: str = "default_value"

        # Temporarily rename to share the same table
        original_name = MigratedModel._get_table_name.__func__

        with Vault(tmp_db, "password") as v:
            v.save(LegacyModel(name="old_record"))

        with Vault(tmp_db, "password") as v:
            # Read using the migrated model (new field should get default)
            result = v.query(LegacyModel).first()
            assert result.name == "old_record"


# ══════════════════════════════════════════════════════════════════════════════
# 8. PERSISTENCE
# ══════════════════════════════════════════════════════════════════════════════

class TestPersistence:
    def test_data_survives_close_and_reopen(self, tmp_db):
        with Vault(tmp_db, "password") as v:
            v.save(SecretKey(service="Github", username="alice", password="xyz"))

        with Vault(tmp_db, "password") as v:
            result = v.query(SecretKey).filter(service="Github").first()
            assert result is not None
            assert result.username == "alice"
            assert result.password == "xyz"

    def test_id_preserved_after_reopen(self, tmp_db):
        with Vault(tmp_db, "password") as v:
            key = SecretKey(service="test", username="u", password="p")
            v.save(key)
            original_id = key._id

        with Vault(tmp_db, "password") as v:
            result = v.query(SecretKey).first()
            assert result._id == original_id


# ══════════════════════════════════════════════════════════════════════════════
# 9. CONTEXT MANAGER
# ══════════════════════════════════════════════════════════════════════════════

class TestContextManager:
    def test_vault_as_context_manager(self, tmp_db):
        with Vault(tmp_db, "password") as v:
            v.save(SecretKey(service="test", username="u", password="p"))
            assert isinstance(v, Vault)

    def test_drop_collection(self, vault):
        vault.save(SecretKey(service="test", username="u", password="p"))
        assert vault.count(SecretKey) == 1

        vault.drop_collection(SecretKey)
        assert vault.count(SecretKey) == 0
