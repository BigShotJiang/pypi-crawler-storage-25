import os
import sys

# เพิ่มโฟลเดอร์ root เข้าไปใน path เพื่อให้ import titanvault ได้ (สำหรับ demo)
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src')))

from flask import Flask, request, jsonify, send_from_directory
from titanvault import Vault, TitanModel

app = Flask(__name__)
DB_PATH = "web_vault.db"

# ในของจริง รหัสผ่านนี้ควรมาจาก Environment Variable หรือให้ User กรอกหน้าเว็บ
MASTER_PASSWORD = "my-super-secret-web-password"

# 1. กำหนดหน้าตาข้อมูล
class SecretNote(TitanModel):
    title: str
    content: str

# 2. Route สำหรับแสดงหน้า HTML
@app.route('/')
def index():
    return send_from_directory('.', 'index.html')

# 3. API สำหรับบันทึกข้อมูล
@app.route('/api/notes', methods=['POST'])
def save_note():
    data = request.json
    title = data.get('title')
    content = data.get('content')
    
    # เปิดตู้เซฟและเข้ารหัสข้อมูล (ใช้ chacha20 + argon2id เพื่อความปลอดภัยสูงสุด)
    with Vault(DB_PATH, secret_key=MASTER_PASSWORD, encryption_algo="chacha20", kdf_type="argon2id") as vault:
        note = SecretNote(title=title, content=content)
        vault.save(note)
        
    return jsonify({"status": "success", "message": "✅ เข้ารหัสและบันทึกข้อมูลลงฐานข้อมูลแล้ว!", "id": note._id})

# 4. API สำหรับดึงข้อมูลมาแสดง
@app.route('/api/notes', methods=['GET'])
def get_notes():
    try:
        # เปิดตู้เซฟเพื่ออ่านและถอดรหัสข้อมูล
        with Vault(DB_PATH, secret_key=MASTER_PASSWORD) as vault:
            notes = vault.query(SecretNote).all()
            
            # ส่งข้อมูลที่ถอดรหัสแล้วกลับไปให้หน้าเว็บแสดงผล
            return jsonify([{
                "id": n._id, 
                "title": n.title, 
                "content": n.content
            } for n in notes])
            
    except Exception as e:
        # กรณีฐานข้อมูลยังไม่ถูกสร้าง
        return jsonify([])

if __name__ == '__main__':
    print("🚀 กำลังเริ่มต้นเซิร์ฟเวอร์...")
    print("👉 กรุณาเปิดเว็บเบราว์เซอร์แล้วเข้าไปที่: http://127.0.0.1:8080")
    app.run(port=8080, debug=True)
