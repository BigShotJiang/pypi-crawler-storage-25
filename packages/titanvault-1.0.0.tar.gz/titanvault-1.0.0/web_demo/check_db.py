import sqlite3

def check_raw_data():
    db_path = 'web_vault.db'
    print(f"--- 🕵️‍♂️ กำลังแอบดูข้อมูลดิบในไฟล์ {db_path} ---")
    
    try:
        # เชื่อมต่อ SQLite แบบธรรมดา (เหมือนแฮกเกอร์ที่ได้ไฟล์ไป)
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # ลองดึงข้อมูลจากตาราง secretnotes
        cursor.execute("SELECT id, field_title, field_content FROM secretnotes")
        rows = cursor.fetchall()
        
        if not rows:
            print("ยังไม่มีข้อมูลในตาราง")
            return
            
        for row in rows:
            record_id = row[0]
            # ข้อมูลดิบที่ถูกเก็บในฐานข้อมูลจะเป็น bytes (BLOB)
            raw_title = row[1]
            raw_content = row[2]
            
            print(f"\n🔑 Record ID: {record_id}")
            print(f"  [ดิบ] หัวข้อ (Title)  : {raw_title[:30]}... (รวม {len(raw_title)} bytes)")
            print(f"  [ดิบ] เนื้อหา (Content): {raw_content[:30]}... (รวม {len(raw_content)} bytes)")
            
            # ลองพยายามแปลงกลับเป็นข้อความแบบดื้อๆ (ซึ่งจะอ่านไม่ออก)
            try:
                print(f"  [แฮก] ลองอ่านตรงๆ   : {raw_title.decode('utf-8', errors='replace')}")
            except Exception:
                pass
                
        print("\n✅ สรุป: ข้อมูลถูกเข้ารหัสทั้งหมด แฮกเกอร์ไม่สามารถอ่านรู้เรื่องได้เลย!")
        
    except sqlite3.OperationalError:
        print("ยังไม่พบตารางข้อมูล (คุณอาจจะยังไม่ได้กด Save ในหน้าเว็บ)")
    finally:
        if 'conn' in locals():
            conn.close()

if __name__ == '__main__':
    check_raw_data()
