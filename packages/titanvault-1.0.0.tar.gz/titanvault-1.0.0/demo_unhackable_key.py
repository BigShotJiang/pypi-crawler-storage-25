import os
from titanvault import Vault, TitanModel

# สร้าง "กุญแจเข้ารหัสลับ (Cryptographic Key)" แบบ 256-bit
# อันนี้ไม่ใช่พาสเวิร์ดให้คนพิมพ์! มันคือไบต์สุ่มที่คอมพิวเตอร์สร้างให้ (เหมือน Private Key ใน Crypto)
# คุณจะเซฟกุญแจนี้ไว้ในไฟล์อื่น หรือใน USB Drive ก็ได้
MACHINE_KEY = os.urandom(32).hex()

print("🔑 กุญแจระดับเครื่องจักร (คุณไม่ต้องจำ คอมพิวเตอร์จำให้):")
print(MACHINE_KEY)
print("-" * 50)

class TopSecretData(TitanModel):
    info: str

# ใช้งาน TitanVault ด้วยกุญแจเครื่องจักร
try:
    with Vault("unhackable.db", secret_key=MACHINE_KEY) as vault:
        vault.save(TopSecretData(info="ข้อมูลนี้ไม่มีมนุษย์คนไหนเดารหัสผ่านได้!"))
        
        # ลองดึงมาดู
        res = vault.query(TopSecretData).first()
        print(f"✅ บันทึกและดึงข้อมูลสำเร็จ: {res.info}")

except Exception as e:
    print(f"เกิดข้อผิดพลาด: {e}")

print("-" * 50)
print("❌ ถ้าแฮกเกอร์พยายามเดาด้วย Dictionary Attack หรือ Brute-force:")
print("เขาต้องเดาตัวอักษร 64 ตัว (เลขฐาน 16) ให้ถูกเป๊ะทุกตัว (เช่น d4f8e9a1...)")
print("ความน่าจะเป็นคือ 1 ใน 115,792,089,237,316,195,423,570,985,008,687,907,853,269,984,665,640,564,039,457,584,007,913,129,639,936")
print("ต้องใช้คอมพิวเตอร์ทั้งหมดบนโลก สุ่มเดาเป็นเวลาหลายพันล้านปีครับ!")
