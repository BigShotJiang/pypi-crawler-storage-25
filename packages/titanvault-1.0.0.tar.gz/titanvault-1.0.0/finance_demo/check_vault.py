import sqlite3
import glob

def check_raw_vault():
    print("--- 🕵️‍♂️ กำลังแอบดูข้อมูลดิบในตู้เซฟของคุณ ---")
    
    # หาไฟล์ .db ในโฟลเดอร์ user_vaults (เอาไฟล์ล่าสุด)
    db_files = glob.glob("user_vaults/*.db")
    if not db_files:
        print("ยังไม่มีไฟล์ตู้เซฟ")
        return
        
    # สมมติว่าเอาไฟล์แรกที่เจอ (ไฟล์ของคุณ)
    db_path = db_files[0]
    print(f"📁 เปิดไฟล์: {db_path}\n")
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # ขอดูข้อมูลรายการรายรับรายจ่าย
        cursor.execute("SELECT field_date, field_category, field_amount, field_note FROM transactions ORDER BY _created_at DESC")
        rows = cursor.fetchall()
        
        if not rows:
            print("ยังไม่มีรายการในตู้เซฟนี้")
            return
            
        print("นี่คือสิ่งที่แฮกเกอร์ (หรือเจ้าของเซิร์ฟเวอร์) จะเห็น หากเปิดไฟล์นี้:")
        print("-" * 50)
        
        for i, row in enumerate(rows):
            print(f"รายการที่ {i+1}:")
            # ข้อมูลถูกเก็บเป็น bytes (BLOB)
            print(f"  [ดิบ] วันที่ (Date)     : {repr(row[0][:20])}... (เข้ารหัส)")
            print(f"  [ดิบ] หมวดหมู่ (Category): {repr(row[1][:20])}... (เข้ารหัส)")
            print(f"  [ดิบ] จำนวนเงิน (Amount): {repr(row[2][:20])}... (เข้ารหัส)")
            print(f"  [ดิบ] หมายเหตุ (Note)   : {repr(row[3][:20])}... (เข้ารหัส)")
            print("-" * 50)
            
        print("\n✅ สรุป: ข้อมูล 'ไอติม', '500', 'รับจ้างตัดหญ้า' ถูกบดละเอียดเป็นก้อนไบต์ (Bytes)")
        print("ไม่มีใครอ่านรู้เรื่องได้เลย นอกจากตัวโปรแกรมที่ถือ 'รหัสผ่าน' ของคุณอยู่!")
        
    except sqlite3.OperationalError:
        print("เกิดข้อผิดพลาดในการอ่านไฟล์")
    finally:
        if 'conn' in locals():
            conn.close()

if __name__ == '__main__':
    check_raw_vault()
