import os
import sys
import datetime

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src')))

from flask import Flask, request, jsonify, send_from_directory
from titanvault import Vault, TitanModel, DecryptionError

app = Flask(__name__)
VAULT_DIR = "user_vaults"

# สร้างโฟลเดอร์สำหรับเก็บตู้เซฟของผู้ใช้แต่ละคน
os.makedirs(VAULT_DIR, exist_ok=True)

# 1. กำหนดหน้าตาข้อมูล
class UserProfile(TitanModel):
    email: str
    full_name: str
    phone: str
    address: str

class Transaction(TitanModel):
    date: str
    type: str # 'income' หรือ 'expense'
    category: str
    amount: float
    note: str

# Helper Function: ดึง path ของไฟล์ vault ตามอีเมล
def get_vault_path(email):
    # ป้องกัน path traversal
    safe_email = "".join([c for c in email if c.isalnum() or c in "@.-_"])
    return os.path.join(VAULT_DIR, f"{safe_email}.db")

@app.route('/')
def index():
    return send_from_directory('.', 'index.html')

# 2. API สมัครสมาชิก
@app.route('/api/register', methods=['POST'])
def register():
    data = request.json
    email = data.get('email')
    password = data.get('password')
    
    vault_path = get_vault_path(email)
    
    if os.path.exists(vault_path):
        return jsonify({"status": "error", "message": "อีเมลนี้มีตู้เซฟอยู่แล้ว!"}), 400
        
    try:
        # สร้างตู้เซฟใหม่ด้วยรหัสผ่านของผู้ใช้
        with Vault(vault_path, secret_key=password, encryption_algo="chacha20", kdf_type="argon2id") as vault:
            profile = UserProfile(
                email=email,
                full_name=data.get('full_name'),
                phone=data.get('phone'),
                address=data.get('address')
            )
            vault.save(profile)
        return jsonify({"status": "success", "message": "สร้างบัญชีและตู้เซฟเข้ารหัสสำเร็จ!"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

# 3. API ดึงข้อมูลโปรไฟล์ (ใช้เป็นการ Login ไปในตัว)
@app.route('/api/login', methods=['POST'])
def login():
    data = request.json
    email = data.get('email')
    password = data.get('password')
    
    vault_path = get_vault_path(email)
    if not os.path.exists(vault_path):
        return jsonify({"status": "error", "message": "ไม่พบบัญชีนี้"}), 404
        
    try:
        # พยายามเปิดตู้เซฟ ถ้ารหัสถูก จะเปิดได้ ถ้ารหัสผิด จะโยน DecryptionError
        with Vault(vault_path, secret_key=password) as vault:
            profile = vault.query(UserProfile).first()
            if profile:
                return jsonify({
                    "status": "success", 
                    "message": "เข้าสู่ระบบและปลดล็อกตู้เซฟสำเร็จ!",
                    "profile": {
                        "full_name": profile.full_name,
                        "phone": profile.phone,
                        "address": profile.address
                    }
                })
            return jsonify({"status": "error", "message": "ไม่พบข้อมูลโปรไฟล์"}), 404
    except DecryptionError:
        return jsonify({"status": "error", "message": "รหัสผ่านผิดพลาด! ระบบปฏิเสธการปลดล็อกตู้เซฟ"}), 401

# 4. API บันทึกรายรับรายจ่าย
@app.route('/api/transactions', methods=['POST'])
def add_transaction():
    data = request.json
    email = data.get('email')
    password = data.get('password')
    
    vault_path = get_vault_path(email)
    
    try:
        with Vault(vault_path, secret_key=password) as vault:
            txn = Transaction(
                date=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                type=data.get('type'),
                category=data.get('category'),
                amount=float(data.get('amount')),
                note=data.get('note', '')
            )
            vault.save(txn)
            return jsonify({"status": "success", "message": "บันทึกและเข้ารหัสรายการสำเร็จ!"})
    except DecryptionError:
        return jsonify({"status": "error", "message": "รหัสผ่านไม่ถูกต้อง"}), 401

# 5. API ดึงประวัติรายรับรายจ่าย
@app.route('/api/transactions', methods=['GET'])
def get_transactions():
    email = request.args.get('email')
    password = request.args.get('password')
    
    vault_path = get_vault_path(email)
    if not os.path.exists(vault_path):
        return jsonify([])
        
    try:
        with Vault(vault_path, secret_key=password) as vault:
            txns = vault.query(Transaction).order_by("date", desc=True).all()
            return jsonify([{
                "id": t._id,
                "date": t.date,
                "type": t.type,
                "category": t.category,
                "amount": t.amount,
                "note": t.note
            } for t in txns])
    except DecryptionError:
        return jsonify({"status": "error", "message": "Unauthorized"}), 401

if __name__ == '__main__':
    print("🚀 เริ่มระบบ Secure Finance App บน http://127.0.0.1:8081")
    app.run(port=8081, debug=True)
