"""
TitanVault Core Module
======================
The heart of TitanVault: the `Vault` class and the `QueryBuilder`.

Architecture (ORM-like with field-level encryption):
  ┌──────────────────────────────────────────────────────────┐
  │                       Vault                              │
  │                                                          │
  │  save(obj) ──┐                                           │
  │              ├─► Encrypt each field individually         │
  │              └─► Store in typed columns (BLOB)           │
  │                                                          │
  │  query() ──► Read encrypted columns ──► Decrypt ──► obj │
  └──────────────────────────────────────────────────────────┘

SQLite Schema (per vault file):
  _vault_meta (key TEXT PK, value BLOB)
      └─ "master_salt" → 32-byte random salt
      └─ (model)_schema → SHA256 hash of schema for auto-migration

  <modelname>s (id TEXT PK, field_1 BLOB, field_2 BLOB, ..., _created_at TEXT, _updated_at TEXT)
      └─ id      = UUID (unencrypted, indexed for O(1) access)
      └─ field_N = Encrypted field value (as BLOB)
      └─ _created_at, _updated_at = Unencrypted ISO-8601 timestamps

All field values are encrypted individually using AES-256-GCM.
Timestamps and ID are left unencrypted for efficient querying.
Schema auto-migration happens when model fields change.
"""

from __future__ import annotations

import contextlib
import dataclasses
import datetime
import json
import sqlite3
import uuid
from typing import Any, Dict, Generic, Iterable, Iterator, List, Optional, Type, TypeVar

from .models import TitanModel
from .security import DecryptionError, decrypt_data, derive_key, encrypt_data, generate_salt
from .utils import utcnow_iso

# ── Types ──────────────────────────────────────────────────────────────────────
T = TypeVar("T", bound=TitanModel)

# ── Internal Constants ─────────────────────────────────────────────────────────
_META_TABLE = "_vault_meta"
_SALT_KEY = "master_salt"
_ENC_ALGO_KEY = "encryption_algo"
_KDF_TYPE_KEY = "kdf_type"
_SCHEMA_KEY_TEMPLATE = "{model}_schema"  # e.g., "secretkey_schema"

_BLOBS_TABLE = "_blobs"
_BLOB_CHUNKS_TABLE = "_blob_chunks"
_DEFAULT_CHUNK_SIZE = 1024 * 1024  # 1MB


# ── Exceptions ─────────────────────────────────────────────────────────────────
class VaultError(Exception):
    """General TitanVault operational error."""


class RecordNotFoundError(VaultError):
    """Raised when a requested record does not exist."""


# ── Query Builder ──────────────────────────────────────────────────────────────
class QueryBuilder(Generic[T]):
    """
    Fluent interface for querying a TitanVault collection.

    Example:
        result = vault.query(SecretKey) \\
                      .filter(service="Github") \\
                      .order_by("username") \\
                      .first()
    """

    def __init__(self, vault: "Vault", model_cls: Type[T]) -> None:
        self._vault = vault
        self._model_cls = model_cls
        self._filters: Dict[str, Any] = {}
        self._limit_val: Optional[int] = None
        self._offset_val: int = 0
        self._order_field: Optional[str] = None
        self._order_desc: bool = False

    # ── Filter Methods ─────────────────────────────────────────────────────────

    def filter(self, **kwargs: Any) -> "QueryBuilder[T]":
        """
        Add equality filters. Multiple calls are ANDed together.

        Example:
            .filter(service="Github", username="manus")
        """
        self._filters.update(kwargs)
        return self

    def order_by(self, field: str, desc: bool = False) -> "QueryBuilder[T]":
        """
        Sort results by a field.

        Args:
            field: Name of the model attribute to sort by.
            desc:  If True, sort in descending order.
        """
        self._order_field = field
        self._order_desc = desc
        return self

    def limit(self, n: int) -> "QueryBuilder[T]":
        """Limit the number of returned records."""
        self._limit_val = n
        return self

    def offset(self, n: int) -> "QueryBuilder[T]":
        """Skip the first `n` matching records."""
        self._offset_val = n
        return self

    # ── Terminal Methods ───────────────────────────────────────────────────────

    def all(self) -> List[T]:
        """
        Execute the query and return all matching records.

        Returns:
            List of fully-decrypted, type-safe model instances.
        """
        records = self._vault._fetch_all(self._model_cls)

        # Apply filters
        if self._filters:
            records = [
                r for r in records
                if all(
                    getattr(r, k, _SENTINEL) == v
                    for k, v in self._filters.items()
                )
            ]

        # Apply ordering
        if self._order_field:
            records.sort(
                key=lambda r: (getattr(r, self._order_field, None) or ""),  # type: ignore[arg-type]
                reverse=self._order_desc,
            )

        # Apply offset & limit
        if self._offset_val:
            records = records[self._offset_val:]
        if self._limit_val is not None:
            records = records[: self._limit_val]

        return records

    def first(self) -> Optional[T]:
        """Return the first matching record, or None if none found."""
        results = self.limit(1).all()
        return results[0] if results else None

    def last(self) -> Optional[T]:
        """Return the last matching record, or None if none found."""
        results = self.all()
        return results[-1] if results else None

    def count(self) -> int:
        """Return the count of matching records."""
        return len(self.all())

    def exists(self) -> bool:
        """Return True if at least one matching record exists."""
        return self.first() is not None


_SENTINEL = object()  # Used to detect missing attributes in filter()


# ── Vault ──────────────────────────────────────────────────────────────────────
class Vault:
    """
    The secure, encrypted local storage engine.

    Quick start:
        vault = Vault("secrets.db", secret_key="my-master-password")

        class ApiKey(TitanModel):
            service: str
            token: str

        vault.save(ApiKey(service="OpenAI", token="sk-..."))
        key = vault.query(ApiKey).filter(service="OpenAI").first()
        print(key.token)  # sk-...

        vault.close()

    As a context manager:
        with Vault("secrets.db", secret_key="password") as vault:
            ...
    """

    def __init__(
        self,
        db_path: str,
        secret_key: str,
        encryption_algo: str = "aes-gcm",
        kdf_type: str = "pbkdf2"
    ) -> None:
        """
        Open (or create) a vault.

        Args:
            db_path:         Path to the SQLite file. Will be created if absent.
            secret_key:      Master password. Used to derive the AES-256 key.
            encryption_algo: "aes-gcm" (default) or "chacha20".
            kdf_type:        "pbkdf2" (default) or "argon2id".

        Raises:
            VaultError: If the vault cannot be initialised.
        """
        self._db_path = db_path
        self._secret_key = secret_key
        self._requested_algo = encryption_algo
        self._requested_kdf = kdf_type

        self._conn: sqlite3.Connection = sqlite3.connect(
            db_path, check_same_thread=False
        )
        self._conn.row_factory = sqlite3.Row

        # Enable WAL for better concurrent read performance & crash safety
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        # Synchronise at the OS level — protects against power loss
        self._conn.execute("PRAGMA synchronous=NORMAL")

        self._txn_depth: int = 0  # tracks nested transaction depth

        # Meta settings (will be loaded from DB if exists)
        self._enc_algo = encryption_algo
        self._kdf_type = kdf_type

        self._master_key: bytes = self._init_vault()

    # ── Internal: Vault Bootstrap ──────────────────────────────────────────────

    def _ensure_blob_tables(self) -> None:
        """Create internal tables for encrypted blob storage."""
        self._conn.execute(
            f"""
            CREATE TABLE IF NOT EXISTS {_BLOBS_TABLE} (
                id          TEXT PRIMARY KEY,
                metadata    BLOB NOT NULL,
                _created_at TEXT NOT NULL,
                _updated_at TEXT NOT NULL
            )
            """
        )
        self._conn.execute(
            f"""
            CREATE TABLE IF NOT EXISTS {_BLOB_CHUNKS_TABLE} (
                blob_id     TEXT NOT NULL,
                chunk_index INTEGER NOT NULL,
                data        BLOB NOT NULL,
                PRIMARY KEY (blob_id, chunk_index),
                FOREIGN KEY (blob_id) REFERENCES {_BLOBS_TABLE} (id) ON DELETE CASCADE
            )
            """
        )
        self._conn.commit()

    def _init_vault(self) -> bytes:
        """
        Set up the metadata table and derive the master key.

        On first run: generates salt and stores crypto settings.
        On subsequent runs: reads settings and re-derives the key.
        """
        self._conn.execute(
            f"""
            CREATE TABLE IF NOT EXISTS {_META_TABLE} (
                key   TEXT PRIMARY KEY NOT NULL,
                value BLOB NOT NULL
            )
            """
        )
        self._conn.commit()

        # Try to load existing metadata
        rows = self._conn.execute(
            f"SELECT key, value FROM {_META_TABLE} WHERE key IN (?, ?, ?)",
            (_SALT_KEY, _ENC_ALGO_KEY, _KDF_TYPE_KEY)
        ).fetchall()

        meta = {row["key"]: row["value"] for row in rows}

        if _SALT_KEY not in meta:
            # First time setup
            salt = generate_salt()
            self._conn.execute(
                f"INSERT INTO {_META_TABLE} (key, value) VALUES (?, ?)",
                (_SALT_KEY, salt),
            )
            self._conn.execute(
                f"INSERT INTO {_META_TABLE} (key, value) VALUES (?, ?)",
                (_ENC_ALGO_KEY, self._requested_algo.encode("utf-8")),
            )
            self._conn.execute(
                f"INSERT INTO {_META_TABLE} (key, value) VALUES (?, ?)",
                (_KDF_TYPE_KEY, self._requested_kdf.encode("utf-8")),
            )
            self._conn.commit()

            self._enc_algo = self._requested_algo
            self._kdf_type = self._requested_kdf
        else:
            # Load existing settings (ignore requested settings)
            salt = bytes(meta[_SALT_KEY])
            self._enc_algo = meta[_ENC_ALGO_KEY].decode("utf-8")
            self._kdf_type = meta[_KDF_TYPE_KEY].decode("utf-8")

        self._ensure_blob_tables()
        return derive_key(self._secret_key, salt, kdf_type=self._kdf_type)

    def _ensure_table(self, model_cls: Type[TitanModel]) -> None:
        """
        Create the model's table with ORM-like typed columns if it doesn't exist.
        Also performs auto-migration if schema has changed.
        """
        table = model_cls._get_table_name()
        schema_key = _SCHEMA_KEY_TEMPLATE.format(model=table.rstrip("s"))

        # Get current schema hash
        current_hash = model_cls._get_schema_hash()

        # Check if table exists
        table_exists = self._conn.execute(
            f"SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)
        ).fetchone() is not None

        if not table_exists:
            # Build CREATE TABLE statement with typed columns
            field_schemas = model_cls._get_field_schemas()
            col_defs = ["id TEXT PRIMARY KEY NOT NULL"]

            for field_name, sqlite_type in field_schemas:
                col_defs.append(f"field_{field_name} BLOB")

            col_defs.extend([
                "_created_at TEXT NOT NULL",
                "_updated_at TEXT NOT NULL"
            ])

            create_sql = f"CREATE TABLE {table} ({', '.join(col_defs)})"
            self._conn.execute(create_sql)

            # Record schema hash for this model (use INSERT OR IGNORE to avoid conflicts)
            self._conn.execute(
                f"INSERT OR IGNORE INTO {_META_TABLE} (key, value) VALUES (?, ?)",
                (schema_key, current_hash.encode("utf-8")),
            )
            self._conn.commit()
        else:
            # Auto-migration: check if schema has changed
            stored_hash_row = self._conn.execute(
                f"SELECT value FROM {_META_TABLE} WHERE key = ?", (schema_key,)
            ).fetchone()
            stored_hash = stored_hash_row[0].decode("utf-8") if stored_hash_row else None

            if stored_hash is None or stored_hash != current_hash:
                # Schema has changed, perform migration
                self._migrate_table_schema(model_cls, table, current_hash, schema_key)

    def _migrate_table_schema(
        self,
        model_cls: Type[TitanModel],
        table: str,
        new_hash: str,
        schema_key: str
    ) -> None:
        """
        Perform auto-migration when model schema changes.
        Adds new columns with defaults for new fields.
        """
        field_schemas = model_cls._get_field_schemas()
        
        # Get existing columns
        existing_cols = set()
        for row in self._conn.execute(f"PRAGMA table_info({table})"):
            existing_cols.add(row[1])  # column name

        # Add missing columns
        for field_name, sqlite_type in field_schemas:
            col_name = f"field_{field_name}"
            if col_name not in existing_cols:
                self._conn.execute(
                    f"ALTER TABLE {table} ADD COLUMN {col_name} BLOB"
                )

        # Update schema hash
        self._conn.execute(
            f"UPDATE {_META_TABLE} SET value = ? WHERE key = ?",
            (new_hash.encode("utf-8"), schema_key),
        )
        self._conn.commit()

    # ── Internal: Serialization Pipeline ──────────────────────────────────────

    def _encrypt_field(self, value: Any) -> bytes:
        """Encrypt a single field value (as JSON) using the vault's algorithm."""
        json_bytes = json.dumps(value, ensure_ascii=False, default=str).encode("utf-8")
        return encrypt_data(json_bytes, self._master_key, algo=self._enc_algo)

    def _decrypt_field(self, encrypted_blob: bytes) -> Any:
        """Decrypt a single field value from JSON."""
        json_bytes = decrypt_data(encrypted_blob, self._master_key, algo=self._enc_algo)
        return json.loads(json_bytes.decode("utf-8"))

    def _serialize_and_encrypt(self, record: TitanModel) -> Dict[str, bytes]:
        """
        Serialize record fields into encrypted BLOB values.
        Returns a dict mapping field_name -> encrypted bytes.
        """
        result: Dict[str, bytes] = {}
        for field_name, _ in type(record)._get_field_schemas():
            value = getattr(record, field_name, None)
            result[field_name] = self._encrypt_field(value)
        return result

    def _decrypt_and_deserialize(self, model_cls: Type[T], field_dict: Dict[str, bytes]) -> T:
        """
        Decrypt field values and reconstruct a model instance.
        
        Args:
            model_cls: The model class to instantiate
            field_dict: Dict mapping field_name -> encrypted bytes
        """
        decrypted_values: Dict[str, Any] = {}
        for field_name, encrypted_blob in field_dict.items():
            decrypted_values[field_name] = self._decrypt_field(encrypted_blob)

        # Reconstruct the object
        obj = model_cls(**decrypted_values)
        return obj

    # ── Internal: Fetch ────────────────────────────────────────────────────────

    def _fetch_all(self, model_cls: Type[T]) -> List[T]:
        self._ensure_table(model_cls)
        table = model_cls._get_table_name()
        field_names = [fname for fname, _ in model_cls._get_field_schemas()]
        
        # Build column list: id, field_*, timestamps
        col_list = ["id"] + [f"field_{fname}" for fname in field_names] + ["_created_at", "_updated_at"]
        select_sql = f"SELECT {', '.join(col_list)} FROM {table}"
        
        rows = self._conn.execute(select_sql).fetchall()
        results: List[T] = []
        for row in rows:
            try:
                # Reconstruct field_dict from encrypted columns
                field_dict: Dict[str, bytes] = {}
                for fname in field_names:
                    encrypted_blob = bytes(row[f"field_{fname}"])
                    field_dict[fname] = encrypted_blob
                
                # Decrypt and deserialize
                obj = self._decrypt_and_deserialize(model_cls, field_dict)
                
                # Restore metadata (already decrypted from unencrypted columns)
                obj._id = row["id"]
                obj._created_at = row["_created_at"]
                obj._updated_at = row["_updated_at"]
                
                results.append(obj)
            except DecryptionError:
                raise
            except Exception:
                # Skip individual corrupted records without aborting the query
                continue
        return results

    # ── Public: CRUD ───────────────────────────────────────────────────────────

    def save(self, record: TitanModel) -> TitanModel:
        """
        Persist a record to the vault (insert or update).

        - New records receive a UUID `_id`, `_created_at`, and `_updated_at`.
        - Existing records have their `_updated_at` refreshed.
        - Each field is encrypted individually before storing in typed columns.

        Args:
            record: Any `TitanModel` instance.

        Returns:
            The same record, with metadata attributes set.
        """
        model_cls = type(record)
        self._ensure_table(model_cls)

        now = utcnow_iso()

        if not getattr(record, "_id", None):
            record._id = str(uuid.uuid4())
            record._created_at = now

        record._updated_at = now

        # Encrypt each field individually
        encrypted_fields = self._serialize_and_encrypt(record)
        table = model_cls._get_table_name()
        field_names = [fname for fname, _ in model_cls._get_field_schemas()]

        # Build INSERT statement
        col_names = ["id"] + [f"field_{fname}" for fname in field_names] + ["_created_at", "_updated_at"]
        placeholders = ", ".join(["?"] * len(col_names))
        insert_sql = f"INSERT OR REPLACE INTO {table} ({', '.join(col_names)}) VALUES ({placeholders})"

        # Build values list
        values = [record._id]
        for fname in field_names:
            values.append(encrypted_fields[fname])
        values.extend([record._created_at, record._updated_at])

        self._conn.execute(insert_sql, values)
        self._maybe_commit()
        return record

    def save_many(self, records: List[TitanModel]) -> None:
        """
        Persist multiple records in a single atomic transaction.

        Either all records are saved, or none are (on error).

        Args:
            records: List of `TitanModel` instances (must all be the same type).

        Raises:
            VaultError: If `records` contains mixed model types.
        """
        if not records:
            return

        types = {type(r) for r in records}
        if len(types) > 1:
            raise VaultError(
                "save_many() requires all records to be the same model type. "
                f"Found: {[t.__name__ for t in types]}"
            )

        model_cls = type(records[0])
        self._ensure_table(model_cls)
        table = model_cls._get_table_name()
        field_names = [fname for fname, _ in model_cls._get_field_schemas()]
        col_names = ["id"] + [f"field_{fname}" for fname in field_names] + ["_created_at", "_updated_at"]
        placeholders = ", ".join(["?"] * len(col_names))
        insert_sql = f"INSERT OR REPLACE INTO {table} ({', '.join(col_names)}) VALUES ({placeholders})"
        now = utcnow_iso()

        with self._atomic():
            for record in records:
                if not getattr(record, "_id", None):
                    record._id = str(uuid.uuid4())
                    record._created_at = now
                record._updated_at = now
                
                # Encrypt each field individually
                encrypted_fields = self._serialize_and_encrypt(record)
                values = [record._id]
                for fname in field_names:
                    values.append(encrypted_fields[fname])
                values.extend([record._created_at, record._updated_at])
                
                self._conn.execute(insert_sql, values)

    def get(self, model_cls: Type[T], record_id: str) -> Optional[T]:
        """
        Retrieve a single record by its UUID.

        Args:
            model_cls: The model class (e.g. `SecretKey`).
            record_id: The `_id` of the record.

        Returns:
            A decrypted model instance, or None if not found.
        """
        self._ensure_table(model_cls)
        table = model_cls._get_table_name()
        field_names = [fname for fname, _ in model_cls._get_field_schemas()]
        
        # Build SELECT statement for all field columns
        col_list = ["id"] + [f"field_{fname}" for fname in field_names] + ["_created_at", "_updated_at"]
        select_sql = f"SELECT {', '.join(col_list)} FROM {table} WHERE id = ?"
        
        row = self._conn.execute(select_sql, (record_id,)).fetchone()

        if row is None:
            return None

        # Reconstruct field_dict from encrypted columns
        field_dict: Dict[str, bytes] = {}
        for fname in field_names:
            encrypted_blob = bytes(row[f"field_{fname}"])
            field_dict[fname] = encrypted_blob
        
        # Decrypt and deserialize
        obj = self._decrypt_and_deserialize(model_cls, field_dict)
        
        # Restore metadata
        obj._id = row["id"]
        obj._created_at = row["_created_at"]
        obj._updated_at = row["_updated_at"]
        
        return obj

    def query(self, model_cls: Type[T]) -> QueryBuilder[T]:
        """
        Start a fluent query against a model collection.

        Example:
            vault.query(SecretKey).filter(service="Github").first()

        Args:
            model_cls: The model class to query.

        Returns:
            A `QueryBuilder` instance.
        """
        return QueryBuilder(self, model_cls)

    def delete(self, record: TitanModel) -> bool:
        """
        Delete a record from the vault.

        Args:
            record: A previously-saved `TitanModel` instance.

        Returns:
            True if a record was deleted, False if it was not found.
        """
        model_cls = type(record)
        record_id = getattr(record, "_id", None)
        if not record_id:
            return False
        return self.delete_by_id(model_cls, record_id)

    def delete_by_id(self, model_cls: Type[TitanModel], record_id: str) -> bool:
        """
        Delete a record by its UUID.

        Args:
            model_cls: The model class.
            record_id: The UUID of the record to delete.

        Returns:
            True if deleted, False if not found.
        """
        self._ensure_table(model_cls)
        table = model_cls._get_table_name()
        cursor = self._conn.execute(
            f"DELETE FROM {table} WHERE id = ?", (record_id,)
        )
        self._maybe_commit()
        return cursor.rowcount > 0

    def count(self, model_cls: Type[TitanModel]) -> int:
        """Return the total number of records for a model (no decryption needed)."""
        self._ensure_table(model_cls)
        table = model_cls._get_table_name()
        row = self._conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()
        return row[0] if row else 0

    def drop_collection(self, model_cls: Type[TitanModel]) -> None:
        """
        Permanently delete all records of a model type and drop its table.

        ⚠️ This operation is irreversible.
        """
        table = model_cls._get_table_name()
        self._conn.execute(f"DROP TABLE IF EXISTS {table}")
        self._maybe_commit()

    # ── Public: Transaction ────────────────────────────────────────────────────

    @contextlib.contextmanager
    def transaction(self) -> Iterator[None]:
        """
        Context manager for explicit atomic transactions.

        On success: commits.
        On exception: rolls back.

        Example:
            with vault.transaction():
                vault.save(record_a)
                vault.save(record_b)
                vault.delete(old_record)
        """
        with self._atomic():
            yield

    def _maybe_commit(self) -> None:
        """Commit only when NOT inside an explicit transaction block."""
        if self._txn_depth == 0:
            self._conn.commit()

    @contextlib.contextmanager
    def _atomic(self) -> Iterator[None]:
        """Internal atomic transaction helper with nesting support."""
        self._txn_depth += 1
        try:
            yield
            self._txn_depth -= 1
            if self._txn_depth == 0:
                self._conn.commit()
        except Exception:
            self._txn_depth -= 1
            if self._txn_depth == 0:
                self._conn.rollback()
            raise

    # ── Public: Blob Storage ───────────────────────────────────────────────────

    def put_blob(
        self,
        data: bytes | Iterable[bytes],
        metadata: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        Store a large binary object in the vault.

        The data is split into 1MB chunks, and each chunk is encrypted
        individually before being stored in SQLite.

        Args:
            data:     Bytes or an iterable of bytes (for streaming).
            metadata: Optional dictionary of metadata to store with the blob.

        Returns:
            The unique `blob_id` (UUID).
        """
        blob_id = str(uuid.uuid4())
        now = utcnow_iso()
        
        # Encrypt metadata
        meta_dict = metadata or {}
        enc_metadata = self._encrypt_field(meta_dict)

        with self._atomic():
            # Insert blob entry
            self._conn.execute(
                f"INSERT INTO {_BLOBS_TABLE} (id, metadata, _created_at, _updated_at) VALUES (?, ?, ?, ?)",
                (blob_id, enc_metadata, now, now)
            )

            # Insert chunks
            chunk_index = 0
            if isinstance(data, bytes):
                # Chunk memory-resident bytes
                for i in range(0, len(data), _DEFAULT_CHUNK_SIZE):
                    chunk = data[i : i + _DEFAULT_CHUNK_SIZE]
                    enc_chunk = encrypt_data(chunk, self._master_key, algo=self._enc_algo)
                    self._conn.execute(
                        f"INSERT INTO {_BLOB_CHUNKS_TABLE} (blob_id, chunk_index, data) VALUES (?, ?, ?)",
                        (blob_id, chunk_index, enc_chunk)
                    )
                    chunk_index += 1
            else:
                # Stream from iterable
                buffer = b""
                for part in data:
                    buffer += part
                    while len(buffer) >= _DEFAULT_CHUNK_SIZE:
                        chunk = buffer[:_DEFAULT_CHUNK_SIZE]
                        buffer = buffer[_DEFAULT_CHUNK_SIZE:]
                        enc_chunk = encrypt_data(chunk, self._master_key, algo=self._enc_algo)
                        self._conn.execute(
                            f"INSERT INTO {_BLOB_CHUNKS_TABLE} (blob_id, chunk_index, data) VALUES (?, ?, ?)",
                            (blob_id, chunk_index, enc_chunk)
                        )
                        chunk_index += 1
                
                # Final partial chunk
                if buffer:
                    enc_chunk = encrypt_data(buffer, self._master_key, algo=self._enc_algo)
                    self._conn.execute(
                        f"INSERT INTO {_BLOB_CHUNKS_TABLE} (blob_id, chunk_index, data) VALUES (?, ?, ?)",
                        (blob_id, chunk_index, enc_chunk)
                    )

        return blob_id

    def get_blob(self, blob_id: str) -> Iterator[bytes]:
        """
        Retrieve a blob as a stream of decrypted chunks.

        Args:
            blob_id: The UUID of the blob to retrieve.

        Yields:
            Decrypted bytes chunks.
        """
        cursor = self._conn.execute(
            f"SELECT data FROM {_BLOB_CHUNKS_TABLE} WHERE blob_id = ? ORDER BY chunk_index ASC",
            (blob_id,)
        )
        
        found = False
        for row in cursor:
            found = True
            enc_chunk = row[0]
            yield decrypt_data(enc_chunk, self._master_key, algo=self._enc_algo)
            
        if not found:
            # Check if blob exists at all (might be an empty blob or missing)
            exists = self._conn.execute(
                f"SELECT 1 FROM {_BLOBS_TABLE} WHERE id = ?", (blob_id,)
            ).fetchone()
            if not exists:
                raise RecordNotFoundError(f"Blob not found: {blob_id}")

    def get_blob_metadata(self, blob_id: str) -> Dict[str, Any]:
        """
        Retrieve the decrypted metadata for a blob.

        Args:
            blob_id: The UUID of the blob.

        Returns:
            Decrypted metadata dictionary.
        """
        row = self._conn.execute(
            f"SELECT metadata FROM {_BLOBS_TABLE} WHERE id = ?", (blob_id,)
        ).fetchone()
        
        if row is None:
            raise RecordNotFoundError(f"Blob not found: {blob_id}")
            
        return self._decrypt_field(row[0])

    def delete_blob(self, blob_id: str) -> bool:
        """
        Delete a blob and all its associated chunks.

        Args:
            blob_id: The UUID of the blob to delete.

        Returns:
            True if deleted, False if not found.
        """
        # ON DELETE CASCADE handles the chunks automatically
        cursor = self._conn.execute(
            f"DELETE FROM {_BLOBS_TABLE} WHERE id = ?", (blob_id,)
        )
        self._maybe_commit()
        return cursor.rowcount > 0

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    def close(self) -> None:
        """Close the database connection."""
        self._conn.close()

    def __enter__(self) -> "Vault":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def __repr__(self) -> str:
        return f"Vault(db={self._db_path!r})"
