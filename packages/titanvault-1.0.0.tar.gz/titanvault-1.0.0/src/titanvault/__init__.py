"""
TitanVault — Secure, Lightweight, Type-Safe Local Storage
==========================================================

    from titanvault import Vault, TitanModel

    class SecretKey(TitanModel):
        service: str
        username: str
        password: str

    with Vault("my_vault.db", secret_key="super-secret-password") as vault:
        vault.save(SecretKey(service="Github", username="manus", password="123"))
        result = vault.query(SecretKey).filter(service="Github").first()
        print(result.username)  # manus
"""

from .core import QueryBuilder, RecordNotFoundError, Vault, VaultError
from .models import TitanModel
from .security import DecryptionError

__version__ = "1.0.0"
__author__ = "TitanVault Contributors"
__license__ = "MIT"

__all__ = [
    # Core
    "Vault",
    "VaultError",
    "RecordNotFoundError",
    # Models
    "TitanModel",
    # Security
    "DecryptionError",
    # Query
    "QueryBuilder",
]
