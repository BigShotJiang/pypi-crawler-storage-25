"""
TitanVault Security Module
==========================
NASA-grade encryption using AES-256-GCM with PBKDF2-HMAC-SHA256 key derivation.

Security Properties:
- AES-256-GCM: Authenticated encryption (confidentiality + integrity + authenticity)
- PBKDF2: 600,000 iterations (NIST SP 800-132 recommended minimum for 2023+)
- Unique nonce per encryption: prevents ciphertext reuse attacks
- Random 32-byte salt: prevents rainbow table attacks
"""

from __future__ import annotations

import os

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM, ChaCha20Poly1305
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.kdf.argon2 import Argon2id

# ── Constants ──────────────────────────────────────────────────────────────────
SALT_SIZE: int = 32       # 256-bit salt
NONCE_SIZE: int = 12      # 96-bit nonce (Standard for GCM and ChaCha20Poly1305)
KEY_SIZE: int = 32        # 256-bit key
PBKDF2_ITERATIONS: int = 600_000  # NIST SP 800-132 (2023)


# ── Exceptions ─────────────────────────────────────────────────────────────────
class DecryptionError(Exception):
    """
    Raised when decryption fails.
    Causes: wrong password, corrupted data, or tampered ciphertext.
    """


# ── Core Functions ─────────────────────────────────────────────────────────────
def generate_salt() -> bytes:
    """Generate a cryptographically secure random salt."""
    return os.urandom(SALT_SIZE)


def derive_key(password: str, salt: bytes, kdf_type: str = "pbkdf2") -> bytes:
    """
    Derive a 256-bit encryption key from a password.

    Args:
        password: The user-supplied master password.
        salt:     A unique random salt.
        kdf_type: "pbkdf2" or "argon2id"
    """
    if kdf_type == "argon2id":
        # Argon2id with recommended parameters (Memory: 64MB, Iterations: 3, Lanes: 4)
        kdf = Argon2id(
            salt=salt,
            length=KEY_SIZE,
            iterations=3,
            memory_cost=65536,
            lanes=4,
        )
    else:
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=KEY_SIZE,
            salt=salt,
            iterations=PBKDF2_ITERATIONS,
        )
    return kdf.derive(password.encode("utf-8"))


def encrypt_data(plaintext: bytes, key: bytes, algo: str = "aes-gcm") -> bytes:
    """
    Encrypt bytes using AES-256-GCM or ChaCha20-Poly1305.
    """
    nonce = os.urandom(NONCE_SIZE)
    if algo == "chacha20":
        cipher = ChaCha20Poly1305(key)
    else:
        cipher = AESGCM(key)
    
    ciphertext = cipher.encrypt(nonce, plaintext, associated_data=None)
    return nonce + ciphertext


def decrypt_data(blob: bytes, key: bytes, algo: str = "aes-gcm") -> bytes:
    """
    Decrypt and authenticate a blob.
    """
    if len(blob) < NONCE_SIZE:
        raise DecryptionError("Blob is too short to be valid ciphertext.")

    nonce = blob[:NONCE_SIZE]
    ciphertext = blob[NONCE_SIZE:]
    
    if algo == "chacha20":
        cipher = ChaCha20Poly1305(key)
    else:
        cipher = AESGCM(key)

    try:
        return cipher.decrypt(nonce, ciphertext, associated_data=None)
    except InvalidTag as exc:
        raise DecryptionError(
            "Decryption failed: wrong password or corrupted / tampered data."
        ) from exc
