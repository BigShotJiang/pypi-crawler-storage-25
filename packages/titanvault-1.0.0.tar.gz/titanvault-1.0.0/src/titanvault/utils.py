"""
TitanVault Utilities Module
============================
Internal helpers used across the library.
"""

from __future__ import annotations

import dataclasses
import datetime
import uuid
from typing import Any, Dict, Type


# ── Type Mapping ───────────────────────────────────────────────────────────────

_PY_TO_SQLITE: Dict[type, str] = {
    str:   "TEXT",
    int:   "INTEGER",
    float: "REAL",
    bool:  "INTEGER",
    bytes: "BLOB",
}


def python_type_to_sqlite(py_type: Type[Any]) -> str:
    """Map a Python type to the closest SQLite affinity."""
    return _PY_TO_SQLITE.get(py_type, "TEXT")


# ── Time Helpers ───────────────────────────────────────────────────────────────

def utcnow_iso() -> str:
    """Return the current UTC time as an ISO-8601 string."""
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def new_uuid() -> str:
    """Generate a new UUID v4 string."""
    return str(uuid.uuid4())


# ── Schema Introspection ───────────────────────────────────────────────────────

def get_field_names(cls: type) -> list[str]:
    """Return the names of all dataclass fields for a TitanModel subclass."""
    try:
        return [f.name for f in dataclasses.fields(cls)]  # type: ignore[arg-type]
    except TypeError:
        return []


def schema_summary(cls: type) -> str:
    """
    Return a human-readable summary of a model's schema.

    Example:
        >>> schema_summary(SecretKey)
        'SecretKey(service: str, username: str, password: str)'
    """
    try:
        fields = dataclasses.fields(cls)  # type: ignore[arg-type]
        parts = [f"{f.name}: {f.type}" for f in fields]
        return f"{cls.__name__}({', '.join(parts)})"
    except TypeError:
        return f"{cls.__name__}(?)"
