"""
TitanVault Models Module
========================
Provides `TitanModel`, the base class for all user-defined data schemas.

Usage:
    class SecretKey(TitanModel):
        service: str
        username: str
        password: str

    key = SecretKey(service="Github", username="manus", password="123")

Subclassing `TitanModel` automatically applies `@dataclass`, so no decorator
is needed. Metadata fields (_id, _created_at, _updated_at) are managed
transparently by the Vault engine.
"""

from __future__ import annotations

import dataclasses
import datetime
import uuid
from typing import Any, Dict, Optional, Type, TypeVar

from .utils import python_type_to_sqlite

T = TypeVar("T", bound="TitanModel")

# ── Internal Helpers ───────────────────────────────────────────────────────────

_METADATA_FIELDS = ("_id", "_created_at", "_updated_at")


def _coerce(value: Any, field: dataclasses.Field) -> Any:  # type: ignore[type-arg]
    """Best-effort type coercion when deserializing from JSON."""
    if value is None:
        return value
    hint = field.type
    # Resolve string annotations (e.g. from `from __future__ import annotations`)
    if isinstance(hint, str):
        return value
    try:
        if hint is bool:
            return bool(value)
        if hint is int:
            return int(value)
        if hint is float:
            return float(value)
        if hint is str:
            return str(value)
    except (TypeError, ValueError):
        pass
    return value


# ── Base Model ─────────────────────────────────────────────────────────────────

class TitanModel:
    """
    Base class for all TitanVault data models.

    Simply define your fields with type annotations — no `@dataclass` needed:

        class Credential(TitanModel):
            service: str
            username: str
            password: str

    Auto-managed metadata (set by the Vault, not by the user):
        _id          : str  — UUID v4 primary key
        _created_at  : str  — ISO-8601 UTC timestamp of first save
        _updated_at  : str  — ISO-8601 UTC timestamp of latest save
    """

    def __init_subclass__(cls, **kwargs: Any) -> None:
        """Automatically apply @dataclass to every subclass."""
        super().__init_subclass__(**kwargs)
        dataclasses.dataclass(cls)

    # ── Class-Level Helpers ────────────────────────────────────────────────────

    @classmethod
    def _get_table_name(cls) -> str:
        """Return the SQLite table name for this model (lowercase class name + 's')."""
        return cls.__name__.lower() + "s"

    @classmethod
    def _dataclass_fields(cls) -> tuple[dataclasses.Field, ...]:  # type: ignore[type-arg]
        return dataclasses.fields(cls)  # type: ignore[arg-type]

    @classmethod
    def _get_field_schemas(cls) -> list[tuple[str, str]]:
        """
        Return a list of (field_name, sqlite_type) tuples for all user-defined fields.
        
        Example:
            [("service", "TEXT"), ("age", "INTEGER")]
        """
        result: list[tuple[str, str]] = []
        for field in cls._dataclass_fields():
            sqlite_type = python_type_to_sqlite(field.type)
            result.append((field.name, sqlite_type))
        return result

    @classmethod
    def _get_schema_hash(cls) -> str:
        """
        Return a deterministic hash of the schema for auto-migration detection.
        Used to detect when fields have been added/removed/changed.
        """
        import hashlib
        schemas = cls._get_field_schemas()
        schema_str = "|".join(f"{name}:{stype}" for name, stype in schemas)
        return hashlib.sha256(schema_str.encode()).hexdigest()[:16]

    # ── Serialization ──────────────────────────────────────────────────────────

    def to_dict(self) -> Dict[str, Any]:
        """
        Serialize to a plain dictionary for JSON encoding.
        Includes both user-defined fields and vault metadata.
        """
        d: Dict[str, Any] = dataclasses.asdict(self)  # type: ignore[call-overload]
        for attr in _METADATA_FIELDS:
            val = getattr(self, attr, None)
            if val is not None:
                d[attr] = val
        return d

    @classmethod
    def from_dict(cls: Type[T], data: Dict[str, Any]) -> T:
        """
        Deserialize from a dictionary, restoring user fields and metadata.
        Missing optional fields fall back to their declared defaults.
        Supports schema evolution: new fields with defaults are handled gracefully.
        """
        init_kwargs: Dict[str, Any] = {}

        for field in dataclasses.fields(cls):  # type: ignore[arg-type]
            if field.name in data:
                init_kwargs[field.name] = _coerce(data[field.name], field)
            elif field.default is not dataclasses.MISSING:
                init_kwargs[field.name] = field.default
            elif field.default_factory is not dataclasses.MISSING:  # type: ignore[misc]
                init_kwargs[field.name] = field.default_factory()  # type: ignore[misc]
            # If required field is absent, cls(**init_kwargs) will raise TypeError

        obj = cls(**init_kwargs)

        # Restore vault metadata (not dataclass fields, just plain attributes)
        obj._id = data.get("_id", str(uuid.uuid4()))
        obj._created_at = data.get("_created_at", datetime.datetime.now(datetime.timezone.utc).isoformat())
        obj._updated_at = data.get("_updated_at", datetime.datetime.now(datetime.timezone.utc).isoformat())

        return obj

    # ── Dunder Helpers ─────────────────────────────────────────────────────────

    def __repr__(self) -> str:
        fields_str = ", ".join(
            f"{f.name}={getattr(self, f.name)!r}"
            for f in dataclasses.fields(self)  # type: ignore[arg-type]
        )
        record_id = getattr(self, "_id", "unsaved")
        return f"{self.__class__.__name__}(id={record_id!r}, {fields_str})"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, self.__class__):
            return NotImplemented
        return self.to_dict() == other.to_dict()
