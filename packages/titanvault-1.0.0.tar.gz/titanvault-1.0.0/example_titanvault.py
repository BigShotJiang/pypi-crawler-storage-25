from titanvault import Vault, TitanModel
import os

# 1. นิยามโครงสร้างข้อมูล
class SecretKey(TitanModel):
    service: str
    username: str
    password: str

# 2. เปิดใช้งาน Vault ด้วยรหัสผ่านระดับนาซ่า
# ตอนนี้รองรับอัลกอริทึมที่หลากหลายตาม Blueprint แล้ว!
# ตัวอย่าง: ใช้ ChaCha20 และ Argon2id (ความปลอดภัยสูงสุดและเร็วบนมือถือ)
DB_PATH = "my_secure_vault.db"
if os.path.exists(DB_PATH):
    os.remove(DB_PATH) # ลบของเก่าเพื่อสาธิตการสร้างใหม่

print("--- กำลังสร้าง Vault ใหม่ด้วย ChaCha20 + Argon2id ---")
with Vault(DB_PATH, secret_key="super-secret-password", 
           encryption_algo="chacha20", 
           kdf_type="argon2id") as vault:

    # 3. บันทึกข้อมูล (เข้ารหัสอัตโนมัติ)
    new_key = SecretKey(service="Github", username="manus", password="secure_token_123")
    vault.save(new_key)
    print(f"บันทึกข้อมูลเรียบร้อย: {new_key.service} (ID: {new_key._id})")

print("\n--- กำลังโหลด Vault เดิม (ระบบจะจำการตั้งค่า Encryption ให้อัตโนมัติ) ---")
with Vault(DB_PATH, secret_key="super-secret-password") as vault:
    # 4. ดึงข้อมูล (ถอดรหัสและคืนค่าเป็น Object)
    result = vault.query(SecretKey).filter(service="Github").first()
    if result:
        print(f"ดึงข้อมูลสำเร็จ!")
        print(f"Service: {result.service}")
        print(f"Username: {result.username}")
        print(f"Password: {result.password}") # ข้อมูลถูกถอดรหัสออกมาเป็น Plaintext ใน Memory เท่านั้น
    
    # ตรวจสอบความปลอดภัย: ลองใช้รหัสผ่านผิด
    print("\n--- ทดสอบใช้รหัสผ่านผิด ---")
    try:
        with Vault(DB_PATH, secret_key="wrong-password") as wrong_vault:
            wrong_vault.query(SecretKey).all()
    except Exception as e:
        print(f"ระบบป้องกันสำเร็จ: {e}")

    # 5. ตัวอย่างการใช้ Encrypted Blob Storage (สำหรับไฟล์ขนาดใหญ่)
    print("\n--- ทดสอบระบบ Encrypted Blob Storage (Chunked) ---")
    large_data = b"This is a simulated large file content." * 100
    blob_id = vault.put_blob(large_data, metadata={"filename": "important_doc.txt"})
    print(f"บันทึก Blob สำเร็จ (ID: {blob_id})")
    
    # ดึง Metadata
    meta = vault.get_blob_metadata(blob_id)
    print(f"Metadata ที่ดึงมา: {meta}")
    
    # ดึงข้อมูล Blob
    retrieved_data = b"".join(vault.get_blob(blob_id))
    print(f"ความถูกต้องของข้อมูล: {retrieved_data == large_data}")

# ลบไฟล์ตัวอย่าง
if os.path.exists(DB_PATH):
    os.remove(DB_PATH)
    # ลบไฟล์ wal และ shm ของ sqlite ด้วย
    for ext in ["-wal", "-shm"]:
        if os.path.exists(DB_PATH + ext):
            os.remove(DB_PATH + ext)
