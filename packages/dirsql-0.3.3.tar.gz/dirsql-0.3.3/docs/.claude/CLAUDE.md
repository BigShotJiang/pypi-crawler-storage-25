# dirsql docs

@../AGENTS.md
