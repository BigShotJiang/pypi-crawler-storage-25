#!/usr/bin/env bash
# Push the lightbulb-sdk/ subdirectory of this private monorepo to a public
# GitHub repo as its main branch. Idempotent — re-run after merges to keep
# the mirror in sync.
#
# Prereq: create the empty public repo on GitHub first (no template, no README).
# Suggested name: lightbulb-partners/lightbulb-mcp (or RPasquale/lightbulb-mcp
# if there's no org yet). Then export PUBLIC_REPO_URL and run this script.
#
# Usage:
#   export PUBLIC_REPO_URL="https://github.com/<org>/lightbulb-mcp.git"
#   ./scripts/mirror_to_public_repo.sh
#
# What it does:
#   1. From the monorepo root, create a synthetic branch containing only the
#      history of `lightbulb-sdk/` (via `git subtree split`).
#   2. Force-push that branch to the public repo's main.
#   3. Clean up the local synthetic branch.
#
# Why force-push: subtree split rewrites the SHA chain. The public repo is a
# read-only mirror — no one is committing to it directly, so force-push is
# safe AND necessary.
#
# For automation, the GitHub Actions workflow at .github/workflows/mirror-sdk.yml
# does this on every push to main automatically.

set -euo pipefail

if [[ -z "${PUBLIC_REPO_URL:-}" ]]; then
    echo "ERROR: set PUBLIC_REPO_URL=https://github.com/<org>/lightbulb-mcp.git" >&2
    exit 1
fi

# Find the monorepo root (this script lives at lightbulb-sdk/scripts/...)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MONOREPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
cd "$MONOREPO_ROOT"

echo "Monorepo: $MONOREPO_ROOT"
echo "Mirror target: $PUBLIC_REPO_URL"

# Subtree split — produces a synthetic SHA representing the lightbulb-sdk/
# subtree's history.
echo "→ git subtree split --prefix=lightbulb-sdk -b _lightbulb_sdk_mirror"
git branch -D _lightbulb_sdk_mirror 2>/dev/null || true
git subtree split --prefix=lightbulb-sdk -b _lightbulb_sdk_mirror

# Force-push to the public repo's main.
echo "→ git push --force $PUBLIC_REPO_URL _lightbulb_sdk_mirror:main"
git push --force "$PUBLIC_REPO_URL" _lightbulb_sdk_mirror:main

# Clean up.
git branch -D _lightbulb_sdk_mirror

echo "✓ Mirror updated."
