"""Generate a Flyway migration that seeds `tools` rows for every adapter op.

Why this exists:
    `lightbulb-mcp` 0.5.0 generates ~565 connector-op MCP tools that call
    `POST /api/tools/invoke`. The Spring-side handler (`ToolRegistryController`)
    looks up the tool name in the `tools` table; if no row exists, it 404s.
    Today only ~14 `crm.*` rows exist (V1055). This migration seeds the
    remainder so customer JWTs can actually invoke the ops their adapters
    already implement.

What it produces:
    db/migration/V1441__seed_connector_tool_keys.sql with ON CONFLICT DO NOTHING
    inserts. Idempotent — safe to re-run if more ops are added later (run the
    script again with the new ops; emit a fresh V14xx_*.sql).

The platform team should:
    1. Review the generated SQL.
    2. Optionally trim ops they don't want to expose.
    3. Run Flyway as part of the next deploy.

To regenerate:
    python3 scripts/generate_tool_seed_migration.py
"""

from __future__ import annotations

import hashlib
from pathlib import Path

# ──────────────────────────────────────────────────────────────────────
# Adapter op vocabulary, extracted from the switch expressions in
# springboot-server/.../service/tools/connectors/adapters/*Adapter.java
# Filtered to drop obvious non-ops (single-word constants like 'open',
# 'success', 'all', 'any' that grep matched from non-switch contexts).
# ──────────────────────────────────────────────────────────────────────

ADAPTER_OPS: dict[str, dict] = {
    # connector_db_name → {domain, ops}
    "gmail": {
        "domain": "communication",
        "ops": ["gmail.list_emails", "gmail.send_email"],
    },
    "microsoft_365": {
        "domain": "communication",
        "ops": [
            "microsoft.list_emails", "microsoft.send_email", "microsoft.list_events",
            "microsoft.list_drive_files", "microsoft.list_teams", "microsoft.list_team_channels",
            "microsoft.list_channel_messages", "microsoft.list_chats", "microsoft.list_chat_messages",
            "microsoft.post_channel_message", "microsoft.post_chat_message",
            "microsoft.list_sharepoint_sites", "microsoft.list_sharepoint_drives",
            "microsoft.list_sharepoint_drive_items",
            "microsoft.download_file", "microsoft.upload_file", "microsoft.update_file",
            "teams.post_channel_message", "teams.post_chat_message",
            "iam.disable_user", "iam.revoke_tokens",
        ],
    },
    "microsoft_excel": {
        "domain": "productivity",
        "ops": ["excel.list_worksheets", "excel.get_range", "excel.update_range", "excel.add_worksheet"],
    },
    "google_calendar": {
        "domain": "productivity",
        "ops": ["calendar.create_event", "calendar.update_event", "calendar.delete_event", "calendar.get_availability"],
    },
    "google_docs": {
        "domain": "productivity",
        "ops": ["docs.create_document", "docs.get_content", "docs.get_metadata", "docs.update_document"],
    },
    "google_drive": {
        "domain": "productivity",
        "ops": ["drive.list_files", "drive.get_file", "drive.upload_file", "drive.update_file", "drive.download_file"],
    },
    "google_sheets": {
        "domain": "productivity",
        "ops": [
            "sheets.create_spreadsheet", "sheets.get_spreadsheet", "sheets.get_values",
            "sheets.update_values", "sheets.append_values", "sheets.clear_values", "sheets.add_sheet",
        ],
    },
    "google_slides": {
        "domain": "productivity",
        "ops": ["slides.create_presentation", "slides.get_content", "slides.get_metadata", "slides.update_presentation"],
    },
    "google_workspace_identity": {
        "domain": "iam",
        "ops": ["iam.get_user", "iam.disable_user", "iam.revoke_tokens"],
    },
    "salesforce_crm": {
        "domain": "crm",
        # `crm.get_contact|create_contact|search_contacts|update_contact` already in V1055; skip.
        "ops": [
            "crm.get_account", "crm.search_accounts", "crm.update_account",
            "crm.get_opportunity", "crm.list_opportunities", "crm.create_opportunity", "crm.update_opportunity",
            "crm.create_task", "crm.create_note", "crm.log_call",
            "salesforce.bulk_query_create", "salesforce.bulk_query_status", "salesforce.bulk_query_results",
            "salesforce.bulk_ingest_create", "salesforce.bulk_ingest_upload", "salesforce.bulk_ingest_close",
            "salesforce.bulk_ingest_status", "salesforce.bulk_ingest_results", "salesforce.pipeline_report",
        ],
    },
    "hubspot_crm": {
        "domain": "crm",
        "ops": [
            # crm.get_contact / create_contact / search_contacts / update_contact in V1055 already
            "crm.get_account", "crm.search_accounts", "crm.update_account",
            "crm.get_deal", "crm.search_deals", "crm.create_deal", "crm.update_deal",
            "crm.get_ticket", "crm.search_tickets", "crm.create_ticket", "crm.update_ticket",
            "crm.get_engagement", "crm.search_engagements", "crm.create_engagement",
            "crm.list_owners", "crm.get_owner", "crm.list_pipelines",
            "crm.create_association", "crm.get_associations",
        ],
    },
    "notion": {
        "domain": "productivity",
        "ops": [
            "notion.search", "notion.search_by_title", "notion.get_self", "notion.get_user", "notion.list_users",
            "notion.create_page", "notion.get_page", "notion.update_page", "notion.archive_page",
            "notion.append_block_children", "notion.list_block_children", "notion.update_block", "notion.delete_block",
            "notion.create_database", "notion.update_database", "notion.list_databases", "notion.query_database",
            "notion.list_data_sources", "notion.query_data_source",
            "notion.create_comment", "notion.list_comments",
        ],
    },
    "slack": {
        "domain": "communication",
        "ops": [
            "slack.post_message", "slack.update_message", "slack.delete_message",
            "slack.post_ephemeral", "slack.me_message", "slack.schedule_message",
            "slack.list_scheduled_messages", "slack.delete_scheduled_message",
            "slack.get_channel_history", "slack.get_thread_replies", "slack.search_messages",
            "slack.list_channels", "slack.create_channel", "slack.archive_channel", "slack.unarchive_channel",
            "slack.set_channel_purpose", "slack.set_channel_topic",
            "slack.invite_to_channel", "slack.kick_from_channel", "slack.list_channel_members", "slack.open_dm",
            "slack.list_users", "slack.users_info", "slack.lookup_user", "slack.users_set_presence",
            "slack.add_reaction", "slack.remove_reaction", "slack.list_reactions",
            "slack.pins_add", "slack.pins_remove",
            "slack.team_info", "slack.unfurl_link",
            "slack.usergroups_list", "slack.usergroups_users_list",
            "slack.files_upload_v2", "slack.files_get_upload_url_external",
            "slack.files_complete_upload_external", "slack.files_info", "slack.files_delete",
            "slack.create_canvas", "slack.access_canvas", "slack.edit_canvas", "slack.delete_canvas",
            "slack.create_conversation_canvas", "slack.canvas_section_lookup",
            "slack.views_open", "slack.views_publish", "slack.views_push", "slack.views_update",
            "slack.assistant_set_status", "slack.assistant_set_title", "slack.assistant_set_suggested_prompts",
            "slack.workflows_step_completed", "slack.workflows_step_failed",
        ],
    },
    "jira": {
        "domain": "it_ops",
        "ops": [
            "jira.create_issue", "jira.get_issue", "jira.update_issue", "jira.search_issues",
            "jira.transition_issue", "jira.bulk_transition", "jira.create_subtask", "jira.link_issues",
            "jira.add_comment", "jira.add_attachment", "jira.log_work", "jira.update_custom_fields",
            "jira.get_board_sprints", "jira.get_sprint_issues", "jira.create_sprint",
            "jira.start_sprint", "jira.close_sprint", "jira.add_to_sprint", "jira.rank_backlog",
            "jira.list_webhooks", "jira.subscribe_webhook", "jira.delete_webhook",
            "jira.list_automation_rules", "jira.create_automation_rule", "jira.delete_automation_rule",
        ],
    },
    "github": {
        "domain": "it_ops",
        "ops": [
            "github.create_issue", "github.get_issue", "github.update_issue", "github.list_issues",
            "github.create_issue_comment", "github.add_labels_to_issue", "github.remove_label_from_issue",
            "github.create_pull_request", "github.get_pull_request", "github.update_pull_request",
            "github.list_pull_requests", "github.list_pull_request_files", "github.list_pull_request_review_comments",
            "github.merge_pull_request", "github.request_reviewers", "github.remove_requested_reviewers",
            "github.list_reviews", "github.submit_review", "github.dismiss_review",
            "github.create_release", "github.list_releases", "github.update_release",
            "github.create_branch_ref", "github.delete_branch_ref", "github.get_branch", "github.list_branches",
            "github.get_branch_protection", "github.update_branch_protection", "github.compare_commits", "github.list_commits",
            "github.create_repository", "github.create_ruleset", "github.list_rulesets",
            "github.trigger_workflow", "github.cancel_workflow_run", "github.rerun_workflow_run",
            "github.get_workflow_run", "github.get_workflow_run_logs", "github.list_workflow_runs", "github.list_workflow_jobs",
            "github.create_check_run", "github.update_check_run", "github.list_check_runs", "github.list_check_suites",
            "github.create_environment", "github.list_environments", "github.create_deployment_status", "github.list_deployments",
            "github.list_code_scanning_alerts", "github.list_secret_scanning_alerts", "github.list_dependabot_alerts",
            "github.add_project_v2_item", "github.list_project_v2_items", "github.update_project_v2_item_field",
        ],
    },
    "shopify": {
        "domain": "commerce",
        "ops": [
            "ecommerce.search_products", "ecommerce.get_product", "ecommerce.create_product",
            "ecommerce.update_product", "ecommerce.get_product_reviews",
            "ecommerce.search_orders", "ecommerce.get_order", "ecommerce.update_order",
            "ecommerce.search_customers", "ecommerce.get_customer", "ecommerce.create_customer", "ecommerce.update_customer",
            "ecommerce.get_inventory", "ecommerce.create_discount",
            "shopify.get_shop_info", "shopify.list_locations", "shopify.list_collections",
            "shopify.list_draft_orders", "shopify.list_abandoned_checkouts",
            "shopify.list_fulfillment_orders", "shopify.list_transactions", "shopify.list_refunds",
            "shopify.list_discounts", "shopify.create_price_rule",
            "shopify.list_metafield_definitions", "shopify.get_metafields", "shopify.update_metafield",
            "shopify.tag_customers_bulk",
            "shopify.bulk_operation_create", "shopify.bulk_operation_status", "shopify.bulk_operation_result",
            "shopify.analytics_query",
        ],
    },
    "square": {
        "domain": "commerce",
        "ops": [
            "square.list_locations", "square.list_payments", "square.get_payment",
            "square.list_orders", "square.get_order", "square.search_orders",
            "square.list_customers",
            "square.search_catalog", "square.get_catalog_item",
            "square.get_inventory",
            "square.list_appointments",
            "square.list_payouts", "square.list_refunds", "square.create_refund", "square.create_invoice",
        ],
    },
    "quickbooks": {
        "domain": "finance",
        "ops": [
            "quickbooks.company_info", "quickbooks.get_company_info", "quickbooks.preferences",
            "quickbooks.controller_snapshot", "quickbooks.deep_sync", "quickbooks.cdc", "quickbooks.batch", "quickbooks.query",
            "quickbooks.list_accounts", "quickbooks.list_classes", "quickbooks.list_departments",
            "quickbooks.list_payment_methods", "quickbooks.list_terms", "quickbooks.list_tax_codes", "quickbooks.list_tax_rates",
            "quickbooks.list_customers", "quickbooks.list_vendors", "quickbooks.list_items",
            "quickbooks.create_invoice", "quickbooks.get_invoice", "quickbooks.list_invoices",
            "quickbooks.create_bill", "quickbooks.list_bills", "quickbooks.pay_bill",
            "quickbooks.list_payments", "quickbooks.list_purchase_orders", "quickbooks.list_purchases",
            "quickbooks.list_credit_memos", "quickbooks.list_refund_receipts", "quickbooks.list_sales_receipts",
            "quickbooks.list_deposits", "quickbooks.list_vendor_credits",
            "quickbooks.create_journal_entry", "quickbooks.create_entity", "quickbooks.get_entity",
            "quickbooks.update_entity", "quickbooks.list_entities",
            "quickbooks.balance_sheet_report", "quickbooks.profit_loss_report", "quickbooks.cash_flow_report",
            "quickbooks.trial_balance_report", "quickbooks.aged_payable_report", "quickbooks.aged_receivable_report", "quickbooks.report",
            "quickbooks.payroll_company_info", "quickbooks.payroll_employees", "quickbooks.payroll_payslips",
        ],
    },
    "xero": {
        "domain": "finance",
        "ops": [
            "xero.get_organisation",
            "xero.list_contacts", "xero.create_contact", "xero.update_contact",
            "xero.list_invoices", "xero.get_invoice", "xero.create_invoice", "xero.update_invoice",
            "xero.list_bills", "xero.create_bill", "xero.pay_bill",
            "xero.list_payments", "xero.create_payment",
            "xero.list_credit_notes", "xero.create_credit_note", "xero.update_credit_note",
            "xero.list_bank_transactions", "xero.create_bank_transaction", "xero.update_bank_transaction",
            "xero.list_manual_journals", "xero.create_manual_journal", "xero.update_manual_journal",
            "xero.list_quotes", "xero.create_quote", "xero.update_quote",
            "xero.list_purchase_orders", "xero.get_purchase_order", "xero.create_purchase_order", "xero.update_purchase_order",
            "xero.list_receipts", "xero.create_receipt", "xero.update_receipt",
            "xero.list_repeating_invoices", "xero.create_repeating_invoice", "xero.update_repeating_invoice",
            "xero.list_expense_claims", "xero.create_expense_claim", "xero.update_expense_claim",
            "xero.list_items", "xero.create_item", "xero.update_item",
            "xero.list_accounts", "xero.list_tax_rates", "xero.list_currencies", "xero.list_branding_themes",
            "xero.list_tracking_categories", "xero.create_tracking_category", "xero.update_tracking_category",
            "xero.create_tracking_option", "xero.update_tracking_options",
            "xero.list_attachments", "xero.get_attachment", "xero.upload_attachment",
            "xero.list_files", "xero.get_file", "xero.upload_file", "xero.list_folders", "xero.create_folder",
            "xero.list_history", "xero.create_history_note", "xero.create_association", "xero.list_associations",
            "xero.list_assets", "xero.list_asset_types", "xero.get_asset", "xero.create_asset", "xero.update_asset",
            "xero.dispose_asset", "xero.book_depreciation",
            "xero.list_projects", "xero.get_project", "xero.create_project", "xero.update_project",
            "xero.list_tasks", "xero.create_task", "xero.list_time_entries", "xero.create_time_entry", "xero.list_project_users",
            "xero.list_budgets", "xero.get_budget",
            "xero.list_overpayments", "xero.list_prepayments", "xero.list_linked_transactions", "xero.list_statements", "xero.create_statement",
            "xero.balance_sheet_report", "xero.profit_loss_report", "xero.cash_flow_report",
            "xero.trial_balance_report", "xero.aged_payable_report", "xero.aged_receivable_report",
            "xero.executive_summary_report", "xero.budget_summary_report", "xero.bank_summary_report",
            "xero.bas_report", "xero.gst_report", "xero.payroll_summary_report",
            "xero.list_payroll_au_employees", "xero.list_payroll_au_payruns", "xero.list_payroll_au_payitems",
            "xero.list_payroll_au_employee_leave", "xero.list_payroll_au_employee_leave_balances",
            "xero.list_payroll_au_leave_periods", "xero.list_payroll_au_leave_types",
            "xero.list_payroll_au_superfunds", "xero.list_payroll_au_timesheets", "xero.list_employees_accounting",
            "xero.create_payroll_au_timesheet", "xero.get_payroll_au_timesheet",
            "xero.approve_payroll_au_timesheet", "xero.revert_payroll_au_timesheet",
            "xero.list_feed_connections", "xero.create_feed_connection", "xero.delete_feed_connection",
            "xero.api_request",
        ],
    },
    "clio": {
        "domain": "legal",
        "ops": [
            "clio.who_am_i", "clio.search", "clio.api_request", "clio.request",
            "clio.list_matters", "clio.get_matter", "clio.create_matter", "clio.update_matter",
            "clio.list_contacts", "clio.get_contact", "clio.create_contact",
            "clio.list_documents", "clio.get_document", "clio.upload_document",
            "clio.list_folders", "clio.create_folder",
            "clio.list_tasks", "clio.create_task",
            "clio.list_time_entries", "clio.create_time_entry",
            "clio.list_bills", "clio.create_bill",
            "clio.list_payments", "clio.list_payment_links", "clio.create_payment_link",
            "clio.list_calendars", "clio.list_communications", "clio.list_notes",
            "clio.list_activities", "clio.list_practice_areas", "clio.list_users", "clio.get_user",
            "clio.list_custom_fields", "clio.list_custom_actions", "clio.get_custom_action",
            "clio.create_custom_action", "clio.update_custom_action", "clio.delete_custom_action",
            "clio.list_grants", "clio.get_grant", "clio.create_grant", "clio.update_grant", "clio.delete_grant",
            "clio.list_damages", "clio.get_damage", "clio.create_damage", "clio.update_damage", "clio.delete_damage",
            "clio.list_medical_records_details", "clio.get_medical_records_detail",
            "clio.create_medical_records_detail", "clio.update_medical_records_detail",
            "clio.delete_medical_records_detail", "clio.update_medical_record", "clio.update_medical_bill",
            "clio.list_webhooks", "clio.get_webhook", "clio.create_webhook",
            "clio.update_webhook", "clio.delete_webhook",
        ],
    },
    "monday": {
        "domain": "it_ops",
        "ops": [
            "monday.list_workspaces", "monday.list_boards", "monday.get_board",
            "monday.create_board", "monday.duplicate_board", "monday.archive_board",
            "monday.list_items", "monday.get_item", "monday.search_items",
            "monday.create_item", "monday.delete_item", "monday.archive_item",
            "monday.move_item_to_group", "monday.create_subitem", "monday.list_subitems",
            "monday.change_column_value",
            "monday.create_group",
            "monday.list_updates", "monday.create_update",
            "monday.get_me", "monday.list_users", "monday.list_teams", "monday.list_docs",
            "monday.list_webhooks", "monday.create_webhook", "monday.delete_webhook",
            "monday.query_data",
        ],
    },
}


# ──────────────────────────────────────────────────────────────────────
# Risk classification heuristics. The platform team should review and
# adjust per-op; this is a sensible default so reviewers don't start
# from zero. Verbs that mutate state default to 'high', read-only to 'low'.
# ──────────────────────────────────────────────────────────────────────

_HIGH_RISK_VERBS = {
    "create", "update", "delete", "archive", "send", "post", "upload",
    "transition", "merge", "approve", "reject", "pay", "publish", "trigger",
    "schedule", "kick", "invite", "disable", "revoke", "dispose", "writeback",
    "remove", "rerun", "cancel", "duplicate", "submit", "move", "set",
    "edit", "delete_block", "request",
    "ingest", "bulk", "execute",
}


def risk_for(op: str) -> str:
    leaf = op.rsplit(".", 1)[-1]
    first_word = leaf.split("_", 1)[0]
    if first_word in _HIGH_RISK_VERBS:
        return "high"
    return "low"


def deterministic_uuid(tool_name: str) -> str:
    h = hashlib.sha256(f"lightbulb-mcp:{tool_name}".encode()).hexdigest()
    # Format as 8-4-4-4-12 with version 4 + variant bits set
    raw = list(h[:32])
    raw[12] = "4"
    raw[16] = "8"
    return f"{''.join(raw[0:8])}-{''.join(raw[8:12])}-{''.join(raw[12:16])}-{''.join(raw[16:20])}-{''.join(raw[20:32])}"


def main() -> int:
    out = Path(__file__).resolve().parent.parent.parent / (
        "springboot-server/src/main/resources/db/migration/V1441__seed_connector_tool_keys.sql"
    )

    rows: list[str] = []
    op_rows = 0
    seen: set[str] = set()
    for connector, meta in ADAPTER_OPS.items():
        domain = meta["domain"]
        for op in meta["ops"]:
            if op in seen:
                continue
            seen.add(op)
            risk = risk_for(op)
            timeout = 60 if risk == "high" else 30
            tool_uuid = deterministic_uuid(op)
            description = f"Connector op `{op}`. Routed via the bound tenant connector."
            input_schema = '{"type":"object","additionalProperties":true}'
            output_schema = '{"type":"object","additionalProperties":true}'
            rows.append(
                f"    ('{tool_uuid}', '{op}', '{domain}',\n"
                f"     '{description}',\n"
                f"     '{input_schema}',\n"
                f"     '{output_schema}',\n"
                f"     '{risk}', {timeout})"
            )
            op_rows += 1

    body = ",\n".join(rows)

    sql = (
        "-- Seed `tools` rows for every adapter operation already implemented\n"
        "-- on the platform. lightbulb-mcp v0.5.1 generates per-op MCP tools\n"
        "-- that POST to /api/tools/invoke with these toolName values; without\n"
        "-- these rows ToolRuntime.lookupTool() 404s and customers see\n"
        "-- generic dispatch errors.\n"
        "--\n"
        "-- Generated by lightbulb-sdk/scripts/generate_tool_seed_migration.py\n"
        "-- DO NOT EDIT BY HAND — re-run the generator if more ops are added\n"
        "-- to the adapter switch tables.\n"
        "--\n"
        "-- Risk-level defaults are heuristic (mutating verbs → high, reads → low).\n"
        "-- Platform team should review and tighten before applying.\n"
        "\n"
        "INSERT INTO tools (tool_id, name, domain, description, input_schema, output_schema, risk_level, timeout_seconds)\n"
        "VALUES\n"
        f"{body}\n"
        "ON CONFLICT (name) DO NOTHING;\n"
    )

    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(sql, encoding="utf-8")
    print(f"Wrote {out}")
    print(f"  total rows: {op_rows}")
    print(f"  connectors covered: {len(ADAPTER_OPS)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
