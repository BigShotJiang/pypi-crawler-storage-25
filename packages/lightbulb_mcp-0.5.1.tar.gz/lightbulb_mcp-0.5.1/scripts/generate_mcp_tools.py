"""Codegen for lightbulb/mcp_generated_tools.py.

Reads:
- agent-workers/agents/domain_registry.py → DOMAIN_ACTIONS dict (284 actions)
- scripts/connector_tool_keys.txt        → dotted tool keys (~574 ops)

Emits one MCP tool per (domain, action) and one per connector op, calling
the existing _get_client().dispatch() / .invoke_tool() machinery in mcp_server.

The generated module is imported at the bottom of mcp_server.py so the
@mcp.tool decorators register against the same FastMCP instance.

Re-run with:
    python3 scripts/generate_mcp_tools.py
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DOMAIN_REGISTRY = ROOT.parent / "agent-workers" / "agents" / "domain_registry.py"
TOOL_KEYS_FILE = ROOT / "scripts" / "connector_tool_keys.txt"
OUTPUT = ROOT / "lightbulb" / "mcp_generated_tools.py"
EXISTING_MCP = ROOT / "lightbulb" / "mcp_server.py"


def load_domain_actions() -> dict[str, list[str]]:
    """Parse DOMAIN_ACTIONS from agent-workers/agents/domain_registry.py."""
    sys.path.insert(0, str(DOMAIN_REGISTRY.parent.parent))
    try:
        from agents.domain_registry import DOMAIN_ACTIONS  # type: ignore
    finally:
        sys.path.pop(0)
    return dict(DOMAIN_ACTIONS)


def load_tool_keys() -> list[str]:
    """Read connector_tool_keys.txt (dotted format)."""
    text = TOOL_KEYS_FILE.read_text(encoding="utf-8")
    keys = sorted({line.strip() for line in text.splitlines() if line.strip()})
    return keys


def existing_tool_names() -> set[str]:
    """Names of the 156 hand-written @mcp.tool functions in mcp_server.py."""
    text = EXISTING_MCP.read_text(encoding="utf-8")
    pat = re.compile(r"@mcp\.tool\(\)\s*\ndef\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*\(", re.MULTILINE)
    return set(pat.findall(text))


def safe_python_name(name: str) -> str:
    """Convert a tool key like 'clio.create_matter' to a valid Python identifier."""
    name = name.replace(".", "_").replace("-", "_")
    name = re.sub(r"[^a-zA-Z0-9_]", "_", name)
    if not name or name[0].isdigit():
        name = "tool_" + name
    return name


def domain_action_py_name(domain: str, action: str) -> str:
    """`finance_finance_lbo_model` → `finance_lbo_model` (dedup redundant prefix)."""
    py = safe_python_name(f"{domain}_{action}")
    redundant = f"{domain}_{domain}_"
    if py.startswith(redundant):
        py = py[len(domain) + 1:]
    return py


# False-positive tool keys. The grep over Spring Boot source matched some
# string literals that aren't actually platform tools (URL fragments,
# config keys, etc). Filter these aggressively.
_OP_VERBS = {
    "list", "get", "create", "update", "delete", "remove", "add", "send",
    "post", "fetch", "search", "query", "invoke", "execute", "run", "build",
    "publish", "upload", "download", "approve", "reject", "cancel", "trigger",
    "set", "patch", "describe", "request", "review", "match", "modify", "move",
    "merge", "review_only", "who_am_i", "verify", "register", "unregister",
    "subscribe", "unsubscribe", "call", "log", "track", "import", "export",
    "sync", "refresh", "report", "open", "close", "complete",
}
_TLD_TAILS = {"com", "io", "net", "org", "co", "ai", "dev", "app", "uk", "us"}


def looks_like_real_op(tool_key: str) -> bool:
    """Skip URL-style fragments and obvious non-ops."""
    if "." not in tool_key:
        return False
    _, _, op = tool_key.partition(".")
    if not op:
        return False
    if op in _TLD_TAILS:  # e.g. microsoft.com
        return False
    if "_" in op:  # most real ops are snake_case multi-word
        return True
    # single-word op — only allow if it's a known verb
    return op in _OP_VERBS


def render_domain_action_tool(domain: str, action: str) -> str:
    """Generate one @mcp.tool wrapper for a (domain, action) pair."""
    py_name = domain_action_py_name(domain, action)
    return f'''
@mcp.tool()
def {py_name}(message: str = "", inputs: str = "{{}}") -> str:
    """Run the {domain} domain agent action `{action}`.

    Routes through the platform's domain-agent dispatcher under your JWT,
    tenant, and company scope.

    Args:
        message: Free-text objective for the action.
        inputs: Optional JSON string of structured inputs for the action.
    """
    parsed_inputs = {{}}
    if inputs and inputs.strip() != "{{}}":
        try:
            parsed_inputs = json.loads(inputs)
        except json.JSONDecodeError:
            return f"Error: 'inputs' must be valid JSON, got: {{inputs[:200]}}"

    def _do():
        return _get_client().dispatch({domain!r}, action={action!r}, message=message, inputs=parsed_inputs or None)
    return _format_result(_call_with_retry(_do))
'''


def render_connector_op_tool(tool_key: str, connector: str, op: str) -> str:
    """Generate one @mcp.tool wrapper for a connector operation."""
    py_name = safe_python_name(tool_key)
    return f'''
@mcp.tool()
def {py_name}(arguments: str = "{{}}") -> str:
    """{connector.capitalize()} connector operation `{op}` (platform tool `{tool_key}`).

    Routes through `/api/tools/invoke` under your JWT, tenant, and company scope.

    Args:
        arguments: JSON string of arguments for the connector operation.
    """
    parsed = {{}}
    if arguments and arguments.strip() != "{{}}":
        try:
            parsed = json.loads(arguments)
        except json.JSONDecodeError:
            return "Error: arguments must be valid JSON"

    def _do():
        return _get_client().invoke_tool({tool_key!r}, parsed)
    result = _call_with_retry(_do)
    return json.dumps(result, indent=2, default=str)[:5000]
'''


HEADER = '''"""Auto-generated MCP tool definitions — DO NOT EDIT BY HAND.

Generated by scripts/generate_mcp_tools.py from:
- agent-workers/agents/domain_registry.py (domain agent actions)
- scripts/connector_tool_keys.txt        (platform tool registry)

Imported at the bottom of mcp_server.py so the @mcp.tool decorators
register against the same FastMCP instance as the hand-written tools.

To regenerate:
    python3 scripts/generate_mcp_tools.py
"""

from __future__ import annotations

import json

from lightbulb.mcp_server import (
    _get_client,
    _format_result,
    _call_with_retry,
    mcp,
)
'''


def main() -> int:
    domain_actions = load_domain_actions()
    tool_keys = load_tool_keys()
    existing = existing_tool_names()

    # Plan the generation; skip names that collide with existing hand-written tools.
    domain_tools: list[tuple[str, str, str]] = []  # (py_name, domain, action)
    for domain, actions in sorted(domain_actions.items()):
        for action in actions:
            py_name = domain_action_py_name(domain, action)
            if py_name in existing:
                continue  # skip collisions; hand-written wins
            domain_tools.append((py_name, domain, action))

    seen_py_names = {n for n, _, _ in domain_tools} | existing
    connector_tools: list[tuple[str, str, str, str]] = []  # (py_name, key, connector, op)
    skipped_false_positive = 0
    for key in tool_keys:
        if not looks_like_real_op(key):
            skipped_false_positive += 1
            continue
        connector, _, op = key.partition(".")
        py_name = safe_python_name(key)
        if py_name in seen_py_names:
            continue
        seen_py_names.add(py_name)
        connector_tools.append((py_name, key, connector, op))

    # Emit
    parts: list[str] = [HEADER, ""]
    parts.append(f"# === Domain agent actions ({len(domain_tools)}) ===\n")
    for _, domain, action in domain_tools:
        parts.append(render_domain_action_tool(domain, action))
    parts.append(f"\n# === Connector operations ({len(connector_tools)}) ===\n")
    for _, key, connector, op in connector_tools:
        parts.append(render_connector_op_tool(key, connector, op))

    parts.append("\n")
    OUTPUT.write_text("".join(parts), encoding="utf-8")

    print(f"Wrote {OUTPUT}")
    print(f"  domain action tools  : {len(domain_tools)}")
    print(f"  connector op tools   : {len(connector_tools)}")
    print(f"  total generated      : {len(domain_tools) + len(connector_tools)}")
    print(f"  false-positives skipped: {skipped_false_positive}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
