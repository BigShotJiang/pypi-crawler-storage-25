"""Integration smoke tests — requires a running Lightbulb stack.

Run only when the full stack is up:
    LIGHTBULB_URL=http://localhost:8080 \
    LIGHTBULB_API_KEY=your-internal-api-key \
    LIGHTBULB_TENANT_ID=your-tenant-uuid \
    LIGHTBULB_USER_ID=your-user-uuid \
    LIGHTBULB_COMPANY_ID=your-company-uuid \
    python -m pytest tests/test_integration_smoke.py -v

Skip in CI unless explicitly enabled:
    LIGHTBULB_INTEGRATION=1 pytest tests/test_integration_smoke.py
"""

import os
import pytest

from lightbulb import LightbulbClient
from lightbulb.auth import exchange_local_api_key_for_jwt

INTEGRATION_ENABLED = os.getenv("LIGHTBULB_INTEGRATION", "").strip().lower() in ("1", "true", "yes")
LIGHTBULB_URL = os.getenv("LIGHTBULB_URL", "http://localhost:8080")
LIGHTBULB_API_KEY = os.getenv("LIGHTBULB_API_KEY", "")
LIGHTBULB_TENANT_ID = os.getenv("LIGHTBULB_TENANT_ID", "")
LIGHTBULB_USER_ID = os.getenv("LIGHTBULB_USER_ID", "")
LIGHTBULB_COMPANY_ID = os.getenv("LIGHTBULB_COMPANY_ID", "")

skip_unless_integration = pytest.mark.skipif(
    not INTEGRATION_ENABLED,
    reason="Set LIGHTBULB_INTEGRATION=1 and provide credentials to run integration tests",
)


def _client() -> LightbulbClient:
    if not LIGHTBULB_API_KEY or not LIGHTBULB_TENANT_ID or not LIGHTBULB_USER_ID:
        pytest.skip("Missing LIGHTBULB_API_KEY, LIGHTBULB_TENANT_ID, or LIGHTBULB_USER_ID")
    auth = exchange_local_api_key_for_jwt(
        LIGHTBULB_URL,
        api_key=LIGHTBULB_API_KEY,
        tenant_id=LIGHTBULB_TENANT_ID,
        user_id=LIGHTBULB_USER_ID,
        company_id=LIGHTBULB_COMPANY_ID or None,
    )
    return LightbulbClient(LIGHTBULB_URL, auth=auth, enforce_https=False)


@skip_unless_integration
class TestDocumentAgentSmoke:
    """Smoke tests that hit the real document_intelligence domain agent."""

    def test_search_documents(self):
        client = _client()
        result = client.search_documents("test document")
        assert result.domain == "document_intelligence"
        assert result.raw.get("action") in ("search_documents", "chat")

    def test_grep_content(self):
        client = _client()
        result = client.grep_documents("test", regex=False)
        assert result.domain == "document_intelligence"
        outputs = result.outputs
        assert "matches" in outputs or "status" in result.raw

    def test_list_folder_root(self):
        client = _client()
        result = client.list_folder("/")
        assert result.domain == "document_intelligence"
        outputs = result.outputs
        assert "items" in outputs or "status" in result.raw

    def test_create_and_verify_document(self):
        client = _client()
        result = client.create_document(
            "SDK Smoke Test Doc",
            "This document was created by the Lightbulb SDK integration test.",
            format="docx",
            target_suite="internal_library",
        )
        assert result.domain == "document_intelligence"
        # Should either succeed or return a meaningful error
        assert result.raw.get("action") == "write_document"


@skip_unless_integration
class TestDomainAgentSmoke:
    """Smoke tests that hit generic domain agent endpoints."""

    def test_list_conversations(self):
        client = _client()
        conversations = client.list_conversations("document_intelligence")
        assert isinstance(conversations, list)

    def test_create_and_delete_conversation(self):
        client = _client()
        conv = client.create_conversation("document_intelligence")
        assert "id" in conv

        client.delete_conversation("document_intelligence", conv["id"])

    def test_stream_chat_yields_events(self):
        client = _client()
        events = []
        for event in client.stream_chat("document_intelligence", message="Hello, what can you do?"):
            events.append(event)
            if event.event == "complete":
                break
            if len(events) > 100:
                break  # Safety cutoff

        assert len(events) > 0
        event_types = {e.event for e in events}
        # Should have at least a status or chat event
        assert event_types & {"status", "chat", "complete"}


@skip_unless_integration
class TestDocumentSessionSmoke:
    """Smoke tests for the document builder session API."""

    def test_create_and_list_sessions(self):
        client = _client()
        session = client.create_document_session(
            document_type="report",
            document_title="SDK Smoke Test Session",
        )
        assert "id" in session

        sessions = client.list_document_sessions()
        assert isinstance(sessions, list)
        assert any(s.get("id") == session["id"] for s in sessions)
