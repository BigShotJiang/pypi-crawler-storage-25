from __future__ import annotations

import importlib
import json
import os
import sys
from unittest.mock import Mock, patch

import pytest

from lightbulb.auth import JwtAuth


def _mcp_import_problem() -> str | None:
    sys.modules.pop("lightbulb.mcp_server", None)
    try:
        importlib.import_module("lightbulb.mcp_server")
    except Exception as exc:
        return str(exc)
    return None


_MCP_SKIP = _mcp_import_problem()
pytestmark = pytest.mark.skipif(
    _MCP_SKIP is not None,
    reason=_MCP_SKIP or "lightbulb.mcp_server unavailable",
)


def test_mcp_server_imports_without_fastmcp_schema_crash() -> None:
    sys.modules.pop("lightbulb.mcp_server", None)

    module = importlib.import_module("lightbulb.mcp_server")

    assert module.mcp is not None
    assert hasattr(module, "search_documents")


def test_mcp_server_supports_api_key_auth_env() -> None:
    sys.modules.pop("lightbulb.mcp_server", None)
    with patch.dict(
        os.environ,
        {
            "LIGHTBULB_API_KEY": "test-api-key-long-enough",
            "LIGHTBULB_TENANT_ID": "00000000-0000-0000-0000-000000000001",
            "LIGHTBULB_USER_ID": "00000000-0000-0000-0000-000000000002",
            "LIGHTBULB_COMPANY_ID": "00000000-0000-0000-0000-000000000003",
        },
        clear=False,
    ):
        module = importlib.import_module("lightbulb.mcp_server")
        with patch.object(
            module,
            "exchange_local_api_key_for_jwt",
            return_value=JwtAuth(
                token="eyJhbGciOiJIUzUxMiJ9.local-bootstrap.signature-here",
                tenant_id="00000000-0000-0000-0000-000000000001",
                company_id="00000000-0000-0000-0000-000000000003",
            ),
        ) as mock_exchange:
            auth = module._get_auth()

    assert auth.tenant_id == "00000000-0000-0000-0000-000000000001"
    assert auth.company_id == "00000000-0000-0000-0000-000000000003"
    mock_exchange.assert_called_once()


def test_list_code_workspaces_shows_ids_and_status() -> None:
    sys.modules.pop("lightbulb.mcp_server", None)
    module = importlib.import_module("lightbulb.mcp_server")

    client = Mock()
    client.list_code_workspaces.return_value = [
        {"id": "ws-123", "name": "Project401", "status": "READY", "branch": "main"},
    ]

    with patch.object(module, "_get_client", return_value=client):
        text = module.list_code_workspaces()

    assert "Project401" in text
    assert "`ws-123`" in text
    assert "READY" in text


def test_code_workspace_chat_forwards_rich_kwargs_and_formats_result() -> None:
    sys.modules.pop("lightbulb.mcp_server", None)
    module = importlib.import_module("lightbulb.mcp_server")

    client = Mock()
    client.code_workspace_chat.return_value = {
        "status": "completed",
        "reply": "Updated the handler and added coverage.",
        "runId": "run-123",
        "conversation_id": "conv-1",
        "runtime_backend": "codex",
        "verification": {"status": "passed", "summary": "2 tests passed"},
        "changed_files": ["src/app.py", "tests/test_app.py"],
        "diff": "--- a/src/app.py\n+++ b/src/app.py",
    }

    with patch.object(module, "_get_client", return_value=client):
        text = module.code_workspace_chat(
            workspace_id="ws-1",
            message="Fix the handler",
            action="propose_changes",
            conversation_id="conv-1",
            active_file="src/app.py",
            history='[{"role":"user","content":"previous"}]',
            context='{"selected_text":"handler"}',
            preview_mode=True,
        )

    client.code_workspace_chat.assert_called_once_with(
        "ws-1",
        "Fix the handler",
        action="chat",
        conversation_id="conv-1",
        active_file="src/app.py",
        history=[{"role": "user", "content": "previous"}],
        context={"selected_text": "handler"},
        preview_mode=True,
    )
    assert "Status: `completed`" in text
    assert "Run ID: `run-123`" in text
    assert "Verification: `passed`" in text
    assert "src/app.py" in text


def test_code_workspace_chat_rejects_invalid_json() -> None:
    sys.modules.pop("lightbulb.mcp_server", None)
    module = importlib.import_module("lightbulb.mcp_server")

    text = module.code_workspace_chat(
        workspace_id="ws-1",
        message="Fix the handler",
        context="{not-json}",
    )

    assert "Error:" in text
    assert "context must be valid JSON" in text


def test_stripe_raw_api_request_tool_uses_governed_sdk_path() -> None:
    sys.modules.pop("lightbulb.mcp_server", None)
    module = importlib.import_module("lightbulb.mcp_server")

    stripe_client = Mock()
    stripe_client.raw_api_request.return_value = {"success": True}

    with patch.object(module, "_stripe_client", return_value=stripe_client):
        text = module.stripe_raw_api_request(
            api_path="/v1/setup_intents",
            method="GET",
            params='{"limit":3}',
            stripe_account_id="acct_123",
            base_address="api",
        )

    stripe_client.raw_api_request.assert_called_once_with(
        "/v1/setup_intents",
        method="GET",
        params={"limit": 3},
        stripe_account_id="acct_123",
        base_address="api",
    )
    assert '"success": true' in text


def test_software_delivery_context_aggregates_loop_context() -> None:
    sys.modules.pop("lightbulb.mcp_server", None)
    module = importlib.import_module("lightbulb.mcp_server")

    client = Mock()
    client.workspace_bundle.side_effect = lambda domain: {"domain": domain, "status": "ok"}
    client.it_ops_mcp_manifest.return_value = {"tools": ["software_delivery_loop"]}
    client.list_code_workspace_runs.return_value = [{"id": "run-1"}]
    client.code_workspace_runs_insights.return_value = {"success_rate": 1.0}
    client.get_code_workspace_active_run.return_value = None

    with patch.object(module, "_get_client", return_value=client):
        text = module.software_delivery_context(
            repository="acme/platform",
            workspace_id="ws-1",
            project_key="IT",
            include_live=False,
            include_memory=False,
        )

    payload = json.loads(text)
    assert payload["schema"] == "lightbulb.mcp.software_delivery_context.v1"
    assert payload["repository"] == "acme/platform"
    assert payload["sources"]["it_ops_workspace"]["domain"] == "it_ops"
    assert payload["sources"]["coding_workspace"]["domain"] == "coding"
    assert payload["sources"]["code_workspace_runs"][0]["id"] == "run-1"
    assert "software_spot_weld_fix" in payload["recommended_next_tools"]


def test_software_delivery_loop_dispatches_it_ops_with_repo_binding() -> None:
    sys.modules.pop("lightbulb.mcp_server", None)
    module = importlib.import_module("lightbulb.mcp_server")

    client = Mock()
    client.dispatch.return_value = {
        "reply": "Loop started.",
        "outputs": {"status": "completed", "summary": "Ready."},
        "traceId": "trace-1",
    }

    with patch.object(module, "_get_client", return_value=client):
        text = module.software_delivery_loop(
            request="Turn checkout feedback into a fix",
            workspace_id="ws-1",
            repository="acme/platform",
            project_key="IT",
            mode="feedback_to_code",
            open_pr=True,
            extra_inputs='{"ticket_key":"IT-123"}',
        )

    payload = json.loads(text)
    assert payload["schema"] == "lightbulb.mcp.software_delivery_response.v1"
    assert payload["status"] == "completed"
    kwargs = client.dispatch.call_args.kwargs
    assert kwargs["action"] == "feedback_to_code_loop"
    assert kwargs["inputs"]["github_repository"]["full_name"] == "acme/platform"
    assert kwargs["inputs"]["repo_binding_required"] is True
    assert kwargs["inputs"]["software_delivery_loop"] is True
    assert kwargs["inputs"]["ticket_key"] == "IT-123"


def test_software_spot_weld_fix_routes_cloud_scope_to_gated_cloud_delivery() -> None:
    sys.modules.pop("lightbulb.mcp_server", None)
    module = importlib.import_module("lightbulb.mcp_server")

    client = Mock()
    client.dispatch.return_value = {
        "reply": "Spot weld routed.",
        "outputs": {"status": "pending_approval"},
    }

    with patch.object(module, "_get_client", return_value=client):
        text = module.software_spot_weld_fix(
            request="Stabilize production container rollout",
            workspace_id="ws-1",
            repository="acme/platform",
            environment="production",
            scope="cloud",
        )

    payload = json.loads(text)
    assert payload["status"] == "pending_approval"
    kwargs = client.dispatch.call_args.kwargs
    assert kwargs["action"] == "cloud_delivery_setup"
    assert kwargs["inputs"]["preview_mode"] is True
    assert kwargs["inputs"]["open_pr"] is True
    assert kwargs["inputs"]["trigger_deploy"] is False
    assert kwargs["inputs"]["cloud_ops_review_required"] is True
    assert kwargs["inputs"]["spot_weld_fix"]["requires_human_approval"] is True


def test_code_workspace_wait_for_run_uses_active_run_when_run_id_missing() -> None:
    sys.modules.pop("lightbulb.mcp_server", None)
    module = importlib.import_module("lightbulb.mcp_server")

    client = Mock()
    client.get_code_workspace_active_run.return_value = {"id": "run-9", "status": "running"}
    client.get_code_workspace_run.side_effect = [
        {"id": "run-9", "status": "running"},
        {
            "id": "run-9",
            "status": "completed",
            "replyText": "Finished successfully.",
            "verificationJson": {"status": "passed"},
        },
    ]

    with patch.object(module, "_get_client", return_value=client), patch.object(module.time, "sleep", return_value=None):
        text = module.code_workspace_wait_for_run("ws-1", timeout_seconds=5, poll_interval_seconds=1)

    assert "Finished successfully." in text
    assert "Status: `completed`" in text


def test_code_workspace_wait_for_run_treats_pending_approval_as_terminal() -> None:
    sys.modules.pop("lightbulb.mcp_server", None)
    module = importlib.import_module("lightbulb.mcp_server")

    client = Mock()
    client.get_code_workspace_run.return_value = {
        "id": "run-approval",
        "status": "pending_approval",
        "phase": "awaiting_approval",
        "approvalState": {"status": "pending", "approval_required": True},
    }

    with patch.object(module, "_get_client", return_value=client), patch.object(module.time, "sleep", return_value=None):
        text = module.code_workspace_wait_for_run("ws-1", run_id="run-approval", timeout_seconds=5, poll_interval_seconds=1)

    assert "Status: `pending_approval`" in text
    assert "Approval: `pending`" in text
    client.get_code_workspace_run.assert_called_once_with("ws-1", "run-approval")
