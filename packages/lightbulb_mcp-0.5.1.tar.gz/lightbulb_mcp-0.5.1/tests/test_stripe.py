"""Tests for the typed Stripe orchestration SDK client."""

import pytest

from lightbulb.auth import ApiKeyAuth
from lightbulb.client import LightbulbClient
from lightbulb.stripe import StripeOrchestratorClient, StripeWorkflow


TENANT = "00000000-0000-0000-0000-000000000001"
USER = "00000000-0000-0000-0000-000000000002"


def _client():
    return LightbulbClient(
        "http://localhost:8080",
        auth=ApiKeyAuth(
            api_key="test-api-key-long-enough",
            tenant_id=TENANT,
            user_id=USER,
        ),
    )


class TestStripeOrchestratorClient:

    def test_dispatch_uses_generic_stripe_tool(self, monkeypatch):
        inner = _client()
        stripe = StripeOrchestratorClient(inner)
        calls = []

        def invoke(tool_name, arguments):
            calls.append((tool_name, arguments))
            return {"success": True}

        monkeypatch.setattr(inner, "invoke_tool", invoke)

        result = stripe.dispatch(
            "customers",
            "list",
            {"limit": 10},
            stripe_account_id="acct_123",
        )

        assert result == {"success": True}
        assert calls == [(
            "stripe.dispatch",
            {
                "resource": "customers",
                "verb": "list",
                "inputs": {"limit": 10},
                "stripe_account_id": "acct_123",
            },
        )]

    def test_raw_api_request_dispatches_to_governed_fallback(self, monkeypatch):
        inner = _client()
        stripe = StripeOrchestratorClient(inner)
        calls = []

        def invoke(tool_name, arguments):
            calls.append((tool_name, arguments))
            return {"success": True, "queued": False}

        monkeypatch.setattr(inner, "invoke_tool", invoke)

        stripe.raw_api_request(
            "/v1/setup_intents",
            method="GET",
            params={"limit": 3},
            base_address="api",
        )

        assert calls == [(
            "stripe.dispatch",
            {
                "resource": "api",
                "verb": "request",
                "inputs": {
                    "api_path": "/v1/setup_intents",
                    "method": "GET",
                    "params": {"limit": 3},
                    "base_address": "api",
                },
            },
        )]

    def test_mcp_invoke_passes_tool_arguments(self, monkeypatch):
        inner = _client()
        stripe = StripeOrchestratorClient(inner)
        calls = []

        monkeypatch.setattr(
            inner,
            "invoke_tool",
            lambda tool_name, arguments: calls.append((tool_name, arguments)) or {"ok": True},
        )

        stripe.mcp_invoke(
            "search_stripe_documentation",
            {"query": "payment links"},
            stripe_account_id="acct_999",
        )

        assert calls == [(
            "stripe.mcp.invoke",
            {
                "tool": "search_stripe_documentation",
                "arguments": {"query": "payment links"},
                "stripe_account_id": "acct_999",
            },
        )]

    def test_workflow_rejects_unknown_name(self):
        stripe = StripeOrchestratorClient(_client())

        with pytest.raises(ValueError):
            stripe.run_workflow("workflow.not_real")

    def test_agent_toolkit_includes_raw_api_tool(self, monkeypatch):
        inner = _client()
        stripe = StripeOrchestratorClient(inner)
        calls = []

        monkeypatch.setattr(
            inner,
            "invoke_tool",
            lambda tool_name, arguments: calls.append((tool_name, arguments)) or {"ok": True},
        )

        tools = {tool["name"]: tool for tool in stripe.as_agent_toolkit_tools()}
        tools["stripe_api_request"]["call"]({"api_path": "/v1/topups", "method": "GET"})

        assert "stripe_api_request" in tools
        assert calls == [(
            "stripe.dispatch",
            {
                "resource": "api",
                "verb": "request",
                "inputs": {"api_path": "/v1/topups", "method": "GET"},
            },
        )]

    def test_workflow_catalog_contains_expected_ids(self):
        assert StripeWorkflow.FAILED_PAYMENT_RECOVERY in StripeWorkflow.all()
        assert StripeWorkflow.SUBSCRIPTION_HEALTH_AUDIT in StripeWorkflow.all()
