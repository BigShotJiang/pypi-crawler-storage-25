"""Tests for SSE streaming methods on LightbulbClient."""

import json
import httpx
import pytest
from unittest.mock import MagicMock, patch

from lightbulb.auth import ApiKeyAuth
from lightbulb.client import LightbulbClient, SSEEvent


TENANT = "00000000-0000-0000-0000-000000000001"
USER = "00000000-0000-0000-0000-000000000002"


def _auth():
    return ApiKeyAuth(
        api_key="test-api-key-long-enough",
        tenant_id=TENANT,
        user_id=USER,
    )


def _client():
    return LightbulbClient("http://localhost:8080", auth=_auth())


def _make_stream_cm(lines):
    """Build a context manager that yields a Response-like object whose
    iter_lines() returns the given lines."""
    response = MagicMock()
    response.raise_for_status = MagicMock()
    response.iter_lines.return_value = iter(lines)

    cm = MagicMock()
    cm.__enter__.return_value = response
    cm.__exit__.return_value = False
    return cm


class TestStreamCodeWorkspaceChat:

    def test_yields_sse_events(self):
        client = _client()
        cm = _make_stream_cm([
            "event: status",
            'data: {"phase":"started"}',
            "",
            "event: token",
            'data: {"text":"hello"}',
            "",
            "event: complete",
            'data: {"reply":"done"}',
            "",
        ])

        with patch.object(httpx.Client, "stream", return_value=cm) as mock_stream:
            events = list(client.stream_code_workspace_chat("ws-1", "Fix bug"))

        assert len(events) == 3
        assert all(isinstance(e, SSEEvent) for e in events)
        assert events[0].event == "status"
        assert events[0].data == {"phase": "started"}
        assert events[1].event == "token"
        assert events[1].data == {"text": "hello"}
        assert events[2].event == "complete"
        assert events[2].data == {"reply": "done"}

        # Hit the right URL
        url = mock_stream.call_args.args[1]
        assert url.endswith("/api/code/workspaces/ws-1/chat/stream")
        # Body has the streaming payload shape
        payload = mock_stream.call_args.kwargs["json"]
        assert payload["workspace_id"] == "ws-1"
        assert payload["message"] == "Fix bug"

    def test_normalizes_optional_kwargs_in_streaming_payload(self):
        client = _client()
        cm = _make_stream_cm(["event: complete", 'data: {}', ""])

        with patch.object(httpx.Client, "stream", return_value=cm) as mock_stream:
            list(client.stream_code_workspace_chat(
                "ws-1", "go",
                conversation_id="conv-1",
                active_file="src/app.py",
                preview_mode=True,
            ))

        payload = mock_stream.call_args.kwargs["json"]
        # Snake-case kwargs become camelCase before being sent over the wire
        assert payload["conversationId"] == "conv-1"
        assert payload["activeFile"] == "src/app.py"
        assert payload["previewMode"] is True

    def test_rejects_empty_message(self):
        client = _client()
        with pytest.raises(ValueError, match="empty"):
            list(client.stream_code_workspace_chat("ws-1", ""))


class TestStreamPageBuilderMessage:

    def test_yields_events_and_hits_correct_url(self):
        client = _client()
        cm = _make_stream_cm([
            "event: page_update",
            'data: {"pages":["index"]}',
            "",
        ])
        with patch.object(httpx.Client, "stream", return_value=cm) as mock_stream:
            events = list(client.stream_page_builder_message("sess-1", "Add a hero"))

        assert len(events) == 1
        assert events[0].event == "page_update"
        assert events[0].data == {"pages": ["index"]}
        assert mock_stream.call_args.args[1].endswith(
            "/api/page-builder/sessions/sess-1/message"
        )

    def test_workspace_automation_stream_url(self):
        client = _client()
        cm = _make_stream_cm(["event: complete", 'data: {}', ""])
        with patch.object(httpx.Client, "stream", return_value=cm) as mock_stream:
            list(client.stream_page_builder_workspace_automation("sess-1"))

        assert mock_stream.call_args.args[1].endswith(
            "/api/page-builder/sessions/sess-1/workspace-automation/stream"
        )


class TestStreamDocumentBuilderMessage:

    def test_yields_events_and_hits_correct_url(self):
        client = _client()
        cm = _make_stream_cm([
            "event: token",
            'data: {"text":"chapter 1"}',
            "",
            "event: complete",
            'data: {"reply":"saved"}',
            "",
        ])
        with patch.object(httpx.Client, "stream", return_value=cm) as mock_stream:
            events = list(client.stream_document_builder_message("ds-9", "Write chapter"))

        assert [e.event for e in events] == ["token", "complete"]
        assert mock_stream.call_args.args[1].endswith(
            "/api/document-builder/sessions/ds-9/message"
        )


class TestSSEParserEdgeCases:

    def test_handles_keepalive_comments(self):
        """Lines starting with `:` are SSE comments and must not produce events."""
        client = _client()
        cm = _make_stream_cm([
            ": keepalive",
            "event: status",
            'data: {"ok":true}',
            "",
            ": another keepalive",
            "event: complete",
            'data: {}',
            "",
        ])
        with patch.object(httpx.Client, "stream", return_value=cm):
            events = list(client.stream_document_builder_message("ds-1", "x"))

        assert [e.event for e in events] == ["status", "complete"]

    def test_falls_back_to_raw_text_on_invalid_json(self):
        client = _client()
        cm = _make_stream_cm([
            "event: token",
            "data: not-valid-json{",
            "",
        ])
        with patch.object(httpx.Client, "stream", return_value=cm):
            events = list(client.stream_document_builder_message("ds-1", "x"))

        assert events[0].data == {"raw_text": "not-valid-json{"}

    def test_default_event_name_is_message(self):
        """Events with no `event:` line default to 'message'."""
        client = _client()
        cm = _make_stream_cm([
            'data: {"x":1}',
            "",
        ])
        with patch.object(httpx.Client, "stream", return_value=cm):
            events = list(client.stream_document_builder_message("ds-1", "x"))

        assert events[0].event == "message"
        assert events[0].data == {"x": 1}
