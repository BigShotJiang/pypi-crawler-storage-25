"""Tests for the Xero deep-integration client."""

import httpx
import pytest
from unittest.mock import MagicMock, patch

from lightbulb.auth import ApiKeyAuth
from lightbulb.client import LightbulbClient
from lightbulb.xero import XeroAgentClient, XeroPlaybook


def _client():
    return LightbulbClient(
        "http://localhost:8080",
        auth=ApiKeyAuth(
            api_key="test-api-key-long-enough",
            tenant_id="00000000-0000-0000-0000-000000000001",
            user_id="00000000-0000-0000-0000-000000000002",
        ),
    )


def _ok(json_body):
    m = MagicMock()
    m.status_code = 200
    m.raise_for_status = MagicMock()
    m.json.return_value = json_body
    return m


class TestXeroPlaybook:

    def test_all_constants_match(self):
        all_ids = XeroPlaybook.all()
        assert XeroPlaybook.MONTH_END_CLOSE in all_ids
        assert XeroPlaybook.AR_FOLLOWUP in all_ids
        assert XeroPlaybook.BANK_RECONCILIATION in all_ids
        assert XeroPlaybook.PAYROLL_TRUEUP in all_ids
        assert XeroPlaybook.REPORTING_PACK in all_ids

    def test_no_duplicates(self):
        ids = XeroPlaybook.all()
        assert len(ids) == len(set(ids))


class TestXeroAgentClient:

    def test_snapshot_post(self):
        inner = _client()
        x = XeroAgentClient(inner)
        with patch.object(httpx.Client, "post", return_value=_ok({"orgs": []})) as mock_post:
            x.snapshot()
        assert mock_post.call_args.args[0].endswith("/api/finance/xero/agent/snapshot")
        assert mock_post.call_args.kwargs["json"] == {}

    def test_snapshot_passes_body(self):
        inner = _client()
        x = XeroAgentClient(inner)
        with patch.object(httpx.Client, "post", return_value=_ok({})) as mock_post:
            x.snapshot({"xero_tenant_ids": ["tid-1"]})
        assert mock_post.call_args.kwargs["json"] == {"xero_tenant_ids": ["tid-1"]}

    def test_proposals(self):
        inner = _client()
        x = XeroAgentClient(inner)
        with patch.object(httpx.Client, "post", return_value=_ok({"proposals": []})) as mock_post:
            x.proposals({"kind": "bank_reconciliation"})
        assert mock_post.call_args.args[0].endswith("/api/finance/xero/agent/proposals")
        assert mock_post.call_args.kwargs["json"] == {"kind": "bank_reconciliation"}

    def test_create_proposal(self):
        inner = _client()
        x = XeroAgentClient(inner)
        with patch.object(httpx.Client, "post", return_value=_ok({"id": "p-1"})) as mock_post:
            x.create_proposal({"action": "reconcile"})
        assert mock_post.call_args.args[0].endswith("/api/finance/xero/agent/proposals/create")

    def test_approve_proposal(self):
        inner = _client()
        x = XeroAgentClient(inner)
        with patch.object(httpx.Client, "post", return_value=_ok({"approved": True})) as mock_post:
            x.approve_proposal("p-9")
        assert mock_post.call_args.args[0].endswith("/api/finance/xero/agent/proposals/p-9/approve")

    def test_reject_proposal_passes_reason(self):
        inner = _client()
        x = XeroAgentClient(inner)
        with patch.object(httpx.Client, "post", return_value=_ok({"rejected": True})) as mock_post:
            x.reject_proposal("p-9", reason="not enough evidence")
        assert mock_post.call_args.args[0].endswith("/api/finance/xero/agent/proposals/p-9/reject")
        assert mock_post.call_args.kwargs["json"] == {"reason": "not enough evidence"}

    def test_run_sync(self):
        inner = _client()
        x = XeroAgentClient(inner)
        with patch.object(httpx.Client, "post", return_value=_ok({"job_id": "j-1"})) as mock_post:
            x.run_sync()
        assert mock_post.call_args.args[0].endswith("/api/finance/xero/agent/sync/run")

    def test_run_playbook_uses_id_in_url(self):
        inner = _client()
        x = XeroAgentClient(inner)
        with patch.object(httpx.Client, "post", return_value=_ok({"queued": True})) as mock_post:
            x.run_playbook(XeroPlaybook.MONTH_END_CLOSE, {"period": "2026-04"})
        assert mock_post.call_args.args[0].endswith(
            f"/api/finance/xero/agent/playbook/{XeroPlaybook.MONTH_END_CLOSE}/run"
        )
        assert mock_post.call_args.kwargs["json"] == {"period": "2026-04"}

    def test_org_profile_get(self):
        inner = _client()
        x = XeroAgentClient(inner)
        with patch.object(httpx.Client, "get", return_value=_ok({"name": "Acme"})) as mock_get:
            x.org_profile("xero-tenant-1")
        assert mock_get.call_args.args[0].endswith(
            "/api/finance/xero/agent/orgs/xero-tenant-1/profile"
        )

    def test_propose_invoice(self):
        inner = _client()
        x = XeroAgentClient(inner)
        with patch.object(httpx.Client, "post", return_value=_ok({"id": "inv-1"})) as mock_post:
            x.propose_invoice({"contact_id": "c-1", "amount": 100})
        assert mock_post.call_args.args[0].endswith("/api/finance/xero/intake/invoice-proposal")

    def test_propose_bill(self):
        inner = _client()
        x = XeroAgentClient(inner)
        with patch.object(httpx.Client, "post", return_value=_ok({})) as mock_post:
            x.propose_bill({})
        assert mock_post.call_args.args[0].endswith("/api/finance/xero/intake/bill-proposal")

    def test_propose_journal(self):
        inner = _client()
        x = XeroAgentClient(inner)
        with patch.object(httpx.Client, "post", return_value=_ok({})) as mock_post:
            x.propose_journal({})
        assert mock_post.call_args.args[0].endswith("/api/finance/xero/intake/journal-proposal")

    def test_propose_payroll_trueup(self):
        inner = _client()
        x = XeroAgentClient(inner)
        with patch.object(httpx.Client, "post", return_value=_ok({})) as mock_post:
            x.propose_payroll_trueup({})
        assert mock_post.call_args.args[0].endswith(
            "/api/finance/xero/intake/payroll-trueup-proposal"
        )
