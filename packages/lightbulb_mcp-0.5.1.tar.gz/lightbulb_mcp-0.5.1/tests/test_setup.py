"""Tests for the guided setup module (lightbulb.setup)."""

import json
import re
import sys
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from lightbulb import setup as lb_setup
from lightbulb.setup import (
    DEFAULT_BASE_URL,
    SERVER_NAME,
    DetectedTool,
    ProbeResult,
    ToolTarget,
    build_command_args,
    build_env_block,
    build_mcp_entry,
    detect_tools,
    installed_targets,
    probe_connection,
    render_codex_toml_block,
    render_status_report,
    write_codex_toml,
    write_json_mcp_config,
)


class TestDetection:

    def test_detect_returns_all_targets(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        tools = detect_tools(project_dir=tmp_path)
        targets = [t.target for t in tools]
        assert ToolTarget.CLAUDE_CODE_PROJECT in targets
        assert ToolTarget.CLAUDE_CODE_USER in targets
        assert ToolTarget.CODEX in targets
        assert ToolTarget.CURSOR in targets

    def test_installed_targets_filters_by_presence(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        # Pretend Claude is installed and Codex config exists
        codex_config = tmp_path / ".codex" / "config.toml"
        codex_config.parent.mkdir(parents=True, exist_ok=True)
        codex_config.write_text("# existing\n")

        def fake_which(name: str):
            return "/usr/local/bin/claude" if name == "claude" else None

        with patch("lightbulb.setup.shutil.which", side_effect=fake_which):
            tools = detect_tools(project_dir=tmp_path)
            installed = installed_targets(tools)

        installed_targets_only = [t.target for t in installed]
        # Claude (binary on PATH) and Codex (config file present) should be
        # picked up; Cursor should not.
        assert ToolTarget.CODEX in installed_targets_only
        assert ToolTarget.CLAUDE_CODE_PROJECT in installed_targets_only or \
               ToolTarget.CLAUDE_CODE_USER in installed_targets_only
        assert ToolTarget.CURSOR not in installed_targets_only


class TestCommandPicker:

    def test_uses_console_script_when_on_path(self):
        with patch("lightbulb.setup.shutil.which", return_value="/usr/local/bin/lightbulb-mcp"):
            cmd, args = build_command_args()
        assert cmd == "lightbulb-mcp"
        assert args == []

    def test_falls_back_to_python_module(self):
        with patch("lightbulb.setup.shutil.which", return_value=None):
            cmd, args = build_command_args()
        assert args == ["-m", "lightbulb.mcp_server"]
        # Command should be a Python interpreter
        assert cmd.endswith("python") or cmd.endswith("python3") or "python" in cmd.lower()


class TestEnvAndEntryBuilders:

    def test_env_block_minimal(self):
        env = build_env_block("https://x.test/")
        assert env == {"LIGHTBULB_URL": "https://x.test"}

    def test_env_block_with_jwt(self):
        env = build_env_block("https://x.test", jwt="eyJabc", tenant_id="t-1")
        assert env["LIGHTBULB_JWT"] == "eyJabc"
        assert env["LIGHTBULB_TENANT_ID"] == "t-1"

    def test_mcp_entry_shape(self):
        with patch("lightbulb.setup.shutil.which", return_value=None):
            entry = build_mcp_entry("https://x.test")
        assert entry["args"] == ["-m", "lightbulb.mcp_server"]
        assert entry["env"]["LIGHTBULB_URL"] == "https://x.test"
        assert "cwd" not in entry  # unset → omitted

    def test_mcp_entry_with_cwd(self, tmp_path):
        with patch("lightbulb.setup.shutil.which", return_value=None):
            entry = build_mcp_entry("https://x.test", cwd=tmp_path)
        assert entry["cwd"] == str(tmp_path)


class TestJsonMcpWriter:

    def _entry(self):
        return {"command": "lightbulb-mcp", "args": [], "env": {"LIGHTBULB_URL": "https://x"}}

    def test_creates_new_file_with_server(self, tmp_path):
        cfg = tmp_path / ".mcp.json"
        path, replaced, backup = write_json_mcp_config(cfg, self._entry())
        assert path == cfg
        assert replaced is False
        assert backup is None
        data = json.loads(cfg.read_text())
        assert SERVER_NAME in data["mcpServers"]

    def test_preserves_other_servers(self, tmp_path):
        cfg = tmp_path / ".mcp.json"
        cfg.write_text(json.dumps({
            "mcpServers": {
                "stripe": {"command": "stripe-mcp"},
                "github": {"command": "github-mcp"},
            }
        }))
        write_json_mcp_config(cfg, self._entry())
        data = json.loads(cfg.read_text())
        assert set(data["mcpServers"].keys()) == {"stripe", "github", SERVER_NAME}

    def test_replaces_existing_lightbulb_entry(self, tmp_path):
        cfg = tmp_path / ".mcp.json"
        cfg.write_text(json.dumps({
            "mcpServers": {
                SERVER_NAME: {"command": "old-binary", "args": ["--legacy"]},
            }
        }))
        path, replaced, backup = write_json_mcp_config(cfg, self._entry())
        assert replaced is True
        assert backup is not None
        assert backup.exists()
        data = json.loads(cfg.read_text())
        assert data["mcpServers"][SERVER_NAME]["command"] == "lightbulb-mcp"

    def test_handles_invalid_existing_json(self, tmp_path):
        cfg = tmp_path / ".mcp.json"
        cfg.write_text("not valid json{")
        # Should treat as empty and not crash
        write_json_mcp_config(cfg, self._entry())
        data = json.loads(cfg.read_text())
        assert SERVER_NAME in data["mcpServers"]


class TestCodexTomlWriter:

    def test_renders_minimal_block(self):
        with patch("lightbulb.setup.shutil.which", return_value=None):
            block = render_codex_toml_block("https://agent.example.com/")
        assert "[mcp_servers.lightbulb]" in block
        assert "[mcp_servers.lightbulb.env]" in block
        assert "command = " in block
        assert 'LIGHTBULB_URL = "https://agent.example.com"' in block
        assert "args = [" in block
        assert "enabled = true" in block

    def test_renders_with_jwt(self):
        with patch("lightbulb.setup.shutil.which", return_value=None):
            block = render_codex_toml_block(
                "https://x.test", jwt="eyJtoken", tenant_id="t-1"
            )
        assert 'LIGHTBULB_JWT = "eyJtoken"' in block
        assert 'LIGHTBULB_TENANT_ID = "t-1"' in block

    def test_creates_new_file(self, tmp_path):
        cfg = tmp_path / ".codex" / "config.toml"
        with patch("lightbulb.setup.shutil.which", return_value=None):
            block = render_codex_toml_block("https://x.test")
        path, replaced, backup = write_codex_toml(cfg, block)
        assert path == cfg
        assert replaced is False
        assert backup is None
        text = cfg.read_text()
        assert "[mcp_servers.lightbulb]" in text

    def test_preserves_unrelated_blocks(self, tmp_path):
        cfg = tmp_path / "config.toml"
        existing = (
            'model = "gpt-5"\n'
            'service_tier = "fast"\n'
            '\n'
            '[plugins."github@openai-curated"]\n'
            'enabled = true\n'
        )
        cfg.write_text(existing)

        with patch("lightbulb.setup.shutil.which", return_value=None):
            block = render_codex_toml_block("https://x.test")
        path, replaced, backup = write_codex_toml(cfg, block)
        assert replaced is False
        assert backup is not None and backup.exists()

        text = cfg.read_text()
        # Original directives still present
        assert 'model = "gpt-5"' in text
        assert "[plugins.\"github@openai-curated\"]" in text
        # Lightbulb block appended
        assert "[mcp_servers.lightbulb]" in text

    def test_replaces_existing_lightbulb_blocks(self, tmp_path):
        cfg = tmp_path / "config.toml"
        cfg.write_text(
            'model = "gpt-5"\n'
            '\n'
            '[mcp_servers.lightbulb]\n'
            'command = "old-binary"\n'
            'args = ["--legacy"]\n'
            'enabled = true\n'
            '\n'
            '[mcp_servers.lightbulb.env]\n'
            'LIGHTBULB_URL = "https://OLD.test"\n'
        )
        with patch("lightbulb.setup.shutil.which", return_value=None):
            block = render_codex_toml_block("https://NEW.test")
        path, replaced, backup = write_codex_toml(cfg, block)
        assert replaced is True
        text = cfg.read_text()
        assert 'OLD.test' not in text
        assert 'NEW.test' in text
        assert "old-binary" not in text
        # Only one [mcp_servers.lightbulb] table now
        assert text.count("[mcp_servers.lightbulb]") == 1
        assert text.count("[mcp_servers.lightbulb.env]") == 1
        # Original `model` directive untouched
        assert 'model = "gpt-5"' in text

    def test_escapes_quotes_in_values(self, tmp_path):
        with patch("lightbulb.setup.shutil.which", return_value=None):
            block = render_codex_toml_block(
                "https://x.test",
                jwt='eyJ"bad"token',
                tenant_id="t-1",
            )
        # Quotes inside the JWT must be escaped, otherwise the TOML is invalid
        assert 'eyJ\\"bad\\"token' in block


class TestStatusReport:

    def test_status_report_lists_targets(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        report = render_status_report(DEFAULT_BASE_URL, project_dir=tmp_path)
        assert "Lightbulb SDK status" in report
        assert "Platform URL" in report
        assert ToolTarget.CODEX.label in report

    def test_reports_lightbulb_wired_in_for_codex(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        codex = tmp_path / ".codex" / "config.toml"
        codex.parent.mkdir(parents=True)
        codex.write_text(
            '[mcp_servers.lightbulb]\ncommand = "x"\nargs = []\nenabled = true\n'
        )
        report = render_status_report(DEFAULT_BASE_URL, project_dir=tmp_path)
        assert "lightbulb wired in" in report

    def test_reports_no_lightbulb_entry_for_existing_json(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        cfg = tmp_path / ".claude.json"
        cfg.write_text(json.dumps({"mcpServers": {"stripe": {"command": "stripe-mcp"}}}))
        report = render_status_report(DEFAULT_BASE_URL, project_dir=tmp_path)
        assert "no lightbulb entry" in report

    def test_prompts_for_setup_when_no_token(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        with patch("lightbulb.setup.load_cached_token", return_value=None):
            report = render_status_report(DEFAULT_BASE_URL, project_dir=tmp_path)
        assert "lightbulb setup" in report


class TestProbeConnection:

    def test_no_token_returns_unauthenticated(self):
        with patch("lightbulb.setup.load_cached_token", return_value=None):
            result = probe_connection(DEFAULT_BASE_URL)
        assert result.ok is False
        assert "lightbulb setup" in result.detail

    def test_with_jwt_calls_whoami(self):
        with patch("lightbulb.setup.LightbulbClient") as MockClient:
            instance = MockClient.return_value
            instance.whoami.return_value = {"email": "u@co.com", "role": "COMPANY"}

            result = probe_connection(
                DEFAULT_BASE_URL,
                jwt="eyJtoken-long-enough-for-validation",
                tenant_id="00000000-0000-0000-0000-000000000001",
            )
        assert result.ok is True
        assert "u@co.com" in result.detail

    def test_invalid_jwt_returns_friendly_error(self):
        result = probe_connection(DEFAULT_BASE_URL, jwt="short", tenant_id="00000000-0000-0000-0000-000000000001")
        assert result.ok is False
        assert "Invalid JWT" in result.detail

    def test_whoami_failure_returns_unhealthy(self):
        with patch("lightbulb.setup.LightbulbClient") as MockClient:
            MockClient.return_value.whoami.side_effect = RuntimeError("boom")

            result = probe_connection(
                DEFAULT_BASE_URL,
                jwt="eyJtoken-long-enough-for-validation",
                tenant_id="00000000-0000-0000-0000-000000000001",
            )
        assert result.ok is False
        assert "whoami() failed" in result.detail


class TestRunSetup:

    def test_skip_login_skips_device_flow(self, tmp_path, monkeypatch, capsys):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        with patch("lightbulb.setup.probe_connection") as probe, \
             patch("lightbulb.setup._pick_target", return_value=None) as picker:
            probe.return_value = ProbeResult(ok=True, detail="Authenticated")

            rc = lb_setup.run_setup(
                base_url="https://x.test",
                target=None,
                write=False,
                project_dir=tmp_path,
                skip_login=True,
            )

        assert rc == 0

    def test_writes_json_config_when_target_is_claude(self, tmp_path, monkeypatch, capsys):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        cfg = tmp_path / ".claude.json"

        with patch("lightbulb.setup.probe_connection") as probe:
            probe.return_value = ProbeResult(ok=True, detail="Authenticated")

            rc = lb_setup.run_setup(
                base_url="https://x.test",
                target=ToolTarget.CLAUDE_CODE_USER,
                write=True,
                project_dir=tmp_path,
                skip_login=True,
            )

        assert rc == 0
        assert cfg.exists()
        data = json.loads(cfg.read_text())
        assert SERVER_NAME in data["mcpServers"]
        assert data["mcpServers"][SERVER_NAME]["env"]["LIGHTBULB_URL"] == "https://x.test"

    def test_writes_codex_toml_when_target_is_codex(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        cfg = tmp_path / ".codex" / "config.toml"

        with patch("lightbulb.setup.probe_connection") as probe:
            probe.return_value = ProbeResult(ok=True, detail="Authenticated")

            rc = lb_setup.run_setup(
                base_url="https://x.test",
                target=ToolTarget.CODEX,
                write=True,
                project_dir=tmp_path,
                skip_login=True,
            )

        assert rc == 0
        text = cfg.read_text()
        assert "[mcp_servers.lightbulb]" in text
        assert "[mcp_servers.lightbulb.env]" in text
        assert 'LIGHTBULB_URL = "https://x.test"' in text

    def test_returns_nonzero_when_probe_fails(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        with patch("lightbulb.setup.probe_connection") as probe:
            probe.return_value = ProbeResult(ok=False, detail="No token")

            rc = lb_setup.run_setup(
                base_url="https://x.test",
                target=ToolTarget.CODEX,
                write=False,
                project_dir=tmp_path,
                skip_login=True,
            )
        assert rc == 1
