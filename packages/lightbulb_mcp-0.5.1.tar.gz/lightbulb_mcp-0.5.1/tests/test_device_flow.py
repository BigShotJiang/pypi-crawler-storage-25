"""Tests for device authorization flow and token cache."""

import json
import os
import stat
import sys
import time
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from lightbulb.auth import JwtAuth, device_login
from lightbulb.token_cache import (
    CACHE_DIR,
    load_cached_token,
    save_cached_token,
    clear_cached_token,
    _cache_path,
)


class TestTokenCache:

    def setup_method(self):
        self.test_url = "http://test-instance:8080"
        self.path = _cache_path(self.test_url)
        # Clean up before each test
        if self.path.exists():
            self.path.unlink()

    def teardown_method(self):
        if self.path.exists():
            self.path.unlink()

    def test_save_and_load_token(self, tmp_path, monkeypatch):
        monkeypatch.setattr("lightbulb.token_cache.CACHE_DIR", tmp_path)
        auth = JwtAuth(
            token="eyJhbGciOiJIUzUxMiJ9.test-payload-long-enough.signature",
            tenant_id="00000000-0000-0000-0000-000000000001",
            company_id="00000000-0000-0000-0000-000000000002",
        )
        save_cached_token("http://localhost:8080", auth, expires_in=3600)

        loaded = load_cached_token("http://localhost:8080")
        assert loaded is not None
        assert loaded.tenant_id == "00000000-0000-0000-0000-000000000001"
        assert loaded.company_id == "00000000-0000-0000-0000-000000000002"

    def test_expired_token_not_loaded(self, tmp_path, monkeypatch):
        monkeypatch.setattr("lightbulb.token_cache.CACHE_DIR", tmp_path)
        auth = JwtAuth(
            token="eyJhbGciOiJIUzUxMiJ9.test-payload-long-enough.signature",
            tenant_id="00000000-0000-0000-0000-000000000001",
        )
        save_cached_token("http://localhost:8080", auth, expires_in=-1)

        loaded = load_cached_token("http://localhost:8080")
        assert loaded is None

    def test_missing_token_returns_none(self, tmp_path, monkeypatch):
        monkeypatch.setattr("lightbulb.token_cache.CACHE_DIR", tmp_path)
        loaded = load_cached_token("http://nonexistent:8080")
        assert loaded is None

    def test_clear_removes_token(self, tmp_path, monkeypatch):
        monkeypatch.setattr("lightbulb.token_cache.CACHE_DIR", tmp_path)
        auth = JwtAuth(
            token="eyJhbGciOiJIUzUxMiJ9.test-payload-long-enough.signature",
            tenant_id="00000000-0000-0000-0000-000000000001",
        )
        save_cached_token("http://localhost:8080", auth)
        clear_cached_token("http://localhost:8080")

        loaded = load_cached_token("http://localhost:8080")
        assert loaded is None

    @pytest.mark.skipif(sys.platform == "win32", reason="POSIX directory permission bits")
    def test_file_permissions_are_secure(self, tmp_path, monkeypatch):
        monkeypatch.setattr("lightbulb.token_cache.CACHE_DIR", tmp_path)
        auth = JwtAuth(
            token="eyJhbGciOiJIUzUxMiJ9.test-payload-long-enough.signature",
            tenant_id="00000000-0000-0000-0000-000000000001",
        )
        save_cached_token("http://localhost:8080", auth)

        # Check cache dir permissions
        dir_mode = stat.S_IMODE(tmp_path.stat().st_mode)
        assert dir_mode & stat.S_IROTH == 0, "Cache dir should not be world-readable"

    @pytest.mark.skipif(sys.platform == "win32", reason="POSIX chmod semantics for insecure-file probe")
    def test_insecure_file_rejected(self, tmp_path, monkeypatch):
        monkeypatch.setattr("lightbulb.token_cache.CACHE_DIR", tmp_path)
        auth = JwtAuth(
            token="eyJhbGciOiJIUzUxMiJ9.test-payload-long-enough.signature",
            tenant_id="00000000-0000-0000-0000-000000000001",
        )
        save_cached_token("http://localhost:8080", auth)

        # Make the file world-readable
        from lightbulb.token_cache import _cache_path as _cp
        path = _cp("http://localhost:8080")
        os.chmod(path, 0o644)

        loaded = load_cached_token("http://localhost:8080")
        assert loaded is None  # Should refuse to read insecure file


class TestDeviceLogin:

    def test_device_login_full_flow(self):
        """Test the complete device login flow with mocked HTTP."""
        authorize_response = MagicMock()
        authorize_response.status_code = 200
        authorize_response.json.return_value = {
            "device_code": "abc123def456",
            "user_code": "BCDG-HJKM",
            "verification_uri": "http://localhost:3000/authorize/device",
            "verification_uri_complete": "http://localhost:3000/authorize/device?code=BCDG-HJKM",
            "expires_in": 900,
            "interval": 1,
        }

        # First poll: pending, second poll: approved
        pending_response = MagicMock()
        pending_response.status_code = 400
        pending_response.json.return_value = {
            "error": "authorization_pending",
            "error_description": "Waiting for user",
        }

        approved_response = MagicMock()
        approved_response.status_code = 200
        approved_response.json.return_value = {
            "access_token": "eyJhbGciOiJIUzUxMiJ9.approved-token.signature-long",
            "token_type": "Bearer",
            "expires_in": 86400,
            "tenant_id": "00000000-0000-0000-0000-000000000001",
            "company_id": "00000000-0000-0000-0000-000000000002",
        }

        call_count = {"n": 0}

        def mock_post(url, **kwargs):
            if "/authorize" in url:
                return authorize_response
            call_count["n"] += 1
            return pending_response if call_count["n"] <= 1 else approved_response

        with patch("lightbulb.auth.httpx.Client") as MockClient:
            instance = MockClient.return_value.__enter__.return_value
            instance.post.side_effect = mock_post

            with patch("time.sleep"):
                with patch("webbrowser.open"):
                    auth, expires_in = device_login(
                        "http://localhost:8080",
                        poll_interval=0.01,
                        open_browser=False,
                    )

        assert isinstance(auth, JwtAuth)
        assert auth.tenant_id == "00000000-0000-0000-0000-000000000001"
        assert auth.company_id == "00000000-0000-0000-0000-000000000002"
        assert expires_in == 86400

    def test_device_login_denied(self):
        authorize_response = MagicMock()
        authorize_response.status_code = 200
        authorize_response.json.return_value = {
            "device_code": "abc123",
            "user_code": "BCDG-HJKM",
            "verification_uri": "http://localhost:3000/authorize/device",
            "expires_in": 900,
            "interval": 1,
        }

        denied_response = MagicMock()
        denied_response.status_code = 403
        denied_response.json.return_value = {
            "error": "access_denied",
            "error_description": "User denied",
        }

        def mock_post(url, **kwargs):
            if "/authorize" in url:
                return authorize_response
            return denied_response

        with patch("lightbulb.auth.httpx.Client") as MockClient:
            instance = MockClient.return_value.__enter__.return_value
            instance.post.side_effect = mock_post

            with patch("time.sleep"):
                with pytest.raises(RuntimeError, match="denied"):
                    device_login("http://localhost:8080", poll_interval=0.01, open_browser=False)

    def test_device_login_expired(self):
        authorize_response = MagicMock()
        authorize_response.status_code = 200
        authorize_response.json.return_value = {
            "device_code": "abc123",
            "user_code": "BCDG-HJKM",
            "verification_uri": "http://localhost:3000/authorize/device",
            "expires_in": 1,  # Expires in 1 second
            "interval": 1,
        }

        expired_response = MagicMock()
        expired_response.status_code = 400
        expired_response.json.return_value = {
            "error": "expired_token",
            "error_description": "Code expired",
        }

        def mock_post(url, **kwargs):
            if "/authorize" in url:
                return authorize_response
            return expired_response

        with patch("lightbulb.auth.httpx.Client") as MockClient:
            instance = MockClient.return_value.__enter__.return_value
            instance.post.side_effect = mock_post

            with patch("time.sleep"):
                with pytest.raises(RuntimeError, match="expired"):
                    device_login("http://localhost:8080", poll_interval=0.01, open_browser=False)
