"""Tests for the lightbulb CLI."""

import json
import io
import pytest
from unittest.mock import MagicMock, patch

from lightbulb import cli
from lightbulb.client import DispatchResult


class TestParser:

    def test_parser_has_top_level_commands(self):
        parser = cli.build_parser()
        # All subcommands should be reachable via --help without erroring.
        for cmd in ("whoami", "ping", "list-domains", "list-companies", "logout"):
            args = parser.parse_args([cmd])
            assert args.command == cmd

    def test_dispatch_subcommand_required_args(self):
        parser = cli.build_parser()
        args = parser.parse_args(["dispatch", "finance", "-m", "hello"])
        assert args.domain == "finance"
        assert args.message == "hello"
        assert args.action == "chat"  # default

    def test_approvals_subcommand_routing(self):
        parser = cli.build_parser()
        args = parser.parse_args(["approvals", "approve", "task-1", "-c", "ok"])
        assert args.subcommand == "approve"
        assert args.task_id == "task-1"
        assert args.comment == "ok"

    def test_voice_subcommand_routing(self):
        parser = cli.build_parser()
        args = parser.parse_args(["voice", "list", "--limit", "5"])
        assert args.limit == 5

    def test_aoc_stop_requires_run_id(self):
        parser = cli.build_parser()
        args = parser.parse_args(["aoc", "stop", "run-9"])
        assert args.run_id == "run-9"

    def test_setup_subcommand_options(self):
        parser = cli.build_parser()
        args = parser.parse_args([
            "setup", "--target", "codex", "--url", "http://localhost:8080",
            "--yes", "--skip-login",
        ])
        assert args.command == "setup"
        assert args.target == "codex"
        assert args.url == "http://localhost:8080"
        assert args.yes is True
        assert args.skip_login is True

    def test_status_and_mcp_are_registered(self):
        parser = cli.build_parser()
        assert parser.parse_args(["status"]).command == "status"
        assert parser.parse_args(["mcp"]).command == "mcp"

    def test_bare_invocation_defaults_to_status(self):
        parser = cli.build_parser()
        args = parser.parse_args([])
        # No subcommand chosen
        assert getattr(args, "command", None) in (None, "")


class TestSetupAndStatusCommands:

    def test_status_command_calls_render(self, capsys):
        with patch("lightbulb.cli.setup_module.render_status_report",
                   return_value="STATUS REPORT") as render:
            rc = cli.main(["status"])
        assert rc == 0
        assert render.called
        assert "STATUS REPORT" in capsys.readouterr().out

    def test_bare_invocation_runs_status(self, capsys):
        with patch("lightbulb.cli.setup_module.render_status_report",
                   return_value="STATUS via default") as render:
            rc = cli.main([])
        assert rc == 0
        assert render.called
        assert "STATUS via default" in capsys.readouterr().out

    def test_setup_yes_flag_passes_write_true(self):
        with patch("lightbulb.cli.setup_module.run_setup", return_value=0) as run:
            rc = cli.main([
                "setup", "--target", "codex", "--url", "https://x.test",
                "--yes", "--skip-login",
            ])
        assert rc == 0
        kw = run.call_args.kwargs
        assert kw["target"].value == "codex"
        assert kw["base_url"] == "https://x.test"
        assert kw["write"] is True
        assert kw["skip_login"] is True

    def test_setup_no_write_flag_passes_write_false(self):
        with patch("lightbulb.cli.setup_module.run_setup", return_value=0) as run:
            cli.main(["setup", "--target", "codex", "--no-write", "--skip-login"])
        assert run.call_args.kwargs["write"] is False

    def test_setup_no_flags_passes_write_none(self):
        """No --yes / --no-write → run_setup gets write=None to ask interactively."""
        with patch("lightbulb.cli.setup_module.run_setup", return_value=0) as run:
            cli.main(["setup", "--target", "codex", "--skip-login"])
        assert run.call_args.kwargs["write"] is None

    def test_mcp_command_invokes_server_main(self):
        inner = MagicMock()
        with patch("lightbulb.cli._load_mcp_main", return_value=inner):
            rc = cli.main(["mcp"])
        assert rc == 0
        inner.assert_called_once()


class TestCommands:

    def _stub_client(self, **methods):
        """Build a MagicMock LightbulbClient with the given methods stubbed."""
        client = MagicMock()
        for name, value in methods.items():
            getattr(client, name).return_value = value
        return client

    def test_whoami_prints_json(self, capsys):
        stub = self._stub_client(whoami={"email": "u@co.com", "role": "COMPANY"})
        with patch.object(cli, "_client_from_env", return_value=stub):
            rc = cli.main(["whoami"])

        captured = capsys.readouterr()
        assert rc == 0
        parsed = json.loads(captured.out)
        assert parsed["email"] == "u@co.com"

    def test_list_domains(self, capsys):
        stub = self._stub_client(list_domains=[{"id": "finance"}, {"id": "crm"}])
        with patch.object(cli, "_client_from_env", return_value=stub):
            rc = cli.main(["list-domains"])

        captured = capsys.readouterr()
        assert rc == 0
        parsed = json.loads(captured.out)
        assert parsed[0]["id"] == "finance"

    def test_dispatch_passes_inputs_as_json(self, capsys):
        result = DispatchResult(
            domain="finance",
            action="chat",
            mode="completed",
            reply="ok",
            conversation_id="c-1",
            trace_id="t-1",
            outputs={"foo": "bar"},
            raw={"reply": "ok", "outputs": {"foo": "bar"}},
        )
        stub = MagicMock()
        stub.dispatch.return_value = result

        with patch.object(cli, "_client_from_env", return_value=stub):
            rc = cli.main([
                "dispatch", "finance",
                "--action", "query_data",
                "-m", "show me last month",
                "--inputs", '{"month": "2026-03"}',
            ])

        assert rc == 0
        kw = stub.dispatch.call_args.kwargs
        assert kw["action"] == "query_data"
        assert kw["message"] == "show me last month"
        assert kw["inputs"] == {"month": "2026-03"}

        captured = capsys.readouterr()
        parsed = json.loads(captured.out)
        assert parsed["reply"] == "ok"

    def test_dispatch_returns_nonzero_on_failure(self):
        result = DispatchResult(
            domain="finance",
            action="chat",
            mode="failed",
            reply="",
            conversation_id="",
            trace_id="",
            outputs={},
            raw={"state": "failed"},
        )
        stub = MagicMock()
        stub.dispatch.return_value = result

        with patch.object(cli, "_client_from_env", return_value=stub):
            rc = cli.main(["dispatch", "finance", "-m", "x"])
        assert rc == 2

    def test_search_documents(self, capsys):
        result = DispatchResult(
            domain="document_intelligence", action="search_documents",
            mode="completed", reply="found",
            conversation_id="c", trace_id="t",
            outputs={"top_hits": [{"document_id": "d-1"}]},
            raw={"outputs": {"top_hits": [{"document_id": "d-1"}]}},
        )
        stub = MagicMock()
        stub.search_documents.return_value = result

        with patch.object(cli, "_client_from_env", return_value=stub):
            rc = cli.main(["search-documents", "quarterly revenue", "--top-k", "5"])

        assert rc == 0
        kw = stub.search_documents.call_args.kwargs
        assert kw["top_k"] == 5

    def test_approvals_list(self, capsys):
        stub = self._stub_client(list_pending_approvals=[{"id": "task-1"}])
        with patch.object(cli, "_client_from_env", return_value=stub):
            rc = cli.main(["approvals", "list"])

        assert rc == 0
        parsed = json.loads(capsys.readouterr().out)
        assert parsed[0]["id"] == "task-1"

    def test_approvals_approve_passes_comment(self, capsys):
        stub = MagicMock()
        stub.approve_task.return_value = {"status": "approved"}

        with patch.object(cli, "_client_from_env", return_value=stub):
            rc = cli.main(["approvals", "approve", "task-1", "--comment", "looks good"])

        assert rc == 0
        stub.approve_task.assert_called_once_with("task-1", comments="looks good")

    def test_approvals_reject(self):
        stub = MagicMock()
        stub.reject_task.return_value = {"status": "rejected"}

        with patch.object(cli, "_client_from_env", return_value=stub):
            rc = cli.main(["approvals", "reject", "task-9", "-c", "no thanks"])

        assert rc == 0
        stub.reject_task.assert_called_once_with("task-9", comments="no thanks")

    def test_voice_list_passes_limit(self, capsys):
        stub = MagicMock()
        stub.list_voice_executions.return_value = [{"id": "e-1"}]

        with patch.object(cli, "_client_from_env", return_value=stub):
            rc = cli.main(["voice", "list", "--limit", "3"])

        assert rc == 0
        stub.list_voice_executions.assert_called_once_with(limit=3)

    def test_voice_get(self, capsys):
        stub = MagicMock()
        stub.get_voice_execution.return_value = {"id": "exec-1"}

        with patch.object(cli, "_client_from_env", return_value=stub):
            rc = cli.main(["voice", "get", "exec-1"])

        assert rc == 0
        stub.get_voice_execution.assert_called_once_with("exec-1")

    def test_aoc_stop(self, capsys):
        stub = MagicMock()
        stub.stop_aoc_run.return_value = {"stopped": True}

        with patch.object(cli, "_client_from_env", return_value=stub):
            rc = cli.main(["aoc", "stop", "run-9"])

        assert rc == 0
        stub.stop_aoc_run.assert_called_once_with("run-9")

    def test_ping_healthy(self, capsys):
        stub = MagicMock()
        stub.whoami.return_value = {"email": "u@co.com", "role": "COMPANY"}

        with patch.object(cli, "_client_from_env", return_value=stub):
            rc = cli.main(["ping"])

        assert rc == 0
        out = capsys.readouterr().out
        assert "ok" in out
        assert "u@co.com" in out

    def test_ping_unhealthy(self, capsys):
        with patch.object(cli, "_client_from_env", side_effect=RuntimeError("no auth")):
            rc = cli.main(["ping"])

        assert rc == 1
        out = capsys.readouterr().out
        assert "unhealthy" in out

    def test_main_returns_1_on_runtime_error(self, capsys):
        with patch.object(cli, "_client_from_env", side_effect=RuntimeError("boom")):
            rc = cli.main(["whoami"])
        assert rc == 1
        err = capsys.readouterr().err
        assert "error" in err
