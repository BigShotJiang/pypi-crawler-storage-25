"""Live coding-workspace smoke tests via the Lightbulb SDK and MCP.

Run only when the full local stack is up:
    LIGHTBULB_INTEGRATION=1 \
    LIGHTBULB_URL=http://localhost:8080 \
    LIGHTBULB_API_KEY=your-internal-api-key \
    LIGHTBULB_TENANT_ID=your-tenant-uuid \
    LIGHTBULB_USER_ID=your-user-uuid \
    LIGHTBULB_COMPANY_ID=your-company-uuid \
    python -m pytest tests/test_coding_workspace_integration_smoke.py -v
"""

from __future__ import annotations

import functools
import json
import os
import re
import subprocess
import uuid

import anyio
import pytest
from mcp import ClientSession
from mcp.client.stdio import StdioServerParameters, stdio_client

from lightbulb import LightbulbClient
from lightbulb.auth import exchange_local_api_key_for_jwt

INTEGRATION_ENABLED = os.getenv("LIGHTBULB_INTEGRATION", "").strip().lower() in ("1", "true", "yes")
LIGHTBULB_URL = os.getenv("LIGHTBULB_URL", "http://localhost:8080")
LIGHTBULB_API_KEY = os.getenv("LIGHTBULB_API_KEY", "")
LIGHTBULB_TENANT_ID = os.getenv("LIGHTBULB_TENANT_ID", "")
LIGHTBULB_USER_ID = os.getenv("LIGHTBULB_USER_ID", "")
LIGHTBULB_COMPANY_ID = os.getenv("LIGHTBULB_COMPANY_ID", "")
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
SDK_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
PYTHON_BIN = os.getenv("LIGHTBULB_MCP_PYTHON", os.sys.executable)
WORKSPACE_RUNNER_CONTAINER = os.getenv("LIGHTBULB_WORKSPACE_RUNNER_CONTAINER", "project401-workspace-runner")
RUN_ID_PATTERN = re.compile(r"Run ID: `([^`]+)`")

AGENTS_FIXTURE = """# Agent Orchestration Rules (Codex)

## Purpose
This smoke fixture exists to validate the Lightbulb coding agent safely.

## Workflow
1. Inspect the repository.
2. Propose changes carefully.
3. Keep read-only questions non-mutating.
"""

README_FIXTURE = """# Smoke Fixture Repo

This repository exists for the Lightbulb coding agent integration smoke test.
The demo service prints hello from `app.py`.
Use `AGENTS.md` for workflow guidance.
"""

APP_FIXTURE = 'print("hello from smoke fixture")\n'

skip_unless_integration = pytest.mark.skipif(
    not INTEGRATION_ENABLED,
    reason="Set LIGHTBULB_INTEGRATION=1 and provide Lightbulb credentials to run integration smoke tests",
)


def _client() -> LightbulbClient:
    if not LIGHTBULB_API_KEY or not LIGHTBULB_TENANT_ID or not LIGHTBULB_USER_ID:
        pytest.skip("Missing LIGHTBULB_API_KEY, LIGHTBULB_TENANT_ID, or LIGHTBULB_USER_ID")
    auth = exchange_local_api_key_for_jwt(
        LIGHTBULB_URL,
        api_key=LIGHTBULB_API_KEY,
        tenant_id=LIGHTBULB_TENANT_ID,
        user_id=LIGHTBULB_USER_ID,
        company_id=LIGHTBULB_COMPANY_ID or None,
    )
    return LightbulbClient(LIGHTBULB_URL, auth=auth, enforce_https=False)


def _run_docker_shell(script: str) -> str:
    result = subprocess.run(
        ["docker", "exec", WORKSPACE_RUNNER_CONTAINER, "sh", "-lc", script],
        check=True,
        text=True,
        capture_output=True,
    )
    return result.stdout


def _prepare_fixture_source() -> str:
    source_path = f"/tmp/lightbulb-coding-smoke-{uuid.uuid4().hex[:10]}"
    script = f"""set -e
rm -rf {source_path}
mkdir -p {source_path}
cat > {source_path}/AGENTS.md <<'EOF_AGENTS'
{AGENTS_FIXTURE}EOF_AGENTS
cat > {source_path}/README.md <<'EOF_README'
{README_FIXTURE}EOF_README
cat > {source_path}/app.py <<'EOF_APP'
{APP_FIXTURE}EOF_APP
"""
    _run_docker_shell(script)
    return source_path


def _remove_fixture_source(source_path: str) -> None:
    try:
        _run_docker_shell(f"rm -rf {source_path}")
    except Exception:
        # Keep cleanup best-effort for local smoke runs.
        pass


def _read_workspace_file(workspace_path: str, relative_path: str) -> str:
    escaped_path = (workspace_path.rstrip("/") + "/" + relative_path.lstrip("/")).replace("'", "'\"'\"'")
    return _run_docker_shell(f"cat '{escaped_path}'")


def _extract_run_id(text: str) -> str:
    match = RUN_ID_PATTERN.search(text or "")
    if not match:
        raise AssertionError(f"Expected MCP response to include a run id, got: {text}")
    return match.group(1)


def _mcp_env() -> dict[str, str]:
    env = os.environ.copy()
    env.update(
        {
            "PYTHONPATH": SDK_ROOT,
            "LIGHTBULB_URL": LIGHTBULB_URL,
            "LIGHTBULB_API_KEY": LIGHTBULB_API_KEY,
            "LIGHTBULB_TENANT_ID": LIGHTBULB_TENANT_ID,
            "LIGHTBULB_USER_ID": LIGHTBULB_USER_ID,
        }
    )
    if LIGHTBULB_COMPANY_ID:
        env["LIGHTBULB_COMPANY_ID"] = LIGHTBULB_COMPANY_ID
    return env


def _text_from_result(result: object) -> str:
    parts: list[str] = []
    for item in getattr(result, "content", []) or []:
        text = getattr(item, "text", None)
        if text:
            parts.append(text)
    return "\n".join(parts)


async def _run_mcp_chat(
    workspace_id: str,
    *,
    message: str,
    action: str = "chat",
    active_file: str = "",
    context: dict[str, object] | None = None,
    preview_mode: bool = False,
    timeout_seconds: int = 90,
) -> dict[str, str]:
    server = StdioServerParameters(
        command=PYTHON_BIN,
        args=["-m", "lightbulb.mcp_server"],
        env=_mcp_env(),
        cwd=PROJECT_ROOT,
    )
    async with stdio_client(server) as (read_stream, write_stream):
        async with ClientSession(read_stream, write_stream) as session:
            await session.initialize()
            chat_result = await session.call_tool(
                "code_workspace_chat",
                {
                    "workspace_id": workspace_id,
                    "message": message,
                    "action": action,
                    "active_file": active_file,
                    "context": json.dumps(context or {}),
                    "preview_mode": preview_mode,
                },
            )
            chat_text = _text_from_result(chat_result)
            run_id = _extract_run_id(chat_text)
            wait_result = await session.call_tool(
                "code_workspace_wait_for_run",
                {
                    "workspace_id": workspace_id,
                    "run_id": run_id,
                    "timeout_seconds": timeout_seconds,
                    "poll_interval_seconds": 3,
                },
            )
            wait_text = _text_from_result(wait_result)
            return {
                "chat_text": chat_text,
                "wait_text": wait_text,
                "run_id": run_id,
            }


@pytest.fixture
def smoke_workspace() -> dict[str, str]:
    client = _client()
    source_path = _prepare_fixture_source()
    label = f"lightbulb-coding-smoke-{uuid.uuid4().hex[:8]}"
    created = client.create_code_workspace(
        source=source_path,
        label=label,
        metadata={"suite": "coding_workspace_integration_smoke"},
        company_id=LIGHTBULB_COMPANY_ID or None,
    )
    workspace = created.get("workspace") or {}
    profile = created.get("profile") or {}
    workspace_id = str(workspace.get("id") or "").strip()
    workspace_path = str(profile.get("path") or "").strip()
    if not workspace_id or not workspace_path:
        raise AssertionError(f"Workspace creation returned unexpected payload: {created}")
    try:
        yield {
            "workspace_id": workspace_id,
            "workspace_path": workspace_path,
            "source_path": source_path,
        }
    finally:
        _remove_fixture_source(source_path)


@skip_unless_integration
def test_coding_workspace_preview_and_read_only_via_mcp(smoke_workspace: dict[str, str]):
    client = _client()
    workspace_id = smoke_workspace["workspace_id"]
    workspace_path = smoke_workspace["workspace_path"]

    agents_before = _read_workspace_file(workspace_path, "AGENTS.md")
    assert agents_before == AGENTS_FIXTURE

    preview = anyio.run(
        functools.partial(
            _run_mcp_chat,
            workspace_id,
            message=(
                "Preview only. In AGENTS.md, rename the heading '## Workflow' to "
                "'## Delivery Workflow'. Do not apply the change; only propose it and show the diff."
            ),
            action="propose_changes",
            active_file="AGENTS.md",
            preview_mode=True,
        )
    )

    assert "Preview only. Proposed changes were not applied." in preview["wait_text"]
    assert "Changed files: AGENTS.md" in preview["wait_text"]
    assert "## Delivery Workflow" in preview["wait_text"]

    preview_run = client.get_code_workspace_run(workspace_id, preview["run_id"])
    assert preview_run["status"] == "succeeded"
    assert preview_run["previewMode"] is True
    assert preview_run["backend"] == "coding-agent"
    assert preview_run["runtimeBackend"]
    assert preview_run["executionPath"]
    assert preview_run["changedFiles"] == ["AGENTS.md"]
    assert preview_run["verification"]["status"] == "skipped"

    agents_after = _read_workspace_file(workspace_path, "AGENTS.md")
    assert agents_after == AGENTS_FIXTURE

    readme_before = _read_workspace_file(workspace_path, "README.md")
    assert readme_before == README_FIXTURE

    read_only = anyio.run(
        functools.partial(
            _run_mcp_chat,
            workspace_id,
            message=(
                "Read-only request. Summarize README.md in three bullets. "
                "Do not modify files and do not run any commands."
            ),
            active_file="README.md",
        )
    )

    assert "Changed files:" not in read_only["wait_text"]
    assert "Smoke Fixture Repo" in read_only["wait_text"] or "demo service" in read_only["wait_text"]

    read_only_run = client.get_code_workspace_run(workspace_id, read_only["run_id"])
    assert read_only_run["status"] == "succeeded"
    assert read_only_run["previewMode"] in (None, False)
    assert read_only_run["changedFiles"] == []
    assert not read_only_run.get("diff")

    readme_after = _read_workspace_file(workspace_path, "README.md")
    assert readme_after == README_FIXTURE

    approval = anyio.run(
        functools.partial(
            _run_mcp_chat,
            workspace_id,
            message=(
                "Update README.md by appending a sentence that says this HITL smoke was approved. "
                "Use the workspace write tool to make the file change."
            ),
            active_file="README.md",
            context={
                "resolved_runtime_backend": "codex_app_server",
                "codex_approval_mode": "hitl",
            },
            timeout_seconds=120,
        )
    )

    assert "Status: `pending_approval`" in approval["wait_text"]
    assert "Approval: `pending`" in approval["wait_text"]

    approval_run = client.get_code_workspace_run(workspace_id, approval["run_id"])
    assert approval_run["status"] == "pending_approval"
    assert approval_run["phase"] == "awaiting_approval"
    assert approval_run["runtimeBackend"] == "codex_app_server"
    assert approval_run["executionPath"] == "codex_app_server_hitl_pending"
    assert approval_run["changedFiles"] == []
    assert approval_run["verification"]["status"] == "skipped"
    assert approval_run["approvalState"]["approval_required"] is True
    assert approval_run["approvalState"]["status"] == "pending"
    assert approval_run["approvalState"]["approval_task_id"]

    readme_after_approval = _read_workspace_file(workspace_path, "README.md")
    assert readme_after_approval == README_FIXTURE
