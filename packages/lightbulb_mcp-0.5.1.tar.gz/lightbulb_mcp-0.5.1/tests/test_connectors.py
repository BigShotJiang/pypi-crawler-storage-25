"""Tests for typed connector clients (Slack, Jira, BambooHR, Greenhouse, Monday)."""

import httpx
import pytest
from unittest.mock import MagicMock, patch

from lightbulb.auth import ApiKeyAuth
from lightbulb.client import LightbulbClient
from lightbulb.connectors import (
    BambooHRClient,
    GreenhouseClient,
    JiraClient,
    MondayClient,
    SlackClient,
)


TENANT = "00000000-0000-0000-0000-000000000001"
USER = "00000000-0000-0000-0000-000000000002"


def _client():
    return LightbulbClient(
        "http://localhost:8080",
        auth=ApiKeyAuth(
            api_key="test-api-key-long-enough",
            tenant_id=TENANT,
            user_id=USER,
        ),
    )


def _ok(json_body):
    m = MagicMock()
    m.status_code = 200
    m.raise_for_status = MagicMock()
    m.json.return_value = json_body
    return m


class TestSlackClient:

    def test_post_message(self):
        inner = _client()
        slack = SlackClient(inner)
        with patch.object(inner, "invoke_tool") as invoke:
            invoke.return_value = {"ok": True, "ts": "1.0"}
            slack.post_message(channel="#deals", text="hello")
        invoke.assert_called_once_with(
            "slack.post_message",
            {"channel": "#deals", "text": "hello"},
        )

    def test_post_message_with_thread(self):
        inner = _client()
        slack = SlackClient(inner)
        with patch.object(inner, "invoke_tool") as invoke:
            slack.post_message(channel="#deals", text="reply", thread_ts="1234.5")
        args = invoke.call_args.args
        assert args[1]["thread_ts"] == "1234.5"

    def test_post_message_with_blocks(self):
        inner = _client()
        slack = SlackClient(inner)
        with patch.object(inner, "invoke_tool") as invoke:
            slack.post_message(
                channel="#deals",
                text="fallback",
                blocks=[{"type": "section", "text": {"type": "mrkdwn", "text": "*hi*"}}],
            )
        assert invoke.call_args.args[1]["blocks"][0]["type"] == "section"

    def test_add_reaction(self):
        inner = _client()
        slack = SlackClient(inner)
        with patch.object(inner, "invoke_tool") as invoke:
            slack.add_reaction(channel="C1", ts="1.0", name="thumbsup")
        invoke.assert_called_once_with(
            "slack.add_reaction",
            {"channel": "C1", "ts": "1.0", "name": "thumbsup"},
        )

    def test_lookup_user(self):
        inner = _client()
        slack = SlackClient(inner)
        with patch.object(inner, "invoke_tool") as invoke:
            slack.lookup_user(email="a@b.com")
        invoke.assert_called_once_with("slack.lookup_user", {"email": "a@b.com"})

    def test_search_messages(self):
        inner = _client()
        slack = SlackClient(inner)
        with patch.object(inner, "invoke_tool") as invoke:
            slack.search_messages("revenue", count=5)
        invoke.assert_called_once_with(
            "slack.search_messages", {"query": "revenue", "count": 5}
        )


class TestJiraClient:

    def test_create_issue_minimum(self):
        inner = _client()
        jira = JiraClient(inner)
        with patch.object(inner, "invoke_tool") as invoke:
            jira.create_issue(project_key="ENG", summary="Bug", issue_type="Bug")
        invoke.assert_called_once_with(
            "jira.create_issue",
            {"project_key": "ENG", "summary": "Bug", "issue_type": "Bug"},
        )

    def test_create_issue_full(self):
        inner = _client()
        jira = JiraClient(inner)
        with patch.object(inner, "invoke_tool") as invoke:
            jira.create_issue(
                project_key="ENG",
                summary="Bug",
                issue_type="Bug",
                description="Repro steps...",
                assignee="alice",
                labels=["regression"],
                priority="High",
                custom_fields={"customfield_10001": "X"},
            )
        args = invoke.call_args.args[1]
        assert args["description"] == "Repro steps..."
        assert args["assignee"] == "alice"
        assert args["labels"] == ["regression"]
        assert args["priority"] == "High"
        assert args["custom_fields"] == {"customfield_10001": "X"}

    def test_search_issues_jql(self):
        inner = _client()
        jira = JiraClient(inner)
        with patch.object(inner, "invoke_tool") as invoke:
            jira.search_issues("project = ENG AND status = Open", max_results=10)
        invoke.assert_called_once_with(
            "jira.search_issues",
            {"jql": "project = ENG AND status = Open", "max_results": 10},
        )

    def test_transition_issue_with_comment(self):
        inner = _client()
        jira = JiraClient(inner)
        with patch.object(inner, "invoke_tool") as invoke:
            jira.transition_issue("ENG-1", "Done", comment="Shipped")
        invoke.assert_called_once_with(
            "jira.transition_issue",
            {"issue_key": "ENG-1", "transition": "Done", "comment": "Shipped"},
        )

    def test_link_issues(self):
        inner = _client()
        jira = JiraClient(inner)
        with patch.object(inner, "invoke_tool") as invoke:
            jira.link_issues(inward_key="ENG-1", outward_key="ENG-2", link_type="blocks")
        invoke.assert_called_once_with(
            "jira.link_issues",
            {"inward_key": "ENG-1", "outward_key": "ENG-2", "link_type": "blocks"},
        )

    def test_get_board_sprints_default_state(self):
        inner = _client()
        jira = JiraClient(inner)
        with patch.object(inner, "invoke_tool") as invoke:
            jira.get_board_sprints("board-1")
        invoke.assert_called_once_with(
            "jira.get_board_sprints", {"board_id": "board-1", "state": "active"}
        )


class TestBambooHRClient:

    def test_whos_out_routes_to_hr_live(self):
        inner = _client()
        bamboo = BambooHRClient(inner)
        with patch.object(inner, "hr_live_whos_out") as live:
            live.return_value = {"out": []}
            bamboo.whos_out()
        live.assert_called_once_with()

    def test_leave_balance_routes_to_hr_live(self):
        inner = _client()
        bamboo = BambooHRClient(inner)
        with patch.object(inner, "hr_live_leave_balance") as live:
            bamboo.leave_balance("emp-1")
        live.assert_called_once_with("emp-1")

    def test_health_routes_to_hr_live(self):
        inner = _client()
        bamboo = BambooHRClient(inner)
        with patch.object(inner, "hr_live_health") as live:
            bamboo.health()
        live.assert_called_once_with()

    def test_get_employee_uses_invoke_tool(self):
        inner = _client()
        bamboo = BambooHRClient(inner)
        with patch.object(inner, "invoke_tool") as invoke:
            bamboo.get_employee("emp-1")
        invoke.assert_called_once_with("bamboohr.get_employee", {"employee_id": "emp-1"})


class TestGreenhouseClient:

    def test_list_jobs_routes_to_hr_live(self):
        inner = _client()
        gh = GreenhouseClient(inner)
        with patch.object(inner, "hr_live_recruiting_jobs") as live:
            gh.list_jobs(status="open")
        live.assert_called_once_with(status="open")

    def test_advance_application_passes_body_kwarg(self):
        """The HR-live advance endpoint takes the body via kwarg `body=`."""
        inner = _client()
        gh = GreenhouseClient(inner)
        with patch.object(inner, "hr_live_advance_application") as live:
            gh.advance_application("app-1", {"stage_id": "next"})
        live.assert_called_once_with("app-1", body={"stage_id": "next"})

    def test_reject_application(self):
        inner = _client()
        gh = GreenhouseClient(inner)
        with patch.object(inner, "hr_live_reject_application") as live:
            gh.reject_application("app-1", {"reason": "off-topic"})
        live.assert_called_once_with("app-1", body={"reason": "off-topic"})

    def test_get_candidate_uses_invoke_tool(self):
        inner = _client()
        gh = GreenhouseClient(inner)
        with patch.object(inner, "invoke_tool") as invoke:
            gh.get_candidate("c-1")
        invoke.assert_called_once_with("greenhouse.get_candidate", {"candidate_id": "c-1"})


class TestMondayClient:

    def test_onboarding_board_routes_to_hr_live(self):
        inner = _client()
        monday = MondayClient(inner)
        with patch.object(inner, "hr_live_monday_onboarding_board") as live:
            monday.onboarding_board("checklist-1")
        live.assert_called_once_with("checklist-1")

    def test_create_item_includes_column_values(self):
        inner = _client()
        monday = MondayClient(inner)
        with patch.object(inner, "invoke_tool") as invoke:
            monday.create_item(
                board_id="b-1",
                group_id="g-1",
                item_name="New row",
                column_values={"status": "Working on it"},
            )
        invoke.assert_called_once_with(
            "monday.create_item",
            {
                "board_id": "b-1",
                "group_id": "g-1",
                "item_name": "New row",
                "column_values": {"status": "Working on it"},
            },
        )

    def test_create_item_omits_column_values_when_none(self):
        inner = _client()
        monday = MondayClient(inner)
        with patch.object(inner, "invoke_tool") as invoke:
            monday.create_item(board_id="b-1", group_id="g-1", item_name="x")
        assert "column_values" not in invoke.call_args.args[1]
