"""Tests for lightbulb.auth — credential validation and header injection."""

import json
import pytest
from unittest.mock import MagicMock, patch
from lightbulb.auth import (
    ApiKeyAuth,
    JwtAuth,
    TwoFactorRequired,
    complete_2fa_login,
    exchange_local_api_key_for_jwt,
    login,
    sso_redirect_url,
)


class TestApiKeyAuth:

    def test_valid_construction(self):
        auth = ApiKeyAuth(
            api_key="a-long-enough-api-key",
            tenant_id="00000000-0000-0000-0000-000000000001",
            user_id="00000000-0000-0000-0000-000000000002",
        )
        assert auth.tenant_id == "00000000-0000-0000-0000-000000000001"
        assert auth.company_id is None

    def test_with_company_id(self):
        auth = ApiKeyAuth(
            api_key="a-long-enough-api-key",
            tenant_id="00000000-0000-0000-0000-000000000001",
            user_id="00000000-0000-0000-0000-000000000002",
            company_id="00000000-0000-0000-0000-000000000003",
        )
        assert auth.company_id == "00000000-0000-0000-0000-000000000003"

    def test_rejects_short_api_key(self):
        with pytest.raises(ValueError, match="at least 16"):
            ApiKeyAuth(
                api_key="short",
                tenant_id="00000000-0000-0000-0000-000000000001",
                user_id="00000000-0000-0000-0000-000000000002",
            )

    def test_rejects_empty_api_key(self):
        with pytest.raises(ValueError):
            ApiKeyAuth(
                api_key="",
                tenant_id="00000000-0000-0000-0000-000000000001",
                user_id="00000000-0000-0000-0000-000000000002",
            )

    def test_rejects_invalid_tenant_id(self):
        with pytest.raises(ValueError, match="valid UUID"):
            ApiKeyAuth(
                api_key="a-long-enough-api-key",
                tenant_id="not-a-uuid",
                user_id="00000000-0000-0000-0000-000000000002",
            )

    def test_rejects_invalid_user_id(self):
        with pytest.raises(ValueError, match="valid UUID"):
            ApiKeyAuth(
                api_key="a-long-enough-api-key",
                tenant_id="00000000-0000-0000-0000-000000000001",
                user_id="bad",
            )

    def test_rejects_invalid_company_id(self):
        with pytest.raises(ValueError, match="valid UUID"):
            ApiKeyAuth(
                api_key="a-long-enough-api-key",
                tenant_id="00000000-0000-0000-0000-000000000001",
                user_id="00000000-0000-0000-0000-000000000002",
                company_id="bad",
            )

    def test_apply_injects_correct_headers(self):
        auth = ApiKeyAuth(
            api_key="super-secret-api-key-value",
            tenant_id="00000000-0000-0000-0000-000000000001",
            user_id="00000000-0000-0000-0000-000000000002",
            company_id="00000000-0000-0000-0000-000000000003",
        )
        headers = auth.apply({"Content-Type": "application/json"})
        assert headers["X-Internal-API-Key"] == "super-secret-api-key-value"
        assert headers["X-Tenant-Id"] == "00000000-0000-0000-0000-000000000001"
        assert headers["X-User-Id"] == "00000000-0000-0000-0000-000000000002"
        assert headers["X-Company-Id"] == "00000000-0000-0000-0000-000000000003"
        assert headers["Content-Type"] == "application/json"

    def test_apply_does_not_mutate_original_dict(self):
        auth = ApiKeyAuth(
            api_key="a-long-enough-api-key",
            tenant_id="00000000-0000-0000-0000-000000000001",
            user_id="00000000-0000-0000-0000-000000000002",
        )
        original = {"Existing": "header"}
        result = auth.apply(original)
        assert "X-Internal-API-Key" not in original
        assert "X-Internal-API-Key" in result

    def test_repr_does_not_leak_api_key(self):
        auth = ApiKeyAuth(
            api_key="super-secret-api-key-value",
            tenant_id="00000000-0000-0000-0000-000000000001",
            user_id="00000000-0000-0000-0000-000000000002",
        )
        r = repr(auth)
        assert "super-secret" not in r
        assert "tenant_id" in r


class TestJwtAuth:

    def test_valid_construction(self):
        auth = JwtAuth(
            token="eyJhbGciOiJIUzI1NiJ9.test-payload.signature",
            tenant_id="00000000-0000-0000-0000-000000000001",
        )
        assert auth.tenant_id == "00000000-0000-0000-0000-000000000001"

    def test_rejects_short_token(self):
        with pytest.raises(ValueError, match="at least 20"):
            JwtAuth(token="short", tenant_id="00000000-0000-0000-0000-000000000001")

    def test_apply_injects_bearer_header(self):
        token = "eyJhbGciOiJIUzI1NiJ9.test-payload.signature"
        auth = JwtAuth(
            token=token,
            tenant_id="00000000-0000-0000-0000-000000000001",
        )
        headers = auth.apply({})
        assert headers["Authorization"] == f"Bearer {token}"
        assert headers["X-Tenant-Id"] == "00000000-0000-0000-0000-000000000001"

    def test_repr_does_not_leak_token(self):
        auth = JwtAuth(
            token="eyJhbGciOiJIUzI1NiJ9.test-payload.signature",
            tenant_id="00000000-0000-0000-0000-000000000001",
        )
        r = repr(auth)
        assert "eyJ" not in r


class TestLogin:

    def test_login_returns_jwt_auth_with_user_scope(self):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "token": "eyJhbGciOiJIUzUxMiJ9.real-jwt-payload.signature-here",
            "user": {
                "tenantId": "00000000-0000-0000-0000-000000000001",
                "companyId": "00000000-0000-0000-0000-000000000003",
                "email": "user@company.com",
                "role": "COMPANY",
            },
        }

        with patch("lightbulb.auth.httpx.Client") as MockClient:
            instance = MockClient.return_value.__enter__.return_value
            instance.post.return_value = mock_response

            auth = login("http://localhost:8080", "user@company.com", "password123")

        assert isinstance(auth, JwtAuth)
        assert auth.tenant_id == "00000000-0000-0000-0000-000000000001"
        assert auth.company_id == "00000000-0000-0000-0000-000000000003"

        # Verify it applies Bearer auth, not internal API key
        headers = auth.apply({})
        assert "Authorization" in headers
        assert headers["Authorization"].startswith("Bearer ")
        assert "X-Internal-API-Key" not in headers

    def test_login_rejects_invalid_credentials(self):
        mock_response = MagicMock()
        mock_response.status_code = 401
        mock_response.text = "Unauthorized"

        with patch("lightbulb.auth.httpx.Client") as MockClient:
            instance = MockClient.return_value.__enter__.return_value
            instance.post.return_value = mock_response

            with pytest.raises(RuntimeError, match="invalid email or password"):
                login("http://localhost:8080", "bad@email.com", "wrongpass")

    def test_login_rejects_rate_limited(self):
        mock_response = MagicMock()
        mock_response.status_code = 429
        mock_response.text = "Too many requests"

        with patch("lightbulb.auth.httpx.Client") as MockClient:
            instance = MockClient.return_value.__enter__.return_value
            instance.post.return_value = mock_response

            with pytest.raises(RuntimeError, match="rate limited"):
                login("http://localhost:8080", "user@co.com", "pass")

    def test_login_rejects_missing_tenant(self):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "token": "eyJhbGciOiJIUzUxMiJ9.payload.sig-long-enough",
            "user": {"email": "user@co.com"},  # no tenantId
        }

        with patch("lightbulb.auth.httpx.Client") as MockClient:
            instance = MockClient.return_value.__enter__.return_value
            instance.post.return_value = mock_response

            with pytest.raises(ValueError, match="tenantId"):
                login("http://localhost:8080", "user@co.com", "pass")


class TestLocalApiKeyExchange:

    def test_exchange_local_api_key_for_jwt_returns_jwt_auth(self):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "token": "eyJhbGciOiJIUzUxMiJ9.local-bootstrap.signature-here",
            "tenant_id": "00000000-0000-0000-0000-000000000001",
            "user_id": "00000000-0000-0000-0000-000000000002",
        }

        with patch("lightbulb.auth.httpx.Client") as MockClient:
            instance = MockClient.return_value.__enter__.return_value
            instance.post.return_value = mock_response

            auth = exchange_local_api_key_for_jwt(
                "http://localhost:8080",
                "test-api-key-long-enough",
                "00000000-0000-0000-0000-000000000001",
                "00000000-0000-0000-0000-000000000002",
                "00000000-0000-0000-0000-000000000003",
            )

        assert isinstance(auth, JwtAuth)
        assert auth.tenant_id == "00000000-0000-0000-0000-000000000001"
        assert auth.company_id == "00000000-0000-0000-0000-000000000003"
        headers = auth.apply({})
        assert headers["Authorization"].startswith("Bearer ")
        assert "X-Internal-API-Key" not in headers


class TestTwoFactorLogin:

    def _resp(self, *, status=200, body=None):
        m = MagicMock()
        m.status_code = status
        m.text = "" if body is None else json.dumps(body)
        m.json.return_value = body or {}
        m.cookies = MagicMock()
        m.cookies.get.return_value = ""
        m.headers = MagicMock()
        m.headers.get_list.return_value = []
        return m

    def test_login_raises_two_factor_required_when_no_code(self):
        first = self._resp(body={"requires2FA": True, "message": "Enter code"})
        with patch("lightbulb.auth.httpx.Client") as MockClient:
            instance = MockClient.return_value.__enter__.return_value
            instance.post.return_value = first

            with pytest.raises(TwoFactorRequired) as excinfo:
                login("http://localhost:8080", "user@co.com", "pw")
        assert excinfo.value.email == "user@co.com"
        assert excinfo.value.base_url == "http://localhost:8080"
        assert "Enter code" in str(excinfo.value)

    def test_login_with_code_completes_two_factor_inline(self):
        first = self._resp(body={"requires2FA": True})
        second = self._resp(
            body={
                "token": "eyJhbGciOiJIUzUxMiJ9.real-payload-after-2fa.signature-here",
                "user": {
                    "tenantId": "00000000-0000-0000-0000-000000000001",
                    "companyId": "00000000-0000-0000-0000-000000000003",
                },
            }
        )

        with patch("lightbulb.auth.httpx.Client") as MockClient:
            instance = MockClient.return_value.__enter__.return_value
            instance.post.side_effect = [first, second]

            auth = login("http://localhost:8080", "user@co.com", "pw", code="123456")

        assert isinstance(auth, JwtAuth)
        assert auth.tenant_id == "00000000-0000-0000-0000-000000000001"
        # Second POST should be to /api/auth/login/2fa with the code
        second_call = instance.post.call_args_list[1]
        assert second_call.args[0].endswith("/api/auth/login/2fa")
        assert second_call.kwargs["json"] == {"email": "user@co.com", "code": "123456"}

    def test_complete_2fa_login_validates_code_format(self):
        with pytest.raises(ValueError, match="6 digits"):
            complete_2fa_login("http://localhost:8080", "user@co.com", "abc123")
        with pytest.raises(ValueError, match="6 digits"):
            complete_2fa_login("http://localhost:8080", "user@co.com", "12345")  # too short

    def test_complete_2fa_login_accepts_8_digit_backup_code(self):
        resp = self._resp(
            body={
                "token": "eyJhbGciOiJIUzUxMiJ9.backup-code-payload.sig-here-long",
                "user": {"tenantId": "00000000-0000-0000-0000-000000000001"},
            }
        )

        with patch("lightbulb.auth.httpx.Client") as MockClient:
            instance = MockClient.return_value.__enter__.return_value
            instance.post.return_value = resp

            auth = complete_2fa_login("http://localhost:8080", "user@co.com", "12345678")
        assert isinstance(auth, JwtAuth)

    def test_complete_2fa_login_rejects_invalid_code(self):
        resp = self._resp(status=401, body={})
        with patch("lightbulb.auth.httpx.Client") as MockClient:
            instance = MockClient.return_value.__enter__.return_value
            instance.post.return_value = resp

            with pytest.raises(RuntimeError, match="invalid or expired"):
                complete_2fa_login("http://localhost:8080", "user@co.com", "654321")

    def test_complete_2fa_login_rate_limited(self):
        resp = self._resp(status=429)
        with patch("lightbulb.auth.httpx.Client") as MockClient:
            instance = MockClient.return_value.__enter__.return_value
            instance.post.return_value = resp

            with pytest.raises(RuntimeError, match="rate-limited"):
                complete_2fa_login("http://localhost:8080", "user@co.com", "654321")

    def test_complete_2fa_login_missing_token(self):
        resp = self._resp(body={"user": {"tenantId": "00000000-0000-0000-0000-000000000001"}})
        with patch("lightbulb.auth.httpx.Client") as MockClient:
            instance = MockClient.return_value.__enter__.return_value
            instance.post.return_value = resp

            with pytest.raises(ValueError, match="missing JWT"):
                complete_2fa_login("http://localhost:8080", "user@co.com", "654321")

    def test_login_no_2fa_path_unchanged_passes_through(self):
        # Plain login (no MFA) must still work — regression guard
        resp = self._resp(
            body={
                "token": "eyJhbGciOiJIUzUxMiJ9.no-mfa-payload.sig-here-long-enough",
                "user": {"tenantId": "00000000-0000-0000-0000-000000000001"},
            }
        )
        with patch("lightbulb.auth.httpx.Client") as MockClient:
            instance = MockClient.return_value.__enter__.return_value
            instance.post.return_value = resp

            auth = login("http://localhost:8080", "user@co.com", "pw")
        assert isinstance(auth, JwtAuth)


class TestSsoRedirectUrl:

    def test_resolves_relative_path_to_absolute(self):
        resp = MagicMock()
        resp.status_code = 200
        resp.json.return_value = {"url": "/oauth2/authorization/google"}

        with patch("lightbulb.auth.httpx.Client") as MockClient:
            instance = MockClient.return_value.__enter__.return_value
            instance.get.return_value = resp

            url = sso_redirect_url("http://localhost:8080", "google")
        assert url == "http://localhost:8080/oauth2/authorization/google"

    def test_rejects_cross_host_absolute_url(self):
        """A malicious server returning an absolute URL on a different host
        must be rejected — otherwise the SSO redirect can be hijacked."""
        resp = MagicMock()
        resp.status_code = 200
        resp.json.return_value = {"url": "https://login.microsoftonline.com/oauth2/authorize"}

        with patch("lightbulb.auth.httpx.Client") as MockClient:
            instance = MockClient.return_value.__enter__.return_value
            instance.get.return_value = resp

            with pytest.raises(RuntimeError, match="does not match platform host"):
                sso_redirect_url("http://localhost:8080", "microsoft")

    def test_accepts_absolute_url_on_same_host(self):
        """An absolute URL whose host matches the platform is allowed."""
        resp = MagicMock()
        resp.status_code = 200
        resp.json.return_value = {"url": "http://localhost:8080/oauth2/authorization/google"}

        with patch("lightbulb.auth.httpx.Client") as MockClient:
            instance = MockClient.return_value.__enter__.return_value
            instance.get.return_value = resp

            url = sso_redirect_url("http://localhost:8080", "google")
        assert url == "http://localhost:8080/oauth2/authorization/google"

    def test_rejects_protocol_relative_url(self):
        """`//evil.com/...` was the original bypass — must be rejected."""
        resp = MagicMock()
        resp.status_code = 200
        resp.json.return_value = {"url": "//evil.com/steal-token"}

        with patch("lightbulb.auth.httpx.Client") as MockClient:
            instance = MockClient.return_value.__enter__.return_value
            instance.get.return_value = resp

            with pytest.raises(RuntimeError, match="protocol-relative"):
                sso_redirect_url("http://localhost:8080", "google")

    def test_rejects_javascript_scheme(self):
        resp = MagicMock()
        resp.status_code = 200
        resp.json.return_value = {"url": "javascript:fetch('http://evil.com')"}

        with patch("lightbulb.auth.httpx.Client") as MockClient:
            instance = MockClient.return_value.__enter__.return_value
            instance.get.return_value = resp

            with pytest.raises(RuntimeError, match="disallowed scheme"):
                sso_redirect_url("http://localhost:8080", "google")

    def test_rejects_unknown_provider(self):
        with pytest.raises(ValueError, match="google.*microsoft"):
            sso_redirect_url("http://localhost:8080", "linkedin")

    def test_raises_on_missing_url_field(self):
        resp = MagicMock()
        resp.status_code = 200
        resp.json.return_value = {}

        with patch("lightbulb.auth.httpx.Client") as MockClient:
            instance = MockClient.return_value.__enter__.return_value
            instance.get.return_value = resp

            with pytest.raises(RuntimeError, match="missing 'url'"):
                sso_redirect_url("http://localhost:8080", "google")
