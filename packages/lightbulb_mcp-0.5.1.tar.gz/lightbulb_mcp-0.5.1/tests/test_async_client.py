"""Tests for AsyncLightbulbClient."""

import json
import httpx
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from lightbulb.async_client import AsyncLightbulbClient
from lightbulb.auth import JwtAuth
from lightbulb.client import DispatchResult, SSEEvent


TENANT = "00000000-0000-0000-0000-000000000001"
COMPANY = "00000000-0000-0000-0000-000000000003"


def _auth():
    return JwtAuth(
        token="eyJhbGciOiJIUzUxMiJ9.test-payload-long-enough.signature",
        tenant_id=TENANT,
        company_id=COMPANY,
    )


def _ok(json_body, status: int = 200):
    m = MagicMock()
    m.status_code = status
    m.raise_for_status = MagicMock()
    m.json.return_value = json_body
    m.content = b"{}"
    return m


@pytest.fixture
def patched_async_client():
    """Patch httpx.AsyncClient so all AsyncLightbulbClient calls return mocks."""
    with patch("lightbulb.async_client.httpx.AsyncClient") as MockClass:
        instance = MockClass.return_value
        instance.is_closed = False
        instance.aclose = AsyncMock()
        instance.get = AsyncMock()
        instance.post = AsyncMock()
        yield instance


class TestConstruction:

    def test_rejects_http_for_non_localhost(self):
        with pytest.raises(ValueError, match="HTTPS is required"):
            AsyncLightbulbClient("http://agents.lightbulbpartners.com", auth=_auth())

    def test_allows_localhost_http(self):
        c = AsyncLightbulbClient("http://localhost:8080", auth=_auth())
        assert c.active_company_id == COMPANY


class TestAsyncDispatch:

    @pytest.mark.asyncio
    async def test_dispatch_returns_typed_result(self, patched_async_client):
        patched_async_client.post.return_value = _ok({
            "domain": "finance",
            "action": "chat",
            "mode": "workflow_completed",
            "reply": "ok",
            "conversationId": "c-1",
            "traceId": "t-1",
            "outputs": {},
        })

        async with AsyncLightbulbClient("http://localhost:8080", auth=_auth()) as c:
            result = await c.dispatch("finance", action="chat", message="hello")

        assert isinstance(result, DispatchResult)
        assert result.reply == "ok"
        assert result.conversation_id == "c-1"
        # Sent to dispatch URL
        urls = [call.args[0] for call in patched_async_client.post.call_args_list]
        assert any(u.endswith("/api/domain-agents/finance/dispatch") for u in urls)

    @pytest.mark.asyncio
    async def test_dispatch_validates_domain(self, patched_async_client):
        async with AsyncLightbulbClient("http://localhost:8080", auth=_auth()) as c:
            with pytest.raises(ValueError, match="Invalid domain"):
                await c.dispatch("../etc/passwd", action="chat", message="x")

    @pytest.mark.asyncio
    async def test_dispatch_uses_active_company_id(self, patched_async_client):
        patched_async_client.post.return_value = _ok({"reply": "ok"})

        async with AsyncLightbulbClient("http://localhost:8080", auth=_auth()) as c:
            await c.dispatch("finance", action="chat", message="hi")

        # Find the dispatch POST call (second post; first is csrf)
        dispatch_call = next(
            call for call in patched_async_client.post.call_args_list
            if "dispatch" in call.args[0]
        )
        assert dispatch_call.kwargs["json"]["company_id"] == COMPANY


class TestAsyncWhoami:

    @pytest.mark.asyncio
    async def test_whoami_hits_users_me(self, patched_async_client):
        patched_async_client.get.return_value = _ok({"email": "u@co.com", "role": "COMPANY"})

        async with AsyncLightbulbClient("http://localhost:8080", auth=_auth()) as c:
            me = await c.whoami()

        assert me["email"] == "u@co.com"
        # /api/auth/csrf is fetched too, so check that /users/me was called
        assert any(
            call.args[0].endswith("/api/users/me")
            for call in patched_async_client.get.call_args_list
        )


class TestAsyncListCompanies:

    @pytest.mark.asyncio
    async def test_list_companies_uses_tenant_path(self, patched_async_client):
        patched_async_client.get.return_value = _ok([{"id": "co-1", "name": "Acme"}])

        async with AsyncLightbulbClient("http://localhost:8080", auth=_auth()) as c:
            companies = await c.list_companies()

        assert companies[0]["id"] == "co-1"
        url = next(
            call.args[0] for call in patched_async_client.get.call_args_list
            if "companies/tenant" in call.args[0]
        )
        assert url.endswith(f"/api/companies/tenant/{TENANT}")


class TestAsyncApprovals:

    @pytest.mark.asyncio
    async def test_list_pending_approvals(self, patched_async_client):
        patched_async_client.get.return_value = _ok([{"id": "task-1"}])

        async with AsyncLightbulbClient("http://localhost:8080", auth=_auth()) as c:
            tasks = await c.list_pending_approvals()

        assert tasks[0]["id"] == "task-1"

    @pytest.mark.asyncio
    async def test_approve_task_posts_comments(self, patched_async_client):
        patched_async_client.post.return_value = _ok({"status": "approved"})

        async with AsyncLightbulbClient("http://localhost:8080", auth=_auth()) as c:
            await c.approve_task("task-1", comments="lgtm")

        approve_call = next(
            call for call in patched_async_client.post.call_args_list
            if call.args[0].endswith("/approve") and "approvals" in call.args[0]
        )
        assert approve_call.kwargs["json"] == {"comments": "lgtm"}

    @pytest.mark.asyncio
    async def test_reject_task(self, patched_async_client):
        patched_async_client.post.return_value = _ok({"status": "rejected"})

        async with AsyncLightbulbClient("http://localhost:8080", auth=_auth()) as c:
            await c.reject_task("task-1", comments="too risky")

        reject_call = next(
            call for call in patched_async_client.post.call_args_list
            if call.args[0].endswith("/reject")
        )
        assert reject_call.kwargs["json"] == {"comments": "too risky"}


class TestAsyncVoice:

    @pytest.mark.asyncio
    async def test_list_voice_executions_with_filter(self, patched_async_client):
        patched_async_client.get.return_value = _ok([{"id": "e-1"}])

        async with AsyncLightbulbClient("http://localhost:8080", auth=_auth()) as c:
            execs = await c.list_voice_executions(status="active")

        assert execs[0]["id"] == "e-1"
        get_call = next(
            call for call in patched_async_client.get.call_args_list
            if "voice/executions" in call.args[0]
        )
        assert get_call.kwargs["params"] == {"status": "active"}

    @pytest.mark.asyncio
    async def test_approve_voice_action(self, patched_async_client):
        patched_async_client.post.return_value = _ok({"approved": True})

        async with AsyncLightbulbClient("http://localhost:8080", auth=_auth()) as c:
            await c.approve_voice_action("e-1", "task-1", comments="go ahead")

        approve_call = next(
            call for call in patched_async_client.post.call_args_list
            if "voice/executions/e-1/approvals/task-1/approve" in call.args[0]
        )
        assert approve_call.kwargs["json"] == {"comments": "go ahead"}


class TestAsyncAOC:

    @pytest.mark.asyncio
    async def test_list_aoc_runs(self, patched_async_client):
        patched_async_client.get.return_value = _ok([{"id": "run-1"}])

        async with AsyncLightbulbClient("http://localhost:8080", auth=_auth()) as c:
            runs = await c.list_aoc_runs()

        assert runs[0]["id"] == "run-1"

    @pytest.mark.asyncio
    async def test_stop_aoc_run(self, patched_async_client):
        patched_async_client.post.return_value = _ok({"stopped": True})

        async with AsyncLightbulbClient("http://localhost:8080", auth=_auth()) as c:
            result = await c.stop_aoc_run("run-1")

        assert result == {"stopped": True}
        stop_call = next(
            call for call in patched_async_client.post.call_args_list
            if call.args[0].endswith("/api/aoc/runs/run-1/stop")
        )
        assert stop_call is not None


class TestAsyncInvokeTool:

    @pytest.mark.asyncio
    async def test_invoke_tool_payload_shape(self, patched_async_client):
        patched_async_client.post.return_value = _ok({"ok": True})

        async with AsyncLightbulbClient("http://localhost:8080", auth=_auth()) as c:
            await c.invoke_tool("slack.post_message", {"channel": "#ops", "text": "hi"})

        invoke_call = next(
            call for call in patched_async_client.post.call_args_list
            if call.args[0].endswith("/api/tools/invoke")
        )
        # Spring-side InvokeToolRequest expects toolName + inputs + tenant/company
        # (audit-id: invoke_tool_wire_shape_0_5_1).
        assert invoke_call.kwargs["json"] == {
            "toolName": "slack.post_message",
            "inputs": {"channel": "#ops", "text": "hi"},
            "tenantId": TENANT,
            "companyId": COMPANY,
        }


class TestAsyncLifecycle:

    @pytest.mark.asyncio
    async def test_aenter_aexit_creates_and_closes(self, patched_async_client):
        c = AsyncLightbulbClient("http://localhost:8080", auth=_auth())
        async with c:
            assert c._client is not None
        # __aexit__ should have called aclose
        patched_async_client.aclose.assert_awaited()

    @pytest.mark.asyncio
    async def test_close_idempotent(self, patched_async_client):
        c = AsyncLightbulbClient("http://localhost:8080", auth=_auth())
        async with c:
            pass
        await c.close()  # second close should not blow up
        # _client is reset to None
        assert c._client is None


class TestAsyncStreaming:
    """Verify streaming methods iterate SSE events from a mocked response."""

    @pytest.mark.asyncio
    async def test_stream_chat_yields_events(self):
        """End-to-end async SSE: domain agent stream_chat."""
        # We mock httpx.AsyncClient inside _stream_sse (which opens a fresh
        # client for streaming) to return a context manager whose response
        # has aiter_lines() yielding SSE lines.
        async def _aiter_lines():
            for line in [
                "event: status",
                'data: {"phase":"started"}',
                "",
                "event: token",
                'data: {"text":"hi"}',
                "",
            ]:
                yield line

        response_mock = MagicMock()
        response_mock.raise_for_status = MagicMock()
        response_mock.aiter_lines = _aiter_lines

        stream_cm = MagicMock()
        stream_cm.__aenter__ = AsyncMock(return_value=response_mock)
        stream_cm.__aexit__ = AsyncMock(return_value=False)

        async_client_mock = MagicMock()
        async_client_mock.stream = MagicMock(return_value=stream_cm)
        async_client_mock.__aenter__ = AsyncMock(return_value=async_client_mock)
        async_client_mock.__aexit__ = AsyncMock(return_value=False)

        # _stream_sse uses `async with httpx.AsyncClient(...)` for the stream
        # (separate from the persistent client used elsewhere). We also need
        # to satisfy the persistent client path used by _ensure_client and
        # _fetch_csrf_token, which get called in __aenter__. Provide stable
        # mocks for both.
        persistent = MagicMock()
        persistent.is_closed = False
        persistent.aclose = AsyncMock()
        persistent.get = AsyncMock(return_value=_ok({"token": ""}))
        persistent.post = AsyncMock(return_value=_ok({"token": ""}))

        # First call returns the persistent client; subsequent calls in
        # _stream_sse return the streaming client.
        with patch(
            "lightbulb.async_client.httpx.AsyncClient",
            side_effect=[persistent, async_client_mock],
        ):
            async with AsyncLightbulbClient("http://localhost:8080", auth=_auth()) as c:
                events = []
                async for ev in c.stream_chat("finance", message="forecast"):
                    events.append(ev)

        assert len(events) == 2
        assert events[0].event == "status"
        assert events[0].data == {"phase": "started"}
        assert events[1].event == "token"
