"""Tests for lightbulb.client — API client dispatch, streaming, validation."""

import json
import pytest
import httpx
from unittest.mock import MagicMock, patch

from lightbulb.auth import ApiKeyAuth
from lightbulb.client import LightbulbClient, DispatchResult, SSEEvent, _validate_domain, _validate_message


TENANT = "00000000-0000-0000-0000-000000000001"
USER = "00000000-0000-0000-0000-000000000002"


def _auth():
    return ApiKeyAuth(
        api_key="test-api-key-long-enough",
        tenant_id=TENANT,
        user_id=USER,
    )


class TestClientConstruction:

    def test_rejects_http_for_non_localhost(self):
        with pytest.raises(ValueError, match="HTTPS is required"):
            LightbulbClient("http://agents.lightbulbpartners.com", auth=_auth())

    def test_allows_https(self):
        client = LightbulbClient("https://agents.lightbulbpartners.com", auth=_auth())
        assert client._base_url == "https://agents.lightbulbpartners.com"

    def test_allows_http_for_localhost(self):
        client = LightbulbClient("http://localhost:8080", auth=_auth())
        assert client._base_url == "http://localhost:8080"

    def test_allows_http_with_enforce_false(self):
        client = LightbulbClient(
            "http://staging.example.com",
            auth=_auth(),
            enforce_https=False,
        )
        assert client._base_url == "http://staging.example.com"

    def test_strips_trailing_slash(self):
        client = LightbulbClient("http://localhost:8080/", auth=_auth())
        assert client._base_url == "http://localhost:8080"


class TestInputValidation:

    def test_validate_domain_accepts_valid(self):
        assert _validate_domain("document_intelligence") == "document_intelligence"
        assert _validate_domain("CRM") == "crm"
        assert _validate_domain("finance") == "finance"

    def test_validate_domain_rejects_empty(self):
        with pytest.raises(ValueError):
            _validate_domain("")

    def test_validate_domain_rejects_special_chars(self):
        with pytest.raises(ValueError):
            _validate_domain("../../../etc/passwd")

    def test_validate_domain_rejects_sql_injection(self):
        with pytest.raises(ValueError):
            _validate_domain("finance; DROP TABLE users")

    def test_validate_message_accepts_valid(self):
        assert _validate_message("Search for quarterly revenue") == "Search for quarterly revenue"

    def test_validate_message_rejects_empty(self):
        with pytest.raises(ValueError, match="empty"):
            _validate_message("")

    def test_validate_message_rejects_oversized(self):
        with pytest.raises(ValueError, match="limit"):
            _validate_message("x" * 200_000)


class TestDispatch:

    def test_dispatch_sends_correct_request(self):
        client = LightbulbClient("http://localhost:8080", auth=_auth())

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "domain": "document_intelligence",
            "action": "search_documents",
            "mode": "workflow_completed",
            "reply": "Found 3 documents matching your query.",
            "conversationId": "conv-1",
            "traceId": "trace-1",
            "outputs": {"top_hits": [{"document_id": "d-1"}]},
        }

        with patch.object(httpx.Client, "post", return_value=mock_response) as mock_post:
            with patch.object(httpx.Client, "__enter__", return_value=httpx.Client()):
                with patch.object(httpx.Client, "__exit__", return_value=False):
                    result = client.dispatch(
                        "document_intelligence",
                        action="search_documents",
                        message="quarterly revenue",
                    )

        assert isinstance(result, DispatchResult)
        assert result.domain == "document_intelligence"
        assert result.reply == "Found 3 documents matching your query."
        assert result.success

    def test_dispatch_rejects_invalid_domain(self):
        client = LightbulbClient("http://localhost:8080", auth=_auth())
        with pytest.raises(ValueError, match="Invalid domain"):
            client.dispatch("../etc/passwd", action="chat", message="hello")

    def test_dispatch_rejects_invalid_action(self):
        client = LightbulbClient("http://localhost:8080", auth=_auth())
        with pytest.raises(ValueError, match="Invalid action"):
            client.dispatch("finance", action="'; DROP TABLE", message="hello")


class TestInvokeTool:
    """Regression for the 0.5.1 wire-shape fix.

    Spring's ``InvokeToolRequest`` DTO at ToolRegistryController:736 expects
    ``toolName`` + ``inputs`` (+ optional ``tenantId``/``companyId``). Earlier
    versions sent ``{tool, arguments}`` which silently deserialized to
    null-fields and 404'd inside ToolRuntime. Audit-id: invoke_tool_wire_shape_0_5_1.
    """

    def test_invoke_tool_payload_shape(self):
        client = LightbulbClient("http://localhost:8080", auth=_auth())
        client.active_company_id = "00000000-0000-0000-0000-000000000099"

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {"ok": True}

        with patch.object(httpx.Client, "post", return_value=mock_response) as mock_post:
            client.invoke_tool("slack.post_message", {"channel": "#ops", "text": "hi"})

        invoke_call = next(
            call for call in mock_post.call_args_list
            if call.args[0].endswith("/api/tools/invoke")
        )
        assert invoke_call.kwargs["json"] == {
            "toolName": "slack.post_message",
            "inputs": {"channel": "#ops", "text": "hi"},
            "tenantId": TENANT,
            "companyId": "00000000-0000-0000-0000-000000000099",
        }


class TestCodeWorkspaceClient:

    def test_create_code_workspace_uses_expected_payload(self):
        client = LightbulbClient("http://localhost:8080", auth=_auth())

        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {"workspace": {"id": "ws-1"}}

        with patch.object(httpx.Client, "post", return_value=mock_response) as mock_post:
            result = client.create_code_workspace(
                source="/tmp/smoke-fixture",
                label="SDK smoke workspace",
                branch="main",
                depth=1,
                metadata={"suite": "coding"},
                company_id="00000000-0000-0000-0000-000000000003",
            )

        assert result["workspace"]["id"] == "ws-1"
        payload = mock_post.call_args.kwargs["json"]
        assert payload["source"] == "/tmp/smoke-fixture"
        assert payload["label"] == "SDK smoke workspace"
        assert payload["branch"] == "main"
        assert payload["depth"] == 1
        assert payload["metadata"] == {"suite": "coding"}
        assert payload["companyId"] == "00000000-0000-0000-0000-000000000003"
        assert mock_post.call_args.args[0].endswith("/api/code/workspaces")

    def test_code_workspace_chat_preserves_optional_kwargs(self):
        client = LightbulbClient("http://localhost:8080", auth=_auth())

        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {"reply": "ok"}

        with patch.object(httpx.Client, "post", return_value=mock_response) as mock_post:
            with patch.object(httpx.Client, "__enter__", return_value=httpx.Client()):
                with patch.object(httpx.Client, "__exit__", return_value=False):
                    result = client.code_workspace_chat(
                        "ws-1",
                        "Fix the bug",
                        conversation_id="conv-1",
                        active_file="src/app.py",
                        preview_mode=True,
                        context={"selected_text": "hello"},
                    )

        assert result["reply"] == "ok"
        payload = mock_post.call_args.kwargs["json"]
        assert payload["workspace_id"] == "ws-1"
        assert payload["conversationId"] == "conv-1"
        assert payload["activeFile"] == "src/app.py"
        assert payload["previewMode"] is True
        assert payload["context"] == {"selected_text": "hello"}

    def test_get_code_workspace_active_run_returns_none_on_no_content(self):
        client = LightbulbClient("http://localhost:8080", auth=_auth())

        mock_response = MagicMock()
        mock_response.status_code = 204
        mock_response.raise_for_status = MagicMock()

        with patch.object(httpx.Client, "get", return_value=mock_response):
            result = client.get_code_workspace_active_run("ws-1")

        assert result is None

    def test_get_code_workspace_run_uses_expected_endpoint(self):
        client = LightbulbClient("http://localhost:8080", auth=_auth())

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {"id": "run-1", "status": "completed"}

        with patch.object(httpx.Client, "get", return_value=mock_response) as mock_get:
            result = client.get_code_workspace_run("ws-1", "run-1")

        assert result["id"] == "run-1"
        assert mock_get.call_args.args[0].endswith("/api/code/workspaces/ws-1/runs/run-1")


class TestDocumentShortcuts:

    def test_search_documents_dispatches_correctly(self):
        client = LightbulbClient("http://localhost:8080", auth=_auth())
        with patch.object(client, "dispatch") as mock:
            mock.return_value = DispatchResult(
                domain="document_intelligence",
                action="search_documents",
                mode="completed",
                reply="Found results",
                conversation_id="c-1",
                trace_id="t-1",
                outputs={},
                raw={},
            )
            result = client.search_documents("quarterly revenue", folder_path="/reports")

        mock.assert_called_once_with(
            "document_intelligence",
            action="search_documents",
            message="quarterly revenue",
            inputs={"message": "quarterly revenue", "top_k": 10, "folder_path_prefix": "/reports"},
        )

    def test_grep_documents_dispatches_correctly(self):
        client = LightbulbClient("http://localhost:8080", auth=_auth())
        with patch.object(client, "dispatch") as mock:
            mock.return_value = DispatchResult(
                domain="document_intelligence", action="grep_content",
                mode="completed", reply="Found matches",
                conversation_id="c-1", trace_id="t-1", outputs={}, raw={},
            )
            result = client.grep_documents(r"revenue\s+grew", regex=True)

        call_args = mock.call_args
        assert call_args.kwargs["action"] == "grep_content"
        assert call_args.kwargs["inputs"]["pattern"] == r"revenue\s+grew"
        assert call_args.kwargs["inputs"]["regex"] is True

    def test_list_folder_dispatches_correctly(self):
        client = LightbulbClient("http://localhost:8080", auth=_auth())
        with patch.object(client, "dispatch") as mock:
            mock.return_value = DispatchResult(
                domain="document_intelligence", action="list_folder",
                mode="completed", reply="Listed 5 files",
                conversation_id="c-1", trace_id="t-1", outputs={}, raw={},
            )
            result = client.list_folder("/contracts", source_system="google_drive")

        call_args = mock.call_args
        assert call_args.kwargs["action"] == "list_folder"
        assert call_args.kwargs["inputs"]["folder_path"] == "/contracts"
        assert call_args.kwargs["inputs"]["source_system"] == "google_drive"

    def test_create_document_dispatches_correctly(self):
        client = LightbulbClient("http://localhost:8080", auth=_auth())
        with patch.object(client, "dispatch") as mock:
            mock.return_value = DispatchResult(
                domain="document_intelligence", action="write_document",
                mode="completed", reply="Created",
                conversation_id="c-1", trace_id="t-1", outputs={}, raw={},
            )
            result = client.create_document("Q1 Report", "Report content here", format="docx")

        call_args = mock.call_args
        assert call_args.kwargs["action"] == "write_document"
        assert call_args.kwargs["inputs"]["title"] == "Q1 Report"
        assert call_args.kwargs["inputs"]["body"] == "Report content here"
        assert call_args.kwargs["inputs"]["format"] == "docx"


class TestSSEParsing:

    def test_parse_sse_stream(self):
        client = LightbulbClient("http://localhost:8080", auth=_auth())

        lines = [
            "event: status",
            'data: {"type": "thinking", "message": "Analyzing..."}',
            "",
            "event: chat",
            'data: {"delta": "Found 3 documents."}',
            "",
            "event: complete",
            'data: {"status": "completed", "summary": "Done"}',
            "",
        ]

        mock_response = MagicMock()
        mock_response.iter_lines.return_value = iter(lines)

        events = list(client._parse_sse_stream(mock_response))
        assert len(events) == 3
        assert events[0].event == "status"
        assert events[0].data["type"] == "thinking"
        assert events[1].event == "chat"
        assert events[1].data["delta"] == "Found 3 documents."
        assert events[2].event == "complete"
        assert events[2].data["status"] == "completed"

    def test_parse_sse_handles_keepalive(self):
        client = LightbulbClient("http://localhost:8080", auth=_auth())

        lines = [
            ": keepalive",
            "event: chat",
            'data: {"delta": "text"}',
            "",
        ]

        mock_response = MagicMock()
        mock_response.iter_lines.return_value = iter(lines)

        events = list(client._parse_sse_stream(mock_response))
        assert len(events) == 1
        assert events[0].event == "chat"

    def test_parse_sse_handles_malformed_json(self):
        client = LightbulbClient("http://localhost:8080", auth=_auth())

        lines = [
            "event: error",
            "data: not-valid-json",
            "",
        ]

        mock_response = MagicMock()
        mock_response.iter_lines.return_value = iter(lines)

        events = list(client._parse_sse_stream(mock_response))
        assert len(events) == 1
        assert events[0].data == {"raw_text": "not-valid-json"}
