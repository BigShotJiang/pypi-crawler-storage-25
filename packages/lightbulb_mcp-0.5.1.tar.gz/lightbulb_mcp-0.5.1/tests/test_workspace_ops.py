"""Tests for code workspace tool/preview ops + marketing connector setup."""

import httpx
import pytest
from unittest.mock import MagicMock, patch

from lightbulb.auth import ApiKeyAuth
from lightbulb.client import LightbulbClient


TENANT = "00000000-0000-0000-0000-000000000001"
USER = "00000000-0000-0000-0000-000000000002"


def _auth():
    return ApiKeyAuth(
        api_key="test-api-key-long-enough",
        tenant_id=TENANT,
        user_id=USER,
    )


def _client():
    return LightbulbClient("http://localhost:8080", auth=_auth())


def _ok(json_body):
    m = MagicMock()
    m.status_code = 200
    m.content = b"{}"
    m.raise_for_status = MagicMock()
    m.json.return_value = json_body
    return m


class TestCodeWorkspaceTools:

    def test_invoke_tool_targets_correct_path(self):
        client = _client()
        with patch.object(httpx.Client, "post", return_value=_ok({"ok": True})) as mock_post:
            client.code_workspace_invoke_tool("ws-1", "files.read", {"path": "src/app.py"})

        url = mock_post.call_args.args[0]
        assert url.endswith("/api/code/workspaces/ws-1/tools/files.read")
        assert mock_post.call_args.kwargs["json"] == {"path": "src/app.py"}

    def test_invoke_tool_supports_tool_keys_with_dots(self):
        """Tool keys like 'shell.run' must survive verbatim in the URL."""
        client = _client()
        with patch.object(httpx.Client, "post", return_value=_ok({"stdout": "hi"})) as mock_post:
            client.code_workspace_invoke_tool("ws-1", "shell.run", {"command": "echo hi"})
        assert mock_post.call_args.args[0].endswith("/tools/shell.run")

    def test_invoke_tool_rejects_empty_key(self):
        client = _client()
        with pytest.raises(ValueError, match="tool_key"):
            client.code_workspace_invoke_tool("ws-1", "", {})

    def test_invoke_tool_defaults_arguments_to_empty_dict(self):
        client = _client()
        with patch.object(httpx.Client, "post", return_value=_ok({})) as mock_post:
            client.code_workspace_invoke_tool("ws-1", "git.status")
        assert mock_post.call_args.kwargs["json"] == {}

    def test_runtime_catalog_uses_get(self):
        client = _client()
        with patch.object(httpx.Client, "get", return_value=_ok({"tools": []})) as mock_get:
            client.code_workspace_runtime_catalog("ws-1")
        assert mock_get.call_args.args[0].endswith("/api/code/workspaces/ws-1/runtime/catalog")

    def test_register_runtime_tools_uses_post(self):
        client = _client()
        with patch.object(httpx.Client, "post", return_value=_ok({"registered": 2})) as mock_post:
            client.code_workspace_register_runtime_tools(
                "ws-1", {"tools": [{"key": "files.read"}]}
            )
        assert mock_post.call_args.args[0].endswith("/api/code/workspaces/ws-1/runtime/catalog")


class TestCodeWorkspacePreview:

    def test_preview_start(self):
        client = _client()
        with patch.object(httpx.Client, "post", return_value=_ok({"url": "http://preview"})) as mock_post:
            client.code_workspace_preview_start("ws-1", {"port": 3000})
        assert mock_post.call_args.args[0].endswith("/api/code/workspaces/ws-1/preview/start")
        assert mock_post.call_args.kwargs["json"] == {"port": 3000}

    def test_preview_get(self):
        client = _client()
        with patch.object(httpx.Client, "get", return_value=_ok({"url": "..."})) as mock_get:
            client.code_workspace_preview("ws-1")
        assert mock_get.call_args.args[0].endswith("/api/code/workspaces/ws-1/preview")

    def test_preview_stop(self):
        client = _client()
        with patch.object(httpx.Client, "post", return_value=_ok({"stopped": True})) as mock_post:
            client.code_workspace_preview_stop("ws-1")
        assert mock_post.call_args.args[0].endswith("/api/code/workspaces/ws-1/preview/stop")

    def test_preview_proxy_returns_raw_response(self):
        client = _client()
        proxied = MagicMock()
        proxied.status_code = 418
        proxied.text = "I'm a teapot"

        with patch.object(httpx.Client, "request", return_value=proxied) as mock_req:
            resp = client.code_workspace_preview_proxy(
                "ws-1", "/health", method="GET"
            )

        assert resp.status_code == 418
        assert mock_req.call_args.args[0] == "GET"
        assert mock_req.call_args.args[1].endswith("/api/code/workspaces/ws-1/preview/proxy/health")

    def test_preview_proxy_strips_leading_slash(self):
        """A user-passed path 'foo' or '/foo' should both work."""
        client = _client()
        proxied = MagicMock(); proxied.status_code = 200
        with patch.object(httpx.Client, "request", return_value=proxied) as mock_req:
            client.code_workspace_preview_proxy("ws-1", "foo")
        assert mock_req.call_args.args[1].endswith("/preview/proxy/foo")


class TestCodeWorkspaceEvalsAndPolicy:

    def test_evals(self):
        client = _client()
        with patch.object(httpx.Client, "get", return_value=_ok({"runs": 0})) as mock_get:
            client.code_workspace_evals("ws-1")
        assert mock_get.call_args.args[0].endswith("/api/code/workspaces/ws-1/evals")

    def test_policy_replay_passes_filters(self):
        client = _client()
        with patch.object(httpx.Client, "get", return_value=_ok({"replays": []})) as mock_get:
            client.code_workspace_policy_replay("ws-1", run_id="r-1", request_family="chat")
        assert mock_get.call_args.kwargs["params"] == {"run_id": "r-1", "request_family": "chat"}

    def test_clear_policy(self):
        client = _client()
        with patch.object(httpx.Client, "post", return_value=_ok({"cleared": 5})) as mock_post:
            client.code_workspace_clear_policy("ws-1", "chat")
        assert mock_post.call_args.args[0].endswith("/api/code/workspaces/ws-1/policy/chat/clear")


class TestMarketingContentSetup:

    def test_setup_uses_get(self):
        client = _client()
        with patch.object(httpx.Client, "get", return_value=_ok({"providers": []})) as mock_get:
            client.marketing_content_setup()
        assert mock_get.call_args.args[0].endswith(
            "/api/tools/connectors/marketing/content-setup"
        )

    def test_configure_provider(self):
        client = _client()
        with patch.object(httpx.Client, "post", return_value=_ok({"configured": True})) as mock_post:
            client.marketing_content_configure_provider("ga4", {"property_id": "123"})
        assert mock_post.call_args.args[0].endswith(
            "/api/tools/connectors/marketing/content-setup/providers/ga4"
        )
        assert mock_post.call_args.kwargs["json"] == {"property_id": "123"}

    def test_add_site(self):
        client = _client()
        with patch.object(httpx.Client, "post", return_value=_ok({"id": "site-1"})) as mock_post:
            client.marketing_add_website_analytics_site({"domain": "example.com"})
        assert mock_post.call_args.args[0].endswith(
            "/content-setup/website-analytics/sites"
        )

    def test_select_site(self):
        client = _client()
        with patch.object(httpx.Client, "post", return_value=_ok({"selected": "site-1"})) as mock_post:
            client.marketing_select_website_analytics_site("site-1")
        assert mock_post.call_args.args[0].endswith(
            "/content-setup/website-analytics/sites/site-1/select"
        )

    def test_remove_site(self):
        client = _client()
        del_resp = MagicMock()
        del_resp.status_code = 200
        del_resp.content = b""
        del_resp.raise_for_status = MagicMock()

        with patch.object(httpx.Client, "delete", return_value=del_resp) as mock_del:
            result = client.marketing_remove_website_analytics_site("site-1")
        assert mock_del.call_args.args[0].endswith(
            "/content-setup/website-analytics/sites/site-1"
        )
        assert result == {"removed": "site-1"}

    def test_verify(self):
        client = _client()
        with patch.object(httpx.Client, "post", return_value=_ok({"ok": True})) as mock_post:
            client.marketing_verify_website_analytics()
        assert mock_post.call_args.args[0].endswith(
            "/content-setup/website-analytics/verify"
        )

    def test_install_to_workspace(self):
        client = _client()
        with patch.object(httpx.Client, "post", return_value=_ok({"installed": True})) as mock_post:
            client.marketing_install_website_analytics("ws-9", {"variant": "next"})
        assert mock_post.call_args.args[0].endswith(
            "/content-setup/website-analytics/workspaces/ws-9/install"
        )
        assert mock_post.call_args.kwargs["json"] == {"variant": "next"}
