"""Targeted tests for the security fixes from the v0.4.0 audit.

Each test ties to a finding ID (H1, H3, M7, M8, etc.) so future contributors
can grep for the audit reference if they ever revisit a hardening rule.
"""

import json
import os
import re
import stat
from pathlib import Path
from unittest.mock import MagicMock, patch

import httpx
import pytest

from lightbulb.auth import _validate_redirect_url, sso_redirect_url
from lightbulb.client import LightbulbClient, _validate_id
from lightbulb.errors import (
    AuthenticationError,
    LightbulbError,
    NotFoundError,
    PermissionDenied,
    RateLimitedError,
    ServerError,
    ValidationError,
    from_response,
    wrap_http_error,
)
from lightbulb.setup import (
    _safe_backup,
    _toml_escape,
    render_codex_toml_block,
    write_codex_toml,
    write_json_mcp_config,
)
from lightbulb.token_cache import _cache_path, _is_secure, save_cached_token
from lightbulb.validators import (
    CLAUDE_SESSION_ACTIONS,
    CODEX_THREAD_ACTIONS,
    CODEX_TURN_ACTIONS,
    is_local_url,
    validate_choice,
    validate_id,
    validate_method,
    validate_relative_path,
    validate_tool_key,
)
from lightbulb.auth import ApiKeyAuth, JwtAuth


def _auth():
    return ApiKeyAuth(
        api_key="test-api-key-long-enough",
        tenant_id="00000000-0000-0000-0000-000000000001",
        user_id="00000000-0000-0000-0000-000000000002",
    )


# ── H1 / H2: SSO redirect URL validation ─────────────────────────────


class TestRedirectUrlValidator:
    """Audit findings H1 + H2 — server-supplied URLs must not bypass host check."""

    def test_rejects_protocol_relative(self):
        with pytest.raises(RuntimeError, match="protocol-relative"):
            _validate_redirect_url("//evil.com/steal", "https://platform.test")

    def test_rejects_javascript_scheme(self):
        with pytest.raises(RuntimeError, match="disallowed scheme"):
            _validate_redirect_url("javascript:alert(1)", "https://platform.test")

    def test_rejects_data_scheme(self):
        with pytest.raises(RuntimeError, match="disallowed scheme"):
            _validate_redirect_url("data:text/html,<script>", "https://platform.test")

    def test_rejects_file_scheme(self):
        with pytest.raises(RuntimeError, match="disallowed scheme"):
            _validate_redirect_url("file:///etc/passwd", "https://platform.test")

    def test_rejects_cross_host_absolute(self):
        with pytest.raises(RuntimeError, match="does not match platform host"):
            _validate_redirect_url("https://evil.com/oauth", "https://platform.test")

    def test_rejects_dotdot_segments(self):
        with pytest.raises(RuntimeError, match="'\\.\\.'"):
            _validate_redirect_url("/oauth/../admin", "https://platform.test")

    def test_accepts_same_host_absolute(self):
        url = _validate_redirect_url(
            "https://platform.test/oauth/callback?code=abc",
            "https://platform.test",
        )
        assert url.startswith("https://platform.test/oauth/")

    def test_accepts_clean_relative(self):
        url = _validate_redirect_url("/oauth/start", "https://platform.test")
        assert url == "https://platform.test/oauth/start"

    def test_rejects_relative_without_leading_slash(self):
        with pytest.raises(RuntimeError, match="absolute or start with"):
            _validate_redirect_url("evil/oauth", "https://platform.test")


# ── H3 / H4 / M1: Path-component validation ──────────────────────────


class TestPathComponentValidation:
    """Audit findings H3, H4, M1 — IDs interpolated into URL paths."""

    def test_validate_id_rejects_path_traversal(self):
        with pytest.raises(ValueError, match="\\.\\."):
            _validate_id("../../../etc/passwd", "workspace_id")

    def test_validate_id_rejects_slash(self):
        with pytest.raises(ValueError):
            _validate_id("ws-1/admin", "workspace_id")

    def test_validate_id_rejects_query_separators(self):
        for bad in ("ws-1?force=true", "ws-1#frag", "ws-1&x=y"):
            with pytest.raises(ValueError):
                _validate_id(bad, "workspace_id")

    def test_validate_id_rejects_control_chars(self):
        with pytest.raises(ValueError):
            _validate_id("ws-1\nINJECT", "workspace_id")

    def test_validate_id_accepts_alnum_dot_dash_underscore(self):
        for ok in ("ws-1", "task_2", "abc.def", "a-b.c_d"):
            assert _validate_id(ok, "id") == ok

    def test_validate_tool_key_requires_lowercase_dotted(self):
        for ok in ("files.read", "shell.run", "git.commit", "x"):
            assert validate_tool_key(ok) == ok
        for bad in ("Files.Read", "files/read", "files..read", "files-read", "../etc"):
            with pytest.raises(ValidationError):
                validate_tool_key(bad)

    def test_invoke_tool_rejects_traversal_in_workspace_id(self):
        client = LightbulbClient("http://localhost:8080", auth=_auth())
        with pytest.raises(ValueError):
            client.code_workspace_invoke_tool("../../etc", "files.read", {})

    def test_invoke_tool_rejects_traversal_in_tool_key(self):
        client = LightbulbClient("http://localhost:8080", auth=_auth())
        with pytest.raises(ValidationError):
            client.code_workspace_invoke_tool("ws-1", "../admin/dangerous", {})

    def test_claude_session_action_allowlist(self):
        client = LightbulbClient("http://localhost:8080", auth=_auth())
        with pytest.raises(ValidationError):
            client.claude_session_action("ws-1", "sess-1", "delete-everything")
        # All known-good actions parse — pass a mock so we don't hit network.
        with patch.object(httpx.Client, "post") as mock_post:
            mock_post.return_value = MagicMock(status_code=200, raise_for_status=MagicMock(), json=lambda: {})
            for action in CLAUDE_SESSION_ACTIONS:
                client.claude_session_action("ws-1", "sess-1", action)

    def test_codex_thread_action_allowlist(self):
        client = LightbulbClient("http://localhost:8080", auth=_auth())
        with pytest.raises(ValidationError):
            client.codex_thread_action("ws-1", "thr-1", "evict")
        with patch.object(httpx.Client, "post") as mock_post:
            mock_post.return_value = MagicMock(status_code=200, raise_for_status=MagicMock(), json=lambda: {})
            for action in CODEX_THREAD_ACTIONS:
                client.codex_thread_action("ws-1", "thr-1", action)

    def test_codex_turn_action_allowlist(self):
        client = LightbulbClient("http://localhost:8080", auth=_auth())
        with pytest.raises(ValidationError):
            client.codex_turn_action("ws-1", "thr-1", "turn-1", "exfiltrate")


# ── M2: preview_proxy header smuggling + method validation ───────────


class TestPreviewProxy:

    def test_rejects_invalid_http_method(self):
        client = LightbulbClient("http://localhost:8080", auth=_auth())
        with pytest.raises(ValidationError):
            client.code_workspace_preview_proxy("ws-1", "/", method="CONNECT; smuggle")

    def test_caller_cannot_override_auth_headers(self):
        """Audit M2: caller-supplied headers are merged BEFORE auth headers,
        so they cannot displace Authorization / X-Internal-API-Key."""
        client = LightbulbClient("http://localhost:8080", auth=_auth())
        proxied = MagicMock(status_code=200)

        with patch.object(httpx.Client, "request", return_value=proxied) as mock_req:
            client.code_workspace_preview_proxy(
                "ws-1", "/health",
                method="GET",
                headers={
                    "Authorization": "Bearer attacker-jwt",
                    "X-Internal-API-Key": "attacker-key",
                    "X-Tenant-Id": "evil-tenant",
                },
            )

        sent_headers = mock_req.call_args.kwargs["headers"]
        # The real auth's API key wins, not the attacker's value
        assert sent_headers["X-Internal-API-Key"] == "test-api-key-long-enough"
        assert sent_headers.get("Authorization", "") != "Bearer attacker-jwt"
        assert sent_headers["X-Tenant-Id"] == "00000000-0000-0000-0000-000000000001"

    def test_rejects_path_with_dotdot(self):
        client = LightbulbClient("http://localhost:8080", auth=_auth())
        with pytest.raises(ValidationError):
            client.code_workspace_preview_proxy("ws-1", "../admin/secrets")

    def test_rejects_scheme_in_path(self):
        client = LightbulbClient("http://localhost:8080", auth=_auth())
        with pytest.raises(ValidationError):
            client.code_workspace_preview_proxy("ws-1", "https://evil.com/x")


# ── M3 / M4: SSE size caps ──────────────────────────────────────────


class TestSseSizeLimits:

    def test_oversized_line_aborts_stream(self):
        """A single SSE line larger than _MAX_SSE_LINE_BYTES must abort."""
        from lightbulb.client import _MAX_SSE_LINE_BYTES

        big_line = "data: " + "x" * (_MAX_SSE_LINE_BYTES + 10)
        response = MagicMock()
        response.raise_for_status = MagicMock()
        response.iter_lines.return_value = iter([
            big_line,
            "event: should_not_arrive",
            'data: {"reached":true}',
            "",
        ])
        cm = MagicMock()
        cm.__enter__.return_value = response
        cm.__exit__.return_value = False

        client = LightbulbClient("http://localhost:8080", auth=_auth())
        with patch.object(httpx.Client, "stream", return_value=cm):
            events = list(client.stream_code_workspace_chat("ws-1", "go"))
        # The oversized line should have aborted before any complete event yielded.
        assert all(ev.event != "should_not_arrive" for ev in events)


# ── H5 / H6 / M6: token cache + .bak handling ────────────────────────


class TestTokenCacheSecurity:

    def test_save_cached_token_is_atomic_and_chmod(self, tmp_path, monkeypatch):
        """Audit H5: save uses tempfile + os.replace + chmod-before-write."""
        monkeypatch.setattr("lightbulb.token_cache.CACHE_DIR", tmp_path / "tokens")
        monkeypatch.setattr(
            "lightbulb.token_cache._cache_path",
            lambda url: (tmp_path / "tokens") / "abc.json",
        )
        auth = JwtAuth(
            token="eyJabc.payload-stuff-here-long.signature-here",
            tenant_id="00000000-0000-0000-0000-000000000001",
        )
        save_cached_token("https://x.test", auth, expires_in=300)

        cache_file = (tmp_path / "tokens") / "abc.json"
        assert cache_file.exists()
        if hasattr(os, "getuid"):
            mode = stat.S_IMODE(cache_file.stat().st_mode)
            assert mode == 0o600, f"Expected 0o600, got 0o{mode:o}"

        # No leftover tempfiles in the cache dir
        leftovers = [p for p in (tmp_path / "tokens").iterdir() if p.name.startswith(".tok-")]
        assert leftovers == []

    def test_is_secure_rejects_symlinks(self, tmp_path, monkeypatch):
        """Audit M6: a symlinked cache file must be rejected."""
        if not hasattr(os, "symlink"):
            pytest.skip("symlinks not available on this platform")
        target = tmp_path / "real.json"
        target.write_text('{"x":1}')
        try:
            os.chmod(target, 0o600)
        except OSError:
            pass
        link = tmp_path / "link.json"
        try:
            os.symlink(target, link)
        except (OSError, NotImplementedError):
            pytest.skip("symlinks not supported here")
        assert _is_secure(link) is False


class TestSafeBackup:

    def test_backup_chmod_to_0o600(self, tmp_path):
        original = tmp_path / "config.json"
        original.write_text('{"secret":"jwt"}')
        backup = _safe_backup(original, original.read_text(), 0o644)
        assert backup is not None
        if hasattr(os, "getuid"):
            mode = stat.S_IMODE(backup.stat().st_mode)
            # The clamped mode should drop group/other bits
            assert (mode & 0o077) == 0, f"Expected no group/other bits, got 0o{mode:o}"

    def test_backup_refuses_symlink(self, tmp_path):
        if not hasattr(os, "symlink"):
            pytest.skip("symlinks not available")
        original = tmp_path / "config.json"
        original.write_text('{"x":1}')
        # Pre-plant a symlink at the .bak target
        backup_target = tmp_path / "elsewhere"
        backup_target.write_text("attacker content")
        backup_link = original.with_suffix(".json.bak")
        try:
            os.symlink(backup_target, backup_link)
        except (OSError, NotImplementedError):
            pytest.skip("symlinks not supported")

        result = _safe_backup(original, original.read_text(), 0o600)
        assert result is None  # refused


# ── M7: localhost detection ──────────────────────────────────────────


class TestLocalUrlDetection:
    """Audit M7: don't fall for substring tricks like 'evil.localhost.com'."""

    def test_real_localhost_detected(self):
        for url in (
            "http://localhost:8080",
            "http://127.0.0.1:8080",
            "http://0.0.0.0:9000",
            "http://host.docker.internal:8080",
        ):
            assert is_local_url(url) is True

    def test_attacker_lookalikes_rejected(self):
        for url in (
            "https://evil.localhost.com",
            "https://attacker.com/?ref=localhost",
            "https://localhost.example.com",
            "https://127.0.0.1.evil.com",
        ):
            assert is_local_url(url) is False, f"{url} should not be considered local"


# ── M8: TOML escape covers control characters (RCE risk) ─────────────


class TestTomlEscape:
    """Audit M8: control chars MUST be escaped — newline injection in
    config.toml lets an attacker register arbitrary [mcp_servers.X] blocks
    that run their command on every Codex launch."""

    def test_escapes_newline(self):
        out = _toml_escape("evil\nLIGHTBULB_FAKE = \"injected\"")
        assert "\n" not in out
        assert "\\n" in out

    def test_escapes_carriage_return(self):
        assert "\\r" in _toml_escape("a\rb")

    def test_escapes_tab_and_backspace(self):
        assert "\\t" in _toml_escape("a\tb")
        assert "\\b" in _toml_escape("a\bb")

    def test_escapes_null_byte(self):
        out = _toml_escape("a\x00b")
        assert "\x00" not in out
        assert "\\u0000" in out

    def test_escapes_control_char(self):
        # ESC (0x1b) and DEL (0x7f) — both must be escaped.
        for c in ("\x1b", "\x7f", "\x01"):
            out = _toml_escape(c)
            assert c not in out
            assert out.startswith("\\u")

    def test_renders_block_with_injection_attempt_neutralized(self, tmp_path):
        cfg = tmp_path / "config.toml"
        with patch("lightbulb.setup.shutil.which", return_value=None):
            block = render_codex_toml_block(
                "https://x.test",
                jwt='abc"\n[mcp_servers.attacker]\ncommand="rm -rf"',
                tenant_id="00000000-0000-0000-0000-000000000001",
            )
        write_codex_toml(cfg, block)
        text = cfg.read_text()

        # Real proof: parse the result with tomllib and confirm the attacker's
        # table did NOT become a top-level section.
        import tomllib
        parsed = tomllib.loads(text)
        servers = parsed.get("mcp_servers", {})
        assert "attacker" not in servers, (
            "Attacker successfully injected an mcp_servers.attacker table — "
            "TOML escape failed."
        )
        # The escaped JWT string round-trips containing the literal characters
        # (newlines became "\n" inside a TOML basic string).
        env = servers.get("lightbulb", {}).get("env", {})
        assert env.get("LIGHTBULB_JWT", "").startswith('abc"\n[mcp_servers.attacker]')


# ── M9: Atomic JSON config write ─────────────────────────────────────


class TestAtomicJsonWrite:

    def test_no_tempfile_leftover(self, tmp_path):
        cfg = tmp_path / ".mcp.json"
        write_json_mcp_config(cfg, {"command": "lightbulb-mcp", "args": [], "env": {}})
        # tempfiles use prefix "."+path.name+"-"
        leftovers = [p.name for p in tmp_path.iterdir() if p.name.startswith(".") and p.name.endswith(".tmp")]
        assert leftovers == []

    def test_chmod_0o600_on_create(self, tmp_path):
        if not hasattr(os, "getuid"):
            pytest.skip("POSIX permissions not meaningful here")
        cfg = tmp_path / ".mcp.json"
        write_json_mcp_config(cfg, {"command": "lightbulb-mcp", "args": [], "env": {}})
        mode = stat.S_IMODE(cfg.stat().st_mode)
        assert mode == 0o600

    def test_rejects_non_dict_existing_config(self, tmp_path):
        cfg = tmp_path / ".mcp.json"
        cfg.write_text(json.dumps(["not", "an", "object"]))
        with pytest.raises(RuntimeError, match="not a JSON object"):
            write_json_mcp_config(cfg, {"command": "x"})

    def test_rejects_symlinked_config(self, tmp_path):
        if not hasattr(os, "symlink"):
            pytest.skip("symlinks not available")
        target = tmp_path / "real.json"
        target.write_text("{}")
        link = tmp_path / "link.json"
        try:
            os.symlink(target, link)
        except (OSError, NotImplementedError):
            pytest.skip("symlinks not supported")
        with pytest.raises(RuntimeError, match="symlink"):
            write_json_mcp_config(link, {"command": "x"})


# ── M10: auth error messages don't leak resp.text ────────────────────


class TestAuthErrorMessages:

    def test_login_error_is_status_only(self):
        from lightbulb.auth import login

        resp = MagicMock()
        resp.status_code = 500
        resp.text = "leaked-credential-or-pii-content-that-should-not-bubble-up"

        with patch("lightbulb.auth.httpx.Client") as MockClient:
            instance = MockClient.return_value.__enter__.return_value
            instance.post.return_value = resp

            with pytest.raises(RuntimeError) as ei:
                login("http://localhost:8080", "u@co.com", "pw")
        msg = str(ei.value)
        # Status code is OK to include; raw body is not.
        assert "500" in msg
        assert "leaked-credential" not in msg


# ── Errors / from_response ──────────────────────────────────────────


class TestErrors:

    def _make_response(self, status: int, body: dict | None = None, headers: dict | None = None):
        request = MagicMock()
        request.url = MagicMock()
        request.url.path = "/api/x"
        resp = MagicMock(spec=httpx.Response)
        resp.status_code = status
        resp.json.return_value = body or {}
        resp.headers = headers or {}
        resp.request = request
        return resp

    def test_401_maps_to_authentication_error(self):
        err = from_response(self._make_response(401, {"message": "expired"}))
        assert isinstance(err, AuthenticationError)
        assert err.status_code == 401
        assert "expired" in str(err)

    def test_403_maps_to_permission_denied(self):
        err = from_response(self._make_response(403, {"message": "nope"}))
        assert isinstance(err, PermissionDenied)

    def test_404_maps_to_not_found(self):
        err = from_response(self._make_response(404))
        assert isinstance(err, NotFoundError)

    def test_429_includes_retry_after_header(self):
        err = from_response(self._make_response(429, headers={"retry-after": "30"}))
        assert isinstance(err, RateLimitedError)
        assert err.retry_after == 30.0

    def test_5xx_maps_to_server_error(self):
        for status in (500, 502, 503, 504):
            err = from_response(self._make_response(status))
            assert isinstance(err, ServerError)

    def test_validation_error_is_also_value_error(self):
        """Backward compat — existing `except ValueError` clauses must still catch."""
        try:
            raise ValidationError("bad input")
        except ValueError as exc:
            assert isinstance(exc, ValidationError)

    def test_safe_message_does_not_leak_other_keys(self):
        """from_response must NOT include full body, only message/error/detail."""
        body = {
            "message": "validation failed",
            "leaked_token": "eyJsecret",
            "stack_trace": "internal info",
        }
        err = from_response(self._make_response(400, body))
        # The error message should be the validation message, not the body.
        assert "validation failed" in str(err)
        assert "eyJsecret" not in str(err)
        assert "stack_trace" not in str(err)


# ── Validators module sanity ─────────────────────────────────────────


class TestRefreshAuth:
    """The auth_refresh hook lets callers swap in fresh credentials after a 401."""

    def test_no_callback_means_no_refresh(self):
        client = LightbulbClient("http://localhost:8080", auth=_auth())
        assert client.refresh_auth() is False

    def test_callback_swaps_in_new_auth(self):
        new_auth = ApiKeyAuth(
            api_key="new-api-key-long-enough",
            tenant_id="00000000-0000-0000-0000-000000000001",
            user_id="00000000-0000-0000-0000-000000000002",
        )
        client = LightbulbClient(
            "http://localhost:8080",
            auth=_auth(),
            auth_refresh=lambda: new_auth,
        )
        assert client.refresh_auth() is True
        assert client._auth is new_auth

    def test_callback_failure_returns_false(self):
        def boom():
            raise RuntimeError("network down")
        client = LightbulbClient(
            "http://localhost:8080",
            auth=_auth(),
            auth_refresh=boom,
        )
        assert client.refresh_auth() is False
        # Original auth still in place
        assert client._auth is not None

    def test_returning_none_is_a_noop(self):
        client = LightbulbClient(
            "http://localhost:8080",
            auth=_auth(),
            auth_refresh=lambda: None,
        )
        original = client._auth
        assert client.refresh_auth() is False
        assert client._auth is original


class TestValidators:

    def test_validate_method_rejects_smuggling(self):
        with pytest.raises(ValidationError):
            validate_method("GET; CONNECT")

    def test_validate_method_uppercases(self):
        assert validate_method("get") == "GET"

    def test_validate_choice_rejects_unknown(self):
        with pytest.raises(ValidationError):
            validate_choice("foo", {"a", "b"}, "x")

    def test_validate_relative_path_strips_leading_slash(self):
        assert validate_relative_path("/api/x") == "api/x"

    def test_validate_relative_path_blocks_protocol_relative(self):
        with pytest.raises(ValidationError):
            validate_relative_path("//evil.com/x")
