"""Single source of truth for package version (CLI User-Agent, hatch, __init__)."""

__version__ = "0.5.1"
