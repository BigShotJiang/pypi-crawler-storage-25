# Lightbulb MCP server

The MCP server exposes the Lightbulb platform as tools for AI hosts (Claude Code, Codex CLI, Cursor, etc.). Every call runs as the **authenticated user** through Spring Boot: tenant isolation, company isolation, RBAC, and rate limits match the web app—there is no elevated “MCP service role.”

Companion CLI documentation: [README.md](README.md).

## Run

After `pip install lightbulb-mcp`:

```bash
lightbulb-mcp
```

Equivalent:

```bash
python -m lightbulb.mcp_server
```

The host should spawn this command with **stdio** transport (default MCP). Example `.mcp.json` fragment:

```json
{
  "mcpServers": {
    "lightbulb": {
      "command": "lightbulb-mcp",
      "env": {
        "LIGHTBULB_URL": "https://agents.lightbulbpartners.com"
      }
    }
  }
}
```

Use `command` + `args` if `lightbulb-mcp` is not on `PATH`:

```json
"command": "python",
"args": ["-m", "lightbulb.mcp_server"]
```

## Authentication

The server resolves credentials in an order similar to the CLI:

1. **`LIGHTBULB_JWT`** + **`LIGHTBULB_TENANT_ID`** (optional `LIGHTBULB_COMPANY_ID`) — e.g. token from a browser session.
2. **`LIGHTBULB_API_KEY`** + **`LIGHTBULB_TENANT_ID`** + **`LIGHTBULB_USER_ID`** — localhost / integration bootstrap.
3. **Cached device-flow token** under `~/.lightbulb/tokens/` (shared with `lightbulb` CLI).
4. **`LIGHTBULB_EMAIL`** + **`LIGHTBULB_PASSWORD`** — password login at startup (users with MFA must use device flow or JWT).

| Variable | Purpose |
|----------|---------|
| `LIGHTBULB_URL` | Platform URL (default `https://agents.lightbulbpartners.com`) |
| `LIGHTBULB_JWT` | Bearer JWT |
| `LIGHTBULB_TENANT_ID` | Tenant UUID (required with JWT) |
| `LIGHTBULB_COMPANY_ID` | Optional company scope |
| `LIGHTBULB_EMAIL` / `LIGHTBULB_PASSWORD` | Startup login (avoid for MFA-only accounts) |
| `LIGHTBULB_API_KEY` / `LIGHTBULB_USER_ID` | Local integration |

**HTTPS:** For non-loopback hostnames the SDK enforces HTTPS on the HTTP client unless the URL is explicitly local (`localhost`, `127.0.0.1`, etc.—parsed by hostname, not substring).

## Behaviour & scope

- **RBAC:** Tools map to platform endpoints the user is allowed to call; denied actions surface as errors (typically permission / validation), not silent success.
- **Company context:** Instructions remind admin users to select company when required (same as product behaviour).
- **Rate limits:** Platform rate limits apply per user/session like normal API usage.
- **Retries:** The MCP layer may retry on behalf of the host where documented in code (e.g. auth refresh paths); tools themselves do not bypass server-side throttling.

## Tool surface

The server registers a large set of tools (on the order of **150+**): domain `dispatch_domain_agent`, documents, page/document builders, code workspaces, voice/HITL, AOC, HR live, RAG, connectors (`invoke_tool`), CRM tasks, memory graph, approvals, notifications, domain workspace helpers, Xero/Stripe-oriented flows where exposed, etc.

Domain names and actions should follow `agent-workers/agents/domain_registry.py` on the platform; the MCP system prompt summarizes common domains.

### Software delivery loop tools

Claude Code, Codex, Cursor, and other MCP hosts can use these tools as the
preferred bridge into Lightbulb's software/user-feedback/deployment loop:

- `software_delivery_context` — read the current IT/Ops, coding workspace,
  GitHub/Jira/Slack/Notion, memory, approval, CloudOps, and deployment context
  before editing code.
- `software_delivery_loop` — route a user-feedback or engineering request into
  the governed loop: SDLC context, CodingAgent, repo binding, PR, container
  release, CloudOps, deployment gates, and HITL.
- `software_spot_weld_fix` — request a bounded urgent code/prod/cloud fix. It
  defaults to preview mode, opens a PR, keeps deploy disabled, and marks
  production/cloud work as approval-gated.

The MCP layer does not grant elevated privileges. All three tools run as the
authenticated user and rely on the same tenant/company/RBAC and approval gates
as the web application.

## Troubleshooting

| Symptom | Things to check |
|---------|------------------|
| **401 / AuthenticationError** | JWT expired → run `lightbulb setup` or refresh env JWT; MFA users should prefer device flow / cached token / JWT, not raw password. |
| **403** | Missing RBAC permission for that endpoint; confirm role in admin UI. |
| **HTTPS errors** | Use `https://` for production hosts; for local dev use `http://localhost:...`. |
| **Module not found (`mcp`)** | Reinstall: `pip install --upgrade lightbulb-mcp`. |
| **Stale config** | `lightbulb` / `lightbulb setup` status shows whether MCP entries exist for each host editor. |

## Security posture (MCP)

- Secrets live in **host env** or OS token cache—never commit `.mcp.json` with passwords or JWTs.
- Token cache files are user-private and written atomically (see SDK README).
- Error paths avoid echoing full HTTP bodies to logs/tracebacks where the SDK controls messaging.

## Version history (MCP-facing)

### 0.4.0

- Same transport and env vars; underlying HTTP client aligns with SDK security fixes (URLs, localhost detection, error sanitization).
- Tool count and names unchanged from 0.3.x series unless platform endpoints moved (regenerate from server package when upgrading).

### 0.3.0

- Major expansion of tool families (voice, HR live, code workspace collaboration/runtimes, AOC, memory graph, CRM tasks, approvals, notifications, domain workspaces, Xero helpers, page/document automation, etc.).
- `lightbulb-mcp` console script added for portable configs.

### 0.2.0

- Broad domain registry alignment and Xero-oriented tooling alongside existing Stripe/workflows surface.
