# coding=utf-8
import math
from deco.model import DecompressionModel

# Constantes Buhlmenn ZHL-16 pour l'air
BUHLMANN_PERIODS = [4, 8, 12.5, 18.5, 27, 38.3, 54.3, 77, 109, 146, 187, 239, 305, 390, 498, 635]  # minutes
BUHLMANN_A = [1.2599, 1.0000, 0.8618, 0.7562, 0.6667, 0.5933, 0.5282, 0.4701, 0.4187, 0.3798, 0.3497, 0.3223, 0.2971, 0.2737, 0.2523, 0.2327]
BUHLMANN_B = [0.5050, 0.6514, 0.7222, 0.7825, 0.8126, 0.8434, 0.8693, 0.8910, 0.9092, 0.9222, 0.9319, 0.9403, 0.9477, 0.9544, 0.9602, 0.9653]

PP_N2_AIR = 0.7902
PP_H2O_ALVEOLAIRE = 0.0627


class Compartment:
    def __init__(self, period, a, b):
        self.period = period  # en minutes
        self.a = a
        self.b = b
        self.tension = PP_N2_AIR * 1.0  # Tension initiale a la surface (1 bar * fraction N2)

    def update_tension(self, pn2_inspired, time_minutes):
        """
        Met a jour la tension du compartiment selon l'equation de Buhlmenn
        P = P0 + (Pi - P0) * (1 - 2^(-t/period))
        """
        k = math.log(2) / self.period
        self.tension = self.tension + (pn2_inspired - self.tension) * (1 - math.exp(-k * time_minutes))

    def get_critical_pressure(self):
        """
        Calcule la pression critique pour ce compartiment
        """
        return self.a + self.b * self.tension


class DecompressionModelBuhlmann(DecompressionModel):
    def __init__(self, gas_mixture=None):
        self.compartments = []
        for i in range(16):
            self.compartments.append(Compartment(BUHLMANN_PERIODS[i], BUHLMANN_A[i], BUHLMANN_B[i]))

        # Support pour differents melanges gazeux
        if gas_mixture is None:
            self.gas_mixture = {"N2": 0.7902, "O2": 0.2095, "Ar": 0.0003}
        else:
            self.gas_mixture = gas_mixture

        self.pp_n2 = self.gas_mixture.get("N2", 0.7902)
        self.dive_profile = []

    def append(self, time: int, depth: int, gas_mixture=None, **options):
        """
        Ajouter un segment de plongee
        :param time: temps en minutes
        :param depth: profondeur en metres
        :param gas_mixture: melange gazeux optionnel
        """
        if gas_mixture is not None:
            self.gas_mixture = gas_mixture
            self.pp_n2 = self.gas_mixture.get("N2", 0.7902)

        # Calculer la pression absolue
        p_abs = (depth / 10) + 1  # 10m = 1 bar

        # Pression partielle d'azote inspire
        pn2_inspired = self.pp_n2 * p_abs

        # Mettre a jour tous les compartiments
        for compartment in self.compartments:
            compartment.update_tension(pn2_inspired, time)

        # Stocker le segment
        self.dive_profile.append({
            'time': time,
            'depth': depth,
            'gas_mixture': self.gas_mixture.copy(),
            'tensions': [c.tension for c in self.compartments]
        })

        return self.get_max_tension()

    def reset(self):
        """
        Reinitialiser le modele
        """
        for compartment in self.compartments:
            compartment.tension = PP_N2_AIR * 1.0
        self.dive_profile = []

    def get_max_tension(self):
        """
        Retourne la tension maximale parmi tous les compartiments
        """
        return max(c.tension for c in self.compartments)

    def decompression_stop(self, **kwargs):
        """
        Calcule les paliers de decompression selon Buhlmenn
        :return: tuple (temps_total, profondeur_max, palier_12m, palier_9m, palier_6m, palier_3m, GPS)
        """
        if not self.dive_profile:
            return (0, 0, 0, 0, 0, 0, 'A')

        # Profondeur maximale
        max_depth = max(segment['depth'] for segment in self.dive_profile)

        # Temps total
        total_time = sum(segment['time'] for segment in self.dive_profile)

        # Calculer les paliers
        stops = self._calculate_decompression_stops()

        return (total_time, max_depth, stops[0], stops[1], stops[2], stops[3], 'N')  # GPS simplifie

    def _calculate_decompression_stops(self):
        """
        Calcule les paliers de decompression
        :return: tuple (palier_12m, palier_9m, palier_6m, palier_3m)
        """
        # Profondeurs de palier standard (en metres)
        stop_depths = [12, 9, 6, 3]

        stops = [0, 0, 0, 0]  # palier_12m, palier_9m, palier_6m, palier_3m

        # Pour chaque profondeur de palier, calculer le temps necessaire
        for i, stop_depth in enumerate(stop_depths):
            p_abs_stop = (stop_depth / 10) + 1
            pn2_stop = self.pp_n2 * p_abs_stop

            # Trouver le compartiment le plus lent (celui qui necessite le plus de temps)
            max_time = 0
            for compartment in self.compartments:
                if compartment.get_critical_pressure() > pn2_stop:
                    # Calculer le temps necessaire pour descendre en dessous du seuil critique
                    # Approximation simplifiee
                    time_needed = self._calculate_ascent_time(compartment, pn2_stop)
                    max_time = max(max_time, time_needed)

            stops[i] = max_time

        return stops

    def _calculate_ascent_time(self, compartment, target_pn2):
        """
        Calcule le temps d'ascension necessaire pour un compartiment
        Approximation simplifiee
        """
        if compartment.tension <= target_pn2:
            return 0

        # Vitesse d'ascension typique (1 m/min = 0.1 bar/min)
        ascent_rate = 0.1  # bar/min

        # Difference de pression
        delta_p = compartment.tension - target_pn2

        # Temps approximatif (tres simplifie)
        # En realite, il faudrait resoudre l'equation differentielle
        time = delta_p / ascent_rate

        return int(time)