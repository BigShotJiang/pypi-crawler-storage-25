import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="decompression-diver",
    version="1.1.0",
    author="Fred Pidancier",
    author_email="frederic.pidancier@gmail.com",
    description="Diving decompression library (MN90, compartment model)",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/pidancier/decompression",
    packages=setuptools.find_packages(
        exclude=("deco.test", "deco.test.*")
    ),
    package_data={"deco": ["resources/*.csv"]},
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: Apache Software License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    include_package_data=True,
)
