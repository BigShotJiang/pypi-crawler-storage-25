from as3lib import (ArgumentError, false, Infinity, Math, NaN, null, Number,
                    Object, RangeError, true, TypeError, undefined, Vector)
from as3lib.flash.display import Sprite, MovieClip
from as3lib.flash.geom import (ColorTransform, Matrix, Matrix3D,
                               PerspectiveProjection, Point, Rectangle,
                               Utils3D, Vector3D)
from as3lib.tests import as3libTestCase, TestNotImplemented


class MatrixTests(as3libTestCase):
   def test_constructor(self):
      self.assertMatrix(Matrix(), 1, 0, 0, 1, 0, 0)
      self.assertMatrix(Matrix(1), 1, 0, 0, 1, 0, 0)
      self.assertMatrix(Matrix(1, 2), 1, 2, 0, 1, 0, 0)
      self.assertMatrix(Matrix(1, 2, 3), 1, 2, 3, 1, 0, 0)
      self.assertMatrix(Matrix(1, 2, 3, 4), 1, 2, 3, 4, 0, 0)
      self.assertMatrix(Matrix(1, 2, 3, 4, 5), 1, 2, 3, 4, 5, 0)
      self.assertMatrix(Matrix(1, 2, 3, 4, 5, 6), 1, 2, 3, 4, 5, 6)

   def test_indentity(self):
      matrix = Matrix(1, 2, 3, 4, 5, 6)
      matrix.identity()
      self.assertMatrix(matrix, 1, 0, 0, 1, 0, 0)

   def test_clone(self):
      matrix = Matrix(1, 2, 3, 4, 5, 6)
      cloned = matrix.clone()

      self.assertMatrix(cloned, 1, 2, 3, 4, 5, 6)
      self.assertIsNot(cloned, matrix)

   def test_scale(self):
      matrix = Matrix()
      matrix.scale(3, 5)
      self.assertMatrix(matrix, 3, 0, 0, 5, 0, 0)

      matrix = Matrix(2, 0, 0, 2, 100, 100)
      matrix.scale(7, 11)
      self.assertMatrix(matrix, 14, 0, 0, 22, 700, 1100)

      matrix = Matrix(1, 2, 3, 4, 5, 6)
      matrix.scale(13, 17)
      self.assertMatrix(matrix, 13, 34, 39, 68, 65, 102)

   def test_rotate(self):
      matrix = Matrix()
      matrix.rotate(0)
      self.assertMatrix(matrix, 1, 0, 0, 1, 0, 0)

      matrix = Matrix()
      matrix.rotate(0.5)
      self.assertMatrix(matrix, 0.8775825618903728, 0.479425538604203,
                        -0.479425538604203, 0.8775825618903728, 0, 0)

      matrix = Matrix(1, 2, 3, 4, 5, 6)
      matrix.rotate(0)
      self.assertMatrix(matrix, 1, 2, 3, 4, 5, 6)

      matrix = Matrix(1, 2, 3, 4, 5, 6)
      matrix.rotate(Number(90/180)*Math.PI)
      self.assertMatrix(matrix, -2, 1.0000000000000002, -4,
                        3.0000000000000004, -6, 5)

   def test_translate(self):
      matrix = Matrix()
      matrix.translate(3, 5)
      self.assertMatrix(matrix, 1, 0, 0, 1, 3, 5)

      matrix = Matrix(2, 0, 0, 2, 100, 100)
      matrix.translate(7, 11)
      self.assertMatrix(matrix, 2, 0, 0, 2, 107, 111)

   def test_invert(self):
      matrix = Matrix()
      matrix.invert()
      self.assertMatrix(matrix, 1, 0, 0, 1, 0, 0)

      matrix = Matrix(2, 3, 5, 7, 9, 11)
      matrix.invert()
      self.assertMatrix(matrix, -7, 3, 5, -2, 8, -5)

   def test_createBox(self):
      matrix = Matrix()
      matrix.createBox(2, 3)
      self.assertMatrix(matrix, 2, 0, 0, 3, 0, 0)

      matrix.createBox(2, 3, 0)
      self.assertMatrix(matrix, 2, 0, 0, 3, 0, 0)

      matrix.createBox(2, 3, 5)
      self.assertMatrix(matrix, 0.5673243709264525, -2.8767728239894153,
                        1.917848549326277, 0.8509865563896788, 0, 0)

      matrix.createBox(2, 3, 5, 7)
      self.assertMatrix(matrix, 0.5673243709264525, -2.8767728239894153,
                        1.917848549326277, 0.8509865563896788, 7, 0)

      matrix.createBox(2, 3, 5, 7, 9)
      self.assertMatrix(matrix, 0.5673243709264525, -2.8767728239894153,
                        1.917848549326277, 0.8509865563896788, 7, 9)

   def test_createGradientBox(self):
      matrix = Matrix()
      matrix.createGradientBox(200, 300)
      self.assertMatrix(matrix, 0.1220703125, 0, 0, 0.18310546875, 100, 150)

      matrix.createGradientBox(200, 300, 0)
      self.assertMatrix(matrix, 0.1220703125, 0, 0, 0.18310546875, 100, 150)

      matrix.createGradientBox(200, 300, 500)
      self.assertMatrix(matrix, -0.10789175701067846, -0.08565157568160574,
                        0.05710105045440383, -0.1618376355160177, 100, 150)

      matrix.createGradientBox(200, 300, 500, 700)
      self.assertMatrix(matrix, -0.10789175701067846, -0.08565157568160574,
                        0.05710105045440383, -0.1618376355160177, 800, 150)

      matrix.createGradientBox(200, 300, 500, 700, 900)
      self.assertMatrix(matrix, -0.10789175701067846, -0.08565157568160574,
                        0.05710105045440383, -0.1618376355160177, 800, 1050)

   def test_transformPoint(self):
      matrix = Matrix(2, 3, 5, 7, 11, 13)
      point = matrix.transformPoint(Point(1, 1))
      self.assertPoint(point, 18, 23)

   def test_deltaTransformPoint(self):
      matrix = Matrix(2, 3, 5, 7, 11, 13)
      point = matrix.deltaTransformPoint(Point(1, 1))
      self.assertPoint(point, 7, 10)

   def test_copyFrom(self):
      matrix = Matrix(2, 3, 5, 7, 11, 13)
      matrix2 = Matrix()
      self.assertMatrix(matrix2, 1, 0, 0, 1, 0, 0)
      matrix2.copyFrom(matrix)
      self.assertMatrix(matrix2, 2, 3, 5, 7, 11, 13)

   def test_setTo(self):
      matrix = Matrix()
      matrix.setTo(2, 3, 5, 7, 11, 13)
      self.assertMatrix(matrix, 2, 3, 5, 7, 11, 13)

   def test_copyRowTo(self):
      matrix = Matrix(2, 3, 5, 7, 11, 13)
      vector = Vector3D(1, 2, 3, 4)

      matrix.copyRowTo(0, vector)
      self.assertVector3D(vector, 2, 5, 11)

      matrix.copyRowTo(1, vector)
      self.assertVector3D(vector, 3, 7, 13)

      matrix.copyRowTo(2, vector)
      self.assertVector3D(vector, 0, 0, 1)

      matrix.copyRowTo(3, vector)
      self.assertVector3D(vector, 0, 0, 1)

   def test_copyColumnTo(self):
      matrix = Matrix(2, 3, 5, 7, 11, 13)
      vector = Vector3D(1, 2, 3, 4)

      matrix.copyColumnTo(0, vector)
      self.assertVector3D(vector, 2, 3, 0)

      matrix.copyColumnTo(1, vector)
      self.assertVector3D(vector, 5, 7, 0)

      matrix.copyColumnTo(2, vector)
      self.assertVector3D(vector, 11, 13, 1)

      matrix.copyColumnTo(3, vector)
      self.assertVector3D(vector, 11, 13, 1)

   def test_copyRowFrom(self):
      matrix = Matrix(2, 3, 5, 7, 11, 13)
      vector = Vector3D(17, 19, 23, 29)

      matrix.copyRowFrom(0, vector)
      self.assertMatrix(matrix, 17, 3, 19, 7, 23, 13)

      matrix.copyRowFrom(1, vector)
      self.assertMatrix(matrix, 17, 17, 19, 19, 23, 23)

      matrix.copyRowFrom(2, vector)
      self.assertMatrix(matrix, 17, 17, 19, 19, 23, 23)

      matrix.copyRowFrom(3, vector)
      self.assertMatrix(matrix, 17, 17, 19, 19, 23, 23)

   def test_copyColumnFrom(self):
      matrix = Matrix(2, 3, 5, 7, 11, 13)
      vector = Vector3D(17, 19, 23, 29)

      matrix.copyColumnFrom(0, vector)
      self.assertMatrix(matrix, 17, 3, 19, 7, 23, 13)

      matrix.copyColumnFrom(1, vector)
      self.assertMatrix(matrix, 17, 17, 19, 19, 23, 23)

      matrix.copyColumnFrom(2, vector)
      self.assertMatrix(matrix, 17, 17, 19, 19, 23, 23)

      matrix.copyColumnFrom(3, vector)
      self.assertMatrix(matrix, 17, 17, 19, 19, 23, 23)


class MatrixConcatTests(as3libTestCase):
   @classmethod
   def setUpClass(cls):
      cls.matrix = Matrix(11, 13, 17, 19, 23, 29)
      cls.scale = Matrix()
      cls.scale.scale(3, 5)
      cls.translate = Matrix()
      cls.translate.translate(7, 9)
      cls.rotate = Matrix()
      cls.rotate.rotate(Math.PI / 2)

   def assertMatrixClose(self, matrix, a, b, c, d, tx, ty):
      # TODO: Remove this once Number is used instead of float
      self.assertAlmostEqual(matrix.a, a, 15)
      self.assertAlmostEqual(matrix.b, b, 15)
      self.assertAlmostEqual(matrix.c, c, 15)
      self.assertAlmostEqual(matrix.d, d, 15)
      self.assertAlmostEqual(matrix.tx, tx, 15)
      self.assertAlmostEqual(matrix.ty, ty, 15)

   def test_double(self):
      # Scale + Translate
      result = self.scale.clone()
      result.concat(self.translate)
      self.assertMatrix(result, 3, 0, 0, 5, 7, 9)

      # Translate + Scale
      result = self.translate.clone()
      result.concat(self.scale)
      self.assertMatrix(result, 3, 0, 0, 5, 21, 45)

      # TODO: Fails because python uses one extra digit of precision
      # Scale + Rotate
      result = self.scale.clone()
      result.concat(self.rotate)
      self.assertMatrixClose(result, 1.836970198721029e-16, 3, -5,
                             3.0616169978683834e-16, 0, 0)

      # Rotate + Scale
      result = self.rotate.clone()
      result.concat(self.scale)
      self.assertMatrixClose(result, 1.836970198721029e-16, 5, -3,
                             3.0616169978683834e-16, 0, 0)

      # Translate + Rotate
      result = self.translate.clone()
      result.concat(self.rotate)
      self.assertMatrixClose(result, 6.123233995736766e-17, 1, -1,
                             6.123233995736766e-17, -9, 7.000000000000001)

      # Rotate + Translate
      result = self.rotate.clone()
      result.concat(self.translate)
      self.assertMatrixClose(result, 6.123233995736766e-17, 1, -1,
                             6.123233995736766e-17, 7, 9)

   def test_triple(self):
      # Scale + Translate + Rotate
      result = self.scale.clone()
      result.concat(self.translate)
      result.concat(self.rotate)
      self.assertMatrixClose(result, 1.836970198721029e-16, 3, -5,
                             3.0616169978683834e-16, -9, 7.000000000000001)

      # Scale + Rotate + Translate
      result = self.scale.clone()
      result.concat(self.rotate)
      result.concat(self.translate)
      self.assertMatrixClose(result, 1.836970198721029e-16, 3, -5,
                             3.0616169978683834e-16, 7, 9)

      # Translate + Scale + Rotate
      result = self.translate.clone()
      result.concat(self.scale)
      result.concat(self.rotate)
      self.assertMatrixClose(result, 1.836970198721029e-16, 3, -5,
                             3.0616169978683834e-16, -45, 21.000000000000004)

      # Translate + Rotate + Scale
      result = self.translate.clone()
      result.concat(self.rotate)
      result.concat(self.scale)
      self.assertMatrixClose(result, 1.836970198721029e-16, 5, -3,
                             3.0616169978683834e-16, -27, 35.00000000000001)

      # Rotate + Translate + Scale
      result = self.rotate.clone()
      result.concat(self.translate)
      result.concat(self.scale)
      self.assertMatrixClose(result, 1.836970198721029e-16, 5, -3,
                             3.0616169978683834e-16, 21, 45)

      # Rotate + Scale + Translate
      result = self.rotate.clone()
      result.concat(self.scale)
      result.concat(self.translate)
      self.assertMatrixClose(result, 1.836970198721029e-16, 5, -3,
                             3.0616169978683834e-16, 7, 9)

   def test_right_single(self):
      # Matrix + Scale
      result = self.matrix.clone()
      result.concat(self.scale)
      self.assertMatrix(result, 33, 65, 51, 95, 69, 145)

      # Matrix + Transform
      result = self.matrix.clone()
      result.concat(self.translate)
      self.assertMatrix(result, 11, 13, 17, 19, 30, 38)

      # Matrix + Rotate
      result = self.matrix.clone()
      result.concat(self.rotate)
      self.assertMatrix(result, -13, 11, -19, 17, -29, 23)

   def test_right_double(self):
      # Matrix + Scale + Translate
      result = self.matrix.clone()
      result.concat(self.scale)
      result.concat(self.translate)
      self.assertMatrix(result, 33, 65, 51, 95, 76, 154)

      # Matrix + Translate + Scale
      result = self.matrix.clone()
      result.concat(self.translate)
      result.concat(self.scale)
      self.assertMatrix(result, 33, 65, 51, 95, 90, 190)

      # Matrix + Scale + Rotate
      result = self.matrix.clone()
      result.concat(self.scale)
      result.concat(self.rotate)
      self.assertMatrix(result, -65, 33.00000000000001, -95,
                        51.00000000000001, -145, 69.00000000000001)

      # Matrix + Rotate + Scale
      result = self.matrix.clone()
      result.concat(self.rotate)
      result.concat(self.scale)
      self.assertMatrix(result, -39, 55, -57, 85, -87, 115)

      # Matrix + Translate + Rotate
      result = self.matrix.clone()
      result.concat(self.translate)
      result.concat(self.rotate)
      self.assertMatrix(result, -13, 11, -19, 17, -38, 30.000000000000004)

      # Matrix + Rotate + Translate
      result = self.matrix.clone()
      result.concat(self.rotate)
      result.concat(self.translate)
      self.assertMatrix(result, -13, 11, -19, 17, -22, 32)

   def test_right_triple(self):
      # Matrix + Scale + Translate + Rotate
      result = self.matrix.clone()
      result.concat(self.scale)
      result.concat(self.translate)
      result.concat(self.rotate)
      self.assertMatrix(result, -65, 33.00000000000001, -95,
                        51.00000000000001, -154, 76.00000000000001)

      # Matrix + Scale + Rotate + Translate
      result = self.matrix.clone()
      result.concat(self.scale)
      result.concat(self.rotate)
      result.concat(self.translate)
      self.assertMatrix(result, -65, 33.00000000000001, -95,
                        51.00000000000001, -138, 78.00000000000001)

      # Matrix + Translate + Scale + Rotate
      result = self.matrix.clone()
      result.concat(self.translate)
      result.concat(self.scale)
      result.concat(self.rotate)
      self.assertMatrix(result, -65, 33.00000000000001, -95,
                        51.00000000000001, -190, 90.00000000000001)

      # Matrix + Translate + Rotate + Scale
      result = self.matrix.clone()
      result.concat(self.translate)
      result.concat(self.rotate)
      result.concat(self.scale)
      self.assertMatrix(result, -39, 55, -57, 85, -114, 150.00000000000003)

      # Matrix + Rotate + Translate + Scale
      result = self.matrix.clone()
      result.concat(self.rotate)
      result.concat(self.translate)
      result.concat(self.scale)
      self.assertMatrix(result, -39, 55, -57, 85, -66, 160)

      # Matrix + Rotate + Scale + Translate
      result = self.matrix.clone()
      result.concat(self.rotate)
      result.concat(self.scale)
      result.concat(self.translate)
      self.assertMatrix(result, -39, 55, -57, 85, -80, 124)

   def test_left_single(self):
      # Scale + Matrix
      result = self.scale.clone()
      result.concat(self.matrix)
      self.assertMatrix(result, 33, 39, 85, 95, 23, 29)

      # Translate + Matrix
      result = self.translate.clone()
      result.concat(self.matrix)
      self.assertMatrix(result, 11, 13, 17, 19, 253, 291)

      # Rotate + Matrix
      result = self.rotate.clone()
      result.concat(self.matrix)
      self.assertMatrix(result, 17, 19, -10.999999999999998,
                        -12.999999999999998, 23, 29)

   def test_left_double(self):
      # Scale + Translate + Matrix
      result = self.scale.clone()
      result.concat(self.translate)
      result.concat(self.matrix)
      self.assertMatrix(result, 33, 39, 85, 95, 253, 291)

      # Translate + Scale + Matrix
      result = self.translate.clone()
      result.concat(self.scale)
      result.concat(self.matrix)
      self.assertMatrix(result, 33, 39, 85, 95, 1019, 1157)

      # Scale + Rotate + Matrix
      result = self.scale.clone()
      result.concat(self.rotate)
      result.concat(self.matrix)
      self.assertMatrix(result, 51, 57, -54.99999999999999, -65, 23, 29)

      # Rotate + Scale + Matrix
      result = self.rotate.clone()
      result.concat(self.scale)
      result.concat(self.matrix)
      self.assertMatrix(result, 85, 95, -32.99999999999999,
                        -38.99999999999999, 23, 29)

      # Translate + Rotate + Matrix
      result = self.translate.clone()
      result.concat(self.rotate)
      result.concat(self.matrix)
      self.assertMatrix(result, 17, 19, -10.999999999999998,
                        -12.999999999999998, 43.000000000000014,
                        45.00000000000003)

      # Rotate + Translate + Matrix
      result = self.rotate.clone()
      result.concat(self.translate)
      result.concat(self.matrix)
      self.assertMatrix(result, 17, 19, -10.999999999999998,
                        -12.999999999999998, 253, 291)

   def test_left_triple(self):
      # scale + translate + rotate + matrix
      result = self.scale.clone()
      result.concat(self.translate)
      result.concat(self.rotate)
      result.concat(self.matrix)
      self.assertMatrix(result, 51, 57, -54.99999999999999, -65,
                        43.000000000000014, 45.00000000000003)

      # scale + rotate + translate + matrix
      result = self.scale.clone()
      result.concat(self.rotate)
      result.concat(self.translate)
      result.concat(self.matrix)
      self.assertMatrix(result, 51, 57, -54.99999999999999, -65, 253, 291)

      # translate + scale + rotate + matrix
      result = self.translate.clone()
      result.concat(self.scale)
      result.concat(self.rotate)
      result.concat(self.matrix)
      self.assertMatrix(result, 51, 57, -54.99999999999999, -65,
                        -114.99999999999994, -156.99999999999994)

      # translate + rotate + scale + matrix
      result = self.translate.clone()
      result.concat(self.rotate)
      result.concat(self.scale)
      result.concat(self.matrix)
      self.assertMatrix(result, 85, 95, -32.99999999999999,
                        -38.99999999999999, 321.0000000000001,
                        343.0000000000001)

      # rotate + translate + scale + matrix
      result = self.rotate.clone()
      result.concat(self.translate)
      result.concat(self.scale)
      result.concat(self.matrix)
      self.assertMatrix(result, 85, 95, -32.99999999999999,
                        -38.99999999999999, 1019, 1157)

      # rotate + scale + translate + matrix
      result = self.rotate.clone()
      result.concat(self.scale)
      result.concat(self.translate)
      result.concat(self.matrix)
      self.assertMatrix(result, 85, 95, -32.99999999999999,
                        -38.99999999999999, 253, 291)

   def test_middle_double(self):
      # scale + matrix + translate
      result = self.scale.clone()
      result.concat(self.matrix)
      result.concat(self.translate)
      self.assertMatrix(result, 33, 39, 85, 95, 30, 38)

      # translate + matrix + scale
      result = self.translate.clone()
      result.concat(self.matrix)
      result.concat(self.scale)
      self.assertMatrix(result, 33, 65, 51, 95, 759, 1455)

      # scale + matrix + rotate
      result = self.scale.clone()
      result.concat(self.matrix)
      result.concat(self.rotate)
      self.assertMatrix(result, -39, 33, -95, 85, -29, 23)

      # rotate + matrix + scale
      result = self.rotate.clone()
      result.concat(self.matrix)
      result.concat(self.scale)
      self.assertMatrix(result, 51, 95, -32.99999999999999,
                        -64.99999999999999, 69, 145)

      # translate + matrix + rotate
      result = self.translate.clone()
      result.concat(self.matrix)
      result.concat(self.rotate)
      self.assertMatrix(result, -13, 11, -19, 17, -291, 253.00000000000003)

      # rotate + matrix + translate
      result = self.rotate.clone()
      result.concat(self.matrix)
      result.concat(self.translate)
      self.assertMatrix(result, 17, 19, -10.999999999999998,
                        -12.999999999999998, 30, 38)

   def test_middle_triple1(self):
      # scale + matrix + translate + rotate
      result = self.scale.clone()
      result.concat(self.matrix)
      result.concat(self.translate)
      result.concat(self.rotate)
      self.assertMatrix(result, -39, 33, -95, 85, -38, 30.000000000000004)

      # scale + matrix + rotate + translate
      result = self.scale.clone()
      result.concat(self.matrix)
      result.concat(self.rotate)
      result.concat(self.translate)
      self.assertMatrix(result, -39, 33, -95, 85, -22, 32)

      # translate + matrix + scale + rotate
      result = self.translate.clone()
      result.concat(self.matrix)
      result.concat(self.scale)
      result.concat(self.rotate)
      self.assertMatrix(result, -65, 33.00000000000001, -95,
                        51.00000000000001, -1455, 759.0000000000001)

      # translate + matrix + rotate + scale
      result = self.translate.clone()
      result.concat(self.matrix)
      result.concat(self.rotate)
      result.concat(self.scale)
      self.assertMatrix(result, -39, 55, -57, 85, -873, 1265.0000000000002)

      # rotate + matrix + translate + scale
      result = self.rotate.clone()
      result.concat(self.matrix)
      result.concat(self.translate)
      result.concat(self.scale)
      self.assertMatrix(result, 51, 95, -32.99999999999999,
                        -64.99999999999999, 90, 190)

      # rotate + matrix + scale + translate
      result = self.rotate.clone()
      result.concat(self.matrix)
      result.concat(self.scale)
      result.concat(self.translate)
      self.assertMatrix(result, 51, 95, -32.99999999999999,
                        -64.99999999999999, 76, 154)

   def test_middle_triple2(self):
      # scale + translate + matrix + rotate
      result = self.scale.clone()
      result.concat(self.translate)
      result.concat(self.matrix)
      result.concat(self.rotate)
      self.assertMatrix(result, -39, 33, -95, 85, -291, 253.00000000000003)

      # scale + rotate + matrix + translate
      result = self.scale.clone()
      result.concat(self.rotate)
      result.concat(self.matrix)
      result.concat(self.translate)
      self.assertMatrix(result, 51, 57, -54.99999999999999, -65, 30, 38)

      # translate + scale + matrix + rotate
      result = self.translate.clone()
      result.concat(self.scale)
      result.concat(self.matrix)
      result.concat(self.rotate)
      self.assertMatrix(result, -39, 33, -95, 85, -1157, 1019.0000000000001)

      # translate + rotate + matrix + scale
      result = self.translate.clone()
      result.concat(self.rotate)
      result.concat(self.matrix)
      result.concat(self.scale)
      self.assertMatrix(result, 51, 95, -32.99999999999999,
                        -64.99999999999999, 129.00000000000006,
                        225.00000000000014)

      # rotate + translate + matrix + scale
      result = self.rotate.clone()
      result.concat(self.translate)
      result.concat(self.matrix)
      result.concat(self.scale)
      self.assertMatrix(result, 51, 95, -32.99999999999999,
                        -64.99999999999999, 759, 1455)

      # rotate + scale + matrix + translate
      result = self.rotate.clone()
      result.concat(self.scale)
      result.concat(self.matrix)
      result.concat(self.translate)
      self.assertMatrix(result, 85, 95, -32.99999999999999,
                        -38.99999999999999, 30, 38)


class Matrix3DTests(as3libTestCase):
   def test_constructor(self):
      m = Matrix3D()
      asrt = (1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)
      self.assertMatrix3D(m, asrt)

   def test_appendScale(self):
      m = Matrix3D()
      m.appendScale(1, 2, 3)
      asrt = (1, 0, 0, 0, 0, 2, 0, 0, 0, 0, 3, 0, 0, 0, 0, 1)
      self.assertMatrix3D(m, asrt)

   def test_identity(self):
      v = Vector.Number([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
                         16])
      m = Matrix3D(v)

      asrt = (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16)
      self.assertMatrix3D(m, asrt)

      m.identity()

      asrt = (1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)
      self.assertMatrix3D(m, asrt)

   def test_determinant(self):
      # Zero
      v = Vector.Number([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
      m = Matrix3D(v)
      self.assertEqual(m.determinant, 0)

      v = Vector.Number([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
                         16])
      m = Matrix3D(v)
      self.assertEqual(m.determinant, 0)

      # Non-zero, randomly generated input
      v = Vector.Number([37, 48, 70, 38, 17, 33, 70, 52, 94, 89, 11, 4, 2, 43,
                         90, 50])
      m = Matrix3D(v)
      self.assertEqual(m.determinant, 1953360)

      v = Vector.Number([30, 76, 67, 56, 69, 61, 99, 11, 95, 92, 84, 24, 14,
                         35, 96, 71])
      m = Matrix3D(v)
      self.assertEqual(m.determinant, 8822702)

   def test_2(self):
      v = Vector.Number([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
                         16])
      m = Matrix3D(v)
      asrt = (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16)
      self.assertMatrix3D(m, asrt)

      self.assertVector3D(m.position, 13, 14, 15)
      m.position = Vector3D(12, 13, 14)
      self.assertVector3D(m.position, 12, 13, 14)

      m.prependTranslation(-1, 0, 2)
      self.assertVector3D(m.position, 29, 31, 33)
      asrt = (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 29, 31, 33, 36)
      self.assertMatrix3D(m, asrt)

      m.prepend(m)
      asrt = (154, 168, 182, 200, 330, 364, 398, 440, 506, 560, 614, 680,
              1525, 1690, 1855, 2056)
      self.assertMatrix3D(m, asrt)

      other = Matrix3D()
      other.copyFrom(m)
      self.assertMatrix3D(other, asrt)

      out = Vector.Number()
      out.length = 20
      m.copyRawDataTo(out, 1, True)
      asrt = (0, 154, 168, 182, 200, 330, 364, 398, 440, 506, 560, 614, 680,
              1525, 1690, 1855, 2056, 0, 0, 0)
      self.assertArray(out, asrt)
      m.copyRawDataTo(out, 2, True)
      asrt = (0, 154, 154, 330, 506, 1525, 168, 364, 560, 1690, 182, 398, 614,
              1855, 200, 440, 680, 2056, 0, 0)
      self.assertArray(out, asrt)

      v = Vector3D(1, 2, 3, 4)
      vOut = m.transformVector(v)
      self.assertVector3D(vOut, 3857, 4266, 4675, 5176)

      vecs = Vector.Number([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
      vecsOut = Vector.Number()
      m.transformVectors(vecs, vecsOut)
      asrt = (3857, 4266, 4675, 6827, 7542, 8257, 9797, 10818, 11839)
      self.assertArray(vecsOut, asrt)

      vecsOutFixed = Vector.Number(vecs.length, True)
      m.transformVectors(vecs, vecsOutFixed)
      asrt = (3857, 4266, 4675, 6827, 7542, 8257, 9797, 10818, 11839, 0)
      self.assertArray(vecsOutFixed, asrt)

      vecsOutFixedTooSmall = Vector.Number(4, True)
      self.assertRaises(RangeError, m.transformVector, vecs,
                        vecsOutFixedTooSmall)

      self.assertRaises(TypeError, m.transformVectors, null, vecsOut)
      self.assertRaises(TypeError, m.transformVectors, vecs, null)

      vOut = m.deltaTransformVector(v)
      self.assertVector3D(vOut, 2332, 2576, 2820, 3120)

      tooShort = Matrix3D(Vector.Number([1, 2]))
      asrt = (1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)
      self.assertMatrix3D(tooShort, asrt)

      v = Vector.Number([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
                         16, 17])
      tooLong = Matrix3D(v)
      self.assertMatrix3D(tooLong, asrt)

      modified = Vector.Number([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14,
                                15, 16])
      newMat = Matrix3D(modified)
      asrt = (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16)
      self.assertMatrix3D(newMat, asrt)
      modified[0] = 9999
      self.assertMatrix3D(newMat, asrt)

      v = Vector.Number([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
                         16])
      newMat = Matrix3D(v)
      col = Vector3D()
      check = ((1, 2, 3, 4), (5, 6, 7, 8), (9, 10, 11, 12), (13, 14, 15, 16))
      for i in range(4):
         newMat.copyColumnTo(i, col)
         self.assertVector3D(col, *check[i])

      self.assertRaises(ArgumentError, newMat.copyColumnTo, 4, col)

      row = Vector3D()
      check = ((1, 5, 9, 13), (2, 6, 10, 14), (3, 7, 11, 15), (3, 8, 12, 16))
      for i in range(4):
         newMat.copyRowTo(i, row)
         self.assertVector3D(row, *check[i])

      self.assertRaises(ArgumentError, newMat.copyRowTo, 4, row)

      row0 = Vector3D(100, 200, 300, 400)
      row1 = Vector3D(500, 600, 700, 800)
      row2 = Vector3D(900, 1000, 1100, 1200)
      row3 = Vector3D(1300, 1400, 1500, 1600)

      newMat.copyRowFrom(0, row0)
      newMat.copyRowFrom(1, row1)
      newMat.copyRowFrom(2, row2)
      newMat.copyRowFrom(3, row3)

      self.assertRaises(ArgumentError, newMat.copyRowFrom, 4, row3)

      asrt = (100, 500, 900, 1300, 200, 600, 1000, 1400, 300, 700, 1100, 1500,
              400, 800, 1200, 1600)
      self.assertMatrix3D(newMat, asrt)

      newMat.prependRotation(90, Vector3D.X_AXIS)
      asrt = (100, 500, 900, 1300, 300, 700, 1100, 1500, -199.99999999999997,
              -600, -999.9999999999999, -1400, 400, 800, 1200, 1600)
      self.assertMatrix3D(newMat, asrt)

      newMat.prependScale(1, 2, 3)
      asrt = (100, 500, 900, 1300, 600, 1400, 2200, 3000, -599.9999999999999,
              -1800, -2999.9999999999995, -4200, 400, 800, 1200, 1600)
      self.assertMatrix(newMat, asrt)

   def test_copyColumnFrom(self):
      v = Vector.Number([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
      mat = Matrix3D(v)
      col = Vector3D(3, 4, 5, 6)
      check = ((3, 4, 5, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
               (3, 4, 5, 6, 3, 4, 5, 6, 0, 0, 0, 0, 0, 0, 0, 0),
               (3, 4, 5, 6, 3, 4, 5, 6, 3, 4, 5, 6, 0, 0, 0, 0),
               (3, 4, 5, 6, 3, 4, 5, 6, 3, 4, 5, 6, 3, 4, 5, 6))
      for i in range(4):
         mat.copyColumnFrom(i, col)
         self.assertMatrix3D(mat, check[i])

      self.assertRaises(ArgumentError, mat.copyColumnFrom, 4, col)

   def test_compose(self):
      raise TestNotImplemented

   def assertInvertedMat3D(self, mat, determinant, check):
      self.assertEqual(mat.determinant, determinant)

      invmat = mat.clone()
      invmat.invert()
      self.assertMatrix3D(invmat, check)

   def test_invert(self):
      # Identity
      check = (1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)
      self.assertInvertedMat3D(Matrix3D(), 1, check)

      # Translation
      matrix = Matrix3D()
      matrix.appendTranslation(10, 20, 30)
      check = (1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, -10, -20, -30, 1)
      self.assertInvertedMat3D(matrix, 1, check)

      # Scale
      matrix = Matrix3D()
      matrix.appendScale(2, 2, 2)
      check = (0.5, 0, 0, 0, 0, 0.5, 0, 0, 0, 0, 0.5, 0, 0, 0, 0, 1)
      self.assertInvertedMat3D(matrix, 8, check)

      # Rotation
      matrix = Matrix3D()
      matrix.appendRotation(0.3, Vector3D.X_AXIS)
      matrix.appendRotation(0.5, Vector3D.Y_AXIS)
      matrix.appendRotation(0.7, Vector3D.Z_AXIS)
      check = (0.9998872955663178, -0.012171144953375805,
               0.008789732396306326, 0, 0.012216535649290344,
               0.999912221147948, -0.005128962439600703, 0,
               -0.008726535498373933, 0.005235764461960769,
               0.9999482158335472, 0, 0, 0, 0, 0.9999999999999999)
      self.assertInvertedMat3D(matrix, 1, check)

      # Rotation and scaling
      matrix = Matrix3D()
      matrix.appendRotation(0.3, Vector3D.X_AXIS)
      matrix.appendRotation(0.5, Vector3D.Y_AXIS)
      matrix.appendRotation(0.7, Vector3D.Z_AXIS)
      matrix.appendScale(2, 2, 2)
      check = (0.4999436477831589, -0.006085572476687903,
               0.004394866198153163, 0, 0.006108267824645172,
               0.499956110573974, -0.0025644812198003515, 0,
               -0.0043632677491869665, 0.0026178822309803843,
               0.4999741079167736, 0, 0, 0, 0, 0.9999999999999999)
      self.assertInvertedMat3D(matrix, 8, check)

      # Non-uniform scaling
      matrix = Matrix3D()
      matrix.appendScale(2, 3, 4)
      check = (0.5, 0, 0, 0, 0, 0.3333333333333333, 0, 0, 0, 0, 0.25, 0, 0, 0,
               0, 1)
      self.assertInvertedMat3D(matrix, 24, check)


class PerspectiveProjectionTests(as3libTestCase):
   ...


class PointTests(as3libTestCase):
   def test_constructor(self):
      p = Point()
      self.assertPoint(p, 0, 0)

      p = Point(1)
      self.assertPoint(p, 1, 0)

      p = Point(1, 2)
      self.assertPoint(p, 1, 2)

      # TODO: Find a way to handle this
      p = Point(Object(), 2)
      self.assertNaN(p.x)
      self.assertEqual(p.y, 2)

   def test_add(self):
      p = Point()
      self.assertPoint(p.add(Point(1, 2)), 1, 2)
      self.assertPoint(p, 0, 0)

   def test_subtract(self):
      p = Point()
      self.assertPoint(p.subtract(Point(1, 2)), -1, -2)
      self.assertPoint(p, 0, 0)

   def test_distance(self):
      d = Point.distance(Point(), Point())
      self.assertEqual(d, 0)

      d = Point.distance(Point(-100, 200), Point(100, 200))
      self.assertEqual(d, 200)

   def test_equals(self):
      p = Point()
      self.assertFalse(p.equals(Point(1, 2)))
      self.assertTrue(p.equals(p))
      self.assertPoint(p, 0, 0)

   def test_clone(self):
      p = Point(1, 2)
      clone = p.clone()
      self.assertPoint(p, 1, 2)
      self.assertPoint(clone, 1, 2)

      self.assertIsNot(p, clone)
      self.assertTrue(p.equals(clone))

   def test_interpolate(self):
      p1 = Point(-100, -200)
      p2 = Point(100, 200)

      self.assertPoint(Point.interpolate(p1, p2, -1), 300, 600)
      self.assertPoint(Point.interpolate(p1, p2, 0), 100, 200)
      self.assertPoint(Point.interpolate(p1, p2, 0.5), 0, 0)
      self.assertPoint(Point.interpolate(p1, p2, 1), -100, -200)
      self.assertPoint(Point.interpolate(p1, p2, 2), -300, -600)

   def test_length(self):
      self.assertEqual(Point().length, 0)
      self.assertEqual(Point(100, 0).length, 100)
      self.assertEqual(Point(0, -200).length, 200)

   def test_normalize(self):
      p = Point()
      p.normalize(10)
      self.assertPoint(p, 0, 0)

      p = Point()
      p.normalize(-5)
      self.assertPoint(p, 0, 0)

      p = Point(100, 200)
      p.normalize(10)
      self.assertPoint(p, 4.47213595499958, 8.94427190999916)

      p = Point(100, 200)
      p.normalize(-5)
      self.assertPoint(p, -2.23606797749979, -4.47213595499958)

      p = Point(-200, 100)
      p.normalize(10)
      self.assertPoint(p, -8.94427190999916, 4.47213595499958)

      p = Point(-200, 100)
      p.normalize(-5)
      self.assertPoint(p, 4.47213595499958, -2.23606797749979)

      p = Point(undefined, 100)
      p.normalize(1)
      self.assertNaN(p.x)
      self.assertEqual(p.y, 100)

      p = Point(100, null)
      p.normalize(1)
      self.assertPoint(p, 1, 0)

   def test_offset(self):
      p = Point()
      self.assertPoint(p, 0, 0)

      p.offset(100, 200)
      self.assertPoint(p, 100, 200)

      p.offset(-1000, -2000)
      self.assertPoint(p, -900, -1800)

   def test_polar(self):
      self.assertPoint(Point.polar(5, Math.atan(3/4)), 4, 3)
      self.assertPoint(Point.polar(0, Math.atan(3/4)), 0, 0)

   def test_toString(self):
      p = Point()
      self.assertEqual(p.toString(), '(x=0, y=0)')


class RectangleTests(as3libTestCase):
   def assertRectangle(self, rect, top, right, bottom, left, topLeft,
                       bottomRight, width, height, size, x, y):
      # Previously called "dump"
      self.assertEqual(rect.top, top)
      self.assertEqual(rect.right, right)
      self.assertEqual(rect.bottom, bottom)
      self.assertEqual(rect.left, left)
      self.assertPoint(rect.topLeft, topLeft.x, topLeft.y)
      self.assertPoint(rect.bottomRight, bottomRight.x, bottomRight.y)
      self.assertEqual(rect.width, width)
      self.assertEqual(rect.height, height)
      self.assertPoint(rect.size, size.x, size.y)
      self.assertEqual(rect.x, x)
      self.assertEqual(rect.y, y)
      #trace(" // " + desc)
      #trace(extended)
      #trace("")

   def test_constructor(self):
      check = (0, 0, 0, 0, Point(0, 0), Point(0, 0), 0, 0, Point(0, 0), 0, 0)
      self.assertRectangle(Rectangle(), *check)
      check = (0, 1, 0, 1, Point(1, 0), Point(1, 0), 0, 0, Point(0, 0), 1, 0)
      self.assertRectangle(Rectangle(1), *check)
      check = (2, 1, 2, 1, Point(1, 2), Point(1, 2), 0, 0, Point(0, 0), 1, 2)
      self.assertRectangle(Rectangle(1, 2), *check)
      check = (2, 4, 2, 1, Point(1, 2), Point(4, 2), 3, 0, Point(3, 0), 1, 2)
      self.assertRectangle(Rectangle(1, 2, 3), *check)
      check = (2, 4, 6, 1, Point(1, 2), Point(4, 6), 3, 4, Point(3, 4), 1, 2)
      self.assertRectangle(Rectangle(1, 2, 3, 4), *check)

   def tryValues(self, key, values, check):
      rect = Rectangle(1, 3, 5, 7)
      self.assertRectangle(rect, 3, 6, 10, 1, Point(1, 3), Point(6, 10), 5, 7, Point(5, 7), 1, 3)

      for i in range(len(values)):
         # Reset, just to make sure we aren't leaking state
         rect = Rectangle(1, 3, 5, 7)

         # originally "rect[key] = value"
         setattr(rect, key, values[i])

         self.assertRectangle(rect, *(check[i]))

   def test_constructorSpecial(self):
      numberValues = (0, 100, -200, NaN, Infinity)
      check = ((0, 6, 10, 1, Point(1, 0), Point(6, 10), 5, 10, Point(5, 10), 1, 0),
               (100, 6, 10, 1, Point(1, 100), Point(6, 10), 5, -90, Point(5, -90), 1, 100),
               (-200, 6, 10, 1, Point(1, -200), Point(6, 10), 5, 210, Point(5, 210), 1, -200),
               (NaN, 6, NaN, 1, Point(1, NaN), Point(6, NaN), 5, NaN, Point(5, NaN), 1, NaN),
               (Infinity, 6, NaN, 1, Point(1, Infinity), Point(6, NaN), 5, -Infinity, Point(5, -Infinity), 1, Infinity))
      self.tryValues("top", numberValues, check)

      check = ((3, 0, 10, 1, Point(1, 3), Point(0, 10), -1, 7, Point(-1, 7), 1, 3),
               (3, 100, 10, 1, Point(1, 3), Point(100, 10), 99, 7, Point(99, 7), 1, 3),
               (3, -200, 10, 1, Point(1, 3), Point(-200, 10), -201, 7, Point(-201, 7), 1, 3),
               (3, NaN, 10, 1, Point(1, 3), Point(NaN, 10), NaN, 7, Point(NaN, 7), 1, 3),
               (3, Infinity, 10, 1, Point(1, 3), Point(Infinity, 10), Infinity, 7, Point(Infinity, 7), 1, 3))
      self.tryValues("right", numberValues, check)

      check = ((3, 6, 10, 0, Point(0, 3), Point(6, 10), 6, 7, Point(6, 7), 0, 3),
               (3, 6, 10, 100, Point(100, 3), Point(6, 10), -94, 7, Point(-94, 7), 100, 3),
               (3, 6, 10, -200, Point(-200, 3), Point(6, 10), 206, 7, Point(206, 7), -200, 3),
               (3, NaN, 10, NaN, Point(NaN, 3), Point(NaN, 10), NaN, 7, Point(NaN, 7), NaN, 3),
               (3, NaN, 10, Infinity, Point(Infinity, 3), Point(NaN, 10), -Infinity, 7, Point(-Infinity, 7), Infinity, 3))
      self.tryValues("left", numberValues, check)

      check = ((3, 6, 0, 1, Point(1, 3), Point(6, 0), 5, -3, Point(5, -3), 1, 3),
               (3, 6, 100, 1, Point(1, 3), Point(6, 100), 5, 97, Point(5, 97), 1, 3),
               (3, 6, -200, 1, Point(1, 3), Point(6, -200), 5, -203, Point(5, -203), 1, 3),
               (3, 6, NaN, 1, Point(1, 3), Point(6, NaN), 5, NaN, Point(5, NaN), 1, 3),
               (3, 6, Infinity, 1, Point(1, 3), Point(6, Infinity), 5, Infinity, Point(5, Infinity), 1, 3))
      self.tryValues("bottom", numberValues, check)

      check = ((3, 1, 10, 1, Point(1, 3), Point(1, 10), 0, 7, Point(0, 7), 1, 3),
               (3, 101, 10, 1, Point(1, 3), Point(101, 10), 100, 7, Point(100, 7), 1, 3),
               (3, -199, 10, 1, Point(1, 3), Point(-199, 10), -200, 7, Point(-200, 7), 1, 3),
               (3, NaN, 10, 1, Point(1, 3), Point(NaN, 10), NaN, 7, Point(NaN, 7), 1, 3),
               (3, Infinity, 10, 1, Point(1, 3), Point(Infinity, 10), Infinity, 7, Point(Infinity, 7), 1, 3))
      self.tryValues("width", numberValues, check)

      check = ((3, 6, 3, 1, Point(1, 3), Point(6, 3), 5, 0, Point(5, 0), 1, 3),
               (3, 6, 103, 1, Point(1, 3), Point(6, 103), 5, 100, Point(5, 100), 1, 3),
               (3, 6, -197, 1, Point(1, 3), Point(6, -197), 5, -200, Point(5, -200), 1, 3),
               (3, 6, NaN, 1, Point(1, 3), Point(6, NaN), 5, NaN, (5, NaN), 1, 3),
               (3, 6, Infinity, 1, Point(1, 3), Point(6, Infinity), 5, Infinity, Point(5, Infinity), 1, 3))
      self.tryValues("height", numberValues, check)

      check = ((3, 5, 10, 0, Point(0, 3), Point(5, 10), 5, 7, Point(5, 7), 0, 3),
               (3, 105, 10, 100, Point(100, 3), Point(105, 10), 5, 7, Point(5, 7), 100, 3),
               (3, -195, 10, -200, Point(-200, 3), Point(-195, 10), 5, 7, Point(5, 7), -200, 3),
               (3, NaN, 10, NaN, Point(NaN, 3), Point(NaN, 10), 5, 7, Point(5, 7), NaN, 3),
               (3, Infinity, 10, Infinity, Point(Infinity, 3), Point(Infinity, 10), 5, 7, Point(5, 7), Infinity, 3))
      self.tryValues("x", numberValues, check)

      check = ((0, 6, 7, 1, Point(1, 0), Point(6, 7), 5, 7, Point(5, 7), 1, 0),
               (100, 6, 107, 1, Point(1, 100), Point(6, 107), 5, 7, Point(5, 7), 1, 100),
               (-200, 6, -193, 1, Point(1, -200), Point(6, -193), 5, 7, Point(5, 7), 1, -200),
               (NaN, 6, NaN, 1, Point(1, NaN), Point(6, NaN), 5, 7, Point(5, 7), 1, NaN),
               (Infinity, 6, Infinity, 1, Point(1, Infinity), Point(6, Infinity), 5, 7, Point(5, 7), 1, Infinity))
      self.tryValues("y", numberValues, check)

      pointValues = (Point(0,0), Point(-100,-200), Point(100,200),
                     Point(Infinity,Infinity), Point(NaN,NaN))
      check = ((0, 6, 10, 0, Point(0, 0), Point(6, 10), 6, 10, Point(6, 10), 0, 0),
               (-200, 6, 10, -100, Point(-100, -200), Point(6, 10), 106, 210, Point(106, 210), -100, -200),
               (200, 6, 10, 100, Point(100, 200), Point(6, 10), -94, -190, Point(-94, -190), 100, 200),
               (Infinity, NaN, NaN, Infinity, Point(Infinity, Infinity), Point(NaN, NaN), -Infinity, -Infinity, Point(-Infinity, -Infinity), Infinity, Infinity),
               (NaN, NaN, NaN, NaN, Point(NaN, NaN), Point(NaN, NaN), NaN, NaN, Point(NaN, NaN), NaN, NaN))
      self.tryValues("topLeft", pointValues, check)

      check = ((3, 0, 0, 1, Point(1, 3), Point(0, 0), -1, -3, Point(-1, -3), 1, 3),
               (3, -100, -200, 1, Point(1, 3), Point(-100, -200), -101, -203, Point(-101, -203), 1, 3),
               (3, 100, 200, 1, Point(1, 3), Point(100, 200), 99, 197, Point(99, 197), 1, 3),
               (3, Infinity, Infinity, 1, Point(1, 3), Point(Infinity, Infinity), Infinity, Infinity, Point(Infinity, Infinity), 1, 3),
               (3, NaN, NaN, 1, Point(1, 3), Point(NaN, NaN), NaN, NaN, Point(NaN, NaN), 1, 3))
      self.tryValues("bottomRight", pointValues, check)

      check = ((3, 1, 3, 1, Point(1, 3), Point(1, 3), 0, 0, Point(0, 0), 1, 3),
               (3, -99, -197, 1, Point(1, 3), Point(-99, -197), -100, -200, Point(-100, -200), 1, 3),
               (3, 101, 203, 1, Point(1, 3), Point(101, 203), 100, 200, Point(100, 200), 1, 3),
               (3, Infinity, Infinity, 1, Point(1, 3), Point(Infinity, Infinity), Infinity, Infinity, Point(Infinity, Infinity), 1, 3),
               (3, NaN, NaN, 1, Point(1, 3), Point(NaN, NaN), NaN, NaN, Point(NaN, NaN), 1, 3))
      self.tryValues("size", pointValues, check)

   def test_clone(self):
      orig = Rectangle(1, 3, 5, 7)
      cloned = orig.clone()

      check = (3, 6, 10, 1, Point(1, 3), Point(6, 10), 5, 7, Point(5, 7), 1, 3)
      self.assertRectangle(orig, *check)
      self.assertRectangle(cloned, *check)

      self.assertNotEqual(orig, cloned)
      self.assertTrue(orig.equals(cloned))

   def test_copyFrom(self):
      orig = Rectangle(1, 3, 5, 7)
      other = Rectangle(2, 1, 3, 7)

      check_orig = (3, 6, 10, 1, Point(1, 3), Point(6, 10), 5, 7, Point(5, 7), 1, 3)
      check_other = (1, 5, 8, 2, Point(2, 1), Point(5, 8), 3, 7, Point(3, 7), 2, 1)
      self.assertRectangle(orig, *check_orig)
      self.assertRectangle(other, *check_other)

      other.copyFrom(orig)
      self.assertRectangle(other, *check_orig)

      self.assertNotEqual(orig, other)

   def test_equals(self):
      orig = Rectangle(1, 3, 5, 7)

      check = (3, 6, 10, 1, Point(1, 3), Point(6, 10), 5, 7, Point(5, 7), 1, 3)
      self.assertRectangle(orig, *check)

      self.assertTrue(orig.equals(Rectangle(1, 3, 5, 7)))

   def test_isEmpty(self):
      # TODO: Number needs to support <=
      self.assertTrue(Rectangle().isEmpty())
      self.assertTrue(Rectangle(0, 0, 0, 0).isEmpty())
      self.assertTrue(Rectangle(1, 2, 3, 0).isEmpty())
      self.assertTrue(Rectangle(1, 2, 0, 4).isEmpty())
      self.assertFalse(Rectangle(1, 2, 3, 4).isEmpty())
      self.assertFalse(Rectangle(1, 2, Infinity, Infinity).isEmpty())
      self.assertFalse(Rectangle(1, 2, NaN, NaN).isEmpty())
      self.assertFalse(Rectangle(1, 2, undefined, undefined).isEmpty())
      self.assertTrue(Rectangle(1, 2, -1, -2).isEmpty())

   def test_setEmpty(self):
      orig = Rectangle(1, 3, 5, 7)

      check = (3, 6, 10, 1, Point(1, 3), Point(6, 10), 5, 7, Point(5, 7), 1, 3)
      self.assertRectangle(orig, *check)

      ret = orig.setEmpty()
      self.assertIs(ret, undefined)

      check = (0, 0, 0, 0, Point(0, 0), Point(0, 0), 0, 0, Point(0, 0), 0, 0)
      self.assertRectangle(orig, *check)

   def tryMethod(name, argsList, isRect, dumpOrig):
      #trace("");
      #trace("/// " + name);
      #trace("");

      rectList = (Rectangle(), Rectangle(1, 3, 5, 7), Rectangle(-1, -3, 5, 7), Rectangle(1, 3, -5, 7))
      for h in range(len(rectList)):
         #dump(rectList[h], "rect")
         for i in range(len(argsList)):
               #Reset, just to make sure we aren't leaking state
               rect = rectList[h].clone()

               args = argsList[i]
               argsText = ""
               for j in range(len(args)):
                  if (argsText.length > 0):
                     argsText += ", "
                  argsText += args[j]

               result = rect[name].apply(rect, args)
               if (isRect):
                  dump(result, "rect." + name + "(" + argsText + ")")
               else:
                  trace("// rect." + name + "(" + argsText + ")")
                  trace(result)
                  trace("")

               if (dumpOrig):
                  dump(rect, "rect")

   def test_contains(self):
      """
      tryMethod("contains", [
      //    [],
      //    [1],
         [1, 2],
         [1, 3],
         [1.1, 3.1],
         [6, 10],
         [5.9, 9.9],
         [4, NaN],
      //    [undefined, 5],
         [5, "5"],
         [5, Infinity],
      //    [true],
      //    [false],
      //    [true, true],
      //    [false, false],
      //    [true, false],
      //    [false, true],
      //    [0, 0],
      //    [1, 1],
      //    [0],
      //    [1],
      //    [{}],
      //    [{}, {}],
      //    [Infinity],
      //    [NaN],
      //    [new Point(1, 3)],
      //    []
      ], false, false);
      """
      """
      /// contains
      // rect
      (top=0, right=0, bottom=0, left=0, topLeft=(x=0, y=0), bottomRight=(x=0, y=0), width=0, height=0, size=(x=0, y=0), x=0, y=0)
      // rect.contains(1, 2)
      false
      // rect.contains(1, 3)
      false
      // rect.contains(1.1, 3.1)
      false
      // rect.contains(6, 10)
      false
      // rect.contains(5.9, 9.9)
      false
      // rect.contains(4, NaN)
      false
      // rect.contains(5, 5)
      false
      // rect.contains(5, Infinity)
      false
      // rect
      (top=3, right=6, bottom=10, left=1, topLeft=(x=1, y=3), bottomRight=(x=6, y=10), width=5, height=7, size=(x=5, y=7), x=1, y=3)
      // rect.contains(1, 2)
      false
      // rect.contains(1, 3)
      true
      // rect.contains(1.1, 3.1)
      true
      // rect.contains(6, 10)
      false
      // rect.contains(5.9, 9.9)
      true
      // rect.contains(4, NaN)
      false
      // rect.contains(5, 5)
      true
      // rect.contains(5, Infinity)
      false
      // rect
      (top=-3, right=4, bottom=4, left=-1, topLeft=(x=-1, y=-3), bottomRight=(x=4, y=4), width=5, height=7, size=(x=5, y=7), x=-1, y=-3)
      // rect.contains(1, 2)
      true
      // rect.contains(1, 3)
      true
      // rect.contains(1.1, 3.1)
      true
      // rect.contains(6, 10)
      false
      // rect.contains(5.9, 9.9)
      false
      // rect.contains(4, NaN)
      false
      // rect.contains(5, 5)
      false
      // rect.contains(5, Infinity)
      false
      // rect
      (top=3, right=-4, bottom=10, left=1, topLeft=(x=1, y=3), bottomRight=(x=-4, y=10), width=-5, height=7, size=(x=-5, y=7), x=1, y=3)
      // rect.contains(1, 2)
      false
      // rect.contains(1, 3)
      false
      // rect.contains(1.1, 3.1)
      false
      // rect.contains(6, 10)
      false
      // rect.contains(5.9, 9.9)
      false
      // rect.contains(4, NaN)
      false
      // rect.contains(5, 5)
      false
      // rect.contains(5, Infinity)
      false
      """
      raise TestNotImplemented

   def test_containsPoint(self):
      """
      tryMethod("containsPoint", [
         [new Point()],
         [new Point(1)],
         [new Point(1, 2)],
         [new Point(1, 3)],
         [new Point(1.1, 3.1)],
         [new Point(6, 10)],
         [new Point(5.9, 9.9)],
      //    [new Point(undefined, 5)],
      //    [{x: 5, y: Infinity}],
      //    [{x: 5, y: 5}]
      ], false, false);
      """
      raise TestNotImplemented

   def test_containsRect(self):
      """
      tryMethod("containsRect", [
         [new Rectangle(0.9, 2.9, 5, 7)],
         [new Rectangle(1, 3, 5.1, 7.1)],
         [new Rectangle(5, 5, NaN, 1)]
      ], false, false);
      """
      raise TestNotImplemented

   def test_inflate(self):
      """
      tryMethod("inflate", [
      //    [],
      //    [1],
         [1, 2],
         [-3, -4],
         [Infinity, 5],
         [5, NaN],
      //    [3, {}]
      ], false, true);
      """
      raise TestNotImplemented

   def test_inflateRect(self):
      """
      tryMethod("inflatePoint", [
      //    [],
      //    [new Point()],
         [new Point(1, 2)],
      //    [{x: 3, y: 4}],
      //    [{x: 5}]
      ], false, true);
      """
      raise TestNotImplemented

   def test_intersection(self):
      """
      tryMethod("intersection", [
      //    [],
      //    [new Rectangle(1, 3, 5, 7)],
         [new Rectangle(3, 5, 7, 9)],
         [new Rectangle(-1, -3, 5, 7)],
         [new Rectangle(30, 50, 1, 1)],
      //    [{x: 3, y: 5, width: 7, height: 1}],
      //    [{x: 3, y: 5, width: 2}]
      ], true, false);
      """
      raise TestNotImplemented

   def test_intersects(self):
      """
      tryMethod("intersects", [
      //    [],
      //    [new Rectangle(1, 3, 5, 7)],
         [new Rectangle(3, 5, 7, 9)],
         [new Rectangle(-1, -3, 5, 7)],
      //    [{x: 3, y: 5, width: 7, height: 1}],
      //    [{x: 3, y: 5, width: 2}]
      ], false, false);
      """
      raise TestNotImplemented

   def test_offset(self):
      """
      tryMethod("offset", [
      //    [],
      //    [1],
         [1, 2],
         [-3, -4],
         [Infinity, 5],
         [NaN, 6],
      //    [5, NaN],
      //    [3, {}]
      ], false, true);
      """
      raise TestNotImplemented

   def test_offsetPoint(self):
      """
      tryMethod("offsetPoint", [
      //    [],
      //    [new Point()],
         [new Point(1, 2)],
      //    [{x: 3, y: 4}],
      //    [{x: 5}]
      ], false, true);
      """
      raise TestNotImplemented

   def test_union(self):
      """
      tryMethod("union", [
      //    [],
      //    [new Rectangle(1, 3, 5, 7)],
         [new Rectangle(3, 5, 7, 9)],
         [new Rectangle(3, 5, 7, 9)],
         [new Rectangle(-1, -3, NaN, 7)],
      //    [{x: 3, y: 5, width: 7, height: 1}],
      //    [{x: 3, y: 5, width: 2}]
      ], true, false);
      """
      raise TestNotImplemented

   def test_setTo(self):
      """
      tryMethod("setTo", [
         [3,5,7,9],
         [-1,-3,5,7]
      ], false, true);
      """
      raise TestNotImplemented

   def test_toString(self):
      raise TestNotImplemented


class TransformTests(as3libTestCase):
   class TestClass(MovieClip):
      def __init__(self, cls):
         self.c = cls
         self.testEQ()
         self.test2D()
         self.test3D()
         self.testCopy2D()
         self.testCopy3D()
         # self.testImageComparison()

      def testEQ(self):
         # These tests originally used ===
         # TODO: Test these on flash player
         s = Sprite()
         t = s.transform

         t.matrix = Matrix()
         self.c.assertIsNot(t.matrix, t.matrix)

         t.matrix3D = Matrix3D()
         self.c.assertIs(t.matrix3D, t.matrix3D)

         t.perspectiveProjection = PerspectiveProjection()
         self.c.assertIsNot(t.perspectiveProjection, t.perspectiveProjection)

         t.colorTransform = ColorTransform()
         self.c.assertIsNot(t.colorTransform, t.colorTransform)

      def test2D(self):
         sprite2D = Sprite()

         # sprite2D: new Sprite has null matrix3D and valid matrix
         self.c.assertMatrix(sprite2D.transform.matrix, 1, 0, 0, 1, 0, 0)
         self.c.assertEqual(sprite2D.transform.matrix3D, null)

         # sprite2D: set identity matrix
         mat2D = Matrix()
         mat2D.identity()
         sprite2D.transform.matrix = mat2D
         self.c.assertMatrix(sprite2D.transform.matrix, 1, 0, 0, 1, 0, 0)
         self.c.assertEqual(sprite2D.transform.matrix3D, null)
         self.c.assertMatrix(mat2D, 1, 0, 0, 1, 0, 0)

         #  sprite2D: update mat2D"
         mat2D.setTo(2, 3, 4, 5, 6, 7)
         self.c.assertMatrix(sprite2D.transform.matrix, 1, 0, 0, 1, 0, 0)
         self.c.assertEqual(sprite2D.transform.matrix3D, null)
         self.c.assertMatrix(mat2D, 2, 3, 4, 5, 6, 7)

         # sprite2D: .matrix = mat2D
         sprite2D.transform.matrix = mat2D
         self.c.assertMatrix(sprite2D.transform.matrix, 2, 3, 4, 5, 6, 7)
         self.c.assertEqual(sprite2D.transform.matrix3D, null)
         self.c.assertMatrix(mat2D, 2, 3, 4, 5, 6, 7)

         # sprite2D: .matrix = null
         sprite2D.transform.matrix = null
         self.c.assertEqual(sprite2D.transform.matrix, null)
         asrt = (2, 3, 0, 0, 4, 5, 0, 0, 0, 0, 1, 0, 6, 7, 0, 1)
         self.c.assertMatrix3D(sprite2D.transform.matrix3D, asrt)
         self.c.assertMatrix(mat2D, 2, 3, 4, 5, 6, 7)

         # sprite2D: .matrix3D = null
         sprite2D.transform.matrix3D = null
         self.c.assertMatrix(sprite2D.transform.matrix, 1, 0, 0, 1, 0, 0)
         self.c.assertEqual(sprite2D.transform.matrix3D, null)
         self.c.assertMatrix(mat2D, 2, 3, 4, 5, 6, 7)

         # sprite2D: set x = 30, y = 50
         sprite2D.x = 30
         sprite2D.y = 50
         self.c.assertMatrix(sprite2D.transform.matrix, 1, 0, 0, 1, 30, 50)
         self.c.assertEqual(sprite2D.transform.matrix3D, null)
         self.c.assertMatrix(mat2D, 2, 3, 4, 5, 6, 7)

      def test3D(self):
         sprite3D = Sprite()

         # sprite3D: set identity matrix3D
         mat3D = Matrix3D()
         mat3D.identity()
         sprite3D.transform.matrix3D = mat3D
         self.c.assertEqual(sprite2D.transform.matrix, null)
         asrt = (1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)
         self.c.assertMatrix3D(sprite2D.transform.matrix3D, asrt)
         self.c.assertMatrix3D(mat3D, asrt)

         # sprite3D: update mat3D
         # RUFFLE: FIXME: values shouldn't be zero (0) for test coverage. Unsupported now.
         v = Vector.Number([2, 3, 0, 0, 4, 5, 0, 0, 0, 0, 1, 0, 6, 7, 0, 1])
         mat3D.copyFrom(Matrix3D(v))
         self.c.assertEqual(sprite2D.transform.matrix, null)
         # RUFFLE: FIXME: mat3D update should be applied to transform.matrix3D immediately
         # trace("sprite3D.transform.matrix3D.rawData", sprite3D.transform.matrix3D.rawData);
         asrt = (2, 3, 0, 0, 4, 5, 0, 0, 0, 0, 1, 0, 6, 7, 0, 1)
         self.c.assertMatrix3D(mat3D, asrt)

         # sprite3D: .matrix3D = mat3D
         sprite3D.transform.matrix3D = mat3D
         self.c.assertEqual(sprite2D.transform.matrix, null)
         self.c.assertMatrix3D(sprite2D.transform.matrix3D, asrt)
         self.c.assertMatrix3D(mat3D, asrt)

         # sprite3D: .matrix = null
         self.c.assertEqual(sprite2D.transform.matrix, null)
         self.c.assertMatrix3D(sprite2D.transform.matrix3D, asrt)
         self.c.assertMatrix3D(mat3D, asrt)

         # sprite3D: set x = 30, y = 50
         sprite3D.x = 30
         sprite3D.y = 50
         self.c.assertEqual(sprite2D.transform.matrix, null)
         asrt = (2, 3, 0, 0, 4, 5, 0, 0, 0, 0, 1, 0, 30, 50, 0, 1)
         self.c.assertMatrix3D(sprite2D.transform.matrix3D, asrt)
         # RUFFLE: FIXME: mat3D.rawData should be updated by sprite3D x/y update.
         # trace("mat3D.rawData", mat3D.rawData);

         # sprite3D: .matrix3D = null
         sprite3D.transform.matrix3D = null
         self.c.assertMatrix(sprite2D.transform.matrix, 1, 0, 0, 1, 0, 0)
         self.c.assertEqual(sprite2D.transform.matrix3D, null)
         # RUFFLE: FIXME: mat3D.rawData should be updated by sprite3D x/y update.
         # trace("mat3D.rawData", mat3D.rawData)

      def testCopy2D(self):
         sprite1 = Sprite()
         sprite2 = Sprite()

         mat2D = Matrix(1, 2, 3, 4, 5, 6)
         sprite1.transform.matrix = mat2D
         sprite2.transform = sprite1.transform
         self.c.assertMatrix(sprite1.transform.matrix, 1, 2, 3, 4, 5, 6)
         self.c.assertEqual(sprite1.transform.matrix3D, null)
         self.c.assertMatrix(sprite2.transform.matrix, 1, 2, 3, 4, 5, 6)
         self.c.assertEqual(sprite2.transform.matrix3D, null)

      def testCopy3D(self):
         sprite1 = Sprite()
         sprite2 = Sprite()

         mat3D = Matrix3D()
         mat3D.appendRotation(1, Vector3D.Z_AXIS)
         # RUFFLE: FIXME: zScale shouldn't be one (1) for test coverage. Unsupported now.
         mat3D.appendScale(2, 3, 1)
         # RUFFLE: FIXME: z shouldn't be zero (0) for test coverage. Unsupported now.
         mat3D.appendTranslation(5, 6, 0)
         sprite1.transform.matrix3D = mat3D
         sprite2.transform = sprite1.transform

         asrt = (1.9996954202651978, 0.05235721915960312, 0, 0,
                 -0.03490481153130531, 2.9995431900024414, 0, 0, 0, 0, 1, 0,
                 5, 6, 0, 1)

         self.c.assertEqual(sprite1.transform.matrix, null)
         self.c.assertMatrix3D(sprite1.transform.matrix3D, asrt)
         self.c.assertEqual(sprite2.transform.matrix, null)
         self.c.assertMatrix3D(sprite2.transform.matrix3D, asrt)

      '''
      def testImageComparison(self):
         m = Matrix3D()

         # id
         s1 = Sprite()
         s1.x = 10
         s1.y = 10
         bd1 = BitmapData(50, 50, false, 0xFF0000)
         b1 = Bitmap(bd1)
         m.identity()
         b1.transform.matrix3D = m.clone()
         s1.addChild(b1)
         self.addChild(s1)  # This comes from DisplayObjectContainer

         # scale
         s2 = Sprite()
         s2.x = 160
         s2.y = 10
         bd2 = BitmapData(50, 50, false, 0x00FF00)
         b2 = Bitmap(bd2)
         m.identity()
         m.appendScale(1.5, 3, 1)
         b2.transform.matrix3D = m.clone()
         s2.addChild(b2)
         self.addChild(s2)

         # rotation
         s3 = Sprite()
         s3.x = 310
         s3.y = 10
         bd3 = BitmapData(50, 50, false, 0x00FFFF)
         b3 = Bitmap(bd3)
         m.identity()
         m.appendRotation(30, Vector3D.Z_AXIS)
         b3.transform.matrix3D = m.clone()
         s3.addChild(b3)
         self.addChild(s3)

         # translation
         s4 = Sprite()
         s4.x = 10
         s4.y = 160
         bd4 = BitmapData(50, 50, false, 0x0000FF)
         b4 = Bitmap(bd4)
         m.identity()
         m.appendTranslation(50, 50, 0)
         b4.transform.matrix3D = m.clone()
         s4.addChild(b4)
         self.addChild(s4)

         # scale + rotation + translation
         s5 = Sprite()
         s5.x = 160
         s5.y = 160
         bd5 = BitmapData(50, 50, false, 0xFF00FF)
         b5 = Bitmap(bd5)
         m.identity()
         m.appendScale(2, 3, 1)
         m.appendRotation(30, Vector3D.Z_AXIS)
         m.appendTranslation(50, 50, 0)
         b5.transform.matrix3D = m.clone()
         s5.addChild(b5)
         self.addChild(s5)
      '''

   def test_1(self):
      TransformTests.TestClass(self)


class Utils3DTests(as3libTestCase):
   def test_1(self):
      vec = Vector3D(1.0, 2.0, 3.0, 4.0)
      mat = Matrix3D(Vector.Number([
         100, 200, 300, 400,
         500, 600, 700, 800,
         900, 1000, 1100, 1200,
         1300, 1400, 1500, 1600
      ]))

      projected = Utils3D.projectVector(mat, vec)
      self.assertVector3D(projected, 0.7083333333333334, 0.8055555555555556,
                          0.9027777777777778, 7200)

      verts = Vector.Number([100, 200, 300, 400, 500, 600])
      projectedVerts = Vector.Number([])
      uvts = Vector.Number([])

      # Bad project
      Utils3D.projectVectors(mat, verts, projectedVerts, uvts)

      asrt = (0.6789529914529915, 0.7859686609686609, 0.6486423220973783,
              0.7657615480649188)
      self.assertArray(projectedVerts, asrt, 4)
      asrt = (0, 0, 0.0000017806267806267806, 0, 0, 7.802746566791511e-7)
      self.assertArray(uvts, asrt, 6)

      # Good project
      # Deliberately missing a final z coord
      uvts = uvts = Vector.Number([1000, 2000, 3000, 4000, 5000, 6000, 5, 6])

      Utils3D.projectVectors(mat, verts, projectedVerts, uvts)
      asrt = (0.6789529914529915, 0.7859686609686609, 0.6486423220973783,
              0.7657615480649188)
      self.assertArray(projectedVerts, asrt, 4)
      asrt = (1000, 2000, 0.0000017806267806267806, 4000, 5000,
              7.802746566791511e-7, 5, 6)
      self.assertArray(uvts, asrt, 8)


class Vector3DTests(as3libTestCase):
   def roundNumber(self, x):  # Originally called r
      return Math.round(x * 1000000000000) / 1000000000000

   def roundVector(self, v):  # Originally called rv
      return Vector3D(self.roundNumber(v.x), self.roundNumber(v.y),
                      self.roundNumber(v.z), self.roundNumber(v.w))

   def test_constructor(self):
      v = Vector3D()
      self.assertVector3D(v, 0, 0, 0, 0)

      v = Vector3D(1)
      self.assertVector3D(v, 1, 0, 0, 0)

      v = Vector3D(1, 2)
      self.assertVector3D(v, 1, 2, 0, 0)

      v = Vector3D(1, 2, 3)
      self.assertVector3D(v, 1, 2, 3, 0)

      v = Vector3D(1, 2, 3, 4)
      self.assertVector3D(v, 1, 2, 3, 4)

      v = Vector3D(Object(), 2)
      self.assertNaN(v.x)
      self.assertEqual(v.y, 2)
      self.assertEqual(v.z, 0)
      self.assertEqual(v.w, 0)

   def test_toString(self):
      v = Vector3D()
      self.assertEqual(v.toString(), '(x=0, y=0, z=0)')

      v = Vector3D(1)
      self.assertEqual(v.toString(), '(x=1, y=0, z=0)')

      v = Vector3D(1, 2)
      self.assertEqual(v.toString(), '(x=1, y=2, z=0)')

      v = Vector3D(1, 2, 3)
      self.assertEqual(v.toString(), '(x=1, y=2, z=3)')

      v = Vector3D(1, 2, 3, 4)
      self.assertEqual(v.toString(), '(x=1, y=2, z=3)')

   def test_constants(self):
      self.assertVector3D(Vector3D.X_AXIS, 1, 0, 0, 0)
      self.assertVector3D(Vector3D.Y_AXIS, 0, 1, 0, 0)
      self.assertVector3D(Vector3D.Z_AXIS, 0, 0, 1, 0)

   def test_copyFrom(self):
      v = Vector3D(1, 2, 3, 4)
      v.copyFrom(Vector3D())
      self.assertVector3D(v, 0, 0, 0, 4)

      v = Vector3D()
      v.copyFrom(Vector3D(4, 5, 6, 7))
      self.assertVector3D(v, 4, 5, 6, 0)

      v = Vector3D(1, 2, 3, 4)
      v.copyFrom(Vector3D(4, 5, 6, 7))
      self.assertVector3D(v, 4, 5, 6, 4)

   def test_setTo(self):
      v = Vector3D()
      v.setTo(6, 7, 8)
      self.assertVector3D(v, 6, 7, 8, 0)

      v = Vector3D(1, 2, 3, 4)
      v.setTo(6, 7, 8)
      self.assertVector3D(v, 6, 7, 8, 4)

   def test_add(self):
      v1 = Vector3D()
      v2 = v1.add(Vector3D(1, 2, 3, 4))
      self.assertVector3D(v2, 1, 2, 3, 0)
      self.assertVector3D(v1, 0, 0, 0, 0)

      v1 = Vector3D(5, 6, 8, 9)
      v2 = v1.add(Vector3D())
      self.assertVector3D(v2, 5, 6, 8, 0)

      v1 = Vector3D(6, -7, 8, -9)
      v2 = v1.add(Vector3D(-10, 20, -30, 40))
      self.assertVector3D(v2, -4, 13, -22, 0)

   def test_subtract(self):
      v1 = Vector3D()
      v2 = v1.subtract(Vector3D(1, 2, 3, 4))
      self.assertVector3D(v2, -1, -2, -3, 0)
      self.assertVector3D(v1, 0, 0, 0, 0)

      v1 = Vector3D(5, 6, 8, 9)
      v2 = v1.subtract(Vector3D())
      self.assertVector3D(v2, 5, 6, 8, 0)

      v1 = Vector3D(6, -7, 8, -9)
      v2 = v1.subtract(Vector3D(-10, 20, -30, 40))
      self.assertVector3D(v2, 16, -27, 38, 0)

   def test_incrementBy(self):
      v = Vector3D()
      v.incrementBy(Vector3D())
      self.assertVector3D(v, 0, 0, 0, 0)

      v = Vector3D()
      v.incrementBy(Vector3D(1, 2, -3, 4))
      self.assertVector3D(v, 1, 2, -3, 0)

      v = Vector3D(3, -4, 5, 6)
      v.incrementBy(Vector3D(1, 2, -3, 4))
      self.assertVector3D(v, 4, -2, 2, 6)

   def test_decrementBy(self):
      v = Vector3D()
      v.decrementBy(Vector3D())
      self.assertVector3D(v, 0, 0, 0, 0)

      v = Vector3D()
      v.decrementBy(Vector3D(1, 2, -3, 4))
      self.assertVector3D(v, -1, -2, 3, 0)

      v = Vector3D(3, -4, 5, 6)
      v.decrementBy(Vector3D(1, 2, -3, 4))
      self.assertVector3D(v, 2, -6, 8, 6)

   def test_scaleBy(self):
      v = Vector3D(2, -4, 0, 5)
      v.scaleBy(10)
      self.assertVector3D(v, 20, -40, 0, 5)

      v = Vector3D(2, -4, 0, 5)
      v.scaleBy(-0.5)
      self.assertVector3D(v, -1, 2, 0, 5)

      v = Vector3D(2, -4, 0, 5)
      v.scaleBy(0)
      self.assertVector3D(v, 0, 0, 0, 5)

      v = Vector3D(2, -4, 0, 5)
      v.scaleBy(1)
      self.assertVector3D(v, 2, -4, 0, 5)

      v = Vector3D()
      v.scaleBy(100)
      self.assertVector3D(v, 0, 0, 0, 0)

   def test_negate(self):
      v = Vector3D(2, -4, 0)
      v.negate()
      self.assertVector3D(v, -2, 4, 0, 0)

      v = Vector3D(2, -4, 0, 5)
      v.negate()
      self.assertVector3D(v, -2, 4, 0, 5)

      v = Vector3D()
      v.negate()
      self.assertVector3D(v, 0, 0, 0, 0)

   def test_distance(self):
      d = Vector3D.distance(Vector3D(), Vector3D())
      self.assertEqual(d, 0)

      v = Vector3D(-100, 200, 300, -400)
      d = Vector3D.distance(v, Vector3D(100, 200, 300, -400))
      self.assertEqual(d, 200)

      d = Vector3D.distance(v, Vector3D(-102, 210, 311, -420))
      self.assertEqual(d, 15)

   def test_equals(self):
      v = Vector3D()
      self.assertFalse(v.equals(Vector3D(1, 2, 3, 4)))

      self.assertTrue(v.equals(v))

      self.assertTrue(Vector3D(1, 2, 3).equals(Vector3D(1, 2, 3, 4)))

   def test_nearEquals(self):
      # allFour=False
      n = Vector3D(100, 200, 300).nearEquals(Vector3D(100, 200, 300), 0, False)
      self.assertFalse(n)
      n = Vector3D(100, 200, 300).nearEquals(Vector3D(100, 200, 300), 1, False)
      self.assertTrue(n)
      n = Vector3D(100, 200, 300).nearEquals(Vector3D(100, 200, 300), 10, False)
      self.assertTrue(n)

      n = Vector3D(100, 200, 300, 400).nearEquals(Vector3D(100, 200, 300, 400), 0, False)
      self.assertFalse(n)
      n = Vector3D(100, 200, 300, 400).nearEquals(Vector3D(100, 200, 300, 400), 1, False)
      self.assertTrue(n)
      n = Vector3D(100, 200, 300, 400).nearEquals(Vector3D(100, 200, 300, 400), 10, False)
      self.assertTrue(n)

      n = Vector3D(100, 200, 300, 400).nearEquals(Vector3D(100, 200, 350, 400), 10, False)
      self.assertFalse(n)
      n = Vector3D(100, 200, 300, 400).nearEquals(Vector3D(100, 200, 350, 400), 100, False)
      self.assertTrue(n)

      n = Vector3D(100, 200, 300, 400).nearEquals(Vector3D(100, 200, 300, 450), 10, False)
      self.assertTrue(n)
      n = Vector3D(100, 200, 300, 400).nearEquals(Vector3D(100, 200, 300, 450), 100, False)
      self.assertTrue(n)

      # allFour=True
      n = Vector3D(100, 200, 300).nearEquals(Vector3D(100, 200, 300), 0, True)
      self.assertFalse(n)
      n = Vector3D(100, 200, 300).nearEquals(Vector3D(100, 200, 300), 1, True)
      self.assertTrue(n)
      n = Vector3D(100, 200, 300).nearEquals(Vector3D(100, 200, 300), 10, True)
      self.assertTrue(n)

      n = Vector3D(100, 200, 300, 400).nearEquals(Vector3D(100, 200, 300, 400), 0, True)
      self.assertFalse(n)
      n = Vector3D(100, 200, 300, 400).nearEquals(Vector3D(100, 200, 300, 400), 1, True)
      self.assertFalse(n)
      n = Vector3D(100, 200, 300, 400).nearEquals(Vector3D(100, 200, 300, 400), 10, True)
      self.assertFalse(n)

      n = Vector3D(100, 200, 300, 400).nearEquals(Vector3D(100, 200, 350, 400), 10, True)
      self.assertFalse(n)
      n = Vector3D(100, 200, 300, 400).nearEquals(Vector3D(100, 200, 350, 400), 100, True)
      self.assertFalse(n)

      n = Vector3D(100, 200, 300, 400).nearEquals(Vector3D(100, 200, 300, 450), 10, True)
      self.assertFalse(n)
      n = Vector3D(100, 200, 300, 400).nearEquals(Vector3D(100, 200, 300, 450), 100, True)
      self.assertFalse(n)

      # Buggy with allFour=True
      n = Vector3D(100, 200, 300, 10).nearEquals(Vector3D(100, 200, 300, 20), 100, True)
      self.assertTrue(n)
      n = Vector3D(100, 200, 300, 210).nearEquals(Vector3D(100, 200, 300, 220), 100, True)
      self.assertFalse(n)
      n = Vector3D(100, 200, 300, 0).nearEquals(Vector3D(100, 200, 300, 200), 100, True)
      self.assertFalse(n)
      n = Vector3D(100, 200, 300, 200).nearEquals(Vector3D(100, 200, 300, 0), 100, True)
      self.assertTrue(n)
      n = Vector3D(100, 200, 300, 0).nearEquals(Vector3D(100, 200, 300, -200), 100, True)
      self.assertFalse(n)
      n = Vector3D(100, 200, 300, -200).nearEquals(Vector3D(100, 200, 300, 0), 100, True)
      self.assertTrue(n)

   def test_clone(self):
      v = Vector3D(1, 2, 3, 4)
      clone = v.clone()

      self.assertVector3D(v, 1, 2, 3, 4)
      self.assertVector3D(clone, 1, 2, 3, 4)
      self.assertIsNot(v, clone)
      self.assertTrue(v.equals(clone))

   def test_length(self):
      self.assertEqual(Vector3D().length, 0)
      self.assertEqual(Vector3D(100, 0).length, 100)
      self.assertEqual(Vector3D(2, -10, 11, -20).length, 15)

   def test_lengthSquared(self):
      self.assertEqual(Vector3D().lengthSquared, 0)
      self.assertEqual(Vector3D(100, 0).lengthSquared, 10000)
      self.assertEqual(Vector3D(100, -200, 300, -400).lengthSquared, 140000)

   def test_normalize(self):
      v = Vector3D()
      n = v.normalize()
      self.assertEqual(n, 0)
      self.assertVector3D(v, 0, 0, 0, 0)

      v = Vector3D(30, 40)
      n = v.normalize()
      self.assertEqual(n, 50)
      self.assertVector3D(v, 0.6, 0.8, 0, 0)

      v = Vector3D(-9, 12, 20)
      n = v.normalize()
      self.assertEqual(n, 25)
      self.assertVector3D(v, -0.36, 0.48, 0.8, 0)

      v = Vector3D(-9, 12, 20, -100)
      n = v.normalize()
      self.assertEqual(n, 25)
      self.assertVector3D(v, -0.36, 0.48, 0.8, -100)

      v = Vector3D(undefined, 100, 100, 100)
      n = v.normalize()
      self.assertNaN(n)
      self.assertVector3DNaN(v, 100)

      v = Vector3D(7, null, 24, 365)
      n = v.normalize()
      self.assertEqual(n, 25)
      self.assertVector3D(v, 0.28, 0, 0.96, 365)

   def test_project(self):
      v = Vector3D()
      v.project()
      self.assertVector3DNaN(v, 0)

      v = Vector3D(1, 2, 3)
      v.project()
      self.assertVector3D(v, Infinity, Infinity, Infinity, 0)

      v = Vector3D(1, 2, 3, 1)
      v.project()
      self.assertVector3D(v, 1, 2, 3, 1)

      v = Vector3D(0, 0, 0, 1)
      v.project()
      self.assertVector3D(v, 0, 0, 0, 1)

      v = Vector3D(20, 30, 40, 10)
      v.project()
      self.assertVector3D(v, 2, 3, 4, 10)

      v = Vector3D(5, -6, 7, 0.1)
      v.project()
      self.assertVector3D(v, 50, -60, 70, 0.1)

      v = Vector3D(5, -6, 7, -0.2)
      v.project()
      self.assertVector3D(v, -25, 30, -35, -0.2)

   def test_angleBetween(self):
      a = Vector3D.angleBetween(Vector3D(), Vector3D())
      self.assertNaN(self.roundNumber(a))

      a = Vector3D.angleBetween(Vector3D(), Vector3D(1, 0, 0))
      self.assertNaN(self.roundNumber(a))

      a = Vector3D.angleBetween(Vector3D(1, 0, 0), Vector3D())
      self.assertNaN(self.roundNumber(a))

      a = Vector3D.angleBetween(Vector3D(1, 0, 0), Vector3D(0, 1, 0))
      self.assertEqual(self.roundNumber(a), 1.570796326795)

      a = Vector3D.angleBetween(Vector3D(0, -1, 0), Vector3D(0, 0, 1))
      self.assertEqual(self.roundNumber(a), 1.570796326795)

      a = Vector3D.angleBetween(Vector3D(0, -20, 0), Vector3D(0, 0, 0.1))
      self.assertEqual(self.roundNumber(a), 1.570796326795)

      a = Vector3D.angleBetween(Vector3D(2, 4, 6), Vector3D(0.6, 0.5, 0.1))
      self.assertEqual(self.roundNumber(a), 0.869901249923)

      a = Vector3D.angleBetween(Vector3D(0.6, 0.5, 0.1), Vector3D(2, 4, 6))
      self.assertEqual(self.roundNumber(a), 0.869901249923)

      a = Vector3D.angleBetween(Vector3D(2, 4, 6, 8), Vector3D(0.6, 0.5, 0.1, -0.2))
      self.assertEqual(self.roundNumber(a), 0.869901249923)

   def test_dotProduct(self):
      dp = Vector3D().dotProduct(Vector3D())
      self.assertEqual(self.roundNumber(dp), 0)

      dp = Vector3D().dotProduct(Vector3D(1, 0, 0))
      self.assertEqual(self.roundNumber(dp), 0)

      dp = Vector3D(1, 0, 0).dotProduct(Vector3D())
      self.assertEqual(self.roundNumber(dp), 0)

      dp = Vector3D(1, 0, 0).dotProduct(Vector3D(0, 1, 0))
      self.assertEqual(self.roundNumber(dp), 0)

      dp = Vector3D(0, -1, 0).dotProduct(Vector3D(0, 0, 1))
      self.assertEqual(self.roundNumber(dp), 0)

      dp = Vector3D(0, -20, 0).dotProduct(Vector3D(0, 0, 0.1))
      self.assertEqual(self.roundNumber(dp), 0)

      dp = Vector3D(2, 4, 6).dotProduct(Vector3D(0.6, 0.5, 0.1))
      self.assertEqual(self.roundNumber(dp), 3.8)

      dp = Vector3D(0.6, 0.5, 0.1).dotProduct(Vector3D(2, 4, 6))
      self.assertEqual(self.roundNumber(dp), 3.8)

      dp = Vector3D(2, 4, 6, 8).dotProduct(Vector3D(0.6, 0.5, 0.1, -0.2))
      self.assertEqual(self.roundNumber(dp), 3.8)

   def test_crossProduct(self):
      cp = Vector3D().crossProduct(Vector3D())
      self.assertVector3D(cp, 0, 0, 0, 1)

      cp = Vector3D().crossProduct(Vector3D(1, 0, 0))
      self.assertVector3D(cp, 0, 0, 0, 1)

      cp = Vector3D(1, 0, 0).crossProduct(Vector3D())
      self.assertVector3D(cp, 0, 0, 0, 1)

      cp = Vector3D(1, 0, 0).crossProduct(Vector3D(0, 1, 0))
      self.assertVector3D(cp, 0, 0, 1, 1)

      cp = Vector3D(0, -1, 0).crossProduct(Vector3D(0, 0, 1))
      self.assertVector3D(cp, -1, 0, 0, 1)

      cp = Vector3D(0, -20, 0).crossProduct(Vector3D(0, 0, 0.1))
      self.assertVector3D(cp, -2, 0, 0, 1)

      cp = Vector3D(2, 4, 6).crossProduct(Vector3D(0.6, 0.5, 0.1))
      self.assertVector3D(cp, -2.6, 3.4, -1.4, 1)

      cp = Vector3D(0.6, 0.5, 0.1).crossProduct(Vector3D(2, 4, 6))
      self.assertVector3D(cp, 2.6, -3.4, 1.4, 1)

      cp = Vector3D(2, 4, 6, 8).crossProduct(Vector3D(0.6, 0.5, 0.1, -0.2))
      self.assertVector3D(cp, -2.6, 3.4, -1.4, 1)
