/*
 * cmb_assert.c - function triggered when an cmb_assert fires
 *
 * Copyright (c) Asbjørn M. Bonvik 1993-1995, 2025.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied .
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdio.h>

#include "cmb_assert.h"
#include "cmb_logger.h"

/*
 * cmi_assert_failed - Report and abort in case of assert triggered.
 */
void cmi_assert_failed(const char *sourcefile,
                       const char *func,
                       const int line,
                       const char *condition)
{
    /* Key advice: Place a debugger breakpoint right here. You will thank me later. */
    cmi_logger_fatal(stderr, func, line,
                     "Assert \"%s\" failed, source file %s",
                     condition, sourcefile);
}
