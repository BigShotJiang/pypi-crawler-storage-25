"""Convert Python values to Snowflake SQL API binding format."""

import json
from datetime import datetime, date
from decimal import Decimal
from typing import Any, Dict, List, Optional


def format_bindings(params: Optional[List[Any]]) -> Optional[Dict[str, Dict[str, str]]]:
    """
    Convert a list of Python values to Snowflake SQL API binding format.

    Snowflake expects: {"1": {"type": "TEXT", "value": "val"}, "2": ...}

    Args:
        params: List of Python values in positional order.

    Returns:
        Formatted bindings dict, or None if params is empty/None.
    """
    if not params:
        return None

    bindings = {}
    for i, value in enumerate(params, start=1):
        bindings[str(i)] = _format_single(value)
    return bindings


def _format_single(value: Any) -> Dict[str, Any]:
    """Convert a single Python value to Snowflake binding entry."""
    if value is None:
        return {"type": "TEXT", "value": None}
    elif isinstance(value, bool):
        return {"type": "BOOLEAN", "value": str(value).lower()}
    elif isinstance(value, int):
        return {"type": "FIXED", "value": str(value)}
    elif isinstance(value, float):
        return {"type": "REAL", "value": str(value)}
    elif isinstance(value, Decimal):
        return {"type": "FIXED", "value": str(value)}
    elif isinstance(value, datetime):
        return {"type": "TIMESTAMP", "value": value.isoformat()}
    elif isinstance(value, date):
        return {"type": "DATE", "value": value.isoformat()}
    elif isinstance(value, (list, dict)):
        return {"type": "TEXT", "value": json.dumps(value)}
    else:
        return {"type": "TEXT", "value": str(value)}
