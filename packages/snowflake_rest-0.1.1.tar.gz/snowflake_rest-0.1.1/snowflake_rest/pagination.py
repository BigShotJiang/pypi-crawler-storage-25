"""Result partition fetching and lazy streaming for large result sets."""

import logging
import time
from typing import Any, Callable, Dict, Iterator, List, Optional

import requests

logger = logging.getLogger(__name__)

_PARTITION_MAX_RETRIES = 3
_PARTITION_BASE_DELAY = 1.0


def _fetch_partition_with_retry(
    session: requests.Session,
    url: str,
    headers_fn: Callable[[], Dict[str, str]],
    partition_idx: int,
) -> Optional[List[List[Any]]]:
    """Fetch a single partition with exponential backoff retry."""
    for attempt in range(_PARTITION_MAX_RETRIES):
        try:
            resp = session.get(url, headers=headers_fn(), timeout=60)
            if resp.status_code == 200:
                return resp.json().get("data", [])
            if resp.status_code in (429, 502, 503, 504) and attempt < _PARTITION_MAX_RETRIES - 1:
                delay = _PARTITION_BASE_DELAY * (2 ** attempt)
                logger.warning(
                    f"Partition {partition_idx} returned HTTP {resp.status_code}, "
                    f"retrying in {delay:.1f}s"
                )
                time.sleep(delay)
                continue
            logger.warning(
                f"Failed to fetch partition {partition_idx}: HTTP {resp.status_code}"
            )
            return None
        except (requests.ConnectionError, requests.Timeout) as e:
            if attempt < _PARTITION_MAX_RETRIES - 1:
                delay = _PARTITION_BASE_DELAY * (2 ** attempt)
                logger.warning(
                    f"Partition {partition_idx} error: {e}, retrying in {delay:.1f}s"
                )
                time.sleep(delay)
                continue
            logger.warning(f"Error fetching partition {partition_idx}: {e}")
            return None
        except Exception as e:
            logger.warning(f"Error fetching partition {partition_idx}: {e}")
            return None
    return None


def fetch_all_partitions(
    base_url: str,
    result: Dict[str, Any],
    headers_fn: Callable[[], Dict[str, str]],
    session: requests.Session,
) -> List[List[Any]]:
    """
    Fetch all result partitions from a Snowflake SQL API response.

    The initial response contains partition 0. If there are more partitions,
    fetch them via GET requests to the partition URLs.

    Args:
        base_url: Base Snowflake API URL.
        result: Initial JSON response from Snowflake.
        headers_fn: Callable that returns fresh auth headers.
        session: requests.Session for connection reuse.

    Returns:
        Combined list of all rows across all partitions.
    """
    all_rows = list(result.get("data", []))

    metadata = result.get("resultSetMetaData", {})
    total_partitions = metadata.get("partitionInfo", [])

    if len(total_partitions) <= 1:
        return all_rows

    statement_handle = result.get("statementHandle")
    if not statement_handle:
        return all_rows

    # Fetch partitions 1..N (partition 0 is already in the initial response)
    account_url = base_url.split("/api/v2/")[0]

    for partition_idx in range(1, len(total_partitions)):
        partition_url = (
            f"{account_url}/api/v2/statements/{statement_handle}"
            f"?partition={partition_idx}"
        )
        partition_data = _fetch_partition_with_retry(
            session, partition_url, headers_fn, partition_idx
        )
        if partition_data is None:
            break
        all_rows.extend(partition_data)

    return all_rows


def stream_partitions(
    base_url: str,
    result: Dict[str, Any],
    headers_fn: Callable[[], Dict[str, str]],
    session: requests.Session,
) -> Iterator[List[Any]]:
    """
    Lazily yield rows from all result partitions.

    Yields rows from partition 0 first, then fetches subsequent
    partitions on demand. Memory-efficient for large result sets.

    Args:
        base_url: Base Snowflake API URL.
        result: Initial JSON response from Snowflake.
        headers_fn: Callable that returns fresh auth headers.
        session: requests.Session for connection reuse.

    Yields:
        Individual rows (as lists) from the result set.
    """
    # Yield partition 0 rows
    for row in result.get("data", []):
        yield row

    metadata = result.get("resultSetMetaData", {})
    total_partitions = metadata.get("partitionInfo", [])

    if len(total_partitions) <= 1:
        return

    statement_handle = result.get("statementHandle")
    if not statement_handle:
        return

    account_url = base_url.split("/api/v2/")[0]

    for partition_idx in range(1, len(total_partitions)):
        partition_url = (
            f"{account_url}/api/v2/statements/{statement_handle}"
            f"?partition={partition_idx}"
        )
        partition_data = _fetch_partition_with_retry(
            session, partition_url, headers_fn, partition_idx
        )
        if partition_data is None:
            return
        for row in partition_data:
            yield row
