"""SnowflakeClient — the main entry point for snowflake-rest."""

import json
import os
import time
import uuid
import logging
from typing import Any, Callable, Dict, Iterator, List, Optional, Type, TypeVar, Union

import requests

from .auth import JWTGenerator, load_private_key
from .bindings import format_bindings
from ._escaping import quote_identifier, validate_file_format_key, validate_file_format_value
from .exceptions import (
    AuthError,
    QueryError,
    SnowflakeRestError,
    TimeoutError,
    TransactionError,
)
from .pagination import fetch_all_partitions, stream_partitions
from .retry import RetryableError, with_retry
from .row_mapping import map_rows
from .types import build_coercion_map, coerce_row

logger = logging.getLogger(__name__)

T = TypeVar("T")


class SnowflakeClient:
    """
    Lightweight Snowflake SQL API client.

    Uses JWT keypair authentication over REST, avoiding the need for the native
    Snowflake connector. Suitable for serverless environments (Lambda, Cloud Functions)
    as well as traditional deployments.
    """

    def __init__(
        self,
        account: str,
        user: str,
        private_key: Union[str, bytes, None] = None,
        private_key_path: Optional[str] = None,
        private_key_passphrase: Optional[bytes] = None,
        database: Optional[str] = None,
        schema: Optional[str] = None,
        warehouse: Optional[str] = None,
        role: Optional[str] = None,
        timeout: int = 45,
        poll_interval: float = 2.0,
        max_poll_time: float = 300.0,
        type_coercion: bool = True,
        timezone: str = "UTC",
        retries: int = 0,
        pool_size: int = 10,
        on_query: Optional[Callable] = None,
    ):
        """
        Initialize the Snowflake client.

        Args:
            account: Snowflake account identifier (e.g. "myorg-myaccount").
            user: Snowflake username.
            private_key: PEM-encoded private key as string or bytes.
            private_key_path: Path to .p8 private key file.
            private_key_passphrase: Optional passphrase for encrypted keys.
            database: Default database.
            schema: Default schema.
            warehouse: Default warehouse.
            role: Default role.
            timeout: Default query timeout in seconds.
            poll_interval: Seconds between async poll attempts.
            max_poll_time: Maximum seconds to wait for async queries.
            type_coercion: Auto-convert Snowflake types to Python types.
            timezone: Session timezone (default "UTC").
            retries: Number of retry attempts for transient errors (0 = no retries).
            pool_size: HTTP connection pool size (default 10).
            on_query: Optional callback(sql, duration_ms, rows_returned, query_id).
        """
        self.account = account
        self.user = user
        self.database = database
        self.schema = schema
        self.warehouse = warehouse
        self.role = role
        self.timeout = timeout
        self.poll_interval = poll_interval
        self.max_poll_time = max_poll_time
        self.type_coercion = type_coercion
        self.timezone = timezone
        self._retries = retries
        self._on_query = on_query

        # Load key and set up JWT generator
        key_obj, fingerprint = load_private_key(
            private_key=private_key,
            private_key_path=private_key_path,
            passphrase=private_key_passphrase,
        )
        self._jwt = JWTGenerator(account, user, key_obj, fingerprint)

        # Build base URL (underscores -> hyphens for SSL compatibility)
        account_for_url = account.lower().replace("_", "-")
        self._base_url = (
            f"https://{account_for_url}.snowflakecomputing.com/api/v2/statements"
        )

        # Reuse TCP+TLS connections across queries
        self._session = requests.Session()
        adapter = requests.adapters.HTTPAdapter(
            pool_connections=pool_size, pool_maxsize=pool_size
        )
        self._session.mount("https://", adapter)

        logger.info(f"SnowflakeClient initialized for {account}/{user}")

    @classmethod
    def from_env(cls) -> "SnowflakeClient":
        """
        Create a client from environment variables.

        Reads: SNOWFLAKE_ACCOUNT, SNOWFLAKE_USER, SNOWFLAKE_PRIVATE_KEY (or _PATH),
               SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA, SNOWFLAKE_WAREHOUSE, SNOWFLAKE_ROLE,
               SNOWFLAKE_PRIVATE_KEY_PASSPHRASE, SNOWFLAKE_RETRIES.
        """
        account = os.environ.get("SNOWFLAKE_ACCOUNT")
        user = os.environ.get("SNOWFLAKE_USER")
        if not account or not user:
            raise AuthError(
                "SNOWFLAKE_ACCOUNT and SNOWFLAKE_USER environment variables are required"
            )

        private_key = os.environ.get("SNOWFLAKE_PRIVATE_KEY")
        private_key_path = os.environ.get("SNOWFLAKE_PRIVATE_KEY_PATH")
        passphrase = os.environ.get("SNOWFLAKE_PRIVATE_KEY_PASSPHRASE")

        return cls(
            account=account,
            user=user,
            private_key=private_key,
            private_key_path=private_key_path,
            private_key_passphrase=passphrase.encode() if passphrase else None,
            database=os.environ.get("SNOWFLAKE_DATABASE"),
            schema=os.environ.get("SNOWFLAKE_SCHEMA"),
            warehouse=os.environ.get("SNOWFLAKE_WAREHOUSE"),
            role=os.environ.get("SNOWFLAKE_ROLE"),
            retries=int(os.environ.get("SNOWFLAKE_RETRIES", "0")),
        )

    def __enter__(self) -> "SnowflakeClient":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    def close(self) -> None:
        """Close the underlying HTTP session."""
        self._session.close()

    # ── Headers ──────────────────────────────────────────────────────────

    def _headers(self) -> Dict[str, str]:
        """Build auth headers with a fresh JWT token."""
        return {
            "Authorization": f"Bearer {self._jwt.get_token()}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            "X-Snowflake-Authorization-Token-Type": "KEYPAIR_JWT",
        }

    # ── Core HTTP execution ──────────────────────────────────────────────

    def _execute_raw(
        self,
        sql: str,
        params: Optional[List[Any]] = None,
        extra_params: Optional[Dict[str, Any]] = None,
        statement_timeout: Optional[int] = None,
        async_exec: bool = False,
    ) -> Dict[str, Any]:
        """
        Execute SQL against the Snowflake SQL API and return the raw JSON response.

        This is the lowest-level execution method. All public methods route through here.
        """
        headers = self._headers()
        if async_exec:
            headers["X-Snowflake-Async"] = "true"

        body: Dict[str, Any] = {
            "statement": sql,
            "timeout": statement_timeout or self.timeout,
            "resultSetMetaData": {"format": "json"},
        }

        if self.warehouse:
            body["warehouse"] = self.warehouse
        if self.database:
            body["database"] = self.database
        if self.schema:
            body["schema"] = self.schema
        if self.role:
            body["role"] = self.role

        bindings = format_bindings(params)
        if bindings:
            body["bindings"] = bindings

        body.setdefault("parameters", {})["TIMEZONE"] = self.timezone
        if extra_params:
            body["parameters"].update(extra_params)

        logger.debug(f"Executing: {sql[:100]}...")

        t0 = time.time()
        http_timeout = max((statement_timeout or self.timeout) + 30, 90)

        try:
            response = self._session.post(
                self._base_url,
                headers=headers,
                json=body,
                timeout=http_timeout,
            )
        except (requests.ConnectionError, requests.Timeout) as e:
            raise RetryableError(e)

        duration_ms = (time.time() - t0) * 1000
        logger.info(f"HTTP {response.status_code} in {duration_ms:.0f}ms")

        if response.status_code == 200:
            return response.json()

        if response.status_code == 202:
            # Async auto-promotion or explicit async
            result = response.json()
            if async_exec:
                return result
            # Sync query got auto-promoted — poll for result
            status_url = result.get("statementStatusUrl", "")
            return self._poll_for_result(status_url)

        # Error responses
        if response.status_code in (429, 502, 503, 504):
            raise RetryableError(
                QueryError(
                    f"HTTP {response.status_code}: {response.text}",
                    error_code=str(response.status_code),
                )
            )

        # Parse error details from response
        try:
            err = response.json()
            raise QueryError(
                err.get("message", response.text),
                sql_state=err.get("sqlState"),
                error_code=err.get("code"),
            )
        except (json.JSONDecodeError, KeyError):
            raise QueryError(
                f"HTTP {response.status_code}: {response.text}",
                error_code=str(response.status_code),
            )

    def _execute_with_retry(self, sql: str, **kwargs) -> Dict[str, Any]:
        """Execute with optional retry wrapper."""
        @with_retry(max_retries=self._retries)
        def _do():
            return self._execute_raw(sql, **kwargs)
        return _do()

    # ── Polling ──────────────────────────────────────────────────────────

    def _poll_for_result(self, status_url: str) -> Dict[str, Any]:
        """Poll an async query until completion."""
        base = self._base_url.split("/api/v2/")[0]
        full_url = base + status_url
        elapsed = 0.0

        while elapsed < self.max_poll_time:
            time.sleep(self.poll_interval)
            elapsed += self.poll_interval

            try:
                resp = self._session.get(
                    full_url, headers=self._headers(), timeout=30
                )
            except (requests.ConnectionError, requests.Timeout) as e:
                logger.warning(f"Poll connection error: {e}")
                continue

            if resp.status_code == 200:
                logger.info(f"Async query completed after ~{elapsed:.0f}s")
                return resp.json()
            elif resp.status_code == 202:
                logger.debug(f"Still running after ~{elapsed:.0f}s")
                continue
            else:
                raise QueryError(
                    f"Poll failed: HTTP {resp.status_code}: {resp.text}",
                    error_code=str(resp.status_code),
                )

        raise TimeoutError(f"Query did not complete within {self.max_poll_time}s")

    # ── Result parsing ───────────────────────────────────────────────────

    def _parse_rows(
        self, result: Dict[str, Any], as_tuples: bool = False
    ) -> tuple:
        """
        Parse a Snowflake response into rows.

        Returns:
            Tuple of (rows_as_dicts_or_tuples, column_names, statement_handle, row_types).
        """
        metadata = result.get("resultSetMetaData", {})
        row_types = metadata.get("rowType", [])
        columns = [col["name"] for col in row_types]
        statement_handle = result.get("statementHandle")

        # Fetch all partitions
        all_rows = fetch_all_partitions(
            self._base_url, result, self._headers, self._session
        )

        # Type coercion
        if self.type_coercion and row_types:
            coercers = build_coercion_map(row_types)
            all_rows = [coerce_row(row, coercers) for row in all_rows]

        if as_tuples:
            rows = [tuple(row) for row in all_rows]
        else:
            rows = [dict(zip(columns, row)) for row in all_rows]

        return rows, columns, statement_handle, row_types

    def _notify_hook(
        self, sql: str, duration_ms: float, rows: int, query_id: Optional[str]
    ):
        """Call the on_query hook if registered."""
        if self._on_query:
            try:
                self._on_query(sql, duration_ms, rows, query_id)
            except Exception as e:
                logger.debug(f"on_query hook error: {e}")

    # ── Public query methods ─────────────────────────────────────────────

    def query(
        self,
        sql: str,
        params: Optional[List[Any]] = None,
        row_type: Optional[Type[T]] = None,
        as_tuples: bool = False,
    ) -> list:
        """
        Execute SQL and return rows.

        Args:
            sql: SQL query string with ? placeholders.
            params: List of parameter values.
            row_type: Optional dataclass or Pydantic model for result mapping.
            as_tuples: If True, return rows as tuples instead of dicts.

        Returns:
            List of dicts, tuples, or row_type instances.
        """
        t0 = time.time()
        result = self._execute_with_retry(sql, params=params)
        rows, columns, handle, _ = self._parse_rows(result, as_tuples=as_tuples)
        duration_ms = (time.time() - t0) * 1000
        self._notify_hook(sql, duration_ms, len(rows), handle)

        if row_type and not as_tuples:
            return map_rows(rows, row_type)
        return rows

    def query_one(
        self,
        sql: str,
        params: Optional[List[Any]] = None,
        row_type: Optional[Type[T]] = None,
    ):
        """Execute SQL and return the first row, or None."""
        rows = self.query(sql, params, row_type=row_type)
        return rows[0] if rows else None

    def query_scalar(
        self,
        sql: str,
        params: Optional[List[Any]] = None,
    ) -> Any:
        """Execute SQL and return the first column of the first row."""
        t0 = time.time()
        result = self._execute_with_retry(sql, params=params)
        rows, columns, handle, _ = self._parse_rows(result)
        duration_ms = (time.time() - t0) * 1000
        self._notify_hook(sql, duration_ms, len(rows), handle)

        if not rows:
            return None
        first_row = rows[0]
        if not first_row:
            return None
        return next(iter(first_row.values()))

    def query_column(
        self,
        sql: str,
        params: Optional[List[Any]] = None,
    ) -> List[Any]:
        """Execute SQL and return the first column as a flat list."""
        t0 = time.time()
        result = self._execute_with_retry(sql, params=params)
        rows, columns, handle, _ = self._parse_rows(result)
        duration_ms = (time.time() - t0) * 1000
        self._notify_hook(sql, duration_ms, len(rows), handle)

        if not rows or not columns:
            return []
        first_col = columns[0]
        return [row[first_col] for row in rows]

    def query_df(
        self,
        sql: str,
        params: Optional[List[Any]] = None,
    ):
        """
        Execute SQL and return results as a pandas DataFrame.

        Raises ImportError if pandas is not installed.
        """
        try:
            import pandas as pd
        except ImportError:
            raise ImportError(
                "pandas is required for query_df(). "
                "Install it with: pip install snowflake-rest[pandas]"
            )

        rows = self.query(sql, params)
        return pd.DataFrame(rows)

    def query_stream(
        self,
        sql: str,
        params: Optional[List[Any]] = None,
        row_type: Optional[Type[T]] = None,
    ) -> Iterator:
        """
        Execute SQL and yield rows lazily. Memory-efficient for large result sets.

        Fetches result partitions on demand instead of loading everything into memory.

        Args:
            sql: SQL query string.
            params: List of parameter values.
            row_type: Optional dataclass or Pydantic model to map rows to.

        Yields:
            Dict if row_type is None, otherwise instances of row_type.
        """
        result = self._execute_with_retry(sql, params=params)
        metadata = result.get("resultSetMetaData", {})
        row_types = metadata.get("rowType", [])
        columns = [col["name"] for col in row_types]

        coercers = None
        if self.type_coercion and row_types:
            coercers = build_coercion_map(row_types)

        for raw_row in stream_partitions(
            self._base_url, result, self._headers, self._session
        ):
            if coercers:
                raw_row = coerce_row(raw_row, coercers)

            row_dict = dict(zip(columns, raw_row))

            if row_type:
                from .row_mapping import map_row
                yield map_row(row_dict, row_type)
            else:
                yield row_dict

    # ── DML ──────────────────────────────────────────────────────────────

    def execute(self, sql: str, params: Optional[List[Any]] = None) -> int:
        """
        Execute DML (INSERT/UPDATE/DELETE) and return rows affected.

        Args:
            sql: DML statement with ? placeholders.
            params: List of parameter values.

        Returns:
            Number of rows affected.
        """
        t0 = time.time()
        result = self._execute_with_retry(sql, params=params)
        duration_ms = (time.time() - t0) * 1000
        handle = result.get("statementHandle")

        # Try to extract rows affected from response metadata
        rows_affected = 0
        metadata = result.get("resultSetMetaData", {})
        num_rows = metadata.get("numRows", 0)
        if num_rows:
            rows_affected = num_rows
        elif "data" in result and result["data"]:
            # Some DML returns the count in data
            try:
                rows_affected = int(result["data"][0][0])
            except (IndexError, ValueError, TypeError):
                pass

        self._notify_hook(sql, duration_ms, rows_affected, handle)
        return rows_affected

    # ── Batch insert ─────────────────────────────────────────────────────

    def insert_many(
        self,
        table: str,
        rows: List[Dict[str, Any]],
        batch_size: int = 1000,
    ) -> int:
        """
        Insert multiple rows efficiently, auto-chunked into batches.

        Args:
            table: Table name (e.g. "MY_TABLE" or "SCHEMA.MY_TABLE").
            rows: List of dicts where keys are column names.
            batch_size: Maximum rows per INSERT statement.

        Returns:
            Total number of rows inserted.
        """
        if not rows:
            return 0

        from ._escaping import escape_value

        # Use columns from the first row
        columns = list(rows[0].keys())
        safe_table = quote_identifier(table)
        col_list = ", ".join(quote_identifier(c) for c in columns)
        total_inserted = 0

        for i in range(0, len(rows), batch_size):
            batch = rows[i : i + batch_size]
            value_rows = []
            for row in batch:
                vals = ", ".join(escape_value(row.get(c)) for c in columns)
                value_rows.append(f"({vals})")

            values_sql = ",\n".join(value_rows)
            sql = f'INSERT INTO {safe_table} ({col_list})\nVALUES\n{values_sql}'

            result = self._execute_with_retry(sql)
            total_inserted += len(batch)

        return total_inserted

    # ── Transactions ─────────────────────────────────────────────────────

    def transaction(self, warehouse: Optional[str] = None) -> "Transaction":
        """
        Return a Transaction context manager.

        Usage:
            with client.transaction() as tx:
                tx.set('now_ts', 'CURRENT_TIMESTAMP()')
                tx.execute("UPDATE t SET col=? WHERE id=?", [val, id])
                tx.execute("INSERT INTO audit (...) VALUES (?)", [val])
        """
        return Transaction(self, warehouse=warehouse)

    # ── Async queries ────────────────────────────────────────────────────

    def submit(
        self, sql: str, params: Optional[List[Any]] = None
    ) -> "QueryHandle":
        """
        Submit an async query and return a handle immediately.

        Args:
            sql: SQL query string.
            params: List of parameter values.

        Returns:
            QueryHandle for checking status and retrieving results.
        """
        result = self._execute_with_retry(sql, params=params, async_exec=True)
        handle = result.get("statementHandle")
        if not handle:
            raise QueryError("Async submission did not return a statement handle")

        return QueryHandle(
            client=self,
            handle_id=handle,
            status_url=result.get("statementStatusUrl", ""),
        )

    # ── Stored procedures ────────────────────────────────────────────────

    def call(
        self,
        procedure: str,
        args: Optional[List[Any]] = None,
    ) -> Any:
        """
        Call a stored procedure and return the parsed result.

        Args:
            procedure: Procedure name (e.g. 'MY_PROCEDURE' or '"MY_PROC"').
            args: List of positional argument values.

        Returns:
            Parsed VARIANT result (dict, list, or scalar).
        """
        safe_procedure = quote_identifier(procedure)
        placeholders = ", ".join(["?" for _ in (args or [])])
        sql = f"CALL {safe_procedure}({placeholders})"

        result = self._execute_with_retry(sql, params=args)
        rows, _, _, _ = self._parse_rows(result)

        if not rows:
            return None

        raw_value = next(iter(rows[0].values()))

        # VARIANT may come as JSON string or already parsed
        if isinstance(raw_value, str):
            try:
                return json.loads(raw_value)
            except json.JSONDecodeError:
                return raw_value
        return raw_value

    # ── Export ────────────────────────────────────────────────────────────

    def export(
        self,
        sql: str,
        stage: str,
        path: str,
        filename: Optional[str] = None,
        params: Optional[List[Any]] = None,
        file_format: Optional[Dict[str, str]] = None,
        header: bool = True,
        async_exec: bool = False,
    ):
        """
        Export query results to a stage via COPY INTO.

        Args:
            sql: SELECT query to export.
            stage: Stage name (e.g. "@MY_STAGE").
            path: Path within stage (e.g. "exports/2026/").
            filename: Output filename (auto-generated if None).
            params: Query parameters.
            file_format: File format options (defaults to CSV/GZIP).
            header: Include column headers.
            async_exec: If True, return QueryHandle instead of ExportResult.

        Returns:
            ExportResult or QueryHandle (if async_exec=True).
        """
        from ._escaping import substitute_placeholders

        if filename is None:
            filename = f"export_{uuid.uuid4().hex[:12]}.csv.gz"

        # Substitute params into the inner query
        inner_sql = substitute_placeholders(sql, params or [])

        # Build file format clause
        if file_format:
            fmt_parts = ", ".join(
                f"{validate_file_format_key(k)}={validate_file_format_value(v)}"
                for k, v in file_format.items()
            )
        else:
            fmt_parts = (
                "TYPE='CSV', FIELD_OPTIONALLY_ENCLOSED_BY='\"', COMPRESSION=GZIP"
            )

        header_str = "TRUE" if header else "FALSE"
        full_path = f"{stage}/{path.rstrip('/')}/{filename}"

        copy_sql = (
            f"COPY INTO '{full_path}'\n"
            f"FROM ({inner_sql})\n"
            f"FILE_FORMAT = ({fmt_parts})\n"
            f"SINGLE=TRUE HEADER={header_str} MAX_FILE_SIZE=100000000"
        )

        if async_exec:
            return self.submit(copy_sql)

        result = self._execute_with_retry(copy_sql, statement_timeout=300)

        # Parse COPY INTO result
        rows_unloaded = 0
        file_size = 0
        if "data" in result and result["data"]:
            try:
                row = result["data"][0]
                rows_unloaded = int(row[0]) if row[0] else 0
                # file_size is typically in column index 2 or 3
                for val in row[1:]:
                    try:
                        size = int(val)
                        if size > rows_unloaded:
                            file_size = size
                            break
                    except (ValueError, TypeError):
                        continue
            except (IndexError, ValueError, TypeError):
                pass

        return ExportResult(
            rows_unloaded=rows_unloaded,
            file_size=file_size,
            path=full_path,
        )


# ── Transaction ──────────────────────────────────────────────────────────


class Transaction:
    """
    Transaction context manager for atomic multi-statement execution.

    Queues statements and sends them all as BEGIN/COMMIT on exit.
    """

    def __init__(self, client: SnowflakeClient, warehouse: Optional[str] = None):
        self._client = client
        self._warehouse = warehouse
        self._statements: List[tuple] = []  # [(sql, params), ...]

    def __enter__(self) -> "Transaction":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        if exc_type is not None:
            # Exception occurred — don't send anything
            return

        if not self._statements:
            return

        self._commit()

    def execute(self, sql: str, params: Optional[List[Any]] = None) -> None:
        """Queue a statement in the transaction."""
        self._statements.append((sql, params or []))

    def set(self, var: str, expr: str) -> None:
        """
        Queue a SET statement in the transaction.

        Args:
            var: Variable name.
            expr: SQL expression (e.g. 'CURRENT_TIMESTAMP()').
        """
        self._statements.append((f"SET {var} = {expr}", []))

    def _commit(self) -> None:
        """Send all queued statements as a single atomic transaction."""
        from ._escaping import substitute_placeholders

        sql_parts = ["BEGIN"]
        for sql, params in self._statements:
            sql_parts.append(substitute_placeholders(sql, params))
        sql_parts.append("COMMIT")

        combined_sql = ";\n".join(sql_parts)
        total_count = len(self._statements) + 2  # BEGIN + stmts + COMMIT

        # Temporarily override warehouse if specified
        original_warehouse = self._client.warehouse
        if self._warehouse:
            self._client.warehouse = self._warehouse

        try:
            result = self._client._execute_with_retry(
                combined_sql,
                extra_params={"MULTI_STATEMENT_COUNT": str(total_count)},
                statement_timeout=300,
            )
        except SnowflakeRestError:
            raise
        except Exception as e:
            raise TransactionError(f"Transaction failed: {e}") from e
        finally:
            self._client.warehouse = original_warehouse


# ── QueryHandle ──────────────────────────────────────────────────────────


class QueryHandle:
    """Handle for an async query, with status checking and result retrieval."""

    def __init__(self, client: SnowflakeClient, handle_id: str, status_url: str):
        self._client = client
        self.handle_id = handle_id
        self._status_url = status_url

    def status(self) -> str:
        """
        Check query status.

        Returns:
            'running', 'complete', or 'failed'.
        """
        headers = self._client._headers()
        url = f"{self._client._base_url}/{self.handle_id}"

        resp = self._client._session.get(url, headers=headers, timeout=30)

        if resp.status_code == 202:
            return "running"

        if resp.status_code == 200:
            result = resp.json()
            code = result.get("code", "")
            if code in ("090003", "333334"):
                return "running"
            if code == "090001" or "data" in result:
                return "complete"
            if code.startswith("001") or code.startswith("002"):
                return "failed"
            return "complete"

        return "failed"

    def result(self, poll: bool = True) -> List[Dict[str, Any]]:
        """
        Get query results.

        Args:
            poll: If True, block until the query completes.

        Returns:
            List of row dicts.
        """
        if poll:
            elapsed = 0.0
            while elapsed < self._client.max_poll_time:
                s = self.status()
                if s == "complete":
                    break
                if s == "failed":
                    raise QueryError("Async query failed")
                time.sleep(self._client.poll_interval)
                elapsed += self._client.poll_interval
            else:
                raise TimeoutError(
                    f"Async query did not complete within {self._client.max_poll_time}s"
                )

        # Fetch final result
        headers = self._client._headers()
        url = f"{self._client._base_url}/{self.handle_id}"
        resp = self._client._session.get(url, headers=headers, timeout=60)

        if resp.status_code != 200:
            raise QueryError(f"Failed to fetch results: HTTP {resp.status_code}")

        result = resp.json()
        rows, _, _, _ = self._client._parse_rows(result)
        return rows

    def cancel(self) -> None:
        """Cancel the running query."""
        headers = self._client._headers()
        url = f"{self._client._base_url}/{self.handle_id}/cancel"
        self._client._session.post(url, headers=headers, timeout=30)


# ── ExportResult ─────────────────────────────────────────────────────────


class ExportResult:
    """Result of a COPY INTO export operation."""

    def __init__(self, rows_unloaded: int, file_size: int, path: str):
        self.rows_unloaded = rows_unloaded
        self.file_size = file_size
        self.path = path

    def __repr__(self) -> str:
        return (
            f"ExportResult(rows_unloaded={self.rows_unloaded}, "
            f"file_size={self.file_size}, path='{self.path}')"
        )
