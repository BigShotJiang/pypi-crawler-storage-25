"""CLI entry point for snowflake-rest."""

import argparse
import csv
import io
import json
import sys
import time
import threading

from .client import SnowflakeClient
from .exceptions import SnowflakeRestError


# ── ANSI helpers ────────────────────────────────────────────────────────

_IS_TTY = hasattr(sys.stderr, "isatty") and sys.stderr.isatty()

_BOLD = "\033[1m" if _IS_TTY else ""
_DIM = "\033[2m" if _IS_TTY else ""
_CYAN = "\033[36m" if _IS_TTY else ""
_GREEN = "\033[32m" if _IS_TTY else ""
_YELLOW = "\033[33m" if _IS_TTY else ""
_RED = "\033[31m" if _IS_TTY else ""
_RESET = "\033[0m" if _IS_TTY else ""
_CLEAR_LINE = "\033[2K\r" if _IS_TTY else ""


# ── Spinner ─────────────────────────────────────────────────────────────

class _Spinner:
    """Simple terminal spinner that runs in a background thread."""

    _FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]

    def __init__(self, message="Running query"):
        self._message = message
        self._stop_event = threading.Event()
        self._thread = None

    def __enter__(self):
        if _IS_TTY:
            self._thread = threading.Thread(target=self._spin, daemon=True)
            self._thread.start()
        return self

    def __exit__(self, *exc):
        self._stop_event.set()
        if self._thread:
            self._thread.join()
        if _IS_TTY:
            sys.stderr.write(_CLEAR_LINE)
            sys.stderr.flush()

    def _spin(self):
        i = 0
        while not self._stop_event.is_set():
            frame = self._FRAMES[i % len(self._FRAMES)]
            sys.stderr.write(f"{_CLEAR_LINE}{_CYAN}{frame}{_RESET} {_DIM}{self._message}...{_RESET}")
            sys.stderr.flush()
            i += 1
            self._stop_event.wait(0.08)


# ── Main ────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        prog="snowflake-rest",
        description="Query Snowflake from the command line via SQL API.",
    )
    subparsers = parser.add_subparsers(dest="command")

    # query subcommand
    query_parser = subparsers.add_parser("query", help="Execute a SQL query")
    query_parser.add_argument("sql", nargs="?", help="SQL query string")
    query_parser.add_argument(
        "-f", "--file", help="Read SQL from a file instead"
    )
    query_parser.add_argument(
        "--format",
        choices=["table", "csv", "json", "jsonl"],
        default="table",
        help="Output format (default: table)",
    )
    query_parser.add_argument(
        "--params", help="JSON array of query parameters (e.g. '[42, \"active\"]')"
    )
    query_parser.add_argument("--database", help="Override database")
    query_parser.add_argument("--schema", help="Override schema")
    query_parser.add_argument("--warehouse", help="Override warehouse")
    query_parser.add_argument("--role", help="Override role")

    args = parser.parse_args()

    if args.command != "query":
        parser.print_help()
        sys.exit(1)

    # Get SQL
    if args.file:
        with open(args.file, "r") as f:
            sql = f.read().strip()
    elif args.sql:
        sql = args.sql
    else:
        query_parser.print_help()
        sys.exit(1)

    # Parse params
    params = None
    if args.params:
        try:
            params = json.loads(args.params)
            if not isinstance(params, list):
                print(f"{_RED}Error:{_RESET} --params must be a JSON array", file=sys.stderr)
                sys.exit(1)
        except json.JSONDecodeError as e:
            print(f"{_RED}Error:{_RESET} invalid JSON in --params: {e}", file=sys.stderr)
            sys.exit(1)

    # Create client from env vars
    try:
        client = SnowflakeClient.from_env()
    except SnowflakeRestError as e:
        print(f"{_RED}Error:{_RESET} {e}", file=sys.stderr)
        print(
            f"{_DIM}Set SNOWFLAKE_ACCOUNT, SNOWFLAKE_USER, and "
            f"SNOWFLAKE_PRIVATE_KEY_PATH environment variables.{_RESET}",
            file=sys.stderr,
        )
        sys.exit(1)

    # Apply overrides
    if args.database:
        client.database = args.database
    if args.schema:
        client.schema = args.schema
    if args.warehouse:
        client.warehouse = args.warehouse
    if args.role:
        client.role = args.role

    # Execute
    try:
        t0 = time.time()
        with _Spinner("Running query"):
            rows = client.query(sql, params)
        duration = time.time() - t0
    except SnowflakeRestError as e:
        print(f"{_RED}Error:{_RESET} {e}", file=sys.stderr)
        sys.exit(1)

    # Output
    if not rows:
        print(f"{_DIM}0 rows returned ({duration:.2f}s){_RESET}", file=sys.stderr)
        return

    if args.format == "json":
        print(json.dumps(rows, indent=2, default=str))
    elif args.format == "jsonl":
        for row in rows:
            print(json.dumps(row, default=str))
    elif args.format == "csv":
        writer = csv.DictWriter(sys.stdout, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)
    else:
        # Table format
        _print_table(rows)

    # Summary line
    row_label = "row" if len(rows) == 1 else "rows"
    print(
        f"\n{_GREEN}{len(rows)} {row_label}{_RESET} {_DIM}({duration:.2f}s){_RESET}",
        file=sys.stderr,
    )


def _print_table(rows):
    """Print rows as a styled ASCII table."""
    if not rows:
        return

    columns = list(rows[0].keys())

    # Calculate column widths (cap at 40 to prevent blowout)
    widths = {col: len(col) for col in columns}
    for row in rows:
        for col in columns:
            val = str(row.get(col, ""))
            widths[col] = min(max(widths[col], len(val)), 40)

    # Header
    header = f" {_DIM}│{_RESET} ".join(
        f"{_BOLD}{col.ljust(widths[col])}{_RESET}" for col in columns
    )
    separator = f"{_DIM}─┼─{_RESET}".join(
        f"{_DIM}{'─' * widths[col]}{_RESET}" for col in columns
    )

    print(f" {header} ")
    print(f"{_DIM}─{_RESET}{separator}{_DIM}─{_RESET}")

    # Rows
    for row in rows:
        cells = []
        for col in columns:
            val = str(row.get(col, ""))
            if len(val) > 40:
                val = val[:37] + "..."
            cells.append(val.ljust(widths[col]))
        line = f" {_DIM}│{_RESET} ".join(cells)
        print(f" {line} ")


if __name__ == "__main__":
    main()
