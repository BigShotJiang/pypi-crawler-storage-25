"""Custom exceptions for snowflake-rest."""


class SnowflakeRestError(Exception):
    """Base exception for all snowflake-rest errors."""


class AuthError(SnowflakeRestError):
    """JWT generation, key loading, or fingerprint errors."""


class QueryError(SnowflakeRestError):
    """Query execution failed (syntax error, permission denied, etc.)."""

    def __init__(self, message: str, sql_state: str = None, error_code: str = None):
        self.sql_state = sql_state
        self.error_code = error_code
        super().__init__(message)


class TransactionError(SnowflakeRestError):
    """Transaction failed to commit."""


class TimeoutError(SnowflakeRestError):
    """Async poll exceeded max_poll_time."""
