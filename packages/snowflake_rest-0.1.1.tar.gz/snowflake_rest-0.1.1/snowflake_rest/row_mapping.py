"""Map result dicts to dataclass or Pydantic model instances."""

import dataclasses
from typing import Any, Dict, List, Optional, Type, TypeVar

T = TypeVar("T")

# Detect Pydantic availability at import time
_PYDANTIC_AVAILABLE = False
try:
    import pydantic
    _PYDANTIC_AVAILABLE = True
except ImportError:
    pass


def map_row(row: Dict[str, Any], row_type: Type[T]) -> T:
    """
    Map a dict row to a dataclass or Pydantic model instance.

    Args:
        row: Dict of column_name -> value.
        row_type: Target type (dataclass or Pydantic BaseModel).

    Returns:
        Instance of row_type.
    """
    if _PYDANTIC_AVAILABLE and _is_pydantic_model(row_type):
        return row_type.model_validate(row)

    if dataclasses.is_dataclass(row_type):
        # Only pass fields that the dataclass declares
        field_names = {f.name for f in dataclasses.fields(row_type)}
        filtered = {k: v for k, v in row.items() if k in field_names}
        return row_type(**filtered)

    # Fallback: try calling the constructor with the dict
    return row_type(**row)


def map_rows(rows: List[Dict[str, Any]], row_type: Optional[Type[T]]) -> list:
    """
    Map a list of dict rows to typed instances.

    Args:
        rows: List of dicts.
        row_type: Target type, or None to return dicts as-is.

    Returns:
        List of row_type instances (or original dicts if row_type is None).
    """
    if row_type is None:
        return rows
    return [map_row(row, row_type) for row in rows]


def _is_pydantic_model(cls) -> bool:
    """Check if a class is a Pydantic BaseModel subclass."""
    if not _PYDANTIC_AVAILABLE:
        return False
    try:
        return issubclass(cls, pydantic.BaseModel)
    except TypeError:
        return False
