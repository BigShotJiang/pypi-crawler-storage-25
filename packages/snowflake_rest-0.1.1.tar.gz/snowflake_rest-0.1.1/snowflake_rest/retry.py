"""Retry logic with exponential backoff for transient failures."""

import time
import logging
from functools import wraps
from typing import Callable, TypeVar

import requests

from .exceptions import SnowflakeRestError

logger = logging.getLogger(__name__)

T = TypeVar("T")

# HTTP status codes that indicate transient errors worth retrying
_RETRYABLE_STATUS_CODES = {429, 503, 502, 504}


class RetryableError(Exception):
    """Marker for errors that should be retried."""

    def __init__(self, original: Exception):
        self.original = original
        super().__init__(str(original))


def is_retryable(error: Exception) -> bool:
    """Determine if an error is transient and worth retrying."""
    if isinstance(error, RetryableError):
        return True
    if isinstance(error, requests.ConnectionError):
        return True
    if isinstance(error, requests.Timeout):
        return True
    if isinstance(error, requests.HTTPError):
        if error.response is not None:
            return error.response.status_code in _RETRYABLE_STATUS_CODES
    return False


def with_retry(max_retries: int = 0, base_delay: float = 1.0):
    """
    Decorator that retries a function on transient failures.

    Uses exponential backoff: delay = base_delay * 2^attempt.
    Only retries on connection errors, timeouts, and 429/502/503/504.
    Does NOT retry on query errors (syntax, permissions, etc.).

    Args:
        max_retries: Maximum number of retry attempts (0 = no retries).
        base_delay: Base delay in seconds before first retry.
    """
    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        if max_retries <= 0:
            return func

        @wraps(func)
        def wrapper(*args, **kwargs) -> T:
            last_error = None
            for attempt in range(max_retries + 1):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_error = e
                    if attempt < max_retries and is_retryable(e):
                        delay = base_delay * (2 ** attempt)
                        logger.warning(
                            f"Retryable error (attempt {attempt + 1}/{max_retries + 1}), "
                            f"retrying in {delay:.1f}s: {e}"
                        )
                        time.sleep(delay)
                    else:
                        raise
            raise last_error

        return wrapper
    return decorator
