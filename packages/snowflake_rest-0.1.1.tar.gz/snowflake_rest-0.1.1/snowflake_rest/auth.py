"""JWT authentication for Snowflake SQL API."""

import time
import hashlib
import base64
import logging
from typing import Optional, Union

import jwt
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.backends import default_backend

from .exceptions import AuthError

logger = logging.getLogger(__name__)


def load_private_key(
    private_key: Union[str, bytes, None] = None,
    private_key_path: Optional[str] = None,
    passphrase: Optional[bytes] = None,
) -> tuple:
    """
    Load RSA private key and compute public key fingerprint.

    Args:
        private_key: PEM-encoded key as string or bytes.
        private_key_path: Path to .p8 key file.
        passphrase: Optional passphrase for encrypted keys.

    Returns:
        Tuple of (private_key_obj, fingerprint_str).

    Raises:
        AuthError: If key cannot be loaded.
    """
    try:
        if private_key is not None:
            if isinstance(private_key, str):
                key_data = private_key.encode("utf-8")
            else:
                key_data = private_key
        elif private_key_path is not None:
            with open(private_key_path, "rb") as f:
                key_data = f.read()
        else:
            raise AuthError("Either private_key or private_key_path must be provided")

        key_obj = serialization.load_pem_private_key(
            key_data,
            password=passphrase,
            backend=default_backend(),
        )

        # Compute SHA256 fingerprint of the public key
        pub_der = key_obj.public_key().public_bytes(
            encoding=serialization.Encoding.DER,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        fingerprint = "SHA256:" + base64.b64encode(
            hashlib.sha256(pub_der).digest()
        ).decode("utf-8")

        return key_obj, fingerprint

    except AuthError:
        raise
    except Exception as e:
        raise AuthError(f"Failed to load private key: {e}") from e


class JWTGenerator:
    """Generates and caches JWT tokens for Snowflake SQL API authentication."""

    def __init__(self, account: str, user: str, private_key_obj, fingerprint: str):
        self._account = account.upper()
        self._user = user.upper()
        self._private_key = private_key_obj
        self._fingerprint = fingerprint
        self._cached_token: Optional[str] = None
        self._cached_exp: int = 0

    def get_token(self) -> str:
        """Return a valid JWT token, generating a new one if needed."""
        now = int(time.time())

        # Reuse cached token if still valid (60s safety margin)
        if self._cached_token and self._cached_exp > now + 60:
            return self._cached_token

        qualified_username = f"{self._account}.{self._user}"
        exp = now + 3600

        payload = {
            "iss": f"{qualified_username}.{self._fingerprint}",
            "sub": qualified_username,
            "iat": now,
            "exp": exp,
        }

        try:
            token = jwt.encode(payload, self._private_key, algorithm="RS256")
        except Exception as e:
            raise AuthError(f"Failed to generate JWT: {e}") from e

        self._cached_token = token
        self._cached_exp = exp
        logger.debug("Generated new JWT token for Snowflake authentication")
        return token
