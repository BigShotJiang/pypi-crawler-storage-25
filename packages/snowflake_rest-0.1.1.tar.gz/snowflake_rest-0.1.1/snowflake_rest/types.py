"""Snowflake result type coercion — convert string values to Python native types."""

import json
import logging
from datetime import datetime, date, time
from decimal import Decimal
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)

# Snowflake timestamp formats (SQL API returns these as strings)
_TIMESTAMP_FORMATS = [
    "%Y-%m-%dT%H:%M:%S.%f%z",      # with timezone and fractional
    "%Y-%m-%dT%H:%M:%S%z",          # with timezone, no fractional
    "%Y-%m-%dT%H:%M:%S.%f",         # no timezone, fractional
    "%Y-%m-%dT%H:%M:%S",            # no timezone, no fractional
    "%Y-%m-%d %H:%M:%S.%f%z",       # space separator
    "%Y-%m-%d %H:%M:%S.%f",         # space separator, no tz
    "%Y-%m-%d %H:%M:%S",            # space separator, no fractional
]


def _parse_timestamp(value: str) -> datetime:
    """Parse a Snowflake timestamp string into a datetime."""
    # fromisoformat is C-level fast and handles most Snowflake formats (Python 3.11+)
    try:
        return datetime.fromisoformat(value)
    except ValueError:
        pass
    for fmt in _TIMESTAMP_FORMATS:
        try:
            return datetime.strptime(value, fmt)
        except ValueError:
            continue
    raise ValueError(f"Cannot parse timestamp: {value}")


def _parse_date(value: str) -> date:
    """Parse a Snowflake date string into a date."""
    try:
        return date.fromisoformat(value)
    except ValueError:
        # Snowflake may return epoch days as a number string
        try:
            return date.fromordinal(int(value) + 719163)  # Unix epoch offset
        except (ValueError, OverflowError):
            raise ValueError(f"Cannot parse date: {value}")


def _parse_time(value: str) -> time:
    """Parse a Snowflake time string into a time."""
    for fmt in ["%H:%M:%S.%f", "%H:%M:%S"]:
        try:
            return datetime.strptime(value, fmt).time()
        except ValueError:
            continue
    raise ValueError(f"Cannot parse time: {value}")


def _parse_json(value: str):
    """Parse a JSON string into a Python object."""
    try:
        return json.loads(value)
    except (json.JSONDecodeError, TypeError):
        return value


def build_coercion_map(row_types: List[Dict[str, Any]]) -> List[Optional[Callable]]:
    """
    Build a list of coercion functions from Snowflake resultSetMetaData.rowType.

    Each entry in row_types has: name, type, scale, precision, nullable, etc.

    Returns:
        List of callables (or None for no conversion) matching column order.
    """
    coercers = []
    for col in row_types:
        sf_type = col.get("type", "").upper()
        scale = col.get("scale", 0)

        if sf_type == "FIXED":
            if scale == 0:
                coercers.append(lambda v: int(v) if v is not None else None)
            else:
                coercers.append(lambda v: Decimal(v) if v is not None else None)
        elif sf_type in ("REAL", "FLOAT"):
            coercers.append(lambda v: float(v) if v is not None else None)
        elif sf_type == "BOOLEAN":
            coercers.append(
                lambda v: v in ("true", "True", "TRUE", "1") if v is not None else None
            )
        elif sf_type in (
            "TIMESTAMP_NTZ", "TIMESTAMP_LTZ", "TIMESTAMP_TZ", "TIMESTAMP"
        ):
            coercers.append(lambda v: _parse_timestamp(v) if v is not None else None)
        elif sf_type == "DATE":
            coercers.append(lambda v: _parse_date(v) if v is not None else None)
        elif sf_type == "TIME":
            coercers.append(lambda v: _parse_time(v) if v is not None else None)
        elif sf_type in ("VARIANT", "OBJECT", "ARRAY"):
            coercers.append(lambda v: _parse_json(v) if v is not None else None)
        else:
            # TEXT, VARCHAR, etc. — no conversion
            coercers.append(None)

    return coercers


def coerce_row(row: List[Any], coercers: List[Optional[Callable]]) -> List[Any]:
    """Apply coercion functions to a single row of values in place."""
    for i in range(min(len(row), len(coercers))):
        if row[i] is not None and coercers[i] is not None:
            try:
                row[i] = coercers[i](row[i])
            except (ValueError, TypeError) as e:
                logger.debug(f"Type coercion failed for column {i}, value={row[i]!r}: {e}")
    return row
