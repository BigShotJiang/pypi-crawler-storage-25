"""
Internal: SQL value escaping and placeholder substitution for transactions.

Snowflake SQL API only applies bindings to the FIRST statement in
multi-statement requests. For transactions, we inline values safely.
"""

import json
from datetime import datetime, date
from decimal import Decimal
from typing import Any, List


def quote_identifier(name: str) -> str:
    """
    Quote a Snowflake identifier (table, column, procedure name).

    Handles dotted names like "DB.SCHEMA.TABLE" by quoting each part individually.
    Already-quoted parts (surrounded by double quotes) are left as-is.

    Args:
        name: SQL identifier, possibly dotted.

    Returns:
        Safely quoted identifier string.
    """
    parts = []
    for part in name.split("."):
        stripped = part.strip()
        if stripped.startswith('"') and stripped.endswith('"'):
            # Already quoted — just escape internal double quotes
            inner = stripped[1:-1].replace('"', '""')
            parts.append(f'"{inner}"')
        else:
            parts.append(f'"{stripped.replace(chr(34), chr(34)+chr(34))}"')
    return ".".join(parts)


def validate_file_format_key(key: str) -> str:
    """Validate a file format option key is a simple alphanumeric identifier."""
    cleaned = key.strip().upper()
    if not cleaned.replace("_", "").isalnum():
        raise ValueError(f"Invalid file format key: {key!r}")
    return cleaned


def validate_file_format_value(value: str) -> str:
    """Validate a file format option value contains no SQL injection vectors."""
    val = str(value).strip()
    # Allow simple tokens: TRUE, FALSE, GZIP, CSV, 'delim', numbers, etc.
    # Reject semicolons, comments, and unbalanced quotes
    if ";" in val or "--" in val or "/*" in val:
        raise ValueError(f"Invalid file format value: {value!r}")
    return val


def escape_value(value: Any) -> str:
    """
    Escape a Python value for safe inline SQL insertion.

    Args:
        value: The value to escape.

    Returns:
        SQL-safe string representation.
    """
    if value is None:
        return "NULL"
    elif isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    elif isinstance(value, (int, float, Decimal)):
        return str(value)
    elif isinstance(value, datetime):
        return f"'{value.isoformat()}'"
    elif isinstance(value, date):
        return f"'{value.isoformat()}'"
    elif isinstance(value, (list, dict)):
        escaped = json.dumps(value).replace("\\", "\\\\").replace("'", "''")
        return f"'{escaped}'"
    elif isinstance(value, str):
        escaped = value.replace("\\", "\\\\").replace("'", "''")
        return f"'{escaped}'"
    else:
        escaped = str(value).replace("\\", "\\\\").replace("'", "''")
        return f"'{escaped}'"


def substitute_placeholders(sql: str, params: List[Any]) -> str:
    """
    Replace ? placeholders with escaped literal values.

    Uses character-by-character scanning to avoid replacing ? inside
    string literals. Handles escaped quotes ('') correctly.

    Args:
        sql: SQL with ? placeholders.
        params: List of values in positional order.

    Returns:
        SQL with placeholders replaced by escaped values.
    """
    if not params:
        return sql

    parts = []
    param_idx = 0
    in_string = False
    i = 0

    while i < len(sql):
        char = sql[i]

        if char == "'" and in_string:
            # Check for escaped quote ('')
            if i + 1 < len(sql) and sql[i + 1] == "'":
                parts.append("''")
                i += 2
                continue
            else:
                in_string = False
                parts.append(char)
        elif char == "'" and not in_string:
            in_string = True
            parts.append(char)
        elif char == "?" and not in_string and param_idx < len(params):
            parts.append(escape_value(params[param_idx]))
            param_idx += 1
        else:
            parts.append(char)

        i += 1

    return "".join(parts)
