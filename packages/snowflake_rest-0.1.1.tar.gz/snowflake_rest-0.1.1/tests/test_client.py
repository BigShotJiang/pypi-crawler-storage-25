"""Tests for SnowflakeClient with mocked HTTP responses."""

import json
import os
from unittest.mock import MagicMock, patch

import pytest
import responses

from snowflake_rest import SnowflakeClient, AuthError, QueryError

# Test RSA key generation
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization


def _generate_test_key_pem() -> bytes:
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    return key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )


TEST_KEY = _generate_test_key_pem()
TEST_ACCOUNT = "testorg-testaccount"
TEST_USER = "TEST_USER"
BASE_URL = f"https://{TEST_ACCOUNT}.snowflakecomputing.com/api/v2/statements"


def _make_client(**kwargs) -> SnowflakeClient:
    defaults = dict(
        account=TEST_ACCOUNT,
        user=TEST_USER,
        private_key=TEST_KEY,
        database="TEST_DB",
        schema="PUBLIC",
        warehouse="TEST_WH",
    )
    defaults.update(kwargs)
    return SnowflakeClient(**defaults)


def _snowflake_response(columns, rows, handle="test-handle-123"):
    """Build a mock Snowflake SQL API response."""
    return {
        "resultSetMetaData": {
            "rowType": [
                {"name": col[0], "type": col[1], "scale": col[2] if len(col) > 2 else 0}
                for col in columns
            ],
            "partitionInfo": [{"rowCount": len(rows)}],
        },
        "data": rows,
        "statementHandle": handle,
    }


class TestClientInit:
    def test_basic_init(self):
        client = _make_client()
        assert client.account == TEST_ACCOUNT
        assert client.database == "TEST_DB"

    def test_from_env(self):
        env = {
            "SNOWFLAKE_ACCOUNT": "myorg-myaccount",
            "SNOWFLAKE_USER": "myuser",
            "SNOWFLAKE_PRIVATE_KEY": TEST_KEY.decode(),
            "SNOWFLAKE_DATABASE": "MY_DB",
        }
        with patch.dict(os.environ, env, clear=False):
            client = SnowflakeClient.from_env()
            assert client.account == "myorg-myaccount"
            assert client.database == "MY_DB"

    def test_from_env_missing_account(self):
        with patch.dict(os.environ, {}, clear=True):
            with pytest.raises(AuthError, match="SNOWFLAKE_ACCOUNT"):
                SnowflakeClient.from_env()

    def test_context_manager(self):
        with _make_client() as client:
            assert client is not None


class TestQuery:
    @responses.activate
    def test_simple_query(self):
        resp = _snowflake_response(
            columns=[("ID", "FIXED", 0), ("NAME", "TEXT")],
            rows=[["42", "Alice"], ["43", "Bob"]],
        )
        responses.add(responses.POST, BASE_URL, json=resp, status=200)

        client = _make_client()
        rows = client.query("SELECT * FROM users")

        assert len(rows) == 2
        assert rows[0]["ID"] == 42  # Type coercion: FIXED -> int
        assert rows[0]["NAME"] == "Alice"

    @responses.activate
    def test_query_with_params(self):
        resp = _snowflake_response(
            columns=[("ID", "FIXED", 0)],
            rows=[["42"]],
        )
        responses.add(responses.POST, BASE_URL, json=resp, status=200)

        client = _make_client()
        rows = client.query("SELECT * FROM users WHERE id = ?", [42])

        assert len(rows) == 1
        # Verify bindings were sent
        request_body = json.loads(responses.calls[0].request.body)
        assert "bindings" in request_body
        assert request_body["bindings"]["1"]["type"] == "FIXED"

    @responses.activate
    def test_query_one(self):
        resp = _snowflake_response(
            columns=[("COUNT", "FIXED", 0)],
            rows=[["100"]],
        )
        responses.add(responses.POST, BASE_URL, json=resp, status=200)

        client = _make_client()
        row = client.query_one("SELECT COUNT(*) AS COUNT FROM users")
        assert row == {"COUNT": 100}

    @responses.activate
    def test_query_one_empty(self):
        resp = _snowflake_response(columns=[("ID", "FIXED", 0)], rows=[])
        responses.add(responses.POST, BASE_URL, json=resp, status=200)

        client = _make_client()
        assert client.query_one("SELECT * FROM empty") is None

    @responses.activate
    def test_query_scalar(self):
        resp = _snowflake_response(
            columns=[("COUNT", "FIXED", 0)],
            rows=[["42"]],
        )
        responses.add(responses.POST, BASE_URL, json=resp, status=200)

        client = _make_client()
        result = client.query_scalar("SELECT COUNT(*) FROM users")
        assert result == 42

    @responses.activate
    def test_query_column(self):
        resp = _snowflake_response(
            columns=[("ID", "FIXED", 0)],
            rows=[["1"], ["2"], ["3"]],
        )
        responses.add(responses.POST, BASE_URL, json=resp, status=200)

        client = _make_client()
        ids = client.query_column("SELECT id FROM users")
        assert ids == [1, 2, 3]

    @responses.activate
    def test_query_as_tuples(self):
        resp = _snowflake_response(
            columns=[("ID", "FIXED", 0), ("NAME", "TEXT")],
            rows=[["1", "Alice"]],
        )
        responses.add(responses.POST, BASE_URL, json=resp, status=200)

        client = _make_client()
        rows = client.query("SELECT * FROM users", as_tuples=True)
        assert rows == [(1, "Alice")]

    @responses.activate
    def test_type_coercion_disabled(self):
        resp = _snowflake_response(
            columns=[("ID", "FIXED", 0)],
            rows=[["42"]],
        )
        responses.add(responses.POST, BASE_URL, json=resp, status=200)

        client = _make_client(type_coercion=False)
        rows = client.query("SELECT id FROM users")
        assert rows[0]["ID"] == "42"  # No coercion, stays string


class TestQueryError:
    @responses.activate
    def test_query_error_response(self):
        responses.add(
            responses.POST,
            BASE_URL,
            json={"message": "Object does not exist", "code": "002003", "sqlState": "42S02"},
            status=422,
        )

        client = _make_client()
        with pytest.raises(QueryError) as exc_info:
            client.query("SELECT * FROM nonexistent")

        assert exc_info.value.error_code == "002003"
        assert exc_info.value.sql_state == "42S02"


class TestExecute:
    @responses.activate
    def test_execute_dml(self):
        resp = {
            "resultSetMetaData": {
                "numRows": 5,
                "rowType": [],
            },
            "data": [],
            "statementHandle": "handle-123",
        }
        responses.add(responses.POST, BASE_URL, json=resp, status=200)

        client = _make_client()
        affected = client.execute("UPDATE users SET status = ?", ["inactive"])
        assert affected == 5


class TestOnQueryHook:
    @responses.activate
    def test_hook_called(self):
        resp = _snowflake_response(
            columns=[("ID", "FIXED", 0)],
            rows=[["1"]],
        )
        responses.add(responses.POST, BASE_URL, json=resp, status=200)

        hook_calls = []
        def my_hook(sql, duration_ms, rows, query_id):
            hook_calls.append((sql, rows, query_id))

        client = _make_client(on_query=my_hook)
        client.query("SELECT 1")

        assert len(hook_calls) == 1
        assert hook_calls[0][0] == "SELECT 1"
        assert hook_calls[0][1] == 1
        assert hook_calls[0][2] == "test-handle-123"


class TestRowTypeMapping:
    @responses.activate
    def test_dataclass_mapping(self):
        from dataclasses import dataclass

        @dataclass
        class User:
            ID: int
            NAME: str

        resp = _snowflake_response(
            columns=[("ID", "FIXED", 0), ("NAME", "TEXT")],
            rows=[["42", "Alice"]],
        )
        responses.add(responses.POST, BASE_URL, json=resp, status=200)

        client = _make_client()
        users = client.query("SELECT * FROM users", row_type=User)
        assert isinstance(users[0], User)
        assert users[0].ID == 42
        assert users[0].NAME == "Alice"
