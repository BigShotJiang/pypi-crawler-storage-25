"""Tests for SQL escaping and placeholder substitution."""

from datetime import datetime
from decimal import Decimal

from snowflake_rest._escaping import escape_value, substitute_placeholders


class TestEscapeValue:
    def test_none(self):
        assert escape_value(None) == "NULL"

    def test_bool_true(self):
        assert escape_value(True) == "TRUE"

    def test_bool_false(self):
        assert escape_value(False) == "FALSE"

    def test_int(self):
        assert escape_value(42) == "42"

    def test_float(self):
        assert escape_value(3.14) == "3.14"

    def test_decimal(self):
        assert escape_value(Decimal("99.50")) == "99.50"

    def test_string(self):
        assert escape_value("hello") == "'hello'"

    def test_string_with_quotes(self):
        assert escape_value("it's") == "'it''s'"

    def test_string_with_backslash(self):
        assert escape_value("a\\b") == "'a\\\\b'"

    def test_string_with_quotes_and_backslash(self):
        assert escape_value("it's\\n") == "'it''s\\\\n'"

    def test_datetime(self):
        dt = datetime(2026, 4, 3, 12, 0, 0)
        assert "2026-04-03" in escape_value(dt)

    def test_list_as_json(self):
        result = escape_value([1, 2, 3])
        assert result == "'[1, 2, 3]'"

    def test_dict_as_json(self):
        result = escape_value({"key": "val"})
        assert "'key'" not in result  # Should be JSON, not Python repr
        assert "key" in result


class TestSubstitutePlaceholders:
    def test_no_params(self):
        sql = "SELECT * FROM t"
        assert substitute_placeholders(sql, []) == sql

    def test_single_param(self):
        sql = "SELECT * FROM t WHERE id = ?"
        result = substitute_placeholders(sql, [42])
        assert result == "SELECT * FROM t WHERE id = 42"

    def test_multiple_params(self):
        sql = "SELECT * FROM t WHERE id = ? AND name = ?"
        result = substitute_placeholders(sql, [42, "Alice"])
        assert result == "SELECT * FROM t WHERE id = 42 AND name = 'Alice'"

    def test_question_mark_in_string_literal(self):
        sql = "SELECT * FROM t WHERE note = 'what?' AND id = ?"
        result = substitute_placeholders(sql, [42])
        assert result == "SELECT * FROM t WHERE note = 'what?' AND id = 42"

    def test_escaped_quotes_in_string(self):
        sql = "SELECT * FROM t WHERE name = 'O''Brien' AND id = ?"
        result = substitute_placeholders(sql, [42])
        assert result == "SELECT * FROM t WHERE name = 'O''Brien' AND id = 42"

    def test_null_param(self):
        sql = "UPDATE t SET col = ? WHERE id = ?"
        result = substitute_placeholders(sql, [None, 1])
        assert result == "UPDATE t SET col = NULL WHERE id = 1"

    def test_bool_param(self):
        sql = "UPDATE t SET active = ? WHERE id = ?"
        result = substitute_placeholders(sql, [True, 1])
        assert result == "UPDATE t SET active = TRUE WHERE id = 1"

    def test_string_with_special_chars(self):
        sql = "INSERT INTO t (name) VALUES (?)"
        result = substitute_placeholders(sql, ["it's a \"test\""])
        assert "it''s" in result

    def test_sql_injection_prevention(self):
        sql = "SELECT * FROM t WHERE name = ?"
        result = substitute_placeholders(sql, ["'; DROP TABLE t; --"])
        # The injected SQL should be escaped inside quotes
        assert "DROP TABLE" in result
        assert result.count("'") >= 4  # Opening, escaped inner quotes, closing
