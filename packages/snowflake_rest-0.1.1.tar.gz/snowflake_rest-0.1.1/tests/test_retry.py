"""Tests for retry logic."""

import pytest
import requests

from snowflake_rest.retry import RetryableError, is_retryable, with_retry


class TestIsRetryable:
    def test_retryable_error(self):
        assert is_retryable(RetryableError(Exception("test")))

    def test_connection_error(self):
        assert is_retryable(requests.ConnectionError())

    def test_timeout_error(self):
        assert is_retryable(requests.Timeout())

    def test_generic_exception_not_retryable(self):
        assert not is_retryable(ValueError("test"))

    def test_runtime_error_not_retryable(self):
        assert not is_retryable(RuntimeError("test"))


class TestWithRetry:
    def test_no_retry_on_success(self):
        call_count = 0

        @with_retry(max_retries=3, base_delay=0.01)
        def succeed():
            nonlocal call_count
            call_count += 1
            return "ok"

        assert succeed() == "ok"
        assert call_count == 1

    def test_retry_on_retryable_error(self):
        call_count = 0

        @with_retry(max_retries=3, base_delay=0.01)
        def fail_then_succeed():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise RetryableError(Exception("transient"))
            return "ok"

        assert fail_then_succeed() == "ok"
        assert call_count == 3

    def test_no_retry_on_permanent_error(self):
        call_count = 0

        @with_retry(max_retries=3, base_delay=0.01)
        def fail_permanently():
            nonlocal call_count
            call_count += 1
            raise ValueError("permanent error")

        with pytest.raises(ValueError, match="permanent"):
            fail_permanently()
        assert call_count == 1

    def test_max_retries_exceeded(self):
        call_count = 0

        @with_retry(max_retries=2, base_delay=0.01)
        def always_fail():
            nonlocal call_count
            call_count += 1
            raise RetryableError(Exception("always fails"))

        with pytest.raises(RetryableError):
            always_fail()
        assert call_count == 3  # 1 initial + 2 retries

    def test_zero_retries_no_retry(self):
        call_count = 0

        @with_retry(max_retries=0)
        def fail():
            nonlocal call_count
            call_count += 1
            raise RetryableError(Exception("fail"))

        with pytest.raises(RetryableError):
            fail()
        assert call_count == 1
