"""Tests for transaction context manager."""

import json

import responses
import pytest

from tests.test_client import _make_client, _snowflake_response, BASE_URL
from snowflake_rest.exceptions import TransactionError


class TestTransaction:
    @responses.activate
    def test_basic_transaction(self):
        """Transaction sends BEGIN + statements + COMMIT as multi-statement."""
        resp = _snowflake_response(columns=[], rows=[])
        responses.add(responses.POST, BASE_URL, json=resp, status=200)

        client = _make_client()
        with client.transaction() as tx:
            tx.execute("UPDATE t SET col = ? WHERE id = ?", ["val", 42])
            tx.execute("INSERT INTO audit (action) VALUES (?)", ["update"])

        body = json.loads(responses.calls[0].request.body)
        sql = body["statement"]
        assert sql.startswith("BEGIN")
        assert "COMMIT" in sql
        assert "'val'" in sql  # Params inlined
        assert "42" in sql
        assert body["parameters"]["MULTI_STATEMENT_COUNT"] == "4"  # BEGIN + 2 + COMMIT

    @responses.activate
    def test_transaction_with_set(self):
        """Transaction supports SET session variables."""
        resp = _snowflake_response(columns=[], rows=[])
        responses.add(responses.POST, BASE_URL, json=resp, status=200)

        client = _make_client()
        with client.transaction() as tx:
            tx.set("now_ts", "CURRENT_TIMESTAMP()")
            tx.execute("UPDATE t SET ts = $now_ts WHERE id = ?", [1])

        body = json.loads(responses.calls[0].request.body)
        sql = body["statement"]
        assert "SET now_ts = CURRENT_TIMESTAMP()" in sql
        assert "$now_ts" in sql
        assert body["parameters"]["MULTI_STATEMENT_COUNT"] == "4"

    @responses.activate
    def test_transaction_warehouse_override(self):
        """Transaction can override warehouse."""
        resp = _snowflake_response(columns=[], rows=[])
        responses.add(responses.POST, BASE_URL, json=resp, status=200)

        client = _make_client()
        original_wh = client.warehouse

        with client.transaction(warehouse="BIG_WH") as tx:
            tx.execute("UPDATE t SET col = ?", ["val"])

        # Warehouse should be restored after transaction
        assert client.warehouse == original_wh
        # The request should have used the override
        body = json.loads(responses.calls[0].request.body)
        assert body["warehouse"] == "BIG_WH"

    def test_transaction_no_send_on_exception(self):
        """Transaction should NOT send anything if an exception occurs."""
        client = _make_client()

        with pytest.raises(ValueError):
            with client.transaction() as tx:
                tx.execute("UPDATE t SET col = ?", ["val"])
                raise ValueError("something broke")

        # No HTTP calls should have been made

    def test_empty_transaction_no_send(self):
        """Empty transaction should not send any HTTP request."""
        client = _make_client()
        with client.transaction() as tx:
            pass  # No statements added
        # No HTTP calls

    @responses.activate
    def test_transaction_multiple_params(self):
        """Transaction correctly inlines multiple parameters per statement."""
        resp = _snowflake_response(columns=[], rows=[])
        responses.add(responses.POST, BASE_URL, json=resp, status=200)

        client = _make_client()
        with client.transaction() as tx:
            tx.execute(
                "UPDATE t SET a=?, b=?, c=? WHERE id=?",
                ["hello", True, None, 42],
            )

        body = json.loads(responses.calls[0].request.body)
        sql = body["statement"]
        assert "'hello'" in sql
        assert "TRUE" in sql
        assert "NULL" in sql
        assert "42" in sql
