"""Tests for the CLI."""

import json
import subprocess
import sys
import os

import pytest
import responses

from snowflake_rest.cli import _print_table


class TestPrintTable:
    def test_basic_table(self, capsys):
        rows = [
            {"ID": 1, "NAME": "Alice"},
            {"ID": 2, "NAME": "Bob"},
        ]
        _print_table(rows)
        output = capsys.readouterr().out
        assert "ID" in output
        assert "NAME" in output
        assert "Alice" in output
        assert "Bob" in output

    def test_empty_table(self, capsys):
        _print_table([])
        output = capsys.readouterr().out
        assert output == ""


class TestCLIHelp:
    def test_main_help(self):
        result = subprocess.run(
            [sys.executable, "-m", "snowflake_rest.cli", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "snowflake-rest" in result.stdout

    def test_query_help(self):
        result = subprocess.run(
            [sys.executable, "-m", "snowflake_rest.cli", "query", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "--format" in result.stdout
        assert "--params" in result.stdout

    def test_no_command_shows_help(self):
        result = subprocess.run(
            [sys.executable, "-m", "snowflake_rest.cli"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 1

    def test_query_no_sql_shows_help(self):
        result = subprocess.run(
            [sys.executable, "-m", "snowflake_rest.cli", "query"],
            capture_output=True,
            text=True,
            env={**os.environ, "SNOWFLAKE_ACCOUNT": "", "SNOWFLAKE_USER": ""},
        )
        assert result.returncode == 1

    def test_missing_env_vars_error(self):
        """CLI shows error when env vars are missing."""
        env = {k: v for k, v in os.environ.items()}
        # Remove snowflake vars
        for key in list(env.keys()):
            if key.startswith("SNOWFLAKE_"):
                del env[key]

        result = subprocess.run(
            [sys.executable, "-m", "snowflake_rest.cli", "query", "SELECT 1"],
            capture_output=True,
            text=True,
            env=env,
        )
        assert result.returncode == 1
        assert "SNOWFLAKE_ACCOUNT" in result.stderr

    def test_invalid_params_json(self):
        """CLI shows error on invalid --params JSON."""
        # Need valid env vars to get past the client creation
        # But we'll fail on params parsing first since it happens before client creation
        env = {**os.environ}
        for key in list(env.keys()):
            if key.startswith("SNOWFLAKE_"):
                del env[key]

        result = subprocess.run(
            [
                sys.executable, "-m", "snowflake_rest.cli",
                "query", "SELECT 1", "--params", "not-json",
            ],
            capture_output=True,
            text=True,
            env=env,
        )
        assert result.returncode == 1
        assert "invalid JSON" in result.stderr or "SNOWFLAKE_ACCOUNT" in result.stderr
