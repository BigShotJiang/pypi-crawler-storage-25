"""Tests for auth module."""

import pytest

from snowflake_rest.auth import JWTGenerator, load_private_key
from snowflake_rest.exceptions import AuthError

# Generate a test RSA key pair for testing
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization


def _generate_test_key_pem() -> bytes:
    """Generate a test RSA private key in PEM format."""
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    return key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )


class TestLoadPrivateKey:
    def test_load_from_bytes(self):
        pem = _generate_test_key_pem()
        key_obj, fingerprint = load_private_key(private_key=pem)
        assert key_obj is not None
        assert fingerprint.startswith("SHA256:")

    def test_load_from_string(self):
        pem = _generate_test_key_pem().decode("utf-8")
        key_obj, fingerprint = load_private_key(private_key=pem)
        assert key_obj is not None
        assert fingerprint.startswith("SHA256:")

    def test_load_from_file(self, tmp_path):
        pem = _generate_test_key_pem()
        key_file = tmp_path / "test_key.p8"
        key_file.write_bytes(pem)

        key_obj, fingerprint = load_private_key(private_key_path=str(key_file))
        assert key_obj is not None
        assert fingerprint.startswith("SHA256:")

    def test_no_key_provided(self):
        with pytest.raises(AuthError, match="Either private_key or private_key_path"):
            load_private_key()

    def test_invalid_key_data(self):
        with pytest.raises(AuthError, match="Failed to load"):
            load_private_key(private_key="not-a-real-key")


class TestJWTGenerator:
    def test_generate_token(self):
        pem = _generate_test_key_pem()
        key_obj, fingerprint = load_private_key(private_key=pem)
        gen = JWTGenerator("myaccount", "myuser", key_obj, fingerprint)

        token = gen.get_token()
        assert isinstance(token, str)
        assert len(token) > 0

    def test_token_caching(self):
        pem = _generate_test_key_pem()
        key_obj, fingerprint = load_private_key(private_key=pem)
        gen = JWTGenerator("myaccount", "myuser", key_obj, fingerprint)

        token1 = gen.get_token()
        token2 = gen.get_token()
        assert token1 == token2  # Should be cached

    def test_account_user_uppercased(self):
        pem = _generate_test_key_pem()
        key_obj, fingerprint = load_private_key(private_key=pem)
        gen = JWTGenerator("myaccount", "myuser", key_obj, fingerprint)

        assert gen._account == "MYACCOUNT"
        assert gen._user == "MYUSER"
