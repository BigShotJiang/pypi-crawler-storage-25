"""Tests for streaming results and pagination."""

import responses

from tests.test_client import _make_client, BASE_URL


def _multi_partition_response():
    """Build a response with 2 partitions."""
    return {
        "resultSetMetaData": {
            "rowType": [
                {"name": "ID", "type": "FIXED", "scale": 0},
                {"name": "NAME", "type": "TEXT", "scale": 0},
            ],
            "partitionInfo": [
                {"rowCount": 2},
                {"rowCount": 2},
            ],
        },
        "data": [["1", "Alice"], ["2", "Bob"]],
        "statementHandle": "part-handle-123",
    }


def _partition_1_response():
    return {
        "data": [["3", "Charlie"], ["4", "Diana"]],
    }


class TestQueryStream:
    @responses.activate
    def test_stream_single_partition(self):
        """query_stream yields all rows from a single partition."""
        resp = {
            "resultSetMetaData": {
                "rowType": [
                    {"name": "ID", "type": "FIXED", "scale": 0},
                ],
                "partitionInfo": [{"rowCount": 3}],
            },
            "data": [["1"], ["2"], ["3"]],
            "statementHandle": "h-1",
        }
        responses.add(responses.POST, BASE_URL, json=resp, status=200)

        client = _make_client()
        rows = list(client.query_stream("SELECT id FROM t"))
        assert len(rows) == 3
        assert rows[0] == {"ID": 1}
        assert rows[2] == {"ID": 3}

    @responses.activate
    def test_stream_multiple_partitions(self):
        """query_stream fetches partitions lazily."""
        responses.add(
            responses.POST, BASE_URL, json=_multi_partition_response(), status=200
        )

        part_url = (
            "https://testorg-testaccount.snowflakecomputing.com"
            "/api/v2/statements/part-handle-123?partition=1"
        )
        responses.add(responses.GET, part_url, json=_partition_1_response(), status=200)

        client = _make_client()
        rows = list(client.query_stream("SELECT * FROM t"))
        assert len(rows) == 4
        assert rows[0]["NAME"] == "Alice"
        assert rows[3]["NAME"] == "Diana"

    @responses.activate
    def test_stream_with_row_type(self):
        """query_stream supports row_type mapping."""
        from dataclasses import dataclass

        @dataclass
        class Item:
            ID: int
            NAME: str

        resp = {
            "resultSetMetaData": {
                "rowType": [
                    {"name": "ID", "type": "FIXED", "scale": 0},
                    {"name": "NAME", "type": "TEXT", "scale": 0},
                ],
                "partitionInfo": [{"rowCount": 1}],
            },
            "data": [["42", "Widget"]],
            "statementHandle": "h-1",
        }
        responses.add(responses.POST, BASE_URL, json=resp, status=200)

        client = _make_client()
        items = list(client.query_stream("SELECT * FROM items", row_type=Item))
        assert len(items) == 1
        assert isinstance(items[0], Item)
        assert items[0].ID == 42


class TestPaginatedQuery:
    @responses.activate
    def test_query_fetches_all_partitions(self):
        """Regular query() also fetches all partitions."""
        responses.add(
            responses.POST, BASE_URL, json=_multi_partition_response(), status=200
        )

        part_url = (
            "https://testorg-testaccount.snowflakecomputing.com"
            "/api/v2/statements/part-handle-123?partition=1"
        )
        responses.add(responses.GET, part_url, json=_partition_1_response(), status=200)

        client = _make_client()
        rows = client.query("SELECT * FROM t")
        assert len(rows) == 4
        assert rows[3]["NAME"] == "Diana"
