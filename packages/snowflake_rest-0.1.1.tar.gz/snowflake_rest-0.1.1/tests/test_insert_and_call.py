"""Tests for insert_many and stored procedure calls."""

import json

import responses

from tests.test_client import _make_client, _snowflake_response, BASE_URL


class TestInsertMany:
    @responses.activate
    def test_basic_insert(self):
        """insert_many sends INSERT with escaped values."""
        resp = _snowflake_response(columns=[], rows=[])
        responses.add(responses.POST, BASE_URL, json=resp, status=200)

        client = _make_client()
        count = client.insert_many("MY_TABLE", [
            {"NAME": "Alice", "AGE": 30},
            {"NAME": "Bob", "AGE": 25},
        ])

        assert count == 2
        body = json.loads(responses.calls[0].request.body)
        sql = body["statement"]
        assert 'INSERT INTO "MY_TABLE" ("NAME", "AGE")' in sql
        assert "'Alice'" in sql
        assert "'Bob'" in sql
        assert "30" in sql
        assert "25" in sql

    @responses.activate
    def test_insert_batching(self):
        """insert_many splits into batches."""
        resp = _snowflake_response(columns=[], rows=[])
        # Two batches expected
        responses.add(responses.POST, BASE_URL, json=resp, status=200)
        responses.add(responses.POST, BASE_URL, json=resp, status=200)

        client = _make_client()
        rows = [{"VAL": i} for i in range(5)]
        count = client.insert_many("T", rows, batch_size=3)

        assert count == 5
        assert len(responses.calls) == 2  # 2 batches: 3 + 2

    def test_insert_empty(self):
        """insert_many with empty list returns 0."""
        client = _make_client()
        assert client.insert_many("T", []) == 0

    @responses.activate
    def test_insert_with_none_values(self):
        """insert_many handles NULL values."""
        resp = _snowflake_response(columns=[], rows=[])
        responses.add(responses.POST, BASE_URL, json=resp, status=200)

        client = _make_client()
        client.insert_many("T", [{"NAME": "Alice", "NOTE": None}])

        body = json.loads(responses.calls[0].request.body)
        sql = body["statement"]
        assert "NULL" in sql

    @responses.activate
    def test_insert_with_special_chars(self):
        """insert_many escapes special characters."""
        resp = _snowflake_response(columns=[], rows=[])
        responses.add(responses.POST, BASE_URL, json=resp, status=200)

        client = _make_client()
        client.insert_many("T", [{"NAME": "O'Brien", "NOTE": "a\\b"}])

        body = json.loads(responses.calls[0].request.body)
        sql = body["statement"]
        assert "O''Brien" in sql
        assert "a\\\\b" in sql


class TestCall:
    @responses.activate
    def test_call_procedure_dict_result(self):
        """call() parses JSON string VARIANT result."""
        resp = _snowflake_response(
            columns=[("PROC_RESULT", "VARIANT")],
            rows=[['{"status": "ok", "count": 5}']],
        )
        responses.add(responses.POST, BASE_URL, json=resp, status=200)

        client = _make_client()
        result = client.call("MY_PROC", [42, "arg2"])

        assert result == {"status": "ok", "count": 5}
        body = json.loads(responses.calls[0].request.body)
        assert 'CALL "MY_PROC"(?, ?)' in body["statement"]

    @responses.activate
    def test_call_procedure_no_args(self):
        """call() works with no arguments."""
        resp = _snowflake_response(
            columns=[("RESULT", "TEXT")],
            rows=[["done"]],
        )
        responses.add(responses.POST, BASE_URL, json=resp, status=200)

        client = _make_client()
        result = client.call("MY_PROC")

        assert result == "done"
        body = json.loads(responses.calls[0].request.body)
        assert 'CALL "MY_PROC"()' in body["statement"]

    @responses.activate
    def test_call_procedure_empty_result(self):
        """call() returns None when procedure returns no rows."""
        resp = _snowflake_response(columns=[("R", "TEXT")], rows=[])
        responses.add(responses.POST, BASE_URL, json=resp, status=200)

        client = _make_client()
        result = client.call("MY_PROC", [1])
        assert result is None
