"""Tests for error handling, retries, and edge cases."""

import json

import responses
import requests
import pytest

from tests.test_client import _make_client, _snowflake_response, BASE_URL
from snowflake_rest.exceptions import QueryError, TimeoutError
from snowflake_rest.retry import RetryableError


class TestHTTPErrors:
    @responses.activate
    def test_422_query_error(self):
        """422 raises QueryError with parsed details."""
        responses.add(
            responses.POST,
            BASE_URL,
            json={
                "message": "Object 'T' does not exist.",
                "code": "002003",
                "sqlState": "42S02",
            },
            status=422,
        )

        client = _make_client()
        with pytest.raises(QueryError) as exc_info:
            client.query("SELECT * FROM T")

        assert exc_info.value.error_code == "002003"
        assert exc_info.value.sql_state == "42S02"
        assert "does not exist" in str(exc_info.value)

    @responses.activate
    def test_400_bad_request(self):
        """400 raises QueryError."""
        responses.add(
            responses.POST,
            BASE_URL,
            json={"message": "Bad request"},
            status=400,
        )

        client = _make_client()
        with pytest.raises(QueryError):
            client.query("INVALID SQL")

    @responses.activate
    def test_500_non_json_response(self):
        """Non-JSON error response still raises QueryError."""
        responses.add(
            responses.POST,
            BASE_URL,
            body="Internal Server Error",
            status=500,
        )

        client = _make_client()
        with pytest.raises(QueryError, match="500"):
            client.query("SELECT 1")


class TestRetryIntegration:
    @responses.activate
    def test_retry_on_429(self):
        """429 is retried, second attempt succeeds."""
        responses.add(responses.POST, BASE_URL, body="Rate limited", status=429)
        resp = _snowflake_response(
            columns=[("ID", "FIXED", 0)], rows=[["1"]]
        )
        responses.add(responses.POST, BASE_URL, json=resp, status=200)

        client = _make_client(retries=2)
        rows = client.query("SELECT 1")
        assert len(rows) == 1
        assert len(responses.calls) == 2  # First failed, second succeeded

    @responses.activate
    def test_retry_on_503(self):
        """503 is retried."""
        responses.add(responses.POST, BASE_URL, body="Unavailable", status=503)
        resp = _snowflake_response(
            columns=[("ID", "FIXED", 0)], rows=[["1"]]
        )
        responses.add(responses.POST, BASE_URL, json=resp, status=200)

        client = _make_client(retries=1)
        rows = client.query("SELECT 1")
        assert len(rows) == 1

    @responses.activate
    def test_no_retry_on_syntax_error(self):
        """Query syntax errors (422) are NOT retried."""
        responses.add(
            responses.POST,
            BASE_URL,
            json={"message": "Syntax error", "code": "001003"},
            status=422,
        )

        client = _make_client(retries=3)
        with pytest.raises(QueryError):
            client.query("SELCT 1")  # typo

        assert len(responses.calls) == 1  # No retries


class TestPollTimeout:
    @responses.activate
    def test_poll_timeout(self):
        """Sync query auto-promoted to async times out if poll exceeds max."""
        async_resp = {
            "statementHandle": "timeout-h",
            "statementStatusUrl": "/api/v2/statements/timeout-h",
        }
        responses.add(responses.POST, BASE_URL, json=async_resp, status=202)

        poll_url = "https://testorg-testaccount.snowflakecomputing.com/api/v2/statements/timeout-h"
        for _ in range(50):
            responses.add(responses.GET, poll_url, json={}, status=202)

        client = _make_client(poll_interval=0.01, max_poll_time=0.05)
        with pytest.raises(TimeoutError):
            client.query("SELECT * FROM slow_table")
