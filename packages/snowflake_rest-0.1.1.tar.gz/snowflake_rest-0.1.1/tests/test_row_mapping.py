"""Tests for row mapping."""

from dataclasses import dataclass

from snowflake_rest.row_mapping import map_row, map_rows


@dataclass
class User:
    ID: int
    NAME: str
    STATUS: str


class TestMapRow:
    def test_dataclass_mapping(self):
        row = {"ID": 42, "NAME": "Alice", "STATUS": "active"}
        user = map_row(row, User)
        assert isinstance(user, User)
        assert user.ID == 42
        assert user.NAME == "Alice"
        assert user.STATUS == "active"

    def test_dataclass_extra_columns_ignored(self):
        row = {"ID": 42, "NAME": "Alice", "STATUS": "active", "EXTRA": "ignored"}
        user = map_row(row, User)
        assert user.ID == 42
        assert not hasattr(user, "EXTRA")


class TestMapRows:
    def test_none_row_type_returns_dicts(self):
        rows = [{"A": 1}, {"A": 2}]
        result = map_rows(rows, None)
        assert result == rows

    def test_dataclass_mapping(self):
        rows = [
            {"ID": 1, "NAME": "Alice", "STATUS": "active"},
            {"ID": 2, "NAME": "Bob", "STATUS": "inactive"},
        ]
        result = map_rows(rows, User)
        assert len(result) == 2
        assert all(isinstance(r, User) for r in result)
        assert result[0].NAME == "Alice"
        assert result[1].NAME == "Bob"

    def test_empty_list(self):
        assert map_rows([], User) == []
