"""Tests for type coercion."""

from datetime import date, datetime, time
from decimal import Decimal

from snowflake_rest.types import build_coercion_map, coerce_row


def _make_row_type(sf_type, scale=0):
    return {"name": "COL", "type": sf_type, "scale": scale}


class TestBuildCoercionMap:
    def test_fixed_int(self):
        coercers = build_coercion_map([_make_row_type("FIXED", scale=0)])
        assert coercers[0]("42") == 42

    def test_fixed_decimal(self):
        coercers = build_coercion_map([_make_row_type("FIXED", scale=2)])
        result = coercers[0]("99.50")
        assert result == Decimal("99.50")
        assert isinstance(result, Decimal)

    def test_real(self):
        coercers = build_coercion_map([_make_row_type("REAL")])
        assert coercers[0]("3.14") == 3.14

    def test_float(self):
        coercers = build_coercion_map([_make_row_type("FLOAT")])
        assert coercers[0]("3.14") == 3.14

    def test_boolean_true(self):
        coercers = build_coercion_map([_make_row_type("BOOLEAN")])
        assert coercers[0]("true") is True
        assert coercers[0]("1") is True

    def test_boolean_false(self):
        coercers = build_coercion_map([_make_row_type("BOOLEAN")])
        assert coercers[0]("false") is False
        assert coercers[0]("0") is False

    def test_timestamp_ntz(self):
        coercers = build_coercion_map([_make_row_type("TIMESTAMP_NTZ")])
        result = coercers[0]("2026-04-03T12:00:00.000")
        assert isinstance(result, datetime)
        assert result.year == 2026

    def test_timestamp_with_space(self):
        coercers = build_coercion_map([_make_row_type("TIMESTAMP_NTZ")])
        result = coercers[0]("2026-04-03 12:00:00.000")
        assert isinstance(result, datetime)

    def test_date(self):
        coercers = build_coercion_map([_make_row_type("DATE")])
        result = coercers[0]("2026-04-03")
        assert result == date(2026, 4, 3)

    def test_time(self):
        coercers = build_coercion_map([_make_row_type("TIME")])
        result = coercers[0]("12:30:45.000")
        assert isinstance(result, time)
        assert result.hour == 12

    def test_variant_json(self):
        coercers = build_coercion_map([_make_row_type("VARIANT")])
        result = coercers[0]('{"key": "val"}')
        assert result == {"key": "val"}

    def test_array_json(self):
        coercers = build_coercion_map([_make_row_type("ARRAY")])
        result = coercers[0]("[1, 2, 3]")
        assert result == [1, 2, 3]

    def test_text_no_conversion(self):
        coercers = build_coercion_map([_make_row_type("TEXT")])
        assert coercers[0] is None

    def test_null_handling(self):
        coercers = build_coercion_map([_make_row_type("FIXED", scale=0)])
        assert coercers[0](None) is None


class TestCoerceRow:
    def test_basic_coercion(self):
        row_types = [
            _make_row_type("FIXED", scale=0),
            _make_row_type("TEXT"),
            _make_row_type("BOOLEAN"),
        ]
        coercers = build_coercion_map(row_types)
        row = ["42", "hello", "true"]
        result = coerce_row(row, coercers)
        assert result == [42, "hello", True]

    def test_null_in_row(self):
        coercers = build_coercion_map([_make_row_type("FIXED", scale=0)])
        assert coerce_row([None], coercers) == [None]

    def test_coercion_failure_returns_original(self):
        coercers = build_coercion_map([_make_row_type("FIXED", scale=0)])
        result = coerce_row(["not_a_number"], coercers)
        assert result == ["not_a_number"]
