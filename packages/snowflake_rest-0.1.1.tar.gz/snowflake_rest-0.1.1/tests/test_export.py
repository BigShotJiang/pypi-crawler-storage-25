"""Tests for export (COPY INTO) functionality."""

import json

import responses

from tests.test_client import _make_client, BASE_URL
from snowflake_rest.client import ExportResult


class TestExport:
    @responses.activate
    def test_basic_export(self):
        """export() sends COPY INTO and returns ExportResult."""
        copy_resp = {
            "resultSetMetaData": {"rowType": [], "numRows": 1},
            "data": [["5000", "report.csv.gz", "102400"]],
            "statementHandle": "export-h-123",
        }
        responses.add(responses.POST, BASE_URL, json=copy_resp, status=200)

        client = _make_client()
        result = client.export(
            sql="SELECT * FROM users",
            stage="@MY_STAGE",
            path="exports/2026/",
        )

        assert isinstance(result, ExportResult)
        assert result.rows_unloaded == 5000
        assert result.path.startswith("@MY_STAGE/exports/2026/")
        assert result.path.endswith(".csv.gz")

        # Verify the SQL sent
        body = json.loads(responses.calls[0].request.body)
        sql = body["statement"]
        assert "COPY INTO" in sql
        assert "@MY_STAGE" in sql
        assert "COMPRESSION=GZIP" in sql
        assert "HEADER=TRUE" in sql

    @responses.activate
    def test_export_with_params(self):
        """export() substitutes params into the inner query."""
        copy_resp = {
            "resultSetMetaData": {"rowType": [], "numRows": 1},
            "data": [["100", "f.csv.gz", "1024"]],
            "statementHandle": "h-1",
        }
        responses.add(responses.POST, BASE_URL, json=copy_resp, status=200)

        client = _make_client()
        result = client.export(
            sql="SELECT * FROM users WHERE id = ?",
            params=[42],
            stage="@STG",
            path="out/",
        )

        body = json.loads(responses.calls[0].request.body)
        sql = body["statement"]
        # The param should be substituted (not as a binding)
        assert "42" in sql
        assert "?" not in sql

    @responses.activate
    def test_export_custom_filename(self):
        """export() uses provided filename."""
        copy_resp = {
            "resultSetMetaData": {"rowType": [], "numRows": 1},
            "data": [["10", "my_report.csv.gz", "500"]],
            "statementHandle": "h-1",
        }
        responses.add(responses.POST, BASE_URL, json=copy_resp, status=200)

        client = _make_client()
        result = client.export(
            sql="SELECT 1",
            stage="@STG",
            path="out/",
            filename="my_report.csv.gz",
        )

        assert "my_report.csv.gz" in result.path

    @responses.activate
    def test_export_no_header(self):
        """export() respects header=False."""
        copy_resp = {
            "resultSetMetaData": {"rowType": [], "numRows": 1},
            "data": [["10", "f.csv.gz", "500"]],
            "statementHandle": "h-1",
        }
        responses.add(responses.POST, BASE_URL, json=copy_resp, status=200)

        client = _make_client()
        client.export(
            sql="SELECT 1", stage="@STG", path="out/", header=False
        )

        body = json.loads(responses.calls[0].request.body)
        assert "HEADER=FALSE" in body["statement"]

    @responses.activate
    def test_export_async(self):
        """export(async_exec=True) returns a QueryHandle."""
        from snowflake_rest.client import QueryHandle

        async_resp = {
            "statementHandle": "async-export-h",
            "statementStatusUrl": "/api/v2/statements/async-export-h",
        }
        responses.add(responses.POST, BASE_URL, json=async_resp, status=202)

        client = _make_client()
        handle = client.export(
            sql="SELECT 1", stage="@STG", path="out/", async_exec=True
        )

        assert isinstance(handle, QueryHandle)
        assert handle.handle_id == "async-export-h"


class TestExportResult:
    def test_repr(self):
        r = ExportResult(rows_unloaded=100, file_size=5000, path="@STG/out/f.csv.gz")
        s = repr(r)
        assert "100" in s
        assert "5000" in s
        assert "@STG/out/f.csv.gz" in s
