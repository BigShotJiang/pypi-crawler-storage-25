"""Tests for async query submission, polling, and QueryHandle."""

import json

import responses
import pytest

from tests.test_client import _make_client, _snowflake_response, BASE_URL
from snowflake_rest.exceptions import QueryError, TimeoutError


class TestSubmit:
    @responses.activate
    def test_submit_returns_handle(self):
        """submit() returns a QueryHandle with the statement handle."""
        async_resp = {
            "statementHandle": "async-handle-123",
            "statementStatusUrl": "/api/v2/statements/async-handle-123",
        }
        responses.add(responses.POST, BASE_URL, json=async_resp, status=202)

        client = _make_client()
        handle = client.submit("SELECT * FROM big_table")

        assert handle.handle_id == "async-handle-123"
        # Verify async header was sent
        headers = responses.calls[0].request.headers
        assert headers.get("X-Snowflake-Async") == "true"

    @responses.activate
    def test_submit_no_handle_raises(self):
        """submit() raises QueryError if no handle returned."""
        responses.add(responses.POST, BASE_URL, json={}, status=200)

        client = _make_client()
        with pytest.raises(QueryError, match="statement handle"):
            client.submit("SELECT 1")


class TestQueryHandle:
    @responses.activate
    def test_status_running(self):
        """status() returns 'running' on 202."""
        async_resp = {
            "statementHandle": "h-123",
            "statementStatusUrl": "/api/v2/statements/h-123",
        }
        responses.add(responses.POST, BASE_URL, json=async_resp, status=202)

        status_url = f"{BASE_URL}/h-123"
        responses.add(responses.GET, status_url, json={}, status=202)

        client = _make_client()
        handle = client.submit("SELECT 1")
        assert handle.status() == "running"

    @responses.activate
    def test_status_complete(self):
        """status() returns 'complete' when data is present."""
        async_resp = {
            "statementHandle": "h-123",
            "statementStatusUrl": "/api/v2/statements/h-123",
        }
        responses.add(responses.POST, BASE_URL, json=async_resp, status=202)

        complete_resp = _snowflake_response(
            columns=[("ID", "FIXED", 0)],
            rows=[["1"]],
            handle="h-123",
        )
        complete_resp["code"] = "090001"
        status_url = f"{BASE_URL}/h-123"
        responses.add(responses.GET, status_url, json=complete_resp, status=200)

        client = _make_client()
        handle = client.submit("SELECT 1")
        assert handle.status() == "complete"

    @responses.activate
    def test_status_failed(self):
        """status() returns 'failed' on error codes."""
        async_resp = {
            "statementHandle": "h-123",
            "statementStatusUrl": "/api/v2/statements/h-123",
        }
        responses.add(responses.POST, BASE_URL, json=async_resp, status=202)

        status_url = f"{BASE_URL}/h-123"
        responses.add(
            responses.GET,
            status_url,
            json={"code": "002003", "message": "SQL error"},
            status=200,
        )

        client = _make_client()
        handle = client.submit("SELECT 1")
        assert handle.status() == "failed"

    @responses.activate
    def test_result_polls_until_complete(self):
        """result() polls until query completes."""
        async_resp = {
            "statementHandle": "h-123",
            "statementStatusUrl": "/api/v2/statements/h-123",
        }
        responses.add(responses.POST, BASE_URL, json=async_resp, status=202)

        status_url = f"{BASE_URL}/h-123"
        # First poll: still running
        responses.add(responses.GET, status_url, json={}, status=202)
        # Second poll: complete
        complete_resp = _snowflake_response(
            columns=[("ID", "FIXED", 0)],
            rows=[["42"]],
            handle="h-123",
        )
        complete_resp["code"] = "090001"
        responses.add(responses.GET, status_url, json=complete_resp, status=200)
        # Third GET: fetch final result
        responses.add(responses.GET, status_url, json=complete_resp, status=200)

        client = _make_client(poll_interval=0.01, max_poll_time=5)
        handle = client.submit("SELECT 1")
        rows = handle.result()
        assert rows[0]["ID"] == 42

    @responses.activate
    def test_result_timeout(self):
        """result() raises TimeoutError when max_poll_time exceeded."""
        async_resp = {
            "statementHandle": "h-123",
            "statementStatusUrl": "/api/v2/statements/h-123",
        }
        responses.add(responses.POST, BASE_URL, json=async_resp, status=202)

        status_url = f"{BASE_URL}/h-123"
        # Always running
        for _ in range(50):
            responses.add(responses.GET, status_url, json={}, status=202)

        client = _make_client(poll_interval=0.01, max_poll_time=0.05)
        handle = client.submit("SELECT 1")
        with pytest.raises(TimeoutError):
            handle.result()

    @responses.activate
    def test_cancel(self):
        """cancel() sends POST to cancel endpoint."""
        async_resp = {
            "statementHandle": "h-123",
            "statementStatusUrl": "/api/v2/statements/h-123",
        }
        responses.add(responses.POST, BASE_URL, json=async_resp, status=202)

        cancel_url = f"{BASE_URL}/h-123/cancel"
        responses.add(responses.POST, cancel_url, json={}, status=200)

        client = _make_client()
        handle = client.submit("SELECT 1")
        handle.cancel()

        assert responses.calls[1].request.url == cancel_url


class TestAutoPromotedAsync:
    @responses.activate
    def test_sync_query_auto_promoted_to_async(self):
        """A sync query that gets 202 should be polled automatically."""
        # First call returns 202 (auto-promoted)
        async_resp = {
            "statementHandle": "auto-h-456",
            "statementStatusUrl": "/api/v2/statements/auto-h-456",
        }
        responses.add(responses.POST, BASE_URL, json=async_resp, status=202)

        # Poll returns completed result
        complete_resp = _snowflake_response(
            columns=[("VAL", "TEXT")],
            rows=[["hello"]],
            handle="auto-h-456",
        )
        poll_url = f"https://testorg-testaccount.snowflakecomputing.com/api/v2/statements/auto-h-456"
        responses.add(responses.GET, poll_url, json=complete_resp, status=200)

        client = _make_client(poll_interval=0.01)
        rows = client.query("SELECT 'hello' AS VAL")
        assert rows[0]["VAL"] == "hello"
