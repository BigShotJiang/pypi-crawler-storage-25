"""Tests for bindings module."""

import json
from datetime import date, datetime
from decimal import Decimal

from snowflake_rest.bindings import format_bindings


def test_format_bindings_none():
    assert format_bindings(None) is None
    assert format_bindings([]) is None


def test_format_bindings_string():
    result = format_bindings(["hello"])
    assert result == {"1": {"type": "TEXT", "value": "hello"}}


def test_format_bindings_int():
    result = format_bindings([42])
    assert result == {"1": {"type": "FIXED", "value": "42"}}


def test_format_bindings_float():
    result = format_bindings([3.14])
    assert result == {"1": {"type": "REAL", "value": "3.14"}}


def test_format_bindings_bool():
    result = format_bindings([True, False])
    assert result == {
        "1": {"type": "BOOLEAN", "value": "true"},
        "2": {"type": "BOOLEAN", "value": "false"},
    }


def test_format_bindings_none_value():
    result = format_bindings([None])
    assert result == {"1": {"type": "TEXT", "value": None}}


def test_format_bindings_decimal():
    result = format_bindings([Decimal("99.50")])
    assert result == {"1": {"type": "FIXED", "value": "99.50"}}


def test_format_bindings_datetime():
    dt = datetime(2026, 4, 3, 12, 0, 0)
    result = format_bindings([dt])
    assert result["1"]["type"] == "TIMESTAMP"
    assert "2026-04-03" in result["1"]["value"]


def test_format_bindings_date():
    d = date(2026, 4, 3)
    result = format_bindings([d])
    assert result == {"1": {"type": "DATE", "value": "2026-04-03"}}


def test_format_bindings_list():
    result = format_bindings([[1, 2, 3]])
    assert result["1"]["type"] == "TEXT"
    assert json.loads(result["1"]["value"]) == [1, 2, 3]


def test_format_bindings_mixed():
    result = format_bindings([42, "active", True])
    assert result["1"] == {"type": "FIXED", "value": "42"}
    assert result["2"] == {"type": "TEXT", "value": "active"}
    assert result["3"] == {"type": "BOOLEAN", "value": "true"}
