# webos-ctl

CLI tool to control LG Smart TVs from your laptop.

## Requirements

- Python 3.12+
- [arp-scan](https://github.com/royhills/arp-scan) (install via your package manager)
- Root privileges

## Installation

```bash
pip install webos-ctl
# or
uv add webos-ctl
```

Or from source:

```bash
git clone https://github.com/MarkLevkovich/webos-ctl.git
cd webos-ctl
pip install -e .
```

## Usage

```bash
sudo webos-ctl
```

### Features

1. **Add TV** - Scan local network for LG devices and register a new TV
2. **Select TV** - Choose from saved TVs and control it

TV credentials are stored in `~/.webos_ctl_store.json`.

## License

MIT