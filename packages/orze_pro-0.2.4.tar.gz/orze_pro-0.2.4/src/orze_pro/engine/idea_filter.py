"""Inline Tier 1 idea filter for the orchestration loop.

CALLING SPEC:
    filter_queued_ideas(results_dir) -> int
        Run Tier 1 rule-based filtering on all queued ideas in the lake.
        Returns the number of ideas filtered (set to 'skipped').

    tier1_check(idea_id, config, completed_fingerprints, known_keys) -> str | None
        Check a single idea against Tier 1 rules.
        Returns rejection reason or None.

This module is designed to be called INLINE during idea ingestion
(phases.py _sync_ideas), not on a periodic FSM cycle. This prevents
garbage ideas from being claimed and starting GPU training before
the next FSM tick.

The same logic lives in fsm/plugins/idea_verifier.py for the FSM-based
path, but this module avoids the fsm.engine dependency so it can be
imported directly by orze core via extensions.
"""

from __future__ import annotations

import hashlib
import json
import logging
import sqlite3
import time
from pathlib import Path
from typing import Optional, Set

logger = logging.getLogger("orze.idea_filter")


# These are absolute — confirmed dead in RESEARCH_RULES.md
PROVEN_DEAD = [
    {"share_norms": True, "share_ln_f": True},   # share all 3 norms = always 0%
    {"tie_gate": True},                            # gate=up in SwiGLU = always 0%
    {"d_model": 2, "head_dim": 2},                # untrainable at any param count
]


def _config_fingerprint(config: dict) -> str:
    """Full config hash INCLUDING seed — only exact duplicates match."""
    cfg = {k: v for k, v in sorted(config.items())}
    return hashlib.md5(json.dumps(cfg, sort_keys=True).encode()).hexdigest()[:16]


def _has_novel_keys(config: dict, known_keys: set) -> bool:
    """True if config has keys not seen in any completed experiment."""
    return bool(set(config.keys()) - known_keys)


def tier1_check(idea_id: str, config: dict,
                completed_fingerprints: Set[str],
                known_keys: Set[str]) -> Optional[str]:
    """Returns rejection reason or None. ONLY rejects certainties.

    - Rejects proven-dead configs (structurally broken, regardless of novel keys)
    - Rejects exact duplicates (same config + same seed)
    - NEVER rejects ideas with novel config keys for the duplicate check
    """
    # Reject proven-dead configs FIRST — structurally broken regardless
    # of novel keys (share_all_norms, tie_gate, d=2/hd=2)
    for dead in PROVEN_DEAD:
        if all(config.get(k) == v for k, v in dead.items()):
            return f"proven dead: {dead}"

    # Novel keys protect against over-filtering "similar" ideas
    # but not against proven-dead patterns (handled above)
    if _has_novel_keys(config, known_keys):
        return None

    # Reject exact duplicates (same config + same seed)
    fp = _config_fingerprint(config)
    if fp in completed_fingerprints:
        return f"exact duplicate (fingerprint {fp})"

    return None


def filter_queued_ideas(results_dir: Path) -> int:
    """Run Tier 1 filtering on all queued ideas in the lake.

    Args:
        results_dir: Path to the results directory

    Returns:
        Number of ideas filtered (set to 'skipped').
    """
    import yaml

    lake_path = results_dir.parent / "idea_lake.db"
    if not lake_path.exists():
        lake_path = results_dir / "idea_lake.db"
    if not lake_path.exists():
        return 0

    try:
        conn = sqlite3.connect(str(lake_path), timeout=5)
    except Exception:
        return 0

    # Build completed fingerprints and known keys
    completed_fingerprints: Set[str] = set()
    known_keys: Set[str] = set()
    try:
        rows = conn.execute(
            "SELECT config FROM ideas WHERE status = 'completed'"
        ).fetchall()
        for (config_str,) in rows:
            if not config_str:
                continue
            try:
                config = yaml.safe_load(config_str)
                if isinstance(config, dict):
                    completed_fingerprints.add(_config_fingerprint(config))
                    known_keys.update(config.keys())
            except Exception:
                continue
    except Exception:
        conn.close()
        return 0

    # Check queued ideas
    try:
        rows = conn.execute(
            "SELECT idea_id, config FROM ideas WHERE status = 'queued'"
        ).fetchall()
    except Exception:
        conn.close()
        return 0

    filtered = 0
    for idea_id, config_str in rows:
        if not config_str:
            continue
        try:
            config = yaml.safe_load(config_str)
            if not isinstance(config, dict):
                continue
        except Exception:
            continue

        reason = tier1_check(idea_id, config, completed_fingerprints, known_keys)
        if reason:
            try:
                conn.execute(
                    "UPDATE ideas SET status = 'skipped' WHERE idea_id = ?",
                    (idea_id,))
                idea_dir = results_dir / idea_id
                idea_dir.mkdir(exist_ok=True)
                (idea_dir / "metrics.json").write_text(json.dumps({
                    "status": "SKIPPED",
                    "skip_reason": reason,
                    "skipped_by": "tier1_inline",
                    "time": time.strftime("%Y-%m-%dT%H:%M:%S"),
                }, indent=2), encoding="utf-8")
                filtered += 1
                logger.info("Tier1 inline filter %s: %s", idea_id, reason)
            except Exception as e:
                logger.error("Failed to filter %s: %s", idea_id, e)

    if filtered > 0:
        try:
            conn.commit()
        except Exception:
            pass

    try:
        conn.close()
    except Exception:
        pass

    if filtered > 0:
        logger.info("Tier1 inline: filtered %d exact duplicates/dead configs",
                     filtered)

    return filtered
