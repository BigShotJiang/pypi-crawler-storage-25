"""Convert PDF to structured text using MistralOCR"""

__version__ = "1.6.44"
