"""Unit tests for the downmixer.providers module (base classes and protocols)."""

from typing import Protocol
from unittest.mock import MagicMock

import pytest

from downmixer.providers import (
    BaseProvider,
    list_protocols,
)
from downmixer.providers.connections import Connection
from downmixer.providers.protocols import (
    SupportsLibrary,
    SupportsMetadata,
)
from downmixer.types.library import ResourceType


class MockConnection(Connection):
    """Mock connection for testing BaseProvider."""

    _default_options = {"mock_option": "mock_value"}
    _initialized = True

    def initialize(self) -> bool:
        self._initialized = True
        return True

    def check_valid_url(self, url: str, type_filter=None) -> bool:
        return True

    def get_resource_type(self, value: str) -> ResourceType | None:
        return ResourceType.SONG


class TestBaseProvider:
    """Tests for the BaseProvider class."""

    def test_init_with_connection(self):
        """Test BaseProvider initialization with a connection."""
        conn = MockConnection()
        provider = BaseProvider(connection=conn)
        assert provider.connection == conn
        assert provider.client == conn.client

    def test_init_with_options(self):
        """Test BaseProvider initialization with custom options."""
        conn = MockConnection()
        provider = BaseProvider(connection=conn, options={"custom": "option"})
        assert provider.options["custom"] == "option"

    def test_init_with_logger(self):
        """Test BaseProvider initialization with custom logger."""
        conn = MockConnection()
        mock_logger = MagicMock()
        provider = BaseProvider(connection=conn, logger=mock_logger)
        assert provider.logger == mock_logger

    def test_name_property(self):
        """Test that name property returns _name."""

        class NamedProvider(BaseProvider):
            _name = "test_provider"

        conn = MockConnection()
        provider = NamedProvider(connection=conn)
        assert provider.name == "test_provider"

    def test_pretty_name_property(self):
        """Test that pretty_name property returns _pretty_name."""

        class NamedProvider(BaseProvider):
            _name = "test"
            _pretty_name = "Test Provider"

        conn = MockConnection()
        provider = NamedProvider(connection=conn)
        assert provider.pretty_name == "Test Provider"

    def test_name_with_whitespace_raises_error(self):
        """Test that a name with whitespace raises ValueError."""

        class BadProvider(BaseProvider):
            _name = "bad provider"

        conn = MockConnection()
        with pytest.raises(ValueError) as exc_info:
            BadProvider(connection=conn)

        assert "whitespace" in str(exc_info.value).lower()

    def test_name_with_spaces_raises_error(self):
        """Test various whitespace characters in name raise ValueError."""

        class TabProvider(BaseProvider):
            _name = "bad\tprovider"

        class NewlineProvider(BaseProvider):
            _name = "bad\nprovider"

        conn = MockConnection()

        with pytest.raises(ValueError):
            TabProvider(connection=conn)

        with pytest.raises(ValueError):
            NewlineProvider(connection=conn)

    def test_empty_name_is_valid(self):
        """Test that an empty name is valid (no whitespace)."""

        class EmptyNameProvider(BaseProvider):
            _name = ""

        conn = MockConnection()
        # Should not raise
        provider = EmptyNameProvider(connection=conn)
        assert provider.name == ""

    def test_options_merge_with_defaults(self):
        """Test that options are merged with default options."""

        class OptionsProvider(BaseProvider):
            _name = "options"
            _default_options = {"default": "value", "shared": "default"}

        conn = MockConnection()
        provider = OptionsProvider(
            connection=conn, options={"custom": "value", "shared": "custom"}
        )

        # Default options have priority
        assert provider.options["default"] == "value"
        assert provider.options["shared"] == "default"  # default wins
        assert provider.options["custom"] == "value"


class TestListProtocols:
    """Tests for the list_protocols() function."""

    def test_returns_list(self):
        """Test that list_protocols returns a list."""
        result = list_protocols()
        assert isinstance(result, list)

    def test_returns_protocol_classes(self):
        """Test that list_protocols returns Protocol subclasses."""
        result = list_protocols()
        for protocol_cls in result:
            assert isinstance(protocol_cls, type)
            assert issubclass(protocol_cls, Protocol)

    def test_excludes_base_protocol(self):
        """Test that the base Protocol class is excluded."""
        result = list_protocols()
        assert Protocol not in result

    def test_includes_supports_metadata(self):
        """Test that SupportsMetadata is included."""
        result = list_protocols()
        assert SupportsMetadata in result

    def test_includes_supports_library(self):
        """Test that SupportsLibrary is included."""
        result = list_protocols()
        assert SupportsLibrary in result

    def test_returns_expected_count(self):
        """Test that the expected number of protocols is returned."""
        result = list_protocols()
        assert len(result) == 2
