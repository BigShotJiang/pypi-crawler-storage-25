---
hide:
  - navigation
---

# Home


## Getting started

For a complete introduction to using Downmixer, see the [Usage guide](usage.md).

Downmixer is a Python library providing the core framework for bridging streaming music services. It handles music
metadata types, provider architecture, and fuzzy matching — the building blocks for tools that discover and
cross-reference music across platforms.

These modules are:

- `matching` - Fuzzy matching between songs from different providers
- `providers` - Protocol-based provider system (see [providers page](providers/index.md))
- `types` - Data type definitions (Song, Album, Artist, Playlist, SearchResult)
- `log` - Logging infrastructure with colored formatters
- `utils` - Utility functions used across the library

These packages are designed to be independent and composable — implement them in your application however best fits your
needs.

## Commands

Downmixer is a library and cannot be used as a program with a CLI. Please write your own Python scripts or build your
own tools on top of it.
