import json
import os
import re
import subprocess


def run_cmd(command: str) -> str:
    result = subprocess.run(command.split(" "), capture_output=True, text=True)
    return result.stdout


def parse_version(version_str):
    """
    Parses a version string into a comparable tuple that handles
    integers and basic pre-release strings correctly.
    """
    # Split by dots, and also split numeric from non-numeric parts within segments
    parts = re.split(r"(\d+)", version_str)
    version_tuple = []
    for part in parts:
        if part:
            try:
                version_tuple.append(int(part))
            except ValueError:
                # Handle non-integer parts (e.g., 'a', 'rc', 'post')
                version_tuple.append(part)
    return tuple(version_tuple)


def is_newer(new: str, old: str) -> bool:
    new_parsed = parse_version(new)
    old_parsed = parse_version(old)
    return new_parsed > old_parsed


print(f"Working directory: {os.getcwd()}")

raw = run_cmd("pip index versions downmixer --pre --json")
latest: str = json.loads(raw).get("latest")
current = run_cmd("uv version --short")

newer = is_newer(current, latest)
print(
    f"Latest version: {latest}\nCurrent version: {current}\nIs newer? {'yes' if newer else 'no'}"
)
exit(0 if newer else 1)
