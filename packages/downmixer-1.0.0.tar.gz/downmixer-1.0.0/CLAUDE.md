# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Commands

```bash
# Install dependencies
uv sync

# Run all tests
uv run pytest tests/ --cov=. --cov-report=html --force-sugar

# Run a single test file
uv run pytest tests/test_matching.py

# Run tests across all supported Python versions
tox

# Build the package
uv build

# Build and deploy documentation
uv run mkdocs gh-deploy -b pages

# Check version consistency with PyPI before publishing
python check_version.py
```

## Architecture

Downmixer is a Python library for bridging streaming music services. It discovers and downloads music metadata and audio from Spotify, YouTube Music, and Qobuz, with fuzzy matching across platforms.

### Provider System

The core is a **protocol-based capability system** — providers don't use multi-level inheritance; they implement Python Protocols from `src/downmixer/providers/protocols.py`:

- `SupportsMetadata` — search and fetch songs/albums/artists/playlists/users
- `SupportsAudioDownload` — download audio files
- `SupportsLibrary` — access a user's saved content
- `SupportsLyrics` — fetch lyrics

All providers inherit `BaseProvider` (`src/downmixer/providers/__init__.py`) and have a companion `Connection` or `AuthenticatedConnection` subclass that handles initialization and auth separately from the provider logic.

Provider discovery is automatic via `list_providers()` / `get_provider_info()`.

### Type System (`src/downmixer/types/`)

Core types use dataclasses with `from_provider()` factory methods for normalization:
- `Song`, `Album`, `Artist`, `Playlist`, `User` — metadata types in `library.py`
- `LocalFile` — a downloaded file with codec, container, bitrate; auto-calculates match quality
- `SearchResult[T]` — generic wrapper that tracks provider origin and optional match score
- `ResourceType`, `AlbumType` — enumerations

### Matching (`src/downmixer/matching/`)

Uses **RapidFuzz** for fuzzy string comparison. `match(song_a, song_b)` returns a `MatchResult` with per-field scores (name, artists, album, duration). Duration uses a custom ease curve `y = 1 - (f * x²)`. `MatchQuality` thresholds: PERFECT=500, GREAT=475, GOOD=400, MEDIOCRE=300.

### File Tools (`src/downmixer/file_tools/`)

- `Converter` — async FFmpeg wrapper for transcoding audio; supports `Codec` (FLAC, MP3, OPUS, VORBIS, AAC_HE, AAC_LC) and `Container` enums
- `tag.py` — audio metadata tagging via mutagen

### Implemented Providers

| Provider | Location | Protocols |
|---|---|---|
| Spotify | `providers/spotify/` | Metadata, Library |
| Qobuz | `providers/qobuz/` | Metadata, Library, AudioDownload (lossless) |
| YouTube Music | `providers/yt_music/` | Metadata, Library, AudioDownload |

Each provider directory contains the main provider class, a connection class, and a `library.py` with provider-specific adapter types.

### CI/CD

Forgejo workflows in `.forgejo/workflows/`:
- `docs.yml` — deploys MkDocs docs to `pages` branch on push to main
- `publish.yml` — runs `check_version.py`, tests, builds, and publishes to PyPI on release
