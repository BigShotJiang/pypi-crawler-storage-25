# Plan: Changelog Command

## Problem
Users who run `pipx upgrade psamvault` have no way to know what changed.
`pipx upgrade` has no post-install hook mechanism, so the CLI must detect
the upgrade itself on the next run and surface the changelog proactively.

## Approach
1. Hardcode changelog entries in a new `changelog.py` module.
2. Persist the "last seen version" in `~/.psamvault/last_seen_version`.
3. On every CLI startup, compare installed version vs last-seen — if newer,
   auto-print the new entries once, then update the stored version.
4. Add a `psamvault changelog` command so users can re-read it on demand.

## Files

| File | Action | Purpose |
|---|---|---|
| `changelog.py` | Create | Version → change entries dict + display helpers |
| `command/changelog_command.py` | Create | `psamvault changelog` command |
| `session.py` | Edit | Add `get_last_seen_version()` / `set_last_seen_version()` |
| `main.py` | Edit | Hook upgrade detection at startup + register command |

## Todos

1. **changelog-data** — Create `changelog.py` with hardcoded version history and a `format_changelog()` display helper.
2. **session-version-state** — Add `get_last_seen_version()` and `set_last_seen_version()` to `session.py` using `~/.psamvault/last_seen_version`.
3. **upgrade-detection** — Add `check_and_show_upgrade_notice()` to `changelog.py`; called in `main.py`'s `_main` callback after `start_update_check()`. Shows only the entries for versions newer than last-seen, then updates the stored version.
4. **changelog-command** — Create `command/changelog_command.py` with a `psamvault changelog` command that prints the full history. Register it in `main.py`.

## Behaviour Details

### Auto-show (upgrade detection)
- Reads `~/.psamvault/last_seen_version` (missing = first ever run, treated as "no previous version")
- Compares against current installed version (via `importlib.metadata`)
- If newer: prints only entries for versions > last_seen, then updates the file
- Shown **before** the actual command output so it's noticed immediately
- Silently skips if version detection or file I/O fails

### `psamvault changelog` command
- Prints all versions in reverse order (newest first)
- Each version block: version header + bullet list of changes

### Changelog entry format
```python
CHANGELOG = {
    "0.2.3": [
        "Fixed: first-run token rotation bug in psamvault list, update, and ak-update",
    ],
    "0.2.2": [...],
    ...
}
```

## Notes
- No network calls — fully offline
- Graceful: any file I/O error is silently swallowed
- The auto-show path must not block or crash any command
