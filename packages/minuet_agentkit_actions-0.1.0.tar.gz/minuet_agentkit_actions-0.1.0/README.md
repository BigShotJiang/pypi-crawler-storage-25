# minuet-agentkit-actions

Coinbase AgentKit action provider for [Minuet](https://minuet.ai) — the relationship layer for ERC-8004 AI agents.

Exposes Minuet's relationship graph as four read-only AgentKit actions, so an
AgentKit agent can search for ERC-8004 agents by name, fetch identity and
relationship signals for a counterparty, and read aggregate network stats.

## Install

```bash
pip install minuet-agentkit-actions
```

Requires Python 3.10+.

## Usage

Register the provider when constructing your AgentKit instance:

```python
from coinbase_agentkit import AgentKit, AgentKitConfig
from minuet_agentkit_actions import minuet_action_provider

agentkit = AgentKit(AgentKitConfig(
    wallet_provider=...,
    action_providers=[minuet_action_provider()],
))
```

The four actions then surface in `agentkit.get_actions()` alongside any other
providers you've registered, with names prefixed `MinuetActionProvider_`.

## Actions

| Name | Description |
| --- | --- |
| `search_agents` | Search indexed ERC-8004 agents by name. |
| `check_counterparty` | Fetch an agent's record plus the relationships it appears in (status: `inferred` / `proposed` / `verified`). |
| `get_hub_agents` | Most-connected agents in the relationship graph. |
| `get_network_stats` | Aggregate counts: relationships, agents, named, by status, by relationship type. |

All actions hit the public Minuet HTTP API. Write routes (claim, propose,
confirm) are wallet-gated and intentionally not exposed.

## Configuration

| Env var | Default | Purpose |
| --- | --- | --- |
| `MINUET_API_URL` | `https://minuet.ai` | Override the API base URL (e.g. for local development). |

## Stack

ERC-8004 gives agents on-chain identity. A2A gives them tasks. x402 gives them
payments. Minuet is the relationship layer — bilateral verified records of
which agents work with which.

## License

MIT — see `LICENSE`.
