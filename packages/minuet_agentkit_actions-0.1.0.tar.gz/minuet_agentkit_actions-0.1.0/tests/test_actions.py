"""Tests for action provider behaviour with mocked HTTP responses."""

from __future__ import annotations

import json

import httpx
import respx

from minuet_agentkit_actions import minuet_action_provider


@respx.mock
def test_search_agents_happy_path() -> None:
    respx.get("https://minuet.ai/api/agents").mock(
        return_value=httpx.Response(
            200,
            json={"agents": [{"id": "1:1", "name": "alice"}, {"id": "1:2", "name": "alfred"}]},
        )
    )
    provider = minuet_action_provider()
    raw = provider.search_agents({"query": "al", "limit": 25})
    parsed = json.loads(raw)
    assert parsed["success"] is True
    assert parsed["count"] == 2
    assert parsed["agents"][0]["name"] == "alice"


@respx.mock
def test_search_agents_handles_http_error() -> None:
    respx.get("https://minuet.ai/api/agents").mock(
        return_value=httpx.Response(500, json={"error": "boom"})
    )
    provider = minuet_action_provider()
    raw = provider.search_agents({"query": "al"})
    parsed = json.loads(raw)
    assert parsed["success"] is False
    assert "error" in parsed


@respx.mock
def test_check_counterparty_aggregates_status() -> None:
    respx.get("https://minuet.ai/api/agent/1:6817").mock(
        return_value=httpx.Response(200, json={"id": "1:6817", "name": "bob"})
    )
    respx.get("https://minuet.ai/api/agent/1:6817/relationships").mock(
        return_value=httpx.Response(
            200,
            json={
                "relationships": [
                    {"id": 1, "status": "inferred"},
                    {"id": 2, "status": "inferred"},
                    {"id": 3, "status": "verified"},
                ]
            },
        )
    )
    provider = minuet_action_provider()
    raw = provider.check_counterparty({"agent_id": "1:6817"})
    parsed = json.loads(raw)
    assert parsed["success"] is True
    assert parsed["agent"]["name"] == "bob"
    assert parsed["relationship_count"] == 3
    assert parsed["status_breakdown"] == {"inferred": 2, "verified": 1}


@respx.mock
def test_get_hub_agents() -> None:
    respx.get("https://minuet.ai/api/relationships/clusters").mock(
        return_value=httpx.Response(
            200,
            json={"hubs": [{"id": "1:1", "connection_count": 5}], "ecosystems": [], "stats": {}},
        )
    )
    provider = minuet_action_provider()
    raw = provider.get_hub_agents({"limit": 10})
    parsed = json.loads(raw)
    assert parsed["success"] is True
    assert parsed["count"] == 1
    assert parsed["hubs"][0]["connection_count"] == 5


@respx.mock
def test_get_network_stats_merges_counts() -> None:
    respx.get("https://minuet.ai/api/relationships/clusters").mock(
        return_value=httpx.Response(
            200, json={"stats": {"total_relationships": 232, "named_agents": 186}}
        )
    )
    respx.get("https://minuet.ai/api/relationships").mock(
        return_value=httpx.Response(
            200,
            json={
                "relationships": [
                    {"status": "inferred", "relationship_type": "can_send_message_to"},
                    {"status": "inferred", "relationship_type": "can_send_message_to"},
                    {"status": "verified", "relationship_type": "collaborates_with"},
                ]
            },
        )
    )
    provider = minuet_action_provider()
    raw = provider.get_network_stats({})
    parsed = json.loads(raw)
    assert parsed["success"] is True
    stats = parsed["stats"]
    assert stats["total_relationships"] == 232
    assert stats["by_status"] == {"inferred": 2, "verified": 1}
    assert stats["by_relationship_type"] == {
        "can_send_message_to": 2,
        "collaborates_with": 1,
    }


def test_invalid_args_return_error() -> None:
    provider = minuet_action_provider()
    # Missing required `agent_id` should validate-fail and surface as error JSON.
    raw = provider.check_counterparty({})
    parsed = json.loads(raw)
    assert parsed["success"] is False
    assert "error" in parsed
