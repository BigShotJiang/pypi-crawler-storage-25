"""Smoke tests: imports, provider construction, action wiring."""

from __future__ import annotations

from minuet_agentkit_actions import (
    MinuetActionProvider,
    MinuetClient,
    minuet_action_provider,
)


def test_imports() -> None:
    assert MinuetActionProvider is not None
    assert MinuetClient is not None
    assert minuet_action_provider is not None


def test_factory_returns_provider() -> None:
    provider = minuet_action_provider()
    assert isinstance(provider, MinuetActionProvider)


def test_provider_name() -> None:
    provider = minuet_action_provider()
    assert provider.name == "minuet"


def test_supports_network_is_chain_agnostic() -> None:
    from coinbase_agentkit.network import Network

    provider = minuet_action_provider()
    # Off-chain — accepts any network input.
    assert provider.supports_network(Network(protocol_family="evm", chain_id="1")) is True
    assert provider.supports_network(Network(protocol_family="evm", chain_id="8453")) is True


def test_actions_registered() -> None:
    provider = minuet_action_provider()
    actions = provider.get_actions(wallet_provider=None)  # type: ignore[arg-type]
    names = {a.name for a in actions}
    assert names == {
        "MinuetActionProvider_search_agents",
        "MinuetActionProvider_check_counterparty",
        "MinuetActionProvider_get_hub_agents",
        "MinuetActionProvider_get_network_stats",
    }
