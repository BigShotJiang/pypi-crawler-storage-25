"""Sync HTTP client for the Minuet public API."""

from __future__ import annotations

import os
from importlib.metadata import PackageNotFoundError, version
from typing import Any

import httpx

DEFAULT_BASE_URL = "https://minuet.ai"
DEFAULT_TIMEOUT = 20.0

try:
    _VERSION = version("minuet-agentkit-actions")
except PackageNotFoundError:  # running from a source tree without install
    _VERSION = "0.0.0+local"

USER_AGENT = f"minuet-agentkit-actions/{_VERSION}"


class MinuetClient:
    """Thin sync wrapper around the Minuet Flask API.

    All methods return the parsed JSON body. Read-only — write routes
    (claim, propose, confirm) are wallet-gated and intentionally not exposed.
    """

    def __init__(
        self,
        base_url: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        self.base_url = (
            base_url or os.environ.get("MINUET_API_URL") or DEFAULT_BASE_URL
        ).rstrip("/")
        self.timeout = timeout
        self._headers = {"User-Agent": USER_AGENT}

    def _get(self, path: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        with httpx.Client(
            base_url=self.base_url, timeout=self.timeout, headers=self._headers
        ) as client:
            response = client.get(path, params=params)
        response.raise_for_status()
        return response.json()

    # ----- Agents -----

    def list_agents(
        self,
        name: str | None = None,
        limit: int | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {}
        if name:
            params["name"] = name
        if limit is not None:
            params["limit"] = limit
        return self._get("/api/agents", params=params or None)

    def get_agent(self, agent_id: str) -> dict[str, Any]:
        return self._get(f"/api/agent/{agent_id}")

    def get_agent_relationships(
        self, agent_id: str, direction: str = "both"
    ) -> dict[str, Any]:
        return self._get(
            f"/api/agent/{agent_id}/relationships",
            params={"direction": direction},
        )

    # ----- Relationships -----

    def list_relationships(self) -> dict[str, Any]:
        return self._get("/api/relationships")

    def get_clusters(self) -> dict[str, Any]:
        return self._get("/api/relationships/clusters")
