"""Input schemas for Minuet AgentKit actions."""

from __future__ import annotations

from pydantic import BaseModel, Field


class SearchAgentsSchema(BaseModel):
    """Input schema for searching ERC-8004 agents by name."""

    query: str | None = Field(
        default=None,
        description="Optional substring to match against agent name. "
        "Omit to list agents without filtering.",
    )
    limit: int = Field(
        default=25,
        description="Maximum number of agents to return.",
        ge=1,
        le=200,
    )


class CheckCounterpartySchema(BaseModel):
    """Input schema for fetching an agent's identity + relationship signals."""

    agent_id: str = Field(
        ...,
        description="Canonical agent identifier in the form `chainId:agentId` "
        "(e.g. `1:6817` for Ethereum mainnet agent 6817).",
    )


class GetHubAgentsSchema(BaseModel):
    """Input schema for the most-connected-agents listing."""

    limit: int = Field(
        default=10,
        description="Maximum number of hub agents to return.",
        ge=1,
        le=100,
    )


class GetNetworkStatsSchema(BaseModel):
    """Input schema for aggregate network statistics. No arguments."""
