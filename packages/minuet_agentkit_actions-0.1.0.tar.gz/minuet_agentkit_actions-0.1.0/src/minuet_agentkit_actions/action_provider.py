"""AgentKit action provider exposing Minuet's relationship graph."""

from __future__ import annotations

import json
from collections import Counter
from typing import Any

from coinbase_agentkit.action_providers.action_decorator import create_action
from coinbase_agentkit.action_providers.action_provider import ActionProvider
from coinbase_agentkit.network import Network
from coinbase_agentkit.wallet_providers import WalletProvider

from .client import MinuetClient
from .schemas import (
    CheckCounterpartySchema,
    GetHubAgentsSchema,
    GetNetworkStatsSchema,
    SearchAgentsSchema,
)


class MinuetActionProvider(ActionProvider[WalletProvider]):
    """Read-only actions over the Minuet relationship graph.

    All actions hit the public Minuet HTTP API. Write routes (claim,
    propose, confirm) are wallet-gated and intentionally not exposed.
    """

    def __init__(self) -> None:
        super().__init__("minuet", [])

    @create_action(
        name="search_agents",
        description=(
            "Search indexed ERC-8004 agents by name. "
            "Returns up to `limit` agents matching the query (or the first "
            "`limit` agents if no query is given). Use this to discover "
            "agents before drilling into their relationships."
        ),
        schema=SearchAgentsSchema,
    )
    def search_agents(self, args: dict[str, Any]) -> str:
        """Search agents by name."""
        try:
            validated = SearchAgentsSchema(**args)
            data = MinuetClient().list_agents(
                name=validated.query, limit=validated.limit
            )
            agents = data.get("agents", [])[: validated.limit]
            return json.dumps(
                {"success": True, "count": len(agents), "agents": agents}
            )
        except Exception as e:
            return json.dumps({"success": False, "error": f"{e!s}"})

    @create_action(
        name="check_counterparty",
        description=(
            "Fetch identity and relationship signals for a single ERC-8004 "
            "agent. Use this when an agent needs to evaluate whether it has "
            "context on a counterparty before interacting. Returns the agent "
            "record and the list of relationships in which it appears, with "
            "each relationship's status (`inferred`, `proposed`, `verified`)."
        ),
        schema=CheckCounterpartySchema,
    )
    def check_counterparty(self, args: dict[str, Any]) -> str:
        """Fetch an agent and its relationships."""
        try:
            validated = CheckCounterpartySchema(**args)
            client = MinuetClient()
            agent = client.get_agent(validated.agent_id)
            rels = client.get_agent_relationships(validated.agent_id)
            relationships = rels.get("relationships", [])
            status_counts = Counter(r.get("status", "") for r in relationships)
            return json.dumps(
                {
                    "success": True,
                    "agent": agent,
                    "relationship_count": len(relationships),
                    "status_breakdown": dict(status_counts),
                    "relationships": relationships,
                }
            )
        except Exception as e:
            return json.dumps({"success": False, "error": f"{e!s}"})

    @create_action(
        name="get_hub_agents",
        description=(
            "Return the most-connected agents in the Minuet relationship "
            "graph. Useful for discovering which agents other agents "
            "actually work with."
        ),
        schema=GetHubAgentsSchema,
    )
    def get_hub_agents(self, args: dict[str, Any]) -> str:
        """Return the most-connected agents."""
        try:
            validated = GetHubAgentsSchema(**args)
            data = MinuetClient().get_clusters()
            hubs = data.get("hubs", [])[: validated.limit]
            return json.dumps(
                {"success": True, "count": len(hubs), "hubs": hubs}
            )
        except Exception as e:
            return json.dumps({"success": False, "error": f"{e!s}"})

    @create_action(
        name="get_network_stats",
        description=(
            "Return aggregate statistics about the Minuet relationship "
            "graph: totals for relationships, agents, named agents, "
            "verified vs inferred status, and the top relationship types."
        ),
        schema=GetNetworkStatsSchema,
    )
    def get_network_stats(self, args: dict[str, Any]) -> str:
        """Return aggregate network statistics."""
        try:
            client = MinuetClient()
            clusters = client.get_clusters()
            rels = client.list_relationships()
            relationships = rels.get("relationships", [])
            status_counts = Counter(r.get("status", "") for r in relationships)
            type_counts = Counter(
                r.get("relationship_type", "") for r in relationships
            )
            stats = dict(clusters.get("stats", {}))
            stats["by_status"] = dict(status_counts)
            stats["by_relationship_type"] = dict(type_counts)
            return json.dumps({"success": True, "stats": stats})
        except Exception as e:
            return json.dumps({"success": False, "error": f"{e!s}"})

    def supports_network(self, network: Network) -> bool:
        """Minuet relationships are off-chain — chain-agnostic."""
        return True


def minuet_action_provider() -> MinuetActionProvider:
    """Create a new Minuet action provider."""
    return MinuetActionProvider()
