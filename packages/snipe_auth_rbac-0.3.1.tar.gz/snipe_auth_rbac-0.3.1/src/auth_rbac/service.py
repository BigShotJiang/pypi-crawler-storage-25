"""Permissions service — wraps the SQL helper RPCs.

Two read paths:
  * ``user_can(user_id, resource, action, company_id=None)``
    — single boolean check. Calls ``rbac.user_can``.
  * ``hydrate_profile(user_id)`` — full profile in one call. Calls
    ``rbac.user_profile``. Used by the ``/me/profile`` endpoint.

The functions live in the dedicated ``rbac`` Postgres schema, so
adopters must add ``rbac`` to their PostgREST exposed-schemas list
(Supabase Studio → Settings → API → Exposed schemas) for the
``schema("rbac")`` calls below to reach them.

A small in-process LRU caches the hydrated profile per user with a
TTL of 30 seconds. Adopters that need cross-process invalidation
(multi-worker FastAPI) should swap ``_ProfileCache`` for a Redis
implementation — the public API is unchanged.
"""

from __future__ import annotations

import time
from threading import RLock
from typing import Any, Protocol

from .types import (
    Action,
    AuthRbacError,
    CompanyMembership,
    PermissionGrid,
    PermissionMap,
    ResourceDescriptor,
    ResourceScope,
    RoleSummary,
    UserProfile,
)


class SupabaseLike(Protocol):
    """Just enough of the supabase-py surface for the service to
    work. Adopters can pass any object that implements these two
    methods (``rpc`` for the resolver / hydrator, ``from_`` for the
    one-shot resource sync)."""

    def rpc(self, fn: str, args: dict[str, Any]) -> Any: ...

    def from_(self, table: str) -> Any: ...


class _ProfileCache:
    def __init__(self, ttl_seconds: float = 30.0) -> None:
        self._ttl = ttl_seconds
        self._lock = RLock()
        self._data: dict[str, tuple[float, UserProfile]] = {}

    def get(self, user_id: str) -> UserProfile | None:
        with self._lock:
            entry = self._data.get(user_id)
            if entry is None:
                return None
            stored_at, profile = entry
            if time.monotonic() - stored_at > self._ttl:
                del self._data[user_id]
                return None
            return profile

    def put(self, user_id: str, profile: UserProfile) -> None:
        with self._lock:
            self._data[user_id] = (time.monotonic(), profile)

    def invalidate(self, user_id: str | None = None) -> None:
        with self._lock:
            if user_id is None:
                self._data.clear()
            else:
                self._data.pop(user_id, None)


class PermissionsService:
    """Single entry point used by the FastAPI deps and by manual
    callers (admin scripts, tests).

    The service is stateless except for the profile cache; instances
    are safe to share across requests."""

    def __init__(
        self,
        supabase: SupabaseLike,
        *,
        resources: list[ResourceDescriptor],
        cache_ttl_seconds: float = 30.0,
    ) -> None:
        self._sb = supabase
        self._resources = {r.resource: r for r in resources}
        self._cache = _ProfileCache(cache_ttl_seconds)

    # ── Resource registry helpers ──────────────────────────────────

    def resource_scope(self, resource: str) -> ResourceScope | None:
        descriptor = self._resources.get(resource)
        return descriptor.scope if descriptor else None

    # ── Read APIs ─────────────────────────────────────────────────

    def user_can(
        self,
        user_id: str,
        resource: str,
        action: Action,
        company_id: str | None = None,
    ) -> bool:
        """Single boolean check. Calls the SQL function directly so
        super-admin bypass + scope rules stay in one place."""
        try:
            result = self._sb.schema("rbac").rpc(
                "user_can",
                {
                    "p_user_id": user_id,
                    "p_resource": resource,
                    "p_action": action,
                    "p_company_id": company_id,
                },
            ).execute()
        except Exception as exc:  # pragma: no cover — bubbled
            raise AuthRbacError(
                f"rbac.user_can RPC failed: {exc}"
            ) from exc

        # supabase-py returns an APIResponse; raw clients return a dict-ish.
        data = getattr(result, "data", result)
        if isinstance(data, list) and data:
            data = data[0]
        if isinstance(data, dict):
            data = data.get("user_can", next(iter(data.values()), False))
        return bool(data)

    def hydrate_profile(
        self,
        user_id: str,
        *,
        force_refresh: bool = False,
    ) -> UserProfile:
        if not force_refresh:
            cached = self._cache.get(user_id)
            if cached is not None:
                return cached
        try:
            result = self._sb.schema("rbac").rpc(
                "user_profile",
                {"p_user_id": user_id},
            ).execute()
        except Exception as exc:
            raise AuthRbacError(
                f"rbac.user_profile RPC failed: {exc}"
            ) from exc
        data = getattr(result, "data", result)
        if isinstance(data, list) and data:
            data = data[0]
        if isinstance(data, dict):
            # The function returns jsonb wrapping the whole object,
            # so the dict's only value IS the profile.
            if "user_profile" in data:
                data = data["user_profile"]
        if not isinstance(data, dict):
            raise AuthRbacError("unexpected rbac.user_profile payload")
        profile = _profile_from_jsonb(data)
        self._cache.put(user_id, profile)
        return profile

    # ── Template defaults ─────────────────────────────────────────

    def apply_template_defaults(
        self,
        role_id: str,
        *,
        only_missing: bool = True,
    ) -> int:
        """Materialise ``rbac.role_permissions`` rows from a template
        role's ``default_permissions`` JSONB pattern.

        Run this **after** ``sync_resources()`` so the function can
        match the template's group/resource patterns against the
        current resource registry.

        Returns the number of rows inserted/updated."""
        try:
            result = self._sb.schema("rbac").rpc(
                "apply_template_defaults",
                {"p_role_id": role_id, "p_only_missing": only_missing},
            ).execute()
        except Exception as exc:
            raise AuthRbacError(
                f"rbac.apply_template_defaults RPC failed: {exc}"
            ) from exc
        data = getattr(result, "data", result)
        if isinstance(data, list) and data:
            data = data[0]
        if isinstance(data, dict):
            data = data.get(
                "apply_template_defaults",
                next(iter(data.values()), 0),
            )
        return int(data or 0)

    # ── Resource sync (run once at app boot) ──────────────────────

    def sync_resources(
        self,
        resources: list[ResourceDescriptor] | None = None,
    ) -> int:
        """Upsert resource descriptors into ``rbac.resources``.

        Call this once during app start-up so adding a new resource
        is purely a code change — no manual migration required. The
        registry passed at construction is used by default; pass a
        list explicitly to sync a different set.

        Returns the number of rows upserted.

        Idempotent: running it again with the same list is a no-op
        on the matrix UI but does refresh `label` / `description` /
        `group_label` if you tweaked them.
        """
        rows = resources if resources is not None else list(self._resources.values())
        if not rows:
            return 0
        try:
            payload = [
                {
                    "resource": r.resource,
                    "scope": r.scope,
                    "label": r.label,
                    "description": r.description,
                    "group_label": r.group,
                }
                for r in rows
            ]
            self._sb.schema("rbac").from_("resources").upsert(  # type: ignore[attr-defined]
                payload, on_conflict="resource"
            ).execute()
        except Exception as exc:
            raise AuthRbacError(
                f"sync_resources failed: {exc}"
            ) from exc
        return len(rows)

    # ── Bootstrap detection ───────────────────────────────────────

    def detect_schema(self) -> bool:
        """Returns True if the ``rbac`` schema looks installed.

        Cheap probe — calls ``rbac.user_can`` with a non-existent
        user; a missing schema or unexposed PostgREST surface
        bubbles up as an exception. A False return means the
        bootstrap migration hasn't been applied OR the ``rbac``
        schema isn't in the project's exposed-schemas list.

        Run this at app boot from your start-up hook; on False,
        log a clear error and skip the rest of the auth-rbac wiring
        so the app comes up degraded rather than crashing on every
        request."""
        try:
            self._sb.schema("rbac").rpc(
                "user_can",
                {
                    "p_user_id": "00000000-0000-0000-0000-000000000000",
                    "p_resource": "__rbac_self_check__",
                    "p_action": "read",
                    "p_company_id": None,
                },
            ).execute()
        except Exception:
            return False
        return True

    def require_schema(self) -> None:
        """Raise ``AuthRbacError`` if ``detect_schema`` returns False.

        Convenience wrapper for app start-up that wants to abort
        boot rather than silently degrade."""
        if not self.detect_schema():
            raise AuthRbacError(
                "rbac schema is not reachable. Apply 0001_initial.sql "
                "(and optionally 0002_seed_defaults.sql) and add 'rbac' "
                "to your PostgREST exposed-schemas list."
            )

    # ── Cache control ─────────────────────────────────────────────

    def invalidate(self, user_id: str | None = None) -> None:
        """Drop one user's cached profile (or all if user_id is None).

        Adopters wire this to a Postgres LISTEN/NOTIFY or a Supabase
        realtime channel on the assignments tables so demotions
        propagate within seconds rather than 30s TTL."""
        self._cache.invalidate(user_id)


# ── jsonb → dataclass helpers ────────────────────────────────────


def _grid_from_dict(payload: dict[str, Any]) -> PermissionGrid:
    return PermissionGrid(
        read=bool(payload.get("read")),
        write=bool(payload.get("write")),
        update=bool(payload.get("update")),
        delete=bool(payload.get("delete")),
    )


def _perm_map_from_dict(payload: dict[str, Any] | None) -> PermissionMap:
    if not payload:
        return {}
    return {k: _grid_from_dict(v or {}) for k, v in payload.items()}


def _role_from_dict(payload: dict[str, Any]) -> RoleSummary:
    return RoleSummary(
        id=str(payload.get("id")),
        name=str(payload.get("name", "")),
        is_system=bool(payload.get("is_system", False)),
        is_super=bool(payload.get("is_super", False)),
        frontend_config=payload.get("frontend_config") or {},
    )


def _membership_from_dict(payload: dict[str, Any]) -> CompanyMembership:
    return CompanyMembership(
        company_id=str(payload["company_id"]),
        company_name=str(payload.get("company_name", "")),
        company_slug=payload.get("company_slug"),
        roles=[_role_from_dict(r) for r in (payload.get("roles") or [])],
        permissions=_perm_map_from_dict(payload.get("permissions")),
        frontend_config=payload.get("frontend_config") or {},
    )


def _profile_from_jsonb(payload: dict[str, Any]) -> UserProfile:
    return UserProfile(
        user_id=str(payload["user_id"]),
        is_super_admin=bool(payload.get("is_super_admin")),
        system_roles=[
            _role_from_dict(r) for r in (payload.get("system_roles") or [])
        ],
        system_permissions=_perm_map_from_dict(payload.get("system_permissions")),
        system_frontend_config=payload.get("system_frontend_config") or {},
        memberships=[
            _membership_from_dict(m) for m in (payload.get("memberships") or [])
        ],
    )
