"""Two-layer RBAC for Python backends.

Pair with the SQL migration in ``packages/auth-rbac/sql/`` and the
``@snipe/auth-rbac`` TypeScript sibling. Designed transport-agnostic
— bring any client that can call a SQL function (the package's
``rbac.user_can`` / ``rbac.user_profile``) and any auth
dependency that resolves the current user's id.

Public API:

    from auth_rbac import (
        Action,
        ResourceScope,
        ResourceDescriptor,
        UserProfile,
        PermissionsService,
    )
    from auth_rbac.deps import (
        require_permission,
        require_system_permission,
        active_company_middleware,
    )
    from auth_rbac.scope import apply_company_scope

The deps module is FastAPI-flavoured but small enough to copy into
a Flask / Litestar adapter when needed.
"""

from .scope import apply_company_scope, register_table_company_column
from .service import PermissionsService
from .types import (
    Action,
    AuthRbacError,
    CompanyMembership,
    PermissionDenied,
    PermissionGrid,
    PermissionMap,
    ResourceDescriptor,
    ResourceScope,
    RoleSummary,
    UserProfile,
)

__all__ = [
    "Action",
    "AuthRbacError",
    "CompanyMembership",
    "PermissionDenied",
    "PermissionGrid",
    "PermissionMap",
    "PermissionsService",
    "ResourceDescriptor",
    "ResourceScope",
    "RoleSummary",
    "UserProfile",
    "apply_company_scope",
    "register_table_company_column",
]

__version__ = "0.1.0"
