"""FastAPI helpers — Depends factories + middleware.

Adopters bind the package to their own auth resolver + service
once at app start-up via ``configure_auth_rbac()`` and then drop
``Depends(require_permission(...))`` into any endpoint.

For Flask / Litestar / Starlette-bare projects, the same patterns
apply: read user_id from the request, call ``service.user_can``,
raise on miss. Copy 30 lines, port them — no need for a framework
shim per host.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any

from .service import PermissionsService
from .types import Action

try:
    from fastapi import HTTPException, Request, status
except ImportError:  # pragma: no cover — FastAPI is an optional extra
    HTTPException = None  # type: ignore[assignment]
    Request = None  # type: ignore[assignment]
    status = None  # type: ignore[assignment]


# Adopter-supplied callable that returns the current user's id from
# a Starlette/FastAPI request. Most projects already have one; the
# package only needs the id, no role logic.
UserIdResolver = Callable[["Request"], Awaitable[str] | str]


_state: dict[str, Any] = {
    "service": None,
    "user_id_resolver": None,
}


def configure_auth_rbac(
    *,
    service: PermissionsService,
    user_id_resolver: UserIdResolver,
) -> None:
    """Bind the package to a project. Call once at app start-up,
    typically from your ``main.py`` next to where you wire up
    middleware and routers.

    Args:
        service: Configured ``PermissionsService`` (you bring the
            Supabase / SQL client + your project's resource list).
        user_id_resolver: Sync or async callable that pulls the
            authenticated user's UUID off the incoming request.
            Most FastAPI projects already have a ``get_current_user``
            dependency that does exactly this.
    """
    _state["service"] = service
    _state["user_id_resolver"] = user_id_resolver


def _service() -> PermissionsService:
    svc = _state["service"]
    if svc is None:
        raise RuntimeError(
            "auth_rbac: configure_auth_rbac() was not called "
            "— set service + user_id_resolver during app start-up.",
        )
    return svc


async def _resolve_user_id(request: Request) -> str:  # type: ignore[valid-type]
    resolver = _state["user_id_resolver"]
    if resolver is None:
        raise RuntimeError("auth_rbac: configure_auth_rbac() was not called")
    result = resolver(request)
    if hasattr(result, "__await__"):
        result = await result
    return result  # type: ignore[return-value]


# ─────────────────────────────────────────────────────────────────
# Active-company middleware
#
# Reads X-Company-Id header (preferred) or path prefix /c/<slug>/
# and stuffs the validated id on request.state.company_id. Endpoints
# never have to repeat the lookup.
# ─────────────────────────────────────────────────────────────────


COMPANY_HEADER = "X-Company-Id"
COMPANY_PATH_PREFIX = "/c/"


async def active_company_middleware(request: Request, call_next):  # type: ignore[no-untyped-def, valid-type]
    """Starlette/FastAPI middleware. Wire it via
    ``app.middleware("http")(active_company_middleware)`` or
    ``app.add_middleware(BaseHTTPMiddleware, dispatch=...)``.

    Side effects:
      * Sets ``request.state.company_id`` to the validated id, or
        ``None`` for system-context requests.
      * Does NOT raise on missing/unknown id — that's
        ``require_permission``'s job.  The middleware just
        normalises the value so endpoints don't re-parse.
    """
    company_id: str | None = request.headers.get(COMPANY_HEADER)
    if company_id is None and request.url.path.startswith(COMPANY_PATH_PREFIX):
        slug = request.url.path[len(COMPANY_PATH_PREFIX) :].split("/", 1)[0]
        if slug:
            company_id = slug  # left as slug; the resolver tolerates either
    request.state.company_id = company_id or None
    return await call_next(request)


# ─────────────────────────────────────────────────────────────────
# Depends factories
# ─────────────────────────────────────────────────────────────────


def require_permission(
    resource: str,
    action: Action,
):
    """Use as ``_: None = Depends(require_permission("payments", "read"))``.

    Auto-resolves whether the resource is system- or company-scope
    via the registered service. For company resources, reads
    ``request.state.company_id`` (set by ``active_company_middleware``);
    if it's missing, returns 400.
    """
    if HTTPException is None:
        raise RuntimeError(
            "auth_rbac.deps requires the optional 'fastapi' extra: "
            "pip install 'snipe-auth-rbac[fastapi]'"
        )

    async def _dep(request: Request) -> None:  # type: ignore[valid-type]
        user_id = await _resolve_user_id(request)
        svc = _service()
        scope = svc.resource_scope(resource)
        company_id: str | None = None
        if scope == "company":
            company_id = getattr(request.state, "company_id", None)
            if not company_id:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail={
                        "error": "company_required",
                        "resource": resource,
                        "action": action,
                    },
                )
        ok = svc.user_can(user_id, resource, action, company_id)
        if not ok:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={
                    "error": "permission_denied",
                    "resource": resource,
                    "action": action,
                    "scope": scope,
                    "company_id": company_id,
                },
            )

    return _dep


def require_system_permission(resource: str, action: Action):
    """Same as ``require_permission`` but explicitly for system-scope
    resources. Useful for endpoints that should never look at the
    active company (e.g. ``/system/companies``)."""
    if HTTPException is None:
        raise RuntimeError(
            "auth_rbac.deps requires the optional 'fastapi' extra: "
            "pip install 'snipe-auth-rbac[fastapi]'"
        )

    async def _dep(request: Request) -> None:  # type: ignore[valid-type]
        user_id = await _resolve_user_id(request)
        svc = _service()
        scope = svc.resource_scope(resource)
        if scope != "system":
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail={
                    "error": "wrong_scope",
                    "resource": resource,
                    "expected": "system",
                    "actual": scope,
                },
            )
        ok = svc.user_can(user_id, resource, action, None)
        if not ok:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={
                    "error": "permission_denied",
                    "resource": resource,
                    "action": action,
                    "scope": "system",
                },
            )

    return _dep
