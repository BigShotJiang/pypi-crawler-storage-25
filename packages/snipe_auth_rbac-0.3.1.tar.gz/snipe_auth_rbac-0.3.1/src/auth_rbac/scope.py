"""Row-level company-scope filter.

Distinct from permission scope: ``apply_company_scope`` answers
"which rows of this resource type belong to the active company"
*after* ``require_permission`` has decided "yes, this user may
read this resource type at all".

The mapping table → company_id-column lives in a process-wide
registry that adopters extend at app start-up. Defaults cover
the most common SaaS shapes; anything project-specific is
registered explicitly.
"""

from __future__ import annotations

from typing import Any

# Adopter-extensible mapping. Key = table name, value = the column on
# that table that holds the owning company's UUID.
_TABLE_COMPANY_COLUMN: dict[str, str] = {}


def register_table_company_column(table: str, column: str) -> None:
    """Tell the package which column to filter on for a given table.

    Call once at app start-up::

        register_table_company_column("properties", "owner_company_id")
        register_table_company_column("payments", "company_id")
    """
    _TABLE_COMPANY_COLUMN[table] = column


def lookup_company_column(table: str) -> str | None:
    return _TABLE_COMPANY_COLUMN.get(table)


def apply_company_scope(
    query: Any,
    company_id: str | None,
    *,
    table: str | None = None,
    column: str | None = None,
) -> Any:
    """Append a company filter to a Supabase / PostgREST query.

    Pass either ``column`` directly or a ``table`` name registered
    via ``register_table_company_column``. ``company_id=None``
    short-circuits — used by super-admins viewing the platform.

    The function is duck-typed: any object with an ``in_`` method
    works (Supabase Python client, Postgrest builder, custom
    wrappers). For SQLAlchemy you'd write a sibling helper.
    """
    if company_id is None:
        return query
    col = column or (lookup_company_column(table) if table else None)
    if col is None:
        raise ValueError(
            "apply_company_scope: no column resolved — pass column=… or "
            "register the table via register_table_company_column()"
        )
    if not hasattr(query, "eq"):
        raise TypeError(
            "apply_company_scope: query object does not support .eq() — "
            "pass a Supabase / PostgREST query, or write your own helper"
        )
    return query.eq(col, company_id)
