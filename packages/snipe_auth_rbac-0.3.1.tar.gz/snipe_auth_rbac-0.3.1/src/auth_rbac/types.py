"""Core dataclasses + exceptions.

Mirrors the TypeScript ``types.ts`` shapes so the same JSON payload
flows over the wire without extra adaptation.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

Action = Literal["read", "write", "update", "delete"]
ResourceScope = Literal["system", "company"]


@dataclass(frozen=True)
class ResourceDescriptor:
    resource: str
    scope: ResourceScope
    label: str
    description: str | None = None
    group: str | None = None


@dataclass(frozen=True)
class RoleSummary:
    id: str
    name: str
    is_system: bool = False
    is_super: bool = False
    frontend_config: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class PermissionGrid:
    read: bool = False
    write: bool = False
    update: bool = False
    delete: bool = False

    def get(self, action: Action) -> bool:
        return getattr(self, action)


PermissionMap = dict[str, PermissionGrid]


@dataclass(frozen=True)
class CompanyMembership:
    company_id: str
    company_name: str
    company_slug: str | None
    roles: list[RoleSummary]
    permissions: PermissionMap
    frontend_config: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class UserProfile:
    user_id: str
    is_super_admin: bool
    system_roles: list[RoleSummary]
    system_permissions: PermissionMap
    system_frontend_config: dict[str, Any]
    memberships: list[CompanyMembership]


class AuthRbacError(Exception):
    """Base class for everything raised by the package."""


class PermissionDenied(AuthRbacError):  # noqa: N818 — intentional public name, "Error" suffix would be redundant
    """Raised when a permission check fails. FastAPI deps catch this
    and convert it to a 403; non-FastAPI hosts can catch it directly.
    """

    def __init__(
        self,
        resource: str,
        action: str,
        *,
        scope: ResourceScope | None = None,
        company_id: str | None = None,
    ) -> None:
        self.resource = resource
        self.action = action
        self.scope = scope
        self.company_id = company_id
        super().__init__(
            f"permission denied: {action!r} on {resource!r}"
            + (f" (company={company_id})" if company_id else "")
        )
