"""CLI 命令装饰器

提供 @cli_command 装饰器，自动注入 OutputFormatter、捕获异常、处理退出码。
对现有命令的迁移改动最小化。
"""
from __future__ import annotations

import inspect
import sys
from functools import wraps

from .errors import CLIError, ExitCode
from .output import OutputFormatter


def cli_command(fn):
    """装饰命令方法，添加 Agent 友好的输出和错误处理

    用法：
        class MyGroup:
            @cli_command
            def my_cmd(self, name: str, _out: OutputFormatter = None):
                _out.info("处理中...")
                _out.success({"result": "ok"})

    行为：
    1. 自动创建 OutputFormatter 注入为 _out 参数
    2. 捕获 CLIError → emit 到 stderr + sys.exit(exit_code)
    3. 捕获未知异常 → 包装为 CLIError
    4. 返回 None 阻止 Fire 的 auto-print
    """
    @wraps(fn)
    def wrapper(*args, **kwargs):
        out = OutputFormatter()
        kwargs["_out"] = out
        try:
            fn(*args, **kwargs)
            return None  # 阻止 Fire auto-print
        except CLIError as e:
            e.emit(out)
            sys.exit(e.exit_code)
        except SystemExit:
            raise  # 不拦截 sys.exit
        except KeyboardInterrupt:
            sys.exit(130)
        except Exception as e:
            err = CLIError(
                error_type="internal_error",
                message=str(e),
                retryable=False,
                exit_code=ExitCode.GENERAL_ERROR,
            )
            err.emit(out)
            sys.exit(ExitCode.GENERAL_ERROR)

    # 修改签名：隐藏 _out 参数，让 Fire 不暴露它
    sig = inspect.signature(fn)
    params = [p for name, p in sig.parameters.items() if name != "_out"]
    wrapper.__signature__ = sig.replace(parameters=params)
    return wrapper
