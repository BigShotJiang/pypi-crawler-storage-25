"""结构化错误和语义退出码

提供 CLIError 异常类和 ExitCode 枚举，让 Agent 能通过退出码和 JSON 错误消息
可靠地判断命令执行结果。
"""
from __future__ import annotations

import json
import sys
from enum import IntEnum


class ExitCode(IntEnum):
    """语义化退出码，超越 0/1 二元判断"""
    SUCCESS = 0
    GENERAL_ERROR = 1
    USAGE_ERROR = 2        # 参数错误、无效输入
    NOT_FOUND = 3          # 资源未找到（端口无进程、服务不存在等）
    PERMISSION_DENIED = 4  # 权限不足
    CONFLICT = 5           # 资源已存在、状态冲突


class CLIError(Exception):
    """结构化 CLI 错误，包含机器可读类型和恢复建议"""

    def __init__(
        self,
        error_type: str,
        message: str,
        suggestion: str = None,
        retryable: bool = False,
        exit_code: ExitCode = ExitCode.GENERAL_ERROR,
        context: dict = None,
    ):
        super().__init__(message)
        self.error_type = error_type
        self.suggestion = suggestion
        self.retryable = retryable
        self.exit_code = exit_code
        self.context = context or {}

    def to_dict(self) -> dict:
        d = {
            "error": self.error_type,
            "message": str(self),
            "retryable": self.retryable,
        }
        if self.suggestion:
            d["suggestion"] = self.suggestion
        if self.context:
            d["context"] = self.context
        return d

    def emit(self, formatter=None):
        """输出错误信息到 stderr

        formatter 为 None 或 JSON 模式时输出 JSON，否则输出 Rich 格式。
        """
        if formatter is None or formatter.is_json:
            json.dump(self.to_dict(), sys.stderr)
            sys.stderr.write("\n")
            sys.stderr.flush()
        else:
            from rich import print as rprint
            rprint(f"[red]错误: {self}[/red]", file=sys.stderr)
            if self.suggestion:
                rprint(f"[yellow]建议: {self.suggestion}[/yellow]", file=sys.stderr)
