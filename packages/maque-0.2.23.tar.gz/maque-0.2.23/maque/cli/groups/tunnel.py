"""内网穿透命令组"""

from rich import print


class TunnelGroup:
    """内网穿透命令组

    将内网服务通过隧道服务器暴露到外网。四种后端：

    python（默认）  零外部依赖，双端需安装 maque
    chisel          Go 单二进制，高性能加密传输，自动下载
    frp             Go 高性能，适合接入已有 frp 基础设施，自动下载
    ssh             零安装，直接用系统 sshd，无需启动 server，支持 ~/.ssh/config Host 别名

    Usage:
        maque tunnel server [--port=25565] [--method=python|chisel|frp]
        maque tunnel client SERVER:PORT 远程端口:本地端口 [--method=python|chisel|frp|ssh]
        maque tunnel install [--tool=chisel|frp]

    注: ssh 后端直接使用目标机器的 sshd，无需 tunnel server。

    Examples:
        # server（python 默认，chisel/frp 需指定 --method）
        maque tunnel server                                              # python 服务端
        maque tunnel server --auth=secret123                             # python 带认证
        maque tunnel server --method=chisel --auth=user:pass             # chisel 带认证
        maque tunnel server --method=frp --port=7000 --auth=my_token     # frp 带认证（惯用端口 7000）

        # client（python 默认，ssh 无需 server）
        maque tunnel client IP:25565 9000:8000                           # python 客户端
        maque tunnel client IP:25565 9000:8000 9001:8001 --auth=secret123  # 多端口 + 认证
        maque tunnel client IP:25565 9000:192.168.1.5:8000               # 映射内网其他机器
        maque tunnel client IP:25565 9000:8000 --method=chisel --auth=user:pass  # chisel
        maque tunnel client IP:7000 9000:8000 --method=frp --auth=my_token       # frp
        maque tunnel client HOST 9000:8000 --method=ssh                  # ssh（~/.ssh/config 别名）
        maque tunnel client IP 9000:8000 --method=ssh --ssh_user=root    # ssh（IP + 用户名）

        # install（python/ssh 无需下载）
        maque tunnel install                                             # 预下载 chisel
        maque tunnel install --tool=frp                                  # 预下载 frp
    """

    def __init__(self, cli_instance):
        self.cli = cli_instance

    @staticmethod
    def server(
        port: int = 25565,
        auth: str = None,
        host: str = "0.0.0.0",
        method: str = "python",
    ):
        """启动隧道服务端（在有外网的机器上运行）

        支持 python（默认）、chisel、frp 三种后端。
        SSH 后端使用系统 sshd，无需启动服务端。

        Args:
            port: 监听端口，默认 25565（frp 惯用 7000）
            auth: 认证 token（python/frp）或 user:password（chisel）
            host: 监听地址，默认 0.0.0.0
            method: 后端类型 python/chisel/frp

        Examples:
            maque tunnel server
            maque tunnel server --method=chisel
            maque tunnel server --method=frp --port=7000
            maque tunnel server --auth=secret123
        """
        from maque.tunnel import tunnel_server

        tunnel_server(port=port, host=host, auth=auth, method=method)

    @staticmethod
    def client(
        server: str,
        *mappings: str,
        auth: str = None,
        method: str = "python",
        ssh_user: str = "root",
    ):
        """启动隧道客户端（在内网机器上运行）

        将客户端能访问的服务，通过隧道服务器暴露出去。
        支持 python（默认）、chisel、frp、ssh 四种后端。

        端口映射格式:
            远程端口:本地端口           映射本机服务
            远程端口:目标IP:目标端口     映射客户端网络内任意可达的 IP:端口

        Args:
            server: 隧道服务器地址 IP:PORT，SSH 后端支持 ~/.ssh/config Host 别名
            *mappings: 端口映射，支持多个空格分隔
            auth: 认证 token（python/frp）或 user:password（chisel）
            method: 后端类型 python/chisel/frp/ssh
            ssh_user: SSH 用户名，仅 ssh 后端且用 IP 连接时需要，默认 root

        Examples:
            maque tunnel client SERVER_IP:25565 9000:8000
            maque tunnel client SERVER_IP:25565 9000:8000 9001:8001
            maque tunnel client SERVER_IP:7000 9000:8000 --method=frp
            maque tunnel client SERVER_IP:25565 9000:8000 --auth=secret123
            maque tunnel client work 9000:8000 --method=ssh
            maque tunnel client 10.0.0.1 9000:8000 --method=ssh --ssh_user=kunyuan
        """
        from maque.tunnel import tunnel_client

        tunnel_client(
            server=server,
            mappings=list(mappings),
            auth=auth,
            method=method,
            ssh_user=ssh_user,
        )

    @staticmethod
    def install(tool: str = "chisel", use_mirror: bool = None):
        """下载/更新隧道工具二进制到 ~/.maque/bin/

        用于在有网络的机器上预先下载，然后手动拷贝到内网机器。
        python 和 ssh 后端无需下载。

        Args:
            tool: 工具名称 chisel/frp，默认 chisel
            use_mirror: True=强制走镜像, False=强制直连, 默认先直连再 fallback 镜像

        Examples:
            maque tunnel install
            maque tunnel install --tool=frp
            maque tunnel install --use_mirror
        """
        from maque.tunnel import tunnel_install

        tunnel_install(tool=tool, use_mirror=use_mirror)
