"""服务管理命令组"""
import os
import json
import subprocess
import time
import signal
import psutil
from pathlib import Path
from rich import print
from rich.table import Table
from rich.console import Console

from ..decorators import cli_command
from ..errors import CLIError, ExitCode
from ..output import OutputFormatter
from ..compat import confirm


class ServiceGroup:
    """服务管理命令组"""

    def __init__(self, cli_instance):
        self.cli = cli_instance
        self.console = Console()
        self.services_config_file = Path.home() / '.maque' / 'services.json'

    def _ensure_config_dir(self):
        """确保配置目录存在"""
        self.services_config_file.parent.mkdir(exist_ok=True)

    def _load_services_config(self):
        """加载服务配置"""
        if self.services_config_file.exists():
            with open(self.services_config_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}

    def _save_services_config(self, config):
        """保存服务配置"""
        self._ensure_config_dir()
        with open(self.services_config_file, 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=2, ensure_ascii=False)

    def _get_service_status(self, service_info):
        """获取服务状态"""
        pid = service_info.get('pid')

        if not pid:
            return 'stopped', None

        try:
            process = psutil.Process(pid)
            if process.is_running():
                return 'running', pid
            else:
                return 'stopped', None
        except psutil.NoSuchProcess:
            return 'stopped', None
        except Exception:
            return 'unknown', pid

    def _check_port_health(self, port):
        """检查端口健康状态"""
        import socket

        try:
            start_time = time.time()
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            result = sock.connect_ex(('localhost', port))
            sock.close()

            response_time = (time.time() - start_time) * 1000
            return result == 0, response_time
        except Exception:
            return False, None

    def _require_service(self, config, name):
        """检查服务是否存在，不存在则抛 CLIError"""
        if name not in config:
            raise CLIError(
                "not_found", f"服务 '{name}' 不存在",
                suggestion="使用 'maque service list' 查看已注册的服务",
                exit_code=ExitCode.NOT_FOUND,
            )
        return config[name]

    @cli_command
    def list(self, status: bool = True, _out: OutputFormatter = None):
        """列出已注册的服务

        Args:
            status: 是否显示服务状态，默认True

        Examples:
            maque service list
            maque service list --format=json
        """
        config = self._load_services_config()

        if not config:
            _out.success({"services": []})
            return

        if status:
            headers = ["服务名", "端口", "命令", "状态", "PID"]
            rows = []
            for service_name, service_info in config.items():
                port = str(service_info.get('port', 'N/A'))
                command = service_info.get('command', 'N/A')
                svc_status, pid = self._get_service_status(service_info)
                pid_str = str(pid) if pid else "N/A"
                rows.append([service_name, port, command, svc_status, pid_str])
        else:
            headers = ["服务名", "端口", "命令"]
            rows = []
            for service_name, service_info in config.items():
                port = str(service_info.get('port', 'N/A'))
                command = service_info.get('command', 'N/A')
                rows.append([service_name, port, command])

        _out.table(headers, rows, title="已注册的服务")

    @cli_command
    def register(
        self,
        name: str,
        command: str,
        port: int = None,
        working_dir: str = None,
        env_vars: str = None,
        description: str = None,
        force: bool = False,
        _out: OutputFormatter = None,
    ):
        """注册新服务

        Args:
            name: 服务名称
            command: 启动命令
            port: 服务端口（可选）
            working_dir: 工作目录（可选）
            env_vars: 环境变量，格式: "KEY1=VALUE1,KEY2=VALUE2"
            description: 服务描述
            force: 如果服务已存在，直接覆盖（不询问确认）

        Examples:
            maque service register ollama "ollama serve" --port=11434
            maque service register my-api "python app.py" --port=8000 --working_dir="/path/to/app"
        """
        config = self._load_services_config()

        if name in config and not force:
            if not confirm(f"服务 '{name}' 已存在，是否覆盖？"):
                raise CLIError("conflict", "操作已取消", exit_code=ExitCode.CONFLICT)

        # 解析环境变量
        env_dict = {}
        if env_vars:
            for pair in env_vars.split(','):
                if '=' in pair:
                    key, value = pair.split('=', 1)
                    env_dict[key.strip()] = value.strip()

        service_config = {
            'command': command,
            'working_dir': working_dir or os.getcwd(),
            'env_vars': env_dict,
            'description': description or '',
            'created_at': str(time.time())
        }

        if port:
            service_config['port'] = port

        config[name] = service_config
        self._save_services_config(config)

        _out.info(f"[green]服务 '{name}' 已注册[/green]")
        _out.success({"name": name, "action": "registered", **service_config})

    @cli_command
    def unregister(self, name: str, force: bool = False, _out: OutputFormatter = None):
        """注销服务

        Args:
            name: 服务名称
            force: 强制注销（不询问确认）
        """
        config = self._load_services_config()
        self._require_service(config, name)

        # 检查服务是否在运行
        status, pid = self._get_service_status(config[name])
        if status == 'running':
            _out.warn(f"服务 '{name}' 正在运行 (PID: {pid})")
            if not force:
                if not confirm("是否先停止服务并注销？"):
                    raise CLIError("conflict", "操作已取消", exit_code=ExitCode.CONFLICT)
                self.stop(name)

        del config[name]
        self._save_services_config(config)
        _out.info(f"[green]服务 '{name}' 已注销[/green]")
        _out.success({"name": name, "action": "unregistered"})

    @cli_command
    def start(self, name: str, detach: bool = True, _out: OutputFormatter = None):
        """启动服务

        Args:
            name: 服务名称
            detach: 是否后台运行，默认True
        """
        config = self._load_services_config()
        service_info = self._require_service(config, name)
        status, pid = self._get_service_status(service_info)

        if status == 'running':
            raise CLIError(
                "conflict", f"服务 '{name}' 已在运行 (PID: {pid})",
                exit_code=ExitCode.CONFLICT,
            )

        _out.info(f"[blue]启动服务 '{name}'...[/blue]")

        # 准备环境
        env = os.environ.copy()
        env.update(service_info.get('env_vars', {}))

        working_dir = service_info.get('working_dir', os.getcwd())
        command = service_info['command']

        if detach:
            process = subprocess.Popen(
                command,
                shell=True,
                cwd=working_dir,
                env=env,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True
            )

            time.sleep(2)
            if process.poll() is None:
                config[name]['pid'] = process.pid
                config[name]['last_started'] = str(time.time())
                self._save_services_config(config)

                _out.info(f"[green]服务 '{name}' 已启动 (PID: {process.pid})[/green]")
                _out.success({"name": name, "action": "started", "pid": process.pid})
            else:
                raise CLIError("start_failed", f"服务 '{name}' 启动失败")
        else:
            _out.info(f"在前台运行服务 '{name}'... 按 Ctrl+C 停止")
            _out.info(f"命令: {command}")
            _out.info(f"工作目录: {working_dir}")
            subprocess.run(command, shell=True, cwd=working_dir, env=env)

    @cli_command
    def stop(self, name: str, timeout: int = 10, _out: OutputFormatter = None):
        """停止服务

        Args:
            name: 服务名称
            timeout: 超时时间（秒），默认10秒
        """
        config = self._load_services_config()
        service_info = self._require_service(config, name)
        status, pid = self._get_service_status(service_info)

        if status != 'running':
            raise CLIError(
                "conflict", f"服务 '{name}' 未在运行",
                exit_code=ExitCode.CONFLICT,
            )

        _out.info(f"[blue]停止服务 '{name}' (PID: {pid})...[/blue]")

        try:
            process = psutil.Process(pid)
            process.terminate()

            forced = False
            try:
                process.wait(timeout=timeout)
            except psutil.TimeoutExpired:
                _out.warn(f"服务超时，强制终止...")
                process.kill()
                process.wait(timeout=5)
                forced = True

            # 清理PID信息
            if 'pid' in config[name]:
                del config[name]['pid']
            config[name]['last_stopped'] = str(time.time())
            self._save_services_config(config)

            _out.info(f"[green]服务 '{name}' 已{'强制' if forced else ''}停止[/green]")
            _out.success({"name": name, "action": "stopped", "pid": pid, "forced": forced})

        except psutil.NoSuchProcess:
            _out.warn(f"进程不存在，清理服务状态")
            if 'pid' in config[name]:
                del config[name]['pid']
            self._save_services_config(config)
            _out.success({"name": name, "action": "cleaned", "pid": pid})

    def restart(self, name: str):
        """重启服务

        Args:
            name: 服务名称
        """
        print(f"[blue]重启服务 '{name}'...[/blue]")
        self.stop(name)
        time.sleep(1)
        self.start(name)

    @cli_command
    def status(self, name: str = None, _out: OutputFormatter = None):
        """显示服务状态

        Args:
            name: 服务名称，不指定则显示所有服务状态

        Examples:
            maque service status
            maque service status my-api
            maque service status my-api --format=json
        """
        config = self._load_services_config()

        if not config:
            _out.success({"services": []})
            return

        if name:
            service_info = self._require_service(config, name)
            svc_status, pid = self._get_service_status(service_info)

            detail = {
                "name": name,
                "status": svc_status,
                "command": service_info.get('command', 'N/A'),
                "working_dir": service_info.get('working_dir', 'N/A'),
            }
            if pid:
                detail["pid"] = pid
            if service_info.get('port'):
                detail["port"] = service_info['port']
            if service_info.get('description'):
                detail["description"] = service_info['description']
            if service_info.get('last_started'):
                detail["last_started"] = time.strftime(
                    '%Y-%m-%d %H:%M:%S',
                    time.localtime(float(service_info['last_started']))
                )
            if service_info.get('last_stopped'):
                detail["last_stopped"] = time.strftime(
                    '%Y-%m-%d %H:%M:%S',
                    time.localtime(float(service_info['last_stopped']))
                )
            _out.success(detail)
        else:
            self.list(status=True)

    def logs(self, name: str, lines: int = 50, follow: bool = False):
        """查看服务日志

        Args:
            name: 服务名称
            lines: 显示行数，默认50行
            follow: 是否持续跟踪日志，默认False
        """
        config = self._load_services_config()

        if name not in config:
            print(f"[red]服务 '{name}' 不存在[/red]")
            return

        service_info = config[name]
        log_file = Path.home() / '.maque' / 'logs' / f'{name}.log'

        if not log_file.exists():
            print(f"[yellow]服务 '{name}' 的日志文件不存在[/yellow]")
            print(f"预期位置: {log_file}")
            return

        try:
            if follow:
                print(f"[blue]跟踪服务 '{name}' 的日志 (按 Ctrl+C 停止)[/blue]\n")
                subprocess.run(['tail', '-f', str(log_file)])
            else:
                print(f"[blue]服务 '{name}' 的最近 {lines} 行日志[/blue]\n")
                with open(log_file, 'r', encoding='utf-8') as f:
                    all_lines = f.readlines()
                    recent_lines = all_lines[-lines:] if len(all_lines) > lines else all_lines

                    for line in recent_lines:
                        print(line.rstrip())

        except KeyboardInterrupt:
            print(f"\n[yellow]停止跟踪日志[/yellow]")
        except Exception as e:
            print(f"[red]读取日志失败: {e}[/red]")

    @cli_command
    def health(self, name: str = None, _out: OutputFormatter = None):
        """检查服务健康状态

        Args:
            name: 服务名称，不指定则检查所有服务

        Examples:
            maque service health
            maque service health my-api
            maque service health --format=json
        """
        config = self._load_services_config()

        if not config:
            _out.success({"services": []})
            return

        services_to_check = [name] if name else list(config.keys())

        headers = ["服务名", "状态", "端口检查", "响应时间"]
        rows = []
        results = []

        for service_name in services_to_check:
            if service_name not in config:
                continue

            service_info = config[service_name]
            svc_status, pid = self._get_service_status(service_info)

            port_ok = None
            resp_time = None

            if service_info.get('port'):
                port_ok, resp_time = self._check_port_health(service_info['port'])

            port_display = "N/A"
            time_display = "N/A"
            if port_ok is not None:
                port_display = "正常" if port_ok else "异常"
                time_display = f"{resp_time:.2f}ms" if resp_time else "N/A"

            rows.append([service_name, svc_status, port_display, time_display])
            results.append({
                "name": service_name,
                "status": svc_status,
                "port_healthy": port_ok,
                "response_time_ms": round(resp_time, 2) if resp_time else None,
            })

        if _out.is_json:
            _out.success({"services": results})
        else:
            _out.table(headers, rows, title="服务健康检查")
