"""vLLM 服务配置命令组"""

from rich import print
from rich.console import Console


_CONFIG_TEMPLATE = """\
# ============================================================
# vLLM Serve 配置文件
# 用法: vllm serve --config {filename}
# 参数优先级: 命令行 > 配置文件 > 默认值
# 完整参数: vllm serve --help
# ============================================================

# 模型路径或 HuggingFace 模型名
model: {model}

# ---------- 服务 ----------
host: "0.0.0.0"
port: 8000
# api-key: null                   # API 鉴权密钥，设置后客户端需带 Authorization header
# served-model-name: null         # 对外暴露的模型名，默认同 model

# ---------- 推理 ----------
dtype: auto                       # auto / half / float16 / bfloat16 / float32
# max-model-len: 32768            # 最大上下文长度，默认读取模型 config
gpu-memory-utilization: 0.9       # GPU 显存占用比例 (0-1)
trust-remote-code: true
# enforce-eager: false            # 禁用 CUDA Graph，调试时开启
# seed: 0                         # 随机种子

# ---------- Reasoning / Thinking ----------
# reasoning-parser: null           # 推理解析器: qwen3 / deepseek_r1 / granite

# ---------- Tool Calling ----------
# enable-auto-tool-choice: false   # 启用自动工具调用
# tool-call-parser: null           # 解析器: hermes / llama3_json / mistral / qwen3_coder

# ---------- 推测解码 ----------
# speculative-config: '{{"method":"qwen3_next_mtp","num_speculative_tokens":1}}'
#                                  # Qwen3.5 原生 MTP 加速，num_speculative_tokens 建议 1-3
#                                  # 传统草稿模型: '{{"method":"draft_model","model":"small-model","num_speculative_tokens":5}}'

# ---------- 并行 ----------
# tensor-parallel-size: 1         # 张量并行卡数，需能整除 attention heads
# pipeline-parallel-size: 1       # 流水线并行（跨节点时用）

# ---------- 调度 ----------
# max-num-seqs: 256               # 最大并发序列数
# max-num-batched-tokens: null    # 每次迭代最大 token 数
# enable-chunked-prefill: null    # 分块预填充，长序列场景有效
# enable-prefix-caching: false    # 前缀缓存，重复 system prompt 场景大幅提速
# cpu-offload-gb: 0               # 模型权重卸载到 CPU 的空间 (GiB)

# ---------- 多模态 ----------
# limit-mm-per-prompt: null       # 每个 prompt 最大媒体数，如 "image=4"
# language-model-only: false      # 多模态模型只加载文本部分，跳过视觉模块

# ---------- LoRA ----------
# enable-lora: false              # 启用 LoRA 适配器
# max-loras: 1                    # 同时加载的 LoRA 数量
# max-lora-rank: 16               # 最大 LoRA rank (可选: 1/8/16/32/64/128/256/512)
# lora-modules:                   # LoRA 模块列表
#   - name: "adapter-1"
#     path: "/path/to/lora1"
#   - name: "adapter-2"
#     path: "/path/to/lora2"

# ---------- 量化 ----------
# quantization: null               # awq / gptq / fp8 / marlin / bitsandbytes 等
# kv-cache-dtype: auto             # kv cache 精度: auto / fp8

# ---------- 模板与 Tokenizer ----------
# chat-template: null              # 自定义 Jinja2 聊天模板路径
# tokenizer: null                  # 自定义 tokenizer（默认同 model）
# hf-overrides: null               # 覆盖模型 HF config，JSON 格式
# response-role: "assistant"       # 响应中的 role 字段

# ---------- 日志 ----------
# enable-log-requests: false       # 记录请求详情，生产环境建议关闭
# max-log-len: null                # 截断请求日志中的 prompt/output 长度
# uvicorn-log-level: info          # debug / info / warning / error
"""


class VllmGroup:
    """vLLM 配置管理

    生成和管理 vLLM serve 的 YAML 配置文件。
    """

    def __init__(self, cli_instance):
        self.cli = cli_instance
        self.console = Console()

    def gen_config(
        self,
        model: str = "your-org/your-model",
        output: str = "vllm_serve.yaml",
    ):
        """生成 vLLM serve 配置文件

        生成带注释的 YAML 配置模板，修改后直接用于 vllm serve --config。

        Args:
            model: 模型名称或路径
            output: 输出文件路径，默认 vllm_serve.yaml

        Examples:
            maque vllm gen-config --model=Qwen/Qwen2.5-7B-Instruct
            maque vllm gen-config --model=Qwen/Qwen2.5-7B-Instruct -o serve.yaml
        """
        from pathlib import Path

        content = _CONFIG_TEMPLATE.format(model=model, filename=output)

        path = Path(output)
        if path.exists():
            print(f"[yellow]文件已存在: {output}，将覆盖[/yellow]")

        path.write_text(content, encoding="utf-8")

        print(f"[green]已生成: {output}[/green]")
        print(f"[dim]使用: vllm serve --config {output}[/dim]")
