"""统一输出格式化器

核心契约：stdout = 结构化数据（Agent 消费），stderr = 诊断信息（人类查看）。
支持 JSON / TABLE / PLAIN 三种格式，自动 TTY 检测。
"""
from __future__ import annotations

import json
import os
import sys
from enum import Enum


class OutputFormat(str, Enum):
    JSON = "json"
    TABLE = "table"
    PLAIN = "plain"


class OutputFormatter:
    """统一输出管理器

    使用方式：
        out = OutputFormatter()
        out.info("正在处理...")        # → stderr（诊断）
        out.success({"ip": "10.0.0.1"}) # → stdout（数据）
        out.table(["名称", "端口"], rows) # → stdout（表格数据）
    """

    def __init__(self, format: OutputFormat = None):
        if format is not None:
            self.format = OutputFormat(format)
        else:
            env_format = os.environ.get("MAQUE_OUTPUT_FORMAT", "").lower()
            if env_format in ("json", "table", "plain"):
                self.format = OutputFormat(env_format)
            elif sys.stdout.isatty():
                self.format = OutputFormat.TABLE
            else:
                self.format = OutputFormat.JSON

    @property
    def is_json(self) -> bool:
        return self.format == OutputFormat.JSON

    @property
    def is_tty(self) -> bool:
        return sys.stdout.isatty()

    def success(self, data: dict | list):
        """输出结构化数据到 stdout"""
        if self.is_json:
            json.dump(data, sys.stdout, ensure_ascii=False, default=str)
            sys.stdout.write("\n")
            sys.stdout.flush()
        else:
            # TABLE/PLAIN 模式：如果是 dict/list，尝试友好展示
            if isinstance(data, dict):
                self._print_dict(data)
            elif isinstance(data, list):
                self._print_list(data)
            else:
                print(data)

    def table(self, headers: list[str], rows: list[list], title: str = None):
        """输出表格数据到 stdout"""
        if self.is_json:
            records = [dict(zip(headers, row)) for row in rows]
            json.dump(records, sys.stdout, ensure_ascii=False, default=str)
            sys.stdout.write("\n")
            sys.stdout.flush()
        elif self.format == OutputFormat.PLAIN:
            if title:
                print(title)
            for row in rows:
                print("\t".join(str(c) for c in row))
        else:
            from rich.table import Table as RichTable
            from rich.console import Console
            t = RichTable(title=title, show_header=True, header_style="bold magenta")
            for h in headers:
                t.add_column(h)
            for row in rows:
                t.add_row(*(str(c) for c in row))
            Console().print(t)

    def info(self, message: str):
        """诊断信息 → stderr（JSON 模式下静默）"""
        if self.is_json:
            return
        if self.is_tty and os.environ.get("NO_COLOR") is None:
            from rich import print as rprint
            rprint(message, file=sys.stderr)
        else:
            # 去除 Rich 标记
            clean = _strip_rich_markup(message)
            print(clean, file=sys.stderr)

    def warn(self, message: str):
        """警告信息 → stderr"""
        if self.is_json:
            return
        if self.is_tty and os.environ.get("NO_COLOR") is None:
            from rich import print as rprint
            rprint(f"[yellow]{message}[/yellow]", file=sys.stderr)
        else:
            clean = _strip_rich_markup(message)
            print(f"WARNING: {clean}", file=sys.stderr)

    def _print_dict(self, data: dict):
        """TTY 模式下友好展示 dict"""
        if self.format == OutputFormat.PLAIN:
            for k, v in data.items():
                print(f"{k}: {v}")
        else:
            from rich import print as rprint
            rprint(data)

    def _print_list(self, data: list):
        """TTY 模式下友好展示 list"""
        if not data:
            return
        if isinstance(data[0], dict):
            # list of dicts → 表格
            headers = list(data[0].keys())
            rows = [[item.get(h, "") for h in headers] for item in data]
            self.table(headers, rows)
        else:
            for item in data:
                print(item)


def _strip_rich_markup(text: str) -> str:
    """去除 Rich 标记，如 [green]...[/green] → ..."""
    import re
    return re.sub(r'\[/?[^\]]*\]', '', text)
