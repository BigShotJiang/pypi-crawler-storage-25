"""TTY 兼容工具

提供交互式终端检测和安全的确认提示，防止非 TTY 环境下挂起。
"""
from __future__ import annotations

import os
import sys


def is_interactive() -> bool:
    """检测是否在交互式终端中运行"""
    if not sys.stdin.isatty():
        return False
    if os.environ.get("CI"):
        return False
    if os.environ.get("MAQUE_NON_INTERACTIVE"):
        return False
    return True


def confirm(prompt: str, default: bool = False) -> bool:
    """TTY 安全的确认提示

    交互式终端：显示提示等待用户输入
    非交互式：直接返回 default，不挂起
    """
    if not is_interactive():
        return default

    suffix = " (Y/n): " if default else " (y/N): "
    try:
        response = input(prompt + suffix).strip().lower()
    except (EOFError, KeyboardInterrupt):
        return default

    if not response:
        return default
    return response in ("y", "yes")
