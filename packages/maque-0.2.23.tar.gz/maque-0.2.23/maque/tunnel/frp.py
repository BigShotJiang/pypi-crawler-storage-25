"""frp 后端 - 基于 TCP 的高性能内网穿透"""
from __future__ import annotations

import json
import os
import platform
import subprocess
import sys
import tarfile
import tempfile
import urllib.request
from io import BytesIO
from pathlib import Path

from rich import print


def _get_frp_path(component: str = "frpc"):
    """获取 frp 二进制路径，优先 PATH，其次 ~/.maque/bin/

    Args:
        component: frps 或 frpc
    """
    import shutil

    exe_name = f"{component}.exe" if sys.platform == "win32" else component
    found = shutil.which(exe_name)
    if found:
        return found

    local = Path.home() / ".maque" / "bin" / exe_name
    if local.exists():
        return str(local)
    return None


def _download_frp(use_mirror: bool = None):
    """从 GitHub 下载 frp 二进制（frps + frpc），返回安装目录或 None"""
    system = platform.system().lower()
    machine = platform.machine().lower()

    os_map = {"linux": "linux", "darwin": "darwin", "windows": "windows"}
    arch_map = {
        "x86_64": "amd64",
        "amd64": "amd64",
        "aarch64": "arm64",
        "arm64": "arm64",
    }

    os_name = os_map.get(system)
    arch = arch_map.get(machine)

    if not os_name or not arch:
        print(f"[red]不支持的平台: {system}/{machine}[/red]")
        print("请手动下载: https://github.com/fatedier/frp/releases")
        return None

    print("[dim]正在获取最新版本...[/dim]")
    api_url = "https://api.github.com/repos/fatedier/frp/releases/latest"
    try:
        req = urllib.request.Request(api_url, headers={"User-Agent": "maque"})
        with urllib.request.urlopen(req, timeout=15) as resp:
            release_info = json.loads(resp.read())
        version = release_info["tag_name"].lstrip("v")
    except Exception as e:
        print(f"[red]获取版本信息失败: {e}[/red]")
        return None

    ext = "zip" if os_name == "windows" else "tar.gz"
    filename = f"frp_{version}_{os_name}_{arch}.{ext}"
    raw_url = f"https://github.com/fatedier/frp/releases/download/v{version}/{filename}"

    mirror_url = None
    try:
        from maque.git import convert_to_mirror_url

        mirror_url = convert_to_mirror_url(raw_url)
        if mirror_url == raw_url:
            mirror_url = None
    except ImportError:
        pass

    if use_mirror is True and mirror_url:
        urls = [mirror_url]
    elif use_mirror is False:
        urls = [raw_url]
    else:
        urls = [raw_url]
        if mirror_url:
            urls.append(mirror_url)

    bin_dir = Path.home() / ".maque" / "bin"
    bin_dir.mkdir(parents=True, exist_ok=True)

    print(f"[blue]下载 frp v{version} ({os_name}/{arch})...[/blue]")

    for i, url in enumerate(urls):
        if i > 0:
            print("[yellow]直连失败，尝试镜像...[/yellow]")
        print(f"[dim]{url}[/dim]")

        try:
            req = urllib.request.Request(url, headers={"User-Agent": "maque"})
            with urllib.request.urlopen(req, timeout=120) as resp:
                data = resp.read()

            if os_name == "windows":
                import zipfile

                with zipfile.ZipFile(BytesIO(data)) as zf:
                    for component in ("frps", "frpc"):
                        exe = f"{component}.exe"
                        matches = [n for n in zf.namelist() if n.endswith(exe)]
                        if matches:
                            with open(bin_dir / exe, "wb") as f:
                                f.write(zf.read(matches[0]))
            else:
                with tarfile.open(fileobj=BytesIO(data), mode="r:gz") as tf:
                    for component in ("frps", "frpc"):
                        matches = [
                            m for m in tf.getmembers()
                            if m.name.endswith(f"/{component}") and m.isfile()
                        ]
                        if matches:
                            extracted = tf.extractfile(matches[0])
                            dest = bin_dir / component
                            with open(dest, "wb") as f:
                                f.write(extracted.read())
                            os.chmod(dest, 0o755)

            print(f"[green]frp 已安装到 {bin_dir}[/green]")
            print(f"[dim]  frps: {bin_dir / 'frps'}[/dim]")
            print(f"[dim]  frpc: {bin_dir / 'frpc'}[/dim]")
            return str(bin_dir)

        except Exception as e:
            print(f"[red]下载失败: {e}[/red]")
            if i < len(urls) - 1:
                continue

    print("请手动下载: https://github.com/fatedier/frp/releases")
    return None


def _ensure_frp(component: str = "frpc"):
    """确保 frp 可用，不可用时自动下载"""
    path = _get_frp_path(component)
    if path:
        return path
    print(f"[yellow]{component} 未找到，正在自动下载...[/yellow]")
    result = _download_frp()
    if result:
        return _get_frp_path(component)
    return None


def _generate_server_config(port: int, host: str, auth: str = None) -> str:
    """生成 frps 配置内容"""
    lines = [
        f'bindAddr = "{host}"',
        f"bindPort = {port}",
    ]
    if auth:
        lines.extend([
            "",
            '[auth]',
            'method = "token"',
            f'token = "{auth}"',
        ])
    return "\n".join(lines) + "\n"


def _generate_client_config(
    server: str,
    mappings: list[tuple[int, str, int]],
    auth: str = None,
) -> str:
    """生成 frpc 配置内容"""
    parts = server.split(":")
    host = parts[0]
    port = parts[1] if len(parts) > 1 else "7000"

    lines = [
        f'serverAddr = "{host}"',
        f"serverPort = {port}",
    ]
    if auth:
        lines.extend([
            "",
            '[auth]',
            'method = "token"',
            f'token = "{auth}"',
        ])

    for i, (remote_port, target_host, target_port) in enumerate(mappings):
        lines.extend([
            "",
            f"[[proxies]]",
            f'name = "tunnel-{i}"',
            f'type = "tcp"',
            f'localIP = "{target_host}"',
            f"localPort = {target_port}",
            f"remotePort = {remote_port}",
        ])

    return "\n".join(lines) + "\n"


def frp_server(port: int = 7000, host: str = "0.0.0.0", auth: str = None):
    """启动 frp server"""
    frps = _ensure_frp("frps")
    if not frps:
        return

    config_content = _generate_server_config(port, host, auth)

    tmp = tempfile.NamedTemporaryFile(
        mode="w", suffix=".toml", prefix="frps_", delete=False
    )
    try:
        tmp.write(config_content)
        tmp.close()

        cmd = [frps, "-c", tmp.name]

        print(f"[green]启动 frp server，监听 {host}:{port}[/green]")
        print(f"[dim]客户端连接: maque tunnel client <本机IP>:{port} <远程端口>:<本地端口> --method=frp[/dim]")
        if auth:
            print(f"[dim]认证已开启[/dim]")
        print(f"[dim]按 Ctrl+C 停止[/dim]\n")

        subprocess.run(cmd)
    except KeyboardInterrupt:
        print("\n[yellow]服务已停止[/yellow]")
    except FileNotFoundError:
        print(f"[red]找不到 frps: {frps}[/red]")
    finally:
        os.unlink(tmp.name)


def frp_client(
    server: str, mappings: list[tuple[int, str, int]], auth: str = None
):
    """启动 frp client

    Args:
        server: 服务器地址 host:port
        mappings: [(remote_port, target_host, target_port), ...]
        auth: 认证 token
    """
    frpc = _ensure_frp("frpc")
    if not frpc:
        return

    config_content = _generate_client_config(server, mappings, auth)

    tmp = tempfile.NamedTemporaryFile(
        mode="w", suffix=".toml", prefix="frpc_", delete=False
    )
    try:
        tmp.write(config_content)
        tmp.close()

        server_host = server.split(":")[0]
        for remote_port, target_host, target_port in mappings:
            print(
                f"  [blue]{server_host}:{remote_port}[/blue] -> [cyan]{target_host}:{target_port}[/cyan]"
            )

        print(f"\n[green]连接到 {server}[/green]")
        print("[dim]按 Ctrl+C 断开[/dim]\n")

        subprocess.run([frpc, "-c", tmp.name])
    except KeyboardInterrupt:
        print("\n[yellow]隧道已断开[/yellow]")
    except FileNotFoundError:
        print(f"[red]找不到 frpc: {frpc}[/red]")
    finally:
        os.unlink(tmp.name)


def frp_install(use_mirror: bool = None):
    """下载/更新 frp 二进制"""
    existing = _get_frp_path("frpc")
    if existing:
        print(f"[yellow]frp 已存在: {existing}[/yellow]")
        print("[dim]重新下载以更新...[/dim]")

    result = _download_frp(use_mirror=use_mirror)
    if result:
        print(f"\n[cyan]如需拷贝到内网机器:[/cyan]")
        print(f"  scp {result}/frps {result}/frpc user@内网机器:~/.maque/bin/")
