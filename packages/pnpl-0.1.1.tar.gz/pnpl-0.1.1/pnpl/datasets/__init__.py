# Make this subpackage composition-friendly so additional modules can be added
# or override existing ones without explicit registration.
try:
    from .._namespace import extend_overlay_path as _extend_overlay_path

    __path__ = _extend_overlay_path(__path__, __name__)
except Exception:
    pass

# Lazily expose convenience imports to avoid importing heavy dependencies at
# module import time while keeping `from pnpl.datasets import LibriBrainPhoneme`
# and similar imports available.
_PUBLIC_MAP = {
    # LibriBrain dataset entry point with an explicit task parameter
    "LibriBrain": ("pnpl.datasets.libribrain2025.dataset", "LibriBrain"),

    # Dataset-specific wrappers
    "LibriBrainPhoneme": ("pnpl.datasets.libribrain2025.compat", "LibriBrainPhoneme"),
    "LibriBrainSpeech": ("pnpl.datasets.libribrain2025.compat", "LibriBrainSpeech"),
    "LibriBrainWord": ("pnpl.datasets.libribrain2025.compat", "LibriBrainWord"),
    "LibriBrainSentence": ("pnpl.datasets.libribrain2025.sentence_dataset", "LibriBrainSentence"),

    # LibriBrain100 — union of pnpl/LibriBrain + pnpl/LibriBrain2
    "LibriBrain100": ("pnpl.datasets.libribrain100.dataset", "LibriBrain100"),
    "LibriBrain100Speech": ("pnpl.datasets.libribrain100.compat", "LibriBrain100Speech"),
    "LibriBrain100Phoneme": ("pnpl.datasets.libribrain100.compat", "LibriBrain100Phoneme"),
    "LibriBrain100Word": ("pnpl.datasets.libribrain100.compat", "LibriBrain100Word"),

    # MEG-MASC (Gwilliams et al., 2022) — auto-downloads from OSF
    "Gwilliams2022": ("pnpl.datasets.gwilliams2022.dataset", "Gwilliams2022"),

    # Armeni et al. (2022) — Radboud Data Repository (auth required)
    "Armeni2022": ("pnpl.datasets.armeni2022.dataset", "Armeni2022"),

    # Schöffelen et al. (2019) "MOUS" — Radboud Data Repository (auth required)
    "Schoffelen2019": ("pnpl.datasets.schoffelen2019.dataset", "Schoffelen2019"),

    # Pallier et al. (2025) "LittlePrince — Listen" — OpenNeuro ds007523
    "Pallier2025": ("pnpl.datasets.pallier2025.dataset", "Pallier2025"),

    # Utilities
    "GroupedDataset": ("pnpl.datasets.grouped_dataset", "GroupedDataset"),
}

__all__ = list(_PUBLIC_MAP.keys())

def __getattr__(name):  # pragma: no cover - import-time hook
    if name in _PUBLIC_MAP:
        modname, attr = _PUBLIC_MAP[name]
        from importlib import import_module
        mod = import_module(modname)
        return getattr(mod, attr)

    # Fallback to optional additional re-exports when available
    try:
        from importlib import import_module
        priv = import_module("pnpl.datasets._private_exports")
        return getattr(priv, name)
    except Exception as _e:
        raise AttributeError(name) from _e

def __dir__():  # pragma: no cover - import-time hook
    names = set(__all__)
    try:
        from importlib import import_module
        priv = import_module("pnpl.datasets._private_exports")
        names.update(n for n in dir(priv) if not n.startswith("_"))
    except Exception:
        pass
    return sorted(names)
