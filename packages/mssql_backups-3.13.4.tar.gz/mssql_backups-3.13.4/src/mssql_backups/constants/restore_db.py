# Restaurar desde .bak sql server

SQL_COMMAND = (
    "RESTORE DATABASE [{DB_NAME}] "
    "FROM DISK = '{BACKUP_PATH}' "
    "WITH MOVE '{LOGICAL_NAME_DATA}' TO '{DATA_PATH}', "
    "MOVE '{LOGICAL_NAME_LOG}' TO '{LOG_PATH}', "
    "REPLACE, RECOVERY"
)
