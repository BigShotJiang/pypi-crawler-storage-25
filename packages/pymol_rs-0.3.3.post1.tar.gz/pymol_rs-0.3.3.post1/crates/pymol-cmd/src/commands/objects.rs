//! Object commands: delete, rename, create, copy, group, ungroup

use pymol_mol::dss::{assign_secondary_structure, assigner_for};
use pymol_mol::{AtomIndex, ObjectMolecule};
use pymol_scene::{DirtyFlags, MoleculeObject};

use crate::args::{ArgValue, ParsedCommand};
use crate::command::{ArgHint, Command, CommandContext, CommandRegistry, ViewerLike};
use crate::helpers::state_index_from_user;
use crate::commands::selecting::evaluate_selection;
use crate::error::{CmdError, CmdResult};

/// Parse a members string into individual name patterns
///
/// Members can be space-separated or comma-separated.
fn parse_members(members_str: &str) -> Vec<String> {
    if members_str.is_empty() {
        return Vec::new();
    }
    members_str
        .split([' ', ','])
        .map(|s| s.trim())
        .filter(|s| !s.is_empty())
        .map(|s| s.to_string())
        .collect()
}

/// Resolve member patterns against the object registry
///
/// Expands glob patterns (e.g., `lig*`) using `registry.matching()`.
fn resolve_members(registry: &pymol_scene::ObjectRegistry, patterns: &[String]) -> Vec<String> {
    let mut result = Vec::new();
    for pattern in patterns {
        if pattern.contains('*') || pattern == "all" {
            result.extend(
                registry
                    .matching(pattern)
                    .into_iter()
                    .map(|s| s.to_string()),
            );
        } else if registry.contains(pattern) {
            result.push(pattern.clone());
        }
    }
    result
}

/// Recursively collect all descendants of a group (children, grandchildren, etc.)
///
/// Results are added depth-first so children are deleted before their parents.
fn collect_group_descendants(
    registry: &pymol_scene::ObjectRegistry,
    name: &str,
    result: &mut Vec<String>,
) {
    if let Some(group) = registry.get_group(name) {
        for child in group.children().to_vec() {
            collect_group_descendants(registry, &child, result);
            result.push(child);
        }
    }
}

/// Register object commands
pub fn register(registry: &mut CommandRegistry) {
    registry.register(DeleteCommand);
    registry.register(RenameCommand);
    registry.register(CreateCommand);
    registry.register(CopyCommand);
    registry.register(GroupCommand);
    registry.register(UngroupCommand);
    registry.register(StateCommand);
    registry.register(CountStatesCommand);
    registry.register(SplitStatesCommand);
    registry.register(DeleteStatesCommand);
    registry.register(ExtractCommand);
    registry.register(RemoveCommand);
    registry.register(DssCommand);
}

// ============================================================================
// delete command
// ============================================================================

struct DeleteCommand;

impl Command for DeleteCommand {
    fn name(&self) -> &str {
        "delete"
    }

    fn arg_hints(&self) -> &[ArgHint] {
        &[ArgHint::Selection]
    }

    fn help(&self) -> &str {
        r#"
DESCRIPTION

    "delete" removes objects and/or named selections.

USAGE

    delete name

ARGUMENTS

    name = string: object or selection name (supports glob patterns)

EXAMPLES

    delete protein
    delete obj*
    delete sele
    delete all
"#
    }

    fn execute<'v, 'r>(&self, ctx: &mut CommandContext<'v, 'r, dyn ViewerLike + 'v>, args: &ParsedCommand) -> CmdResult {
        let name = args.str_arg(0, "name")
            .ok_or_else(|| CmdError::MissingArgument("name".to_string()))?;

        let mut deleted_objects = 0usize;
        let mut deleted_selections = 0usize;

        // Delete matching objects
        let obj_matches: Vec<String> = ctx
            .viewer
            .objects()
            .matching(name)
            .iter()
            .map(|s| s.to_string())
            .collect();

        // Expand groups to include their descendants
        let mut to_delete = Vec::new();
        for obj_name in &obj_matches {
            collect_group_descendants(ctx.viewer.objects(), obj_name, &mut to_delete);
            to_delete.push(obj_name.clone());
        }
        // Deduplicate (a child might already be in obj_matches)
        to_delete.dedup();

        for obj_name in &to_delete {
            ctx.viewer.objects_mut().remove(obj_name);
            deleted_objects += 1;
        }

        // Delete matching named selections
        let matching_sels: Vec<String> = ctx.viewer.selections().matching(name)
            .iter().map(|s| s.to_string()).collect();
        for sel_name in &matching_sels {
            ctx.viewer.remove_selection(sel_name);
            deleted_selections += 1;
        }

        let total = deleted_objects + deleted_selections;
        if total == 0 {
            return Err(CmdError::ObjectNotFound(name.to_string()));
        }

        if deleted_objects > 0 {
            ctx.viewer.update_movie_state_count();
        }
        ctx.viewer.request_redraw();

        if !ctx.quiet {
            match (deleted_objects, deleted_selections) {
                (1, 0) => ctx.print(&format!(" Deleted \"{}\"", name)),
                (o, 0) => ctx.print(&format!(" Deleted {} objects matching \"{}\"", o, name)),
                (0, 1) => ctx.print(&format!(" Deleted selection \"{}\"", name)),
                (0, s) => ctx.print(&format!(" Deleted {} selections matching \"{}\"", s, name)),
                (o, s) => ctx.print(&format!(" Deleted {} objects and {} selections matching \"{}\"", o, s, name)),
            }
        }

        Ok(())
    }
}

// ============================================================================
// rename command (also: set_name)
// ============================================================================

struct RenameCommand;

impl Command for RenameCommand {
    fn name(&self) -> &str {
        "set_name"
    }

    fn aliases(&self) -> &[&str] {
        &["rename"]
    }

    fn help(&self) -> &str {
        r#"
DESCRIPTION

    "set_name" renames an object or selection.

USAGE

    set_name old_name, new_name

ARGUMENTS

    old_name = string: current object or selection name
    new_name = string: new name

EXAMPLES

    set_name protein, myprotein
    rename ligand, drug
"#
    }

    fn arg_hints(&self) -> &[ArgHint] {
        &[ArgHint::Object, ArgHint::None]
    }

    fn execute<'v, 'r>(&self, ctx: &mut CommandContext<'v, 'r, dyn ViewerLike + 'v>, args: &ParsedCommand) -> CmdResult {
        let old_name = args.str_arg(0, "old_name")
            .ok_or_else(|| CmdError::MissingArgument("old_name".to_string()))?;
        let new_name = args.str_arg(1, "new_name")
            .ok_or_else(|| CmdError::MissingArgument("new_name".to_string()))?;

        // Try renaming as an object first, then as a selection
        let renamed = match ctx.viewer.objects_mut().rename(old_name, new_name) {
            Ok(()) => true,
            Err(_) => ctx.viewer.rename_selection(old_name, new_name),
        };

        if !renamed {
            return Err(CmdError::ObjectNotFound(old_name.to_string()));
        }

        if !ctx.quiet {
            ctx.print(&format!(" Renamed \"{}\" to \"{}\"", old_name, new_name));
        }

        Ok(())
    }
}

// ============================================================================
// create command
// ============================================================================

struct CreateCommand;

impl Command for CreateCommand {
    fn name(&self) -> &str {
        "create"
    }

    fn arg_hints(&self) -> &[ArgHint] {
        &[ArgHint::None, ArgHint::Selection]
    }

    fn help(&self) -> &str {
        r#"
DESCRIPTION

    "create" creates a new object from a selection.

USAGE

    create name, selection [, source_state [, target_state [, discrete ]]]

ARGUMENTS

    name = string: name for the new object
    selection = string: selection of atoms to include
    source_state = integer: state to copy from (default: 0 = all)
    target_state = integer: state to copy to (default: 0)
    discrete = 0/1: create discrete states (default: 0)

EXAMPLES

    create chainA, chain A
    create ligand, organic
"#
    }

    fn execute<'v, 'r>(&self, ctx: &mut CommandContext<'v, 'r, dyn ViewerLike + 'v>, args: &ParsedCommand) -> CmdResult {
        let name = args.str_arg(0, "name")
            .ok_or_else(|| CmdError::MissingArgument("name".to_string()))?;
        let selection = args.str_arg(1, "selection")
            .ok_or_else(|| CmdError::MissingArgument("selection".to_string()))?;
        let source_state = args.int_arg_or(2, "source_state", 0);

        // Evaluate selection
        let results = evaluate_selection(ctx.viewer, selection)?;

        // Find first object with selected atoms
        let (src_name, sel_result) = results
            .into_iter()
            .find(|(_, sel)| sel.count() > 0)
            .ok_or_else(|| {
                CmdError::Selection(format!("No atoms matching '{}'", selection))
            })?;

        let state_opt = state_index_from_user(source_state);

        // Get source molecule and its representations (read-only borrow)
        let (new_mol, source_reps) = {
            let mol_obj = ctx
                .viewer
                .objects()
                .get_molecule(&src_name)
                .ok_or_else(|| CmdError::ObjectNotFound(src_name.clone()))?;
            let src_mol = mol_obj.molecule();

            (extract_molecule(src_mol, &sel_result, name, state_opt), mol_obj.visible_reps())
        };

        let atom_count = new_mol.atom_count();
        let mut mol_obj = MoleculeObject::from_raw_with_name(new_mol, name);
        mol_obj.set_visible_reps(source_reps);
        ctx.viewer.objects_mut().add(mol_obj);
        ctx.viewer.request_redraw();

        if !ctx.quiet {
            ctx.print(&format!(
                " Created \"{}\" from \"{}\" with {} atoms",
                name, selection, atom_count
            ));
        }

        Ok(())
    }
}

/// Extract a subset of atoms from a molecule based on a selection result.
///
/// If `source_state` is `None`, all states are copied. If `Some(i)` (0-indexed),
/// only that single state is copied into the new object.
pub(crate) fn extract_molecule(
    src: &ObjectMolecule,
    selection: &pymol_select::SelectionResult,
    name: &str,
    source_state: Option<usize>,
) -> ObjectMolecule {
    use std::collections::HashMap;

    let selected_indices: Vec<AtomIndex> = selection.indices().collect();
    let mut new_mol = ObjectMolecule::with_capacity(name, selected_indices.len(), 0);

    // Build old→new atom index mapping and copy atoms
    let mut index_map: HashMap<u32, AtomIndex> = HashMap::new();
    for &old_idx in &selected_indices {
        let atom = src.get_atom(old_idx).unwrap().clone();
        let new_idx = new_mol.add_atom(atom);
        index_map.insert(old_idx.0, new_idx);
    }

    // Copy bonds where both endpoints are selected
    for bond in src.bonds() {
        if let (Some(&new_a1), Some(&new_a2)) =
            (index_map.get(&bond.atom1.0), index_map.get(&bond.atom2.0))
        {
            let _ = new_mol.add_bond(new_a1, new_a2, bond.order);
        }
    }

    // Determine which states to copy
    let states: Vec<usize> = match source_state {
        Some(s) => vec![s],
        None => (0..src.state_count()).collect(),
    };

    // Copy coordinate sets (extract coords for selected atoms only)
    for state in states {
        if let Some(cs) = src.get_coord_set(state) {
            let mut coords = Vec::with_capacity(selected_indices.len() * 3);
            for &old_idx in &selected_indices {
                if let Some(v) = cs.get_atom_coord(old_idx) {
                    coords.push(v.x);
                    coords.push(v.y);
                    coords.push(v.z);
                } else {
                    coords.extend_from_slice(&[0.0, 0.0, 0.0]);
                }
            }
            let new_cs = pymol_mol::CoordSet::from_coords(coords);
            new_mol.add_coord_set(new_cs);
        }
    }

    // Classify atoms (protein, nucleic, etc.)
    new_mol.classify_atoms();

    new_mol
}

// ============================================================================
// copy command
// ============================================================================

struct CopyCommand;

impl Command for CopyCommand {
    fn name(&self) -> &str {
        "copy"
    }

    fn arg_hints(&self) -> &[ArgHint] {
        &[ArgHint::None, ArgHint::Selection]
    }

    fn help(&self) -> &str {
        r#"
DESCRIPTION

    "copy" creates a new object from an object or selection.

USAGE

    copy target, source

ARGUMENTS

    target = string: name for the new object
    source = string: object name or selection expression

EXAMPLES

    copy protein_copy, protein
    copy active_site, byres around 5 ligand
    copy chainA, chain A
"#
    }

    fn execute<'v, 'r>(&self, ctx: &mut CommandContext<'v, 'r, dyn ViewerLike + 'v>, args: &ParsedCommand) -> CmdResult {
        let target = args.str_arg(0, "target")
            .ok_or_else(|| CmdError::MissingArgument("target".to_string()))?;
        let source = args.str_arg(1, "source")
            .ok_or_else(|| CmdError::MissingArgument("source".to_string()))?;

        // Try as full object copy first (exact name match, no selection parsing)
        if let Some(mol_obj) = ctx.viewer.objects().get_molecule(source) {
            let cloned_mol = mol_obj.molecule().clone();
            let source_reps = mol_obj.visible_reps();
            let atom_count = cloned_mol.atom_count();

            let mut new_obj = MoleculeObject::from_raw_with_name(cloned_mol, target);
            new_obj.set_visible_reps(source_reps);
            ctx.viewer.objects_mut().add(new_obj);
            ctx.viewer.request_redraw();

            if !ctx.quiet {
                ctx.print(&format!(
                    " Created \"{}\" as copy of \"{}\" ({} atoms)",
                    target, source, atom_count
                ));
            }
            return Ok(());
        }

        // Otherwise treat as selection expression (like create)
        let results = evaluate_selection(ctx.viewer, source)?;

        let (src_name, sel_result) = results
            .into_iter()
            .find(|(_, sel)| sel.count() > 0)
            .ok_or_else(|| {
                CmdError::Selection(format!("No atoms matching '{}'", source))
            })?;

        let (new_mol, source_reps) = {
            let mol_obj = ctx.viewer.objects().get_molecule(&src_name)
                .ok_or_else(|| CmdError::ObjectNotFound(src_name.clone()))?;
            (extract_molecule(mol_obj.molecule(), &sel_result, target, None), mol_obj.visible_reps())
        };

        let atom_count = new_mol.atom_count();
        let mut new_obj = MoleculeObject::from_raw_with_name(new_mol, target);
        new_obj.set_visible_reps(source_reps);
        ctx.viewer.objects_mut().add(new_obj);
        ctx.viewer.request_redraw();

        if !ctx.quiet {
            ctx.print(&format!(
                " Created \"{}\" from \"{}\" ({} atoms)",
                target, source, atom_count
            ));
        }

        Ok(())
    }
}

// ============================================================================
// group command
// ============================================================================

struct GroupCommand;

impl Command for GroupCommand {
    fn name(&self) -> &str {
        "group"
    }

    fn help(&self) -> &str {
        r#"
DESCRIPTION

    "group" creates or modifies a group of objects.

USAGE

    group name [, members [, action ]]

ARGUMENTS

    name = string: group name
    members = string: object names to add (space or comma separated)
    action = add, remove, open, close, toggle, auto, ungroup, empty,
             purge, excise (default: add)

EXAMPLES

    group proteins, obj1 obj2 obj3
    group ligands, lig*, action=add
"#
    }

    fn arg_hints(&self) -> &[ArgHint] {
        &[ArgHint::Object, ArgHint::None, ArgHint::Keywords(&["add", "remove", "open", "close", "toggle", "auto", "ungroup", "empty", "purge", "excise"])]
    }

    fn execute<'v, 'r>(&self, ctx: &mut CommandContext<'v, 'r, dyn ViewerLike + 'v>, args: &ParsedCommand) -> CmdResult {
        let name = args.str_arg(0, "name")
            .ok_or_else(|| CmdError::MissingArgument("name".to_string()))?;
        let members_str = args.str_arg_or(1, "members", "");
        let action = args.str_arg_or(2, "action", "auto");

        let member_patterns = parse_members(members_str);

        match action {
            "add" => {
                let resolved = resolve_members(ctx.viewer.objects(), &member_patterns);
                // Create group if it doesn't exist and no members were specified
                if resolved.is_empty()
                    && member_patterns.is_empty()
                    && !ctx.viewer.objects().contains(name)
                {
                    use pymol_scene::GroupObject;
                    ctx.viewer.objects_mut().add(GroupObject::new(name));
                }
                for member in &resolved {
                    ctx.viewer.objects_mut().add_to_group(name, member);
                }
                if !ctx.quiet {
                    if resolved.is_empty() && member_patterns.is_empty() {
                        ctx.print(&format!(" Created group \"{}\"", name));
                    } else {
                        ctx.print(&format!(" Added {} members to group \"{}\"", resolved.len(), name));
                    }
                }
            }
            "remove" => {
                let resolved = resolve_members(ctx.viewer.objects(), &member_patterns);
                for member in &resolved {
                    if let Some(group) = ctx.viewer.objects_mut().get_group_mut(name) {
                        group.remove_child(member);
                    }
                }
                if !ctx.quiet {
                    ctx.print(&format!(" Removed {} members from group \"{}\"", resolved.len(), name));
                }
            }
            "open" => {
                if let Some(group) = ctx.viewer.objects_mut().get_group_mut(name) {
                    group.set_open(true);
                } else {
                    return Err(CmdError::ObjectNotFound(name.to_string()));
                }
                if !ctx.quiet {
                    ctx.print(&format!(" Opened group \"{}\"", name));
                }
            }
            "close" => {
                if let Some(group) = ctx.viewer.objects_mut().get_group_mut(name) {
                    group.set_open(false);
                } else {
                    return Err(CmdError::ObjectNotFound(name.to_string()));
                }
                if !ctx.quiet {
                    ctx.print(&format!(" Closed group \"{}\"", name));
                }
            }
            "toggle" => {
                if let Some(group) = ctx.viewer.objects_mut().get_group_mut(name) {
                    group.toggle_open();
                } else {
                    return Err(CmdError::ObjectNotFound(name.to_string()));
                }
                if !ctx.quiet {
                    ctx.print(&format!(" Toggled group \"{}\"", name));
                }
            }
            "auto" => {
                if !member_patterns.is_empty() {
                    // Has members → act like "add"
                    let resolved = resolve_members(ctx.viewer.objects(), &member_patterns);
                    for member in &resolved {
                        ctx.viewer.objects_mut().add_to_group(name, member);
                    }
                    if !ctx.quiet {
                        ctx.print(&format!(" Added {} members to group \"{}\"", resolved.len(), name));
                    }
                } else if ctx.viewer.objects().get_group(name).is_some() {
                    // Group exists, no members → toggle open/close
                    if let Some(group) = ctx.viewer.objects_mut().get_group_mut(name) {
                        group.toggle_open();
                    }
                    if !ctx.quiet {
                        ctx.print(&format!(" Toggled group \"{}\"", name));
                    }
                } else {
                    // Create empty group
                    use pymol_scene::GroupObject;
                    ctx.viewer.objects_mut().add(GroupObject::new(name));
                    if !ctx.quiet {
                        ctx.print(&format!(" Created group \"{}\"", name));
                    }
                }
            }
            "empty" => {
                if let Some(group) = ctx.viewer.objects_mut().get_group_mut(name) {
                    group.clear();
                } else {
                    return Err(CmdError::ObjectNotFound(name.to_string()));
                }
                if !ctx.quiet {
                    ctx.print(&format!(" Emptied group \"{}\"", name));
                }
            }
            "purge" => {
                // Collect children, clear group, delete all child objects
                let children: Vec<String> = ctx
                    .viewer
                    .objects()
                    .get_group(name)
                    .map(|g| g.children().to_vec())
                    .unwrap_or_default();
                if let Some(group) = ctx.viewer.objects_mut().get_group_mut(name) {
                    group.clear();
                }
                for child in &children {
                    ctx.viewer.objects_mut().remove(child);
                }
                if !ctx.quiet {
                    ctx.print(&format!(" Purged group \"{}\" ({} objects deleted)", name, children.len()));
                }
            }
            "excise" | "ungroup" => {
                // Clear children (they become ungrouped), then delete the group
                if let Some(group) = ctx.viewer.objects_mut().get_group_mut(name) {
                    group.clear();
                }
                ctx.viewer.objects_mut().remove(name);
                if !ctx.quiet {
                    let verb = if action == "excise" { "Excised" } else { "Ungrouped" };
                    ctx.print(&format!(" {} group \"{}\"", verb, name));
                }
            }
            _ => {
                return Err(CmdError::InvalidArgument {
                    name: "action".to_string(),
                    reason: format!("Unknown group action: {}", action),
                });
            }
        }

        ctx.viewer.request_redraw();
        Ok(())
    }
}

// ============================================================================
// ungroup command
// ============================================================================

struct UngroupCommand;

impl Command for UngroupCommand {
    fn name(&self) -> &str {
        "ungroup"
    }

    fn help(&self) -> &str {
        r#"
DESCRIPTION

    "ungroup" removes objects from a group.

USAGE

    ungroup name

ARGUMENTS

    name = string: group name to ungroup

EXAMPLES

    ungroup proteins
"#
    }

    fn arg_hints(&self) -> &[ArgHint] {
        &[ArgHint::Object]
    }

    fn execute<'v, 'r>(&self, ctx: &mut CommandContext<'v, 'r, dyn ViewerLike + 'v>, args: &ParsedCommand) -> CmdResult {
        let name = args.str_arg(0, "name")
            .ok_or_else(|| CmdError::MissingArgument("name".to_string()))?;

        if ctx.viewer.objects().get_group(name).is_none() {
            return Err(CmdError::ObjectNotFound(name.to_string()));
        }

        // Clear children (they become ungrouped, not deleted)
        if let Some(group) = ctx.viewer.objects_mut().get_group_mut(name) {
            group.clear();
        }

        // Delete the group object itself
        ctx.viewer.objects_mut().remove(name);
        ctx.viewer.request_redraw();

        if !ctx.quiet {
            ctx.print(&format!(" Ungrouped \"{}\"", name));
        }

        Ok(())
    }
}

// ============================================================================
// state command
// ============================================================================

struct StateCommand;

impl Command for StateCommand {
    fn name(&self) -> &str {
        "state"
    }

    fn arg_hints(&self) -> &[ArgHint] {
        &[ArgHint::None, ArgHint::Object]
    }

    fn help(&self) -> &str {
        r#"
DESCRIPTION

    "state" sets the displayed state for objects.

USAGE

    state N [, object]

ARGUMENTS

    N = integer: state number (1-indexed)
    object = string: object name (default: all objects)

EXAMPLES

    state 1
    state 5, 1nmr
"#
    }

    fn execute<'v, 'r>(&self, ctx: &mut CommandContext<'v, 'r, dyn ViewerLike + 'v>, args: &ParsedCommand) -> CmdResult {
        let state_num = args.int_arg(0, "N")
            .ok_or_else(|| CmdError::MissingArgument("N".to_string()))?;

        if state_num < 1 {
            return Err(CmdError::invalid_arg("N", "State number must be >= 1"));
        }

        let state_idx = (state_num - 1) as usize;
        let object = args.str_arg(1, "object");

        if let Some(obj_name) = object {
            // Set state for a specific object
            let mol_obj = ctx.viewer.objects_mut().get_molecule_mut(obj_name)
                .ok_or_else(|| CmdError::ObjectNotFound(obj_name.to_string()))?;
            if !mol_obj.set_display_state(state_idx) {
                return Err(CmdError::execution(format!(
                    "State {} is out of range for \"{}\" ({} states)",
                    state_num, obj_name, mol_obj.molecule().state_count()
                )));
            }
        } else {
            // Set state for all objects
            let names: Vec<String> = ctx.viewer.objects().names().map(|s| s.to_string()).collect();
            for name in &names {
                if let Some(mol_obj) = ctx.viewer.objects_mut().get_molecule_mut(name) {
                    mol_obj.set_display_state(state_idx);
                }
            }
        }

        ctx.viewer.request_redraw();

        if !ctx.quiet {
            if let Some(obj_name) = object {
                ctx.print(&format!(" State {} for \"{}\"", state_num, obj_name));
            } else {
                ctx.print(&format!(" State {}", state_num));
            }
        }

        Ok(())
    }
}

// ============================================================================
// count_states command
// ============================================================================

struct CountStatesCommand;

impl Command for CountStatesCommand {
    fn name(&self) -> &str {
        "count_states"
    }

    fn arg_hints(&self) -> &[ArgHint] {
        &[ArgHint::Selection]
    }

    fn help(&self) -> &str {
        r#"
DESCRIPTION

    "count_states" reports the number of states in an object.

USAGE

    count_states [selection]

ARGUMENTS

    selection = string: object or selection (default: all)

EXAMPLES

    count_states
    count_states 1nmr
"#
    }

    fn execute<'v, 'r>(&self, ctx: &mut CommandContext<'v, 'r, dyn ViewerLike + 'v>, args: &ParsedCommand) -> CmdResult {
        let selection = args.str_arg(0, "selection");
        let mut max_states = 0usize;

        if let Some(sel) = selection {
            // Try as object name first
            if let Some(mol_obj) = ctx.viewer.objects().get_molecule(sel) {
                let count = mol_obj.molecule().state_count();
                max_states = max_states.max(count);
                if !ctx.quiet {
                    ctx.print(&format!(" \"{}\" has {} states.", sel, count));
                }
            } else {
                // Try as selection — report for all matching objects
                let results = evaluate_selection(ctx.viewer, sel)?;
                for (obj_name, sel_result) in &results {
                    if sel_result.count() > 0 {
                        if let Some(mol_obj) = ctx.viewer.objects().get_molecule(obj_name) {
                            let count = mol_obj.molecule().state_count();
                            max_states = max_states.max(count);
                            if !ctx.quiet {
                                ctx.print(&format!(" \"{}\" has {} states.", obj_name, count));
                            }
                        }
                    }
                }
            }
        } else {
            // Report for all objects
            let names: Vec<String> = ctx.viewer.objects().names().map(|s| s.to_string()).collect();
            for name in &names {
                if let Some(mol_obj) = ctx.viewer.objects().get_molecule(name) {
                    let count = mol_obj.molecule().state_count();
                    max_states = max_states.max(count);
                    if !ctx.quiet {
                        ctx.print(&format!(" \"{}\" has {} states.", name, count));
                    }
                }
            }
        }

        if !ctx.quiet {
            ctx.print(&format!(" cmd.count_states: {} states.", max_states));
        }

        Ok(())
    }
}

// ============================================================================
// split_states command
// ============================================================================

struct SplitStatesCommand;

impl Command for SplitStatesCommand {
    fn name(&self) -> &str {
        "split_states"
    }

    fn arg_hints(&self) -> &[ArgHint] {
        &[ArgHint::Object]
    }

    fn help(&self) -> &str {
        r#"
DESCRIPTION

    "split_states" creates individual objects for each state of a
    multi-state object.

USAGE

    split_states object [, first [, last [, prefix ]]]

ARGUMENTS

    object = string: source object name
    first = integer: first state (1-indexed, default: 1)
    last = integer: last state (1-indexed, default: last)
    prefix = string: name prefix (default: object_)

EXAMPLES

    split_states 1nmr
    split_states 1nmr, first=1, last=5
    split_states 1nmr, prefix=model_
"#
    }

    fn execute<'v, 'r>(&self, ctx: &mut CommandContext<'v, 'r, dyn ViewerLike + 'v>, args: &ParsedCommand) -> CmdResult {
        let object = args.str_arg(0, "object")
            .ok_or_else(|| CmdError::MissingArgument("object".to_string()))?;

        let mol_obj = ctx.viewer.objects().get_molecule(object)
            .ok_or_else(|| CmdError::ObjectNotFound(object.to_string()))?;
        let n_states = mol_obj.molecule().state_count();

        if n_states == 0 {
            return Err(CmdError::execution(format!("\"{}\" has no states", object)));
        }

        let first = args.int_arg(1, "first")
            .map(|v| (v.max(1) - 1) as usize)
            .unwrap_or(0);
        let last = args.int_arg(2, "last")
            .map(|v| (v.max(1) as usize).min(n_states))
            .unwrap_or(n_states);
        let prefix = args.str_arg(3, "prefix")
            .map(|s| s.to_string())
            .unwrap_or_else(|| format!("{}_", object));

        // Collect new molecules and source reps (borrow src as read-only)
        let (new_mols, source_reps) = {
            let mol_obj = ctx.viewer.objects().get_molecule(object).unwrap();
            let src_mol = mol_obj.molecule();
            let reps = mol_obj.visible_reps();

            // Build an "all atoms" selection
            let all_sel = pymol_select::SelectionResult::all(src_mol.atom_count());

            let mols: Vec<(String, ObjectMolecule)> = (first..last)
                .map(|state_idx| {
                    let name = format!("{}{:04}", prefix, state_idx + 1);
                    let mol = extract_molecule(src_mol, &all_sel, &name, Some(state_idx));
                    (name, mol)
                })
                .collect();
            (mols, reps)
        };

        let count = new_mols.len();
        for (name, mol) in new_mols {
            let mut mol_obj = MoleculeObject::from_raw_with_name(mol, &name);
            mol_obj.set_visible_reps(source_reps);
            ctx.viewer.objects_mut().add(mol_obj);
        }

        ctx.viewer.request_redraw();

        if !ctx.quiet {
            ctx.print(&format!(
                " Split \"{}\" into {} objects ({}{:04} to {}{:04})",
                object, count, prefix, first + 1, prefix, last
            ));
        }

        Ok(())
    }
}

// ============================================================================
// delete_states command
// ============================================================================

/// Parse state spec tokens from args starting at `from` into sorted, deduplicated
/// 0-indexed state indices.
///
/// Accepts individual states (`1 2 3`) and ranges (`1-3 9-13`). All values are
/// 1-indexed on the user side and converted to 0-indexed internally.
fn parse_state_spec(args: &ParsedCommand, from: usize) -> Result<Vec<usize>, CmdError> {
    let mut tokens = Vec::new();
    for (_, val) in args.args.iter().skip(from) {
        match val {
            ArgValue::Int(i) => tokens.push(i.to_string()),
            ArgValue::Float(f) => tokens.push(f.to_string()),
            ArgValue::String(s) => tokens.push(s.clone()),
            _ => {}
        }
    }

    if tokens.is_empty() {
        return Err(CmdError::MissingArgument("states".to_string()));
    }

    let mut indices = Vec::new();
    for token in &tokens {
        if let Some(dash_pos) = token[1..].find('-') {
            // Range like "1-3" — offset by 1 to skip possible leading digit
            let dash_pos = dash_pos + 1;
            let start: usize = token[..dash_pos].parse().map_err(|_| CmdError::InvalidArgument {
                name: "states".to_string(),
                reason: format!("invalid range start in '{}'", token),
            })?;
            let end: usize = token[dash_pos + 1..].parse().map_err(|_| CmdError::InvalidArgument {
                name: "states".to_string(),
                reason: format!("invalid range end in '{}'", token),
            })?;
            if start == 0 || end == 0 {
                return Err(CmdError::InvalidArgument {
                    name: "states".to_string(),
                    reason: "state indices are 1-based".to_string(),
                });
            }
            let (lo, hi) = if start <= end { (start, end) } else { (end, start) };
            for s in lo..=hi {
                indices.push(s - 1);
            }
        } else {
            let state: usize = token.parse().map_err(|_| CmdError::InvalidArgument {
                name: "states".to_string(),
                reason: format!("expected integer or range, got '{}'", token),
            })?;
            if state == 0 {
                return Err(CmdError::InvalidArgument {
                    name: "states".to_string(),
                    reason: "state indices are 1-based".to_string(),
                });
            }
            indices.push(state - 1);
        }
    }

    indices.sort_unstable();
    indices.dedup();
    Ok(indices)
}

struct DeleteStatesCommand;

impl Command for DeleteStatesCommand {
    fn name(&self) -> &str {
        "delete_states"
    }

    fn aliases(&self) -> &[&str] {
        &["delete_state"]
    }

    fn arg_hints(&self) -> &[ArgHint] {
        &[ArgHint::Object]
    }

    fn help(&self) -> &str {
        r#"
DESCRIPTION

    "delete_states" removes states from a multi-state object like a
    trajectory or NMR ensemble.

USAGE

    delete_states name, states

ARGUMENTS

    name = string: object name (wildcard supported)
    states = space-separated list of state numbers or ranges (1-indexed)

EXAMPLES

    delete_states 1nmr, 1-5
    delete_states *, 1-3 10-40
    delete_states traj, 1 2 3
"#
    }

    fn execute<'v, 'r>(&self, ctx: &mut CommandContext<'v, 'r, dyn ViewerLike + 'v>, args: &ParsedCommand) -> CmdResult {
        let name = args.str_arg(0, "name")
            .ok_or_else(|| CmdError::MissingArgument("name".to_string()))?;

        let indices = parse_state_spec(args, 1)?;

        let obj_names: Vec<String> = ctx
            .viewer
            .objects()
            .matching(name)
            .iter()
            .map(|s| s.to_string())
            .collect();

        if obj_names.is_empty() {
            return Err(CmdError::ObjectNotFound(name.to_string()));
        }

        let mut total_deleted = 0usize;
        let mut objects_modified = 0usize;

        for obj_name in &obj_names {
            let mol_obj = match ctx.viewer.objects_mut().get_molecule_mut(obj_name) {
                Some(m) => m,
                None => continue,
            };

            let n_states = mol_obj.molecule().state_count();
            if n_states == 0 {
                continue;
            }

            // Filter to valid indices for this object
            let valid: Vec<usize> = indices.iter().copied().filter(|&i| i < n_states).collect();
            if valid.is_empty() {
                continue;
            }

            let count = valid.len();
            mol_obj.molecule_mut().remove_states(&valid);
            total_deleted += count;
            objects_modified += 1;
        }

        if total_deleted == 0 {
            return Err(CmdError::execution("no matching states found to delete".to_string()));
        }

        ctx.viewer.update_movie_state_count();
        ctx.viewer.request_redraw();

        if !ctx.quiet {
            if objects_modified == 1 {
                ctx.print(&format!(
                    " Deleted {} state(s) from \"{}\".",
                    total_deleted, obj_names[0]
                ));
            } else {
                ctx.print(&format!(
                    " Deleted {} state(s) from {} objects.",
                    total_deleted, objects_modified
                ));
            }
        }

        Ok(())
    }
}

// ============================================================================
// extract command
// ============================================================================

struct ExtractCommand;

impl Command for ExtractCommand {
    fn name(&self) -> &str {
        "extract"
    }

    fn arg_hints(&self) -> &[ArgHint] {
        &[ArgHint::None, ArgHint::Selection]
    }

    fn help(&self) -> &str {
        r#"
DESCRIPTION

    "extract" creates a new object from a selection and removes
    those atoms from the source object.

USAGE

    extract name, selection [, source_state]

ARGUMENTS

    name = string: name for the new object
    selection = string: selection of atoms to extract
    source_state = integer: state to copy from (default: 0 = all)

EXAMPLES

    extract ligand, organic
    extract chainA, chain A
"#
    }

    fn execute<'v, 'r>(&self, ctx: &mut CommandContext<'v, 'r, dyn ViewerLike + 'v>, args: &ParsedCommand) -> CmdResult {
        let name = args.str_arg(0, "name")
            .ok_or_else(|| CmdError::MissingArgument("name".to_string()))?;
        let selection = args.str_arg(1, "selection")
            .ok_or_else(|| CmdError::MissingArgument("selection".to_string()))?;
        let source_state = args.int_arg_or(2, "source_state", 0);
        let state_opt = state_index_from_user(source_state);

        // Evaluate selection
        let results = evaluate_selection(ctx.viewer, selection)?;

        // Find first object with selected atoms
        let (src_name, sel_result) = results
            .into_iter()
            .find(|(_, sel)| sel.count() > 0)
            .ok_or_else(|| {
                CmdError::Selection(format!("No atoms matching '{}'", selection))
            })?;

        // Extract molecule from source (read-only borrow)
        let (new_mol, remove_indices) = {
            let mol_obj = ctx.viewer.objects().get_molecule(&src_name)
                .ok_or_else(|| CmdError::ObjectNotFound(src_name.clone()))?;
            let src_mol = mol_obj.molecule();

            let new_mol = extract_molecule(src_mol, &sel_result, name, state_opt);
            let remove_indices: Vec<AtomIndex> = sel_result.indices().collect();
            (new_mol, remove_indices)
        };

        let atom_count = new_mol.atom_count();

        // Copy visible representations from source object
        let source_reps = ctx.viewer.objects().get_molecule(&src_name)
            .map(|obj| obj.visible_reps())
            .unwrap_or_default();

        // Add the new object preserving per-atom representations from source
        let mut mol_obj = MoleculeObject::from_raw_with_name(new_mol, name);
        mol_obj.set_visible_reps(source_reps);
        ctx.viewer.objects_mut().add(mol_obj);

        // Remove atoms from source
        if let Some(src_obj) = ctx.viewer.objects_mut().get_molecule_mut(&src_name) {
            src_obj.molecule_mut().remove_atoms(&remove_indices);
            src_obj.invalidate(DirtyFlags::ALL);
        }

        ctx.viewer.request_redraw();

        if !ctx.quiet {
            ctx.print(&format!(
                " Extracted {} atoms from \"{}\" into \"{}\"",
                atom_count, src_name, name
            ));
        }

        Ok(())
    }
}

// ============================================================================
// remove command
// ============================================================================

struct RemoveCommand;

impl Command for RemoveCommand {
    fn name(&self) -> &str {
        "remove"
    }

    fn arg_hints(&self) -> &[ArgHint] {
        &[ArgHint::Selection]
    }

    fn help(&self) -> &str {
        r#"
DESCRIPTION

    "remove" eliminates the atoms in a selection from their respective
    molecular objects. If all atoms of an object are removed, the object
    is deleted entirely.

USAGE

    remove selection

ARGUMENTS

    selection = string: atom selection expression

EXAMPLES

    remove resn HOH
    remove elem H
    remove not polymer
    remove resi 124

SEE ALSO

    delete, extract
"#
    }

    fn execute<'v, 'r>(
        &self,
        ctx: &mut CommandContext<'v, 'r, dyn ViewerLike + 'v>,
        args: &ParsedCommand,
    ) -> CmdResult {
        let selection = args.str_arg(0, "selection")
            .ok_or_else(|| CmdError::MissingArgument("selection".to_string()))?;

        // Evaluate selection across all objects
        let results = evaluate_selection(ctx.viewer, selection)?;

        // Collect (object_name, indices_to_remove) before mutating
        let removals: Vec<(String, Vec<AtomIndex>)> = results
            .into_iter()
            .filter_map(|(obj_name, sel_result)| {
                if sel_result.count() == 0 {
                    return None;
                }
                let indices: Vec<AtomIndex> = sel_result.indices().collect();
                Some((obj_name, indices))
            })
            .collect();

        if removals.is_empty() {
            if !ctx.quiet {
                ctx.print(&format!(" No atoms selected by '{}'", selection));
            }
            return Ok(());
        }

        let mut total_removed = 0usize;
        let mut objects_to_delete: Vec<String> = Vec::new();

        // Apply removals
        for (obj_name, indices) in &removals {
            total_removed += indices.len();

            if let Some(obj) = ctx.viewer.objects_mut().get_molecule_mut(obj_name) {
                obj.molecule_mut().remove_atoms(indices);
                obj.invalidate(DirtyFlags::ALL);

                // If all atoms gone, schedule object deletion
                if obj.molecule().atom_count() == 0 {
                    objects_to_delete.push(obj_name.clone());
                }
            }
        }

        // Delete objects that lost all their atoms
        for name in &objects_to_delete {
            ctx.viewer.objects_mut().remove(name);
        }

        ctx.viewer.request_redraw();

        if !ctx.quiet {
            ctx.print(&format!(" Removed {} atom(s).", total_removed));
        }

        Ok(())
    }
}

// ============================================================================
// dss command
// ============================================================================

/// Define secondary structure using backbone geometry
struct DssCommand;

impl Command for DssCommand {
    fn name(&self) -> &str {
        "dss"
    }

    fn arg_hints(&self) -> &[ArgHint] {
        &[ArgHint::Selection]
    }

    fn help(&self) -> &str {
        r#"
DESCRIPTION

    "dss" calculates secondary structure assignments using backbone
    phi/psi dihedral angles, using the DSS algorithm.

    This overwrites any existing secondary structure assignments from
    the PDB/CIF file with computed values based on backbone geometry.

USAGE

    dss [selection [, state [, quiet ]]]

ARGUMENTS

    selection = string: atoms to process (default: all)
    state = integer: coordinate state to use (default: 1)
    quiet = 0/1: suppress feedback (default: 0)

NOTES

    The algorithm classifies residues based on phi/psi angles:
    - Alpha helix: phi ~-57°, psi ~-48°
    - Beta strand: phi ~-124°, psi ~124°

    This is automatically applied when loading structures if the
    auto_dss setting is enabled (default: on).

EXAMPLES

    dss
    dss protein
    dss all, 1, quiet=1
"#
    }

    fn execute<'v, 'r>(&self, ctx: &mut CommandContext<'v, 'r, dyn ViewerLike + 'v>, args: &ParsedCommand) -> CmdResult {
        let _selection = args.str_arg_or(0, "selection", "all");
        let state_idx = state_index_from_user(args.int_arg_or(1, "state", 1)).unwrap_or(0);
        let quiet = args.bool_arg_or(2, "quiet", false);

        // Get molecule names first to avoid borrowing conflicts
        let mol_names: Vec<String> = ctx.viewer
            .objects()
            .names()
            .map(|s| s.to_string())
            .collect();

        let algorithm = ctx.viewer.settings().behavior.dss_algorithm;
        let assigner = assigner_for(algorithm);
        let mut total_updated = 0usize;

        // Apply DSS to all molecule objects
        // TODO: Support selection filtering when selection system is more developed
        for name in mol_names {
            if let Some(mol_obj) = ctx.viewer.objects_mut().get_molecule_mut(&name) {
                let mol = mol_obj.molecule_mut();
                let updated = assign_secondary_structure(mol, state_idx, assigner.as_ref());
                total_updated += updated;
            }
        }

        ctx.viewer.request_redraw();

        if !quiet {
            ctx.print(&format!(" Assigned secondary structure to {} atoms", total_updated));
        }

        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::command::CommandContext;
    use crate::parser::parse_command;
    use pymol_mol::{AtomBuilder, BondOrder, Element};
    use pymol_scene::{MoleculeObject, Session, SessionAdapter};

    /// Create a molecule with two residues: ALA (3 atoms) and HOH (1 atom)
    fn create_test_molecule(name: &str) -> pymol_mol::ObjectMolecule {
        let mut mol = pymol_mol::ObjectMolecule::new(name);

        // ALA residue: 3 atoms (CA, CB, C)
        let ca = AtomBuilder::new()
            .name("CA")
            .element(Element::Carbon)
            .resn("ALA")
            .resv(1)
            .chain("A")
            .build();
        let cb = AtomBuilder::new()
            .name("CB")
            .element(Element::Carbon)
            .resn("ALA")
            .resv(1)
            .chain("A")
            .build();
        let c = AtomBuilder::new()
            .name("C")
            .element(Element::Carbon)
            .resn("ALA")
            .resv(1)
            .chain("A")
            .build();

        // HOH residue: 1 atom (O)
        let o = AtomBuilder::new()
            .name("O")
            .element(Element::Oxygen)
            .resn("HOH")
            .resv(2)
            .chain("A")
            .build();

        let i_ca = mol.add_atom(ca);
        let i_cb = mol.add_atom(cb);
        let i_c = mol.add_atom(c);
        let _i_o = mol.add_atom(o);

        let _ = mol.add_bond(i_ca, i_cb, BondOrder::Single);
        let _ = mol.add_bond(i_ca, i_c, BondOrder::Single);

        // Add a coordinate set
        let cs = pymol_mol::CoordSet::from_vec3(&[
            lin_alg::f32::Vec3::new(0.0, 0.0, 0.0),
            lin_alg::f32::Vec3::new(1.5, 0.0, 0.0),
            lin_alg::f32::Vec3::new(0.0, 1.5, 0.0),
            lin_alg::f32::Vec3::new(3.0, 0.0, 0.0),
        ]);
        mol.add_coord_set(cs);
        mol
    }

    fn setup_session_with(mol: pymol_mol::ObjectMolecule) -> Session {
        let mut session = Session::new();
        session.registry.add(MoleculeObject::new(mol));
        session
    }

    fn run_remove(session: &mut Session, cmd_str: &str) -> CmdResult {
        let mut needs_redraw = false;
        let mut adapter = SessionAdapter {
            session,
            render_context: None,
            default_size: (800, 600),
            needs_redraw: &mut needs_redraw,
            async_fetch_fn: None,
        };
        let parsed = parse_command(cmd_str).map_err(CmdError::Parse)?;
        let viewer: &mut dyn ViewerLike = &mut adapter;
        let mut ctx = CommandContext::new(viewer).with_quiet(true);
        RemoveCommand.execute(&mut ctx, &parsed)
    }

    #[test]
    fn test_remove_by_resn() {
        let mol = create_test_molecule("test");
        let mut session = setup_session_with(mol);

        assert_eq!(
            session.registry.get_molecule("test").unwrap().molecule().atom_count(),
            4
        );

        run_remove(&mut session, "remove resn HOH").unwrap();

        let obj = session.registry.get_molecule("test").unwrap();
        assert_eq!(obj.molecule().atom_count(), 3);
    }

    #[test]
    fn test_remove_all_deletes_object() {
        let mol = create_test_molecule("test");
        let mut session = setup_session_with(mol);

        run_remove(&mut session, "remove all").unwrap();

        assert!(session.registry.get_molecule("test").is_none());
    }

    #[test]
    fn test_remove_empty_selection() {
        let mol = create_test_molecule("test");
        let mut session = setup_session_with(mol);

        // resn GLY doesn't exist in our molecule
        run_remove(&mut session, "remove resn GLY").unwrap();

        let obj = session.registry.get_molecule("test").unwrap();
        assert_eq!(obj.molecule().atom_count(), 4);
    }

    #[test]
    fn test_remove_by_element() {
        let mol = create_test_molecule("test");
        let mut session = setup_session_with(mol);

        // Remove all oxygen atoms (the HOH water)
        run_remove(&mut session, "remove elem O").unwrap();

        let obj = session.registry.get_molecule("test").unwrap();
        assert_eq!(obj.molecule().atom_count(), 3);
    }
}
