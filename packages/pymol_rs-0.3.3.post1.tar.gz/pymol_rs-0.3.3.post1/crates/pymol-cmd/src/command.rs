//! Command trait and registry
//!
//! Defines the interface for commands and the registry that maps names to implementations.

use std::io::{Read, Write};
use std::sync::Arc;

use ahash::AHashMap;
use pymol_mol::ObjectMolecule;
use pymol_settings::{DynamicSettingDescriptor, SharedSettingStore};

use crate::history::CommandHistory;

/// A script handler registered by a plugin for a specific file extension.
///
/// Used by the `run` command to dispatch non-.pml files to the appropriate handler.
pub type ScriptHandler = Arc<dyn Fn(&str) -> Result<(), String> + Send + Sync>;

/// Factory that reads molecules from a plugin-provided file format.
///
/// The host opens the file and passes a `Box<dyn Read>`. The plugin
/// parses the content and returns molecules.
pub type PluginReaderFn =
    Arc<dyn Fn(Box<dyn Read>) -> Result<Vec<ObjectMolecule>, String> + Send + Sync>;

/// Factory that writes molecules in a plugin-provided file format.
///
/// The host opens the file and passes a `Box<dyn Write>`. The plugin
/// serializes the molecules.
pub type PluginWriterFn =
    Arc<dyn Fn(Box<dyn Write>, &[ObjectMolecule]) -> Result<(), String> + Send + Sync>;

/// A plugin-provided file format handler for `load` and `save` commands.
pub struct FormatHandler {
    /// Human-readable format name (e.g., "MMTF", "DCD")
    pub name: String,
    /// File extensions this handler supports (lowercase, no dot, e.g., `["mmtf"]`)
    pub extensions: Vec<String>,
    /// Reader factory, or `None` if the format is write-only
    pub reader: Option<PluginReaderFn>,
    /// Writer factory, or `None` if the format is read-only
    pub writer: Option<PluginWriterFn>,
}

// =============================================================================
// Dynamic setting registry
// =============================================================================

/// An entry in the dynamic setting registry: descriptor + shared store.
///
/// Cloning is cheap — the store is behind `Arc<RwLock>`.
#[derive(Clone)]
pub struct DynamicSettingEntry {
    /// Metadata (type, default, constraints, side effects).
    pub descriptor: DynamicSettingDescriptor,
    /// Shared store holding the actual values (owned by the plugin).
    pub store: SharedSettingStore,
}

/// Registry for dynamically registered settings (from plugins).
///
/// Lives on [`CommandExecutor`](crate::executor::CommandExecutor), mirroring
/// how `script_handlers` and `format_handlers` are stored.
/// The `set`/`get` commands fall through to this after checking the built-in
/// static registry.
/// Cloning is cheap — each entry's store is behind `Arc<RwLock>`.
#[derive(Clone)]
pub struct DynamicSettingRegistry {
    entries: AHashMap<String, DynamicSettingEntry>,
    /// Insertion-ordered names (for autocomplete).
    names: Vec<String>,
}

impl DynamicSettingRegistry {
    /// Create an empty registry.
    pub fn new() -> Self {
        Self {
            entries: AHashMap::new(),
            names: Vec::new(),
        }
    }

    /// Register a dynamic setting with its shared store.
    ///
    /// Returns an error if the name collides with a built-in setting or an
    /// already-registered dynamic setting.
    pub fn register(
        &mut self,
        descriptor: DynamicSettingDescriptor,
        store: SharedSettingStore,
    ) -> Result<(), String> {
        let name = &descriptor.name;

        // Reject collision with built-in settings
        if pymol_settings::registry::lookup_by_name(name).is_some() {
            return Err(format!(
                "Cannot register dynamic setting '{}': collides with a built-in setting",
                name
            ));
        }

        // Reject duplicate dynamic settings
        if self.entries.contains_key(name) {
            return Err(format!(
                "Dynamic setting '{}' is already registered",
                name
            ));
        }

        self.names.push(name.clone());
        self.entries.insert(
            name.clone(),
            DynamicSettingEntry { descriptor, store },
        );
        Ok(())
    }

    /// Remove all entries whose name matches a predicate.
    pub fn unregister_where(&mut self, predicate: impl Fn(&str) -> bool) {
        self.entries.retain(|name, _| !predicate(name));
        self.names.retain(|name| !predicate(name));
    }

    /// Look up a dynamic setting by name.
    pub fn lookup(&self, name: &str) -> Option<&DynamicSettingEntry> {
        self.entries.get(name)
    }

    /// All registered dynamic setting names (insertion order).
    pub fn names(&self) -> &[String] {
        &self.names
    }
}

impl Default for DynamicSettingRegistry {
    fn default() -> Self {
        Self::new()
    }
}

// Re-export ViewerLike from pymol-scene
pub use pymol_scene::ViewerLike;

use crate::args::ParsedCommand;
use crate::error::CmdResult;

// ============================================================================
// Argument hints for completion
// ============================================================================

/// Hint about what type of argument a command expects at a given position.
/// Used by the completion system to provide context-aware suggestions.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum ArgHint {
    /// No specific hint (generic argument)
    #[default]
    None,
    /// File or directory path
    Path,
    /// Selection expression
    Selection,
    /// Object name
    Object,
    /// Representation type (cartoon, sticks, spheres, etc.)
    Representation,
    /// Color name or value
    Color,
    /// Setting name
    Setting,
    /// Named selection only (no objects)
    NamedSelection,
    /// Label property expression (name, resn, resi, chain, b, q, etc.)
    LabelProperty,
    /// Command name (for help, etc.)
    Command,
    /// Fixed list of keyword choices (e.g., &["show", "hide"])
    Keywords(&'static [&'static str]),
}

// ============================================================================
// Output message types
// ============================================================================

/// Kind of command output message
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum MessageKind {
    /// Informational message (default)
    #[default]
    Info,
    /// Warning message
    Warning,
    /// Error message
    Error,
}

/// A typed output message from command execution
#[derive(Debug, Clone)]
pub struct OutputMessage {
    /// The message text
    pub text: String,
    /// The message kind (info, warning, error)
    pub kind: MessageKind,
}

impl OutputMessage {
    /// Create an info message
    pub fn info(text: impl Into<String>) -> Self {
        Self {
            text: text.into(),
            kind: MessageKind::Info,
        }
    }

    /// Create a warning message
    pub fn warning(text: impl Into<String>) -> Self {
        Self {
            text: text.into(),
            kind: MessageKind::Warning,
        }
    }

    /// Create an error message
    pub fn error(text: impl Into<String>) -> Self {
        Self {
            text: text.into(),
            kind: MessageKind::Error,
        }
    }
}

/// Side-effect actions that a command can request.
///
/// These are dispatched by the application layer after command execution.
#[derive(Debug, Clone)]
pub enum CommandAction {
    /// Request that a named panel be shown.
    ShowPanel(String),
    /// Request that a named panel be hidden.
    HidePanel(String),
    /// Request application quit.
    Quit,
}

/// Command execution context
///
/// Provides access to the viewer state and execution options.
/// Generic over `V: ViewerLike` to support different viewer implementations.
///
/// The two lifetime parameters are:
/// - `'v` - lifetime of the viewer reference
/// - `'r` - lifetime of the registry reference (may differ from viewer)
pub struct CommandContext<'v, 'r, V: ViewerLike + ?Sized> {
    /// Reference to the viewer (scene, objects, camera, settings)
    pub viewer: &'v mut V,
    /// Whether to suppress output messages
    pub quiet: bool,
    /// Collected output messages (for GUI display)
    output_buffer: Vec<OutputMessage>,
    /// Collected side-effect actions
    action_buffer: Vec<CommandAction>,
    /// Optional reference to command registry (for help lookups)
    registry: Option<&'r CommandRegistry>,
    /// Script handlers registered by plugins (extension -> handler)
    script_handlers: Option<&'r AHashMap<String, ScriptHandler>>,
    /// Format handlers registered by plugins (extension -> handler)
    format_handlers: Option<&'r AHashMap<String, Arc<FormatHandler>>>,
    /// Command history (for saving as .pml script)
    history: Option<&'r CommandHistory>,
    /// Dynamic settings registered by plugins
    dynamic_settings: Option<&'r DynamicSettingRegistry>,
}

impl<'v, 'r, V: ViewerLike + ?Sized> CommandContext<'v, 'r, V> {
    /// Create a new command context
    pub fn new(viewer: &'v mut V) -> Self {
        Self {
            viewer,
            quiet: false,
            output_buffer: Vec::new(),
            action_buffer: Vec::new(),
            registry: None,
            script_handlers: None,
            format_handlers: None,
            history: None,
            dynamic_settings: None,
        }
    }

    /// Set the quiet flag
    pub fn with_quiet(mut self, quiet: bool) -> Self {
        self.quiet = quiet;
        self
    }

    /// Set the command registry reference
    pub fn with_registry(mut self, registry: &'r CommandRegistry) -> Self {
        self.registry = Some(registry);
        self
    }

    /// Set the script handlers reference
    pub fn with_script_handlers(mut self, handlers: &'r AHashMap<String, ScriptHandler>) -> Self {
        self.script_handlers = Some(handlers);
        self
    }

    /// Get a reference to the command registry (if available)
    pub fn registry(&self) -> Option<&CommandRegistry> {
        self.registry
    }

    /// Set the format handlers reference
    pub fn with_format_handlers(mut self, handlers: &'r AHashMap<String, Arc<FormatHandler>>) -> Self {
        self.format_handlers = Some(handlers);
        self
    }

    /// Get a script handler for the given extension
    pub fn script_handler(&self, ext: &str) -> Option<&ScriptHandler> {
        self.script_handlers.and_then(|h| h.get(ext))
    }

    /// Get a format handler for the given extension
    pub fn format_handler(&self, ext: &str) -> Option<&Arc<FormatHandler>> {
        self.format_handlers.and_then(|h| h.get(ext))
    }

    /// Get the full script handlers map (if available)
    pub fn script_handlers_map(&self) -> Option<&AHashMap<String, ScriptHandler>> {
        self.script_handlers
    }

    /// Get the full format handlers map (if available)
    pub fn format_handlers_map(&self) -> Option<&AHashMap<String, Arc<FormatHandler>>> {
        self.format_handlers
    }

    /// Set the command history reference
    pub fn with_history(mut self, history: &'r CommandHistory) -> Self {
        self.history = Some(history);
        self
    }

    /// Get the command history
    pub fn history(&self) -> Option<&CommandHistory> {
        self.history
    }

    /// Set the dynamic settings registry reference
    pub fn with_dynamic_settings(mut self, registry: &'r DynamicSettingRegistry) -> Self {
        self.dynamic_settings = Some(registry);
        self
    }

    /// Look up a dynamic setting entry by name.
    pub fn dynamic_setting(&self, name: &str) -> Option<&DynamicSettingEntry> {
        self.dynamic_settings.and_then(|r| r.lookup(name))
    }

    /// Get the full dynamic settings registry (if available).
    pub fn dynamic_settings(&self) -> Option<&DynamicSettingRegistry> {
        self.dynamic_settings
    }

    /// Print an info message (unless quiet mode is enabled)
    ///
    /// The message is both logged and collected in the output buffer
    /// for retrieval by the GUI.
    pub fn print(&mut self, msg: &str) {
        if !self.quiet {
            log::info!("{}", msg);
            self.output_buffer.push(OutputMessage::info(msg));
        }
    }

    /// Print a warning message (unless quiet mode is enabled)
    pub fn print_warning(&mut self, msg: &str) {
        if !self.quiet {
            log::warn!("{}", msg);
            self.output_buffer.push(OutputMessage::warning(msg));
        }
    }

    /// Print an error message (even in quiet mode)
    ///
    /// Error messages are always shown regardless of quiet mode.
    pub fn print_error(&mut self, msg: &str) {
        log::error!("{}", msg);
        self.output_buffer.push(OutputMessage::error(msg));
    }

    /// Take the collected output messages, clearing the buffer
    pub fn take_output(&mut self) -> Vec<OutputMessage> {
        std::mem::take(&mut self.output_buffer)
    }

    /// Get a reference to the collected output messages
    pub fn output(&self) -> &[OutputMessage] {
        &self.output_buffer
    }

    /// Request that a named panel be shown
    pub fn show_panel(&mut self, name: impl Into<String>) {
        self.action_buffer.push(CommandAction::ShowPanel(name.into()));
    }

    /// Request that a named panel be hidden
    pub fn hide_panel(&mut self, name: impl Into<String>) {
        self.action_buffer.push(CommandAction::HidePanel(name.into()));
    }

    /// Request application quit
    pub fn quit(&mut self) {
        self.action_buffer.push(CommandAction::Quit);
    }

    /// Take the collected actions, clearing the buffer
    pub fn take_actions(&mut self) -> Vec<CommandAction> {
        std::mem::take(&mut self.action_buffer)
    }
}

/// Trait for command implementations
///
/// Commands receive a context with access to the viewer state and
/// parsed arguments, and return a result indicating success or failure.
pub trait Command: Send + Sync {
    /// Get the command name
    fn name(&self) -> &str;

    /// Execute the command
    ///
    /// Uses lifetime parameters to allow the context to borrow from non-'static viewers.
    /// - `'v` - lifetime of the viewer reference
    /// - `'r` - lifetime of the registry reference
    fn execute<'v, 'r>(&self, ctx: &mut CommandContext<'v, 'r, dyn ViewerLike + 'v>, args: &ParsedCommand) -> CmdResult;

    /// Get help text for this command
    fn help(&self) -> &str {
        "No help available."
    }

    /// Get list of command aliases
    fn aliases(&self) -> &[&str] {
        &[]
    }

    /// Get argument hints for completion
    ///
    /// Returns a slice of hints indicating what type of argument is expected
    /// at each position. Used by the completion system to provide context-aware
    /// suggestions (e.g., file paths for "load", selections for "select").
    fn arg_hints(&self) -> &[ArgHint] {
        &[]
    }
}

/// Registry mapping command names to implementations
pub struct CommandRegistry {
    /// Commands indexed by name
    commands: AHashMap<String, Arc<dyn Command>>,
    /// Aliases mapping alias -> command name
    aliases: AHashMap<String, String>,
}

impl Clone for CommandRegistry {
    fn clone(&self) -> Self {
        Self {
            commands: self.commands.clone(),
            aliases: self.aliases.clone(),
        }
    }
}

impl Default for CommandRegistry {
    fn default() -> Self {
        Self::new()
    }
}

impl CommandRegistry {
    /// Create a new empty registry
    pub fn new() -> Self {
        Self {
            commands: AHashMap::new(),
            aliases: AHashMap::new(),
        }
    }

    /// Create a registry with all built-in commands registered
    pub fn with_builtins() -> Self {
        let mut registry = Self::new();
        crate::commands::register_all(&mut registry);
        registry
    }

    /// Register a command
    ///
    /// Also registers any aliases defined by the command.
    pub fn register<C: Command + 'static>(&mut self, cmd: C) {
        let name = cmd.name().to_string();
        let aliases: Vec<String> = cmd.aliases().iter().map(|s| s.to_string()).collect();
        let cmd = Arc::new(cmd);

        // Register aliases
        for alias in aliases {
            self.aliases.insert(alias, name.clone());
        }

        self.commands.insert(name, cmd);
    }

    /// Register a boxed command (for plugin system).
    ///
    /// Like [`register`](Self::register) but accepts a `Box<dyn Command>`.
    pub fn register_boxed(&mut self, cmd: Box<dyn Command>) {
        let name = cmd.name().to_string();
        let aliases: Vec<String> = cmd.aliases().iter().map(|s| s.to_string()).collect();
        let cmd: Arc<dyn Command> = cmd.into();

        for alias in aliases {
            self.aliases.insert(alias, name.clone());
        }

        self.commands.insert(name, cmd);
    }

    /// Unregister a command by name.
    ///
    /// Removes the command and any aliases that point to it.
    /// Returns `true` if the command was found and removed.
    pub fn unregister(&mut self, name: &str) -> bool {
        if self.commands.remove(name).is_some() {
            self.aliases.retain(|_, target| target != name);
            true
        } else {
            false
        }
    }

    /// Add an alias for an existing command
    pub fn add_alias(&mut self, alias: impl Into<String>, command: impl Into<String>) {
        self.aliases.insert(alias.into(), command.into());
    }

    /// Look up a command by name or alias
    pub fn get(&self, name: &str) -> Option<Arc<dyn Command>> {
        // Try direct lookup first
        if let Some(cmd) = self.commands.get(name) {
            return Some(cmd.clone());
        }

        // Try alias lookup
        if let Some(real_name) = self.aliases.get(name) {
            return self.commands.get(real_name).cloned();
        }

        None
    }

    /// Check if a command exists
    pub fn contains(&self, name: &str) -> bool {
        self.commands.contains_key(name) || self.aliases.contains_key(name)
    }

    /// Get all command names (not including aliases)
    pub fn names(&self) -> impl Iterator<Item = &str> {
        self.commands.keys().map(|s| s.as_str())
    }

    /// Get all command names and aliases
    pub fn all_names(&self) -> impl Iterator<Item = &str> {
        self.commands
            .keys()
            .map(|s| s.as_str())
            .chain(self.aliases.keys().map(|s| s.as_str()))
    }

    /// Get the number of registered commands
    pub fn len(&self) -> usize {
        self.commands.len()
    }

    /// Check if the registry is empty
    pub fn is_empty(&self) -> bool {
        self.commands.is_empty()
    }

    /// Get all command names (including aliases) that expect a specific argument hint
    /// at the given position (0-indexed).
    ///
    /// This is used by the completion system to determine which commands should
    /// trigger specific completion types (e.g., file path completion).
    pub fn commands_with_hint(&self, hint: ArgHint, position: usize) -> Vec<&str> {
        let mut result = Vec::new();

        for (name, cmd) in &self.commands {
            let hints = cmd.arg_hints();
            if hints.get(position) == Some(&hint) {
                result.push(name.as_str());
                // Also include aliases for this command
                for (alias, target) in &self.aliases {
                    if target == name {
                        result.push(alias.as_str());
                    }
                }
            }
        }

        result
    }

    /// Check if a command expects a specific argument hint at the given position
    pub fn command_has_hint(&self, name: &str, hint: ArgHint, position: usize) -> bool {
        self.get(name)
            .map(|cmd| cmd.arg_hints().get(position) == Some(&hint))
            .unwrap_or(false)
    }

}

#[cfg(test)]
mod tests {
    use super::*;

    struct TestCommand {
        name: String,
    }

    impl Command for TestCommand {
        fn name(&self) -> &str {
            &self.name
        }

        fn execute<'v, 'r>(&self, _ctx: &mut CommandContext<'v, 'r, dyn ViewerLike + 'v>, _args: &ParsedCommand) -> CmdResult {
            Ok(())
        }

        fn help(&self) -> &str {
            "Test command"
        }

        fn aliases(&self) -> &[&str] {
            &["test_alias"]
        }
    }

    #[test]
    fn test_registry() {
        let mut registry = CommandRegistry::new();

        registry.register(TestCommand {
            name: "test".to_string(),
        });

        assert!(registry.contains("test"));
        assert!(registry.contains("test_alias"));
        assert!(!registry.contains("unknown"));

        let cmd = registry.get("test").unwrap();
        assert_eq!(cmd.name(), "test");

        let cmd = registry.get("test_alias").unwrap();
        assert_eq!(cmd.name(), "test");
    }

}
