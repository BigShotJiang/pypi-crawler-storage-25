//! Object management for scene objects
//!
//! This module provides:
//! - [`Object`] trait for all scene objects
//! - [`ObjectType`] enum for object type identification
//! - [`ObjectState`] for per-object visual state
//! - [`ObjectRegistry`] for managing named objects

mod cgo;
mod group;
mod label;
mod map;
mod measurement;
mod molecule;
mod surface;

pub use cgo::CgoObject;
pub use group::GroupObject;
pub use label::{Label, LabelAnchor, LabelObject};
pub use map::{MapData, MapDisplayMode, MapObject};
pub use measurement::{Measurement, MeasurementObject, MeasurementType};
pub use molecule::{DirtyFlags, MoleculeObject};
pub use surface::SurfaceObject;

use ahash::AHashMap;
use lin_alg::f32::{Mat4, Vec3};
use pymol_color::ColorIndex;
use pymol_mol::RepMask;
use pymol_settings::ObjectOverrides;
use serde::{Deserialize, Serialize};

// On native targets, Object requires Send + Sync for thread safety.
// On wasm32, wgpu's WebGPU backend types use RefCell (not Sync),
// and threading is not used, so we relax the bounds.
#[cfg(not(target_arch = "wasm32"))]
pub trait MaybeSend: Send {}
#[cfg(not(target_arch = "wasm32"))]
impl<T: Send> MaybeSend for T {}

#[cfg(target_arch = "wasm32")]
pub trait MaybeSend {}
#[cfg(target_arch = "wasm32")]
impl<T> MaybeSend for T {}

#[cfg(not(target_arch = "wasm32"))]
pub trait MaybeSync: Sync {}
#[cfg(not(target_arch = "wasm32"))]
impl<T: Sync> MaybeSync for T {}

#[cfg(target_arch = "wasm32")]
pub trait MaybeSync {}
#[cfg(target_arch = "wasm32")]
impl<T> MaybeSync for T {}

use crate::error::{SceneError, SceneResult};

/// Object type enumeration
///
/// Identifies the type of a scene object for type-safe downcasting and
/// type-specific operations.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum ObjectType {
    /// Molecular object (atoms, bonds, coordinates)
    Molecule,
    /// Electron density map
    Map,
    /// Triangle mesh
    Mesh,
    /// Molecular surface
    Surface,
    /// Compiled Graphics Object (custom primitives)
    Cgo,
    /// Group of objects
    Group,
    /// Measurement (distances, angles, etc.)
    Measurement,
    /// Label (text annotations)
    Label,
    /// Volume rendering
    Volume,
    /// Alignment object
    Alignment,
}

impl std::fmt::Display for ObjectType {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            ObjectType::Molecule => write!(f, "molecule"),
            ObjectType::Map => write!(f, "map"),
            ObjectType::Mesh => write!(f, "mesh"),
            ObjectType::Surface => write!(f, "surface"),
            ObjectType::Cgo => write!(f, "cgo"),
            ObjectType::Group => write!(f, "group"),
            ObjectType::Measurement => write!(f, "measurement"),
            ObjectType::Label => write!(f, "label"),
            ObjectType::Volume => write!(f, "volume"),
            ObjectType::Alignment => write!(f, "alignment"),
        }
    }
}

/// Per-object visual state
///
/// Contains the common visual properties shared by all object types.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ObjectState {
    /// Whether the object is enabled/visible
    pub enabled: bool,
    /// Default object color
    pub color: ColorIndex,
    /// Visible representations (for applicable objects)
    pub visible_reps: RepMask,
    /// 4x4 transformation matrix (TTT in PyMOL)
    ///
    /// This matrix is applied to all coordinates when rendering.
    #[serde(with = "crate::serde_helpers::mat4_serde")]
    pub transform: Mat4,
}

impl Default for ObjectState {
    fn default() -> Self {
        Self {
            enabled: true,
            color: ColorIndex::default(),
            visible_reps: RepMask::default(),
            transform: Mat4::new_identity(),
        }
    }
}

impl ObjectState {
    /// Create a new object state with default values
    pub fn new() -> Self {
        Self::default()
    }

    /// Create a disabled object state
    pub fn disabled() -> Self {
        Self {
            enabled: false,
            ..Default::default()
        }
    }

    /// Set the transformation matrix
    pub fn set_transform(&mut self, transform: Mat4) {
        self.transform = transform;
    }

    /// Reset the transformation to identity
    pub fn reset_transform(&mut self) {
        self.transform = Mat4::new_identity();
    }

    /// Check if a representation is visible
    pub fn rep_visible(&self, rep: RepMask) -> bool {
        self.visible_reps.is_visible(rep)
    }

    /// Show a representation
    pub fn show_rep(&mut self, rep: RepMask) {
        self.visible_reps.set_visible(rep);
    }

    /// Hide a representation
    pub fn hide_rep(&mut self, rep: RepMask) {
        self.visible_reps.set_hidden(rep);
    }
}

/// Trait for all scene objects
///
/// This trait defines the common interface for all objects that can be
/// added to a scene, including molecules, maps, surfaces, etc.
pub trait Object: MaybeSend + MaybeSync {
    /// Get the object name
    fn name(&self) -> &str;

    /// Get the object type
    fn object_type(&self) -> ObjectType;

    /// Get the visual state
    fn state(&self) -> &ObjectState;

    /// Get mutable access to the visual state
    fn state_mut(&mut self) -> &mut ObjectState;

    /// Get the bounding box (min, max) for the current coordinate state
    ///
    /// Returns `None` if the object has no geometry.
    fn extent(&self) -> Option<(Vec3, Vec3)>;

    /// Get the number of coordinate states
    ///
    /// For single-state objects, returns 1.
    fn n_states(&self) -> usize {
        1
    }

    /// Get the current state index
    fn current_state(&self) -> usize {
        0
    }

    /// Set the current state index
    fn set_current_state(&mut self, _state: usize) -> bool {
        false
    }

    /// Get object-level settings overrides (if any)
    fn overrides(&self) -> Option<&ObjectOverrides> {
        None
    }

    /// Get mutable object-level settings overrides
    fn overrides_mut(&mut self) -> Option<&mut ObjectOverrides> {
        None
    }

    /// Get or create mutable object-level settings overrides.
    ///
    /// Default implementation panics — override in types that support per-object settings.
    fn get_or_create_overrides(&mut self) -> &mut ObjectOverrides {
        unimplemented!("{} does not support per-object settings overrides", self.name())
    }

    /// Check if this object is enabled
    fn is_enabled(&self) -> bool {
        self.state().enabled
    }

    /// Enable the object
    fn enable(&mut self) {
        self.state_mut().enabled = true;
    }

    /// Disable the object
    fn disable(&mut self) {
        self.state_mut().enabled = false;
    }

    /// Get the center of the object
    fn center(&self) -> Option<Vec3> {
        let (min, max) = self.extent()?;
        Some(Vec3::new(
            (min.x + max.x) * 0.5,
            (min.y + max.y) * 0.5,
            (min.z + max.z) * 0.5,
        ))
    }

    /// Set the object name
    fn set_name(&mut self, name: String);
}

/// Object registry for managing named objects
///
/// The registry stores all scene objects by name and maintains render order.
///
/// Note: The `objects` field contains trait objects (`Box<dyn Object>`) which
/// cannot be directly serialized. Use [`ObjectRegistrySnapshot`] for
/// serialization of the object data.
pub struct ObjectRegistry {
    /// Objects stored by name
    objects: AHashMap<String, Box<dyn Object>>,
    /// Ordered list of object names for rendering
    render_order: Vec<String>,
    /// Counter for generating unique names
    next_id: u32,
    /// Generation counter, incremented on structural changes (add/remove/rename)
    generation: u64,
}

/// Serializable snapshot of the object registry.
///
/// Captures molecule, group, and map objects (the types that carry
/// domain data). Render-only objects (surface, cgo, label) are
/// omitted because they are transient GPU caches.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ObjectRegistrySnapshot {
    /// Molecule objects (name -> data)
    pub molecules: Vec<(String, MoleculeObjectSnapshot)>,
    /// Group objects (name -> data)
    pub groups: Vec<(String, GroupObject)>,
    /// Map objects (name -> data)
    #[serde(default)]
    pub maps: Vec<(String, MapObjectSnapshot)>,
    /// Render order
    pub render_order: Vec<String>,
    /// Object states for all objects (name -> state)
    pub object_states: Vec<(String, ObjectState)>,
    /// Next id counter
    pub next_id: u32,
    /// Generation counter
    pub generation: u64,
}

/// Serializable snapshot of a MoleculeObject (without render caches).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MoleculeObjectSnapshot {
    /// The underlying molecular data
    pub molecule: pymol_mol::ObjectMolecule,
    /// Visual state
    pub state: ObjectState,
    /// Current coordinate state index being displayed
    pub display_state: usize,
    /// Per-object settings overrides
    pub overrides: Option<ObjectOverrides>,
    /// Surface quality
    pub surface_quality: i32,
}

/// Serializable snapshot of a MapObject (without render caches).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MapObjectSnapshot {
    /// Map data for each state
    pub states: Vec<MapData>,
    /// Visual state
    pub state: ObjectState,
    /// Current display state index
    pub current_state: usize,
    /// Isocontour level
    pub level: f32,
    /// Display mode
    pub display_mode: MapDisplayMode,
    /// Mesh color (RGBA)
    pub mesh_color: [f32; 4],
    /// Carve radius
    pub carve_radius: f32,
    /// Carve positions
    pub carve_positions: Option<Vec<[f32; 3]>>,
    /// Per-object settings overrides
    pub overrides: Option<ObjectOverrides>,
}

impl ObjectRegistry {
    /// Create a serializable snapshot of this registry.
    pub fn to_snapshot(&self) -> ObjectRegistrySnapshot {
        let mut molecules = Vec::new();
        let mut groups = Vec::new();
        let mut maps = Vec::new();
        let mut object_states = Vec::new();

        for name in &self.render_order {
            if let Some(obj) = self.objects.get(name) {
                object_states.push((name.clone(), obj.state().clone()));
                match obj.object_type() {
                    ObjectType::Molecule => {
                        if let Some(mol_obj) = self.get_molecule(name) {
                            molecules.push((
                                name.clone(),
                                MoleculeObjectSnapshot {
                                    molecule: mol_obj.molecule().clone(),
                                    state: mol_obj.state().clone(),
                                    display_state: mol_obj.display_state(),
                                    overrides: mol_obj.overrides().cloned(),
                                    surface_quality: mol_obj.surface_quality(),
                                },
                            ));
                        }
                    }
                    ObjectType::Group => {
                        if let Some(group) = self.get_group(name) {
                            groups.push((name.clone(), group.clone()));
                        }
                    }
                    ObjectType::Map => {
                        if let Some(map_obj) = self.get_map(name) {
                            maps.push((
                                name.clone(),
                                MapObjectSnapshot {
                                    states: map_obj.states().to_vec(),
                                    state: map_obj.state().clone(),
                                    current_state: map_obj.current_state(),
                                    level: map_obj.level(),
                                    display_mode: map_obj.display_mode(),
                                    mesh_color: map_obj.mesh_color(),
                                    carve_radius: map_obj.carve_radius(),
                                    carve_positions: map_obj.carve_positions().cloned(),
                                    overrides: map_obj.overrides().cloned(),
                                },
                            ));
                        }
                    }
                    _ => {
                        // Surface, CGO, Label objects are transient
                    }
                }
            }
        }

        ObjectRegistrySnapshot {
            molecules,
            groups,
            maps,
            render_order: self.render_order.clone(),
            object_states,
            next_id: self.next_id,
            generation: self.generation,
        }
    }

    /// Restore from a serializable snapshot.
    pub fn from_snapshot(snapshot: ObjectRegistrySnapshot) -> Self {
        let mut registry = Self::new();
        registry.next_id = snapshot.next_id;
        registry.generation = snapshot.generation;

        // Add molecules (use from_raw to preserve per-atom visible_reps)
        for (name, snap) in snapshot.molecules {
            let mut mol_obj = MoleculeObject::from_raw(snap.molecule);
            mol_obj.molecule_mut().name = name.clone();
            *mol_obj.state_mut() = snap.state;
            if snap.display_state > 0 {
                mol_obj.set_display_state(snap.display_state);
            }
            if let Some(overrides) = snap.overrides {
                *mol_obj.get_or_create_overrides() = overrides;
            }
            mol_obj.set_surface_quality(snap.surface_quality);
            registry.objects.insert(name, Box::new(mol_obj));
        }

        // Add groups
        for (name, group) in snapshot.groups {
            registry.objects.insert(name, Box::new(group));
        }

        // Add maps
        for (name, snap) in snapshot.maps {
            let mut map_obj = MapObject::empty(&name);
            for map_data in snap.states {
                map_obj.add_state(map_data);
            }
            *map_obj.state_mut() = snap.state;
            if snap.current_state > 0 {
                map_obj.set_current_state(snap.current_state);
            }
            map_obj.set_level(snap.level);
            map_obj.set_display_mode(snap.display_mode);
            map_obj.set_mesh_color(snap.mesh_color);
            map_obj.set_carve_radius(snap.carve_radius);
            if let Some(positions) = snap.carve_positions {
                map_obj.set_carve_positions(positions);
            }
            if let Some(overrides) = snap.overrides {
                map_obj.set_overrides(overrides);
            }
            registry.objects.insert(name, Box::new(map_obj));
        }

        // Restore render order (only names that exist)
        registry.render_order = snapshot
            .render_order
            .into_iter()
            .filter(|n| registry.objects.contains_key(n))
            .collect();

        registry
    }
}

impl Default for ObjectRegistry {
    fn default() -> Self {
        Self::new()
    }
}

impl ObjectRegistry {
    /// Create a new empty registry
    pub fn new() -> Self {
        Self {
            objects: AHashMap::new(),
            render_order: Vec::new(),
            next_id: 1,
            generation: 0,
        }
    }

    /// Get the number of objects
    pub fn len(&self) -> usize {
        self.objects.len()
    }

    /// Check if the registry is empty
    pub fn is_empty(&self) -> bool {
        self.objects.is_empty()
    }

    /// Get the generation counter (incremented on structural changes)
    pub fn generation(&self) -> u64 {
        self.generation
    }

    /// Mark all molecule objects as fully dirty so representations rebuild.
    pub fn mark_all_dirty(&mut self) {
        self.generation += 1;
        let names: Vec<String> = self.names().map(|s| s.to_string()).collect();
        for name in &names {
            if let Some(mol) = self.get_molecule_mut(name) {
                mol.invalidate(DirtyFlags::ALL);
            }
        }
    }

    /// Add an object to the registry
    ///
    /// Returns the name used for the object. If an object with the same name
    /// already exists, it will be replaced.
    /// Insert a pre-boxed object by name.
    pub fn insert_boxed(&mut self, name: &str, obj: Box<dyn Object>) {
        self.render_order.retain(|n| n != name);
        self.render_order.push(name.to_string());
        self.objects.insert(name.to_string(), obj);
        self.generation += 1;
    }

    pub fn add<O: Object + 'static>(&mut self, obj: O) -> &str {
        let name = obj.name().to_string();
        self.render_order.retain(|n| n != &name);
        self.render_order.push(name.clone());
        self.objects.insert(name, Box::new(obj));
        self.generation += 1;
        self.render_order.last().map(|s| s.as_str()).unwrap()
    }

    /// Add an object with an auto-generated name
    pub fn add_with_name<O: Object + 'static>(&mut self, mut obj: O, base_name: &str) -> String {
        let name = self.generate_unique_name(base_name);
        obj.set_name(name.clone());
        self.add(obj);
        name
    }

    /// Generate a unique name based on a base name
    fn generate_unique_name(&mut self, base: &str) -> String {
        if !self.objects.contains_key(base) {
            return base.to_string();
        }

        loop {
            let name = format!("{}_{}", base, self.next_id);
            self.next_id += 1;
            if !self.objects.contains_key(&name) {
                return name;
            }
        }
    }

    /// Remove an object by name
    ///
    /// Also removes the object from any group that contains it.
    pub fn remove(&mut self, name: &str) -> Option<Box<dyn Object>> {
        self.remove_from_groups(name);
        self.render_order.retain(|n| n != name);
        let removed = self.objects.remove(name);
        if removed.is_some() {
            self.generation += 1;
        }
        removed
    }

    /// Get an object by name
    pub fn get(&self, name: &str) -> Option<&dyn Object> {
        self.objects.get(name).map(|b| b.as_ref())
    }

    /// Get mutable access to an object by name
    pub fn get_mut(&mut self, name: &str) -> Option<&mut dyn Object> {
        match self.objects.get_mut(name) {
            Some(boxed) => Some(boxed.as_mut()),
            None => None,
        }
    }

    /// Get a molecule object by name
    pub fn get_molecule(&self, name: &str) -> Option<&MoleculeObject> {
        let obj = self.objects.get(name)?;
        if obj.object_type() == ObjectType::Molecule {
            // Safety: we just checked the type
            let ptr = obj.as_ref() as *const dyn Object;
            Some(unsafe { &*(ptr as *const MoleculeObject) })
        } else {
            None
        }
    }

    /// Get mutable access to a molecule object by name
    pub fn get_molecule_mut(&mut self, name: &str) -> Option<&mut MoleculeObject> {
        let obj = self.objects.get_mut(name)?;
        if obj.object_type() == ObjectType::Molecule {
            // Safety: we just checked the type
            let ptr = obj.as_mut() as *mut dyn Object;
            Some(unsafe { &mut *(ptr as *mut MoleculeObject) })
        } else {
            None
        }
    }

    /// Get a group object by name
    pub fn get_group(&self, name: &str) -> Option<&GroupObject> {
        let obj = self.objects.get(name)?;
        if obj.object_type() == ObjectType::Group {
            // Safety: we just checked the type
            let ptr = obj.as_ref() as *const dyn Object;
            Some(unsafe { &*(ptr as *const GroupObject) })
        } else {
            None
        }
    }

    /// Get mutable access to a group object by name
    pub fn get_group_mut(&mut self, name: &str) -> Option<&mut GroupObject> {
        let obj = self.objects.get_mut(name)?;
        if obj.object_type() == ObjectType::Group {
            // Safety: we just checked the type
            let ptr = obj.as_mut() as *mut dyn Object;
            Some(unsafe { &mut *(ptr as *mut GroupObject) })
        } else {
            None
        }
    }

    /// Get a surface object by name
    pub fn get_surface(&self, name: &str) -> Option<&SurfaceObject> {
        let obj = self.objects.get(name)?;
        if obj.object_type() == ObjectType::Surface {
            // Safety: we just checked the type
            let ptr = obj.as_ref() as *const dyn Object;
            Some(unsafe { &*(ptr as *const SurfaceObject) })
        } else {
            None
        }
    }

    /// Get mutable access to a surface object by name
    pub fn get_surface_mut(&mut self, name: &str) -> Option<&mut SurfaceObject> {
        let obj = self.objects.get_mut(name)?;
        if obj.object_type() == ObjectType::Surface {
            // Safety: we just checked the type
            let ptr = obj.as_mut() as *mut dyn Object;
            Some(unsafe { &mut *(ptr as *mut SurfaceObject) })
        } else {
            None
        }
    }

    /// Get a CGO object by name
    pub fn get_cgo(&self, name: &str) -> Option<&CgoObject> {
        let obj = self.objects.get(name)?;
        if obj.object_type() == ObjectType::Cgo {
            // Safety: we just checked the type
            let ptr = obj.as_ref() as *const dyn Object;
            Some(unsafe { &*(ptr as *const CgoObject) })
        } else {
            None
        }
    }

    /// Get mutable access to a CGO object by name
    pub fn get_cgo_mut(&mut self, name: &str) -> Option<&mut CgoObject> {
        let obj = self.objects.get_mut(name)?;
        if obj.object_type() == ObjectType::Cgo {
            // Safety: we just checked the type
            let ptr = obj.as_mut() as *mut dyn Object;
            Some(unsafe { &mut *(ptr as *mut CgoObject) })
        } else {
            None
        }
    }

    /// Get a measurement object by name
    pub fn get_measurement(&self, name: &str) -> Option<&MeasurementObject> {
        let obj = self.objects.get(name)?;
        if obj.object_type() == ObjectType::Measurement {
            // Safety: we just checked the type
            let ptr = obj.as_ref() as *const dyn Object;
            Some(unsafe { &*(ptr as *const MeasurementObject) })
        } else {
            None
        }
    }

    /// Get mutable access to a measurement object by name
    pub fn get_measurement_mut(&mut self, name: &str) -> Option<&mut MeasurementObject> {
        let obj = self.objects.get_mut(name)?;
        if obj.object_type() == ObjectType::Measurement {
            // Safety: we just checked the type
            let ptr = obj.as_mut() as *mut dyn Object;
            Some(unsafe { &mut *(ptr as *mut MeasurementObject) })
        } else {
            None
        }
    }

    /// Get a map object by name
    pub fn get_map(&self, name: &str) -> Option<&MapObject> {
        let obj = self.objects.get(name)?;
        if obj.object_type() == ObjectType::Map {
            // Safety: we just checked the type
            let ptr = obj.as_ref() as *const dyn Object;
            Some(unsafe { &*(ptr as *const MapObject) })
        } else {
            None
        }
    }

    /// Get mutable access to a map object by name
    pub fn get_map_mut(&mut self, name: &str) -> Option<&mut MapObject> {
        let obj = self.objects.get_mut(name)?;
        if obj.object_type() == ObjectType::Map {
            // Safety: we just checked the type
            let ptr = obj.as_mut() as *mut dyn Object;
            Some(unsafe { &mut *(ptr as *mut MapObject) })
        } else {
            None
        }
    }

    /// Get the combined bounding box of all children in a group
    ///
    /// Recursively computes the extent including nested groups.
    pub fn group_extent(&self, group_name: &str) -> Option<(Vec3, Vec3)> {
        let group = self.get_group(group_name)?;
        let children = group.children().to_vec();

        let mut min = Vec3::new(f32::MAX, f32::MAX, f32::MAX);
        let mut max = Vec3::new(f32::MIN, f32::MIN, f32::MIN);
        let mut has_extent = false;

        for child_name in &children {
            // Check if child is a group (recursive)
            if self.get_group(child_name).is_some() {
                if let Some((child_min, child_max)) = self.group_extent(child_name) {
                    min.x = min.x.min(child_min.x);
                    min.y = min.y.min(child_min.y);
                    min.z = min.z.min(child_min.z);
                    max.x = max.x.max(child_max.x);
                    max.y = max.y.max(child_max.y);
                    max.z = max.z.max(child_max.z);
                    has_extent = true;
                }
            } else if let Some(obj) = self.get(child_name) {
                if let Some((child_min, child_max)) = obj.extent() {
                    min.x = min.x.min(child_min.x);
                    min.y = min.y.min(child_min.y);
                    min.z = min.z.min(child_min.z);
                    max.x = max.x.max(child_max.x);
                    max.y = max.y.max(child_max.y);
                    max.z = max.z.max(child_max.z);
                    has_extent = true;
                }
            }
        }

        if has_extent {
            Some((min, max))
        } else {
            None
        }
    }

    /// Enable or disable a group and all its children recursively
    pub fn set_group_enabled(&mut self, group_name: &str, enabled: bool) -> SceneResult<()> {
        // First, collect the children names
        let children = {
            let group = self
                .get_group(group_name)
                .ok_or_else(|| SceneError::ObjectNotFound(group_name.to_string()))?;
            group.children().to_vec()
        };

        // Enable/disable the group itself
        if let Some(obj) = self.objects.get_mut(group_name) {
            obj.state_mut().enabled = enabled;
        }

        // Recursively enable/disable children
        for child_name in children {
            // Check if child is a group
            if self.get_group(&child_name).is_some() {
                // Recursive call for nested groups
                let _ = self.set_group_enabled(&child_name, enabled);
            } else if let Some(obj) = self.objects.get_mut(&child_name) {
                obj.state_mut().enabled = enabled;
            }
        }

        Ok(())
    }

    /// Find the parent group of an object (if any)
    ///
    /// An object can be in at most one group. Returns the group name.
    pub fn parent_group(&self, name: &str) -> Option<&str> {
        for obj in self.objects.values() {
            if obj.object_type() == ObjectType::Group {
                // Safety: we just checked the type
                let ptr = obj.as_ref() as *const dyn Object;
                let group = unsafe { &*(ptr as *const GroupObject) };
                if group.contains_child(name) {
                    return Some(group.name());
                }
            }
        }
        None
    }

    /// Remove an object from any group that contains it
    pub fn remove_from_groups(&mut self, name: &str) {
        for obj in self.objects.values_mut() {
            if obj.object_type() == ObjectType::Group {
                // Safety: we just checked the type
                let ptr = obj.as_mut() as *mut dyn Object;
                let group = unsafe { &mut *(ptr as *mut GroupObject) };
                group.remove_child(name);
            }
        }
    }

    /// Add an object to a group, creating the group if it doesn't exist
    ///
    /// The child is removed from any existing group first (an object can only
    /// be in one group). Returns false if the child doesn't exist or if
    /// trying to add an object to itself.
    pub fn add_to_group(&mut self, group_name: &str, child_name: &str) -> bool {
        if !self.objects.contains_key(child_name) {
            return false;
        }
        if group_name == child_name {
            return false;
        }

        // Remove from any existing group
        self.remove_from_groups(child_name);

        // Create group if needed
        if !self.objects.contains_key(group_name) {
            self.add(GroupObject::new(group_name));
        }

        if let Some(group) = self.get_group_mut(group_name) {
            group.add_child(child_name.to_string());
        } else {
            return false;
        }

        self.reorder_children_after_group(group_name);
        self.generation += 1;
        true
    }

    /// Reorder render_order so group children appear immediately after their group
    fn reorder_children_after_group(&mut self, group_name: &str) {
        let children: Vec<String> = match self.get_group(group_name) {
            Some(g) => g.children().to_vec(),
            None => return,
        };

        // Remove children from render_order
        self.render_order.retain(|n| !children.contains(n));

        // Find group position and insert children right after
        if let Some(pos) = self.render_order.iter().position(|n| n == group_name) {
            for (i, child) in children.into_iter().enumerate() {
                self.render_order.insert(pos + 1 + i, child);
            }
        }
    }

    /// Get names of top-level objects (not children of any group)
    ///
    /// Returns names in render order, excluding objects that are children
    /// of a group. Used by the GUI to start tree iteration.
    pub fn top_level_names(&self) -> Vec<&str> {
        // Collect all children across all groups
        let mut children_set = std::collections::HashSet::new();
        for obj in self.objects.values() {
            if obj.object_type() == ObjectType::Group {
                // Safety: we just checked the type
                let ptr = obj.as_ref() as *const dyn Object;
                let group = unsafe { &*(ptr as *const GroupObject) };
                for child in group.children() {
                    children_set.insert(child.as_str());
                }
            }
        }
        self.render_order
            .iter()
            .map(|s| s.as_str())
            .filter(|name| !children_set.contains(name))
            .collect()
    }

    /// Check if an object exists
    pub fn contains(&self, name: &str) -> bool {
        self.objects.contains_key(name)
    }

    /// Get all object names
    pub fn names(&self) -> impl Iterator<Item = &str> {
        self.render_order.iter().map(|s| s.as_str())
    }

    /// Get all objects in render order
    pub fn iter(&self) -> impl Iterator<Item = &dyn Object> {
        self.render_order
            .iter()
            .filter_map(|name| self.objects.get(name).map(|b| b.as_ref()))
    }

    /// Get all objects mutably as boxed references
    ///
    /// Note: Returns iterator over Box references, not trait object references,
    /// to avoid lifetime issues with trait objects.
    pub fn iter_mut(&mut self) -> impl Iterator<Item = &mut Box<dyn Object>> + '_ {
        self.objects.values_mut()
    }

    /// Enable an object
    pub fn enable(&mut self, name: &str, enabled: bool) -> SceneResult<()> {
        let obj = self
            .objects
            .get_mut(name)
            .ok_or_else(|| SceneError::ObjectNotFound(name.to_string()))?;
        obj.state_mut().enabled = enabled;
        Ok(())
    }

    /// Disable all objects
    pub fn disable_all(&mut self) {
        for obj in self.objects.values_mut() {
            obj.state_mut().enabled = false;
        }
    }

    /// Enable all objects
    pub fn enable_all(&mut self) {
        for obj in self.objects.values_mut() {
            obj.state_mut().enabled = true;
        }
    }

    /// Get enabled objects in render order
    pub fn enabled_objects(&self) -> impl Iterator<Item = &dyn Object> {
        self.render_order.iter().filter_map(|name| {
            self.objects.get(name).and_then(|obj| {
                if obj.state().enabled {
                    Some(obj.as_ref())
                } else {
                    None
                }
            })
        })
    }

    /// Get object names matching a pattern.
    ///
    /// Supports `*` (any characters) and `?` (single character) wildcards
    /// via `pymol_select::Pattern::Wildcard`. Pattern `*` or `all` matches
    /// everything. Names without wildcard characters are matched exactly.
    pub fn matching<'a>(&'a self, pattern: &'a str) -> Vec<&'a str> {
        if pattern == "*" || pattern == "all" {
            return self.render_order.iter().map(|s| s.as_str()).collect();
        }

        if pattern.contains('*') || pattern.contains('?') {
            let pat = pymol_select::Pattern::Wildcard(pattern.to_string());
            return self
                .render_order
                .iter()
                .filter(|name| pat.matches(name, false))
                .map(|s| s.as_str())
                .collect();
        }

        // Exact match
        if self.objects.contains_key(pattern) {
            // Return a reference to our stored name, not the input
            self.render_order
                .iter()
                .find(|n| n.as_str() == pattern)
                .map(|s| vec![s.as_str()])
                .unwrap_or_default()
        } else {
            vec![]
        }
    }

    /// Set the render order
    pub fn set_render_order(&mut self, names: &[&str]) {
        // Keep only names that exist and preserve any not in the list at the end
        let mut new_order = Vec::new();
        let mut used = std::collections::HashSet::new();

        for name in names {
            if self.objects.contains_key(*name) && !used.contains(*name) {
                new_order.push((*name).to_string());
                used.insert(*name);
            }
        }

        // Add any remaining objects at the end
        for name in &self.render_order {
            if !used.contains(name.as_str()) {
                new_order.push(name.clone());
            }
        }

        self.render_order = new_order;
    }

    /// Move an object to the front of the render order
    pub fn bring_to_front(&mut self, name: &str) {
        if let Some(pos) = self.render_order.iter().position(|n| n == name) {
            let name = self.render_order.remove(pos);
            self.render_order.push(name);
        }
    }

    /// Move an object to the back of the render order
    pub fn send_to_back(&mut self, name: &str) {
        if let Some(pos) = self.render_order.iter().position(|n| n == name) {
            let name = self.render_order.remove(pos);
            self.render_order.insert(0, name);
        }
    }

    /// Compute the bounding box of all enabled objects
    pub fn extent(&self) -> Option<(Vec3, Vec3)> {
        let mut min = Vec3::new(f32::MAX, f32::MAX, f32::MAX);
        let mut max = Vec3::new(f32::MIN, f32::MIN, f32::MIN);
        let mut has_extent = false;

        for obj in self.enabled_objects() {
            if let Some((obj_min, obj_max)) = obj.extent() {
                min.x = min.x.min(obj_min.x);
                min.y = min.y.min(obj_min.y);
                min.z = min.z.min(obj_min.z);
                max.x = max.x.max(obj_max.x);
                max.y = max.y.max(obj_max.y);
                max.z = max.z.max(obj_max.z);
                has_extent = true;
            }
        }

        if has_extent {
            Some((min, max))
        } else {
            None
        }
    }

    /// Get the center of all enabled objects
    pub fn center(&self) -> Option<Vec3> {
        let (min, max) = self.extent()?;
        Some(Vec3::new(
            (min.x + max.x) * 0.5,
            (min.y + max.y) * 0.5,
            (min.z + max.z) * 0.5,
        ))
    }

    /// Rename an object
    pub fn rename(&mut self, old_name: &str, new_name: &str) -> SceneResult<()> {
        if !self.objects.contains_key(old_name) {
            return Err(SceneError::ObjectNotFound(old_name.to_string()));
        }
        if self.objects.contains_key(new_name) {
            return Err(SceneError::ObjectExists(new_name.to_string()));
        }

        if let Some(mut obj) = self.objects.remove(old_name) {
            // Update the internal name field
            obj.set_name(new_name.to_string());
            self.objects.insert(new_name.to_string(), obj);

            // Update render order
            for name in &mut self.render_order {
                if name == old_name {
                    *name = new_name.to_string();
                }
            }
        }

        // Update group children references
        let old = old_name.to_string();
        let new = new_name.to_string();
        for obj in self.objects.values_mut() {
            if obj.object_type() == ObjectType::Group {
                let ptr = obj.as_mut() as *mut dyn Object;
                let group = unsafe { &mut *(ptr as *mut GroupObject) };
                for child in group.children_mut() {
                    if *child == old {
                        *child = new.clone();
                    }
                }
            }
        }

        self.generation += 1;
        Ok(())
    }

    /// Clear all objects
    pub fn clear(&mut self) {
        if !self.objects.is_empty() {
            self.generation += 1;
        }
        self.objects.clear();
        self.render_order.clear();
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    // Mock object for testing
    struct MockObject {
        name: String,
        state: ObjectState,
    }

    impl MockObject {
        fn new(name: &str) -> Self {
            Self {
                name: name.to_string(),
                state: ObjectState::default(),
            }
        }
    }

    impl Object for MockObject {
        fn name(&self) -> &str {
            &self.name
        }

        fn object_type(&self) -> ObjectType {
            ObjectType::Molecule
        }

        fn state(&self) -> &ObjectState {
            &self.state
        }

        fn state_mut(&mut self) -> &mut ObjectState {
            &mut self.state
        }

        fn extent(&self) -> Option<(Vec3, Vec3)> {
            None
        }

        fn set_name(&mut self, name: String) {
            self.name = name;
        }
    }

    #[test]
    fn test_registry_add_remove() {
        let mut registry = ObjectRegistry::new();

        registry.add(MockObject::new("obj1"));
        registry.add(MockObject::new("obj2"));

        assert_eq!(registry.len(), 2);
        assert!(registry.contains("obj1"));
        assert!(registry.contains("obj2"));

        registry.remove("obj1");
        assert_eq!(registry.len(), 1);
        assert!(!registry.contains("obj1"));
    }

    #[test]
    fn test_registry_render_order() {
        let mut registry = ObjectRegistry::new();

        registry.add(MockObject::new("a"));
        registry.add(MockObject::new("b"));
        registry.add(MockObject::new("c"));

        let names: Vec<_> = registry.names().collect();
        assert_eq!(names, vec!["a", "b", "c"]);

        registry.bring_to_front("a");
        let names: Vec<_> = registry.names().collect();
        assert_eq!(names, vec!["b", "c", "a"]);

        registry.send_to_back("a");
        let names: Vec<_> = registry.names().collect();
        assert_eq!(names, vec!["a", "b", "c"]);
    }

    #[test]
    fn test_registry_matching() {
        let mut registry = ObjectRegistry::new();

        registry.add(MockObject::new("protein"));
        registry.add(MockObject::new("protein_chain_A"));
        registry.add(MockObject::new("ligand"));

        let matches = registry.matching("protein*");
        assert_eq!(matches.len(), 2);

        let matches = registry.matching("*chain_A");
        assert_eq!(matches.len(), 1);

        let matches = registry.matching("*");
        assert_eq!(matches.len(), 3);
    }

    #[test]
    fn test_enable_disable() {
        let mut registry = ObjectRegistry::new();
        registry.add(MockObject::new("obj1"));
        registry.add(MockObject::new("obj2"));

        registry.disable_all();
        assert!(registry.enabled_objects().next().is_none());

        registry.enable("obj1", true).unwrap();
        assert_eq!(registry.enabled_objects().count(), 1);
    }

    #[test]
    fn test_add_to_group() {
        let mut registry = ObjectRegistry::new();
        registry.add(MockObject::new("obj1"));
        registry.add(MockObject::new("obj2"));
        registry.add(MockObject::new("obj3"));

        // Create group by adding to it
        assert!(registry.add_to_group("grp", "obj1"));
        assert!(registry.add_to_group("grp", "obj2"));

        // Group should exist and contain children
        let group = registry.get_group("grp").unwrap();
        assert!(group.contains_child("obj1"));
        assert!(group.contains_child("obj2"));
        assert!(!group.contains_child("obj3"));

        // Children should follow group in render order
        let names: Vec<_> = registry.names().collect();
        let grp_pos = names.iter().position(|n| *n == "grp").unwrap();
        let obj1_pos = names.iter().position(|n| *n == "obj1").unwrap();
        let obj2_pos = names.iter().position(|n| *n == "obj2").unwrap();
        assert!(obj1_pos == grp_pos + 1);
        assert!(obj2_pos == grp_pos + 2);
    }

    #[test]
    fn test_add_to_group_prevents_self() {
        let mut registry = ObjectRegistry::new();
        registry.add(GroupObject::new("grp"));
        assert!(!registry.add_to_group("grp", "grp"));
    }

    #[test]
    fn test_add_to_group_moves_between_groups() {
        let mut registry = ObjectRegistry::new();
        registry.add(MockObject::new("obj1"));
        registry.add(GroupObject::new("grp1"));
        registry.add(GroupObject::new("grp2"));

        registry.add_to_group("grp1", "obj1");
        assert!(registry.get_group("grp1").unwrap().contains_child("obj1"));

        // Move to different group
        registry.add_to_group("grp2", "obj1");
        assert!(!registry.get_group("grp1").unwrap().contains_child("obj1"));
        assert!(registry.get_group("grp2").unwrap().contains_child("obj1"));
    }

    #[test]
    fn test_parent_group() {
        let mut registry = ObjectRegistry::new();
        registry.add(MockObject::new("obj1"));
        registry.add(MockObject::new("obj2"));

        assert!(registry.parent_group("obj1").is_none());

        registry.add_to_group("grp", "obj1");
        assert_eq!(registry.parent_group("obj1"), Some("grp"));
        assert!(registry.parent_group("obj2").is_none());
    }

    #[test]
    fn test_remove_cleans_up_groups() {
        let mut registry = ObjectRegistry::new();
        registry.add(MockObject::new("obj1"));
        registry.add_to_group("grp", "obj1");

        assert!(registry.get_group("grp").unwrap().contains_child("obj1"));

        registry.remove("obj1");
        assert!(!registry.get_group("grp").unwrap().contains_child("obj1"));
    }

    #[test]
    fn test_top_level_names() {
        let mut registry = ObjectRegistry::new();
        registry.add(MockObject::new("obj1"));
        registry.add(MockObject::new("obj2"));
        registry.add(MockObject::new("obj3"));

        // All are top-level initially
        assert_eq!(registry.top_level_names().len(), 3);

        // Add obj1 and obj2 to a group
        registry.add_to_group("grp", "obj1");
        registry.add_to_group("grp", "obj2");

        let top = registry.top_level_names();
        assert!(top.contains(&"grp"));
        assert!(top.contains(&"obj3"));
        assert!(!top.contains(&"obj1"));
        assert!(!top.contains(&"obj2"));
        assert_eq!(top.len(), 2);
    }
}
