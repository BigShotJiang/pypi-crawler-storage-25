//! SessionAdapter — bridges Session to the ViewerLike trait
//!
//! [`SessionAdapter`] borrows a [`Session`] and an optional [`RenderContext`]
//! and implements [`ViewerLike`], allowing the command system to operate on
//! pure scene state with optional GPU support.

use std::path::Path;

use pymol_color::NamedColors;
use pymol_render::RenderContext;
use pymol_settings::Settings;

use crate::camera::Camera;
use crate::capture::capture_png_to_file;
use crate::movie::Movie;
use crate::object::ObjectRegistry;
use crate::scene::{SceneManager, SceneStoreMask};
use crate::selection::SelectionManager;
use crate::session::Session;
use crate::view::ViewManager;
use crate::viewer_trait::{ViewportImage, ViewerLike};

/// Callback type for async fetch operations (GUI sets this; headless leaves None).
type AsyncFetchFn<'a> = Box<dyn Fn(&str, &str, u8) -> bool + 'a>;

/// Adapter that wraps a [`Session`] to implement [`ViewerLike`] for command execution.
///
/// Borrows a mutable reference to a `Session` (scene state) plus an optional
/// `RenderContext` (GPU resources) and a `needs_redraw` flag.
pub struct SessionAdapter<'a> {
    /// The scene state
    pub session: &'a mut Session,
    /// GPU render context (None if headless / not yet initialized)
    pub render_context: Option<&'a RenderContext>,
    /// Default viewport size for capture when width/height not specified
    pub default_size: (u32, u32),
    /// Redraw flag — set to true when a re-render is needed
    pub needs_redraw: &'a mut bool,
    /// Optional callback for async fetch (GUI sets this; headless leaves None)
    pub async_fetch_fn: Option<AsyncFetchFn<'a>>,
}

impl<'a> ViewerLike for SessionAdapter<'a> {
    // =========================================================================
    // Required Accessors
    // =========================================================================

    fn objects(&self) -> &ObjectRegistry { &self.session.registry }
    fn objects_mut(&mut self) -> &mut ObjectRegistry { &mut self.session.registry }
    fn camera(&self) -> &Camera { &self.session.camera }
    fn camera_mut(&mut self) -> &mut Camera { &mut self.session.camera }
    fn settings(&self) -> &Settings { &self.session.settings }
    fn settings_mut(&mut self) -> &mut Settings { &mut self.session.settings }
    fn movie(&self) -> &Movie { &self.session.movie }
    fn movie_mut(&mut self) -> &mut Movie { &mut self.session.movie }
    fn scenes(&self) -> &SceneManager { &self.session.scenes }
    fn scenes_mut(&mut self) -> &mut SceneManager { &mut self.session.scenes }
    fn views(&self) -> &ViewManager { &self.session.views }
    fn views_mut(&mut self) -> &mut ViewManager { &mut self.session.views }
    fn selections(&self) -> &SelectionManager { &self.session.selections }
    fn selections_mut(&mut self) -> &mut SelectionManager { &mut self.session.selections }
    fn named_colors(&self) -> &NamedColors { &self.session.named_colors }
    fn named_colors_mut(&mut self) -> &mut NamedColors { &mut self.session.named_colors }
    fn clear_color(&self) -> [f32; 3] { self.session.clear_color }
    fn set_clear_color(&mut self, color: [f32; 3]) { self.session.clear_color = color; }
    fn viewport_image_ref(&self) -> Option<&ViewportImage> { self.session.viewport_image.as_ref() }
    fn set_viewport_image_internal(&mut self, image: Option<ViewportImage>) { self.session.viewport_image = image; }

    fn request_redraw(&mut self) {
        *self.needs_redraw = true;
    }

    fn session(&self) -> &Session { self.session }
    fn session_mut(&mut self) -> &mut Session { self.session }

    fn replace_session(&mut self, session: Session) {
        *self.session = session;
        // Mark all objects dirty so representations rebuild
        self.session.registry.mark_all_dirty();
        *self.needs_redraw = true;
    }

    // =========================================================================
    // Async fetch
    // =========================================================================

    fn request_async_fetch(&mut self, code: &str, name: &str, format: u8) -> bool {
        if let Some(ref f) = self.async_fetch_fn {
            f(code, name, format)
        } else {
            false
        }
    }

    // =========================================================================
    // GPU-specific overrides
    // =========================================================================

    fn capture_png(
        &mut self,
        path: &Path,
        width: Option<u32>,
        height: Option<u32>,
    ) -> Result<(), String> {
        let context = self.render_context.ok_or_else(|| {
            "No render context available".to_string()
        })?;

        capture_png_to_file(
            path,
            width,
            height,
            context,
            &mut self.session.camera,
            &mut self.session.registry,
            &self.session.settings,
            &self.session.named_colors,
            &self.session.element_colors,
            self.session.clear_color,
            self.default_size,
        ).map_err(|e| e.to_string())
    }

    fn gpu_device(&self) -> Option<&wgpu::Device> {
        self.render_context.map(|c| c.device())
    }

    fn gpu_queue(&self) -> Option<&wgpu::Queue> {
        self.render_context.map(|c| c.queue())
    }

    fn prepare_render(&mut self) {
        if let Some(context) = self.render_context {
            self.session.prepare_render_all(context);
        }
    }

    fn capture_frame_png(
        &mut self,
        frame: usize,
        path: &Path,
        width: Option<u32>,
        height: Option<u32>,
    ) -> Result<(), String> {
        self.session.movie.goto_frame(frame);
        if let Some(view) = self.session.movie.interpolated_view() {
            self.session.camera.set_view(view);
        }
        self.session.apply_movie_object_transforms();
        if let Some(scene_name) = self.session.movie.current_scene_name().map(|s| s.to_string()) {
            if let Some(scene) = self.session.scenes.get(&scene_name) {
                scene.apply(&mut self.session.camera, &mut self.session.registry, false, 0.0);
                if let Some(view) = self.session.movie.interpolated_view() {
                    self.session.camera.set_view(view);
                }
            }
        }
        self.capture_png(path, width, height)
    }

    // =========================================================================
    // Per-impl methods (borrow checker constraints)
    // =========================================================================

    fn scene_store(&mut self, key: &str, storemask: u32) {
        let mask = SceneStoreMask::from_bits_truncate(storemask);
        self.session.scenes.store(key, mask, &self.session.camera, &self.session.registry);
        *self.needs_redraw = true;
    }

    fn scene_recall(&mut self, key: &str, animate: bool, duration: f32) -> Result<(), String> {
        self.session
            .scenes
            .recall(key, &mut self.session.camera, &mut self.session.registry, animate, duration)
            .map_err(|e| e.to_string())?;
        *self.needs_redraw = true;
        Ok(())
    }

    fn view_recall(&mut self, key: &str, animate: f32) -> Result<(), String> {
        self.session
            .views
            .recall(key, &mut self.session.camera, animate)
            .map_err(|e| e.to_string())?;
        *self.needs_redraw = true;
        Ok(())
    }

    fn viewport_size(&self) -> (u32, u32) {
        self.default_size
    }
}
