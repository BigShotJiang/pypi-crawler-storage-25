"""ContextPulse - Turn your Git history into a human story."""
__version__ = "0.2.0"
