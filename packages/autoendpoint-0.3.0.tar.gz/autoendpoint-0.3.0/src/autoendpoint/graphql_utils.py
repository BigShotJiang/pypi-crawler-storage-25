from typing import List, Type, Dict, Any, Optional, Union
import strawberry
from sqlalchemy.ext.asyncio import AsyncSession
from sqlmodel import SQLModel, select
from sqlalchemy.orm import class_mapper


def generate_graphql_schema(models: List[Type[SQLModel]], db_session: AsyncSession) -> strawberry.Schema:
    """Dynamically generates a Strawberry GraphQL schema for the given SQLModels.

    Args:
        models: A list of SQLModel classes to include in the schema.
        db_session: The asynchronous database session to use for queries.

    Returns:
        A Strawberry Schema object.
    """

    model_to_strawberry_type: Dict[Type[SQLModel], Any] = {}

    # First pass: Create the basic Strawberry types without relationships
    for model in models:
        @strawberry.experimental.pydantic.type(model=model, all_fields=True, name=f"{model.__name__}Type")
        class ModelType:
            @strawberry.field
            def string_representation(self) -> str:
                return str(self)

        model_to_strawberry_type[model] = ModelType

    # Second pass: Add relationship fields to the Strawberry types
    for model, strawberry_type in model_to_strawberry_type.items():
        mapper = class_mapper(model)
        for rel in mapper.relationships:
            target_model = rel.mapper.class_
            if target_model in model_to_strawberry_type:
                target_strawberry_type = model_to_strawberry_type[target_model]
                rel_name = rel.key
                is_list = rel.uselist

                # Define a resolver for the relationship
                def make_rel_resolver(r_n=rel_name):
                    async def resolve_rel(root: Any) -> Any:
                        # Since we are in an async environment, 
                        # we must ensure the relationship is loaded.
                        # However, for simplicity now, let's try direct access.
                        # A better approach might involve selectinload in the main query.
                        return getattr(root, r_n)
                    return resolve_rel

                # Determine the type annotation
                if is_list:
                    field_type = List[target_strawberry_type] # type: ignore
                else:
                    field_type = Optional[target_strawberry_type] # type: ignore

                # Create the field
                field = strawberry.field(resolver=make_rel_resolver(), name=rel_name)
                # Use strawberry.annotation.StrawberryAnnotation to wrap the type
                from strawberry.annotation import StrawberryAnnotation
                field.type_annotation = StrawberryAnnotation(field_type)
                
                # Add to the type definition
                strawberry_type.__strawberry_definition__.fields.append(field)

    query_fields = {}
    for model, strawberry_type in model_to_strawberry_type.items():
        # Define a closure for the resolver
        def make_resolver(m=model, t=strawberry_type):
            from sqlalchemy.orm import selectinload
            mapper = class_mapper(m)
            # Find all relationships that should be preloaded
            options = []
            for rel in mapper.relationships:
                if rel.mapper.class_ in model_to_strawberry_type:
                    options.append(selectinload(getattr(m, rel.key)))

            async def resolve(self) -> List[t]: # type: ignore
                stmt = select(m)
                if options:
                    stmt = stmt.options(*options)
                results = await db_session.execute(stmt)
                return results.scalars().all()
            return resolve
            
        query_fields[f"list_{model.__name__.lower()}"] = strawberry.field(resolver=make_resolver())

    DynamicQuery = type("Query", (object,), query_fields)
    DynamicQuery = strawberry.type(DynamicQuery)

    return strawberry.Schema(query=DynamicQuery)
