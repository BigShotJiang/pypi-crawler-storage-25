from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from soc_mre.database_sql import (
    add_credential_sql,
    close_db,
    export_domain_txt,
    init_db,
)


class DatabaseSqlTests(unittest.TestCase):
    def setUp(self) -> None:
        self._tmpdir = tempfile.TemporaryDirectory()
        self.db_path = Path(self._tmpdir.name) / "master.db"

    def tearDown(self) -> None:
        self._tmpdir.cleanup()

    def test_init_db_creates_file(self) -> None:
        self.assertFalse(self.db_path.exists())
        conn = init_db(self.db_path)
        try:
            self.assertTrue(self.db_path.is_file())
            cur = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='credentials'"
            )
            self.assertIsNotNone(cur.fetchone())
        finally:
            close_db(conn)

    def test_add_credential_and_dedupe(self) -> None:
        conn = init_db(self.db_path)
        try:
            self.assertTrue(
                add_credential_sql(
                    conn, "User@Test.com", "secret1", "@test.com", "unit"
                )
            )
            conn.commit()
            self.assertFalse(
                add_credential_sql(
                    conn, "user@test.com", "secret1", "@test.com", "unit"
                )
            )
            row = conn.execute(
                "SELECT COUNT(*) FROM credentials WHERE email=? AND password=?",
                ("user@test.com", "secret1"),
            ).fetchone()
            self.assertEqual(row[0], 1)
        finally:
            close_db(conn)

    def test_export_domain_txt_format_matches_blacklist_style(self) -> None:
        conn = init_db(self.db_path)
        out = Path(self._tmpdir.name) / "blackList-test.txt"
        try:
            add_credential_sql(conn, "a@x.com", "z", "@x.com", None)
            add_credential_sql(conn, "a@x.com", "m", "@x.com", None)
            conn.commit()
            n = export_domain_txt(conn, "@x.com", out)
            self.assertEqual(n, 1)
            paths = sorted(Path(self._tmpdir.name).glob("blackList-test_*.txt"))
            self.assertEqual(len(paths), 1)
            line = paths[0].read_text(encoding="utf-8").strip()
            self.assertTrue(line.startswith("a@x.com:"))
            self.assertIn("m", line)
            self.assertIn("z", line)
            # Mesmo estilo que database.save_database: email:senha1,senha2 (ordenado)
            self.assertEqual(line, "a@x.com:m,z")
        finally:
            close_db(conn)

    def test_export_domain_txt_second_run_creates_distinct_timestamped_files(self) -> None:
        conn = init_db(self.db_path)
        out = Path(self._tmpdir.name) / "blackList-versioned.txt"
        try:
            add_credential_sql(conn, "v@ver.com", "p1", "@ver.com", None)
            conn.commit()
            n1 = export_domain_txt(conn, "@ver.com", out)
            self.assertEqual(n1, 1)
            add_credential_sql(conn, "v@ver.com", "p2", "@ver.com", None)
            conn.commit()
            n2 = export_domain_txt(conn, "@ver.com", out)
            self.assertEqual(n2, 1)
            paths = sorted(Path(self._tmpdir.name).glob("blackList-versioned_*.txt"))
            self.assertEqual(len(paths), 2)
            self.assertEqual(paths[0].read_text(encoding="utf-8").strip(), "v@ver.com:p1")
            self.assertEqual(paths[1].read_text(encoding="utf-8").strip(), "v@ver.com:p1,p2")
        finally:
            close_db(conn)

    def test_export_empty_domain_returns_zero_and_no_file(self) -> None:
        conn = init_db(self.db_path)
        out = Path(self._tmpdir.name) / "blackList-empty.txt"
        try:
            add_credential_sql(conn, "a@x.com", "p", "@x.com", None)
            conn.commit()
            self.assertFalse(out.exists())
            n = export_domain_txt(conn, "@other.com", out)
            self.assertEqual(n, 0)
            self.assertFalse(out.exists())
        finally:
            close_db(conn)

    def test_db_file_exists_after_close_db(self) -> None:
        conn = init_db(self.db_path)
        add_credential_sql(conn, "b@y.com", "pw", "@y.com", None)
        close_db(conn)
        self.assertTrue(self.db_path.is_file())


if __name__ == "__main__":
    unittest.main()
