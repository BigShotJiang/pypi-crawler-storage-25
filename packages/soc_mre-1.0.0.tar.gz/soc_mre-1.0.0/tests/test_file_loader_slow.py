from __future__ import annotations

import io
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import py7zr
from openpyxl import Workbook

from soc_mre.database_sql import init_db
from soc_mre.detector import process_domain
from soc_mre.file_loader import (
    detect_stream_kind,
    list_txt_files,
    stream_any_file,
    stream_pdf,
    stream_xlsx,
    warn_slow_format,
)


class FileLoaderSlowFormatTests(unittest.TestCase):
    def _write_7z(self, path: Path, members: dict[str, bytes]) -> None:
        buf = io.BytesIO()
        with py7zr.SevenZipFile(buf, "w") as zf:
            for arcname, data in members.items():
                zf.writestr(data, arcname)
        path.write_bytes(buf.getvalue())

    def test_list_txt_files_includes_slow_extensions(self) -> None:
        d = Path(tempfile.mkdtemp())
        try:
            for name in ("a.7z", "b.rar", "c.pdf", "d.xlsx"):
                (d / name).touch()
            names = {p.name for p in list_txt_files(d)}
            self.assertTrue({"a.7z", "b.rar", "c.pdf", "d.xlsx"}.issubset(names))
        finally:
            shutil.rmtree(d, ignore_errors=True)

    def test_detect_stream_kind_slow_suffixes(self) -> None:
        d = Path(tempfile.mkdtemp())
        try:
            for suf, kind in (
                (".7z", "7z"),
                (".rar", "rar"),
                (".pdf", "pdf"),
                (".xlsx", "xlsx"),
            ):
                p = d / f"x{suf}"
                p.touch()
                self.assertEqual(detect_stream_kind(p), kind)
        finally:
            shutil.rmtree(d, ignore_errors=True)

    def test_warn_slow_format_prompt_yes(self) -> None:
        d = Path(tempfile.mkdtemp())
        try:
            p = d / "slow.7z"
            p.touch()
            with mock.patch("soc_mre.file_loader.input", return_value="s"):
                self.assertTrue(warn_slow_format(p))
        finally:
            shutil.rmtree(d, ignore_errors=True)

    def test_warn_slow_format_prompt_no(self) -> None:
        d = Path(tempfile.mkdtemp())
        try:
            p = d / "slow.7z"
            p.touch()
            with mock.patch("soc_mre.file_loader.input", return_value="N"):
                self.assertFalse(warn_slow_format(p))
        finally:
            shutil.rmtree(d, ignore_errors=True)

    def test_stream_any_file_7z_skipped_when_user_declines(self) -> None:
        d = Path(tempfile.mkdtemp())
        try:
            zp = d / "x.7z"
            self._write_7z(zp, {"a.txt": b"u@decline.com:x\n"})
            with mock.patch("soc_mre.file_loader.input", return_value="n"):
                self.assertEqual(list(stream_any_file(zp)), [])
        finally:
            shutil.rmtree(d, ignore_errors=True)

    def test_stream_any_file_7z_when_user_accepts(self) -> None:
        d = Path(tempfile.mkdtemp())
        try:
            zp = d / "x.7z"
            self._write_7z(
                zp,
                {
                    "a.txt": b"one@7zok.com:p1\n",
                    "sub/b.txt": b"two@7zok.com:p2\n",
                },
            )
            with mock.patch("soc_mre.file_loader.input", return_value="s"):
                lines = list(stream_any_file(zp))
            joined = b"".join(lines)
            self.assertIn(b"one@7zok.com:p1", joined)
            self.assertIn(b"two@7zok.com:p2", joined)
        finally:
            shutil.rmtree(d, ignore_errors=True)

    def test_process_domain_7z_confirm_s_finds_credentials(self) -> None:
        leaks = Path(tempfile.mkdtemp())
        db_parent = Path(tempfile.mkdtemp())
        dbf = db_parent / "db.sqlite"
        try:
            self._write_7z(
                leaks / "leak.7z",
                {"f.txt": b"a@7zproc.com:pa\n", "g.txt": b"b@7zproc.com:pb\n"},
            )
            before = {p.resolve() for p in leaks.rglob("*") if p.is_file()}
            conn = init_db(dbf)
            insert_count = [0]
            local: dict = {}
            with mock.patch("soc_mre.file_loader.input", return_value="s"):
                stats = process_domain(
                    leaks,
                    "@7zproc.com",
                    conn,
                    insert_count,
                    local,
                    None,
                    None,
                )
            after = {p.resolve() for p in leaks.rglob("*") if p.is_file()}
            self.assertEqual(stats.credentials_parsed, 2)
            self.assertEqual(before, after)
            conn.close()
        finally:
            shutil.rmtree(leaks, ignore_errors=True)
            shutil.rmtree(db_parent, ignore_errors=True)

    def test_process_domain_7z_confirm_n_skipped(self) -> None:
        leaks = Path(tempfile.mkdtemp())
        db_parent = Path(tempfile.mkdtemp())
        dbf = db_parent / "db.sqlite"
        try:
            self._write_7z(leaks / "skip.7z", {"f.txt": b"a@7zskip.com:pa\n"})
            conn = init_db(dbf)
            insert_count = [0]
            local: dict = {}
            with mock.patch("soc_mre.file_loader.input", return_value="N"):
                stats = process_domain(
                    leaks,
                    "@7zskip.com",
                    conn,
                    insert_count,
                    local,
                    None,
                    None,
                )
            self.assertEqual(stats.credentials_parsed, 0)
            conn.close()
        finally:
            shutil.rmtree(leaks, ignore_errors=True)
            shutil.rmtree(db_parent, ignore_errors=True)

    def test_stream_pdf_finds_email_password_line(self) -> None:
        pdf_path = Path(__file__).resolve().parent / "fixtures" / "cred_one_line.pdf"
        self.assertTrue(pdf_path.is_file(), "fixture PDF em tests/fixtures/")
        lines = list(stream_pdf(pdf_path))
        decoded = b"\n".join(lines).decode("utf-8")
        self.assertIn("cred@pdftest.com:pdfpass", decoded)

    def test_process_domain_pdf_with_fixture(self) -> None:
        leaks = Path(tempfile.mkdtemp())
        db_parent = Path(tempfile.mkdtemp())
        dbf = db_parent / "db.sqlite"
        try:
            src = Path(__file__).resolve().parent / "fixtures" / "cred_one_line.pdf"
            shutil.copy(src, leaks / "doc.pdf")
            before = {p.resolve() for p in leaks.rglob("*") if p.is_file()}
            conn = init_db(dbf)
            insert_count = [0]
            local: dict = {}
            with mock.patch("soc_mre.file_loader.input", return_value="s"):
                stats = process_domain(
                    leaks,
                    "@pdftest.com",
                    conn,
                    insert_count,
                    local,
                    None,
                    None,
                )
            after = {p.resolve() for p in leaks.rglob("*") if p.is_file()}
            self.assertEqual(stats.credentials_parsed, 1)
            self.assertEqual(before, after)
            conn.close()
        finally:
            shutil.rmtree(leaks, ignore_errors=True)
            shutil.rmtree(db_parent, ignore_errors=True)

    def test_stream_xlsx_columns_email_password(self) -> None:
        d = Path(tempfile.mkdtemp())
        try:
            xp = d / "t.xlsx"
            wb = Workbook()
            ws = wb.active
            assert ws is not None
            ws.append(["user@xlsstream.com", "pw123"])
            wb.save(xp)
            wb.close()
            raw = b"\n".join(stream_xlsx(xp)).decode("utf-8")
            self.assertIn("user@xlsstream.com:pw123", raw)
        finally:
            shutil.rmtree(d, ignore_errors=True)

    def test_process_domain_xlsx(self) -> None:
        leaks = Path(tempfile.mkdtemp())
        db_parent = Path(tempfile.mkdtemp())
        dbf = db_parent / "db.sqlite"
        try:
            xp = leaks / "data.xlsx"
            wb = Workbook()
            ws = wb.active
            assert ws is not None
            ws.append(["mail@xlsproc.com", "secret99"])
            wb.save(xp)
            wb.close()
            before = {p.resolve() for p in leaks.rglob("*") if p.is_file()}
            conn = init_db(dbf)
            insert_count = [0]
            local: dict = {}
            with mock.patch("soc_mre.file_loader.input", return_value="s"):
                stats = process_domain(
                    leaks,
                    "@xlsproc.com",
                    conn,
                    insert_count,
                    local,
                    None,
                    None,
                )
            after = {p.resolve() for p in leaks.rglob("*") if p.is_file()}
            self.assertEqual(stats.credentials_parsed, 1)
            self.assertEqual(before, after)
            conn.close()
        finally:
            shutil.rmtree(leaks, ignore_errors=True)
            shutil.rmtree(db_parent, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
