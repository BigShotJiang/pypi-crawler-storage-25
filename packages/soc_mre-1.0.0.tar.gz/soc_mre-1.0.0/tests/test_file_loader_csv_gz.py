from __future__ import annotations

import gzip
import io
import shutil
import tempfile
import unittest
import zipfile
from pathlib import Path

from soc_mre.database_sql import init_db
from soc_mre.detector import process_domain
from soc_mre.file_loader import (
    detect_stream_kind,
    list_txt_files,
    stream_any_file,
    stream_gz,
    stream_zip,
)


class FileLoaderCsvGzTests(unittest.TestCase):
    def test_list_txt_files_includes_csv_and_gz(self) -> None:
        d = Path(tempfile.mkdtemp())
        try:
            (d / "a.txt").write_text("x", encoding="utf-8")
            (d / "b.csv").write_text("y", encoding="utf-8")
            (d / "c.gz").write_bytes(gzip.compress(b"z"))
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
                zf.writestr("x.txt", "z")
            (d / "d.zip").write_bytes(buf.getvalue())
            names = {p.name for p in list_txt_files(d)}
            self.assertEqual(names, {"a.txt", "b.csv", "c.gz", "d.zip"})
        finally:
            shutil.rmtree(d, ignore_errors=True)

    def test_stream_gz_roundtrip(self) -> None:
        d = Path(tempfile.mkdtemp())
        try:
            p = d / "t.gz"
            raw = b"a@test.com:secret1\nb@test.com:secret2\n"
            p.write_bytes(gzip.compress(raw))
            out = b"".join(stream_gz(p))
            self.assertEqual(out, raw)
        finally:
            shutil.rmtree(d, ignore_errors=True)

    def test_stream_any_file_csv_and_plain(self) -> None:
        d = Path(tempfile.mkdtemp())
        try:
            csv_p = d / "f.csv"
            csv_p.write_bytes(b"line1\n")
            self.assertEqual(
                list(stream_any_file(csv_p, "text/csv")),
                [b"line1\n"],
            )
            txt_p = d / "f.txt"
            txt_p.write_bytes(b"ok\n")
            self.assertEqual(
                list(stream_any_file(txt_p, "text/plain")),
                [b"ok\n"],
            )
        finally:
            shutil.rmtree(d, ignore_errors=True)

    def test_detect_stream_kind_by_suffix(self) -> None:
        d = Path(tempfile.mkdtemp())
        try:
            (d / "x.csv").touch()
            (d / "x.gz").touch()
            (d / "x.txt").touch()
            (d / "x.zip").touch()
            self.assertEqual(detect_stream_kind(d / "x.csv"), "text/csv")
            self.assertEqual(detect_stream_kind(d / "x.gz"), "gzip")
            self.assertEqual(detect_stream_kind(d / "x.zip"), "zip")
            self.assertEqual(detect_stream_kind(d / "x.txt"), "text/plain")
        finally:
            shutil.rmtree(d, ignore_errors=True)

    def test_stream_any_file_autodetect_csv_suffix(self) -> None:
        d = Path(tempfile.mkdtemp())
        try:
            p = d / "auto.csv"
            p.write_bytes(b"x@y.com:pw\n")
            self.assertEqual(list(stream_any_file(p)), [b"x@y.com:pw\n"])
        finally:
            shutil.rmtree(d, ignore_errors=True)

    def test_process_domain_finds_three_credentials_in_csv(self) -> None:
        leaks = Path(tempfile.mkdtemp())
        db_parent = Path(tempfile.mkdtemp())
        dbf = db_parent / "db.sqlite"
        try:
            (leaks / "cred.csv").write_bytes(
                b"a@csvtest.com:pass1\n"
                b"b@csvtest.com:pass2\n"
                b"c@csvtest.com:pass3\n"
            )
            conn = init_db(dbf)
            insert_count = [0]
            local: dict = {}
            stats = process_domain(
                leaks,
                "@csvtest.com",
                conn,
                insert_count,
                local,
                None,
                None,
            )
            self.assertEqual(stats.credentials_parsed, 3)
            conn.close()
        finally:
            shutil.rmtree(leaks, ignore_errors=True)
            shutil.rmtree(db_parent, ignore_errors=True)

    def _write_zip(self, path: Path, members: dict[str, bytes]) -> None:
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            for name, data in members.items():
                zf.writestr(name, data)
        path.write_bytes(buf.getvalue())

    def test_stream_zip_two_internal_txt(self) -> None:
        d = Path(tempfile.mkdtemp())
        try:
            zp = d / "t.zip"
            self._write_zip(
                zp,
                {
                    "a.txt": b"one@ziptest.com:p1\n",
                    "b.txt": b"two@ziptest.com:p2\n",
                },
            )
            out = b"".join(stream_zip(zp))
            self.assertEqual(
                out,
                b"one@ziptest.com:p1\ntwo@ziptest.com:p2\n",
            )
            self.assertEqual(list(stream_any_file(zp)), [b"one@ziptest.com:p1\n", b"two@ziptest.com:p2\n"])
        finally:
            shutil.rmtree(d, ignore_errors=True)

    def test_stream_zip_skips_dirs_and_subfolders(self) -> None:
        d = Path(tempfile.mkdtemp())
        try:
            zp = d / "nested.zip"
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
                zf.writestr("sub/inner/c.txt", b"x@subzip.com:pw\n")
                zf.writestr("root.txt", b"y@subzip.com:pw2\n")
            zp.write_bytes(buf.getvalue())
            out = b"".join(stream_zip(zp))
            self.assertIn(b"x@subzip.com:pw\n", out)
            self.assertIn(b"y@subzip.com:pw2\n", out)
        finally:
            shutil.rmtree(d, ignore_errors=True)

    def test_process_domain_finds_credentials_in_zip_two_files(self) -> None:
        leaks = Path(tempfile.mkdtemp())
        db_parent = Path(tempfile.mkdtemp())
        dbf = db_parent / "db.sqlite"
        try:
            self._write_zip(
                leaks / "leak.zip",
                {
                    "f1.txt": b"a@zipcred.com:pa\n",
                    "f2.txt": b"b@zipcred.com:pb\n",
                },
            )
            before = {p.resolve() for p in leaks.rglob("*") if p.is_file()}
            conn = init_db(dbf)
            insert_count = [0]
            local: dict = {}
            stats = process_domain(
                leaks,
                "@zipcred.com",
                conn,
                insert_count,
                local,
                None,
                None,
            )
            after = {p.resolve() for p in leaks.rglob("*") if p.is_file()}
            self.assertEqual(stats.credentials_parsed, 2)
            self.assertEqual(before, after, "nenhum ficheiro extra deve aparecer em leaks (sem extrair)")
            conn.close()
        finally:
            shutil.rmtree(leaks, ignore_errors=True)
            shutil.rmtree(db_parent, ignore_errors=True)

    def test_process_domain_zip_with_internal_subfolders(self) -> None:
        leaks = Path(tempfile.mkdtemp())
        db_parent = Path(tempfile.mkdtemp())
        dbf = db_parent / "db.sqlite"
        try:
            self._write_zip(
                leaks / "pack.zip",
                {
                    "dir/deep/x.txt": b"u@zipsub.com:sec\n",
                    "top.txt": b"v@zipsub.com:sec2\n",
                },
            )
            conn = init_db(dbf)
            insert_count = [0]
            local: dict = {}
            stats = process_domain(
                leaks,
                "@zipsub.com",
                conn,
                insert_count,
                local,
                None,
                None,
            )
            self.assertEqual(stats.credentials_parsed, 2)
            conn.close()
        finally:
            shutil.rmtree(leaks, ignore_errors=True)
            shutil.rmtree(db_parent, ignore_errors=True)

    def test_process_domain_finds_credentials_in_gz(self) -> None:
        leaks = Path(tempfile.mkdtemp())
        db_parent = Path(tempfile.mkdtemp())
        dbf = db_parent / "db.sqlite"
        try:
            payload = b"u1@gztest.com:p1\nu2@gztest.com:p2\n"
            (leaks / "leak.gz").write_bytes(gzip.compress(payload))
            conn = init_db(dbf)
            insert_count = [0]
            local: dict = {}
            stats = process_domain(
                leaks,
                "@gztest.com",
                conn,
                insert_count,
                local,
                None,
                None,
            )
            self.assertEqual(stats.credentials_parsed, 2)
            conn.close()
        finally:
            shutil.rmtree(leaks, ignore_errors=True)
            shutil.rmtree(db_parent, ignore_errors=True)

    def test_csv_without_credentials_zero_parsed(self) -> None:
        leaks = Path(tempfile.mkdtemp())
        db_parent = Path(tempfile.mkdtemp())
        dbf = db_parent / "db.sqlite"
        try:
            (leaks / "empty.csv").write_bytes(b"col1,col2\nfoo,bar\n")
            conn = init_db(dbf)
            insert_count = [0]
            local: dict = {}
            stats = process_domain(
                leaks,
                "@notpresent.invalid",
                conn,
                insert_count,
                local,
                None,
                None,
            )
            self.assertEqual(stats.credentials_parsed, 0)
            conn.close()
        finally:
            shutil.rmtree(leaks, ignore_errors=True)
            shutil.rmtree(db_parent, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
