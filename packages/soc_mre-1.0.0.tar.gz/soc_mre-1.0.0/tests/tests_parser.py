from __future__ import annotations

import unittest

from soc_mre.parser import parse_credential_line


class ParserTests(unittest.TestCase):
    def test_required_cases(self) -> None:
        cases = [
            ("usuario@jfal.jus.br:123456", ("usuario@jfal.jus.br", "123456")),
            ("usuario@jfal.jus.br:P@$$w0rd!", ("usuario@jfal.jus.br", "P@$$w0rd!")),
            ("usuario@jfal.jus.br senha@123", ("usuario@jfal.jus.br", "senha@123")),
            ("usuario@jfal.jus.br|senha#2024", ("usuario@jfal.jus.br", "senha#2024")),
            ("usuario@jfal.jus.br -> senha!@#", ("usuario@jfal.jus.br", "senha!@#")),
            (
                "usuario@jfal.jus.br:senha@jfal.jus.br",
                ("usuario@jfal.jus.br", "senha@jfal.jus.br"),
            ),
        ]
        for raw, expected in cases:
            with self.subTest(raw=raw):
                self.assertEqual(parse_credential_line(raw), expected)

    def test_multiple_domains_supported(self) -> None:
        cases = [
            ("ana@jfce.jus.br:Senha#1", ("ana@jfce.jus.br", "Senha#1")),
            ("bob@mpf.mp.br | A!2@3#4", ("bob@mpf.mp.br", "A!2@3#4")),
            ("carol@trf5.jus.br -> XyZ@2026", ("carol@trf5.jus.br", "XyZ@2026")),
        ]
        for raw, expected in cases:
            with self.subTest(raw=raw):
                self.assertEqual(parse_credential_line(raw), expected)

    def test_noise_before_email(self) -> None:
        raw = "http://site.com usuario@jfal.jus.br:senha123"
        self.assertEqual(
            parse_credential_line(raw),
            ("usuario@jfal.jus.br", "senha123"),
        )

    def test_scheme_less_url_prefix_before_email(self) -> None:
        raw = "accounts.google.com/signin/v2/challenge/pwd:marcia.martire@sptrans.com.br:majosantos2017"
        self.assertEqual(
            parse_credential_line(raw),
            ("marcia.martire@sptrans.com.br", "majosantos2017"),
        )

    def test_first_email_only(self) -> None:
        raw = "a@jfal.jus.br:senha com b@jfal.jus.br dentro"
        self.assertEqual(
            parse_credential_line(raw),
            ("a@jfal.jus.br", "senha com b@jfal.jus.br dentro"),
        )

    def test_inverted_line_fallback(self) -> None:
        raw = "P@$$w0rd! -> usuario@jfal.jus.br"
        self.assertEqual(
            parse_credential_line(raw),
            ("usuario@jfal.jus.br", "P@$$w0rd!"),
        )


if __name__ == "__main__":
    unittest.main()
