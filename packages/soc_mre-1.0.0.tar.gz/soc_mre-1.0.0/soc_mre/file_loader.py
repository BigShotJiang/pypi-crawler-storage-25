from __future__ import annotations

import csv  # noqa: F401 — stdlib; linhas CSV tratadas em bytes como .txt
import gzip
import mmap
import zipfile
import os
import sys
from pathlib import Path
from typing import Iterable, Iterator

import openpyxl
import pdfplumber
import py7zr
import rarfile

MMAP_THRESHOLD_BYTES = 10 * 1024 * 1024

SLOW_FORMATS = frozenset({".rar", ".7z", ".pdf", ".xlsx"})


def list_domains(input_dir: Path) -> list[Path]:
    if not input_dir.exists():
        return []
    return sorted([p for p in input_dir.iterdir() if p.is_dir()], key=lambda x: x.name.lower())


def list_cti_groups(cti_dir: Path) -> list[Path]:
    """Lista as pastas de primeiro nivel dentro do CTI."""
    return list_domains(cti_dir)


def looks_like_domain_folder(name: str) -> bool:
    cleaned = name.strip()
    if cleaned.startswith("@"):
        cleaned = cleaned[1:]
    return "." in cleaned and " " not in cleaned


def list_domains_in_group(group_dir: Path) -> list[Path]:
    """
    Lista diretorios de dominio dentro do grupo selecionado.
    Busca de forma recursiva para cobrir organizacoes com subniveis.
    """
    if not group_dir.exists() or not group_dir.is_dir():
        return []
    domains = [
        p
        for p in group_dir.rglob("*")
        if p.is_dir() and looks_like_domain_folder(p.name)
    ]
    return sorted(domains, key=lambda x: x.name.lower())


def list_txt_files(base_dir: Path) -> list[Path]:
    """Lista ficheiros de leak suportados (nome da funcao mantido por compatibilidade)."""
    paths: list[Path] = []
    for pattern in (
        "*.txt",
        "*.csv",
        "*.gz",
        "*.zip",
        "*.7z",
        "*.rar",
        "*.pdf",
        "*.xlsx",
    ):
        paths.extend(p for p in base_dir.glob(pattern) if p.is_file())
    return sorted(set(paths), key=lambda x: x.name.lower())


def warn_slow_format(path: Path) -> bool:
    ext = path.suffix.lower()
    if ext in SLOW_FORMATS:
        resposta = input(
            f"[!] {path.name} é um formato lento ({ext}). "
            f"Processar mesmo assim? [s/N]: "
        )
        return resposta.lower() == "s"
    return True


def stream_csv(path: Path) -> Iterator[bytes]:
    with path.open("rb") as f:
        for line in f:
            yield line


def stream_gz(path: Path) -> Iterator[bytes]:
    with gzip.open(path, "rb") as f:
        for line in f:
            yield line


def stream_zip(path: Path) -> Iterator[bytes]:
    """Le linhas de todos os membros do zip em memoria (sem extrair para disco)."""
    with zipfile.ZipFile(path, "r") as zf:
        for name in zf.namelist():
            if name.endswith("/"):
                continue
            with zf.open(name) as f:
                for line in f:
                    yield line


def stream_7z(path: Path) -> Iterator[bytes]:
    """Le membros do 7z em memoria via py7zr.read() (sem extractall para disco)."""
    with py7zr.SevenZipFile(path, "r") as sz:
        for name, bio in sz.read().items():
            if name.endswith("/") or bio is None:
                continue
            bio.seek(0)
            for line in bio:
                yield line


def stream_rar(path: Path) -> Iterator[bytes]:
    """Le membros do RAR em streaming (sem extrair para disco)."""
    with rarfile.RarFile(path) as rf:
        for info in rf.infolist():
            if info.isdir():
                continue
            with rf.open(info) as f:
                for line in f:
                    yield line


def stream_pdf(path: Path) -> Iterator[bytes]:
    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            text = page.extract_text() or ""
            for line in text.splitlines():
                yield line.encode("utf-8")


def stream_xlsx(path: Path) -> Iterator[bytes]:
    wb = openpyxl.load_workbook(path, read_only=True)
    try:
        for ws in wb.worksheets:
            for row in ws.iter_rows(values_only=True):
                line = ":".join(str(c) for c in row if c)
                yield line.encode("utf-8")
    finally:
        wb.close()


def detect_stream_kind(path: Path) -> str:
    """
    Retorna tipo logico para stream_any_file: text/csv, gzip, zip, 7z, rar, pdf, xlsx, ou plano.
    """
    try:
        import magic

        mime = magic.from_file(os.fsdecode(path), mime=True)
        if mime == "text/csv":
            return "text/csv"
        if mime in ("application/gzip", "application/x-gzip"):
            return "gzip"
        if mime == "application/zip":
            return "zip"
        if mime == "application/x-7z-compressed":
            return "7z"
        if mime in ("application/vnd.rar", "application/x-rar-compressed"):
            return "rar"
        if mime == "application/pdf":
            return "pdf"
        if mime == (
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        ):
            return "xlsx"
    except Exception:
        pass
    suf = path.suffix.lower()
    if suf == ".csv":
        return "text/csv"
    if suf == ".gz":
        return "gzip"
    if suf == ".zip":
        return "zip"
    if suf == ".7z":
        return "7z"
    if suf == ".rar":
        return "rar"
    if suf == ".pdf":
        return "pdf"
    if suf == ".xlsx":
        return "xlsx"
    return "text/plain"


def stream_any_file(path: Path, tipo: str | None = None) -> Iterator[bytes]:
    t = tipo if tipo is not None else detect_stream_kind(path)
    if path.suffix.lower() in SLOW_FORMATS:
        if not warn_slow_format(path):
            return
    if t == "text/csv":
        yield from stream_csv(path)
    elif t == "gzip":
        yield from stream_gz(path)
    elif t == "zip":
        yield from stream_zip(path)
    elif t == "7z":
        yield from stream_7z(path)
    elif t == "rar":
        yield from stream_rar(path)
    elif t == "pdf":
        yield from stream_pdf(path)
    elif t == "xlsx":
        yield from stream_xlsx(path)
    else:
        yield from stream_file_lines_raw(path)


def stream_file_lines(file_path: Path) -> Iterator[str]:
    # errors="replace" evita quebra com arquivos parcialmente corrompidos.
    with file_path.open("r", encoding="utf-8", errors="replace") as f:
        for line in f:
            yield line


def stream_file_lines_raw(file_path: Path) -> Iterator[bytes]:
    """
    Leitura em bytes com estrategia hibrida:
    - Arquivos grandes (>10 MB): mmap por padrao.
    - Arquivos menores: streaming tradicional.

    mmap tende a ser mais eficiente em arquivos grandes por reduzir overhead de
    syscalls repetidas e aproveitar melhor o cache de paginas do sistema.
    """
    try:
        file_size = file_path.stat().st_size
    except OSError:
        file_size = 0

    if file_size > MMAP_THRESHOLD_BYTES:
        yield from stream_lines_mmap(file_path)
        return

    # Arquivos pequenos: caminho simples com baixa sobrecarga.
    with file_path.open("rb") as f:
        for raw_line in f:
            yield raw_line


def stream_lines_mmap(filepath: Path) -> Iterator[bytes]:
    with filepath.open("rb") as f:
        with mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as mm:
            for line in iter(mm.readline, b""):
                yield line


def stream_from_stdin() -> Iterator[bytes]:
    for line in sys.stdin.buffer:
        yield line


def progress_iterable(items: Iterable, desc: str):
    try:
        from tqdm import tqdm  # type: ignore
        return tqdm(items, desc=desc, unit="arquivo")
    except Exception:
        return items
