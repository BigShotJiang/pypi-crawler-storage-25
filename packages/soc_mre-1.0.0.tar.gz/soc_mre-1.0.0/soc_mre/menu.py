from __future__ import annotations

from pathlib import Path
from typing import Optional

from rich.console import Console
from rich.table import Table

from .file_loader import list_cti_groups, list_domains_in_group, looks_like_domain_folder

_console = Console()


def print_banner() -> None:
    """Painel SOC MRE (implementacao em main para evitar duplicar markup)."""
    from .main import _print_soc_banner

    _print_soc_banner()


def _print_options_table(
    title: str,
    option_rows: list[tuple[str, str, str]],
    zero_label: str,
    zero_result: str,
) -> None:
    table = Table(show_header=True, header_style="bold cyan", title=title)
    table.add_column("Opcao", style="dim", width=6)
    table.add_column("Dominio / Acao")
    table.add_column("Status", justify="right")
    for opc, nome, status in option_rows:
        table.add_row(opc, nome, status)
    zstatus = "[red]Sair[/]" if zero_result == "__EXIT__" else "[dim]Voltar[/]"
    table.add_row("0", zero_label, zstatus)
    _console.print(table)


def _choose_from_list(
    title: str,
    label: str,
    options: list[Path],
    zero_option_label: str = "Sair",
    zero_result: str = "__EXIT__",
    extra_option_value: int | None = None,
    extra_option_label: str | None = None,
    extra_result: str | None = None,
    extra_option2_value: int | None = None,
    extra_option2_label: str | None = None,
    extra2_result: str | None = None,
) -> Optional[Path]:
    if not options:
        _console.print(f"\n[red][!][/] Nenhuma opcao encontrada para: {title}.\n")
        return None

    print_banner()
    rows: list[tuple[str, str, str]] = []
    for idx, option in enumerate(options, start=1):
        rows.append((str(idx), option.name, "[dim]pendente[/]"))
    if extra_option_value is not None and extra_option_label and extra_result:
        rows.append(
            (
                str(extra_option_value),
                extra_option_label,
                "[bold]varredura completa[/]",
            )
        )
    if extra_option2_value is not None and extra_option2_label and extra2_result:
        rows.append(
            (
                str(extra_option2_value),
                extra_option2_label,
                "[bold cyan]rg + stdin[/]",
            )
        )
    _print_options_table(title, rows, zero_option_label, zero_result)

    while True:
        raw = input(f"\nSelecione {label}: ").strip()
        if not raw.isdigit():
            _console.print("[yellow]Entrada invalida. Digite apenas numeros.[/]")
            continue

        value = int(raw)
        if value == 0:
            return Path(zero_result)
        if (
            extra_option_value is not None
            and extra_option_label
            and extra_result
            and value == extra_option_value
        ):
            return Path(extra_result)
        if (
            extra_option2_value is not None
            and extra_option2_label
            and extra2_result
            and value == extra_option2_value
        ):
            return Path(extra2_result)
        if 1 <= value <= len(options):
            return options[value - 1]

        _console.print("[yellow]Opcao fora do intervalo.[/]")


def choose_cti_group(cti_dir: Path) -> Optional[Path]:
    groups = list_cti_groups(cti_dir)
    return _choose_from_list(
        "Pastas CTI Disponiveis",
        "uma pasta CTI",
        groups,
        extra_option_value=len(groups) + 1 if groups else None,
        extra_option_label="TODOS os dominios",
        extra_result="__ALL_ROOT__",
        extra_option2_value=len(groups) + 2 if groups else None,
        extra_option2_label="Modo turbo por dominio (rg + stdin)",
        extra2_result="__FAST_STDIN__",
    )


def choose_domain_in_group(group_dir: Path) -> Optional[Path]:
    domains = list_domains_in_group(group_dir)
    # Suporta estrutura CTI com dominios no primeiro nivel (sem subpastas).
    if not domains and looks_like_domain_folder(group_dir.name):
        return group_dir
    return _choose_from_list(
        f"Dominios Disponiveis em {group_dir.name}",
        "um dominio",
        domains,
        zero_option_label="Voltar",
        zero_result="__BACK__",
    )
