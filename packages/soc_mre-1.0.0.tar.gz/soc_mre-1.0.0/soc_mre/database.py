from __future__ import annotations

from pathlib import Path
from typing import Dict, Set


CredentialDB = Dict[str, Set[str]]


def load_database(db_path: Path) -> CredentialDB:
    db: CredentialDB = {}
    if not db_path.exists():
        return db

    with db_path.open("r", encoding="utf-8", errors="replace") as f:
        for raw in f:
            line = raw.strip()
            if not line or ":" not in line:
                continue
            email, passwords_raw = line.split(":", 1)
            email = email.strip().lower()
            if not email:
                continue
            password_set = {
                p.strip()
                for p in passwords_raw.split(",")
                if p.strip()
            }
            if not password_set:
                continue
            db.setdefault(email, set()).update(password_set)
    return db


def add_credential(db: CredentialDB, email: str, password: str) -> bool:
    """Retorna True se foi novidade na base."""
    email = email.lower().strip()
    password = password.strip()
    if not email or not password:
        return False

    known = db.setdefault(email, set())
    if password in known:
        return False

    known.add(password)
    return True


def save_database(db_path: Path, db: CredentialDB) -> None:
    tmp = db_path.with_suffix(".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        for email in sorted(db.keys()):
            values = sorted(db[email])
            if not values:
                continue
            f.write(f"{email}:{','.join(values)}\n")
    tmp.replace(db_path)
