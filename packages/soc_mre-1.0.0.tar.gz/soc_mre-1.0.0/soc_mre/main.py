from __future__ import annotations

import argparse
import shutil
import subprocess
from pathlib import Path

import psutil
from rich import print as rprint
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

_ui_console = Console()

from .config import (
    DEFAULT_CONFIG_FILE,
    MASTERLIST_FILENAME,
    load_config,
    save_default_config,
)
from .database import CredentialDB, add_credential, load_database
from .database_sql import (
    add_credential_sql,
    close_db,
    export_domain_txt,
    import_masterlist_txt_to_sql,
    init_db,
    sync_credential_dict_to_sql,
)
from .detector import process_all_domains, process_domain
from .file_loader import (
    list_cti_groups,
    list_domains_in_group,
    looks_like_domain_folder,
    stream_from_stdin,
)
from .menu import choose_cti_group, choose_domain_in_group
from .parser import parse_credential_line
from .utils import (
    load_recent_state,
    normalize_domain,
    sanitize_domain_for_output,
    save_recent_state,
    utc_now_iso,
)

MEMORY_LIMIT_PERCENT = 75  # 75% de 8GB = ~6GB


def _print_soc_banner() -> None:
    rprint(
        Panel.fit(
            "[bold cyan]SOC MRE[/] [dim]v1.0[/]\n"
            "[dim]Credential Intelligence Tool[/]",
            border_style="cyan",
        )
    )


def _print_credential_line(email: str, password: str, is_new: bool) -> None:
    tag = "[green][NOVO][/]" if is_new else "[yellow][JA NA BASE][/]"
    _ui_console.print(f"{email}:{password} {tag}")


def _print_result_summary_table(title: str, rows: list[tuple[str, int, int, int]]) -> None:
    """rows: (dominio, linhas, achados, novos)."""
    table = Table(title=title, header_style="bold cyan")
    table.add_column("Dominio")
    table.add_column("Linhas", justify="right")
    table.add_column("Achados", justify="right")
    table.add_column("Novos", justify="right", style="green")
    for dominio, linhas, achados, novos in rows:
        table.add_row(dominio, str(linhas), str(achados), str(novos))
    _ui_console.print(table)


def _check_dependencies() -> None:
    avisos = []
    try:
        import magic  # noqa: F401
    except ImportError:
        avisos.append(
            "[!] python-magic não encontrado.\n"
            "    Execute: sudo apt install libmagic1"
        )
    try:
        import rarfile

        _ = rarfile.RarFile  # testa import
    except Exception:
        avisos.append(
            "[!] rarfile não encontrado.\n"
            "    Execute: sudo apt install unrar"
        )
    try:
        import py7zr  # noqa: F401
    except ImportError:
        avisos.append("[!] py7zr não encontrado.\n    Execute: pip install py7zr")
    try:
        import pdfplumber  # noqa: F401
    except ImportError:
        avisos.append("[!] pdfplumber não encontrado.\n    Execute: pip install pdfplumber")
    try:
        import openpyxl  # noqa: F401
    except ImportError:
        avisos.append("[!] openpyxl não encontrado.\n    Execute: pip install openpyxl")
    for aviso in avisos:
        _ui_console.print(aviso)


def _memory_ok() -> bool:
    return psutil.virtual_memory().percent < MEMORY_LIMIT_PERCENT


def _memory_usage_str() -> str:
    mem = psutil.virtual_memory()
    return f"{mem.used / 1024 / 1024:.0f}MB / {mem.total / 1024 / 1024:.0f}MB ({mem.percent}%)"


def _print_memory_pressure_warning() -> None:
    _ui_console.print(f"[!] Memoria: {_memory_usage_str()}")
    _ui_console.print("[!] Pressao de memoria — considere encerrar outros processos")


def _warn_memory_if_pressure(lines_count: int) -> None:
    """Chamado pelo detector a cada 100k linhas analisadas/lidas."""
    if lines_count <= 0 or lines_count % 100_000 != 0:
        return
    if not _memory_ok():
        _print_memory_pressure_warning()


def find_cti_domain_dir(cti_dir: Path, domain_arg: str) -> Path | None:
    """
    Localiza a pasta do dominio em qualquer nivel sob CTI
    (ex.: CTI/@brde.com.br ou CTI/PGR/@mpf.mp.br).
    """
    raw = domain_arg.strip()
    if not raw:
        return None
    norm = normalize_domain(raw)
    matches: list[Path] = []
    for p in cti_dir.rglob("*"):
        if not p.is_dir() or not looks_like_domain_folder(p.name):
            continue
        if p.name.lower() == raw.lower() or normalize_domain(p.name) == norm:
            matches.append(p)
    if not matches:
        return None
    exact = [p for p in matches if p.name.lower() == raw.lower()]
    pool = exact if exact else matches
    return min(pool, key=lambda x: len(x.parts))


def _merge_databases(base: CredentialDB, incoming: CredentialDB) -> CredentialDB:
    for email, passwords in incoming.items():
        if not passwords:
            continue
        base.setdefault(email, set()).update(passwords)
    return base


def _migrate_masterlist_txt_if_present(
    db_dir: Path,
    master_path: Path,
    sql_db_path: Path,
    conn,
    insert_count: list,
) -> None:
    if not master_path.is_file():
        return
    n = import_masterlist_txt_to_sql(conn, master_path, insert_count)
    backup = db_dir / f"{master_path.name}.bak"
    master_path.rename(backup)
    _ui_console.print(
        f"[green][+][/] Migracao SQLite: {n} credenciais importadas de {master_path.name} -> {sql_db_path.name}"
    )
    _ui_console.print(f"[green][+][/] Arquivo legado renomeado para: {backup.name}")


def resolve_domain_blacklist_path(domain_dir: Path, domain_name: str) -> tuple[Path, CredentialDB]:
    """
    Usa o novo padrao blackList-<dominio>.txt, mantendo compatibilidade com
    blackList.txt legado quando existir.
    """
    domain_slug = sanitize_domain_for_output(domain_name)
    preferred_path = domain_dir / f"blackList-{domain_slug}.txt"
    legacy_path = domain_dir / "blackList.txt"

    domain_db = load_database(preferred_path)
    if preferred_path != legacy_path and legacy_path.exists():
        _merge_databases(domain_db, load_database(legacy_path))

    return preferred_path, domain_db


def count_records_written(domain_db: CredentialDB) -> int:
    # Cada linha do arquivo representa um email unico.
    return sum(1 for passwords in domain_db.values() if passwords)


def run_fast_stdin_mode(
    leaks_dir: Path,
    cti_dir: Path,
    sql_db_path: Path,
    conn,
    insert_count: list,
    recent_state: dict[str, str],
    state_file: Path,
) -> None:
    rg_bin = shutil.which("rg")
    if not rg_bin:
        _ui_console.print("[red][!][/] rg nao encontrado no sistema. Instale ripgrep para usar o modo turbo.")
        return

    domain = input("\nDigite o dominio (ex.: @sptrans.com.br): ").strip()
    if not domain:
        _ui_console.print("[red][!][/] Dominio vazio.")
        return

    domain_dir = find_cti_domain_dir(cti_dir, domain)
    if domain_dir is None:
        _ui_console.print(f"[red][!][/] Pasta do dominio nao encontrada sob o CTI: {domain}")
        return

    domain_marker = "@" + domain.lower().lstrip("@")
    domain_blacklist_path, domain_database = resolve_domain_blacklist_path(domain_dir, domain)
    sync_credential_dict_to_sql(conn, domain, domain_database, insert_count)

    cmd = [rg_bin, "-i", domain_marker, str(leaks_dir)]
    process = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
    )

    lines_analyzed = 0
    credentials_parsed = 0
    new_credentials = 0

    _ui_console.print(f"\n[bold cyan][+][/] Modo turbo ativo para dominio: {domain}")
    _ui_console.print("[bold][+][/] Credenciais encontradas (usuario:senha):")

    if process.stdout:
        for raw_line in process.stdout:
            lines_analyzed += 1
            if lines_analyzed % 100_000 == 0:
                if not _memory_ok():
                    _print_memory_pressure_warning()
            if domain_marker.encode("ascii", errors="ignore") not in raw_line.lower():
                continue
            line = raw_line.decode("utf-8", errors="replace")
            parsed = parse_credential_line(line)
            if not parsed:
                continue
            email, password = parsed
            if not email.lower().endswith(domain_marker):
                continue
            credentials_parsed += 1
            is_new = add_credential(domain_database, email, password)
            add_credential_sql(
                conn,
                email,
                password,
                domain,
                source=str(leaks_dir),
                insert_count=insert_count,
            )
            if is_new:
                new_credentials += 1
            _print_credential_line(email, password, is_new)

    process.wait()

    if domain_database:
        domain_dir.mkdir(parents=True, exist_ok=True)
    export_domain_txt(conn, domain, domain_blacklist_path)

    recent_state[domain] = utc_now_iso()
    save_recent_state(state_file, recent_state)

    _print_result_summary_table(
        "Resultado Final (turbo)",
        [(domain, lines_analyzed, credentials_parsed, new_credentials)],
    )
    _ui_console.print(f"Credenciais gravadas no .txt: {count_records_written(domain_database)}")
    _ui_console.print(f"Base global (SQLite): {sql_db_path}")
    if domain_database:
        _ui_console.print(f"Base do dominio atualizada: {domain_blacklist_path}")


def build_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Detector defensivo de credenciais por dominio.",
        epilog=(
            'Exemplo: rg -i "@mpf.mp.br" /leaks/ | soc-mre --stdin --domain @mpf.mp.br '
            "-c /caminho/CTI -d /caminho/database  (pasta pode estar em CTI/PGR/@mpf.mp.br)"
        ),
    )
    parser.add_argument(
        "--init-config",
        action="store_true",
        help="Cria um arquivo de configuracao local e encerra.",
    )
    parser.add_argument(
        "--config",
        default=DEFAULT_CONFIG_FILE,
        help="Arquivo JSON com defaults para leaks/cti/database_dir.",
    )
    parser.add_argument(
        "--leaks",
        "-l",
        required=False,
        help="Diretorio com os arquivos .txt de vazamentos (sem subpastas).",
    )
    parser.add_argument(
        "--cti",
        "-c",
        required=False,
        help="Diretorio CTI contendo pastas de dominios monitorados.",
    )
    parser.add_argument(
        "--database-dir",
        "-d",
        required=False,
        help="Diretorio de persistencia (database.db SQLite; migracao de masterList.txt se existir).",
    )
    parser.add_argument(
        "--recent-hours",
        type=int,
        default=24,
        help="Janela para considerar um dominio processado recentemente.",
    )
    parser.add_argument(
        "--state-file",
        default=".processed_state.json",
        help="Arquivo que registra a ultima analise por dominio.",
    )
    parser.add_argument(
        "--stdin",
        action="store_true",
        help="Le linhas do stdin (permite pipe com rg/grep)",
    )
    parser.add_argument(
        "--domain",
        required=False,
        help="Dominio alvo para o modo --stdin.",
    )
    return parser.parse_args()


def main() -> int:
    _check_dependencies()
    args = build_args()
    config_path = Path(args.config)

    if args.init_config:
        save_default_config(config_path)
        _ui_console.print(f"[green][+][/] Configuracao criada: {config_path}")
        _ui_console.print("[dim][i][/] Edite os caminhos e rode: soc-mre")
        return 0

    config_data = load_config(config_path)

    leaks_value = args.leaks or config_data.get("leaks")
    cti_value = args.cti or config_data.get("cti")
    db_value = args.database_dir or config_data.get("database_dir")
    recent_hours = args.recent_hours
    if recent_hours == 24 and isinstance(config_data.get("recent_hours"), int):
        recent_hours = config_data["recent_hours"]
    state_file_value = args.state_file
    if state_file_value == ".processed_state.json" and isinstance(config_data.get("state_file"), str):
        state_file_value = config_data["state_file"]

    if args.stdin and not args.domain:
        _ui_console.print("[red][!][/] Em modo --stdin, informe --domain explicitamente.")
        _ui_console.print(
            "[dim][i][/] Exemplo: rg -i \"@mpf.mp.br\" /leaks/ | soc-mre --stdin --domain @mpf.mp.br "
            "-c /caminho/CTI -d /caminho/database"
        )
        return 1

    if not db_value:
        _ui_console.print(
            "[red][!][/] Parametro obrigatorio ausente: --database-dir (ou database_dir no config)."
        )
        return 1

    if not args.stdin and (not leaks_value or not cti_value):
        _ui_console.print("[red][!][/] Parametros obrigatorios ausentes.")
        _ui_console.print("[dim][i][/] Rode com: soc-mre -l <leaks> -c <cti> -d <database>")
        _ui_console.print("[dim][i][/] Ou gere config com: soc-mre --init-config")
        return 1

    leaks_dir = Path(leaks_value) if leaks_value else None
    cti_dir = Path(cti_value) if cti_value else None
    db_dir = Path(db_value)
    db_path = db_dir / MASTERLIST_FILENAME
    state_file = Path(state_file_value)

    if not args.stdin and (leaks_dir is None or not leaks_dir.exists() or not leaks_dir.is_dir()):
        _ui_console.print(f"[red][!][/] Diretorio de leaks invalido: {leaks_dir}")
        return 1

    if not args.stdin and (cti_dir is None or not cti_dir.exists() or not cti_dir.is_dir()):
        _ui_console.print(f"[red][!][/] Diretorio CTI invalido: {cti_dir}")
        return 1

    if not db_dir.exists() or not db_dir.is_dir():
        _ui_console.print(f"[red][!][/] Diretorio da base invalido: {db_dir}")
        return 1

    sql_db_path = db_dir / "database.db"
    insert_count = [0]
    conn = init_db(sql_db_path)
    try:
        _migrate_masterlist_txt_if_present(db_dir, db_path, sql_db_path, conn, insert_count)
        recent_state = load_recent_state(state_file)

        if args.stdin:
            if cti_dir is None or not cti_dir.exists() or not cti_dir.is_dir():
                _ui_console.print(
                    "[red][!][/] Modo --stdin requer diretorio CTI valido (-c ou chave cti no config) "
                    "para gravar blackList-<dominio>.txt."
                )
                return 1

            domain = args.domain.strip()
            domain_marker = "@" + domain.lower().lstrip("@")
            domain_dir = find_cti_domain_dir(cti_dir, domain)
            if domain_dir is None:
                _ui_console.print(f"[red][!][/] Pasta do dominio nao encontrada sob o CTI: {domain}")
                _ui_console.print(
                    "[dim][i][/] Use o nome da pasta do dominio (ex.: @brde.com.br na raiz, "
                    "ou @mpf.mp.br dentro de PGR/). Pastas de grupo (PGR, TRF5) nao sao dominios."
                )
                return 1
            domain_blacklist_path, domain_database = resolve_domain_blacklist_path(domain_dir, domain)
            sync_credential_dict_to_sql(conn, domain, domain_database, insert_count)

            lines_analyzed = 0
            credentials_parsed = 0
            new_credentials = 0

            _ui_console.print(f"\n[bold cyan][+][/] Modo stdin ativo para dominio: {domain}")
            _ui_console.print("[bold][+][/] Credenciais encontradas (usuario:senha):")

            for raw_line in stream_from_stdin():
                lines_analyzed += 1
                if lines_analyzed % 100_000 == 0:
                    if not _memory_ok():
                        _print_memory_pressure_warning()
                if domain_marker.encode("ascii", errors="ignore") not in raw_line.lower():
                    continue
                line = raw_line.decode("utf-8", errors="replace")
                parsed = parse_credential_line(line)
                if not parsed:
                    continue
                email, password = parsed
                if not email.lower().endswith(domain_marker):
                    continue
                credentials_parsed += 1
                is_new = add_credential(domain_database, email, password)
                add_credential_sql(
                    conn,
                    email,
                    password,
                    domain,
                    source="stdin",
                    insert_count=insert_count,
                )
                if is_new:
                    new_credentials += 1
                _print_credential_line(email, password, is_new)

            if domain_database:
                domain_dir.mkdir(parents=True, exist_ok=True)
            export_domain_txt(conn, domain, domain_blacklist_path)

            recent_state[domain] = utc_now_iso()
            save_recent_state(state_file, recent_state)

            _print_result_summary_table(
                "Resultado Final (stdin)",
                [(domain, lines_analyzed, credentials_parsed, new_credentials)],
            )
            _ui_console.print(f"Credenciais gravadas no .txt: {count_records_written(domain_database)}")
            _ui_console.print(f"Base global (SQLite): {sql_db_path}")
            if domain_database:
                _ui_console.print(f"Base do dominio atualizada: {domain_blacklist_path}")
            return 0

        def process_single_domain(
            selected_domain: Path,
        ) -> tuple[str, int, int, int, int, Path]:
            domain = selected_domain.name
            domain_blacklist_path, domain_database = resolve_domain_blacklist_path(
                selected_domain, domain
            )
            sync_credential_dict_to_sql(conn, domain, domain_database, insert_count)

            _ui_console.print(f"\n[bold cyan][+][/] Iniciando analise do dominio: {domain}")
            _ui_console.print("[bold][+][/] Credenciais encontradas (usuario:senha):")
            stats = process_domain(
                leaks_dir=leaks_dir,
                domain=domain,
                conn=conn,
                insert_count=insert_count,
                domain_local_db=domain_database,
                on_credential_found=lambda e, p, n: _print_credential_line(e, p, n),
                on_leak_lines_milestone=_warn_memory_if_pressure,
            )
            recent_state[domain] = utc_now_iso()
            save_recent_state(state_file, recent_state)
            export_domain_txt(conn, domain, domain_blacklist_path)

            _print_result_summary_table(
                "Resultado Final",
                [
                    (
                        domain,
                        stats.lines_analyzed,
                        stats.credentials_parsed,
                        stats.new_credentials,
                    )
                ],
            )
            _ui_console.print(f"Arquivos processados: {stats.files_processed}")
            _ui_console.print(f"Credenciais gravadas no .txt: {count_records_written(domain_database)}")
            _ui_console.print(f"Arquivos com erro: {stats.file_errors}")
            _ui_console.print(f"Base global (SQLite): {sql_db_path}")
            _ui_console.print(f"Base do dominio atualizada: {domain_blacklist_path}")
            return (
                domain,
                stats.files_processed,
                stats.lines_analyzed,
                stats.credentials_parsed,
                stats.new_credentials,
                stats.file_errors,
                domain_blacklist_path,
            )

        def collect_domains_from_group(group_dir: Path) -> list[Path]:
            domains = list_domains_in_group(group_dir)
            if not domains and looks_like_domain_folder(group_dir.name):
                return [group_dir]
            return domains

        def process_domains_batch(domains: list[Path], context_label: str) -> None:
            if not domains:
                _ui_console.print("\n[dim][i][/] Nenhum dominio encontrado para varredura em lote.")
                return

            _ui_console.print(f"\n[bold cyan][+][/] Iniciando varredura completa de {len(domains)} dominio(s).")
            totals = {
                "domains": 0,
                "files_processed": 0,
                "lines_analyzed": 0,
                "credentials_parsed": 0,
                "new_credentials": 0,
                "file_errors": 0,
            }

            if len(domains) > 1:
                domain_names = [p.name for p in domains]
                domain_databases: dict[str, CredentialDB] = {}
                save_targets: list[tuple[Path, str, Path, CredentialDB]] = []
                for domain_path in domains:
                    name = domain_path.name
                    bl_path, dom_db = resolve_domain_blacklist_path(domain_path, name)
                    domain_databases[name] = dom_db
                    save_targets.append((domain_path, name, bl_path, dom_db))
                    sync_credential_dict_to_sql(conn, name, dom_db, insert_count)

                _ui_console.print("[bold][+][/] Modo combinado: uma passada nos arquivos de leak.")
                _ui_console.print("[bold][+][/] Credenciais encontradas (usuario:senha):")
                stats_map = process_all_domains(
                    leaks_dir=leaks_dir,
                    domains=domain_names,
                    conn=conn,
                    insert_count=insert_count,
                    domain_databases=domain_databases,
                    on_credential_found=lambda e, p, n: _print_credential_line(e, p, n),
                    on_leak_lines_milestone=_warn_memory_if_pressure,
                )

                for domain_path in domains:
                    name = domain_path.name
                    recent_state[name] = utc_now_iso()
                save_recent_state(state_file, recent_state)
                for domain_path, name, bl_path, _dom_db in save_targets:
                    domain_path.mkdir(parents=True, exist_ok=True)
                    export_domain_txt(conn, name, bl_path)

                totals["domains"] = len(domains)
                for name in domain_names:
                    st = stats_map.get(name)
                    if not st:
                        continue
                    totals["files_processed"] += st.files_processed
                    totals["lines_analyzed"] += st.lines_analyzed
                    totals["credentials_parsed"] += st.credentials_parsed
                    totals["new_credentials"] += st.new_credentials
                    totals["file_errors"] += st.file_errors

                per_rows: list[tuple[str, int, int, int]] = []
                for name in domain_names:
                    st = stats_map.get(name)
                    if st:
                        per_rows.append(
                            (
                                name,
                                st.lines_analyzed,
                                st.credentials_parsed,
                                st.new_credentials,
                            )
                        )
                if per_rows:
                    _print_result_summary_table(
                        "Resultado por dominio (passada unica)",
                        per_rows,
                    )
                for _domain_path, name, bl_path, dom_db in save_targets:
                    st = stats_map.get(name)
                    if not st:
                        continue
                    _ui_console.print(
                        f"[dim]{name}[/] — arquivos: {st.files_processed} | "
                        f"gravados .txt: {count_records_written(dom_db)} | erros: {st.file_errors}"
                    )
                    _ui_console.print(f"[dim]  ->[/] {bl_path}")

            else:
                for domain_path in domains:
                    (
                        _domain_name,
                        files_processed,
                        lines_analyzed,
                        credentials_parsed,
                        new_credentials,
                        file_errors,
                        _domain_blacklist_path,
                    ) = process_single_domain(domain_path)
                    totals["domains"] += 1
                    totals["files_processed"] += files_processed
                    totals["lines_analyzed"] += lines_analyzed
                    totals["credentials_parsed"] += credentials_parsed
                    totals["new_credentials"] += new_credentials
                    totals["file_errors"] += file_errors

            _print_result_summary_table(
                "Resultado Final (Consolidado)",
                [
                    (
                        f"TOTAL ({totals['domains']} dominios)",
                        totals["lines_analyzed"],
                        totals["credentials_parsed"],
                        totals["new_credentials"],
                    )
                ],
            )
            _ui_console.print(f"Arquivos processados: {totals['files_processed']}")
            _ui_console.print(f"Arquivos com erro: {totals['file_errors']}")
            _ui_console.print(f"Base global (SQLite): {sql_db_path}")
            _ui_console.print(f"\n[dim]Retornando ao menu principal ({context_label})...[/]")


        while True:
            selected_group = choose_cti_group(cti_dir)
            if selected_group is None:
                return 0

            if selected_group.name == "__EXIT__":
                _ui_console.print("\n[dim]Encerrando.[/]")
                break

            if selected_group.name == "__ALL_ROOT__":
                root_entries = list_cti_groups(cti_dir)
                all_domains: list[Path] = []
                for entry in root_entries:
                    all_domains.extend(collect_domains_from_group(entry))
                # Remove duplicados mantendo ordem.
                unique_domains = list(dict.fromkeys(all_domains))
                process_domains_batch(unique_domains, "todos os dominios")
                continue

            if selected_group.name == "__FAST_STDIN__":
                run_fast_stdin_mode(
                    leaks_dir=leaks_dir,
                    cti_dir=cti_dir,
                    sql_db_path=sql_db_path,
                    conn=conn,
                    insert_count=insert_count,
                    recent_state=recent_state,
                    state_file=state_file,
                )
                _ui_console.print("\n[dim]Retornando ao menu principal...[/]")
                continue

            if looks_like_domain_folder(selected_group.name):
                process_single_domain(selected_group)
                _ui_console.print("\n[dim]Retornando ao menu principal...[/]")
                continue

            while True:
                selected_domain = choose_domain_in_group(selected_group)
                if selected_domain is None:
                    _ui_console.print("\n[dim][i][/] Nenhum dominio encontrado nessa pasta CTI.")
                    break

                if selected_domain.name == "__BACK__":
                    break

                process_single_domain(selected_domain)
                _ui_console.print(f"\n[dim]Retornando aos dominios de {selected_group.name}...[/]")

        return 0
    finally:
        close_db(conn)


if __name__ == "__main__":
    raise SystemExit(main())
