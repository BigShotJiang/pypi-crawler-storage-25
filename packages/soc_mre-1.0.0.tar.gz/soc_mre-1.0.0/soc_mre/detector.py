from __future__ import annotations

import re
import shutil
import sqlite3
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

# Intervalo alinhado ao monitoramento de RAM em main.py (aviso a cada N linhas lidas).
_LEAK_LINES_MEMORY_MILESTONE = 100_000

from .database import CredentialDB, add_credential
from .database_sql import add_credential_sql
from .file_loader import list_txt_files, progress_iterable, stream_any_file
from .parser import parse_credential_line, parse_line
from .utils import normalize_domain


@dataclass
class DetectionStats:
    files_processed: int = 0
    lines_analyzed: int = 0
    credentials_parsed: int = 0
    new_credentials: int = 0
    file_errors: int = 0


DomainStats = DetectionStats


def _belongs_to_domain(email: str, domain: str) -> bool:
    normalized_domain = normalize_domain(domain)
    return email.lower().endswith("@" + normalized_domain)


def _parse_candidate_line(raw_line: bytes, domain: str) -> Optional[tuple[str, str]]:
    line = raw_line.decode("utf-8", errors="replace")
    stripped = line.strip()
    if not stripped:
        return None

    credential_login: str
    password: str
    if stripped.lower().startswith("http"):
        parsed_url = parse_line(stripped)
        if not parsed_url:
            return None
        credential_login = parsed_url["login"].lower()
        password = parsed_url["password"]
    else:
        parsed_legacy = parse_credential_line(stripped)
        if not parsed_legacy:
            return None
        credential_login, password = parsed_legacy

    if not _belongs_to_domain(credential_login, domain):
        return None

    return credential_login, password


def _stream_rg_candidates(leaks_dir: Path, normalized_domain: str):
    rg_bin = shutil.which("rg")
    if not rg_bin:
        return None

    # Pre-filtra por dominio diretamente no rg, reduzindo IO total.
    cmd = [
        rg_bin,
        "-i",
        "--no-heading",
        "--no-filename",
        "--glob",
        "*.txt",
        "--glob",
        "*.csv",
        "--glob",
        "*.gz",
        "--glob",
        "*.zip",
        "--glob",
        "*.7z",
        "--glob",
        "*.rar",
        "--glob",
        "*.pdf",
        "--glob",
        "*.xlsx",
        f"@{normalized_domain}",
        str(leaks_dir),
    ]
    process = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
    )
    return process


def _domain_key_for_boundary_match(matched_fragment: str, domains: list[str]) -> Optional[str]:
    """Resolve o dominio canonico (chave em domain_databases) a partir do trecho casado no regex."""
    norm_hit = normalize_domain(matched_fragment)
    for d in domains:
        if normalize_domain(d) == norm_hit:
            return d
    return None


def _stream_rg_all_domains(leaks_dir: Path, rg_pattern: str):
    """
    rg com padrao combinado (ex.: @dom1|@dom2). Mantem --glob *.txt alinhado a process_domain.
    """
    rg_bin = shutil.which("rg")
    if not rg_bin:
        return None
    cmd = [
        rg_bin,
        "-i",
        "--no-heading",
        "--no-filename",
        "--glob",
        "*.txt",
        "--glob",
        "*.csv",
        "--glob",
        "*.gz",
        "--glob",
        "*.zip",
        "--glob",
        "*.7z",
        "--glob",
        "*.rar",
        "--glob",
        "*.pdf",
        "--glob",
        "*.xlsx",
        "-a",
        rg_pattern,
        str(leaks_dir),
    ]
    process = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
    )
    return process


def process_all_domains(
    leaks_dir: Path,
    domains: list[str],
    conn: sqlite3.Connection,
    insert_count: list,
    domain_databases: dict[str, CredentialDB],
    on_credential_found: Optional[Callable[[str, str, bool], None]] = None,
    on_leak_lines_milestone: Optional[Callable[[int], None]] = None,
) -> dict[str, DomainStats]:
    """
    Uma passada nos leaks para varios dominios: rg (ou leitura unica) + regex com boundary
    no dominio normalizado (evita brde dentro de abrde).
    """
    if not domains:
        return {}

    txt_files = list_txt_files(leaks_dir)
    n_files = len(txt_files)
    # Maior primeiro no alternativo do regex para estabilidade com sobreposicoes textuais.
    domain_order = sorted(domains, key=lambda d: len(normalize_domain(d)), reverse=True)
    escaped_frags = [re.escape(normalize_domain(d)) for d in domain_order]
    pattern = re.compile(
        r"(?<!\w)(" + "|".join(escaped_frags) + r")(?!\w)",
        re.IGNORECASE,
    )
    rg_pattern = "|".join("@" + normalize_domain(d) for d in domain_order)

    stats_by: dict[str, DetectionStats] = {
        d: DetectionStats(files_processed=n_files) for d in domains
    }

    def _emit_credential(
        domain_key: str,
        credential_login: str,
        password: str,
        source: str,
    ) -> None:
        st = stats_by[domain_key]
        st.credentials_parsed += 1
        local_db = domain_databases[domain_key]
        is_new = add_credential(local_db, credential_login, password)
        add_credential_sql(
            conn,
            credential_login,
            password,
            domain_key,
            source=source,
            insert_count=insert_count,
        )
        if is_new:
            st.new_credentials += 1
        if on_credential_found:
            on_credential_found(credential_login, password, is_new)

    leak_lines_seen = 0

    def _bump_raw_line() -> None:
        nonlocal leak_lines_seen
        leak_lines_seen += 1
        if (
            on_leak_lines_milestone
            and leak_lines_seen % _LEAK_LINES_MEMORY_MILESTONE == 0
        ):
            on_leak_lines_milestone(leak_lines_seen)

    rg_process = _stream_rg_all_domains(leaks_dir, rg_pattern)
    if rg_process and rg_process.stdout:
        for raw_line in rg_process.stdout:
            _bump_raw_line()
            line_str = raw_line.decode("utf-8", errors="replace")
            m = pattern.search(line_str)
            if not m:
                continue
            domain_key = _domain_key_for_boundary_match(m.group(1), domains)
            if domain_key is None:
                continue
            stats_by[domain_key].lines_analyzed += 1
            parsed = _parse_candidate_line(raw_line, domain_key)
            if not parsed:
                continue
            credential_login, password = parsed
            _emit_credential(domain_key, credential_login, password, str(leaks_dir))

        return_code = rg_process.wait()
        if return_code in (0, 1):
            return stats_by

    for file_path in progress_iterable(txt_files, desc="Processando multiplos dominios"):
        try:
            for raw_line in stream_any_file(file_path):
                _bump_raw_line()
                line_str = raw_line.decode("utf-8", errors="replace")
                m = pattern.search(line_str)
                if not m:
                    continue
                domain_key = _domain_key_for_boundary_match(m.group(1), domains)
                if domain_key is None:
                    continue
                stats_by[domain_key].lines_analyzed += 1
                parsed = _parse_candidate_line(raw_line, domain_key)
                if not parsed:
                    continue
                credential_login, password = parsed
                _emit_credential(
                    domain_key,
                    credential_login,
                    password,
                    str(file_path),
                )
        except OSError:
            for d in domains:
                stats_by[d].file_errors += 1
            continue

    return stats_by


def process_domain(
    leaks_dir: Path,
    domain: str,
    conn: sqlite3.Connection,
    insert_count: list,
    domain_local_db: CredentialDB,
    on_credential_found: Optional[Callable[[str, str, bool], None]] = None,
    on_leak_lines_milestone: Optional[Callable[[int], None]] = None,
) -> DetectionStats:
    stats = DetectionStats()
    txt_files = list_txt_files(leaks_dir)
    stats.files_processed = len(txt_files)
    normalized_domain = normalize_domain(domain)
    domain_marker_bytes = f"@{normalized_domain}".encode("ascii", errors="ignore")

    rg_process = _stream_rg_candidates(leaks_dir, normalized_domain)
    if rg_process and rg_process.stdout:
        for raw_line in rg_process.stdout:
            stats.lines_analyzed += 1
            if (
                on_leak_lines_milestone
                and stats.lines_analyzed % _LEAK_LINES_MEMORY_MILESTONE == 0
            ):
                on_leak_lines_milestone(stats.lines_analyzed)
            parsed = _parse_candidate_line(raw_line, domain)
            if not parsed:
                continue
            credential_login, password = parsed

            stats.credentials_parsed += 1
            is_new = add_credential(
                domain_local_db, credential_login, password
            )
            add_credential_sql(
                conn,
                credential_login,
                password,
                domain,
                source=str(leaks_dir),
                insert_count=insert_count,
            )
            if is_new:
                stats.new_credentials += 1
            if on_credential_found:
                on_credential_found(credential_login, password, is_new)

        return_code = rg_process.wait()
        # rc=0 encontrou matches, rc=1 sem match, demais = erro.
        if return_code in (0, 1):
            return stats
        # Falhou no rg: segue com o caminho legado.

    for file_path in progress_iterable(txt_files, desc=f"Processando {domain}"):
        try:
            for raw_line in stream_any_file(file_path):
                stats.lines_analyzed += 1
                if (
                    on_leak_lines_milestone
                    and stats.lines_analyzed % _LEAK_LINES_MEMORY_MILESTONE == 0
                ):
                    on_leak_lines_milestone(stats.lines_analyzed)
                # Fase 1 (rapida): filtra por dominio em bytes.
                if domain_marker_bytes not in raw_line.lower():
                    continue

                # Fase 2 (custosa): parse completo apenas em linhas candidatas.
                parsed = _parse_candidate_line(raw_line, domain)
                if not parsed:
                    continue
                credential_login, password = parsed

                stats.credentials_parsed += 1
                # Etapa 1: banco do dominio define [NOVO] / [JA NA BASE] na saida.
                # Etapa 2: banco global sempre atualizado (retorno ignorado).
                is_new = add_credential(
                    domain_local_db, credential_login, password
                )
                add_credential_sql(
                    conn,
                    credential_login,
                    password,
                    domain,
                    source=str(file_path),
                    insert_count=insert_count,
                )
                if is_new:
                    stats.new_credentials += 1
                if on_credential_found:
                    on_credential_found(credential_login, password, is_new)
        except OSError:
            stats.file_errors += 1
            continue

    return stats
