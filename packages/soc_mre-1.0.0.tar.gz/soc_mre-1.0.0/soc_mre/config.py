from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict


DEFAULT_CONFIG_FILE = "soc_mre.json"

MASTERLIST_FILENAME = "masterList.txt"


def load_config(config_path: Path) -> Dict[str, Any]:
    if not config_path.exists():
        return {}
    try:
        raw = json.loads(config_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}
    if not isinstance(raw, dict):
        return {}
    return raw


def save_default_config(config_path: Path) -> None:
    template = {
        "leaks": "/home/kali/Area de trabalho/leaks_23-04-2026",
        "cti": "/home/kali/Area de trabalho/CTI",
        "database_dir": "/home/kali/Area de trabalho/database",
        "blacklist_pattern": "blackList-<dominio>.txt",
        "recent_hours": 24,
        "state_file": ".processed_state.json",
    }
    config_path.write_text(
        json.dumps(template, ensure_ascii=True, indent=2),
        encoding="utf-8",
    )
