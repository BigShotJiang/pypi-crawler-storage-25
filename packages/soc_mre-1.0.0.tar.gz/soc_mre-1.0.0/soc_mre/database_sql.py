from __future__ import annotations

import sqlite3
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from .database import CredentialDB


def init_db(db_path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("""
        CREATE TABLE IF NOT EXISTS credentials (
            email    TEXT NOT NULL,
            password TEXT NOT NULL,
            domain   TEXT NOT NULL,
            source   TEXT,
            found_at TEXT DEFAULT (datetime('now')),
            PRIMARY KEY (email, password)
        )
    """)
    conn.commit()
    return conn


def add_credential_sql(
    conn: sqlite3.Connection,
    email: str,
    password: str,
    domain: str,
    source: Optional[str] = None,
    insert_count: Optional[list] = None,
) -> bool:
    cursor = conn.execute(
        "INSERT OR IGNORE INTO credentials "
        "(email, password, domain, source) VALUES (?,?,?,?)",
        (email.lower(), password, domain, source),
    )
    inserted = cursor.rowcount > 0
    if inserted and insert_count is not None:
        insert_count[0] += 1
        if insert_count[0] % 100_000 == 0:
            conn.commit()
    return inserted


def _get_timestamped_path(output_path: Path) -> Path:
    """
    Gera um nome de arquivo único usando timestamp com microssegundos.
    Evita colisão mesmo em execuções simultâneas.
    """
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S-%f")

    base = output_path.stem
    suffix = output_path.suffix
    parent = output_path.parent

    return parent / f"{base}_{timestamp}{suffix}"


def export_domain_txt(
    conn: sqlite3.Connection,
    domain: str,
    output_path: Path,
) -> int:
    rows = conn.execute(
        "SELECT email, GROUP_CONCAT(password, ',' ORDER BY password) "
        "FROM credentials WHERE domain=? "
        "GROUP BY email ORDER BY email",
        (domain,),
    ).fetchall()
    if not rows:
        return 0
    target_path = _get_timestamped_path(output_path)
    tmp = target_path.with_suffix(".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        for email, passwords in rows:
            f.write(f"{email}:{passwords}\n")
    tmp.replace(target_path)
    return len(rows)


def close_db(conn: sqlite3.Connection) -> None:
    conn.commit()
    conn.close()


# Linhas migradas de masterList.txt sem dominio por linha.
_MASTERLIST_DOMAIN = "__masterlist__"


def import_masterlist_txt_to_sql(
    conn: sqlite3.Connection,
    masterlist_path: Path,
    insert_count: Optional[list] = None,
) -> int:
    """Importa conteudo de masterList.txt (formato database.load_database) para o SQLite."""
    from .database import load_database

    if not masterlist_path.exists():
        return 0
    legacy: CredentialDB = load_database(masterlist_path)
    n = 0
    for email, passwords in legacy.items():
        for password in passwords:
            if add_credential_sql(
                conn,
                email,
                password,
                _MASTERLIST_DOMAIN,
                "migration:masterList.txt",
                insert_count,
            ):
                n += 1
    conn.commit()
    return n


def sync_credential_dict_to_sql(
    conn: sqlite3.Connection,
    domain: str,
    cred_db: "CredentialDB",
    insert_count: Optional[list] = None,
) -> None:
    """Garante no SQLite as credenciais ja carregadas do blackList-<dominio>.txt em RAM."""
    for email, passwords in cred_db.items():
        for password in passwords:
            add_credential_sql(
                conn,
                email,
                password,
                domain,
                "import:blackList",
                insert_count,
            )
    conn.commit()
