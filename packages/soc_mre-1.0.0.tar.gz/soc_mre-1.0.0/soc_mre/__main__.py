"""Permite: python -m soc_mre [args]"""

from .main import main

if __name__ == "__main__":
    raise SystemExit(main())
