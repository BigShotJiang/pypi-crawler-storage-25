"""SOC MRE — pacote de análise de credenciais para SOC."""
