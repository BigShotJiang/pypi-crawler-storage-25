from __future__ import annotations

import re
from typing import Optional, Tuple

from .utils import EMAIL_PATTERN


# Remove apenas separador no inicio da faixa de senha.
# Nao altera o restante para evitar truncar caracteres especiais validos.
LEADING_SEPARATOR_PATTERN = re.compile(r"^\s*(?:->|:|;|\||\s+)\s*")
TRAILING_SEPARATOR_PATTERN = re.compile(r"\s*(?:->|:|;|\|)\s*$")
SCHEME_RE = re.compile(r"^(https?://)(.+)$", re.IGNORECASE)


def _clean_token(value: str) -> str:
    return value.strip().strip("'\"`").strip()


def _extract_password_from_right_side(right_side: str) -> str:
    # Usa tudo apos o primeiro email, removendo apenas delimitador inicial.
    return _clean_token(LEADING_SEPARATOR_PATTERN.sub("", right_side, count=1))


def _clean_password(password: str) -> str:
    for marker in ("https://", "http://"):
        if marker in password:
            password = password.split(marker)[0]
    return password.rstrip(":").strip()


def _has_structural_separators(value: str) -> bool:
    # Prefixos como host/path: ou key=value: sao comuns em dumps e nao devem
    # ser descartados como ruido so por nao conter espacos.
    return any(ch in value for ch in (":", "/", "\\", "|", ";", "="))


def parse_line(line: str) -> Optional[dict[str, str]]:
    """
    Parser rapido para o formato moderno: url:login:senha.

    Decisao de performance:
    - Usa split limitado (max 2 separacoes), evitando regex pesada no caminho
      mais frequente de dumps com URL no inicio.
    - Descarta cedo linhas com baixa probabilidade de credencial real.
    """
    raw = line.strip()
    if not raw:
        return None

    match = SCHEME_RE.match(raw)
    if not match:
        return None

    scheme = match.group(1)
    rest = match.group(2)

    parts = rest.split(":", 2)
    if len(parts) < 3:
        return None

    host = _clean_token(parts[0])
    login = _clean_token(parts[1])
    password = _clean_token(parts[2])
    if not host or not login or not password:
        return None

    if "@" not in login and "." not in host:
        return None

    return {
        "url": scheme + host,
        "login": login,
        "password": password,
        "raw": raw,
    }


def parse_credential_line(line: str) -> Optional[Tuple[str, str]]:
    """
    Extrai (email, senha) de uma linha.

    Decisao de performance:
    - Se a linha comeca com "http", tenta primeiro o parser de split rapido
      (caminho otimizado para url:login:senha).
    - Em linhas sem URL inicial, usa a estrategia regex existente para manter
      compatibilidade com formatos antigos (email:senha e variantes).

    Aceita formatos como:
    - email:senha
    - email;senha
    - email senha
    - login@dominio | senha
    """
    raw = line.strip()
    if not raw:
        return None

    if raw.lower().startswith("http"):
        parsed = parse_line(raw)
        if parsed:
            login = parsed["login"].lower()
            if "@" not in login:
                return None
            password = _clean_password(parsed["password"])
            if not password:
                return None
            return login, password

    # Sempre considera o primeiro email valido da linha.
    email_match = EMAIL_PATTERN.search(raw)
    if not email_match:
        return None

    before_prefix = raw[: email_match.start()].strip()
    if len(before_prefix) > 10 and " " not in before_prefix and not _has_structural_separators(before_prefix):
        return None

    email = email_match.group(0).lower()
    before = raw[: email_match.start()]
    after = raw[email_match.end() :]

    # Caminho principal: tudo depois do email e considerado senha potencial.
    if after.strip():
        password = _extract_password_from_right_side(after)
        if password:
            password = _clean_password(password)
            if not password:
                return None
            return email, password

    # Fallback para linhas invertidas: "senha -> email"
    # Preserva caracteres especiais da senha e remove separador final.
    if before.strip():
        candidate = _clean_token(TRAILING_SEPARATOR_PATTERN.sub("", before, count=1))
        if candidate:
            candidate = _clean_password(candidate)
            if not candidate:
                return None
            return email, candidate

    return None
