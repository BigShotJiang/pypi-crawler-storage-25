from __future__ import annotations

import json
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict


EMAIL_PATTERN = re.compile(
    r"(?i)\b[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}\b"
)


def sanitize_domain_for_output(domain: str) -> str:
    """Converte o nome do dominio para usar em nome de arquivo."""
    base = normalize_domain(domain)
    if "." in base:
        base = base.split(".", 1)[0]
    return re.sub(r"[^a-z0-9_\-]+", "_", base) or "domain"


def normalize_domain(domain: str) -> str:
    """Normaliza dominio vindo de pasta (ex.: '@jfal.jus.br')."""
    return domain.strip().lower().lstrip("@")


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def load_recent_state(state_file: Path) -> Dict[str, str]:
    if not state_file.exists():
        return {}
    try:
        data = json.loads(state_file.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return {str(k): str(v) for k, v in data.items()}
    except (json.JSONDecodeError, OSError):
        return {}
    return {}


def save_recent_state(state_file: Path, state: Dict[str, str]) -> None:
    state_file.parent.mkdir(parents=True, exist_ok=True)
    state_file.write_text(
        json.dumps(state, ensure_ascii=True, indent=2),
        encoding="utf-8",
    )


def was_processed_recently(
    domain: str,
    state: Dict[str, str],
    hours: int,
) -> bool:
    raw = state.get(domain)
    if not raw:
        return False
    try:
        last_dt = datetime.fromisoformat(raw)
    except ValueError:
        return False
    return (datetime.now(timezone.utc) - last_dt) < timedelta(hours=hours)
