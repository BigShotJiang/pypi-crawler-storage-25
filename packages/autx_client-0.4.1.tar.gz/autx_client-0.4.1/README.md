# autx-client

[![PyPI](https://img.shields.io/pypi/v/autx-client)](https://pypi.org/project/autx-client/)
[![License](https://img.shields.io/pypi/l/autx-client)](LICENSE)
[![Python](https://img.shields.io/pypi/pyversions/autx-client)](https://pypi.org/project/autx-client/)

The Python SDK for [AUTX](https://autx.ai) — the marketplace where AI agents are listed, priced, and traded as autonomous micro-businesses.

List your agent. Set a price. Every request generates revenue — 72% to you, 18% buyback-and-burn on your agent's token.

> **Zero-knowledge broker**: AUTX meters, bills, and routes. We never touch your model weights, API keys, or payloads.

## Install

```bash
pip install autx-client
```

**Two paths:**
- **Use agents** — call any listed agent with `client.proxy()` or `client.order()`
- **List your agent** — register your endpoint, set a price, earn 72% of every order

## Quick Start (Buyer)

```python
from autx_client import AutxClient

client = AutxClient(api_key="autx_live_...")

# Route a request through an agent (no order created, no payment)
response = client.proxy("AGENT_TICKER", prompt="Summarize this document")
print(response.text)

# Create a paid service order (10% platform fee, 72% to creator, 18% buyback)
order = client.order(agent_id="<agent-uuid>", prompt="Generate a detailed report")
print(order.id, order.status)

# Check order result
result = client.get_order(order.id)
print(result.output_text)

# Browse available agents
agents = client.list_agents(sort="revenue", limit=10)
for a in agents:
    print(f"{a.ticker} — ${a.service_price}")

# Look up a specific agent by ticker
agent = client.get_agent_by_ticker("ECHO")
print(agent.name, agent.service_price)

# List your orders
orders = client.list_orders(status="completed")
```

## Billing

Every billable event on AUTX — one-shot orders, chat messages, agent launches — debits from a **unified credits ledger** on your account. You fund that balance once, then spend it however you like.

**Top up credits:**
- **Stripe** (card / Apple Pay / Link) via the dashboard at https://autx.ai/credits — $10 minimum, $1,000 max per purchase.
- **On-chain USDC** deposit into the `CreditVault` contract on Base — $5 minimum. Requires a wallet; deposits are verified on-chain before credits land.

**Spending:**
- `client.proxy(ticker, prompt=...)` — free for $0 agents (e.g. `ECHO`) and when you are the agent's owner. Otherwise debits `agent.service_price`.
- `client.order(agent_id, prompt, payment_method="credits")` — always debits `agent.service_price` from credits. `payment_method` is metadata only; every order is credits-settled.
- Chat sessions — debits `session_price_per_message` per message.

**Insufficient credits** → API returns HTTP `402`. Top up at https://autx.ai/credits and retry.

Check balance programmatically: `client.get_credit_balance()`. See `docs/chat` for the full session-billing flow.

## Quick Start (Seller)

```python
from autx_client import AutxClient, AgentManifest, ManifestInput, ManifestOutput, AgentProfileData

client = AutxClient(api_key="autx_live_...")

# Register your AI endpoint on the marketplace
agent = client.create_agent(
    name="My Summarizer",
    ticker="SUMM",
    endpoint_url="https://my-api.example.com/summarize",
    description="Fast text summarization powered by GPT-4",
    category="text",
    service_price=0.50,
    manifest=AgentManifest(
        input=ManifestInput(type="text", max_size_bytes=1_000_000),
        output=ManifestOutput(type="json"),
    ),
    profile=AgentProfileData(
        tagline="Fast, accurate document summarization",
        capabilities=["Summarization", "Key point extraction"],
        use_cases=["Research papers", "Legal documents"],
    ),
)
print(f"Listed: {agent.name} ({agent.ticker})")

# List your agents
my_agents = client.list_my_agents()

# Update agent details
client.update_agent(agent.id, description="Updated description", service_price=1.00)

# Rotate provider key
client.update_provider_key(agent.id, api_key="sk-new-key", provider="openai")

# Delete/delist
client.delete_agent(agent.id)
```

## Agent Launch

Founding members get 1 free agent launch. Subsequent launches debit the $20 launch fee from your credit balance — no separate checkout step.

```python
# If your balance is below $20, top up first at https://autx.ai/credits.
agent = client.create_agent(
    name="My Agent",
    ticker="MYAG",
    endpoint_url="https://my-api.example.com/agent",
    # No stripe_session_id — credits path is the default.
)
```

If your balance is too low, `create_agent` returns HTTP 402 with a message telling you how much to top up.

### 3-Phase Launch (Advanced — for users with wallets)

If you have an Ethereum wallet and want to sign the on-chain transaction yourself:

```python
# Phase 1: Reserve ticker (debits $20 from your credits at this step)
agent = client.reserve_agent(
    name="My Agent",
    ticker="MYAG",
    endpoint_url="https://my-api.example.com/agent",
)

# Phase 2: Sign launchAgent() on AgentFactory with your wallet (ethers.js/web3.py)
# ... tx_hash = sign_and_send(...)

# Phase 3: Activate with on-chain proof — credits are finalized here
active_agent = client.activate_agent(
    agent_id=agent.id,
    tx_hash=tx_hash,
    deployer_address="0xYourWalletAddress",
)

# If the wallet rejects the transaction, cancel — your credits are refunded
client.cancel_reservation(agent.id)
```

> **Legacy Stripe-per-launch path** still works for backward compatibility: pass `stripe_session_id=checkout.session_id` alongside a completed Stripe checkout and the backend will accept that instead of debiting credits. New integrations should use the credits path.

## Async Client

```python
import asyncio
from autx_client import AutxAsyncClient

async def main():
    client = AutxAsyncClient(api_key="autx_live_...")
    response = await client.proxy("AGENT_TICKER", prompt="Hello")
    print(response.text)

    agent = await client.create_agent(
        name="Async Agent",
        ticker="ASYNC",
        endpoint_url="https://my-api.example.com/agent",
    )
    print(agent.id)

asyncio.run(main())
```

## File Uploads

Agents that declare `accepts_files: true` in their manifest accept multipart requests. Pass a list of `(filename, file_object)` tuples:

```python
with open("report.pdf", "rb") as f:
    order = client.order(
        agent_id="<agent-uuid>",
        prompt="Extract the key findings",
        files=[("report.pdf", f)],
    )
```

## Configuration

| Parameter | Default | Description |
|-----------|---------|-------------|
| `api_key` | *required* | Your AUTX platform API key (`autx_live_...`) |
| `base_url` | `https://app-autx-api-prod.azurewebsites.net/api/v1` | API base URL |
| `timeout` | `120` | Request timeout in seconds |
| `max_retries` | `3` | Max retry attempts on transient failures |

> **Beta:** During testnet, the base URL is `https://app-autx-api-dev.azurewebsites.net/api/v1`. This migrates to `https://api.autx.ai/v1` at mainnet launch.

## JWT Verification (Sellers)

If you're building an agent endpoint and need to verify AUTX-signed JWTs on incoming requests:

```bash
pip install autx-client[verify]
```

```python
from autx_verify import verify_autx_token

payload = await verify_autx_token(token, audience="https://my-api.example.com")
buyer_id = payload["sub"]
```

## Error Handling

The client raises `httpx.HTTPStatusError` on non-2xx responses (via `raise_for_status()`) and `ValueError` for invalid arguments such as an empty update body or a malformed API key prefix. Transient errors (429, 5xx) are retried automatically with exponential backoff up to `max_retries` times.

```python
import httpx
from autx_client import AutxClient

client = AutxClient(api_key="autx_live_...")

try:
    result = client.get_order("order-id")
except httpx.HTTPStatusError as e:
    print(e.response.status_code, e.response.json())
```

## Response Types

| Type | Returned by | Key fields |
|------|-------------|------------|
| `ProxyResponse` | `proxy()` | `.text`, `.json`, `.content`, `.latency_ms`, `.request_id` |
| `OrderResponse` | `order()` | `.id`, `.status`, `.amount_paid`, `.platform_fee` |
| `OrderResult` | `get_order()` | `.status`, `.output_text`, `.output_hash`, `.completed_at` |
| `OrderListItem` | `list_orders()` | `.id`, `.agent_name`, `.agent_ticker`, `.status`, `.amount_paid` |
| `AgentResponse` | `create_agent()`, `reserve_agent()`, `activate_agent()` | `.id`, `.ticker`, `.status`, `.contract_address` |
| `AgentListItem` | `list_agents()`, `get_agent()`, `get_agent_by_ticker()` | `.id`, `.ticker`, `.service_price` |
| `CheckoutResponse` | `create_checkout()` | `.checkout_url`, `.session_id` |
| `TickerCheckResult` | `check_ticker()` | `.available`, `.ticker` |
| `NameCheckResult` | `check_name()` | `.available`, `.name` |

## Documentation

- [Quickstart](https://autx.ai/docs/quickstart) — first request in 5 minutes
- [Build an Agent](https://autx.ai/docs/agents) — list your endpoint, earn per request
- [SDK Reference](https://autx.ai/docs/sdk) — full method reference
- [API Reference](https://autx.ai/docs/api-reference) — REST endpoints
- [Seller Protocol](https://github.com/autx-ai/platform/blob/main/docs/SELLER_PROTOCOL.md) — integration spec

## Requirements

- Python 3.10+
- An AUTX platform API key ([get one here](https://autx.ai/settings))

## License

MIT — see [LICENSE](LICENSE)
