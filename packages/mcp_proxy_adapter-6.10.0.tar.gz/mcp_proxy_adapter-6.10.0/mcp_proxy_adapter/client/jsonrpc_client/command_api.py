"""Command helpers for JsonRpcClient.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Awaitable, Callable, Dict, Optional, TYPE_CHECKING

from mcp_proxy_adapter.client.jsonrpc_client.execution_status_observer import (
    ExecutionStatusObserver,
)
from mcp_proxy_adapter.api.execute_async_contract import (
    parse_acceptance_payload,
)
from mcp_proxy_adapter.client.jsonrpc_client.operation_state import (
    build_operation_state_from_acceptance,
)
from mcp_proxy_adapter.client.jsonrpc_client.transport import JsonRpcTransport
from mcp_proxy_adapter.client.jsonrpc_client.ws_job_status import (
    wait_for_job_via_websocket,
    wait_for_terminal_delivery_via_websocket,
)
from mcp_proxy_adapter.core.constants import WS_JOB_WAIT_TIMEOUT
from mcp_proxy_adapter.core.delivery.contracts import DeliveryMode
from mcp_proxy_adapter.core.delivery.exceptions import InvalidDeliveryContractError

if TYPE_CHECKING:
    from mcp_proxy_adapter.client.jsonrpc_client.schema_generator import MethodInfo

logger = logging.getLogger(__name__)


def _is_blank(value: str | None) -> bool:
    """Check if value is None, empty, or whitespace-only."""
    if value is None:
        return True
    return isinstance(value, str) and value.strip() == ""


class CommandApiMixin(JsonRpcTransport):
    """Mixin providing standard JSON-RPC command helpers."""

    async def echo(
        self, message: str = "Hello, World!", timestamp: Optional[str] = None
    ) -> Dict[str, Any]:
        params: Dict[str, Any] = {"message": message}
        if timestamp:
            params["timestamp"] = timestamp
        response = await self.jsonrpc_call("echo", params)
        return self._extract_result(response)

    async def help(self, command_name: Optional[str] = None) -> Dict[str, Any]:
        params: Dict[str, Any] = {}
        if command_name:
            params["command"] = command_name
        response = await self.jsonrpc_call("help", params)
        return self._extract_result(response)

    async def get_config(self) -> Dict[str, Any]:
        response = await self.jsonrpc_call("config", {})
        return self._extract_result(response)

    async def long_task(self, seconds: int) -> Dict[str, Any]:
        response = await self.jsonrpc_call("long_task", {"seconds": seconds})
        return self._extract_result(response)

    async def job_status(self, job_id: str) -> Dict[str, Any]:
        response = await self.jsonrpc_call("job_status", {"job_id": job_id})
        return self._extract_result(response)

    async def execute_command(
        self,
        command: str,
        params: Optional[Dict[str, Any]] = None,
        use_cmd_endpoint: bool = False,
    ) -> Dict[str, Any]:
        """
        Execute command using either /cmd endpoint or JSON-RPC.

        The /cmd endpoint supports the CommandRequest schema with oneOf discriminator
        and detailed parameter validation. Use use_cmd_endpoint=True to use this endpoint.

        Args:
            command: Command name to execute
            params: Optional command parameters
            use_cmd_endpoint: If True, use /cmd endpoint; otherwise use JSON-RPC

        Returns:
            Command execution result
        """
        if use_cmd_endpoint:
            return await self.cmd_call(command, params)
        else:
            response = await self.jsonrpc_call(command, params or {})
            return self._extract_result(response)

    async def execute_async(
        self,
        command: str,
        params: Optional[Dict[str, Any]] = None,
        *,
        on_result: Callable[[Dict[str, Any]], Any],
        timeout: float = 60.0,
    ) -> Dict[str, Any]:
        """
        Submit command for async execution; result is delivered via WebSocket callback.

        Sends execute_async RPC without client deliver_id. Server returns acceptance
        with server-issued ws_id and delivery contract. Client subscribes to /ws
        by ws_id after acceptance (subscribe-after-acceptance); when the server
        pushes delivery_completed/delivery_failed/delivery_cancelled, on_result(payload)
        is invoked once. Optional status observer runs by job_id when status_observable.

        Args:
            command: Command name to execute.
            params: Optional command parameters.
            on_result: Callback invoked with the terminal delivery dict (event, ws_id,
                result or error). May be sync or async.
            timeout: Max seconds to wait for terminal delivery.

        Returns:
            Server acceptance dict (job_id, ws_id, delivery). Invalid acceptance
            raises InvalidDeliveryContractError.
        """
        wait_task: Optional[asyncio.Task[Dict[str, Any]]] = None
        observer_task: Optional[asyncio.Task[None]] = None

        try:
            response = await self.jsonrpc_call(
                "execute_async",
                {"command": command, "params": params or {}},
            )
            result = self._extract_result(response)
            acceptance_model = parse_acceptance_payload(
                result, allow_legacy_deliver_id=True
            )
            payload = acceptance_model.model_dump(mode="json")
            state = build_operation_state_from_acceptance(payload)

            if not payload.get("accepted"):
                return result

            if state.delivery_mode in (DeliveryMode.WS, DeliveryMode.WS_WITH_STATUS):
                ws_id = state.ws_id
                if _is_blank(ws_id):
                    logger.error(
                        "execute_async: WS delivery mode requires ws_id, but received blank value. "
                        "Server response may be missing ws_id or deliver_id field."
                    )
                    raise InvalidDeliveryContractError(
                        "execute_async acceptance missing ws_id for WS delivery"
                    )
                # After validation, ws_id is guaranteed to be non-None and non-blank
                assert (
                    ws_id is not None and ws_id.strip() != ""
                ), "ws_id validation failed"
                logger.debug(
                    "execute_async: Subscribing to WebSocket delivery with ws_id=%s",
                    ws_id,
                )
                # CRITICAL: Always use wait_for_terminal_delivery_via_websocket (not wait_for_job_via_websocket)
                # for execute_async delivery path. This ensures correct ws_id-based subscription.
                wait_task = asyncio.create_task(
                    wait_for_terminal_delivery_via_websocket(
                        self, ws_id, timeout=timeout
                    )
                )

            if state.job_id and getattr(
                payload.get("delivery"), "status_observable", False
            ):
                observer = ExecutionStatusObserver(self, state.job_id, state)
                observer_task = asyncio.create_task(
                    observer.run_until_terminal(
                        poll_interval=1.0,
                        terminal_statuses=frozenset({"completed", "failed", "stopped"}),
                    )
                )

            if wait_task is not None:
                try:
                    delivery_payload = await wait_task
                    state.apply_delivery_event(delivery_payload)
                    if asyncio.iscoroutinefunction(on_result):
                        await on_result(delivery_payload)
                    else:
                        on_result(delivery_payload)
                except asyncio.TimeoutError:
                    state.mark_timeout()
                    raise
                except asyncio.CancelledError:
                    state.mark_cancelled()
                    raise

            return result
        finally:
            if observer_task is not None and not observer_task.done():
                observer_task.cancel()
                try:
                    await observer_task
                except asyncio.CancelledError:
                    pass
            if wait_task is not None and not wait_task.done():
                wait_task.cancel()
                try:
                    await wait_task
                except (asyncio.CancelledError, asyncio.TimeoutError):
                    pass

    async def execute_command_unified(
        self,
        command: str,
        params: Optional[Dict[str, Any]] = None,
        *,
        use_cmd_endpoint: bool = False,
        expect_queue: Optional[bool] = None,
        auto_poll: bool = True,
        poll_interval: float = 1.0,
        timeout: Optional[float] = None,
        status_hook: Optional[Callable[[Dict[str, Any]], Awaitable[None]]] = None,
    ) -> Dict[str, Any]:
        """
        Execute a command and transparently handle queued or immediate responses.

        1. Submits the command via ``execute_command``.
        2. If the server returns ``job_id``, waits for the result via WebSocket (/ws).
        3. Returns either the immediate result or the queued result (no polling).

        Args:
            command: Command name to execute.
            params: Payload for the command.
            use_cmd_endpoint: Use the ``/cmd`` endpoint instead of JSON-RPC.
            expect_queue: If ``True`` and no job_id is returned, raises. If ``False``,
                return immediately even if response contains job_id.
            auto_poll: When ``True`` (default), wait for queued job via WS until done.
                When ``False``, return as soon as job_id is detected.
            poll_interval: Unused (kept for signature compatibility).
            timeout: Max seconds to wait for job completion via WS. 0 = no timeout.
                Defaults to ``WS_JOB_WAIT_TIMEOUT``.
            status_hook: Optional async callback invoked with the initial command
                response (when *job_id* is present) and with each inbound WebSocket
                message while waiting for a terminal queue event (when
                *auto_poll* is True). Ignored when the path returns immediately
                without a WS wait.

        Returns:
            For immediate: ``{"mode": "immediate", "result": ...}``.
            For queued: ``{"mode": "queued", "job_id": ..., "status": ..., "result": ...}``.
        """

        command_result = await self.execute_command(
            command,
            params or {},
            use_cmd_endpoint=use_cmd_endpoint,
        )

        # Extract job_id from response (always present for queued commands, even with polling)
        job_id = self._extract_job_identifier(command_result)

        # Check if response already contains result/status from automatic polling (poll_interval > 0)
        # Server-side polling returns job_id + result/status/progress in one response
        has_polled_result = (
            isinstance(command_result, dict)
            and job_id is not None
            and (
                "result" in command_result
                or command_result.get("status") not in (None, "pending", "queued")
                or "progress" in command_result
            )
        )

        # If expect_queue is explicitly False, return immediate result even if job_id exists
        if expect_queue is False:
            return {
                "mode": "immediate",
                "command": command,
                "result": command_result,
                "queued": False,
            }

        # If expect_queue is True but no job_id, raise error
        if expect_queue is True and job_id is None:
            raise RuntimeError(
                f"Command '{command}' expected to run via queue, but no job_id was returned."
            )

        # If no job_id and expect_queue is None (auto-detect), return immediate result
        if job_id is None:
            return {
                "mode": "immediate",
                "command": command,
                "result": command_result,
                "queued": False,
            }

        # If response contains result from server-side polling, return it with job_id
        if has_polled_result:
            return {
                "mode": "queued",
                "command": command,
                "job_id": job_id,  # Always include job_id
                "queued": True,
                "status": command_result.get("status", "unknown"),
                "result": command_result.get("result") or command_result,
                "progress": command_result.get("progress"),
                "description": command_result.get("description"),
                "message": command_result.get("message"),
            }

        if not auto_poll:
            return {
                "mode": "queued",
                "command": command,
                "job_id": job_id,
                "queued": True,
                "status": (
                    command_result.get("status", "queued")
                    if isinstance(command_result, dict)
                    else "queued"
                ),
                "result": command_result,
            }

        if status_hook is not None and isinstance(command_result, dict):
            await status_hook(command_result)

        async def _ws_inbound_hook(msg: Dict[str, Any]) -> None:
            recorder = getattr(self, "_record_queue_job_ws_message", None)
            if recorder is not None and job_id is not None:
                await recorder(job_id, msg)
            if status_hook is not None:
                await status_hook(msg)

        # Wait for job completion via WebSocket (no polling)
        event = await wait_for_job_via_websocket(
            self,
            job_id,
            timeout=timeout if timeout is not None else WS_JOB_WAIT_TIMEOUT,
            on_inbound_message=_ws_inbound_hook,
        )
        ev = event.get("event") or event.get("type") or ""

        if ev == "job_failed":
            raise RuntimeError(
                f"Queued command '{command}' failed (job_id={job_id}): {event}"
            )

        result = event.get("result")
        if isinstance(result, dict) and "data" in result:
            result = result.get("data")

        return {
            "mode": "queued",
            "command": command,
            "job_id": job_id,
            "status": ev or "job_completed",
            "result": result,
            "queued": True,
            "raw_status": event,
        }

    async def execute(
        self,
        method_name: str,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Execute method with schema-based validation and default values.

        This method uses the SchemaRequestGenerator to:
        - Validate required parameters
        - Set default values for missing optional parameters
        - Validate parameter types
        - Execute the command and return deserialized Python object

        Args:
            method_name: Name of the method to execute
            params: Method parameters (optional)

        Returns:
            Deserialized command execution result (Python dict)

        Raises:
            MethodNotFoundError: If method is not found in schema
            RequiredParameterMissingError: If required parameter is missing
            InvalidParameterTypeError: If parameter type is invalid
            InvalidParameterValueError: If parameter value is invalid
            RuntimeError: If command execution fails
        """
        from mcp_proxy_adapter.client.jsonrpc_client.exceptions import (
            MethodNotFoundError,
            RequiredParameterMissingError,
            InvalidParameterTypeError,
            InvalidParameterValueError,
        )

        # Get schema generator
        generator = await self.get_schema_generator_async()

        # Validate and prepare parameters
        try:
            prepared_params = generator.validate_and_prepare_params(method_name, params)
        except (
            MethodNotFoundError,
            RequiredParameterMissingError,
            InvalidParameterTypeError,
            InvalidParameterValueError,
        ):
            raise  # Re-raise schema validation errors

        # Execute command
        result = await self.cmd_call(method_name, prepared_params)

        # Result is already a Python dict (deserialized JSON)
        return result

    async def get_methods(self) -> Dict[str, "MethodInfo"]:
        """
        Get all available methods with their descriptions.

        Returns:
            Dictionary mapping method names to MethodInfo objects
        """
        generator = await self.get_schema_generator_async()
        return generator.get_methods()  # type: ignore[no-any-return]

    async def get_method_description(self, method_name: str) -> str:
        """
        Get detailed description of a method.

        Args:
            method_name: Name of the method

        Returns:
            Detailed description string including:
            - Method name and description
            - Return type and description
            - Parameter details (type, description, default, required)
        """
        generator = await self.get_schema_generator_async()
        return generator.get_method_description(method_name)  # type: ignore[no-any-return]

    async def schema_example(self) -> str:
        """
        Get schema example with detailed descriptions.

        Returns:
            JSON string containing:
            - Full OpenAPI schema
            - Standard description (OpenAPI 3.0.2)
            - Detailed field descriptions
            - All methods with parameter details
        """
        generator = await self.get_schema_generator_async()
        return generator.schema_example()  # type: ignore[no-any-return]

    async def get_commands_list(self) -> Dict[str, Any]:
        """
        Get list of all available commands.

        This method calls the GET /commands endpoint to retrieve
        the list of all registered commands on the server.

        Returns:
            Dictionary containing list of commands and their metadata
        """
        client = await self._get_client()
        response = await client.get(f"{self.base_url}/commands", headers=self.headers)
        response.raise_for_status()
        from typing import cast

        return cast(Dict[str, Any], response.json())

    async def get_heartbeat(self) -> Dict[str, Any]:
        """
        Get server heartbeat information.

        This method calls the GET /heartbeat endpoint to retrieve
        server heartbeat status and metadata.

        Returns:
            Dictionary containing heartbeat status, server name, URL, and timestamp
        """
        client = await self._get_client()
        response = await client.get(f"{self.base_url}/heartbeat", headers=self.headers)
        response.raise_for_status()
        from typing import cast

        return cast(Dict[str, Any], response.json())

    async def list_commands(self) -> Dict[str, Any]:
        """
        List all available commands via JSON-RPC.

        This is an alias for calling the 'list' command via JSON-RPC.
        Equivalent to: execute_command("list", {})

        Returns:
            Dictionary containing list of commands
        """
        return await self.execute_command("list", {})

    async def load_command(self, module_path: str, **kwargs: Any) -> Dict[str, Any]:
        """
        Load a command module.

        Args:
            module_path: Path to the command module to load
            **kwargs: Additional parameters for the load command

        Returns:
            Result of the load operation
        """
        params = {"module_path": module_path, **kwargs}
        return await self.execute_command("load", params)

    async def unload_command(self, command_name: str, **kwargs: Any) -> Dict[str, Any]:
        """
        Unload a command.

        Args:
            command_name: Name of the command to unload
            **kwargs: Additional parameters for the unload command

        Returns:
            Result of the unload operation
        """
        params = {"command": command_name, **kwargs}
        return await self.execute_command("unload", params)

    async def reload_command(self, command_name: str, **kwargs: Any) -> Dict[str, Any]:
        """
        Reload a command.

        Args:
            command_name: Name of the command to reload
            **kwargs: Additional parameters for the reload command

        Returns:
            Result of the reload operation
        """
        params = {"command": command_name, **kwargs}
        return await self.execute_command("reload", params)

    async def get_tool(self, tool_name: str) -> Dict[str, Any]:
        """
        Get tool description.

        Args:
            tool_name: Name of the tool

        Returns:
            Tool description and metadata
        """
        client = await self._get_client()
        response = await client.get(
            f"{self.base_url}/tools/{tool_name}",
            headers=self.headers,
        )
        response.raise_for_status()
        from typing import cast

        return cast(Dict[str, Any], response.json())

    async def execute_tool(
        self,
        tool_name: str,
        payload: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Execute a tool.

        Args:
            tool_name: Name of the tool to execute
            payload: Tool execution parameters

        Returns:
            Tool execution result
        """
        client = await self._get_client()
        response = await client.post(
            f"{self.base_url}/tools/{tool_name}",
            json=payload or {},
            headers=self.headers,
        )
        response.raise_for_status()
        from typing import cast

        return cast(Dict[str, Any], response.json())

    # Queue-related command helpers

    @staticmethod
    def _extract_job_identifier(command_response: Any) -> Optional[str]:
        """
        Extract job identifier from a command response, if present.
        """
        if not isinstance(command_response, dict):
            return None

        data_section = command_response.get("data", {})
        if not isinstance(data_section, dict):
            data_section = {}

        candidates = [
            command_response.get("job_id"),
            command_response.get("jobId"),
            data_section.get("job_id"),
            data_section.get("jobId"),
        ]

        for candidate in candidates:
            if isinstance(candidate, str) and candidate.strip():
                return candidate
        return None

    async def get_command_status(self, job_id: str) -> Dict[str, Any]:
        """
        Get status of a command execution in queue.

        This is a convenience method that calls queue_get_job_status.
        Use this when you have a job_id from a queued command execution.

        Args:
            job_id: Job ID returned from execute_command when command uses queue

        Returns:
            Dictionary containing job status, progress, description, and result
        """
        return await self.queue_get_job_status(job_id)  # type: ignore[attr-defined,no-any-return]

    async def cancel_command(self, job_id: str) -> Dict[str, Any]:
        """
        Cancel a command execution in queue.

        This method stops and deletes the job from the queue.
        Equivalent to: queue_stop_job() + queue_delete_job()

        Args:
            job_id: Job ID returned from execute_command when command uses queue

        Returns:
            Result of the cancellation operation
        """
        # Try to stop first, then delete
        try:
            await self.queue_stop_job(job_id)  # type: ignore[attr-defined]
        except Exception:
            pass  # Job might already be stopped or completed
        return await self.queue_delete_job(job_id)  # type: ignore[attr-defined,no-any-return]

    async def list_queued_commands(
        self,
        status: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        List all commands currently in the queue.

        This method filters jobs to show only command executions (job_type="command_execution").

        Args:
            status: Filter by status (pending, running, completed, failed, stopped)
            limit: Maximum number of jobs to return (default: 100)

        Returns:
            Dictionary containing list of queued commands with their status
        """
        # Use queue_list_jobs with job_type filter for command executions
        result = await self.queue_list_jobs(  # type: ignore[attr-defined]
            status=status, job_type="command_execution"
        )

        # Apply limit if specified
        if limit and "data" in result:
            jobs = result.get("data", {}).get("jobs", [])
            if len(jobs) > limit:
                result["data"]["jobs"] = jobs[:limit]
                result["data"]["total_count"] = limit

        return result  # type: ignore[no-any-return]

    async def list_all_queue_jobs(
        self,
        status: Optional[str] = None,
        job_type: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        List all jobs in the queue (commands and other job types).

        Args:
            status: Filter by status (pending, running, completed, failed, stopped)
            job_type: Filter by job type (command_execution, data_processing, api_call)
            limit: Maximum number of jobs to return (default: 100)

        Returns:
            Dictionary containing list of all jobs with their status
        """
        result = await self.queue_list_jobs(  # type: ignore[attr-defined]
            status=status, job_type=job_type
        )

        # Apply limit if specified
        if limit and "data" in result:
            jobs = result.get("data", {}).get("jobs", [])
            if len(jobs) > limit:
                result["data"]["jobs"] = jobs[:limit]
                result["data"]["total_count"] = limit

        return result  # type: ignore[no-any-return]
