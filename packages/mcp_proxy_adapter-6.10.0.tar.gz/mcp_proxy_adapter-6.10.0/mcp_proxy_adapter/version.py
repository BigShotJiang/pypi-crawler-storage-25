"""
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

Version information for MCP Proxy Adapter.
"""

__version__ = "6.10.0"
