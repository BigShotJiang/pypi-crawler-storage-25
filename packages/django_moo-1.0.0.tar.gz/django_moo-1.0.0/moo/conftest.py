# -*- coding: utf-8 -*-
"""
Support resources for PyTest framework.
"""

import importlib.resources
import logging

import pytest
from django.conf import settings
from django.contrib.auth.models import User  # pylint: disable=imported-auth-user

from moo.bootstrap import load_python
from moo.core.models import Object, Player, Repository

log = logging.getLogger(__name__)


@pytest.fixture(autouse=True, scope="session")
def configure_celery_for_tests():
    from moo.celery import app

    app.conf.update(
        broker_url="memory://",
        task_always_eager=True,
        task_store_eager_result=True,
    )


@pytest.fixture()
def t_init(request):
    """
    Test fixture that pre-seeds a basic bootstrapped environment.
    """
    name = request.param if hasattr(request, "param") else "test"
    log.debug(f"t_init: {name}")
    Repository.objects.create(slug=name, prefix=f"moo/bootstrap/{name}_verbs", url=settings.DEFAULT_GIT_REPO_URL)
    ref = importlib.resources.files("moo.bootstrap") / f"{name}.py"
    with importlib.resources.as_file(ref) as path:
        load_python(path)
    yield Object.objects.get(id=1)


@pytest.fixture()
def t_wizard():
    """
    Test fixture that returns the Wizard account.
    """
    yield Object.objects.get(name="Wizard")
