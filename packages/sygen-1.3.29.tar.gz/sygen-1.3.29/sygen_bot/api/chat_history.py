"""Helpers for persisting ``chat_message`` events into admin chat history.

Used by :class:`~sygen_bot.api.server.ApiServer` to append task / interagent
events into the admin panel's chat session file so they survive a reload.
Messages with no matching chat session are broadcast-only: we write the
event to disk when possible, but the WS fan-out is the source of truth.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
import uuid
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


_SESSION_ID_RE = __import__("re").compile(r"^[a-zA-Z0-9_-]+$")


def _home() -> Path:
    return Path(os.environ.get("SYGEN_HOME", Path.home() / ".sygen"))


def _chat_sessions_path() -> Path:
    return _home() / "chat_sessions.json"


def _chat_history_dir() -> Path:
    return _home() / "chat_history"


def _read_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text("utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return None


def _write_json(path: Path, data: Any) -> None:
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False, default=str), "utf-8")
    tmp.replace(path)


_file_locks: dict[str, asyncio.Lock] = {}


def _lock_for(path: Path) -> asyncio.Lock:
    key = str(path)
    lock = _file_locks.get(key)
    if lock is None:
        lock = _file_locks.setdefault(key, asyncio.Lock())
    return lock


def _latest_session_id_for_agent(agent: str) -> str | None:
    """Return the most recently updated chat session for *agent*, if any."""
    data = _read_json(_chat_sessions_path())
    sessions = (data or {}).get("sessions", []) if isinstance(data, dict) else []
    candidates = [s for s in sessions if isinstance(s, dict) and s.get("agent") == agent]
    if not candidates:
        return None
    candidates.sort(key=lambda s: s.get("updated_at", 0), reverse=True)
    sid = candidates[0].get("id")
    return sid if isinstance(sid, str) and _SESSION_ID_RE.match(sid) else None


def _payload_to_message(payload: dict[str, Any]) -> dict[str, Any]:
    """Shape a ``chat_message`` WS payload into a persisted history record.

    Keeps the same field names that ``ChatSessionMessage`` in the admin
    client expects (sender/agentName/content/timestamp) and adds
    kind/meta so non-text events can re-render as cards after reload.
    """
    ts_raw = payload.get("timestamp", time.time())
    try:
        ts_float = float(ts_raw)
    except (TypeError, ValueError):
        ts_float = time.time()
    iso = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(ts_float))

    agent = payload.get("agent") or "main"
    record: dict[str, Any] = {
        "id": f"msg-{uuid.uuid4()}",
        "sender": "agent" if payload.get("role", "agent") != "system" else "system",
        "agentName": str(agent),
        "content": str(payload.get("content", "")),
        "timestamp": iso,
        "kind": str(payload.get("kind", "text")),
    }
    meta = payload.get("meta")
    if isinstance(meta, dict) and meta:
        record["meta"] = meta
    files = payload.get("files")
    if isinstance(files, list) and files:
        record["files"] = files
    return record


async def persist_chat_message(payload: dict[str, Any]) -> str | None:
    """Append a ``chat_message`` payload to the agent's latest chat history.

    Returns the resolved session id on success, ``None`` if no matching
    chat session exists (broadcast-only) or persistence failed. Best-effort:
    never raises — admin WS fan-out continues regardless.
    """
    agent = str(payload.get("agent") or "")
    if not agent:
        return None

    session_id = str(payload.get("session_id") or "")
    # Only trust client-supplied session ids that already map to an
    # admin-managed REST session. Named-session ids (ia-main, etc.) fall
    # back to the latest REST session for the agent.
    sessions = _read_json(_chat_sessions_path()) or {}
    known_ids = {
        s.get("id")
        for s in (sessions.get("sessions", []) if isinstance(sessions, dict) else [])
        if isinstance(s, dict)
    }
    if session_id not in known_ids or not _SESSION_ID_RE.match(session_id or ""):
        fallback = _latest_session_id_for_agent(agent)
        if fallback is None:
            return None
        session_id = fallback

    history_dir = _chat_history_dir()
    history_dir.mkdir(parents=True, exist_ok=True)
    history_file = history_dir / f"{session_id}.json"

    record = _payload_to_message(payload)
    lock = _lock_for(history_file)
    try:
        async with lock:
            existing = _read_json(history_file)
            if isinstance(existing, dict):
                messages = list(existing.get("messages") or [])
            elif isinstance(existing, list):
                messages = list(existing)
            else:
                messages = []
            messages.append(record)
            _write_json(history_file, {"messages": messages})

        # Bump the session's updated_at so it sorts to the top of the list.
        sessions_path = _chat_sessions_path()
        sessions_lock = _lock_for(sessions_path)
        async with sessions_lock:
            data = _read_json(sessions_path) or {"sessions": []}
            for s in data.get("sessions", []):
                if isinstance(s, dict) and s.get("id") == session_id:
                    s["updated_at"] = time.time()
                    break
            _write_json(sessions_path, data)
    except Exception:
        logger.debug("persist_chat_message failed for session=%s", session_id, exc_info=True)
        return None

    return session_id
