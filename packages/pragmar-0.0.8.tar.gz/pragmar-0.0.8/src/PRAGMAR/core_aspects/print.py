from .meta import ap, grammar_def
from ..tree import TreeNode
from ..util import indent, connect_pipes, replace_first_char_every_line


def load():
    print_ast = ap.create_aspect("print_ast")

    @print_ast.define_on("Node").Value()
    def depth(node: TreeNode) -> int:
        return len(node.get_path_to_root())


    @print_ast.define_on("Node").Value()
    def print_tree(node: TreeNode, show_grammar_structure=True, show_attributes=True) -> str:
        tree_str = f"#{node.type}#\n"

        if show_attributes:
            basic_attributes_str = "<BasicAttributes>\n"
            basic_attributes_fields = []
            keys = node.data.keys()
            for i, key in enumerate(keys):
                if i == len(keys) - 1:
                    line = f"|---{key}: {node.data[key]}"
                else:
                    line = f"|---{key}: {node.data[key]}"
                    line = replace_first_char_every_line(line, "|")
                basic_attributes_fields.append(line)
            basic_attributes_str += "\n".join(basic_attributes_fields)
            if not basic_attributes_fields:
                basic_attributes_str = ""

        if show_grammar_structure:
            grammar_fields_str = "<GrammarFields>\n"
            grammar_fields = []
            children = node.get_children()
            for i, node in enumerate(children):
                if i == len(children) - 1:
                    line = f"|---{node.attribute('print_tree')()}"
                else:
                    line = f"|---{node.attribute('print_tree')()}"
                    line = replace_first_char_every_line(line, "|")
                grammar_fields.append(line)
            grammar_fields_str += "\n".join(grammar_fields)
            if not grammar_fields:
                grammar_fields_str = ""

        if basic_attributes_str and grammar_fields_str:
            tree_str += indent(1,"\n".join([basic_attributes_str, grammar_fields_str]))
        elif basic_attributes_str:
            tree_str += indent(1, basic_attributes_str)
        elif grammar_fields_str:
            tree_str += indent(1, grammar_fields_str)

        return tree_str


