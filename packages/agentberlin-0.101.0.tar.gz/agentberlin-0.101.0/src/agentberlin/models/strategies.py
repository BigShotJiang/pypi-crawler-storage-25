"""Pydantic models for the Strategies API."""

from typing import List

from pydantic import BaseModel, Field


class Applicable(BaseModel):
    """Brand-fit constraints for a strategy. Empty lists mean 'applies to all'."""

    business_models: List[str] = Field(default_factory=list)
    industries: List[str] = Field(default_factory=list)


class Strategy(BaseModel):
    """A single SEO strategy from the curated catalog."""

    id: str
    name: str
    category: str
    intent: str  # monitor | act | both
    summary: str
    required_capabilities: List[str] = Field(default_factory=list)
    applicable: Applicable = Field(default_factory=Applicable)
    cadence: str
    details: str
    created_by: str
    version: str
    last_reviewed: str  # YYYY-MM-DD


class StrategyListResponse(BaseModel):
    """Wire shape for POST /strategies/list."""

    strategies: List[Strategy]
