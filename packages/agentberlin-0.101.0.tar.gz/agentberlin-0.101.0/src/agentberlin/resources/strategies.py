"""Strategies resource for Agent Berlin SDK.

Read-only access to the curated SEO strategy catalog. Strategies live in the
backend's `strategies` table; the SDK exposes them so agents and humans can
list available strategies and fetch a single strategy's full body.
"""

from typing import List

from .._http import HTTPClient
from ..models.strategies import Strategy, StrategyListResponse


class StrategiesResource:
    """Resource for fetching SEO strategies.

    Example:
        all_strategies = client.strategies.list()
        for s in all_strategies:
            print(f"{s.id}: {s.name}")

        s = client.strategies.get("keyword-rank-tracking")
        print(s.cadence)
        print(s.details)
    """

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def list(self) -> List[Strategy]:
        """Return every strategy in the catalog, ordered by ID."""
        data = self._http.post("/strategies/list", json={})
        return StrategyListResponse.model_validate(data).strategies

    def get(self, id: str) -> Strategy:
        """Fetch a single strategy by ID.

        Raises:
            AgentBerlinNotFoundError: If the ID does not match any strategy.
        """
        data = self._http.post("/strategies/get", json={"id": id})
        return Strategy.model_validate(data)
