"""Tests for the `agentberlin workflow` CLI subcommand group.

Covers manifest-shape validation, kind enforcement, id-writeback, and URL
routing across `apply`, `publish`, `submit`, and `run`. HTTP calls are
stubbed via the `responses` library so tests don't hit a real backend.
"""

import json
from pathlib import Path
from typing import Any

import responses
from click.testing import CliRunner

from agentberlin.cli import main
from agentberlin.config import DEFAULT_BASE_URL


def _write_manifest(tmp_path: Path, data: dict[str, Any], name: str = "manifest.json") -> Path:
    path = tmp_path / name
    path.write_text(json.dumps(data))
    return path


def _read_manifest(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text())


# ---------------------------------------------------------------------------
# workflow apply
# ---------------------------------------------------------------------------


class TestWorkflowApply:
    @responses.activate
    def test_apply_without_id_creates_and_writes_back(self, tmp_path: Path) -> None:
        manifest = _write_manifest(
            tmp_path,
            {
                "kind": "workflow",
                "name": "Weekly Rank Tracking",
                "details": "Query GSC weekly and flag drops.",
                "schedule": {"type": "cron", "cron_expression": "0 9 * * 1", "timezone": "UTC"},
            },
        )
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/workflows",
            json={"success": True, "workflow_id": "wfl_123", "name": "Weekly Rank Tracking", "phase": "pre_planning"},
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "apply", "-m", str(manifest), "--token", "t"])

        assert result.exit_code == 0, result.output
        assert "wfl_123" in result.output
        assert _read_manifest(manifest)["id"] == "wfl_123"

        body = json.loads(responses.calls[0].request.body)
        assert body["details"] == "Query GSC weekly and flag drops."
        assert body["schedule"]["type"] == "cron"

    @responses.activate
    def test_apply_with_id_patches(self, tmp_path: Path) -> None:
        manifest = _write_manifest(
            tmp_path,
            {
                "kind": "workflow",
                "id": "wfl_abc",
                "name": "Edited Name",
                "description": "new desc",
                "details": "revised spec",
            },
        )
        responses.add(
            responses.PATCH,
            f"{DEFAULT_BASE_URL}/workflows/wfl_abc",
            json={"success": True, "workflow_id": "wfl_abc", "name": "Edited Name", "phase": "pre_planning"},
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "apply", "-m", str(manifest), "--token", "t"])

        assert result.exit_code == 0, result.output
        assert "wfl_abc" in result.output
        body = json.loads(responses.calls[0].request.body)
        assert body["name"] == "Edited Name"
        assert body["description"] == "new desc"
        assert body["details"] == "revised spec"

    def test_apply_rejects_manifest_without_kind(self, tmp_path: Path) -> None:
        manifest = _write_manifest(tmp_path, {"name": "X", "details": "..."})
        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "apply", "-m", str(manifest), "--token", "t"])
        assert result.exit_code != 0
        assert "kind" in result.output.lower()

    def test_apply_rejects_manifest_with_wrong_kind(self, tmp_path: Path) -> None:
        manifest = _write_manifest(tmp_path, {"kind": "report", "slug": "audit", "details": "..."})
        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "apply", "-m", str(manifest), "--token", "t"])
        assert result.exit_code != 0
        # Either rejects on kind or on slug; both are workflow-side validation.
        out_lower = result.output.lower()
        assert "kind" in out_lower or "slug" in out_lower

    def test_apply_rejects_manifest_with_slug(self, tmp_path: Path) -> None:
        manifest = _write_manifest(
            tmp_path, {"kind": "workflow", "name": "X", "slug": "oops"}
        )
        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "apply", "-m", str(manifest), "--token", "t"])
        assert result.exit_code != 0
        assert "slug" in result.output.lower()

    def test_apply_rejects_manifest_without_name(self, tmp_path: Path) -> None:
        manifest = _write_manifest(tmp_path, {"kind": "workflow", "details": "..."})
        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "apply", "-m", str(manifest), "--token", "t"])
        assert result.exit_code != 0
        assert "name" in result.output.lower()


# ---------------------------------------------------------------------------
# workflow publish
# ---------------------------------------------------------------------------


def _write_estimate(tmp_path: Path, name: str = "api_estimate.json") -> Path:
    """Drop a minimal-but-valid cost-estimate JSON into tmp_path."""
    p = tmp_path / name
    p.write_text('{"estimates": []}')
    return p


def _publish_manifest(tmp_path: Path, workflow_id: str = "wfl_xyz") -> Path:
    return _write_manifest(
        tmp_path,
        {"kind": "workflow", "id": workflow_id, "name": "X"},
        name="manifest.json",
    )


class TestWorkflowPublish:
    @responses.activate
    def test_publish_dir_routes_estimate_into_body_and_filters_droppings(
        self, tmp_path: Path
    ) -> None:
        # --dir bundles main.py + spec.json into the files map,
        # routes api_estimate.json into the cost_estimate body field, and
        # filters dotfiles / __pycache__ / *.pyc droppings, plus the manifest itself.
        (tmp_path / "main.py").write_text("print('hi')\n")
        (tmp_path / "spec.json").write_text('{"type":"object"}')
        estimate = {
            "estimates": [
                {
                    "resource": "gsc",
                    "method": "query",
                    "calls_per_run": {"min": 1, "max": 30, "typical": 5},
                    "basis": "one query per page",
                }
            ]
        }
        (tmp_path / "api_estimate.json").write_text(json.dumps(estimate))
        (tmp_path / ".DS_Store").write_text("ignored")
        (tmp_path / "main.pyc").write_bytes(b"\x00\x00")
        (tmp_path / "__pycache__").mkdir()
        manifest = _publish_manifest(tmp_path)

        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/workflows/wfl_xyz/versions/current/files",
            json={"success": True, "version": 3},
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "workflow",
                "publish",
                "-m",
                str(manifest),
                "--dir",
                str(tmp_path),
                "--cost-estimate-file",
                str(tmp_path / "api_estimate.json"),
                "--token",
                "t",
            ],
        )

        assert result.exit_code == 0, result.output
        assert "version 3" in result.output

        body = json.loads(responses.calls[0].request.body)
        assert set(body["files"].keys()) == {"main.py", "spec.json"}
        assert body["files"]["main.py"] == "print('hi')\n"
        assert body["cost_estimate"] == estimate

    def test_publish_rejects_passing_both_file_and_dir(self, tmp_path: Path) -> None:
        # The two flags are mutually exclusive; passing both is a user error
        # that should fail before any HTTP call is made.
        (tmp_path / "main.py").write_text("print('hi')\n")
        estimate = _write_estimate(tmp_path)
        manifest = _publish_manifest(tmp_path)
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "workflow",
                "publish",
                "-m",
                str(manifest),
                "--file",
                str(tmp_path / "main.py"),
                "--dir",
                str(tmp_path),
                "--cost-estimate-file",
                str(estimate),
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "exactly one" in result.output.lower()

    def test_publish_requires_one_of_file_or_dir(self, tmp_path: Path) -> None:
        estimate = _write_estimate(tmp_path)
        manifest = _publish_manifest(tmp_path)
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "workflow",
                "publish",
                "-m",
                str(manifest),
                "--cost-estimate-file",
                str(estimate),
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "exactly one" in result.output.lower()

    def test_publish_requires_cost_estimate_file(self, tmp_path: Path) -> None:
        # The flag is mandatory: omitting it fails before any HTTP call.
        (tmp_path / "main.py").write_text("print('hi')\n")
        manifest = _publish_manifest(tmp_path)
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "workflow",
                "publish",
                "-m",
                str(manifest),
                "--dir",
                str(tmp_path),
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "cost-estimate-file" in result.output.lower()

    def test_publish_dir_errors_when_empty(self, tmp_path: Path) -> None:
        # An empty publish would silently no-op and leave the version row
        # empty; surface it as an error instead.
        outside = tmp_path.parent / "estimate.json"
        outside.write_text('{"estimates": []}')
        # Manifest lives outside the dir so it doesn't accidentally satisfy
        # _collect_dir_files.
        manifest = _write_manifest(
            tmp_path.parent,
            {"kind": "workflow", "id": "wfl_xyz", "name": "X"},
            name="manifest_empty.json",
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "workflow",
                "publish",
                "-m",
                str(manifest),
                "--dir",
                str(tmp_path),
                "--cost-estimate-file",
                str(outside),
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "no publishable files" in result.output.lower()

    @responses.activate
    def test_publish_cost_estimate_file_outside_dir_excluded_from_files(
        self, tmp_path: Path
    ) -> None:
        # The cost-estimate file may live outside --dir entirely; the body
        # should still carry it, the dir's files are unaffected.
        src_dir = tmp_path / "src"
        src_dir.mkdir()
        (src_dir / "main.py").write_text("print('hi')\n")
        estimate_path = tmp_path / "api_estimate.json"
        estimate_path.write_text('{"estimates": []}')
        manifest = _publish_manifest(tmp_path)

        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/workflows/wfl_xyz/versions/current/files",
            json={"success": True, "version": 1},
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "workflow",
                "publish",
                "-m",
                str(manifest),
                "--dir",
                str(src_dir),
                "--cost-estimate-file",
                str(estimate_path),
                "--token",
                "t",
            ],
        )

        assert result.exit_code == 0, result.output
        body = json.loads(responses.calls[0].request.body)
        assert set(body["files"].keys()) == {"main.py"}
        assert body["cost_estimate"] == {"estimates": []}

    def test_publish_rejects_invalid_cost_estimate_json(self, tmp_path: Path) -> None:
        (tmp_path / "main.py").write_text("print('hi')\n")
        bad = tmp_path / "api_estimate.json"
        bad.write_text("not json at all")
        manifest = _publish_manifest(tmp_path)

        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "workflow",
                "publish",
                "-m",
                str(manifest),
                "--dir",
                str(tmp_path),
                "--cost-estimate-file",
                str(bad),
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "not valid json" in result.output.lower()

    def test_publish_rejects_cost_estimate_without_estimates_array(
        self, tmp_path: Path
    ) -> None:
        (tmp_path / "main.py").write_text("print('hi')\n")
        bad = tmp_path / "api_estimate.json"
        bad.write_text('{"foo": "bar"}')
        manifest = _publish_manifest(tmp_path)

        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "workflow",
                "publish",
                "-m",
                str(manifest),
                "--dir",
                str(tmp_path),
                "--cost-estimate-file",
                str(bad),
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "estimates" in result.output.lower()

    def test_publish_dir_with_only_cost_estimate_file_errors(self, tmp_path: Path) -> None:
        # If the dir only contains the cost-estimate file (and the manifest),
        # both get filtered out — surface the empty-dir error.
        estimate_path = tmp_path / "api_estimate.json"
        estimate_path.write_text('{"estimates": []}')
        manifest = _publish_manifest(tmp_path)

        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "workflow",
                "publish",
                "-m",
                str(manifest),
                "--dir",
                str(tmp_path),
                "--cost-estimate-file",
                str(estimate_path),
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "no publishable files" in result.output.lower()

    def test_publish_rejects_manifest_without_id(self, tmp_path: Path) -> None:
        # Publish needs a known workflow_id; manifest without id is a user error.
        (tmp_path / "main.py").write_text("print('hi')\n")
        estimate = _write_estimate(tmp_path)
        manifest = _write_manifest(
            tmp_path, {"kind": "workflow", "name": "X"}, name="no_id.json"
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "workflow",
                "publish",
                "-m",
                str(manifest),
                "--dir",
                str(tmp_path),
                "--cost-estimate-file",
                str(estimate),
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "id" in result.output.lower()


# ---------------------------------------------------------------------------
# workflow submit
# ---------------------------------------------------------------------------


class TestWorkflowSubmit:
    @responses.activate
    def test_submit_uploads_output(self, tmp_path: Path) -> None:
        output = tmp_path / "output.json"
        output.write_text('{"score": 42}')
        manifest = _write_manifest(
            tmp_path, {"kind": "workflow", "id": "wfl_xyz", "name": "X"}
        )
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/workflow-runs/artifacts",
            json={"success": True},
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "workflow",
                "submit",
                "-m",
                str(manifest),
                "--file",
                str(output),
                "--token",
                "t",
            ],
        )
        assert result.exit_code == 0, result.output
        # Multipart bodies end up as bytes; verify the output filename appears.
        body = responses.calls[0].request.body
        assert b'name="output"' in body
        assert b'output.json' in body
