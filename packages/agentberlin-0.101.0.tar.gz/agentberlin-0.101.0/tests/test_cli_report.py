"""Tests for the `agentberlin report` CLI subcommand group.

Covers manifest-shape validation, kind enforcement, id-writeback, and URL
routing across `apply`, `publish`, and `submit`. HTTP calls are stubbed via
the `responses` library so tests don't hit a real backend.
"""

import json
from pathlib import Path
from typing import Any

import responses
from click.testing import CliRunner

from agentberlin.cli import main
from agentberlin.config import DEFAULT_BASE_URL


def _write_manifest(tmp_path: Path, data: dict[str, Any], name: str = "manifest.json") -> Path:
    path = tmp_path / name
    path.write_text(json.dumps(data))
    return path


def _read_manifest(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text())


def _write(path: Path, text: str) -> Path:
    path.write_text(text)
    return path


def _html(tmp_path: Path, name: str = "index.html") -> Path:
    return _write(tmp_path / name, "<html><body>viewer</body></html>")


def _spec(tmp_path: Path, name: str = "spec.json") -> Path:
    return _write(tmp_path / name, json.dumps({"version": 1, "fields": []}))


def _data(tmp_path: Path, name: str = "data.json") -> Path:
    return _write(tmp_path / name, json.dumps({"score": 42}))


# ---------------------------------------------------------------------------
# report apply
# ---------------------------------------------------------------------------


class TestReportApply:
    @responses.activate
    def test_apply_without_id_creates_and_writes_back(self, tmp_path: Path) -> None:
        manifest = _write_manifest(
            tmp_path,
            {
                "kind": "report",
                "slug": "audit",
                "name": "Audit",
                "description": "Weekly",
                "details": "Workflow X produces { rows: [...] }; render as a table.",
            },
        )
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/reports",
            json={
                "success": True,
                "report_id": "rpt_abc",
                "url": "https://cdn/example.com/reports/audit/index.html",
            },
            status=202,
        )

        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "apply",
                "-m",
                str(manifest),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )

        assert result.exit_code == 0, result.output
        assert "rpt_abc" in result.output
        assert "enqueued" in result.output.lower()
        assert _read_manifest(manifest)["id"] == "rpt_abc"

        body = responses.calls[0].request.body
        assert "details=" in body
        assert "Audit" in body  # name maps to title

    @responses.activate
    def test_apply_with_id_patches_with_details(self, tmp_path: Path) -> None:
        manifest = _write_manifest(
            tmp_path,
            {
                "kind": "report",
                "id": "rpt_abc",
                "slug": "audit",
                "details": "Workflow Y now produces a score field; surface it as a dial.",
            },
        )
        responses.add(
            responses.PATCH,
            f"{DEFAULT_BASE_URL}/reports/audit",
            json={
                "success": True,
                "report_id": "rpt_abc",
                "url": "https://cdn/example.com/reports/audit/index.html",
            },
            status=202,
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "apply",
                "-m",
                str(manifest),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code == 0, result.output
        assert "enqueued" in result.output.lower()
        body = responses.calls[0].request.body
        assert "details=" in body

    @responses.activate
    def test_apply_with_id_metadata_only(self, tmp_path: Path) -> None:
        manifest = _write_manifest(
            tmp_path,
            {
                "kind": "report",
                "id": "rpt_abc",
                "slug": "audit",
                "name": "New title",
            },
        )
        responses.add(
            responses.PATCH,
            f"{DEFAULT_BASE_URL}/reports/audit",
            json={
                "success": True,
                "report_id": "rpt_abc",
                "url": "https://cdn/example.com/reports/audit/index.html",
            },
            status=200,
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "apply",
                "-m",
                str(manifest),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code == 0, result.output
        body = responses.calls[0].request.body
        assert "New+title" in body or "New title" in body

    def test_apply_first_time_requires_details(self, tmp_path: Path) -> None:
        manifest = _write_manifest(
            tmp_path, {"kind": "report", "slug": "audit", "name": "Audit"}
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "apply",
                "-m",
                str(manifest),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "details" in result.output.lower()

    def test_apply_rejects_manifest_without_slug(self, tmp_path: Path) -> None:
        manifest = _write_manifest(tmp_path, {"kind": "report", "details": "..."})
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "apply",
                "-m",
                str(manifest),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "slug" in result.output.lower()

    def test_apply_rejects_manifest_with_schedule(self, tmp_path: Path) -> None:
        manifest = _write_manifest(
            tmp_path,
            {
                "kind": "report",
                "slug": "audit",
                "details": "...",
                "schedule": {"type": "manual"},
            },
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "apply",
                "-m",
                str(manifest),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "schedule" in result.output.lower()

    def test_apply_rejects_manifest_with_wrong_kind(self, tmp_path: Path) -> None:
        manifest = _write_manifest(
            tmp_path, {"kind": "workflow", "name": "X", "details": "..."}
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "apply",
                "-m",
                str(manifest),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "kind" in result.output.lower()

    @responses.activate
    def test_apply_surfaces_409_duplicate(self, tmp_path: Path) -> None:
        manifest = _write_manifest(
            tmp_path,
            {"kind": "report", "slug": "audit", "details": "x"},
        )
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/reports",
            json={"error": "Report with slug 'audit' already exists. The manifest needs an 'id' to update an existing report."},
            status=409,
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "apply",
                "-m",
                str(manifest),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "already exists" in result.output


# ---------------------------------------------------------------------------
# report publish
# ---------------------------------------------------------------------------


def _publish_manifest(tmp_path: Path, slug: str = "audit", report_id: str = "rpt_abc") -> Path:
    return _write_manifest(
        tmp_path,
        {"kind": "report", "id": report_id, "slug": slug, "name": "Audit"},
    )


class TestReportPublish:
    @responses.activate
    def test_publish_uploads_html_and_spec_from_dir(self, tmp_path: Path) -> None:
        _html(tmp_path)
        _spec(tmp_path)
        manifest = _publish_manifest(tmp_path)

        responses.add(
            responses.PATCH,
            f"{DEFAULT_BASE_URL}/reports/audit",
            json={
                "success": True,
                "report_id": "rpt_abc",
                "url": "https://cdn/example.com/reports/audit/index.html",
            },
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "publish",
                "-m",
                str(manifest),
                "--dir",
                str(tmp_path),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code == 0, result.output
        body = responses.calls[0].request.body
        assert b'name="file"' in body
        assert b'name="spec"' in body
        assert b"index.html" in body
        assert b"spec.json" in body

    def test_publish_requires_id(self, tmp_path: Path) -> None:
        _html(tmp_path)
        _spec(tmp_path)
        manifest = _write_manifest(
            tmp_path, {"kind": "report", "slug": "audit"}, name="no_id.json"
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "publish",
                "-m",
                str(manifest),
                "--dir",
                str(tmp_path),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "id" in result.output.lower()

    def test_publish_errors_when_index_html_missing(self, tmp_path: Path) -> None:
        _spec(tmp_path)
        manifest = _publish_manifest(tmp_path)
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "publish",
                "-m",
                str(manifest),
                "--dir",
                str(tmp_path),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "index.html" in result.output

    def test_publish_errors_when_spec_json_missing(self, tmp_path: Path) -> None:
        _html(tmp_path)
        manifest = _publish_manifest(tmp_path)
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "publish",
                "-m",
                str(manifest),
                "--dir",
                str(tmp_path),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "spec.json" in result.output


# ---------------------------------------------------------------------------
# report submit
# ---------------------------------------------------------------------------


class TestReportSubmit:
    @responses.activate
    def test_submit_happy_path(self, tmp_path: Path) -> None:
        data = _data(tmp_path)
        manifest = _publish_manifest(tmp_path)
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/reports/audit/publish",
            json={
                "success": True,
                "report_id": "rpt_abc",
                "url": "https://cdn/example.com/reports/audit/data.json",
            },
            status=200,
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "submit",
                "-m",
                str(manifest),
                "--file",
                str(data),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code == 0, result.output
        assert "audit" in result.output.lower()

    def test_submit_rejects_non_json(self, tmp_path: Path) -> None:
        bad = _write(tmp_path / "data.csv", "a,b\n1,2\n")
        manifest = _publish_manifest(tmp_path)
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "submit",
                "-m",
                str(manifest),
                "--file",
                str(bad),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert ".json" in result.output

    def test_submit_rejects_invalid_json(self, tmp_path: Path) -> None:
        bad = _write(tmp_path / "data.json", "{not json")
        manifest = _publish_manifest(tmp_path)
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "submit",
                "-m",
                str(manifest),
                "--file",
                str(bad),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "valid JSON" in result.output or "not valid JSON" in result.output

    def test_submit_requires_id(self, tmp_path: Path) -> None:
        data = _data(tmp_path)
        manifest = _write_manifest(
            tmp_path, {"kind": "report", "slug": "audit"}, name="no_id.json"
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "submit",
                "-m",
                str(manifest),
                "--file",
                str(data),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "id" in result.output.lower()

    @responses.activate
    def test_submit_surfaces_404(self, tmp_path: Path) -> None:
        data = _data(tmp_path)
        manifest = _publish_manifest(tmp_path, slug="missing")
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/reports/missing/publish",
            json={"error": "not found"},
            status=404,
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "submit",
                "-m",
                str(manifest),
                "--file",
                str(data),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "not found" in result.output.lower()
