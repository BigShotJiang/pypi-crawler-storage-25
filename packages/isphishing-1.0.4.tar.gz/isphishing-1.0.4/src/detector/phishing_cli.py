import os
import sys

def main_cli():
    # Get the directory where the package is installed
    package_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    # Define paths relative to where the user runs the command
    user_dir = os.getcwd()
    MODEL_PATH = os.path.join(user_dir, "models", "model.pkl")
    VECTORIZER_PATH = os.path.join(user_dir, "models", "vectorizer.pkl")

    sys.path.insert(0, user_dir)

    from src.detector.phishing_detector import PhishingDetector
    from src.inputs.email_input import EmailInput
    from src.inputs.url_input import URLInput

    # Check if model exists
    if not os.path.exists(MODEL_PATH):
        print("=" * 50)
        print("  Model not found!")
        print("  Please run: isphishing-train")
        print("  Or download the model from:")
        print("  https://github.com/f3d4yn/phishing-detector")
        print("=" * 50)
        return

    detector = PhishingDetector(
        model_path=MODEL_PATH,
        vectorizer_path=VECTORIZER_PATH
    )

    print("=" * 50)
    print("      PHISHING DETECTOR")
    print("      by Habib Ilyas & Boukyod Abdessamad")
    print("=" * 50)
    print("1. Analyze a URL")
    print("2. Analyze an Email")
    print("=" * 50)

    choice = input("Enter your choice (1 or 2): ").strip()

    if choice == "1":
        url = input("Enter the URL to analyze: ").strip()
        report = detector.analyze(URLInput(url))
        print(report)
    elif choice == "2":
        sender = input("Enter sender email: ").strip()
        subject = input("Enter email subject: ").strip()
        body = input("Enter email body: ").strip()
        report = detector.analyze(EmailInput(body, subject, sender))
        print(report)
    else:
        print("Invalid choice.")
