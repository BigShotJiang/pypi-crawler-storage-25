"""Initialize project node to find project root."""

from typing import Any

from rich.console import Console

from ..config import ConfigError, find_project_root, load_project_config
from ..logging_config import init_project_logging
from ..state import FirmwareState

console = Console()


def init_project_node(state: FirmwareState) -> dict[str, Any]:
    """
    Initialize project paths using .fwauto/ anchor.

    Searches for .fwauto/ directory from current working directory upwards,
    loads configuration, and initializes logging.
    """
    # Search for .fwauto/ anchor
    project_root = find_project_root()

    if not project_root:
        # No .fwauto/ found
        return {
            **state,
            "project_root": "",
            "project_initialized": False,
            "build_status": "error",
            "build_errors": ["No .fwauto/ directory found. Please run 'fwauto init' first."],
        }

    # Found .fwauto/ directory
    try:
        # Initialize logging with project directory
        init_project_logging(project_root)

        # Load project configuration
        config = load_project_config(project_root)
        console.print(f"[green]Found project root: {project_root}[/green]")
        console.print(f"[cyan]Project: {project_root.name}[/cyan]")

        return {
            **state,
            "project_root": str(project_root),
            "project_initialized": True,
            "config": config,
        }

    except ConfigError as e:
        console.print(f"[red]Config error: {e}[/red]")
        return {
            **state,
            "project_root": "",
            "project_initialized": False,
            "build_status": "error",
            "build_errors": [f"Configuration error: {str(e)}"],
        }
