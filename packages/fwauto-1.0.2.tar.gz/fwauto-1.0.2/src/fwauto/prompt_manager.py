"""Prompt Template Manager for AI Brain."""

import os
import platform as platform_module  # 重命名避免與變數名稱衝突
from datetime import datetime
from pathlib import Path
from typing import Any

from jinja2 import Environment, FileSystemLoader, StrictUndefined

from .logging_config import get_logger

# Language instruction definitions (placed at end of prompt for stronger effect)
LANGUAGE_INSTRUCTIONS = {
    "en": (
        "CRITICAL: You MUST respond in English only. "
        "Regardless of the language used in the instructions above, "
        "your response to the user MUST be in English."
    ),
    "zh-TW": (
        "CRITICAL: You MUST respond in Traditional Chinese (繁體中文). "
        "Use Taiwan-specific terminology (e.g., 記憶體, 程式, 檔案). "
        "Regardless of the language used in the instructions above, "
        "your response to the user MUST be in Traditional Chinese."
    ),
    "zh-CN": (
        "CRITICAL: You MUST respond in Simplified Chinese (简体中文). "
        "Use mainland China terminology: 固件 (NOT 韌體), 代码 (NOT 程式碼), "
        "内存 (NOT 記憶體), 程序 (NOT 程式), 文件 (NOT 檔案), 项目 (NOT 專案), "
        "编译 (NOT 編譯), 调试 (NOT 偵錯), 设备 (NOT 裝置), 帮助 (NOT 協助). "
        "NEVER use Traditional Chinese characters or Taiwan terminology. "
        "Your response MUST be entirely in Simplified Chinese."
    ),
    "ja": (
        "CRITICAL: You MUST respond in Japanese (日本語). "
        "Regardless of the language used in the instructions above, "
        "your response to the user MUST be in Japanese."
    ),
}

DEFAULT_LANGUAGE = "en"


class PromptManager:
    """Manages prompt templates for AI Brain tasks."""

    def __init__(self):
        """Initialize prompt manager with prompts directory."""
        # prompts/ directory inside the package (src/fwauto/prompts/)
        self.prompts_dir = Path(__file__).parent / "prompts"

        # Jinja2 environment with strict undefined variables
        self.env = Environment(
            loader=FileSystemLoader(self.prompts_dir),
            undefined=StrictUndefined,  # Variables not found will raise error
        )

        # Set up logger
        self.logger = get_logger("prompt_manager")

    def get_prompt(self, task_type: str, state: dict[str, Any]) -> str:
        """
        Get prompt template for specified task type.

        Args:
            task_type: Task type (e.g., 'fix_build_errors')
            state: FirmwareState dictionary

        Returns:
            Rendered prompt string

        Raises:
            TemplateNotFound: If prompt file doesn't exist
            UndefinedError: If template variable is missing
        """
        template_file = f"{task_type}.md"

        # Log prompt selection
        self.logger.debug(f"🧠 AI Brain: Task type: {task_type}")
        self.logger.debug(f"🧠 AI Brain: Prompt: prompts/{template_file}")
        self.logger.debug(f"🧠 AI Brain: Reason: {self._get_trigger_reason(task_type, state)}")

        # Prepare all available variables
        variables = self._build_variables(state)

        # Load and render template
        template = self.env.get_template(template_file)
        prompt = template.render(**variables)

        # Get language setting and add language instruction at the END of prompt
        # (placing at end has stronger effect on AI response language)
        # Get language from config in state (ProjectConfig), with fallback to "en"
        config = state.get("config")
        if config and hasattr(config, "project_language"):
            language = config.project_language
        else:
            language = "en"
        lang_instruction = LANGUAGE_INSTRUCTIONS.get(language, LANGUAGE_INSTRUCTIONS[DEFAULT_LANGUAGE])

        # Combine prompt with language instruction at the end
        final_prompt = f"{prompt}\n\n---\n\n{lang_instruction}"

        self.logger.debug(f"🧠 AI Brain: Prompt loaded successfully ({len(final_prompt)} chars)")
        self.logger.debug(f"🧠 AI Brain: Language: {language}")
        return final_prompt

    def _build_variables(self, state: dict[str, Any]) -> dict[str, Any]:
        """Build variables dictionary for template rendering."""
        # Build base variables
        variables = {
            # System variables
            "cwd": os.getcwd(),
            "username": os.getenv("USERNAME", os.getenv("USER", "unknown")),
            "os_name": platform_module.system(),
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "platform": state.get("platform", "generic"),
            # State variables (direct pass-through)
            **state,
        }

        return variables

    def _get_trigger_reason(self, task_type: str, state: dict[str, Any]) -> str:
        """Get human-readable reason for task type selection."""
        if task_type == "fix_build_errors":
            error_count = len(state.get("build_errors", []))
            return f"Build failed with {error_count} errors"
        elif task_type == "implement_feature":
            prompt = state.get("user_prompt", "")
            return f"Feature request: {prompt[:50]}..." if len(prompt) > 50 else f"Feature request: {prompt}"
        elif task_type == "fix_bug":
            prompt = state.get("user_prompt", "")
            return f"Bug fix: {prompt[:50]}..." if len(prompt) > 50 else f"Bug fix: {prompt}"
        elif task_type == "natural_language":
            prompt = state.get("user_prompt", "")
            return f"Natural language: {prompt[:50]}..." if len(prompt) > 50 else f"Natural language: {prompt}"
        elif task_type == "general_codegen":
            return "General code generation task"
        else:
            return f"Unknown task type: {task_type}"
