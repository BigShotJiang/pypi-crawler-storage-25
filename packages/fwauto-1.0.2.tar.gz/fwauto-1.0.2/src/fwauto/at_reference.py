"""Parse @path references in user input for file/directory context injection."""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from prompt_toolkit.completion import Completer, Completion

if TYPE_CHECKING:
    from prompt_toolkit.document import Document

# Directories excluded from @ tab completion
_EXCLUDED_NAMES = frozenset({"__pycache__", "node_modules", ".fwauto"})


@dataclass
class AtReference:
    """Parsed @ reference."""

    raw: str  # Original text (e.g., "@src/main.c")
    path: Path  # Resolved absolute path
    exists: bool  # Whether path exists
    is_dir: bool  # True if directory, False if file


def parse_at_references(text: str, project_root: str) -> list[AtReference]:
    """Parse @path references from user input.

    Supports:
        @src/main.c        - relative to project root
        @/opt/sdk/api.h    - absolute path
        @~/projects/lib.c  - home directory
        @./config.toml     - relative to CWD
        @../shared/utils.h - relative to CWD

    Args:
        text: User input text
        project_root: Project root directory path

    Returns:
        List of parsed AtReference objects
    """
    # Match @path preceded by whitespace or at start of string
    # Path continues until delimiter: whitespace, comma, semicolon, etc.
    pattern = r"(?:^|(?<=\s))@([^\s,;!?()\[\]{}]+)"
    matches = re.finditer(pattern, text)

    refs = []
    root = Path(project_root)

    for match in matches:
        raw_path = match.group(1)

        # Resolve path
        if raw_path.startswith("~/"):
            resolved = Path.home() / raw_path[2:]
        elif raw_path.startswith("/"):
            resolved = Path(raw_path)
        elif raw_path.startswith("./") or raw_path.startswith("../"):
            # Explicit relative paths resolve against CWD
            resolved = (Path.cwd() / raw_path).resolve()
        else:
            # Bare relative paths resolve against project root
            resolved = (root / raw_path).resolve()

        refs.append(
            AtReference(
                raw=match.group(0),
                path=resolved,
                exists=resolved.exists(),
                is_dir=resolved.is_dir() if resolved.exists() else False,
            )
        )

    return refs


def build_enriched_query(user_input: str, refs: list[AtReference]) -> str:
    """Build enriched query with @ reference instructions.

    Prepends instructions telling AI to read referenced paths.

    Args:
        user_input: Original user input
        refs: Parsed @ references

    Returns:
        Enriched query string
    """
    if not refs:
        return user_input

    lines = [
        "[System: The user referenced the following paths. "
        "Please read them using your Read/Glob tools before responding.]",
    ]

    for ref in refs:
        if not ref.exists:
            lines.append(f"- {ref.path} (NOT FOUND)")
        elif ref.is_dir:
            lines.append(f"- {ref.path} (directory - use Glob or LS to explore)")
        else:
            lines.append(f"- {ref.path} (file)")

    lines.append("")
    lines.append(user_input)

    return "\n".join(lines)


class AtReferenceCompleter(Completer):
    """Completer for @ file references. Triggers on '@' preceded by whitespace or at line start."""

    def __init__(self, project_root: str) -> None:
        self.project_root = project_root

    def get_completions(self, document: Document, complete_event):
        text = document.text_before_cursor

        # Find last '@' in the text
        at_pos = text.rfind("@")
        if at_pos == -1:
            return

        # '@' must be at start of text or preceded by whitespace
        if at_pos > 0 and not text[at_pos - 1].isspace():
            return

        # Extract partial path after '@'
        partial = text[at_pos + 1 :]

        # Don't complete if there's a space in the partial (user moved past the ref)
        if " " in partial:
            return

        # Determine base directory and prefix for completions
        base_dir, prefix = self._resolve_base(partial)
        if base_dir is None:
            return

        # Split into directory part and name filter
        if "/" in partial[len(prefix) :]:
            # e.g., partial="src/ma" -> dir_part="src", name_filter="ma"
            rest = partial[len(prefix) :]
            last_slash = rest.rfind("/")
            dir_part = rest[: last_slash + 1]
            name_filter = rest[last_slash + 1 :]
            scan_dir = base_dir / dir_part.rstrip("/")
            completion_prefix = prefix + dir_part
        else:
            name_filter = partial[len(prefix) :]
            scan_dir = base_dir
            completion_prefix = prefix

        # Calculate start_position (replace from '@' to cursor)
        start_position = -(len(partial) + 1)  # +1 for '@'

        # List directory and yield completions
        try:
            entries = sorted(scan_dir.iterdir(), key=lambda p: p.name)
        except OSError:
            return

        for entry in entries:
            name = entry.name

            # Filter hidden files and excluded directories
            if name.startswith(".") or name in _EXCLUDED_NAMES:
                continue

            # Filter by partial name
            if not name.lower().startswith(name_filter.lower()):
                continue

            is_dir = entry.is_dir()
            display_name = f"{name}/" if is_dir else name
            completion_text = f"@{completion_prefix}{display_name}"

            yield Completion(
                text=completion_text,
                start_position=start_position,
                display=display_name,
                display_meta="directory" if is_dir else "file",
            )

    def _resolve_base(self, partial: str) -> tuple[Path | None, str]:
        """Resolve the base directory and prefix from partial path.

        Returns:
            Tuple of (base_directory, prefix_string).
            base_directory is None if the path cannot be resolved.
            prefix_string is the path prefix to prepend to completions (e.g., "./", "~/").
        """
        if partial.startswith("~/"):
            return Path.home(), "~/"
        elif partial.startswith("/"):
            return Path("/"), "/"
        elif partial.startswith("./") or partial.startswith("../"):
            prefix = "./" if partial.startswith("./") else "../"
            base = Path.cwd() / prefix.rstrip("/")
            return base.resolve(), prefix
        else:
            # Bare relative path -> project root (fallback to CWD if empty)
            root = self.project_root or str(Path.cwd())
            return Path(root), ""
