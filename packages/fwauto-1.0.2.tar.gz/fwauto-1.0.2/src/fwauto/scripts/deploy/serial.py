#!/usr/bin/env python3
"""Deploy delegation script - Serial type (UART flashing)."""

import sys
import tomllib
from pathlib import Path


def main() -> int:
    """Execute serial deployment (placeholder)."""
    project_root = Path.cwd()
    config_path = project_root / ".fwauto" / "config.toml"

    if not config_path.exists():
        print(f"❌ Config not found: {config_path}", file=sys.stderr)
        return 1

    with open(config_path, "rb") as f:
        config = tomllib.load(f)

    # 讀取 deployment 設定
    deployment = config.get("deployment", {})
    port = deployment.get("port", "/dev/ttyUSB0")

    print(f"🔌 Serial deployment via {port}")
    print("⚠️  Serial flashing not yet implemented")

    # TODO: Implement serial flashing logic

    return 1  # 返回錯誤，表示未實作


if __name__ == "__main__":
    sys.exit(main())
