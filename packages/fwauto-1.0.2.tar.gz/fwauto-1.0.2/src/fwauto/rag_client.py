"""RAG Client - REST client for FWAuto Server RAG v2 API."""

import time
from collections.abc import Generator
from pathlib import Path

import requests

from .logging_config import get_logger

logger = get_logger("rag_client")


class RAGError(Exception):
    """RAG API error."""

    def __init__(self, message: str, status_code: int = 0):
        super().__init__(message)
        self.status_code = status_code


class RAGClient:
    """REST client for FWAuto Server RAG v2 API.

    All requests include Bearer token authentication.
    """

    def __init__(self, base_url: str, token: str, timeout: int = 30):
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.timeout = timeout

    @property
    def _headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self.token}"}

    # ============================================================
    # 文檔管理
    # ============================================================

    def list_documents(self) -> list:
        """List all documents. (GET /api/documents)"""
        response = requests.get(
            f"{self.base_url}/api/documents",
            headers=self._headers,
            timeout=self.timeout,
        )

        if response.status_code != 200:
            raise RAGError(f"Failed to list documents: {response.text}", response.status_code)

        return response.json()

    def get_document(self, doc_id: str) -> dict:
        """Get document details. (GET /api/documents/<doc_id>)"""
        response = requests.get(
            f"{self.base_url}/api/documents/{doc_id}",
            headers=self._headers,
            timeout=self.timeout,
        )

        if response.status_code != 200:
            raise RAGError(f"Document not found: {response.text}", response.status_code)

        return response.json()

    def upload(self, file_path: Path) -> dict:
        """Upload a PDF file. (POST /api/documents/upload)

        Returns:
            dict with doc_id, job_id, filename, page_count
        """
        file_path = Path(file_path)
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        if not file_path.suffix.lower() == ".pdf":
            raise ValueError(f"Only PDF files are supported: {file_path}")

        with open(file_path, "rb") as f:
            response = requests.post(
                f"{self.base_url}/api/documents/upload",
                headers=self._headers,
                files={"file": (file_path.name, f, "application/pdf")},
                timeout=self.timeout,
            )

        if response.status_code != 200:
            raise RAGError(f"Upload failed: {response.text}", response.status_code)

        return response.json()

    def delete_document(self, doc_id: str) -> bool:
        """Delete a document. (DELETE /api/documents/<doc_id>)"""
        response = requests.delete(
            f"{self.base_url}/api/documents/{doc_id}",
            headers=self._headers,
            timeout=self.timeout,
        )

        if response.status_code != 200:
            raise RAGError(f"Failed to delete document: {response.text}", response.status_code)

        return True

    # ============================================================
    # Job 狀態
    # ============================================================

    def get_job_status(self, job_id: str) -> dict:
        """Get processing job status. (GET /api/jobs/<job_id>/status)"""
        response = requests.get(
            f"{self.base_url}/api/jobs/{job_id}/status",
            headers=self._headers,
            timeout=self.timeout,
        )

        if response.status_code != 200:
            raise RAGError(f"Failed to get job status: {response.text}", response.status_code)

        return response.json()

    def stream_job_progress(self, job_id: str) -> Generator[dict, None, None]:
        """Stream job progress via SSE. (GET /sse/jobs/<job_id>)

        Yields:
            dict with stage, progress, total, message
        """
        import json

        url = f"{self.base_url}/sse/jobs/{job_id}?token={self.token}"
        try:
            with requests.get(url, stream=True, timeout=600) as response:
                if response.status_code != 200:
                    raise RAGError(f"SSE connection failed: {response.text}", response.status_code)

                for line in response.iter_lines(decode_unicode=True):
                    if line and line.startswith("data: "):
                        data = json.loads(line[6:])
                        yield data
                        if data.get("stage") in ("complete", "error"):
                            return
                        if "error" in data:
                            return
        except requests.exceptions.ConnectionError:
            logger.warning("SSE connection failed, falling back to polling")
            raise RAGError("SSE not available")

    def wait_for_job(self, job_id: str, poll_interval: float = 2.0, timeout: int = 600) -> dict:
        """Poll job status until complete or error (fallback).

        Args:
            job_id: Job ID from upload
            poll_interval: Seconds between polls
            timeout: Max seconds to wait

        Returns:
            Final job status dict
        """
        start = time.time()
        while True:
            status = self.get_job_status(job_id)
            stage = status.get("stage", "")

            if stage == "complete":
                return status
            if stage == "error":
                raise RAGError(f"Processing failed: {status.get('message', 'unknown error')}")

            if time.time() - start > timeout:
                raise RAGError(f"Timeout waiting for job {job_id} (stage: {stage})")

            time.sleep(poll_interval)

    # ============================================================
    # 搜尋 & 問答
    # ============================================================

    def search(self, question: str, doc_id: str | None = None, top_k: int = 15) -> dict:
        """Search documents. (POST /api/search)

        Returns:
            dict with question, doc_id, total, contexts
        """
        payload: dict = {"question": question, "top_k": top_k}
        if doc_id:
            payload["doc_id"] = doc_id

        response = requests.post(
            f"{self.base_url}/api/search",
            headers=self._headers,
            json=payload,
            timeout=self.timeout,
        )

        if response.status_code != 200:
            raise RAGError(f"Search failed: {response.text}", response.status_code)

        return response.json()

    def qa(self, question: str, doc_id: str | None = None) -> dict:
        """Ask a question with RAG-powered answer. (POST /api/qa)

        Returns:
            dict with answer, contexts_used, contexts, rewritten_queries
        """
        payload: dict = {"question": question}
        if doc_id:
            payload["doc_id"] = doc_id

        response = requests.post(
            f"{self.base_url}/api/qa",
            headers=self._headers,
            json=payload,
            timeout=120,  # QA 需要更長的 timeout（LLM 回答）
        )

        if response.status_code != 200:
            raise RAGError(f"QA failed: {response.text}", response.status_code)

        return response.json()
