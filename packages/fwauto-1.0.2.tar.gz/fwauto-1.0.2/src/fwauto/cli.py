"""Modern CLI using Typer framework.

This module is a thin registration layer. All command implementations
live in cli_commands/ submodules.
"""

import sys
from pathlib import Path

import typer
from rich.console import Console

from fwauto.cli_commands.auth import auth_app
from fwauto.cli_commands.firmware import (
    build_command,
    chat_command,
    dashboard_command,
    deploy_command,
    enter_unified_chat_mode,
    feat_command,
    help_command,
    log_command,
    run_command,
)
from fwauto.cli_commands.rag import rag_app
from fwauto.cli_commands.uart import uart_app

# Create Typer app
app = typer.Typer(
    name="fwauto",
    help="🚀 Firmware Automation Tool with AI",
    add_completion=False,
    pretty_exceptions_enable=False,
    invoke_without_command=True,
)

# Register sub-apps
app.add_typer(auth_app, name="auth")
app.add_typer(uart_app, name="uart", hidden=True)
app.add_typer(rag_app, name="rag")

# Config sub-commands (Typer instance created here to register callback below)
config_app = typer.Typer(help="⚙️ Configuration management")
app.add_typer(config_app, name="config")

console = Console()


# ============================================================
# App callback
# ============================================================


@app.callback(invoke_without_command=True)
def callback(
    ctx: typer.Context,
    ai_log: str = typer.Option(
        None,
        "--ai-log",
        envvar="FWAUTO_AI_LOG",
        hidden=True,
    ),
):
    """
    🚀 FWAuto - Firmware Development Automation Tool

    Run without command to start interactive chat:
        fwauto
        fwauto "讓 LED 快速閃爍"
    """
    from .logging_config import setup_ai_logger

    setup_ai_logger(level=ai_log)  # handles None → config.toml → OFF fallback

    # 如果有明確的子命令，讓 typer 處理
    if ctx.invoked_subcommand is not None:
        return

    # 無子命令但有 options (e.g. --ai-log INFO)，進入互動 chat
    enter_unified_chat_mode()


# ============================================================
# Register commands
# ============================================================

app.command(name="build")(build_command)
app.command(name="deploy")(deploy_command)
app.command(name="run", hidden=True)(run_command)
app.command(name="log")(log_command)
app.command(name="feat", hidden=True)(feat_command)
app.command(name="chat", hidden=True)(chat_command)
app.command(name="dashboard")(dashboard_command)
app.command(name="help")(help_command)


# ============================================================
# Config sub-commands (callback + get/set)
# ============================================================


@config_app.callback(invoke_without_command=True)
def config_callback(
    ctx: typer.Context,
    log: bool = typer.Option(False, "--log", help="Configure log settings"),
):
    """
    ⚙️ View or modify FWAuto project configuration.

    Examples:
        fwauto config                              # Show all settings
        fwauto config --log                        # Configure log settings
        fwauto config get build.type               # Get a specific value
        fwauto config set deployment.board_ip 192.168.1.100  # Set a value
    """
    # If a subcommand was invoked, let it handle
    if ctx.invoked_subcommand is not None:
        return

    project_root = Path.cwd()

    if log:
        from .cli_commands.config import run_log_wizard

        config_path = project_root / ".fwauto" / "config.toml"

        if not config_path.exists():
            console.print("[red]❌ Not in a FWAuto project (no .fwauto/config.toml)[/red]")
            console.print("[yellow]Tip: Run 'fwauto build' or 'fwauto deploy' to initialize a project[/yellow]")
            sys.exit(1)

        console.print("[cyan]⚙️ FWAuto Log Configuration[/cyan]")
        success = run_log_wizard(config_path)
        sys.exit(0 if success else 1)

    # Default: show all config
    from .cli_commands.config import config_show

    config_path = project_root / ".fwauto" / "config.toml"

    if not config_path.exists():
        console.print("[red]❌ Not in a FWAuto project (no .fwauto/config.toml)[/red]")
        console.print("[yellow]Tip: Run 'fwauto build' or 'fwauto deploy' to initialize a project[/yellow]")
        sys.exit(1)

    config_show(config_path)


@config_app.command(name="get")
def config_get_cmd(
    key: str = typer.Argument(..., help="Config key (e.g., build.type)"),
):
    """
    🔍 Get a configuration value.

    Examples:
        fwauto config get build.type
        fwauto config get deployment.board_ip
    """
    from .cli_commands.config import config_get

    config_path = Path.cwd() / ".fwauto" / "config.toml"

    if not config_path.exists():
        console.print("[red]❌ Not in a FWAuto project (no .fwauto/config.toml)[/red]")
        raise typer.Exit(1)

    try:
        _, value = config_get(key, config_path)
        if value is not None:
            console.print(f"  {key} = {value}")
        else:
            console.print(f"[yellow]⚠️ Key '{key}' not found[/yellow]")
    except ValueError as e:
        console.print(f"[red]❌ {e}[/red]")
        raise typer.Exit(1)


@config_app.command(name="set")
def config_set_cmd(
    key: str = typer.Argument(..., help="Config key (e.g., build.type)"),
    value: str = typer.Argument(..., help="Value to set"),
):
    """
    ✏️ Set a configuration value.

    Examples:
        fwauto config set build.type command
        fwauto config set deployment.board_ip 192.168.1.100
    """
    from .cli_commands.config import config_set

    config_path = Path.cwd() / ".fwauto" / "config.toml"

    if not config_path.exists():
        console.print("[red]❌ Not in a FWAuto project (no .fwauto/config.toml)[/red]")
        raise typer.Exit(1)

    try:
        config_set(key, value, config_path)
        console.print(f"[green]✅ Set {key} = {value}[/green]")
    except ValueError as e:
        console.print(f"[red]❌ {e}[/red]")
        raise typer.Exit(1)


# ============================================================
# Banner utilities
# ============================================================


def _load_banners() -> list[str]:
    """Load ASCII banners from banners.txt, split by '---' separator."""
    import importlib.resources

    try:
        text = importlib.resources.files("fwauto").joinpath("banners.txt").read_text(encoding="utf-8")
        banners = [b.strip("\n") for b in text.split("\n---\n") if b.strip()]
        if banners:
            return banners
    except Exception:
        pass
    # Fallback
    return [
        "░▒█▀▀▀░▒█░░▒█░█▀▀▄░▒█░▒█░▀▀█▀▀░▒█▀▀▀█\n"
        "░▒█▀▀░░▒█▒█▒█▒█▄▄█░▒█░▒█░░▒█░░░▒█░░▒█\n"
        "░▒█░░░░▒▀▄▀▄▀▒█░▒█░░▀▄▄▀░░▒█░░░▒█▄▄▄█"
    ]


def _print_banner():
    """Print a randomly selected FWAuto ASCII banner with version."""
    import random
    from importlib.metadata import version

    try:
        ver = version("fwauto") or "dev"
    except Exception:
        ver = "unknown"

    banner = random.choice(_load_banners())  # noqa: S311
    console.print(f"[cyan]{banner}[/cyan]")
    console.print(f"[dim]v{ver}[/dim]\n")


# ============================================================
# Entry point
# ============================================================


def main():
    """Entry point for the CLI."""
    from .logging_config import init_project_logging, setup_ai_logger
    from .uart_daemon import restart_daemon_if_running

    # Print banner
    _print_banner()

    # Initialize logging first (ensures debug logs for all commands)
    init_project_logging()

    # AI API logging (picks up config.toml if configured, no-op if OFF)
    setup_ai_logger()

    # Auto-restart UART daemon if running (resets 30-minute timer)
    restart_daemon_if_running()

    # Check if running in unified chat mode (no arguments or with message)
    if len(sys.argv) == 1:
        enter_unified_chat_mode()
    else:
        # 檢查第一個參數是否為子命令
        subcommand_names = {
            "build",
            "deploy",
            "run",
            "log",
            "feat",
            "chat",
            "config",
            "help",
            "auth",
            "rag",
            "dashboard",
            "uart",
        }
        first_arg = sys.argv[1] if len(sys.argv) > 1 else ""

        # 如果第一個參數是選項 (--xxx) 或有效子命令，讓 typer 處理
        if first_arg.startswith("-") or first_arg.lower() in subcommand_names:
            app()
        else:
            # 第一個參數是 chat message
            # 進入帶 message 的 chat 模式
            from fwauto.cli_commands.config import ensure_project_initialized

            project_root = ensure_project_initialized()
            if project_root:
                chat_command(first_arg)
            else:
                console.print("[red]❌ Setup cancelled[/red]")
                sys.exit(1)


if __name__ == "__main__":
    main()
