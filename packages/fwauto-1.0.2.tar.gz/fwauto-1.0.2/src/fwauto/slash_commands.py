"""Slash command parsing for unified chat interface."""

import os
import shlex
from dataclasses import dataclass
from typing import Any

from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.document import Document


@dataclass
class SlashCommand:
    """Parsed slash command representation."""

    name: str  # "build", "deploy", "log"
    raw_args: list[str]  # 原始參數列表
    parsed_args: dict[str, Any]  # 解析後的參數 dict


# Single Source of Truth for slash command names and descriptions
SLASH_COMMANDS: dict[str, str] = {
    "build": "Build firmware project",
    "deploy": "Deploy firmware to device",
    "log": "Analyze UART log files",
    "rag": "RAG document management",
    "auth": "Authentication commands (status/logout)",
    "config": "View or modify project configuration",
    "bug-report": "Report a bug (BETA model)",
    "help": "Show help information",
    "exit": "Exit chat session",
}


class SlashCommandCompleter(Completer):
    """Completer for slash commands. Triggers on '/' at start of text or after whitespace."""

    def get_completions(self, document: Document, complete_event):
        text = document.text_before_cursor

        # Find the last '/' in the text
        slash_pos = text.rfind("/")
        if slash_pos == -1:
            return

        # '/' must be at start of text or preceded by whitespace
        if slash_pos > 0 and not text[slash_pos - 1].isspace():
            return

        # Extract partial command after the last '/'
        partial = text[slash_pos + 1 :]

        # Don't complete if there's a space after the command name (user is typing args)
        if " " in partial:
            return

        # Calculate how many chars to replace (from '/' to cursor)
        start_position = -(len(partial) + 1)  # +1 for the '/' itself

        for name, description in SLASH_COMMANDS.items():
            if name.startswith(partial):
                yield Completion(
                    text=f"/{name}",
                    start_position=start_position,
                    display=f"/{name}",
                    display_meta=description,
                )


def parse_slash_command(user_input: str) -> SlashCommand | None:
    """Parse user input as slash command.

    Examples:
        "/build" -> SlashCommand(name="build", raw_args=[], parsed_args={})
        "/deploy --binary-args test.hex" -> SlashCommand(...)
        "/log analyze.txt '有任何 error 嗎?'" -> SlashCommand(...)
        "請幫我分析這個錯誤" -> None

    Args:
        user_input: User input string

    Returns:
        SlashCommand if input is valid slash command, None otherwise
    """
    if not user_input.strip().startswith("/"):
        return None

    try:
        # posix=False on Windows to preserve backslashes in file paths
        parts = shlex.split(user_input, posix=(os.name != "nt"))
    except ValueError:
        # Invalid quote syntax
        return None

    if not parts:
        return None

    command_name = parts[0][1:]  # Remove leading /

    if command_name not in SLASH_COMMANDS:
        return None

    return SlashCommand(
        name=command_name,
        raw_args=parts[1:],
        parsed_args={},  # Will be filled by parse_command_args
    )


def parse_command_args(cmd: SlashCommand) -> dict[str, Any]:
    """Parse slash command arguments into command_args dict.

    Handles:
    - /build -> {}
    - /deploy --binary-args test.hex -> {"binary_args": "test.hex"}
    - /deploy --scenario quick -> {"binary_args": scenario.binary_args}
    - /log path.txt "prompt" -> {"log_path": "path.txt", "analysis_prompt": "prompt"}

    Args:
        cmd: SlashCommand to parse

    Returns:
        Dictionary of parsed arguments

    Raises:
        ValueError: If required arguments are missing
    """
    if cmd.name == "build":
        return _parse_build_args(cmd.raw_args)
    elif cmd.name == "deploy":
        return _parse_deploy_args(cmd.raw_args)
    elif cmd.name == "log":
        return _parse_log_args(cmd.raw_args)
    elif cmd.name == "help":
        return {}  # help 不需要參數
    elif cmd.name == "exit":
        return {}  # exit 不需要參數
    elif cmd.name == "auth":
        return _parse_auth_args(cmd.raw_args)
    elif cmd.name == "rag":
        return _parse_rag_args(cmd.raw_args)
    elif cmd.name == "config":
        return _parse_config_args(cmd.raw_args)
    elif cmd.name == "bug-report":
        return _parse_bug_report_args(cmd.raw_args)
    else:
        raise ValueError(f"Unknown command: {cmd.name}")


def _parse_build_args(args: list[str]) -> dict[str, Any]:
    """Parse build command arguments.

    Build command has no arguments currently.

    Args:
        args: Raw argument list

    Returns:
        Empty dict
    """
    return {}


def _parse_deploy_args(args: list[str]) -> dict[str, Any]:
    """Parse deploy command arguments.

    Priority: --binary-args > --scenario

    Args:
        args: Raw argument list

    Returns:
        Dictionary with "binary_args" key

    Examples:
        ["--binary-args", "test.hex"] -> {"binary_args": "test.hex"}
        ["--scenario", "quick"] -> {"binary_args": <from scenario>}
        ["-ba", "on"] -> {"binary_args": "on"}
    """
    binary_args = ""
    scenario = ""

    i = 0
    while i < len(args):
        if args[i] in ["--binary-args", "-ba"]:
            if i + 1 < len(args):
                binary_args = args[i + 1]
                i += 2
            else:
                raise ValueError("--binary-args requires a value")
        elif args[i] in ["--scenario", "-s"]:
            if i + 1 < len(args):
                scenario = args[i + 1]
                i += 2
            else:
                raise ValueError("--scenario requires a value")
        else:
            i += 1

    # Apply priority rule
    final_binary_args = binary_args
    if not final_binary_args and scenario:
        # Load scenario (will be done in handler)
        # For now, just pass the scenario name
        return {"binary_args": "", "scenario": scenario}

    return {"binary_args": final_binary_args}


def _parse_log_args(args: list[str]) -> dict[str, Any]:
    """Parse log command arguments.

    Format: /log [log_path] [analysis_prompt]

    Args:
        args: Raw argument list

    Returns:
        Dictionary with "log_path" and "analysis_prompt" keys
        - log_path: None if not provided (system will use last_log_file_path from config)
        - analysis_prompt: User prompt or default "Analyze this log"

    Examples:
        [] -> {"log_path": None, "analysis_prompt": "Analyze this log"}
        ["有 error 嗎?"] -> {"log_path": None, "analysis_prompt": "有 error 嗎?"}
        ["uart.log"] -> {"log_path": "uart.log", "analysis_prompt": "Analyze this log"}
        ["uart.log", "有 error 嗎?"] -> {"log_path": "uart.log", "analysis_prompt": "有 error 嗎?"}
    """
    if not args:
        # No arguments: use default prompt and auto-detect log path from config
        return {"log_path": None, "analysis_prompt": "Analyze this log"}

    # Detect if first arg is a file path or a prompt
    # Heuristic: if first arg contains path-like patterns or file extensions, treat as path
    first_arg = args[0]
    is_path = (
        "/" in first_arg  # Contains path separator
        or "\\" in first_arg  # Windows path
        or first_arg.endswith((".log", ".txt"))  # Has log file extension
        or "@" in first_arg  # Remote path (user@host:path)
    )

    if is_path:
        # First arg is log_path
        log_path = first_arg
        analysis_prompt = " ".join(args[1:]) if len(args) > 1 else "Analyze this log"
    else:
        # First arg is analysis_prompt (no log_path provided)
        log_path = None
        analysis_prompt = " ".join(args)

    return {"log_path": log_path, "analysis_prompt": analysis_prompt}


def _parse_config_args(args: list[str]) -> dict[str, Any]:
    """Parse config command arguments.

    Format: /config [subcommand] [key] [value]
    - /config              -> show all config
    - /config get <key>    -> get value
    - /config set <key> <value> -> set value

    Args:
        args: Raw argument list

    Returns:
        Dictionary with "subcommand" key and optional "key"/"value"

    Raises:
        ValueError: If required arguments are missing
    """
    if not args:
        return {"subcommand": "show"}

    subcommand = args[0].lower()

    if subcommand == "get":
        if len(args) < 2:
            raise ValueError("/config get requires a key (e.g., /config get build.type)")
        return {"subcommand": "get", "key": args[1]}

    elif subcommand == "set":
        if len(args) < 3:
            raise ValueError("/config set requires key and value (e.g., /config set build.type command)")
        return {"subcommand": "set", "key": args[1], "value": " ".join(args[2:])}

    else:
        # Unknown subcommand, treat as show
        return {"subcommand": "show"}


def _parse_rag_args(args: list[str]) -> dict[str, Any]:
    """Parse rag command arguments.

    Format: /rag [subcommand] [args...]
    - /rag                    -> show help
    - /rag list               -> list all documents
    - /rag info <doc_id>      -> document details
    - /rag upload <path>      -> upload PDF
    - /rag delete <doc_id>    -> delete document
    - /rag status <job_id>    -> check job status
    - /rag search <query>     -> search documents
    - /rag search <query> --doc-id <id>  -> search in specific doc
    - /rag qa <question>      -> ask question with RAG answer
    - /rag qa <question> --doc-id <id>   -> ask about specific doc
    """
    if not args:
        return {"subcommand": "help"}

    subcommand = args[0].lower()

    if subcommand == "list":
        return {"subcommand": "list"}

    elif subcommand == "info":
        if len(args) < 2:
            return {"subcommand": "info", "doc_id": ""}
        return {"subcommand": "info", "doc_id": args[1]}

    elif subcommand == "upload":
        if len(args) < 2:
            return {"subcommand": "upload", "path": ""}
        return {"subcommand": "upload", "path": " ".join(args[1:])}

    elif subcommand == "delete":
        if len(args) < 2:
            return {"subcommand": "delete", "doc_id": ""}
        return {"subcommand": "delete", "doc_id": args[1]}

    elif subcommand == "status":
        if len(args) < 2:
            return {"subcommand": "status", "job_id": ""}
        return {"subcommand": "status", "job_id": args[1]}

    elif subcommand == "search":
        doc_id = ""
        query_parts = []
        i = 1
        while i < len(args):
            if args[i] in ("--doc-id", "-d") and i + 1 < len(args):
                doc_id = args[i + 1]
                i += 2
            else:
                query_parts.append(args[i])
                i += 1
        return {"subcommand": "search", "query": " ".join(query_parts), "doc_id": doc_id}

    elif subcommand == "qa":
        doc_id = ""
        query_parts = []
        i = 1
        while i < len(args):
            if args[i] in ("--doc-id", "-d") and i + 1 < len(args):
                doc_id = args[i + 1]
                i += 2
            else:
                query_parts.append(args[i])
                i += 1
        return {"subcommand": "qa", "question": " ".join(query_parts), "doc_id": doc_id}

    else:
        return {"subcommand": "help"}


def _parse_bug_report_args(args: list[str]) -> dict[str, Any]:
    """Parse bug-report command arguments.

    Format: /bug-report <description>
    All args after /bug-report are joined as the description text.
    """
    description = " ".join(args).strip()
    return {"description": description}


def _parse_auth_args(args: list[str]) -> dict[str, Any]:
    """Parse auth command arguments.

    Format: /auth [subcommand]
    - /auth         -> show help
    - /auth status  -> show status
    - /auth logout  -> logout

    Args:
        args: Raw argument list

    Returns:
        Dictionary with "subcommand" key
    """
    if not args:
        return {"subcommand": "help"}

    subcommand = args[0].lower()
    if subcommand in ("status", "logout"):
        return {"subcommand": subcommand}
    else:
        return {"subcommand": "help"}  # 無效子命令顯示幫助
