"""RAG document management CLI commands."""

from pathlib import Path

import typer
from rich.console import Console

rag_app = typer.Typer(help="📚 RAG document search")

console = Console()


def _get_rag_client():
    """Get RAG client instance using FWAuto Server URL + auth token."""
    from ..auth import get_auth_server_url, get_user_token
    from ..rag_client import RAGClient

    token = get_user_token()
    server_url = get_auth_server_url()

    if not token or not server_url:
        console.print("[yellow]⚠️ Please login first: fwauto auth login[/yellow]")
        raise typer.Exit(1)

    return RAGClient(base_url=server_url, token=token)


def _rag_input(prompt_text: str) -> str:
    """Get user input for RAG interactive mode. Uses console.input() for async compatibility."""
    return console.input(f"[cyan]{prompt_text}>[/cyan] ").strip()


def _rag_interactive_list():
    """Interactive list: show docs -> select one -> action (search/delete)."""
    client = _get_rag_client()

    try:
        docs = client.list_documents()
    except Exception as e:
        console.print(f"[red]❌ Failed to list documents: {e}[/red]")
        raise typer.Exit(1)

    if not docs:
        console.print("[yellow]No documents found.[/yellow]")
        return

    # Display numbered list
    console.print(f"\n[bold]📚 Documents ({len(docs)})[/bold]")
    for i, doc in enumerate(docs, 1):
        filename = doc.get("filename", doc.get("name", "unknown"))
        status = doc.get("status", "unknown")
        pages = doc.get("pages", doc.get("page_count", "?"))
        status_color = "green" if status == "ready" else "yellow" if status == "processing" else "red"
        console.print(f"  [{i}] {filename}  [{status_color}]{status}[/{status_color}]  {pages} pages")
    console.print()

    # Select document
    try:
        choice = _rag_input(f"Select document [1-{len(docs)}]")
    except (EOFError, KeyboardInterrupt):
        return

    if not choice:
        return

    try:
        idx = int(choice) - 1
        if idx < 0 or idx >= len(docs):
            console.print("[red]❌ Invalid selection[/red]")
            return
    except ValueError:
        console.print("[red]❌ Please enter a number[/red]")
        return

    doc = docs[idx]
    doc_id = doc.get("id", doc.get("doc_id", ""))
    filename = doc.get("filename", doc.get("name", "unknown"))

    # Action menu
    console.print(f"\n[bold]📄 {filename}[/bold]")
    console.print("  [1] search - Search this document")
    console.print("  [2] delete - Delete this document")
    console.print()

    try:
        action = _rag_input("Action [1-2]")
    except (EOFError, KeyboardInterrupt):
        return

    if action == "1":
        try:
            query = _rag_input("🔍 Search query")
        except (EOFError, KeyboardInterrupt):
            return
        if query:
            _rag_do_search(client, query, doc_id=doc_id)
    elif action == "2":
        confirm = typer.confirm(f"Delete {filename}?", default=False)
        if confirm:
            try:
                client.delete_document(doc_id)
                console.print(f"[green]✅ Deleted: {filename}[/green]")
            except Exception as e:
                console.print(f"[red]❌ Delete failed: {e}[/red]")


def _rag_wait_for_processing(client, job_id: str, doc_id: str) -> None:
    """Wait for document processing with SSE progress, fallback to polling."""
    from rich.live import Live
    from rich.spinner import Spinner

    from ..rag_client import RAGError

    # 嘗試 SSE 即時進度
    try:
        with Live(Spinner("dots", text="Processing..."), console=console, refresh_per_second=4) as live:
            for event in client.stream_job_progress(job_id):
                stage = event.get("stage", "")
                msg = event.get("message", "")
                if "error" in event:
                    console.print(f"[red]❌ {event['error']}[/red]")
                    return
                live.update(Spinner("dots", text=f"{stage}: {msg}" if msg else f"Stage: {stage}"))
                if stage == "complete":
                    return
                if stage == "error":
                    console.print(f"[red]❌ Processing failed: {msg}[/red]")
                    return
    except RAGError:
        pass  # SSE 不可用，fallback 到 polling

    # Polling fallback
    import time

    console.print("[dim]Polling for status...[/dim]")
    start = time.time()
    while True:
        try:
            status = client.get_job_status(job_id)
        except RAGError as e:
            if "not found" in str(e).lower():
                # Check if document is already ready
                try:
                    docs = client.list_documents()
                    doc = next((d for d in docs if d.get("id") == doc_id or d.get("doc_id") == doc_id), None)
                    if doc and doc.get("status") == "ready":
                        return
                except Exception:
                    pass
            console.print(f"[red]❌ {e}[/red]")
            return

        stage = status.get("stage", "")
        msg = status.get("message", "")

        if stage == "complete":
            return
        if stage == "error":
            console.print(f"[red]❌ Processing failed: {msg}[/red]")
            return
        if time.time() - start > 600:
            console.print("[red]❌ Timeout (10 min)[/red]")
            return

        time.sleep(2)


def _rag_do_info(client, doc_id: str) -> None:
    """Display document details in a Rich panel."""
    from rich.panel import Panel

    try:
        doc = client.get_document(doc_id)
    except Exception as e:
        console.print(f"[red]❌ {e}[/red]")
        return

    filename = doc.get("filename", doc.get("name", "unknown"))
    info_lines = [
        f"Filename:  {filename}",
        f"Doc ID:    {doc.get('id', doc.get('doc_id', '?'))}",
        f"Status:    {doc.get('status', '?')}",
        f"Pages:     {doc.get('pages', doc.get('page_count', '?'))}",
        f"Chunks:    {doc.get('chunks', doc.get('chunk_count', '?'))}",
        f"Size:      {doc.get('size', doc.get('file_size', '?'))}",
        f"Uploaded:  {doc.get('created_at', doc.get('uploaded_at', '?'))}",
    ]
    console.print(Panel("\n".join(info_lines), title=f"📄 {filename}"))


def _rag_do_qa(client, question: str, doc_id: str | None = None) -> None:
    """Execute QA and display answer with sources."""
    from rich.panel import Panel

    console.print(f"[cyan]🤖 Asking: {question}[/cyan]")
    if doc_id:
        console.print(f"[dim]Document: {doc_id}[/dim]")

    try:
        result = client.qa(question, doc_id=doc_id)
    except Exception as e:
        console.print(f"[red]❌ QA failed: {e}[/red]")
        return

    answer = result.get("answer", "No answer")
    console.print(Panel(answer, title="📝 Answer"))

    # 顯示來源
    contexts = result.get("contexts", [])
    if contexts:
        console.print(f"\n[dim]📚 Based on {len(contexts)} context(s):[/dim]")
        for i, ctx in enumerate(contexts[:5], 1):
            score = ctx.get("score", 0)
            doc_name = ctx.get("doc_name", "unknown")
            page = ctx.get("page", "?")
            console.print(f"  [{i}] {score:.3f} 📄 {doc_name} (p.{page})")

    # 顯示 rewritten queries
    rewritten = result.get("rewritten_queries", [])
    if rewritten:
        console.print(f"\n[dim]🔄 Rewritten queries: {', '.join(rewritten)}[/dim]")


def _rag_do_search(client, question: str, doc_id: str | None = None):
    """Execute search and display results."""
    console.print(f"[cyan]🔍 Searching: {question}[/cyan]")
    if doc_id:
        console.print(f"[dim]Document: {doc_id}[/dim]")

    try:
        result = client.search(question, doc_id=doc_id)
    except Exception as e:
        console.print(f"[red]❌ Search failed: {e}[/red]")
        return

    contexts = result.get("contexts", [])
    if not contexts:
        console.print("[yellow]No results found.[/yellow]")
        return

    console.print(f"[green]Found {len(contexts)} result(s):[/green]\n")

    for i, ctx in enumerate(contexts, 1):
        score = ctx.get("score", 0)
        doc_name = ctx.get("doc_name", "unknown")
        page = ctx.get("page", "?")
        text = ctx.get("text", "")

        preview = text[:200] + "..." if len(text) > 200 else text
        preview = preview.replace("\n", " ")

        score_color = "green" if score > 0.7 else "yellow" if score > 0.4 else "red"
        console.print(f"[bold][{i}][/bold] [{score_color}]{score:.3f}[/{score_color}] 📄 {doc_name} (p.{page})")
        console.print(f"    [dim]{preview}[/dim]")
        console.print()


@rag_app.command(name="upload")
def rag_upload(
    path: Path = typer.Argument(..., help="PDF file path to upload"),
):
    """
    📤 Upload a PDF file for RAG processing.

    Examples:
        fwauto rag upload ./datasheet.pdf
    """
    client = _get_rag_client()

    console.print(f"[cyan]📤 Uploading: {path.name}[/cyan]")

    try:
        result = client.upload(path)
    except FileNotFoundError:
        console.print(f"[red]❌ File not found: {path}[/red]")
        raise typer.Exit(1)
    except ValueError as e:
        console.print(f"[red]❌ {e}[/red]")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]❌ Upload failed: {e}[/red]")
        raise typer.Exit(1)

    doc_id: str = result.get("doc_id", "")
    job_id: str = result.get("job_id", "")
    pages = result.get("page_count", "?")
    console.print(f"[green]✅ Uploaded! doc_id={doc_id}, pages={pages}[/green]")
    console.print(f"[dim]Processing job: {job_id}[/dim]")

    # Wait for processing with SSE progress
    console.print("[cyan]⏳ Waiting for processing...[/cyan]")
    try:
        _rag_wait_for_processing(client, job_id, doc_id)
    except KeyboardInterrupt:
        console.print(f"\n[yellow]Processing continues in background. job_id={job_id}[/yellow]")
        raise typer.Exit(0)

    console.print(f"[green]✅ Processing complete! doc_id={doc_id}[/green]")


@rag_app.command(name="status")
def rag_status(
    job_id: str = typer.Argument(..., help="Job ID from upload"),
):
    """
    📋 Check upload processing status.

    Examples:
        fwauto rag status 550e8400-e29b-41d4-a716-446655440000
    """
    client = _get_rag_client()

    try:
        status = client.get_job_status(job_id)
    except Exception as e:
        console.print(f"[red]❌ {e}[/red]")
        raise typer.Exit(1)

    stage = status.get("stage", "unknown")
    progress = status.get("progress", 0)
    total = status.get("total", 0)
    message = status.get("message", "")

    stage_colors = {
        "pending": "dim",
        "text": "cyan",
        "table": "cyan",
        "vision": "yellow",
        "vectorize": "yellow",
        "complete": "green",
        "error": "red",
    }
    color = stage_colors.get(stage, "white")

    console.print(f"[{color}]Stage: {stage}[/{color}]")
    if total > 0:
        console.print(f"Progress: {progress}/{total}")
    if message:
        console.print(f"Message: {message}")


@rag_app.command(name="list")
def rag_list():
    """
    📋 List all uploaded documents.

    Examples:
        fwauto rag list
    """
    from rich.table import Table

    client = _get_rag_client()

    try:
        docs = client.list_documents()
    except Exception as e:
        console.print(f"[red]❌ Failed to list documents: {e}[/red]")
        raise typer.Exit(1)

    if not docs:
        console.print("[yellow]No documents found.[/yellow]")
        raise typer.Exit(0)

    table = Table(title=f"📚 Documents ({len(docs)})")
    table.add_column("doc_id", style="cyan")
    table.add_column("Filename", style="white")
    table.add_column("Status", style="green")
    table.add_column("Pages", justify="right")
    table.add_column("Uploaded", style="dim")

    for doc in docs:
        doc_id = doc.get("id", doc.get("doc_id", "?"))
        filename = doc.get("filename", doc.get("name", "unknown"))
        status = doc.get("status", "unknown")
        pages = str(doc.get("pages", doc.get("page_count", "?")))
        uploaded = doc.get("created_at", doc.get("uploaded_at", "?"))

        status_style = "green" if status == "ready" else "yellow" if status == "processing" else "red"
        table.add_row(doc_id, filename, f"[{status_style}]{status}[/{status_style}]", pages, uploaded)

    console.print(table)


@rag_app.command(name="delete")
def rag_delete(
    doc_ids: list[str] | None = typer.Argument(None, help="Document ID(s) to delete"),
    all_docs: bool = typer.Option(False, "--all", "-a", help="Delete all documents"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
):
    """
    🗑️ Delete uploaded document(s).

    Examples:
        fwauto rag delete bb430ee4                  # Delete one
        fwauto rag delete bb430ee4 0036ff05         # Delete multiple
        fwauto rag delete --all                     # Delete all
        fwauto rag delete --all --force             # Delete all, skip confirmation
    """
    client = _get_rag_client()

    if all_docs:
        try:
            docs = client.list_documents()
        except Exception as e:
            console.print(f"[red]❌ Failed to list documents: {e}[/red]")
            raise typer.Exit(1)

        if not docs:
            console.print("[yellow]No documents to delete.[/yellow]")
            raise typer.Exit(0)

        if not force:
            confirm = typer.confirm(f"Delete ALL {len(docs)} documents?", default=False)
            if not confirm:
                console.print("[yellow]Cancelled.[/yellow]")
                raise typer.Exit(0)

        deleted = 0
        for doc in docs:
            did = doc.get("id", doc.get("doc_id", ""))
            try:
                client.delete_document(did)
                console.print(f"[green]✅ Deleted: {did} ({doc.get('filename', doc.get('name', ''))})[/green]")
                deleted += 1
            except Exception as e:
                console.print(f"[red]❌ Failed to delete {did}: {e}[/red]")

        console.print(f"\n[green]Deleted {deleted}/{len(docs)} documents.[/green]")
        return

    if not doc_ids:
        console.print("[red]❌ Provide doc_id(s) or use --all[/red]")
        raise typer.Exit(1)

    if not force and len(doc_ids) > 1:
        confirm = typer.confirm(f"Delete {len(doc_ids)} documents?", default=False)
        if not confirm:
            console.print("[yellow]Cancelled.[/yellow]")
            raise typer.Exit(0)
    elif not force:
        confirm = typer.confirm(f"Delete document {doc_ids[0]}?", default=False)
        if not confirm:
            console.print("[yellow]Cancelled.[/yellow]")
            raise typer.Exit(0)

    for did in doc_ids:
        try:
            client.delete_document(did)
            console.print(f"[green]✅ Deleted: {did}[/green]")
        except Exception as e:
            console.print(f"[red]❌ Failed to delete {did}: {e}[/red]")


@rag_app.command(name="search")
def rag_search(
    question: str = typer.Argument(..., help="Search query"),
    doc_id: str | None = typer.Option(None, "--doc-id", "-d", help="Limit search to specific document"),
    top_k: int = typer.Option(15, "--top-k", "-k", help="Number of results"),
):
    """
    🔍 Search uploaded documents.

    Examples:
        fwauto rag search "VCI voltage range"
        fwauto rag search "GPIO config" --doc-id abc123
        fwauto rag search "power supply" --top-k 5
    """
    client = _get_rag_client()
    _rag_do_search(client, question, doc_id=doc_id)


@rag_app.command(name="info")
def rag_info(
    doc_id: str = typer.Argument(..., help="Document ID"),
):
    """
    📄 Show document details.

    Examples:
        fwauto rag info c0b7b797
    """
    client = _get_rag_client()
    _rag_do_info(client, doc_id)


@rag_app.command(name="qa")
def rag_qa(
    question: str = typer.Argument(..., help="Question to ask"),
    doc_id: str | None = typer.Option(None, "--doc-id", "-d", help="Limit to specific document"),
):
    """
    🤖 Ask a question with RAG-powered answer.

    Examples:
        fwauto rag qa "What is the power supply voltage?"
        fwauto rag qa "GPIO config" --doc-id abc123
    """
    client = _get_rag_client()
    _rag_do_qa(client, question, doc_id=doc_id)
