"""Firmware build, deploy, run, and log CLI commands."""

import sys
from typing import Annotated

import typer
from rich.console import Console

from ..state import FirmwareState

console = Console()


def _ensure_authenticated() -> bool:
    """
    Ensure user is authenticated before running AI commands.

    Returns True if authenticated, False otherwise.
    """
    from ..auth import get_auth_manager

    auth = get_auth_manager()

    # 嘗試載入已有的 token
    if auth._load_config() and auth._verify_token():
        return True

    # Login required
    console.print("[yellow]⚠️  Not logged in. Login required to use AI features[/yellow]")
    console.print()

    # Ask if user wants to login
    try:
        do_login = typer.confirm("Login now?", default=True)
        if do_login:
            return auth.ensure_authenticated(use_dev_login=False)
        else:
            console.print("[dim]Tip: Run 'fwauto auth login' to login[/dim]")
            return False
    except (KeyboardInterrupt, EOFError):
        console.print("\n[yellow]Cancelled[/yellow]")
        return False


def _ensure_ai_ready() -> bool:
    """
    Ensure all prerequisites for AI features.

    Checks: User is logged in (skipped in Direct mode)

    Returns True if ready, False otherwise.
    """
    from ..auth import is_direct_api_mode

    # Direct 模式跳過登入檢查（使用本機 Claude Max 訂閱）
    if is_direct_api_mode():
        return True

    # Proxy 模式檢查登入狀態
    if not _ensure_authenticated():
        return False

    return True


def _build_deploy_state(
    binary_args: str,
    project_root: str,
) -> FirmwareState:
    """Build FirmwareState for deploy command.

    Used by both CLI deploy command and /deploy slash command.

    Args:
        binary_args: Binary arguments string
        project_root: Project root path

    Returns:
        FirmwareState configured for deploy
    """
    state: FirmwareState = {
        "user_prompt": "Deploy firmware to device",
        "project_root": project_root,
        "project_initialized": True,
        "execution_mode": "deploy",
        "command": "deploy",
        "command_args": {"binary_args": binary_args},
        "mode_metadata": {},
        "command_error": None,
        "build_status": "pending",
        "build_error_type": None,
        "build_errors": [],
        "build_log": "",
        "deploy_status": "pending",
        "deploy_errors": [],
        "deploy_log": "",
        "iteration": 0,
        "max_retries": 3,
        "log_file_path": None,
        "log_analysis_result": None,
        "firmware_path": None,
        "chat_completed": None,
        "config": None,
    }
    return state


def _build_log_state(
    log_path: str | None,
    analysis_prompt: str,
    project_root: str,
) -> FirmwareState:
    """Build FirmwareState for log command.

    Used by both CLI log command and /log slash command.
    Maintains double storage pattern for log_file_path.

    Args:
        log_path: Path to log file (None to auto-detect from config)
        analysis_prompt: Analysis prompt text
        project_root: Project root path

    Returns:
        FirmwareState configured for log analysis
    """
    state: FirmwareState = {
        "user_prompt": analysis_prompt,
        "project_root": project_root,
        "project_initialized": True,
        "execution_mode": "log",
        "command": "log",
        "command_args": {
            "log_path": log_path,
            "analysis_prompt": analysis_prompt,
        },
        "mode_metadata": {},
        "command_error": None,
        "build_status": "pending",
        "build_error_type": None,
        "build_errors": [],
        "build_log": "",
        "deploy_status": "pending",
        "deploy_errors": [],
        "deploy_log": "",
        "iteration": 0,
        "max_retries": 3,
        "log_file_path": log_path,  # Double storage (None is OK, log_node will handle)
        "log_analysis_result": None,
        "firmware_path": None,
        "chat_completed": None,
        "config": None,
    }
    return state


def run_workflow(state: FirmwareState) -> None:
    """Execute the firmware workflow with given state."""
    from ..graph import create_firmware_graph
    from ..nodes.chat import classify_error_for_ai_repair

    workflow = create_firmware_graph()

    try:
        # Stream workflow execution
        for event in workflow.stream(state):
            for node, result in event.items():
                # Display progress
                if node == "build":
                    status = result.get("build_status")
                    if status == "success":
                        console.print("[green]✓ Build succeeded[/green]")
                    elif status == "error":
                        iteration = result.get("iteration", 0)
                        max_retries = result.get("max_retries", 3)
                        console.print(f"[red]❌ Build failed (attempt {iteration}/{max_retries})[/red]")

                        # Display build log for error details
                        build_log = result.get("build_log", "")
                        if build_log:
                            console.print(f"[yellow]{build_log}[/yellow]")

                elif node == "deploy":
                    status = result.get("deploy_status")
                    if status == "success":
                        console.print("[green]✓ Deploy succeeded[/green]")

                        # Show remote log path if available
                        log_file_path = result.get("log_file_path")
                        if log_file_path:
                            console.print(f"[cyan]📊 Remote log: {log_file_path}[/cyan]")

                    elif status == "error":
                        console.print("[red]❌ Deploy failed[/red]")

                        # Get full error output for classification
                        errors = result.get("deploy_errors", [])
                        error_output = errors[0] if errors else ""

                        # Show brief error summary
                        if error_output:
                            error_summary = error_output.split("\n")[0]
                            if error_summary and error_summary != "Deploy failed: ":
                                console.print(f"[red]   {error_summary}[/red]")

                        # Classify error and show troubleshooting tips
                        should_offer_ai, prompt_message, _ = classify_error_for_ai_repair("deploy", error_output)

                        if not should_offer_ai:
                            # Infrastructure error - show troubleshooting tips
                            console.print(f"\n{prompt_message}")

                elif node == "log":
                    # Show log analysis result or error
                    log_result = result.get("log_analysis_result", "")
                    if log_result and log_result.startswith("Error:"):
                        console.print(f"[red]❌ {log_result}[/red]")

    except KeyboardInterrupt:
        console.print("\n[yellow]⚠️  Operation cancelled by user[/yellow]")
        sys.exit(130)
    except Exception as e:
        console.print(f"[red]❌ Workflow error: {e}[/red]")
        sys.exit(1)


def build_command():
    """
    🔨 Build firmware project.

    Auto-initializes if .fwauto/ configuration is missing.

    Example:
        fwauto build
    """
    from .config import ensure_project_initialized

    # 自動觸發專案初始化（如需要）
    project_root = ensure_project_initialized()
    if not project_root:
        raise typer.Exit(1)

    console.print("[cyan]🔨 Building project...[/cyan]")

    state: FirmwareState = {
        "user_prompt": "build",
        "project_root": "",
        "project_initialized": False,
        "build_status": "pending",
        "build_error_type": None,
        "build_errors": [],
        "build_log": "",
        "deploy_status": "pending",
        "deploy_errors": [],
        "deploy_log": "",
        "iteration": 0,
        "max_retries": 3,
        "execution_mode": "build",
        "command": "build",
        "command_args": {},
        "mode_metadata": None,
        "command_error": None,
        "log_file_path": None,
        "log_analysis_result": None,
        "firmware_path": None,
        "chat_completed": None,
        "config": None,
    }

    run_workflow(state)


def deploy_command(
    binary_args: str = typer.Option(
        "",
        "--binary-args",
        "-ba",
        help="Arguments to pass to the binary (e.g., 'on' or '--mode test')",
    ),
    scenario: str = typer.Option(
        "",
        "--scenario",
        "-s",
        help="Use a predefined scenario (overridden by --binary-args)",
    ),
):
    """
    📥 Deploy firmware to device.

    Auto-initializes if .fwauto/ configuration is missing.
    Supports passing arguments to the binary after deployment.

    \b
    Examples:
        fwauto deploy                             # Deploy without arguments
        fwauto deploy --binary-args "on"          # Pass single argument
        fwauto deploy -ba "arg1 arg2"             # Pass multiple arguments
        fwauto deploy --scenario led-on           # Use predefined scenario
        fwauto deploy -s test-mode                # Use scenario (short option)
    """
    from .config import ensure_project_initialized

    # 自動觸發專案初始化（如需要）
    project_root_init = ensure_project_initialized()
    if not project_root_init:
        raise typer.Exit(1)

    console.print("[cyan]📥 Deploying firmware...[/cyan]")

    # 優先級：--binary-args > --scenario
    final_binary_args = binary_args

    if not final_binary_args and scenario:
        # 載入 scenario
        try:
            from ..config import find_project_root, load_project_config

            project_root = find_project_root()
            if not project_root:
                console.print("[red]❌ Not in a FWAuto project (no .fwauto/ found)[/red]")
                raise typer.Exit(1)

            config = load_project_config(project_root)
            scenario_manager = config.get_scenario_manager()

            scenario_obj = scenario_manager.get_scenario(scenario)
            if not scenario_obj:
                console.print(f"[red]❌ Scenario '{scenario}' not found[/red]")
                console.print("[yellow]💡 Check scenarios in .fwauto/config.toml[/yellow]")
                raise typer.Exit(1)

            final_binary_args = scenario_obj.binary_args
            console.print(f"[green]✓[/green] Using scenario: {scenario_obj.name}")
            console.print(f"[dim]  Description: {scenario_obj.description}[/dim]")
            console.print(f"[dim]  Args: {scenario_obj.binary_args}[/dim]")

        except typer.Exit:
            raise
        except Exception as e:
            console.print(f"[red]❌ Failed to load scenario: {e}[/red]")
            raise typer.Exit(1)

    if final_binary_args:
        console.print(f"[cyan]📦 Binary args: {final_binary_args}[/cyan]")

    # Get project config for helper function
    from ..config import find_project_root

    project_root_path = find_project_root()
    if not project_root_path:
        console.print("[red]❌ Not in a FWAuto project (no .fwauto/ found)[/red]")
        raise typer.Exit(1)

    # Use helper function to build state
    state = _build_deploy_state(final_binary_args, str(project_root_path))

    run_workflow(state)


def run_command(
    binary_args: str = typer.Option(
        "",
        "--binary-args",
        "-ba",
        help="Arguments to pass to the binary (e.g., 'on' or '--mode test')",
    ),
    scenario: str = typer.Option(
        "",
        "--scenario",
        "-s",
        help="Use a predefined scenario (overridden by --binary-args)",
    ),
):
    """
    ⚡ Run build and deploy.

    Auto-initializes if .fwauto/ configuration is missing.
    Builds the project and deploys to device with optional binary arguments.

    \b
    Examples:
        fwauto run                                # Build and deploy
        fwauto run --binary-args "on"             # Build, deploy with argument
        fwauto run -ba "arg1 arg2"                # Build, deploy with multiple args
        fwauto run --scenario led-on              # Build, deploy with scenario
        fwauto run -s test-mode                   # Build, deploy with scenario (short)
    """
    from .config import ensure_project_initialized

    # 自動觸發專案初始化（如需要）
    project_root_init = ensure_project_initialized()
    if not project_root_init:
        raise typer.Exit(1)

    console.print("[cyan]⚡ Running build and deploy...[/cyan]")

    # 優先級：--binary-args > --scenario
    final_binary_args = binary_args

    if not final_binary_args and scenario:
        # 載入 scenario
        try:
            from ..config import find_project_root, load_project_config

            project_root = find_project_root()
            if not project_root:
                console.print("[red]❌ Not in a FWAuto project (no .fwauto/ found)[/red]")
                raise typer.Exit(1)

            config = load_project_config(project_root)
            scenario_manager = config.get_scenario_manager()

            scenario_obj = scenario_manager.get_scenario(scenario)
            if not scenario_obj:
                console.print(f"[red]❌ Scenario '{scenario}' not found[/red]")
                console.print("[yellow]💡 Check scenarios in .fwauto/config.toml[/yellow]")
                raise typer.Exit(1)

            final_binary_args = scenario_obj.binary_args
            console.print(f"[green]✓[/green] Using scenario: {scenario_obj.name}")
            console.print(f"[dim]  Description: {scenario_obj.description}[/dim]")
            console.print(f"[dim]  Args: {scenario_obj.binary_args}[/dim]")

        except typer.Exit:
            raise
        except Exception as e:
            console.print(f"[red]❌ Failed to load scenario: {e}[/red]")
            raise typer.Exit(1)

    if final_binary_args:
        console.print(f"[cyan]📦 Binary args: {final_binary_args}[/cyan]")

    state: FirmwareState = {
        "user_prompt": "run",
        "project_root": "",
        "project_initialized": False,
        "build_status": "pending",
        "build_error_type": None,
        "build_errors": [],
        "build_log": "",
        "deploy_status": "pending",
        "deploy_errors": [],
        "deploy_log": "",
        "iteration": 0,
        "max_retries": 3,
        "execution_mode": "run",
        "command": "run",
        "command_args": {"binary_args": final_binary_args},
        "mode_metadata": {"deploy_after_build": True},
        "command_error": None,
        "log_file_path": None,
        "log_analysis_result": None,
        "firmware_path": None,
        "chat_completed": None,
        "config": None,
    }

    run_workflow(state)


def log_command(
    prompt: str = typer.Argument(..., help="Analysis question or query"),
    log_path: str | None = typer.Option(
        None,
        "--log-path",
        "-l",
        help="Path to UART log file (local or remote: user@host:/path). If not provided, uses last log from config.",
    ),
):
    """
    📊 Analyze UART log files using AI.

    Supports both local and remote log files via SSH/SCP.

    Examples:
        fwauto log "有任何 error 嗎?"
        fwauto log "LED的閃爍頻率為何?" --log-path logs/uart.log
        fwauto log "開機訊息" --log-path user@192.168.1.100:/var/log/uart.log
    """
    from .config import ensure_project_initialized

    # 自動觸發專案初始化（如需要）
    project_root_path = ensure_project_initialized()
    if not project_root_path:
        raise typer.Exit(1)

    # 檢查 AI 功能是否可用
    if not _ensure_ai_ready():
        raise typer.Exit(1)

    if log_path:
        console.print(f"[cyan]📊 Analyzing log: {log_path}[/cyan]")
    else:
        console.print("[cyan]📊 Using log path from last deployment...[/cyan]")
    console.print(f"[cyan]❓ Question: {prompt}[/cyan]")

    # Use helper function to build state (pass None if not provided)
    state = _build_log_state(log_path, prompt, str(project_root_path))

    run_workflow(state)


def feat_command(
    prompt: str = typer.Argument(..., help="Feature description in natural language"),
):
    """
    🚀 AI-assisted firmware feature implementation.

    Automatically implements new firmware features with AI assistance,
    including code generation, compilation, auto-fix, and deployment.

    Examples:
        fwauto feat "實作摩斯密碼編碼，支援字符 A-Z"
        fwauto feat "加入蜂鳴器控制，發出 100ms 短音和 300ms 長音"
    """
    # 檢查 AI 功能是否可用
    if not _ensure_ai_ready():
        raise typer.Exit(1)

    console.print("[cyan]🚀 AI Feature Implementation[/cyan]")
    console.print(f"[yellow]Feature: {prompt}[/yellow]\n")

    state: FirmwareState = {
        "user_prompt": prompt,
        "project_root": "",
        "project_initialized": False,
        "build_status": "pending",
        "build_error_type": None,
        "build_errors": [],
        "build_log": "",
        "deploy_status": "pending",
        "deploy_errors": [],
        "deploy_log": "",
        "iteration": 0,
        "max_retries": 3,
        "execution_mode": "feat",
        "command": "feat",
        "command_args": {"feature_prompt": prompt},
        "mode_metadata": {"deploy_after_build": True},
        "command_error": None,
        "log_file_path": None,
        "log_analysis_result": None,
        "firmware_path": None,
        "chat_completed": None,
        "config": None,
    }

    run_workflow(state)


def chat_command(
    message: Annotated[
        str | None,
        typer.Argument(help="Initial message to send (optional)"),
    ] = None,
):
    """
    💬 Interactive chat with AI.

    Start an interactive conversation session to:
    - Ask questions about your project
    - Request code modifications or new features
    - Get help with debugging and analysis
    - Explore codebase structure

    Requires .fwauto/ configuration in current directory or parent directories.

    Examples:
        fwauto chat
        fwauto chat "讓 LED 快速閃爍"
    """
    # 檢查 AI 功能是否可用
    if not _ensure_ai_ready():
        raise typer.Exit(1)

    if message:
        console.print(f"[cyan]💬 Starting chat with: {message}[/cyan]")
    else:
        console.print("[cyan]💬 Starting interactive chat session...[/cyan]")

    state: FirmwareState = {
        "user_prompt": message or "chat",
        "project_root": "",
        "project_initialized": False,
        "build_status": "pending",
        "build_error_type": None,
        "build_errors": [],
        "build_log": "",
        "deploy_status": "pending",
        "deploy_errors": [],
        "deploy_log": "",
        "iteration": 0,
        "max_retries": 3,
        "execution_mode": "chat",
        "command": "chat",
        "command_args": {"initial_message": message} if message else {},
        "mode_metadata": None,
        "command_error": None,
        "log_file_path": None,
        "log_analysis_result": None,
        "firmware_path": None,
        "chat_completed": None,
        "config": None,
    }

    run_workflow(state)


def dashboard_command(
    open_browser: bool = typer.Option(False, "--open", "-o", help="Open dashboard in browser"),
):
    """
    🌐 Show or open FWAuto Dashboard.

    Examples:
        fwauto dashboard          # Show dashboard URL
        fwauto dashboard --open   # Open in browser
    """
    import webbrowser

    from ..auth import FWAUTO_SERVER_URL

    dashboard_url = f"{FWAUTO_SERVER_URL}/dashboard"

    console.print()
    console.print("🌐 FWAuto Dashboard")
    console.print("=" * 50)
    console.print(f"   URL: {dashboard_url}")
    console.print()

    if open_browser:
        console.print("[dim]Opening browser...[/dim]")
        webbrowser.open(dashboard_url)
    else:
        console.print("[dim]Tip: Use --open or -o to open browser directly[/dim]")
    console.print()


def help_command():
    """
    ❓ Show help information.

    Displays available commands, version, environment info, and API key status.

    Example:
        fwauto help
    """
    console.print(_get_help_info())


def _get_auth_status() -> str:
    """Get authentication status for display."""
    import json

    from ..auth import AUTH_CONFIG_FILE, get_user_token

    token = get_user_token()
    if not token:
        return "❌ Not logged in"

    # Try to get email from config
    try:
        if AUTH_CONFIG_FILE.exists():
            with open(AUTH_CONFIG_FILE, encoding="utf-8") as f:
                config = json.load(f)
                email = config.get("email", "")
                if email:
                    return f"✅ {email}"
    except Exception:
        pass

    return "✅ Logged in"


def _get_help_info() -> str:
    """Generate help information string.

    Returns formatted help text including:
    - Version
    - Available commands
    - Environment info (Python, platform, project path)
    - Auth status
    """
    import platform
    from importlib.metadata import version

    from ..auth import FWAUTO_SERVER_URL
    from ..config import find_project_root

    # Get version
    try:
        ver = version("fwauto")
    except Exception:
        ver = "unknown"

    # Get project root
    project_root = find_project_root()
    project_path = str(project_root) if project_root else "Not in a project directory"

    # Get auth status
    auth_status = _get_auth_status()

    # Build help text
    help_text = f"""🚀 FWAuto v{ver}

📋 Available Commands:
  build       🔨 Build firmware project
  deploy      📥 Deploy firmware to device
  log         📊 Analyze UART log files
  config      ⚙️ View or modify project configuration
  auth        🔐 Authentication (login/logout/status)
  rag         📚 RAG document management (upload/list/delete/search)
  dashboard   🌐 Show Dashboard URL
  help        ❓ Show this help message

💡 Run fwauto (no arguments) to enter interactive mode

🔧 Environment Info:
  Python:    {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}
  Platform:  {platform.system().lower()}
  Project:   {project_path}

🔐 Auth Status: {auth_status}
🌐 Dashboard: {FWAUTO_SERVER_URL}/dashboard"""

    return help_text


def enter_unified_chat_mode() -> None:
    """Enter unified chat interface mode.

    This replaces the old _interactive_mode() function.
    Uses chat_node for interactive conversation with slash command support.
    """
    from ..logging_config import get_logger

    logger = get_logger(__name__)

    try:
        from .config import ensure_project_initialized

        # 自動觸發專案初始化（如需要）
        project_root = ensure_project_initialized()
        if not project_root:
            console.print("[red]❌ Setup cancelled[/red]")
            sys.exit(1)

        console.print(f"[cyan]📁 Project: {project_root}[/cyan]")
        console.print("[cyan]💬 Entering chat mode (type /exit or Ctrl+D to quit)[/cyan]")
        console.print("[dim]Tip: Use /build, /deploy, /log to run commands[/dim]\n")

        # Load project configuration for language settings
        from ..config import load_project_config
        from ..graph import create_firmware_graph

        config = load_project_config(project_root)

        # Build initial state for chat mode
        state: FirmwareState = {
            "user_prompt": "",
            "project_root": str(project_root),
            "project_initialized": True,
            "execution_mode": "chat",
            "command": "chat",
            "command_args": {},
            "mode_metadata": {},
            "command_error": None,
            "build_status": "pending",
            "build_error_type": None,
            "build_errors": [],
            "build_log": "",
            "deploy_status": "pending",
            "deploy_errors": [],
            "deploy_log": "",
            "iteration": 0,
            "max_retries": 3,
            "log_file_path": None,
            "log_analysis_result": None,
            "firmware_path": None,
            "chat_completed": None,
            "config": config,
        }

        # Create and execute graph (which will route to chat_node)
        app_graph = create_firmware_graph()
        result = app_graph.invoke(state)

        logger.debug(f"💬 Chat: Graph result chat_completed = {result.get('chat_completed')}")
        if result.get("chat_completed"):
            console.print("\n[green]✅ Chat ended[/green]")
        else:
            console.print("\n[yellow]⚠️ Chat ended abnormally[/yellow]")

    except KeyboardInterrupt:
        # User pressed Ctrl+C, treat as normal exit
        console.print("\n[green]✅ Chat ended[/green]")

    except FileNotFoundError as e:
        console.print(f"[red]❌ Project not found: {e}[/red]")
        console.print("[yellow]Tip: Run this command in a FWAuto project directory (with .fwauto/)[/yellow]")
        sys.exit(1)

    except Exception as e:
        logger.error(f"Chat mode failed: {e}", exc_info=True)
        console.print(f"[red]❌ Failed to start chat mode: {e}[/red]")
        sys.exit(1)
