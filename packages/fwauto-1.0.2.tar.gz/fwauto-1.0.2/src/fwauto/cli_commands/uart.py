"""UART monitor CLI commands."""

import typer
from rich.console import Console

uart_app = typer.Typer(help="🔌 UART monitor commands")

console = Console()


@uart_app.command(name="start")
def uart_start():
    """
    ▶️ Start UART monitoring daemon.

    Starts a background daemon that monitors the serial port
    and writes received data to log files.

    The daemon has a 30-minute timeout and auto-restarts
    when any fwauto command is executed.

    Example:
        fwauto uart start
    """
    from ..config import find_project_root, load_project_config
    from ..uart_daemon import UartDaemon

    project_root = find_project_root()
    if not project_root:
        console.print("[red]❌ Not in a FWAuto project (no .fwauto/ found)[/red]")
        console.print("[yellow]Tip: Run 'fwauto build' or 'fwauto config' to initialize[/yellow]")
        raise typer.Exit(1)

    # Load config for serial port settings
    try:
        config = load_project_config(project_root)
        port = config.log_serial_port
        baudrate = config.log_baudrate
    except Exception as e:
        console.print(f"[red]❌ Failed to load config: {e}[/red]")
        raise typer.Exit(1)

    if not port:
        console.print("[red]❌ Serial port not configured[/red]")
        console.print("[yellow]Tip: Run 'fwauto config --log' to configure serial port[/yellow]")
        raise typer.Exit(1)

    daemon = UartDaemon(project_root)
    success = daemon.start(port, baudrate)

    if not success:
        raise typer.Exit(1)


@uart_app.command(name="stop")
def uart_stop():
    """
    ⏹️ Stop UART monitoring daemon.

    Example:
        fwauto uart stop
    """
    from ..config import find_project_root
    from ..uart_daemon import UartDaemon

    project_root = find_project_root()
    if not project_root:
        console.print("[red]❌ Not in a FWAuto project (no .fwauto/ found)[/red]")
        raise typer.Exit(1)

    daemon = UartDaemon(project_root)
    daemon.stop()


@uart_app.command(name="status")
def uart_status():
    """
    📊 Show UART daemon status.

    Displays daemon running state, PID, uptime, and log file info.

    Example:
        fwauto uart status
    """
    from ..config import find_project_root
    from ..uart_daemon import UartDaemon

    project_root = find_project_root()
    if not project_root:
        console.print("[red]❌ Not in a FWAuto project (no .fwauto/ found)[/red]")
        raise typer.Exit(1)

    daemon = UartDaemon(project_root)
    status = daemon.status()

    console.print("\n[cyan]🔌 UART Daemon Status[/cyan]")
    console.print("=" * 40)

    if status["running"]:
        console.print(f"[green]● Running[/green] (PID: {status['pid']})")

        if "uptime_seconds" in status:
            uptime = status["uptime_seconds"]
            minutes, seconds = divmod(uptime, 60)
            console.print(f"   Uptime: {minutes}m {seconds}s")

        if "start_time" in status:
            console.print(f"   Started: {status['start_time']}")
    else:
        console.print("[dim]○ Not running[/dim]")

    console.print(f"\n   PID file: {status['pid_file']}")
    console.print(f"   Log dir: {status['log_dir']}")

    if "latest_log" in status:
        size_kb = status.get("log_size", 0) / 1024
        console.print(f"   Latest log: {status['latest_log']} ({size_kb:.1f} KB)")

    console.print()


@uart_app.command(name="restart")
def uart_restart():
    """
    🔄 Restart UART monitoring daemon.

    Stops the daemon if running, then starts it again.
    Useful for resetting the 30-minute timeout.

    Example:
        fwauto uart restart
    """
    from ..config import find_project_root, load_project_config
    from ..uart_daemon import UartDaemon

    project_root = find_project_root()
    if not project_root:
        console.print("[red]❌ Not in a FWAuto project (no .fwauto/ found)[/red]")
        raise typer.Exit(1)

    # Load config for serial port settings
    try:
        config = load_project_config(project_root)
        port = config.log_serial_port
        baudrate = config.log_baudrate
    except Exception as e:
        console.print(f"[red]❌ Failed to load config: {e}[/red]")
        raise typer.Exit(1)

    if not port:
        console.print("[red]❌ Serial port not configured[/red]")
        console.print("[yellow]Tip: Run 'fwauto config --log' to configure serial port[/yellow]")
        raise typer.Exit(1)

    daemon = UartDaemon(project_root)
    success = daemon.restart(port, baudrate)

    if not success:
        raise typer.Exit(1)
