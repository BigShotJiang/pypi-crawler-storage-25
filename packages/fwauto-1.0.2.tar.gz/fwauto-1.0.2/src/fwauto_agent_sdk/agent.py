"""
核心 Agent - 透過 OpenAI Chat Completions API 格式與 LiteLLM Proxy 通訊

透過 FWAuto Server 的 /api/v1/chat/completions 端點，
經 LiteLLM 路由支援 Claude / Gemini / OpenAI 等多模型。
支援 Agentic Loop（工具呼叫循環）。
"""

import asyncio
import importlib.metadata
import json
import logging
import os
import platform
import time
import uuid
from collections.abc import AsyncIterator
from dataclasses import dataclass, field

import httpx

from .tools import TOOL_DEFINITIONS, ToolExecutor
from .types import (
    AgentMessage,
    AssistantMessage,
    ChatCompletionResponse,
)

# ============================================================================
# 預設配置
# ============================================================================

DEFAULT_MODEL = ""
DEFAULT_PROXY_URL = "https://fwauto-server-189969833984.asia-east1.run.app/api"
_PROCESS_SESSION_ID = str(uuid.uuid4())

try:
    _CLIENT_VERSION = importlib.metadata.version("fwauto") or "dev"
except (importlib.metadata.PackageNotFoundError, Exception):
    _CLIENT_VERSION = "dev"
_PYTHON_VERSION = platform.python_version()
_CLIENT_OS = platform.system()

logger = logging.getLogger(__name__)


# ============================================================================
# Exceptions
# ============================================================================


class ContextWindowExceededError(RuntimeError):
    """Server 回報 context window 超出限制"""

    pass


def _is_context_window_error(error_text: str) -> bool:
    """
    判斷 API 錯誤是否為 context window 超出限制。

    涵蓋多種後端格式：
    - Anthropic 原生：error.type == "context_window_exceeded"
    - LiteLLM / Vertex AI：訊息含 "exceeds the model's maximum context length"
    - 其他 proxy：訊息含 "context_window_exceeded"
    """
    lower = error_text.lower()
    return (
        "context_window_exceeded" in lower
        or "contextwindowexceeded" in lower
        or "exceeds the model's maximum context length" in lower
        or "requested token count exceeds" in lower
    )


def _detect_context_window_error(error_text: str) -> None:
    """偵測 context window 錯誤，有的話 raise ContextWindowExceededError。"""
    # 嘗試 JSON 結構化偵測
    try:
        error_data = json.loads(error_text)
        error_type = error_data.get("error", {}).get("type", "")
        error_msg = error_data.get("error", {}).get("message", "")
        if error_type == "context_window_exceeded" or _is_context_window_error(error_msg):
            raise ContextWindowExceededError(error_msg or error_text)
    except ContextWindowExceededError:
        raise
    except (json.JSONDecodeError, ValueError):
        pass
    # 純字串 fallback（JSON 解析失敗時）
    if _is_context_window_error(error_text):
        raise ContextWindowExceededError(error_text)


# ============================================================================
# 對話歷史壓縮（漸進式多級策略 v2）
#
# 設計原則：便宜確定的手段先做，昂貴有風險的手段後做
#   L0：截斷超長 message content（不分 role，零成本）
#   L1：移除舊輪次細節，保留最近 3 輪（支援 tool rounds + 純 Q&A）
#   L2：縮減到保留最近 1 輪
#   L3：暴力截斷所有 message 到 2K（最後手段）
# ============================================================================

# 截斷時保留頭尾各多少字元
_TRUNCATE_HEAD = 2000
_TRUNCATE_TAIL = 2000

# 各 role 的截斷門檻（assistant 資訊密度高，門檻拉高）
_THRESHOLD_USER = 8000
_THRESHOLD_TOOL = 8000
_THRESHOLD_ASSISTANT = 16000

# L3 暴力截斷的上限
_BRUTAL_MAX = 2000


def _truncate_content(content: str, head: int = _TRUNCATE_HEAD, tail: int = _TRUNCATE_TAIL) -> str:
    """截斷超長文字，保留頭尾。"""
    if len(content) <= head + tail + 200:
        return content
    omitted = len(content) - head - tail
    return content[:head] + f"\n\n... [{omitted} chars omitted to save context] ...\n\n" + content[-tail:]


def _get_threshold(msg: dict) -> int:
    """根據 message role 回傳對應的截斷門檻。"""
    role = msg.get("role", "")
    if role == "assistant":
        return _THRESHOLD_ASSISTANT
    if role == "tool":
        return _THRESHOLD_TOOL
    return _THRESHOLD_USER


# ---------------------------------------------------------------------------
# 輪次偵測（同時支援 tool rounds 和純 Q&A rounds）
# ---------------------------------------------------------------------------


def _find_conversation_rounds(messages: list[dict]) -> list[tuple[int, int]]:
    """
    掃描訊息列表，找出每一輪對話的索引範圍。

    一輪的定義：
    - Tool round：assistant（含 tool_calls）+ 後續所有 tool results
    - Q&A round：user + assistant（無 tool_calls）

    Returns:
        list of (start_idx, end_idx) inclusive，按出現順序排列
    """
    rounds: list[tuple[int, int]] = []
    i = 0
    while i < len(messages):
        msg = messages[i]
        role = msg.get("role", "")

        # Tool round：assistant 帶 tool_calls + 後續 tool results
        if role == "assistant" and msg.get("tool_calls"):
            start = i
            j = i + 1
            while j < len(messages) and messages[j].get("role") == "tool":
                j += 1
            rounds.append((start, j - 1))
            i = j
            continue

        # Q&A round：user + 下一個 assistant（無 tool_calls）
        if role == "user":
            j = i + 1
            if j < len(messages) and messages[j].get("role") == "assistant" and not messages[j].get("tool_calls"):
                rounds.append((i, j))
                i = j + 1
                continue

        i += 1

    return rounds


def _summarize_round(messages: list[dict], start: int, end: int) -> list[dict]:
    """
    將一輪對話壓縮為一條 assistant 摘要訊息。

    Tool round：列出呼叫的工具名稱
    Q&A round：保留 user 問題前 100 chars + assistant 回覆前 200 chars
    """
    first = messages[start]

    # Tool round
    if first.get("role") == "assistant" and first.get("tool_calls"):
        text = first.get("content") or ""
        tool_names = [tc.get("function", {}).get("name", "?") for tc in first.get("tool_calls", [])]
        summary = f"[Earlier tool calls: {', '.join(tool_names)} — results omitted to save context]"
        return [
            {
                "role": "assistant",
                "content": f"{text}\n{summary}" if text else summary,
            }
        ]

    # Q&A round
    user_text = (first.get("content") or "")[:100]
    assistant_text = ""
    if end > start:
        assistant_text = (messages[end].get("content") or "")[:200]
    summary = f'[Earlier Q&A: user asked: "{user_text}" — AI responded: "{assistant_text}..."]'
    return [{"role": "assistant", "content": summary}]


# ---------------------------------------------------------------------------
# L0：截斷所有超長 message content
# ---------------------------------------------------------------------------


def _compress_level0(messages: list[dict]) -> tuple[list[dict], bool]:
    """
    Level 0：截斷所有超長 message content（不分 role）。
    user/tool > 8K, assistant > 16K 時截斷，保留頭尾各 2K。
    Message 結構（role、tool_call_id、tool_calls）完整保留。
    """
    did_truncate = False
    compressed = []
    for msg in messages:
        content = msg.get("content")
        if isinstance(content, str):
            threshold = _get_threshold(msg)
            if len(content) > threshold:
                truncated = _truncate_content(content)
                compressed.append({**msg, "content": truncated})
                did_truncate = True
                continue
        compressed.append(msg)

    if did_truncate:
        logger.info(
            "Compress L0: truncated long message contents "
            f"(user/tool>{_THRESHOLD_USER}, assistant>{_THRESHOLD_ASSISTANT})"
        )
    return compressed, did_truncate


# ---------------------------------------------------------------------------
# L1：移除舊輪次細節，保留最近 3 輪
# ---------------------------------------------------------------------------


def _compress_level1(messages: list[dict]) -> tuple[list[dict], bool]:
    """
    Level 1：移除舊輪次細節，保留最近 3 輪完整。
    同時支援 tool rounds 和純 Q&A rounds。
    """
    rounds = _find_conversation_rounds(messages)
    keep = 3
    if len(rounds) <= keep:
        return messages, False

    old_rounds = rounds[:-keep]
    replace_ranges: list[tuple[int, int]] = [(s, e) for s, e in old_rounds]
    indices_in_old: set[int] = set()
    for s, e in replace_ranges:
        for idx in range(s, e + 1):
            indices_in_old.add(idx)

    compressed = []
    i = 0
    while i < len(messages):
        if i in indices_in_old:
            for s, e in replace_ranges:
                if i == s:
                    compressed.extend(_summarize_round(messages, s, e))
                    break
            i += 1
        else:
            compressed.append(messages[i])
            i += 1

    removed = len(messages) - len(compressed)
    logger.info(
        f"Compress L1: condensed {len(old_rounds)} old rounds into summaries, "
        f"removed {removed} msgs, keeping {keep} recent rounds"
    )
    return compressed, True


# ---------------------------------------------------------------------------
# L2：只保留最近 1 輪
# ---------------------------------------------------------------------------


def _compress_level2(messages: list[dict]) -> tuple[list[dict], bool]:
    """
    Level 2：只保留最近 1 輪完整，其餘全部壓縮為摘要。
    """
    rounds = _find_conversation_rounds(messages)
    keep = 1
    if len(rounds) <= keep:
        return messages, False

    old_rounds = rounds[:-keep]
    indices_in_old: set[int] = set()
    replace_ranges: list[tuple[int, int]] = [(s, e) for s, e in old_rounds]
    for s, e in replace_ranges:
        for idx in range(s, e + 1):
            indices_in_old.add(idx)

    compressed = []
    i = 0
    while i < len(messages):
        if i in indices_in_old:
            for s, e in replace_ranges:
                if i == s:
                    compressed.extend(_summarize_round(messages, s, e))
                    break
            i += 1
        else:
            compressed.append(messages[i])
            i += 1

    removed = len(messages) - len(compressed)
    logger.info(
        f"Compress L2: condensed {len(old_rounds)} old rounds, "
        f"removed {removed} msgs, keeping {keep} recent round"
    )
    return compressed, True


# ---------------------------------------------------------------------------
# L3：暴力截斷所有 message
# ---------------------------------------------------------------------------


def _compress_level3(messages: list[dict]) -> tuple[list[dict], bool]:
    """
    Level 3（最後手段）：暴力截斷所有 message content 到 2K chars。
    保證 token 數一定能大幅降低。
    """
    did_truncate = False
    compressed = []
    for msg in messages:
        content = msg.get("content")
        if isinstance(content, str) and len(content) > _BRUTAL_MAX:
            truncated = _truncate_content(content, head=1000, tail=1000)
            compressed.append({**msg, "content": truncated})
            did_truncate = True
        else:
            compressed.append(msg)

    if did_truncate:
        logger.info(f"Compress L3: brutally truncated all messages to {_BRUTAL_MAX} chars")
    return compressed, did_truncate


# ---------------------------------------------------------------------------
# 漸進式壓縮調度器
# ---------------------------------------------------------------------------


def _compress_messages(messages: list[dict], level: int = 0) -> tuple[list[dict], bool]:
    """
    漸進式多級壓縮對話歷史。

    Level 0：截斷所有超長 message content（user/tool>8K, assistant>16K）
    Level 1：移除舊輪次細節（保留最近 3 輪），支援 tool rounds + 純 Q&A
    Level 2：縮小保留到最近 1 輪
    Level 3：暴力截斷所有 message 到 2K chars（最後手段）

    Args:
        messages: 對話訊息列表（不含 system）
        level: 壓縮等級（0-3）

    Returns:
        (compressed_messages, did_compress)
    """
    if len(messages) <= 2:
        return messages, False

    if level == 0:
        return _compress_level0(messages)
    elif level == 1:
        return _compress_level1(messages)
    elif level == 2:
        return _compress_level2(messages)
    elif level >= 3:
        return _compress_level3(messages)

    return messages, False


def _progressive_compress(messages: list[dict]) -> list[dict] | None:
    """
    從 Level 0 到 3 依序嘗試壓縮，回傳第一個成功壓縮的結果。
    全部都無法壓縮時回傳 None。
    """
    for level in range(0, 4):
        compressed, did = _compress_messages(messages, level=level)
        if did:
            return compressed
    return None


# ============================================================================
# AI API Logging helpers
# ============================================================================


def _build_api_headers(api_key: str, options: "ClaudeAgentOptions") -> dict[str, str]:
    """Build HTTP headers for LLM API requests with client metadata."""
    headers = {
        "x-fwauto-token": api_key,
        "Content-Type": "application/json",
        "X-FWAuto-Version": _CLIENT_VERSION,
        "X-FWAuto-Python-Version": _PYTHON_VERSION,
        "X-FWAuto-OS": _CLIENT_OS,
        "X-FWAuto-Source": options.source,
        "X-FWAuto-Session-ID": options.session_id,
    }
    # 確保所有 header 值都是字串（避免 None 導致 httpx 報錯）
    return {k: v or "" for k, v in headers.items()}


def _build_request_ai_data(options: "ClaudeAgentOptions", iteration: int, messages: list[dict]) -> dict:
    """Build ai_data dict for REQUEST log."""
    ai_data: dict = {
        "type": "REQUEST",
        "session_id": options.session_id,
        "source": options.source,
        "iteration": iteration,
        "model": options.model,
        "max_tokens": options.max_tokens,
    }
    if iteration == 1:
        for msg in reversed(messages):
            if msg.get("role") == "user":
                content = msg.get("content", "")
                ai_data["user_input"] = content[:500] if isinstance(content, str) else str(content)[:500]
                break
    else:
        tool_results = []
        for msg in messages:
            if msg.get("role") == "tool":
                tool_results.append(
                    {
                        "tool_call_id": msg.get("tool_call_id", ""),
                        "name": msg.get("name", ""),
                        "content_length": len(msg.get("content", "")),
                    }
                )
        if tool_results:
            ai_data["tool_results"] = tool_results[-5:]
    return ai_data


def _build_response_ai_data(
    options: "ClaudeAgentOptions",
    iteration: int,
    response: "ChatCompletionResponse",
    duration_ms: int,
    status_code: int,
) -> dict:
    """Build ai_data dict for successful RESPONSE log."""
    ai_data: dict = {
        "type": "RESPONSE",
        "session_id": options.session_id,
        "source": options.source,
        "iteration": iteration,
        "status": "success",
        "status_code": status_code,
        "model": response.model or options.model,
        "duration_ms": duration_ms,
    }
    if response.usage:
        ai_data["prompt_tokens"] = response.usage.prompt_tokens
        ai_data["completion_tokens"] = response.usage.completion_tokens
        ai_data["total_tokens"] = response.usage.total_tokens
    local_tool_calls = response.get_local_tool_calls()
    ai_data["tool_calls"] = _summarize_tool_calls(local_tool_calls) if local_tool_calls else []
    return ai_data


# Keys worth capturing per tool for token tracking
_TOOL_KEY_ARGS: dict[str, list[str]] = {
    "Read": ["file_path"],
    "Edit": ["file_path"],
    "Write": ["file_path"],
    "Grep": ["pattern", "path", "glob"],
    "Glob": ["pattern", "path"],
    "Bash": ["command"],
    "WebFetch": ["url"],
}


def _summarize_tool_calls(tool_calls: list) -> list[dict[str, str]]:
    """Extract tool name + key arguments for logging."""
    summaries = []
    for tc in tool_calls:
        entry: dict[str, str] = {"name": tc.function.name}
        keys = _TOOL_KEY_ARGS.get(tc.function.name)
        if keys:
            try:
                args = tc.function.get_parsed_arguments()
                for k in keys:
                    if k in args:
                        val = str(args[k])
                        if len(val) > 200:
                            val = val[:200] + "..."
                        entry[k] = val
            except Exception:
                pass
        summaries.append(entry)
    return summaries


def _build_error_ai_data(
    options: "ClaudeAgentOptions",
    iteration: int,
    status_code: int,
    error_text: str,
    duration_ms: int,
) -> dict:
    """Build ai_data dict for error RESPONSE log."""
    return {
        "type": "RESPONSE",
        "session_id": options.session_id,
        "source": options.source,
        "iteration": iteration,
        "status": "error",
        "status_code": status_code,
        "error": f"API error ({status_code}): {error_text[:500]}",
        "duration_ms": duration_ms,
    }


def _get_ai_logger() -> logging.Logger:
    """Get the AI API logger."""
    return logging.getLogger("fwauto.ai")


# ============================================================================
# ClaudeAgentOptions - 與 claude_agent_sdk 相容
# ============================================================================


@dataclass
class ClaudeAgentOptions:
    """
    Agent 設定（相容 claude_agent_sdk.ClaudeAgentOptions）

    用法：
        options = ClaudeAgentOptions(
            cwd="/path/to/project",
            permission_mode="bypassPermissions",
        )

    多輪對話用法：
        # 第一輪
        agent = Agent(options)
        async for msg in agent.run("你好"):
            print(msg)

        # 第二輪（傳入歷史）
        options.messages = agent.get_messages()
        async for msg in agent.run("繼續剛才的話題"):
            print(msg)
    """

    # 工具與權限
    allowed_tools: list[str] = field(
        default_factory=lambda: ["Read", "Write", "Edit", "MultiEdit", "Glob", "Grep", "Bash", "WebFetch"]
    )
    permission_mode: str = "default"  # "default" | "bypassPermissions"
    add_dirs: list[str] = field(default_factory=list)
    cwd: str | None = None
    env: dict[str, str] | None = None

    # 對話上下文
    messages: list[dict] | None = None  # 傳入歷史對話以延續多輪對話

    # 模型與 API
    model: str = DEFAULT_MODEL
    api_key: str | None = None
    base_url: str | None = None
    system_prompt: str | None = None
    max_iterations: int = 20
    timeout: int = 300
    max_tokens: int = 4096
    temperature: float | None = None

    # Web Search（透過 web_search_options 參數，不走 tools）
    web_search: bool = False
    search_context_size: str = "medium"  # "low" / "medium" / "high"

    # AI API logging
    source: str = "unknown"
    session_id: str = field(default_factory=lambda: _PROCESS_SESSION_ID)

    def get_api_key(self) -> str:
        """
        取得 FWAuto Token

        優先順序：
        1. 直接設定的 api_key
        2. env 中的 FWAUTO_TOKEN
        3. 環境變數 FWAUTO_TOKEN
        4. env 中的 ANTHROPIC_API_KEY（舊版 fallback）
        5. 環境變數 ANTHROPIC_API_KEY（舊版 fallback）
        """
        if self.api_key:
            return self.api_key
        if self.env and "FWAUTO_TOKEN" in self.env:
            return self.env["FWAUTO_TOKEN"]
        token = os.environ.get("FWAUTO_TOKEN")
        if token:
            return token
        # 舊版 fallback
        if self.env and "ANTHROPIC_API_KEY" in self.env:
            return self.env["ANTHROPIC_API_KEY"]
        return os.environ.get("ANTHROPIC_API_KEY", "")

    def get_base_url(self) -> str:
        """
        取得 API Base URL

        優先順序：
        1. 直接設定的 base_url
        2. env 中的 FWAUTO_BASE_URL
        3. 環境變數 FWAUTO_BASE_URL
        4. env 中的 ANTHROPIC_BASE_URL（舊版 fallback）
        5. 環境變數 ANTHROPIC_BASE_URL（舊版 fallback）
        6. DEFAULT_PROXY_URL
        """
        if self.base_url:
            return self.base_url
        if self.env and "FWAUTO_BASE_URL" in self.env:
            return self.env["FWAUTO_BASE_URL"]
        url = os.environ.get("FWAUTO_BASE_URL")
        if url:
            return url
        # 舊版 fallback
        if self.env and "ANTHROPIC_BASE_URL" in self.env:
            return self.env["ANTHROPIC_BASE_URL"]
        return os.environ.get("ANTHROPIC_BASE_URL") or DEFAULT_PROXY_URL


# ============================================================================
# Agent 核心
# ============================================================================


class Agent:
    """
    核心 Agent

    透過 OpenAI Chat Completions API 格式與 LiteLLM Proxy 通訊，
    支援 Agentic Loop（工具呼叫循環）和多輪對話。

    多輪對話用法：
        agent = Agent(options)

        # 第一輪對話
        async for msg in agent.run("讀取 README.md"):
            print(msg)

        # 第二輪對話（自動保留上下文）
        async for msg in agent.run("幫我修改剛才那個檔案"):
            print(msg)

        # 取得完整對話歷史
        history = agent.get_messages()
    """

    def __init__(self, options: ClaudeAgentOptions):
        self.options = options
        self.project_root = options.cwd or "."
        self.tool_executor = ToolExecutor(
            project_root=self.project_root,
            allowed_dirs=options.add_dirs or [self.project_root],
        )
        self._iteration = 0
        # 對話歷史：如果 options 有傳入就用，否則建立新的
        self._messages: list[dict] = list(options.messages) if options.messages else []

    def _get_system_prompt(self) -> str:
        """取得系統提示詞"""
        if self.options.system_prompt:
            return self.options.system_prompt

        return f"""You are a software development assistant.
You can read, write, and edit code files, and execute shell commands.
Project directory: {self.project_root}

Use the provided tools when working with files.
Read file contents before editing to understand context.
Be cautious when executing commands and avoid dangerous operations."""

    def _get_tools(self) -> list[dict] | None:
        """
        取得啟用的工具定義（OpenAI Function Calling 格式）

        WebSearch 不再作為 tool，改用 request body 的 web_search_options 參數
        """
        allowed = set(self.options.allowed_tools)
        tools = []

        for t in TOOL_DEFINITIONS:
            if t["name"] in allowed:
                tools.append(
                    {
                        "type": "function",
                        "function": {
                            "name": t["name"],
                            "description": t["description"],
                            "parameters": t["input_schema"],
                        },
                    }
                )

        return tools if tools else None

    def _build_messages(self, messages: list[dict]) -> list[dict]:
        """
        在 messages 最前面插入 system message

        OpenAI 格式把 system prompt 放在 messages 陣列第一個，
        而非 Anthropic 的頂層 system 參數。
        """
        system_msg = {"role": "system", "content": self._get_system_prompt()}
        return [system_msg] + messages

    async def run(self, prompt: str) -> AsyncIterator[AgentMessage]:
        """
        執行 Agent

        支援多輪對話：同一個 Agent 實例可以多次呼叫 run()，
        會自動保留對話歷史。

        Args:
            prompt: 使用者輸入

        Yields:
            AgentMessage 物件
        """
        self._iteration = 0
        self._messages.append({"role": "user", "content": prompt})
        messages = self._messages
        _compress_level = -1  # 目前壓縮等級（-1=未壓縮，0-3=對應 L0-L3）

        while self._iteration < self.options.max_iterations:
            self._iteration += 1
            # 只在第一輪帶 web_search，後續工具回合不帶
            is_first_round = self._iteration == 1

            try:
                response = await self._call_api(messages, include_web_search=is_first_round)
            except ContextWindowExceededError as e:
                # 漸進式壓縮：從目前等級往上找到能壓縮的等級
                compressed = None
                while _compress_level < 3:
                    _compress_level += 1
                    result, did = _compress_messages(messages, level=_compress_level)
                    if did:
                        compressed = result
                        break
                if compressed is None:
                    err = f"Context window exceeded (exhausted all compression levels): {e}"
                    yield AgentMessage(type="error", content=err)
                    return
                messages.clear()
                messages.extend(compressed)
                yield AgentMessage(
                    type="text",
                    content=f"⚠️ Context window exceeded, compressing history (level {_compress_level}) and retrying...",
                )
                self._iteration -= 1  # 不算這次失敗的迭代
                continue
            except httpx.TimeoutException:
                yield AgentMessage(
                    type="error",
                    content="Request timed out — the AI model is taking too long to respond. "
                    "Try shorter input or a different model.",
                )
                return
            except Exception as e:
                yield AgentMessage(type="error", content=str(e))
                return

            # 輸出文字內容
            text_content = response.get_text()
            if text_content:
                yield AgentMessage(type="text", content=text_content)

            # 取得需要本地執行的工具呼叫（過濾掉 web_search）
            local_tool_calls = response.get_local_tool_calls()

            if not local_tool_calls:
                # 沒有工具呼叫，加入 assistant 訊息並完成
                messages.append(response.to_assistant_message_dict())
                return

            # 有工具呼叫，加入 assistant 訊息（含 tool_calls）
            messages.append(response.to_assistant_message_dict())

            # 逐一執行工具並加入 tool result messages
            for tool_call in local_tool_calls:
                name = tool_call.function.name
                args = tool_call.function.get_parsed_arguments()

                yield AgentMessage(
                    type="tool_use",
                    tool_name=name,
                    tool_input=args,
                )

                result = await self.tool_executor.execute(name, args)

                yield AgentMessage(
                    type="tool_result",
                    tool_name=name,
                    tool_result=result,
                )

                # OpenAI 格式：每個 tool result 是獨立的 message
                messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": tool_call.id,
                        "name": name,
                        "content": result,
                    }
                )

        yield AgentMessage(type="error", content=f"達到迭代上限 ({self.options.max_iterations})")

    async def _call_api(self, messages: list[dict], include_web_search: bool = True) -> ChatCompletionResponse:
        """呼叫 OpenAI Chat Completions API

        Args:
            messages: 對話訊息
            include_web_search: 是否帶 web_search_options（只在第一輪帶，後續工具回合不帶）
        """
        ai_logger = _get_ai_logger()

        api_key = self.options.get_api_key()
        base_url = self.options.get_base_url()

        if not api_key:
            raise RuntimeError("未設定 API Token (FWAUTO_TOKEN 或 ANTHROPIC_API_KEY)")

        api_url = base_url.rstrip("/") + "/v1/chat/completions"

        # 組裝 request body（OpenAI 格式）
        request_body: dict = {
            "model": self.options.model,
            "messages": self._build_messages(messages),
            "max_tokens": self.options.max_tokens,
        }

        # 工具定義（有工具才傳）
        tools = self._get_tools()
        if tools:
            request_body["tools"] = tools

        # 可選參數
        if self.options.temperature is not None:
            request_body["temperature"] = self.options.temperature

        # Web Search — 只在第一輪帶，後續工具回合不帶（避免非 Claude 模型每輪多一次搜尋）
        if self.options.web_search and include_web_search:
            request_body["web_search_options"] = {
                "search_context_size": self.options.search_context_size,
            }

        headers = _build_api_headers(api_key, self.options)

        # Log REQUEST
        if ai_logger.handlers:
            req_data = _build_request_ai_data(self.options, self._iteration, messages)
            if ai_logger.isEnabledFor(logging.DEBUG):
                req_data["headers"] = {k: v for k, v in headers.items() if k != "x-fwauto-token"}
                req_data["body"] = request_body
            ai_logger.info("", extra={"ai_data": req_data})

        start_time = time.monotonic()

        async with httpx.AsyncClient(timeout=self.options.timeout) as client:
            response = await client.post(api_url, headers=headers, json=request_body)

            duration_ms = int((time.monotonic() - start_time) * 1000)

            if response.status_code != 200:
                error_text = response.text
                # Log error RESPONSE
                if ai_logger.handlers:
                    ai_logger.log(
                        logging.WARNING if response.status_code == 429 else logging.ERROR,
                        "",
                        extra={
                            "ai_data": _build_error_ai_data(
                                self.options,
                                self._iteration,
                                response.status_code,
                                error_text,
                                duration_ms,
                            )
                        },
                    )
                # 偵測 context window exceeded
                _detect_context_window_error(error_text)
                raise RuntimeError(f"API error ({response.status_code}): {error_text}")

            data = response.json()
            result = ChatCompletionResponse.from_dict(data)

            # Log success RESPONSE
            if ai_logger.handlers:
                resp_data = _build_response_ai_data(
                    self.options,
                    self._iteration,
                    result,
                    duration_ms,
                    response.status_code,
                )
                if ai_logger.isEnabledFor(logging.DEBUG):
                    resp_data["body"] = data
                ai_logger.info("", extra={"ai_data": resp_data})

            return result

    def get_messages(self) -> list[dict]:
        """
        取得完整對話歷史

        Returns:
            對話訊息列表
        """
        return list(self._messages)

    def clear_messages(self):
        """清除對話歷史"""
        self._messages.clear()

    @property
    def message_count(self) -> int:
        """取得目前對話訊息數量"""
        return len(self._messages)

    @property
    def turn_count(self) -> int:
        """取得目前對話輪數（使用者訊息數量）"""
        return len([m for m in self._messages if m.get("role") == "user"])


# ============================================================================
# query() 函數 - 與 claude_agent_sdk 相容
# ============================================================================


async def query(
    *,
    prompt: str,
    options: ClaudeAgentOptions | None = None,
) -> AsyncIterator[AgentMessage]:
    """
    與 claude_agent_sdk.query 相容的介面

    用法：
        async for message in query(prompt="修復 bug", options=options):
            print(message)

    Args:
        prompt: 使用者輸入
        options: 設定選項

    Yields:
        AgentMessage 物件
    """
    opts = options or ClaudeAgentOptions()
    agent = Agent(opts)

    async for message in agent.run(prompt):
        yield message


def run_query(
    *,
    prompt: str,
    options: ClaudeAgentOptions | None = None,
) -> list[str]:
    """
    同步版本的 query

    Args:
        prompt: 使用者輸入
        options: 設定選項

    Returns:
        回應字串列表
    """

    async def _run():
        results = []
        async for msg in query(prompt=prompt, options=options):
            results.append(str(msg))
        return results

    return asyncio.run(_run())


# ============================================================================
# 便利函數
# ============================================================================


def create_options(
    project_dir: str,
    api_key: str | None = None,
    base_url: str | None = None,
    model: str = DEFAULT_MODEL,
    bypass_permissions: bool = True,
) -> ClaudeAgentOptions:
    """
    建立選項的便利函數

    Args:
        project_dir: 專案目錄
        api_key: API Key
        base_url: Proxy URL
        model: 模型名稱
        bypass_permissions: 是否跳過權限確認

    Returns:
        ClaudeAgentOptions 物件
    """
    return ClaudeAgentOptions(
        cwd=project_dir,
        api_key=api_key,
        base_url=base_url,
        model=model,
        permission_mode="bypassPermissions" if bypass_permissions else "default",
    )


# ============================================================================
# ClaudeSDKClient - 與 claude_agent_sdk.ClaudeSDKClient 相容
# ============================================================================


class ClaudeSDKClient:
    """
    與 claude_agent_sdk.ClaudeSDKClient 相容的客戶端

    用於持續對話，支援 async context manager。

    用法：
        async with ClaudeSDKClient(options=options) as client:
            await client.connect()
            await client.query("你好")
            async for msg in client.receive_response():
                print(msg)

    或不使用 context manager：
        client = ClaudeSDKClient(options=options)
        await client.connect()
        await client.query("你好")
        async for msg in client.receive_response():
            print(msg)
        await client.disconnect()
    """

    def __init__(self, options: ClaudeAgentOptions | None = None):
        """
        初始化客戶端

        Args:
            options: 設定選項
        """
        self.options = options or ClaudeAgentOptions()
        self.project_root = self.options.cwd or "."
        self.tool_executor = ToolExecutor(
            project_root=self.project_root,
            allowed_dirs=self.options.add_dirs or [self.project_root],
        )
        self._messages: list[dict] = []
        self._connected = False
        self._pending_response: ChatCompletionResponse | None = None
        self._http_client: httpx.AsyncClient | None = None
        self._iteration = 0

    async def __aenter__(self) -> "ClaudeSDKClient":
        """Async context manager entry"""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit"""
        await self.disconnect()

    async def connect(self, prompt: str | None = None) -> None:
        """
        連接到 LLM

        Args:
            prompt: 可選的初始提示詞
        """
        self._http_client = httpx.AsyncClient(timeout=self.options.timeout)
        self._connected = True

        if prompt:
            await self.query(prompt)

    async def disconnect(self) -> None:
        """斷開連接"""
        if self._http_client:
            await self._http_client.aclose()
            self._http_client = None
        self._connected = False

    async def query(self, prompt: str, session_id: str = "default") -> None:
        """
        發送查詢

        Args:
            prompt: 使用者輸入
            session_id: 會話 ID（目前未使用，保留相容性）
        """
        if not self._connected:
            raise RuntimeError("Client not connected. Call connect() first.")

        self._iteration = 0
        # 加入使用者訊息
        self._messages.append({"role": "user", "content": prompt})
        self._iteration += 1

        # 呼叫 API（第一輪帶 web_search），context window 超出時漸進式壓縮重試
        try:
            self._pending_response = await self._call_api(include_web_search=True)
        except httpx.TimeoutException:
            raise RuntimeError(
                "Request timed out — the AI model is taking too long to respond. "
                "Try shorter input or a different model."
            )
        except ContextWindowExceededError:
            compressed = _progressive_compress(self._messages)
            if compressed is None:
                raise
            self._messages.clear()
            self._messages.extend(compressed)
            logger.info("Context window exceeded on query, retrying after compression")
            self._pending_response = await self._call_api(include_web_search=True)

    async def receive_response(self) -> AsyncIterator[AssistantMessage]:
        """
        接收回應

        Yields:
            AssistantMessage 物件
        """
        if not self._pending_response:
            return

        response = self._pending_response
        self._pending_response = None

        # 處理 Agentic Loop
        while True:
            # 產生 AssistantMessage
            assistant_msg = AssistantMessage.from_response(response)
            yield assistant_msg

            # 檢查是否有需要本地執行的工具呼叫
            local_tool_calls = response.get_local_tool_calls()
            if not local_tool_calls:
                # 沒有工具呼叫，加入 assistant 訊息並完成
                self._messages.append(response.to_assistant_message_dict())
                return

            # 加入 assistant 訊息（含 tool_calls）
            self._messages.append(response.to_assistant_message_dict())

            # 執行工具並加入 tool result messages
            for tool_call in local_tool_calls:
                name = tool_call.function.name
                args = tool_call.function.get_parsed_arguments()
                result = await self.tool_executor.execute(name, args)

                # OpenAI 格式：每個 tool result 是獨立的 message
                self._messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": tool_call.id,
                        "name": name,
                        "content": result,
                    }
                )

            # 繼續呼叫 API（後續工具回合不帶 web_search），context window 超出時漸進式壓縮重試
            self._iteration += 1
            try:
                response = await self._call_api(include_web_search=False)
            except httpx.TimeoutException:
                raise RuntimeError(
                    "Request timed out — the AI model is taking too long to respond. "
                "Try shorter input or a different model."
                )
            except ContextWindowExceededError:
                compressed = _progressive_compress(self._messages)
                if compressed is None:
                    raise
                self._messages.clear()
                self._messages.extend(compressed)
                logger.info("Context window exceeded in agentic loop, retrying after compression")
                response = await self._call_api(include_web_search=False)

    async def receive_messages(self) -> AsyncIterator[AssistantMessage]:
        """
        接收所有訊息（別名，與 claude_agent_sdk 相容）

        Yields:
            AssistantMessage 物件
        """
        async for msg in self.receive_response():
            yield msg

    async def interrupt(self) -> None:
        """
        中斷當前操作

        目前實作為清除 pending response
        """
        self._pending_response = None

    def _get_system_prompt(self) -> str:
        """取得系統提示詞"""
        if self.options.system_prompt:
            return self.options.system_prompt

        return f"""You are a software development assistant.
You can read, write, and edit code files, and execute shell commands.
Project directory: {self.project_root}

Use the provided tools when working with files.
Read file contents before editing to understand context.
Be cautious when executing commands and avoid dangerous operations."""

    def _get_tools(self) -> list[dict] | None:
        """
        取得啟用的工具定義（OpenAI Function Calling 格式）

        WebSearch 不再作為 tool，改用 request body 的 web_search_options 參數
        """
        allowed = set(self.options.allowed_tools)
        tools = []

        for t in TOOL_DEFINITIONS:
            if t["name"] in allowed:
                tools.append(
                    {
                        "type": "function",
                        "function": {
                            "name": t["name"],
                            "description": t["description"],
                            "parameters": t["input_schema"],
                        },
                    }
                )

        return tools if tools else None

    def _build_messages(self) -> list[dict]:
        """在 messages 最前面插入 system message"""
        system_msg = {"role": "system", "content": self._get_system_prompt()}
        return [system_msg] + self._messages

    async def _call_api(self, include_web_search: bool = True) -> ChatCompletionResponse:
        """呼叫 OpenAI Chat Completions API"""
        ai_logger = _get_ai_logger()

        api_key = self.options.get_api_key()
        base_url = self.options.get_base_url()

        if not api_key:
            raise RuntimeError("未設定 API Token (FWAUTO_TOKEN 或 ANTHROPIC_API_KEY)")

        if not self._http_client:
            raise RuntimeError("HTTP client not initialized")

        api_url = base_url.rstrip("/") + "/v1/chat/completions"

        # 組裝 request body（OpenAI 格式）
        request_body: dict = {
            "model": self.options.model,
            "messages": self._build_messages(),
            "max_tokens": self.options.max_tokens,
        }

        # 工具定義（有工具才傳）
        tools = self._get_tools()
        if tools:
            request_body["tools"] = tools

        # 可選參數
        if self.options.temperature is not None:
            request_body["temperature"] = self.options.temperature

        # Web Search — 只在第一輪帶，後續工具回合不帶
        if self.options.web_search and include_web_search:
            request_body["web_search_options"] = {
                "search_context_size": self.options.search_context_size,
            }

        headers = _build_api_headers(api_key, self.options)

        # Log REQUEST
        if ai_logger.handlers:
            req_data = _build_request_ai_data(self.options, self._iteration, self._messages)
            if ai_logger.isEnabledFor(logging.DEBUG):
                req_data["headers"] = {k: v for k, v in headers.items() if k != "x-fwauto-token"}
                req_data["body"] = request_body
            ai_logger.info("", extra={"ai_data": req_data})

        start_time = time.monotonic()

        response = await self._http_client.post(
            api_url,
            headers=headers,
            json=request_body,
        )

        duration_ms = int((time.monotonic() - start_time) * 1000)

        if response.status_code != 200:
            error_text = response.text
            if ai_logger.handlers:
                ai_logger.log(
                    logging.WARNING if response.status_code == 429 else logging.ERROR,
                    "",
                    extra={
                        "ai_data": _build_error_ai_data(
                            self.options,
                            self._iteration,
                            response.status_code,
                            error_text,
                            duration_ms,
                        )
                    },
                )
            # 偵測 context window exceeded
            _detect_context_window_error(error_text)
            raise RuntimeError(f"API error ({response.status_code}): {error_text}")

        data = response.json()
        result = ChatCompletionResponse.from_dict(data)

        # Log success RESPONSE
        if ai_logger.handlers:
            resp_data = _build_response_ai_data(
                self.options,
                self._iteration,
                result,
                duration_ms,
                response.status_code,
            )
            if ai_logger.isEnabledFor(logging.DEBUG):
                resp_data["body"] = data
            ai_logger.info("", extra={"ai_data": resp_data})

        return result

    def get_messages(self) -> list[dict]:
        """取得完整對話歷史"""
        return list(self._messages)

    def clear_messages(self) -> None:
        """清除對話歷史"""
        self._messages.clear()

    @property
    def message_count(self) -> int:
        """取得目前對話訊息數量"""
        return len(self._messages)

    @property
    def turn_count(self) -> int:
        """取得目前對話輪數"""
        return len([m for m in self._messages if m.get("role") == "user"])
