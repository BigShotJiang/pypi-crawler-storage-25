"""
FWAuto Agent SDK

透過 OpenAI Chat Completions API 格式與 FWAuto Server (LiteLLM) 通訊，
支援 Claude / Gemini / OpenAI 等多模型。
"""

from .agent import (
    Agent,
    ClaudeAgentOptions,
    ClaudeSDKClient,
    ContextWindowExceededError,
    create_options,
    query,
    run_query,
)
from .types import (
    AgentMessage,
    AssistantMessage,
    ChatCompletionResponse,
    FunctionCall,
    Message,
    ResultMessage,
    SystemMessage,
    TextBlock,
    ToolCall,
    ToolUseBlock,
    UserMessage,
)

__version__ = "0.2.0"

__all__ = [
    # Agent
    "Agent",
    "ClaudeAgentOptions",
    "ClaudeSDKClient",
    "ContextWindowExceededError",
    "create_options",
    "query",
    "run_query",
    # Types - OpenAI Chat Completions
    "ChatCompletionResponse",
    "FunctionCall",
    "ToolCall",
    # Types - 相容
    "AgentMessage",
    "AssistantMessage",
    "Message",
    "ResultMessage",
    "SystemMessage",
    "TextBlock",
    "ToolUseBlock",
    "UserMessage",
]
