# FWAuto

> **新用戶？** 請參考 [Quickstart Guide](docs/quickstart.md) 快速上手。

## Installation

### Install as Global Tool (Recommended)

使用 `uv tool install` 安裝，讓 fwauto 在任意目錄都可執行：

```bash
cd /path/to/fwauto
uv tool install --force --editable .
```

> [!NOTE] 安裝前記得先 `git pull` 確保程式是最新版的

安裝後，可在任意目錄執行：

```bash
cd /path/to/your/stm32-project/examples/實例 xxx
fwauto build        # 從當前目錄 .fwauto/
fwauto run          # Build + Deploy
fwauto init         # 初始化專案
```

解除安裝：

```bash
uv tool uninstall fwauto
```

### Development Mode

如果不想全域安裝，在開發目錄使用 `uv run`：

```bash
cd /path/to/fwauto
uv run fwauto build
uv run fwauto deploy
uv run fwauto run
uv run fwauto log "有任何 error 嗎?"
```

### Dual Version Install

同時安裝 Claude SDK 版本(`fwauto`) 和 Non Claude Code SDK (`fwauto2`)：

```bash
./dual.sh
```

安裝結果：

| 指令      | Branch              | 說明                         |
| --------- | ------------------- | ---------------------------- |
| `fwauto`  | main                | Claude SDK                   |
| `fwauto2` | fwauto-agent-sdk-v2 | 無 Claude Claude SDK(小煌版) |

此 script 使用 git worktree 維護兩個獨立源碼目錄，以 editable 模式安裝。重新執行即可更新。

安裝完成後會有兩個全域的指令 `fwauto` , `fwauto2` 依需要使用即可, 目前 Github 上面處理的 Issues 會以 fwauto 版為準

## 安裝與更新

發佈到 PyPI 後，其他機器可透過以下方式安裝或更新 fwauto。

### 全新安裝

```bash
# 使用 pip
pip install fwauto

# 使用 uv（推薦）
uv tool install fwauto
```

### 更新到最新版本

```bash
# 使用 pip
pip install --upgrade fwauto

# 使用 uv
uv tool upgrade fwauto
```

### 安裝特定版本

```bash
# 使用 pip
pip install fwauto==0.5.1

# 使用 uv
uv tool install fwauto==0.5.1 --force
```

### 確認安裝版本

```bash
fwauto --version
```
