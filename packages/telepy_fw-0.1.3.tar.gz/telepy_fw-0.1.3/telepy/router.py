class Router:
    def __init__(self):
        self.message_handlers = []
        self.callback_handlers = []

    def cmd(self, commands: list, state=None):
        """Декоратор для обработки команд в роутере"""
        def decorator(func):
            state_val = state.name if hasattr(state, 'name') else state
            self.message_handlers.append({'func': func, 'state': state_val, 'commands': commands})
            return func
        return decorator

    def message(self, state=None):
        """Декоратор для обработки сообщений в роутере"""
        def decorator(func):
            state_val = state.name if hasattr(state, 'name') else state
            self.message_handlers.append({'func': func, 'state': state_val})
            return func
        return decorator

    def callback_query(self, data: str = None, state=None):
        """Декоратор для обработки колбэков в роутере"""
        def decorator(func):
            state_val = state.name if hasattr(state, 'name') else state
            self.callback_handlers.append({'func': func, 'data': data, 'state': state_val})
            return func
        return decorator