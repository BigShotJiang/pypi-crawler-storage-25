import asyncio
from .types import Message, CallbackQuery
from .fsm import MemoryStorage, FSMContext
from .router import Router

class BaseMiddleware:
    async def __call__(self, event, data: dict, handler):
        return await handler(event, data)

class Dispatcher:
    def __init__(self, bot):
        self.bot = bot
        self.message_handlers = []
        self.callback_handlers = []
        self.middlewares = []
        self.storage = MemoryStorage()

    def add_middleware(self, middleware: BaseMiddleware):
        self.middlewares.append(middleware)
        
    def connect_router(self, router: Router):
        """Подключает роутер и забирает из него все хендлеры"""
        self.message_handlers.extend(router.message_handlers)
        self.callback_handlers.extend(router.callback_handlers)

    def cmd(self, commands: list, state=None):
        """Декоратор для обработки команд (например: /start, /help)"""
        def decorator(func):
            state_val = state.name if hasattr(state, 'name') else state
            self.message_handlers.append({'func': func, 'state': state_val, 'commands': commands})
            return func
        return decorator

    def message(self, state=None):
        def decorator(func):
            state_val = state.name if hasattr(state, 'name') else state
            self.message_handlers.append({'func': func, 'state': state_val})
            return func
        return decorator

    def callback_query(self, data: str = None, state=None):
        def decorator(func):
            state_val = state.name if hasattr(state, 'name') else state
            self.callback_handlers.append({'func': func, 'data': data, 'state': state_val})
            return func
        return decorator

    async def _process_middleware_chain(self, event, data, handlers, event_type):
        async def execute_handler(evt, d):
            for handler in handlers:
                # Фильтрация по FSM
                current_state = await d['state'].get_state()
                expected_state = handler.get('state')

                if expected_state != "*" and current_state != expected_state:
                    continue

                # Логика для Message (обработка команд)
                if event_type == "message":
                    expected_commands = handler.get('commands')
                    if expected_commands is not None:
                        # Если это не команда (нет текста или не начинается с /)
                        if not evt.text or not evt.text.startswith('/'):
                            continue
                        
                        # Парсим команду: "/start arg" -> "start", "/help@bot" -> "help"
                        cmd_text = evt.text.split()[0][1:].split('@')[0]
                        if cmd_text not in expected_commands:
                            continue

                # Логика для CallbackQuery
                if event_type == "callback_query":
                    expected_data = handler.get('data')
                    if expected_data and expected_data != evt.data:
                        continue
                
                await handler['func'](evt, **d)
                break 

        handler_chain = execute_handler
        for middleware in reversed(self.middlewares):
            def make_chain(mw, nxt):
                async def chain(evt, d):
                    return await mw(evt, d, nxt)
                return chain
            handler_chain = make_chain(middleware, handler_chain)
            
        await handler_chain(event, data)

    async def process_update(self, update: dict):
        if "message" in update:
            # Передаем бота в Message
            msg = Message(update["message"], self.bot)
            state = FSMContext(self.storage, msg.chat.id, msg.f_user.id)
            await self._process_middleware_chain(msg, {"state": state}, self.message_handlers, "message")
            
        elif "callback_query" in update:
            cq = CallbackQuery(update["callback_query"], self.bot)
            chat_id = cq.message.chat.id if cq.message else cq.f_user.id
            state = FSMContext(self.storage, chat_id, cq.f_user.id)
            await self._process_middleware_chain(cq, {"state": state}, self.callback_handlers, "callback_query")

    async def start_polling(self, silent: bool = False):
        offset = None
        
        if not silent:
            # Получаем инфу о боте перед стартом!
            bot_info = await self.bot.my_data()
            bot_name = bot_info.first_name if bot_info else "UnknownBot"
            print(f'Bot "{bot_name}" polling started...')
            
        try:
            while True:
                updates = await self.bot.get_updates(offset=offset)
                if updates:
                    for update in updates:
                        offset = update["update_id"] + 1
                        asyncio.create_task(self.process_update(update))
                await asyncio.sleep(0.1)
        except asyncio.CancelledError:
            pass
        finally:
            await self.bot.close()