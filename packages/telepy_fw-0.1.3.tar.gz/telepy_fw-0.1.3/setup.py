import os
from setuptools import setup, find_packages

# Пытаемся прочитать README.md для красивого описания на PyPI
long_description = "A fast, modern and elegant framework for Telegram Bots"
if os.path.exists("README.md"):
    with open("README.md", "r", encoding="utf-8") as fh:
        long_description = fh.read()

setup(
    name="telepy-fw",                       # Имя пакета для pip install
    version="0.1.1",                        # Версия твоего фреймворка
    author="TREAT",                     # Впиши сюда свой никнейм или имя!
    description="A fast and simple framework for Telegram Bots",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),               # Сам найдет папку telepy и telepy/sync
    install_requires=[                      # Зависимости, которые pip установит сам
        "aiohttp>=3.8.0",
        "requests>=2.25.0"
    ],
    python_requires=">=3.8",                # Минимальная версия Питона
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)