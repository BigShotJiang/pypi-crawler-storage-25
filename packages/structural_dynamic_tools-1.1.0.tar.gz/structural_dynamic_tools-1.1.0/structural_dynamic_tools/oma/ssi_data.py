"""
Data-driven Stochastic Subspace Identification (SSI-DATA).

SSI-DATA identifies modal parameters directly from output-only measurements
by projecting the row space of future outputs onto past outputs and applying
SVD to the resulting projection matrix.

Reference:
    Van Overschee, P., & De Moor, B. (1996).
    Subspace Identification for Linear Systems.
    Springer Science & Business Media.
"""

import numpy as np
from scipy.linalg import svd

from structural_dynamic_tools.utils.oma_utils import (
    build_block_hankel,
    extract_modal_parameters,
)


def ssi_data(
    data: np.ndarray,
    block_rows: int,
    order: int,
    dt: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Data-driven Stochastic Subspace Identification.

    Steps:
        1. Build block Hankel matrix H with 2·i + 1 block rows.
        2. Extract Y_p (blocks 0 … i−1), Y_f (blocks i … 2i−1).
        3. Project row space of Y_f onto Y_p → O_i.
        4. SVD of O_i → observability matrix Γ_i and Kalman state X_i.
        5. Project shifted Y_f (blocks i+1 … 2i−1) onto
           extended Y_p (blocks 0 … i) → O_{i−1}.
        6. Estimate X_{i+1} = pinv(Γ_{i−1}) @ O_{i−1}.
        7. Estimate A, C by least squares on [X_{i+1}; Y_i] = [A; C] @ X_i.
        8. Extract continuous-time modal parameters from A, C.

    Args:
        data: Output-only data, shape ``(channels, samples)``.
        block_rows: Number of block rows i.
        order: Model order (state dimension). Must be ≤ ``channels * block_rows``.
        dt: Sampling period (seconds).

    Returns:
        Tuple ``(freq, damp, phi, keep)``:
            - ``freq``: natural frequencies (Hz)
            - ``damp``: damping ratios
            - ``phi``: mode shape matrix ``(channels, n_modes)``
            - ``keep``: index mask of retained eigenvalues

    Raises:
        ValueError: If ``order`` exceeds the maximum allowed by the data dimensions.
    """
    l, N = data.shape

    if N < 2 * block_rows + 1:
        raise ValueError(
            f"Not enough samples: need at least 2*block_rows+1={2*block_rows+1}, "
            f"got {N}"
        )

    i = block_rows
    j = N - 2 * i + 1
    j_shift = N - 2 * i

    H = build_block_hankel(data, 2 * i + 1, scaling=1.0 / np.sqrt(j))

    Y_p = H[:l * i, :j]
    Y_f = H[l * i:l * 2 * i, :j]

    O_i = Y_f @ Y_p.T @ np.linalg.pinv(Y_p @ Y_p.T) @ Y_p

    U, S, Vh = svd(O_i, full_matrices=False)

    S_sqrt = np.sqrt(S[:order])
    Gamma_i = U[:, :order] * S_sqrt
    X_i = np.diag(S_sqrt) @ Vh[:order, :j]

    Y_p_shift = H[:l * (i + 1), :j_shift]
    Y_f_shift = H[l * (i + 1):l * 2 * i, :j_shift]

    O_i_minus = (
        Y_f_shift @ Y_p_shift.T
        @ np.linalg.pinv(Y_p_shift @ Y_p_shift.T)
        @ Y_p_shift
    )

    Gamma_i_minus = Gamma_i[:l * (i - 1), :]
    X_i_next = np.linalg.pinv(Gamma_i_minus) @ O_i_minus

    X_i_curr = X_i[:, :j_shift]
    Y_i_curr = H[l * i:l * (i + 1), :j_shift]

    AC = np.vstack([X_i_next, Y_i_curr]) @ np.linalg.pinv(X_i_curr)
    A = AC[:order, :]
    C = AC[order:, :]

    return extract_modal_parameters(A, C, dt)


def ssi_data_singular_values(
    data: np.ndarray,
    block_rows: int,
) -> np.ndarray:
    """
    Return singular values of the projection matrix for model-order selection.

    Args:
        data: Output-only data, shape ``(channels, samples)``.
        block_rows: Number of block rows i.

    Returns:
        1-D array of singular values in descending order.
    """
    l, N = data.shape
    j = N - 2 * block_rows + 1
    H = build_block_hankel(data, 2 * block_rows, scaling=1.0 / np.sqrt(j))

    Y_p = H[:l * block_rows, :]
    Y_f = H[l * block_rows:, :]

    O_i = Y_f @ Y_p.T @ np.linalg.pinv(Y_p @ Y_p.T) @ Y_p

    U, S, Vh = svd(O_i, full_matrices=False)
    return S
