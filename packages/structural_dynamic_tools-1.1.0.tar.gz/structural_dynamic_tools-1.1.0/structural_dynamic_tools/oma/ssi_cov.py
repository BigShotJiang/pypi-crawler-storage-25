"""
Covariance-driven Stochastic Subspace Identification (SSI-COV).

SSI-COV identifies modal parameters (natural frequencies, damping ratios,
mode shapes) from output-only vibration measurements by decomposing the
block Toeplitz matrix built from output covariance sequences.

Reference:
    Peeters, B., & De Roeck, G. (1999).
    Reference-based stochastic subspace identification for output-only
    modal analysis. Mechanical Systems and Signal Processing.
"""

import numpy as np
from scipy.linalg import svd

from structural_dynamic_tools.utils.oma_utils import (
    compute_covariance_sequence,
    build_block_toeplitz,
    extract_modal_parameters,
)


def ssi_cov(
    data: np.ndarray,
    block_rows: int,
    order: int,
    dt: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Covariance-driven Stochastic Subspace Identification.

    Steps:
        1. Compute output covariance sequence Λ_i (i = 0 … 2·block_rows−1).
        2. Assemble block Toeplitz matrix T.
        3. SVD: ``T = U·Σ·Vᵀ``.
        4. Truncate to model order n, form observability matrix Γ.
        5. Estimate system matrices A (from shifted Γ) and C (top block of Γ).
        6. Extract continuous-time modal parameters from A, C.

    Args:
        data: Output-only acceleration / displacement data,
            shape ``(channels, samples)``.
        block_rows: Number of block rows i for the Toeplitz matrix.
            Must satisfy ``2 * block_rows * channels <= order``? No: the
            order is the state dimension; block_rows only determines the
            size of the Toeplitz matrix.
        order: Model order (dimension of the state vector). Must be an
            even integer ≤ ``channels * block_rows``.
        dt: Sampling period (seconds).

    Returns:
        Tuple ``(freq, damp, phi, keep)``:
            - ``freq``: natural frequencies (Hz)
            - ``damp``: damping ratios
            - ``phi``: mode shape matrix ``(channels, n_modes)``
            - ``keep``: index mask of retained eigenvalues (positive imag. part)

    Raises:
        ValueError: If ``order`` exceeds the rank of the Toeplitz matrix.
    """
    l = data.shape[0]
    max_lag = 2 * block_rows
    cov_seq = compute_covariance_sequence(data, max_lag)

    T = build_block_toeplitz(cov_seq, block_rows)

    U, S, Vh = svd(T, full_matrices=False)
    S_sqrt = np.sqrt(S[:order])
    O = U[:, :order] * S_sqrt

    O_up = O[:l * (block_rows - 1), :]
    O_down = O[l:, :]
    A = np.linalg.pinv(O_up) @ O_down

    C = O[:l, :]

    return extract_modal_parameters(A, C, dt)


def ssi_cov_singular_values(
    data: np.ndarray,
    block_rows: int,
) -> np.ndarray:
    """
    Return singular values of the Toeplitz matrix for model-order selection.

    Args:
        data: Output-only data, shape ``(channels, samples)``.
        block_rows: Number of block rows for the Toeplitz matrix.

    Returns:
        1-D array of singular values in descending order.
    """
    max_lag = 2 * block_rows
    cov_seq = compute_covariance_sequence(data, max_lag)
    T = build_block_toeplitz(cov_seq, block_rows)

    U, S, Vh = svd(T, full_matrices=False)
    return S
