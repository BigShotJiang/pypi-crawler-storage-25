import numpy as np


def adjust_length(
    data: np.ndarray, seq_len: int, target_len: int, *, axis: int = -1
) -> np.ndarray:
    """
    Truncate or zero-pad data array to match target length along a given axis.

    Args:
        data: Input data array.
        seq_len: Original length of the data along the specified axis.
        target_len: Target length.
        axis: Axis along which to truncate or pad. Defaults to -1.

    Returns:
        Adjusted data array.
    """
    if target_len > seq_len:
        pad_width = [(0, 0)] * data.ndim
        pad_width[axis] = (0, target_len - seq_len)
        idx = [slice(None)] * data.ndim
        idx[axis] = slice(None, seq_len)
        return np.pad(data[tuple(idx)], pad_width)
    elif target_len < seq_len:
        idx = [slice(None)] * data.ndim
        idx[axis] = slice(None, target_len)
        return data[tuple(idx)]
    else:
        idx = [slice(None)] * data.ndim
        idx[axis] = slice(None, seq_len)
        return data[tuple(idx)]


def adjust_amplitude(
    data: np.ndarray, target_amp: float, *, axis: int = -1
) -> np.ndarray:
    """
    Scale data to match a target peak amplitude.

    Args:
        data: Input data array.
        target_amp: Target peak amplitude.
        axis: Axis along which to compute the peak amplitude. Defaults to -1.

    Returns:
        Amplitude-adjusted data array.

    Raises:
        ZeroDivisionError: If data has zero amplitude.
    """
    max_amp = np.abs(data).max(axis=axis, keepdims=True)
    if np.any(max_amp == 0):
        raise ZeroDivisionError("Cannot adjust data with zero amplitude")
    return data * target_amp / max_amp
