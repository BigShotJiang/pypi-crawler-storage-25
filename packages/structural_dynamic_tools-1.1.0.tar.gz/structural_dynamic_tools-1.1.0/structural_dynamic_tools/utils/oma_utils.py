"""
Utility functions for Operational Modal Analysis (OMA).

Provides core linear algebra building blocks shared by SSI-COV and SSI-DATA
algorithms: block Hankel / Toeplitz construction, covariance sequence estimation,
modal parameter extraction from discrete-time state-space matrices, and
stabilization diagram generation.
"""

import numpy as np


def compute_covariance_sequence(
    data: np.ndarray, max_lag: int, *, unbiased: bool = False
) -> np.ndarray:
    """
    Estimate output covariance sequence from multi-channel time-series.

    For an l-channel signal y_k (shape ``(l, N)``), computes

        Λ_i = (1 / N) · Σ_{k=0}^{N-i-1} y_{k+i} · y_kᵀ

    for i = 0, 1, …, max_lag.

    Args:
        data: Output time-series, shape ``(channels, samples)``.
        max_lag: Maximum lag index (inclusive).
        unbiased: If True, divide by N-i instead of N.

    Returns:
        Covariance tensor, shape ``(max_lag+1, channels, channels)``.
    """
    l, N = data.shape
    cov_seq = np.zeros((max_lag + 1, l, l))

    for i in range(max_lag + 1):
        denominator = N - i if unbiased else N
        cov_seq[i] = data[:, i:] @ data[:, :N - i].T / denominator

    return cov_seq


def build_block_hankel(
    data: np.ndarray, block_rows: int, *, scaling: float | None = None
) -> np.ndarray:
    """
    Build a block Hankel matrix from multi-channel time-series data.

    Given an l×N data matrix, construct the li×j block Hankel matrix

        H = [y₀   y₁   …  y_{j-1}  ]
            [y₁   y₂   …  y_j      ]
            [  …                     ]
            [y_{i-1} y_i … y_{i+j-2}]

    where i = block_rows and j = N - i + 1.

    Args:
        data: Output time-series, shape ``(channels, samples)``.
        block_rows: Number of block rows i.
        scaling: If a float is given, multiply the result by it
            (e.g. ``1 / sqrt(j)`` for SSI-DATA).

    Returns:
        Block Hankel matrix, shape ``(channels * block_rows, j)``.
    """
    l, N = data.shape
    j = N - block_rows + 1
    H = np.zeros((l * block_rows, j))

    for r in range(block_rows):
        H[r * l:(r + 1) * l, :] = data[:, r:r + j]

    if scaling is not None:
        H *= scaling

    return H


def build_block_toeplitz(cov_seq: np.ndarray, block_rows: int) -> np.ndarray:
    """
    Build block Toeplitz matrix from a covariance sequence.

    Given covariance matrices Λ₀ … Λ_{2i-1}, assemble

        T = [Λ_i    Λ_{i-1} … Λ_1  ]
            [Λ_{i+1} Λ_i    … Λ_2  ]
            [  …                     ]
            [Λ_{2i-1} Λ_{2i-2} … Λ_i]

    where i = block_rows.

    Args:
        cov_seq: Covariance tensor from ``compute_covariance_sequence``,
            shape ``(2*block_rows, channels, channels)``.
        block_rows: Number of block rows i.

    Returns:
        Block Toeplitz matrix, shape ``(channels*block_rows, channels*block_rows)``.

    Raises:
        ValueError: If cov_seq has fewer than 2*block_rows lag entries.
    """
    l = cov_seq.shape[1]
    needed = 2 * block_rows
    if cov_seq.shape[0] < needed:
        raise ValueError(
            f"Covariance sequence has {cov_seq.shape[0]} entries, "
            f"need {needed} for block_rows={block_rows}"
        )

    T = np.zeros((l * block_rows, l * block_rows))
    for r in range(block_rows):
        for c in range(block_rows):
            T[r * l:(r + 1) * l, c * l:(c + 1) * l] = cov_seq[block_rows + r - c]

    return T


def extract_modal_parameters(
    A: np.ndarray,
    C: np.ndarray,
    dt: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Convert discrete-time state-space matrices to continuous-time modal parameters.

    For each eigenvalue λ_d of A, computes:

        λ_c = ln(λ_d) / dt
        f = |λ_c| / (2π)
        ξ = −Re(λ_c) / |λ_c|
        φ = C · ψ

    where ψ is the eigenvector of A.

    Eigenvalues with positive imaginary parts are retained (complex conjugate
    pairs are collapsed).

    Args:
        A: Discrete-time system matrix, shape ``(n, n)``.
        C: Output matrix, shape ``(l, n)``.
        dt: Sampling interval (seconds).

    Returns:
        Tuple ``(freq, damp, phi, idx_real)`` where
        ``freq`` is natural frequencies (Hz),
        ``damp`` is damping ratios,
        ``phi`` is mode shape matrix ``(l, modes)``,
        and ``idx_real`` is the index mask of retained eigenvalues.
    """
    eig_vals, eig_vecs = np.linalg.eig(A)

    lam_c = np.log(eig_vals) / dt
    freq = np.abs(lam_c) / (2 * np.pi)
    damp = -lam_c.real / np.abs(lam_c)

    keep = lam_c.imag >= 0
    freq = freq[keep]
    damp = damp[keep]
    eig_vecs = eig_vecs[:, keep]

    phi = C @ eig_vecs

    return freq.real, damp.real, phi, keep


def build_stabilization_diagram(
    data: np.ndarray,
    block_rows: int,
    order_min: int,
    order_max: int,
    order_step: int,
    dt: float,
    method: str,
    tol_freq: float = 0.01,
    tol_damp: float = 0.05,
    tol_mac: float = 0.80,
) -> dict:
    """
    Build a stabilization diagram across model orders.

    For each model order n ∈ [order_min, order_max] (step order_step) the
    corresponding SSI variant is called, modal parameters are extracted, and
    each pole is classified as stable, frequency-stable, or unstable by
    comparing with the nearest pole from the previous order.

    Stability criteria:
        - frequency: |f_{new} − f_{ref}| / f_{new} < tol_freq
        - damping:   |ξ_{new} − ξ_{ref}| / ξ_{new} < tol_damp  (if ξ_{ref} > 0)
        - mode shape: MAC(φ_{new}, φ_{ref}) ≥ tol_mac

    A pole is **stable** when all three criteria are met, **frequency-stable**
    when only frequency passes, and **unstable** otherwise.

    Args:
        data: Output time-series, shape ``(channels, samples)``.
        block_rows: Number of block rows for the Hankel / Toeplitz matrix.
        order_min: Minimum model order.
        order_max: Maximum model order.
        order_step: Step between successive model orders.
        dt: Sampling interval (seconds).
        method: ``"cov"`` (SSI-COV) or ``"data"`` (SSI-DATA).
        tol_freq: Relative frequency tolerance.
        tol_damp: Relative damping tolerance.
        tol_mac: MAC threshold for mode-shape stability.

    Returns:
        Dictionary with keys:
            - ``orders``: list of model orders evaluated.
            - ``freq``: nested list, ``freq[i]`` contains frequencies at order i.
            - ``damp``: nested list of damping ratios.
            - ``phi``: nested list of mode shape matrices.
            - ``labels``: nested list of stability labels
              (``"s"`` = stable, ``"f"`` = freq-only, ``"u"`` = unstable).

    Raises:
        ValueError: If method is unrecognized.
    """
    if method not in ("cov", "data"):
        raise ValueError(f"Unknown method '{method}', expected 'cov' or 'data'")

    from structural_dynamic_tools.oma.ssi_cov import ssi_cov
    from structural_dynamic_tools.oma.ssi_data import ssi_data

    ssi_fn = ssi_cov if method == "cov" else ssi_data

    orders = list(range(order_min, order_max + 1, order_step))
    all_freq = []
    all_damp = []
    all_phi = []
    all_labels = []

    prev_freq = None
    prev_damp = None
    prev_phi = None

    for order in orders:
        freq, damp_vals, phi, _ = ssi_fn(data, block_rows, order, dt)
        all_freq.append(freq)
        all_damp.append(damp_vals)
        all_phi.append(phi)

        if prev_freq is not None and len(freq) > 0 and len(prev_freq) > 0:
            labels = _classify_poles(
                freq, damp_vals, phi, prev_freq, prev_damp, prev_phi,
                tol_freq, tol_damp, tol_mac,
            )
        else:
            labels = ["u"] * len(freq)

        all_labels.append(labels)
        prev_freq, prev_damp, prev_phi = freq, damp_vals, phi

    return {
        "orders": orders,
        "freq": all_freq,
        "damp": all_damp,
        "phi": all_phi,
        "labels": all_labels,
    }


def _mac(phi_a: np.ndarray, phi_b: np.ndarray) -> float:
    """Modal Assurance Criterion between two mode shape vectors."""
    return (
        np.abs(phi_a.conj().T @ phi_b) ** 2
        / ((phi_a.conj().T @ phi_a) * (phi_b.conj().T @ phi_b))
    ).real


def _classify_poles(
    freq: np.ndarray,
    damp: np.ndarray,
    phi: np.ndarray,
    freq_ref: np.ndarray,
    damp_ref: np.ndarray,
    phi_ref: np.ndarray,
    tol_freq: float,
    tol_damp: float,
    tol_mac: float,
) -> list[str]:
    labels = []
    n_ref = len(freq_ref)
    for k, f_new in enumerate(freq):
        best_mac = 0.0
        best_idx = 0
        for j in range(n_ref):
            f_ref_val = freq_ref[j]
            if f_ref_val == 0:
                continue
            df_ratio = abs(f_new - f_ref_val) / max(f_new, 1e-12)
            if df_ratio > tol_freq:
                continue
            mac_val = _mac(phi[:, k], phi_ref[:, j])
            if mac_val > best_mac:
                best_mac = mac_val
                best_idx = j

        df_ratio = abs(f_new - freq_ref[best_idx]) / max(f_new, 1e-12)
        d_ratio = (
            abs(damp[k] - damp_ref[best_idx]) / max(abs(damp_ref[best_idx]), 1e-12)
            if abs(damp_ref[best_idx]) > 1e-12
            else 1.0
        )

        if df_ratio < tol_freq and d_ratio < tol_damp and best_mac >= tol_mac:
            labels.append("s")
        elif df_ratio < tol_freq:
            labels.append("f")
        else:
            labels.append("u")

    return labels
