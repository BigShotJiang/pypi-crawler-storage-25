"""Ramberg-Osgood smooth hysteresis model.

The skeleton curve follows:
    d/Δy = F/Fy + (F/Fy)^η

The hysteresis loop is constructed via Masing's rule: the unloading and
reloading curves are geometrically related to the skeleton curve scaled
and shifted.
"""

import numpy as np

from structural_dynamic_tools.constitutive.base import ConstitutiveModel


class RambergOsgood(ConstitutiveModel):
    """Ramberg-Osgood smooth hysteresis model.

    Provides a smooth force-deformation relationship described by a
    power-law skeleton curve with Masing-rule hysteresis.

    Args:
        initial_stiffness: Initial elastic stiffness.
        yield_force: Reference yield force.
        eta: Smoothness parameter (≥ 1). A value of 1 gives linear elastic;
            larger values produce sharper transitions.
    """

    def __init__(
        self,
        initial_stiffness: float = 1.0,
        yield_force: float = 1.0,
        eta: float = 5.0,
    ) -> None:
        self._k0 = float(initial_stiffness)
        self._fy = float(yield_force)
        self._eta = float(eta)
        self._dy = self._fy / self._k0

        self._d_prev: float = 0.0
        self._f_prev: float = 0.0
        self._d_rev: float = 0.0
        self._f_rev: float = 0.0
        self._reversed: bool = False

    @property
    def initial_stiffness(self) -> float:
        return self._k0

    def _skeleton_force(self, d: float) -> float:
        if d == 0.0:
            return 0.0
        ratio = abs(d) / self._dy
        sign = np.sign(d)
        return sign * self._fy * ratio ** (1.0 / self._eta)

    def _skeleton_stiffness(self, d: float) -> float:
        if d == 0.0:
            return self._k0
        ratio = abs(d) / self._dy
        return self._k0 / (self._eta * ratio ** ((self._eta - 1) / self._eta))

    def update(self, deformation: float) -> tuple[float, float]:
        d = deformation
        dd = d - self._d_prev

        if self._f_prev * dd < 0.0:
            self._d_rev = self._d_prev
            self._f_rev = self._f_prev
            self._reversed = True

        if self._reversed:
            d_scaled = (d - self._d_rev) / 2.0
            f_scaled = self._skeleton_force(d_scaled)
            force = self._f_rev + 2.0 * f_scaled
            stiffness = self._skeleton_stiffness(d_scaled)
        else:
            force = self._skeleton_force(d)
            stiffness = self._skeleton_stiffness(d)

        self._d_prev = d
        self._f_prev = force
        return force, stiffness

    def reset(self) -> None:
        self._d_prev = 0.0
        self._f_prev = 0.0
        self._d_rev = 0.0
        self._f_rev = 0.0
        self._reversed = False
