"""Reinforced concrete specific constitutive models.

OpenSees-compatible implementations:
- Steel02 (Giuffré-Menegotto-Pinto reinforcing steel)
- Concrete01 (Kent-Scott-Park, zero tensile strength)
- Concrete02 (linear tension softening)
- ManderConcrete (confined/unconfined concrete)
"""

import numpy as np
from structural_dynamic_tools.constitutive.base import ConstitutiveModel


class Steel02(ConstitutiveModel):
    """Giuffré-Menegotto-Pinto reinforcing steel model.

    Models cyclic behavior of reinforcing bars including Bauschinger effect
    and isotropic hardening. Uses the Menegotto-Pinto equation for curved
    transition between elastic and plastic asymptotes.

    Args:
        E: Elastic modulus (MPa). Default 200000.
        fy: Yield strength (MPa). Default 420.
        b: Strain hardening ratio. Default 0.01.
        R0, cR1, cR2: Curvature parameters. Default OpenSees values.
        a1, a2, a3, a4: Isotropic hardening. Default OpenSees values.
    """

    def __init__(
        self,
        E: float = 200000.0,
        fy: float = 420.0,
        b: float = 0.01,
        R0: float = 20.0,
        cR1: float = 0.925,
        cR2: float = 0.15,
        a1: float = 0.01,
        a2: float = 1.0,
        a3: float = 0.01,
        a4: float = 1.0,
    ) -> None:
        self._E = float(E)
        self._fy = float(fy)
        self._b = float(b)
        self._eps_y = self._fy / self._E
        self._R0 = float(R0)
        self._cR1 = float(cR1)
        self._cR2 = float(cR2)
        self._a1 = float(a1)
        self._a2 = float(a2)
        self._a3 = float(a3)
        self._a4 = float(a4)
        self._d_prev: float = 0.0
        self._f_prev: float = 0.0
        self._eps_prev: float = 0.0
        self._sig_prev: float = 0.0
        self._eps_rev: float = 0.0
        self._sig_rev: float = 0.0
        self._eps_max: float = self._eps_y
        self._eps_min: float = -self._eps_y
        self._eps_t_max: float = 0.0

    @property
    def initial_stiffness(self) -> float:
        return self._E

    def update(self, deformation: float) -> tuple[float, float]:
        eps = deformation
        d_eps = eps - self._eps_prev

        if (self._sig_prev + self._E * d_eps) * self._sig_prev < 0:
            self._eps_rev = self._eps_prev
            self._sig_rev = self._sig_prev
            self._eps_t_max = max(abs(self._eps_max), abs(self._eps_min))

        h_iso = 1.0 + self._a1 * (
            self._eps_t_max / self._eps_y - self._a2
        ) ** self._a3 if self._eps_t_max > self._eps_y else 1.0

        eps_star = (eps - self._eps_rev) / (h_iso * self._eps_y)
        xi = abs(self._eps_rev / self._eps_y)
        R = self._R0 * (1.0 - self._cR1 * xi / (self._cR2 + xi))

        sig = self._sig_rev + h_iso * self._fy * (
            self._b * eps_star
            + (1.0 - self._b) * eps_star
            / (1.0 + abs(eps_star) ** R) ** (1.0 / R)
        )
        tangent = self._E * (
            self._b
            + (1.0 - self._b)
            / (1.0 + abs(eps_star) ** R) ** ((1.0 + R) / R)
        )

        if eps > self._eps_max:
            self._eps_max = eps
        if eps < self._eps_min:
            self._eps_min = eps

        self._eps_prev = eps
        self._sig_prev = sig
        self._d_prev = eps
        self._f_prev = sig
        return sig, tangent

    def reset(self) -> None:
        self._eps_prev = 0.0
        self._sig_prev = 0.0
        self._eps_rev = 0.0
        self._sig_rev = 0.0
        self._eps_max = self._eps_y
        self._eps_min = -self._eps_y
        self._eps_t_max = 0.0
        self._d_prev = 0.0
        self._f_prev = 0.0


class Concrete01(ConstitutiveModel):
    """Kent-Scott-Park concrete with zero tensile strength (OpenSees Concrete01).

    Compression: parabolic ascending + linear descending. No tensile strength.
    Unloading/reloading is linear to the plastic strain point.

    Args:
        fpc: Compressive strength (MPa, positive). Default 30.0.
        epsc0: Strain at peak stress. Default 0.002.
        fpcU: Ultimate stress (MPa, positive). Default 10.0.
        epsU: Ultimate strain. Default 0.006.
    """

    def __init__(
        self,
        fpc: float = 30.0,
        epsc0: float = 0.002,
        fpcU: float = 10.0,
        epsU: float = 0.006,
    ) -> None:
        self._fpc = float(fpc)
        self._epsc0 = float(epsc0)
        self._fpcU = float(fpcU)
        self._epsU = float(epsU)
        self._Ec = 2.0 * self._fpc / self._epsc0
        self._d_prev: float = 0.0
        self._f_prev: float = 0.0
        self._eps_min: float = 0.0
        self._eps_pl: float = 0.0
        self._sig_prev: float = 0.0

    @property
    def initial_stiffness(self) -> float:
        return self._Ec

    def _compressive(self, eps: float) -> tuple[float, float]:
        eps_c = abs(eps)
        if eps_c <= self._epsc0:
            x = eps_c / self._epsc0
            return -self._fpc * (2.0 * x - x * x), self._Ec * (1.0 - x)
        elif eps_c <= self._epsU:
            sig = -self._fpc - (self._fpc - self._fpcU) * (
                (eps_c - self._epsc0) / (self._epsU - self._epsc0)
            )
            sig = max(sig, -self._fpcU)
            k = -(self._fpc - self._fpcU) / (self._epsU - self._epsc0)
            return sig, k
        return -self._fpcU, 0.0

    def update(self, deformation: float) -> tuple[float, float]:
        eps = deformation
        if eps < self._eps_min:
            self._eps_min = eps
            sig, k = self._compressive(eps)
        elif eps >= 0.0:
            sig, k = 0.0, 0.0
        else:
            sig = self._Ec * (eps - self._eps_pl)
            k = self._Ec
            if abs(sig) > abs(self._compressive(eps)[0]):
                self._eps_min = min(self._eps_min, eps)
                sig, k = self._compressive(eps)
        self._d_prev = eps
        self._f_prev = sig
        return sig, k

    def reset(self) -> None:
        self._d_prev = 0.0
        self._f_prev = 0.0
        self._eps_min = 0.0
        self._eps_pl = 0.0
        self._sig_prev = 0.0


class Concrete02(ConstitutiveModel):
    """Uniaxial concrete with linear tension softening (OpenSees Concrete02).

    Compression: Kent-Scott-Park with degraded unloading stiffness.
    Tension: linear elastic up to tensile strength, then linear softening.

    Args:
        fpc: Compressive strength (MPa). Default 30.0.
        epsc0: Strain at peak stress. Default 0.002.
        fpcU: Ultimate stress (MPa). Default 10.0.
        epsU: Ultimate strain. Default 0.006.
        ft: Tensile strength (MPa). Default 3.0.
        Ets: Tension softening stiffness (MPa). Default 1000.0.
        lambda_factor: Compression unloading degradation. Default 0.1.
    """

    def __init__(
        self,
        fpc: float = 30.0,
        epsc0: float = 0.002,
        fpcU: float = 10.0,
        epsU: float = 0.006,
        ft: float = 3.0,
        Ets: float = 1000.0,
        lambda_factor: float = 0.1,
    ) -> None:
        self._fpc = float(fpc)
        self._epsc0 = float(epsc0)
        self._fpcU = float(fpcU)
        self._epsU = float(epsU)
        self._ft = float(ft)
        self._Ets = float(Ets)
        self._lam = float(lambda_factor)
        self._Ec = 2.0 * self._fpc / self._epsc0
        self._eps_t = self._ft / self._Ec
        self._d_prev: float = 0.0
        self._f_prev: float = 0.0
        self._eps_prev: float = 0.0
        self._eps_min: float = 0.0
        self._eps_max: float = self._eps_t
        self._eps_pl: float = 0.0
        self._Eu: float = self._Ec
        self._sig_prev: float = 0.0

    @property
    def initial_stiffness(self) -> float:
        return self._Ec

    def _compressive(self, eps: float) -> tuple[float, float]:
        ec = abs(eps)
        if ec <= self._epsc0:
            x = ec / self._epsc0
            return -self._fpc * (2.0 * x - x * x), self._Ec * (1.0 - x)
        elif ec <= self._epsU:
            sig = -self._fpc - (self._fpc - self._fpcU) * (
                (ec - self._epsc0) / (self._epsU - self._epsc0)
            )
            sig = max(sig, -self._fpcU)
            k = -(self._fpc - self._fpcU) / (self._epsU - self._epsc0)
            return sig, k
        return -self._fpcU, 0.0

    def update(self, deformation: float) -> tuple[float, float]:
        eps = deformation
        d_eps = eps - self._eps_prev

        if d_eps < 0 and self._sig_prev >= 0:
            self._eps_pl = self._eps_prev
            self._Eu = self._Ec * (0.8 + self._lam * abs(self._eps_min) / self._epsc0)
            self._Eu = max(self._Eu, 0.1 * self._Ec)

        if eps > self._eps_max:
            self._eps_max = eps
            sig = self._ft - self._Ets * (eps - self._eps_t)
            sig = max(sig, 0.0)
            k = -self._Ets
        elif eps >= 0.0:
            sig = self._Ec * eps
            k = self._Ec
            if sig > self._ft:
                self._eps_max = eps
                sig = self._ft - self._Ets * (eps - self._eps_t)
                sig = max(sig, 0.0)
                k = -self._Ets
        elif eps < self._eps_min:
            self._eps_min = eps
            sig, k = self._compressive(eps)
        else:
            sig = self._Eu * (eps - self._eps_pl)
            k = self._Eu

        self._eps_prev = eps
        self._sig_prev = sig
        self._d_prev = eps
        self._f_prev = sig
        return sig, k

    def reset(self) -> None:
        self._d_prev = 0.0
        self._f_prev = 0.0
        self._eps_min = 0.0
        self._eps_max = self._eps_t
        self._eps_pl = 0.0
        self._Eu = self._Ec
        self._sig_prev = 0.0


class ManderConcrete(ConstitutiveModel):
    """Mander confined/unconfined concrete model.

    Uses the Mander stress-strain relationship with a single parameter r
    controlling the post-peak branch curvature.

    Args:
        fpc: Unconfined strength (MPa). Default 30.0.
        epsc0: Strain at unconfined peak. Default 0.002.
        Ec: Initial modulus (default ACI 318: 5000*sqrt(fpc)).
        fcc: Confined strength (MPa). Default 35.0.
        epscc: Strain at confined peak. Default computed.
        fccU: Ultimate confined strength. Default 5.0.
        epsccU: Ultimate confined strain. Default 0.015.
    """

    def __init__(
        self,
        fpc: float = 30.0,
        epsc0: float = 0.002,
        Ec: float | None = None,
        fcc: float = 35.0,
        epscc: float | None = None,
        fccU: float = 5.0,
        epsccU: float = 0.015,
    ) -> None:
        self._fpc = float(fpc)
        self._epsc0 = float(epsc0)
        self._Ec = float(Ec) if Ec else 5000.0 * np.sqrt(self._fpc)
        self._fcc = float(fcc)
        self._fccU = float(fccU)
        self._epsccU = float(epsccU)
        self._epscc = float(epscc) if epscc else (
            self._epsc0 * (1.0 + 5.0 * (self._fcc / self._fpc - 1.0))
        )
        self._d_prev: float = 0.0
        self._f_prev: float = 0.0
        self._eps_prev: float = 0.0
        self._eps_min: float = 0.0
        self._eps_pl: float = 0.0
        self._Eu: float = self._Ec
        self._sig_prev: float = 0.0

    @property
    def initial_stiffness(self) -> float:
        return self._Ec

    def _envelope(self, eps: float) -> tuple[float, float]:
        ec = abs(eps)
        if ec >= self._epsccU:
            return -self._fccU, 0.0
        x = ec / self._epscc
        E_sec = self._fcc / self._epscc
        r = self._Ec / (self._Ec - E_sec)
        sig = -self._fcc * x * r / (r - 1.0 + x ** r)
        k_num = self._fcc * r * (r - 1.0 - (r + 1.0) * x ** r)
        k_den = self._epscc * (r - 1.0 + x ** r) ** 2
        return sig, k_num / k_den

    def update(self, deformation: float) -> tuple[float, float]:
        eps = deformation
        d_eps = eps - self._eps_prev
        if d_eps < 0 and self._sig_prev >= 0:
            self._eps_pl = self._eps_prev
            self._Eu = self._Ec * max(0.1, 0.8 * abs(
                self._epscc / max(abs(self._eps_min), self._epscc)
            ))
        if eps >= 0.0:
            sig, k = 0.0, 0.0
        elif eps < self._eps_min:
            self._eps_min = eps
            sig, k = self._envelope(eps)
        else:
            sig = self._Eu * (eps - self._eps_pl)
            k = self._Eu
        self._eps_prev = eps
        self._sig_prev = sig
        self._d_prev = eps
        self._f_prev = sig
        return sig, k

    def reset(self) -> None:
        self._d_prev = 0.0
        self._f_prev = 0.0
        self._eps_min = 0.0
        self._eps_pl = 0.0
        self._Eu = self._Ec
        self._sig_prev = 0.0
