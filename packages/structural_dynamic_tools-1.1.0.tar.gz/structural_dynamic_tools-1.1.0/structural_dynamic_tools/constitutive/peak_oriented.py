"""Peak-oriented hysteresis model.

The unloading and reloading paths are directed toward the previous peak
point on the opposite side, modeling stiffness degradation and pinching
common in reinforced concrete and masonry structures.
"""

import numpy as np

from structural_dynamic_tools.constitutive.base import ConstitutiveModel


class PeakOriented(ConstitutiveModel):
    """Peak-oriented hysteresis model.

    Represents peak-oriented hysteretic behavior for RC and masonry
    structures. Unloading and reloading paths are directed toward the
    previous peak point on the opposite side.

    Args:
        initial_stiffness: Initial elastic stiffness.
        yield_deformation: Yield deformation.
        yield_force: Yield force. Derived from yield_deformation if not given.
        hardening_ratio: Post-yield hardening ratio (0 ≤ r < 1).
        pinching_factor: Pinching factor (0 ≤ p ≤ 1).
            1.0 = no pinching, 0.0 = full pinching.
    """

    def __init__(
        self,
        initial_stiffness: float = 1.0,
        yield_deformation: float | None = None,
        yield_force: float | None = None,
        hardening_ratio: float = 0.02,
        pinching_factor: float = 1.0,
    ) -> None:
        self._k0 = float(initial_stiffness)
        self._r = float(hardening_ratio)
        self._pinch = float(np.clip(pinching_factor, 0.0, 1.0))

        if yield_force is not None:
            self._fy = float(yield_force)
            self._dy = self._fy / self._k0
        elif yield_deformation is not None:
            self._dy = float(yield_deformation)
            self._fy = self._k0 * self._dy
        else:
            raise ValueError("Either yield_deformation or yield_force must be provided")

        self._d_prev: float = 0.0
        self._f_prev: float = 0.0
        self._d_max: float = self._dy
        self._f_max: float = self._fy
        self._d_min: float = -self._dy
        self._f_min: float = -self._fy
        self._d_peak_pos: float = self._dy
        self._f_peak_pos: float = self._fy
        self._d_peak_neg: float = -self._dy
        self._f_peak_neg: float = -self._fy
        self._loading_dir: int = 1

    @property
    def initial_stiffness(self) -> float:
        return self._k0

    def update(self, deformation: float) -> tuple[float, float]:
        d = deformation
        dd = d - self._d_prev

        if dd > 0:
            self._loading_dir = 1
        elif dd < 0:
            self._loading_dir = -1

        if self._loading_dir == 1:
            ftrial = self._f_prev + self._k0 * dd
            if ftrial > self._f_max:
                self._d_max = d
                self._f_max = self._fy + self._r * self._k0 * (d - self._dy)
                self._d_peak_pos = d
                self._f_peak_pos = self._f_max
                force = self._f_max
                stiffness = self._r * self._k0
            else:
                force = self._f_prev + self._k0 * self._pinch * dd
                stiffness = self._k0 * self._pinch
        else:
            ftrial = self._f_prev - self._k0 * dd
            if d < self._d_min:
                self._d_min = d
                self._f_min = -self._fy + self._r * self._k0 * (d + self._dy)
                self._d_peak_neg = d
                self._f_peak_neg = self._f_min
                force = self._f_min
                stiffness = self._r * self._k0
            else:
                force = self._f_prev + self._k0 * self._pinch * dd
                stiffness = self._k0 * self._pinch

        self._d_prev = d
        self._f_prev = force
        return force, stiffness

    def reset(self) -> None:
        self._d_prev = 0.0
        self._f_prev = 0.0
        self._d_max = self._dy
        self._f_max = self._fy
        self._d_min = -self._dy
        self._f_min = -self._fy
        self._d_peak_pos = self._dy
        self._f_peak_pos = self._fy
        self._d_peak_neg = -self._dy
        self._f_peak_neg = -self._fy
        self._loading_dir = 1
