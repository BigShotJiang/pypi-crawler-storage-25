"""Abstract base class for nonlinear constitutive models."""

from abc import ABC, abstractmethod


class ConstitutiveModel(ABC):
    """Abstract base class for nonlinear constitutive models.

    Each subclass must implement:
        - update(deformation): compute restoring force and tangent stiffness
        - reset(): reset internal state to initial conditions
    """

    @abstractmethod
    def update(self, deformation: float) -> tuple[float, float]:
        """Update state given a new deformation.

        Args:
            deformation: Current total deformation.

        Returns:
            Tuple of (restoring_force, tangent_stiffness).
        """
        ...

    @abstractmethod
    def reset(self) -> None:
        """Reset the model to its initial undeformed state."""
        ...

    @property
    @abstractmethod
    def initial_stiffness(self) -> float:
        """Return the initial elastic stiffness."""
        ...
