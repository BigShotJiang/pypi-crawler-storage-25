"""Refined hysteresis models.

- BoucWenBaberNoori: pinching + strength/stiffness degradation
- Pinching4: 4-parameter pinching hysteresis
- EnhancedClough: Clough with additional energy-based degradation
"""

import numpy as np
from structural_dynamic_tools.constitutive.base import ConstitutiveModel


class BoucWenBaberNoori(ConstitutiveModel):
    """Bouc-Wen-Baber-Noori model with pinching and degradation.

    Extends the Bouc-Wen model with mass-normalized pinching and
    energy-based strength/stiffness degradation.

    Args:
        initial_stiffness: Elastic stiffness.
        post_yield_ratio: Post-yield stiffness ratio.
        yield_deformation: Yield deformation.
        A, beta, gamma, n: Standard Bouc-Wen parameters.
        delta_nu, delta_eta: Strength/stiffness degradation rates.
        p: Pinching slope parameter.
        psi: Pinching magnitude parameter.
        delta_psi: Pinching degradation rate.
    """

    def __init__(
        self,
        initial_stiffness: float = 1.0,
        post_yield_ratio: float = 0.05,
        yield_deformation: float = 1.0,
        A: float = 1.0,
        beta: float = 0.5,
        gamma: float = 0.5,
        n: float = 2.0,
        delta_nu: float = 0.0,
        delta_eta: float = 0.0,
        p: float = 1.0,
        psi: float = 1.0,
        delta_psi: float = 0.0,
    ) -> None:
        self._k0 = float(initial_stiffness)
        self._alpha = float(post_yield_ratio)
        self._dy = float(yield_deformation)
        self._A = float(A)
        self._beta = float(beta)
        self._gamma = float(gamma)
        self._n = float(n)
        self._dn = float(delta_nu)
        self._de = float(delta_eta)
        self._p = float(p)
        self._psi = float(psi)
        self._dpsi = float(delta_psi)

        self._d_prev: float = 0.0
        self._z_prev: float = 0.0
        self._energy: float = 0.0
        self._nu: float = 1.0
        self._eta: float = 1.0

    @property
    def initial_stiffness(self) -> float:
        return self._k0

    def _h(self, z: float, dd: float) -> float:
        zeta1 = self._psi * (1.0 + self._dpsi * self._energy)
        zeta2 = self._p * (1.0 + self._dpsi * self._energy)
        return 1.0 - zeta1 * np.exp(-((z * np.sign(dd) - zeta2) ** 2) / zeta2**2)

    def update(self, deformation: float) -> tuple[float, float]:
        d = deformation
        dd = d - self._d_prev
        z = self._z_prev

        h = self._h(z, dd)
        z_abs = abs(z)
        dz = (
            self._A * dd
            - self._nu
            * (
                self._beta * abs(dd) * z_abs ** (self._n - 1) * z
                + self._gamma * dd * z_abs**self._n
            )
        ) / (self._dy * self._eta)

        z_new = z + h * dz
        force = self._alpha * self._k0 * d + (1 - self._alpha) * self._k0 * z_new

        self._energy += (1 - self._alpha) * self._k0 * z * dd
        self._nu = 1.0 + self._dn * self._energy
        self._eta = 1.0 + self._de * self._energy

        self._d_prev = d
        self._z_prev = z_new
        return force, self._k0

    def reset(self) -> None:
        self._d_prev = 0.0
        self._z_prev = 0.0
        self._energy = 0.0
        self._nu = 1.0
        self._eta = 1.0


class Pinching4(ConstitutiveModel):
    """4-parameter pinching hysteresis model (Pinching4).

    Generalization of the Ibarra-Medina-Krawinkler model with trilinear
    backbone, pinching controlled by 4 parameters, and cyclic strength/
    stiffness degradation.

    Args:
        initial_stiffness: Elastic stiffness.
        yield_force: Positive yield force.
        cap_force: Positive capping force.
        cap_deformation: Deformation at capping.
        ultimate_deformation: Deformation at ultimate point.
        residual_force: Residual force ratio.
        pinch_x: Pinching deformation parameter.
        pinch_y: Pinching force parameter.
        damage1: Ductility-based energy dissipation capacity.
        damage2: Cumulative energy dissipation capacity.
        beta_k: Stiffness degradation power.
        beta_f: Strength degradation power.
    """

    def __init__(
        self,
        initial_stiffness: float = 1.0,
        yield_force: float = 10.0,
        cap_force: float = 12.0,
        cap_deformation: float = 2.0,
        ultimate_deformation: float = 5.0,
        residual_force: float = 0.2,
        pinch_x: float = 0.5,
        pinch_y: float = 0.3,
        damage1: float = 100.0,
        damage2: float = 100.0,
        beta_k: float = 0.1,
        beta_f: float = 0.1,
    ) -> None:
        self._k0 = float(initial_stiffness)
        self._fy = float(yield_force)
        self._fc = float(cap_force)
        self._dc = float(cap_deformation)
        self._du = float(ultimate_deformation)
        self._fr = float(residual_force)
        self._px = float(pinch_x)
        self._py = float(pinch_y)
        self._d1 = float(damage1)
        self._d2 = float(damage2)
        self._bk = float(beta_k)
        self._bf = float(beta_f)

        self._dy = self._fy / self._k0
        self._d_prev: float = 0.0
        self._f_prev: float = 0.0
        self._d_max: float = self._dy
        self._f_max: float = self._fy
        self._d_min: float = -self._dy
        self._f_min: float = -self._fy
        self._energy: float = 0.0
        self._loading_dir: int = 1

    @property
    def initial_stiffness(self) -> float:
        return self._k0

    def _degradation_k(self) -> float:
        return 1.0 / (1.0 + self._bk * (self._energy / self._d2))

    def _degradation_f(self) -> float:
        return 1.0 / (1.0 + self._bf * (self._energy / self._d2))

    def _backbone_pos(self, d: float) -> tuple[float, float]:
        df = self._degradation_f()
        if d <= self._dy:
            return self._k0 * d, self._k0
        elif d <= self._dc:
            k_hard = (self._fc - self._fy) / (self._dc - self._dy)
            return self._fy + k_hard * (d - self._dy), k_hard
        elif d <= self._du:
            k_soft = -self._fc * (1.0 - self._fr) / (self._du - self._dc)
            return self._fc + k_soft * (d - self._dc), k_soft
        return self._fr * df * self._fc, 0.0

    def update(self, deformation: float) -> tuple[float, float]:
        d = deformation
        dd = d - self._d_prev

        if dd > 0:
            self._loading_dir = 1
        elif dd < 0:
            self._loading_dir = -1

        dk = self._degradation_k()
        if self._loading_dir == 1:
            if d > self._d_max:
                self._d_max = d
                f, k = self._backbone_pos(d)
                self._f_max = f
                force, stiff = f, k * dk
            else:
                k_unload = self._k0 * dk * self._px
                force = self._f_prev + k_unload * dd * self._py
                stiff = k_unload * self._py
        else:
            if d < self._d_min:
                self._d_min = d
                f_neg, k_neg = self._backbone_pos(-d)
                force = -f_neg
                stiff = k_neg * dk
            else:
                k_unload = self._k0 * dk * self._px
                force = self._f_prev + k_unload * dd * self._py
                stiff = k_unload * self._py

        self._energy += abs(self._f_prev * dd)
        self._d_prev = d
        self._f_prev = force
        return force, stiff

    def reset(self) -> None:
        self._d_prev = 0.0
        self._f_prev = 0.0
        self._d_max = self._dy
        self._f_max = self._fy
        self._d_min = -self._dy
        self._f_min = -self._fy
        self._energy = 0.0
        self._loading_dir = 1


class EnhancedClough(ConstitutiveModel):
    """Enhanced Clough model with energy-based stiffness degradation.

    Extends the basic Clough model with cumulative energy-based degradation
    and optional peak-oriented reloading.

    Args:
        initial_stiffness: Elastic stiffness.
        yield_force: Yield force.
        degradation_param: Basic degradation exponent (0.2-0.6).
        energy_degradation: Energy-based degradation factor.
        reloading_factor: Reloading stiffness to peak factor (0-1).
    """

    def __init__(
        self,
        initial_stiffness: float = 1.0,
        yield_force: float = 10.0,
        degradation_param: float = 0.4,
        energy_degradation: float = 0.0,
        reloading_factor: float = 0.5,
    ) -> None:
        self._k0 = float(initial_stiffness)
        self._fy = float(yield_force)
        self._dy = self._fy / self._k0
        self._gamma = float(degradation_param)
        self._e_degrad = float(energy_degradation)
        self._reload = float(reloading_factor)

        self._d_prev: float = 0.0
        self._f_prev: float = 0.0
        self._d_max: float = self._dy
        self._d_min: float = -self._dy
        self._k_unload: float = self._k0
        self._energy: float = 0.0

    @property
    def initial_stiffness(self) -> float:
        return self._k0

    def update(self, deformation: float) -> tuple[float, float]:
        d = deformation
        dd = d - self._d_prev

        ftrial = self._f_prev + self._k0 * dd
        energy_factor = 1.0 / (1.0 + self._e_degrad * self._energy)

        if ftrial > self._fy:
            self._d_max = d
            self._k_unload = (
                self._k0
                * (self._dy / max(abs(self._d_max), self._dy)) ** self._gamma
                * energy_factor
            )
            force = self._fy
            stiffness = 0.0
        elif ftrial < -self._fy:
            self._d_min = d
            self._k_unload = (
                self._k0
                * (self._dy / max(abs(self._d_min), self._dy)) ** self._gamma
                * energy_factor
            )
            force = -self._fy
            stiffness = 0.0
        else:
            force = ftrial
            stiffness = self._k0
            if dd != 0.0 and self._f_prev * dd < 0.0:
                stiffness = self._k_unload * self._reload + self._k0 * (
                    1.0 - self._reload
                )

        self._energy += abs(self._f_prev * dd)
        self._d_prev = d
        self._f_prev = force
        return force, stiffness

    def reset(self) -> None:
        self._d_prev = 0.0
        self._f_prev = 0.0
        self._d_max = self._dy
        self._d_min = -self._dy
        self._k_unload = self._k0
        self._energy = 0.0
