"""Bilinear hysteresis constitutive model."""

from structural_dynamic_tools.constitutive.base import ConstitutiveModel


class Bilinear(ConstitutiveModel):
    """Bilinear hysteresis constitutive model.

    The force-deformation relationship consists of an elastic branch
    (initial stiffness) followed by a post-yield branch (yield stiffness).

    This model covers elastic-perfectly plastic behavior when
    ``yield_stiffness`` is set to zero.

    Args:
        initial_stiffness: Elastic stiffness before yielding.
        yield_stiffness: Post-yield stiffness ratio (0 ≤ r < 1).
            A value of 0 gives elastic-perfectly plastic behavior.
        yield_deformation: Deformation at which yielding initiates.
        yield_force: Force at which yielding initiates.
            Either ``yield_deformation`` or ``yield_force`` must be provided.
            If both are given, ``yield_force`` takes precedence.
    """

    def __init__(
        self,
        initial_stiffness: float = 1.0,
        yield_stiffness: float = 0.0,
        yield_deformation: float | None = None,
        yield_force: float | None = None,
    ) -> None:
        self._k0 = float(initial_stiffness)
        self._r = float(yield_stiffness)
        self._k1 = self._k0 * self._r

        if yield_force is not None:
            self._fy = float(yield_force)
            self._dy = self._fy / self._k0
        elif yield_deformation is not None:
            self._dy = float(yield_deformation)
            self._fy = self._k0 * self._dy
        else:
            raise ValueError(
                "Either yield_deformation or yield_force must be provided"
            )

        self._d_prev: float = 0.0
        self._f_prev: float = 0.0
        self._d_max: float = self._dy
        self._d_min: float = -self._dy

    @property
    def initial_stiffness(self) -> float:
        return self._k0

    def update(self, deformation: float) -> tuple[float, float]:
        d = deformation
        dd = d - self._d_prev
        ftrial = self._f_prev + self._k0 * dd

        if ftrial > self._fy:
            self._d_max = d
            force = self._fy + self._k1 * (d - self._d_max)
            stiffness = self._k1
        elif ftrial < -self._fy:
            self._d_min = d
            force = -self._fy + self._k1 * (d - self._d_min)
            stiffness = self._k1
        else:
            force = ftrial
            stiffness = self._k0

        self._d_prev = d
        self._f_prev = force
        return force, stiffness

    def reset(self) -> None:
        self._d_prev = 0.0
        self._f_prev = 0.0
        self._d_max = self._dy
        self._d_min = -self._dy
