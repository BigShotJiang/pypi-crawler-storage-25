"""Bouc-Wen smooth hysteresis constitutive model.

The total restoring force is:
    F = α·K·d + (1-α)·K·z

where z evolves by the differential equation:
    dz/dt = (A·dd - β·|dd|·|z|^(n-1)·z - γ·dd·|z|^n) / dy
"""

import numpy as np

from structural_dynamic_tools.constitutive.base import ConstitutiveModel


class BoucWen(ConstitutiveModel):
    """Bouc-Wen smooth hysteresis constitutive model.

    Produces smooth hysteretic loops controlled by shape parameters
    governing the transition and loop shape.

    Args:
        initial_stiffness: Elastic stiffness.
        post_yield_ratio: Ratio of post-yield to initial stiffness (alpha).
        yield_deformation: Yield deformation.
        A: Hysteresis amplitude parameter (default 1.0).
        beta: Hysteresis shape parameter.
        gamma: Hysteresis shape parameter.
        n: Smoothness parameter (larger = sharper transition).
    """

    def __init__(
        self,
        initial_stiffness: float = 1.0,
        post_yield_ratio: float = 0.05,
        yield_deformation: float = 1.0,
        A: float = 1.0,
        beta: float = 0.5,
        gamma: float = 0.5,
        n: float = 2.0,
    ) -> None:
        self._k0 = float(initial_stiffness)
        self._alpha = float(post_yield_ratio)
        self._dy = float(yield_deformation)
        self._A = float(A)
        self._beta = float(beta)
        self._gamma = float(gamma)
        self._n = float(n)

        self._d_prev: float = 0.0
        self._z_prev: float = 0.0

    @property
    def initial_stiffness(self) -> float:
        return self._k0

    def update(self, deformation: float) -> tuple[float, float]:
        d = deformation
        dd = d - self._d_prev
        z = self._z_prev

        z_abs = abs(z)
        dz = (
            self._A * dd
            - self._beta * abs(dd) * z_abs ** (self._n - 1) * z
            - self._gamma * dd * z_abs ** self._n
        ) / self._dy

        z_new = z + dz
        force = (
            self._alpha * self._k0 * d
            + (1 - self._alpha) * self._k0 * z_new
        )
        stiffness = (
            self._alpha * self._k0
            + (1 - self._alpha) * self._k0 * self._A / self._dy
        )

        self._d_prev = d
        self._z_prev = z_new
        return force, stiffness

    def reset(self) -> None:
        self._d_prev = 0.0
        self._z_prev = 0.0
