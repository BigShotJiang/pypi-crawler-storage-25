"""Seismic isolation and damping device constitutive models.

- LRB: Lead Rubber Bearing (bilinear with high initial stiffness)
- FPS: Friction Pendulum System
- ViscousDamper: Maxwell viscous damper model
"""

import numpy as np
from structural_dynamic_tools.constitutive.base import ConstitutiveModel


class LRB(ConstitutiveModel):
    """Lead Rubber Bearing bilinear model.

    Combines the elastic stiffness of rubber with the yielding behavior
    of the lead core. Characterized by high initial stiffness followed
    by a low post-yield stiffness.

    Args:
        initial_stiffness: Elastic stiffness (K1).
        post_yield_stiffness: Post-yield stiffness (K2).
        yield_force: Yield force of the lead core.
        damping_ratio: Equivalent damping ratio (ignored in static analysis).
    """

    def __init__(
        self,
        initial_stiffness: float = 10000.0,
        post_yield_stiffness: float = 1000.0,
        yield_force: float = 100.0,
        damping_ratio: float = 0.3,
    ) -> None:
        self._k1 = float(initial_stiffness)
        self._k2 = float(post_yield_stiffness)
        self._fy = float(yield_force)
        self._dy = self._fy / self._k1
        self._damp = float(damping_ratio)

        self._d_prev: float = 0.0
        self._f_prev: float = 0.0
        self._d_max: float = self._dy
        self._d_min: float = -self._dy

    @property
    def initial_stiffness(self) -> float:
        return self._k1

    def update(self, deformation: float) -> tuple[float, float]:
        d = deformation
        dd = d - self._d_prev
        ftrial = self._f_prev + self._k1 * dd

        if ftrial > self._fy:
            self._d_max = d
            force = self._fy + self._k2 * (d - self._d_max)
            stiffness = self._k2
        elif ftrial < -self._fy:
            self._d_min = d
            force = -self._fy + self._k2 * (d - self._d_min)
            stiffness = self._k2
        else:
            force = ftrial
            stiffness = self._k1

        self._d_prev = d
        self._f_prev = force
        return force, stiffness

    def reset(self) -> None:
        self._d_prev = 0.0
        self._f_prev = 0.0
        self._d_max = self._dy
        self._d_min = -self._dy


class FPS(ConstitutiveModel):
    """Friction Pendulum System (FPS) bearing model.

    A sliding isolation bearing using a spherical sliding surface.
    The restoring force is proportional to the normal load and inversely
    proportional to the radius of curvature. Dynamic friction coefficient
    varies with sliding velocity.

    Args:
        radius: Radius of curvature (m).
        friction_coefficient: Sliding friction coefficient.
        normal_load: Vertical load on the bearing (kN).
        rate_parameter: Velocity-dependent friction parameter (s/m).
    """

    def __init__(
        self,
        radius: float = 2.0,
        friction_coefficient: float = 0.05,
        normal_load: float = 1000.0,
        rate_parameter: float = 0.5,
    ) -> None:
        self._R = float(radius)
        self._mu0 = float(friction_coefficient)
        self._N = float(normal_load)
        self._a = float(rate_parameter)

        self._k_eff = self._N / self._R
        self._d_prev: float = 0.0
        self._f_prev: float = 0.0
        self._vel_prev: float = 0.0

    @property
    def initial_stiffness(self) -> float:
        return self._k_eff

    def update(self, deformation: float) -> tuple[float, float]:
        d = deformation
        dd = d - self._d_prev
        velocity = dd if abs(dd) > 1e-10 else 0.0

        mu = self._mu0 * (1.0 + self._a * abs(velocity))
        friction_force = mu * self._N * np.sign(velocity) if velocity != 0 else 0.0
        restoring_force = self._k_eff * d

        if abs(dd) < 1e-10:
            stick_force = self._f_prev
            if abs(stick_force) <= mu * self._N:
                force = stick_force
                stiffness = self._k_eff
            else:
                force = friction_force + restoring_force
                stiffness = self._k_eff
        else:
            force = friction_force + restoring_force
            stiffness = self._k_eff

        self._d_prev = d
        self._f_prev = force
        self._vel_prev = velocity
        return force, stiffness

    def reset(self) -> None:
        self._d_prev = 0.0
        self._f_prev = 0.0
        self._vel_prev = 0.0


class ViscousDamper(ConstitutiveModel):
    """Linear/nonlinear viscous damper model.

    Implements F = C * |v|^alpha * sign(v), where alpha = 1.0 for linear
    damping and 0 < alpha < 1 for nonlinear (typically 0.3-0.5 for seismic).

    Args:
        damping_coefficient: Damping coefficient C (kN/(m/s)^alpha).
        alpha: Velocity exponent. 1.0 = linear, < 1.0 = nonlinear.
        stiffness: Optional elastic stiffness in series (Maxwell model).
    """

    def __init__(
        self,
        damping_coefficient: float = 100.0,
        alpha: float = 1.0,
        stiffness: float | None = None,
    ) -> None:
        self._C = float(damping_coefficient)
        self._alpha = float(alpha)
        self._K = float(stiffness) if stiffness else float("inf")

        self._d_prev: float = 0.0
        self._f_prev: float = 0.0
        self._vel_prev: float = 0.0

    @property
    def initial_stiffness(self) -> float:
        return self._K if self._K != float("inf") else self._C * 100.0

    def update(self, deformation: float) -> tuple[float, float]:
        d = deformation
        dd = d - self._d_prev
        velocity = dd if abs(dd) > 1e-10 else 0.0

        if abs(velocity) < 1e-10:
            damper_force = 0.0
            tangent = self._C * self._alpha * 1e-10 ** (self._alpha - 1)
        else:
            vel_abs = abs(velocity)
            damper_force = self._C * vel_abs**self._alpha * np.sign(velocity)
            tangent = self._C * self._alpha * vel_abs ** (self._alpha - 1)

        force = damper_force
        stiffness = tangent

        self._d_prev = d
        self._f_prev = force
        self._vel_prev = velocity
        return force, stiffness

    def reset(self) -> None:
        self._d_prev = 0.0
        self._f_prev = 0.0
        self._vel_prev = 0.0
