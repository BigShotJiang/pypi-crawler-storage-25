"""Clough stiffness-degrading hysteresis model."""

from structural_dynamic_tools.constitutive.base import ConstitutiveModel


class Clough(ConstitutiveModel):
    """Clough stiffness-degrading hysteresis model.

    Captures stiffness degradation commonly observed in reinforced
    concrete structures under cyclic loading. The unloading stiffness
    degrades as a function of the maximum experienced deformation.

    Args:
        initial_stiffness: Initial elastic stiffness.
        yield_deformation: Yield deformation.
        yield_force: Yield force. Derived from yield_deformation if not given.
        degradation_param: Stiffness degradation exponent (typically 0.4~0.5).
            Lower values produce more significant degradation.
    """

    def __init__(
        self,
        initial_stiffness: float = 1.0,
        yield_deformation: float | None = None,
        yield_force: float | None = None,
        degradation_param: float = 0.4,
    ) -> None:
        self._k0 = float(initial_stiffness)

        if yield_force is not None:
            self._fy = float(yield_force)
            self._dy = self._fy / self._k0
        elif yield_deformation is not None:
            self._dy = float(yield_deformation)
            self._fy = self._k0 * self._dy
        else:
            raise ValueError("Either yield_deformation or yield_force must be provided")

        self._gamma = float(degradation_param)

        self._d_prev: float = 0.0
        self._f_prev: float = 0.0
        self._d_max: float = self._dy
        self._d_min: float = -self._dy
        self._k_unload: float = self._k0

    @property
    def initial_stiffness(self) -> float:
        return self._k0

    def _update_yield_surface(self, d: float, force: float) -> None:
        if d > self._d_max:
            self._d_max = d
        if d < self._d_min:
            self._d_min = d

    def update(self, deformation: float) -> tuple[float, float]:
        d = deformation
        dd = d - self._d_prev
        ftrial = self._f_prev + self._k0 * dd

        if ftrial > self._fy:
            self._d_max = d
            self._k_unload = (
                self._k0 * (self._dy / max(abs(self._d_max), self._dy)) ** self._gamma
            )
            force = self._fy
            stiffness = 0.0
        elif ftrial < -self._fy:
            self._d_min = d
            self._k_unload = (
                self._k0 * (self._dy / max(abs(self._d_min), self._dy)) ** self._gamma
            )
            force = -self._fy
            stiffness = 0.0
        else:
            force = ftrial
            stiffness = self._k0

            if dd != 0.0 and self._f_prev * dd < 0.0:
                stiffness = self._k_unload

        self._d_prev = d
        self._f_prev = force
        self._update_yield_surface(d, force)
        return force, stiffness

    def reset(self) -> None:
        self._d_prev = 0.0
        self._f_prev = 0.0
        self._d_max = self._dy
        self._d_min = -self._dy
        self._k_unload = self._k0
