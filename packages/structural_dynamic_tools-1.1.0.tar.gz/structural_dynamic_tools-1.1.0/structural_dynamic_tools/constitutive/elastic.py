"""Linear elastic constitutive model."""

from structural_dynamic_tools.constitutive.base import ConstitutiveModel


class Elastic(ConstitutiveModel):
    """Linear elastic constitutive model.

    Args:
        stiffness: Elastic stiffness.
    """

    def __init__(self, stiffness: float = 1.0) -> None:
        self._stiffness = float(stiffness)

    @property
    def initial_stiffness(self) -> float:
        return self._stiffness

    def update(self, deformation: float) -> tuple[float, float]:
        force = self._stiffness * deformation
        return force, self._stiffness

    def reset(self) -> None:
        pass
