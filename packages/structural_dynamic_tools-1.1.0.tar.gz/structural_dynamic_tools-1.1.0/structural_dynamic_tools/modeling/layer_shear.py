"""Layer shear model (also known as the shear building or lumped mass model)."""

import numpy as np


def _build_shear_stiffness(freedom: int, diagonals: np.ndarray) -> np.ndarray:
    """Construct a shear-type stiffness matrix from layer diagonal values."""
    K = np.zeros((freedom, freedom))
    for i in range(freedom - 1):
        K[i, i] = diagonals[i] + diagonals[i + 1]
        K[i, i + 1] = -diagonals[i + 1]
        K[i + 1, i] = -diagonals[i + 1]
    K[freedom - 1, freedom - 1] = diagonals[freedom - 1]
    return K


class LayerShear:
    """Layer shear model representing a multi-story shear building."""

    def __init__(
        self, each_shear_m: np.ndarray, each_shear_k: np.ndarray, h: float = 3.0
    ) -> None:
        """
        Initialize a layer shear model.

        Args:
            each_shear_m: Mass of each story (1D array, length = number of stories).
            each_shear_k: Stiffness of each story (1D array).
            h: Total height of the structure. Defaults to 3.0.
        """
        self.each_shear_m = np.asarray(each_shear_m, dtype=np.float64)
        self.each_shear_k = np.asarray(each_shear_k, dtype=np.float64)
        self.h = float(h)
        self.freedom = len(each_shear_k)
        self.m = np.diag(self.each_shear_m)
        self.k = _build_shear_stiffness(self.freedom, self.each_shear_k)

    def build_p_delta(self) -> np.ndarray:
        """
        Construct the P-Delta geometric stiffness matrix.

        Returns:
            The P-Delta stiffness matrix divided by story height.
        """
        w = np.zeros(self.freedom)
        for i in range(self.freedom):
            w[i] = np.sum(self.each_shear_m[: self.freedom - i]) * 9.8
        k_p = _build_shear_stiffness(self.freedom, w)
        return k_p / self.h


def build_stiffness(each_shear_k: np.ndarray) -> np.ndarray:
    """
    Build a shear-type stiffness matrix from story stiffness values.

    Args:
        each_shear_k: Stiffness of each story (1D array).

    Returns:
        Stiffness matrix (2D array).
    """
    freedom = len(each_shear_k)
    return _build_shear_stiffness(freedom, np.asarray(each_shear_k, dtype=np.float64))


def extract_story_stiffness(K: np.ndarray) -> np.ndarray:
    """
    Extract story stiffness values from a shear-type stiffness matrix.

    Args:
        K: Stiffness matrix (2D array).

    Returns:
        Story stiffness values (1D array).
    """
    freedom = len(K)
    each_shear_k = np.zeros(freedom)
    each_shear_k[-1] = K[-1, -1]
    for i in range(freedom - 2, -1, -1):
        each_shear_k[i] = K[i, i] - each_shear_k[i + 1]
    return each_shear_k
