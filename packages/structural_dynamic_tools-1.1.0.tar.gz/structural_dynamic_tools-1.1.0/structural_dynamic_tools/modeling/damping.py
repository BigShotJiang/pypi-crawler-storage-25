"""Damping matrix construction for structural dynamics.

This module provides interfaces for computing Rayleigh and Caughey damping matrices.
"""

import numpy as np
from scipy.linalg import eig, inv


def rayleigh(
    mass: np.ndarray,
    stiffness: np.ndarray,
    damping_ratio: float | np.ndarray = 0.05,
    seq: tuple[int, int] = (0, 1),
) -> np.ndarray:
    """
    Compute the Rayleigh damping matrix.

    Args:
        mass: Mass matrix.
        stiffness: Stiffness matrix.
        damping_ratio: Damping ratio (scalar or 2-element array).
        seq: Mode indices used for calibration. Defaults to (0, 1).

    Returns:
        Rayleigh damping matrix.
    """
    omega_sq = np.real(eig(stiffness, mass)[0])
    omega_sq = np.sort(omega_sq)

    if len(omega_sq) == 1:
        return 2 * mass * np.sqrt(omega_sq) * damping_ratio

    omega_i = np.sqrt(omega_sq[seq[0]])
    omega_j = np.sqrt(omega_sq[seq[1]])

    if isinstance(damping_ratio, np.ndarray):
        T = np.array([[omega_j, -omega_i], [-1 / omega_j, 1 / omega_i]])
        coeff = 2 * omega_i * omega_j / (omega_j**2 - omega_i**2)
        ab = coeff * (T @ damping_ratio)
        a, b = ab[0], ab[1]
    else:
        a = 2 * omega_i * omega_j / (omega_i + omega_j) * damping_ratio
        b = 2 * damping_ratio / (omega_i + omega_j)

    if np.all(damping_ratio == 0):
        a, b = 0.0, 0.0

    return a * mass + b * stiffness


def caughey(
    mass: np.ndarray,
    stiffness: np.ndarray,
    damping_ratio: float,
    seq: np.ndarray | None = None,
) -> np.ndarray:
    """
    Compute the Caughey damping matrix.

    If no mode sequence is provided, all modes are used.

    Args:
        mass: Mass matrix.
        stiffness: Stiffness matrix.
        damping_ratio: Uniform damping ratio.
        seq: Mode indices to include. Defaults to all modes.

    Returns:
        Caughey damping matrix.
    """
    n = len(mass)

    if seq is None:
        seq = np.arange(n, dtype=int)

    length = len(seq)
    zeta = damping_ratio * np.ones(length)

    omega_sq = np.real(eig(stiffness, mass)[0])
    omega_sq = np.sort(omega_sq)
    omega = np.sqrt(omega_sq)

    omega_n = np.zeros((length, length))
    for i in range(length):
        for j in range(length):
            omega_n[i, j] = omega[seq[i]] ** (2 * (j + 1) - 3)

    a = 2 * inv(omega_n) @ zeta

    C = np.zeros((n, n))
    M_inv_K = inv(mass) @ stiffness
    for i in range(length):
        C = C + a[i] * mass @ np.linalg.matrix_power(M_inv_K, i)

    return C


def damping_nonclassical(
    mass: np.ndarray,
    stiffness: np.ndarray,
    shear_stiffness: np.ndarray,
    child_damping_ratio: list[float],
    child_shear_num: list[int],
    omega_i: float = 0.0,
    omega_j: float = 0.0,
) -> np.ndarray:
    """
    Construct non-proportional (non-classical) damping matrix via recursion.

    The child_damping_ratio list should be ordered from top story to bottom story.

    Args:
        mass: Mass matrix.
        stiffness: Stiffness matrix.
        shear_stiffness: Story stiffness values (1D array).
        child_damping_ratio: Damping ratios of sub-structures (ordered top to bottom).
        child_shear_num: Start/end story indices for each sub-structure.
        omega_i: Pre-computed first reference frequency (0 = auto-compute).
        omega_j: Pre-computed second reference frequency (0 = auto-compute).

    Returns:
        Non-proportional damping matrix.
    """
    if omega_i == 0 or omega_j == 0:
        omega_sq = np.real(eig(stiffness, mass)[0])
        omega_sq = np.sort(omega_sq)
        omega_i = np.sqrt(omega_sq[0])
        omega_j = np.sqrt(omega_sq[1])

    if len(child_damping_ratio) == 1:
        a = 2 * omega_i * omega_j / (omega_i + omega_j) * child_damping_ratio[0]
        b = 2 * child_damping_ratio[0] / (omega_i + omega_j)
        return a * mass + b * stiffness

    flag = child_shear_num[-1]
    child_mass_1 = mass[:flag, :flag]
    child_mass_4 = mass[flag:, flag:]
    child_stiffness_1 = stiffness[:flag, :flag]
    child_stiffness_2 = stiffness[:flag, flag:]
    child_stiffness_4 = stiffness[flag:, flag:]

    K_r = np.zeros((flag, flag))
    K_r[-1, -1] = shear_stiffness[flag]

    D1 = damping_nonclassical(
        child_mass_1,
        child_stiffness_1 - K_r,
        shear_stiffness,
        child_damping_ratio[:-1],
        child_shear_num[:-1],
        omega_i,
        omega_j,
    )

    a = 2 * omega_i * omega_j / (omega_i + omega_j) * child_damping_ratio[-1]
    b = 2 * child_damping_ratio[-1] / (omega_i + omega_j)

    D1 = D1 + b * K_r
    D2 = b * child_stiffness_2
    D3 = D2.T
    D4 = a * child_mass_4 + b * child_stiffness_4

    return np.block([[D1, D2], [D3, D4]])
