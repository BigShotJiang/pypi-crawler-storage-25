from importlib import resources

import numpy as np
import re

NUMBER_RE = r"[+-]?(\d+([.]\d*)?([eE][+-]?\d+)?|[.]\d+([eE][+-]?\d+)?)"


def read_wave_from_1line_file(
    filepath: str,
    start_line: int = 1,
    end_line: int | None = None,
    dt: float | int = 0,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Read seismic wave data from a single-column text file.

    Default file format: the first line is the time step, and starting from the
    second line are the seismic acceleration data (single column).

    Args:
        filepath: Path to the input file.
        start_line: Start line index (0-based). Defaults to 1 (second line).
        end_line: End line index (exclusive). Defaults to None (read to end).
        dt: Time step. If float, use directly; if int, read from the line at that index.

    Returns:
        Tuple[np.ndarray, np.ndarray]: Time array and seismic wave data array (g or m/s²).
    """
    with open(filepath, "r") as fp:
        lines = fp.readlines()
        wave_data = [float(line.strip()) for line in lines[start_line:end_line]]

        if isinstance(dt, float):
            pass
        elif isinstance(dt, int):
            dt = float(lines[dt].split()[-1])
        else:
            raise ValueError(f"dt 参数类型必须为 float 或 int，当前类型: {type(dt)}")

        n = len(wave_data)
        time = np.linspace(0, (n - 1) * dt, n, dtype=np.float64)

        return time, np.array(wave_data, dtype=np.float64)


def write_wave_to_1line_file(
    filepath: str, acc: np.ndarray, dt: float | None = None
) -> None:
    """
    Write seismic wave data to a single-column text file.

    Default file format: the first line is the time step (if provided), and starting
    from the second line are the seismic acceleration data (single column).

    Args:
        filepath: Path to the output file.
        acc: Acceleration data array.
        dt: Time step (optional). If provided, written as the first line.
    """
    if dt is None:
        np.savetxt(filepath, acc, fmt="%.6f")
    else:
        with open(filepath, "w") as fp:
            fp.write(f"{dt}\n")
            np.savetxt(fp, acc, fmt="%.6f")


def read_wave_from_2line_file(
    filepath: str, start_line: int = 0, end_line: int | None = None, seg: str = " "
) -> tuple[np.ndarray, np.ndarray]:
    """
    Read seismic wave data from a two-column text file.

    File format: first column is time, second column is value, separated by seg.

    Args:
        filepath: Path to the input file.
        start_line: Start line index (0-based). Defaults to 0 (first line).
        end_line: End line index (exclusive). Defaults to None (read to end).
        seg: Column separator. Defaults to space.

    Returns:
        Tuple[np.ndarray, np.ndarray]: Time array and value array.
    """
    time_data = []
    value_data = []

    with open(filepath, "r") as fp:
        lines = fp.readlines()
        target_lines = lines[start_line:end_line]

        for line in target_lines:
            line = line.strip()
            if line:
                parts = line.split(seg)
                if len(parts) >= 2:
                    time_data.append(float(parts[0]))
                    value_data.append(float(parts[1]))

    return np.array(time_data, dtype=np.float64), np.array(value_data, dtype=np.float64)


def write_wave_to_2line_file(
    filepath: str, time: np.ndarray, value: np.ndarray, seg: str = " "
) -> None:
    """
    Write seismic wave data to a two-column text file.

    File format: first column is time, second column is value, separated by seg.

    Args:
        filepath: Path to the output file.
        time: Time data array.
        value: Value data array.
        seg: Column separator. Defaults to space.
    """
    with open(filepath, "w") as fp:
        for t, v in zip(time, value):
            fp.write(f"{t}{seg}{v}\n")


def read_from_kik(file_path: str) -> tuple[np.ndarray, np.ndarray]:
    """
    Read ground motion data from KIK format.

    Args:
        file_path: Path to the KIK format file.

    Returns:
        Tuple[np.ndarray, np.ndarray]: Time array and ground motion data array (m/s²).
    """
    gm_data_list = None
    scale_factor = None
    time_step = None

    with open(file_path, "r") as f:
        lines = f.readlines()
        for line in lines:
            if re.match(r"^Memo\.", line):
                idx = lines.index(line) + 1
                gm_data_list = []
                for i in range(idx, len(lines)):
                    for val in lines[i].split():
                        gm_data_list.append(eval(val) * 0.01)
                break
            elif re.match(r"^Scale Factor\.", line):
                match_result = re.search(r"(\d+)\D*(\d+)/?$", line)
                scale_factor = eval(match_result.group(1)) / eval(match_result.group(2))
            elif re.match(r"^Sampling Freq\.", line):
                time_step = 1 / eval(re.search(NUMBER_RE, line).group())

    if gm_data_list is None or scale_factor is None or time_step is None:
        raise ValueError(
            "Failed to parse KIK file: missing Memo., Scale Factor., or Sampling Freq. line."
        )

    gm_data = np.array(gm_data_list, dtype=np.float64)
    gm_data = (gm_data - gm_data.mean()) * scale_factor

    n = len(gm_data)
    time = np.linspace(0, (n - 1) * time_step, n, dtype=np.float64)

    return time, gm_data


def read_from_peer(file_path: str) -> tuple[np.ndarray, np.ndarray]:
    """
    Read ground motion data from PEER format.

    Args:
        file_path: Path to the PEER format file.

    Returns:
        Tuple[np.ndarray, np.ndarray]: Time array and ground motion data array (m/s²).
    """
    with open(file_path, "r") as fp:
        lines = fp.readlines()
        time_step = eval(re.findall(r"\.[0-9]*", lines[3])[0])
        gm_data_list = []
        for i in range(4, len(lines)):
            for val in lines[i].split():
                gm_data_list.append(eval(val) * 9.8)

    gm_data = np.array(gm_data_list, dtype=np.float64)
    n = len(gm_data)
    time = np.linspace(0, (n - 1) * time_step, n, dtype=np.float64)

    return time, gm_data


def load_example_seismic_wave(name: str = "elcentro") -> tuple[np.ndarray, np.ndarray]:
    """
    Load example seismic wave data.

    Supported names:
    - "elcentro": Generate a simulated El Centro seismic wave.

    Args:
        name: Seismic wave name. Defaults to "elcentro".

    Returns:
        Tuple[np.ndarray, np.ndarray]: Time array and acceleration array.

    Raises:
        ValueError: If the seismic wave name is unknown.
    """
    if name.lower() == "elcentro":
        data_path = resources.files("structural_dynamic_tools") / "res" / "ELCENTRO.txt"
        with resources.as_file(data_path) as path:
            return read_from_peer(str(path))
    else:
        raise ValueError(f"Unknown seismic wave name: {name}")
