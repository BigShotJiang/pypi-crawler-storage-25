"""
Modal analysis module for structural dynamics.

This module provides various computational methods for practical vibration analysis.
Currently, the frequency calculations are verified to be correct, which generally
ensures correct mode shapes. However, mode shape normalization is not yet implemented.

There are three common normalization methods:
- Normalization to a specific coordinate
- Maximum value normalization
- Normalization with respect to mass matrix

These will be implemented in future revisions.
"""

import numpy as np
from scipy.linalg import inv, eig, eigh, norm


def normalize(mat: np.ndarray, psi: np.ndarray) -> np.ndarray:
    """
    Normalize a vector psi with respect to a matrix.

    Args:
        mat: Normalization matrix (typically mass matrix)
        psi: Vector to be normalized

    Returns:
        Normalized vector
    """
    mat_num = psi.T @ mat @ psi
    return psi / np.sqrt(mat_num)


def rayleigh_psi(
    mass: np.ndarray, stiffness: np.ndarray, psi: np.ndarray | None = None
) -> float:
    """
    Calculate natural frequency using Rayleigh's quotient.

    Args:
        mass: Mass matrix
        stiffness: Stiffness matrix
        psi: Assumed mode shape vector. If None, uses a vector of ones.

    Returns:
        Natural frequency (rad/s)
    """
    if psi is None:
        n = len(mass)
        psi = np.ones(n)

    numerator = psi.T @ stiffness @ psi
    denominator = psi.T @ mass @ psi
    return np.sqrt(numerator / denominator)


def rayleigh_ritz(
    mass: np.ndarray,
    stiffness: np.ndarray,
    psi: int | np.ndarray = 1,
    load: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Rayleigh-Ritz method for modal analysis.

    If no assumed mode shapes are provided, the program automatically generates
    a set of load-dependent Ritz vectors. If no load is provided, a unit load
    is applied at each degree of freedom.

    Args:
        mass: Mass matrix
        stiffness: Stiffness matrix
        psi: Number of modes to calculate (int) or pre-defined mode shapes (ndarray)
        load: Load vector for generating Ritz vectors

    Returns:
        Tuple containing natural frequencies and mode shapes
    """
    if isinstance(psi, int):
        psi, _, _ = load_depended_ritz_vector(mass, stiffness, psi, load)

    k_reduced = psi.T @ stiffness @ psi
    m_reduced = psi.T @ mass @ psi

    omega_sq, gene_crd = eig(k_reduced, m_reduced)
    omega = np.sqrt(omega_sq)

    phi = psi @ gene_crd

    return omega.real, phi.real


def load_depended_ritz_vector(
    mass: np.ndarray,
    stiffness: np.ndarray,
    count: int = 1,
    load: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Generate load-dependent Ritz vectors.

    These vectors can be used in mode superposition methods to accelerate
    convergence when higher modes significantly affect the response.

    Args:
        mass: Mass matrix
        stiffness: Stiffness matrix
        count: Number of Ritz vectors to generate
        load: Load vector. If None, uses unit loads at each DOF.

    Returns:
        Tuple containing Ritz vectors, alpha coefficients, and beta coefficients
    """
    n = len(mass)

    if load is None:
        load = np.ones(n)

    stiffness_inv = inv(stiffness)

    dpm = stiffness_inv @ load
    ritz = np.zeros((n, count + 1))
    ritz[:, 0] = normalize(mass, dpm)

    alpha = np.zeros(count)
    beta = np.zeros(count)

    for i in range(count):
        dpm = stiffness_inv @ mass @ ritz[:, i]

        for j in range(i + 1):
            alpha_ij = dpm.T @ mass @ ritz[:, j]
            dpm -= alpha_ij * ritz[:, j]

        ritz[:, i + 1] = normalize(mass, dpm)
        alpha[i] = ritz[:, i].T @ mass @ stiffness_inv @ mass @ ritz[:, i]
        beta[i] = np.sqrt(dpm.T @ mass @ dpm)

    return ritz[:, :-1], alpha, beta


def mat_iterate_base(
    mass: np.ndarray, stiffness: np.ndarray, precision: float = 1e-3
) -> tuple[float, np.ndarray]:
    """
    Matrix iteration method for fundamental mode.

    Args:
        mass: Mass matrix
        stiffness: Stiffness matrix
        precision: Convergence tolerance

    Returns:
        Tuple containing fundamental frequency and mode shape
    """
    n = mass.shape[0]
    stiffness_inv = inv(stiffness)
    dyn_mat = stiffness_inv @ mass

    phi = np.random.uniform(-1, 1, n)
    omega_temp = np.sqrt(phi.T @ stiffness @ phi)

    step = 0
    max_steps = 100

    while step < max_steps:
        phi_temp = dyn_mat @ phi
        phi = phi_temp / np.sqrt(phi_temp.T @ mass @ phi_temp)
        omega = np.sqrt(phi.T @ stiffness @ phi)

        if abs(omega - omega_temp) < precision * omega:
            break

        omega_temp = omega
        step += 1

    return omega, phi


def mat_iterate_high(
    mass: np.ndarray,
    stiffness: np.ndarray,
    omega_pre: np.ndarray,
    phi_pre: np.ndarray,
    precision: float = 1e-3,
) -> tuple[float, np.ndarray]:
    """
    Matrix iteration method for higher modes (with orthogonalization).

    Args:
        mass: Mass matrix
        stiffness: Stiffness matrix
        omega_pre: Previous mode frequencies
        phi_pre: Previous mode shapes
        precision: Convergence tolerance

    Returns:
        Tuple containing higher mode frequency and mode shape
    """
    n = mass.shape[0]
    stiffness_inv = inv(stiffness)
    dyn_mat = stiffness_inv @ mass

    phi = np.random.uniform(-1, 1, n)
    omega_temp = np.sqrt(phi.T @ stiffness @ phi)

    step = 0
    max_steps = 100

    while step < max_steps:
        phi_temp = dyn_mat @ phi
        phi = phi_temp / np.sqrt(phi_temp.T @ mass @ phi_temp)

        for i in range(len(omega_pre)):
            phi_prev = phi_pre[:, i] if phi_pre.ndim == 2 else phi_pre[i]
            alpha = phi.T @ mass @ phi_prev
            phi -= alpha * phi_prev

        omega = np.sqrt(phi.T @ stiffness @ phi)

        if abs(omega - omega_temp) < precision * omega:
            break

        omega_temp = omega
        step += 1

    return omega, phi


def mat_iterate_highest(
    mass: np.ndarray, stiffness: np.ndarray, precision: float = 1e-3
) -> tuple[float, np.ndarray]:
    """
    Matrix iteration method for highest mode.

    Args:
        mass: Mass matrix
        stiffness: Stiffness matrix
        precision: Convergence tolerance

    Returns:
        Tuple containing highest frequency and mode shape
    """
    n = mass.shape[0]
    mass_inv = inv(mass)
    dyn_mat = mass_inv @ stiffness

    phi = np.random.uniform(-1, 1, n)
    omega_temp = np.sqrt(phi.T @ stiffness @ phi)

    step = 0
    max_steps = 100

    while step < max_steps:
        phi_temp = dyn_mat @ phi
        phi = phi_temp / np.sqrt(phi_temp.T @ mass @ phi_temp)
        omega = np.sqrt(phi.T @ stiffness @ phi)

        if abs(omega - omega_temp) < precision * omega:
            break

        omega_temp = omega
        step += 1

    return omega, phi


def subspace_iteration(
    mass: np.ndarray,
    stiffness: np.ndarray,
    psi: int | np.ndarray = 1,
    precision: float = 1e-3,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Subspace iteration method for modal analysis.

    Args:
        mass: Mass matrix
        stiffness: Stiffness matrix
        psi: Number of modes (int) or initial subspace vectors (ndarray)
        precision: Convergence tolerance

    Returns:
        Tuple containing natural frequencies and mode shapes
    """
    if isinstance(psi, int):
        psi, _, _ = load_depended_ritz_vector(mass, stiffness, psi)

    stiffness_inv = inv(stiffness)
    dyn_mat = stiffness_inv @ mass

    omega_temp = np.ones(len(mass))
    step = 0
    max_steps = 100

    while step < max_steps:
        psi = dyn_mat @ psi

        k_temp = psi.T @ stiffness @ psi
        m_temp = psi.T @ mass @ psi

        omega_sq, comb_coeff = eig(k_temp, m_temp)
        omega = np.sqrt(omega_sq)
        phi = psi @ comb_coeff

        if norm(omega - omega_temp) < norm(precision * omega):
            break

        omega_temp = omega
        step += 1

    return omega.real, phi.real


def lanczos(
    mass: np.ndarray,
    stiffness: np.ndarray,
    count: int = 1,
    load: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Lanczos method for modal analysis.

    Args:
        mass: Mass matrix
        stiffness: Stiffness matrix
        count: Number of modes to calculate
        load: Load vector for generating initial Ritz vectors

    Returns:
        Tuple containing eigenvalues and mode shapes
    """
    psi, alpha, beta = load_depended_ritz_vector(mass, stiffness, count, load)

    T = np.diag(alpha) + np.diag(beta[:-1], k=1) + np.diag(beta[:-1], k=-1)
    eigenvalues, eigenvectors = eigh(T)

    return eigenvalues, psi @ eigenvectors


def dunkerley(mass: np.ndarray, stiffness: np.ndarray) -> float:
    """
    Dunkerley's formula for approximate fundamental frequency.

    Provides a lower bound estimate of the fundamental frequency. Useful when
    higher modes have significantly higher frequencies than the fundamental.

    Note: This method provides a rough approximation.

    Args:
        mass: Mass matrix
        stiffness: Stiffness matrix

    Returns:
        Approximate fundamental frequency
    """
    stiffness_inv = inv(stiffness)
    dyn_mat = stiffness_inv @ mass
    return np.sqrt(1 / dyn_mat.trace())


def jacobi(
    mass: np.ndarray, stiffness: np.ndarray, eps: float = 1e-10, max_iter: int = 1000
) -> tuple[np.ndarray, np.ndarray]:
    """
    Jacobi iteration method for symmetric matrix eigenvalue problem.

    Args:
        mass: Mass matrix
        stiffness: Stiffness matrix
        eps: Convergence tolerance
        max_iter: Maximum number of iterations

    Returns:
        Tuple containing natural frequencies and mode shapes
    """
    n = len(mass)
    stiffness_inv = inv(stiffness)
    dyn_mat = stiffness_inv @ mass

    v_rotate = np.eye(n)
    dyn_np = np.asarray(dyn_mat)

    for _ in range(max_iter):
        triu_vals = np.triu(dyn_np, 1)
        max_idx = np.argmax(np.abs(triu_vals))

        if np.abs(dyn_np.flat[max_idx]) ** 2 < eps:
            break

        i, j = divmod(max_idx, n)

        if dyn_np[i, i] == dyn_np[j, j]:
            theta = np.pi / 4
        else:
            theta = 0.5 * np.arctan(2 * dyn_np[i, j] / (dyn_np[i, i] - dyn_np[j, j]))

        r_rotate = np.eye(n)
        r_rotate[i, i] = np.cos(theta)
        r_rotate[j, j] = np.cos(theta)
        r_rotate[i, j] = -np.sin(theta)
        r_rotate[j, i] = np.sin(theta)

        dyn_np = r_rotate.T @ dyn_np @ r_rotate
        v_rotate = v_rotate @ r_rotate

    eig_values = np.diag(dyn_np)
    eig_vectors = v_rotate.T
    omega = 1 / np.sqrt(eig_values)

    return omega, eig_vectors
