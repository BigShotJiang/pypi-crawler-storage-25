"""Single Degree of Freedom Nonlinear Time Integration Methods.

This module provides time-stepping integration for SDOF systems with
nonlinear constitutive models.  Both the central-difference method (
explicit) and the Newmark-β constant-average-acceleration method (
implicit with tangent stiffness) are implemented.

All public functions support batch computation: a single mass &
damping system is driven by multiple load histories simultaneously.
Each batch slice maintains its own constitutive-model state.
"""

from __future__ import annotations

from typing import List, Tuple, Union

import numpy as np

from structural_dynamic_tools.utils.wave_utils import adjust_length
from structural_dynamic_tools.constitutive import ConstitutiveModel


def _add_batch_dim(load: np.ndarray) -> np.ndarray:
    if load.ndim == 1:
        return load[np.newaxis, :]
    return load


def _init_response(
    result_len: int,
    batch_size: int,
    disp_0: float,
    vel_0: float,
    acc_0: float | None = None,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray | None]:
    disp = np.zeros((batch_size, result_len))
    vel = np.zeros((batch_size, result_len))
    acc = np.zeros((batch_size, result_len)) if acc_0 is not None else None
    disp[:, 0] = disp_0
    vel[:, 0] = vel_0
    if acc is not None:
        acc[:, 0] = acc_0
    return disp, vel, acc


def _ensure_nl_batch(
    constitutive_model: Union[ConstitutiveModel, List[ConstitutiveModel]],
    batch_size: int,
) -> List[ConstitutiveModel]:
    """Normalise constitutive model argument to a list of length ``batch_size``.

    When a single model is passed it is reused for every batch slice after
    calling ``reset()`` on it.  A list must already match ``batch_size``.
    """
    if isinstance(constitutive_model, ConstitutiveModel):
        constitutive_model.reset()
        return [constitutive_model] * batch_size
    if len(constitutive_model) != batch_size:
        raise ValueError(
            f"Expected {batch_size} constitutive models, got {len(constitutive_model)}"
        )
    return constitutive_model


def sdof_nonlinear_center_diff(
    mass: float,
    constitutive_model: ConstitutiveModel | List[ConstitutiveModel],
    load: np.ndarray,
    time: np.ndarray,
    *,
    damping_ratio: float = 0.05,
    disp_0: float = 0.0,
    vel_0: float = 0.0,
    result_len: int = 0,
    **kwargs: object,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Central-difference method for a nonlinear SDOF system.

    The restoring force is supplied by a ``ConstitutiveModel`` instance.
    No tangent stiffness is needed, making this method straightforward
    for any hysteretic law.

    Args:
        mass: Mass.
        constitutive_model: Nonlinear constitutive model.  Pass a list
            (one per batch) for batched computation.
        load: Load array of shape ``(seq_len,)`` or ``(batch, seq_len)``.
        time: Time array.
        damping_ratio: Damping ratio.  Defaults to 0.05.
        disp_0: Initial displacement.  Defaults to 0.0.
        vel_0: Initial velocity.  Defaults to 0.0.
        result_len: Length of output arrays.  Defaults to ``len(time)``.

    Returns:
        Tuple of ``(disp, vel, acc)`` arrays, each of shape
        ``(result_len,)`` or ``(batch, result_len)``.
    """
    seq_len = load.shape[-1]

    if result_len == 0:
        result_len = len(time)

    load = _add_batch_dim(load)
    load = adjust_length(load, seq_len, result_len, axis=-1)
    batch_size = load.shape[0]

    models = _ensure_nl_batch(constitutive_model, batch_size)

    omega_n = np.sqrt(np.mean([m.initial_stiffness for m in models]) / mass)
    damping = 2.0 * mass * omega_n * damping_ratio

    dt0 = time[1] - time[0]
    acc_0 = np.zeros(batch_size)
    for b in range(batch_size):
        f_s, _ = models[b].update(disp_0)
        acc_0[b] = (load[b, 0] - damping * vel_0 - f_s) / mass
    disp_minus1 = disp_0 - dt0 * vel_0 + 0.5 * dt0 * dt0 * acc_0

    disp, vel, acc = _init_response(result_len, batch_size, disp_0, vel_0, 0.0)

    equ_k0 = mass / (dt0 * dt0) + damping / (2.0 * dt0)
    a_mat0 = 2.0 * mass / (dt0 * dt0)
    b_mat0 = mass / (dt0 * dt0) - damping / (2.0 * dt0)

    for b in range(batch_size):
        f_s, _ = models[b].update(disp_0)
        equ_p0 = load[b, 0] - f_s + a_mat0 * disp_0 - b_mat0 * disp_minus1[b]
        disp[b, 1] = equ_p0 / equ_k0

    vel[:, 0] = (disp[:, 1] - disp_minus1) / (2.0 * dt0)
    acc[:, 0] = (disp[:, 1] - 2.0 * disp[:, 0] + disp_minus1) / (dt0 * dt0)

    for i in range(1, result_len - 1):
        dti = time[i + 1] - time[i]

        equ_k = mass / (dti * dti) + damping / (2.0 * dti)
        a_mat = 2.0 * mass / (dti * dti)
        b_mat = mass / (dti * dti) - damping / (2.0 * dti)

        for b in range(batch_size):
            f_s, _ = models[b].update(disp[b, i])
            equ_p = load[b, i] - f_s + a_mat * disp[b, i] - b_mat * disp[b, i - 1]
            disp[b, i + 1] = equ_p / equ_k

        vel[:, i] = (disp[:, i + 1] - disp[:, i - 1]) / (2.0 * dti)
        acc[:, i] = (disp[:, i + 1] - 2.0 * disp[:, i] + disp[:, i - 1]) / (dti * dti)

    if batch_size == 1:
        disp = disp[0]
        vel = vel[0]
        acc = acc[0]

    return disp, vel, acc


def sdof_nonlinear_hht(
    mass: float,
    constitutive_model: ConstitutiveModel | List[ConstitutiveModel],
    load: np.ndarray,
    time: np.ndarray,
    *,
    damping_ratio: float = 0.05,
    disp_0: float = 0.0,
    vel_0: float = 0.0,
    alpha: float = -0.1,
    result_len: int = 0,
    max_iter: int = 10,
    tol: float = 1e-6,
    **kwargs: object,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """HHT-α method for nonlinear SDOF with Newton‑Raphson iteration.

    Hilber-Hughes-Taylor method introduces controllable numerical damping
    for high-frequency modes while preserving second-order accuracy for
    low-frequency response.  α ∈ [-⅓, 0]; α = 0 recovers Newmark‑β.

    Integration parameters are set automatically:
        β = (1 − α)² / 4,   γ = ½ − α.

    Args:
        mass: Mass.
        constitutive_model: Nonlinear constitutive model.
        load: Load array ``(seq_len,)`` or ``(batch, seq_len)``.
        time: Time array.
        damping_ratio: Damping ratio. Defaults to 0.05.
        disp_0: Initial displacement. Defaults to 0.
        vel_0: Initial velocity. Defaults to 0.
        alpha: HHT-α parameter ( ∈ [-⅓, 0]). Defaults to -0.1.
        result_len: Output length. Defaults to ``len(time)``.
        max_iter: Max Newton‑Raphson iterations per step. Defaults to 10.
        tol: Convergence tolerance on residual force. Defaults to 1e-6.

    Returns:
        ``(disp, vel, acc)`` arrays.
    """
    if alpha > 0 or alpha < -1.0 / 3.0:
        raise ValueError("alpha must be in [-1/3, 0]")

    gamma = 0.5 - alpha
    beta = (1.0 - alpha) ** 2 / 4.0

    seq_len = load.shape[-1]
    if result_len == 0:
        result_len = len(time)

    load = _add_batch_dim(load)
    load = adjust_length(load, seq_len, result_len, axis=-1)
    batch_size = load.shape[0]
    models = _ensure_nl_batch(constitutive_model, batch_size)

    omega_n = np.sqrt(np.mean([m.initial_stiffness for m in models]) / mass)
    damping = 2.0 * mass * omega_n * damping_ratio

    acc_0 = np.zeros(batch_size)
    for b in range(batch_size):
        f_s, _ = models[b].update(disp_0)
        acc_0[b] = (load[b, 0] - damping * vel_0 - f_s) / mass
    disp, vel, acc = _init_response(result_len, batch_size, disp_0, vel_0, acc_0)

    for b in range(batch_size):
        models[b].reset()
        models[b].update(disp_0)

    for i in range(result_len - 1):
        dti = time[i + 1] - time[i]
        a_0 = 1.0 / (beta * dti * dti)
        a_1 = gamma / (beta * dti)
        a_2 = 1.0 / (beta * dti)
        a_3 = 1.0 / (2.0 * beta) - 1.0
        a_6 = dti * (1.0 - gamma)
        a_7 = gamma * dti

        for b in range(batch_size):
            model_snap = dict(vars(models[b]))
            d_new = disp[b, i]
            v_new = vel[b, i]
            acc_old = acc[b, i]

            for _ in range(max_iter):
                for key, val in model_snap.items():
                    setattr(models[b], key, val)

                f_s, k_t = models[b].update(d_new)
                a_new = a_0 * (d_new - disp[b, i]) - a_2 * vel[b, i] - a_3 * acc[b, i]
                v_new = vel[b, i] + a_6 * acc[b, i] + a_7 * a_new

                residual = (
                    (1.0 + alpha) * load[b, i + 1]
                    - alpha * load[b, i]
                    - mass * a_new
                    - (1.0 + alpha) * damping * v_new
                    + alpha * damping * vel[b, i]
                    - (1.0 + alpha) * f_s
                    + alpha * models[b].update(disp[b, i])[0]
                )

                if abs(residual) < tol:
                    break

                K_eff = (1.0 + alpha) * k_t + a_0 * mass + (1.0 + alpha) * a_1 * damping
                d_new += residual / K_eff

            disp[b, i + 1] = d_new
            vel[b, i + 1] = v_new
            acc[b, i + 1] = a_new

            for key, val in model_snap.items():
                setattr(models[b], key, val)
            models[b].update(d_new)

    if batch_size == 1:
        disp = disp[0]
        vel = vel[0]
        acc = acc[0]

    return disp, vel, acc


def sdof_nonlinear_newmark_beta(
    mass: float,
    constitutive_model: ConstitutiveModel | List[ConstitutiveModel],
    load: np.ndarray,
    time: np.ndarray,
    *,
    damping_ratio: float = 0.05,
    disp_0: float = 0.0,
    vel_0: float = 0.0,
    beta: float = 0.25,
    gamma: float = 0.5,
    result_len: int = 0,
    max_iter: int = 10,
    tol: float = 1e-6,
    **kwargs: object,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Newmark-β method for a nonlinear SDOF with Newton‑Raphson iteration.

    Equilibrium iteration is performed at every time step until the
    residual force falls below ``tol`` or the maximum iteration count
    is reached.

    Args:
        mass: Mass.
        constitutive_model: Nonlinear constitutive model.  Pass a list
            (one per batch) for batched computation.
        load: Load array of shape ``(seq_len,)`` or ``(batch, seq_len)``.
        time: Time array.
        damping_ratio: Damping ratio.  Defaults to 0.05.
        disp_0: Initial displacement.  Defaults to 0.0.
        vel_0: Initial velocity.  Defaults to 0.0.
        beta: Newmark-β parameter.  Defaults to 0.25.
        gamma: Newmark-γ parameter.  Defaults to 0.5.
        result_len: Length of output arrays.  Defaults to ``len(time)``.
        max_iter: Maximum Newton‑Raphson iterations per time step.
            Defaults to 10.
        tol: Convergence tolerance on the residual force.
            Defaults to 1e-6.

    Returns:
        Tuple of ``(disp, vel, acc)`` arrays, each of shape
        ``(result_len,)`` or ``(batch, result_len)``.
    """
    seq_len = load.shape[-1]

    if result_len == 0:
        result_len = len(time)

    load = _add_batch_dim(load)
    load = adjust_length(load, seq_len, result_len, axis=-1)
    batch_size = load.shape[0]

    models = _ensure_nl_batch(constitutive_model, batch_size)

    omega_n = np.sqrt(np.mean([m.initial_stiffness for m in models]) / mass)
    damping = 2.0 * mass * omega_n * damping_ratio

    acc_0 = np.zeros(batch_size)
    for b in range(batch_size):
        f_s, _ = models[b].update(disp_0)
        acc_0[b] = (load[b, 0] - damping * vel_0 - f_s) / mass

    disp, vel, acc = _init_response(result_len, batch_size, disp_0, vel_0, acc_0)

    for i in range(result_len - 1):
        dti = time[i + 1] - time[i]

        a_0 = 1.0 / (beta * dti * dti)
        a_1 = gamma / (beta * dti)
        a_2 = 1.0 / (beta * dti)
        a_3 = 1.0 / (2.0 * beta) - 1.0
        a_6 = dti * (1.0 - gamma)
        a_7 = gamma * dti

        for b in range(batch_size):
            model_snap = dict(vars(models[b]))

            d_new = disp[b, i]
            v_new = vel[b, i]

            for _ in range(max_iter):
                for key, val in model_snap.items():
                    setattr(models[b], key, val)

                f_s, k_t = models[b].update(d_new)

                a_new = a_0 * (d_new - disp[b, i]) - a_2 * vel[b, i] - a_3 * acc[b, i]
                v_new = vel[b, i] + a_6 * acc[b, i] + a_7 * a_new

                residual = load[b, i + 1] - mass * a_new - damping * v_new - f_s

                if abs(residual) < tol:
                    break

                K_eff = k_t + a_0 * mass + a_1 * damping
                d_new += residual / K_eff

            disp[b, i + 1] = d_new
            vel[b, i + 1] = v_new
            acc[b, i + 1] = (
                a_0 * (d_new - disp[b, i]) - a_2 * vel[b, i] - a_3 * acc[b, i]
            )

            for key, val in model_snap.items():
                setattr(models[b], key, val)
            models[b].update(d_new)

    if batch_size == 1:
        disp = disp[0]
        vel = vel[0]
        acc = acc[0]

    return disp, vel, acc
