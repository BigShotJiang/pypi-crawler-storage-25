"""Adaptive time-stepping integration for MDOF systems.

- Adaptive Newmark-β: half-step error estimation with sub-stepping
- Adaptive RK45: explicit embedded Runge-Kutta 5(4) for MDOF
"""

from __future__ import annotations

from typing import List, Tuple

import numpy as np
from scipy.linalg import solve

from structural_dynamic_tools.modeling import rayleigh
from structural_dynamic_tools.constitutive import ConstitutiveModel


def _assemble_restoring_force_mdof_adaptive(
    models: List[ConstitutiveModel], disp: np.ndarray
) -> Tuple[np.ndarray, np.ndarray]:
    freedom = len(models)
    force = np.empty(freedom)
    k_tangent = np.empty(freedom)
    for j in range(freedom):
        f_s, k_t = models[j].update(disp[j])
        force[j] = f_s
        k_tangent[j] = k_t
    return force, k_tangent


def mdof_adaptive_newmark(
    mass: np.ndarray,
    stiffness: np.ndarray,
    constitutive_models: List[ConstitutiveModel],
    load: np.ndarray,
    time: np.ndarray,
    *,
    damping_ratio: float | np.ndarray = 0.05,
    disp_0: np.ndarray | None = None,
    vel_0: np.ndarray | None = None,
    beta: float = 0.25,
    gamma: float = 0.5,
    rtol: float = 1e-6,
    max_iter: int = 10,
    max_substeps: int = 8,
    **kwargs: object,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Adaptive Newmark-β for nonlinear MDOF with sub-stepping.

    When Newton‑Raphson fails to converge, the integration step is
    successively halved (up to ``max_substeps`` times), ensuring robust
    passage through strong nonlinearities.

    Args:
        mass: Mass matrix (freedom, freedom).
        stiffness: Stiffness matrix (freedom, freedom).
        constitutive_models: One model per DOF.
        load: Load array (seq_len, freedom).
        time: Time array.
        damping_ratio: Damping ratio or damping matrix.
        disp_0: Initial displacement.
        vel_0: Initial velocity.
        beta, gamma: Newmark parameters.
        rtol: Convergence tolerance.
        max_iter: Max NR iterations per sub-step.
        max_substeps: Max number of sub-step divisions.

    Returns:
        ``(disp, vel, acc)`` arrays.
    """
    freedom = mass.shape[0]
    n = len(time)

    if disp_0 is None:
        disp_0 = np.zeros(freedom)
    if vel_0 is None:
        vel_0 = np.zeros(freedom)

    if isinstance(damping_ratio, np.ndarray):
        damping = damping_ratio
    else:
        damping = rayleigh(mass, stiffness, damping_ratio)

    for m in constitutive_models:
        m.reset()

    disp = np.zeros((n, freedom))
    vel = np.zeros((n, freedom))
    acc = np.zeros((n, freedom))
    disp[0] = disp_0
    vel[0] = vel_0

    f_s0, _ = _assemble_restoring_force_mdof_adaptive(constitutive_models, disp_0)
    acc[0] = solve(mass, load[0, :] - damping @ vel_0 - f_s0)

    for i in range(n - 1):
        dt = time[i + 1] - time[i]
        sub_div = 0

        while sub_div <= max_substeps:
            dt_sub = dt / (2 ** sub_div)
            if dt_sub < 1e-12:
                break

            a_0 = 1.0 / (beta * dt_sub * dt_sub)
            a_1 = gamma / (beta * dt_sub)
            a_2 = 1.0 / (beta * dt_sub)
            a_3 = 1.0 / (2.0 * beta) - 1.0
            a_6 = dt_sub * (1.0 - gamma)
            a_7 = gamma * dt_sub

            d_current = disp[i].copy()
            v_current = vel[i].copy()
            a_current = acc[i].copy()
            step_ok = True

            for k_step in range(2 ** sub_div):
                alpha_p = (k_step + 1) / (2 ** sub_div)
                p_mid = load[i, :] + (load[i + 1, :] - load[i, :]) * alpha_p

                model_snap = [dict(vars(m)) for m in constitutive_models]

                d_new = d_current.copy()
                v_new = v_current.copy()

                for _ in range(max_iter):
                    for m, snap in zip(constitutive_models, model_snap):
                        for key, val in snap.items():
                            setattr(m, key, val)

                    f_s, k_t_diag = _assemble_restoring_force_mdof_adaptive(constitutive_models, d_new)

                    a_new = a_0 * (d_new - d_current) - a_2 * v_current - a_3 * a_current
                    v_new = v_current + a_6 * a_current + a_7 * a_new

                    residual = p_mid - mass @ a_new - damping @ v_new - f_s

                    if np.max(np.abs(residual)) < rtol:
                        break

                    k_t_mat = np.diag(k_t_diag)
                    K_eff = k_t_mat + a_0 * mass + a_1 * damping
                    delta_d = solve(K_eff, residual)
                    d_new += delta_d
                else:
                    step_ok = False
                    break

                d_current, v_current, a_current = d_new, v_new, a_new

                for m, snap in zip(constitutive_models, model_snap):
                    for key, val in snap.items():
                        setattr(m, key, val)
                _assemble_restoring_force_mdof_adaptive(constitutive_models, d_new)

            if step_ok:
                disp[i + 1] = d_current
                vel[i + 1] = v_current
                acc[i + 1] = a_current
                break
            sub_div += 1

    return disp, vel, acc


def mdof_adaptive_rk45(
    mass: np.ndarray,
    stiffness: np.ndarray,
    constitutive_models: List[ConstitutiveModel],
    load: np.ndarray,
    time: np.ndarray,
    *,
    damping_ratio: float | np.ndarray = 0.05,
    disp_0: np.ndarray | None = None,
    vel_0: np.ndarray | None = None,
    rtol: float = 1e-6,
    atol: float = 1e-9,
    dt_min: float = 1e-8,
    **kwargs: object,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Adaptive RK45 for nonlinear MDOF.

    Dormand-Prince 5(4) explicit embedded pair with automatic step-size
    control. State vector is [d_0, ..., d_n, v_0, ..., v_n].

    Args:
        mass: Mass matrix.
        stiffness: Stiffness matrix.
        constitutive_models: One model per DOF.
        load: Load array (seq_len, freedom).
        time: Output time points.
        damping_ratio: Damping ratio or matrix.
        disp_0, vel_0: Initial conditions.
        rtol, atol: Tolerances.
        dt_min: Minimum allowable step.

    Returns:
        ``(disp, vel, acc, t_out)`` arrays.
    """
    freedom = mass.shape[0]
    n_out = len(time)

    if disp_0 is None:
        disp_0 = np.zeros(freedom)
    if vel_0 is None:
        vel_0 = np.zeros(freedom)

    if isinstance(damping_ratio, np.ndarray):
        damping = damping_ratio
    else:
        damping = rayleigh(mass, stiffness, damping_ratio)

    for m in constitutive_models:
        m.reset()

    t_start = time[0]
    avg_dt = (time[-1] - t_start) / max(n_out - 1, 1)
    dt_max = 10.0 * avg_dt

    disp_out = np.zeros((n_out, freedom))
    vel_out = np.zeros((n_out, freedom))
    acc_out = np.zeros((n_out, freedom))
    t_out = time.copy()
    disp_out[0] = disp_0
    vel_out[0] = vel_0
    f_s0, _ = _assemble_restoring_force_mdof_adaptive(constitutive_models, disp_0)
    acc_out[0] = solve(mass, load[0, :] - damping @ vel_0 - f_s0)

    t = t_start
    y = np.concatenate([disp_0, vel_0])
    h = avg_dt * 0.1
    out_idx = 1

    def rhs(t_val: float, y_vec: np.ndarray) -> np.ndarray:
        d = y_vec[:freedom]
        v = y_vec[freedom:]
        f_s, _ = _assemble_restoring_force_mdof_adaptive(constitutive_models, d)
        idx = np.searchsorted(time, t_val)
        if idx >= n_out:
            idx = n_out - 1
        if idx == 0:
            p = load[0, :]
        else:
            alpha_l = (t_val - time[idx - 1]) / max(time[idx] - time[idx - 1], 1e-12)
            p = load[idx - 1, :] + (load[idx, :] - load[idx - 1, :]) * min(max(alpha_l, 0.0), 1.0)
        a = solve(mass, p - damping @ v - f_s)
        return np.concatenate([v, a])

    while t < time[-1] and out_idx < n_out:
        h = min(h, time[out_idx] - t)
        if h < dt_min:
            h = dt_min

        k1 = rhs(t, y)
        k2 = rhs(t + h / 5, y + h * (k1 / 5))
        k3 = rhs(t + 3 * h / 10, y + h * (3 * k1 / 40 + 9 * k2 / 40))
        k4 = rhs(t + 4 * h / 5, y + h * (44 * k1 / 45 - 56 * k2 / 15 + 32 * k3 / 9))
        k5 = rhs(t + 8 * h / 9, y + h * (
            19372 * k1 / 6561 - 25360 * k2 / 2187 + 64448 * k3 / 6561 - 212 * k4 / 729
        ))
        k6 = rhs(t + h, y + h * (
            9017 * k1 / 3168 - 355 * k2 / 33 + 46732 * k3 / 5247
            + 49 * k4 / 176 - 5103 * k5 / 18656
        ))

        y5 = y + h * (35 * k1 / 384 + 500 * k3 / 1113 + 125 * k4 / 192
                      - 2187 * k5 / 6784 + 11 * k6 / 84)
        y4 = y + h * (5179 * k1 / 57600 + 7571 * k3 / 16695 + 393 * k4 / 640
                      - 92097 * k5 / 339200 + 187 * k6 / 2100 + k1 / 40)

        err = np.max(np.abs(y5 - y4) / (atol + rtol * np.maximum(np.abs(y), np.abs(y5))))

        if err <= 1.0:
            t += h
            y = y5
            while out_idx < n_out and t >= time[out_idx] - 1e-12:
                disp_out[out_idx] = y[:freedom]
                vel_out[out_idx] = y[freedom:]
                f_s, _ = _assemble_restoring_force_mdof_adaptive(constitutive_models, y[:freedom])
                acc_out[out_idx] = solve(mass, load[out_idx, :] - damping @ y[freedom:] - f_s)
                out_idx += 1

        h_new = h * min(5.0, max(0.1, 0.9 / max(err, 1e-12) ** 0.2))
        h = min(max(h_new, dt_min), dt_max)

    return disp_out, vel_out, acc_out, t_out
