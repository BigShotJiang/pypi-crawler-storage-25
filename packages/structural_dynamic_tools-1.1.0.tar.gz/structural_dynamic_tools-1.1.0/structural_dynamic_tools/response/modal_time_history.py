"""Modal decomposition and superposition methods for time history analysis.

Implements Fourier transform method, mode superposition method, and complex
modal analysis method for computing dynamic time history responses of MDOF
linear systems.
"""

import numpy as np
from scipy.linalg import eigh, eig


def fourier_response(
    mass: float,
    stiffness: float,
    load: np.ndarray,
    delta_time: float,
    damping_ratio: float = 0.05,
) -> np.ndarray:
    """
    Fourier transform method for SDOF seismic response.

    Solves the equation of motion in the frequency domain via FFT, then
    transforms back to the time domain.

    Args:
        mass: Modal mass.
        stiffness: Modal stiffness.
        load: Load time history array.
        delta_time: Time step.
        damping_ratio: Damping ratio. Defaults to 0.05.

    Returns:
        Displacement response time history.
    """
    load_fft = np.fft.fft(load)
    omega_n = np.sqrt(stiffness / mass)
    n = len(load_fft)
    result = np.zeros(n, dtype=complex)

    for i in range(n):
        omega = 2 * np.pi * i / (delta_time * n)
        h = (
            complex(
                1 - (omega / omega_n) ** 2,
                2 * damping_ratio * (omega / omega_n),
            )
            * stiffness
        )
        result[i] = load_fft[i] / h

    result = np.fft.ifft(result)
    return 2 * result.real


def modal_superposition(
    mass: np.ndarray,
    stiffness: np.ndarray,
    load: np.ndarray,
    delta_time: float,
    damping_ratio: float = 0.05,
) -> np.ndarray:
    """
    Mode superposition method for MDOF linear time history analysis.

    Transforms the coupled MDOF system into decoupled SDOF modal equations,
    solves each mode independently using Fourier transform, then transforms
    back to physical coordinates.

    Args:
        mass: Mass matrix (n x n).
        stiffness: Stiffness matrix (n x n).
        load: Load matrix (n_steps x n), each row is the load vector at a
            time step.
        delta_time: Time step.
        damping_ratio: Uniform damping ratio for all modes. Defaults to 0.05.

    Returns:
        Displacement response matrix (n_steps x n), each row is the
        displacement vector at a time step.
    """
    n_dof = mass.shape[0]
    n_steps = len(load)

    omega_sq, phi = eigh(stiffness, mass)
    idx = omega_sq.argsort()
    omega_sq = omega_sq[idx]
    phi = phi[:, idx]

    modal_mass = np.diag(phi.T @ mass @ phi)
    modal_stiffness = np.diag(phi.T @ stiffness @ phi)
    modal_load = np.array([phi.T @ load[i] for i in range(n_steps)])

    dpm = np.zeros((n_steps, n_dof))
    for i in range(n_dof):
        dpm[:, i] = fourier_response(
            modal_mass[i],
            modal_stiffness[i],
            modal_load[:, i],
            delta_time,
            damping_ratio,
        )

    for i in range(n_steps):
        dpm[i] = phi @ dpm[i]

    return dpm


def complex_modal_superposition(
    mass: np.ndarray,
    stiffness: np.ndarray,
    load: np.ndarray,
    delta_time: float,
    damping: np.ndarray,
    influence_vector: np.ndarray | None = None,
) -> np.ndarray:
    """
    Complex modal analysis method for non-proportionally damped MDOF systems.

    Constructs a 2N-dimensional state-space eigenvalue problem via generalized
    eigenvalue decomposition of the complex stiffness and mass matrices,
    then solves using complex mode superposition.

    Args:
        mass: Mass matrix (n x n).
        stiffness: Stiffness matrix (n x n).
        load: Load time history array (n_steps,).
        delta_time: Time step.
        damping: Damping matrix (n x n).
        influence_vector: Influence vector for base excitation (n,).
            Defaults to [0, ..., 0, 1] (excitation at the lowest story).

    Returns:
        Displacement response matrix (n_steps x n), each row is the
        displacement vector at a time step.
    """
    n_dof = mass.shape[0]
    n_steps = len(load)

    if influence_vector is None:
        influence_vector = np.zeros(n_dof)
        influence_vector[-1] = 1

    zero_mat = np.zeros((n_dof, n_dof))

    mass_row1 = np.hstack((damping, mass))
    mass_row2 = np.hstack((mass, zero_mat))
    mass_complex = np.vstack((mass_row1, mass_row2))

    stiffness_row1 = np.hstack((stiffness, zero_mat))
    stiffness_row2 = np.hstack((zero_mat, -mass))
    stiffness_complex = np.vstack((stiffness_row1, stiffness_row2))

    unit_complex = np.hstack((np.zeros(n_dof), influence_vector))

    lambda_full, phi_full = eig(stiffness_complex, mass_complex)

    real_lambda = lambda_full[0::2]
    complex_lambda = lambda_full[1::2]
    real_phi = phi_full[:, 0::2]
    complex_phi = phi_full[:, 1::2]
    lambda_ = np.hstack((real_lambda, complex_lambda))
    phi = np.hstack((real_phi, complex_phi))

    a = np.zeros(2 * n_dof, dtype=complex)
    nita = np.zeros(2 * n_dof, dtype=complex)
    for i in range(2 * n_dof):
        a[i] = phi[:, i].T @ mass_complex @ phi[:, i]
        nita[i] = phi[:, i].T @ mass_complex @ unit_complex / a[i]

    dpm = np.zeros((n_steps, n_dof), dtype=complex)

    for i in range(2 * n_dof):
        quad = 0 + 0j
        dpm_temp = np.zeros((n_steps, n_dof), dtype=complex)
        for j in range(n_steps):
            quad += np.exp(lambda_[i] * j * delta_time) * load[j] * delta_time
            dpm_temp[j] = (
                phi[:n_dof, i] * nita[i] * np.exp(-lambda_[i] * j * delta_time) * quad
            )
        dpm += dpm_temp

    return np.real(dpm)
