"""Single Degree of Freedom Linear Time Integration Methods."""

from typing import Tuple, Callable

import numpy as np
from scipy import integrate
from multiprocessing import Pool

from structural_dynamic_tools.utils.wave_utils import adjust_length


def _add_batch_dim(load: np.ndarray) -> np.ndarray:
    """Ensure load has batch dimension: returns (batch, seq_len)."""
    if load.ndim == 1:
        return load[np.newaxis, :]
    return load


def _init_response(
    result_len: int,
    batch_size: int,
    disp_0: float,
    vel_0: float,
    acc_0: float | None = None,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    disp = np.zeros((batch_size, result_len))
    vel = np.zeros((batch_size, result_len))
    acc = np.zeros((batch_size, result_len)) if acc_0 is not None else None
    disp[:, 0] = disp_0
    vel[:, 0] = vel_0
    if acc_0 is not None:
        acc[:, 0] = acc_0
    return disp, vel, acc


def sdof_linear_duhamel_parse(
    mass: float,
    stiffness: float,
    load: Callable[[float], float],
    time: np.ndarray,
    *,
    damping_ratio: float = 0.05,
    **kwargs,
) -> np.ndarray:
    """
    Duhamel integral for single DOF system with analytical load.

    Args:
        mass: Mass of the system
        stiffness: Stiffness of the system
        load: Load function (callable)
        time: Time array
        damping_ratio: Damping ratio. Defaults to 0.05.

    Returns:
        Displacement response array
    """
    result_len = len(time)

    omega_n = np.sqrt(stiffness / mass)
    omega_d = omega_n * np.sqrt(1 - damping_ratio**2)
    disp = np.zeros(result_len)

    def integrand(tau: float, t: float) -> float:
        return (
            load(tau)
            * np.exp(-damping_ratio * omega_n * (t - tau))
            * np.sin(omega_d * (t - tau))
        )

    for i in range(result_len):
        t = time[i]
        disp[i] = 1 / omega_d * integrate.quad(integrand, 0, t, args=(t,))[0]

    return disp


def sdof_linear_duhamel_numerical(
    mass: float,
    stiffness: float,
    load: np.ndarray,
    time: np.ndarray,
    *,
    damping_ratio: float = 0.05,
    result_len: int = 0,
    **kwargs,
) -> np.ndarray:
    """
    Numerical Duhamel integral for single DOF system.

    Supports non-uniform time steps and batch computation.

    Args:
        mass: Mass of the system
        stiffness: Stiffness of the system
        load: Load array of shape (seq_len,) or (batch, seq_len).
        time: Time array
        damping_ratio: Damping ratio. Defaults to 0.05.
        result_len: Length of the result array. Defaults to len(time).

    Returns:
        Displacement response array of shape (result_len,) or (batch, result_len).
    """
    seq_len = load.shape[-1]

    if result_len == 0:
        result_len = len(time)

    load = _add_batch_dim(load)
    load = adjust_length(load, seq_len, result_len, axis=-1)
    batch_size = load.shape[0]

    omega_n = np.sqrt(stiffness / mass)
    omega_d = omega_n * np.sqrt(1 - damping_ratio**2)
    disp = np.zeros((batch_size, result_len))

    for i in range(result_len):
        t = time[i]
        disp_temp = np.zeros(batch_size)
        for j in range(i):
            tau = time[j]
            dti = time[j + 1] - time[j] if j + 1 < result_len else time[j] - time[j - 1]
            disp_temp += (
                load[:, j]
                * np.exp(-damping_ratio * omega_n * (t - tau))
                * np.sin(omega_d * (t - tau))
                * dti
            )
        disp[:, i] = disp_temp / (omega_d * mass)

    if batch_size == 1:
        disp = disp[0]

    return disp


def _duhamel_numerical_kernel(
    i: int,
    time: np.ndarray,
    load: np.ndarray,
    damping_ratio: float,
    omega_n: float,
    omega_d: float,
) -> float:
    """Kernel function for parallel Duhamel numerical integration."""
    t = time[i]
    disp_temp = 0.0
    for j in range(i):
        tau = time[j]
        dti = time[j + 1] - time[j] if j + 1 < len(time) else time[j] - time[j - 1]
        disp_temp += (
            load[j]
            * np.exp(-damping_ratio * omega_n * (t - tau))
            * np.sin(omega_d * (t - tau))
            * dti
        )
    return disp_temp


def sdof_linear_duhamel_numerical_multiprocess(
    mass: float,
    stiffness: float,
    load: np.ndarray,
    time: np.ndarray,
    *,
    damping_ratio: float = 0.05,
    num_workers: int = 8,
    **kwargs,
) -> np.ndarray:
    """
    Parallel numerical Duhamel integral for single DOF system.

    Args:
        mass: Mass of the system
        stiffness: Stiffness of the system
        load: Load array of shape (seq_len,).
        time: Time array
        damping_ratio: Damping ratio. Defaults to 0.05.
        num_workers: Number of parallel workers. Defaults to 8.

    Returns:
        Displacement response array
    """
    seq_len = len(load)
    omega_n = np.sqrt(stiffness / mass)
    omega_d = omega_n * np.sqrt(1 - damping_ratio**2)
    disp = np.zeros(seq_len)

    with Pool(num_workers) as pool:
        process_list = []
        for i in range(seq_len):
            process_list.append(
                pool.apply_async(
                    func=_duhamel_numerical_kernel,
                    args=(i, time, load, damping_ratio, omega_n, omega_d),
                )
            )

        for i in range(seq_len):
            disp_temp = process_list[i].get()
            disp[i] = disp_temp / (omega_d * mass)
            print(f"\rcalculated time: {time[i]:.3f}, disp = {disp[i]:.6f}", end="")

    return disp


def sdof_linear_segmented_parse(
    mass: float,
    stiffness: float,
    load: np.ndarray,
    time: np.ndarray,
    *,
    damping_ratio: float = 0.05,
    disp_0: float = 0.0,
    vel_0: float = 0.0,
    result_len: int = 0,
    **kwargs,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Segmented parsing method for single DOF system.

    Supports non-uniform time steps and batch computation.

    Args:
        mass: Mass of the system
        stiffness: Stiffness of the system
        load: Load array of shape (seq_len,) or (batch, seq_len).
        time: Time array
        damping_ratio: Damping ratio. Defaults to 0.05.
        disp_0: Initial displacement. Defaults to 0.0.
        vel_0: Initial velocity. Defaults to 0.0.
        result_len: Length of the result array. Defaults to len(time).

    Returns:
        Tuple containing displacement, velocity, and acceleration arrays,
        each of shape (result_len,) or (batch, result_len).
    """
    seq_len = load.shape[-1]

    if result_len == 0:
        result_len = len(time)

    load = _add_batch_dim(load)
    load = adjust_length(load, seq_len, result_len, axis=-1)
    batch_size = load.shape[0]

    omega_n = np.sqrt(stiffness / mass)
    damping = 2 * mass * omega_n * damping_ratio

    disp, vel, acc = _init_response(result_len, batch_size, disp_0, vel_0, 0.0)

    for i in range(result_len - 1):
        dti = time[i + 1] - time[i]

        omega_d = omega_n * np.sqrt(1 - damping_ratio**2)
        temp_1 = np.exp(-damping_ratio * omega_n * dti)
        temp_2 = damping_ratio / np.sqrt(1 - damping_ratio**2)
        temp_3 = 2 * damping_ratio / (omega_n * dti)
        temp_4 = (1 - 2 * damping_ratio**2) / (omega_d * dti)
        temp_5 = omega_n / np.sqrt(1 - damping_ratio**2)
        sin_val = np.sin(omega_d * dti)
        cos_val = np.cos(omega_d * dti)

        A = temp_1 * (temp_2 * sin_val + cos_val)
        B = temp_1 * (sin_val / omega_d)
        C = (
            1
            / stiffness
            * (temp_3 + temp_1 * ((temp_4 - temp_2) * sin_val - (1 + temp_3) * cos_val))
        )
        D = (
            1
            / stiffness
            * (1 - temp_3 + temp_1 * (-temp_4 * sin_val + temp_3 * cos_val))
        )
        A_prime = -temp_1 * (temp_5 * sin_val)
        B_prime = temp_1 * (cos_val - temp_2 * sin_val)
        C_prime = (
            1
            / stiffness
            * (
                -1 / dti
                + temp_1 * ((temp_5 + temp_2 / dti) * sin_val + 1 / dti * cos_val)
            )
        )
        D_prime = 1 / (stiffness * dti) * (1 - temp_1 * (temp_2 * sin_val + cos_val))

        disp[:, i + 1] = (
            A * disp[:, i] + B * vel[:, i] + C * load[:, i] + D * load[:, i + 1]
        )
        vel[:, i + 1] = (
            A_prime * disp[:, i]
            + B_prime * vel[:, i]
            + C_prime * load[:, i]
            + D_prime * load[:, i + 1]
        )
        acc[:, i + 1] = (
            load[:, i + 1] - damping * vel[:, i + 1] - stiffness * disp[:, i + 1]
        ) / mass

    if batch_size == 1:
        disp = disp[0]
        vel = vel[0]
        acc = acc[0]

    return disp, vel, acc


def sdof_linear_center_diff(
    mass: float,
    stiffness: float,
    load: np.ndarray,
    time: np.ndarray,
    *,
    damping_ratio: float = 0.05,
    disp_0: float = 0.0,
    vel_0: float = 0.0,
    result_len: int = 0,
    **kwargs,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Central difference method for single DOF system.

    Supports non-uniform time steps and batch computation.

    Args:
        mass: Mass of the system
        stiffness: Stiffness of the system
        load: Load array of shape (seq_len,) or (batch, seq_len).
        time: Time array
        damping_ratio: Damping ratio. Defaults to 0.05.
        disp_0: Initial displacement. Defaults to 0.0.
        vel_0: Initial velocity. Defaults to 0.0.
        result_len: Length of the result array. Defaults to len(time).

    Returns:
        Tuple containing displacement, velocity, and acceleration arrays,
        each of shape (result_len,) or (batch, result_len).
    """
    seq_len = load.shape[-1]

    if result_len == 0:
        result_len = len(time)

    load = _add_batch_dim(load)
    load = adjust_length(load, seq_len, result_len, axis=-1)
    batch_size = load.shape[0]

    omega_n = np.sqrt(stiffness / mass)
    damping = 2 * mass * omega_n * damping_ratio

    dt0 = time[1] - time[0]
    acc_0 = (load[:, 0] - damping * vel_0 - stiffness * disp_0) / mass
    disp_minus1 = disp_0 - dt0 * vel_0 + dt0**2 * acc_0 / 2

    disp, vel, acc = _init_response(result_len, batch_size, disp_0, vel_0, 0.0)

    equ_k0 = mass / dt0**2 + damping / (2 * dt0)
    a_mat0 = (2 * mass) / dt0**2
    b_mat0 = mass / dt0**2 - damping / (2 * dt0)
    equ_p0 = load[:, 0] - (stiffness - a_mat0) * disp_0 - b_mat0 * disp_minus1
    disp[:, 1] = equ_p0 / equ_k0
    vel[:, 0] = (disp[:, 1] - disp_minus1) / (2 * dt0)
    acc[:, 0] = (disp[:, 1] - 2 * disp[:, 0] + disp_minus1) / dt0**2

    for i in range(1, result_len - 1):
        dti = time[i + 1] - time[i]

        equ_k = mass / dti**2 + damping / (2 * dti)
        a_mat = (2 * mass) / dti**2
        b_mat = mass / dti**2 - damping / (2 * dti)

        equ_p = load[:, i] - (stiffness - a_mat) * disp[:, i] - b_mat * disp[:, i - 1]
        disp[:, i + 1] = equ_p / equ_k
        vel[:, i] = (disp[:, i + 1] - disp[:, i - 1]) / (2 * dti)
        acc[:, i] = (disp[:, i + 1] - 2 * disp[:, i] + disp[:, i - 1]) / dti**2

    if batch_size == 1:
        disp = disp[0]
        vel = vel[0]
        acc = acc[0]

    return disp, vel, acc


def sdof_linear_newmark_beta(
    mass: float,
    stiffness: float,
    load: np.ndarray,
    time: np.ndarray,
    *,
    damping_ratio: float = 0.05,
    disp_0: float = 0.0,
    vel_0: float = 0.0,
    acc_0: float = 0.0,
    beta: float = 0.25,
    gamma: float = 0.5,
    result_len: int = 0,
    **kwargs,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Newmark-beta method for single DOF system.

    Supports non-uniform time steps and batch computation.

    Args:
        mass: Mass of the system
        stiffness: Stiffness of the system
        load: Load array of shape (seq_len,) or (batch, seq_len).
        time: Time array
        damping_ratio: Damping ratio. Defaults to 0.05.
        disp_0: Initial displacement. Defaults to 0.0.
        vel_0: Initial velocity. Defaults to 0.0.
        acc_0: Initial acceleration. Defaults to 0.0.
        beta: Beta parameter. Defaults to 0.25.
        gamma: Gamma parameter. Defaults to 0.5.
        result_len: Length of the result array. Defaults to len(time).

    Returns:
        Tuple containing displacement, velocity, and acceleration arrays,
        each of shape (result_len,) or (batch, result_len).
    """
    seq_len = load.shape[-1]

    if result_len == 0:
        result_len = len(time)

    load = _add_batch_dim(load)
    load = adjust_length(load, seq_len, result_len, axis=-1)
    batch_size = load.shape[0]

    omega_n = np.sqrt(stiffness / mass)
    damping = 2 * mass * omega_n * damping_ratio

    disp, vel, acc = _init_response(result_len, batch_size, disp_0, vel_0, acc_0)

    for i in range(result_len - 1):
        dti = time[i + 1] - time[i]

        a_0 = 1 / (beta * dti**2)
        a_1 = gamma / (beta * dti)
        a_2 = 1 / (beta * dti)
        a_3 = 1 / (2 * beta) - 1
        a_4 = gamma / beta - 1
        a_5 = dti / 2 * (a_4 - 1)
        a_6 = dti * (1 - gamma)
        a_7 = gamma * dti

        equ_k = stiffness + a_0 * mass + a_1 * damping

        equ_p = (
            load[:, i + 1]
            + mass * (a_0 * disp[:, i] + a_2 * vel[:, i] + a_3 * acc[:, i])
            + damping * (a_1 * disp[:, i] + a_4 * vel[:, i] + a_5 * acc[:, i])
        )
        disp[:, i + 1] = equ_p / equ_k
        acc[:, i + 1] = (
            a_0 * (disp[:, i + 1] - disp[:, i]) - a_2 * vel[:, i] - a_3 * acc[:, i]
        )
        vel[:, i + 1] = vel[:, i] + a_6 * acc[:, i] + a_7 * acc[:, i + 1]

    if batch_size == 1:
        disp = disp[0]
        vel = vel[0]
        acc = acc[0]

    return disp, vel, acc
