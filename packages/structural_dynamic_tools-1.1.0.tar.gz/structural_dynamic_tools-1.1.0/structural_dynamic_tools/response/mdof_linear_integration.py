"""Multiple Degree of Freedom Linear Time Integration Methods."""

from typing import Tuple

import numpy as np
from scipy.linalg import solve

from structural_dynamic_tools.modeling import rayleigh
from structural_dynamic_tools.utils.wave_utils import adjust_length


def _add_batch_dim(load: np.ndarray) -> np.ndarray:
    """Ensure load has batch dimension: returns (batch, seq_len, freedom)."""
    if load.ndim == 2:
        return load[np.newaxis, ...]
    return load


def _init_response(
    result_len: int,
    freedom: int,
    batch_size: int,
    disp_0: np.ndarray,
    vel_0: np.ndarray,
    acc_0: np.ndarray | None = None,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:

    disp = np.zeros((batch_size, result_len, freedom))
    vel = np.zeros((batch_size, result_len, freedom))
    acc = np.zeros((batch_size, result_len, freedom)) if acc_0 is not None else None
    disp[:, 0, :] = np.broadcast_to(disp_0, (batch_size, freedom))
    vel[:, 0, :] = np.broadcast_to(vel_0, (batch_size, freedom))
    if acc_0 is not None:
        acc[:, 0, :] = np.broadcast_to(acc_0, (batch_size, freedom))
    return disp, vel, acc


def _adjust_load_mdof(
    load: np.ndarray, seq_len: int, result_len: int, axis: int
) -> np.ndarray:
    return adjust_length(load, seq_len, result_len, axis=axis)


def _build_damping(
    mass: np.ndarray,
    stiffness: np.ndarray,
    damping_ratio: float | np.ndarray,
) -> np.ndarray:
    if isinstance(damping_ratio, np.ndarray):
        return damping_ratio
    return rayleigh(mass, stiffness, damping_ratio)


def mdof_linear_center_diff(
    mass: np.ndarray,
    stiffness: np.ndarray,
    load: np.ndarray,
    time: np.ndarray,
    *,
    damping_ratio: float | np.ndarray = 0.05,
    disp_0: np.ndarray | None = None,
    vel_0: np.ndarray | None = None,
    result_len: int = 0,
    **kwargs,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Central difference method for multi-DOF system.

    Supports non-uniform time steps.

    Args:
        mass: Mass matrix (freedom, freedom).
        stiffness: Stiffness matrix (freedom, freedom).
        load: Load array of shape (seq_len, freedom) or (batch, seq_len, freedom).
        time: Time array of shape (result_len,).
        damping_ratio: Damping ratio (scalar or damping matrix).
        disp_0: Initial displacement. Defaults to zeros.
        vel_0: Initial velocity. Defaults to zeros.
        result_len: Length of the result. Defaults to len(time).

    Returns:
        Tuple containing displacement, velocity, and acceleration arrays,
        each of shape (batch, result_len, freedom).
    """
    freedom = mass.shape[0]
    seq_len = load.shape[-2]

    if result_len == 0:
        result_len = len(time)

    load = _add_batch_dim(load)
    load = _adjust_load_mdof(load, seq_len, result_len, axis=-2)
    batch_size = load.shape[0]

    if disp_0 is None:
        disp_0 = np.zeros(freedom)
    if vel_0 is None:
        vel_0 = np.zeros(freedom)

    damping = _build_damping(mass, stiffness, damping_ratio)

    dt0 = time[1] - time[0]
    acc_0 = solve(mass, load[:, 0, :].T - damping @ vel_0 - stiffness @ disp_0).T
    disp_minus1 = np.broadcast_to(
        disp_0 - dt0 * vel_0 + dt0**2 * acc_0 / 2, (batch_size, freedom)
    )

    disp, vel, acc = _init_response(result_len, freedom, batch_size, disp_0, vel_0, np.zeros(freedom))

    equ_k0 = mass / dt0**2 + damping / (2 * dt0)
    a_mat0 = (2 * mass) / dt0**2
    b_mat0 = mass / dt0**2 - damping / (2 * dt0)
    equ_p0 = load[:, 0, :].T - (stiffness - a_mat0) @ disp_0 - b_mat0 @ disp_minus1.T
    disp[:, 1, :] = solve(equ_k0, equ_p0).T
    vel[:, 0, :] = (disp[:, 1, :] - disp_minus1) / (2 * dt0)
    acc[:, 0, :] = (disp[:, 1, :] - 2 * disp[:, 0, :] + disp_minus1) / dt0**2

    for i in range(1, result_len - 1):
        dti = time[i + 1] - time[i]

        equ_k = mass / dti**2 + damping / (2 * dti)
        a_mat = (2 * mass) / dti**2
        b_mat = mass / dti**2 - damping / (2 * dti)

        d_prev = disp[:, i - 1, :]

        equ_p = (
            load[:, i, :].T - (stiffness - a_mat) @ disp[:, i, :].T - b_mat @ d_prev.T
        )
        disp[:, i + 1, :] = solve(equ_k, equ_p).T
        vel[:, i, :] = (disp[:, i + 1, :] - d_prev) / (2 * dti)
        acc[:, i, :] = (disp[:, i + 1, :] - 2 * disp[:, i, :] + d_prev) / dti**2

    if batch_size == 1:
        disp = disp[0]
        vel = vel[0]
        acc = acc[0]

    return disp, vel, acc


def mdof_linear_newmark_beta(
    mass: np.ndarray,
    stiffness: np.ndarray,
    load: np.ndarray,
    time: np.ndarray,
    *,
    damping_ratio: float | np.ndarray = 0.05,
    disp_0: np.ndarray | None = None,
    vel_0: np.ndarray | None = None,
    acc_0: np.ndarray | None = None,
    beta: float = 0.25,
    gamma: float = 0.5,
    result_len: int = 0,
    **kwargs,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Newmark-beta method for multi-DOF system.

    Supports non-uniform time steps. Coefficients are recomputed at each step.

    Args:
        mass: Mass matrix (freedom, freedom).
        stiffness: Stiffness matrix (freedom, freedom).
        load: Load array of shape (seq_len, freedom) or (batch, seq_len, freedom).
        time: Time array of shape (result_len,).
        damping_ratio: Damping ratio (scalar or damping matrix).
        disp_0: Initial displacement. Defaults to zeros.
        vel_0: Initial velocity. Defaults to zeros.
        acc_0: Initial acceleration. Defaults to zeros.
        beta: Beta parameter. Defaults to 0.25.
        gamma: Gamma parameter. Defaults to 0.5.
        result_len: Length of the result. Defaults to len(time).

    Returns:
        Tuple containing displacement, velocity, and acceleration arrays,
        each of shape (batch, result_len, freedom).
    """
    freedom = mass.shape[0]
    seq_len = load.shape[-2]

    if result_len == 0:
        result_len = len(time)

    load = _add_batch_dim(load)
    load = _adjust_load_mdof(load, seq_len, result_len, axis=-2)
    batch_size = load.shape[0]

    if disp_0 is None:
        disp_0 = np.zeros(freedom)
    if vel_0 is None:
        vel_0 = np.zeros(freedom)
    if acc_0 is None:
        acc_0 = np.zeros(freedom)

    damping = _build_damping(mass, stiffness, damping_ratio)

    disp, vel, acc = _init_response(
        result_len, freedom, batch_size, disp_0, vel_0, acc_0
    )

    for i in range(result_len - 1):
        dti = time[i + 1] - time[i]

        a_0 = 1 / (beta * dti**2)
        a_1 = gamma / (beta * dti)
        a_2 = 1 / (beta * dti)
        a_3 = 1 / (2 * beta) - 1
        a_4 = gamma / beta - 1
        a_5 = dti / 2 * (a_4 - 1)
        a_6 = dti * (1 - gamma)
        a_7 = gamma * dti

        equ_k = stiffness + a_0 * mass + a_1 * damping

        equ_p = (
            load[:, i + 1, :].T
            + mass
            @ (a_0 * disp[:, i, :].T + a_2 * vel[:, i, :].T + a_3 * acc[:, i, :].T)
            + damping
            @ (a_1 * disp[:, i, :].T + a_4 * vel[:, i, :].T + a_5 * acc[:, i, :].T)
        )
        disp[:, i + 1, :] = solve(equ_k, equ_p).T
        acc[:, i + 1, :] = (
            a_0 * (disp[:, i + 1, :] - disp[:, i, :])
            - a_2 * vel[:, i, :]
            - a_3 * acc[:, i, :]
        )
        vel[:, i + 1, :] = vel[:, i, :] + a_6 * acc[:, i, :] + a_7 * acc[:, i + 1, :]

    if batch_size == 1:
        disp = disp[0]
        vel = vel[0]
        acc = acc[0]

    return disp, vel, acc


def mdof_linear_wilson_theta(
    mass: np.ndarray,
    stiffness: np.ndarray,
    load: np.ndarray,
    time: np.ndarray,
    *,
    damping_ratio: float | np.ndarray = 0.05,
    disp_0: np.ndarray | None = None,
    vel_0: np.ndarray | None = None,
    acc_0: np.ndarray | None = None,
    theta: float = 1.37,
    result_len: int = 0,
    **kwargs,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Wilson-theta method for multi-DOF system.

    Supports non-uniform time steps. Coefficients are recomputed at each step.

    Args:
        mass: Mass matrix (freedom, freedom).
        stiffness: Stiffness matrix (freedom, freedom).
        load: Load array of shape (seq_len, freedom) or (batch, seq_len, freedom).
        time: Time array of shape (result_len,).
        damping_ratio: Damping ratio (scalar or damping matrix).
        disp_0: Initial displacement. Defaults to zeros.
        vel_0: Initial velocity. Defaults to zeros.
        acc_0: Initial acceleration. Defaults to zeros.
        theta: Wilson-theta parameter. Defaults to 1.37.
        result_len: Length of the result. Defaults to len(time).

    Returns:
        Tuple containing displacement, velocity, and acceleration arrays,
        each of shape (batch, result_len, freedom).
    """
    freedom = mass.shape[0]
    seq_len = load.shape[-2]

    if result_len == 0:
        result_len = len(time)

    load = _add_batch_dim(load)
    load = _adjust_load_mdof(load, seq_len, result_len, axis=-2)
    batch_size = load.shape[0]

    if disp_0 is None:
        disp_0 = np.zeros(freedom)
    if vel_0 is None:
        vel_0 = np.zeros(freedom)
    if acc_0 is None:
        acc_0 = np.zeros(freedom)

    damping = _build_damping(mass, stiffness, damping_ratio)

    disp, vel, acc = _init_response(
        result_len, freedom, batch_size, disp_0, vel_0, acc_0
    )

    for i in range(result_len - 1):
        dti = time[i + 1] - time[i]
        dt_theta = theta * dti

        equ_k = stiffness + 6 / dt_theta**2 * mass + 3 / dt_theta * damping

        equ_load = load[:, i, :] + theta * (load[:, i + 1, :] - load[:, i, :])
        mass_term = (
            6 / dt_theta**2 * disp[:, i, :].T
            + 6 / dt_theta * vel[:, i, :].T
            + 2 * acc[:, i, :].T
        )
        damp_term = (
            3 / dt_theta * disp[:, i, :].T
            + 2 * vel[:, i, :].T
            + dt_theta / 2 * acc[:, i, :].T
        )
        equ_load = equ_load.T + mass @ mass_term + damping @ damp_term

        disp_theta = solve(equ_k, equ_load).T
        acc[:, i + 1, :] = (
            6 / (theta**3 * dti**2) * (disp_theta - disp[:, i, :])
            - 6 / (theta**2 * dti) * vel[:, i, :]
            + (1 - 3 / theta) * acc[:, i, :]
        )
        vel[:, i + 1, :] = vel[:, i, :] + dti / 2 * (acc[:, i + 1, :] + acc[:, i, :])
        disp[:, i + 1, :] = (
            disp[:, i, :]
            + dti * vel[:, i, :]
            + dti**2 / 6 * (acc[:, i + 1, :] + 2 * acc[:, i, :])
        )

    if batch_size == 1:
        disp = disp[0]
        vel = vel[0]
        acc = acc[0]

    return disp, vel, acc
