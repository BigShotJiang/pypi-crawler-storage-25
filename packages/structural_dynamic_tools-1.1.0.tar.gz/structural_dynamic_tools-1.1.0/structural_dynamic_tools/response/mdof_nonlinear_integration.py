"""Multiple Degree of Freedom Nonlinear Time Integration Methods.

This module provides time-stepping integration for MDOF systems with
nonlinear constitutive models at each degree of freedom. Both the
central-difference method (explicit) and the Newmark-β
constant-average-acceleration method (implicit with assembled tangent
stiffness) are implemented.

All public functions support batch computation: a single mass/damping
system is driven by multiple load histories simultaneously. Each batch
slice maintains its own set of constitutive-model state.
"""

from __future__ import annotations

from typing import List, Tuple, Union

import numpy as np
from scipy.linalg import solve

from structural_dynamic_tools.modeling import rayleigh
from structural_dynamic_tools.utils.wave_utils import adjust_length
from structural_dynamic_tools.constitutive import ConstitutiveModel


def _add_batch_dim_mdof(load: np.ndarray) -> np.ndarray:
    if load.ndim == 2:
        return load[np.newaxis, ...]
    return load


def _adjust_load_mdof(
    load: np.ndarray, seq_len: int, result_len: int, axis: int
) -> np.ndarray:
    return adjust_length(load, seq_len, result_len, axis=axis)


def _init_response_mdof(
    result_len: int,
    freedom: int,
    batch_size: int,
    disp_0: np.ndarray,
    vel_0: np.ndarray,
    acc_0: np.ndarray | None = None,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray | None]:
    disp = np.zeros((batch_size, result_len, freedom))
    vel = np.zeros((batch_size, result_len, freedom))
    acc = np.zeros((batch_size, result_len, freedom)) if acc_0 is not None else None
    disp[:, 0, :] = disp_0
    vel[:, 0, :] = vel_0
    if acc is not None:
        acc[:, 0, :] = acc_0
    return disp, vel, acc


def _ensure_mdof_nl_batch(
    constitutive_models: Union[List[ConstitutiveModel], List[List[ConstitutiveModel]]],
    batch_size: int,
    freedom: int,
) -> List[List[ConstitutiveModel]]:
    """Normalise constitutive model argument to shape ``(batch_size, freedom)``.

    * ``List[ConstitutiveModel]`` of length ``freedom`` → broadcast across batches.
    * ``List[List[ConstitutiveModel]]`` of shape ``(batch_size, freedom)`` → used as-is.
    """
    if not isinstance(constitutive_models, list):
        raise TypeError(
            "constitutive_models must be a list of ConstitutiveModel instances"
        )

    if len(constitutive_models) == 0:
        raise ValueError("constitutive_models must not be empty")

    if isinstance(constitutive_models[0], ConstitutiveModel):
        if len(constitutive_models) != freedom:
            raise ValueError(
                f"Expected {freedom} constitutive models (one per DOF), "
                f"got {len(constitutive_models)}"
            )
        for m in constitutive_models:
            m.reset()
        return [constitutive_models] * batch_size

    if isinstance(constitutive_models[0], list):
        if len(constitutive_models) != batch_size:
            raise ValueError(
                f"Expected {batch_size} batches of constitutive models, "
                f"got {len(constitutive_models)}"
            )
        for b in range(batch_size):
            if len(constitutive_models[b]) != freedom:
                raise ValueError(
                    f"Batch {b}: expected {freedom} models, "
                    f"got {len(constitutive_models[b])}"
                )
        return constitutive_models

    raise TypeError("Unsupported constitutive_models structure")


def _build_damping_matrix(
    mass: np.ndarray,
    stiffness: np.ndarray,
    damping_ratio: float | np.ndarray,
) -> np.ndarray:
    if isinstance(damping_ratio, np.ndarray):
        return damping_ratio
    return rayleigh(mass, stiffness, damping_ratio)


def _assemble_restoring_force(
    models: List[ConstitutiveModel], disp: np.ndarray
) -> Tuple[np.ndarray, np.ndarray]:
    """Evaluate restoring force vector and tangent stiffness diagonal.

    Args:
        models: Constitutive model for each DOF (length = freedom).
        disp: Displacement vector (freedom,).

    Returns:
        Tuple of (force_vector, tangent_stiffness_diagonal), each of shape (freedom,).
    """
    freedom = len(models)
    force = np.empty(freedom)
    k_tangent = np.empty(freedom)
    for j in range(freedom):
        f_s, k_t = models[j].update(disp[j])
        force[j] = f_s
        k_tangent[j] = k_t
    return force, k_tangent


def mdof_nonlinear_center_diff(
    mass: np.ndarray,
    stiffness: np.ndarray,
    constitutive_models: List[ConstitutiveModel] | List[List[ConstitutiveModel]],
    load: np.ndarray,
    time: np.ndarray,
    *,
    damping_ratio: float | np.ndarray = 0.05,
    disp_0: np.ndarray | None = None,
    vel_0: np.ndarray | None = None,
    result_len: int = 0,
    **kwargs: object,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Central-difference method for a nonlinear MDOF system.

    The restoring force vector is supplied by a ``ConstitutiveModel``
    instance per DOF. No tangent stiffness is needed, making this
    method straightforward for any hysteretic law.

    Args:
        mass: Mass matrix (freedom, freedom).
        stiffness: Stiffness matrix (freedom, freedom) -- used only for
            Rayleigh damping construction and initial acceleration estimate.
        constitutive_models: One ``ConstitutiveModel`` per DOF (list of
            length ``freedom``), or a list-of-lists of shape
            ``(batch, freedom)`` for batched computation.
        load: Load array of shape ``(seq_len, freedom)`` or
            ``(batch, seq_len, freedom)``.
        time: Time array.
        damping_ratio: Damping ratio or damping matrix.
        disp_0: Initial displacement. Defaults to zeros.
        vel_0: Initial velocity. Defaults to zeros.
        result_len: Length of output arrays. Defaults to ``len(time)``.

    Returns:
        Tuple of ``(disp, vel, acc)`` arrays, each of shape
        ``(result_len, freedom)`` or ``(batch, result_len, freedom)``.
    """
    freedom = mass.shape[0]
    seq_len = load.shape[-2]

    if result_len == 0:
        result_len = len(time)

    load = _add_batch_dim_mdof(load)
    load = _adjust_load_mdof(load, seq_len, result_len, axis=-2)
    batch_size = load.shape[0]

    if disp_0 is None:
        disp_0 = np.zeros(freedom)
    if vel_0 is None:
        vel_0 = np.zeros(freedom)

    models = _ensure_mdof_nl_batch(constitutive_models, batch_size, freedom)

    damping = _build_damping_matrix(mass, stiffness, damping_ratio)

    dt0 = time[1] - time[0]
    f_s0 = np.zeros((batch_size, freedom))
    acc_0 = np.zeros((batch_size, freedom))
    for b in range(batch_size):
        f_s0[b], _ = _assemble_restoring_force(models[b], disp_0)
        acc_0[b] = solve(mass, load[b, 0, :] - damping @ vel_0 - f_s0[b])
    disp_minus1 = disp_0 - dt0 * vel_0 + 0.5 * dt0 * dt0 * acc_0

    disp, vel, acc = _init_response_mdof(
        result_len, freedom, batch_size, disp_0, vel_0, np.zeros(freedom)
    )

    equ_k0 = mass / (dt0 * dt0) + damping / (2.0 * dt0)
    a_mat0 = 2.0 * mass / (dt0 * dt0)
    b_mat0 = mass / (dt0 * dt0) - damping / (2.0 * dt0)

    for b in range(batch_size):
        f_s0_b, _ = _assemble_restoring_force(models[b], disp_0)
        equ_p0 = load[b, 0, :] - f_s0_b + a_mat0 @ disp_0 - b_mat0 @ disp_minus1[b]
        disp[b, 1, :] = solve(equ_k0, equ_p0)

    vel[:, 0, :] = (disp[:, 1, :] - disp_minus1) / (2.0 * dt0)
    acc[:, 0, :] = (disp[:, 1, :] - 2.0 * disp[:, 0, :] + disp_minus1) / (dt0 * dt0)

    for i in range(1, result_len - 1):
        dti = time[i + 1] - time[i]

        equ_k = mass / (dti * dti) + damping / (2.0 * dti)
        a_mat = 2.0 * mass / (dti * dti)
        b_mat = mass / (dti * dti) - damping / (2.0 * dti)

        for b in range(batch_size):
            f_s_i, _ = _assemble_restoring_force(models[b], disp[b, i, :])
            equ_p = (
                load[b, i, :]
                - f_s_i
                + a_mat @ disp[b, i, :]
                - b_mat @ disp[b, i - 1, :]
            )
            disp[b, i + 1, :] = solve(equ_k, equ_p)

        vel[:, i, :] = (disp[:, i + 1, :] - disp[:, i - 1, :]) / (2.0 * dti)
        acc[:, i, :] = (disp[:, i + 1, :] - 2.0 * disp[:, i, :] + disp[:, i - 1, :]) / (
            dti * dti
        )

    if batch_size == 1:
        disp = disp[0]
        vel = vel[0]
        acc = acc[0]

    return disp, vel, acc


def mdof_nonlinear_hht(
    mass: np.ndarray,
    stiffness: np.ndarray,
    constitutive_models: List[ConstitutiveModel] | List[List[ConstitutiveModel]],
    load: np.ndarray,
    time: np.ndarray,
    *,
    damping_ratio: float | np.ndarray = 0.05,
    disp_0: np.ndarray | None = None,
    vel_0: np.ndarray | None = None,
    alpha: float = -0.1,
    result_len: int = 0,
    max_iter: int = 10,
    tol: float = 1e-6,
    **kwargs: object,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """HHT-α method for nonlinear MDOF with Newton‑Raphson iteration.

    α ∈ [-⅓, 0]; α = 0 recovers Newmark‑β. The algorithm introduces
    controllable numerical damping for spurious high‑frequency modes
    while preserving second‑order accuracy in the low‑frequency range.

    β = (1 − α)² / 4,   γ = ½ − α.

    Args:
        mass: Mass matrix (freedom, freedom).
        stiffness: Stiffness matrix (freedom, freedom).
        constitutive_models: One ``ConstitutiveModel`` per DOF.
        load: Load array ``(seq_len, freedom)`` or ``(batch, seq_len, freedom)``.
        time: Time array.
        damping_ratio: Damping ratio or damping matrix.
        disp_0: Initial displacement.
        vel_0: Initial velocity.
        alpha: HHT-α parameter (default -0.1).
        result_len: Output length.
        max_iter: Max Newton iterations per step.
        tol: Convergence tolerance.

    Returns:
        ``(disp, vel, acc)`` arrays.
    """
    if alpha > 0 or alpha < -1.0 / 3.0:
        raise ValueError("alpha must be in [-1/3, 0]")

    gamma = 0.5 - alpha
    beta = (1.0 - alpha) ** 2 / 4.0

    freedom = mass.shape[0]
    seq_len = load.shape[-2]

    if result_len == 0:
        result_len = len(time)

    load = _add_batch_dim_mdof(load)
    load = _adjust_load_mdof(load, seq_len, result_len, axis=-2)
    batch_size = load.shape[0]

    if disp_0 is None:
        disp_0 = np.zeros(freedom)
    if vel_0 is None:
        vel_0 = np.zeros(freedom)

    models = _ensure_mdof_nl_batch(constitutive_models, batch_size, freedom)
    damping = _build_damping_matrix(mass, stiffness, damping_ratio)

    acc_0 = np.zeros((batch_size, freedom))
    for b in range(batch_size):
        f_s0, _ = _assemble_restoring_force(models[b], disp_0)
        acc_0[b] = solve(mass, load[b, 0, :] - damping @ vel_0 - f_s0)

    disp, vel, acc = _init_response_mdof(
        result_len, freedom, batch_size, disp_0, vel_0, acc_0
    )

    for b in range(batch_size):
        for m in models[b]:
            m.reset()
            m.update(0.0)

    for i in range(result_len - 1):
        dti = time[i + 1] - time[i]
        a_0 = 1.0 / (beta * dti * dti)
        a_1 = gamma / (beta * dti)
        a_2 = 1.0 / (beta * dti)
        a_3 = 1.0 / (2.0 * beta) - 1.0
        a_6 = dti * (1.0 - gamma)
        a_7 = gamma * dti

        for b in range(batch_size):
            model_snap = [dict(vars(m)) for m in models[b]]
            f_s_old, _ = _assemble_restoring_force(models[b], disp[b, i, :])

            d_new = disp[b, i, :].copy()
            v_new = vel[b, i, :].copy()

            for _ in range(max_iter):
                for m, snap in zip(models[b], model_snap):
                    for key, val in snap.items():
                        setattr(m, key, val)

                f_s, k_t_diag = _assemble_restoring_force(models[b], d_new)

                a_new = a_0 * (d_new - disp[b, i, :]) - a_2 * vel[b, i, :] - a_3 * acc[b, i, :]
                v_new = vel[b, i, :] + a_6 * acc[b, i, :] + a_7 * a_new

                residual = (
                    (1.0 + alpha) * load[b, i + 1, :]
                    - alpha * load[b, i, :]
                    - mass @ a_new
                    - (1.0 + alpha) * damping @ v_new
                    + alpha * damping @ vel[b, i, :]
                    - (1.0 + alpha) * f_s
                    + alpha * f_s_old
                )

                if np.max(np.abs(residual)) < tol:
                    break

                k_t_mat = np.diag(k_t_diag)
                K_eff = (1.0 + alpha) * k_t_mat + a_0 * mass + (1.0 + alpha) * a_1 * damping
                delta_d = solve(K_eff, residual)
                d_new += delta_d

            disp[b, i + 1, :] = d_new
            vel[b, i + 1, :] = v_new
            acc[b, i + 1, :] = a_new

            for m, snap in zip(models[b], model_snap):
                for key, val in snap.items():
                    setattr(m, key, val)
            _assemble_restoring_force(models[b], d_new)

    if batch_size == 1:
        disp = disp[0]
        vel = vel[0]
        acc = acc[0]

    return disp, vel, acc


def mdof_nonlinear_newmark_beta(
    mass: np.ndarray,
    stiffness: np.ndarray,
    constitutive_models: List[ConstitutiveModel] | List[List[ConstitutiveModel]],
    load: np.ndarray,
    time: np.ndarray,
    *,
    damping_ratio: float | np.ndarray = 0.05,
    disp_0: np.ndarray | None = None,
    vel_0: np.ndarray | None = None,
    beta: float = 0.25,
    gamma: float = 0.5,
    result_len: int = 0,
    max_iter: int = 10,
    tol: float = 1e-6,
    **kwargs: object,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Newmark-β method for a nonlinear MDOF system with Newton‑Raphson iteration.

    Equilibrium iteration is performed at every time step until the
    residual force norm falls below ``tol`` or the maximum iteration
    count is reached.

    Args:
        mass: Mass matrix (freedom, freedom).
        stiffness: Stiffness matrix (freedom, freedom) -- used for Rayleigh
            damping and as the initial tangent for the Newton iteration.
        constitutive_models: One ``ConstitutiveModel`` per DOF (list of
            length ``freedom``), or a list-of-lists of shape
            ``(batch, freedom)`` for batched computation.
        load: Load array of shape ``(seq_len, freedom)`` or
            ``(batch, seq_len, freedom)``.
        time: Time array.
        damping_ratio: Damping ratio or damping matrix.
        disp_0: Initial displacement. Defaults to zeros.
        vel_0: Initial velocity. Defaults to zeros.
        beta: Newmark-β parameter. Defaults to 0.25.
        gamma: Newmark-γ parameter. Defaults to 0.5.
        result_len: Length of output arrays. Defaults to ``len(time)``.
        max_iter: Maximum Newton‑Raphson iterations per time step.
            Defaults to 10.
        tol: Convergence tolerance on the residual force norm.
            Defaults to 1e-6.

    Returns:
        Tuple of ``(disp, vel, acc)`` arrays, each of shape
        ``(result_len, freedom)`` or ``(batch, result_len, freedom)``.
    """
    freedom = mass.shape[0]
    seq_len = load.shape[-2]

    if result_len == 0:
        result_len = len(time)

    load = _add_batch_dim_mdof(load)
    load = _adjust_load_mdof(load, seq_len, result_len, axis=-2)
    batch_size = load.shape[0]

    if disp_0 is None:
        disp_0 = np.zeros(freedom)
    if vel_0 is None:
        vel_0 = np.zeros(freedom)

    models = _ensure_mdof_nl_batch(constitutive_models, batch_size, freedom)

    damping = _build_damping_matrix(mass, stiffness, damping_ratio)

    acc_0 = np.zeros((batch_size, freedom))
    for b in range(batch_size):
        f_s0, _ = _assemble_restoring_force(models[b], disp_0)
        acc_0[b] = solve(mass, load[b, 0, :] - damping @ vel_0 - f_s0)

    disp, vel, acc = _init_response_mdof(
        result_len, freedom, batch_size, disp_0, vel_0, acc_0
    )

    for i in range(result_len - 1):
        dti = time[i + 1] - time[i]

        a_0 = 1.0 / (beta * dti * dti)
        a_1 = gamma / (beta * dti)
        a_2 = 1.0 / (beta * dti)
        a_3 = 1.0 / (2.0 * beta) - 1.0
        a_6 = dti * (1.0 - gamma)
        a_7 = gamma * dti

        for b in range(batch_size):
            model_snap = [dict(vars(m)) for m in models[b]]

            d_new = disp[b, i, :].copy()
            v_new = vel[b, i, :].copy()

            converged = False
            for _ in range(max_iter):
                for m, snap in zip(models[b], model_snap):
                    for key, val in snap.items():
                        setattr(m, key, val)

                f_s, k_t_diag = _assemble_restoring_force(models[b], d_new)

                a_new = (
                    a_0 * (d_new - disp[b, i, :])
                    - a_2 * vel[b, i, :]
                    - a_3 * acc[b, i, :]
                )
                v_new = vel[b, i, :] + a_6 * acc[b, i, :] + a_7 * a_new

                residual = load[b, i + 1, :] - mass @ a_new - damping @ v_new - f_s

                if np.max(np.abs(residual)) < tol:
                    converged = True
                    break

                k_t_mat = np.diag(k_t_diag)
                K_eff = k_t_mat + a_0 * mass + a_1 * damping
                delta_d = solve(K_eff, residual)
                d_new += delta_d

            disp[b, i + 1, :] = d_new
            vel[b, i + 1, :] = v_new
            acc[b, i + 1, :] = (
                a_0 * (d_new - disp[b, i, :]) - a_2 * vel[b, i, :] - a_3 * acc[b, i, :]
            )

            for m, snap in zip(models[b], model_snap):
                for key, val in snap.items():
                    setattr(m, key, val)
            _assemble_restoring_force(models[b], d_new)

    if batch_size == 1:
        disp = disp[0]
        vel = vel[0]
        acc = acc[0]

    return disp, vel, acc
