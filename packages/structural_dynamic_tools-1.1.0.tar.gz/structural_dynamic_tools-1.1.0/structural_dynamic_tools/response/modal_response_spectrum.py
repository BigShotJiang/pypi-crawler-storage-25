"""Modal response spectrum analysis for seismic design.

Provides combination rules (SRSS, CQC, ABS) and the modal response spectrum
method for computing maximum story shear forces per seismic design codes.
"""

import numpy as np
from scipy.linalg import eigh

from structural_dynamic_tools.spectrum.code_spectrum import gb50011_spectrum


def _modal_info(mass, stiffness, n_modes, modes, omega_sq):
    freq = np.sqrt(omega_sq[:n_modes]) / (2 * np.pi)
    return {
        "freq": freq,
        "periods": 1.0 / freq,
        "damp": np.zeros(n_modes),
        "modes": modes[:, :n_modes],
        "modal_mass": np.diag(modes[:, :n_modes].T @ mass @ modes[:, :n_modes]),
        "modal_stiffness": np.diag(
            modes[:, :n_modes].T @ stiffness @ modes[:, :n_modes]
        ),
    }


def _cqc_correlation(
    T1: float,
    T2: float,
    xi1: float,
    xi2: float,
) -> float:
    """
    Compute CQC correlation coefficient between two modes.

    Args:
        T1: Period of mode 1 (s).
        T2: Period of mode 2 (s).
        xi1: Damping ratio of mode 1.
        xi2: Damping ratio of mode 2.

    Returns:
        Correlation coefficient ρ_{ij}.
    """
    omega1 = 2 * np.pi / T1
    omega2 = 2 * np.pi / T2

    gamma = omega2 / omega1

    numerator = 8 * np.sqrt(xi1 * xi2) * (xi1 + gamma * xi2) * gamma**1.5
    denominator = (
        (1 - gamma**2) ** 2
        + 4 * xi1 * xi2 * (1 + gamma**2) * gamma
        + 4 * (xi1**2 + xi2**2) * gamma**2
    )

    return numerator / denominator


def cqc_combination(
    modal_responses: np.ndarray,
    periods: np.ndarray,
    damp: np.ndarray,
) -> np.ndarray:
    """
    Complete Quadratic Combination (CQC) method.

    Combines modal responses accounting for cross-modal correlation through
    modal damping and frequency ratios.

    Args:
        modal_responses: Modal responses (n_modes x n_dof), e.g., story shear
            forces per mode.
        periods: Natural periods of each mode (s).
        damp: Damping ratios of each mode.

    Returns:
        Combined response vector (n_dof,).
    """
    n_modes = len(periods)
    n_dof = modal_responses.shape[1]

    combined = np.zeros(n_dof)

    for i in range(n_dof):
        cqc_sum = 0.0
        for j in range(n_modes):
            for k in range(n_modes):
                r_jk = _cqc_correlation(periods[j], periods[k], damp[j], damp[k])
                cqc_sum += modal_responses[j, i] * modal_responses[k, i] * r_jk
        combined[i] = np.sqrt(cqc_sum)

    return combined


def srss_combination(
    modal_responses: np.ndarray,
) -> np.ndarray:
    """
    Square Root of Sum of Squares (SRSS) method.

    Suitable when modal frequencies are well-separated.

    Args:
        modal_responses: Modal responses (n_modes x n_dof).

    Returns:
        Combined response vector (n_dof,).
    """
    return np.sqrt(np.sum(modal_responses**2, axis=0))


def abs_combination(
    modal_responses: np.ndarray,
) -> np.ndarray:
    """
    Absolute Sum (ABS) combination method.

    Conservative upper-bound estimate summing absolute modal responses.

    Args:
        modal_responses: Modal responses (n_modes x n_dof).

    Returns:
        Combined response vector (n_dof,).
    """
    return np.sum(np.abs(modal_responses), axis=0)


def effective_mass_fraction(
    modes: np.ndarray,
    mass: np.ndarray,
    direction: int = 0,
) -> np.ndarray:
    """
    Compute effective mass fraction for each mode.

    Used to determine how many modes are needed to capture a sufficient
    fraction of the total structural mass (e.g., ≥90% per code).

    Args:
        modes: Mode shape matrix (n_dof x n_modes).
        mass: Mass matrix (n_dof x n_dof).
        direction: Direction index (0-based) in unit excitation vector.

    Returns:
        Effective mass fraction per mode (n_modes,).
    """
    n_modes = modes.shape[1]
    total_mass = np.sum(np.diag(mass))

    effective_mass = np.zeros(n_modes)
    for i in range(n_modes):
        phi_i = modes[:, i]
        m_eff_i = (phi_i.T @ mass @ np.eye(len(mass))[:, direction]) ** 2
        m_eff_i /= phi_i.T @ mass @ phi_i
        effective_mass[i] = m_eff_i

    return effective_mass / total_mass


def check_mode_truncation(
    modes: np.ndarray,
    mass: np.ndarray,
    threshold: float = 0.90,
    direction: int = 0,
) -> tuple[int, float]:
    """
    Determine the number of modes needed to reach an effective mass threshold.

    Args:
        modes: Mode shape matrix (n_dof x n_modes).
        mass: Mass matrix (n_dof x n_dof).
        threshold: Target cumulative effective mass fraction (default 0.90).
        direction: Direction index.

    Returns:
        Tuple of (n_modes_needed, cumulative_effective_mass).
    """
    eff_mass = effective_mass_fraction(modes, mass, direction)
    cumulative = np.cumsum(eff_mass)

    idx = np.searchsorted(cumulative, threshold)
    if idx >= len(cumulative):
        return len(cumulative), cumulative[-1]

    return idx + 1, cumulative[idx]


def modal_response_spectrum_analysis(
    mass: np.ndarray,
    stiffness: np.ndarray,
    damping_ratio: float = 0.05,
    combination_method: str = "srss",
    n_modes: int | None = None,
    spectrum_func=gb50011_spectrum,
    **spectrum_kwargs,
) -> dict:
    """
    Modal response spectrum analysis for computing maximum story shear forces.

    1. Performs modal analysis to extract periods and mode shapes.
    2. Computes seismic influence coefficient α(T) for each mode using the
       specified design spectrum.
    3. Computes equivalent lateral forces per mode.
    4. Computes story shear forces per mode.
    5. Combines modal story shears using SRSS, CQC, or ABS.

    Args:
        mass: Mass matrix (n x n).
        stiffness: Stiffness matrix (n x n).
        damping_ratio: Uniform damping ratio for all modes. Defaults to 0.05.
        combination_method: ``"srss"``, ``"cqc"``, or ``"abs"``.
        n_modes: Number of modes to consider. If None, all modes.
        spectrum_func: Design spectrum function with signature
            ``f(periods, damping=damping_ratio, **kwargs)``. Defaults to
            :func:`gb50011_spectrum`.
        **spectrum_kwargs: Additional arguments passed to ``spectrum_func``
            (e.g., ``site_class``, ``intensity`` for GB 50011).

    Returns:
        Dictionary with keys:

        - ``modal``: Modal analysis results (freq, periods, damp, modes, etc.).
        - ``alpha``: Seismic influence coefficient per mode.
        - ``gamma``: Modal participation factor per mode.
        - ``modal_story_shear``: Story shear per mode (n_modes x n_dof).
        - ``combined_story_shear``: Combined story shear (n_dof,).
        - ``combination_method``: Method used.
    """
    n = mass.shape[0]
    n_dof = n

    if n_modes is None:
        n_modes = n

    omega_sq, modes = eigh(stiffness, mass)
    idx = omega_sq.argsort()
    omega_sq = omega_sq[idx]
    modes = modes[:, idx]

    modal = _modal_info(mass, stiffness, n_modes, modes, omega_sq)

    n_modes_used = n_modes

    gamma = np.zeros(n_modes_used)
    modal_story_shear = np.zeros((n_modes_used, n_dof))

    damp = np.full(n_modes_used, damping_ratio)

    alpha = spectrum_func(
        modal["periods"],
        damping=damping_ratio,
        **spectrum_kwargs,
    )

    for i in range(n_modes_used):
        gamma[i] = (modal["modes"][:, i].T @ mass @ np.ones(n_dof)) / modal[
            "modal_mass"
        ][i]

        equ_force = alpha[i] * 9.8 * gamma[i] * mass @ modal["modes"][:, i]

        for j in range(n_dof):
            modal_story_shear[i, j] = np.sum(equ_force[j:])

    method = combination_method.lower()
    if method == "cqc":
        combined = cqc_combination(modal_story_shear, modal["periods"], damp)
    elif method == "srss":
        combined = srss_combination(modal_story_shear)
    elif method == "abs":
        combined = abs_combination(modal_story_shear)
    else:
        raise ValueError(
            f"Unknown combination_method: '{combination_method}'. "
            "Use 'srss', 'cqc', or 'abs'."
        )

    return {
        "modal": modal,
        "alpha": alpha,
        "gamma": gamma,
        "modal_story_shear": modal_story_shear,
        "combined_story_shear": combined,
        "combination_method": method,
    }
