"""Adaptive time-stepping integration for SDOF systems.

Provides adaptive step-size integrators that automatically refine the time
step in regions of strong nonlinearity, balancing accuracy and efficiency:
- RK45 (Dormand-Prince 5(4)): explicit embedded Runge-Kutta pair
- Adaptive Newmark-β: half-step error estimation with sub-stepping
"""

from __future__ import annotations

from typing import List, Tuple

import numpy as np

from structural_dynamic_tools.constitutive import ConstitutiveModel


def _build_load_interpolator(
    time: np.ndarray, load_flat: np.ndarray
) -> callable:
    def interpolate(t: float) -> float:
        if t <= time[0]:
            return load_flat[0]
        if t >= time[-1]:
            return load_flat[-1]
        idx = np.searchsorted(time, t)
        if idx == 0:
            return load_flat[0]
        t0, t1 = time[idx - 1], time[idx]
        p0, p1 = load_flat[idx - 1], load_flat[idx]
        return p0 + (p1 - p0) * (t - t0) / (t1 - t0)
    return interpolate


def sdof_adaptive_rk45(
    mass: float,
    constitutive_model: ConstitutiveModel,
    load: np.ndarray,
    time: np.ndarray,
    *,
    damping_ratio: float = 0.05,
    disp_0: float = 0.0,
    vel_0: float = 0.0,
    rtol: float = 1e-6,
    atol: float = 1e-9,
    dt_min: float = 1e-8,
    dt_max: float | None = None,
    **kwargs: object,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Adaptive RK45 (Dormand-Prince 5(4)) for nonlinear SDOF.

    Automatically adjusts the time-step to meet the prescribed relative
    and absolute tolerances. The state vector is [displacement, velocity].

    Args:
        mass: Mass.
        constitutive_model: Nonlinear constitutive model.
        load: Load array (seq_len,).
        time: Time array for output (non-uniform OK).
        damping_ratio: Damping ratio. Defaults to 0.05.
        disp_0: Initial displacement. Defaults to 0.
        vel_0: Initial velocity. Defaults to 0.
        rtol: Relative tolerance. Defaults to 1e-6.
        atol: Absolute tolerance. Defaults to 1e-9.
        dt_min: Minimum allowable time step. Defaults to 1e-8.
        dt_max: Maximum allowable time step. Defaults to 10*(avg dt).

    Returns:
        ``(disp, vel, acc, t_out)`` arrays at the output time points.
    """
    model = constitutive_model
    model.reset()
    load_fn = _build_load_interpolator(time, load)

    k0 = model.initial_stiffness
    omega_n = np.sqrt(k0 / mass)
    c = 2.0 * mass * omega_n * damping_ratio

    n_out = len(time)
    t_start = time[0]
    t_end = time[-1]
    avg_dt = (t_end - t_start) / max(n_out - 1, 1)
    if dt_max is None:
        dt_max = 10.0 * avg_dt

    disp_out = np.zeros(n_out)
    vel_out = np.zeros(n_out)
    acc_out = np.zeros(n_out)
    t_out = time.copy()

    disp_out[0] = disp_0
    vel_out[0] = vel_0

    f_s0, _ = model.update(disp_0)
    acc_out[0] = (load_fn(t_start) - c * vel_0 - f_s0) / mass

    t = t_start
    d = disp_0
    v = vel_0
    h = avg_dt * 0.1
    out_idx = 1

    def rhs(t_val: float, y: np.ndarray) -> np.ndarray:
        d_val, v_val = y[0], y[1]
        f_s, _ = model.update(d_val)
        a_val = (load_fn(t_val) - c * v_val - f_s) / mass
        return np.array([v_val, a_val])

    while t < t_end and out_idx < n_out:
        h = min(h, time[out_idx] - t)
        if h < dt_min:
            h = dt_min

        y = np.array([d, v])

        k1 = rhs(t, y)
        k2 = rhs(t + h / 5, y + h * (k1 / 5))
        k3 = rhs(t + 3 * h / 10, y + h * (3 * k1 / 40 + 9 * k2 / 40))
        k4 = rhs(
            t + 4 * h / 5,
            y + h * (44 * k1 / 45 - 56 * k2 / 15 + 32 * k3 / 9),
        )
        k5 = rhs(
            t + 8 * h / 9,
            y + h * (19372 * k1 / 6561 - 25360 * k2 / 2187 + 64448 * k3 / 6561 - 212 * k4 / 729),
        )
        k6 = rhs(
            t + h,
            y + h * (9017 * k1 / 3168 - 355 * k2 / 33 + 46732 * k3 / 5247 + 49 * k4 / 176 - 5103 * k5 / 18656),
        )

        y5 = y + h * (35 * k1 / 384 + 500 * k3 / 1113 + 125 * k4 / 192 - 2187 * k5 / 6784 + 11 * k6 / 84)
        y4 = y + h * (5179 * k1 / 57600 + 7571 * k3 / 16695 + 393 * k4 / 640 - 92097 * k5 / 339200 + 187 * k6 / 2100 + k1 / 40)

        err = np.max(np.abs(y5 - y4) / (atol + rtol * np.maximum(np.abs(y), np.abs(y5))))

        if err <= 1.0:
            t += h
            d, v = y5[0], y5[1]
            f_s, _ = model.update(d)
            a = (load_fn(t) - c * v - f_s) / mass

            while out_idx < n_out and t >= time[out_idx] - 1e-12:
                alpha = (time[out_idx] - (t - h)) / h
                alpha = max(0.0, min(1.0, alpha))
                disp_out[out_idx] = d + alpha * (d - d)
                vel_out[out_idx] = y4[1] + alpha * (v - y4[1])
                f_s_prev, _ = model.update(y4[0])
                a_prev = (load_fn(t - h) - c * y4[1] - f_s_prev) / mass
                acc_out[out_idx] = a_prev + alpha * (a - a_prev)
                out_idx += 1

        h_new = h * min(5.0, max(0.1, 0.9 / max(err, 1e-12) ** 0.2))
        h = min(max(h_new, dt_min), dt_max)

    return disp_out, vel_out, acc_out, t_out


def sdof_adaptive_newmark(
    mass: float,
    constitutive_model: ConstitutiveModel,
    load: np.ndarray,
    time: np.ndarray,
    *,
    damping_ratio: float = 0.05,
    disp_0: float = 0.0,
    vel_0: float = 0.0,
    beta: float = 0.25,
    gamma: float = 0.5,
    rtol: float = 1e-6,
    max_iter: int = 10,
    max_substeps: int = 8,
    **kwargs: object,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Adaptive Newmark-β with automatic sub-stepping.

    When Newton‑Raphson fails to converge within ``max_iter`` iterations,
    the time step is halved and the step is re-attempted (up to
    ``max_substeps`` subdivisions). This ensures robust integration
    through strong nonlinearities without global step-size reduction.

    Args:
        mass: Mass.
        constitutive_model: Nonlinear constitutive model.
        load: Load array ``(seq_len,)``.
        time: Time array.
        damping_ratio: Damping ratio.
        disp_0: Initial displacement.
        vel_0: Initial velocity.
        beta, gamma: Newmark parameters.
        rtol: Convergence tolerance on residual.
        max_iter: Max NR iterations per (sub-)step.
        max_substeps: Max number of sub-step divisions.

    Returns:
        ``(disp, vel, acc)`` arrays.
    """
    model = constitutive_model
    model.reset()

    k0 = model.initial_stiffness
    omega_n = np.sqrt(k0 / mass)
    c = 2.0 * mass * omega_n * damping_ratio

    n = len(time)
    disp = np.zeros(n)
    vel = np.zeros(n)
    acc = np.zeros(n)

    disp[0] = disp_0
    vel[0] = vel_0
    f_s0, _ = model.update(disp_0)
    acc[0] = (load[0] - c * vel_0 - f_s0) / mass

    for i in range(n - 1):
        dt = time[i + 1] - time[i]
        sub_div = 0
        converged = False
        d_current = disp[i]
        v_current = vel[i]
        a_current = acc[i]

        while sub_div <= max_substeps:
            dt_sub = dt / (2 ** sub_div)
            if dt_sub < 1e-12:
                break

            a_0 = 1.0 / (beta * dt_sub * dt_sub)
            a_1 = gamma / (beta * dt_sub)
            a_2 = 1.0 / (beta * dt_sub)
            a_3 = 1.0 / (2.0 * beta) - 1.0
            a_6 = dt_sub * (1.0 - gamma)
            a_7 = gamma * dt_sub

            d_new = d_current
            v_new = v_current
            step_ok = True

            for k_step in range(2 ** sub_div):
                t_mid = time[i] + (k_step + 1) * dt_sub
                p_mid = load[i] + (load[i + 1] - load[i]) * (k_step + 1) / (2 ** sub_div)

                model_snap = dict(vars(model))

                for _ in range(max_iter):
                    for key, val in model_snap.items():
                        setattr(model, key, val)

                    f_s, k_t = model.update(d_new)
                    a_new = a_0 * (d_new - d_current) - a_2 * v_current - a_3 * a_current
                    v_new = v_current + a_6 * a_current + a_7 * a_new

                    residual = p_mid - mass * a_new - c * v_new - f_s

                    if abs(residual) < rtol:
                        break

                    K_eff = k_t + a_0 * mass + a_1 * c
                    d_new += residual / K_eff
                else:
                    step_ok = False
                    break

                d_current, v_current, a_current = d_new, v_new, a_new

                for key, val in model_snap.items():
                    setattr(model, key, val)
                model.update(d_new)

            if step_ok:
                converged = True
                break
            sub_div += 1
            d_current = disp[i]
            v_current = vel[i]
            a_current = acc[i]

        disp[i + 1] = d_current
        vel[i + 1] = v_current
        acc[i + 1] = a_current

    return disp, vel, acc
