"""
Seismic response spectrum calculation.

Provides functions to compute acceleration, velocity, displacement,
pseudo-acceleration, and pseudo-velocity response spectra from ground
motion time histories.

Uses the Newmark-beta average acceleration method (beta=0.25, gamma=0.5)
from the ``response`` module for unconditionally stable SDOF integration.
Supports batch processing of multiple ground motions.
"""

import numpy as np

from structural_dynamic_tools.response import sdof_linear_newmark_beta

SPECTRUM_PERIOD = np.array(
    [
        0.01,
        0.02,
        0.03,
        0.04,
        0.05,
        0.06,
        0.07,
        0.08,
        0.09,
        0.10,
        0.15,
        0.20,
        0.25,
        0.30,
        0.35,
        0.40,
        0.45,
        0.50,
        0.60,
        0.80,
        1.00,
        1.20,
        1.40,
        1.60,
        1.80,
        2.00,
        2.50,
        3.00,
        3.50,
        4.00,
        5.00,
        6.00,
    ],
    dtype=np.float64,
)
"""Default period sampling points for response spectrum (seconds)."""


def _build_time_array(seq_len: int, dt: float) -> np.ndarray:
    return np.arange(seq_len, dtype=np.float64) * dt


def _extract_spectral_ordinates(
    disp: np.ndarray, vel: np.ndarray, acc: np.ndarray, omega: float
) -> tuple:
    """
    Extract spectral ordinates from SDOF response history.

    Args:
        disp: Displacement response, shape (batch, n_steps) or (n_steps,).
        vel: Velocity response.
        acc: Relative acceleration response.
        omega: Circular frequency (rad/s).

    Returns:
        Tuple of (sa, sv, sd, psa, psv) — max absolute values per record.
    """
    if disp.ndim == 1:
        disp = disp[np.newaxis, :]
        vel = vel[np.newaxis, :]
        acc = acc[np.newaxis, :]

    sd = np.abs(disp).max(axis=1)
    sv = np.abs(vel).max(axis=1)
    sa = np.abs(acc).max(axis=1)
    psa = sd * omega**2
    psv = sd * omega

    return sa, sv, sd, psa, psv


def response_spectrum(
    acc: np.ndarray,
    dt: float,
    periods: np.ndarray | None = None,
    damp: float | np.ndarray = 0.05,
) -> tuple:
    """
    Compute response spectra using Newmark-beta average acceleration method.

    Args:
        acc: Ground acceleration history, shape (samples,) or (batch, samples).
        dt: Time step (seconds).
        periods: Periods at which to compute the spectrum. Defaults to
            ``SPECTRUM_PERIOD``.
        damp: Damping ratio(s). Scalar or array matching ``periods``.

    Returns:
        Tuple ``(sa, sv, sd, psa, psv)``, each of shape
        ``(n_periods,)`` if single record, or ``(batch, n_periods)`` if
        multiple records are provided.
    """
    acc = np.asarray(acc, dtype=np.float64)
    if periods is None:
        periods = SPECTRUM_PERIOD
    periods = np.asarray(periods, dtype=np.float64).flatten()

    single_record = acc.ndim == 1
    if single_record:
        acc = acc[np.newaxis, :]

    batch_size, seq_len = acc.shape
    n_periods = len(periods)
    time = _build_time_array(seq_len, dt)

    if np.isscalar(damp):
        damp_arr = np.full(n_periods, float(damp))
    else:
        damp_arr = np.asarray(damp, dtype=np.float64).flatten()
        if len(damp_arr) != n_periods:
            damp_arr = np.resize(damp_arr, n_periods)

    sa = np.empty((batch_size, n_periods))
    sv = np.empty((batch_size, n_periods))
    sd = np.empty((batch_size, n_periods))
    psa = np.empty((batch_size, n_periods))
    psv = np.empty((batch_size, n_periods))

    for i, T in enumerate(periods):
        if T <= 0:
            sa[:, i] = 0.0
            sv[:, i] = 0.0
            sd[:, i] = 0.0
            psa[:, i] = 0.0
            psv[:, i] = 0.0
            continue

        omega = 2 * np.pi / T
        stiffness = omega**2
        load = -acc

        disp, vel, rel_acc = sdof_linear_newmark_beta(
            mass=1.0,
            stiffness=stiffness,
            load=load,
            time=time,
            damping_ratio=damp_arr[i],
            disp_0=0.0,
            vel_0=0.0,
            acc_0=0.0,
            beta=0.25,
            gamma=0.5,
            result_len=seq_len,
        )

        sa[:, i], sv[:, i], sd[:, i], psa[:, i], psv[:, i] = (
            _extract_spectral_ordinates(disp, vel, rel_acc, omega)
        )

    if single_record:
        sa = sa[0]
        sv = sv[0]
        sd = sd[0]
        psa = psa[0]
        psv = psv[0]

    return sa, sv, sd, psa, psv


def plot_response_spectrum(
    periods: np.ndarray,
    spectrum: np.ndarray,
    spec_type: str = "sa",
    title: str | None = None,
    ax=None,
    **kwargs,
):
    """
    Plot response spectrum.

    Args:
        periods: Periods (seconds).
        spectrum: Response spectrum values.
        spec_type: Type of spectrum: ``"sa"``, ``"sv"``, ``"sd"``,
            ``"psa"``, ``"psv"``.
        title: Plot title.
        ax: Matplotlib axes object (optional).
        **kwargs: Additional arguments for ``plt.plot()``.

    Returns:
        Matplotlib axes object.
    """
    import matplotlib.pyplot as plt

    if ax is None:
        ax = plt.gca()

    ax.plot(periods, spectrum, **kwargs)

    labels = {
        "sa": ("Acceleration Response Spectrum", "Acceleration"),
        "sv": ("Velocity Response Spectrum", "Velocity"),
        "sd": ("Displacement Response Spectrum", "Displacement"),
        "psa": ("Pseudo-Acceleration Response Spectrum", "Pseudo-Acceleration"),
        "psv": ("Pseudo-Velocity Response Spectrum", "Pseudo-Velocity"),
    }

    lbl_title, lbl_y = labels.get(spec_type, ("Response Spectrum", "Response"))
    ax.set_title(title or lbl_title)
    ax.set_xlabel("Period (s)")
    ax.set_ylabel(lbl_y)
    ax.grid(True, linestyle="--", alpha=0.7)
    ax.set_xscale("log")

    return ax
