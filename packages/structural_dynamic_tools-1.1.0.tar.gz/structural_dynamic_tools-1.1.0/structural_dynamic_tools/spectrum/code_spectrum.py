"""
Design response spectra according to international codes.

Implementation of design response spectra from:
- GB 50011-2010 (China)
- ASCE 7-22 (USA)
- EC8 (Eurocode 8)
- Japan Building Standard Law
"""

import numpy as np
import warnings

warnings.warn(
    "code_spectrum: Design response spectra are not verified.",
    UserWarning,
    stacklevel=2,
)


def gb50011_spectrum(
    periods: np.ndarray,
    site_class: str = "II",
    intensity: int = 8,
    damping: float = 0.05,
    **kwargs,
) -> np.ndarray:
    """
    Design response spectrum according to GB 50011-2010 (China).

    Computes the seismic influence coefficient α(T).

    Segments (Table 5.1.5):
        T ∈ [0, 0.1)         : linear rise 0.45 α_max → α_max
        T ∈ [0.1, T_g)       : plateau = η₂ α_max
        T ∈ [T_g, 5 T_g]     : (T_g / T)^γ  η₂ α_max
        T ∈ (5 T_g, 6.0]     : [η₂ 0.2^γ − η₁ (T − 5 T_g)] α_max

    Args:
        periods: Periods (seconds).
        site_class: Site classification 'I₀', 'I₁', 'II', 'III', 'IV'.
        intensity: Fortification intensity: 6, 7, 7.5, 8, 8.5, 9.
        damping: Damping ratio (default 0.05).

    Returns:
        Seismic influence coefficient α(T), dimensionless.
    """
    periods = np.asarray(periods).flatten()

    site_info = {
        "I0": {"T_g": 0.20},
        "I1": {"T_g": 0.25},
        "II": {"T_g": 0.35},
        "III": {"T_g": 0.45},
        "IV": {"T_g": 0.65},
    }
    if site_class not in site_info:
        raise ValueError(f"site_class must be one of {list(site_info.keys())}")

    intensity_alpha_max = {
        6: 0.04,
        7: 0.08,
        7.5: 0.12,
        8: 0.16,
        8.5: 0.24,
        9: 0.32,
    }
    if intensity not in intensity_alpha_max:
        raise ValueError(f"intensity must be one of {list(intensity_alpha_max.keys())}")

    T_g = site_info[site_class]["T_g"]
    alpha_max = intensity_alpha_max[intensity]

    if damping == 0.05:
        gamma = 0.9
        eta1 = 0.02
        eta2 = 1.0
    else:
        gamma = 0.9 + (0.05 - damping) / (0.3 + 6.0 * damping)
        eta1 = 0.02 + (0.05 - damping) / (4.0 + 32.0 * damping)
        eta2 = 1.0 + (0.05 - damping) / (0.08 + 1.6 * damping)
    eta1 = max(eta1, 0.0)
    eta2 = max(eta2, 0.55)

    alpha = np.zeros(len(periods))

    for i, T in enumerate(periods):
        if T <= 0.0:
            alpha[i] = 0.0
        elif T < 0.1:
            alpha[i] = (0.45 + 10.0 * (eta2 - 0.45) * T) * alpha_max
        elif T < T_g:
            alpha[i] = eta2 * alpha_max
        elif T <= 5.0 * T_g:
            alpha[i] = (T_g / T) ** gamma * eta2 * alpha_max
        else:
            alpha[i] = (eta2 * 0.2**gamma - eta1 * (T - 5.0 * T_g)) * alpha_max

    return alpha


def asce7_22_spectrum(
    periods: np.ndarray,
    site_class: str = "D",
    s_s: float = 0.75,
    s_1: float = 0.30,
    damping: float = 0.05,
) -> np.ndarray:
    """
    Design response spectrum according to ASCE 7-22 (USA).

    Segments:
        T ∈ [0, T₀)         : S_a = S_DS × (0.4 + 0.6 T / T₀)
        T ∈ [T₀, T_S]       : S_a = S_DS
        T ∈ (T_S, T_L]      : S_a = S_D1 / T
        T ∈ (T_L, ∞)        : S_a = S_D1 × T_L / T²

    where T₀ = 0.2 S_D1 / S_DS,  T_S = S_D1 / S_DS.

    Args:
        periods: Periods (seconds).
        site_class: Site class A-F (only affects T_L).
        s_s: MCE spectral acceleration at 0.2 s (g).
        s_1: MCE spectral acceleration at 1.0 s (g).
        damping: Damping ratio.

    Returns:
        Design spectral acceleration S_a (g).
    """
    periods = np.asarray(periods).flatten()

    tl_table = {"A": 8.0, "B": 8.0, "C": 8.0, "D": 8.0, "E": 8.0, "F": 8.0}
    if site_class not in tl_table:
        raise ValueError(f"site_class must be one of {list(tl_table.keys())}")
    T_L = tl_table[site_class]

    S_DS = s_s * 2.0 / 3.0
    S_D1 = s_1 * 2.0 / 3.0

    T_0 = 0.2 * S_D1 / S_DS
    T_S = S_D1 / S_DS

    sa = np.zeros(len(periods))
    for i, T in enumerate(periods):
        if T <= 0.0:
            sa[i] = 0.0
        elif T < T_0:
            sa[i] = S_DS * (0.4 + 0.6 * T / T_0)
        elif T <= T_S:
            sa[i] = S_DS
        elif T <= T_L:
            sa[i] = S_D1 / T
        else:
            sa[i] = S_D1 * T_L / (T**2)

    return sa


def ec8_spectrum(
    periods: np.ndarray,
    site_class: str = "C",
    ag: float = 0.2,
    damping: float = 0.05,
    spectrum_type: int = 1,
) -> np.ndarray:
    """
    Design response spectrum according to Eurocode 8 (EN 1998-1).

    Horizontal elastic response spectrum:
        T ∈ [0, T_B)         : S_e = a_g · S · [1 + T/T_B · (η · 2.5 − 1)]
        T ∈ [T_B, T_C]       : S_e = a_g · S · η · 2.5
        T ∈ (T_C, T_D]       : S_e = a_g · S · η · 2.5 · T_C / T
        T ∈ (T_D, 4 s]       : S_e = a_g · S · η · 2.5 · T_C · T_D / T²

    Args:
        periods: Periods (seconds).
        site_class: Ground type A-E.
        ag: Design ground acceleration on type A ground (g).
        damping: Damping ratio.
        spectrum_type: 1 or 2.

    Returns:
        Elastic response spectrum S_e (g).
    """
    periods = np.asarray(periods).flatten()

    ec8_params = {
        "A": {
            "S_type1": 1.0,
            "T_B1": 0.15,
            "T_C1": 0.4,
            "T_D1": 2.0,
            "S_type2": 1.0,
            "T_B2": 0.05,
            "T_C2": 0.25,
            "T_D2": 1.2,
        },
        "B": {
            "S_type1": 1.2,
            "T_B1": 0.15,
            "T_C1": 0.5,
            "T_D1": 2.0,
            "S_type2": 1.35,
            "T_B2": 0.05,
            "T_C2": 0.25,
            "T_D2": 1.2,
        },
        "C": {
            "S_type1": 1.15,
            "T_B1": 0.20,
            "T_C1": 0.6,
            "T_D1": 2.0,
            "S_type2": 1.5,
            "T_B2": 0.10,
            "T_C2": 0.25,
            "T_D2": 1.2,
        },
        "D": {
            "S_type1": 1.35,
            "T_B1": 0.20,
            "T_C1": 0.8,
            "T_D1": 2.0,
            "S_type2": 1.8,
            "T_B2": 0.10,
            "T_C2": 0.30,
            "T_D2": 1.2,
        },
        "E": {
            "S_type1": 1.4,
            "T_B1": 0.15,
            "T_C1": 0.5,
            "T_D1": 2.0,
            "S_type2": 1.6,
            "T_B2": 0.05,
            "T_C2": 0.25,
            "T_D2": 1.2,
        },
    }
    if site_class not in ec8_params:
        raise ValueError(f"site_class must be one of {list(ec8_params.keys())}")

    p = ec8_params[site_class]
    if spectrum_type == 1:
        S = p["S_type1"]
        T_B = p["T_B1"]
        T_C = p["T_C1"]
        T_D = p["T_D1"]
    elif spectrum_type == 2:
        S = p["S_type2"]
        T_B = p["T_B2"]
        T_C = p["T_C2"]
        T_D = p["T_D2"]
    else:
        raise ValueError("spectrum_type must be 1 or 2")

    if damping == 0.05:
        eta = 1.0
    else:
        eta = max(np.sqrt(10.0 / (5.0 + damping)), 0.55)

    S_e = np.zeros(len(periods))
    for i, T in enumerate(periods):
        if T <= 0.0:
            S_e[i] = 0.0
        elif T < T_B:
            S_e[i] = ag * S * (1.0 + T / T_B * (eta * 2.5 - 1.0))
        elif T <= T_C:
            S_e[i] = ag * S * eta * 2.5
        elif T <= T_D:
            S_e[i] = ag * S * eta * 2.5 * (T_C / T)
        else:
            S_e[i] = ag * S * eta * 2.5 * (T_C * T_D) / (T**2)

    return S_e


def japan_spectrum(
    periods: np.ndarray,
    ground_type: int = 2,
    damping: float = 0.05,
    **kwargs,
) -> np.ndarray:
    """
    Design response spectrum according to Japan Building Standard Law.

    Acceleration response spectrum factor R_T:
        T ∈ [0, T_C)         : R_T = 1 + (R_opt − 1) · T / T_C
        T ∈ [T_C, T_1]       : R_T = R_opt
        T ∈ (T_1, T_2]       : R_T = R_opt · T_1 / T
        T > T_2              : R_T = R_opt · T_1 · T_2 / T²

    Args:
        periods: Periods (seconds).
        ground_type: Ground type 1, 2, or 3.
        damping: Damping ratio (default 0.05).

    Returns:
        Acceleration response spectrum factor R_T, dimensionless.
    """
    periods = np.asarray(periods).flatten()

    ground_params = {
        1: {"T_C": 0.16, "R_opt": 4.0, "T_1": 0.564, "T_2": 1.5},
        2: {"T_C": 0.24, "R_opt": 3.0, "T_1": 0.754, "T_2": 2.0},
        3: {"T_C": 0.32, "R_opt": 2.5, "T_1": 0.886, "T_2": 2.5},
    }
    if ground_type not in ground_params:
        raise ValueError(f"ground_type must be one of {list(ground_params.keys())}")

    gp = ground_params[ground_type]
    T_C = gp["T_C"]
    R_opt = gp["R_opt"]
    T_1 = gp["T_1"]
    T_2 = gp["T_2"]

    if damping == 0.05:
        F_h = 1.0
    else:
        F_h = 1.5 / (1.0 + 10.0 * damping)

    R_T = np.zeros(len(periods))
    for i, T in enumerate(periods):
        if T <= 0.0:
            R_T[i] = 0.0
        elif T < T_C:
            R_T[i] = 1.0 + (R_opt - 1.0) * T / T_C
        elif T <= T_1:
            R_T[i] = R_opt
        elif T <= T_2:
            R_T[i] = R_opt * T_1 / T
        else:
            R_T[i] = R_opt * T_1 * T_2 / (T**2)

    return R_T * F_h


def code_spectrum(
    periods: np.ndarray,
    code: str = "gb50011",
    **kwargs,
) -> np.ndarray:
    """
    Unified interface for design response spectra from various codes.

    Args:
        periods: Periods at which to compute the spectrum (seconds).
        code: Code identifier: 'gb50011', 'asce7', 'ec8', 'japan'
        **kwargs: Additional parameters specific to each code.

    Returns:
        Design spectral acceleration.
    """
    code = code.lower()

    if code == "gb50011":
        return gb50011_spectrum(periods, **kwargs)
    elif code == "asce7":
        return asce7_22_spectrum(periods, **kwargs)
    elif code == "ec8":
        return ec8_spectrum(periods, **kwargs)
    elif code == "japan":
        return japan_spectrum(periods, **kwargs)
    else:
        raise ValueError(f"Unknown code: {code}")


def plot_code_spectrum(
    periods: np.ndarray,
    spectrum: np.ndarray,
    code: str = None,
    ax=None,
    **kwargs,
):
    """
    Plot design response spectrum.

    Args:
        periods: Periods (seconds).
        spectrum: Response spectrum values.
        code: Code name for title.
        ax: Matplotlib axes object (optional).
        **kwargs: Additional arguments for plt.plot().

    Returns:
        Matplotlib axes object.
    """
    import matplotlib.pyplot as plt

    if ax is None:
        ax = plt.gca()

    ax.plot(periods, spectrum, **kwargs)

    if code is not None:
        title_map = {
            "gb50011": "GB 50011-2010 Design Spectrum",
            "asce7": "ASCE 7-22 Design Spectrum",
            "ec8": "Eurocode 8 Design Spectrum",
            "japan": "Japan Building Standard Law Spectrum",
        }
        ax.set_title(title_map.get(code, f"{code} Design Spectrum"))
    else:
        ax.set_title("Design Response Spectrum")

    ax.set_xlabel("Period (s)")
    ax.set_ylabel("Spectral Acceleration (g)")
    ax.grid(True, linestyle="--", alpha=0.7)
    ax.set_xscale("log")

    return ax
