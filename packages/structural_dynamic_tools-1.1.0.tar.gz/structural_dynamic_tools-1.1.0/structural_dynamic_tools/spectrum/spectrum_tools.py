"""
Supporting tools for spectrum analysis.

Includes functions for:
- Spectrum fitting quality assessment
- Ground motion scaling (dual-band)
- Spectrum-code compatibility checking
- Spectral parameter extraction
- Artificial ground motion generation
"""

import numpy as np


def spectrum_fit_score(
    target_spectrum: np.ndarray,
    computed_spectrum: np.ndarray,
    periods: np.ndarray,
    method: str = "rms",
) -> float:
    """
    Evaluate the fitting quality between computed and target spectra.

    Args:
        target_spectrum: Target/design spectrum values.
        computed_spectrum: Computed response spectrum values.
        periods: Periods at which spectra are defined.
        method: ``"rms"``, ``"max"``, ``"correlation"``, ``"sse"``, or ``"nrmse"``.

    Returns:
        Fit score (lower is better for ``"rms"``, ``"max"``, ``"sse"``;
        higher is better for ``"correlation"``).
    """
    target = np.asarray(target_spectrum)
    computed = np.asarray(computed_spectrum)
    periods = np.asarray(periods)

    if target.shape != computed.shape:
        raise ValueError("Target and computed spectra must have the same shape")

    mask = periods > 0
    target = target[mask]
    computed = computed[mask]

    if len(target) == 0:
        raise ValueError("No valid periods provided")

    if method.lower() == "rms":
        diff = target - computed
        return np.sqrt(np.mean(diff**2))
    elif method.lower() == "max":
        return np.max(np.abs(target - computed))
    elif method.lower() == "correlation":
        if np.std(target) == 0 or np.std(computed) == 0:
            return 0.0
        return np.corrcoef(target, computed)[0, 1]
    elif method.lower() == "sse":
        return np.sum((target - computed) ** 2)
    elif method.lower() == "nrmse":
        mean_target = np.mean(target)
        if mean_target == 0:
            return np.sqrt(np.mean((target - computed) ** 2))
        return np.sqrt(np.mean(((target - computed) / mean_target) ** 2))
    else:
        raise ValueError(f"Unknown method: {method}")


def scale_ground_motion(
    acc: np.ndarray,
    dt: float,
    target_spectrum: np.ndarray,
    periods: np.ndarray,
    damp: float = 0.05,
    freq_range: tuple | None = None,
) -> np.ndarray:
    """
    Scale ground motion to match target pseudo-acceleration response spectrum.

    Args:
        acc: Original ground acceleration time history.
        dt: Time step (seconds).
        target_spectrum: Target response spectrum.
        periods: Periods at which target spectrum is defined.
        damp: Damping ratio for spectrum computation.
        freq_range: Frequency range ``(f_min, f_max)`` for scaling.
            If None, use the full range.

    Returns:
        Scaled ground acceleration.
    """
    from .response_spectrum import response_spectrum

    acc = np.asarray(acc)
    _, _, _, psa, _ = response_spectrum(acc, dt, periods, damp)

    if freq_range is not None:
        f_min, f_max = freq_range
        mask = (periods >= 1.0 / f_max) & (periods <= 1.0 / f_min)
    else:
        mask = periods > 0

    scale_factor = np.mean(target_spectrum[mask] / psa[mask])
    return acc * scale_factor


def dual_band_scaling(
    acc: np.ndarray,
    dt: float,
    target_spectrum: np.ndarray,
    periods: np.ndarray,
    damp: float = 0.05,
    t_low: float = 0.1,
    t_high: float = 2.0,
) -> np.ndarray:
    """
    Dual-band scaling for ground motion.

    Scales the ground motion in two frequency bands independently:
    - Low-frequency band (long periods, ``T >= t_high``)
    - High-frequency band (short periods, ``T <= t_low``)

    Args:
        acc: Original ground acceleration time history.
        dt: Time step (seconds).
        target_spectrum: Target response spectrum.
        periods: Periods at which target spectrum is defined.
        damp: Damping ratio.
        t_low: Period threshold for high-frequency band.
        t_high: Period threshold for low-frequency band.

    Returns:
        Scaled ground acceleration.
    """
    from .response_spectrum import response_spectrum

    acc = np.asarray(acc)
    _, _, _, psa, _ = response_spectrum(acc, dt, periods, damp)

    low_mask = periods >= t_high
    high_mask = periods <= t_low

    if np.any(low_mask):
        scale_low = np.mean(target_spectrum[low_mask] / psa[low_mask])
    else:
        scale_low = 1.0

    if np.any(high_mask):
        scale_high = np.mean(target_spectrum[high_mask] / psa[high_mask])
    else:
        scale_high = 1.0

    n = len(acc)
    freqs = np.fft.rfftfreq(n, dt)
    acc_fft = np.fft.rfft(acc)

    omega_low = 2 * np.pi / t_high
    omega_high = 2 * np.pi / t_low

    scaled_fft = np.zeros_like(acc_fft)
    for i, f in enumerate(freqs):
        omega = 2 * np.pi * f
        if omega <= omega_low:
            scaled_fft[i] = acc_fft[i] * scale_low
        elif omega >= omega_high:
            scaled_fft[i] = acc_fft[i] * scale_high
        else:
            alpha = (omega - omega_low) / (omega_high - omega_low)
            scaled_fft[i] = acc_fft[i] * (scale_low * (1 - alpha) + scale_high * alpha)

    return np.fft.irfft(scaled_fft)


def check_spectrum_compatibility(
    acc: np.ndarray,
    dt: float,
    code: str = "gb50011",
    site_class: str = "II",
    ag: float = 0.1,
    **kwargs,
) -> dict:
    """
    Check if ground motion response spectrum is compatible with a design code.

    Computes the pseudo-acceleration spectrum of the record and compares
    it against the corresponding code design spectrum.

    Args:
        acc: Ground acceleration time history.
        dt: Time step (seconds).
        code: Code identifier (``"gb50011"``, ``"asce7"``, ``"ec8"``, ``"japan"``).
        site_class: Site classification.
        ag: Design ground motion acceleration.
        **kwargs: Additional parameters for code spectrum.

    Returns:
        Dictionary with keys ``"rms_error"``, ``"correlation"``,
        ``"is_compatible"``, ``"periods"``, ``"response_spectrum"``,
        ``"design_spectrum"``.
    """
    from .response_spectrum import response_spectrum
    from .code_spectrum import code_spectrum

    periods = np.logspace(-2, 2, 100)
    _, _, _, psa, _ = response_spectrum(acc, dt, periods)
    design_spec = code_spectrum(periods, code, site_class=site_class, ag=ag, **kwargs)

    score_rms = spectrum_fit_score(design_spec, psa, periods, method="rms")
    score_corr = spectrum_fit_score(design_spec, psa, periods, method="correlation")
    is_compatible = score_corr > 0.7 and score_rms < 0.1 * np.max(design_spec)

    return {
        "rms_error": score_rms,
        "correlation": score_corr,
        "is_compatible": is_compatible,
        "periods": periods,
        "response_spectrum": psa,
        "design_spectrum": design_spec,
    }


def plot_spectrum_comparison(
    periods: np.ndarray,
    spectra: dict,
    ax=None,
    **kwargs,
):
    """
    Plot multiple spectra for comparison.

    Args:
        periods: Periods (seconds).
        spectra: Dictionary of spectrum name → spectrum values.
        ax: Matplotlib axes object (optional).
        **kwargs: Forwarded to ``plt.plot()``.

    Returns:
        Matplotlib axes object.
    """
    import matplotlib.pyplot as plt

    if ax is None:
        ax = plt.gca()

    for name, spectrum in spectra.items():
        ax.plot(periods, spectrum, label=name, **kwargs)

    ax.set_xlabel("Period (s)")
    ax.set_ylabel("Spectral Acceleration")
    ax.set_xscale("log")
    ax.grid(True, linestyle="--", alpha=0.7)
    ax.legend()
    return ax


def compute_spectral_parameters(
    acc: np.ndarray,
    dt: float,
    periods: np.ndarray | None = None,
    damp: float = 0.05,
) -> dict:
    """
    Compute key spectral parameters from ground motion.

    Args:
        acc: Ground acceleration time history.
        dt: Time step (seconds).
        periods: Periods at which to compute spectrum. Defaults to
            ``SPECTRUM_PERIOD``.
        damp: Damping ratio.

    Returns:
        Dictionary with ``"pga"``, ``"pgv"``, ``"pgd"``,
        ``"sa_max"``, ``"t_max"``, ``"sa"``, ``"sv"``, ``"sd"``,
        ``"psa"``, ``"psv"``.
    """
    from .response_spectrum import response_spectrum, SPECTRUM_PERIOD

    if periods is None:
        periods = SPECTRUM_PERIOD
    periods = np.asarray(periods, dtype=np.float64)

    sa, sv, sd, psa, psv = response_spectrum(acc, dt, periods, damp)

    acc_flat = np.asarray(acc).flatten()
    pga = np.max(np.abs(acc_flat))
    pgv = np.max(np.abs(np.cumsum(acc_flat) * dt))
    pgdis = np.max(np.abs(np.cumsum(np.cumsum(acc_flat) * dt) * dt))

    idx_max = np.argmax(psa)
    t_max = periods[idx_max]
    sa_max = psa[idx_max]

    return {
        "pga": pga,
        "pgv": pgv,
        "pgd": pgdis,
        "sa_max": sa_max,
        "t_max": t_max,
        "sa": sa,
        "sv": sv,
        "sd": sd,
        "psa": psa,
        "psv": psv,
    }


def generate_artificial_ground_motion(
    target_spectrum: np.ndarray,
    periods: np.ndarray,
    dt: float,
    duration: float,
    damp: float = 0.05,
    seed: int | None = None,
) -> np.ndarray:
    """
    Generate artificial ground motion matching a target spectrum.

    Args:
        target_spectrum: Target response spectrum.
        periods: Periods at which target spectrum is defined.
        dt: Time step (seconds).
        duration: Duration of generated motion (seconds).
        damp: Damping ratio.
        seed: Random seed for reproducibility.

    Returns:
        Generated ground acceleration time history.
    """
    n = int(duration / dt)
    rng = np.random.default_rng(seed)

    freqs = np.fft.rfftfreq(n, dt)
    omega = 2 * np.pi * freqs

    s0 = np.zeros(len(freqs))
    for i, f in enumerate(freqs):
        if f == 0:
            s0[i] = 0.0
            continue
        T = 1.0 / f
        sa_target = np.interp(T, periods, target_spectrum)
        omega_n = 2 * np.pi / T
        denom = (omega_n**2 - omega[i] ** 2) ** 2 + (2 * damp * omega_n * omega[i]) ** 2
        h = 1.0 / np.sqrt(denom)
        s0[i] = sa_target / (omega_n**2 * h)

    phase = rng.uniform(0, 2 * np.pi, len(freqs))
    acc_fft = np.sqrt(s0) * np.exp(1j * phase)
    acc_fft[0] = 0.0

    acc = np.fft.irfft(acc_fft)
    acc = acc / np.max(np.abs(acc)) * np.max(target_spectrum)

    return acc
