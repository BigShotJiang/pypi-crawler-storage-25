# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: https://github.com/CoReason-AI/coreason-ecosystem

"""Von Neumann Expansion Loop — Thermodynamic Capital Scaling.

Monitors the sovereign treasury's on-chain balance via URN-based MCP
projection and automatically provisions physical GPU hardware via the
PricingOracle and PulumiActuator when sufficient reinvestment capital
is aggregated.

No mutable in-memory state is held.  The treasury balance is queried
exclusively through a Sovereign Treasury MCP at
``urn:coreason:state:treasury`` — the Governance Plane does not import
Web3 libraries or hold private keys.

The expansion loop integrates with the VFE (Variational Free Energy)
divergence assessment to enforce the Economic Guillotine per LAW 7
(Thermodynamic Cost Bounding / Ashby's Limit).
"""

from __future__ import annotations

from loguru import logger

from coreason_ecosystem.fleet.pricing_oracle import (
    PricingOracle,
    assess_thermodynamic_expenditure,
)
from coreason_ecosystem.gateway.sovereign_mcp_registry import SovereignMCPRegistry
from coreason_ecosystem.fleet.pulumi_actuator import PulumiActuator
from pathlib import Path

# Hardware threshold (approx 10,000,000,000 Gwei / ~10 ETH at historical rates)
HARDWARE_NODE_COST_GWEI = 10_000_000_000
SAFETY_MARGIN_GWEI = 2_000_000_000

# Polling cadence for the expansion daemon.
DEFAULT_POLLING_INTERVAL_SEC = 30.0

# URN for the Sovereign Treasury MCP.
TREASURY_URN = "urn:coreason:state:treasury"


async def von_neumann_expansion_daemon(
    registry: SovereignMCPRegistry,
    oracle: PricingOracle,
    max_budget_hr: float = 10.0,
    polling_interval_sec: float = DEFAULT_POLLING_INTERVAL_SEC,
) -> None:
    """Continuous daemon loop assessing capital scaling capabilities.

    Resolves the Sovereign Treasury MCP endpoint from the capability
    registry and queries it for on-chain balance via JSON-RPC.  The
    Governance Plane never holds Web3 state — it routes the query
    blindly through the URN.

    The loop runs a VFE divergence check each iteration.  If the threshold
    is breached, a ``TopologicalHaltIntent`` is logged and the loop exits
    to allow the fleet daemon to sever kinetic execution.

    Args:
        registry: The SovereignMCPRegistry for URN-based treasury resolution.
        oracle: The PricingOracle for dynamic hardware profile resolution.
        max_budget_hr: Maximum hourly budget for compute provisioning.
        polling_interval_sec: Seconds between polling iterations.
    """
    # Resolve the treasury endpoint from the Sovereign MCP matrix.
    try:
        treasury_endpoint = registry.resolve_urn(TREASURY_URN)
    except KeyError:
        logger.error(
            f"[ExpansionLoop] Treasury URN '{TREASURY_URN}' not registered in "
            "capabilities.matrix.yaml. Cannot initiate Von Neumann expansion."
        )
        return

    logger.info(
        "[ExpansionLoop] Initiated Von Neumann daemon. "
        f"Treasury projected via {treasury_endpoint}."
    )

    target_cost = HARDWARE_NODE_COST_GWEI + SAFETY_MARGIN_GWEI

    while True:
        # VFE divergence check — the Economic Guillotine gate.
        from coreason_manifest.spec.ontology import (
            SpatialHardwareProfile as HardwareProfile,
        )

        assessment = await assess_thermodynamic_expenditure(
            hardware_profile=HardwareProfile(
                min_vram_gb=1.0, provider_whitelist=["aws", "vast"]
            ),
            max_budget_hr=max_budget_hr,
        )
        if assessment.threshold_breached:
            logger.critical(
                "[ExpansionLoop] Economic Guillotine triggered. "
                "Halting expansion loop to prevent thermodynamic exhaustion."
            )
            actuator = PulumiActuator(Path.cwd() / "infrastructure")
            await actuator.execute_thermodynamic_guillotine(assessment)
            return

        # Query the Sovereign Treasury MCP for on-chain balance.
        # The Governance Plane opens an HTTP/SSE connection to the external
        # container — it does NOT import web3 or hold private keys.
        raise NotImplementedError(
            "Von Neumann Expansion Loop requires the Sovereign Treasury MCP "
            f"at {treasury_endpoint} to be deployed and serving JSON-RPC. "
            f"Target cost threshold: {target_cost} Gwei."
        )
