"""mcp-server-radia-interop — CAD-MCP mesh dispatcher.

**Sugawara Lab (菅原研) stance**: the official primary pair is
**build123d + Cubit**. All other CAD sources (CadQuery, OpenSCAD,
FreeCAD, Blender, Onshape, AutoCAD, KiCad, …) are treated as
compatibility layers routed through this interop module.

New lab work should be authored in **build123d** and meshed via
**Cubit** (`build123d_to_cubit_hex` + `cubit_mesh_auto`). This
module exists only to let legacy scripts and other CAD MCPs reuse
the same backend.

Tools:
  any_step_to_cubit_hex(step_path)          — universal STEP → hex
  openscad_to_cubit_hex(code)               — compat: OpenSCAD CLI
  freecad_to_cubit_hex(script)              — compat: FreeCADCmd
  list_cad_mcp_interop()                    — lists adapters with roles
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("mcp-server-radia-interop")


def _which(*candidates: str) -> str | None:
	for c in candidates:
		p = shutil.which(c)
		if p:
			return p
	return None


# Common Windows install locations — many CAD tools are installed but not
# added to PATH. Glob-expand and prefer highest-version-looking hit.
_WIN_OPENSCAD_GLOBS = [
	r"C:\Program Files\OpenSCAD\openscad.exe",
	r"C:\Program Files (x86)\OpenSCAD\openscad.exe",
]
_WIN_FREECAD_GLOBS = [
	r"C:\Program Files\FreeCAD*\bin\FreeCADCmd.exe",
	r"C:\Program Files\FreeCAD*\bin\FreeCAD.exe",
	r"C:\Program Files (x86)\FreeCAD*\bin\FreeCADCmd.exe",
]
_POSIX_OPENSCAD_GLOBS = [
	"/Applications/OpenSCAD.app/Contents/MacOS/OpenSCAD",
	"/usr/local/bin/openscad",
	"/usr/bin/openscad",
]
_POSIX_FREECAD_GLOBS = [
	"/Applications/FreeCAD.app/Contents/Resources/bin/FreeCADCmd",
	"/usr/local/bin/FreeCADCmd",
	"/usr/bin/FreeCADCmd",
]


def _glob_first(patterns: list[str]) -> str | None:
	import glob as _glob
	for pat in patterns:
		hits = sorted(_glob.glob(pat), reverse=True)  # newest version first
		for h in hits:
			if os.path.exists(h):
				return h
	return None


def _find_openscad() -> str | None:
	"""Locate the OpenSCAD binary. Priority:
	  1. $OPENSCAD env var
	  2. PATH via `shutil.which`
	  3. Platform-specific install globs (Windows Program Files, macOS)
	"""
	env = os.environ.get("OPENSCAD")
	if env and os.path.exists(env):
		return env
	w = _which("openscad", "OpenSCAD")
	if w:
		return w
	if os.name == "nt":
		return _glob_first(_WIN_OPENSCAD_GLOBS)
	return _glob_first(_POSIX_OPENSCAD_GLOBS)


def _find_freecad() -> str | None:
	"""Locate the FreeCADCmd / FreeCAD binary. Priority:
	  1. $FREECAD_CMD env var
	  2. PATH
	  3. Windows `Program Files/FreeCAD*` globs (latest-version wins)
	  4. macOS / Linux default install paths
	"""
	env = os.environ.get("FREECAD_CMD")
	if env and os.path.exists(env):
		return env
	w = _which("FreeCADCmd", "freecadcmd", "freecad-cmd",
	           "FreeCAD", "freecad")
	if w:
		return w
	if os.name == "nt":
		return _glob_first(_WIN_FREECAD_GLOBS)
	return _glob_first(_POSIX_FREECAD_GLOBS)


# ---------------------------------------------------------------------------
# Universal: any STEP → Cubit hex mesh
# ---------------------------------------------------------------------------

@mcp.tool()
def any_step_to_cubit_hex(step_path: str,
                           target_size: float = 1.0,
                           prefer: str = "hex",
                           commit_to_gui: bool = True,
                           timeout_s: int = 600) -> str:
	"""Universal CAD-MCP mesh backend: accept ANY STEP file and run it
	through `cubit_mesh_auto` (batch ladder → winner replayed in live
	Cubit GUI).

	Upstream sources that have been tested:
	  * build123d (via `build123d_to_cubit_hex`)
	  * cadquery (via `cadquery_to_cubit_hex`)
	  * OpenSCAD (via `openscad_to_cubit_hex`)
	  * FreeCAD / FreeCAD-MCP (via `freecad_to_cubit_hex` or any
	    FreeCAD STEP export)
	  * Blender-MCP, Onshape-MCP, AutoCAD-MCP, KiCad-MCP — any of
	    them; feed the exported STEP directly.

	This is the "advertised" backend door for the CAD-MCP ecosystem:
	other MCP authors can call this from their server knowing it
	will give a reliable hex mesh with GUI preview.

	Args:
	    step_path: path to a STEP file from any source.
	    target_size: `volume all size` for the mesh.
	    prefer: "hex" (require hex>0) or "any".
	    commit_to_gui: replay winning recipe in live Cubit GUI.
	    timeout_s: per-rung timeout.
	"""
	if not Path(step_path).exists():
		return json.dumps({"status": "error",
		                   "error": f"STEP not found: {step_path}"})
	try:
		from ..cubit.server import cubit_mesh_auto
	except ImportError as e:
		return json.dumps({"status": "error",
		                   "stage": "cubit_import",
		                   "error": str(e)})
	return cubit_mesh_auto(step_path=step_path.replace("\\", "/"),
	                        target_size=target_size,
	                        prefer=prefer,
	                        commit_to_gui=commit_to_gui,
	                        timeout_s=timeout_s)


# ---------------------------------------------------------------------------
# OpenSCAD adapter (CLI: openscad -o out.step in.scad)
# ---------------------------------------------------------------------------

@mcp.tool()
def openscad_to_cubit_hex(code: str,
                           target_size: float = 1.0,
                           prefer: str = "hex",
                           commit_to_gui: bool = True,
                           timeout_s: int = 600) -> str:
	"""Execute OpenSCAD code, export STEP, run through `cubit_mesh_auto`.

	Requires the `openscad` CLI on PATH (or `OPENSCAD` env var).
	OpenSCAD ≥ 2021.01 supports STEP export via `-o out.step`.

	Args:
	    code: OpenSCAD source (self-contained).
	    target_size / prefer / commit_to_gui / timeout_s: forwarded
	        to `cubit_mesh_auto`.
	"""
	exe = _find_openscad()
	if not exe:
		return json.dumps({
			"status": "error",
			"stage": "openscad_missing",
			"error": ("OpenSCAD CLI not found. Install OpenSCAD ≥ 2021.01 "
			          "(PATH, Windows Program Files, or $OPENSCAD env var)."),
		})

	tmp = Path(tempfile.mkdtemp(prefix="openscad_to_cubit_"))
	scad_path = tmp / "model.scad"
	step_path = tmp / "model.step"
	scad_path.write_text(code, encoding="utf-8")
	try:
		r = subprocess.run(
			[exe, "-o", str(step_path), str(scad_path)],
			capture_output=True, text=True, timeout=timeout_s,
		)
	except subprocess.TimeoutExpired:
		return json.dumps({"status": "error",
		                   "stage": "openscad_timeout",
		                   "error": f"exceeded {timeout_s}s"})
	except OSError as e:
		return json.dumps({"status": "error",
		                   "stage": "openscad_spawn",
		                   "error": str(e)})
	if r.returncode != 0 or not step_path.exists():
		return json.dumps({"status": "error",
		                   "stage": "openscad_export",
		                   "returncode": r.returncode,
		                   "stderr": (r.stderr or "")[-800:],
		                   "stdout": (r.stdout or "")[-400:]})

	# Hand off
	return any_step_to_cubit_hex(step_path=str(step_path),
	                              target_size=target_size,
	                              prefer=prefer,
	                              commit_to_gui=commit_to_gui,
	                              timeout_s=timeout_s)


# ---------------------------------------------------------------------------
# FreeCAD adapter (FreeCADCmd subprocess)
# ---------------------------------------------------------------------------

_FREECAD_WRAPPER = """\
# Auto-generated by radia-mcp freecad_to_cubit_hex.
# User script runs here; whatever ends up in the variable `shape` (or
# the module-level `__result__`) is exported to `{out_step}`.
import sys, traceback, Part
__result__ = None

try:
{indented}
except Exception as e:
    traceback.print_exc()
    sys.exit(1)

# Pick up result: prefer __result__, else `shape`, else last Part.Shape var
result = None
if __result__ is not None:
    result = __result__
elif 'shape' in dir() and hasattr(shape, 'exportStep'):
    result = shape
else:
    for _n in reversed(list(dir())):
        _o = eval(_n)
        if hasattr(_o, 'exportStep'):
            result = _o
            break

if result is None:
    print('NO_SHAPE')
    sys.exit(2)
try:
    result.exportStep(r"{out_step}")
except Exception:
    traceback.print_exc()
    sys.exit(3)
print('WROTE_STEP')
"""


@mcp.tool()
def freecad_to_cubit_hex(script: str,
                          target_size: float = 1.0,
                          prefer: str = "hex",
                          commit_to_gui: bool = True,
                          timeout_s: int = 600) -> str:
	"""Execute a FreeCAD script in a FreeCADCmd subprocess, export the
	resulting shape to STEP, run through `cubit_mesh_auto`.

	Requires `FreeCADCmd` (headless FreeCAD) on PATH (or `FREECAD_CMD`
	env var).  The script runs with `Part` pre-imported.  To indicate
	the shape to export, set `__result__ = your_shape` or leave a
	variable named `shape` in the namespace.

	Example (minimal):
	    ```python
	    box = Part.makeBox(10, 10, 10)
	    __result__ = box
	    ```

	Args:
	    script: FreeCAD Python snippet (runs with `Part` imported).
	    target_size / prefer / commit_to_gui / timeout_s: forwarded
	        to `cubit_mesh_auto`.
	"""
	exe = _find_freecad()
	if not exe:
		return json.dumps({
			"status": "error",
			"stage": "freecad_missing",
			"error": ("FreeCADCmd not found. Install FreeCAD (PATH, "
			          "Windows Program Files, /Applications, or "
			          "$FREECAD_CMD env var)."),
		})

	tmp = Path(tempfile.mkdtemp(prefix="freecad_to_cubit_"))
	step_path = tmp / "model.step"
	wrapper = tmp / "_wrapper.py"
	indented = "\n".join("    " + ln for ln in script.splitlines())
	wrapper.write_text(
		_FREECAD_WRAPPER.format(
			indented=indented,
			out_step=str(step_path).replace("\\", "/"),
		),
		encoding="utf-8",
	)
	try:
		r = subprocess.run(
			[exe, str(wrapper)],
			capture_output=True, text=True, timeout=timeout_s,
		)
	except subprocess.TimeoutExpired:
		return json.dumps({"status": "error",
		                   "stage": "freecad_timeout",
		                   "error": f"exceeded {timeout_s}s"})
	except OSError as e:
		return json.dumps({"status": "error",
		                   "stage": "freecad_spawn",
		                   "error": str(e)})
	if r.returncode != 0 or not step_path.exists():
		return json.dumps({"status": "error",
		                   "stage": "freecad_export",
		                   "returncode": r.returncode,
		                   "stderr": (r.stderr or "")[-800:],
		                   "stdout": (r.stdout or "")[-400:]})

	return any_step_to_cubit_hex(step_path=str(step_path),
	                              target_size=target_size,
	                              prefer=prefer,
	                              commit_to_gui=commit_to_gui,
	                              timeout_s=timeout_s)


# ---------------------------------------------------------------------------
# Introspection
# ---------------------------------------------------------------------------

@mcp.tool()
def list_cad_mcp_interop() -> str:
	"""List registered CAD-MCP interop adapters + their availability.

	Reports which upstream CAD tools are detected on this machine
	(OpenSCAD, FreeCAD) so callers know which one-shot tools will
	work end-to-end vs which will return a structured "not installed"
	error.
	"""
	adapters = [
		{
			"name": "build123d_to_cubit_hex",
			"tool": "gumyr/build123d",
			"requires": "pip install radia-mcp[build123d]",
			"detected": _try_import("build123d"),
			"where": "radia_mcp.build123d.server",
			"role": "PREFERRED — lab standard upstream CAD",
		},
		{
			"name": "any_step_to_cubit_hex",
			"tool": "any source with STEP export",
			"requires": "any STEP file on disk",
			"detected": True,
			"role": "universal fallback for any upstream CAD MCP",
		},
		{
			"name": "cadquery_to_cubit_hex",
			"tool": "CadQuery",
			"requires": "pip install radia-mcp[cadquery]",
			"detected": _try_import("cadquery"),
			"where": "radia_mcp.build123d.server",
			"role": "compat — OCCT sibling, cadquery-mcp interop",
		},
		{
			"name": "openscad_to_cubit_hex",
			"tool": "OpenSCAD ≥ 2021.01",
			"requires": "PATH / Windows Program Files / $OPENSCAD",
			"detected": _find_openscad() or False,
			"role": "compat — legacy OpenSCAD scripts",
		},
		{
			"name": "freecad_to_cubit_hex",
			"tool": "FreeCADCmd (headless FreeCAD)",
			"requires": "PATH / Windows Program Files/FreeCAD* / $FREECAD_CMD",
			"detected": _find_freecad() or False,
			"role": ("friendly — Sugawara Lab respects the FreeCAD "
			         "community; first-class interop path, not first-"
			         "class authoring"),
		},
	]
	# Convert detected-path strings to bool-ish for readability
	for a in adapters:
		d = a["detected"]
		if isinstance(d, str):
			a["detected_path"] = d
			a["detected"] = True
	return json.dumps({
		"status": "ok",
		"backend": "cubit_mesh_auto (batch ladder → live GUI replay)",
		"family": "radia-mcp universal CAD-MCP mesh dispatcher",
		"lab": "Sugawara Lab (菅原研), Kindai University",
		"primary_pair": "build123d (CAD authoring) + Cubit (hex mesh)",
		"preferred_upstream": "build123d (lab standard) — use "
		                       "build123d_to_cubit_hex / build123d_try / "
		                       "generate_build123d_script(pattern='...')",
		"note": ("OpenSCAD / FreeCAD / CadQuery adapters exist for "
		         "interop with legacy scripts or other CAD MCPs, but "
		         "new lab work should be authored in build123d and "
		         "meshed in Cubit."),
		"adapters": adapters,
	}, indent=2, ensure_ascii=False)


def _try_import(module: str) -> bool:
	try:
		__import__(module)
		return True
	except ImportError:
		return False


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
	if "--selftest" in sys.argv:
		print("radia-interop MCP server self-test:")
		print(list_cad_mcp_interop())
		return
	mcp.run(transport="stdio")


if __name__ == "__main__":
	main()
