"""
CLI entry point — `synth-data-tn generate`.

Usage examples:
    synth-data-tn generate
    synth-data-tn generate --domain banking
    synth-data-tn generate --domain banking --domain ecommerce
    synth-data-tn generate --n 500 --format parquet --seed 99 --output ./data
"""

from __future__ import annotations

import time
from pathlib import Path

import click

from synth_data_tn.config import GeneratorConfig, OutputFormat
from synth_data_tn.pipeline import available_domains, run_pipeline


@click.group()
def cli() -> None:
    """Synthetic Tunisian data generator — ecommerce, banking, telecom."""


@cli.command()
@click.option(
    "--n", default=100, show_default=True, help="Base entity count per domain."
)
@click.option(
    "--domain",
    "domains",
    multiple=True,
    type=click.Choice(available_domains(), case_sensitive=False),
    help="Domain to generate. Repeatable. Defaults to all.",
)
@click.option(
    "--format",
    "fmt",
    default="csv",
    show_default=True,
    type=click.Choice(["csv", "parquet"], case_sensitive=False),
    help="Output file format.",
)
@click.option(
    "--seed", default=42, show_default=True, help="RNG seed for reproducible datasets."
)
@click.option(
    "--output",
    "output_dir",
    default="output",
    show_default=True,
    type=click.Path(),
    help="Directory where files are saved.",
)
def generate(n: int, domains: tuple, fmt: str, seed: int, output_dir: str) -> None:
    """Generate synthetic Tunisian datasets and save them to disk."""

    config = GeneratorConfig(
        seed=seed,
        output_dir=Path(output_dir),
        output_format=OutputFormat(fmt),
    )

    selected = list(domains) if domains else None
    label = ", ".join(selected) if selected else "all"

    click.echo(f"\n{'─' * 60}")
    click.echo(f"  synth-data-tn  |  n={n}  seed={seed}  format={fmt}")
    click.echo(f"  domains → {label}")
    click.echo(f"  output  → {config.output_dir.resolve()}")
    click.echo(f"{'─' * 60}\n")

    start = time.perf_counter()
    written = run_pipeline(config, n, domains=selected)
    elapsed = time.perf_counter() - start

    click.echo(f"\n{'─' * 60}")
    click.echo(f"  ✅  {len(written)} files written in {elapsed:.2f}s")
    click.echo(f"{'─' * 60}\n")


def main() -> None:
    cli()


if __name__ == "__main__":
    main()
