"""
Pipeline — the single orchestration entry point.

Adding a new domain = one import + one entry in _GENERATORS. Nothing else changes.
"""

from __future__ import annotations

from pathlib import Path

from synth_data_tn.config import GeneratorConfig
from synth_data_tn.core.base import BaseGenerator
from synth_data_tn.core.exporter import DataExporter
from synth_data_tn.domains import BankingGenerator, EcommerceGenerator, TelecomGenerator

_GENERATORS: dict[str, type[BaseGenerator]] = {
    "ecommerce": EcommerceGenerator,
    "banking": BankingGenerator,
    "telecom": TelecomGenerator,
}


def available_domains() -> list[str]:
    """Return the list of registered domain names."""
    return list(_GENERATORS.keys())


def run_pipeline(
    config: GeneratorConfig,
    n: int,
    domains: list[str] | None = None,
) -> list[Path]:
    selected = domains or available_domains()

    invalid = set(selected) - _GENERATORS.keys()
    if invalid:
        raise ValueError(
            f"Unknown domain(s): {invalid}. Available: {set(_GENERATORS.keys())}"
        )

    exporter = DataExporter(config)
    written: list[Path] = []

    for domain in selected:
        generator = _GENERATORS[domain](config)
        datasets: dict = generator.generate(n)

        for dataset_name, df in datasets.items():
            path = exporter.export(df, dataset_name)
            written.append(path)
            print(f"  ✓  {dataset_name:<35} {len(df):>6} rows  →  {path}")

    return written
