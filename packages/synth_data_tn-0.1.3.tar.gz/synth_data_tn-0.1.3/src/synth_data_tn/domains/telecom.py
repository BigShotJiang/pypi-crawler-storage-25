"""
Telecom domain generator.

Produces two correlated datasets:
  - subscribers  : mobile subscribers with operator & plan
  - usage        : monthly data/call usage records per subscriber
"""

from __future__ import annotations

import uuid

import pandas as pd

from synth_data_tn.core.base import BaseGenerator

_RECHARGE_METHODS = ["Boutique", "Application mobile", "SMS", "Tabac/Presse", "ATM"]


class TelecomGenerator(BaseGenerator):
    def generate(self, n: int) -> dict[str, pd.DataFrame]:  # type: ignore[override]
        """
        Generate correlated telecom datasets.

        Args:
            n: Number of subscribers. Usage records ~= n * 6 (6 months).

        Returns:
            Dict with keys: "telecom_subscribers", "telecom_usage".
        """
        self._validate_n(n)

        subscribers = self._generate_subscribers(n)
        usage = self._generate_usage(
            subscriber_ids=subscribers["subscriber_id"].tolist(),
            n_records=n * 6,
        )

        return {
            "telecom_subscribers": subscribers,
            "telecom_usage": usage,
        }

    # ------------------------------------------------------------------ #
    # Private builders                                                     #
    # ------------------------------------------------------------------ #

    def _generate_subscribers(self, n: int) -> pd.DataFrame:
        records = []
        for _ in range(n):
            plan = self.fake.tn_telecom_plan()
            city, gov = self.tn_location()
            records.append(
                {
                    "subscriber_id": str(uuid.uuid4()),
                    "full_name": self.fake.tn_full_name(),
                    "phone": self.fake.tn_phone(),
                    "city": city,
                    "governorate": gov,
                    "operator": self.fake.tn_operator(),
                    "plan_name": plan["name"],
                    "plan_data_gb": plan["data_gb"],
                    "plan_monthly_fee_tnd": plan["monthly_fee_tnd"],
                    "subscribed_at": self.fake.date_between(
                        start_date="-5y", end_date="today"
                    ).isoformat(),
                    "is_active": self.fake.boolean(chance_of_getting_true=88),
                }
            )
        return pd.DataFrame(records)

    def _generate_usage(
        self, subscriber_ids: list[str], n_records: int
    ) -> pd.DataFrame:
        records = []
        for _ in range(n_records):
            data_limit = self.fake.random_element([5, 20, 50, None])
            data_consumed = (
                round(
                    self.fake.pyfloat(
                        min_value=0.1, max_value=data_limit, right_digits=2
                    ),
                    2,
                )
                if data_limit
                else round(
                    self.fake.pyfloat(min_value=0.1, max_value=200, right_digits=2), 2
                )
            )
            records.append(
                {
                    "usage_id": str(uuid.uuid4()),
                    "subscriber_id": self.fake.random_element(subscriber_ids),
                    "month": self.fake.date_between(
                        start_date="-6M", end_date="today"
                    ).strftime("%Y-%m"),
                    "data_consumed_gb": data_consumed,
                    "calls_minutes": self.fake.random_int(min=0, max=1800),
                    "sms_count": self.fake.random_int(min=0, max=300),
                    "recharge_amount_tnd": round(
                        self.fake.pyfloat(min_value=5, max_value=100, right_digits=3), 3
                    ),
                    "recharge_method": self.fake.random_element(_RECHARGE_METHODS),
                }
            )
        return pd.DataFrame(records)
