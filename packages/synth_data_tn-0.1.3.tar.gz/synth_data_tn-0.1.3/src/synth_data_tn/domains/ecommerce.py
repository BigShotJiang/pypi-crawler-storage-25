"""
E-commerce domain generator.

Produces three correlated datasets:
  - customers  : buyer profiles
  - products   : product catalogue snapshot
  - orders     : purchase transactions linking customers ↔ products

Correlation strategy:
  Customer IDs and product IDs are generated first, then orders
  reference them by sampling — this makes the dataset JOIN-ready.
"""

from __future__ import annotations

import uuid
from datetime import timedelta

import pandas as pd

from synth_data_tn.core.base import BaseGenerator


class EcommerceGenerator(BaseGenerator):
    def generate(self, n: int) -> dict[str, pd.DataFrame]:  # type: ignore[override]
        """
        Generate correlated e-commerce datasets.

        Args:
            n: Number of customers. Orders ~= n * 3, products = 15 (catalogue).

        Returns:
            Dict with keys: "ecommerce_customers", "ecommerce_products", "ecommerce_orders".
        """
        self._validate_n(n)

        customers = self._generate_customers(n)
        products = self._generate_products()
        orders = self._generate_orders(
            customer_ids=customers["customer_id"].tolist(),
            product_ids=products["product_id"].tolist(),
            n_orders=n * 3,
        )

        return {
            "ecommerce_customers": customers,
            "ecommerce_products": products,
            "ecommerce_orders": orders,
        }

    # ------------------------------------------------------------------ #
    # Private builders                                                     #
    # ------------------------------------------------------------------ #

    def _generate_customers(self, n: int) -> pd.DataFrame:
        records = []
        for _ in range(n):
            gender = self.fake.random_element(["male", "female"])
            city, gov = self.tn_location()
            records.append(
                {
                    "customer_id": str(uuid.uuid4()),
                    "full_name": self.fake.tn_full_name(gender),
                    "gender": gender,
                    "phone": self.fake.tn_phone(),
                    "city": city,
                    "governorate": gov,
                    "registered_at": self.fake.date_time_between(
                        start_date="-3y", end_date="now"
                    ).isoformat(),
                }
            )
        return pd.DataFrame(records)

    def _generate_products(self) -> pd.DataFrame:
        """Products are seeded from the curated catalogue — not random."""
        from synth_data_tn.providers.tn_provider import TunisianProvider

        records = []
        for item in TunisianProvider._PRODUCT_CATALOG:  # TunisianProvider is last
            lo, hi = item["price_range"]
            records.append(
                {
                    "product_id": str(uuid.uuid4()),
                    "name": item["name"],
                    "category": item["category"],
                    "price_tnd": round(
                        self.fake.pyfloat(min_value=lo, max_value=hi, right_digits=3), 3
                    ),
                }
            )
        return pd.DataFrame(records)

    def _generate_orders(
        self,
        customer_ids: list[str],
        product_ids: list[str],
        n_orders: int,
    ) -> pd.DataFrame:
        records = []
        for _ in range(n_orders):
            qty = self.fake.random_int(min=1, max=5)
            order_date = self.fake.date_time_between(start_date="-2y", end_date="now")
            estimated_delivery = order_date + timedelta(
                days=self.fake.random_int(min=2, max=10)
            )

            records.append(
                {
                    "order_id": str(uuid.uuid4()),
                    "customer_id": self.fake.random_element(customer_ids),
                    "product_id": self.fake.random_element(product_ids),
                    "quantity": qty,
                    "unit_price_tnd": round(
                        self.fake.pyfloat(min_value=10, max_value=3000, right_digits=3),
                        3,
                    ),
                    "total_price_tnd": round(
                        qty
                        * self.fake.pyfloat(
                            min_value=10, max_value=3000, right_digits=3
                        ),
                        3,
                    ),
                    "status": self.fake.tn_order_status(),
                    "payment_method": self.fake.tn_payment_method(),
                    "ordered_at": order_date.isoformat(),
                    "estimated_delivery": estimated_delivery.date().isoformat(),
                }
            )
        return pd.DataFrame(records)
