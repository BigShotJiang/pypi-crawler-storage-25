"""
Banking domain generator.

Produces two correlated datasets:
  - accounts     : bank account profiles
  - transactions : debit/credit movements on those accounts

Realism notes:
  - Balance is kept plausible (5 TND → 150 000 TND range).
  - Transaction amounts respect typical retail banking patterns.
  - Categories mirror real Tunisian spending behaviour.
"""

from __future__ import annotations

import uuid

import pandas as pd

from synth_data_tn.core.base import BaseGenerator

_TRANSACTION_CATEGORIES = [
    "Alimentation",
    "Transport",
    "Santé",
    "Éducation",
    "Loisirs",
    "Vêtements",
    "Électronique",
    "Immobilier",
    "Restaurant",
    "Voyage",
    "Services publics",
    "Transfert",
]

_TRANSACTION_TYPES = ["Débit", "Crédit"]


class BankingGenerator(BaseGenerator):
    def generate(self, n: int) -> dict[str, pd.DataFrame]:  # type: ignore[override]
        """
        Generate correlated banking datasets.

        Args:
            n: Number of accounts. Transactions ~= n * 10.

        Returns:
            Dict with keys: "banking_accounts", "banking_transactions".
        """
        self._validate_n(n)

        accounts = self._generate_accounts(n)
        transactions = self._generate_transactions(
            account_ids=accounts["account_id"].tolist(),
            n_transactions=n * 10,
        )

        return {
            "banking_accounts": accounts,
            "banking_transactions": transactions,
        }

    # ------------------------------------------------------------------ #
    # Private builders                                                     #
    # ------------------------------------------------------------------ #

    def _generate_accounts(self, n: int) -> pd.DataFrame:
        records = []
        for _ in range(n):
            bank_name, bank_abbr = self.fake.tn_bank()
            city, gov = self.tn_location()
            records.append(
                {
                    "account_id": str(uuid.uuid4()),
                    "owner_name": self.fake.tn_full_name(),
                    "phone": self.fake.tn_phone(),
                    "governorate": gov,
                    "city": city,
                    "bank_name": bank_name,
                    "bank_abbr": bank_abbr,
                    "iban": self.fake.tn_iban(),
                    "account_type": self.fake.tn_account_type(),
                    "balance_tnd": round(
                        self.fake.pyfloat(
                            min_value=5, max_value=150_000, right_digits=3
                        ),
                        3,
                    ),
                    "opened_at": self.fake.date_between(
                        start_date="-10y", end_date="today"
                    ).isoformat(),
                    "is_active": self.fake.boolean(chance_of_getting_true=92),
                }
            )
        return pd.DataFrame(records)

    def _generate_transactions(
        self, account_ids: list[str], n_transactions: int
    ) -> pd.DataFrame:
        records = []
        for _ in range(n_transactions):
            tx_type = self.fake.random_element(_TRANSACTION_TYPES)
            records.append(
                {
                    "transaction_id": str(uuid.uuid4()),
                    "account_id": self.fake.random_element(account_ids),
                    "type": tx_type,
                    "amount_tnd": round(
                        self.fake.pyfloat(min_value=1, max_value=5_000, right_digits=3),
                        3,
                    ),
                    "category": self.fake.random_element(_TRANSACTION_CATEGORIES),
                    "merchant": self.fake.company(),
                    "city": self.fake.tn_city(),
                    "executed_at": self.fake.date_time_between(
                        start_date="-2y", end_date="now"
                    ).isoformat(),
                    "reference": self.fake.bothify(text="TXN-####-????").upper(),
                }
            )
        return pd.DataFrame(records)
