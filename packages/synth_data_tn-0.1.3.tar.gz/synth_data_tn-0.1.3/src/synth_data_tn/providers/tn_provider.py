"""
Tunisian Faker provider.

Extends BaseProvider with locale-specific data that Faker's built-in
ar_TN / fr_TN locales don't cover (banks, operators, cities, names).
"""

from __future__ import annotations

import random
from faker.providers import BaseProvider


class TunisianProvider(BaseProvider):
    """Faker provider for Tunisian-specific data."""

    # ------------------------------------------------------------------ #
    # Geography                                                            #
    # ------------------------------------------------------------------ #
    _GOVERNORATE_CITIES: dict[str, list[str]] = {
        "Tunis": [
            "Médina",
            "Bab Souika",
            "Carthage",
            "Le Bardo",
            "La Marsa",
            "Sidi Hassine",
            "Ezzouhour",
            "Cité El Khadra",
        ],
        "Ariana": [
            "Ariana",
            "La Soukra",
            "Raoued",
            "Sidi Thabet",
            "Ettadhamen",
            "Mnihla",
            "Kalâat el-Andalous",
        ],
        "Ben Arous": [
            "Ben Arous",
            "Radès",
            "Mégrine",
            "El Mourouj",
            "Hammam Lif",
            "Hammam Chott",
            "Fouchana",
            "Mornag",
        ],
        "Manouba": [
            "Manouba",
            "Den Den",
            "Douar Hicher",
            "Oued Ellil",
            "Tébourba",
            "Djedeida",
            "Mornaguia",
            "Borj El Amri",
        ],
        "Nabeul": [
            "Nabeul",
            "Hammamet",
            "Kelibia",
            "Grombalia",
            "Soliman",
            "Korba",
            "El Haouaria",
            "Béni Khiar",
        ],
        "Zaghouan": [
            "Zaghouan",
            "El Fahs",
            "Nadhour",
            "Zriba",
            "Bir Mcherga",
            "Saouaf",
        ],
        "Bizerte": [
            "Bizerte",
            "Menzel Bourguiba",
            "Mateur",
            "Ras Jebel",
            "Sejnane",
            "Ghezala",
            "Ghar El Melh",
            "Utique",
        ],
        "Béja": [
            "Béja",
            "Medjez el-Bab",
            "Testour",
            "Téboursouk",
            "Goubellat",
            "Nefza",
            "Thibar",
            "Amdoun",
        ],
        "Jendouba": [
            "Jendouba",
            "Tabarka",
            "Aïn Draham",
            "Bou Salem",
            "Ghardimaou",
            "Fernana",
            "Oued Mliz",
        ],
        "Le Kef": [
            "Le Kef",
            "Dahmani",
            "Sers",
            "Tajerouine",
            "Nebeur",
            "Sakiet Sidi Youssef",
            "Touiref",
        ],
        "Siliana": [
            "Siliana",
            "Makthar",
            "Rouhia",
            "Kesra",
            "Bou Arada",
            "Gaafour",
            "Bargou",
            "El Aroussa",
        ],
        "Sousse": [
            "Sousse",
            "Msaken",
            "Kalaa Kebira",
            "Akouda",
            "Hammam Sousse",
            "Enfidha",
            "Sidi Bou Ali",
            "Kondar",
        ],
        "Monastir": [
            "Monastir",
            "Ksar Hellal",
            "Moknine",
            "Jemmal",
            "Téboulba",
            "Zeramdine",
            "Bekalta",
            "Sayada",
        ],
        "Mahdia": [
            "Mahdia",
            "El Jem",
            "Chebba",
            "Ksour Essef",
            "Bou Merdes",
            "Souassi",
            "Sidi Alouane",
        ],
        "Sfax": [
            "Sfax",
            "Sakiet Ezzit",
            "Agareb",
            "Jebeniana",
            "Mahres",
            "Kerkennah",
            "Bir Ali Ben Khalifa",
            "Skhira",
        ],
        "Kairouan": [
            "Kairouan",
            "Sbikha",
            "Haffouz",
            "Oueslatia",
            "Hajeb El Ayoun",
            "Nasrallah",
            "Bouhajla",
            "Chebika",
        ],
        "Kasserine": [
            "Kasserine",
            "Sbeitla",
            "Thala",
            "Foussana",
            "Feriana",
            "Haïdra",
            "Jedeliane",
        ],
        "Sidi Bouzid": [
            "Sidi Bouzid",
            "Regueb",
            "Jelma",
            "Meknassy",
            "Bir El Hafey",
            "Sidi Ali Ben Aoun",
            "Mezzouna",
        ],
        "Gabès": [
            "Gabès",
            "El Hamma",
            "Mareth",
            "Matmata",
            "Nouvelle Matmata",
            "Ghannouch",
            "Métouia",
        ],
        "Médenine": [
            "Médenine",
            "Zarzis",
            "Houmt Souk",
            "Midoun",
            "Ben Gardane",
            "Beni Khedache",
            "Sidi Makhlouf",
        ],
        "Tataouine": [
            "Tataouine",
            "Ghomrassen",
            "Bir Lahmar",
            "Remada",
            "Dehiba",
            "Smar",
        ],
        "Gafsa": [
            "Gafsa",
            "Métlaoui",
            "Moularès",
            "Redeyef",
            "Om Larayes",
            "Sidi Aïch",
            "Belkhir",
        ],
        "Tozeur": ["Tozeur", "Nefta", "Degache", "Tameghza", "Hazoua"],
        "Kebili": ["Kebili", "Douz", "Faouar", "Souk Lahad", "El Golaa"],
    }

    # ------------------------------------------------------------------ #
    # Names (bilingual: Arabic & French — reflects Tunisian reality)       #
    # ------------------------------------------------------------------ #

    _FIRST_NAMES_MALE: list[str] = [
        "Mohamed",
        "Ahmed",
        "Ali",
        "Youssef",
        "Omar",
        "Khalil",
        "Amine",
        "Hamza",
        "Sami",
        "Tarek",
        "Bilel",
        "Nader",
        "Anis",
        "Rami",
        "Hatem",
        "Slim",
        "Mehdi",
        "Fares",
        "Wassim",
        "Lotfi",
        "Karim",
        "Walid",
        "Skander",
        "Aymen",
        "Aziz",
        "Riadh",
        "Kais",
        "Moez",
        "Hichem",
        "Zied",
        "Imed",
        "Mounir",
        "Nabil",
        "Chokri",
        "Seif",
        "Seifeddine",
        "Ala",
        "Ghassen",
        "Marwen",
        "Maher",
        "Jawher",
        "Nidhal",
        "Haythem",
        "Fethi",
        "Sofiene",
        "Montassar",
        "Makram",
        "Atef",
        "Kamel",
        "Raouf",
        "Jalel",
        "Badis",
        "Yassine",
        "Oussema",
        "Sabri",
        "Bassem",
        "Adel",
        "Houssem",
        "Naoufel",
        "Hedi",
    ]

    _FIRST_NAMES_FEMALE: list[str] = [
        "Fatma",
        "Mariem",
        "Amira",
        "Salma",
        "Nour",
        "Ines",
        "Rania",
        "Hana",
        "Asma",
        "Sana",
        "Leila",
        "Rim",
        "Yasmine",
        "Wafa",
        "Donia",
        "Nadia",
        "Chaima",
        "Olfa",
        "Sarra",
        "Maha",
        "Aicha",
        "Khadija",
        "Sihem",
        "Manel",
        "Dorra",
        "Rahma",
        "Afef",
        "Souhir",
        "Emna",
        "Hela",
        "Marwa",
        "Aya",
        "Amani",
        "Nesrine",
        "Lobna",
        "Houda",
        "Syrine",
        "Malek",
        "Imen",
        "Nermine",
        "Ghofrane",
        "Racha",
        "Samia",
        "Najla",
        "Mouna",
        "Sabrine",
        "Amel",
        "Feten",
        "Ikram",
        "Radhia",
        "Feryel",
        "Kenza",
        "Lina",
        "Abeer",
        "Hanen",
        "Ons",
        "Eya",
        "Zeineb",
        "Sondos",
        "Rihab",
    ]

    _LAST_NAMES: list[str] = [
        "Ben Ali",
        "Trabelsi",
        "Chaabane",
        "Bouzid",
        "Hamdi",
        "Nasri",
        "Mrad",
        "Saidi",
        "Cherif",
        "Mansouri",
        "Boukadi",
        "Riahi",
        "Gharbi",
        "Jlassi",
        "Ouali",
        "Khelil",
        "Ferchichi",
        "Dridi",
        "Tlili",
        "Amri",
        "Ben Salah",
        "Ben Romdhane",
        "Zouari",
        "Mejri",
        "Ayari",
        "Abid",
        "Akrout",
        "Allani",
        "Baccar",
        "Baccouche",
        "Baklouti",
        "Barhoumi",
        "Belhadj",
        "Ben Ahmed",
        "Ben Amor",
        "Ben Brahim",
        "Ben Hassine",
        "Ben Mahmoud",
        "Ben Mustapha",
        "Ben Yahia",
        "Bennour",
        "Bessaoud",
        "Brahmi",
        "Chatti",
        "Chebbi",
        "Dhaouadi",
        "Fakhfakh",
        "Frikha",
        "Gdoura",
        "Ghariani",
        "Gharsalli",
        "Guezguez",
        "Haddad",
        "Hajji",
        "Hallouli",
        "Jaziri",
        "Karray",
        "Kasmi",
        "Kefi",
        "Kharrat",
        "Kooli",
        "Laabidi",
        "Lassoued",
        "Mabrouk",
        "Maatoug",
        "Mahjoub",
        "Mekki",
        "Miled",
        "Mnif",
        "Nefzi",
        "Rekik",
        "Sellami",
        "Siala",
        "Souissi",
        "Touati",
        "Yacoubi",
        "Zoghlami",
        "Kammoun",
        "Guesmi",
        "Bejaoui",
        "Heni",
        "Ben Hmida",
        "Masmoudi",
        "Bouhlel",
        "Bouazizi",
        "Charfi",
        "Kchaou",
        "Ksentini",
        "Mzoughi",
        "Smaoui",
        "Ben Abdallah",
        "Bahloul",
        "Bouchnak",
        "Dabboussi",
    ]

    # ------------------------------------------------------------------ #
    # Banking                                                              #
    # ------------------------------------------------------------------ #
    _BANKS: list[tuple[str, str]] = [
        ("Banque Nationale Agricole", "BNA"),
        ("Société Tunisienne de Banque", "STB"),
        ("Banque Internationale Arabe de Tunisie", "BIAT"),
        ("Attijari Bank Tunisie", "ATB"),
        ("Union Internationale de Banques", "UIB"),
        ("Banque de Tunisie", "BT"),
        ("Amen Bank", "AB"),
        ("Arab Tunisian Bank", "ATB"),
        ("Banque de l'Habitat", "BH"),
        ("Zitouna Bank", "ZB"),
        ("Al Baraka Bank", "ABT"),
    ]

    _ACCOUNT_TYPES: list[str] = ["Courant", "Épargne", "Professionnel"]

    # ------------------------------------------------------------------ #
    # Telecom                                                              #
    # ------------------------------------------------------------------ #
    _OPERATORS: list[str] = ["Ooredoo", "Orange Tunisie", "Tunisie Telecom"]

    _TELECOM_PLANS: list[dict] = [
        {"name": "Go 5", "data_gb": 5, "monthly_fee_tnd": 15.0},
        {"name": "Go 20", "data_gb": 20, "monthly_fee_tnd": 29.0},
        {"name": "Go 50", "data_gb": 50, "monthly_fee_tnd": 49.0},
        {"name": "Unlimited", "data_gb": None, "monthly_fee_tnd": 79.0},
    ]

    # ------------------------------------------------------------------ #
    # E-commerce                                                           #
    # ------------------------------------------------------------------ #
    _PRODUCT_CATALOG: list[dict] = [
        {
            "name": "Smartphone Samsung Galaxy A54",
            "category": "Électronique",
            "price_range": (699, 999),
        },
        {
            "name": "Laptop HP 15",
            "category": "Électronique",
            "price_range": (1800, 3200),
        },
        {
            "name": "Écouteurs JBL Tune",
            "category": "Électronique",
            "price_range": (89, 199),
        },
        {"name": "T-shirt Polo", "category": "Vêtements", "price_range": (25, 80)},
        {"name": "Jean Slim", "category": "Vêtements", "price_range": (60, 150)},
        {"name": "Robe Été", "category": "Vêtements", "price_range": (40, 120)},
        {
            "name": "Huile d'olive Chemlali 1L",
            "category": "Alimentation",
            "price_range": (12, 25),
        },
        {
            "name": "Harissa traditionnelle 200g",
            "category": "Alimentation",
            "price_range": (4, 10),
        },
        {
            "name": "Dattes Deglet Nour 1kg",
            "category": "Alimentation",
            "price_range": (15, 35),
        },
        {"name": "Canapé 3 places", "category": "Maison", "price_range": (800, 2500)},
        {"name": "Table à manger", "category": "Maison", "price_range": (400, 1200)},
        {"name": "Chaussures de sport", "category": "Sport", "price_range": (120, 350)},
        {"name": "Vélo de ville", "category": "Sport", "price_range": (350, 900)},
        {
            "name": "Livre Arabe-Français",
            "category": "Librairie",
            "price_range": (8, 35),
        },
        {"name": "Parfum local Jasmin", "category": "Beauté", "price_range": (30, 90)},
    ]

    _ORDER_STATUSES: list[str] = [
        "En attente",
        "Confirmée",
        "En cours de livraison",
        "Livrée",
        "Annulée",
        "Retournée",
    ]

    _PAYMENT_METHODS: list[str] = [
        "Carte bancaire",
        "Virement",
        "Paiement à la livraison",
        "D17",
        "Flouci",
    ]

    # ------------------------------------------------------------------ #
    # Public interface                                                      #
    # ------------------------------------------------------------------ #

    def tn_first_name(self, gender: str | None = None) -> str:
        if gender == "male":
            return self.random_element(self._FIRST_NAMES_MALE)
        if gender == "female":
            return self.random_element(self._FIRST_NAMES_FEMALE)
        pool = self._FIRST_NAMES_MALE + self._FIRST_NAMES_FEMALE
        return self.random_element(pool)

    def tn_last_name(self) -> str:
        return self.random_element(self._LAST_NAMES)

    def tn_full_name(self, gender: str | None = None) -> str:
        return f"{self.tn_first_name(gender)} {self.tn_last_name()}"

    def tn_city(self, governorate: str | None = None) -> str:
        """Return a city, optionally constrained to a specific governorate."""
        if governorate:
            cities = self._GOVERNORATE_CITIES.get(governorate)
            if not cities:
                raise ValueError(f"Unknown governorate: {governorate!r}")
            return self.random_element(cities)
        # Pick from all cities, preserving uniform distribution over governorates
        gov = self.tn_governorate()
        return self.random_element(self._GOVERNORATE_CITIES[gov])

    def tn_governorate(self) -> str:
        return self.random_element(list(self._GOVERNORATE_CITIES.keys()))

    def tn_governorate_and_city(self) -> tuple[str, str]:
        """Return a consistent (governorate, city) pair."""
        gov = self.tn_governorate()
        city = self.random_element(self._GOVERNORATE_CITIES[gov])
        return gov, city

    def tn_address(self) -> dict:
        """Return a full consistent address dict."""
        gov, city = self.tn_governorate_and_city()
        return {"city": city, "governorate": gov}

    def tn_phone(self) -> str:
        """Tunisian mobile: +216 [2|4|5|9]X XXX XXX"""
        prefix = self.random_element(
            [
                "20",
                "25",
                "50",
                "52",
                "55",
                "90",
                "92",
                "93",
                "94",
                "95",
                "97",
                "98",
                "99",
            ]
        )
        suffix = self.numerify("######")
        return f"+216 {prefix} {suffix[:3]} {suffix[3:]}"

    def tn_bank(self) -> tuple[str, str]:
        """Returns (full_name, abbreviation)."""
        return self.random_element(self._BANKS)

    def tn_iban(self) -> str:
        """Tunisian IBAN format: TN59 + 20 digits."""
        digits = "".join([str(random.randint(0, 9)) for _ in range(20)])
        return f"TN59 {digits[:4]} {digits[4:8]} {digits[8:12]} {digits[12:16]} {digits[16:]}"

    def tn_account_type(self) -> str:
        return self.random_element(self._ACCOUNT_TYPES)

    def tn_operator(self) -> str:
        return self.random_element(self._OPERATORS)

    def tn_telecom_plan(self) -> dict:
        return self.random_element(self._TELECOM_PLANS)

    def tn_product(self) -> dict:
        return self.random_element(self._PRODUCT_CATALOG)

    def tn_order_status(self) -> str:
        return self.random_element(self._ORDER_STATUSES)

    def tn_payment_method(self) -> str:
        return self.random_element(self._PAYMENT_METHODS)
