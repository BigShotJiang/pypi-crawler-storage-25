"""
Runtime configuration for all synthetic data generators.

Kept as a plain dataclass (no Pydantic) to avoid heavy dependencies.
Validation is explicit and fails loudly — no silent coercion.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path


class OutputFormat(str, Enum):
    CSV = "csv"
    PARQUET = "parquet"


@dataclass(frozen=True)
class GeneratorConfig:
    """
    Immutable config passed to every generator and the exporter.

    Attributes:
        seed:           RNG seed — ensures reproducible datasets.
        output_dir:     Directory where generated files land.
        output_format:  CSV (human-readable) or Parquet (analytics-ready).
        locale:         Faker locale used for base providers (names, emails…).
    """

    seed: int = 42
    output_dir: Path = field(default_factory=lambda: Path("output"))
    output_format: OutputFormat = OutputFormat.CSV
    locale: str = "fr_FR"  # French — closest to TN for base Faker data

    def __post_init__(self) -> None:
        if self.seed < 0:
            raise ValueError(f"seed must be non-negative, got {self.seed}")
        # Coerce str → Path without breaking frozen semantics
        object.__setattr__(self, "output_dir", Path(self.output_dir))
        if not isinstance(self.output_format, OutputFormat):
            object.__setattr__(self, "output_format", OutputFormat(self.output_format))
