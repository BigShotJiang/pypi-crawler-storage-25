"""
Abstract base for all domain generators.

Design:
  - Forces a consistent generate(n) interface across every domain.
  - Owns the Faker instance so seed management is centralised.
  - Intentionally thin — no business logic lives here.
"""

from __future__ import annotations

from abc import ABC, abstractmethod

import pandas as pd
from faker import Faker

from synth_data_tn.config import GeneratorConfig
from synth_data_tn.providers import TunisianProvider


class BaseGenerator(ABC):
    """
    All domain generators inherit from this class.

    The Faker instance is shared across the generator and carries the
    TunisianProvider so every subclass can call `self.fake.tn_*()` helpers.
    """

    def __init__(self, config: GeneratorConfig) -> None:
        self.config = config
        self.fake = Faker(config.locale)
        self.fake.add_provider(TunisianProvider)
        Faker.seed(config.seed)  # global seed → reproducible runs

    @abstractmethod
    def generate(self, n: int) -> pd.DataFrame:
        """
        Generate `n` synthetic records and return them as a DataFrame.

        Args:
            n: Number of rows to produce. Must be > 0.

        Returns:
            pd.DataFrame with domain-specific columns.
        """
        ...

    # ------------------------------------------------------------------ #
    # Shared helpers                                                       #
    # ------------------------------------------------------------------ #

    def _validate_n(self, n: int) -> None:
        if n <= 0:
            raise ValueError(f"n must be a positive integer, got {n}")

    def tn_location(self) -> tuple[str, str]:
        """Returns (city, governorate) as a consistent matched pair."""
        gov = self.fake.tn_governorate()
        city = self.fake.tn_city(governorate=gov)
        return city, gov
