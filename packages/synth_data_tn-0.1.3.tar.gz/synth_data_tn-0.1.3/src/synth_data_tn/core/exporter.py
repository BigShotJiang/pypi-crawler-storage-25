"""
Exporter — decoupled I/O layer.

Why a dedicated exporter?
  - Keeps generators pure (no I/O side effects).
  - Format logic lives in one place → easy to add JSON, Delta, etc.
  - Callers get back the written Path for piping into other systems.
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from synth_data_tn.config import GeneratorConfig, OutputFormat


class DataExporter:
    """Writes DataFrames to disk in the format specified by GeneratorConfig."""

    def __init__(self, config: GeneratorConfig) -> None:
        self.config = config
        config.output_dir.mkdir(parents=True, exist_ok=True)

    def export(self, df: pd.DataFrame, name: str) -> Path:
        """
        Persist `df` under `config.output_dir / <name>.<ext>`.

        Args:
            df:   DataFrame produced by a domain generator.
            name: Logical dataset name, e.g. "ecommerce_orders".

        Returns:
            Resolved path of the written file.
        """
        if df.empty:
            raise ValueError(f"DataFrame '{name}' is empty — nothing to export.")

        path = self._resolve_path(name)

        match self.config.output_format:
            case OutputFormat.CSV:
                df.to_csv(
                    path, index=False, encoding="utf-8-sig"
                )  # utf-8-sig for Excel compat
            case OutputFormat.PARQUET:
                df.to_parquet(path, index=False, engine="pyarrow")

        return path.resolve()

    # ------------------------------------------------------------------ #
    # Private                                                              #
    # ------------------------------------------------------------------ #

    def _resolve_path(self, name: str) -> Path:
        ext = self.config.output_format.value
        return self.config.output_dir / f"{name}.{ext}"
