import re
from html import escape
from html.parser import HTMLParser
from .node import Tag, Safe, Fragment, VOID, RAW

SAFE_ATTR = re.compile('^[a-zA-Z_][\\w\\-:.]*$')
BAD_URL = re.compile('^(?:javascript:|vbscript:|data:(?!(?:text/html|text/plain|image/|application/json)))', re.I)
URL_ATTRS = frozenset('href src action formaction data poster codebase cite background'.split())

"""Render Tag trees to HTML strings, and parse HTML back to Tag trees."""

def render_attrs(d):
    parts = []
    for k, v in d.items():
        if not SAFE_ATTR.match(k): raise ValueError(f'Bad attr name: {k!r}')
        if k in URL_ATTRS and BAD_URL.match(str(v)): raise ValueError(f'Bad URL in {k}')
        if   v is True:              parts.append(f' {k}')
        elif v is not False and v is not None:
            v2 = str(v).replace('&', '&amp;').replace('<', '&lt;').replace('"', '&quot;')
            parts.append(f' {k}="{v2}"')
    return ''.join(parts)

def to_html(t):
    if hasattr(t, '__html__') and not isinstance(t, Tag): return t.__html__()
    if not isinstance(t, Tag): return escape(str(t).replace('\x00', ''))
    a = render_attrs(t.attrs) if t.attrs else ''
    if t.void:
        if t.children: raise ValueError(f'<{t.tag}> is void, no children')
        return f'<{t.tag}{a} />' if t.sc else f'<{t.tag}{a}>'
    if t.raw:
        inner = ''.join(str(c).replace('\x00', '') for c in t.children)
        return f'<{t.tag}{a}>{inner}</{t.tag}>'
    inner = ''.join(to_html(c) for c in t.children)
    if not t.tag: return inner
    if not inner and t.sc: return f'<{t.tag}{a} />'
    if t.tag == 'html': return f'<!DOCTYPE html>\n<{t.tag}{a}>{inner}</{t.tag}>'
    return f'<{t.tag}{a}>{inner}</{t.tag}>'

def pretty(t, indent=2, _depth=0):
    pad  = ' ' * (indent * _depth)
    pad1 = ' ' * (indent * (_depth + 1))
    if hasattr(t, '__html__') and not isinstance(t, Tag): return t.__html__()
    if not isinstance(t, Tag): return pad + escape(str(t).replace('\x00', ''))
    a = render_attrs(t.attrs) if t.attrs else ''
    if t.void: return f'{pad}<{t.tag}{a} />' if t.sc else f'{pad}<{t.tag}{a}>'
    if t.raw:
        inner = ''.join(str(c).replace('\x00', '') for c in t.children)
        if not inner: return f'{pad}<{t.tag}{a}></{t.tag}>'
        lines = inner.strip().splitlines()
        return f'{pad}<{t.tag}{a}>\n' + '\n'.join(pad1 + l for l in lines) + f'\n{pad}</{t.tag}>'
    if not t.tag: return '\n'.join(pretty(c, indent, _depth) for c in t.children)
    if not t.children:
        return f'{pad}<{t.tag}{a} />' if t.sc else f'{pad}<{t.tag}{a}></{t.tag}>'
    if len(t.children) == 1 and isinstance(t.children[0], str):
        return f'{pad}<{t.tag}{a}>{escape(t.children[0])}</{t.tag}>'
    pre = '<!DOCTYPE html>\n' if t.tag == 'html' else ''
    kids = '\n'.join(pretty(c, indent, _depth + 1) for c in t.children)
    return f'{pre}{pad}<{t.tag}{a}>\n{kids}\n{pad}</{t.tag}>'

def html_to_tag(s):
    stack, root = [[]], []
    class P(HTMLParser):
        def handle_starttag(self, tag, attrs):
            d = {k: (v if v is not None else True) for k, v in attrs}
            if tag in VOID: stack[-1].append(Tag(tag, (), d, void=True))
            else:
                stack.append([])
                root.append((tag, d))
        def handle_endtag(self, tag):
            if tag in VOID: return
            children = tuple(stack.pop())
            t, d = root.pop()
            stack[-1].append(Tag(t, children, d, raw=(t in RAW)))
        def handle_data(self, data):
            if data.strip(): stack[-1].append(data.strip())
    P().feed(s)
    res = stack[0]
    return res[0] if len(res) == 1 else Fragment(*res)
