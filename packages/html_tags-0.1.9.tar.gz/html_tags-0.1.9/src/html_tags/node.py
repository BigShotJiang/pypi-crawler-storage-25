import types
from collections import namedtuple

VOID = frozenset('area base br col embed hr img input link meta source track wbr'.split())
RAW = frozenset(['script', 'style'])
SVG_VOID = frozenset('stop set image use'.split()) | frozenset('feBlend feColorMatrix feComposite feConvolveMatrix feDisplacementMap feDistantLight feDropShadow feFlood feFuncA feFuncB feFuncG feFuncR feGaussianBlur feImage feMergeNode feMorphology feOffset fePointLight feSpotLight feTile feTurbulence'.split())
SVG_SC = frozenset('circle ellipse line path polygon polyline rect animate animateMotion animateTransform'.split())
SVG_NAMES = dict(clipPath='clipPath', foreignObject='foreignObject', linearGradient='linearGradient', radialGradient='radialGradient', textPath='textPath', animateMotion='animateMotion', animateTransform='animateTransform', **{k: k for k in 'feBlend feColorMatrix feComponentTransfer feComposite feConvolveMatrix feDiffuseLighting feDisplacementMap feDistantLight feDropShadow feFlood feFuncA feFuncB feFuncG feFuncR feGaussianBlur feImage feMerge feMergeNode feMorphology feOffset fePointLight feSpecularLighting feSpotLight feTile feTurbulence'.split()})
_ATTR_MAP = {'cls': 'class', '_class': 'class', '_for': 'for', '_from': 'from', '_in': 'in', '_is': 'is'}
SVG_NAMES_LOWER = {k.lower(): v for k, v in SVG_NAMES.items()}

"""Tag tree node: pure data, no rendering."""

class Tag(namedtuple('Tag', 'tag children attrs void raw sc', defaults=((), {}, False, False, False))):
    """An HTML element as pure data."""

    @staticmethod
    def _attrmap(k): return _ATTR_MAP.get(k, k.rstrip('_').replace('_', '-'))

    @staticmethod
    def _flatten(items):
        for o in items:
            if o is None or o is False: continue
            if isinstance(o, Tag): yield o
            elif isinstance(o, (list, tuple, map, filter, types.GeneratorType)):
                yield from Tag._flatten(o)
            else: yield o

    def __call__(self, *c, **kw):
        da = {}
        ch = []
        for o in c:
            if isinstance(o, dict): da.update(o)
            else: ch.append(o)
        return self._replace(
            children=self.children + tuple(Tag._flatten(ch)),
            attrs={**self.attrs, **{Tag._attrmap(k): v for k, v in kw.items()}, **da})

class Safe(str):
    """Pre-escaped HTML string."""
    def __html__(self): return self

def attrmap(k): return Tag._attrmap(k)

def flatten(items): return Tag._flatten(items)

def Fragment(*c, **kw):
    return Tag('', tuple(Tag._flatten(c)), {Tag._attrmap(k): v for k, v in kw.items()})

def mktag(name):
    "Create a Tag constructor for any element name."
    name = SVG_NAMES_LOWER.get(name.lower(), name)
    low = name.lower()
    v = low in VOID or low in SVG_VOID
    r = low in RAW
    s = low in SVG_SC
    def tag(*c, **kw):
        da, ch = {}, []
        for o in c:
            if isinstance(o, dict): da.update(o)
            else: ch.append(o)
        return Tag(name, tuple(Tag._flatten(ch)), {**{Tag._attrmap(k): v for k, v in kw.items()}, **da}, v, r, s)
    tag.__name__ = name
    return tag
