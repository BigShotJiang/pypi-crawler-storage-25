"""HTML/SVG generation for Python. Zero dependencies."""
__version__ = '0.1.9'
__author__ = 'Deufel'
from .node import Tag, Safe, attrmap, flatten, Fragment, mktag
from .emit import render_attrs, to_html, pretty, html_to_tag
__all__ = [
    "Fragment",
    "Safe",
    "Tag",
    "attrmap",
    "flatten",
    "html_to_tag",
    "mktag",
    "pretty",
    "render_attrs",
    "to_html",
]
def __getattr__(name):
        return mktag(name.rstrip('_').replace('_', '-'))
