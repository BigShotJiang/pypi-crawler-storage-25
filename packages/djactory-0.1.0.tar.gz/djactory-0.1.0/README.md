# Djactory

`Djactory` is an interactive Django project factory. It helps you choose an architecture, API style, authentication stack, feature modules, design patterns, and now an optional project environment bootstrap in one flow.

## What it does

- Guides you through project creation with a Rich-powered wizard instead of a long flags list
- Generates Django projects for clean architecture, modular monolith, layered Django, and microservices-ready layouts
- Supports DRF, GraphQL, hybrid REST + GraphQL, and SSR delivery modes
- Composes authentication, background jobs, Redis, Channels, logging, Docker, CI, and more
- Recommends sensible defaults based on the project name and description
- Can optionally create `.venv` or use `uv` and install the generated project dependencies immediately

## Install

```bash
pip install Djactory
```

The installed commands are:

```bash
djactory
```

Legacy alias:

```bash
djangoforge
```

## Quick start

Run the interactive wizard:

```bash
djactory
```

Or explicitly:

```bash
djactory new
```

Choose the architecture and features you want, then decide how Djactory should handle the environment:

- `Skip environment bootstrap`
- `python -m venv`
- `uv`

If you choose `python -m venv` or `uv`, Djactory can also install the generated project's dependencies automatically.

## Example flow

```text
Project name: Acme Booking
Description: Multi-tenant booking platform for hotels
Architecture: Modular Monolith
API: Django REST Framework
Authentication: JWT
Frontend: Next.js ready
Features: Redis, Celery, Docker, CI/CD
Patterns: Service Layer, Repository, Unit of Work
Environment: python -m venv
Install dependencies now: yes
```

That produces a Django project with a `.venv`, project dependencies installed, and a scaffold shaped for a SaaS-style booking backend.

## Example generated tree

```text
acme-booking/
├── .env.example
├── Dockerfile
├── README.md
├── manage.py
├── pyproject.toml
└── src/
    └── acme_booking/
        ├── api/
        ├── apps/
        │   ├── core/
        │   └── users/
        ├── config/
        │   └── settings/
        └── shared/
```

## Typical commands

Create a new project in the current directory:

```bash
djactory
```

Create a new project in a specific folder:

```bash
djactory new --output-dir ~/workspaces
```

Check the installed version:

```bash
djactory --version
```

## Generated project setup

If you skip bootstrap, the generated project still contains everything needed to start manually:

```bash
cd your-project
python3 -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
cp .env.example .env
python manage.py migrate
python manage.py runserver
```

If you choose `uv`, install it first from the official installer and let Djactory run the environment creation and dependency sync for you.

## Development

```bash
python3 -m pip install -e ".[dev]"
python3 -m unittest discover -s tests -v
```

## Packaging

Build distributions locally:

```bash
python3 -m pip install -e ".[publish]"
python3 -m build
python3 -m twine check dist/*
```

Publishing notes are in [PUBLISHING.md](PUBLISHING.md).
