from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from djangoforge.cli.wizard import Wizard
from djangoforge.core.bootstrap import BootstrapError, EnvironmentBootstrapper
from djangoforge.core.config_builder import ConfigBuilder
from djangoforge.core.feature_injector import FeatureInjector
from djangoforge.core.generator import ProjectGenerator
from djangoforge.core.recommender import RecommendationEngine
from djangoforge.core.registry import RegistryStore
from djangoforge.core.templates_engine import TemplateEngine
from djangoforge.utils.logger import ForgeLogger


@dataclass(slots=True)
class CreateCommand:
    logger: ForgeLogger

    def run(self, output_dir: Path) -> int:
        registry = RegistryStore.load()
        recommender = RecommendationEngine(registry)
        wizard = Wizard(self.logger, registry, recommender)
        selections = wizard.run(output_dir)

        builder = ConfigBuilder(
            registry=registry,
            recommender=recommender,
            feature_injector=FeatureInjector(registry),
        )
        config = builder.build(selections)
        if not wizard.confirm(config):
            self.logger.warning("Generation cancelled.")
            return 1

        templates_root = Path(__file__).resolve().parents[2] / "templates"
        generator = ProjectGenerator(
            template_engine=TemplateEngine(templates_root),
            logger=self.logger,
        )
        result = generator.generate(config)
        self.logger.success(f"Project generated at {result.root_path}")
        bootstrapper = EnvironmentBootstrapper(self.logger)
        try:
            bootstrap_result = bootstrapper.run(config)
        except BootstrapError as exc:
            self.logger.error(str(exc))
            self.logger.warning(
                "Project files were generated, but environment bootstrap did not complete."
            )
            return 1

        if bootstrap_result.mode != "none":
            self.logger.success(
                f"Environment prepared with {wizard._bootstrap_label(bootstrap_result.mode)}."
            )
            activation = bootstrapper.activation_hint(bootstrap_result)
            if activation:
                self.logger.info(f"Activate it with: {activation}")
            if bootstrap_result.install_dependencies:
                self.logger.info("Dependencies were installed inside the generated project environment.")
        else:
            self.logger.info("Next step: cd into the project, install dependencies, and run migrations.")
        return 0
