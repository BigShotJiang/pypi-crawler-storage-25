"""CLI package for Djactory."""
