from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from rich.panel import Panel
from rich.prompt import Confirm, Prompt
from rich.table import Table

from djangoforge.core.models import CatalogOption, ProjectConfig, ProjectSelections, Recommendation
from djangoforge.core.recommender import RecommendationEngine
from djangoforge.core.registry import RegistryStore
from djangoforge.utils.logger import DJANGO_GREEN, ForgeLogger


@dataclass(slots=True)
class Wizard:
    logger: ForgeLogger
    registry: RegistryStore
    recommender: RecommendationEngine

    def run(self, output_dir: Path) -> ProjectSelections:
        self.logger.banner()

        project_name = self._ask_text(
            "Step 1",
            "Project identity",
            "Name your project and describe what it does.",
            "Project name",
        )
        description = self._ask_text(
            "Step 1",
            "Project identity",
            "Add a short one-line description so Djactory can tailor recommendations.",
            "Project description",
        )

        recommendation = self.recommender.recommend_from_text(project_name, description)
        self._show_recommendation(recommendation)

        architecture = self._choose_one(
            "Step 2",
            "Architecture selection",
            list(self.registry.architectures.values()),
            recommendation.architecture,
        )
        api_style = self._choose_one(
            "Step 3",
            "API style",
            list(self.registry.api_styles.values()),
            recommendation.api_style,
        )
        auth_style = self._choose_one(
            "Step 4",
            "Authentication system",
            list(self.registry.auth_styles.values()),
            recommendation.auth_style,
        )
        frontend_mode = self._choose_one(
            "Step 5",
            "Frontend integration",
            list(self.registry.frontend_modes.values()),
            recommendation.frontend_mode,
        )
        features = self._choose_many(
            "Step 6",
            "Feature modules",
            list(self.registry.features.values()),
            recommendation.features,
        )
        patterns = self._choose_many(
            "Step 7",
            "Design patterns",
            list(self.registry.patterns.values()),
            recommendation.patterns,
        )
        bootstrap_mode = self._choose_one(
            "Step 8",
            "Environment setup",
            self._environment_options(),
            "venv",
        )
        install_dependencies = False
        if bootstrap_mode != "none":
            self.logger.console.print(
                Panel(
                    "Djactory can create the project environment immediately and install the generated dependencies for you.",
                    title=f"[bold {DJANGO_GREEN}]Step 8[/bold {DJANGO_GREEN}] Environment setup",
                    border_style=DJANGO_GREEN,
                )
            )
            install_dependencies = Confirm.ask(
                "[bold #44B78B]Create the environment and install project dependencies now?[/bold #44B78B]",
                default=True,
            )

        return ProjectSelections(
            project_name=project_name,
            description=description,
            architecture=architecture,
            api_style=api_style,
            auth_style=auth_style,
            frontend_mode=frontend_mode,
            features=features,
            patterns=patterns,
            output_dir=output_dir,
            bootstrap_mode=bootstrap_mode,
            install_dependencies=install_dependencies,
        )

    def confirm(self, config: ProjectConfig) -> bool:
        summary = Table.grid(padding=(0, 1))
        summary.add_column(style="bold")
        summary.add_column()
        summary.add_row("Project", config.selections.project_name)
        summary.add_row("Description", config.selections.description)
        summary.add_row("Architecture", config.architecture.label)
        summary.add_row("API", config.api_style.label)
        summary.add_row("Authentication", config.auth_style.label)
        summary.add_row("Frontend", config.frontend_mode.label)
        summary.add_row(
            "Features",
            ", ".join(feature.label for feature in config.features) or "None",
        )
        summary.add_row(
            "Patterns",
            ", ".join(pattern.label for pattern in config.patterns) or "None",
        )
        summary.add_row("Environment", self._bootstrap_label(config.selections.bootstrap_mode))
        summary.add_row(
            "Auto install",
            "Yes" if config.selections.install_dependencies else "No",
        )
        summary.add_row("Target", str(config.output_path))
        self.logger.console.print(
            Panel(
                summary,
                title=f"[bold {DJANGO_GREEN}]Step 9[/bold {DJANGO_GREEN}] Final confirmation",
                border_style=DJANGO_GREEN,
            )
        )
        if config.warnings:
            self.logger.console.print(
                Panel(
                    "\n".join(f"- {item}" for item in config.warnings),
                    title="[yellow]Warnings[/yellow]",
                    border_style="yellow",
                )
            )
        if config.notes:
            self.logger.console.print(
                Panel(
                    "\n".join(f"- {item}" for item in config.notes),
                    title="[cyan]Notes[/cyan]",
                    border_style="cyan",
                )
            )
        return Confirm.ask("[bold #44B78B]Generate project now?[/bold #44B78B]", default=True)

    def _show_recommendation(self, recommendation: Recommendation) -> None:
        body = (
            f"[bold]Detected profile:[/bold] {recommendation.profile_label}\n"
            f"[bold]Rationale:[/bold] {recommendation.rationale}\n"
            f"[bold]Suggested stack:[/bold] "
            f"{self.registry.architectures[recommendation.architecture].label}, "
            f"{self.registry.api_styles[recommendation.api_style].label}, "
            f"{self.registry.auth_styles[recommendation.auth_style].label}, "
            f"{self.registry.frontend_modes[recommendation.frontend_mode].label}\n"
            f"[bold]Suggested features:[/bold] "
            f"{', '.join(self.registry.features[item].label for item in recommendation.features) or 'None'}\n"
            f"[bold]Suggested patterns:[/bold] "
            f"{', '.join(self.registry.patterns[item].label for item in recommendation.patterns) or 'None'}"
        )
        self.logger.console.print(
            Panel(
                body,
                title="[bold #44B78B]Djactory Recommendation Engine[/bold #44B78B]",
                border_style=DJANGO_GREEN,
            )
        )

    def _ask_text(self, step: str, title: str, body: str, label: str) -> str:
        self.logger.console.print(
            Panel(
                body,
                title=f"[bold {DJANGO_GREEN}]{step}[/bold {DJANGO_GREEN}] {title}",
                border_style=DJANGO_GREEN,
            )
        )
        while True:
            value = Prompt.ask(f"[bold]{label}[/bold]").strip()
            if value:
                return value
            self.logger.warning(f"{label} cannot be empty.")

    def _choose_one(
        self,
        step: str,
        title: str,
        options: list[CatalogOption],
        default_id: str,
    ) -> str:
        self._render_option_table(step, title, options, set(), default_id)
        valid_ids = {item.id for item in options}
        mapping = {str(index): option.id for index, option in enumerate(options, start=1)}
        default_index = next(
            (index for index, item in enumerate(options, start=1) if item.id == default_id),
            1,
        )
        while True:
            raw = Prompt.ask("Choose an option", default=str(default_index)).strip()
            choice = mapping.get(raw, raw)
            if choice in valid_ids:
                return choice
            self.logger.warning("Enter a valid option number.")

    def _choose_many(
        self,
        step: str,
        title: str,
        options: list[CatalogOption],
        default_ids: list[str],
    ) -> list[str]:
        selected = set(default_ids)
        mapping = {str(index): option.id for index, option in enumerate(options, start=1)}
        valid_ids = {item.id for item in options}

        while True:
            self._render_option_table(step, title, options, selected, None)
            raw = self.logger.console.input(
                "[bold]Toggle by number, comma-separated. Press Enter when done[/bold] "
            ).strip()
            if not raw:
                return [option.id for option in options if option.id in selected]

            tokens = [token.strip() for token in raw.split(",") if token.strip()]
            invalid = [token for token in tokens if token not in mapping and token not in valid_ids]
            if invalid:
                self.logger.warning(f"Unknown choices: {', '.join(invalid)}")
                continue
            for token in tokens:
                option_id = mapping.get(token, token)
                if option_id not in valid_ids:
                    continue
                if option_id in selected:
                    selected.remove(option_id)
                else:
                    selected.add(option_id)

    def _render_option_table(
        self,
        step: str,
        title: str,
        options: list[CatalogOption],
        selected: set[str],
        default_id: str | None,
    ) -> None:
        table = Table(show_header=True, header_style=f"bold {DJANGO_GREEN}")
        table.add_column("#", style="bold")
        table.add_column("Option")
        table.add_column("Description")
        table.add_column("State")
        for index, option in enumerate(options, start=1):
            badges = []
            if option.id in selected:
                badges.append("[green][x] selected[/green]")
            else:
                badges.append("[dim][ ][/dim]")
            if option.id == default_id:
                badges.append("[cyan]recommended[/cyan]")
            if option.recommended_badges:
                badges.append("[dim]" + ", ".join(option.recommended_badges) + "[/dim]")
            table.add_row(str(index), option.label, option.description, " ".join(badges))
        self.logger.console.print(
            Panel(
                table,
                title=f"[bold {DJANGO_GREEN}]{step}[/bold {DJANGO_GREEN}] {title}",
                border_style=DJANGO_GREEN,
            )
        )

    def _environment_options(self) -> list[CatalogOption]:
        return [
            CatalogOption(
                id="none",
                label="Skip environment bootstrap",
                description="Only generate the project files and leave environment setup to me.",
            ),
            CatalogOption(
                id="venv",
                label="python -m venv",
                description="Create a local .venv and optionally install the generated dependencies with pip.",
                recommended_badges=["recommended"],
            ),
            CatalogOption(
                id="uv",
                label="uv",
                description="Use uv to create .venv and install dependencies quickly if uv is already installed.",
                recommended_badges=["fast"],
            ),
        ]

    def _bootstrap_label(self, mode: str) -> str:
        labels = {item.id: item.label for item in self._environment_options()}
        return labels.get(mode, mode)
