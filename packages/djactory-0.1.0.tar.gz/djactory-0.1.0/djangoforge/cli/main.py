from __future__ import annotations

import argparse
from pathlib import Path

from djangoforge import __version__
from djangoforge.cli.commands.create import CreateCommand
from djangoforge.utils.logger import ForgeLogger


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="djactory",
        description="Interactive Django project generator with architecture, feature composition, and optional environment bootstrap.",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    subparsers = parser.add_subparsers(dest="command")

    new_parser = subparsers.add_parser("new", help="Launch the interactive project wizard.")
    new_parser.add_argument(
        "--output-dir",
        default=".",
        help="Directory where the generated project folder will be created.",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    command = args.command or "new"
    logger = ForgeLogger.build()

    if command == "new":
        create = CreateCommand(logger)
        return create.run(Path(getattr(args, "output_dir", ".")))

    parser.print_help()
    return 0
