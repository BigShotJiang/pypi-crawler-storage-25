from __future__ import annotations

import re
from pathlib import Path


def slugify_name(value: str) -> str:
    normalized = re.sub(r"[^a-zA-Z0-9]+", "-", value.strip().lower())
    normalized = normalized.strip("-")
    return normalized or "django-project"


def python_package_name(value: str) -> str:
    slug = slugify_name(value).replace("-", "_")
    if slug[0].isdigit():
        slug = f"project_{slug}"
    return slug


def ensure_directory(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def is_directory_empty(path: Path) -> bool:
    return not path.exists() or not any(path.iterdir())


def write_text_file(path: Path, content: str) -> None:
    ensure_directory(path.parent)
    path.write_text(content, encoding="utf-8")


def make_executable(path: Path) -> None:
    current_mode = path.stat().st_mode
    path.chmod(current_mode | 0o111)

