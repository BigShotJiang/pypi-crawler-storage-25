from __future__ import annotations

from dataclasses import dataclass

from rich.console import Console
from rich.panel import Panel
from rich.text import Text


DJANGO_GREEN = "#44B78B"
DJANGO_DARK = "#092E20"


@dataclass(slots=True)
class ForgeLogger:
    console: Console

    @classmethod
    def build(cls) -> "ForgeLogger":
        return cls(console=Console())

    def banner(self) -> None:
        header = Text(
            "\n"
            "  _____  _            _                    \n"
            " |  __ \\(_)          | |                   \n"
            " | |  | |_  __ _  ___| |_ ___  _ __ _   _  \n"
            " | |  | | |/ _` |/ __| __/ _ \\| '__| | | | \n"
            " | |__| | | (_| | (__| || (_) | |  | |_| | \n"
            " |_____/|_|\\__,_|\\___|\\__\\___/|_|   \\__, | \n"
            "                                     __/ | \n"
            "                                    |___/  \n",
            style=f"bold {DJANGO_GREEN}",
        )
        self.console.print(
            Panel(
                header,
                title="[bold #44B78B]Djactory[/bold #44B78B]",
                subtitle="[cyan]Intelligent Django project factory[/cyan]",
                border_style=DJANGO_GREEN,
                style=f"on {DJANGO_DARK}",
                padding=(0, 2),
            )
        )

    def section(self, title: str, body: str) -> None:
        self.console.print(
            Panel(
                body,
                title=f"[bold {DJANGO_GREEN}]{title}[/bold {DJANGO_GREEN}]",
                border_style=DJANGO_GREEN,
            )
        )

    def info(self, message: str) -> None:
        self.console.print(f"[cyan]info[/cyan] {message}")

    def success(self, message: str) -> None:
        self.console.print(f"[green]success[/green] {message}")

    def warning(self, message: str) -> None:
        self.console.print(f"[yellow]warning[/yellow] {message}")

    def error(self, message: str) -> None:
        self.console.print(f"[red]error[/red] {message}")
