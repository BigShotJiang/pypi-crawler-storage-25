from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from rich.progress import BarColumn, Progress, SpinnerColumn, TaskProgressColumn, TextColumn

from djangoforge.core.models import ProjectConfig
from djangoforge.core.templates_engine import TemplateEngine
from djangoforge.utils.filesystem import ensure_directory, is_directory_empty, make_executable
from djangoforge.utils.logger import ForgeLogger


@dataclass(slots=True)
class GenerationResult:
    root_path: Path
    rendered_files: list[Path]


@dataclass(slots=True)
class ProjectGenerator:
    template_engine: TemplateEngine
    logger: ForgeLogger

    def generate(self, config: ProjectConfig) -> GenerationResult:
        destination = config.output_path
        if destination.exists() and not is_directory_empty(destination):
            raise FileExistsError(f"Target directory already exists and is not empty: {destination}")

        ensure_directory(destination)
        context = config.to_template_context()
        rendered_files: list[Path] = []
        total_files = sum(self.template_engine.count_templates(item) for item in config.template_dirs)
        total_files = max(total_files, 1)

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            console=self.logger.console,
        ) as progress:
            task_id = progress.add_task("Generating project", total=total_files)
            for template_dir in config.template_dirs:
                planned = self.template_engine.count_templates(template_dir)
                progress.update(task_id, description=f"Rendering {template_dir}")
                files = self.template_engine.render_tree(template_dir, destination, context)
                rendered_files.extend(files)
                progress.advance(task_id, planned)

        manage_py = destination / "manage.py"
        if manage_py.exists():
            make_executable(manage_py)

        return GenerationResult(root_path=destination, rendered_files=rendered_files)
