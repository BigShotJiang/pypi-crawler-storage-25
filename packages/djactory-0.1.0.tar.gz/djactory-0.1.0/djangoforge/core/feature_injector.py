from __future__ import annotations

from dataclasses import dataclass

from djangoforge.core.models import FeatureDefinition, InjectionResult
from djangoforge.core.registry import RegistryStore


def _dedupe(values: list[str]) -> list[str]:
    return list(dict.fromkeys(values))


@dataclass(slots=True)
class FeatureInjector:
    registry: RegistryStore

    def resolve(self, selected_feature_ids: list[str]) -> InjectionResult:
        resolved_ids: list[str] = []
        auto_enabled: list[str] = []
        warnings: list[str] = []

        def visit(feature_id: str, explicit: bool) -> None:
            if feature_id in resolved_ids:
                return
            feature = self.registry.features[feature_id]
            for required_id in feature.requires:
                if required_id not in selected_feature_ids:
                    auto_enabled.append(required_id)
                    warnings.append(
                        f"{feature.label} requires {self.registry.features[required_id].label}; it was added automatically."
                    )
                visit(required_id, explicit=False)
            resolved_ids.append(feature_id)

        for feature_id in selected_feature_ids:
            visit(feature_id, explicit=True)

        definitions: list[FeatureDefinition] = [self.registry.features[item] for item in resolved_ids]
        dependencies = _dedupe(
            [dependency for item in definitions for dependency in item.dependencies]
        )
        dev_dependencies = _dedupe(
            [dependency for item in definitions for dependency in item.dev_dependencies]
        )
        installed_apps = _dedupe(
            [app for item in definitions for app in item.installed_apps]
        )
        middleware = _dedupe(
            [entry for item in definitions for entry in item.middleware]
        )
        env_vars: dict[str, str] = {}
        for item in definitions:
            env_vars.update(item.env_vars)
        template_dirs = [
            item.template_dir for item in definitions if item.template_dir is not None
        ]

        return InjectionResult(
            features=definitions,
            dependencies=dependencies,
            dev_dependencies=dev_dependencies,
            installed_apps=installed_apps,
            middleware=middleware,
            env_vars=env_vars,
            template_dirs=template_dirs,
            warnings=_dedupe(warnings),
            auto_enabled_features=_dedupe(auto_enabled),
        )

