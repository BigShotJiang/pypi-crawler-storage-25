from __future__ import annotations

import os
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path

from djangoforge.core.models import ProjectConfig
from djangoforge.utils.logger import ForgeLogger


@dataclass(slots=True)
class BootstrapCommand:
    description: str
    argv: list[str]


@dataclass(slots=True)
class BootstrapPlan:
    mode: str
    env_path: Path | None
    install_dependencies: bool
    commands: list[BootstrapCommand]


@dataclass(slots=True)
class BootstrapResult:
    mode: str
    env_path: Path | None
    install_dependencies: bool
    commands_run: list[str]


class BootstrapError(RuntimeError):
    """Raised when environment bootstrap fails after project generation."""


@dataclass(slots=True)
class EnvironmentBootstrapper:
    logger: ForgeLogger
    python_executable: str = field(default_factory=lambda: sys.executable)

    def build_plan(self, config: ProjectConfig) -> BootstrapPlan:
        mode = config.selections.bootstrap_mode
        install_dependencies = config.selections.install_dependencies
        if mode == "none":
            return BootstrapPlan(
                mode=mode,
                env_path=None,
                install_dependencies=False,
                commands=[],
            )

        env_path = config.output_path / ".venv"
        commands: list[BootstrapCommand] = []

        if mode == "venv":
            commands.append(
                BootstrapCommand(
                    description="Creating .venv with python -m venv",
                    argv=[self.python_executable, "-m", "venv", str(env_path)],
                )
            )
            if install_dependencies:
                env_python = self._env_python(env_path)
                commands.extend(
                    [
                        BootstrapCommand(
                            description="Upgrading pip inside .venv",
                            argv=[str(env_python), "-m", "pip", "install", "--upgrade", "pip"],
                        ),
                        BootstrapCommand(
                            description="Installing generated project dependencies",
                            argv=[str(env_python), "-m", "pip", "install", "-e", ".[dev]"],
                        ),
                    ]
                )
        elif mode == "uv":
            commands.append(
                BootstrapCommand(
                    description="Creating .venv with uv",
                    argv=["uv", "venv", str(env_path)],
                )
            )
            if install_dependencies:
                commands.append(
                    BootstrapCommand(
                        description="Installing generated project dependencies with uv",
                        argv=["uv", "sync", "--extra", "dev"],
                    )
                )
        else:
            raise BootstrapError(f"Unsupported bootstrap mode: {mode}")

        return BootstrapPlan(
            mode=mode,
            env_path=env_path,
            install_dependencies=install_dependencies,
            commands=commands,
        )

    def run(self, config: ProjectConfig) -> BootstrapResult:
        plan = self.build_plan(config)
        if not plan.commands:
            return BootstrapResult(
                mode=plan.mode,
                env_path=plan.env_path,
                install_dependencies=plan.install_dependencies,
                commands_run=[],
            )

        executed: list[str] = []
        for command in plan.commands:
            with self.logger.console.status(f"[cyan]{command.description}[/cyan]"):
                try:
                    completed = subprocess.run(
                        command.argv,
                        cwd=config.output_path,
                        check=True,
                        capture_output=True,
                        text=True,
                    )
                except FileNotFoundError as exc:
                    missing = command.argv[0]
                    raise BootstrapError(
                        f"Bootstrap tool not found: {missing}. Install it first or choose another environment option."
                    ) from exc
                except subprocess.CalledProcessError as exc:
                    stderr = (exc.stderr or "").strip()
                    stdout = (exc.stdout or "").strip()
                    details = stderr or stdout or str(exc)
                    raise BootstrapError(f"{command.description} failed: {details}") from exc
            if completed.stdout.strip():
                self.logger.info(completed.stdout.strip())
            executed.append(" ".join(command.argv))

        return BootstrapResult(
            mode=plan.mode,
            env_path=plan.env_path,
            install_dependencies=plan.install_dependencies,
            commands_run=executed,
        )

    def activation_hint(self, result: BootstrapResult) -> str | None:
        if result.env_path is None:
            return None
        if os.name == "nt":
            return f"{result.env_path.name}\\Scripts\\activate"
        return f"source {result.env_path.name}/bin/activate"

    def _env_python(self, env_path: Path) -> Path:
        if os.name == "nt":
            return env_path / "Scripts" / "python.exe"
        return env_path / "bin" / "python"
