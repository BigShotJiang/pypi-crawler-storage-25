from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass(slots=True)
class CatalogOption:
    id: str
    label: str
    description: str
    template_dir: str | None = None
    dependencies: list[str] = field(default_factory=list)
    dev_dependencies: list[str] = field(default_factory=list)
    installed_apps: list[str] = field(default_factory=list)
    middleware: list[str] = field(default_factory=list)
    env_vars: dict[str, str] = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)
    recommended_badges: list[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "CatalogOption":
        return cls(
            id=raw["id"],
            label=raw["label"],
            description=raw["description"],
            template_dir=raw.get("template_dir"),
            dependencies=list(raw.get("dependencies", [])),
            dev_dependencies=list(raw.get("dev_dependencies", [])),
            installed_apps=list(raw.get("installed_apps", [])),
            middleware=list(raw.get("middleware", [])),
            env_vars=dict(raw.get("env_vars", {})),
            notes=list(raw.get("notes", [])),
            recommended_badges=list(raw.get("recommended_badges", [])),
        )


@dataclass(slots=True)
class ArchitectureDefinition(CatalogOption):
    preview: list[str] = field(default_factory=list)
    app_module_path: str = "apps"
    supports_multi_tenancy: bool = True

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "ArchitectureDefinition":
        return cls(
            id=raw["id"],
            label=raw["label"],
            description=raw["description"],
            template_dir=raw.get("template_dir"),
            preview=list(raw.get("preview", [])),
            app_module_path=raw.get("app_module_path", "apps"),
            supports_multi_tenancy=raw.get("supports_multi_tenancy", True),
            notes=list(raw.get("notes", [])),
            recommended_badges=list(raw.get("recommended_badges", [])),
        )


@dataclass(slots=True)
class FeatureDefinition(CatalogOption):
    requires: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "FeatureDefinition":
        base = CatalogOption.from_dict(raw)
        return cls(
            id=base.id,
            label=base.label,
            description=base.description,
            template_dir=base.template_dir,
            dependencies=base.dependencies,
            dev_dependencies=base.dev_dependencies,
            installed_apps=base.installed_apps,
            middleware=base.middleware,
            env_vars=base.env_vars,
            notes=base.notes,
            recommended_badges=base.recommended_badges,
            requires=list(raw.get("requires", [])),
            tags=list(raw.get("tags", [])),
        )


@dataclass(slots=True)
class ProjectSelections:
    project_name: str
    description: str
    architecture: str
    api_style: str
    auth_style: str
    frontend_mode: str
    features: list[str]
    patterns: list[str]
    output_dir: Path
    bootstrap_mode: str = "none"
    install_dependencies: bool = False


@dataclass(slots=True)
class Recommendation:
    profile_id: str
    profile_label: str
    rationale: str
    architecture: str
    api_style: str
    auth_style: str
    frontend_mode: str
    features: list[str]
    patterns: list[str]
    warnings: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    confidence: int = 0


@dataclass(slots=True)
class InjectionResult:
    features: list[FeatureDefinition]
    dependencies: list[str]
    dev_dependencies: list[str]
    installed_apps: list[str]
    middleware: list[str]
    env_vars: dict[str, str]
    template_dirs: list[str]
    warnings: list[str]
    auto_enabled_features: list[str]


@dataclass(slots=True)
class ProjectConfig:
    selections: ProjectSelections
    project_slug: str
    package_name: str
    output_path: Path
    architecture: ArchitectureDefinition
    api_style: CatalogOption
    auth_style: CatalogOption
    frontend_mode: CatalogOption
    features: list[FeatureDefinition]
    patterns: list[CatalogOption]
    recommendation: Recommendation
    template_dirs: list[str]
    dependencies: list[str]
    dev_dependencies: list[str]
    installed_apps: list[str]
    middleware: list[str]
    env_vars: dict[str, str]
    warnings: list[str]
    notes: list[str]
    feature_flags: dict[str, bool]
    pattern_flags: dict[str, bool]
    user_app_dir: str
    user_app_module: str
    core_app_dir: str
    core_app_module: str

    @property
    def feature_ids(self) -> list[str]:
        return [feature.id for feature in self.features]

    @property
    def pattern_ids(self) -> list[str]:
        return [pattern.id for pattern in self.patterns]

    def to_template_context(self) -> dict[str, Any]:
        supports_rest = self.api_style.id in {"drf", "hybrid"}
        supports_graphql = self.api_style.id in {"graphql", "hybrid"}
        supports_ssr = self.api_style.id == "ssr" or self.frontend_mode.id in {
            "legacy_admin",
            "htmx_ssr",
        }
        return {
            "project_name": self.selections.project_name,
            "project_slug": self.project_slug,
            "package_name": self.package_name,
            "description": self.selections.description,
            "bootstrap_mode": self.selections.bootstrap_mode,
            "install_dependencies": self.selections.install_dependencies,
            "architecture_id": self.architecture.id,
            "architecture_label": self.architecture.label,
            "api_style_id": self.api_style.id,
            "api_style_label": self.api_style.label,
            "auth_style_id": self.auth_style.id,
            "auth_style_label": self.auth_style.label,
            "frontend_mode_id": self.frontend_mode.id,
            "frontend_mode_label": self.frontend_mode.label,
            "feature_ids": self.feature_ids,
            "pattern_ids": self.pattern_ids,
            "feature_flags": self.feature_flags,
            "pattern_flags": self.pattern_flags,
            "features": [{"id": item.id, "label": item.label} for item in self.features],
            "patterns": [{"id": item.id, "label": item.label} for item in self.patterns],
            "dependencies": self.dependencies,
            "dev_dependencies": self.dev_dependencies,
            "installed_apps": self.installed_apps,
            "middleware": self.middleware,
            "env_vars": self.env_vars,
            "warnings": self.warnings,
            "notes": self.notes,
            "project_package_dir": f"src/{self.package_name}",
            "user_app_dir": self.user_app_dir,
            "user_app_module": self.user_app_module,
            "core_app_dir": self.core_app_dir,
            "core_app_module": self.core_app_module,
            "django_settings_module": f"{self.package_name}.config.settings.local",
            "supports_rest": supports_rest,
            "supports_graphql": supports_graphql,
            "supports_ssr": supports_ssr,
            "uses_jwt": self.auth_style.id in {"jwt", "hybrid"},
            "uses_session_auth": self.auth_style.id in {"session", "hybrid"},
            "uses_oauth": self.auth_style.id in {"oauth", "hybrid"},
            "uses_celery": self.feature_flags.get("celery", False),
            "uses_redis": self.feature_flags.get("redis", False),
            "uses_channels": self.feature_flags.get("channels", False),
            "uses_structlog": self.feature_flags.get("logging", False),
            "uses_audit_trail": self.feature_flags.get("audit_trail", False),
            "uses_multi_tenancy": self.feature_flags.get("multi_tenancy", False),
            "uses_rbac": self.feature_flags.get("rbac", False),
            "uses_storage": self.feature_flags.get("storage", False),
            "uses_docker": self.feature_flags.get("docker", False),
            "uses_ci_cd": self.feature_flags.get("ci_cd", False),
            "uses_repository_pattern": self.pattern_flags.get("repository", False),
            "uses_service_layer": self.pattern_flags.get("service_layer", False),
            "uses_factory_pattern": self.pattern_flags.get("factory", False),
            "uses_uow_pattern": self.pattern_flags.get("unit_of_work", False),
            "uses_cqrs": self.pattern_flags.get("cqrs", False),
        }
