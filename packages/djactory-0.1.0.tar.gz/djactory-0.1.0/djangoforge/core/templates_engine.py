from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from jinja2 import Environment, StrictUndefined

from djangoforge.utils.filesystem import write_text_file


@dataclass(slots=True)
class TemplateEngine:
    templates_root: Path
    environment: Environment = field(init=False, repr=False)

    def __post_init__(self) -> None:
        self.environment = Environment(
            autoescape=False,
            keep_trailing_newline=True,
            lstrip_blocks=True,
            trim_blocks=True,
            undefined=StrictUndefined,
        )

    def render_tree(
        self,
        template_dir: str,
        destination_root: Path,
        context: dict[str, Any],
    ) -> list[Path]:
        source_root = self.templates_root / template_dir
        if not source_root.exists():
            return []

        rendered_files: list[Path] = []
        for source_path in source_root.rglob("*"):
            if source_path.is_dir():
                continue
            relative_path = source_path.relative_to(source_root)
            output_path = self._resolve_output_path(relative_path, destination_root, context)
            template = self.environment.from_string(source_path.read_text(encoding="utf-8"))
            content = template.render(**context)
            if not content.strip():
                continue
            write_text_file(output_path, content)
            rendered_files.append(output_path)
        return rendered_files

    def count_templates(self, template_dir: str) -> int:
        source_root = self.templates_root / template_dir
        if not source_root.exists():
            return 0
        return sum(1 for path in source_root.rglob("*") if path.is_file())

    def _resolve_output_path(
        self,
        relative_path: Path,
        destination_root: Path,
        context: dict[str, Any],
    ) -> Path:
        resolved = relative_path.as_posix()
        for key, value in context.items():
            if isinstance(value, (str, Path)):
                resolved = resolved.replace(f"__{key}__", str(value))
        if resolved.endswith(".j2"):
            resolved = resolved[:-3]
        return destination_root / resolved
