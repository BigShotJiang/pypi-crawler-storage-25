from __future__ import annotations

from dataclasses import dataclass

from djangoforge.core.feature_injector import FeatureInjector
from djangoforge.core.models import ProjectConfig, ProjectSelections
from djangoforge.core.recommender import RecommendationEngine
from djangoforge.core.registry import RegistryStore
from djangoforge.utils.filesystem import python_package_name


def _dedupe(values: list[str]) -> list[str]:
    return list(dict.fromkeys(values))


@dataclass(slots=True)
class ConfigBuilder:
    registry: RegistryStore
    recommender: RecommendationEngine
    feature_injector: FeatureInjector

    def build(self, selections: ProjectSelections) -> ProjectConfig:
        architecture = self.registry.architectures[selections.architecture]
        api_style = self.registry.api_styles[selections.api_style]
        auth_style = self.registry.auth_styles[selections.auth_style]
        frontend_mode = self.registry.frontend_modes[selections.frontend_mode]
        patterns = [self.registry.patterns[item] for item in selections.patterns]

        package_name = python_package_name(selections.project_name)
        project_slug = package_name.replace("_", "-")
        output_path = selections.output_dir / project_slug

        recommendation = self.recommender.refine(selections)
        injections = self.feature_injector.resolve(selections.features)

        feature_flags = {feature.id: True for feature in injections.features}
        pattern_flags = {pattern.id: True for pattern in patterns}

        base_dependencies = [
            "Django>=5.1,<6.0",
            "python-dotenv>=1.0.1",
            "gunicorn>=22.0.0",
            "whitenoise>=6.9.0",
        ]
        base_dev_dependencies = [
            "pytest>=8.2.0",
            "pytest-django>=4.8.0",
            "ruff>=0.6.9",
            "mypy>=1.11.2",
        ]
        if "factory" in pattern_flags:
            base_dev_dependencies.append("factory-boy>=3.3.1")

        dependencies = _dedupe(
            base_dependencies
            + architecture.dependencies
            + api_style.dependencies
            + auth_style.dependencies
            + frontend_mode.dependencies
            + injections.dependencies
        )
        dev_dependencies = _dedupe(
            base_dev_dependencies
            + architecture.dev_dependencies
            + api_style.dev_dependencies
            + auth_style.dev_dependencies
            + frontend_mode.dev_dependencies
            + injections.dev_dependencies
        )

        app_root = architecture.app_module_path
        user_app_module = f"{package_name}.{app_root}.users"
        core_app_module = f"{package_name}.{app_root}.core"
        user_app_dir = f"src/{package_name}/{app_root.replace('.', '/')}/users"
        core_app_dir = f"src/{package_name}/{app_root.replace('.', '/')}/core"

        installed_apps = _dedupe(
            [
                "django.contrib.admin",
                "django.contrib.auth",
                "django.contrib.contenttypes",
                "django.contrib.sessions",
                "django.contrib.messages",
                "django.contrib.staticfiles",
                core_app_module,
                user_app_module,
            ]
            + api_style.installed_apps
            + auth_style.installed_apps
            + frontend_mode.installed_apps
            + injections.installed_apps
        )
        middleware = _dedupe(
            [
                "django.middleware.security.SecurityMiddleware",
                "whitenoise.middleware.WhiteNoiseMiddleware",
                "django.contrib.sessions.middleware.SessionMiddleware",
                "django.middleware.common.CommonMiddleware",
                "django.middleware.csrf.CsrfViewMiddleware",
                "django.contrib.auth.middleware.AuthenticationMiddleware",
                "django.contrib.messages.middleware.MessageMiddleware",
                "django.middleware.clickjacking.XFrameOptionsMiddleware",
            ]
            + frontend_mode.middleware
            + injections.middleware
        )

        env_vars = {
            "DJANGO_SECRET_KEY": "change-me",
            "DJANGO_DEBUG": "True",
            "DJANGO_ALLOWED_HOSTS": "127.0.0.1,localhost",
            "DATABASE_URL": "sqlite:///db.sqlite3",
        }
        env_vars.update(api_style.env_vars)
        env_vars.update(auth_style.env_vars)
        env_vars.update(frontend_mode.env_vars)
        env_vars.update(injections.env_vars)

        template_dirs = _dedupe(
            [
                "base",
                architecture.template_dir or "",
                api_style.template_dir or "",
                auth_style.template_dir or "",
                frontend_mode.template_dir or "",
            ]
            + injections.template_dirs
        )
        template_dirs = [item for item in template_dirs if item]

        warnings = _dedupe(recommendation.warnings + injections.warnings)
        notes = _dedupe(recommendation.notes + architecture.notes + api_style.notes + auth_style.notes)

        return ProjectConfig(
            selections=selections,
            project_slug=project_slug,
            package_name=package_name,
            output_path=output_path,
            architecture=architecture,
            api_style=api_style,
            auth_style=auth_style,
            frontend_mode=frontend_mode,
            features=injections.features,
            patterns=patterns,
            recommendation=recommendation,
            template_dirs=template_dirs,
            dependencies=dependencies,
            dev_dependencies=dev_dependencies,
            installed_apps=installed_apps,
            middleware=middleware,
            env_vars=env_vars,
            warnings=warnings,
            notes=notes,
            feature_flags=feature_flags,
            pattern_flags=pattern_flags,
            user_app_dir=user_app_dir,
            user_app_module=user_app_module,
            core_app_dir=core_app_dir,
            core_app_module=core_app_module,
        )
