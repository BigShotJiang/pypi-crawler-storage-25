from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from djangoforge.core.models import ArchitectureDefinition, CatalogOption, FeatureDefinition


@dataclass(slots=True)
class RegistryStore:
    root: Path
    architectures: dict[str, ArchitectureDefinition]
    features: dict[str, FeatureDefinition]
    api_styles: dict[str, CatalogOption]
    auth_styles: dict[str, CatalogOption]
    frontend_modes: dict[str, CatalogOption]
    patterns: dict[str, CatalogOption]
    profiles: list[dict[str, Any]]

    @classmethod
    def load(cls, root: Path | None = None) -> "RegistryStore":
        base_root = root or Path(__file__).resolve().parent.parent / "registry"

        def load_json(filename: str) -> Any:
            return json.loads((base_root / filename).read_text(encoding="utf-8"))

        architectures = {
            item["id"]: ArchitectureDefinition.from_dict(item)
            for item in load_json("architectures.json")
        }
        features = {
            item["id"]: FeatureDefinition.from_dict(item)
            for item in load_json("features.json")
        }
        options = load_json("options.json")

        return cls(
            root=base_root,
            architectures=architectures,
            features=features,
            api_styles={
                item["id"]: CatalogOption.from_dict(item) for item in options["api_styles"]
            },
            auth_styles={
                item["id"]: CatalogOption.from_dict(item) for item in options["auth_styles"]
            },
            frontend_modes={
                item["id"]: CatalogOption.from_dict(item)
                for item in options["frontend_modes"]
            },
            patterns={
                item["id"]: CatalogOption.from_dict(item) for item in options["patterns"]
            },
            profiles=load_json("profiles.json"),
        )

