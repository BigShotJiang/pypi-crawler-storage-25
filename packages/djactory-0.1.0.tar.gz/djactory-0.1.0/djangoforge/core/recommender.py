from __future__ import annotations

from dataclasses import dataclass

from djangoforge.core.models import ProjectSelections, Recommendation
from djangoforge.core.registry import RegistryStore


@dataclass(slots=True)
class RecommendationEngine:
    registry: RegistryStore

    def recommend_from_text(self, project_name: str, description: str) -> Recommendation:
        text = f"{project_name} {description}".lower()
        best_profile = None
        best_score = -1

        for profile in self.registry.profiles:
            score = sum(1 for keyword in profile["keywords"] if keyword in text)
            if score > best_score:
                best_score = score
                best_profile = profile

        if not best_profile or best_score <= 0:
            return self._default_recommendation()

        recommendations = best_profile["recommendations"]
        return Recommendation(
            profile_id=best_profile["id"],
            profile_label=best_profile["label"],
            rationale=best_profile["rationale"],
            architecture=recommendations["architecture"],
            api_style=recommendations["api_style"],
            auth_style=recommendations["auth_style"],
            frontend_mode=recommendations["frontend_mode"],
            features=list(recommendations.get("features", [])),
            patterns=list(recommendations.get("patterns", [])),
            warnings=list(best_profile.get("warnings", [])),
            notes=list(best_profile.get("notes", [])),
            confidence=best_score,
        )

    def refine(self, selections: ProjectSelections) -> Recommendation:
        recommendation = self.recommend_from_text(
            selections.project_name,
            selections.description,
        )
        chosen_features = set(selections.features)
        chosen_patterns = set(selections.patterns)

        warnings = list(recommendation.warnings)
        notes = list(recommendation.notes)

        if "channels" in chosen_features and "redis" not in chosen_features:
            warnings.append("Django Channels is strongest with Redis; Redis will be auto-enabled.")

        if selections.frontend_mode == "nextjs_ready" and selections.auth_style == "session":
            warnings.append(
                "Next.js frontends usually pair better with JWT or hybrid auth than session-only auth."
            )

        if selections.architecture == "microservices" and "docker" not in chosen_features:
            warnings.append(
                "Microservices-ready scaffolds benefit from Docker and CI/CD for local parity and delivery."
            )

        if selections.architecture == "layered" and "multi_tenancy" in chosen_features:
            warnings.append(
                "Multi-tenancy can put pressure on a layered codebase. Modular or clean architecture scales better."
            )

        if selections.api_style == "ssr" and selections.auth_style == "jwt":
            warnings.append(
                "Pure SSR apps usually prefer session auth. JWT-only auth is better suited to external clients."
            )

        missing_features = [
            feature_id
            for feature_id in recommendation.features
            if feature_id not in chosen_features
        ]
        if missing_features:
            notes.append(
                "Recommended but not selected: "
                + ", ".join(self.registry.features[item].label for item in missing_features)
            )

        missing_patterns = [
            pattern_id
            for pattern_id in recommendation.patterns
            if pattern_id not in chosen_patterns
        ]
        if missing_patterns:
            notes.append(
                "Suggested patterns not selected: "
                + ", ".join(self.registry.patterns[item].label for item in missing_patterns)
            )

        recommendation.warnings = warnings
        recommendation.notes = notes
        return recommendation

    def _default_recommendation(self) -> Recommendation:
        return Recommendation(
            profile_id="general",
            profile_label="General Django Product",
            rationale=(
                "A modular monolith with DRF, JWT, Redis, and a service layer is a solid default "
                "for most product-oriented Django systems."
            ),
            architecture="modular",
            api_style="drf",
            auth_style="jwt",
            frontend_mode="api_only",
            features=["redis", "logging", "docker", "ci_cd"],
            patterns=["service_layer", "repository"],
            notes=["Use this as a baseline and tighten the stack around your deployment model."],
            confidence=0,
        )

