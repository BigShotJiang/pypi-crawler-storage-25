from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from djangoforge.core.config_builder import ConfigBuilder
from djangoforge.core.feature_injector import FeatureInjector
from djangoforge.core.generator import ProjectGenerator
from djangoforge.core.models import ProjectSelections
from djangoforge.core.recommender import RecommendationEngine
from djangoforge.core.registry import RegistryStore
from djangoforge.core.templates_engine import TemplateEngine
from djangoforge.utils.logger import ForgeLogger


class GeneratorTests(unittest.TestCase):
    def test_generator_creates_project_files(self) -> None:
        registry = RegistryStore.load()
        recommender = RecommendationEngine(registry)
        builder = ConfigBuilder(registry, recommender, FeatureInjector(registry))
        output_dir = Path(tempfile.mkdtemp(prefix="forge-generator-", dir="/tmp"))

        selections = ProjectSelections(
            project_name="Internal Ops",
            description="Internal admin dashboard",
            architecture="layered",
            api_style="ssr",
            auth_style="session",
            frontend_mode="htmx_ssr",
            features=["logging", "docker"],
            patterns=["service_layer"],
            output_dir=output_dir,
        )
        config = builder.build(selections)

        generator = ProjectGenerator(
            template_engine=TemplateEngine(Path("djangoforge/templates").resolve()),
            logger=ForgeLogger.build(),
        )
        result = generator.generate(config)

        self.assertTrue((result.root_path / "manage.py").exists())
        self.assertTrue((result.root_path / "src" / "internal_ops" / "config" / "urls.py").exists())
        self.assertTrue((result.root_path / "Dockerfile").exists())


if __name__ == "__main__":
    unittest.main()

