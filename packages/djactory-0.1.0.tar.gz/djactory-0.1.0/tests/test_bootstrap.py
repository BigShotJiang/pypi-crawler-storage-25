from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from djangoforge.core.bootstrap import EnvironmentBootstrapper
from djangoforge.core.config_builder import ConfigBuilder
from djangoforge.core.feature_injector import FeatureInjector
from djangoforge.core.models import ProjectSelections
from djangoforge.core.recommender import RecommendationEngine
from djangoforge.core.registry import RegistryStore
from djangoforge.utils.logger import ForgeLogger


class BootstrapperTests(unittest.TestCase):
    def setUp(self) -> None:
        registry = RegistryStore.load()
        recommender = RecommendationEngine(registry)
        self.builder = ConfigBuilder(registry, recommender, FeatureInjector(registry))
        self.bootstrapper = EnvironmentBootstrapper(ForgeLogger.build(), python_executable="/usr/bin/python3")

    def test_none_mode_generates_empty_plan(self) -> None:
        config = self._build_config("none", False)

        plan = self.bootstrapper.build_plan(config)

        self.assertEqual(plan.mode, "none")
        self.assertEqual(plan.commands, [])
        self.assertIsNone(plan.env_path)

    def test_venv_mode_installs_with_generated_env_python(self) -> None:
        config = self._build_config("venv", True)

        plan = self.bootstrapper.build_plan(config)

        self.assertEqual(plan.mode, "venv")
        self.assertEqual(plan.env_path, config.output_path / ".venv")
        self.assertEqual(plan.commands[0].argv[:3], ["/usr/bin/python3", "-m", "venv"])
        self.assertIn("pip", " ".join(plan.commands[1].argv))
        self.assertEqual(plan.commands[2].argv[-2:], ["-e", ".[dev]"])

    def test_uv_mode_builds_uv_sync_plan(self) -> None:
        config = self._build_config("uv", True)

        plan = self.bootstrapper.build_plan(config)

        self.assertEqual(plan.commands[0].argv[0], "uv")
        self.assertEqual(plan.commands[1].argv, ["uv", "sync", "--extra", "dev"])

    def _build_config(self, mode: str, install_dependencies: bool):
        selections = ProjectSelections(
            project_name="Bootstrap Demo",
            description="Generated test project",
            architecture="modular",
            api_style="drf",
            auth_style="jwt",
            frontend_mode="api_only",
            features=["logging"],
            patterns=["service_layer"],
            output_dir=Path(tempfile.mkdtemp(prefix="forge-bootstrap-", dir="/tmp")),
            bootstrap_mode=mode,
            install_dependencies=install_dependencies,
        )
        return self.builder.build(selections)


if __name__ == "__main__":
    unittest.main()
