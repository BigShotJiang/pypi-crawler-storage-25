from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from djangoforge.core.config_builder import ConfigBuilder
from djangoforge.core.feature_injector import FeatureInjector
from djangoforge.core.models import ProjectSelections
from djangoforge.core.recommender import RecommendationEngine
from djangoforge.core.registry import RegistryStore


class ConfigBuilderTests(unittest.TestCase):
    def setUp(self) -> None:
        self.registry = RegistryStore.load()
        self.recommender = RecommendationEngine(self.registry)
        self.builder = ConfigBuilder(
            registry=self.registry,
            recommender=self.recommender,
            feature_injector=FeatureInjector(self.registry),
        )

    def test_celery_auto_enables_redis(self) -> None:
        selections = ProjectSelections(
            project_name="Acme Booking",
            description="Booking workflow system",
            architecture="modular",
            api_style="drf",
            auth_style="jwt",
            frontend_mode="api_only",
            features=["celery"],
            patterns=["service_layer"],
            output_dir=Path(tempfile.mkdtemp(prefix="forge-tests-", dir="/tmp")),
        )

        config = self.builder.build(selections)

        self.assertIn("celery", config.feature_ids)
        self.assertIn("redis", config.feature_ids)
        self.assertTrue(any("automatically" in warning for warning in config.warnings))

    def test_clean_architecture_uses_interface_app_module(self) -> None:
        selections = ProjectSelections(
            project_name="Developer Platform",
            description="API platform for developers",
            architecture="clean",
            api_style="hybrid",
            auth_style="hybrid",
            frontend_mode="api_only",
            features=["logging"],
            patterns=["service_layer", "repository"],
            output_dir=Path(tempfile.mkdtemp(prefix="forge-tests-", dir="/tmp")),
        )

        config = self.builder.build(selections)

        self.assertEqual(config.user_app_module, "developer_platform.interfaces.django.users")
        self.assertIn("src/developer_platform/interfaces/django/users", config.user_app_dir)


if __name__ == "__main__":
    unittest.main()

