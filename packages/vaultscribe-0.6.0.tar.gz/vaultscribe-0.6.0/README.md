# Vaultscribe

Vaultscribe is a tool for managing secrets. It's intended for solo devs and small teams. It uses Google Cloud Secret Manager to store secrets, and can sync secrets to multiple targets (GCloud Run, Cloudflare Pages, Github Actions, etc). It also generates code so you can access the secrets in your apps.

GCloud Secret Manager offers 6 secrets for free. Vaultscribe bundles up all your secrets, and stores them in a single 'secret slot' - meaning you can practically store as many [*](#gcloud-secret-manager-quotas) secrets as you like.

## Installation

```bash
uv add --dev vaultscribe
```
or
```bash
pip install vaultscribe
```

## Quickstart

### Prerequisites:

- Google Cloud SDK CLI installed, with Secret Manager set up (see [below](#gcloud-secrets-manager-first-time-setup)).

### Quick Usage

```bash
# Scaffold a new project. This will create a vaultscribe.toml file.
vs init     
# Start a time-limited authenticated session - best practice for not leaving an active gcloud session running
vs shell  
# Fetch secrets from GCloud Secret Manager for 'prod' environment, store in '.secrets.prod' file. Unset secrets are left blank.
vs pull prod  
# Push secrets from '.secrets.prod' to GCloud Secret Manager for 'prod' environment. Also generates code and syncs secrets to deploy targets.
vs push prod  
# Fetch secrets from GCloud Secret Manager and display
vs show prod  
```

## Vaultscribe Concepts

More details [here](docs/concepts.md).

## Vaultscribe Commands

More details [here](docs/commands.md).

## GCloud Secrets Manager first time setup

```bash
# Enable Secret Manager for your project
gcloud services enable secretmanager.googleapis.com --project=YOUR_PROJECT_ID
```

## GCloud Secret Manager Quotas

Each secret 'slot' in GCloud Secret Manager has a 64KiB size limit. See [here](https://cloud.google.com/secret-manager/quotas). So while, to paraphrase, "64KiB ought to be enough for anybody", you may hit this limit if you have a very large number of secrets, or if you store really big secrets. If you hit the limit, you probably need a more 'enterprise-y' secrets manager. 