import { VS_EXAMPLE_BACKEND_URL, vsLoadConfig } from "./vs_config";

async function main() {
  // You can access 'build' secrets directly. These are baked into your bundle.
  const backendUrlEl = document.getElementById("backend-url");
  if (backendUrlEl) {
    backendUrlEl.textContent = VS_EXAMPLE_BACKEND_URL ?? "(not set)";
  }

  // This is where you import the Vaultscribe runtime config. It queries the
  // Cloudflare Function at vs-config.ts.
  const config = await vsLoadConfig();

  // Now you can access 'runtime' secrets. These are *not* baked into your bundle
  // and can be changed without redeploying the frontend.
  const firebaseKeyEl = document.getElementById("firebase-api-key");
  if (firebaseKeyEl) {
    firebaseKeyEl.textContent = config.vsExampleFirebaseApiKey;
  }
}

main();
