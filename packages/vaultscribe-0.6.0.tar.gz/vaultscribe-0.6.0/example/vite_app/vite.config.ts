import { defineConfig } from "vite";
// This is where you import the Vaultscribe plugin.
import { vaultScribePlugin } from "./src/vs_vite_plugin";

export default defineConfig({
  plugins: [vaultScribePlugin()],
});
