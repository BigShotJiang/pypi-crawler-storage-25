from vs_secrets import VaultscribeSecretSettings


class Settings(VaultscribeSecretSettings):
    pass
