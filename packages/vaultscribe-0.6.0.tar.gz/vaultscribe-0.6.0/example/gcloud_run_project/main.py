from config import Settings
from fastapi import FastAPI

app = FastAPI()

_settings = Settings()  # ty: ignore[missing-argument]  # pydantic-settings fills fields from env vars

_MASK_MIN_LEN = 8


def _mask(value: str) -> str:
    if len(value) <= _MASK_MIN_LEN:
        return "***"
    return f"{value[:4]}...{value[-4:]}"


@app.get("/health")
def health() -> dict[str, str]:
    return {
        "status": "ok",
        # Secrets: masked so this endpoint is safe to expose
        "vs_example_database_url": _mask(_settings.vs_example_database_url),
        "vs_example_session_secret": _mask(_settings.vs_example_session_secret),
        # Public values: safe to expose in full
        "vs_example_backend_url": _settings.vs_example_backend_url,
        "vs_example_firebase_api_key": _settings.vs_example_firebase_api_key,
    }
