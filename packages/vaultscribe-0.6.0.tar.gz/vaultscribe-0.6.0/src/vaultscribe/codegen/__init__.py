"""Language binding code generation (Python pydantic, TypeScript vite)."""

from __future__ import annotations

from .main import codegen

__all__ = ["codegen"]
