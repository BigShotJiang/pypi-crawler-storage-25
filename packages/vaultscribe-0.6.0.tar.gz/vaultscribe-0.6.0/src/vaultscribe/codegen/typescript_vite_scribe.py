"""TypeScript binding code generation (vite, cloudflare pages)."""

from __future__ import annotations

import textwrap
from pathlib import Path
from typing import NamedTuple

from ..ui import err_console
from ..utils import to_camel_case
from ..vs_types import _REPO_ROOT, Flavour
from .shared import FieldMap, _get_autogen_header


class TypescriptFieldSets(NamedTuple):
    build_fields: FieldMap
    runtime_fields: FieldMap


def _runtime_function_endpoint(runtime_function_path: str) -> str:
    """Derive the URL path served by a Pages Function from its file path.

    e.g. "app/functions/vs-config.ts" -> "/vs-config"
    """
    after_functions = runtime_function_path.split("functions/", 1)[-1]
    return "/" + after_functions.removesuffix(".ts")


def _scribe_typescript(
    output_path: Path,
    field_sets: TypescriptFieldSets,
    runtime_function_path: str | None = None,
    silent: bool = False,
) -> None:
    build_fields = field_sets.build_fields
    runtime_fields = field_sets.runtime_fields

    runtime_public_keys = sorted(k for k, f in runtime_fields.items() if f.sensitivity == "PUBLIC")

    # window.VS_CONFIG type: runtime PUBLIC fields only.
    app_config_members = [f"{to_camel_case(k)}: string;" for k in runtime_public_keys]

    # VITE_* exports: build PUBLIC fields only.
    checks_list = []
    for key, f in sorted(build_fields.items()):
        if f.sensitivity == "PUBLIC":
            desc = (f.config.description or "").replace("\n", " ")
            checks_list.append(
                f"/** {desc} */\n"
                f"export const {key} = import.meta.env.VITE_{key};\n"
                f"if (!{key}) {{\n"
                f"  throw new Error(\n"
                f'    "{key} is missing from the client environment — ensure VITE_{key} is set",\n'
                f"  );\n"
                f"}}"
            )

    sections: list[str] = [
        _get_autogen_header(Flavour.TYPESCRIPT_VITE).rstrip("\n"),
    ]

    if app_config_members:
        config_members = textwrap.indent("\n".join(app_config_members), "      ")
        sections.append(
            f"declare global {{\n  interface Window {{\n    VS_CONFIG: {{\n{config_members}\n    }};\n  }}\n}}"
        )

    if runtime_public_keys and runtime_function_path:
        endpoint = _runtime_function_endpoint(runtime_function_path)
        field_literals = ", ".join(f'"{to_camel_case(k)}"' for k in runtime_public_keys)
        sections.append(
            f'function _vsParseConfig(raw: unknown): Window["VS_CONFIG"] {{\n'
            f'  if (typeof raw !== "object" || raw === null) {{\n'
            f'    throw new Error("vsLoadConfig: config response is not an object");\n'
            f"  }}\n"
            f"  const obj = raw as Record<string, unknown>;\n"
            f"  for (const field of [{field_literals}]) {{\n"
            f'    if (typeof obj[field] !== "string") {{\n'
            f'      throw new Error(`vsLoadConfig: missing or invalid field "${{field}}"`);\n'
            f"    }}\n"
            f"  }}\n"
            f'  return obj as unknown as Window["VS_CONFIG"];\n'
            f"}}\n\n"
            f"/** Fetch runtime config from the server and populate window.VS_CONFIG. */\n"
            f'export async function vsLoadConfig(): Promise<Window["VS_CONFIG"]> {{\n'
            f'  const res = await fetch("{endpoint}");\n'
            f"  if (!res.ok) {{\n"
            f"    throw new Error(`vsLoadConfig: fetch failed (${{res.status}} ${{res.statusText}})`);\n"
            f"  }}\n"
            f"  window.VS_CONFIG = _vsParseConfig(await res.json());\n"
            f"  if (import.meta.env.DEV) {{\n"
            f'    console.debug("[vaultscribe] runtime config loaded", window.VS_CONFIG);\n'
            f"  }}\n"
            f"  return window.VS_CONFIG;\n"
            f"}}"
        )

    if checks_list:
        sections.append("\n\n".join(checks_list))

    output_path.write_text("\n\n".join(sections) + "\n")
    if not silent:
        err_console.print(
            f"[bold green]✔︎ Scribed TypeScript bindings to {output_path.relative_to(_REPO_ROOT)}[/bold green]"
        )


def _scribe_vite_plugin(
    output_path: Path,
    build_public_fields: FieldMap,
    runtime_public_fields: FieldMap,
    runtime_function_path: str | None,
    silent: bool = False,
) -> None:
    """Generate a Vite plugin that handles all Vaultscribe integration.

    The plugin (vsPlugin) encapsulates:
    - Build-time validation: fails the build if any VITE_* vars are missing.
    - Dev-time validation: fails 'vite serve' if any runtime vars are missing.
    - Mock /vs-config endpoint for local development.

    Safe to import from vite.config.ts (no import.meta.env or browser APIs).
    """
    build_vars = sorted(f"VITE_{k}" for k in build_public_fields)
    runtime_vars = sorted(runtime_public_fields.keys())

    build_vars_inline = "[" + ", ".join(f'"{v}"' for v in build_vars) + "]"
    runtime_vars_inline = "[" + ", ".join(f'"{v}"' for v in runtime_vars) + "]"

    config_obj_entries = textwrap.indent(
        "\n".join(f"{to_camel_case(k)}: _env.{k}," for k in runtime_vars), "            "
    )

    endpoint = _runtime_function_endpoint(runtime_function_path) if runtime_function_path else "/vs-config"

    content = (
        _get_autogen_header(Flavour.TYPESCRIPT_VITE).rstrip("\n")
        + "\n\n"
        + 'import { loadEnv, type Plugin } from "vite";\n'
        + "\n"
        + f"const _BUILD_VARS = {build_vars_inline} as const;\n"
        + f"const _DEV_VARS = {runtime_vars_inline} as const;\n"
        + "\n"
        + "/**\n"
        + " * Vaultscribe Vite plugin. Add to your plugins array in vite.config.ts:\n"
        + " *\n"
        + " *   import { vaultScribePlugin } from './src/vs_vite_plugin';\n"
        + " *   plugins: [vaultScribePlugin(), ...]\n"
        + " */\n"
        + "export function vaultScribePlugin(): Plugin {\n"
        + "  let _env: Record<string, string> = {};\n"
        + "  return {\n"
        + '    name: "vaultscribe",\n'
        + "    config(_, { command, mode }) {\n"
        + '      _env = loadEnv(mode, process.cwd(), "");\n'
        + "      if (command === "
        + '"build") {\n'
        + "        const missing = _BUILD_VARS.filter((v) => !_env[v]);\n"
        + "        if (missing.length > 0) {\n"
        + "          throw new Error(\n"
        + "            `Missing build-time env vars — inject via 'vs run prod --target frontend_app': ${missing.join(\", \")}`,\n"  # noqa: E501
        + "          );\n"
        + "        }\n"
        + "      }\n"
        + '      if (command === "serve") {\n'
        + "        const missing = _DEV_VARS.filter((v) => !_env[v]);\n"
        + "        if (missing.length > 0) {\n"
        + "          throw new Error(\n"
        + "            `Missing dev env vars — run 'vs run dev --target frontend_app -- npm run dev': ${missing.join(\", \")}`,\n"  # noqa: E501
        + "          );\n"
        + "        }\n"
        + "      }\n"
        + "    },\n"
        + "    configureServer(server) {\n"
        + f'      server.middlewares.use("{endpoint}", (_req, res) => {{\n'
        + '        res.setHeader("Content-Type", "application/json");\n'
        + "        res.end(\n"
        + "          JSON.stringify({\n"
        + f"{config_obj_entries}\n"
        + "          }),\n"
        + "        );\n"
        + "      });\n"
        + "    },\n"
        + "  };\n"
        + "}\n"
    )
    output_path.write_text(content)
    if not silent:
        err_console.print(f"[bold green]✔︎ Scribed Vite plugin to {output_path.relative_to(_REPO_ROOT)}[/bold green]")


def _scribe_env_development_vs_example(
    output_path: Path,
    build_public_fields: FieldMap,
    runtime_public_fields: FieldMap,
    silent: bool = False,
) -> None:
    lines = [
        "# Generated by vaultscribe — do not edit manually.",
        "#",
        "#  - This is used to override secrets for local development.",
        "#  - Copy this file to .env.development and fill in your local dev values.",
        "#  - Vite loads .env.development automatically during `vite dev`.",
        "#",
        "# Do NOT commit .env.development — add it to your .gitignore.",
    ]

    if build_public_fields:
        lines += ["", "# Build-time public values (baked into the JS bundle as import.meta.env.VITE_*):"]
        for key in sorted(build_public_fields):
            desc = build_public_fields[key].config.description
            if desc:
                lines.append(f"# {desc}")
            lines.append(f"VITE_{key}=")

    if runtime_public_fields:
        lines += ["", "# Runtime public values (served via the /vs-config dev mock — NOT baked into bundle):"]
        for key in sorted(runtime_public_fields):
            desc = runtime_public_fields[key].config.description
            if desc:
                lines.append(f"# {desc}")
            lines.append(f"{key}=")

    output_path.write_text("\n".join(lines) + "\n")
    if not silent:
        err_console.print(
            f"[bold green]✔︎ Scribed dev env example to {output_path.relative_to(_REPO_ROOT)}[/bold green]"
        )


def _scribe_pages_function(
    output_path: Path,
    runtime_public_fields: FieldMap,
    silent: bool = False,
) -> None:
    sorted_keys = sorted(runtime_public_fields.keys())

    env_fields = textwrap.indent("\n".join(f"{key}: string;" for key in sorted_keys), "  ")
    response_entries = textwrap.indent(
        "\n".join(f"{to_camel_case(key)}: context.env.{key}," for key in sorted_keys),
        "      ",
    )

    content = (
        _get_autogen_header(Flavour.TYPESCRIPT_VITE).rstrip("\n")
        + "\n\n"
        + f"""\
export interface Env {{
{env_fields}
}}

export const onRequest: PagesFunction<Env> = async (context) => {{
  return new Response(
    JSON.stringify({{
{response_entries}
    }}),
    {{
      headers: {{
        "Content-Type": "application/json",
      }},
    }},
  );
}};
"""
    )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(content)
    if not silent:
        err_console.print(f"[bold green]✔︎ Scribed Pages Function to {output_path.relative_to(_REPO_ROOT)}[/bold green]")
