"""Language binding code generation orchestration."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import assert_never

from .. import vs_types as types
from ..schema import _parse_schema, _parse_sync_target, _report_config_error
from ..ui import (
    ErrorCategory,
    err_console,
    report_error,
    report_hint,
    report_list_item,
)
from ..vs_types import (
    _REPO_ROOT,
    CloudflarePagesTargetConfig,
    GcloudRunTargetConfig,
    Schema,
    SecretMetaField,
    Sensitivity,
    TargetDelivery,
    TargetType,
)
from .python_pydantic_scribe import PythonScribeConfig, _scribe_env_dev_vs_example, _scribe_python
from .shared import Field, FieldMap
from .typescript_vite_scribe import (
    TypescriptFieldSets,
    _scribe_env_development_vs_example,
    _scribe_pages_function,
    _scribe_typescript,
    _scribe_vite_plugin,
)


def _collect_all_fields(schema: Schema) -> FieldMap:
    all_fields: FieldMap = {}
    for block, sensitivity in [
        (schema.secrets, Sensitivity.SECRET),
        (schema.public, Sensitivity.PUBLIC),
    ]:
        for key, config in block.items():
            all_fields[key] = Field(config=config, sensitivity=sensitivity)
    return all_fields


def _resolve_sync_target_defaults(schema: Schema, all_fields: FieldMap) -> None:
    """Validate sync_targets references and auto-default for single non-CF targets."""
    for k, f in all_fields.items():
        for st_raw in f.config.sync_targets or []:
            st = _parse_sync_target(st_raw)
            if st.target not in schema.targets:
                msg = f"Secret '{k}' '{SecretMetaField.SYNC_TARGETS}' contains undefined consumer '{st.target}'."
                action = f"Define [targets.{st.target}] or remove it from '{SecretMetaField.SYNC_TARGETS}'."
                _report_config_error(msg, key=k, context=SecretMetaField.SYNC_TARGETS, action=action)

    non_cf_targets = [
        name
        for name, target in schema.targets.items()
        if target.type not in {TargetType.CLOUDFLARE_PAGES, TargetType.SCRIPT}
    ]
    if len(schema.targets) > 1:
        missing = [k for k, f in all_fields.items() if f.config.sync_targets is None]
        if missing:
            report_error("Multiple targets detected.", category=ErrorCategory.CODEGEN)
            report_hint(
                "Info:",
                "When multiple targets are defined, every secret must explicitly declare "
                f"'{SecretMetaField.SYNC_TARGETS}'.",
            )
            report_hint("Action:", "Add `sync_targets = []` for CLI-only secrets.")
            report_hint("Missing:", "Secrets missing targets:")
            for k in missing:
                report_list_item(k)
            err_console.print()
            sys.exit(1)
    elif len(non_cf_targets) == 1:
        # Auto-default only for non-cloudflare single targets; cloudflare targets
        # require explicit delivery qualifiers which cannot be assumed.
        only_target = non_cf_targets[0]
        for key, field in all_fields.items():
            if field.config.sync_targets is None:
                new_config = types.SecretConfig(
                    description=field.config.description,
                    source=field.config.source,
                    sync_targets=[only_target],
                    auto_generate=field.config.auto_generate,
                )
                all_fields[key] = Field(config=new_config, sensitivity=field.sensitivity)


def _codegen_gcloud_run(
    target: GcloudRunTargetConfig,
    schema: Schema,
    target_fields: FieldMap,
    silent: bool,
) -> None:
    source_dir = _REPO_ROOT / target.source
    _scribe_python(
        source_dir / "vs_secrets.py",
        target_fields,
        envs=schema.environments,
        config=PythonScribeConfig(
            source_depth=len(Path(target.source).parts),
            source=target.source,
            secrets_env_var=target.secrets_env_var,
            overlay=target.overlay,
        ),
        silent=silent,
    )
    if target.overlay:
        _scribe_env_dev_vs_example(
            source_dir / f"{target.overlay}.vs_example",
            fields=target_fields,
            overlay_name=target.overlay,
            silent=silent,
        )


def _codegen_cloudflare_pages(
    target: CloudflarePagesTargetConfig,
    name: str,
    target_fields: FieldMap,
    silent: bool,
) -> None:
    source_dir = _REPO_ROOT / target.source

    def _target_delivery(f: Field, delivery: TargetDelivery) -> bool:
        return any(
            _parse_sync_target(st).target == name and _parse_sync_target(st).delivery == delivery
            for st in f.config.sync_targets or []
        )

    build_fields = {k: f for k, f in target_fields.items() if _target_delivery(f, TargetDelivery.BUILD)}
    runtime_fields = {k: f for k, f in target_fields.items() if _target_delivery(f, TargetDelivery.RUNTIME)}
    _scribe_typescript(
        source_dir / "vs_config.ts",
        field_sets=TypescriptFieldSets(
            build_fields=build_fields,
            runtime_fields=runtime_fields,
        ),
        runtime_function_path=target.runtime_function_path,
        silent=silent,
    )
    build_public_fields = {k: f for k, f in build_fields.items() if f.sensitivity == Sensitivity.PUBLIC}
    runtime_public_fields = {k: f for k, f in runtime_fields.items() if f.sensitivity == Sensitivity.PUBLIC}
    if build_public_fields or runtime_public_fields:
        _scribe_vite_plugin(
            source_dir / "vs_vite_plugin.ts",
            build_public_fields=build_public_fields,
            runtime_public_fields=runtime_public_fields,
            runtime_function_path=target.runtime_function_path,
            silent=silent,
        )
        _scribe_env_development_vs_example(
            source_dir.parent / ".env.development.vs_example",
            build_public_fields=build_public_fields,
            runtime_public_fields=runtime_public_fields,
            silent=silent,
        )
    if target.runtime_function_path and runtime_public_fields:
        _scribe_pages_function(
            _REPO_ROOT / target.runtime_function_path,
            runtime_public_fields=runtime_public_fields,
            silent=silent,
        )


def _codegen_for_target(
    name: str,
    target: GcloudRunTargetConfig | CloudflarePagesTargetConfig,
    schema: Schema,
    all_fields: FieldMap,
    silent: bool,
) -> None:
    def _in_target(f: Field) -> bool:
        return any(_parse_sync_target(st).target == name for st in f.config.sync_targets or [])

    target_fields = {k: f for k, f in all_fields.items() if _in_target(f)}

    match target:
        case GcloudRunTargetConfig():
            _codegen_gcloud_run(target, schema, target_fields, silent)
        case CloudflarePagesTargetConfig():
            _codegen_cloudflare_pages(target, name, target_fields, silent)
        case _:
            assert_never(target)


def codegen(silent: bool = False) -> None:
    """Read the schema and scribe the language bindings."""
    schema: Schema = _parse_schema()
    all_fields = _collect_all_fields(schema)
    _resolve_sync_target_defaults(schema, all_fields)
    for name, target in schema.targets.items():
        if isinstance(target, (GcloudRunTargetConfig, CloudflarePagesTargetConfig)):
            _codegen_for_target(name, target, schema, all_fields, silent)
