"""Python binding code generation (pydantic)."""

from __future__ import annotations

import textwrap
from dataclasses import dataclass
from pathlib import Path

from ..ui import err_console
from ..utils import to_snake_case
from ..vs_types import _REPO_ROOT, EnvConfig, EnvName, Flavour, Namespace, Sensitivity
from .shared import _INDENT, _S105_REGEX, FieldMap, _get_autogen_header


@dataclass(frozen=True)
class PythonScribeConfig:
    source_depth: int
    source: str
    secrets_env_var: str
    overlay: str | None = None


# Plain string (not f-string) so the Python-code braces inside are literal characters.
_BUNDLE_SOURCE_CLASS = '''


class _BundleSource(PydanticBaseSettingsSource):
    """Reads the BUNDLE_ENV_VAR env var (JSON string) as the lowest-priority source."""

    def _bundle(self) -> dict[str, Any]:
        raw = os.environ.get(BUNDLE_ENV_VAR, "")
        if not raw:
            return {}
        data = json.loads(raw)
        if not isinstance(data, dict):
            raise ValueError(f"{BUNDLE_ENV_VAR} must be a JSON object, got {type(data).__name__}")

        def map_keys(d: dict[str, Any]) -> dict[SecretField, Any]:
            out: dict[SecretField, Any] = {}
            for k, v in d.items():
                try:
                    is_member = k.upper() in SecretField.__members__
                    field = SecretField[k.upper()] if is_member else SecretField(k.lower())
                    out[field] = v
                except (KeyError, ValueError):
                    continue
            return out

        typed_data = {
            Namespace.SECRET: map_keys(data.get(Namespace.SECRET, {})),
            Namespace.PUBLIC: map_keys(data.get(Namespace.PUBLIC, {})),
        }
        bundle = SecretBundle.model_validate(typed_data)
        merged = {**bundle.secret, **bundle.public}
        return {k.name.lower(): v for k, v in merged.items()}

    def get_field_value(self, field: FieldInfo, field_name: str) -> tuple[Any, str, bool]:
        return self._bundle().get(field_name.lower()), field_name, False

    def field_is_complex(self, field: FieldInfo) -> bool:
        return False

    def __call__(self) -> dict[str, Any]:
        bundle_data = self._bundle()
        known_keys = {f.name.lower() for f in SecretField}
        return {k: v for k, v in bundle_data.items() if k in known_keys}
'''

_CUSTOMISE_SOURCES_METHOD = """

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        return (init_settings, env_settings, dotenv_settings, _BundleSource(settings_cls))
"""

_STARTUP_DIAGNOSTICS_FUNC = '''\
def _log_startup_diagnostics() -> None:
    """Log Vaultscribe startup diagnostics.

    Reports which source provided each key (override detection) and warns
    about keys in overlay files that are not defined in vaultscribe.toml.
    Subclasses that override model_post_init must call super().model_post_init(__context).
    """
    known_keys = {field.name for field in SecretField}

    # Track which file last provided each key to detect overrides.
    sourced: dict[str, str] = {}
    for filepath in _ENV_FILES:
        path = Path(filepath)
        if not path.exists():
            continue
        for key in _dotenv_values(filepath):
            upper = key.upper()
            if upper in sourced:
                _logger.debug(
                    "Override: %s — %s overrides %s",
                    key,
                    path.name,
                    Path(sourced[upper]).name,
                )
            else:
                _logger.debug("Sourced: %s from %s", key, path.name)
            sourced[upper] = filepath

    # Report any remaining keys sourced directly from environment variables.
    for field in SecretField:
        if field.name in os.environ and field.name not in sourced:
            _logger.debug("Sourced: %s from env var", field.name)

    # Warn about keys in overlay files that Vaultscribe does not own.
    for filepath in _OVERLAY_FILES:
        path = Path(filepath)
        if not path.exists():
            continue
        for key in _dotenv_values(filepath):
            if key.upper() not in known_keys:
                _logger.warning(
                    "%s: %r is not defined in vaultscribe.toml",
                    path.name,
                    key,
                )

    _logger.info("Vaultscribe: %d secrets loaded.", len(known_keys))
'''

_STARTUP_DIAGNOSTICS_FUNC = '''\
def _log_startup_diagnostics() -> None:
    """Log Vaultscribe startup diagnostics.

    Logs sources in priority order (lowest first) so that the final winner is
    clear. Bundle is logged first; local env files and overlays follow and show
    as overrides when they supersede the bundle.
    Subclasses that override model_post_init must call super().model_post_init(__context).
    """
    # sourced tracks the current winning source for each key (key_upper -> label).
    sourced: dict[str, str] = {}

    # 1. Bundle — lowest local priority, always reported first.
    _bundle_raw = os.environ.get(BUNDLE_ENV_VAR, "")
    if _bundle_raw:
        try:
            _bundle_data = json.loads(_bundle_raw)
            for _ns in Namespace:
                for _key in _bundle_data.get(_ns, {}):
                    _logger.debug("Sourced: %s from bundle (%s)", _key, BUNDLE_ENV_VAR)
                    sourced[_key.upper()] = BUNDLE_ENV_VAR
        except Exception as e:
            _logger.debug("Could not parse bundle env var: %s", e)

    # 2. Env files then overlays — higher priority; log as overrides where they win.
    for filepath in _ENV_FILES + _OVERLAY_FILES:
        path = Path(filepath)
        if not path.exists():
            continue
        for key in _dotenv_values(filepath):
            upper = key.upper()
            prev = sourced.get(upper)
            if prev is not None:
                prev_label = f"bundle ({BUNDLE_ENV_VAR})" if prev == BUNDLE_ENV_VAR else Path(prev).name
                _logger.debug("Override: %s — %s overrides %s", key, path.name, prev_label)
            else:
                _logger.debug("Sourced: %s from %s", key, path.name)
            sourced[upper] = filepath

    # 3. Individual env vars — highest priority.
    for field in SecretField:
        if field.name in os.environ and field.name not in sourced:
            _logger.debug("Sourced: %s from env var", field.name)

    n_secrets = sum(1 for f in SecretField if SECRET_DETAILS[f].sensitivity == Sensitivity.SECRET)
    n_public = sum(1 for f in SecretField if SECRET_DETAILS[f].sensitivity == Sensitivity.PUBLIC)
    _logger.info(
        "Vaultscribe: schema satisfied — %d %s, %d public %s loaded.",
        n_secrets,
        "secret" if n_secrets == 1 else "secrets",
        n_public,
        "value" if n_public == 1 else "values",
    )
'''


def _scribe_python(
    output_path: Path,
    fields: FieldMap,
    envs: dict[EnvName, EnvConfig],
    config: PythonScribeConfig,
    silent: bool = False,
) -> None:
    enum_lines = []
    for key in sorted(fields.keys()):
        line = f'{key} = "{key}"'
        if _S105_REGEX.search(key):
            line += "  # noqa: S105"
        enum_lines.append(line)
    enum_members = textwrap.indent("\n".join(enum_lines), _INDENT)

    # details_entries are each indented by _INDENT internally, then wrapped by a
    # further _INDENT via textwrap.indent — so the effective column for field lines
    # is _INDENT * 2.
    _DETAILS_FIELD_COL = len(_INDENT) * 2
    _MAX_LINE_LEN = 120

    def _str_field(label: str, value: str) -> str:
        """Return `label="value",`, wrapping into implicit concatenation if too long."""
        prefix = f"{_INDENT}{label}="
        # +3: opening quote, closing quote, comma
        if _DETAILS_FIELD_COL + len(label) + 1 + len(value) + 3 <= _MAX_LINE_LEN:
            return f'{prefix}"{value}",'
        # Wrap: split at whitespace into chunks that fit on one quoted line.
        # inner is _INDENT*2 within the entry; textwrap.indent adds one more _INDENT,
        # so the final rendered column is _DETAILS_FIELD_COL + len(_INDENT).
        inner = _INDENT * 2
        final_inner_col = _DETAILS_FIELD_COL + len(_INDENT)
        chunk_width = _MAX_LINE_LEN - final_inner_col - 2  # 2 for surrounding quotes
        chunks = textwrap.wrap(value, chunk_width)
        joined = ("\n" + inner).join(f'"{c}"' for c in chunks)
        return f"{prefix}(\n{inner}{joined}\n{_INDENT}),"

    details_entries = []
    settings_fields = []
    for key in sorted(fields.keys()):
        f = fields[key]
        entry = (
            f"SecretField.{key}: SecretDetail(\n"
            f"{_str_field('description', f.config.description or '')}\n"
            f"{_str_field('source', f.config.source or '')}\n"
            f"{_INDENT}sensitivity=Sensitivity.{f.sensitivity},\n"
            f"{_INDENT}auto_generate={bool(f.config.auto_generate)},\n"
            f"),"
        )
        details_entries.append(entry)
        settings_fields.append(f'{to_snake_case(key)}: str = Field(alias="{key}")')

    details_block = textwrap.indent("\n".join(details_entries), _INDENT)
    settings_block = textwrap.indent("\n".join(settings_fields), _INDENT)

    def nq(s: str) -> str:
        return "  # noqa: S105" if _S105_REGEX.search(s) else ""

    # _ENV_FILES: secrets files for every env (in declaration order).
    env_file_entries = [f'    str(_REPO_ROOT / ".secrets.{env_name}"),' for env_name in envs]
    env_files_lines = "\n".join(env_file_entries)

    overlay_entries = [f'    str(_REPO_ROOT / "{config.source}" / "{config.overlay}"),'] if config.overlay else []

    imports = """\
import json
import logging
import os
from dataclasses import dataclass
from enum import StrEnum, unique
from pathlib import Path
from typing import Any, Final, NewType

from dotenv import dotenv_values as _dotenv_values
from pydantic import BaseModel, ConfigDict, Field
from pydantic.fields import FieldInfo
from pydantic_settings import BaseSettings, PydanticBaseSettingsSource, SettingsConfigDict
"""
    bundle_env_var_line = f'\nBUNDLE_ENV_VAR: Final[str] = "{config.secrets_env_var}"{nq(config.secrets_env_var)}\n'

    overlay_files_lines = "\n".join(overlay_entries)

    content = (
        _get_autogen_header(Flavour.PYTHON_PYDANTIC)
        + imports
        + bundle_env_var_line
        + f"""
_REPO_ROOT = Path(__file__).parents[{config.source_depth}]
_ENV_FILES = [
{env_files_lines}
]
_OVERLAY_FILES = [
{overlay_files_lines}
]

_logger = logging.getLogger(__name__)


@unique
class Namespace(StrEnum):
    \"\"\"Namespaces for the secret bundle.\"\"\"

    SECRET = "{Namespace.SECRET}"{nq(Namespace.SECRET)}
    PUBLIC = "{Namespace.PUBLIC}"{nq(Namespace.PUBLIC)}


@unique
class Sensitivity(StrEnum):
    \"\"\"Namespaces for the secret bundle.\"\"\"

    SECRET = "SECRET"{nq("SECRET")}
    PUBLIC = "PUBLIC"{nq("PUBLIC")}


@unique
class SecretField(StrEnum):
    \"\"\"The set of production secrets required by the application.\"\"\"

{enum_members}


SecretValue = NewType("SecretValue", str)


class SecretBundle(BaseModel):
    \"\"\"The complete JSON structure for the secret bundle.\"\"\"

    model_config = ConfigDict(frozen=True, extra="forbid")

    {Namespace.SECRET}: dict[SecretField, SecretValue]
    {Namespace.PUBLIC}: dict[SecretField, SecretValue]


@dataclass(frozen=True)
class SecretDetail:
    \"\"\"Metadata for a single secret field.\"\"\"

    description: str
    source: str
    sensitivity: Sensitivity = Sensitivity.SECRET
    auto_generate: bool = False


# Documentation for each secret. This is the single source of truth.
SECRET_DETAILS: Final[dict[SecretField, SecretDetail]] = {{
{details_block}
}}"""
        + _BUNDLE_SOURCE_CLASS
        + "\n\n"
        + _STARTUP_DIAGNOSTICS_FUNC
        + "\n\n"
        + f"""class VaultscribeSecretSettings(BaseSettings):
    \"\"\"Autogenerated base class for Pydantic Settings.

    Contains all secret and public fields assigned to this target.
    \"\"\"

    model_config = SettingsConfigDict(
        env_file=_ENV_FILES,
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
        populate_by_name=True,
    )

{settings_block}{_CUSTOMISE_SOURCES_METHOD}
    def model_post_init(self, __context: object) -> None:
        _log_startup_diagnostics()
"""
    )
    output_path.write_text(content)
    if not silent:
        err_console.print(
            f"[bold green]✔︎ Scribed Python bindings to {output_path.relative_to(_REPO_ROOT)}[/bold green]"
        )


def _scribe_env_dev_vs_example(
    output_path: Path,
    fields: FieldMap,
    overlay_name: str,
    silent: bool = False,
) -> None:
    secret_fields = {k: f for k, f in fields.items() if f.sensitivity == Sensitivity.SECRET}
    public_fields = {k: f for k, f in fields.items() if f.sensitivity == Sensitivity.PUBLIC}

    lines = [
        "# Generated by vaultscribe — do not edit manually.",
        "#",
        "#  - This is used to override secrets for local development.",
        f"#  - Copy this file to {overlay_name} and fill in your local dev values.",
        f"#  - Vaultscribe will automatically load {overlay_name} during local development.",
        "#",
        f"# Do NOT commit {overlay_name} — add it to your .gitignore.",
    ]

    if secret_fields:
        lines += ["", "# Secrets:"]
        for key in sorted(secret_fields):
            desc = secret_fields[key].config.description
            if desc:
                lines.append(f"# {desc}")
            lines.append(f"{key}=")

    if public_fields:
        lines += ["", "# Public config:"]
        for key in sorted(public_fields):
            desc = public_fields[key].config.description
            if desc:
                lines.append(f"# {desc}")
            lines.append(f"{key}=")

    output_path.write_text("\n".join(lines) + "\n")
    if not silent:
        err_console.print(
            f"[bold green]✔︎ Scribed dev env example to {output_path.relative_to(_REPO_ROOT)}[/bold green]"
        )
