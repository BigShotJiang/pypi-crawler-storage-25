"""Sync secrets to deployment targets (Cloud Run, Cloudflare Pages)."""

from __future__ import annotations

import json
import sys
import urllib.error
import urllib.request
from typing import assert_never

from .deps import GH, NPX, check_cli
from .gcloud import _fetch_from_gcloud
from .schema import _get_env_config, _parse_schema
from .shell import RunContext, _run
from .ui import ErrorCategory, err_console, report_error, report_hint, report_list_item
from .validation import _parse_sync_target
from .vs_types import (
    CloudflarePagesTargetConfig,
    FlatSecrets,
    GcloudRunTargetConfig,
    GitHubActionsTargetConfig,
    Schema,
    ScriptTargetConfig,
    SecretConfig,
    SecretKey,
    TargetDelivery,
    TargetName,
)


def _resolve_val(val: str, env_vars: FlatSecrets, schema: Schema) -> str:
    """Interpolate ${KEY} from the vault bundle using exact casing."""
    if not val.startswith("${") or not val.endswith("}"):
        return val

    target_key = val[2:-1]
    sk = SecretKey(target_key)
    if sk in env_vars:
        return env_vars[sk]

    all_keys = list(schema.secrets.keys()) + list(schema.public.keys())
    low_target = target_key.lower()
    match = next((k for k in all_keys if k.lower() == low_target), None)

    report_error(f"Reference '{val}' not found in schema.", category=ErrorCategory.CONFIG)
    if match:
        report_hint("Action:", f"Did you mean '${{{match}}}'? (Casing must match exactly)")
    else:
        report_hint("Action:", f"Define '{target_key}' in vaultscribe.toml or remove the reference.")
    err_console.print()
    sys.exit(1)


def _sync_cloudflare_runtime_secret(key: str, val: str, proj_name: str, auth_token: str, acc_id: str) -> None:
    """Push a single runtime secret to Cloudflare Pages via wrangler."""
    _run(
        [
            "npx",
            "wrangler",
            "pages",
            "secret",
            "put",
            key,
            "--project-name",
            proj_name,
        ],
        input=val.encode(),
        context=RunContext(env={"CLOUDFLARE_API_TOKEN": auth_token, "CLOUDFLARE_ACCOUNT_ID": acc_id}),
        silent=True,
    )


def _sync_cloudflare_build_env_vars(build_kvs: dict[str, str], proj_name: str, auth_token: str, acc_id: str) -> None:
    """Push build-time env vars to Cloudflare Pages via the REST API.

    These are set as VITE_-prefixed variables under deployment_configs.production
    so that future Cloudflare-triggered builds pick them up.
    """
    env_vars_payload = {f"VITE_{k}": {"value": v} for k, v in build_kvs.items()}
    payload = json.dumps({"deployment_configs": {"production": {"env_vars": env_vars_payload}}}).encode()

    url = f"https://api.cloudflare.com/client/v4/accounts/{acc_id}/pages/projects/{proj_name}"
    req = urllib.request.Request(  # noqa: S310
        url,
        data=payload,
        method="PATCH",
        headers={
            "Authorization": f"Bearer {auth_token}",
            "Content-Type": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(req) as resp:  # noqa: S310
            body = json.loads(resp.read())
        if not body.get("success"):
            errors = body.get("errors", [])
            report_error(f"Failed to set build env vars for '{proj_name}'.", category=ErrorCategory.CLOUDFLARE)
            for err in errors:
                report_list_item(err)
            err_console.print()
            sys.exit(1)
    except urllib.error.HTTPError as e:
        body_text = e.read().decode(errors="replace")
        report_error(f"HTTP {e.code} patching build env vars for '{proj_name}'.", category=ErrorCategory.CLOUDFLARE)
        report_hint("Details:", body_text)
        err_console.print()
        sys.exit(1)


def _sync_cloudflare(target: CloudflarePagesTargetConfig, env_vars: FlatSecrets, schema: Schema, env_name: str) -> None:
    check_cli(NPX)
    proj_name = target.project_name_for_env(env_name)
    raw_auth = target.auth_token_for_env(env_name)
    raw_acc = target.account_id_for_env(env_name)
    auth_token = _resolve_val(raw_auth, env_vars, schema)
    acc_id = _resolve_val(raw_acc, env_vars, schema)

    err_console.print(f"Syncing to Cloudflare Pages '{proj_name}'...")

    runtime_keys: list[str] = []
    build_keys: list[str] = []
    for block in [schema.secrets, schema.public]:
        for k, config in block.items():
            for st_raw in config.sync_targets or []:
                st = _parse_sync_target(st_raw)
                if st.target == target.name:
                    if st.delivery == TargetDelivery.RUNTIME:
                        runtime_keys.append(k)
                    elif st.delivery == TargetDelivery.BUILD:
                        build_keys.append(k)

    for k in sorted(runtime_keys):
        val = str(env_vars.get(SecretKey(k), ""))
        err_console.print(f"  - {k} (runtime)...", end="")
        _sync_cloudflare_runtime_secret(k, val, proj_name, auth_token, acc_id)
        err_console.print(" done")

    if build_keys:
        build_kvs = {k: str(env_vars.get(SecretKey(k), "")) for k in sorted(build_keys)}
        keys_str = ", ".join(f"VITE_{k}" for k in sorted(build_keys))
        err_console.print(f"  - {keys_str} (build)...", end="")
        _sync_cloudflare_build_env_vars(build_kvs, proj_name, auth_token, acc_id)
        err_console.print(" done")


def _gh_targets_for_key(target_name: str, sync_targets: list[str] | None) -> bool:
    """Return True if any entry in sync_targets matches this github_actions target."""
    for st_raw in sync_targets or []:
        st = _parse_sync_target(st_raw)
        if st.target == target_name:
            return True
    return False


def _gh_run(args: list[str], value: str) -> None:
    """Run a `gh` command, piping the value via stdin (never on argv)."""
    _run(args, input=value.encode(), silent=True)


def _sync_github_actions(
    target: GitHubActionsTargetConfig, env_vars: FlatSecrets, schema: Schema, env_name: str
) -> None:
    check_cli(GH)

    if target.vs_env != env_name:
        err_console.print(
            f"[dim]Skipping '{target.name}': bound to vs env '{target.vs_env}', current push is '{env_name}'.[/dim]"
        )
        return

    scope_label = f"{target.repo}"
    scope_args = ["--repo", target.repo]
    if target.environment is not None:
        scope_label += f" (environment: {target.environment})"
        scope_args += ["--env", target.environment]

    err_console.print(f"Syncing to GitHub Actions {scope_label} for vs env '{env_name}'...")

    def _push_block(block: dict[SecretKey, SecretConfig], gh_subcmd: str, label: str) -> None:
        for key in sorted(block.keys()):
            config = block[key]
            if not _gh_targets_for_key(target.name, config.sync_targets):
                continue
            value = str(env_vars.get(SecretKey(key), ""))
            err_console.print(f"  - {key} ({label})...", end="")
            _gh_run(["gh", gh_subcmd, "set", key, *scope_args], value)
            err_console.print(" done")

    _push_block(schema.secrets, "secret", "secret")
    _push_block(schema.public, "variable", "variable")


def _sync_cmd(env_name: str, target_name: str | None = None) -> None:
    """Broadcast secrets from GCloud Secret Manager to secondary providers."""
    schema = _parse_schema()
    env_conf = _get_env_config(schema, env_name)

    err_console.print(f"Fetching [bold]{env_conf.slot}[/bold] from GCloud Secret Manager ({env_name})...")
    env_vars = _fetch_from_gcloud(env_conf.project, env_conf.slot, schema)

    selected_names: list[str] = [target_name] if target_name else list(schema.targets.keys())

    for name in selected_names:
        target = schema.targets.get(TargetName(name))
        if target is None:
            continue

        match target:
            case CloudflarePagesTargetConfig():
                _sync_cloudflare(target, env_vars, schema, env_name)
            case GitHubActionsTargetConfig():
                _sync_github_actions(target, env_vars, schema, env_name)
            case GcloudRunTargetConfig() | ScriptTargetConfig():
                # GCloud Run targets draw secrets directly from Secret Manager at
                # runtime via --set-secrets; script targets are CLI-only.
                pass
            case _:
                assert_never(target)
