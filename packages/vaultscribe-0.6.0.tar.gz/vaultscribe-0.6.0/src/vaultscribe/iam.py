"""IAM management for GCloud Secret Manager."""

from __future__ import annotations

import json
import subprocess

from .ui import err_console
from .vs_types import EnvConfig, Schema, TargetType


def _ensure_gcloud_run_iam(env_conf: EnvConfig, schema: Schema, env_name: str) -> None:
    """Ensure the Compute Engine default SA has secretAccessor on the slot."""
    has_gcloud_run = any(target.type == TargetType.GCLOUD_RUN for target in schema.targets.values())
    if not has_gcloud_run:
        return

    try:
        result = subprocess.run(
            [
                "gcloud",
                "projects",
                "describe",
                env_conf.project,
                "--format=value(projectNumber)",
            ],
            capture_output=True,
            text=True,
            check=True,
        )
        project_number = result.stdout.strip()
    except subprocess.CalledProcessError:
        err_console.print("[yellow]⚠️  Could not determine project number; skipping IAM check.[/yellow]")
        return

    sa = f"{project_number}-compute@developer.gserviceaccount.com"
    member = f"serviceAccount:{sa}"
    role = "roles/secretmanager.secretAccessor"

    err_console.print(f"Checking [bold]{sa}[/bold] has Secret Manager access on [bold]{env_conf.slot}[/bold]...")

    already_granted = False
    try:
        policy_result = subprocess.run(
            [
                "gcloud",
                "secrets",
                "get-iam-policy",
                env_conf.slot,
                f"--project={env_conf.project}",
                "--format=json",
            ],
            capture_output=True,
            text=True,
            check=True,
        )
        policy = json.loads(policy_result.stdout)
        bindings = policy.get("bindings", [])
        already_granted = any(b.get("role") == role and member in b.get("members", []) for b in bindings)
    except (subprocess.CalledProcessError, json.JSONDecodeError):
        pass

    if already_granted:
        err_console.print(f"[bold green]✔︎ [bold]{sa}[/bold] already has access.[/bold green]")
        return

    err_console.print(f"  Granting [bold]{role}[/bold]...")
    try:
        subprocess.run(
            [
                "gcloud",
                "secrets",
                "add-iam-policy-binding",
                env_conf.slot,
                f"--member={member}",
                f"--role={role}",
                f"--project={env_conf.project}",
            ],
            capture_output=True,
            text=True,
            check=True,
        )
        err_console.print(f"[bold green]✔︎ Granted [bold]{role}[/bold] to [bold]{sa}[/bold].[/bold green]")
    except subprocess.CalledProcessError as e:
        err_lower = e.stderr.lower()
        if "does not exist" in err_lower or "not found" in err_lower:
            err_console.print(
                "[yellow]⚠️  Service account does not exist yet. Re-run 'vs push' after first deploy.[/yellow]"
            )
        else:
            err_console.print(f"[yellow]⚠️  Could not grant IAM: {e.stderr.strip()}[/yellow]")
