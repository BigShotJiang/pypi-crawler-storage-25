"""CLI entry point: argument parsing and command dispatch."""

from __future__ import annotations

import argparse
import dataclasses
import importlib.metadata
import json
import os
import sys
from enum import Enum
from typing import assert_never

from .codegen import codegen
from .display import _list_cmd, _mock_env_cmd, _show_cmd
from .gcloud import GCloudTokenExpiredError
from .init import _init_cmd
from .run import _run_command
from .schema import _parse_schema
from .session import _reauth_in_shell, _start_shell
from .sync import _sync_cmd
from .ui import err_console, out_console, report_error, report_hint, report_warning
from .vault import _pull, _push, _rotate_cmd
from .vs_types import MOCK_ENV, Command

# Commands that require an active vs shell session (i.e. GCloud auth).
_GCLOUD_COMMANDS = frozenset(
    {
        Command.PULL,
        Command.PUSH,
        Command.ROTATE,
        Command.SHOW,
        Command.SYNC,
        Command.RUN,
    }
)

# Subset of GCloud commands that take env as a positional argument.
_ENV_COMMANDS = frozenset(
    {
        Command.PULL,
        Command.PUSH,
        Command.ROTATE,
        Command.SHOW,
        Command.SYNC,
        Command.RUN,
    }
)


def _schema_to_json(obj: object) -> object:
    """JSON encoder for Schema dataclasses and Enum members."""
    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        return dataclasses.asdict(obj)
    if isinstance(obj, Enum):
        return obj.value
    raise TypeError(f"Object of type {type(obj)} is not JSON serialisable")


def _require_env(command: Command) -> None:
    """Exit with a helpful error listing available environments when env is omitted."""
    schema = _parse_schema()
    available = sorted(schema.environments.keys())
    report_error(f"env is required for '{command}'.")
    if available:
        report_hint("Available:", ", ".join(available))
        report_hint("Example:", f"[green]vs {command} {available[0]}[/green]")
    err_console.print()
    sys.exit(1)


def _require_shell(command: Command) -> None:
    """Exit with a friendly error if not inside a vs shell."""
    if "VS_SESSION_DIR" not in os.environ:
        report_warning("This command requires a secure session.")
        report_hint("Action:", "[green]vs shell[/green]")
        err_console.print()
        sys.exit(1)


def _dispatch(args: argparse.Namespace, env: str) -> None:  # noqa: PLR0912
    """Execute the requested command (without any auth retry logic)."""
    command = Command(args.command)
    match command:
        case Command.PARSE_TEST:
            schema = _parse_schema()
            if args.quiet:
                err_console.print("[bold green]✔︎ vaultscribe.toml parsed successfully.[/bold green]")
            else:
                out_console.print_json(json.dumps(dataclasses.asdict(schema), default=_schema_to_json))
        case Command.CODEGEN:
            codegen()
        case Command.MOCK_ENV:
            _mock_env_cmd()
        case Command.PULL:
            _pull(env)
        case Command.PUSH:
            _push(env, args.no_sync)
        case Command.SYNC:
            _sync_cmd(env, getattr(args, "target", None))
        case Command.LIST:
            _list_cmd()
        case Command.SHOW:
            _show_cmd(env, args.key, args.all, args.reveal)
        case Command.ROTATE:
            _rotate_cmd(env, args.key, args.value)
        case Command.RUN:
            _run_command(env, args.target, args.cmd)
        case Command.INIT | Command.SHELL:
            # Handled in main() before reaching _dispatch
            pass
        case _:
            assert_never(command)


def _build_parser() -> tuple[argparse.ArgumentParser, argparse.ArgumentParser]:
    """Build and return the CLI argument parser and the run subparser."""
    try:
        version = importlib.metadata.version("vaultscribe")
    except importlib.metadata.PackageNotFoundError:
        version = "unknown"

    parser = argparse.ArgumentParser(description="Vaultscribe: Type-safe configuration manager.")
    parser.add_argument("--version", action="version", version=f"%(prog)s {version}")
    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("init", help="Scaffold a new Vaultscribe project.")
    p_parse_test = subparsers.add_parser("parse-test", help="Parse vaultscribe.toml AST.")
    p_parse_test.add_argument(
        "--quiet", action="store_true", help="Suppress JSON output; report success or failure only."
    )
    subparsers.add_parser("codegen", help="Scribe application bindings.")
    subparsers.add_parser("mock-env", help="Output mock environment string.")
    subparsers.add_parser("list", help="List all schema keys.")
    subparsers.add_parser("shell", help="Start a secure GCloud session.")

    p_pull = subparsers.add_parser("pull", help="Fetch secrets to local file.")
    p_pull.add_argument("env", nargs="?", help="Target environment (e.g. prod, dev).")

    p_push = subparsers.add_parser("push", help="Upload local file to GCloud Secret Manager.")
    p_push.add_argument("env", nargs="?", help="Target environment (e.g. prod, dev).")
    p_push.add_argument("--no-sync", action="store_true", help="Skip broadcasting to secondary targets.")

    p_sync = subparsers.add_parser("sync", help="Broadcast secrets to secondary targets.")
    p_sync.add_argument("env", nargs="?", help="Target environment (e.g. prod, dev).")
    p_sync.add_argument("target", nargs="?", help="Specific target to sync.")

    p_show = subparsers.add_parser("show", help="Display secrets from GCloud Secret Manager.")
    p_show.add_argument("env", nargs="?", help="Target environment (e.g. prod, dev).")
    p_show.add_argument("key", nargs="?", help="Specific key to show.")
    p_show.add_argument("--all", action="store_true", help="Show all values.")
    p_show.add_argument("--reveal", action="store_true", help="Reveal plaintext.")

    p_rotate = subparsers.add_parser(
        "rotate",
        help="Rotate a single secret value in GCloud Secret Manager. Zero disk.",
    )
    p_rotate.add_argument("env", nargs="?", help="Target environment (e.g. prod, dev).")
    p_rotate.add_argument("key", nargs="?", help="The secret key.")
    p_rotate.add_argument(
        "value",
        nargs="?",
        help="The new value (omit to be prompted, or auto-generated for auto_generate keys).",
    )

    run_parser = subparsers.add_parser("run", help="Execute command with secrets.")
    run_parser.add_argument("env", help="Environment to draw secrets from (e.g. dev, prod).")
    run_parser.add_argument(
        "--target",
        "-t",
        default=None,
        help="Target name for type-specific injection (e.g. backend_api, frontend_app). "
        "Omit for individual env var injection (tests, tooling).",
    )
    return parser, run_parser


def main() -> None:
    parser, run_parser = _build_parser()

    # Pre-split sys.argv at '--' so that argparse never sees the trailing command.
    # argparse.REMAINDER would consume '--target' if it appeared after the first
    # positional, breaking 'vs run dev --target backend_api -- uv run ...'.
    argv = sys.argv[1:]
    trailing_cmd: list[str] = []
    if "--" in argv:
        sep = argv.index("--")
        trailing_cmd = argv[sep + 1 :]
        argv = argv[:sep]

    args = parser.parse_args(argv)
    if trailing_cmd:
        args.cmd = trailing_cmd
    elif not hasattr(args, "cmd"):
        args.cmd = []
    env: str = getattr(args, "env", None) or ""
    command = Command(args.command)

    if command is Command.INIT:
        _init_cmd()
        return

    if command is Command.SHELL:
        _start_shell(schema=_parse_schema())
        return

    if command in _ENV_COMMANDS and not env:
        _require_env(command)

    if command is Command.RUN and not args.cmd:
        run_parser.print_help()
        sys.exit(1)

    if command in _GCLOUD_COMMANDS and not (command is Command.RUN and env == MOCK_ENV):
        _require_shell(command)

    try:
        _dispatch(args, env)
    except GCloudTokenExpiredError:
        proj: str = _parse_schema().project
        session_dir = os.environ.get("VS_SESSION_DIR", "")
        _reauth_in_shell(proj, session_dir)
        _dispatch(args, env)
