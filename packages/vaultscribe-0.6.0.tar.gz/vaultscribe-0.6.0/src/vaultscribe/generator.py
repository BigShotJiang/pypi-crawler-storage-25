"""Secret value generation logic."""

from __future__ import annotations

import secrets

from .vs_types import AutoGenerateConfig, AutoGenerateType


def _generate_secret_value(config: AutoGenerateConfig) -> str:
    """Generate a random value based on strict auto_generate rules."""
    match config.type:
        case AutoGenerateType.HEX:
            return secrets.token_hex(config.length // 2)
        case _:
            # This should be unreachable if AutoGenerateType is correctly parsed
            raise ValueError(f"Unhandled auto-generate type: {config.type}")
