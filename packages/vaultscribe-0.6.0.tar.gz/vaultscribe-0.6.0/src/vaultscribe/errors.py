"""Error reporting for vaultscribe configuration."""

from __future__ import annotations

import sys
from typing import NoReturn

from . import vs_types as types
from .ui import ErrorCategory, err_console, report_error, report_hint


def _report_config_error(
    message: str,
    key: str | None = None,
    context: str | None = None,
    action: str | None = None,
) -> NoReturn:
    """Print a professional error message with line number, source context, and action."""
    report_error(message, category=ErrorCategory.CONFIG)

    found_line = -1
    line_content = ""

    if key and types._SCHEMA_FILE.exists():
        lines = types._SCHEMA_FILE.read_text().splitlines()
        block_patterns = [
            f"[{key}]",
            f"[secrets.{key}]",
            f"[public.{key}]",
            f"[envs.{key}]",
            f"[targets.{key}]",
        ]
        start_idx = 0
        for i, line in enumerate(lines):
            if any(p in line.strip() for p in block_patterns):
                start_idx = i
                found_line = i + 1
                line_content = line
                break

        if context:
            for i in range(start_idx, len(lines)):
                line = lines[i]
                if context in line:
                    found_line = i + 1
                    line_content = line
                    break
                if i > start_idx and line.strip().startswith("["):
                    break

    if found_line != -1:
        err_console.print(f"[yellow]File: {types._SCHEMA_FILE.name}:{found_line}[/yellow]")
        err_console.print(f"[dim]{found_line:>4}[/dim] | {line_content}")

    if action:
        report_hint("Action:", action)

    err_console.print()
    sys.exit(1)
