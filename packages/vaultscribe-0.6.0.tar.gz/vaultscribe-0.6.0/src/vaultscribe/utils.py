"""General utility functions for Vaultscribe."""

from __future__ import annotations

import re


def to_snake_case(s: str) -> str:
    """Convert a string to snake_case.

    Used for Pydantic settings field names to ensure they follow Python conventions.

    This function is robust and handles PascalCase, camelCase, and acronyms (e.g., HTTPClient).
    It is idempotent: to_snake_case(to_snake_case(s)) == to_snake_case(s).
    """
    s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", s)
    return re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1).lower().replace("__", "_")


def to_camel_case(s: str) -> str:
    """Convert a string to camelCase.

    Used for TypeScript interface properties to ensure they follow TS conventions.

    Caveat: This function assumes the input is already in snake_case. It is "lossy" for
    other formats; for example, "PascalCase" becomes "pascalcase" because it does not
    detect word boundaries without underscores.

    To safely convert from an unknown format to camelCase, use:
    to_camel_case(to_snake_case(s)).
    """
    parts = s.lower().split("_")
    return parts[0] + "".join(x.title() for x in parts[1:])
