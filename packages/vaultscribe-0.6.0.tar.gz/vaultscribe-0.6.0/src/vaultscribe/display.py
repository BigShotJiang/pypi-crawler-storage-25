"""Display commands: show, list, mock-env."""

from __future__ import annotations

import sys

from .codegen import codegen
from .gcloud import _fetch_from_gcloud
from .schema import _generate_mock_secrets, _get_env_config, _parse_schema
from .ui import err_console, out_console, report_error, report_hint
from .vs_types import FlatSecrets, Schema, SecretKey

_LONG_SECRET_THRESHOLD = 12


def _mask(value: str) -> str:
    """Partially reveal a secret value without exposing it in full."""
    if len(value) > _LONG_SECRET_THRESHOLD:
        return f"{value[:4]}...{value[-4:]}"
    return f"{value[0]}...{value[-1]}"


def _show_single_key(key: str, env_vars: FlatSecrets, schema: Schema, reveal: bool) -> None:
    sk = SecretKey(key)
    if sk in env_vars:
        v = str(env_vars[sk])
        if not reveal:
            v = _mask(v)
        out_console.print(f"{key:<35} | {v}")
        return
    all_keys = list(schema.secrets.keys()) + list(schema.public.keys())
    low_key = key.lower()
    suggestion = next((k for k in all_keys if k.lower() == low_key), None)
    if suggestion:
        report_error(f"Key '{key}' not found.")
        report_hint("Action:", f"Did you mean '{suggestion}'?")
    else:
        report_error(f"Key '{key}' not defined in schema.")
    err_console.print()
    sys.exit(1)


def _show_all_keys(schema: Schema, env_vars: FlatSecrets, reveal: bool) -> None:
    for block, label in [
        (schema.secrets, "PRIVATE SECRETS"),
        (schema.public, "PUBLIC CONFIG"),
    ]:
        keys = sorted(block.keys())
        if not keys:
            continue
        err_console.print(f"\n[bold cyan]--- {label} " + "-" * (70 - len(label)) + "[/bold cyan]")
        out_console.print(f"{'KEY':<35} | {'VALUE'}")
        out_console.print("-" * 80)
        for k in keys:
            raw = env_vars.get(SecretKey(k), "")
            if not raw:
                v = "[yellow]<empty>[/yellow]"
            elif not reveal:
                v = _mask(raw)
            else:
                v = raw
            out_console.print(f"{k:<35} | {v}")
    out_console.print()


def _show_cmd(env_name: str, key: str | None = None, show_all: bool = False, reveal: bool = False) -> None:
    """Display Master Vault secrets from GCloud Secret Manager."""
    if not key and not show_all:
        report_error("Please specify a key or use --all to see the full list.")
        report_hint("Info:", f"Targeting environment: [cyan]{env_name}[/cyan]")
        report_hint("Try:", "[green]vs list[/green]            # List all key names")
        report_hint("Try:", "[green]vs show <KEY_NAME>[/green] # Show a specific value")
        report_hint("Info:", "Use --all to show all values.")
        err_console.print()
        return

    codegen(silent=True)
    schema = _parse_schema()
    env_conf = _get_env_config(schema, env_name)
    err_console.print(f"Fetching [bold]{env_conf.slot}[/bold] from GCloud Secret Manager ({env_name})...")
    env_vars = _fetch_from_gcloud(env_conf.project, env_conf.slot, schema)

    if key:
        _show_single_key(key, env_vars, schema, reveal)
        return
    _show_all_keys(schema, env_vars, reveal)


def _list_cmd() -> None:
    """List all secret keys defined in the schema."""
    schema = _parse_schema()
    for block, label in [
        (schema.secrets, "PRIVATE SECRETS"),
        (schema.public, "PUBLIC CONFIG"),
    ]:
        keys = sorted(block.keys())
        if not keys:
            continue
        err_console.print(f"\n[bold cyan]--- {label} " + "-" * (70 - len(label)) + "[/bold cyan]")
        for k in keys:
            out_console.print(f"  {k}")
    out_console.print()


def _mock_env_cmd() -> None:
    """Output a shell-ready string of mock environment variables."""
    schema = _parse_schema()
    secrets = _generate_mock_secrets(schema)
    vars_list = [f"{key}='{val}'" for key, val in secrets.items()]
    out_console.print(" ".join(vars_list))


def _show_details_cmd(key: str) -> None:
    """Show metadata for a single secret key from the schema."""
    schema = _parse_schema()
    all_fields = {**schema.secrets, **schema.public}
    sk = SecretKey(key)
    if sk not in all_fields:
        all_keys = list(all_fields.keys())
        low_key = key.lower()
        match = next((k for k in all_keys if k.lower() == low_key), None)
        if match:
            report_error(f"Key '{key}' not found.")
            report_hint("Action:", f"Did you mean '{match}'?")
        else:
            report_error(f"Key '{key}' not defined in schema.")
        err_console.print()
        sys.exit(1)

    config = all_fields[sk]
    err_console.print(f"\n[bold cyan]{key}[/bold cyan]")
    err_console.print(f"  Description: {config.description or ''}")
    err_console.print(f"  Source:      {config.source or ''}")
    targets = config.sync_targets
    err_console.print(f"  Targets:     {', '.join(targets) if targets else '(none)'}")
    ag = config.auto_generate
    if ag:
        err_console.print(f"  Auto-gen:    {ag.type.value} (length: {ag.length})")
    err_console.print()
