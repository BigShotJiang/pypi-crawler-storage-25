"""High-level schema validation for vaultscribe."""

from __future__ import annotations

import re
from typing import Any

from ..errors import _report_config_error
from ..vs_types import MOCK_ENV, EnvField, GlobalField
from .targets import _validate_each_target


def _validate_envs_block(envs: dict[str, Any]) -> None:
    if not envs:
        _report_config_error("No environments defined in [envs] block.")
    for env_name, env_conf in envs.items():
        if env_name == MOCK_ENV:
            _report_config_error(
                f"'{MOCK_ENV}' is a reserved pseudo-environment name and cannot be used in vaultscribe.toml.",
                key=MOCK_ENV,
                action=f"Rename this environment to something other than '{MOCK_ENV}'.",
            )
        if EnvField.SLOT not in env_conf:
            _report_config_error(
                f"Environment '{env_name}' is missing a 'slot' name.",
                key=env_name,
                action=f'Add `slot = "..."` to [envs.{env_name}].',
            )


def _validate_secret_keys(schema: dict[str, Any]) -> None:
    all_keys = list(schema.get(GlobalField.SECRETS, {}).keys()) + list(schema.get(GlobalField.PUBLIC, {}).keys())
    seen_lower: dict[str, str] = {}
    pattern = re.compile(r"^[A-Za-z0-9._-]+$")

    for key in all_keys:
        if not pattern.match(key):
            _report_config_error(
                f"Invalid characters in secret name '{key}'.",
                key=key,
                action="Secret names must only contain A-Z, a-z, 0-9, '.', '-', and '_'.",
            )

        low = key.lower()
        if low in seen_lower:
            _report_config_error(
                f"Case collision detected for secret '{key}'. Conflicting with '{seen_lower[low]}'.",
                key=key,
                action="Vaultscribe requires all secret names to be unique regardless of case.",
            )
        seen_lower[low] = key


def _validate_schema_structure(schema: dict[str, Any]) -> None:
    """Perform high-level structural validation of the parsed schema."""
    if GlobalField.GCLOUD_PROJECT_ID not in schema:
        _report_config_error(
            "Missing global 'gcloud_project_id'.",
            action='Add `gcloud_project_id = "your-project-id"` to the top of vaultscribe.toml.',
        )

    envs = schema.get(GlobalField.ENVS, {})
    _validate_envs_block(envs)
    _validate_secret_keys(schema)

    targets = schema.get(GlobalField.TARGETS, {})
    if not targets:
        _report_config_error("No targets defined in [targets] block.")

    for t_name, t_conf in targets.items():
        _validate_each_target(t_name, t_conf, schema, envs)
