"""Script target specific validation."""

from __future__ import annotations

from typing import Any

from ...errors import _report_config_error
from ...vs_types import GlobalField, SecretMetaField
from ..common import _parse_sync_target


def _validate_script_target(t_name: str, schema: dict[str, Any]) -> None:
    """Validate script-specific rules for a target."""
    for section in [GlobalField.SECRETS, GlobalField.PUBLIC]:
        for k, config in schema.get(section, {}).items():
            for st_raw in config.sync_targets or []:
                st = _parse_sync_target(st_raw)
                if st.target == t_name and st.delivery is not None:
                    _report_config_error(
                        f"Secret '{k}' references script target '{t_name}' with a delivery qualifier ':{st.delivery}'.",
                        key=k,
                        context=SecretMetaField.SYNC_TARGETS,
                        action=(
                            f"Remove the qualifier — replace '{t_name}:{st.delivery}' with '{t_name}'. "
                            "Script targets inject secrets as plain env vars with no delivery routing."
                        ),
                    )
