"""Cloudflare Pages specific validation."""

from __future__ import annotations

from typing import Any

from ...errors import _report_config_error
from ...vs_types import GlobalField, SecretMetaField, TargetDelivery, TargetField
from ..common import _parse_sync_target


def _validate_cloudflare_target(t_name: str, t_conf: dict[str, Any], schema: dict[str, Any]) -> None:
    """Validate cloudflare_pages-specific rules for a target."""
    all_keys = list(schema.get(GlobalField.SECRETS, {}).keys()) + list(schema.get(GlobalField.PUBLIC, {}).keys())
    all_details = {
        **schema.get(GlobalField.SECRETS, {}),
        **schema.get(GlobalField.PUBLIC, {}),
    }

    has_runtime_keys = any(
        any(
            _parse_sync_target(st).target == t_name and _parse_sync_target(st).delivery == TargetDelivery.RUNTIME
            for st in all_details[k].sync_targets
        )
        for k in all_keys
    )

    if has_runtime_keys and TargetField.RUNTIME_FUNCTION_PATH not in t_conf:
        _report_config_error(
            f"Target '{t_name}' has ':runtime' keys but no 'runtime_function_path'.",
            key=t_name,
            action=(f'Add `runtime_function_path = "functions/vs-config.ts"` to [targets.{t_name}].'),
        )

    for field, example in [
        (TargetField.PROJECT_NAME, 'project_name = "my-pages-project"'),
        (TargetField.AUTH_TOKEN, 'auth_token = "${CLOUDFLARE_API_TOKEN}"'),
        (TargetField.ACCOUNT_ID, 'account_id = "${CLOUDFLARE_ACCOUNT_ID}"'),
    ]:
        if field not in t_conf:
            _report_config_error(
                f"Cloudflare Pages target '{t_name}' is missing mandatory field '{field.value}'.",
                key=t_name,
                action=f"Add `{example}` to [targets.{t_name}].",
            )

    for k, config in schema.get(GlobalField.SECRETS, {}).items():
        for st_raw in config.sync_targets:
            st = _parse_sync_target(st_raw)
            if st.target == t_name:
                _report_config_error(
                    f"Secret '{k}' cannot be synced to Cloudflare Pages target '{t_name}'.",
                    key=k,
                    context=SecretMetaField.SYNC_TARGETS,
                    action=(
                        "Both ':build' and ':runtime' delivery paths expose values to the browser. "
                        "Move this key to [public] if it is safe to expose, or sync it to a "
                        "server-side target instead."
                    ),
                )

    for k, config in schema.get(GlobalField.PUBLIC, {}).items():
        for st_raw in config.sync_targets:
            st = _parse_sync_target(st_raw)
            if st.target == t_name and st.delivery is None:
                _report_config_error(
                    f"Secret '{k}' references cloudflare_pages target '{t_name}' without a delivery qualifier.",
                    key=k,
                    context=SecretMetaField.SYNC_TARGETS,
                    action=(
                        f"Replace '{t_name}' with '{t_name}:build' (baked into JS bundle at build time) "
                        f"or '{t_name}:runtime' (served by Pages Function at request time). "
                        "Cloudflare Pages is a routed target: a delivery qualifier is mandatory."
                    ),
                )
