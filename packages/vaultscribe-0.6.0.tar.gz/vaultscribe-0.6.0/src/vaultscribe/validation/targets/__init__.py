"""Target validation dispatcher."""

from __future__ import annotations

from typing import Any, assert_never

from ...errors import _report_config_error
from ...vs_types import (
    DEPLOYED_TARGET_TYPES,
    VALID_FLAVOURS,
    Flavour,
    TargetField,
    TargetType,
)
from ..flavours import _validate_python_target_keywords, _validate_typescript_target_keywords
from .cloudflare import _validate_cloudflare_target
from .gcloud import _validate_gcloud_run_target
from .github import _validate_github_actions_target
from .script import _validate_script_target


def _validate_deployment_target_fields(t_name: str, t_conf: dict[str, Any], target_type: TargetType) -> None:
    """Validate source, flavour, and flavour compatibility for non-script targets."""
    for field in [TargetField.SOURCE, TargetField.FLAVOUR]:
        if field not in t_conf:
            _report_config_error(
                f"Target '{t_name}' is missing mandatory field '{field.value}'.",
                key=t_name,
                action=f'Add `{field.value} = "..."` to [targets.{t_name}].',
            )

    try:
        target_flavour = Flavour(t_conf[TargetField.FLAVOUR])
    except ValueError:
        _report_config_error(
            f"Unsupported flavour '{t_conf['flavour']}' for target '{t_name}'.",
            key=t_name,
            action=f"Supported values: {', '.join(f.value for f in Flavour)}",
        )

    allowed = VALID_FLAVOURS.get(target_type, [])
    if target_flavour not in allowed:
        valid_str = ", ".join(f"'{f.value}'" for f in allowed)
        _report_config_error(
            f"Target '{t_name}' ({target_type.value}) has invalid flavour '{target_flavour.value}'.",
            key=t_name,
            context=TargetField.FLAVOUR,
            action=f"Supported flavours for {target_type.value}: {valid_str}",
        )

    if target_flavour == Flavour.TYPESCRIPT_VITE and TargetField.OVERLAY in t_conf:
        _report_config_error(
            f"Target '{t_name}' specifies 'overlay', which is not supported for typescript:vite targets.",
            key=t_name,
            context=TargetField.OVERLAY,
            action=(
                "Remove 'overlay' from this target. Vite loads .env.* files natively "
                "from the project root — create .env.development there instead."
            ),
        )


def _validate_each_target(t_name: str, t_conf: dict[str, Any], schema: dict[str, Any], envs: dict[str, Any]) -> None:  # noqa: PLR0912
    if TargetField.TYPE not in t_conf:
        _report_config_error(
            f"Target '{t_name}' is missing mandatory field '{TargetField.TYPE.value}'.",
            key=t_name,
            action=f'Add `{TargetField.TYPE.value} = "..."` to [targets.{t_name}].',
        )

    try:
        target_type = TargetType(t_conf[TargetField.TYPE])
    except ValueError:
        _report_config_error(
            f"Unsupported type '{t_conf['type']}' for target '{t_name}'.",
            key=t_name,
            action=f"Supported values: {', '.join(t.value for t in TargetType)}",
        )

    if target_type in DEPLOYED_TARGET_TYPES:
        _validate_deployment_target_fields(t_name, t_conf, target_type)
        flavour = Flavour(t_conf[TargetField.FLAVOUR])
        match flavour:
            case Flavour.PYTHON_PYDANTIC:
                _validate_python_target_keywords(t_name, schema)
            case Flavour.TYPESCRIPT_VITE:
                _validate_typescript_target_keywords(t_name, schema)
            case _:
                assert_never(flavour)

    match target_type:
        case TargetType.CLOUDFLARE_PAGES:
            _validate_cloudflare_target(t_name, t_conf, schema)
        case TargetType.GCLOUD_RUN:
            _validate_gcloud_run_target(t_name, schema)
        case TargetType.SCRIPT:
            _validate_script_target(t_name, schema)
        case TargetType.GITHUB_ACTIONS:
            _validate_github_actions_target(t_name, t_conf, schema, list(envs.keys()))

    for key, val in t_conf.items():
        if isinstance(val, dict) and key not in envs:
            if len(val) == 1:
                member_key = next(iter(val.keys()))
                action = f"Remove 'targets.{t_name}.{key}.{member_key}' or define [envs.{key}] in vaultscribe.toml."
            else:
                action = f"Remove '[targets.{t_name}.{key}]' or define [envs.{key}] in vaultscribe.toml."
            _report_config_error(
                f"Target '{t_name}' has an override for undefined environment '{key}'.",
                key=t_name,
                context=key,
                action=action,
            )
