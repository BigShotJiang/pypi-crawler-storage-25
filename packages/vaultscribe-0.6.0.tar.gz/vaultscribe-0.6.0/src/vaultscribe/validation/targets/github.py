"""GitHub Actions specific validation."""

from __future__ import annotations

from typing import Any

from ...errors import _report_config_error
from ...vs_types import GlobalField, SecretMetaField, TargetField
from ..common import _fuzzy_match_env, _parse_sync_target


def _resolve_github_actions_vs_env(
    t_name: str,
    t_conf: dict[str, Any],
    env_names: list[str],
) -> str:
    """Resolve which vs env a github_actions target binds to."""
    explicit = t_conf.get(TargetField.VS_ENV)
    if explicit is not None:
        if explicit not in env_names:
            available = ", ".join(f"'{e}'" for e in env_names) or "<none>"
            _report_config_error(
                f"github_actions target '{t_name}' has vs_env='{explicit}' which is not a defined environment.",
                key=t_name,
                context=TargetField.VS_ENV,
                action=f"Available environments: {available}.",
            )
        return str(explicit)

    environment = t_conf.get(TargetField.ENVIRONMENT)
    if environment is not None:
        environment_str = str(environment)
        if environment_str in env_names:
            return environment_str
        for e in env_names:
            if e.lower() == environment_str.lower():
                return e
        suggestion = _fuzzy_match_env(environment_str, env_names)
        if suggestion is not None:
            _report_config_error(
                f"github_actions target '{t_name}' has environment='{environment_str}' "
                f"but no [envs.{environment_str}] is defined.",
                key=t_name,
                context=TargetField.ENVIRONMENT,
                action=(
                    f"Did you mean vs env '{suggestion}'? Add `vs_env = \"{suggestion}\"` "
                    f"to [targets.{t_name}] to bind this target to the '{suggestion}' env."
                ),
            )
        available = ", ".join(f"'{e}'" for e in env_names) or "<none>"
        _report_config_error(
            f"github_actions target '{t_name}' has environment='{environment_str}' but no matching vs env was found.",
            key=t_name,
            context=TargetField.ENVIRONMENT,
            action=(f'Add `vs_env = "..."` to [targets.{t_name}] to bind it to a vs env. Available envs: {available}.'),
        )

    available = ", ".join(f"'{e}'" for e in env_names) or "<none>"
    _report_config_error(
        f"github_actions target '{t_name}' must declare either 'vs_env' or 'environment'.",
        key=t_name,
        action=(
            f'Add `vs_env = "..."` (the vs env name to sync from) or `environment = "..."` '
            f"(the GitHub environment name; vs will infer vs_env from it). "
            f"Available envs: {available}."
        ),
    )


def _validate_github_actions_target(
    t_name: str,
    t_conf: dict[str, Any],
    schema: dict[str, Any],
    env_names: list[str],
) -> None:
    """Validate github_actions-specific rules for a target."""
    if TargetField.REPO not in t_conf:
        _report_config_error(
            f"github_actions target '{t_name}' is missing mandatory field 'repo'.",
            key=t_name,
            action=f'Add `repo = "owner/repo"` to [targets.{t_name}].',
        )

    for section in [GlobalField.SECRETS, GlobalField.PUBLIC]:
        for k, config in schema.get(section, {}).items():
            for st_raw in config.sync_targets or []:
                st = _parse_sync_target(st_raw)
                if st.target == t_name and st.delivery is not None:
                    _report_config_error(
                        f"Secret '{k}' references github_actions target '{t_name}' "
                        f"with a delivery qualifier ':{st.delivery}'.",
                        key=k,
                        context=SecretMetaField.SYNC_TARGETS,
                        action=(
                            f"Remove the qualifier — replace '{t_name}:{st.delivery}' with '{t_name}'. "
                            "GitHub Actions targets store secrets/variables flat with no delivery routing."
                        ),
                    )

    _resolve_github_actions_vs_env(t_name, t_conf, env_names)
