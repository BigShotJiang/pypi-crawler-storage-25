"""Common validation helpers for vaultscribe."""

from __future__ import annotations

import sys

from ..ui import ErrorCategory, err_console, report_error, report_hint
from ..vs_types import SyncTarget, TargetDelivery


def _parse_sync_target(raw: str) -> SyncTarget:
    """Parse a sync_targets entry like 'target_name' or 'target_name:delivery'."""
    if ":" in raw:
        name, _, delivery_str = raw.partition(":")
        try:
            return SyncTarget(target=name, delivery=TargetDelivery(delivery_str))
        except ValueError:
            valid = ", ".join(f":{d.value}" for d in TargetDelivery)
            report_error(
                f"Unknown delivery qualifier ':{delivery_str}' in sync target '{raw}'.",
                category=ErrorCategory.CONFIG,
            )
            report_hint("Valid:", valid)
            err_console.print()
            sys.exit(1)
    return SyncTarget(target=raw, delivery=None)


def _fuzzy_match_env(environment: str, env_names: list[str]) -> str | None:
    """Best-effort match of a GitHub environment name to a known vs env."""
    env_low = environment.lower()
    for vs_env in env_names:
        vs_low = vs_env.lower()
        if env_low == vs_low:
            continue
        if env_low.startswith(vs_low) or vs_low.startswith(env_low):
            return vs_env
    return None
