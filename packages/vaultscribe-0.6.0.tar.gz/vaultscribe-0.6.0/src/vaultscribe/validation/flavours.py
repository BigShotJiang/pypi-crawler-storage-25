"""Flavour-specific validation for vaultscribe (e.g., Python/TS keywords)."""

from __future__ import annotations

import keyword
from typing import Any

from ..errors import _report_config_error
from ..utils import to_camel_case, to_snake_case
from ..vs_types import GlobalField
from .common import _parse_sync_target

_TS_KEYWORDS = {
    "break",
    "case",
    "catch",
    "class",
    "const",
    "continue",
    "debugger",
    "default",
    "delete",
    "do",
    "else",
    "enum",
    "export",
    "extends",
    "false",
    "finally",
    "for",
    "function",
    "if",
    "import",
    "in",
    "instanceof",
    "new",
    "null",
    "return",
    "super",
    "switch",
    "this",
    "throw",
    "true",
    "try",
    "typeof",
    "var",
    "void",
    "while",
    "with",
    "yield",
    "await",
    "let",
    "static",
    "implements",
    "interface",
    "package",
    "private",
    "protected",
    "public",
}


def _validate_python_target_keywords(t_name: str, schema: dict[str, Any]) -> None:
    """Ensure no secret synced to a Python target uses a Python keyword."""
    for section in [GlobalField.SECRETS, GlobalField.PUBLIC]:
        for k, config in schema.get(section, {}).items():
            for st_raw in config.sync_targets or []:
                st = _parse_sync_target(st_raw)
                if st.target == t_name:
                    snake = to_snake_case(k)
                    bad = None
                    if keyword.iskeyword(k):
                        bad = k
                    elif keyword.iskeyword(snake):
                        bad = snake

                    if bad:
                        _report_config_error(
                            f"Target '{t_name}' cannot use Python keyword '{bad}' as a secret name.",
                            key=k,
                            action=(
                                f"Rename the secret '{k}' to something that is not a Python keyword "
                                "(including its snake_case version)."
                            ),
                        )


def _validate_typescript_target_keywords(t_name: str, schema: dict[str, Any]) -> None:
    """Ensure no secret synced to a TypeScript target uses a TypeScript keyword."""
    for section in [GlobalField.SECRETS, GlobalField.PUBLIC]:
        for k, config in schema.get(section, {}).items():
            for st_raw in config.sync_targets or []:
                st = _parse_sync_target(st_raw)
                if st.target == t_name:
                    camel = to_camel_case(k)
                    bad = None
                    if k.lower() in _TS_KEYWORDS:
                        bad = k.lower()
                    elif camel.lower() in _TS_KEYWORDS:
                        bad = camel.lower()

                    if bad:
                        _report_config_error(
                            f"Target '{t_name}' cannot use TypeScript keyword '{bad}' as a secret name.",
                            key=k,
                            action=(
                                f"Rename the secret '{k}' to something that is not a TypeScript keyword "
                                "(including its camelCase version)."
                            ),
                        )
