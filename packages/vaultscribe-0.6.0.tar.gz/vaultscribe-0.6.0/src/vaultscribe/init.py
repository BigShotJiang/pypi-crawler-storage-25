"""Interactive project scaffolding (vs init)."""

from __future__ import annotations

import sys
from pathlib import Path

from .init_prompts import (
    _prompt_another_target,
    _prompt_configure_targets,
    _prompt_envs,
    _prompt_project_id,
    _prompt_slot_base,
    _prompt_target_config,
)
from .init_toml import _generate_vaultscribe_toml
from .shell import _ensure_secrets_ignored
from .ui import err_console, report_error, report_hint
from .vs_types import _REPO_ROOT, _SCHEMA_FILE, GcloudRunTargetConfig, TargetConfig


def _create_overlays(targets_data: dict[str, TargetConfig]) -> None:
    for t_name, t_conf in targets_data.items():
        if not isinstance(t_conf, GcloudRunTargetConfig) or not t_conf.overlay:
            continue
        try:
            overlay_path = _REPO_ROOT / t_conf.source / t_conf.overlay
            if not overlay_path.exists():
                header = f"# {t_conf.overlay} — LOCAL OVERRIDES for {t_name} (dev).\n"
                header += "# Values here win over GCloud Secret Manager values.\n"
                header += "# Use this for localhost URLs, emulator config, etc.\n\n"
                overlay_path.write_text(header)
                err_console.print(f"[bold green]✔︎ Created overlay {overlay_path.relative_to(_REPO_ROOT)}[/bold green]")
        except Exception as e:
            err_console.print(f"Warning: Could not create overlay for {t_name}: {e}")


def _print_next_steps(envs: list[str], targets_data: dict[str, TargetConfig]) -> None:
    err_console.print("\n[bold cyan]Vaultscribe initialisation complete![/bold cyan]")
    err_console.print("\nNext Steps:")
    step = 1
    err_console.print(f"  {step}. Edit [cyan]vaultscribe.toml[/cyan] to define your secrets schema.")
    step += 1
    err_console.print(f"  {step}. Run [green]vs shell[/green] to start a secure 1-hour GCloud session.")
    step += 1
    for env in envs:
        err_console.print(f"  {step}. Run [green]vs pull {env}[/green] to generate a local secrets file to fill in.")
        step += 1
        overlays = [
            t_conf.source + t_conf.overlay
            for t_conf in targets_data.values()
            if isinstance(t_conf, GcloudRunTargetConfig) and t_conf.overlay is not None
        ]
        if overlays and env == "dev":
            for o in overlays:
                err_console.print(f"     Also fill in [cyan]{o}[/cyan] with any localhost overrides.")
        err_console.print(
            f"  {step}. Run [green]vs push {env}[/green] to upload your secrets and seed the infrastructure.\n"
        )
        step += 1


def _init_cmd() -> None:
    """Scaffold a new Vaultscribe project."""
    if (_REPO_ROOT / "vaultscribe.toml").exists():
        report_error("vaultscribe.toml already exists.")
        report_hint("Action:", "If you want to start fresh, delete or move vaultscribe.toml first.")
        report_hint("Info:", "Otherwise, use 'vs pull', 'vs codegen', or 'vs rotate' to manage")
        report_hint("Info:", "the current install.")
        err_console.print()
        sys.exit(1)

    err_console.print("\n[bold cyan]🚀 Welcome to Vaultscribe Initialisation[/bold cyan]")

    project_id = _prompt_project_id()
    if project_id is None:
        err_console.print("\nInitialisation aborted.")
        sys.exit(0)

    suggested_base = Path.cwd().name.replace("_", "-")
    suggested_slot = suggested_base + "-secrets"
    slot_base = _prompt_slot_base(suggested_slot)
    if slot_base is None:
        err_console.print("\nInitialisation aborted.")
        sys.exit(0)

    envs = _prompt_envs()
    if envs is None:
        err_console.print("\nInitialisation aborted.")
        sys.exit(0)
    if not envs:
        report_error("You must select at least one environment.")
        err_console.print()
        sys.exit(1)

    sys.stdout.write("\033[F\033[K")
    err_console.print(
        f"[bold cyan]? Which environments do you need? done ({', '.join(f'{e!r}' for e in envs)})[/bold cyan]"
    )

    configure_targets = _prompt_configure_targets()
    if configure_targets is None:
        err_console.print("\nInitialisation aborted.")
        sys.exit(0)

    targets_data: dict[str, TargetConfig] = {}
    if configure_targets:
        while True:
            t_conf = _prompt_target_config(suggested_base, envs)
            if t_conf is None:
                err_console.print("\nInitialisation aborted.")
                sys.exit(0)
            targets_data[t_conf.name] = t_conf
            if not _prompt_another_target():
                break

    toml_content = _generate_vaultscribe_toml(project_id, slot_base, envs, targets_data, suggested_base)
    _SCHEMA_FILE.write_text(toml_content)

    err_console.print(f"\n[bold green]✔︎ Created {_SCHEMA_FILE.name}[/bold green]")

    _create_overlays(targets_data)
    _ensure_secrets_ignored()
    _print_next_steps(envs, targets_data)
