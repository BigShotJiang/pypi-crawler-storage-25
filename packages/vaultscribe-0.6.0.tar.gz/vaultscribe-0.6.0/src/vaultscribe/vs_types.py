"""Shared Enums and module-level constants for Vaultscribe."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum, unique
from pathlib import Path
from typing import Final, Literal, NamedTuple, NewType

__all__ = [
    "DEPLOYED_TARGET_TYPES",
    "MOCK_ENV",
    "VALID_FLAVOURS",
    "AutoGenerateConfig",
    "AutoGenerateType",
    "CloudflareEnvOverride",
    "CloudflarePagesTargetConfig",
    "EnvConfig",
    "EnvName",
    "FlatSecrets",
    "Flavour",
    "GcloudRunTargetConfig",
    "GitHubActionsTargetConfig",
    "Namespace",
    "Schema",
    "ScriptTargetConfig",
    "SecretConfig",
    "SecretKey",
    "Sensitivity",
    "SyncTarget",
    "TargetConfig",
    "TargetDelivery",
    "TargetName",
    "TargetType",
]

_REPO_ROOT = Path.cwd()
_SCHEMA_FILE = _REPO_ROOT / "vaultscribe.toml"

MOCK_ENV: Final[str] = "mock"

EnvName = NewType("EnvName", str)
SecretKey = NewType("SecretKey", str)
TargetName = NewType("TargetName", str)
FlatSecrets = NewType("FlatSecrets", dict[SecretKey, str])


@dataclass(frozen=True)
class EnvConfig:
    project: str
    slot: str


@unique
class Flavour(StrEnum):
    """Supported code generation and injection styles."""

    PYTHON_PYDANTIC = "python:pydantic"
    TYPESCRIPT_VITE = "typescript:vite"


@unique
class TargetType(StrEnum):
    """Supported infrastructure target types."""

    GCLOUD_RUN = "gcloud_run"
    CLOUDFLARE_PAGES = "cloudflare_pages"
    SCRIPT = "script"
    GITHUB_ACTIONS = "github_actions"


@dataclass(frozen=True)
class CloudflareEnvOverride:
    """Per-environment overrides for a cloudflare_pages target's mutable config."""

    project_name: str | None = None
    auth_token: str | None = None
    account_id: str | None = None


@dataclass(frozen=True)
class GcloudRunTargetConfig:
    """A target deploying secrets via GCloud Run's --set-secrets bundle."""

    name: str
    source: str
    flavour: Flavour
    secrets_env_var: str
    overlay: str | None = None
    type: Literal[TargetType.GCLOUD_RUN] = TargetType.GCLOUD_RUN


@dataclass(frozen=True)
class CloudflarePagesTargetConfig:
    """A target syncing build- and runtime-time values to Cloudflare Pages."""

    name: str
    source: str
    flavour: Flavour
    project_name: str
    auth_token: str
    account_id: str
    runtime_function_path: str | None = None
    env_overrides: tuple[tuple[str, CloudflareEnvOverride], ...] = ()
    type: Literal[TargetType.CLOUDFLARE_PAGES] = TargetType.CLOUDFLARE_PAGES

    def project_name_for_env(self, env_name: str) -> str:
        for env, override in self.env_overrides:
            if env == env_name and override.project_name is not None:
                return override.project_name
        return self.project_name

    def auth_token_for_env(self, env_name: str) -> str:
        for env, override in self.env_overrides:
            if env == env_name and override.auth_token is not None:
                return override.auth_token
        return self.auth_token

    def account_id_for_env(self, env_name: str) -> str:
        for env, override in self.env_overrides:
            if env == env_name and override.account_id is not None:
                return override.account_id
        return self.account_id


@dataclass(frozen=True)
class ScriptTargetConfig:
    """A named subset of secrets injected into local CLI invocations only."""

    name: str
    type: Literal[TargetType.SCRIPT] = TargetType.SCRIPT


@dataclass(frozen=True)
class GitHubActionsTargetConfig:
    """A target syncing secrets/variables to a GitHub repo for CI/CD consumption.

    `vs_env` is always set after parsing — either explicitly in the toml or
    inferred from `environment` matching a known vs env name.
    """

    name: str
    repo: str
    vs_env: str
    environment: str | None = None
    type: Literal[TargetType.GITHUB_ACTIONS] = TargetType.GITHUB_ACTIONS


type TargetConfig = GcloudRunTargetConfig | CloudflarePagesTargetConfig | ScriptTargetConfig | GitHubActionsTargetConfig


# List of supported flavours for each deploy target type
VALID_FLAVOURS: Final[dict[TargetType, list[Flavour]]] = {
    TargetType.GCLOUD_RUN: [Flavour.PYTHON_PYDANTIC],
    TargetType.CLOUDFLARE_PAGES: [Flavour.TYPESCRIPT_VITE],
    TargetType.SCRIPT: [],
    TargetType.GITHUB_ACTIONS: [],
}

# Target types that deploy to infrastructure and therefore require source + flavour.
DEPLOYED_TARGET_TYPES: Final[frozenset[TargetType]] = frozenset(
    {
        TargetType.GCLOUD_RUN,
        TargetType.CLOUDFLARE_PAGES,
    }
)


@unique
class TargetDelivery(StrEnum):
    """How a value is delivered to a cloudflare_pages target.

    BUILD:   baked into the JS bundle at build time (injected as VITE_* env var).
    RUNTIME: served by the generated Pages Function at request time.
    """

    BUILD = "build"
    RUNTIME = "runtime"


class SyncTarget(NamedTuple):
    """Parsed representation of a single sync_targets entry."""

    target: str
    delivery: TargetDelivery | None


@unique
class AutoGenerateType(StrEnum):
    """Supported auto-generation algorithms."""

    HEX = "hex"


@dataclass(frozen=True)
class AutoGenerateConfig:
    """Strict configuration for an auto-generated secret."""

    type: AutoGenerateType
    length: int


@dataclass(frozen=True)
class SecretConfig:
    """Strict configuration for a single secret key from vaultscribe.toml."""

    description: str | None
    source: str | None
    sync_targets: list[str] | None
    auto_generate: AutoGenerateConfig | None


@unique
class Namespace(StrEnum):
    """Namespaces for the secret bundle."""

    SECRET = "secret"  # noqa: S105
    PUBLIC = "public"


@unique
class Sensitivity(StrEnum):
    """Namespaces for the secret bundle."""

    SECRET = "SECRET"  # noqa: S105
    PUBLIC = "PUBLIC"


@unique
class GlobalField(StrEnum):
    GCLOUD_PROJECT_ID = "gcloud_project_id"
    ENVS = "envs"
    TARGETS = "targets"
    SECRETS = "secrets"
    PUBLIC = "public"


@unique
class EnvField(StrEnum):
    SLOT = "slot"


@unique
class TargetField(StrEnum):
    TYPE = "type"
    SOURCE = "source"
    FLAVOUR = "flavour"
    OVERLAY = "overlay"
    PROJECT_NAME = "project_name"
    AUTH_TOKEN = "auth_token"  # noqa: S105
    ACCOUNT_ID = "account_id"
    SECRETS_ENV_VAR = "secrets_env_var"
    RUNTIME_FUNCTION_PATH = "runtime_function_path"
    REPO = "repo"
    ENVIRONMENT = "environment"
    VS_ENV = "vs_env"


@unique
class SecretMetaField(StrEnum):
    DESCRIPTION = "description"
    SOURCE = "source"
    SYNC_TARGETS = "sync_targets"
    AUTO_GENERATE = "auto_generate"


@unique
class Command(StrEnum):
    """All top-level vs CLI commands.

    Keep docs/commands.md in sync when adding, removing, or renaming members.
    """

    INIT = "init"
    PARSE_TEST = "parse-test"
    CODEGEN = "codegen"
    MOCK_ENV = "mock-env"
    PULL = "pull"
    PUSH = "push"
    SYNC = "sync"
    LIST = "list"
    SHOW = "show"
    ROTATE = "rotate"
    SHELL = "shell"
    RUN = "run"


@dataclass(frozen=True)
class Schema:
    """Fully-typed, validated representation of vaultscribe.toml."""

    project: str
    environments: dict[EnvName, EnvConfig]
    secrets: dict[SecretKey, SecretConfig]
    public: dict[SecretKey, SecretConfig]
    targets: dict[TargetName, TargetConfig]
