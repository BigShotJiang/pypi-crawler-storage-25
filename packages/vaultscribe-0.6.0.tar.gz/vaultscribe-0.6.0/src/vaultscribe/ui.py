"""Terminal styling utilities for Vaultscribe."""

from __future__ import annotations

from enum import Enum

import questionary
from rich.console import Console


class ErrorCategory(Enum):
    """Categories for standardized error reporting."""

    CONFIG = "CONFIG"
    CODEGEN = "CODEGEN"
    GCLOUD = "GCLOUD"
    AUTH = "AUTH"
    CLOUDFLARE = "CLOUDFLARE"
    INTERNAL = "INTERNAL"


# Custom style to avoid terminal "inversion". Yuck.
_VS_STYLE = questionary.Style(
    [
        ("qmark", "fg:cyan bold"),
        ("question", "bold"),
        ("pointer", "fg:cyan bold"),
        ("highlighted", "fg:cyan noreverse bg:default"),
        ("selected", "bold noreverse bg:default"),
        ("checked", "fg:green bold"),
        ("answer", "fg:cyan bold"),
    ]
)

# Shared console for all CLI output.
# out_console for standard output (piping).
# err_console for chat, errors, and warnings.
out_console = Console()
err_console = Console(stderr=True)

_HINT_INDENT = 4
_HINT_LABEL_WIDTH = 14


def report_error(message: str, category: ErrorCategory | None = None) -> None:
    """Prints the standardised bold red error header with icon.

    Does NOT exit.
    """
    prefix = f"{category.value} " if category else ""
    err_console.print(f"\n[bold red]❌ {prefix}ERROR: {message}[/bold red]")


def report_warning(message: str) -> None:
    """Prints the standardised bold yellow warning header with icon.

    Does NOT exit.
    """
    err_console.print(f"\n[bold yellow]⚠️  WARNING: {message}[/bold yellow]")


def report_hint(label: str, content: str) -> None:
    """Prints a standardised 'hint' line (e.g. Action, Example, Available).

    Uses consistent indentation for clean UI.
    """
    err_console.print(f"{' ' * _HINT_INDENT}[bold]{label:{_HINT_LABEL_WIDTH}}[/bold] {content}")


def report_list_item(content: str) -> None:
    """Prints a list item aligned with report_hint content."""
    # 1 space for the gap between label and content
    indent = _HINT_INDENT + _HINT_LABEL_WIDTH + 1
    err_console.print(f"{' ' * indent}- {content}")
