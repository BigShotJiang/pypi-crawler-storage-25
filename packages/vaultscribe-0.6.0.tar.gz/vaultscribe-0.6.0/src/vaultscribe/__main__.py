from vaultscribe.cli import main

main()
