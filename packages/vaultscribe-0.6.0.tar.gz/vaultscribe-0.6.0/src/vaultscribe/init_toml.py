"""TOML generation for Vaultscribe initialisation."""

from __future__ import annotations

import json
from typing import assert_never

from .vs_types import (
    CloudflarePagesTargetConfig,
    Flavour,
    GcloudRunTargetConfig,
    GitHubActionsTargetConfig,
    ScriptTargetConfig,
    TargetConfig,
    TargetType,
)


def _generate_target_lines(t_name: str, t_conf: TargetConfig, slot_base: str) -> list[str]:
    lines: list[str] = [f"[targets.{t_name}]", f'type = "{t_conf.type}"']
    match t_conf:
        case GcloudRunTargetConfig():
            lines.append(f'source = "{t_conf.source}"')
            lines.append(f'flavour = "{t_conf.flavour}"')
            secrets_env_var = slot_base.upper().replace("-", "_")
            lines.append("# Add the following to your GCloud Run deploy commmand:")
            lines.append(f'#     --set-secrets="{secrets_env_var}={slot_base}-prod:latest"')
            lines.append(f'secrets_env_var = "{secrets_env_var}"')
            if t_conf.overlay:
                lines.append(f'overlay = "{t_conf.overlay}"')
        case CloudflarePagesTargetConfig():
            lines.append(f'source = "{t_conf.source}"')
            lines.append(f'flavour = "{t_conf.flavour}"')
            lines.extend(
                [
                    f'project_name = "{t_conf.project_name}"',
                    'auth_token = "${CLOUDFLARE_API_TOKEN}"',
                    'account_id = "${CLOUDFLARE_ACCOUNT_ID}"',
                ]
            )
            if t_conf.runtime_function_path:
                lines.extend(
                    [
                        "# Call `await vsLoadConfig()` in your app's entry point before importing",
                        "# any modules that depend on window.VS_CONFIG (e.g. Firebase init).",
                        f'runtime_function_path = "{t_conf.runtime_function_path}"',
                    ]
                )
            if t_conf.flavour == Flavour.TYPESCRIPT_VITE:
                lines.append(
                    "# Dev overrides: create .env.development in the Vite project root"
                    " (the directory containing vite.config.*)."
                )
                lines.append(
                    "# As Vite loads .env.* files natively — a Vaultscribe 'overlay' is not applicable"
                    " for typescript:vite targets."
                )
        case ScriptTargetConfig():
            pass
        case GitHubActionsTargetConfig():
            lines.append(f'repo = "{t_conf.repo}"')
            if t_conf.environment is not None:
                lines.append(f'environment = "{t_conf.environment}"')
            lines.append(f'vs_env = "{t_conf.vs_env}"')
        case _:
            assert_never(t_conf)
    lines.append("")
    return lines


def _generate_targets_section(targets_data: dict[str, TargetConfig], slot_base: str) -> list[str]:
    if not targets_data:
        return [
            "# No targets configured. Examples:",
            "# [targets.backend]",
            f'# type = "{TargetType.GCLOUD_RUN}"',
            '# source = "api/"',
            f'# flavour = "{Flavour.PYTHON_PYDANTIC}"',
            f'# secrets_env_var = "{slot_base.upper().replace("-", "_")}"',
            "",
            "# [targets.frontend]",
            f'# type = "{TargetType.CLOUDFLARE_PAGES}"',
            '# source = "app/src/"',
            f'# flavour = "{Flavour.TYPESCRIPT_VITE}"',
            "",
            "# [targets.gh_prod]   # syncs [secrets] -> GH Secrets, [public] -> GH Variables",
            f'# type = "{TargetType.GITHUB_ACTIONS}"',
            '# repo = "owner/repo"',
            '# environment = "production"   # optional GitHub environment scope',
            '# vs_env = "prod"              # optional; inferred from `environment` if it matches a vs env name',
            "",
        ]
    lines: list[str] = []
    for t_name, t_conf in targets_data.items():
        lines.extend(_generate_target_lines(t_name, t_conf, slot_base))
    return lines


def _generate_vaultscribe_toml(
    project_id: str,
    slot_base: str,
    envs: list[str],
    targets_data: dict[str, TargetConfig],
    suggested_base: str,
) -> str:
    toml_lines = [
        "# vaultscribe.toml (Requires TOML v1.1 parser)",
        "",
        "# ==========================================",
        "# INFRASTRUCTURE GLOBAL",
        "# ==========================================",
        f'gcloud_project_id = "{project_id}"',
        "",
    ]

    for env in envs:
        toml_lines.append(f"[envs.{env}]")
        if env == "dev":
            share_with = "staging" if "staging" in envs else "prod" if "prod" in envs else "dev"
            comment = (
                "  # Shares staging values"
                if share_with == "staging"
                else "  # Shares prod values"
                if share_with == "prod"
                else ""
            )
            toml_lines.append(f'slot = "{slot_base}-{share_with}"{comment}')
        else:
            toml_lines.append(f'slot = "{slot_base}-{env}"')
        toml_lines.append("")

    toml_lines.extend(
        [
            "# ==========================================",
            "# TARGETS (Code Consumers)",
            "# ==========================================",
        ]
    )

    cloudflare_targets = [name for name, conf in targets_data.items() if conf.type == TargetType.CLOUDFLARE_PAGES]
    toml_lines.extend(_generate_targets_section(targets_data, slot_base))

    target_list = list(targets_data.keys())
    primary_target = target_list[0] if target_list else "backend"

    toml_lines.extend(
        [
            "# ==========================================",
            "# SAMPLE SECRETS (Edit to define your schema)",
            "# 'description' and 'source' are optional, but recommended.",
            "# ==========================================",
            "",
            "[secrets.AdMiN_SeCrEt] # Example: case preservation and auto-generation",
            'description = "Authenticates admin endpoints."',
            "# For an 'autogenerate' secret, you must provide a 'type' and 'length'.",
            "# 'type' can be 'hex', 'base64', or 'string'.",
            "# 'length' is the length of the generated secret.",
            'auto_generate = { type = "hex", length = 32 }',
            f'sync_targets = ["{primary_target}"]',
            "",
            "[secrets.DATABASE_URL]",
            'description = "Primary database connection string."',
            'source = "Obtain from your database provider console."',
            f'sync_targets = ["{primary_target}"]',
            "",
        ]
    )

    if cloudflare_targets:
        toml_lines.extend(
            [
                "# Cloudflare Deployment Credentials (CLI-only — not synced to any target)",
                "[secrets.CLOUDFLARE_API_TOKEN]",
                'description = "Cloudflare API token for deployment."',
                'source = "Obtain from Cloudflare Dashboard."',
                "sync_targets = []",
                "",
                "[secrets.CLOUDFLARE_ACCOUNT_ID]",
                'description = "Cloudflare Account ID."',
                'source = "Found in the URL of your Cloudflare Dashboard."',
                "sync_targets = []",
                "",
            ]
        )

    # Build a qualified sync_targets list for sample public config.
    # cloudflare_pages targets need a ':build' qualifier; others are plain names.
    cf_target_set = set(cloudflare_targets)
    qualified_target_list = [f"{t}:build" if t in cf_target_set else t for t in target_list]

    toml_lines.extend(
        [
            "# ==========================================",
            "# SAMPLE PUBLIC CONFIG",
            "# ==========================================",
            "",
            "[public.PUBLIC_API_URL]",
            'description = "The public URL of the backend API."',
            'source = "Determined by your deployment environment."',
            "sync_targets = " + json.dumps(qualified_target_list) if qualified_target_list else "sync_targets = []",
        ]
    )

    return "\n".join(toml_lines) + "\n"
