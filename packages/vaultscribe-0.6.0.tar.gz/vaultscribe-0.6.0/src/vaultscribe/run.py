"""Zero-disk command execution with secrets injected per target type."""

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import assert_never

from .gcloud import _fetch_from_gcloud
from .schema import (
    _generate_mock_secrets,
    _get_env_config,
    _get_target_config,
    _parse_schema,
    _parse_sync_target,
)
from .ui import err_console
from .vs_types import (
    _REPO_ROOT,
    MOCK_ENV,
    CloudflarePagesTargetConfig,
    FlatSecrets,
    GcloudRunTargetConfig,
    GitHubActionsTargetConfig,
    Namespace,
    Schema,
    ScriptTargetConfig,
    SecretKey,
    TargetDelivery,
)


def _inject_script(
    schema: Schema,
    env_vars: FlatSecrets,
    target_name: str,
    flat_env: dict[str, str],
) -> None:
    for block in [schema.secrets, schema.public]:
        for key, config in block.items():
            if SecretKey(key) not in env_vars:
                continue
            for st in config.sync_targets or []:
                parsed = _parse_sync_target(st)
                if parsed.target == target_name:
                    flat_env[key] = str(env_vars[SecretKey(key)])


def _build_bundle_json(schema: Schema, env_vars: FlatSecrets) -> str:
    """Pack env_vars into the namespaced JSON bundle format expected by _BundleSource."""
    secret_part: dict[str, str] = {}
    public_part: dict[str, str] = {}
    for key, val in env_vars.items():
        if SecretKey(key) in schema.public:
            public_part[key] = val
        elif SecretKey(key) in schema.secrets:
            secret_part[key] = val
    return json.dumps({Namespace.SECRET: secret_part, Namespace.PUBLIC: public_part})


def _read_overlay(path: Path) -> dict[str, str]:
    """Read all key=value pairs from a .env file, including non-schema keys."""
    result: dict[str, str] = {}
    for line in path.read_text().splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key, _, value = stripped.partition("=")
        result[key.strip()] = value.strip()
    return result


def _inject_gcloud_run(
    schema: Schema,
    env_vars: FlatSecrets,
    target: GcloudRunTargetConfig,
    flat_env: dict[str, str],
) -> None:
    flat_env[target.secrets_env_var] = _build_bundle_json(schema, env_vars)
    if target.overlay:
        overlay_path = _REPO_ROOT / target.source / target.overlay
        if overlay_path.exists():
            flat_env.update(_read_overlay(overlay_path))


def _inject_cloudflare_pages(
    schema: Schema,
    env_vars: FlatSecrets,
    target: CloudflarePagesTargetConfig,
    flat_env: dict[str, str],
) -> None:
    for block in [schema.secrets, schema.public]:
        for key, config in block.items():
            if SecretKey(key) not in env_vars:
                continue
            for st in config.sync_targets or []:
                parsed = _parse_sync_target(st)
                if parsed.target != target.name:
                    continue
                if parsed.delivery == TargetDelivery.BUILD:
                    # Baked into the bundle by Vite at build time.
                    flat_env[f"VITE_{key}"] = str(env_vars[SecretKey(key)])
                elif parsed.delivery == TargetDelivery.RUNTIME:
                    # Served by the mock /vs-config middleware in dev,
                    # mirroring what the Pages Function does in production.
                    flat_env[key] = str(env_vars[SecretKey(key)])


def _run_command(env_name: str, target_name: str | None, command_args: list[str]) -> None:
    """Execute a command with secrets injected according to the target type.

    gcloud_run target:  injects the JSON bundle (matching Cloud Run behaviour)
                        plus overlay vars as individual env vars.
    cloudflare_pages:   injects VITE_-prefixed :build vars and plain :runtime vars.
    script / github_actions: injects only sync_targets-scoped keys as plain env vars.
    No target:          injects all secrets as individual env vars (for tooling
                        and tests that don't correspond to a specific target).
    """
    schema = _parse_schema()
    if env_name == MOCK_ENV:
        env_vars = _generate_mock_secrets(schema)
    else:
        env_conf = _get_env_config(schema, env_name)
        env_vars = _fetch_from_gcloud(env_conf.project, env_conf.slot, schema)

    flat_env: dict[str, str] = {**os.environ}

    if target_name:
        target = _get_target_config(schema, target_name)
        match target:
            case GcloudRunTargetConfig():
                _inject_gcloud_run(schema, env_vars, target, flat_env)
            case CloudflarePagesTargetConfig():
                _inject_cloudflare_pages(schema, env_vars, target, flat_env)
            case ScriptTargetConfig() | GitHubActionsTargetConfig():
                _inject_script(schema, env_vars, target_name, flat_env)
            case _:
                assert_never(target)
    else:
        for key, val in env_vars.items():
            flat_env[key] = str(val)

    # Consume leading KEY=VALUE tokens (shell inline-env syntax) and inject them.
    _kv_re = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*=")
    while command_args and _kv_re.match(command_args[0]):
        key, _, val = command_args.pop(0).partition("=")
        flat_env[key] = val

    try:
        subprocess.run(command_args, check=True, env=flat_env)
    except subprocess.CalledProcessError as e:
        sys.exit(e.returncode)
    except FileNotFoundError as e:
        err_console.print(f"[red]Error: Command not found: {e}[/red]")
        sys.exit(1)
