"""Local .env file I/O and casing validation."""

from __future__ import annotations

import sys
from pathlib import Path

from .ui import err_console, report_error, report_hint
from .vs_types import _REPO_ROOT, FlatSecrets, Schema, SecretKey


def _get_secrets_path(env_name: str) -> Path:
    """Return the path to the environment-specific local vault file."""
    return _REPO_ROOT / f".secrets.{env_name}"


def _read_flat_file(path: Path, schema: Schema) -> FlatSecrets:
    """Read a flat .env style file using exact casing from schema."""
    typed_vars: dict[SecretKey, str] = {}
    lines = path.read_text().splitlines()
    all_keys = list(schema.secrets.keys()) + list(schema.public.keys())

    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key, _, value = stripped.partition("=")
        sk = SecretKey(key)
        if sk in all_keys:
            typed_vars[sk] = value
        else:
            low_key = key.lower()
            match = next((k for k in all_keys if k.lower() == low_key), None)
            if match:
                report_error(f"Key '{key}' in {path.name} has incorrect casing.")
                report_hint("Action:", f"Rename to '{match}' to match schema.")
                err_console.print()
                sys.exit(1)
            continue
    return FlatSecrets(typed_vars)
