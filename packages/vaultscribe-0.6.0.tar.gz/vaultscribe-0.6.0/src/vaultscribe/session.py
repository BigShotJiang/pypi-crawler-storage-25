"""Secure shell session management (vs shell)."""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
from datetime import UTC, datetime, timedelta
from pathlib import Path

import questionary

from .gcloud import _check_ambient_gcloud_auth
from .ui import err_console
from .vs_types import Schema


def _run_oauth(proj: str) -> str:
    """Run the OAuth flow in an isolated temp dir. Returns the access token.

    The temp dir (which holds the refresh token) is deleted immediately after
    the access token is extracted — the refresh token never persists to disk.
    """
    auth_dir = tempfile.mkdtemp(prefix="vs-auth-")
    # Strip CLOUDSDK_AUTH_ACCESS_TOKEN so gcloud uses the credentials stored in
    # auth_dir rather than echoing back any pre-existing (possibly expired) token.
    clean_env = {k: v for k, v in os.environ.items() if k != "CLOUDSDK_AUTH_ACCESS_TOKEN"}
    try:
        subprocess.run(
            ["gcloud", "auth", "login", f"--project={proj}", "--no-update-adc"],
            env={**clean_env, "CLOUDSDK_CONFIG": auth_dir},
            check=True,
        )
        return subprocess.run(
            ["gcloud", "auth", "print-access-token"],
            env={**clean_env, "CLOUDSDK_CONFIG": auth_dir},
            capture_output=True,
            text=True,
            check=True,
        ).stdout.strip()
    except subprocess.CalledProcessError:
        err_console.print("\n[red]Authentication cancelled or failed.[/red]")
        sys.exit(1)
    finally:
        shutil.rmtree(auth_dir, ignore_errors=True)


def _write_session_token(session_dir: str, token: str, expires_at: datetime) -> None:
    token_file = Path(session_dir) / "vs_token"
    expires_file = Path(session_dir) / "vs_expires_at"
    token_file.write_text(token)
    token_file.chmod(0o600)
    expires_file.write_text(str(int(expires_at.timestamp())))


def _build_zshrc(session_dir: str) -> str:
    """Build the .zshrc content for the vs secure shell."""
    return (
        '[[ -f "$HOME/.zshrc" ]] && source "$HOME/.zshrc"\n'
        "\n"
        f'export VS_SESSION_DIR="{session_dir}"\n'
        "\n"
        # precmd runs before every prompt. It reads the token file (updated by
        # re-auth inside any vs subprocess) and refreshes the shell env var so
        # that both vs commands and plain gcloud commands always use a fresh token.
        "function _vs_precmd() {\n"
        '    local token_file="${VS_SESSION_DIR}/vs_token"\n'
        '    local expires_file="${VS_SESSION_DIR}/vs_expires_at"\n'
        '    if [[ ! -f "$token_file" ]]; then\n'
        '        PROMPT="%F{red}[vaultscribe | NO AUTH]%f %F{green}%~%f > "\n'
        "        return\n"
        "    fi\n"
        '    export CLOUDSDK_AUTH_ACCESS_TOKEN="$(cat "$token_file")"\n'
        "    local now expires remaining\n"
        "    now=$(date +%s)\n"
        '    expires=$(cat "$expires_file" 2>/dev/null || echo 0)\n'
        "    remaining=$(( (expires - now) / 60 ))\n"
        "    if (( remaining > 0 )); then\n"
        '        PROMPT="%F{cyan}[vaultscribe | ${remaining}m]%f %F{green}%~%f > "\n'
        "    else\n"
        '        PROMPT="%F{red}[vaultscribe | EXPIRED]%f %F{green}%~%f > "\n'
        "    fi\n"
        "}\n"
        "precmd_functions+=(_vs_precmd)\n"
    )


def _start_shell(schema: Schema) -> None:
    proj = schema.project

    err_console.print("[cyan]Authenticating to GCloud...[/cyan]")
    token = _run_oauth(proj)
    _check_ambient_gcloud_auth()

    session_dir = tempfile.mkdtemp(prefix="vs-session-")
    expires_at = datetime.now(tz=UTC) + timedelta(hours=1)
    _write_session_token(session_dir, token, expires_at)

    s_env = os.environ.copy()
    # Set the token in the initial shell env so gcloud commands work before
    # the first precmd fires, and so the precmd has something to refresh from.
    s_env["CLOUDSDK_AUTH_ACCESS_TOKEN"] = token
    s_env["CLOUDSDK_CORE_PROJECT"] = proj
    s_env["CLOUDSDK_CONFIG"] = session_dir
    s_env["VS_SESSION_DIR"] = session_dir

    z_dir = tempfile.mkdtemp(prefix="vs-zsh-")
    Path(z_dir, ".zshrc").write_text(_build_zshrc(session_dir))
    s_env["ZDOTDIR"] = z_dir

    expires_local = expires_at.astimezone().strftime("%H:%M")
    err_console.print(f"\n[bold green]✔︎ Secure session started (expires in 1 hour at {expires_local}).[/bold green]")
    err_console.print("[cyan]  GCloud auth is active for both vs commands and gcloud CLI.\n[/cyan]")

    try:
        subprocess.run(["zsh", "-i"], env=s_env, check=False)
    finally:
        shutil.rmtree(session_dir, ignore_errors=True)
        shutil.rmtree(z_dir, ignore_errors=True)

    err_console.print("\n[bold green]✔︎ Secure session ended. GCloud auth revoked.[/bold green]\n")


def _reauth_in_shell(proj: str, session_dir: str) -> None:
    """Prompt the user to re-authenticate mid-session, then retry."""
    confirmed = questionary.confirm(
        "Your GCloud session has expired. Re-authenticate?",
        default=True,
    ).ask()
    if not confirmed:
        sys.exit(1)

    err_console.print("[cyan]Re-authenticating...[/cyan]")
    token = _run_oauth(proj)

    expires_at = datetime.now(tz=UTC) + timedelta(hours=1)
    _write_session_token(session_dir, token, expires_at)
    # Update this process's env so the immediate retry picks up the new token.
    os.environ["CLOUDSDK_AUTH_ACCESS_TOKEN"] = token

    expires_local = expires_at.astimezone().strftime("%H:%M")
    err_console.print(f"[bold green]✔︎ Re-authenticated (new session expires at {expires_local}).[/bold green]")
