"""GCloud Secret Manager fetch, push, and error handling."""

from __future__ import annotations

import json
import os
import subprocess
import sys
from typing import Any, NoReturn

from .deps import GCLOUD, check_cli
from .ui import (
    ErrorCategory,
    err_console,
    report_error,
    report_hint,
    report_list_item,
    report_warning,
)
from .vs_types import FlatSecrets, Namespace, Schema, SecretKey


class GCloudTokenExpiredError(Exception):
    """Raised when the GCloud access token has expired inside a vaultscribe shell."""


def _check_ambient_gcloud_auth() -> None:
    """Warn if the system gcloud has stored credentials (a persistent refresh token on disk).

    Runs against the default CLOUDSDK_CONFIG (~/.config/gcloud), not our isolated session dir.
    """
    result = subprocess.run(
        ["gcloud", "auth", "list", "--format=value(account)"],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0 or not result.stdout.strip():
        return

    accounts = result.stdout.strip().splitlines()
    report_warning("Your system gcloud has stored credentials (refresh token on disk).")
    for acct in accounts:
        report_list_item(acct)
    report_hint("Info:", "This is separate from your vs session but means you are persistently")
    report_hint("Info:", "authenticated to GCloud.")
    report_hint("Action:", "[green]gcloud auth revoke --all[/green]")
    err_console.print()


def _handle_gcloud_error(e: subprocess.CalledProcessError) -> NoReturn:
    """Parse GCloud stderr and provide helpful, actionable advice."""
    err_msg = e.stderr.lower()

    # Must check UNAUTHENTICATED before printing the error header — the caller
    # handles user interaction when we raise instead of printing and exiting.
    if "unauthenticated" in err_msg or "cloudsdk_auth_access_token" in err_msg:
        if "VS_SESSION_DIR" in os.environ:
            raise GCloudTokenExpiredError()
        report_error("Your GCloud access token has expired or is invalid.", category=ErrorCategory.AUTH)
        report_hint("Action:", "Run [green]vs shell[/green] to start a secure 1-hour session.")
        err_console.print()
        sys.exit(e.returncode)

    if (
        "re-authentication" in err_msg
        or "permission denied" in err_msg
        or "403" in err_msg
        or "active account" in err_msg
    ):
        report_error(
            "Your GCloud session has expired, is missing, or lacks permissions.",
            category=ErrorCategory.AUTH,
        )
        report_hint("Action:", "Run [green]vs shell[/green] to start a secure 1-hour session.")
    elif "not_found" in err_msg or "404" in err_msg:
        report_error("The requested secret slot does not exist.", category=ErrorCategory.GCLOUD)
        report_hint("Action:", "Have you run 'vs push' yet to create it?")
        report_hint("Tip:", "You can see all secrets in Secret Manager with 'gcloud secrets list'.")
    else:
        report_error(f"Command failed with exit code {e.returncode}.", category=ErrorCategory.GCLOUD)
        report_hint("Details:", e.stderr.strip())

    err_console.print()
    sys.exit(e.returncode)


def _validate_and_flatten_bundle(data: dict[str, Any], schema: Schema) -> FlatSecrets:
    """Validate JSON bundle against schema using exact casing."""
    if not isinstance(data, dict) or Namespace.SECRET not in data or Namespace.PUBLIC not in data:
        raise ValueError(
            f"GCloud Secret Manager bundle is missing mandatory '{Namespace.SECRET}' or '{Namespace.PUBLIC}' namespaces."  # noqa: E501
        )

    merged = {**data[Namespace.SECRET], **data[Namespace.PUBLIC]}
    all_keys = list(schema.secrets.keys()) + list(schema.public.keys())
    env_vars: dict[SecretKey, str] = {}

    for k, v in merged.items():
        sk = SecretKey(k)
        if sk in all_keys:
            env_vars[sk] = str(v)
        else:
            low_k = k.lower()
            match = next((cand for cand in all_keys if cand.lower() == low_k), None)
            if match:
                report_error(f"Key '{k}' in GCloud has incorrect casing.", category=ErrorCategory.GCLOUD)
                report_hint("Expected:", f"'{match}' (as defined in TOML)")
                err_console.print()
                sys.exit(1)
            continue

    missing = [k for k in all_keys if k not in env_vars]
    if missing:
        err_console.print(
            f"[yellow]Warning: GCloud Secret Manager bundle is missing fields defined in schema: {', '.join(missing)}[/yellow]"  # noqa: E501
        )

    return FlatSecrets(env_vars)


def _fetch_from_gcloud(project: str, slot: str, schema: Schema) -> FlatSecrets:
    """Fetch the namespaced JSON from GCloud Secret Manager into memory."""
    check_cli(GCLOUD)
    cmd = [
        "gcloud",
        "secrets",
        "versions",
        "access",
        "latest",
        f"--secret={slot}",
        f"--project={project}",
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        raw_data = json.loads(result.stdout)
        return _validate_and_flatten_bundle(raw_data, schema)
    except subprocess.CalledProcessError as e:
        _handle_gcloud_error(e)
    except Exception as e:
        report_error("Failed to parse secrets from GCloud.", category=ErrorCategory.GCLOUD)
        report_hint("Details:", str(e))
        err_console.print()
        sys.exit(1)


def _try_fetch_from_gcloud(project: str, slot: str, schema: Schema) -> FlatSecrets | None:
    """Like _fetch_from_gcloud but returns None if the slot doesn't exist yet."""
    check_cli(GCLOUD)
    cmd = [
        "gcloud",
        "secrets",
        "versions",
        "access",
        "latest",
        f"--secret={slot}",
        f"--project={project}",
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        raw_data = json.loads(result.stdout)
        return _validate_and_flatten_bundle(raw_data, schema)
    except subprocess.CalledProcessError as e:
        err_msg = e.stderr.lower()
        # Only treat as "slot doesn't exist yet" if there's no auth failure alongside it.
        # GCloud includes account info in NOT_FOUND messages (e.g. "...active account..."),
        # so we must not mistake an auth error for a missing slot.
        is_not_found = "not_found" in err_msg or "404" in err_msg
        no_auth_fail = (
            "re-authentication" not in err_msg and "permission denied" not in err_msg and "403" not in err_msg
        )
        if is_not_found and no_auth_fail:
            return None
        _handle_gcloud_error(e)
    except Exception as e:
        report_error("Failed to parse secrets from GCloud.", category=ErrorCategory.GCLOUD)
        report_hint("Details:", str(e))
        err_console.print()
        sys.exit(1)
