"""Interactive prompts for Vaultscribe initialisation."""

from __future__ import annotations

import re
import subprocess
from typing import NamedTuple

import questionary

from .ui import _VS_STYLE
from .vs_types import (
    VALID_FLAVOURS,
    CloudflarePagesTargetConfig,
    Flavour,
    GcloudRunTargetConfig,
    GitHubActionsTargetConfig,
    ScriptTargetConfig,
    TargetConfig,
    TargetType,
)


def _prompt_project_id() -> str | None:
    def required(text: str) -> bool | str:
        return True if text.strip() else "This field is required (press Ctrl+C to exit)."

    return questionary.text(
        "Enter your Google Cloud Project ID (e.g., my-startup-123):",
        validate=required,
        style=_VS_STYLE,
    ).ask()


def _prompt_slot_base(suggested_slot: str) -> str | None:
    def required(text: str) -> bool | str:
        return True if text.strip() else "This field is required (press Ctrl+C to exit)."

    return questionary.text(
        "Enter the base name for your secret slots:",
        default=suggested_slot,
        validate=required,
        style=_VS_STYLE,
    ).ask()


def _prompt_envs() -> list[str] | None:
    return questionary.checkbox(
        "Which environments do you need?",
        choices=[
            questionary.Choice("dev", checked=True),
            questionary.Choice("staging", checked=False),
            questionary.Choice("prod", checked=True),
        ],
        style=_VS_STYLE,
    ).ask()


def _prompt_configure_targets() -> bool | None:
    return questionary.confirm(
        "Would you like to configure code consumers (targets) now?",
        default=True,
        style=_VS_STYLE,
    ).ask()


class _TargetExtras(NamedTuple):
    overlay: str | None
    project_name: str | None
    runtime_function_path: str | None


def _prompt_target_extras(
    t_name: str,
    target_flavour: Flavour,
    target_type: TargetType,
    suggested_base: str,
) -> _TargetExtras | None:
    """Prompt for overlay and (if Cloudflare) project config. Returns None if user cancels."""

    def required(text: str) -> bool | str:
        return True if text.strip() else "This field is required (press Ctrl+C to exit)."

    t_overlay: str | None = None
    if target_flavour != Flavour.TYPESCRIPT_VITE:
        t_overlay_raw = questionary.text(
            f"Enter local overlay file for '{t_name}' (empty to skip):",
            default=".env.dev",
            style=_VS_STYLE,
        ).ask()
        if t_overlay_raw is None:
            return None
        t_overlay = t_overlay_raw.strip() or None

    t_project_name: str | None = None
    t_runtime_function_path: str | None = None
    if target_type == TargetType.CLOUDFLARE_PAGES:
        slug = t_name.replace("_", "-")
        t_project_name = questionary.text(
            f"Enter Cloudflare Project Name for '{t_name}':",
            default=f"{suggested_base}-{slug}",
            style=_VS_STYLE,
            validate=required,
        ).ask()
        if t_project_name is None:
            return None
        t_runtime_function_path = questionary.text(
            f"Enter the path for the generated runtime config function for '{t_name}':",
            default="functions/vs-config.ts",
            style=_VS_STYLE,
            validate=required,
        ).ask()
        if t_runtime_function_path is None:
            return None

    return _TargetExtras(
        overlay=t_overlay,
        project_name=t_project_name,
        runtime_function_path=t_runtime_function_path,
    )


def _required_text(text: str) -> bool | str:
    return True if text.strip() else "This field is required (press Ctrl+C to exit)."


def _prompt_deployed_target(t_name: str, target_type: TargetType, suggested_base: str) -> TargetConfig | None:
    """Prompt for source/flavour/extras and build a gcloud_run or cloudflare_pages config."""
    t_src = questionary.text(
        f"Enter source directory for '{t_name}':",
        default="api/" if "backend" in t_name or "api" in t_name else "app/src/",
        style=_VS_STYLE,
        validate=_required_text,
    ).ask()
    if t_src is None:
        return None

    allowed = VALID_FLAVOURS.get(target_type, [])
    t_flavour_raw = questionary.select(
        f"Enter flavour for '{t_name}':",
        choices=[f.value for f in allowed],
        style=_VS_STYLE,
    ).ask()
    if t_flavour_raw is None:
        return None
    target_flavour = Flavour(t_flavour_raw)

    extras = _prompt_target_extras(t_name, target_flavour, target_type, suggested_base)
    if extras is None:
        return None

    if target_type == TargetType.GCLOUD_RUN:
        return GcloudRunTargetConfig(
            name=t_name,
            source=t_src,
            flavour=target_flavour,
            secrets_env_var="VS_SECRETS",
            overlay=extras.overlay,
        )
    # CLOUDFLARE_PAGES — _prompt_target_extras enforces these are set; fail closed if not.
    if extras.project_name is None or extras.runtime_function_path is None:
        return None
    return CloudflarePagesTargetConfig(
        name=t_name,
        source=t_src,
        flavour=target_flavour,
        project_name=extras.project_name,
        auth_token="${CLOUDFLARE_API_TOKEN}",  # noqa: S106 — toml interpolation template, not a credential
        account_id="${CLOUDFLARE_ACCOUNT_ID}",
        runtime_function_path=extras.runtime_function_path,
    )


def _discover_github_repo() -> str | None:
    """Attempt to discover the owner/repo from the git 'origin' remote."""
    try:
        result = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            capture_output=True,
            text=True,
            check=False,
        )
        if result.returncode != 0:
            return None

        url = result.stdout.strip()
        # Matches both HTTPS (github.com/owner/repo) and SSH (github.com:owner/repo)
        match = re.search(r"github\.com[:/](.+/.+?)(\.git)?$", url)
        if match:
            return match.group(1)
    except Exception:
        return None
    return None


def _prompt_github_actions(t_name: str, envs: list[str]) -> GitHubActionsTargetConfig | None:
    """Collect repo, vs_env, and optional GitHub environment for a github_actions target."""
    t_repo = questionary.text(
        f"Enter the GitHub repository (owner/repo) for '{t_name}':",
        default=_discover_github_repo() or "",
        style=_VS_STYLE,
        validate=_required_text,
    ).ask()
    if t_repo is None:
        return None

    t_vs_env = questionary.select(
        f"Which vs env should '{t_name}' sync from?",
        choices=envs,
        style=_VS_STYLE,
    ).ask()
    if t_vs_env is None:
        return None

    t_environment_raw = questionary.text(
        f"Optional GitHub environment scope for '{t_name}' (empty for repo-level):",
        style=_VS_STYLE,
    ).ask()
    if t_environment_raw is None:
        return None
    t_environment = t_environment_raw.strip() or None

    return GitHubActionsTargetConfig(
        name=t_name,
        repo=t_repo,
        vs_env=t_vs_env,
        environment=t_environment,
    )


def _prompt_target_config(suggested_base: str, envs: list[str]) -> TargetConfig | None:
    t_name = questionary.text(
        "Enter the name of this code consumer (target) (e.g., backend, frontend, api):",
        validate=_required_text,
        style=_VS_STYLE,
    ).ask()
    if t_name is None:
        return None

    t_type_raw = questionary.select(
        f"Enter type for '{t_name}':",
        choices=[f.value for f in TargetType],
        style=_VS_STYLE,
    ).ask()
    if t_type_raw is None:
        return None
    target_type = TargetType(t_type_raw)

    match target_type:
        case TargetType.GCLOUD_RUN | TargetType.CLOUDFLARE_PAGES:
            return _prompt_deployed_target(t_name, target_type, suggested_base)
        case TargetType.SCRIPT:
            return ScriptTargetConfig(name=t_name)
        case TargetType.GITHUB_ACTIONS:
            return _prompt_github_actions(t_name, envs)


def _prompt_another_target() -> bool | None:
    return questionary.confirm(
        "Would you like to configure another code consumer?",
        default=False,
        style=_VS_STYLE,
    ).ask()
