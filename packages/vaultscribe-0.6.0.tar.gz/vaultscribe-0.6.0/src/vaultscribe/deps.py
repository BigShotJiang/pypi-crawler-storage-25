"""External CLI dependency checks with friendly install hints."""

from __future__ import annotations

import shutil
import sys
from dataclasses import dataclass

from .ui import err_console, report_error, report_hint, report_list_item


@dataclass(frozen=True)
class CliDependency:
    """A required external CLI tool and the guidance to surface when missing."""

    name: str
    install_url: str
    login_hint: str | None = None
    env_hints: tuple[str, ...] = ()


GCLOUD = CliDependency(
    name="gcloud",
    install_url="https://cloud.google.com/sdk/docs/install",
    login_hint="Run `vs shell` to start a time-limited authenticated session.",
)

NPX = CliDependency(
    name="npx",
    install_url="https://nodejs.org/ (npx ships with Node.js). `wrangler` is fetched on demand by npx.",
    env_hints=(
        "CLOUDFLARE_API_TOKEN — declare in [secrets] and reference via auth_token in the cloudflare target.",
        "CLOUDFLARE_ACCOUNT_ID — declare in [secrets] and reference via account_id in the cloudflare target.",
    ),
)

GH = CliDependency(
    name="gh",
    install_url="https://cli.github.com/",
    login_hint="Run `gh auth login` once to authenticate the GitHub CLI.",
)


def check_cli(dep: CliDependency) -> None:
    """Exit with a friendly message if the CLI tool is not on PATH."""
    if shutil.which(dep.name) is not None:
        return

    report_error(f"Required CLI '{dep.name}' is not installed or not on PATH.")
    report_hint("Install:", dep.install_url)
    if dep.login_hint:
        report_hint("Auth:", dep.login_hint)
    if dep.env_hints:
        report_hint("Env:", "")
        for hint in dep.env_hints:
            report_list_item(hint)
    err_console.print()
    sys.exit(1)
