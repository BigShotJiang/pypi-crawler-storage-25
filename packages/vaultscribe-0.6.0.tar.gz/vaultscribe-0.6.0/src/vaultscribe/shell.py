"""Subprocess execution helper and repository security utilities."""

from __future__ import annotations

import os
import selectors
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import IO, cast

from .ui import err_console
from .vs_types import _REPO_ROOT


@dataclass(frozen=True)
class RunContext:
    env: dict[str, str] = field(default_factory=dict)
    cwd: Path | None = None


_DEFAULT_RUN_CONTEXT = RunContext()


def _run(
    args: list[str],
    *,
    input: bytes | None = None,
    context: RunContext = _DEFAULT_RUN_CONTEXT,
    capture: bool = True,
    silent: bool = False,
) -> subprocess.CompletedProcess[str]:
    """Run a command and exit cleanly on failure. Supports streaming for long tasks."""
    run_env = {**os.environ, **context.env} if context.env else os.environ.copy()

    if not capture:
        result = subprocess.run(
            args,
            input=input.decode() if input else None,
            capture_output=False,
            text=True,
            check=False,
            env=run_env,
            cwd=context.cwd,
        )
        return result

    process = subprocess.Popen(
        args,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        env=run_env,
        cwd=context.cwd,
        bufsize=1,
    )

    stdout_lines: list[str] = []
    stderr_lines: list[str] = []

    sel = selectors.DefaultSelector()
    sel.register(cast(IO[str], process.stdout), selectors.EVENT_READ)
    sel.register(cast(IO[str], process.stderr), selectors.EVENT_READ)

    if input:
        if process.stdin is None:
            raise RuntimeError("process.stdin is None but input was provided")
        process.stdin.write(input.decode())
        process.stdin.close()

    while True:
        for key, _ in sel.select():
            fileobj = cast(IO[str], key.fileobj)
            line = fileobj.readline()
            if not line:
                sel.unregister(key.fileobj)
                continue
            if key.fileobj is process.stdout:
                stdout_lines.append(line)
                if not silent:
                    sys.stdout.write(line)
                    sys.stdout.flush()
            else:
                stderr_lines.append(line)
                if not silent:
                    sys.stderr.write(line)
                    sys.stderr.flush()

        if not sel.get_map():
            break

    returncode = process.wait()
    completed = subprocess.CompletedProcess(
        args=args,
        returncode=returncode,
        stdout="".join(stdout_lines),
        stderr="".join(stderr_lines),
    )
    if returncode != 0:
        raise subprocess.CalledProcessError(returncode, args, completed.stdout, completed.stderr)
    return completed


def _ensure_secrets_ignored() -> None:
    """Proactively ensure .secrets.* is present in common ignore files."""
    ignore_files = [".gitignore", ".dockerignore", ".gcloudignore"]
    pattern = ".secrets.*"

    for filename in ignore_files:
        path = _REPO_ROOT / filename
        if not path.exists():
            continue

        content = path.read_text()
        if pattern in content:
            continue

        err_console.print(f"[cyan]🛡️  Vaultscribe: Adding {pattern} to {filename}...[/cyan]")
        new_content = content.rstrip() + f"\n\n# --- Vaultscribe ---\n{pattern}\n"
        path.write_text(new_content)
