"""Bundle formatting and GCloud Secret Manager master updates."""

from __future__ import annotations

import json
import subprocess

from .gcloud import _handle_gcloud_error
from .shell import _run
from .sync import _sync_cmd
from .ui import err_console
from .vs_types import EnvConfig, FlatSecrets, Namespace, Schema, SecretKey


def _get_sectioned_env_content(env_vars: FlatSecrets, schema: Schema, env_name: str) -> str:
    filename = f".secrets.{env_name}"
    header = f"""\
# {filename} — {env_name.upper()} SECRETS. This file is gitignored at the root.
#
# Fill in any empty values, then run: vs push {env_name}
# Push uploads to GCloud Secret Manager and deletes this file.
#
# These are LIVE {env_name.upper()} credentials. Treat this file like a password.
# Delete it as soon as you have finished editing and pushed.
"""
    lines = [header, "#"]
    all_fields = {**schema.secrets, **schema.public}
    for key in sorted(all_fields.keys()):
        config = all_fields[key]
        desc = config.description or ""
        source = config.source or ""
        lines.append(f"# {key}\n#   Description: {desc}")
        if source:
            lines.append(f"#   Source:      {source}")
        lines.append("#")

    lines.append("\n# " + "-" * 75 + "\n# PRIVATE SECRETS\n# " + "-" * 75)
    for key in sorted(schema.secrets.keys()):
        lines.append(f"{key}={env_vars.get(key, '')}")

    lines.append("\n# " + "-" * 75 + "\n# PUBLIC CONFIG\n# " + "-" * 75)
    for key in sorted(schema.public.keys()):
        lines.append(f"{key}={env_vars.get(key, '')}")

    return "\n".join(lines) + "\n"


def _push_bundle(
    env_conf: EnvConfig,
    schema: Schema,
    env_vars: FlatSecrets,
    no_sync: bool,
    env_name: str,
) -> None:
    secret_part: dict[str, str] = {}
    public_part: dict[str, str] = {}

    for key, val in env_vars.items():
        if SecretKey(key) in schema.public:
            public_part[key] = str(val)
        elif SecretKey(key) in schema.secrets:
            secret_part[key] = str(val)

    bundle_data = {Namespace.SECRET: secret_part, Namespace.PUBLIC: public_part}
    payload = json.dumps(bundle_data, indent=2).encode()

    try:
        _run(
            [
                "gcloud",
                "secrets",
                "versions",
                "add",
                env_conf.slot,
                "--data-file=-",
                f"--project={env_conf.project}",
            ],
            input=payload,
            silent=True,
        )
    except subprocess.CalledProcessError as e:
        err_msg = e.stderr.lower()
        if "not_found" in err_msg or "404" in err_msg:
            slot = f"[bold]{env_conf.slot}[/bold]"
            err_console.print(
                f"[cyan]Secret slot '{slot}' not found in GCloud Secret Manager — creating it now...[/cyan]"
            )
            try:
                _run(
                    [
                        "gcloud",
                        "secrets",
                        "create",
                        env_conf.slot,
                        f"--project={env_conf.project}",
                    ]
                )
                _run(
                    [
                        "gcloud",
                        "secrets",
                        "versions",
                        "add",
                        env_conf.slot,
                        "--data-file=-",
                        f"--project={env_conf.project}",
                    ],
                    input=payload,
                )
            except subprocess.CalledProcessError as create_err:
                _handle_gcloud_error(create_err)
        else:
            _handle_gcloud_error(e)

    err_console.print(f"[bold green]✔︎ GCloud Secret Manager Master updated ({env_name})[/bold green]")

    if not no_sync:
        _sync_cmd(env_name)
