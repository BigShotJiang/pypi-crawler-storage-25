"""Core vault commands: pull, push, rotate."""

from __future__ import annotations

import sys

import questionary

from .bundle import _get_sectioned_env_content, _push_bundle
from .codegen import codegen
from .env_file import _get_secrets_path, _read_flat_file
from .gcloud import _fetch_from_gcloud, _try_fetch_from_gcloud
from .generator import _generate_secret_value
from .iam import _ensure_gcloud_run_iam
from .schema import _get_env_config, _parse_schema
from .shell import _ensure_secrets_ignored
from .ui import (
    _VS_STYLE,
    err_console,
    report_error,
    report_hint,
    report_list_item,
    report_warning,
)
from .vs_types import FlatSecrets, SecretKey


def _pull(env_name: str) -> None:
    """Generate a local secrets file from GCloud Secret Manager and the current schema.

    Aborts if a local .secrets.{env} file already exists — this signals unfinished secrets
    work. The user should push or manually delete the file before pulling again.

    If the GCloud slot does not exist yet, a blank template is generated from the schema.
    Keys removed from the schema are dropped; new keys are added (auto-generated or blank).
    """
    _ensure_secrets_ignored()
    schema = _parse_schema()
    env_conf = _get_env_config(schema, env_name)
    dest = _get_secrets_path(env_name)

    if dest.exists():
        report_error(f"{dest.name} already exists.")
        report_hint("Info:", "You may have unfinished secrets work.")
        report_hint("Action:", f"[green]vs push {env_name}[/green]")
        report_hint("Example:", f"[green]rm {dest.name} && vs pull {env_name}[/green]")
        err_console.print()
        sys.exit(1)

    err_console.print(f"Fetching [bold]{env_conf.slot}[/bold] from GCloud Secret Manager ({env_name})...")
    gcloud_vars = _try_fetch_from_gcloud(env_conf.project, env_conf.slot, schema)
    if gcloud_vars is None:
        report_warning(f"Secret slot '{env_conf.slot}' not found in GCloud Secret Manager.")
        report_hint("Info:", "Generating a blank template from the current schema.")
        err_console.print()
        gcloud_vars = FlatSecrets({})

    all_fields = {**schema.secrets, **schema.public}
    resolved: dict[SecretKey, str] = {}
    for key, config in all_fields.items():
        if gcloud_vars.get(key):
            resolved[key] = gcloud_vars[key]
        elif config.auto_generate:
            resolved[key] = _generate_secret_value(config.auto_generate)
        else:
            resolved[key] = ""

    content = _get_sectioned_env_content(FlatSecrets(resolved), schema, env_name)
    dest.write_text(content)

    err_console.print(f"[bold green]✔︎ Generated {dest.name}[/bold green]")

    empty_keys = [k for k in all_fields if not resolved[k]]
    if empty_keys:
        report_hint("Pending:", f"{len(empty_keys)} key(s) need values — fill them in before pushing:")
        for k in empty_keys:
            report_list_item(k)
        err_console.print()


def _push(env_name: str, no_sync: bool) -> None:
    """Push local secrets to GCloud Secret Manager, then run codegen and sync."""
    schema = _parse_schema()
    env_conf = _get_env_config(schema, env_name)
    secrets_file = _get_secrets_path(env_name)

    if not secrets_file.exists():
        report_error(f"{secrets_file.name} not found.")
        report_hint("Action:", f"Run [green]vs pull {env_name}[/green] to generate it.")
        err_console.print()
        sys.exit(1)

    env_vars = _read_flat_file(secrets_file, schema)

    all_keys = list(schema.secrets.keys()) + list(schema.public.keys())
    missing = [k for k in all_keys if k not in env_vars]
    if missing:
        report_error(f"Missing fields in {secrets_file.name}:")
        for k in missing:
            report_list_item(k)
        report_hint("Action:", "Fill in the missing values then run push again.")
        err_console.print()
        sys.exit(1)

    _push_bundle(env_conf, schema, env_vars, no_sync, env_name)
    _ensure_gcloud_run_iam(env_conf, schema, env_name)
    codegen()

    err_console.print()
    if questionary.confirm(f"Delete {secrets_file.name} now?", default=True).ask():
        secrets_file.unlink()
        err_console.print(f"[bold green]✔︎ Deleted {secrets_file.name}[/bold green]")


def _rotate_cmd(env_name: str, key: str | None, value: str | None) -> None:
    """Rotate a single secret value in GCloud Secret Manager. Zero disk."""
    schema = _parse_schema()
    env_conf = _get_env_config(schema, env_name)

    all_keys = list(schema.secrets.keys()) + list(schema.public.keys())
    if key:
        if SecretKey(key) not in all_keys:
            low_key = key.lower()
            match = next((k for k in all_keys if k.lower() == low_key), None)
            if match:
                report_error(f"Key '{key}' not found in schema.")
                report_hint("Action:", f"Did you mean '{match}'?")
            else:
                report_error(f"Key '{key}' not defined in schema.")
            err_console.print()
            sys.exit(1)
    else:
        key = questionary.select("Select secret to rotate:", choices=sorted(all_keys), style=_VS_STYLE).ask()
        if not key:
            sys.exit(0)

    err_console.print("Fetching current bundle from GCloud Secret Manager...")
    env_vars = _fetch_from_gcloud(env_conf.project, env_conf.slot, schema)

    sk = SecretKey(key)
    if sk not in env_vars:
        report_warning(f"'{key}' has no existing {env_name} value in GCloud.")
        report_hint("Info:", f"This will add it as a new secret to {env_name}.")
        report_hint("Action:", "Press Ctrl+C to cancel.")
        err_console.print()

    if not value:
        config = schema.secrets.get(sk) or schema.public.get(sk)
        if config and config.auto_generate:
            value = _generate_secret_value(config.auto_generate)
            err_console.print(f"[bold green]✔︎ Auto-generated new value for {key}.[/bold green]")
        else:
            value = questionary.password(f"Enter new value for {key} ({env_name}):", style=_VS_STYLE).ask()
            if value is None:
                sys.exit(0)

    updated = FlatSecrets({**env_vars, sk: value})
    _push_bundle(env_conf, schema, updated, False, env_name)
    codegen()
