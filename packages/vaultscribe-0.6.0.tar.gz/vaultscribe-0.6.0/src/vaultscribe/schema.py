"""Public API for vaultscribe schema operations."""

from __future__ import annotations

import sys

from .errors import _report_config_error
from .parsing import _parse_schema
from .ui import ErrorCategory, err_console, report_error, report_hint
from .validation import _parse_sync_target, _validate_cloudflare_target, _validate_schema_structure
from .vs_types import (
    MOCK_ENV,
    EnvConfig,
    EnvName,
    FlatSecrets,
    Schema,
    SecretKey,
    TargetConfig,
    TargetName,
)

__all__ = [
    "_generate_mock_secrets",
    "_get_env_config",
    "_get_target_config",
    "_parse_schema",
    "_parse_sync_target",
    "_report_config_error",
    "_validate_cloudflare_target",
    "_validate_schema_structure",
]


def _generate_mock_secrets(schema: Schema) -> FlatSecrets:
    """Generate mock values for every secret and public key in the schema."""
    result: dict[SecretKey, str] = {}
    for block in [schema.secrets, schema.public]:
        for key in block:
            result[SecretKey(key)] = f"mock_{key.lower()}"
    return FlatSecrets(result)


def _get_env_config(schema: Schema, env_name: str) -> EnvConfig:
    """Extract environment configuration from schema."""
    if env_name == MOCK_ENV:
        report_error(f"'{MOCK_ENV}' is a pseudo-environment for vs run only.", category=ErrorCategory.CONFIG)
        report_hint("Usage:", f"[green]vs run {MOCK_ENV} --target <name> -- <cmd>[/green]")
        err_console.print()
        sys.exit(1)
    if env_name not in schema.environments:
        report_error(f"Environment '{env_name}' is not defined in vaultscribe.toml.", category=ErrorCategory.CONFIG)
        err_console.print()
        sys.exit(1)
    return schema.environments[EnvName(env_name)]


def _get_target_config(schema: Schema, target_name: str) -> TargetConfig:
    """Return typed config for a named target. Exits with a helpful error if not found."""
    key = TargetName(target_name)
    if key not in schema.targets:
        available = ", ".join(sorted(schema.targets.keys()))
        report_error(f"Target '{target_name}' is not defined in vaultscribe.toml.", category=ErrorCategory.CONFIG)
        report_hint("Available:", available)
        err_console.print()
        sys.exit(1)
    return schema.targets[key]
