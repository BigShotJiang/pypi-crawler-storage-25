# Changelog

## [0.6.0](https://github.com/lawther/vaultscribe/compare/v0.5.0...v0.6.0) (2026-05-03)


### Features

* **run:** add mock pseudo-environment for target-aware injection without GCloud auth ([b751d5b](https://github.com/lawther/vaultscribe/commit/b751d5b107a431cc78388c961d0f708c1bf5d431))
* **ui:** standardise CLI reporting and add consistency tests ([f1c3e80](https://github.com/lawther/vaultscribe/commit/f1c3e80a814868e42eaffc8b6fa7987877aff478))


### Bug Fixes

* raise on malformed secret bundle instead of logging and continuing ([8751cac](https://github.com/lawther/vaultscribe/commit/8751cac412d238022e9e948fb063f3227a8cbe23))

## [0.5.0](https://github.com/lawther/vaultscribe/compare/v0.4.0...v0.5.0) (2026-05-02)


### Features

* abort vs pull when local secrets file already exists ([d95c33e](https://github.com/lawther/vaultscribe/commit/d95c33ec6a6301ed1a94f16f066086769ae987ef))
* add version-controlled git hooks and auto-install on precommit ([cdfcf92](https://github.com/lawther/vaultscribe/commit/cdfcf92a2c38a32a16f5d7f2b6a69861390aac3a))
* include 'source' in pulled secrets file header ([7684c49](https://github.com/lawther/vaultscribe/commit/7684c49d6e16c601d9888ee44188b0a12bba10b6))
* prevent Python keywords as secret names in Python targets ([ef33464](https://github.com/lawther/vaultscribe/commit/ef334642194a065cbc7c35c3109f039d85292732))
* prevent TypeScript keywords as secret names in TS targets ([3d4d29c](https://github.com/lawther/vaultscribe/commit/3d4d29c78cd8d4ed5153761bcc7472392fa2eda9))
* restrict secret and public name characters ([28b14a4](https://github.com/lawther/vaultscribe/commit/28b14a46950ea7eb5dc65d8760a30ddca221aff6))
* suggest current GitHub repo in vs init ([09d9794](https://github.com/lawther/vaultscribe/commit/09d979415b23883ca536c6fc822a0c47dbcf4b92))


### Bug Fixes

* resolve pre-existing lint errors (E501, F401, PLR0912) ([feab5d3](https://github.com/lawther/vaultscribe/commit/feab5d37bcc57b9b11337bbec799710dd4655295))
* throw on missing build-time env vars instead of console.error ([f13f632](https://github.com/lawther/vaultscribe/commit/f13f632c03f108528c8e8bb3584bb5bcd23d84cd))
* update GCloud Secret Manager log messages for clarity and consistency ([f7ac062](https://github.com/lawther/vaultscribe/commit/f7ac06214309e2d3f2fe276295ca29f1ab48901a))


### Documentation

* update capitalization of service names in README ([fe96dce](https://github.com/lawther/vaultscribe/commit/fe96dce59219cc004b6256c062cf5da66c0905a8))

## [0.4.0](https://github.com/lawther/vaultscribe/compare/v0.3.2...v0.4.0) (2026-05-02)


### Features

* add --version flag to vs CLI ([24f30ae](https://github.com/lawther/vaultscribe/commit/24f30ae6d1b16fe6598ff71eb83bfa9ddb3c6d17))

## [0.3.2](https://github.com/lawther/vaultscribe/compare/v0.3.1...v0.3.2) (2026-05-02)


### Bug Fixes

* remove brittle uv run hack from vs shell ([c7205d3](https://github.com/lawther/vaultscribe/commit/c7205d3fc8acba903ff203e3e65bb2b13f89d76f))

## [0.3.1](https://github.com/lawther/vaultscribe/compare/v0.3.0...v0.3.1) (2026-05-02)


### Bug Fixes

* handle non-deploy target types in interactive init prompts ([590a784](https://github.com/lawther/vaultscribe/commit/590a784a404d510b306f1e78d86522f9014dc95d))

## [0.3.0](https://github.com/lawther/vaultscribe/compare/v0.2.0...v0.3.0) (2026-05-02)


### Features

* add 'github_actions' target type for CI/CD secret sync ([9f1511d](https://github.com/lawther/vaultscribe/commit/9f1511d14d88ba5acc9e4e40a668460d05b7c0bd))
* add 'script' target type for least-privilege vs run injection ([1c9ff09](https://github.com/lawther/vaultscribe/commit/1c9ff0991909580278ec4792cc1b962fa500270e))
* upgrade release-please-action to v5 ([812dc48](https://github.com/lawther/vaultscribe/commit/812dc48d738a2652c04511632de84d917e5a783b))


### Documentation

* add vs shell documentation and reorganize core command references ([271c1f3](https://github.com/lawther/vaultscribe/commit/271c1f31b410fc79765a361ca40df8b15887e5c8))
* fix typo in README target description ([266e9f5](https://github.com/lawther/vaultscribe/commit/266e9f5c5bb18e7b064e77fd255eacbcea2fd458))
* migrate README documentation to separate files for commands and concepts ([cf4c477](https://github.com/lawther/vaultscribe/commit/cf4c4775ccc4690b90e0b9b7270cbc0080a482dd))

## [0.2.0](https://github.com/lawther/vaultscribe/compare/v0.1.1...v0.2.0) (2026-04-30)


### Features

* add --quiet flag to parse-test command ([5797417](https://github.com/lawther/vaultscribe/commit/579741711f4b3dcd2194fa67090faf821e81b8f8))
* add example project and lint it in just lint ([6305ff5](https://github.com/lawther/vaultscribe/commit/6305ff5c0e2a3c2da677b0c6f32ca32595abdc68))
* generate .env.*.vs_example files alongside vs_secrets ([7e34ac1](https://github.com/lawther/vaultscribe/commit/7e34ac19aa83cb9a2de6145dd210fa2207547098))
* lint and type-check Python snapshots in just lint ([90615ad](https://github.com/lawther/vaultscribe/commit/90615ad08a4fdbe072ac10c64b6ee9f858db69a1))
* lint and type-check TypeScript snapshots in just lint ([9bc85f6](https://github.com/lawther/vaultscribe/commit/9bc85f656fc45ba12206d7f75d8179a5d7ab8cbd))
* log runtime config to console in dev mode after vsLoadConfig() ([433090b](https://github.com/lawther/vaultscribe/commit/433090b0a8bf848e80b1084399322de9b7602e8d))
* reject [secrets] keys synced to cloudflare_pages targets ([017aee6](https://github.com/lawther/vaultscribe/commit/017aee6e3cd367426e9ed2a75d5802c5efee4881))
* rename BaseManagedSettings to VaultscribeSecretSettings ([a3db121](https://github.com/lawther/vaultscribe/commit/a3db1210e996dcd56dd1bd50b870150b58dc3e83))
* rename gcloud_project to gcloud_project_id in vaultscribe.toml ([9602d39](https://github.com/lawther/vaultscribe/commit/9602d39b4e721199fe1216e58d86b3566b736046))
* rename generated runtime config endpoint from /api/config to /vs-config ([fdff78d](https://github.com/lawther/vaultscribe/commit/fdff78d693a87a99d7f987dcdb19974ab4824900))
* rename vs_secrets.ts to vs_config.ts, drop SecretField enum ([02067a6](https://github.com/lawther/vaultscribe/commit/02067a68c484e1903ef8701327b48ba6a0f594c8))
* rename window.APP_CONFIG to window.VS_CONFIG in generated TypeScript ([54f7888](https://github.com/lawther/vaultscribe/commit/54f788892eacbeaa666705f5dfe883233c87dfb7))
* require project_name, auth_token, account_id for cloudflare_pages targets ([c59fcbb](https://github.com/lawther/vaultscribe/commit/c59fcbb0aaace17d816dfcd91d26c73003c0f110))
* standardise branding to 'Vaultscribe' ([2b38c3b](https://github.com/lawther/vaultscribe/commit/2b38c3b13f86b5a003ab3005886713ed8afbfee8))


### Documentation

* add coding conventions and project guidelines for CLAUDE and GEMINI AI assistants ([a311f56](https://github.com/lawther/vaultscribe/commit/a311f56d76af9241faab9b7be77cedb9407034f7))
* clarify secret slot terminology and expand documentation with configuration examples and new vs shell/run commands ([7ef8413](https://github.com/lawther/vaultscribe/commit/7ef8413bbd3466cf6cd8b69db671239a107fb7ce))
* fix indentation in README.md file structure diagram ([3cf3ed3](https://github.com/lawther/vaultscribe/commit/3cf3ed35dc18f6664cac512171f1445ebc9a0052))

## [0.1.1](https://github.com/lawther/vaultscribe/compare/v0.1.0...v0.1.1) (2026-04-29)


### Bug Fixes

* **ci:** add contents: read to publish job permissions ([2c136df](https://github.com/lawther/vaultscribe/commit/2c136df2b8712d2943ad28388ebd6ce6b9cef498))

## 0.1.0 (2026-04-29)


### Features

* initial vaultscribe package scaffold ([9e02a42](https://github.com/lawther/vaultscribe/commit/9e02a42f3298e901bddf4f07977733e30468133e))
