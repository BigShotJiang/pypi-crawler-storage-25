"""Tests for vs pull command behaviour.

Pull is the entry point for secrets work. These tests cover the key contracts:
  - If a local secrets file already exists, pull must abort immediately with
    a clear error message pointing the user toward push or manual deletion.
  - On a fresh pull (no local file), GCloud values are written verbatim.
  - Keys absent from GCloud but marked auto_generate receive a generated value.
  - When the GCloud slot doesn't exist yet, a blank template is written.
"""

from pathlib import Path
from unittest import mock

import pytest

from vaultscribe import vault as vs_vault
from vaultscribe.vs_types import (
    AutoGenerateConfig,
    AutoGenerateType,
    EnvConfig,
    EnvName,
    FlatSecrets,
    Schema,
    SecretConfig,
    SecretKey,
)

_ENV_NAME = "prod"
_ENV_CONF = EnvConfig(project="test-proj", slot="test-slot")


def _empty_conf() -> SecretConfig:
    return SecretConfig(description=None, source=None, sync_targets=[], auto_generate=None)


def _autogen_conf() -> SecretConfig:
    return SecretConfig(
        description=None,
        source=None,
        sync_targets=[],
        auto_generate=AutoGenerateConfig(type=AutoGenerateType.HEX, length=32),
    )


_SCHEMA = Schema(
    project="test-proj",
    environments={EnvName(_ENV_NAME): _ENV_CONF},
    secrets={SecretKey("DB_PASSWORD"): _empty_conf()},
    public={SecretKey("API_URL"): _empty_conf()},
    targets={},
)

_SCHEMA_WITH_AUTOGEN = Schema(
    project="test-proj",
    environments={EnvName(_ENV_NAME): _ENV_CONF},
    secrets={
        SecretKey("DB_PASSWORD"): _empty_conf(),
        SecretKey("SESSION_SECRET"): _autogen_conf(),
    },
    public={},
    targets={},
)


# ---------------------------------------------------------------------------
# Abort-if-exists Tests
# ---------------------------------------------------------------------------


def test_pull_aborts_when_local_file_exists(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    """Pull must abort immediately if a local secrets file already exists.

    # This prevents the silent-stale-value bug where re-pulling would preserve
    # an old local value when the real secret had been rotated in GCloud.
    # Having a local file signals unfinished secrets work — the user must
    # explicitly resolve it before pulling fresh.
    """
    dest = tmp_path / ".secrets.prod"
    dest.write_text("DB_PASSWORD=old_value\n")

    with (
        mock.patch("vaultscribe.vault._ensure_secrets_ignored"),
        mock.patch("vaultscribe.vault._parse_schema", return_value=_SCHEMA),
        mock.patch("vaultscribe.vault._get_env_config", return_value=_ENV_CONF),
        mock.patch("vaultscribe.vault._get_secrets_path", return_value=dest),
        pytest.raises(SystemExit) as exc_info,
    ):
        vs_vault._pull(_ENV_NAME)

    # Non-zero exit signals an error, not normal termination
    assert exc_info.value.code == 1

    err = capsys.readouterr().err
    # Error message must name the file so the user knows what blocked them
    assert ".secrets.prod" in err
    # Error message must offer the next step for the most common case
    assert f"vs push {_ENV_NAME}" in err
    # Error message must show the explicit delete path for the re-pull case
    assert "rm .secrets.prod" in err


def test_pull_abort_does_not_contact_gcloud(tmp_path: Path) -> None:
    """GCloud must not be contacted if pull aborts due to an existing local file.

    # Early abort keeps secrets work intentional. If the abort triggered a
    # GCloud fetch anyway, it would do unnecessary auth and network work.
    """
    dest = tmp_path / ".secrets.prod"
    dest.write_text("DB_PASSWORD=old_value\n")

    with (
        mock.patch("vaultscribe.vault._ensure_secrets_ignored"),
        mock.patch("vaultscribe.vault._parse_schema", return_value=_SCHEMA),
        mock.patch("vaultscribe.vault._get_env_config", return_value=_ENV_CONF),
        mock.patch("vaultscribe.vault._get_secrets_path", return_value=dest),
        mock.patch("vaultscribe.vault._try_fetch_from_gcloud") as mock_fetch,
        pytest.raises(SystemExit),
    ):
        vs_vault._pull(_ENV_NAME)

    mock_fetch.assert_not_called()


def test_pull_abort_leaves_local_file_unchanged(tmp_path: Path) -> None:
    """Abort must not modify the existing file — only the user should change it.

    # If pull silently rewrote the file on abort, the user would lose their
    # in-progress edits without any warning.
    """
    dest = tmp_path / ".secrets.prod"
    original_content = "DB_PASSWORD=old_value\n"
    dest.write_text(original_content)

    with (
        mock.patch("vaultscribe.vault._ensure_secrets_ignored"),
        mock.patch("vaultscribe.vault._parse_schema", return_value=_SCHEMA),
        mock.patch("vaultscribe.vault._get_env_config", return_value=_ENV_CONF),
        mock.patch("vaultscribe.vault._get_secrets_path", return_value=dest),
        mock.patch("vaultscribe.vault._try_fetch_from_gcloud"),
        pytest.raises(SystemExit),
    ):
        vs_vault._pull(_ENV_NAME)

    assert dest.read_text() == original_content


# ---------------------------------------------------------------------------
# Fresh Pull Tests (no local file exists)
# ---------------------------------------------------------------------------


def test_pull_creates_file_with_gcloud_values(tmp_path: Path) -> None:
    """A fresh pull must write GCloud values into the new local file."""
    dest = tmp_path / ".secrets.prod"
    gcloud_secrets = FlatSecrets(
        {
            SecretKey("DB_PASSWORD"): "super-secret",
            SecretKey("API_URL"): "https://api.example.com",
        }
    )

    with (
        mock.patch("vaultscribe.vault._ensure_secrets_ignored"),
        mock.patch("vaultscribe.vault._parse_schema", return_value=_SCHEMA),
        mock.patch("vaultscribe.vault._get_env_config", return_value=_ENV_CONF),
        mock.patch("vaultscribe.vault._get_secrets_path", return_value=dest),
        mock.patch("vaultscribe.vault._try_fetch_from_gcloud", return_value=gcloud_secrets),
    ):
        vs_vault._pull(_ENV_NAME)

    assert dest.exists()
    content = dest.read_text()
    assert "DB_PASSWORD=super-secret" in content
    assert "API_URL=https://api.example.com" in content


def test_pull_auto_generates_key_absent_from_gcloud(tmp_path: Path) -> None:
    """Keys marked auto_generate and absent from GCloud must receive a generated value.

    # A blank auto_generate key is a broken secret — the schema says it
    # should always have a value. If GCloud doesn't have one yet, generate it
    # so the user can immediately push a valid bundle.
    """
    dest = tmp_path / ".secrets.prod"
    # GCloud only has DB_PASSWORD; SESSION_SECRET is absent (auto_generate key)
    gcloud_secrets = FlatSecrets({SecretKey("DB_PASSWORD"): "db-pass"})

    with (
        mock.patch("vaultscribe.vault._ensure_secrets_ignored"),
        mock.patch("vaultscribe.vault._parse_schema", return_value=_SCHEMA_WITH_AUTOGEN),
        mock.patch("vaultscribe.vault._get_env_config", return_value=_ENV_CONF),
        mock.patch("vaultscribe.vault._get_secrets_path", return_value=dest),
        mock.patch("vaultscribe.vault._try_fetch_from_gcloud", return_value=gcloud_secrets),
    ):
        vs_vault._pull(_ENV_NAME)

    assert dest.exists()
    content = dest.read_text()
    # SESSION_SECRET must have been auto-generated (non-empty, 32 hex chars)
    for line in content.splitlines():
        if line.startswith("SESSION_SECRET="):
            generated = line.partition("=")[2]
            assert len(generated) == 32
            assert all(c in "0123456789abcdef" for c in generated)
            break
    else:
        pytest.fail("SESSION_SECRET not found in generated file")


def test_pull_leaves_non_autogenerate_keys_blank_when_absent_from_gcloud(tmp_path: Path) -> None:
    """Keys not in GCloud and not auto_generate must be written as empty placeholders."""
    dest = tmp_path / ".secrets.prod"

    with (
        mock.patch("vaultscribe.vault._ensure_secrets_ignored"),
        mock.patch("vaultscribe.vault._parse_schema", return_value=_SCHEMA),
        mock.patch("vaultscribe.vault._get_env_config", return_value=_ENV_CONF),
        mock.patch("vaultscribe.vault._get_secrets_path", return_value=dest),
        mock.patch("vaultscribe.vault._try_fetch_from_gcloud", return_value=FlatSecrets({})),
    ):
        vs_vault._pull(_ENV_NAME)

    content = dest.read_text()
    for line in content.splitlines():
        if line.startswith("DB_PASSWORD="):
            assert line == "DB_PASSWORD=", f"Expected empty placeholder, got: {line!r}"
        if line.startswith("API_URL="):
            assert line == "API_URL=", f"Expected empty placeholder, got: {line!r}"


def test_pull_creates_blank_template_when_gcloud_slot_missing(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    """When the GCloud slot does not exist yet, pull must produce a blank template.

    # This is the first-time bootstrap case: the project exists in the schema
    # but has never been pushed to GCloud. Pull should give the user a template
    # to fill in rather than failing.
    """
    dest = tmp_path / ".secrets.prod"

    with (
        mock.patch("vaultscribe.vault._ensure_secrets_ignored"),
        mock.patch("vaultscribe.vault._parse_schema", return_value=_SCHEMA),
        mock.patch("vaultscribe.vault._get_env_config", return_value=_ENV_CONF),
        mock.patch("vaultscribe.vault._get_secrets_path", return_value=dest),
        mock.patch("vaultscribe.vault._try_fetch_from_gcloud", return_value=None),
    ):
        vs_vault._pull(_ENV_NAME)

    # File must exist even though GCloud had nothing
    assert dest.exists()
    # A warning must be printed so the user understands what happened
    assert "not found" in capsys.readouterr().err
