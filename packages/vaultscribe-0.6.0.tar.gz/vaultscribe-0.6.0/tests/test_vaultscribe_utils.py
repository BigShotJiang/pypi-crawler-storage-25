"""Tests for Vaultscribe utility functions."""

import pytest

from vaultscribe.utils import to_camel_case, to_snake_case


@pytest.mark.parametrize(
    ("input_str", "expected"),
    [
        ("PascalCase", "pascal_case"),
        ("camelCase", "camel_case"),
        ("snake_case", "snake_case"),
        ("Simple", "simple"),
        ("already_snake_case", "already_snake_case"),
        ("StringWithNumbers123", "string_with_numbers123"),
        ("HTTPClient", "http_client"),
        ("MyHTTPClient", "my_http_client"),
        ("the_snake_case_string", "the_snake_case_string"),
        ("A", "a"),
        ("ABC", "abc"),
        ("aB", "a_b"),
        ("special_case", "special_case"),
    ],
)
def test_to_snake_case(input_str: str, expected: str) -> None:
    """Test converting strings to snake_case."""
    assert to_snake_case(input_str) == expected


@pytest.mark.parametrize(
    ("input_str", "expected"),
    [
        ("snake_case", "snakeCase"),
        ("already_snake_case", "alreadySnakeCase"),
        ("simple", "simple"),
        ("the_snake_case_string", "theSnakeCaseString"),
        ("a_b_c", "aBC"),
        ("v1_secret", "v1Secret"),
        ("a", "a"),
        ("", ""),
    ],
)
def test_to_camel_case(input_str: str, expected: str) -> None:
    """Test converting strings to camelCase."""
    assert to_camel_case(input_str) == expected


@pytest.mark.parametrize(
    "input_str",
    [
        "PascalCase",
        "camelCase",
        "snake_case",
        "HTTPClient",
        "v1_secret",
    ],
)
def test_idempotency_and_stability(input_str: str) -> None:
    """Test idempotency and stable compositions of utility functions."""
    # to_snake_case is idempotent
    snake = to_snake_case(input_str)
    assert to_snake_case(snake) == snake

    # to_snake_case(to_camel_case(s)) is stable for snake_case results
    # (Note: to_camel_case is lossy if input isn't snake_case, but the result
    # of the composition is stable)
    f_x = to_snake_case(to_camel_case(snake))
    assert to_snake_case(to_camel_case(f_x)) == f_x

    # to_camel_case(to_snake_case(s)) is the canonical way to get stable camelCase
    g_x = to_camel_case(to_snake_case(input_str))
    assert to_camel_case(to_snake_case(g_x)) == g_x
