"""Snapshot tests for Python (pydantic) code generation.

White-box tests: call the scriber directly with a known fixture and assert
that the generated output matches a stored golden file.

To regenerate the snapshot after an intentional change to the scriber:
    UPDATE_SNAPSHOTS=1 uv run pytest scripts/tests/test_vaultscribe_codegen_python.py
"""

from __future__ import annotations

import importlib.util
import json
import os
import types
from pathlib import Path

import pytest

from vaultscribe.codegen.main import Field
from vaultscribe.codegen.python_pydantic_scribe import PythonScribeConfig, _scribe_env_dev_vs_example, _scribe_python
from vaultscribe.vs_types import (
    AutoGenerateConfig,
    AutoGenerateType,
    EnvConfig,
    EnvName,
    SecretConfig,
    SecretKey,
    Sensitivity,
)

_SNAPSHOT_DIR = Path(__file__).parent / "snapshots"
_SNAPSHOT_PATH = _SNAPSHOT_DIR / "vs_secrets.py.snap"


def _fixture_fields() -> dict[SecretKey, Field]:
    """Minimal but representative field set for snapshot testing.

    Includes a secret with description+source, one with auto-generate, and
    one public key — covering the main branches in the scriber.
    """
    return {
        SecretKey("DATABASE_URL"): Field(
            config=SecretConfig(
                description="Primary database connection string.",
                source="Obtain from your database provider.",
                sync_targets=["backend"],
                auto_generate=None,
            ),
            sensitivity=Sensitivity.SECRET,
        ),
        SecretKey("JWT_SECRET"): Field(
            config=SecretConfig(
                description="JWT signing key.",
                source=None,
                sync_targets=["backend"],
                auto_generate=AutoGenerateConfig(type=AutoGenerateType.HEX, length=32),
            ),
            sensitivity=Sensitivity.SECRET,
        ),
        SecretKey("PUBLIC_API_URL"): Field(
            config=SecretConfig(
                description="Public URL of the backend API.",
                source=None,
                sync_targets=["backend"],
                auto_generate=None,
            ),
            sensitivity=Sensitivity.PUBLIC,
        ),
    }


def _fixture_envs() -> dict[EnvName, EnvConfig]:
    return {
        EnvName("dev"): EnvConfig(project="test-proj", slot="test-secrets-dev"),
        EnvName("prod"): EnvConfig(project="test-proj", slot="test-secrets-prod"),
    }


def test_python_codegen_snapshot(tmp_path: Path) -> None:
    """Generated vs_secrets.py must match the stored golden file.

    White-box: calls _scribe_python directly, bypassing toml parsing.
    """
    out = tmp_path / "vs_secrets.py"
    _scribe_python(
        output_path=out,
        fields=_fixture_fields(),
        envs=_fixture_envs(),
        config=PythonScribeConfig(source_depth=1, source="api/", overlay=".env.dev", secrets_env_var="BACKEND_API"),
        silent=True,
    )
    content = out.read_text()

    if os.environ.get("UPDATE_SNAPSHOTS"):
        _SNAPSHOT_DIR.mkdir(exist_ok=True)
        _SNAPSHOT_PATH.write_text(content)
        pytest.skip("Snapshot updated.")
    else:
        assert _SNAPSHOT_PATH.exists(), (
            f"Snapshot missing. Run with UPDATE_SNAPSHOTS=1 to create it:\n  {_SNAPSHOT_PATH}"
        )
        assert content == _SNAPSHOT_PATH.read_text(), (
            "Generated output differs from snapshot. Run with UPDATE_SNAPSHOTS=1 if the change is intentional."
        )


def test_env_dev_vs_example_snapshot(tmp_path: Path) -> None:
    """Generated .env.dev.vs_example must match the stored golden file.

    White-box: calls _scribe_env_dev_vs_example directly.
    Covers: secret fields, public fields, descriptions as comments.
    """
    _snapshot_path = _SNAPSHOT_DIR / "env_dev_vs_example.snap"
    out = tmp_path / ".env.dev.vs_example"
    _scribe_env_dev_vs_example(
        output_path=out,
        fields=_fixture_fields(),
        overlay_name=".env.dev",
        silent=True,
    )
    content = out.read_text()

    if os.environ.get("UPDATE_SNAPSHOTS"):
        _SNAPSHOT_DIR.mkdir(exist_ok=True)
        _snapshot_path.write_text(content)
        pytest.skip("Snapshot updated.")
    else:
        assert _snapshot_path.exists(), (
            f"Snapshot missing. Run with UPDATE_SNAPSHOTS=1 to create it:\n  {_snapshot_path}"
        )
        assert content == _snapshot_path.read_text(), (
            "Generated output differs from snapshot. Run with UPDATE_SNAPSHOTS=1 if the change is intentional."
        )


@pytest.fixture(scope="module")
def bundle_module(tmp_path_factory: pytest.TempPathFactory) -> types.ModuleType:
    """Generate vs_secrets.py and return the imported module.

    Used by _BundleSource runtime behaviour tests below. Generating once at
    module scope avoids re-running the scriber for each test.
    """
    tmp_path = tmp_path_factory.mktemp("generated")
    out = tmp_path / "vs_secrets.py"
    _scribe_python(
        output_path=out,
        fields=_fixture_fields(),
        envs=_fixture_envs(),
        config=PythonScribeConfig(source_depth=1, source="api/", overlay=".env.dev", secrets_env_var="BACKEND_API"),
        silent=True,
    )
    spec = importlib.util.spec_from_file_location("vs_secrets_generated", out)
    assert spec is not None and spec.loader is not None
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)  # type: ignore[union-attr]
    return mod


def test_bundle_not_set_returns_empty(monkeypatch: pytest.MonkeyPatch, bundle_module: types.ModuleType) -> None:
    """When BUNDLE_ENV_VAR is absent, _bundle() returns {} without error.

    Returning {} is correct — the bundle source is optional; other
    pydantic-settings sources (env files, individual env vars) take over.
    """
    monkeypatch.delenv("BACKEND_API", raising=False)
    source = bundle_module._BundleSource(bundle_module.VaultscribeSecretSettings)
    assert source._bundle() == {}


def test_bundle_malformed_json_raises(monkeypatch: pytest.MonkeyPatch, bundle_module: types.ModuleType) -> None:
    """When BUNDLE_ENV_VAR contains invalid JSON, _bundle() raises immediately.

    Logging and continuing would let the app start with no secrets, producing
    confusing downstream errors. Hard failure is intentional.
    """
    monkeypatch.setenv("BACKEND_API", "not-valid-json{{{")
    source = bundle_module._BundleSource(bundle_module.VaultscribeSecretSettings)
    with pytest.raises(json.JSONDecodeError):
        source._bundle()


def test_bundle_non_dict_json_raises(monkeypatch: pytest.MonkeyPatch, bundle_module: types.ModuleType) -> None:
    """When BUNDLE_ENV_VAR is valid JSON but not an object, _bundle() raises ValueError.

    A JSON array or scalar is a misconfiguration, not a recoverable state.
    """
    monkeypatch.setenv("BACKEND_API", json.dumps([1, 2, 3]))
    source = bundle_module._BundleSource(bundle_module.VaultscribeSecretSettings)
    with pytest.raises(ValueError, match="BACKEND_API must be a JSON object"):
        source._bundle()


def test_bundle_valid_returns_parsed_values(monkeypatch: pytest.MonkeyPatch, bundle_module: types.ModuleType) -> None:
    """When BUNDLE_ENV_VAR is a well-formed bundle, _bundle() returns the merged key/value map."""
    payload = json.dumps(
        {
            "secret": {"DATABASE_URL": "postgres://host/db", "JWT_SECRET": "s3cr3t"},
            "public": {"PUBLIC_API_URL": "https://api.example.com"},
        }
    )
    monkeypatch.setenv("BACKEND_API", payload)
    source = bundle_module._BundleSource(bundle_module.VaultscribeSecretSettings)
    result = source._bundle()
    assert result["database_url"] == "postgres://host/db"
    assert result["jwt_secret"] == "s3cr3t"
    assert result["public_api_url"] == "https://api.example.com"
