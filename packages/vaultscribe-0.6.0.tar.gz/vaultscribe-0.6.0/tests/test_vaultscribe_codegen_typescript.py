"""Snapshot tests for TypeScript (vite) code generation.

White-box tests: call the scribers directly with a known fixture and assert
that the generated output matches a stored golden file.

To regenerate snapshots after an intentional change to the scriber:
    UPDATE_SNAPSHOTS=1 uv run pytest scripts/tests/test_vaultscribe_codegen_typescript.py
"""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from vaultscribe.codegen.main import Field
from vaultscribe.codegen.typescript_vite_scribe import (
    TypescriptFieldSets,
    _scribe_env_development_vs_example,
    _scribe_pages_function,
    _scribe_typescript,
    _scribe_vite_plugin,
)
from vaultscribe.vs_types import (
    AutoGenerateConfig,
    AutoGenerateType,
    SecretConfig,
    SecretKey,
    Sensitivity,
)

_SNAPSHOT_DIR = Path(__file__).parent / "snapshots"
_RUNTIME_FUNCTION_PATH = "app/functions/vs-config.ts"


def _fixture_build_fields() -> dict[SecretKey, Field]:
    """PUBLIC field delivered at build time (VITE_* env var)."""
    return {
        SecretKey("ANALYTICS_ID"): Field(
            config=SecretConfig(
                description="Analytics tracking ID.",
                source="Obtain from your analytics provider.",
                sync_targets=["frontend:build"],
                auto_generate=None,
            ),
            sensitivity=Sensitivity.PUBLIC,
        ),
    }


def _fixture_runtime_fields() -> dict[SecretKey, Field]:
    """Mix of SECRET and PUBLIC fields delivered at runtime via Pages Function."""
    return {
        SecretKey("JWT_SECRET"): Field(
            config=SecretConfig(
                description="JWT signing key.",
                source=None,
                sync_targets=["frontend:runtime"],
                auto_generate=AutoGenerateConfig(type=AutoGenerateType.HEX, length=32),
            ),
            sensitivity=Sensitivity.SECRET,
        ),
        SecretKey("PUBLIC_API_URL"): Field(
            config=SecretConfig(
                description="Public URL of the backend API.",
                source=None,
                sync_targets=["frontend:runtime"],
                auto_generate=None,
            ),
            sensitivity=Sensitivity.PUBLIC,
        ),
    }


def test_typescript_codegen_snapshot(tmp_path: Path) -> None:
    """Generated vs_config.ts must match the stored golden file.

    White-box: calls _scribe_typescript directly.
    Covers: build PUBLIC fields (VITE_* exports), runtime fields (app_config_members),
    and the vsLoadConfig function (runtime_function_path provided).
    """
    _snapshot_path = _SNAPSHOT_DIR / "vs_config.ts.snap"
    out = tmp_path / "vs_config.ts"
    _scribe_typescript(
        output_path=out,
        field_sets=TypescriptFieldSets(
            build_fields=_fixture_build_fields(),
            runtime_fields=_fixture_runtime_fields(),
        ),
        runtime_function_path=_RUNTIME_FUNCTION_PATH,
        silent=True,
    )
    content = out.read_text()

    if os.environ.get("UPDATE_SNAPSHOTS"):
        _SNAPSHOT_DIR.mkdir(exist_ok=True)
        _snapshot_path.write_text(content)
        pytest.skip("Snapshot updated.")
    else:
        assert _snapshot_path.exists(), (
            f"Snapshot missing. Run with UPDATE_SNAPSHOTS=1 to create it:\n  {_snapshot_path}"
        )
        assert content == _snapshot_path.read_text(), (
            "Generated output differs from snapshot. Run with UPDATE_SNAPSHOTS=1 if the change is intentional."
        )


def test_vite_plugin_snapshot(tmp_path: Path) -> None:
    """Generated vs_vite_plugin.ts must match the stored golden file.

    White-box: calls _scribe_vite_plugin directly.
    Covers: build vars validation, dev vars validation, mock /vs-config endpoint.
    """
    _snapshot_path = _SNAPSHOT_DIR / "vs_vite_plugin.ts.snap"
    build_public = _fixture_build_fields()
    runtime_public = {k: f for k, f in _fixture_runtime_fields().items() if f.sensitivity == Sensitivity.PUBLIC}
    out = tmp_path / "vs_vite_plugin.ts"
    _scribe_vite_plugin(
        output_path=out,
        build_public_fields=build_public,
        runtime_public_fields=runtime_public,
        runtime_function_path=_RUNTIME_FUNCTION_PATH,
        silent=True,
    )
    content = out.read_text()

    if os.environ.get("UPDATE_SNAPSHOTS"):
        _SNAPSHOT_DIR.mkdir(exist_ok=True)
        _snapshot_path.write_text(content)
        pytest.skip("Snapshot updated.")
    else:
        assert _snapshot_path.exists(), (
            f"Snapshot missing. Run with UPDATE_SNAPSHOTS=1 to create it:\n  {_snapshot_path}"
        )
        assert content == _snapshot_path.read_text(), (
            "Generated output differs from snapshot. Run with UPDATE_SNAPSHOTS=1 if the change is intentional."
        )


def test_pages_function_snapshot(tmp_path: Path) -> None:
    """Generated pages function must match the stored golden file.

    White-box: calls _scribe_pages_function directly.
    Covers: Env interface, onRequest handler, camelCase field mapping.
    """
    _snapshot_path = _SNAPSHOT_DIR / "vs_pages_function.ts.snap"
    runtime_public = {k: f for k, f in _fixture_runtime_fields().items() if f.sensitivity == Sensitivity.PUBLIC}
    out = tmp_path / "config.ts"
    _scribe_pages_function(
        output_path=out,
        runtime_public_fields=runtime_public,
        silent=True,
    )
    content = out.read_text()

    if os.environ.get("UPDATE_SNAPSHOTS"):
        _SNAPSHOT_DIR.mkdir(exist_ok=True)
        _snapshot_path.write_text(content)
        pytest.skip("Snapshot updated.")
    else:
        assert _snapshot_path.exists(), (
            f"Snapshot missing. Run with UPDATE_SNAPSHOTS=1 to create it:\n  {_snapshot_path}"
        )
        assert content == _snapshot_path.read_text(), (
            "Generated output differs from snapshot. Run with UPDATE_SNAPSHOTS=1 if the change is intentional."
        )


def test_env_development_vs_example_snapshot(tmp_path: Path) -> None:
    """Generated .env.development.vs_example must match the stored golden file.

    White-box: calls _scribe_env_development_vs_example directly.
    Covers: build-time VITE_* vars, runtime vars, field descriptions as comments.
    """
    _snapshot_path = _SNAPSHOT_DIR / "env_development_vs_example.snap"
    build_public = _fixture_build_fields()
    runtime_public = {k: f for k, f in _fixture_runtime_fields().items() if f.sensitivity == Sensitivity.PUBLIC}
    out = tmp_path / ".env.development.vs_example"
    _scribe_env_development_vs_example(
        output_path=out,
        build_public_fields=build_public,
        runtime_public_fields=runtime_public,
        silent=True,
    )
    content = out.read_text()

    if os.environ.get("UPDATE_SNAPSHOTS"):
        _SNAPSHOT_DIR.mkdir(exist_ok=True)
        _snapshot_path.write_text(content)
        pytest.skip("Snapshot updated.")
    else:
        assert _snapshot_path.exists(), (
            f"Snapshot missing. Run with UPDATE_SNAPSHOTS=1 to create it:\n  {_snapshot_path}"
        )
        assert content == _snapshot_path.read_text(), (
            "Generated output differs from snapshot. Run with UPDATE_SNAPSHOTS=1 if the change is intentional."
        )
