from vaultscribe.bundle import _get_sectioned_env_content
from vaultscribe.vs_types import EnvConfig, EnvName, FlatSecrets, Schema, SecretConfig, SecretKey


def test_get_sectioned_env_content_includes_source() -> None:
    schema = Schema(
        project="test-project",
        environments={EnvName("prod"): EnvConfig(project="test-project", slot="test-slot")},
        secrets={
            SecretKey("SECRET_WITH_SOURCE"): SecretConfig(
                description="A secret with source", source="GCloud Secret Manager", sync_targets=[], auto_generate=None
            ),
            SecretKey("SECRET_WITHOUT_SOURCE"): SecretConfig(
                description="A secret without source", source=None, sync_targets=[], auto_generate=None
            ),
        },
        public={},
        targets={},
    )
    env_vars = FlatSecrets(
        {
            SecretKey("SECRET_WITH_SOURCE"): "val1",
            SecretKey("SECRET_WITHOUT_SOURCE"): "val2",
        }
    )

    content = _get_sectioned_env_content(env_vars, schema, "prod")

    assert "SECRET_WITH_SOURCE" in content
    assert "Description: A secret with source" in content
    assert "Source:      GCloud Secret Manager" in content

    assert "SECRET_WITHOUT_SOURCE" in content
    assert "Description: A secret without source" in content
    assert (
        "Source:" not in content.split("SECRET_WITHOUT_SOURCE")[1].split("#")[1]
    )  # Check it's not in the block for this secret

    # Check that it's in the header section
    lines = content.splitlines()
    found_with_source = False
    found_without_source = False

    for i, line in enumerate(lines):
        if "# SECRET_WITH_SOURCE" in line:
            assert "Description: A secret with source" in lines[i + 1]
            assert "Source:      GCloud Secret Manager" in lines[i + 2]
            found_with_source = True
        if "# SECRET_WITHOUT_SOURCE" in line:
            assert "Description: A secret without source" in lines[i + 1]
            assert "Source:" not in lines[i + 2]
            found_without_source = True

    assert found_with_source
    assert found_without_source
