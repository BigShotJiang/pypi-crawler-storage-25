import pytest

from vaultscribe import schema as vs_schema
from vaultscribe.vs_types import SecretConfig


def test_validate_python_keyword_as_secret_name(capsys: pytest.CaptureFixture[str]) -> None:
    """Verify error when a secret name is a Python keyword and synced to a Python target."""
    schema = {
        "gcloud_project_id": "test-proj",
        "envs": {"prod": {"slot": "test"}},
        "targets": {
            "backend": {
                "source": "api/",
                "flavour": "python:pydantic",
                "type": "gcloud_run",
            }
        },
        "secrets": {"def": SecretConfig(description="...", source=None, sync_targets=["backend"], auto_generate=None)},
    }
    with pytest.raises(SystemExit) as e:
        vs_schema._validate_schema_structure(schema)

    assert e.value.code == 1
    captured = capsys.readouterr()
    err_text = " ".join(captured.err.split())
    assert "cannot use Python keyword 'def' as a secret name" in err_text


def test_validate_python_keyword_after_snake_case(capsys: pytest.CaptureFixture[str]) -> None:
    """Verify error when a secret name becomes a Python keyword after to_snake conversion."""
    schema = {
        "gcloud_project_id": "test-proj",
        "envs": {"prod": {"slot": "test"}},
        "targets": {
            "backend": {
                "source": "api/",
                "flavour": "python:pydantic",
                "type": "gcloud_run",
            }
        },
        "secrets": {
            "Class": SecretConfig(description="...", source=None, sync_targets=["backend"], auto_generate=None)
        },
    }
    with pytest.raises(SystemExit) as e:
        vs_schema._validate_schema_structure(schema)

    assert e.value.code == 1
    captured = capsys.readouterr()
    err_text = " ".join(captured.err.split())
    # 'Class' becomes 'class' which is a keyword
    assert "cannot use Python keyword 'class' as a secret name" in err_text
