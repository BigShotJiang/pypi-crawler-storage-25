"""Repo-wide housekeeping checks."""

from __future__ import annotations

import re
from pathlib import Path

from vaultscribe.ui import _HINT_LABEL_WIDTH

_REPO_ROOT = Path(__file__).parents[1]
_SCAN_SUFFIXES = {".py", ".ts", ".md", ".html", ".toml", ".yml", ".yaml", ".json", ".txt"}
_EXCLUDE_DIRS = {".git", "__pycache__", ".venv", "node_modules", ".mypy_cache"}


def _scan_files() -> list[Path]:
    return [
        p
        for p in _REPO_ROOT.rglob("*")
        if p.is_file()
        and p.suffix in _SCAN_SUFFIXES
        and not any(exc in p.parts for exc in _EXCLUDE_DIRS)
        and p != Path(__file__)
    ]


def test_no_old_brand_vaultscribe_camel_case() -> None:
    """No file in the repo may contain the old 'VaultScribe' branding.

    # The correct spelling is 'Vaultscribe' (single word, one capital letter).
    # This test prevents accidental reintroduction via copy-paste or new files.
    """
    hits: list[str] = []
    for path in _scan_files():
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        for i, line in enumerate(text.splitlines(), start=1):
            if "VaultScribe" in line:
                hits.append(f"{path.relative_to(_REPO_ROOT)}:{i}: {line.strip()}")

    assert not hits, "Found old 'VaultScribe' branding — use 'Vaultscribe':\n" + "\n".join(hits)


def test_ui_hint_labels_fit_width() -> None:
    """Ensure all report_hint labels fit within _HINT_LABEL_WIDTH to preserve alignment.

    If a label is too long, it will push the content out and break the vertical alignment
    at column 19. If you must use a longer label, increase _HINT_LABEL_WIDTH in ui.py.
    """
    # Regex to find report_hint("Label:", ...)
    # Handles both single and double quotes
    pattern = re.compile(r"report_hint\s*\(\s*['\"]([^'\"]+)['\"]")

    hits: list[str] = []
    for path in _REPO_ROOT.rglob("src/vaultscribe/**/*.py"):
        text = path.read_text(encoding="utf-8")
        for i, line in enumerate(text.splitlines(), start=1):
            match = pattern.search(line)
            if match:
                label = match.group(1)
                if len(label) > _HINT_LABEL_WIDTH:
                    hits.append(
                        f"{path.relative_to(_REPO_ROOT)}:{i}: "
                        f"Label '{label}' is {len(label)} chars (max {_HINT_LABEL_WIDTH})"
                    )

    msg = (
        f"UI hint labels must not exceed {_HINT_LABEL_WIDTH} characters to maintain alignment.\n"
        "To fix this, either shorten the label or increase _HINT_LABEL_WIDTH in ui.py.\n"
    )
    assert not hits, msg + "\n".join(hits)
