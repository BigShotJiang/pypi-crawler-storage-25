import pytest

from vaultscribe import schema as vs_schema
from vaultscribe.vs_types import SecretConfig


def test_validate_secret_key_invalid_characters(capsys: pytest.CaptureFixture[str]) -> None:
    """Verify error when a secret name contains invalid characters."""
    schema = {
        "gcloud_project_id": "test-proj",
        "envs": {"prod": {"slot": "test"}},
        "targets": {
            "backend": {
                "source": "api/",
                "flavour": "python:pydantic",
                "type": "gcloud_run",
            }
        },
        "secrets": {"DB NAME": SecretConfig(description="...", source=None, sync_targets=None, auto_generate=None)},
    }
    with pytest.raises(SystemExit) as e:
        vs_schema._validate_schema_structure(schema)

    assert e.value.code == 1
    captured = capsys.readouterr()
    assert "Invalid characters in secret name 'DB NAME'" in captured.err
    # Split assertion to avoid brittle failures from console wrapping
    assert "Secret names must only contain" in captured.err
    assert "A-Z, a-z, 0-9" in captured.err


def test_validate_public_key_invalid_characters(capsys: pytest.CaptureFixture[str]) -> None:
    """Verify error when a public name contains invalid characters."""
    schema = {
        "gcloud_project_id": "test-proj",
        "envs": {"prod": {"slot": "test"}},
        "targets": {
            "backend": {
                "source": "api/",
                "flavour": "python:pydantic",
                "type": "gcloud_run",
            }
        },
        "public": {"API$KEY": SecretConfig(description="...", source=None, sync_targets=None, auto_generate=None)},
    }
    with pytest.raises(SystemExit) as e:
        vs_schema._validate_schema_structure(schema)

    assert e.value.code == 1
    captured = capsys.readouterr()
    assert "Invalid characters in secret name 'API$KEY'" in captured.err


def test_validate_valid_key_characters() -> None:
    """Verify that valid characters are accepted."""
    schema = {
        "gcloud_project_id": "test-proj",
        "envs": {"prod": {"slot": "test"}},
        "targets": {
            "backend": {
                "source": "api/",
                "flavour": "python:pydantic",
                "type": "gcloud_run",
            }
        },
        "secrets": {
            "DB.HOST-NAME_123": SecretConfig(description="...", source=None, sync_targets=None, auto_generate=None)
        },
        "public": {"site-url.v1": SecretConfig(description="...", source=None, sync_targets=None, auto_generate=None)},
    }
    # Should not raise
    vs_schema._validate_schema_structure(schema)
