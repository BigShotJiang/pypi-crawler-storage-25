from pathlib import Path
from unittest import mock

import pytest

from vaultscribe import codegen as vs_codegen
from vaultscribe import schema as vs_schema
from vaultscribe.vs_types import (
    EnvConfig,
    EnvName,
    Flavour,
    GcloudRunTargetConfig,
    Schema,
    SecretConfig,
    SecretKey,
    TargetName,
)


def test_validate_missing_project(capsys: pytest.CaptureFixture[str]) -> None:
    """Verify error when root 'gcloud_project_id' is missing."""
    schema = {
        "envs": {"prod": {"slot": "test"}},
        "targets": {
            "backend": {
                "source": "api/",
                "flavour": "python:pydantic",
                "type": "gcloud_run",
            }
        },
    }
    with pytest.raises(SystemExit) as e:
        vs_schema._validate_schema_structure(schema)

    assert e.value.code == 1
    captured = capsys.readouterr()
    assert "Missing global 'gcloud_project_id'" in captured.err


def test_validate_missing_envs(capsys: pytest.CaptureFixture[str]) -> None:
    """Verify error when 'envs' block is missing or empty."""
    schema = {
        "gcloud_project_id": "test-proj",
        "targets": {
            "backend": {
                "source": "api/",
                "flavour": "python:pydantic",
                "type": "gcloud_run",
            }
        },
    }
    with pytest.raises(SystemExit) as e:
        vs_schema._validate_schema_structure(schema)

    assert e.value.code == 1
    captured = capsys.readouterr()
    assert "No environments defined" in captured.err


def test_validate_missing_env_slot(capsys: pytest.CaptureFixture[str]) -> None:
    """Verify error when an environment is missing its 'slot'."""
    schema = {
        "gcloud_project_id": "test-proj",
        "envs": {"prod": {}},  # Missing slot
        "targets": {
            "backend": {
                "source": "api/",
                "flavour": "python:pydantic",
                "type": "gcloud_run",
            }
        },
    }
    with pytest.raises(SystemExit) as e:
        vs_schema._validate_schema_structure(schema)

    assert e.value.code == 1
    captured = capsys.readouterr()
    assert "Environment 'prod' is missing a 'slot' name" in captured.err


def test_validate_missing_target_fields(capsys: pytest.CaptureFixture[str]) -> None:
    """Verify error when target is missing mandatory fields.

    # 'type' is validated first and is always required; 'source' and 'flavour'
    # are validated only for non-script types.
    """
    schema = {
        "gcloud_project_id": "test-proj",
        "envs": {"prod": {"slot": "test"}},
        "targets": {"backend": {"source": "api/"}},  # Missing flavour and type
    }
    with pytest.raises(SystemExit) as e:
        vs_schema._validate_schema_structure(schema)

    assert e.value.code == 1
    captured = capsys.readouterr()
    assert "Target 'backend' is missing mandatory field 'type'" in captured.err


def test_validate_unsupported_flavour(capsys: pytest.CaptureFixture[str]) -> None:
    """Verify error for unknown flavour."""
    schema = {
        "gcloud_project_id": "test-proj",
        "envs": {"prod": {"slot": "test"}},
        "targets": {"backend": {"source": "api/", "flavour": "banana", "type": "gcloud_run"}},
    }
    with pytest.raises(SystemExit) as e:
        vs_schema._validate_schema_structure(schema)

    assert e.value.code == 1
    captured = capsys.readouterr()
    assert "Unsupported flavour 'banana'" in captured.err


def test_validate_stale_override(capsys: pytest.CaptureFixture[str]) -> None:
    """Verify error when target has override for undefined env (the 'staging' case)."""
    schema = {
        "gcloud_project_id": "test-proj",
        "envs": {"prod": {"slot": "test"}},  # Staging is NOT here
        "targets": {
            "frontend": {
                "source": "app/",
                "flavour": "typescript:vite",
                "type": "cloudflare_pages",
                "project_name": "my-app",
                "auth_token": "${CLOUDFLARE_API_TOKEN}",
                "account_id": "${CLOUDFLARE_ACCOUNT_ID}",
                "staging": {"project_name": "stale"},  # Undefined env
            }
        },
    }
    with pytest.raises(SystemExit) as e:
        vs_schema._validate_schema_structure(schema)

    assert e.value.code == 1
    captured = capsys.readouterr()
    err_text = " ".join(captured.err.split())
    assert "has an override for undefined environment 'staging'" in err_text
    assert "Remove 'targets.frontend.staging.project_name'" in err_text


def test_validate_invalid_type_flavour_combination(
    capsys: pytest.CaptureFixture[str],
) -> None:
    """Verify error when flavour does not match target type."""
    schema = {
        "gcloud_project_id": "test-proj",
        "envs": {"prod": {"slot": "test"}},
        "targets": {
            "bad_target": {
                "source": "api/",
                "type": "gcloud_run",
                "flavour": "typescript:vite",  # Invalid for gcloud_run
            }
        },
    }
    with pytest.raises(SystemExit) as e:
        vs_schema._validate_schema_structure(schema)

    assert e.value.code == 1
    err_text = " ".join(capsys.readouterr().err.split())
    assert "has invalid flavour 'typescript:vite'" in err_text
    assert "Supported flavours for gcloud_run: 'python:pydantic'" in err_text


def test_validate_sync_target_mismatch(capsys: pytest.CaptureFixture[str]) -> None:
    """Verify error when sync_targets refers to a non-existent target."""
    schema = Schema(
        project="test-proj",
        environments={EnvName("prod"): EnvConfig(project="test-proj", slot="test")},
        secrets={
            SecretKey("DB_URL"): SecretConfig(
                description="...",
                sync_targets=["ghost"],  # Target 'ghost' does not exist
                source=None,
                auto_generate=None,
            )
        },
        public={},
        targets={
            TargetName("backend"): GcloudRunTargetConfig(
                name="backend",
                source="api/",
                flavour=Flavour.PYTHON_PYDANTIC,
                secrets_env_var="VS_SECRETS",
            )
        },
    )
    # codegen does this part of validation
    with (
        mock.patch("vaultscribe.codegen.main._parse_schema", return_value=schema),
        pytest.raises(SystemExit),
    ):
        vs_codegen.codegen()


def test_malformed_toml(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    """Verify graceful handling of TOML syntax errors."""
    bad_toml = "gcloud_project = 'test' \n [envs.prod \n slot = 'oops'"  # Missing closing bracket
    toml_file = tmp_path / "vaultscribe.toml"
    toml_file.write_text(bad_toml)

    with (
        mock.patch("vaultscribe.vs_types._SCHEMA_FILE", toml_file),
        pytest.raises(SystemExit),
    ):
        vs_schema._parse_schema()


def test_validate_gcloud_run_target_rejects_qualifier(
    capsys: pytest.CaptureFixture[str],
) -> None:
    """Verify error when a sync_target for a gcloud_run target uses a delivery qualifier.

    # GCloud Run targets use a single secret bundle read at runtime — there is no
    # distinct build/runtime delivery mechanism. A qualifier like ':runtime' is
    # architecturally meaningless and should be rejected rather than silently ignored.
    """
    schema = {
        "gcloud_project_id": "test-proj",
        "envs": {"prod": {"slot": "test"}},
        "targets": {
            "backend": {
                "source": "api/",
                "flavour": "python:pydantic",
                "type": "gcloud_run",
            }
        },
        "secrets": {
            "DB_URL": SecretConfig(
                description="...",
                sync_targets=["backend:runtime"],  # Qualifier not valid for gcloud_run
                source=None,
                auto_generate=None,
            )
        },
    }
    with pytest.raises(SystemExit) as e:
        vs_schema._validate_schema_structure(schema)

    assert e.value.code == 1
    err_text = " ".join(capsys.readouterr().err.split())
    assert "delivery qualifier ':runtime'" in err_text
    assert "backend" in err_text


def test_cloudflare_pages_rejects_secrets() -> None:
    """Verify error when a [secrets] key is synced to a cloudflare_pages target.

    # Both ':build' and ':runtime' delivery paths expose values to the browser,
    # so no [secrets] key may ever be routed to a cloudflare_pages target.
    # This applies regardless of delivery qualifier.
    """
    base_target = {
        "source": "app/src/",
        "flavour": "typescript:vite",
        "type": "cloudflare_pages",
        "project_name": "my-app",
        "auth_token": "${CF_TOKEN}",
        "account_id": "${CF_ACCOUNT}",
        "runtime_function_path": "functions/vs-config.ts",
    }
    for qualifier in [":build", ":runtime"]:
        schema = {
            "gcloud_project_id": "test-proj",
            "envs": {"prod": {"slot": "test"}},
            "targets": {"frontend": base_target},
            "secrets": {
                "DB_URL": SecretConfig(
                    description="...",
                    sync_targets=[f"frontend{qualifier}"],
                    source=None,
                    auto_generate=None,
                )
            },
        }
        with pytest.raises(SystemExit) as e:
            vs_schema._validate_schema_structure(schema)

        assert e.value.code == 1


def test_auto_generate_source_default() -> None:
    """Verify that auto-generated secrets get a default source if not provided."""
    from vaultscribe.parsing import _parse_secret_config

    # 1. No source provided -> Default assigned
    data_1 = {"auto_generate": {"type": "hex", "length": 32}}
    config_1 = _parse_secret_config("KEY1", data_1)
    assert config_1.source == "Generated by Vaultscribe."

    # 2. Source provided -> Respect it
    data_2 = {
        "auto_generate": {"type": "hex", "length": 32},
        "source": "Manual entry",
    }
    config_2 = _parse_secret_config("KEY2", data_2)
    assert config_2.source == "Manual entry"

    # 3. Not auto-generated -> No default source
    data_3 = {"description": "..."}
    config_3 = _parse_secret_config("KEY3", data_3)
    assert config_3.source is None


def _script_schema_base() -> dict:
    return {
        "gcloud_project_id": "test-proj",
        "envs": {"prod": {"slot": "test"}},
        "targets": {"alembic_migration": {"type": "script"}},
        "secrets": {
            "DATABASE_URL": SecretConfig(
                description="DB connection string.",
                source=None,
                sync_targets=["alembic_migration"],
                auto_generate=None,
            )
        },
        "public": {},
    }


def test_script_target_valid() -> None:
    """A script target with no source or flavour must pass validation."""
    # Should not raise — no exception or SystemExit expected.
    vs_schema._validate_schema_structure(_script_schema_base())


def test_script_target_rejects_delivery_qualifier(capsys: pytest.CaptureFixture[str]) -> None:
    """A delivery qualifier on a script sync_target must be rejected.

    # Script targets inject secrets as plain env vars with no delivery routing.
    # Qualifiers like :build or :runtime are meaningless and likely a user mistake.
    """
    schema = _script_schema_base()
    schema["secrets"]["DATABASE_URL"] = SecretConfig(
        description="DB connection string.",
        source=None,
        sync_targets=["alembic_migration:build"],
        auto_generate=None,
    )
    with pytest.raises(SystemExit) as e:
        vs_schema._validate_schema_structure(schema)

    assert e.value.code == 1
    err = capsys.readouterr().err
    assert "delivery qualifier" in err
    assert "alembic_migration" in err


def _gh_schema_base(
    target_extras: dict | None = None,
    envs: dict | None = None,
) -> dict:
    """Schema dict with one github_actions target. Extras override target fields."""
    target_conf = {"type": "github_actions", "repo": "owner/repo", "vs_env": "prod"}
    if target_extras:
        target_conf.update(target_extras)
    return {
        "gcloud_project_id": "test-proj",
        "envs": envs or {"prod": {"slot": "test-prod"}, "dev": {"slot": "test-dev"}},
        "targets": {"gh_prod": target_conf},
        "secrets": {
            "DEPLOY_TOKEN": SecretConfig(
                description=None,
                source=None,
                sync_targets=["gh_prod"],
                auto_generate=None,
            )
        },
        "public": {},
    }


def test_github_actions_target_valid_with_explicit_vs_env() -> None:
    """A github_actions target with repo and explicit vs_env passes validation."""
    vs_schema._validate_schema_structure(_gh_schema_base())


def test_github_actions_target_valid_with_environment_inference() -> None:
    """Environment matching a vs env name (case-insensitive) infers vs_env."""
    schema = _gh_schema_base(target_extras={"environment": "prod", "vs_env": None})
    # Drop None so we test inference rather than explicit-and-invalid
    del schema["targets"]["gh_prod"]["vs_env"]
    vs_schema._validate_schema_structure(schema)


def test_github_actions_target_missing_repo(capsys: pytest.CaptureFixture[str]) -> None:
    """A github_actions target without repo fails validation."""
    schema = _gh_schema_base()
    del schema["targets"]["gh_prod"]["repo"]

    with pytest.raises(SystemExit) as e:
        vs_schema._validate_schema_structure(schema)

    assert e.value.code == 1
    err_text = " ".join(capsys.readouterr().err.split())
    assert "missing mandatory field 'repo'" in err_text


def test_github_actions_target_rejects_delivery_qualifier(capsys: pytest.CaptureFixture[str]) -> None:
    """A delivery qualifier on a github_actions sync_target must be rejected."""
    schema = _gh_schema_base()
    schema["secrets"]["DEPLOY_TOKEN"] = SecretConfig(
        description=None,
        source=None,
        sync_targets=["gh_prod:build"],
        auto_generate=None,
    )
    with pytest.raises(SystemExit) as e:
        vs_schema._validate_schema_structure(schema)

    assert e.value.code == 1
    err_text = " ".join(capsys.readouterr().err.split())
    assert "delivery qualifier" in err_text
    assert "gh_prod" in err_text


def test_github_actions_target_unknown_vs_env(capsys: pytest.CaptureFixture[str]) -> None:
    """vs_env that doesn't name a defined environment is rejected with available list."""
    schema = _gh_schema_base(target_extras={"vs_env": "staging"})

    with pytest.raises(SystemExit) as e:
        vs_schema._validate_schema_structure(schema)

    assert e.value.code == 1
    err_text = " ".join(capsys.readouterr().err.split())
    assert "vs_env='staging'" in err_text
    assert "'prod'" in err_text  # available env should be listed


def test_github_actions_target_fuzzy_environment_suggests_vs_env(
    capsys: pytest.CaptureFixture[str],
) -> None:
    """environment='production' with [envs.prod] fails with a precise vs_env suggestion."""
    schema = _gh_schema_base(target_extras={"environment": "production"})
    del schema["targets"]["gh_prod"]["vs_env"]

    with pytest.raises(SystemExit) as e:
        vs_schema._validate_schema_structure(schema)

    assert e.value.code == 1
    err_text = " ".join(capsys.readouterr().err.split())
    assert "production" in err_text
    assert 'vs_env = "prod"' in err_text


def test_github_actions_target_no_match_environment_lists_available(
    capsys: pytest.CaptureFixture[str],
) -> None:
    """An unrelated environment value lists available envs in the error."""
    schema = _gh_schema_base(target_extras={"environment": "qa"})
    del schema["targets"]["gh_prod"]["vs_env"]

    with pytest.raises(SystemExit) as e:
        vs_schema._validate_schema_structure(schema)

    assert e.value.code == 1
    err_text = " ".join(capsys.readouterr().err.split())
    assert "no matching vs env" in err_text
    assert "'prod'" in err_text
    assert "'dev'" in err_text


def test_github_actions_target_missing_both_routing_fields(
    capsys: pytest.CaptureFixture[str],
) -> None:
    """A github_actions target with neither vs_env nor environment fails validation."""
    schema = _gh_schema_base()
    del schema["targets"]["gh_prod"]["vs_env"]

    with pytest.raises(SystemExit) as e:
        vs_schema._validate_schema_structure(schema)

    assert e.value.code == 1
    err_text = " ".join(capsys.readouterr().err.split())
    assert "must declare either 'vs_env' or 'environment'" in err_text
