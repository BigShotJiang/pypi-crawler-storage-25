from unittest import mock

from vaultscribe.init_prompts import _discover_github_repo


def test_discover_github_repo_https() -> None:
    mock_result = mock.Mock()
    mock_result.returncode = 0
    mock_result.stdout = "https://github.com/owner/repo.git\n"

    with mock.patch("vaultscribe.init_prompts.subprocess.run", return_value=mock_result):
        assert _discover_github_repo() == "owner/repo"


def test_discover_github_repo_ssh() -> None:
    mock_result = mock.Mock()
    mock_result.returncode = 0
    mock_result.stdout = "git@github.com:owner/repo.git\n"

    with mock.patch("vaultscribe.init_prompts.subprocess.run", return_value=mock_result):
        assert _discover_github_repo() == "owner/repo"


def test_discover_github_repo_no_extension() -> None:
    mock_result = mock.Mock()
    mock_result.returncode = 0
    mock_result.stdout = "https://github.com/owner/repo\n"

    with mock.patch("vaultscribe.init_prompts.subprocess.run", return_value=mock_result):
        assert _discover_github_repo() == "owner/repo"


def test_discover_github_repo_not_github() -> None:
    mock_result = mock.Mock()
    mock_result.returncode = 0
    mock_result.stdout = "https://gitlab.com/owner/repo.git\n"

    with mock.patch("vaultscribe.init_prompts.subprocess.run", return_value=mock_result):
        assert _discover_github_repo() is None


def test_discover_github_repo_git_error() -> None:
    mock_result = mock.Mock()
    mock_result.returncode = 1
    mock_result.stderr = "fatal: not a git repository"

    with mock.patch("vaultscribe.init_prompts.subprocess.run", return_value=mock_result):
        assert _discover_github_repo() is None


def test_discover_github_repo_exception() -> None:
    with mock.patch("vaultscribe.init_prompts.subprocess.run", side_effect=RuntimeError("env error")):
        assert _discover_github_repo() is None
