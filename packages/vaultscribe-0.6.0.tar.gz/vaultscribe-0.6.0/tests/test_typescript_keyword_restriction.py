import pytest

from vaultscribe import schema as vs_schema
from vaultscribe.vs_types import SecretConfig


def test_validate_ts_keyword_as_secret_name(capsys: pytest.CaptureFixture[str]) -> None:
    """Verify error when a secret name is a TS keyword and synced to a TS target."""
    schema = {
        "gcloud_project_id": "test-proj",
        "envs": {"prod": {"slot": "test"}},
        "targets": {
            "frontend": {
                "source": "app/",
                "flavour": "typescript:vite",
                "type": "cloudflare_pages",
                "project_name": "my-app",
                "auth_token": "${CF_TOKEN}",
                "account_id": "${CF_ACCOUNT}",
            }
        },
        "public": {
            "function": SecretConfig(
                description="...", source=None, sync_targets=["frontend:build"], auto_generate=None
            )
        },
    }
    with pytest.raises(SystemExit) as e:
        vs_schema._validate_schema_structure(schema)

    assert e.value.code == 1
    captured = capsys.readouterr()
    err_text = " ".join(captured.err.split())
    assert "cannot use TypeScript keyword 'function' as a secret name" in err_text


def test_validate_ts_keyword_after_camel_case(capsys: pytest.CaptureFixture[str]) -> None:
    """Verify error when a secret name becomes a TS keyword after to_camel conversion."""
    schema = {
        "gcloud_project_id": "test-proj",
        "envs": {"prod": {"slot": "test"}},
        "targets": {
            "frontend": {
                "source": "app/",
                "flavour": "typescript:vite",
                "type": "cloudflare_pages",
                "project_name": "my-app",
                "auth_token": "${CF_TOKEN}",
                "account_id": "${CF_ACCOUNT}",
                "runtime_function_path": "functions/vs-config.ts",
            }
        },
        "public": {
            "DEFAULT": SecretConfig(
                description="...", source=None, sync_targets=["frontend:runtime"], auto_generate=None
            )
        },
    }
    with pytest.raises(SystemExit) as e:
        vs_schema._validate_schema_structure(schema)

    assert e.value.code == 1
    captured = capsys.readouterr()
    err_text = " ".join(captured.err.split())
    # 'DEFAULT' becomes 'default' which is a keyword
    assert "cannot use TypeScript keyword 'default' as a secret name" in err_text


def test_validate_ts_keyword_direct_camel(capsys: pytest.CaptureFixture[str]) -> None:
    schema = {
        "gcloud_project_id": "test-proj",
        "envs": {"prod": {"slot": "test"}},
        "targets": {
            "frontend": {
                "source": "app/",
                "flavour": "typescript:vite",
                "type": "cloudflare_pages",
                "project_name": "my-app",
                "auth_token": "${CF_TOKEN}",
                "account_id": "${CF_ACCOUNT}",
                "runtime_function_path": "functions/vs-config.ts",
            }
        },
        "public": {
            "interface": SecretConfig(
                description="...", source=None, sync_targets=["frontend:runtime"], auto_generate=None
            )
        },
    }
    with pytest.raises(SystemExit) as e:
        vs_schema._validate_schema_structure(schema)

    assert e.value.code == 1
    captured = capsys.readouterr()
    err_text = " ".join(captured.err.split())
    assert "cannot use TypeScript keyword 'interface' as a secret name" in err_text
