import argparse
import importlib
import json
import subprocess
import sys
from pathlib import Path
from unittest import mock

import pytest

from vaultscribe import cli as vs_cli
from vaultscribe import display as vs_display
from vaultscribe import gcloud as vs_gcloud
from vaultscribe import generator as vs_generator
from vaultscribe import iam as vs_iam
from vaultscribe import run as vs_run
from vaultscribe import schema as vs_schema
from vaultscribe import shell as vs_shell
from vaultscribe import sync as vs_sync
from vaultscribe.display import _LONG_SECRET_THRESHOLD, _mask
from vaultscribe.vs_types import (
    CloudflareEnvOverride,
    CloudflarePagesTargetConfig,
    EnvConfig,
    EnvName,
    Flavour,
    GcloudRunTargetConfig,
    GitHubActionsTargetConfig,
    Schema,
    ScriptTargetConfig,
    SecretConfig,
    SecretKey,
    TargetName,
)

# ---------------------------------------------------------------------------
# Display Tests
# ---------------------------------------------------------------------------


def test_mask_long_value_shows_four_chars_each_end() -> None:
    # Values longer than 12 chars reveal 4 from each end
    assert _mask("abcdefghijklmnop") == "abcd...mnop"


def test_mask_short_value_shows_one_char_each_end() -> None:
    # Values 12 chars or fewer reveal only the first and last character
    assert _mask("abc123") == "a...3"
    assert _mask("xy") == "x...y"


def test_mask_boundary_at_threshold() -> None:
    # Exactly at threshold (12 chars) → short path: first and last char only
    # "abcdefghijkl" → "a...l"
    at_threshold = "abcdefghijkl"
    assert len(at_threshold) == _LONG_SECRET_THRESHOLD
    assert _mask(at_threshold) == "a...l"

    # One over threshold (13 chars) → long path: four chars from each end
    # "abcdefghijklm" → "abcd...jklm"
    over_threshold = "abcdefghijklm"
    assert len(over_threshold) == _LONG_SECRET_THRESHOLD + 1
    assert _mask(over_threshold) == "abcd...jklm"


def test_show_all_renders_empty_values(capsys: pytest.CaptureFixture[str]) -> None:
    """Empty strings and missing keys must display as <empty>, not ********.

    # This catches the case where a secret slot exists in GCloud but a key
    # was never populated — masking it as ******** falsely implies a value.
    """
    from vaultscribe.vs_types import SecretConfig

    def empty_conf() -> SecretConfig:
        return SecretConfig(description=None, source=None, sync_targets=[], auto_generate=None)

    schema = Schema(
        project="test-project",
        environments={EnvName("prod"): EnvConfig(project="test-project", slot="test-slot")},
        secrets={
            SecretKey("SECRET_KEY"): empty_conf(),
            SecretKey("EMPTY_KEY"): empty_conf(),
        },
        public={},
        targets={},
    )
    env_conf = EnvConfig(project="test-project", slot="test-slot")
    # EMPTY_KEY is missing from the bundle entirely; SECRET_KEY has a real value.
    # Use a short value (≤12 chars) so the masking path produces "********".
    env_vars = {SecretKey("SECRET_KEY"): "abc123"}

    with (
        mock.patch("vaultscribe.display.codegen"),
        mock.patch("vaultscribe.display._parse_schema", return_value=schema),
        mock.patch("vaultscribe.display._get_env_config", return_value=env_conf),
        mock.patch("vaultscribe.display._fetch_from_gcloud", return_value=env_vars),
    ):
        vs_display._show_cmd("prod", show_all=True)

    captured = capsys.readouterr()
    lines = captured.out.splitlines()
    empty_key_line = next((line for line in lines if line.startswith("EMPTY_KEY")), None)
    secret_key_line = next((line for line in lines if line.startswith("SECRET_KEY")), None)

    assert empty_key_line is not None, "EMPTY_KEY row not found in output"
    assert "<empty>" in empty_key_line, f"Expected <empty> for missing key, got: {empty_key_line!r}"
    assert secret_key_line is not None, "SECRET_KEY row not found in output"
    # Short values show first and last char only (a...3), never the full value
    assert "a...3" in secret_key_line, f"Expected partial reveal for present key, got: {secret_key_line!r}"
    assert "abc123" not in secret_key_line


def test_show_all_renders_empty_string_value(
    capsys: pytest.CaptureFixture[str],
) -> None:
    """An empty string stored in GCloud must also display as <empty>.

    # GCloud can store "" as a value — this is distinct from a missing key
    # but must be treated the same way in the display.
    """
    from vaultscribe.vs_types import SecretConfig

    def empty_conf() -> SecretConfig:
        return SecretConfig(description=None, source=None, sync_targets=[], auto_generate=None)

    schema = Schema(
        project="test-project",
        environments={EnvName("prod"): EnvConfig(project="test-project", slot="test-slot")},
        secrets={SecretKey("EMPTY_STRING_KEY"): empty_conf()},
        public={},
        targets={},
    )
    env_conf = EnvConfig(project="test-project", slot="test-slot")
    env_vars = {SecretKey("EMPTY_STRING_KEY"): ""}  # Explicitly empty string

    with (
        mock.patch("vaultscribe.display.codegen"),
        mock.patch("vaultscribe.display._parse_schema", return_value=schema),
        mock.patch("vaultscribe.display._get_env_config", return_value=env_conf),
        mock.patch("vaultscribe.display._fetch_from_gcloud", return_value=env_vars),
    ):
        vs_display._show_cmd("prod", show_all=True)

    captured = capsys.readouterr()
    lines = captured.out.splitlines()
    key_line = next((line for line in lines if line.startswith("EMPTY_STRING_KEY")), None)

    assert key_line is not None, "EMPTY_STRING_KEY row not found in output"
    assert "<empty>" in key_line, f"Expected <empty> for empty string value, got: {key_line!r}"
    assert "********" not in key_line


# ---------------------------------------------------------------------------
# Independence Tests (Prevent Bootstrap Paradox)
# ---------------------------------------------------------------------------


def test_cli_is_independent_of_generated_code() -> None:
    """Verify that the CLI can be imported even if vs_secrets is missing.

    # This ensures that the tool can always run to FIX broken bindings.
    """
    # 1. Capture the original state
    original_path = sys.path.copy()
    original_modules = sys.modules.copy()

    try:
        # 2. Remove vs_secrets from loaded modules if it exists
        if "vs_secrets" in sys.modules:
            del sys.modules["vs_secrets"]

        # 3. Force a reload of the cli module
        importlib.reload(vs_cli)

        # 4. Success means it didn't crash on import
        assert True
    finally:
        # Restore environment
        sys.path = original_path
        sys.modules.update(original_modules)


# ---------------------------------------------------------------------------
# Generation Tests (Auto-Secrets)
# ---------------------------------------------------------------------------


def test_generate_secret_value() -> None:
    """Verify that generate_secret_value correctly interprets typed config."""
    from vaultscribe.vs_types import AutoGenerateConfig, AutoGenerateType

    # 1. Hex generation (32 chars = 16 bytes)
    hex_len = 32
    config = AutoGenerateConfig(type=AutoGenerateType.HEX, length=hex_len)
    val = vs_generator._generate_secret_value(config)
    assert len(val) == hex_len
    assert all(c in "0123456789abcdef" for c in val)

    # 2. Unhandled type raises ValueError
    with pytest.raises(ValueError, match="Unhandled auto-generate type"):
        # bypass enum for test coverage of default case
        bad_config = AutoGenerateConfig(type="invalid", length=10)  # type: ignore
        vs_generator._generate_secret_value(bad_config)


# ---------------------------------------------------------------------------
# Logic Tests (Hierarchy & Resolution)
# ---------------------------------------------------------------------------


def test_target_config_env_override_hierarchy() -> None:
    """Verify that env-specific overrides win over the base project_name."""
    target = CloudflarePagesTargetConfig(
        name="frontend",
        source="app/",
        flavour=Flavour.TYPESCRIPT_VITE,
        project_name="base-app",
        auth_token="${CLOUDFLARE_API_TOKEN}",
        account_id="${CLOUDFLARE_ACCOUNT_ID}",
        env_overrides=(("staging", CloudflareEnvOverride(project_name="staging-app")),),
    )
    # 1. No override defined for prod → base value returned
    assert target.project_name_for_env("prod") == "base-app"

    # 2. Override defined for staging → staging-specific value returned
    assert target.project_name_for_env("staging") == "staging-app"


def test_resolve_val_strict_interpolation(capsys: pytest.CaptureFixture[str]) -> None:
    """Verify that ${KEY} interpolation requires exact casing and suggests fixes."""
    from vaultscribe.vs_types import SecretConfig

    def empty_conf() -> SecretConfig:
        return SecretConfig(description=None, source=None, sync_targets=[], auto_generate=None)

    # AdMiN_SeCrEt is our strict test case
    from vaultscribe.vs_types import FlatSecrets

    env_vars = FlatSecrets({SecretKey("AdMiN_SeCrEt"): "real-value"})
    schema = Schema(
        project="test",
        environments={},
        secrets={SecretKey("AdMiN_SeCrEt"): empty_conf()},
        public={},
        targets={},
    )

    # 1. Exact match works
    assert vs_sync._resolve_val("${AdMiN_SeCrEt}", env_vars, schema) == "real-value"

    # 2. Case-insensitive mismatch fails gracefully with a suggestion
    with pytest.raises(SystemExit):
        vs_sync._resolve_val("${admin_secret}", env_vars, schema)

    captured = capsys.readouterr()
    assert "Did you mean '${AdMiN_SeCrEt}'?" in captured.err


# ---------------------------------------------------------------------------
# Ingestion Tests (Regression for NameError)
# ---------------------------------------------------------------------------


def test_validate_bundle_casing_error_regression(
    capsys: pytest.CaptureFixture[str],
) -> None:
    """Regression test for NameError in _validate_and_flatten_bundle.

    # Ensures that mismatched keys from GCloud trigger a suggestion, not a crash.
    """
    from vaultscribe.vs_types import SecretConfig

    def empty_conf() -> SecretConfig:
        return SecretConfig(description=None, source=None, sync_targets=[], auto_generate=None)

    schema = Schema(
        project="test",
        environments={},
        secrets={SecretKey("AdMiN_SeCrEt"): empty_conf()},
        public={},
        targets={},
    )
    # GCloud returns incorrect lowercase key
    data = {"secret": {"admin_secret": "val"}, "public": {}}

    with pytest.raises(SystemExit):
        vs_gcloud._validate_and_flatten_bundle(data, schema)

    captured = capsys.readouterr()
    err_text = " ".join(captured.err.split())
    assert "incorrect casing" in err_text
    assert "Expected: 'AdMiN_SeCrEt'" in err_text


# ---------------------------------------------------------------------------
# Safety Tests (Ignore Injection)
# ---------------------------------------------------------------------------


def test_ensure_secrets_ignored_logic(tmp_path: Path) -> None:
    """Verify that .secrets.* is injected only when missing."""
    gitignore = tmp_path / ".gitignore"
    gitignore.write_text("dist/\n")

    with mock.patch("vaultscribe.shell._REPO_ROOT", tmp_path):
        # 1. First injection
        vs_shell._ensure_secrets_ignored()
        content = gitignore.read_text()
        assert ".secrets.*" in content
        assert "# --- Vaultscribe ---" in content

        # 2. Idempotency (should not append again)
        vs_shell._ensure_secrets_ignored()
        assert content == gitignore.read_text()


# ---------------------------------------------------------------------------
# Collision Detection
# ---------------------------------------------------------------------------


def test_case_collision_detection(capsys: pytest.CaptureFixture[str]) -> None:
    """Verify that ADMIN_SECRET and admin_secret cannot coexist."""
    from vaultscribe.vs_types import SecretConfig

    def empty_conf() -> SecretConfig:
        return SecretConfig(description=None, source=None, sync_targets=[], auto_generate=None)

    schema = {
        "gcloud_project_id": "test",
        "envs": {"prod": {"slot": "test"}},
        "secrets": {
            "ADMIN_SECRET": empty_conf(),
            "admin_secret": empty_conf(),  # Collision!
        },
        "public": {},
    }
    with pytest.raises(SystemExit):
        vs_schema._validate_schema_structure(schema)

    captured = capsys.readouterr()
    assert "Case collision detected" in captured.err


# ---------------------------------------------------------------------------
# Parser Tests (env is a required positional, not a flag)
# ---------------------------------------------------------------------------


def test_argparse_env_positional() -> None:
    """Verify that env is parsed as a required positional for commands that need it."""
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command")

    # Replicate subcommands that carry env
    p_pull = subparsers.add_parser("pull")
    p_pull.add_argument("env")

    p_run = subparsers.add_parser("run")
    p_run.add_argument("env")
    p_run.add_argument("cmd", nargs=argparse.REMAINDER)

    p_sync = subparsers.add_parser("sync")
    p_sync.add_argument("env")
    p_sync.add_argument("target", nargs="?")

    # Replicate subcommands that do NOT carry env
    subparsers.add_parser("codegen")

    # CASE A: pull prod
    args = parser.parse_args(["pull", "prod"])
    assert args.command == "pull"
    assert args.env == "prod"

    # CASE B: run prod -- ls -la (argparse strips the -- separator from REMAINDER)
    args = parser.parse_args(["run", "prod", "--", "ls", "-la"])
    assert args.command == "run"
    assert args.env == "prod"
    assert args.cmd == ["ls", "-la"]

    # CASE C: sync with optional target
    args = parser.parse_args(["sync", "staging", "cloudflare"])
    assert args.command == "sync"
    assert args.env == "staging"
    assert args.target == "cloudflare"

    # CASE D: codegen has no env attribute
    args = parser.parse_args(["codegen"])
    assert args.command == "codegen"
    assert not hasattr(args, "env")


# ---------------------------------------------------------------------------
# IAM Tests (_ensure_gcloud_run_iam)
# ---------------------------------------------------------------------------

_GCLOUD_RUN_SCHEMA = Schema(
    project="test-proj",
    environments={EnvName("prod"): EnvConfig(project="test-proj", slot="test-slot")},
    secrets={},
    public={},
    targets={
        TargetName("backend"): GcloudRunTargetConfig(
            name="backend",
            source="api/",
            flavour=Flavour.PYTHON_PYDANTIC,
            secrets_env_var="VS_SECRETS",
        )
    },
)

_CLOUDFLARE_SCHEMA = Schema(
    project="test-proj",
    environments={EnvName("prod"): EnvConfig(project="test-proj", slot="test-slot")},
    secrets={},
    public={},
    targets={
        TargetName("frontend"): CloudflarePagesTargetConfig(
            name="frontend",
            source="app/",
            flavour=Flavour.TYPESCRIPT_VITE,
            project_name="my-app",
            auth_token="${CLOUDFLARE_API_TOKEN}",
            account_id="${CLOUDFLARE_ACCOUNT_ID}",
        )
    },
)

_PROJECT_NUMBER = "751502879957"
_SA = f"{_PROJECT_NUMBER}-compute@developer.gserviceaccount.com"
_MEMBER = f"serviceAccount:{_SA}"
_ROLE = "roles/secretmanager.secretAccessor"


def _describe_result() -> mock.Mock:
    r = mock.Mock()
    r.stdout = f"{_PROJECT_NUMBER}\n"
    return r


def _policy_result(has_binding: bool) -> mock.Mock:
    r = mock.Mock()
    bindings = [{"role": _ROLE, "members": [_MEMBER]}] if has_binding else []
    r.stdout = json.dumps({"bindings": bindings})
    return r


def test_ensure_gcloud_run_iam_skips_when_no_gcloud_run_target() -> None:
    """No subprocess calls at all when no gcloud_run target is configured."""
    env_conf = EnvConfig(project="test-project", slot="test-slot")

    with mock.patch("vaultscribe.iam.subprocess.run") as mock_run:
        vs_iam._ensure_gcloud_run_iam(env_conf, _CLOUDFLARE_SCHEMA, "prod")
        mock_run.assert_not_called()


def test_ensure_gcloud_run_iam_already_granted(
    capsys: pytest.CaptureFixture[str],
) -> None:
    """Prints 'already has access' and makes no grant call when binding exists."""
    env_conf = EnvConfig(project="test-project", slot="test-slot")

    with mock.patch(
        "vaultscribe.iam.subprocess.run",
        side_effect=[_describe_result(), _policy_result(has_binding=True)],
    ) as mock_run:
        vs_iam._ensure_gcloud_run_iam(env_conf, _GCLOUD_RUN_SCHEMA, "prod")
        # describe + get-iam-policy only — no add-iam-policy-binding
        assert mock_run.call_count == 2

    assert "already has access" in capsys.readouterr().err


def test_ensure_gcloud_run_iam_grants_when_missing(
    capsys: pytest.CaptureFixture[str],
) -> None:
    """Runs the grant command and prints success when the binding is absent."""
    env_conf = EnvConfig(project="test-project", slot="test-slot")

    with mock.patch(
        "vaultscribe.iam.subprocess.run",
        side_effect=[
            _describe_result(),
            _policy_result(has_binding=False),
            mock.Mock(),  # add-iam-policy-binding succeeds
        ],
    ) as mock_run:
        vs_iam._ensure_gcloud_run_iam(env_conf, _GCLOUD_RUN_SCHEMA, "prod")
        assert mock_run.call_count == 3

    err = capsys.readouterr().err
    assert "Granted" in err
    assert _SA in err


def test_ensure_gcloud_run_iam_warns_when_sa_not_found(
    capsys: pytest.CaptureFixture[str],
) -> None:
    """Prints a warning (does not raise) when the Compute SA doesn't exist yet."""
    env_conf = EnvConfig(project="test-project", slot="test-slot")

    grant_error = subprocess.CalledProcessError(1, "gcloud", stderr="ERROR: Service account does not exist.")

    with mock.patch(
        "vaultscribe.iam.subprocess.run",
        side_effect=[
            _describe_result(),
            _policy_result(has_binding=False),
            grant_error,
        ],
    ):
        vs_iam._ensure_gcloud_run_iam(env_conf, _GCLOUD_RUN_SCHEMA, "prod")

    err = capsys.readouterr().err
    assert "Re-run" in err


def test_ensure_gcloud_run_iam_warns_when_project_number_unavailable(
    capsys: pytest.CaptureFixture[str],
) -> None:
    """Prints a warning and skips all further calls if gcloud projects describe fails."""
    env_conf = EnvConfig(project="test-project", slot="test-slot")

    describe_error = subprocess.CalledProcessError(1, "gcloud", stderr="ERROR: auth")

    with mock.patch(
        "vaultscribe.iam.subprocess.run",
        side_effect=[describe_error],
    ) as mock_run:
        vs_iam._ensure_gcloud_run_iam(env_conf, _GCLOUD_RUN_SCHEMA, "prod")
        assert mock_run.call_count == 1

    assert "skipping IAM check" in capsys.readouterr().err


# ---------------------------------------------------------------------------
# run_command: inline KEY=VALUE env injection
# ---------------------------------------------------------------------------

_RUN_ENV = "dev"
_RUN_SCHEMA = Schema(
    project="test-proj",
    environments={EnvName(_RUN_ENV): EnvConfig(project="test-proj", slot="test-slot")},
    secrets={},
    public={},
    targets={
        TargetName("frontend_app"): CloudflarePagesTargetConfig(
            name="frontend_app",
            source="app/",
            flavour=Flavour.TYPESCRIPT_VITE,
            project_name="my-app",
            auth_token="${CLOUDFLARE_API_TOKEN}",
            account_id="${CLOUDFLARE_ACCOUNT_ID}",
        )
    },
)

_RUN_ENV_CONF = EnvConfig(project="test-proj", slot="test-slot")
_RUN_TARGET = CloudflarePagesTargetConfig(
    name="frontend_app",
    source="app/",
    flavour=Flavour.TYPESCRIPT_VITE,
    project_name="my-app",
    auth_token="${CLOUDFLARE_API_TOKEN}",
    account_id="${CLOUDFLARE_ACCOUNT_ID}",
)


def _run_command_patches(target_name: str | None, command_args: list[str]) -> mock.MagicMock:
    """Call run_command with all external I/O mocked. Returns the subprocess.run mock."""
    mock_subprocess = mock.MagicMock()
    with (
        mock.patch("vaultscribe.run._parse_schema", return_value=_RUN_SCHEMA),
        mock.patch("vaultscribe.run._get_env_config", return_value=_RUN_ENV_CONF),
        mock.patch("vaultscribe.run._fetch_from_gcloud", return_value={}),
        mock.patch("vaultscribe.run._get_target_config", return_value=_RUN_TARGET),
        mock.patch("vaultscribe.run.subprocess.run", mock_subprocess),
    ):
        vs_run._run_command(_RUN_ENV, target_name, command_args)
    return mock_subprocess


def test_run_command_inline_kv_stripped_from_command() -> None:
    """Leading KEY=VALUE tokens must not be passed as the executable to subprocess.run.

    # This is the bug that caused 'just run-app' to fail: subprocess.run received
    # ['VITE_CASEY_API_URL=http://localhost:8080', 'npx', 'vite', ...] and tried to
    # exec the first element as a binary.
    """
    mock_subprocess = _run_command_patches(
        "frontend_app",
        ["VITE_CASEY_API_URL=http://localhost:8080", "npx", "vite", "--port", "8081"],
    )

    actual_cmd = mock_subprocess.call_args[0][0]
    # The KEY=VALUE prefix must be consumed — only the real command remains.
    assert actual_cmd == ["npx", "vite", "--port", "8081"]


def test_run_command_inline_kv_injected_into_env() -> None:
    """The value from a leading KEY=VALUE token must appear in the subprocess env."""
    mock_subprocess = _run_command_patches(
        "frontend_app",
        ["VITE_CASEY_API_URL=http://localhost:8080", "npx", "vite"],
    )

    actual_env = mock_subprocess.call_args[1]["env"]
    assert actual_env["VITE_CASEY_API_URL"] == "http://localhost:8080"


def test_run_command_multiple_inline_kv_all_consumed() -> None:
    """Multiple consecutive KEY=VALUE tokens are all stripped and injected."""
    mock_subprocess = _run_command_patches(
        "frontend_app",
        ["FOO=bar", "BAZ=qux", "npx", "vite"],
    )

    actual_cmd = mock_subprocess.call_args[0][0]
    actual_env = mock_subprocess.call_args[1]["env"]
    assert actual_cmd == ["npx", "vite"]
    assert actual_env["FOO"] == "bar"
    assert actual_env["BAZ"] == "qux"


def test_run_command_no_inline_kv_passes_command_unchanged() -> None:
    """When there are no KEY=VALUE prefixes the command list is passed through as-is."""
    mock_subprocess = _run_command_patches(None, ["npx", "vite", "--port", "8081"])

    actual_cmd = mock_subprocess.call_args[0][0]
    assert actual_cmd == ["npx", "vite", "--port", "8081"]


def test_run_command_url_value_not_treated_as_kv() -> None:
    """A URL argument like http://localhost:8080 must not be consumed as a KEY=VALUE token.

    # The regex requires the key to start with a letter or underscore and contain
    # only word characters — a colon (in http:) prevents a false match.
    """
    mock_subprocess = _run_command_patches(None, ["curl", "http://localhost:8080"])

    actual_cmd = mock_subprocess.call_args[0][0]
    assert actual_cmd == ["curl", "http://localhost:8080"]


# ---------------------------------------------------------------------------
# cli.main(): 'vs run' argument parsing — '--' pre-split
# ---------------------------------------------------------------------------

# Minimal schema used to satisfy _parse_schema() calls inside main().
_CLI_SCHEMA = Schema(
    project="test-proj",
    environments={
        EnvName("dev"): EnvConfig(project="test-proj", slot="test-slot"),
        EnvName("prod"): EnvConfig(project="test-proj", slot="prod-slot"),
    },
    secrets={},
    public={},
    targets={
        TargetName("backend_api"): GcloudRunTargetConfig(
            name="backend_api",
            source="api/",
            flavour=Flavour.PYTHON_PYDANTIC,
            secrets_env_var="CASEY_AI",
        )
    },
)

_CLI_ENV_CONF = EnvConfig(project="test-proj", slot="test-slot")


def _main_run_patches(argv: list[str]) -> mock.MagicMock:
    """Call main() with the given argv, mocking everything external.

    Returns the mock for run_command so callers can assert on what it received.
    """
    mock_run_command = mock.MagicMock()
    with (
        mock.patch.object(sys, "argv", ["vs", *argv]),
        mock.patch("vaultscribe.cli._parse_schema", return_value=_CLI_SCHEMA),
        mock.patch("vaultscribe.cli._require_shell"),
        mock.patch("vaultscribe.cli._run_command", mock_run_command),
    ):
        vs_cli.main()
    return mock_run_command


def test_run_argv_double_dash_separates_target_from_command() -> None:
    """'--target' must be parsed as a vaultscribe option, not swallowed by REMAINDER.

    # This was the bug: argparse.REMAINDER captured '--target backend_api' as part
    # of args.cmd, so subprocess received '--target' as the executable name.
    # The fix pre-splits sys.argv at '--' before calling parse_args().
    """
    mock_run = _main_run_patches(["run", "prod", "--target", "backend_api", "--", "uv", "run", "pytest"])
    mock_run.assert_called_once_with("prod", "backend_api", ["uv", "run", "pytest"])


def test_run_argv_no_double_dash_target_still_parsed() -> None:
    """Without a '--' separator, '--target' must still be recognised as an option."""
    mock_run = _main_run_patches(["run", "dev", "--target", "backend_api", "--", "echo", "hello"])
    mock_run.assert_called_once_with("dev", "backend_api", ["echo", "hello"])


def test_run_argv_no_target_passes_none() -> None:
    """Omitting '--target' passes None to run_command (individual env var injection)."""
    mock_run = _main_run_patches(["run", "dev", "--", "pytest"])
    mock_run.assert_called_once_with("dev", None, ["pytest"])


def test_run_argv_command_with_its_own_flags_unaffected() -> None:
    """Flags belonging to the wrapped command (after '--') are passed through intact."""
    mock_run = _main_run_patches(
        [
            "run",
            "prod",
            "--target",
            "backend_api",
            "--",
            "uv",
            "run",
            "--directory",
            "api",
            "alembic",
            "upgrade",
            "head",
        ]
    )
    mock_run.assert_called_once_with(
        "prod",
        "backend_api",
        ["uv", "run", "--directory", "api", "alembic", "upgrade", "head"],
    )


# ---------------------------------------------------------------------------
# run_command: script target secret injection
# ---------------------------------------------------------------------------

_SCRIPT_ENV = "dev"
_SCRIPT_ENV_CONF = EnvConfig(project="test-proj", slot="test-slot")
_SCRIPT_TARGET = ScriptTargetConfig(name="alembic_migration")


def _run_command_script_patches(
    schema: Schema,
    env_vars: dict,
    command_args: list[str],
) -> mock.MagicMock:
    """Call _run_command with a script target and all external I/O mocked."""
    mock_subprocess = mock.MagicMock()
    with (
        mock.patch("vaultscribe.run._parse_schema", return_value=schema),
        mock.patch("vaultscribe.run._get_env_config", return_value=_SCRIPT_ENV_CONF),
        mock.patch("vaultscribe.run._fetch_from_gcloud", return_value=env_vars),
        mock.patch("vaultscribe.run._get_target_config", return_value=_SCRIPT_TARGET),
        mock.patch("vaultscribe.run.subprocess.run", mock_subprocess),
    ):
        vs_run._run_command(_SCRIPT_ENV, "alembic_migration", command_args)
    return mock_subprocess


def test_run_command_script_target_injects_only_scoped_secrets() -> None:
    """Only secrets that declare the script target in sync_targets must be injected.

    # DATABASE_URL is scoped to alembic_migration; ADMIN_SECRET is not.
    # The subprocess env must contain DATABASE_URL but not ADMIN_SECRET.
    """
    from vaultscribe.vs_types import FlatSecrets, SecretConfig, SecretKey

    schema = Schema(
        project="test-proj",
        environments={EnvName(_SCRIPT_ENV): _SCRIPT_ENV_CONF},
        secrets={
            SecretKey("DATABASE_URL"): SecretConfig(
                description=None, source=None, sync_targets=["alembic_migration"], auto_generate=None
            ),
            SecretKey("ADMIN_SECRET"): SecretConfig(
                description=None, source=None, sync_targets=["backend_api"], auto_generate=None
            ),
        },
        public={},
        targets={TargetName("alembic_migration"): _SCRIPT_TARGET},
    )
    env_vars = FlatSecrets({SecretKey("DATABASE_URL"): "postgres://...", SecretKey("ADMIN_SECRET"): "abc123"})

    mock_subprocess = _run_command_script_patches(schema, env_vars, ["alembic", "upgrade", "head"])

    actual_env = mock_subprocess.call_args[1]["env"]
    assert actual_env["DATABASE_URL"] == "postgres://..."
    assert "ADMIN_SECRET" not in actual_env


def test_run_command_script_target_injects_public_keys() -> None:
    """Public keys scoped to the script target must also be injected.

    # Public keys follow the same sync_targets mechanism — the script target
    # has no concept of secrets vs public, so both are injected as plain env vars.
    """
    from vaultscribe.vs_types import FlatSecrets, SecretConfig, SecretKey

    schema = Schema(
        project="test-proj",
        environments={EnvName(_SCRIPT_ENV): _SCRIPT_ENV_CONF},
        secrets={},
        public={
            SecretKey("API_URL"): SecretConfig(
                description=None, source=None, sync_targets=["alembic_migration"], auto_generate=None
            ),
            SecretKey("OTHER_URL"): SecretConfig(
                description=None, source=None, sync_targets=["frontend_app"], auto_generate=None
            ),
        },
        targets={TargetName("alembic_migration"): _SCRIPT_TARGET},
    )
    env_vars = FlatSecrets(
        {SecretKey("API_URL"): "https://api.example.com", SecretKey("OTHER_URL"): "https://other.com"}
    )

    mock_subprocess = _run_command_script_patches(schema, env_vars, ["alembic", "upgrade", "head"])

    actual_env = mock_subprocess.call_args[1]["env"]
    assert actual_env["API_URL"] == "https://api.example.com"
    assert "OTHER_URL" not in actual_env


# ---------------------------------------------------------------------------
# github_actions sync
# ---------------------------------------------------------------------------


def _gh_schema(
    target: GitHubActionsTargetConfig,
    secrets: dict[str, list[str] | None],
    public: dict[str, list[str] | None],
) -> Schema:
    from vaultscribe.vs_types import SecretConfig as _SC

    return Schema(
        project="test-proj",
        environments={EnvName("prod"): EnvConfig(project="test-proj", slot="test-prod")},
        secrets={
            SecretKey(k): _SC(description=None, source=None, sync_targets=v, auto_generate=None)
            for k, v in secrets.items()
        },
        public={
            SecretKey(k): _SC(description=None, source=None, sync_targets=v, auto_generate=None)
            for k, v in public.items()
        },
        targets={TargetName(target.name): target},
    )


def test_sync_github_actions_invokes_gh_for_secrets_and_variables() -> None:
    """Secrets go to `gh secret set`, public values go to `gh variable set`.

    Each call is scoped to the target's repo and environment, with the value via stdin.
    """
    from vaultscribe.vs_types import FlatSecrets

    target = GitHubActionsTargetConfig(
        name="gh_prod",
        repo="owner/repo",
        environment="production",
        vs_env="prod",
    )
    schema = _gh_schema(
        target,
        secrets={"DEPLOY_TOKEN": ["gh_prod"], "OTHER_SECRET": ["backend"]},
        public={"BACKEND_URL": ["gh_prod"], "FRONTEND_URL": ["frontend"]},
    )
    env_vars = FlatSecrets(
        {
            SecretKey("DEPLOY_TOKEN"): "tok123",
            SecretKey("OTHER_SECRET"): "ignored",
            SecretKey("BACKEND_URL"): "https://api.example.com",
            SecretKey("FRONTEND_URL"): "https://app.example.com",
        }
    )

    with mock.patch("vaultscribe.sync.check_cli"), mock.patch("vaultscribe.sync._run") as mock_run:
        vs_sync._sync_github_actions(target, env_vars, schema, "prod")

    calls = mock_run.call_args_list
    assert len(calls) == 2

    secret_call = calls[0]
    secret_args = secret_call.args[0]
    assert secret_args[:3] == ["gh", "secret", "set"]
    assert "DEPLOY_TOKEN" in secret_args
    assert "--repo" in secret_args
    assert "owner/repo" in secret_args
    assert "--env" in secret_args
    assert "production" in secret_args
    assert secret_call.kwargs["input"] == b"tok123"

    var_call = calls[1]
    var_args = var_call.args[0]
    assert var_args[:3] == ["gh", "variable", "set"]
    assert "BACKEND_URL" in var_args
    assert var_call.kwargs["input"] == b"https://api.example.com"


def test_sync_github_actions_skips_when_bound_env_mismatches(
    capsys: pytest.CaptureFixture[str],
) -> None:
    """A github_actions target bound to vs env 'prod' is skipped when pushing 'dev'."""
    from vaultscribe.vs_types import FlatSecrets

    target = GitHubActionsTargetConfig(
        name="gh_prod",
        repo="owner/repo",
        vs_env="prod",
    )
    schema = _gh_schema(target, secrets={"DEPLOY_TOKEN": ["gh_prod"]}, public={})
    env_vars = FlatSecrets({SecretKey("DEPLOY_TOKEN"): "tok"})

    with mock.patch("vaultscribe.sync.check_cli"), mock.patch("vaultscribe.sync._run") as mock_run:
        vs_sync._sync_github_actions(target, env_vars, schema, "dev")

    assert mock_run.call_count == 0
    err = capsys.readouterr().err
    assert "Skipping 'gh_prod'" in err
    assert "bound to vs env 'prod'" in err


def test_sync_github_actions_omits_env_arg_when_environment_unset() -> None:
    """A github_actions target without environment uses repo scope only."""
    from vaultscribe.vs_types import FlatSecrets

    target = GitHubActionsTargetConfig(
        name="gh_repo",
        repo="owner/repo",
        vs_env="prod",
    )
    schema = _gh_schema(target, secrets={"TOKEN": ["gh_repo"]}, public={})
    env_vars = FlatSecrets({SecretKey("TOKEN"): "v"})

    with mock.patch("vaultscribe.sync.check_cli"), mock.patch("vaultscribe.sync._run") as mock_run:
        vs_sync._sync_github_actions(target, env_vars, schema, "prod")

    args = mock_run.call_args_list[0].args[0]
    assert "--env" not in args


# ---------------------------------------------------------------------------
# run_command: github_actions target injection (mirrors script behaviour)
# ---------------------------------------------------------------------------


def test_run_command_github_actions_target_injects_scoped_secrets() -> None:
    """A vs run targeted at a github_actions target injects sync_targets-scoped keys."""
    from vaultscribe.vs_types import FlatSecrets, SecretConfig

    gh_target = GitHubActionsTargetConfig(
        name="gh_prod",
        repo="owner/repo",
        vs_env="prod",
    )
    env_conf = EnvConfig(project="test-proj", slot="test-prod")
    schema = Schema(
        project="test-proj",
        environments={EnvName("prod"): env_conf},
        secrets={
            SecretKey("DEPLOY_TOKEN"): SecretConfig(
                description=None, source=None, sync_targets=["gh_prod"], auto_generate=None
            ),
            SecretKey("OTHER_TOKEN"): SecretConfig(
                description=None, source=None, sync_targets=["backend"], auto_generate=None
            ),
        },
        public={},
        targets={TargetName("gh_prod"): gh_target},
    )
    env_vars = FlatSecrets({SecretKey("DEPLOY_TOKEN"): "tok123", SecretKey("OTHER_TOKEN"): "nope"})

    mock_subprocess = mock.MagicMock()
    with (
        mock.patch("vaultscribe.run._parse_schema", return_value=schema),
        mock.patch("vaultscribe.run._get_env_config", return_value=env_conf),
        mock.patch("vaultscribe.run._fetch_from_gcloud", return_value=env_vars),
        mock.patch("vaultscribe.run._get_target_config", return_value=gh_target),
        mock.patch("vaultscribe.run.subprocess.run", mock_subprocess),
    ):
        vs_run._run_command("prod", "gh_prod", ["echo", "hi"])

    actual_env = mock_subprocess.call_args[1]["env"]
    assert actual_env["DEPLOY_TOKEN"] == "tok123"
    assert "OTHER_TOKEN" not in actual_env


# ---------------------------------------------------------------------------
# deps.check_cli
# ---------------------------------------------------------------------------


def test_check_cli_exits_when_binary_missing(capsys: pytest.CaptureFixture[str]) -> None:
    from vaultscribe import deps

    dep = deps.CliDependency(
        name="some-nonexistent-cli-xyzzy",
        install_url="https://example.com/install",
        login_hint="run `xyzzy login`.",
    )
    with mock.patch("vaultscribe.deps.shutil.which", return_value=None), pytest.raises(SystemExit) as e:
        deps.check_cli(dep)

    assert e.value.code == 1
    err = capsys.readouterr().err
    assert "some-nonexistent-cli-xyzzy" in err
    assert "https://example.com/install" in err
    assert "xyzzy login" in err


def test_check_cli_returns_when_binary_present() -> None:
    from vaultscribe import deps

    dep = deps.CliDependency(name="anything", install_url="...")
    with mock.patch("vaultscribe.deps.shutil.which", return_value="/usr/bin/anything"):
        deps.check_cli(dep)  # Must not raise


# ---------------------------------------------------------------------------
# vs run mock: target-aware injection without GCloud auth
# ---------------------------------------------------------------------------

_MOCK_SCHEMA = Schema(
    project="test-proj",
    environments={EnvName("dev"): EnvConfig(project="test-proj", slot="test-slot")},
    secrets={
        SecretKey("CASEY_API_URL"): SecretConfig(
            description=None,
            source=None,
            sync_targets=["frontend_app:build"],
            auto_generate=None,
        ),
        SecretKey("PRIVATE_TOKEN"): SecretConfig(
            description=None,
            source=None,
            sync_targets=["frontend_app:runtime"],
            auto_generate=None,
        ),
    },
    public={
        SecretKey("PUBLIC_URL"): SecretConfig(
            description=None,
            source=None,
            sync_targets=["frontend_app:build"],
            auto_generate=None,
        ),
    },
    targets={
        TargetName("frontend_app"): CloudflarePagesTargetConfig(
            name="frontend_app",
            source="app/",
            flavour=Flavour.TYPESCRIPT_VITE,
            project_name="my-app",
            auth_token="${CLOUDFLARE_API_TOKEN}",
            account_id="${CLOUDFLARE_ACCOUNT_ID}",
        )
    },
)


def _run_mock_patches(schema: Schema, target_name: str | None, command_args: list[str]) -> mock.MagicMock:
    """Call _run_command("mock", ...) with all external I/O mocked. Returns subprocess mock."""
    mock_subprocess = mock.MagicMock()
    with (
        mock.patch("vaultscribe.run._parse_schema", return_value=schema),
        mock.patch("vaultscribe.run._fetch_from_gcloud") as mock_fetch,
        mock.patch("vaultscribe.run._get_target_config", return_value=schema.targets[TargetName(target_name)])
        if target_name
        else mock.patch("vaultscribe.run._get_target_config"),
        mock.patch("vaultscribe.run.subprocess.run", mock_subprocess),
    ):
        vs_run._run_command("mock", target_name, command_args)
        # Verify GCloud was never called — mock env must be auth-free.
        mock_fetch.assert_not_called()
    return mock_subprocess


def test_run_mock_cloudflare_build_keys_get_vite_prefix() -> None:
    """Keys with :build delivery on a cloudflare_pages target must be injected as VITE_<KEY>.

    # The whole point of vs run mock is that the same VITE_ prefixing used for
    # real environments is applied to mock values — without requiring GCloud auth.
    """
    mock_subprocess = _run_mock_patches(_MOCK_SCHEMA, "frontend_app", ["npm", "test"])
    actual_env = mock_subprocess.call_args[1]["env"]

    # :build keys → VITE_ prefix, value follows mock_{key.lower()} convention
    assert actual_env.get("VITE_CASEY_API_URL") == "mock_casey_api_url"
    assert actual_env.get("VITE_PUBLIC_URL") == "mock_public_url"
    # Raw key must not appear — it would bypass the Vite bundle
    assert "CASEY_API_URL" not in actual_env
    assert "PUBLIC_URL" not in actual_env


def test_run_mock_cloudflare_runtime_keys_have_no_prefix() -> None:
    """Keys with :runtime delivery on a cloudflare_pages target must be injected as plain KEY=value.

    # Runtime keys are served by the Pages Function middleware, not baked into
    # the JS bundle, so no VITE_ prefix is applied.
    """
    mock_subprocess = _run_mock_patches(_MOCK_SCHEMA, "frontend_app", ["npm", "test"])
    actual_env = mock_subprocess.call_args[1]["env"]

    assert actual_env.get("PRIVATE_TOKEN") == "mock_private_token"
    assert "VITE_PRIVATE_TOKEN" not in actual_env


def test_run_mock_gcloud_run_injects_json_bundle() -> None:
    """A gcloud_run target must receive a JSON bundle, not individual env vars."""
    import json

    gcloud_schema = Schema(
        project="test-proj",
        environments={EnvName("dev"): EnvConfig(project="test-proj", slot="test-slot")},
        secrets={
            SecretKey("DB_URL"): SecretConfig(
                description=None, source=None, sync_targets=["backend_api"], auto_generate=None
            )
        },
        public={},
        targets={
            TargetName("backend_api"): GcloudRunTargetConfig(
                name="backend_api",
                source="api/",
                flavour=Flavour.PYTHON_PYDANTIC,
                secrets_env_var="VS_SECRETS",
            )
        },
    )

    mock_subprocess = mock.MagicMock()
    gcloud_target = gcloud_schema.targets[TargetName("backend_api")]
    with (
        mock.patch("vaultscribe.run._parse_schema", return_value=gcloud_schema),
        mock.patch("vaultscribe.run._fetch_from_gcloud") as mock_fetch,
        mock.patch("vaultscribe.run._get_target_config", return_value=gcloud_target),
        mock.patch("vaultscribe.run.subprocess.run", mock_subprocess),
    ):
        vs_run._run_command("mock", "backend_api", ["pytest"])
        mock_fetch.assert_not_called()

    actual_env = mock_subprocess.call_args[1]["env"]
    bundle = json.loads(actual_env["VS_SECRETS"])
    # DB_URL is a secret (not public), so it lands in the "secret" namespace
    assert bundle["secret"]["DB_URL"] == "mock_db_url"


def test_run_mock_no_target_injects_all_keys_as_plain_env_vars() -> None:
    """Without a --target, all keys are injected as individual plain env vars."""
    flat_schema = Schema(
        project="test-proj",
        environments={EnvName("dev"): EnvConfig(project="test-proj", slot="test-slot")},
        secrets={
            SecretKey("SECRET_A"): SecretConfig(description=None, source=None, sync_targets=None, auto_generate=None)
        },
        public={
            SecretKey("PUBLIC_B"): SecretConfig(description=None, source=None, sync_targets=None, auto_generate=None)
        },
        targets={},
    )

    mock_subprocess = mock.MagicMock()
    with (
        mock.patch("vaultscribe.run._parse_schema", return_value=flat_schema),
        mock.patch("vaultscribe.run._fetch_from_gcloud") as mock_fetch,
        mock.patch("vaultscribe.run.subprocess.run", mock_subprocess),
    ):
        vs_run._run_command("mock", None, ["pytest"])
        mock_fetch.assert_not_called()

    actual_env = mock_subprocess.call_args[1]["env"]
    assert actual_env["SECRET_A"] == "mock_secret_a"
    assert actual_env["PUBLIC_B"] == "mock_public_b"


def test_run_mock_env_does_not_require_shell() -> None:
    """Vs run mock must not require an active GCloud shell session.

    # This is the primary DX goal: test runners need to call vs run mock in CI
    # without any GCloud credentials set up.
    """
    require_shell_mock = mock.MagicMock()
    mock_run_command = mock.MagicMock()
    with (
        mock.patch.object(sys, "argv", ["vs", "run", "mock", "--target", "frontend_app", "--", "npm", "test"]),
        mock.patch("vaultscribe.cli._parse_schema", return_value=_CLI_SCHEMA),
        mock.patch("vaultscribe.cli._require_shell", require_shell_mock),
        mock.patch("vaultscribe.cli._run_command", mock_run_command),
    ):
        vs_cli.main()

    require_shell_mock.assert_not_called()
    mock_run_command.assert_called_once_with("mock", "frontend_app", ["npm", "test"])


def test_mock_env_reserved_name_rejected_in_toml(capsys: pytest.CaptureFixture[str]) -> None:
    """Defining [envs.mock] in vaultscribe.toml must exit with a clear error.

    # 'mock' is a pseudo-environment consumed by vs run; a real GCloud-backed
    # environment named 'mock' would create ambiguity and is disallowed.
    """
    schema_dict = {
        "gcloud_project_id": "test",
        "envs": {"mock": {"slot": "test"}},
        "secrets": {},
        "public": {},
        "targets": {"backend": {"type": "script"}},
    }
    with pytest.raises(SystemExit):
        vs_schema._validate_schema_structure(schema_dict)

    captured = capsys.readouterr()
    assert "reserved" in captured.err.lower() or "pseudo-environment" in captured.err
