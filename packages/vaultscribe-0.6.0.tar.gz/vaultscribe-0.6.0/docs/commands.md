# Vaultscribe Core

All commands are invoked as `vs <command>`. use `vs --help` for the full list.


## `vs init`

Scaffold a new Vaultscribe project in the current directory.


## `vs shell`

Start a session with time-limited authentication to GCloud Secret Manager. 

Most commands require an active shell session. Vaultscribe is opinionated about requiring you to use the shell when doing secrets work. It ensures secret work is done intentionally, and does not leave auth tokens hanging around.


## `vs pull <env>`

Fetch secrets for the given environment from GCloud Secret Manager to a local file.

| Argument | Description |
|----------|-------------|
| `env` | Target environment (e.g. `prod`, `dev`). |


## `vs push <env>`

Upload the local secrets file for the given environment to GCloud Secret Manager. Also implicitly runs `codegen` and `sync`. The `sync` step pushes secrets to deploy targets (cloudflare pages) and CI/CD targets (github actions); github_actions targets only sync when their bound vs env matches.

| Argument / Flag | Description |
|-----------------|-------------|
| `env` | Target environment (e.g. `prod`, `dev`). |
| `--no-sync` | Skip broadcasting secrets to targets after pushing. |


## `vs rotate <env> [key] [value]`

Rotate a single secret value in GCloud Secret Manager.

| Argument | Description |
|----------|-------------|
| `env` | Target environment (e.g. `prod`, `dev`). |
| `key` | (Optional) The secret key to rotate. Prompted if omitted. |
| `value` | (Optional) The new value. Prompted if omitted, or auto-generated for `auto_generate` keys. |

## `vs run <env> [--target <name>] -- <cmd>`

Execute a command with secrets injected as environment variables. This is target aware, so for example if using a Vite target, Vaultscribe will inject VITE_ prefixed keys.

Example: `vs run prod --target frontend_app -- npm --prefix app run build`, injects build-time secrets (VITE_* env vars) so Vite bakes them into the bundle.

Also useful for ensuring your overrides are working, eg `vs run dev -- env`

| Argument / Flag | Description |
|-----------------|-------------|
| `env` | Environment to draw secrets from (e.g. `dev`, `prod`). Use `mock` for auth-free local testing (see below). |
| `--target`, `-t` | Target name for type-specific injection (e.g. `backend_api`). Omit for individual env var injection. |
| `-- <cmd>` | The command to run, passed after the `--` separator. |

### Mock pseudo-environment

`mock` is a reserved pseudo-environment that skips GCloud auth entirely. Mock values are generated from the schema (`mock_{key.lower()}`) and passed through the same target-aware injection path as a real environment — so `cloudflare_pages` targets get `VITE_`-prefixed build vars, `gcloud_run` targets get the JSON bundle, etc.

```
vs run mock --target frontend_app -- npm test
vs run mock --target backend_api -- pytest
```

No `vs shell` session is required. `mock` cannot be used as a real environment name in `vaultscribe.toml`.

---

# Other Vaultscribe Commands

## `vs parse-test`

Parse `vaultscribe.toml` and print the resulting schema as JSON.

| Flag | Description |
|------|-------------|
| `--quiet` | Suppress JSON output; report success or failure only. |


## `vs codegen`

Generate application bindings from the schema.



## `vs mock-env`

Output a mock environment string (useful for local development and testing).



## `vs list`

List all secret and public keys defined in the schema.



## `vs show <env> [key]`

Display secrets for the given environment from GCloud Secret Manager.

| Argument / Flag | Description |
|-----------------|-------------|
| `env` | Target environment (e.g. `prod`, `dev`). |
| `key` | (Optional) Specific secret key to display. |
| `--all` | Show all values including public keys. |
| `--reveal` | Reveal plaintext values (masked by default). |




