# Vaultscribe Concepts

Vaultscribe uses `vaultscribe.toml` to describe the secrets it manages. The secret values are NOT stored here. See `example/vaultscribe.toml' for an example file.

## Environments

An environment is a collection of secrets that are deployed together. You can define as many environments as you like in your vaultscribe.toml file. For example, you can have a dev environment, a staging environment, and a prod environment.
```toml
# define as [envs.YOUR_NAME], for example
[envs.prod]
slot = "example-secrets-prod"
```

## Targets

A target is a service that uses secrets. It has a `'type'`, for example GCloud Run, or CloudFlare Pages. A type also has a `flavour`, for example Python/Pydantic, or Typescript/Vite.

```toml
# define as [targets.YOUR_NAME], for example
[targets.my-backend]
type = "gcloud_run"
flavour = "python:pydantic"
```

### GitHub Actions targets

A `github_actions` target syncs secrets and public values into a GitHub repository so they can be referenced as `${{ secrets.X }}` and `${{ vars.X }}` from your workflow YAML. `[secrets]` go to GitHub *Secrets* (masked); `[public]` values go to GitHub *Variables* (visible in logs). Vaultscribe shells out to the `gh` CLI, so you must already be logged in with `gh auth login`.

Each `github_actions` target must declare which vs env it syncs from — set `vs_env` explicitly, or set `environment` to a name that exactly matches a vs env. If `environment` is set but is a near-miss for a vs env (e.g. `production` while you have `[envs.prod]`), Vaultscribe fails with a precise suggestion.

```toml
[targets.gh_prod]
type = "github_actions"
repo = "owner/repo"
environment = "production"   # optional GitHub environment scope
vs_env = "prod"              # optional; inferred from environment if it matches a vs env name
```

Removing a key from `vaultscribe.toml` does not remove it from GitHub — Vaultscribe only pushes.

## Secrets

These are the secrets that are synced from GCloud Secret Manager to the target environments. They cannot be synced to a frontend target like `cloudflare_pages`, as that would expose them in the browser.

```toml
# define as [secrets.YOUR_NAME], for example
[secrets.MY_SECRET_NAME]
sync_targets = ["my-backend"]
```

## Public

These are values that are not actually secret, but are needed for running your application. For example, the URL of your backend API, or the API key for a service like Google Maps. These may be synced to any target.

```toml
# define as [public.YOUR_NAME], for example
[public.MY_PUBLIC_VALUE]
sync_targets = ["my-backend", "my-frontend"]
```

# Vaultscribe Shell

When auth'ing to a sensitive service like secret management, you do not want to leave your credentials hanging around longer than you need. Unfortunately, Google Cloud does not offer a way to authenticate for a short period of time. So Vaultscribe offers a way to do your secrets work inside a shell that has a temporary authentication. It does this by getting you to authenticate, but then throwing away the refresh token. This gives you one hour to do your secrets work, then you will need to re-authenticate. The one hour is a Google thing, it cannot be adjusted.

```bash
# Start a vaultscribe shell
vs shell
```

Vaultscribe is opinionated about requiring you to use the shell when doing secrets work. It ensures secret work is done intentionally, and does not leave auth tokens hanging around.

# Vaultscribe Run

If you want to run a script with all the secrets injected as environment variables, you can use the `vs run` command.

```bash
# Run a script with all the secrets injected as environment variables
vs run dev --target backend -- python your_script.py
```