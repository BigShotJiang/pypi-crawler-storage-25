import pytest
from pytest import approx

import numpy as np
import copy
import math



@pytest.mark.parametrize("length", [ 100, 1000, 10000 ])
def test_PermPatterns_TS_Does_Not_Change( length ):

    TS = np.random.uniform( 0., length, (length) )
    TS2 = copy.deepcopy( TS )

    from irreversibility.Preprocessing import PermPatterns
    TS3, _ = PermPatterns.TimeSeriesToPermPatterns( TS )
    assert np.sum( TS - TS2 ) == 0, (
        "Time series has been modified"
    )


@pytest.mark.parametrize("length", [ 10, 20, 40, 80, 160 ])
@pytest.mark.parametrize("pSize", [ 3, 4, 5 ])
def test_PermPatterns_TS_Size_Does_Not_Change( length, pSize ):

    TS = np.random.uniform( 0., length, (length) )

    from irreversibility.Preprocessing import PermPatterns
    TS2, _ = PermPatterns.TimeSeriesToPermPatterns( TS, pSize = pSize )
    assert np.size( TS ) == np.size( TS2 ) + pSize, (
        "Time series length has been modified"
    )

    TS = np.floor( TS )
    TS2, _ = PermPatterns.TimeSeriesToPermPatterns( TS, pSize = pSize )
    assert np.size( TS ) == np.size( TS2 ) + pSize, (
        "Time series length has been modified"
    )


@pytest.mark.parametrize("pSize", [ 3, 4, 5 ])
def test_PermPatterns_Size_PP( pSize ):

    length = 200
    TS = np.random.uniform( 0., length, (length) )

    from irreversibility.Preprocessing import PermPatterns
    TS2, PP = PermPatterns.TimeSeriesToPermPatterns( TS, pSize = pSize )

    assert np.size( PP, 1 ) == pSize, (
        "PermPatt size not coherent"
    )

    assert np.size( PP, 0 ) == math.factorial( pSize ), (
        "PermPatt size not coherent"
    )



def test_PermPatterns_Manual():

    from irreversibility.Preprocessing import PermPatterns

    TS = np.array( np.arange( 100 ) )
    TS2, PP = PermPatterns.TimeSeriesToPermPatterns( TS, pSize = 3, overlapping = True )

    assert np.sum( TS2 > 0 ) == 0, (
        "Time series not correctly transformed"
    )

    TS2, PP = PermPatterns.TimeSeriesToPermPatterns( TS, pSize = 3, overlapping = False )

    assert np.sum( TS2 > 0 ) == 0, (
        "Time series not correctly transformed"
    )



@pytest.mark.parametrize("pSize, TS_length", [(3, 10), (2, 5), (4, 20)])
def test_TimeSeriesToPermPatterns_pSize(pSize, TS_length):
    TS = np.random.uniform(0, 10, TS_length)
    from irreversibility.Preprocessing import PermPatterns
    encoded, _ = PermPatterns.TimeSeriesToPermPatterns(TS, pSize=pSize)
    factorial_pSize = math.factorial(pSize)
    assert encoded.dtype == np.int64, "Encoded time series must be integers"
    assert np.min(encoded) >= 0 and np.max(encoded) < factorial_pSize, (
        f"Encoded values must be between 0 and {factorial_pSize-1}"
    )



@pytest.mark.parametrize("length", [ 10, 20, 40, 80, 160 ])
@pytest.mark.parametrize("pSize", [ 3, 4, 5 ])
@pytest.mark.parametrize("overlapping", [ True, False ])
def test_TimeSeriesToPermPatterns_reproducibility( length, pSize, overlapping ):
    """Test that same input produces same output"""
    TS = np.random.uniform( 0., 1., (length) )
    
    from irreversibility.Preprocessing import PermPatterns
    encodedTS1, allPatts1 = PermPatterns.TimeSeriesToPermPatterns(TS, pSize=pSize, overlapping=overlapping)
    encodedTS2, allPatts2 = PermPatterns.TimeSeriesToPermPatterns(TS, pSize=pSize, overlapping=overlapping)
    
    assert np.array_equal(encodedTS1, encodedTS2)
    assert np.array_equal(allPatts1, allPatts2)

