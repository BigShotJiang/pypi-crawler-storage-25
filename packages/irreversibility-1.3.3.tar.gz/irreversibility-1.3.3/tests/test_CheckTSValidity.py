import pytest
from pytest import approx

import numpy as np
import copy
import math


@pytest.mark.parametrize("ndim", [2, 3, 4])
def test_CheckTSValidity_ValueError_Dim(ndim):
    TS = np.random.rand(10, ndim)
    from irreversibility.utilities import _CheckTSValidity
    with pytest.raises(ValueError):
        _CheckTSValidity(TS, 10)


@pytest.mark.parametrize("length", [5, 10, 15])
def test_CheckTSValidity_ValueError_Length(length):
    TS = np.random.rand(length)
    from irreversibility.utilities import _CheckTSValidity
    with pytest.raises(ValueError):
        _CheckTSValidity(TS, length + 1)

