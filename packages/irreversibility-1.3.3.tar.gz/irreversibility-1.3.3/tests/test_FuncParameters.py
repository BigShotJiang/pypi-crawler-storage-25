import pytest
from pytest import approx

import numpy as np
import copy

import irreversibility as irr



def test_Parameters_BDS():

    TS = np.random.uniform( 0., 1., ( 100 ) )

    with pytest.raises(Exception) as e_info:
        irr.Metrics.BDS.GetPValue( TS, max_dim = 0.5 )

    with pytest.raises(Exception) as e_info:
        irr.Metrics.BDS.GetPValue( TS, max_dim = 0 )

    with pytest.raises(Exception) as e_info:
        irr.Metrics.BDS.GetPValue( TS, distance = 0. )



def test_Parameters_Casali():

    TS = np.random.uniform( 0., 1., ( 100 ) )

    with pytest.raises(Exception) as e_info:
        irr.Metrics.Casali.GetPValue( TS, m = 0.5 )

    with pytest.raises(Exception) as e_info:
        irr.Metrics.Casali.GetPValue( TS, m = 0 )

    with pytest.raises(Exception) as e_info:
        irr.Metrics.Casali.GetPValue( TS, numRndReps = 0.5 )

    with pytest.raises(Exception) as e_info:
        irr.Metrics.Casali.GetPValue( TS, numRndReps = -1 )

    with pytest.raises(Exception) as e_info:
        irr.Metrics.Casali.GetPValue( TS, pValueMethod = 'weird_method' )



def test_Parameters_COP():

    TS = np.random.uniform( 0., 1., ( 100 ) )

    with pytest.raises(Exception) as e_info:
        irr.Metrics.COP.GetPValue( TS, pSize = 0.5 )

    with pytest.raises(Exception) as e_info:
        irr.Metrics.COP.GetPValue( TS, pSize = 1 )

    with pytest.raises(Exception) as e_info:
        irr.Metrics.COP.GetPValue( TS, numIters = 0.5 )

    with pytest.raises(Exception) as e_info:
        irr.Metrics.COP.GetPValue( TS, numIters = 0 )

    with pytest.raises(Exception) as e_info:
        irr.Metrics.COP.GetPValue( TS, useShaders = 0 )



def test_Parameters_CostaIndex():

    TS = np.random.uniform( 0., 1., ( 100 ) )

    with pytest.raises(Exception) as e_info:
        irr.Metrics.CostaIndex.GetPValue( TS, tau = 0.5 )

    with pytest.raises(Exception) as e_info:
        irr.Metrics.CostaIndex.GetPValue( TS, tau = 0 )

    with pytest.raises(Exception) as e_info:
        irr.Metrics.CostaIndex.GetPValue( TS, method = 'method' )

    with pytest.raises(Exception) as e_info:
        irr.Metrics.CostaIndex.GetPValue( TS, numRndReps = 0.5 )

    with pytest.raises(Exception) as e_info:
        irr.Metrics.CostaIndex.GetPValue( TS, numRndReps = -1 )

    with pytest.raises(Exception) as e_info:
        irr.Metrics.CostaIndex.GetPValue( TS, pValueMethod = 'weird_method' )



def test_Parameters_DFK():

    TS = np.random.uniform( 0., 1., ( 100 ) )

    with pytest.raises(Exception) as e_info:
        irr.Metrics.DFK.GetPValue( TS, n = 0.5 )

    with pytest.raises(Exception) as e_info:
        irr.Metrics.DFK.GetPValue( TS, n = 0 )

    with pytest.raises(Exception) as e_info:
        irr.Metrics.DFK.GetPValue( TS, L = 0.5 )

    with pytest.raises(Exception) as e_info:
        irr.Metrics.DFK.GetPValue( TS, L = 0 )



def test_Parameters_Diks():

    TS = np.random.uniform( 0., 1., ( 100 ) )

    with pytest.raises(Exception) as e_info:
        irr.Metrics.Diks.GetPValue( TS, embD = 0.5 )

    with pytest.raises(Exception) as e_info:
        irr.Metrics.Diks.GetPValue( TS, embD = 0 )

    with pytest.raises(Exception) as e_info:
        irr.Metrics.Diks.GetPValue( TS, dVar = -0.5 )



