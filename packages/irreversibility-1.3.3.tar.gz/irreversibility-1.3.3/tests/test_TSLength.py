import pytest
from pytest import approx

import numpy as np
import copy

import irreversibility as irr



def test_BDS():

    targetL = 2

    TS = np.random.uniform( 0., 1., (targetL + 1) )
    irr.Metrics.BDS.GetPValue( TS )
    with pytest.raises(Exception) as e_info:
        irr.Metrics.BDS.GetPValue( TS[ :-1 ] )


def test_Casali():

    targetL = 2

    TS = np.random.uniform( 0., 1., (targetL + 1) )
    irr.Metrics.Casali.GetPValue( TS )
    with pytest.raises(Exception) as e_info:
        irr.Metrics.Casali.GetPValue( TS[ :-1 ] )


def test_COP():

    targetL = 3

    TS = np.random.uniform( 0., 1., (targetL + 1) )
    irr.Metrics.COP.GetPValue( TS )
    with pytest.raises(Exception) as e_info:
        irr.Metrics.COP.GetPValue( TS[ :-1 ] )


def test_CostaIndex():

    targetL = 2

    TS = np.random.uniform( 0., 1., (targetL + 1) )
    irr.Metrics.CostaIndex.GetPValue( TS )
    with pytest.raises(Exception) as e_info:
        irr.Metrics.CostaIndex.GetPValue( TS[ :-1 ] )


def test_DFK():

    targetL = 2

    TS = np.random.uniform( 0., 1., (targetL + 1) )
    irr.Metrics.DFK.GetPValue( TS )
    with pytest.raises(Exception) as e_info:
        irr.Metrics.DFK.GetPValue( TS[ :-1 ] )


def test_Diks():

    targetL = 17

    TS = np.random.uniform( 0., 1., (targetL + 1) )
    irr.Metrics.Diks.GetPValue( TS )
    with pytest.raises(Exception) as e_info:
        irr.Metrics.Diks.GetPValue( TS[ :-1 ] )


def test_LocalCC():

    targetL = 2

    TS = np.random.uniform( 0., 1., (targetL + 1) )
    irr.Metrics.LocalCC.GetPValue( TS )
    with pytest.raises(Exception) as e_info:
        irr.Metrics.LocalCC.GetPValue( TS[ :-1 ] )


def test_MSTrends():

    targetL = 2

    TS = np.random.uniform( 0., 1., (targetL + 1) )
    irr.Metrics.MSTrends.GetPValue( TS )
    with pytest.raises(Exception) as e_info:
        irr.Metrics.MSTrends.GetPValue( TS[ :-1 ] )


def test_PermPatterns():

    targetL = 3

    TS = np.random.uniform( 0., 1., (targetL + 1) )
    irr.Metrics.PermPatterns.GetPValue( TS )
    with pytest.raises(Exception) as e_info:
        irr.Metrics.PermPatterns.GetPValue( TS[ :-1 ] )


def test_Pomeau():

    targetL = 4

    TS = np.random.uniform( 0., 1., (targetL + 1) )
    irr.Metrics.Pomeau.GetPValue( TS )
    with pytest.raises(Exception) as e_info:
        irr.Metrics.Pomeau.GetPValue( TS[ :-1 ] )


def test_Ramsey():

    targetL = 3

    TS = np.random.uniform( 0., 1., (targetL + 1) )
    irr.Metrics.Ramsey.GetPValue( TS )
    with pytest.raises(Exception) as e_info:
        irr.Metrics.Ramsey.GetPValue( TS[ :-1 ] )


def test_Skewness():

    targetL = 3

    TS = np.random.uniform( 0., 1., (targetL + 1) )
    irr.Metrics.Skewness.GetPValue( TS )
    with pytest.raises(Exception) as e_info:
        irr.Metrics.Skewness.GetPValue( TS[ :-1 ] )


def test_TernaryCoding():

    targetL = 4

    TS = np.random.uniform( 0., 1., (targetL + 1) )
    irr.Metrics.TernaryCoding.GetPValue( TS )
    with pytest.raises(Exception) as e_info:
        irr.Metrics.TernaryCoding.GetPValue( TS[ :-1 ] )


def test_TPLength():

    targetL = 2

    TS = np.random.uniform( 0., 1., (targetL + 1) )
    irr.Metrics.TPLength.GetPValue( TS )
    with pytest.raises(Exception) as e_info:
        irr.Metrics.TPLength.GetPValue( TS[ :-1 ] )


def test_VisibilityGraph():

    targetL = 6

    TS = np.random.uniform( 0., 1., (targetL + 1) )
    irr.Metrics.VisibilityGraph.GetPValue( TS )
    with pytest.raises(Exception) as e_info:
        irr.Metrics.VisibilityGraph.GetPValue( TS[ :-1 ] )


def test_Zumbach():

    targetL = 2

    TS = np.random.uniform( 0., 1., (targetL + 1) )
    irr.Metrics.Zumbach.GetPValue( TS )
    with pytest.raises(Exception) as e_info:
        irr.Metrics.Zumbach.GetPValue( TS[ :-1 ] )

