import pytest
from pytest import approx

import numpy as np
import copy

import irreversibility as irr



@pytest.mark.parametrize("horizon", [-1, 10, 50])
@pytest.mark.parametrize("length", [ 20, 40, 80 ])
def test_TS_Does_Not_Change( horizon, length ):

    TS = np.random.uniform( 0., 1., (length) )
    TS2 = copy.deepcopy( TS )

    irr.Metrics.VisibilityGraph.GetPValue( TS, horizon = horizon )
    assert np.sum( TS - TS2 ) == 0, (
        "Time series has been modified"
    )




@pytest.mark.parametrize("length", [ 20, 40, 80 ])
def test_GetPValue( length ):
    """Test the functions for calculating the p-value"""

    TS = np.random.uniform( 0., 1., (length) )

    with pytest.raises(ValueError):
        irr.Metrics.VisibilityGraph.GetPValue( TS, horizon = 1. )
    with pytest.raises(ValueError):
        irr.Metrics.VisibilityGraph.GetPValue( TS, horizon = -2 )

    irr.Metrics.VisibilityGraph.GetPValue( TS )




@pytest.mark.parametrize("length", [ 20, 40, 80 ])
def test_GetStatistic( length ):
    """Test the functions for calculating the p-value"""

    TS = np.random.uniform( 0., 1., (length) )

    result = irr.Metrics.VisibilityGraph.GetStatistic( TS )
    assert isinstance( result, float )





def test_Optimisation():
    """Test the functions for optimising the parameters"""

    from irreversibility.ParameterOptimisation.Opt_VisibilityGraph import Optimisation

    tsSet = []
    for k in range( 10 ):
        tsSet.append( np.random.uniform( 0., 1., (80) ) )

    Optimisation( tsSet )

