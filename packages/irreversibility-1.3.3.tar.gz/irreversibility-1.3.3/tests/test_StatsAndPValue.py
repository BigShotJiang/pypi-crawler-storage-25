import pytest
from pytest import approx

import numpy as np
import copy

import irreversibility as irr



def test_BDS():
    TS = np.random.uniform( 0., 1., ( 80 ) )
    pvalue, stat = irr.Metrics.BDS.GetPValue(TS)
    assert isinstance(pvalue, float)
    assert isinstance(stat, float)
    assert stat == irr.Metrics.BDS.GetStatistic(TS)
    assert 0.0 <= pvalue <= 1.0

