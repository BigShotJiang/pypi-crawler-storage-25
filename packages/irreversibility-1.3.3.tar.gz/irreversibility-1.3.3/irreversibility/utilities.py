
import numpy as np

from .warningHandling import warnUser


def _CheckTSValidity( TS, minimumLength, warningOnConstant = True ):

    if np.ndim( TS ) != 1:
        raise ValueError("The time series seems to have too many dimensions")

    if np.size( TS ) <= minimumLength:
        raise ValueError("The time series is too short to perform this test")
    
    if warningOnConstant:
        if np.std( TS ) == 0.:
            warnUser( source = 'TS Check', message = "The time series is constant, the output of this test will not be reliable" )
    
