"""
irreversibility v1.3.3 — Time series irreversibility testing library
=====================================================================

A library to calculate statistical tests of time irreversibility on
continuous and discrete time series, plus utilities for time series
generation, preprocessing, downsampling, and parameter optimisation.

To print this reference at any time::

    import irreversibility
    irreversibility.describe()


QUICK START
-----------
::

    import numpy as np
    from irreversibility.Metrics.BDS import GetPValue

    ts = np.random.randn(500)
    p_value, statistic = GetPValue(ts)
    print(p_value)   # small value (< 0.05) indicates irreversibility

Run all 17 continuous tests at once::

    from irreversibility import allTests
    for name, test in allTests:
        p_value, statistic = test(ts)
        print(name, p_value)


RETURN VALUE CONVENTION
-----------------------
All GetPValue functions return a tuple: (p_value: float, statistic: float).
A small p-value (< 0.05) indicates that the time series is statistically
irreversible (i.e., time-asymmetric). GetStatistic returns only the float
statistic.


CONTINUOUS IRREVERSIBILITY TESTS  (input: 1-D numpy.ndarray)
-------------------------------------------------------------
All functions share the signature::

    GetPValue(TS: numpy.ndarray, **kwargs) -> tuple[float, float]
    GetStatistic(TS: numpy.ndarray, **kwargs) -> float

1.  BDS test (Broock, Scheinkman, Dechert & LeBaron 1996)::

        from irreversibility.Metrics.BDS import GetPValue
        GetPValue(TS, max_dim=2, distance=1.5)

2.  Casali test (Casali et al. 2008)::

        from irreversibility.Metrics.Casali import GetPValue
        GetPValue(TS, m=1, numRndReps=100, pValueMethod='proportion')
        # pValueMethod: 'proportion' or 'z-score'

3.  COP (Continuous Ordinal Patterns) test (Zanin 2023)::

        from irreversibility.Metrics.COP import GetPValue
        GetPValue(TS, pSize=3, numIters=auto, useShaders=False)

4.  Costa Index test (Costa, Goldberger & Peng 2005)::

        from irreversibility.Metrics.CostaIndex import GetPValue
        GetPValue(TS, tau=1, method='fraction', numRndReps=100, pValueMethod='z-score')
        # method: 'fraction' or 'entropy'
        # pValueMethod: 'proportion' or 'z-score'

5.  DFK (Daw-Finney-Kennel) test (Daw et al. 2000)::

        from irreversibility.Metrics.DFK import GetPValue
        GetPValue(TS, n=3, L=3)

6.  Diks test (Diks et al. 1996)::

        from irreversibility.Metrics.Diks import GetPValue
        GetPValue(TS, embD=6, dVar=1.5)

7.  Local Clustering Coefficient test (Donges, Donner & Kurths 2013)::

        from irreversibility.Metrics.LocalCC import GetPValue
        GetPValue(TS)  # no optional parameters

8.  MS Trends (Micro-Scale Trends) test (Zanin 2021)::

        from irreversibility.Metrics.MSTrends import GetPValue
        GetPValue(TS, wSize=2, wSize2=20)

9.  Permutation Patterns test (Zanin et al. 2018)::

        from irreversibility.Metrics.PermPatterns import GetPValue
        GetPValue(TS, pSize=3)

10. Pomeau test (Pomeau 1982)::

        from irreversibility.Metrics.Pomeau import GetPValue
        GetPValue(TS, tau=1, numRndReps=100, pValueMethod='proportion', useShaders=False)
        # pValueMethod: 'proportion' or 'z-score'

11. Product of Powers test (Nogare & Fulcher 2025)::

        from irreversibility.Metrics.ProductOfPowers import GetPValue
        GetPValue(TS, exponents=numpy.array([1, 3]), abs=True)

12. Ramsey test (Ramsey & Rothman 1996)::

        from irreversibility.Metrics.Ramsey import GetPValue
        GetPValue(TS, kappa=1)

13. Skewness test (Koutsoyiannis 2019)::

        from irreversibility.Metrics.Skewness import GetPValue
        GetPValue(TS, numRndReps=100, pValueMethod='z-score')
        # pValueMethod: 'proportion' or 'z-score'

14. Ternary Coding test (Cammarota & Rogora 2007)::

        from irreversibility.Metrics.TernaryCoding import GetPValue
        GetPValue(TS, segL=4, alpha=10)
        # alpha: percentile threshold (integer, 0-100)

15. TP Length (Trend Pattern Lengths) test (Morales Herrera & Salgado-Garcia 2024)::

        from irreversibility.Metrics.TPLength import GetPValue
        GetPValue(TS)  # no optional parameters

16. Visibility Graph test (Lacasa et al. 2012)::

        from irreversibility.Metrics.VisibilityGraph import GetPValue
        GetPValue(TS, horizon=-1, parallel=False)
        # horizon=-1 uses the full series; any positive int limits link distance

17. Zumbach test (Zumbach 2009)::

        from irreversibility.Metrics.Zumbach import GetPValue
        GetPValue(TS, deltaT=20, granularity=3)

The list ``allTests`` contains all 17 tests as [name, GetPValue] pairs::

    from irreversibility import allTests
    # allTests[i] = ['TestName', GetPValue_function]


DISCRETE IRREVERSIBILITY TESTS  (input: integer-valued array or list of walks)
-------------------------------------------------------------------------------
1.  Gaspard test — entropy production (Gaspard 2004)::

        from irreversibility.DiscreteMetrics.Gaspard import GetPValue
        GetPValue(TS, n=3, numRndReps=100, pValueMethod='proportion', useShaders=False)
        # TS: numpy.ndarray of integers
        # pValueMethod: 'proportion' or 'z-score'

2.  Costa Index (discrete) test::

        from irreversibility.DiscreteMetrics.CostaIndex import GetPValue
        GetPValue(TS, tau=1, numRndReps=100, pValueMethod='z-score')
        # TS: numpy.ndarray of integers

3.  Detailed Balance test::

        from irreversibility.DiscreteMetrics.DetBalance import GetPValue
        GetPValue(Walks, conditional=False, numRndReps=100)
        # Walks: list of numpy.ndarray paths (each path is a 1-D array of node IDs)
        #        or a single numpy.ndarray treated as one walk

The list ``allTestsDiscrete`` contains all 3 tests as [name, GetPValue] pairs::

    from irreversibility import allTestsDiscrete


ADDITIONAL UTILITIES
--------------------
Time series generators (all return numpy.ndarray)::

    from irreversibility.TimeSeriesGeneration.Lorenz import lorenz
    from irreversibility.TimeSeriesGeneration.OUProcess import OrnsteinUhlenbeck
    from irreversibility.TimeSeriesGeneration.Logistic import logistic
    from irreversibility.TimeSeriesGeneration.Henon import henon
    from irreversibility.TimeSeriesGeneration.srGBM import srGBM
    from irreversibility.TimeSeriesGeneration.MSModel import msmodel, msmodel_periodic
    from irreversibility.TimeSeriesGeneration.SymbolicRandomWalk import UnbiasedRandomWalk, BiasedRandomWalk
    from irreversibility.TimeSeriesGeneration.LCG import congruential
    from irreversibility.TimeSeriesGeneration.aWeierstrass import aWeierstrass

Parameter optimisation — returns (best_params: dict, best_value: float)::

    from irreversibility.ParameterOptimisation.Opt_BDS import Optimisation
    best_params, best_value = Optimisation(tsSet)
    # tsSet: list of numpy.ndarray time series
    # Replace 'BDS' with any metric name: Casali, COP, CostaIndex,
    #   CostaIndexDiscrete, DFK, Diks, LocalCC, MSTrends, PermPatterns,
    #   Pomeau, ProductOfPowers, Ramsey, Skewness, TernaryCoding,
    #   TPLength, VisibilityGraph, Zumbach

Preprocessing::

    from irreversibility.Preprocessing.PermPatterns import TimeSeriesToPermPatterns
    encoded_ts, patterns = TimeSeriesToPermPatterns(TS, pSize=3, overlapping=True)

Downsampling::

    from irreversibility.Downsampling.Downsampling import OneEveryN, Downsampling_Avg, Decimate
    downsampled = OneEveryN(TS, tau)       # keep every tau-th sample
    downsampled = Downsampling_Avg(TS, tau)  # average within windows of size tau
    downsampled = Decimate(TS, tau)        # scipy-based decimation

COP manipulation — increase or decrease measured irreversibility::

    from irreversibility.Manipulation.COP import GetTransformedTimeSeries
    transformed_ts, best_pv, correlation = GetTransformedTimeSeries(
        TS, test, testParams={}, increase=True,
        pSize=4, numIterations=1000, pvThreshold=0.001)
    # test: any GetPValue function
    # increase=True maximises irreversibility; False minimises it
"""

from .exposeTests import allTests
from .exposeTestsDiscrete import allTests as allTestsDiscrete


__version__ = "1.3.3"


def describe():
    """Print the full public API reference for the irreversibility package."""
    print(__doc__)


__all__ = [
    "__version__",
    "allTests",
    "allTestsDiscrete",
    "describe",
]
