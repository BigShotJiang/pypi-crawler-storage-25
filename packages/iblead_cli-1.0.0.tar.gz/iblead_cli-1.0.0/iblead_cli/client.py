"""Shared HTTP client for the IBLead API v1."""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any, Optional

import click
import requests

DEFAULT_BASE_URL = "https://app.iblead.com/api/v1"
CREDENTIALS_PATH = Path.home() / ".config" / "iblead" / "credentials"
USER_AGENT = "iblead-cli/1.0.0"


def _base_url() -> str:
    return os.environ.get("IBLEAD_API_URL", DEFAULT_BASE_URL).rstrip("/")


def load_api_key() -> Optional[str]:
    """Resolve API key. Env var wins over credentials file."""
    key = os.environ.get("IBLEAD_API_KEY")
    if key:
        return key.strip()
    if CREDENTIALS_PATH.is_file():
        try:
            return CREDENTIALS_PATH.read_text(encoding="utf-8").strip() or None
        except OSError:
            return None
    return None


def require_api_key() -> str:
    key = load_api_key()
    if not key:
        click.echo(
            "Error: no API key found. Run `iblead login` or set IBLEAD_API_KEY.",
            err=True,
        )
        sys.exit(2)
    return key


def save_api_key(key: str) -> None:
    CREDENTIALS_PATH.parent.mkdir(parents=True, exist_ok=True)
    CREDENTIALS_PATH.write_text(key.strip() + "\n", encoding="utf-8")
    try:
        os.chmod(CREDENTIALS_PATH, 0o600)
    except OSError:
        pass


def delete_api_key() -> bool:
    if CREDENTIALS_PATH.is_file():
        CREDENTIALS_PATH.unlink()
        return True
    return False


def _auth_headers(api_key: Optional[str] = None) -> dict:
    key = api_key or require_api_key()
    return {
        "Authorization": f"Bearer {key}",
        "User-Agent": USER_AGENT,
        "Accept": "application/json",
    }


def _handle_response(resp: requests.Response) -> Any:
    if resp.status_code == 401:
        click.echo("Error: invalid or revoked API key. Run `iblead login` again.", err=True)
        sys.exit(2)
    if resp.status_code == 403:
        click.echo("Error: your plan does not allow this action (403).", err=True)
        sys.exit(3)
    if resp.status_code == 402:
        try:
            body = resp.json()
            click.echo(
                f"Error: insufficient credits. Balance {body.get('balance')} / cost {body.get('cost')}.",
                err=True,
            )
        except ValueError:
            click.echo("Error: insufficient credits (402).", err=True)
        sys.exit(4)
    if resp.status_code == 429:
        retry = resp.headers.get("Retry-After")
        msg = "Rate limited (429)."
        if retry:
            msg += f" Retry after {retry}s."
        try:
            detail = resp.json().get("detail")
            if detail:
                msg += f" {detail}"
        except ValueError:
            pass
        click.echo(f"Error: {msg}", err=True)
        sys.exit(5)
    if resp.status_code >= 500:
        click.echo(f"Error: server error {resp.status_code}. Try again in a moment.", err=True)
        sys.exit(6)
    if not resp.ok:
        try:
            detail = resp.json().get("detail", resp.text)
        except ValueError:
            detail = resp.text
        click.echo(f"Error {resp.status_code}: {detail}", err=True)
        sys.exit(7)
    ctype = resp.headers.get("Content-Type", "")
    if "application/json" in ctype:
        return resp.json()
    return resp.content


def api_get(path: str, params: Optional[dict] = None, *, api_key: Optional[str] = None, timeout: int = 60) -> Any:
    url = f"{_base_url()}{path}"
    clean_params = _clean_params(params)
    resp = requests.get(url, params=clean_params, headers=_auth_headers(api_key), timeout=timeout)
    return _handle_response(resp)


def api_post(path: str, body: Optional[dict] = None, *, api_key: Optional[str] = None, timeout: int = 120) -> Any:
    url = f"{_base_url()}{path}"
    headers = _auth_headers(api_key)
    headers["Content-Type"] = "application/json"
    resp = requests.post(url, data=json.dumps(body or {}), headers=headers, timeout=timeout)
    return _handle_response(resp)


def api_delete(path: str, *, api_key: Optional[str] = None, timeout: int = 60) -> Any:
    url = f"{_base_url()}{path}"
    resp = requests.delete(url, headers=_auth_headers(api_key), timeout=timeout)
    return _handle_response(resp)


def _clean_params(params: Optional[dict]) -> Optional[dict]:
    if not params:
        return None
    cleaned = {}
    for k, v in params.items():
        if v is None:
            continue
        if isinstance(v, bool):
            cleaned[k] = "true" if v else "false"
        else:
            cleaned[k] = v
    return cleaned or None


def read_wkt_arg(value: Optional[str]) -> Optional[str]:
    """Accept either a raw WKT string or `@path/to/file.wkt`."""
    if not value:
        return None
    if value.startswith("@"):
        path = Path(value[1:]).expanduser()
        if not path.is_file():
            click.echo(f"Error: WKT file not found: {path}", err=True)
            sys.exit(1)
        return path.read_text(encoding="utf-8").strip()
    return value.strip()


def print_json(data: Any) -> None:
    click.echo(json.dumps(data, indent=2, ensure_ascii=False, default=str))
