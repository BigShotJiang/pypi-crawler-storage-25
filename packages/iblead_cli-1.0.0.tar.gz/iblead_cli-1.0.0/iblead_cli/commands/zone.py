"""Zone / polygon tooling — offline helpers around WKT."""

import re
import sys
from pathlib import Path

import click

# Mirrors `validate_bbox_wkt` from gmaps_api/marketplace_utils.py.
_WKT_RE = re.compile(
    r"^POLYGON\s*\(\s*\(\s*"
    r"(-?\d+(?:\.\d+)?)\s+(-?\d+(?:\.\d+)?)"
    r"(?:\s*,\s*(-?\d+(?:\.\d+)?)\s+(-?\d+(?:\.\d+)?)){3,999}"
    r"\s*\)\s*\)\s*$"
)


@click.group()
def zone():
    """Validate and build WKT polygons for zone-scoped queries."""
    pass


@zone.command("validate")
@click.argument("source")
def zone_validate(source):
    """Validate a WKT polygon from a file, a "@file" reference or a raw string."""
    wkt = _read_source(source)
    ok, err = _validate(wkt)
    if not ok:
        click.echo(f"Invalid: {err}", err=True)
        sys.exit(1)
    points = _count_points(wkt)
    click.echo(f"Valid WKT polygon — {points} points.")


@zone.command("rectangle")
@click.option("--min-lat", required=True, type=float)
@click.option("--min-lon", required=True, type=float)
@click.option("--max-lat", required=True, type=float)
@click.option("--max-lon", required=True, type=float)
def zone_rectangle(min_lat, min_lon, max_lat, max_lon):
    """Emit a WKT rectangle from bounding-box coords."""
    if min_lat >= max_lat or min_lon >= max_lon:
        click.echo("Error: min coords must be lower than max coords.", err=True)
        sys.exit(1)
    wkt = (
        f"POLYGON(({min_lon} {min_lat}, {max_lon} {min_lat}, "
        f"{max_lon} {max_lat}, {min_lon} {max_lat}, {min_lon} {min_lat}))"
    )
    click.echo(wkt)


# ---------------------------------------------------------------------------

def _read_source(source: str) -> str:
    if source.startswith("@"):
        p = Path(source[1:]).expanduser()
    else:
        p = Path(source).expanduser()
    if p.is_file():
        return p.read_text(encoding="utf-8").strip()
    return source.strip()


def _validate(wkt: str) -> tuple[bool, str]:
    if not wkt:
        return False, "empty input"
    if len(wkt) > 32000:
        return False, "WKT too long (>32000 chars)"
    if not _WKT_RE.match(wkt):
        return False, "does not match POLYGON((lon lat, ...)) shape, need 4-1000 points"
    coords = _parse_coords(wkt)
    if coords[0] != coords[-1]:
        return False, "ring is not closed (first point != last)"
    for lon, lat in coords:
        if not -180 <= lon <= 180:
            return False, f"longitude out of range: {lon}"
        if not -90 <= lat <= 90:
            return False, f"latitude out of range: {lat}"
    return True, ""


def _parse_coords(wkt: str) -> list:
    inner = wkt[wkt.index("((") + 2: wkt.rindex("))")]
    return [tuple(map(float, pt.strip().split())) for pt in inner.split(",")]


def _count_points(wkt: str) -> int:
    return len(_parse_coords(wkt))
