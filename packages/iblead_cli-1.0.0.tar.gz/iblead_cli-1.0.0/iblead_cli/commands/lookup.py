"""Lookup command — find a business by place_id, CID or Google Maps URL."""

import sys
from pathlib import Path

import click

from iblead_cli.client import api_get, api_post, print_json


@click.group()
def lookup():
    """Lookup businesses by place_id, CID, or Google Maps URL."""
    pass


@lookup.command("one")
@click.argument("query")
def lookup_one(query):
    """Lookup a single business. QUERY = place_id, CID, or Google Maps URL."""
    data = api_get("/lookup", params={"q": query})
    print_json(data)


@lookup.command("bulk")
@click.option("--file", "-f", "input_file", type=click.Path(exists=True, dir_okay=False), required=False,
              help="File with one identifier per line.")
@click.argument("items", nargs=-1)
def lookup_bulk(input_file, items):
    """Lookup up to 100 businesses in one call. Reads stdin if no --file / args given."""
    ids: list[str] = list(items)
    if input_file:
        ids.extend([
            line.strip()
            for line in Path(input_file).read_text(encoding="utf-8").splitlines()
            if line.strip()
        ])
    if not ids and not sys.stdin.isatty():
        ids.extend([line.strip() for line in sys.stdin if line.strip()])

    if not ids:
        click.echo("Error: no identifiers provided (use arguments, --file, or stdin).", err=True)
        sys.exit(1)
    if len(ids) > 100:
        click.echo(f"Error: bulk lookup is limited to 100 items (got {len(ids)}).", err=True)
        sys.exit(1)

    data = api_post("/lookup/bulk", body={"items": ids})
    print_json(data)
