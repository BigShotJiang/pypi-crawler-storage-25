"""Search command — paginated listing of businesses."""

import csv
import sys
from typing import Optional

import click

from iblead_cli.client import api_get, print_json, read_wkt_arg


_BOOL_FLAGS = [
    ("has_website", "--has-website/--no-has-website", "Filter by website presence."),
    ("has_phone", "--has-phone/--no-has-phone", "Filter by phone presence."),
    ("has_email", "--has-email/--no-has-email", "Filter by email presence."),
    ("has_facebook", "--has-facebook/--no-has-facebook", "Filter by Facebook."),
    ("has_instagram", "--has-instagram/--no-has-instagram", "Filter by Instagram."),
    ("has_linkedin", "--has-linkedin/--no-has-linkedin", "Filter by LinkedIn."),
    ("has_youtube", "--has-youtube/--no-has-youtube", "Filter by YouTube."),
    ("has_twitter", "--has-twitter/--no-has-twitter", "Filter by Twitter/X."),
    ("has_siret", "--has-siret/--no-has-siret", "Filter by SIRET (FR only)."),
    ("has_claimed", "--has-claimed/--no-has-claimed", "Filter by claimed on Google."),
]


def _add_bool_flags(func):
    for name, flag, help_ in reversed(_BOOL_FLAGS):
        func = click.option(flag, name, default=None, help=help_)(func)
    return func


@click.command()
@click.option("--country", "-c", help="ISO-2 country code (e.g. FR, US).")
@click.option("--countries", help="Comma-separated ISO-2 codes.")
@click.option("--category", help="Macro category (see `iblead categories`).")
@click.option("--subcategory", help="Subcategory (see `iblead subcategories`).")
@click.option("--cities", help="Comma-separated cities.")
@click.option("--postal-codes", help="Comma-separated postal codes (prefixes allowed: 75%).")
@click.option("--min-rating", type=float)
@click.option("--max-rating", type=float)
@click.option("--min-reviews", type=int)
@click.option("--max-reviews", type=int)
@click.option("--phone-type", type=click.Choice(["mobile", "landline"]), default=None)
@click.option("--ape-codes", help="Comma-separated APE codes (FR).")
@click.option(
    "--bbox",
    "bbox_wkt",
    help='WKT POLYGON, or "@file.wkt" to read from a file.',
)
@click.option("--limit", "-n", type=click.IntRange(1, 200), default=50, show_default=True)
@click.option("--offset", type=click.IntRange(0), default=0, show_default=True)
@click.option("--include-reviews/--no-reviews", default=True, show_default=True)
@click.option("--only-unlocked", is_flag=True, help="Restrict to fiches already unlocked by this account.")
@click.option("--format", "-f", "fmt", type=click.Choice(["json", "csv", "table"]), default="json", show_default=True)
@_add_bool_flags
def search(
    country,
    countries,
    category,
    subcategory,
    cities,
    postal_codes,
    min_rating,
    max_rating,
    min_reviews,
    max_reviews,
    phone_type,
    ape_codes,
    bbox_wkt,
    limit,
    offset,
    include_reviews,
    only_unlocked,
    fmt,
    **bool_filters,
):
    """Search businesses. Max 200 per page; use --offset to paginate.

    Examples:

      iblead search --country FR --category Restaurant -n 20

      iblead search --bbox @paris.wkt --has-email -f csv > out.csv
    """
    params = {
        "country": country,
        "countries": countries,
        "category": category,
        "subcategory": subcategory,
        "cities": cities,
        "postal_codes": postal_codes,
        "min_rating": min_rating,
        "max_rating": max_rating,
        "min_reviews": min_reviews,
        "max_reviews": max_reviews,
        "phone_type": phone_type,
        "ape_codes": ape_codes,
        "bbox_wkt": read_wkt_arg(bbox_wkt),
        "limit": limit,
        "offset": offset,
        "include_reviews": include_reviews,
        "only_unlocked": only_unlocked,
    }
    for k, v in bool_filters.items():
        if v is not None:
            params[k] = v

    data = api_get("/businesses", params=params)

    if fmt == "json":
        print_json(data)
        return

    rows = data.get("data", [])
    if not rows:
        click.echo("No results.", err=True)
        return

    if fmt == "csv":
        _write_csv(rows, sys.stdout)
    else:  # table
        _write_table(rows)


def _write_csv(rows, out) -> None:
    fields = _collect_fields(rows)
    writer = csv.DictWriter(out, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    for r in rows:
        writer.writerow({k: _flatten_cell(r.get(k)) for k in fields})


def _write_table(rows) -> None:
    cols = ["id", "name", "city", "country_code", "rating", "review_count", "phone", "website"]
    cols = [c for c in cols if any(c in r for r in rows)]
    widths = {c: max(len(c), *(len(str(r.get(c, "") or "")[:40]) for r in rows)) for c in cols}
    click.echo(" | ".join(c.ljust(widths[c]) for c in cols))
    click.echo("-+-".join("-" * widths[c] for c in cols))
    for r in rows:
        click.echo(" | ".join(str(r.get(c, "") or "")[:40].ljust(widths[c]) for c in cols))


def _collect_fields(rows) -> list:
    seen = []
    for r in rows:
        for k in r.keys():
            if k not in seen:
                seen.append(k)
    return seen


def _flatten_cell(v) -> str:
    if v is None:
        return ""
    if isinstance(v, (list, dict)):
        import json
        return json.dumps(v, ensure_ascii=False)
    return str(v)
