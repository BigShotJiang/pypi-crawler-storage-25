"""Metadata commands: credits/account, categories, countries, cities."""

import click

from iblead_cli.client import api_get, print_json


@click.command()
def credits():
    """Show credit balance + daily export usage."""
    data = api_get("/account")
    click.echo(f"Email:  {data.get('email', '?')}")
    click.echo(f"Tier:   {data.get('tier', '?')}")
    click.echo(f"Credits: {data.get('credits', 0)}")
    used = data.get("daily_export_used", 0)
    limit = data.get("daily_export_limit", 0)
    remaining = data.get("daily_export_remaining", 0)
    click.echo(f"Daily export: {used} / {limit} ({remaining} remaining)")
    lc = data.get("lifetime_countries") or []
    if lc:
        click.echo("LTV countries:")
        for c in lc:
            click.echo(f"  - {c.get('country_code')} ({c.get('plan_type')})")


@click.command()
@click.option("--country", "-c", help="Limit to a country.")
@click.option("--format", "-f", "fmt", type=click.Choice(["json", "table"]), default="table")
def categories(country, fmt):
    """List macro categories with counts."""
    data = api_get("/categories", params={"country": country})
    if fmt == "json":
        print_json(data)
        return
    rows = data.get("data", [])
    for r in rows:
        name = r.get("category") or r.get("name") or "?"
        count = r.get("count") or r.get("total") or ""
        click.echo(f"{name:<40}  {count}")


@click.command()
@click.option("--category", help="Macro category to filter.")
@click.option("--search", help="Substring search.")
@click.option("--limit", type=click.IntRange(1, 500), default=50, show_default=True)
@click.option("--offset", type=click.IntRange(0), default=0)
def subcategories(category, search, limit, offset):
    """List subcategories (~4000 in the tree)."""
    data = api_get("/subcategories", params={
        "category": category,
        "search": search,
        "limit": limit,
        "offset": offset,
    })
    print_json(data)


@click.command()
@click.option("--format", "-f", "fmt", type=click.Choice(["json", "table"]), default="table")
def countries(fmt):
    """List countries available in the database."""
    data = api_get("/countries")
    if fmt == "json":
        print_json(data)
        return
    for r in data.get("data", []):
        code = r.get("country_code") or r.get("code") or "?"
        count = r.get("count") or r.get("total") or ""
        name = r.get("country_name") or r.get("name") or ""
        click.echo(f"{code}  {count:>10}  {name}")


@click.command()
@click.option("--country", "-c", required=True)
@click.option("--search")
@click.option("--limit", type=click.IntRange(1, 100), default=30, show_default=True)
@click.option("--offset", type=click.IntRange(0), default=0)
def cities(country, search, limit, offset):
    """List cities for a country."""
    data = api_get("/cities", params={
        "country": country,
        "search": search,
        "limit": limit,
        "offset": offset,
    })
    print_json(data)
