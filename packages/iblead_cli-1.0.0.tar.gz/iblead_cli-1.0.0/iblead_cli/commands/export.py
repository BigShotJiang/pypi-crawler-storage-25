"""Export command — async POST + poll + download in one line.

This is the CLI's killer feature: replaces the 3-call sequence
(POST /export → GET /export/jobs/{id} loop → GET presigned URL)
with a single `iblead export run ...`.
"""

from __future__ import annotations

import sys
import time
from pathlib import Path
from typing import Optional

import click
import requests

from iblead_cli.client import api_get, api_post, print_json, read_wkt_arg

_POLL_INTERVAL = 5  # seconds — server rate-limit is 30s but we want feedback
_MAX_POLL_SECONDS = 2 * 3600  # API caps jobs at 2h


@click.group()
def export():
    """Launch and manage asynchronous exports."""
    pass


_BOOL_FLAGS = [
    ("has_website", "--has-website/--no-has-website"),
    ("has_phone", "--has-phone/--no-has-phone"),
    ("has_email", "--has-email/--no-has-email"),
    ("has_facebook", "--has-facebook/--no-has-facebook"),
    ("has_instagram", "--has-instagram/--no-has-instagram"),
    ("has_linkedin", "--has-linkedin/--no-has-linkedin"),
    ("has_youtube", "--has-youtube/--no-has-youtube"),
    ("has_twitter", "--has-twitter/--no-has-twitter"),
    ("has_siret", "--has-siret/--no-has-siret"),
    ("has_claimed", "--has-claimed/--no-has-claimed"),
]


def _add_bool_flags(func):
    for name, flag in reversed(_BOOL_FLAGS):
        func = click.option(flag, name, default=None)(func)
    return func


@export.command("run")
@click.option("--country", "-c", required=False, help="ISO-2 country code (recommended).")
@click.option("--category")
@click.option("--subcategory")
@click.option("--cities", help="Comma-separated.")
@click.option("--postal-codes", help="Comma-separated (prefixes allowed).")
@click.option("--min-rating", type=float)
@click.option("--max-rating", type=float)
@click.option("--min-reviews", type=int)
@click.option("--max-reviews", type=int)
@click.option("--phone-type", type=click.Choice(["mobile", "landline"]), default=None)
@click.option("--ape-codes", help="Comma-separated APE codes (FR).")
@click.option("--bbox", "bbox_wkt", help='WKT POLYGON, or "@file.wkt".')
@click.option("--format", "-f", "fmt", type=click.Choice(["csv", "json"]), default="csv", show_default=True)
@click.option("--limit", type=int, help="Max records. Default = everything.")
@click.option("--include-reviews/--no-reviews", default=True, show_default=True,
              help="--no-reviews makes files ~50x smaller.")
@click.option("--resume/--no-resume", default=True, show_default=True)
@click.option("--redownload", is_flag=True, help="Re-export everything (disables the cursor).")
@click.option("--webhook-url", help="If set, you'll receive a POST when the export is ready.")
@click.option("--output", "-o", type=click.Path(dir_okay=False, writable=True),
              help="Where to save the file. Default: iblead-export-<job_id>.<fmt>")
@click.option("--wait/--no-wait", default=True, show_default=True,
              help="--no-wait prints the job_id and exits immediately.")
@click.option("--poll-interval", type=click.IntRange(3, 60), default=_POLL_INTERVAL, show_default=True)
@_add_bool_flags
def export_run(
    country, category, subcategory, cities, postal_codes,
    min_rating, max_rating, min_reviews, max_reviews,
    phone_type, ape_codes, bbox_wkt, fmt, limit,
    include_reviews, resume, redownload,
    webhook_url, output, wait, poll_interval,
    **bool_filters,
):
    """Launch an export, wait for it to finish, and download the file.

    Example:

      iblead export run --country FR --category Restaurant \\
                        --has-email -o restos.csv
    """
    body: dict = {
        "country": country,
        "category": category,
        "subcategory": subcategory,
        "cities": _split_csv(cities),
        "postal_codes": _split_csv(postal_codes),
        "min_rating": min_rating,
        "max_rating": max_rating,
        "min_reviews": min_reviews,
        "max_reviews": max_reviews,
        "phone_type": phone_type,
        "ape_codes": _split_csv(ape_codes),
        "bbox_wkt": read_wkt_arg(bbox_wkt),
        "format": fmt,
        "limit": limit,
        "include_reviews": include_reviews,
        "resume": resume,
        "redownload": redownload,
        "webhook_url": webhook_url,
        "async": True,  # always go through the async path from the CLI
    }
    for k, v in bool_filters.items():
        if v is not None:
            body[k] = v
    body = {k: v for k, v in body.items() if v is not None}

    resp = api_post("/export", body=body)
    job_id = resp.get("job_id")
    if not job_id:
        click.echo("Error: server did not return a job_id.", err=True)
        print_json(resp)
        sys.exit(7)
    click.echo(f"Export started — job {job_id}")

    if not wait:
        click.echo(f"Poll: iblead export status {job_id}")
        return

    job = _poll_job(job_id, poll_interval)
    status = job.get("status")
    if status != "completed":
        click.echo(f"Export failed: {job.get('error', 'unknown error')}", err=True)
        sys.exit(7)

    download_url = job.get("download_url")
    if not download_url:
        click.echo("Error: completed job has no download_url.", err=True)
        sys.exit(7)

    out_path = Path(output) if output else Path(f"iblead-export-{job_id}.{fmt}")
    _download(download_url, out_path)

    size_mb = out_path.stat().st_size / (1024 * 1024)
    click.echo(f"Saved {out_path} ({size_mb:.2f} MB, {job.get('count', '?')} records).")
    remaining = job.get("daily_remaining")
    if remaining is not None:
        click.echo(f"Daily remaining: {remaining} / {job.get('daily_limit')}")


@export.command("status")
@click.argument("job_id")
@click.option("--watch", is_flag=True, help="Keep polling until the job finishes.")
@click.option("--poll-interval", type=click.IntRange(3, 60), default=_POLL_INTERVAL)
def export_status(job_id, watch, poll_interval):
    """Show the status of an export job."""
    if watch:
        job = _poll_job(job_id, poll_interval)
    else:
        job = api_get(f"/export/jobs/{job_id}")
    print_json(job)


@export.command("download")
@click.argument("job_id")
@click.option("--output", "-o", type=click.Path(dir_okay=False, writable=True))
def export_download(job_id, output):
    """Download the file for a completed job."""
    job = api_get(f"/export/jobs/{job_id}")
    if job.get("status") != "completed":
        click.echo(f"Job is not completed (status={job.get('status')}).", err=True)
        sys.exit(7)
    url = job.get("download_url")
    fmt = job.get("format", "csv")
    out_path = Path(output) if output else Path(f"iblead-export-{job_id}.{fmt}")
    _download(url, out_path)
    click.echo(f"Saved {out_path}")


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------

def _poll_job(job_id: str, interval: int) -> dict:
    deadline = time.monotonic() + _MAX_POLL_SECONDS
    last_status: Optional[str] = None
    while True:
        job = api_get(f"/export/jobs/{job_id}")
        status = job.get("status")
        if status != last_status:
            click.echo(f"[{_now()}] status: {status}")
            last_status = status
        if status in ("completed", "failed"):
            return job
        if time.monotonic() > deadline:
            click.echo("Error: polling timed out after 2h (server limit).", err=True)
            sys.exit(7)
        time.sleep(interval)


def _download(url: str, out_path: Path) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    # Presigned R2 URL: auth is in the signature, do NOT send Bearer.
    with requests.get(url, stream=True, timeout=3600) as r:
        if not r.ok:
            click.echo(f"Error downloading file: {r.status_code} {r.text[:200]}", err=True)
            sys.exit(7)
        total = int(r.headers.get("Content-Length", "0"))
        done = 0
        with out_path.open("wb") as fh:
            for chunk in r.iter_content(chunk_size=256 * 1024):
                if not chunk:
                    continue
                fh.write(chunk)
                done += len(chunk)
                if total:
                    pct = done * 100 / total
                    click.echo(f"\rDownloading: {pct:5.1f}% ({done // (1024*1024)} MB)", nl=False, err=True)
                else:
                    click.echo(f"\rDownloading: {done // (1024*1024)} MB", nl=False, err=True)
        click.echo("", err=True)


def _split_csv(value: Optional[str]) -> Optional[list]:
    if not value:
        return None
    parts = [p.strip() for p in value.split(",") if p.strip()]
    return parts or None


def _now() -> str:
    return time.strftime("%H:%M:%S")
