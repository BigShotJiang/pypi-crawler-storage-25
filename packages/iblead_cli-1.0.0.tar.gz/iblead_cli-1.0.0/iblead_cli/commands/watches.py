"""Watches — saved searches with optional webhook notifications."""

from typing import Optional

import click

from iblead_cli.client import api_delete, api_get, api_post, print_json, read_wkt_arg


@click.group()
def watch():
    """Manage saved searches (watches)."""
    pass


_BOOL_FLAGS = [
    ("has_website", "--has-website/--no-has-website"),
    ("has_phone", "--has-phone/--no-has-phone"),
    ("has_email", "--has-email/--no-has-email"),
    ("has_facebook", "--has-facebook/--no-has-facebook"),
    ("has_instagram", "--has-instagram/--no-has-instagram"),
    ("has_linkedin", "--has-linkedin/--no-has-linkedin"),
    ("has_youtube", "--has-youtube/--no-has-youtube"),
    ("has_twitter", "--has-twitter/--no-has-twitter"),
    ("has_siret", "--has-siret/--no-has-siret"),
]


def _add_bool_flags(func):
    for name, flag in reversed(_BOOL_FLAGS):
        func = click.option(flag, name, default=None)(func)
    return func


@watch.command("list")
def watch_list():
    """List your watches with new_count for each."""
    data = api_get("/watches")
    print_json(data)


@watch.command("get")
@click.argument("watch_id", type=int)
def watch_get(watch_id):
    """Show a single watch."""
    data = api_get(f"/watches/{watch_id}")
    print_json(data)


@watch.command("new")
@click.argument("watch_id", type=int)
@click.option("--limit", type=click.IntRange(1, 200), default=50)
@click.option("--offset", type=click.IntRange(0), default=0)
def watch_new(watch_id, limit, offset):
    """List new businesses matched by a watch since its cursor."""
    data = api_get(f"/watches/{watch_id}/new", params={"limit": limit, "offset": offset})
    print_json(data)


@watch.command("create")
@click.option("--name")
@click.option("--country", "-c")
@click.option("--category")
@click.option("--subcategory")
@click.option("--cities", help="Comma-separated.")
@click.option("--postal-codes", help="Comma-separated.")
@click.option("--min-rating", type=float)
@click.option("--max-rating", type=float)
@click.option("--min-reviews", type=int)
@click.option("--max-reviews", type=int)
@click.option("--phone-type", type=click.Choice(["mobile", "landline"]), default=None)
@click.option("--ape-codes", help="Comma-separated.")
@click.option("--bbox", "bbox_wkt", help='WKT POLYGON or "@file.wkt".')
@click.option("--webhook-url")
@click.option("--auto-notify/--no-auto-notify", default=False)
@click.option("--since-now/--since-beginning", default=True,
              help="since-now ignores existing businesses (default). since-beginning matches everything.")
@_add_bool_flags
def watch_create(
    name, country, category, subcategory, cities, postal_codes,
    min_rating, max_rating, min_reviews, max_reviews,
    phone_type, ape_codes, bbox_wkt, webhook_url, auto_notify, since_now,
    **bool_filters,
):
    """Create a saved search. Need at least --country, --category, or --bbox."""
    body: dict = {
        "name": name,
        "country": country,
        "category": category,
        "subcategory": subcategory,
        "cities": _split_csv(cities),
        "postal_codes": _split_csv(postal_codes),
        "min_rating": min_rating,
        "max_rating": max_rating,
        "min_reviews": min_reviews,
        "max_reviews": max_reviews,
        "phone_type": phone_type,
        "ape_codes": _split_csv(ape_codes),
        "bbox_wkt": read_wkt_arg(bbox_wkt),
        "webhook_url": webhook_url,
        "auto_notify": auto_notify,
        "since_now": since_now,
    }
    for k, v in bool_filters.items():
        if v is not None:
            body[k] = v
    body = {k: v for k, v in body.items() if v is not None}

    data = api_post("/watches", body=body)
    print_json(data)


@watch.command("delete")
@click.argument("watch_id", type=int)
@click.confirmation_option(prompt="Delete this watch?")
def watch_delete(watch_id):
    """Delete a watch."""
    api_delete(f"/watches/{watch_id}")
    click.echo(f"Deleted watch {watch_id}.")


@watch.command("unlock")
@click.argument("watch_id", type=int)
@click.option("--limit", type=int, help="Maximum number of new fiches to unlock.")
def watch_unlock(watch_id, limit):
    """Unlock the new fiches matched by a watch. Debits credits."""
    body: dict = {}
    if limit is not None:
        body["limit"] = limit
    data = api_post(f"/watches/{watch_id}/unlock", body=body)
    print_json(data)


def _split_csv(value: Optional[str]) -> Optional[list]:
    if not value:
        return None
    parts = [p.strip() for p in value.split(",") if p.strip()]
    return parts or None
