"""Auth commands: login, whoami, logout."""

import sys

import click

from iblead_cli.client import (
    CREDENTIALS_PATH,
    api_get,
    delete_api_key,
    load_api_key,
    save_api_key,
)


@click.command()
@click.option("--api-key", "api_key_opt", help="API key (skips prompt). Read from stdin if '-'.")
def login(api_key_opt):
    """Store your IBLead API key locally (chmod 600)."""
    if api_key_opt == "-":
        key = sys.stdin.read().strip()
    elif api_key_opt:
        key = api_key_opt.strip()
    else:
        key = click.prompt("IBLead API key", hide_input=True).strip()

    if not key:
        click.echo("Error: empty API key.", err=True)
        sys.exit(1)

    # Validate against /account before saving.
    data = api_get("/account", api_key=key)
    save_api_key(key)
    click.echo(f"Saved to {CREDENTIALS_PATH}")
    email = data.get("email") or data.get("user", {}).get("email") or "unknown"
    click.echo(f"Logged in as {email}.")


@click.command()
def whoami():
    """Show the account linked to the current API key."""
    if not load_api_key():
        click.echo("Not logged in. Run `iblead login`.", err=True)
        sys.exit(1)
    data = api_get("/account")
    email = data.get("email") or "?"
    tier = data.get("tier", "?")
    credits = data.get("credits", "?")
    click.echo(f"Email: {email}")
    click.echo(f"Tier:  {tier}")
    click.echo(f"Credits: {credits}")
    lc = data.get("lifetime_countries") or []
    if lc:
        codes = ", ".join(f"{c.get('country_code')}({c.get('plan_type')})" for c in lc)
        click.echo(f"LTV: {codes}")


@click.command()
def logout():
    """Delete the locally stored API key."""
    if delete_api_key():
        click.echo("Logged out.")
    else:
        click.echo("No credentials file to delete.")
