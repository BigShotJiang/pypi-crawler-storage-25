import click

from iblead_cli.commands.auth import login, whoami, logout
from iblead_cli.commands.search import search
from iblead_cli.commands.lookup import lookup
from iblead_cli.commands.export import export
from iblead_cli.commands.watches import watch
from iblead_cli.commands.meta import credits, categories, subcategories, countries, cities
from iblead_cli.commands.zone import zone


@click.group()
@click.version_option("1.0.0", prog_name="iblead")
def cli():
    """IBLead CLI — search, export and watch Google Maps leads.

    Get an API key at https://app.iblead.com/dashboard/api then run:

      iblead login
      iblead credits
      iblead search --country FR --category Restaurant --limit 10

    Docs: https://app.iblead.com/docs/api
    """
    pass


cli.add_command(login)
cli.add_command(whoami)
cli.add_command(logout)
cli.add_command(search)
cli.add_command(lookup)
cli.add_command(export)
cli.add_command(watch)
cli.add_command(credits)
cli.add_command(categories)
cli.add_command(subcategories)
cli.add_command(countries)
cli.add_command(cities)
cli.add_command(zone)


if __name__ == "__main__":
    cli()
