import os

import pytest

from dsvmonkey.detectors.encoding import detect_encoding, detect_mixed_encoding


# ---------- BOM detection ----------


@pytest.mark.parametrize(
    "bom, expected",
    [
        (b"\xef\xbb\xbf", "utf-8-sig"),
        (b"\xff\xfe", "utf-16-le"),
        (b"\xfe\xff", "utf-16-be"),
        (b"\x00\x00\xfe\xff", "utf-32-be"),
        (b"\xff\xfe\x00\x00", "utf-32-le"),
    ],
)
def test_bom_detection(bom, expected):
    # UTF-16/UTF-32 BOMs share prefixes with shorter BOMs, so the detector
    # must check longest markers first. A well-formed body isn't required —
    # the BOM alone is definitive.
    data = bom + b"id,name\n1,alice\n"
    result = detect_encoding(data)
    assert result.value == expected
    assert result.confidence == 1.0
    assert result.method == "bom"


# ---------- Content-based scoring ----------


def test_plain_ascii_is_detected_as_utf8():
    data = b"id,name,age\n1,alice,30\n2,bob,25\n"
    result = detect_encoding(data)
    assert result.value == "utf-8"
    assert result.method == "content-scored"
    assert result.confidence > 0.8


def test_utf8_with_accented_chars_beats_latin1():
    text = "id,name\n1,café\n2,naïve\n3,résumé\n"
    data = text.encode("utf-8")
    result = detect_encoding(data)
    assert result.value == "utf-8"
    # latin-1 would also decode these bytes but as mojibake, so it should
    # either not be the top pick or score lower.
    alt_values = [alt.value for alt in result.alternatives]
    if "latin-1" in alt_values:
        latin_alt = next(a for a in result.alternatives if a.value == "latin-1")
        assert latin_alt.confidence <= result.confidence


def test_cp1252_bytes_not_valid_utf8_pick_cp1252_over_latin1():
    # 0x92 is a cp1252 right single quote, undefined in strict UTF-8 and
    # unassigned in many other encodings; cp1252 and latin-1 both decode.
    data = "don’t,worry\n".encode("cp1252")
    result = detect_encoding(data)
    # Must not be utf-8 since bytes don't decode as utf-8.
    assert result.value != "utf-8"
    # Should prefer cp1252 over latin-1 (latin-1 has a tie-break penalty).
    assert result.value in {"cp1252", "mac_roman", "cp437"}


def test_mojibake_penalizes_wrong_encoding():
    # The bytes "caf\xc3\xa9" are utf-8 for "café"; decoded as latin-1 or
    # cp1252 they produce the mojibake "café". The score for those
    # encodings should be lower than for utf-8.
    data = "café\n".encode("utf-8") * 20
    result = detect_encoding(data)
    assert result.value == "utf-8"


def test_empty_input_does_not_crash():
    result = detect_encoding(b"")
    # Any decision is acceptable; we just require it doesn't raise and
    # returns a well-formed result.
    assert 0.0 <= result.confidence <= 1.0
    assert result.method in {"content-scored", "fallback", "bom"}


# ---------- BOM-less UTF-16 ----------


def test_bomless_utf16_le_detected():
    # Emit UTF-16-LE without the BOM prefix. Real-world case: some
    # tools strip the BOM during export and leave you with raw UTF-16.
    text = "id,name,age\n1,alice,30\n2,bob,25\n3,carol,40\n4,dave,35\n"
    data = text.encode("utf-16-le")
    result = detect_encoding(data)
    assert result.value == "utf-16-le"
    assert result.method == "null-byte-parity"
    assert data.decode(result.value) == text


def test_bomless_utf16_be_detected():
    text = "id,name,age\n1,alice,30\n2,bob,25\n3,carol,40\n4,dave,35\n"
    data = text.encode("utf-16-be")
    result = detect_encoding(data)
    assert result.value == "utf-16-be"
    assert result.method == "null-byte-parity"


def test_bomless_utf16_not_triggered_by_regular_utf8():
    # Plain UTF-8 has effectively zero null bytes; must not be
    # misclassified as UTF-16.
    text = "id,name,age\n1,alice,30\n2,bob,25\n3,carol,40\n4,dave,35\n"
    data = text.encode("utf-8")
    result = detect_encoding(data)
    assert result.value == "utf-8"


def test_bomless_utf16_not_triggered_by_random_binary():
    # Lots of nulls but evenly distributed across both parities →
    # not the UTF-16 pattern. Must fall through to content scoring
    # (or fallback) rather than falsely return UTF-16.
    data = (b"\x00\x01" * 50) + (b"\x02\x00" * 50) + b"text,more,stuff\n" * 10
    result = detect_encoding(data)
    assert result.value not in {"utf-16-le", "utf-16-be"}


# ---------- Mixed-encoding detection ----------


def test_pure_utf8_is_not_mixed():
    data = "hello world,café,naïve\n".encode("utf-8") * 100
    assert detect_mixed_encoding(data) is False


def test_pure_cp1252_is_not_mixed():
    # The whole file fails utf-8 decode, and the tail (after the first
    # bad byte) also fails — that's "not utf-8", not "mixed".
    data = "don’t,worry\n".encode("cp1252") * 50
    assert detect_mixed_encoding(data) is False


def test_isolated_non_utf8_byte_flags_as_mixed():
    # Fixture includes genuine UTF-8 multi-byte sequences (é, ñ) so
    # the data has positive evidence of being UTF-8 before being
    # corrupted by the embedded cp1252 byte (0x92, right single quote).
    # Pure-ASCII + stray byte is ambiguous (could be cp1252 throughout)
    # and is no longer flagged as mixed.
    head = "id,name,note\ncafé,niño,résumé\n".encode("utf-8") * 10
    tail = "more,utf8,rows\njalapeño,olé,piñata\n".encode("utf-8") * 10
    data = head + b"\x92" + tail
    assert detect_mixed_encoding(data) is True


def test_adjacent_bad_bytes_still_flagged_as_mixed():
    # Review finding: the old one-byte-skip + retry logic gave up
    # when two adjacent bytes both failed — a common concatenation
    # artefact (e.g. a copy-paste that tore a cp1252 multi-byte-
    # looking sequence in half). The new surrogate-escape counter
    # correctly counts N adjacent bad bytes as N failures.
    head = ("id,name,note\ncafé,niño,résumé\n".encode("utf-8")) * 10
    tail = ("more,utf8,rows\njalapeño,olé,piñata\n".encode("utf-8")) * 10
    data = head + b"\x92\x93" + tail
    assert detect_mixed_encoding(data) is True


def test_three_adjacent_bad_bytes_still_flagged_as_mixed():
    # Adversarial: more adjacent failures. Old code returned False
    # after the first retry failed; new code counts each byte.
    head = ("id,name,note\ncafé,niño,résumé\n".encode("utf-8")) * 20
    tail = ("more,utf8,rows\njalapeño,olé,piñata\n".encode("utf-8")) * 20
    data = head + b"\x92\x93\x94" + tail
    assert detect_mixed_encoding(data) is True


def test_pure_ascii_with_stray_byte_is_not_flagged_as_mixed():
    # Review finding: an ASCII-heavy cp1252 file with one stray cp1252
    # byte used to be flagged as mixed. It's really a single-encoding
    # cp1252 file; without multi-byte UTF-8 sequences there's no
    # positive evidence the original was UTF-8.
    head = b"id,name,note\n" + b"1,alice,ok\n" * 100
    tail = b"2,bob,fine\n" * 10
    data = head + b"\x92" + tail
    assert detect_mixed_encoding(data) is False


# ---------- Streaming full-file mixed-encoding scan ----------


def test_scan_file_detects_mixed_encoding_past_sample_window(tmp_path):
    # Review finding: profile_file() used to read only ~256 KB, so a
    # stray non-UTF-8 byte anywhere beyond that window went
    # unnoticed. scan_file_mixed_encoding must catch it regardless of
    # position — but only when there's genuine UTF-8 evidence in the
    # file (multi-byte sequences), not merely ASCII that could be
    # cp1252 just as easily.
    from dsvmonkey.detectors.encoding import scan_file_mixed_encoding

    path = tmp_path / "late.csv"
    head = ("id,name\n" + "1,café\n" * 40000).encode("utf-8")
    assert len(head) > 260_000
    tail = b"2,bob\n" * 10
    path.write_bytes(head + b"\x92" + tail)

    assert scan_file_mixed_encoding(path) is True


def test_scan_file_clean_utf8_is_not_flagged(tmp_path):
    from dsvmonkey.detectors.encoding import scan_file_mixed_encoding

    path = tmp_path / "clean.csv"
    path.write_bytes(("hello,café,naïve\n" * 10000).encode("utf-8"))

    assert scan_file_mixed_encoding(path) is False


def test_scan_file_stable_under_small_chunk_sizes(tmp_path):
    # Review finding: the original streaming scan used a best-effort
    # 3-byte carry that counted partial multi-byte sequences at chunk
    # boundaries as decode failures. On a genuinely mixed file with
    # small chunk_size, those fake failures drove the running ratio
    # over the threshold and triggered early-return False — missing
    # the real mix. The new codecs.IncrementalDecoder-based
    # implementation is stable across any chunk size.
    from dsvmonkey.detectors.encoding import scan_file_mixed_encoding

    path = tmp_path / "mixed.csv"
    # Genuinely mixed: UTF-8 with multi-byte chars (é) + one stray byte.
    head = ("id,name\n" + "1,café\n" * 1000).encode("utf-8")
    path.write_bytes(head + b"\x92" + b"2,bob\n")

    # Small chunk sizes that previously produced boundary artifacts
    # every few bytes. All must now agree with the default.
    for cs in (4, 5, 7, 14, 20, 100, 1_048_576):
        assert scan_file_mixed_encoding(path, chunk_size=cs) is True, (
            f"chunk_size={cs} disagrees with larger chunks"
        )


def test_scan_file_stable_on_clean_utf8_under_small_chunks(tmp_path):
    # Partner to the above: a pure-UTF-8 file with multi-byte sequences
    # must not be misclassified as mixed at any chunk size.
    from dsvmonkey.detectors.encoding import scan_file_mixed_encoding

    path = tmp_path / "clean.csv"
    path.write_bytes(("id,name\n" + "1,café\n" * 2000).encode("utf-8"))

    for cs in (4, 5, 7, 14, 20, 100, 1_048_576):
        assert scan_file_mixed_encoding(path, chunk_size=cs) is False


def test_decode_preserves_legitimate_u_feff_after_utf8_sig_bom():
    # Review finding: _decode() used to strip the first U+FEFF
    # whenever has_bom=True, even when the codec (utf-8-sig) had
    # already consumed the real BOM. A file whose content legitimately
    # begins with U+FEFF (ZWNBSP, rare but valid) would lose that
    # first character silently — and the ZWNBSP is data, not
    # structure, so removing it alters the decoded text.
    from dsvmonkey.orchestrate import _decode

    # Bytes: UTF-8 BOM (EF BB BF) + U+FEFF (EF BB BF) + "rest".
    # After utf-8-sig: the codec consumes the first BOM, leaving
    # "﻿" + "rest" = "﻿rest". The defensive strip must
    # NOT fire because utf-8-sig already did its job.
    raw = b"\xef\xbb\xbf" + "﻿rest".encode("utf-8")
    decoded = _decode(raw, "utf-8-sig", has_bom=True)
    assert decoded == "﻿rest"


def test_decode_still_strips_bom_for_endian_utf16_codecs():
    # Partner to the above: endian-specific UTF-16 codecs do NOT
    # consume their BOM, so the defensive strip MUST still fire for
    # those. Without it the BOM would leak into the first cell
    # (the bug originally fixed for UTF-16 files).
    from dsvmonkey.orchestrate import _decode

    raw = b"\xff\xfe" + "hello".encode("utf-16-le")
    decoded = _decode(raw, "utf-16-le", has_bom=True)
    assert decoded == "hello"
    assert "﻿" not in decoded


def test_profile_file_preserves_legitimate_u_feff_in_first_header():
    # Public-boundary probe: a caller who constructs a file whose
    # real first header cell starts with U+FEFF (admittedly odd but
    # not invalid) should see it preserved — the BOM-handling layer
    # must not eat their first character.
    #
    # This is the canonical BOM scenario: file starts with UTF-8 BOM
    # bytes; after the BOM the first header cell is "﻿weird"
    # (the ZWNBSP kept as content). We expect profile.headers[0]
    # to equal "weird" after cleanmonkey's canonical header
    # normalization (which removes U+FEFF as an invisible — that's
    # separate from the _decode concern). The key negative assertion:
    # the second header "id" must NOT have disappeared or shifted.
    import tempfile
    from pathlib import Path as _Path

    import dsvmonkey

    with tempfile.TemporaryDirectory() as tmp:
        path = _Path(tmp) / "feff.csv"
        # BOM + "﻿weird,id\n1,2\n" encoded as UTF-8.
        path.write_bytes(
            b"\xef\xbb\xbf" + "﻿weird,id\n1,2\n".encode("utf-8")
        )
        profile = dsvmonkey.profile_file(path)
    # "id" is present — i.e. we didn't shift the fields by mis-counting
    # a stripped character.
    assert "id" in profile.headers
    assert len(profile.headers) == 2


def test_scan_file_early_clustered_failures_no_longer_short_circuit(tmp_path):
    # Review finding (#1 High): the scan used to short-circuit to
    # False (not mixed) as soon as the running failure ratio
    # exceeded threshold. Chunk-size dependent: early clustered
    # failures could trip the short-circuit in the first chunk
    # even though later clean bytes would bring the ratio under
    # threshold by EOF. That false-negative defeats the detector's
    # purpose — mixed-encoding is one of the library's core safety
    # signals.
    #
    # Construct a file where the first 4 KiB has a failure ratio
    # above 0.001 (enough to trip the old short-circuit) but the
    # FULL file has a failure ratio well below 0.001 after many
    # MiB of clean UTF-8.
    from dsvmonkey.detectors.encoding import scan_file_mixed_encoding

    path = tmp_path / "early_cluster.csv"
    # 5 bad bytes in the first 4 KiB = 0.00125 ratio locally, above
    # the 0.001 threshold — would short-circuit the old code.
    # Clean-file tail: 5 MiB of "1,café\n" (plenty of UTF-8
    # multi-byte evidence) brings the global ratio well under
    # 0.001.
    head = b"id,name\n" + b"1,alice\n" * 500 + b"\x92\x92\x92\x92\x92"
    tail = ("1,café\n" * 200_000).encode("utf-8")
    path.write_bytes(head + tail)

    # Use a small chunk size so the early cluster lands entirely
    # in the first chunk. Under the old code this short-circuited
    # to False; under the fix it scans to EOF and returns True.
    assert scan_file_mixed_encoding(path, chunk_size=4096) is True


def test_scan_file_with_literal_u_fffd_is_not_counted_as_failure(tmp_path):
    # Review finding: the scanner previously decoded with
    # errors="replace" and counted every U+FFFD in the output as a
    # decode failure. A file with a SMALL number of legitimate
    # U+FFFD characters (under the short-circuit threshold) plus
    # valid UTF-8 multi-byte evidence was falsely flagged as mixed:
    # failure_count > 0, ratio under 0.001, multibyte_found True →
    # old code returned True. The scanner now uses
    # errors="surrogateescape" and counts surrogate code points
    # (which CAN'T appear in real text), leaving genuine U+FFFD
    # untouched, so the same file is correctly reported as clean.
    from dsvmonkey.detectors.encoding import scan_file_mixed_encoding

    path = tmp_path / "fffd.csv"
    # 2000 clean UTF-8 lines (café → real multi-byte evidence) plus
    # 2 lines containing a legitimate U+FFFD character. Total file
    # well over 20000 bytes; two legit U+FFFD produces an old
    # failure ratio of ~0.0001 — below 0.001, so the short-circuit
    # never fires and the false "mixed" verdict lands.
    clean = ("id,note\n" + "1,café\n" * 2000).encode("utf-8")
    tail = "2,marker �\n3,marker �\n".encode("utf-8")
    path.write_bytes(clean + tail)

    assert scan_file_mixed_encoding(path) is False


def test_scan_file_still_flags_real_stray_byte_alongside_u_fffd(tmp_path):
    # Partner to the above: if the file contains BOTH a real stray
    # non-UTF-8 byte AND legitimate U+FFFD content, the stray byte
    # must still be counted. Surrogate-escape isolates decode failures
    # from content, so the legit U+FFFD doesn't mask the real failure.
    from dsvmonkey.detectors.encoding import scan_file_mixed_encoding

    path = tmp_path / "both.csv"
    clean_utf8 = ("id,note\n" + "1,café �\n" * 2000).encode("utf-8")
    path.write_bytes(clean_utf8 + b"\x92" + b"2,bob\n")

    assert scan_file_mixed_encoding(path) is True


def test_scan_file_pure_cp1252_is_not_flagged(tmp_path):
    # Whole file is non-UTF-8 — that's "not UTF-8", not "mixed".
    from dsvmonkey.detectors.encoding import scan_file_mixed_encoding

    path = tmp_path / "cp1252.csv"
    path.write_bytes(("don\x92t,worry\n" * 1000).encode("latin-1"))

    assert scan_file_mixed_encoding(path) is False


def test_profile_file_flags_late_file_mixed_encoding(tmp_path):
    # End-to-end: profile_file must surface the issue when the stray
    # byte sits beyond its bounded-read window AND the file has
    # positive UTF-8 evidence (multi-byte sequences).
    import dsvmonkey

    path = tmp_path / "late.csv"
    head = ("id,name\n" + "1,café\n" * 40000).encode("utf-8")
    assert len(head) > 260_000
    path.write_bytes(head + b"\x92" + b"2,bob\n" * 10)

    profile = dsvmonkey.profile_file(path)
    assert profile.mixed_encoding_suspected is True
    assert any("mixed encoding" in issue for issue in profile.issues)


# ---------- Gap 2: stray byte near the END of the sample ----------


def test_stray_byte_near_end_of_sample_is_flagged_as_mixed():
    # Gap 2: mirror of the "isolated stray byte" case. The stray byte
    # sits near the very end of the buffer, not at position 0. Pins
    # that detect_mixed_encoding scans the whole window — not just
    # the head — so late-buffer corruption is still caught when the
    # surrounding data has genuine UTF-8 multi-byte evidence.
    head = "id,name,note\ncafé,niño,résumé\n".encode("utf-8") * 50
    tail = b"ab\n"  # tiny clean tail after the stray byte
    data = head + b"\x92" + tail
    # Sanity: the stray byte is in the last few bytes of the buffer.
    assert data.rindex(b"\x92") > len(data) - 10
    assert detect_mixed_encoding(data) is True


# ---------- Gap 8: detect_encoding fallback / low-confidence path ----------


def test_detect_encoding_random_binary_noise_does_not_crash():
    # Gap 8: feed random binary noise. Contract: we get a well-formed
    # DetectionResult (no crash), confidence in [0, 1], and method
    # is one of the known tags.
    data = bytes(os.urandom(4096))
    result = detect_encoding(data)
    assert 0.0 <= result.confidence <= 1.0
    assert result.method in {"content-scored", "fallback", "bom", "null-byte-parity"}
    assert isinstance(result.value, str)


def test_random_binary_gets_low_confidence_not_confident_mislabel():
    # Contract: before the textlike-ratio fix, cp437 decoded random
    # bytes cleanly (every byte maps to a printable glyph) and won
    # confidence ~0.88 — a confident "this is cp437" for what is
    # obviously not text. With the textlike ratio signal, random
    # binary decodes to mostly box-drawing / Greek / math symbols
    # which the signal recognises as non-text, dropping confidence
    # below the 0.6 warning threshold. This catches the
    # "confidently-wrong" regression.
    #
    # Seeded deterministically so the test doesn't rely on a single
    # hypothesis of what os.urandom produced.
    import random
    rng = random.Random(0xDEADBEEF)
    data = bytes(rng.randrange(256) for _ in range(4096))

    result = detect_encoding(data)
    # We don't require any specific encoding name — the point is
    # that we don't claim strong confidence in whichever one we pick.
    assert result.confidence < 0.6, (
        f"random binary scored {result.confidence:.2f} "
        f"({result.value!r}) — expected below 0.6 so a warning fires"
    )
    assert result.warnings, (
        "low-confidence content-scored result should attach a "
        "diagnostic warning for the user"
    )


def test_text_like_content_still_scores_confidently():
    # Guard against over-penalising real text. A plain English DSV
    # sample must still score above the 0.6 warning threshold.
    data = b"id,name,email,city\n" + b"1,alice,alice@example.com,london\n" * 100
    result = detect_encoding(data)
    assert result.confidence > 0.8
    assert result.value == "utf-8"


def test_french_text_still_scores_confidently():
    # Non-English text: accented letters are still alnum, so the
    # textlike-ratio signal does not punish legitimate locales.
    data = ("id,nom,ville\n" + "1,café,paris\n" * 100).encode("utf-8")
    result = detect_encoding(data)
    assert result.confidence > 0.8
    assert result.value == "utf-8"


def test_cjk_utf8_scored_as_confident_utf8():
    # Regression: a previous pass added an ASCII-ratio penalty that
    # scaled CJK / Japanese / Chinese content's UTF-8 score toward
    # zero because those scripts have near-zero ASCII ratio —
    # legitimate non-Latin files could lose to latin-1 fallback.
    # The penalty is now based on control-character density (which
    # is language-agnostic), so CJK UTF-8 decodes correctly.
    text = "id,名前,都市\n1,田中,東京\n2,佐藤,大阪\n"
    data = (text * 20).encode("utf-8")
    result = detect_encoding(data)
    assert result.value == "utf-8"
    assert result.confidence > 0.8


def test_chinese_utf8_scored_as_confident_utf8():
    text = "id,姓名,城市\n1,张伟,北京\n2,王芳,上海\n"
    data = (text * 20).encode("utf-8")
    result = detect_encoding(data)
    assert result.value == "utf-8"
    assert result.confidence > 0.8


def test_emoji_sprinkled_text_still_scores_confidently():
    # Emoji are Unicode category So (Symbol Other) — under a naive
    # category-based check they'd look like noise. Real emoji-
    # containing CSVs have sparse emoji amid mostly-text, so the
    # control-char signal (which emoji don't trigger) correctly
    # accepts them as legitimate content.
    text = "id,status\n1,active \U0001f44b\n2,complete \U0001f30d\n3,waiting \U0001f389\n"
    data = (text * 30).encode("utf-8")
    result = detect_encoding(data)
    assert result.value == "utf-8"
    assert result.confidence > 0.8


# ---------- Gap 9: _score_decoded empty-string / single-char guards ----------


def test_score_decoded_empty_string_returns_zero():
    # Gap 9: the docstring implies text is expected, but the code
    # early-returns (0.0, "empty sample") for the empty case. Pin
    # both the score and that it does not raise on division-by-zero.
    from dsvmonkey.detectors.encoding import _score_decoded

    score, reason = _score_decoded("", "utf-8")
    assert score == 0.0
    assert "empty" in reason.lower()


def test_score_decoded_single_char_does_not_crash():
    # Gap 9 adversarial: one character means length == 1; several
    # divisions are guarded by max(length / 100, 1) but a naive
    # implementation could still divide by zero somewhere. Pin that
    # it returns a sane score and doesn't raise.
    from dsvmonkey.detectors.encoding import _score_decoded

    score, reason = _score_decoded("a", "utf-8")
    assert 0.0 <= score <= 1.0
    assert isinstance(reason, str)


# ---------- Gap 23: scan_file_mixed_encoding threshold boundary ----------


def test_scan_file_just_below_failure_ratio_is_flagged_mixed(tmp_path):
    # Gap 23 (just-below): default max_failure_ratio is 0.001. With
    # exactly 1 failure in 1000 bytes, ratio == 0.001, which is
    # `<=` the threshold and must classify as mixed. Positive
    # UTF-8 evidence (é = 0xc3 0xa9) is included so the multibyte
    # gate is satisfied.
    from dsvmonkey.detectors.encoding import scan_file_mixed_encoding

    path = tmp_path / "just_below.csv"
    # 994 ASCII + 5-byte UTF-8 "café" + 1 stray byte = 1000 bytes.
    clean = b"a" * 994 + "café".encode("utf-8")
    assert len(clean) == 999
    path.write_bytes(clean + b"\x92")
    assert path.stat().st_size == 1000

    assert scan_file_mixed_encoding(path) is True


def test_scan_file_just_above_failure_ratio_is_not_flagged_mixed(tmp_path):
    # Gap 23 (just-above): 1 failure in 999 bytes gives ratio
    # ~0.001001, strictly greater than 0.001, so the file is
    # classified "not mixed" (really: the failure density is too
    # high to be isolated concatenation corruption).
    from dsvmonkey.detectors.encoding import scan_file_mixed_encoding

    path = tmp_path / "just_above.csv"
    # 993 ASCII + 5-byte UTF-8 "café" + 1 stray byte = 999 bytes.
    clean = b"a" * 993 + "café".encode("utf-8")
    assert len(clean) == 998
    path.write_bytes(clean + b"\x92")
    assert path.stat().st_size == 999

    assert scan_file_mixed_encoding(path) is False
