import statistics

import pytest

from dsvmonkey.detectors.delimiter import _score_counts, detect_delimiter


# ---------- Happy path: each common delimiter ----------


@pytest.mark.parametrize(
    "delim, sample",
    [
        (",", "id,name,age\n1,alice,30\n2,bob,25\n3,carol,40\n"),
        ("\t", "id\tname\tage\n1\talice\t30\n2\tbob\t25\n3\tcarol\t40\n"),
        (";", "id;name;age\n1;alice;30\n2;bob;25\n3;carol;40\n"),
        ("|", "id|name|age\n1|alice|30\n2|bob|25\n3|carol|40\n"),
    ],
)
def test_detects_each_common_delimiter(delim, sample):
    result = detect_delimiter(sample)
    assert result.value == delim
    assert result.method == "field-count-consistency"
    assert result.confidence > 0.8


# ---------- Ambiguity handling ----------


def test_semicolon_wins_over_comma_when_commas_are_inside_fields():
    # European export style: semicolon delimiter, comma decimal separator.
    sample = (
        "id;amount;note\n"
        "1;1,50;ok\n"
        "2;2,75;also, ok\n"
        "3;3,00;fine\n"
        "4;4,25;totally, fine\n"
    )
    result = detect_delimiter(sample)
    assert result.value == ";"
    # Comma should still appear as an alternative, with a lower score.
    comma_alts = [a for a in result.alternatives if a.value == ","]
    assert comma_alts
    assert comma_alts[0].confidence < result.confidence


def test_pipe_wins_when_other_chars_appear_inside_fields():
    sample = (
        "id|description|tags\n"
        "1|hello, world|a;b;c\n"
        "2|foo, bar|x;y\n"
        "3|baz, qux|p;q;r\n"
    )
    result = detect_delimiter(sample)
    assert result.value == "|"


# ---------- Quoted fields with embedded delimiters ----------


def test_quoted_field_with_embedded_delimiter_does_not_fool_detector():
    # The quoted `"Smith, John"` contains a comma but csv.reader counts
    # it as a single field, so consistency stays high.
    sample = (
        'id,name,note\n'
        '1,"Smith, John",admin\n'
        '2,"Doe, Jane",user\n'
        '3,"Roe, Richard",user\n'
    )
    result = detect_delimiter(sample)
    assert result.value == ","
    assert result.confidence > 0.8


def test_quoted_newline_does_not_break_counts():
    # The `"\n` inside quotes must not create an extra logical row.
    sample = (
        'id,text\n'
        '1,"line one\nline two"\n'
        '2,"single line"\n'
        '3,"another\nmultiline"\n'
    )
    result = detect_delimiter(sample)
    assert result.value == ","


# ---------- Degenerate inputs ----------


def test_single_column_content_classified_as_single_column():
    # Contract update: a file where no candidate produces
    # multi-field rows is now surfaced as method="single-column"
    # rather than a phantom comma fallback — downstream parsing
    # then uses the U+001F sentinel so any incidental commas in
    # cell content don't split fields.
    sample = "just\nsingle\ncolumn\nlines\n"
    result = detect_delimiter(sample)
    assert result.method == "single-column"
    assert result.value == "\x1f"


def test_empty_sample_falls_back_to_single_column():
    # An empty sample has nothing to score against — same
    # classification as a single-column file.
    result = detect_delimiter("")
    assert result.method == "single-column"
    assert result.value == "\x1f"


def test_delimiter_scoring_tries_both_quote_chars():
    # Self-review finding: delimiter scoring hardcoded quotechar='"'
    # so single-quote-quoted files with embedded delimiters got
    # misparsed during delimiter scoring (before quote detection
    # ran). The detector now tries both quote chars and uses the more
    # consistent interpretation per delimiter.
    sample = (
        "id;note\n"
        "1;'embedded; semicolon here'\n"
        "2;'another; one with; three'\n"
        "3;'a; b'\n"
        "4;'x; y; z; w'\n"
    )
    result = detect_delimiter(sample)
    assert result.value == ";"
    # With single-quote parsing, every data row has 2 fields,
    # matching the 2-field header — perfect consistency.
    assert result.confidence > 0.9


def test_delimiter_detects_through_long_preamble():
    # Self-review finding: _DEFAULT_MAX_ROWS=30 was narrower than
    # _MAX_SAMPLE_ROWS=100, so preambles over 30 rows left the
    # delimiter detector with only preamble rows to score. Now
    # aligned at 100.
    preamble = "META: info\n" * 40  # >30 rows of non-CSV preamble
    body = "id,name,age\n1,alice,30\n2,bob,25\n3,carol,40\n"
    sample = preamble + body
    result = detect_delimiter(sample)
    assert result.value == ","


def test_ragged_rows_still_pick_winning_delimiter_but_with_lower_confidence():
    # Most rows have 3 fields, one has 4. Consistent enough to pick `,`
    # but confidence reflects the ragged row.
    sample = (
        "id,name,age\n"
        "1,alice,30\n"
        "2,bob,25,extra\n"
        "3,carol,40\n"
    )
    result = detect_delimiter(sample)
    assert result.value == ","
    assert result.confidence < 1.0


# Gap 10: no-multi-field-rows branch. Previously a fallback comma;
# now correctly surfaced as "single-column" so downstream consumers
# parse with the U+001F sentinel and every row stays one field.
def test_long_preamble_with_consistent_csv_block_classified_as_csv():
    # Review finding (#1 High, regression): an earlier fix added
    # a "<5% of rows have delim" gate to catch 1-2 incidental
    # commas in free text. That gate over-fired on a long
    # preamble + small consistent CSV block: 80 META lines + 4
    # consistent CSV rows = 4/84 ≈ 5%, classified as
    # single-column even though the 4 rows are clearly a real
    # data block. Refined heuristic: ≥ 3 consistent delim-bearing
    # rows = real CSV regardless of how sparse they are in the
    # sample.
    preamble = "META: line\n" * 80
    body = "id,name,age\n1,alice,30\n2,bob,25\n3,carol,40\n"
    result = detect_delimiter(preamble + body)
    assert result.value == ","
    assert result.method == "field-count-consistency"


def test_few_consistent_delim_rows_still_classified_as_single_column():
    # Negative case: 2 delim-bearing rows that happen to agree on
    # field count are NOT enough to declare a CSV block. Two
    # rows of subject-comma-body in 50 lines of notes is
    # incidental, not a structured 2-column data section.
    sample = (
        "Notes from the team meeting follow.\n"
        + "Single-line entry without a delim.\n" * 47
        + "Subject, body of a note\n"
        + "Header, content of another\n"
    )
    result = detect_delimiter(sample)
    assert result.method == "single-column"


def test_three_consistent_delim_rows_promoted_to_csv():
    # Boundary: 3 is the minimum threshold for "real CSV block."
    sample = (
        "header content\n" * 30
        + "id,name,age\n1,alice,30\n2,bob,25\n"
    )
    result = detect_delimiter(sample)
    assert result.value == ","
    assert result.method == "field-count-consistency"


def test_single_column_sentinel_falls_back_when_default_collides_with_sample():
    # Review finding (#3): the default \x1f sentinel can collide
    # with messy exports containing control characters. The
    # detector now picks from {\x1f, \x1e, \x1d, \x1c} and uses
    # the first one absent from the sample, avoiding the
    # collision-induced row split.
    sample = "this\x1fhas the default sentinel\nlines\nmore lines\n"
    result = detect_delimiter(sample)
    # Should NOT be \x1f (it's in the sample). Falls back to \x1e.
    assert result.value != "\x1f"
    assert result.value in ("\x1e", "\x1d", "\x1c")
    assert result.method == "single-column"
    # And the chosen sentinel actually doesn't appear in the
    # sample, so downstream parsing yields one cell per row.
    assert result.value not in sample


def test_single_column_sentinel_warns_when_all_candidates_collide():
    # Adversarial: sample contains every default candidate. The
    # detector falls back to the primary sentinel anyway (to keep
    # the API value predictable for callers checking `value`)
    # but appends a warning that downstream parsing may split
    # rows unexpectedly.
    sample = "id\x1fcontent\x1ealso\x1dincludes\x1cevery\nsentinel\n"
    result = detect_delimiter(sample)
    assert result.method == "single-column"
    assert any(
        "sentinel" in w.lower() and "appear" in w.lower()
        for w in result.warnings
    )


def test_no_delimiter_anywhere_classified_as_single_column():
    sample = "apple\nbanana\ncherry\n"
    result = detect_delimiter(sample)
    assert result.value == "\x1f"
    assert result.method == "single-column"
    assert any(
        "single column" in w.lower() for w in result.warnings
    )


def test_no_candidate_branch_emits_low_confidence_not_full(tmp_path):
    # Review finding (#2 Medium-High): the "no candidate matched"
    # branch used to return confidence=1.0, overclaiming when the
    # actual diagnosis is "we don't know" (could be genuine
    # single-column OR a custom delimiter outside our default set).
    # Low confidence + diagnostic warning now surfaces the
    # uncertainty so callers can inspect `profile.delimiter.
    # warnings` and override `profile.delimiter.value` when the
    # file actually uses, say, `:` or `#` as the separator.
    sample = "apple\nbanana\ncherry\n"
    result = detect_delimiter(sample)
    assert result.confidence < 0.6  # below the warning threshold
    assert any(
        "custom delimiter" in w.lower() for w in result.warnings
    )


def test_file_with_custom_delimiter_surfaces_uncertainty():
    # End-to-end: a file that's actually colon-delimited would
    # previously collapse to single-column with confidence 1.0 —
    # silently wrong. It still classifies as single-column (we
    # can't auto-detect `:`) but the low confidence + warning
    # direct the user to override.
    sample = "id:name:city\n1:alice:london\n2:bob:paris\n"
    result = detect_delimiter(sample)
    # Auto-detection can't handle `:`; lands in single-column with
    # low confidence.
    assert result.method == "single-column"
    assert result.confidence < 0.6
    # Warning mentions the custom-delimiter possibility so a
    # reader of the inspect report knows what to do.
    assert any(
        "custom delimiter" in w.lower() for w in result.warnings
    )


# Gap 11: _score_counts boundary / adversarial cases.
def test_score_counts_high_cv_gives_low_score():
    # Highly variable counts: cv is large, consistency clamps to 0,
    # so only the small field_factor bonus contributes.
    counts = [1, 10, 1, 10]
    score, reason = _score_counts(counts)
    mean = statistics.mean(counts)
    stdev = statistics.stdev(counts)
    cv = stdev / mean
    expected_consistency = max(0.0, 1.0 - cv)
    expected_field_factor = min(mean / 3.0, 1.0)
    expected = max(
        0.0,
        min(1.0, expected_consistency * 0.85 + expected_field_factor * 0.15),
    )
    assert score == pytest.approx(expected)
    # Sanity: such wild variation must not be treated as consistent.
    assert score < 0.3
    assert "cv=" in reason


def test_score_counts_zero_cv_gives_high_score():
    # Perfectly consistent counts: stdev=0, cv=0, consistency=1.
    counts = [5, 5, 5, 5]
    score, reason = _score_counts(counts)
    # mean=5 -> field_factor=min(5/3, 1.0)=1.0 -> score = 0.85 + 0.15 = 1.0
    assert score == pytest.approx(1.0)
    assert "stdev=0.00" in reason


def test_score_counts_single_count_does_not_crash():
    # statistics.stdev would raise on a single sample; source guards
    # with `if len(counts) > 1 else 0.0`. Score should be a sensible
    # value and not raise.
    score, reason = _score_counts([5])
    # len==1 branch: stdev=0.0, mean=5, cv=0, consistency=1,
    # field_factor = min(5/3, 1.0) = 1.0 -> score clamps to 1.0.
    assert score == pytest.approx(1.0)
    assert "rows=1" in reason


# ---------- Single-column detection ----------
#
# Review finding: a one-column notes / comments export where rows
# naturally contain commas used to have `,` picked as the delimiter
# with low confidence. That cascaded into wrong header selection
# and ragged rows. The detector now catches the case explicitly.


def test_single_column_notes_with_incidental_commas():
    # Majority of rows have no delimiter; the minority that do have
    # varied field counts (free prose, no fixed structure). Must be
    # classified as single-column.
    sample = (
        "notes\n"
        "Everything is fine today.\n"
        "I saw the report, it was fine.\n"
        "Everything OK.\n"
        "Issues found: A, B, and C.\n"
        "No problems.\n"
        "Multiple commas, here, there, everywhere.\n"
        "Short.\n"
        "Another clean line.\n"
        "Yet more, prose.\n"
        "Final line no delimiter.\n"
    )
    result = detect_delimiter(sample)
    assert result.method == "single-column"
    # Single-column sentinel: csv.reader accepts any single char,
    # and U+001F can't appear in real text.
    assert result.value == "\x1f"
    assert any(
        "single column" in (w or "").lower() for w in result.warnings
    )


def test_pure_single_column_with_no_delimiters_at_all():
    # Boundary: no delimiter candidate even qualifies (every row
    # has 1 field under every candidate). Must still reach a
    # single-column verdict rather than falling through to the
    # `method="fallback"` "no candidate" path — the latter is for
    # "I don't know", the former is for "I know: single column".
    sample = "id\nalice\nbob\ncarol\ndave\n"
    result = detect_delimiter(sample)
    # Either "single-column" or "fallback" is defensible; pin
    # whichever behaviour we land on so it doesn't drift silently.
    # Current: no candidate scores (max<2 gate), so method="fallback"
    # with confidence 0.0 — a legitimate "I have no signal" verdict
    # for a 1-column file where no delimiter character occurs.
    assert result.method in {"single-column", "fallback"}
    # Whatever the verdict, parsing with the returned delimiter
    # must yield 1-field rows (i.e. downstream consumers see the
    # file as single-column either way).
    import csv
    import io
    parsed = list(csv.reader(io.StringIO(sample), delimiter=result.value))
    assert all(len(r) == 1 for r in parsed)


def test_preamble_plus_real_csv_still_classified_as_csv():
    # Adversarial: a long preamble gives "majority of rows have no
    # delimiter", but the data rows below are field-count-consistent.
    # This is a real CSV with a preamble, NOT single-column. The
    # heuristic must distinguish.
    preamble = "META_HEADER_LINE\n" * 40
    body = "id,name,age\n1,alice,30\n2,bob,25\n3,carol,40\n"
    result = detect_delimiter(preamble + body)
    assert result.value == ","
    assert result.method == "field-count-consistency"


def test_two_column_file_where_every_row_has_the_delimiter():
    # Boundary on the other side: every row has the delimiter (no
    # no-delim rows). Must be classified as 2-column CSV, never as
    # single-column — the single-column rule requires majority
    # no-delim.
    sample = "subject,body\nhello,world\nfoo,bar\nbaz,qux\n"
    result = detect_delimiter(sample)
    assert result.value == ","
    assert result.method == "field-count-consistency"


def test_one_accidental_delim_in_free_text_classified_as_single_column():
    # Review finding: a single-column notes file with ONE accidental
    # comma previously produced has_delim = [N] (size-1 set — "not
    # varied") and fell through to "field-count-consistency", letting
    # the header detector pick the multi-cell row as a header and
    # cascading into schema corruption. The refined heuristic now
    # treats `len(has_delim) <= 1` as evidence of incidental
    # delimiting, independent of the variance check.
    sample = (
        "notes\n"
        "All quiet today.\n"
        "Nothing unusual happened.\n"
        "One anomaly observed, investigated.\n"  # the only comma
        "System nominal.\n"
        "No errors.\n"
        "Smooth operation.\n"
        "End of log.\n"
    )
    result = detect_delimiter(sample)
    assert result.method == "single-column"


def test_two_accidental_delims_in_free_text_classified_as_single_column():
    # Boundary: 2 delim-bearing rows in 20 rows = 10%, above the
    # len<=1 gate but below the 5% sparse-rows gate? No — 2/20 =
    # 10% > 5%, so this falls through to the variance check.
    # has_delim=[2,2] → set size 1 → NOT varied → NOT classified
    # as single-column. Pin this specifically so a future
    # threshold tweak has to land an explicit contract update.
    sample = (
        "notes\n"
        + "Normal line.\n" * 17
        + "One comma, here.\n"
        + "Another, one.\n"
    )
    result = detect_delimiter(sample)
    # Conservative: when 2+ rows have the delimiter AND they're
    # consistent, we CAN'T confidently say "free text" without
    # content understanding.
    assert result.method in {"single-column", "field-count-consistency"}
    # The important contract is downstream safety: whichever branch
    # wins, parsing must not lose text from the consistent rows.
    import csv
    import io
    parsed = list(csv.reader(io.StringIO(sample), delimiter=result.value))
    # Every parsed cell's concatenation should contain the original
    # line content (no silently-dropped bytes).
    for cells, original in zip(parsed, sample.splitlines()):
        reconstructed = result.value.join(cells) if len(cells) > 1 else cells[0]
        assert reconstructed in original or original.startswith(reconstructed)


def test_few_delims_in_large_file_classified_as_single_column():
    # The `len(has_delim) / len(counts) < 0.05` gate. 2 delim-bearing
    # rows in 50 rows = 4% — below the 5% threshold → single-column.
    sample = (
        "notes\n"
        + "Line without any delim.\n" * 47
        + "A comma, in this one.\n"
        + "Another, rare one.\n"
    )
    result = detect_delimiter(sample)
    assert result.method == "single-column"


def test_single_column_roundtrip_through_read_and_repair(tmp_path):
    # End-to-end: a single-column notes file must round-trip cleanly
    # through read() (every row as a single field) and repair()
    # (output preserves the single-column shape, no spurious splitting
    # on commas in prose).
    import dsvmonkey
    from pathlib import Path as _Path

    src = _Path(tmp_path) / "notes.csv"
    dst = _Path(tmp_path) / "out.csv"
    src.write_bytes(
        (
            "notes\n"
            "Today the system, as it were, was fine.\n"
            "No errors.\n"
            "Several issues, specifically: A, B, C.\n"
            "Normal day.\n"
            "A, B, C happened too.\n"
            "Clean run.\n"
            "End of log.\n"
        ).encode("utf-8")
    )

    rows = list(dsvmonkey.read(src, as_dict=False, clean=False))
    # Every data row arrives as exactly one cell — the commas in
    # prose stayed inside the cell instead of splitting it.
    assert all(len(r) == 1 for r in rows)
    # The comma-heavy row is one cell, not three.
    assert any("specifically: A, B, C" in r[0] for r in rows)

    dsvmonkey.repair(src, dst, clean_cells=False)
    # Output preserves single-column shape: no added quoting, no
    # lost text between commas.
    out_lines = dst.read_text().splitlines()
    assert any("Several issues, specifically: A, B, C." in ln for ln in out_lines)


def test_score_counts_empty_counts_returns_zero_without_crashing():
    # Adversarial empty input. Contract: "no crash, sensible score."
    # The helper now guards against `statistics.mean([])` and returns
    # a zero-score sentinel so direct callers don't trip on a
    # StatisticsError. Public-path callers still filter upstream; this
    # test pins the helper's independent defence.
    score, reason = _score_counts([])
    assert score == 0.0
    assert "rows=0" in reason


def test_long_preamble_respected_when_max_rows_is_generous():
    # Review finding (Medium): the parsed-row cap was 100. A real
    # CSV with a 250-line metadata preamble exhausted the budget on
    # preamble lines (all field count == 1) before any data row
    # reached the scorer, leading to a "single-column" misclassification.
    # Pin both directions of the contract: with max_rows=100 the
    # bug surface is still reproducible (regression marker for
    # anyone tempted to lower the constant); with max_rows=1000
    # (the new default) detection sees the data block and recovers.
    text = (
        "# meta line with no delimiter at all\n" * 250
        + "id,name,age\n1,alice,30\n2,bob,25\n3,carol,40\n"
    )
    starved = detect_delimiter(text, max_rows=100)
    assert starved.method == "single-column", (
        "with the old cap, preamble starves the scorer and we should "
        "still be able to demonstrate the misclassification — if this "
        "ever passes with method='field-count-consistency', the lower-"
        "bound bug is no longer reproducible and the default cap could "
        "be tuned down again"
    )

    recovered = detect_delimiter(text, max_rows=1000)
    assert recovered.method == "field-count-consistency"
    assert recovered.value == ","
