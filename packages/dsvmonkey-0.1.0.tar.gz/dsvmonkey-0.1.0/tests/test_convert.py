import json
from pathlib import Path

import pytest

from dsvmonkey.convert import to_jsonl


def _read_jsonl(path: Path) -> list[dict]:
    with path.open(encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def test_csv_to_jsonl_with_headers(tmp_path: Path):
    src = tmp_path / "in.csv"
    dst = tmp_path / "out.jsonl"
    src.write_bytes(b"id,name,age\n1,alice,30\n2,bob,25\n3,carol,40\n")

    count = to_jsonl(src, dst)

    assert count == 3
    rows = _read_jsonl(dst)
    assert rows == [
        {"id": "1", "name": "alice", "age": "30"},
        {"id": "2", "name": "bob", "age": "25"},
        {"id": "3", "name": "carol", "age": "40"},
    ]


def test_jsonl_preserves_non_ascii(tmp_path: Path):
    src = tmp_path / "in.csv"
    dst = tmp_path / "out.jsonl"
    src.write_bytes("id,name\n1,café\n2,naïve\n".encode("utf-8"))

    to_jsonl(src, dst)

    # ensure_ascii=False: non-ASCII stays readable in the output.
    text = dst.read_text()
    assert "café" in text
    assert "naïve" in text


def test_jsonl_strips_bom_from_keys(tmp_path: Path):
    src = tmp_path / "in.csv"
    dst = tmp_path / "out.jsonl"
    src.write_bytes("﻿id,name\n1,alice\n".encode("utf-8"))

    to_jsonl(src, dst)

    rows = _read_jsonl(dst)
    assert "id" in rows[0]
    assert "﻿id" not in rows[0]


def test_jsonl_one_row_per_line(tmp_path: Path):
    src = tmp_path / "in.csv"
    dst = tmp_path / "out.jsonl"
    src.write_bytes(b"id,name\n1,alice\n2,bob\n")

    to_jsonl(src, dst)

    text = dst.read_text()
    # Exactly one trailing newline per row, no embedded blank lines.
    assert text.count("\n") == 2
    for line in text.splitlines():
        json.loads(line)  # each line parses as JSON on its own


def test_to_jsonl_sanitize_formulas_neutralizes_payloads(tmp_path: Path):
    # Review finding (#7): JSON consumers don't evaluate formulas,
    # but JSONL is commonly transformed back to CSV/Excel later
    # — at which point a `=SUM(A:A)*cmd|...` payload that survived
    # as a JSON string value becomes a live formula. The API now
    # accepts `sanitize_formulas` so callers can opt in to
    # neutralisation at the JSONL boundary.
    #
    # Includes an `id` numeric column so header detection's
    # low-contrast guard fires and `name,formula` is recognised
    # as a header.
    src = tmp_path / "evil.csv"
    dst = tmp_path / "out.jsonl"
    src.write_bytes(
        b"id,name,formula\n"
        b"1,alice,=SUM(A:A)\n"
        b"2,bob,benign\n"
    )

    n = to_jsonl(src, dst, sanitize_formulas=True, clean_cells=False)
    assert n == 2
    rows = _read_jsonl(dst)
    assert rows[0]["formula"] == "'=SUM(A:A)"  # neutralised
    assert rows[1]["formula"] == "benign"      # untouched


def test_to_jsonl_sanitize_formulas_neutralizes_header_keys_too(
    tmp_path: Path,
):
    # Review finding (#2): repair() neutralises formula triggers
    # in header CELLS, but to_jsonl()'s sanitize_formulas
    # previously only walked dict VALUES — keys (the headers)
    # passed through unchanged. A downstream consumer that
    # materialises keys back into a spreadsheet (CSV export,
    # tabular renderer using key as column header) would see a
    # live formula in the header row even though the caller
    # asked for sanitisation. Cross-API parity with repair()
    # requires both keys and values to be neutralised.
    src = tmp_path / "evil_header.csv"
    dst = tmp_path / "out.jsonl"
    src.write_bytes(
        b"id,=evil_header\n"
        b"1,benign value\n"
        b"2,another benign value\n"
    )

    n = to_jsonl(src, dst, sanitize_formulas=True, clean_cells=False)
    assert n == 2
    rows = _read_jsonl(dst)
    # Header KEYS are sanitised in the dict.
    assert "'=evil_header" in rows[0]
    assert "=evil_header" not in rows[0]


def test_to_jsonl_sanitize_formulas_raises_on_post_neutralisation_key_collision(
    tmp_path: Path,
):
    # Review finding (#1): when caller passes overlapping headers
    # like ["'=id", "=id"] AND sanitize_formulas=True, both
    # normalise to "'=id" — the dict comprehension silently
    # overwrites one. Silent data loss in the explicit-security
    # mode is the wrong default. Now raises ValueError naming
    # the collision so the caller fixes the input rather than
    # losing a column.
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.jsonl"
    src.write_bytes(b"a,b\n1,2\n")

    with pytest.raises(ValueError, match="key collision"):
        to_jsonl(
            src,
            dst,
            headers=["'=id", "=id"],
            sanitize_formulas=True,
            clean_cells=False,
        )


def test_to_jsonl_sanitize_formulas_off_by_default(tmp_path: Path):
    # Strict-JSON consumers (jq, structured loggers) want
    # byte-for-byte cell values. Default off preserves content.
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.jsonl"
    src.write_bytes(
        b"id,name,formula\n"
        b"1,alice,=SUM(A:A)\n"
    )
    to_jsonl(src, dst, clean_cells=False)
    rows = _read_jsonl(dst)
    assert rows[0]["formula"] == "=SUM(A:A)"


def test_to_jsonl_skip_empty_rows_false_preserves_blanks(tmp_path: Path):
    # Review finding (High): `to_jsonl()` had no `skip_empty_rows`
    # parameter, so `dsvmonkey convert --to jsonl --keep-empty-rows`
    # silently dropped blank rows despite the flag. JSONL conversion
    # now accepts the same opt-out as read() / repair(), and the
    # CLI threads `--keep-empty-rows` through for jsonl output.
    src = tmp_path / "ws.csv"
    dst = tmp_path / "out.jsonl"
    src.write_bytes(b"id,name\n1,alice\n   ,   \n2,bob\n\t,\t\n3,carol\n")

    n = to_jsonl(src, dst, skip_empty_rows=False)

    # 5 rows preserved: 3 real + 2 blank.
    assert n == 5
    rows = _read_jsonl(dst)
    assert len(rows) == 5


def test_to_jsonl_skip_empty_rows_default_drops_blanks(tmp_path: Path):
    # Negative case: default behaviour (drop blanks) is unchanged.
    src = tmp_path / "ws.csv"
    dst = tmp_path / "out.jsonl"
    src.write_bytes(b"id,name\n1,alice\n   ,   \n2,bob\n")
    n = to_jsonl(src, dst)
    assert n == 2


def test_to_jsonl_rejects_same_input_output_path(tmp_path: Path):
    # Review finding: truncating the input inode while streaming
    # from it is a corruption hazard. Fail fast before the source
    # is touched.
    src = tmp_path / "same.csv"
    src.write_bytes(b"id,name\n1,alice\n")
    original = src.read_bytes()

    with pytest.raises(ValueError, match="same file|same path"):
        to_jsonl(src, src)

    # Source must be untouched.
    assert src.read_bytes() == original


def test_jsonl_for_no_header_file_uses_col_names(tmp_path: Path):
    src = tmp_path / "in.csv"
    dst = tmp_path / "out.jsonl"
    src.write_bytes(b"1,100,50\n2,200,75\n3,300,25\n4,400,90\n5,500,10\n")

    to_jsonl(src, dst)

    rows = _read_jsonl(dst)
    assert rows[0] == {"col_0": "1", "col_1": "100", "col_2": "50"}


def test_to_jsonl_on_overflow_raise_aborts_and_writes_no_file(
    tmp_path: Path,
):
    # JSONL is a dict-mode output, so it inherits read()'s
    # overflow contract. on_overflow="raise" must abort on the
    # first wider-than-headers row and leave no partial file at
    # output_path (the atomic-writer cleanup discards the temp).
    src = tmp_path / "ragged.csv"
    dst = tmp_path / "out.jsonl"
    src.write_bytes(
        b"id,name,age\n"
        b"1,alice,30\n"
        b"2,bob,25,extra\n"
        b"3,carol,40\n"
    )

    from dsvmonkey import DictOverflowError
    with pytest.raises(DictOverflowError) as excinfo:
        to_jsonl(src, dst, on_overflow="raise", clean_cells=False)

    # Typed-exception contract: handlers can read structured
    # widths off the exception without parsing the message.
    assert excinfo.value.row_width == 4
    assert excinfo.value.header_width == 3
    # Subclasses ValueError so existing handlers still catch it.
    assert isinstance(excinfo.value, ValueError)

    # Atomic writer must have removed the temp file on the raise.
    assert not dst.exists()


def test_to_jsonl_validates_profile_at_its_own_boundary(tmp_path: Path):
    # Review finding (Medium): when a caller-supplied profile was
    # mismatched against the input path, validation still fired —
    # but inside read(), so the error message named "read()" rather
    # than "to_jsonl()". Confusing in cached-profile pipelines
    # where the caller is reasoning about to_jsonl(), not its
    # internal streaming dependency. The validation now runs at
    # to_jsonl()'s own boundary so the error message matches the
    # API the caller invoked.
    a = tmp_path / "a.csv"
    b = tmp_path / "b.csv"
    a.write_bytes(b"id,name\n1,alice\n")
    b.write_bytes(b"x;y\n1;alice\n")
    out = tmp_path / "out.jsonl"

    import dsvmonkey
    profile_a = dsvmonkey.profile_file(a)

    with pytest.raises(ValueError) as excinfo:
        to_jsonl(b, out, profile=profile_a)

    msg = str(excinfo.value)
    assert msg.startswith("to_jsonl()"), (
        f"expected error to name to_jsonl() at the boundary, got: {msg!r}"
    )
    assert not out.exists()
