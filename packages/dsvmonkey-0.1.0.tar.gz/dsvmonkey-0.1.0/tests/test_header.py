import pytest

from dsvmonkey.detectors.header import detect_header_row


def test_header_on_row_zero():
    rows = [
        ["id", "name", "age"],
        ["1", "alice", "30"],
        ["2", "bob", "25"],
        ["3", "carol", "40"],
    ]
    result = detect_header_row(rows)
    assert result.value == 0
    assert result.confidence >= 0.5
    assert result.method == "headeriness-score"
    # No preamble warning for row-0 headers.
    assert not any("preamble" in w for w in result.warnings)


def test_header_after_decorative_title_row():
    rows = [
        ["Sales Report Q4 2024", "", "", ""],
        ["id", "product", "qty", "price"],
        ["1", "widget", "10", "2.50"],
        ["2", "gadget", "5", "9.99"],
        ["3", "sprocket", "20", "1.25"],
    ]
    result = detect_header_row(rows)
    assert result.value == 1
    assert any("preamble" in w for w in result.warnings)


def test_header_after_blank_and_metadata_rows():
    rows = [
        ["Generated: 2024-01-15", "", ""],
        ["", "", ""],
        ["id", "name", "score"],
        ["1", "alice", "95"],
        ["2", "bob", "82"],
        ["3", "carol", "91"],
    ]
    result = detect_header_row(rows)
    assert result.value == 2


def test_missing_headers_returns_none():
    # Pure data, no row has any non-numeric "header-like" pattern that
    # contrasts with the others.
    rows = [
        ["1", "100", "50"],
        ["2", "200", "75"],
        ["3", "300", "25"],
        ["4", "400", "90"],
        ["5", "500", "10"],
    ]
    result = detect_header_row(rows)
    assert result.value is None
    assert result.method == "absent"


def test_empty_rows_list_falls_back():
    result = detect_header_row([])
    assert result.value is None
    assert result.method == "fallback"


def test_all_rows_empty_falls_back():
    rows = [[""], ["", "", ""], [""]]
    result = detect_header_row(rows)
    assert result.value is None
    assert result.method == "fallback"


def test_header_beats_row_with_duplicates():
    # Row 0 has duplicated cells ("x", "x", "x"), row 1 is a proper
    # header. The header should win on uniqueness + type contrast.
    rows = [
        ["x", "x", "x"],
        ["id", "name", "age"],
        ["1", "alice", "30"],
        ["2", "bob", "25"],
    ]
    result = detect_header_row(rows)
    assert result.value == 1


def test_long_preamble_does_not_pick_narrow_preamble_row():
    # Review finding: 15 metadata rows before the real header defeated
    # the old 10-row candidate window. Widening to 25 wasn't enough on
    # its own — rows with fewer cells than the table body still beat
    # the real header on type-contrast because their lookahead caught
    # numeric data rows. Narrow rows are now excluded when multi-cell
    # rows exist in the sample.
    rows = [["META_LINE_0: x"]] * 15 + [
        ["id", "name", "qty", "price"],
        ["1", "widget", "10", "2.50"],
        ["2", "gadget", "5", "9.99"],
        ["3", "sprocket", "20", "1.25"],
    ]
    result = detect_header_row(rows)
    assert result.value == 15
    assert any("preamble" in w for w in result.warnings)


def test_detect_header_row_accepts_custom_candidate_window(tmp_path=None):
    # Parametric: callers can raise max_candidate_rows when dealing
    # with even longer preambles than the default 25.
    rows = [["META_LINE", ""]] * 30 + [
        ["id", "name"],
        ["1", "alice"],
        ["2", "bob"],
    ]
    # Default window 25 misses a header at row 30.
    default_result = detect_header_row(rows)
    assert default_result.value != 30
    # With a wider window, it's found.
    wide_result = detect_header_row(rows, max_candidate_rows=40)
    assert wide_result.value == 30


def test_single_column_file_still_scores_headers():
    # The narrow-row filter is conditioned on "any multi-cell rows
    # exist". A truly single-column file has no multi-cell rows, so
    # narrow rows remain valid candidates.
    rows = [["name"], ["alice"], ["bob"], ["carol"]]
    result = detect_header_row(rows)
    # With only one column there's limited signal, so we don't
    # require a specific index — just confirm the filter didn't
    # drop every row.
    assert result.method != "fallback"


def test_us_thousands_grouping_recognised_as_numeric():
    # Review finding (#3): the previous implementation only
    # handled EU decimal (`1,50` → numeric via comma-as-dot
    # replace). US thousands-grouped values like `1,234` happened
    # to parse correctly under the same replace (1.234), but
    # `1,234.56` (US thousands AND decimal) failed both
    # interpretations. Explicit US-thousands handling adds
    # coverage and removes the implicit-coupling.
    from dsvmonkey.detectors.header import _looks_numeric

    # Plain.
    assert _looks_numeric("1.5") is True
    assert _looks_numeric("-3") is True
    # EU decimal.
    assert _looks_numeric("1,50") is True
    # US thousands (comma) + decimal (dot).
    assert _looks_numeric("1,234.56") is True
    # US thousands without decimal.
    assert _looks_numeric("1,234") is True
    # Genuinely non-numeric.
    assert _looks_numeric("hello") is False
    assert _looks_numeric("12 abc") is False


def test_european_decimals_not_treated_as_header():
    # Rows with cells like `1,50` — the detector's numeric test tolerates
    # European decimals, so these count as numeric (data), not strings
    # (header).
    rows = [
        ["id", "amount", "note"],
        ["1", "1,50", "ok"],
        ["2", "2,75", "ok"],
        ["3", "3,00", "ok"],
    ]
    result = detect_header_row(rows)
    assert result.value == 0


# Gap 3: threshold boundary (_HEADER_THRESHOLD = 0.6)
# Scoring weights: 0.30*type_contrast + 0.25*no_numeric +
#                  0.25*populated_ratio + 0.20*unique_ratio.
# Using a single-row sample forces type_contrast=0 (no data rows
# to compare against), letting us hit the boundary with the three
# remaining signals alone.


def test_header_score_just_below_threshold_returns_none():
    # Gap 3: Row scores 0.575 — below both the base 0.6 threshold
    # and the stricter 0.85 low-contrast threshold. Absent either
    # way.
    # width=4, non-empty=2 -> populated=0.50
    # no_numeric=1.0, unique=1.0, type_contrast=0.0 (no data rows)
    # => 0 + 0.25 + 0.125 + 0.20 = 0.575
    from dsvmonkey.detectors.header import _header_score

    row = ["a", "b", "", ""]
    score, _, type_contrast = _header_score(row, [])
    assert score == pytest.approx(0.575)
    assert type_contrast == 0.0

    result = detect_header_row([row])
    assert result.value is None
    assert result.method == "absent"


def test_header_score_above_base_threshold_with_real_type_contrast_detected():
    # Replaces an earlier test that pinned "0.65 above 0.6 detects
    # header" using a single-row sample (type_contrast=0). That
    # behaviour was a false-positive vector on headerless all-
    # string files — detection now requires BOTH score >= base
    # AND meaningful type_contrast. Construct a fixture where the
    # candidate row scores above the base threshold AND has real
    # numeric differentiation from the rows below.
    from dsvmonkey.detectors.header import _header_score

    rows = [
        ["a", "b", "c", "d"],          # candidate header
        ["1", "2", "3", "4"],          # numeric data
        ["5", "6", "7", "8"],
    ]
    score, _, type_contrast = _header_score(rows[0], rows[1:])
    assert type_contrast > 0.25  # clears the low-contrast gate
    assert score >= 0.6

    result = detect_header_row(rows)
    assert result.value == 0
    assert result.method == "headeriness-score"


def test_headerless_all_string_file_not_flagged_as_header():
    # Review finding (Medium): the old base threshold of 0.6 would
    # flag row 0 of an all-string dataset as header via
    # no_numeric=1 + populated=1 + unique~1 + type_contrast=0
    # (sum ~0.70, above 0.6). That dropped the first data row
    # from the output. Stricter low-contrast threshold (0.85) now
    # requires real numeric differentiation before accepting a
    # header on all-string files — if every column is prose, we
    # can't tell a header from its first data row, so we should
    # err on the side of "no header" and let the user override.
    rows = [
        ["alice", "london", "engineer"],
        ["bob", "paris", "designer"],
        ["carol", "berlin", "writer"],
        ["dave", "amsterdam", "analyst"],
    ]
    result = detect_header_row(rows)
    assert result.value is None
    assert result.method == "absent"
    assert any("threshold" in w for w in result.warnings)


# Gap 4: "decorative title row 0 + real header row 1" contract.


def test_decorative_title_row_then_real_header_picks_row_one():
    # Gap 4: The docstring ("decorative title row 0 + real header row 1
    # case — row 1 will usually score higher because it has more
    # populated cells and a cleaner type contrast") promises row 1 wins
    # when row 0 is a decorative title with mostly-empty / narrow cells.
    rows = [
        ["Q4 Sales Report", "", "", ""],
        ["id", "product", "qty", "price"],
        ["1", "widget", "10", "2.50"],
        ["2", "gadget", "5", "9.99"],
        ["3", "sprocket", "20", "1.25"],
    ]
    result = detect_header_row(rows)
    assert result.value == 1
    assert any("preamble" in w for w in result.warnings)


def test_decorative_title_row_all_unique_not_empty_still_picks_real_header():
    # Gap 4 adversarial: row 0 is a decorative title with ALL unique,
    # ALL populated, non-numeric cells — by every signal except
    # identifier-shape it looks as "headery" as row 1. The detector
    # now breaks the score tie with an `_identifier_ratio` signal:
    # "id", "product", "qty", "price" are all lowercase single
    # tokens, while "Quarterly", "Report", "Summary" are mixed-case.
    # Row 1 wins the tie-break.
    rows = [
        ["Quarterly", "Report", "2024Q4", "Summary"],
        ["id", "product", "qty", "price"],
        ["1", "widget", "10", "2.50"],
        ["2", "gadget", "5", "9.99"],
        ["3", "sprocket", "20", "1.25"],
    ]
    result = detect_header_row(rows)
    assert result.value == 1


def test_identifier_tie_break_does_not_override_genuine_score_difference():
    # Contract: identifier_ratio is a *tie-breaker*, not a weight —
    # a row that scores substantially higher on the main signals must
    # still win even if its cells are Title-Case. Prevents regressing
    # Title-Case-header files.
    rows = [
        ["x", "x", "x"],  # row 0: all identifier-shaped but duplicated
        ["First Name", "Last Name", "Age"],  # row 1: Title-Case header
        ["Alice", "Jones", "30"],
        ["Bob", "Smith", "25"],
        ["Carol", "Doe", "40"],
    ]
    result = detect_header_row(rows)
    # Row 1 should still win on uniqueness + type-contrast, despite
    # row 0 being more "identifier-shaped".
    assert result.value == 1


def test_pure_data_file_reports_absent_not_fallback():
    # Gap 4 pinning: a file that is pure numeric data with no header
    # anywhere should be reported as method="absent" (a confident
    # "no header here"), distinct from method="fallback" (empty /
    # unusable input). This confirms the False-for-a-different-reason
    # contract.
    rows = [
        ["1", "100", "50", "0.5"],
        ["2", "200", "75", "0.6"],
        ["3", "300", "25", "0.7"],
        ["4", "400", "90", "0.8"],
        ["5", "500", "10", "0.9"],
    ]
    result = detect_header_row(rows)
    assert result.value is None
    assert result.method == "absent"
    # "absent" carries a diagnostic warning; "fallback" wouldn't
    # mention a best-candidate score.
    assert any("headers may be missing" in w for w in result.warnings)
