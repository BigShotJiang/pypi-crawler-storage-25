import warnings
from pathlib import Path

import pytest

import dsvmonkey


# ---------- Basic streaming ----------


def test_yields_dicts_by_default(tmp_path: Path):
    path = tmp_path / "clean.csv"
    path.write_bytes(b"id,name,age\n1,alice,30\n2,bob,25\n")
    rows = list(dsvmonkey.read(path))
    assert rows == [
        {"id": "1", "name": "alice", "age": "30"},
        {"id": "2", "name": "bob", "age": "25"},
    ]


def test_as_dict_false_yields_lists(tmp_path: Path):
    path = tmp_path / "clean.csv"
    path.write_bytes(b"id,name,age\n1,alice,30\n2,bob,25\n")
    rows = list(dsvmonkey.read(path, as_dict=False))
    assert rows == [["1", "alice", "30"], ["2", "bob", "25"]]


def test_preamble_and_header_are_skipped(tmp_path: Path):
    path = tmp_path / "titled.csv"
    path.write_bytes(
        b"Sales Report Q4 2024,,,\r\n"
        b"\r\n"
        b"id,product,qty,price\r\n"
        b"1,widget,10,2.50\r\n"
        b"2,gadget,5,9.99\r\n"
    )
    rows = list(dsvmonkey.read(path))
    assert len(rows) == 2
    assert rows[0] == {"id": "1", "product": "widget", "qty": "10", "price": "2.50"}


# ---------- BOM handling ----------


def test_bom_does_not_leak_into_first_header_key(tmp_path: Path):
    # The classic regression: "﻿id" ends up as a dict key and every
    # lookup of `row["id"]` raises KeyError.
    path = tmp_path / "bom.csv"
    path.write_bytes("﻿id,name\n1,alice\n2,bob\n".encode("utf-8"))
    rows = list(dsvmonkey.read(path))
    assert "id" in rows[0]
    assert "﻿id" not in rows[0]
    assert rows[0]["id"] == "1"


# ---------- cleanmonkey integration ----------


def test_invisible_chars_stripped_from_cells(tmp_path: Path):
    # ​ = zero-width space; a common source of silent breakage
    # when categorical values don't compare equal.
    path = tmp_path / "zwsp.csv"
    path.write_bytes("id,status\n1,Active​\n2,Active\n".encode("utf-8"))
    rows = list(dsvmonkey.read(path))
    # Both should now compare equal — that's the whole point of
    # cleaning at the boundary.
    assert rows[0]["status"] == rows[1]["status"] == "Active"


def test_nbsp_in_numeric_field_is_normalized(tmp_path: Path):
    # 1 2,50 -> 1 2,50 in cp1252/fr exports; cleanmonkey should
    # at least normalize the NBSP to a regular space.
    path = tmp_path / "nbsp.csv"
    path.write_bytes(
        "id,amount\n1,1 234\n2,5 678\n".encode("utf-8")
    )
    rows = list(dsvmonkey.read(path))
    # Cleaned form shouldn't contain the NBSP; it's been collapsed to
    # a regular space or removed.
    for row in rows:
        assert " " not in row["amount"]


def test_clean_false_preserves_cell_bytes(tmp_path: Path):
    path = tmp_path / "invis.csv"
    raw = "id,status\n1,Active​\n".encode("utf-8")
    path.write_bytes(raw)
    rows = list(dsvmonkey.read(path, clean=False))
    assert rows[0]["status"] == "Active​"


def test_clean_by_profile_name(tmp_path: Path):
    # "minimal" doesn't strip whitespace or collapse spaces.
    path = tmp_path / "minimal.csv"
    path.write_bytes(b"id,note\n1,  padded  \n")
    rows = list(dsvmonkey.read(path, clean="minimal"))
    # Padding preserved under minimal profile.
    assert rows[0]["note"] == "  padded  "


# ---------- Ragged rows and missing headers ----------


def test_short_rows_pad_with_empty_strings(tmp_path: Path):
    path = tmp_path / "ragged.csv"
    path.write_bytes(b"id,name,age\n1,alice,30\n2,bob\n")
    rows = list(dsvmonkey.read(path))
    assert rows[1] == {"id": "2", "name": "bob", "age": ""}


def test_utf16_bom_does_not_leak_into_first_cell(tmp_path: Path):
    # Review finding: the encoding detector returns endianness-specific
    # codec names for BOM-bearing UTF-16 files (utf-16-le, utf-16-be).
    # Those codecs don't consume the BOM the way utf-16 does, so
    # ﻿ ends up in the first cell of the first row. With
    # clean=False and no header to skip, the leak is visible to
    # downstream code.
    path = tmp_path / "utf16bom.csv"
    text = "1,alice\n2,bob\n3,carol\n"
    path.write_bytes(b"\xff\xfe" + text.encode("utf-16-le"))

    rows = list(dsvmonkey.read(path, as_dict=False, clean=False))
    assert rows == [["1", "alice"], ["2", "bob"], ["3", "carol"]]
    assert "﻿" not in rows[0][0]


def test_utf16_be_bom_does_not_leak_into_first_cell(tmp_path: Path):
    # Same regression, big-endian variant.
    path = tmp_path / "utf16bebom.csv"
    text = "1,alice\n2,bob\n"
    path.write_bytes(b"\xfe\xff" + text.encode("utf-16-be"))

    rows = list(dsvmonkey.read(path, as_dict=False, clean=False))
    assert rows[0][0] == "1"


def test_long_rows_truncate_to_header_width(tmp_path: Path):
    path = tmp_path / "overlong.csv"
    path.write_bytes(b"id,name\n1,alice,extra,more\n2,bob\n")
    # Overflow cells are discarded at the dict boundary — and that
    # discarding now surfaces a UserWarning so the loss is visible.
    with pytest.warns(UserWarning, match="overflow cells are dropped"):
        rows = list(dsvmonkey.read(path))
    assert rows[0] == {"id": "1", "name": "alice"}


def test_missing_headers_auto_generates_col_names(tmp_path: Path):
    path = tmp_path / "no_header.csv"
    path.write_bytes(b"1,100,50\n2,200,75\n3,300,25\n4,400,90\n5,500,10\n")
    rows = list(dsvmonkey.read(path))
    assert rows[0] == {"col_0": "1", "col_1": "100", "col_2": "50"}


def test_explicit_headers_override_detection(tmp_path: Path):
    path = tmp_path / "custom.csv"
    path.write_bytes(b"1,100\n2,200\n3,300\n")
    rows = list(dsvmonkey.read(path, headers=["n", "v"]))
    assert rows[0] == {"n": "1", "v": "100"}


def test_explicit_empty_headers_are_respected(tmp_path: Path):
    # Behaviour: passing headers=[] explicitly means "no header
    # mapping, yield empty dicts" — the lazy first-row-width
    # fallback does NOT trigger and silently replace [] with
    # auto-generated col_N. The behaviour is preserved; a
    # UserWarning surfaces the fact that every cell is being
    # discarded (review finding: this is a sharp edge that's easy
    # to trigger accidentally in wrapper code).
    path = tmp_path / "ex.csv"
    path.write_bytes(b"1,alice\n2,bob\n")
    with pytest.warns(UserWarning, match="empty dicts"):
        rows = list(dsvmonkey.read(path, headers=[]))
    assert rows == [{}, {}]


def test_explicit_empty_headers_no_warning_in_list_mode(tmp_path: Path):
    # The empty-headers warning is dict-mode specific. List mode
    # preserves every cell regardless of headers, so there's no
    # data loss to flag.
    path = tmp_path / "ex.csv"
    path.write_bytes(b"1,alice\n2,bob\n")
    with warnings.catch_warnings():
        warnings.simplefilter("error", UserWarning)
        rows = list(dsvmonkey.read(path, headers=[], as_dict=False))
    assert rows == [["1", "alice"], ["2", "bob"]]


# ---------- Passing a precomputed profile ----------


def test_reuses_precomputed_profile(tmp_path: Path):
    path = tmp_path / "pre.csv"
    path.write_bytes(b"id,name\n1,alice\n2,bob\n")
    profile = dsvmonkey.profile_file(path)
    rows = list(dsvmonkey.read(path, profile=profile))
    assert rows == [{"id": "1", "name": "alice"}, {"id": "2", "name": "bob"}]


# ---------- Streaming semantics ----------


def test_is_a_generator_not_a_list(tmp_path: Path):
    path = tmp_path / "gen.csv"
    path.write_bytes(b"id,name\n1,alice\n2,bob\n")
    gen = dsvmonkey.read(path)
    # Must be iterable but not a materialized list.
    assert not isinstance(gen, list)
    first = next(iter(gen))
    assert first == {"id": "1", "name": "alice"}


# ---------- Regression: silent empty-dict fallback ----------


def test_unresolved_field_count_does_not_silently_empty_dicts(tmp_path: Path):
    # Review finding: if DSVProfile.field_count stays None (e.g. because
    # header detection couldn't locate a header and the sample parse
    # didn't populate it), read(as_dict=True) used to zip every row
    # against an empty header list and yield `{}` silently — data loss
    # dressed up as success.
    path = tmp_path / "f.csv"
    path.write_bytes(b"a,b,c\n1,2,3\n4,5,6\n")
    profile = dsvmonkey.profile_file(path)
    profile.headers = None
    profile.field_count = None
    profile.header_row.value = None

    rows = list(dsvmonkey.read(path, profile=profile, as_dict=True))

    # Three physical rows, three non-empty dicts out — not three `{}`s.
    assert len(rows) == 3
    assert all(row for row in rows), rows
    # First row's width (3) should drive auto-generated col_N names.
    assert set(rows[0].keys()) == {"col_0", "col_1", "col_2"}
    assert rows[0] == {"col_0": "a", "col_1": "b", "col_2": "c"}


# ---------- Warnings on silent data-loss shapes ----------


def test_duplicate_headers_warn_once(tmp_path: Path):
    # Review finding: duplicate headers silently collapse in dict
    # mode because csv.DictReader-style zipping puts both values under
    # one key; the later value wins and the earlier column is lost.
    # We now emit a UserWarning so the caller knows data is being
    # discarded.
    path = tmp_path / "dup.csv"
    path.write_bytes(b"id,name,id\n1,alice,99\n2,bob,88\n")

    with pytest.warns(UserWarning, match="duplicate header"):
        rows = list(dsvmonkey.read(path))

    # Behaviour is unchanged — the warning is the new signal, not a
    # behavior change. Users who want strictness can escalate via
    # warnings.filterwarnings("error", ...).
    assert rows[0]["id"] == "99"


def test_duplicate_headers_do_not_warn_in_list_mode(tmp_path: Path):
    # List output preserves every cell, so duplicate header names
    # don't actually lose data — no warning should fire.
    path = tmp_path / "dup.csv"
    path.write_bytes(b"id,name,id\n1,alice,99\n2,bob,88\n")

    with warnings.catch_warnings():
        warnings.simplefilter("error")
        rows = list(dsvmonkey.read(path, as_dict=False))

    assert rows == [["1", "alice", "99"], ["2", "bob", "88"]]


def test_overflow_rows_warn_once_in_dict_mode(tmp_path: Path):
    # Review finding: rows wider than the header are silently
    # truncated in dict mode. We warn on the first occurrence per
    # read() call (not once per offending row, to avoid flooding the
    # log on a 10k-row file).
    path = tmp_path / "wide.csv"
    path.write_bytes(
        b"id,name\n"
        b"1,alice,extra,more\n"
        b"2,bob,lots,more,overflow\n"
        b"3,carol\n"
    )

    with pytest.warns(UserWarning, match="overflow cells are dropped") as caught:
        rows = list(dsvmonkey.read(path))

    # Exactly one warning — not one per offending row.
    overflow_warnings = [
        w for w in caught.list if "overflow cells are dropped" in str(w.message)
    ]
    assert len(overflow_warnings) == 1

    # Behaviour unchanged for the rows themselves.
    assert rows[0] == {"id": "1", "name": "alice"}


def test_read_accepts_callable_clean(tmp_path: Path):
    # Self-review finding: _resolve_clean used to treat bare callables
    # as cleanmonkey.Profile objects and crash on first row with a
    # confusing TypeError. Callables now pass through as-is.
    path = tmp_path / "f.csv"
    path.write_bytes(b"id,name\n1,alice\n2,bob\n")
    rows = list(dsvmonkey.read(path, clean=str.upper))
    # Callable is applied to headers (via _resolve_headers) and cells,
    # so everything is uppercased.
    assert rows == [
        {"ID": "1", "NAME": "ALICE"},
        {"ID": "2", "NAME": "BOB"},
    ]


def test_read_rejects_bogus_clean_setting(tmp_path: Path):
    path = tmp_path / "f.csv"
    path.write_bytes(b"id,name\n1,alice\n")
    with pytest.raises(TypeError, match="clean must be"):
        list(dsvmonkey.read(path, clean=42))  # type: ignore[arg-type]


def test_skip_empty_rows_false_preserves_blank_rows(tmp_path: Path):
    # Review finding: both read() and repair() dropped whitespace-only
    # rows unconditionally, which is the right ETL default but wrong
    # for fixed-format exports, audit trails, or placeholder-marker
    # workflows where blank rows carry meaning. `skip_empty_rows=False`
    # opts out and preserves them in the yielded stream.
    path = tmp_path / "ws.csv"
    path.write_bytes(b"id,name\n1,alice\n   ,   \n2,bob\n\t,\t\n3,carol\n")

    rows = list(dsvmonkey.read(path, as_dict=False, skip_empty_rows=False))
    # Five rows: 3 real + 2 blank, preserved in order.
    assert len(rows) == 5
    # Blank rows are yielded with their (possibly whitespace-only) cells.
    blank_rows = [r for r in rows if not any(c.strip() for c in r)]
    assert len(blank_rows) == 2


def test_zero_width_space_only_rows_are_dropped_with_default_cleaning(
    tmp_path: Path,
):
    # Review finding (#1): str.strip() doesn't remove U+200B
    # (zero-width space) or U+FEFF, so rows composed entirely of
    # invisibles used to pass the is-empty check, get cleaned
    # into empty strings by cleanmonkey, and land in the output
    # as ghost rows of empty cells — inconsistent with the
    # documented "invisible chars cleaned + blank rows skipped"
    # behaviour.
    zwsp = "​"
    content = (
        "id,name\n"
        "1,alice\n"
        f"{zwsp},{zwsp}\n"       # pure ZWSP row
        "2,bob\n"
    ).encode("utf-8")
    path = tmp_path / "zwsp.csv"
    path.write_bytes(content)

    rows = list(dsvmonkey.read(path, as_dict=False))
    # ZWSP row must be dropped — not surface as ['', ''].
    assert rows == [["1", "alice"], ["2", "bob"]]


def test_bom_char_only_rows_are_dropped_with_default_cleaning(tmp_path: Path):
    # Same bug, different invisible: U+FEFF (ZWNBSP) is also
    # transparent to str.strip() but cleaned away by cleanmonkey.
    feff = "﻿"
    content = (
        "id,name\n"
        "1,alice\n"
        f"{feff},{feff}\n"
        "2,bob\n"
    ).encode("utf-8")
    path = tmp_path / "feff.csv"
    path.write_bytes(content)

    rows = list(dsvmonkey.read(path, as_dict=False))
    assert rows == [["1", "alice"], ["2", "bob"]]


def test_clean_false_preserves_invisible_only_rows(tmp_path: Path):
    # Byte-exact mode (clean=False) preserves content — invisibles
    # are data under that contract. The empty-row check runs on
    # raw bytes, and ZWSP passes `str.strip()` as non-whitespace,
    # so the row survives. Pin the consistency: clean=False means
    # "I want what's in the file."
    zwsp = "​"
    content = (
        "id,name\n"
        "1,alice\n"
        f"{zwsp},{zwsp}\n"
        "2,bob\n"
    ).encode("utf-8")
    path = tmp_path / "zwsp.csv"
    path.write_bytes(content)

    rows = list(dsvmonkey.read(path, as_dict=False, clean=False))
    # 3 rows: alice, the ZWSP row, bob.
    assert len(rows) == 3
    assert rows[1] == [zwsp, zwsp]


def test_single_column_with_sentinel_collision_outside_sample(tmp_path: Path):
    # Review finding (#1 Medium): the single-column sentinel was
    # picked from the detection sample (~256 KB). If the sentinel
    # character appeared later in the unsampled file body, csv.reader
    # would split single-column rows on it. The fix bypasses
    # csv.reader entirely for single-column files — line iteration
    # has no concept of a delimiter, so collisions can't occur.
    #
    # Construct a file where the chosen sentinel shows up in line
    # content far past the sample window. Under the old behaviour,
    # those lines would split into multiple cells.
    path = tmp_path / "long.csv"
    # Big single-column file (no candidate delimiter in the head).
    head = b"line of plain text without any delimiter\n" * 8000
    # Trailing line containing the default sentinel character — would
    # cause splits under the old csv.reader path.
    tail = b"this line\x1fhas the default sentinel embedded\n"
    path.write_bytes(head + tail)

    rows = list(dsvmonkey.read(path, as_dict=False, clean=False))
    # Each line is one cell, regardless of what bytes it contains.
    assert all(len(r) == 1 for r in rows)
    # The trailing line preserved as-is (sentinel byte intact).
    assert any("\x1f" in r[0] for r in rows)


def test_single_column_with_quoted_multiline_cells_preserves_row_boundaries(
    tmp_path: Path,
):
    # Review finding (High): single-column mode used physical-line
    # iteration unconditionally, which silently corrupted files
    # where a one-column cell legitimately contained a newline
    # inside CSV quoting. A 3-line file with one quoted-multiline
    # cell yielded three rows instead of two — actual data loss,
    # not just formatting drift. The fix splits the single-column
    # parsing path on quote-char presence: when quoting is
    # detected, defer to csv.reader so the quote-aware row
    # boundary logic joins the multi-physical-line cell back into
    # one logical row. Pin the contract.
    path = tmp_path / "quoted_multiline.csv"
    # One quoted multiline cell ("hello\nworld") plus one plain
    # quoted cell ("foo"). Three physical lines, two logical rows.
    path.write_bytes(b'"hello\nworld"\n"foo"\n')

    rows = list(dsvmonkey.read(path, as_dict=False, clean=False))
    assert len(rows) == 2, (
        f"expected 2 rows (quote-aware), got {len(rows)} rows: {rows!r}"
    )
    assert rows[0] == ["hello\nworld"]
    assert rows[1] == ["foo"]


def test_single_column_repair_round_trip_preserves_quoted_multiline(
    tmp_path: Path,
):
    # Companion to the read() test: repair() shares
    # `_make_row_iterator`, so the same fix has to make round-trip
    # output well-formed too. Previously repair() emitted malformed
    # quoting (`"""hello"`, `"world"""`, ...) because each physical
    # line was treated as a separate row and re-quoted on the way
    # out.
    src = tmp_path / "in.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b'"hello\nworld"\n"foo"\n')

    import dsvmonkey
    dsvmonkey.repair(src, dst, clean_cells=False)

    text = dst.read_text()
    # Round-trip through csv.writer should produce the same logical
    # cell content — one row with an embedded newline, one plain row.
    import csv
    import io
    parsed = list(csv.reader(io.StringIO(text)))
    assert len(parsed) == 2
    assert parsed[0] == ["hello\nworld"]
    assert parsed[1] == ["foo"]


def test_single_column_no_quote_char_still_uses_line_iteration(
    tmp_path: Path,
):
    # Negative pin: the line-iteration path is still used when no
    # quote char was detected (plain free-text exports). This
    # preserves the sentinel-vs-content collision protection that
    # earlier review cycles closed: physical-line iteration has no
    # delimiter concept, so a sentinel character appearing in the
    # body can't split a row.
    path = tmp_path / "plain.csv"
    # Free-text single column, no quoting anywhere. Includes the
    # default sentinel character in line content to confirm line
    # iteration ignores it.
    path.write_bytes(
        b"first plain line\n"
        b"second plain line\n"
        b"line with embedded \x1f sentinel byte\n"
        b"last line\n"
    )

    rows = list(dsvmonkey.read(path, as_dict=False, clean=False))
    # Four physical lines → four one-cell rows. Sentinel in content
    # is preserved (line iteration never used it as a delimiter).
    assert len(rows) == 4
    assert rows[2] == ["line with embedded \x1f sentinel byte"]


def test_single_column_strips_only_one_record_terminator(tmp_path: Path):
    # Review finding (#3): rstrip("\r\n") strips ANY trailing
    # combination of CR and LF, not just the record terminator
    # sequence. Lines that legitimately end in "\r\r\n" (rare —
    # protocol dumps, certain binary-shaped exports) had their
    # meaningful trailing CR eaten by the strip. Now we strip
    # exactly the terminator.
    #
    # Build a single-column file with embedded trailing CRs.
    # Content of each line: text + bare CR + LF terminator.
    # Expected after read: text + bare CR (the LF was the
    # terminator; the preceding CR is content).
    path = tmp_path / "preserve_cr.csv"
    path.write_bytes(b"line one with trailing cr\r\nplain line\nlast\r\n")

    rows = list(dsvmonkey.read(path, as_dict=False, clean=False))
    # Three lines, each one cell.
    assert len(rows) == 3
    # The "\r\n" terminators were stripped completely (no
    # trailing CR survives because there was only the
    # terminator's CR, no content CR before it).
    assert rows[0] == ["line one with trailing cr"]
    assert rows[1] == ["plain line"]
    assert rows[2] == ["last"]


def test_single_column_preserves_content_cr_before_terminator(tmp_path: Path):
    # Adversarial: content CR immediately before the CRLF
    # terminator. Old `rstrip("\r\n")` would eat both; new
    # `_strip_one_record_terminator` strips only the CRLF and
    # preserves the content CR.
    from dsvmonkey.reader import _strip_one_record_terminator

    # Direct unit test on the helper — easier to construct than
    # via file iteration (Python's text-mode line splitter has
    # its own opinions about back-to-back CR sequences).
    assert _strip_one_record_terminator("abc\r\r\n") == "abc\r"
    assert _strip_one_record_terminator("abc\r\n") == "abc"
    assert _strip_one_record_terminator("abc\n") == "abc"
    assert _strip_one_record_terminator("abc\r") == "abc"
    assert _strip_one_record_terminator("abc") == "abc"
    # And bare CR before LF: strip only the LF, preserve the CR.
    assert _strip_one_record_terminator("abc\r\rstill-cr\n") == "abc\r\rstill-cr"


def test_skip_empty_rows_default_still_drops(tmp_path: Path):
    # Negative case: the default is unchanged. Blank rows still go.
    path = tmp_path / "ws.csv"
    path.write_bytes(b"id,name\n1,alice\n   ,   \n2,bob\n")
    rows = list(dsvmonkey.read(path, as_dict=False))
    assert len(rows) == 2


def test_read_warns_when_header_index_past_eof(tmp_path: Path):
    # Review finding: if a caller passes a profile with
    # header_row.value larger than the file's row count, read() used
    # to skip to EOF and silently yield no rows. That's hard to
    # diagnose without tracing. The skip loop now warns so a
    # monitoring check can surface it.
    path = tmp_path / "tiny.csv"
    path.write_bytes(b"id,name\n1,alice\n")
    profile = dsvmonkey.profile_file(path)
    # Force header_row past the file's actual rows.
    profile.header_row.value = 99

    with pytest.warns(UserWarning, match="only"):
        rows = list(dsvmonkey.read(path, profile=profile, as_dict=False))
    # Behaviour unchanged: still no data. The warning is the new signal.
    assert rows == []


def test_read_skips_whitespace_only_rows(tmp_path: Path):
    # Self-review finding: repair() now skips whitespace-only rows
    # after the prior review; read() should match so the two APIs
    # don't disagree on what counts as empty.
    path = tmp_path / "ws.csv"
    path.write_bytes(b"id,name\n1,alice\n   ,   \n2,bob\n\t,\t\n3,carol\n")
    rows = list(dsvmonkey.read(path))
    assert rows == [
        {"id": "1", "name": "alice"},
        {"id": "2", "name": "bob"},
        {"id": "3", "name": "carol"},
    ]


def test_overflow_warning_is_escalatable_to_error_for_etl_pipelines(
    tmp_path: Path,
):
    # Contract for unattended ETL: the only signal that overflow cells
    # are being dropped is the UserWarning. Production pipelines that
    # can't afford silent data loss must be able to promote it to an
    # exception via the standard warnings machinery. This test pins
    # that escalation path so a future "log-once" or custom-category
    # refactor can't accidentally make the drop unrecoverable.
    path = tmp_path / "wide.csv"
    path.write_bytes(b"id,name\n1,alice,extra,more\n2,bob\n")

    with warnings.catch_warnings():
        warnings.simplefilter("error", UserWarning)
        with pytest.raises(UserWarning, match="overflow cells are dropped"):
            list(dsvmonkey.read(path))


def test_overflow_rows_do_not_warn_in_list_mode(tmp_path: Path):
    # as_dict=False already preserves every cell, so no data loss,
    # no warning.
    path = tmp_path / "wide.csv"
    path.write_bytes(b"id,name\n1,alice,extra,more\n")

    with warnings.catch_warnings():
        warnings.simplefilter("error")
        rows = list(dsvmonkey.read(path, as_dict=False))

    assert rows == [["1", "alice", "extra", "more"]]


def test_large_file_does_not_load_fully(tmp_path: Path):
    # Synthesize a moderately large file and confirm we can read the
    # first row without consuming everything. A real memory check is
    # tricky; this is a smoke test that the generator yields before
    # the file is fully parsed.
    path = tmp_path / "big.csv"
    header = b"id,name\n"
    body = b"".join(f"{i},name_{i}\n".encode() for i in range(10_000))
    path.write_bytes(header + body)

    gen = dsvmonkey.read(path)
    first = next(iter(gen))
    assert first == {"id": "0", "name": "name_0"}


# ---------- Contract-driven additions ----------


# Gap 1: _resolve_clean accepts a cleanmonkey.Profile object directly.
# The docstring lists it as an accepted input; no existing test passes
# an actual Profile instance (previous tests only cover bool/str/callable).
def test_read_accepts_cleanmonkey_profile_object(tmp_path: Path):
    import cleanmonkey

    # Use the shipped "csv" profile as a real Profile instance.
    csv_profile = cleanmonkey.PROFILES["csv"]
    assert isinstance(csv_profile, cleanmonkey.Profile)

    path = tmp_path / "profile_obj.csv"
    # Zero-width space in a cell — the csv profile strips invisibles.
    path.write_bytes("id,status\n1,Active​\n".encode("utf-8"))
    rows = list(dsvmonkey.read(path, clean=csv_profile))
    # Passing a Profile must actually clean (not silently fall through
    # to no-op) — the ZWSP disappears.
    assert rows[0]["status"] == "Active"


# Gap 5: header_index=0 means one skip (the header itself), not zero.
# The docstring promises "skip N+1"; off-by-one here would yield the
# header row as data.
def test_header_at_index_zero_skips_one_row(tmp_path: Path):
    path = tmp_path / "h0.csv"
    path.write_bytes(b"id,name\n1,alice\n2,bob\n")
    profile = dsvmonkey.profile_file(path)
    # Pin the contract: detected header at row 0.
    assert profile.header_row is not None
    assert profile.header_row.value == 0

    rows = list(dsvmonkey.read(path, profile=profile, as_dict=False))
    # First yielded row must be the first DATA row, not the header.
    assert rows[0] == ["1", "alice"]
    assert rows[0] != ["id", "name"]


# Gap 6: _zip_to_dict pads short rows with "". A padded-to-width row
# and a row containing a genuine empty cell must be indistinguishable
# in dict output — that's the intent the padding preserves.
def test_padded_short_row_indistinguishable_from_genuine_empty(
    tmp_path: Path,
):
    path_genuine = tmp_path / "genuine.csv"
    path_genuine.write_bytes(b"a,b\n1,\n")
    path_padded = tmp_path / "padded.csv"
    path_padded.write_bytes(b"a,b\n1\n")

    genuine = list(dsvmonkey.read(path_genuine, as_dict=True))
    padded = list(dsvmonkey.read(path_padded, as_dict=True))

    # Both rows must produce the same dict: {"a": "1", "b": ""}.
    assert genuine == padded
    assert genuine[0] == {"a": "1", "b": ""}


# Gap 7: true cold-start lazy first-row-width fallback.
# No detected header, field_count=None, caller passes no headers.
# Docstring promises col_N keys derived from the first row's width.
def test_cold_start_lazy_width_fallback_generates_col_names(tmp_path: Path):
    # Two rows so delimiter detection has enough evidence to pick
    # comma (single-row samples are genuinely ambiguous between
    # "multi-column CSV" and "single column containing commas", and
    # the detector correctly treats those as single-column now).
    path = tmp_path / "cold.csv"
    path.write_bytes(b"a,b,c\nd,e,f\n")
    profile = dsvmonkey.profile_file(path)
    # Force a true zero-info profile — simulate a detection pipeline
    # that returned nothing useful structurally.
    profile.headers = None
    profile.field_count = None
    profile.header_row.value = None

    rows = list(dsvmonkey.read(path, profile=profile, as_dict=True))
    assert len(rows) == 2
    assert set(rows[0].keys()) == {"col_0", "col_1", "col_2"}
    assert rows[0] == {"col_0": "a", "col_1": "b", "col_2": "c"}


# Gap 14: _effective_text_encoding falls back to "utf-8" when
# profile.encoding is None. Pins the documented default.
def test_effective_text_encoding_falls_back_to_utf8_when_encoding_none(
    tmp_path: Path,
):
    from dsvmonkey.reader import _effective_text_encoding

    path = tmp_path / "any.csv"
    path.write_bytes(b"a,b\n1,2\n")
    profile = dsvmonkey.profile_file(path)
    # Clear the detected encoding to probe the fallback branch.
    profile.encoding = None
    profile.has_bom = False

    assert _effective_text_encoding(profile) == "utf-8"


# Gap 21: callable clean applies to BOTH header names AND cell values.
# Uses a distinctive marker (not just case-folding) so the assertion
# can't pass by coincidence of the source data.
def test_callable_clean_applied_to_headers_and_cells(tmp_path: Path):
    path = tmp_path / "marker.csv"
    path.write_bytes(b"id,name\n1,alice\n")
    rows = list(dsvmonkey.read(path, clean=lambda s: "X_" + s))
    # Header names must carry the marker (keys).
    assert "X_id" in rows[0]
    assert "X_name" in rows[0]
    # Cell values must carry the marker too.
    assert rows[0]["X_id"] == "X_1"
    assert rows[0]["X_name"] == "X_alice"


# Gap 25: the BOM-stripping remap only targets endian-specific codecs.
# utf-8-sig and plain utf-16 already strip their own BOM and MUST NOT
# be remapped — identity passthrough is the contract.
def test_effective_text_encoding_handles_uppercase_endian_codec_alias(
    tmp_path: Path,
):
    # Review finding (#2): caller-supplied profiles can use valid
    # codec aliases / casing that Python's codecs.lookup accepts.
    # The BOM-strip remap was case-sensitive against lowercase
    # canonical keys, so a profile with `encoding.value="UTF-16-LE"`
    # bypassed the remap and leaked the BOM into the first cell.
    # Normalisation before lookup closes the gap.
    from dsvmonkey.profile import DSVProfile, DetectionResult
    from dsvmonkey.reader import _effective_text_encoding

    path = tmp_path / "x.csv"
    profile = DSVProfile(path=path, file_size=10, sample_bytes=10)
    profile.has_bom = True
    # Common alias casing variants accepted by codecs.lookup.
    for alias in ("UTF-16-LE", "Utf-16-Le", "utf_16_le", "utf-16-LE"):
        profile.encoding = DetectionResult(
            value=alias, confidence=1.0, method="bom"
        )
        # All these should remap to the BOM-stripping `utf-16`.
        assert _effective_text_encoding(profile) == "utf-16", alias


def test_effective_text_encoding_does_not_remap_self_stripping_codecs(
    tmp_path: Path,
):
    from dsvmonkey.reader import _effective_text_encoding

    path = tmp_path / "any.csv"
    path.write_bytes(b"a,b\n1,2\n")
    profile = dsvmonkey.profile_file(path)
    profile.has_bom = True

    # utf-8-sig already strips its own BOM — leave it alone.
    profile.encoding.value = "utf-8-sig"
    assert _effective_text_encoding(profile) == "utf-8-sig"

    # Plain utf-16 (non-endian variant) already strips its BOM too.
    profile.encoding.value = "utf-16"
    assert _effective_text_encoding(profile) == "utf-16"

    # Sanity check the other side of the boundary: utf-16-le IS remapped.
    profile.encoding.value = "utf-16-le"
    assert _effective_text_encoding(profile) == "utf-16"


def test_read_on_overflow_warn_is_default_and_drops_cells(
    tmp_path: Path, recwarn,
):
    # Default behaviour pin: dict-mode rows wider than headers
    # emit one UserWarning and drop the overflow cells. Same as
    # the historical contract — no behaviour change for callers
    # who don't pass `on_overflow`.
    src = tmp_path / "ragged.csv"
    src.write_bytes(
        b"id,name,age\n"
        b"1,alice,30\n"
        b"2,bob,25,extra\n"
        b"3,carol,40\n"
    )

    rows = list(dsvmonkey.read(src, as_dict=True))
    assert len(rows) == 3
    # Overflow cell dropped from row 2.
    assert rows[1] == {"id": "2", "name": "bob", "age": "25"}
    # Exactly one overflow warning emitted (not one per overflow row).
    overflow_warnings = [
        w for w in recwarn.list
        if "overflow cells are dropped" in str(w.message)
    ]
    assert len(overflow_warnings) == 1


def test_read_on_overflow_raise_aborts_first_overflow(tmp_path: Path):
    # Review finding (Medium): production users with
    # warnings.simplefilter("ignore") upstream would silently lose
    # cells. The new on_overflow="raise" lets unattended pipelines
    # opt into loud failure on the first wider-than-headers row.
    import pytest
    src = tmp_path / "ragged.csv"
    src.write_bytes(
        b"id,name,age\n"
        b"1,alice,30\n"
        b"2,bob,25,extra\n"
        b"3,carol,40\n"
    )

    # Typed exception (DictOverflowError) so callers — including the
    # CLI's strict-mode gate — can catch by class instead of
    # substring-matching the message. Subclasses ValueError so
    # existing handlers still catch it.
    with pytest.raises(dsvmonkey.DictOverflowError) as excinfo:
        list(dsvmonkey.read(src, as_dict=True, on_overflow="raise"))
    assert excinfo.value.row_width == 4
    assert excinfo.value.header_width == 3
    assert isinstance(excinfo.value, ValueError)


def test_read_on_overflow_silent_drops_with_no_warning(
    tmp_path: Path, recwarn,
):
    # Negative pin for the third value of the policy: explicit
    # opt-in to silent drop for callers who know overflow is
    # expected and don't want noise.
    src = tmp_path / "ragged.csv"
    src.write_bytes(
        b"id,name,age\n"
        b"1,alice,30\n"
        b"2,bob,25,extra\n"
        b"3,carol,40\n"
    )

    rows = list(dsvmonkey.read(src, as_dict=True, on_overflow="silent"))
    assert len(rows) == 3
    overflow_warnings = [
        w for w in recwarn.list
        if "overflow cells are dropped" in str(w.message)
    ]
    assert overflow_warnings == []


def test_read_on_overflow_rejects_unknown_policy(tmp_path: Path):
    # Boundary validation at the API: typo'd policy values must
    # surface as a clean ValueError up front, not a confusing
    # comparison-against-string later.
    import pytest
    src = tmp_path / "f.csv"
    src.write_bytes(b"id,name\n1,alice\n")

    with pytest.raises(ValueError, match="on_overflow must be one of"):
        list(dsvmonkey.read(src, on_overflow="explode"))  # type: ignore[arg-type]


def test_read_on_overflow_raise_is_no_op_for_list_mode(tmp_path: Path):
    # as_dict=False preserves every cell, so the overflow concept
    # doesn't apply. The kwarg should be accepted but inert —
    # passing on_overflow="raise" with as_dict=False must NOT
    # raise, since list mode never drops anything.
    src = tmp_path / "ragged.csv"
    src.write_bytes(
        b"id,name,age\n"
        b"1,alice,30\n"
        b"2,bob,25,extra,more\n"
        b"3,carol,40\n"
    )

    rows = list(dsvmonkey.read(src, as_dict=False, on_overflow="raise"))
    # Every cell preserved, including the overflow.
    assert len(rows) == 3
    assert rows[1] == ["2", "bob", "25", "extra", "more"]
