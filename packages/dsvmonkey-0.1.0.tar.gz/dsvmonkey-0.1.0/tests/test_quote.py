import csv

import pytest

from dsvmonkey.detectors.quote import (
    _count_logical_fields,
    detect_quote_char,
)


def test_double_quote_detected_when_fields_are_wrapped():
    sample = (
        'id,name,note\n'
        '1,"alice","admin, full"\n'
        '2,"bob","user"\n'
        '3,"carol","auditor, read-only"\n'
    )
    result = detect_quote_char(sample, delimiter=",")
    assert result.value == '"'
    assert result.method == "field-start-count"
    assert result.confidence >= 0.5


def test_single_quote_detected_when_fields_use_apostrophe_wrapping():
    sample = (
        "id,name,note\n"
        "1,'alice','admin'\n"
        "2,'bob','user'\n"
        "3,'carol','auditor'\n"
    )
    result = detect_quote_char(sample, delimiter=",")
    assert result.value == "'"


def test_returns_none_when_no_quoting_used():
    sample = (
        "id,name,age\n"
        "1,alice,30\n"
        "2,bob,25\n"
        "3,carol,40\n"
    )
    result = detect_quote_char(sample, delimiter=",")
    assert result.value is None
    assert result.method == "absent"


def test_empty_sample_returns_none():
    result = detect_quote_char("", delimiter=",")
    assert result.value is None
    assert result.method == "absent"


def test_mixed_quoting_prefers_the_more_common_quote_char():
    # Mostly double-quoted with a stray single-quoted field — double
    # wins on boundary-hit count.
    sample = (
        'id,name,note\n'
        '1,"alice","admin"\n'
        "2,'bob','user'\n"
        '3,"carol","auditor"\n'
        '4,"dave","viewer"\n'
        '5,"eve","reader"\n'
    )
    result = detect_quote_char(sample, delimiter=",")
    assert result.value == '"'
    # Single quote should show up as a runner-up with hits.
    alt_values = [a.value for a in result.alternatives]
    assert "'" in alt_values


def test_tab_delimited_with_quoted_fields():
    # Quote detection must work with any delimiter, not just commas.
    sample = (
        'id\tname\tnote\n'
        '1\t"alice"\t"admin"\n'
        '2\t"bob"\t"user"\n'
    )
    result = detect_quote_char(sample, delimiter="\t")
    assert result.value == '"'


def test_quoted_fields_with_embedded_delimiter_detected():
    # Review finding: the naive split-and-check-wrapped detector
    # returned None on `1,"Doe, John",admin` because the quoted cell
    # contains the delimiter itself, so `line.split(",")` produced
    # `"Doe` and ` John"` — neither wrapped. The new field-start
    # counter catches the `,"` pattern regardless of where the cell
    # ends.
    sample = (
        'id,name,note\n'
        '1,"Doe, John",admin\n'
        '2,"Smith, Jane",user\n'
        '3,"Roe, Richard",user\n'
        '4,"Brown, Alice",admin\n'
    )
    result = detect_quote_char(sample, delimiter=",")
    assert result.value == '"'
    assert result.method == "field-start-count"


def test_multi_line_quoted_fields_do_not_distort_field_count():
    # Review finding: quote detection used `sample.splitlines()` for
    # the total-fields denominator, so a file with lots of quoted
    # newlines over-counted total fields (each physical line added
    # its own delimiter-count + 1). The confidence ratio dropped even
    # when detection was correct. Counting logical fields via
    # csv.reader fixes this.
    sample = (
        'id,note\n'
        '1,"line one\nline two\nline three"\n'
        '2,"plain"\n'
        '3,"again\nwith\nmany\nlines"\n'
        '4,"last"\n'
    )
    result = detect_quote_char(sample, delimiter=",")
    assert result.value == '"'
    # Four logical rows × 2 fields = 8 total fields. Each row starts
    # with a `,"` before the second cell, so 4 starts. Confidence
    # should be well above the 0.5 floor.
    assert result.confidence >= 0.75


def test_apostrophes_inside_unquoted_fields_do_not_trigger_single_quote():
    # Fields like `don't` contain apostrophes but aren't *wrapped* in
    # them, so the start+end test filters them out.
    sample = (
        "id,name,note\n"
        "1,alice,don't worry\n"
        "2,bob,it's fine\n"
        "3,carol,can't complain\n"
    )
    result = detect_quote_char(sample, delimiter=",")
    assert result.value is None


# Gap 15: detect_quote_char promise — "Returns value=None when no
# evidence of quoting." Pin for a non-empty sample that contains no
# quote characters at all, and probe an adversarial case where quote
# characters appear but not as field starts.

def test_sample_with_no_quote_chars_at_all_returns_none():
    # Gap 15: plain, fully-unquoted CSV. Neither `"` nor `'` appears
    # anywhere in the text, so field-start-count is 0 for every
    # candidate and the detector must report value=None via the
    # "absent" method branch.
    sample = "id,name\n1,alice\n2,bob\n"
    assert '"' not in sample and "'" not in sample
    result = detect_quote_char(sample, delimiter=",")
    assert result.value is None
    assert result.method == "absent"


def test_quote_chars_inside_unquoted_fields_not_at_field_start():
    # Gap 15 adversarial: both `'` and `"` appear as literal content
    # (an apostrophe and an inch mark inside the `desc` column), but
    # neither sits at a field start (i.e. after a delimiter or at the
    # start of a line). A user reading the file would say "this file
    # isn't quoted — those are just characters inside the text." Pin
    # what the code does so a future regression is caught.
    sample = (
        "id,desc\n"
        "1,5'3\" tall\n"
        "2,6'0\" also tall\n"
    )
    result = detect_quote_char(sample, delimiter=",")
    # Neither candidate sits at a field start, so detector reports
    # "absent" — matching user expectation.
    assert result.value is None
    assert result.method == "absent"


# ---------- Apostrophe-in-data must NOT be detected as quote char ----------


def test_leading_apostrophes_in_prose_do_not_detect_as_quote():
    # Review finding (High): raw start-count scoring treated leading
    # apostrophes in prose ('twas, 'alice) as quote opens. csv.reader
    # with quote="'" would then keep reading physical lines until an
    # unmatched ' appeared — row-count collapse and structural
    # corruption, not a confidence issue. The balance check (opens
    # should match closes) now catches this: apostrophe-in-data has
    # many opens, few closes.
    sample = (
        "name,note\n"
        "'alice,ok\n"
        "bob,'fine\n"
        "carol,ok\n"
        "dave,'fine\n"
        "eve,ok\n"
    )
    result = detect_quote_char(sample, delimiter=",")
    # Must NOT pick ' as the quote char.
    assert result.value != "'"
    # Returns absent with a diagnostic warning so the user can see why.
    assert result.value is None
    assert any(
        "merges rows" in w or "treating as data" in w
        for w in result.warnings
    )


def test_balanced_single_quote_quoting_still_detected():
    # Negative case: a file that legitimately uses single-quote
    # quoting (opens matched by closes, no stray apostrophes) must
    # still be detected. The balance check allows legitimate '-quoting
    # to pass.
    sample = (
        "id,note\n"
        "1,'quoted value'\n"
        "2,'another, with comma'\n"
        "3,'third'\n"
        "4,'fourth'\n"
    )
    result = detect_quote_char(sample, delimiter=",")
    assert result.value == "'"


def test_multiline_double_quote_still_detected_after_balance_check():
    # Regression guard: the balance check must not reject legitimate
    # multi-line quoted fields where an open on one physical line is
    # matched by a close on a later physical line.
    sample = (
        'id,note\n'
        '1,"line one\nline two\nline three"\n'
        '2,"plain"\n'
        '3,"again\nwith\nmany\nlines"\n'
        '4,"last"\n'
    )
    result = detect_quote_char(sample, delimiter=",")
    assert result.value == '"'


def test_apostrophe_in_data_does_not_corrupt_row_boundaries_via_read(tmp_path):
    # End-to-end: the real-world consequence of the bug was that
    # read()/repair() would merge rows when quote detection picked
    # apostrophes. Pin the full-stack invariant: a notes-style file
    # with leading apostrophes yields the correct number of rows.
    import dsvmonkey
    from pathlib import Path as _Path

    path = _Path(tmp_path) / "apostrophes.csv"
    path.write_bytes(
        "id,note\n"
        "1,'alice reported ok\n"
        "2,bob confirmed\n"
        "3,'carol noted an issue\n"
        "4,final entry\n".encode("utf-8")
    )

    rows = list(dsvmonkey.read(path, as_dict=False, clean=False))
    # Four data rows — no catastrophic merging into one quoted blob.
    assert len(rows) == 4
    assert rows[0][0] == "1"
    assert rows[3][0] == "4"


def test_quote_detected_after_long_preamble():
    # Review finding (High): the default 30-physical-line cap meant
    # files with metadata preambles longer than that lost their
    # quoted data — quote detection saw only preamble lines (no
    # quotes), returned "absent", and downstream parsing split
    # embedded delimiters into extra fields. Default is now 1000
    # lines so realistic preambles don't defeat detection.
    preamble = "META: line {}\n"
    sample = "".join(preamble.format(i) for i in range(50))  # 50 preamble lines
    sample += 'id,note\n'
    sample += '1,"alice, jones"\n'
    sample += '2,"bob, smith"\n'
    sample += '3,"carol, doe"\n'

    result = detect_quote_char(sample, delimiter=",")
    # Without the wider window, this would return None and the
    # embedded commas inside the quoted "alice, jones" would split
    # into extra fields downstream.
    assert result.value == '"'


def test_quote_detected_after_very_long_preamble_via_explicit_max_lines():
    # If a caller knows their preambles can exceed the 1000-line
    # default, they can crank max_lines higher. Pin the contract.
    preamble = "META\n" * 1500
    sample = preamble + 'id,note\n1,"alice, jones"\n2,"bob, smith"\n'
    # Default cap (1000) doesn't see the data.
    default = detect_quote_char(sample, delimiter=",")
    assert default.value is None
    # Wider cap does.
    wide = detect_quote_char(sample, delimiter=",", max_lines=2000)
    assert wide.value == '"'


def test_max_lines_threaded_to_denominator():
    # Review finding: `_count_logical_fields` was called with a
    # hardcoded _DEFAULT_MAX_LOGICAL_ROWS (30) regardless of the
    # caller's `max_lines`. Numerator (field-start counts) scaled
    # with max_lines; denominator did not — confidence became
    # unexplainable and tuning became unpredictable. The two now
    # share the same cap.
    #
    # Fixture: 15 quoted rows followed by 24 unquoted, with
    # max_lines=40 so the cap is well above the old hardcoded 30.
    # starts = 15 quoted rows × 2 starts-per-row = 30.
    # Under the bug: denominator capped at 30 rows × 2 fields = 60,
    #   confidence = min(30 / (60 * 0.5), 1.0) = 1.0 (capped).
    # After the fix: denominator = 40 rows × 2 = 80,
    #   confidence = min(30 / (80 * 0.5), 1.0) = 0.75.
    # Both above the 0.5 floor so the change is visible.
    sample = "id,name\n" + '"1","alice"\n' * 15 + "bob,carol\n" * 24
    result = detect_quote_char(sample, delimiter=",", max_lines=40)
    assert result.value == '"'
    assert result.confidence == pytest.approx(0.75)


# Gap 16: _count_logical_fields fallback when csv.reader fails.

def test_count_logical_fields_on_csv_error_returns_zero_without_raising():
    # Gap 16: craft text that triggers csv.Error by exceeding the
    # field size limit. The function MUST NOT propagate the exception;
    # it catches csv.Error and returns 0 so the caller (detect_quote_char)
    # can switch to its physical-line fallback.
    #
    # NOTE: the task prompt describes the fallback as returning ">0",
    # but reading quote.py lines 60-63 shows the physical-line fallback
    # lives in detect_quote_char, not in _count_logical_fields. The
    # helper itself returns 0 on csv.Error. We pin the actual contract.
    original_limit = csv.field_size_limit()
    try:
        csv.field_size_limit(50)
        # A single 200-char unquoted field blows past the 50-byte limit
        # mid-parse and makes csv.reader raise csv.Error.
        huge_field = "x" * 200
        text = huge_field + "\nother,row\n"
        # Sanity check: our setup really does raise csv.Error when
        # driven through csv.reader directly.
        import io
        with pytest.raises(csv.Error):
            list(csv.reader(io.StringIO(text)))
        # Now exercise the except branch deliberately.
        result = _count_logical_fields(text, ",", 30)
    finally:
        csv.field_size_limit(original_limit)
    assert result == 0


def test_count_logical_fields_parses_successfully_when_no_error():
    # Gap 16: also exercise the success branch so the csv.Error test
    # above is seen to be a deliberate divergence, not an accident of
    # csv.reader tolerating every input. A multi-row CSV parses cleanly
    # and returns rows*cols logical fields.
    text = "a,b,c\n1,2,3\n4,5,6\n"
    assert _count_logical_fields(text, ",", 30) == 9


def test_count_logical_fields_empty_text_returns_zero():
    # Gap 16: empty input yields no rows from csv.reader, so the total
    # remains 0. Pin the behaviour — callers rely on the 0 signal to
    # trigger the physical-line fallback inside detect_quote_char.
    assert _count_logical_fields("", ",", 30) == 0


def test_count_logical_fields_only_blank_lines_returns_zero():
    # Gap 16: csv.reader yields empty-list rows for blank lines, and
    # the `if row:` guard skips them. Three blank lines therefore
    # contribute 0 fields — consistent with the fallback definition
    # ("no real content to count").
    assert _count_logical_fields("\n\n\n", ",", 30) == 0


def test_detect_quote_char_uses_physical_line_fallback_when_csv_reader_fails():
    # Gap 16: the *real* contract the task cares about — when
    # csv.reader fails, detection still runs. The physical-line
    # fallback lives in detect_quote_char (lines 60-63). With a
    # tiny field_size_limit we force _count_logical_fields to return 0,
    # then confirm detect_quote_char still returns a sensible result
    # (and does not divide-by-zero or raise). The sample has clearly
    # quoted fields so the detector should still pick `"`.
    original_limit = csv.field_size_limit()
    try:
        # Small enough to trip on any realistic unquoted row, but big
        # enough that the sample below can still be walked physically.
        csv.field_size_limit(20)
        sample = (
            'id,name\n'
            '1,"' + ("a" * 40) + '"\n'
            '2,"' + ("b" * 40) + '"\n'
            '3,"' + ("c" * 40) + '"\n'
        )
        result = detect_quote_char(sample, delimiter=",")
    finally:
        csv.field_size_limit(original_limit)
    # Detection survives and still identifies double-quote.
    assert result.value == '"'
    assert result.confidence >= 0.5
