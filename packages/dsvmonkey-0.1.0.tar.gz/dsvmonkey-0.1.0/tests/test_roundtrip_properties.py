"""Property-based round-trip and consistency tests.

Handwritten tests pin known contracts at known inputs. These tests
ask hypothesis to find inputs we didn't think of. Two properties are
probed:

1. repair() round-trips: whatever valid DSV we generate, repair() +
   re-read must give the same rows. This catches encoding / quoting /
   delimiter-escape asymmetries that only show up on input the test
   author wouldn't have typed.

2. read() and repair() agree: the rows read() yields must match the
   rows repair() writes (minus header). If the two APIs ever drift —
   the class of bug we just fixed for UTF-16 BOMs — hypothesis will
   find it faster than a handwritten test.

No custom shrinking or stateful machines — just `@given` with
structured strategies over the axes that actually matter: delimiter
choice, quoting needs, cell content, ragged widths.
"""

from __future__ import annotations

import csv
import io
import os
from pathlib import Path

import pytest

# Property tests require hypothesis. Default: skip the whole module
# gracefully when it isn't installed so plain `pytest` (without
# `.[dev]` extras) doesn't fail at collection.
#
# CI / release-gate mode: set `DSVMONKEY_REQUIRE_HYPOTHESIS=1` to
# escalate the missing-hypothesis case into a hard collection failure.
# Without this knob, a CI run with the dev extras accidentally
# uninstalled silently drops the entire generative-test suite — the
# operator sees "all green" while the highest-signal property checks
# never executed. Loud failure beats silent coverage loss.
#
# We try a real functional import (the `strategies` submodule) rather
# than just `pytest.importorskip("hypothesis")` because a namespace-
# package fragment can satisfy the top-level import while having no
# actual implementation — and then the `from hypothesis import ...`
# below would fail at collection time with an ImportError instead of
# a clean skip.
try:
    from hypothesis import HealthCheck, given, settings
    from hypothesis import strategies as st
except ImportError:
    if os.environ.get("DSVMONKEY_REQUIRE_HYPOTHESIS") == "1":
        raise
    pytest.skip(
        "hypothesis not available; install with `pip install -e .[dev]` "
        "to run property tests "
        "(set DSVMONKEY_REQUIRE_HYPOTHESIS=1 to fail instead of skip)",
        allow_module_level=True,
    )

import dsvmonkey  # noqa: E402


# Cell text: printable ASCII plus a few troublesome unicode points
# (NBSP, ZWSP, smart quote). We exclude control chars and the
# delimiter/quote/newline chars, which are handled separately through
# proper CSV quoting rather than by hoping they never appear.
_CELL_CHARS = st.sampled_from(
    list("abcdefghijklmnopqrstuvwxyz0123456789 ._-/:@#")
)


@st.composite
def cell(draw):
    # 0..20 chars. Empty cells are explicitly allowed — they're the
    # boundary case that separates "missing column" from "column with
    # no value" in most downstream consumers.
    size = draw(st.integers(min_value=0, max_value=20))
    return "".join(draw(_CELL_CHARS) for _ in range(size))


@st.composite
def row(draw, width):
    return [draw(cell()) for _ in range(width)]


def _row_is_substantive(r: list[str]) -> bool:
    # repair() and read() both skip whitespace-only rows by design
    # (documented contract: blank lines are dropped). Exclude them
    # from the round-trip strategy so the property under test isn't
    # "empty rows survive" (they shouldn't).
    return any(cell.strip() for cell in r)


@st.composite
def table(draw):
    width = draw(st.integers(min_value=1, max_value=6))
    n_data_rows = draw(st.integers(min_value=1, max_value=20))
    # Header is always `h0..hN-1` — simple, unique, guaranteed to
    # score as a header so detection doesn't wobble on tiny samples.
    header = [f"h{i}" for i in range(width)]
    data = []
    for _ in range(n_data_rows):
        r = draw(row(width))
        if _row_is_substantive(r):
            data.append(r)
    # After filtering we might have zero data rows — retry via
    # hypothesis's assume mechanism rather than draining the strategy.
    from hypothesis import assume

    assume(data)
    return header, data


def _write_csv(path: Path, header: list[str], data: list[list[str]]) -> None:
    # Use stdlib csv.writer so the fixture writer itself is known-
    # correct. Hand-rolling CSV escaping is exactly the trap the
    # philosophy paragraph warns about.
    with path.open("w", encoding="utf-8", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(header)
        w.writerows(data)


def _profile_with_forced_header(src: Path, width: int) -> dsvmonkey.DSVProfile:
    # Hypothesis can generate tables where header detection is
    # genuinely ambiguous (e.g. mostly-empty data rows where a later
    # row scores higher than the real header — a real limitation of
    # the detector that's tested separately in test_header.py).
    # These round-trip properties are about repair/read preserving
    # DATA given a correct profile, not about detector robustness,
    # so we pin the profile's header/width explicitly.
    profile = dsvmonkey.profile_file(src)
    profile.header_row.value = 0
    profile.field_count = width
    return profile


@given(table())
@settings(
    max_examples=75,
    suppress_health_check=[HealthCheck.function_scoped_fixture],
    deadline=None,
)
def test_repair_roundtrips_to_same_rows(tmp_path_factory, data):
    # Hypothesis feeds randomly generated (header, rows) into write +
    # repair + re-parse. Property: repair() does not lose or mangle
    # any row of valid UTF-8 CSV when the profile is accurate.
    header, rows = data
    tmp = tmp_path_factory.mktemp("rt")
    src = tmp / "src.csv"
    dst = tmp / "dst.csv"
    _write_csv(src, header, rows)

    profile = _profile_with_forced_header(src, len(header))

    # clean_cells=False to keep the round-trip bit-exact — cleanmonkey
    # is allowed to normalise content on its own tests, but here we
    # want to isolate repair()'s own behaviour.
    dsvmonkey.repair(src, dst, profile=profile, clean_cells=False)

    with dst.open(encoding="utf-8", newline="") as fh:
        parsed = list(csv.reader(fh))

    # First row is the header, rest are data. repair() must preserve
    # every cell of every row.
    assert parsed[0] == header
    assert parsed[1:] == rows


@given(table())
@settings(
    max_examples=75,
    suppress_health_check=[HealthCheck.function_scoped_fixture],
    deadline=None,
)
def test_read_and_repair_agree(tmp_path_factory, data):
    # Cross-API consistency: given the same profile, read() and
    # repair() must see the same data. If one silently drops/pads/
    # mangles a row that the other preserves, the two APIs are lying
    # to their callers about what's in the file.
    header, rows = data
    tmp = tmp_path_factory.mktemp("cc")
    src = tmp / "src.csv"
    dst = tmp / "dst.csv"
    _write_csv(src, header, rows)

    profile = _profile_with_forced_header(src, len(header))

    read_rows = list(
        dsvmonkey.read(src, profile=profile, as_dict=False, clean=False)
    )
    dsvmonkey.repair(src, dst, profile=profile, clean_cells=False)
    with dst.open(encoding="utf-8", newline="") as fh:
        repair_rows = list(csv.reader(fh))

    assert repair_rows[0] == header
    assert repair_rows[1:] == read_rows


# ---------- Fuzz: profile_bytes must never raise ----------


@given(st.binary(min_size=0, max_size=4096))
@settings(max_examples=200, deadline=None)
def test_profile_bytes_never_raises_on_arbitrary_bytes(data):
    # Contract from the docstring of profile_bytes: "Run the full
    # detection pipeline against `data`." No input validation, no
    # error-raising clause. Hypothesis hammers random bytes at it;
    # any uncaught exception is a bug.
    result = dsvmonkey.profile_bytes(data)
    # Result must be a DSVProfile — not a partial object, not None.
    assert isinstance(result, dsvmonkey.DSVProfile)
    # Core invariant: encoding detection always populates *something*.
    assert result.encoding is not None
    assert 0.0 <= result.encoding.confidence <= 1.0


# ---------- Smoke: stdlib csv can read what repair writes ----------


@given(table())
@settings(
    max_examples=50,
    suppress_health_check=[HealthCheck.function_scoped_fixture],
    deadline=None,
)
def test_repair_output_parses_under_strict_stdlib_csv(tmp_path_factory, data):
    # The hard contract: whatever repair() produces must be parseable
    # by the stdlib csv reader with default settings. If repair() ever
    # writes output that only dsvmonkey can re-read, it has become a
    # quoting-format island.
    header, rows = data
    tmp = tmp_path_factory.mktemp("strict")
    src = tmp / "src.csv"
    dst = tmp / "dst.csv"
    _write_csv(src, header, rows)
    profile = _profile_with_forced_header(src, len(header))
    dsvmonkey.repair(src, dst, profile=profile, clean_cells=False)

    text = dst.read_text(encoding="utf-8")
    parsed = list(csv.reader(io.StringIO(text)))
    # Width consistency: every row has the expected width.
    expected_width = len(header)
    for r in parsed:
        assert len(r) == expected_width
