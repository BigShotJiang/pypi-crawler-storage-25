"""CLI tests.

We invoke `main()` directly with an argv list rather than spawning a
subprocess — faster, no shell quoting, and stdout is captured via
pytest's `capsys`.
"""

import csv
import json
from pathlib import Path

import pytest

from dsvmonkey.cli import main


# ---------- inspect ----------


def test_inspect_prints_report(tmp_path: Path, capsys):
    src = tmp_path / "f.csv"
    src.write_bytes(b"id,name,age\n1,alice,30\n2,bob,25\n")

    exit_code = main(["inspect", str(src)])
    out = capsys.readouterr().out

    assert exit_code == 0
    assert "dsvmonkey inspect report" in out
    assert "Encoding:" in out
    assert "utf-8" in out
    assert "Delimiter:" in out
    assert "Header row:" in out
    assert "id, name, age" in out


def test_inspect_verbose_includes_alternatives(tmp_path: Path, capsys):
    src = tmp_path / "f.csv"
    src.write_bytes(b"id,name,age\n1,alice,30\n2,bob,25\n3,carol,40\n")

    main(["inspect", "-v", str(src)])
    out = capsys.readouterr().out
    assert "Alternatives:" in out


def test_inspect_missing_file_returns_error(tmp_path: Path, capsys):
    exit_code = main(["inspect", str(tmp_path / "nope.csv")])
    err = capsys.readouterr().err
    assert exit_code == 2
    assert "not found" in err


def test_inspect_tab_delimiter_rendered_readably(tmp_path: Path, capsys):
    src = tmp_path / "f.tsv"
    src.write_bytes(b"id\tname\n1\talice\n2\tbob\n")

    main(["inspect", str(src)])
    out = capsys.readouterr().out
    assert "\\t (tab)" in out


# ---------- normalize ----------


def test_normalize_strips_bom_and_normalizes_endings(tmp_path: Path, capsys):
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes("﻿id,name\r\n1,alice\r\n2,bob\r\n".encode("utf-8"))

    exit_code = main(["normalize", str(src), "-o", str(dst)])
    out = capsys.readouterr().out

    assert exit_code == 0
    assert dst.exists()
    assert "BOM stripped" in out
    assert "line endings normalized" in out

    out_bytes = dst.read_bytes()
    assert not out_bytes.startswith(b"\xef\xbb\xbf")
    assert b"\r\n" not in out_bytes


def test_normalize_with_crlf_line_ending(tmp_path: Path):
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name\n1,alice\n2,bob\n")

    main(["normalize", str(src), "-o", str(dst), "--line-ending", "crlf"])
    assert dst.read_bytes().count(b"\r\n") == 3


def test_normalize_multi_char_delimiter_fails_cleanly(tmp_path: Path, capsys):
    # Review finding: csv.writer requires a 1-character delimiter.
    # Without CLI validation, passing "||" used to surface as an
    # uncaught TypeError traceback rather than a friendly error.
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name\n1,alice\n")

    exit_code = main(
        ["normalize", str(src), "-o", str(dst), "--delimiter", "||"]
    )
    err = capsys.readouterr().err
    assert exit_code == 2
    assert "single character" in err
    # Failed validation must not leave a partial output file behind.
    assert not dst.exists()


def test_normalize_negative_field_count_fails_cleanly(tmp_path: Path, capsys):
    # Review finding: _fit_row(row, -2) slices as row[:-2] and
    # silently drops cells. CLI now rejects negative/zero values
    # up front with a clear error.
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name\n1,alice\n")

    exit_code = main(
        ["normalize", str(src), "-o", str(dst), "--field-count", "-2"]
    )
    err = capsys.readouterr().err
    assert exit_code == 2
    assert "positive integer" in err
    assert not dst.exists()


def test_normalize_zero_field_count_fails_cleanly(tmp_path: Path, capsys):
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name\n1,alice\n")

    exit_code = main(
        ["normalize", str(src), "-o", str(dst), "--field-count", "0"]
    )
    err = capsys.readouterr().err
    assert exit_code == 2
    assert "positive integer" in err


def test_inspect_negative_sample_rows_fails_cleanly(tmp_path: Path, capsys):
    # Review finding: argparse accepts `-1` via type=int, then
    # profile_columns breaks out of the sampling loop on the first
    # iteration because count >= -1 is always True. Columns were
    # reported with zero samples — silently misleading. The CLI now
    # rejects non-positive values up front.
    src = tmp_path / "f.csv"
    src.write_bytes(b"id,name\n1,alice\n2,bob\n")

    exit_code = main(["inspect", str(src), "--sample-rows", "-1"])
    err = capsys.readouterr().err
    assert exit_code == 2
    assert "positive integer" in err


def test_inspect_zero_sample_rows_fails_cleanly(tmp_path: Path, capsys):
    src = tmp_path / "f.csv"
    src.write_bytes(b"id,name\n1,alice\n2,bob\n")

    exit_code = main(["inspect", str(src), "--sample-rows", "0"])
    err = capsys.readouterr().err
    assert exit_code == 2
    assert "positive integer" in err


def test_normalize_sanitize_formulas_flag_neutralizes_output(
    tmp_path: Path, capsys
):
    # Review finding: repair() supported sanitize_formulas but the
    # CLI didn't expose it — CLI-only users couldn't activate the
    # defense without writing Python. Now `--sanitize-formulas` on
    # both `normalize` and `convert` plumbs through.
    src = tmp_path / "evil.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"name,formula\nalice,=SUM(A:A)\n")

    rc = main([
        "normalize", str(src), "-o", str(dst), "--sanitize-formulas",
    ])
    assert rc == 0
    out_text = dst.read_text()
    assert "'=SUM(A:A)" in out_text


def test_normalize_sanitize_formulas_off_by_default(tmp_path: Path):
    # Without the flag, behaviour is unchanged.
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"name,formula\nalice,=SUM(A:A)\n")
    rc = main(["normalize", str(src), "-o", str(dst)])
    assert rc == 0
    assert "'=SUM(A:A)" not in dst.read_text()
    assert "=SUM(A:A)" in dst.read_text()


def test_convert_jsonl_sanitize_formulas_actually_sanitizes(
    tmp_path: Path, capsys
):
    # Review finding (#7): JSONL consumers don't evaluate formulas
    # themselves, but JSONL output is commonly transformed back to
    # CSV/Excel downstream — and at that point any `=SUM(A:A)*cmd|`
    # surviving as a JSON string value becomes a live formula.
    # Previously the CLI warned-and-ignored the flag for JSONL,
    # leaving a security-expectation gap. Now `--sanitize-formulas`
    # actually applies on the JSONL path too.
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.jsonl"
    src.write_bytes(b"name,formula\nalice,=SUM(A:A)\n")

    rc = main([
        "convert", str(src), "-o", str(dst),
        "--to", "jsonl", "--sanitize-formulas",
    ])
    assert rc == 0
    # Sanitised content reaches the JSONL output: trigger char
    # is prefixed with ' so a downstream spreadsheet import
    # treats it as literal text.
    text = dst.read_text()
    assert "'=SUM(A:A)" in text
    assert "\"=SUM(A:A)\"" not in text  # no raw formula


def test_convert_jsonl_without_sanitize_preserves_raw_content(
    tmp_path: Path, capsys
):
    # Default (no flag) preserves content unchanged — strict-JSON
    # consumers (jq, structured loggers) want byte-for-byte cell
    # values and shouldn't see the `'` prefix.
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.jsonl"
    src.write_bytes(b"name,formula\nalice,=SUM(A:A)\n")
    main(["convert", str(src), "-o", str(dst), "--to", "jsonl"])
    text = dst.read_text()
    assert "=SUM(A:A)" in text
    assert "'=SUM(A:A)" not in text


def test_convert_sanitize_formulas_flag(tmp_path: Path):
    src = tmp_path / "evil.csv"
    dst = tmp_path / "out.tsv"
    src.write_bytes(b"name,formula\nalice,=SUM(A:A)\n")
    rc = main([
        "convert", str(src), "-o", str(dst), "--to", "tsv",
        "--sanitize-formulas",
    ])
    assert rc == 0
    assert "'=SUM(A:A)" in dst.read_text()


def test_normalize_keep_empty_rows_flag(tmp_path: Path):
    # Companion flag: --keep-empty-rows preserves blank rows in the
    # output instead of dropping them. Pin the CLI plumb-through.
    src = tmp_path / "ws.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name\n1,alice\n   ,   \n2,bob\n")

    rc = main(["normalize", str(src), "-o", str(dst), "--keep-empty-rows"])
    assert rc == 0
    # Dst should have header + 3 rows (1 alice, blank, 2 bob).
    out_text = dst.read_text()
    assert out_text.count("\n") == 4


def test_convert_jsonl_keep_empty_rows_flag_preserves_blanks(tmp_path: Path):
    # Review finding (High): `convert --to jsonl --keep-empty-rows`
    # previously dropped blanks despite the flag. The flag now
    # plumbs through via to_jsonl(skip_empty_rows=...).
    src = tmp_path / "ws.csv"
    dst = tmp_path / "out.jsonl"
    src.write_bytes(b"id,name\n1,alice\n   ,   \n2,bob\n")

    rc = main([
        "convert", str(src), "-o", str(dst), "--to", "jsonl",
        "--keep-empty-rows",
    ])
    assert rc == 0
    lines = [line for line in dst.read_text().splitlines() if line]
    # 3 rows now, not 2.
    assert len(lines) == 3


def test_convert_jsonl_without_flag_drops_blanks(tmp_path: Path):
    # Negative case: default convert --to jsonl still drops blanks.
    src = tmp_path / "ws.csv"
    dst = tmp_path / "out.jsonl"
    src.write_bytes(b"id,name\n1,alice\n   ,   \n2,bob\n")
    rc = main(["convert", str(src), "-o", str(dst), "--to", "jsonl"])
    assert rc == 0
    lines = [line for line in dst.read_text().splitlines() if line]
    assert len(lines) == 2


def test_inspect_surfaces_review_recommended_on_low_confidence_file(
    tmp_path: Path, capsys
):
    # Detection from bytes has fundamental limits. When the
    # library can't be confident, the CLI inspect report
    # surfaces a "Review recommended" block so an operator
    # scanning the output sees the recommendation prominently
    # — not buried in `profile.issues` text alone.
    src = tmp_path / "ambiguous.csv"
    # File with no auto-detectable delimiter — single-line,
    # no candidates produce multi-field rows, lands in low-
    # confidence single-column verdict.
    src.write_bytes(b"single text row no delimiter at all here\n")

    rc = main(["inspect", str(src)])
    out = capsys.readouterr().out

    assert rc == 0
    assert "Review recommended" in out
    assert "Visually inspect" in out
    # The reasons block is enumerated.
    assert "delimiter confidence" in out


def test_inspect_omits_review_block_on_confident_file(
    tmp_path: Path, capsys
):
    # Negative case: confidently-detected file produces no
    # "Review recommended" output. The block must not false-
    # positive on healthy input.
    src = tmp_path / "clean.csv"
    src.write_bytes(b"id,name,age\n1,alice,30\n2,bob,25\n3,carol,40\n")

    main(["inspect", str(src)])
    out = capsys.readouterr().out

    assert "Review recommended" not in out


def test_inspect_renders_all_single_column_sentinel_variants(tmp_path: Path, capsys):
    # Review finding (#3): the CLI special-cased only \x1f, but
    # the dynamic sentinel picker can choose \x1e, \x1d, or \x1c
    # when \x1f collides with the sample. Without all four
    # variants recognised, those fallback sentinels rendered as
    # raw control chars in the inspect report — operator-hostile.
    src = tmp_path / "ambiguous.csv"
    # Sample contains \x1f so the picker falls back to \x1e.
    content = (b"line one\x1f with default sentinel\n"
               b"line two without\n"
               b"line three\n")
    src.write_bytes(content)

    rc = main(["inspect", "--no-columns", str(src)])
    out = capsys.readouterr().out
    assert rc == 0
    # Whatever sentinel was picked, the CLI should render it as
    # the friendly string rather than a raw control char.
    assert "(none — single column)" in out
    # And no raw control char leaks into the rendered line.
    assert "'\\x1e'" not in out
    assert "'\\x1d'" not in out
    assert "'\\x1c'" not in out


def test_inspect_strict_exits_three_when_review_recommended(
    tmp_path: Path, capsys
):
    # `--strict` is the shell/CI gate: exit code 3 means "this
    # file's detection wasn't confident enough — queue for review."
    # Lets unattended pipelines branch without parsing stdout:
    #     dsvmonkey inspect --strict file.csv || queue_for_review
    src = tmp_path / "ambiguous.csv"
    src.write_bytes(b"single text row no delimiter at all here\n")

    rc = main(["inspect", "--strict", str(src)])
    out = capsys.readouterr().out
    assert rc == 3
    # The Review-recommended block is still printed — the exit
    # code is the machine-readable signal, the block is the
    # human-readable one.
    assert "Review recommended" in out


def test_inspect_strict_exits_zero_on_clean_file(tmp_path: Path, capsys):
    # Negative: a confidently-detected file passes --strict with
    # the normal exit 0. The gate must not false-positive on
    # healthy input.
    src = tmp_path / "clean.csv"
    src.write_bytes(b"id,name,age\n1,alice,30\n2,bob,25\n3,carol,40\n")

    rc = main(["inspect", "--strict", str(src)])
    out = capsys.readouterr().out
    assert rc == 0
    assert "Review recommended" not in out


def test_inspect_without_strict_always_exits_zero_even_on_uncertain_file(
    tmp_path: Path, capsys
):
    # Backwards-compat: the default behaviour is unchanged. Without
    # `--strict`, inspect still exits 0 regardless of needs_review,
    # so existing callers / scripts aren't broken by the new gate.
    src = tmp_path / "ambiguous.csv"
    src.write_bytes(b"single text row no delimiter at all here\n")

    rc = main(["inspect", str(src)])
    out = capsys.readouterr().out
    assert rc == 0
    # The advisory block is still shown; the exit code just
    # doesn't promote it to a hard failure.
    assert "Review recommended" in out


def test_cli_csv_error_caught_and_returns_exit_code_two(
    tmp_path: Path, capsys, monkeypatch
):
    # Review finding (#1): main()'s exception handler chain
    # didn't include csv.Error, so a deep parse failure bubbled
    # as a Python traceback. Automation wrappers expecting a
    # stable exit-code contract got broken output.
    #
    # Patch the body-row iterator (not csv.reader globally —
    # that would also derail profile_file's own sample parser
    # via the shared csv module reference). Replacing
    # `_make_row_iterator` lets profiling complete normally and
    # the failure happen during the actual body read, where a
    # real csv.Error would surface.
    import csv as _csv
    import importlib

    repair_mod = importlib.import_module("dsvmonkey.repair")

    src = tmp_path / "f.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name\n1,alice\n")

    def exploding_iterator(fh, profile):
        # Yield the header row (so skip_rows succeeds) then
        # raise on the next call.
        yield ["id", "name"]
        raise _csv.Error("simulated parse failure")

    # Patch the reference repair.py imported at module load —
    # patching reader.py wouldn't affect the binding repair.py
    # already captured into its own namespace.
    monkeypatch.setattr(repair_mod, "_make_row_iterator", exploding_iterator)

    rc = main(["normalize", str(src), "-o", str(dst)])
    err = capsys.readouterr().err
    assert rc == 2
    assert "CSV parse failure" in err
    assert "simulated parse failure" in err


def test_normalize_strict_refuses_ambiguous_file(
    tmp_path: Path, capsys
):
    # Review finding (#2): inspect --strict was the only gate;
    # normalize and convert ran the full pipeline regardless of
    # needs_review, leaving an ops gap for unattended scripts.
    # `normalize --strict` now profiles first and bails with
    # exit 3 + no output when detection is uncertain.
    src = tmp_path / "ambiguous.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"single text row no delimiter at all here\n")

    rc = main(["normalize", str(src), "-o", str(dst), "--strict"])
    err = capsys.readouterr().err
    assert rc == 3
    assert "requires review" in err
    # No output written — the gate fires BEFORE repair() runs.
    assert not dst.exists()


def test_normalize_without_strict_processes_anyway(tmp_path: Path):
    # Negative case: default behaviour unchanged. Without
    # --strict, normalize processes ambiguous files (the user
    # opted out of the gate).
    src = tmp_path / "ambiguous.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"single text row no delimiter at all here\n")

    rc = main(["normalize", str(src), "-o", str(dst)])
    assert rc == 0
    assert dst.exists()


def test_convert_strict_refuses_ambiguous_file(
    tmp_path: Path, capsys
):
    # Same gate semantics on the convert path.
    src = tmp_path / "ambiguous.csv"
    dst = tmp_path / "out.jsonl"
    src.write_bytes(b"single text row no delimiter at all here\n")

    rc = main([
        "convert", str(src), "-o", str(dst),
        "--to", "jsonl", "--strict",
    ])
    err = capsys.readouterr().err
    assert rc == 3
    assert "requires review" in err
    assert not dst.exists()


def test_normalize_strict_passes_clean_file(tmp_path: Path, capsys):
    # Negative case: a confidently-detected file passes
    # --strict and produces normal output.
    src = tmp_path / "clean.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name,age\n1,alice,30\n2,bob,25\n3,carol,40\n")

    rc = main(["normalize", str(src), "-o", str(dst), "--strict"])
    assert rc == 0
    assert dst.exists()


def test_normalize_strict_profiles_file_only_once(
    tmp_path: Path, monkeypatch
):
    # Review finding: the previous --strict gate profiled the file,
    # discarded the result, then let repair() profile it again from
    # scratch. Two practical problems:
    #   1. TOCTOU — file (or its mtime / mid-write tail) could
    #      change between the two reads, so the dialect the gate
    #      approved might not be the dialect repair() actually used.
    #   2. Wasted I/O — every --strict run paid double the
    #      sampling cost.
    # The fix threads the gate's profile into repair() via
    # `profile=`. Pin the contract: with --strict, profile_file
    # runs exactly once across the whole CLI invocation.
    src = tmp_path / "clean.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name,age\n1,alice,30\n2,bob,25\n3,carol,40\n")

    import importlib
    cli_mod = importlib.import_module("dsvmonkey.cli")
    repair_mod = importlib.import_module("dsvmonkey.repair")
    orch_mod = importlib.import_module("dsvmonkey.orchestrate")

    calls = {"cli": 0, "repair": 0}
    real = orch_mod.profile_file

    def counting_cli(*args, **kwargs):
        calls["cli"] += 1
        return real(*args, **kwargs)

    def counting_repair(*args, **kwargs):
        calls["repair"] += 1
        return real(*args, **kwargs)

    monkeypatch.setattr(cli_mod, "profile_file", counting_cli)
    monkeypatch.setattr(repair_mod, "profile_file", counting_repair)

    rc = main(["normalize", str(src), "-o", str(dst), "--strict"])
    assert rc == 0
    # Gate profiled once; repair() received the gate's profile via
    # `profile=` and skipped its own profiling pass. Total: 1.
    assert calls["cli"] == 1, (
        f"expected exactly 1 cli profile_file call, got {calls['cli']}"
    )
    assert calls["repair"] == 0, (
        f"expected repair() to skip its own profile_file call when "
        f"the gate threaded one in, got {calls['repair']}"
    )


def test_convert_jsonl_strict_profiles_file_only_once(
    tmp_path: Path, monkeypatch
):
    # Same single-profile contract on the convert --to jsonl path.
    src = tmp_path / "clean.csv"
    dst = tmp_path / "out.jsonl"
    src.write_bytes(b"id,name,age\n1,alice,30\n2,bob,25\n3,carol,40\n")

    import importlib
    cli_mod = importlib.import_module("dsvmonkey.cli")
    convert_mod = importlib.import_module("dsvmonkey.convert")
    orch_mod = importlib.import_module("dsvmonkey.orchestrate")

    calls = {"cli": 0, "convert": 0}
    real = orch_mod.profile_file

    def counting_cli(*args, **kwargs):
        calls["cli"] += 1
        return real(*args, **kwargs)

    def counting_convert(*args, **kwargs):
        calls["convert"] += 1
        return real(*args, **kwargs)

    monkeypatch.setattr(cli_mod, "profile_file", counting_cli)
    monkeypatch.setattr(convert_mod, "profile_file", counting_convert)

    rc = main([
        "convert", str(src), "-o", str(dst),
        "--to", "jsonl", "--strict",
    ])
    assert rc == 0
    assert calls["cli"] == 1
    assert calls["convert"] == 0


def test_convert_csv_strict_profiles_file_only_once(
    tmp_path: Path, monkeypatch
):
    # The convert --to csv path goes through repair(), so check the
    # repair-side profile_file is also bypassed when the gate
    # threaded a profile in.
    src = tmp_path / "clean.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id\tname\tage\n1\talice\t30\n2\tbob\t25\n3\tcarol\t40\n")

    import importlib
    cli_mod = importlib.import_module("dsvmonkey.cli")
    repair_mod = importlib.import_module("dsvmonkey.repair")
    orch_mod = importlib.import_module("dsvmonkey.orchestrate")

    calls = {"cli": 0, "repair": 0}
    real = orch_mod.profile_file

    def counting_cli(*args, **kwargs):
        calls["cli"] += 1
        return real(*args, **kwargs)

    def counting_repair(*args, **kwargs):
        calls["repair"] += 1
        return real(*args, **kwargs)

    monkeypatch.setattr(cli_mod, "profile_file", counting_cli)
    monkeypatch.setattr(repair_mod, "profile_file", counting_repair)

    rc = main([
        "convert", str(src), "-o", str(dst),
        "--to", "csv", "--strict",
    ])
    assert rc == 0
    assert calls["cli"] == 1
    assert calls["repair"] == 0


def test_normalize_without_strict_does_not_double_profile(
    tmp_path: Path, monkeypatch
):
    # Negative-side pin: when --strict is NOT set, the gate skips
    # profiling entirely (the old fast path), so repair() does its
    # own one and only profiling pass — total 1, not 0 and not 2.
    src = tmp_path / "clean.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name,age\n1,alice,30\n2,bob,25\n3,carol,40\n")

    import importlib
    cli_mod = importlib.import_module("dsvmonkey.cli")
    repair_mod = importlib.import_module("dsvmonkey.repair")
    orch_mod = importlib.import_module("dsvmonkey.orchestrate")

    calls = {"cli": 0, "repair": 0}
    real = orch_mod.profile_file

    def counting_cli(*args, **kwargs):
        calls["cli"] += 1
        return real(*args, **kwargs)

    def counting_repair(*args, **kwargs):
        calls["repair"] += 1
        return real(*args, **kwargs)

    monkeypatch.setattr(cli_mod, "profile_file", counting_cli)
    monkeypatch.setattr(repair_mod, "profile_file", counting_repair)

    rc = main(["normalize", str(src), "-o", str(dst)])
    assert rc == 0
    assert calls["cli"] == 0  # no gate, no CLI-side profile
    assert calls["repair"] == 1  # repair does its own single pass


def test_inspect_one_sample_row_accepted(tmp_path: Path, capsys):
    # Boundary: 1 is the smallest valid value; must pass validation
    # and actually sample one row.
    src = tmp_path / "f.csv"
    src.write_bytes(b"id,name\n1,alice\n2,bob\n3,carol\n")

    exit_code = main(["inspect", str(src), "--sample-rows", "1"])
    out = capsys.readouterr().out
    assert exit_code == 0
    # Per-column sample count must reflect the cap — one non-empty
    # value per column from the single sampled row.
    assert "1 values" in out


def test_normalize_ascii_encoding_with_non_ascii_source(tmp_path: Path, capsys):
    # Review finding: write-time UnicodeEncodeError bubbles up as a
    # traceback unless main() catches it. UnicodeEncodeError is a
    # ValueError subclass so the existing handler picks it up; this
    # test pins that coverage in case someone narrows the except.
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes("id,name\n1,café\n".encode("utf-8"))

    exit_code = main(
        ["normalize", str(src), "-o", str(dst), "--encoding", "ascii"]
    )
    err = capsys.readouterr().err
    assert exit_code == 2
    assert "error:" in err
    assert "ascii" in err
    # No partial output, no traceback.
    assert "Traceback" not in err


def test_normalize_to_directory_path_fails_cleanly(tmp_path: Path, capsys):
    # Review finding: OSError family wasn't caught. Writing output to
    # a directory path triggers IsADirectoryError — it used to surface
    # as a traceback. Now intercepted as a clean CLI error.
    src = tmp_path / "f.csv"
    src.write_bytes(b"id,name\n1,alice\n")

    # Point --out at an existing directory rather than a file.
    dst_dir = tmp_path / "outdir"
    dst_dir.mkdir()

    exit_code = main(["normalize", str(src), "-o", str(dst_dir)])
    err = capsys.readouterr().err

    assert exit_code == 2
    assert "error:" in err
    assert "Traceback" not in err


def test_normalize_unknown_encoding_fails_cleanly(tmp_path: Path, capsys):
    # Review finding: an unknown codec name used to propagate as an
    # uncaught LookupError traceback. The validator now rejects it
    # pre-flight with exit 2 + a one-line message.
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name\n1,alice\n")

    exit_code = main(
        ["normalize", str(src), "-o", str(dst), "--encoding", "not-an-encoding"]
    )
    err = capsys.readouterr().err
    assert exit_code == 2
    assert "unknown encoding" in err
    assert not dst.exists()


def test_normalize_aliased_encoding_accepted(tmp_path: Path):
    # Python's codec lookup is alias-tolerant; the validator must pass
    # aliases through rather than rejecting them.
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name\n1,alice\n2,bob\n")

    # "latin1" is an alias for "iso-8859-1".
    exit_code = main(
        ["normalize", str(src), "-o", str(dst), "--encoding", "latin1"]
    )
    assert exit_code == 0
    assert dst.exists()


def test_inspect_no_deep_scan_flag_accepted(tmp_path: Path):
    # Review finding (perf): --no-deep-scan is available on inspect,
    # normalize and convert so callers with very large or remote
    # files can bound the I/O cost.
    src = tmp_path / "f.csv"
    src.write_bytes(b"id,name\n1,alice\n2,bob\n")
    exit_code = main(["inspect", "--no-deep-scan", str(src)])
    assert exit_code == 0


def test_normalize_no_deep_scan_flag_accepted(tmp_path: Path):
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name\n1,alice\n2,bob\n")
    exit_code = main(
        ["normalize", str(src), "-o", str(dst), "--no-deep-scan"]
    )
    assert exit_code == 0
    assert dst.exists()


def test_convert_no_deep_scan_flag_accepted(tmp_path: Path):
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.tsv"
    src.write_bytes(b"id,name\n1,alice\n2,bob\n")
    exit_code = main(
        ["convert", str(src), "-o", str(dst), "--to", "tsv", "--no-deep-scan"]
    )
    assert exit_code == 0
    assert dst.exists()


def test_normalize_unknown_line_ending_fails(tmp_path: Path, capsys):
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name\n1,alice\n")

    exit_code = main(
        ["normalize", str(src), "-o", str(dst), "--line-ending", "bogus"]
    )
    err = capsys.readouterr().err
    assert exit_code == 2
    assert "unknown line ending" in err


def test_normalize_override_field_count(tmp_path: Path):
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name\n1,alice\n2,bob\n")

    main(
        [
            "normalize", str(src), "-o", str(dst),
            "--field-count", "4",
        ]
    )
    with dst.open() as f:
        rows = list(csv.reader(f))
    assert all(len(r) == 4 for r in rows)


# ---------- convert ----------


def test_convert_to_tsv(tmp_path: Path):
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.tsv"
    src.write_bytes(b"id,name,age\n1,alice,30\n2,bob,25\n")

    main(["convert", str(src), "-o", str(dst), "--to", "tsv"])

    text = dst.read_text()
    assert "\t" in text
    assert "id\tname\tage" in text.splitlines()[0]


def test_convert_to_jsonl(tmp_path: Path, capsys):
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.jsonl"
    src.write_bytes(b"id,name,age\n1,alice,30\n2,bob,25\n3,carol,40\n")

    exit_code = main(["convert", str(src), "-o", str(dst), "--to", "jsonl"])
    out = capsys.readouterr().out

    assert exit_code == 0
    assert "wrote 3 rows" in out
    rows = [json.loads(line) for line in dst.read_text().splitlines()]
    assert rows[0] == {"id": "1", "name": "alice", "age": "30"}


def test_convert_to_csv_default(tmp_path: Path):
    # TSV in, CSV out.
    src = tmp_path / "f.tsv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id\tname\n1\talice\n2\tbob\n")

    main(["convert", str(src), "-o", str(dst)])  # --to csv is default

    with dst.open() as f:
        rows = list(csv.reader(f))
    assert rows[0] == ["id", "name"]
    assert rows[1] == ["1", "alice"]


def test_convert_no_clean_preserves_invisibles(tmp_path: Path):
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.jsonl"
    src.write_bytes("id,status\n1,Active​\n".encode("utf-8"))

    main(
        [
            "convert", str(src), "-o", str(dst),
            "--to", "jsonl", "--no-clean",
        ]
    )
    rows = [json.loads(line) for line in dst.read_text().splitlines()]
    assert "​" in rows[0]["status"]


# ---------- Help / missing command ----------


def test_no_args_shows_help(capsys):
    with pytest.raises(SystemExit):
        main([])


def test_normalize_strict_detects_file_mutation_between_gate_and_write(
    tmp_path: Path, capsys
):
    # Review finding (Medium): the in-process double-profile fix
    # closed the gate-vs-run race for the dialect decision but did
    # not address the on-disk race — a concurrent writer to the
    # same path between the gate's profile and the downstream
    # read could replace the bytes underneath us, so the
    # gate-approved profile would drive parse decisions on
    # different content. Mitigation: the gate snapshots
    # (mtime, size) and the downstream re-stats; mismatch → exit 3,
    # no output written.
    src = tmp_path / "clean.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name,age\n1,alice,30\n2,bob,25\n3,carol,40\n")

    # Splice a mutation between the gate and the write by patching
    # `_check_file_unchanged_since_gate` to first overwrite the
    # source, then call the real check. The file's (mtime, size)
    # both change → gate trips.
    import importlib
    cli_mod = importlib.import_module("dsvmonkey.cli")
    real_check = cli_mod._check_file_unchanged_since_gate

    def mutate_then_check(args):
        # Bigger payload + advanced mtime guarantee both fields
        # differ from the gate snapshot.
        src.write_bytes(b"completely,different,content\n" * 50)
        os.utime(src, (1234567890.0, 1234567890.0))
        return real_check(args)

    monkeypatch_target = "dsvmonkey.cli._check_file_unchanged_since_gate"
    import os
    import unittest.mock
    with unittest.mock.patch(monkeypatch_target, side_effect=mutate_then_check):
        rc = main([
            "normalize", str(src), "-o", str(dst), "--strict",
        ])
    err = capsys.readouterr().err
    assert rc == 3
    assert "changed on disk" in err
    assert not dst.exists()


def test_normalize_strict_passes_when_file_stable(
    tmp_path: Path, capsys
):
    # Negative pin: when nothing changes on disk between gate and
    # write, the new mutation guard is invisible — the run
    # completes normally.
    src = tmp_path / "clean.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name,age\n1,alice,30\n2,bob,25\n3,carol,40\n")

    rc = main(["normalize", str(src), "-o", str(dst), "--strict"])
    assert rc == 0
    assert dst.exists()


def test_duplicate_header_review_reason_uses_shared_constant(
    tmp_path: Path,
):
    # Review finding (Low): the review-reason gate matched on
    # `"duplicate header" in issue` while orchestrate emitted the
    # producer string `"duplicate header name(s) ..."`. A future
    # rewording of the producer side (e.g. "duplicate column
    # name") would silently break the consumer gate without any
    # static-analysis signal. Both sides now reference the
    # shared `DUPLICATE_HEADER_ISSUE_PREFIX` constant; pin that
    # the integration still wires through and any future spelling
    # drift surfaces here.
    from dsvmonkey.profile import DUPLICATE_HEADER_ISSUE_PREFIX

    src = tmp_path / "dup.csv"
    src.write_bytes(b"id,name,id\n1,alice,2\n2,bob,3\n3,carol,4\n")

    from dsvmonkey import profile_file
    profile = profile_file(src)
    # Producer wrote the prefix.
    assert any(
        issue.startswith(DUPLICATE_HEADER_ISSUE_PREFIX)
        for issue in profile.issues
    )
    # Consumer reached the review-reasons gate.
    assert any(
        "duplicate header names detected" in r for r in profile.review_reasons
    )
    assert profile.needs_review


def test_mixed_line_endings_warning_uses_shared_constant(tmp_path: Path):
    # Same brittle-coupling fix on the line-ending side: producer
    # (detectors/line_ending.py) and consumer (repair._line_ending_was_changed)
    # both now reference MIXED_LINE_ENDINGS_WARNING. Pin the round-trip.
    from dsvmonkey.profile import MIXED_LINE_ENDINGS_WARNING

    src = tmp_path / "mixed.csv"
    # Mix CRLF and LF deliberately so the detector emits the warning.
    src.write_bytes(b"id,name\r\n1,alice\n2,bob\r\n3,carol\n")

    from dsvmonkey import profile_file
    profile = profile_file(src)
    assert profile.line_ending is not None
    assert MIXED_LINE_ENDINGS_WARNING in (profile.line_ending.warnings or [])


def test_inspect_surfaces_ragged_width_growth_in_column_warnings(
    tmp_path: Path, capsys
):
    # Review finding (Low): profile_columns silently truncated
    # cells past the inferred column width, leaving the inspect
    # report with no signal that some data was excluded from
    # profiling. Now the last column's `warnings` carries an
    # overflow notice naming the row count and max observed width.
    src = tmp_path / "ragged.csv"
    # 3 columns inferred from header; row 3 has 5 cells.
    src.write_bytes(
        b"id,name,age\n"
        b"1,alice,30\n"
        b"2,bob,25\n"
        b"3,carol,40,extra1,extra2\n"
        b"4,dave,28\n"
    )

    rc = main(["inspect", str(src)])
    out = capsys.readouterr().out
    assert rc == 0
    # The diagnostic line names how many rows overflowed and the
    # widest one.
    assert "1 sampled row(s) had more cells than the 3 profiled column(s)" in out
    assert "max observed width: 5" in out


def test_normalize_strict_fails_closed_when_post_gate_stat_fails(
    tmp_path: Path, capsys
):
    # Review finding (Medium): the previous mutation guard returned
    # None (proceed) on stat() failure during the re-check, silently
    # disabling the strict-mode safety contract exactly when the
    # filesystem was misbehaving (NFS hiccup, file deleted, perms
    # changed). Strict mode now fails closed: stat error → exit 3
    # with a clear "couldn't verify file stability" message.
    src = tmp_path / "clean.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name,age\n1,alice,30\n2,bob,25\n3,carol,40\n")

    import importlib
    cli_mod = importlib.import_module("dsvmonkey.cli")
    real_check = cli_mod._check_file_unchanged_since_gate

    def stat_fails_then_check(args):
        # Delete the file so args.path.stat() inside the check raises
        # FileNotFoundError. Strict mode must surface this rather
        # than silently proceed.
        src.unlink()
        return real_check(args)

    import unittest.mock
    with unittest.mock.patch(
        "dsvmonkey.cli._check_file_unchanged_since_gate",
        side_effect=stat_fails_then_check,
    ):
        rc = main(["normalize", str(src), "-o", str(dst), "--strict"])
    err = capsys.readouterr().err
    assert rc == 3
    assert "couldn't re-stat" in err
    assert "verify file stability" in err
    assert not dst.exists()


def test_convert_jsonl_strict_escalates_overflow_to_exit_3(
    tmp_path: Path, capsys
):
    # Companion to the on_overflow=raise direct-API test:
    # `convert --to jsonl --strict` must escalate dict-mode
    # overflow into a strict-mode failure (exit 3) instead of
    # the generic ValueError exit 2. Strict callers gate on
    # `|| queue_for_review` and expect 3 specifically.
    src = tmp_path / "ragged.csv"
    dst = tmp_path / "out.jsonl"
    src.write_bytes(
        b"id,name,age\n"
        b"1,alice,30\n"
        b"2,bob,25,extra\n"
        b"3,carol,40\n"
    )

    rc = main([
        "convert", str(src), "-o", str(dst),
        "--to", "jsonl", "--strict",
    ])
    err = capsys.readouterr().err
    assert rc == 3
    assert "wider-than-header rows" in err
    assert not dst.exists()


def test_convert_jsonl_without_strict_keeps_warning_behaviour(
    tmp_path: Path,
):
    # Negative pin: without --strict, the historical warn-and-drop
    # contract is unchanged. JSONL output is produced, the warning
    # is emitted via the standard channel.
    src = tmp_path / "ragged.csv"
    dst = tmp_path / "out.jsonl"
    src.write_bytes(
        b"id,name,age\n"
        b"1,alice,30\n"
        b"2,bob,25,extra\n"
        b"3,carol,40\n"
    )

    rc = main([
        "convert", str(src), "-o", str(dst), "--to", "jsonl",
    ])
    assert rc == 0
    assert dst.exists()


def test_normalize_strict_fails_closed_when_initial_stat_fails(
    tmp_path: Path, capsys
):
    # Companion to the post-gate test: if the gate itself can't
    # snapshot the file (e.g. permissions race in a shared dir),
    # strict mode must also fail closed instead of marching on
    # without a snapshot.
    src = tmp_path / "missing.csv"
    dst = tmp_path / "out.csv"
    # Don't create src — the gate's stat() will raise FileNotFoundError.

    rc = main(["normalize", str(src), "-o", str(dst), "--strict"])
    err = capsys.readouterr().err
    assert rc == 3
    assert "couldn't snapshot file state" in err
    assert not dst.exists()
