import re
from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as _pkg_version
from pathlib import Path

import pytest

import dsvmonkey
from dsvmonkey.profile import DetectionAlternative, DetectionResult, DSVProfile


# ---------- Version source-of-truth ----------
#
# Review finding: pyproject.toml and __init__.py both held a literal
# version string; they could drift on release. __init__ now reads
# from package metadata so pyproject is canonical. Pin that —
# BUT only when the package is actually installed. pytest runs from
# the src tree via `pythonpath = ["src"]`, so a contributor who
# clones + runs `pytest` without `pip install -e .` legitimately
# hits the `"0.0.0+unknown"` fallback. Skipping in that case keeps
# the version invariant meaningful without producing spurious CI
# failures for fresh checkouts.


def _package_is_installed() -> bool:
    try:
        _pkg_version("dsvmonkey")
    except PackageNotFoundError:
        return False
    return True


package_installed = pytest.mark.skipif(
    not _package_is_installed(),
    reason="dsvmonkey not installed (src-tree pytest run); version metadata "
    "unavailable. Run `pip install -e .[dev]` to exercise these tests.",
)


@package_installed
def test_version_string_is_pep440_shaped():
    # When the package IS installed: __version__ must be a plausible
    # PEP 440-ish string from the installed metadata, not the
    # "0.0.0+unknown" dev fallback.
    assert isinstance(dsvmonkey.__version__, str)
    assert dsvmonkey.__version__
    assert dsvmonkey.__version__ != "0.0.0+unknown"
    # Loose PEP 440 shape: starts with a digit.
    assert re.match(r"\d", dsvmonkey.__version__) is not None


@package_installed
def test_version_matches_installed_metadata():
    # The point of the fix: __version__ comes from importlib.metadata,
    # so it equals the installed package metadata exactly. Drift
    # between a future hand-edited __init__.py and pyproject.toml
    # fails this assertion.
    assert dsvmonkey.__version__ == _pkg_version("dsvmonkey")


def test_detection_result_accepts_valid_confidence():
    result = DetectionResult(value="utf-8", confidence=0.92, method="bom")
    assert result.value == "utf-8"
    assert result.confidence == 0.92
    assert result.method == "bom"
    assert result.alternatives == []
    assert result.warnings == []


@pytest.mark.parametrize("bad", [-0.01, 1.01, 2.0, -1.0])
def test_detection_result_rejects_out_of_range_confidence(bad):
    with pytest.raises(ValueError):
        DetectionResult(value="utf-8", confidence=bad, method="bom")


def test_detection_result_boundary_values_allowed():
    DetectionResult(value="x", confidence=0.0, method="m")
    DetectionResult(value="x", confidence=1.0, method="m")


def test_detection_alternative_is_frozen():
    alt = DetectionAlternative(value="cp1252", confidence=0.7, reason="runner-up")
    with pytest.raises(Exception):
        alt.confidence = 0.9  # type: ignore[misc]


def test_profile_default_fields_are_none_or_empty():
    profile = DSVProfile(path=Path("/tmp/x.csv"), file_size=100, sample_bytes=100)
    assert profile.encoding is None
    assert profile.delimiter is None
    assert profile.quote_char is None
    assert profile.line_ending is None
    assert profile.header_row is None
    assert profile.has_bom is False
    assert profile.bom is None
    assert profile.mixed_encoding_suspected is False
    assert profile.headers is None
    assert profile.field_count is None
    assert profile.issues == []


# ---------- needs_review aggregate ----------
#
# Detection from bytes has fundamental limits — some files genuinely
# can't be classified without human inspection. `needs_review`
# aggregates per-detector low-confidence + ambiguity signals into a
# single boolean so callers can branch on "I can't tell — look at
# the file yourself" without having to inspect every detector
# individually.


def test_needs_review_false_on_confident_clean_file():
    # Negative case: a confidently-detected file does NOT trigger
    # review. The aggregate must not false-positive on healthy
    # input.
    profile = DSVProfile(path=Path(""), file_size=100, sample_bytes=100)
    profile.encoding = DetectionResult(value="utf-8", confidence=1.0, method="bom")
    profile.delimiter = DetectionResult(value=",", confidence=0.95, method="content-scored")
    assert profile.needs_review is False
    assert profile.review_reasons == []


def test_needs_review_true_on_low_confidence_delimiter():
    # Confirmed-true: low delimiter confidence flips the aggregate.
    profile = DSVProfile(path=Path(""), file_size=100, sample_bytes=100)
    profile.encoding = DetectionResult(value="utf-8", confidence=1.0, method="bom")
    profile.delimiter = DetectionResult(value="\x1f", confidence=0.4, method="single-column")
    assert profile.needs_review is True
    assert any("delimiter confidence" in r for r in profile.review_reasons)


def test_needs_review_true_on_low_confidence_encoding():
    profile = DSVProfile(path=Path(""), file_size=100, sample_bytes=100)
    profile.encoding = DetectionResult(value="latin-1", confidence=0.3, method="content-scored")
    profile.delimiter = DetectionResult(value=",", confidence=0.95, method="content-scored")
    assert profile.needs_review is True
    assert any("encoding confidence" in r for r in profile.review_reasons)


def test_needs_review_true_on_mixed_encoding_suspected():
    # Confirmed-true via the mixed-encoding signal even when both
    # detection confidences are high (the decoder picked one
    # encoding confidently, but stray bytes elsewhere suggest the
    # file isn't homogeneous).
    profile = DSVProfile(path=Path(""), file_size=100, sample_bytes=100)
    profile.encoding = DetectionResult(value="utf-8", confidence=1.0, method="bom")
    profile.delimiter = DetectionResult(value=",", confidence=0.95, method="content-scored")
    profile.mixed_encoding_suspected = True
    assert profile.needs_review is True
    assert any("mixed encoding" in r for r in profile.review_reasons)


def test_needs_review_at_threshold_boundary():
    # Boundary probe. The floor is 0.6: confidence == 0.6 should
    # NOT trigger (>= boundary), confidence == 0.59 should.
    profile = DSVProfile(path=Path(""), file_size=100, sample_bytes=100)
    profile.encoding = DetectionResult(value="utf-8", confidence=1.0, method="bom")
    profile.delimiter = DetectionResult(value=",", confidence=0.6, method="content-scored")
    assert profile.needs_review is False

    profile.delimiter = DetectionResult(value=",", confidence=0.59, method="content-scored")
    assert profile.needs_review is True


def test_needs_review_collects_all_reasons():
    # Multiple signals stack — review_reasons enumerates each
    # contributing factor so the operator sees the full picture
    # in one place.
    profile = DSVProfile(path=Path(""), file_size=100, sample_bytes=100)
    profile.encoding = DetectionResult(value="latin-1", confidence=0.3, method="content-scored")
    profile.delimiter = DetectionResult(value=",", confidence=0.4, method="single-column")
    profile.mixed_encoding_suspected = True
    reasons = profile.review_reasons
    assert len(reasons) == 3  # encoding, mixed, delimiter
    assert profile.needs_review is True


def test_needs_review_true_on_single_column_method_at_high_confidence():
    # Review finding (#1 High): single-column verdict at confidence
    # 1.0 used to bypass needs_review (which only checked the 0.6
    # floor). But single-column is INHERENTLY ambiguous — the same
    # verdict covers true single-column files AND custom-delimiter
    # files we don't auto-detect. Always recommend review when the
    # method is single-column, regardless of confidence number.
    profile = DSVProfile(path=Path(""), file_size=100, sample_bytes=100)
    profile.encoding = DetectionResult(value="utf-8", confidence=1.0, method="bom")
    profile.delimiter = DetectionResult(
        value="\x1f", confidence=1.0, method="single-column"
    )
    assert profile.needs_review is True
    assert any("single-column" in r for r in profile.review_reasons)


def test_needs_review_true_on_duplicate_headers_in_issues():
    # Review finding (#2 High): dict-mode duplicate-header collapse
    # is silent data loss that downstream warning filters can hide.
    # `needs_review` now triggers on the existing
    # `profile.issues` "duplicate header" entry, gating unattended
    # pipelines on the boolean rather than relying on the warning
    # channel alone.
    profile = DSVProfile(path=Path(""), file_size=100, sample_bytes=100)
    profile.encoding = DetectionResult(value="utf-8", confidence=1.0, method="bom")
    profile.delimiter = DetectionResult(value=",", confidence=0.95, method="content-scored")
    profile.issues.append("duplicate header name(s) ['id']: ...")
    assert profile.needs_review is True
    assert any("duplicate header" in r for r in profile.review_reasons)


# ---------- assert_clean / ReviewRecommendedError ----------


def test_assert_clean_silent_on_confident_profile():
    # Negative: a confidently-detected file passes through with no
    # exception. The gate is one line at the top of the pipeline;
    # callers shouldn't see false positives on healthy input.
    import dsvmonkey

    profile = DSVProfile(path=Path("/tmp/x.csv"), file_size=100, sample_bytes=100)
    profile.encoding = DetectionResult(value="utf-8", confidence=1.0, method="bom")
    profile.delimiter = DetectionResult(value=",", confidence=0.95, method="content-scored")
    # Should not raise.
    dsvmonkey.assert_clean(profile)


def test_assert_clean_raises_on_review_recommended():
    # Confirmed-true: when needs_review fires, the helper raises
    # the typed exception with .path and .reasons populated.
    import dsvmonkey

    profile = DSVProfile(path=Path("/tmp/x.csv"), file_size=100, sample_bytes=100)
    profile.encoding = DetectionResult(value="utf-8", confidence=1.0, method="bom")
    profile.delimiter = DetectionResult(
        value="\x1f", confidence=1.0, method="single-column"
    )
    with pytest.raises(dsvmonkey.ReviewRecommendedError) as exc_info:
        dsvmonkey.assert_clean(profile)
    err = exc_info.value
    assert err.path == Path("/tmp/x.csv")
    # `.reasons` is a copy — mutation by handlers must not affect
    # the underlying profile.
    err.reasons.append("mutated")
    assert "mutated" not in profile.review_reasons


def test_review_recommended_error_message_includes_reasons():
    # The exception's str() carries the path and at least one
    # reason — useful for log lines / queue-message bodies that
    # don't unpack `.reasons` explicitly.
    import dsvmonkey

    profile = DSVProfile(path=Path("/tmp/x.csv"), file_size=100, sample_bytes=100)
    profile.encoding = DetectionResult(value="utf-8", confidence=1.0, method="bom")
    profile.delimiter = DetectionResult(value=",", confidence=0.4, method="content-scored")
    err = dsvmonkey.ReviewRecommendedError(profile)
    msg = str(err)
    assert "/tmp/x.csv" in msg
    assert "delimiter confidence" in msg


def test_review_recommended_error_is_a_subclass_of_exception():
    # Caller-friendly: standard `except Exception` catches it.
    # Nothing exotic in the inheritance chain.
    import dsvmonkey

    assert issubclass(dsvmonkey.ReviewRecommendedError, Exception)


def test_review_reasons_dedup_on_low_confidence_single_column():
    # Review finding (#6): the de-dup between "low delimiter
    # confidence" and "single-column classification" used a
    # substring check on the joined reasons — brittle to
    # message-text changes. Refactored to an explicit boolean
    # flag. Pin behaviour: when a single-column verdict ALSO
    # has confidence below floor, only one delimiter-related
    # reason fires (the more specific confidence one), not both.
    profile = DSVProfile(path=Path(""), file_size=100, sample_bytes=100)
    profile.encoding = DetectionResult(value="utf-8", confidence=1.0, method="bom")
    profile.delimiter = DetectionResult(
        value="\x1f", confidence=0.4, method="single-column"
    )
    reasons = profile.review_reasons
    delimiter_reasons = [r for r in reasons if "delimiter" in r]
    assert len(delimiter_reasons) == 1
    # The confidence reason wins (more specific than the
    # generic single-column reason).
    assert "delimiter confidence" in delimiter_reasons[0]


def test_review_reasons_single_column_at_full_confidence_still_reports():
    # Negative case: a single-column verdict at confidence 1.0
    # (heuristic-detected free-text file) doesn't trip the
    # low-confidence reason, so the single-column reason fires
    # alone. The two paths cover disjoint cases and both should
    # surface.
    profile = DSVProfile(path=Path(""), file_size=100, sample_bytes=100)
    profile.encoding = DetectionResult(value="utf-8", confidence=1.0, method="bom")
    profile.delimiter = DetectionResult(
        value="\x1f", confidence=1.0, method="single-column"
    )
    reasons = profile.review_reasons
    delimiter_reasons = [r for r in reasons if "delimiter" in r]
    assert len(delimiter_reasons) == 1
    assert "single-column" in delimiter_reasons[0]


def test_needs_review_true_on_low_confidence_quote_char():
    # Review finding (#1): quote_char wasn't gated, so a weak
    # quote-detection result didn't trigger review even though
    # quote-char misclassification materially changes parsing
    # semantics (split fields incorrectly on quote-state errors).
    profile = DSVProfile(path=Path(""), file_size=100, sample_bytes=100)
    profile.encoding = DetectionResult(value="utf-8", confidence=1.0, method="bom")
    profile.delimiter = DetectionResult(value=",", confidence=0.95, method="content-scored")
    profile.quote_char = DetectionResult(
        value="'", confidence=0.45, method="field-start-count"
    )
    assert profile.needs_review is True
    assert any("quote_char confidence" in r for r in profile.review_reasons)


def test_needs_review_true_on_low_confidence_header_row():
    # Header row picked but barely. method="absent" with
    # confidence < 0.6 means the detector couldn't decide either
    # way — should gate.
    profile = DSVProfile(path=Path(""), file_size=100, sample_bytes=100)
    profile.encoding = DetectionResult(value="utf-8", confidence=1.0, method="bom")
    profile.delimiter = DetectionResult(value=",", confidence=0.95, method="content-scored")
    profile.header_row = DetectionResult(value=None, confidence=0.45, method="absent")
    assert profile.needs_review is True
    assert any("header_row confidence" in r for r in profile.review_reasons)


def test_needs_review_skips_header_row_method_fallback():
    # Negative case: method="fallback" fires only on empty samples
    # (no rows at all). That's a benign state — there's no parsing
    # to get wrong. Don't gate.
    profile = DSVProfile(path=Path(""), file_size=0, sample_bytes=0)
    profile.encoding = DetectionResult(value="utf-8", confidence=1.0, method="bom")
    profile.delimiter = DetectionResult(value=",", confidence=0.95, method="content-scored")
    profile.header_row = DetectionResult(value=None, confidence=0.0, method="fallback")
    # No header_row reason fires — method="fallback" excluded.
    assert not any("header_row" in r for r in profile.review_reasons)


def test_needs_review_does_not_gate_on_low_line_ending_confidence():
    # Negative case: line_ending confidence is intentionally
    # NOT in the gate. Single-line files legitimately produce
    # confidence 0.0 (method="fallback"), and repair() always
    # normalises to the target line ending anyway — gating on
    # this would just produce CI noise without surfacing real
    # parsing risk.
    profile = DSVProfile(path=Path(""), file_size=10, sample_bytes=10)
    profile.encoding = DetectionResult(value="utf-8", confidence=1.0, method="bom")
    profile.delimiter = DetectionResult(value=",", confidence=0.95, method="content-scored")
    profile.line_ending = DetectionResult(value="\n", confidence=0.0, method="fallback")
    assert profile.needs_review is False


def test_needs_review_handles_partially_populated_profile():
    # Adversarial: a profile mid-construction (encoding set,
    # delimiter not yet) should not crash. Missing detectors are
    # treated as "no signal" rather than "definitely needs
    # review."
    profile = DSVProfile(path=Path(""), file_size=100, sample_bytes=100)
    profile.encoding = DetectionResult(value="utf-8", confidence=1.0, method="bom")
    # delimiter still None — pre-detection state.
    assert profile.needs_review is False
