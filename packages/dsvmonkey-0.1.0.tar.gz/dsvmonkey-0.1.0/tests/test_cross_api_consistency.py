"""Cross-API consistency tests.

read(), repair(), and to_jsonl() all work from the same DSVProfile
but touch different output paths. If they ever disagree about what's
in the file, at least one of them is lying to its caller — exactly
the class of bug that motivated the UTF-16 BOM fix. This suite pins
agreement across every structural axis: encoding (BOM and non-BOM),
line endings, delimiters, ragged rows, empty rows, quoted fields.

Organized as a handful of matrix-style parameterised cases rather
than one-test-per-variant, so adding a new axis or fixture is cheap.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path

import pytest

import dsvmonkey


def _write(path: Path, content: bytes) -> Path:
    path.write_bytes(content)
    return path


def _repair_rows(src: Path, dst: Path) -> list[list[str]]:
    # Normalise to comma-delimited output so the stdlib csv.reader
    # reads it back correctly regardless of the source delimiter.
    # The delimiter change itself is tested elsewhere; here we're
    # only asserting data preservation.
    dsvmonkey.repair(src, dst, clean_cells=False, target_delimiter=",")
    with dst.open(encoding="utf-8", newline="") as fh:
        return list(csv.reader(fh))


def _read_rows(src: Path) -> list[list[str]]:
    return list(dsvmonkey.read(src, as_dict=False, clean=False))


def _jsonl_rows(src: Path, dst: Path) -> list[dict]:
    dsvmonkey.to_jsonl(src, dst, clean_cells=False)
    return [json.loads(line) for line in dst.read_text().splitlines()]


# ---------- Structural axis parameterisation ----------


@pytest.mark.parametrize(
    "name, content, expected_header, expected_data",
    [
        (
            "utf8_no_bom",
            b"id,name\n1,alice\n2,bob\n",
            ["id", "name"],
            [["1", "alice"], ["2", "bob"]],
        ),
        (
            "utf8_bom",
            b"\xef\xbb\xbfid,name\n1,alice\n2,bob\n",
            ["id", "name"],
            [["1", "alice"], ["2", "bob"]],
        ),
        (
            "utf16_le_bom",
            b"\xff\xfe" + "id,name\n1,alice\n2,bob\n".encode("utf-16-le"),
            ["id", "name"],
            [["1", "alice"], ["2", "bob"]],
        ),
        (
            "utf16_be_bom",
            b"\xfe\xff" + "id,name\n1,alice\n2,bob\n".encode("utf-16-be"),
            ["id", "name"],
            [["1", "alice"], ["2", "bob"]],
        ),
        (
            "crlf_line_endings",
            b"id,name\r\n1,alice\r\n2,bob\r\n",
            ["id", "name"],
            [["1", "alice"], ["2", "bob"]],
        ),
        (
            "tab_delimiter",
            b"id\tname\n1\talice\n2\tbob\n",
            ["id", "name"],
            [["1", "alice"], ["2", "bob"]],
        ),
        (
            "semicolon_delimiter",
            b"id;name\n1;alice\n2;bob\n",
            ["id", "name"],
            [["1", "alice"], ["2", "bob"]],
        ),
        (
            "quoted_fields_with_embedded_delimiter",
            b'id,note\n1,"alice, bob"\n2,carol\n',
            ["id", "note"],
            [["1", "alice, bob"], ["2", "carol"]],
        ),
    ],
)
def test_read_and_repair_agree_across_axes(
    tmp_path: Path, name, content, expected_header, expected_data
):
    # One property, many inputs: read() and repair() must both produce
    # the same data rows for the same file, independent of encoding,
    # line endings, delimiter, or quoting. Drift between the two APIs
    # is the bug class this suite exists to catch.
    src = _write(tmp_path / f"{name}.csv", content)
    dst = tmp_path / f"{name}.out.csv"

    read_rows = _read_rows(src)
    repair_rows = _repair_rows(src, dst)

    assert read_rows == expected_data, (
        f"{name}: read() disagreed with fixture"
    )
    assert repair_rows[0] == expected_header, (
        f"{name}: repair() dropped or mangled the header row"
    )
    assert repair_rows[1:] == expected_data, (
        f"{name}: repair() data rows differ from read()"
    )


@pytest.mark.parametrize(
    "name, content, expected_dicts",
    [
        (
            "utf8_no_bom",
            b"id,name\n1,alice\n2,bob\n",
            [{"id": "1", "name": "alice"}, {"id": "2", "name": "bob"}],
        ),
        (
            "utf8_bom",
            b"\xef\xbb\xbfid,name\n1,alice\n2,bob\n",
            [{"id": "1", "name": "alice"}, {"id": "2", "name": "bob"}],
        ),
        (
            "utf16_le_bom",
            b"\xff\xfe" + "id,name\n1,alice\n2,bob\n".encode("utf-16-le"),
            [{"id": "1", "name": "alice"}, {"id": "2", "name": "bob"}],
        ),
    ],
)
def test_read_dict_and_jsonl_agree(tmp_path: Path, name, content, expected_dicts):
    # read(as_dict=True) and to_jsonl() both key rows by header. The
    # JSONL output must be a byte-parseable representation of exactly
    # the dicts read() yields. If these drift, a downstream pipeline
    # feeding jq / pgmonkey / typemonkey silently sees different data
    # than a user inspecting the file with read().
    src = _write(tmp_path / f"{name}.csv", content)
    dst = tmp_path / f"{name}.jsonl"

    read_dicts = list(dsvmonkey.read(src, as_dict=True, clean=False))
    jsonl_dicts = _jsonl_rows(src, dst)

    assert read_dicts == expected_dicts, f"{name}: read() disagrees"
    assert jsonl_dicts == expected_dicts, f"{name}: to_jsonl() disagrees"


# ---------- Ragged / overflow rows: repair pads, read pads, jsonl drops ----------
#
# This is the one axis where the three APIs are DELIBERATELY different.
# Pin the documented divergence so a future "make them all consistent"
# refactor has to make the contract change explicit.


def test_ragged_rows_documented_divergence(tmp_path: Path):
    src = _write(
        tmp_path / "ragged.csv",
        b"id,name,age\n1,alice\n2,bob,30,extra\n3,carol,25\n",
    )

    # read(as_dict=False) preserves every cell of every row.
    list_rows = list(dsvmonkey.read(src, as_dict=False, clean=False))
    assert list_rows == [
        ["1", "alice"],           # short row preserved short
        ["2", "bob", "30", "extra"],  # long row preserved long
        ["3", "carol", "25"],
    ]

    # read(as_dict=True) pads short rows, drops overflow with warning.
    with pytest.warns(UserWarning, match="overflow cells are dropped"):
        dict_rows = list(dsvmonkey.read(src, as_dict=True, clean=False))
    assert dict_rows == [
        {"id": "1", "name": "alice", "age": ""},  # pad
        {"id": "2", "name": "bob", "age": "30"},  # truncate
        {"id": "3", "name": "carol", "age": "25"},
    ]

    # repair() pads AND truncates to the header width, counting each.
    dst = tmp_path / "out.csv"
    report = dsvmonkey.repair(src, dst, clean_cells=False)
    assert report.short_rows_padded == 1
    assert report.long_rows_truncated == 1
    with dst.open(encoding="utf-8") as fh:
        written = list(csv.reader(fh))
    assert written[1:] == [
        ["1", "alice", ""],
        ["2", "bob", "30"],
        ["3", "carol", "25"],
    ]


# ---------- Empty rows: all three APIs drop them ----------


# ---------- Header name normalization across APIs ----------
#
# Review finding: read() applied cleanmonkey to profile.headers before
# using them as dict keys, but profile_columns() resolved column names
# from profile.headers directly. A ZWSP / BOM / NBSP in a header byte
# showed up as a silent key mismatch between the two APIs. Headers are
# now cleaned canonically at orchestration time so every downstream
# consumer sees the same column name.


def test_header_with_bom_is_normalized_consistently_across_apis(tmp_path: Path):
    src = _write(
        tmp_path / "bom_in_header.csv",
        "﻿id,name,age\n1,alice,30\n2,bob,25\n".encode("utf-8"),
    )

    profile = dsvmonkey.profile_file(src)
    # Canonical form lives on the profile — no BOM.
    assert profile.headers == ["id", "name", "age"]

    read_keys = list(next(iter(dsvmonkey.read(src))).keys())
    col_names = [c.name for c in dsvmonkey.profile_columns(src)]

    assert read_keys == ["id", "name", "age"]
    assert col_names == ["id", "name", "age"]
    assert read_keys == col_names


def test_header_with_zero_width_space_is_normalized(tmp_path: Path):
    # U+200B (ZERO WIDTH SPACE) embedded in a header byte stream.
    # Pre-fix: profile_columns produced ColumnProfile(name="​id")
    # while read(as_dict=True) produced dicts keyed by "id" — two
    # different schemas for the same file.
    src = _write(
        tmp_path / "zwsp_in_header.csv",
        "​id,name\n1,alice\n2,bob\n".encode("utf-8"),
    )

    profile = dsvmonkey.profile_file(src)
    assert "​" not in profile.headers[0]
    assert profile.headers == ["id", "name"]

    read_keys = list(next(iter(dsvmonkey.read(src))).keys())
    col_names = [c.name for c in dsvmonkey.profile_columns(src)]
    assert read_keys == col_names == ["id", "name"]


def test_header_with_nbsp_is_normalized(tmp_path: Path):
    # NBSP (U+00A0) between words in a header. cleanmonkey's csv
    # profile normalises whitespace so column names don't contain
    # invisible padding.
    #
    # Fixture adds a numeric column so header detection fires — the
    # all-string false-positive fix requires real type_contrast
    # before claiming a header. NBSP normalisation still has to
    # work when a header IS detected, which is the contract this
    # test pins.
    nbsp = "\u00a0"
    content = (
        f"first{nbsp}name,last{nbsp}name,age\n"
        "alice,jones,30\n"
        "bob,smith,25\n"
    ).encode("utf-8")
    src = _write(tmp_path / "nbsp_in_header.csv", content)

    profile = dsvmonkey.profile_file(src)
    assert profile.headers is not None
    # NBSP must not survive in the canonical header list.
    assert all(nbsp not in h for h in profile.headers)

    read_keys = list(next(iter(dsvmonkey.read(src))).keys())
    col_names = [c.name for c in dsvmonkey.profile_columns(src)]
    assert read_keys == col_names


def test_all_apis_agree_on_empty_row_dropping(tmp_path: Path):
    src = _write(
        tmp_path / "blanks.csv",
        b"id,name\n1,alice\n\n  ,\t\n2,bob\n",
    )

    list_rows = list(dsvmonkey.read(src, as_dict=False, clean=False))
    assert list_rows == [["1", "alice"], ["2", "bob"]]

    dst = tmp_path / "out.csv"
    dsvmonkey.repair(src, dst, clean_cells=False)
    with dst.open(encoding="utf-8") as fh:
        repair_rows = list(csv.reader(fh))
    # Header + 2 data rows only.
    assert repair_rows == [["id", "name"], ["1", "alice"], ["2", "bob"]]

    jsonl_dst = tmp_path / "out.jsonl"
    dsvmonkey.to_jsonl(src, jsonl_dst, clean_cells=False)
    jsonl = [json.loads(line) for line in jsonl_dst.read_text().splitlines()]
    assert jsonl == [{"id": "1", "name": "alice"}, {"id": "2", "name": "bob"}]
