from dsvmonkey.detectors.line_ending import detect_line_ending


def test_pure_unix_line_endings():
    sample = "id,name\n1,alice\n2,bob\n3,carol\n"
    result = detect_line_ending(sample)
    assert result.value == "\n"
    assert result.confidence == 1.0
    assert result.method == "occurrence-count"
    assert result.warnings == []


def test_pure_windows_line_endings():
    sample = "id,name\r\n1,alice\r\n2,bob\r\n3,carol\r\n"
    result = detect_line_ending(sample)
    assert result.value == "\r\n"
    assert result.confidence == 1.0
    # Critical: the bare \n count must not be inflated by the \n at the
    # end of each \r\n pair — that would make the confidence drop to 0.5.


def test_pure_classic_mac_line_endings():
    sample = "id,name\r1,alice\r2,bob\r3,carol\r"
    result = detect_line_ending(sample)
    assert result.value == "\r"
    assert result.confidence == 1.0


def test_mixed_line_endings_warns():
    # File concatenated from a Windows export and a Unix export.
    sample = "id,name\r\n1,alice\r\n2,bob\n3,carol\n"
    result = detect_line_ending(sample)
    assert result.value in {"\r\n", "\n"}
    assert "mixed line endings in sample" in result.warnings
    assert result.confidence < 1.0


def test_no_line_endings_falls_back():
    result = detect_line_ending("single line with no terminators")
    assert result.value == "\n"
    assert result.method == "fallback"
    assert result.confidence == 0.0


def test_alternatives_list_non_zero_counts():
    sample = "a\r\nb\r\nc\nd\n"  # 2 crlf, 2 bare lf
    result = detect_line_ending(sample)
    alt_values = [a.value for a in result.alternatives]
    # The runner-up should appear as an alternative.
    assert len(alt_values) >= 1


# Gap 18 (a): Single-line file with NO trailing newline — fallback path.
def test_gap18_single_line_no_trailing_newline_falls_back():
    sample = "id,name"
    # Verify fixture: zero line terminators of any kind.
    assert sample.encode().count(b"\n") == 0
    assert sample.encode().count(b"\r") == 0
    result = detect_line_ending(sample)
    assert result.value == "\n"
    assert result.confidence == 0.0
    assert result.method == "fallback"
    assert "no line endings in sample" in result.warnings


# Gap 18 (b): Adversarial empty string — pin the fallback behaviour.
def test_gap18_empty_string_falls_back():
    result = detect_line_ending("")
    assert result.value == "\n"
    assert result.confidence == 0.0
    assert result.method == "fallback"
    assert "no line endings in sample" in result.warnings
    # Empty input has no alternatives to report.
    assert result.alternatives == []


# Gap 18 (c): Single \r\n only — one data point, unambiguous.
def test_gap18_single_crlf_is_confident():
    sample = "id,name\r\n"
    assert sample.encode().count(b"\r\n") == 1
    result = detect_line_ending(sample)
    assert result.value == "\r\n"
    assert result.confidence == 1.0
    assert result.method == "occurrence-count"
    # No mixed-endings warning when only one kind is present.
    assert "mixed line endings in sample" not in result.warnings


# Gap 18 (d): Exact tie between \r\n and \n — pin deterministic choice.
def test_gap18_exact_tie_crlf_vs_lf_is_deterministic():
    sample = ("a\r\n" * 5) + ("b\n" * 5)
    # Verify fixture: 5 crlf and 5 bare lf.
    raw = sample.encode()
    crlf = raw.count(b"\r\n")
    bare_lf = raw.count(b"\n") - crlf
    assert crlf == 5
    assert bare_lf == 5
    # Run twice — result must be reproducible.
    r1 = detect_line_ending(sample)
    r2 = detect_line_ending(sample)
    assert r1.value == r2.value
    assert r1.confidence == r2.confidence
    assert r1.value in {"\r\n", "\n"}
    # Tie means neither dominates fully.
    assert r1.confidence == 0.5
    # Mixed endings present → warning should fire.
    assert "mixed line endings in sample" in r1.warnings
    # Current implementation: stable sort keeps the original order on ties,
    # so "\r\n" (first in the counts list) wins.
    assert r1.value == "\r\n"


def test_embedded_newline_in_quoted_field_not_counted_as_line_ending():
    # Review finding (#3 Medium): the detector counted
    # newline-shaped bytes anywhere in the sample, including
    # inside quoted multi-line cells. A clean CRLF file with a
    # multi-line text column would get spuriously flagged as
    # mixed endings (CRLF outside, LF inside the quote). Quote-
    # aware counting fixes this.
    sample = (
        'id,note\r\n'
        '1,"line one\nline two"\r\n'
        '2,"plain"\r\n'
        '3,"another\nmulti\nline"\r\n'
    )
    result = detect_line_ending(sample)
    # CRLF is the only real row terminator. Embedded \n inside
    # quoted fields should NOT show up as alternatives, and no
    # mixed-endings warning should fire.
    assert result.value == "\r\n"
    assert result.confidence == 1.0
    assert not any("mixed" in w for w in result.warnings)


def test_quotechar_none_falls_back_to_raw_count():
    # Negative case: when no quote char is in play (passed None),
    # the function reverts to a raw count over the whole sample —
    # matches the previous behaviour for files that genuinely
    # have no quoting.
    sample = "a\r\nb\nc\r\n"
    result = detect_line_ending(sample, quotechar=None)
    # Two CRLFs and one bare LF, so CRLF dominates.
    assert result.value == "\r\n"


def test_doubled_quote_inside_quoted_field_does_not_unbalance_state():
    # Adversarial: `""` inside a quoted region is a CSV-escaped
    # literal quote, not a region-toggle. The state machine must
    # treat it correctly so a subsequent embedded \n stays
    # inside the quote.
    sample = (
        'id,note\r\n'
        '1,"she said ""hi"" then\nleft"\r\n'
        '2,"plain"\r\n'
    )
    result = detect_line_ending(sample)
    assert result.value == "\r\n"
    assert not any("mixed" in w for w in result.warnings)


def test_apostrophes_in_prose_do_not_suppress_line_endings():
    # Review finding (#1, #2 Medium): the previous state machine
    # toggled quote state on EVERY apostrophe, so under
    # `quotechar="'"` a normal contraction in text (`it's`,
    # `don't`) opened a quote region mid-cell and suppressed
    # every newline until another apostrophe appeared. A file
    # with a single stray apostrophe early on would land in
    # the "no line endings in sample" fallback path with a
    # bogus 0.0 confidence — destructive to the line-ending
    # signal, not just confidence noise.
    sample = "x'y\nz\nq\nr\n"
    result = detect_line_ending(sample, quotechar="'", delimiter=",")
    # All four newlines counted as legitimate row terminators.
    assert result.value == "\n"
    assert result.method == "occurrence-count"
    assert result.confidence == 1.0


def test_apostrophe_quoted_csv_with_real_quoted_field():
    # Negative case: under `quotechar="'"`, a LEGITIMATE quoted
    # field (apostrophe at field-start, closing apostrophe at
    # field-end) still suppresses embedded newlines correctly.
    # The state machine has to recognise the field-start position
    # to distinguish "real quote opener" from "apostrophe in
    # content."
    sample = (
        "id,note\n"
        "1,'embedded\nnewline in quoted field'\n"
        "2,plain\n"
    )
    result = detect_line_ending(sample, quotechar="'", delimiter=",")
    # Three newlines outside quoted regions (header, row 1 end,
    # row 2 end). The newline INSIDE the quoted field is content,
    # not a row terminator.
    assert result.value == "\n"
    assert result.confidence == 1.0


def test_line_ending_detection_falls_back_to_raw_when_delimiter_missing():
    # When the caller doesn't pass a delimiter, the state machine
    # can't reliably identify field-start positions — apostrophes
    # could go either way. The function falls back to raw count,
    # which is the safer default than a state machine that might
    # over-fire on apostrophes.
    sample = "x'y\nz\nq\n"
    result = detect_line_ending(sample, quotechar="'", delimiter=None)
    # Raw count: 3 \n's. No state-machine suppression.
    assert result.value == "\n"
    assert result.confidence == 1.0


# Gap 18 (e): Classic Mac \r-only endings — should be recognised, not fallback.
def test_gap18_classic_mac_cr_only_is_recognised():
    sample = "a\rb\rc\r"
    raw = sample.encode()
    crlf = raw.count(b"\r\n")
    bare_cr = raw.count(b"\r") - crlf
    assert crlf == 0
    assert bare_cr == 3
    result = detect_line_ending(sample)
    assert result.value == "\r"
    assert result.confidence == 1.0
    assert result.method == "occurrence-count"
    assert "mixed line endings in sample" not in result.warnings
