"""End-to-end pipeline tests.

These exercise `profile_bytes` against realistic DSV shapes — the
same scenarios the individual detectors cover, but composed.
"""

from pathlib import Path

import pytest

import dsvmonkey
from dsvmonkey import profile_bytes, profile_file


# ---------- Duplicate header surfacing ----------


def test_duplicate_headers_surface_in_profile_issues(tmp_path: Path):
    # Review finding: read(as_dict=True) warns on duplicate header
    # collisions, but warnings can be filtered silently. The same
    # information now lives on profile.issues — a persistent,
    # non-filterable channel visible in `inspect` and in the
    # RepairReport's profile, so a muted warning can't hide silent
    # data loss.
    path = tmp_path / "dup.csv"
    path.write_bytes(b"id,name,id\n1,alice,99\n2,bob,88\n")
    profile = profile_file(path)
    assert any("duplicate header" in issue for issue in profile.issues)
    # And the specific duplicated name is called out so a reader of
    # the inspect report can tell which column is colliding.
    assert any("'id'" in issue for issue in profile.issues)


def test_unique_headers_do_not_trigger_duplicate_issue(tmp_path: Path):
    # Negative case: no false-positives on healthy files.
    path = tmp_path / "clean.csv"
    path.write_bytes(b"id,name,age\n1,alice,30\n2,bob,25\n")
    profile = profile_file(path)
    assert not any("duplicate header" in issue for issue in profile.issues)


def test_duplicate_headers_issue_reaches_repair_report(tmp_path: Path):
    # The repair report carries the profile, so the duplicate-header
    # issue is reachable from a monitoring-style
    # `report.profile.issues` check without any extra API call.
    src = tmp_path / "dup.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name,id\n1,alice,99\n2,bob,88\n")
    report = dsvmonkey.repair(src, dst)
    assert any(
        "duplicate header" in issue for issue in report.profile.issues
    )


def test_duplicate_headers_after_cleanmonkey_normalisation(tmp_path: Path):
    # Adversarial: two header cells that are distinct raw bytes but
    # collapse to the same name after cleanmonkey normalises
    # invisibles. The duplicate check runs AFTER normalisation, so
    # this collision is still caught.
    path = tmp_path / "zwsp_dup.csv"
    # Row 0 is "id,<ZWSP>id" where the second cell has a leading ZWSP.
    path.write_bytes("id,​id\n1,2\n3,4\n".encode("utf-8"))
    profile = profile_file(path)
    assert any("duplicate header" in issue for issue in profile.issues)


# ---------- sample_size validation ----------
#
# Review finding: profile_file(sample_size=-1) previously slipped
# through to the binary read, where Python's file.read(-1) means
# "read the whole file" — silently changing I/O semantics — and
# min(len(data), -1) made DSVProfile.sample_bytes negative. Both
# APIs now validate the parameter.


def test_profile_bytes_rejects_zero_sample_size():
    with pytest.raises(ValueError, match="positive integer"):
        profile_bytes(b"a,b\n1,2\n", sample_size=0)


def test_profile_bytes_rejects_negative_sample_size():
    with pytest.raises(ValueError, match="positive integer"):
        profile_bytes(b"a,b\n1,2\n", sample_size=-1)


def test_profile_file_rejects_zero_sample_size(tmp_path: Path):
    path = tmp_path / "x.csv"
    path.write_bytes(b"a,b\n1,2\n")
    with pytest.raises(ValueError, match="positive integer"):
        profile_file(path, sample_size=0)


def test_profile_file_rejects_negative_sample_size(tmp_path: Path):
    # Specific regression from the review: sample_size=-1 used to
    # read the whole file via file.read(-1) and produce a negative
    # sample_bytes in the profile.
    path = tmp_path / "x.csv"
    path.write_bytes(b"a,b\n1,2\n")
    with pytest.raises(ValueError, match="positive integer"):
        profile_file(path, sample_size=-1)


def test_profile_bytes_accepts_sample_size_of_one():
    # Boundary: 1 is the smallest legitimate sample. Must not crash
    # and must produce a well-formed profile even on a 1-byte window.
    result = profile_bytes(b"a,b\n1,2\n", sample_size=1)
    assert result.sample_bytes == 1
    assert result.sample_bytes >= 0  # the invariant the bug broke


# ---------- Partial profile rejection ----------
#
# Review finding: read()/repair() accept a caller-supplied profile
# and used to dereference `profile.delimiter.value` without
# checking, so a DSVProfile constructed manually (missing the
# delimiter DetectionResult) would AttributeError deep in a private
# helper. The public APIs now raise ValueError up front.


def test_read_rejects_profile_missing_delimiter(tmp_path: Path):
    from dsvmonkey.profile import DSVProfile
    import dsvmonkey

    path = tmp_path / "x.csv"
    path.write_bytes(b"a,b\n1,2\n")
    bare = DSVProfile(path=path, file_size=path.stat().st_size, sample_bytes=8)

    with pytest.raises(ValueError, match="delimiter"):
        next(dsvmonkey.read(path, profile=bare))


def test_repair_rejects_profile_missing_delimiter(tmp_path: Path):
    from dsvmonkey.profile import DSVProfile
    import dsvmonkey

    src = tmp_path / "x.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"a,b\n1,2\n")
    bare = DSVProfile(path=src, file_size=src.stat().st_size, sample_bytes=8)

    with pytest.raises(ValueError, match="delimiter"):
        dsvmonkey.repair(src, dst, profile=bare)
    # Guard runs before any output is written.
    assert not dst.exists()


def test_read_rejects_profile_missing_encoding(tmp_path: Path):
    # Review finding: a profile with delimiter set but encoding left
    # as None previously slipped through validation and then silently
    # decoded with a UTF-8 fallback in _effective_text_encoding —
    # mojibake on cp1252 / latin-1 / UTF-16 files with no warning.
    # Encoding is now a required field.
    from dsvmonkey.profile import DSVProfile, DetectionResult
    import dsvmonkey

    path = tmp_path / "x.csv"
    path.write_bytes(b"a,b\n1,2\n")
    partial = DSVProfile(path=path, file_size=path.stat().st_size, sample_bytes=8)
    partial.delimiter = DetectionResult(value=",", confidence=1.0, method="manual")
    # encoding deliberately left None.
    with pytest.raises(ValueError, match="encoding"):
        next(dsvmonkey.read(path, profile=partial))


def test_repair_rejects_profile_missing_encoding(tmp_path: Path):
    # Partner to the read() case. The original review specifically
    # noted that repair() would crash with AttributeError when it
    # built the RepairReport via `profile.encoding.value`. Guard
    # now raises ValueError up front.
    from dsvmonkey.profile import DSVProfile, DetectionResult
    import dsvmonkey

    src = tmp_path / "x.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"a,b\n1,2\n")
    partial = DSVProfile(path=src, file_size=src.stat().st_size, sample_bytes=8)
    partial.delimiter = DetectionResult(value=",", confidence=1.0, method="manual")
    with pytest.raises(ValueError, match="encoding"):
        dsvmonkey.repair(src, dst, profile=partial)
    assert not dst.exists()


def test_validate_profile_lists_all_missing_fields_together(tmp_path: Path):
    # Usability: a profile missing both delimiter AND encoding
    # should surface both in a single error, not force the caller
    # to fix one, retry, fix the other, retry.
    from dsvmonkey.profile import DSVProfile
    import dsvmonkey

    path = tmp_path / "x.csv"
    path.write_bytes(b"a,b\n1,2\n")
    bare = DSVProfile(path=path, file_size=path.stat().st_size, sample_bytes=8)

    with pytest.raises(ValueError) as exc:
        next(dsvmonkey.read(path, profile=bare))
    msg = str(exc.value)
    assert "delimiter" in msg
    assert "encoding" in msg


def test_read_rejects_profile_with_multichar_delimiter(tmp_path: Path):
    # Review finding: _validate_profile checked presence but not
    # shape. A caller overriding profile.delimiter.value with a
    # multi-character string would pass validation and then blow
    # up deep in csv.reader with TypeError — inconsistent with the
    # clean boundary errors every other validator produces.
    from dsvmonkey.profile import DetectionResult
    import dsvmonkey

    path = tmp_path / "x.csv"
    path.write_bytes(b"a,b\n1,2\n")
    profile = dsvmonkey.profile_file(path)
    profile.delimiter = DetectionResult(value="||", confidence=1.0, method="manual")

    with pytest.raises(ValueError, match="single character"):
        next(dsvmonkey.read(path, profile=profile))


def test_read_rejects_profile_built_from_different_file(tmp_path: Path):
    # Review finding (#1 High): a caller who cached a profile and
    # then applied it to a different file would silently parse file
    # B with file A's delimiter/encoding/header assumptions —
    # valid-looking but wrong output with no exception. Easy to
    # trigger in cached-profile pipelines. Now caught at the
    # read() boundary.
    import dsvmonkey

    csv_path = tmp_path / "a.csv"
    tsv_path = tmp_path / "b.tsv"
    csv_path.write_bytes(b"id,name\n1,alice\n")
    tsv_path.write_bytes(b"id\tname\n1\talice\n")

    csv_profile = dsvmonkey.profile_file(csv_path)
    with pytest.raises(ValueError, match="profile was built from"):
        list(dsvmonkey.read(tsv_path, profile=csv_profile))


def test_repair_rejects_profile_built_from_different_file(tmp_path: Path):
    import dsvmonkey

    src = tmp_path / "a.csv"
    other = tmp_path / "b.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name\n1,alice\n")
    other.write_bytes(b"id,name\n2,bob\n")

    other_profile = dsvmonkey.profile_file(other)
    with pytest.raises(ValueError, match="profile was built from"):
        dsvmonkey.repair(src, dst, profile=other_profile)
    assert not dst.exists()


def test_read_accepts_profile_for_same_file_via_different_path(tmp_path: Path):
    # Negative case: resolved-path equality catches `./x.csv` vs
    # `x.csv` — same underlying file, legitimate usage. The guard
    # must NOT false-positive on path normalisation differences.
    import os
    import dsvmonkey

    path = tmp_path / "x.csv"
    path.write_bytes(b"id,name\n1,alice\n")
    profile = dsvmonkey.profile_file(path)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        # Same file, different spelling.
        rows = list(dsvmonkey.read("x.csv", profile=profile))
        assert rows == [{"id": "1", "name": "alice"}]
        rows2 = list(dsvmonkey.read("./x.csv", profile=profile))
        assert rows2 == [{"id": "1", "name": "alice"}]
    finally:
        os.chdir(cwd)


def test_read_accepts_profile_bytes_profile_with_empty_path(tmp_path: Path):
    # Negative case: a profile built via profile_bytes() without a
    # path argument has profile.path = Path(""). The mismatch check
    # should treat this as "not tied to a specific file" and
    # permit use with any input path.
    import dsvmonkey

    path = tmp_path / "x.csv"
    path.write_bytes(b"id,name\n1,alice\n")

    # Build a profile from bytes, no path — explicit "not tied" case.
    data = path.read_bytes()
    profile = dsvmonkey.profile_bytes(data)
    assert profile.path == Path("")

    rows = list(dsvmonkey.read(path, profile=profile))
    assert rows == [{"id": "1", "name": "alice"}]


def test_read_rejects_profile_with_non_string_delimiter(tmp_path: Path):
    # Review finding (#2): a non-string delimiter (e.g. int from a
    # buggy wrapper) previously hit len(42) with TypeError instead
    # of the boundary ValueError. Callers relying on ValueError
    # exception class couldn't catch it cleanly.
    from dsvmonkey.profile import DetectionResult
    import dsvmonkey

    path = tmp_path / "x.csv"
    path.write_bytes(b"a,b\n1,2\n")
    profile = dsvmonkey.profile_file(path)
    profile.delimiter = DetectionResult(value=42, confidence=1.0, method="manual")
    with pytest.raises(ValueError, match="must be a string"):
        next(dsvmonkey.read(path, profile=profile))


def test_read_rejects_profile_with_non_string_encoding(tmp_path: Path):
    from dsvmonkey.profile import DetectionResult
    import dsvmonkey

    path = tmp_path / "x.csv"
    path.write_bytes(b"a,b\n1,2\n")
    profile = dsvmonkey.profile_file(path)
    profile.encoding = DetectionResult(value=b"utf-8", confidence=1.0, method="manual")
    with pytest.raises(ValueError, match="must be a string"):
        next(dsvmonkey.read(path, profile=profile))


def test_read_rejects_profile_with_multichar_quote_char(tmp_path: Path):
    # Review finding (#1 High): `_validate_profile` checked
    # delimiter and encoding shape but not quote_char. A caller
    # overriding profile.quote_char.value with a multi-char or
    # empty string hit csv.reader with TypeError rather than a
    # clean boundary error.
    from dsvmonkey.profile import DetectionResult
    import dsvmonkey

    path = tmp_path / "x.csv"
    path.write_bytes(b"a,b\n1,2\n")
    profile = dsvmonkey.profile_file(path)
    profile.quote_char = DetectionResult(
        value="''", confidence=1.0, method="manual"
    )
    with pytest.raises(ValueError, match="quote_char"):
        next(dsvmonkey.read(path, profile=profile))


def test_read_rejects_profile_with_empty_quote_char(tmp_path: Path):
    # Adversarial: empty string passes `is not None` but fails
    # length == 1. Must be caught.
    from dsvmonkey.profile import DetectionResult
    import dsvmonkey

    path = tmp_path / "x.csv"
    path.write_bytes(b"a,b\n1,2\n")
    profile = dsvmonkey.profile_file(path)
    profile.quote_char = DetectionResult(
        value="", confidence=1.0, method="manual"
    )
    with pytest.raises(ValueError, match="quote_char"):
        next(dsvmonkey.read(path, profile=profile))


def test_read_rejects_profile_with_unknown_encoding(tmp_path: Path):
    # Review finding (#2 High): validation checked encoding
    # PRESENCE but not that the codec name actually exists.
    # `Path.open(encoding="ut-8")` raises LookupError, a different
    # exception type from the rest of the boundary guards.
    from dsvmonkey.profile import DetectionResult
    import dsvmonkey

    path = tmp_path / "x.csv"
    path.write_bytes(b"a,b\n1,2\n")
    profile = dsvmonkey.profile_file(path)
    profile.encoding = DetectionResult(
        value="ut-8", confidence=1.0, method="manual"
    )
    with pytest.raises(ValueError, match="not a recognised codec"):
        next(dsvmonkey.read(path, profile=profile))


def test_read_rejects_profile_with_string_header_row_value(tmp_path: Path):
    # Review finding (#3 Medium): `_rows_to_skip` does
    # `header_row.value + 1` unguarded. A string "0" passes
    # "not None" but fails the addition with TypeError. Validate
    # the type at the boundary.
    from dsvmonkey.profile import DetectionResult
    import dsvmonkey

    path = tmp_path / "x.csv"
    path.write_bytes(b"a,b\n1,2\n")
    profile = dsvmonkey.profile_file(path)
    profile.header_row = DetectionResult(
        value="0", confidence=1.0, method="manual"
    )
    with pytest.raises(ValueError, match="header_row.value"):
        next(dsvmonkey.read(path, profile=profile))


def test_read_rejects_profile_with_negative_header_row_value(tmp_path: Path):
    # Adversarial: negative header_row index would also produce
    # wrong behaviour (skip_rows = -5 + 1 = -4, range(-4) is empty,
    # so nothing is skipped and the header leaks into data rows).
    # Caught at the boundary.
    from dsvmonkey.profile import DetectionResult
    import dsvmonkey

    path = tmp_path / "x.csv"
    path.write_bytes(b"a,b\n1,2\n")
    profile = dsvmonkey.profile_file(path)
    profile.header_row = DetectionResult(
        value=-5, confidence=1.0, method="manual"
    )
    with pytest.raises(ValueError, match="non-negative"):
        next(dsvmonkey.read(path, profile=profile))


def test_read_accepts_full_precomputed_profile_with_none_quote(tmp_path: Path):
    # Negative case: a profile whose quote_char is None (legitimate
    # "no quoting") must NOT be rejected. This is the common case
    # for QUOTE_NONE files.
    import dsvmonkey

    path = tmp_path / "x.csv"
    path.write_bytes(b"id,name\n1,alice\n")
    profile = dsvmonkey.profile_file(path)
    profile.quote_char = None  # legitimate "no quoting"
    rows = list(dsvmonkey.read(path, profile=profile))
    assert rows == [{"id": "1", "name": "alice"}]


def test_read_deep_scan_flag_skips_full_file_pass(tmp_path: Path, monkeypatch):
    # Review finding (#4 Medium): `read()` used to call
    # profile_file() without exposing deep_scan, forcing the
    # full-file mixed-encoding pass on every call without a
    # precomputed profile. Large or remote files paid for the
    # scan whether the caller wanted it or not. `deep_scan=False`
    # now threads through.
    import dsvmonkey
    from dsvmonkey import orchestrate as orch_mod

    path = tmp_path / "x.csv"
    path.write_bytes(b"id,name\n1,alice\n2,bob\n")

    calls = {"n": 0}
    real_scan = orch_mod.scan_file_mixed_encoding

    def counting_scan(*a, **kw):
        calls["n"] += 1
        return real_scan(*a, **kw)

    # Patch the reference orchestrate.py actually uses — the
    # module imports `scan_file_mixed_encoding` at load time, so
    # patching at the detectors module is too late.
    monkeypatch.setattr(orch_mod, "scan_file_mixed_encoding", counting_scan)

    # Default: scan runs.
    list(dsvmonkey.read(path))
    default_count = calls["n"]
    assert default_count >= 1

    # With deep_scan=False: scan is skipped.
    calls["n"] = 0
    list(dsvmonkey.read(path, deep_scan=False))
    assert calls["n"] == 0


def test_read_rejects_profile_with_reserved_delimiter(tmp_path: Path):
    # Same pattern as the target_delimiter reserved-char guard: a
    # caller-crafted profile with delimiter=\n or \" would produce
    # unparseable output. Library-boundary error matches the
    # target_delimiter behaviour for consistency.
    from dsvmonkey.profile import DetectionResult
    import dsvmonkey

    path = tmp_path / "x.csv"
    path.write_bytes(b"a,b\n1,2\n")
    profile = dsvmonkey.profile_file(path)
    profile.delimiter = DetectionResult(value="\n", confidence=1.0, method="manual")

    with pytest.raises(ValueError, match="reserved"):
        next(dsvmonkey.read(path, profile=profile))


def test_read_accepts_full_precomputed_profile(tmp_path: Path):
    # Negative case: a profile returned by profile_file() works
    # unmodified. Validation doesn't false-positive on the normal
    # happy path.
    import dsvmonkey

    path = tmp_path / "x.csv"
    path.write_bytes(b"id,name\n1,alice\n")
    profile = profile_file(path)
    rows = list(dsvmonkey.read(path, profile=profile))
    assert rows == [{"id": "1", "name": "alice"}]


def test_clean_utf8_csv():
    data = b"id,name,age\n1,alice,30\n2,bob,25\n3,carol,40\n"
    profile = profile_bytes(data)
    assert profile.encoding.value == "utf-8"
    assert profile.delimiter.value == ","
    assert profile.quote_char.value is None
    assert profile.line_ending.value == "\n"
    assert profile.header_row.value == 0
    assert profile.headers == ["id", "name", "age"]
    assert profile.field_count == 3
    assert not profile.issues


def test_utf8_bom_gets_stripped_from_first_header():
    data = "﻿id,name,age\n1,alice,30\n2,bob,25\n".encode("utf-8")
    profile = profile_bytes(data)
    assert profile.encoding.value == "utf-8-sig"
    assert profile.has_bom is True
    # The headline regression this guards against: a stray ﻿ glued
    # to the first header name breaks every downstream dict lookup.
    assert profile.headers is not None
    assert profile.headers[0] == "id"
    assert not profile.headers[0].startswith("﻿")


def test_semicolon_windows_export_with_decorative_title():
    # European semicolon-delimited export, \r\n endings, title on row 0.
    body = (
        "Sales Report Q4 2024;;;\r\n"
        "\r\n"
        "id;product;qty;price\r\n"
        "1;widget;10;2,50\r\n"
        "2;gadget;5;9,99\r\n"
        "3;sprocket;20;1,25\r\n"
    )
    profile = profile_bytes(body.encode("utf-8"))
    assert profile.delimiter.value == ";"
    assert profile.line_ending.value == "\r\n"
    assert profile.header_row.value == 2
    assert profile.headers == ["id", "product", "qty", "price"]


def test_tab_delimited_with_quoted_fields():
    data = (
        'id\tname\tnote\n'
        '1\t"alice"\t"admin, full access"\n'
        '2\t"bob"\t"user"\n'
        '3\t"carol"\t"auditor"\n'
    ).encode("utf-8")
    profile = profile_bytes(data)
    assert profile.delimiter.value == "\t"
    assert profile.quote_char.value == '"'
    assert profile.header_row.value == 0


def test_pipe_delimited_with_embedded_commas():
    data = (
        "id|description|tags\n"
        "1|hello, world|a;b\n"
        "2|foo, bar|x;y\n"
        "3|baz, qux|p;q\n"
    ).encode("utf-8")
    profile = profile_bytes(data)
    assert profile.delimiter.value == "|"
    assert profile.header_row.value == 0


def test_cp1252_file_with_smart_quotes_is_read():
    # 0x92 = cp1252 right single quote, not valid utf-8.
    data = (
        "id,name,note\n"
        "1,alice,don\x92t worry\n"
        "2,bob,it\x92s fine\n"
        "3,carol,can\x92t complain\n"
        "4,dave,won\x92t bite\n"
    ).encode("latin-1")  # latin-1 round-trips cp1252 byte 0x92
    profile = profile_bytes(data)
    # Must not pick utf-8 (those bytes don't decode as utf-8).
    assert profile.encoding.value != "utf-8"
    assert profile.delimiter.value == ","
    assert profile.header_row.value == 0


def test_missing_headers_flagged():
    data = (
        "1,100,50\n"
        "2,200,75\n"
        "3,300,25\n"
        "4,400,90\n"
        "5,500,10\n"
    ).encode("utf-8")
    profile = profile_bytes(data)
    assert profile.header_row.value is None
    assert profile.headers is None
    # field_count should still be inferred from the first data row.
    assert profile.field_count == 3


def test_mixed_encoding_flag_set():
    # Mixed-encoding detection now requires positive UTF-8 evidence
    # — at least one valid multi-byte sequence — before flagging, so
    # a pure-ASCII file with a stray byte isn't mistaken for a
    # corrupted UTF-8 file. This data has real UTF-8 multi-byte chars
    # (é, ï, é) in the head and tail plus an isolated non-UTF-8 byte.
    head = "id,name,note\ncafé,naïve,résumé\n".encode("utf-8") * 5
    tail = "more,utf8,rows\nolé,piñata,jalapeño\n".encode("utf-8") * 5
    data = head + b"\x92" + tail
    profile = profile_bytes(data)
    assert profile.mixed_encoding_suspected is True
    assert any("mixed encoding" in issue for issue in profile.issues)


def test_profile_file_reads_from_disk(tmp_path: Path):
    path = tmp_path / "sample.csv"
    path.write_bytes(b"id,name\n1,alice\n2,bob\n")
    profile = profile_file(path)
    assert profile.path == path
    assert profile.delimiter.value == ","
    assert profile.headers == ["id", "name"]


def test_profile_file_accepts_string_path(tmp_path: Path):
    path = tmp_path / "sample.csv"
    path.write_bytes(b"a,b,c\n1,2,3\n4,5,6\n")
    profile = profile_file(str(path))
    assert profile.delimiter.value == ","


# ---------- Review findings: scan gating and opt-out ----------


def test_cp1252_file_with_sparse_smart_quote_is_not_flagged_mixed(tmp_path: Path):
    # Review finding: scan_file_mixed_encoding is UTF-8-centric
    # ("mostly UTF-8 with sparse bad bytes"), so running it on a
    # cp1252 file with a small number of cp1252 bytes used to mis-
    # flag the file as mixed. The correct interpretation is: this
    # file just isn't UTF-8.
    data = b"id,name,note\n" + b"1,alice,a quiet day\n" * 200 + b"2,bob,it\x92s fine\n"
    path = tmp_path / "cp1252-sparse.csv"
    path.write_bytes(data)

    profile = profile_file(path)
    # Detection should pick cp1252 / latin-1 / similar — not UTF-8.
    assert profile.encoding.value not in {"utf-8", "utf-8-sig"}
    # And because the base encoding isn't UTF-8, the mixed-encoding
    # scan should not have run.
    assert profile.mixed_encoding_suspected is False


def test_utf8_file_with_late_stray_byte_is_still_flagged(tmp_path: Path):
    # Companion to the cp1252-sparse test: a genuinely UTF-8 file
    # (real multi-byte sequences) with a concatenation stray byte
    # past the sample window must still be caught.
    path = tmp_path / "late.csv"
    head = ("id,name\n" + "1,café\n" * 40000).encode("utf-8")
    assert len(head) > 260_000
    path.write_bytes(head + b"\x92" + b"2,bob\n" * 10)

    profile = profile_file(path)
    assert profile.encoding.value == "utf-8"
    assert profile.mixed_encoding_suspected is True


def test_profile_file_reports_actual_file_size_not_sample_size(tmp_path: Path):
    # Review finding: file_size used to reflect the sample buffer
    # length. For any file larger than the sample, inspect printed
    # the wrong size. Now populated from path.stat().st_size.
    path = tmp_path / "big.csv"
    body = b"a,b\n" + b"1,2\n" * 100_000  # ~600 KB, larger than default sample
    path.write_bytes(body)
    actual = path.stat().st_size

    profile = profile_file(path, sample_size=16384, deep_scan=False)
    assert profile.file_size == actual
    # sample_bytes still reflects the bounded read.
    assert profile.sample_bytes == 16384


def test_profile_file_honors_sample_size_bound(tmp_path: Path):
    # Review finding: the old code read `max(sample_size*4, 262_144)`
    # bytes, so passing `sample_size=16384` actually pulled 256 KiB
    # off disk. Callers tuning sample_size for bounded I/O must now
    # get exactly what they ask for.
    path = tmp_path / "big.csv"
    # Build a file much larger than the sample we're going to ask for.
    path.write_bytes(b"a,b\n" + b"1,2\n" * 500_000)

    read_sizes: list[int] = []

    from pathlib import Path as _P
    orig_open = _P.open

    def tracking_open(self, mode="r", *args, **kwargs):
        fh = orig_open(self, mode, *args, **kwargs)
        if "b" in mode:
            inner_read = fh.read
            def counting_read(n: int = -1) -> bytes:
                data = inner_read(n)
                read_sizes.append(len(data))
                return data
            fh.read = counting_read  # type: ignore[method-assign]
        return fh

    _P.open = tracking_open
    try:
        profile_file(path, sample_size=16384, deep_scan=False)
    finally:
        _P.open = orig_open

    # First (and only, with deep_scan=False) read should be exactly
    # the requested size — no 4x multiplier, no 256 KiB floor.
    assert read_sizes, "no byte reads observed"
    assert read_sizes[0] == 16384, (
        f"expected 16384 bytes read, got {read_sizes[0]}"
    )


def test_deep_scan_false_skips_full_file_pass(tmp_path: Path):
    # Review finding (perf): profile_file() does a second full-file
    # read when deep_scan is True. Callers with large or remote files
    # can opt out; the profile is then based on the bounded sample
    # only and late-file corruption is reported as not-suspected.
    path = tmp_path / "late.csv"
    head = ("id,name\n" + "1,café\n" * 40000).encode("utf-8")
    path.write_bytes(head + b"\x92" + b"2,bob\n" * 10)

    shallow = profile_file(path, deep_scan=False)
    deep = profile_file(path, deep_scan=True)

    # Shallow pass can't see the stray byte past the sample window.
    assert shallow.mixed_encoding_suspected is False
    # Deep pass does.
    assert deep.mixed_encoding_suspected is True


def test_long_preamble_does_not_starve_delimiter_detection(tmp_path: Path):
    # Review finding (Medium): the parsed-row cap was 100. A file
    # with a 200-row metadata preamble (common in regulated-industry
    # exports — disclaimers, run metadata, environment dump) used
    # the entire budget on preamble lines and never reached the
    # data block, leading to a silent "single-column" misclassification.
    # The cap was bumped to 1000 so realistic preambles can't starve
    # the scorer. Pin a 250-row preamble + small CSV body and check
    # the delimiter is still detected as a comma with
    # field-count-consistency.
    preamble = b"# meta line with no delimiter at all\n" * 250
    body = b"id,name,age\n1,alice,30\n2,bob,25\n3,carol,40\n"
    path = tmp_path / "preamble.csv"
    path.write_bytes(preamble + body)

    profile = profile_file(path)
    assert profile.delimiter.value == ","
    assert profile.delimiter.method == "field-count-consistency", (
        f"expected csv classification despite long preamble, got "
        f"method={profile.delimiter.method!r}"
    )
