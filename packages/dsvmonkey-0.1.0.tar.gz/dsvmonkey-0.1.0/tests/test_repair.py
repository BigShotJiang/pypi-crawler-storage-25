import csv
from pathlib import Path

import pytest

import dsvmonkey
from dsvmonkey.profile import DSVProfile
from dsvmonkey.repair import (
    _apply_clean,
    _differs,
    _normalize_encoding_name,
    _resolve_field_count,
)


def _read_raw(path: Path) -> bytes:
    return path.read_bytes()


# ---------- Happy path: clean in, clean out ----------


def test_clean_file_passes_through(tmp_path: Path):
    src = tmp_path / "clean.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name\n1,alice\n2,bob\n")

    report = dsvmonkey.repair(src, dst)

    assert report.rows_read == 2
    # Data rows only — header is surfaced separately.
    assert report.rows_written == 2
    assert report.header_written is True
    assert report.short_rows_padded == 0
    assert report.long_rows_truncated == 0
    assert report.bom_stripped is False
    with dst.open() as f:
        rows = list(csv.reader(f))
    assert rows == [["id", "name"], ["1", "alice"], ["2", "bob"]]


# ---------- BOM stripping ----------


def test_bom_is_stripped_on_output(tmp_path: Path):
    src = tmp_path / "bom.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes("﻿id,name\n1,alice\n2,bob\n".encode("utf-8"))

    report = dsvmonkey.repair(src, dst)

    assert report.bom_stripped is True
    # Output must not start with BOM bytes.
    out_bytes = _read_raw(dst)
    assert not out_bytes.startswith(b"\xef\xbb\xbf")
    assert out_bytes.startswith(b"id,")


# Contract: the docstring promises "no BOM" by default. The reader's
# _open_text already knows UTF-16/UTF-32 endian codecs don't consume
# their own BOM; repair() must apply the same remap or a literal
# `﻿` leaks into the first cell of the repaired output — the very
# thing the report's `bom_stripped=True` flag claims we handled.
def test_utf16_le_bom_does_not_leak_into_repair_output(tmp_path: Path):
    src = tmp_path / "utf16le.csv"
    dst = tmp_path / "out.csv"
    text = "id,name\n1,alice\n2,bob\n"
    src.write_bytes(b"\xff\xfe" + text.encode("utf-16-le"))

    report = dsvmonkey.repair(src, dst, clean_cells=False)

    # Report claims the BOM was stripped.
    assert report.bom_stripped is True
    # And the output had better honour that claim.
    out_text = dst.read_text(encoding="utf-8")
    assert "﻿" not in out_text
    out_bytes = _read_raw(dst)
    # No UTF-8 BOM sneaking back in either.
    assert not out_bytes.startswith(b"\xef\xbb\xbf")
    assert out_bytes.startswith(b"id,")
    # Structurally round-trippable.
    with dst.open(encoding="utf-8") as f:
        rows = list(csv.reader(f))
    assert rows == [["id", "name"], ["1", "alice"], ["2", "bob"]]


def test_utf16_be_bom_does_not_leak_into_repair_output(tmp_path: Path):
    src = tmp_path / "utf16be.csv"
    dst = tmp_path / "out.csv"
    text = "id,name\n1,alice\n2,bob\n"
    src.write_bytes(b"\xfe\xff" + text.encode("utf-16-be"))

    report = dsvmonkey.repair(src, dst, clean_cells=False)

    assert report.bom_stripped is True
    out_text = dst.read_text(encoding="utf-8")
    assert "﻿" not in out_text
    with dst.open(encoding="utf-8") as f:
        rows = list(csv.reader(f))
    assert rows[0] == ["id", "name"]
    assert rows[1] == ["1", "alice"]


def test_utf32_le_bom_does_not_leak_into_repair_output(tmp_path: Path):
    src = tmp_path / "utf32le.csv"
    dst = tmp_path / "out.csv"
    text = "id,name\n1,alice\n"
    src.write_bytes(b"\xff\xfe\x00\x00" + text.encode("utf-32-le"))

    report = dsvmonkey.repair(src, dst, clean_cells=False)

    assert report.bom_stripped is True
    out_text = dst.read_text(encoding="utf-8")
    assert "﻿" not in out_text


def test_utf32_be_bom_does_not_leak_into_repair_output(tmp_path: Path):
    src = tmp_path / "utf32be.csv"
    dst = tmp_path / "out.csv"
    text = "id,name\n1,alice\n"
    src.write_bytes(b"\x00\x00\xfe\xff" + text.encode("utf-32-be"))

    report = dsvmonkey.repair(src, dst, clean_cells=False)

    assert report.bom_stripped is True
    out_text = dst.read_text(encoding="utf-8")
    assert "﻿" not in out_text


def test_utf16_le_bom_first_cell_clean_even_without_cleanmonkey(tmp_path: Path):
    # Adversarial version of the motivating bug: no header row to
    # absorb the leak, clean_cells=False so cleanmonkey can't hide
    # the problem. A literal BOM in cell[0][0] is what we're guarding
    # against.
    src = tmp_path / "noheader.csv"
    dst = tmp_path / "out.csv"
    text = "1,alice\n2,bob\n"
    src.write_bytes(b"\xff\xfe" + text.encode("utf-16-le"))

    profile = dsvmonkey.profile_file(src)
    # Force "no header" so whatever was in position (0, 0) shows up
    # directly in the first data row of the output.
    profile.headers = None
    profile.header_row.value = None

    dsvmonkey.repair(src, dst, profile=profile, clean_cells=False, write_header=False)

    with dst.open(encoding="utf-8") as f:
        rows = list(csv.reader(f))
    # First cell is the literal digit "1", not "﻿1".
    assert rows[0][0] == "1"
    assert "﻿" not in rows[0][0]


def test_read_and_repair_agree_on_utf16_bom_contents(tmp_path: Path):
    # Cross-API consistency: whatever read() yields, repair() must
    # write. Previously repair() leaked a BOM that read() stripped.
    src = tmp_path / "utf16le.csv"
    dst = tmp_path / "out.csv"
    text = "id,name\n1,alice\n2,bob\n"
    src.write_bytes(b"\xff\xfe" + text.encode("utf-16-le"))

    read_rows = list(dsvmonkey.read(src, as_dict=False, clean=False))
    dsvmonkey.repair(src, dst, clean_cells=False)
    with dst.open(encoding="utf-8") as f:
        repair_rows = list(csv.reader(f))
    # repair() writes the header as its first row; read() skips it.
    assert repair_rows[1:] == read_rows


# ---------- Line-ending normalization ----------


def test_crlf_is_normalized_to_lf_by_default(tmp_path: Path):
    src = tmp_path / "crlf.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name\r\n1,alice\r\n2,bob\r\n")

    report = dsvmonkey.repair(src, dst)

    assert report.line_ending_changed is True
    out_bytes = _read_raw(dst)
    assert b"\r\n" not in out_bytes
    assert out_bytes.count(b"\n") == 3


def test_mixed_line_endings_reported_as_changed_even_when_dominant_matches_target(
    tmp_path: Path,
):
    # Review finding: a file with mostly `\n` plus some `\r\n` rows
    # gets normalised during write (csv.writer emits one terminator),
    # but `line_ending_changed` used to stay False because the
    # dominant detected value (`\n`) equalled the default target
    # (`\n`). Observability drift in a data-quality tool.
    src = tmp_path / "mixed.csv"
    dst = tmp_path / "out.csv"
    # 3 of 4 lines with \n, 1 with \r\n. Detector picks \n as
    # dominant (≥75%), target defaults to \n.
    src.write_bytes(b"id,name\n1,alice\n2,bob\r\n3,carol\n")

    report = dsvmonkey.repair(src, dst)

    # Dominant matches target, but mixed-endings warning on the
    # detector means the write DID normalise something.
    assert report.line_ending_changed is True


def test_uniform_line_endings_reported_as_unchanged(tmp_path: Path):
    # Negative case: a file that's uniformly one ending and matches
    # the target must NOT be reported as changed. The mixed-endings
    # signal only fires when there are actually multiple endings.
    src = tmp_path / "clean.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name\n1,alice\n2,bob\n3,carol\n")
    report = dsvmonkey.repair(src, dst)
    assert report.line_ending_changed is False


def test_preserve_crlf_when_asked(tmp_path: Path):
    src = tmp_path / "unix.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name\n1,alice\n2,bob\n")

    report = dsvmonkey.repair(src, dst, target_line_ending="\r\n")

    assert report.line_ending_changed is True
    out_bytes = _read_raw(dst)
    assert out_bytes.count(b"\r\n") == 3


# ---------- Ragged row repair ----------


def test_short_rows_are_padded(tmp_path: Path):
    src = tmp_path / "short.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name,age\n1,alice,30\n2,bob\n3,carol,40\n")

    report = dsvmonkey.repair(src, dst)

    assert report.short_rows_padded == 1
    with dst.open() as f:
        rows = list(csv.reader(f))
    # bob's row was padded to 3 cells.
    assert rows[2] == ["2", "bob", ""]


def test_long_rows_are_truncated(tmp_path: Path):
    src = tmp_path / "long.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name\n1,alice,extra1,extra2\n2,bob\n")

    report = dsvmonkey.repair(src, dst)

    assert report.long_rows_truncated == 1
    with dst.open() as f:
        rows = list(csv.reader(f))
    assert rows[1] == ["1", "alice"]


def test_target_field_count_overrides_detection(tmp_path: Path):
    src = tmp_path / "wide.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name\n1,alice\n2,bob\n")

    report = dsvmonkey.repair(src, dst, target_field_count=4)

    # Header gets padded too, but isn't counted as data in the report.
    assert report.short_rows_padded == 2  # both data rows
    with dst.open() as f:
        rows = list(csv.reader(f))
    assert all(len(r) == 4 for r in rows)


# ---------- Empty-row handling ----------


def test_whitespace_only_rows_are_skipped(tmp_path: Path):
    # Review finding: `not any(cell for cell in row)` is True only
    # when every cell is the empty string; a row like ["  ", "\t"]
    # has truthy cells and survived into the output as empty cells
    # after cleanmonkey strips them. Users expect normalize to drop
    # blank lines regardless of invisible padding.
    src = tmp_path / "ws.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name\n1,alice\n   ,   \n2,bob\n\t,\t\n3,carol\n")

    report = dsvmonkey.repair(src, dst)

    assert report.empty_rows_skipped == 2
    with dst.open() as f:
        rows = list(csv.reader(f))
    # Only the header + 3 data rows — no `['', '']` survivors.
    assert rows == [
        ["id", "name"],
        ["1", "alice"],
        ["2", "bob"],
        ["3", "carol"],
    ]


def test_empty_rows_are_skipped(tmp_path: Path):
    src = tmp_path / "spacey.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name\n1,alice\n\n2,bob\n\n3,carol\n")

    report = dsvmonkey.repair(src, dst)

    assert report.empty_rows_skipped >= 2
    with dst.open() as f:
        rows = list(csv.reader(f))
    # Header + 3 data rows; the blank lines are gone.
    assert len(rows) == 4


# ---------- Delimiter change ----------


def test_convert_csv_to_tsv(tmp_path: Path):
    src = tmp_path / "in.csv"
    dst = tmp_path / "out.tsv"
    src.write_bytes(b"id,name,age\n1,alice,30\n2,bob,25\n")

    report = dsvmonkey.repair(src, dst, target_delimiter="\t")

    assert report.delimiter_changed is True
    out_text = dst.read_text()
    assert "\t" in out_text
    assert "," not in out_text.splitlines()[0]


# ---------- Cell cleaning in the output ----------


def test_invisible_chars_cleaned_in_output_by_default(tmp_path: Path):
    src = tmp_path / "zwsp.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes("id,status\n1,Active​\n2,Active\n".encode("utf-8"))

    dsvmonkey.repair(src, dst)

    out_text = dst.read_text()
    # Zero-width space gone from the repaired output.
    assert "​" not in out_text


def test_clean_cells_false_preserves_bytes(tmp_path: Path):
    src = tmp_path / "zwsp.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes("id,status\n1,Active​\n".encode("utf-8"))

    dsvmonkey.repair(src, dst, clean_cells=False)

    out_text = dst.read_text()
    assert "​" in out_text


# ---------- Dry run ----------


def test_dry_run_produces_report_without_writing(tmp_path: Path):
    # Contract: output_path=None is the unambiguous "no file
    # written" signal. The `rows_written` / `header_written`
    # counters carry the "what WOULD be written" semantic so
    # preview/monitoring callers get useful numbers from a dry
    # run. Previously these stayed at 0/False in dry-run,
    # misleading any caller comparing dry-run throughput against
    # expected counts.
    src = tmp_path / "src.csv"
    src.write_bytes(b"id,name\n1,alice\n2,bob\n3,carol\n")

    report = dsvmonkey.repair(src, None)

    assert report.output_path is None  # no file written
    assert report.rows_read == 3
    # Would-write counters reflect the preview, not "zero output."
    assert report.rows_written == 3
    assert report.header_written is True
    # Invariant on the normal write path still holds in dry-run:
    # rows_read == rows_written + empty_rows_skipped.
    assert (
        report.rows_read == report.rows_written + report.empty_rows_skipped
    )


def test_dry_run_no_header_written_when_write_header_false(tmp_path: Path):
    # Negative case: header_written reflects what WOULD happen
    # under the current settings, not just whether a header
    # exists. With write_header=False, a dry-run report must
    # show header_written=False even if the input has a header.
    src = tmp_path / "src.csv"
    src.write_bytes(b"id,name\n1,alice\n2,bob\n")

    report = dsvmonkey.repair(src, None, write_header=False)
    assert report.header_written is False
    assert report.rows_written == 2


def test_dry_run_counts_padded_and_truncated_rows(tmp_path: Path):
    # Preview counters should include the same
    # short_rows_padded / long_rows_truncated / empty_rows_skipped
    # numbers the real write produces. Pinned so preview + real
    # write stay consistent.
    src = tmp_path / "ragged.csv"
    src.write_bytes(
        b"id,name,age\n"
        b"1,alice\n"         # short
        b"2,bob,30,extra\n"  # long
        b"   ,  ,  \n"        # whitespace-only: dropped
        b"3,carol,25\n"
    )

    dry = dsvmonkey.repair(src, None)
    dst = tmp_path / "out.csv"
    real = dsvmonkey.repair(src, dst)

    # Preview numbers must match the real run exactly.
    assert dry.rows_read == real.rows_read
    assert dry.rows_written == real.rows_written
    assert dry.header_written == real.header_written
    assert dry.short_rows_padded == real.short_rows_padded
    assert dry.long_rows_truncated == real.long_rows_truncated
    assert dry.empty_rows_skipped == real.empty_rows_skipped


# ---------- Missing header files ----------


# ---------- Regression: width fallback of 1 collapsed rows ----------


def test_unresolved_field_count_does_not_collapse_rows_to_one_column(tmp_path: Path):
    # Review finding: _resolve_field_count used to return 1 when the
    # profile couldn't give a value, which then truncated every
    # multi-column row down to the first cell during normalize/
    # convert. The fallback now defers to the first streamed data
    # row's width.
    src = tmp_path / "in.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"a,b,c\n1,2,3\n4,5,6\n")

    profile = dsvmonkey.profile_file(src)
    profile.headers = None
    profile.field_count = None
    profile.header_row.value = None

    report = dsvmonkey.repair(src, dst, profile=profile, write_header=False)

    with dst.open() as f:
        rows = list(csv.reader(f))
    # Three rows preserved at three columns each.
    assert rows == [["a", "b", "c"], ["1", "2", "3"], ["4", "5", "6"]]
    # No rogue truncation reported.
    assert report.long_rows_truncated == 0
    assert report.short_rows_padded == 0


# ---------- In-place write safety ----------


# ---------- target_field_count / target_delimiter library-level guards ----------
#
# The CLI already validates these, but direct Python-API callers were
# previously exposed: repair(target_field_count=0) silently truncated
# every row to an empty list via `row[:0]`, and
# repair(target_delimiter="||") raised a deep csv.writer TypeError.


def test_repair_rejects_zero_target_field_count(tmp_path: Path):
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"a,b\n1,2\n")
    with pytest.raises(ValueError, match="positive integer"):
        dsvmonkey.repair(src, dst, target_field_count=0)
    # Guard runs before any output is written.
    assert not dst.exists()


def test_repair_rejects_negative_target_field_count(tmp_path: Path):
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"a,b,c\n1,2,3\n")
    with pytest.raises(ValueError, match="positive integer"):
        dsvmonkey.repair(src, dst, target_field_count=-1)
    assert not dst.exists()


def test_repair_accepts_target_field_count_of_one(tmp_path: Path):
    # Boundary: 1 is the smallest legitimate width.
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,extra\n1,drop\n2,drop\n")
    report = dsvmonkey.repair(src, dst, target_field_count=1)
    assert report.long_rows_truncated == 2
    with dst.open() as f:
        rows = list(csv.reader(f))
    assert all(len(r) == 1 for r in rows)


def test_repair_rejects_multicharacter_target_delimiter(tmp_path: Path):
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"a,b\n1,2\n")
    with pytest.raises(ValueError, match="single character"):
        dsvmonkey.repair(src, dst, target_delimiter="||")
    assert not dst.exists()


def test_repair_rejects_non_string_target_delimiter(tmp_path: Path):
    # Review finding (#2): a non-string arg (e.g. int from a wrapper
    # that forgot to stringify) previously hit len(42) with
    # TypeError — inconsistent with the ValueError every other
    # target validator produces. Caught as ValueError now.
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"a,b\n1,2\n")
    with pytest.raises(ValueError, match="must be a string"):
        dsvmonkey.repair(src, dst, target_delimiter=42)  # type: ignore[arg-type]


def test_repair_rejects_non_string_target_encoding(tmp_path: Path):
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"a,b\n1,2\n")
    with pytest.raises(ValueError, match="must be a string"):
        dsvmonkey.repair(src, dst, target_encoding=42)  # type: ignore[arg-type]


def test_repair_rejects_empty_target_delimiter(tmp_path: Path):
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"a,b\n1,2\n")
    with pytest.raises(ValueError, match="single character"):
        dsvmonkey.repair(src, dst, target_delimiter="")
    assert not dst.exists()


def test_repair_rejects_newline_as_target_delimiter(tmp_path: Path):
    # Review finding (#5): `\n` passes the "single character" check
    # but reserves the row-terminator role; writing with it
    # produces output csv.reader can't parse back. Easy to trip
    # on in automation (line-ending value piped into delimiter
    # arg). Must be rejected at validation time.
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"a,b\n1,2\n")
    with pytest.raises(ValueError, match="reserved"):
        dsvmonkey.repair(src, dst, target_delimiter="\n")
    assert not dst.exists()


def test_repair_rejects_quote_as_target_delimiter(tmp_path: Path):
    # `"` is the other structurally-reserved character.
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"a,b\n1,2\n")
    with pytest.raises(ValueError, match="reserved"):
        dsvmonkey.repair(src, dst, target_delimiter='"')
    assert not dst.exists()


def test_atomic_writer_cleanup_does_not_mask_original_exception(
    tmp_path: Path, monkeypatch
):
    # Review finding (#5): the temp-file cleanup in
    # _atomic_text_writer used to suppress only FileNotFoundError.
    # If the unlink itself raised something else
    # (PermissionError on Windows, race-condition errors on
    # network mounts), that secondary error replaced the
    # original exception's traceback context — bad for diagnosis
    # of the primary failure. Now suppresses every OSError so
    # the original error always propagates intact.
    import importlib
    from pathlib import Path as _Path

    repair_mod = importlib.import_module("dsvmonkey.repair")

    src = tmp_path / "f.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name\n1,alice\n")

    # Force csv.writer to raise the *real* failure we want to see.
    real_writer = repair_mod.csv.writer

    class _ExplodingWriter:
        def __init__(self, *a, **kw):
            self._inner = real_writer(*a, **kw)

        def writerow(self, row):
            raise RuntimeError("ORIGINAL_FAILURE")

    monkeypatch.setattr(repair_mod.csv, "writer", _ExplodingWriter)

    # And force the temp unlink to raise PermissionError —
    # simulating a Windows-style race or restricted-mount cleanup
    # failure that would have hidden the original error under
    # the old code.
    real_unlink = _Path.unlink

    def exploding_unlink(self, *a, **kw):
        if str(self).endswith(".partial"):
            raise PermissionError("simulated cleanup failure")
        return real_unlink(self, *a, **kw)

    monkeypatch.setattr(_Path, "unlink", exploding_unlink)

    # The ORIGINAL error must propagate, not the cleanup error.
    with pytest.raises(RuntimeError, match="ORIGINAL_FAILURE"):
        dsvmonkey.repair(src, dst)


def test_repair_writes_are_atomic_on_exception(tmp_path: Path, monkeypatch):
    # Review finding (#3): non-atomic writes risk partial output
    # on interruption. Writes now go to a sibling temp file and
    # os.replace() into the final path on successful close. If
    # the writer raises, the temp is removed and the original
    # path (empty / nonexistent / previous output) is untouched.
    import importlib

    repair_mod = importlib.import_module("dsvmonkey.repair")

    src = tmp_path / "f.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name\n1,alice\n2,bob\n3,carol\n")

    # Pre-existing output file; atomic writes shouldn't corrupt it
    # if the write crashes mid-stream.
    dst.write_text("PREVIOUS CONTENTS\n", encoding="utf-8")
    original = dst.read_bytes()

    # Simulate a mid-write failure by monkeypatching csv.writer to
    # raise after a few rows.
    import csv as _csv
    real_writer = _csv.writer

    class _ExplodingWriter:
        def __init__(self, *a, **kw):
            self._inner = real_writer(*a, **kw)
            self._count = 0

        def writerow(self, row):
            self._count += 1
            if self._count > 2:
                raise RuntimeError("simulated mid-write failure")
            return self._inner.writerow(row)

    monkeypatch.setattr(repair_mod.csv, "writer", _ExplodingWriter)

    with pytest.raises(RuntimeError, match="simulated"):
        dsvmonkey.repair(src, dst)

    # Destination file must still have its previous contents —
    # atomic write protected it from the partial new output.
    assert dst.read_bytes() == original
    # And no stray temp files in the directory.
    assert not any(
        p.name.startswith(".out.csv.") and p.name.endswith(".partial")
        for p in tmp_path.iterdir()
    )


def test_repair_rejects_unknown_target_encoding(tmp_path: Path):
    # Review finding: CLI validates encoding names via codecs.lookup
    # and converts LookupError into a clean ValueError with exit 2;
    # direct Python-API callers previously got a raw LookupError
    # from inside Path.open, which is inconsistent with the rest of
    # repair's validation surface (all other invalid args raise
    # ValueError).
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"a,b\n1,2\n")
    with pytest.raises(ValueError, match="unknown target_encoding"):
        dsvmonkey.repair(src, dst, target_encoding="ut-8")
    assert not dst.exists()


def test_repair_drops_invisible_only_rows_under_default_cleaning(
    tmp_path: Path,
):
    # Review finding (#1): rows of pure ZWSP or BOM characters
    # passed the empty-row check (str.strip() leaves them as
    # non-whitespace), then cleanmonkey reduced them to empty
    # strings, and they landed in the output as ghost rows of
    # empty cells. The empty-row decision now happens AFTER
    # cleaning, so the repair output is consistent with what
    # users expect from "blank rows dropped, invisibles cleaned."
    zwsp = "​"
    feff = "﻿"
    content = (
        "id,name\n"
        "1,alice\n"
        f"{zwsp},{zwsp}\n"
        "2,bob\n"
        f"{feff},{feff}\n"
        "3,carol\n"
    ).encode("utf-8")
    src = tmp_path / "invis.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(content)

    report = dsvmonkey.repair(src, dst)

    with dst.open() as f:
        rows = list(csv.reader(f))
    # Header + 3 real data rows; invisible-only rows are gone.
    assert rows == [
        ["id", "name"],
        ["1", "alice"],
        ["2", "bob"],
        ["3", "carol"],
    ]
    # And the report accounts for them: 5 rows_read
    # (3 real + 2 invisible), 2 empty_rows_skipped.
    assert report.rows_read == 5
    assert report.empty_rows_skipped == 2


def test_repair_skip_empty_rows_false_preserves_blanks(tmp_path: Path):
    # Review finding: audit / fixed-format contexts need blank rows
    # preserved. `skip_empty_rows=False` opts out of the default
    # ETL-friendly drop behaviour.
    src = tmp_path / "ws.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name\n1,alice\n   ,   \n2,bob\n\t,\t\n3,carol\n")

    report = dsvmonkey.repair(src, dst, skip_empty_rows=False)

    # No rows dropped; the two whitespace-only rows survive.
    assert report.empty_rows_skipped == 0
    # rows_read still counts all data rows (5) including the blanks.
    assert report.rows_read == 5
    assert report.rows_written == 5


def test_repair_sanitize_formulas_neutralizes_leading_trigger_chars(
    tmp_path: Path,
):
    # Review finding: repair() previously wrote cells verbatim. A
    # malicious or unvetted input like `=cmd|' /C calc.exe'!A1`
    # becomes a live formula when the CSV is opened in Excel /
    # Sheets. `sanitize_formulas=True` prepends `'` to each cell
    # beginning with =, +, -, or @ so spreadsheets treat the
    # content as literal text.
    src = tmp_path / "evil.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(
        b"name,formula\n"
        b"alice,=SUM(A:A)\n"
        b"bob,+1+1\n"
        b"carol,-DDE()\n"
        b"dave,@HYPERLINK\n"
        b"eve,benign value\n"
    )

    dsvmonkey.repair(src, dst, sanitize_formulas=True, clean_cells=False)

    with dst.open() as f:
        rows = list(csv.reader(f))
    # Leading trigger chars are prefixed with '; benign cells
    # unchanged.
    assert rows[1][1] == "'=SUM(A:A)"
    assert rows[2][1] == "'+1+1"
    assert rows[3][1] == "'-DDE()"
    assert rows[4][1] == "'@HYPERLINK"
    assert rows[5][1] == "benign value"


def test_repair_sanitize_formulas_neutralizes_leading_invisibles(
    tmp_path: Path,
):
    # Review finding (#2 Medium): lstrip() doesn't remove BOM
    # (U+FEFF) or zero-width chars, so a payload like
    # "﻿=SUM(A:A)" passed `cell.lstrip()[0] == '='` check
    # falsely (the [0] was the BOM). Excel ignores leading
    # invisibles when evaluating, so the formula still ran.
    # The check now skips both whitespace AND Cf / Mn Unicode
    # categories before looking at the trigger character.
    src = tmp_path / "evil.csv"
    dst = tmp_path / "out.csv"
    feff = "﻿"   # ZWNBSP / BOM
    zwsp = "​"   # zero-width space
    zwnj = "‌"   # zero-width non-joiner
    content = (
        "name,formula\n"
        f"alice,{feff}=SUM(A:A)\n"
        f"bob,{zwsp}+1+1\n"
        f"carol,{zwnj}-DDE()\n"
        f"dave,{feff}{zwsp} =mixed\n"  # combined invisibles + space
        "eve,benign\n"
    ).encode("utf-8")
    src.write_bytes(content)

    # clean_cells=False so cleanmonkey can't pre-remove the
    # invisibles — the sanitiser must catch them on its own.
    dsvmonkey.repair(src, dst, sanitize_formulas=True, clean_cells=False)

    with dst.open() as f:
        rows = list(csv.reader(f))
    # Each invisible-prefixed payload is neutralised. The leading
    # invisible is preserved (we only PREFIX, never strip), so
    # round-trip data is unchanged.
    assert rows[1][1].startswith("'") and "=SUM(A:A)" in rows[1][1]
    assert rows[2][1].startswith("'") and "+1+1" in rows[2][1]
    assert rows[3][1].startswith("'") and "-DDE()" in rows[3][1]
    assert rows[4][1].startswith("'") and "=mixed" in rows[4][1]
    assert rows[5][1] == "benign"


def test_repair_sanitize_formulas_neutralizes_leading_whitespace(
    tmp_path: Path,
):
    # Review finding: the original `cell[0] in TRIGGERS` check was
    # bypassed by leading whitespace — Excel and Sheets trim leading
    # whitespace before evaluating, so " =2+2" still ran as a
    # formula. The check now strips leading whitespace before
    # looking at the first character.
    src = tmp_path / "evil.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(
        b'name,formula\n'
        b'alice," =SUM(A:A)"\n'        # leading space
        b'bob,"\t-DDE()"\n'             # leading tab
        b'carol,"   +malicious"\n'      # multiple spaces
        b'dave,benign\n'
    )

    dsvmonkey.repair(src, dst, sanitize_formulas=True, clean_cells=False)

    with dst.open() as f:
        rows = list(csv.reader(f))
    # Whitespace-prefixed triggers are also neutralised — the
    # leading whitespace is preserved in the cell, but `'` is
    # prepended so the spreadsheet sees text, not a formula.
    assert rows[1][1] == "' =SUM(A:A)"
    assert rows[2][1] == "'\t-DDE()"
    assert rows[3][1] == "'   +malicious"
    assert rows[4][1] == "benign"


def test_repair_sanitize_formulas_off_by_default(tmp_path: Path):
    # Data-preservation default: off. The option must be explicitly
    # turned on at the boundary where output crosses into untrusted
    # spreadsheet territory.
    src = tmp_path / "maybe_evil.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"name,formula\nalice,=SUM(A:A)\n")

    dsvmonkey.repair(src, dst, clean_cells=False)

    with dst.open() as f:
        rows = list(csv.reader(f))
    # Unmutated: the `=` is preserved for legitimate formula-carrying
    # pipelines (e.g. CSVs that feed into typemonkey, not Excel).
    assert rows[1][1] == "=SUM(A:A)"


def test_repair_sanitize_formulas_also_neutralizes_header(tmp_path: Path):
    # A header cell that starts with a trigger char is just as
    # dangerous as a data cell. Sanitization applies to both.
    src = tmp_path / "evil_header.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"=evil,name\n1,alice\n")

    dsvmonkey.repair(src, dst, sanitize_formulas=True, clean_cells=False)

    with dst.open() as f:
        rows = list(csv.reader(f))
    assert rows[0][0] == "'=evil"


def test_repair_accepts_known_target_encoding_aliases(tmp_path: Path):
    # Negative case: common aliases (different case, underscore form)
    # that `codecs.lookup` accepts must pass validation — no
    # false-positives on legitimate codec names.
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"a,b\n1,2\n")
    for alias in ("UTF-8", "utf_8", "latin-1", "cp1252"):
        dsvmonkey.repair(src, dst, target_encoding=alias)
        assert dst.exists()
        dst.unlink()


def test_repair_rejects_same_input_output_path(tmp_path: Path):
    # Review finding: repair(path, path) previously opened input for
    # read, then truncated the same inode with `open("w")`. POSIX
    # semantics kept the read fd alive on most filesystems, but the
    # pattern fails on Windows and can silently truncate on NFS /
    # tmpfs / streamed writes. Fail fast with a clear message before
    # either file is touched.
    src = tmp_path / "same.csv"
    src.write_bytes(b"id,name\n1,alice\n")
    original = src.read_bytes()

    with pytest.raises(ValueError, match="same file|same path"):
        dsvmonkey.repair(src, src)

    # Most important: the source was NOT modified.
    assert src.read_bytes() == original


def test_repair_rejects_same_path_even_when_expressed_differently(
    tmp_path: Path,
):
    # Path-normalisation adversarial: "./file.csv" vs "file.csv" both
    # resolve to the same inode. The guard uses Path.resolve() so
    # this is caught too.
    import os

    src = tmp_path / "same.csv"
    src.write_bytes(b"id,name\n1,alice\n")

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        with pytest.raises(ValueError, match="same file|same path"):
            dsvmonkey.repair("same.csv", "./same.csv")
    finally:
        os.chdir(cwd)


def test_repair_different_paths_still_work(tmp_path: Path):
    # Guard must not false-positive on genuinely distinct paths.
    src = tmp_path / "a.csv"
    dst = tmp_path / "b.csv"
    src.write_bytes(b"id,name\n1,alice\n")

    report = dsvmonkey.repair(src, dst)
    assert report.rows_written == 1  # one data row
    assert report.header_written is True
    assert dst.exists()


def test_row_counters_are_directly_comparable(tmp_path: Path):
    # Review finding: rows_read counted only data rows while
    # rows_written included the header, breaking the symmetry any
    # monitoring dashboard expects. Both counters now measure data
    # rows; the invariant is rows_read == rows_written +
    # empty_rows_skipped in the normal write path.
    src = tmp_path / "ws.csv"
    dst = tmp_path / "out.csv"
    # 3 data rows + 2 whitespace-only rows that get skipped.
    src.write_bytes(b"id,name\n1,alice\n   ,   \n2,bob\n\t,\t\n3,carol\n")

    report = dsvmonkey.repair(src, dst)

    assert report.rows_read == 5
    assert report.empty_rows_skipped == 2
    assert report.rows_written == 3
    assert report.header_written is True
    # The symmetric-counter invariant.
    assert report.rows_read == report.rows_written + report.empty_rows_skipped


def test_header_written_false_when_write_header_false(tmp_path: Path):
    # Pin that header_written reflects what actually happened, not
    # whether a header existed in the input.
    src = tmp_path / "f.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name\n1,alice\n2,bob\n")

    report = dsvmonkey.repair(src, dst, write_header=False)

    assert report.header_written is False
    assert report.rows_written == 2


def test_header_written_false_when_input_has_no_header(tmp_path: Path):
    # Headerless file: even though write_header defaults to True,
    # there's nothing to write. header_written must reflect that.
    src = tmp_path / "bare.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"1,100\n2,200\n3,300\n")

    report = dsvmonkey.repair(src, dst)

    assert report.header_written is False
    assert report.rows_written == 3


def test_repair_warns_when_header_index_past_eof(tmp_path: Path):
    # Review finding: read() warns when profile.header_row.value
    # skips past EOF; repair() used to return silently. Same
    # diagnostic now applies on both paths so a monitoring check
    # can catch profile-vs-file mismatches regardless of which
    # entry point the pipeline uses.
    src = tmp_path / "tiny.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"id,name\n1,alice\n")

    profile = dsvmonkey.profile_file(src)
    profile.header_row.value = 99  # way past end of file

    with pytest.warns(UserWarning, match="only"):
        report = dsvmonkey.repair(src, dst, profile=profile)

    # Behaviour unchanged otherwise: no data, no header written.
    assert report.rows_written == 0
    assert report.header_written is False


def test_repair_rejects_hardlinked_same_inode(tmp_path: Path):
    # Review finding (#5): same-file protection now compares inode
    # identity, so hardlinks / bind mounts pointing at the same
    # underlying file are caught even though their resolved paths
    # differ. Skip on Windows where os.link isn't universally
    # supported.
    import os
    if not hasattr(os, "link"):
        pytest.skip("os.link unavailable on this platform")

    src = tmp_path / "real.csv"
    src.write_bytes(b"id,name\n1,alice\n")
    link = tmp_path / "linked.csv"
    try:
        os.link(str(src), str(link))
    except OSError:
        pytest.skip("filesystem doesn't support hardlinks")

    original = src.read_bytes()
    with pytest.raises(ValueError, match="same file|same path"):
        dsvmonkey.repair(src, link)

    # Source unchanged — guard fired before truncating.
    assert src.read_bytes() == original


def test_repair_dry_run_not_affected_by_guard(tmp_path: Path):
    # Dry run passes output_path=None — the guard must short-circuit
    # and let it through.
    src = tmp_path / "f.csv"
    src.write_bytes(b"id,name\n1,alice\n")
    report = dsvmonkey.repair(src, None)
    assert report.rows_read == 1


# ---------- Missing header files ----------


def test_no_header_file_gets_fresh_column_names(tmp_path: Path):
    src = tmp_path / "bare.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"1,100,50\n2,200,75\n3,300,25\n4,400,90\n5,500,10\n")

    report = dsvmonkey.repair(src, dst, write_header=False)

    assert report.profile.header_row.value is None
    with dst.open() as f:
        rows = list(csv.reader(f))
    # No header was written; all 5 rows are data.
    assert len(rows) == 5
    assert rows[0] == ["1", "100", "50"]


# ---------- Contract-driven gap closures ----------


# Gap 12: repair() docstring claims the width fallback is the first
# data row's width when both the override and profile.field_count are
# None. Adversarial shape: first row is 5 wide, second is 3 wide —
# the second must pad up, not be dropped and not pull the first down.
def test_first_data_row_width_pads_subsequent_short_rows(tmp_path: Path):
    src = tmp_path / "ragged.csv"
    dst = tmp_path / "out.csv"
    src.write_bytes(b"a,b,c,d,e\n1,2,3\n")

    profile = dsvmonkey.profile_file(src)
    # Erase both sources of a known width so the fallback branch fires.
    profile.headers = None
    profile.field_count = None
    profile.header_row.value = None

    report = dsvmonkey.repair(
        src,
        dst,
        profile=profile,
        target_field_count=None,
        write_header=False,
    )

    with dst.open() as f:
        rows = list(csv.reader(f))
    # First row established width 5; second padded to width 5.
    assert rows == [["a", "b", "c", "d", "e"], ["1", "2", "3", "", ""]]
    assert report.short_rows_padded == 1
    assert report.long_rows_truncated == 0


# Gap 13: _resolve_field_count has three distinct return paths —
# explicit override (including zero), profile fallback, and None.
def _bare_profile(field_count: int | None) -> DSVProfile:
    """Minimal DSVProfile for exercising _resolve_field_count in isolation."""
    p = DSVProfile(path=Path(""), file_size=0, sample_bytes=0)
    p.field_count = field_count
    return p


def test_resolve_field_count_zero_is_preserved_at_helper_level():
    # Contract at the helper level: override=0 is NOT swallowed by a
    # truthy fallback to the profile's value. The helper preserves
    # caller intent (0 vs None vs positive int). Silent-truncation
    # protection now lives at the public `repair()` boundary — a
    # library caller reaching this helper directly must have opted
    # past that guard intentionally.
    profile = _bare_profile(field_count=7)
    assert _resolve_field_count(profile, 0) == 0


def test_resolve_field_count_uses_profile_when_override_none():
    profile = _bare_profile(field_count=4)
    assert _resolve_field_count(profile, None) == 4


def test_resolve_field_count_returns_none_when_both_unknown():
    # Both override and profile.field_count are None: defer to the
    # first data row (signalled by returning None).
    profile = _bare_profile(field_count=None)
    assert _resolve_field_count(profile, None) is None


# Gap 19: _normalize_encoding_name must be case-insensitive and
# underscore-tolerant for the utf-8-sig remap; other codecs are just
# lowercased and passed through.
def test_normalize_encoding_name_maps_utf8_sig_uppercase():
    assert _normalize_encoding_name("UTF-8-SIG") == "utf-8"


def test_normalize_encoding_name_maps_utf8_sig_mixed_case():
    assert _normalize_encoding_name("Utf-8-Sig") == "utf-8"


def test_normalize_encoding_name_maps_utf8_sig_with_underscores():
    assert _normalize_encoding_name("UTF_8_SIG") == "utf-8"


def test_normalize_encoding_name_passes_unrelated_codecs_through():
    # Adversarial: similarly-shaped name that is NOT utf-8-sig; should
    # only be lowercased, not remapped.
    assert _normalize_encoding_name("UTF-16-LE") == "utf-16-le"


# Gap 20: _differs is a boolean helper — exhaust the truth table and
# pin the None short-circuit that protects report.encoding_changed /
# line_ending_changed from flipping on "no info".
def test_differs_same_strings_false():
    assert _differs("a", "a") is False


def test_differs_different_strings_true():
    assert _differs("a", "b") is True


def test_differs_none_left_is_false():
    # None on either side means "no info" — must NOT flag a change.
    assert _differs(None, "a") is False


def test_differs_none_right_is_false():
    assert _differs("a", None) is False


def test_differs_empty_strings_and_none_mix():
    # Adversarial: empty string is concrete info (not None), so two
    # empties must compare as equal; empty-vs-None must still short
    # circuit to False because one side is None.
    assert _differs("", "") is False
    assert _differs("", None) is False


# Gap 24: _apply_clean with clean_fn=None must be a byte-exact
# passthrough, including invisibles.
def test_apply_clean_none_preserves_invisibles_byte_exact():
    # zero-width space + NBSP + BOM codepoint inside a cell.
    cell = "a​b c﻿d"
    out = _apply_clean(cell, None)
    assert out == cell
    # Belt and braces: each invisible codepoint is still there.
    assert "​" in out
    assert " " in out
    assert "﻿" in out


def test_repair_clean_cells_false_preserves_invisibles_end_to_end(tmp_path: Path):
    # Composed contract at the public boundary: the same invisibles
    # must survive through repair() when the caller opts out of cleaning.
    src = tmp_path / "invis.csv"
    dst = tmp_path / "out.csv"
    # Header has plain cells; data cell carries ZWSP, NBSP, and a BOM
    # codepoint inside the field (not at file start).
    src.write_bytes("id,val\n1,a​b c﻿d\n".encode("utf-8"))

    dsvmonkey.repair(src, dst, clean_cells=False)

    with dst.open(encoding="utf-8") as f:
        rows = list(csv.reader(f))
    assert rows[1] == ["1", "a​b c﻿d"]
