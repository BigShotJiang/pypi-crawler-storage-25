"""Golden-file CLI regression tests.

Per-field assertions on CLI output catch wrong values but miss
formatting drift: a changed header, renamed section, or reordered
field breaks downstream parsers (shell scripts, grep-based
monitoring) without breaking any existing test.

These tests pin the *shape* of the CLI output: the exact lines
printed for a fixed fixture. When a test fails, inspect the diff —
if the new output is intentionally better, update the golden text.
If it's accidental drift, the test caught it.

Non-deterministic fields (the fixture's absolute path, file size if
it varies) are masked with stable placeholders before comparison.
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest

from dsvmonkey.cli import main


# Stable fixture: nothing locale-sensitive, nothing randomized,
# enough rows for date detection to stabilize.
_INSPECT_FIXTURE = (
    b"id,event_date,amount\n"
    b"1,2024-01-15,10\n"
    b"2,2024-02-20,25\n"
    b"3,2024-03-10,40\n"
    b"4,2024-04-05,55\n"
    b"5,2024-05-30,70\n"
)


def _mask_volatile(text: str, fixture_path: Path) -> str:
    # File path varies per tmp_path; normalise to a placeholder so
    # the golden output is stable across runs. Also collapse trailing
    # whitespace on each line (harmless drift).
    masked = text.replace(str(fixture_path), "<FIXTURE>")
    masked = re.sub(r"[ \t]+\n", "\n", masked)
    return masked


def _run(argv: list[str], capsys) -> str:
    rc = main(argv)
    assert rc == 0, f"CLI exited non-zero ({rc}) for argv={argv}"
    return capsys.readouterr().out


# ---------- inspect: default output shape ----------


_EXPECTED_INSPECT_OUTPUT = """\
dsvmonkey inspect report
========================
File:         <FIXTURE>
Size:         101 bytes
Sample:       101 bytes

Encoding: 'utf-8'  (confidence: 1.00, method: content-scored)
  BOM:        no
  Mixed:      no

Delimiter: ','  (confidence: 1.00, method: field-count-consistency)
Quote char: (none)  (confidence: 0.80, method: absent)
Line ending: LF  (confidence: 1.00, method: occurrence-count)

Header row: 0  (confidence: 0.90, method: headeriness-score)
  Columns:    id, event_date, amount
  Field count: 3

Issues: (none)

Columns:
  [0] id  (5 values, 0 empty)
  [1] event_date  (5 values, 0 empty)
       date: ISO 8601 (%Y-%m-%d) — confidence high, match 100%
  [2] amount  (5 values, 0 empty)
"""


def test_inspect_golden_output(tmp_path: Path, capsys):
    # If this test fails, print the diff and decide: is the new output
    # an intentional improvement (update the golden) or accidental
    # drift (fix the source)? Either way, don't silence it.
    fixture = tmp_path / "sales.csv"
    fixture.write_bytes(_INSPECT_FIXTURE)

    got = _run(["inspect", str(fixture)], capsys)
    masked = _mask_volatile(got, fixture)

    assert masked == _EXPECTED_INSPECT_OUTPUT, (
        "CLI inspect output drift. "
        "If intentional, update _EXPECTED_INSPECT_OUTPUT.\n"
        f"--- expected ---\n{_EXPECTED_INSPECT_OUTPUT}"
        f"--- got ---\n{masked}"
    )


# ---------- inspect: verbose adds alternatives, doesn't change shape ----------


def test_inspect_verbose_contains_alternatives_section(tmp_path: Path, capsys):
    # Light-touch shape assertion: -v adds "Alternatives:" lines for
    # detection results that have runner-ups. We don't pin the exact
    # verbose output because encoding candidate scores can shift
    # legitimately as the detector tunes. We DO pin that the flag
    # produces an additive change, not a reshape.
    fixture = tmp_path / "sales.csv"
    fixture.write_bytes(_INSPECT_FIXTURE)

    plain = _run(["inspect", str(fixture)], capsys)
    verbose = _run(["inspect", "-v", str(fixture)], capsys)

    # Every line of plain output (modulo trailing whitespace) must
    # also appear in verbose. -v is additive, not a rewrite.
    plain_lines = set(_mask_volatile(plain, fixture).splitlines())
    verbose_lines = set(_mask_volatile(verbose, fixture).splitlines())
    missing = plain_lines - verbose_lines
    assert not missing, (
        f"-v dropped these lines from the plain report: {missing}"
    )
    # And verbose must add at least one "Alternatives:" line.
    assert any("Alternatives:" in line for line in verbose_lines), (
        "-v didn't add an Alternatives: section"
    )


# ---------- normalize: report output shape ----------


_EXPECTED_NORMALIZE_OUTPUT_TEMPLATE = """\
Input:  <FIXTURE>
Output: <OUTPUT>
Rows read:    5
Rows written: 5 (+ header)
Changes: (none — input was already clean)
"""


def test_normalize_golden_report(tmp_path: Path, capsys):
    fixture = tmp_path / "sales.csv"
    fixture.write_bytes(_INSPECT_FIXTURE)
    out = tmp_path / "out.csv"

    got = _run(["normalize", str(fixture), "-o", str(out)], capsys)
    masked = got.replace(str(fixture), "<FIXTURE>").replace(str(out), "<OUTPUT>")
    masked = re.sub(r"[ \t]+\n", "\n", masked)

    assert masked == _EXPECTED_NORMALIZE_OUTPUT_TEMPLATE


# ---------- normalize: bom-stripping file gets a "BOM stripped" change ----------


def test_normalize_bom_stripped_appears_in_report(tmp_path: Path, capsys):
    # Narrower golden: assert that a specific fixture triggers the
    # "BOM stripped" line. Exact rest of the report isn't pinned here
    # (it's covered by test_normalize_golden_report); we're pinning
    # the CHANGE enumeration format specifically.
    fixture = tmp_path / "bom.csv"
    fixture.write_bytes(b"\xef\xbb\xbfid,name\n1,alice\n2,bob\n")
    out = tmp_path / "out.csv"

    got = _run(["normalize", str(fixture), "-o", str(out)], capsys)

    assert "Changes:" in got
    assert "- BOM stripped" in got


# ---------- convert: jsonl output and stdout line ----------


def test_convert_jsonl_golden_stdout(tmp_path: Path, capsys):
    fixture = tmp_path / "sales.csv"
    fixture.write_bytes(_INSPECT_FIXTURE)
    out = tmp_path / "out.jsonl"

    got = _run(["convert", str(fixture), "-o", str(out), "--to", "jsonl"], capsys)
    masked = got.replace(str(out), "<OUTPUT>").strip()

    assert masked == "wrote 5 rows to <OUTPUT>"


# ---------- Error path golden text ----------


def test_missing_file_exits_two_with_message(tmp_path: Path, capsys):
    missing = tmp_path / "no-such.csv"

    rc = main(["inspect", str(missing)])
    err = capsys.readouterr().err

    assert rc == 2
    assert err.startswith("error: file not found:")
    assert str(missing) in err


def test_invalid_delimiter_exits_two_with_message(tmp_path: Path, capsys):
    fixture = tmp_path / "sales.csv"
    fixture.write_bytes(_INSPECT_FIXTURE)
    out = tmp_path / "out.csv"

    rc = main(
        ["normalize", str(fixture), "-o", str(out), "--delimiter", "||"]
    )
    err = capsys.readouterr().err

    assert rc == 2
    assert "single character" in err


@pytest.mark.parametrize("fmt", ["csv", "tsv", "jsonl"])
def test_convert_supported_formats_all_exit_zero(tmp_path: Path, capsys, fmt):
    # Smoke-matrix: each documented --to value must produce output
    # without crashing. This catches a "we added a new format but
    # forgot to wire it up" class of regression.
    fixture = tmp_path / "sales.csv"
    fixture.write_bytes(_INSPECT_FIXTURE)
    out = tmp_path / f"out.{fmt}"

    rc = main(["convert", str(fixture), "-o", str(out), "--to", fmt])
    assert rc == 0
    assert out.exists()
    assert out.stat().st_size > 0
