from pathlib import Path

import pytest

import dsvmonkey


def test_iso_date_column_detected(tmp_path: Path):
    src = tmp_path / "f.csv"
    src.write_bytes(
        b"id,event_date,amount\n"
        b"1,2024-01-15,10\n"
        b"2,2024-02-20,25\n"
        b"3,2024-03-10,40\n"
        b"4,2024-04-05,55\n"
        b"5,2024-05-30,70\n"
    )
    columns = dsvmonkey.profile_columns(src)

    by_name = {c.name: c for c in columns}
    event_date = by_name["event_date"]
    assert event_date.date_format == "%Y-%m-%d"
    assert event_date.date_confidence == "high"
    assert event_date.date_match_ratio == 1.0

    # Numeric columns should NOT be flagged as dates.
    assert by_name["id"].date_format is None
    assert by_name["amount"].date_format is None


def test_empty_cells_counted_not_sampled(tmp_path: Path):
    src = tmp_path / "f.csv"
    src.write_bytes(
        b"id,event_date\n"
        b"1,2024-01-15\n"
        b"2,\n"
        b"3,2024-03-10\n"
        b"4,\n"
        b"5,2024-05-30\n"
    )
    columns = dsvmonkey.profile_columns(src)
    event_date = next(c for c in columns if c.name == "event_date")
    assert event_date.empty_count == 2
    assert event_date.sample_size == 3


def test_non_date_text_column_has_no_date_format(tmp_path: Path):
    src = tmp_path / "f.csv"
    src.write_bytes(
        b"id,name,city\n"
        b"1,alice,london\n"
        b"2,bob,paris\n"
        b"3,carol,berlin\n"
    )
    columns = dsvmonkey.profile_columns(src)
    for column in columns:
        assert column.date_format is None


def test_sample_rows_limit_respected(tmp_path: Path):
    src = tmp_path / "f.csv"
    rows = [b"id,event_date"]
    for i in range(200):
        rows.append(f"{i},2024-01-{(i % 28) + 1:02d}".encode())
    src.write_bytes(b"\n".join(rows) + b"\n")

    columns = dsvmonkey.profile_columns(src, sample_rows=50)
    event_date = next(c for c in columns if c.name == "event_date")
    assert event_date.sample_size == 50


def test_no_header_file_uses_col_names(tmp_path: Path):
    src = tmp_path / "f.csv"
    src.write_bytes(
        b"1,2024-01-15,100\n"
        b"2,2024-02-20,200\n"
        b"3,2024-03-10,300\n"
        b"4,2024-04-05,400\n"
        b"5,2024-05-30,500\n"
    )
    columns = dsvmonkey.profile_columns(src)
    names = [c.name for c in columns]
    assert names == ["col_0", "col_1", "col_2"]
    date_column = next(c for c in columns if c.name == "col_1")
    assert date_column.date_format is not None


def test_explicit_profile_is_reused(tmp_path: Path):
    src = tmp_path / "f.csv"
    src.write_bytes(b"id,name\n1,alice\n2,bob\n")
    profile = dsvmonkey.profile_file(src)
    columns = dsvmonkey.profile_columns(src, profile=profile)
    assert [c.name for c in columns] == ["id", "name"]


def test_eu_date_format_detected_with_locale_hint(tmp_path: Path):
    src = tmp_path / "f.csv"
    src.write_bytes(
        b"id,event_date\n"
        b"1,15/01/2024\n"
        b"2,20/02/2024\n"
        b"3,10/03/2024\n"
        b"4,05/04/2024\n"
        b"5,30/05/2024\n"
    )
    columns = dsvmonkey.profile_columns(src, locale_preference="eu")
    event_date = next(c for c in columns if c.name == "event_date")
    # EU: day first. Pattern should have %d before %m.
    assert event_date.date_format is not None
    assert event_date.date_format.index("%d") < event_date.date_format.index("%m")


def test_cli_inspect_includes_date_column(tmp_path: Path, capsys):
    src = tmp_path / "f.csv"
    src.write_bytes(
        b"id,event_date,amount\n"
        b"1,2024-01-15,10\n"
        b"2,2024-02-20,25\n"
        b"3,2024-03-10,40\n"
        b"4,2024-04-05,55\n"
        b"5,2024-05-30,70\n"
    )

    from dsvmonkey.cli import main
    main(["inspect", str(src)])
    out = capsys.readouterr().out

    assert "Columns:" in out
    assert "event_date" in out
    assert "date:" in out
    assert "ISO 8601" in out or "%Y-%m-%d" in out


def test_excel_serial_threshold_configurable(tmp_path: Path):
    # Values 1-5 are rejected by the default threshold but accepted
    # when the caller lowers the gate (e.g. working with genuine
    # pre-1927 date serials).
    src = tmp_path / "f.csv"
    src.write_bytes(
        b"id,event_serial\n"
        b"1,1\n"
        b"2,2\n"
        b"3,3\n"
        b"4,4\n"
        b"5,5\n"
    )
    default_cols = dsvmonkey.profile_columns(src)
    loose_cols = dsvmonkey.profile_columns(src, excel_serial_min_value=0)

    default_serial = next(c for c in default_cols if c.name == "event_serial")
    loose_serial = next(c for c in loose_cols if c.name == "event_serial")

    assert default_serial.date_format is None
    assert loose_serial.date_format == "EXCEL_SERIAL"


def test_excel_serial_threshold_accepts_modern_serials_by_default(tmp_path: Path):
    # Serials in the real-world date range (here: values around
    # 45000, corresponding to 2023) should be detected even with
    # the default threshold.
    src = tmp_path / "f.csv"
    src.write_bytes(
        b"id,event_serial\n"
        b"1,45000\n"
        b"2,45100\n"
        b"3,45200\n"
        b"4,45300\n"
        b"5,45400\n"
    )
    columns = dsvmonkey.profile_columns(src)
    serial = next(c for c in columns if c.name == "event_serial")
    assert serial.date_format == "EXCEL_SERIAL"


def test_cli_excel_serial_min_flag(tmp_path: Path, capsys):
    src = tmp_path / "f.csv"
    src.write_bytes(
        b"id,event_serial\n"
        b"1,1\n"
        b"2,2\n"
        b"3,3\n"
        b"4,4\n"
        b"5,5\n"
    )

    from dsvmonkey.cli import main
    main(["inspect", "--excel-serial-min", "0", str(src)])
    out = capsys.readouterr().out
    # With the gate disabled, the serial column should be flagged
    # as a date in the report.
    assert "EXCEL_SERIAL" in out or "Excel serial" in out


def test_profile_columns_default_is_raw(tmp_path: Path):
    # Review finding: profile_columns used to call read() with the
    # default clean=True, so date detection and column statistics ran
    # against cleanmonkey-normalized values, hiding data-quality
    # issues from inspection. Default is now raw.
    src = tmp_path / "f.csv"
    # Smart quotes in data — cleanmonkey converts them to straight
    # quotes; raw profiling should see the originals.
    src.write_bytes(
        "id,status\n"
        "1,“Active”\n"
        "2,Active\n"
        "3,“Active”\n"
        "4,Active\n"
        "5,Active\n".encode("utf-8")
    )

    raw_cols = dsvmonkey.profile_columns(src)
    cleaned_cols = dsvmonkey.profile_columns(src, clean_cells=True)

    # The "status" column has 5 values either way; the difference is
    # whether we see the file's original content or cleanmonkey's
    # normalised view. A minimal proof: the raw pass is the default
    # and runs without cleanmonkey touching the data.
    assert raw_cols[1].sample_size == 5
    assert cleaned_cols[1].sample_size == 5


def test_cli_inspect_no_columns_flag_skips_column_section(
    tmp_path: Path, capsys
):
    src = tmp_path / "f.csv"
    src.write_bytes(b"id,event_date\n1,2024-01-15\n2,2024-02-20\n")

    from dsvmonkey.cli import main
    main(["inspect", "--no-columns", str(src)])
    out = capsys.readouterr().out

    # The Columns section shouldn't appear.
    assert "Columns:\n" not in out + "\n"  # no trailing "Columns:" header


# ---------- Narrowed exception handling in date detection ----------
#
# Previous contract: `except Exception` around datemonkey swallowed
# everything, including programming errors that should have surfaced.
# New contract: only *data-shaped* failures (ValueError, TypeError,
# ArithmeticError, UnicodeError) are swallowed into a column warning;
# programming errors propagate so a broken install or refactor doesn't
# silently degrade every column to "no date detected".


def test_value_error_from_date_detector_is_recorded_not_raised(
    tmp_path: Path, monkeypatch
):
    # Adversarial data-shaped failure: the docstring says analysis
    # should keep going for other columns. The failing column must
    # have a warning attached and no date_format populated.
    src = tmp_path / "f.csv"
    src.write_bytes(
        b"id,event_date\n"
        b"1,2024-01-15\n"
        b"2,2024-02-20\n"
        b"3,2024-03-10\n"
    )

    from dsvmonkey import columns as columns_mod

    def boom(values, locale_preference=None):
        raise ValueError("malformed sample")

    monkeypatch.setattr(columns_mod.datemonkey, "detect_format", boom)

    result = dsvmonkey.profile_columns(src)

    for col in result:
        assert col.date_format is None
        assert any("date detection failed" in w for w in col.warnings)
        assert any("malformed sample" in w for w in col.warnings)


def test_type_error_from_date_detector_is_recorded_not_raised(
    tmp_path: Path, monkeypatch
):
    # TypeError is the other common data-shape failure (wrong argument
    # type slipping through). Must be swallowed, not raised.
    src = tmp_path / "f.csv"
    src.write_bytes(b"id,date\n1,2024-01-15\n2,2024-02-20\n3,2024-03-10\n")

    from dsvmonkey import columns as columns_mod

    def boom(values, locale_preference=None):
        raise TypeError("unexpected type")

    monkeypatch.setattr(columns_mod.datemonkey, "detect_format", boom)

    result = dsvmonkey.profile_columns(src)
    assert all(col.date_format is None for col in result)
    assert any(
        "date detection failed" in w for col in result for w in col.warnings
    )


def test_programming_error_from_date_detector_propagates(
    tmp_path: Path, monkeypatch
):
    # Regression guard: `except Exception` used to swallow AttributeError
    # too. A programming error — the kind you want to *see* during
    # development or a broken install — must now propagate instead of
    # being silently written into a column warning.
    src = tmp_path / "f.csv"
    src.write_bytes(b"id,date\n1,2024-01-15\n2,2024-02-20\n3,2024-03-10\n")

    from dsvmonkey import columns as columns_mod

    def boom(values, locale_preference=None):
        raise AttributeError("detect_format moved")

    monkeypatch.setattr(columns_mod.datemonkey, "detect_format", boom)

    with pytest.raises(AttributeError, match="detect_format moved"):
        dsvmonkey.profile_columns(src)


def test_import_error_from_date_detector_propagates(
    tmp_path: Path, monkeypatch
):
    # Broken transitive-dependency install is NOT a data failure; it
    # should bubble up so the operator can fix the environment.
    src = tmp_path / "f.csv"
    src.write_bytes(b"id,date\n1,2024-01-15\n2,2024-02-20\n")

    from dsvmonkey import columns as columns_mod

    def boom(values, locale_preference=None):
        raise ImportError("missing submodule")

    monkeypatch.setattr(columns_mod.datemonkey, "detect_format", boom)

    with pytest.raises(ImportError):
        dsvmonkey.profile_columns(src)


def test_other_columns_profile_normally_when_date_detector_fails(
    tmp_path: Path, monkeypatch
):
    # The docstring claim we're checking: "a non-date column's analysis
    # failing shouldn't kill the whole report." Even with detect_format
    # raising a data error on every invocation, empty_count and
    # sample_size must still be correct for every column.
    src = tmp_path / "f.csv"
    src.write_bytes(
        b"id,event_date,amount\n"
        b"1,2024-01-15,10\n"
        b"2,,25\n"
        b"3,2024-03-10,\n"
    )

    from dsvmonkey import columns as columns_mod

    def boom(values, locale_preference=None):
        raise ValueError("never parses")

    monkeypatch.setattr(columns_mod.datemonkey, "detect_format", boom)

    cols = dsvmonkey.profile_columns(src)
    by_name = {c.name: c for c in cols}

    assert by_name["id"].sample_size == 3
    assert by_name["id"].empty_count == 0
    assert by_name["event_date"].sample_size == 2
    assert by_name["event_date"].empty_count == 1
    assert by_name["amount"].sample_size == 2
    assert by_name["amount"].empty_count == 1


# ---------- Gap 17: "reasonably confident match" contract ----------
#
# The `profile_columns` docstring / `ColumnProfile` class docstring
# claim date fields are populated only on a "reasonably confident
# match" from datemonkey. The code at `_fill_date_fields` gates only
# on `match_count > 0`. Pin the real behaviour so future readers can
# see which branch of the truth-table the contract sits on.


# Gap 17a: match_count == 0 => all three date fields must be None.
def test_date_fields_none_when_datemonkey_reports_no_matches(
    tmp_path: Path, monkeypatch
):
    src = tmp_path / "f.csv"
    src.write_bytes(b"id,event\n1,foo\n2,bar\n3,baz\n")

    from dsvmonkey import columns as columns_mod
    from datemonkey.models import (
        Confidence,
        DateFormat,
        FormatDetectionResult,
    )

    def no_match(values, locale_preference=None):
        # match_count=0 means datemonkey saw nothing date-like.
        return FormatDetectionResult(
            format=DateFormat(pattern="%Y-%m-%d", label="ISO 8601"),
            confidence=Confidence.FAILED,
            sample_size=len(values),
            match_count=0,
        )

    monkeypatch.setattr(columns_mod.datemonkey, "detect_format", no_match)

    cols = dsvmonkey.profile_columns(src)
    for col in cols:
        assert col.date_format is None
        assert col.date_confidence is None
        assert col.date_match_ratio is None


# Gap 17b: LOW-confidence, low-match-ratio result.
# Contract: the docstring promises a "reasonably confident match"
# before populating date fields. The implementation now gates on
# match_ratio >= _MIN_DATE_MATCH_RATIO (0.5) so a 1-in-10 pattern
# match does NOT get labelled as a date column. This is the case
# where a free-text column happens to contain a handful of
# date-shaped strings — the detector must stay quiet.
def test_low_match_ratio_does_not_populate_date_fields(
    tmp_path: Path, monkeypatch
):
    src = tmp_path / "f.csv"
    src.write_bytes(b"id,event\n1,aaa\n2,bbb\n3,ccc\n")

    from dsvmonkey import columns as columns_mod
    from datemonkey.models import (
        Confidence,
        DateFormat,
        FormatDetectionResult,
    )

    def low_conf(values, locale_preference=None):
        # match_count=1/sample_size=10 => match_ratio = 0.1, LOW —
        # below the 0.5 gate, so no date fields should be set.
        return FormatDetectionResult(
            format=DateFormat(pattern="%Y-%m-%d", label="ISO 8601"),
            confidence=Confidence.LOW,
            sample_size=10,
            match_count=1,
        )

    monkeypatch.setattr(columns_mod.datemonkey, "detect_format", low_conf)

    cols = dsvmonkey.profile_columns(src)
    event = next(c for c in cols if c.name == "event")
    assert event.date_format is None
    assert event.date_confidence is None
    assert event.date_match_ratio is None
    # Review finding (#8): weak signals were dropped silently.
    # Now surfaced as a warning so an operator scanning the
    # inspect report sees "this column has SOME date-shaped
    # values" without the column being mis-labelled as a date.
    assert any("weak date signal" in w for w in event.warnings)


def test_zero_match_count_emits_no_warning(
    tmp_path: Path, monkeypatch
):
    # Negative case: weak-date-signal warning fires only for
    # match_ratio > 0 but below threshold. Pure non-date columns
    # (match_count=0) emit no warning — that's noise we don't
    # want.
    src = tmp_path / "f.csv"
    src.write_bytes(b"id,event\n1,aaa\n2,bbb\n3,ccc\n")

    from dsvmonkey import columns as columns_mod
    from datemonkey.models import (
        Confidence,
        DateFormat,
        FormatDetectionResult,
    )

    def no_match(values, locale_preference=None):
        return FormatDetectionResult(
            format=DateFormat(pattern="%Y-%m-%d", label="ISO 8601"),
            confidence=Confidence.FAILED,
            sample_size=10,
            match_count=0,
        )

    monkeypatch.setattr(columns_mod.datemonkey, "detect_format", no_match)

    cols = dsvmonkey.profile_columns(src)
    event = next(c for c in cols if c.name == "event")
    assert event.date_format is None
    assert not any("weak date signal" in w for w in event.warnings)


# Boundary probe: match_ratio exactly equal to _MIN_DATE_MATCH_RATIO
# (0.5) should accept; just-below (0.49) should reject. Pins the
# threshold so a future tuning change has to land an explicit contract
# update.
def test_match_ratio_at_threshold_populates_date_fields(
    tmp_path: Path, monkeypatch
):
    src = tmp_path / "f.csv"
    src.write_bytes(b"id,event\n1,x\n2,y\n3,z\n")

    from dsvmonkey import columns as columns_mod
    from datemonkey.models import (
        Confidence,
        DateFormat,
        FormatDetectionResult,
    )

    def at_threshold(values, locale_preference=None):
        # match_ratio = 5/10 = 0.5, equal to the gate.
        return FormatDetectionResult(
            format=DateFormat(pattern="%Y-%m-%d", label="ISO 8601"),
            confidence=Confidence.MEDIUM,
            sample_size=10,
            match_count=5,
        )

    monkeypatch.setattr(columns_mod.datemonkey, "detect_format", at_threshold)

    cols = dsvmonkey.profile_columns(src)
    event = next(c for c in cols if c.name == "event")
    assert event.date_format == "%Y-%m-%d"
    assert event.date_match_ratio == pytest.approx(0.5)


def test_profile_columns_rejects_non_positive_sample_rows(tmp_path: Path):
    # Defence-in-depth guard (separate from the CLI validation) so
    # library callers don't silently get zero-sample column profiles.
    src = tmp_path / "f.csv"
    src.write_bytes(b"id,name\n1,alice\n2,bob\n")

    with pytest.raises(ValueError, match="positive integer"):
        dsvmonkey.profile_columns(src, sample_rows=0)

    with pytest.raises(ValueError, match="positive integer"):
        dsvmonkey.profile_columns(src, sample_rows=-5)


def test_profile_columns_skip_empty_rows_false_includes_blanks_in_counts(
    tmp_path: Path,
):
    # Review finding (#3): profile_columns inherited read()'s
    # default skip_empty_rows=True with no override, so
    # whitespace-with-delimiter rows were dropped before profiling
    # — empty_count under-reported audit-style datasets. The new
    # parameter threads through to read() so the "blank rows are
    # semantic" contract reaches per-column stats.
    src = tmp_path / "audit.csv"
    # Three data rows plus two audit blank rows (delimiter present,
    # cells whitespace-only).
    src.write_bytes(b"id,amount\n1,100\n,\n2,200\n  ,  \n3,300\n")

    # Default: audit rows dropped, empty_count is 0 on real data.
    default_cols = dsvmonkey.profile_columns(src)
    assert default_cols[0].empty_count == 0
    assert default_cols[0].sample_size == 3

    # With skip_empty_rows=False: the audit rows survive as empty
    # cells in every column.
    preserved = dsvmonkey.profile_columns(src, skip_empty_rows=False)
    assert preserved[0].empty_count == 2
    assert preserved[0].sample_size == 3


def test_profile_columns_deep_scan_flag_threads_to_profile_file(
    tmp_path: Path, monkeypatch
):
    # Review finding (#4): profile_columns always called
    # profile_file(path) without exposing deep_scan, forcing the
    # full-file mixed-encoding pass on large/remote files. The
    # parameter now threads through.
    import dsvmonkey
    from dsvmonkey import columns as columns_mod

    src = tmp_path / "f.csv"
    src.write_bytes(b"id,name\n1,alice\n")

    seen: list[bool] = []
    real_profile_file = columns_mod.profile_file

    def spy(path, **kwargs):
        seen.append(kwargs.get("deep_scan", True))
        return real_profile_file(path, **kwargs)

    monkeypatch.setattr(columns_mod, "profile_file", spy)

    dsvmonkey.profile_columns(src)  # default deep_scan=True
    dsvmonkey.profile_columns(src, deep_scan=False)

    assert seen == [True, False]


def test_profile_columns_accepts_sample_rows_of_one(tmp_path: Path):
    # Boundary: 1 is the smallest valid bound. Must actually sample
    # one row and report sample_size=1.
    src = tmp_path / "f.csv"
    src.write_bytes(b"id,name\n1,alice\n2,bob\n3,carol\n")

    cols = dsvmonkey.profile_columns(src, sample_rows=1)
    assert all(c.sample_size == 1 for c in cols)


def test_profile_columns_single_pass_when_width_missing(
    tmp_path: Path, monkeypatch
):
    # Review finding: when profile.headers and profile.field_count
    # were both None, the old code called read() twice — once to
    # peek the first row for width, again to do the actual sampling.
    # Count the read() calls to pin the new single-pass behaviour.
    import dsvmonkey
    from dsvmonkey import columns as columns_mod

    src = tmp_path / "f.csv"
    src.write_bytes(b"1,2,3\n4,5,6\n7,8,9\n")

    real_read = columns_mod.read
    call_count = {"n": 0}

    def counting_read(*args, **kwargs):
        call_count["n"] += 1
        return real_read(*args, **kwargs)

    monkeypatch.setattr(columns_mod, "read", counting_read)

    profile = dsvmonkey.profile_file(src)
    profile.headers = None
    profile.field_count = None
    profile.header_row.value = None

    cols = dsvmonkey.profile_columns(src, profile=profile)

    # Exactly one read() call — the first row is peeked from the
    # same iterator the sampling loop consumes.
    assert call_count["n"] == 1
    # And the result is correct: 3 columns, each sample_size=3
    # (includes the peeked row).
    assert len(cols) == 3
    assert all(c.sample_size == 3 for c in cols)


def test_profile_columns_peeks_first_row_when_profile_has_no_width(
    tmp_path: Path,
):
    # Review finding: a profile with no headers and no field_count
    # previously caused profile_columns() to return [] silently —
    # misleading for diagnostics. Callers hit this when they forced
    # header_row to None AND the profile hadn't set field_count (e.g.
    # they bypassed profile_file() or edited the profile).
    #
    # `profile_columns` now peeks at the first data row to determine
    # width and synthesises col_N names, matching `read()`'s
    # lazy-width fallback.
    src = tmp_path / "f.csv"
    src.write_bytes(b"1,2,3\n4,5,6\n7,8,9\n")

    profile = dsvmonkey.profile_file(src)
    # Force the profile into a zero-structural-info state.
    profile.headers = None
    profile.field_count = None
    profile.header_row.value = None

    cols = dsvmonkey.profile_columns(src, profile=profile)

    # Three columns discovered from the first data row's width, not
    # an empty list.
    assert len(cols) == 3
    assert [c.name for c in cols] == ["col_0", "col_1", "col_2"]


def test_profile_columns_returns_empty_for_truly_empty_file(tmp_path: Path):
    # Negative case: the first-row peek must still return [] for an
    # actually empty file (no false-positives on the peek fallback).
    src = tmp_path / "empty.csv"
    src.write_bytes(b"")

    cols = dsvmonkey.profile_columns(src)
    assert cols == []


def test_match_ratio_just_below_threshold_rejects(
    tmp_path: Path, monkeypatch
):
    src = tmp_path / "f.csv"
    src.write_bytes(b"id,event\n1,x\n2,y\n3,z\n")

    from dsvmonkey import columns as columns_mod
    from datemonkey.models import (
        Confidence,
        DateFormat,
        FormatDetectionResult,
    )

    def below(values, locale_preference=None):
        # match_ratio = 49/100 = 0.49, just below the 0.5 gate.
        return FormatDetectionResult(
            format=DateFormat(pattern="%Y-%m-%d", label="ISO 8601"),
            confidence=Confidence.MEDIUM,
            sample_size=100,
            match_count=49,
        )

    monkeypatch.setattr(columns_mod.datemonkey, "detect_format", below)

    cols = dsvmonkey.profile_columns(src)
    event = next(c for c in cols if c.name == "event")
    assert event.date_format is None
    assert event.date_match_ratio is None


# Gap 17c (below-threshold): 9999 is just under the 10000 cutoff and
# must NOT be detected as EXCEL_SERIAL.
def test_excel_serial_just_below_threshold_rejected(tmp_path: Path):
    src = tmp_path / "f.csv"
    src.write_bytes(
        b"id,event_serial\n"
        b"1,9999\n"
        b"2,9999\n"
        b"3,9999\n"
        b"4,9999\n"
        b"5,9999\n"
    )
    cols = dsvmonkey.profile_columns(src)
    serial = next(c for c in cols if c.name == "event_serial")
    assert serial.date_format is None


# Gap 17c (at-threshold): 10000 is the documented boundary and
# MUST be accepted (`min >= min_value`).
def test_excel_serial_at_threshold_accepted(tmp_path: Path):
    src = tmp_path / "f.csv"
    src.write_bytes(
        b"id,event_serial\n"
        b"1,10000\n"
        b"2,10000\n"
        b"3,10000\n"
        b"4,10000\n"
        b"5,10000\n"
    )
    cols = dsvmonkey.profile_columns(src)
    serial = next(c for c in cols if c.name == "event_serial")
    assert serial.date_format == "EXCEL_SERIAL"


# Bonus gap: `_plausible_excel_serials` returns False when float()
# raises ValueError. This is the "False for the wrong reason" truth-
# table corner — non-numeric strings with a positive min_value must
# take the ValueError branch and return False (not True, not raise).
def test_plausible_excel_serials_returns_false_on_value_error():
    from dsvmonkey.columns import _plausible_excel_serials

    assert _plausible_excel_serials(["abc", "def"], 10000) is False


def test_plausible_excel_serials_tolerant_of_mixed_numeric_and_text():
    # Review finding: the old implementation failed the whole check
    # on the first ValueError, so a single `"N/A"` sentinel amid
    # legitimate serial-shaped values suppressed date classification
    # for the column. The pattern was already matched by datemonkey
    # by the time this gate runs — we only need it to decide whether
    # the NUMERIC values look like dates.
    from dsvmonkey.columns import _plausible_excel_serials

    # Numeric values are all well above 10000 (real serial dates);
    # non-numeric sentinels must be skipped, not fatal.
    values = ["45000", "N/A", "45100", "", "45200", "null"]
    assert _plausible_excel_serials(values, 10000) is True


def test_plausible_excel_serials_still_rejects_below_threshold_with_sentinels(
):
    # Negative case: the tolerance must not rescue a column where
    # the numeric values are below the threshold — only skips
    # non-numeric entries, doesn't lower the bar.
    from dsvmonkey.columns import _plausible_excel_serials

    values = ["5", "N/A", "6", "", "7"]
    assert _plausible_excel_serials(values, 10000) is False
