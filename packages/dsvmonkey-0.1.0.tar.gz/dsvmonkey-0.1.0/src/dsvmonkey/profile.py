"""Profile and detection result types.

`DetectionResult` is the shared shape for every piece of structural
information dsvmonkey infers about a file: encoding, delimiter, quote
character, header row, line ending. Carrying the runner-up candidates
and the reason for the choice — rather than a bare float — is what
makes the `inspect` report useful and allows callers to programmatically
override a low-confidence guess.

`DSVProfile` is the aggregate result for one file. Fields are filled in
order by the detection pipeline (encoding first, since everything else
depends on having bytes decoded).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# Shared diagnostic-string identifiers. The producer sites
# (orchestrate._flag_duplicate_headers, detectors.line_ending) emit
# strings starting with these prefixes; consumer sites
# (DSVProfile.review_reasons, repair._line_ending_was_changed) match
# via .startswith() on the same constants. Without this shared
# vocabulary, the consumer's substring check (`"duplicate header" in
# issue`) silently breaks the day someone rewords the producer
# message — fragile coupling we'd only catch via integration test.
DUPLICATE_HEADER_ISSUE_PREFIX = "duplicate header name(s)"
MIXED_LINE_ENDINGS_WARNING = "mixed line endings in sample"


@dataclass(frozen=True)
class DetectionAlternative:
    """A candidate that wasn't chosen, with its score and the reason.

    Surfaced in `inspect` reports so a human can see *why* the winner won.
    """

    value: Any
    confidence: float
    reason: str


@dataclass
class DetectionResult:
    """The outcome of a single detection step.

    `method` is a short machine-readable tag for how the decision was
    made (`"bom"`, `"content-scored"`, `"fallback"`, `"sniffer"`, ...).
    `alternatives` lists runner-up candidates in score order.
    `warnings` records anything noteworthy that didn't prevent a decision
    (e.g. a BOM was stripped before scoring).
    """

    value: Any
    confidence: float
    method: str
    alternatives: list[DetectionAlternative] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        if not 0.0 <= self.confidence <= 1.0:
            raise ValueError(
                f"confidence must be in [0.0, 1.0], got {self.confidence!r}"
            )


_REVIEW_CONFIDENCE_FLOOR = 0.6


@dataclass
class DSVProfile:
    """Structural profile of a single DSV file.

    Populated incrementally by the detection pipeline. Detection fields
    are `None` until their step has run; this lets callers build a
    profile in stages and lets `inspect` render a partial result if a
    later step fails.
    """

    path: Path
    file_size: int
    sample_bytes: int

    encoding: DetectionResult | None = None
    delimiter: DetectionResult | None = None
    quote_char: DetectionResult | None = None
    line_ending: DetectionResult | None = None
    header_row: DetectionResult | None = None

    has_bom: bool = False
    bom: str | None = None
    mixed_encoding_suspected: bool = False

    headers: list[str] | None = None
    field_count: int | None = None

    issues: list[str] = field(default_factory=list)

    @property
    def needs_review(self) -> bool:
        """True when detection wasn't confident enough to trust the
        profile alone — caller should visually inspect the file.

        Detection from bytes has fundamental limits: some files are
        genuinely ambiguous between interpretations (free text vs
        custom-delimited CSV, mixed encoding without enough UTF-8
        evidence, etc.). Rather than confidently producing a wrong
        answer, the library surfaces uncertainty via per-detector
        confidence scores and the `issues` list. `needs_review`
        aggregates those signals into one boolean for callers and
        the CLI inspect report.
        """
        return bool(self.review_reasons)

    @property
    def review_reasons(self) -> list[str]:
        """Human-readable reasons why `needs_review` is True (or
        empty when detection is confident).

        Each entry names a specific signal that suggests the
        profile shouldn't be trusted blindly: low-confidence
        detection, suspected mixed encoding, ambiguous single-
        column verdict, duplicate header collisions that will
        lose data in dict mode, and so on. Order matches detection
        order.
        """
        reasons: list[str] = []
        if self.encoding is not None and (
            self.encoding.confidence < _REVIEW_CONFIDENCE_FLOOR
        ):
            reasons.append(
                f"encoding confidence {self.encoding.confidence:.2f} "
                f"< {_REVIEW_CONFIDENCE_FLOOR}"
            )
        if self.mixed_encoding_suspected:
            reasons.append("mixed encoding suspected")

        # Track whether we've already reported the delimiter so the
        # "single-column" reason doesn't duplicate the "low
        # confidence" one. Using an explicit boolean flag rather
        # than a substring check on `" ".join(reasons)` — the
        # substring approach worked but was brittle to message-text
        # changes (a future tweak to either reason's wording could
        # silently double-flag or mis-suppress).
        delimiter_reported = False
        if self.delimiter is not None and (
            self.delimiter.confidence < _REVIEW_CONFIDENCE_FLOOR
        ):
            reasons.append(
                f"delimiter confidence {self.delimiter.confidence:.2f} "
                f"< {_REVIEW_CONFIDENCE_FLOOR} "
                f"(method={self.delimiter.method!r})"
            )
            delimiter_reported = True
        # Single-column classification is inherently ambiguous —
        # could be a true single-column file OR a multi-column file
        # using a custom delimiter outside the auto-detect set. The
        # heuristic confidence is an internal signal, not a
        # statement of "this is definitely one column." Always
        # recommend review on a single-column verdict, regardless
        # of confidence number, so a custom-delimiter file isn't
        # silently collapsed in unattended pipelines.
        if (
            not delimiter_reported
            and self.delimiter is not None
            and self.delimiter.method == "single-column"
        ):
            reasons.append(
                "delimiter classified as single-column "
                f"(confidence {self.delimiter.confidence:.2f}); "
                "could also indicate a custom delimiter not in the "
                "auto-detect set"
            )
        # Quote-char and header-row low confidence materially
        # affect parsing semantics — quote misclassification can
        # split or merge fields wrongly, header misclassification
        # produces wrong schema. Both deserve review even though
        # they're less catastrophic than encoding/delimiter
        # ambiguity. Line-ending confidence is deliberately NOT
        # checked here: its impact is mostly cosmetic (repair()
        # normalises to the target ending regardless of detection
        # certainty), and single-line files legitimately produce
        # a 0.0-confidence fallback verdict that shouldn't gate
        # everything in CI.
        if self.quote_char is not None and (
            self.quote_char.confidence < _REVIEW_CONFIDENCE_FLOOR
        ):
            reasons.append(
                f"quote_char confidence {self.quote_char.confidence:.2f} "
                f"< {_REVIEW_CONFIDENCE_FLOOR} "
                f"(method={self.quote_char.method!r})"
            )
        if self.header_row is not None and (
            self.header_row.confidence < _REVIEW_CONFIDENCE_FLOOR
            and self.header_row.method != "fallback"
        ):
            # `method="fallback"` fires only on empty samples
            # (no rows at all); not a parsing-correctness issue.
            # The interesting cases are method="absent" or
            # method="headeriness-score" with a marginal score —
            # we picked something but barely.
            reasons.append(
                f"header_row confidence {self.header_row.confidence:.2f} "
                f"< {_REVIEW_CONFIDENCE_FLOOR} "
                f"(method={self.header_row.method!r})"
            )

        # Dict-mode duplicate-header collisions cause silent data
        # loss (later value overwrites earlier) per the documented
        # warn-and-collapse contract. The warning channel can be
        # filtered in production; surface via needs_review so an
        # unattended pipeline gating on the boolean catches the
        # data-loss risk.
        if any(
            issue.startswith(DUPLICATE_HEADER_ISSUE_PREFIX)
            for issue in self.issues
        ):
            reasons.append(
                "duplicate header names detected; "
                "read(as_dict=True) and to_jsonl() will silently "
                "overwrite earlier columns"
            )
        return reasons


class ReviewRecommendedError(Exception):
    """Raised by `assert_clean()` (and `DSVProfile.assert_clean()`)
    when a profile signals `needs_review=True`.

    Pipelines that can't tolerate uncertain detection can use the
    canonical gate:

        try:
            dsvmonkey.assert_clean(profile)
        except dsvmonkey.ReviewRecommendedError as exc:
            queue_for_human_review(exc.path, exc.reasons)
            return

    Carries `path` and `reasons` so handlers don't have to peek
    back at the profile to format the message.
    """

    def __init__(self, profile: "DSVProfile") -> None:
        self.profile = profile
        self.path = profile.path
        self.reasons: list[str] = list(profile.review_reasons)
        msg = (
            f"detection uncertain for {profile.path}: "
            + "; ".join(self.reasons)
        )
        super().__init__(msg)


class DictOverflowError(ValueError):
    """Raised by `read(as_dict=True, on_overflow="raise")` and
    `to_jsonl(on_overflow="raise")` when a row is wider than the
    effective header set.

    Subclasses `ValueError` so existing `except ValueError`
    handlers still catch it (backwards compatibility), but
    callers (notably the CLI's strict-mode gate) can catch by
    class instead of substring-matching the exception message.
    Pinning the contract: the CLI used to inspect `str(err)` for
    "overflow cells would be dropped" — fragile if the wording
    drifted, the strict-pipeline exit-3 contract would silently
    regress to a generic exit 2.

    Carries `row_width` and `header_width` for handlers that
    want to format their own message without parsing the
    exception text.
    """

    def __init__(self, row_width: int, header_width: int) -> None:
        self.row_width = row_width
        self.header_width = header_width
        super().__init__(
            f"row has {row_width} cells but only {header_width} "
            "header(s); overflow cells would be dropped in dict "
            "output. on_overflow='raise' refuses to continue. "
            "Use as_dict=False to preserve every cell, pass a "
            "wider `headers=` list, or switch to "
            "on_overflow='warn' / 'silent' if the loss is "
            "intentional."
        )


def assert_clean(profile: "DSVProfile") -> None:
    """Raise `ReviewRecommendedError` when `profile.needs_review` is
    True; do nothing otherwise.

    Convenience wrapper around the canonical pattern

        if profile.needs_review:
            raise SomeError(...)

    so callers don't have to write the conditional themselves.
    Idiomatic gate at the top of an unattended pipeline:

        profile = dsvmonkey.profile_file(path)
        dsvmonkey.assert_clean(profile)        # may raise
        for row in dsvmonkey.read(path, profile=profile):
            ...
    """
    if profile.needs_review:
        raise ReviewRecommendedError(profile)
