"""Format conversion.

`repair()` already handles CSV ↔ TSV ↔ any-DSV via `target_delimiter`.
This module adds the one thing repair() can't: JSON Lines output.

JSON Lines is increasingly the lingua franca between data tools —
every row a JSON object, one per line, streamable. `typemonkey` and
`pgmonkey` both consume it cleanly.
"""

from __future__ import annotations

import json
from pathlib import Path

from dsvmonkey._internal import (
    _atomic_text_writer,
    _neutralize_formula,
    _reject_same_path,
)
from dsvmonkey.orchestrate import profile_file
from dsvmonkey.profile import DSVProfile
from dsvmonkey.reader import (
    CleanSetting,
    OverflowPolicy,
    _validate_profile,
    read,
)


def to_jsonl(
    input_path: Path | str,
    output_path: Path | str,
    *,
    profile: DSVProfile | None = None,
    clean_cells: CleanSetting = True,
    headers: list[str] | None = None,
    deep_scan: bool = True,
    skip_empty_rows: bool = True,
    sanitize_formulas: bool = False,
    on_overflow: OverflowPolicy = "warn",
) -> int:
    """Stream `input_path` as JSON Lines to `output_path`.

    Returns the number of data rows written. Output is UTF-8 with Unix
    line endings and no BOM regardless of input. `ensure_ascii=False`
    so non-ASCII stays readable — downstream tools handle Unicode.

    `deep_scan` is forwarded to `profile_file` when no precomputed
    profile is supplied — set to False to skip the full-file mixed-
    encoding pass on very large or remote files.

    `skip_empty_rows` matches the same-named parameter on `read()`
    and `repair()`. Default True (ETL-friendly). Set to False for
    fixed-format / audit workflows where blank rows are semantic
    — blank rows then yield a JSON object shaped by the detected
    headers with every value set to the empty string.

    `sanitize_formulas` matches `repair()`. JSON consumers don't
    evaluate formulas themselves, but JSONL output is often
    transformed back to CSV/Excel later — and at that point any
    `=SUM(A:A)*cmd|...` payload that survived as a string value
    becomes a live formula. Pass `True` when output is destined
    for any pipeline that may eventually feed a spreadsheet UI.
    Off by default because the prefix mutates visible content
    and is unwanted when the consumer is a strict JSON tool
    (jq, structured-loggers, etc.).

    `on_overflow` matches `read()`. JSONL is a dict-mode output,
    so wider-than-header rows would silently lose cells. Default
    `"warn"`. Pass `"raise"` in unattended pipelines where dropped
    warnings would mask the data loss; the conversion aborts on
    the first overflow row and the partial JSONL temp file is
    discarded by the atomic-writer cleanup, so no half-written
    output reaches `output_path`.
    """
    input_path = Path(input_path)
    output_path = Path(output_path)
    _reject_same_path(input_path, output_path, "to_jsonl")

    if profile is None:
        profile = profile_file(input_path, deep_scan=deep_scan)
    else:
        # Validate at the to_jsonl boundary so the error message names
        # the API the caller actually invoked. Without this, a
        # mismatched profile still gets caught — but inside read(),
        # which surfaces as `error: read(): profile was built from
        # ...`. Confusing in cached-profile pipelines where the
        # caller is reasoning about to_jsonl(), not its internal
        # streaming dependency.
        _validate_profile(profile, "to_jsonl", input_path)

    # Atomic write: same pattern as repair() — stream into a sibling
    # temp file, then os.replace() into the final path on successful
    # close. Protects against partial JSONL on crash / Ctrl+C / disk
    # full.
    count = 0
    with _atomic_text_writer(output_path, encoding="utf-8") as out:
        for row in read(
            input_path,
            profile=profile,
            as_dict=True,
            clean=clean_cells,
            headers=headers,
            skip_empty_rows=skip_empty_rows,
            on_overflow=on_overflow,
        ):
            if sanitize_formulas:
                # Sanitise BOTH keys and values. `repair()`
                # already neutralises the header row's cells, but
                # to_jsonl turns those into dict KEYS — and any
                # downstream consumer that materialises keys back
                # into a spreadsheet (CSV export, table renderer
                # that uses key as column header) would otherwise
                # see a live formula in the header even though
                # the caller asked for sanitisation. Cross-API
                # parity with repair() requires header keys
                # neutralised too.
                #
                # Post-sanitisation key collision check: if the
                # caller's headers include both `=id` and `'=id`,
                # neutralisation produces `'=id` from both — a
                # naive dict comprehension would silently
                # overwrite. Silent data loss in the security
                # mode is exactly the wrong default. Detect the
                # collision and raise instead.
                sanitised_items = [
                    (_neutralize_formula(k), _neutralize_formula(v))
                    for k, v in row.items()
                ]
                seen: set[str] = set()
                collisions: list[str] = []
                for key, _ in sanitised_items:
                    if key in seen and key not in collisions:
                        collisions.append(key)
                    seen.add(key)
                if collisions:
                    raise ValueError(
                        f"to_jsonl(): sanitize_formulas=True would "
                        f"cause key collision(s) {collisions!r} after "
                        "neutralising formula triggers. Two or more "
                        "input headers normalise to the same string "
                        "(e.g. `=id` and `'=id` both become `'=id`). "
                        "Disambiguate the headers before calling, or "
                        "use sanitize_formulas=False if the headers "
                        "are trusted."
                    )
                row = dict(sanitised_items)
            out.write(json.dumps(row, ensure_ascii=False))
            out.write("\n")
            count += 1
    return count
