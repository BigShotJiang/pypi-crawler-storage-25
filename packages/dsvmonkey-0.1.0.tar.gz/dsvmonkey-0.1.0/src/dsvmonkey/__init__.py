"""dsvmonkey — detect, profile, normalize and repair DSV files."""

from importlib.metadata import PackageNotFoundError, version as _pkg_version

from dsvmonkey.columns import ColumnProfile, profile_columns
from dsvmonkey.convert import to_jsonl
from dsvmonkey.orchestrate import profile_bytes, profile_file
from dsvmonkey.profile import (
    DetectionAlternative,
    DetectionResult,
    DictOverflowError,
    DSVProfile,
    ReviewRecommendedError,
    assert_clean,
)
from dsvmonkey.reader import read
from dsvmonkey.repair import RepairReport, repair

# pyproject.toml is the single source of truth for the version number.
# Reading via importlib.metadata avoids hand-syncing a duplicate
# string here — a previous foot-gun where __init__.py's hardcoded
# "0.1.0" could drift from the packaged version on a release. The
# fallback covers running directly from a source tree where the
# package isn't installed (rare but legal during dev).
try:
    __version__ = _pkg_version("dsvmonkey")
except PackageNotFoundError:
    __version__ = "0.0.0+unknown"

__all__ = [
    "ColumnProfile",
    "DetectionAlternative",
    "DetectionResult",
    "DictOverflowError",
    "DSVProfile",
    "RepairReport",
    "ReviewRecommendedError",
    "assert_clean",
    "profile_bytes",
    "profile_columns",
    "profile_file",
    "read",
    "repair",
    "to_jsonl",
    "__version__",
]
