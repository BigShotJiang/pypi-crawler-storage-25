"""Streaming DSV reader.

`read()` is the one-call "I have a messy DSV file, give me clean rows"
entry point. It:

- profiles the file (or uses a profile passed in);
- opens it streamed with the detected encoding (handles BOM);
- skips preamble and header rows;
- parses with the detected delimiter / quote char;
- passes every cell through `cleanmonkey.clean()` with the `"csv"`
  profile by default (BOMs, NBSPs, zero-width spaces, smart quotes,
  control chars, fullwidth digits — all normalised on the way out);
- yields dicts keyed by cleaned header names, or lists when asked.

Cleaning is on by default because the entire pain point of DSV files
is the invisible garbage in cell values — if dsvmonkey doesn't clean
them at the boundary, every downstream consumer has to defend against
it independently. Pass `clean=False` for byte-exact work.
"""

from __future__ import annotations

import codecs
import csv
import warnings
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import IO, Literal, Union, overload

import cleanmonkey

from dsvmonkey.orchestrate import profile_file
from dsvmonkey.profile import DictOverflowError, DSVProfile

CleanSetting = Union[bool, str, "cleanmonkey.Profile", Callable[[str], str]]
OverflowPolicy = Literal["warn", "raise", "silent"]
_VALID_OVERFLOW_POLICIES: frozenset[str] = frozenset(
    {"warn", "raise", "silent"}
)


# Overloads narrow the return type on the `as_dict` literal so callers
# don't see a `dict | list` union they have to pattern-match. Without
# these, every `read(..., as_dict=False)` call site has to either
# `cast()` or eat a mypy union-attr error when it accesses list-only
# operations on the result.
@overload
def read(
    path: Path | str,
    *,
    profile: DSVProfile | None = ...,
    as_dict: Literal[True] = ...,
    clean: CleanSetting = ...,
    headers: list[str] | None = ...,
    skip_empty_rows: bool = ...,
    deep_scan: bool = ...,
    on_overflow: OverflowPolicy = ...,
) -> Iterator[dict[str, str]]: ...


@overload
def read(
    path: Path | str,
    *,
    profile: DSVProfile | None = ...,
    as_dict: Literal[False],
    clean: CleanSetting = ...,
    headers: list[str] | None = ...,
    skip_empty_rows: bool = ...,
    deep_scan: bool = ...,
    on_overflow: OverflowPolicy = ...,
) -> Iterator[list[str]]: ...


def read(
    path: Path | str,
    *,
    profile: DSVProfile | None = None,
    as_dict: bool = True,
    clean: CleanSetting = True,
    headers: list[str] | None = None,
    skip_empty_rows: bool = True,
    deep_scan: bool = True,
    on_overflow: OverflowPolicy = "warn",
) -> Iterator[dict[str, str] | list[str]]:
    """Stream cleaned data rows from a DSV file.

    Parameters
    ----------
    path
        File to read. The file is opened twice when `profile` is None:
        once (bounded) for profiling, once (streamed) for data.
    profile
        A pre-computed `DSVProfile`. Skips the profile pass. Useful
        when the caller has already run `profile_file` or wants to
        override detections.
    as_dict
        When True (default), yields dicts keyed by header name. When
        False, yields lists.
    clean
        - True (default): apply cleanmonkey's `"csv"` profile to
          every cell.
        - False: emit cell values byte-exact (modulo decoding).
        - str: name of a cleanmonkey profile (`"minimal"`,
          `"aggressive"`, ...).
        - cleanmonkey.Profile: use this profile directly.
        - Callable `str -> str`: applied to every cell. NOTE: the
          cleaner is ALSO applied to detected header names before
          they become dict keys, so a callable like `str.upper` or
          a case-folder can rename columns unexpectedly or cause
          key collisions. Use `as_dict=False` if you want callable
          cleaning applied to data only.
    headers
        Override detected headers. When the file has no detectable
        header and `as_dict=True`, pass this to name the columns.
        Defaults to `col_0`, `col_1`, ... in that case.
    skip_empty_rows
        When True (default), rows where every cell is whitespace-only
        are dropped silently — the common ETL contract. Set to False
        for domains where blank rows are semantic (fixed-format
        exports, audit spacing, placeholder markers).
    deep_scan
        Forwarded to `profile_file` when `profile` is None.
        Default True. Pass `False` for large or remote files where
        the full-file mixed-encoding pass is prohibitively
        expensive — the tradeoff is that late-file encoding
        corruption (a stray non-UTF-8 byte beyond the 256 KiB
        sample window) won't be surfaced.
    on_overflow
        How to handle rows wider than `effective_headers` when
        `as_dict=True` (overflow cells would be dropped by
        `_zip_to_dict`). Only meaningful in dict mode — list mode
        always preserves every cell.
        - `"warn"` (default): emit one `UserWarning` then continue,
          dropping overflow cells. Matches the historical behaviour;
          appropriate when the warning channel is observed.
        - `"raise"`: raise `ValueError` on the first overflow row
          and stop streaming. Use in unattended pipelines where
          `warnings.simplefilter("ignore")` upstream would otherwise
          mask the silent data loss.
        - `"silent"`: drop without warning. Use only when overflow
          is expected and intentional (rare).
    """
    if on_overflow not in _VALID_OVERFLOW_POLICIES:
        raise ValueError(
            f"on_overflow must be one of {sorted(_VALID_OVERFLOW_POLICIES)}, "
            f"got {on_overflow!r}"
        )
    path = Path(path)
    if profile is None:
        profile = profile_file(path, deep_scan=deep_scan)
    else:
        _validate_profile(profile, "read", path)

    clean_fn = _resolve_clean(clean)
    # `headers is not None` captures explicit caller intent —
    # including `headers=[]`, which means "I want empty dicts, don't
    # auto-generate anything." We track this separately so the lazy
    # first-row-width fallback below only fires when the caller gave
    # us no guidance at all.
    explicit_headers = headers is not None
    effective_headers = _resolve_headers(profile, headers, clean_fn)
    skip_rows = _rows_to_skip(profile)

    if as_dict and effective_headers:
        _warn_if_duplicate_headers(effective_headers)
    elif as_dict and explicit_headers and not effective_headers:
        # `read(headers=[], as_dict=True)` is intentional ("yield
        # empty dicts") but it's also a sharp edge — every cell of
        # every row gets discarded with no other signal. Warn once
        # so wrappers that pass an empty list by mistake (e.g. a
        # caller that filters their `headers` collection down to
        # zero) see it. Behaviour is unchanged.
        warnings.warn(
            "headers=[] with as_dict=True yields empty dicts and "
            "drops every cell; pass as_dict=False or a non-empty "
            "headers list if you didn't mean to discard all data",
            UserWarning,
            stacklevel=2,
        )

    # Track whether we've already warned about overflow rows so a
    # 10,000-row file with ragged data doesn't emit 10,000 warnings.
    overflow_warned = False

    with _open_text(path, profile) as fh:
        reader = _make_row_iterator(fh, profile)

        for i in range(skip_rows):
            try:
                next(reader)
            except StopIteration:
                # Skip consumed every row in the file — no data rows
                # to yield. Usually this means `profile.header_row.value`
                # is larger than the file's actual row count (e.g. a
                # caller-constructed profile with an out-of-range
                # header index). Silent empty output is hard to
                # diagnose; warn so a grep-based monitoring check
                # can surface it. The generator still returns empty
                # — we don't raise because a legitimately tiny file
                # might truncate mid-preamble.
                warnings.warn(
                    f"profile.header_row.value={skip_rows - 1} "
                    f"but file has only {i} row(s) before EOF; "
                    "no data rows will be yielded",
                    UserWarning,
                    stacklevel=2,
                )
                return

        for row in reader:
            if not row:
                continue
            # Clean BEFORE the empty-row check. str.strip() removes
            # ASCII whitespace and NBSP but NOT zero-width characters
            # (U+200B, U+FEFF, etc.) — so rows composed entirely of
            # invisibles used to pass the "is empty" check, get
            # cleaned into empty strings by cleanmonkey, and then
            # land in the output as ghost rows of empty cells.
            # Cleaning first means the emptiness check sees what
            # callers actually care about. Under `clean=False`
            # (byte-exact mode) we preserve original bytes and use
            # the raw strip() check — consistent with that mode's
            # "no content mutation" contract.
            cleaned = [clean_fn(cell) for cell in row] if clean_fn else list(row)
            if skip_empty_rows and not any(cell.strip() for cell in cleaned):
                continue
            if as_dict:
                # Lazy width resolution: if profiling couldn't determine
                # the column structure (no detected header, no
                # field_count) *and* the caller didn't override, fall
                # back to the first real row's width. Without this
                # check, `read(..., headers=[])` would be silently
                # replaced by the auto-generated col_N list.
                if not effective_headers and not explicit_headers:
                    effective_headers = [f"col_{i}" for i in range(len(cleaned))]
                if (
                    effective_headers
                    and len(cleaned) > len(effective_headers)
                ):
                    if on_overflow == "raise":
                        # Typed exception so downstream callers (the
                        # CLI's strict-mode gate; user code) can
                        # catch by class instead of substring-matching
                        # the message. Subclasses ValueError so
                        # existing `except ValueError` handlers are
                        # unaffected.
                        raise DictOverflowError(
                            row_width=len(cleaned),
                            header_width=len(effective_headers),
                        )
                    if on_overflow == "warn" and not overflow_warned:
                        warnings.warn(
                            f"row has {len(cleaned)} cells but only "
                            f"{len(effective_headers)} header(s); overflow "
                            "cells are dropped in dict output. Use "
                            "as_dict=False to preserve every cell, pass "
                            "a wider `headers=` list, or "
                            "on_overflow='raise' to fail loudly.",
                            UserWarning,
                            stacklevel=2,
                        )
                        overflow_warned = True
                yield _zip_to_dict(effective_headers, cleaned)
            else:
                yield cleaned


def _warn_if_duplicate_headers(headers: list[str]) -> None:
    """Emit a `UserWarning` when `headers` contains repeats.

    In dict-output mode, duplicate keys silently collapse — the last
    occurrence wins and every earlier column for that name is lost.
    That's real data loss, so we surface it once per read() call.
    Callers who want strict behavior can escalate the warning with
    ``warnings.filterwarnings("error")``.
    """
    seen: set[str] = set()
    duplicates: list[str] = []
    for name in headers:
        if name in seen and name not in duplicates:
            duplicates.append(name)
        seen.add(name)
    if duplicates:
        warnings.warn(
            f"duplicate header name(s) {duplicates}; later values "
            "overwrite earlier ones in dict output (use as_dict=False "
            "or pass a disambiguated `headers=` list to preserve all "
            "columns).",
            UserWarning,
            stacklevel=3,
        )


def _resolve_clean(setting: CleanSetting):
    """Return a `str -> str` callable, or None for no cleaning.

    Accepts:
    - `True`  → cleanmonkey's `"csv"` profile.
    - `False` → no cleaning (None).
    - `str`   → cleanmonkey profile name.
    - `cleanmonkey.Profile` → that profile.
    - Any `str -> str` callable → used as-is. Previously these were
      treated as Profile objects and crashed on first row with a
      confusing TypeError deep inside cleanmonkey.
    """
    if setting is False:
        return None
    if setting is True:
        return lambda text: cleanmonkey.clean(text, profile="csv")
    if isinstance(setting, str):
        return lambda text: cleanmonkey.clean(text, profile=setting)
    if isinstance(setting, cleanmonkey.Profile):
        return lambda text: cleanmonkey.clean(text, profile=setting)
    if callable(setting):
        return setting
    raise TypeError(
        f"clean must be bool, str, cleanmonkey.Profile, or callable, "
        f"got {type(setting).__name__}"
    )


def _resolve_headers(
    profile: DSVProfile,
    override: list[str] | None,
    clean_fn,
) -> list[str]:
    """Decide the header list to key dict rows by.

    Precedence: explicit override > profile-detected headers >
    auto-generated `col_N`. Detected headers are cleaned so a BOM or
    invisible char in the first cell doesn't produce a silently-broken
    key like `"﻿id"`.
    """
    if override is not None:
        return list(override)
    if profile.headers:
        if clean_fn:
            return [clean_fn(h) for h in profile.headers]
        return list(profile.headers)
    width = profile.field_count or 0
    return [f"col_{i}" for i in range(width)]


def _rows_to_skip(profile: DSVProfile) -> int:
    """How many physical rows to consume before the first data row.

    When a header is present at index N, skip N+1 (the N preamble rows
    plus the header itself). When no header is present, skip nothing —
    data starts at row 0.
    """
    header_index = profile.header_row.value if profile.header_row else None
    if header_index is None:
        return 0
    return header_index + 1


def _make_row_iterator(fh: IO[str], profile: DSVProfile) -> Iterator[list[str]]:
    """Return an iterator of rows (each row a list of cell strings)
    appropriate for `profile`'s detected dialect.

    For most files this is `csv.reader` with the detected delimiter
    and quote char. For files classified `method="single-column"`
    we choose between two parsing strategies based on whether a
    quote character was detected:

    1. No quote char detected → physical-line iteration. Each line
       becomes a one-cell row. The sentinel `delimiter.value` (U+001F
       or another Information Separator) is never used to split
       anything, eliminating the risk of the sentinel coinciding
       with content past the detection sample (~256 KiB).

    2. Quote char detected → csv.reader with the sentinel as
       delimiter. The file is using CSV-style quoting, which means
       multiline cells like `"hello\\nworld"` span multiple physical
       lines but are ONE logical row. Physical-line iteration would
       silently split them — actual data corruption: a 3-line file
       with one quoted-multiline cell yields three rows instead of
       two, and repair() then emits malformed output. csv.reader
       honours quote-aware row boundaries and joins those lines
       correctly. The sentinel-vs-content collision risk re-emerges
       on this path (a stray sentinel byte past the sample window
       would split the row), but is bounded: the sentinel is picked
       from the C0 separator block (extremely rare in real text)
       and an unexpected split surfaces as ragged rows the caller
       can detect via `_zip_to_dict` overflow warnings. Silent
       multi-row corruption was the worse failure mode.
    """
    if profile.delimiter and profile.delimiter.method == "single-column":
        if profile.quote_char and profile.quote_char.value:
            # Quoted single-column: defer to csv.reader so multiline
            # quoted cells stay one logical row.
            return csv.reader(fh, **_reader_kwargs(profile))
        return (
            [_strip_one_record_terminator(line)] for line in fh
        )
    return csv.reader(fh, **_reader_kwargs(profile))


def _strip_one_record_terminator(line: str) -> str:
    """Strip exactly one trailing record terminator from `line`.

    Python's universal-newline iteration over a file opened with
    `newline=""` yields each physical line WITH its terminator
    attached (`\\r\\n`, `\\n`, or `\\r`). We need to remove the
    terminator before the line becomes a single-column cell value.

    Naive `line.rstrip("\\r\\n")` strips ANY trailing combination
    of CR / LF, which over-eats data in the rare case where a
    line legitimately ends in a CR followed by the terminator
    sequence (`"abc\\r\\r\\n"` — meaningful trailing CR + CRLF
    record terminator, the kind of thing seen in some protocol
    dumps and binary-shaped exports). Strip exactly the
    terminator and preserve any trailing CRs that belong to the
    cell content.
    """
    if line.endswith("\r\n"):
        return line[:-2]
    if line.endswith("\n") or line.endswith("\r"):
        return line[:-1]
    return line


def _reader_kwargs(profile: DSVProfile) -> dict:
    # `_validate_profile` guarantees `profile.delimiter` is non-None
    # before any reader-touching code runs — assert here so mypy
    # narrows the union and a future refactor that bypasses
    # validation gets a loud failure instead of an AttributeError
    # on the first row.
    assert profile.delimiter is not None
    kwargs: dict = {"delimiter": profile.delimiter.value}
    if profile.quote_char and profile.quote_char.value:
        kwargs["quotechar"] = profile.quote_char.value
    else:
        # No quoting used — disable it so a stray quote mark in data
        # doesn't glue rows together.
        kwargs["quotechar"] = '"'
        kwargs["quoting"] = csv.QUOTE_NONE
    return kwargs


def _zip_to_dict(headers: list[str], row: list[str]) -> dict[str, str]:
    """Zip a row to a dict, padding short rows with empty strings and
    discarding overflow cells.

    Strict zip would raise on ragged rows, which is precisely the kind
    of input dsvmonkey is meant to survive. Repair (pad/truncate with
    a warning channel) is a job for the repair module — here we just
    keep the stream moving.
    """
    result: dict[str, str] = {}
    for i, key in enumerate(headers):
        result[key] = row[i] if i < len(row) else ""
    return result


_STRUCTURALLY_RESERVED_DELIMITERS_READER: frozenset[str] = frozenset(
    {"\n", "\r", '"', "'"}
)


def _validate_profile(
    profile: DSVProfile, op: str, path: Path | None = None
) -> None:
    """Reject partial or malformed profiles at the public API boundary.

    `read()` and `repair()` accept a caller-supplied `profile` to
    skip the profiling pass. A DSVProfile constructed without
    running `profile_file()` — i.e. with `encoding`/`delimiter`/
    `header_row` left at their default `None` — would previously
    AttributeError inside `_reader_kwargs` when it did
    `profile.delimiter.value`, OR decode silently as UTF-8 (the
    fallback in `_effective_text_encoding`) when the file was
    actually in another encoding — silent mojibake. Both are worse
    than a clear `ValueError` up front.

    When `path` is supplied, the profile's stored `.path` is compared
    against it: a profile built from file A applied to file B would
    otherwise parse B with A's delimiter / encoding / header
    assumptions, producing valid-looking but silently wrong output —
    an easy trap in cached-profile pipelines. Profiles with an empty
    `.path` (built via `profile_bytes` without a path argument) are
    exempt from this check — they're explicitly "not tied to a
    specific file."

    Only the *structural* fields downstream code dereferences are
    required; optional fields (like `headers`, `quote_char`) remain
    optional.
    """
    if path is not None and profile.path and profile.path != Path(""):
        try:
            profile_resolved = profile.path.resolve(strict=False)
            input_resolved = path.resolve(strict=False)
        except OSError:
            profile_resolved = profile.path
            input_resolved = path
        if profile_resolved != input_resolved:
            raise ValueError(
                f"{op}(): profile was built from {profile.path} but "
                f"the current call is processing {path}. Re-profile "
                "the target file (dsvmonkey.profile_file(path)) or "
                'clear `profile.path` to `Path("")` to bypass this '
                "check if the mismatch is intentional."
            )
    missing: list[str] = []
    if profile.delimiter is None or profile.delimiter.value is None:
        missing.append("delimiter")
    if profile.encoding is None or profile.encoding.value is None:
        # Encoding has a UTF-8 fallback in _effective_text_encoding,
        # but silently defaulting produces mojibake on non-UTF-8
        # input. Require the caller to be explicit.
        missing.append("encoding")
    if missing:
        raise ValueError(
            f"{op}(): profile is missing required field(s) {missing}. "
            "Build the profile via dsvmonkey.profile_file() or populate "
            "the fields explicitly."
        )

    # mypy can't carry the narrowing from `profile.X is None or
    # profile.X.value is None → missing.append(...) → raise` across
    # the `missing` indirection, so re-state the invariant explicitly.
    # These asserts are runtime no-ops on the validated path and a
    # loud failure on any future refactor that bypasses the missing-
    # fields check.
    assert profile.delimiter is not None
    assert profile.encoding is not None

    # Shape validation. A caller-supplied delimiter that's multi-char
    # or structurally reserved (`\n`, `\r`, `"`, `'`) would otherwise
    # blow up deep in csv.reader with a TypeError — "profile is fine"
    # + "parse crashes" is the exact unclean failure mode the
    # presence check already guards against. Same rules the library's
    # own `target_delimiter` validator enforces at the repair()
    # boundary, applied here so caller-crafted profiles get the same
    # clean error.
    delim = profile.delimiter.value
    if not isinstance(delim, str):
        # A non-string delimiter (e.g. `42`, `b","`) would reach
        # `len()` with TypeError instead of our ValueError —
        # inconsistent with the "boundary validation raises
        # ValueError" contract every other guard upholds.
        raise ValueError(
            f"{op}(): profile.delimiter.value must be a string, "
            f"got {type(delim).__name__} ({delim!r})"
        )
    if len(delim) != 1:
        raise ValueError(
            f"{op}(): profile.delimiter.value must be a single "
            f"character, got {delim!r} (length {len(delim)})"
        )
    if delim in _STRUCTURALLY_RESERVED_DELIMITERS_READER:
        raise ValueError(
            f"{op}(): profile.delimiter.value {delim!r} is reserved "
            "by DSV parsing (newlines and quote characters can't be "
            "delimiters); pick a different character"
        )

    # Encoding codec must actually exist. Without this, a typo like
    # `encoding.value = "ut-8"` in a caller-crafted profile sails
    # through validation and then blows up inside `Path.open` with
    # `LookupError` — a different exception type from the rest of
    # the library's validation surface.
    enc = profile.encoding.value
    if not isinstance(enc, str):
        # `codecs.lookup(42)` raises TypeError; guard here for the
        # same boundary-error-consistency reason as delimiter.
        raise ValueError(
            f"{op}(): profile.encoding.value must be a string, "
            f"got {type(enc).__name__} ({enc!r})"
        )
    try:
        codecs.lookup(enc)
    except LookupError:
        raise ValueError(
            f"{op}(): profile.encoding.value {enc!r} is not a "
            "recognised codec name"
        ) from None

    # `quote_char` is optional (None → QUOTE_NONE parsing), but if
    # present it must be a single character. A multi-char or empty
    # value reaches csv.reader as TypeError rather than a clean
    # boundary error.
    if profile.quote_char is not None and profile.quote_char.value is not None:
        qc = profile.quote_char.value
        if not isinstance(qc, str) or len(qc) != 1:
            raise ValueError(
                f"{op}(): profile.quote_char.value must be a single "
                f"character (or None for no quoting), got {qc!r}"
            )

    # `header_row` is optional (None → no header skip), but if
    # present its .value must be either None or a non-negative int.
    # A string `"0"` would fail `skip_rows + 1` with TypeError
    # deep in the reader; bool would arithmetically work but is
    # nearly always a caller bug.
    if profile.header_row is not None and profile.header_row.value is not None:
        hv = profile.header_row.value
        if isinstance(hv, bool) or not isinstance(hv, int):
            raise ValueError(
                f"{op}(): profile.header_row.value must be an int "
                f"or None, got {type(hv).__name__} ({hv!r})"
            )
        if hv < 0:
            raise ValueError(
                f"{op}(): profile.header_row.value must be "
                f"non-negative, got {hv}"
            )


def _effective_text_encoding(profile: DSVProfile) -> str:
    """Resolve the codec name to use when opening the file as text.

    For endianness-specific UTF-16/UTF-32 codecs (utf-16-le, utf-16-be,
    utf-32-le, utf-32-be), the codec does NOT consume the BOM — the
    `\\xff\\xfe` / `\\xfe\\xff` bytes decode to a literal `\\ufeff`
    (ZWNBSP) at position 0 of the stream. When the profile tells us
    there's a BOM, switch to the auto-detecting variant (`utf-16`,
    `utf-32`), which strips the BOM and picks endianness from it.

    `utf-8-sig` and plain `utf-16` / `utf-32` already strip their own
    BOM so no remap is needed; `utf-8` without -sig is only picked
    when there's no BOM so remapping it would just mis-decode.

    Caller-supplied profiles may use legitimate codec aliases / casing
    (e.g. `"UTF-16-LE"`, `"utf_16_le"`) that Python's `codecs.lookup`
    accepts. The BOM-strip dict is keyed in canonical lowercase-with-
    hyphens form, so we normalise the encoding string before lookup
    to avoid leaking a BOM into the first cell of profiles built by
    hand. The returned value is the original string (with the remap
    applied if needed) so error messages and inspect output keep the
    caller's preferred spelling.

    Shared by `read()` and `repair()` so the two paths can't drift —
    a BOM stripped in one must be stripped in the other.
    """
    encoding = profile.encoding.value if profile.encoding else "utf-8"
    if profile.has_bom:
        normalised = encoding.lower().replace("_", "-")
        if normalised in _BOM_STRIPPING_EQUIVALENT:
            encoding = _BOM_STRIPPING_EQUIVALENT[normalised]
    return encoding


@contextmanager
def _open_text(path: Path, profile: DSVProfile) -> Iterator[IO[str]]:
    """Open `path` as text using the BOM-aware effective encoding."""
    encoding = _effective_text_encoding(profile)
    with path.open("r", encoding=encoding, errors="replace", newline="") as fh:
        yield fh


# Endian-specific UTF-16/32 codecs don't strip their own BOM. Map
# them to the auto-detecting variants when we know a BOM is present.
_BOM_STRIPPING_EQUIVALENT: dict[str, str] = {
    "utf-16-le": "utf-16",
    "utf-16-be": "utf-16",
    "utf-32-le": "utf-32",
    "utf-32-be": "utf-32",
}
