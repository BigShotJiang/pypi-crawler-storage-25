"""Quote character detection.

Runs *after* the delimiter is known. For each candidate quote char,
count how many field *starts* appear wrapped in that character —
either at the beginning of a line or immediately after the delimiter.
The winner is whichever candidate appears at field boundaries most
often; if neither does, the file likely uses no quoting at all
(`value=None`).

Counting at field *starts* rather than wrapped fields is deliberate:
a row like `1,"Doe, John",admin` has one quoted field that contains
the delimiter. A naive split-by-delimiter would see the quoted cell
as two pieces (`"Doe` and ` John"`), neither of which looks wrapped
on its own — silently returning "no quoting" and cascading into
`csv.QUOTE_NONE` for parsing. Counting `<delim><quote>` and line-
start `<quote>` occurrences catches that case because the pattern
marks a *start*, not a wrapped span.

Field-total counting uses `csv.reader` so fields that span physical
lines (quoted newlines) aren't counted multiple times. Earlier code
used `splitlines()`, which over-counted when files contain embedded
newlines in quoted cells.
"""

from __future__ import annotations

import csv
import io

from dsvmonkey.profile import DetectionAlternative, DetectionResult

_DEFAULT_CANDIDATES: tuple[str, ...] = ('"', "'")
# Scan enough physical lines to see past realistic preambles.
# The 30-line default missed quoted data in files with metadata
# preambles longer than that, which then parsed with no-quoting
# and split embedded delimiters into extra fields — data corruption,
# not a confidence issue. 1000 lines covers virtually every real-
# world preamble while staying bounded by the upstream 256 KiB
# sample (which tops out around 5000 short lines anyway). Cost is
# linear in lines scanned; 1000 is still cheap.
_DEFAULT_MAX_LINES = 1000


def detect_quote_char(
    sample: str,
    delimiter: str,
    candidates: tuple[str, ...] = _DEFAULT_CANDIDATES,
    max_lines: int = _DEFAULT_MAX_LINES,
) -> DetectionResult:
    """Infer the quote character given a known `delimiter`.

    Returns `value=None` when no evidence of quoting is found — which is
    a real and common outcome (plenty of DSV files quote nothing).
    """
    physical_lines = [
        line for line in sample.splitlines() if line.strip()
    ][:max_lines]
    if not physical_lines:
        return DetectionResult(
            value=None,
            confidence=0.5,
            method="absent",
            warnings=["empty sample"],
        )

    # Thread the caller's max_lines into the logical-row cap so the
    # denominator tracks the same sample window as the numerator
    # (field-start counts). Previously this was hardcoded to
    # _DEFAULT_MAX_LOGICAL_ROWS (30), which made confidence
    # unexplainable when max_lines was tuned: a caller raising
    # max_lines to 100 got a numerator over 100 lines and a
    # denominator over 30, producing a skewed ratio.
    total_fields = _count_logical_fields(sample, delimiter, max_lines)
    if total_fields == 0:
        # csv.reader failed to produce any fields. Fall back to the
        # physical-line field estimate so detection still runs.
        total_fields = sum(line.count(delimiter) + 1 for line in physical_lines)

    scored: list[tuple[str, int, int]] = []  # (quote, field_starts, total_fields)
    for quote in candidates:
        starts = _count_quoted_field_starts_in_text(sample, delimiter, quote, max_lines)
        scored.append((quote, starts, total_fields))

    scored.sort(key=lambda row: row[1], reverse=True)
    best_quote, best_starts, total_fields = scored[0]

    if best_starts == 0:
        return DetectionResult(
            value=None,
            confidence=0.8,
            method="absent",
        )

    # Balance sanity check. Counting field-starts is a fast
    # heuristic, but it can't tell the difference between "genuine
    # single-quote quoting" and "apostrophes as the first character
    # of prose values" (`'twas the night`, `'alice smith`). If the
    # detected candidate is really an apostrophe in data, turning
    # it into a quote char makes csv.reader swallow whole blocks
    # of rows until it finds an unmatched `'` — catastrophic row
    # merging, not a confidence issue.
    #
    # Legitimate quoting has matching opens and closes: every
    # quote-at-field-start is followed by a quote-at-field-end.
    # Apostrophes in data have opens with no corresponding closes.
    # Count both positions and require rough balance; if opens
    # vastly outnumber closes, the candidate isn't really a
    # quote char.
    if not _quote_candidate_is_balanced(
        sample, delimiter, best_quote, max_lines
    ):
        return DetectionResult(
            value=None,
            confidence=0.7,
            method="absent",
            warnings=[
                f"found {best_starts} {best_quote!r} occurrences at "
                "field starts, but parsing with it as quote char "
                "merges rows (unterminated quoted fields swallow "
                "lines); treating as data, not quoting"
            ],
        )

    # Confidence: fraction of fields that start with the quote char,
    # capped. A file where every field is quoted maxes at 1.0; a file
    # with a handful of quoted fields lands mid-range.
    confidence = min(best_starts / max(total_fields * 0.5, 1), 1.0)
    confidence = max(confidence, 0.5)

    alternatives = [
        DetectionAlternative(
            value=quote,
            confidence=min(starts / max(total * 0.5, 1), 1.0),
            reason=f"{starts}/{total} field starts wrapped",
        )
        for quote, starts, total in scored[1:]
        if starts > 0
    ]

    return DetectionResult(
        value=best_quote,
        confidence=confidence,
        method="field-start-count",
        alternatives=alternatives,
    )


def _count_quoted_field_starts_in_text(
    sample: str,
    delimiter: str,
    quote: str,
    max_lines: int,
) -> int:
    """Count occurrences of quoted-field-start patterns in `sample`.

    A field *starts* either at the beginning of a line or right after
    a delimiter. We count positions where the next char is `quote`.
    This catches `1,"Doe, John"` — the quote char appears after the
    first comma, giving a hit — whereas naive split-and-check-wrapped
    would miss it because `"Doe` alone isn't a wrapped field.

    Scans only up to `max_lines` physical lines (matching the
    document-size bound the caller uses).
    """
    starts = 0
    delim_then_quote = delimiter + quote
    for line in sample.splitlines()[:max_lines]:
        if not line:
            continue
        if line.startswith(quote):
            starts += 1
        starts += line.count(delim_then_quote)
    return starts


def _quote_candidate_is_balanced(
    sample: str, delimiter: str, quote: str, max_lines: int
) -> bool:
    """True when quote-at-field-start counts approximately match
    quote-at-field-end counts.

    Legitimate quoting has matched opens and closes (`"alice"` has
    one of each, a multi-line quoted field has its open on one
    physical line and its close on another). Apostrophes used as
    the first character of prose (`'twas`, `'alice`) produce opens
    with no corresponding closes. A 60% close-to-open ratio is the
    slack floor — lower values indicate data, not quoting. The
    slack accommodates files where a multi-line quoted field is
    truncated at the sample boundary with its close missing.
    """
    starts = _count_quoted_field_starts_in_text(
        sample, delimiter, quote, max_lines
    )
    ends = _count_quoted_field_ends_in_text(
        sample, delimiter, quote, max_lines
    )
    if starts == 0:
        return True
    return ends >= starts * 0.6


def _count_quoted_field_ends_in_text(
    sample: str, delimiter: str, quote: str, max_lines: int
) -> int:
    """Count occurrences of quote char at field-end positions:
    immediately before a delimiter, or at end of line."""
    ends = 0
    quote_then_delim = quote + delimiter
    for line in sample.splitlines()[:max_lines]:
        if not line:
            continue
        if line.endswith(quote):
            ends += 1
        ends += line.count(quote_then_delim)
    return ends


def _count_logical_fields(sample: str, delimiter: str, max_rows: int) -> int:
    """Count total logical fields using csv.reader so quoted newlines
    don't over-count (a multi-line quoted cell is one field, not two).

    Uses quotechar='"' — the common case; for files that use single-
    quote quoting the count will be slightly off, but still proportional
    to actual field count. The confidence ratio tolerates this.
    """
    try:
        reader = csv.reader(
            io.StringIO(sample),
            delimiter=delimiter,
            quotechar='"',
        )
        total = 0
        for i, row in enumerate(reader):
            if i >= max_rows:
                break
            if row:
                total += len(row)
        return total
    except csv.Error:
        return 0
