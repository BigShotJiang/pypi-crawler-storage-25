"""Encoding detection.

Strategy, in order:

1. Check for a BOM. If present, the encoding is known with certainty.
2. Try each candidate encoding in strict mode. Score every one that
   decodes by *content quality* — printable ratio, replacement-char
   count, and mojibake-bigram frequency — not just "did it decode".
   `latin-1` decodes any byte sequence, so a float-only "did it decode"
   test would always pick it.
3. Separately, check whether the file looks like it contains *multiple*
   encodings (common when files are concatenated from different sources).
   This is surfaced as a flag; repair of mixed-encoding files is handled
   elsewhere.
"""

from __future__ import annotations

import codecs
import unicodedata
from pathlib import Path

from dsvmonkey.profile import DetectionAlternative, DetectionResult

# BOM markers, longest first — UTF-32 BOMs share a prefix with UTF-16
# BOMs, so order matters.
_BOM_MARKERS: tuple[tuple[bytes, str], ...] = (
    (b"\x00\x00\xfe\xff", "utf-32-be"),
    (b"\xff\xfe\x00\x00", "utf-32-le"),
    (b"\xef\xbb\xbf", "utf-8-sig"),
    (b"\xff\xfe", "utf-16-le"),
    (b"\xfe\xff", "utf-16-be"),
)

# Candidates are ordered by prior likelihood for DSV files in the wild.
# `latin-1` is last because it always succeeds — it's the catch-all.
#
# UTF-16/UTF-32 deliberately excluded: without a BOM they're wildly
# ambiguous — any even-length byte sequence "decodes" into printable-
# looking codepoints and wins the score on a short sample. Real-world
# UTF-16 DSV files include a BOM (the `_detect_bom` step catches those);
# truly BOM-less UTF-16 is rare enough that callers should pass the
# encoding explicitly rather than hope for a guess.
_CANDIDATE_ENCODINGS: tuple[str, ...] = (
    "utf-8",
    "cp1252",
    "mac_roman",
    "cp437",
    "latin-1",
)

# Sequences that appear when UTF-8 bytes are decoded as cp1252/latin-1.
# Their presence in a decoded string is strong evidence the *wrong*
# encoding was used.
# `â€` is added as a 2-char prefix: any UTF-8 sequence that starts with
# 0xE2 0x80 (the U+2000–U+207F General Punctuation block — curly quotes,
# en/em dashes, zero-width spaces, etc.) decodes in cp1252/latin-1 as
# `â€` followed by another char. Legitimate text almost never contains
# that pair.
_MOJIBAKE_BIGRAMS: tuple[str, ...] = (
    "Ã©", "Ã¨", "Ã¡", "Ã­", "Ã³", "Ãº", "Ã±", "Ã§",
    "â€",
    "Â ", "Â£", "Â©", "Â®",
)

_DEFAULT_SAMPLE_SIZE = 65536


def detect_encoding(
    data: bytes,
    sample_size: int = _DEFAULT_SAMPLE_SIZE,
) -> DetectionResult:
    """Infer the text encoding of `data`.

    `sample_size` bounds how many leading bytes are considered. Detection
    on a sample is fine for the common case; mixed-encoding detection
    (which needs the whole file) lives in `detect_mixed_encoding`.
    """
    sample = data[:sample_size]

    bom_result = _detect_bom(sample)
    if bom_result is not None:
        return bom_result

    utf16_result = _detect_bomless_utf16(sample)
    if utf16_result is not None:
        return utf16_result

    scored: list[tuple[str, float, str]] = []
    for encoding in _CANDIDATE_ENCODINGS:
        try:
            decoded = sample.decode(encoding, errors="strict")
        except UnicodeDecodeError:
            continue
        score, reason = _score_decoded(decoded, encoding)
        scored.append((encoding, score, reason))

    if not scored:
        # Shouldn't happen — latin-1 always decodes — but be defensive.
        return DetectionResult(
            value="latin-1",
            confidence=0.1,
            method="fallback",
            warnings=["no candidate encoding decoded strictly"],
        )

    scored.sort(key=lambda row: row[1], reverse=True)
    best_encoding, best_score, best_reason = scored[0]

    alternatives = [
        DetectionAlternative(value=enc, confidence=score, reason=reason)
        for enc, score, reason in scored[1:4]
    ]

    return DetectionResult(
        value=best_encoding,
        confidence=best_score,
        method="content-scored",
        alternatives=alternatives,
        warnings=[best_reason] if best_score < 0.6 else [],
    )


def detect_mixed_encoding(
    data: bytes, max_failure_ratio: float = 0.05
) -> bool:
    """Flag in-memory byte strings where a *small* number of non-UTF-8
    bytes appears in an otherwise valid UTF-8 sample that also contains
    genuine UTF-8 multi-byte sequences.

    Heuristic: decode the whole buffer with `errors="surrogateescape"`.
    That maps each invalid byte to a unique surrogate in U+DC80–U+DCFF
    (a reserved range that cannot appear in legitimate decoded text).
    Count those surrogates — that's the decode-failure count, exactly.
    Flag as mixed when:

    - there's at least one decode failure (something is wrong), AND
    - the valid regions contain UTF-8 multi-byte sequences (positive
      evidence the file was UTF-8 to begin with), AND
    - failures are a small fraction of the buffer (pure cp1252 files
      have failures every few bytes — that's "not UTF-8", not "mixed").

    Previously this walked a single-byte-skip + retry path: decode
    failed at position N, skip byte N, retry on data[N+1:]. Two
    adjacent bad bytes (a common concatenation artefact — e.g. a
    Windows CRLF boundary that corrupted two bytes) made the retry
    fail and the function silently returned False, under-reporting
    real mixed-encoding content. The surrogate-escape counter has no
    such blind spot: adjacent bad bytes produce adjacent surrogates
    and are counted correctly.

    `max_failure_ratio` is looser than `scan_file_mixed_encoding`'s
    0.001 default because this function runs on a bounded sample
    (typically 256 KiB) where a couple of failures should still
    flag; the streaming scan sees the whole file and can afford a
    tighter ratio.

    Known limitation: pure-ASCII UTF-8 files with a handful of bad
    bytes are NOT flagged, because there's no way to distinguish
    them from a cp1252 file with a few smart quotes without content
    understanding. `"hello,world\\n"` + `b"\\x92"` and
    `"don't,worry\\n"` encoded as cp1252 are structurally identical:
    both are ASCII-heavy with sparse non-ASCII bytes. Requiring
    positive UTF-8 multi-byte evidence is how we disambiguate —
    genuine UTF-8-with-corruption files have at least one valid
    multi-byte sequence in the clean regions; pure-cp1252 files
    don't. Callers who know their pipeline is UTF-8-only should
    validate independently (or pass `encoding="utf-8"` with
    `errors="strict"` to the reader to catch corruption at read
    time).

    For whole-file checking (late-file corruption beyond any sample),
    use `scan_file_mixed_encoding`.
    """
    if not data:
        return False
    decoder = codecs.getincrementaldecoder("utf-8")(errors="surrogateescape")
    text = decoder.decode(data, final=True)

    failure_count = 0
    multibyte_found = False
    for ch in text:
        codepoint = ord(ch)
        if 0xDC80 <= codepoint <= 0xDCFF:
            failure_count += 1
        elif codepoint > 127:
            multibyte_found = True

    if failure_count == 0 or not multibyte_found:
        return False
    return failure_count / len(data) <= max_failure_ratio


def scan_file_mixed_encoding(
    path: Path,
    chunk_size: int = 1_048_576,
    max_failure_ratio: float = 0.001,
) -> bool:
    """Stream `path` from disk looking for isolated non-UTF-8 bytes
    anywhere in the file, not just a sample prefix.

    Returns True when the file is mostly UTF-8 but has a small number
    of non-UTF-8 bytes — the concatenated-exports signature. Files
    that fail UTF-8 throughout (i.e. they're just cp1252 or latin-1)
    are reported as non-mixed: that's "not UTF-8", not "mixed".

    `max_failure_ratio` bounds how many decode failures per byte the
    file can have before it's classified as non-UTF-8 rather than
    mixed. 0.001 (= 0.1%) is generous enough for a handful of
    concatenation-boundary bytes in a multi-megabyte file while
    rejecting a file with a failure every few cells.

    Uses `codecs.IncrementalDecoder` so UTF-8 multi-byte sequences
    that span chunk boundaries are buffered across reads instead of
    producing spurious decode failures. Earlier versions that did a
    best-effort carry created boundary-induced false failures at
    certain chunk sizes, which could misclassify valid UTF-8 as
    non-UTF-8 or hide real mixed-encoding flags.

    The scan always runs to EOF. A previous optimisation short-
    circuited to "not mixed" as soon as the running failure ratio
    exceeded threshold, but that was chunk-size-dependent: early
    clustered bad bytes in the first chunk would trip the
    short-circuit even when later clean bytes would have brought
    the ratio back under threshold by EOF. False negatives on
    mixed-encoding are the exact observability failure this
    detector exists to prevent.
    """
    failure_count = 0
    valid_found = False
    multibyte_found = False
    total_bytes = 0
    # `surrogateescape` maps each invalid byte to a unique low-surrogate
    # code point in U+DC80–U+DCFF. That range is reserved for this
    # purpose and cannot appear in legitimate decoded text, so counting
    # surrogates exactly counts decode failures — unlike `errors=replace`,
    # which substitutes U+FFFD and then collides with any genuine U+FFFD
    # already in the source (a real character that turns up in rare
    # datasets where the author embedded a visible "replacement" glyph).
    # The incremental decoder still buffers incomplete multi-byte
    # sequences across chunk boundaries, so no boundary-induced failures
    # are counted.
    decoder = codecs.getincrementaldecoder("utf-8")(errors="surrogateescape")

    def _scan(text: str) -> None:
        """Update counters from `text`."""
        nonlocal failure_count, valid_found, multibyte_found
        for ch in text:
            codepoint = ord(ch)
            if 0xDC80 <= codepoint <= 0xDCFF:
                failure_count += 1
            else:
                valid_found = True
                if not multibyte_found and codepoint > 127:
                    multibyte_found = True

    with path.open("rb") as fh:
        while True:
            chunk = fh.read(chunk_size)
            if not chunk:
                break
            total_bytes += len(chunk)
            _scan(decoder.decode(chunk, final=False))

    # Flush any trailing buffered state; a partial sequence at EOF
    # becomes a real failure here.
    _scan(decoder.decode(b"", final=True))

    if total_bytes == 0 or not valid_found or failure_count == 0:
        return False
    if not multibyte_found:
        # Pure-ASCII file with a few non-ASCII bytes. Could be cp1252
        # or latin-1 as easily as corrupted UTF-8 — refuse to guess.
        return False
    return failure_count / total_bytes <= max_failure_ratio


def _detect_bomless_utf16(sample: bytes) -> DetectionResult | None:
    """Detect UTF-16 without a BOM via null-byte parity.

    UTF-16 encodings of ASCII-heavy text — including almost every DSV
    file, which is commas and digits and short Latin words — put a
    `\\x00` byte in every other position. Which position depends on
    endianness:

    - UTF-16-LE of `"a"` is `b"a\\x00"`        → nulls at odd positions.
    - UTF-16-BE of `"a"` is `b"\\x00a"`        → nulls at even positions.

    Sound plain UTF-8 or cp1252 has effectively zero null bytes. So
    a sample with a high null-byte rate concentrated on one parity is
    almost certainly BOM-less UTF-16; the opposite parity should have
    virtually no nulls, which lets us distinguish UTF-16 from random
    binary data that just happens to contain lots of zeros.
    """
    n = len(sample)
    if n < 32:
        # Too small to be confident; let the content-scored pass handle it.
        return None

    # Counting on just the first few KB is enough — the pattern is
    # essentially uniform across a UTF-16 file.
    window = sample[: min(4096, n)]
    wlen = len(window)

    even_positions = (wlen + 1) // 2
    odd_positions = wlen // 2
    even_nulls = sum(1 for i in range(0, wlen, 2) if window[i] == 0)
    odd_nulls = sum(1 for i in range(1, wlen, 2) if window[i] == 0)

    even_ratio = even_nulls / even_positions if even_positions else 0.0
    odd_ratio = odd_nulls / odd_positions if odd_positions else 0.0

    # Require a strong concentration on one side and near-absence on
    # the other. Thresholds chosen empirically: 0.5 catches "mostly
    # ASCII" UTF-16, 0.1 on the opposite side rejects binary noise.
    if even_ratio >= 0.5 and odd_ratio <= 0.1:
        encoding = "utf-16-be"
    elif odd_ratio >= 0.5 and even_ratio <= 0.1:
        encoding = "utf-16-le"
    else:
        return None

    # Final verification: the sample must actually decode under the
    # inferred encoding. A BOM-less file that only *looks* UTF-16-like
    # but can't decode isn't one.
    try:
        sample.decode(encoding, errors="strict")
    except UnicodeDecodeError:
        return None

    return DetectionResult(
        value=encoding,
        confidence=0.85,
        method="null-byte-parity",
        warnings=["BOM-less UTF-16 inferred from null-byte pattern"],
    )


def _detect_bom(sample: bytes) -> DetectionResult | None:
    for marker, encoding in _BOM_MARKERS:
        if sample.startswith(marker):
            return DetectionResult(
                value=encoding,
                confidence=1.0,
                method="bom",
            )
    return None


def _is_legitimate_char(ch: str) -> bool:
    """True if `ch` plausibly belongs in decoded text.

    `str.isprintable()` is too strict: it returns False for format
    characters (Cf) like `\\u200b` ZWSP and `\\ufeff` BOM, which are
    intentional Unicode — their presence should not penalize a utf-8
    decode relative to a cp1252 mojibake that happens to consist of
    printable Ll/Sc chars.
    """
    if ch in "\n\r\t":
        return True
    category = unicodedata.category(ch)
    if category.startswith("C"):
        # Treat format chars (Cf) as legitimate; reject control (Cc),
        # surrogate (Cs), private use (Co), unassigned (Cn).
        return category == "Cf"
    return True


def _score_decoded(text: str, encoding: str) -> tuple[float, str]:
    """Return (score in [0, 1], human-readable reason)."""
    if not text:
        return 0.0, "empty sample"

    length = len(text)
    printable = sum(1 for ch in text if _is_legitimate_char(ch))
    replacement = text.count("�")

    printable_ratio = printable / length
    replacement_ratio = replacement / length

    mojibake_hits = sum(text.count(seq) for seq in _MOJIBAKE_BIGRAMS)
    # Normalize against sample length so long files aren't unduly penalized
    # for a single hit, but several hits in a short sample still count.
    mojibake_ratio = min(mojibake_hits / max(length / 100, 1), 1.0)

    # Control-character density: the clearest signal of "decoded
    # noise". Real text has 0–2 control chars outside \n \r \t
    # (rare typo or embedded escape); random binary through single-
    # byte codecs (latin-1, cp437, mac_roman, cp1252) hits 10–25%
    # control chars because bytes 0x00–0x1F decode to Cc code points
    # under those codecs. This signal is encoding-agnostic: pure
    # Japanese / CJK / emoji text scores identically to English
    # (near-zero Cc ratio) while random binary gets rejected.
    #
    # Previously the detector penalised on ASCII ratio, which was a
    # bug I introduced while fixing random-cp437 false positives —
    # it mistakenly punished legitimate non-Latin text. The
    # control-char signal targets the real noise signature without
    # the language bias.
    cc_count = sum(
        1 for ch in text
        if ch not in "\n\r\t" and unicodedata.category(ch) == "Cc"
    )
    cc_ratio = cc_count / length

    score = printable_ratio - replacement_ratio - (mojibake_ratio * 0.5)

    # Penalty kicks in above a small noise-floor (0.02 = 2%, well
    # above what a typo in real text would produce) and ramps
    # linearly toward zero as Cc density rises. At 12% Cc, the
    # score is already scaled by 0 — random-binary decode can't
    # masquerade as a confident pick.
    _CC_NOISE_FLOOR = 0.02
    _CC_PENALTY_SLOPE = 10.0
    if cc_ratio > _CC_NOISE_FLOOR:
        score *= max(
            0.0, 1.0 - (cc_ratio - _CC_NOISE_FLOOR) * _CC_PENALTY_SLOPE
        )

    # latin-1 decodes any byte sequence, so a tie should go to a more
    # specific encoding. Small penalty, not disqualifying.
    if encoding == "latin-1":
        score -= 0.1

    score = max(0.0, min(1.0, score))

    reason = (
        f"printable={printable_ratio:.2f} "
        f"replacement={replacement_ratio:.2f} "
        f"cc={cc_ratio:.2f} "
        f"mojibake_hits={mojibake_hits}"
    )
    return score, reason
