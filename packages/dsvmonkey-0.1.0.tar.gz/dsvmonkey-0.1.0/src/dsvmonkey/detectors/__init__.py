"""Detection modules.

Each module owns one axis of the profile (encoding, delimiter, ...) and
returns a `DetectionResult`. Keeping them separate means one can be
swapped or tuned without touching the others.
"""
