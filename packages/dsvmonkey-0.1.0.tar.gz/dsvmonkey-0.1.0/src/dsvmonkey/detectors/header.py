"""Header-row detection.

Real-world DSV files often don't put headers on row 0: decorative
title rows, metadata banners, blank spacers, or completely missing
headers all show up. This detector scores each candidate row for
"headeriness" and picks the strongest one — the window defaults to
the first 25 rows (`_DEFAULT_MAX_CANDIDATE_ROWS`, overridable per
call) so enterprise exports with long metadata preambles still
reach the real header. If nothing scores highly enough, it returns
`value=None` to signal "headers are probably missing".

Signals, in order of weight:

- **Type contrast with data rows below.** Headers are strings; data
  frequently contains numbers. When this row's cells are non-numeric
  in positions where later rows are numeric, that's strong evidence.
- **No numeric cells.** Headers rarely contain numbers.
- **Uniqueness.** Headers usually don't repeat column names.
- **All cells populated.** Header rows tend not to have gaps.

The input is a list of already-parsed rows (the caller has run
`csv.reader` with the detected delimiter/quotechar). Working on
parsed rows — not raw text — means the quote/delimiter handling is
consistent with what the reader will emit downstream.
"""

from __future__ import annotations

from dsvmonkey.profile import DetectionAlternative, DetectionResult

_DEFAULT_MAX_CANDIDATE_ROWS = 25
_DATA_LOOKAHEAD = 5
# 0.6 is the sweet spot: above the ~0.53 false-positive zone for
# headerless files whose first row happens to have mixed numeric and
# non-numeric cells (e.g. `1,2024-01-15,100`), and well below the
# ~0.9 that real headers score when there's any type contrast.
_HEADER_THRESHOLD = 0.6
# When type_contrast is below this, the remaining signals can't
# reliably distinguish "header" from "first data row in an all-
# string dataset." See _LOW_CONTRAST_THRESHOLD below for the
# stricter bar that applies in that regime.
_MIN_TYPE_CONTRAST_FOR_BASE_THRESHOLD = 0.25
_LOW_CONTRAST_THRESHOLD = 0.85


def detect_header_row(
    rows: list[list[str]],
    max_candidate_rows: int = _DEFAULT_MAX_CANDIDATE_ROWS,
) -> DetectionResult:
    """Infer which row index is the header.

    Returns `value=None` when no row scores above the header threshold
    — treat this as "headers are missing, data starts at row 0".

    `max_candidate_rows` bounds how many *scored candidates* are
    considered — NOT how many raw rows are read. Narrow preamble
    rows (single-cell rows when multi-cell rows exist in the
    sample) are filtered out before scoring, so a file with 40
    lines of single-cell metadata followed by a real header could
    scan ALL 40 metadata rows and still have budget left for the
    header as candidate #1. Default 25 scored candidates
    accommodates enterprise exports with long decorative / metadata
    preambles; raise further only if a file has more than ~20
    DISTINCT header-shape candidates (rare — most files have one
    or two).
    """
    if not rows:
        return DetectionResult(
            value=None,
            confidence=0.0,
            method="fallback",
            warnings=["no rows in sample"],
        )

    # When a file contains any multi-cell rows, single-cell rows are
    # almost always preamble (they don't contain the delimiter at all).
    # Excluding them prevents decorative / metadata rows from winning
    # the header-score lottery over the real header — a long
    # "META_LINE_N: x" preamble used to defeat a proper CSV header in
    # the first 25 rows simply because the narrow rows have only one
    # column to score against.
    any_multi_cell = any(len(r) >= 2 for r in rows if r)

    # Each candidate entry: (index, score, reason, id_ratio, type_contrast).
    candidates: list[tuple[int, float, str, float, float]] = []
    # Budget `max_candidate_rows` against *valid* candidates, not raw
    # indices. When a file has more preamble rows than the default
    # window (e.g. 35 narrow metadata rows before the real header),
    # counting raw indices would stop scanning before reaching the
    # header. The filter below skips narrow preamble rows; we keep
    # scanning past them until we've scored `max_candidate_rows`
    # plausible candidates or run out of rows entirely.
    for index, row in enumerate(rows):
        if len(candidates) >= max_candidate_rows:
            break
        if not _has_any_content(row):
            continue
        if any_multi_cell and len(row) < 2:
            continue
        data_rows = rows[index + 1 : index + 1 + _DATA_LOOKAHEAD]
        score, reason, type_contrast = _header_score(row, data_rows)
        id_ratio = _identifier_ratio(row)
        candidates.append((index, score, reason, id_ratio, type_contrast))

    if not candidates:
        return DetectionResult(
            value=None,
            confidence=0.0,
            method="fallback",
            warnings=[f"no populated rows in first {max_candidate_rows}"],
        )

    # Highest score wins. Within score ties, the row whose cells look
    # more like column identifiers wins — this is what breaks the
    # "decorative title row 0 + real header row 1" tie when both rows
    # are all-unique, all-populated, all-non-numeric and score
    # identically on the main signals. Without this tie-breaker a
    # title like ["Quarterly", "Report", "2024Q4", "Summary"] beats
    # the real ["id", "product", "qty", "price"] header on index-0.
    # Final tie-break is earliest-index.
    candidates.sort(key=lambda entry: (-entry[1], -entry[3], entry[0]))
    best_index, best_score, best_reason, _, best_type_contrast = candidates[0]

    # Without numeric differentiation between the candidate row and
    # the data below, raise the bar. no_numeric + populated + unique
    # alone can score ~0.70 on a headerless all-string dataset
    # (every row is non-numeric, fully populated, values unique
    # within the row) — the base 0.6 threshold would treat the
    # first data row as a header and drop it from output. Require
    # a stronger signal when we can't tell the difference.
    effective_threshold = _HEADER_THRESHOLD
    if best_type_contrast < _MIN_TYPE_CONTRAST_FOR_BASE_THRESHOLD:
        effective_threshold = _LOW_CONTRAST_THRESHOLD

    if best_score < effective_threshold:
        return DetectionResult(
            value=None,
            confidence=1.0 - best_score,
            method="absent",
            warnings=[
                f"best candidate (row {best_index}) scored "
                f"{best_score:.2f} (threshold {effective_threshold:.2f}); "
                "headers may be missing"
            ],
        )

    alternatives = [
        DetectionAlternative(value=idx, confidence=score, reason=reason)
        for idx, score, reason, _, _ in candidates
        if idx != best_index
    ][:5]

    warnings: list[str] = []
    if best_index > 0:
        warnings.append(
            f"{best_index} preamble row(s) before the header "
            "(decorative title, metadata, or blank spacers)"
        )

    return DetectionResult(
        value=best_index,
        confidence=best_score,
        method="headeriness-score",
        alternatives=alternatives,
        warnings=warnings,
    )


def _has_any_content(row: list[str]) -> bool:
    return any(cell.strip() for cell in row)


def _header_score(
    row: list[str], data_rows: list[list[str]]
) -> tuple[float, str, float]:
    """Return (score in [0, 1], reason, type_contrast).

    Weighted sum of four independent signals; each normalized to
    [0, 1]. `type_contrast` is returned separately so the caller
    can apply a stricter threshold when it's low — without numeric
    differentiation between the candidate row and the data below,
    the remaining signals (no_numeric, populated, unique) can't
    reliably distinguish "first row is column labels" from "first
    row is the first piece of data in an all-string dataset," and
    the weaker bar would false-positive a headerless all-string
    file into treating its first data row as header.
    """
    width = len(row)
    if width == 0:
        return 0.0, "empty row", 0.0

    non_empty = sum(1 for cell in row if cell.strip())
    populated_ratio = non_empty / width

    numeric_count = sum(1 for cell in row if _looks_numeric(cell))
    no_numeric_score = 1.0 - (numeric_count / width)

    non_empty_values = [cell.strip() for cell in row if cell.strip()]
    if non_empty_values:
        unique_ratio = len(set(non_empty_values)) / len(non_empty_values)
    else:
        unique_ratio = 0.0

    type_contrast = _type_contrast(row, data_rows)

    score = (
        0.30 * type_contrast
        + 0.25 * no_numeric_score
        + 0.25 * populated_ratio
        + 0.20 * unique_ratio
    )
    score = max(0.0, min(1.0, score))

    reason = (
        f"populated={populated_ratio:.2f} "
        f"no_numeric={no_numeric_score:.2f} "
        f"unique={unique_ratio:.2f} "
        f"type_contrast={type_contrast:.2f}"
    )
    return score, reason, type_contrast


def _type_contrast(row: list[str], data_rows: list[list[str]]) -> float:
    """Fraction of columns where this row is non-numeric and the data
    below is numeric in the same position.

    Returns 0.0 when there are no data rows to compare against (in
    which case the other signals carry all the weight).
    """
    if not data_rows or not row:
        return 0.0

    width = len(row)
    numeric_in_data = [0] * width
    for data_row in data_rows:
        for i in range(min(width, len(data_row))):
            if _looks_numeric(data_row[i]):
                numeric_in_data[i] += 1

    diff_columns = sum(
        1
        for i in range(width)
        if numeric_in_data[i] > 0 and not _looks_numeric(row[i])
    )
    return diff_columns / width


def _identifier_ratio(row: list[str]) -> float:
    """Fraction of non-empty cells that look like a column identifier.

    Column labels tend to be short single tokens, all-lowercase or
    snake_case or SCREAMING_CASE — never mixed-case prose with spaces.
    A typical decorative title row is the opposite ("Quarterly
    Report", "Q4 Sales Summary"). This signal is used only as a
    tie-breaker: when the main headeriness score can't distinguish
    two candidates, the row whose cells look more identifier-like is
    almost always the real header.

    Returns 0.0 for rows with no non-empty cells (to avoid a
    division-by-zero and because an all-empty row isn't a header
    anyway).
    """
    non_empty = [cell.strip() for cell in row if cell.strip()]
    if not non_empty:
        return 0.0
    return sum(1 for cell in non_empty if _is_identifier_shaped(cell)) / len(non_empty)


def _is_identifier_shaped(cell: str) -> bool:
    """Cheap "does this look like a column label" test.

    A cell is identifier-shaped if it's short, has no embedded
    whitespace, and is case-consistent (all-lowercase, all-uppercase,
    or all-digit — no Title Case). `_`, `-`, and digits are allowed.
    Doesn't need to be watertight: this signal only fires when the
    main header score has already produced a tie.
    """
    if not cell or len(cell) > 40:
        return False
    if any(ch.isspace() for ch in cell):
        return False
    # Strip the allowed punctuation and check the remainder is
    # case-consistent.
    letters = [ch for ch in cell if ch.isalpha()]
    if not letters:
        # Pure digits / symbols (e.g. "2024_q4" has letters;
        # "12345" doesn't). Treat as identifier-shaped — a bare
        # numeric column label is weird but not title-shaped.
        return True
    return all(ch.islower() for ch in letters) or all(ch.isupper() for ch in letters)


def _looks_numeric(cell: str) -> bool:
    """Cheap numeric test. Tolerates locale variants:

    - Plain ASCII float: `1.5`, `-3`, `42`.
    - European decimal: `1,50`.
    - US thousands grouping: `1,234.56`, `1,234`.

    Deliberately doesn't try to be clever beyond that: currency
    symbols, percent signs and date separators all cause `float()`
    to fail, which is fine here — those cells count as non-numeric,
    which pulls the header score toward "this is a header".

    Previous implementation only did a comma-as-dot replace, which
    parsed `1,234` (US thousands) as `1.234` (EU decimal) — same
    outcome of "is numeric" in this header-detection context, but
    the implicit coupling was fragile. Trying multiple
    interpretations explicitly makes the contract obvious and adds
    coverage for `1,234.56` (which the old single-replace would
    fail to parse).
    """
    s = cell.strip()
    if not s:
        return False
    # Plain (no separators).
    try:
        float(s)
        return True
    except ValueError:
        pass
    # EU decimal (comma is the decimal point).
    try:
        float(s.replace(",", "."))
        return True
    except ValueError:
        pass
    # US thousands grouping (commas are separators, dot is decimal).
    try:
        float(s.replace(",", ""))
        return True
    except ValueError:
        return False
