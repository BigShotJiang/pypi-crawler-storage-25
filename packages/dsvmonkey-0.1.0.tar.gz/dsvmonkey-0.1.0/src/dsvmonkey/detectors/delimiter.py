"""Delimiter detection.

Strategy: parse the sample with `csv.reader` once per candidate
delimiter, then score each by *field-count consistency* across rows.
A real delimiter produces a stable number of fields per line; a
coincidental character (e.g. a comma inside a pipe-delimited file)
produces ragged field counts.

We use `csv.reader` rather than naive `str.split(delim)` so that
quoted fields — including embedded delimiters and newlines — are
counted the way a real reader will count them. Quote-char defaults
to `"` during delimiter detection; the quote detector runs after and
a second pass could re-verify if needed.
"""

from __future__ import annotations

import csv
import io
import statistics

from dsvmonkey.profile import DetectionAlternative, DetectionResult

_DEFAULT_CANDIDATES: tuple[str, ...] = (",", "\t", ";", "|")
# ASCII Unit Separator (U+001F). Used as the sentinel "delimiter"
# when detection concludes the file is single-column: every row is
# then parsed as one field because U+001F cannot appear in real
# text, and any downstream csv.writer produces no separator byte
# for single-field rows. Picking a guaranteed-absent character is
# cleaner than threading a `value=None` / `single_column=True` flag
# through every consumer.
_SINGLE_COLUMN_SENTINEL = "\x1f"
# Backup sentinels in case the primary collides with sample
# content. ASCII 0x1c–0x1f are the four "Information Separator"
# control characters reserved by ANSI X3.4 for exactly this kind
# of structural use; collision in real-world text data is
# vanishingly rare but possible (binary-shaped exports, certain
# protocol dumps). Picking the rarest one not present in the
# sample is the cheapest defence.
_SENTINEL_CANDIDATES: tuple[str, ...] = ("\x1f", "\x1e", "\x1d", "\x1c")
# Minimum number of consistently-shaped delim-bearing rows that
# qualifies as a "real CSV block" worth preserving past a long
# preamble. Below this, a small number of consistent delim rows
# is more likely to be incidental punctuation (`'subject, body'`
# entries inside otherwise-prose notes) than a structured data
# section.
_MIN_CONSISTENT_CSV_ROWS = 3
# Matches the upstream sample cap in orchestrate.py so detection
# sees the whole parsed window. Bumped from 100 → 1000 alongside
# orchestrate's _MAX_SAMPLE_ROWS so a long metadata preamble
# (50–500 lines, common in regulated-industry exports) doesn't
# consume the budget before real data rows reach the scorer.
_DEFAULT_MAX_ROWS = 1000
# Quote characters to try while scoring delimiter candidates.
# Hardcoding `"` misses files that use single-quote quoting for cells
# containing embedded delimiters — the resulting field counts are
# wrong and delimiter scoring gets misled before quote detection even
# runs. Trying both and taking the higher-scoring variant per
# delimiter picks the right interpretation regardless.
_QUOTE_CANDIDATES: tuple[str, ...] = ('"', "'")


def detect_delimiter(
    sample: str,
    candidates: tuple[str, ...] = _DEFAULT_CANDIDATES,
    max_rows: int = _DEFAULT_MAX_ROWS,
) -> DetectionResult:
    """Infer the field delimiter of `sample`.

    `sample` must be a decoded string. The caller is responsible for
    stripping any BOM before calling.
    """
    scored: list[tuple[str, float, str, str]] = []

    for delimiter in candidates:
        # Try each possible quote interpretation, take the most
        # consistent field-count distribution. This disentangles
        # delimiter detection from quote-char detection in the
        # chicken-and-egg "need quote to parse, need parse to pick
        # delimiter" loop.
        best_score = 0.0
        best_reason = ""
        best_quote = '"'
        chose_any = False
        for quote in _QUOTE_CANDIDATES:
            counts = _field_counts(sample, delimiter, max_rows, quote)
            if len(counts) < 2 or max(counts) < 2:
                continue
            score, reason = _score_counts(counts)
            if score > best_score or not chose_any:
                best_score = score
                best_reason = reason
                best_quote = quote
                chose_any = True
        if not chose_any:
            continue
        scored.append((delimiter, best_score, best_reason, best_quote))

    if not scored:
        # Every candidate produced only single-field rows — no
        # character in `candidates` appears often enough to split
        # anything. Two possibilities we can't distinguish without
        # content understanding:
        #
        # (a) The file genuinely has one column (notes / log /
        #     single-metric export), OR
        # (b) The file uses a custom delimiter outside our default
        #     candidate set (`:`, `#`, `^`, `~`, etc.) and we just
        #     didn't try it.
        #
        # Previously this branch returned confidence=1.0 — which
        # overclaimed on case (b). Multi-column files with exotic
        # separators silently collapsed into "one cell per row"
        # with the library reporting full confidence. The verdict
        # is now emitted with low confidence and a diagnostic
        # warning so callers (and the inspect report) can see
        # we're guessing. Downstream parsing still uses the
        # U+001F sentinel so incidental characters in content
        # don't accidentally split fields, but a caller who
        # knows the actual delimiter can override
        # `profile.delimiter.value`.
        sentinel, sentinel_warning = _pick_safe_sentinel(sample)
        warnings = [
            "no candidate delimiter "
            f"({', '.join(repr(c) for c in candidates)}) produced "
            "multi-field rows. Treating as a single column, but "
            "the file may use a custom delimiter outside the "
            "default set — override profile.delimiter.value "
            "explicitly if so."
        ]
        if sentinel_warning:
            warnings.append(sentinel_warning)
        return DetectionResult(
            value=sentinel,
            confidence=0.4,
            method="single-column",
            warnings=warnings,
        )

    scored.sort(key=lambda row: row[1], reverse=True)
    best_delim, best_score, best_reason, best_quote = scored[0]

    # Single-column detection. Classic failure case: a one-column
    # notes export where rows naturally contain commas in prose ("I
    # saw the report, it was fine"). The comma candidate wins by
    # default because there's nothing else to choose, but parsing
    # with it produces ragged rows, cascades into bad header
    # detection, and materially corrupts the output.
    #
    # Heuristic: declare single-column when majority of rows have
    # NO delimiter AND the minority that do have varied field
    # counts. A real CSV with a long preamble also has "majority
    # of rows have no delimiter", but the delimiter-bearing rows
    # are field-count-consistent (every data row has the same
    # structure) — so we keep that case treated as structured CSV.
    # The combination of "majority no-delim + varied counts among
    # delim-bearing rows" is what specifically identifies free-text
    # single-column content where the delimiter is incidental.
    #
    # We still can't catch "free text where every row has 1-2
    # commas" without content understanding — if every row has at
    # least one delimiter, both interpretations parse. This
    # heuristic catches the majority practical case the user
    # flagged.
    # Pass `best_quote` so the re-parse uses the same quote
    # interpretation that won the scoring phase. Without this,
    # `_looks_single_column` re-parsed with the default `"` quote
    # regardless of whether scoring picked `'`, producing skewed
    # field counts on single-quote-quoted files and pushing some
    # of them into a spurious single-column verdict.
    if _looks_single_column(sample, best_delim, max_rows, best_quote):
        sentinel, sentinel_warning = _pick_safe_sentinel(sample)
        warnings = [
            "file appears to be a single column of text; the "
            "candidate delimiter occurs sporadically inside cell "
            "content rather than between cells (too few or too "
            "inconsistent delim-bearing rows to be a structured "
            "data block)"
        ]
        if sentinel_warning:
            warnings.append(sentinel_warning)
        return DetectionResult(
            value=sentinel,
            confidence=1.0,
            method="single-column",
            alternatives=[
                DetectionAlternative(
                    value=d,
                    confidence=s,
                    reason=f"rejected as single-column: {r}",
                )
                for d, s, r, _ in scored
            ],
            warnings=warnings,
        )

    alternatives = [
        DetectionAlternative(value=d, confidence=s, reason=r)
        for d, s, r, _ in scored[1:]
    ]

    low_confidence_warnings: list[str] = []
    if best_score < 0.6:
        low_confidence_warnings.append(best_reason)

    return DetectionResult(
        value=best_delim,
        confidence=best_score,
        method="field-count-consistency",
        alternatives=alternatives,
        warnings=low_confidence_warnings,
    )


def _pick_safe_sentinel(sample: str) -> tuple[str, str | None]:
    """Pick a single-character delimiter that doesn't appear in the
    sample, for the single-column verdict.

    The default `\\x1f` (Information Separator One) is reserved by
    ANSI X3.4 and almost never appears in real text — but messy
    exports (binary-shaped data, certain protocol dumps) can
    contain control characters. A collision would split the
    "single-column" rows on the sentinel itself, producing the
    exact corruption the sentinel was supposed to avoid.

    Returns `(sentinel_char, optional_warning)`. The warning is
    non-None when every default candidate collides with sample
    content — in that case we still return the primary sentinel
    (to keep the API predictable) but flag the risk on the result.
    """
    for candidate in _SENTINEL_CANDIDATES:
        if candidate not in sample:
            return candidate, None
    return (
        _SINGLE_COLUMN_SENTINEL,
        f"all single-column sentinel candidates "
        f"({', '.join(repr(c) for c in _SENTINEL_CANDIDATES)}) "
        "appear in the sample; downstream parsing may split rows "
        "unexpectedly. Override profile.delimiter.value if so.",
    )


def _looks_single_column(
    sample: str, delimiter: str, max_rows: int, quotechar: str = '"'
) -> bool:
    """True when the sample is likely one column of free text rather
    than a structured DSV with `delimiter`.

    Decision tree (after the upstream "majority of rows have the
    delimiter" check has filtered out clear CSVs):

    1. No row has the delimiter at all → single-column.
    2. ≥ `_MIN_CONSISTENT_CSV_ROWS` delim-bearing rows AND they all
       agree on field count → real CSV block (possibly preceded by
       a long preamble of no-delim metadata rows). NOT single-column.
       This is the path the previous "<5% sparse" gate
       over-rejected: a 200-line preamble + 4 consistent CSV rows
       hit `4/204 ≈ 0.02 < 0.05` and got misclassified as
       single-column, collapsing the real data into one cell per
       row.
    3. Anything else with majority no-delim → single-column. Covers:
       - 0 or 1 delim-bearing rows (incidental punctuation).
       - 2 delim-bearing rows that happen to agree (still likely
         incidental — coincidence in tiny samples is common).
       - Varied field counts among delim-bearing rows (free text
         with sporadic punctuation).

    `quotechar` must match the quote interpretation that won the
    scoring phase. Re-parsing with a different quote char here
    produces different field-count distributions than scoring saw,
    which skews the "consistent across delim-bearing rows" check
    on single-quote-quoted files and can push them into a spurious
    single-column verdict.
    """
    counts = _field_counts(sample, delimiter, max_rows, quotechar)
    if not counts:
        return False
    no_delim = sum(1 for c in counts if c == 1)
    has_delim = [c for c in counts if c >= 2]
    if not has_delim:
        # Handled upstream by max(counts) < 2, but defensive here.
        return True
    if no_delim / len(counts) <= 0.5:
        # Majority of rows have the delimiter — it IS delimiting
        # something. Real CSV, possibly messy.
        return False
    # Majority no-delim. The delim-bearing minority is either a
    # real CSV block (preamble + structured data) or incidental
    # punctuation in prose. The discriminator is absolute count of
    # consistent rows, not ratio: a CSV file's data block doesn't
    # care how long its preamble is, but free text with 1-2
    # accidental commas absolutely shouldn't be force-promoted to
    # CSV via "well, those 2 rows agree on field count."
    if (
        len(has_delim) >= _MIN_CONSISTENT_CSV_ROWS
        and len(set(has_delim)) == 1
    ):
        # Enough rows of consistent shape — preamble + real CSV.
        return False
    return True


def _field_counts(
    sample: str,
    delimiter: str,
    max_rows: int,
    quotechar: str = '"',
) -> list[int]:
    """Parse `sample` with `delimiter` and return per-row field counts.

    `csv.reader` handles quoted newlines, so the row count here reflects
    *logical* rows, not physical lines.
    """
    try:
        reader = csv.reader(
            io.StringIO(sample),
            delimiter=delimiter,
            quotechar=quotechar,
        )
        rows: list[list[str]] = []
        for i, row in enumerate(reader):
            if i >= max_rows:
                break
            rows.append(row)
    except csv.Error:
        return []

    # Skip fully empty rows: a trailing newline creates a `[]` row that
    # would pull the mean/stdev around without reflecting real structure.
    return [len(row) for row in rows if row]


def _score_counts(counts: list[int]) -> tuple[float, str]:
    """Score field-count consistency: tight distribution → high score.

    Main signal is coefficient of variation (stdev / mean). Small
    secondary bonus for higher field counts, so that when two
    delimiters are equally consistent the one producing more columns
    wins — a character that only happens to appear once per line is
    probably accidental.
    """
    if not counts:
        # Callers on the public path filter empty-counts upstream, but
        # direct callers (and future refactors) deserve a sensible
        # return instead of a StatisticsError from statistics.mean([]).
        return 0.0, "rows=0"
    mean = statistics.mean(counts)
    stdev = statistics.stdev(counts) if len(counts) > 1 else 0.0

    cv = stdev / mean if mean > 0 else 1.0
    consistency = max(0.0, 1.0 - cv)

    field_factor = min(mean / 3.0, 1.0)

    score = consistency * 0.85 + field_factor * 0.15
    score = max(0.0, min(1.0, score))

    reason = (
        f"rows={len(counts)} mean={mean:.1f} "
        f"stdev={stdev:.2f} cv={cv:.2f}"
    )
    return score, reason
