"""Line-ending detection.

Three candidates: `\\r\\n` (Windows / many DB exports), `\\n` (Unix,
most modern tooling), `\\r` (classic Mac, rare but still seen in
legacy data).

Counting order matters: every `\\r\\n` contains a `\\n`, so we count
the two-byte sequence first and subtract its occurrences from the
lone `\\n` and `\\r` tallies to avoid double-counting.

Newlines INSIDE quoted fields (a multi-line cell `"line one\\nline two"`)
are not row terminators — they're part of cell content. Counting them
as line endings inflates the "mixed line endings" warning on files
that legitimately have one terminator outside quoted regions and a
different `\\n` inside a quoted multi-line cell. The `quotechar` and
`delimiter` parameters let the caller pass the detected dialect so
the counter walks the sample with proper quote-state awareness.

Quote state only flips at FIELD-START positions (start of line or
right after a delimiter). A bare quote char in the middle of a cell
is content, not a state transition. Without this, an apostrophe in
prose (`it's a great day`) under `quotechar="'"` would toggle quote
state mid-cell, suppressing every newline until the next apostrophe
appeared — pushing the detector to "no line endings in sample"
fallback. Field-start gating is the same pattern `detect_quote_char`
uses for its evidence count.
"""

from __future__ import annotations

from dsvmonkey.profile import (
    MIXED_LINE_ENDINGS_WARNING,
    DetectionAlternative,
    DetectionResult,
)


def detect_line_ending(
    sample: str,
    quotechar: str | None = '"',
    delimiter: str | None = ",",
) -> DetectionResult:
    """Infer the dominant line-ending sequence of `sample`."""
    crlf, bare_lf, bare_cr = _count_line_endings_outside_quotes(
        sample, quotechar, delimiter
    )

    counts = [
        ("\r\n", crlf),
        ("\n", bare_lf),
        ("\r", bare_cr),
    ]
    total = sum(count for _, count in counts)

    if total == 0:
        # Single-line input, no line endings at all. Default to `\n`
        # (what most modern code emits) with zero confidence.
        return DetectionResult(
            value="\n",
            confidence=0.0,
            method="fallback",
            warnings=["no line endings in sample"],
        )

    counts.sort(key=lambda pair: pair[1], reverse=True)
    best_ending, best_count = counts[0]
    confidence = best_count / total

    alternatives = [
        DetectionAlternative(
            value=ending,
            confidence=count / total,
            reason=f"{count}/{total} occurrences",
        )
        for ending, count in counts[1:]
        if count > 0
    ]

    warnings: list[str] = []
    # Mixed line endings are a real data-quality signal — worth
    # surfacing even when one clearly dominates.
    non_zero = sum(1 for _, count in counts if count > 0)
    if non_zero > 1:
        warnings.append(MIXED_LINE_ENDINGS_WARNING)

    return DetectionResult(
        value=best_ending,
        confidence=confidence,
        method="occurrence-count",
        alternatives=alternatives,
        warnings=warnings,
    )


def _count_line_endings_outside_quotes(
    sample: str, quotechar: str | None, delimiter: str | None
) -> tuple[int, int, int]:
    """Return `(crlf, bare_lf, bare_cr)` outside quoted regions.

    When either `quotechar` or `delimiter` is None, falls back to a
    raw count over the whole sample — without both, we can't reliably
    identify field-start positions, and a less-aware state machine
    would over-fire (e.g. an apostrophe in prose mid-cell flipping
    quote state under `quotechar="'"`). Raw count is the lesser
    failure mode in that case.

    With both parameters set, walks the sample with a state machine
    that:

    - Opens a quoted region only when `quotechar` appears at a
      FIELD-START position (start of line or right after a
      `delimiter`). Bare quote chars in the middle of a cell are
      treated as content, not state transitions — exactly how
      csv.reader treats them, and what stops an apostrophe in
      `it's` from toggling quote state across the rest of the file.
    - Inside a quoted region, `""` (doubled quote) is the literal
      escape and does NOT close the region; a single quote followed
      by anything else closes.
    - Newlines outside quoted regions are counted by type
      (`\\r\\n` / `\\n` / `\\r`); newlines inside quoted regions are
      content and not counted.
    """
    if quotechar is None or delimiter is None:
        crlf = sample.count("\r\n")
        return crlf, sample.count("\n") - crlf, sample.count("\r") - crlf

    crlf = bare_lf = bare_cr = 0
    in_quote = False
    at_field_start = True
    n = len(sample)
    i = 0
    while i < n:
        ch = sample[i]
        if in_quote:
            if ch == quotechar:
                # `""` escape: doubled quote inside region is a
                # literal quote, not the closing marker.
                if i + 1 < n and sample[i + 1] == quotechar:
                    i += 2
                    continue
                in_quote = False
                at_field_start = False
            i += 1
            continue
        if at_field_start and ch == quotechar:
            in_quote = True
            at_field_start = False
            i += 1
            continue
        if ch == delimiter:
            at_field_start = True
            i += 1
            continue
        if ch == "\r":
            if i + 1 < n and sample[i + 1] == "\n":
                crlf += 1
                i += 2
            else:
                bare_cr += 1
                i += 1
            at_field_start = True
            continue
        if ch == "\n":
            bare_lf += 1
            at_field_start = True
            i += 1
            continue
        # Any other character is regular content; we're past the
        # field's first position.
        at_field_start = False
        i += 1
    return crlf, bare_lf, bare_cr
