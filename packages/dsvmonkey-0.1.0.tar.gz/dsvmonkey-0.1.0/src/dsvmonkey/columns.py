"""Per-column profiling.

Where `DSVProfile` describes the *structure* of a file (encoding,
delimiter, headers, etc.), this module describes the *content* of
each column — currently: a sample of values, null counts, and date
format detection delegated to `datemonkey`.

Kept separate from the structural profile because column profiling
reads further into the file and takes longer. Callers who just want
"does this look like a CSV?" can skip it.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import datemonkey  # type: ignore[import-untyped]

from dsvmonkey.orchestrate import profile_file
from dsvmonkey.profile import DSVProfile
from dsvmonkey.reader import read

_DEFAULT_SAMPLE_ROWS = 500

# datemonkey matches any small positive integers as Excel serial dates
# (value 1 = 1900-01-01, value 5 = 1900-01-05). That's technically
# correct but produces a flood of false positives on integer ID
# columns. Only accept EXCEL_SERIAL when the minimum value would
# correspond to a plausible real-world date (~1927 onwards).
_EXCEL_SERIAL_MIN_VALUE = 10000

# Minimum fraction of sampled values that must match the detected
# date format before we surface it. datemonkey cheerfully returns a
# "low-confidence, 10% match" result for any column that contains a
# couple of date-shaped strings amongst otherwise-free-text values;
# populating date_format on that produces a misleading "this column
# is a date" claim in the inspect report. The docstring's
# "reasonably confident match" gate is pinned here.
_MIN_DATE_MATCH_RATIO = 0.5


@dataclass
class ColumnProfile:
    """Structural and content summary of one column.

    Date fields are only populated when `datemonkey.detect_format`
    returns a reasonably confident match on the sampled values. For
    non-date columns they stay `None` — callers should treat that as
    "no date format detected", not "no data".
    """

    name: str
    index: int
    sample_size: int
    empty_count: int

    date_format: str | None = None
    date_format_label: str | None = None
    date_confidence: str | None = None
    date_match_ratio: float | None = None

    warnings: list[str] = field(default_factory=list)


def profile_columns(
    path: Path | str,
    *,
    profile: DSVProfile | None = None,
    sample_rows: int = _DEFAULT_SAMPLE_ROWS,
    locale_preference: str | None = None,
    excel_serial_min_value: float = _EXCEL_SERIAL_MIN_VALUE,
    clean_cells: bool = False,
    skip_empty_rows: bool = True,
    deep_scan: bool = True,
) -> list[ColumnProfile]:
    """Collect per-column samples and run date-format detection.

    Parameters
    ----------
    path
        DSV file to profile.
    profile
        Precomputed `DSVProfile`. When None, `profile_file` runs first.
    sample_rows
        Maximum number of data rows to consume. Date detection
        stabilises well before 500 samples, so this is a reasonable
        cap for large files.
    locale_preference
        Passed to `datemonkey.detect_format` as a tie-breaker when
        US vs EU date order is ambiguous (`"us"` or `"eu"`).
    excel_serial_min_value
        Minimum column-min value required to accept an EXCEL_SERIAL
        match. Defaults to 10000 (≈ year 1927). Set to 0 to trust
        datemonkey's Excel serial detection unconditionally — useful
        when working with genuine pre-1927 date serials; set higher
        to reject more integer-ID false positives.
    clean_cells
        Whether to cleanmonkey cells before profiling. Default False
        — a profiling tool should show data quality issues, not hide
        them by normalising smart quotes, invisible characters or
        stray whitespace before inspection. Pass True when you
        specifically want cleaned-view profiling (e.g. to make date
        detection tolerant of NBSPs or similar).
    skip_empty_rows
        Forwarded to `read()`. Default True (matches the ETL-friendly
        default). Set to False for audit-style datasets where blank
        rows carry meaning — otherwise they're dropped before
        profiling and the resulting `sample_size` / `empty_count`
        numbers under-report the true row shape of the file.
    deep_scan
        Forwarded to `profile_file` when `profile` is None. Default
        True. Pass False for large or remote files where the
        full-file mixed-encoding pass is prohibitively expensive;
        tradeoff is that late-file corruption beyond the 256 KiB
        sample window won't be surfaced.
    """
    if sample_rows < 1:
        # Silently returning empty column profiles (the old behaviour
        # when sample_rows <= 0) produced a misleading report where
        # every column looked like it had zero data. A caller passing
        # a non-positive bound almost certainly has a bug; surface it.
        raise ValueError(
            f"sample_rows must be a positive integer, got {sample_rows}"
        )

    path = Path(path)
    if profile is None:
        profile = profile_file(path, deep_scan=deep_scan)

    # Single-pass sampling: open the reader once, peek the first row
    # if we need it to determine width, then include that row in the
    # sampling loop. Previously, when the profile lacked headers and
    # field_count, _resolve_column_names opened a separate read()
    # just to peek at the first row for width — doubling I/O on
    # large or remote files and inviting width/sampling-shape drift.
    reader_iter = iter(
        read(
            path,
            profile=profile,
            as_dict=False,
            clean=clean_cells,
            skip_empty_rows=skip_empty_rows,
        )
    )

    # Fast path: names come from the profile, no peek needed.
    if profile.headers:
        names: list[str] = list(profile.headers)
        first_row: list[str] | None = None
    elif profile.field_count:
        names = [f"col_{i}" for i in range(profile.field_count)]
        first_row = None
    else:
        # Need to peek at the first row to know the width.
        try:
            first_row = next(reader_iter)
        except StopIteration:
            return []
        names = [f"col_{i}" for i in range(len(first_row))]

    samples: list[list[str]] = [[] for _ in names]
    empty_counts = [0] * len(names)
    # Track ragged-width growth: rows wider than the inferred column
    # set used to be silently truncated by `_absorb`, leaving the
    # caller no signal that some cells were dropped from profiling
    # entirely. Surface the worst case via a warning on the last
    # column so the inspect report reflects the structural drift.
    max_seen_width = len(names)
    overflow_row_count = 0

    def _absorb(row: list[str]) -> None:
        nonlocal max_seen_width, overflow_row_count
        if len(row) > len(names):
            overflow_row_count += 1
            if len(row) > max_seen_width:
                max_seen_width = len(row)
        for i in range(len(names)):
            cell = row[i] if i < len(row) else ""
            if cell.strip() == "":
                empty_counts[i] += 1
            else:
                samples[i].append(cell)

    count = 0
    if first_row is not None:
        _absorb(first_row)
        count = 1

    for row in reader_iter:
        if count >= sample_rows:
            break
        _absorb(row)
        count += 1

    column_profiles = [
        _profile_one_column(
            name=name,
            index=i,
            values=samples[i],
            empty_count=empty_counts[i],
            locale_preference=locale_preference,
            excel_serial_min_value=excel_serial_min_value,
        )
        for i, name in enumerate(names)
    ]

    if overflow_row_count and column_profiles:
        # Attach to the last column's warnings so the inspect report
        # surfaces the ragged growth without inventing a synthetic
        # column. Phrasing pins the two numbers a maintainer needs:
        # how many rows overflowed and the maximum observed width.
        column_profiles[-1].warnings.append(
            f"{overflow_row_count} sampled row(s) had more cells "
            f"than the {len(names)} profiled column(s) "
            f"(max observed width: {max_seen_width}); overflow "
            "cells were not included in column samples. Re-profile "
            "with explicit headers= or pass repair() with a wider "
            "target_field_count to capture them."
        )

    return column_profiles


def _profile_one_column(
    name: str,
    index: int,
    values: list[str],
    empty_count: int,
    locale_preference: str | None,
    excel_serial_min_value: float,
) -> ColumnProfile:
    column = ColumnProfile(
        name=name,
        index=index,
        sample_size=len(values),
        empty_count=empty_count,
    )

    if not values:
        # Nothing to analyse. Not worth flagging as a warning — a
        # column that's empty in the sample may be populated later.
        return column

    _fill_date_fields(column, values, locale_preference, excel_serial_min_value)
    return column


def _fill_date_fields(
    column: ColumnProfile,
    values: list[str],
    locale_preference: str | None,
    excel_serial_min_value: float,
) -> None:
    """Populate `column` with date-format fields if datemonkey gives a
    reasonably confident match.

    Two gates: `match_count > 0` filters the "no dates at all" case,
    and `match_ratio >= _MIN_DATE_MATCH_RATIO` filters the "a couple
    of dates amongst free text" case — without the second gate, a
    column with 1 date-shaped string in 10 values would be labelled
    a date column in the inspect report.
    """
    try:
        result = datemonkey.detect_format(
            values,
            locale_preference=locale_preference,
        )
    except (ValueError, TypeError, ArithmeticError, UnicodeError) as err:
        # Data-shaped failures: a non-date column whose values confused
        # datemonkey's parsing shouldn't take down the whole report.
        # Programming errors (AttributeError, NameError, ImportError,
        # LookupError, ...) stay uncaught so they surface instead of
        # silently degrading every column to "no date format detected".
        column.warnings.append(f"date detection failed: {err}")
        return

    if result.match_count == 0:
        return

    if result.match_ratio < _MIN_DATE_MATCH_RATIO:
        # Below the gate but non-zero — surface as a warning so an
        # operator scanning the inspect report sees "this column
        # has SOME date-shaped values" without the column getting
        # mis-labelled as a date type. Helps with manual review of
        # mixed-content / partially-date columns the bulk gate
        # would otherwise drop on the floor silently.
        column.warnings.append(
            f"weak date signal: {result.match_count} of "
            f"{result.sample_size} values match "
            f"{result.format.pattern} ({result.match_ratio:.0%}) — "
            "below the classification gate; consider manual review"
        )
        return

    if (
        result.format.pattern == "EXCEL_SERIAL"
        and not _plausible_excel_serials(values, excel_serial_min_value)
    ):
        return

    column.date_format = result.format.pattern
    column.date_format_label = result.format.label
    column.date_confidence = _confidence_name(result.confidence)
    column.date_match_ratio = result.match_ratio

    if result.warnings:
        column.warnings.extend(str(w) for w in result.warnings)


def _plausible_excel_serials(values: list[str], min_value: float) -> bool:
    """True if `values` fall in the range of real-world date serials.

    Anything below `min_value` is almost certainly an integer ID
    column that datemonkey has over-interpreted. `min_value=0`
    disables the filter.

    Skips non-numeric entries instead of failing the whole check on
    the first `ValueError`. Real-world date columns commonly contain
    a sprinkling of non-numeric sentinels (`"N/A"`, `""`, `"null"`)
    alongside serial-date values; rejecting the column outright on
    the first non-parseable cell produced false-negatives that
    suppressed legitimate date classification even when datemonkey
    matched the bulk of the column as serials.
    """
    if min_value <= 0:
        return True
    numbers: list[float] = []
    for v in values:
        s = v.strip()
        if not s:
            continue
        try:
            numbers.append(float(s))
        except ValueError:
            # Non-numeric cell: skip. The pattern was already matched
            # by datemonkey's own detection, so we only need the gate
            # to decide whether the numeric values look like dates,
            # not re-adjudicate every cell.
            continue
    if not numbers:
        return False
    return min(numbers) >= min_value


def _confidence_name(confidence) -> str:
    """Normalize datemonkey's Confidence enum to a lowercase string."""
    value = getattr(confidence, "value", None)
    if isinstance(value, str):
        return value
    return str(confidence).lower().split(".")[-1]
