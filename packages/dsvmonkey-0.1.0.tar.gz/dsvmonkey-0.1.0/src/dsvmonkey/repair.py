"""File-level repair.

Where `read()` silently pads and truncates for ergonomics, `repair()`
does the same transformations but writes a cleaned version of the file
to disk and returns a structured `RepairReport` describing exactly
what was changed. This is the engine behind the `dsvmonkey normalize`
CLI and the foundation for `dsvmonkey convert`.

Default output: UTF-8, Unix line endings, no BOM, the input's detected
delimiter, `csv.QUOTE_MINIMAL` quoting, cells cleaned with cleanmonkey.
All four output knobs (encoding, line ending, delimiter, quoting) can
be overridden.
"""

from __future__ import annotations

import codecs
import csv
import warnings
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterator

from dsvmonkey._internal import (
    _atomic_text_writer,
    _neutralize_formula,
    _reject_same_path,
)
from dsvmonkey.orchestrate import profile_file
from dsvmonkey.profile import MIXED_LINE_ENDINGS_WARNING, DSVProfile
from dsvmonkey.reader import (
    CleanSetting,
    _effective_text_encoding,
    _make_row_iterator,
    _resolve_clean,
    _validate_profile,
)


@dataclass
class RepairReport:
    """Structured summary of what `repair()` changed.

    Consumable by the CLI and by callers that want to log data-quality
    stats. `profile` is the detected input profile; every transformation
    is reported relative to that.

    Both `rows_read` and `rows_written` count **data rows only** — the
    header is surfaced separately via `header_written`. This makes the
    two counters directly comparable for monitoring / ETL logging:
    `rows_read == rows_written + empty_rows_skipped` in the normal
    case (no dry run). Previously `rows_written` included the header
    while `rows_read` didn't, which produced a spurious off-by-one in
    symmetric-counter dashboards.
    """

    input_path: Path
    output_path: Path | None
    profile: DSVProfile

    rows_read: int = 0
    rows_written: int = 0
    header_written: bool = False

    bom_stripped: bool = False
    line_ending_changed: bool = False
    delimiter_changed: bool = False
    encoding_changed: bool = False

    short_rows_padded: int = 0
    long_rows_truncated: int = 0
    empty_rows_skipped: int = 0

    issues: list[str] = field(default_factory=list)


def repair(
    input_path: Path | str,
    output_path: Path | str | None,
    *,
    profile: DSVProfile | None = None,
    target_field_count: int | None = None,
    target_encoding: str = "utf-8",
    target_line_ending: str = "\n",
    target_delimiter: str | None = None,
    clean_cells: CleanSetting = True,
    write_header: bool = True,
    deep_scan: bool = True,
    skip_empty_rows: bool = True,
    sanitize_formulas: bool = False,
) -> RepairReport:
    """Read `input_path`, write a cleaned version to `output_path`.

    Parameters
    ----------
    input_path
        Source DSV file.
    output_path
        Destination. Pass `None` for a dry run — the file is read and
        the report is produced, but nothing is written.
    profile
        Pre-computed profile. When None, `profile_file` is run against
        the input.
    target_field_count
        Desired columns per row. Short rows are padded with empty
        strings; long rows are truncated. Defaults to the detected
        field count (from headers or the first data row).
    target_encoding, target_line_ending, target_delimiter
        Output dialect. Default: UTF-8, \\n, same delimiter as input.
    clean_cells
        Passed through to the cleaning layer shared with `read()`.
        Same semantics: True = `"csv"` profile, False = no cleaning,
        str or Profile = explicit.
    write_header
        When True (default), the header row (cleaned, with target field
        count) is written first. Skip for append-mode workflows.
    skip_empty_rows
        When True (default), whitespace-only rows are dropped and
        counted in `report.empty_rows_skipped`. Set to False to
        preserve them in the output — needed for fixed-format
        exports or audit trails where blank rows are semantic.
    sanitize_formulas
        When True, prepend `'` to cells that begin with `=`, `+`,
        `-`, or `@` to neutralise spreadsheet-formula injection when
        the output will be opened in Excel / Sheets. Off by default
        because the prefix mutates visible content and is unwanted
        when the consumer isn't a spreadsheet. Turn on at the
        pipeline boundary where output crosses into untrusted
        spreadsheet territory — a classic defense-in-depth layer.
    """
    input_path = Path(input_path)
    out_path = Path(output_path) if output_path is not None else None
    _reject_same_path(input_path, out_path, "repair")
    _validate_target_field_count(target_field_count)
    _validate_target_delimiter(target_delimiter)
    _validate_target_encoding(target_encoding)

    if profile is None:
        profile = profile_file(input_path, deep_scan=deep_scan)
    else:
        _validate_profile(profile, "repair", input_path)

    # `_validate_profile` (or `profile_file`) guarantees these are
    # non-None; the asserts re-state the invariant for mypy.
    assert profile.delimiter is not None
    assert profile.encoding is not None

    effective_delimiter = target_delimiter or profile.delimiter.value
    effective_field_count = _resolve_field_count(profile, target_field_count)
    clean_fn = _resolve_clean(clean_cells)

    report = RepairReport(
        input_path=input_path,
        output_path=out_path,
        profile=profile,
        bom_stripped=profile.has_bom,
        line_ending_changed=_line_ending_was_changed(
            profile, target_line_ending
        ),
        delimiter_changed=_differs(profile.delimiter.value, effective_delimiter),
        encoding_changed=_differs(
            _normalize_encoding_name(profile.encoding.value),
            _normalize_encoding_name(target_encoding),
        ),
    )

    header_row, data_rows = _iter_repaired_rows(
        input_path,
        profile,
        effective_field_count,
        clean_fn,
        report,
        skip_empty_rows=skip_empty_rows,
        sanitize_formulas=sanitize_formulas,
    )

    if out_path is None:
        # Dry run. Exhaust the iterator so rows_read reflects what
        # was streamed, AND mirror the write counters so the report
        # reflects what WOULD be written — `output_path=None` already
        # unambiguously signals "no file written," so rows_written /
        # header_written can carry the "would-write" semantic
        # without confusion. Without this, a preview/monitoring
        # caller comparing dry-run `rows_written` against expected
        # throughput sees a misleading 0.
        if write_header and header_row is not None:
            report.header_written = True
        for _ in data_rows:
            report.rows_written += 1
        return report

    out_path.parent.mkdir(parents=True, exist_ok=True)
    # Atomic write: stream into a temp file in the same directory
    # (so `os.replace` is a single filesystem rename, atomic on
    # POSIX and Windows), then rename on successful close. If the
    # process is killed or disk fills mid-write, the final path
    # either has the previous contents (if any) or doesn't exist —
    # never half-written output. The temp is removed on any
    # exception to keep the directory clean.
    with _atomic_text_writer(
        out_path, encoding=target_encoding
    ) as out_fh:
        writer = csv.writer(
            out_fh,
            delimiter=effective_delimiter,
            quotechar='"',
            quoting=csv.QUOTE_MINIMAL,
            lineterminator=target_line_ending,
        )
        if write_header and header_row is not None:
            writer.writerow(header_row)
            report.header_written = True
        for row in data_rows:
            writer.writerow(row)
            report.rows_written += 1

    return report


def _validate_target_field_count(value: int | None) -> None:
    """Reject non-positive `target_field_count` at the library
    boundary.

    Previously this was a CLI-only guard. Direct API callers could
    pass `target_field_count=0` and hit `_fit_row(row, 0)`, which
    slices to `row[:0]` (empty list) — silent structural destruction
    of every data row. `target_field_count=-1` silently drops the
    last cell of every row via `row[:-1]`. A caller who "deliberately"
    wants zero columns is expressing confusion, not intent.
    """
    if value is None:
        return
    if value < 1:
        raise ValueError(
            f"target_field_count must be a positive integer, got {value}"
        )


_STRUCTURALLY_RESERVED_DELIMITERS: frozenset[str] = frozenset(
    {"\n", "\r", '"', "'"}
)


def _validate_target_delimiter(value: str | None) -> None:
    """Reject multi-character / empty / structurally-reserved
    `target_delimiter` at the library boundary.

    Python's csv.writer rejects multi-character delimiters deep in
    its C implementation with a confusing TypeError. The CLI already
    validates; mirror that guard at the library entry so direct API
    callers get the same one-line ValueError instead of a traceback.

    Also reject characters that are structurally reserved in DSV
    parsing: `\\n` and `\\r` are row terminators, `"` and `'` are
    quote characters. Accepting them as field delimiters produces
    degenerate output that csv.reader can't parse back — the kind
    of mistake that's easy to make in automation (e.g. piping a
    line-endings value into the delimiter arg) and impossible to
    recover from later. Fail fast.
    """
    if value is None:
        return
    if not isinstance(value, str):
        # Without this, `len(42)` raises TypeError — inconsistent
        # with the ValueError that every other target-validator
        # emits.
        raise ValueError(
            f"target_delimiter must be a string, got "
            f"{type(value).__name__} ({value!r})"
        )
    if len(value) != 1:
        raise ValueError(
            f"target_delimiter must be a single character, got "
            f"{value!r} (length {len(value)})"
        )
    if value in _STRUCTURALLY_RESERVED_DELIMITERS:
        raise ValueError(
            f"target_delimiter {value!r} is reserved by DSV parsing "
            "(newlines and quote characters can't be delimiters); "
            "pick a different character"
        )


def _validate_target_encoding(value: str) -> None:
    """Reject codec names Python doesn't recognise at the library
    boundary.

    Without this, a typo like `target_encoding="ut-8"` surfaces as
    a `LookupError` inside `Path.open` — a different exception type
    from the rest of repair's validation surface. The CLI already
    does this via `codecs.lookup`; mirror it here.
    """
    if not isinstance(value, str):
        raise ValueError(
            f"target_encoding must be a string, got "
            f"{type(value).__name__} ({value!r})"
        )
    try:
        codecs.lookup(value)
    except LookupError:
        raise ValueError(f"unknown target_encoding {value!r}") from None


def _resolve_field_count(
    profile: DSVProfile,
    override: int | None,
) -> int | None:
    """Decide the target width, or return None to defer to the first
    streamed data row.

    Returning 1 as a fallback used to be catastrophic: multi-column
    rows were silently truncated to one cell. `None` now means
    "establish width from the first real row you see," which is both
    safer and matches what a human running `dsvmonkey normalize`
    would expect if they didn't pass `--field-count`.
    """
    if override is not None:
        return override
    if profile.field_count:
        return profile.field_count
    return None


def _iter_repaired_rows(
    input_path: Path,
    profile: DSVProfile,
    field_count: int | None,
    clean_fn,
    report: RepairReport,
    *,
    skip_empty_rows: bool = True,
    sanitize_formulas: bool = False,
) -> tuple[list[str] | None, Iterator[list[str]]]:
    """Return the (cleaned) header row and a generator of data rows.

    `field_count` may be None, meaning "use the first data row's width".
    This happens when the profile couldn't determine columns (e.g.
    header detected beyond the sample window) and the caller didn't
    pass an explicit target.

    The header is materialized eagerly so the caller can choose whether
    to write it; data rows stream.
    """
    # Shared BOM-aware encoding resolver so repair() and read() can't
    # disagree: endianness-specific UTF-16/32 codecs don't consume
    # their BOM and would otherwise leak `﻿` into the first cell
    # of the output.
    encoding = _effective_text_encoding(profile)
    fh = input_path.open("r", encoding=encoding, errors="replace", newline="")

    # Use the shared row iterator so single-column files bypass
    # csv.reader entirely (see reader._make_row_iterator). That
    # eliminates the risk of the sentinel value colliding with
    # content beyond the detection sample window.
    reader = _make_row_iterator(fh, profile)

    skip = profile.header_row.value + 1 if profile.header_row and profile.header_row.value is not None else 0

    header_row: list[str] | None = None
    for i in range(skip):
        try:
            row = next(reader)
        except StopIteration:
            # Skip consumed every row in the file — same diagnostic
            # gap that `read()` already surfaces. Previously repair()
            # returned silently, leaving a monitoring check no way
            # to tell "profile was wrong" from "file was empty".
            # Warn so automated pipelines can grep the log.
            warnings.warn(
                f"profile.header_row.value={skip - 1} but file has "
                f"only {i} row(s) before EOF; repair() wrote no data",
                UserWarning,
                stacklevel=3,
            )
            fh.close()
            return None, iter(())
        if profile.header_row and i == profile.header_row.value:
            cleaned_header = [_apply_clean(cell, clean_fn) for cell in row]
            if sanitize_formulas:
                cleaned_header = [
                    _neutralize_formula(cell) for cell in cleaned_header
                ]
            if field_count is None:
                # Header width establishes the target for the rest of
                # the file when no other source gave us a number.
                field_count = len(cleaned_header)
            header_row = _fit_row(
                cleaned_header,
                field_count,
                report,
                counts_as_data=False,
            )

    width: int | None = field_count

    def generator() -> Iterator[list[str]]:
        nonlocal width
        try:
            for row in reader:
                report.rows_read += 1
                # Clean BEFORE the empty-row check. `str.strip()`
                # doesn't remove zero-width characters (U+200B ZWSP,
                # U+FEFF ZWNBSP, etc.), so rows containing only
                # those invisibles used to pass the is-empty check
                # and then appear in the output as ghost rows of
                # empty cells after cleanmonkey stripped them.
                # Cleaning first means the empty-row contract and
                # the cleaning contract agree on "what counts as
                # empty." Under `clean_cells=False` (byte-exact
                # mode), the raw check runs instead.
                cleaned = [_apply_clean(cell, clean_fn) for cell in row]
                if skip_empty_rows and not any(cell.strip() for cell in cleaned):
                    report.empty_rows_skipped += 1
                    continue
                if sanitize_formulas:
                    cleaned = [_neutralize_formula(cell) for cell in cleaned]
                if width is None:
                    # First data row sets the target width. Later rows
                    # pad/truncate to match it.
                    width = len(cleaned)
                yield _fit_row(cleaned, width, report, counts_as_data=True)
        finally:
            fh.close()

    return header_row, generator()


def _apply_clean(cell: str, clean_fn) -> str:
    return clean_fn(cell) if clean_fn else cell


def _fit_row(
    row: list[str],
    field_count: int,
    report: RepairReport,
    counts_as_data: bool,
) -> list[str]:
    """Pad short rows and truncate long rows to `field_count`.

    `counts_as_data=False` for the header itself — a ragged header
    shouldn't contribute to the pad/truncate counts in the report.
    """
    if len(row) < field_count:
        if counts_as_data:
            report.short_rows_padded += 1
        return row + [""] * (field_count - len(row))
    if len(row) > field_count:
        if counts_as_data:
            report.long_rows_truncated += 1
        return row[:field_count]
    return row


def _line_ending_was_changed(profile: DSVProfile, target: str) -> bool:
    """True when `repair()` actually rewrote line endings.

    The naive check — "did the dominant detected value differ from
    the target?" — misses mixed-ending files: a file containing
    mostly `\\n` but some `\\r\\n` rows gets normalised during
    write (the writer uses one terminator), but the dominant `\\n`
    matches the default `\\n` target, so the report said "line
    endings unchanged" — observability drift in a data-quality
    tool.

    Report a change whenever EITHER (a) the dominant value differs
    from the target, OR (b) the detector flagged mixed endings in
    the sample (in which case the write definitely normalised
    something even if the dominant matched).
    """
    if profile.line_ending is None:
        return False
    if _differs(profile.line_ending.value, target):
        return True
    # Detector attaches MIXED_LINE_ENDINGS_WARNING to its warnings
    # when more than one ending appears in the sample; treat that as
    # a change even if the dominant matched. Shared constant so
    # producer/consumer can't drift on the spelling.
    return any(
        w == MIXED_LINE_ENDINGS_WARNING
        for w in (profile.line_ending.warnings or [])
    )


def _differs(a, b) -> bool:
    if a is None or b is None:
        return False
    return a != b


def _normalize_encoding_name(name: str) -> str:
    """Map utf-8-sig → utf-8 etc. so a BOM-only difference doesn't
    register as an encoding change."""
    lowered = name.lower().replace("_", "-")
    if lowered == "utf-8-sig":
        return "utf-8"
    return lowered
