"""End-to-end profile orchestration.

Wires the individual detectors together in the order their dependencies
require: encoding → decode → delimiter → quote → line ending → header.
Returns a fully populated `DSVProfile`.

The detectors themselves are free-standing — they can be called
individually, e.g. when a caller has already decoded the text or
already knows the delimiter. This module is the "just run the whole
pipeline on bytes" convenience path.
"""

from __future__ import annotations

import csv
import io
from pathlib import Path

import cleanmonkey

from dsvmonkey.detectors.delimiter import detect_delimiter
from dsvmonkey.detectors.encoding import (
    detect_encoding,
    detect_mixed_encoding,
    scan_file_mixed_encoding,
)
from dsvmonkey.detectors.header import detect_header_row
from dsvmonkey.detectors.line_ending import detect_line_ending
from dsvmonkey.detectors.quote import detect_quote_char
from dsvmonkey.profile import DUPLICATE_HEADER_ISSUE_PREFIX, DSVProfile

# 256 KiB is large enough for dialect detection and a reasonable
# preamble (header rows up to ~25 + hundreds of data rows for type
# contrast) while bounding per-file memory. Callers tuning this
# parameter get exactly what they ask for — no hidden 4× multiplier.
_DEFAULT_SAMPLE_SIZE = 262_144
# Max rows parsed FROM the byte sample. Previously 100 — too low
# when a file has a long metadata preamble (some enterprise
# exports prefix data with 50–500 disclaimer / metadata rows). A
# 200-row preamble would consume the entire budget before the
# parser ever reached real data, leading to silent
# "single-column" misclassification. 1000 covers realistic
# preambles with headroom; csv.reader of 1000 rows from an
# in-memory StringIO is microseconds, so the cost is negligible.
_MAX_SAMPLE_ROWS = 1000


def profile_bytes(
    data: bytes,
    path: Path | None = None,
    sample_size: int = _DEFAULT_SAMPLE_SIZE,
    file_size: int | None = None,
) -> DSVProfile:
    """Run the full detection pipeline against `data`.

    `path` is stored on the profile for reporting; it does not need to
    exist. `sample_size` bounds how many leading bytes the encoding
    detector looks at.

    `file_size` lets callers supply the real on-disk size when `data`
    is a sample prefix rather than the whole file. Without it,
    `DSVProfile.file_size` reports the sample length — misleading for
    the CLI's `Size:` line on files larger than the sample window.
    """
    if sample_size < 1:
        # min(len(data), -1) produces a negative sample_bytes which
        # breaks every downstream observer. read(-1) also has
        # semantics ("read everything") that silently changes
        # profile_file's I/O characteristics. Fail fast.
        raise ValueError(
            f"sample_size must be a positive integer, got {sample_size}"
        )
    profile = DSVProfile(
        path=path or Path(""),
        file_size=file_size if file_size is not None else len(data),
        sample_bytes=min(len(data), sample_size),
    )

    profile.encoding = detect_encoding(data, sample_size=sample_size)
    profile.has_bom = profile.encoding.method == "bom"
    if profile.has_bom:
        profile.bom = profile.encoding.value
    profile.mixed_encoding_suspected = detect_mixed_encoding(data)

    text = _decode(data, profile.encoding.value, profile.has_bom)

    profile.delimiter = detect_delimiter(text)
    profile.quote_char = detect_quote_char(
        text, delimiter=profile.delimiter.value
    )
    # Pass the detected quote AND delimiter so the line-ending
    # state machine can identify field-start positions correctly.
    # Without delimiter, an apostrophe-quoted file would have
    # every `it's` toggle quote state mid-cell and suppress the
    # newlines after it; without quotechar, embedded newlines
    # inside quoted multi-line cells get counted as row endings.
    profile.line_ending = detect_line_ending(
        text,
        quotechar=profile.quote_char.value if profile.quote_char else None,
        delimiter=profile.delimiter.value if profile.delimiter else None,
    )

    rows = _parse_sample_rows(
        text,
        delimiter=profile.delimiter.value,
        quote_char=profile.quote_char.value,
    )
    profile.header_row = detect_header_row(rows)

    if profile.header_row.value is not None and rows:
        header_idx = profile.header_row.value
        if header_idx < len(rows):
            # Clean headers canonically at detection time so every
            # downstream consumer (read(), profile_columns(), CLI
            # report) sees the same column names. Without this, a
            # BOM / ZWSP / NBSP in a header byte leaks into
            # profile_columns() results while read(as_dict=True)
            # shows the cleaned name — producing two different
            # schemas from the same file. cleanmonkey's "csv" profile
            # targets exactly the structural artefacts (invisibles,
            # smart quotes, control chars) that don't belong in a
            # column name, regardless of the caller's `clean_cells`
            # preference for row content.
            profile.headers = [
                cleanmonkey.clean(cell, profile="csv")
                for cell in rows[header_idx]
            ]
            profile.field_count = len(rows[header_idx])
            _flag_duplicate_headers(profile)
    elif rows:
        # No header → width is determined by the first data row.
        profile.field_count = len(rows[0])

    if profile.mixed_encoding_suspected:
        profile.issues.append(
            "mixed encoding suspected — some bytes decode under a "
            "different encoding than the majority of the file"
        )
    if profile.delimiter.confidence < 0.5:
        profile.issues.append(
            f"low-confidence delimiter ({profile.delimiter.confidence:.2f})"
        )

    return profile


def profile_file(
    path: Path | str,
    sample_size: int = _DEFAULT_SAMPLE_SIZE,
    deep_scan: bool = True,
) -> DSVProfile:
    """Convenience wrapper: read a file and profile its bytes.

    Reads exactly `sample_size` bytes for structural detection (no
    hidden multiplier). Default 256 KiB. Callers tuning `sample_size`
    get exactly what they ask for.

    When `deep_scan` is True (default), the file is streamed end-to-
    end once more to catch stray non-UTF-8 bytes beyond the sample
    window. The scan requires *positive* UTF-8 evidence (at least
    one valid multi-byte sequence in the decoded regions) before
    flagging, so pure-cp1252 files with sparse non-ASCII bytes stay
    unflagged. Set `deep_scan=False` to skip the extra read entirely
    on very large or remote files where bounded I/O matters.
    """
    if sample_size < 1:
        raise ValueError(
            f"sample_size must be a positive integer, got {sample_size}"
        )
    path = Path(path)
    file_size = path.stat().st_size
    with path.open("rb") as f:
        data = f.read(sample_size)
    profile = profile_bytes(
        data, path=path, sample_size=sample_size, file_size=file_size
    )

    if deep_scan and not profile.mixed_encoding_suspected:
        if scan_file_mixed_encoding(path):
            profile.mixed_encoding_suspected = True
            profile.issues.append(
                "mixed encoding suspected — some bytes decode under a "
                "different encoding than the majority of the file"
            )

    return profile


def _flag_duplicate_headers(profile: DSVProfile) -> None:
    """Record duplicate header names as a profile issue.

    `read(as_dict=True)` emits a UserWarning about duplicate keys at
    call time, but warnings can be filtered in production pipelines
    (and are, often silently). The same information belongs on the
    profile as a non-filterable `issues` entry so:

    - `dsvmonkey inspect` prints it in the human report,
    - `repair()` / `to_jsonl()` callers reading `report.profile.issues`
      see it regardless of warning filters,
    - a CI step grepping the inspect output for "duplicate header"
      can catch the data-loss-shaped input before it ships.

    This does NOT change dict-key collision behaviour (later values
    still win) — fixing that would silently rename the caller's
    columns, which is worse. The point here is visibility: make the
    collision impossible to miss even when warnings are muted.
    """
    if not profile.headers:
        return
    seen: set[str] = set()
    duplicates: list[str] = []
    for name in profile.headers:
        if name in seen and name not in duplicates:
            duplicates.append(name)
        seen.add(name)
    if duplicates:
        profile.issues.append(
            f"{DUPLICATE_HEADER_ISSUE_PREFIX} {duplicates}: later "
            "occurrences overwrite earlier ones in dict/JSONL output; "
            "use as_dict=False or pass a disambiguated headers= list "
            "to preserve every column"
        )


def _decode(data: bytes, encoding: str, has_bom: bool) -> str:
    """Decode `data` with `encoding`, stripping a leading BOM only
    when the codec didn't already consume it.

    `utf-8-sig` and the non-endian `utf-16`/`utf-32` codecs strip
    their own BOM. The endian-specific codecs (`utf-16-le`, `utf-16-be`,
    `utf-32-le`, `utf-32-be`) do NOT — the BOM bytes decode to a
    literal U+FEFF at position 0, and detection returned those
    endian-specific names. For those we still need a defensive strip.

    Previously we stripped unconditionally whenever `has_bom=True`.
    That over-stripped in the rare but real case where `utf-8-sig`
    correctly consumed the BOM and the content's first character
    was a legitimate U+FEFF (ZWNBSP) — a valid codepoint some
    datasets embed intentionally. Gate on the codec so self-stripping
    codecs don't get a second strip.
    """
    text = data.decode(encoding, errors="replace")
    if (
        has_bom
        and encoding not in _SELF_STRIPPING_BOM_CODECS
        and text
        and text[0] == "﻿"
    ):
        text = text[1:]
    return text


# Codecs that consume the BOM themselves as part of decoding. The
# endian-specific UTF-16/32 codecs are NOT in this set — they decode
# the BOM bytes to a literal U+FEFF and rely on a downstream strip.
_SELF_STRIPPING_BOM_CODECS: frozenset[str] = frozenset(
    {"utf-8-sig", "utf-16", "utf-32"}
)


def _parse_sample_rows(
    text: str,
    delimiter: str,
    quote_char: str | None,
    max_rows: int = _MAX_SAMPLE_ROWS,
) -> list[list[str]]:
    """Parse the sample with the detected dialect, capped at `max_rows`.

    `quote_char=None` means "no quoting used" — we pass a placeholder
    `csv.QUOTE_NONE` equivalent by setting quotechar to '"' and
    quoting=csv.QUOTE_NONE so the reader doesn't treat any char as
    a quote.
    """
    reader_kwargs: dict = {"delimiter": delimiter}
    if quote_char is None:
        reader_kwargs["quotechar"] = '"'
        reader_kwargs["quoting"] = csv.QUOTE_NONE
    else:
        reader_kwargs["quotechar"] = quote_char

    try:
        reader = csv.reader(io.StringIO(text), **reader_kwargs)
        rows: list[list[str]] = []
        for i, row in enumerate(reader):
            if i >= max_rows:
                break
            rows.append(row)
    except csv.Error:
        return []
    return rows
