"""Command-line interface.

Three subcommands, one per core workflow from the brief:

- ``dsvmonkey inspect <file>`` — print the detection report.
- ``dsvmonkey normalize <file> -o <out>`` — write a cleaned version.
- ``dsvmonkey convert   <file> -o <out> --to {csv,tsv,jsonl}``

The CLI is a thin wrapper around ``profile_file``, ``repair`` and
``to_jsonl``. Business logic stays in the library; this module is for
argument parsing, pretty-printing, and exit codes.
"""

from __future__ import annotations

import argparse
import codecs
import csv
import sys
from pathlib import Path

from dsvmonkey.columns import ColumnProfile, profile_columns
from dsvmonkey.convert import to_jsonl
from dsvmonkey.reader import OverflowPolicy
from dsvmonkey.orchestrate import profile_file
from dsvmonkey.profile import DetectionResult, DictOverflowError, DSVProfile
from dsvmonkey.repair import RepairReport, repair

_LINE_ENDING_ALIASES = {
    "lf": "\n",
    "unix": "\n",
    "crlf": "\r\n",
    "windows": "\r\n",
    "cr": "\r",
    "mac": "\r",
}


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    try:
        if args.command == "inspect":
            return _cmd_inspect(args)
        if args.command == "normalize":
            return _cmd_normalize(args)
        if args.command == "convert":
            return _cmd_convert(args)
    except FileNotFoundError as err:
        print(f"error: file not found: {err.filename}", file=sys.stderr)
        return 2
    except PermissionError as err:
        # Own clause before OSError for a friendlier message.
        print(f"error: permission denied: {err.filename}", file=sys.stderr)
        return 2
    except IsADirectoryError as err:
        print(f"error: expected a file, got a directory: {err.filename}",
              file=sys.stderr)
        return 2
    except ValueError as err:
        # ValueError covers UnicodeEncodeError and UnicodeDecodeError
        # (both subclass UnicodeError → ValueError), so codec mismatches
        # on output land here cleanly.
        print(f"error: {err}", file=sys.stderr)
        return 2
    except csv.Error as err:
        # csv.reader / csv.writer raise csv.Error on malformed
        # input (unmatched quotes that confuse the parser even
        # under our defensive settings, etc.). Without this
        # clause it bubbled as a Python traceback — bad for
        # automation wrappers expecting a stable exit-code
        # contract.
        print(f"error: CSV parse failure: {err}", file=sys.stderr)
        return 2
    except OSError as err:
        # Catch-all for the rest of the I/O family: disk full, file
        # locked, invalid path, etc. Better a one-line error than a
        # stack trace.
        print(f"error: I/O failure: {err}", file=sys.stderr)
        return 2

    parser.print_help()
    return 1


# ---------- Argument parser ----------


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="dsvmonkey",
        description=(
            "Detect, profile, normalize and repair delimiter-separated "
            "values files."
        ),
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_inspect = sub.add_parser(
        "inspect", help="Profile a DSV file and print the detection report"
    )
    p_inspect.add_argument("path", type=Path)
    p_inspect.add_argument(
        "-v", "--verbose", action="store_true",
        help="Include runner-up alternatives and detection reasons",
    )
    p_inspect.add_argument(
        "--no-columns", action="store_true",
        help="Skip per-column sampling and date-format detection",
    )
    p_inspect.add_argument(
        "--sample-rows", type=int, default=500,
        help="Rows to sample per column (default: 500)",
    )
    p_inspect.add_argument(
        "--excel-serial-min", type=float, default=10000,
        help=(
            "Minimum column-min value required to accept an Excel "
            "serial date match (default: 10000 ≈ year 1927). "
            "Set to 0 to trust all serial-date matches."
        ),
    )
    p_inspect.add_argument(
        "--no-deep-scan", action="store_true",
        help=(
            "Skip the full-file mixed-encoding scan. Bounds I/O on "
            "very large or remote files at the cost of missing late-"
            "file corruption."
        ),
    )
    p_inspect.add_argument(
        "--clean-sample", action="store_true",
        help=(
            "Run column profiling against cleaned cell values rather "
            "than raw. Default is raw (profiling a cleaned view hides "
            "data-quality issues); enable when date detection needs "
            "tolerance for NBSPs or similar."
        ),
    )
    p_inspect.add_argument(
        "--strict", action="store_true",
        help=(
            "Exit with code 3 (instead of 0) when the profile signals "
            "needs_review — i.e. detection wasn't confident enough to "
            "trust the profile alone. Lets unattended pipelines gate "
            "on the file's reviewability without parsing stdout: "
            "`dsvmonkey inspect --strict file.csv || queue_for_review`."
        ),
    )

    p_normalize = sub.add_parser(
        "normalize",
        help="Fix ragged rows, strip BOM, normalize line endings; write cleaned output",
    )
    p_normalize.add_argument("path", type=Path)
    p_normalize.add_argument("-o", "--out", type=Path, required=True)
    p_normalize.add_argument("--encoding", default="utf-8")
    p_normalize.add_argument(
        "--line-ending", default="lf",
        help="Output line ending: lf (default), crlf, cr",
    )
    p_normalize.add_argument(
        "--delimiter", default=None,
        help="Override output delimiter (defaults to detected)",
    )
    p_normalize.add_argument(
        "--field-count", type=int, default=None,
        help="Force columns per row (short rows pad, long rows truncate)",
    )
    p_normalize.add_argument(
        "--no-clean", action="store_true",
        help="Disable cleanmonkey cell cleaning",
    )
    p_normalize.add_argument(
        "--no-deep-scan", action="store_true",
        help="Skip the full-file mixed-encoding scan (perf on large files)",
    )
    p_normalize.add_argument(
        "--keep-empty-rows", action="store_true",
        help=(
            "Preserve whitespace-only rows in the output. Default is "
            "to drop them. Useful for fixed-format exports or audit "
            "trails where blank rows are semantic."
        ),
    )
    p_normalize.add_argument(
        "--sanitize-formulas", action="store_true",
        help=(
            "Prepend ' to cells beginning with =, +, -, or @ so the "
            "output can't be evaluated as a formula when opened in "
            "Excel / Sheets. Off by default because it mutates "
            "content; turn on when output is destined for a "
            "spreadsheet from untrusted data."
        ),
    )
    p_normalize.add_argument(
        "--strict", action="store_true",
        help=(
            "Refuse to process files whose profile signals "
            "needs_review. Same gate semantics as `inspect "
            "--strict`: profile the file first, exit with code 3 "
            "(no output written) when detection isn't confident "
            "enough. Use in unattended pipelines to route "
            "ambiguous files to human review instead of running "
            "the normalisation against an uncertain dialect."
        ),
    )

    p_convert = sub.add_parser(
        "convert",
        help="Convert to CSV, TSV or JSON Lines",
    )
    p_convert.add_argument("path", type=Path)
    p_convert.add_argument("-o", "--out", type=Path, required=True)
    p_convert.add_argument(
        "--to", dest="fmt", choices=["csv", "tsv", "jsonl"], default="csv",
    )
    p_convert.add_argument(
        "--no-clean", action="store_true",
        help="Disable cleanmonkey cell cleaning",
    )
    p_convert.add_argument(
        "--no-deep-scan", action="store_true",
        help="Skip the full-file mixed-encoding scan (perf on large files)",
    )
    p_convert.add_argument(
        "--keep-empty-rows", action="store_true",
        help="Preserve whitespace-only rows in the output (default: drop)",
    )
    p_convert.add_argument(
        "--sanitize-formulas", action="store_true",
        help=(
            "Prepend ' to cells beginning with =, +, -, or @ to "
            "neutralise spreadsheet-formula injection. Apply when "
            "output is destined for Excel / Sheets — including JSONL "
            "output that may later be transformed back to a "
            "spreadsheet, where formula payloads surviving as JSON "
            "string values become live formulas."
        ),
    )
    p_convert.add_argument(
        "--strict", action="store_true",
        help=(
            "Refuse to process files whose profile signals "
            "needs_review. Exit with code 3 (no output written) "
            "when detection isn't confident enough. Same semantics "
            "as `inspect --strict` and `normalize --strict`."
        ),
    )

    return parser


# ---------- Commands ----------


def _cmd_inspect(args: argparse.Namespace) -> int:
    sample_rows = _validate_sample_rows(args.sample_rows)
    profile = profile_file(args.path, deep_scan=not args.no_deep_scan)
    columns: list[ColumnProfile] = []
    if not args.no_columns:
        columns = profile_columns(
            args.path,
            profile=profile,
            sample_rows=sample_rows,
            excel_serial_min_value=args.excel_serial_min,
            clean_cells=args.clean_sample,
        )
    print(_format_profile(profile, columns=columns, verbose=args.verbose))
    # `--strict` exits 3 when the profile recommends human review.
    # Lets unattended pipelines gate on reviewability with a plain
    # shell `||` — no need to parse the report. The "Review
    # recommended" block is already in the printed report (above);
    # the exit code is the machine-readable counterpart.
    if args.strict and profile.needs_review:
        return 3
    return 0


def _strict_gate_or_continue(
    args: argparse.Namespace,
) -> tuple[int | None, DSVProfile | None]:
    """Run the --strict gate and return the profile alongside the
    exit-code decision so the caller can thread it into the downstream
    operation.

    Returns `(rc, profile)`:
      - `(3, None)` — --strict set and the profile recommends review,
        OR the file changed on disk between profile and write;
        caller should return immediately, no output written.
      - `(None, profile)` — --strict set and the profile is clean;
        caller MUST pass `profile=profile` into the downstream
        repair() / to_jsonl() so the dialect the gate approved is
        the dialect that gets written. This closes both the
        gate-vs-run in-process TOCTOU window (a single in-memory
        profile decides both verdict and behaviour) and the
        duplicate profiling cost the previous version paid.
      - `(None, None)` — --strict not set; caller proceeds with
        the downstream's own profiling pass, exactly as before.

    File-mutation guard: the gate snapshots `(mtime, size)` and
    stashes them on `args._gate_stat`. Downstream `_cmd_normalize`
    / `_cmd_convert` re-stat before opening for read and bail with
    exit 3 when the pair has changed. This catches the realistic
    case (a concurrent writer to the same path between gate and
    open) without holding the file handle end-to-end. It does NOT
    catch sub-second races or in-place mutation that preserves
    (mtime, size) — a determined adversary can defeat any
    advisory check; the goal is to surface accidental concurrent
    overwrites in shared ingest directories.
    """
    if not getattr(args, "strict", False):
        return None, None
    try:
        gate_stat = args.path.stat()
    except OSError as err:
        # In strict mode, "couldn't even snapshot the file state" is
        # itself a reviewability failure — proceeding would mean the
        # mutation guard is silently disabled. Fail closed: emit a
        # clean error and exit 3, matching the rest of strict mode's
        # "be conservative when uncertain" contract. (The downstream
        # open would likely fail too with FileNotFoundError /
        # PermissionError, but that surfaces as exit 2 — a different
        # contract; --strict callers expect 3 for any
        # gate-can't-verify outcome.)
        print(
            f"error: --strict set but couldn't snapshot file state "
            f"for {args.path}: {err}. No output written.",
            file=sys.stderr,
        )
        return 3, None
    args._gate_stat = (gate_stat.st_mtime_ns, gate_stat.st_size)
    profile = profile_file(args.path, deep_scan=not args.no_deep_scan)
    if profile.needs_review:
        print(
            f"error: --strict set and {args.path} requires review:",
            file=sys.stderr,
        )
        for reason in profile.review_reasons:
            print(f"  - {reason}", file=sys.stderr)
        print(
            "  No output written. Inspect the file or rerun without "
            "--strict.",
            file=sys.stderr,
        )
        return 3, None
    return None, profile


def _check_file_unchanged_since_gate(
    args: argparse.Namespace,
) -> int | None:
    """Re-stat the input and bail with exit 3 when (mtime, size) has
    changed since the gate snapshot, OR when re-stat itself fails.

    Returns `3` to abort, or `None` to proceed. No-op when --strict
    isn't set.

    Fail-closed semantics: previously a stat() failure on the
    re-check returned None (proceed as if unchanged), which silently
    disabled the mutation guard exactly when something went wrong on
    the filesystem (NFS hiccup, file deleted between gate and write,
    permissions changed mid-pipeline). Strict mode's contract is
    "be conservative when uncertain" — a stat failure IS uncertainty.
    """
    if not getattr(args, "strict", False):
        return None
    snapshot = getattr(args, "_gate_stat", None)
    if snapshot is None:
        # The gate already failed closed if it couldn't snapshot, so
        # this branch only fires for callers who somehow reach the
        # check without going through the gate — defensive.
        print(
            f"error: --strict set but no gate snapshot recorded for "
            f"{args.path}; cannot verify file stability. No output "
            "written.",
            file=sys.stderr,
        )
        return 3
    try:
        current = args.path.stat()
    except OSError as err:
        print(
            f"error: --strict set but couldn't re-stat {args.path} "
            f"to verify file stability after gate: {err}. No output "
            "written.",
            file=sys.stderr,
        )
        return 3
    if (current.st_mtime_ns, current.st_size) != snapshot:
        print(
            f"error: --strict set and {args.path} changed on disk "
            "between gate and write (mtime/size differ from the "
            "moment the profile was taken). No output written.",
            file=sys.stderr,
        )
        return 3
    return None


def _cmd_normalize(args: argparse.Namespace) -> int:
    line_ending = _resolve_line_ending(args.line_ending)
    delimiter = _validate_delimiter(args.delimiter)
    field_count = _validate_field_count(args.field_count)
    encoding = _validate_encoding(args.encoding)
    gate_rc, gate_profile = _strict_gate_or_continue(args)
    if gate_rc is not None:
        return gate_rc
    mutation_rc = _check_file_unchanged_since_gate(args)
    if mutation_rc is not None:
        return mutation_rc
    report = repair(
        args.path,
        args.out,
        profile=gate_profile,
        target_encoding=encoding,
        target_line_ending=line_ending,
        target_delimiter=delimiter,
        target_field_count=field_count,
        clean_cells=not args.no_clean,
        deep_scan=not args.no_deep_scan,
        skip_empty_rows=not args.keep_empty_rows,
        sanitize_formulas=args.sanitize_formulas,
    )
    print(_format_repair_report(report))
    return 0


def _cmd_convert(args: argparse.Namespace) -> int:
    gate_rc, gate_profile = _strict_gate_or_continue(args)
    if gate_rc is not None:
        return gate_rc
    mutation_rc = _check_file_unchanged_since_gate(args)
    if mutation_rc is not None:
        return mutation_rc
    if args.fmt == "jsonl":
        # JSON consumers don't evaluate formulas themselves, but
        # JSONL output is commonly transformed back to CSV/Excel
        # downstream — `=SUM(A:A)` surviving as a string value
        # there becomes a live formula in the spreadsheet. So when
        # the caller asks for sanitization, we apply it even on the
        # JSONL path. Previously the CLI warned-and-ignored this
        # flag, which left a security-expectation gap.
        # --strict on JSONL escalates dict-mode overflow to a hard
        # failure: a wider-than-headers row would otherwise drop
        # cells with only a UserWarning, which an unattended
        # pipeline silencing warnings would miss. The strict
        # contract is "fail conservatively when unattended"; a
        # silent column drop on the JSONL boundary contradicts
        # that. Direct API callers can opt into the same via
        # `to_jsonl(..., on_overflow="raise")`.
        overflow_policy: OverflowPolicy = "raise" if args.strict else "warn"
        try:
            rows_written = to_jsonl(
                args.path,
                args.out,
                profile=gate_profile,
                clean_cells=not args.no_clean,
                deep_scan=not args.no_deep_scan,
                skip_empty_rows=not args.keep_empty_rows,
                sanitize_formulas=args.sanitize_formulas,
                on_overflow=overflow_policy,
            )
        except DictOverflowError as err:
            # Caught by class, not by message substring — the previous
            # version inspected `str(err)` which silently regressed to
            # the top-level ValueError handler (exit 2) the moment the
            # message wording drifted. Strict callers gating on
            # `|| queue_for_review` need exit 3 specifically; pin the
            # contract via the typed exception.
            if args.strict:
                print(
                    f"error: --strict set and {args.path} has "
                    f"wider-than-header rows ({err.row_width} cells "
                    f"vs {err.header_width} header(s)); JSONL would "
                    "lose cells. No output written.",
                    file=sys.stderr,
                )
                return 3
            raise
        print(f"wrote {rows_written} rows to {args.out}")
        return 0

    delimiter = "," if args.fmt == "csv" else "\t"
    report = repair(
        args.path,
        args.out,
        profile=gate_profile,
        target_delimiter=delimiter,
        clean_cells=not args.no_clean,
        deep_scan=not args.no_deep_scan,
        skip_empty_rows=not args.keep_empty_rows,
        sanitize_formulas=args.sanitize_formulas,
    )
    print(_format_repair_report(report))
    return 0


_STRUCTURALLY_RESERVED_DELIMITERS = frozenset({"\n", "\r", '"', "'"})


def _validate_delimiter(value: str | None) -> str | None:
    """Enforce the single-character requirement Python's csv module has.

    Also rejects structurally-reserved characters (`\\n`, `\\r`, `"`,
    `'`) that pass the single-char check but break DSV parsing —
    easy to trip on in automation (line-ending variable piped into
    delimiter arg) and impossible to recover from after write.
    Without this, `csv.writer(delimiter="||")` raises TypeError
    deep in the library — users of the CLI would see an uncaught
    traceback.
    """
    if value is None:
        return None
    if len(value) != 1:
        raise ValueError(
            f"delimiter must be a single character, got {value!r} "
            f"(length {len(value)})"
        )
    if value in _STRUCTURALLY_RESERVED_DELIMITERS:
        raise ValueError(
            f"delimiter {value!r} is reserved by DSV parsing "
            "(newlines and quote characters can't be delimiters); "
            "pick a different character"
        )
    return value


def _validate_field_count(value: int | None) -> int | None:
    """Reject non-positive field counts.

    `_fit_row(row, field_count=-2)` slices as `row[:-2]` — it silently
    drops cells instead of padding/truncating to a consistent width.
    """
    if value is None:
        return None
    if value < 1:
        raise ValueError(
            f"--field-count must be a positive integer, got {value}"
        )
    return value


def _validate_sample_rows(value: int) -> int:
    """Reject non-positive sample-row counts.

    `profile_columns(sample_rows=-1)` returns column profiles with
    zero sampled values because the `count >= sample_rows` break
    fires on the first iteration. That's a misleading silent empty
    report rather than a useful error. Argparse happily accepts
    `-1` through `type=int`; this enforces the contract implied by
    the help text ("Rows to sample per column").
    """
    if value < 1:
        raise ValueError(
            f"--sample-rows must be a positive integer, got {value}"
        )
    return value


def _validate_encoding(name: str) -> str:
    """Reject codec names Python doesn't recognise.

    Without this, a typo like `--encoding not-an-encoding` reaches
    `open(..., encoding=name)` deep in repair() and raises LookupError.
    main() doesn't catch LookupError, so users see a full traceback.
    Validating up front keeps the CLI's error surface consistent
    (exit 2, one-line message).
    """
    try:
        codecs.lookup(name)
    except LookupError:
        raise ValueError(f"unknown encoding {name!r}")
    return name


# ---------- Pretty-printing ----------


def _format_profile(
    profile: DSVProfile,
    *,
    columns: list[ColumnProfile] | None = None,
    verbose: bool,
) -> str:
    lines: list[str] = []
    lines.append("dsvmonkey inspect report")
    lines.append("=" * 24)
    lines.append(f"File:         {profile.path}")
    lines.append(f"Size:         {profile.file_size:,} bytes")
    lines.append(f"Sample:       {profile.sample_bytes:,} bytes")
    lines.append("")

    lines.append(_format_detection("Encoding", profile.encoding, verbose))
    lines.append(f"  BOM:        {'yes' if profile.has_bom else 'no'}"
                 + (f" ({profile.bom})" if profile.bom else ""))
    lines.append(
        f"  Mixed:      {'suspected' if profile.mixed_encoding_suspected else 'no'}"
    )
    lines.append("")

    lines.append(_format_detection("Delimiter", profile.delimiter, verbose,
                                   value_repr=_repr_control))
    lines.append(_format_detection("Quote char", profile.quote_char, verbose,
                                   value_repr=_repr_control))
    lines.append(_format_detection("Line ending", profile.line_ending, verbose,
                                   value_repr=_repr_line_ending))
    lines.append("")

    lines.append(_format_detection("Header row", profile.header_row, verbose))
    if profile.headers:
        preview = ", ".join(profile.headers[:8])
        if len(profile.headers) > 8:
            preview += f", ... (+{len(profile.headers) - 8} more)"
        lines.append(f"  Columns:    {preview}")
    lines.append(f"  Field count: {profile.field_count}")
    lines.append("")

    if profile.issues:
        lines.append("Issues:")
        for issue in profile.issues:
            lines.append(f"  - {issue}")
    else:
        lines.append("Issues: (none)")

    # `needs_review` is the aggregate "look at the file yourself"
    # signal. Surfacing it prominently after the issues list keeps
    # the recommendation visible to operators scanning the report.
    if profile.needs_review:
        lines.append("")
        lines.append("Review recommended — detection is uncertain:")
        for reason in profile.review_reasons:
            lines.append(f"  - {reason}")
        lines.append(
            "  Visually inspect the file before trusting the profile."
        )

    if columns:
        lines.append("")
        lines.append(_format_columns(columns))

    return "\n".join(lines)


def _format_columns(columns: list[ColumnProfile]) -> str:
    lines: list[str] = []
    lines.append("Columns:")
    for column in columns:
        # `sample_size` is the count of NON-EMPTY sampled values, not
        # total rows sampled. Previous label "sampled N" invited the
        # mis-reading "N rows were sampled"; saying "N values, M
        # empty" matches the actual semantics of what the column
        # profiler collects.
        header = (
            f"  [{column.index}] {column.name}  "
            f"({column.sample_size} values, {column.empty_count} empty)"
        )
        lines.append(header)
        if column.date_format:
            lines.append(
                f"       date: {column.date_format_label} "
                f"({column.date_format}) — "
                f"confidence {column.date_confidence}, "
                f"match {column.date_match_ratio:.0%}"
            )
        for warning in column.warnings:
            lines.append(f"       ! {warning}")
    return "\n".join(lines)


def _format_detection(
    label: str,
    result: DetectionResult | None,
    verbose: bool,
    value_repr=repr,
) -> str:
    if result is None:
        return f"{label}: (not detected)"

    value_str = value_repr(result.value) if result.value is not None else "(none)"
    line = (
        f"{label}: {value_str}  "
        f"(confidence: {result.confidence:.2f}, method: {result.method})"
    )
    if not verbose:
        return line

    extra: list[str] = []
    if result.alternatives:
        alt_parts = [
            f"{value_repr(a.value)} ({a.confidence:.2f})"
            for a in result.alternatives
        ]
        extra.append(f"  Alternatives: {', '.join(alt_parts)}")
        for alt in result.alternatives:
            extra.append(f"    {value_repr(alt.value)}: {alt.reason}")
    if result.warnings:
        for warning in result.warnings:
            extra.append(f"  ! {warning}")

    if extra:
        return line + "\n" + "\n".join(extra)
    return line


def _format_repair_report(report: RepairReport) -> str:
    lines: list[str] = []
    lines.append(f"Input:  {report.input_path}")
    if report.output_path:
        lines.append(f"Output: {report.output_path}")
    else:
        lines.append("Output: (dry run, nothing written)")
    lines.append(f"Rows read:    {report.rows_read}")
    lines.append(
        f"Rows written: {report.rows_written}"
        + (" (+ header)" if report.header_written else "")
    )
    changes: list[str] = []
    if report.bom_stripped:
        changes.append("BOM stripped")
    if report.line_ending_changed:
        changes.append("line endings normalized")
    if report.delimiter_changed:
        changes.append("delimiter changed")
    if report.encoding_changed:
        changes.append("encoding changed")
    if report.short_rows_padded:
        changes.append(f"{report.short_rows_padded} short row(s) padded")
    if report.long_rows_truncated:
        changes.append(f"{report.long_rows_truncated} long row(s) truncated")
    if report.empty_rows_skipped:
        changes.append(f"{report.empty_rows_skipped} empty row(s) skipped")
    if changes:
        lines.append("Changes:")
        for change in changes:
            lines.append(f"  - {change}")
    else:
        lines.append("Changes: (none — input was already clean)")
    return "\n".join(lines)


_SINGLE_COLUMN_SENTINEL_CHARS = frozenset({"\x1f", "\x1e", "\x1d", "\x1c"})


def _repr_control(value) -> str:
    """Display tabs and control chars readably in the report."""
    if value is None:
        return "(none)"
    if value == "\t":
        return "\\t (tab)"
    if value in _SINGLE_COLUMN_SENTINEL_CHARS:
        # Single-column sentinel emitted by the delimiter detector
        # when the file has no real delimiter. The detector picks
        # from {\x1f, \x1e, \x1d, \x1c} dynamically (whichever is
        # absent from the sample, to avoid collision), so the CLI
        # has to recognise all four — surfacing the raw control
        # char isn't helpful to an operator.
        return "(none — single column)"
    return repr(value)


def _repr_line_ending(value) -> str:
    if value == "\n":
        return "LF"
    if value == "\r\n":
        return "CRLF"
    if value == "\r":
        return "CR"
    return repr(value)


def _resolve_line_ending(alias: str) -> str:
    key = alias.lower()
    if key in _LINE_ENDING_ALIASES:
        return _LINE_ENDING_ALIASES[key]
    raise ValueError(
        f"unknown line ending {alias!r}; use one of: "
        + ", ".join(sorted(_LINE_ENDING_ALIASES))
    )


if __name__ == "__main__":
    sys.exit(main())
