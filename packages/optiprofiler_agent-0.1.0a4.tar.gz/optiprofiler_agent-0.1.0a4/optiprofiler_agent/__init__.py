"""OptiProfiler Agent — AI-powered assistant for optimization benchmarking."""

__version__ = "0.1.0a4"

from optiprofiler_agent.config import AgentConfig, LLMConfig

__all__ = ["AgentConfig", "LLMConfig", "__version__"]
