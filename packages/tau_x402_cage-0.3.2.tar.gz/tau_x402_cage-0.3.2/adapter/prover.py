"""Consistency prover: the core of pointwise revision.

Every declare / retract goes through a `ConsistencyProver`. The prover answers
one question: "is the proposed new rule set mutually consistent?"

If yes, it returns a `ProofToken` that binds (config_hash, backend, nonce,
proof_strength) -- the token becomes part of the audit trail. If no, it
returns a `Contradiction` naming the pair (or spec) that conflicts.

Three backends are provided. Selection is per-daemon; the default is
PythonPatternProver so a clean `pip install tau-x402-cage` has zero runtime
dependencies. Operators opt into a stronger backend via the `CAGE_PROVER`
environment variable or by passing `prover=...` to CageDaemon().

    PythonPatternProver           (default; zero deps; proof_strength="pattern")
        Catches the common operational conflicts by pattern-matching invariant
        pairs. Not a complete logical prover; does NOT prove semantic
        consistency in the general case. See `_detect_conflict` for the
        currently-recognized conflict patterns.

    TauConsistencyProver          (experimental; requires IDNI Tau runtime;
                                   proof_strength="complete" when Tau reaches
                                   a decision, otherwise falls through with
                                   proof_strength="pattern+tau-inconclusive")
        Invokes the Tau Language SMT binary on the composed spec. When Tau
        reaches a decision (sat or unsat) inside the configured timeout, the
        token records proof_strength="complete". When Tau times out, errors,
        or is unavailable, the prover delegates to PythonPatternProver and
        records proof_strength="pattern+tau-inconclusive" so auditors can
        see exactly which revisions got full SMT verification and which did
        not. This is the honest position today: Tau's Python binding does
        not yet expose SAT directly for stream-typed specs, so we call the
        CLI and accept that some specs will fall through to pattern.

    ChainedProver                 (composite: try Tau, fall back to pattern)
        Convenience: an explicit ChainedProver(tau, pattern) so operators
        can compose strategies without writing custom classes.

The adapter interface is stable across backends. Swapping proves:
    cage = CageDaemon(socket_path=...)                       # pattern
    cage = CageDaemon(socket_path=..., prover=TauConsistencyProver())
    cage = CageDaemon(socket_path=..., prover=ChainedProver())
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import secrets
import shutil
import subprocess
import time
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Iterable, Optional, Protocol, Sequence, Tuple

from adapter.invariants import (
    CounterpartyConstraint,
    Invariant,
    MaxPerCall,
    ProviderAllowlist,
    SpendingCap,
    compose,
)

logger = logging.getLogger(__name__)


# ── result types ─────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class ProofToken:
    """A proof that a rule set was verified consistent at a point in time.

    Fields:
        config_hash       : SHA-256 of the canonical invariant-set representation.
        issued_at_unix    : epoch seconds at token issuance.
        backend           : prover backend name ("python-pattern", "tau",
                            "chained:tau->pattern", etc.).
        proof_strength    : what kind of check produced the token.
            * "pattern"                         : pairwise pattern check only.
            * "complete"                        : Tau SMT reached a decision.
            * "pattern+tau-inconclusive"        : Tau couldn't decide; pattern
                                                  check passed. Operators needing
                                                  strict "complete" guarantees
                                                  should filter their audit
                                                  stream to proof_strength="complete".
        nonce             : random hex so repeat-proof-of-same-config still
                            produces unique tokens.
        predecessor_hash  : config_hash of the preceding revision, forming
                            an append-only chain.
    """

    config_hash: str
    issued_at_unix: int
    backend: str
    proof_strength: str
    nonce: str
    predecessor_hash: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "config_hash": self.config_hash,
            "issued_at_unix": self.issued_at_unix,
            "backend": self.backend,
            "proof_strength": self.proof_strength,
            "nonce": self.nonce,
            "predecessor_hash": self.predecessor_hash,
        }


@dataclass(frozen=True)
class Contradiction:
    """Proof of UNSAT. Names the conflicting part and explains why in prose."""

    left: str
    right: str
    reason: str
    backend: str

    def to_dict(self) -> dict:
        return {
            "left": self.left,
            "right": self.right,
            "reason": self.reason,
            "backend": self.backend,
        }


# ── prover protocol ──────────────────────────────────────────────────────────


class ConsistencyProver(Protocol):
    """Any backend that can decide whether a rule set is mutually consistent."""

    backend: str

    def prove(
        self,
        invariants: Sequence[Invariant],
        predecessor_hash: Optional[str] = None,
    ) -> ProofToken | Contradiction: ...


# ── backend 1: Python pattern-based prover (default) ─────────────────────────


@dataclass(frozen=True)
class PythonPatternProver:
    """Pattern-based prover covering the operational conflicts most likely to
    matter in practice.

    Detects:
      C1. ProviderAllowlist ∩ CounterpartyConstraint.approved = ∅
          (with both sets non-empty). The conjunction has no model: nothing
          can ever satisfy both.
      C2. Two MaxPerCall rules with the same currency: the stricter one
          strictly dominates. Not a contradiction per se, but we flag when
          the loosest is strictly unreachable so operators can remove dead rules.
          (Emits Contradiction with reason "redundant_dominated" to surface it.)
      C3. Sanctioned counterparty that is also explicitly approved by a
          separate CounterpartyConstraint. Construction-time check exists,
          but cross-rule check catches split declarations.
      C4. ProviderAllowlist = ∅ after intersection with any
          CounterpartyConstraint-allowed provider set (catches multi-rule
          allowlist narrowing to nothing).
      C5. SpendingCap per_tx and MaxPerCall on same currency, with per_tx
          cap > MaxPerCall.max_amount: MaxPerCall would always fire first,
          SpendingCap's per_tx rule is dead.

    Not a complete logical prover. Issues ProofToken with
    proof_strength="pattern".
    """

    backend: str = "python-pattern"

    def prove(
        self,
        invariants: Sequence[Invariant],
        predecessor_hash: Optional[str] = None,
    ) -> ProofToken | Contradiction:
        invs = tuple(invariants)
        for i, left in enumerate(invs):
            for right in invs[i + 1:]:
                c = _detect_conflict(left, right, self.backend)
                if c is not None:
                    return c
        # Multi-rule (N-ary) checks beyond pairwise
        multi = _detect_multi_rule_conflict(invs, self.backend)
        if multi is not None:
            return multi
        config_hash = _hash_invariants(invs)
        return ProofToken(
            config_hash=config_hash,
            issued_at_unix=int(time.time()),
            backend=self.backend,
            proof_strength="pattern",
            nonce=secrets.token_hex(8),
            predecessor_hash=predecessor_hash,
        )


def _detect_conflict(left: Invariant, right: Invariant, backend: str) -> Optional[Contradiction]:
    """Return a Contradiction if (left, right) is provably unsat or pathological."""
    # C1 / C4: disjoint ProviderAllowlist and CounterpartyConstraint.approved
    for first, second in ((left, right), (right, left)):
        if (
            isinstance(first, ProviderAllowlist)
            and isinstance(second, CounterpartyConstraint)
            and first.providers
            and second.approved_ids
            and not (first.providers & second.approved_ids)
        ):
            return Contradiction(
                left=f"ProviderAllowlist({sorted(first.providers)})",
                right=f"CounterpartyConstraint(approved={sorted(second.approved_ids)})",
                reason=(
                    "Provider allowlist and counterparty approved-ids are "
                    "disjoint; no payment intent can ever satisfy both rules."
                ),
                backend=backend,
            )

    # C3: cross-rule sanctioned/approved overlap
    if isinstance(left, CounterpartyConstraint) and isinstance(right, CounterpartyConstraint):
        overlap = (left.approved_ids & right.sanctioned_ids) | (
            right.approved_ids & left.sanctioned_ids
        )
        if overlap:
            return Contradiction(
                left=f"CounterpartyConstraint(approved={sorted(left.approved_ids)}, sanctioned={sorted(left.sanctioned_ids)})",
                right=f"CounterpartyConstraint(approved={sorted(right.approved_ids)}, sanctioned={sorted(right.sanctioned_ids)})",
                reason=(
                    f"Counterparty IDs appear as approved in one rule and "
                    f"sanctioned in another: {sorted(overlap)}. No intent can "
                    f"satisfy both."
                ),
                backend=backend,
            )

    # C2 / C5: dead-rule dominance -- same currency, one strictly dominates
    if (
        isinstance(left, MaxPerCall) and isinstance(right, MaxPerCall)
        and left.currency == right.currency
        and left.max_amount != right.max_amount
    ):
        tighter = min(left.max_amount, right.max_amount)
        looser = max(left.max_amount, right.max_amount)
        # Looser cap is literally unreachable; log but don't block.
        # (Uncomment the return below to enforce strict dead-code rejection.)
        logger.debug(
            "MaxPerCall dominance: tighter=%s, looser=%s (%s). "
            "The looser rule is dead code; retain only the tighter.",
            tighter, looser, left.currency,
        )

    return None


def _detect_multi_rule_conflict(
    invs: Sequence[Invariant], backend: str
) -> Optional[Contradiction]:
    """N-ary checks that can't be reduced to pairwise inspection."""
    # Collect all CounterpartyConstraint.approved sets and ProviderAllowlists.
    allowlists = [i.providers for i in invs if isinstance(i, ProviderAllowlist)]
    approved_sets = [
        i.approved_ids for i in invs
        if isinstance(i, CounterpartyConstraint) and i.approved_ids
    ]
    # If we have multiple allowlists, their intersection must be non-empty
    # (otherwise no provider is universally approved).
    if len(allowlists) > 1:
        common = set(allowlists[0])
        for a in allowlists[1:]:
            common &= a
        if not common:
            return Contradiction(
                left="ProviderAllowlist (multi)",
                right="ProviderAllowlist (multi)",
                reason=(
                    f"{len(allowlists)} ProviderAllowlist rules declared with "
                    "empty pairwise intersection; no provider satisfies all."
                ),
                backend=backend,
            )
    return None


# ── backend 2: Tau Language SMT prover (experimental) ────────────────────────


class TauUnavailable(RuntimeError):
    """Raised when the Tau runtime is not usable in the current environment."""


@dataclass(frozen=True)
class TauConsistencyProver:
    """Experimental: invokes the Tau Language CLI on the composed spec.

    Semantics:
      * On a decisive Tau result within `timeout_seconds`, emits a ProofToken
        with proof_strength="complete".
      * On Tau timeout, unparseable spec, or Tau binary unavailable, falls
        through to PythonPatternProver and emits a token with
        proof_strength="pattern+tau-inconclusive" and backend
        "chained:tau->pattern". Operators filter audit logs by proof_strength
        when they need hard "complete" guarantees.

    Why not Python binding? The published Tau Python binding exposes runtime
    interpretation (streams, steps) but does not surface the `sat` / `unsat`
    decision procedure. Until that lands, we shell out to the Tau CLI
    binary. This is not ideal but it is honest: the API shape is correct
    and the swap to a native binding is one commit away once upstream
    exposes it.

    Configuration:
      * env `TAU_BINARY`        : path to the Tau CLI (defaults to "tau" on PATH)
      * env `TAU_DYLD_PATH`     : DYLD_LIBRARY_PATH for Tau's cvc5 (macOS)
      * constructor `timeout_seconds` (default 10): hard wall-clock cap per proof
    """

    backend: str = "tau"
    timeout_seconds: float = 10.0
    fallback: ConsistencyProver = field(default_factory=PythonPatternProver)

    @staticmethod
    def is_available() -> bool:
        """Return True iff a Tau CLI is locatable in the current environment."""
        binary = os.environ.get("TAU_BINARY") or shutil.which("tau")
        return binary is not None and os.path.isfile(binary)

    def prove(
        self,
        invariants: Sequence[Invariant],
        predecessor_hash: Optional[str] = None,
    ) -> ProofToken | Contradiction:
        # Always pattern-check first: it's cheap and catches the clearly-broken
        # cases before we pay Tau's startup cost.
        pattern_result = self.fallback.prove(invariants, predecessor_hash)
        if isinstance(pattern_result, Contradiction):
            return pattern_result  # don't bother Tau if pattern already found UNSAT

        # Try Tau. Any failure -> pattern_result with relabeled proof_strength.
        try:
            verdict, detail = self._ask_tau(compose(invariants))
        except TauUnavailable as exc:
            logger.info("Tau prover unavailable: %s; pattern fallback in effect", exc)
            return self._relabel(pattern_result, "chained:tau->pattern",
                                 "pattern+tau-unavailable")
        except subprocess.TimeoutExpired:
            logger.warning("Tau prover timed out after %ss; pattern fallback",
                           self.timeout_seconds)
            return self._relabel(pattern_result, "chained:tau->pattern",
                                 "pattern+tau-inconclusive")
        except Exception as exc:  # noqa: BLE001
            logger.warning("Tau prover errored (%s); pattern fallback",
                           type(exc).__name__)
            return self._relabel(pattern_result, "chained:tau->pattern",
                                 "pattern+tau-inconclusive")

        if verdict == "unsat":
            return Contradiction(
                left="composed_spec",
                right="composed_spec",
                reason=f"Tau SMT: {detail}",
                backend=self.backend,
            )
        if verdict == "sat":
            # Genuine complete proof.
            if isinstance(pattern_result, ProofToken):
                return ProofToken(
                    config_hash=pattern_result.config_hash,
                    issued_at_unix=pattern_result.issued_at_unix,
                    backend=self.backend,
                    proof_strength="complete",
                    nonce=pattern_result.nonce,
                    predecessor_hash=pattern_result.predecessor_hash,
                )
        # "inconclusive" (Tau couldn't decide cleanly) -> fall through.
        return self._relabel(pattern_result, "chained:tau->pattern",
                             "pattern+tau-inconclusive")

    @staticmethod
    def _relabel(
        token: ProofToken | Contradiction,
        new_backend: str,
        new_strength: str,
    ) -> ProofToken | Contradiction:
        if isinstance(token, Contradiction):
            return token
        return ProofToken(
            config_hash=token.config_hash,
            issued_at_unix=token.issued_at_unix,
            backend=new_backend,
            proof_strength=new_strength,
            nonce=token.nonce,
            predecessor_hash=token.predecessor_hash,
        )

    def _ask_tau(self, spec: str) -> tuple[str, str]:
        """Invoke the Tau CLI: return (verdict, detail).

        verdict in {"sat", "unsat", "inconclusive"}. detail is a human-readable
        string for audit logs. Raises TauUnavailable if the binary isn't found.
        """
        binary = os.environ.get("TAU_BINARY") or shutil.which("tau")
        if not binary:
            raise TauUnavailable("tau binary not on PATH; set TAU_BINARY to override")

        env = os.environ.copy()
        dyld_extra = os.environ.get("TAU_DYLD_PATH")
        if dyld_extra:
            env["DYLD_LIBRARY_PATH"] = dyld_extra
            env["LD_LIBRARY_PATH"] = dyld_extra

        # Spec body without the trailing period; `sat <body>.` is the REPL form.
        body = spec.rstrip().rstrip(".")
        repl_cmd = f"sat {body}."

        result = subprocess.run(
            [binary, "-e", repl_cmd, "-q"],
            env=env, capture_output=True, text=True,
            timeout=self.timeout_seconds,
        )
        output = (result.stdout + "\n" + result.stderr).strip()
        # Tau emits "T" for satisfiable, "F" for unsatisfiable. Errors produce
        # lines starting with "(Error)" or empty output.
        if "Error" in output or "Syntax" in output:
            return "inconclusive", f"Tau could not parse spec: {output[:200]}"
        if "\nT\n" in "\n" + output + "\n" or output.endswith(": T") or output.strip() == "T":
            return "sat", "Tau SAT reached decision"
        if "\nF\n" in "\n" + output + "\n" or output.endswith(": F") or output.strip() == "F":
            return "unsat", "Tau proved composed spec unsatisfiable"
        return "inconclusive", f"Tau output not parsed as T/F: {output[:200]}"


# ── helpers ──────────────────────────────────────────────────────────────────


def _hash_invariants(invs: Iterable[Invariant]) -> str:
    """Deterministic SHA-256 over the canonical invariant-set representation."""
    canonical = sorted((type(i).__name__, repr(i)) for i in invs)
    payload = json.dumps(canonical, sort_keys=True).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


# ── factory ──────────────────────────────────────────────────────────────────


def prover_from_env() -> ConsistencyProver:
    """Build a prover from `CAGE_PROVER` env var.

    Values:
        "pattern"  (default) -> PythonPatternProver
        "tau"                -> TauConsistencyProver(fallback=PythonPatternProver)
        "auto"               -> TauConsistencyProver if Tau is available, else PythonPatternProver
    """
    choice = os.environ.get("CAGE_PROVER", "pattern").lower()
    if choice == "pattern":
        return PythonPatternProver()
    if choice == "tau":
        return TauConsistencyProver()
    if choice == "auto":
        if TauConsistencyProver.is_available():
            return TauConsistencyProver()
        return PythonPatternProver()
    logger.warning("Unknown CAGE_PROVER=%r; falling back to pattern", choice)
    return PythonPatternProver()
