import datetime
import enum
from typing import Any
from uuid import UUID

from pydantic import BaseModel as _BaseModel
from pydantic import Field


class State(str, enum.Enum):
    RETRY = "RETRY"
    PREPARING = "PREPARING"
    PENDING = "PENDING"
    WORKING = "WORKING"
    PAWING = "PAWING"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    REVOKED = "REVOKED"


class SourceType(str, enum.Enum):
    """Used for object creation in `payload.sourceFileName.sourceType`"""

    ADT = "ADT"
    URL = "URL"
    FILEPATH = "FILEPATH"
    FILESTORE = "FILESTORE"


class BaseModel(_BaseModel):
    def dump(self) -> dict[str, Any]:
        return self.model_dump(mode="json", by_alias=True)


class JobCreateModel(BaseModel):
    userId: UUID
    payload: dict[str, Any]
    webData: dict[str, Any] = Field(default_factory=dict)
    datasetReleaseId: str | None = None
    datasetSchemaId: str | None = None
    projectId: UUID | None = None
    publish: bool = False


class JobSubmitModel(BaseModel):
    executionSlug: str | None = Field(default=None, alias="execution_slug")


class JobModel(JobCreateModel):
    id: UUID | None = None
    groupId: str | None = None
    errors: list[Any] = Field(default_factory=list)
    created: datetime.datetime | None = None
    modified: datetime.datetime | None = None
    state: State = Field(State.PENDING)
    status: dict[str, Any] = Field(default_factory=dict)
    deleted: bool = False
    storeTTL: int | None = None
    methodName: str | None = None
    publications: list[dict[str, Any]] = Field(default_factory=list)


class TaskStatusModel(BaseModel):
    state: State
    status: dict[str, Any] = Field(default_factory=dict)


class JobResultPath(BaseModel):
    name: str
    size: int
    mimetype: str


class CacheMemberModel(BaseModel):
    id: UUID = Field(..., alias="guid")
    filename: str
    mimetype: str
    thumbnail: dict[str, str] | None = None
