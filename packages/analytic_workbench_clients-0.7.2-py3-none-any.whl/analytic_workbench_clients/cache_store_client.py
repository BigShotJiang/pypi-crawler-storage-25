from typing import Any
from uuid import UUID

from clients_core.exceptions import ClientValueError  # noqa: F401
from clients_core.service_clients import E360ServiceClient
from pydantic import TypeAdapter

from .models import CacheMemberModel


class AWCacheStoreClient(E360ServiceClient):
    """
    Subclasses dataclass `clients_core.service_clients.E360ServiceClient`.

    Args:
        client (clients_core.rest_client.RestClient): an instance of a rest client
        user_id (str): the user_id guid

    """

    service_endpoint = ""
    extra_headers = {"accept": "application/json"}

    def list_cache(self, job_id: UUID, **kwargs: Any) -> list[CacheMemberModel]:
        url = f"{job_id}/"
        response = self.client.get(url, headers=self.service_headers, raises=True, **kwargs)
        return TypeAdapter(list[CacheMemberModel]).validate_python(response.json())

    def get_cache_item(self, job_id: UUID, cache_id: UUID, **kwargs: Any) -> bytes:
        url = f"{job_id}/{cache_id}/"
        headers = self.extra_headers.copy()
        headers.update(self.service_headers)
        headers.update({"accept": "application/octet-stream"})
        response = self.client.get(url, raises=True, headers=headers, **kwargs)
        return response.content
