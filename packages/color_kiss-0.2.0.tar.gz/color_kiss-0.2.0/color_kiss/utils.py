from . import CYAN, GREEN, RED, RESET, YELLOW

# Severity prefixes
ERROR_PREFIX = f"{RED}Error:{RESET}"
SUCCESS_PREFIX = f"{GREEN}Success:{RESET}"
WARNING_PREFIX = f"{YELLOW}Warning:{RESET}"
INFO_PREFIX = f"{CYAN}Info:{RESET}"


def styled(text: str, *styles: str) -> str:
    """
    Apply multiple ANSI styles to text and auto-reset.

    Args:
        text: The text to style.
        *styles: One or more ANSI style codes (e.g., BOLD, RED, BG_BLUE).

    Returns:
        Styled string with RESET appended.

    Example:
        >>> styled("Hello", BOLD, RED)
        '\\033[1m\\033[31mHello\\033[0m'
    """
    return "".join(styles) + text + RESET


def error(text: str) -> str:
    """
    Format an error message with red "Error:" prefix.

    Args:
        text: The error message text.

    Returns:
        Formatted string: "Error: {text}" in red.

    Example:
        >>> error("File not found")
        '\\033[31mError:\\033[0m File not found'
    """
    return f"{ERROR_PREFIX} {text}"


def success(text: str) -> str:
    """
    Format a success message with green "Success:" prefix.

    Args:
        text: The success message text.

    Returns:
        Formatted string: "Success: {text}" in green.

    Example:
        >>> success("Download complete")
        '\\033[32mSuccess:\\033[0m Download complete'
    """
    return f"{SUCCESS_PREFIX} {text}"


def warning(text: str) -> str:
    """
    Format a warning message with yellow "Warning:" prefix.

    Args:
        text: The warning message text.

    Returns:
        Formatted string: "Warning: {text}" in yellow.

    Example:
        >>> warning("Low disk space")
        '\\033[33mWarning:\\033[0m Low disk space'
    """
    return f"{WARNING_PREFIX} {text}"


def info(text: str) -> str:
    """
    Format an info message with cyan "Info:" prefix.

    Args:
        text: The info message text.

    Returns:
        Formatted string: "Info: {text}" in cyan.

    Example:
        >>> info("Processing 3 files")
        '\\033[36mInfo:\\033[0m Processing 3 files'
    """
    return f"{INFO_PREFIX} {text}"
