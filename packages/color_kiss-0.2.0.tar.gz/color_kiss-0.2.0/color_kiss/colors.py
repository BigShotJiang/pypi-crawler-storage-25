"""
ANSI color codes for terminal output formatting.

This module provides a comprehensive set of ANSI escape codes for styling
terminal text output. It includes base colors, text styles (bold, italic, etc.),
background colors, and all possible combinations of styles with colors.

Usage:
    from color_kiss import RED, GREEN, RESET, BOLD_RED, ITALIC_BLUE
    print(f"{BOLD_RED}Error:{RESET} Something went wrong")

Available categories:
    - Base styles: BOLD, DIM, ITALIC, UNDERLINE, BLINK, REVERSE, HIDDEN, STRIKETHROUGH
    - Base colors: BLACK, RED, GREEN, YELLOW, BLUE, MAGENTA, CYAN, WHITE
    - Bright colors: BRIGHT_BLACK, BRIGHT_RED, BRIGHT_GREEN, BRIGHT_YELLOW,
                     BRIGHT_BLUE, BRIGHT_MAGENTA, BRIGHT_CYAN, BRIGHT_WHITE
    - Background colors: BG_BLACK, BG_RED, BG_GREEN, ..., BG_BRIGHT_WHITE
    - Combined styles: BOLD_RED, ITALIC_BLUE, UNDERLINE_GREEN, etc.
    - Background combinations: BOLD_BG_RED, ITALIC_BG_BLUE, etc.
    - Aliases: GRAY (same as BRIGHT_BLACK), BG_GRAY, BOLD_GRAY
"""

RESET = "\033[0m"
"""Reset all ANSI styles and colors to terminal defaults."""

_STYLES = {
    "BOLD": "1",
    "DIM": "2",
    "ITALIC": "3",
    "UNDERLINE": "4",
    "BLINK": "5",
    "REVERSE": "7",
    "HIDDEN": "8",
    "STRIKETHROUGH": "9",
}
"""Mapping of text style names to their ANSI escape codes."""

_COLORS = {
    "BLACK": "30",
    "RED": "31",
    "GREEN": "32",
    "YELLOW": "33",
    "BLUE": "34",
    "MAGENTA": "35",
    "CYAN": "36",
    "WHITE": "37",
    "BRIGHT_BLACK": "90",
    "BRIGHT_RED": "91",
    "BRIGHT_GREEN": "92",
    "BRIGHT_YELLOW": "93",
    "BRIGHT_BLUE": "94",
    "BRIGHT_MAGENTA": "95",
    "BRIGHT_CYAN": "96",
    "BRIGHT_WHITE": "97",
}
"""Mapping of foreground color names to their ANSI escape codes."""

_BG = {
    "BLACK": "40",
    "RED": "41",
    "GREEN": "42",
    "YELLOW": "43",
    "BLUE": "44",
    "MAGENTA": "45",
    "CYAN": "46",
    "WHITE": "47",
    "BRIGHT_BLACK": "100",
    "BRIGHT_RED": "101",
    "BRIGHT_GREEN": "102",
    "BRIGHT_YELLOW": "103",
    "BRIGHT_BLUE": "104",
    "BRIGHT_MAGENTA": "105",
    "BRIGHT_CYAN": "106",
    "BRIGHT_WHITE": "107",
}
"""Mapping of background color names to their ANSI escape codes."""


def _generate_colors():
    """Generate all color constants in the global namespace.

    Creates the following categories of global variables:
        - Base styles: BOLD, DIM, ITALIC, etc.
        - Foreground colors: RED, GREEN, BLUE, etc.
        - Background colors: BG_RED, BG_GREEN, etc.
        - Style + color combinations: BOLD_RED, ITALIC_BLUE, etc.
        - Style + background combinations: BOLD_BG_RED, ITALIC_BG_BLUE, etc.
        - Aliases: GRAY, BG_GRAY, BOLD_GRAY

    All generated variables are strings containing the corresponding
    ANSI escape sequences (e.g., "\\033[1;31m" for BOLD_RED).
    """
    for _name, _code in _STYLES.items():
        globals()[_name] = f"\033[{_code}m"

    for _name, _code in _COLORS.items():
        globals()[_name] = f"\033[{_code}m"
        globals()[f"BG_{_name}"] = f"\033[{_BG[_name]}m"

    for _style_name, _style_code in _STYLES.items():
        for _color_name, _color_code in _COLORS.items():
            globals()[f"{_style_name}_{_color_name}"] = (
                f"\033[{_style_code};{_color_code}m"
            )
            globals()[f"{_style_name}_BG_{_color_name}"] = (
                f"\033[{_style_code};{_BG[_color_name]}m"
            )

    # Convenience aliases for commonly used colors
    globals()["GRAY"] = globals()["BRIGHT_BLACK"]
    globals()["BG_GRAY"] = globals()["BG_BRIGHT_BLACK"]
    globals()["BOLD_GRAY"] = globals()["BOLD_BRIGHT_BLACK"]


_generate_colors()
