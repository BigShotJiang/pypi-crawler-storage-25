"""
color-kiss - ANSI color codes for terminal output formatting.

A lightweight library providing ANSI escape codes for terminal text styling.
Supports 16 colors, 8 text styles, background colors, and all combinations.

Usage:
    from color_kiss import RED, GREEN, RESET, BOLD_RED, ITALIC_BLUE
    from color_kiss.utils import styled, success, error

    print(f"{BOLD_RED}Error:{RESET} {error('Something went wrong')}")
    print(f"{ITALIC_BLUE}Processing...{RESET}")
"""

from .colors import *  # noqa: F401, F403
from .utils import error, info, styled, success, warning  # noqa: F401

__all__ = [
    # Reset
    "RESET",
    # Base styles
    "BOLD",
    "DIM",
    "ITALIC",
    "UNDERLINE",
    "BLINK",
    "REVERSE",
    "HIDDEN",
    "STRIKETHROUGH",
    # Base colors
    "BLACK",
    "RED",
    "GREEN",
    "YELLOW",
    "BLUE",
    "MAGENTA",
    "CYAN",
    "WHITE",
    # Bright colors
    "BRIGHT_BLACK",
    "BRIGHT_RED",
    "BRIGHT_GREEN",
    "BRIGHT_YELLOW",
    "BRIGHT_BLUE",
    "BRIGHT_MAGENTA",
    "BRIGHT_CYAN",
    "BRIGHT_WHITE",
    # Backgrounds
    "BG_BLACK",
    "BG_RED",
    "BG_GREEN",
    "BG_YELLOW",
    "BG_BLUE",
    "BG_MAGENTA",
    "BG_CYAN",
    "BG_WHITE",
    "BG_BRIGHT_BLACK",
    "BG_BRIGHT_RED",
    "BG_BRIGHT_GREEN",
    "BG_BRIGHT_YELLOW",
    "BG_BRIGHT_BLUE",
    "BG_BRIGHT_MAGENTA",
    "BG_BRIGHT_CYAN",
    "BG_BRIGHT_WHITE",
    # Aliases
    "GRAY",
    "BG_GRAY",
    "BOLD_GRAY",
    # Utilities
    "styled",
    "success",
    "error",
    "warning",
    "info",
]
