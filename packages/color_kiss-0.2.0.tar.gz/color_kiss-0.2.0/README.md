# color-kiss — A lightweight, zero-dependency ANSI color library for terminal output

[![Python](https://img.shields.io/badge/python-3.0+-blue.svg)](https://python.org)
[![PyPI](https://img.shields.io/pypi/v/color-kiss.svg)](https://pypi.org/project/color-kiss/)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Platform](https://img.shields.io/badge/platform-linux%20%7C%20macOS%20%7C%20windows-lightgrey)]()

No bloat, no dependencies — just ANSI escape codes and helper functions. Uses only Python's built-in string formatting.

## ✨ Features

- **Zero Dependencies** — Uses only Python standard library
- **Full ANSI Spectrum** — 8 regular + 8 bright foreground & background colors
- **Text Styles** — Bold, dim, italic, underline, blink, reverse, hidden, strikethrough
- **256+ Style Combinations** — Every style × color combination: `BOLD_RED`, `ITALIC_BLUE`, `UNDERLINE_BG_GREEN`, etc.
- **Severity Helpers** — `error()`, `success()`, `warning()`, `info()` with colored prefixes
- **Auto-reset Helper** — `styled()` applies styles and resets automatically
- **Convenience Aliases** — `GRAY`, `BG_GRAY`, `BOLD_GRAY` for readability

## 🚀 Quick Start

### Installation

```bash
pip install color-kiss        # pip
uv pip install color-kiss     # uv
pipx install color-kiss       # pipx
```

### Usage

```python
from color_kiss import BOLD, RED, GREEN, BOLD_RED, RESET
from color_kiss.utils import styled, error, success 

# Manual color codes
print(f"{BOLD_RED}Error:{RESET} Something went wrong")

# Auto-reset helper
print(styled("Hello, World!", BOLD, GREEN))

# Pre-combined styles (no need to list multiple codes)
print(f"{BOLD_RED}Critical error!{RESET}")
print(f"{ITALIC_BLUE}Processing...{RESET}")

# Severity helpers
print(error("File not found"))
print(success("Download complete"))
```

## 📋 Reference

### Text Styles

| Code | Effect |
|------|--------|
| `BOLD` | Bold text |
| `DIM` | Dim text |
| `ITALIC` | Italic text |
| `UNDERLINE` | Underlined text |
| `BLINK` | Blinking text |
| `REVERSE` | Swapped fg/bg |
| `HIDDEN` | Hidden text |
| `STRIKETHROUGH` | Strikethrough text |

### Foreground Colors

| Code | Preview |
|------|---------|
| `BLACK`, `RED`, `GREEN` | Regular colors |
| `YELLOW`, `BLUE`, `MAGENTA` | Regular colors |
| `CYAN`, `WHITE` | Regular colors |
| `BRIGHT_BLACK`–`BRIGHT_WHITE` | Bright colors |
| `GRAY` | → `BRIGHT_BLACK` |

### Background Colors

| Code | Preview |
|------|---------|
| `BG_BLACK`–`BG_WHITE` | Regular backgrounds |
| `BG_BRIGHT_BLACK`–`BG_BRIGHT_WHITE` | Bright backgrounds |
| `BG_GRAY` | → `BG_BRIGHT_BLACK` |

### Style × Color Combinations

| Code | Equivalent To |
|------|---------------|
| `BOLD_RED` | `\033[1;31m` |
| `ITALIC_BLUE` | `\033[3;34m` |
| `UNDERLINE_GREEN` | `\033[4;32m` |
| `BOLD_BG_YELLOW` | `\033[1;43m` |
| `DIM_BRIGHT_CYAN` | `\033[2;96m` |
| *... 256+ combinations* | *All style × color × bg* |

### Helper Functions

| Function | Description |
|----------|-------------|
| `styled(text, *styles)` | Apply styles to text, auto-append `RESET` |
| `error(text)` | `Error: {text}` in red |
| `success(text)` | `Success: {text}` in green |
| `warning(text)` | `Warning: {text}` in yellow |
| `info(text)` | `Info: {text}` in cyan |

### Severity Prefixes

| Prefix | Value |
|--------|-------|
| `ERROR_PREFIX` | `Error:` in red |
| `SUCCESS_PREFIX` | `Success:` in green |
| `WARNING_PREFIX` | `Warning:` in yellow |
| `INFO_PREFIX` | `Info:` in cyan |

## 📖 Examples

```python
from color_kiss import (
    BOLD, RED, GREEN, YELLOW, 
    BG_YELLOW, BLACK, RESET,
    BOLD_RED, ITALIC_BLUE, UNDERLINE_GREEN,
)
from color_kiss.utils import (
    error, success, warning,
    info, styled
)

# Status messages
print(error("Connection refused"))
print(success("Server started on port 8080"))
print(warning("Disk space low"))
print(info("Processing 42 files..."))

# Highlighted warnings
print(styled(" WARNING: Unsaved changes! ", BG_YELLOW, BLACK, BOLD))

# Using combined styles
print(f"{BOLD_RED}[FATAL]{RESET} System crash detected")
print(f"{UNDERLINE_GREEN}Task completed{RESET}")

# Logging with severity prefixes
def log(level, msg):
    prefixes = {
        "ERROR": ERROR_PREFIX,
        "WARN": WARNING_PREFIX,
        "INFO": INFO_PREFIX,
    }
    print(f"{prefixes.get(level, '')} {msg}{RESET}")
```

## 🔧 Requirements

Python 3.0+ — no external dependencies.

## ❓ FAQ

### Why another color library?

`color-kiss` is **zero bytes beyond Python's stdlib** — just string constants. Unlike `rich` (10+ deps) or `colorama` (Windows compat layer), it does one thing: ANSI escape codes.

### Why 256+ style combinations?

Instead of manually writing `BOLD + RED` every time, use `BOLD_RED` as a single constant. All combinations are auto-generated at import time — zero runtime overhead.

### Does this work on Windows?

Yes, on Windows Terminal, PowerShell 5.1+, ConEmu, and `cmd.exe` (Windows 10+). For legacy Windows, enable VT100 with `os.system('')`.

### What about 24-bit True Color?

Sticks to 16 standard ANSI colors (32 with backgrounds) supported by virtually all terminals. For 24-bit, use raw escapes: `\033[38;2;255;100;0m`.

## 📁 Project Structure

```
color-kiss/
├── color_kiss/
│   ├── __init__.py      # Public API imports
│   ├── colors.py        # ANSI constants & style×color combinations
│   └── utils.py         # Helpers: styled(), error(), success(), etc.
├── pyproject.toml
├── README.md
└── LICENSE
```

## 📄 License

MIT License — see [LICENSE](LICENSE) file.

---

**Author:** [Fkernel653](https://github.com/Fkernel653)
**Repository:** [github.com/Fkernel653/color-kiss](https://github.com/Fkernel653/color-kiss)
**PyPI:** [pypi.org/project/color-kiss](https://pypi.org/project/color-kiss/)
