"""Daemon server -- persistent Session hosting pools over Unix socket.

Architecture:
    Daemon event loop (main thread)     Session event loop (background thread)
    +-- Unix socket server              +-- ActorSystem
    +-- Client handlers                 +-- Pool actors
    +-- TTL timers                      +-- Node actors, SSH, workers

Task dispatch uses pool.run_async() which returns a concurrent.futures.Future,
then asyncio.wrap_future() converts it for the daemon's event loop. This avoids
deadlocking -- the daemon's loop never blocks on the Session's loop.
"""

from __future__ import annotations

import asyncio
import contextlib
import traceback as tb_module
import uuid
from pathlib import Path
from types import TracebackType
from typing import Any

import cloudpickle
from casty import ActorRef, ActorSystem, EventJournal, SqliteJournal

from skyward.observability.logger import logger

from .protocol import (
    BroadcastSucceeded,
    DaemonError,
    DaemonRequest,
    DaemonResponse,
    Disconnect,
    Disconnected,
    EnsurePool,
    GetNodeCount,
    GetPools,
    GetPoolView,
    NodeCount,
    Ping,
    Pong,
    PoolFailed,
    PoolReady,
    PoolShutdown,
    ShutdownPool,
    SubmitBroadcast,
    SubmitTask,
    SubscribeEvents,
    TaskFailed,
    TaskSucceeded,
)
from .wire import async_recv, async_send

log = logger.bind(component="daemon")

_DEFAULT_SOCKET = Path.home() / ".skyward" / "daemon.sock"
_STATE_DIR = Path.home() / ".skyward" / "state"


class DaemonServer:
    """Asyncio Unix socket server hosting a Skyward Session.

    The Session runs in a background thread (standard Skyward pattern).
    The socket server runs in its own event loop. Task dispatch bridges
    the two via run_async() + wrap_future().
    """

    def __init__(
        self,
        socket_path: Path = _DEFAULT_SOCKET,
        journal: EventJournal | None = None,
    ) -> None:
        self._socket_path = socket_path
        self._server: asyncio.Server | None = None
        self._pools: dict[str, Any] = {}  # name -> ComputePool (live references)
        self._ttl_tasks: dict[str, asyncio.Task[None]] = {}  # name -> TTL timer
        self._pool_ttls: dict[str, int] = {}  # name -> TTL seconds
        self._session: Any = None
        from skyward.api.projection import SessionProjection
        self._projection = SessionProjection()
        if journal is None:
            _STATE_DIR.mkdir(parents=True, exist_ok=True)
            journal = SqliteJournal(str(_STATE_DIR / "daemon.db"))
        self._journal = journal
        self._state_ref: ActorRef | None = None
        self._actor_system: ActorSystem | None = None
        self._stop: asyncio.Event | None = None

    async def __aenter__(self) -> DaemonServer:
        from .state import daemon_state_actor

        self._socket_path.parent.mkdir(parents=True, exist_ok=True)
        self._socket_path.unlink(missing_ok=True)

        self._actor_system = ActorSystem("daemon")
        await self._actor_system.__aenter__()
        self._state_ref = self._actor_system.spawn(
            daemon_state_actor("daemon-state", self._journal), "daemon-state",
        )

        await self._run_recovery()

        self._server = await asyncio.start_unix_server(
            self._handle_client, path=str(self._socket_path),
        )
        log.info("Daemon listening on {path}", path=self._socket_path)
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        if self._server is not None:
            self._server.close()
            await self._server.wait_closed()
        self._socket_path.unlink(missing_ok=True)
        for name in list(self._pools):
            await self._teardown_pool(name)
        if self._actor_system is not None:
            await self._actor_system.__aexit__(None, None, None)
            self._actor_system = None
            self._state_ref = None
        if self._session is not None:
            self._session.__exit__(None, None, None)
            self._session = None
        log.info("Daemon stopped")

    async def _handle_client(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        """Handle one client connection."""
        client_id = uuid.uuid4().hex[:12]
        connected_pools: set[str] = set()

        try:
            while True:
                try:
                    request = await async_recv(reader)
                except (asyncio.IncompleteReadError, ConnectionError, EOFError):
                    break

                response = await self._dispatch(request, client_id)  # type: ignore[arg-type]
                await async_send(writer, response)

                match request:
                    case EnsurePool(name=name):
                        connected_pools.add(name)
                    case Disconnect():
                        break
        except Exception as e:
            log.warning("Client {cid} handler error: {err}", cid=client_id, err=e)
        finally:
            for pool_name in connected_pools:
                await self._unregister_client(pool_name, client_id)
            writer.close()
            with contextlib.suppress(Exception):
                await writer.wait_closed()

    async def _dispatch(self, request: DaemonRequest, client_id: str) -> DaemonResponse:
        """Route a request to the appropriate handler."""
        try:
            match request:
                case Ping():
                    return Pong()

                case EnsurePool(name=name, project_dir=project_dir):
                    return await self._ensure_pool(name, project_dir, client_id)

                case SubmitTask(pool_name=name, payload=payload, timeout=timeout):
                    return await self._submit_task(name, payload, timeout)

                case SubmitBroadcast(pool_name=name, payload=payload, timeout=timeout):
                    return await self._submit_broadcast(name, payload, timeout)

                case GetNodeCount(pool_name=name):
                    return self._get_node_count(name)

                case Disconnect(pool_name=name):
                    await self._unregister_client(name, client_id)
                    return Disconnected()

                case ShutdownPool(pool_name=name):
                    return await self._shutdown_pool(name)

                case GetPools():
                    return self._get_pools()

                case GetPoolView(pool_name=name):
                    return self._get_pool_view(name)

                case SubscribeEvents():
                    return DaemonError(error="SubscribeEvents requires streaming (not yet implemented)")

                case _:
                    return DaemonError(error=f"Unknown request: {type(request).__name__}")

        except Exception as e:
            return DaemonError(error=str(e), traceback=tb_module.format_exc())

    # -- Pool provisioning -------------------------------------------------

    async def _ensure_pool(
        self, name: str, project_dir: str | None, client_id: str,
    ) -> PoolReady | PoolFailed:
        assert self._actor_system is not None and self._state_ref is not None
        if name in self._pools:
            pool = self._pools[name]
            await self._register_client(name, client_id)
            return PoolReady(pool_name=name, node_count=pool.current_nodes())

        try:
            pool = self._provision_pool(name, project_dir)
            self._pools[name] = pool

            from .state import RegisterPool

            instance_ids = tuple(
                ni.instance.id for ni in pool._instances.values()
            )
            await self._actor_system.ask(
                self._state_ref,
                lambda r: RegisterPool(
                    pool_name=name,
                    cluster_id=pool._cluster_id,
                    instance_ids=instance_ids,
                    project_dir=project_dir or str(Path.cwd()),
                    provider_name=pool._spec.provider or "",
                    cluster_bytes=cloudpickle.dumps(pool._cluster),
                    spec_bytes=cloudpickle.dumps(pool._spec),
                    provider_config_bytes=cloudpickle.dumps(
                        pool._specs[0].provider,
                    ),
                    reply_to=r,
                ),
                timeout=5.0,
            )
            self._start_ttl(name)
            await self._register_client(name, client_id)
            return PoolReady(pool_name=name, node_count=pool.current_nodes())
        except Exception as e:
            return PoolFailed(pool_name=name, reason=str(e))

    def _provision_pool(self, name: str, project_dir: str | None) -> Any:
        """Resolve config and provision a ComputePool via Session."""
        from skyward.config import resolve_pool_config

        resolution = resolve_pool_config(
            name, project_dir=Path(project_dir) if project_dir else None,
        )
        pool = resolution.pool

        if self._session is None:
            from skyward.core.session import Session
            self._session = Session(console=False, logging=True)
            self._session.__enter__()

        pool.__enter__()
        self._pool_ttls[name] = resolution.ttl
        return pool

    # -- Task dispatch (async, no deadlock) --------------------------------

    async def _submit_task(
        self, name: str, payload: bytes, timeout: float,
    ) -> TaskSucceeded | TaskFailed:
        if name not in self._pools:
            return TaskFailed(error=f"Pool '{name}' not found", traceback="")

        pool = self._pools[name]
        pending = cloudpickle.loads(payload)

        try:
            future = pool.run_async(pending)
            result = await asyncio.wrap_future(future)
            return TaskSucceeded(payload=cloudpickle.dumps(result))
        except Exception as e:
            return TaskFailed(error=str(e), traceback=tb_module.format_exc())

    async def _submit_broadcast(
        self, name: str, payload: bytes, timeout: float,
    ) -> BroadcastSucceeded | TaskFailed:
        if name not in self._pools:
            return TaskFailed(error=f"Pool '{name}' not found", traceback="")

        pool = self._pools[name]
        pending = cloudpickle.loads(payload)

        try:
            loop = asyncio.get_running_loop()
            results = await loop.run_in_executor(None, pool.broadcast, pending)
            return BroadcastSucceeded(payload=cloudpickle.dumps(results))
        except Exception as e:
            return TaskFailed(error=str(e), traceback=tb_module.format_exc())

    def _get_node_count(self, name: str) -> NodeCount | DaemonError:
        if name not in self._pools:
            return DaemonError(error=f"Pool '{name}' not found")
        return NodeCount(ready=self._pools[name].current_nodes())

    def _get_pools(self) -> DaemonResponse:
        from skyward.api.views import NodeStatus

        from .protocol import PoolList, PoolSummary

        summaries: list[PoolSummary] = []
        view = self._projection.view
        for name, pv in view.pools.items():
            ready = sum(1 for n in pv.nodes.values() if n.status.value >= NodeStatus.READY.value)
            summaries.append(PoolSummary(
                name=name, phase=pv.phase.name,
                nodes_ready=ready, nodes_total=pv.total_nodes,
                tasks_done=pv.tasks.done, tasks_running=pv.tasks.running,
                started_at=pv.started_at,
            ))
        return PoolList(pools=tuple(summaries))

    def _get_pool_view(self, name: str) -> DaemonResponse:
        from .protocol import PoolViewResponse

        view = self._projection.view
        if name not in view.pools:
            return DaemonError(error=f"Pool '{name}' not found")
        return PoolViewResponse(view=view.pools[name])

    async def _shutdown_pool(self, name: str) -> PoolShutdown | DaemonError:
        if name not in self._pools:
            return DaemonError(error=f"Pool '{name}' not found")
        await self._teardown_pool(name)
        return PoolShutdown()

    # -- Client tracking (via state actor) ---------------------------------

    async def _register_client(self, pool_name: str, client_id: str) -> None:
        assert self._actor_system is not None and self._state_ref is not None
        from .state import AddClient
        await self._actor_system.ask(
            self._state_ref,
            lambda r: AddClient(pool_name=pool_name, client_id=client_id, reply_to=r),
            timeout=5.0,
        )
        log.info("Client {cid} joined pool {pool}", cid=client_id, pool=pool_name)

    async def _unregister_client(self, pool_name: str, client_id: str) -> None:
        assert self._actor_system is not None and self._state_ref is not None
        from .state import RemoveClient
        await self._actor_system.ask(
            self._state_ref,
            lambda r: RemoveClient(pool_name=pool_name, client_id=client_id, reply_to=r),
            timeout=5.0,
        )
        log.info("Client {cid} left pool {pool}", cid=client_id, pool=pool_name)

    # -- TTL management (hard lifetime) ------------------------------------

    def _start_ttl(self, name: str) -> None:
        if name not in self._pools:
            return
        ttl = self._pool_ttls.get(name, 1200)
        self._cancel_ttl(name)
        self._ttl_tasks[name] = asyncio.create_task(self._ttl_expire(name, ttl))
        log.info("Pool {name} TTL started: {ttl}s", name=name, ttl=ttl)

    def _cancel_ttl(self, name: str) -> None:
        if task := self._ttl_tasks.pop(name, None):
            task.cancel()

    async def _ttl_expire(self, name: str, ttl: int) -> None:
        await asyncio.sleep(ttl)
        log.info("Pool {name} TTL expired, tearing down", name=name, ttl=ttl)
        self._ttl_tasks.pop(name, None)
        await self._teardown_pool(name)
        if not self._pools and self._stop is not None:
            self._stop.set()

    async def _teardown_pool(self, name: str) -> None:
        self._cancel_ttl(name)
        if pool := self._pools.pop(name, None):
            try:
                loop = asyncio.get_running_loop()
                await loop.run_in_executor(None, pool.__exit__, None, None, None)
            except Exception as e:
                log.warning("Error tearing down pool {name}: {err}", name=name, err=e)
        self._pool_ttls.pop(name, None)
        if self._actor_system is not None and self._state_ref is not None:
            from .state import RemovePool

            await self._actor_system.ask(
                self._state_ref,
                lambda r: RemovePool(pool_name=name, reply_to=r),
                timeout=5.0,
            )

    # -- Crash recovery -----------------------------------------------------

    async def _run_recovery(self) -> None:
        """Replay journal and attempt to reconnect pools from previous run."""
        assert self._actor_system is not None and self._state_ref is not None
        from .state import GetState

        state = await self._actor_system.ask(
            self._state_ref, lambda r: GetState(reply_to=r), timeout=5.0,
        )
        if not state.pools:
            return

        log.info("Recovery: found {n} pools in journal", n=len(state.pools))

        for name, entry in state.pools.items():
            try:
                recovered = await self._recover_pool(name, entry)
                if recovered:
                    log.info("Pool {name} recovered successfully", name=name)
                else:
                    log.warning("Pool {name} could not be recovered", name=name)
            except Exception as e:
                log.warning(
                    "Pool {name} recovery error: {err}", name=name, err=e,
                )

        from .state import RemoveClient

        state = await self._actor_system.ask(
            self._state_ref, lambda r: GetState(reply_to=r), timeout=5.0,
        )
        for name, entry in state.pools.items():
            for stale_cid in entry.clients:
                await self._actor_system.ask(
                    self._state_ref,
                    lambda r, c=stale_cid, n=name: RemoveClient(
                        pool_name=n, client_id=c, reply_to=r,
                    ),
                    timeout=5.0,
                )

    async def _recover_pool(self, name: str, entry: Any) -> bool:
        """Verify instances and reconnect a pool from journal state."""
        assert self._actor_system is not None and self._state_ref is not None

        if not entry.cluster_bytes or not entry.spec_bytes:
            log.info(
                "Pool {name}: no recovery data in journal (legacy entry), skipping",
                name=name,
            )
            return False

        try:
            cluster = cloudpickle.loads(entry.cluster_bytes)
            spec = cloudpickle.loads(entry.spec_bytes)
            provider_config = cloudpickle.loads(entry.provider_config_bytes)
        except Exception as e:
            log.warning(
                "Pool {name}: deserialization failed ({err}), skipping",
                name=name, err=e,
            )
            return False

        if not Path(cluster.ssh_key_path).exists():
            log.warning(
                "Pool {name}: SSH key missing at {path}, "
                "cannot reconnect -- terminating instances",
                name=name, path=cluster.ssh_key_path,
            )
            provider = await self._create_provider(provider_config)
            await self._terminate_and_cleanup(name, provider, cluster, entry.instance_ids)
            return False

        provider = await self._create_provider(provider_config)
        alive: list[Any] = []
        dead: list[str] = []

        for iid in entry.instance_ids:
            try:
                cluster, instance = await provider.get_instance(cluster, iid)
            except Exception as e:
                log.warning(
                    "Pool {name}: get_instance({iid}) failed: {err}",
                    name=name, iid=iid, err=e,
                )
                dead.append(iid)
                continue

            if instance is None or getattr(instance, "status", None) == "exited":
                dead.append(iid)
                log.info("Pool {name}: instance {iid} is gone", name=name, iid=iid)
            else:
                alive.append(instance)
                log.info(
                    "Pool {name}: instance {iid} alive (status={status})",
                    name=name, iid=iid, status=instance.status,
                )

        if len(alive) < spec.nodes.min:
            log.warning(
                "Pool {name}: only {alive}/{min} instances alive, "
                "terminating survivors",
                name=name, alive=len(alive), min=spec.nodes.min,
            )
            alive_ids = tuple(inst.id for inst in alive)
            await self._terminate_and_cleanup(name, provider, cluster, alive_ids)
            return False

        log.info(
            "Pool {name}: {alive}/{total} instances alive, recovering",
            name=name, alive=len(alive), total=len(entry.instance_ids),
        )

        pool = await self._recover_pool_via_session(
            name, spec, provider, cluster, tuple(alive),
        )
        self._pools[name] = pool
        self._pool_ttls[name] = spec.ttl

        if dead:
            from .state import RegisterPool

            alive_ids = tuple(inst.id for inst in alive)
            await self._actor_system.ask(
                self._state_ref,
                lambda r: RegisterPool(
                    pool_name=name,
                    cluster_id=cluster.id,
                    instance_ids=alive_ids,
                    project_dir=entry.project_dir,
                    provider_name=entry.provider_name,
                    cluster_bytes=cloudpickle.dumps(cluster),
                    spec_bytes=entry.spec_bytes,
                    provider_config_bytes=entry.provider_config_bytes,
                    reply_to=r,
                ),
                timeout=5.0,
            )

        self._start_ttl(name)
        return True

    async def _create_provider(self, provider_config: Any) -> Any:
        """Instantiate a provider from a persisted config."""
        return await provider_config.create_provider()

    async def _recover_pool_via_session(
        self,
        name: str,
        spec: Any,
        provider: Any,
        cluster: Any,
        instances: tuple[Any, ...],
    ) -> Any:
        """Bridge to Session to create a recovered ComputePool.

        Uses RecoverExistingPool instead of SpawnPool to skip
        prepare()/provision() and jump to node-spawning.
        """
        if self._session is None:
            from skyward.core.session import Session
            self._session = Session(console=False, logging=True)
            self._session.__enter__()

        return self._session.recover_pool(
            name=name, spec=spec, provider=provider,
            cluster=cluster, instances=instances,
        )

    async def _terminate_and_cleanup(
        self,
        name: str,
        provider: Any,
        cluster: Any,
        instance_ids: tuple[str, ...],
    ) -> None:
        """Terminate instances and remove pool from journal."""
        assert self._actor_system is not None and self._state_ref is not None
        from contextlib import suppress

        from .state import RemovePool

        if instance_ids:
            with suppress(Exception):
                await provider.terminate(cluster, instance_ids)
        with suppress(Exception):
            await provider.teardown(cluster)

        await self._actor_system.ask(
            self._state_ref,
            lambda r: RemovePool(pool_name=name, reply_to=r),
            timeout=5.0,
        )

    async def serve_forever(self) -> None:
        assert self._server is not None
        async with self._server:
            await self._server.serve_forever()
