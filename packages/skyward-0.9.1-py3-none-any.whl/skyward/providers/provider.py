from __future__ import annotations

from collections.abc import AsyncIterator, Sequence
from typing import TYPE_CHECKING, Protocol, Self, runtime_checkable

from skyward.core import Cluster, Instance, PoolSpec
from skyward.core.model import Offer

if TYPE_CHECKING:
    from skyward.storage import Storage


@runtime_checkable
class Provider[C, S](Protocol):
    """Interface for cloud provider operations.

    Every method that receives a Cluster returns an (optionally updated)
    Cluster, allowing the immutable context to evolve across the lifecycle.
    """

    name: str

    @classmethod
    async def create(cls, config: C) -> Self:
        """Create a new instance of the provider."""
        ...

    def offers(self) -> AsyncIterator[Offer]:
        """List all available offers from this provider.

        Yields the complete catalog — no filtering. Filtering is handled
        by the OfferRepository query layer.

        Yields
        ------
        Offer
            Available machine offers with pricing.
        """
        ...

    async def prepare(self, spec: PoolSpec, offer: Offer) -> Cluster[S]:
        """Provision cluster-level infrastructure.

        Sets up everything needed before instances can be launched:
        SSH key registration, VPC/security groups (AWS), overlay
        networks (VastAI), GPU type resolution, etc.

        Returns
        -------
        Cluster[S]
            Immutable cluster context for subsequent calls.
        """
        ...

    async def provision(
        self, cluster: Cluster[S], count: int,
    ) -> tuple[Cluster[S], Sequence[Instance]]:
        """Launch compute instances.

        Returns
        -------
        tuple[Cluster[S], Sequence[Instance]]
            Updated cluster and launched instances in "provisioning" state.
        """
        ...

    async def get_instance(
        self, cluster: Cluster[S], instance_id: str,
    ) -> tuple[Cluster[S], Instance | None]:
        """Query current state of an instance.

        Returns
        -------
        tuple[Cluster[S], Instance | None]
            Updated cluster and current instance status.
        """
        ...

    async def terminate(self, cluster: Cluster[S], instance_ids: tuple[str, ...]) -> Cluster[S]:
        """Terminate one or more instances."""
        ...

    async def teardown(self, cluster: Cluster[S]) -> Cluster[S]:
        """Clean up cluster-level resources."""
        ...


@runtime_checkable
class FilterableProvider[C, S](Provider[C, S], Protocol):
    """Provider that declares specific-JSON filters for catalog queries."""

    def offer_filters(self) -> dict[str, str]: ...


@runtime_checkable
class WarmableProvider[C, S](Provider[C, S], Protocol):
    async def save(self, cluster: Cluster[S]) -> Cluster[S]:
        """Save a prebaked image from the current cluster state."""
        ...


@runtime_checkable
class Mountable[S](Protocol):
    """Protocol for providers that support volume mounting."""

    async def storage(self, cluster: Cluster[S]) -> Storage: ...
