"""Cloud providers for Skyward.

Each provider implements the Provider[C, S] protocol:
- prepare → provisions cluster-level infrastructure
- provision → launches instances
- get_instance → polls instance status
- terminate → destroys instances
- teardown → cleans up cluster resources

Available providers:
- AWS: Amazon Web Services (EC2 Fleet, spot instances)
- GCP: Google Cloud Platform (Compute Engine, instance templates, bulk_insert)
- Hyperstack: GPU cloud (bare-metal, environment-scoped resources)
- JarvisLabs: Jarvis Labs GPU cloud (India/Europe, per-minute billing, SSH key auto-registration)
- RunPod: GPU cloud (pods, serverless endpoints)
- TensorDock: GPU marketplace (bare-metal VMs, per-second billing)
- VastAI: GPU marketplace (Docker containers, spot/bid pricing)
- Verda: GPU cloud (dedicated instances, spot pricing)

NOTE: Only config classes are imported at module level to avoid pulling in
SDK dependencies (aioboto3, google-cloud-compute, etc.).
"""

# Only import config classes - these have NO SDK dependencies
# This allows `import skyward as sky` without requiring provider SDKs
from .aws.config import AWS
from .container.config import Container
from .gcp.config import GCP
from .hyperstack.config import Hyperstack
from .jarvislabs.config import JarvisLabs
from .runpod.config import RunPod
from .scaleway.config import Scaleway
from .tensordock.config import TensorDock
from .vastai.config import VastAI
from .verda.config import Verda
from .vultr.config import Vultr

__all__ = [
    # Config classes only - handlers must be imported explicitly
    "AWS",
    "Container",
    "GCP",
    "Hyperstack",
    "JarvisLabs",
    "RunPod",
    "Scaleway",
    "TensorDock",
    "VastAI",
    "Verda",
    "Vultr",
]
