from __future__ import annotations

import json
import logging
from collections.abc import Callable
from pathlib import Path
from typing import Any

from rich.progress import BarColumn, Progress, SpinnerColumn, TextColumn, TimeElapsedColumn

from xrag.config.models import IndexingConfig, ProviderConfig
from xrag.config.settings import Settings, get_settings
from xrag.core.embedding.base import BaseEmbedding
from xrag.core.embedding.factory import build_embedding
from xrag.core.vector_store.base import BaseVectorStore
from xrag.core.vector_store.factory import build_vector_store
from xrag.models.result import IndexingResult
from xrag.pipelines.helpers import flatten_chunks

logger = logging.getLogger(__name__)

ProgressCallback = Callable[[str, int, int], None]
"""Optional progress hook: ``(stage_label, completed, total)`` per batch."""


def _is_parent(chunk: dict[str, Any]) -> bool:
    """Return True if a chunk has children — i.e. it's a parent section root.

    RAGFlow's upstream skips vectors for parents (`available_int=0`) and serves
    them only as context expansion for child hits. We mirror that by excluding
    parents from the embed + vector-store path; the parent metadata remains in
    the chunks.json artifact for callers that need it.
    """
    child_ids = chunk.get("child_chunk_ids")
    return isinstance(child_ids, list) and len(child_ids) > 0


_CONT_SUFFIXES = (" (cont.)", " (continued)")


def _strip_continuation_suffix(heading: str) -> str | None:
    """Return the base heading if ``heading`` ends with a continuation marker."""
    h = (heading or "").rstrip()
    for suffix in _CONT_SUFFIXES:
        if h.endswith(suffix):
            return h[: -len(suffix)].rstrip()
    return None


def _merge_continuation_sections(chunks: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Merge ``X (cont.)`` section parents back into the prior ``X`` parent.

    The parser splits sections at page boundaries and the chunker emits each
    half as its own section. The continuation half has the same logical
    heading suffixed by ``(cont.)`` or ``(continued)``. Here we re-parent the
    continuation's children to the original section and drop the duplicate
    parent so family-aware dedup and ranking treat them as one unit.
    """
    by_id = {c.get("chunk_id"): c for c in chunks if c.get("chunk_id")}
    seen_originals: dict[str, dict[str, Any]] = {}
    drop_ids: set[str] = set()

    for c in chunks:
        if c.get("chunk_type") != "section":
            continue
        heading = (c.get("heading_path") or [""])[-1] if c.get("heading_path") else ""
        base = _strip_continuation_suffix(heading)
        if base is not None and base in seen_originals:
            original = seen_originals[base]
            for child_id in c.get("child_chunk_ids") or []:
                child = by_id.get(child_id)
                if child is None:
                    continue
                child["parent_chunk_id"] = original["chunk_id"]
                original.setdefault("child_chunk_ids", []).append(child_id)
            drop_ids.add(c["chunk_id"])
        elif base is None:
            # Only register canonical (non-cont) sections as merge targets.
            seen_originals[heading] = c

    if not drop_ids:
        return chunks
    return [c for c in chunks if c.get("chunk_id") not in drop_ids]


def _is_indexable_leaf(chunk: dict[str, Any], cfg: IndexingConfig) -> bool:
    """Decide whether a chunk should reach the vector store.

    Two filters layered on top of ``flatten_chunks``:
      1. ``exclude_parents_from_index`` — skip parents (see ``_is_parent``).
      2. ``min_section_body_chars`` — skip section-type leaves whose body
         is shorter than the threshold. These are typically heading-only
         sections (``"10. TAXATION"``) or parser-misclassified cover-page
         lines (addresses, dates, registration numbers); their text is
         already in the heading_path of meaningful downstream chunks, so
         indexing them just pollutes top-k with near-empty points.
    """
    if cfg.exclude_parents_from_index and _is_parent(chunk):
        return False
    if cfg.min_section_body_chars > 0 and chunk.get("chunk_type") == "section":
        body = (chunk.get("content") or "").strip()
        if len(body) < cfg.min_section_body_chars:
            return False
    return True


def _build_embed_text(chunk: dict[str, Any]) -> str:
    """Build the string passed to the embedding model for one chunk.

    For **table** chunks (Option B from the table-summary discussion):
    embed = summary + questions + heading. Raw cells are kept off the
    embedding because the flat cell-join is semantically thin and the
    LLM still gets the structured table at prompt time. Falls back to
    ``content_with_weight`` / ``content`` if no enrichment ran.

    For **text** chunks: original RAGFlow-aligned policy.
    - Prefer ``question_kwd`` if present (auto-generated questions
      replace content for embedding).
    - Otherwise use ``content_with_weight`` if set (post-enrichment).
    - Otherwise use raw ``content``.

    Heading prepend was tested and REVERTED for text chunks: it diluted
    short chunks and hurt multi_hop faithfulness. The chunker's own
    ``content`` field already includes heading context where useful.
    """
    if chunk.get("chunk_type") == "table":
        summary = chunk.get("summary_kwd")
        questions = chunk.get("question_kwd")
        has_summary = isinstance(summary, str) and bool(summary.strip())
        has_questions = bool(questions)
        # Option B applies only when at least one enrichment lane has
        # output. Heading alone is not a useful embedding — it's a
        # complement, not a substitute. Bare tables (no enrichment) fall
        # through to the chunker-built wrapped content.
        if has_summary or has_questions:
            parts: list[str] = []
            if has_summary:
                parts.append(summary.strip())
            if has_questions:
                parts.append("Questions:\n" + "\n".join(questions))
            heading = chunk.get("heading_path")
            if heading:
                parts.append("Section: " + " > ".join(heading))
            return "\n\n".join(parts)
        return chunk.get("content_with_weight") or chunk.get("content", "")

    if chunk.get("question_kwd"):
        return "\n".join(chunk["question_kwd"])
    return chunk.get("content_with_weight") or chunk.get("content", "")


def run_indexing_pipeline(
    input_path: Path,
    embedding_config: ProviderConfig,
    vector_store_config: ProviderConfig,
    tenant_id: str = "default",
    indexing_config: IndexingConfig | None = None,
    settings: Settings | None = None,
    on_progress: ProgressCallback | None = None,
) -> IndexingResult:
    """Embed and index chunks into a vector store.

    Enrichment fields (``summary_kwd``, ``question_kwd`` etc.) are
    expected to already be present on chunks — they are produced by
    ``run_chunk_prepare_pipeline`` when ``enrichment.pipeline`` is set.
    Indexing reads them via ``_build_embed_text`` but does not generate
    them.

    Args:
        input_path: Path to chunks.json from a chunk prepare run.
        embedding_config: Embedding provider config.
        vector_store_config: Vector store provider config.
        tenant_id: Multi-tenant scope tag stamped on every chunk's
            payload. Retrieval filters on this; default ``"default"``
            for single-tenant setups.
        settings: Optional settings override. Defaults to
            ``get_settings()``. Backends pass per-tenant settings here
            instead of mutating the process-global instance.
        on_progress: Optional callback fired as ``(stage_label,
            completed, total)`` after each embed/store batch. When
            ``None``, a ``rich.Progress`` bar is rendered to stdout
            (the existing CLI behavior). When set, no rich rendering
            happens — the caller (e.g. an ingest orchestrator or a
            backend handler) is responsible for displaying progress.

    Returns:
        Structured indexing result.
    """
    payload = json.loads(input_path.read_text())
    chunks = flatten_chunks(payload)

    resolved_settings = settings or get_settings()
    cfg = indexing_config or IndexingConfig()

    # Step A: merge `(cont.)` sections back into the original section's
    # parent so logical sections split by page boundaries become one unit
    # before parent exclusion runs.
    if cfg.merge_continuation_sections:
        before = len(chunks)
        chunks = _merge_continuation_sections(chunks)
        merged_dropped = before - len(chunks)
        if merged_dropped:
            logger.info(
                "Merged %d (cont.) section parents into originals",
                merged_dropped,
            )

    # Step B: filter to indexable leaves (parents + tiny header sections out).
    chunks_for_vector = [c for c in chunks if _is_indexable_leaf(c, cfg)]
    skipped = len(chunks) - len(chunks_for_vector)
    if skipped:
        logger.info(
            "Excluding %d non-indexable chunks (parents + tiny headers): %d → %d",
            skipped,
            len(chunks),
            len(chunks_for_vector),
        )

    embedding = build_embedding(embedding_config)
    vector_store = build_vector_store(vector_store_config)

    # Tag each persisted chunk with the embedding model used, so a later
    # retrieval run can detect index/query model drift and refuse to serve
    # stale vectors. See MVP 3 Gap 2b.
    model_tag = str(embedding_config.options.get("model") or embedding_config.provider)
    for chunk in chunks_for_vector:
        chunk["embedding_model"] = model_tag
        chunk["tenant_id"] = tenant_id

    texts = [_build_embed_text(chunk) for chunk in chunks_for_vector]

    embed_batch_size = resolved_settings.embed_batch_size
    store_batch_size = resolved_settings.store_batch_size

    if on_progress is None:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("{task.completed}/{task.total}"),
            TimeElapsedColumn(),
        ) as progress:
            embed_task = progress.add_task("Embedding chunks", total=len(texts))
            store_task = progress.add_task("Storing chunks", total=len(chunks_for_vector))
            embeddings = _embed_in_batches(
                embedding,
                texts,
                embedding_config.options,
                embed_batch_size,
                lambda n: progress.update(embed_task, advance=n),
            )
            _store_in_batches(
                vector_store,
                chunks_for_vector,
                embeddings,
                vector_store_config.options,
                store_batch_size,
                lambda n: progress.update(store_task, advance=n),
            )
    else:
        embeddings = _embed_in_batches(
            embedding,
            texts,
            embedding_config.options,
            embed_batch_size,
            _make_callback_tick("embedding", len(texts), on_progress),
        )
        _store_in_batches(
            vector_store,
            chunks_for_vector,
            embeddings,
            vector_store_config.options,
            store_batch_size,
            _make_callback_tick("storing", len(chunks_for_vector), on_progress),
        )

    collection_name = vector_store_config.options.get("collection_name", "default")

    return IndexingResult(
        input_path=str(input_path),
        chunk_count=len(chunks_for_vector),
        embedding_provider=embedding_config.provider,
        vector_store_provider=vector_store_config.provider,
        collection_name=collection_name,
    )


def _embed_in_batches(
    embedding: BaseEmbedding,
    texts: list[str],
    options: dict[str, Any],
    batch_size: int,
    tick: Callable[[int], None],
) -> list[list[float]]:
    """Embed texts in batches, calling ``tick(batch_count)`` after each batch."""
    all_embeddings: list[list[float]] = []
    for i in range(0, len(texts), batch_size):
        batch = texts[i : i + batch_size]
        batch_embeddings = embedding.embed_texts(batch, options)
        all_embeddings.extend(batch_embeddings)
        tick(len(batch))
    return all_embeddings


def _store_in_batches(
    vector_store: BaseVectorStore,
    chunks: list[dict[str, Any]],
    embeddings: list[list[float]],
    options: dict[str, Any],
    batch_size: int,
    tick: Callable[[int], None],
) -> None:
    """Store chunks in batches, calling ``tick(batch_count)`` after each batch."""
    for i in range(0, len(chunks), batch_size):
        batch_chunks = chunks[i : i + batch_size]
        batch_embeddings = embeddings[i : i + batch_size]
        vector_store.add_chunks(batch_chunks, batch_embeddings, options)
        tick(len(batch_chunks))


def _make_callback_tick(
    stage_label: str,
    total: int,
    on_progress: ProgressCallback,
) -> Callable[[int], None]:
    """Build a per-batch tick that funnels into a ``(stage, completed, total)`` callback."""
    state = {"completed": 0}

    def tick(batch_count: int) -> None:
        state["completed"] += batch_count
        on_progress(stage_label, state["completed"], total)

    return tick
