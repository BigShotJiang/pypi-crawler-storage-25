from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from xrag.config.models import AppConfig, ProviderConfig, RetrievalConfig
from xrag.core.embedding.factory import build_embedding
from xrag.core.generation.factory import build_generator
from xrag.core.reranker.factory import build_reranker
from xrag.core.retrieval.factory import build_retriever
from xrag.core.tracing.factory import build_tracer
from xrag.core.vector_store.factory import build_vector_store
from xrag.models.result import RagQueryResult
from xrag.pipelines.helpers import run_retrieval

logger = logging.getLogger(__name__)


def _apply_pipeline_filter(retrieval_config: RetrievalConfig, config: AppConfig) -> None:
    """Merge ``tenant_id`` (always) and ``doc_ids`` (optional) into the
    retriever's ``options.filter`` dict.

    Caller-supplied filter keys win — this only fills in payload fields
    the run config asserted, so ad-hoc overrides via YAML still work.
    """
    pipeline = config.pipeline
    existing = dict(retrieval_config.options.get("filter") or {})
    existing.setdefault("tenant_id", pipeline.tenant_id)
    if pipeline.doc_ids and "doc_id" not in existing:
        existing["doc_id"] = list(pipeline.doc_ids)
    retrieval_config.options["filter"] = existing


def run_rag(
    query: str,
    config: AppConfig,
) -> RagQueryResult:
    """Run a single RAG query: retrieve context and generate an answer.

    Args:
        query: The user question.
        config: Application config with embedding, vector_store, retrieval,
            and generation sections populated.

    Returns:
        Structured RAG query result.
    """
    if config.embedding is None:
        raise ValueError(
            "config.embedding is required: must match the model used at index time. "
            "Silently defaulting would risk drifting against the indexed vectors."
        )
    embedding_config = config.embedding
    vs_config = config.vector_store or ProviderConfig(provider="chroma", options={})
    retrieval_config = config.retrieval or RetrievalConfig(provider="simple", options={"top_k": 5})
    generation_config = config.generation or ProviderConfig(
        provider="openai", options={"model": "gpt-4.1-nano"}
    )

    _apply_pipeline_filter(retrieval_config, config)

    tracer = build_tracer(config.tracing)
    tracer.setup()

    embedding = build_embedding(embedding_config)
    vector_store = build_vector_store(vs_config)
    retriever = build_retriever(retrieval_config, embedding, vector_store)
    rr_cfg = retrieval_config.effective_reranker
    reranker = build_reranker(rr_cfg) if rr_cfg else None
    generator = build_generator(generation_config, callbacks=tracer.get_callbacks())

    retrieved = run_retrieval(retriever, reranker, query, retrieval_config)
    logger.info("Retrieved %d chunks for query", len(retrieved))

    result = generator.generate(query, retrieved, generation_config.options)
    tracer.shutdown()

    return RagQueryResult(
        query=query,
        answer=result["answer"],
        model=result["model"],
        retrieved_chunks=len(retrieved),
        context_chunk_ids=result.get("context_chunk_ids", []),
    )


def run_rag_batch(
    input_path: Path,
    output_path: Path,
    config: AppConfig,
) -> list[RagQueryResult]:
    """Run RAG queries in batch from a JSONL file.

    Args:
        input_path: Path to a JSONL file with ``question`` fields.
        output_path: Path to write results JSONL.
        config: Application config.

    Returns:
        List of RAG query results.
    """
    if config.embedding is None:
        raise ValueError(
            "config.embedding is required: must match the model used at index time. "
            "Silently defaulting would risk drifting against the indexed vectors."
        )
    embedding_config = config.embedding
    vs_config = config.vector_store or ProviderConfig(provider="chroma", options={})
    retrieval_config = config.retrieval or RetrievalConfig(provider="simple", options={"top_k": 5})
    generation_config = config.generation or ProviderConfig(
        provider="openai", options={"model": "gpt-4.1-nano"}
    )

    tracer = build_tracer(config.tracing)
    tracer.setup()

    _apply_pipeline_filter(retrieval_config, config)

    embedding = build_embedding(embedding_config)
    vector_store = build_vector_store(vs_config)
    retriever = build_retriever(retrieval_config, embedding, vector_store)
    rr_cfg = retrieval_config.effective_reranker
    reranker = build_reranker(rr_cfg) if rr_cfg else None
    generator = build_generator(generation_config, callbacks=tracer.get_callbacks())

    results: list[RagQueryResult] = []
    rows: list[dict[str, Any]] = []
    with input_path.open() as fh:
        for line in fh:
            rows.append(json.loads(line))

    with output_path.open("w") as out:
        for row in rows:
            query = row.get("question", row.get("query", ""))
            retrieved = run_retrieval(retriever, reranker, query, retrieval_config)
            gen_result = generator.generate(query, retrieved, generation_config.options)
            result = RagQueryResult(
                query=query,
                answer=gen_result["answer"],
                model=gen_result["model"],
                retrieved_chunks=len(retrieved),
                context_chunk_ids=gen_result.get("context_chunk_ids", []),
            )
            results.append(result)
            out.write(json.dumps(result.model_dump(mode="json")) + "\n")

    tracer.shutdown()
    logger.info("Processed %d queries, results written to %s", len(results), output_path)
    return results
