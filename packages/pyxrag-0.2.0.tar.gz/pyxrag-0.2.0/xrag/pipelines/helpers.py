from __future__ import annotations

from pathlib import Path
from typing import Any

from langsmith import traceable

from xrag.config.models import AppConfig, RetrievalConfig
from xrag.core.common.ids import new_run_id
from xrag.core.reranker.base import BaseReranker
from xrag.core.retrieval.base import BaseRetriever
from xrag.core.retrieval.dedup import dedup_by_family

DEFAULT_RERANKER_CANDIDATES = 30
DEFAULT_TOP_K = 5
# When dedup_family is on, over-fetch by this factor so dedup has candidates
# to drop into the final top_k slot without silently shrinking the result.
DEDUP_OVERFETCH = 2


def resolve_output_dir(config: AppConfig, output_dir: Path | None) -> tuple[str, Path]:
    """Resolve the artifact output directory for a run.

    Args:
        config: Application config.
        output_dir: Optional explicit output directory override.

    Returns:
        Tuple of run id and resolved output directory path.
    """
    if output_dir is not None:
        output_dir.mkdir(parents=True, exist_ok=True)
        run_id = output_dir.name
        return run_id, output_dir

    run_id = new_run_id(prefix=config.pipeline.name)
    resolved = config.pipeline.artifact_dir / run_id
    resolved.mkdir(parents=True, exist_ok=True)
    return run_id, resolved


def flatten_chunks(payload: Any) -> list[dict[str, Any]]:
    """Flatten a chunks.json payload into a single list of chunk dicts.

    Args:
        payload: Either a list of chunks or a doc_id-to-chunks mapping.

    Returns:
        A flat list of chunk dicts.
    """
    if isinstance(payload, list):
        return payload
    if isinstance(payload, dict):
        chunks: list[dict[str, Any]] = []
        for doc_chunks in payload.values():
            if isinstance(doc_chunks, list):
                chunks.extend(doc_chunks)
        return chunks
    raise ValueError("chunks.json must be a list of chunks or a doc_id-to-chunks mapping")


def resolve_retrieve_top_k(
    retrieval_config: RetrievalConfig,
) -> tuple[int, int]:
    """Resolve the retriever and final top_k for a (possibly reranked) retrieval stage.

    Args:
        retrieval_config: Retrieval config, optionally carrying a nested
            reranker block.

    Returns:
        Tuple of ``(retrieve_top_k, final_top_k)``. Without a reranker both
        equal ``options.top_k``. With a reranker, ``retrieve_top_k`` pulls
        the reranker's ``candidates`` (default 30) and ``final_top_k``
        trims to ``reranker.options.top_k`` or ``options.top_k``.
    """
    base_top_k = int(retrieval_config.options.get("top_k", DEFAULT_TOP_K))
    rr_cfg = retrieval_config.effective_reranker
    if rr_cfg is None:
        return base_top_k, base_top_k
    rr_opts = rr_cfg.options
    candidates = int(rr_opts.get("candidates", DEFAULT_RERANKER_CANDIDATES))
    final = int(rr_opts.get("top_k", base_top_k))
    return candidates, final


def count_context_chars(chunks: list[dict[str, Any]]) -> tuple[int, int]:
    """Sum and mean of ``len(chunk["content"])`` over the retrieved set.

    Tokenizer-free proxy for prompt size in eval reporting; stable across
    model swaps. ``(0, 0)`` for an empty list; ``mean`` is rounded.

    Args:
        chunks: Retrieved chunks; each is expected to carry ``content``.

    Returns:
        ``(total_chars, mean_chars_per_chunk)``.
    """
    if not chunks:
        return 0, 0
    per = [len(chunk.get("content", "") or "") for chunk in chunks]
    return sum(per), round(sum(per) / len(per))


@traceable(name="retrieve", run_type="retriever")
def _traced_retrieve(
    retriever: BaseRetriever, query: str, options: dict[str, Any]
) -> list[dict[str, Any]]:
    return retriever.retrieve(query, options)


@traceable(name="rerank")
def _traced_rerank(
    reranker: BaseReranker,
    query: str,
    chunks: list[dict[str, Any]],
    options: dict[str, Any],
) -> list[dict[str, Any]]:
    return reranker.rerank(query, chunks, options)


@traceable(name="retrieval")
def run_retrieval(
    retriever: BaseRetriever,
    reranker: BaseReranker | None,
    query: str,
    retrieval_config: RetrievalConfig,
) -> list[dict[str, Any]]:
    """Run retrieve + optional family dedup + optional rerank.

    When ``retrieval.options.dedup_family`` is true, the post-RRF
    candidate set has parent/child near-duplicates removed before the
    reranker sees them (or before we return in the no-reranker path).
    See ``docs/sub-plans/retrieval-quality-fixes.md`` F5.

    When ``reranker`` is None this is equivalent to ``retriever.retrieve()``
    with the user's configured options. When a reranker is present the
    retriever is asked for ``candidates`` chunks and the reranker trims to
    the final ``top_k``.
    """
    retrieve_top_k, final_top_k = resolve_retrieve_top_k(retrieval_config)
    dedup_family = bool(retrieval_config.options.get("dedup_family", False))

    if reranker is None:
        if not dedup_family:
            return _traced_retrieve(retriever, query, retrieval_config.options)
        # Over-fetch so dedup does not silently shrink the result set.
        retrieve_opts = {
            **retrieval_config.options,
            "top_k": retrieve_top_k * DEDUP_OVERFETCH,
        }
        candidates = _traced_retrieve(retriever, query, retrieve_opts)
        return dedup_by_family(candidates, top_k=retrieve_top_k)

    retrieve_opts = {**retrieval_config.options, "top_k": retrieve_top_k}
    chunks = _traced_retrieve(retriever, query, retrieve_opts)
    if dedup_family:
        chunks = dedup_by_family(chunks, top_k=retrieve_top_k)
    return _traced_rerank(reranker, query, chunks, {"top_k": final_top_k})
