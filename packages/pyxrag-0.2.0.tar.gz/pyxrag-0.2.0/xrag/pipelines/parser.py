from __future__ import annotations

import shutil
from pathlib import Path

from xrag.config.models import AppConfig
from xrag.core.artifact_store.factory import build_artifact_store
from xrag.core.common.telemetry import Telemetry
from xrag.core.parser.factory import build_parser
from xrag.models.manifest import Manifest
from xrag.models.result import PipelineResult
from xrag.pipelines.helpers import resolve_output_dir


def run_parser_pipeline(
    config: AppConfig,
    config_path: Path,
    output_dir: Path | None = None,
) -> PipelineResult:
    """Run the parser pipeline and persist parser artifacts.

    Args:
        config: Parsed application config.
        config_path: Path to the config file used for the run.
        output_dir: Optional explicit output directory override.

    Returns:
        Structured pipeline result for CLI output.
    """
    run_id, resolved_output_dir = resolve_output_dir(config, output_dir)
    _cleanup_parser_output_dir(resolved_output_dir)
    telemetry, started_counter = Telemetry.start()

    parser = build_parser(config.parser)
    artifact_store = build_artifact_store(config.artifact_store, resolved_output_dir)

    parse_bundle = parser.run(config.sources, config.parser.options)

    parser_output_path = artifact_store.save_parser_output(parse_bundle.raw_outputs)

    telemetry.finish(started_counter)
    telemetry_path = artifact_store.save_telemetry(telemetry.to_dict())

    manifest = Manifest(
        run_id=run_id,
        command="parser",
        config_path=str(config_path),
        output_dir=str(resolved_output_dir),
        parser_provider=config.parser.provider,
        parser_output_format="unstructured_raw",
        source_count=len(config.sources),
        status="completed",
        files={
            "parser_output": str(parser_output_path),
            "telemetry": str(telemetry_path),
        },
    )
    manifest_path = artifact_store.save_manifest(manifest)

    return PipelineResult(
        run_id=run_id,
        output_dir=str(resolved_output_dir),
        manifest_path=str(manifest_path),
        raw_outputs_path=str(parser_output_path),
        telemetry_path=str(telemetry_path),
    )


def _cleanup_parser_output_dir(output_dir: Path) -> None:
    """Remove stale parser-incompatible artifacts from the output directory.

    Args:
        output_dir: Output directory for the current parser run.
    """
    stale_paths = [
        output_dir / "chunks",
        output_dir / "raw_provider_output",
        output_dir / "parsed" / "documents.json",
    ]
    for stale_path in stale_paths:
        if stale_path.is_dir():
            shutil.rmtree(stale_path)
        elif stale_path.is_file():
            stale_path.unlink()
