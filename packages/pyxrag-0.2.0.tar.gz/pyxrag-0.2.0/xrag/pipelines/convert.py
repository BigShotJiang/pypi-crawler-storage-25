from __future__ import annotations

from pathlib import Path

from xrag.core.convert.factory import build_converter


def run_convert_pipeline(
    source_format: str,
    target_format: str,
    input_path: Path,
    output_path: Path,
) -> Path:
    """Run the file conversion pipeline.

    Args:
        source_format: Source file format such as `docx`.
        target_format: Target file format such as `pdf`.
        input_path: Source file path.
        output_path: Destination file path.

    Returns:
        Path to the converted output file.
    """
    converter = build_converter(source_format=source_format, target_format=target_format)
    return converter.run(input_path=input_path, output_path=output_path)
