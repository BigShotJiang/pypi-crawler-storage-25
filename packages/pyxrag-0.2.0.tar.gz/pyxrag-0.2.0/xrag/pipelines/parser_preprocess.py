from __future__ import annotations

import json
import re
from collections import Counter
from pathlib import Path
from typing import Any

from bs4 import BeautifulSoup

from xrag.config.models import PreprocessConfig
from xrag.config.settings import get_settings
from xrag.models.result import PreprocessResult, PreprocessWarning

# `unstructured` ships in the default xrag install, but imports stay inside the
# pipeline so retrieve-only consumers do not pay the import cost on module load.

_UNICODE_REPLACEMENTS = {
    "\u00a0": " ",
    "\u2018": "'",
    "\u2019": "'",
    "\u201c": '"',
    "\u201d": '"',
    "\u2013": "-",
    "\u2014": "-",
}
_CURRENCY_TOKENS = {"$", "US$", "USD"}


def run_parser_preprocess_pipeline(
    input_path: Path,
    output_dir: Path | None = None,
    config: PreprocessConfig | None = None,
) -> PreprocessResult:
    """Normalize saved parser output into lighter-weight review artifacts.

    Args:
        input_path: Path to raw Unstructured parser output JSON.
        output_dir: Optional explicit output directory for normalized artifacts.

    Returns:
        Structured preprocessing result.
    """
    payload = json.loads(input_path.read_text())
    doc_id, element_dicts = _load_single_document_payload(payload)
    preprocess_config = config or PreprocessConfig()
    normalized_elements, warnings = _normalize_elements(
        doc_id=doc_id,
        elements=element_dicts,
        config=preprocess_config,
    )
    resolved_output_dir = _resolve_output_dir(input_path=input_path, output_dir=output_dir)
    resolved_output_dir.mkdir(parents=True, exist_ok=True)

    normalized_payload: list[dict[str, Any]] | dict[str, list[dict[str, Any]]]
    if doc_id is None:
        normalized_payload = normalized_elements
    else:
        normalized_payload = {doc_id: normalized_elements}

    normalized_elements_path = resolved_output_dir / "elements.json"
    normalized_elements_path.write_text(json.dumps(normalized_payload, indent=2))

    from unstructured.partition.html.convert import elements_to_html
    from unstructured.staging.base import elements_from_dicts

    review_html_path = resolved_output_dir / "review.html"
    elements = elements_from_dicts(normalized_elements)
    html = elements_to_html(elements, no_group_by_page=_should_disable_page_grouping(elements))
    review_html_path.write_text(html, encoding="utf-8")

    return PreprocessResult(
        input_path=str(input_path),
        output_dir=str(resolved_output_dir),
        normalized_elements_path=str(normalized_elements_path),
        review_html_path=str(review_html_path),
        warning_count=len(warnings),
        warnings=warnings,
    )


def _load_single_document_payload(
    payload: Any,
) -> tuple[str | None, list[dict[str, Any]]]:
    """Load a single document payload from saved raw parser output."""
    if isinstance(payload, list):
        return None, payload
    if isinstance(payload, dict) and all(isinstance(value, list) for value in payload.values()):
        if len(payload) != 1:
            raise ValueError(
                "parser preprocess requires a single-document payload or a single doc_id selection"
            )
        doc_id = next(iter(payload))
        return doc_id, payload[doc_id]
    raise ValueError("parser preprocess input must be a list of elements or a single-doc mapping")


def _resolve_output_dir(input_path: Path, output_dir: Path | None) -> Path:
    """Resolve the output directory for normalized parser artifacts."""
    if output_dir is not None:
        return output_dir
    return input_path.parent.parent / "normalized"


def _normalize_elements(
    doc_id: str | None,
    elements: list[dict[str, Any]],
    config: PreprocessConfig,
) -> tuple[list[dict[str, Any]], list[PreprocessWarning]]:
    """Apply v1 normalization rules to serialized elements."""
    warnings: list[PreprocessWarning] = []
    working = [json.loads(json.dumps(element)) for element in elements]

    if config.steps.normalize_unicode:
        _normalize_unicode_fields(working)

    removed_decorative_ids: list[str] = []
    if config.steps.drop_decorative_elements:
        removed_decorative_ids = _drop_decorative_elements(working)
    if removed_decorative_ids:
        warnings.append(
            PreprocessWarning(
                code="removed_decorative_elements",
                message="Removed decorative or empty standalone elements.",
                count=len(removed_decorative_ids),
                element_ids=removed_decorative_ids,
            )
        )

    reclassified_ids: list[str] = []
    if config.steps.reclassify_bold_headings:
        reclassified_ids = _reclassify_bold_headings(working)
    if reclassified_ids:
        warnings.append(
            PreprocessWarning(
                code="reclassified_bold_headings",
                message="Reclassified bold short UncategorizedText elements as Title.",
                count=len(reclassified_ids),
                element_ids=reclassified_ids,
            )
        )

    stripped_image_ids: list[str] = []
    if config.steps.strip_image_base64:
        stripped_image_ids = _strip_image_base64(working)
    if stripped_image_ids:
        warnings.append(
            PreprocessWarning(
                code="stripped_image_base64",
                message="Removed image_base64 payloads from image metadata.",
                count=len(stripped_image_ids),
                element_ids=stripped_image_ids,
            )
        )

    removed_boilerplate_ids: list[str] = []
    if config.steps.deduplicate_boilerplate:
        removed_boilerplate_ids = _deduplicate_boilerplate(working)
    if removed_boilerplate_ids:
        warnings.append(
            PreprocessWarning(
                code="removed_boilerplate",
                message="Removed repeated boilerplate header or footer elements.",
                count=len(removed_boilerplate_ids),
                element_ids=removed_boilerplate_ids,
            )
        )

    table_warning_counts = _normalize_tables(working, config=config)
    if table_warning_counts["table_cell_normalization_applied"]:
        warnings.append(
            PreprocessWarning(
                code="table_cell_normalization_applied",
                message="Applied table cleanup for review HTML and normalized table text.",
                count=table_warning_counts["table_cell_normalization_applied"],
            )
        )
    if table_warning_counts["malformed_table_numeric_value"]:
        warnings.append(
            PreprocessWarning(
                code="malformed_table_numeric_value",
                message="Detected malformed numeric values while normalizing tables.",
                count=table_warning_counts["malformed_table_numeric_value"],
            )
        )

    stripped_source_ids: list[str] = []
    if config.steps.strip_local_data_source:
        stripped_source_ids = _normalize_data_source(working, doc_id=doc_id)
    if stripped_source_ids:
        warnings.append(
            PreprocessWarning(
                code="stripped_local_data_source",
                message="Removed local ETL-only data_source metadata.",
                count=len(stripped_source_ids),
                element_ids=stripped_source_ids,
            )
        )

    if config.steps.warn_missing_page_numbers and any(
        (element.get("metadata") or {}).get("page_number") is None for element in working
    ):
        warnings.append(
            PreprocessWarning(
                code="missing_page_numbers",
                message="Some or all elements do not include page_number metadata.",
                count=sum(
                    1
                    for element in working
                    if (element.get("metadata") or {}).get("page_number") is None
                ),
            )
        )

    filename = _first_filename(working)
    if (
        config.steps.warn_missing_comments_metadata
        and filename
        and "with-comments" in filename.lower()
        and not _has_comments_metadata(working)
    ):
        warnings.append(
            PreprocessWarning(
                code="missing_comments_metadata",
                message=(
                    "Input filename suggests comments are expected, but no comments "
                    "metadata was extracted."
                ),
                count=1,
            )
        )

    return working, warnings


def _normalize_unicode_fields(elements: list[dict[str, Any]]) -> None:
    """Normalize unicode punctuation and spacing in element text fields."""
    for element in elements:
        if isinstance(element.get("text"), str):
            element["text"] = _normalize_text(element["text"])
        metadata = element.get("metadata") or {}
        for key, value in list(metadata.items()):
            if isinstance(value, str):
                metadata[key] = _normalize_text(value)
            elif isinstance(value, list):
                metadata[key] = [
                    _normalize_text(item) if isinstance(item, str) else item for item in value
                ]
            elif isinstance(value, dict):
                metadata[key] = _normalize_nested_strings(value)
        element["metadata"] = metadata


def _normalize_nested_strings(value: dict[str, Any]) -> dict[str, Any]:
    """Recursively normalize string values in nested dictionaries."""
    normalized: dict[str, Any] = {}
    for key, item in value.items():
        if isinstance(item, str):
            normalized[key] = _normalize_text(item)
        elif isinstance(item, dict):
            normalized[key] = _normalize_nested_strings(item)
        elif isinstance(item, list):
            normalized[key] = [
                _normalize_text(entry) if isinstance(entry, str) else entry for entry in item
            ]
        else:
            normalized[key] = item
    return normalized


def _normalize_text(value: str) -> str:
    """Normalize unicode punctuation and whitespace."""
    for source, target in _UNICODE_REPLACEMENTS.items():
        value = value.replace(source, target)
    value = re.sub(r"[ \t]+", " ", value)
    value = re.sub(r" *\n *", "\n", value)
    return value.strip()


def _drop_decorative_elements(elements: list[dict[str, Any]]) -> list[str]:
    """Remove decorative or empty elements."""
    removed_ids: list[str] = []
    kept: list[dict[str, Any]] = []
    for element in elements:
        text = (element.get("text") or "").strip()
        if not text or _is_decorative_text(text):
            removed_ids.append(str(element.get("element_id", "")))
            continue
        kept.append(element)
    elements[:] = kept
    return removed_ids


def _is_decorative_text(text: str) -> bool:
    """Return True when text is decorative noise."""
    if re.fullmatch(r"[_\-\.\s]{3,}", text):
        return True
    if text.lower() in {"note:", "notes:"}:
        return True
    return False


def _reclassify_bold_headings(elements: list[dict[str, Any]]) -> list[str]:
    """Convert heading-like bold UncategorizedText elements into Title."""
    settings = get_settings()
    reclassified_ids: list[str] = []
    for element in elements:
        metadata = element.get("metadata") or {}
        if element.get("type") != "UncategorizedText":
            continue
        tags = metadata.get("emphasized_text_tags") or []
        text = (element.get("text") or "").strip()
        if "b" not in tags:
            continue
        if metadata.get("category_depth") != 0:
            continue
        if not _looks_like_heading(text, max_chars=settings.heading_max_chars):
            continue
        element["type"] = "Title"
        reclassified_ids.append(str(element.get("element_id", "")))
    return reclassified_ids


def _looks_like_heading(text: str, max_chars: int = 120) -> bool:
    """Return True when normalized text looks like a heading."""
    if not text or len(text) > max_chars:
        return False
    if _is_decorative_text(text):
        return False
    alpha_count = sum(char.isalpha() for char in text)
    digit_count = sum(char.isdigit() for char in text)
    if alpha_count == 0 or digit_count > alpha_count:
        return False
    return text.count(".") <= 2


def _strip_image_base64(elements: list[dict[str, Any]]) -> list[str]:
    """Remove heavy image_base64 payloads from metadata."""
    stripped_ids: list[str] = []
    for element in elements:
        metadata = element.get("metadata") or {}
        if metadata.pop("image_base64", None) is not None:
            stripped_ids.append(str(element.get("element_id", "")))
    return stripped_ids


def _deduplicate_boilerplate(elements: list[dict[str, Any]]) -> list[str]:
    """Remove repeated boilerplate headers or footers."""
    settings = get_settings()
    bp_max = settings.boilerplate_max_chars
    normalized_texts = [
        (element.get("element_id"), _normalize_text(element.get("text") or ""))
        for element in elements
        if _is_boilerplate_candidate(element, max_chars=bp_max)
    ]
    counts = Counter(text for _, text in normalized_texts if text)
    repeated = {text for text, count in counts.items() if count >= 3}

    removed_ids: list[str] = []
    kept: list[dict[str, Any]] = []
    for element in elements:
        text = _normalize_text(element.get("text") or "")
        if text in repeated and _is_boilerplate_candidate(element, max_chars=bp_max):
            removed_ids.append(str(element.get("element_id", "")))
            continue
        kept.append(element)
    elements[:] = kept
    return removed_ids


def _is_boilerplate_candidate(element: dict[str, Any], max_chars: int = 80) -> bool:
    """Return True when an element looks like recurring page boilerplate."""
    text = _normalize_text(element.get("text") or "")
    if not text or len(text) > max_chars:
        return False
    if element.get("type") == "Table":
        return False
    return text.upper() == text or bool(re.fullmatch(r"[A-Z0-9 .,&()'-]+", text))


def _normalize_tables(
    elements: list[dict[str, Any]],
    config: PreprocessConfig,
) -> dict[str, int]:
    """Normalize table HTML for display and table text for retrieval."""
    warning_counts = {
        "table_cell_normalization_applied": 0,
        "malformed_table_numeric_value": 0,
    }
    if not config.steps.normalize_tables:
        return warning_counts

    for element in elements:
        if element.get("type") != "Table":
            continue
        metadata = element.get("metadata") or {}
        html = metadata.get("text_as_html")
        if not html:
            continue
        matrix = _parse_table_html(html)
        if not matrix:
            continue
        cleaned_matrix = _clean_table_matrix(matrix, config=config)
        metadata["text_as_html"] = _matrix_to_html(cleaned_matrix)
        element["text"] = _matrix_to_text(cleaned_matrix)
        element["metadata"] = metadata
        warning_counts["table_cell_normalization_applied"] += 1
        warning_counts["malformed_table_numeric_value"] += _count_malformed_numeric_values(
            cleaned_matrix
        )
    return warning_counts


def _parse_table_html(html: str) -> list[list[str]]:
    """Parse table HTML into a matrix of normalized strings."""
    soup = BeautifulSoup(html, "html.parser")
    matrix: list[list[str]] = []
    for tr in soup.find_all("tr"):
        row = [
            _normalize_text(cell.get_text(" ", strip=True)) for cell in tr.find_all(["td", "th"])
        ]
        if row:
            matrix.append(row)
    return matrix


def _clean_table_matrix(
    matrix: list[list[str]],
    config: PreprocessConfig,
) -> list[list[str]]:
    """Clean table matrix for display and retrieval."""
    rows = [row[:] for row in matrix]
    rows = [row for row in rows if any(cell for cell in row)]
    if config.steps.merge_table_currency_cells:
        rows = [_merge_currency_cells(row) for row in rows]
    if config.steps.merge_table_orphan_suffix_cells:
        rows = [_merge_orphan_suffix_cells(row) for row in rows]
    rows = [_blank_duplicate_adjacent_cells(row) for row in rows]
    if config.steps.merge_table_columns:
        rows = _collapse_header_only_spacer_columns(rows)
    rows = _drop_empty_columns(rows)
    rows = [row for row in rows if any(cell for cell in row)]
    return rows


def _merge_currency_cells(row: list[str]) -> list[str]:
    """Merge accounting-style currency cells with the following numeric cell."""
    merged = row[:]
    for index, value in enumerate(row[:-1]):
        next_value = merged[index + 1]
        if value in _CURRENCY_TOKENS and next_value and next_value not in _CURRENCY_TOKENS:
            merged[index + 1] = f"{value}{next_value}"
            merged[index] = ""
    return merged


def _blank_duplicate_adjacent_cells(row: list[str]) -> list[str]:
    """Blank duplicate adjacent cells so column cleanup can collapse them."""
    deduped = row[:]
    for index in range(1, len(deduped)):
        if deduped[index] and deduped[index] == deduped[index - 1]:
            deduped[index] = ""
    return deduped


def _merge_orphan_suffix_cells(row: list[str]) -> list[str]:
    """Merge punctuation-only suffix cells back into the previous value cell."""
    merged = row[:]
    for index in range(1, len(merged)):
        value = merged[index]
        previous = merged[index - 1]
        if not value or not previous:
            continue
        if not re.fullmatch(r"[\)\]%]+", value):
            continue
        merged[index - 1] = f"{previous}{value}"
        merged[index] = ""
    return merged


def _drop_empty_columns(rows: list[list[str]]) -> list[list[str]]:
    """Drop columns that are empty across all rows."""
    if not rows:
        return rows
    max_width = max(len(row) for row in rows)
    padded = [row + [""] * (max_width - len(row)) for row in rows]
    keep_indexes = [index for index in range(max_width) if any(row[index] for row in padded)]
    return [[row[index] for index in keep_indexes] for row in padded]


def _collapse_header_only_spacer_columns(rows: list[list[str]]) -> list[list[str]]:
    """Move header-only labels onto neighboring data columns and drop sparse spacers.

    This handles extracted financial tables where year headers occupy their own
    sparse column while the actual values sit one column to the right.
    """
    if not rows:
        return rows

    max_width = max(len(row) for row in rows)
    padded = [row + [""] * (max_width - len(row)) for row in rows]
    header_rows = 1

    for index in range(1, max_width - 1):
        header_values = [padded[row_index][index] for row_index in range(header_rows)]
        body_values = [padded[row_index][index] for row_index in range(header_rows, len(padded))]
        next_body_values = [
            padded[row_index][index + 1] for row_index in range(header_rows, len(padded))
        ]

        if not any(header_values):
            continue
        if any(body_values):
            continue
        if not any(next_body_values):
            continue

        for row_index in range(header_rows):
            if padded[row_index][index] and not padded[row_index][index + 1]:
                padded[row_index][index + 1] = padded[row_index][index]
                padded[row_index][index] = ""

    return padded


def _matrix_to_html(rows: list[list[str]]) -> str:
    """Serialize cleaned table matrix back to compact HTML."""
    html_rows: list[str] = []
    for row in rows:
        cells = "".join(f"<td>{_escape_html(cell)}</td>" for cell in row)
        html_rows.append(f"<tr>{cells}</tr>")
    return f"<table>{''.join(html_rows)}</table>"


def _matrix_to_text(rows: list[list[str]]) -> str:
    """Convert cleaned table matrix into readable text."""
    lines: list[str] = []
    for row in rows:
        values = [cell for cell in row if cell]
        if values:
            lines.append(" | ".join(values))
    return "\n".join(lines)


def _escape_html(value: str) -> str:
    """Escape a string for safe inclusion in HTML."""
    return (
        value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")
    )


def _count_malformed_numeric_values(rows: list[list[str]]) -> int:
    """Count likely malformed numeric tokens after table cleanup."""
    malformed = 0
    for row in rows:
        for cell in row:
            if re.fullmatch(r"\(?-?\d{1,3}(,\d{2})+\)?", cell):
                malformed += 1
    return malformed


def _normalize_data_source(elements: list[dict[str, Any]], doc_id: str | None) -> list[str]:
    """Strip ETL-local data_source metadata that is not user-facing."""
    stripped_ids: list[str] = []
    for element in elements:
        metadata = element.get("metadata") or {}
        data_source = metadata.get("data_source")
        if not isinstance(data_source, dict):
            continue
        url = data_source.get("url")
        if isinstance(url, str) and url.startswith("file:///home/etl/"):
            metadata.pop("data_source", None)
            if doc_id is not None:
                metadata["source_doc_id"] = doc_id
            stripped_ids.append(str(element.get("element_id", "")))
    return stripped_ids


def _first_filename(elements: list[dict[str, Any]]) -> str | None:
    """Return the first available filename in element metadata."""
    for element in elements:
        filename = (element.get("metadata") or {}).get("filename")
        if isinstance(filename, str):
            return filename
    return None


def _has_comments_metadata(elements: list[dict[str, Any]]) -> bool:
    """Return True when any element metadata appears to contain extracted comments."""
    for element in elements:
        metadata = element.get("metadata") or {}
        if any("comment" in key.lower() for key in metadata):
            return True
    return False


def _should_disable_page_grouping(elements: list) -> bool:
    """Return True when any element lacks page_number metadata."""
    return any(getattr(element.metadata, "page_number", None) is None for element in elements)
