"""End-to-end ingestion: parser → preprocess → chunk → index in one call.

Composed over the existing per-stage pipelines. The CLI shim and any
backend handler share this single entry point — no subprocess execution,
no stdout parsing.

Stages can be selectively skipped via ``config.pipeline.stages``;
skipped stages must have their output already on disk in the supplied
``output_dir`` (the canonical "resume from a prior run" pattern).

See ``docs/sub-plans/ingest-module-plan.md``.
"""

from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import Any

from xrag.config.models import IngestStage
from xrag.config.settings import get_settings
from xrag.core.vector_store.factory import build_vector_store
from xrag.models.ingest import (
    IngestEvent,
    IngestRequest,
    IngestResult,
    ProgressTick,
    SourceCompleted,
    SourceError,
    SourceFailed,
    SourceStarted,
    StageCompleted,
    StageStarted,
)
from xrag.models.result import PreprocessResult
from xrag.pipelines.chunk_prepare import run_chunk_prepare_pipeline
from xrag.pipelines.helpers import resolve_output_dir
from xrag.pipelines.indexing import run_indexing_pipeline
from xrag.pipelines.parser import run_parser_pipeline
from xrag.pipelines.parser_preprocess import run_parser_preprocess_pipeline

logger = logging.getLogger(__name__)

_STAGE_ORDER: tuple[IngestStage, ...] = ("parser", "preprocess", "chunk", "index")


def run_ingest(req: IngestRequest) -> IngestResult:
    """Run the configured ingestion stages end-to-end and return a structured result.

    Stages run in canonical order (``parser → preprocess → chunk →
    index``); ``config.pipeline.stages`` chooses which ones execute.
    Skipped stages are loaded from the conventional path under
    ``output_dir``:

    - ``parser`` skipped → reads ``{output_dir}/parsed/unstructured_elements.json``
    - ``preprocess`` skipped → reads ``{output_dir}/normalized/elements.json``
    - ``chunk`` skipped → reads ``{output_dir}/chunked/chunks.json``
    - ``index`` skipped → no downstream consumer; just not run

    Args:
        req: Inputs (config, optional output_dir, tenant override,
            settings override, ``on_event`` callback, strict mode).

    Returns:
        Per-stage results — populated for stages that ran, ``None`` for
        skipped ones. ``collection_name`` is ``None`` when ``index`` is
        skipped.

    Raises:
        ValueError: Required config sections missing for the active
            stages, or empty stages list.
        FileNotFoundError: A skipped stage's prior artifact is missing,
            or a declared source file does not exist when ``parser`` is
            active.
        Per-stage exceptions when ``req.strict=True`` and a per-source
            preprocess step fails.
    """
    config = req.config
    settings = req.settings or get_settings()

    if req.tenant_id is not None:
        config.pipeline.tenant_id = req.tenant_id

    active = _normalize_active_stages(config.pipeline.stages)
    _validate_for_active_stages(config, active, req.output_dir)

    run_id, run_dir = resolve_output_dir(config, req.output_dir)

    parser_result = None
    preprocess_results: dict[str, PreprocessResult] = {}
    errors: list[SourceError] = []
    chunk_result = None
    indexing_result = None

    # --- Stage 1: parser -----------------------------------------------
    if "parser" in active:
        _emit(req, StageStarted(stage="parser", run_id=run_id))
        started = time.perf_counter()
        parser_result = run_parser_pipeline(
            config=config,
            config_path=req.config_path or Path("<programmatic>"),
            output_dir=run_dir,
        )
        _emit(
            req,
            StageCompleted(
                stage="parser",
                run_id=run_id,
                elapsed_seconds=time.perf_counter() - started,
            ),
        )
        parsed_payload_path = Path(parser_result.raw_outputs_path)
    else:
        parsed_payload_path = run_dir / "parsed" / "unstructured_elements.json"
        if "preprocess" in active:
            _require_artifact(parsed_payload_path, skipped="parser", needed_by="preprocess")

    # --- Stage 2: per-doc preprocess -----------------------------------
    combined_elements_path = run_dir / "normalized" / "elements.json"

    if "preprocess" in active:
        _emit(req, StageStarted(stage="preprocess", run_id=run_id))
        started = time.perf_counter()

        parsed_payload = json.loads(parsed_payload_path.read_text())
        if not isinstance(parsed_payload, dict):
            raise ValueError(
                "parser raw_outputs must be a doc_id-keyed mapping; "
                f"got {type(parsed_payload).__name__}"
            )

        normalized_payload: dict[str, list[dict[str, Any]]] = {}
        for doc_id, elements in parsed_payload.items():
            _emit(req, SourceStarted(stage="preprocess", doc_id=doc_id))
            try:
                doc_dir = run_dir / "preprocess" / doc_id
                doc_dir.mkdir(parents=True, exist_ok=True)
                doc_input_path = doc_dir / "_input.json"
                doc_input_path.write_text(json.dumps({doc_id: elements}))

                preprocess_result = run_parser_preprocess_pipeline(
                    input_path=doc_input_path,
                    output_dir=doc_dir,
                    config=config.preprocess,
                )
                preprocess_results[doc_id] = preprocess_result
                normalized_payload[doc_id] = _read_normalized_elements(
                    preprocess_result.normalized_elements_path,
                    doc_id=doc_id,
                )
                _emit(req, SourceCompleted(stage="preprocess", doc_id=doc_id))
            except Exception as exc:
                if req.strict:
                    raise
                errors.append(SourceError(doc_id=doc_id, stage="preprocess", error=str(exc)))
                _emit(
                    req,
                    SourceFailed(stage="preprocess", doc_id=doc_id, error=str(exc)),
                )

        if not normalized_payload:
            raise ValueError("preprocess produced no normalized documents")

        combined_elements_path.parent.mkdir(parents=True, exist_ok=True)
        combined_elements_path.write_text(json.dumps(normalized_payload, indent=2))

        _emit(
            req,
            StageCompleted(
                stage="preprocess",
                run_id=run_id,
                elapsed_seconds=time.perf_counter() - started,
            ),
        )
    elif "chunk" in active:
        _require_artifact(combined_elements_path, skipped="preprocess", needed_by="chunk")

    # --- Stage 3: chunk prepare ----------------------------------------
    chunked_path = run_dir / "chunked" / "chunks.json"

    if "chunk" in active:
        _emit(req, StageStarted(stage="chunk", run_id=run_id))
        started = time.perf_counter()
        chunk_result = run_chunk_prepare_pipeline(
            input_path=combined_elements_path,
            output_dir=run_dir / "chunked",
            config=config.chunker,
            enrichment_config=config.enrichment,
        )
        chunked_path = Path(chunk_result.chunks_path)
        _emit(
            req,
            StageCompleted(
                stage="chunk",
                run_id=run_id,
                elapsed_seconds=time.perf_counter() - started,
            ),
        )
    elif "index" in active:
        _require_artifact(chunked_path, skipped="chunk", needed_by="index")

    # --- Stage 4: indexing ---------------------------------------------
    if "index" in active:
        if req.reset_collection:
            collection_name = (
                config.vector_store.options.get("collection_name", "default")
                if config.vector_store
                else "default"
            )
            logger.info(
                "reset_collection=True: dropping vector-store collection %r before index",
                collection_name,
            )
            store = build_vector_store(config.vector_store)
            try:
                store.delete_collection()
            finally:
                store.close()

        _emit(req, StageStarted(stage="index", run_id=run_id))
        started = time.perf_counter()
        indexing_result = run_indexing_pipeline(
            input_path=chunked_path,
            embedding_config=config.embedding,
            vector_store_config=config.vector_store,
            tenant_id=config.pipeline.tenant_id,
            indexing_config=config.indexing,
            settings=settings,
            on_progress=_build_progress_adapter(req),
        )
        _emit(
            req,
            StageCompleted(
                stage="index",
                run_id=run_id,
                elapsed_seconds=time.perf_counter() - started,
            ),
        )

    return IngestResult(
        run_id=run_id,
        output_dir=str(run_dir),
        stages_run=list(active),
        parser=parser_result,
        preprocess=preprocess_results,
        chunk=chunk_result,
        indexing=indexing_result,
        errors=errors,
        collection_name=indexing_result.collection_name if indexing_result else None,
    )


def _normalize_active_stages(stages: list[IngestStage]) -> list[IngestStage]:
    """Return stages in canonical order, deduplicated. Empty list is rejected."""
    if not stages:
        raise ValueError("pipeline.stages must list at least one stage")
    requested = set(stages)
    return [s for s in _STAGE_ORDER if s in requested]


def _validate_for_active_stages(config, active: list[IngestStage], output_dir: Path | None) -> None:
    """Validate config completeness based on which stages will run.

    Sources are required only when ``parser`` is active. ``embedding``
    and ``vector_store`` are required only when ``index`` is active.
    ``output_dir`` is required when any active stage's input must be
    loaded from a prior run (i.e. a stage is skipped that the next
    active stage depends on).
    """
    if "parser" in active:
        if not config.sources:
            raise ValueError("at least one source is required when 'parser' is in pipeline.stages")
        for source in config.sources:
            if not source.path.exists():
                raise FileNotFoundError(f"source file not found: {source.path}")

    if "index" in active:
        if config.embedding is None:
            raise ValueError(
                "config must include an 'embedding' section when 'index' is in pipeline.stages"
            )
        if config.vector_store is None:
            raise ValueError(
                "config must include a 'vector_store' section when 'index' is in pipeline.stages"
            )

    needs_prior_artifact = (
        ("preprocess" in active and "parser" not in active)
        or ("chunk" in active and "preprocess" not in active)
        or ("index" in active and "chunk" not in active)
    )
    if needs_prior_artifact and output_dir is None:
        raise ValueError(
            "output_dir is required when an active stage's input comes "
            "from a skipped predecessor. Point it at a prior run directory."
        )


def _require_artifact(path: Path, *, skipped: str, needed_by: str) -> None:
    """Fail with a clear message when a skipped stage's output is missing."""
    if not path.exists():
        raise FileNotFoundError(
            f"{skipped} stage skipped but {path} not found — "
            f"{needed_by} needs it. Re-run with {skipped!r} in pipeline.stages "
            f"or point output_dir at a run directory containing the artifact."
        )


def _emit(req: IngestRequest, event: IngestEvent) -> None:
    """Forward an event to ``req.on_event`` if set."""
    if req.on_event is not None:
        req.on_event(event)


def _build_progress_adapter(req: IngestRequest):
    """Translate batch ticks into ``ProgressTick`` events on ``req.on_event``."""
    if req.on_event is None:
        return None
    callback = req.on_event

    def adapter(stage_label: str, completed: int, total: int) -> None:
        callback(ProgressTick(stage=stage_label, completed=completed, total=total))

    return adapter


def _read_normalized_elements(path: str, doc_id: str) -> list[dict[str, Any]]:
    """Read a per-doc preprocess output and return the flat element list.

    parser_preprocess writes ``[..]`` for an unscoped doc and
    ``{doc_id: [..]}`` for a scoped one. We always pass scoped input,
    so we expect the dict form, but we accept the list form for safety.
    """
    payload = json.loads(Path(path).read_text())
    if isinstance(payload, list):
        return payload
    if isinstance(payload, dict):
        if doc_id in payload:
            return payload[doc_id]
        if len(payload) == 1:
            return next(iter(payload.values()))
    raise ValueError(f"unexpected normalized payload shape at {path}: {type(payload).__name__}")
