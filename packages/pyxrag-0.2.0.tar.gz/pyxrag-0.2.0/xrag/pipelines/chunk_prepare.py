from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from xrag.config.models import EnrichmentConfig, ProviderConfig
from xrag.core.chunker.factory import build_chunker
from xrag.core.enrichment.pipeline import run_enrichment_pipeline
from xrag.models.result import ChunkPrepareResult


def run_chunk_prepare_pipeline(
    input_path: Path,
    output_dir: Path | None = None,
    config: ProviderConfig | None = None,
    enrichment_config: EnrichmentConfig | None = None,
) -> ChunkPrepareResult:
    """Build structured retrieval chunks from normalized parser elements.

    When ``enrichment_config.pipeline`` is non-empty the configured
    enrichers (e.g. ``table_summary``, ``auto_questions``) run after
    chunking so the persisted ``chunks.json`` already carries the
    LLM-derived fields. Indexing then becomes a pure embed + upsert.

    Args:
        input_path: Path to normalized elements JSON.
        output_dir: Optional explicit output directory for chunk artifacts.
        config: Optional chunker provider config.
        enrichment_config: Optional ordered enrichment config. Empty
            pipeline (default) is a no-op.

    Returns:
        Structured chunk preparation result.
    """
    payload = json.loads(input_path.read_text())
    documents = _load_documents(payload)
    resolved_output_dir = _resolve_output_dir(input_path=input_path, output_dir=output_dir)
    resolved_output_dir.mkdir(parents=True, exist_ok=True)
    chunker_config = config or ProviderConfig(provider="section_table", options={})
    chunker = build_chunker(chunker_config)

    enrichment_steps: list[str] = []
    run_enrichment = enrichment_config is not None and bool(enrichment_config.pipeline)

    output_payload: dict[str, list[dict[str, Any]]] | list[dict[str, Any]]
    if len(documents) == 1 and documents[0][0] is None:
        chunks = chunker.run(
            doc_id=None,
            elements=documents[0][1],
            options=chunker_config.options,
        )
        if run_enrichment:
            chunks = run_enrichment_pipeline(chunks, enrichment_config)
        output_payload = chunks
        chunk_count = len(chunks)
    else:
        output_payload = {}
        chunk_count = 0
        for doc_id, elements in documents:
            chunks = chunker.run(doc_id=doc_id, elements=elements, options=chunker_config.options)
            if run_enrichment:
                chunks = run_enrichment_pipeline(chunks, enrichment_config)
            output_payload[doc_id or "document"] = chunks
            chunk_count += len(chunks)

    if run_enrichment:
        enrichment_steps = list(enrichment_config.pipeline)

    chunks_path = resolved_output_dir / "chunks.json"
    chunks_path.write_text(json.dumps(output_payload, indent=2))

    return ChunkPrepareResult(
        input_path=str(input_path),
        output_dir=str(resolved_output_dir),
        chunks_path=str(chunks_path),
        document_count=len(documents),
        chunk_count=chunk_count,
        chunker_provider=chunker_config.provider,
        enrichment_steps=enrichment_steps,
    )


def _load_documents(payload: Any) -> list[tuple[str | None, list[dict[str, Any]]]]:
    """Load one or more normalized documents from JSON payload."""
    if isinstance(payload, list):
        return [(None, payload)]
    if isinstance(payload, dict) and all(isinstance(value, list) for value in payload.values()):
        return [(str(doc_id), elements) for doc_id, elements in payload.items()]
    raise ValueError(
        "chunk prepare input must be a list of elements or a doc_id-to-elements mapping"
    )


def _resolve_output_dir(input_path: Path, output_dir: Path | None) -> Path:
    """Resolve the output directory for chunk artifacts."""
    if output_dir is not None:
        return output_dir
    return input_path.parent.parent / "chunked"
