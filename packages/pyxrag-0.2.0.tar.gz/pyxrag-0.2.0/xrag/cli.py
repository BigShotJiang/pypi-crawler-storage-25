from __future__ import annotations

import json
import logging
import sys
from datetime import datetime
from pathlib import Path
from typing import Annotated

import typer

from tools.eval_dataset.review import (
    generate_dataset_review_html,
    load_chunks_index,
    load_dataset,
)
from tools.evaluation.preview import generate_eval_preview_html, load_run
from tools.pipelines.chunk_eda import render_report, run_chunk_eda
from tools.pipelines.dataset_peek import peek_datasets
from tools.pipelines.eval_create_dataset import run_eval_create_dataset_pipeline
from tools.pipelines.eval_run import run_eval_pipeline
from tools.pipelines.parser_review import run_parser_review_pipeline
from tools.pipelines.rag_baseline import run_baseline_rag
from tools.review.chunker_review import generate_chunk_review_html, load_chunks
from xrag.config.loader import (
    load_chunker_config,
    load_config,
    load_dataset_generation_config,
    load_enrichment_config,
    load_preprocess_config,
    load_rag_config,
)
from xrag.config.models import ProviderConfig
from xrag.config.validator import validate_config
from xrag.core.common.logging import setup_logging
from xrag.core.vector_store.factory import build_vector_store
from xrag.models.ingest import IngestRequest
from xrag.pipelines.chunk_prepare import run_chunk_prepare_pipeline
from xrag.pipelines.convert import run_convert_pipeline
from xrag.pipelines.indexing import run_indexing_pipeline
from xrag.pipelines.ingest import run_ingest
from xrag.pipelines.parser import run_parser_pipeline
from xrag.pipelines.parser_preprocess import run_parser_preprocess_pipeline
from xrag.pipelines.rag_query import run_rag, run_rag_batch

app = typer.Typer(help="Config-driven RAG CLI")
eval_app = typer.Typer(help="Evaluation workflows")
dataset_app = typer.Typer(help="Dataset exploration workflows")
chunk_app = typer.Typer(help="Chunk preparation workflows")
rag_app = typer.Typer(help="RAG workflows")
parser_app = typer.Typer(
    help="Parser workflows",
    invoke_without_command=True,
    no_args_is_help=False,
)
app.add_typer(eval_app, name="eval")
app.add_typer(dataset_app, name="dataset")
app.add_typer(chunk_app, name="chunk")
app.add_typer(rag_app, name="rag")
app.add_typer(parser_app, name="parser")


@app.callback()
def _root_callback(
    ctx: typer.Context,
    log_file: Annotated[
        Path | None,
        typer.Option(
            "--log-file",
            file_okay=True,
            dir_okay=False,
            help="Path to write the run log. Defaults to logs/<timestamp>-<command>.log.",
        ),
    ] = None,
    no_log_file: Annotated[
        bool,
        typer.Option(
            "--no-log-file",
            help="Disable file logging for this run (stderr logging is unaffected).",
        ),
    ] = False,
) -> None:
    """Set up logging for every CLI invocation."""
    if ctx.resilient_parsing or ctx.invoked_subcommand is None:
        return

    if no_log_file:
        setup_logging(None)
        return

    if log_file is None:
        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        log_file = Path("logs") / f"{timestamp}-{ctx.invoked_subcommand}.log"

    setup_logging(log_file)
    logger = logging.getLogger("rag-cli")
    logger.info("command: %s", " ".join(sys.argv))
    logger.info("log_file: %s", log_file)


@app.command("convert")
def convert_command(
    source: Annotated[str, typer.Option(..., help="Source format, for example `docx`.")],
    target: Annotated[str, typer.Option(..., help="Target format, for example `pdf`.")],
    input_path: Annotated[
        Path,
        typer.Option("--input", exists=True, dir_okay=False, help="Input file path."),
    ],
    output_path: Annotated[
        Path,
        typer.Option("--output", dir_okay=False, help="Output file path."),
    ],
) -> None:
    """Convert one file from a source format to a target format.

    Args:
        source: Source file format.
        target: Target file format.
        input_path: Input file path.
        output_path: Output file path.
    """
    converted_path = run_convert_pipeline(
        source_format=source,
        target_format=target,
        input_path=input_path,
        output_path=output_path,
    )
    typer.echo(json.dumps({"output_path": str(converted_path)}))


@parser_app.callback()
def parser_command(
    ctx: typer.Context,
    config: Annotated[
        Path | None,
        typer.Option(exists=True, dir_okay=False, help="Path to a YAML config file"),
    ] = None,
    output_dir: Annotated[
        Path | None,
        typer.Option(
            file_okay=False,
            help="Optional output directory override. If set, parser artifacts are written here.",
        ),
    ] = None,
    pretty: Annotated[bool, typer.Option(help="Pretty-print the pipeline result JSON.")] = False,
) -> None:
    """Run the parser pipeline from a YAML config.

    Args:
        config: Path to the runtime YAML config.
        output_dir: Optional explicit artifact directory for this run.
        pretty: Whether to pretty-print the JSON result.
    """
    if ctx.invoked_subcommand is not None:
        return
    if config is None:
        raise typer.BadParameter("Missing option '--config'.")
    parsed_config = load_config(config)
    validate_config(parsed_config, command="parser")
    result = run_parser_pipeline(
        config=parsed_config,
        config_path=config,
        output_dir=output_dir,
    )
    if pretty:
        typer.echo(json.dumps(result.model_dump(mode="json"), indent=2))
    else:
        typer.echo(json.dumps(result.model_dump(mode="json")))


@parser_app.command("review")
def parser_review_command(
    input_path: Annotated[
        Path,
        typer.Option(
            "--input",
            exists=True,
            dir_okay=False,
            help="Path to saved Unstructured JSON parser output.",
        ),
    ],
    output_format: Annotated[
        str,
        typer.Option(help="Review output format. Supported by Unstructured: html, markdown, text."),
    ] = "html",
    output_path: Annotated[
        Path | None,
        typer.Option("--output", dir_okay=False, help="Optional rendered output file path."),
    ] = None,
) -> None:
    """Render saved parser output into a reviewable document format.

    Args:
        input_path: Path to saved Unstructured parser output JSON.
        output_format: Requested review output format.
        output_path: Optional explicit destination path.
    """
    result = run_parser_review_pipeline(
        input_path=input_path,
        output_format=output_format,
        output_path=output_path,
    )
    typer.echo(json.dumps(result.model_dump(mode="json")))


@parser_app.command("preprocess")
def parser_preprocess_command(
    input_path: Annotated[
        Path,
        typer.Option(
            "--input",
            exists=True,
            dir_okay=False,
            help="Path to saved Unstructured JSON parser output.",
        ),
    ],
    output_dir: Annotated[
        Path | None,
        typer.Option(
            "--output-dir",
            file_okay=False,
            help="Optional output directory for normalized parser artifacts.",
        ),
    ] = None,
    config: Annotated[
        Path | None,
        typer.Option(
            "--config",
            exists=True,
            dir_okay=False,
            help="Optional YAML config for preprocess step toggles.",
        ),
    ] = None,
) -> None:
    """Normalize saved parser output into lighter-weight artifacts.

    Args:
        input_path: Path to saved Unstructured parser output JSON.
        output_dir: Optional explicit output directory for normalized artifacts.
        config: Optional preprocess YAML config path.
    """
    preprocess_config = load_preprocess_config(config) if config is not None else None
    result = run_parser_preprocess_pipeline(
        input_path=input_path,
        output_dir=output_dir,
        config=preprocess_config,
    )
    typer.echo(json.dumps(result.model_dump(mode="json")))


@app.command("indexing")
def indexing_command(
    input_path: Annotated[
        Path,
        typer.Option(
            "--input",
            exists=True,
            dir_okay=False,
            help="Path to chunks.json from a chunk prepare run.",
        ),
    ],
    config: Annotated[
        Path,
        typer.Option("--config", exists=True, dir_okay=False, help="Path to a YAML config file."),
    ],
    tenant_id: Annotated[
        str | None,
        typer.Option(
            "--tenant-id",
            help="Multi-tenant scope tag stamped on every chunk payload. "
            "Overrides pipeline.tenant_id from the YAML config.",
        ),
    ] = None,
    pretty: Annotated[bool, typer.Option(help="Pretty-print the pipeline result JSON.")] = False,
) -> None:
    """Embed and index chunks into a vector store.

    Args:
        input_path: Path to chunks.json.
        config: Path to YAML config with embedding and vector_store sections.
        tenant_id: Optional override for pipeline.tenant_id.
        pretty: Whether to pretty-print the JSON result.
    """
    parsed_config = load_rag_config(config)
    if not parsed_config.embedding:
        raise typer.BadParameter("Config must include an 'embedding' section.")
    if not parsed_config.vector_store:
        raise typer.BadParameter("Config must include a 'vector_store' section.")
    if tenant_id is not None:
        parsed_config.pipeline.tenant_id = tenant_id
    result = run_indexing_pipeline(
        input_path=input_path,
        embedding_config=parsed_config.embedding,
        vector_store_config=parsed_config.vector_store,
        tenant_id=parsed_config.pipeline.tenant_id,
        indexing_config=parsed_config.indexing,
    )
    if pretty:
        typer.echo(json.dumps(result.model_dump(mode="json"), indent=2))
    else:
        typer.echo(json.dumps(result.model_dump(mode="json")))


@app.command("delete-collection")
def delete_collection_command(
    config: Annotated[
        Path,
        typer.Option("--config", exists=True, dir_okay=False, help="Path to a YAML config file."),
    ],
    collection: Annotated[
        str | None,
        typer.Option(
            "--collection",
            help="Override the collection name from the YAML config's vector_store options.",
        ),
    ] = None,
    yes: Annotated[
        bool,
        typer.Option(
            "--yes",
            "-y",
            help="Skip the interactive confirmation prompt.",
        ),
    ] = False,
) -> None:
    """Delete the vector-store collection named by the config.

    Destructive — drops every chunk in the collection. By default
    prompts for confirmation; pass ``--yes`` to skip.

    Args:
        config: Path to YAML config with a ``vector_store`` section.
        collection: Optional override for the collection name.
        yes: Skip the confirmation prompt when set.
    """
    parsed_config = load_rag_config(config)
    if not parsed_config.vector_store:
        raise typer.BadParameter("Config must include a 'vector_store' section.")

    vector_store_config = parsed_config.vector_store
    if collection is not None:
        vector_store_config = vector_store_config.model_copy(
            update={"options": {**vector_store_config.options, "collection_name": collection}}
        )
    collection_name = vector_store_config.options.get("collection_name", "default")

    if not yes:
        typer.confirm(
            f"Delete collection '{collection_name}' from "
            f"{vector_store_config.provider}? This cannot be undone.",
            abort=True,
        )

    vector_store = build_vector_store(vector_store_config)
    deleted = vector_store.delete_collection()
    typer.echo(
        json.dumps(
            {
                "provider": vector_store_config.provider,
                "collection_name": collection_name,
                "deleted": deleted,
            }
        )
    )


@app.command("ingest")
def ingest_command(
    config: Annotated[
        Path,
        typer.Option("--config", exists=True, dir_okay=False, help="Path to a YAML config file."),
    ],
    output_dir: Annotated[
        Path | None,
        typer.Option(
            "--output-dir",
            file_okay=False,
            help="Optional explicit run directory. Defaults to pipeline.artifact_dir/<run_id>. "
            "Required when any stage is skipped (used to load the prior artifact).",
        ),
    ] = None,
    tenant_id: Annotated[
        str | None,
        typer.Option(
            "--tenant-id",
            help="Multi-tenant scope tag stamped on every chunk payload. "
            "Overrides pipeline.tenant_id from the YAML config.",
        ),
    ] = None,
    stage: Annotated[
        list[str] | None,
        typer.Option(
            "--stage",
            help="Run only the listed stages (repeatable: --stage chunk --stage index). "
            "Valid: parser, preprocess, chunk, index. Stages execute in canonical "
            "order regardless of flag order. Overrides pipeline.stages from the YAML config.",
        ),
    ] = None,
    skip_parser: Annotated[
        bool,
        typer.Option(
            "--skip-parser",
            help="Skip the parser stage; reuse parser artifacts under --output-dir. "
            "Sugar for `--stage preprocess --stage chunk --stage index`. "
            "Mutually exclusive with --stage.",
        ),
    ] = False,
    reset_collection: Annotated[
        bool,
        typer.Option(
            "--reset-collection",
            help="Drop the configured vector-store collection before re-indexing. "
            "Use for clean re-indexes where appending would mix stale vectors. "
            "Honoured only when the index stage is active.",
        ),
    ] = False,
    strict: Annotated[
        bool,
        typer.Option(
            "--strict/--no-strict",
            help="Fail fast when a per-source preprocess step errors out. "
            "When --no-strict (default), errors are collected into the "
            "result and the run continues with the remaining docs.",
        ),
    ] = False,
    pretty: Annotated[bool, typer.Option(help="Pretty-print the pipeline result JSON.")] = False,
) -> None:
    """Run the configured ingestion stages: parser → preprocess → chunk → index.

    Builds one shared run directory under ``pipeline.artifact_dir`` and
    leaves the configured vector-store collection ready for retrieve and
    generate. Same config file as ``rag-cli indexing`` — any
    ``rag-*.yml`` works, retrieval/generation sections are simply ignored.

    Use ``--stage`` to run a subset (e.g. ``--stage chunk --stage index``
    on a prior run dir to re-chunk and re-index without re-parsing).
    Skipped stages must have their artifacts on disk in ``--output-dir``.

    Args:
        config: Path to YAML config with parser, chunker, embedding,
            and vector_store sections.
        output_dir: Optional explicit run directory.
        tenant_id: Optional override for ``pipeline.tenant_id``.
        stage: Repeatable; selects which stages to run. Overrides
            ``pipeline.stages`` from the YAML config.
        strict: Fail fast on per-source preprocess errors when set.
        pretty: Whether to pretty-print the JSON result.
    """
    parsed_config = load_rag_config(config)
    if stage and skip_parser:
        raise typer.BadParameter("--skip-parser and --stage are mutually exclusive.")
    if stage:
        parsed_config.pipeline.stages = list(stage)
    elif skip_parser:
        parsed_config.pipeline.stages = ["preprocess", "chunk", "index"]
    result = run_ingest(
        IngestRequest(
            config=parsed_config,
            config_path=config,
            output_dir=output_dir,
            tenant_id=tenant_id,
            strict=strict,
            reset_collection=reset_collection,
        )
    )
    if pretty:
        typer.echo(json.dumps(result.model_dump(mode="json"), indent=2))
    else:
        typer.echo(json.dumps(result.model_dump(mode="json")))


@dataset_app.command("peek")
def dataset_peek_command(
    dataset: Annotated[
        str,
        typer.Option(
            "--dataset",
            help="Dataset to inspect: `financebench`, `t2-ragbench`, `finder`, or `all`.",
        ),
    ] = "all",
    root: Annotated[
        Path,
        typer.Option(
            "--root",
            file_okay=False,
            help="Root directory containing downloaded datasets.",
        ),
    ] = Path("data/datasets"),
    samples: Annotated[
        int,
        typer.Option("--samples", min=1, help="Number of sample rows or files to print."),
    ] = 2,
    pretty: Annotated[bool, typer.Option(help="Pretty-print the output JSON.")] = False,
) -> None:
    """Inspect downloaded benchmark datasets and print sample content.

    Args:
        dataset: Dataset selector or ``all``.
        root: Root directory containing downloaded datasets.
        samples: Number of sample rows or files to include.
        pretty: Whether to pretty-print the output JSON.
    """
    result = peek_datasets(dataset_root=root, dataset_name=dataset, samples=samples)
    if pretty:
        typer.echo(json.dumps(result, indent=2))
    else:
        typer.echo(json.dumps(result))


@chunk_app.command("prepare")
def chunk_prepare_command(
    input_path: Annotated[
        Path,
        typer.Option(
            "--input",
            exists=True,
            dir_okay=False,
            help="Path to normalized parser elements JSON.",
        ),
    ],
    output_dir: Annotated[
        Path | None,
        typer.Option(
            "--output-dir",
            file_okay=False,
            help="Optional output directory for chunk artifacts.",
        ),
    ] = None,
    config: Annotated[
        Path | None,
        typer.Option(
            "--config",
            exists=True,
            dir_okay=False,
            help="Optional YAML config for chunker strategy and enrichment pipeline.",
        ),
    ] = None,
) -> None:
    """Build structured retrieval chunks from normalized parser elements.

    When the YAML config has a non-empty ``enrichment.pipeline``, the
    configured enrichers (e.g. ``table_summary``, ``auto_questions``)
    run after chunking so the persisted ``chunks.json`` carries the
    LLM-derived fields. Indexing then becomes a pure embed + upsert.

    Args:
        input_path: Path to normalized parser elements JSON.
        output_dir: Optional explicit output directory for chunk artifacts.
        config: Optional chunker + enrichment YAML config path.
    """
    chunker_config = load_chunker_config(config) if config is not None else None
    enrichment_config = load_enrichment_config(config) if config is not None else None
    result = run_chunk_prepare_pipeline(
        input_path=input_path,
        output_dir=output_dir,
        config=chunker_config,
        enrichment_config=enrichment_config,
    )
    typer.echo(json.dumps(result.model_dump(mode="json")))


@chunk_app.command("review")
def chunk_review_command(
    input_path: Annotated[
        Path,
        typer.Option(
            "--input",
            exists=True,
            dir_okay=False,
            help="Path to chunks.json to visualize.",
        ),
    ],
    output: Annotated[
        Path | None,
        typer.Option(
            "--output",
            dir_okay=False,
            help="Output HTML file path. Defaults to <chunks_dir>/review.html.",
        ),
    ] = None,
) -> None:
    """Generate an interactive HTML browser for a chunks.json file.

    Args:
        input_path: Path to chunks.json.
        output: Output HTML file path.
    """
    chunks, title = load_chunks(input_path)
    out_path = output or input_path.parent / "chunks_review.html"
    out_path.write_text(generate_chunk_review_html(chunks, title=title), encoding="utf-8")
    typer.echo(f"Wrote {len(chunks)} chunks → {out_path}")


@chunk_app.command("eda")
def chunk_eda_command(
    input_path: Annotated[
        Path,
        typer.Option(
            "--input",
            exists=True,
            help="Path to a chunks.json file or a directory containing one.",
        ),
    ],
    top: Annotated[
        int,
        typer.Option("--top", help="How many largest-by-char chunks to surface."),
    ] = 5,
    json_output: Annotated[
        bool,
        typer.Option(
            "--json/--text",
            help="Emit machine-readable JSON instead of the rendered text report.",
        ),
    ] = False,
) -> None:
    """Run exploratory analysis on a chunks.json artifact.

    Surfaces token/char distributions, per-chunk-type size breakdown,
    cap-violation counts, top-N largest chunks (with chunk_id), internal
    separator inventory, sentence/line unit sizes, heading hierarchy depth,
    table context coverage, parent/child structure, element coverage,
    content smells, and page-number coverage — each tied to a concrete
    chunker knob.

    Args:
        input_path: chunks.json file or its containing directory.
        top: How many of the largest chunks to surface with chunk_id.
        json_output: Emit JSON instead of the rendered text report.
    """
    report = run_chunk_eda(input_path, top_n_outliers=top)
    if json_output:
        typer.echo(json.dumps(report, indent=2))
    else:
        typer.echo(render_report(report))


@eval_app.command("create-dataset")
def eval_create_dataset_command(
    input_path: Annotated[
        Path,
        typer.Option(
            "--input",
            exists=True,
            dir_okay=False,
            help="Path to chunks.json from a chunk prepare run.",
        ),
    ],
    output_dir: Annotated[
        Path | None,
        typer.Option(
            "--output-dir",
            file_okay=False,
            help="Optional output directory for eval dataset artifacts.",
        ),
    ] = None,
    config: Annotated[
        Path | None,
        typer.Option(
            "--config",
            exists=True,
            dir_okay=False,
            help="Optional YAML config for dataset generation strategy and options.",
        ),
    ] = None,
) -> None:
    """Generate evaluation QA dataset from chunk artifacts.

    Args:
        input_path: Path to chunks.json from a chunk prepare run.
        output_dir: Optional explicit output directory for eval dataset artifacts.
        config: Optional dataset generation YAML config path.
    """
    gen_config = load_dataset_generation_config(config) if config is not None else None
    result = run_eval_create_dataset_pipeline(
        input_path=input_path,
        output_dir=output_dir,
        config=gen_config,
    )
    typer.echo(json.dumps(result.model_dump(mode="json")))


@eval_app.command("review")
def eval_review_command(
    input_path: Annotated[
        Path,
        typer.Option(
            "--input",
            exists=True,
            dir_okay=False,
            help="Path to a testset JSONL (or single-array JSON) file.",
        ),
    ],
    chunks_path: Annotated[
        Path | None,
        typer.Option(
            "--chunks",
            exists=True,
            dir_okay=False,
            help="Optional chunks.json. When supplied, evidence_chunk_ids in the "
            "detail view inline-resolve to chunk heading + content excerpts.",
        ),
    ] = None,
    output: Annotated[
        Path | None,
        typer.Option(
            "--output",
            dir_okay=False,
            help="Output HTML file path. Defaults to <input_dir>/dataset_review.html.",
        ),
    ] = None,
) -> None:
    """Generate an interactive HTML browser for an eval dataset.

    Use this to audit a testset (LLM-generated or curated) before
    running ``eval run`` against it: scan questions, drill into the
    answer + evidence, and sanity-check the distribution by difficulty
    / reasoning_type / doc_id from the filter bar.

    Pass ``--chunks chunks.json`` to inline the actual chunk content
    next to each item's evidence_chunk_ids — the most useful audit
    feature, since you can see whether the cited evidence really
    answers the question.

    Args:
        input_path: Path to the testset file.
        chunks_path: Optional chunks.json for evidence inlining.
        output: Output HTML path. Defaults to a sibling of the input.
    """
    items, title = load_dataset(input_path)
    chunks_by_id = load_chunks_index(chunks_path) if chunks_path is not None else None
    out_path = output or input_path.parent / "testset_review.html"
    out_path.write_text(
        generate_dataset_review_html(items, title=title, chunks_by_id=chunks_by_id),
        encoding="utf-8",
    )
    typer.echo(f"Wrote {len(items)} items → {out_path}")


@eval_app.command("preview")
def eval_preview_command(
    input_path: Annotated[
        Path,
        typer.Option(
            "--input",
            exists=True,
            help="Eval-run dir (or eval_results.json / per_question.jsonl inside it).",
        ),
    ],
    output: Annotated[
        Path | None,
        typer.Option(
            "--output",
            dir_okay=False,
            help="Output HTML file path. Defaults to <run-dir>/preview.html.",
        ),
    ] = None,
) -> None:
    """Render an eval run as an interactive React+JSX page.

    Reads ``config.yml``, ``eval_results.json``, ``per_question.jsonl``,
    and (when present) ``fail_cases.md`` from the run directory and emits
    a self-contained HTML page: headline metrics, fail-bucket pivot
    (mirrors CLAUDE.md "Fail-case analysis" taxonomy), per-question
    table with search + filter + click-to-expand detail (gold evidence
    vs retrieved top-10, with cross-doc highlighting).

    Args:
        input_path: Run dir or any file inside it.
        output: Output HTML path; defaults to <run-dir>/eval_preview.html.
    """
    payload = load_run(input_path)
    run_dir = Path(payload["run_dir"])
    out_path = output or run_dir / "eval_preview.html"
    out_path.write_text(
        generate_eval_preview_html(payload, title=run_dir.name),
        encoding="utf-8",
    )
    typer.echo(f"Wrote {len(payload['per_question'])} questions → {out_path} (open in a browser)")


@app.command("query")
def query_command(
    question: Annotated[
        str | None,
        typer.Option("--question", help="Single question to answer via RAG."),
    ] = None,
    input_path: Annotated[
        Path | None,
        typer.Option(
            "--input",
            exists=True,
            dir_okay=False,
            help="Path to a JSONL file with questions for batch mode.",
        ),
    ] = None,
    output_path: Annotated[
        Path | None,
        typer.Option("--output", dir_okay=False, help="Output JSONL path for batch results."),
    ] = None,
    config: Annotated[
        Path,
        typer.Option("--config", exists=True, dir_okay=False, help="Path to a YAML config file."),
    ] = ...,
    tenant_id: Annotated[
        str | None,
        typer.Option(
            "--tenant-id",
            help="Multi-tenant scope filter for retrieval. Overrides pipeline.tenant_id.",
        ),
    ] = None,
    doc_id: Annotated[
        list[str] | None,
        typer.Option(
            "--doc-id",
            help="Optional doc_id filter (repeatable for IN-match). Overrides pipeline.doc_ids.",
        ),
    ] = None,
    pretty: Annotated[bool, typer.Option(help="Pretty-print the result JSON.")] = False,
) -> None:
    """Run a RAG query: retrieve context and generate an answer.

    Args:
        question: Single question for interactive mode.
        input_path: JSONL input for batch mode.
        output_path: Output path for batch results.
        config: Path to YAML config.
        tenant_id: Optional override for pipeline.tenant_id.
        doc_id: Optional repeatable doc_id filter.
        pretty: Whether to pretty-print the JSON result.
    """
    if question is None and input_path is None:
        raise typer.BadParameter("Provide either --question or --input for batch mode.")

    parsed_config = load_rag_config(config)
    if tenant_id is not None:
        parsed_config.pipeline.tenant_id = tenant_id
    if doc_id:
        parsed_config.pipeline.doc_ids = list(doc_id)

    if question is not None:
        result = run_rag(query=question, config=parsed_config)
        if pretty:
            typer.echo(json.dumps(result.model_dump(mode="json"), indent=2))
        else:
            typer.echo(json.dumps(result.model_dump(mode="json")))
    else:
        resolved_output = output_path or input_path.parent / "rag_results.jsonl"
        results = run_rag_batch(
            input_path=input_path,
            output_path=resolved_output,
            config=parsed_config,
        )
        summary = {
            "query_count": len(results),
            "output_path": str(resolved_output),
        }
        if pretty:
            typer.echo(json.dumps(summary, indent=2))
        else:
            typer.echo(json.dumps(summary))


@rag_app.command("baseline")
def rag_baseline_command(
    input_path: Annotated[
        Path,
        typer.Option(
            "--input",
            exists=True,
            dir_okay=False,
            help="Path to chunks.json from a chunk prepare run.",
        ),
    ],
    question: Annotated[
        str,
        typer.Option("--question", help="Single question to answer with one-shot baseline RAG."),
    ],
    config: Annotated[
        Path,
        typer.Option("--config", exists=True, dir_okay=False, help="Path to a YAML config file."),
    ],
    pretty: Annotated[bool, typer.Option(help="Pretty-print the result JSON.")] = False,
) -> None:
    """Run one-shot baseline RAG over local chunk artifacts.

    Args:
        input_path: Path to chunks.json.
        question: User question.
        config: Path to YAML config.
        pretty: Whether to pretty-print the JSON result.
    """
    parsed_config = load_rag_config(config)
    result = run_baseline_rag(input_path=input_path, question=question, config=parsed_config)
    if pretty:
        typer.echo(json.dumps(result.model_dump(mode="json"), indent=2))
    else:
        typer.echo(json.dumps(result.model_dump(mode="json")))


@eval_app.command("run")
def eval_run_command(
    dataset: Annotated[
        str,
        typer.Option(
            "--dataset",
            help="Eval dataset provider: 'financebench' or 'testset'.",
        ),
    ] = "financebench",
    input_path: Annotated[
        Path | None,
        typer.Option(
            "--input",
            exists=True,
            dir_okay=False,
            help="Path to testset JSONL (required when --dataset=testset).",
        ),
    ] = None,
    filter_doc: Annotated[
        str | None,
        typer.Option("--filter-doc", help="Filter to questions about a specific document."),
    ] = None,
    config: Annotated[
        Path,
        typer.Option("--config", exists=True, dir_okay=False, help="Path to a YAML config file."),
    ] = ...,
    dataset_root: Annotated[
        Path,
        typer.Option(
            "--dataset-root",
            file_okay=False,
            help="Root directory for benchmark datasets (financebench, etc.).",
        ),
    ] = Path("data/datasets"),
    output_dir: Annotated[
        Path | None,
        typer.Option("--output-dir", file_okay=False, help="Output directory for eval artifacts."),
    ] = None,
    workers: Annotated[
        int,
        typer.Option(
            "--workers",
            help="Concurrency for retrieve+generate phase (default 1 = sequential).",
        ),
    ] = 1,
    tenant_id: Annotated[
        str | None,
        typer.Option(
            "--tenant-id",
            help="Multi-tenant scope filter for retrieval. Overrides pipeline.tenant_id.",
        ),
    ] = None,
    doc_id: Annotated[
        list[str] | None,
        typer.Option(
            "--doc-id",
            help="Optional doc_id filter (repeatable). Overrides pipeline.doc_ids.",
        ),
    ] = None,
    full_eval: Annotated[
        bool,
        typer.Option(
            "--full-eval",
            help="Run RAGAS LLM-judge metrics (faithfulness, answer_relevancy, "
            "context_precision) on top of the deterministic retrieval "
            "metrics. Off by default for the fast inner loop; flip on for "
            "promotion-grade rows in BENCHMARK.md.",
        ),
    ] = False,
    pretty: Annotated[bool, typer.Option(help="Pretty-print the result JSON.")] = False,
) -> None:
    """Run end-to-end RAG evaluation against a dataset provider.

    Args:
        dataset: Eval dataset provider name.
        input_path: Path to testset JSONL when using the testset provider.
        filter_doc: Optional document filter (by doc_name or doc_id).
        config: Path to YAML config.
        dataset_root: Root directory for benchmark datasets.
        output_dir: Optional output directory.
        workers: Concurrency for the retrieve+generate phase.
        tenant_id: Optional override for pipeline.tenant_id.
        doc_id: Optional repeatable doc_id filter.
        full_eval: Include RAGAS LLM-judge metrics in the run.
        pretty: Whether to pretty-print the JSON result.
    """
    parsed_config = load_rag_config(config)
    if tenant_id is not None:
        parsed_config.pipeline.tenant_id = tenant_id
    if doc_id:
        parsed_config.pipeline.doc_ids = list(doc_id)
    options: dict[str, object] = {}
    if dataset == "financebench":
        options["root"] = str(dataset_root)
        if filter_doc:
            options["filter_doc"] = filter_doc
    elif dataset == "testset":
        if input_path is None:
            raise typer.BadParameter("--input is required when --dataset=testset")
        options["input"] = str(input_path)
        if filter_doc:
            options["filter_doc"] = filter_doc
    else:
        raise typer.BadParameter(f"unknown --dataset: {dataset}")

    eval_dataset_config = ProviderConfig(provider=dataset, options=options)
    result = run_eval_pipeline(
        config=parsed_config,
        eval_dataset_config=eval_dataset_config,
        output_dir=output_dir,
        config_name=config.stem,
        max_workers=workers,
        full_eval=full_eval,
    )
    if pretty:
        typer.echo(json.dumps(result.model_dump(mode="json"), indent=2))
    else:
        typer.echo(json.dumps(result.model_dump(mode="json")))


def main() -> None:
    """Run the Typer application."""
    app()


if __name__ == "__main__":
    main()
