"""Typed error hierarchy for the high-level xrag client (v0.2+).

Every public method on ``Xrag`` / ``XragTenant`` (the resources under
``client.documents.*``, ``client.retrievals.*``, ``client.rag.*``) raises
from a subclass of :class:`XragError`. Callers can catch the base for
"any xrag operation failed" or specific subclasses for fine-grained
handling (HTTP-status mapping, retry logic, user-facing messages).

The wire-API codes in ``docs/sub-plans/api/apis_design.md`` map 1:1 to
these exceptions — see the docstrings on each subclass for the wire
status the consumer should propagate.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from xrag.models.chunks import ChunkValidationError


class XragError(Exception):
    """Base class for all xrag client errors.

    Attributes
    ----------
    code:
        Machine-readable error code matching the wire API (e.g.
        ``"validation_error"``, ``"document_not_found"``).
    request_id:
        If the error is propagated from an inner request (e.g. an OpenAI
        call that surfaced a request id), the upstream id is preserved
        here so callers can correlate.
    """

    code: str = "xrag_error"

    def __init__(
        self,
        message: str,
        *,
        code: str | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(message)
        if code is not None:
            self.code = code
        self.request_id = request_id

    def __repr__(self) -> str:
        return f"{type(self).__name__}(code={self.code!r}, message={str(self)!r})"


class XragValidationError(XragError):
    """Caller supplied invalid arguments — wire 4xx ``validation_error``.

    Examples: missing required field, bad collection name, malformed
    metadata JSON, unknown enrichment stage.
    """

    code = "validation_error"


class XragDocumentNotFound(XragError):
    """Document id does not exist for the given tenant — wire 404."""

    code = "document_not_found"


class XragCollectionNotFound(XragError):
    """Vector store collection does not exist — wire 404.

    Raised on retrieval against a collection that no document has ever
    been ingested into.
    """

    code = "collection_not_found"


class XragCollectionDimMismatch(XragError):
    """Embedding dim of the configured model conflicts with an existing
    collection — wire 409 ``collection_dim_mismatch``.

    Typically surfaces when a caller switches embedding models without
    creating a new collection.
    """

    code = "collection_dim_mismatch"


class XragDocumentConflict(XragError):
    """Another document with the same ``external_id`` already exists in
    the collection — wire 409 ``external_id_conflict``."""

    code = "external_id_conflict"


class XragGenerationNotConfigured(XragError):
    """Raised by ``client.rag.ask`` when the client was built without
    ``generation=`` configured (retrieve-only profile).

    Hint: pass ``generation="openai:gpt-4.1-nano"`` (or equivalent) at
    construction, or use ``client.retrievals.search`` and run your own
    LLM over the returned chunks.
    """

    code = "generation_not_configured"


class XragChunksInvalid(XragError):
    """Caller-supplied chunks failed validation in
    ``client.documents.index_chunks`` — wire 422 ``chunks_invalid``.

    Attributes
    ----------
    detail:
        One :class:`xrag.models.chunks.ChunkValidationError` per offending
        chunk: ``(index, field, message, code)``. ``field`` is ``None``
        when the error is at the file/root level (e.g. malformed JSON,
        unknown ``schema_version``).
    """

    code = "chunks_invalid"

    def __init__(
        self,
        message: str,
        *,
        detail: list[ChunkValidationError] | None = None,
        code: str | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(message, code=code, request_id=request_id)
        self.detail: list[Any] = list(detail or [])


class XragArtifactsError(XragError):
    """Raised when ingest cannot manage its intermediate artifacts dir.

    Codes
    -----
    ``artifacts_dir_unwritable``
        Supplied ``artifacts_dir`` is not writable.
    ``artifacts_disk_full``
        A write failed mid-ingest.
    ``artifacts_path_collision``
        Another ingest is already running against the same
        ``artifacts_dir`` (lockfile present).

    For ``artifacts_path_collision``, ``detail`` holds the holder's
    ``pid``, ``hostname``, ``started_at``, ``document_id``, and
    ``xrag_version`` from the lockfile JSON.
    """

    code = "artifacts_error"

    def __init__(
        self,
        message: str,
        *,
        code: str = "artifacts_error",
        detail: dict[str, Any] | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(message, code=code, request_id=request_id)
        self.detail: dict[str, Any] = dict(detail or {})


class XragTransientError(XragError):
    """A retryable upstream failure (network, 5xx, timeout) that
    exhausted the client's retry budget — wire 502.
    """

    code = "transient_error"
