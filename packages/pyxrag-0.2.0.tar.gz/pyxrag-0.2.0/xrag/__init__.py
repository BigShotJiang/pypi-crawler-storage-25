"""xrag — RAG ingest + retrieval engine.

Public API surface for v0.2.0. Two layers, both SemVer-bound:

1. Functional API (v0.1+): ``run_ingest``, ``run_rag``, plus configs,
   loaders, ingest events, and ``RagQueryResult``. The high-level client
   wraps these; reach for them when you need full control of
   ``AppConfig`` (testing, eval batches, custom pipelines).

2. High-level :class:`Xrag` async client (v0.2+): resource-namespaced
   ops (``client.documents.*``, ``client.retrievals.*``,
   ``client.rag.*``), tenant binding via ``for_tenant``, typed error
   hierarchy, opt-in capabilities (composable retrieve-only / index-only
   profiles supported).

Anything outside ``__all__`` is internal and not SemVer-bound.

The functional-API entry points (``run_ingest``, ``run_rag``) are loaded
lazily so ``import xrag`` doesn't pull optional-extra deps like
``unstructured``. Calling them triggers the heavy imports — and surfaces
a friendly ``ImportError`` if the required extra isn't installed.
"""

from importlib import import_module

# Client (v0.2)
from xrag.client import Xrag, XragTenant
from xrag.client.resources import DocumentsResource, RagResource, RetrievalsResource

# Configs
from xrag.config.loader import load_config
from xrag.config.models import (
    AppConfig,
    IngestStage,
    ProviderConfig,
    RetrievalConfig,
    SourceConfig,
)

# Typed error hierarchy (v0.2)
from xrag.errors import (
    XragArtifactsError,
    XragChunksInvalid,
    XragCollectionDimMismatch,
    XragCollectionNotFound,
    XragDocumentConflict,
    XragDocumentNotFound,
    XragError,
    XragGenerationNotConfigured,
    XragTransientError,
    XragValidationError,
)

# Document / Chunk / Retrieval / RAG models (v0.2)
from xrag.models.chunk_adapters import chunks_from_internal_json
from xrag.models.chunks import (
    ChunkValidationError,
    ValidationReport,
    chunks_json_schema,
    validate_chunks,
    validate_chunks_file,
)
from xrag.models.document import Chunk, ChunksPage, Document, DocumentStatus
from xrag.models.ingest import (
    IngestEvent,
    IngestRequest,
    IngestResult,
    ProgressTick,
    SourceCompleted,
    SourceError,
    SourceFailed,
    SourceStarted,
    StageCompleted,
    StageStarted,
)
from xrag.models.rag import RagRequest, RagResult, TokenUsage
from xrag.models.result import RagQueryResult
from xrag.models.retrieval import RetrievalRequest, RetrievalResult, ScoredChunk

try:
    from xrag._version import __version__
except ImportError:
    __version__ = "0.0.0+unknown"

# Lazy: pulls pipeline modules that transitively depend on optional extras
# (e.g. ``unstructured`` for parser_preprocess). Resolved on first access.
_LAZY_ATTRS: dict[str, tuple[str, str]] = {
    "run_ingest": ("xrag.pipelines.ingest", "run_ingest"),
    "run_rag": ("xrag.pipelines.rag_query", "run_rag"),
}


def __getattr__(name: str):  # PEP 562
    if name in _LAZY_ATTRS:
        module_name, attr = _LAZY_ATTRS[name]
        value = getattr(import_module(module_name), attr)
        globals()[name] = value
        return value
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__() -> list[str]:
    return sorted({*globals(), *_LAZY_ATTRS})


__all__ = [
    # High-level client (v0.2)
    "Xrag",
    "XragTenant",
    "DocumentsResource",
    "RetrievalsResource",
    "RagResource",
    # Functional API (lazy)
    "run_ingest",
    "run_rag",
    # Configs
    "AppConfig",
    "ProviderConfig",
    "RetrievalConfig",
    "SourceConfig",
    "IngestStage",
    "load_config",
    # Ingest request / result / events (v0.1)
    "IngestRequest",
    "IngestResult",
    "IngestEvent",
    "StageStarted",
    "StageCompleted",
    "SourceStarted",
    "SourceCompleted",
    "SourceFailed",
    "SourceError",
    "ProgressTick",
    # Document / Chunk / Retrieval / RAG (v0.2)
    "Document",
    "DocumentStatus",
    "Chunk",
    "ChunksPage",
    "ChunkValidationError",
    "ValidationReport",
    "validate_chunks",
    "validate_chunks_file",
    "chunks_json_schema",
    "chunks_from_internal_json",
    "ScoredChunk",
    "RetrievalRequest",
    "RetrievalResult",
    "RagRequest",
    "RagResult",
    "TokenUsage",
    # Existing functional-API result (renamed to RagResult in the v0.2 client path)
    "RagQueryResult",
    # Errors (v0.2)
    "XragError",
    "XragValidationError",
    "XragDocumentNotFound",
    "XragCollectionNotFound",
    "XragCollectionDimMismatch",
    "XragDocumentConflict",
    "XragGenerationNotConfigured",
    "XragChunksInvalid",
    "XragArtifactsError",
    "XragTransientError",
    # Version
    "__version__",
]
