"""High-level async client for ``xrag``.

Groups the library surface into ``documents``, ``retrievals``, and ``rag``
resource namespaces with shared defaults and lazily-built providers.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import TYPE_CHECKING, Any

from xrag.client.providers import parse_provider
from xrag.config.models import (
    AppConfig,
    PipelineConfig,
    ProviderConfig,
    RetrievalConfig,
    SourceConfig,
)
from xrag.errors import XragValidationError

if TYPE_CHECKING:
    from qdrant_client import QdrantClient

    from xrag.client.resources.documents import DocumentsResource
    from xrag.client.resources.rag import RagResource
    from xrag.client.resources.retrievals import RetrievalsResource
    from xrag.client.tenant import XragTenant
    from xrag.core.embedding.base import BaseEmbedding
    from xrag.core.generation.base import BaseGenerator
    from xrag.core.reranker.base import BaseReranker
    from xrag.core.retrieval.base import BaseRetriever
    from xrag.core.tracing.base import BaseTracer
    from xrag.core.vector_store.base import BaseVectorStore
    from xrag.models.document import Document

logger = logging.getLogger(__name__)


_DEFAULT_EMBEDDING = "openai:text-embedding-3-small"
_DEFAULT_PARSER = "unstructured"
_DEFAULT_CHUNKER = "section_table"
_DEFAULT_ENRICHMENT: tuple[str, ...] = ("auto_keywords", "auto_questions")
_KNOWN_ENRICHMENT_STAGES: frozenset[str] = frozenset(
    {"auto_keywords", "auto_questions", "table_context", "table_summary"}
)


class Xrag:
    """Async client for ingest, retrieval, and RAG operations.

    Create the client directly for explicit control, or use
    :meth:`from_env` or :meth:`from_app_config` as convenience
    constructors.
    """

    def __init__(
        self,
        *,
        qdrant_url: str | None = None,
        qdrant_path: str | Path | None = None,
        embedding: str = _DEFAULT_EMBEDDING,
        generation: str | None = None,
        enrichment: tuple[str, ...] | None = _DEFAULT_ENRICHMENT,
        reranker: str | None = None,
        parser: str = _DEFAULT_PARSER,
        chunker: str = _DEFAULT_CHUNKER,
        retrieval_defaults: RetrievalConfig | None = None,
        upload_dir: str | Path = "/tmp/xrag_uploads",
        artifacts_dir: str | Path | None = None,
        timeout_s: float = 30.0,
        ingest_timeout_s: float = 600.0,
        tracing: str | None = None,
    ) -> None:
        if not qdrant_url and not qdrant_path:
            raise XragValidationError(
                "Xrag requires either qdrant_url (server mode) or qdrant_path (local file mode)",
                code="missing_qdrant",
            )
        if qdrant_url and qdrant_path:
            raise XragValidationError(
                "Xrag accepts qdrant_url XOR qdrant_path, not both",
                code="conflicting_qdrant_modes",
            )
        self._qdrant_url = qdrant_url
        self._qdrant_path = Path(qdrant_path) if qdrant_path else None
        self._embedding_cfg = parse_provider(embedding, role="embedding")
        self._generation_cfg = parse_provider(generation, role="generation")
        self._reranker_cfg = parse_provider(reranker, role="reranker")
        self._tracing_cfg = parse_provider(tracing, role="tracing")

        if enrichment is not None:
            self._validate_enrichment(enrichment)
        self._enrichment = enrichment

        self._parser_cfg = self._parse_parser(parser)
        self._chunker_cfg = self._parse_chunker(chunker)

        self._retrieval_defaults = retrieval_defaults or RetrievalConfig(
            provider="hybrid",
            options={
                "top_k": 10,
                "bm25_candidates": 50,
                "vector_candidates": 50,
                "rrf_k": 60,
                "dedup_family": True,
            },
        )
        self._upload_dir = Path(upload_dir)
        self._artifacts_dir = Path(artifacts_dir) if artifacts_dir else None
        self._timeout_s = timeout_s
        self._ingest_timeout_s = ingest_timeout_s

        # Single-process registry; persistent storage belongs to the wire-API consumer.
        self._doc_registry: dict[str, Document] = {}

        # Provider cache — built lazily, reused for the client's lifetime.
        self._embedding: BaseEmbedding | None = None
        self._reranker: BaseReranker | None = None
        self._generator: BaseGenerator | None = None
        self._tracer: BaseTracer | None = None
        # Per-collection vector stores share one QdrantClient per Xrag — required for
        # local-file mode, which holds a per-path file lock.
        self._vector_stores: dict[str, BaseVectorStore] = {}
        self._qdrant_clients: dict[tuple[str, str], QdrantClient] = {}
        # Retrievers are cached per (collection, provider) because the hybrid retriever
        # builds a full-collection BM25 index on first retrieve(); per-call tunables flow
        # through retrieve()'s options dict.
        self._retrievers: dict[tuple[str, str], BaseRetriever] = {}

    @classmethod
    def from_env(cls) -> Xrag:
        """Build a client from ``XRAG_*`` environment variables."""
        qdrant_url = os.environ.get("XRAG_QDRANT_URL") or None
        qdrant_path = os.environ.get("XRAG_QDRANT_PATH") or None
        if not qdrant_url and not qdrant_path:
            raise XragValidationError(
                "Xrag.from_env() requires XRAG_QDRANT_URL or XRAG_QDRANT_PATH to be set",
                code="missing_qdrant",
            )

        tracing: str | None = None
        if os.environ.get("LANGSMITH_API_KEY"):
            project = os.environ.get("LANGSMITH_PROJECT", "xrag")
            tracing = f"langsmith:{project}"

        return cls(
            qdrant_url=qdrant_url,
            qdrant_path=qdrant_path,
            embedding=os.environ.get("XRAG_DEFAULT_EMBEDDING", _DEFAULT_EMBEDDING),
            generation=os.environ.get("XRAG_DEFAULT_GENERATION") or None,
            reranker=os.environ.get("XRAG_DEFAULT_RERANKER") or None,
            upload_dir=os.environ.get("XRAG_UPLOAD_DIR", "/tmp/xrag_uploads"),
            artifacts_dir=os.environ.get("XRAG_ARTIFACTS_DIR") or None,
            tracing=tracing,
        )

    @classmethod
    def from_app_config(cls, cfg: AppConfig) -> Xrag:
        """Build a client from an existing :class:`AppConfig`.

        Forwards every client-level field; per-call resource args still override.
        """
        vs_options = (cfg.vector_store.options if cfg.vector_store else {}) or {}
        qdrant_url = vs_options.get("url") or os.environ.get("XRAG_QDRANT_URL") or None
        qdrant_path = vs_options.get("path") or os.environ.get("XRAG_QDRANT_PATH") or None
        if not qdrant_url and not qdrant_path:
            raise XragValidationError(
                "Xrag.from_app_config requires cfg.vector_store.options.url or .path "
                "(or XRAG_QDRANT_URL / XRAG_QDRANT_PATH in env)",
                code="missing_qdrant",
            )

        embedding = _provider_to_string(cfg.embedding) or _DEFAULT_EMBEDDING
        generation = _provider_to_string(cfg.generation)
        reranker_cfg = cfg.retrieval.reranker if cfg.retrieval else None
        reranker = _provider_to_string(reranker_cfg) if reranker_cfg else None
        tracing = _provider_to_string(cfg.tracing)

        # None ⇒ inherit client default; empty pipeline ⇒ disable enrichment.
        if cfg.enrichment is None:
            enrichment: tuple[str, ...] | None = _DEFAULT_ENRICHMENT
        else:
            enrichment = tuple(cfg.enrichment.pipeline)

        client = cls(
            qdrant_url=qdrant_url,
            qdrant_path=qdrant_path,
            embedding=embedding,
            generation=generation,
            reranker=reranker,
            retrieval_defaults=cfg.retrieval,
            enrichment=enrichment,
            artifacts_dir=cfg.pipeline.artifact_dir if cfg.pipeline else None,
            tracing=tracing,
        )

        # Parser / chunker may carry options that don't round-trip through the
        # public string form, so forward the ProviderConfig directly.
        if cfg.parser is not None:
            client._parser_cfg = cfg.parser
        if cfg.chunker is not None:
            client._chunker_cfg = cfg.chunker
        return client

    def for_tenant(self, tenant_id: str) -> XragTenant:
        """Return a tenant-bound view of this client."""
        from xrag.client.tenant import XragTenant as _XragTenant

        return _XragTenant(self, tenant_id)

    @property
    def documents(self) -> DocumentsResource:
        from xrag.client.resources.documents import DocumentsResource as _R

        return _R(self)

    @property
    def retrievals(self) -> RetrievalsResource:
        from xrag.client.resources.retrievals import RetrievalsResource as _R

        return _R(self)

    @property
    def rag(self) -> RagResource:
        from xrag.client.resources.rag import RagResource as _R

        return _R(self)

    # Lazy build-once, reuse-forever. A race produces two builds + one leaked
    # instance; correctness is preserved, so no lock.

    def _get_embedding(self) -> BaseEmbedding:
        if self._embedding is None:
            from xrag.core.embedding.factory import build_embedding

            if self._embedding_cfg is None:
                raise XragValidationError(
                    "embedding provider is required for retrieve/ask but was not configured",
                    code="missing_embedding",
                )
            logger.debug("xrag client: building embedding provider (cold)")
            self._embedding = build_embedding(self._embedding_cfg)
        return self._embedding

    def _get_vector_store(self, collection: str) -> BaseVectorStore:
        cached = self._vector_stores.get(collection)
        if cached is not None:
            return cached
        from xrag.core.vector_store.qdrant import QdrantVectorStore

        client = self._get_qdrant_client()
        logger.debug(
            "xrag client: building vector store for collection %r (cold)",
            collection,
        )
        vs = QdrantVectorStore(
            collection_name=collection,
            client=client,
            distance="cosine",
        )
        self._vector_stores[collection] = vs
        return vs

    def _get_qdrant_client(self) -> QdrantClient:
        """Return the cached :class:`QdrantClient` for this Xrag's location."""
        from qdrant_client import QdrantClient

        if self._qdrant_path is not None:
            key: tuple[str, str] = ("path", str(self._qdrant_path))
        else:
            key = ("url", str(self._qdrant_url))

        cached = self._qdrant_clients.get(key)
        if cached is not None:
            return cached

        from xrag.config.settings import get_settings

        settings = get_settings()
        if self._qdrant_path is not None:
            path = str(self._qdrant_path)
            if path == ":memory:":
                client = QdrantClient(location=":memory:")
            else:
                client = QdrantClient(path=path)
        else:
            client = QdrantClient(
                url=self._qdrant_url,
                api_key=settings.qdrant_api_key,
                prefer_grpc=False,
            )
        logger.debug("xrag client: built shared QdrantClient (%s=%s)", *key)
        self._qdrant_clients[key] = client
        return client

    def _get_reranker(self) -> BaseReranker | None:
        """Return the cached reranker, or ``None`` if not configured."""
        if self._reranker_cfg is None:
            return None
        if self._reranker is None:
            from xrag.core.reranker.factory import build_reranker

            logger.debug("xrag client: building reranker (cold)")
            self._reranker = build_reranker(self._reranker_cfg)
        return self._reranker

    def _get_generator(self) -> BaseGenerator:
        """Return the cached generator.

        Raises:
            XragValidationError: No generation provider is configured.
        """
        if self._generation_cfg is None:
            raise XragValidationError(
                "generation provider is not configured", code="generation_not_configured"
            )
        if self._generator is None:
            from xrag.core.generation.factory import build_generator

            tracer = self._get_tracer()
            logger.debug("xrag client: building generator (cold)")
            self._generator = build_generator(
                self._generation_cfg, callbacks=tracer.get_callbacks()
            )
        return self._generator

    def _get_tracer(self) -> BaseTracer:
        if self._tracer is None:
            from xrag.core.tracing.factory import build_tracer

            logger.debug("xrag client: building tracer (cold)")
            tracer = build_tracer(self._tracing_cfg)
            tracer.setup()
            self._tracer = tracer
        return self._tracer

    def _get_retriever(self, collection: str, *, hybrid: bool) -> BaseRetriever:
        """Return a cached retriever for a collection and retrieval mode."""
        provider = "hybrid" if hybrid else "simple"
        key = (collection, provider)
        cached = self._retrievers.get(key)
        if cached is not None:
            return cached

        from xrag.core.retrieval.factory import build_retriever

        embedding = self._get_embedding()
        vector_store = self._get_vector_store(collection)
        ctor_cfg = self._retrieval_defaults.model_copy(deep=True)
        ctor_cfg = ctor_cfg.model_copy(update={"provider": provider})
        logger.debug(
            "xrag client: building retriever for collection %r provider %r (cold)",
            collection,
            provider,
        )
        retriever = build_retriever(ctor_cfg, embedding, vector_store)
        self._retrievers[key] = retriever
        return retriever

    def _build_app_config(
        self,
        *,
        tenant_id: str,
        collection: str,
        sources: list[SourceConfig] | None = None,
        doc_ids: list[str] | None = None,
        artifact_dir: str | Path | None = None,
        enrichment_override: tuple[str, ...] | None = None,
    ) -> AppConfig:
        """Build an :class:`AppConfig` for one client operation.

        Args:
            tenant_id: Tenant scope for the operation.
            collection: Qdrant collection name.
            sources: Sources for ingest operations.
            doc_ids: Optional document restriction for retrieval config.
            artifact_dir: Artifacts directory to place on the pipeline config.
            enrichment_override: ``None`` uses the client default, ``()``
                disables enrichment, and a non-empty tuple replaces the
                default stage list.
        """
        # Emit only the mode the client was constructed with — mixing url+path
        # silently routes to path in the factory.
        vs_options: dict[str, object] = {
            "collection_name": collection,
            "distance": "cosine",
        }
        if self._qdrant_path is not None:
            vs_options["path"] = str(self._qdrant_path)
        else:
            vs_options["url"] = self._qdrant_url
        vector_store = ProviderConfig(provider="qdrant", options=vs_options)

        retrieval = self._retrieval_defaults.model_copy(deep=True)
        if self._reranker_cfg and "reranker" not in retrieval.options:
            retrieval = retrieval.model_copy(
                update={
                    "options": {
                        **retrieval.options,
                        "reranker": self._reranker_cfg.model_dump(),
                    }
                }
            )

        generation = self._generation_cfg.model_copy(deep=True) if self._generation_cfg else None
        if generation is not None and "temperature" not in generation.options:
            generation = generation.model_copy(
                update={"options": {**generation.options, "temperature": 0.1}}
            )

        stages = self._enrichment if enrichment_override is None else enrichment_override
        enrichment_cfg = None
        if stages:
            from xrag.config.models import EnrichmentConfig

            enrichment_cfg = EnrichmentConfig(pipeline=list(stages), options={})

        # Pass only non-None overrides — PipelineConfig validates None as missing.
        pipeline_kwargs: dict[str, Any] = {
            "name": "xrag-client",
            "mode": "full",
            "tenant_id": tenant_id,
        }
        if doc_ids:
            pipeline_kwargs["doc_ids"] = list(doc_ids)
        if artifact_dir is None:
            artifact_dir, _ = self._resolve_artifact_dir(None)
        pipeline_kwargs["artifact_dir"] = str(artifact_dir)
        pipeline = PipelineConfig(**pipeline_kwargs)

        return AppConfig(
            pipeline=pipeline,
            sources=sources,
            parser=self._parser_cfg,
            chunker=self._chunker_cfg,
            embedding=self._embedding_cfg,
            vector_store=vector_store,
            retrieval=retrieval,
            generation=generation,
            enrichment=enrichment_cfg,
            tracing=self._tracing_cfg,
        )

    def _resolve_artifact_dir(self, per_call: str | Path | None) -> tuple[Path, bool]:
        """Resolve the artifacts directory for one ingest call.

        Returns:
            A ``(path, was_ephemeral)`` tuple.
        """
        if per_call is not None:
            return Path(per_call), False
        if self._artifacts_dir is not None:
            return self._artifacts_dir, False
        import tempfile

        ephemeral = Path(tempfile.mkdtemp(prefix="xrag_ingest_"))
        logger.debug("xrag client: created ephemeral artifacts dir at %s", ephemeral)
        return ephemeral, True

    def _check_external_id_conflict(
        self,
        *,
        tenant_id: str,
        collection: str,
        external_id: str | None,
    ) -> None:
        """Raise on an ``external_id`` collision in this process-local registry."""
        if external_id is None:
            return
        from xrag.errors import XragDocumentConflict

        for existing in self._doc_registry.values():
            if (
                existing.tenant_id == tenant_id
                and existing.collection == collection
                and existing.external_id == external_id
            ):
                raise XragDocumentConflict(
                    f"document with external_id {external_id!r} already exists "
                    f"in collection {collection!r} for tenant {tenant_id!r} "
                    f"(internal id: {existing.id!r})"
                )

    def _invalidate_retrievers(self, collection: str) -> None:
        """Drop cached retrievers for a collection after a write."""
        stale = [key for key in self._retrievers if key[0] == collection]
        for key in stale:
            self._retrievers.pop(key, None)

    def close(self) -> None:
        """Release cached providers and close open connections. Idempotent."""
        # Vector stores hold borrowed QdrantClient refs — drop them before closing the clients.
        for vs in self._vector_stores.values():
            try:
                vs.close()
            except Exception:
                pass
        self._vector_stores.clear()
        for client in self._qdrant_clients.values():
            try:
                client.close()
            except Exception:
                pass
        self._qdrant_clients.clear()
        self._retrievers.clear()
        for provider in (self._embedding, self._reranker, self._generator, self._tracer):
            if provider is not None and hasattr(provider, "close"):
                try:
                    provider.close()
                except Exception:
                    pass
        self._embedding = None
        self._reranker = None
        self._generator = None
        self._tracer = None

    @staticmethod
    def _validate_enrichment(stages: tuple[str, ...]) -> None:
        unknown = sorted(set(stages) - _KNOWN_ENRICHMENT_STAGES)
        if unknown:
            raise XragValidationError(
                f"unknown enrichment stage(s): {unknown}; "
                f"valid stages: {sorted(_KNOWN_ENRICHMENT_STAGES)}",
                code="unknown_enrichment_stage",
            )

    @staticmethod
    def _parse_parser(spec: str) -> ProviderConfig:
        """Parse parser strings like ``"unstructured"`` or ``"unstructured_local:fast"``."""
        if ":" not in spec:
            return ProviderConfig(provider=spec, options={})
        provider, _, strategy = spec.partition(":")
        if provider == "unstructured":
            return ProviderConfig(
                provider="unstructured_local",
                options={
                    "strategy": strategy,
                    "workers": 8,
                    "infer_table_structure": True,
                },
            )
        return ProviderConfig(provider=provider, options={"strategy": strategy})

    @staticmethod
    def _parse_chunker(spec: str) -> ProviderConfig:
        """Parse chunker strings — currently just the provider name."""
        return ProviderConfig(provider=spec, options={})


def _provider_to_string(cfg: ProviderConfig | None) -> str | None:
    """Convert a provider config back into a public provider string.

    Returns ``None`` when the config cannot be represented by the public string form.
    """
    if cfg is None:
        return None
    model = cfg.options.get("model") if isinstance(cfg.options, dict) else None
    if not model or not isinstance(model, str):
        return None
    prefix = cfg.provider
    if prefix == "unstructured_local":
        prefix = "unstructured"
    return f"{prefix}:{model}"
