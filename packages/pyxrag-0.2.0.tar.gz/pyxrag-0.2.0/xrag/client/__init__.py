"""User-facing async client exports for ``xrag``.

The high-level client lives under :class:`xrag.client.xrag.Xrag`.
Lower-level functional entrypoints remain available under :mod:`xrag`
for callers that want direct control over pipeline config.
"""

from xrag.client.tenant import XragTenant
from xrag.client.xrag import Xrag

__all__ = ["Xrag", "XragTenant"]
