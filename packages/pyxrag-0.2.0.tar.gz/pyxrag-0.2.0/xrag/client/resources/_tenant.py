"""Tenant resolution shared by all resource methods."""

from __future__ import annotations

from xrag.errors import XragValidationError


def resolve_tenant(bound: str | None, passed: str | None) -> str:
    """Return the tenant id for one resource call.

    Tenant-bound resources (from ``client.for_tenant(...)``) reject explicit
    ``tenant_id`` arguments. On the bare client, the per-call value wins and
    falls back to ``"default"``.

    Raises:
        XragValidationError: ``tenant_id`` was passed to a bound resource.
    """
    if bound is not None:
        if passed is not None:
            raise XragValidationError(
                "tenant_id cannot be passed to a tenant-bound resource; "
                "use the bare client.<resource> to override",
                code="tenant_id_on_bound_resource",
            )
        return bound
    return passed or "default"
