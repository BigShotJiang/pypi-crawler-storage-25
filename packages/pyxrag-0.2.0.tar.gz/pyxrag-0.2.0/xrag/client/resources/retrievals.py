"""Retrieval operations exposed under ``client.retrievals``."""

from __future__ import annotations

import asyncio
import logging
import time
import uuid
from typing import TYPE_CHECKING, Any

from xrag.client.resources._chunk_convert import to_scored_chunk
from xrag.client.resources._tenant import resolve_tenant
from xrag.config.models import RetrievalConfig
from xrag.errors import XragCollectionNotFound, XragError
from xrag.models.retrieval import RetrievalResult

if TYPE_CHECKING:
    from xrag.client.xrag import Xrag

logger = logging.getLogger(__name__)


class RetrievalsResource:
    def __init__(self, client: Xrag, *, bound_tenant: str | None = None) -> None:
        self._client = client
        self._bound_tenant = bound_tenant

    async def search(
        self,
        *,
        query: str,
        collection: str,
        tenant_id: str | None = None,
        top_k: int = 10,
        filter: dict[str, Any] | None = None,
        rerank: bool | None = None,
        hybrid: bool | None = None,
        config_overrides: RetrievalConfig | None = None,
    ) -> RetrievalResult:
        """Search an indexed collection and return scored chunks."""
        effective_tenant = resolve_tenant(self._bound_tenant, tenant_id)
        request_id = "req_" + uuid.uuid4().hex[:24]

        # default True; explicit False forces vector-only.
        use_hybrid = hybrid is not False
        retriever = self._client._get_retriever(collection, hybrid=use_hybrid)

        retrieval_cfg = (
            config_overrides.model_copy(deep=True)
            if config_overrides
            else self._client._retrieval_defaults.model_copy(deep=True)
        )
        options = dict(retrieval_cfg.options or {})
        options["top_k"] = top_k
        options["filter"] = {
            **(options.get("filter") or {}),
            **(filter or {}),
            "tenant_id": effective_tenant,
        }
        retrieval_cfg.options = options

        wants_rerank = bool(rerank) if rerank is not None else False
        reranker = self._client._get_reranker() if wants_rerank else None

        from xrag.pipelines.helpers import run_retrieval

        t0 = time.perf_counter()
        try:
            retrieved = await asyncio.to_thread(
                run_retrieval, retriever, reranker, query, retrieval_cfg
            )
        except Exception as e:
            msg = str(e).lower()
            if "doesn't exist" in msg or "not found" in msg or "no such collection" in msg:
                raise XragCollectionNotFound(
                    f"collection {collection!r} does not exist for tenant {effective_tenant!r}",
                    request_id=request_id,
                ) from e
            raise XragError(
                f"retrieval failed: {e}", code="retrieval_failed", request_id=request_id
            ) from e
        took_ms = int((time.perf_counter() - t0) * 1000)

        return RetrievalResult(
            chunks=[to_scored_chunk(c) for c in retrieved],
            took_ms=took_ms,
            request_id=request_id,
        )
