"""Convert retriever payloads into public retrieval models."""

from __future__ import annotations

from typing import Any, get_args

from xrag.models.retrieval import ScoredChunk, ScoreType

_VALID_SCORE_TYPES = frozenset(get_args(ScoreType))


def to_scored_chunk(payload: dict[str, Any], *, default_score_type: str = "hybrid") -> ScoredChunk:
    """Build a :class:`ScoredChunk` from a retriever payload.

    Normalises the payload variants used across xrag retrievers; fields without
    first-class slots on :class:`ScoredChunk` are folded into ``metadata``.
    """
    chunk_id = str(payload.get("chunk_id") or payload.get("id") or "")
    document_id = str(payload.get("document_id") or payload.get("doc_id") or "")
    text = str(payload.get("content") or payload.get("text") or "")
    score = float(payload.get("score") or 0.0)
    score_type = payload.get("score_type") or default_score_type
    if score_type not in _VALID_SCORE_TYPES:
        score_type = "hybrid"

    base_metadata = dict(payload.get("metadata") or {})
    for k in ("section_title", "page_start", "page_end", "chunk_type", "parent_id"):
        if k in payload and k not in base_metadata:
            base_metadata[k] = payload[k]

    return ScoredChunk(
        chunk_id=chunk_id,
        document_id=document_id,
        text=text,
        score=score,
        score_type=score_type,
        metadata=base_metadata,
    )
