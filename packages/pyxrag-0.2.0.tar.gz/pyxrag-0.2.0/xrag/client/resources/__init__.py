"""Resource namespaces exposed by :class:`xrag.client.xrag.Xrag`."""

from xrag.client.resources.documents import DocumentsResource
from xrag.client.resources.rag import RagResource
from xrag.client.resources.retrievals import RetrievalsResource

__all__ = ["DocumentsResource", "RetrievalsResource", "RagResource"]
