"""Document operations exposed under ``client.documents``."""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import os
import shutil
import socket
import uuid
from collections.abc import Iterator
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any, BinaryIO

from xrag.client.resources._tenant import resolve_tenant
from xrag.config.models import SourceConfig
from xrag.errors import (
    XragArtifactsError,
    XragChunksInvalid,
    XragDocumentNotFound,
    XragError,
    XragValidationError,
)
from xrag.models.chunk_adapters import (
    chunk_to_payload,
    chunks_from_internal_json,
    payload_to_chunk,
)
from xrag.models.document import Chunk, ChunksPage, Document, DocumentStatus

if TYPE_CHECKING:
    from xrag.client.xrag import Xrag

logger = logging.getLogger(__name__)

_EXPORT_PAGE_SIZE = 256
_INDEX_EMBED_BATCH = 100
_LOCK_FILENAME = ".xrag_ingest.lock"


def _should_keep_artifacts(*, was_ephemeral: bool, keep: bool | None, success: bool) -> bool:
    """Return whether ingest artifacts should be kept after a run."""
    if keep is True:
        return True
    if keep is False:
        # Explicit path is caller-owned; preserve it on failure even with keep=False.
        return False if success else not was_ephemeral
    if was_ephemeral:
        return not success
    return True


@contextlib.contextmanager
def _ingest_lock(
    artifacts_dir: Path | None,
    *,
    document_id: str,
    source_name: str,
) -> Iterator[None]:
    """Lock an artifacts directory for the duration of one ingest."""
    if artifacts_dir is None:
        yield
        return

    lock_path = artifacts_dir / _LOCK_FILENAME
    try:
        artifacts_dir.mkdir(parents=True, exist_ok=True)
        fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o644)
    except FileExistsError as exc:
        try:
            holder = json.loads(lock_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            holder = {}
        raise XragArtifactsError(
            f"another ingest is already running against {artifacts_dir}",
            code="artifacts_path_collision",
            detail=holder,
        ) from exc
    except OSError as exc:
        raise XragArtifactsError(
            f"failed to create lock file at {lock_path}: {exc}",
            code="artifacts_dir_unwritable",
        ) from exc

    try:
        from xrag import __version__ as xrag_version

        payload = {
            "pid": os.getpid(),
            "hostname": socket.gethostname(),
            "started_at": datetime.now(UTC).isoformat(),
            "document_id": document_id,
            "source_name": source_name,
            "xrag_version": xrag_version,
        }
        os.write(fd, json.dumps(payload).encode("utf-8"))
    finally:
        os.close(fd)

    try:
        yield
    finally:
        # Release on both success and failure so a crashed run doesn't permanently block the dir.
        with contextlib.suppress(OSError):
            lock_path.unlink(missing_ok=True)


def _embed_and_store(
    embedding: Any,
    vs: Any,
    chunks: list[Chunk],
    tenant_id: str,
    document_id: str,
    embed_opts: dict[str, Any],
    model_tag: str | None,
) -> int:
    """Embed chunks in batches and upsert them into the vector store."""
    texts = [c.text for c in chunks]
    all_embeddings: list[list[float]] = []
    for i in range(0, len(texts), _INDEX_EMBED_BATCH):
        batch = texts[i : i + _INDEX_EMBED_BATCH]
        all_embeddings.extend(embedding.embed_texts(batch, embed_opts))

    payloads = [
        chunk_to_payload(c, tenant_id=tenant_id, document_id=document_id, model_tag=model_tag)
        for c in chunks
    ]
    for i in range(0, len(payloads), _INDEX_EMBED_BATCH):
        vs.add_chunks(
            payloads[i : i + _INDEX_EMBED_BATCH],
            all_embeddings[i : i + _INDEX_EMBED_BATCH],
            {},
        )
    return len(chunks)


class DocumentsResource:
    def __init__(self, client: Xrag, *, bound_tenant: str | None = None) -> None:
        self._client = client
        self._bound_tenant = bound_tenant

    async def ingest(
        self,
        source: str | Path | bytes | BinaryIO,
        *,
        collection: str,
        tenant_id: str | None = None,
        external_id: str | None = None,
        name: str | None = None,
        metadata: dict[str, Any] | None = None,
        enrichment: tuple[str, ...] | None = None,
        artifacts_dir: str | Path | None = None,
        keep_artifacts: bool | None = None,
    ) -> Document:
        """Ingest one document and return its resulting document record.

        Args:
            keep_artifacts: ``None`` keeps ephemeral dirs only on failure and
                always preserves explicit paths. ``True`` never auto-deletes.
                ``False`` deletes on success and wipes ephemeral dirs on failure.
                When kept, ``Document.metadata['artifacts_dir']`` holds the path.
        """
        effective_tenant = resolve_tenant(self._bound_tenant, tenant_id)
        document_id = "doc_" + uuid.uuid4().hex[:24]

        if enrichment is not None:
            self._client._validate_enrichment(enrichment)

        self._client._check_external_id_conflict(
            tenant_id=effective_tenant,
            collection=collection,
            external_id=external_id,
        )

        source_path = await asyncio.to_thread(
            self._materialize_source,
            source,
            effective_tenant,
            name,
        )

        effective_artifacts_dir, was_ephemeral = self._client._resolve_artifact_dir(artifacts_dir)

        def _do() -> Document:
            from xrag.models.ingest import IngestRequest
            from xrag.pipelines.ingest import run_ingest

            cfg = self._client._build_app_config(
                tenant_id=effective_tenant,
                collection=collection,
                sources=[SourceConfig(path=source_path, doc_id=document_id)],
                doc_ids=[document_id],
                artifact_dir=effective_artifacts_dir,
                enrichment_override=enrichment,
            )
            with _ingest_lock(
                effective_artifacts_dir,
                document_id=document_id,
                source_name=source_path.name,
            ):
                try:
                    ingest_result = run_ingest(IngestRequest(config=cfg))
                except XragError:
                    raise
                except Exception as e:
                    raise XragError(f"ingest failed: {e}", code="ingest_failed") from e

            now = datetime.now(UTC)
            chunk_count = (
                ingest_result.indexing.chunk_count if ingest_result.indexing is not None else None
            )
            doc = Document(
                id=document_id,
                tenant_id=effective_tenant,
                collection=collection,
                name=name or source_path.name,
                external_id=external_id,
                status=DocumentStatus.READY,
                chunk_count=chunk_count,
                created_at=now,
                updated_at=now,
                metadata=dict(metadata or {}),
            )
            self._client._doc_registry[document_id] = doc
            return doc

        success = False
        doc: Document | None = None
        try:
            doc = await asyncio.to_thread(_do)
            success = True
        finally:
            keep = _should_keep_artifacts(
                was_ephemeral=was_ephemeral, keep=keep_artifacts, success=success
            )
            if not keep:
                shutil.rmtree(effective_artifacts_dir, ignore_errors=True)
            elif success and doc is not None:
                doc.metadata = {
                    **doc.metadata,
                    "artifacts_dir": str(effective_artifacts_dir),
                }

        # Stale BM25 cache after new chunks landed.
        self._client._invalidate_retrievers(collection)
        return doc  # type: ignore[return-value]

    async def get(self, document_id: str, *, tenant_id: str | None = None) -> Document:
        """Look up a document in this client's in-memory registry.

        The registry is process-local and populated by ``ingest`` / ``index_chunks``
        on this same client; persistent storage belongs to the wire-API consumer.

        Raises:
            XragDocumentNotFound: ``document_id`` is unknown to this client.
        """
        effective_tenant = resolve_tenant(self._bound_tenant, tenant_id)
        doc = self._client._doc_registry.get(document_id)
        if doc is None or doc.tenant_id != effective_tenant:
            raise XragDocumentNotFound(
                f"document {document_id!r} not found for tenant {effective_tenant!r}"
            )
        return doc

    async def list_chunks(
        self,
        document_id: str,
        *,
        tenant_id: str | None = None,
        cursor: str | None = None,
        limit: int = 50,
    ) -> ChunksPage:
        """List chunks for a document, paginated by Qdrant scroll cursor.

        Pass ``next_cursor`` back as ``cursor=`` to fetch the following page;
        ``next_cursor=None`` signals end of pages. Document resolution shares
        the registry caveat from :meth:`get`.

        Raises:
            XragDocumentNotFound: Document not registered on this client.
            XragValidationError: ``limit`` out of ``[1, 1000]``.
        """
        effective_tenant = resolve_tenant(self._bound_tenant, tenant_id)
        if limit < 1 or limit > 1000:
            raise XragValidationError("limit must be in [1, 1000]", code="limit_out_of_range")

        doc = self._client._doc_registry.get(document_id)
        if doc is None or doc.tenant_id != effective_tenant:
            raise XragDocumentNotFound(
                f"document {document_id!r} not found for tenant {effective_tenant!r}"
            )

        vs = self._client._get_vector_store(doc.collection)
        payloads, next_offset = await asyncio.to_thread(
            vs.scroll,
            filter={"tenant_id": effective_tenant, "document_id": document_id},
            limit=limit,
            offset=cursor,
        )
        return ChunksPage(
            chunks=[payload_to_chunk(p) for p in payloads],
            next_cursor=str(next_offset) if next_offset is not None else None,
            total=None,
        )

    async def delete(
        self,
        document_id: str,
        *,
        tenant_id: str | None = None,
    ) -> None:
        """Delete a document's chunks from Qdrant and drop its registry entry.

        Resolution shares the registry caveat from :meth:`get`; after a
        process restart, callers must drop into the vector store directly
        (``vs.delete_by_filter({...})``) or rebuild the registry. On
        vector-store failure the registry entry is preserved for retry.

        Raises:
            XragDocumentNotFound: Document not registered on this client.
        """
        effective_tenant = resolve_tenant(self._bound_tenant, tenant_id)
        doc = self._client._doc_registry.get(document_id)
        if doc is None or doc.tenant_id != effective_tenant:
            raise XragDocumentNotFound(
                f"document {document_id!r} not found for tenant {effective_tenant!r}"
            )

        vs = self._client._get_vector_store(doc.collection)
        await asyncio.to_thread(
            vs.delete_by_filter,
            {"tenant_id": effective_tenant, "document_id": document_id},
        )
        # Pop only after the delete succeeds so a partial failure can be retried.
        self._client._doc_registry.pop(document_id, None)
        self._client._invalidate_retrievers(doc.collection)

    async def index_chunks(
        self,
        chunks: list[Chunk] | str | Path,
        *,
        collection: str,
        tenant_id: str | None = None,
        document_id: str | None = None,
        external_id: str | None = None,
        name: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Document:
        """Index pre-chunked data into a collection.

        The input is validated, embedded, stored in the vector store,
        and registered as a ready document on this client.

        Args:
            chunks: A list of :class:`Chunk` objects, a list of dicts with
                ``id``/``text`` keys, or a ``str``/``Path`` to a JSON
                envelope written by :meth:`export_chunks`.
            collection: Target collection name.
            tenant_id: Multi-tenant scope tag.
            document_id: Optional fixed id; auto-generated if absent.
            external_id: Caller-supplied external reference.
            name: Human-readable name stored on the returned Document.
            metadata: Additional metadata stored on the returned Document.

        Raises:
            XragChunksInvalid: Validation failed (duplicate ids, reserved
                metadata keys, missing required fields, …).
            XragValidationError: File not found or empty chunk list.
        """
        from xrag.models.chunks import validate_chunks, validate_chunks_file

        effective_tenant = resolve_tenant(self._bound_tenant, tenant_id)

        self._client._check_external_id_conflict(
            tenant_id=effective_tenant,
            collection=collection,
            external_id=external_id,
        )

        if isinstance(chunks, (str, Path)):
            p = Path(chunks)
            if not p.exists():
                raise XragValidationError(f"chunks file not found: {p}", code="source_not_found")
            report = validate_chunks_file(p)
            if not report.ok:
                raise XragChunksInvalid(
                    f"chunks file failed validation with {len(report.errors)} error(s)",
                    detail=report.errors,
                )
            chunk_list: list[Chunk] = chunks_from_internal_json(p)
        else:
            report = validate_chunks(chunks)
            if not report.ok:
                raise XragChunksInvalid(
                    f"chunks failed validation with {len(report.errors)} error(s)",
                    detail=report.errors,
                )
            chunk_list = [c if isinstance(c, Chunk) else payload_to_chunk(c) for c in chunks]

        if not chunk_list:
            raise XragValidationError("chunk list is empty", code="chunks_empty")

        doc_id = document_id or "doc_" + uuid.uuid4().hex[:24]

        embedding = self._client._get_embedding()
        vs = self._client._get_vector_store(collection)
        embed_cfg = self._client._embedding_cfg
        embed_opts: dict[str, Any] = dict(embed_cfg.options) if embed_cfg else {}
        model_tag: str | None = None
        if embed_cfg:
            raw_model = embed_cfg.options.get("model")
            model_tag = f"{raw_model}" if isinstance(raw_model, str) else embed_cfg.provider

        chunk_count = await asyncio.to_thread(
            _embed_and_store,
            embedding,
            vs,
            chunk_list,
            effective_tenant,
            doc_id,
            embed_opts,
            model_tag,
        )

        now = datetime.now(UTC)
        doc = Document(
            id=doc_id,
            tenant_id=effective_tenant,
            collection=collection,
            name=name or f"chunks_{doc_id[:8]}",
            external_id=external_id,
            status=DocumentStatus.READY,
            chunk_count=chunk_count,
            created_at=now,
            updated_at=now,
            metadata=dict(metadata or {}),
        )
        self._client._doc_registry[doc_id] = doc
        self._client._invalidate_retrievers(collection)
        return doc

    async def export_chunks(
        self,
        *,
        collection: str,
        document_id: str | None = None,
        tenant_id: str | None = None,
        output: str | Path | None = None,
        include_embeddings: bool = False,
    ) -> list[Chunk] | Path:
        """Export chunks to memory or to a JSON envelope file.

        Exported files are written through a temporary sibling path and
        renamed atomically at the end.

        Args:
            collection: Required.
            document_id: Restrict export to this doc; ``None`` ⇒ entire
                collection (filtered by tenant_id).
            tenant_id: Multi-tenant filter, applied unconditionally.
            output: ``None`` ⇒ return ``list[Chunk]`` in memory.
                ``Path`` ⇒ write a JSON envelope and return the path.
            include_embeddings: Attach each chunk's embedding under
                ``metadata.__embedding__``. Off by default — vectors are
                large (~6 KB per 1536-dim float32 chunk).
        """
        effective_tenant = resolve_tenant(self._bound_tenant, tenant_id)
        filter_dict: dict[str, Any] = {"tenant_id": effective_tenant}
        if document_id is not None:
            filter_dict["document_id"] = document_id

        vs = self._client._get_vector_store(collection)

        if output is None:
            return await asyncio.to_thread(
                self._scroll_to_list,
                vs,
                filter_dict,
                include_embeddings,
            )

        out_path = Path(output)
        return await asyncio.to_thread(
            self._scroll_to_file,
            vs,
            filter_dict,
            out_path,
            include_embeddings,
        )

    @staticmethod
    def _scroll_to_list(
        vs: Any, filter_dict: dict[str, Any], include_embeddings: bool
    ) -> list[Chunk]:
        chunks: list[Chunk] = []
        offset: Any = None
        while True:
            payloads, offset = vs.scroll(
                filter=filter_dict,
                limit=_EXPORT_PAGE_SIZE,
                offset=offset,
                with_vectors=include_embeddings,
            )
            for p in payloads:
                chunks.append(payload_to_chunk(p, include_embedding=include_embeddings))
            if offset is None:
                break
        return chunks

    def _scroll_to_file(
        self,
        vs: Any,
        filter_dict: dict[str, Any],
        out_path: Path,
        include_embeddings: bool,
    ) -> Path:
        """Write an export envelope through a temporary sibling file."""
        from xrag import __version__ as xrag_version

        out_path.parent.mkdir(parents=True, exist_ok=True)
        tmp_path = out_path.with_suffix(out_path.suffix + ".tmp")

        embedding_model: str | None = None
        if include_embeddings and self._client._embedding_cfg is not None:
            model = self._client._embedding_cfg.options.get("model")
            if isinstance(model, str):
                embedding_model = f"{self._client._embedding_cfg.provider}:{model}"

        try:
            with tmp_path.open("w", encoding="utf-8") as f:
                f.write("{\n")
                f.write('  "schema_version": "1",\n')
                f.write(f'  "generated_by": "xrag@{xrag_version}",\n')
                f.write(f'  "embedding_model": {json.dumps(embedding_model)},\n')
                f.write(f'  "exported_at": "{datetime.now(UTC).isoformat()}",\n')
                f.write('  "chunks": [\n')

                offset: Any = None
                first = True
                count = 0
                while True:
                    payloads, offset = vs.scroll(
                        filter=filter_dict,
                        limit=_EXPORT_PAGE_SIZE,
                        offset=offset,
                        with_vectors=include_embeddings,
                    )
                    for p in payloads:
                        chunk = payload_to_chunk(p, include_embedding=include_embeddings)
                        prefix = "    " if first else ",\n    "
                        f.write(prefix)
                        f.write(chunk.model_dump_json())
                        first = False
                        count += 1
                    if offset is None:
                        break

                f.write("\n  ]\n}\n")
        except Exception:
            tmp_path.unlink(missing_ok=True)
            raise

        tmp_path.replace(out_path)
        logger.debug("exported %d chunks to %s", count, out_path)
        return out_path

    def _materialize_source(
        self,
        source: str | Path | bytes | BinaryIO,
        tenant_id: str,
        name: str | None,
    ) -> Path:
        """Return a local file path for the ingest source.

        Bytes and file-like objects are spooled into ``upload_dir/<tenant>/``.
        """
        upload_dir = self._client._upload_dir / tenant_id
        upload_dir.mkdir(parents=True, exist_ok=True)

        if isinstance(source, (str, Path)):
            p = Path(source)
            if not p.exists():
                raise XragValidationError(
                    f"source path does not exist: {p}", code="source_not_found"
                )
            return p

        if isinstance(source, (bytes, bytearray)):
            target = upload_dir / (name or f"upload_{uuid.uuid4().hex[:12]}.bin")
            target.write_bytes(bytes(source))
            return target

        target = upload_dir / (name or f"upload_{uuid.uuid4().hex[:12]}.bin")
        with target.open("wb") as fh:
            while True:
                chunk = source.read(1024 * 1024)
                if not chunk:
                    break
                fh.write(chunk)
        return target
