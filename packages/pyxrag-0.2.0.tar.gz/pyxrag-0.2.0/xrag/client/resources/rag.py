"""RAG operations exposed under ``client.rag``."""

from __future__ import annotations

import asyncio
import logging
import time
import uuid
from typing import TYPE_CHECKING, Any

from xrag.client.resources._chunk_convert import to_scored_chunk
from xrag.client.resources._tenant import resolve_tenant
from xrag.errors import XragError, XragGenerationNotConfigured
from xrag.models.rag import RagResult, TokenUsage

if TYPE_CHECKING:
    from xrag.client.xrag import Xrag

logger = logging.getLogger(__name__)


class RagResource:
    def __init__(self, client: Xrag, *, bound_tenant: str | None = None) -> None:
        self._client = client
        self._bound_tenant = bound_tenant

    async def ask(
        self,
        *,
        query: str,
        collection: str,
        tenant_id: str | None = None,
        top_k: int = 10,
        filter: dict[str, Any] | None = None,
        rerank: bool | None = None,
    ) -> RagResult:
        """Retrieve context and generate an answer.

        Raises:
            XragGenerationNotConfigured: The client was built without a
                generation provider.
        """
        if self._client._generation_cfg is None:
            raise XragGenerationNotConfigured(
                "client.rag.ask requires `generation=` to be configured at construction. "
                "Either pass generation='openai:gpt-4.1-nano' (or equivalent) to Xrag(...), "
                "or use client.retrievals.search and run your own LLM over the chunks."
            )

        effective_tenant = resolve_tenant(self._bound_tenant, tenant_id)
        request_id = "req_" + uuid.uuid4().hex[:24]

        retriever = self._client._get_retriever(collection, hybrid=True)
        generator = self._client._get_generator()

        retrieval_cfg = self._client._retrieval_defaults.model_copy(deep=True)
        options = dict(retrieval_cfg.options or {})
        options["top_k"] = top_k
        options["filter"] = {
            **(options.get("filter") or {}),
            **(filter or {}),
            "tenant_id": effective_tenant,
        }
        retrieval_cfg.options = options

        wants_rerank = bool(rerank) if rerank is not None else False
        reranker = self._client._get_reranker() if wants_rerank else None

        from xrag.pipelines.helpers import run_retrieval

        gen_options = dict(self._client._generation_cfg.options or {})

        def _retrieve_then_generate() -> tuple[list[dict], dict]:
            retrieved = run_retrieval(retriever, reranker, query, retrieval_cfg)
            gen_result = generator.generate(query, retrieved, gen_options)
            return retrieved, gen_result

        t0 = time.perf_counter()
        try:
            retrieved, gen = await asyncio.to_thread(_retrieve_then_generate)
        except XragError:
            raise
        except Exception as e:
            raise XragError(
                f"rag.ask failed: {e}", code="rag_ask_failed", request_id=request_id
            ) from e
        took_ms = int((time.perf_counter() - t0) * 1000)

        usage = None
        if isinstance(gen.get("usage"), dict):
            u = gen["usage"]
            usage = TokenUsage(
                prompt_tokens=int(u.get("prompt_tokens") or 0),
                completion_tokens=int(u.get("completion_tokens") or 0),
                total_tokens=int(u.get("total_tokens") or 0),
            )

        return RagResult(
            answer=gen["answer"],
            chunks=[to_scored_chunk(c) for c in retrieved],
            model=gen["model"],
            usage=usage,
            took_ms=took_ms,
            request_id=request_id,
        )
