"""Parse public provider strings into internal provider configs.

Examples:
    ``"openai:gpt-4.1-nano"``
    ``"openai:text-embedding-3-small"``
    ``"cohere:rerank-v3.5"``
"""

from __future__ import annotations

from typing import Literal

from xrag.config.models import ProviderConfig
from xrag.errors import XragValidationError

ProviderRole = Literal["embedding", "generation", "reranker", "tracing"]

# role -> set of accepted prefixes
_ROLE_PREFIXES: dict[ProviderRole, frozenset[str]] = {
    "embedding": frozenset({"openai"}),
    "generation": frozenset({"openai"}),
    "reranker": frozenset({"cohere"}),
    "tracing": frozenset({"langsmith"}),
}

_HUMAN_ROLE: dict[ProviderRole, str] = {
    "embedding": "embedding model",
    "generation": "generation model",
    "reranker": "reranker",
    "tracing": "tracer",
}


def parse_provider(spec: str | None, *, role: ProviderRole) -> ProviderConfig | None:
    """Parse a ``"prefix:identifier"`` provider string for the given role.

    Args:
        spec: A provider string (e.g. ``"openai:text-embedding-3-small"``)
            or ``None`` to indicate "no provider configured for this role".
        role: Which client role this string is for. Determines which
            prefixes are accepted.

    Returns:
        A :class:`ProviderConfig` ready to feed into the existing factory
        functions, or ``None`` when ``spec`` is ``None``.

    Raises:
        XragValidationError: ``spec`` doesn't follow the
            ``prefix:identifier`` shape, or the prefix is not in the
            v0.2 registry for the given role.
    """
    if spec is None:
        return None
    if ":" not in spec:
        raise XragValidationError(
            f"{_HUMAN_ROLE[role]} provider must be a 'prefix:identifier' string; got {spec!r}",
            code="provider_string_malformed",
        )

    prefix, _, identifier = spec.partition(":")
    prefix = prefix.strip().lower()
    identifier = identifier.strip()

    if not identifier:
        raise XragValidationError(
            f"{_HUMAN_ROLE[role]} provider missing identifier after ':' in {spec!r}",
            code="provider_string_malformed",
        )

    accepted = _ROLE_PREFIXES[role]
    if prefix not in accepted:
        raise XragValidationError(
            (
                f"unknown {_HUMAN_ROLE[role]} provider prefix {prefix!r}; "
                f"v0.2 supports {sorted(accepted)} for this role"
            ),
            code="unknown_provider",
        )

    return ProviderConfig(provider=prefix, options={"model": identifier})
