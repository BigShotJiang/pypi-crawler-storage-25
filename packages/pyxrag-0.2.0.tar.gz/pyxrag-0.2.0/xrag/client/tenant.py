"""Tenant-bound view of :class:`xrag.client.xrag.Xrag`.

Returned by :meth:`xrag.client.xrag.Xrag.for_tenant`; resource methods on this
view reject per-call ``tenant_id`` arguments.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from xrag.client.resources.documents import DocumentsResource
    from xrag.client.resources.rag import RagResource
    from xrag.client.resources.retrievals import RetrievalsResource
    from xrag.client.xrag import Xrag


class XragTenant:
    """Thin proxy that binds a tenant to the client resources."""

    def __init__(self, client: Xrag, tenant_id: str) -> None:
        self._client = client
        self._tenant_id = tenant_id

    @property
    def tenant_id(self) -> str:
        return self._tenant_id

    @property
    def documents(self) -> DocumentsResource:
        from xrag.client.resources.documents import DocumentsResource as _R

        return _R(self._client, bound_tenant=self._tenant_id)

    @property
    def retrievals(self) -> RetrievalsResource:
        from xrag.client.resources.retrievals import RetrievalsResource as _R

        return _R(self._client, bound_tenant=self._tenant_id)

    @property
    def rag(self) -> RagResource:
        from xrag.client.resources.rag import RagResource as _R

        return _R(self._client, bound_tenant=self._tenant_id)
