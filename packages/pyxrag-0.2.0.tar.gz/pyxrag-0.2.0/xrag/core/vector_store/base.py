"""Base contract for vector store providers."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class BaseVectorStore(ABC):
    """Store embedded chunks and query them by similarity."""

    @abstractmethod
    def add_chunks(
        self,
        chunks: list[dict[str, Any]],
        embeddings: list[list[float]],
        options: dict[str, Any],
    ) -> int:
        """Store chunks with precomputed embeddings.

        Args:
            chunks: Chunk records to store.
            embeddings: Embedding vectors, one per chunk.
            options: Provider-specific store options.

        Returns:
            The number of chunks stored.
        """
        raise NotImplementedError

    @abstractmethod
    def query(
        self,
        query_embedding: list[float],
        top_k: int,
        options: dict[str, Any],
    ) -> list[dict[str, Any]]:
        """Retrieve the top-k most similar chunks.

        Args:
            query_embedding: The query embedding vector.
            top_k: Maximum number of results to return.
            options: Provider-specific query options.

        Returns:
            Chunk dicts augmented with a ``score`` field, sorted by relevance.
        """
        raise NotImplementedError

    @abstractmethod
    def get_all(self) -> list[dict[str, Any]]:
        """Return all stored chunks without embeddings.

        Returns:
            List of chunk dicts, each with at least ``chunk_id`` and ``content``.
        """
        raise NotImplementedError

    def scroll(
        self,
        *,
        filter: dict[str, Any] | None = None,
        limit: int = 50,
        offset: Any = None,
        with_vectors: bool = False,
    ) -> tuple[list[dict[str, Any]], Any]:
        """Scan stored chunks with cursor-based pagination.

        Args:
            filter: Optional payload filter.
            limit: Max chunks to return in this page.
            offset: Opaque cursor returned by a prior call.
            with_vectors: Whether to include stored vectors in the result.

        Returns:
            ``(chunks, next_offset)``.

        Raises:
            NotImplementedError: Provider does not support scrolling.
        """
        raise NotImplementedError(
            f"{type(self).__name__} does not implement scroll(); "
            "use a Qdrant-backed store for documents.list_chunks / export_chunks"
        )

    def delete_by_filter(self, filter: dict[str, Any]) -> None:
        """Delete every point matching a payload filter.

        Args:
            filter: Non-empty payload filter.

        Raises:
            ValueError: ``filter`` is empty.
            NotImplementedError: Provider has no filter-delete support.
        """
        raise NotImplementedError(
            f"{type(self).__name__} does not implement delete_by_filter(); "
            "use a Qdrant-backed store for documents.delete"
        )

    @abstractmethod
    def delete_collection(self) -> bool:
        """Delete the configured collection from the backend.

        Returns:
            True if the collection existed and was deleted, False if the
            collection did not exist.
        """
        raise NotImplementedError

    def close(self) -> None:
        """Release any resources held by the store (file locks, sockets).

        Default no-op for in-process providers without persistent
        handles. Local Qdrant must override to drop its flock so a
        subsequent client (e.g. an indexer running in the same process
        right after a reset) can open the same path.
        """
        return
