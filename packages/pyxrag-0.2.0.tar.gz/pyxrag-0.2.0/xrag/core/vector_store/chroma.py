from __future__ import annotations

import json
from typing import Any

import chromadb

from xrag.core.vector_store.base import BaseVectorStore


class ChromaVectorStore(BaseVectorStore):
    """ChromaDB vector store provider.

    Collection creation is lazy: ``__init__`` only opens the client.
    ``add_chunks`` / ``query`` / ``get_all`` materialize the collection
    on first use via ``get_or_create_collection``. This keeps
    ``delete_collection`` honest — instantiating the store to delete
    a collection does not first re-create it.
    """

    def __init__(
        self,
        collection_name: str = "default",
        persist_directory: str | None = None,
    ) -> None:
        if persist_directory:
            self._client = chromadb.PersistentClient(path=persist_directory)
        else:
            self._client = chromadb.EphemeralClient()
        self._collection_name = collection_name
        self._collection: chromadb.Collection | None = None

    def _get_collection(self) -> chromadb.Collection:
        """Return the underlying Chroma collection, creating it on first use."""
        if self._collection is None:
            self._collection = self._client.get_or_create_collection(
                name=self._collection_name,
                metadata={"hnsw:space": "cosine"},
            )
        return self._collection

    def add_chunks(
        self,
        chunks: list[dict[str, Any]],
        embeddings: list[list[float]],
        options: dict[str, Any],
    ) -> int:
        """Store chunks with embeddings in ChromaDB.

        Args:
            chunks: Chunk records with at least ``chunk_id`` and ``content`` fields.
            embeddings: Embedding vectors, one per chunk.
            options: Provider-specific options (unused).

        Returns:
            The number of chunks stored.
        """
        ids = [chunk.get("chunk_id", str(i)) for i, chunk in enumerate(chunks)]
        documents = [chunk.get("content", "") for chunk in chunks]
        metadatas_raw = [_extract_metadata(chunk) for chunk in chunks]
        metadatas = [m if m else None for m in metadatas_raw]
        has_any_metadata = any(m is not None for m in metadatas)

        self._get_collection().upsert(
            ids=ids,
            embeddings=embeddings,
            documents=documents,
            metadatas=metadatas if has_any_metadata else None,
        )
        return len(chunks)

    def query(
        self,
        query_embedding: list[float],
        top_k: int,
        options: dict[str, Any],
    ) -> list[dict[str, Any]]:
        """Retrieve top-k chunks by cosine similarity from ChromaDB.

        Args:
            query_embedding: The query embedding vector.
            top_k: Maximum number of results.
            options: Provider-specific options (unused).

        Returns:
            Chunk dicts with ``score``, ``chunk_id``, ``content``, and metadata fields.
        """
        results = self._get_collection().query(
            query_embeddings=[query_embedding],
            n_results=top_k,
            include=["documents", "metadatas", "distances"],
        )

        chunks: list[dict[str, Any]] = []
        for i in range(len(results["ids"][0])):
            chunk: dict[str, Any] = {
                "chunk_id": results["ids"][0][i],
                "content": results["documents"][0][i],
                "score": 1.0 - results["distances"][0][i],
            }
            if results["metadatas"] and results["metadatas"][0][i]:
                metadata = _deserialize_metadata(results["metadatas"][0][i])
                chunk.update(metadata)
            chunks.append(chunk)
        return chunks

    def get_all(self) -> list[dict[str, Any]]:
        """Return all stored chunks from ChromaDB without embeddings.

        Args:
            None.

        Returns:
            List of chunk dicts with ``chunk_id``, ``content``, and metadata fields.
        """
        results = self._get_collection().get(include=["documents", "metadatas"])
        chunks: list[dict[str, Any]] = []
        for i, chunk_id in enumerate(results["ids"]):
            chunk: dict[str, Any] = {
                "chunk_id": chunk_id,
                "content": results["documents"][i] if results["documents"] else "",
            }
            if results["metadatas"] and results["metadatas"][i]:
                metadata = _deserialize_metadata(results["metadatas"][i])
                chunk.update(metadata)
            chunks.append(chunk)
        return chunks

    def delete_collection(self) -> bool:
        """Delete the configured collection from ChromaDB.

        A subsequent ``add_chunks`` / ``query`` call will lazily
        recreate the collection via ``get_or_create_collection``.

        Args:
            None.

        Returns:
            True if the collection existed and was deleted, False otherwise.
        """
        existing = {c.name for c in self._client.list_collections()}
        if self._collection_name not in existing:
            return False
        self._client.delete_collection(name=self._collection_name)
        self._collection = None
        return True


def _extract_metadata(chunk: dict[str, Any]) -> dict[str, str | int | float | bool]:
    """Extract Chroma-safe metadata from a chunk record.

    Args:
        chunk: A chunk record dict.

    Returns:
        Flat metadata dict with only str/int/float/bool values.
    """
    metadata: dict[str, str | int | float | bool] = {}
    # Scalar fields persisted as-is
    for key in (
        "doc_id",
        "chunk_type",
        "chunk_strategy",
        "page_number",
        "content_with_weight",
        "important_tks",
        "question_tks",
        # Table + RAGFlow alias fields needed at retrieval / generation time
        "table_html",
        "table_text",
        "table_text_markdown",
        "pre_text",
        "post_text",
        "docnm_kwd",
        "doc_type_kwd",
        "parent_chunk_id",
        # MVP 3 Gap 2b hygiene: prompt-budget accounting + migration guard.
        "token_count",
        "embedding_model",
    ):
        if key in chunk and chunk[key] is not None:
            metadata[key] = chunk[key]
    # List fields: JSON-serialize (Chroma requires scalar values)
    for key in ("heading_path", "important_kwd", "question_kwd", "tag_kwd", "position_int"):
        if key in chunk and chunk[key]:
            metadata[key] = json.dumps(chunk[key])
    return metadata


def _deserialize_metadata(metadata: dict[str, Any]) -> dict[str, Any]:
    """Decode metadata fields serialized for Chroma compatibility."""
    decoded = dict(metadata)
    for key in ("heading_path", "important_kwd", "question_kwd", "tag_kwd", "position_int"):
        if key in decoded:
            decoded[key] = json.loads(decoded[key])
    return decoded
