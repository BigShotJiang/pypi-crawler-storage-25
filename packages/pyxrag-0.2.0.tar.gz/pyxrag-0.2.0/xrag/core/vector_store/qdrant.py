from __future__ import annotations

import logging
import uuid
from typing import Any

from qdrant_client import QdrantClient
from qdrant_client.models import (
    Distance,
    FieldCondition,
    Filter,
    KeywordIndexParams,
    KeywordIndexType,
    MatchAny,
    MatchValue,
    PayloadSchemaType,
    PointStruct,
    VectorParams,
)

from xrag.core.vector_store.base import BaseVectorStore

logger = logging.getLogger(__name__)

# Payload fields that get a Qdrant payload index when the collection is
# created. ``tenant_id`` uses the ``is_tenant=True`` flag so points with
# the same tenant are physically co-located on disk (Qdrant's
# multitenancy optimization, ≥ 1.11).
_TENANT_KEY = "tenant_id"
_KEYWORD_INDEX_KEYS = ("doc_id", "chunk_strategy", "embedding_model")

_POINT_ID_NAMESPACE = uuid.UUID("6ba7b810-9dad-11d1-80b4-00c04fd430c8")


class QdrantVectorStore(BaseVectorStore):
    """Qdrant vector store provider.

    Supports three deployment modes, selected by constructor args:

    * ``path=":memory:"`` — in-process, in-memory storage (tests, experiments).
    * ``path="<dir>"`` — local on-disk persistent storage.
    * ``url="..."`` with optional ``api_key`` — remote server or Qdrant Cloud.

    Collection creation is deferred until the first ``add_chunks`` call so the
    vector dimension can be inferred from the embeddings.
    """

    def __init__(
        self,
        collection_name: str = "default",
        url: str | None = None,
        api_key: str | None = None,
        path: str | None = None,
        prefer_grpc: bool = False,
        distance: str = "cosine",
        client: QdrantClient | None = None,
    ) -> None:
        if client is not None:
            # Caller-managed client (typically the per-Xrag shared instance).
            # We borrow it for the lifetime of this store and skip closing it
            # on ``close()`` — the owner handles teardown.
            self._client = client
            self._owns_client = False
        else:
            if path is not None:
                if path == ":memory:":
                    self._client = QdrantClient(location=":memory:")
                else:
                    self._client = QdrantClient(path=path)
            elif url is not None:
                self._client = QdrantClient(url=url, api_key=api_key, prefer_grpc=prefer_grpc)
            else:
                self._client = QdrantClient(location=":memory:")
            self._owns_client = True
        self._collection_name = collection_name
        self._distance = _resolve_distance(distance)

    def add_chunks(
        self,
        chunks: list[dict[str, Any]],
        embeddings: list[list[float]],
        options: dict[str, Any],
    ) -> int:
        """Store chunks with embeddings in Qdrant.

        Args:
            chunks: Chunk records with at least ``chunk_id`` and ``content`` fields.
            embeddings: Embedding vectors, one per chunk.
            options: Provider-specific options (unused).

        Returns:
            The number of chunks stored.
        """
        if not chunks:
            return 0
        self._ensure_collection(len(embeddings[0]))

        points: list[PointStruct] = []
        for chunk, vector in zip(chunks, embeddings, strict=True):
            chunk_id = str(chunk.get("chunk_id", ""))
            points.append(
                PointStruct(
                    id=_point_id(chunk_id),
                    vector=vector,
                    payload=_build_payload(chunk),
                )
            )
        self._client.upsert(
            collection_name=self._collection_name,
            points=points,
            wait=True,
        )
        return len(points)

    def query(
        self,
        query_embedding: list[float],
        top_k: int,
        options: dict[str, Any],
    ) -> list[dict[str, Any]]:
        """Retrieve top-k chunks by vector similarity from Qdrant.

        Args:
            query_embedding: The query embedding vector.
            top_k: Maximum number of results.
            options: Provider-specific options. Recognized keys:
                ``filter`` — dict mapping payload key → value (scalar
                for equality, list for IN match). Forwarded to Qdrant
                as a ``must``-only filter.

        Returns:
            Chunk dicts with ``score``, ``chunk_id``, ``content``, and metadata fields.
        """
        qdrant_filter = _build_qdrant_filter(options.get("filter"))

        response = self._client.query_points(
            collection_name=self._collection_name,
            query=query_embedding,
            limit=top_k,
            with_payload=True,
            query_filter=qdrant_filter,
        )

        chunks: list[dict[str, Any]] = []
        for point in response.points:
            payload = dict(point.payload or {})
            payload["score"] = float(point.score)
            chunks.append(payload)
        return chunks

    def get_all(self) -> list[dict[str, Any]]:
        """Return all stored chunks from Qdrant without embeddings.

        Args:
            None.

        Returns:
            List of chunk dicts with ``chunk_id``, ``content``, and metadata fields.
        """
        results: list[dict[str, Any]] = []
        offset: Any = None
        while True:
            points, offset = self._client.scroll(
                collection_name=self._collection_name,
                limit=256,
                offset=offset,
                with_payload=True,
                with_vectors=False,
            )
            for point in points:
                results.append(dict(point.payload or {}))
            if offset is None:
                break
        return results

    def scroll(
        self,
        *,
        filter: dict[str, Any] | None = None,
        limit: int = 50,
        offset: Any = None,
        with_vectors: bool = False,
    ) -> tuple[list[dict[str, Any]], Any]:
        """Cursor-paginated scroll. ``offset=None`` starts from the
        beginning; the second element of the returned tuple is the
        opaque cursor for the next page (``None`` ⇒ done).

        When ``with_vectors=True`` each chunk dict has its embedding
        attached under the ``__embedding__`` key (used by
        export_chunks(include_embeddings=True)).
        """
        qdrant_filter = _build_qdrant_filter(filter)
        points, next_offset = self._client.scroll(
            collection_name=self._collection_name,
            scroll_filter=qdrant_filter,
            limit=limit,
            offset=offset,
            with_payload=True,
            with_vectors=with_vectors,
        )
        chunks: list[dict[str, Any]] = []
        for p in points:
            payload = dict(p.payload or {})
            if with_vectors and p.vector is not None:
                # p.vector is list[float] for single-vector configs; dict for named-vector ones.
                payload["__embedding__"] = (
                    p.vector if isinstance(p.vector, dict) else list(p.vector)
                )
            chunks.append(payload)
        return chunks, next_offset

    def delete_by_filter(self, filter: dict[str, Any]) -> None:
        """Delete every point matching ``filter`` (refuses an empty
        filter — would otherwise wipe the collection)."""
        if not filter:
            raise ValueError(
                "delete_by_filter requires a non-empty filter; use delete_collection() "
                "to drop the entire collection"
            )
        from qdrant_client.models import FilterSelector

        qdrant_filter = _build_qdrant_filter(filter)
        self._client.delete(
            collection_name=self._collection_name,
            points_selector=FilterSelector(filter=qdrant_filter),
            wait=True,
        )

    def delete_collection(self) -> bool:
        """Delete the configured collection from Qdrant.

        A subsequent ``add_chunks`` call will lazily recreate the
        collection (with payload indexes) via ``_ensure_collection``.

        Args:
            None.

        Returns:
            True if the collection existed and was deleted, False otherwise.
        """
        if not self._client.collection_exists(self._collection_name):
            return False
        self._client.delete_collection(collection_name=self._collection_name)
        return True

    def close(self) -> None:
        """Close the underlying QdrantClient if this store owns it.

        When the client was passed in via the constructor (per-Xrag
        shared instance), the owner is responsible for teardown — calling
        ``close()`` here is a no-op so sibling stores keep working.
        """
        if self._owns_client:
            self._client.close()

    def _ensure_collection(self, vector_size: int) -> None:
        """Create the target collection (with payload indexes) if it does not already exist."""
        if self._client.collection_exists(self._collection_name):
            self._ensure_payload_indexes()
            return
        self._client.create_collection(
            collection_name=self._collection_name,
            vectors_config=VectorParams(size=vector_size, distance=self._distance),
        )
        self._ensure_payload_indexes()

    def _ensure_payload_indexes(self) -> None:
        """Create payload indexes for tenant_id (tenant-optimized) + keyword keys.

        Idempotent — Qdrant's ``create_payload_index`` no-ops on a
        pre-existing index of the same schema. We surface failures as a
        warning rather than aborting so an older Qdrant server (pre-1.11,
        no ``is_tenant`` flag) still gets usable indexes.
        """
        try:
            self._client.create_payload_index(
                collection_name=self._collection_name,
                field_name=_TENANT_KEY,
                field_schema=KeywordIndexParams(
                    type=KeywordIndexType.KEYWORD,
                    is_tenant=True,
                ),
            )
        except Exception as exc:
            logger.warning(
                "tenant payload index on %s failed (%s); falling back to keyword",
                _TENANT_KEY,
                exc,
            )
            try:
                self._client.create_payload_index(
                    collection_name=self._collection_name,
                    field_name=_TENANT_KEY,
                    field_schema=PayloadSchemaType.KEYWORD,
                )
            except Exception as inner:
                logger.warning("keyword fallback for %s failed: %s", _TENANT_KEY, inner)

        for key in _KEYWORD_INDEX_KEYS:
            try:
                self._client.create_payload_index(
                    collection_name=self._collection_name,
                    field_name=key,
                    field_schema=PayloadSchemaType.KEYWORD,
                )
            except Exception as exc:
                logger.warning("keyword payload index on %s failed: %s", key, exc)


def _point_id(chunk_id: str) -> str:
    """Derive a deterministic UUID string from a chunk_id for use as a Qdrant point ID.

    Qdrant requires point IDs to be unsigned ints or UUIDs; our chunk IDs are
    arbitrary strings like ``doc_id:chunk:1``, so we hash them into UUID5.

    Args:
        chunk_id: The original chunk identifier.

    Returns:
        A UUID string usable as a Qdrant point ID.
    """
    if not chunk_id:
        return str(uuid.uuid4())
    return str(uuid.uuid5(_POINT_ID_NAMESPACE, chunk_id))


def _build_payload(chunk: dict[str, Any]) -> dict[str, Any]:
    """Build a Qdrant payload from a chunk record, dropping null values."""
    return {key: value for key, value in chunk.items() if value is not None}


def _build_qdrant_filter(filter_dict: dict[str, Any] | None) -> Filter | None:
    """Translate a payload-key→value dict into a Qdrant ``must`` filter.

    Scalar values become ``MatchValue`` equality conditions; lists become
    ``MatchAny`` IN conditions. ``None`` or empty values for a key are
    skipped (so callers can pass an unscoped doc_id without matching).

    Args:
        filter_dict: Optional payload filter dict.

    Returns:
        ``Filter`` with ``must`` conditions, or ``None`` if no conditions.
    """
    if not filter_dict:
        return None
    conditions: list[FieldCondition] = []
    for key, value in filter_dict.items():
        if value is None:
            continue
        if isinstance(value, list):
            if not value:
                continue
            conditions.append(FieldCondition(key=key, match=MatchAny(any=value)))
        else:
            conditions.append(FieldCondition(key=key, match=MatchValue(value=value)))
    if not conditions:
        return None
    return Filter(must=conditions)


def _resolve_distance(name: str) -> Distance:
    """Resolve a distance name to the Qdrant ``Distance`` enum value."""
    key = name.lower()
    table = {
        "cosine": Distance.COSINE,
        "dot": Distance.DOT,
        "euclid": Distance.EUCLID,
        "euclidean": Distance.EUCLID,
        "manhattan": Distance.MANHATTAN,
    }
    if key not in table:
        raise ValueError(f"unsupported qdrant distance metric: {name}")
    return table[key]
