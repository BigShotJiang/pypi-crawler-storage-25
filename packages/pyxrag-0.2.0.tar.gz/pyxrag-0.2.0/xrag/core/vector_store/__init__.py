"""Vector store provider implementations."""
