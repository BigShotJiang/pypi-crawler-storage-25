from __future__ import annotations

from xrag.config.models import ProviderConfig
from xrag.config.settings import get_settings
from xrag.core.vector_store.base import BaseVectorStore


def build_vector_store(config: ProviderConfig) -> BaseVectorStore:
    """Build the configured vector store implementation.

    Provider modules are imported lazily so that consumers who don't need
    a particular backend (e.g. a retrieve-only wheel that lacks the
    `[chroma]` extra) don't pay the import cost or hit ImportError on
    `import xrag`.

    Args:
        config: Vector store provider config.

    Returns:
        Concrete vector store implementation.
    """
    if config.provider == "chroma":
        try:
            from xrag.core.vector_store.chroma import ChromaVectorStore
        except ImportError as e:  # pragma: no cover — extras-gating
            raise ImportError(
                "Chroma support requires the [chroma] extra. "
                "Install with `pip install 'xrag[chroma]'`."
            ) from e
        return ChromaVectorStore(
            collection_name=config.options.get("collection_name", "default"),
            persist_directory=config.options.get("persist_directory"),
        )
    if config.provider == "qdrant":
        from xrag.core.vector_store.qdrant import QdrantVectorStore

        settings = get_settings()
        # Caller-supplied url/path/api_key win over settings; fall back
        # to settings only when the option is absent. The high-level Xrag
        # client always supplies one of url or path explicitly, and not
        # honouring that silently routes the request to whatever happens
        # to be in the env (or in-memory mode if nothing is set).
        return QdrantVectorStore(
            collection_name=config.options.get("collection_name", "default"),
            url=config.options.get("url") or settings.qdrant_url,
            api_key=config.options.get("api_key") or settings.qdrant_api_key,
            path=config.options.get("path"),
            prefer_grpc=config.options.get("prefer_grpc", False),
            distance=config.options.get("distance", "cosine"),
        )
    raise ValueError(f"unsupported vector store provider: {config.provider}")
