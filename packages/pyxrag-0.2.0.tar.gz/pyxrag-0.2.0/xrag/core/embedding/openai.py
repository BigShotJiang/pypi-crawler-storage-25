from __future__ import annotations

from langchain_openai import OpenAIEmbeddings

from xrag.config.settings import get_settings
from xrag.core.embedding.base import BaseEmbedding


class OpenAIEmbedding(BaseEmbedding):
    """OpenAI embedding provider using langchain-openai."""

    def __init__(
        self,
        model: str = "text-embedding-3-small",
        dimensions: int | None = None,
    ) -> None:
        self._model = model
        self._dimensions = dimensions
        settings = get_settings()
        kwargs: dict[str, object] = {"model": model, "api_key": settings.openai_api_key}
        if dimensions is not None:
            # text-embedding-3-* models support Matryoshka shrinking via the
            # OpenAI ``dimensions`` request parameter; pass through only when
            # the caller asked for it so other models keep their natural size.
            kwargs["dimensions"] = dimensions
        self._client = OpenAIEmbeddings(**kwargs)

    @property
    def model_name(self) -> str:
        return self._model

    def embed_texts(self, texts: list[str], options: dict[str, object]) -> list[list[float]]:
        """Embed a batch of document texts via OpenAI API.

        Args:
            texts: Text strings to embed.
            options: Provider-specific options (unused for OpenAI).

        Returns:
            A list of embedding vectors.
        """
        return self._client.embed_documents(texts)

    def embed_query(self, query: str, options: dict[str, object]) -> list[float]:
        """Embed a single query string via OpenAI API.

        Args:
            query: The query text to embed.
            options: Provider-specific options (unused for OpenAI).

        Returns:
            The query embedding vector.
        """
        return self._client.embed_query(query)
