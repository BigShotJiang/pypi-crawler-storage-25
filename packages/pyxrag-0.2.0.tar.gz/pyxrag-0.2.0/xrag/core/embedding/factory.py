from __future__ import annotations

from xrag.config.models import ProviderConfig
from xrag.core.embedding.base import BaseEmbedding
from xrag.core.embedding.openai import OpenAIEmbedding


def build_embedding(config: ProviderConfig) -> BaseEmbedding:
    """Build the configured embedding implementation.

    Args:
        config: Embedding provider config.

    Returns:
        Concrete embedding implementation.
    """
    if config.provider == "openai":
        model = config.options.get("model", "text-embedding-3-small")
        dimensions = config.options.get("dimensions")
        return OpenAIEmbedding(model=model, dimensions=dimensions)
    raise ValueError(f"unsupported embedding provider: {config.provider}")
