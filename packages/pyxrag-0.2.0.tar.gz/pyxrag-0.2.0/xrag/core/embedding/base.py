"""Base contract for embedding providers."""

from __future__ import annotations

from abc import ABC, abstractmethod


class BaseEmbedding(ABC):
    """Embed document text and queries into numeric vectors."""

    @property
    def model_name(self) -> str | None:
        """Return the provider model identifier used for drift checks.

        Concrete providers should return the same string the indexer
        stamps onto each chunk's ``embedding_model`` payload; ``None``
        opts the provider out of the drift check.
        """
        return None

    @abstractmethod
    def embed_texts(self, texts: list[str], options: dict[str, object]) -> list[list[float]]:
        """Embed a batch of document texts.

        Args:
            texts: Text strings to embed.
            options: Provider-specific embedding options.

        Returns:
            A list of embedding vectors, one per input text.
        """
        raise NotImplementedError

    @abstractmethod
    def embed_query(self, query: str, options: dict[str, object]) -> list[float]:
        """Embed one query string.

        Args:
            query: The query text to embed.
            options: Provider-specific embedding options.

        Returns:
            The query embedding vector.
        """
        raise NotImplementedError
