from __future__ import annotations

import json
import mimetypes
import time
from typing import Any

from xrag.config.models import SourceConfig
from xrag.config.settings import get_settings
from xrag.core.parser.base import BaseParser
from xrag.models.result import ParseBundle, ParsedSourceMetadata


class UnstructuredParser(BaseParser):
    """Parser implementation backed by the Unstructured API."""

    def run(self, sources: list[SourceConfig], options: dict) -> ParseBundle:
        """Parse source files with the Unstructured API.

        Args:
            sources: Source file declarations.
            options: Provider-specific parser options.

        Returns:
            Parsed document bundle containing raw outputs.
        """
        client = self._build_client()
        template_id = str(options.get("template_id", "hi_res_and_enrichment"))
        settings = get_settings()
        poll_interval_seconds = int(
            options.get("poll_interval_seconds", settings.poll_interval_seconds)
        )

        with client:
            job_id, source_pairs = self._submit_job(
                client=client,
                sources=sources,
                template_id=template_id,
            )
            job = self._poll_job(
                client=client,
                job_id=job_id,
                poll_interval_seconds=poll_interval_seconds,
            )
            if getattr(job, "status", None) != "COMPLETED":
                raise RuntimeError(
                    f"unstructured job failed with status: {getattr(job, 'status', None)}"
                )
            raw_outputs = self._fetch_outputs(
                client=client,
                job_id=job_id,
                source_pairs=source_pairs,
            )

        metadata = []
        for source in sources:
            metadata.append(
                ParsedSourceMetadata(
                    doc_id=source.doc_id,
                    source_path=str(source.path),
                    provider="unstructured",
                    job_id=job_id,
                    status="COMPLETED",
                )
            )

        return ParseBundle(
            raw_outputs=raw_outputs,
            source_metadata=metadata,
        )

    def _build_client(self):
        """Build the Unstructured SDK client from settings.

        Returns:
            Configured Unstructured client.
        """
        settings = get_settings()
        api_key = settings.unstructured_api_key
        if not api_key:
            raise ValueError("UNSTRUCTURED_API_KEY is required")

        from unstructured_client import UnstructuredClient

        kwargs: dict[str, Any] = {"api_key_auth": api_key}
        api_url = settings.unstructured_api_url
        if api_url:
            kwargs["server_url"] = api_url
        return UnstructuredClient(**kwargs)

    def _submit_job(self, client, sources: list[SourceConfig], template_id: str):
        """Submit an Unstructured on-demand parsing job.

        Args:
            client: Unstructured SDK client.
            sources: Source files to submit.
            template_id: Unstructured template identifier.

        Returns:
            Tuple of job id and source-to-file-id pairs.
        """
        from unstructured_client.models.operations import CreateJobRequest
        from unstructured_client.models.shared import BodyCreateJob, InputFiles

        files = []
        for source in sources:
            content_type = mimetypes.guess_type(str(source.path))[0] or "application/octet-stream"
            files.append(
                InputFiles(
                    content=source.path.read_bytes(),
                    file_name=source.path.name,
                    content_type=content_type,
                )
            )

        response = client.jobs.create_job(
            request=CreateJobRequest(
                body_create_job=BodyCreateJob(
                    request_data=json.dumps({"template_id": template_id}),
                    input_files=files,
                )
            )
        )
        job_info = response.job_information
        file_ids = list(getattr(job_info, "input_file_ids", []) or [])
        if len(file_ids) != len(sources):
            raise RuntimeError(
                "unstructured job returned a different number of input_file_ids "
                "than submitted sources"
            )
        source_pairs = list(zip(sources, file_ids, strict=True))
        return job_info.id, source_pairs

    def _poll_job(self, client, job_id: str, poll_interval_seconds: int):
        """Poll an Unstructured job until it reaches a terminal state.

        Args:
            client: Unstructured SDK client.
            job_id: Job identifier to poll.
            poll_interval_seconds: Delay between polls.

        Returns:
            Terminal job object.
        """
        while True:
            response = client.jobs.get_job(request={"job_id": job_id})
            job = response.job_information
            status = getattr(job, "status", None)
            if status in {"COMPLETED", "FAILED", "CANCELED"}:
                return job
            time.sleep(poll_interval_seconds)

    def _fetch_outputs(self, client, job_id: str, source_pairs):
        """Download raw outputs for each submitted source.

        Args:
            client: Unstructured SDK client.
            job_id: Completed job identifier.
            source_pairs: Source-to-file-id pairs.

        Returns:
            Raw outputs keyed by document id.
        """
        from unstructured_client.models.operations import DownloadJobOutputRequest

        outputs: dict[str, object] = {}
        for source, file_id in source_pairs:
            response = client.jobs.download_job_output(
                request=DownloadJobOutputRequest(job_id=job_id, file_id=file_id)
            )
            outputs[source.doc_id] = response.any
        return outputs
