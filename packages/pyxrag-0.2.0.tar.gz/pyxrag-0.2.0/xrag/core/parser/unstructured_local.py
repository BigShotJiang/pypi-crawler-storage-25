from __future__ import annotations

import logging
import multiprocessing as mp
import os
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

from xrag.config.models import SourceConfig
from xrag.core.parser.base import BaseParser
from xrag.models.result import ParseBundle, ParsedSourceMetadata

logger = logging.getLogger(__name__)

# `spawn` start method: forkbug-safe when the parent has background threads
# (torch CUDA probe, langsmith client, ragas judges, etc.). On Linux the
# default is `fork`, which inherits parent threads in an inconsistent state
# and can hang or crash workers. spawn pays a slightly higher per-worker
# startup cost (re-imports modules) but the parser is the bottleneck, not
# pool startup.
_MP_CONTEXT = mp.get_context("spawn")

_DOCX_SUFFIXES = {".docx", ".doc"}
_PDF_SUFFIXES = {".pdf"}
_PDF_EXTRA_HINT = (
    "Local PDF parsing requires the [parser-unstructured-local-pdf] extra. "
    "Install with `pip install 'xrag[parser-unstructured-local-pdf]'`."
)


def _partition_one(path_str: str, strategy: str, infer_table_structure: bool) -> list[dict]:
    """Worker entry point: parse one file and return element dicts.

    Lives at module top-level so ProcessPoolExecutor can pickle it.
    """
    from unstructured.staging.base import elements_to_dicts

    suffix = Path(path_str).suffix.lower()
    if suffix in _DOCX_SUFFIXES:
        from unstructured.partition.docx import partition_docx

        elements = partition_docx(
            filename=path_str,
            strategy=strategy,
            infer_table_structure=infer_table_structure,
        )
    elif suffix in _PDF_SUFFIXES:
        try:
            from unstructured.partition.pdf import partition_pdf
        except ImportError as e:  # pragma: no cover - extras gating
            raise ImportError(_PDF_EXTRA_HINT) from e

        elements = partition_pdf(
            filename=path_str,
            strategy=strategy,
            infer_table_structure=infer_table_structure,
        )
    else:
        from unstructured.partition.auto import partition

        elements = partition(
            filename=path_str,
            strategy=strategy,
            infer_table_structure=infer_table_structure,
        )
    return elements_to_dicts(elements)


class UnstructuredLocalParser(BaseParser):
    """Parser implementation backed by the local ``unstructured`` library.

    Runs ``partition_docx`` / ``partition_pdf`` / ``partition`` directly in
    the current Python process — no hosted-API job submission, polling, or
    network round-trip. For DOCX with ``strategy="fast"`` this skips the
    YOLOX layout model and OCR entirely (native python-docx XML walk),
    which is the fast path for office documents.

    Multi-source runs use a process pool (DOCX/PDF parsing is CPU-bound
    and the GIL prevents thread-level speedup). Set ``options.workers``
    to control pool size; defaults to ``min(8, os.cpu_count())``.
    """

    def run(self, sources: list[SourceConfig], options: dict) -> ParseBundle:
        """Parse source files locally with the unstructured library.

        Args:
            sources: Source file declarations.
            options: Provider options.
                strategy: ``"fast"`` (default), ``"hi_res"``, ``"ocr_only"``,
                    or ``"auto"``. ``"fast"`` is correct for native-text
                    office formats; switch to ``"hi_res"`` for scanned PDFs.
                infer_table_structure: Whether to extract table structure
                    metadata. Default ``True`` to mirror the hosted API.
                workers: Process pool size for parallel parsing across
                    sources. Default ``min(8, os.cpu_count())``. Set to
                    ``1`` to disable multiprocessing (useful for debugging
                    or single-source runs).

        Returns:
            Parsed document bundle keyed by ``doc_id``.
        """
        strategy = str(options.get("strategy", "fast"))
        infer_table_structure = bool(options.get("infer_table_structure", True))
        default_workers = min(8, os.cpu_count() or 1)
        workers = max(1, int(options.get("workers", default_workers)))

        path_strs = [str(source.path) for source in sources]
        outputs: dict[str, list[dict]] = {}

        if workers == 1 or len(sources) == 1:
            for source, path_str in zip(sources, path_strs, strict=True):
                t0 = time.time()
                outputs[source.doc_id] = _partition_one(path_str, strategy, infer_table_structure)
                logger.info(
                    "parsed %s (%s, %.1fs, %d elements)",
                    source.doc_id,
                    strategy,
                    time.time() - t0,
                    len(outputs[source.doc_id]),
                )
        else:
            pool_size = min(workers, len(sources))
            t0 = time.time()
            with ProcessPoolExecutor(max_workers=pool_size, mp_context=_MP_CONTEXT) as pool:
                future_to_doc = {
                    pool.submit(
                        _partition_one, path_str, strategy, infer_table_structure
                    ): source.doc_id
                    for source, path_str in zip(sources, path_strs, strict=True)
                }
                for future in as_completed(future_to_doc):
                    doc_id = future_to_doc[future]
                    outputs[doc_id] = future.result()
            logger.info(
                "parsed %d sources in %.1fs (workers=%d, strategy=%s)",
                len(sources),
                time.time() - t0,
                pool_size,
                strategy,
            )

        metadata = [
            ParsedSourceMetadata(
                doc_id=source.doc_id,
                source_path=str(source.path),
                provider="unstructured_local",
                job_id=f"local:{strategy}",
                status="COMPLETED",
            )
            for source in sources
        ]

        return ParseBundle(
            raw_outputs={doc_id: outputs[doc_id] for doc_id in (s.doc_id for s in sources)},
            source_metadata=metadata,
        )
