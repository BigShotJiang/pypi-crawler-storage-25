from __future__ import annotations

from xrag.config.models import ProviderConfig
from xrag.core.parser.base import BaseParser


def build_parser(config: ProviderConfig) -> BaseParser:
    """Build the configured parser implementation.

    Provider modules are imported lazily so consumers without the
    local Unstructured extra can still `import xrag`.

    Args:
        config: Parser provider config.

    Returns:
        Concrete parser implementation.
    """
    if config.provider == "unstructured":
        from xrag.core.parser.unstructured import UnstructuredParser

        return UnstructuredParser()
    if config.provider == "unstructured_local":
        from xrag.core.parser.unstructured_local import UnstructuredLocalParser

        return UnstructuredLocalParser()
    raise ValueError(f"unsupported parser provider: {config.provider}")
