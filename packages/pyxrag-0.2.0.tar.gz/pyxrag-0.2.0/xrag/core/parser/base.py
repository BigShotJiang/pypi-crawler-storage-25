"""Base contract for parser providers."""

from __future__ import annotations

from abc import ABC, abstractmethod

from xrag.config.models import SourceConfig
from xrag.models.result import ParseBundle


class BaseParser(ABC):
    """Parse source documents into raw provider output."""

    @abstractmethod
    def run(self, sources: list[SourceConfig], options: dict) -> ParseBundle:
        """Parse source documents into a parse bundle.

        Args:
            sources: Source file declarations.
            options: Provider-specific parser options.

        Returns:
            Parsed output bundle.
        """
        raise NotImplementedError
