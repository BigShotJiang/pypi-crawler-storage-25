"""Base contract for artifact storage backends."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

from xrag.models.manifest import Manifest


class BaseArtifactStore(ABC):
    """Write manifests, telemetry, and raw pipeline artifacts."""

    @abstractmethod
    def save_manifest(self, manifest: Manifest) -> Path:
        """Write the run manifest to the artifact store.

        Args:
            manifest: Manifest payload to save.

        Returns:
            Path to the written artifact.
        """
        raise NotImplementedError

    @abstractmethod
    def save_telemetry(self, payload: dict[str, Any]) -> Path:
        """Write telemetry output to the artifact store.

        Args:
            payload: Telemetry payload to save.

        Returns:
            Path to the written artifact.
        """
        raise NotImplementedError

    @abstractmethod
    def save_parser_output(self, outputs: dict[str, Any]) -> Path:
        """Write raw parser output to the artifact store.

        Args:
            outputs: Raw parser outputs keyed by document id.

        Returns:
            Path to the written artifact file.
        """
        raise NotImplementedError
