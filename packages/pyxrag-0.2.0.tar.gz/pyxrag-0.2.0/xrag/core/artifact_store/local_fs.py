from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from pydantic import BaseModel

from xrag.core.artifact_store.base import BaseArtifactStore
from xrag.models.manifest import Manifest


class LocalFsArtifactStore(BaseArtifactStore):
    """Filesystem-backed artifact store implementation."""

    def __init__(self, output_dir: Path) -> None:
        """Initialize the local filesystem artifact store.

        Args:
            output_dir: Base output directory for artifacts.
        """
        self.output_dir = output_dir
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def save_manifest(self, manifest: Manifest) -> Path:
        """Save the run manifest as JSON."""
        return self._write_json(self.output_dir / "manifest.json", self._to_jsonable(manifest))

    def save_telemetry(self, payload: dict[str, Any]) -> Path:
        """Save telemetry metadata as JSON."""
        return self._write_json(self.output_dir / "telemetry.json", payload)

    def save_parser_output(self, outputs: dict[str, Any]) -> Path:
        """Save raw parser outputs as a single JSON artifact."""
        return self._write_json(self.output_dir / "parsed" / "unstructured_elements.json", outputs)

    def _write_json(self, path: Path, payload: Any) -> Path:
        """Write JSON payload to disk.

        Args:
            path: Destination path.
            payload: JSON-serializable payload.

        Returns:
            Path to the written file.
        """
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload, indent=2))
        return path

    def _to_jsonable(self, value: Any) -> Any:
        """Convert supported objects into JSON-serializable values.

        Args:
            value: Value to convert.

        Returns:
            JSON-serializable representation of the input value.
        """
        if isinstance(value, BaseModel):
            return value.model_dump(mode="json")
        if isinstance(value, dict):
            return {key: self._to_jsonable(item) for key, item in value.items()}
        if isinstance(value, list):
            return [self._to_jsonable(item) for item in value]
        return value
