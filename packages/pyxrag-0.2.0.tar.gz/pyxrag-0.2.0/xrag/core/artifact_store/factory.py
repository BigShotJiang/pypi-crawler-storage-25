from __future__ import annotations

from pathlib import Path

from xrag.config.models import ProviderConfig
from xrag.core.artifact_store.base import BaseArtifactStore
from xrag.core.artifact_store.local_fs import LocalFsArtifactStore


def build_artifact_store(config: ProviderConfig, output_dir: Path) -> BaseArtifactStore:
    """Build the configured artifact store implementation.

    Args:
        config: Artifact store provider config.
        output_dir: Destination directory for artifacts.

    Returns:
        A concrete artifact store implementation.
    """
    if config.provider == "local_fs":
        return LocalFsArtifactStore(output_dir=output_dir)
    raise ValueError(f"unsupported artifact store provider: {config.provider}")
