"""Artifact storage backends for pipeline outputs."""
