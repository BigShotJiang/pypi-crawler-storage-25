"""Retriever implementations over embedded chunk stores."""
