from __future__ import annotations

from xrag.config.models import ProviderConfig, RetrievalConfig
from xrag.core.embedding.base import BaseEmbedding
from xrag.core.retrieval.base import BaseRetriever
from xrag.core.retrieval.hybrid import HybridRetriever
from xrag.core.retrieval.simple import SimpleRetriever
from xrag.core.vector_store.base import BaseVectorStore


def build_retriever(
    config: ProviderConfig | RetrievalConfig,
    embedding: BaseEmbedding,
    vector_store: BaseVectorStore,
) -> BaseRetriever:
    """Build the configured retriever implementation.

    Args:
        config: Retrieval provider config.
        embedding: Pre-built embedding instance for query encoding.
        vector_store: Pre-built vector store instance for search.

    Returns:
        Concrete retriever implementation.
    """
    if config.provider == "simple":
        return SimpleRetriever(embedding=embedding, vector_store=vector_store)
    if config.provider == "hybrid":
        return HybridRetriever(
            embedding=embedding,
            vector_store=vector_store,
            rrf_k=config.options.get("rrf_k", 60),
            bm25_candidates=config.options.get("bm25_candidates", 50),
            vector_candidates=config.options.get("vector_candidates", 50),
        )
    raise ValueError(f"unsupported retrieval provider: {config.provider}")
