from __future__ import annotations

from typing import Any

from xrag.core.embedding.base import BaseEmbedding
from xrag.core.retrieval.base import BaseRetriever
from xrag.core.retrieval.drift import assert_embedding_model_match
from xrag.core.vector_store.base import BaseVectorStore


class SimpleRetriever(BaseRetriever):
    """Naive vector-similarity retriever with no reranking."""

    def __init__(self, embedding: BaseEmbedding, vector_store: BaseVectorStore) -> None:
        self._embedding = embedding
        self._vector_store = vector_store
        self._drift_checked = False

    def warmup(self) -> None:
        """Pre-pay embedding + vector-store lazy init costs on the main thread.

        Without this, N concurrent workers each pay ~4s on their first query
        while LangChain's OpenAIEmbeddings lazy-loads its tokenizer/HTTP client.
        """
        try:
            warm_vec = self._embedding.embed_query("warmup", {})
            self._vector_store.query(warm_vec, top_k=1, options={})
        except Exception:
            # Best-effort warmup; swallow errors without failing the run.
            pass

    def retrieve(self, query: str, options: dict[str, Any]) -> list[dict[str, Any]]:
        """Embed the query and retrieve top-k chunks by cosine similarity.

        Args:
            query: The user query string.
            options: Must include ``top_k`` (default 5).

        Returns:
            Ranked list of chunk dicts with scores.
        """
        top_k = options.get("top_k", 5)
        query_embedding = self._embedding.embed_query(query, options)
        results = self._vector_store.query(query_embedding, top_k=top_k, options=options)
        if not self._drift_checked:
            assert_embedding_model_match(results, self._embedding.model_name)
            self._drift_checked = True
        return results
