"""Base contract for retriever implementations."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class BaseRetriever(ABC):
    """Retrieve relevant chunks for a query."""

    @abstractmethod
    def retrieve(self, query: str, options: dict[str, Any]) -> list[dict[str, Any]]:
        """Retrieve ranked chunks for one query.

        Args:
            query: The user query string.
            options: Provider-specific retrieval options.

        Returns:
            Ranked list of chunk dicts with scores.
        """
        raise NotImplementedError
