"""Post-retrieval deduplication by parent/child chunk family.

Addresses issue I1 in `docs/sub-plans/retrieval-quality-fixes.md`:
even with `exclude_parents_from_index=True`, overlapping windows and
siblings quoting the same figure can still fill top-k with near-
duplicates. ``dedup_by_family`` walks a candidate list in rank order and
drops any hit whose parent or children have already appeared at a higher
rank.

Relation to existing production patterns (see plan survey):
- LlamaIndex / Haystack ``AutoMergingRetriever`` *swap* a majority of
  sibling leaves for their parent — a Layer-3 consolidation decision.
- RAGFlow parent-child and LangChain ``ParentDocumentRetriever`` always
  return the parent at serve time (with the LangChain version known to
  silently duplicate parents in top-k — see issue #17310).
- This function does neither: it is a pure redundancy filter that
  preserves the original ranking's winner. Compose it with a
  merge/upgrade step if benchmarks show sibling convergence too.
"""

from __future__ import annotations

from typing import Any


def dedup_by_family(hits: list[dict[str, Any]], top_k: int) -> list[dict[str, Any]]:
    """Drop parent/child family duplicates from a ranked hit list.

    The input must already be sorted best-first. Walks the list in order
    and keeps a hit only when none of the following are already in the
    kept set:

    * The hit's ``chunk_id`` itself.
    * The hit's ``parent_chunk_id`` (hit is a child of a kept ancestor).
    * Any entry in the hit's ``child_chunk_ids`` (hit is an ancestor
      whose child was kept at a higher rank).

    Args:
        hits: Ranked candidate chunks with optional ``chunk_id``,
            ``parent_chunk_id``, and ``child_chunk_ids`` fields.
        top_k: Maximum number of chunks to return. Call sites should
            pass a pre-dedup candidate list ≥ ``top_k × 2`` so the
            dedup has slack to work with.

    Returns:
        A new list with at most ``top_k`` family-unique chunks, in the
        same relative order as the input.
    """
    if top_k <= 0 or not hits:
        return []

    kept: list[dict[str, Any]] = []
    kept_ids: set[str] = set()
    for hit in hits:
        if len(kept) >= top_k:
            break
        chunk_id = _as_id(hit.get("chunk_id"))
        parent_id = _as_id(hit.get("parent_chunk_id"))
        child_ids = {_as_id(cid) for cid in hit.get("child_chunk_ids") or [] if _as_id(cid)}

        if chunk_id and chunk_id in kept_ids:
            continue
        if parent_id and parent_id in kept_ids:
            continue
        if child_ids & kept_ids:
            continue

        kept.append(hit)
        if chunk_id:
            kept_ids.add(chunk_id)
    return kept


def _as_id(value: Any) -> str:
    """Return a stripped string id or empty string."""
    if value is None:
        return ""
    return str(value).strip()
