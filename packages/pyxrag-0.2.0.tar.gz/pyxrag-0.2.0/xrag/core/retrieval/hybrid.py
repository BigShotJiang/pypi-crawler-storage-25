"""Hybrid retriever: BM25 + dense vector with Reciprocal Rank Fusion."""

from __future__ import annotations

import re
import threading
from typing import Any

from rank_bm25 import BM25Okapi

from xrag.core.embedding.base import BaseEmbedding
from xrag.core.retrieval.base import BaseRetriever
from xrag.core.retrieval.drift import assert_embedding_model_match
from xrag.core.vector_store.base import BaseVectorStore

_TOKEN_RE = re.compile(r"\w+")


def _tokenize(text: str) -> list[str]:
    """Lowercase word-boundary tokenization with no external dependencies.

    Args:
        text: Input string to tokenize.

    Returns:
        List of lowercase token strings.
    """
    return _TOKEN_RE.findall(text.lower())


def _bm25_text(chunk: dict[str, Any]) -> str:
    """Build the BM25 token source for a chunk.

    Mirrors RAGFlow's pattern of boosting content tokens with
    ``important_kwd`` — if the auto_keywords enricher populated important
    keywords, they get appended to the content so BM25 treats them as
    extra hit signal (higher term frequency).
    """
    body = chunk.get("content_with_weight") or chunk.get("content", "")
    important = chunk.get("important_kwd") or []
    if important:
        body = f"{body} {' '.join(important)}"
    return body


def _chunk_matches_filter(chunk: dict[str, Any], filter_dict: dict[str, Any]) -> bool:
    """Return True if ``chunk``'s payload satisfies every condition in ``filter_dict``.

    Mirrors the Qdrant ``must`` filter semantics used by the dense leg: a
    scalar value is an equality match; a list value is an IN match. Empty
    list values and ``None`` values are skipped (match-anything).

    The BM25 corpus is built once over the whole collection so the filter
    must be applied at retrieval time — otherwise BM25 hits from other
    tenants or excluded doc_ids leak into the fused result.
    """
    if not filter_dict:
        return True
    for key, expected in filter_dict.items():
        if expected is None:
            continue
        if isinstance(expected, list):
            if not expected:
                continue
            if chunk.get(key) not in expected:
                return False
        else:
            if chunk.get(key) != expected:
                return False
    return True


def _rrf_fuse(ranked_lists: list[list[str]], k: int) -> dict[str, float]:
    """Reciprocal Rank Fusion over multiple ranked lists of chunk IDs.

    Args:
        ranked_lists: Each inner list is an ordered sequence of chunk IDs, best first.
        k: RRF constant (default 60 per Cormack et al., 2009).

    Returns:
        Dict mapping chunk_id → combined RRF score (higher is better).
    """
    scores: dict[str, float] = {}
    for ranked in ranked_lists:
        for rank, chunk_id in enumerate(ranked):
            scores[chunk_id] = scores.get(chunk_id, 0.0) + 1.0 / (k + rank + 1)
    return scores


class HybridRetriever(BaseRetriever):
    """Hybrid BM25 + dense vector retriever with Reciprocal Rank Fusion.

    BM25 index is built lazily on first retrieval from the full collection.
    Subsequent calls reuse the in-memory index (one build per process lifetime).

    Args:
        embedding: Embedding provider for query encoding.
        vector_store: Vector store for dense retrieval and corpus loading.
        rrf_k: RRF constant k (default 60). Must be > 0.
        bm25_candidates: Number of BM25 candidates before fusion.
        vector_candidates: Number of vector candidates before fusion.
    """

    def __init__(
        self,
        embedding: BaseEmbedding,
        vector_store: BaseVectorStore,
        rrf_k: int = 60,
        bm25_candidates: int = 50,
        vector_candidates: int = 50,
    ) -> None:
        if rrf_k <= 0:
            raise ValueError(f"rrf_k must be > 0, got {rrf_k}")
        self._embedding = embedding
        self._vector_store = vector_store
        self._rrf_k = rrf_k
        self._bm25_candidates = bm25_candidates
        self._vector_candidates = vector_candidates
        self._bm25: BM25Okapi | None = None
        self._bm25_chunks: list[dict[str, Any]] = []
        self._bm25_lock = threading.Lock()
        self._drift_checked = False

    def warmup(self) -> None:
        """Pre-pay first-query init costs so concurrent workers start warm.

        Triggers three lazy initializations upfront:
        1. BM25 corpus build (reads all chunks, tokenizes, builds index)
        2. Embedding client init (LangChain's OpenAIEmbeddings lazily loads
           tokenizer + HTTP client on first embed, ~3s in practice)
        3. Vector store connection (Chroma's first query sets up the HNSW
           cache, ~100ms)

        Safe to call multiple times. Without this, N concurrent workers each
        pay the full ~4s on their first query before settling to ~300ms.
        """
        self._ensure_bm25()
        # Dummy retrieval warms the embedding + vector-store paths.
        try:
            warm_vec = self._embedding.embed_query("warmup", {})
            self._vector_store.query(warm_vec, top_k=1, options={})
        except Exception:
            # Best-effort warmup; swallow errors without failing the run.
            pass

    def _ensure_bm25(self) -> None:
        """Build the BM25 index lazily on first call. Thread-safe.

        Uses double-checked locking so the hot path is lock-free once the
        index is built.
        """
        if self._bm25 is not None:
            return
        with self._bm25_lock:
            if self._bm25 is not None:
                return
            all_chunks = self._vector_store.get_all()
            if not all_chunks:
                return
            tokenized = [_tokenize(_bm25_text(chunk)) for chunk in all_chunks]
            self._bm25_chunks = all_chunks
            self._bm25 = BM25Okapi(tokenized)

    def retrieve(self, query: str, options: dict[str, Any]) -> list[dict[str, Any]]:
        """Retrieve chunks using BM25 + vector fusion via RRF.

        Falls back to vector-only when the BM25 corpus is empty or the query
        tokens have no overlap with any document.

        Args:
            query: The user query string.
            options: Supports ``top_k`` (default 5), ``bm25_candidates``
                (default from constructor), ``vector_candidates``
                (default from constructor), ``rrf_k`` (default from constructor).

        Returns:
            Ranked list of chunk dicts with ``score`` set to the RRF score.
        """
        top_k = options.get("top_k", 5)
        bm25_n = options.get("bm25_candidates", self._bm25_candidates)
        vec_n = options.get("vector_candidates", self._vector_candidates)
        rrf_k = options.get("rrf_k", self._rrf_k)

        # --- Dense vector leg ---
        query_embedding = self._embedding.embed_query(query, options)
        vector_results = self._vector_store.query(query_embedding, top_k=vec_n, options=options)
        if not self._drift_checked:
            assert_embedding_model_match(vector_results, self._embedding.model_name)
            self._drift_checked = True
        vector_ids = [c["chunk_id"] for c in vector_results]
        vector_map = {c["chunk_id"]: c for c in vector_results}

        # --- BM25 leg ---
        self._ensure_bm25()
        if not self._bm25 or not self._bm25_chunks:
            return vector_results[:top_k]

        query_tokens = _tokenize(query)
        bm25_scores = self._bm25.get_scores(query_tokens)

        # Apply the request filter (tenant_id, document_id, doc_ids, …) to
        # the BM25 candidate pool. The dense leg gets this for free via
        # Qdrant's server-side filter; without the same constraint here,
        # BM25 hits from other tenants or excluded docs leak into the
        # fused output.
        filter_dict = options.get("filter") or {}
        candidate_indices = [
            i
            for i in range(len(bm25_scores))
            if _chunk_matches_filter(self._bm25_chunks[i], filter_dict)
        ]
        top_indices = sorted(candidate_indices, key=lambda i: bm25_scores[i], reverse=True)[:bm25_n]

        # Fall back to vector-only when no keyword overlap (or filter
        # eliminated every BM25 candidate).
        if not top_indices or all(bm25_scores[i] == 0.0 for i in top_indices):
            return vector_results[:top_k]

        bm25_results = [self._bm25_chunks[i] for i in top_indices]
        bm25_ids = [c["chunk_id"] for c in bm25_results]
        bm25_map = {c["chunk_id"]: c for c in bm25_results}

        # --- RRF fusion ---
        rrf_scores = _rrf_fuse([vector_ids, bm25_ids], k=rrf_k)
        sorted_ids = sorted(rrf_scores, key=lambda cid: rrf_scores[cid], reverse=True)[:top_k]

        combined_map = {**bm25_map, **vector_map}
        results: list[dict[str, Any]] = []
        for cid in sorted_ids:
            chunk = dict(combined_map[cid])
            chunk["score"] = rrf_scores[cid]
            results.append(chunk)
        return results
