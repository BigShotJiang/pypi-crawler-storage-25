from __future__ import annotations

from typing import Any


class EmbeddingModelDriftError(RuntimeError):
    """Raised when retrieval would query a collection indexed with a different embedding model."""


def assert_embedding_model_match(
    chunks: list[dict[str, Any]],
    expected_model: str | None,
) -> None:
    """Verify the indexed-side ``embedding_model`` payload matches the runtime embedder.

    The indexer (``pipelines/indexing.py``) stamps each chunk with
    ``embedding_model`` set to the model used at index time. A query-time
    embedder using a different model produces vectors that share a dim
    but live in an unrelated space — Qdrant happily returns nonsense.
    This guards against that silent failure mode.

    Skipped when:

    * ``chunks`` is empty (nothing was retrieved — separate concern),
    * ``expected_model`` is ``None`` (the runtime embedder opted out), or
    * the top-1 chunk has no ``embedding_model`` payload (legacy collection
      indexed before the tag was added — we do not retrofit blame).
    """
    if not chunks or not expected_model:
        return
    seen = chunks[0].get("embedding_model")
    if seen is None:
        return
    if seen != expected_model:
        raise EmbeddingModelDriftError(
            f"embedding model drift: collection was indexed with '{seen}' "
            f"but the runtime embedder is '{expected_model}'. Re-index the "
            f"collection or align the embedding config with the index."
        )
