from __future__ import annotations

import logging
import os
from typing import Any

from xrag.config.settings import get_settings
from xrag.core.tracing.base import BaseTracer

logger = logging.getLogger(__name__)


class LangSmithTracer(BaseTracer):
    """LangSmith tracer that enables LangChain auto-tracing via env vars.

    LangSmith traces any LangChain operation automatically once the
    ``LANGSMITH_TRACING`` and ``LANGSMITH_API_KEY`` environment variables
    are set. No callback handlers are needed.
    """

    def __init__(self, project: str | None = None, session: str | None = None) -> None:
        """Initialize with optional project and session overrides.

        Args:
            project: LangSmith project name. Falls back to settings.
            session: Optional session/run name to tag traces with.
        """
        self._project = project
        self._session = session

    def setup(self) -> None:
        """Set LangChain tracing environment variables."""
        settings = get_settings()
        if not settings.langsmith_api_key:
            logger.warning(
                "LangSmith tracing requested but LANGSMITH_API_KEY is not set; disabling."
            )
            return

        os.environ["LANGSMITH_TRACING"] = "true"
        os.environ["LANGSMITH_API_KEY"] = settings.langsmith_api_key
        os.environ["LANGSMITH_ENDPOINT"] = settings.langsmith_endpoint
        os.environ["LANGSMITH_PROJECT"] = self._project or settings.langsmith_project
        if self._session:
            os.environ["LANGSMITH_SESSION"] = self._session
        logger.info(
            "LangSmith tracing enabled (project=%s)",
            os.environ["LANGSMITH_PROJECT"],
        )

    def get_callbacks(self) -> list[Any]:
        """LangSmith auto-traces via env vars; no callbacks needed."""
        return []
