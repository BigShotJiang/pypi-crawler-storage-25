from __future__ import annotations

from xrag.config.models import ProviderConfig
from xrag.core.tracing.base import BaseTracer
from xrag.core.tracing.langfuse import LangFuseTracer
from xrag.core.tracing.langsmith import LangSmithTracer
from xrag.core.tracing.noop import NoopTracer


def build_tracer(config: ProviderConfig | None) -> BaseTracer:
    """Build the configured tracer implementation.

    Args:
        config: Tracing provider config, or None for no tracing.

    Returns:
        Concrete tracer implementation. Returns NoopTracer when config
        is None or provider is ``"none"``.
    """
    if config is None or config.provider in ("none", "noop"):
        return NoopTracer()
    if config.provider == "langsmith":
        return LangSmithTracer(
            project=config.options.get("project"),
            session=config.options.get("session"),
        )
    if config.provider == "langfuse":
        return LangFuseTracer(session_name=config.options.get("session_name"))
    raise ValueError(f"unsupported tracing provider: {config.provider}")
