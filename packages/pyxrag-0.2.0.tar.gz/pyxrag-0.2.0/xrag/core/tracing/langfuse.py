from __future__ import annotations

import logging
from typing import Any

from xrag.config.settings import get_settings
from xrag.core.tracing.base import BaseTracer

logger = logging.getLogger(__name__)


class LangFuseTracer(BaseTracer):
    """LangFuse tracer that attaches a CallbackHandler to LangChain runs."""

    def __init__(self, session_name: str | None = None) -> None:
        """Initialize with an optional session name for grouping traces.

        Args:
            session_name: Optional session identifier shown in LangFuse UI.
        """
        self._session_name = session_name
        self._handler: Any | None = None
        self._client: Any | None = None

    def setup(self) -> None:
        """Initialize the LangFuse client and callback handler."""
        settings = get_settings()
        if not settings.langfuse_public_key or not settings.langfuse_secret_key:
            logger.warning("LangFuse tracing requested but keys are not set; disabling.")
            return

        try:
            from langfuse import Langfuse
            from langfuse.langchain import CallbackHandler
        except ImportError as exc:
            raise ImportError("langfuse is not installed. Install with: uv add langfuse") from exc

        self._client = Langfuse(
            public_key=settings.langfuse_public_key,
            secret_key=settings.langfuse_secret_key,
            host=settings.langfuse_base_url,
        )
        self._handler = CallbackHandler()
        logger.info("LangFuse tracing enabled (base_url=%s)", settings.langfuse_base_url)

    def get_callbacks(self) -> list[Any]:
        """Return the LangFuse callback handler if initialized."""
        if self._handler is None:
            return []
        return [self._handler]

    def shutdown(self) -> None:
        """Flush buffered traces to LangFuse before exit."""
        if self._client is not None:
            try:
                self._client.flush()
            except Exception as exc:  # noqa: BLE001
                logger.warning("LangFuse flush failed: %s", exc)
