"""Base contract for tracing backends."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class BaseTracer(ABC):
    """Provide tracing hooks for LLM observability backends."""

    @abstractmethod
    def setup(self) -> None:
        """Initialize the tracing backend.

        Implementations may set environment variables, initialize SDK
        clients, or perform other one-time setup.
        """
        raise NotImplementedError

    @abstractmethod
    def get_callbacks(self) -> list[Any]:
        """Return callback handlers to attach to LLM calls.

        Returns:
            A list of callback handlers, or an empty list.
        """
        raise NotImplementedError

    def shutdown(self) -> None:
        """Flush pending traces and release resources."""
        return None
