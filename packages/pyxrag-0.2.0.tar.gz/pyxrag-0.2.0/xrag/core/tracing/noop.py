from __future__ import annotations

from typing import Any

from xrag.core.tracing.base import BaseTracer


class NoopTracer(BaseTracer):
    """No-op tracer used when tracing is disabled."""

    def setup(self) -> None:
        """No-op setup."""
        return None

    def get_callbacks(self) -> list[Any]:
        """Return an empty callback list."""
        return []
