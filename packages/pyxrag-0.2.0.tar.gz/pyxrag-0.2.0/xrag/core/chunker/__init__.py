"""Chunker implementations for normalized parser output."""
