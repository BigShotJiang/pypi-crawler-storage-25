"""Base contract for chunker implementations."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class BaseChunker(ABC):
    """Build retrieval chunks from normalized document elements."""

    @abstractmethod
    def run(
        self, doc_id: str | None, elements: list[dict[str, Any]], options: dict[str, Any]
    ) -> list[dict[str, Any]]:
        """Build chunks for one normalized document.

        Args:
            doc_id: Optional document identifier.
            elements: Normalized parser elements for one document.
            options: Provider-specific chunker options.

        Returns:
            A list of chunk records.
        """
        raise NotImplementedError
