from __future__ import annotations

from xrag.config.models import ProviderConfig
from xrag.core.chunker.base import BaseChunker
from xrag.core.chunker.section_table import SectionTableChunker
from xrag.core.chunker.section_token import SectionTokenChunker
from xrag.core.chunker.title_hierarchy import TitleHierarchyChunker


def build_chunker(config: ProviderConfig) -> BaseChunker:
    """Build the configured chunker implementation.

    Args:
        config: Chunker provider config.

    Returns:
        Concrete chunker implementation.
    """
    if config.provider in {"section_table", "current"}:
        return SectionTableChunker()
    if config.provider in {"section_token", "ragflow"}:
        return SectionTokenChunker()
    if config.provider == "title_hierarchy":
        return TitleHierarchyChunker()
    raise ValueError(f"unsupported chunker provider: {config.provider}")
