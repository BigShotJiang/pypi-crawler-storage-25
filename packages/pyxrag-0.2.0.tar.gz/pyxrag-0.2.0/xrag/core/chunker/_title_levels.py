"""Title-level resolution helpers shared by title-based chunkers.

Ports the level-detection logic from RAGFlow's
``rag/flow/chunker/title_chunker/common.py`` and the ``not_bullet`` /
``not_title`` guards from ``rag/nlp/__init__.py``.
"""

from __future__ import annotations

import re
import sys
from collections import Counter
from typing import Any

BODY_LEVEL: int = sys.maxsize - 1
"""Sentinel level assigned to records that are not titles."""

_BULLET_GUARDS: tuple[str, ...] = (r"0", r"[0-9]+ +[0-9~个只-]", r"[0-9]+\.{2,}")
_TITLE_PUNCT = re.compile(r"[,;，。；！!]")


def not_bullet(line: str) -> bool:
    """Return True when the line matches a RAGFlow bullet guard pattern.

    Args:
        line: The candidate title or bullet line.

    Returns:
        True when ``line`` looks like a numeric bullet rather than a heading.
    """
    return any(re.match(pattern, line) for pattern in _BULLET_GUARDS)


def not_title(text: str) -> bool:
    """Return True when the text is unlikely to be a title.

    Ported from RAGFlow ``rag/nlp/__init__.py::not_title``: long lines,
    space-free long lines, and lines containing sentence punctuation are
    rejected.

    Args:
        text: Candidate title text.

    Returns:
        True when the text fails any title heuristic.
    """
    stripped = text.strip()
    if not stripped:
        return True
    if len(stripped.split()) > 12 or (" " not in stripped and len(stripped) >= 32):
        return True
    return bool(_TITLE_PUNCT.search(stripped))


def match_regex_level(text: str, level_group: list[str]) -> int | None:
    """Match the text against each regex in order and return the 1-based level.

    Args:
        text: Candidate title text.
        level_group: Ordered regex patterns; the first match wins.

    Returns:
        The 1-based level index or ``None`` when no pattern matches.
    """
    stripped = text.strip()
    for level, pattern in enumerate(level_group, start=1):
        if re.match(pattern, stripped) and not not_bullet(stripped):
            return level
    return None


def select_level_group(lines: list[str], raw_levels: list[list[str]]) -> list[str]:
    """Pick the regex family with the most matches across the corpus.

    Args:
        lines: All candidate lines from the document.
        raw_levels: A list of regex families; one family is selected to
            assign numeric levels so the levels are consistent.

    Returns:
        The chosen regex family (stripped of empty patterns). Empty list when
        no family matches.
    """
    if not raw_levels:
        return []

    hits = [0] * len(raw_levels)
    for index, group in enumerate(raw_levels):
        for line in lines:
            stripped = line.strip()
            if not stripped:
                continue
            for pattern in group:
                if re.match(pattern, stripped) and not not_bullet(stripped):
                    hits[index] += 1
                    break

    maximum = 0
    selected = -1
    for index, count in enumerate(hits):
        if count <= maximum:
            continue
        selected = index
        maximum = count

    if selected < 0:
        return []
    return [pattern for pattern in raw_levels[selected] if pattern]


def match_layout_level(text: str, layout: str, fallback_level: int) -> int:
    """Classify layout-tagged lines as titles at a fallback level.

    Args:
        text: The candidate line text.
        layout: The element's layout or type label.
        fallback_level: Level to assign when the layout hints at a title.

    Returns:
        ``fallback_level`` when the layout is title-like, else ``BODY_LEVEL``.
    """
    if re.search(r"(section|title|head)", layout, re.IGNORECASE) and not not_title(
        text.split("@")[0].strip()
    ):
        return fallback_level
    return BODY_LEVEL


def resolve_frequency_levels(
    line_records: list[dict[str, Any]],
    raw_levels: list[list[str]],
) -> dict[str, Any]:
    """Assign a level to each line via regex family + layout fallback.

    Args:
        line_records: Records with ``text``, ``doc_type_kwd`` and ``layout``
            keys. Non-text records receive ``BODY_LEVEL``.
        raw_levels: Candidate regex families passed to ``select_level_group``.

    Returns:
        A dict with ``levels`` (list of per-record levels), ``most_level``
        (the most common non-body level or ``None``) and ``source``.
    """
    level_group = select_level_group(
        [record.get("text", "") for record in line_records],
        raw_levels,
    )
    fallback_level = len(level_group) + 1

    levels: list[int] = []
    for record in line_records:
        if record.get("doc_type_kwd") != "text":
            levels.append(BODY_LEVEL)
            continue
        text = record.get("text", "")
        level = match_regex_level(text, level_group)
        if level is not None:
            levels.append(level)
            continue
        levels.append(match_layout_level(text, record.get("layout", "") or "", fallback_level))

    most_level: int | None = None
    for level, _count in Counter(levels).most_common():
        if level < BODY_LEVEL:
            most_level = level
            break

    return {"levels": levels, "most_level": most_level, "source": "frequency"}


def resolve_target_level(levels: list[int], hierarchy: int | None) -> int | None:
    """Map a ``hierarchy`` parameter onto a concrete observed title level.

    Args:
        levels: Per-record levels.
        hierarchy: 1-based cut depth. ``None`` or ``<= 0`` means cut at the
            deepest observed level.

    Returns:
        The target cut level or ``None`` when no title levels exist.
    """
    title_levels = sorted({level for level in levels if 0 < level < BODY_LEVEL})
    if not title_levels:
        return None
    if hierarchy is None or int(hierarchy) <= 0:
        return title_levels[-1]
    hierarchy_num = max(int(hierarchy), 1)
    return title_levels[min(hierarchy_num, len(title_levels)) - 1]
