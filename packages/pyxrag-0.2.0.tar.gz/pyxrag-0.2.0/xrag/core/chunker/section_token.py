from __future__ import annotations

import re
from typing import Any

from xrag.core.chunker.base import BaseChunker
from xrag.core.common.converter import table_html_to_markdown

_TEXT_TYPES = {
    "NarrativeText",
    "ListItem",
    "Title",
    "Header",
    "Text",
    "UncategorizedText",
    "Address",
    "EmailAddress",
}
_NON_CONTENT_TYPES = {"Image", "FigureCaption", "PageBreak", "Footer", "PageFooter", "PageHeader"}


class SectionTokenChunker(BaseChunker):
    """Section-aware chunker with token-budgeted child splits.

    Ported from RAGFlow's naive chunker (``rag/app/naive.py``): one parent
    section per Title/Header, each body split into token-budgeted children
    via configurable delimiters, and table elements wrapped with pre/post
    text context measured in tokens.
    """

    def run(
        self,
        doc_id: str | None,
        elements: list[dict[str, Any]],
        options: dict[str, Any],
    ) -> list[dict[str, Any]]:
        """Build one parent section per Title with token-budgeted children."""
        chunk_token_size = int(options.get("chunk_token_size", 512))
        delimiters = _coerce_delimiters(options.get("delimiters", ["\n"]))
        child_delimiters = _coerce_delimiters(options.get("children_delimiters", []))
        table_context_size = int(options.get("table_context_size", 128))
        use_parent_child = bool(options.get("use_parent_child", bool(child_delimiters)))

        heading_path: list[str] = []
        current_parent_elements: list[dict[str, Any]] = []
        current_parent_heading: list[str] = []
        parent_groups: list[dict[str, Any]] = []

        def flush_parent_group() -> None:
            nonlocal current_parent_elements, current_parent_heading
            if not current_parent_elements:
                return
            parent_groups.append(
                {
                    "heading_path": current_parent_heading[:]
                    if current_parent_heading
                    else ["Document"],
                    "elements": current_parent_elements[:],
                }
            )
            current_parent_elements = []

        for element in elements:
            element_type = str(element.get("type") or "")
            text = _normalize_whitespace(element.get("text") or "")
            if element_type in {"Title", "Header"}:
                flush_parent_group()
                depth = _heading_depth(element)
                heading_path = heading_path[:depth]
                if text:
                    heading_path.append(text)
                current_parent_heading = heading_path[:] if heading_path else ["Document"]
                current_parent_elements = [element]
                continue
            if element_type in _NON_CONTENT_TYPES:
                continue
            current_parent_heading = heading_path[:] if heading_path else ["Document"]
            current_parent_elements.append(element)

        flush_parent_group()

        chunks: list[dict[str, Any]] = []
        chunk_index = 0

        def next_chunk_id() -> str:
            nonlocal chunk_index
            chunk_index += 1
            prefix = doc_id or "document"
            return f"{prefix}:chunk:{chunk_index}"

        for group in parent_groups:
            parent_chunk_id = next_chunk_id()
            parent_text = _group_parent_content(group["elements"])
            parent_chunk = {
                "chunk_id": parent_chunk_id,
                "doc_id": doc_id,
                "chunk_type": "section",
                "chunk_strategy": "section_token",
                "heading_path": group["heading_path"],
                "content": parent_text,
                "source_element_ids": _element_ids(group["elements"]),
                "page_number": _first_page_number(group["elements"]),
                "parent_chunk_id": None,
                "child_chunk_ids": [],
            }
            chunks.append(parent_chunk)

            linear_units = _build_linear_units(group["elements"])
            child_texts = _merge_text_units(
                linear_units=linear_units,
                chunk_token_size=chunk_token_size,
                delimiters=delimiters,
            )
            if use_parent_child and child_delimiters:
                child_texts = _split_child_chunks(child_texts, child_delimiters)

            child_chunks = _build_child_chunks(
                doc_id=doc_id,
                parent_chunk_id=parent_chunk_id,
                heading_path=group["heading_path"],
                child_texts=child_texts,
                linear_units=linear_units,
                chunk_token_size=chunk_token_size,
                table_context_size=table_context_size,
                next_chunk_id=next_chunk_id,
            )
            parent_chunk["child_chunk_ids"].extend(chunk["chunk_id"] for chunk in child_chunks)
            chunks.extend(child_chunks)

        _add_ragflow_aliases(chunks, doc_id=doc_id)
        return chunks


def _build_linear_units(elements: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Convert elements into ordered text and table units."""
    units: list[dict[str, Any]] = []
    for element in elements:
        element_type = str(element.get("type") or "")
        if element_type in {"Title", "Header"}:
            continue
        if element_type == "Table":
            metadata = element.get("metadata") or {}
            units.append(
                {
                    "kind": "table",
                    "text": _normalize_whitespace(element.get("text") or ""),
                    "table_html": metadata.get("text_as_html"),
                    "element": element,
                }
            )
            continue
        if element_type in _TEXT_TYPES:
            text = _normalize_whitespace(element.get("text") or "")
            if text:
                units.append({"kind": "text", "text": text, "element": element})
    return units


def _merge_text_units(
    linear_units: list[dict[str, Any]],
    chunk_token_size: int,
    delimiters: list[str],
) -> list[dict[str, Any]]:
    """Merge text units into token-sized chunks and preserve table units."""
    merged: list[dict[str, Any]] = []
    active_texts: list[str] = []
    active_elements: list[dict[str, Any]] = []

    def flush_texts() -> None:
        nonlocal active_texts, active_elements
        if not active_texts:
            return
        text = "\n".join(active_texts).strip()
        if text:
            merged.extend(
                _split_text_into_token_chunks(text, active_elements, chunk_token_size, delimiters)
            )
        active_texts = []
        active_elements = []

    for unit in linear_units:
        if unit["kind"] == "table":
            flush_texts()
            merged.append(unit)
            continue
        active_texts.append(unit["text"])
        active_elements.append(unit["element"])
    flush_texts()
    return merged


def _split_text_into_token_chunks(
    text: str,
    elements: list[dict[str, Any]],
    chunk_token_size: int,
    delimiters: list[str],
) -> list[dict[str, Any]]:
    """Split text with RAGFlow-style delimiter-first, token-budget-second logic."""
    pattern = _compile_delimiter_pattern(delimiters)
    segments = _split_text_by_pattern(text, pattern) if pattern else [text]
    chunks: list[dict[str, Any]] = []
    buffer: list[str] = []
    for segment in segments:
        candidate = "\n".join(buffer + [segment]).strip()
        if buffer and _estimate_tokens(candidate) > chunk_token_size:
            chunks.append(
                {
                    "kind": "text",
                    "text": "\n".join(buffer).strip(),
                    "elements": elements[:],
                }
            )
            buffer = [segment]
            continue
        buffer.append(segment)
    if buffer:
        chunks.append({"kind": "text", "text": "\n".join(buffer).strip(), "elements": elements[:]})
    return [chunk for chunk in chunks if chunk["text"]]


def _split_child_chunks(
    child_texts: list[dict[str, Any]], delimiters: list[str]
) -> list[dict[str, Any]]:
    """Split parent text chunks into smaller child chunks using child delimiters."""
    pattern = _compile_delimiter_pattern(delimiters)
    if not pattern:
        return child_texts

    result: list[dict[str, Any]] = []
    for chunk in child_texts:
        if chunk["kind"] != "text":
            result.append(chunk)
            continue
        segments = _split_text_by_pattern(chunk["text"], pattern)
        if len(segments) <= 1:
            result.append(chunk)
            continue
        for segment in segments:
            text = segment.strip()
            if text:
                result.append({"kind": "text", "text": text, "elements": chunk["elements"][:]})
    return result


def _build_child_chunks(
    doc_id: str | None,
    parent_chunk_id: str,
    heading_path: list[str],
    child_texts: list[dict[str, Any]],
    linear_units: list[dict[str, Any]],
    chunk_token_size: int,
    table_context_size: int,
    next_chunk_id,
) -> list[dict[str, Any]]:
    """Build child chunks from merged text and table units."""
    children: list[dict[str, Any]] = []
    for index, unit in enumerate(child_texts):
        if unit["kind"] == "text":
            elements = unit["elements"]
            children.append(
                {
                    "chunk_id": next_chunk_id(),
                    "doc_id": doc_id,
                    "chunk_type": "text",
                    "chunk_strategy": "section_token",
                    "heading_path": heading_path,
                    "content": unit["text"],
                    "source_element_ids": _element_ids(elements),
                    "page_number": _first_page_number(elements),
                    "parent_chunk_id": parent_chunk_id,
                    "token_count": _estimate_tokens(unit["text"]),
                }
            )
            continue

        table_element = unit["element"]
        pre_text = _collect_context(
            child_texts, index=index, direction=-1, token_budget=table_context_size
        )
        post_text = _collect_context(
            child_texts, index=index, direction=1, token_budget=table_context_size
        )
        table_text = unit["text"]
        table_text_markdown = table_html_to_markdown(
            unit.get("table_html"),
            fallback_text=table_text,
        )
        content_parts = []
        if heading_path:
            content_parts.append(f"Section: {' > '.join(heading_path)}")
        if pre_text:
            content_parts.append(f"Pre-context:\n{pre_text}")
        content_parts.append(f"Table:\n{table_text}")
        if post_text:
            content_parts.append(f"Post-context:\n{post_text}")
        children.append(
            {
                "chunk_id": next_chunk_id(),
                "doc_id": doc_id,
                "chunk_type": "table",
                "chunk_strategy": "section_token",
                "heading_path": heading_path,
                "content": "\n\n".join(content_parts).strip(),
                "source_element_ids": [str(table_element.get("element_id", ""))],
                "page_number": _page_number(table_element),
                "parent_chunk_id": parent_chunk_id,
                "table_html": unit.get("table_html"),
                "table_text": table_text,
                "table_text_markdown": table_text_markdown,
                "pre_text": pre_text,
                "post_text": post_text,
                "token_count": min(
                    _estimate_tokens(table_text)
                    + _estimate_tokens(pre_text)
                    + _estimate_tokens(post_text),
                    chunk_token_size + (2 * table_context_size),
                ),
            }
        )
    return children


def _collect_context(
    units: list[dict[str, Any]],
    index: int,
    direction: int,
    token_budget: int,
) -> str:
    """Collect surrounding text chunks for table context."""
    if token_budget <= 0:
        return ""
    collected: list[str] = []
    remaining = token_budget
    cursor = index + direction
    while 0 <= cursor < len(units) and remaining > 0:
        unit = units[cursor]
        if unit["kind"] == "table":
            cursor += direction
            continue
        sentences = _split_sentences(unit["text"])
        if direction < 0:
            sentences = list(reversed(sentences))
        current = []
        for sentence in sentences:
            tokens = _estimate_tokens(sentence)
            if tokens > remaining and current:
                break
            if tokens > remaining:
                current.append(sentence)
                remaining = 0
                break
            current.append(sentence)
            remaining -= tokens
        if direction < 0:
            current = list(reversed(current))
            collected.insert(0, "".join(current).strip())
        else:
            collected.append("".join(current).strip())
        cursor += direction
    return "\n".join(part for part in collected if part).strip()


def _compile_delimiter_pattern(delimiters: list[str]) -> str:
    """Compile RAGFlow-style backtick custom delimiters."""
    raw_delimiters = "".join(delimiter for delimiter in delimiters if delimiter)
    custom_delimiters = [match.group(1) for match in re.finditer(r"`([^`]+)`", raw_delimiters)]
    if not custom_delimiters:
        return ""
    return "|".join(
        re.escape(text) for text in sorted(set(custom_delimiters), key=len, reverse=True)
    )


def _split_text_by_pattern(text: str, pattern: str) -> list[str]:
    """Split text and keep custom delimiter text with the left chunk."""
    if not pattern:
        return [text]
    split_texts = re.split(rf"({pattern})", text, flags=re.DOTALL)
    chunks: list[str] = []
    for index in range(0, len(split_texts), 2):
        chunk = split_texts[index]
        if index + 1 < len(split_texts):
            chunk += split_texts[index + 1]
        chunk = chunk.strip()
        if chunk:
            chunks.append(chunk)
    return chunks


def _split_sentences(text: str) -> list[str]:
    """Split text into sentence-like units for context attachment."""
    parts = re.split(r"([.。！？!?；;：:\n])", text)
    sentences: list[str] = []
    buffer = ""
    for part in parts:
        if not part:
            continue
        buffer += part
        if re.fullmatch(r"[.。！？!?；;：:\n]", part):
            sentences.append(buffer)
            buffer = ""
    if buffer:
        sentences.append(buffer)
    return sentences


def _group_parent_content(elements: list[dict[str, Any]]) -> str:
    """Build a parent chunk body from grouped elements."""
    parts: list[str] = []
    for element in elements:
        text = _normalize_whitespace(element.get("text") or "")
        if text:
            parts.append(text)
    return "\n\n".join(parts).strip()


def _coerce_delimiters(value: Any) -> list[str]:
    """Normalize delimiter config into a string list."""
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        return [item for item in value if isinstance(item, str) and item]
    return []


def _element_ids(elements: list[dict[str, Any]]) -> list[str]:
    """Extract non-empty element ids."""
    return [str(element.get("element_id", "")) for element in elements if element.get("element_id")]


def _heading_depth(element: dict[str, Any]) -> int:
    """Return normalized zero-based heading depth."""
    metadata = element.get("metadata") or {}
    depth = metadata.get("category_depth")
    if isinstance(depth, int) and depth >= 0:
        return depth
    return 0


def _page_number(element: dict[str, Any]) -> int | None:
    """Return the page number when present."""
    page_number = (element.get("metadata") or {}).get("page_number")
    return page_number if isinstance(page_number, int) else None


def _first_page_number(elements: list[dict[str, Any]]) -> int | None:
    """Return the first available page number across a list of elements."""
    for element in elements:
        page_number = _page_number(element)
        if page_number is not None:
            return page_number
    return None


def _estimate_tokens(text: str) -> int:
    """Estimate token count conservatively from whitespace-separated terms."""
    if not text:
        return 0
    return max(1, len(re.findall(r"\S+", text)))


def _normalize_whitespace(value: str) -> str:
    """Collapse repeated whitespace while preserving line breaks."""
    value = re.sub(r"[ \t]+", " ", value)
    value = re.sub(r"\n{3,}", "\n\n", value)
    return value.strip()


def _add_ragflow_aliases(chunks: list[dict[str, Any]], doc_id: str | None) -> None:
    """Annotate chunks with RAGFlow-compatible alias fields in-place.

    Adds ``docnm_kwd``, ``tag_kwd``, ``doc_type_kwd``, ``position_int``.
    See ``section_table._add_ragflow_aliases`` for the full contract.
    """
    doc_name = doc_id or "document"
    for chunk in chunks:
        chunk_type = chunk.get("chunk_type", "text")
        chunk["docnm_kwd"] = doc_name
        chunk["tag_kwd"] = [chunk_type]
        chunk["doc_type_kwd"] = "table" if chunk_type == "table" else "text"
        page_number = chunk.get("page_number")
        chunk["position_int"] = [int(page_number)] if isinstance(page_number, int) else []
