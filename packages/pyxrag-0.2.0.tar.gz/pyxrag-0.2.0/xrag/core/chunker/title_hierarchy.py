"""Hierarchical title chunker.

Ports RAGFlow's ``HierarchyTitleChunker`` (``rag/flow/chunker/title_chunker/
hierarchy_chunker.py``) onto our Unstructured-normalized element stream.

Pipeline:
1. Convert parser elements into RAGFlow-style line records with ``text``,
   ``doc_type_kwd`` (``text`` / ``table`` / ``image``), ``layout`` (element
   type) and carry-through ``element_id`` / ``page_number``.
2. Resolve a numeric level for every line via the frequency-based regex
   selector with a layout fallback — see ``_title_levels``.
3. Build a section tree over text records, DFS to emit one chunk per leaf
   path. Tables and images are intercalated in document order; each carries
   the ambient heading stack at its position so context is preserved even
   when they sit between paragraphs of the same section.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from typing import Any

from xrag.core.chunker._title_levels import (
    BODY_LEVEL,
    resolve_frequency_levels,
    resolve_target_level,
)
from xrag.core.chunker.base import BaseChunker
from xrag.core.common.converter import table_html_to_markdown

_CHUNK_STRATEGY = "title_hierarchy"
_NON_CONTENT_TYPES = {"PageBreak", "Footer", "PageFooter", "PageHeader", "FigureCaption"}
_TEXT_TYPES = {
    "Title",
    "Header",
    "NarrativeText",
    "ListItem",
    "Text",
    "UncategorizedText",
    "Address",
    "EmailAddress",
}


class _ChunkNode:
    """Tree node used during hierarchical leaf-path extraction."""

    def __init__(
        self,
        level: int,
        title_indexes: list[int] | None = None,
        body_indexes: list[int] | None = None,
    ) -> None:
        self.level = level
        self.title_indexes = title_indexes or []
        self.body_indexes = body_indexes or []
        self.children: list[_ChunkNode] = []

    def add_body_index(self, index: int) -> None:
        """Append a body-line index under this node."""
        self.body_indexes.append(index)

    def build_tree(self, indexed_lines: list[tuple[int, int]], depth: int) -> _ChunkNode:
        """Build the section tree from ``(level, index)`` pairs.

        Args:
            indexed_lines: Ordered sequence of per-record ``(level, index)``.
            depth: Maximum title depth; lines below this count as body.

        Returns:
            This node, populated as the root of the tree.
        """
        stack: list[_ChunkNode] = [self]
        for level, index in indexed_lines:
            if level > depth:
                stack[-1].add_body_index(index)
                continue
            while len(stack) > 1 and level <= stack[-1].level:
                stack.pop()
            node = _ChunkNode(level, title_indexes=[index])
            stack[-1].children.append(node)
            stack.append(node)
        return self

    def get_paths(self, depth: int, include_heading_content: bool) -> list[list[int]]:
        """Return the list of leaf paths as record-index sequences."""
        paths: list[list[int]] = []
        self._dfs(paths, [], depth, include_heading_content)
        return paths

    def _dfs(
        self,
        paths: list[list[int]],
        titles: list[int],
        depth: int,
        include_heading_content: bool,
    ) -> None:
        """Depth-first emit leaf paths under the current node."""
        if self.level == 0 and self.body_indexes:
            paths.append(titles + self.body_indexes)

        if include_heading_content:
            path_titles = titles + self.title_indexes if 1 <= self.level <= depth else titles
            if self.body_indexes and 1 <= self.level <= depth:
                paths.append(path_titles + self.body_indexes)
            elif not self.children and 1 <= self.level <= depth:
                paths.append(path_titles)
        else:
            path_titles = (
                titles + self.title_indexes + self.body_indexes
                if 1 <= self.level <= depth
                else titles
            )
            if not self.children and 1 <= self.level <= depth:
                paths.append(path_titles)

        for child in self.children:
            child._dfs(paths, path_titles, depth, include_heading_content)


class TitleHierarchyChunker(BaseChunker):
    """Emit one leaf chunk per section path in a title-inferred hierarchy."""

    def run(
        self,
        doc_id: str | None,
        elements: list[dict[str, Any]],
        options: dict[str, Any],
    ) -> list[dict[str, Any]]:
        """Build hierarchical leaf chunks with ancestor titles inlined.

        Args:
            doc_id: Optional document identifier used for chunk id prefixes.
            elements: Unstructured-normalized elements for one document.
            options: Supports ``levels`` (list of regex families),
                ``hierarchy`` (1-based depth cut; 0/None → deepest),
                ``include_heading_content`` (bool) and
                ``root_chunk_as_heading`` (bool).

        Returns:
            A flat list of chunks in document order.
        """
        levels_option = options.get("levels") or []
        raw_levels = _normalize_levels_option(levels_option)
        hierarchy = options.get("hierarchy")
        include_heading_content = bool(options.get("include_heading_content", False))
        root_chunk_as_heading = bool(options.get("root_chunk_as_heading", False))

        line_records = _to_line_records(elements)
        if not line_records:
            return []

        resolved = resolve_frequency_levels(line_records, raw_levels)
        target_level = resolve_target_level(resolved["levels"], hierarchy)
        _attach_levels(line_records, resolved["levels"])
        heading_stacks = _compute_heading_stacks(line_records)

        positioned_groups = _group_records(
            line_records=line_records,
            target_level=target_level,
            include_heading_content=include_heading_content,
            heading_stacks=heading_stacks,
        )

        chunk_index = 0

        def next_chunk_id() -> str:
            nonlocal chunk_index
            chunk_index += 1
            prefix = doc_id or "document"
            return f"{prefix}:chunk:{chunk_index}"

        chunks = [
            _materialize_chunk(
                group=group,
                doc_id=doc_id,
                next_chunk_id=next_chunk_id,
                target_level=target_level,
            )
            for _position, group in positioned_groups
            if group
        ]

        if root_chunk_as_heading and len(chunks) > 1:
            root = chunks[0]
            prefix = root.get("content", "")
            for chunk in chunks[1:]:
                if prefix:
                    chunk["content"] = f"{prefix}\n{chunk.get('content', '')}".strip()
            return chunks[1:]
        return chunks


def _to_line_records(elements: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Convert Unstructured elements into RAGFlow-style line records."""
    records: list[dict[str, Any]] = []
    for element in elements:
        element_type = str(element.get("type") or "")
        text = _normalize_whitespace(element.get("text") or "")
        if element_type in _NON_CONTENT_TYPES:
            continue
        if element_type == "Table":
            records.append(_build_record(element, text, element_type, "table"))
            continue
        if element_type == "Image":
            records.append(_build_record(element, text, element_type, "image"))
            continue
        if element_type not in _TEXT_TYPES or not text:
            continue
        records.append(_build_record(element, text, element_type, "text"))
    return records


def _build_record(
    element: dict[str, Any],
    text: str,
    element_type: str,
    doc_type_kwd: str,
) -> dict[str, Any]:
    """Build a single line record carrying our element metadata."""
    metadata = element.get("metadata") or {}
    return {
        "text": text,
        "doc_type_kwd": doc_type_kwd,
        "layout": element_type,
        "element_id": str(element.get("element_id") or ""),
        "page_number": metadata.get("page_number"),
        "element": element,
    }


def _attach_levels(line_records: list[dict[str, Any]], levels: list[int]) -> None:
    """Mutate each record with its resolved numeric level."""
    for record, level in zip(line_records, levels, strict=True):
        record["_level"] = level


def _compute_heading_stacks(
    line_records: list[dict[str, Any]],
) -> list[list[str]]:
    """Return the ambient heading stack at each record's position.

    The stack at position ``i`` holds the ancestor title texts in depth
    order that are active when record ``i`` is reached.

    Args:
        line_records: Records with ``_level`` attached.

    Returns:
        A list the same length as ``line_records``.
    """
    stacks: list[list[str]] = []
    current: list[tuple[int, str]] = []
    for record in line_records:
        level = int(record.get("_level", BODY_LEVEL))
        if record.get("doc_type_kwd") == "text" and level < BODY_LEVEL:
            current = [(lvl, text) for lvl, text in current if lvl < level]
            current.append((level, record.get("text", "")))
        stacks.append([text for _level, text in current])
    return stacks


def _group_records(
    line_records: list[dict[str, Any]],
    target_level: int | None,
    include_heading_content: bool,
    heading_stacks: list[list[str]],
) -> list[tuple[int, list[dict[str, Any]]]]:
    """Build leaf-path groups over text records plus standalone non-text groups.

    Returns:
        ``(position, group)`` pairs sorted by document position so downstream
        chunk ids follow the original order.
    """
    text_positions = [
        index for index, record in enumerate(line_records) if record.get("doc_type_kwd") == "text"
    ]
    text_records = [line_records[i] for i in text_positions]
    text_levels = [int(line_records[i]["_level"]) for i in text_positions]

    groups: list[tuple[int, list[dict[str, Any]]]] = []

    if text_records:
        if target_level is None:
            groups.append((text_positions[0], text_records.copy()))
        else:
            root = _ChunkNode(0)
            root.build_tree(
                list(zip(text_levels, range(len(text_records)), strict=True)),
                target_level,
            )
            for path in root.get_paths(target_level, include_heading_content):
                if not path:
                    continue
                group = [text_records[i] for i in path]
                position = text_positions[path[0]]
                groups.append((position, group))

    for index, record in enumerate(line_records):
        if record.get("doc_type_kwd") == "text":
            continue
        stamped = dict(record)
        stamped["_heading_stack"] = heading_stacks[index]
        groups.append((index, [stamped]))

    groups.sort(key=lambda item: item[0])
    return groups


def _materialize_chunk(
    group: list[dict[str, Any]],
    doc_id: str | None,
    next_chunk_id: Callable[[], str],
    target_level: int | None,
) -> dict[str, Any]:
    """Convert a record group into our final chunk dict."""
    first = group[0]
    kind = first.get("doc_type_kwd", "text")

    if kind == "table":
        heading_path = list(first.get("_heading_stack") or [])
        return _materialize_table_chunk(first, heading_path, doc_id, next_chunk_id)
    if kind == "image":
        heading_path = list(first.get("_heading_stack") or [])
        return _materialize_image_chunk(first, heading_path, doc_id, next_chunk_id)

    heading_cutoff = target_level if target_level is not None else 0
    heading_path = [
        record.get("text", "")
        for record in group
        if 0 < int(record.get("_level", BODY_LEVEL)) <= heading_cutoff and record.get("text")
    ]
    content = "\n".join(record["text"] for record in group if record.get("text")).strip()
    element_ids = [record["element_id"] for record in group if record.get("element_id")]
    page_number = _first_page(group)
    return {
        "chunk_id": next_chunk_id(),
        "doc_id": doc_id,
        "chunk_type": "text",
        "chunk_strategy": _CHUNK_STRATEGY,
        "heading_path": heading_path or ["Document"],
        "content": content,
        "source_element_ids": element_ids,
        "page_number": page_number,
        "parent_chunk_id": None,
    }


def _materialize_table_chunk(
    record: dict[str, Any],
    heading_path: list[str],
    doc_id: str | None,
    next_chunk_id: Callable[[], str],
) -> dict[str, Any]:
    """Build a table chunk that carries the ambient heading path."""
    element = record.get("element") or {}
    metadata = element.get("metadata") or {}
    table_text = record.get("text", "")
    table_html = metadata.get("text_as_html")
    table_text_markdown = table_html_to_markdown(table_html, fallback_text=table_text)

    content_parts: list[str] = []
    if heading_path:
        content_parts.append(f"Section: {' > '.join(heading_path)}")
    content_parts.append(f"Table:\n{table_text}")

    return {
        "chunk_id": next_chunk_id(),
        "doc_id": doc_id,
        "chunk_type": "table",
        "chunk_strategy": _CHUNK_STRATEGY,
        "heading_path": heading_path or ["Document"],
        "content": "\n\n".join(content_parts).strip(),
        "source_element_ids": [record["element_id"]] if record.get("element_id") else [],
        "page_number": record.get("page_number"),
        "parent_chunk_id": None,
        "table_html": table_html,
        "table_text": table_text,
        "table_text_markdown": table_text_markdown,
    }


def _materialize_image_chunk(
    record: dict[str, Any],
    heading_path: list[str],
    doc_id: str | None,
    next_chunk_id: Callable[[], str],
) -> dict[str, Any]:
    """Build an image chunk that carries the ambient heading path."""
    caption = record.get("text", "")
    content_parts: list[str] = []
    if heading_path:
        content_parts.append(f"Section: {' > '.join(heading_path)}")
    if caption:
        content_parts.append(f"Image: {caption}")

    return {
        "chunk_id": next_chunk_id(),
        "doc_id": doc_id,
        "chunk_type": "image",
        "chunk_strategy": _CHUNK_STRATEGY,
        "heading_path": heading_path or ["Document"],
        "content": "\n\n".join(content_parts).strip(),
        "source_element_ids": [record["element_id"]] if record.get("element_id") else [],
        "page_number": record.get("page_number"),
        "parent_chunk_id": None,
    }


def _first_page(group: list[dict[str, Any]]) -> int | None:
    """Return the first non-null page number in the group."""
    for record in group:
        page = record.get("page_number")
        if isinstance(page, int):
            return page
    return None


def _normalize_levels_option(value: Any) -> list[list[str]]:
    """Normalize the ``levels`` option into a list of regex families."""
    if not value:
        return []
    if isinstance(value, list) and value and isinstance(value[0], str):
        return [list(value)]
    if isinstance(value, list):
        groups: list[list[str]] = []
        for item in value:
            if isinstance(item, list):
                groups.append([str(pattern) for pattern in item if pattern])
            elif isinstance(item, str):
                groups.append([item])
        return groups
    return []


def _normalize_whitespace(value: str) -> str:
    """Collapse runs of whitespace while preserving line breaks."""
    value = re.sub(r"[ \t]+", " ", value)
    value = re.sub(r"\n{3,}", "\n\n", value)
    return value.strip()
