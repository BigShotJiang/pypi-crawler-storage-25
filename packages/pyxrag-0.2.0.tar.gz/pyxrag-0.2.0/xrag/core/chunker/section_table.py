from __future__ import annotations

import re
from typing import Any

from xrag.config.settings import get_settings
from xrag.core.chunker.base import BaseChunker
from xrag.core.common.converter import table_html_to_markdown

_TEXT_TYPES = {
    "NarrativeText",
    "ListItem",
    "Title",
    "Header",
    "Text",
    "UncategorizedText",
    "Address",
    "EmailAddress",
}
_NON_CONTENT_TYPES = {"Image", "FigureCaption", "PageBreak", "Footer", "PageFooter", "PageHeader"}
_CHUNK_STRATEGY = "section_table"

# Financial docs often style parenthetical captions like
# ``(Stated in U.S. Dollars ("US$"))`` as Title/Header in Unstructured output.
# Treating them as headings pollutes heading_path for the balance sheet and
# income-statement tables that live immediately under such captions. Detect
# text whose entire content is wrapped in parentheses so we can fall back to
# the prior heading instead of promoting the caption.
_PARENTHETICAL_CAPTION_RE = re.compile(r"^\(.*\)\.?$", re.DOTALL)


class SectionTableChunker(BaseChunker):
    """Section-aware chunker that preserves text and table structure."""

    def run(
        self,
        doc_id: str | None,
        elements: list[dict[str, Any]],
        options: dict[str, Any],
    ) -> list[dict[str, Any]]:
        """Build parent-child chunks for one normalized document.

        Per-call options (override the global ``settings``):
            - ``section_content_max_chars`` (int) — cap on section parent
              summaries AND text children.
            - ``table_neighbor_count`` (int) — number of neighbor text
              elements collected as ``pre_text`` / ``post_text`` per table.
        """
        settings = get_settings()
        section_max_chars = int(
            options.get("section_content_max_chars", settings.section_content_max_chars)
        )
        neighbor_count = int(options.get("table_neighbor_count", settings.table_neighbor_count))
        section_contexts: dict[tuple[str, ...], dict[str, Any]] = {}
        child_chunks: list[dict[str, Any]] = []
        current_heading_path: list[str] = []
        active_text_group: list[dict[str, Any]] = []
        chunk_index = 0

        def next_chunk_id() -> str:
            nonlocal chunk_index
            chunk_index += 1
            prefix = doc_id or "document"
            return f"{prefix}:chunk:{chunk_index}"

        def register_section(path: list[str], page_number: int | None) -> str:
            key = tuple(path)
            if key not in section_contexts:
                heading_path = path[:] if path else ["Document"]
                section_contexts[key] = {
                    "chunk_id": next_chunk_id(),
                    "doc_id": doc_id,
                    "chunk_strategy": _CHUNK_STRATEGY,
                    "chunk_type": "section",
                    "heading_path": heading_path,
                    "content": " > ".join(heading_path),
                    "source_element_ids": [],
                    "page_number": page_number,
                    "parent_chunk_id": None,
                    "child_chunk_ids": [],
                }
            elif section_contexts[key]["page_number"] is None and page_number is not None:
                section_contexts[key]["page_number"] = page_number
            return str(section_contexts[key]["chunk_id"])

        def update_section_context(path: list[str], text: str, element_ids: list[str]) -> None:
            key = tuple(path)
            if key not in section_contexts:
                register_section(path, page_number=None)
            section = section_contexts[key]
            if text:
                # Dedup at paragraph granularity: both flush_text_group (body
                # text) and _build_table_chunk (table pre_text) feed into the
                # section body, and their ranges overlap. See F3 in
                # docs/sub-plans/retrieval-quality-fixes.md.
                existing_content = section["content"]
                heading_only = " > ".join(section["heading_path"])
                novel_paragraphs = [
                    paragraph
                    for paragraph in (p.strip() for p in text.split("\n\n"))
                    if paragraph and paragraph not in existing_content
                ]
                if novel_paragraphs:
                    novel_text = "\n\n".join(novel_paragraphs)
                    if existing_content and existing_content != heading_only:
                        candidate = f"{existing_content}\n\n{novel_text}"
                    else:
                        candidate = f"{heading_only}\n\n{novel_text}".strip()
                    section["content"] = candidate[:section_max_chars].strip()
            for element_id in element_ids:
                if element_id and element_id not in section["source_element_ids"]:
                    section["source_element_ids"].append(element_id)

        def flush_text_group() -> None:
            if not active_text_group:
                return
            texts = [
                _normalize_whitespace(element.get("text") or "") for element in active_text_group
            ]
            content = "\n".join(text for text in texts if text).strip()
            if not content:
                active_text_group.clear()
                return
            page_number = _first_page_number(active_text_group)
            parent_chunk_id = register_section(current_heading_path, page_number=page_number)
            element_ids = [str(element.get("element_id", "")) for element in active_text_group]
            heading_path = current_heading_path[:] if current_heading_path else ["Document"]
            # Split oversized aggregations using a line → sentence → word
            # separator hierarchy. Sub-chunks share parent + element provenance;
            # exact element-to-sub-chunk attribution would need offset tracking.
            sub_texts = _split_text_to_budget(content, section_max_chars)
            for sub_text in sub_texts:
                chunk = {
                    "chunk_id": next_chunk_id(),
                    "doc_id": doc_id,
                    "chunk_strategy": _CHUNK_STRATEGY,
                    "chunk_type": "text",
                    "heading_path": heading_path[:],
                    "content": sub_text,
                    "source_element_ids": element_ids[:],
                    "page_number": page_number,
                    "parent_chunk_id": parent_chunk_id,
                    "token_count": _estimate_tokens(sub_text),
                }
                child_chunks.append(chunk)
                section_contexts[tuple(current_heading_path)]["child_chunk_ids"].append(
                    chunk["chunk_id"]
                )
            update_section_context(current_heading_path, content, element_ids)
            active_text_group.clear()

        for index, element in enumerate(elements):
            element_type = str(element.get("type") or "")
            text = _normalize_whitespace(element.get("text") or "")
            if element_type in {"Title", "Header"}:
                if _is_parenthetical_caption(text):
                    # Caption styled as Title in the parser — treat as body text
                    # so the real preceding heading stays in heading_path.
                    if text:
                        active_text_group.append(element)
                    continue
                flush_text_group()
                depth = _heading_depth(element)
                title_text = text or element_type
                current_heading_path = current_heading_path[:depth]
                current_heading_path.append(title_text)
                register_section(current_heading_path, page_number=_page_number(element))
                continue

            if element_type == "Table":
                flush_text_group()
                table_chunk = _build_table_chunk(
                    doc_id=doc_id,
                    element=element,
                    elements=elements,
                    index=index,
                    heading_path=current_heading_path,
                    next_chunk_id=next_chunk_id,
                    register_section=register_section,
                    update_section_context=update_section_context,
                    neighbor_count=neighbor_count,
                )
                child_chunks.append(table_chunk)
                section_contexts[tuple(current_heading_path)]["child_chunk_ids"].append(
                    table_chunk["chunk_id"]
                )
                continue

            if element_type in _NON_CONTENT_TYPES:
                flush_text_group()
                continue

            if element_type in _TEXT_TYPES and text:
                active_text_group.append(element)
                continue

            flush_text_group()

        flush_text_group()

        ordered_sections = sorted(
            section_contexts.values(),
            key=lambda chunk: int(str(chunk["chunk_id"]).rsplit(":", maxsplit=1)[-1]),
        )
        all_chunks = ordered_sections + child_chunks
        _add_ragflow_aliases(all_chunks, doc_id=doc_id)
        return all_chunks


def _build_table_chunk(
    doc_id: str | None,
    element: dict[str, Any],
    elements: list[dict[str, Any]],
    index: int,
    heading_path: list[str],
    next_chunk_id,
    register_section,
    update_section_context,
    neighbor_count: int = 2,
) -> dict[str, Any]:
    """Build one table chunk with attached nearby text context."""
    page_number = _page_number(element)
    parent_chunk_id = register_section(heading_path, page_number=page_number)
    pre_elements = _collect_neighbor_text(
        elements, start=index - 1, step=-1, max_count=neighbor_count
    )
    post_elements = _collect_neighbor_text(
        elements, start=index + 1, step=1, max_count=neighbor_count
    )
    pre_text = "\n".join(
        _normalize_whitespace(item.get("text") or "") for item in reversed(pre_elements)
    ).strip()
    post_text = "\n".join(
        _normalize_whitespace(item.get("text") or "") for item in post_elements
    ).strip()
    metadata = element.get("metadata") or {}
    table_text = _normalize_whitespace(element.get("text") or "")
    table_html = metadata.get("text_as_html")
    table_text_markdown = table_html_to_markdown(table_html, fallback_text=table_text)
    content_parts = []
    if heading_path:
        content_parts.append(f"Section: {' > '.join(heading_path)}")
    if pre_text:
        content_parts.append(f"Pre-context:\n{pre_text}")
    if table_text:
        content_parts.append(f"Table:\n{table_text}")
    if post_text:
        content_parts.append(f"Post-context:\n{post_text}")
    content = "\n\n".join(content_parts).strip()

    source_element_ids = [str(element.get("element_id", ""))]
    source_element_ids.extend(str(item.get("element_id", "")) for item in pre_elements)
    source_element_ids.extend(str(item.get("element_id", "")) for item in post_elements)
    source_element_ids = [element_id for element_id in source_element_ids if element_id]

    chunk = {
        "chunk_id": next_chunk_id(),
        "doc_id": doc_id,
        "chunk_strategy": _CHUNK_STRATEGY,
        "chunk_type": "table",
        "heading_path": heading_path[:] if heading_path else ["Document"],
        "content": content,
        "source_element_ids": source_element_ids,
        "page_number": page_number,
        "parent_chunk_id": parent_chunk_id,
        "table_html": table_html,
        "table_text": table_text,
        "table_text_markdown": table_text_markdown,
        "pre_text": pre_text,
        "post_text": post_text,
        "token_count": _estimate_tokens(content),
    }
    update_section_context(heading_path, pre_text or table_text, source_element_ids)
    return chunk


def _collect_neighbor_text(
    elements: list[dict[str, Any]],
    start: int,
    step: int,
    max_count: int = 2,
) -> list[dict[str, Any]]:
    """Collect nearby text elements for table context."""
    collected: list[dict[str, Any]] = []
    index = start
    while 0 <= index < len(elements) and len(collected) < max_count:
        element = elements[index]
        element_type = str(element.get("type") or "")
        text = _normalize_whitespace(element.get("text") or "")
        if element_type in {"Title", "Header", "Table"}:
            break
        if element_type in _TEXT_TYPES and text:
            collected.append(element)
            index += step
            continue
        if element_type in _NON_CONTENT_TYPES:
            index += step
            continue
        break
    return collected


def _is_parenthetical_caption(text: str) -> bool:
    """Return True if ``text`` is a parenthetical caption styled as a heading.

    Currency / unit captions like ``(Stated in U.S. Dollars ("US$"))`` are
    routinely classified as ``Title`` by Unstructured on financial statements
    and push the real section heading (e.g. "Consolidated Balance Sheets")
    out of ``heading_path`` — see ``docs/sub-plans/retrieval-quality-fixes.md`` F2.
    """
    stripped = text.strip()
    if not stripped or len(stripped) < 2:
        return False
    return bool(_PARENTHETICAL_CAPTION_RE.match(stripped))


def _heading_depth(element: dict[str, Any]) -> int:
    """Return normalized zero-based heading depth."""
    metadata = element.get("metadata") or {}
    depth = metadata.get("category_depth")
    if isinstance(depth, int) and depth >= 0:
        return depth
    return 0


def _page_number(element: dict[str, Any]) -> int | None:
    """Return the page number when present."""
    page_number = (element.get("metadata") or {}).get("page_number")
    return page_number if isinstance(page_number, int) else None


def _first_page_number(elements: list[dict[str, Any]]) -> int | None:
    """Return the first available page number across a list of elements."""
    for element in elements:
        page_number = _page_number(element)
        if page_number is not None:
            return page_number
    return None


def _normalize_whitespace(value: str) -> str:
    """Collapse repeated whitespace while preserving line breaks."""
    value = re.sub(r"[ \t]+", " ", value)
    value = re.sub(r"\n{3,}", "\n\n", value)
    return value.strip()


def _estimate_tokens(text: str) -> int:
    """Estimate token count conservatively from whitespace-separated terms.

    Matches the rule used by ``section_token.py`` so ``token_count`` values
    are comparable across chunkers.
    """
    if not text:
        return 0
    return max(1, len(re.findall(r"\S+", text)))


_SENTENCE_SPLIT_RE = re.compile(r"(?<=[.!?])\s+")


def _split_text_to_budget(text: str, cap_chars: int) -> list[str]:
    """Split text into chunks no larger than ``cap_chars`` using a separator
    hierarchy: line (``\\n``) → sentence (``. !? ``) → word → hard char cut.

    Greedy merge: keep stuffing units into the active buffer; when the next
    unit would push it past ``cap_chars``, emit the buffer and start a new one.
    Mirrors what ``RecursiveCharacterTextSplitter`` does, but inline and
    char-only (matches the chunker's existing unit).

    Args:
        text: Joined content for a text group.
        cap_chars: Maximum characters per emitted chunk.

    Returns:
        List of one or more sub-texts, each with ``len(s) <= cap_chars`` (the
        last fallback may emit a chunk equal to the cap when even a single
        word is over-budget).
    """
    if cap_chars <= 0 or len(text) <= cap_chars:
        return [text] if text else []

    def merge_units(units: list[str], joiner: str) -> tuple[list[str], list[str]]:
        """Greedy-merge ``units`` joined by ``joiner`` until each chunk fits.

        Returns ``(chunks, leftovers)`` where ``leftovers`` is any unit that
        was itself larger than ``cap_chars`` and needs further splitting.
        """
        chunks: list[str] = []
        leftovers: list[str] = []
        buf = ""
        for u in units:
            if len(u) > cap_chars:
                if buf:
                    chunks.append(buf)
                    buf = ""
                leftovers.append(u)
                continue
            candidate = (buf + joiner + u) if buf else u
            if len(candidate) <= cap_chars:
                buf = candidate
            else:
                chunks.append(buf)
                buf = u
        if buf:
            chunks.append(buf)
        return chunks, leftovers

    # 1. Line split
    lines = [u for u in text.split("\n") if u.strip()]
    chunks, oversized = merge_units(lines, "\n")

    # 2. Sentence fallback for any oversized line
    for line in oversized:
        sentences = [s.strip() for s in _SENTENCE_SPLIT_RE.split(line) if s.strip()]
        sub_chunks, leftover_sents = merge_units(sentences, " ")
        chunks.extend(sub_chunks)
        # 3. Word fallback for any oversized sentence
        for sent in leftover_sents:
            words = sent.split(" ")
            sub_word_chunks, leftover_words = merge_units(words, " ")
            chunks.extend(sub_word_chunks)
            # 4. Hard char cut for the rare case of a single word > cap
            for word in leftover_words:
                for i in range(0, len(word), cap_chars):
                    chunks.append(word[i : i + cap_chars])

    return [c.strip() for c in chunks if c.strip()]


def _add_ragflow_aliases(chunks: list[dict[str, Any]], doc_id: str | None) -> None:
    """Annotate chunks with RAGFlow-compatible alias fields in-place.

    Adds:
    - ``docnm_kwd``: document identifier (alias of ``doc_id``)
    - ``tag_kwd``: list with the chunk type, usable for retrieval-side boost
    - ``doc_type_kwd``: ``"table"`` for table chunks, ``"text"`` otherwise
    - ``position_int``: list with the page number (RAGFlow uses
      [page, x0, y0, top, bottom] — we only have page for now)

    Backward-compatible: our own code keeps reading canonical names; these
    are extras that downstream retrieval/reranker features can key on.
    """
    doc_name = doc_id or "document"
    for chunk in chunks:
        chunk_type = chunk.get("chunk_type", "text")
        chunk["docnm_kwd"] = doc_name
        chunk["tag_kwd"] = [chunk_type]
        chunk["doc_type_kwd"] = "table" if chunk_type == "table" else "text"
        page_number = chunk.get("page_number")
        chunk["position_int"] = [int(page_number)] if isinstance(page_number, int) else []
