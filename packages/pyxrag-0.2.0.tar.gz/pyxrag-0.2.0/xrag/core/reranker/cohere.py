"""Cohere rerank provider (rerank-v3 family)."""

from __future__ import annotations

import logging
from typing import Any

from xrag.core.reranker.base import BaseReranker

logger = logging.getLogger(__name__)


class CohereReranker(BaseReranker):
    """Rerank chunks via the Cohere rerank API.

    Uses the Cohere v3 rerank models (``rerank-v3.5`` by default; also
    accepts ``rerank-english-v3.0`` / ``rerank-multilingual-v3.0``). Scores
    are native Cohere relevance scores in [0, 1] and are used as-is.

    Args:
        api_key: Cohere API key (must be supplied; do not rely on env
            auto-detection by the client).
        model: Rerank model name (default ``rerank-v3.5``).
        strict: When True, raise on API failure. When False (default), log
            the failure and fall back to the input chunk order truncated to
            ``top_k`` — this keeps the query/eval path alive when Cohere is
            unreachable at the cost of temporary MRR degradation.
    """

    def __init__(
        self,
        api_key: str,
        model: str = "rerank-v3.5",
        strict: bool = False,
    ) -> None:
        from cohere import Client

        self._client = Client(api_key=api_key)
        self._model = model
        self._strict = strict

    def rerank(
        self,
        query: str,
        chunks: list[dict[str, Any]],
        options: dict[str, Any],
    ) -> list[dict[str, Any]]:
        """See :meth:`BaseReranker.rerank`.

        Sends chunk content to Cohere in one request (no client-side batching
        — Cohere accepts the full candidate window we pass, typically ≤ 64).
        Preserves any chunk metadata present on input.
        """
        if not chunks:
            return []
        top_k = options.get("top_k", len(chunks))
        docs = [c.get("content_with_weight", c.get("content", "")) for c in chunks]

        try:
            res = self._client.rerank(
                model=self._model,
                query=query,
                documents=docs,
                top_n=len(docs),
                return_documents=False,
            )
        except Exception:
            if self._strict:
                raise
            logger.warning(
                "cohere rerank failed; falling back to retrieval order (model=%s, n=%d)",
                self._model,
                len(docs),
                exc_info=True,
            )
            return chunks[:top_k]

        reranked: list[dict[str, Any]] = []
        for r in res.results:
            chunk = dict(chunks[r.index])
            chunk["rerank_score"] = float(r.relevance_score)
            chunk["score"] = chunk["rerank_score"]
            reranked.append(chunk)
        reranked.sort(key=lambda c: c["rerank_score"], reverse=True)
        return reranked[:top_k]
