"""Cohere rerank via AWS Bedrock's purpose-built rerank API."""

from __future__ import annotations

import logging
from typing import Any

from xrag.core.reranker.base import BaseReranker

logger = logging.getLogger(__name__)


def resolve_model_arn(model: str, region: str) -> str:
    """Build a full Bedrock model ARN from a bare model ID, or pass one through.

    Args:
        model: Either a bare Bedrock model ID (e.g.
            ``cohere.rerank-v3-5:0``) or a full ARN
            (``arn:aws:bedrock:<region>::foundation-model/<model-id>``).
        region: AWS region used when expanding a bare model ID.

    Returns:
        A full ``arn:aws:bedrock:...`` string suitable for
        ``modelConfiguration.modelArn`` on the rerank request.

    Raises:
        ValueError: If ``model`` is bare and ``region`` is empty.
    """
    if model.startswith("arn:aws:"):
        return model
    if not region:
        raise ValueError(
            "aws_bedrock_cohere requires a region when using a bare model ID "
            f"(got model={model!r}); set options.region or AWS_REGION"
        )
    return f"arn:aws:bedrock:{region}::foundation-model/{model}"


class BedrockCohereReranker(BaseReranker):
    """Rerank chunks via AWS Bedrock's Cohere rerank models.

    Uses the ``bedrock-agent-runtime.rerank`` API. Response scores are
    provider-native (``relevanceScore`` in [0, 1]) and are used as-is.

    Args:
        model: Bedrock model ID (default ``cohere.rerank-v3-5:0``) or full
            ARN. Bare IDs are expanded using ``region``.
        region: AWS region for the Bedrock client and for ARN construction.
        aws_access_key_id: Explicit access key. When None, boto3 uses its
            default credential chain (IAM role, shared config, etc.).
        aws_secret_access_key: Explicit secret key. Must be paired with
            ``aws_access_key_id``.
        aws_session_token: Optional STS session token for temporary creds.
        strict: When True, raise on API failure. When False (default), log
            and fall back to input chunk order truncated to ``top_k``.
    """

    def __init__(
        self,
        model: str = "cohere.rerank-v3-5:0",
        region: str | None = None,
        aws_access_key_id: str | None = None,
        aws_secret_access_key: str | None = None,
        aws_session_token: str | None = None,
        strict: bool = False,
    ) -> None:
        import boto3

        self._model_arn = resolve_model_arn(model, region or "")
        client_kwargs: dict[str, Any] = {"service_name": "bedrock-agent-runtime"}
        if region:
            client_kwargs["region_name"] = region
        if aws_access_key_id and aws_secret_access_key:
            client_kwargs["aws_access_key_id"] = aws_access_key_id
            client_kwargs["aws_secret_access_key"] = aws_secret_access_key
            if aws_session_token:
                client_kwargs["aws_session_token"] = aws_session_token
        self._client = boto3.client(**client_kwargs)
        self._strict = strict

    def rerank(
        self,
        query: str,
        chunks: list[dict[str, Any]],
        options: dict[str, Any],
    ) -> list[dict[str, Any]]:
        """See :meth:`BaseReranker.rerank`."""
        if not chunks:
            return []
        top_k = options.get("top_k", len(chunks))
        docs = [c.get("content_with_weight", c.get("content", "")) for c in chunks]

        try:
            res = self._client.rerank(
                queries=[{"type": "TEXT", "textQuery": {"text": query}}],
                sources=[
                    {
                        "type": "INLINE",
                        "inlineDocumentSource": {
                            "type": "TEXT",
                            "textDocument": {"text": doc},
                        },
                    }
                    for doc in docs
                ],
                rerankingConfiguration={
                    "type": "BEDROCK_RERANKING_MODEL",
                    "bedrockRerankingConfiguration": {
                        "modelConfiguration": {"modelArn": self._model_arn},
                        "numberOfResults": len(docs),
                    },
                },
            )
        except Exception:
            if self._strict:
                raise
            logger.warning(
                "bedrock rerank failed; falling back to retrieval order (arn=%s, n=%d)",
                self._model_arn,
                len(docs),
                exc_info=True,
            )
            return chunks[:top_k]

        reranked: list[dict[str, Any]] = []
        for r in res.get("results", []):
            chunk = dict(chunks[r["index"]])
            chunk["rerank_score"] = float(r["relevanceScore"])
            chunk["score"] = chunk["rerank_score"]
            reranked.append(chunk)
        reranked.sort(key=lambda c: c["rerank_score"], reverse=True)
        return reranked[:top_k]
