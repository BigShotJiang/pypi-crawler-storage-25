from __future__ import annotations

from xrag.config.models import ProviderConfig
from xrag.config.settings import get_settings
from xrag.core.reranker.base import BaseReranker

_COHERE_HINT = (
    "Cohere reranker support requires the [rerank-cohere] extra. "
    "Install with `pip install 'xrag[rerank-cohere]'`."
)


def build_reranker(config: ProviderConfig) -> BaseReranker:
    """Build the configured reranker implementation.

    Args:
        config: Reranker provider config (typically nested under
            ``retrieval.reranker`` in YAML).

    Returns:
        Concrete reranker instance.

    Raises:
        ValueError: If the provider name is not recognized, or if the
            provider requires a credential that is missing from settings.
    """
    settings = get_settings()
    if config.provider == "cohere":
        if not settings.cohere_api_key:
            raise ValueError("cohere reranker requires COHERE_API_KEY in settings/.env")
        try:
            from xrag.core.reranker.cohere import CohereReranker
        except ImportError as e:  # pragma: no cover — extras-gating
            raise ImportError(_COHERE_HINT) from e
        return CohereReranker(
            api_key=settings.cohere_api_key,
            model=config.options.get("model", "rerank-v3.5"),
            strict=config.options.get("strict", False),
        )
    if config.provider == "aws_bedrock_cohere":
        try:
            from xrag.core.reranker.bedrock_cohere import BedrockCohereReranker
        except ImportError as e:  # pragma: no cover — extras-gating
            raise ImportError(_COHERE_HINT) from e
        return BedrockCohereReranker(
            model=config.options.get("model", "cohere.rerank-v3-5:0"),
            region=config.options.get("region") or settings.aws_region,
            aws_access_key_id=settings.aws_access_key_id,
            aws_secret_access_key=settings.aws_secret_access_key,
            aws_session_token=settings.aws_session_token,
            strict=config.options.get("strict", False),
        )
    raise ValueError(f"unsupported reranker provider: {config.provider}")
