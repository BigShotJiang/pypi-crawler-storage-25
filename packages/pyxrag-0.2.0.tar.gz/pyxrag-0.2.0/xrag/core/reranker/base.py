"""Base contract for reranker providers."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class BaseReranker(ABC):
    """Reorder retrieved chunks by relevance to the query."""

    @abstractmethod
    def rerank(
        self,
        query: str,
        chunks: list[dict[str, Any]],
        options: dict[str, Any],
    ) -> list[dict[str, Any]]:
        """Rerank candidate chunks for one query.

        Args:
            query: The user query string.
            chunks: Candidate chunks from an upstream retriever.
            options: Provider-specific options.

        Returns:
            Candidate chunks reordered by rerank score.
        """
        raise NotImplementedError
