from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from time import perf_counter


@dataclass(slots=True)
class Telemetry:
    """Simple timing telemetry for one pipeline execution."""

    started_at: str
    finished_at: str | None = None
    elapsed_ms: int | None = None

    @classmethod
    def start(cls) -> tuple[Telemetry, float]:
        """Create a telemetry object and start timer state.

        Returns:
            Tuple of telemetry object and performance counter start value.
        """
        return cls(started_at=datetime.now(UTC).isoformat()), perf_counter()

    def finish(self, started_counter: float) -> None:
        """Finish timing and populate end metadata.

        Args:
            started_counter: Performance counter captured at start.
        """
        self.finished_at = datetime.now(UTC).isoformat()
        self.elapsed_ms = int((perf_counter() - started_counter) * 1000)

    def to_dict(self) -> dict:
        """Convert telemetry to a dictionary.

        Returns:
            Dictionary form of the telemetry object.
        """
        return asdict(self)
