from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4


def new_run_id(prefix: str = "run") -> str:
    """Generate a unique run identifier.

    Args:
        prefix: Prefix attached to the generated id.

    Returns:
        A timestamped run identifier.
    """
    timestamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    return f"{prefix}_{timestamp}_{uuid4().hex[:8]}"


def new_chunk_id(doc_id: str, index: int) -> str:
    """Generate a chunk identifier.

    Args:
        doc_id: Source document identifier.
        index: Chunk index within the document.

    Returns:
        Chunk identifier string.
    """
    return f"{doc_id}_chunk_{index:04d}"
