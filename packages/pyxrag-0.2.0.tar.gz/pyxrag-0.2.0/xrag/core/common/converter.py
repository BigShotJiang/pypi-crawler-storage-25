from __future__ import annotations

from bs4 import BeautifulSoup


def table_html_to_markdown(table_html: str | None, fallback_text: str = "") -> str:
    """Convert table HTML into a compact Markdown table string.

    Args:
        table_html: Serialized HTML table.
        fallback_text: Fallback plain-text representation when HTML is missing.

    Returns:
        Markdown table text or the fallback text when conversion is not possible.
    """
    if not table_html:
        return fallback_text.strip()

    soup = BeautifulSoup(table_html, "html.parser")
    rows = []
    for row in soup.find_all("tr"):
        cells = [cell.get_text(" ", strip=True) for cell in row.find_all(["th", "td"])]
        if any(cells):
            rows.append(cells)

    if not rows:
        return fallback_text.strip()

    width = max(len(row) for row in rows)
    normalized_rows = [row + [""] * (width - len(row)) for row in rows]

    header = normalized_rows[0]
    body = normalized_rows[1:]
    separator = ["---"] * width

    markdown_lines = [
        "| " + " | ".join(header) + " |",
        "| " + " | ".join(separator) + " |",
    ]
    for row in body:
        markdown_lines.append("| " + " | ".join(row) + " |")

    return "\n".join(markdown_lines).strip()
