"""Shared helpers used across core subsystems and pipelines."""
