from __future__ import annotations

import logging
import sys
from pathlib import Path

_FORMAT = "%(asctime)s %(levelname)s %(name)s: %(message)s"
_DATEFMT = "%Y-%m-%dT%H:%M:%S"
_STREAM_HANDLER_ATTR = "_rag_cli_stream_handler"
_FILE_HANDLER_ATTR = "_rag_cli_file_handler"


def setup_logging(log_file: Path | None = None, level: int = logging.INFO) -> None:
    """Configure root logging with a stderr handler and an optional file handler.

    Idempotent for handlers we own — calling again replaces them. Handlers
    installed by other libraries are left intact.

    Args:
        log_file: If set, append-mode log file written alongside stderr output.
        level: Root logger level (default INFO).
    """
    root = logging.getLogger()
    root.setLevel(level)
    formatter = logging.Formatter(_FORMAT, datefmt=_DATEFMT)

    prev_stream = getattr(root, _STREAM_HANDLER_ATTR, None)
    if prev_stream is not None:
        root.removeHandler(prev_stream)
    stream = logging.StreamHandler(sys.stderr)
    stream.setFormatter(formatter)
    root.addHandler(stream)
    setattr(root, _STREAM_HANDLER_ATTR, stream)

    prev_file = getattr(root, _FILE_HANDLER_ATTR, None)
    if prev_file is not None:
        root.removeHandler(prev_file)
        prev_file.close()
        setattr(root, _FILE_HANDLER_ATTR, None)

    if log_file is not None:
        log_file.parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(log_file, encoding="utf-8")
        file_handler.setFormatter(formatter)
        root.addHandler(file_handler)
        setattr(root, _FILE_HANDLER_ATTR, file_handler)


def get_logger(name: str) -> logging.Logger:
    """Create or retrieve a configured logger.

    Falls back to a basic stderr config when ``setup_logging`` has not run
    (e.g. ad-hoc scripts, tests), so callers always see output.

    Args:
        name: Logger name.

    Returns:
        Configured logger instance.
    """
    if not logging.getLogger().handlers:
        logging.basicConfig(level=logging.INFO, format=_FORMAT, datefmt=_DATEFMT)
    return logging.getLogger(name)
