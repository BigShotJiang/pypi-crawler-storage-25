"""Base contract for answer generation providers."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class BaseGenerator(ABC):
    """Generate an answer from a query and retrieved context."""

    @abstractmethod
    def generate(
        self, query: str, context_chunks: list[dict[str, Any]], options: dict[str, Any]
    ) -> dict[str, Any]:
        """Generate an answer from a query and retrieved chunks.

        Args:
            query: The user question.
            context_chunks: Retrieved chunk dicts providing context.
            options: Provider-specific generation options.

        Returns:
            Dict with at least ``answer`` and ``model`` fields.
        """
        raise NotImplementedError
