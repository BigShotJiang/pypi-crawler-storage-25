from __future__ import annotations

from typing import Any

from xrag.config.models import ProviderConfig
from xrag.core.generation.base import BaseGenerator
from xrag.core.generation.openai import OpenAIGenerator


def build_generator(config: ProviderConfig, callbacks: list[Any] | None = None) -> BaseGenerator:
    """Build the configured answer generator implementation.

    Args:
        config: Generation provider config.
        callbacks: Optional LangChain callback handlers for tracing.

    Returns:
        Concrete generator implementation.
    """
    if config.provider == "openai":
        return OpenAIGenerator(
            model=config.options.get("model", "gpt-4.1-mini"),
            temperature=config.options.get("temperature", 0.1),
            callbacks=callbacks,
        )
    raise ValueError(f"unsupported generation provider: {config.provider}")
