"""Answer generation provider implementations."""
