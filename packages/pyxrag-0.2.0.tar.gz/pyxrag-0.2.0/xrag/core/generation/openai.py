from __future__ import annotations

from operator import itemgetter
from typing import Any

from langchain_core.documents import Document
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda
from langchain_openai import ChatOpenAI

from xrag.config.settings import get_settings
from xrag.core.generation.base import BaseGenerator

_SYSTEM_PROMPT = (
    "You are a precise financial analyst assistant. Answer the question "
    "based ONLY on the provided context.\n"
    "\n"
    "Numeric extraction rules — when the answer is a number from a table:\n"
    "  1. Return the EXACT value as it appears in the source, including "
    "every digit and the original formatting "
    '(e.g. "$12,945,449", not "$13M" or "~$13 million"). Do NOT '
    "round, approximate, or compress to a magnitude word.\n"
    "  2. If multiple cells could match, pick the ONE whose row label "
    "AND column header EXACTLY match the question's metric name and "
    'period (year, quarter, "as of" date). Read the column header '
    "carefully — adjacent columns are usually different periods.\n"
    '  3. If the table header indicates units like "in $000s" or '
    '"in thousands", scale the cell value before answering '
    "(e.g. cell shows 1,205 in a $000s table → answer $1,205,000).\n"
    "  4. Preserve the source's currency symbol and sign convention "
    "(parentheses for negatives if used in the source).\n"
    "\n"
    "Refusal policy — be willing to answer:\n"
    "  - Use the provided context to answer whenever the answer can be "
    "derived from it after careful reading of all retrieved chunks. "
    "Read every chunk before deciding.\n"
    "  - Refuse ONLY if the answer is genuinely absent from every "
    'chunk. "It\'s not in chunk #1" is not a valid reason if chunk '
    "#3 contains it. When in doubt, attempt to extract.\n"
    "\n"
    "When a calculation is required, show the component values from "
    "the context first (e.g., 'Revenue 2024 = $45,042,408, Revenue "
    "2023 = $23,761,586'), then state the computed result. Never "
    "invent values not present in the context. Be concise."
)

_USER_TEMPLATE = """Context:
{context}

Question: {question}"""


def _format_docs(docs: list[Document]) -> str:
    """Join Document page contents into a single context string."""
    return "\n\n---\n\n".join(doc.page_content for doc in docs)


def _chunks_to_documents(chunks: list[dict[str, Any]]) -> list[Document]:
    """Convert chunk dicts into LangChain Documents for structured tracing.

    Table chunks are rendered for the LLM in this priority:

    1. ``table_html`` — raw HTML from the parser. Preserves multi-row
       headers, rowspans, and cell alignment perfectly. Default today
       because the current ``table_html_to_markdown`` converter emits
       structurally-correct-but-noisy markdown (10+ pad columns per row,
       split currency cells, repeated header rows on multi-row date
       headers). HTML costs ~2-3× the tokens of clean markdown but is
       cleaner-on-the-wire than what we synthesize.
    2. ``table_text_markdown`` — the converter's output. Used when the
       parser didn't emit HTML.
    3. ``table_text`` — flattened cell concatenation. Last-resort.
    4. ``content`` — chunker-built blob. Final fallback.

    See `docs/chunker.md` and the TODO at the end of this docstring for
    the planned converter improvement that will let us flip the default
    back to markdown.

    TODO: improve ``src/core/common/converter.py:table_html_to_markdown``
    to drop empty pad columns, merge currency cells (``$ | 4,431,280``
    → ``$4,431,280``), and collapse duplicate multi-row date headers.
    Then flip the priority above so markdown wins by default and HTML
    is the fallback.
    """
    documents: list[Document] = []
    for chunk in chunks:
        metadata: dict[str, Any] = {}
        for key in ("chunk_id", "doc_id", "chunk_type", "heading_path", "page_number", "score"):
            if key in chunk and chunk[key] is not None:
                metadata[key] = chunk[key]

        if chunk.get("chunk_type") == "table":
            table_body = (
                chunk.get("table_html")
                or chunk.get("table_text_markdown")
                or chunk.get("table_text")
                or chunk.get("content", "")
            )
            heading = " > ".join(chunk.get("heading_path") or [])
            page_content = f"Section: {heading}\n\n{table_body}" if heading else table_body
            pre = chunk.get("pre_text") or ""
            post = chunk.get("post_text") or ""
            if pre:
                page_content = f"{page_content}\n\nContext before table:\n{pre}"
            if post:
                page_content = f"{page_content}\n\nContext after table:\n{post}"
        else:
            page_content = chunk.get("content", "")

        documents.append(Document(page_content=page_content, metadata=metadata))
    return documents


class OpenAIGenerator(BaseGenerator):
    """OpenAI chat completion generator using langchain-openai."""

    def __init__(
        self,
        model: str = "gpt-4.1-mini",
        temperature: float = 0.1,
        callbacks: list[Any] | None = None,
    ) -> None:
        self._model = model
        self._temperature = temperature
        self._callbacks = callbacks or []
        settings = get_settings()
        self._client = ChatOpenAI(
            model=model, temperature=temperature, api_key=settings.openai_api_key
        )
        prompt = ChatPromptTemplate.from_messages(
            [("system", _SYSTEM_PROMPT), ("human", _USER_TEMPLATE)]
        )
        self._chain = (
            {
                "context": itemgetter("context")
                | RunnableLambda(_format_docs).with_config(run_name="format_context"),
                "question": itemgetter("question"),
            }
            | prompt
            | self._client
            | StrOutputParser()
        ).with_config(run_name="rag_generation")

    def generate(
        self, query: str, context_chunks: list[dict[str, Any]], options: dict[str, Any]
    ) -> dict[str, Any]:
        """Generate an answer via an LCEL chain.

        Builds Document objects from retrieved chunks so tracing backends
        (LangSmith, LangFuse) capture structured context alongside the LLM
        call rather than a pre-concatenated prompt string.

        Args:
            query: The user question.
            context_chunks: Retrieved chunk dicts with ``content`` fields.
            options: Provider-specific options (unused).

        Returns:
            Dict with ``answer``, ``model``, and ``context_chunk_ids`` keys.
        """
        documents = _chunks_to_documents(context_chunks)
        invoke_config: dict[str, Any] = {"run_name": "rag_generation"}
        if self._callbacks:
            invoke_config["callbacks"] = self._callbacks

        chain_input = {"context": documents, "question": query}
        answer = self._chain.invoke(chain_input, config=invoke_config)

        chunk_ids = [chunk.get("chunk_id", "") for chunk in context_chunks if chunk.get("chunk_id")]

        return {
            "answer": answer,
            "model": self._model,
            "context_chunk_ids": chunk_ids,
        }
