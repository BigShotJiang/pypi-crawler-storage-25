from __future__ import annotations

import time
from typing import Any

from xrag.config.models import EnrichmentConfig
from xrag.core.enrichment.factory import build_enricher


def run_enrichment_pipeline(
    chunks: list[dict[str, Any]],
    config: EnrichmentConfig,
    progress_callback: Any | None = None,
) -> list[dict[str, Any]]:
    """Run an ordered enrichment pipeline over a chunk list."""
    enriched = [dict(chunk) for chunk in chunks]
    context: dict[str, Any] = {"progress_callback": progress_callback}

    total_steps = len(config.pipeline)
    for index, step_name in enumerate(config.pipeline, start=1):
        enricher = build_enricher(step_name)
        step_options = config.options.get(step_name, {})
        if progress_callback is not None:
            progress_callback(
                {
                    "event": "step_start",
                    "step_name": step_name,
                    "step_index": index,
                    "step_total": total_steps,
                    "chunk_count": len(enriched),
                }
            )
        start_time = time.perf_counter()
        try:
            enriched = enricher.enrich(enriched, step_options, context)
        except Exception as exc:
            if progress_callback is not None:
                progress_callback(
                    {
                        "event": "step_error",
                        "step_name": step_name,
                        "step_index": index,
                        "step_total": total_steps,
                        "chunk_count": len(enriched),
                        "elapsed_seconds": round(time.perf_counter() - start_time, 3),
                        "error": str(exc),
                    }
                )
            raise
        if progress_callback is not None:
            progress_callback(
                {
                    "event": "step_end",
                    "step_name": step_name,
                    "step_index": index,
                    "step_total": total_steps,
                    "chunk_count": len(enriched),
                    "elapsed_seconds": round(time.perf_counter() - start_time, 3),
                }
            )

    return enriched
