from __future__ import annotations

import time
from typing import Any

from xrag.core.enrichment.base import BaseEnricher
from xrag.core.enrichment.common import (
    emit_progress,
    get_chunk_text,
    load_cache,
    preserve_existing_list,
    tokenize_text,
)
from xrag.core.enrichment.llm import OpenAIEnrichmentClient


class AutoKeywordsEnricher(BaseEnricher):
    """RAGFlow-style LLM keyword extraction for each chunk."""

    def enrich(
        self,
        chunks: list[dict[str, Any]],
        options: dict[str, Any],
        context: dict[str, Any],
    ) -> list[dict[str, Any]]:
        """Populate ``important_kwd`` and ``important_tks`` fields."""
        topn = int(options.get("topn", 3))
        if topn <= 0:
            return chunks

        model = str(options.get("model", "gpt-4.1-nano"))
        temperature = float(options.get("temperature", 0.2))
        progress_every = max(1, int(options.get("progress_every", 10)))
        client = OpenAIEnrichmentClient(model=model, temperature=temperature)
        cache = load_cache(context, "auto_keywords")
        started_at = time.perf_counter()
        cache_hits = 0
        api_calls = 0

        work_items = [
            (chunk, content) for chunk in chunks if (content := get_chunk_text(chunk).strip())
        ]
        total_chunks = len(work_items)
        if total_chunks == 0:
            return chunks
        emit_progress(
            context,
            {
                "event": "step_progress",
                "step_name": "auto_keywords",
                "processed_chunks": 0,
                "total_chunks": total_chunks,
                "cache_hits": cache_hits,
                "api_calls": api_calls,
                "elapsed_seconds": round(time.perf_counter() - started_at, 3),
            },
        )

        for processed_chunks, (chunk, content) in enumerate(work_items, start=1):
            cache_key = (model, temperature, topn, content)
            result = cache.get(cache_key)
            if result is None:
                result = client.keyword_extraction(content, topn)
                cache[cache_key] = result
                api_calls += 1
            else:
                cache_hits += 1

            keywords = [item.strip() for item in result.split(",") if item.strip()]
            preserve_existing_list(chunk, "important_kwd", keywords)
            if keywords:
                chunk["important_tks"] = tokenize_text(" ".join(keywords))
            else:
                chunk.pop("important_tks", None)

            if (
                processed_chunks == 1
                or processed_chunks % progress_every == 0
                or processed_chunks == total_chunks
            ):
                emit_progress(
                    context,
                    {
                        "event": "step_progress",
                        "step_name": "auto_keywords",
                        "processed_chunks": processed_chunks,
                        "total_chunks": total_chunks,
                        "cache_hits": cache_hits,
                        "api_calls": api_calls,
                        "elapsed_seconds": round(time.perf_counter() - started_at, 3),
                    },
                )

        return chunks
