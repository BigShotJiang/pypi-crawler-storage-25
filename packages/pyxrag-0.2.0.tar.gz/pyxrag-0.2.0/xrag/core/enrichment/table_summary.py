from __future__ import annotations

import time
from typing import Any

from xrag.core.enrichment.base import BaseEnricher
from xrag.core.enrichment.common import (
    chunk_heading_path,
    chunk_is_table,
    emit_progress,
    load_cache,
    tokenize_text,
)
from xrag.core.enrichment.llm import (
    OpenAIEnrichmentClient,
    validate_table_summary_prompt,
)


class TableSummaryEnricher(BaseEnricher):
    """LLM-generated declarative summary for table chunks.

    Writes ``summary_kwd`` (single-paragraph string) and ``summary_tks``
    (BM25-ready tokenized form). The summary is intended for the
    embedding text — the raw cells stay on ``content`` /
    ``table_text_markdown`` and reach the LLM at prompt time. See
    ``_build_embed_text`` in ``src/pipelines/indexing.py`` for the
    Option-B wiring that picks summary + questions + heading for
    table-chunk embeddings.
    """

    def enrich(
        self,
        chunks: list[dict[str, Any]],
        options: dict[str, Any],
        context: dict[str, Any],
    ) -> list[dict[str, Any]]:
        """Populate ``summary_kwd`` and ``summary_tks`` on every table chunk."""
        model = str(options.get("model", "gpt-4.1-nano"))
        temperature = float(options.get("temperature", 0.0))
        target_words = str(options.get("target_words", "50-100"))
        progress_every = max(1, int(options.get("progress_every", 5)))
        # Optional YAML override of the in-code default prompt.
        # When provided, it must contain all five required placeholders.
        prompt_template = options.get("prompt_template")
        if prompt_template is not None:
            prompt_template = str(prompt_template)
            validate_table_summary_prompt(prompt_template)

        client = OpenAIEnrichmentClient(model=model, temperature=temperature)
        cache = load_cache(context, "table_summary")
        started_at = time.perf_counter()
        cache_hits = 0
        api_calls = 0

        work_items = [
            (chunk, prompt_input)
            for chunk in chunks
            if chunk_is_table(chunk) and (prompt_input := _build_prompt_input(chunk))
        ]
        total_chunks = len(work_items)
        if total_chunks == 0:
            return chunks

        emit_progress(
            context,
            {
                "event": "step_progress",
                "step_name": "table_summary",
                "processed_chunks": 0,
                "total_chunks": total_chunks,
                "cache_hits": cache_hits,
                "api_calls": api_calls,
                "elapsed_seconds": round(time.perf_counter() - started_at, 3),
            },
        )

        for processed, (chunk, prompt_input) in enumerate(work_items, start=1):
            # prompt_template is part of the cache key so swapping the
            # YAML template re-summarizes instead of returning stale
            # output cached under the old prompt.
            cache_key = (
                model,
                temperature,
                target_words,
                prompt_template or "<default>",
                prompt_input["heading"],
                prompt_input["table_body"],
                prompt_input["pre_text"],
                prompt_input["post_text"],
            )
            result = cache.get(cache_key)
            if result is None:
                result = client.table_summary(
                    heading=prompt_input["heading"],
                    pre_text=prompt_input["pre_text"],
                    table_body=prompt_input["table_body"],
                    post_text=prompt_input["post_text"],
                    target_words=target_words,
                    prompt_template=prompt_template,
                )
                cache[cache_key] = result
                api_calls += 1
            else:
                cache_hits += 1

            summary = (result or "").strip()
            if summary:
                chunk["summary_kwd"] = summary
                chunk["summary_tks"] = tokenize_text(summary)
            else:
                chunk.pop("summary_kwd", None)
                chunk.pop("summary_tks", None)

            if processed == 1 or processed % progress_every == 0 or processed == total_chunks:
                emit_progress(
                    context,
                    {
                        "event": "step_progress",
                        "step_name": "table_summary",
                        "processed_chunks": processed,
                        "total_chunks": total_chunks,
                        "cache_hits": cache_hits,
                        "api_calls": api_calls,
                        "elapsed_seconds": round(time.perf_counter() - started_at, 3),
                    },
                )

        return chunks


def _build_prompt_input(chunk: dict[str, Any]) -> dict[str, str] | None:
    """Build the structured prompt input for one table chunk.

    Priority for the table body matches the LLM-prompt-time generator
    in ``src/core/generation/openai.py``: ``table_html`` is preferred
    because the chunker's HTML→markdown converter currently emits
    structurally-noisy markdown (10+ pad columns, split currency
    cells, repeated multi-row date headers) that confuses
    summarization. Falls back to markdown, then flat text, then
    ``content``. Returns ``None`` to skip when no usable table body
    exists — guards against empty stub chunks.

    When the converter improves (see TODO #13 in the multi-doc MVP
    plan), flip this priority back to markdown-first.
    """
    table_body = (
        chunk.get("table_html")
        or chunk.get("table_text_markdown")
        or chunk.get("table_text")
        or chunk.get("content")
        or ""
    ).strip()
    if not table_body:
        return None
    heading = " > ".join(chunk_heading_path(chunk))
    pre_text = str(chunk.get("pre_text") or "").strip()
    post_text = str(chunk.get("post_text") or "").strip()
    return {
        "heading": heading,
        "table_body": table_body,
        "pre_text": pre_text,
        "post_text": post_text,
    }
