from __future__ import annotations

import re

from langchain_openai import ChatOpenAI

from xrag.config.settings import get_settings

_KEYWORD_PROMPT_TEMPLATE = """## Role
You are a text analyzer.

## Task
Extract the most important keywords/phrases of a given piece of text content.

## Requirements
- Summarize the text content, and give the top {topn} important keywords/phrases.
- The keywords MUST be in the same language as the given piece of text content.
- The keywords are delimited by ENGLISH COMMA.
- Output keywords ONLY.

---

## Text Content
{content}
"""

_QUESTION_PROMPT_TEMPLATE = """## Role
You are a text analyzer.

## Task
Propose {topn} questions about a given piece of text content.

## Requirements
- Understand and summarize the text content, and propose the top {topn} important questions.
- The questions SHOULD NOT have overlapping meanings.
- The questions SHOULD cover the main content of the text as much as possible.
- The questions MUST be in the same language as the given piece of text content.
- One question per line.
- Output questions ONLY.

---

## Text Content
{content}
"""


_TABLE_SUMMARY_PROMPT_TEMPLATE = """## Role
You are summarizing a table from a financial document for retrieval indexing.

## Task
Write ONE paragraph ({target_words} words) that captures:
  (1) what the table shows,
  (2) the period or fiscal year(s),
  (3) the entities or major accounts involved,
  (4) one or two headline totals with units.

## Requirements
- Use language a user would type as a search query — be specific.
- Do NOT enumerate every row.
- Do NOT use bullet points or lists.
- Output the summary paragraph ONLY (no preamble like "Summary:").

---

## Section
{heading}

## Pre-context
{pre_text}

## Table
{table_body}

## Post-context
{post_text}
"""

_TABLE_SUMMARY_REQUIRED_KEYS = frozenset(
    {"heading", "pre_text", "table_body", "post_text", "target_words"}
)


def get_default_table_summary_prompt() -> str:
    """Return the in-code default prompt template for table summaries.

    Exposed so YAML callers can copy/paste the default when they want
    a small tweak rather than authoring a template from scratch.
    """
    return _TABLE_SUMMARY_PROMPT_TEMPLATE


def validate_table_summary_prompt(template: str) -> None:
    """Validate that a custom template includes all required placeholders.

    Raises:
        ValueError: when one or more of ``{heading}``, ``{pre_text}``,
            ``{table_body}``, ``{post_text}``, ``{target_words}`` is missing.
            All five must appear or the prompt will lose information at format
            time (silently, in the case of unused fields; with a KeyError if
            a key the template references isn't supplied).
    """
    found = set(re.findall(r"\{(\w+)\}", template))
    missing = _TABLE_SUMMARY_REQUIRED_KEYS - found
    if missing:
        raise ValueError(
            "table_summary prompt_template is missing required placeholders: "
            f"{sorted(missing)}. Required set: "
            f"{sorted(_TABLE_SUMMARY_REQUIRED_KEYS)}."
        )


class OpenAIEnrichmentClient:
    """Minimal OpenAI client for RAGFlow-style chunk enrichment prompts."""

    def __init__(self, model: str, temperature: float = 0.2) -> None:
        settings = get_settings()
        self._client = ChatOpenAI(
            model=model,
            temperature=temperature,
            api_key=settings.openai_api_key,
        )

    def keyword_extraction(self, content: str, topn: int) -> str:
        """Extract keywords using the RAGFlow keyword prompt."""
        prompt = _KEYWORD_PROMPT_TEMPLATE.format(content=content, topn=topn)
        return self._invoke(prompt)

    def question_proposal(self, content: str, topn: int) -> str:
        """Generate questions using the RAGFlow question prompt."""
        prompt = _QUESTION_PROMPT_TEMPLATE.format(content=content, topn=topn)
        return self._invoke(prompt)

    def table_summary(
        self,
        *,
        heading: str,
        pre_text: str,
        table_body: str,
        post_text: str,
        target_words: str,
        prompt_template: str | None = None,
    ) -> str:
        """Generate a one-paragraph table summary anchored on section, period, and totals.

        Args:
            heading: Section heading path joined with " > ".
            pre_text: Pre-context text (neighbor paragraph above).
            table_body: Table content — prefer HTML, fallback markdown/text/content.
            post_text: Post-context text (neighbor paragraph below).
            target_words: Target word count (e.g. "50-100").
            prompt_template: Optional override of the default prompt.
                Must include ``{heading}``, ``{pre_text}``, ``{table_body}``,
                ``{post_text}``, ``{target_words}`` placeholders.

        Returns:
            The summary paragraph (model output, post-``</think>`` strip).
        """
        template = prompt_template or _TABLE_SUMMARY_PROMPT_TEMPLATE
        prompt = template.format(
            heading=heading or "(none)",
            pre_text=pre_text or "(none)",
            table_body=table_body or "(none)",
            post_text=post_text or "(none)",
            target_words=target_words,
        )
        return self._invoke(prompt)

    def _invoke(self, prompt: str) -> str:
        """Run a single text-only prompt and normalize the response."""
        response = self._client.invoke(
            [
                ("system", prompt),
                ("human", "Output: "),
            ]
        )
        content = response.content if isinstance(response.content, str) else ""
        content = re.sub(r"^.*</think>", "", content, flags=re.DOTALL).strip()
        if "**ERROR**" in content:
            return ""
        return content
