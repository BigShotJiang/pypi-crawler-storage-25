from __future__ import annotations

from typing import Any

from xrag.core.enrichment.base import BaseEnricher
from xrag.core.enrichment.common import (
    chunk_heading_path,
    chunk_is_table,
    chunk_is_text,
    chunk_page_number,
    count_tokens,
    get_chunk_text,
    set_chunk_text,
    split_sentences,
)


class TableContextEnricher(BaseEnricher):
    """Attach nearby text to table retrieval text using RAGFlow-style budgets."""

    def enrich(
        self,
        chunks: list[dict[str, Any]],
        options: dict[str, Any],
        context: dict[str, Any],
    ) -> list[dict[str, Any]]:
        """Update table chunk context and retrieval text."""
        token_budget = int(options.get("table_context_size", 0))
        if token_budget <= 0:
            return chunks

        for chunk in chunks:
            if "content_with_weight" not in chunk:
                set_chunk_text(chunk, str(chunk.get("content", "")))

        for index, chunk in enumerate(chunks):
            if not chunk_is_table(chunk):
                continue

            prev_text = _collect_neighbor_text(
                chunks=chunks,
                start=index - 1,
                step=-1,
                token_budget=token_budget,
                anchor=chunk,
            )
            next_text = _collect_neighbor_text(
                chunks=chunks,
                start=index + 1,
                step=1,
                token_budget=token_budget,
                anchor=chunk,
            )

            if prev_text:
                chunk["pre_text"] = prev_text
            if next_text:
                chunk["post_text"] = next_text

            parts: list[str] = []
            heading_path = chunk_heading_path(chunk)
            if heading_path:
                parts.append(f"Section: {' > '.join(heading_path)}")
            if prev_text:
                parts.append(f"Pre-context:\n{prev_text}")
            parts.append(f"Table:\n{str(chunk.get('table_text') or chunk.get('content') or '')}")
            if next_text:
                parts.append(f"Post-context:\n{next_text}")
            set_chunk_text(chunk, "\n\n".join(part for part in parts if part).strip())

        return chunks


def _collect_neighbor_text(
    *,
    chunks: list[dict[str, Any]],
    start: int,
    step: int,
    token_budget: int,
    anchor: dict[str, Any],
) -> str:
    """Collect sentence-bounded context from neighboring text chunks."""
    remaining = token_budget
    collected: list[str] = []
    anchor_page = chunk_page_number(anchor)
    anchor_heading = tuple(chunk_heading_path(anchor))

    index = start
    while 0 <= index < len(chunks) and remaining > 0:
        candidate = chunks[index]
        if chunk_is_table(candidate):
            index += step
            continue
        if not chunk_is_text(candidate):
            break

        candidate_page = chunk_page_number(candidate)
        if anchor_page is not None and candidate_page is not None and candidate_page != anchor_page:
            break
        candidate_heading = tuple(chunk_heading_path(candidate))
        if anchor_heading and candidate_heading and candidate_heading != anchor_heading:
            break

        text = get_chunk_text(candidate).strip()
        if text:
            text = _trim_text_by_sentences(text, remaining, from_tail=(step < 0))
            if text:
                if step < 0:
                    collected.insert(0, text)
                else:
                    collected.append(text)
                remaining -= count_tokens(text)
        index += step

    return "\n".join(part for part in collected if part).strip()


def _trim_text_by_sentences(text: str, token_budget: int, *, from_tail: bool) -> str:
    """Trim text to a token budget, preferring full sentences."""
    if token_budget <= 0 or not text:
        return ""

    sentences = split_sentences(text)
    if not sentences:
        return ""

    ordered = list(reversed(sentences)) if from_tail else sentences
    collected: list[str] = []
    remaining = token_budget
    for sentence in ordered:
        token_count = count_tokens(sentence)
        if token_count <= 0:
            continue
        if token_count > remaining and collected:
            break
        collected.append(sentence)
        remaining -= token_count
        if remaining <= 0:
            break

    if from_tail:
        collected.reverse()
    return "".join(collected).strip()
