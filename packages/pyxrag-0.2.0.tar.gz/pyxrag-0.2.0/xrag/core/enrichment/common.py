from __future__ import annotations

import re
from typing import Any

_TOKEN_RE = re.compile(r"\w+")
_SENTENCE_SPLIT_RE = re.compile(r"([.。！？!?；;：:\n])")


def tokenize_text(text: str) -> str:
    """Tokenize text into a whitespace-delimited lowercase string."""
    return " ".join(token.lower() for token in _TOKEN_RE.findall(text))


def split_sentences(text: str) -> list[str]:
    """Split text into sentence-like units following RAGFlow delimiters."""
    parts = re.split(_SENTENCE_SPLIT_RE, text)
    sentences: list[str] = []
    buffer = ""
    for part in parts:
        if not part:
            continue
        if re.fullmatch(_SENTENCE_SPLIT_RE, part):
            buffer += part
            sentences.append(buffer)
            buffer = ""
        else:
            buffer += part
    if buffer:
        sentences.append(buffer)
    return sentences


def count_tokens(text: str) -> int:
    """Approximate token count for local enrichment logic."""
    return len(_TOKEN_RE.findall(text))


def get_chunk_text(chunk: dict[str, Any]) -> str:
    """Return the current retrieval text for a chunk."""
    value = chunk.get("content_with_weight")
    if isinstance(value, str) and value.strip():
        return value
    content = chunk.get("content")
    if isinstance(content, str):
        return content
    return ""


def set_chunk_text(chunk: dict[str, Any], text: str) -> None:
    """Update the RAGFlow-compatible retrieval text field for a chunk."""
    chunk["content_with_weight"] = text


def chunk_is_table(chunk: dict[str, Any]) -> bool:
    """Return whether the chunk is a table chunk."""
    return chunk.get("chunk_type") == "table"


def chunk_is_text(chunk: dict[str, Any]) -> bool:
    """Return whether the chunk should be treated as neighboring text."""
    return chunk.get("chunk_type") in {"text", "section"}


def chunk_page_number(chunk: dict[str, Any]) -> int | None:
    """Extract a comparable page number when present."""
    page = chunk.get("page_number")
    if isinstance(page, int):
        return page
    return None


def chunk_heading_path(chunk: dict[str, Any]) -> list[str]:
    """Return the chunk heading path as strings."""
    value = chunk.get("heading_path")
    if isinstance(value, list):
        return [str(item) for item in value]
    return []


def preserve_existing_list(
    chunk: dict[str, Any],
    key: str,
    values: list[str],
) -> None:
    """Set a list field only when values are present."""
    if values:
        chunk[key] = values
    elif key in chunk:
        chunk.pop(key, None)


def load_cache(context: dict[str, Any], namespace: str) -> dict[Any, Any]:
    """Return a shared per-run cache bucket."""
    caches = context.setdefault("caches", {})
    return caches.setdefault(namespace, {})


def emit_progress(context: dict[str, Any], event: dict[str, Any]) -> None:
    """Emit a progress event through the pipeline callback when present."""
    callback = context.get("progress_callback")
    if callable(callback):
        callback(event)
