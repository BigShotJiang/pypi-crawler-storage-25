from __future__ import annotations

from xrag.core.enrichment.auto_keywords import AutoKeywordsEnricher
from xrag.core.enrichment.auto_questions import AutoQuestionsEnricher
from xrag.core.enrichment.base import BaseEnricher
from xrag.core.enrichment.table_context import TableContextEnricher
from xrag.core.enrichment.table_summary import TableSummaryEnricher


def build_enricher(name: str) -> BaseEnricher:
    """Build one enrichment step by name."""
    if name == "table_context":
        return TableContextEnricher()
    if name == "table_summary":
        return TableSummaryEnricher()
    if name == "auto_keywords":
        return AutoKeywordsEnricher()
    if name == "auto_questions":
        return AutoQuestionsEnricher()
    raise ValueError(f"unsupported enrichment step: {name}")
