"""Base contract for enrichment steps."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class BaseEnricher(ABC):
    """Transform chunks during an enrichment pipeline step."""

    @abstractmethod
    def enrich(
        self,
        chunks: list[dict[str, Any]],
        options: dict[str, Any],
        context: dict[str, Any],
    ) -> list[dict[str, Any]]:
        """Return the chunk list after applying one enrichment step.

        Args:
            chunks: Flat chunk list.
            options: Step-specific options.
            context: Shared mutable pipeline context.

        Returns:
            Enriched chunk list.
        """
        raise NotImplementedError
