"""Internal provider-based subsystems used by xrag pipelines."""
