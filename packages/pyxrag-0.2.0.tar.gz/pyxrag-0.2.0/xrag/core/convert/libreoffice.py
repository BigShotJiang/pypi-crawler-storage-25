from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

from xrag.core.convert.base import BaseConverter


class LibreOfficeConverter(BaseConverter):
    """DOCX-to-PDF converter backed by LibreOffice."""

    def run(self, input_path: Path, output_path: Path) -> Path:
        """Convert a DOCX file to PDF with LibreOffice.

        Args:
            input_path: Source DOCX path.
            output_path: Destination PDF path.

        Returns:
            Path to the converted PDF.
        """
        office_binary = shutil.which("soffice") or shutil.which("libreoffice")
        if office_binary is None:
            raise RuntimeError(
                "LibreOffice is required for docx -> pdf conversion. "
                "Install `soffice` or `libreoffice` and retry."
            )

        output_path.parent.mkdir(parents=True, exist_ok=True)
        subprocess.run(
            [
                office_binary,
                "--headless",
                "--convert-to",
                "pdf",
                "--outdir",
                str(output_path.parent),
                str(input_path),
            ],
            check=True,
            capture_output=True,
            text=True,
        )

        generated_path = output_path.parent / f"{input_path.stem}.pdf"
        if not generated_path.exists():
            raise RuntimeError(f"conversion did not produce expected output: {generated_path}")

        if generated_path != output_path:
            generated_path.replace(output_path)

        return output_path
