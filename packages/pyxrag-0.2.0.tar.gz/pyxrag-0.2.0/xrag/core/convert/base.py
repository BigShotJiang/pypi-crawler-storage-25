"""Base contract for document converters."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path


class BaseConverter(ABC):
    """Convert one document format into another."""

    @abstractmethod
    def run(self, input_path: Path, output_path: Path) -> Path:
        """Convert one file into a target output file.

        Args:
            input_path: Source document path.
            output_path: Destination file path.

        Returns:
            Path to the converted output file.
        """
        raise NotImplementedError
