from __future__ import annotations

from xrag.core.convert.base import BaseConverter
from xrag.core.convert.libreoffice import LibreOfficeConverter


def build_converter(source_format: str, target_format: str) -> BaseConverter:
    """Build a converter for a source and target format pair.

    Args:
        source_format: Source file format such as `docx`.
        target_format: Target file format such as `pdf`.

    Returns:
        Concrete converter implementation.
    """
    if source_format == "docx" and target_format == "pdf":
        return LibreOfficeConverter()
    raise ValueError(f"unsupported conversion: {source_format} -> {target_format}")
