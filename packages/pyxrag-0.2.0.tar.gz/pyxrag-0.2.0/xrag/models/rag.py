"""Public RAG (retrieve + generate) types for the v0.2 ``Xrag`` client.

Mirrors ``docs/sub-plans/api/apis_design.md`` POST /v1/rag/ask.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from xrag.models.retrieval import ScoredChunk


class TokenUsage(BaseModel):
    """LLM call token accounting (best-effort — populated when the
    provider returns it)."""

    model_config = ConfigDict(extra="forbid")

    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


class RagRequest(BaseModel):
    """Programmatic input for ``client.rag.ask`` (also serialisable to
    the wire API body)."""

    model_config = ConfigDict(extra="forbid")

    query: str = Field(min_length=1, max_length=4096)
    collection: str = Field(pattern=r"^[a-zA-Z0-9_-]{1,64}$")
    tenant_id: str = "default"
    top_k: int = Field(default=10, ge=1, le=100)
    filter: dict[str, Any] | None = None
    rerank: bool | None = None


class RagResult(BaseModel):
    """Output of ``client.rag.ask`` — the generated answer plus the
    chunks that grounded it."""

    model_config = ConfigDict(extra="forbid")

    answer: str
    chunks: list[ScoredChunk] = Field(default_factory=list)
    model: str
    usage: TokenUsage | None = None
    took_ms: int = 0
    request_id: str | None = None

    def __str__(self) -> str:
        return self.answer
