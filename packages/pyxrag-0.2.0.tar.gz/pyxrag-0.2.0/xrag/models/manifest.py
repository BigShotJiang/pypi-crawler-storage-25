from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class Manifest(BaseModel):
    """Run manifest stored with parser artifacts."""

    model_config = ConfigDict(extra="forbid")

    run_id: str
    command: str
    config_path: str
    output_dir: str
    parser_provider: str
    parser_output_format: str
    source_count: int
    status: str
    files: dict[str, str] = Field(default_factory=dict)
