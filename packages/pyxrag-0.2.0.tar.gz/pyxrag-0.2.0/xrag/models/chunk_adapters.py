"""Single source of truth for chunk-shape conversion.

Three shapes coexist in the codebase:

* **Public ``Chunk``** (`xrag.models.document.Chunk`): the v0.2 SDK
  surface. Strict Pydantic model, ``extra="forbid"``. Fields:
  ``id``, ``text``, ``metadata``, ``chunk_type``, ``parent_id``.

* **Qdrant payload**: dict written by the indexer / read by scroll &
  query. Uses internal field names (``chunk_id``, ``content``,
  ``parent_chunk_id``, …) and carries the multi-tenant scoping
  fields (``tenant_id``, ``document_id``, ``embedding_model``).

* **Functional pipeline ``chunks.json``**: written by ``run_ingest`` /
  ``run_chunk_prepare``. Either a multi-doc dict
  (``{"<doc_id>": [chunks...]}``) or a flat list. Same per-chunk
  schema as the Qdrant payload, plus ``child_chunk_ids`` for the
  parent/leaf hierarchy.

This module owns the field-name aliasing and the reserved-keys set so
the rest of the codebase doesn't re-implement either. Any future change
to the chunk schema lives here.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from xrag.models.document import Chunk

# Keys that have a dedicated home in the public ``Chunk`` model, are
# auto-injected during ingest (tenant/doc scoping), or carry pipeline-
# internal structure (parent/child links). They MUST be stripped from
# ``Chunk.metadata`` on the read path so the same chunk can round-trip
# index → export → re-index without duplicating fields or losing the
# parent_id alias.
_RESERVED_PAYLOAD_KEYS: frozenset[str] = frozenset(
    {
        # ID + text — go to first-class Chunk fields
        "chunk_id",
        "id",
        "content",
        "text",
        # Tenant / document scoping — collection-level metadata
        "tenant_id",
        "document_id",
        "doc_id",
        # Structural — first-class on Chunk (or pipeline-internal)
        "chunk_type",
        "parent_id",
        "parent_chunk_id",
        "child_chunk_ids",
        # Provenance — top-level on the export envelope, not per-chunk
        "embedding_model",
    }
)

# Sentinel used by ``vector_store.scroll(with_vectors=True)`` to attach
# the dense vector to each scrolled payload. Stays in metadata only when
# the caller opts into ``include_embeddings=True`` on export.
_EMBEDDING_KEY = "__embedding__"


def reserved_metadata_keys() -> frozenset[str]:
    """Public accessor for the reserved-keys set used by validation.

    Excludes the structural ``parent_chunk_id`` / ``child_chunk_ids`` /
    ``parent_id`` aliases (those describe hierarchy, not metadata) and
    the v0.2-internal ``chunk_type`` field (carried as a first-class
    ``Chunk`` field). Validation reports use this to flag user-supplied
    metadata that would collide with auto-injected fields.
    """
    return frozenset({"chunk_id", "id", "content", "text", "tenant_id", "document_id", "doc_id"})


def payload_to_chunk(
    payload: dict[str, Any],
    *,
    include_embedding: bool = False,
) -> Chunk:
    """Map a Qdrant payload (or compatible internal-pipeline chunk dict)
    into a public :class:`Chunk`.

    Reserved payload keys are pulled into first-class fields; everything
    else flows through to ``metadata``. When ``include_embedding=True``
    and the payload carries an ``__embedding__`` sentinel (added by
    ``scroll(with_vectors=True)``), the vector is preserved under
    ``metadata.__embedding__``.
    """
    metadata = {
        k: v for k, v in payload.items() if k not in _RESERVED_PAYLOAD_KEYS and k != _EMBEDDING_KEY
    }
    if include_embedding and _EMBEDDING_KEY in payload:
        metadata[_EMBEDDING_KEY] = payload[_EMBEDDING_KEY]
    return Chunk(
        id=str(payload.get("chunk_id") or payload.get("id") or ""),
        text=str(payload.get("content") or payload.get("text") or ""),
        metadata=metadata,
        # Read both aliases — Qdrant/internal store uses parent_chunk_id;
        # bare-public dicts may use parent_id.
        parent_id=payload.get("parent_chunk_id") or payload.get("parent_id"),
        chunk_type=payload.get("chunk_type"),
    )


def chunk_to_payload(
    chunk: Chunk,
    *,
    tenant_id: str,
    document_id: str,
    model_tag: str | None = None,
) -> dict[str, Any]:
    """Map a public :class:`Chunk` into a Qdrant payload dict.

    Auto-injects ``tenant_id``, ``document_id``, and (when supplied)
    ``embedding_model``. ``parent_id`` is written as ``parent_chunk_id``
    so it round-trips through Qdrant the same way the internal pipeline
    writes it.
    """
    payload: dict[str, Any] = {
        "chunk_id": chunk.id,
        "content": chunk.text,
        "tenant_id": tenant_id,
        "document_id": document_id,
    }
    payload.update(chunk.metadata)
    if chunk.chunk_type is not None:
        payload["chunk_type"] = chunk.chunk_type
    if chunk.parent_id is not None:
        payload["parent_chunk_id"] = chunk.parent_id
    if model_tag is not None:
        payload["embedding_model"] = model_tag
    return payload


def chunks_from_internal_json(
    path: str | Path,
    *,
    exclude_parents: bool = True,
) -> list[Chunk]:
    """Load chunks from any xrag-flavored ``chunks.json`` file.

    Accepts every shape xrag itself produces:

    * v0.2 envelope ``{"schema_version": "1", "chunks": [...]}``
    * bare list ``[...]``
    * functional-pipeline multi-doc dict ``{"<doc_id>": [...], ...}``

    Each per-chunk dict goes through :func:`payload_to_chunk` so internal
    field names (``chunk_id``, ``content``, ``parent_chunk_id``) are
    aliased onto the public ``Chunk`` shape and extra fields land in
    ``metadata``.

    Args:
        path: File path to a chunks JSON of any supported shape.
        exclude_parents: When True (default), skip chunks with non-empty
            ``child_chunk_ids`` to mirror the indexing pipeline's
            ``exclude_parents_from_index=true`` invariant. Pass False
            to round-trip the parent/leaf hierarchy verbatim.

    Returns:
        List of public :class:`Chunk` objects ready for
        :meth:`xrag.client.resources.documents.DocumentsResource.index_chunks`.
    """
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    flat = _flatten_chunks_root(raw)
    if exclude_parents:
        flat = [c for c in flat if not c.get("child_chunk_ids")]
    return [_dict_to_chunk(c) for c in flat]


def _dict_to_chunk(d: dict[str, Any]) -> Chunk:
    """Per-dict shape dispatch: public-shape (with ``metadata`` sub-dict)
    dicts go through ``Chunk.model_validate``; flat payload dicts go
    through ``payload_to_chunk``. Lets the loader accept envelope chunks
    and internal-pipeline chunks side by side without the caller knowing
    which they have."""
    if isinstance(d.get("metadata"), dict) and "id" in d and "text" in d:
        return Chunk.model_validate(d)
    return payload_to_chunk(d)


def flatten_chunks_payload(raw: Any) -> list[dict[str, Any]]:
    """Flatten any supported chunks-root shape into a flat dict-list.

    Public for callers that want to reuse the shape detection without
    converting to ``Chunk`` (e.g. the validator, which inspects raw
    fields for error messages).
    """
    return _flatten_chunks_root(raw)


def _flatten_chunks_root(raw: Any) -> list[dict[str, Any]]:
    if isinstance(raw, list):
        return list(raw)
    if isinstance(raw, dict):
        if _is_envelope(raw):
            chunks = raw.get("chunks") or []
            if not isinstance(chunks, list):
                raise ValueError(
                    f"envelope 'chunks' field must be a list, got {type(chunks).__name__}"
                )
            return list(chunks)
        # Multi-doc dict — values are lists of chunk dicts.
        flat: list[dict[str, Any]] = []
        for v in raw.values():
            if not isinstance(v, list):
                raise ValueError(
                    f"multi-doc chunks dict expects each value to be a list, got {type(v).__name__}"
                )
            flat.extend(v)
        return flat
    raise ValueError(f"unsupported chunks-root type: {type(raw).__name__}")


def _is_envelope(d: dict[str, Any]) -> bool:
    return "schema_version" in d and "chunks" in d
