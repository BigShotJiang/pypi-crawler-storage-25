"""Public retrieval types for the v0.2 ``Xrag`` client.

Mirrors ``docs/sub-plans/api/apis_design.md`` POST /v1/retrievals.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

ScoreType = Literal["vector", "bm25", "hybrid", "rerank"]


class ScoredChunk(BaseModel):
    """One retrieval hit — chunk text + provenance + score."""

    model_config = ConfigDict(extra="forbid")

    chunk_id: str
    document_id: str
    text: str
    score: float
    score_type: ScoreType = "hybrid"
    metadata: dict[str, Any] = Field(default_factory=dict)


class RetrievalRequest(BaseModel):
    """Programmatic input for ``client.retrievals.search`` (also
    serialisable to the wire API request body)."""

    model_config = ConfigDict(extra="forbid")

    query: str = Field(min_length=1, max_length=4096)
    collection: str = Field(pattern=r"^[a-zA-Z0-9_-]{1,64}$")
    tenant_id: str = "default"
    top_k: int = Field(default=10, ge=1, le=100)
    filter: dict[str, Any] | None = None
    rerank: bool | None = None
    hybrid: bool | None = None


class RetrievalResult(BaseModel):
    """Output of ``client.retrievals.search``."""

    model_config = ConfigDict(extra="forbid")

    chunks: list[ScoredChunk] = Field(default_factory=list)
    took_ms: int = 0
    request_id: str | None = None
