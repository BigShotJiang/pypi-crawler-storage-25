from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class ParsedSourceMetadata(BaseModel):
    """Per-source metadata captured during parsing."""

    model_config = ConfigDict(extra="forbid")

    doc_id: str
    source_path: str
    provider: str
    job_id: str
    status: str


class ParseBundle(BaseModel):
    """Aggregate raw parser output before artifact persistence."""

    model_config = ConfigDict(extra="forbid")

    raw_outputs: dict[str, Any] = Field(default_factory=dict)
    source_metadata: list[ParsedSourceMetadata] = Field(default_factory=list)


class PipelineResult(BaseModel):
    """Structured result returned by the CLI pipeline."""

    model_config = ConfigDict(extra="forbid")

    run_id: str
    output_dir: str
    manifest_path: str
    raw_outputs_path: str
    telemetry_path: str


class ReviewResult(BaseModel):
    """Structured result returned by the parser review pipeline."""

    model_config = ConfigDict(extra="forbid")

    input_path: str
    output_path: str
    output_format: str


class PreprocessWarning(BaseModel):
    """Structured warning emitted by parser preprocessing."""

    model_config = ConfigDict(extra="forbid")

    code: str
    message: str
    count: int | None = None
    element_ids: list[str] = Field(default_factory=list)


class PreprocessResult(BaseModel):
    """Structured result returned by parser preprocessing."""

    model_config = ConfigDict(extra="forbid")

    input_path: str
    output_dir: str
    normalized_elements_path: str
    review_html_path: str
    warning_count: int
    warnings: list[PreprocessWarning] = Field(default_factory=list)


class ChunkPrepareResult(BaseModel):
    """Structured result returned by chunk preparation."""

    model_config = ConfigDict(extra="forbid")

    input_path: str
    output_dir: str
    chunks_path: str
    document_count: int
    chunk_count: int
    chunker_provider: str
    enrichment_steps: list[str] = Field(default_factory=list)


class EvalCreateDatasetResult(BaseModel):
    """Structured result returned by eval dataset generation."""

    model_config = ConfigDict(extra="forbid")

    input_path: str
    output_dir: str
    dataset_path: str
    example_count: int
    table_chunks_processed: int
    generator_provider: str
    total_chunks: int = 0
    elapsed_seconds: float = 0.0
    category_counts: dict[str, int] = Field(default_factory=dict)
    difficulty_counts: dict[str, int] = Field(default_factory=dict)
    validation_counts: dict[str, int] = Field(default_factory=dict)


class IndexingResult(BaseModel):
    """Structured result returned by the indexing pipeline."""

    model_config = ConfigDict(extra="forbid")

    input_path: str
    chunk_count: int
    embedding_provider: str
    vector_store_provider: str
    collection_name: str


class RagQueryResult(BaseModel):
    """Structured result returned by a single RAG query."""

    model_config = ConfigDict(extra="forbid")

    query: str
    answer: str
    model: str
    retrieved_chunks: int
    context_chunk_ids: list[str] = Field(default_factory=list)


class BaselineRagResult(BaseModel):
    """Structured result returned by one-shot baseline RAG."""

    model_config = ConfigDict(extra="forbid")

    input_path: str
    query: str
    answer: str
    model: str
    indexed_chunks: int
    retrieved_chunks: int
    context_chunk_ids: list[str] = Field(default_factory=list)


class EvalRunResult(BaseModel):
    """Structured result returned by the evaluation run pipeline."""

    model_config = ConfigDict(extra="forbid")

    dataset_name: str
    filter_doc: str | None = None
    question_count: int
    scores: dict[str, float] = Field(default_factory=dict)
    results_path: str
    per_question_path: str
    experiment_path: str | None = None
    timestamp: str | None = None
    config_snapshot: dict[str, Any] = Field(default_factory=dict)
