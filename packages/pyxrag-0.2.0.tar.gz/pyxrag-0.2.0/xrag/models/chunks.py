"""ChunksValidator — validate pre-chunked data before ``index_chunks`` ingestion.

Error codes (stable, SemVer-bound):
    chunks_invalid_root       — root is not a list, or an item is not a dict / Chunk
    chunks_schema_version     — JSON envelope has wrong schema_version
    chunk_field_missing       — required field (id, text) absent
    chunk_id_duplicate        — two chunks share the same id
    chunk_id_too_long         — id > 128 chars
    chunk_text_empty          — text is blank / whitespace-only
    chunk_text_too_long       — text > 32 KiB
    chunk_metadata_reserved_key — metadata contains a key xrag injects automatically

Warning codes (non-blocking):
    chunk_parent_id_unknown   — parent_id references an id not in this batch
                                (parent may live in a different batch — indexing still works)
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from pydantic import BaseModel

from xrag.models.chunk_adapters import reserved_metadata_keys
from xrag.models.document import Chunk

_MAX_ID_LEN = 128
_MAX_TEXT_LEN = 32 * 1024

# Single source of truth for reserved-keys lives in chunk_adapters; the
# validator only flags user-supplied metadata that would collide with
# auto-injected fields.
_RESERVED_METADATA_KEYS = reserved_metadata_keys()


class ChunkValidationError(BaseModel):
    index: int  # -1 for file-level / root-level errors
    field: str | None
    message: str
    code: str


class ValidationReport(BaseModel):
    ok: bool
    errors: list[ChunkValidationError]
    warnings: list[ChunkValidationError]
    chunk_count: int


def validate_chunks(chunks: list[Any] | Any) -> ValidationReport:
    """Validate a list of :class:`~xrag.models.document.Chunk` objects or raw dicts.

    Returns a :class:`ValidationReport`. Callers should raise
    :class:`~xrag.errors.XragChunksInvalid` when ``report.ok is False``.
    """
    if not isinstance(chunks, list):
        return ValidationReport(
            ok=False,
            errors=[
                ChunkValidationError(
                    index=-1,
                    field=None,
                    message="chunks must be a list",
                    code="chunks_invalid_root",
                )
            ],
            warnings=[],
            chunk_count=0,
        )

    errors: list[ChunkValidationError] = []
    warnings: list[ChunkValidationError] = []
    seen_ids: dict[str, int] = {}

    for i, raw in enumerate(chunks):
        chunk_id: str | None = None
        parent_id: str | None = None

        if isinstance(raw, Chunk):
            chunk_id = raw.id
            parent_id = raw.parent_id
            for key in raw.metadata:
                if key in _RESERVED_METADATA_KEYS:
                    errors.append(
                        ChunkValidationError(
                            index=i,
                            field=f"metadata.{key}",
                            message=(
                                f"metadata key {key!r} is reserved; xrag injects it automatically"
                            ),
                            code="chunk_metadata_reserved_key",
                        )
                    )

        elif isinstance(raw, dict):
            # id / chunk_id
            raw_id = raw.get("id") or raw.get("chunk_id")
            if not raw_id:
                errors.append(
                    ChunkValidationError(
                        index=i,
                        field="id",
                        message="chunk is missing required field 'id'",
                        code="chunk_field_missing",
                    )
                )
            else:
                chunk_id = str(raw_id)
                if len(chunk_id) > _MAX_ID_LEN:
                    errors.append(
                        ChunkValidationError(
                            index=i,
                            field="id",
                            message=f"id length {len(chunk_id)} exceeds max {_MAX_ID_LEN}",
                            code="chunk_id_too_long",
                        )
                    )
                    chunk_id = None  # don't register duplicate check on invalid id

            # text / content
            raw_text = raw.get("text") or raw.get("content")
            if not raw_text:
                errors.append(
                    ChunkValidationError(
                        index=i,
                        field="text",
                        message="chunk is missing required field 'text'",
                        code="chunk_field_missing",
                    )
                )
            elif isinstance(raw_text, str):
                if not raw_text.strip():
                    errors.append(
                        ChunkValidationError(
                            index=i,
                            field="text",
                            message="chunk 'text' is empty or whitespace-only",
                            code="chunk_text_empty",
                        )
                    )
                elif len(raw_text) > _MAX_TEXT_LEN:
                    errors.append(
                        ChunkValidationError(
                            index=i,
                            field="text",
                            message=f"text length {len(raw_text)} exceeds max {_MAX_TEXT_LEN}",
                            code="chunk_text_too_long",
                        )
                    )

            # metadata reserved keys
            meta = raw.get("metadata", {})
            if isinstance(meta, dict):
                for key in meta:
                    if key in _RESERVED_METADATA_KEYS:
                        errors.append(
                            ChunkValidationError(
                                index=i,
                                field=f"metadata.{key}",
                                message=(
                                    f"metadata key {key!r} is reserved;"
                                    " xrag injects it automatically"
                                ),
                                code="chunk_metadata_reserved_key",
                            )
                        )

            parent_id = raw.get("parent_id")

        else:
            errors.append(
                ChunkValidationError(
                    index=i,
                    field=None,
                    message=(f"expected dict or Chunk, got {type(raw).__name__}"),
                    code="chunks_invalid_root",
                )
            )
            continue

        # duplicate id check
        if chunk_id is not None:
            if chunk_id in seen_ids:
                errors.append(
                    ChunkValidationError(
                        index=i,
                        field="id",
                        message=(
                            f"duplicate chunk id {chunk_id!r}"
                            f" (first seen at index {seen_ids[chunk_id]})"
                        ),
                        code="chunk_id_duplicate",
                    )
                )
            else:
                seen_ids[chunk_id] = i

        # parent_id cross-reference (warning — parent may be in a different batch)
        if parent_id is not None and parent_id not in seen_ids:
            warnings.append(
                ChunkValidationError(
                    index=i,
                    field="parent_id",
                    message=(f"parent_id {parent_id!r} is not the id of any chunk in this batch"),
                    code="chunk_parent_id_unknown",
                )
            )

    return ValidationReport(
        ok=len(errors) == 0,
        errors=errors,
        warnings=warnings,
        chunk_count=len(chunks),
    )


def validate_chunks_file(path: Path) -> ValidationReport:
    """Validate a chunks JSON file in any shape xrag itself produces.

    Accepts:

    * v0.2 envelope ``{"schema_version": "1", "chunks": [...]}`` —
      ``schema_version`` is checked.
    * Bare list ``[...]`` — public chunk dicts only.
    * Functional-pipeline multi-doc dict ``{"<doc_id>": [...], ...}`` —
      shape detected via :func:`xrag.models.chunk_adapters.flatten_chunks_payload`.

    Checks the envelope's ``schema_version`` (when present) then delegates
    to :func:`validate_chunks` against the flattened dict-list.
    """
    from xrag.models.chunk_adapters import flatten_chunks_payload

    try:
        payload: Any = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return ValidationReport(
            ok=False,
            errors=[
                ChunkValidationError(
                    index=-1,
                    field=None,
                    message=f"failed to read/parse JSON: {exc}",
                    code="chunks_invalid_root",
                )
            ],
            warnings=[],
            chunk_count=0,
        )

    schema_errors: list[ChunkValidationError] = []
    # Schema_version is only meaningful for the v0.2 envelope shape — a
    # raw multi-doc dict from the functional pipeline doesn't carry one
    # and shouldn't be flagged for its absence.
    if isinstance(payload, dict) and "chunks" in payload:
        version = payload.get("schema_version")
        if version != "1":
            schema_errors.append(
                ChunkValidationError(
                    index=-1,
                    field="schema_version",
                    message=f"unsupported schema_version {version!r}; expected '1'",
                    code="chunks_schema_version",
                )
            )

    try:
        chunks_data = flatten_chunks_payload(payload)
    except ValueError as exc:
        return ValidationReport(
            ok=False,
            errors=[
                ChunkValidationError(
                    index=-1,
                    field=None,
                    message=str(exc),
                    code="chunks_invalid_root",
                )
            ],
            warnings=[],
            chunk_count=0,
        )

    report = validate_chunks(chunks_data)
    if schema_errors:
        return ValidationReport(
            ok=False,
            errors=schema_errors + report.errors,
            warnings=report.warnings,
            chunk_count=report.chunk_count,
        )
    return report


def chunks_json_schema() -> dict:
    """Return the JSON Schema for a single chunk (:class:`~xrag.models.document.Chunk`)."""
    return Chunk.model_json_schema()
