"""Public document and chunk types used by the v0.2 ``Xrag`` client.

These mirror the wire-API shapes in
``docs/sub-plans/api/apis_design.md`` and are designed to round-trip
through the chunks-JSON envelope format used by ``index_chunks`` /
``export_chunks``.
"""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class DocumentStatus(StrEnum):
    """Ingest pipeline state machine (matches the wire API)."""

    PENDING = "pending"
    PARSING = "parsing"
    CHUNKING = "chunking"
    INDEXING = "indexing"
    READY = "ready"
    FAILED = "failed"


class Document(BaseModel):
    """Status + metadata for one ingested (or being-ingested) document.

    Returned by ``client.documents.ingest`` / ``client.documents.get``.
    """

    model_config = ConfigDict(extra="forbid", use_enum_values=True)

    id: str
    tenant_id: str
    collection: str
    name: str
    external_id: str | None = None
    status: DocumentStatus = DocumentStatus.PENDING
    current_stage: str | None = None
    current_stage_progress_pct: int = 0
    chunk_count: int | None = None
    error: str | None = None
    created_at: datetime
    updated_at: datetime | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class Chunk(BaseModel):
    """Public chunk shape — what ``index_chunks`` accepts and
    ``export_chunks`` writes.

    Reserved metadata keys (auto-injected by xrag if absent):
    ``tenant_id``, ``document_id``, ``chunk_id``.
    """

    model_config = ConfigDict(extra="forbid")

    id: str = Field(min_length=1, max_length=128)
    text: str = Field(min_length=1, max_length=32 * 1024)
    metadata: dict[str, Any] = Field(default_factory=dict)
    parent_id: str | None = None
    chunk_type: str | None = None


class ChunksPage(BaseModel):
    """Paginated chunks listing — returned by ``documents.list_chunks``."""

    model_config = ConfigDict(extra="forbid")

    chunks: list[Chunk] = Field(default_factory=list)
    next_cursor: str | None = None
    total: int | None = None
