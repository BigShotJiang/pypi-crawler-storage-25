"""Data models for the unified ingestion pipeline.

These types are imported by both ``src.pipelines.ingest`` and any backend
service that wants to call ``run_ingest`` programmatically.
Keeping them in ``src.models`` (next to the other pipeline result types)
means the public surface for backend integration is one import path.
"""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field

from xrag.config.models import AppConfig
from xrag.config.settings import Settings
from xrag.models.result import (
    ChunkPrepareResult,
    IndexingResult,
    PipelineResult,
    PreprocessResult,
)


class StageStarted(BaseModel):
    """Emitted once when a pipeline stage begins."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["stage_started"] = "stage_started"
    stage: Literal["parser", "preprocess", "chunk", "index"]
    run_id: str


class StageCompleted(BaseModel):
    """Emitted once when a pipeline stage finishes successfully."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["stage_completed"] = "stage_completed"
    stage: Literal["parser", "preprocess", "chunk", "index"]
    run_id: str
    elapsed_seconds: float


class SourceStarted(BaseModel):
    """Emitted before a per-source step inside a stage (today: preprocess)."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["source_started"] = "source_started"
    stage: Literal["preprocess"]
    doc_id: str


class SourceCompleted(BaseModel):
    """Emitted after a per-source step completes."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["source_completed"] = "source_completed"
    stage: Literal["preprocess"]
    doc_id: str


class ProgressTick(BaseModel):
    """Emitted from inside long-running batched stages (embedding, storing)."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["progress_tick"] = "progress_tick"
    stage: str
    completed: int
    total: int


class SourceFailed(BaseModel):
    """Emitted when a per-source step fails and ``strict=False``."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["source_failed"] = "source_failed"
    stage: Literal["preprocess"]
    doc_id: str
    error: str


IngestEvent = Annotated[
    StageStarted | StageCompleted | SourceStarted | SourceCompleted | ProgressTick | SourceFailed,
    Field(discriminator="type"),
]
"""Discriminated union of all events ``on_event`` may receive."""


class SourceError(BaseModel):
    """Captured per-source failure when ``IngestRequest.strict`` is False."""

    model_config = ConfigDict(extra="forbid")

    doc_id: str
    stage: str
    error: str


class IngestRequest(BaseModel):
    """Inputs to ``run_ingest``.

    Built by the CLI shim or a backend handler. The backend constructs
    ``AppConfig`` directly from a request body — no YAML file required.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    config: AppConfig
    config_path: Path | None = None
    output_dir: Path | None = None
    tenant_id: str | None = None
    settings: Settings | None = None
    on_event: Callable[[IngestEvent], None] | None = None
    strict: bool = False
    reset_collection: bool = False
    """Drop the configured vector-store collection before re-indexing.

    Honoured only when the ``index`` stage is active. Use this for clean
    re-indexes (different chunker / embedding model) where appending to
    the prior collection would produce a stale-vector mix.
    """


class IngestResult(BaseModel):
    """Output of ``run_ingest``.

    Mirrors the four per-stage results plus a flat ``collection_name``
    handle that the downstream retrieve / generate phase consumes.
    Per-stage fields are ``None`` when the stage was skipped via
    ``pipeline.stages``.
    """

    model_config = ConfigDict(extra="forbid")

    run_id: str
    output_dir: str
    stages_run: list[str]
    parser: PipelineResult | None = None
    preprocess: dict[str, PreprocessResult] = Field(default_factory=dict)
    chunk: ChunkPrepareResult | None = None
    indexing: IndexingResult | None = None
    errors: list[SourceError] = Field(default_factory=list)
    collection_name: str | None = None
