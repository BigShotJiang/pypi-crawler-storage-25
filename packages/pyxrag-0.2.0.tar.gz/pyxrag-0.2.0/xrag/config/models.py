from __future__ import annotations

from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

IngestStage = Literal["parser", "preprocess", "chunk", "index"]
"""The four ingestion stages, in canonical execution order."""


class PipelineConfig(BaseModel):
    """Top-level pipeline execution settings."""

    model_config = ConfigDict(extra="forbid")

    name: str = "default"
    mode: Literal["parser_only", "full"] = "parser_only"
    artifact_dir: Path = Path("data/artifacts")
    tenant_id: str = "default"
    doc_ids: list[str] = Field(default_factory=list)
    stages: list[IngestStage] = Field(
        default_factory=lambda: ["parser", "preprocess", "chunk", "index"],
        description=(
            "Which ingest stages to run. Default = all four. Skipping a "
            "stage means its output must already exist in the run "
            "directory (point the orchestrator at a prior run via "
            "``output_dir``). Stages always execute in canonical order; "
            "list order is not respected."
        ),
    )


class SourceConfig(BaseModel):
    """One input source document declaration."""

    model_config = ConfigDict(extra="forbid")

    path: Path
    doc_id: str


class ProviderConfig(BaseModel):
    """Provider selection and provider-specific options.

    ``enable`` is useful for optional stages (today: the retrieval reranker)
    so a YAML can keep its full reranker block and turn the stage off with
    a single flag, without deleting the provider/options for A/B runs.
    Required stages ignore this flag.
    """

    model_config = ConfigDict(extra="forbid")

    provider: str
    options: dict[str, Any] = Field(default_factory=dict)
    enable: bool = True


class RetrievalConfig(BaseModel):
    """Retrieval provider config with an optional nested reranker stage.

    When ``reranker`` is set *and* ``reranker.enable`` is true, the
    query/eval pipeline pulls ``reranker.options.candidates`` chunks from
    the retriever, then reranks and truncates to the final top_k
    (``reranker.options.top_k`` if set, otherwise ``options.top_k``).
    Use ``effective_reranker`` to access the reranker config with the
    ``enable`` gate applied.
    """

    model_config = ConfigDict(extra="forbid")

    provider: str
    options: dict[str, Any] = Field(default_factory=dict)
    reranker: ProviderConfig | None = None

    @property
    def effective_reranker(self) -> ProviderConfig | None:
        """Return the reranker config only when it is configured and enabled."""
        if self.reranker is None or not self.reranker.enable:
            return None
        return self.reranker


class PreprocessStepsConfig(BaseModel):
    """Fine-grained parser preprocess step toggles."""

    model_config = ConfigDict(extra="forbid")

    normalize_unicode: bool = True
    drop_decorative_elements: bool = True
    reclassify_bold_headings: bool = True
    strip_image_base64: bool = True
    deduplicate_boilerplate: bool = True
    normalize_tables: bool = True
    merge_table_currency_cells: bool = True
    merge_table_orphan_suffix_cells: bool = True
    merge_table_columns: bool = False
    strip_local_data_source: bool = True
    warn_missing_page_numbers: bool = True
    warn_missing_comments_metadata: bool = True


class PreprocessConfig(BaseModel):
    """Parser preprocess configuration."""

    model_config = ConfigDict(extra="forbid")

    steps: PreprocessStepsConfig = Field(default_factory=PreprocessStepsConfig)


class EnrichmentConfig(BaseModel):
    """Ordered chunk-enrichment configuration applied before embedding."""

    model_config = ConfigDict(extra="forbid")

    pipeline: list[str] = Field(default_factory=list)
    options: dict[str, dict[str, Any]] = Field(default_factory=dict)


class IndexingConfig(BaseModel):
    """Indexing pipeline behavior — what reaches the vector store.

    Lives in the YAML alongside ``embedding`` / ``vector_store`` so a config
    file is the single source of truth for "how chunks were indexed". When
    omitted, defaults apply.
    """

    model_config = ConfigDict(extra="forbid")

    exclude_parents_from_index: bool = Field(
        default=True,
        description=(
            "Skip parent chunks (those with non-empty child_chunk_ids) when "
            "embedding and storing to the vector store. Mirrors RAGFlow's "
            "available_int=0 pattern — parents remain in chunks.json for "
            "context expansion but do not compete with child chunks in top-k."
        ),
    )
    min_section_body_chars: int = Field(
        default=30,
        description=(
            "Drop section-type leaves whose stripped body is shorter than "
            "this many characters. These are usually heading-only sections "
            "(e.g. '10. TAXATION') or parser-misclassified cover-page "
            "metadata; their text is already in the heading_path of "
            "downstream content. Set to 0 to disable."
        ),
    )
    merge_continuation_sections: bool = Field(
        default=True,
        description=(
            "Merge sections whose heading ends with '(cont.)' or "
            "'(continued)' back into the original section's parent. "
            "Restores logical sections split by page boundaries during "
            "parsing so family-aware dedup and ranking see one unit."
        ),
    )


class AppConfig(BaseModel):
    """Full runtime application configuration."""

    model_config = ConfigDict(extra="forbid")

    pipeline: PipelineConfig
    sources: list[SourceConfig]
    parser: ProviderConfig
    artifact_store: ProviderConfig = Field(
        default_factory=lambda: ProviderConfig(provider="local_fs", options={})
    )
    preprocess: PreprocessConfig = Field(default_factory=PreprocessConfig)
    chunker: ProviderConfig = Field(
        default_factory=lambda: ProviderConfig(provider="section_table", options={})
    )
    enrichment: EnrichmentConfig = Field(default_factory=EnrichmentConfig)
    indexing: IndexingConfig = Field(default_factory=IndexingConfig)
    embedding: ProviderConfig | None = None
    vector_store: ProviderConfig | None = None
    retrieval: RetrievalConfig | None = None
    generation: ProviderConfig | None = None
    evaluation: ProviderConfig | None = None
    tracing: ProviderConfig | None = None


class LlmConfig(BaseModel):
    """LLM provider settings for generation and validation."""

    model_config = ConfigDict(extra="forbid")

    provider: str = "openai"
    model: str = "gpt-4o"
    temperature: float = 0.3
    options: dict[str, Any] = Field(default_factory=dict)


class DatasetGenerationConfig(BaseModel):
    """Standalone config for eval dataset generation."""

    model_config = ConfigDict(extra="forbid")

    dataset_generation: ProviderConfig
    llm: LlmConfig = Field(default_factory=LlmConfig)
