from __future__ import annotations

from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Environment-backed application settings.

    All fields can be overridden via environment variables or a ``.env`` file.
    Variable names are case-insensitive (e.g., ``EMBED_BATCH_SIZE=200``).
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # --- API keys ---

    unstructured_api_key: str | None = Field(
        default=None,
        description="API key for the Unstructured hosted API.",
    )
    unstructured_api_url: str | None = Field(
        default=None,
        description="Base URL for the Unstructured API endpoint.",
    )
    openai_api_key: str | None = Field(
        default=None,
        description="API key for OpenAI services (embeddings, chat, evaluation).",
    )
    cohere_api_key: str | None = Field(
        default=None,
        description="API key for Cohere services (rerank-v3 family).",
    )
    qdrant_url: str | None = Field(
        default=None,
        description=(
            "URL for a remote Qdrant instance (e.g. http://localhost:6333 "
            "or https://xyz.cloud.qdrant.io:6333). Used when the vector store "
            "provider is qdrant and no url is given in config options."
        ),
    )
    qdrant_api_key: str | None = Field(
        default=None,
        description="API key for Qdrant Cloud (paired with qdrant_url).",
    )

    # --- AWS (Bedrock reranker, etc.) ---

    aws_access_key_id: str | None = Field(
        default=None,
        description=(
            "AWS access key ID. Leave unset to defer to the boto3 default credential "
            "chain (IAM role, shared config, instance metadata)."
        ),
    )
    aws_secret_access_key: str | None = Field(
        default=None,
        description="AWS secret access key. Paired with AWS_ACCESS_KEY_ID.",
    )
    aws_session_token: str | None = Field(
        default=None,
        description="Optional AWS session token for temporary credentials.",
    )
    aws_region: str | None = Field(
        default=None,
        description=(
            "AWS region (e.g. us-west-2). Used as the default for Bedrock clients "
            "when no per-provider region is configured."
        ),
    )

    # --- Tracing ---

    langsmith_api_key: str | None = Field(
        default=None,
        description="API key for LangSmith tracing (auto-enables LangChain tracing via env).",
    )
    langsmith_project: str = Field(
        default="ir_v2",
        description="LangSmith project name to group traces under.",
    )
    langsmith_endpoint: str = Field(
        default="https://api.smith.langchain.com",
        description="LangSmith API endpoint URL.",
    )
    langfuse_public_key: str | None = Field(
        default=None,
        description="Public key for LangFuse tracing.",
    )
    langfuse_secret_key: str | None = Field(
        default=None,
        description="Secret key for LangFuse tracing.",
    )
    langfuse_base_url: str = Field(
        default="https://cloud.langfuse.com",
        description="LangFuse base URL. Override for self-hosted instances or regional endpoints.",
    )

    # --- Indexing pipeline ---
    # NOTE: exclude_parents_from_index has moved to AppConfig.indexing in YAML.
    # See docs/indexing.md and src/config/models.py:IndexingConfig.

    embed_batch_size: int = Field(
        default=100,
        description=(
            "Number of texts to send per embedding API call. "
            "Lower values reduce memory usage; higher values improve throughput."
        ),
    )
    store_batch_size: int = Field(
        default=500,
        description=(
            "Number of chunks to upsert per vector store batch. "
            "Controls memory pressure during indexing."
        ),
    )

    # --- Chunker defaults ---

    section_content_max_chars: int = Field(
        default=1500,
        description=(
            "Maximum character length for section chunk content in the section-table chunker. "
            "Longer content is truncated to keep section summaries compact."
        ),
    )
    table_neighbor_count: int = Field(
        default=2,
        description=(
            "Number of neighboring text elements to collect above and below a table "
            "for pre_text/post_text context in the section-table chunker."
        ),
    )

    # --- Parser preprocess defaults ---

    heading_max_chars: int = Field(
        default=120,
        description=(
            "Maximum character length for a text element to be considered a heading "
            "during bold-heading reclassification in parser preprocessing."
        ),
    )
    boilerplate_max_chars: int = Field(
        default=80,
        description=(
            "Maximum character length for a text element to be considered "
            "recurring page boilerplate during deduplication."
        ),
    )

    # --- Parser polling ---

    poll_interval_seconds: int = Field(
        default=5,
        description=(
            "Seconds between status polls when waiting for an Unstructured API job. "
            "Applies when no poll_interval_seconds is set in parser options."
        ),
    )

    # --- Dataset generation defaults ---

    max_questions_per_chunk: int = Field(
        default=3,
        description=(
            "Default maximum number of QA items the template generator produces "
            "per table chunk. Can be overridden in dataset generation config options."
        ),
    )

    # --- Display ---

    peek_truncate_chars: int = Field(
        default=200,
        description=(
            "Maximum character length for text fields in dataset peek terminal output. "
            "Longer values are truncated with an ellipsis."
        ),
    )


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return cached settings loaded from environment and `.env`.

    Returns:
        The cached settings instance.
    """
    return Settings()
