from __future__ import annotations

from pathlib import Path

import yaml

from xrag.config.models import (
    AppConfig,
    DatasetGenerationConfig,
    EnrichmentConfig,
    PreprocessConfig,
    ProviderConfig,
)


def load_config(path: str | Path) -> AppConfig:
    """Load and validate YAML config into the repo config model.

    Args:
        path: Filesystem path to the YAML config.

    Returns:
        The validated application config.
    """
    config_path = Path(path)
    data = yaml.safe_load(config_path.read_text()) or {}
    return AppConfig.model_validate(data)


def load_preprocess_config(path: str | Path) -> PreprocessConfig:
    """Load and validate YAML config into the preprocess config model.

    Args:
        path: Filesystem path to the YAML config.

    Returns:
        The validated preprocess config.
    """
    config_path = Path(path)
    data = yaml.safe_load(config_path.read_text()) or {}
    if isinstance(data, dict) and "preprocess" in data:
        data = data["preprocess"] or {}
    return PreprocessConfig.model_validate(data)


def load_chunker_config(path: str | Path) -> ProviderConfig:
    """Load and validate YAML config into the chunker provider config model.

    Args:
        path: Filesystem path to the YAML config.

    Returns:
        The validated chunker provider config.
    """
    config_path = Path(path)
    data = yaml.safe_load(config_path.read_text()) or {}
    if isinstance(data, dict) and "chunker" in data:
        data = data["chunker"] or {}
    return ProviderConfig.model_validate(data)


def load_enrichment_config(path: str | Path) -> EnrichmentConfig:
    """Load and validate the ``enrichment:`` section of a YAML config.

    Returns an empty (no-op) ``EnrichmentConfig`` when the section is
    absent.

    Args:
        path: Filesystem path to the YAML config.

    Returns:
        The validated enrichment config.
    """
    config_path = Path(path)
    data = yaml.safe_load(config_path.read_text()) or {}
    if isinstance(data, dict) and "enrichment" in data:
        data = data["enrichment"] or {}
    else:
        data = {}
    return EnrichmentConfig.model_validate(data)


def load_rag_config(path: str | Path) -> AppConfig:
    """Load RAG pipeline config (embedding, vector_store, retrieval, generation).

    Accepts either a full AppConfig YAML or a standalone RAG-only YAML.

    Args:
        path: Filesystem path to the YAML config.

    Returns:
        The validated application config with RAG fields populated.
    """
    return load_config(path)


def load_dataset_generation_config(path: str | Path) -> DatasetGenerationConfig:
    """Load and validate YAML config into the dataset generation config model.

    Args:
        path: Filesystem path to the YAML config.

    Returns:
        The validated dataset generation config.
    """
    config_path = Path(path)
    data = yaml.safe_load(config_path.read_text()) or {}
    return DatasetGenerationConfig.model_validate(data)
