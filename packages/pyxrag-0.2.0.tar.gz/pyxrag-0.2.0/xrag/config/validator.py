from __future__ import annotations

from xrag.config.models import AppConfig
from xrag.config.settings import get_settings


def validate_config(config: AppConfig, command: str) -> None:
    """Validate config for a specific CLI command.

    Args:
        config: Parsed application config.
        command: CLI command name being executed.
    """
    if command == "parser":
        _validate_parser_config(config)
        return
    raise ValueError(f"unsupported command: {command}")


def _validate_parser_config(config: AppConfig) -> None:
    """Validate parser command requirements.

    Args:
        config: Parsed application config.
    """
    if not config.sources:
        raise ValueError("at least one source is required")
    for source in config.sources:
        if not source.path.exists():
            raise FileNotFoundError(f"source file not found: {source.path}")
    if not config.parser.provider:
        raise ValueError("parser.provider is required")
    settings = get_settings()
    if config.parser.provider == "unstructured" and not settings.unstructured_api_key:
        raise ValueError("UNSTRUCTURED_API_KEY is required when parser.provider is 'unstructured'")
