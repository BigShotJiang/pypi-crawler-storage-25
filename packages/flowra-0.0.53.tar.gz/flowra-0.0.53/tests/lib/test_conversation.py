"""Tests for Conversation view and ConversationReadyEvent lifecycle."""

import contextlib
import dataclasses

from flowra.agent import AgentRuntime, AppendOnlyList, Event, HookSubscription, InMemorySessionStorage
from flowra.agent.flow.hooks import HooksImpl
from flowra.lib import LLMConfig
from flowra.lib.chat import ChatAgent, ChatConfig, ChatResult, ChatSpec, Conversation, ConversationReadyEvent
from flowra.lib.turn import TurnReadyEvent
from flowra.llm import (
    AssistantMessage,
    LLMProvider,
    LLMRequest,
    LLMResponse,
    StopReason,
    TextBlock,
    ToolUseBlock,
    Usage,
    UserMessage,
)
from flowra.tools import ToolRegistry, tool


class TestConversation:
    def test_empty(self) -> None:
        history: AppendOnlyList[UserMessage | AssistantMessage] = AppendOnlyList()
        turn: AppendOnlyList[UserMessage | AssistantMessage] = AppendOnlyList()
        conv = Conversation(history, turn)
        assert len(conv) == 0
        assert list(conv) == []
        assert list(reversed(conv)) == []

    def test_history_only(self) -> None:
        history: AppendOnlyList[UserMessage | AssistantMessage] = AppendOnlyList()
        turn: AppendOnlyList[UserMessage | AssistantMessage] = AppendOnlyList()
        history.append(UserMessage.text("Hi"))
        history.append(AssistantMessage(blocks=[TextBlock(text="Hello")]))
        conv = Conversation(history, turn)
        assert len(conv) == 2
        assert conv[0].blocks[0].text == "Hi"  # type: ignore[union-attr]
        assert conv[1].blocks[0].text == "Hello"  # type: ignore[union-attr]

    def test_turn_only(self) -> None:
        history: AppendOnlyList[UserMessage | AssistantMessage] = AppendOnlyList()
        turn: AppendOnlyList[UserMessage | AssistantMessage] = AppendOnlyList()
        turn.append(UserMessage.text("Question"))
        conv = Conversation(history, turn)
        assert len(conv) == 1
        assert conv[0].blocks[0].text == "Question"  # type: ignore[union-attr]

    def test_combined(self) -> None:
        history: AppendOnlyList[UserMessage | AssistantMessage] = AppendOnlyList()
        turn: AppendOnlyList[UserMessage | AssistantMessage] = AppendOnlyList()
        history.append(UserMessage.text("First"))
        history.append(AssistantMessage(blocks=[TextBlock(text="Reply")]))
        turn.append(UserMessage.text("Second"))
        turn.append(AssistantMessage(blocks=[TextBlock(text="Reply2")]))
        conv = Conversation(history, turn)
        assert len(conv) == 4
        texts = [m.blocks[0].text for m in conv]  # type: ignore[union-attr]
        assert texts == ["First", "Reply", "Second", "Reply2"]

    def test_reversed(self) -> None:
        history: AppendOnlyList[UserMessage | AssistantMessage] = AppendOnlyList()
        turn: AppendOnlyList[UserMessage | AssistantMessage] = AppendOnlyList()
        history.append(UserMessage.text("A"))
        history.append(AssistantMessage(blocks=[TextBlock(text="B")]))
        turn.append(UserMessage.text("C"))
        conv = Conversation(history, turn)
        texts = [m.blocks[0].text for m in reversed(conv)]  # type: ignore[union-attr]
        assert texts == ["C", "B", "A"]

    def test_negative_index(self) -> None:
        history: AppendOnlyList[UserMessage | AssistantMessage] = AppendOnlyList()
        turn: AppendOnlyList[UserMessage | AssistantMessage] = AppendOnlyList()
        history.append(UserMessage.text("H1"))
        turn.append(UserMessage.text("T1"))
        conv = Conversation(history, turn)
        assert conv[-1].blocks[0].text == "T1"  # type: ignore[union-attr]
        assert conv[-2].blocks[0].text == "H1"  # type: ignore[union-attr]

    def test_slice(self) -> None:
        history: AppendOnlyList[UserMessage | AssistantMessage] = AppendOnlyList()
        turn: AppendOnlyList[UserMessage | AssistantMessage] = AppendOnlyList()
        history.append(UserMessage.text("A"))
        history.append(AssistantMessage(blocks=[TextBlock(text="B")]))
        turn.append(UserMessage.text("C"))
        turn.append(AssistantMessage(blocks=[TextBlock(text="D")]))
        conv = Conversation(history, turn)
        # Slice across boundary
        middle = conv[1:3]
        assert len(middle) == 2
        assert middle[0].blocks[0].text == "B"  # type: ignore[union-attr]
        assert middle[1].blocks[0].text == "C"  # type: ignore[union-attr]
        # Negative slice
        last_two = conv[-2:]
        assert len(last_two) == 2
        assert last_two[0].blocks[0].text == "C"  # type: ignore[union-attr]
        assert last_two[1].blocks[0].text == "D"  # type: ignore[union-attr]

    def test_index_out_of_range(self) -> None:
        history: AppendOnlyList[UserMessage | AssistantMessage] = AppendOnlyList()
        turn: AppendOnlyList[UserMessage | AssistantMessage] = AppendOnlyList()
        conv = Conversation(history, turn)
        import pytest

        with pytest.raises(IndexError):
            conv[0]

    def test_history_len_and_turn_len(self) -> None:
        history: AppendOnlyList[UserMessage | AssistantMessage] = AppendOnlyList()
        turn: AppendOnlyList[UserMessage | AssistantMessage] = AppendOnlyList()
        history.append(UserMessage.text("H"))
        turn.append(UserMessage.text("T1"))
        turn.append(UserMessage.text("T2"))
        conv = Conversation(history, turn)
        assert conv.history_len == 1
        assert conv.turn_len == 2

    def test_live_updates(self) -> None:
        """Conversation reflects changes to underlying lists."""
        history: AppendOnlyList[UserMessage | AssistantMessage] = AppendOnlyList()
        turn: AppendOnlyList[UserMessage | AssistantMessage] = AppendOnlyList()
        conv = Conversation(history, turn)
        assert len(conv) == 0
        turn.append(UserMessage.text("New"))
        assert len(conv) == 1
        assert conv[0].blocks[0].text == "New"  # type: ignore[union-attr]


class TestTurnReadyEvent:
    async def test_turn_ready_fires(self) -> None:
        """TurnReadyEvent fires from TurnAgent.__post_init__."""
        received: list[Event[TurnReadyEvent]] = []

        def on_turn_ready(event: Event[TurnReadyEvent]) -> None:
            received.append(event)

        class MockProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="OK")])],
                    stop_reason=StopReason.END_TURN,
                )

        hooks = HooksImpl()
        hooks.on(TurnReadyEvent, on_turn_ready)
        runtime = AgentRuntime(
            agents={"chat": ChatAgent},
            services={
                ChatConfig: ChatConfig(
                    tools=ToolRegistry([]),
                    llm_config=LLMConfig(model="test"),
                    system=[],
                ),
                HookSubscription: hooks,
                LLMProvider: MockProvider(),
            },
        )

        await runtime.run(agent=ChatAgent, spec=ChatSpec.text("Hi"))
        assert len(received) == 1
        assert len(received[0].data.turn_messages) > 0


class TestConversationReadyEvent:
    async def test_conversation_ready_fires(self) -> None:
        """ConversationReadyEvent fires with combined view."""
        conversations: list[Conversation] = []

        def on_conv_ready(event: Event[ConversationReadyEvent]) -> None:
            conversations.append(event.data.conversation)

        class MockProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="Hello!")])],
                    stop_reason=StopReason.END_TURN,
                )

        hooks = HooksImpl()
        hooks.on(ConversationReadyEvent, on_conv_ready)
        runtime = AgentRuntime(
            agents={"chat": ChatAgent},
            services={
                ChatConfig: ChatConfig(
                    tools=ToolRegistry([]),
                    llm_config=LLMConfig(model="test"),
                    system=[],
                ),
                HookSubscription: hooks,
                LLMProvider: MockProvider(),
            },
        )

        await runtime.run(agent=ChatAgent, spec=ChatSpec.text("Hi"))
        assert len(conversations) == 1
        conv = conversations[0]
        # Conversation should contain at least the user message
        assert len(conv) >= 1

    async def test_conversation_includes_history_and_turn(self) -> None:
        """On second turn, conversation shows history + current turn."""
        conversations: list[Conversation] = []

        def on_conv_ready(event: Event[ConversationReadyEvent]) -> None:
            # Snapshot the conversation length at event time
            conversations.append(event.data.conversation)

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text=f"Reply {self.call_count}")])],
                    stop_reason=StopReason.END_TURN,
                    usage=Usage(input_tokens=10, output_tokens=5),
                )

        hooks = HooksImpl()
        hooks.on(ConversationReadyEvent, on_conv_ready)
        storage = InMemorySessionStorage()
        runtime = AgentRuntime(
            agents={"chat": ChatAgent},
            storage=storage,
            services={
                ChatConfig: ChatConfig(
                    tools=ToolRegistry([]),
                    llm_config=LLMConfig(model="test"),
                    system=[],
                ),
                HookSubscription: hooks,
                LLMProvider: MockProvider(),
            },
        )

        # Turn 1
        await runtime.run(agent=ChatAgent, spec=ChatSpec.text("First"), state="chat")
        # Turn 2
        await runtime.run(agent=ChatAgent, spec=ChatSpec.text("Second"), state="chat")

        assert len(conversations) == 2
        # ConversationReadyEvent fires from __post_init__ (before steps run).
        # By turn 2, history has turn 1 messages: user("First") + assistant("Reply 1")
        # BUT collect_result already saved them, so history has 2 entries.
        # However, the event fires before the turn's start step, so turn_messages may still
        # contain messages from crash recovery. On a clean run: history = previous turns.
        conv2 = conversations[1]
        assert conv2.history_len >= 2  # at least turn 1 messages

    async def test_conversation_scan_from_end(self) -> None:
        """Demonstrate scanning conversation from the end."""

        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class GreetParams:
            name: str

        @tool("greet")
        def greet(params: GreetParams) -> str:
            """Greet."""
            return f"Hello, {params.name}!"

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                if self.call_count == 1:
                    return LLMResponse(
                        messages=[AssistantMessage(blocks=[ToolUseBlock(id="c1", name="greet", input={"name": "W"})])],
                        stop_reason=StopReason.TOOL_USE,
                    )
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="Done")])],
                    stop_reason=StopReason.END_TURN,
                )

        conversations: list[Conversation] = []

        def on_conv_ready(event: Event[ConversationReadyEvent]) -> None:
            conversations.append(event.data.conversation)

        hooks = HooksImpl()
        hooks.on(ConversationReadyEvent, on_conv_ready)
        runtime = AgentRuntime(
            agents={"chat": ChatAgent},
            services={
                ChatConfig: ChatConfig(
                    tools=ToolRegistry([greet]),
                    llm_config=LLMConfig(model="test"),
                    system=[],
                ),
                HookSubscription: hooks,
                LLMProvider: MockProvider(),
            },
        )

        await runtime.run(agent=ChatAgent, spec=ChatSpec.text("Greet the world"))
        conv = conversations[0]
        # Scan from end — last message should be from the turn
        last = next(reversed(conv))
        assert isinstance(last, (UserMessage, AssistantMessage))


class TestPostInit:
    async def test___post_init___called_on_creation(self) -> None:
        """__post_init__ fires when agent is first created."""
        calls: list[str] = []

        class MockProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="OK")])],
                    stop_reason=StopReason.END_TURN,
                )

        def track_turn_ready(event: Event[TurnReadyEvent]) -> None:
            calls.append("turn_ready")

        hooks = HooksImpl()
        hooks.on(TurnReadyEvent, track_turn_ready)
        runtime = AgentRuntime(
            agents={"chat": ChatAgent},
            services={
                ChatConfig: ChatConfig(
                    tools=ToolRegistry([]),
                    llm_config=LLMConfig(model="test"),
                    system=[],
                ),
                HookSubscription: hooks,
                LLMProvider: MockProvider(),
            },
        )

        await runtime.run(agent=ChatAgent, spec=ChatSpec.text("Hi"))
        assert "turn_ready" in calls

    async def test___post_init___called_on_crash_recovery(self) -> None:
        """__post_init__ fires when agent is restored from storage."""
        calls: list[str] = []
        call_count = 0

        class CrashProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                nonlocal call_count
                call_count += 1
                if call_count == 1:
                    raise RuntimeError("Simulated crash")
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="OK")])],
                    stop_reason=StopReason.END_TURN,
                )

        def track_turn_ready(event: Event[TurnReadyEvent]) -> None:
            calls.append("turn_ready")

        storage = InMemorySessionStorage()
        hooks = HooksImpl()
        hooks.on(TurnReadyEvent, track_turn_ready)

        provider = CrashProvider()
        config = ChatConfig(
            tools=ToolRegistry([]),
            llm_config=LLMConfig(model="test"),
            system=[],
        )

        runtime = AgentRuntime(
            agents={"chat": ChatAgent},
            storage=storage,
            services={
                ChatConfig: config,
                HookSubscription: hooks,
                LLMProvider: provider,
            },
        )

        # First run — crashes
        with contextlib.suppress(RuntimeError):
            await runtime.run(agent=ChatAgent, spec=ChatSpec.text("Hi"), state="chat")

        calls.clear()

        # Resume — __post_init__ should fire again
        runtime2 = AgentRuntime(
            agents={"chat": ChatAgent},
            storage=storage,
            services={
                ChatConfig: config,
                HookSubscription: hooks,
                LLMProvider: provider,
            },
        )

        result = await runtime2.resume()
        assert isinstance(result, ChatResult)
        assert "turn_ready" in calls
