from flowra.agent import AgentInfo, Event, ExecutionContext, ExecutionFrame
from flowra.agent.flow.hooks import HooksImpl
from flowra.lib.ext.openai import OpenAIToolSearch
from flowra.lib.turn import PrepareLLMRequestEvent
from flowra.llm import LLMRequest, Tool

_DUMMY_CONTEXT = ExecutionContext(
    frame=ExecutionFrame(agent=AgentInfo(name="test", path="test", source_type=None, parent=None)),
    stack=(ExecutionFrame(agent=AgentInfo(name="test", path="test", source_type=None, parent=None)),),
)


def _tool(name: str) -> Tool:
    return Tool(name=name, description="", input_schema=None)


def _request(tools: list[Tool] | None = None) -> LLMRequest:
    return LLMRequest(model="test", system=[], messages=[], tools=tools)


def _apply(ext: OpenAIToolSearch, request: LLMRequest) -> LLMRequest:
    event = Event(data=PrepareLLMRequestEvent(request=request), context=_DUMMY_CONTEXT)
    ext.on_prepare(event)
    return event.data.request


class TestOpenAIToolSearch:
    def test_defers_all_tools_by_default(self) -> None:
        ext = OpenAIToolSearch()
        req = _request(tools=[_tool("a"), _tool("b")])
        result = _apply(ext, req)

        assert result.tools is not None
        # Search tool added at the beginning
        assert result.tools[0].name == "__tool_search__"
        assert result.tools[0].extra["openai"]["type"] == "tool_search"
        # Original tools have defer_loading
        assert result.tools[1].extra.get("openai", {}).get("defer_loading") is True
        assert result.tools[2].extra.get("openai", {}).get("defer_loading") is True

    def test_predicate_filters_tools(self) -> None:
        ext = OpenAIToolSearch(predicate=lambda t: t.name.startswith("admin_"))
        req = _request(tools=[_tool("search"), _tool("admin_delete"), _tool("admin_ban")])
        result = _apply(ext, req)

        assert result.tools is not None
        # Search tool added
        assert result.tools[0].name == "__tool_search__"
        # Non-matching tool NOT deferred
        assert "defer_loading" not in result.tools[1].extra.get("openai", {})
        assert result.tools[1].name == "search"
        # Matching tools deferred
        assert result.tools[2].extra.get("openai", {}).get("defer_loading") is True
        assert result.tools[3].extra.get("openai", {}).get("defer_loading") is True

    def test_no_tools_noop(self) -> None:
        ext = OpenAIToolSearch()
        req = _request(tools=None)
        result = _apply(ext, req)
        assert result.tools is None

    def test_empty_tools_noop(self) -> None:
        ext = OpenAIToolSearch()
        req = _request(tools=[])
        result = _apply(ext, req)
        assert result.tools == []

    def test_predicate_matches_nothing_noop(self) -> None:
        ext = OpenAIToolSearch(predicate=lambda _: False)
        req = _request(tools=[_tool("a"), _tool("b")])
        result = _apply(ext, req)

        # No tools deferred — no search tool added
        assert result.tools is not None
        assert len(result.tools) == 2
        assert result.tools[0].name == "a"

    def test_preserves_existing_extra(self) -> None:
        ext = OpenAIToolSearch()
        tool = Tool(name="a", description="desc", extra={"custom": "value"})
        req = _request(tools=[tool])
        result = _apply(ext, req)

        assert result.tools is not None
        deferred = result.tools[1]
        assert deferred.extra["custom"] == "value"
        assert deferred.extra["openai"]["defer_loading"] is True

    def test_install_registers_hooks(self) -> None:
        hooks = HooksImpl()
        ext = OpenAIToolSearch()
        ext.install(hooks)
        assert hooks.has_handlers(PrepareLLMRequestEvent)
