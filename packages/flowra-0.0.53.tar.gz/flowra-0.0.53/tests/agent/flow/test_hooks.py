import dataclasses

from flowra.agent import Agent, AgentInfo, Event, ExecutionContext, ExecutionFrame, SpanExitHandler
from flowra.agent.flow.hooks import HooksImpl


@dataclasses.dataclass(slots=True, kw_only=True)
class SampleEvent:
    value: int
    extra: str = ""


@dataclasses.dataclass(slots=True, kw_only=True)
class OtherEvent:
    name: str


def _test_context(path: str = "test") -> ExecutionContext:
    info = AgentInfo(name=path.rsplit("/", 1)[-1], path=path, source_type=None, parent=None)
    frame = ExecutionFrame(agent=info)
    return ExecutionContext(frame=frame, stack=(frame,))


def _hooks(root: HooksImpl | None = None, path: str = "test") -> HooksImpl:
    r = root or HooksImpl()
    return r.for_agent(_test_context(path))


class TestHookSubscription:
    def test_on_registers_handler(self) -> None:
        root = HooksImpl()
        hooks = _hooks(root)
        assert not hooks.has_handlers(SampleEvent)
        root.on(SampleEvent, lambda e: None)
        # Dynamic: newly registered global handler is visible
        assert hooks.has_handlers(SampleEvent)
        assert not hooks.has_handlers(OtherEvent)


class TestHooks:
    async def test_emit_no_handlers(self) -> None:
        hooks = _hooks()
        result = await hooks.emit(SampleEvent(value=42))
        assert result.value == 42

    async def test_sync_handler_called(self) -> None:
        received: list[Event[SampleEvent]] = []

        def handler(event: Event[SampleEvent]) -> None:
            received.append(event)

        root = HooksImpl()
        root.on(SampleEvent, handler)
        hooks = _hooks(root)
        await hooks.emit(SampleEvent(value=7))

        assert len(received) == 1
        assert received[0].data.value == 7

    async def test_async_handler_called(self) -> None:
        received: list[int] = []

        async def handler(event: Event[SampleEvent]) -> None:
            received.append(event.data.value)

        root = HooksImpl()
        root.on(SampleEvent, handler)
        hooks = _hooks(root)
        await hooks.emit(SampleEvent(value=99))

        assert received == [99]

    async def test_multiple_handlers_called_in_order(self) -> None:
        order: list[str] = []

        root = HooksImpl()
        root.on(SampleEvent, lambda e: order.append("first"))
        root.on(SampleEvent, lambda e: order.append("second"))
        root.on(SampleEvent, lambda e: order.append("third"))
        hooks = _hooks(root)
        await hooks.emit(SampleEvent(value=0))

        assert order == ["first", "second", "third"]

    async def test_has_handlers(self) -> None:
        root = HooksImpl()
        hooks = _hooks(root)
        assert not hooks.has_handlers(SampleEvent)

        root.on(SampleEvent, lambda e: None)
        assert hooks.has_handlers(SampleEvent)
        assert not hooks.has_handlers(OtherEvent)

    async def test_handler_mutation_visible(self) -> None:
        def mutate(event: Event[SampleEvent]) -> None:
            event.data.extra = "mutated"

        root = HooksImpl()
        root.on(SampleEvent, mutate)
        hooks = _hooks(root)
        result = await hooks.emit(SampleEvent(value=1))

        assert result.extra == "mutated"

    async def test_context_stamped(self) -> None:
        agent_info = AgentInfo(name="test", path="root/test", source_type=Agent, parent=None)
        frame = ExecutionFrame(agent=agent_info, spec=None)
        context = ExecutionContext(frame=frame, stack=(frame,))
        received_contexts: list[ExecutionContext] = []

        def handler(event: Event[SampleEvent]) -> None:
            received_contexts.append(event.context)

        root = HooksImpl()
        root.on(SampleEvent, handler)
        hooks = root.for_agent(context)
        await hooks.emit(SampleEvent(value=1))

        assert len(received_contexts) == 1
        assert received_contexts[0] is context
        assert received_contexts[0].frame.agent.source_type is Agent
        assert received_contexts[0].frame.agent.path == "root/test"


class TestScopedSubscription:
    """Tests for Hooks.on() — scoped subscription to sub-agent events."""

    async def test_scoped_handler_fires_for_descendants(self) -> None:
        received: list[int] = []
        root = HooksImpl()

        parent = _hooks(root, path="app/parent")
        parent.on(SampleEvent, lambda e: received.append(e.data.value))

        child = _hooks(root, path="app/parent/child")
        await child.emit(SampleEvent(value=42))

        assert received == [42]

    async def test_scoped_handler_not_fired_for_self(self) -> None:
        received: list[int] = []
        root = HooksImpl()

        parent = _hooks(root, path="app/parent")
        parent.on(SampleEvent, lambda e: received.append(e.data.value))

        # Scoped handler excludes self (inclusive=False)
        await parent.emit(SampleEvent(value=99))
        assert received == []

    async def test_scoped_handler_not_fired_for_self_even_with_new_hooks(self) -> None:
        """Even if new Hooks is created for the same path after on(), self is excluded."""
        received: list[int] = []
        root = HooksImpl()

        parent = _hooks(root, path="app/parent")
        parent.on(SampleEvent, lambda e: received.append(e.data.value))

        # New hooks for the same path — should still NOT include scoped handler
        parent_new = _hooks(root, path="app/parent")
        await parent_new.emit(SampleEvent(value=99))
        assert received == []

    async def test_scoped_handler_not_fired_for_siblings(self) -> None:
        received: list[int] = []
        root = HooksImpl()

        parent = _hooks(root, path="app/parent")
        parent.on(SampleEvent, lambda e: received.append(e.data.value))

        sibling = _hooks(root, path="app/sibling")
        await sibling.emit(SampleEvent(value=99))
        assert received == []

    async def test_scope_string_filters_to_child(self) -> None:
        received: list[int] = []
        root = HooksImpl()

        parent = _hooks(root, path="app/parent")
        parent.on(SampleEvent, lambda e: received.append(e.data.value), scope="child_a")

        child_a = _hooks(root, path="app/parent/child_a")
        child_b = _hooks(root, path="app/parent/child_b")

        await child_a.emit(SampleEvent(value=1))
        await child_b.emit(SampleEvent(value=2))

        assert received == [1]

    async def test_scope_string_includes_grandchildren(self) -> None:
        received: list[int] = []
        root = HooksImpl()

        parent = _hooks(root, path="app/parent")
        parent.on(SampleEvent, lambda e: received.append(e.data.value), scope="child")

        grandchild = _hooks(root, path="app/parent/child/grandchild")
        await grandchild.emit(SampleEvent(value=7))

        assert received == [7]

    async def test_scope_agent_type(self) -> None:
        received: list[int] = []
        root = HooksImpl()

        parent = _hooks(root, path="app/parent")
        parent.on(SampleEvent, lambda e: received.append(e.data.value), scope=Agent)

        child_info = AgentInfo(name="child", path="app/parent/child", source_type=Agent, parent=None)
        child_frame = ExecutionFrame(agent=child_info)
        child_ctx = ExecutionContext(frame=child_frame, stack=(child_frame,))
        child = root.for_agent(child_ctx)
        await child.emit(SampleEvent(value=5))
        assert received == [5]

    async def test_scope_agent_type_no_match(self) -> None:
        """Type scope doesn't fire if no matching agent type in stack."""
        received: list[int] = []
        root = HooksImpl()

        parent = _hooks(root, path="app/parent")
        parent.on(SampleEvent, lambda e: received.append(e.data.value), scope=Agent)

        # Child without source_type=Agent
        child = _hooks(root, path="app/parent/child")
        await child.emit(SampleEvent(value=5))
        assert received == []

    async def test_global_type_scope(self) -> None:
        """scope=AgentType on root (runtime.hooks) fires for any matching agent."""
        received: list[int] = []
        root = HooksImpl()

        root.on(SampleEvent, lambda e: received.append(e.data.value), scope=Agent)

        child_info = AgentInfo(name="child", path="app/child", source_type=Agent, parent=None)
        child_frame = ExecutionFrame(agent=child_info)
        child_ctx = ExecutionContext(frame=child_frame, stack=(child_frame,))
        child = root.for_agent(child_ctx)
        await child.emit(SampleEvent(value=42))
        assert received == [42]

    async def test_global_type_scope_no_match(self) -> None:
        """scope=AgentType on root does not fire if agent type doesn't match."""
        received: list[int] = []
        root = HooksImpl()

        root.on(SampleEvent, lambda e: received.append(e.data.value), scope=Agent)

        child = _hooks(root, path="app/child")  # source_type=None
        await child.emit(SampleEvent(value=99))
        assert received == []

    async def test_global_and_scoped_coexist(self) -> None:
        global_received: list[int] = []
        scoped_received: list[int] = []
        root = HooksImpl()

        root.on(SampleEvent, lambda e: global_received.append(e.data.value))

        parent = _hooks(root, path="app/parent")
        parent.on(SampleEvent, lambda e: scoped_received.append(e.data.value))

        child = _hooks(root, path="app/parent/child")
        await child.emit(SampleEvent(value=10))

        assert global_received == [10]
        assert scoped_received == [10]

    async def test_has_handlers_includes_scoped(self) -> None:
        root = HooksImpl()
        child = _hooks(root, path="app/parent/child")
        assert not child.has_handlers(SampleEvent)

        parent = _hooks(root, path="app/parent")
        parent.on(SampleEvent, lambda e: None)

        # Dynamic: child now sees the scoped handler
        assert child.has_handlers(SampleEvent)
        # Sibling does not
        sibling_child = _hooks(root, path="app/sibling/child")
        assert not sibling_child.has_handlers(SampleEvent)

    async def test_clear_scoped(self) -> None:
        root = HooksImpl()
        parent = _hooks(root, path="app/parent")
        parent.on(SampleEvent, lambda e: None)
        parent.on_span(SampleEvent, lambda e: None)
        parent.on(SampleEvent, lambda e: None, scope=Agent)
        parent.on_span(SampleEvent, lambda e: None, scope=Agent)

        child = _hooks(root, path="app/parent/child")
        assert child.has_handlers(SampleEvent)
        assert child.has_span_handlers(SampleEvent)
        root.clear_scoped()
        assert not child.has_handlers(SampleEvent)
        assert not child.has_span_handlers(SampleEvent)

    async def test_scoped_on_span_path(self) -> None:
        """on_span with path scope fires for descendants."""
        entered: list[int] = []
        exited: list[int] = []

        @dataclasses.dataclass
        class Span:
            value: int
            result: str | None = None

        def handler(event: Event[Span]) -> SpanExitHandler:
            entered.append(event.data.value)

            def on_end(error: BaseException | None = None) -> None:
                exited.append(event.data.value)

            return on_end

        root = HooksImpl()
        parent = _hooks(root, path="app/parent")
        parent.on_span(Span, handler, scope="child")

        child = _hooks(root, path="app/parent/child")
        span = await child.open_span(Span(value=1))
        span.result = "ok"
        await child.close_span(span)

        assert entered == [1]
        assert exited == [1]

        # Sibling should not fire
        sibling = _hooks(root, path="app/parent/other")
        await sibling.open_span(Span(value=2))
        assert entered == [1]

    async def test_scoped_on_span_type(self) -> None:
        """on_span with type scope fires only when matching agent type in stack."""
        entered: list[int] = []

        @dataclasses.dataclass
        class Span:
            value: int

        root = HooksImpl()
        parent = _hooks(root, path="app/parent")
        parent.on_span(Span, lambda e: entered.append(e.data.value), scope=Agent)

        # Child WITH matching source_type
        child_info = AgentInfo(name="child", path="app/parent/child", source_type=Agent, parent=None)
        child_frame = ExecutionFrame(agent=child_info)
        child_ctx = ExecutionContext(frame=child_frame, stack=(child_frame,))
        child = root.for_agent(child_ctx)
        await child.open_span(Span(value=10))
        assert entered == [10]

        # Child WITHOUT matching source_type — should not fire
        other = _hooks(root, path="app/parent/other")
        await other.open_span(Span(value=20))
        assert entered == [10]
