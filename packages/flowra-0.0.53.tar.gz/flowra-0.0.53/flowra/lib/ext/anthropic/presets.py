"""Composite presets for common Anthropic caching configurations.

Individual caching components (single instances, ready to use):
- ``ANTHROPIC_CACHE_ALL_MESSAGES`` — cache the last block of the last message
- ``ANTHROPIC_CACHE_ALL_SYSTEM_MESSAGES`` — cache the last block of the last system message
- ``ANTHROPIC_CACHE_ALL_TOOLS`` — cache the last tool definition
- ``ANTHROPIC_CACHE_HISTORY_MESSAGES`` — cache the history boundary (requires ChatAgent)
- ``ANTHROPIC_CACHE_NON_TRANSIENT_MESSAGES`` — cache last non-transient block (stops at first transient)
- ``ANTHROPIC_CACHE_NON_TRANSIENT_SYSTEM_MESSAGES`` — cache last non-transient system block (stops at first transient)
- ``ANTHROPIC_CACHE_NON_TRANSIENT_TOOLS`` — cache last non-transient tool (stops at first transient)

Composite presets (multiple caching slots):
- ``ANTHROPIC_CACHE_ALL`` — cache system + tools + messages (all slots)
- ``ANTHROPIC_CACHE_SESSION`` — cache system + tools + history boundary (for chat sessions)
- ``ANTHROPIC_CACHE_NON_TRANSIENT`` — cache non-transient system + tools + messages
"""

from typing import Protocol

from ....agent import AgentRuntime, HookSubscription
from .cache import (
    AnthropicCacheAllMessages,
    AnthropicCacheAllSystemMessages,
    AnthropicCacheAllTools,
    AnthropicCacheHistoryMessages,
    AnthropicCacheNonTransientMessages,
    AnthropicCacheNonTransientSystemMessages,
    AnthropicCacheNonTransientTools,
)

__all__ = [
    "ANTHROPIC_CACHE_ALL",
    "ANTHROPIC_CACHE_ALL_MESSAGES",
    "ANTHROPIC_CACHE_ALL_SYSTEM_MESSAGES",
    "ANTHROPIC_CACHE_ALL_TOOLS",
    "ANTHROPIC_CACHE_HISTORY_MESSAGES",
    "ANTHROPIC_CACHE_NON_TRANSIENT",
    "ANTHROPIC_CACHE_NON_TRANSIENT_MESSAGES",
    "ANTHROPIC_CACHE_NON_TRANSIENT_SYSTEM_MESSAGES",
    "ANTHROPIC_CACHE_NON_TRANSIENT_TOOLS",
    "ANTHROPIC_CACHE_SESSION",
]


type HookTarget = AgentRuntime | HookSubscription


class _Installable(Protocol):
    def install(self, target: HookTarget) -> None: ...


class _CompositeExtension:
    __slots__ = ("__extensions",)

    def __init__(self, *extensions: _Installable) -> None:
        self.__extensions = extensions

    def install(self, target: HookTarget) -> None:
        for ext in self.__extensions:
            ext.install(target)


ANTHROPIC_CACHE_ALL_MESSAGES = AnthropicCacheAllMessages()
ANTHROPIC_CACHE_ALL_SYSTEM_MESSAGES = AnthropicCacheAllSystemMessages()
ANTHROPIC_CACHE_ALL_TOOLS = AnthropicCacheAllTools()
ANTHROPIC_CACHE_HISTORY_MESSAGES = AnthropicCacheHistoryMessages()
ANTHROPIC_CACHE_NON_TRANSIENT_MESSAGES = AnthropicCacheNonTransientMessages()
ANTHROPIC_CACHE_NON_TRANSIENT_SYSTEM_MESSAGES = AnthropicCacheNonTransientSystemMessages()
ANTHROPIC_CACHE_NON_TRANSIENT_TOOLS = AnthropicCacheNonTransientTools()

ANTHROPIC_CACHE_ALL = _CompositeExtension(
    ANTHROPIC_CACHE_ALL_SYSTEM_MESSAGES,
    ANTHROPIC_CACHE_ALL_TOOLS,
    ANTHROPIC_CACHE_ALL_MESSAGES,
)

ANTHROPIC_CACHE_SESSION = _CompositeExtension(
    ANTHROPIC_CACHE_ALL_SYSTEM_MESSAGES,
    ANTHROPIC_CACHE_ALL_TOOLS,
    ANTHROPIC_CACHE_HISTORY_MESSAGES,
)

ANTHROPIC_CACHE_NON_TRANSIENT = _CompositeExtension(
    ANTHROPIC_CACHE_NON_TRANSIENT_SYSTEM_MESSAGES,
    ANTHROPIC_CACHE_NON_TRANSIENT_TOOLS,
    ANTHROPIC_CACHE_NON_TRANSIENT_MESSAGES,
)
