import dataclasses
from typing import Any

__all__ = ["LLMConfig"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class LLMConfig:
    model: str
    temperature: float | None = None
    top_p: float | None = None
    max_tokens: int | None = None
    stop_sequences: list[str] | None = None
    extra: dict[str, Any] = dataclasses.field(default_factory=dict)
