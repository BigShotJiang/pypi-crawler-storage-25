"""OpenTelemetry tracing integration for flowra via span-hooks.

Creates OTel spans with GenAI semantic conventions. Users configure their own
``TracerProvider`` and exporter — flowra just creates spans.

Detects external OTel context on entry: if a span was created with
``tracer.start_as_current_span()`` before calling flowra, flowra's root span
becomes a child of the external span. Parent tracking within flowra uses
``FlowingVar`` (no ``on_enter``/``on_exit`` callbacks — OTel span context
is not synced across flowing context switches, unlike MLflow integration).

Usage::

    from opentelemetry import trace
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import SimpleSpanProcessor, ConsoleSpanExporter

    # Configure OTel (user's responsibility)
    provider = TracerProvider()
    provider.add_span_processor(SimpleSpanProcessor(ConsoleSpanExporter()))
    trace.set_tracer_provider(provider)

    # Install flowra tracing
    from flowra.agent import AgentRuntime
    from flowra.ext.otel import OTEL_TRACING

    runtime = AgentRuntime(agents={...}, services={...})
    OTEL_TRACING.install(runtime)
"""

import json
from collections.abc import Callable
from typing import Any

from opentelemetry import trace
from opentelemetry.trace import Span, SpanKind, StatusCode

from ..agent import AgentRuntime, AgentSpan, Event, FlowingVar, SpanExitHandler, StepSpan
from ..lib.observability import LLMCallSpan, ToolCallSpan

__all__ = ["OTEL_TRACING"]


class _OtelTracing:
    __slots__ = ()

    def install(
        self,
        runtime: AgentRuntime,
        *,
        tracer_name: str = "flowra",
        trace_agents: bool = True,
        trace_steps: bool = True,
        trace_llm_calls: bool = True,
        trace_tool_calls: bool = True,
        capture_content: bool = False,
        session_id: str | Callable[[], str | None] | None = None,
    ) -> None:
        """Install OpenTelemetry tracing span-hooks on a runtime.

        Args:
            runtime: AgentRuntime to install tracing on.
            tracer_name: OTel tracer name (appears in span metadata).
            trace_agents: Trace agent lifecycle (AgentSpan).
            trace_steps: Trace step invocations (StepSpan). Enabled by default.
            trace_llm_calls: Trace LLM calls (LLMCallSpan).
            trace_tool_calls: Trace tool calls (ToolCallSpan).
            capture_content: Capture tool arguments/results as span attributes. Off by default for privacy.
            session_id: Session ID for ``gen_ai.conversation.id``.
        """
        flowing = runtime.flowing
        hooks = runtime.hooks
        tracer = trace.get_tracer(tracer_name)

        otel_parent: FlowingVar[Span | None] = flowing.create_var(default=None)

        if trace_agents:
            hooks.on_span(AgentSpan, _make_agent_handler(otel_parent, tracer, session_id))
        if trace_steps:
            hooks.on_span(StepSpan, _make_step_handler(otel_parent, tracer))
        if trace_llm_calls:
            hooks.on_span(LLMCallSpan, _make_llm_handler(otel_parent, tracer, capture_content))
        if trace_tool_calls:
            hooks.on_span(ToolCallSpan, _make_tool_handler(otel_parent, tracer, capture_content))


OTEL_TRACING = _OtelTracing()


# -- Helpers --


def _resolve_session_id(session_id: str | Callable[[], str | None] | None) -> str | None:
    if session_id is None:
        return None
    if callable(session_id):
        return session_id()
    return session_id


def _start_span(
    otel_parent: FlowingVar[Span | None],
    tracer: trace.Tracer,
    name: str,
    *,
    kind: SpanKind = SpanKind.INTERNAL,
    attributes: dict[str, Any] | None = None,
) -> Span:
    """Start a new span as child of the current parent (flowra or external OTel)."""
    parent = otel_parent.get()
    if parent is None:
        current_span = trace.get_current_span()
        if current_span.is_recording():
            parent = current_span
    ctx = trace.set_span_in_context(parent) if parent is not None else None
    return tracer.start_span(name, context=ctx, kind=kind, attributes=attributes)


# -- Span handlers --


def _make_agent_handler(
    otel_parent: FlowingVar[Span | None],
    tracer: trace.Tracer,
    session_id: str | Callable[[], str | None] | None,
) -> Callable[[Event[AgentSpan]], SpanExitHandler | None]:
    def on_enter(event: Event[AgentSpan]) -> SpanExitHandler:
        span = event.data
        attrs: dict[str, Any] = {
            "gen_ai.operation.name": "invoke_agent",
            "gen_ai.agent.name": span.agent_info.path,
        }
        sid = _resolve_session_id(session_id)
        if sid is not None:
            attrs["gen_ai.conversation.id"] = sid
        if span.is_resume:
            attrs["flowra.is_resume"] = True

        otel_span = _start_span(otel_parent, tracer, f"invoke_agent {span.agent_info.name}", attributes=attrs)
        otel_parent.set(otel_span)

        def on_exit(error: BaseException | None = None) -> None:
            if error is not None:
                otel_span.set_status(StatusCode.ERROR, description=str(error))
                otel_span.set_attribute("error.type", type(error).__qualname__)
                otel_span.record_exception(error)
            else:
                otel_span.set_status(StatusCode.OK)
            otel_span.end()

        return on_exit

    return on_enter


def _make_step_handler(
    otel_parent: FlowingVar[Span | None],
    tracer: trace.Tracer,
) -> Callable[[Event[StepSpan]], SpanExitHandler | None]:
    def on_enter(event: Event[StepSpan]) -> SpanExitHandler:
        span = event.data
        attrs: dict[str, Any] = {
            "flowra.step.name": span.step,
        }

        otel_span = _start_span(otel_parent, tracer, span.step, attributes=attrs)
        otel_parent.set(otel_span)

        def on_exit(error: BaseException | None = None) -> None:
            if error is not None:
                otel_span.set_status(StatusCode.ERROR, description=str(error))
                otel_span.set_attribute("error.type", type(error).__qualname__)
                otel_span.record_exception(error)
            else:
                otel_span.set_status(StatusCode.OK)
            otel_span.end()

        return on_exit

    return on_enter


def _make_llm_handler(
    otel_parent: FlowingVar[Span | None],
    tracer: trace.Tracer,
    capture_content: bool,
) -> Callable[[Event[LLMCallSpan]], SpanExitHandler | None]:
    def on_enter(event: Event[LLMCallSpan]) -> SpanExitHandler | None:
        span = event.data
        parent = otel_parent.get()
        if parent is None:
            return None

        model = span.request.model
        parts = model.split("/", 1)
        provider = parts[0] if len(parts) > 1 else "unknown"
        model_name = parts[1] if len(parts) > 1 else model

        attrs: dict[str, Any] = {
            "gen_ai.operation.name": "chat",
            "gen_ai.provider.name": provider,
            "gen_ai.request.model": model_name,
        }
        if span.request.temperature is not None:
            attrs["gen_ai.request.temperature"] = span.request.temperature
        if span.request.top_p is not None:
            attrs["gen_ai.request.top_p"] = span.request.top_p
        if span.request.max_tokens is not None:
            attrs["gen_ai.request.max_tokens"] = span.request.max_tokens
        for ns, ns_config in span.request.extra.items():
            if isinstance(ns_config, dict):
                for key, val in ns_config.items():
                    attrs[f"gen_ai.request.{ns}.{key}"] = val if isinstance(val, str | int | float | bool) else str(val)

        otel_span = _start_span(otel_parent, tracer, f"chat {model_name}", kind=SpanKind.CLIENT, attributes=attrs)
        otel_parent.set(otel_span)

        def on_exit(error: BaseException | None = None) -> None:
            if error is not None:
                otel_span.set_status(StatusCode.ERROR, description=str(error))
                otel_span.set_attribute("error.type", type(error).__qualname__)
                otel_span.record_exception(error)
            elif span.response is not None:
                resp = span.response
                otel_span.set_status(StatusCode.OK)
                otel_span.set_attribute("gen_ai.response.finish_reasons", [str(resp.stop_reason)])
                if resp.usage:
                    otel_span.set_attribute("gen_ai.usage.input_tokens", resp.usage.input_tokens)
                    otel_span.set_attribute("gen_ai.usage.output_tokens", resp.usage.output_tokens)
                    if resp.usage.cache_read_input_tokens:
                        otel_span.set_attribute(
                            "gen_ai.usage.cache_read.input_tokens", resp.usage.cache_read_input_tokens
                        )
                    if resp.usage.cache_creation_input_tokens:
                        otel_span.set_attribute(
                            "gen_ai.usage.cache_creation.input_tokens", resp.usage.cache_creation_input_tokens
                        )
                    if resp.usage.cost_usd is not None:
                        otel_span.set_attribute("gen_ai.usage.cost", resp.usage.cost_usd)
            otel_span.end()

        return on_exit

    return on_enter


def _make_tool_handler(
    otel_parent: FlowingVar[Span | None],
    tracer: trace.Tracer,
    capture_content: bool,
) -> Callable[[Event[ToolCallSpan]], SpanExitHandler | None]:
    def on_enter(event: Event[ToolCallSpan]) -> SpanExitHandler | None:
        span = event.data
        parent = otel_parent.get()
        if parent is None:
            return None

        attrs: dict[str, Any] = {
            "gen_ai.operation.name": "execute_tool",
            "gen_ai.tool.name": span.tool_use.name,
            "gen_ai.tool.call.id": span.tool_use.id,
        }
        if capture_content:
            attrs["gen_ai.tool.call.arguments"] = json.dumps(span.tool_use.input)

        otel_span = _start_span(otel_parent, tracer, f"execute_tool {span.tool_use.name}", attributes=attrs)
        otel_parent.set(otel_span)

        def on_exit(error: BaseException | None = None) -> None:
            if error is not None:
                otel_span.set_status(StatusCode.ERROR, description=str(error))
                otel_span.set_attribute("error.type", type(error).__qualname__)
                otel_span.record_exception(error)
            else:
                otel_span.set_status(StatusCode.OK)
                if capture_content and span.result is not None:
                    otel_span.set_attribute("gen_ai.tool.call.result", span.result.content)
                    if span.result.is_error:
                        otel_span.set_attribute("flowra.tool.is_error", True)
                    if span.error_kind is not None:
                        otel_span.set_attribute("flowra.tool.error_kind", str(span.error_kind))
            otel_span.end()

        return on_exit

    return on_enter
