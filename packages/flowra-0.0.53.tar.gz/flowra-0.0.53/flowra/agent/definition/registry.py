import dataclasses
import re

from .model import AbstractAgent, AgentDefinition, AgentDefinitionRef, AgentRef

__all__ = ["AgentRegistry", "ResolvedAgent"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ResolvedAgent:
    name: str
    definition: AgentDefinition


class AgentRegistry:
    __VALID_NAME = re.compile(r"^[a-zA-Z0-9_-]+$")

    __slots__ = ("__definitions", "__type_maps")

    def __init__(self, agents: dict[str, AgentDefinitionRef]) -> None:
        self.__definitions: dict[str, AgentDefinition] = {}
        self.__type_maps: dict[str, dict[type[AbstractAgent], str]] = {}
        for name, ref in agents.items():
            self.__register("", name, ref)

    def resolve(
        self,
        ref: AgentRef,
        *,
        context: str | None = None,
    ) -> ResolvedAgent:
        if isinstance(ref, str):
            name = self.__resolve_name(ref, context=context)
            defn = self.__definitions.get(name)
            if defn is None:
                raise KeyError(f"Unknown agent: {name!r}")
            return ResolvedAgent(name=name, definition=defn)

        return self.__resolve_type(ref, context or "")

    def get(self, name: str) -> AgentDefinition:
        defn = self.__definitions.get(name)
        if defn is None:
            raise KeyError(f"Unknown agent: {name!r}")
        return defn

    def all_definitions(self) -> list[AgentDefinition]:
        return list(self.__definitions.values())

    def all_named_definitions(self) -> list[tuple[str, AgentDefinition]]:
        return list(self.__definitions.items())

    def name_for_type(
        self,
        agent_type: type[AbstractAgent],
        *,
        context: str = "",
    ) -> str:
        return self.__resolve_type(agent_type, context).name

    def __register(
        self,
        context: str,
        local_name: str,
        ref: AgentDefinitionRef,
    ) -> None:
        self.__validate_name(local_name)
        full_name = f"{context}/{local_name}" if context else local_name

        if isinstance(ref, type):
            agent_def = ref.__agent_definition__
            type_map = self.__type_maps.setdefault(context, {})
            if ref in type_map:
                msg = f"Duplicate agent class {ref.__name__!r} at level {context!r}"
                raise ValueError(msg)
            type_map[ref] = local_name
        else:
            agent_def = ref

        self.__definitions[full_name] = agent_def

        for subname, subref in agent_def.subagents.items():
            self.__register(full_name, subname, subref)

    def __resolve_type(
        self,
        agent_type: type[AbstractAgent],
        context: str,
    ) -> ResolvedAgent:
        current = context
        while True:
            type_map = self.__type_maps.get(current, {})
            local_name = type_map.get(agent_type)
            if local_name is not None:
                full_name = f"{current}/{local_name}" if current else local_name
                return ResolvedAgent(name=full_name, definition=self.__definitions[full_name])
            if not current:
                break
            slash = current.rfind("/")
            current = current[:slash] if slash >= 0 else ""
        msg = f"Unregistered agent class: {agent_type.__name__}"
        raise KeyError(msg)

    @staticmethod
    def __resolve_name(ref: str, *, context: str | None) -> str:
        if not ref.startswith("."):
            return ref

        if context is None:
            msg = f"Relative agent reference {ref!r} requires a context"
            raise ValueError(msg)

        if ref.startswith("./"):
            suffix = ref[2:]
            return f"{context}/{suffix}"

        if ref.startswith("../"):
            parts = context.split("/")
            remaining = ref
            while remaining.startswith("../"):
                remaining = remaining[3:]
                if not parts or (len(parts) == 1 and parts[0] == ""):
                    msg = f"Relative reference {ref!r} goes above root from context {context!r}"
                    raise ValueError(msg)
                parts.pop()
            if not remaining:
                msg = f"Relative reference {ref!r} resolves to a context, not an agent name"
                raise ValueError(msg)
            parent = "/".join(parts)
            return f"{parent}/{remaining}" if parent else remaining

        msg = f"Invalid relative reference {ref!r}: use './' or '../' prefix"
        raise ValueError(msg)

    @classmethod
    def __validate_name(cls, name: str) -> None:
        if not cls.__VALID_NAME.match(name):
            msg = f"Invalid agent name {name!r}: must contain only alphanumeric characters, underscores, and hyphens"
            raise ValueError(msg)
