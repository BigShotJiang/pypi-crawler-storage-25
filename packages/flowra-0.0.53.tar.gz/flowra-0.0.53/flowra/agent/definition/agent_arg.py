"""Annotated markers for agent parameter binding.

Used in ``__init__``, ``__post_init__``, and ``@step`` methods to control
how parameters are resolved.

Usage::

    from flowra.agent import agent_arg

    class MyAgent(Agent[MySpec, MyResult]):
        def __init__(
            self,
            spec: Annotated[MySpec, agent_arg.AGENT_SPEC],
            provider: Annotated[LLMProvider, agent_arg.SERVICE],
        ) -> None: ...

        @step
        async def collect(
            self,
            r1: Annotated[Result1 | None, agent_arg.CHILD("r1")],
            results: Annotated[list[SubResult], agent_arg.CHILD],
        ) -> FinalResult: ...
"""

__all__ = [
    "AGENT_SPEC",
    "CHILD",
    "SERVICE",
    "STEP_SPEC",
]


class _Child:
    __slots__ = ("tag",)

    def __init__(self, tag: str | None = None) -> None:
        self.tag = tag

    def __call__(self, tag: str) -> "_Child":
        return _Child(tag)


AGENT_SPEC = object()
STEP_SPEC = object()
SERVICE = object()
CHILD = _Child()
