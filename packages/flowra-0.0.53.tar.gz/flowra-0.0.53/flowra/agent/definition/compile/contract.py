import types
from typing import Any, Union, get_args, get_origin

from ..model import StepMeta
from ..step import is_entry_step
from ..step_helpers import get_step_tag
from .type_helpers import resolve_hint

__all__ = ["extract_agent_contract"]


def extract_agent_contract(
    agent_cls: type,
    step_metas: dict[str, StepMeta],
) -> tuple[str, frozenset[type], frozenset[type]]:
    """Determine agent's entry step, spec types, and result types."""
    generic_spec_types, generic_result_types = _extract_generic_params(agent_cls)
    entry_step = _find_entry_step(agent_cls)

    if entry_step is None:
        msg = f"Agent {agent_cls.__name__} must have exactly one @step(entry=True)"
        raise TypeError(msg)

    entry_meta = step_metas.get(entry_step)

    if generic_spec_types is None:
        generic_spec_types = entry_meta.spec_types if entry_meta else frozenset()
    elif entry_meta is not None and entry_meta.spec_types and entry_meta.spec_types != generic_spec_types:
        msg = (
            f"Agent {agent_cls.__name__}: entry step {entry_step!r} spec types "
            f"{entry_meta.spec_types} don't match Agent generic spec types "
            f"{generic_spec_types}"
        )
        raise TypeError(msg)

    if generic_result_types is None:
        generic_result_types = frozenset().union(*(m.result_types for m in step_metas.values()))
    else:
        all_step_result_types = frozenset().union(*(m.result_types for m in step_metas.values()))
        extra = all_step_result_types - generic_result_types
        if extra:
            extra_names = ", ".join(sorted(t.__name__ for t in extra))
            msg = (
                f"Agent {agent_cls.__name__}: steps return types "
                f"{{{extra_names}}} not declared in Agent result type "
                f"{{{', '.join(sorted(t.__name__ for t in generic_result_types))}}}"
            )
            raise TypeError(msg)

    return entry_step, generic_spec_types, generic_result_types


def _extract_generic_params(
    agent_cls: type,
) -> tuple[frozenset[type] | None, frozenset[type] | None]:
    """Extract S and R from ``Agent[S, R]`` in __orig_bases__."""
    from ..agent import Agent

    for base in getattr(agent_cls, "__orig_bases__", ()):
        origin = get_origin(base)
        if origin is Agent:
            args = get_args(base)
            if len(args) == 2:
                spec_raw, result_raw = args
                spec_types = _flatten_spec_types(spec_raw, agent_cls)
                result_types = _flatten_result_types(result_raw, agent_cls)
                return frozenset(spec_types), frozenset(result_types)
    return None, None


def _flatten_spec_types(tp: Any, agent_cls: type) -> tuple[type, ...]:
    tp = resolve_hint(tp)
    if tp is type(None):
        return ()
    if isinstance(tp, types.UnionType) or get_origin(tp) is Union:
        result: list[type] = []
        for arg in get_args(tp):
            result.extend(_flatten_spec_types(arg, agent_cls))
        return tuple(result)
    if isinstance(tp, type):
        return (tp,)
    msg = f"Agent {agent_cls.__name__}: spec type must be a type, got {tp!r}"
    raise TypeError(msg)


def _flatten_result_types(tp: Any, agent_cls: type) -> tuple[type, ...]:
    tp = resolve_hint(tp)
    if tp is type(None):
        return ()
    if isinstance(tp, types.UnionType) or get_origin(tp) is Union:
        result: list[type] = []
        for arg in get_args(tp):
            result.extend(_flatten_result_types(arg, agent_cls))
        return tuple(result)
    if isinstance(tp, type):
        return (tp,)
    msg = f"Agent {agent_cls.__name__}: result type must be a type, got {tp!r}"
    raise TypeError(msg)


def _find_entry_step(agent_cls: type) -> str | None:
    """Find the single @step(entry=True) in agent's MRO. Raises on duplicates."""
    entry_tag: str | None = None
    for klass in reversed(agent_cls.__mro__):
        for attr_name in vars(klass):
            val = getattr(klass, attr_name, None)
            if not callable(val):
                continue
            tag = get_step_tag(val)
            if tag is None:
                continue
            if is_entry_step(val):
                if entry_tag is not None and entry_tag != tag:
                    msg = f"Agent {agent_cls.__name__} has multiple entry steps: {entry_tag!r} and {tag!r}"
                    raise TypeError(msg)
                entry_tag = tag
    return entry_tag
