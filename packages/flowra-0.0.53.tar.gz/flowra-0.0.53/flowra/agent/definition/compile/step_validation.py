import dataclasses
import inspect
from typing import Any

from ...flow import CallAgent, CallStep, GotoAgent, GotoStep, Spawn
from .type_helpers import flatten_types, get_type_hints

__all__ = ["validate_step_return_type"]


def validate_step_return_type(method: Any, tag: str) -> frozenset[type]:
    """Validate step return type and extract result (non-action) types."""
    hints = get_type_hints(method)
    ret = hints.get("return")
    if ret is None or ret is inspect.Parameter.empty:
        return frozenset()
    ret_types = flatten_types(ret)
    result_types: set[type] = set()
    for t in ret_types:
        if t is type(None):
            continue
        if not isinstance(t, type):
            return frozenset()
        if issubclass(t, (GotoStep, GotoAgent, Spawn)):
            continue
        if issubclass(t, (CallStep, CallAgent)):
            raise TypeError(
                f"Step {tag!r} return type {t.__name__} is not a valid StepResult "
                f"(must be GotoStep | GotoAgent | Spawn | dataclass | None)"
            )
        if not dataclasses.is_dataclass(t):
            raise TypeError(f"Step {tag!r} return type {t.__name__} must be a dataclass")
        result_types.add(t)
    return frozenset(result_types)
