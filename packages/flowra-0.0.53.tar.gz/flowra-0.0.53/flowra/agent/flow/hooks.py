import dataclasses
import inspect
import logging
from abc import ABC, abstractmethod
from collections.abc import AsyncIterator, Awaitable, Callable
from contextlib import asynccontextmanager
from typing import Any

from ..definition import AbstractAgent
from .context import ExecutionContext

__all__ = [
    "Event",
    "HookSubscription",
    "Hooks",
    "SpanExitHandler",
]

_logger = logging.getLogger(__name__)


type SpanExitHandler = Callable[[BaseException | None], None | Awaitable[None]]
"""Exit callback returned by a span handler. Called when the span closes.

Receives the error (if the span ended due to an exception) or ``None``.
May be sync or async — the emitter checks ``isawaitable`` at runtime.
"""


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Event[T]:
    """Generic envelope wrapping event/span data with execution context.

    Used for both regular events (``hooks.on``) and span enter handlers
    (``hooks.on_span``), providing a consistent interface.
    """

    data: T
    context: ExecutionContext


# ---------------------------------------------------------------------------
# ABC hierarchy
# ---------------------------------------------------------------------------


class HookSubscription(ABC):
    """Subscribe to events and spans."""

    @abstractmethod
    def on[E](
        self,
        event_type: type[E],
        handler: Callable[[Event[E]], Any],
        *,
        scope: str | type[AbstractAgent] | None = None,
    ) -> None: ...

    @abstractmethod
    def on_span[T](
        self,
        span_type: type[T],
        handler: Callable[[Event[T]], SpanExitHandler | None | Awaitable[SpanExitHandler | None]],
        *,
        scope: str | type[AbstractAgent] | None = None,
    ) -> None: ...


class Hooks(HookSubscription, ABC):
    """Subscribe + emit events and spans."""

    @abstractmethod
    async def emit[T](self, data: T) -> T: ...

    @abstractmethod
    async def open_span[T](self, span: T) -> T: ...

    @abstractmethod
    async def close_span(self, span: Any, *, error: BaseException | None = None) -> None: ...

    @abstractmethod
    def has_handlers(self, event_type: type) -> bool: ...

    @abstractmethod
    def has_span_handlers(self, span_type: type) -> bool: ...

    @asynccontextmanager
    async def span[T](self, span: T) -> AsyncIterator[T]:
        """Context manager: open span, yield, close on exit (with error on exception)."""
        await self.open_span(span)
        try:
            yield span
            await self.close_span(span)
        except BaseException as e:
            await self.close_span(span, error=e)
            raise


# ---------------------------------------------------------------------------
# Internal types
# ---------------------------------------------------------------------------


def _path_matches(for_path: str, prefix: str, *, inclusive: bool) -> bool:
    if not prefix:
        return True
    if inclusive:
        return for_path == prefix or for_path.startswith(prefix + "/")
    return for_path.startswith(prefix + "/")


type _PathScopedEntry = tuple[str, bool, Callable[..., Any]]
"""(path_prefix, inclusive, handler)"""

type _TypeScopedEntry = tuple[str, type[AbstractAgent], Callable[..., Any]]
"""(subtree_path, agent_type, original_handler)"""


class _HandlerGroup:
    __slots__ = ("global_handlers", "scoped", "type_scoped")

    def __init__(self) -> None:
        self.global_handlers: dict[type, list[Callable[..., Any]]] = {}
        self.scoped: dict[type, list[_PathScopedEntry]] = {}
        self.type_scoped: dict[type, list[_TypeScopedEntry]] = {}

    def clear_scoped(self) -> None:
        self.scoped.clear()
        self.type_scoped.clear()


def _make_type_filter(
    handler: Callable[..., Any],
    agent_type: type[AbstractAgent],
    subtree_path: str,
    *,
    is_span: bool,
) -> Callable[..., Any]:
    """Wrap a handler to only fire when the event's stack contains a matching agent type."""

    def _matches(event: Event[Any]) -> bool:
        for frame in event.context.stack:
            path = frame.agent.path
            if not _path_matches(path, subtree_path, inclusive=True):
                continue
            if frame.agent.source_type is agent_type:
                return True
        return False

    if is_span:

        def span_wrapper(event: Event[Any]) -> SpanExitHandler | None | Awaitable[SpanExitHandler | None]:
            if not _matches(event):
                return None
            return handler(event)

        return span_wrapper

    async def event_wrapper(event: Event[Any]) -> None:
        if not _matches(event):
            return
        result = handler(event)
        if inspect.isawaitable(result):
            await result

    return event_wrapper


# ---------------------------------------------------------------------------
# Single implementation
# ---------------------------------------------------------------------------


class HooksImpl(Hooks):
    """Concrete implementation of Hooks.

    Root instance (``context=None``) owns the handler storage and is used
    as ``runtime.hooks``.  Agent instances (``context=..., _root=root``)
    share the root's storage and add emit/span capabilities.
    """

    __slots__ = ("_context", "_events", "_exit_handlers", "_root", "_spans")

    def __init__(self, *, context: ExecutionContext | None = None, _root: "HooksImpl | None" = None) -> None:
        if _root is None:
            self._root: HooksImpl = self
            self._events = _HandlerGroup()
            self._spans = _HandlerGroup()
        else:
            self._root = _root
        self._context = context
        self._exit_handlers: dict[int, list[Callable[..., Any]]] = {}

    # -- HookSubscription --

    def on[E](
        self,
        event_type: type[E],
        handler: Callable[[Event[E]], Any],
        *,
        scope: str | type[AbstractAgent] | None = None,
    ) -> None:
        self.__register(self._root._events, event_type, handler, scope)

    def on_span[T](
        self,
        span_type: type[T],
        handler: Callable[[Event[T]], SpanExitHandler | None | Awaitable[SpanExitHandler | None]],
        *,
        scope: str | type[AbstractAgent] | None = None,
    ) -> None:
        self.__register(self._root._spans, span_type, handler, scope)

    # -- Hooks --

    def has_handlers(self, event_type: type) -> bool:
        return self.__has(self._root._events, event_type)

    def has_span_handlers(self, span_type: type) -> bool:
        return self.__has(self._root._spans, span_type)

    async def emit[T](self, data: T) -> T:
        event = Event(data=data, context=self.__context)
        for handler in self.__resolve(self._root._events, type(data), is_span=False):
            result = handler(event)
            if inspect.isawaitable(result):
                await result
        return event.data

    async def open_span[T](self, span: T) -> T:
        handlers = self.__resolve(self._root._spans, type(span), is_span=True)
        if handlers:
            event = Event(data=span, context=self.__context)
            exit_list: list[SpanExitHandler] = []
            for handler in reversed(handlers):
                try:
                    exit_handler = handler(event)
                    if inspect.isawaitable(exit_handler):
                        exit_handler = await exit_handler
                    if exit_handler is not None:
                        exit_list.append(exit_handler)
                except Exception:
                    _logger.exception("Span enter handler failed")
            if exit_list:
                self._exit_handlers[id(span)] = exit_list
        return span

    async def close_span(self, span: Any, *, error: BaseException | None = None) -> None:
        exit_list: list[SpanExitHandler] | None = self._exit_handlers.pop(id(span), None)
        if exit_list is None:
            return
        for exit_handler in reversed(exit_list):
            try:
                r = exit_handler(error)
                if inspect.isawaitable(r):
                    await r
            except Exception:
                _logger.exception("Span exit handler failed")

    # -- Lifecycle --

    def for_agent(self, context: ExecutionContext) -> "HooksImpl":
        """Create an agent-scoped view sharing this instance's storage."""
        return HooksImpl(context=context, _root=self._root)

    def clear_scoped(self) -> None:
        """Clear all scoped handlers. Called between runs to prevent accumulation."""
        self._root._events.clear_scoped()
        self._root._spans.clear_scoped()

    # -- Internals --

    @property
    def __context(self) -> ExecutionContext:
        assert self._context is not None, "emit/span requires an agent context"
        return self._context

    def __register(
        self,
        group: _HandlerGroup,
        key: type,
        handler: Callable[..., Any],
        scope: str | type[AbstractAgent] | None,
    ) -> None:
        if self._context is None:
            # Global registration (root / runtime.hooks)
            if scope is None:
                group.global_handlers.setdefault(key, []).append(handler)
            elif isinstance(scope, str):
                group.scoped.setdefault(key, []).append((scope, True, handler))
            else:
                group.type_scoped.setdefault(key, []).append(("", scope, handler))
        else:
            # Agent-scoped registration
            agent_path = self._context.frame.agent.path
            if scope is None:
                group.scoped.setdefault(key, []).append((agent_path, False, handler))
            elif isinstance(scope, str):
                group.scoped.setdefault(key, []).append((agent_path + "/" + scope, True, handler))
            else:
                group.type_scoped.setdefault(key, []).append((agent_path, scope, handler))

    def __resolve(self, group: _HandlerGroup, key: type, *, is_span: bool) -> list[Callable[..., Any]]:
        result = list(group.global_handlers.get(key, []))
        if self._context is not None:
            agent_path = self._context.frame.agent.path
            for prefix, inclusive, handler in group.scoped.get(key, []):
                if _path_matches(agent_path, prefix, inclusive=inclusive):
                    result.append(handler)
            for subtree_path, agent_type, handler in group.type_scoped.get(key, []):
                if _path_matches(agent_path, subtree_path, inclusive=False):
                    result.append(_make_type_filter(handler, agent_type, subtree_path, is_span=is_span))
        return result

    def __has(self, group: _HandlerGroup, key: type) -> bool:
        if group.global_handlers.get(key):
            return True
        if self._context is not None:
            agent_path = self._context.frame.agent.path
            for prefix, inclusive, _ in group.scoped.get(key, []):
                if _path_matches(agent_path, prefix, inclusive=inclusive):
                    return True
            for subtree_path, _, _ in group.type_scoped.get(key, []):
                if _path_matches(agent_path, subtree_path, inclusive=False):
                    return True
        return False
