# Flowra — Video Script

## General notes

- Format: screencast (terminal + editor), face optional
- Duration: ~10-12 minutes
- Code is written in real time (or sped up), run, results shown
- Everything in a single file `demo.py`, incrementally growing
- Provider: OpenAI (simplest setup — just an API key)


---


## 1. Intro (30-60 sec)

**Script:**

> Hey! Today I'll show you Flowra — a Python library for building LLM agents.
>
> Flowra is not just a wrapper around LLM APIs. It's a framework where agents
> are state machines with persistent state, tool use, parallel execution,
> and crash recovery.
>
> We'll go from a bare LLM call to a full chatbot with tools, streaming,
> and session persistence. Everything you'll see is working code you can
> run yourself.

**On screen:** Nothing, or the GitHub repo front page.


---


## 2. Installation (30-40 sec)

**Script:**

> Let's start with installation. Flowra is a regular pip package. I'll use
> uv — a fast Python package manager — but plain pip works too.
> Install Flowra with the provider you need. I'll use OpenAI, but Flowra
> also supports Claude via Vertex AI and Gemini.

**On screen:** Terminal.

```bash
uv init demo && cd demo
uv add 'flowra[openai]' python-dotenv
```

> You need Python 3.12 or higher. I'll keep my credentials in a `.env`
> file — here's what it looks like.

**On screen:** Show `.env.example` in the editor.

```
OPENAI_API_KEY=sk-...
OPENAI_BASE_URL=https://api.openai.com/v1
OPENAI_ORGANIZATION=org-...
```

> I have a real `.env` with actual values next to it. Now let's create
> `demo.py` — we'll build it up step by step.

**On screen:** Create an empty `demo.py` in the editor.


---


## 3. A bare LLM call (2-3 min)

**Script:**

> The simplest thing you can do with Flowra is call an LLM directly through
> the provider interface.

**On screen:** Write code in the editor.

```python
import asyncio
import os

from dotenv import load_dotenv
from flowra.llm import LLMRequest, TextBlock, UserMessage
from flowra.llm.providers.openai import OpenAIProvider

load_dotenv()


async def main() -> None:
    async with OpenAIProvider(
        api_key=os.environ["OPENAI_API_KEY"],
        base_url=os.environ.get("OPENAI_BASE_URL"),
        organization=os.environ.get("OPENAI_ORGANIZATION"),
    ) as provider:
        request = LLMRequest(
            model="gpt-4o-mini",
            messages=[UserMessage(blocks=[TextBlock(text="What is 2 + 2?")])],
            max_tokens=256,
        )

        response = await provider.call(request)
        print(response.message.text)
        print(f"{response.usage.input_tokens} in, {response.usage.output_tokens} out, ${response.usage.cost_usd:.4f}")


asyncio.run(main())
```

> Here's what's going on:
>
> - `OpenAIProvider` — one of four built-in providers. There's also
>   Anthropic via Vertex AI, Google Gemini, and OpenAI Responses API.
> - `LLMRequest` — a universal request object, the same for all providers.
>   Model, messages, token limit.
> - The response contains the text, token usage, and an estimated cost.
>
> Let's run it.

**On screen:** Run `uv run demo.py`, see the answer "4" and usage stats.

> That works. But this is just one API call. For a real application you need
> conversation history, tools, persistence. That's where agents come in.


---


## 4. ChatAgent — a chatbot (2-3 min)

**Script:**

> Flowra ships with a built-in `ChatAgent` — a multi-turn chat agent that
> manages conversation history automatically. Each `runtime.run()` call
> is one turn in the dialogue.

**On screen:** Rewrite `demo.py`.

```python
import asyncio
import os

from dotenv import load_dotenv
from flowra.agent import AgentRuntime
from flowra.lib import LLMConfig
from flowra.lib.chat import ChatAgent, ChatConfig, ChatResult, ChatSpec
from flowra.llm import LLMProvider, SystemMessage, TextBlock
from flowra.llm.providers.openai import OpenAIProvider

load_dotenv()


async def main() -> None:
    async with OpenAIProvider(
        api_key=os.environ["OPENAI_API_KEY"],
        base_url=os.environ.get("OPENAI_BASE_URL"),
        organization=os.environ.get("OPENAI_ORGANIZATION"),
    ) as provider:
        config = ChatConfig(
            llm_config=LLMConfig(model="gpt-4o-mini"),
            system=[SystemMessage(blocks=[TextBlock(text="You are a helpful assistant.")])],
        )

        runtime = AgentRuntime(
            agents={"chat": ChatAgent},
            services={
                LLMProvider: provider,
                ChatConfig: config,
            },
        )

        while True:
            user_input = input("You: ")
            if not user_input:
                break

            result = await runtime.run(agent=ChatAgent, spec=ChatSpec.text(user_input))

            if isinstance(result, ChatResult) and result.response:
                print(f"Assistant: {result.response}")


asyncio.run(main())
```

> Let's walk through the key parts:
>
> - **`AgentRuntime`** — the engine that runs agents. You register agent
>   classes and provide the services they need.
> - **Services** are dependency injection. `ChatAgent` needs an LLM provider
>   and a config. The runtime passes them automatically by type.
> - **`ChatSpec`** — input (the user's messages). **`ChatResult`** — output
>   (the assistant's response).
>
> Let's run it and have a conversation.

**On screen:** Run, type a few messages, see the bot remembers context.

```
You: Hi, I'm Ivan
Assistant: Hi Ivan! How can I help you?
You: What's my name?
Assistant: Your name is Ivan!
```

> See — it remembers the name. `ChatAgent` accumulates the history and
> passes it to the LLM on every call.


---


## 5. Adding tools (3-4 min)

**Script:**

> Now for the most interesting part — tools. We can let the LLM call our
> Python functions. The model decides on its own when and which tool to use.

**On screen:** Add the tool at the top of the file.

```python
from dataclasses import dataclass
from flowra.tools import tool


@dataclass
class WeatherParams:
    city: str


@tool("get_weather")
def get_weather(params: WeatherParams) -> str:
    """Get current weather for a city."""
    return f"It's sunny and 22°C in {params.city}"
```

> A tool is just a regular function with the `@tool` decorator. Parameters
> are described as a dataclass — the JSON schema for the LLM is generated
> automatically from it. The description comes from the docstring.
>
> Now let's register the tool in the `ToolRegistry`:

**On screen:** Change registry creation and config.

```python
async with OpenAIProvider(
    api_key=os.environ["OPENAI_API_KEY"],
    base_url=os.environ.get("OPENAI_BASE_URL"),
    organization=os.environ.get("OPENAI_ORGANIZATION"),
) as provider:
    registry = ToolRegistry([get_weather])
```

> Let's run it and ask about the weather.

**On screen:** Run.

```
You: What's the weather like in Paris?
Assistant: The weather in Paris is sunny and 22°C!
```

> Here's what happened under the hood:
>
> 1. ChatAgent sent the message and the tool definitions to the LLM
> 2. The LLM responded: "I want to call `get_weather` with `{"city": "Paris"}`"
> 3. Flowra executed the function and sent the result back to the LLM
> 4. The LLM produced the final response for the user
>
> This is the tool loop. ChatAgent runs it automatically.

**[Pause]**

> Let's add a second tool — a calculator.

**On screen:** Add it.

```python
@dataclass
class CalcParams:
    expression: str


@tool("calculate")
def calculate(params: CalcParams) -> str:
    """Evaluate a math expression. Examples: '2 + 2', '(3 + 5) * 2'."""
    return str(eval(params.expression))
```

> And register both:

```python
registry = ToolRegistry([
    get_weather,
    calculate,
])
```

**On screen:** Run.

```
You: What's 17 * 23 + 5?
Assistant: 17 * 23 + 5 = 396.
You: And what's the weather in London?
Assistant: It's sunny and 22°C in London!
```

> The LLM picks the right tool depending on the question.


---


## 6. Streaming (1.5-2 min)

**Script:**

> Right now we wait for the full response. But we can see the text as it's
> being generated — all it takes is subscribing to a `TextDeltaEvent`.

**On screen:** Add after runtime creation.

```python
from flowra.lib.observability import TextDeltaEvent

# ... after creating the runtime:
runtime.hooks.on(TextDeltaEvent, lambda e: print(e.data.text, end="", flush=True))
```

> One line — and the agent automatically switches from `provider.call()` to
> `provider.stream()`. Nothing else needs to change.

**On screen:** Run, ask a longer question — see text appearing token by token.

```
You: Tell me a fun fact about the Eiffel Tower
Assistant: [text appears token by token]
```

> This works through the hook system — events. When a `TextDeltaEvent`
> handler is registered, the agent detects it and switches to streaming
> automatically.


---


## 7. Persistence and crash recovery (2-3 min)

**Script:**

> The last feature for today — persistence. By default, conversation history
> lives only in memory. But with `FileSessionStorage`, it's saved to disk.

**On screen:** Add storage.

```python
from flowra.agent import FileSessionStorage

storage = FileSessionStorage(base_dir="./sessions", session_id="demo-session")

runtime = AgentRuntime(
    agents={"chat": ChatAgent},
    storage=storage,           # <-- added
    services={
        LLMProvider: provider,
        ChatConfig: config,
    },
)
```

> Now state is persisted after every step. This gives us two things.
>
> First — we can restart the program, and the bot remembers the conversation.

**On screen:** Run, send a message, exit (Ctrl+C), run again, ask "What did I say?"

```
# First run:
You: My favorite color is blue
Assistant: Nice, blue is a great color!
# Ctrl+C

# Second run:
You: What's my favorite color?
Assistant: Your favorite color is blue!
```

> Second — crash recovery. If the process dies mid-execution — say, the LLM
> responded but we crashed before processing the result — we can pick up
> right where we left off.

**On screen:** Add resume logic.

```python
if await runtime.has_pending_execution():
    print("Resuming interrupted execution...")
    result = await runtime.resume()
    if isinstance(result, ChatResult) and result.response:
        print(f"Assistant: {result.response}")
```

> `has_pending_execution()` checks if there's an unfinished run.
> `resume()` continues from the last completed step. Agent state —
> `Scalar` and `AppendOnlyList` — is saved incrementally, only what
> changed.


---


## 8. What's next (30-40 sec)

**Script:**

> We've gone from a bare LLM call to a chatbot with tools, streaming,
> and persistence. But this is just the start.
>
> Flowra can do much more:
>
> - **Custom agents** — state machines with steps and transitions
> - **Parallel execution** — `WhenAll`, `WhenAny`, `WhenN` — run multiple
>   agents in parallel and collect results
> - **Agents as tools** — one agent can be a tool for another
> - **Observability** — MLflow and OpenTelemetry out of the box
> - **MCP servers** — connect external tool servers
>
> Links to the documentation are in the description. Thanks for watching!

**On screen:** Documentation page on GitHub, or a slide with links.


---


## Final code

The complete `demo.py` by the end of the video:

```python
import asyncio
import os
from dataclasses import dataclass

from dotenv import load_dotenv
from flowra.agent import AgentRuntime, FileSessionStorage
from flowra.lib import LLMConfig
from flowra.lib.chat import ChatAgent, ChatConfig, ChatResult, ChatSpec
from flowra.lib.observability import TextDeltaEvent
from flowra.llm import LLMProvider, SystemMessage, TextBlock
from flowra.llm.providers.openai import OpenAIProvider
from flowra.tools import ToolRegistry, tool

load_dotenv()


@dataclass
class WeatherParams:
    city: str


@tool("get_weather")
def get_weather(params: WeatherParams) -> str:
    """Get current weather for a city."""
    return f"It's sunny and 22°C in {params.city}"


@dataclass
class CalcParams:
    expression: str


@tool("calculate")
def calculate(params: CalcParams) -> str:
    """Evaluate a math expression. Examples: '2 + 2', '(3 + 5) * 2'."""
    return str(eval(params.expression))


async def main() -> None:
    async with OpenAIProvider(
        api_key=os.environ["OPENAI_API_KEY"],
        base_url=os.environ.get("OPENAI_BASE_URL"),
        organization=os.environ.get("OPENAI_ORGANIZATION"),
    ) as provider:
        registry = ToolRegistry([
            get_weather,
            calculate,
        ])

        config = ChatConfig(
            tools=registry,
            llm_config=LLMConfig(model="gpt-4o-mini"),
            system=[SystemMessage(blocks=[TextBlock(text="You are a helpful assistant.")])],
        )

        storage = FileSessionStorage(base_dir="./sessions", session_id="demo-session")

        runtime = AgentRuntime(
            agents={"chat": ChatAgent},
            storage=storage,
            services={
                LLMProvider: provider,
                ChatConfig: config,
            },
        )
        runtime.hooks.on(TextDeltaEvent, lambda e: print(e.data.text, end="", flush=True))

        if await runtime.has_pending_execution():
            print("Resuming interrupted execution...")
            result = await runtime.resume()
            if isinstance(result, ChatResult) and result.response:
                print(f"Assistant: {result.response}")

        while True:
            user_input = input("\nYou: ")
            if not user_input:
                break

            result = await runtime.run(agent=ChatAgent, spec=ChatSpec.text(user_input))

            print()  # newline after streaming
            if isinstance(result, ChatResult) and result.response:
                print(f"[response complete]")


asyncio.run(main())
```
