"""External OTel span wrapping flowra with both MLflow and OTel tracing.

Demonstrates how flowra integrates with external OTel context when using both
MLflow and OTel tracing simultaneously.

Setup:
- External OTel span created by business app
- Flowra runs inside with BOTH MLflow and OTel tracing enabled
- OTel spans nest into external context
- MLflow creates independent trace tree

Result: 3 perspectives on the same execution:
1. OTel (Jaeger): full distributed trace including external span
2. MLflow: LLM-specific view with cost/tokens
3. Console: tree visualization

Usage:
    uv run python examples/mlflow_otel_nested_demo.py

View traces:
    # Jaeger (full tree with external span):
    # http://localhost:16686 → service "business_app"

    # MLflow (LLM details):
    uv run mlflow ui --port 5050
    # http://localhost:5050 → experiment "mlflow-otel-nested"
"""

import asyncio
import pathlib

from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor

from examples.app_agent import AppAgent, AppConfig
from examples.model_registry import DEFAULT_MODEL, create_router
from examples.tools import calculate
from flowra.agent import AgentRuntime, InMemorySessionStorage
from flowra.ext.mlflow import MLFLOW_TRACING
from flowra.ext.otel import OTEL_TRACING
from flowra.lib.chat import ChatResult, ChatSpec
from flowra.llm import LLMProvider, SystemMessage, TextBlock
from flowra.tools import ToolRegistry

_EXAMPLES_DIR = pathlib.Path(__file__).parent
_SYSTEM_PROMPT = (_EXAMPLES_DIR / "system_prompt.txt").read_text()


async def run_flowra_agent(runtime: AgentRuntime, question: str) -> ChatResult:
    """Run flowra agent (will be traced by both MLflow and OTel)."""
    print(f"\n→ Question: {question}")
    result = await runtime.run(
        agent=AppAgent,
        spec=ChatSpec.text(question),
    )

    if isinstance(result, ChatResult):
        print(f"← Answer: {result.response}")
        if result.usage:
            print(f"  Tokens: {result.usage.input_tokens} in, {result.usage.output_tokens} out")
            if result.usage.cost_usd:
                print(f"  Cost: ${result.usage.cost_usd:.4f}")

    return result


async def main() -> None:
    # Configure OTel
    resource = Resource(attributes={"service.name": "business_app"})
    provider = TracerProvider(resource=resource)
    otlp_exporter = OTLPSpanExporter(endpoint="http://localhost:4317", insecure=True)
    provider.add_span_processor(BatchSpanProcessor(otlp_exporter))
    trace.set_tracer_provider(provider)

    # Get tracer for business logic
    business_tracer = trace.get_tracer("business_app")

    router = create_router()

    registry = ToolRegistry([calculate])
    app_config = AppConfig(
        default_model=DEFAULT_MODEL,
        tools=registry,
        system=lambda: [SystemMessage(blocks=[TextBlock(text=_SYSTEM_PROMPT)])],
    )

    runtime = AgentRuntime(
        agents={"app": AppAgent},
        storage=InMemorySessionStorage(),
        services={
            AppConfig: app_config,
            LLMProvider: router,
        },
    )

    # Install BOTH MLflow and OTel tracing
    MLFLOW_TRACING.install(runtime, experiment_name="mlflow-otel-nested", trace_steps=True)
    OTEL_TRACING.install(runtime, tracer_name="flowra", capture_content=False)

    print("=" * 70)
    print("External OTel span wrapping flowra with dual tracing")
    print("=" * 70)
    print("Setup:")
    print("  - External OTel span: 'business_workflow'")
    print("  - Flowra with MLflow tracing (independent tree)")
    print("  - Flowra with OTel tracing (nests into external span)")
    print("=" * 70)

    # Create external OTel span
    with business_tracer.start_as_current_span("business_workflow") as workflow_span:
        workflow_span.set_attribute("workflow_type", "math_questions")

        # Run flowra inside external span
        result = await run_flowra_agent(runtime, "What is 144 / 12? Use the calculator.")

        workflow_span.set_attribute("success", True)
        if result.usage:
            workflow_span.set_attribute("total_cost", result.usage.cost_usd or 0)

    # Flush OTel spans
    provider.force_flush()

    print("\n" + "=" * 70)
    print("Done! Compare traces across systems:")
    print("=" * 70)
    print()
    print("1. Jaeger (OTel) — http://localhost:16686")
    print("   Service: 'business_app'")
    print("   Shows: external 'business_workflow' span with flowra spans nested inside")
    print()
    print("2. MLflow — http://localhost:5050")
    print("   Experiment: 'mlflow-otel-nested'")
    print("   Shows: independent MLflow trace tree (different trace ID)")
    print("   Focus: LLM details (cost, tokens, chat messages)")
    print()
    print("Key insight:")
    print("  - OTel integrates with external context (same trace tree)")
    print("  - MLflow creates independent tree (its own trace ID)")
    print("  - Both capture the SAME execution from different perspectives")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
