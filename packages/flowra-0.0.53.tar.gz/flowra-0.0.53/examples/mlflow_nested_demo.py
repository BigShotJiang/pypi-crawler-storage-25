"""MLflow nested tracing demo — flowra agent runs inside external MLflow span.

Demonstrates that flowra integrates with external MLflow context. When you create
a span with `with mlflow.start_span()` and call flowra inside, flowra's spans
become children of the external span.

Usage:
    uv run python examples/mlflow_nested_demo.py

Then view traces:
    uv run mlflow ui --port 5050
    # open http://localhost:5050, experiment "flowra-nested-demo", Traces tab
"""

import asyncio
import pathlib

import mlflow

from examples.app_agent import AppAgent, AppConfig
from examples.model_registry import DEFAULT_MODEL, create_router
from examples.tools import calculate, random_numbers
from flowra.agent import AgentRuntime, InMemorySessionStorage
from flowra.ext.mlflow import MLFLOW_TRACING
from flowra.lib.chat import ChatResult, ChatSpec
from flowra.llm import LLMProvider, SystemMessage, TextBlock
from flowra.tools import ToolRegistry

_EXAMPLES_DIR = pathlib.Path(__file__).parent
_SYSTEM_PROMPT = (_EXAMPLES_DIR / "system_prompt.txt").read_text()


async def run_agent_with_flowra_tracing(runtime: AgentRuntime, question: str) -> ChatResult:
    """Run agent with flowra's MLflow tracing."""
    print(f"\n→ Sending: {question}")
    result = await runtime.run(
        agent=AppAgent,
        spec=ChatSpec.text(question),
    )

    if isinstance(result, ChatResult):
        print(f"← Assistant: {result.response}")
        if result.usage:
            print(f"  Tokens: {result.usage.input_tokens} in, {result.usage.output_tokens} out")
            if result.usage.cost_usd is not None:
                print(f"  Cost: ${result.usage.cost_usd:.4f}")

    return result


async def main() -> None:
    mlflow.set_experiment("flowra-nested-demo")

    router = create_router()

    registry = ToolRegistry([calculate, random_numbers])
    app_config = AppConfig(
        default_model=DEFAULT_MODEL,
        tools=registry,
        system=lambda: [
            SystemMessage(blocks=[TextBlock(text=_SYSTEM_PROMPT)]),
        ],
    )

    runtime = AgentRuntime(
        agents={"app": AppAgent},
        storage=InMemorySessionStorage(),
        services={
            AppConfig: app_config,
            LLMProvider: router,
        },
    )
    MLFLOW_TRACING.install(runtime, experiment_name="flowra-nested-demo", trace_steps=True)

    # Create an external MLflow span
    print("=" * 60)
    print("Creating external MLflow span: 'business_logic'")
    print("=" * 60)

    with mlflow.start_span(name="business_logic") as business_span:
        business_span.set_inputs({"workflow": "multi-question-processing"})

        # First agent call inside external span
        with mlflow.start_span(name="question_1_processing") as q1_span:
            q1_span.set_inputs({"question": "What is 5+3?"})
            result1 = await run_agent_with_flowra_tracing(runtime, "What is 5+3? Use the calculator.")
            q1_span.set_outputs({"answer": result1.response})

        # Second agent call inside external span
        with mlflow.start_span(name="question_2_processing") as q2_span:
            q2_span.set_inputs({"question": "Generate 3 random numbers"})
            result2 = await run_agent_with_flowra_tracing(runtime, "Generate 3 random numbers between 1 and 100.")
            q2_span.set_outputs({"answer": result2.response})

        business_span.set_outputs({"questions_processed": 2, "status": "success"})

    print("\n" + "=" * 60)
    print("Done! View traces: uv run mlflow ui --port 5050")
    print("Check that flowra spans are nested inside 'business_logic' span")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
