#
# Copyright (c) 2026 by Actian Corporation
# All rights reserved.
#
# THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE
# OF ACTIAN CORP.
# The copyright notice above does not evidence any actual or intended
# publication of such source code.
#

"""Smart Batcher subpackage - Automatic batching for high-throughput ingestion."""

from actian_vectorai.batcher.smart_batcher import BatcherConfig, SmartBatcher

__all__ = [
    "SmartBatcher",
    "BatcherConfig",
]
