#
# Copyright (c) 2026 by Actian Corporation
# All rights reserved.
#
# THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE
# OF ACTIAN CORP.
# The copyright notice above does not evidence any actual or intended
# publication of such source code.
#

"""Validation utilities for VectorAI DB client operations.

Provides input validation for vectors, collection names, and payloads
to prevent server errors and provide clear error messages.
"""

from __future__ import annotations

import uuid
from typing import Any, Sequence

import numpy as np

from actian_vectorai.exceptions import ValidationError


def validate_collection_name(name: str) -> str:
    """Validate collection name against server rules.

    Args:
        name: Collection name to validate

    Returns:
        The validated collection name

    Raises:
        ValidationError: If name is invalid

    Note:
        Collection names must:
        - Be 1-255 characters
        - Not contain: < > : " / \\ | ? * NUL (\\0) U+001F
    """
    if not isinstance(name, str):
        raise ValidationError(f"Collection name must be a string, got {type(name).__name__!r}")

    if not name:
        raise ValidationError("Collection name cannot be empty")

    if len(name) > 255:
        raise ValidationError(f"Collection name too long: {len(name)} > 255 characters")

    _invalid_chars = set('<>:"/\\|?*\x00\x1f')
    bad = [c for c in name if c in _invalid_chars]
    if bad:
        unique_bad = "".join(dict.fromkeys(bad))
        raise ValidationError(
            f"Invalid collection name '{name}'. "
            f"Contains invalid characters: {unique_bad!r}. "
            "The following characters are not allowed: "
            '< > : " / \\ | ? * NUL (\\0) U+001F'
        )

    return name

def _validate_numpy_vector(
    vector: "np.ndarray[Any, Any]",
    expected_dimension: int | None,
    name: str,
) -> list[float]:
    """Validate and convert a numpy vector to a float list."""
    if vector.size == 0:
        raise ValidationError(f"{name} cannot be empty")
    if vector.ndim != 1:
        raise ValidationError(
            f"{name} must be 1-D, got shape {vector.shape}"
        )
    if not np.issubdtype(vector.dtype, np.number):
        raise ValidationError(
            f"{name} must contain numeric values, got dtype {vector.dtype}"
        )
    if not np.all(np.isfinite(vector)):
        raise ValidationError(f"{name} contains NaN or Inf values")
    if expected_dimension is not None and vector.shape[0] != expected_dimension:
        raise ValidationError(
            f"{name} dimension mismatch: got {vector.shape[0]}, expected {expected_dimension}"
        )
    arr = vector.astype(np.float32, copy=False) if vector.dtype != np.float32 else vector
    return arr.tolist()  # type: ignore[no-any-return]


def _validate_list_vector(
    vector: list[float] | tuple[float, ...],
    expected_dimension: int | None,
    name: str,
) -> list[float]:
    """Validate and convert a list/tuple vector to a float list."""
    if len(vector) == 0:
        raise ValidationError(f"{name} cannot be empty")
    for i, v in enumerate(vector):
        if not isinstance(v, (int, float)):
            raise ValidationError(f"{name}[{i}] must be numeric, got {type(v).__name__}")
    if expected_dimension is not None and len(vector) != expected_dimension:
        raise ValidationError(
            f"{name} dimension mismatch: got {len(vector)}, expected {expected_dimension}"
        )
    return [float(v) for v in vector]


def validate_vector(
    vector: list[float] | "np.ndarray[Any, Any]" | Any,
    expected_dimension: int | None = None,
    name: str = "vector",
) -> list[float]:
    """Validate vector data.

    Args:
        vector: Vector to validate
        expected_dimension: Expected dimension (if known from collection)
        name: Name for error messages

    Returns:
        The vector as a list of floats

    Raises:
        ValidationError: If vector is invalid
    """
    if isinstance(vector, np.ndarray):
        return _validate_numpy_vector(vector, expected_dimension, name)
    if isinstance(vector, (list, tuple)):
        return _validate_list_vector(vector, expected_dimension, name)
    raise ValidationError(f"{name} must be a list or numpy array, got {type(vector).__name__}")

def validate_vectors_batch(
    vectors: Sequence[list[float] | "np.ndarray[Any, Any]"],
    expected_dimension: int | None = None,
) -> list[list[float]]:
    """Validate a batch of vectors.

    Args:
        vectors: List of vectors to validate
        expected_dimension: Expected dimension (if known from collection)

    Returns:
        List of validated vectors

    Raises:
        ValidationError: If any vector is invalid
    """
    if not vectors:
        raise ValidationError("Vectors list cannot be empty")

    validated = []
    dimension = expected_dimension

    for i, vec in enumerate(vectors):
        validated_vec = validate_vector(vec, dimension, f"vector[{i}]")
        validated.append(validated_vec)

        # Infer dimension from first vector if not specified
        if dimension is None:
            dimension = len(validated_vec)

    return validated

def validate_payload(payload: dict[str, Any] | None) -> dict[str, Any] | None:
    """Validate payload dictionary.

    Args:
        payload: Payload to validate

    Returns:
        The validated payload

    Raises:
        ValidationError: If payload is invalid
    """
    if payload is None:
        return None

    if not isinstance(payload, dict):
        raise ValidationError(f"Payload must be a dict, got {type(payload).__name__}")

    # Check keys are strings
    for key in payload.keys():
        if not isinstance(key, str):
            raise ValidationError(f"Payload keys must be strings, got {type(key).__name__}")

    return payload

def validate_id(id_val: int | str | uuid.UUID) -> int | str:
    """Validate a single vector ID (non-negative int, UUID string, or uuid.UUID object).

    Args:
        id_val: ID to validate — non-negative int, valid UUID string, or uuid.UUID object.
                uuid.UUID objects are automatically converted to their canonical string form.

    Returns:
        Validated ID

    Raises:
        ValidationError: If the ID is invalid
    """
    if isinstance(id_val, uuid.UUID):
        # Accept uuid.UUID objects directly — convert to canonical string form
        return str(id_val)
    if isinstance(id_val, int):
        if id_val < 0:
            raise ValidationError(f"ID must be non-negative, got {id_val}")
        return id_val
    if isinstance(id_val, str):
        try:
            uuid.UUID(id_val)
        except ValueError:
            raise ValidationError(f"String ID must be a valid UUID, got '{id_val}'") from None
        return id_val
    raise ValidationError(
        f"ID must be a non-negative integer or UUID string, got {type(id_val).__name__}"
    )

def validate_ids(ids: Sequence[int | str | uuid.UUID]) -> list[int | str]:
    """Validate a list of vector IDs (non-negative ints, UUID strings, or uuid.UUID objects).

    Args:
        ids: List of IDs to validate

    Returns:
        List of validated IDs

    Raises:
        ValidationError: If any ID is invalid
    """
    if not ids:
        raise ValidationError("IDs list cannot be empty")

    validated = []
    for i, id_val in enumerate(ids):
        try:
            validated.append(validate_id(id_val))
        except ValidationError as e:
            raise ValidationError(f"IDs[{i}]: {e}") from e

    return validated

_MAX_SEARCH_LIMIT: int = 1_000_000

def validate_top_k(top_k: int) -> int:
    """Validate top_k / limit parameter for search operations.

    Args:
        top_k: Number of results to return.

    Returns:
        Validated top_k value

    Raises:
        ValidationError: If top_k is invalid
    """
    if not isinstance(top_k, int):
        raise ValidationError(f"limit must be an integer, got {type(top_k).__name__}")

    if top_k < 1:
        raise ValidationError(f"limit must be >= 1, got {top_k}")

    if top_k > _MAX_SEARCH_LIMIT:
        raise ValidationError(f"limit {top_k} exceeds maximum allowed value of {_MAX_SEARCH_LIMIT}")

    return top_k

def validate_batch_size(batch_size: int, *, max_size: int = 10_000) -> int:
    """Validate batch size parameter.

    Args:
        batch_size: Batch size to validate.
        max_size: Maximum allowed batch size.

    Returns:
        Validated batch size.

    Raises:
        ValidationError: If batch_size is invalid.
    """
    if not isinstance(batch_size, int) or batch_size < 1:
        raise ValidationError(f"batch_size must be a positive integer, got {batch_size}")
    if batch_size > max_size:
        raise ValidationError(f"batch_size {batch_size} exceeds max {max_size}")
    return batch_size

def validate_timeout(timeout: float | None) -> float | None:
    """Validate timeout parameter.

    Args:
        timeout: Timeout value in seconds.

    Returns:
        Validated timeout value.

    Raises:
        ValidationError: If timeout is invalid.
    """
    if timeout is None:
        return None
    if not isinstance(timeout, (int, float)) or timeout <= 0:
        raise ValidationError(f"timeout must be a positive number, got {timeout}")
    return float(timeout)

def validate_vector_dimension(dimension: int) -> int:
    """Validate vector dimension parameter.

    Args:
        dimension: Dimension to validate.

    Returns:
        Validated dimension.

    Raises:
        ValidationError: If dimension is invalid.
    """
    if not isinstance(dimension, int) or dimension < 1:
        raise ValidationError(f"Vector dimension must be a positive integer, got {dimension}")
    if dimension > 65536:
        raise ValidationError(f"Vector dimension {dimension} exceeds maximum (65536)")
    return dimension

def validate_sparse_vector(values: Sequence[float], indices: Sequence[int]) -> None:
    """Validate sparse vector components.

    Args:
        values: Sparse vector values.
        indices: Sparse vector indices.

    Raises:
        ValidationError: If sparse vector is invalid.
    """
    if len(values) != len(indices):
        raise ValidationError(
            f"Sparse vector length mismatch: {len(values)} values vs {len(indices)} indices"
        )
    if indices and min(indices) < 0:
        raise ValidationError("Sparse vector indices must be non-negative")
    if len(set(indices)) != len(indices):
        raise ValidationError("Sparse vector indices must be unique")

def validate_payload_keys(keys: Sequence[str]) -> list[str]:
    """Validate payload key names.

    Args:
        keys: List of payload keys to validate.

    Returns:
        Validated list of keys.

    Raises:
        ValidationError: If any key is invalid.
    """
    if not keys:
        raise ValidationError("Payload keys list cannot be empty")
    for i, key in enumerate(keys):
        if not isinstance(key, str):
            raise ValidationError(f"Payload key[{i}] must be a string, got {type(key).__name__}")
        if not key:
            raise ValidationError(f"Payload key[{i}] cannot be empty")
    return list(keys)
