#
# Copyright (c) 2026 by Actian Corporation
# All rights reserved.
#
# THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE
# OF ACTIAN CORP.
# The copyright notice above does not evidence any actual or intended
# publication of such source code.
#

"""Internal utilities for the Actian VectorAI Python SDK."""

from actian_vectorai.utils.validation import (
    validate_collection_name,
    validate_vector_dimension,
)

__all__ = [
    "validate_collection_name",
    "validate_vector_dimension",
]
