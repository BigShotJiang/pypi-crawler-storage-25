#
# Copyright (c) 2026 by Actian Corporation
# All rights reserved.
#
# THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE
# OF ACTIAN CORP.
# The copyright notice above does not evidence any actual or intended
# publication of such source code.
#

"""Generated gRPC proto stubs for Actian VectorAI DB services.

The server exposes 4 public gRPC services:
  - ActianVectorAI   : HealthCheck
  - Collections      : Collection CRUD, aliases, cluster info
  - Points           : Data CRUD, search, query, payload, field indexes
  - CollectionsExt   : VDE extensions — rebuild, compact, snapshots, stats
"""

# Common types (must be imported first — other modules depend on it)
from actian_vectorai.proto import actian_vectorai_common_pb2  # noqa: F401

# JSON value handling with int64 support
from actian_vectorai.proto import actian_vectorai_json_with_int_pb2  # noqa: F401

# Index types and configuration
from actian_vectorai.proto import actian_vectorai_index_pb2  # noqa: F401

# Message types
from actian_vectorai.proto import actian_vectorai_collections_pb2  # noqa: F401
from actian_vectorai.proto import actian_vectorai_points_pb2  # noqa: F401

# Health check
from actian_vectorai.proto import actian_vectorai_health_check_pb2  # noqa: F401
from actian_vectorai.proto import actian_vectorai_health_check_pb2_grpc  # noqa: F401

# Service stubs — ActianVectorAI
from actian_vectorai.proto import actian_vectorai_pb2  # noqa: F401
from actian_vectorai.proto import actian_vectorai_pb2_grpc  # noqa: F401

# Service stubs — Collections
from actian_vectorai.proto import actian_vectorai_collections_service_pb2  # noqa: F401
from actian_vectorai.proto import actian_vectorai_collections_service_pb2_grpc  # noqa: F401

# Service stubs — Points
from actian_vectorai.proto import actian_vectorai_points_service_pb2  # noqa: F401
from actian_vectorai.proto import actian_vectorai_points_service_pb2_grpc  # noqa: F401

# Service stubs — CollectionsExt (VDE extensions)
from actian_vectorai.proto import actian_vectorai_collections_ext_pb2  # noqa: F401
from actian_vectorai.proto import actian_vectorai_collections_ext_pb2_grpc  # noqa: F401

__all__ = [
    "actian_vectorai_common_pb2",
    "actian_vectorai_json_with_int_pb2",
    "actian_vectorai_index_pb2",
    "actian_vectorai_collections_pb2",
    "actian_vectorai_points_pb2",
    "actian_vectorai_health_check_pb2",
    "actian_vectorai_health_check_pb2_grpc",
    "actian_vectorai_pb2",
    "actian_vectorai_pb2_grpc",
    "actian_vectorai_collections_service_pb2",
    "actian_vectorai_collections_service_pb2_grpc",
    "actian_vectorai_points_service_pb2",
    "actian_vectorai_points_service_pb2_grpc",
    "actian_vectorai_collections_ext_pb2",
    "actian_vectorai_collections_ext_pb2_grpc",
]
