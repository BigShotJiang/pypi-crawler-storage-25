#
# Copyright (c) 2026 by Actian Corporation
# All rights reserved.
#
# THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE
# OF ACTIAN CORP.
# The copyright notice above does not evidence any actual or intended
# publication of such source code.
#

"""RFC 9110 compliant User-Agent string builder."""

from __future__ import annotations

import platform

__all__ = ["build_user_agent"]


def build_user_agent() -> str:
    """Build User-Agent string with SDK, OS, Python, and transport versions.

    Format::

        ActianVectorAI-PythonSDK/<version> (<OS> <arch>; Python <pyver>) grpcio/<grpcver>

    Example::

        ActianVectorAI-PythonSDK/0.1.0b2 (Linux x86_64; Python 3.12.1) grpcio/1.70.0
    """
    from actian_vectorai import __version__

    try:
        import grpc as _grpc

        grpc_ver = _grpc.__version__
    except ImportError:
        grpc_ver = "unknown"

    return (
        f"ActianVectorAI-PythonSDK/{__version__} "
        f"({platform.system()} {platform.machine()}; "
        f"Python {platform.python_version()}) "
        f"grpcio/{grpc_ver}"
    )
