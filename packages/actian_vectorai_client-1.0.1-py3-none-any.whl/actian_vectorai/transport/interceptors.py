#
# Copyright (c) 2026 by Actian Corporation
# All rights reserved.
#
# THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE
# OF ACTIAN CORP.
# The copyright notice above does not evidence any actual or intended
# publication of such source code.
#

"""gRPC client interceptors for authentication, retry, tracing, and logging.

All interceptors target the ``grpc.aio`` async API.  They are injected into
the :class:`~actian_vectorai.transport.pool.ConnectionPool` at construction
time and applied to every RPC call automatically.
"""

from __future__ import annotations

import asyncio
import contextvars
import logging
import random
import time
import uuid
from collections.abc import Awaitable, Callable, Sequence
from typing import Any

import grpc
import grpc.aio

_Continuation = Callable[..., Any]

logger = logging.getLogger(__name__)

# Request-scoped correlation ID — flows across async/sync boundaries
# via contextvars. Set automatically by TracingInterceptor; read by
# logging / error handlers for per-request log correlation.
request_id_var: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "vectorai_request_id", default=None,
)


# ============================================================================
#  Auth interceptor
# ============================================================================


class AuthInterceptor(grpc.aio.UnaryUnaryClientInterceptor):
    """Injects auth credentials into every unary-unary gRPC call.

    Sends credentials in two forms simultaneously:

    1. ``api-key: <raw_token>`` — preferred; token sent verbatim
    2. ``authorization: Bearer <raw_token>`` — fallback; ``Bearer `` prefix stripped server-side

    Backward-compatible deployments that only inspect ``authorization``
    continue to work since both headers carry the same value.

    Supports either a static token *or* a dynamic async token provider
    (e.g. for short-lived OAuth / JWT tokens).

    Example::

        # Static API key
        AuthInterceptor(token="vdai_abc123")

        # Dynamic provider (refreshable JWT / rotating keys)
        AuthInterceptor(token_provider=my_async_refresh_fn)
    """

    __slots__ = ("_token", "_token_provider")

    def __init__(
        self,
        token: str | None = None,
        token_provider: Callable[[], Awaitable[str]] | None = None,
    ) -> None:
        if token and token_provider:
            raise ValueError("Specify either token or token_provider, not both")
        self._token = token
        self._token_provider = token_provider

    async def intercept_unary_unary(
        self,
        continuation: _Continuation,
        client_call_details: grpc.aio.ClientCallDetails,
        request: Any,
    ) -> Any:
        if self._token:
            raw_token = self._token
        elif self._token_provider:
            raw_token = await self._token_provider()
        else:
            return await continuation(client_call_details, request)

        # Strip any accidental "Bearer " prefix — we manage it ourselves
        if raw_token.lower().startswith("bearer "):
            raw_token = raw_token[7:]

        metadata = list(client_call_details.metadata or [])
        # Primary: api-key header (server checks this first)
        metadata.append(("api-key", raw_token))
        # Fallback: authorization header for backward compatibility
        metadata.append(("authorization", f"Bearer {raw_token}"))

        new_details = grpc.aio.ClientCallDetails(
            method=client_call_details.method,
            timeout=client_call_details.timeout,
            metadata=metadata,
            credentials=client_call_details.credentials,
            wait_for_ready=client_call_details.wait_for_ready,
        )
        return await continuation(new_details, request)


# ============================================================================
#  Retry interceptor
# ============================================================================

# Default set of gRPC codes that are safe to retry.
_RETRYABLE_CODES = frozenset(
    {
        grpc.StatusCode.UNAVAILABLE,
        grpc.StatusCode.RESOURCE_EXHAUSTED,
        grpc.StatusCode.ABORTED,
    }
)


class RetryInterceptor(grpc.aio.UnaryUnaryClientInterceptor):
    """Retries transient failures with exponential back-off.

    Only retries on status codes in *retryable_codes*
    (default: UNAVAILABLE, RESOURCE_EXHAUSTED, ABORTED).
    """

    __slots__ = (
        "_max_retries",
        "_initial_backoff_ms",
        "_max_backoff_ms",
        "_multiplier",
        "_retryable_codes",
    )

    def __init__(
        self,
        max_retries: int = 3,
        initial_backoff_ms: int = 100,
        max_backoff_ms: int = 5_000,
        backoff_multiplier: float = 2.0,
        retryable_codes: frozenset[grpc.StatusCode] | None = None,
    ) -> None:
        self._max_retries = max_retries
        self._initial_backoff_ms = initial_backoff_ms
        self._max_backoff_ms = max_backoff_ms
        self._multiplier = backoff_multiplier
        self._retryable_codes = retryable_codes or _RETRYABLE_CODES

    async def intercept_unary_unary(
        self,
        continuation: _Continuation,
        client_call_details: grpc.aio.ClientCallDetails,
        request: Any,
    ) -> Any:
        backoff: float = self._initial_backoff_ms
        last_err: grpc.RpcError | None = None

        for attempt in range(self._max_retries + 1):
            try:
                return await continuation(client_call_details, request)
            except grpc.RpcError as exc:
                if exc.code() not in self._retryable_codes:
                    raise
                # Capacity / licence limit errors are deterministic —
                # retrying will always fail.  Re-raise immediately.
                details_lower = (exc.details() or "").lower()
                if "vector count limit" in details_lower or "limit exceeded" in details_lower:
                    raise
                last_err = exc
                if attempt < self._max_retries:
                    jitter = random.uniform(0.75, 1.25)
                    sleep_ms = min(backoff * jitter, self._max_backoff_ms)
                    logger.debug(
                        "Retry %d/%d after %.0fms: %s",
                        attempt + 1,
                        self._max_retries,
                        sleep_ms,
                        exc.code(),
                    )
                    await asyncio.sleep(sleep_ms / 1000.0)
                    backoff *= self._multiplier

        raise last_err  # type: ignore[misc]


# ============================================================================
#  Tracing interceptor
# ============================================================================


class TracingInterceptor(grpc.aio.UnaryUnaryClientInterceptor):
    """Stamps every unary-unary call with ``x-request-id`` and
    ``x-request-timestamp`` metadata for distributed tracing / log
    correlation.
    """

    async def intercept_unary_unary(
        self,
        continuation: _Continuation,
        client_call_details: grpc.aio.ClientCallDetails,
        request: Any,
    ) -> Any:
        rid = str(uuid.uuid4())
        request_id_var.set(rid)

        metadata = list(client_call_details.metadata or [])
        metadata.append(("x-request-id", rid))
        metadata.append(("x-request-timestamp", str(int(time.time() * 1000))))

        new_details = grpc.aio.ClientCallDetails(
            method=client_call_details.method,
            timeout=client_call_details.timeout,
            metadata=metadata,
            credentials=client_call_details.credentials,
            wait_for_ready=client_call_details.wait_for_ready,
        )
        return await continuation(new_details, request)


# ============================================================================
#  Logging interceptor
# ============================================================================


class LoggingInterceptor(grpc.aio.UnaryUnaryClientInterceptor):
    """Logs RPC method, latency, and errors at a configurable level.

    Useful for local debugging — not recommended for high-throughput
    production use.
    """

    __slots__ = ("_level",)

    def __init__(self, level: int = logging.DEBUG) -> None:
        self._level = level

    async def intercept_unary_unary(
        self,
        continuation: _Continuation,
        client_call_details: grpc.aio.ClientCallDetails,
        request: Any,
    ) -> Any:
        method = client_call_details.method
        t0 = time.monotonic()
        try:
            response = await continuation(client_call_details, request)
            dt = (time.monotonic() - t0) * 1000
            logger.log(self._level, "gRPC OK  %s (%.1fms)", method, dt)
            return response
        except grpc.RpcError as exc:
            dt = (time.monotonic() - t0) * 1000
            logger.warning("gRPC ERR %s %s: %s (%.1fms)", method, exc.code(), exc.details(), dt)
            raise


# ============================================================================
#  Metadata interceptor
# ============================================================================


class MetadataInterceptor(grpc.aio.UnaryUnaryClientInterceptor):
    """Injects a static set of key-value metadata into every call.

    Useful for forwarding tenant IDs, correlation tokens, feature flags, etc.

    Example::

        MetadataInterceptor([("x-tenant-id", "acme"), ("x-env", "prod")])
    """

    __slots__ = ("_metadata",)

    def __init__(self, metadata: Sequence[tuple[str, str]]) -> None:
        self._metadata = list(metadata)

    async def intercept_unary_unary(
        self,
        continuation: _Continuation,
        client_call_details: grpc.aio.ClientCallDetails,
        request: Any,
    ) -> Any:
        existing = list(client_call_details.metadata or [])
        existing.extend(self._metadata)

        new_details = grpc.aio.ClientCallDetails(
            method=client_call_details.method,
            timeout=client_call_details.timeout,
            metadata=existing,
            credentials=client_call_details.credentials,
            wait_for_ready=client_call_details.wait_for_ready,
        )
        return await continuation(new_details, request)


# ============================================================================
#  User-Agent interceptor
# ============================================================================


class UserAgentInterceptor(grpc.aio.UnaryUnaryClientInterceptor):
    """Injects RFC 9110 compliant User-Agent into every RPC.

    Format::

        ActianVectorAI-PythonSDK/<version> (<OS> <arch>; Python <pyver>) grpcio/<grpcver>
    """

    __slots__ = ("_user_agent",)

    def __init__(self) -> None:
        import platform

        import grpc as _grpc

        from actian_vectorai import __version__

        self._user_agent = (
            f"ActianVectorAI-PythonSDK/{__version__} "
            f"({platform.system()} {platform.machine()}; "
            f"Python {platform.python_version()}) "
            f"grpcio/{_grpc.__version__}"
        )

    async def intercept_unary_unary(
        self,
        continuation: _Continuation,
        client_call_details: grpc.aio.ClientCallDetails,
        request: Any,
    ) -> Any:
        existing = list(client_call_details.metadata or [])
        existing.append(("user-agent", self._user_agent))

        new_details = grpc.aio.ClientCallDetails(
            method=client_call_details.method,
            timeout=client_call_details.timeout,
            metadata=existing,
            credentials=client_call_details.credentials,
            wait_for_ready=client_call_details.wait_for_ready,
        )
        return await continuation(new_details, request)


# ============================================================================
#  Circuit breaker interceptor
# ============================================================================

# gRPC codes that should trip the circuit breaker
_CIRCUIT_BREAKER_TRIP_CODES = frozenset(
    {
        grpc.StatusCode.UNAVAILABLE,
        grpc.StatusCode.RESOURCE_EXHAUSTED,
        grpc.StatusCode.INTERNAL,
    }
)


class CircuitBreakerInterceptor(grpc.aio.UnaryUnaryClientInterceptor):
    """gRPC interceptor that enforces circuit breaker state.

    Checks the breaker before each call and records success/failure
    to track consecutive errors.
    """

    __slots__ = ("_breaker",)

    def __init__(self, breaker: Any) -> None:
        self._breaker = breaker

    async def intercept_unary_unary(
        self,
        continuation: _Continuation,
        client_call_details: grpc.aio.ClientCallDetails,
        request: Any,
    ) -> Any:
        self._breaker.ensure_closed()
        try:
            result = await continuation(client_call_details, request)
            self._breaker.record_success()
            return result
        except grpc.RpcError as exc:
            if exc.code() in _CIRCUIT_BREAKER_TRIP_CODES:
                self._breaker.record_failure()
            raise
