#
# Copyright (c) 2026 by Actian Corporation
# All rights reserved.
#
# THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE
# OF ACTIAN CORP.
# The copyright notice above does not evidence any actual or intended
# publication of such source code.
#

"""REST fallback transport using httpx.

Used when gRPC is unavailable (edge proxies, firewalls, etc.).
The server exposes a REST API on port 6573 (oatpp).

Standard response envelope::

    {"status": "ok", "time": 0.001, "result": ...}
"""

from __future__ import annotations

import logging
from typing import Any

import httpx

from actian_vectorai.exceptions import from_http_error

__all__ = ["RESTTransport"]

logger = logging.getLogger("actian_vectorai.transport.rest")


class RESTTransport:
    """httpx-based REST transport for Actian VectorAI DB.

    Parameters
    ----------
    base_url:
        REST API base URL (e.g., ``http://localhost:6573``).
    timeout:
        Default request timeout in seconds.
    headers:
        Static headers injected into every request.
    api_key:
        API key for authentication.  Sends both ``api-key: <token>``
        (server preference) and
        ``Authorization: Bearer <token>`` (backward compat) headers.
    access_token:
        Alternate parameter name for ``api_key``; both are accepted.
        ``api_key`` takes precedence if both are given.
    max_connections:
        Maximum number of connections in the pool.
    max_keepalive_connections:
        Maximum number of idle keep-alive connections.
    """

    def __init__(
        self,
        base_url: str | None = None,
        *,
        timeout: float = 30.0,
        headers: dict[str, str] | None = None,
        api_key: str | None = None,
        access_token: str | None = None,  # backward-compat alias
        max_connections: int = 100,
        max_keepalive_connections: int = 20,
    ) -> None:
        if base_url is None:
            from actian_vectorai.config import settings

            base_url = settings.rest_url
        _headers = dict(headers or {})
        # Resolve credential: explicit api_key > access_token alias > settings
        token = api_key or access_token
        if token is None:
            from actian_vectorai.config import settings as _s

            token = _s.api_key
        if token:
            # Prefer api-key header (server checks first); also send Bearer fallback
            _headers.setdefault("api-key", token)
            _headers.setdefault("Authorization", f"Bearer {token}")
        limits = httpx.Limits(
            max_connections=max_connections,
            max_keepalive_connections=max_keepalive_connections,
        )
        self._client = httpx.AsyncClient(
            base_url=base_url,
            limits=limits,
            timeout=httpx.Timeout(timeout),
            headers=_headers,
        )
        self._base_url = base_url

    # ── Internal request helper ───────────────────────────────────

    async def _request(
        self,
        method: str,
        path: str,
        *,
        json: Any = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        timeout: float | None = None,
        operation: str | None = None,
    ) -> Any:
        """Send an HTTP request and return the parsed result.

        Per-call *headers* are merged over the client-level defaults.
        Raises the appropriate VectorAIError for non-2xx responses.
        """
        kwargs: dict[str, Any] = {}
        if json is not None:
            kwargs["json"] = json
        if params is not None:
            kwargs["params"] = params
        if headers is not None:
            kwargs["headers"] = headers
        if timeout is not None:
            kwargs["timeout"] = timeout

        try:
            resp = await self._client.request(method, path, **kwargs)
        except httpx.ConnectError as exc:
            from actian_vectorai.exceptions import ConnectionRefusedError

            raise ConnectionRefusedError(self._base_url, details=str(exc)) from exc
        except httpx.TimeoutException as exc:
            from actian_vectorai.exceptions import TimeoutError

            raise TimeoutError(operation or "request") from exc

        if resp.status_code >= 400:
            try:
                body = resp.json()
            except Exception:
                body = resp.text
            raise from_http_error(
                resp.status_code,
                body=body,
                headers=dict(resp.headers),
                operation=operation,
            )

        try:
            data = resp.json()
        except Exception:
            # Server returned non-JSON on a 2xx — return raw text as fallback.
            return {"_raw": resp.text}
        return data

    # ── Generic helpers (used by AuthNamespace and other namespaces) ─────

    async def get(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        timeout: float | None = None,
    ) -> Any:
        """Send a ``GET`` request and return the parsed response body."""
        return await self._request(
            "GET", path, params=params, headers=headers, timeout=timeout, operation=path
        )

    async def post(
        self,
        path: str,
        *,
        json: Any = None,
        headers: dict[str, str] | None = None,
        timeout: float | None = None,
    ) -> Any:
        """Send a ``POST`` request and return the parsed response body."""
        return await self._request(
            "POST", path, json=json, headers=headers, timeout=timeout, operation=path
        )

    async def patch(
        self,
        path: str,
        *,
        json: Any = None,
        headers: dict[str, str] | None = None,
        timeout: float | None = None,
    ) -> Any:
        """Send a ``PATCH`` request and return the parsed response body."""
        return await self._request(
            "PATCH", path, json=json, headers=headers, timeout=timeout, operation=path
        )

    async def delete(
        self,
        path: str,
        *,
        headers: dict[str, str] | None = None,
        timeout: float | None = None,
    ) -> Any:
        """Send a ``DELETE`` request and return the parsed response body."""
        return await self._request(
            "DELETE", path, headers=headers, timeout=timeout, operation=path
        )

    # ── Health ────────────────────────────────────────────────────

    async def health_check(self, *, timeout: float | None = None) -> dict[str, Any]:
        """Check server health via ``GET /``."""
        return await self._request("GET", "/", timeout=timeout, operation="health_check")

    # ── Collections ───────────────────────────────────────────────

    async def collections_list(self, *, timeout: float | None = None) -> list[str]:
        """List all collections via ``GET /collections``."""
        data = await self._request(
            "GET", "/collections", timeout=timeout, operation="list_collections"
        )
        result = data.get("result", {})
        collections = result.get("collections", [])
        return sorted(c.get("name", "") for c in collections)

    async def collections_create(
        self,
        name: str,
        config: dict[str, Any],
        *,
        timeout: float | None = None,
    ) -> bool:
        """Create a collection via ``PUT /collections/{name}``."""
        data = await self._request(
            "PUT",
            f"/collections/{name}",
            json=config,
            timeout=timeout,
            operation="create_collection",
        )
        return data.get("result", False)

    async def collections_get(
        self,
        name: str,
        *,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Get collection info via ``GET /collections/{name}``."""
        data = await self._request(
            "GET",
            f"/collections/{name}",
            timeout=timeout,
            operation="get_collection",
        )
        return data.get("result", {})

    async def collections_delete(
        self,
        name: str,
        *,
        timeout: float | None = None,
    ) -> bool:
        """Delete a collection via ``DELETE /collections/{name}``."""
        data = await self._request(
            "DELETE",
            f"/collections/{name}",
            json={},
            timeout=timeout,
            operation="delete_collection",
        )
        return data.get("result", False)

    async def collections_exists(
        self,
        name: str,
        *,
        timeout: float | None = None,
    ) -> bool:
        """Check if collection exists via ``GET /collections/{name}/exists``."""
        data = await self._request(
            "GET",
            f"/collections/{name}/exists",
            timeout=timeout,
            operation="collection_exists",
        )
        result = data.get("result", {})
        return result.get("exists", False)

    async def collections_update(
        self,
        name: str,
        config: dict[str, Any],
        *,
        timeout: float | None = None,
    ) -> bool:
        """Update collection via ``PATCH /collections/{name}``."""
        data = await self._request(
            "PATCH",
            f"/collections/{name}",
            json=config,
            timeout=timeout,
            operation="update_collection",
        )
        return data.get("result", False)

    # ── Points ────────────────────────────────────────────────────

    async def points_upsert(
        self,
        collection_name: str,
        points: list[dict[str, Any]],
        *,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Upsert points via ``PUT /collections/{name}/points``."""
        data = await self._request(
            "PUT",
            f"/collections/{collection_name}/points",
            json={"points": points},
            timeout=timeout,
            operation="upsert",
        )
        return data.get("result", {})

    async def points_get(
        self,
        collection_name: str,
        ids: list[int | str],
        *,
        with_payload: bool = True,
        with_vector: bool = False,
        timeout: float | None = None,
    ) -> list[dict[str, Any]]:
        """Get points by IDs via ``POST /collections/{name}/points``."""
        data = await self._request(
            "POST",
            f"/collections/{collection_name}/points",
            json={
                "ids": ids,
                "with_payload": with_payload,
                "with_vector": with_vector,
            },
            timeout=timeout,
            operation="get",
        )
        return data.get("result", [])

    async def points_delete(
        self,
        collection_name: str,
        *,
        ids: list[int | str] | None = None,
        filter: dict[str, Any] | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Delete points via ``POST /collections/{name}/points/delete``."""
        body: dict[str, Any] = {}
        if ids is not None:
            body["points"] = ids
        if filter is not None:
            body["filter"] = filter
        data = await self._request(
            "POST",
            f"/collections/{collection_name}/points/delete",
            json=body,
            timeout=timeout,
            operation="delete",
        )
        return data.get("result", {})

    async def points_search(
        self,
        collection_name: str,
        vector: list[float],
        limit: int,
        *,
        filter: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        with_payload: bool = True,
        with_vector: bool = False,
        score_threshold: float | None = None,
        offset: int | None = None,
        timeout: float | None = None,
    ) -> list[dict[str, Any]]:
        """Search points via ``POST /collections/{name}/points/search``."""
        body: dict[str, Any] = {
            "vector": vector,
            "limit": limit,
            "with_payload": with_payload,
            "with_vector": with_vector,
        }
        if filter is not None:
            body["filter"] = filter
        if params is not None:
            body["params"] = params
        if score_threshold is not None:
            body["score_threshold"] = score_threshold
        if offset is not None:
            body["offset"] = offset

        data = await self._request(
            "POST",
            f"/collections/{collection_name}/points/search",
            json=body,
            timeout=timeout,
            operation="search",
        )
        return data.get("result", [])

    async def points_query(
        self,
        collection_name: str,
        query: dict[str, Any],
        *,
        timeout: float | None = None,
    ) -> list[dict[str, Any]]:
        """Query points via ``POST /collections/{name}/points/query``."""
        data = await self._request(
            "POST",
            f"/collections/{collection_name}/points/query",
            json=query,
            timeout=timeout,
            operation="query",
        )
        return data.get("result", [])

    async def points_count(
        self,
        collection_name: str,
        *,
        filter: dict[str, Any] | None = None,
        exact: bool | None = None,
        timeout: float | None = None,
    ) -> int:
        """Count points via ``POST /collections/{name}/points/count``."""
        body: dict[str, Any] = {}
        if filter is not None:
            body["filter"] = filter
        if exact is not None:
            body["exact"] = exact
        data = await self._request(
            "POST",
            f"/collections/{collection_name}/points/count",
            json=body,
            timeout=timeout,
            operation="count",
        )
        result = data.get("result", {})
        return result.get("count", 0)

    async def points_set_payload(
        self,
        collection_name: str,
        payload: dict[str, Any],
        *,
        ids: list[int | str] | None = None,
        filter: dict[str, Any] | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Set (merge) payload via ``POST /collections/{name}/points/payload``."""
        body: dict[str, Any] = {"payload": payload}
        if ids is not None:
            body["points"] = ids
        if filter is not None:
            body["filter"] = filter
        data = await self._request(
            "POST",
            f"/collections/{collection_name}/points/payload",
            json=body,
            timeout=timeout,
            operation="set_payload",
        )
        return data.get("result", {})

    async def points_overwrite_payload(
        self,
        collection_name: str,
        payload: dict[str, Any],
        *,
        ids: list[int | str] | None = None,
        filter: dict[str, Any] | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Overwrite payload via ``PUT /collections/{name}/points/payload``."""
        body: dict[str, Any] = {"payload": payload}
        if ids is not None:
            body["points"] = ids
        if filter is not None:
            body["filter"] = filter
        data = await self._request(
            "PUT",
            f"/collections/{collection_name}/points/payload",
            json=body,
            timeout=timeout,
            operation="overwrite_payload",
        )
        return data.get("result", {})

    async def points_delete_payload(
        self,
        collection_name: str,
        keys: list[str],
        *,
        ids: list[int | str] | None = None,
        filter: dict[str, Any] | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Delete payload keys via ``POST /collections/{name}/points/payload/delete``."""
        body: dict[str, Any] = {"keys": keys}
        if ids is not None:
            body["points"] = ids
        if filter is not None:
            body["filter"] = filter
        data = await self._request(
            "POST",
            f"/collections/{collection_name}/points/payload/delete",
            json=body,
            timeout=timeout,
            operation="delete_payload",
        )
        return data.get("result", {})

    async def points_clear_payload(
        self,
        collection_name: str,
        *,
        ids: list[int | str] | None = None,
        filter: dict[str, Any] | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Clear all payload via ``POST /collections/{name}/points/payload/clear``."""
        body: dict[str, Any] = {}
        if ids is not None:
            body["points"] = ids
        if filter is not None:
            body["filter"] = filter
        data = await self._request(
            "POST",
            f"/collections/{collection_name}/points/payload/clear",
            json=body,
            timeout=timeout,
            operation="clear_payload",
        )
        return data.get("result", {})

    async def points_update_vectors(
        self,
        collection_name: str,
        points: list[dict[str, Any]],
        *,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Update vectors via ``PUT /collections/{name}/points/vectors``."""
        data = await self._request(
            "PUT",
            f"/collections/{collection_name}/points/vectors",
            json={"points": points},
            timeout=timeout,
            operation="update_vectors",
        )
        return data.get("result", {})

    async def points_search_batch(
        self,
        collection_name: str,
        searches: list[dict[str, Any]],
        *,
        timeout: float | None = None,
    ) -> list[list[dict[str, Any]]]:
        """Batch search via ``POST /collections/{name}/points/search/batch``."""
        data = await self._request(
            "POST",
            f"/collections/{collection_name}/points/search/batch",
            json={"searches": searches},
            timeout=timeout,
            operation="search_batch",
        )
        return data.get("result", [])

    async def points_query_batch(
        self,
        collection_name: str,
        queries: list[dict[str, Any]],
        *,
        timeout: float | None = None,
    ) -> list[list[dict[str, Any]]]:
        """Batch query via ``POST /collections/{name}/points/query/batch``."""
        data = await self._request(
            "POST",
            f"/collections/{collection_name}/points/query/batch",
            json={"queries": queries},
            timeout=timeout,
            operation="query_batch",
        )
        return data.get("result", [])

    # ── Lifecycle ─────────────────────────────────────────────────

    async def close(self) -> None:
        """Close the underlying httpx client."""
        await self._client.aclose()

    async def aclose(self) -> None:
        """Alias for :meth:`close` (matches httpx / asyncio conventions)."""
        await self.close()

    async def __aenter__(self) -> RESTTransport:
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.close()

    def __del__(self) -> None:
        try:
            if hasattr(self, "_client") and not self._client.is_closed:
                # Best-effort warning — can't await in __del__
                import warnings

                warnings.warn(
                    f"Unclosed {self!r}. Use 'async with' or call close().",
                    ResourceWarning,
                    stacklevel=2,
                )
        except Exception:
            pass

    def __repr__(self) -> str:
        return f"RESTTransport(base_url={self._base_url!r})"
