#
# Copyright (c) 2026 by Actian Corporation
# All rights reserved.
#
# THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE
# OF ACTIAN CORP.
# The copyright notice above does not evidence any actual or intended
# publication of such source code.
#

"""Transport sub-package — connection pooling, TLS, gRPC interceptors, and REST."""

from actian_vectorai.transport.interceptors import (
    AuthInterceptor,
    CircuitBreakerInterceptor,
    LoggingInterceptor,
    MetadataInterceptor,
    RetryInterceptor,
    TracingInterceptor,
    UserAgentInterceptor,
)
from actian_vectorai.transport.pool import (
    ConnectionPool,
    PoolConfig,
    create_credentials_from_files,
    create_ssl_credentials,
)
from actian_vectorai.transport.rest import RESTTransport

__all__ = [
    # Pool
    "ConnectionPool",
    "PoolConfig",
    # TLS
    "create_ssl_credentials",
    "create_credentials_from_files",
    # Interceptors
    "AuthInterceptor",
    "RetryInterceptor",
    "TracingInterceptor",
    "LoggingInterceptor",
    "MetadataInterceptor",
    "UserAgentInterceptor",
    "CircuitBreakerInterceptor",
    # REST
    "RESTTransport",
]
