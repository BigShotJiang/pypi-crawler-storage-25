#
# Copyright (c) 2026 by Actian Corporation
# All rights reserved.
#
# THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE
# OF ACTIAN CORP.
# The copyright notice above does not evidence any actual or intended
# publication of such source code.
#

"""Type-safe Filter DSL for building search queries.

Provides a fluent builder pattern to construct filter expressions that
compile directly to protobuf ``Filter`` objects.  This catches structural
errors at build time rather than getting "Bad Request" from the server.

Two usage styles are supported:

**Fluent builder** (recommended for most use-cases)::

    from actian_vectorai.filters import Field, FilterBuilder

    f = (
        FilterBuilder()
        .must(Field("category").eq("electronics"))
        .must(Field("price").lt(1000.0))
        .should(Field("in_stock").eq(True))
        .must_not(Field("discontinued").eq(True))
    )
    proto = f.to_proto()

**Direct model construction** (for advanced / dynamic use-cases)::

    from actian_vectorai.models.common import (
        Condition, FieldCondition, Filter, Match,
    )

    f = Filter(must=[
        Condition(field=FieldCondition(key="category", match=Match(keyword="electronics"))),
    ])
    proto = f.to_proto()

**Operator composition**::

    a = Field("color").eq("red")
    b = Field("price").lt(50.0)
    combined = a & b            # → Filter(must=[a, b])
    either   = a | b            # → Filter(should=[a, b])
    negated  = ~a               # → Filter(must_not=[a])
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Sequence

from google.protobuf import timestamp_pb2

from actian_vectorai.models.common import (
    Condition,
    DatetimeRange,
    FieldCondition,
    Filter,
    GeoBoundingBox,
    GeoLineString,
    GeoPoint,
    GeoPolygon,
    GeoRadius,
    HasIdCondition,
    HasVectorCondition,
    IsEmptyCondition,
    IsNullCondition,
    Match,
    MinShould,
    NestedCondition,
    PointIdValue,
    Range,
    ValuesCount,
)

# ---------------------------------------------------------------------------
#  Field builder — produces individual Condition objects
# ---------------------------------------------------------------------------

class Field:
    """Builder for field-level filter conditions.

    Each method returns a :class:`Condition` that can be passed to
    :class:`FilterBuilder`, combined with ``&`` / ``|`` / ``~`` operators,
    or used directly in a :class:`Filter` model.

    Example::

        Field("price").gt(100.0)
        Field("category").eq("books")
        Field("tags").any_of(["python", "rust"])
        Field("location").geo_radius(lat=40.7, lon=-74.0, radius=5000.0)
    """

    __slots__ = ("_key",)

    def __init__(self, key: str) -> None:
        if not isinstance(key, str):
            raise TypeError(f"Field key must be a string, got {type(key).__name__!r}")
        if not key.strip():
            raise ValueError("Field key cannot be empty or whitespace")
        self._key = key

    # -- Match conditions ---------------------------------------------------

    def eq(self, value: str | int | bool) -> Condition:
        """Exact equality match.

        Dispatches to the correct ``Match`` variant based on *value* type:
        - ``str``  → ``keyword``
        - ``int``  → ``integer``
        - ``bool`` → ``boolean``
        """
        return Condition(field=FieldCondition(key=self._key, match=_match(value)))

    def text(self, value: str) -> Condition:
        """Full-text substring match."""
        return Condition(field=FieldCondition(key=self._key, match=Match(text=value)))

    def any_of(self, values: Sequence[str | int]) -> Condition:
        """Match any value in *values* (IN semantics).

        - ``list[str]`` → ``keywords``
        - ``list[int]`` → ``integers``
        """
        return Condition(field=FieldCondition(key=self._key, match=_match_multi(values)))

    def except_of(self, values: Sequence[str | int]) -> Condition:
        """Match anything *except* values in the list (NOT IN semantics).

        - ``list[str]`` → ``except_keywords``
        - ``list[int]`` → ``except_integers``
        """
        return Condition(field=FieldCondition(key=self._key, match=_match_except(values)))

    # -- Range conditions ---------------------------------------------------

    def gt(self, value: float) -> Condition:
        """Greater than *value*."""
        return Condition(field=FieldCondition(key=self._key, range=Range(gt=value)))

    def gte(self, value: float) -> Condition:
        """Greater than or equal to *value*."""
        return Condition(field=FieldCondition(key=self._key, range=Range(gte=value)))

    def lt(self, value: float) -> Condition:
        """Less than *value*."""
        return Condition(field=FieldCondition(key=self._key, range=Range(lt=value)))

    def lte(self, value: float) -> Condition:
        """Less than or equal to *value*."""
        return Condition(field=FieldCondition(key=self._key, range=Range(lte=value)))

    def between(
        self,
        lower: float,
        upper: float,
        *,
        inclusive: bool = True,
    ) -> Condition:
        """Value within [lower, upper] (inclusive) or (lower, upper) (exclusive)."""
        if lower > upper:
            raise ValueError(f"lower bound ({lower}) must be <= upper bound ({upper})")
        if inclusive:
            return Condition(field=FieldCondition(key=self._key, range=Range(gte=lower, lte=upper)))
        return Condition(field=FieldCondition(key=self._key, range=Range(gt=lower, lt=upper)))

    def range(
        self,
        *,
        gt: float | None = None,
        gte: float | None = None,
        lt: float | None = None,
        lte: float | None = None,
    ) -> Condition:
        """Arbitrary range with any combination of bounds."""
        if gt is None and gte is None and lt is None and lte is None:
            raise ValueError("At least one bound must be specified")
        # Validate non-overlapping bounds
        lower = gt if gt is not None else gte
        upper = lt if lt is not None else lte
        if lower is not None and upper is not None and lower > upper:
            raise ValueError(
                f"Lower bound ({lower}) must not exceed upper bound ({upper})"
            )
        return Condition(
            field=FieldCondition(key=self._key, range=Range(gt=gt, gte=gte, lt=lt, lte=lte))
        )

    # -- Datetime range conditions ------------------------------------------

    def datetime_gt(self, value: datetime) -> Condition:
        """Datetime greater than *value*."""
        ts = _dt_to_ts(value)
        return Condition(field=FieldCondition(key=self._key, datetime_range=DatetimeRange(gt=ts)))

    def datetime_gte(self, value: datetime) -> Condition:
        """Datetime greater than or equal to *value*."""
        ts = _dt_to_ts(value)
        return Condition(field=FieldCondition(key=self._key, datetime_range=DatetimeRange(gte=ts)))

    def datetime_lt(self, value: datetime) -> Condition:
        """Datetime less than *value*."""
        ts = _dt_to_ts(value)
        return Condition(field=FieldCondition(key=self._key, datetime_range=DatetimeRange(lt=ts)))

    def datetime_lte(self, value: datetime) -> Condition:
        """Datetime less than or equal to *value*."""
        ts = _dt_to_ts(value)
        return Condition(field=FieldCondition(key=self._key, datetime_range=DatetimeRange(lte=ts)))

    def datetime_between(
        self,
        lower: datetime,
        upper: datetime,
        *,
        inclusive: bool = True,
    ) -> Condition:
        """Datetime within the given range."""
        if lower > upper:
            raise ValueError(f"lower datetime ({lower}) must be <= upper datetime ({upper})")
        if inclusive:
            return Condition(
                field=FieldCondition(
                    key=self._key,
                    datetime_range=DatetimeRange(gte=_dt_to_ts(lower), lte=_dt_to_ts(upper)),
                )
            )
        return Condition(
            field=FieldCondition(
                key=self._key,
                datetime_range=DatetimeRange(gt=_dt_to_ts(lower), lt=_dt_to_ts(upper)),
            )
        )

    # -- Values count conditions --------------------------------------------

    def values_count(
        self,
        *,
        lt: int | None = None,
        gt: int | None = None,
        gte: int | None = None,
        lte: int | None = None,
    ) -> Condition:
        """Filter by the count of values in an array payload field."""
        if lt is None and gt is None and gte is None and lte is None:
            raise ValueError("At least one bound must be specified")
        return Condition(
            field=FieldCondition(
                key=self._key,
                values_count=ValuesCount(lt=lt, gt=gt, gte=gte, lte=lte),
            )
        )

    # -- Geo conditions -----------------------------------------------------

    def geo_bounding_box(
        self,
        top_left: tuple[float, float],
        bottom_right: tuple[float, float],
    ) -> Condition:
        """Points within a geographic bounding box.

        Args:
            top_left: (latitude, longitude) of the top-left corner.
            bottom_right: (latitude, longitude) of the bottom-right corner.
        """
        return Condition(
            field=FieldCondition(
                key=self._key,
                geo_bounding_box=GeoBoundingBox(
                    top_left=GeoPoint(lat=top_left[0], lon=top_left[1]),
                    bottom_right=GeoPoint(lat=bottom_right[0], lon=bottom_right[1]),
                ),
            )
        )

    def geo_radius(
        self,
        lat: float,
        lon: float,
        radius: float,
    ) -> Condition:
        """Points within a geographic radius (in metres).

        Args:
            lat:    Centre latitude.
            lon:    Centre longitude.
            radius: Radius in metres.
        """
        return Condition(
            field=FieldCondition(
                key=self._key,
                geo_radius=GeoRadius(
                    center=GeoPoint(lat=lat, lon=lon),
                    radius=radius,
                ),
            )
        )

    def geo_polygon(self, exterior: list[tuple[float, float]]) -> Condition:
        """Points within a geographic polygon.

        Args:
            exterior: List of (lat, lon) vertices forming the exterior ring;
                      the ring will be auto-closed if necessary.
        """
        return Condition(
            field=FieldCondition(
                key=self._key,
                geo_polygon=GeoPolygon(
                    exterior=GeoLineString(
                        points=[GeoPoint(lat=p[0], lon=p[1]) for p in exterior],
                    ),
                ),
            )
        )

# ---------------------------------------------------------------------------
#  Standalone condition factories
# ---------------------------------------------------------------------------

def is_empty(key: str) -> Condition:
    """Condition: field *key* has an empty array value.

    .. note::

       The server also matches points where the field is **missing**
       (absent from the payload) or explicitly ``null``.  If you need to
       match *only* points with an empty array ``[]`` (excluding missing
       / null fields), combine with ``must_not(is_null(...))``::

           FilterBuilder()
               .must(is_empty("tags"))
               .must_not(is_null("tags"))
    """
    return Condition(is_empty=IsEmptyCondition(key=key))

def is_null(key: str) -> Condition:
    """Condition: field *key* is explicitly ``null`` or missing.

    Use this to detect points where a payload field was never set.
    """
    return Condition(is_null=IsNullCondition(key=key))

def has_id(ids: Sequence[PointIdValue]) -> Condition:
    """Condition: point ID is in *ids*.

    Accepts raw ``int`` or ``str`` values — they are automatically wrapped in
    :class:`PointId`.
    """
    from actian_vectorai.models.common import PointId

    wrapped: list[PointId] = []
    for raw in ids:
        if isinstance(raw, int):
            wrapped.append(PointId(num=raw))
        elif isinstance(raw, str):
            wrapped.append(PointId(uuid=raw))
        elif isinstance(raw, PointId):
            wrapped.append(raw)
        else:
            raise TypeError(f"Unsupported id type: {type(raw)}")
    return Condition(has_id=HasIdCondition(has_id=wrapped))

def has_vector(name: str) -> Condition:
    """Condition: point has a vector named *name*."""
    return Condition(has_vector=HasVectorCondition(has_vector=name))

def nested(key: str, filter_: Filter | "FilterBuilder") -> Condition:
    """Condition: nested object at *key* matches *filter_*.

    Args:
        key: Path to the nested object array (e.g. ``"reviews"``).
        filter_: Filter to apply to each nested entry.
    """
    if isinstance(filter_, FilterBuilder):
        filter_ = filter_.build()
    return Condition(nested=NestedCondition(key=key, filter=filter_))

# ---------------------------------------------------------------------------
#  FilterBuilder — fluent builder that produces Filter models
# ---------------------------------------------------------------------------

class FilterBuilder:
    """Fluent builder for constructing :class:`Filter` objects.

    Supports method chaining and operator composition.

    Example::

        f = (
            FilterBuilder()
            .must(Field("color").eq("red"))
            .must(Field("price").lt(100.0))
            .should(Field("brand").any_of(["A", "B"]))
            .must_not(is_empty("description"))
        )
        proto   = f.to_proto()
        model   = f.build()
    """

    __slots__ = ("_must", "_must_not", "_should", "_min_should")

    def __init__(self) -> None:
        self._must: list[Condition] = []
        self._must_not: list[Condition] = []
        self._should: list[Condition] = []
        self._min_should: MinShould | None = None

    # -- Clause setters (fluent) --------------------------------------------

    def must(self, condition: Condition) -> FilterBuilder:
        """Add a required condition (AND logic)."""
        self._must.append(condition)
        return self

    def must_not(self, condition: Condition) -> FilterBuilder:
        """Add a negated condition (NOT logic)."""
        self._must_not.append(condition)
        return self

    def should(self, condition: Condition) -> FilterBuilder:
        """Add an optional condition (OR logic)."""
        self._should.append(condition)
        return self

    def min_should(self, conditions: Sequence[Condition], min_count: int) -> FilterBuilder:
        """Add a minimum-should clause: at least *min_count* must match.

        Only points satisfying **at least** *min_count* of the given
        *conditions* will be included in the result.

        Args:
            conditions: Sequence of conditions to evaluate.
            min_count:  Minimum number that must be satisfied (must be ≥ 1).

        Raises:
            ValueError: If *min_count* < 1 or *conditions* is empty.
        """
        if min_count < 1:
            raise ValueError("min_count must be at least 1")
        if not conditions:
            raise ValueError("conditions must not be empty")
        self._min_should = MinShould(
            conditions=list(conditions),
            min_count=min_count,
        )
        return self

    # -- Composition operators ----------------------------------------------

    def __and__(self, other: FilterBuilder) -> FilterBuilder:
        """Combine two builders with AND (``&`` operator)."""
        fb = FilterBuilder()
        fb._must = self._must + other._must
        fb._must_not = self._must_not + other._must_not
        fb._should = self._should + other._should
        fb._min_should = self._min_should or other._min_should
        return fb

    def __or__(self, other: FilterBuilder) -> FilterBuilder:
        """Combine two builders with OR (``|`` operator).

        Wraps each side as a nested sub-filter inside a ``should`` clause.
        """
        fb = FilterBuilder()
        fb._should = [
            Condition(filter=self.build()),
            Condition(filter=other.build()),
        ]
        return fb

    def __invert__(self) -> FilterBuilder:
        """Negate all conditions (``~`` operator).

        Moves all ``must`` → ``must_not`` and vice-versa.
        """
        fb = FilterBuilder()
        fb._must_not = self._must.copy()
        fb._must = self._must_not.copy()
        fb._should = []
        return fb

    # -- Build / Proto / Utility --------------------------------------------

    def build(self) -> Filter:
        """Build and return a :class:`Filter` model."""
        return Filter(
            must=self._must,
            must_not=self._must_not,
            should=self._should,
            min_should=self._min_should,
        )

    def to_proto(self) -> Any:
        """Build and compile directly to a protobuf ``Filter`` message."""
        return self.build().to_proto()

    def is_empty(self) -> bool:
        """Return True if the builder has no conditions."""
        return (
            not self._must and not self._must_not and not self._should and self._min_should is None
        )

    def copy(self) -> FilterBuilder:
        """Return a shallow copy of this builder."""
        fb = FilterBuilder()
        fb._must = self._must.copy()
        fb._must_not = self._must_not.copy()
        fb._should = self._should.copy()
        fb._min_should = self._min_should
        return fb

    def __getattr__(self, name: str) -> Any:
        _valid = (
            "must",
            "must_not",
            "should",
            "min_should",
            "build",
            "to_proto",
            "is_empty",
            "copy",
        )
        raise AttributeError(
            f"'FilterBuilder' has no filter method {name!r}. Available methods: {', '.join(_valid)}"
        )

    def __bool__(self) -> bool:
        return not self.is_empty()

    def __repr__(self) -> str:
        parts = []
        if self._must:
            parts.append(f"must={len(self._must)}")
        if self._should:
            parts.append(f"should={len(self._should)}")
        if self._must_not:
            parts.append(f"must_not={len(self._must_not)}")
        if self._min_should:
            parts.append(f"min_should={self._min_should.min_count}")
        return f"FilterBuilder({', '.join(parts) or 'empty'})"

# ---------------------------------------------------------------------------
#  Condition operator overloads
# ---------------------------------------------------------------------------
#  Allow:   a & b  →  FilterBuilder with must=[a, b]
#           a | b  →  FilterBuilder with should=[a, b]
#           ~a     →  FilterBuilder with must_not=[a]

def _condition_and(self: Condition, other: Condition) -> FilterBuilder:
    fb = FilterBuilder()
    fb._must = [self, other]
    return fb

def _condition_or(self: Condition, other: Condition) -> FilterBuilder:
    fb = FilterBuilder()
    fb._should = [self, other]
    return fb

def _condition_invert(self: Condition) -> FilterBuilder:
    fb = FilterBuilder()
    fb._must_not = [self]
    return fb

# Monkey-patch operator overloads onto the Pydantic Condition model.
# This is intentional — Pydantic v2 models support dunder methods fine.
Condition.__and__ = _condition_and  # type: ignore[operator]
Condition.__or__ = _condition_or  # type: ignore[method-assign,assignment]
Condition.__invert__ = _condition_invert  # type: ignore[operator]

# ---------------------------------------------------------------------------
#  Private helpers
# ---------------------------------------------------------------------------

def _match(value: str | int | bool) -> Match:
    """Create a Match from a scalar value."""
    if isinstance(value, bool):
        return Match(boolean=value)
    if isinstance(value, int):
        return Match(integer=value)
    if isinstance(value, str):
        return Match(keyword=value)
    raise TypeError(f"Unsupported match value type: {type(value)}")

def _match_multi(values: Sequence[str | int]) -> Match:
    """Create a Match for an IN-list."""
    if not values:
        raise ValueError("values must be non-empty")
    if isinstance(values[0], str):
        return Match(keywords=list(values))  # type: ignore[arg-type]
    if isinstance(values[0], int):
        return Match(integers=list(values))  # type: ignore[arg-type]
    raise TypeError(f"Unsupported match_multi value type: {type(values[0])}")

def _match_except(values: Sequence[str | int]) -> Match:
    """Create a Match for a NOT-IN list."""
    if not values:
        raise ValueError("values must be non-empty")
    if isinstance(values[0], str):
        return Match(except_keywords=list(values))  # type: ignore[arg-type]
    if isinstance(values[0], int):
        return Match(except_integers=list(values))  # type: ignore[arg-type]
    raise TypeError(f"Unsupported match_except value type: {type(values[0])}")

def _dt_to_ts(dt: datetime) -> str:
    """Convert a Python datetime → ISO-8601 string for DatetimeRange."""
    ts = timestamp_pb2.Timestamp()
    ts.FromDatetime(dt)
    return str(ts.ToJsonString())
