#
# Copyright (c) 2026 by Actian Corporation
# All rights reserved.
#
# THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE
# OF ACTIAN CORP.
# The copyright notice above does not evidence any actual or intended
# publication of such source code.
#

"""Filter DSL subpackage — Type-safe filter builder for search queries.

Fluent builder that compiles directly to protobuf Filter objects.
"""

from actian_vectorai.filters.dsl import (
    Field,
    FilterBuilder,
    has_id,
    has_vector,
    is_empty,
    is_null,
    nested,
)

# Re-export Condition and Filter from models for convenience.
from actian_vectorai.models.common import Condition, Filter

__all__ = [
    # Builder API
    "Field",
    "FilterBuilder",
    # Standalone condition factories
    "has_id",
    "has_vector",
    "is_empty",
    "is_null",
    "nested",
    # Model re-exports
    "Condition",
    "Filter",
]
