#
# Copyright (c) 2026 by Actian Corporation
# All rights reserved.
#
# THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE
# OF ACTIAN CORP.
# The copyright notice above does not evidence any actual or intended
# publication of such source code.
#

"""Actian VectorAI DB Python Client SDK.

Public API surface for ``actian_vectorai``.  Import directly::

    from actian_vectorai import (
        VectorAIClient,          # sync
        AsyncVectorAIClient,     # async
        VectorParams, Distance, PointStruct, ScoredPoint,
        Field, FilterBuilder,
    )
"""

__version__ = "1.0.1"

# ── Clients ─────────────────────────────────────────────────────────────────
from actian_vectorai.async_client import AsyncVectorAIClient  # noqa: F401

# ── Smart Batcher ───────────────────────────────────────────────────────────
from actian_vectorai.batcher import BatcherConfig, SmartBatcher  # noqa: F401
from actian_vectorai.client import VectorAIClient  # noqa: F401

# ── Configuration ─────────────────────────────────────────────────────────────────
from actian_vectorai.config import Settings, settings  # noqa: F401

# ── Embeddings ──────────────────────────────────────────────────────────────
from actian_vectorai.embeddings import (  # noqa: F401
    EmbeddingProvider,
    OpenAIEmbedder,
)

# ── Exceptions ──────────────────────────────────────────────────────────────
from actian_vectorai.exceptions import (  # noqa: F401
    AuthenticationError,
    BatchError,
    CapacityExceededError,
    ChannelClosedError,
    CircuitBreakerOpenError,
    ClientClosedError,
    CollectionExistsError,
    CollectionNotFoundError,
    CollectionNotReadyError,
    DimensionMismatchError,
    ErrorCode,
    InvalidCredentialsError,
    MaxRetriesExceededError,
    MessageSizeExceededError,
    PayloadError,
    PayloadKeyNotFoundError,
    PermissionDeniedError,
    PointNotFoundError,
    RateLimitError,
    ServerError,
    UnimplementedError,
    VectorAIError,
    from_grpc_error,
    from_http_error,
    get_retry_delay,
    is_retryable,
)
from actian_vectorai.exceptions import (
    ConnectionError as VectorAIConnectionError,
)
from actian_vectorai.exceptions import (
    ConnectionRefusedError as VaiConnectionRefusedError,
)
from actian_vectorai.exceptions import (
    ConnectionTimeoutError as VaiConnectionTimeoutError,
)
from actian_vectorai.exceptions import (
    TimeoutError as VectorAITimeoutError,
)
from actian_vectorai.exceptions import (
    ValidationError as VectorAIValidationError,
)

# ── Filters ─────────────────────────────────────────────────────────────────
from actian_vectorai.filters import (  # noqa: F401
    Field,
    FilterBuilder,
    has_id,
    has_vector,
    is_empty,
    is_null,
    nested,
)

# ── Hybrid Fusion ───────────────────────────────────────────────────────────
from actian_vectorai.hybrid import (  # noqa: F401
    reciprocal_rank_fusion,
)

# ── Models ──────────────────────────────────────────────────────────────────
from actian_vectorai.models import *  # noqa: F401,F403

# ── Public API surface ──────────────────────────────────────────────────────
# All model names are re-exported from actian_vectorai.models via wildcard.
# This __all__ lists the explicit non-model names plus the models __all__.
from actian_vectorai.models import __all__ as _models_all

# ── Auth models ──────────────────────────────────────────────────────────────────
from actian_vectorai.models.auth import (  # noqa: F401
    AdminExistsResponse,
    AdminLoginResponse,
    ApiKeyCreated,
    ApiKeyInfo,
    ApiKeyPermission,
    AuthEnabledResponse,
    DeleteApiKeyResponse,
    ListApiKeysResponse,
)

# ── Transport (advanced) ────────────────────────────────────────────────────
from actian_vectorai.transport import (  # noqa: F401
    ConnectionPool,
    PoolConfig,
)

__all__ = [
    # Clients
    "VectorAIClient",
    "AsyncVectorAIClient",
    # Configuration
    "Settings",
    "settings",
    # Auth models
    "AdminLoginResponse",
    "AdminExistsResponse",
    "AuthEnabledResponse",
    "ApiKeyInfo",
    "ApiKeyCreated",
    "ApiKeyPermission",
    "ListApiKeysResponse",
    "DeleteApiKeyResponse",
    # Batcher
    "SmartBatcher",
    "BatcherConfig",
    # Exceptions
    "ErrorCode",
    "VectorAIError",
    "ServerError",
    "CollectionNotFoundError",
    "CollectionExistsError",
    "CollectionNotReadyError",
    "PointNotFoundError",
    "DimensionMismatchError",
    "PayloadError",
    "PayloadKeyNotFoundError",
    "BatchError",
    "RateLimitError",
    "CapacityExceededError",
    "MessageSizeExceededError",
    "MaxRetriesExceededError",
    "CircuitBreakerOpenError",
    "ClientClosedError",
    "UnimplementedError",
    "AuthenticationError",
    "InvalidCredentialsError",
    "PermissionDeniedError",
    "ChannelClosedError",
    "VectorAIConnectionError",
    "VaiConnectionRefusedError",
    "VaiConnectionTimeoutError",
    "VectorAITimeoutError",
    "VectorAIValidationError",
    "from_grpc_error",
    "from_http_error",
    "get_retry_delay",
    "is_retryable",
    # Filters
    "Field",
    "FilterBuilder",
    "has_id",
    "has_vector",
    "is_empty",
    "is_null",
    "nested",
    # Hybrid fusion
    "reciprocal_rank_fusion",
    # Embeddings
    "EmbeddingProvider",
    "OpenAIEmbedder",
    # Transport
    "ConnectionPool",
    "PoolConfig",
    # Version
    "__version__",
    # All model/enum names
    *_models_all,
]
