#
# Copyright (c) 2026 by Actian Corporation
# All rights reserved.
#
# THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE
# OF ACTIAN CORP.
# The copyright notice above does not evidence any actual or intended
# publication of such source code.
#

"""Hybrid search fusion module.

Client-side implementation of Reciprocal Rank Fusion (RRF) for
combining results from multiple heterogeneous retrieval pipelines.

While the server supports native fusion via the Universal Query API
(``Fusion.RRF`` in ``PrefetchQuery``), this client-side helper
enables:

- Post-hoc fusion of results from separate queries
- Custom weighting per retrieval source
- Result deduplication across namespaces or named vectors

Reference: Cormack, Clarke & Buettcher (2009) — RRF
"""

from actian_vectorai.hybrid.fusion import (
    reciprocal_rank_fusion,
)

__all__ = [
    "reciprocal_rank_fusion",
]
