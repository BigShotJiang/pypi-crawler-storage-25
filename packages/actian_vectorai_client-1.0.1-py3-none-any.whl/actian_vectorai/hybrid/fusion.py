#
# Copyright (c) 2026 by Actian Corporation
# All rights reserved.
#
# THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE
# OF ACTIAN CORP.
# The copyright notice above does not evidence any actual or intended
# publication of such source code.
#

"""Client-side score fusion algorithm for hybrid search pipelines.

**Reciprocal Rank Fusion (RRF)** — Rank-based fusion that ignores raw
scores entirely.  Robust to score-scale differences between dense
(cosine) and sparse (BM25) retrievers.

Accepts lists of ``ScoredPoint`` results from separate searches
and returns a single, deduped, re-ranked list.

Usage::

    from actian_vectorai.hybrid import reciprocal_rank_fusion

    dense_results  = await client.points.search(col, vector=dense_vec, limit=50)
    sparse_results = await client.points.search(col, vector=sparse_vec, limit=50)

    fused = reciprocal_rank_fusion([dense_results, sparse_results], limit=10)
"""

from __future__ import annotations

from collections import defaultdict
from typing import Any, Sequence

from actian_vectorai.models.points import ScoredPoint

# ============================================================================
#  Reciprocal Rank Fusion (RRF)
# ============================================================================

def reciprocal_rank_fusion(
    responses: Sequence[Sequence[ScoredPoint]],
    limit: int = 10,
    *,
    ranking_constant_k: int = 60,
    weights: Sequence[float] | None = None,
) -> list[ScoredPoint]:
    """Fuse multiple ranked lists using Reciprocal Rank Fusion.

    .. math::

        \\text{RRF}(d) = \\sum_{r \\in R} \\frac{w_r}{k + \\text{rank}_r(d)}

    Args:
        responses: List of search result lists from different retrievers.
        limit: Maximum number of results to return.
        ranking_constant_k: Smoothing constant (default 60).  Lower
            values amplify the importance of top-ranked results.
        weights: Optional per-source weight multipliers.  Must have the
            same length as *responses*.  Defaults to uniform weighting.

    Returns:
        Merged and re-ranked list of ``ScoredPoint``, sorted by fused
        score descending, limited to *limit* items.
    """
    if not responses:
        return []

    n = len(responses)
    if weights is not None and len(weights) != n:
        raise ValueError(f"weights length ({len(weights)}) must match responses length ({n})")
    w = list(weights) if weights is not None else [1.0] * n

    # Accumulate RRF score per unique point ID
    scores: dict[Any, float] = defaultdict(float)
    best_point: dict[Any, ScoredPoint] = {}

    for source_idx, results in enumerate(responses):
        for rank, point in enumerate(results, start=1):
            pid = _point_key(point)
            scores[pid] += w[source_idx] / (ranking_constant_k + rank)
            # Keep the version of the point with the highest original score
            if pid not in best_point or (
                point.score is not None
                and (best_point[pid].score is None or point.score > best_point[pid].score)
            ):
                best_point[pid] = point

    # Build result list sorted by fused score
    ranked = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)[:limit]
    result = []
    for pid, fused_score in ranked:
        pt = best_point[pid]
        result.append(
            ScoredPoint(
                id=pt.id,
                version=pt.version,
                score=fused_score,
                payload=pt.payload,
                vectors=pt.vectors,
            )
        )
    return result

# ============================================================================
#  Private helpers
# ============================================================================

def _point_key(point: ScoredPoint) -> Any:
    """Hashable key for a scored point (supports int and UUID-string IDs)."""
    return point.id
