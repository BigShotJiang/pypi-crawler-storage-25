#
# Copyright (c) 2026 by Actian Corporation
# All rights reserved.
#
# THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE
# OF ACTIAN CORP.
# The copyright notice above does not evidence any actual or intended
# publication of such source code.
#

"""Authentication and API key management namespace.

This namespace wraps the Actian VectorAI DB REST authentication API:

Admin lifecycle (localhost-only create/delete, open login)::

    # One-time setup from the server host
    await client.auth.create_admin(password="MySecurePwd!1")

    # Login to get a short-lived JWT for admin operations
    resp = await client.auth.login(password="MySecurePwd!1")
    admin_jwt = resp.token

    # Enable auth enforcement
    await client.auth.set_auth_enabled(True, admin_jwt=admin_jwt)

API key lifecycle::

    # Create a read+write key
    key = await client.auth.create_api_key(
        name="ci-rw",
        permission="read,write",
        admin_jwt=admin_jwt,
    )
    print(key.api_key)   # vdai_... — save this, shown only once

    # List active keys (no raw tokens)
    keys = await client.auth.list_api_keys(admin_jwt=admin_jwt)

    # Rotate (old key immediately invalidated)
    rotated = await client.auth.rotate_api_key(key.id, admin_jwt=admin_jwt)

    # Delete
    await client.auth.delete_api_key(key.id, admin_jwt=admin_jwt)

All methods accept either ``admin_jwt`` (JWT from ``login()``) or
``admin_api_key`` (an API key that has the ``admin`` permission bit).
If you already configured the client with an ``api_key``, you can omit
both and the client token will be used for admin calls.
"""

from __future__ import annotations

import logging
from typing import Any

from actian_vectorai.exceptions import (
    InvalidCredentialsError,
)
from actian_vectorai.models.auth import (
    AdminExistsResponse,
    AdminLoginResponse,
    ApiKeyCreated,
    ApiKeyInfo,
    AuthEnabledResponse,
    ListApiKeysResponse,
)

__all__ = ["AuthNamespace"]

logger = logging.getLogger(__name__)


def _build_auth_headers(
    admin_jwt: str | None,
    admin_api_key: str | None,
    client_api_key: str | None,
) -> dict[str, str]:
    """Build HTTP auth headers.

    Priority: admin_jwt > admin_api_key > client_api_key.
    Sends ``api-key`` (server checks first) and ``Authorization: Bearer``
    (fallback) for maximum compatibility.
    """
    token = admin_jwt or admin_api_key or client_api_key
    if token:
        return {
            "api-key": token,
            "Authorization": f"Bearer {token}",
        }
    return {}


class AuthNamespace:
    """Admin user and API key management via the REST API.

    .. note::
        This namespace is backed exclusively by the REST API (port 6573).
        gRPC does not have dedicated auth management RPCs.

    Parameters
    ----------
    rest:
        The :class:`~actian_vectorai.transport.rest.RESTTransport` instance
        used for all HTTP calls.
    api_key:
        The client-level API key (from ``AsyncVectorAIClient``).  Used as
        fallback credentials when per-call ``admin_jwt``/``admin_api_key``
        are not supplied.
    """

    __slots__ = ("_rest", "_api_key")

    def __init__(
        self,
        rest: Any,
        api_key: str | None = None,
    ) -> None:
        self._rest = rest
        self._api_key = api_key

    # ═══════════════════════════════════════════════════════════
    #  Admin user management
    # ═══════════════════════════════════════════════════════════

    async def admin_exists(self) -> bool:
        """Return ``True`` if the built-in ``admin`` user has been created.

        This endpoint requires no authentication.
        """
        data = await self._rest.get("/auth/admin/exists")
        resp = AdminExistsResponse.model_validate(data)
        logger.debug("admin_exists → %s", resp.result)
        return resp.result

    async def create_admin(self, password: str) -> None:
        """Create the built-in ``admin`` user.

        .. important::
            This endpoint is only accepted from the **same host** as the
            server.  Remote calls will receive ``403 Forbidden``.

        Parameters
        ----------
        password:
            Must satisfy the server password policy (≥12 chars,
            upper+lower+digit+special, not the username).

        Raises
        ------
        :class:`~actian_vectorai.exceptions.InvalidCredentialsError`
            If the admin already exists.
        :class:`~actian_vectorai.exceptions.VectorAIError`
            For other server errors.
        """
        await self._rest.post("/auth/admin", json={"password": password})
        logger.debug("Admin user created")

    async def delete_admin(self, *, admin_jwt: str | None = None) -> None:
        """Delete the built-in ``admin`` user.

        Requires an admin JWT (not an API key).

        Parameters
        ----------
        admin_jwt:
            JWT obtained from :meth:`login`.

        Raises
        ------
        :class:`~actian_vectorai.exceptions.AuthenticationError`
            If the JWT is missing, invalid, or not an admin JWT.
        """
        headers = _build_auth_headers(admin_jwt, None, None)
        await self._rest.delete("/auth/admin", headers=headers)
        logger.debug("Admin user deleted")

    async def login(self, password: str) -> AdminLoginResponse:
        """Authenticate as the built-in ``admin`` user and return a JWT.

        The JWT is short-lived (default 1 hour) and is required for
        admin-only operations such as :meth:`set_auth_enabled` and
        :meth:`create_api_key`.

        Parameters
        ----------
        password:
            The admin user's password.

        Returns
        -------
        :class:`~actian_vectorai.models.auth.AdminLoginResponse`
            Contains ``token`` (JWT string) and ``expires_in`` (seconds).

        Raises
        ------
        :class:`~actian_vectorai.exceptions.InvalidCredentialsError`
            If the password is wrong.

        Example::

            resp = await client.auth.login(password="MySecurePwd!1")
            admin_jwt = resp.token
        """
        data = await self._rest.post(
            "/auth/admin/login", json={"password": password}
        )
        resp = AdminLoginResponse.model_validate(data)
        if not resp.token:
            raise InvalidCredentialsError("Login failed: " + (resp.message or "invalid credentials"))
        logger.debug("Admin login successful (expires_in=%s)", resp.expires_in)
        return resp

    async def reset_admin_password(
        self,
        old_password: str,
        new_password: str,
    ) -> None:
        """Reset the admin user password.

        Parameters
        ----------
        old_password:
            Current admin password.
        new_password:
            Replacement password (must satisfy password policy).

        Raises
        ------
        :class:`~actian_vectorai.exceptions.InvalidCredentialsError`
            If ``old_password`` is incorrect.
        """
        await self._rest.post(
            "/auth/admin/reset-password",
            json={"old_password": old_password, "new_password": new_password},
        )
        logger.debug("Admin password reset")

    # ═══════════════════════════════════════════════════════════
    #  Auth enable / disable
    # ═══════════════════════════════════════════════════════════

    async def is_auth_enabled(self, *, admin_jwt: str) -> bool:
        """Return ``True`` if authentication enforcement is active.

        Parameters
        ----------
        admin_jwt:
            JWT from :meth:`login`.

        Returns
        -------
        bool
            Current auth-enabled state.
        """
        headers = _build_auth_headers(admin_jwt, None, None)
        data = await self._rest.get("/auth/enabled", headers=headers)
        resp = AuthEnabledResponse.model_validate(data)
        logger.debug("auth_enabled → %s", resp.result)
        return resp.result

    async def set_auth_enabled(
        self,
        enabled: bool,
        *,
        admin_jwt: str,
    ) -> bool:
        """Enable or disable authentication enforcement.

        When disabled, all endpoints are accessible without credentials.
        When enabled, every protected endpoint requires a valid API key or
        admin JWT.

        Parameters
        ----------
        enabled:
            ``True`` to enable, ``False`` to disable.
        admin_jwt:
            JWT from :meth:`login` (only admin JWTs are accepted here).

        Returns
        -------
        bool
            The auth-enabled state **after** the update.

        Raises
        ------
        :class:`~actian_vectorai.exceptions.AuthenticationError`
            If the JWT is missing or invalid.

        Example::

            resp = await client.auth.login("MySecurePwd!1")
            await client.auth.set_auth_enabled(True, admin_jwt=resp.token)
        """
        headers = _build_auth_headers(admin_jwt, None, None)
        data = await self._rest.patch(
            "/auth/enabled",
            json={"enabled": enabled},
            headers=headers,
        )
        resp = AuthEnabledResponse.model_validate(data)
        logger.debug("set_auth_enabled(%s) → %s", enabled, resp.result)
        return resp.result

    # ═══════════════════════════════════════════════════════════
    #  API key CRUD
    # ═══════════════════════════════════════════════════════════

    async def create_api_key(
        self,
        name: str,
        *,
        permission: str = "read,write",
        description: str = "",
        will_expire: bool = False,
        expires_in_seconds: int = 0,
        admin_jwt: str | None = None,
        admin_api_key: str | None = None,
    ) -> ApiKeyCreated:
        """Create a new API key.

        Requires ``auth_enabled=True`` and admin credentials.

        Parameters
        ----------
        name:
            Unique human-readable identifier for the key.
        permission:
            Comma-separated permission string.  Use
            :class:`~actian_vectorai.models.auth.ApiKeyPermission` constants.

            Common values:

            - ``"read"`` — read-only
            - ``"write"`` — write-only
            - ``"read,write"`` — standard R/W (default)
            - ``"read,write,admin"`` — full access
        description:
            Optional free-text description (shown in :meth:`list_api_keys`).
        will_expire:
            If ``True``, the key expires after ``expires_in_seconds``.
        expires_in_seconds:
            TTL in seconds when ``will_expire=True``.  ``0`` = expires
            immediately (useful for testing).
        admin_jwt:
            JWT from :meth:`login`.
        admin_api_key:
            API key with ``admin`` permission bit.

        Returns
        -------
        :class:`~actian_vectorai.models.auth.ApiKeyCreated`
            Includes the raw ``api_key`` value (``vdai_…``).

        .. warning::
            The raw key is shown **only once**.  Store it in a secrets
            manager or ``.env`` file immediately.

        Raises
        ------
        :class:`~actian_vectorai.exceptions.PermissionDeniedError`
            If auth is disabled (``auth_enabled=False``).
        :class:`~actian_vectorai.exceptions.AuthenticationError`
            If credentials are missing or invalid.
        :class:`~actian_vectorai.exceptions.VectorAIError`
            If a key with the same name already exists (409 Conflict).

        Example::

            key = await client.auth.create_api_key(
                name="ci-pipeline",
                permission=ApiKeyPermission.READ_WRITE,
                admin_jwt=admin_jwt,
            )
            # Save key.api_key — shown only once!
        """
        headers = _build_auth_headers(admin_jwt, admin_api_key, self._api_key)
        body: dict[str, Any] = {
            "name": name,
            "description": description,
            "will_expire": will_expire,
            "expires_in_seconds": expires_in_seconds,
            "permission": permission,
        }
        data = await self._rest.post("/auth/api_key", json=body, headers=headers)
        created = ApiKeyCreated.model_validate(data)
        logger.debug("Created API key %r (id=%s, perm=%s)", name, created.id, created.permission)
        return created

    async def list_api_keys(
        self,
        *,
        admin_jwt: str | None = None,
        admin_api_key: str | None = None,
    ) -> list[ApiKeyInfo]:
        """List all API keys (without raw token values).

        Parameters
        ----------
        admin_jwt:
            JWT from :meth:`login`.
        admin_api_key:
            API key with ``admin`` permission bit.

        Returns
        -------
        list[:class:`~actian_vectorai.models.auth.ApiKeyInfo`]

        Raises
        ------
        :class:`~actian_vectorai.exceptions.PermissionDeniedError`
            If auth is disabled.
        :class:`~actian_vectorai.exceptions.AuthenticationError`
            If credentials are missing or invalid.
        """
        headers = _build_auth_headers(admin_jwt, admin_api_key, self._api_key)
        data = await self._rest.get("/auth/api_keys", headers=headers)
        resp = ListApiKeysResponse.model_validate(data)
        logger.debug("list_api_keys → %d keys", len(resp.api_keys))
        return resp.api_keys

    async def delete_api_key(
        self,
        key_id: int,
        *,
        admin_jwt: str | None = None,
        admin_api_key: str | None = None,
    ) -> None:
        """Delete an API key by its numeric ID.

        The key is immediately invalidated.

        Parameters
        ----------
        key_id:
            The ``id`` field from :class:`~actian_vectorai.models.auth.ApiKeyInfo`
            or :class:`~actian_vectorai.models.auth.ApiKeyCreated`.
        admin_jwt:
            JWT from :meth:`login`.
        admin_api_key:
            API key with ``admin`` permission bit.

        Raises
        ------
        :class:`~actian_vectorai.exceptions.VectorAIError`
            If the key does not exist (404) or other server error.
        """
        headers = _build_auth_headers(admin_jwt, admin_api_key, self._api_key)
        await self._rest.delete(f"/auth/api_key/{key_id}", headers=headers)
        logger.debug("Deleted API key id=%s", key_id)

    async def rotate_api_key(
        self,
        key_id: int,
        *,
        admin_jwt: str | None = None,
        admin_api_key: str | None = None,
    ) -> ApiKeyCreated:
        """Rotate an API key, immediately invalidating the old raw token.

        The key ``id``, ``name``, ``description``, ``permission``,
        ``will_expire``, and ``expired_at`` are preserved.  Only the raw
        token value changes.

        Parameters
        ----------
        key_id:
            The ``id`` field from :class:`~actian_vectorai.models.auth.ApiKeyInfo`.
        admin_jwt:
            JWT from :meth:`login`.
        admin_api_key:
            API key with ``admin`` permission bit.

        Returns
        -------
        :class:`~actian_vectorai.models.auth.ApiKeyCreated`
            Contains the new ``api_key`` value.

        Raises
        ------
        :class:`~actian_vectorai.exceptions.VectorAIError`
            If the key does not exist (404) or is expired (409).

        Example::

            rotated = await client.auth.rotate_api_key(key.id, admin_jwt=admin_jwt)
            # old key.api_key is now invalid; use rotated.api_key
        """
        headers = _build_auth_headers(admin_jwt, admin_api_key, self._api_key)
        data = await self._rest.post(
            f"/auth/api_key/{key_id}/rotate",
            json=None,
            headers=headers,
        )
        rotated = ApiKeyCreated.model_validate(data)
        logger.debug("Rotated API key id=%s → new key issued", key_id)
        return rotated

    def __repr__(self) -> str:
        return "AuthNamespace()"
