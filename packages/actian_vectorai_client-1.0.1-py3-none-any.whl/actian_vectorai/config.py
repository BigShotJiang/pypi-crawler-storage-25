#
# Copyright (c) 2026 by Actian Corporation
# All rights reserved.
#
# THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE
# OF ACTIAN CORP.
# The copyright notice above does not evidence any actual or intended
# publication of such source code.
#

"""Centralized environment-aware configuration for Actian VectorAI DB Python SDK.

Loads settings from environment variables (``ACTIAN_VECTORAI_*``) and
optionally from ``.env`` files via ``python-dotenv``.

Priority order (highest wins):
  1. Constructor keyword arguments (explicit)
  2. Environment variables / ``.env`` file
  3. Built-in defaults

Usage::

    from actian_vectorai.config import Settings, settings

    # Global singleton — reads env on first access
    print(settings.url)           # "localhost:6574"
    print(settings.api_key)  # from ACTIAN_VECTORAI_API_KEY or ACTIAN_VECTORAI_ACCESS_TOKEN

    # Custom instance with overrides
    cfg = Settings(url="remote:6574", timeout=60.0)
"""

from __future__ import annotations

import logging
import os
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

__all__ = ["Settings", "settings"]

logger = logging.getLogger("actian_vectorai.config")

# ── .env loading (once) ──────────────────────────────────────────────────

_dotenv_loaded = False
_dotenv_lock = threading.Lock()


def _load_dotenv_once() -> None:
    """Load ``.env`` file exactly once, thread-safe.

    Respects ``ACTIAN_VECTORAI_ENV_FILE`` for custom paths.
    Falls back to ``.env`` in the current working directory.
    """
    global _dotenv_loaded
    if _dotenv_loaded:
        return
    with _dotenv_lock:
        if _dotenv_loaded:
            return
        try:
            from dotenv import load_dotenv
        except ImportError:
            logger.debug("python-dotenv not installed — skipping .env loading")
            _dotenv_loaded = True
            return

        env_file = os.environ.get("ACTIAN_VECTORAI_ENV_FILE", ".env")
        env_path = Path(env_file)
        if env_path.is_file():
            load_dotenv(env_path, override=False)
            logger.debug("Loaded .env from %s", env_path.resolve())
        else:
            logger.debug("No .env file found at %s", env_path.resolve())
        _dotenv_loaded = True


# ── Helpers ──────────────────────────────────────────────────────────────


def _env(key: str, default: str | None = None) -> str | None:
    """Read an environment variable after ensuring .env is loaded."""
    _load_dotenv_once()
    return os.environ.get(key, default)


def _env_bool(key: str, default: bool) -> bool:
    """Parse a boolean environment variable (true/1/yes → True)."""
    val = _env(key)
    if val is None:
        return default
    return val.lower() in ("true", "1", "yes", "on")


def _env_int(key: str, default: int) -> int:
    """Parse an integer environment variable with validation."""
    val = _env(key)
    if val is None:
        return default
    try:
        return int(val)
    except ValueError:
        logger.warning("Invalid integer for %s=%r, using default %d", key, val, default)
        return default


def _env_float(key: str, default: float) -> float:
    """Parse a float environment variable with validation."""
    val = _env(key)
    if val is None:
        return default
    try:
        return float(val)
    except ValueError:
        logger.warning("Invalid float for %s=%r, using default %s", key, val, default)
        return default


# ── Settings class ───────────────────────────────────────────────────────


@dataclass
class Settings:
    """SDK configuration resolved from kwargs → env vars → defaults.

    All ``ACTIAN_VECTORAI_*`` environment variables are loaded on first
    access.  Constructor keyword arguments always take precedence.

    Parameters
    ----------
    url:
        gRPC server address (``host:port``).
    rest_url:
        REST API base URL.
    api_key:
        API key for authentication.  Sent as ``api-key: <token>`` (primary)
        and ``Authorization: Bearer <token>`` (fallback) on every request.
        Resolved from ``ACTIAN_VECTORAI_API_KEY`` or the
        ``ACTIAN_VECTORAI_ACCESS_TOKEN`` environment variable.
    tls:
        Enable TLS.
    tls_ca_cert:
        Path to CA certificate file.
    tls_client_cert:
        Path to client certificate file.
    tls_client_key:
        Path to client private key file.
    timeout:
        Default per-RPC timeout in seconds.
    max_message_size:
        Maximum gRPC message size in bytes (default: 256 MiB).
    max_retries:
        Maximum retry attempts for transient errors.
    pool_size:
        gRPC connection pool size.
    enable_tracing:
        Inject ``x-request-id`` / ``x-request-timestamp`` metadata.
    enable_logging:
        Log every RPC call timing.
    log_level:
        SDK log level (DEBUG, INFO, WARNING, ERROR, CRITICAL).
    grpc_port:
        gRPC port (used when URL is host-only, without port).
    rest_port:
        REST API port.
    """

    url: str = field(default=None)  # type: ignore[assignment]
    rest_url: str = field(default=None)  # type: ignore[assignment]
    api_key: str | None = field(default=None)
    tls: bool = field(default=None)  # type: ignore[assignment]
    tls_ca_cert: str | None = field(default=None)
    tls_client_cert: str | None = field(default=None)
    tls_client_key: str | None = field(default=None)
    timeout: float = field(default=None)  # type: ignore[assignment]
    max_message_size: int = field(default=None)  # type: ignore[assignment]
    max_retries: int = field(default=None)  # type: ignore[assignment]
    pool_size: int = field(default=None)  # type: ignore[assignment]
    enable_tracing: bool = field(default=None)  # type: ignore[assignment]
    enable_logging: bool = field(default=None)  # type: ignore[assignment]
    log_level: str = field(default=None)  # type: ignore[assignment]
    grpc_port: int = field(default=None)  # type: ignore[assignment]
    rest_port: int = field(default=None)  # type: ignore[assignment]

    def __post_init__(self) -> None:
        """Resolve: kwargs (already set) → env vars → defaults."""
        self._resolve_env_defaults()
        self._apply_log_level()
        self._validate()

    def _resolve_env_defaults(self) -> None:
        """Fill unset fields from env vars, then hard-coded defaults.

        Only ``None`` values are resolved from env / defaults;
        explicit values (including empty strings) are preserved as-is.
        """
        if self.url is None:
            self.url = _env("ACTIAN_VECTORAI_URL", "localhost:6574")
        if self.rest_url is None:
            self.rest_url = _env("ACTIAN_VECTORAI_REST_URL", "http://localhost:6573")
        if self.api_key is None:
            # Support both ACTIAN_VECTORAI_API_KEY and ACTIAN_VECTORAI_ACCESS_TOKEN
            self.api_key = (
                _env("ACTIAN_VECTORAI_API_KEY")
                or _env("ACTIAN_VECTORAI_ACCESS_TOKEN")
            )
        if self.tls_ca_cert is None:
            self.tls_ca_cert = _env("ACTIAN_VECTORAI_TLS_CA_CERT")
        if self.tls_client_cert is None:
            self.tls_client_cert = _env("ACTIAN_VECTORAI_TLS_CLIENT_CERT")
        if self.tls_client_key is None:
            self.tls_client_key = _env("ACTIAN_VECTORAI_TLS_CLIENT_KEY")
        self._resolve_typed_defaults()

    def _resolve_typed_defaults(self) -> None:
        """Resolve bool/int/float/str fields that use typed env helpers."""
        _bool_defaults: list[tuple[str, str, bool]] = [
            ("tls", "ACTIAN_VECTORAI_TLS", False),
            ("enable_tracing", "ACTIAN_VECTORAI_ENABLE_TRACING", True),
            ("enable_logging", "ACTIAN_VECTORAI_ENABLE_LOGGING", False),
        ]
        for b_attr, b_key, b_default in _bool_defaults:
            if getattr(self, b_attr) is None:
                setattr(self, b_attr, _env_bool(b_key, b_default))

        _int_defaults: list[tuple[str, str, int]] = [
            ("max_message_size", "ACTIAN_VECTORAI_MAX_MESSAGE_SIZE", 268435456),
            ("max_retries", "ACTIAN_VECTORAI_MAX_RETRIES", 3),
            ("pool_size", "ACTIAN_VECTORAI_POOL_SIZE", 1),
            ("grpc_port", "ACTIAN_VECTORAI_GRPC_PORT", 6574),
            ("rest_port", "ACTIAN_VECTORAI_REST_PORT", 6573),
        ]
        for i_attr, i_key, i_default in _int_defaults:
            if getattr(self, i_attr) is None:
                setattr(self, i_attr, _env_int(i_key, i_default))

        if self.timeout is None:
            self.timeout = _env_float("ACTIAN_VECTORAI_TIMEOUT", 30.0)
        if self.log_level is None:
            self.log_level = _env("ACTIAN_VECTORAI_LOG_LEVEL", "WARNING") or "WARNING"

    def _apply_log_level(self) -> None:
        """Apply the configured log level to the SDK logger."""
        sdk_logger = logging.getLogger("actian_vectorai")
        level = getattr(logging, self.log_level.upper(), logging.WARNING)
        sdk_logger.setLevel(level)

    def _validate(self) -> None:
        """Validate resolved settings."""
        if self.timeout <= 0:
            raise ValueError(f"timeout must be positive, got {self.timeout}")
        if self.max_message_size <= 0:
            raise ValueError(f"max_message_size must be positive, got {self.max_message_size}")
        if self.max_retries < 0:
            raise ValueError(f"max_retries must be >= 0, got {self.max_retries}")
        if self.pool_size < 1:
            raise ValueError(f"pool_size must be >= 1, got {self.pool_size}")
        # Validate URL format (host:port)
        if "://" in self.url:
            raise ValueError(
                f"gRPC url must be host:port without scheme, got {self.url!r}. "
                "Use rest_url for HTTP endpoints."
            )

    def to_dict(self) -> dict[str, Any]:
        """Return all settings as a dictionary (masks api_key)."""
        d: dict[str, Any] = {}
        for k in (
            "url", "rest_url", "api_key", "tls", "tls_ca_cert",
            "tls_client_cert", "tls_client_key", "timeout", "max_message_size",
            "max_retries", "pool_size", "enable_tracing", "enable_logging",
            "log_level", "grpc_port", "rest_port",
        ):
            v = getattr(self, k)
            if k == "api_key" and v:
                d[k] = f"{v[:4]}***" if len(v) > 4 else "***"
            else:
                d[k] = v
        return d

    def __repr__(self) -> str:
        return f"Settings({self.to_dict()})"


# ── Global singleton ─────────────────────────────────────────────────────

_settings: Settings | None = None
_settings_lock = threading.Lock()


def _get_settings() -> Settings:
    """Lazily create the global settings singleton."""
    global _settings
    if _settings is None:
        with _settings_lock:
            if _settings is None:
                _settings = Settings()
    return _settings


class _SettingsProxy:
    """Lazy proxy that defers ``Settings`` construction until first access.

    Avoids side-effects at import time while keeping ``settings.url``
    ergonomics.
    """

    def __getattr__(self, name: str) -> Any:
        return getattr(_get_settings(), name)

    def __repr__(self) -> str:
        return repr(_get_settings())


settings: Settings = _SettingsProxy()  # type: ignore[assignment]
