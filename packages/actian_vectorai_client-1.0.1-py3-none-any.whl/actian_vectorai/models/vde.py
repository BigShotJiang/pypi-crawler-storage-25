#
# Copyright (c) 2026 by Actian Corporation
# All rights reserved.
#
# THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE
# OF ACTIAN CORP.
# The copyright notice above does not evidence any actual or intended
# publication of such source code.
#

"""VDE (Vector Database Engine) extension models.

Maps messages from ``actian_vectorai_collections_ext.proto`` and ``actian_vectorai_index.proto``.
"""

from __future__ import annotations

from pydantic import BaseModel, Field

from actian_vectorai.models.enums import (
    DistanceMetric,
    IndexAlgorithm,
    IndexDriver,
    RebuildDataSourceType,
    RebuildTargetIndexType,
    RebuildTaskState,
    StorageType,
)
from actian_vectorai.proto import actian_vectorai_collections_ext_pb2 as ext_pb

__all__ = [
    # Config
    "HnswConfig",
    "VdeCollectionConfig",
    # Stats
    "CollectionStats",
    "OptimizationProgress",
    "OptimizationsResponse",
    # Rebuild
    "RebuildDataSourceConfig",
    "RebuildTargetConfig",
    "RebuildRunConfig",
    "RebuildStats",
    "RebuildTaskInfo",
    # Advanced ops
    "CompactOptions",
    "CompactStats",
]

# ─── Index Config ────────────────────────────────────────────────────

class HnswConfig(BaseModel):
    """HNSW fixed configuration (VDE extension)."""

    m: int = 16
    ef_construct: int = 200
    ef_search: int = 50

    def to_proto(self) -> ext_pb.HnswConfig:
        return ext_pb.HnswConfig(
            m=self.m,
            ef_construct=self.ef_construct,
            ef_search=self.ef_search,
        )

    @classmethod
    def from_proto(cls, pb: ext_pb.HnswConfig) -> HnswConfig:
        return cls(m=pb.m, ef_construct=pb.ef_construct, ef_search=pb.ef_search)

class VdeCollectionConfig(BaseModel):
    """VDE collection configuration for CloneCollection etc.

    Storage uses the built-in engine (the only supported backend).
    """

    index_driver: IndexDriver = IndexDriver.FAISS
    index_algorithm: IndexAlgorithm = IndexAlgorithm.HNSW
    dimension: int = 0
    distance_metric: DistanceMetric = DistanceMetric.COSINE
    config_json: str = ""
    hnsw_config: HnswConfig | None = None

    def to_proto(self) -> ext_pb.VdeCollectionConfig:
        pb = ext_pb.VdeCollectionConfig(
            index_driver=self.index_driver.value,
            index_algorithm=self.index_algorithm.value,
            storage_type=StorageType.BVSTORE.value,
            dimension=self.dimension,
            distance_metric=self.distance_metric.value,
            config_json=self.config_json,
        )
        if self.hnsw_config is not None:
            pb.hnsw_config.CopyFrom(self.hnsw_config.to_proto())
        return pb

    @classmethod
    def from_proto(cls, pb: ext_pb.VdeCollectionConfig) -> VdeCollectionConfig:
        return cls(
            index_driver=IndexDriver(pb.index_driver),
            index_algorithm=IndexAlgorithm(pb.index_algorithm),
            # storage_type is fixed — pb.storage_type ignored
            dimension=pb.dimension,
            distance_metric=DistanceMetric(pb.distance_metric),
            config_json=pb.config_json,
            hnsw_config=(
                HnswConfig.from_proto(pb.hnsw_config) if pb.HasField("hnsw_config") else None
            ),
        )

# ─── Collection Stats ────────────────────────────────────────────────

class CollectionStats(BaseModel):
    """VDE collection statistics."""

    total_vectors: int = 0
    indexed_vectors: int = 0
    deleted_vectors: int = 0
    storage_bytes: int = 0
    index_memory_bytes: int = 0

    @classmethod
    def from_proto(cls, pb: ext_pb.CollectionStats) -> CollectionStats:
        return cls(
            total_vectors=pb.total_vectors,
            indexed_vectors=pb.indexed_vectors,
            deleted_vectors=pb.deleted_vectors,
            storage_bytes=pb.storage_bytes,
            index_memory_bytes=pb.index_memory_bytes,
        )

class OptimizationProgress(BaseModel):
    """Optimization progress tree node."""

    name: str = ""
    started_at: str = ""
    finished_at: str | None = None
    duration_sec: float | None = None
    done: int | None = None
    total: int | None = None
    children: list[OptimizationProgress] = Field(default_factory=list)

    @classmethod
    def from_proto(cls, pb: ext_pb.OptimizationProgress) -> OptimizationProgress:
        return cls(
            name=pb.name,
            started_at=pb.started_at,
            finished_at=pb.finished_at if pb.HasField("finished_at") else None,
            duration_sec=pb.duration_sec if pb.HasField("duration_sec") else None,
            done=pb.done if pb.HasField("done") else None,
            total=pb.total if pb.HasField("total") else None,
            children=[OptimizationProgress.from_proto(c) for c in pb.children],
        )

# Rebuild for self-reference
OptimizationProgress.model_rebuild()

class OptimizationsResponse(BaseModel):
    """Optimization progress response."""

    ongoing: list[OptimizationProgress] = Field(default_factory=list)
    completed: list[OptimizationProgress] = Field(default_factory=list)

    @classmethod
    def from_proto(cls, pb: ext_pb.OptimizationsResponse) -> OptimizationsResponse:
        return cls(
            ongoing=[OptimizationProgress.from_proto(o) for o in pb.ongoing],
            completed=[OptimizationProgress.from_proto(c) for c in pb.completed],
        )

# ─── Rebuild Types ───────────────────────────────────────────────────

class RebuildDataSourceConfig(BaseModel):
    """Rebuild data source configuration."""

    type: RebuildDataSourceType = RebuildDataSourceType.SOURCE_CURRENT_INDEX
    snapshot_path: str | None = None
    external_uri: str | None = None
    include_deleted: bool | None = None

    def to_proto(self) -> ext_pb.RebuildDataSourceConfig:
        pb = ext_pb.RebuildDataSourceConfig(type=self.type.value)
        if self.snapshot_path is not None:
            pb.snapshot_path = self.snapshot_path
        if self.external_uri is not None:
            pb.external_uri = self.external_uri
        if self.include_deleted is not None:
            pb.include_deleted = self.include_deleted
        return pb

    @classmethod
    def from_proto(cls, pb: ext_pb.RebuildDataSourceConfig) -> RebuildDataSourceConfig:
        return cls(
            type=RebuildDataSourceType(pb.type),
            snapshot_path=pb.snapshot_path if pb.HasField("snapshot_path") else None,
            external_uri=pb.external_uri if pb.HasField("external_uri") else None,
            include_deleted=pb.include_deleted if pb.HasField("include_deleted") else None,
        )

class RebuildTargetConfig(BaseModel):
    """Rebuild target configuration."""

    index_type: RebuildTargetIndexType = RebuildTargetIndexType.TARGET_SAME
    target_collection: str | None = None
    create_new_collection: bool | None = None

    def to_proto(self) -> ext_pb.RebuildTargetConfig:
        pb = ext_pb.RebuildTargetConfig(index_type=self.index_type.value)
        if self.target_collection is not None:
            pb.target_collection = self.target_collection
        if self.create_new_collection is not None:
            pb.create_new_collection = self.create_new_collection
        return pb

    @classmethod
    def from_proto(cls, pb: ext_pb.RebuildTargetConfig) -> RebuildTargetConfig:
        return cls(
            index_type=RebuildTargetIndexType(pb.index_type),
            target_collection=(pb.target_collection if pb.HasField("target_collection") else None),
            create_new_collection=(
                pb.create_new_collection if pb.HasField("create_new_collection") else None
            ),
        )

class RebuildRunConfig(BaseModel):
    """Rebuild run configuration."""

    batch_size: int | None = None
    max_catchup_rounds: int | None = None
    catchup_threshold: int | None = None
    verify_after_rebuild: bool | None = None
    verify_sample_count: int | None = None
    overwrite_collection_config: bool | None = None

    def to_proto(self) -> ext_pb.RebuildRunConfig:
        pb = ext_pb.RebuildRunConfig()
        if self.batch_size is not None:
            pb.batch_size = self.batch_size
        if self.max_catchup_rounds is not None:
            pb.max_catchup_rounds = self.max_catchup_rounds
        if self.catchup_threshold is not None:
            pb.catchup_threshold = self.catchup_threshold
        if self.verify_after_rebuild is not None:
            pb.verify_after_rebuild = self.verify_after_rebuild
        if self.verify_sample_count is not None:
            pb.verify_sample_count = self.verify_sample_count
        if self.overwrite_collection_config is not None:
            pb.overwrite_collection_config = self.overwrite_collection_config
        return pb

    @classmethod
    def from_proto(cls, pb: ext_pb.RebuildRunConfig) -> RebuildRunConfig:
        return cls(
            batch_size=pb.batch_size if pb.HasField("batch_size") else None,
            max_catchup_rounds=(
                pb.max_catchup_rounds if pb.HasField("max_catchup_rounds") else None
            ),
            catchup_threshold=(pb.catchup_threshold if pb.HasField("catchup_threshold") else None),
            verify_after_rebuild=(
                pb.verify_after_rebuild if pb.HasField("verify_after_rebuild") else None
            ),
            verify_sample_count=(
                pb.verify_sample_count if pb.HasField("verify_sample_count") else None
            ),
            overwrite_collection_config=(
                pb.overwrite_collection_config
                if pb.HasField("overwrite_collection_config")
                else None
            ),
        )

class RebuildStats(BaseModel):
    """Rebuild operation statistics."""

    total_vectors: int = 0
    processed_vectors: int = 0
    skipped_vectors: int = 0
    failed_vectors: int = 0
    duration_seconds: float = 0.0
    start_time: str = ""
    end_time: str = ""

    @classmethod
    def from_proto(cls, pb: ext_pb.RebuildStats) -> RebuildStats:
        return cls(
            total_vectors=pb.total_vectors,
            processed_vectors=pb.processed_vectors,
            skipped_vectors=pb.skipped_vectors,
            failed_vectors=pb.failed_vectors,
            duration_seconds=pb.duration_seconds,
            start_time=pb.start_time,
            end_time=pb.end_time,
        )

class RebuildTaskInfo(BaseModel):
    """Rebuild task information."""

    task_id: str = ""
    collection_name: str = ""
    state: RebuildTaskState = RebuildTaskState.TASK_PENDING
    progress: float = 0.0
    stats: RebuildStats | None = None
    error_message: str = ""
    created_at: str = ""
    started_at: str = ""
    finished_at: str | None = None
    current_phase: str = ""

    @classmethod
    def from_proto(cls, pb: ext_pb.RebuildTaskInfo) -> RebuildTaskInfo:
        return cls(
            task_id=pb.task_id,
            collection_name=pb.collection_name,
            state=RebuildTaskState(pb.state),
            progress=pb.progress,
            stats=RebuildStats.from_proto(pb.stats) if pb.HasField("stats") else None,
            error_message=pb.error_message,
            created_at=pb.created_at,
            started_at=pb.started_at,
            finished_at=pb.finished_at if pb.HasField("finished_at") else None,
            current_phase=pb.current_phase,
        )

# ─── Compact Types ───────────────────────────────────────────────────

class CompactOptions(BaseModel):
    """Collection compaction options."""

    target_segment_count: int | None = None
    force_merge_all: bool | None = None
    purge_deleted: bool | None = None
    rebuild_index: bool | None = None

    def to_proto(self) -> ext_pb.CompactOptions:
        pb = ext_pb.CompactOptions()
        if self.target_segment_count is not None:
            pb.target_segment_count = self.target_segment_count
        if self.force_merge_all is not None:
            pb.force_merge_all = self.force_merge_all
        if self.purge_deleted is not None:
            pb.purge_deleted = self.purge_deleted
        if self.rebuild_index is not None:
            pb.rebuild_index = self.rebuild_index
        return pb

    @classmethod
    def from_proto(cls, pb: ext_pb.CompactOptions) -> CompactOptions:
        return cls(
            target_segment_count=(
                pb.target_segment_count if pb.HasField("target_segment_count") else None
            ),
            force_merge_all=(pb.force_merge_all if pb.HasField("force_merge_all") else None),
            purge_deleted=pb.purge_deleted if pb.HasField("purge_deleted") else None,
            rebuild_index=pb.rebuild_index if pb.HasField("rebuild_index") else None,
        )

class CompactStats(BaseModel):
    """Collection compaction statistics."""

    segments_before: int = 0
    segments_after: int = 0
    vectors_removed: int = 0
    bytes_reclaimed: int = 0
    duration_seconds: float = 0.0

    @classmethod
    def from_proto(cls, pb: ext_pb.CompactStats) -> CompactStats:
        return cls(
            segments_before=pb.segments_before,
            segments_after=pb.segments_after,
            vectors_removed=pb.vectors_removed,
            bytes_reclaimed=pb.bytes_reclaimed,
            duration_seconds=pb.duration_seconds,
        )
