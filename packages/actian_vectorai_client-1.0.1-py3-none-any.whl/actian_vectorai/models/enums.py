#
# Copyright (c) 2026 by Actian Corporation
# All rights reserved.
#
# THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE
# OF ACTIAN CORP.
# The copyright notice above does not evidence any actual or intended
# publication of such source code.
#

"""Proto-aligned enumerations for the Actian VectorAI SDK.

Every IntEnum mirrors its protobuf counterpart exactly—same name,
same numeric value.  This guarantees that ``enum.value`` can be
passed directly to a proto message field.
"""

from __future__ import annotations

from enum import IntEnum

__all__ = [
    # collections.proto
    "Datatype",
    "Distance",
    "Modifier",
    "MultiVectorComparator",
    "CollectionStatus",
    "PayloadSchemaType",
    "QuantizationType",
    "CompressionRatio",
    "BinaryQuantizationEncoding",
    "ShardingMethod",
    "TokenizerType",
    "ReplicaState",
    "ReshardingDirection",
    "ShardTransferMethod",
    # points.proto
    "WriteOrderingType",
    "ReadConsistencyType",
    "Direction",
    "Fusion",
    "UpdateStatus",
    # actian_vectorai_collections_ext.proto
    "IndexAlgorithm",
    "IndexDriver",
    # StorageType removed — only the default engine is supported; hardcoded internally
    "DistanceMetric",
    "CollectionState",
    "VectorType",
    "RebuildDataSourceType",
    "RebuildTargetIndexType",
    "RebuildTaskState",
    # actian_vectorai_index.proto
    "IndexType",
    "CollectionHealthStatus",
]


# ─── collections.proto ────────────────────────────────────────────────


class Datatype(IntEnum):
    """Vector element data type."""

    Default = 0
    Float32 = 1
    Uint8 = 2
    Float16 = 3


class Distance(IntEnum):
    """Distance function for vector comparison."""

    UnknownDistance = 0
    Cosine = 1
    Euclid = 2
    Dot = 3


class Modifier(IntEnum):
    """Sparse vector modifier."""

    Non = 0  # 'None' is reserved in Python
    Idf = 1


class MultiVectorComparator(IntEnum):
    """Multi-vector comparison strategy."""

    MaxSim = 0


class CollectionStatus(IntEnum):
    """Collection health / readiness status."""

    UnknownCollectionStatus = 0
    Green = 1
    Yellow = 2
    Red = 3
    Grey = 4


class PayloadSchemaType(IntEnum):
    """Payload field data type."""

    UnknownType = 0
    Keyword = 1
    Integer = 2
    Float = 3
    Geo = 4
    Text = 5
    Bool = 6
    Datetime = 7
    Uuid = 8


class QuantizationType(IntEnum):
    """Quantization type."""

    UnknownQuantization = 0
    Int8 = 1


class CompressionRatio(IntEnum):
    """Product quantization compression ratio."""

    x4 = 0
    x8 = 1
    x16 = 2
    x32 = 3
    x64 = 4


class BinaryQuantizationEncoding(IntEnum):
    """Binary quantization encoding method."""

    OneBit = 0
    TwoBits = 1
    OneAndHalfBits = 2


class ShardingMethod(IntEnum):
    """Sharding strategy."""

    Auto = 0
    Custom = 1


class TokenizerType(IntEnum):
    """Text index tokenizer type."""

    Unknown = 0
    Prefix = 1
    Whitespace = 2
    Word = 3
    Multilingual = 4


class ReplicaState(IntEnum):
    """Shard replica state."""

    Active = 0
    Dead = 1
    Partial = 2
    Initializing = 3
    Listener = 4
    PartialSnapshot = 5
    Recovery = 6
    Resharding = 7
    ReshardingScaleDown = 8
    ActiveRead = 9


class ReshardingDirection(IntEnum):
    """Resharding direction."""

    Up = 0
    Down = 1


class ShardTransferMethod(IntEnum):
    """Shard transfer strategy."""

    StreamRecords = 0
    Snapshot = 1
    WalDelta = 2
    ReshardingStreamRecords = 3


# ─── points.proto ─────────────────────────────────────────────────────


class WriteOrderingType(IntEnum):
    """Write ordering guarantee level."""

    Weak = 0
    Medium = 1
    Strong = 2


class ReadConsistencyType(IntEnum):
    """Read consistency guarantee level."""

    All = 0
    Majority = 1
    Quorum = 2


class Direction(IntEnum):
    """Sort direction."""

    Asc = 0
    Desc = 1


class Fusion(IntEnum):
    """Fusion algorithm for multi-query results."""

    RRF = 0


class UpdateStatus(IntEnum):
    """Point update operation status."""

    UnknownUpdateStatus = 0
    Acknowledged = 1
    Completed = 2
    ClockRejected = 3

    def __str__(self) -> str:
        return self.name.lower()


# ─── actian_vectorai_collections_ext.proto ───────────────────────────────────────


class IndexAlgorithm(IntEnum):
    """VDE index algorithm."""

    HNSW = 0


class IndexDriver(IntEnum):
    """VDE index driver implementation."""

    FAISS = 0


class StorageType(IntEnum):
    """VDE storage backend type (internal — single engine supported)."""

    BVSTORE = 0


class DistanceMetric(IntEnum):
    """VDE distance metric."""

    COSINE = 0
    EUCLIDEAN = 1
    DOT = 2


class CollectionState(IntEnum):
    """VDE collection state."""

    READY = 0
    REBUILDING = 1
    STATE_ERROR = 2


class VectorType(IntEnum):
    """VDE vector type."""

    VECTOR_TYPE_DENSE = 0
    VECTOR_TYPE_SPARSE = 1
    VECTOR_TYPE_MULTI_DENSE = 2


class RebuildDataSourceType(IntEnum):
    """Rebuild data source type."""

    SOURCE_CURRENT_INDEX = 0
    SOURCE_STORAGE = 1
    SOURCE_SNAPSHOT = 2


class RebuildTargetIndexType(IntEnum):
    """Rebuild target index type."""

    TARGET_SAME = 0
    TARGET_HNSW = 1
    TARGET_FLAT = 2


class RebuildTaskState(IntEnum):
    """Rebuild task lifecycle state."""

    TASK_PENDING = 0
    TASK_RUNNING = 1
    TASK_PAUSED = 2
    TASK_COMPLETED = 3
    TASK_FAILED = 4
    TASK_CANCELLED = 5


# ─── actian_vectorai_index.proto ─────────────────────────────────────────────────


class IndexType(IntEnum):
    """VDE index type (multi-index support)."""

    INDEX_TYPE_AUTO = 0
    INDEX_TYPE_FLAT = 1
    INDEX_TYPE_HNSW = 2


class CollectionHealthStatus(IntEnum):
    """VDE collection health status."""

    HEALTH_UNKNOWN = 0
    HEALTH_GREEN = 1
    HEALTH_YELLOW = 2
    HEALTH_GREY = 3
    HEALTH_RED = 4
