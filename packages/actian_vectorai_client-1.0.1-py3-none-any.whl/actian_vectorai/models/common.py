#
# Copyright (c) 2026 by Actian Corporation
# All rights reserved.
#
# THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE
# OF ACTIAN CORP.
# The copyright notice above does not evidence any actual or intended
# publication of such source code.
#

"""Common model types shared across the SDK.

Covers proto messages from ``actian_vectorai_common.proto`` and ``json_with_int.proto``
plus lightweight helper types used across collection and point modules.
"""

from __future__ import annotations

import uuid
from typing import Any

from pydantic import BaseModel, Field

from actian_vectorai.proto import actian_vectorai_common_pb2 as common_pb

__all__ = [
    "PointId",
    "GeoPoint",
    "Filter",
    "Condition",
    "MinShould",
    "FieldCondition",
    "IsEmptyCondition",
    "IsNullCondition",
    "HasIdCondition",
    "HasVectorCondition",
    "NestedCondition",
    "Match",
    "Range",
    "DatetimeRange",
    "GeoBoundingBox",
    "GeoRadius",
    "GeoLineString",
    "GeoPolygon",
    "ValuesCount",
]

# ─── Point ID ─────────────────────────────────────────────────────────

PointIdValue = int | str | uuid.UUID
"""A point identifier: either a ``uint64`` numeric ID, a UUID string, or a ``uuid.UUID`` object."""

class PointId(BaseModel):
    """Wrapper around the proto ``PointId`` oneof.

    Accepts either ``num`` (integer) or ``uuid`` (string).
    """

    num: int | None = None
    uuid: str | None = None

    def to_proto(self) -> common_pb.PointId:
        pb = common_pb.PointId()
        if self.num is not None:
            pb.num = self.num
        elif self.uuid is not None:
            pb.uuid = self.uuid
        return pb

    @classmethod
    def from_proto(cls, pb: common_pb.PointId) -> PointId:
        which = pb.WhichOneof("point_id_options")
        if which == "num":
            return cls(num=pb.num)
        elif which == "uuid":
            return cls(uuid=pb.uuid)
        return cls()

    @classmethod
    def auto(cls, value: PointIdValue) -> PointId:
        """Create from int or string automatically."""
        if isinstance(value, int):
            return cls(num=value)
        return cls(uuid=str(value))

def _point_id_to_proto(value: PointIdValue) -> common_pb.PointId:
    """Convert a raw int/str to proto PointId."""
    if isinstance(value, PointId):
        return value.to_proto()
    return PointId.auto(value).to_proto()

# ─── Geo Types ────────────────────────────────────────────────────────

class GeoPoint(BaseModel):
    """Geographic coordinate."""

    lon: float = Field(..., description="Longitude")
    lat: float = Field(..., description="Latitude")

    def to_proto(self) -> common_pb.GeoPoint:
        return common_pb.GeoPoint(lon=self.lon, lat=self.lat)

    @classmethod
    def from_proto(cls, pb: common_pb.GeoPoint) -> GeoPoint:
        return cls(lon=pb.lon, lat=pb.lat)

class GeoLineString(BaseModel):
    """Ordered sequence of GeoPoints representing a line."""

    points: list[GeoPoint] = Field(default_factory=list)

    def to_proto(self) -> common_pb.GeoLineString:
        return common_pb.GeoLineString(points=[p.to_proto() for p in self.points])

    @classmethod
    def from_proto(cls, pb: common_pb.GeoLineString) -> GeoLineString:
        return cls(points=[GeoPoint.from_proto(p) for p in pb.points])

class GeoBoundingBox(BaseModel):
    """Rectangular geographic bounding box."""

    top_left: GeoPoint
    bottom_right: GeoPoint

    def to_proto(self) -> common_pb.GeoBoundingBox:
        return common_pb.GeoBoundingBox(
            top_left=self.top_left.to_proto(),
            bottom_right=self.bottom_right.to_proto(),
        )

    @classmethod
    def from_proto(cls, pb: common_pb.GeoBoundingBox) -> GeoBoundingBox:
        return cls(
            top_left=GeoPoint.from_proto(pb.top_left),
            bottom_right=GeoPoint.from_proto(pb.bottom_right),
        )

class GeoRadius(BaseModel):
    """Circular geographic area."""

    center: GeoPoint
    radius: float = Field(..., description="Radius in meters")

    def to_proto(self) -> common_pb.GeoRadius:
        return common_pb.GeoRadius(
            center=self.center.to_proto(),
            radius=self.radius,
        )

    @classmethod
    def from_proto(cls, pb: common_pb.GeoRadius) -> GeoRadius:
        return cls(center=GeoPoint.from_proto(pb.center), radius=pb.radius)

class GeoPolygon(BaseModel):
    """Geographic polygon with optional holes."""

    exterior: GeoLineString
    interiors: list[GeoLineString] = Field(default_factory=list)

    def to_proto(self) -> common_pb.GeoPolygon:
        return common_pb.GeoPolygon(
            exterior=self.exterior.to_proto(),
            interiors=[i.to_proto() for i in self.interiors],
        )

    @classmethod
    def from_proto(cls, pb: common_pb.GeoPolygon) -> GeoPolygon:
        return cls(
            exterior=GeoLineString.from_proto(pb.exterior),
            interiors=[GeoLineString.from_proto(i) for i in pb.interiors],
        )

# ─── Match / Range / Values ──────────────────────────────────────────

class Match(BaseModel):
    """Match condition for field filtering.

    Exactly one field should be set.
    """

    keyword: str | None = None
    integer: int | None = None
    boolean: bool | None = None
    text: str | None = None
    keywords: list[str] | None = None
    integers: list[int] | None = None
    except_integers: list[int] | None = None
    except_keywords: list[str] | None = None
    phrase: str | None = None
    text_any: str | None = None

    def to_proto(self) -> common_pb.Match:
        pb = common_pb.Match()
        if self.keyword is not None:
            pb.keyword = self.keyword
        elif self.integer is not None:
            pb.integer = self.integer
        elif self.boolean is not None:
            pb.boolean = self.boolean
        elif self.text is not None:
            pb.text = self.text
        elif self.keywords is not None:
            pb.keywords.CopyFrom(common_pb.RepeatedStrings(strings=self.keywords))
        elif self.integers is not None:
            pb.integers.CopyFrom(common_pb.RepeatedIntegers(integers=self.integers))
        elif self.except_integers is not None:
            pb.except_integers.CopyFrom(common_pb.RepeatedIntegers(integers=self.except_integers))
        elif self.except_keywords is not None:
            pb.except_keywords.CopyFrom(common_pb.RepeatedStrings(strings=self.except_keywords))
        elif self.phrase is not None:
            pb.phrase = self.phrase
        elif self.text_any is not None:
            pb.text_any = self.text_any
        return pb

    @classmethod
    def from_proto(cls, pb: common_pb.Match) -> Match:
        which = pb.WhichOneof("match_value")
        if which == "keyword":
            return cls(keyword=pb.keyword)
        if which == "integer":
            return cls(integer=pb.integer)
        if which == "boolean":
            return cls(boolean=pb.boolean)
        if which == "text":
            return cls(text=pb.text)
        if which == "keywords":
            return cls(keywords=list(pb.keywords.strings))
        if which == "integers":
            return cls(integers=list(pb.integers.integers))
        if which == "except_integers":
            return cls(except_integers=list(pb.except_integers.integers))
        if which == "except_keywords":
            return cls(except_keywords=list(pb.except_keywords.strings))
        if which == "phrase":
            return cls(phrase=pb.phrase)
        if which == "text_any":
            return cls(text_any=pb.text_any)
        return cls()

class Range(BaseModel):
    """Numeric range condition."""

    lt: float | None = None
    gt: float | None = None
    gte: float | None = None
    lte: float | None = None

    def to_proto(self) -> common_pb.Range:
        pb = common_pb.Range()
        if self.lt is not None:
            pb.lt = self.lt
        if self.gt is not None:
            pb.gt = self.gt
        if self.gte is not None:
            pb.gte = self.gte
        if self.lte is not None:
            pb.lte = self.lte
        return pb

    @classmethod
    def from_proto(cls, pb: common_pb.Range) -> Range:
        return cls(
            lt=pb.lt if pb.HasField("lt") else None,
            gt=pb.gt if pb.HasField("gt") else None,
            gte=pb.gte if pb.HasField("gte") else None,
            lte=pb.lte if pb.HasField("lte") else None,
        )

class DatetimeRange(BaseModel):
    """Datetime range condition (ISO-8601 timestamps)."""

    lt: str | None = None
    gt: str | None = None
    gte: str | None = None
    lte: str | None = None

    def to_proto(self) -> common_pb.DatetimeRange:
        from google.protobuf.timestamp_pb2 import Timestamp

        pb = common_pb.DatetimeRange()
        for attr in ("lt", "gt", "gte", "lte"):
            val = getattr(self, attr)
            if val is not None:
                ts = Timestamp()
                ts.FromJsonString(val if val.endswith("Z") else val + "Z")
                getattr(pb, attr).CopyFrom(ts)
        return pb

    @classmethod
    def from_proto(cls, pb: common_pb.DatetimeRange) -> DatetimeRange:
        result: dict[str, str | None] = {}
        for attr in ("lt", "gt", "gte", "lte"):
            if pb.HasField(attr):
                result[attr] = getattr(pb, attr).ToJsonString()
            else:
                result[attr] = None
        return cls(**result)

class ValuesCount(BaseModel):
    """Count-of-values condition."""

    lt: int | None = None
    gt: int | None = None
    gte: int | None = None
    lte: int | None = None

    def to_proto(self) -> common_pb.ValuesCount:
        pb = common_pb.ValuesCount()
        if self.lt is not None:
            pb.lt = self.lt
        if self.gt is not None:
            pb.gt = self.gt
        if self.gte is not None:
            pb.gte = self.gte
        if self.lte is not None:
            pb.lte = self.lte
        return pb

    @classmethod
    def from_proto(cls, pb: common_pb.ValuesCount) -> ValuesCount:
        return cls(
            lt=pb.lt if pb.HasField("lt") else None,
            gt=pb.gt if pb.HasField("gt") else None,
            gte=pb.gte if pb.HasField("gte") else None,
            lte=pb.lte if pb.HasField("lte") else None,
        )

# ─── Field Condition ──────────────────────────────────────────────────

class FieldCondition(BaseModel):
    """Condition on a specific payload field."""

    key: str
    match: Match | None = None
    range: Range | None = None
    geo_bounding_box: GeoBoundingBox | None = None
    geo_radius: GeoRadius | None = None
    values_count: ValuesCount | None = None
    geo_polygon: GeoPolygon | None = None
    datetime_range: DatetimeRange | None = None
    is_empty: bool | None = None
    is_null: bool | None = None

    def to_proto(self) -> common_pb.FieldCondition:
        pb = common_pb.FieldCondition(key=self.key)
        if self.match is not None:
            pb.match.CopyFrom(self.match.to_proto())
        if self.range is not None:
            pb.range.CopyFrom(self.range.to_proto())
        if self.geo_bounding_box is not None:
            pb.geo_bounding_box.CopyFrom(self.geo_bounding_box.to_proto())
        if self.geo_radius is not None:
            pb.geo_radius.CopyFrom(self.geo_radius.to_proto())
        if self.values_count is not None:
            pb.values_count.CopyFrom(self.values_count.to_proto())
        if self.geo_polygon is not None:
            pb.geo_polygon.CopyFrom(self.geo_polygon.to_proto())
        if self.datetime_range is not None:
            pb.datetime_range.CopyFrom(self.datetime_range.to_proto())
        if self.is_empty is not None:
            pb.is_empty = self.is_empty
        if self.is_null is not None:
            pb.is_null = self.is_null
        return pb

    @classmethod
    def from_proto(cls, pb: common_pb.FieldCondition) -> FieldCondition:
        kwargs: dict[str, Any] = {"key": pb.key}
        if pb.HasField("match"):
            kwargs["match"] = Match.from_proto(pb.match)
        if pb.HasField("range"):
            kwargs["range"] = Range.from_proto(pb.range)
        if pb.HasField("geo_bounding_box"):
            kwargs["geo_bounding_box"] = GeoBoundingBox.from_proto(pb.geo_bounding_box)
        if pb.HasField("geo_radius"):
            kwargs["geo_radius"] = GeoRadius.from_proto(pb.geo_radius)
        if pb.HasField("values_count"):
            kwargs["values_count"] = ValuesCount.from_proto(pb.values_count)
        if pb.HasField("geo_polygon"):
            kwargs["geo_polygon"] = GeoPolygon.from_proto(pb.geo_polygon)
        if pb.HasField("datetime_range"):
            kwargs["datetime_range"] = DatetimeRange.from_proto(pb.datetime_range)
        if pb.HasField("is_empty"):
            kwargs["is_empty"] = pb.is_empty
        if pb.HasField("is_null"):
            kwargs["is_null"] = pb.is_null
        return cls(**kwargs)

# ─── Simple Conditions ────────────────────────────────────────────────

class IsEmptyCondition(BaseModel):
    """Check if a field is empty."""

    key: str

    def to_proto(self) -> common_pb.IsEmptyCondition:
        return common_pb.IsEmptyCondition(key=self.key)

    @classmethod
    def from_proto(cls, pb: common_pb.IsEmptyCondition) -> IsEmptyCondition:
        return cls(key=pb.key)

class IsNullCondition(BaseModel):
    """Check if a field is null."""

    key: str

    def to_proto(self) -> common_pb.IsNullCondition:
        return common_pb.IsNullCondition(key=self.key)

    @classmethod
    def from_proto(cls, pb: common_pb.IsNullCondition) -> IsNullCondition:
        return cls(key=pb.key)

class HasIdCondition(BaseModel):
    """Check if point has any of the given IDs."""

    has_id: list[PointId] = Field(default_factory=list)

    def to_proto(self) -> common_pb.HasIdCondition:
        return common_pb.HasIdCondition(has_id=[pid.to_proto() for pid in self.has_id])

    @classmethod
    def from_proto(cls, pb: common_pb.HasIdCondition) -> HasIdCondition:
        return cls(has_id=[PointId.from_proto(pid) for pid in pb.has_id])

class HasVectorCondition(BaseModel):
    """Check if point has a specific named vector."""

    has_vector: str

    def to_proto(self) -> common_pb.HasVectorCondition:
        return common_pb.HasVectorCondition(has_vector=self.has_vector)

    @classmethod
    def from_proto(cls, pb: common_pb.HasVectorCondition) -> HasVectorCondition:
        return cls(has_vector=pb.has_vector)

# ─── Forward-ref enabled: Condition, NestedCondition, Filter ──────────

class Condition(BaseModel):
    """A single filter condition (oneof)."""

    field: FieldCondition | None = None
    is_empty: IsEmptyCondition | None = None
    has_id: HasIdCondition | None = None
    filter: Filter | None = None
    is_null: IsNullCondition | None = None
    nested: NestedCondition | None = None
    has_vector: HasVectorCondition | None = None

    def to_proto(self) -> common_pb.Condition:
        pb = common_pb.Condition()
        if self.field is not None:
            pb.field.CopyFrom(self.field.to_proto())
        elif self.is_empty is not None:
            pb.is_empty.CopyFrom(self.is_empty.to_proto())
        elif self.has_id is not None:
            pb.has_id.CopyFrom(self.has_id.to_proto())
        elif self.filter is not None:
            pb.filter.CopyFrom(self.filter.to_proto())
        elif self.is_null is not None:
            pb.is_null.CopyFrom(self.is_null.to_proto())
        elif self.nested is not None:
            pb.nested.CopyFrom(self.nested.to_proto())
        elif self.has_vector is not None:
            pb.has_vector.CopyFrom(self.has_vector.to_proto())
        return pb

    @classmethod
    def from_proto(cls, pb: common_pb.Condition) -> Condition:
        which = pb.WhichOneof("condition_one_of")
        if which == "field":
            return cls(field=FieldCondition.from_proto(pb.field))
        if which == "is_empty":
            return cls(is_empty=IsEmptyCondition.from_proto(pb.is_empty))
        if which == "has_id":
            return cls(has_id=HasIdCondition.from_proto(pb.has_id))
        if which == "filter":
            return cls(filter=Filter.from_proto(pb.filter))
        if which == "is_null":
            return cls(is_null=IsNullCondition.from_proto(pb.is_null))
        if which == "nested":
            return cls(nested=NestedCondition.from_proto(pb.nested))
        if which == "has_vector":
            return cls(has_vector=HasVectorCondition.from_proto(pb.has_vector))
        return cls()

class NestedCondition(BaseModel):
    """Filter on a nested payload object."""

    key: str
    filter: Filter

    def to_proto(self) -> common_pb.NestedCondition:
        return common_pb.NestedCondition(
            key=self.key,
            filter=self.filter.to_proto(),
        )

    @classmethod
    def from_proto(cls, pb: common_pb.NestedCondition) -> NestedCondition:
        return cls(key=pb.key, filter=Filter.from_proto(pb.filter))

class MinShould(BaseModel):
    """Minimum number of conditions that should match."""

    conditions: list[Condition] = Field(default_factory=list)
    min_count: int = 1

    def to_proto(self) -> common_pb.MinShould:
        return common_pb.MinShould(
            conditions=[c.to_proto() for c in self.conditions],
            min_count=self.min_count,
        )

    @classmethod
    def from_proto(cls, pb: common_pb.MinShould) -> MinShould:
        return cls(
            conditions=[Condition.from_proto(c) for c in pb.conditions],
            min_count=pb.min_count,
        )

class Filter(BaseModel):
    """Filtering conditions for point retrieval.

    Combines ``should`` (OR), ``must`` (AND), ``must_not`` (NOT),
    and ``min_should`` clauses.
    """

    should: list[Condition] = Field(default_factory=list)
    must: list[Condition] = Field(default_factory=list)
    must_not: list[Condition] = Field(default_factory=list)
    min_should: MinShould | None = None

    def to_proto(self) -> common_pb.Filter:
        pb = common_pb.Filter(
            should=[c.to_proto() for c in self.should],
            must=[c.to_proto() for c in self.must],
            must_not=[c.to_proto() for c in self.must_not],
        )
        if self.min_should is not None:
            pb.min_should.CopyFrom(self.min_should.to_proto())
        return pb

    @classmethod
    def from_proto(cls, pb: common_pb.Filter) -> Filter:
        return cls(
            should=[Condition.from_proto(c) for c in pb.should],
            must=[Condition.from_proto(c) for c in pb.must],
            must_not=[Condition.from_proto(c) for c in pb.must_not],
            min_should=(MinShould.from_proto(pb.min_should) if pb.HasField("min_should") else None),
        )

# Rebuild forward references for recursive models
Condition.model_rebuild()
NestedCondition.model_rebuild()
Filter.model_rebuild()
