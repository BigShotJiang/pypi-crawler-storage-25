#
# Copyright (c) 2026 by Actian Corporation
# All rights reserved.
#
# THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE
# OF ACTIAN CORP.
# The copyright notice above does not evidence any actual or intended
# publication of such source code.
#

"""Collection-related Pydantic models with proto conversion.

Maps every user-facing message from ``collections.proto``
and ``collections_service.proto``.
"""

from __future__ import annotations

from typing import ClassVar

from pydantic import BaseModel, Field, field_validator

from actian_vectorai.exceptions import ValidationError
from actian_vectorai.models.enums import (
    BinaryQuantizationEncoding,
    CollectionHealthStatus,
    CollectionStatus,
    CompressionRatio,
    Datatype,
    Distance,
    IndexType,
    Modifier,
    MultiVectorComparator,
    PayloadSchemaType,
    QuantizationType,
    ShardingMethod,
    TokenizerType,
)
from actian_vectorai.proto import actian_vectorai_collections_pb2 as col_pb

__all__ = [
    # Config types
    "VectorParams",
    "VectorParamsDiff",
    "SparseVectorParams",
    "MultiVectorConfig",
    "HnswConfigDiff",
    "SparseIndexConfig",
    "WalConfigDiff",
    "OptimizersConfigDiff",
    "ScalarQuantization",
    "ProductQuantization",
    "BinaryQuantization",
    "QuantizationConfig",
    "QuantizationConfigDiff",
    # Payload index params
    "KeywordIndexParams",
    "IntegerIndexParams",
    "FloatIndexParams",
    "GeoIndexParams",
    "TextIndexParams",
    "BoolIndexParams",
    "DatetimeIndexParams",
    "UuidIndexParams",
    "PayloadIndexParams",
    "PayloadSchemaInfo",
    # Collection CRUD
    "CollectionDescription",
    "CollectionParams",
    "CollectionInfo",
    "CollectionOperationResponse",
    # Optimiser status
    "OptimizerStatus",
]

# ─── HNSW / WAL / Optimizer Config ───────────────────────────────────

class HnswConfigDiff(BaseModel):
    """HNSW index configuration (diff-style, all optional)."""

    m: int | None = None
    ef_construct: int | None = None
    full_scan_threshold: int | None = None
    max_indexing_threads: int | None = None
    on_disk: bool | None = None
    payload_m: int | None = None
    inline_storage: bool | None = None

    def to_proto(self) -> col_pb.HnswConfigDiff:
        pb = col_pb.HnswConfigDiff()
        if self.m is not None:
            pb.m = self.m
        if self.ef_construct is not None:
            pb.ef_construct = self.ef_construct
        if self.full_scan_threshold is not None:
            pb.full_scan_threshold = self.full_scan_threshold
        if self.max_indexing_threads is not None:
            pb.max_indexing_threads = self.max_indexing_threads
        if self.on_disk is not None:
            pb.on_disk = self.on_disk
        if self.payload_m is not None:
            pb.payload_m = self.payload_m
        if self.inline_storage is not None:
            pb.inline_storage = self.inline_storage
        return pb

    @classmethod
    def from_proto(cls, pb: col_pb.HnswConfigDiff) -> HnswConfigDiff:
        return cls(
            m=pb.m if pb.HasField("m") else None,
            ef_construct=pb.ef_construct if pb.HasField("ef_construct") else None,
            full_scan_threshold=(
                pb.full_scan_threshold if pb.HasField("full_scan_threshold") else None
            ),
            max_indexing_threads=(
                pb.max_indexing_threads if pb.HasField("max_indexing_threads") else None
            ),
            on_disk=pb.on_disk if pb.HasField("on_disk") else None,
            payload_m=pb.payload_m if pb.HasField("payload_m") else None,
            inline_storage=pb.inline_storage if pb.HasField("inline_storage") else None,
        )

class SparseIndexConfig(BaseModel):
    """Sparse vector index configuration."""

    full_scan_threshold: int | None = None
    on_disk: bool | None = None
    datatype: Datatype | None = None

    def to_proto(self) -> col_pb.SparseIndexConfig:
        pb = col_pb.SparseIndexConfig()
        if self.full_scan_threshold is not None:
            pb.full_scan_threshold = self.full_scan_threshold
        if self.on_disk is not None:
            pb.on_disk = self.on_disk
        if self.datatype is not None:
            pb.datatype = self.datatype.value
        return pb

    @classmethod
    def from_proto(cls, pb: col_pb.SparseIndexConfig) -> SparseIndexConfig:
        return cls(
            full_scan_threshold=(
                pb.full_scan_threshold if pb.HasField("full_scan_threshold") else None
            ),
            on_disk=pb.on_disk if pb.HasField("on_disk") else None,
            datatype=Datatype(pb.datatype) if pb.HasField("datatype") else None,
        )

class WalConfigDiff(BaseModel):
    """Write-Ahead-Log configuration."""

    wal_capacity_mb: int | None = None
    wal_segments_ahead: int | None = None
    wal_retain_closed: int | None = None

    def to_proto(self) -> col_pb.WalConfigDiff:
        pb = col_pb.WalConfigDiff()
        if self.wal_capacity_mb is not None:
            pb.wal_capacity_mb = self.wal_capacity_mb
        if self.wal_segments_ahead is not None:
            pb.wal_segments_ahead = self.wal_segments_ahead
        if self.wal_retain_closed is not None:
            pb.wal_retain_closed = self.wal_retain_closed
        return pb

    @classmethod
    def from_proto(cls, pb: col_pb.WalConfigDiff) -> WalConfigDiff:
        return cls(
            wal_capacity_mb=pb.wal_capacity_mb if pb.HasField("wal_capacity_mb") else None,
            wal_segments_ahead=(
                pb.wal_segments_ahead if pb.HasField("wal_segments_ahead") else None
            ),
            wal_retain_closed=(pb.wal_retain_closed if pb.HasField("wal_retain_closed") else None),
        )

class OptimizersConfigDiff(BaseModel):
    """Optimizer configuration (diff-style)."""

    deleted_threshold: float | None = None
    vacuum_min_vector_number: int | None = None
    default_segment_number: int | None = None
    max_segment_size: int | None = None
    memmap_threshold: int | None = None
    indexing_threshold: int | None = None
    flush_interval_sec: int | None = None
    # VDE extensions
    min_interval_seconds: int | None = None
    trigger_type: str | None = None
    source_type: str | None = None
    target_type: str | None = None
    pipeline_type: str | None = None
    verifier_enabled: bool | None = None

    def to_proto(self) -> col_pb.OptimizersConfigDiff:
        pb = col_pb.OptimizersConfigDiff()
        if self.deleted_threshold is not None:
            pb.deleted_threshold = self.deleted_threshold
        if self.vacuum_min_vector_number is not None:
            pb.vacuum_min_vector_number = self.vacuum_min_vector_number
        if self.default_segment_number is not None:
            pb.default_segment_number = self.default_segment_number
        if self.max_segment_size is not None:
            pb.max_segment_size = self.max_segment_size
        if self.memmap_threshold is not None:
            pb.memmap_threshold = self.memmap_threshold
        if self.indexing_threshold is not None:
            pb.indexing_threshold = self.indexing_threshold
        if self.flush_interval_sec is not None:
            pb.flush_interval_sec = self.flush_interval_sec
        if self.min_interval_seconds is not None:
            pb.min_interval_seconds = self.min_interval_seconds
        if self.trigger_type is not None:
            pb.trigger_type = self.trigger_type
        if self.source_type is not None:
            pb.source_type = self.source_type
        if self.target_type is not None:
            pb.target_type = self.target_type
        if self.pipeline_type is not None:
            pb.pipeline_type = self.pipeline_type
        if self.verifier_enabled is not None:
            pb.verifier_enabled = self.verifier_enabled
        return pb

    @classmethod
    def from_proto(cls, pb: col_pb.OptimizersConfigDiff) -> OptimizersConfigDiff:
        return cls(
            deleted_threshold=(pb.deleted_threshold if pb.HasField("deleted_threshold") else None),
            vacuum_min_vector_number=(
                pb.vacuum_min_vector_number if pb.HasField("vacuum_min_vector_number") else None
            ),
            default_segment_number=(
                pb.default_segment_number if pb.HasField("default_segment_number") else None
            ),
            max_segment_size=pb.max_segment_size if pb.HasField("max_segment_size") else None,
            memmap_threshold=pb.memmap_threshold if pb.HasField("memmap_threshold") else None,
            indexing_threshold=(
                pb.indexing_threshold if pb.HasField("indexing_threshold") else None
            ),
            flush_interval_sec=(
                pb.flush_interval_sec if pb.HasField("flush_interval_sec") else None
            ),
            min_interval_seconds=(
                pb.min_interval_seconds if pb.HasField("min_interval_seconds") else None
            ),
            trigger_type=pb.trigger_type if pb.HasField("trigger_type") else None,
            source_type=pb.source_type if pb.HasField("source_type") else None,
            target_type=pb.target_type if pb.HasField("target_type") else None,
            pipeline_type=pb.pipeline_type if pb.HasField("pipeline_type") else None,
            verifier_enabled=(pb.verifier_enabled if pb.HasField("verifier_enabled") else None),
        )

# ─── Quantization ────────────────────────────────────────────────────

class ScalarQuantization(BaseModel):
    """Scalar quantization config."""

    type: QuantizationType = QuantizationType.Int8
    quantile: float | None = None
    always_ram: bool | None = None

    def to_proto(self) -> col_pb.ScalarQuantization:
        pb = col_pb.ScalarQuantization(type=self.type.value)
        if self.quantile is not None:
            pb.quantile = self.quantile
        if self.always_ram is not None:
            pb.always_ram = self.always_ram
        return pb

    @classmethod
    def from_proto(cls, pb: col_pb.ScalarQuantization) -> ScalarQuantization:
        return cls(
            type=QuantizationType(pb.type),
            quantile=pb.quantile if pb.HasField("quantile") else None,
            always_ram=pb.always_ram if pb.HasField("always_ram") else None,
        )

class ProductQuantization(BaseModel):
    """Product quantization config."""

    compression: CompressionRatio = CompressionRatio.x4
    always_ram: bool | None = None

    def to_proto(self) -> col_pb.ProductQuantization:
        pb = col_pb.ProductQuantization(compression=self.compression.value)
        if self.always_ram is not None:
            pb.always_ram = self.always_ram
        return pb

    @classmethod
    def from_proto(cls, pb: col_pb.ProductQuantization) -> ProductQuantization:
        return cls(
            compression=CompressionRatio(pb.compression),
            always_ram=pb.always_ram if pb.HasField("always_ram") else None,
        )

class BinaryQuantization(BaseModel):
    """Binary quantization config."""

    always_ram: bool | None = None
    encoding: BinaryQuantizationEncoding | None = None

    def to_proto(self) -> col_pb.BinaryQuantization:
        pb = col_pb.BinaryQuantization()
        if self.always_ram is not None:
            pb.always_ram = self.always_ram
        if self.encoding is not None:
            pb.encoding = self.encoding.value
        return pb

    @classmethod
    def from_proto(cls, pb: col_pb.BinaryQuantization) -> BinaryQuantization:
        return cls(
            always_ram=pb.always_ram if pb.HasField("always_ram") else None,
            encoding=(BinaryQuantizationEncoding(pb.encoding) if pb.HasField("encoding") else None),
        )

class QuantizationConfig(BaseModel):
    """Quantization configuration (oneof)."""

    scalar: ScalarQuantization | None = None
    product: ProductQuantization | None = None
    binary: BinaryQuantization | None = None

    def to_proto(self) -> col_pb.QuantizationConfig:
        pb = col_pb.QuantizationConfig()
        if self.scalar is not None:
            pb.scalar.CopyFrom(self.scalar.to_proto())
        elif self.product is not None:
            pb.product.CopyFrom(self.product.to_proto())
        elif self.binary is not None:
            pb.binary.CopyFrom(self.binary.to_proto())
        return pb

    @classmethod
    def from_proto(cls, pb: col_pb.QuantizationConfig) -> QuantizationConfig:
        which = pb.WhichOneof("quantization")
        if which == "scalar":
            return cls(scalar=ScalarQuantization.from_proto(pb.scalar))
        if which == "product":
            return cls(product=ProductQuantization.from_proto(pb.product))
        if which == "binary":
            return cls(binary=BinaryQuantization.from_proto(pb.binary))
        return cls()

class QuantizationConfigDiff(BaseModel):
    """Quantization configuration diff (for updates)."""

    scalar: ScalarQuantization | None = None
    product: ProductQuantization | None = None
    binary: BinaryQuantization | None = None
    disabled: bool = False

    def to_proto(self) -> col_pb.QuantizationConfigDiff:
        pb = col_pb.QuantizationConfigDiff()
        if self.disabled:
            pb.disabled.CopyFrom(col_pb.Disabled())
        elif self.scalar is not None:
            pb.scalar.CopyFrom(self.scalar.to_proto())
        elif self.product is not None:
            pb.product.CopyFrom(self.product.to_proto())
        elif self.binary is not None:
            pb.binary.CopyFrom(self.binary.to_proto())
        return pb

    @classmethod
    def from_proto(cls, pb: col_pb.QuantizationConfigDiff) -> QuantizationConfigDiff:
        which = pb.WhichOneof("quantization")
        if which == "disabled":
            return cls(disabled=True)
        if which == "scalar":
            return cls(scalar=ScalarQuantization.from_proto(pb.scalar))
        if which == "product":
            return cls(product=ProductQuantization.from_proto(pb.product))
        if which == "binary":
            return cls(binary=BinaryQuantization.from_proto(pb.binary))
        return cls()

# ─── Vector Params ───────────────────────────────────────────────────

class MultiVectorConfig(BaseModel):
    """Multi-vector comparison config."""

    comparator: MultiVectorComparator = MultiVectorComparator.MaxSim

    def to_proto(self) -> col_pb.MultiVectorConfig:
        return col_pb.MultiVectorConfig(comparator=self.comparator.value)

    @classmethod
    def from_proto(cls, pb: col_pb.MultiVectorConfig) -> MultiVectorConfig:
        return cls(comparator=MultiVectorComparator(pb.comparator))

class SparseVectorParams(BaseModel):
    """Sparse vector parameters."""

    index: SparseIndexConfig | None = None
    modifier: Modifier | None = None

    def to_proto(self) -> col_pb.SparseVectorParams:
        pb = col_pb.SparseVectorParams()
        if self.index is not None:
            pb.index.CopyFrom(self.index.to_proto())
        if self.modifier is not None:
            pb.modifier = self.modifier.value
        return pb

    @classmethod
    def from_proto(cls, pb: col_pb.SparseVectorParams) -> SparseVectorParams:
        return cls(
            index=SparseIndexConfig.from_proto(pb.index) if pb.HasField("index") else None,
            modifier=Modifier(pb.modifier) if pb.HasField("modifier") else None,
        )

class VectorParams(BaseModel):
    """Dense vector parameters for collection creation."""

    size: int = Field(..., description="Vector dimension")
    distance: Distance = Distance.Cosine
    hnsw_config: HnswConfigDiff | None = None
    quantization_config: QuantizationConfig | None = None
    on_disk: bool | None = None
    datatype: Datatype | None = None
    multivector_config: MultiVectorConfig | None = None

    MAX_DIMENSION: ClassVar[int] = 8192

    @field_validator("size", mode="before")
    @classmethod
    def validate_size(cls, v: int) -> int:
        if not isinstance(v, int) or isinstance(v, bool):
            raise ValueError(f"size must be an integer, got {type(v).__name__}")
        if v < 0:
            raise ValueError(f"size must be >= 0, got {v}")
        if v > VectorParams.MAX_DIMENSION:
            raise ValidationError(
                f"size {v} exceeds maximum allowed dimension of {VectorParams.MAX_DIMENSION}",
                field="size",
            )
        return v

    def to_proto(self) -> col_pb.VectorParams:
        pb = col_pb.VectorParams(size=self.size, distance=self.distance.value)
        if self.hnsw_config is not None:
            pb.hnsw_config.CopyFrom(self.hnsw_config.to_proto())
        if self.quantization_config is not None:
            pb.quantization_config.CopyFrom(self.quantization_config.to_proto())
        if self.on_disk is not None:
            pb.on_disk = self.on_disk
        if self.datatype is not None:
            pb.datatype = self.datatype.value
        if self.multivector_config is not None:
            pb.multivector_config.CopyFrom(self.multivector_config.to_proto())
        return pb

    @classmethod
    def from_proto(cls, pb: col_pb.VectorParams) -> VectorParams:
        return cls(
            size=pb.size,
            distance=Distance(pb.distance),
            hnsw_config=(
                HnswConfigDiff.from_proto(pb.hnsw_config) if pb.HasField("hnsw_config") else None
            ),
            quantization_config=(
                QuantizationConfig.from_proto(pb.quantization_config)
                if pb.HasField("quantization_config")
                else None
            ),
            on_disk=pb.on_disk if pb.HasField("on_disk") else None,
            datatype=Datatype(pb.datatype) if pb.HasField("datatype") else None,
            multivector_config=(
                MultiVectorConfig.from_proto(pb.multivector_config)
                if pb.HasField("multivector_config")
                else None
            ),
        )

class VectorParamsDiff(BaseModel):
    """Diff-style vector params for updates."""

    hnsw_config: HnswConfigDiff | None = None
    quantization_config: QuantizationConfigDiff | None = None
    on_disk: bool | None = None

    def to_proto(self) -> col_pb.VectorParamsDiff:
        pb = col_pb.VectorParamsDiff()
        if self.hnsw_config is not None:
            pb.hnsw_config.CopyFrom(self.hnsw_config.to_proto())
        if self.quantization_config is not None:
            pb.quantization_config.CopyFrom(self.quantization_config.to_proto())
        if self.on_disk is not None:
            pb.on_disk = self.on_disk
        return pb

    @classmethod
    def from_proto(cls, pb: col_pb.VectorParamsDiff) -> VectorParamsDiff:
        return cls(
            hnsw_config=(
                HnswConfigDiff.from_proto(pb.hnsw_config) if pb.HasField("hnsw_config") else None
            ),
            quantization_config=(
                QuantizationConfigDiff.from_proto(pb.quantization_config)
                if pb.HasField("quantization_config")
                else None
            ),
            on_disk=pb.on_disk if pb.HasField("on_disk") else None,
        )

# ─── Payload Index Params ────────────────────────────────────────────

class KeywordIndexParams(BaseModel):
    """Index parameters for keyword (string) payload fields."""

    is_tenant: bool | None = None
    on_disk: bool | None = None

    def to_proto(self) -> col_pb.KeywordIndexParams:
        pb = col_pb.KeywordIndexParams()
        if self.is_tenant is not None:
            pb.is_tenant = self.is_tenant
        if self.on_disk is not None:
            pb.on_disk = self.on_disk
        return pb

    @classmethod
    def from_proto(cls, pb: col_pb.KeywordIndexParams) -> KeywordIndexParams:
        return cls(
            is_tenant=pb.is_tenant if pb.HasField("is_tenant") else None,
            on_disk=pb.on_disk if pb.HasField("on_disk") else None,
        )

class IntegerIndexParams(BaseModel):
    """Index parameters for integer payload fields."""

    lookup: bool | None = None
    range: bool | None = None
    is_principal: bool | None = None
    on_disk: bool | None = None

    def to_proto(self) -> col_pb.IntegerIndexParams:
        pb = col_pb.IntegerIndexParams()
        if self.lookup is not None:
            pb.lookup = self.lookup
        if self.range is not None:
            pb.range = self.range
        if self.is_principal is not None:
            pb.is_principal = self.is_principal
        if self.on_disk is not None:
            pb.on_disk = self.on_disk
        return pb

    @classmethod
    def from_proto(cls, pb: col_pb.IntegerIndexParams) -> IntegerIndexParams:
        return cls(
            lookup=pb.lookup if pb.HasField("lookup") else None,
            range=pb.range if pb.HasField("range") else None,
            is_principal=pb.is_principal if pb.HasField("is_principal") else None,
            on_disk=pb.on_disk if pb.HasField("on_disk") else None,
        )

class FloatIndexParams(BaseModel):
    """Index parameters for float payload fields."""

    on_disk: bool | None = None
    is_principal: bool | None = None

    def to_proto(self) -> col_pb.FloatIndexParams:
        pb = col_pb.FloatIndexParams()
        if self.on_disk is not None:
            pb.on_disk = self.on_disk
        if self.is_principal is not None:
            pb.is_principal = self.is_principal
        return pb

    @classmethod
    def from_proto(cls, pb: col_pb.FloatIndexParams) -> FloatIndexParams:
        return cls(
            on_disk=pb.on_disk if pb.HasField("on_disk") else None,
            is_principal=pb.is_principal if pb.HasField("is_principal") else None,
        )

class GeoIndexParams(BaseModel):
    """Index parameters for geo-point payload fields."""

    on_disk: bool | None = None

    def to_proto(self) -> col_pb.GeoIndexParams:
        pb = col_pb.GeoIndexParams()
        if self.on_disk is not None:
            pb.on_disk = self.on_disk
        return pb

    @classmethod
    def from_proto(cls, pb: col_pb.GeoIndexParams) -> GeoIndexParams:
        return cls(on_disk=pb.on_disk if pb.HasField("on_disk") else None)

class TextIndexParams(BaseModel):
    """Index parameters for full-text search on text payload fields."""

    tokenizer: TokenizerType = TokenizerType.Unknown
    lowercase: bool | None = None
    min_token_len: int | None = None
    max_token_len: int | None = None
    on_disk: bool | None = None
    phrase_matching: bool | None = None
    ascii_folding: bool | None = None

    def to_proto(self) -> col_pb.TextIndexParams:
        pb = col_pb.TextIndexParams(tokenizer=self.tokenizer.value)
        if self.lowercase is not None:
            pb.lowercase = self.lowercase
        if self.min_token_len is not None:
            pb.min_token_len = self.min_token_len
        if self.max_token_len is not None:
            pb.max_token_len = self.max_token_len
        if self.on_disk is not None:
            pb.on_disk = self.on_disk
        if self.phrase_matching is not None:
            pb.phrase_matching = self.phrase_matching
        if self.ascii_folding is not None:
            pb.ascii_folding = self.ascii_folding
        return pb

    @classmethod
    def from_proto(cls, pb: col_pb.TextIndexParams) -> TextIndexParams:
        return cls(
            tokenizer=TokenizerType(pb.tokenizer),
            lowercase=pb.lowercase if pb.HasField("lowercase") else None,
            min_token_len=pb.min_token_len if pb.HasField("min_token_len") else None,
            max_token_len=pb.max_token_len if pb.HasField("max_token_len") else None,
            on_disk=pb.on_disk if pb.HasField("on_disk") else None,
            phrase_matching=pb.phrase_matching if pb.HasField("phrase_matching") else None,
            ascii_folding=pb.ascii_folding if pb.HasField("ascii_folding") else None,
        )

class BoolIndexParams(BaseModel):
    """Index parameters for boolean payload fields."""

    on_disk: bool | None = None

    def to_proto(self) -> col_pb.BoolIndexParams:
        pb = col_pb.BoolIndexParams()
        if self.on_disk is not None:
            pb.on_disk = self.on_disk
        return pb

    @classmethod
    def from_proto(cls, pb: col_pb.BoolIndexParams) -> BoolIndexParams:
        return cls(on_disk=pb.on_disk if pb.HasField("on_disk") else None)

class DatetimeIndexParams(BaseModel):
    """Index parameters for datetime payload fields."""

    on_disk: bool | None = None
    is_principal: bool | None = None

    def to_proto(self) -> col_pb.DatetimeIndexParams:
        pb = col_pb.DatetimeIndexParams()
        if self.on_disk is not None:
            pb.on_disk = self.on_disk
        if self.is_principal is not None:
            pb.is_principal = self.is_principal
        return pb

    @classmethod
    def from_proto(cls, pb: col_pb.DatetimeIndexParams) -> DatetimeIndexParams:
        return cls(
            on_disk=pb.on_disk if pb.HasField("on_disk") else None,
            is_principal=pb.is_principal if pb.HasField("is_principal") else None,
        )

class UuidIndexParams(BaseModel):
    """Index parameters for UUID payload fields."""

    is_tenant: bool | None = None
    on_disk: bool | None = None

    def to_proto(self) -> col_pb.UuidIndexParams:
        pb = col_pb.UuidIndexParams()
        if self.is_tenant is not None:
            pb.is_tenant = self.is_tenant
        if self.on_disk is not None:
            pb.on_disk = self.on_disk
        return pb

    @classmethod
    def from_proto(cls, pb: col_pb.UuidIndexParams) -> UuidIndexParams:
        return cls(
            is_tenant=pb.is_tenant if pb.HasField("is_tenant") else None,
            on_disk=pb.on_disk if pb.HasField("on_disk") else None,
        )

class PayloadIndexParams(BaseModel):
    """Payload index parameters (oneof)."""

    keyword_index_params: KeywordIndexParams | None = None
    integer_index_params: IntegerIndexParams | None = None
    float_index_params: FloatIndexParams | None = None
    geo_index_params: GeoIndexParams | None = None
    text_index_params: TextIndexParams | None = None
    bool_index_params: BoolIndexParams | None = None
    datetime_index_params: DatetimeIndexParams | None = None
    uuid_index_params: UuidIndexParams | None = None

    def to_proto(self) -> col_pb.PayloadIndexParams:
        pb = col_pb.PayloadIndexParams()
        if self.keyword_index_params is not None:
            pb.keyword_index_params.CopyFrom(self.keyword_index_params.to_proto())
        elif self.integer_index_params is not None:
            pb.integer_index_params.CopyFrom(self.integer_index_params.to_proto())
        elif self.float_index_params is not None:
            pb.float_index_params.CopyFrom(self.float_index_params.to_proto())
        elif self.geo_index_params is not None:
            pb.geo_index_params.CopyFrom(self.geo_index_params.to_proto())
        elif self.text_index_params is not None:
            pb.text_index_params.CopyFrom(self.text_index_params.to_proto())
        elif self.bool_index_params is not None:
            pb.bool_index_params.CopyFrom(self.bool_index_params.to_proto())
        elif self.datetime_index_params is not None:
            pb.datetime_index_params.CopyFrom(self.datetime_index_params.to_proto())
        elif self.uuid_index_params is not None:
            pb.uuid_index_params.CopyFrom(self.uuid_index_params.to_proto())
        return pb

    @classmethod
    def from_proto(cls, pb: col_pb.PayloadIndexParams) -> PayloadIndexParams:
        which = pb.WhichOneof("index_params")
        mapping = {
            "keyword_index_params": ("keyword_index_params", KeywordIndexParams),
            "integer_index_params": ("integer_index_params", IntegerIndexParams),
            "float_index_params": ("float_index_params", FloatIndexParams),
            "geo_index_params": ("geo_index_params", GeoIndexParams),
            "text_index_params": ("text_index_params", TextIndexParams),
            "bool_index_params": ("bool_index_params", BoolIndexParams),
            "datetime_index_params": ("datetime_index_params", DatetimeIndexParams),
            "uuid_index_params": ("uuid_index_params", UuidIndexParams),
        }
        if which and which in mapping:
            attr, model_cls = mapping[which]
            return cls(**{attr: model_cls.from_proto(getattr(pb, which))})  # type: ignore[attr-defined]
        return cls()

class PayloadSchemaInfo(BaseModel):
    """Payload field schema info."""

    data_type: PayloadSchemaType = PayloadSchemaType.UnknownType
    params: PayloadIndexParams | None = None
    points: int | None = None

    @classmethod
    def from_proto(cls, pb: col_pb.PayloadSchemaInfo) -> PayloadSchemaInfo:
        return cls(
            data_type=PayloadSchemaType(pb.data_type),
            params=(PayloadIndexParams.from_proto(pb.params) if pb.HasField("params") else None),
            points=pb.points if pb.HasField("points") else None,
        )

# ─── Optimizer Status ────────────────────────────────────────────────

class OptimizerStatus(BaseModel):
    """Optimizer status."""

    ok: bool = True
    error: str = ""

    @classmethod
    def from_proto(cls, pb: col_pb.OptimizerStatus) -> OptimizerStatus:
        return cls(ok=pb.ok, error=pb.error)

# ─── Collection Info ─────────────────────────────────────────────────

class CollectionDescription(BaseModel):
    """Lightweight collection reference (from List)."""

    name: str

    @classmethod
    def from_proto(cls, pb: col_pb.CollectionDescription) -> CollectionDescription:
        return cls(name=pb.name)

class CollectionParams(BaseModel):
    """Collection parameters."""

    shard_number: int = 1
    on_disk_payload: bool = False
    vectors_config: VectorParams | None = None
    vectors_config_map: dict[str, VectorParams] | None = None
    replication_factor: int | None = None
    write_consistency_factor: int | None = None
    read_fan_out_factor: int | None = None
    sharding_method: ShardingMethod | None = None
    sparse_vectors_config: dict[str, SparseVectorParams] | None = None

    @classmethod
    def from_proto(cls, pb: col_pb.CollectionParams) -> CollectionParams:
        vectors_config = None
        vectors_config_map = None
        if pb.HasField("vectors_config"):
            vc = pb.vectors_config
            which = vc.WhichOneof("config")
            if which == "params":
                vectors_config = VectorParams.from_proto(vc.params)
            elif which == "params_map":
                vectors_config_map = {
                    k: VectorParams.from_proto(v) for k, v in vc.params_map.map.items()
                }

        sparse = None
        if pb.HasField("sparse_vectors_config"):
            sparse = {
                k: SparseVectorParams.from_proto(v) for k, v in pb.sparse_vectors_config.map.items()
            }

        return cls(
            shard_number=pb.shard_number,
            on_disk_payload=pb.on_disk_payload,
            vectors_config=vectors_config,
            vectors_config_map=vectors_config_map,
            replication_factor=(
                pb.replication_factor if pb.HasField("replication_factor") else None
            ),
            write_consistency_factor=(
                pb.write_consistency_factor if pb.HasField("write_consistency_factor") else None
            ),
            read_fan_out_factor=(
                pb.read_fan_out_factor if pb.HasField("read_fan_out_factor") else None
            ),
            sharding_method=(
                ShardingMethod(pb.sharding_method) if pb.HasField("sharding_method") else None
            ),
            sparse_vectors_config=sparse,
        )


class CollectionInfo(BaseModel):
    """Comprehensive collection information."""

    status: CollectionStatus = CollectionStatus.UnknownCollectionStatus
    optimizer_status: OptimizerStatus | None = None
    segments_count: int = 0
    payload_schema: dict[str, PayloadSchemaInfo] = Field(default_factory=dict)
    points_count: int | None = None
    indexed_vectors_count: int | None = None
    # VDE extensions
    name_ext: str | None = None
    health_status_ext: CollectionHealthStatus | None = None
    vectors_count: int | None = None
    index_type_ext: IndexType | None = None

    @classmethod
    def from_proto(cls, pb: col_pb.CollectionInfo) -> CollectionInfo:
        schema = {k: PayloadSchemaInfo.from_proto(v) for k, v in pb.payload_schema.items()}
        return cls(
            status=CollectionStatus(pb.status),
            optimizer_status=(
                OptimizerStatus.from_proto(pb.optimizer_status)
                if pb.HasField("optimizer_status")
                else None
            ),
            segments_count=pb.segments_count,
            payload_schema=schema,
            points_count=pb.points_count if pb.HasField("points_count") else None,
            indexed_vectors_count=(
                pb.indexed_vectors_count if pb.HasField("indexed_vectors_count") else None
            ),
            name_ext=pb.name_ext if pb.HasField("name_ext") else None,
            health_status_ext=(
                CollectionHealthStatus(pb.health_status_ext)
                if pb.HasField("health_status_ext")
                else None
            ),
            vectors_count=pb.vectors_count if pb.HasField("vectors_count") else None,
            index_type_ext=(
                IndexType(pb.index_type_ext) if pb.HasField("index_type_ext") else None
            ),
        )

class CollectionOperationResponse(BaseModel):
    """Response from collection create/update/delete."""

    result: bool = False
    time: float = 0.0

    @classmethod
    def from_proto(cls, pb: col_pb.CollectionOperationResponse) -> CollectionOperationResponse:
        return cls(result=pb.result, time=pb.time)

# ─── Alias ───────────────────────────────────────────────────────────

class AliasDescription(BaseModel):
    """Alias information."""

    alias_name: str
    collection_name: str

    @classmethod
    def from_proto(cls, pb: col_pb.AliasDescription) -> AliasDescription:
        return cls(alias_name=pb.alias_name, collection_name=pb.collection_name)
