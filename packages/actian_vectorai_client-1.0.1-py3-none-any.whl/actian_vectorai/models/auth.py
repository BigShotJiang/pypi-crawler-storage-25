#
# Copyright (c) 2026 by Actian Corporation
# All rights reserved.
#
# THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE
# OF ACTIAN CORP.
# The copyright notice above does not evidence any actual or intended
# publication of such source code.
#

"""Pydantic models for the Actian VectorAI DB authentication and API key API.

These are used by :class:`~actian_vectorai._auth.AuthNamespace` and
are part of the public SDK surface.
"""

from __future__ import annotations

from pydantic import BaseModel, Field

__all__ = [
    "AdminLoginResponse",
    "AdminExistsResponse",
    "AuthEnabledResponse",
    "ApiKeyInfo",
    "ApiKeyCreated",
    "ApiKeyPermission",
    "ListApiKeysResponse",
    "DeleteApiKeyResponse",
]


# ── Permission constants ──────────────────────────────────────────────────


class ApiKeyPermission:
    """Named permission bitmask constants for API key creation.

    The server stores permissions as a bitmask:

    =========  =======  ============================
    Bitmask    String   Meaning
    =========  =======  ============================
    ``1``      read     Read-only access
    ``2``      write    Write access
    ``4``      admin    Admin-only auth endpoints
    ``5``      r+a      Read + admin
    ``6``      w+a      Write + admin
    ``7``      r+w+a    Read + write + admin
    =========  =======  ============================

    Usage::

        await client.auth.create_api_key(
            name="ci-writer",
            permission=ApiKeyPermission.READ_WRITE,
        )
    """

    READ = "read"
    WRITE = "write"
    ADMIN = "admin"
    READ_ADMIN = "read,admin"
    WRITE_ADMIN = "write,admin"
    READ_WRITE = "read,write"
    READ_WRITE_ADMIN = "read,write,admin"


# ── Response models ───────────────────────────────────────────────────────


class AdminLoginResponse(BaseModel):
    """Response from ``POST /auth/admin/login``."""

    token: str | None = Field(None, description="JWT token for admin operations")
    message: str | None = Field(None, description="Human-readable status message")
    expires_in: int = Field(0, description="Token lifetime in seconds (0 = unlimited)")


class AdminExistsResponse(BaseModel):
    """Response from ``GET /auth/admin/exists``."""

    result: bool = Field(..., description="True if the admin user exists")
    status: str = Field("ok")
    time: float = Field(0.0)


class AuthEnabledResponse(BaseModel):
    """Response from ``GET /auth/enabled`` and ``PATCH /auth/enabled``."""

    result: bool = Field(..., description="Current auth-enabled state")
    status: str = Field("ok")
    time: float = Field(0.0)


class ApiKeyInfo(BaseModel):
    """Summary of a single API key (no raw token value).

    Returned by :meth:`~actian_vectorai._auth.AuthNamespace.list_api_keys`.
    """

    id: int = Field(..., description="Unique API key identifier")
    name: str = Field(..., description="Human-readable name")
    description: str = Field("", description="Free-text description")
    created_at: str = Field(..., description="ISO 8601 creation timestamp")
    expired_at: str | None = Field(None, description="ISO 8601 expiry timestamp, or null")
    will_expire: bool = Field(False, description="Whether this key has a fixed TTL")
    permission: str = Field(..., description="Comma-separated permission string")


class ApiKeyCreated(BaseModel):
    """Full API key response, including the raw token.

    Returned by :meth:`~actian_vectorai._auth.AuthNamespace.create_api_key`
    and :meth:`~actian_vectorai._auth.AuthNamespace.rotate_api_key`.

    .. warning::
        The ``api_key`` field is only returned once at creation / rotation.
        Store it securely — it cannot be retrieved again.
    """

    id: int = Field(..., description="Unique API key identifier")
    name: str = Field(..., description="Human-readable name")
    description: str = Field("", description="Free-text description")
    api_key: str = Field(..., description="Raw token value (``vdai_…``).  Store securely.")
    created_at: str = Field(..., description="ISO 8601 creation timestamp")
    expired_at: str | None = Field(None, description="ISO 8601 expiry timestamp, or null")
    will_expire: bool = Field(False, description="Whether this key has a fixed TTL")
    permission: str = Field(..., description="Comma-separated permission string")


class ListApiKeysResponse(BaseModel):
    """Wrapper for the ``GET /auth/api_keys`` response body."""

    api_keys: list[ApiKeyInfo] = Field(default_factory=list)


class DeleteApiKeyResponse(BaseModel):
    """Response from ``DELETE /auth/api_key/{id}``."""

    status: str = Field(...)
    message: str = Field(...)
