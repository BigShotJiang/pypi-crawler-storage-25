#
# Copyright (c) 2026 by Actian Corporation
# All rights reserved.
#
# THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE
# OF ACTIAN CORP.
# The copyright notice above does not evidence any actual or intended
# publication of such source code.
#

"""Points namespace — async methods for the Points gRPC service.

Implemented:
  - CRUD: upsert, delete, get, update_vectors
  - Payload: set_payload, overwrite_payload, delete_payload, clear_payload
  - Search: search, search_batch
  - Count: count
  - Scroll: scroll, scroll_all
  - Query (universal): query, query_batch
  - Convenience: upsert_single, delete_by_ids
"""

from __future__ import annotations

import logging
from collections.abc import AsyncIterator
from typing import Any

import numpy as np

from actian_vectorai._executor import grpc_call
from actian_vectorai.exceptions import PointNotFoundError
from actian_vectorai.models.common import (
    Filter,
    PointId,
    PointIdValue,
    _point_id_to_proto,
)
from actian_vectorai.models.enums import (
    UpdateStatus,
)
from actian_vectorai.models.points import (
    DenseVector,
    PointStruct,
    PrefetchQuery,
    RetrievedPoint,
    ScoredPoint,
    SearchParams,
    UpdateResult,
    WithPayloadSelector,
    WithVectorsSelector,
    _build_vectors_proto,
    _payload_to_proto,
)
from actian_vectorai.proto import actian_vectorai_common_pb2 as common_pb
from actian_vectorai.proto import actian_vectorai_points_pb2 as pts_pb
from actian_vectorai.proto import actian_vectorai_points_service_pb2_grpc as pts_grpc

__all__ = ["PointsNamespace"]

logger = logging.getLogger("actian_vectorai.points")


# ─── Selector helpers ────────────────────────────────────────────────


def _with_payload_proto(
    with_payload: bool | WithPayloadSelector | None,
) -> pts_pb.WithPayloadSelector:
    """Normalize ``with_payload`` into a proto selector."""
    if with_payload is None or with_payload is False:
        return pts_pb.WithPayloadSelector(enable=False)
    if with_payload is True:
        return pts_pb.WithPayloadSelector(enable=True)
    if isinstance(with_payload, WithPayloadSelector):
        return with_payload.to_proto()
    raise TypeError(
        f"with_payload must be a bool or WithPayloadSelector, got {type(with_payload).__name__!r}"
    )


def _with_vectors_proto(
    with_vectors: bool | WithVectorsSelector | None,
) -> pts_pb.WithVectorsSelector | None:
    """Normalize ``with_vectors`` into a proto selector."""
    if with_vectors is None or with_vectors is False:
        return pts_pb.WithVectorsSelector(enable=False)
    if with_vectors is True:
        return pts_pb.WithVectorsSelector(enable=True)
    if isinstance(with_vectors, WithVectorsSelector):
        return with_vectors.to_proto()
    raise TypeError(
        f"with_vectors must be a bool or WithVectorsSelector, got {type(with_vectors).__name__!r}"
    )


def _filter_proto(f: Filter | None) -> common_pb.Filter | None:
    """Convert a model Filter to proto, if not None."""
    if f is None:
        return None
    return f.to_proto()


def _points_selector(
    ids: list[PointIdValue] | None = None,
    filter: Filter | None = None,
) -> pts_pb.PointsSelector:
    """Build a PointsSelector from either IDs or a filter."""
    if ids is not None and filter is not None:
        from actian_vectorai.exceptions import ValidationError

        raise ValidationError(
            "Provide either 'ids' or 'filter', not both.",
            field="points_selector",
        )
    sel = pts_pb.PointsSelector()
    if ids is not None:
        id_list = pts_pb.PointsIdsList()
        id_list.ids.extend(_point_id_to_proto(pid) for pid in ids)
        sel.points.CopyFrom(id_list)
    elif filter is not None:
        sel.filter.CopyFrom(filter.to_proto())
    return sel


def _search_params_proto(params: SearchParams | None) -> pts_pb.SearchParams | None:
    """Convert SearchParams model to proto."""
    if params is None:
        return None
    return params.to_proto()


def _vector_to_floats(
    vector: list[float] | np.ndarray[Any, Any] | DenseVector,
) -> list[float]:
    """Normalize a vector to a plain float list.

    For numpy arrays, uses ``tolist()`` after ensuring float32 dtype,
    which is faster than manual iteration for large vectors.
    """
    if isinstance(vector, np.ndarray):
        if vector.dtype != np.float32:
            vector = vector.astype(np.float32, copy=False)
        return vector.tolist()
    if isinstance(vector, DenseVector):
        return vector.data
    return list(vector)


# ─── Namespace ────────────────────────────────────────────────────────


class PointsNamespace:
    """Async operations on the ``Points`` gRPC service.

    Instantiated by ``AsyncVectorAIClient`` — not created directly.
    """

    __slots__ = ("_stub", "_timeout")

    def __init__(
        self,
        stub: pts_grpc.PointsStub,
        *,
        timeout: float | None = None,
    ) -> None:
        self._stub = stub
        self._timeout = timeout

    # ═══════════════════════════════════════════════════════════
    #  CRUD
    # ═══════════════════════════════════════════════════════════

    async def upsert(
        self,
        collection_name: str,
        points: list[PointStruct],
        *,
        timeout: float | None = None,
    ) -> UpdateResult:
        """Insert or update points.

        Parameters
        ----------
        collection_name:
            Target collection.
        points:
            List of ``PointStruct`` to upsert.
        timeout:
            Per-call timeout (seconds).

        Returns
        -------
        ``UpdateResult`` with operation status.
        """
        req = pts_pb.UpsertPoints(collection_name=collection_name)
        req.points.extend(p.to_proto() for p in points)

        resp = await grpc_call(
            self._stub.Upsert,
            req,
            timeout=timeout if timeout is not None else self._timeout,
            collection_name=collection_name,
        )
        logger.debug(
            "Upserted %d points to %r (%.3fs)",
            len(points),
            collection_name,
            resp.time,
        )
        return UpdateResult.from_proto(resp.result)

    async def delete(
        self,
        collection_name: str,
        *,
        ids: list[PointIdValue] | None = None,
        filter: Filter | None = None,
        strict: bool = True,
        track_ids: bool = False,
        timeout: float | None = None,
    ) -> UpdateResult:
        """Delete points by IDs or filter.

        Provide **either** ``ids`` or ``filter``, not both.

        Parameters
        ----------
        strict:
            When ``True`` (default) and ``ids`` are provided, all IDs must
            exist before deletion proceeds.  Raises ``PointNotFoundError``
            listing every missing ID without deleting anything.  When
            ``False``, non-existent IDs are silently ignored.

        Returns
        -------
        ``UpdateResult`` with operation status.

        Raises
        ------
        ValidationError
            If any ID in ``ids`` is invalid (e.g. negative integer).
        PointNotFoundError
            If ``strict=True`` and one or more IDs do not exist.
        """
        _deleted_ids: list[int | str] | None = None
        _failed_ids: list[int | str] | None = None

        if ids is not None:
            from actian_vectorai.exceptions import ValidationError
            from actian_vectorai.utils.validation import validate_ids

            try:
                validated_ids: list[int | str] = validate_ids(ids)
            except ValidationError as e:
                e.field = "ids"
                raise

            if strict or track_ids:
                fetched = await grpc_call(
                    self._stub.Get,
                    pts_pb.GetPoints(
                        collection_name=collection_name,
                        ids=[_point_id_to_proto(pid) for pid in validated_ids],
                    ),
                    timeout=timeout if timeout is not None else self._timeout,
                    collection_name=collection_name,
                )

                def _id_val(pb_id: Any) -> str:
                    pid = PointId.from_proto(pb_id)
                    return str(pid.num if pid.num is not None else (pid.uuid or 0))

                returned_ids = {_id_val(p.id) for p in fetched.result}
                missing = [id_ for id_ in validated_ids if str(id_) not in returned_ids]

                if strict and missing:
                    raise PointNotFoundError(ids=missing, collection=collection_name)

                if track_ids:
                    _deleted_ids = [id_ for id_ in validated_ids if str(id_) in returned_ids]
                    _failed_ids = missing

        req = pts_pb.DeletePoints(collection_name=collection_name)
        _sel_ids: list[PointIdValue] | None = list(validated_ids) if ids is not None else None
        req.points.CopyFrom(_points_selector(ids=_sel_ids, filter=filter))

        try:
            resp = await grpc_call(
                self._stub.Delete,
                req,
                timeout=timeout if timeout is not None else self._timeout,
                collection_name=collection_name,
            )
        except PointNotFoundError:
            if strict:
                raise
            # Non-strict mode: silently treat "not found" as successful
            return UpdateResult(
                operation_id=None,
                status=UpdateStatus.Completed,
                deleted_ids=_deleted_ids,
                failed_ids=_failed_ids,
            )
        result = UpdateResult.from_proto(resp.result)
        result.deleted_ids = _deleted_ids
        result.failed_ids = _failed_ids
        return result

    async def get(
        self,
        collection_name: str,
        ids: list[PointIdValue],
        *,
        with_payload: bool | WithPayloadSelector = True,
        with_vectors: bool | WithVectorsSelector = False,
        timeout: float | None = None,
    ) -> list[RetrievedPoint]:
        """Retrieve points by ID.

        Parameters
        ----------
        collection_name:
            Collection to query.
        ids:
            List of point IDs (int or str UUIDs).
        with_payload:
            Include payload in response.
        with_vectors:
            Include vector data in response.

        Returns
        -------
        List of ``RetrievedPoint``.
        """
        from actian_vectorai.exceptions import ValidationError
        from actian_vectorai.utils.validation import validate_ids

        try:
            validated = validate_ids(ids)
        except ValidationError as e:
            e.field = "ids"
            raise

        req = pts_pb.GetPoints(collection_name=collection_name)
        for pid in validated:
            req.ids.append(_point_id_to_proto(pid))
        req.with_payload.CopyFrom(_with_payload_proto(with_payload))
        wv = _with_vectors_proto(with_vectors)
        if wv is not None:
            req.with_vectors.CopyFrom(wv)

        resp = await grpc_call(
            self._stub.Get,
            req,
            timeout=timeout if timeout is not None else self._timeout,
            collection_name=collection_name,
        )
        return [RetrievedPoint.from_proto(p) for p in resp.result]

    async def update_vectors(
        self,
        collection_name: str,
        points: list[dict[str, Any]],
        *,
        timeout: float | None = None,
    ) -> UpdateResult:
        """Update named vectors for existing points.

        Parameters
        ----------
        points:
            List of dicts with ``"id"`` and ``"vector"`` (or ``"vectors"``) keys.
        """
        req = pts_pb.UpdatePointVectors(collection_name=collection_name)
        for p in points:
            pv = pts_pb.PointVectors()
            pv.id.CopyFrom(_point_id_to_proto(p["id"]))
            vec_data = p.get("vectors") or p.get("vector")
            if vec_data is None:
                from actian_vectorai.exceptions import ValidationError
                raise ValidationError(
                    "Each point dict must have a 'vector' or 'vectors' key",
                    field="vector",
                )
            pv.vectors.CopyFrom(_build_vectors_proto(vec_data))
            req.points.append(pv)

        resp = await grpc_call(
            self._stub.UpdateVectors,
            req,
            timeout=timeout if timeout is not None else self._timeout,
            collection_name=collection_name,
        )
        return UpdateResult.from_proto(resp.result)

    # ═══════════════════════════════════════════════════════════
    #  Payload operations
    # ═══════════════════════════════════════════════════════════

    async def set_payload(
        self,
        collection_name: str,
        payload: dict[str, Any],
        *,
        ids: list[PointIdValue] | None = None,
        filter: Filter | None = None,
        key: str | None = None,
        timeout: float | None = None,
    ) -> UpdateResult:
        """Set (merge) payload fields for points."""
        req = pts_pb.SetPayloadPoints(collection_name=collection_name)
        for k, v in _payload_to_proto(payload).items():
            req.payload[k].CopyFrom(v)
        if ids is not None or filter is not None:
            req.points_selector.CopyFrom(_points_selector(ids=ids, filter=filter))
        if key is not None:
            req.key = key

        resp = await grpc_call(
            self._stub.SetPayload,
            req,
            timeout=timeout if timeout is not None else self._timeout,
            collection_name=collection_name,
        )
        return UpdateResult.from_proto(resp.result)

    async def overwrite_payload(
        self,
        collection_name: str,
        payload: dict[str, Any],
        *,
        ids: list[PointIdValue] | None = None,
        filter: Filter | None = None,
        key: str | None = None,
        timeout: float | None = None,
    ) -> UpdateResult:
        """Replace the entire payload for points."""
        req = pts_pb.SetPayloadPoints(collection_name=collection_name)
        for k, v in _payload_to_proto(payload).items():
            req.payload[k].CopyFrom(v)
        if ids is not None or filter is not None:
            req.points_selector.CopyFrom(_points_selector(ids=ids, filter=filter))
        if key is not None:
            req.key = key

        resp = await grpc_call(
            self._stub.OverwritePayload,
            req,
            timeout=timeout if timeout is not None else self._timeout,
            collection_name=collection_name,
        )
        return UpdateResult.from_proto(resp.result)

    async def delete_payload(
        self,
        collection_name: str,
        keys: list[str],
        *,
        ids: list[PointIdValue] | None = None,
        filter: Filter | None = None,
        strict: bool = True,
        timeout: float | None = None,
    ) -> UpdateResult:
        """Delete specific payload keys from points.

        Parameters
        ----------
        strict:
            When ``True`` (default) and ``ids`` are provided, all IDs must
            exist before the operation proceeds.  Raises ``PointNotFoundError``
            listing every missing ID without modifying anything.  When
            ``False``, non-existent IDs are silently ignored.
        """
        if ids is not None and strict:
            fetched = await grpc_call(
                self._stub.Get,
                pts_pb.GetPoints(
                    collection_name=collection_name,
                    ids=[_point_id_to_proto(pid) for pid in ids],
                ),
                timeout=timeout if timeout is not None else self._timeout,
                collection_name=collection_name,
            )

            def _id_val(pb_id: Any) -> str:
                pid = PointId.from_proto(pb_id)
                return str(pid.num if pid.num is not None else (pid.uuid or 0))

            returned_ids = {_id_val(p.id) for p in fetched.result}
            missing = [id_ for id_ in ids if str(id_) not in returned_ids]
            if missing:
                raise PointNotFoundError(ids=missing, collection=collection_name)

        req = pts_pb.DeletePayloadPoints(collection_name=collection_name)
        req.keys.extend(keys)
        if ids is not None or filter is not None:
            req.points_selector.CopyFrom(_points_selector(ids=ids, filter=filter))

        resp = await grpc_call(
            self._stub.DeletePayload,
            req,
            timeout=timeout if timeout is not None else self._timeout,
            collection_name=collection_name,
        )
        return UpdateResult.from_proto(resp.result)

    async def clear_payload(
        self,
        collection_name: str,
        *,
        ids: list[PointIdValue] | None = None,
        filter: Filter | None = None,
        timeout: float | None = None,
    ) -> UpdateResult:
        """Remove all payload from points."""
        req = pts_pb.ClearPayloadPoints(collection_name=collection_name)
        req.points.CopyFrom(_points_selector(ids=ids, filter=filter))

        resp = await grpc_call(
            self._stub.ClearPayload,
            req,
            timeout=timeout if timeout is not None else self._timeout,
            collection_name=collection_name,
        )
        return UpdateResult.from_proto(resp.result)

    # ═══════════════════════════════════════════════════════════
    #  Search
    # ═══════════════════════════════════════════════════════════

    async def search(
        self,
        collection_name: str,
        vector: list[float] | np.ndarray[Any, Any] | DenseVector,
        *,
        limit: int = 10,
        filter: Filter | None = None,
        params: SearchParams | None = None,
        score_threshold: float | None = None,
        using: str | None = None,
        with_payload: bool | WithPayloadSelector = True,
        with_vectors: bool | WithVectorsSelector = False,
        sparse_indices: list[int] | None = None,
        timeout: float | None = None,
    ) -> list[ScoredPoint]:
        """Vector similarity search.

        Parameters
        ----------
        collection_name:
            Collection to search.
        vector:
            Query vector (dense float list, ndarray, or DenseVector).
        limit:
            Maximum results to return.
        filter:
            Payload filter conditions.
        params:
            Search parameters (HNSW ef, etc.).
        score_threshold:
            Discard results with score worse than this.
        using:
            Named vector to search (default: unnamed vector).
        with_payload:
            Include payload in results.
        with_vectors:
            Include vector data in results.

        Returns
        -------
        List of ``ScoredPoint`` ordered by similarity.
        """
        from actian_vectorai.exceptions import ValidationError
        from actian_vectorai.utils.validation import validate_top_k, validate_vector

        try:
            validate_top_k(limit)
        except ValidationError as e:
            e.field = "limit"
            raise

        try:
            floats = validate_vector(vector)
        except ValidationError as e:
            e.field = "vector"
            raise

        req = pts_pb.SearchPoints(
            collection_name=collection_name,
            vector=floats,
            limit=limit,
        )
        fp = _filter_proto(filter)
        if fp is not None:
            req.filter.CopyFrom(fp)
        sp = _search_params_proto(params)
        if sp is not None:
            req.params.CopyFrom(sp)
        if score_threshold is not None:
            req.score_threshold = score_threshold
        if using is not None:
            req.vector_name = using  # proto field is vector_name
        req.with_payload.CopyFrom(_with_payload_proto(with_payload))
        wv = _with_vectors_proto(with_vectors)
        if wv is not None:
            req.with_vectors.CopyFrom(wv)
        if sparse_indices is not None:
            req.sparse_indices.data.extend(sparse_indices)

        resp = await grpc_call(
            self._stub.Search,
            req,
            timeout=timeout if timeout is not None else self._timeout,
            collection_name=collection_name,
        )
        results = [ScoredPoint.from_proto(p) for p in resp.result]
        if not results:
            logger.debug(
                "Search on '%s' returned no results. "
                "The collection may be empty or contain no vectors matching your query.",
                collection_name,
            )
        return results

    async def search_batch(
        self,
        collection_name: str,
        searches: list[dict[str, Any]],
        *,
        timeout: float | None = None,
    ) -> list[list[ScoredPoint]]:
        """Batch multiple search requests.

        Parameters
        ----------
        searches:
            List of dicts, each with the same kwargs as ``search()``
            (minus ``collection_name``).

        Returns
        -------
        List of result lists, in the same order as ``searches``.

        Raises
        ------
        ValidationError
            If ``searches`` is empty or exceeds 100 entries.
        """
        from actian_vectorai.exceptions import ValidationError

        if not searches:
            raise ValidationError("searches must not be empty", field="searches")
        if len(searches) > 100:
            raise ValidationError(
                f"searches exceeds maximum batch size of 100 (got {len(searches)})",
                field="searches",
            )
        search_points = []
        for s in searches:
            sp = pts_pb.SearchPoints(
                collection_name=collection_name,
                vector=_vector_to_floats(s["vector"]),
                limit=s.get("limit", 10),
            )
            f = s.get("filter")
            if f is not None:
                sp.filter.CopyFrom(_filter_proto(f))
            p = s.get("params")
            if p is not None:
                sp.params.CopyFrom(_search_params_proto(p))
            if "score_threshold" in s:
                sp.score_threshold = s["score_threshold"]
            vn = s.get("using")
            if vn is not None:
                sp.vector_name = vn  # proto field is vector_name
            sp.with_payload.CopyFrom(_with_payload_proto(s.get("with_payload", True)))
            wv = _with_vectors_proto(s.get("with_vectors", False))
            if wv is not None:
                sp.with_vectors.CopyFrom(wv)
            si = s.get("sparse_indices")
            if si is not None:
                sp.sparse_indices.data.extend(si)
            search_points.append(sp)

        req = pts_pb.SearchBatchPoints(
            collection_name=collection_name,
            search_points=search_points,
        )

        resp = await grpc_call(
            self._stub.SearchBatch,
            req,
            timeout=timeout if timeout is not None else self._timeout,
            collection_name=collection_name,
        )
        return [[ScoredPoint.from_proto(p) for p in batch.result] for batch in resp.result]

    # ═══════════════════════════════════════════════════════════
    #  Count
    # ═══════════════════════════════════════════════════════════

    async def count(
        self,
        collection_name: str,
        *,
        filter: Filter | None = None,
        timeout: float | None = None,
    ) -> int:
        """Count points in a collection.

        Parameters
        ----------
        filter:
            Only count points matching this filter.

        Returns
        -------
        Point count.
        """
        req = pts_pb.CountPoints(
            collection_name=collection_name,
        )
        fp = _filter_proto(filter)
        if fp is not None:
            req.filter.CopyFrom(fp)

        resp = await grpc_call(
            self._stub.Count,
            req,
            timeout=timeout if timeout is not None else self._timeout,
            collection_name=collection_name,
        )
        return resp.result.count

    # ═══════════════════════════════════════════════════════════
    #  Scroll (paginated iteration)
    # ═══════════════════════════════════════════════════════════

    async def scroll(
        self,
        collection_name: str,
        *,
        offset: PointIdValue | None = None,
        limit: int | None = None,
        filter: Filter | None = None,
        with_payload: bool | WithPayloadSelector = True,
        with_vectors: bool | WithVectorsSelector = False,
        timeout: float | None = None,
    ) -> tuple[list[RetrievedPoint], PointIdValue | None]:
        """Scroll (paginate) through points in a collection.

        Iterate over points with optional filtering, ordered by ID.

        Parameters
        ----------
        collection_name:
            Collection to scroll through.
        offset:
            Start after this point ID (nullopt = from beginning).
        limit:
            Maximum points to return per page (default: 10).
            Must be > 0 if specified.
        filter:
            Only iterate points matching this filter.
        with_payload:
            Include payload in results (default: True).
        with_vectors:
            Include vector data in results (default: False).
        timeout:
            Per-call timeout in seconds.

        Returns
        -------
        Tuple of (points, next_offset).
        - points: List of ``RetrievedPoint`` for this page.
        - next_offset: PointId for next page (None = end of data).

        Raises
        ------
        ValidationError
            If limit is 0 or negative.
        """
        from actian_vectorai.exceptions import ValidationError

        # Validate limit
        if limit is not None and limit <= 0:
            raise ValidationError(
                "limit must be greater than 0",
                field="limit",
            )

        req = pts_pb.ScrollPoints(collection_name=collection_name)

        if offset is not None:
            req.offset.CopyFrom(_point_id_to_proto(offset))
        if limit is not None:
            req.limit = limit
        else:
            req.limit = 10  # default limit matches server default

        fp = _filter_proto(filter)
        if fp is not None:
            req.filter.CopyFrom(fp)

        req.with_payload.CopyFrom(_with_payload_proto(with_payload))
        wv = _with_vectors_proto(with_vectors)
        if wv is not None:
            req.with_vectors.CopyFrom(wv)

        resp = await grpc_call(
            self._stub.Scroll,
            req,
            timeout=timeout if timeout is not None else self._timeout,
            collection_name=collection_name,
        )

        points = [RetrievedPoint.from_proto(p) for p in resp.result]

        # Extract next_page_offset as PointIdValue or None
        next_offset: PointIdValue | None = None
        if resp.HasField("next_page_offset"):
            pid = PointId.from_proto(resp.next_page_offset)
            next_offset = pid.num if pid.num is not None else pid.uuid

        logger.debug(
            "Scrolled %d points from %r with limit=%s (%.3fs)",
            len(points),
            collection_name,
            limit or 10,
            resp.time,
        )

        return points, next_offset

    async def scroll_all(
        self,
        collection_name: str,
        *,
        limit: int | None = None,
        filter: Filter | None = None,
        with_payload: bool | WithPayloadSelector = True,
        with_vectors: bool | WithVectorsSelector = False,
        timeout: float | None = None,
    ) -> AsyncIterator[list[RetrievedPoint]]:
        """Iterate over all points in a collection (async generator).

        Automatically handles pagination using scroll().

        Parameters
        ----------
        collection_name:
            Collection to scroll through.
        limit:
            Points per page (default: 10).
        filter:
            Only iterate points matching this filter.
        with_payload:
            Include payload in results.
        with_vectors:
            Include vector data in results.

        Yields
        ------
        List[RetrievedPoint]
            Each page of points as a batch.

        Example
        -------
        >>> async for page in client.points.scroll_all('my_collection', limit=100):
        ...     for point in page:
        ...         print(point.id)
        """
        offset: PointIdValue | None = None
        while True:
            points, next_offset = await self.scroll(
                collection_name,
                offset=offset,
                limit=limit,
                filter=filter,
                with_payload=with_payload,
                with_vectors=with_vectors,
                timeout=timeout,
            )
            if not points:
                break
            yield points
            if next_offset is None:
                break
            offset = next_offset

    # ═══════════════════════════════════════════════════════════
    #  Query (universal endpoint)
    # ═══════════════════════════════════════════════════════════

    async def query(
        self,
        collection_name: str,
        *,
        query: Any | None = None,
        prefetch: list[PrefetchQuery] | None = None,
        using: str | None = None,
        filter: Filter | None = None,
        params: SearchParams | None = None,
        score_threshold: float | None = None,
        limit: int = 10,
        with_payload: bool | WithPayloadSelector = True,
        with_vectors: bool | WithVectorsSelector = False,
        timeout: float | None = None,
    ) -> list[ScoredPoint]:
        """Universal query endpoint.

        Covers search, hybrid, and multi-stage queries
        through the ``query`` parameter.

        Parameters
        ----------
        query:
            A vector (list[float]), or a proto Query object, or None
            (returns points ordered by ID).
        prefetch:
            Sub-queries to execute first (for multi-stage pipelines).
        using:
            Named vector to use for querying.
        filter:
            Payload filter conditions.
        limit:
            Maximum results.

        Returns
        -------
        List of ``ScoredPoint``.
        """
        req = pts_pb.QueryPoints(
            collection_name=collection_name,
            limit=limit,
        )

        # Build the query proto
        if query is not None:
            q_proto = _build_query_proto(query)
            if q_proto is not None:
                req.query.CopyFrom(q_proto)

        # Build prefetch
        if prefetch:
            for pf in prefetch:
                if hasattr(pf, "to_proto"):
                    req.prefetch.append(pf.to_proto())

        if using is not None:
            req.using = using
        fp = _filter_proto(filter)
        if fp is not None:
            req.filter.CopyFrom(fp)
        sp = _search_params_proto(params)
        if sp is not None:
            req.params.CopyFrom(sp)
        if score_threshold is not None:
            req.score_threshold = score_threshold
        req.with_payload.CopyFrom(_with_payload_proto(with_payload))
        wv = _with_vectors_proto(with_vectors)
        if wv is not None:
            req.with_vectors.CopyFrom(wv)

        resp = await grpc_call(
            self._stub.Query,
            req,
            timeout=timeout if timeout is not None else self._timeout,
            collection_name=collection_name,
        )
        return [ScoredPoint.from_proto(p) for p in resp.result]

    async def query_batch(
        self,
        collection_name: str,
        queries: list[dict[str, Any]],
        *,
        timeout: float | None = None,
    ) -> list[list[ScoredPoint]]:
        """Batch multiple query requests.

        Parameters
        ----------
        queries:
            List of dicts with the same kwargs as ``query()``
            (minus ``collection_name``).

        Raises
        ------
        ValidationError
            If ``queries`` is empty or exceeds 100 entries.
        """
        from actian_vectorai.exceptions import ValidationError

        if not queries:
            raise ValidationError("queries must not be empty", field="queries")
        if len(queries) > 100:
            raise ValidationError(
                f"queries exceeds maximum batch size of 100 (got {len(queries)})",
                field="queries",
            )
        query_points = []
        for q in queries:
            qp = pts_pb.QueryPoints(
                collection_name=collection_name,
                limit=q.get("limit", 10),
            )
            qv = q.get("query")
            if qv is not None:
                q_proto = _build_query_proto(qv)
                if q_proto is not None:
                    qp.query.CopyFrom(q_proto)
            f = q.get("filter")
            if f is not None:
                qp.filter.CopyFrom(_filter_proto(f))
            if "using" in q:
                qp.using = q["using"]
            if "score_threshold" in q:
                qp.score_threshold = q["score_threshold"]
            p = q.get("params")
            if p is not None:
                qp.params.CopyFrom(_search_params_proto(p))
            pf_list = q.get("prefetch")
            if pf_list:
                for pf in pf_list:
                    if hasattr(pf, "to_proto"):
                        qp.prefetch.append(pf.to_proto())
            qp.with_payload.CopyFrom(_with_payload_proto(q.get("with_payload", True)))
            wv = _with_vectors_proto(q.get("with_vectors", False))
            if wv is not None:
                qp.with_vectors.CopyFrom(wv)
            query_points.append(qp)

        req = pts_pb.QueryBatchPoints(
            collection_name=collection_name,
            query_points=query_points,
        )
        resp = await grpc_call(
            self._stub.QueryBatch,
            req,
            timeout=timeout if timeout is not None else self._timeout,
            collection_name=collection_name,
        )
        return [[ScoredPoint.from_proto(p) for p in batch.result] for batch in resp.result]

    # ═══════════════════════════════════════════════════════════
    #  Convenience
    # ═══════════════════════════════════════════════════════════

    async def upsert_single(
        self,
        collection_name: str,
        id: PointIdValue,
        vector: list[float] | np.ndarray[Any, Any],
        payload: dict[str, Any] | None = None,
        *,
        timeout: float | None = None,
    ) -> UpdateResult:
        """Upsert a single point (convenience wrapper).

        Parameters
        ----------
        id:
            Point ID.
        vector:
            Dense vector data.
        payload:
            Optional payload dict.
        """
        if isinstance(vector, np.ndarray):
            vector = vector.tolist()
        point = PointStruct(id=id, vector=vector, payload=payload)  # type: ignore[arg-type]
        return await self.upsert(
            collection_name,
            [point],
            timeout=timeout,
        )

    async def delete_by_ids(
        self,
        collection_name: str,
        ids: list[PointIdValue],
        *,
        strict: bool = True,
        timeout: float | None = None,
    ) -> UpdateResult:
        """Delete points by IDs (convenience wrapper)."""
        return await self.delete(
            collection_name,
            ids=ids,
            strict=strict,
            timeout=timeout,
        )

    def __repr__(self) -> str:
        return "PointsNamespace()"


# ─── Query proto builder ────────────────────────────────────────────


def _build_query_proto(query: Any) -> pts_pb.Query | None:
    """Build a Query proto from flexible Python input.

    Accepts:
    - ``list[float]`` → nearest neighbor search
    - ``np.ndarray`` → nearest neighbor search
    - ``DenseVector`` → nearest neighbor search
    - ``pts_pb.Query`` → pass through directly
    - ``dict`` with ``"nearest"`` or ``"fusion"`` keys
    """
    if isinstance(query, pts_pb.Query):
        return query
    if isinstance(query, (list, np.ndarray)):
        floats = _vector_to_floats(query)
        q = pts_pb.Query()
        vi = pts_pb.VectorInput()
        vi.dense.data.extend(floats)
        q.nearest.CopyFrom(vi)
        return q
    if isinstance(query, DenseVector):
        q = pts_pb.Query()
        vi = pts_pb.VectorInput()
        vi.dense.data.extend(query.data)
        q.nearest.CopyFrom(vi)
        return q
    if isinstance(query, dict):
        q = pts_pb.Query()
        if "nearest" in query:
            vi = pts_pb.VectorInput()
            vi.dense.data.extend(_vector_to_floats(query["nearest"]))
            q.nearest.CopyFrom(vi)
        elif "fusion" in query:
            q.fusion = query["fusion"]
        return q
    return None
