#
# Copyright (c) 2026 by Actian Corporation
# All rights reserved.
#
# THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE
# OF ACTIAN CORP.
# The copyright notice above does not evidence any actual or intended
# publication of such source code.
#

"""Abstract base class for embedding providers."""

from __future__ import annotations

from abc import ABC, abstractmethod


class EmbeddingProvider(ABC):
    """Abstract interface for text embedding providers.

    Subclasses must implement :meth:`embed` and :meth:`embed_async`,
    or at minimum :meth:`embed` for synchronous usage.
    """

    @abstractmethod
    def embed(self, texts: list[str]) -> list[list[float]]:
        """Generate embeddings for a list of texts.

        Parameters
        ----------
        texts:
            The input texts to embed.

        Returns
        -------
        list[list[float]]
            A list of embedding vectors, one per input text.
        """

    async def embed_async(self, texts: list[str]) -> list[list[float]]:
        """Async variant of :meth:`embed`.

        Default implementation delegates to the synchronous method.
        Subclasses may override for native async support.
        """
        return self.embed(texts)

    def embed_single(self, text: str) -> list[float]:
        """Convenience: embed a single text and return its vector."""
        return self.embed([text])[0]

    async def embed_single_async(self, text: str) -> list[float]:
        """Async convenience: embed a single text and return its vector."""
        result = await self.embed_async([text])
        return result[0]
