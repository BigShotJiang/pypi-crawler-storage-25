#
# Copyright (c) 2026 by Actian Corporation
# All rights reserved.
#
# THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE
# OF ACTIAN CORP.
# The copyright notice above does not evidence any actual or intended
# publication of such source code.
#

"""OpenAI embedding provider for Actian VectorAI.

Requires the ``openai`` package::

    pip install openai

Usage::

    from actian_vectorai.embeddings import OpenAIEmbedder

    embedder = OpenAIEmbedder(api_key="sk-...")
    vectors = embedder.embed(["hello world"])

    # Async usage
    vectors = await embedder.embed_async(["hello world"])

    # Custom model
    embedder = OpenAIEmbedder(
        api_key="sk-...",
        model="text-embedding-3-large",
        dimensions=3072,
    )
"""

from __future__ import annotations

import logging
from typing import Any

from actian_vectorai.embeddings.base import EmbeddingProvider

__all__ = ["OpenAIEmbedder"]

logger = logging.getLogger("actian_vectorai.embeddings.openai")

# Well-known model dimensions for validation hints
_MODEL_DIMENSIONS: dict[str, int] = {
    "text-embedding-3-small": 1536,
    "text-embedding-3-large": 3072,
    "text-embedding-ada-002": 1536,
}

_MAX_BATCH_SIZE = 2048  # OpenAI API limit per request


def _require_openai() -> Any:
    """Import and return the ``openai`` module, raising a clear error if missing."""
    try:
        import openai
        return openai
    except ImportError:
        raise ImportError(
            "The 'openai' package is required for OpenAIEmbedder. "
            "Install it with: pip install openai"
        ) from None


class OpenAIEmbedder(EmbeddingProvider):
    """Embedding provider using the OpenAI Embeddings API.

    Parameters
    ----------
    api_key:
        OpenAI API key. If ``None``, falls back to the ``OPENAI_API_KEY``
        environment variable (handled by the ``openai`` library).
    model:
        Embedding model name. Defaults to ``"text-embedding-3-small"``.
    dimensions:
        Optional output dimension override (supported by v3 models).
        When ``None``, uses the model's default dimension.
    base_url:
        Optional custom API base URL, for proxies or compatible APIs
        (e.g. Azure OpenAI, local servers).
    max_retries:
        Maximum number of retries on transient errors (default: 3).
    timeout:
        Request timeout in seconds (default: 60.0).
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        model: str = "text-embedding-3-small",
        dimensions: int | None = None,
        base_url: str | None = None,
        max_retries: int = 3,
        timeout: float = 60.0,
    ) -> None:
        openai = _require_openai()

        self._model = model
        self._dimensions = dimensions

        client_kwargs: dict[str, Any] = {
            "max_retries": max_retries,
            "timeout": timeout,
        }
        if api_key is not None:
            client_kwargs["api_key"] = api_key
        if base_url is not None:
            client_kwargs["base_url"] = base_url

        self._client: Any = openai.OpenAI(**client_kwargs)
        self._async_client: Any = openai.AsyncOpenAI(**client_kwargs)

        logger.info(
            "OpenAIEmbedder initialized: model=%s, dimensions=%s",
            self._model,
            self._dimensions,
        )

    @property
    def model(self) -> str:
        """The OpenAI embedding model name."""
        return self._model

    @property
    def dimensions(self) -> int | None:
        """The configured output dimensions, or ``None`` for model default."""
        return self._dimensions

    def _build_kwargs(self) -> dict[str, Any]:
        """Build the kwargs dict for an embeddings.create() call."""
        kwargs: dict[str, Any] = {
            "model": self._model,
            "encoding_format": "float",
        }
        if self._dimensions is not None:
            kwargs["dimensions"] = self._dimensions
        return kwargs

    def embed(self, texts: list[str]) -> list[list[float]]:
        """Generate embeddings for a list of texts using OpenAI.

        Automatically batches requests if the input exceeds the API's
        per-request limit.

        Parameters
        ----------
        texts:
            The input texts to embed.

        Returns
        -------
        list[list[float]]
            Embedding vectors in the same order as the input texts.

        Raises
        ------
        ValueError
            If ``texts`` is empty.
        openai.OpenAIError
            On API errors (auth, rate-limit, server errors, etc.).
        """
        if not texts:
            raise ValueError("texts must be a non-empty list of strings")

        all_embeddings: list[list[float]] = []
        kwargs = self._build_kwargs()

        for batch_start in range(0, len(texts), _MAX_BATCH_SIZE):
            batch = texts[batch_start : batch_start + _MAX_BATCH_SIZE]
            logger.debug(
                "Embedding batch of %d texts (offset %d)", len(batch), batch_start
            )
            response = self._client.embeddings.create(input=batch, **kwargs)
            # Sort by index to preserve input order
            sorted_data = sorted(response.data, key=lambda x: x.index)
            all_embeddings.extend([item.embedding for item in sorted_data])

        return all_embeddings

    async def embed_async(self, texts: list[str]) -> list[list[float]]:
        """Generate embeddings asynchronously using the OpenAI API.

        Parameters
        ----------
        texts:
            The input texts to embed.

        Returns
        -------
        list[list[float]]
            Embedding vectors in the same order as the input texts.
        """
        if not texts:
            raise ValueError("texts must be a non-empty list of strings")

        all_embeddings: list[list[float]] = []
        kwargs = self._build_kwargs()

        for batch_start in range(0, len(texts), _MAX_BATCH_SIZE):
            batch = texts[batch_start : batch_start + _MAX_BATCH_SIZE]
            logger.debug(
                "Embedding batch of %d texts (offset %d)", len(batch), batch_start
            )
            response = await self._async_client.embeddings.create(
                input=batch, **kwargs
            )
            sorted_data = sorted(response.data, key=lambda x: x.index)
            all_embeddings.extend([item.embedding for item in sorted_data])

        return all_embeddings

    def __repr__(self) -> str:
        dims: int | str = self._dimensions or _MODEL_DIMENSIONS.get(self._model) or "?"
        return f"OpenAIEmbedder(model={self._model!r}, dimensions={dims})"
