#
# Copyright (c) 2026 by Actian Corporation
# All rights reserved.
#
# THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE
# OF ACTIAN CORP.
# The copyright notice above does not evidence any actual or intended
# publication of such source code.
#

"""Embedding providers for Actian VectorAI.

Built-in providers:
- ``OpenAIEmbedder`` — OpenAI Embeddings API (requires ``openai`` package)

Usage::

    from actian_vectorai.embeddings import OpenAIEmbedder

    embedder = OpenAIEmbedder(api_key="sk-...")
    vectors = embedder.embed(["hello world", "another sentence"])
"""

from actian_vectorai.embeddings.base import EmbeddingProvider
from actian_vectorai.embeddings.openai import OpenAIEmbedder

__all__ = [
    "EmbeddingProvider",
    "OpenAIEmbedder",
]
