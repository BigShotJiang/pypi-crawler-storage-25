#
# Copyright (c) 2026 by Actian Corporation
# All rights reserved.
#
# THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE
# OF ACTIAN CORP.
# The copyright notice above does not evidence any actual or intended
# publication of such source code.
#

"""Sync / async executor utilities.

Provides the plumbing that lets *one* set of ``async def``
business-logic methods serve both an async and a sync public API
— no code duplication, no hand-written forwarding stubs.

Architecture (adapted for gRPC):
  1. Business logic lives in async namespace classes
     (``_CollectionsNamespace``, ``_PointsNamespace``, …).
  2. ``AsyncVectorAIClient`` exposes them directly.
  3. ``VectorAIClient`` wraps each namespace with ``_SyncProxy``
     which bridges every ``async def`` into a blocking call on a
     background event-loop thread.
"""

from __future__ import annotations

import asyncio
import concurrent.futures
import contextvars
import functools
import inspect
import logging
import threading
from typing import Any, Coroutine, TypeVar

import grpc

from actian_vectorai.exceptions import ErrorCode, VectorAIError, from_grpc_error
from actian_vectorai.exceptions import TimeoutError as VaiTimeoutError

__all__ = [
    "BackgroundLoop",
    "SyncProxy",
    "grpc_call",
]

logger = logging.getLogger("actian_vectorai.executor")

T = TypeVar("T")


# ─── Background Event-Loop Thread ────────────────────────────


class BackgroundLoop:
    """A daemon thread running an ``asyncio`` event loop.

    Used by ``VectorAIClient`` (the synchronous client) to execute
    coroutines produced by the async namespace classes without
    requiring the caller to manage an event loop.
    """

    __slots__ = ("_loop", "_thread")

    def __init__(self) -> None:
        self._loop: asyncio.AbstractEventLoop = asyncio.new_event_loop()
        self._thread = threading.Thread(
            target=self._run,
            name="vectorai-bg-loop",
            daemon=True,
        )
        self._thread.start()

    # ── internal ──────────────────────────────────────────────

    def _run(self) -> None:
        asyncio.set_event_loop(self._loop)
        try:
            self._loop.run_forever()
        except Exception:
            logger.exception("Background event loop crashed")
        finally:
            logger.debug("Background event loop thread exiting")

    # ── public API ────────────────────────────────────────────

    def run(self, coro: Coroutine[Any, Any, T], timeout: float | None = None) -> T:
        """Submit *coro* to the background loop and block until done.

        Copies the caller's :mod:`contextvars` context so that request
        correlation IDs and other context variables propagate across
        the sync → async boundary.
        """
        ctx = contextvars.copy_context()
        future = ctx.run(asyncio.run_coroutine_threadsafe, coro, self._loop)
        try:
            return future.result(timeout=timeout)
        except (TimeoutError, concurrent.futures.TimeoutError) as exc:
            future.cancel()
            raise VaiTimeoutError(operation="background-loop") from exc

    def close(self) -> None:
        """Stop the event loop and join the thread.

        Cancels any pending tasks before shutting down to avoid
        ``RuntimeWarning: coroutine was never awaited`` noise.
        """
        if self._loop.is_closed():
            return

        # Cancel all outstanding tasks so they don't leak.
        # We must exclude the cancel-task itself to avoid infinite recursion.
        async def _cancel_pending() -> None:
            current = asyncio.current_task()
            tasks = [t for t in asyncio.all_tasks(self._loop)
                     if not t.done() and t is not current]
            for t in tasks:
                t.cancel()
            if tasks:
                await asyncio.gather(*tasks, return_exceptions=True)

        try:
            asyncio.run_coroutine_threadsafe(_cancel_pending(), self._loop).result(timeout=3.0)
        except Exception:
            pass  # Best-effort; loop may already be stopping

        self._loop.call_soon_threadsafe(self._loop.stop)
        self._thread.join(timeout=5.0)
        if not self._loop.is_closed():
            self._loop.close()

    @property
    def loop(self) -> asyncio.AbstractEventLoop:
        return self._loop


# ─── Sync Proxy ──────────────────────────────────────────────


class SyncProxy:
    """Transparent sync wrapper around an async namespace object.

    Every public ``async def`` on the wrapped object becomes a
    regular blocking call routed through a ``BackgroundLoop``.
    Non-coroutine attributes are forwarded unchanged.

    Example::

        async_ns = _CollectionsNamespace(stubs)
        sync_ns  = SyncProxy(async_ns, loop)
        sync_ns.create("test", ...)          # blocks until done
    """

    __slots__ = ("_async_obj", "_loop")

    def __init__(self, async_obj: Any, loop: BackgroundLoop) -> None:
        object.__setattr__(self, "_async_obj", async_obj)
        object.__setattr__(self, "_loop", loop)

    def __getattr__(self, name: str) -> Any:
        attr = getattr(self._async_obj, name)
        if inspect.iscoroutinefunction(attr):

            @functools.wraps(attr)
            def _sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                return self._loop.run(attr(*args, **kwargs))

            return _sync_wrapper
        return attr

    def __repr__(self) -> str:
        return f"SyncProxy({self._async_obj!r})"


# ─── gRPC Call Helper ────────────────────────────────────────


async def grpc_call(
    stub_method: Any,
    request: Any,
    *,
    timeout: float | None = None,
    address: str | None = None,
    collection_name: str | None = None,
) -> Any:
    """Invoke a gRPC stub method with unified error mapping.

    All namespace methods call this instead of ``stub.Method()``
    directly, ensuring consistent exception translation via
    ``from_grpc_error()``.

    Parameters
    ----------
    stub_method:
        Bound method on a gRPC async stub, e.g. ``stubs.collections.Create``.
    request:
        The protobuf request message.
    timeout:
        Per-RPC deadline in seconds. ``None`` uses channel default.

    Returns
    -------
    The protobuf response message.

    Raises
    ------
    actian_vectorai.exceptions.*
        A specific VectorAI exception mapped from the gRPC status.
    """
    op_name = getattr(stub_method, "__name__", "unknown")
    try:
        return await stub_method(request, timeout=timeout)
    except asyncio.CancelledError:
        logger.debug("RPC '%s' was cancelled", op_name)
        raise
    except grpc.RpcError as exc:
        try:
            raise from_grpc_error(exc, operation=op_name, address=address, collection_name=collection_name) from exc
        except grpc.RpcError:
            raise  # from_grpc_error itself failed; propagate original
    except asyncio.TimeoutError as exc:
        raise VaiTimeoutError(operation=op_name) from exc
    except Exception as exc:
        if isinstance(exc, VaiTimeoutError):
            raise
        raise VectorAIError(
            f"Unexpected error during '{op_name}'",
            code=ErrorCode.INTERNAL_SERVER_ERROR,
            operation=op_name,
        ) from exc
