#
# Copyright (c) 2026 by Actian Corporation
# All rights reserved.
#
# THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE
# OF ACTIAN CORP.
# The copyright notice above does not evidence any actual or intended
# publication of such source code.
#

"""Type stubs for ``VectorAIClient`` — synchronous client.

These stubs restore IDE autocomplete for namespace methods that are
dynamically dispatched through :class:`SyncProxy`.  Without these
stubs, ``client.collections.create(…)`` would show no signature or
return-type hints.

Generated from the corresponding async namespace classes
(``_collections.py``, ``_points.py``, ``_vde.py``).
"""

from __future__ import annotations

import builtins
from collections.abc import Iterator
from typing import Any

import numpy as np

from actian_vectorai.models.auth import (
    AdminLoginResponse,
    ApiKeyCreated,
    ApiKeyInfo,
)
from actian_vectorai.models.collections import (
    CollectionInfo,
    HnswConfigDiff,
    OptimizersConfigDiff,
    QuantizationConfig,
    QuantizationConfigDiff,
    VectorParams,
    VectorParamsDiff,
)
from actian_vectorai.models.common import Filter, PointIdValue
from actian_vectorai.models.enums import (
    CollectionState,
    IndexType,
    RebuildTaskState,
)
from actian_vectorai.models.points import (
    DenseVector,
    PointStruct,
    PrefetchQuery,
    RetrievedPoint,
    ScoredPoint,
    SearchParams,
    UpdateResult,
    WithPayloadSelector,
    WithVectorsSelector,
)
from actian_vectorai.models.vde import (
    CollectionStats,
    CompactOptions,
    CompactStats,
    OptimizationsResponse,
    RebuildDataSourceConfig,
    RebuildRunConfig,
    RebuildStats,
    RebuildTargetConfig,
    RebuildTaskInfo,
)

# ═══════════════════════════════════════════════════════════
#  Sync namespace stubs
# ═══════════════════════════════════════════════════════════

class _SyncCollections:
    """Stub for ``VectorAIClient.collections`` — collections namespace."""

    # ── CRUD ──

    def create(
        self,
        name: str,
        *,
        vectors_config: VectorParams | dict[str, VectorParams] | None = None,
        hnsw_config: HnswConfigDiff | None = None,
        optimizers_config: OptimizersConfigDiff | None = None,
        quantization_config: QuantizationConfig | None = None,
        sparse_vectors_config: dict[str, Any] | None = None,
        timeout: float | None = None,
        index_type: IndexType | None = None,
        extra_params_json: str | None = None,
    ) -> bool: ...
    def get_info(self, name: str, *, timeout: float | None = None) -> CollectionInfo: ...
    def list(self, *, timeout: float | None = None) -> builtins.list[str]: ...
    def delete(self, name: str, *, strict: bool = True, timeout: float | None = None) -> bool: ...
    def exists(self, name: str, *, timeout: float | None = None) -> bool: ...
    def update(
        self,
        name: str,
        *,
        optimizers_config: OptimizersConfigDiff | None = None,
        hnsw_config: HnswConfigDiff | None = None,
        vectors_config: dict[str, VectorParamsDiff] | None = None,
        quantization_config: QuantizationConfigDiff | None = None,
        sparse_vectors_config: dict[str, Any] | None = None,
        timeout: float | None = None,
        vde_timeout: int | None = None,
    ) -> bool: ...

    # ── Convenience ──

    def recreate(
        self,
        name: str,
        *,
        vectors_config: VectorParams | dict[str, VectorParams] | None = None,
        timeout: float | None = None,
        **kwargs: Any,
    ) -> bool: ...
    def get_or_create(
        self,
        name: str,
        *,
        vectors_config: VectorParams | dict[str, VectorParams] | None = None,
        timeout: float | None = None,
        **kwargs: Any,
    ) -> CollectionInfo: ...

class _SyncPoints:
    """Stub for ``VectorAIClient.points`` — points namespace."""

    # ── CRUD ──

    def upsert(
        self,
        collection_name: str,
        points: list[PointStruct],
        *,
        timeout: float | None = None,
    ) -> UpdateResult: ...
    def delete(
        self,
        collection_name: str,
        *,
        ids: list[PointIdValue] | None = None,
        filter: Filter | None = None,
        strict: bool = True,
        track_ids: bool = False,
        timeout: float | None = None,
    ) -> UpdateResult: ...
    def get(
        self,
        collection_name: str,
        ids: list[PointIdValue],
        *,
        with_payload: bool | WithPayloadSelector = True,
        with_vectors: bool | WithVectorsSelector = False,
        timeout: float | None = None,
    ) -> list[RetrievedPoint]: ...
    def update_vectors(
        self,
        collection_name: str,
        points: list[dict[str, Any]],
        *,
        timeout: float | None = None,
    ) -> UpdateResult: ...

    # ── Payload ──

    def set_payload(
        self,
        collection_name: str,
        payload: dict[str, Any],
        *,
        ids: list[PointIdValue] | None = None,
        filter: Filter | None = None,
        key: str | None = None,
        timeout: float | None = None,
    ) -> UpdateResult: ...
    def overwrite_payload(
        self,
        collection_name: str,
        payload: dict[str, Any],
        *,
        ids: list[PointIdValue] | None = None,
        filter: Filter | None = None,
        key: str | None = None,
        timeout: float | None = None,
    ) -> UpdateResult: ...
    def delete_payload(
        self,
        collection_name: str,
        keys: list[str],
        *,
        ids: list[PointIdValue] | None = None,
        filter: Filter | None = None,
        strict: bool = True,
        timeout: float | None = None,
    ) -> UpdateResult: ...
    def clear_payload(
        self,
        collection_name: str,
        *,
        ids: list[PointIdValue] | None = None,
        filter: Filter | None = None,
        timeout: float | None = None,
    ) -> UpdateResult: ...

    # ── Search ──

    def search(
        self,
        collection_name: str,
        vector: list[float] | np.ndarray[Any, Any] | DenseVector,
        *,
        limit: int = 10,
        filter: Filter | None = None,
        params: SearchParams | None = None,
        score_threshold: float | None = None,
        using: str | None = None,
        with_payload: bool | WithPayloadSelector = True,
        with_vectors: bool | WithVectorsSelector = False,
        sparse_indices: list[int] | None = None,
        timeout: float | None = None,
    ) -> list[ScoredPoint]: ...
    def search_batch(
        self,
        collection_name: str,
        searches: list[dict[str, Any]],
        *,
        timeout: float | None = None,
    ) -> list[list[ScoredPoint]]: ...

    # ── Count ──

    def count(
        self,
        collection_name: str,
        *,
        filter: Filter | None = None,
        timeout: float | None = None,
    ) -> int: ...

    # ── Scroll ──

    def scroll(
        self,
        collection_name: str,
        *,
        offset: PointIdValue | None = None,
        limit: int | None = None,
        filter: Filter | None = None,
        with_payload: bool | WithPayloadSelector = True,
        with_vectors: bool | WithVectorsSelector = False,
        timeout: float | None = None,
    ) -> tuple[list[RetrievedPoint], PointIdValue | None]: ...
    def scroll_all(
        self,
        collection_name: str,
        *,
        limit: int | None = None,
        filter: Filter | None = None,
        with_payload: bool | WithPayloadSelector = True,
        with_vectors: bool | WithVectorsSelector = False,
        timeout: float | None = None,
    ) -> Iterator[list[RetrievedPoint]]: ...

    # ── Query (universal) ──

    def query(
        self,
        collection_name: str,
        *,
        query: Any | None = None,
        prefetch: list[PrefetchQuery] | None = None,
        using: str | None = None,
        filter: Filter | None = None,
        params: SearchParams | None = None,
        score_threshold: float | None = None,
        limit: int = 10,
        with_payload: bool | WithPayloadSelector = True,
        with_vectors: bool | WithVectorsSelector = False,
        timeout: float | None = None,
    ) -> list[ScoredPoint]: ...
    def query_batch(
        self,
        collection_name: str,
        queries: list[dict[str, Any]],
        *,
        timeout: float | None = None,
    ) -> list[list[ScoredPoint]]: ...

    # ── Convenience ──

    def upsert_single(
        self,
        collection_name: str,
        id: PointIdValue,
        vector: list[float] | np.ndarray[Any, Any],
        payload: dict[str, Any] | None = None,
        *,
        timeout: float | None = None,
    ) -> UpdateResult: ...
    def delete_by_ids(
        self,
        collection_name: str,
        ids: list[PointIdValue],
        *,
        strict: bool = True,
        timeout: float | None = None,
    ) -> UpdateResult: ...

class _SyncVDE:
    """Stub for ``VectorAIClient.vde`` — VDE extensions namespace."""

    # ── Lifecycle ──

    def open_collection(self, name: str, *, timeout: float | None = None) -> bool: ...
    def close_collection(self, name: str, *, timeout: float | None = None) -> bool: ...

    # ── Status & Statistics ──

    def get_state(self, name: str, *, timeout: float | None = None) -> CollectionState: ...
    def get_vector_count(self, name: str, *, timeout: float | None = None) -> int: ...
    def get_stats(self, name: str, *, timeout: float | None = None) -> CollectionStats: ...
    def get_optimizations(
        self,
        name: str,
        *,
        include_completed: bool | None = None,
        completed_limit: int | None = None,
        timeout: float | None = None,
    ) -> OptimizationsResponse: ...

    # ── Maintenance ──

    def flush(self, name: str, *, timeout: float | None = None) -> bool: ...
    def rebuild_index(self, name: str, *, timeout: float | None = None) -> bool: ...
    def optimize(self, name: str, *, timeout: float | None = None) -> bool: ...

    # ── Rebuild Management ──

    def trigger_rebuild(
        self,
        name: str,
        *,
        source: RebuildDataSourceConfig | None = None,
        target: RebuildTargetConfig | None = None,
        run_config: RebuildRunConfig | None = None,
        wait: bool | None = None,
        wait_timeout: int | None = None,
        priority: int | None = None,
        timeout: float | None = None,
    ) -> tuple[str, RebuildStats | None]: ...
    def get_rebuild_task(
        self,
        task_id: str,
        *,
        timeout: float | None = None,
    ) -> RebuildTaskInfo: ...
    def list_rebuild_tasks(
        self,
        *,
        collection_name: str | None = None,
        state: RebuildTaskState | None = None,
        limit: int | None = None,
        offset: int | None = None,
        timeout: float | None = None,
    ) -> tuple[list[RebuildTaskInfo], int]: ...
    def cancel_rebuild_task(
        self,
        task_id: str,
        *,
        timeout: float | None = None,
    ) -> bool: ...

    # ── Advanced Operations ──

    def compact_collection(
        self,
        name: str,
        *,
        options: CompactOptions | None = None,
        wait: bool = True,
        wait_timeout: int | None = None,
        timeout: float | None = None,
    ) -> tuple[str, CompactStats | None]: ...
    def import_dataset(
        self,
        collection_name: str,
        dataset_name: str,
        *,
        timeout: float | None = None,
    ) -> bool: ...

# ═══════════════════════════════════════════════════════════
#  Auth namespace stub
# ═══════════════════════════════════════════════════════════

class _SyncAuth:
    """Stub for ``VectorAIClient.auth`` — admin and API key management."""

    def admin_exists(self) -> bool: ...
    def create_admin(self, password: str) -> None: ...
    def delete_admin(self, *, admin_jwt: str | None = None) -> None: ...
    def login(self, password: str) -> AdminLoginResponse: ...
    def reset_admin_password(
        self, old_password: str, new_password: str
    ) -> None: ...
    def is_auth_enabled(self, *, admin_jwt: str) -> bool: ...
    def set_auth_enabled(self, enabled: bool, *, admin_jwt: str) -> bool: ...
    def create_api_key(
        self,
        name: str,
        *,
        permission: str = "read,write",
        description: str = "",
        will_expire: bool = False,
        expires_in_seconds: int = 0,
        admin_jwt: str | None = None,
        admin_api_key: str | None = None,
    ) -> ApiKeyCreated: ...
    def list_api_keys(
        self,
        *,
        admin_jwt: str | None = None,
        admin_api_key: str | None = None,
    ) -> list[ApiKeyInfo]: ...
    def delete_api_key(
        self,
        key_id: int,
        *,
        admin_jwt: str | None = None,
        admin_api_key: str | None = None,
    ) -> None: ...
    def rotate_api_key(
        self,
        key_id: int,
        *,
        admin_jwt: str | None = None,
        admin_api_key: str | None = None,
    ) -> ApiKeyCreated: ...

# ═══════════════════════════════════════════════════════════
#  Sync client
# ═══════════════════════════════════════════════════════════

class VectorAIClient:
    """Synchronous client for Actian VectorAI DB.

    Mirrors the full ``AsyncVectorAIClient`` API surface without
    requiring ``async`` / ``await``.
    """

    def __init__(self, url: str | None = None, **kwargs: Any) -> None: ...

    # ── Typed namespace properties ────────────────────────────

    @property
    def collections(self) -> _SyncCollections: ...
    @property
    def points(self) -> _SyncPoints: ...
    @property
    def vde(self) -> _SyncVDE: ...
    @property
    def auth(self) -> _SyncAuth: ...
    @property
    def is_connected(self) -> bool: ...

    # ── Connection lifecycle ──────────────────────────────────

    def connect(self) -> None: ...
    def close(self) -> None: ...
    def shutdown(self) -> None: ...
    def __enter__(self) -> VectorAIClient: ...
    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None: ...

    # ── Top-level convenience ─────────────────────────────────

    def health_check(self, *, timeout: float | None = None) -> dict[str, Any]: ...
    def upload_points(
        self,
        collection_name: str,
        points: list[PointStruct],
        *,
        batch_size: int = 256,
        timeout: float | None = None,
    ) -> int: ...
    def __repr__(self) -> str: ...
