from pathlib import Path
from typing import Any

from platformdirs import user_config_dir, user_data_dir  # One is for getiing the root folder and another for storing sessions , logs etc
try:
    import tomllib  # stdlib, Python 3.11+
except ImportError:
    import tomli as tomllib  # fallback for Python < 3.11

from config.config import Config
from utils.errors import ConfigError
import logging

logger = logging.getLogger(__name__)
CONFIG_FILE_NAME = "config.toml"

AGENT_MD_FILE = "AGENT.MD"

def get_config_dir() -> Path:
    # Inside root /.agent
    # ~/pratik/.aiagent
    return Path(user_config_dir("ai-agent"))

def get_data_dir() -> Path:
    return Path(user_data_dir("ai-agent"))


def get_system_config_path() -> Path:
    return get_config_dir() / CONFIG_FILE_NAME

def _parse_toml(path: Path):
    try:
        with open(path, "rb") as f:
            return tomllib.load(f)
    except tomllib.TOMLDecodeError as e:
        raise ConfigError(f"Invalid TOML in {path}: {e}", config_file=str(path)) from e
    except (OSError, IOError) as e:
        raise ConfigError(
            f"Failed to read config file {path}: {e}", config_file=str(path)
        ) from e

def _get_project_config(cwd: Path) -> Path | None:
    current = cwd.resolve()
    agent_dir = current / ".ai-agent"

    if agent_dir.is_dir():
        config_file = agent_dir / CONFIG_FILE_NAME
        if config_file.is_file():
            return config_file

    return None


def _get_agent_md_files(cwd: Path) -> Path | None:
    current = cwd.resolve()

    if current.is_dir():
        agent_md_file = current / AGENT_MD_FILE
        if agent_md_file.is_file():
            content = agent_md_file.read_text(encoding="utf-8")
            return content

    return None

def _merge_dicts(base : dict[str, Any], override : dict[str, Any]) -> dict[str, Any]:
    result = base.copy()

    for key, value in override.items():

        # Checking if the value of a key in result and override are dict then recurively merge those 2 dicts again
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            # Both the items are dict so merge again
            result[key] = _merge_dicts(result[key], value)
        else:
            # Update the base key
            result[key] = value

    return result            


def _normalize_config_dict(config_dict: dict[str, Any]) -> dict[str, Any]:
    model_config = config_dict.get("model")
    if isinstance(model_config, dict):
        # Backward compatibility: accept model.model_name in config TOML.
        if "name" not in model_config and "model_name" in model_config:
            model_config["name"] = model_config.pop("model_name")

    return config_dict

def load_config(cwd: Path | None) -> Config:
    cwd = cwd or Path.cwd()

    system_path = get_system_config_path()

    config_dict: dict[str, Any] = {}

    # C:/Users/...
    if system_path.is_file():
        try:
            config_dict = _parse_toml(system_path)
        except ConfigError:
            logger.warning(f"Skipping invalid system config: {system_path}")

    project_path = _get_project_config(cwd)
    # For config file/s in cwd

    if project_path:
        try:
            project_config_dict = _parse_toml(project_path)
            config_dict = _merge_dicts(config_dict, project_config_dict)
        except ConfigError as e:
            raise ConfigError(
                f"Invalid project config file: {project_path}",
                config_file=str(project_path),
                cause=e,
            ) from e

    if "cwd" not in config_dict:
        config_dict["cwd"] = cwd

    if "developer_instructions" not in config_dict:
        agent_md_content = _get_agent_md_files(cwd)
        if agent_md_content:
            config_dict["developer_instructions"] = agent_md_content

    config_dict = _normalize_config_dict(config_dict)

    try:
        config = Config(**config_dict)
    except Exception as e:
        raise ConfigError(f"Invalid configuration: {e}") from e

    return config