# Copyright 2025 Bosutech XXI S.L.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import gc
import os
import time
from collections.abc import Callable
from functools import wraps
from inspect import isasyncgenfunction, iscoroutinefunction, isgeneratorfunction
from typing import TYPE_CHECKING, Any, Literal, TypeVar

import prometheus_client
from typing_extensions import assert_never

if TYPE_CHECKING:  # pragma: no cover
    from traceback import StackSummary
else:
    StackSummary = None

OK = "ok"
ERROR = "error"
INF = float("inf")

_STATUS_METRIC = "status"
_VERSION_METRIC = "version"
_VERSION_ENV_VAR_NAME = "VERSION"


F = TypeVar("F", bound=Callable[..., Any])


class Observer:
    def __init__(
        self,
        name: str,
        *,
        error_mappings: dict[str, type[Exception] | type[BaseException]] | None = None,
        labels: dict[str, str] | None = None,
        buckets: list[float] | None = None,
    ):
        self.error_mappings = error_mappings or {}
        self.labels = labels or {}

        assert (
            # managed by us, do not allow user to specify
            labels is None or (_STATUS_METRIC not in labels and _VERSION_METRIC not in labels)
        )

        if _VERSION_ENV_VAR_NAME in os.environ:
            self.labels[_VERSION_METRIC] = os.environ[_VERSION_ENV_VAR_NAME]

        self.counter = prometheus_client.Counter(
            f"{name}_count",
            f"Number of times {name} was called.",
            labelnames=(*tuple(self.labels.keys()), _STATUS_METRIC),
        )
        hist_kwargs = {}
        if buckets is not None:
            hist_kwargs["buckets"] = buckets
        self.histogram = prometheus_client.Histogram(
            f"{name}_duration_seconds",
            f"Histogram for {name} duration.",
            labelnames=tuple(self.labels.keys()),
            **hist_kwargs,  # type: ignore
        )

    def wrap(self, labels: dict[str, str] | None = None) -> Callable[[F], F]:
        def decorator(func):
            if iscoroutinefunction(func):

                @wraps(func)
                async def inner(*args, **kwargs):
                    with ObserverRecorder(self, labels or {}):
                        return await func(*args, **kwargs)

            elif isasyncgenfunction(func):

                @wraps(func)
                async def inner(*args, **kwargs):
                    with ObserverRecorder(self, labels or {}):
                        async for item in func(*args, **kwargs):
                            yield item

            elif isgeneratorfunction(func):

                @wraps(func)
                def inner(*args, **kwargs):
                    with ObserverRecorder(self, labels or {}):
                        yield from func(*args, **kwargs)

            else:

                @wraps(func)
                def inner(*args, **kwargs):
                    with ObserverRecorder(self, labels or {}):
                        return func(*args, **kwargs)

            return inner

        return decorator

    def __call__(self, labels: dict[str, str] | None = None):
        return ObserverRecorder(self, labels or {})


class ObserverRecorder:
    def __init__(self, observer: Observer, label_overrides: dict[str, str]):
        self.observer = observer
        if len(label_overrides) > 0:
            self.labels = observer.labels.copy()
            self.labels.update(label_overrides)
        else:
            self.labels = observer.labels

    def set_status(self, status: str):
        self.labels[_STATUS_METRIC] = status

    def start(self):
        self.start = time.monotonic()

    def end(self):
        finished = time.monotonic()
        status = self.labels.pop(_STATUS_METRIC, OK)

        if len(self.labels) > 0:
            self.observer.histogram.labels(**self.labels).observe(finished - self.start)
        else:
            self.observer.histogram.observe(finished - self.start)

        self.observer.counter.labels(status=status, **self.labels).inc()

    def __enter__(self):
        self.start()
        return self

    def __exit__(
        self,
        exc_type: type[Exception] | type[BaseException] | None,
        exc_value: Exception | BaseException | None,
        traceback: "StackSummary | None",
    ):
        if exc_type is not None:
            status = ERROR
            for error_label, error_type in self.observer.error_mappings.items():
                if issubclass(exc_type, error_type):
                    status = error_label
                    break
            self.set_status(status)

        self.end()


class Gauge:
    def __init__(self, name: str, *, labels: dict[str, str] | None = None):
        self.labels = labels or {}
        if _VERSION_ENV_VAR_NAME in os.environ:
            self.labels[_VERSION_METRIC] = os.environ[_VERSION_ENV_VAR_NAME]

        self.gauge = prometheus_client.Gauge(
            name, f"Gauge for {name}.", labelnames=tuple(self.labels.keys())
        )

    def set(self, value: float | int, labels: dict[str, str] | None = None):
        merged_labels = self.labels.copy()
        merged_labels.update(labels or {})

        if len(merged_labels) > 0:
            self.gauge.labels(**merged_labels).set(value)
        else:
            self.gauge.set(value)

    def inc(self, value: float | int, labels: dict[str, str] | None = None):
        merged_labels = self.labels.copy()
        merged_labels.update(labels or {})

        if len(merged_labels) > 0:
            self.gauge.labels(**merged_labels).inc(value)
        else:
            self.gauge.inc(value)

    def dec(self, value: float | int, labels: dict[str, str] | None = None):
        merged_labels = self.labels.copy()
        merged_labels.update(labels or {})

        if len(merged_labels) > 0:
            self.gauge.labels(**merged_labels).dec(value)
        else:
            self.gauge.dec(value)

    def remove(self, labels: dict[str, str]):
        self.gauge.remove(*[labels[k] for k in self.labels.keys()])


class Counter:
    def __init__(self, name: str, *, labels: dict[str, str] | None = None):
        self.labels = labels or {}
        if _VERSION_ENV_VAR_NAME in os.environ:
            self.labels[_VERSION_METRIC] = os.environ[_VERSION_ENV_VAR_NAME]

        self.counter = prometheus_client.Counter(
            name, f"Counter for {name}.", labelnames=tuple(self.labels.keys())
        )

    def inc(self, labels: dict[str, str] | None = None, value: float | int = 1):
        merged_labels = self.labels.copy()
        merged_labels.update(labels or {})

        if len(merged_labels) > 0:
            self.counter.labels(**merged_labels).inc(value)
        else:
            self.counter.inc(value)


class Histogram:
    def __init__(
        self,
        name: str,
        *,
        labels: dict[str, str] | None = None,
        buckets: list[float] | None = None,
    ):
        self.labels = labels or {}
        if _VERSION_ENV_VAR_NAME in os.environ:
            self.labels[_VERSION_METRIC] = os.environ[_VERSION_ENV_VAR_NAME]

        kwargs = {}
        if buckets is not None:
            kwargs["buckets"] = buckets
        self.histo = prometheus_client.Histogram(
            name,
            f"Counter for {name}.",
            labelnames=tuple(self.labels.keys()),
            **kwargs,  # type: ignore
        )

    def observe(self, value: float, labels: dict[str, str] | None = None):
        merged_labels = self.labels.copy()
        merged_labels.update(labels or {})
        if len(merged_labels) > 0:
            self.histo.labels(**merged_labels).observe(value)
        else:
            self.histo.observe(value)


gc_collection_time = Histogram(
    "garbage_collector_collection_time_seconds",
    buckets=[
        0.000_250,  # 250µs
        0.000_500,  # 500µs
        0.001,  # 1ms
        0.002_5,  # 2.5ms
        0.005,  # 5ms
        0.010,  # 10ms
        0.025,  # 25ms
        0.050,  # 50ms
        0.100,  # 100ms
        0.250,  # 250ms
        0.500,  # 0.5s
        INF,
    ],
)


class GarbageCollectorObserver:
    """See https://docs.python.org/3/library/gc.html#gc.callbacks for more
    details on the Python garbage collector

    """

    def __init__(self):
        self.collection_start = None

    def callback(
        self,
        phase: Literal["start"] | Literal["stop"],
        info: dict[Literal["generation"] | Literal["collected"] | Literal["uncollectable"], int],
    ):
        if phase == "start":
            self.collection_start = time.monotonic()

        elif phase == "stop":
            if self.collection_start is None:
                return

            collection_time_s = time.monotonic() - self.collection_start
            gc_collection_time.observe(collection_time_s)
            self.collection_start = None

        else:
            assert_never(phase)


def instrument_garbage_collector():
    observer = GarbageCollectorObserver()
    gc.callbacks.append(observer.callback)


__all__ = (
    "ERROR",
    "OK",
    "Counter",
    "Gauge",
    "Histogram",
    "Observer",
    "ObserverRecorder",
    "instrument_garbage_collector",
)
