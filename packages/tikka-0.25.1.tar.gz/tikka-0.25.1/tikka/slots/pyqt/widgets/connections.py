# Copyright 2021 Vincent Texier <vit@free.fr>
#
# This software is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
import sys
from typing import Optional

from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget

from tikka.domains.application import Application
from tikka.domains.entities.constants import (
    DATA_PATH,
)
from tikka.domains.entities.events import (
    DataPodsEvent,
    IndexersEvent,
    NodesEvent,
)
from tikka.domains.entities.node import Node
from tikka.slots.pyqt.entities.constants import (
    ICON_NETWORK_CONNECTED,
    ICON_NETWORK_DISCONNECTED,
)
from tikka.slots.pyqt.entities.event_bus import EventBus
from tikka.slots.pyqt.entities.worker import ThreadManager
from tikka.slots.pyqt.resources.gui.widgets.connections_rc import Ui_ConnectionsWidget


class ConnectionsWidget(QWidget, Ui_ConnectionsWidget):
    """
    ConnectionsWidget class
    """

    def __init__(
        self,
        application: Application,
        parent: Optional[QWidget] = None,
    ) -> None:
        """
        Init ConnectionWidget instance

        :param application: Application instance
        :param parent: MainWindow instance
        """
        super().__init__(parent=parent)
        self.setupUi(self)

        self.application = application
        self._ = self.application.translator.gettext

        self.event_bus: EventBus = EventBus.instance()
        self.event_bus.repository_data_updated.connect(
            self.on_repository_data_updated_event
        )
        self.event_bus.currency_opened.connect(self.on_currency_opened_event)
        self.event_bus.node_connected.connect(self.on_node_connected_event)
        self.event_bus.node_disconnected.connect(self.on_node_disconnected_event)
        self.event_bus.node_updated.connect(self.on_node_updated_event)
        self.event_bus.indexer_connected.connect(self.on_indexer_connected_event)
        self.event_bus.indexer_disconnected.connect(self.on_indexer_disconnected_event)
        self.event_bus.datapod_connected.connect(self.on_datapod_connected_event)
        self.event_bus.datapod_disconnected.connect(self.on_datapod_disconnected_event)

        self.connected_button_text = self._("Disconnect")
        self.disconnected_button_text = self._("Connect")

        self.init_node_urls()
        self.init_indexer_urls()
        self.init_datapod_urls()

        if self.application.connections.node.is_connected():
            self.on_node_connected_event()
        else:
            self.on_node_disconnected_event()

        if self.application.connections.indexer.is_connected():
            self.on_indexer_connected_event()
        else:
            self.on_indexer_disconnected_event()

        if self.application.connections.datapod.is_connected():
            self.on_datapod_connected_event()
        else:
            self.on_datapod_disconnected_event()

        # events
        self.nodeUrlsComboBox.activated.connect(
            self.on_node_urls_combobox_index_changed
        )
        self.nodeConnectButton.clicked.connect(
            self._on_node_connect_button_clicked_event
        )
        self.refreshNodeButton.clicked.connect(
            self._on_refresh_node_button_clicked_event
        )

        self.indexerUrlsComboBox.activated.connect(
            self.on_indexer_urls_combobox_index_changed
        )
        self.indexerConnectButton.clicked.connect(
            self._on_indexer_connect_button_clicked_event
        )
        self.refreshIndexerButton.clicked.connect(
            self._on_refresh_indexer_button_clicked_event
        )

        self.dataPodUrlsComboBox.activated.connect(
            self.on_datapod_urls_combobox_index_changed
        )
        self.dataPodConnectButton.clicked.connect(
            self._on_datapod_connect_button_clicked_event
        )
        self.refreshDataPodButton.clicked.connect(
            self._on_refresh_datapod_button_clicked_event
        )

        # subscribe to application events
        self.application.event_dispatcher.add_event_listener(
            NodesEvent.EVENT_TYPE_LIST_CHANGED,
            lambda event: self.init_node_urls(),
        )
        self.application.event_dispatcher.add_event_listener(
            IndexersEvent.EVENT_TYPE_LIST_CHANGED,
            lambda event: self.init_indexer_urls(),
        )
        self.application.event_dispatcher.add_event_listener(
            DataPodsEvent.EVENT_TYPE_LIST_CHANGED,
            lambda event: self.init_datapod_urls(),
        )

        ##############################
        # ASYNC METHODS
        ##############################
        self.thread_manager: ThreadManager = ThreadManager(self)

        if self.application.connections.node.is_connected():
            self.thread_manager.start(
                self.fetch_node_from_network, self.on_finished_fetch_node_from_network
            )
        if self.application.connections.indexer.is_connected():
            self.thread_manager.start(
                self.fetch_indexer_from_network,
                self.on_finished_fetch_indexer_from_network,
            )
        if self.application.connections.datapod.is_connected():
            self.thread_manager.start(
                self.fetch_datapod_from_network,
                self.on_finished_fetch_datapod_from_network,
            )

    def on_repository_data_updated_event(self):
        """
        Triggered when the main window has updated repository data

        :return:
        """
        self._update_ui()

    def init_node_urls(self) -> None:
        """
        Init combobox with node urls

        :return:
        """
        self.nodeUrlsComboBox.clear()

        urls = [node.url for node in self.application.nodes.list()]
        self.nodeUrlsComboBox.addItems(urls)
        # get current node url from domain
        current_node_url = self.application.nodes.get_current_url()
        if current_node_url in urls:
            self.nodeUrlsComboBox.setCurrentIndex(urls.index(current_node_url))

    def on_node_urls_combobox_index_changed(self):
        """
        Triggered when node url selection is changed

        :return:
        """
        url = self.nodeUrlsComboBox.currentText()
        if url:
            # disconnect current node
            self.application.nodes.network_disconnect()
            self.event_bus.node_disconnected.emit()

            # change node
            self.application.nodes.set_current_url(url)

            # connect to new node
            self.application.nodes.network_connect()

            if self.application.connections.node.is_connected():
                self.event_bus.node_connected.emit()
                self._update_ui()
                self.refreshNodeButton.setEnabled(False)
                self.thread_manager.start(
                    self.fetch_node_from_network,
                    self.on_finished_fetch_node_from_network,
                )
            else:
                self.event_bus.node_disconnected.emit()

    def _on_node_connect_button_clicked_event(self):
        """
        Triggered when user click on connect button

        :return:
        """
        # Disable button
        self.nodeConnectButton.setDisabled(True)
        self.thread_manager.start(
            self.toggle_node_connection, self._on_finished_toggle_node_connection
        )

    def toggle_node_connection(self):
        """
        Toggle node connection

        :return:
        """
        if self.application.connections.node.is_connected():
            self.application.nodes.network_disconnect()
        else:
            url = self.nodeUrlsComboBox.currentText()
            if url:
                self.application.nodes.network_connect()
                if self.application.connections.node.is_connected():
                    self.refreshNodeButton.setEnabled(False)
                    self.thread_manager.start(
                        self.fetch_node_from_network,
                        self.on_finished_fetch_node_from_network,
                    )

    def _on_finished_toggle_node_connection(self):
        """
        Triggered when toggle_node_connection is finished

        :return:
        """
        self.nodeConnectButton.setDisabled(False)
        if self.application.connections.node.is_connected():
            self.event_bus.node_connected.emit()
        else:
            self.event_bus.node_disconnected.emit()

    def _on_refresh_node_button_clicked_event(self):
        """
        Triggered when user click on refresh node button

        :return:
        """
        if self.application.connections.node.is_connected():
            self.refreshNodeButton.setEnabled(False)
            self.thread_manager.start(
                self.fetch_node_from_network, self.on_finished_fetch_node_from_network
            )

    def fetch_node_from_network(self):
        """
        Update node infos from current url connection

        :return:
        """
        try:
            self.application.nodes.network_fetch_current_node()
        except Exception:
            pass

    def on_finished_fetch_node_from_network(self):
        """
        Triggered when async request fetch_node_from_network is finished

        :return:
        """
        self.refreshNodeButton.setEnabled(True)
        self._update_ui()

    def init_indexer_urls(self) -> None:
        """
        Init combobox with indexer urls

        :return:
        """
        self.indexerUrlsComboBox.clear()

        urls = [indexer.url for indexer in self.application.indexers.list()]
        self.indexerUrlsComboBox.addItems(urls)
        # get current indexer url from domain
        current_indexer_url = self.application.indexers.get_current_url()
        if current_indexer_url in urls:
            self.indexerUrlsComboBox.setCurrentIndex(urls.index(current_indexer_url))

    def on_indexer_urls_combobox_index_changed(self):
        """
        Triggered when indexer url selection is changed

        :return:
        """
        url = self.indexerUrlsComboBox.currentText()
        if url:
            # disconnect current indexer
            self.application.indexers.network_disconnect()
            self.event_bus.indexer_disconnected.emit()

            # change indexer
            self.application.indexers.set_current_url(url)

            # connect to new indexer
            self.application.indexers.network_connect()

            if self.application.connections.indexer.is_connected():
                self.event_bus.indexer_connected.emit()
                self._update_ui()
                self.refreshIndexerButton.setEnabled(False)
                self.thread_manager.start(
                    self.fetch_indexer_from_network,
                    self.on_finished_fetch_indexer_from_network,
                )
            else:
                self.event_bus.indexer_disconnected.emit()

    def _on_indexer_connect_button_clicked_event(self):
        """
        Triggered when user click on indexer connect button

        :return:
        """
        self.indexerConnectButton.setDisabled(True)
        self.thread_manager.start(
            self.toggle_indexer_connection, self._on_finished_toggle_indexer_connection
        )

    def toggle_indexer_connection(self):
        """
        Toggle indexer connection

        :return:
        """
        if self.application.connections.indexer.is_connected():
            self.application.indexers.network_disconnect()
        else:
            url = self.indexerUrlsComboBox.currentText()
            if url:
                self.application.indexers.network_connect()
                if self.application.connections.indexer.is_connected():
                    self.refreshIndexerButton.setEnabled(False)
                    self.thread_manager.start(
                        self.fetch_indexer_from_network,
                        self.on_finished_fetch_indexer_from_network,
                    )

    def _on_finished_toggle_indexer_connection(self):
        """
        Triggered when toggle_indexer_connection is finished

        :return:
        """
        self.indexerConnectButton.setDisabled(False)
        if self.application.connections.indexer.is_connected():
            self.event_bus.indexer_connected.emit()
        else:
            self.event_bus.indexer_disconnected.emit()

    def _on_refresh_indexer_button_clicked_event(self):
        """
        Triggered when user click on refresh indexer button

        :return:
        """
        if self.application.connections.indexer.is_connected():
            self.refreshIndexerButton.setEnabled(False)
            self.thread_manager.start(
                self.fetch_indexer_from_network,
                self.on_finished_fetch_indexer_from_network,
            )

    def fetch_indexer_from_network(self):
        """
        Update indexer infos from current url connection

        :return:
        """
        try:
            self.application.indexers.network_fetch_current_indexer()
        except Exception:
            pass

    def on_finished_fetch_indexer_from_network(self):
        """
        Triggered when async request fetch_indexer_from_network is finished

        :return:
        """
        self.refreshIndexerButton.setEnabled(True)
        self._update_ui()

    def init_datapod_urls(self) -> None:
        """
        Init combobox with datapod urls

        :return:
        """
        self.dataPodUrlsComboBox.clear()

        urls = [datapod.url for datapod in self.application.datapods.list()]
        self.dataPodUrlsComboBox.addItems(urls)
        # get current datapod url from domain
        current_datapod_url = self.application.datapods.get_current_url()
        if current_datapod_url in urls:
            self.dataPodUrlsComboBox.setCurrentIndex(urls.index(current_datapod_url))

    def on_datapod_urls_combobox_index_changed(self):
        """
        Triggered when datapod url selection is changed

        :return:
        """
        url = self.dataPodUrlsComboBox.currentText()
        if url:
            # disconnect current datapod
            self.application.datapods.network_disconnect()
            self.event_bus.datapod_disconnected.emit()

            # change datapod
            self.application.datapods.set_current_url(url)

            # connect to new datapod
            self.application.datapods.network_connect()

            if self.application.connections.datapod.is_connected():
                self.event_bus.datapod_connected.emit()
                self._update_ui()
                self.refreshDataPodButton.setEnabled(False)
                self.thread_manager.start(
                    self.fetch_datapod_from_network,
                    self.on_finished_fetch_datapod_from_network,
                )
            else:
                self.event_bus.datapod_disconnected.emit()

    def _on_datapod_connect_button_clicked_event(self):
        """
        Triggered when user click on datapod connect button

        :return:
        """
        self.dataPodConnectButton.setDisabled(True)
        self.thread_manager.start(
            self.toggle_datapod_connection, self._on_finished_toggle_datapod_connection
        )

    def toggle_datapod_connection(self):
        """
        Toggle datapod connection

        :return:
        """
        if self.application.connections.datapod.is_connected():
            self.application.datapods.network_disconnect()
        else:
            url = self.dataPodUrlsComboBox.currentText()
            if url:
                self.application.datapods.network_connect()
                if self.application.connections.datapod.is_connected():
                    self.refreshDataPodButton.setEnabled(False)
                    self.thread_manager.start(
                        self.fetch_datapod_from_network,
                        self.on_finished_fetch_datapod_from_network,
                    )

    def _on_finished_toggle_datapod_connection(self):
        """
        Triggered when toggle_datapod_connection is finished

        :return:
        """
        self.dataPodConnectButton.setDisabled(False)
        if self.application.connections.datapod.is_connected():
            self.event_bus.datapod_connected.emit()
        else:
            self.event_bus.datapod_disconnected.emit()

    def _on_refresh_datapod_button_clicked_event(self):
        """
        Triggered when user click on refresh datapod button

        :return:
        """
        # Disable button
        if self.application.connections.datapod.is_connected():
            self.refreshDataPodButton.setEnabled(False)
            self.thread_manager.start(
                self.fetch_datapod_from_network,
                self.on_finished_fetch_datapod_from_network,
            )

    def fetch_datapod_from_network(self):
        """
        Update datapod infos from current url connection

        :return:
        """
        try:
            self.application.datapods.network_fetch_current_datapod()
        except Exception:
            pass

    def on_finished_fetch_datapod_from_network(self):
        """
        Triggered when async request fetch_datapod_from_network is finished

        :return:
        """
        self.refreshDataPodButton.setEnabled(True)
        self._update_ui()

    def _update_ui(self):
        """
        Update node infos in UI

        :return:
        """
        node_url = self.nodeUrlsComboBox.currentText()
        if node_url:
            node = self.application.nodes.get(node_url)
            if node is None:
                self.softwareValueLabel.setText("")
                self.versionValueLabel.setText("")
                self.peerIDValueLabel.setText("")
                self.nodeBlockValueLabel.setText("?")
                self.epochValueLabel.setText("?")
                self.unsafeAPIExposedValueLabel.setText("")
            else:
                self.softwareValueLabel.setText(node.software)
                self.versionValueLabel.setText(node.software_version)
                self.peerIDValueLabel.setText(node.peer_id)
                self.nodeBlockValueLabel.setText(str(node.block or "?"))
                self.epochValueLabel.setText(str(node.epoch_index))
                self.unsafeAPIExposedValueLabel.setText(
                    self._("Yes") if node.unsafe_api_exposed is True else self._("No")
                )

        indexer_url = self.indexerUrlsComboBox.currentText()
        if indexer_url:
            indexer = self.application.indexers.get(indexer_url)
            if indexer is None or indexer.block is None:
                self.indexerBlockValueLabel.setText("?")
            else:
                self.indexerBlockValueLabel.setText(str(indexer.block))

        datapod_url = self.dataPodUrlsComboBox.currentText()
        if datapod_url:
            datapod = self.application.datapods.get(datapod_url)
            if datapod is None or datapod.block is None:
                self.dataPodBlockValueLabel.setText("?")
            else:
                self.dataPodBlockValueLabel.setText(str(datapod.block))

    def on_currency_opened_event(self, _: str):
        """
        When a currency opened event is triggered

        :param _: Currency code name
        :return:
        """
        self.init_node_urls()
        self.init_indexer_urls()
        self.init_datapod_urls()

    def on_node_connected_event(self):
        """
        Triggered when node is connected

        :return:
        """
        current_node_url = self.application.nodes.get_current_url()
        url_index = self.nodeUrlsComboBox.findText(current_node_url)
        if url_index >= 0:
            self.nodeUrlsComboBox.setCurrentIndex(url_index)
        self.nodeConnectButton.setText(self.connected_button_text)
        self.nodeConnectionStatusLabel.setPixmap(QPixmap(ICON_NETWORK_CONNECTED))
        self._update_ui()

    def on_node_disconnected_event(self):
        """
        Triggered when node is disconnected

        :return:
        """
        self.nodeConnectButton.setText(self.disconnected_button_text)
        self.nodeConnectionStatusLabel.setPixmap(QPixmap(ICON_NETWORK_DISCONNECTED))
        self._update_ui()

    def on_node_updated_event(self, _: Node):
        """
        Triggered when node data is updated

        :param _: Node instance
        :return:
        """
        self._update_ui()

    def on_indexer_connected_event(self):
        """
        Triggered when indexer is connected

        :return:
        """
        current_indexer_url = self.application.indexers.get_current_url()
        url_index = self.indexerUrlsComboBox.findText(current_indexer_url)
        if url_index >= 0:
            self.indexerUrlsComboBox.setCurrentIndex(url_index)
        self.indexerConnectButton.setText(self.connected_button_text)
        self.indexerConnectionStatusLabel.setPixmap(QPixmap(ICON_NETWORK_CONNECTED))
        self._update_ui()

    def on_indexer_disconnected_event(self):
        """
        Triggered when indexer is disconnected

        :return:
        """
        self.indexerConnectButton.setText(self.disconnected_button_text)
        self.indexerConnectionStatusLabel.setPixmap(QPixmap(ICON_NETWORK_DISCONNECTED))
        self._update_ui()

    def on_datapod_connected_event(self):
        """
        Triggered when datapod is connected

        :return:
        """
        current_datapod_url = self.application.datapods.get_current_url()
        url_index = self.dataPodUrlsComboBox.findText(current_datapod_url)
        if url_index >= 0:
            self.dataPodUrlsComboBox.setCurrentIndex(url_index)
        self.dataPodConnectButton.setText(self.connected_button_text)
        self.dataPodConnectionStatusLabel.setPixmap(QPixmap(ICON_NETWORK_CONNECTED))
        self._update_ui()

    def on_datapod_disconnected_event(self):
        """
        Triggered when datapod is disconnected

        :return:
        """
        self.dataPodConnectButton.setText(self.disconnected_button_text)
        self.dataPodConnectionStatusLabel.setPixmap(QPixmap(ICON_NETWORK_DISCONNECTED))
        self._update_ui()


if __name__ == "__main__":
    qapp = QApplication(sys.argv)

    application_ = Application(DATA_PATH)

    main_window = QMainWindow()
    main_window.show()

    main_window.setCentralWidget(ConnectionsWidget(application_, main_window))

    sys.exit(qapp.exec_())
