# Copyright 2021 Vincent Texier <vit@free.fr>
#
# This software is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
import logging
import sys
from typing import Optional

from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget

from tikka.domains.application import Application
from tikka.domains.entities.constants import DATA_PATH
from tikka.slots.pyqt.resources.gui.widgets.account_search_row_rc import (
    Ui_SearchAccountRowWidget,
)


class AccountSearchRowWidget(QWidget, Ui_SearchAccountRowWidget):
    """
    AccountSearchRowWidget class
    """

    def __init__(
        self,
        account_address: str,
        account_balance: str,
        account_v1_address: Optional[str],
        identity_name: str,
        identity_status: str,
        identity_status_color: str,
        is_smith: bool,
        identity_is_linked: bool,
        parent: Optional[QWidget] = None,
    ) -> None:
        """
        Init AccountSearchRowWidget instance

        :param account_address: Account address label text
        :param account_balance: Account balance label text
        :param account_v1_address: Account V1 address label text
        :param identity_name: Identity name label text
        :param identity_status: Identity status
        :param identity_status_color: Identity status color
        :param is_smith: True to display smith icon
        :param identity_is_linked: True to display identity as linked
        :param parent: MainWindow instance
        """
        super().__init__(parent=parent)
        self.setupUi(self)

        account_identity_name_color = "blue"

        self.accountAddressValuelabel.setText(account_address)
        self.accountBalanceValueLabel.setText(account_balance)

        if account_v1_address is not None:
            self.accountAdressV1ValueLabel.setText(account_v1_address)

        self.identityNameValueLabel.setText(identity_name)
        self.identityNameValueLabel.setStyleSheet(
            f'color: "{account_identity_name_color}"'
        )
        self.identityStatusValueLabel.setText(identity_status)
        self.identityStatusValueLabel.setStyleSheet(f'color: "{identity_status_color}"')
        self.smithIconLabel.setVisible(is_smith)

        if identity_is_linked:
            self.italic_font = QFont()
            self.italic_font.setStyle(QFont.StyleItalic)
            self.identityNameValueLabel.setFont(self.italic_font)
            self.identityStatusValueLabel.setFont(self.italic_font)


if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    qapp = QApplication(sys.argv)

    application = Application(DATA_PATH)

    main_window = QMainWindow()
    main_window.show()
    account_address = "5D3r...8uI9"
    account_balance = "30,15 Ğ1"
    account_v1_address = "5D3r...8uI9:xxx"
    identity_name = "vic#67"
    identity_status = "Member"
    identity_status_color = "green"
    is_smith = True
    identity_is_linked = False
    widget = AccountSearchRowWidget(
        account_address,
        account_balance,
        account_v1_address,
        identity_name,
        identity_status,
        identity_status_color,
        is_smith,
        identity_is_linked,
        main_window,
    )
    main_window.setCentralWidget(widget)

    sys.exit(qapp.exec_())
