# Copyright 2021 Vincent Texier <vit@free.fr>
#
# This software is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
import sys
from typing import Optional

from PyQt5.QtCore import QPoint, Qt
from PyQt5.QtGui import QColor
from PyQt5.QtWidgets import QApplication, QMainWindow, QStyledItemDelegate, QWidget

from tikka.domains.application import Application
from tikka.domains.entities.constants import (
    DATA_PATH,
)
from tikka.domains.entities.events import (
    IndexersEvent,
)
from tikka.domains.entities.indexer import Indexer
from tikka.slots.pyqt.entities.constants import (
    INDEXERS_TABLE_SORT_COLUMN_PREFERENCES_KEY,
    INDEXERS_TABLE_SORT_ORDER_PREFERENCES_KEY,
)
from tikka.slots.pyqt.entities.event_bus import EventBus
from tikka.slots.pyqt.entities.worker import ThreadManager
from tikka.slots.pyqt.models.indexers import IndexersTableModel
from tikka.slots.pyqt.resources.gui.widgets.network_indexers_rc import (
    Ui_NetworkIndexersWidget,
)
from tikka.slots.pyqt.widgets.indexer_menu import IndexerPopupMenu
from tikka.slots.pyqt.windows.indexer_add import IndexerAddWindow


class HighlightIndexerDelegate(QStyledItemDelegate):
    """
    Class to highlight connected indexer row
    """

    def __init__(self, table_model, application):
        """
        Initialize HighlightIndexerDelegate instance

        :param table_model: TableModel of
        :param application:
        """
        super().__init__()
        self.table_model = table_model
        self.application = application

    def paint(self, painter, option, index):
        # get current url/row indexer
        current_indexer_url = self.application.indexers.get_current_url()
        indexer = self.table_model.indexers[index.row()]
        # check connection...
        if indexer.url == current_indexer_url:
            color = (
                QColor("lightgreen")
                if self.application.connections.indexer.is_connected()
                else QColor("lightcoral")
            )
            painter.fillRect(option.rect, color)

        # paint rectangle
        super().paint(painter, option, index)


class NetworkIndexersWidget(QWidget, Ui_NetworkIndexersWidget):
    """
    NetworkIndexersWidget class
    """

    def __init__(
        self,
        application: Application,
        parent: Optional[QWidget] = None,
    ) -> None:
        """
        Init NetworkIndexersWidget instance

        :param application: Application instance
        :param parent: MainWindow instance
        """
        super().__init__(parent=parent)
        self.setupUi(self)

        self.application = application
        self._ = self.application.translator.gettext

        self.event_bus = EventBus.instance()
        self.event_bus.indexer_connected.connect(self.on_indexer_connection_event)
        self.event_bus.indexer_disconnected.connect(self.on_indexer_connection_event)
        self.event_bus.repository_data_updated.connect(
            self.on_repository_data_updated_event
        )
        self.event_bus.currency_opened.connect(self.on_repository_data_updated_event)

        self.selected_indexer: Optional[Indexer] = None

        self.indexers_table_model = IndexersTableModel(self.application)
        self.indexersTableView.setModel(self.indexers_table_model)
        self.indexersTableView.resizeColumnsToContents()
        self.indexersTableView.setItemDelegate(
            HighlightIndexerDelegate(self.indexers_table_model, self.application)
        )
        pref_sort_column = self.application.repository.preferences.get(
            INDEXERS_TABLE_SORT_COLUMN_PREFERENCES_KEY
        )
        if pref_sort_column is None:
            sort_column = 0
        else:
            sort_column = int(pref_sort_column)

        pref_sort_order = self.application.repository.preferences.get(
            INDEXERS_TABLE_SORT_ORDER_PREFERENCES_KEY
        )
        if pref_sort_order is None:
            sort_order = int(Qt.SortOrder.AscendingOrder)
        else:
            sort_order = int(pref_sort_order)
        self.indexersTableView.sortByColumn(sort_column, sort_order)

        # events
        self.addIndexerButton.clicked.connect(self._on_add_indexer_button_clicked)
        self.indexersTableView.doubleClicked.connect(self.on_indexer_table_double_click)
        self.indexersTableView.customContextMenuRequested.connect(
            self.on_indexer_context_menu
        )

        # subscribe to application events
        self.application.event_dispatcher.add_event_listener(
            IndexersEvent.EVENT_TYPE_LIST_CHANGED, self._on_indexer_list_changed_event
        )

        ##############################
        # ASYNC METHODS
        ##############################
        self.thread_manager: ThreadManager = ThreadManager(self)

    def on_indexer_connection_event(self):
        """
        Triggered when indexer connection has changed

        :return:
        """
        self.indexersTableView.viewport().update()

    def _on_add_indexer_button_clicked(self):
        """
        Trigger when user click on add indexer button

        :return:
        """
        IndexerAddWindow(self.application, self).exec_()

    def on_repository_data_updated_event(self, _=None):
        """
        When a currency opened event is triggered

        :param _: CurrencyEvent instance
        :return:
        """
        # update model
        self.indexersTableView.model().init_data()

        # resize view
        self.indexersTableView.resizeColumnsToContents()

    def _on_indexer_list_changed_event(self, _):
        """
        When the indexer list has changed

        :param _: IndexersEvent instance
        :return:
        """
        # update model
        self.indexersTableView.model().init_data()
        # resize view
        self.indexersTableView.resizeColumnsToContents()

    def on_indexer_context_menu(self, position: QPoint):
        """
        When right button on indexer table view

        :param position: QPoint instance
        :return:
        """
        index = self.indexersTableView.indexAt(position)
        if index.isValid():
            # get selected indexer
            row = index.row()
            indexer = self.indexers_table_model.indexers[row]
            # display popup menu at click position
            IndexerPopupMenu(self.application, indexer).exec_(
                self.indexersTableView.mapToGlobal(position)
            )

    def on_indexer_table_double_click(self, index):
        """
        Triggered when user double-click on a row of indexer table view
        """
        row = index.row()
        # check index...
        if 0 <= row < len(self.indexers_table_model.indexers):
            self.selected_indexer = self.indexers_table_model.indexers[row]
            self.thread_manager.start(
                self.toggle_indexer_connection,
                self._on_finished_toggle_indexer_connection,
            )

    def toggle_indexer_connection(self):
        """
        Toggle indexer connection

        :return:
        """
        if self.selected_indexer is None:
            return
        # current url connected
        current_indexer_url = self.application.indexers.get_current_url()

        # if same server...
        if self.selected_indexer.url == current_indexer_url:
            # toggle connection...
            if self.application.connections.indexer.is_connected():
                self.application.indexers.network_disconnect()
            else:
                self.application.indexers.network_connect()
        else:
            # connect to another server...
            self.application.indexers.set_current_url(self.selected_indexer.url)
            self.application.indexers.network_connect()

    def _on_finished_toggle_indexer_connection(self):
        """
        Triggered when toggle_indexer_connection is finished

        :return:
        """
        if self.application.connections.indexer.is_connected():
            self.event_bus.indexer_connected.emit()
        else:
            self.event_bus.indexer_disconnected.emit()


if __name__ == "__main__":
    qapp = QApplication(sys.argv)

    application_ = Application(DATA_PATH)

    main_window = QMainWindow()
    main_window.show()

    main_window.setCentralWidget(NetworkIndexersWidget(application_, main_window))

    sys.exit(qapp.exec_())
