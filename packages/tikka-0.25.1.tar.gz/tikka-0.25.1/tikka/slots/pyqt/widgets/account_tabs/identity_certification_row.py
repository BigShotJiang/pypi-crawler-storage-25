# Copyright 2021 Vincent Texier <vit@free.fr>
#
# This software is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
import logging
import sys
from typing import Optional

from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget

from tikka.domains.application import Application
from tikka.domains.entities.constants import DATA_PATH
from tikka.slots.pyqt.resources.gui.widgets.account_certification_row_rc import (
    Ui_AccountCertificationRowWidget,
)


class AccountCertificationRowWidget(QWidget, Ui_AccountCertificationRowWidget):
    """
    AccountCertificationRowWidget class
    """

    def __init__(
        self,
        account_address: str,
        account_name: str,
        identity_name: str,
        identity_status: str,
        identity_status_color: str,
        created_on: str,
        updated_on: str,
        expire_on: str,
        expire_on_color: str,
        parent: Optional[QWidget] = None,
    ) -> None:
        """
        Init AccountTransferRowWidget instance

        :param account_address: Account address label text
        :param account_name: Account name
        :param identity_name: Identity name label text
        :param identity_status: Identity status
        :param identity_status_color: Identity status color
        :param created_on: Created On Datetime label text
        :param updated_on: Updated On Datetime label text
        :param expire_on: Expire On Datetime label text
        :param parent: MainWindow instance
        """
        super().__init__(parent=parent)
        self.setupUi(self)

        account_identity_name_color = "blue"

        self.accountAddressValuelabel.setText(account_address)

        self.identityNameValueLabel.setStyleSheet(
            f'color: "{account_identity_name_color}"'
        )
        self.accountNameValueLabel.setText(
            f" - {account_name}" if account_name is not None else ""
        )
        self.identityNameValueLabel.setText(identity_name)
        self.identityStatusValueLabel.setText(identity_status)
        self.identityStatusValueLabel.setStyleSheet(f'color: "{identity_status_color}"')
        self.createdOnValueLabel.setText(created_on)
        self.updatedOnValueLabel.setText(updated_on)
        self.expireOnValueLabel.setText(expire_on)
        self.expireOnValueLabel.setStyleSheet(
            f"""
        color: white;
        border : 3px solid {expire_on_color};
        border-radius: 10%;
        background: {expire_on_color};"""
        )


if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    qapp = QApplication(sys.argv)

    application = Application(DATA_PATH)

    main_window = QMainWindow()
    main_window.show()
    account_address = "5D3r...8uI9"
    account_name = "Vince"
    identity_name = "vic#67"
    identity_status = "Member"
    identity_status_color = "green"
    created_on = "01/02/2024"
    updated_on = "(renewed on 01/02/2025)"
    expire_on = "expire on 01/02/2027"
    expire_on_color = "green"
    widget = AccountCertificationRowWidget(
        account_address,
        account_name,
        identity_name,
        identity_status,
        identity_status_color,
        created_on,
        updated_on,
        expire_on,
        expire_on_color,
        main_window,
    )
    main_window.setCentralWidget(widget)

    sys.exit(qapp.exec_())
