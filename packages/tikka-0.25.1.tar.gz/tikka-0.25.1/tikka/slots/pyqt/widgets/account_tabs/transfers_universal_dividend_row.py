# Copyright 2021 Vincent Texier <vit@free.fr>
#
# This software is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
import logging
import sys
from typing import Optional

from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget

from tikka.domains.application import Application
from tikka.domains.entities.constants import DATA_PATH
from tikka.slots.pyqt.resources.gui.widgets.account_universal_dividend_row_rc import (
    Ui_AccountUniversalDividendRowWidget,
)


class AccountUniversalDividendRowWidget(QWidget, Ui_AccountUniversalDividendRowWidget):
    """
    AccountUniversalDividendRowWidget class
    """

    def __init__(
        self,
        identity_name: str,
        datetime: str,
        amount: str,
        parent: Optional[QWidget] = None,
    ) -> None:
        """
        Init AccountUniversalDividendRowWidget instance

        :param identity_name: Identity name label text
        :param datetime: Datetime label text
        :param amount: Amount label text
        :param parent: MainWindow instance
        """
        super().__init__(parent=parent)
        self.setupUi(self)

        account_identity_name_color = "blue"

        self.identityNameValueLabel.setStyleSheet(
            f'color: "{account_identity_name_color}"'
        )
        self.identityNameValueLabel.setText(identity_name)

        self.datetimeValueLabel.setText(datetime)

        self.amountValueLabel.setText(amount)


if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    qapp = QApplication(sys.argv)

    application = Application(DATA_PATH)

    main_window = QMainWindow()
    main_window.show()
    account_address = "5D3r...8uI9"
    account_name = "Vince"
    identity_name = "vic#67"
    datetime = "01/02/2025 - 21:50:06"
    amount = "-257 G1"
    comment = "Merci pour les crêpes"
    widget = AccountUniversalDividendRowWidget(
        identity_name,
        datetime,
        amount,
        main_window,
    )
    main_window.setCentralWidget(widget)

    sys.exit(qapp.exec_())
