# Copyright 2021 Vincent Texier <vit@free.fr>
#
# This software is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
import sys
from typing import Optional

from PyQt5.QtWidgets import QApplication, QMenu, QWidget

from tikka.domains.application import Application
from tikka.domains.entities.account import Account
from tikka.domains.entities.constants import DATA_PATH
from tikka.slots.pyqt.entities.event_bus import EventBus


class TechnicalCommitteePopupMenu(QMenu):
    """
    TechnicalCommitteePopupMenu class
    """

    def __init__(
        self,
        application: Application,
        address: str,
        parent: Optional[QWidget] = None,
    ):
        """
        Init TechnicalCommitteePopupMenu instance

        :param application: Application instance
        :param address: Technical Committee Member address
        :param parent: QWidget instance
        """
        super().__init__(parent=parent)

        self.application = application
        self.address = address
        self._ = self.application.translator.gettext

        self.event_bus: EventBus = EventBus.instance()

        # Clipboard action
        copy_address_to_clipboard_action = self.addAction(
            self._("Copy address to clipboard")
        )
        copy_address_to_clipboard_action.triggered.connect(
            self.copy_address_to_clipboard
        )

        # Get member account
        self.account = self.application.accounts.get_by_address(self.address)

        # Add address to accounts action
        add_account_address_action = self.addAction(self._("Add address to accounts"))
        add_account_address_action.triggered.connect(self.add_address_to_accounts)

        # Disable "Add address to accounts" if account already exists
        if self.account is not None:
            add_account_address_action.setEnabled(False)

    def copy_address_to_clipboard(self):
        """
        Copy address of selected row to clipboard

        :return:
        """
        clipboard = QApplication.clipboard()
        clipboard.setText(self.address)

    def add_address_to_accounts(self):
        """
        Add a new account from member address

        :return:
        """
        self.account = Account(self.address)

        self.application.accounts.add(self.account)
        self.event_bus.account_added.emit(self.account)


if __name__ == "__main__":
    qapp = QApplication(sys.argv)

    application_ = Application(DATA_PATH)
    address_ = "732SSfuwjB7jkt9th1zerGhphs6nknaCBCTozxUcPWPU"

    menu = TechnicalCommitteePopupMenu(application_, address_)
    menu.exec_()

    sys.exit(qapp.exec_())
