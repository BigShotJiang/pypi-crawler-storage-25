# Copyright 2021 Vincent Texier <vit@free.fr>
#
# This software is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.


from typing import Optional

from PyQt5.QtWidgets import QDialog, QWidget

from tikka import __version__
from tikka.domains.application import Application
from tikka.slots.pyqt.resources.gui.windows.updated_rc import Ui_UpdatedDialog


class UpdatedWindow(QDialog, Ui_UpdatedDialog):
    """
    UpdatedWindow class
    """

    def __init__(self, application: Application, parent: Optional[QWidget] = None):
        """
        Init about window

        :param application: Application instance
        :param parent: QWidget instance
        """
        super().__init__(parent=parent)
        self.setupUi(self)

        self.application = application
        self._ = self.application.translator.gettext

        self.versionLabel.setText(
            self._("Tikka has been updated to Version {version_number}.").format(
                version_number=__version__
            )
        )
        self.buttonBox.button(self.buttonBox.Close).clicked.connect(self.close)


if __name__ == "__main__":
    from PyQt5.QtCore import QTranslator, QLibraryInfo
    import sys
    from PyQt5.QtWidgets import QApplication
    from tikka.domains.entities.constants import DATA_PATH

    qapp = QApplication(sys.argv)

    translator = QTranslator()
    if translator.load(
        "qtbase_fr", QLibraryInfo.location(QLibraryInfo.TranslationsPath)
    ):
        qapp.installTranslator(translator)

    application_ = Application(DATA_PATH)
    application_.select_language("en_US")
    UpdatedWindow(application_).exec_()
