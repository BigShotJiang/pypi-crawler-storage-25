# Copyright 2021 Vincent Texier <vit@free.fr>
#
# This software is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
import sys
from typing import Optional

from PyQt5 import QtCore, QtWidgets
from PyQt5.QtGui import QKeyEvent, QMovie
from PyQt5.QtWidgets import QApplication, QDialog, QWidget

from tikka.adapters.network.indexer.indexer import NetworkIndexer
from tikka.domains.application import Application
from tikka.domains.entities.constants import DATA_PATH
from tikka.domains.entities.events import IndexersEvent
from tikka.domains.entities.indexer import Indexer
from tikka.slots.pyqt.entities.constants import ICON_LOADER
from tikka.slots.pyqt.entities.worker import ThreadManager
from tikka.slots.pyqt.resources.gui.windows.indexer_add_rc import Ui_indexerAddDialog


class IndexerAddWindow(QDialog, Ui_indexerAddDialog):
    """
    IndexerAddWindow class
    """

    def __init__(self, application: Application, parent: Optional[QWidget] = None):
        """
        Init add indexer window

        :param application: Application instance
        :param parent: QWidget instance
        """
        super().__init__(parent=parent)
        self.setupUi(self)

        self.application = application
        self._ = self.application.translator.gettext

        self.network_indexer_adapter: Optional[NetworkIndexer] = None
        self.indexer: Optional[Indexer] = None
        self.indexer_genesis_block_hash: Optional[str] = None

        # buttons
        self.buttonBox.button(self.buttonBox.Ok).setEnabled(False)

        # animated loading icon
        self.loader_movie = QMovie(ICON_LOADER)
        self.loader_movie.start()
        self.loaderIconLabel.setMovie(self.loader_movie)
        loader_icon_size_policy = self.loaderIconLabel.sizePolicy()
        loader_icon_size_policy.setRetainSizeWhenHidden(True)
        self.loaderIconLabel.setSizePolicy(loader_icon_size_policy)
        self.loaderIconLabel.hide()

        # events
        self.urlLineEdit.keyPressEvent = self.on_url_line_edit_key_press_event
        self.testButton.clicked.connect(self._on_test_button_clicked)
        self.buttonBox.accepted.connect(self.on_accepted_button)
        self.buttonBox.rejected.connect(self.close)

        ##############################
        # ASYNC METHODS
        ##############################
        self.thread_manager: ThreadManager = ThreadManager(self)

    def on_url_line_edit_key_press_event(self, event: QKeyEvent):
        """
        Triggered when enter is pressed to validate url in url t line edit

        :param event: QKeyEvent instance
        :return:
        """
        if event.key() == QtCore.Qt.Key_Return:
            self._on_test_button_clicked()
        else:
            QtWidgets.QLineEdit.keyPressEvent(self.urlLineEdit, event)
            # if the key is not return, handle normally

    def _on_test_button_clicked(self):
        """
        Run when use click test button

        :return:
        """
        self.loaderIconLabel.show()
        self.testButton.setDisabled(True)
        self.thread_manager.start(
            self.network_get_indexer_infos, self._on_finished_network_get_indexer_infos
        )

    def network_get_indexer_infos(self):
        """
        Fetch indexer infos from the network

        :return:
        """
        url = self.urlLineEdit.text().strip()
        if url == "":
            return
        self.network_indexer_adapter = (
            self.application.indexers.network_get_indexer_adapter(url)
        )
        if self.network_indexer_adapter is not None:
            self.indexer = self.network_indexer_adapter.get()
            self.indexer_genesis_block_hash = (
                self.network_indexer_adapter.get_genesis_hash()
            )
        else:
            self.indexer = None
            self.indexer_genesis_block_hash = None

    def _on_finished_network_get_indexer_infos(self):
        """
        WHen async network_get_indexer_infos is finished

        :return:
        """
        self.testButton.setDisabled(False)
        self.loaderIconLabel.hide()

        if self.indexer is None:
            self.blockValueLabel.setText("")
            self.errorLabel.setText(self._("Impossible to connect"))
            self.buttonBox.button(self.buttonBox.Ok).setEnabled(False)
        else:
            self.errorLabel.setText("")
            self.blockValueLabel.setText(str(self.indexer.block))
            self.currencyHashValueLabel.setText(self.indexer_genesis_block_hash)
            self.buttonBox.button(self.buttonBox.Ok).setEnabled(True)

            if not self.application.indexers.check_genesis_hash(
                self.indexer_genesis_block_hash
            ):
                self.errorLabel.setText(
                    self._("Current genesis hash is\n{hash}").format(
                        hash=self.application.currencies.get_current().genesis_hash
                    )
                )
                self.buttonBox.button(self.buttonBox.Ok).setEnabled(False)

    def on_accepted_button(self) -> None:
        """
        Triggered when user click on ok button

        :return:
        """
        url = self.urlLineEdit.text()
        if self.application.indexers.get(url) is not None:
            return

        self.application.indexers.add(
            Indexer(
                url=self.urlLineEdit.text(),
                block=int(self.blockValueLabel.text()),
            )
        )

        self.application.event_dispatcher.dispatch_event(
            IndexersEvent(IndexersEvent.EVENT_TYPE_LIST_CHANGED)
        )


if __name__ == "__main__":
    qapp = QApplication(sys.argv)
    application_ = Application(DATA_PATH)
    IndexerAddWindow(application_).exec_()
