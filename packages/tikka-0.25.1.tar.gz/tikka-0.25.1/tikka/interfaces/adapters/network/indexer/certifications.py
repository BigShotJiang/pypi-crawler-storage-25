# Copyright 2021 Vincent Texier <vit@free.fr>
#
# This software is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import abc
from typing import Dict, List

from tikka.domains.entities.identity import Certification
from tikka.interfaces.adapters.network.indexer.indexer import NetworkIndexerInterface


class IndexerCertificationsInterface(abc.ABC):
    """
    IndexerCertificationsInterface class
    """

    COLUMN_EXPIRE_ON = "EXPIRE_ON"
    SORT_ORDER_ASCENDING = "ASC"
    SORT_ORDER_DESCENDING = "DESC"

    def __init__(self, indexer: NetworkIndexerInterface) -> None:
        """
        Init IndexerCertificationsInterface instance

        :param indexer: NetworkIndexerInterface instance
        :return:
        """
        self.indexer = indexer

    @abc.abstractmethod
    def get_by_index(
        self,
        identity_index: int,
        limit: int,
        offset: int = 0,
        sort_column: str = COLUMN_EXPIRE_ON,
        sort_order: str = SORT_ORDER_ASCENDING,
    ) -> List[Certification]:
        """
        Return list of certifications from and to identity_index

        :param identity_index: Identity index
        :param limit: Max number of certifications to return
        :param offset: Offset to paginate results
        :param sort_column: Sort column, default to IndexerCertificationsInterface.COLUMN_TIMESTAMP
        :param sort_order: Sort order, default to IndexerCertificationsInterface.SORT_ORDER_DESCENDING
        :return:
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_by_indice(
        self,
        identity_indice: List[int],
        limit: int,
        offset: int = 0,
        sort_column: str = COLUMN_EXPIRE_ON,
        sort_order: str = SORT_ORDER_ASCENDING,
    ) -> Dict[int, List[Certification]]:
        """
        Return list of certifications from and to identity index in identity_indice list

        :param identity_indice: List of identity index
        :param limit: Max number of certifications to return
        :param offset: Offset to paginate results
        :param sort_column: Sort column, default to IndexerCertificationsInterface.COLUMN_TIMESTAMP
        :param sort_order: Sort order, default to IndexerCertificationsInterface.SORT_ORDER_DESCENDING
        :return:
        """
        raise NotImplementedError


class IndexerCertificationsException(Exception):
    """
    IndexerCertificationsException class
    """
