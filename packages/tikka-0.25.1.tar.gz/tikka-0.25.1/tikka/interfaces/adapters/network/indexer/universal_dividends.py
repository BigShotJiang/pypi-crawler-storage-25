# Copyright 2021 Vincent Texier <vit@free.fr>
#
# This software is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import abc
from datetime import datetime
from typing import List, Optional

from tikka.domains.entities.universal_dividend import UniversalDividend
from tikka.interfaces.adapters.network.indexer.indexer import NetworkIndexerInterface


class IndexerUniversalDividendsInterface(abc.ABC):
    """
    IndexerUniversalDividendsInterface class
    """

    COLUMN_TIMESTAMP = "timestamp"

    SORT_ORDER_ASCENDING = "ASC"
    SORT_ORDER_DESCENDING = "DESC"

    def __init__(self, indexer: NetworkIndexerInterface) -> None:
        """
        Init IndexerUniversalDividendsInterface instance

        :param indexer: NetworkIndexerInterface instance
        :return:
        """
        self.indexer = indexer

    @abc.abstractmethod
    def list(
        self,
        address: str,
        limit: int,
        offset: int = 0,
        sort_column: str = COLUMN_TIMESTAMP,
        sort_order: str = SORT_ORDER_DESCENDING,
        from_datetime: Optional[datetime] = None,
        to_datetime: Optional[datetime] = None,
    ) -> List[UniversalDividend]:
        """
        Return list of Universal Dividends created on address

        :param address: Account address
        :param limit: Max number of Universal Dividends to return
        :param offset: Offset to paginate results
        :param sort_column: Sort column, default to IndexerUniversalDividendsInterface.COLUMN_TIMESTAMP
        :param sort_order: Sort order, default to IndexerUniversalDividendsInterface.SORT_ORDER_DESCENDING
        :param from_datetime: Only Universal Dividends from datetime, default to None
        :param to_datetime: Only Universal Dividends until datetime, default to None
        :return:
        """
        raise NotImplementedError

    @abc.abstractmethod
    def count(self, address: str) -> int:
        """
        Return transfers total count from and to address

        :param address: Account address
        :return:
        """
        raise NotImplementedError


class IndexerUniversalDividendsException(Exception):
    """
    IndexerUniversalDividendsException class
    """
