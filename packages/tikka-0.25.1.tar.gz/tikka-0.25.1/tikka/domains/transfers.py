# Copyright 2021 Vincent Texier <vit@free.fr>
#
# This software is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from tikka.adapters.network.node.substrate_client import ExtrinsicReceipt
from tikka.domains.currencies import Currencies
from tikka.domains.entities.account import Account
from tikka.domains.entities.transfer import Transfer, TransfersPage, TransfersResult
from tikka.domains.events import EventDispatcher
from tikka.domains.wallets import Wallets
from tikka.interfaces.adapters.network.indexer.transfers import (
    IndexerTransfersInterface,
)
from tikka.interfaces.adapters.network.node.transfers import NodeTransfersInterface
from tikka.interfaces.adapters.repository.transfers import TransfersRepositoryInterface
from tikka.libs.keypair import Keypair


def format_datetime(dt: datetime) -> str:
    """
    Formate une date en OFX (YYYYMMDDHHMMSS).

    :param dt: Datetime data
    :return:
    """
    return dt.strftime("%Y%m%d%H%M%S")


class Transfers:
    """
    Transfers domain class
    """

    def __init__(
        self,
        wallets: Wallets,
        repository: TransfersRepositoryInterface,
        currencies: Currencies,
        node_transfers: NodeTransfersInterface,
        indexer_transfers: IndexerTransfersInterface,
        event_dispatcher: EventDispatcher,
    ):
        """
        Init Transfers domain

        :param wallets: Wallets domain
        :param repository: TransfersRepositoryInterface adapter instance
        :param currencies: Currencies domain instance
        :param node_transfers: NodeTransfersInterface adapter instance
        :param event_dispatcher: EventDispatcher instance
        """
        self.wallets = wallets
        self.repository = repository
        self.currencies = currencies
        self.node_transfers = node_transfers
        self.indexer_transfers = indexer_transfers
        self.event_dispatcher = event_dispatcher

    def add(self, transfer: Transfer):
        """
        Add transfer to repository

        :param transfer: Transfer instance
        :return:
        """
        self.repository.add(transfer)

    def delete(self, transfer_id: str):
        """
        Delete transfer with transfer_id in repository

        :param transfer_id: Transfer ID to delete
        :return:
        """
        self.repository.delete(transfer_id)

    def delete_by_address(self, address: str) -> None:
        """
        Delete transfer history issued from or received by address

        :param address: Account address of transfers to delete
        :return:
        """
        self.repository.delete_by_address(address)

    def delete_all(self) -> None:
        """
        Delete all transfers in repository

        :return:
        """
        self.repository.delete_all()

    def count(self, address: str) -> int:
        """
        Return total number of transfers issued and received by address

        :return:
        """
        return self.repository.count(address)

    def list(
        self,
        address: str,
        filters: Optional[Dict[str, Any]] = None,
        sort_column: str = TransfersRepositoryInterface.COLUMN_TIMESTAMP,
        sort_order: str = TransfersRepositoryInterface.SORT_ORDER_DESCENDING,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Transfer]:
        """
        List transfers from and to address, from repository with optional filters and sort_column

        :param address: Account address
        :param filters: Dict with {column: value} filters or None
        :param sort_column: Sort column constant, TransfersRepositoryInterface.COLUMN_TIMESTAMP by default
        :param sort_order: Sort order constant, TransfersRepositoryInterface.SORT_ORDER_DESCENDING by default
        :param limit: Number of rows to return
        :param offset: Offset of first row to return
        :return:
        """
        return self.repository.list(
            address, filters, sort_column, sort_order, limit, offset
        )

    def network_fetch_history_for_account(self, account: Account, limit: int) -> None:
        """
        Fetch history of last transfers from and to account

        :param account: Account instance to filter issuers and receivers
        :param limit: Maximum number of transfers to fetch
        :return:
        """
        transfers = self.indexer_transfers.list(account.address, limit=limit)
        self.repository.set_history(account.address, transfers)

    def network_fetch_history_with_ud_for_account(
        self, account: Account, page: TransfersPage
    ) -> TransfersResult:
        """
        Fetch history of transfers from and to account, and UDs

        :param account: Account instance to filter issuers and receivers
        :param page: TransfersPage instance
        :return:
        """
        transfers_result = self.indexer_transfers.list_with_uds(account.address, page)
        if page.end_cursor is None:
            self.repository.set_history(account.address, transfers_result.transfers)

        return transfers_result

    def network_fetch_total_count_for_address(self, address: str) -> int:
        """
        Fetch total count of transfers from and to address

        :param address: Address to filter issuers and receivers
        :return:
        """
        return self.indexer_transfers.count(address)

    def network_fees(
        self, sender_keypair: Keypair, recipient_address: str, amount: int
    ) -> Optional[int]:
        """
        Fetch transfer fees from network and return it if request is successful

        :param sender_keypair: Sender Keypair instance
        :param recipient_address: Recipient address
        :param amount: Amount in blockchain unit
        :return:
        """
        return self.node_transfers.fees(sender_keypair, recipient_address, amount)

    def network_send(
        self,
        sender_keypair: Keypair,
        recipient_address: str,
        amount: int,
        comment: Optional[str] = None,
    ) -> Optional[ExtrinsicReceipt]:
        """
        Send transfer to network and return ExtrinsicReceipt if request is successful

        :param sender_keypair: Sender Keypair instance
        :param recipient_address: Recipient address
        :param amount: Amount in blockchain unit
        :param comment: Comment string
        :return:
        """
        return self.node_transfers.send(
            sender_keypair, recipient_address, amount, comment
        )

    def network_send_all(
        self,
        sender_keypair: Keypair,
        recipient_address: str,
        keep_alive: bool = False,
        comment: Optional[str] = None,
    ) -> Optional[ExtrinsicReceipt]:
        """
        Send transfer to network and return ExtrinsicReceipt if request is successful

        :param sender_keypair: Sender Keypair instance
        :param recipient_address: Recipient address
        :param keep_alive: Optional, default False
        :param comment: Comment string
        :return:
        """
        return self.node_transfers.send_all(
            sender_keypair, recipient_address, keep_alive, comment
        )

    def export_as_ofx(
        self,
        filepath: str,
        address: str,
        from_datetime: Optional[datetime] = None,
        to_datetime: Optional[datetime] = None,
    ):
        """
        Export transfers for address in an OFX format file

        :param filepath: Path of the file
        :param address: Account address
        :param from_datetime: Optional period start date
        :param to_datetime: Optional period end date
        :return:
        """
        page_size = 100

        with open(filepath, "w", encoding="utf-8") as f:
            # Écriture de l'en-tête OFX
            f.write(
                f"""OFXHEADER:100
    DATA:OFXSGML
    VERSION:102
    SECURITY:NONE
    ENCODING:USASCII
    CHARSET:1252
    COMPRESSION:NONE
    OLDFILEUID:NONE
    NEWFILEUID:NONE
    
    <OFX>
        <BANKMSGSRSV1>
            <STMTTRNRS>
                <STMTRS>
                    <CURDEF>EUR</CURDEF>
                    <BANKACCTFROM>
                        <BANKID>{self.currencies.get_current().name}</BANKID>
                        <ACCTID>{address}</ACCTID>
                        <ACCTTYPE>CHECKING</ACCTTYPE>
                    </BANKACCTFROM>
                    <BANKTRANLIST>
    """
            )
            page = TransfersPage(size=page_size)
            total_amount: float = 0.0
            while True:
                # get 100 transfers from network
                transfers_result: TransfersResult = (
                    self.indexer_transfers.list_with_uds(
                        address=address,
                        page=page,
                        from_datetime=from_datetime,
                        to_datetime=to_datetime,
                    )
                )
                for transfer in transfers_result.transfers:
                    if transfer.is_ud or transfer.receiver_address == address:
                        amount_sign = 1
                        name = (
                            f"{transfer.issuer_address} - {transfer.issuer_identity_name}#{transfer.issuer_identity_index}"
                            if transfer.issuer_identity_name
                            else transfer.issuer_address
                        )
                    else:
                        amount_sign = -1
                        name = (
                            f"{transfer.receiver_address} - {transfer.receiver_identity_name}#{transfer.receiver_identity_index}"
                            if transfer.receiver_identity_name
                            else transfer.receiver_address
                        )
                    transfer_amount = (int(transfer.amount) / 100) * amount_sign
                    total_amount += transfer_amount  # Convert cents to units

                    f.write(
                        f"""
                    <STMTTRN>
                        <TRNTYPE>XFER</TRNTYPE>
                        <DTPOSTED>{format_datetime(transfer.timestamp)}</DTPOSTED>
                        <TRNAMT>{transfer_amount:.2f}</TRNAMT>
                        <FITID>{transfer.id}</FITID>
                        <NAME>{name}</NAME>
                        <MEMO>{transfer.comment or ''}</MEMO>
                    </STMTTRN>
                    """
                    )
                if not transfers_result.page.has_next_page:
                    break
                page = transfers_result.page  # next cursor

            current_datetime = format_datetime(datetime.now(timezone.utc))

            # Écriture du pied de fichier OFX
            f.write(
                f"""
                    </BANKTRANLIST>
                    <LEDGERBAL>
                        <BALAMT>{total_amount:.2f}</BALAMT>
                        <DTASOF>{current_datetime}</DTASOF>
                    </LEDGERBAL>
                    <AVAILBAL>
                        <BALAMT>{total_amount:.2f}</BALAMT>
                        <DTASOF>{current_datetime}</DTASOF>
                    </AVAILBAL>
                </STMTRS>
            </STMTTRNRS>
        </BANKMSGSRSV1>
    </OFX>
    """
            )

        logging.debug(f"Export OFX terminé : {filepath}")
