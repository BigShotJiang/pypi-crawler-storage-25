# Copyright 2021 Vincent Texier <vit@free.fr>
#
# This software is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# Copyright  2014-2022 Vincent Texier <vit@free.fr>
#
# DuniterPy is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# DuniterPy is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
from __future__ import annotations

import binascii
import hashlib
import re
from hashlib import scrypt
from typing import Optional, Type, Union

import pyaes
from base58 import b58decode, b58encode

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import (
    Encoding,
    PublicFormat,
)

# Scrypt
SCRYPT_PARAMS = {"n": 4096, "r": 16, "p": 1, "seed_length": 32}


class ScryptParams:
    """
    Class to simplify handling of scrypt parameters
    """

    def __init__(
        self,
        n: int = SCRYPT_PARAMS["n"],
        r: int = SCRYPT_PARAMS["r"],
        p: int = SCRYPT_PARAMS["p"],
        seed_length: int = SCRYPT_PARAMS["seed_length"],
    ) -> None:
        """
        Init a ScryptParams instance with crypto parameters

        :param n: scrypt param N, default see constant SCRYPT_PARAMS
        :param r: scrypt param r, default see constant SCRYPT_PARAMS
        :param p: scrypt param p, default see constant SCRYPT_PARAMS
        :param seed_length: scrypt param seed_length, default see constant SCRYPT_PARAMS
        """
        self.N = n
        self.r = r
        self.p = p
        self.seed_length = seed_length


def ensure_bytes(data: Union[str, bytes]) -> bytes:
    """
    Convert data in bytes if data is a string

    :param data: Data
    :return:
    """
    if isinstance(data, str):
        return bytes(data, "utf-8")
    return data


def xor_bytes(b1: bytes, b2: bytes) -> bytearray:
    """
    Apply XOR operation on two bytes arguments

    :param b1: First bytes argument
    :param b2: Second bytes argument
    :return:
    """
    result = bytearray()
    for i1, i2 in zip(b1, b2):
        result.append(i1 ^ i2)
    return result


def hex_decode(data: bytes) -> bytes:
    """
    Convert hexadecimal byte string to bytes

    :param data: Data to decode
    :return:
    """
    return binascii.unhexlify(data)


def hex_encode(data: bytes) -> bytes:
    """
    Convert bytes to hexadecimal byte string

    :param data: Data to encode
    :return:
    """
    return binascii.hexlify(data)


class SigningKey:
    def __init__(self, seed: bytes) -> None:
        """
        Init a signing key from a 32-byte seed.

        :param seed: 32-byte seed (private key material)
        """
        if len(seed) != 32:
            raise ValueError("Seed must be 32 bytes")
        self.seed = seed

        # Generate Ed25519 key pair using cryptography
        self._private_key = Ed25519PrivateKey.from_private_bytes(seed)
        self.vk = self._private_key.public_key().public_bytes(
            encoding=Encoding.Raw, format=PublicFormat.Raw
        )
        self.sk = seed + self.vk
        self.pubkey = b58encode(self.vk).decode("utf8")

    @classmethod
    def from_credentials(
        cls: Type[SigningKey],
        salt: Union[str, bytes],
        password: Union[str, bytes],
        scrypt_params: Optional[ScryptParams] = None,
    ) -> SigningKey:
        """
        Create a SigningKey object from credentials

        :param salt: Secret salt passphrase credential
        :param password: Secret password credential
        :param scrypt_params: ScryptParams instance or None
        """
        if scrypt_params is None:
            scrypt_params = ScryptParams()

        salt = ensure_bytes(salt)
        password = ensure_bytes(password)
        seed = scrypt(
            password,
            salt=salt,
            n=scrypt_params.N,
            r=scrypt_params.r,
            p=scrypt_params.p,
            dklen=scrypt_params.seed_length,
        )

        return cls(seed)

    @classmethod
    def from_credentials_file(
        cls, path: str, scrypt_params: Optional[ScryptParams] = None
    ) -> SigningKey:
        """
        Create a SigningKey object from a credentials file

        A file with the salt on the first line and the password on the second line

        :param path: Credentials file path
        :param scrypt_params: ScryptParams instance or None
        :return:
        """
        with open(path, encoding="utf-8") as fh:
            lines = fh.readlines()
            assert len(lines) > 1
            salt = lines[0].strip()
            password = lines[1].strip()

        return cls.from_credentials(salt, password, scrypt_params)

    @classmethod
    def from_pubsec_file(cls: Type[SigningKey], path: str) -> SigningKey:
        """
        Return SigningKey instance from Duniter PubSec file

        :param path: Path to PubSec file
        """
        with open(path, encoding="utf-8") as fh:
            pubsec_content = fh.read()

        regex_pubkey = re.compile("pub: ([1-9A-HJ-NP-Za-km-z]{43,44})", re.MULTILINE)
        regex_signkey = re.compile("sec: ([1-9A-HJ-NP-Za-km-z]{87,90})", re.MULTILINE)

        match = re.search(regex_pubkey, pubsec_content)
        if not match:
            raise Exception("Error: Bad format PubSec v1 file, missing public key")

        match = re.search(regex_signkey, pubsec_content)
        if not match:
            raise Exception("Error: Bad format PubSec v1 file, missing sec key")

        signkey_hex = match.groups()[0]
        seed = bytes(b58decode(signkey_hex)[0:32])
        return cls(seed)

    @classmethod
    def from_wif_or_ewif_file(
        cls, path: str, password: Optional[str] = None
    ) -> SigningKey:
        """
        Return SigningKey instance from Duniter WIF or EWIF file

        :param path: Path to WIF or EWIF file
        :param password: Password needed for EWIF file
        """
        with open(path, encoding="utf-8") as fh:
            wif_content = fh.read()

        regex = re.compile("Data: ([1-9A-HJ-NP-Za-km-z]+)", re.MULTILINE)
        match = re.search(regex, wif_content)
        if not match:
            raise Exception("Error: Bad format WIF or EWIF v1 file")

        wif_hex = match.groups()[0]
        return cls.from_wif_or_ewif_hex(wif_hex, password)

    @classmethod
    def from_wif_or_ewif_hex(
        cls, wif_hex: str, password: Optional[str] = None
    ) -> SigningKey:
        """
        Return SigningKey instance from Duniter WIF or EWIF in hexadecimal format

        :param wif_hex: WIF or EWIF string in base58
        :param password: Password of EWIF encrypted seed
        """
        wif_bytes = b58decode(wif_hex)
        fi = wif_bytes[0:1]

        if fi == b"\x01":
            result = cls.from_wif_hex(wif_hex)
        elif fi == b"\x02" and password is not None:
            result = cls.from_ewif_hex(wif_hex, password)
        else:
            raise Exception("Error: Bad format: not WIF nor EWIF")
        return result

    @classmethod
    def from_wif_file(cls, path: str) -> SigningKey:
        """
        Return SigningKey instance from Duniter WIF file

        :param path: Path to WIF file
        """
        with open(path, encoding="utf-8") as fh:
            wif_content = fh.read()

        regex = re.compile("Data: ([1-9A-HJ-NP-Za-km-z]+)", re.MULTILINE)
        match = re.search(regex, wif_content)
        if not match:
            raise Exception("Error: Bad format WIF v1 file")

        wif_hex = match.groups()[0]
        return cls.from_wif_hex(wif_hex)

    @classmethod
    def from_wif_hex(cls: Type[SigningKey], wif_hex: str) -> SigningKey:
        """
        Return SigningKey instance from Duniter WIF in hexadecimal format

        :param wif_hex: WIF string in base58
        """
        wif_bytes = b58decode(wif_hex)
        if len(wif_bytes) != 35:
            raise Exception("Error: the size of WIF is invalid")

        checksum_from_wif = wif_bytes[-2:]
        fi = wif_bytes[0:1]
        seed = wif_bytes[1:-2]
        seed_fi = wif_bytes[0:-2]

        if fi != b"\x01":
            raise Exception("Error: bad format version, not WIF")

        # Replace libnacl.crypto_hash_sha256 with hashlib.sha256
        checksum = hashlib.sha256(hashlib.sha256(seed_fi).digest()).digest()[0:2]
        if checksum_from_wif != checksum:
            raise Exception("Error: bad checksum of the WIF")

        return cls(seed)

    @classmethod
    def from_ewif_file(cls, path: str, password: str) -> SigningKey:
        """
        Return SigningKey instance from Duniter EWIF file

        :param path: Path to EWIF file
        :param password: Password of the encrypted seed
        """
        with open(path, encoding="utf-8") as fh:
            wif_content = fh.read()

        regex = re.compile("Data: ([1-9A-HJ-NP-Za-km-z]+)", re.MULTILINE)
        match = re.search(regex, wif_content)
        if not match:
            raise Exception("Error: Bad format EWIF v1 file")

        ewif_hex = match.groups()[0]
        return cls.from_ewif_hex(ewif_hex, password)

    @classmethod
    def from_ewif_hex(
        cls: Type[SigningKey], ewif_hex: str, password: str
    ) -> SigningKey:
        """
        Return SigningKey instance from Duniter EWIF in hexadecimal format

        :param ewif_hex: EWIF string in base58
        :param password: Password of the encrypted seed
        """
        ewif_bytes = b58decode(ewif_hex)
        if len(ewif_bytes) != 39:
            raise Exception("Error: the size of EWIF is invalid")

        fi = ewif_bytes[0:1]
        checksum_from_ewif = ewif_bytes[-2:]
        ewif_no_checksum = ewif_bytes[0:-2]
        salt = ewif_bytes[1:5]
        encryptedhalf1 = ewif_bytes[5:21]
        encryptedhalf2 = ewif_bytes[21:37]

        if fi != b"\x02":
            raise Exception("Error: bad format version, not EWIF")

        # Replace libnacl.crypto_hash_sha256
        checksum = hashlib.sha256(hashlib.sha256(ewif_no_checksum).digest()).digest()[
            0:2
        ]
        if checksum_from_ewif != checksum:
            raise Exception("Error: bad checksum of the EWIF")

        # SCRYPT
        password_bytes = password.encode("utf-8")
        scrypt_seed = scrypt(password_bytes, salt=salt, n=16384, r=8, p=8, dklen=64)
        derivedhalf1 = scrypt_seed[0:32]
        derivedhalf2 = scrypt_seed[32:64]

        # AES
        aes = pyaes.AESModeOfOperationECB(derivedhalf2)
        decryptedhalf1 = aes.decrypt(encryptedhalf1)
        decryptedhalf2 = aes.decrypt(encryptedhalf2)

        # XOR
        seed1 = xor_bytes(decryptedhalf1, derivedhalf1[0:16])
        seed2 = xor_bytes(decryptedhalf2, derivedhalf1[16:32])
        seed = bytes(seed1 + seed2)

        # Password Control
        signer = SigningKey(seed)
        salt_from_seed = hashlib.sha256(
            hashlib.sha256(b58decode(signer.pubkey)).digest()
        ).digest()[0:4]
        if salt_from_seed != salt:
            raise Exception("Error: bad Password of EWIF address")

        return cls(seed)
