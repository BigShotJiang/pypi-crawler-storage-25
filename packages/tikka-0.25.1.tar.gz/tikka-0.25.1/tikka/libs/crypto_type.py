# Copyright 2021 Vincent Texier <vit@free.fr>
#
# This software is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
import sr25519


def is_valid_sr25519(public_key: bytes) -> bool:
    """
    Checks if a 32-byte public key is valid on Sr25519.
    Uses the derive_pubkey function as a cryptographic validity test.

    :param public_key: Public key to check
    :return:
    """
    if len(public_key) != 32:
        return False

    # Reject the null key (point at infinity)
    if all(b == 0 for b in public_key):
        return False

    try:
        # Create an ExtendedPubKey from the public key and a dummy chain code
        # The chain code is required by the format but does not affect key validity.
        fake_chain_code = bytes([0] * 32)  # A 32-byte chain code, as used in Polkadot

        # Attempt derivation with a dummy identifier
        # The byte string b'a' * 32 is an arbitrary identifier.
        _ = sr25519.derive_pubkey((fake_chain_code, public_key), b"a" * 32)

        # If we reach this point without an exception, the public key is structurally valid.
        return True
    except Exception:
        # Any exception (invalid key, invalid chain code, etc.) indicates an invalid key.
        return False
