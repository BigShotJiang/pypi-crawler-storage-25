# Copyright 2021 Vincent Texier <vit@free.fr>
#
# This software is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
from datetime import datetime
from typing import Dict, List, Optional

from dateutil import parser
from gql import gql

from tikka.domains.entities.transfer import Transfer, TransfersPage, TransfersResult
from tikka.interfaces.adapters.network.connection import NetworkConnectionError
from tikka.interfaces.adapters.network.indexer.transfers import (
    IndexerTransfersException,
    IndexerTransfersInterface,
)


class IndexerTransfers(IndexerTransfersInterface):
    """
    IndexerTransfers class
    """

    def list(
        self,
        address: str,
        limit: int,
        offset: int = 0,
        sort_column: str = IndexerTransfersInterface.COLUMN_TIMESTAMP,
        sort_order: str = IndexerTransfersInterface.SORT_ORDER_DESCENDING,
        from_datetime: Optional[datetime] = None,
        to_datetime: Optional[datetime] = None,
    ) -> List[Transfer]:
        __doc__ = IndexerTransfersInterface.list.__doc__

        if (
            not self.indexer.connection.is_connected()
            or self.indexer.connection.client is None
        ):
            raise IndexerTransfersException(NetworkConnectionError())

        date_filter = []
        if from_datetime:
            date_filter.append(
                f'{{ timestamp: {{ greaterThanOrEqualTo: "{from_datetime.isoformat()}" }} }}'
            )
        if to_datetime:
            date_filter.append(
                f'{{ timestamp: {{ lessThanOrEqualTo: "{to_datetime.isoformat()}" }} }}'
            )

        date_filter_str = "and: [" + ", ".join(date_filter) + "]" if date_filter else ""

        # Construire la requête GraphQL
        query = f"""
            query {{
              transfers(
                first: {limit}
                offset: {offset}
                orderBy: {sort_column.upper()}_{sort_order.upper()}
                filter: {{
                    or: [
                        {{ fromId: {{ equalTo: "{address}" }} }},
                        {{ toId: {{ equalTo: "{address}" }} }}
                    ]
                    {date_filter_str}
                }}
              ) {{
                nodes {{
                    id
                    fromId
                    from {{
                      identity {{
                        id
                        index
                        name
                      }}
                    }}
                    toId
                    to {{
                      identity {{
                        id
                        index
                        name
                      }}
                    }}
                    amount
                    timestamp
                    comment {{
                      type
                      remark
                      remarkBytes
                    }}
                }}
              }}
            }}
        """

        try:
            result = self.indexer.connection.client.execute(gql(query))
        except Exception as exception:
            raise IndexerTransfersException(exception)

        transfers = []
        for transfer in result["transfers"]["nodes"]:
            issuer_identity_index = (
                transfer["from"]["identity"]["index"]
                if transfer["from"]["identity"]
                else None
            )
            issuer_identity_name = (
                (
                    transfer["from"]["identity"]["name"]
                    if transfer["from"]["identity"]["name"]
                    != transfer["from"]["identity"]["id"]
                    else None
                )
                if transfer["from"]["identity"]
                else None
            )
            receiver_identity_index = (
                transfer["to"]["identity"]["index"]
                if transfer["to"]["identity"]
                else None
            )
            receiver_identity_name = (
                (
                    transfer["to"]["identity"]["name"]
                    if transfer["to"]["identity"]["name"]
                    != transfer["to"]["identity"]["id"]
                    else None
                )
                if transfer["to"]["identity"]
                else None
            )

            comment = None
            comment_type = None
            if transfer["comment"]:
                comment = (
                    transfer["comment"]["remarkBytes"]
                    if transfer["comment"]["type"] == "RAW"
                    else transfer["comment"]["remark"]
                )
                comment_type = transfer["comment"]["type"]

            transfers.append(
                Transfer(
                    account_address=address,
                    id=transfer["id"],
                    issuer_address=transfer["fromId"],
                    issuer_identity_index=issuer_identity_index,
                    issuer_identity_name=issuer_identity_name,
                    receiver_address=transfer["toId"],
                    receiver_identity_index=receiver_identity_index,
                    receiver_identity_name=receiver_identity_name,
                    amount=transfer["amount"],
                    timestamp=parser.parse(transfer["timestamp"]),
                    comment=comment,
                    comment_type=comment_type,
                    is_ud=False,
                )
            )

        return transfers

    def count(self, address) -> int:
        __doc__ = (  # pylint: disable=redefined-builtin, unused-variable
            IndexerTransfersInterface.count.__doc__
        )
        if (
            not self.indexer.connection.is_connected()
            or self.indexer.connection.client is None
        ):
            raise IndexerTransfersException(NetworkConnectionError())

        query = f"""
        query {{
          transfers(
            filter: {{
              or: [
                {{ fromId: {{ equalTo: "{address}" }} }}
                {{ toId: {{ equalTo: "{address}" }} }}
              ]
            }}
          ) {{
            totalCount
          }}
        }}
        """
        try:
            result = self.indexer.connection.client.execute(gql(query))
        except Exception as exception:
            raise IndexerTransfersException(exception)

        # {
        #     "data": {
        #         "transfers": {
        #             "totalCount": 916
        #         }
        #     }
        # }
        return result["transfers"]["totalCount"]

    def list_with_uds(
        self,
        address: str,
        page: TransfersPage,
        sort_column: str = IndexerTransfersInterface.COLUMN_TIMESTAMP,
        sort_order: str = IndexerTransfersInterface.SORT_ORDER_DESCENDING,
        from_datetime: Optional[datetime] = None,
        to_datetime: Optional[datetime] = None,
    ) -> TransfersResult:
        __doc__ = IndexerTransfersInterface.list_with_uds.__doc__

        if (
            not self.indexer.connection.is_connected()
            or self.indexer.connection.client is None
        ):
            raise IndexerTransfersException(NetworkConnectionError())

        if page.end_cursor is None:
            after_cursor_str = "null"
        else:
            after_cursor_str = f'"{page.end_cursor}"'

        date_filter = []
        if from_datetime:
            date_filter.append(
                f'{{ timestamp: {{ greaterThanOrEqualTo: "{from_datetime.isoformat()}" }} }}'
            )
        if to_datetime:
            date_filter.append(
                f'{{ timestamp: {{ lessThanOrEqualTo: "{to_datetime.isoformat()}" }} }}'
            )

        date_filter_str = "and: [" + ", ".join(date_filter) + "]" if date_filter else ""

        # query {
        #   accounts(
        #     first: 1
        #     # last: 1
        #     # offset: 1
        #     # before: "_____"
        #     # after: "_____"
        #     # orderBy: [PRIMARY_KEY_ASC]
        #     # condition: {}
        #     filter: {id:{equalTo: "g1LLsVzyfd2JpLaNb9fnPHsk2sVjQWCrcU2KQmV5d87VPxfbb"} }
        #   ) {
        #     nodes {
        #        transferWithUd(
        #         orderBy: TIMESTAMP_DESC
        #         first: 10
        #         # last: 1
        #         # offset: 1
        #         # before: "_____"
        #         after: null
        #         filter: {}
        #       ) {
        #          nodes{
        #             amount
        #             timestamp
        #             toId
        #             fromId
        #             udAmount
        #             isUd
        #          }
        #              pageInfo {
        #       hasNextPage
        #       hasPreviousPage
        #       startCursor
        #       endCursor
        #     }
        #     totalCount
        #       }
        #     }
        #
        #   }
        # }

        # GraphQL request
        query = f"""
            query {{
                accounts(
                    filter: {{
                        id:{{equalTo: "{address}"}}
                    }}
                ) {{
                    nodes {{
                        transferWithUd(
                            first: {page.size}
                            after: {after_cursor_str}
                            orderBy: {sort_column.upper()}_{sort_order.upper()}
                            filter: {{
                                {date_filter_str}
                            }}
                      ) {{
                        nodes {{
                            id
                            amount
                            timestamp
                            toId
                            toIdentityIndex
                            toIdentityName
                            toIdentityStatus
                            fromId
                            fromIdentityIndex
                            fromIdentityName
                            fromIdentityStatus
                            commentId
                            commentRemark
                            udIdentityId
                            udAmount
                            isUd
                        }}
                        pageInfo {{
                            hasNextPage
                            hasPreviousPage
                            startCursor
                            endCursor
                        }}
                        totalCount
                      }}
                  }}
              }}
            }}
        """
        # {
        #   "data": {
        #     "accounts": {
        #       "nodes": [
        #         {
        #           "transferWithUd": {
        #             "nodes": [
        #               {
        #                 "id": "ud-xxx-283265-0000283265-2bb1d-000000",
        #                 "amount": "1178",
        #                 "timestamp": "2026-03-27T11:00:00+00:00",
        #                 "toId": "yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy",
        #                 "toIdentityIndex": 69,
        #                 "toIdentityName": "xxxx",
        #                 "toIdentityStatus": "Member",
        #                 "fromId": null,
        #                 "fromIdentityIndex": null,
        #                 "fromIdentityName": null,
        #                 "fromIdentityStatus": null,
        #                 "commentId": null,
        #                 "commentRemark": null,
        #                 "udIdentityId": "genesis-identity_69",
        #                 "udAmount": "1178",
        #                 "isUd": true
        #               }],
        #             "pageInfo": {
        #                     "hasNextPage": false,
        #                     "hasPreviousPage": false,
        #                     "startCursor": "WyJuYXR1cmFsIiwxXQ==",
        #                     "endCursor": "WyJuYXR1cmFsIiwyMl0="
        #                 },
        #             "totalCount": 22
        #               }

        try:
            result = self.indexer.connection.client.execute(gql(query))
        except Exception as exception:
            raise IndexerTransfersException(exception)

        if len(result["accounts"]["nodes"]) == 0:
            return TransfersResult()

        transfers_with_uds = []
        transfer_to_comment_ids: Dict[str, str] = {}
        result_node = result["accounts"]["nodes"][0]
        for row in result_node["transferWithUd"]["nodes"]:
            if row["isUd"] is True:
                transfers_with_uds.append(
                    Transfer(
                        account_address=address,
                        id=row["id"],
                        issuer_address=row["toId"],
                        issuer_identity_index=row["toIdentityIndex"],
                        issuer_identity_name=row["toIdentityName"]
                        if row["toIdentityStatus"] != "Unconfirmed"
                        else None,
                        receiver_address=row["toId"],
                        receiver_identity_index=row["toIdentityIndex"],
                        receiver_identity_name=row["toIdentityName"]
                        if row["toIdentityStatus"] != "Unconfirmed"
                        else None,
                        amount=row["udAmount"],
                        timestamp=parser.parse(row["timestamp"]),
                        comment=row["commentRemark"],
                        comment_type=None,
                        is_ud=row["isUd"],
                    )
                )
            else:
                if row["commentRemark"] is not None:
                    transfer_to_comment_ids[row["id"]] = row["commentId"]
                transfers_with_uds.append(
                    Transfer(
                        account_address=address,
                        id=row["id"],
                        issuer_address=row["fromId"],
                        issuer_identity_index=row["fromIdentityIndex"],
                        issuer_identity_name=row["fromIdentityName"]
                        if row["fromIdentityStatus"] != "Unconfirmed"
                        else None,
                        receiver_address=row["toId"],
                        receiver_identity_index=row["toIdentityIndex"],
                        receiver_identity_name=row["toIdentityName"]
                        if row["toIdentityStatus"] != "Unconfirmed"
                        else None,
                        amount=row["amount"],
                        timestamp=parser.parse(row["timestamp"]),
                        comment=row["commentRemark"],
                        comment_type=None,
                        is_ud=row["isUd"],
                    )
                )
        total_count = result_node["transferWithUd"]["totalCount"]
        page = TransfersPage(
            size=page.size,
            has_next_page=result_node["transferWithUd"]["pageInfo"]["hasNextPage"],
            has_previous_page=result_node["transferWithUd"]["pageInfo"][
                "hasPreviousPage"
            ],
            start_cursor=result_node["transferWithUd"]["pageInfo"]["startCursor"],
            end_cursor=result_node["transferWithUd"]["pageInfo"]["endCursor"],
        )

        if len(transfer_to_comment_ids) > 0:
            query = """
                query GetComments($ids: [String!]!) {                
                    txComments(
                        filter: {
                            id: { in: $ids }
                        }
                      ) {
                        nodes {
                            id
                            type
                            remark
                            remarkBytes
                        }
                    }
                }
            """
            variables = {"ids": list(transfer_to_comment_ids.values())}
            try:
                result_comments = self.indexer.connection.client.execute(
                    gql(query), variables
                )
            except Exception as exception:
                raise IndexerTransfersException(exception)

            comment_dict = {
                row["id"]: row for row in result_comments["txComments"]["nodes"]
            }
            for transfer in transfers_with_uds:
                if isinstance(transfer, Transfer) and transfer.comment is not None:
                    comment_id = transfer_to_comment_ids[transfer.id]
                    transfer.comment_type = comment_dict[comment_id]["type"]
                    transfer.comment = (
                        comment_dict[comment_id]["remarkBytes"]
                        if transfer.comment_type == "RAW"
                        else comment_dict[comment_id]["remark"]
                    )

        return TransfersResult(
            transfers=transfers_with_uds, total_count=total_count, page=page
        )
