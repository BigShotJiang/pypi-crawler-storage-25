# Copyright 2021 Vincent Texier <vit@free.fr>
#
# This software is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
from datetime import datetime, timedelta
from typing import Dict, List

from dateutil import parser
from gql import gql

from tikka.domains.entities.identity import Certification, IdentityStatus
from tikka.interfaces.adapters.network.connection import NetworkConnectionError
from tikka.interfaces.adapters.network.indexer.certifications import (
    IndexerCertificationsException,
    IndexerCertificationsInterface,
)


class IndexerCertifications(IndexerCertificationsInterface):
    """
    IndexerCertifications class
    """

    identity_status_map = {
        "Unconfirmed": IdentityStatus.UNCONFIRMED,
        "Unvalidated": IdentityStatus.UNVALIDATED,
        "Validated": IdentityStatus.MEMBER,
        "Member": IdentityStatus.MEMBER,
        "NotMember": IdentityStatus.NOT_MEMBER,
        "Revoked": IdentityStatus.REVOKED,
        "Removed": IdentityStatus.REMOVED,
    }

    def get_by_index(
        self,
        identity_index: int,
        limit: int,
        offset: int = 0,
        sort_column: str = IndexerCertificationsInterface.COLUMN_EXPIRE_ON,
        sort_order: str = IndexerCertificationsInterface.SORT_ORDER_DESCENDING,
    ) -> List[Certification]:
        __doc__ = (  # pylint: disable=redefined-builtin, unused-variable
            IndexerCertificationsInterface.get_by_index.__doc__
        )

        if (
            not self.indexer.connection.is_connected()
            or self.indexer.connection.client is None
        ):
            raise IndexerCertificationsException(NetworkConnectionError())

        query = f"""
                query CertDetails {{
                blocks (
                    filter: {{ and: [
                                        {{ height: {{ greaterThanOrEqualTo: 0 }} }},
                                        {{ height: {{ lessThan: 2 }} }}
                                    ]
                            }}
                    orderBy: [HEIGHT_ASC], first: 2) {{
                    nodes {{
                      height
                      timestamp
                    }}
                  }}
                  certs(
                    first: {limit}
                    offset: {offset}
                    orderBy: {sort_column.upper()}_{sort_order.upper()}
                    filter: {{
                        or: [
                            {{ issuer: {{ index: {{ equalTo: {identity_index} }} }} }},
                            {{ receiver: {{ index: {{ equalTo: {identity_index} }} }} }}
                        ]
                    }}
                  ) {{
                    nodes {{
                          id
                          isActive
                          createdIn {{
                            block {{
                              timestamp
                            }}
                          }}
                          updatedIn {{
                            block {{
                              timestamp
                            }}
                          }}
                          expireOn
                          issuer {{
                            index
                            name
                            accountId
                            status
                          }}
                          receiver {{
                            index
                            name
                            accountId
                            status
                          }}
                    }}
                  }}
                }}
            """

        try:
            result = self.indexer.connection.client.execute(gql(query))
        except Exception as exception:
            raise IndexerCertificationsException(exception)

        # datetime are set in block since/before the block zero datetime of the blockchain
        first_two_blocks = result["blocks"]["nodes"]
        block_number_0 = first_two_blocks[0]["height"]
        assert block_number_0 == 0

        block_time_0 = parser.parse(first_two_blocks[0]["timestamp"])
        block_time_1 = parser.parse(first_two_blocks[1]["timestamp"])
        block_duration = block_time_1 - block_time_0
        avg_time_per_block = block_duration.total_seconds()

        certifications = []
        for certification in result["certs"]["nodes"]:

            expire_on_block = certification["expireOn"]

            if expire_on_block > 0:
                expire_on_time = block_time_0 + timedelta(
                    seconds=avg_time_per_block * abs(expire_on_block)
                )
            elif expire_on_block < 0:
                expire_on_time = block_time_0 - timedelta(
                    seconds=avg_time_per_block * abs(expire_on_block)
                )
            elif expire_on_block == 0:
                expire_on_time = block_time_0

            certifications.append(
                Certification(
                    id=certification["id"],
                    issuer_identity_index=certification["issuer"]["index"],
                    issuer_identity_name=certification["issuer"]["name"],
                    issuer_identity_status=self.identity_status_map[
                        certification["issuer"]["status"]
                    ],
                    issuer_address=certification["issuer"]["accountId"],
                    receiver_identity_index=certification["receiver"]["index"],
                    receiver_identity_name=certification["receiver"]["name"],
                    receiver_identity_status=self.identity_status_map[
                        certification["receiver"]["status"]
                    ],
                    receiver_address=certification["receiver"]["accountId"],
                    created_on=parser.parse(
                        certification["createdIn"]["block"]["timestamp"]
                    ),
                    updated_on=parser.parse(
                        certification["updatedIn"]["block"]["timestamp"]
                    ),
                    expire_on=expire_on_time,
                )
            )

        return certifications

    def get_by_indice(
        self,
        identity_indice: List[int],
        limit: int,
        offset: int = 0,
        sort_column: str = IndexerCertificationsInterface.COLUMN_EXPIRE_ON,
        sort_order: str = IndexerCertificationsInterface.SORT_ORDER_ASCENDING,
    ) -> Dict[int, List[Certification]]:
        __doc__ = (  # pylint: disable=redefined-builtin, unused-variable
            IndexerCertificationsInterface.get_by_indice.__doc__
        )

        if (
            not self.indexer.connection.is_connected()
            or self.indexer.connection.client is None
        ):
            raise IndexerCertificationsException(NetworkConnectionError())

        query = """
            query GetCertsByIndice($indice: [Int!]!, $offset: Int!, $limit: Int!) {
                  blocks (
                        filter: { and: [
                                            { height: { greaterThanOrEqualTo: 0 } },
                                            {height: { lessThan: 2 } }
                                        ]
                                }
                        orderBy: [HEIGHT_ASC], first: 2) {
                        nodes {
                          height
                          timestamp
                        }
                      }
                  identities(
                    filter: {
                            index: {in: $indice}
                        }
                  ) {
                    
                    nodes {
                      index
                      certIssued (first: $limit
                        offset: $offset
                        orderBy: EXPIRE_ON_ASC) {
                        nodes {
                          id
                              isActive
                              createdIn {
                                block {
                                  timestamp
                                }
                              }
                              updatedIn {
                                block {
                                  timestamp
                                }
                              }
                              expireOn
                              issuer {
                                index
                                name
                                accountId
                                status
                              }
                              receiver {
                                index
                                name
                                accountId
                                status
                              }
                        }
                  }
                  certReceived (
                        first: $limit
                        offset: $offset
                        orderBy: EXPIRE_ON_ASC) {
                        nodes {
                          id
                              isActive
                              createdIn {
                                block {
                                  timestamp
                                }
                              }
                              updatedIn {
                                block {
                                  timestamp
                                }
                              }
                              expireOn
                              issuer {
                                index
                                name
                                accountId
                                status
                              }
                              receiver {
                                index
                                name
                                accountId
                                status
                              }
                        }
                  }
            }
        }
    }
    """
        variables = {"indice": identity_indice, "offset": offset, "limit": limit}
        try:
            result = self.indexer.connection.client.execute(gql(query), variables)
        except Exception as exception:
            raise IndexerCertificationsException(exception)

        # {
        #   "data": {
        #     "blocks": {
        #       "nodes": [
        #         {
        #           "height": 0,
        #           "timestamp": "2026-03-07T17:36:18.006+00:00"
        #         },
        #         {
        #           "height": 1,
        #           "timestamp": "2026-03-07T17:36:24.006+00:00"
        #         }
        #       ]
        #     },
        #     "identities": {
        #       "nodes": [
        #         {
        #           "index": 58,
        #           "certIssued": {
        #             "nodes": [
        #               {
        #                 "id": "historic-cert_58-12",
        #                 "isActive": false,
        #                 "createdIn": {
        #                   "block": {
        #                     "timestamp": "2017-03-08T15:32:07+00:00"
        #                   }
        #                 },
        #                 "updatedIn": {
        #                   "block": {
        #                     "timestamp": "2017-03-08T15:32:07+00:00"
        #                   }
        #                 },
        #                 "expireOn": -711267,
        #                 "issuer": {
        #                   "index": 58,
        #                   "name": "vit",
        #                   "accountId": "g1LLsVzyfd2JpLaNb9fnPHsk2sVjQWCrcU2KQmV5d87VPxfbb",
        #                   "status": "Member"
        #                 },
        #                 "receiver": {
        #                   "index": 12,
        #                   "name": "EstienneDunord",
        #                   "accountId": "g1PWTYFcwL8qB4NJsq8qf7v2DwHx5hgtwoLYT4Lvd1WcXNNed",
        #                   "status": "Member"
        #                 }
        #               }
        #             ]
        #           },
        #           "certReceived": {
        #             "nodes": [
        #               {
        #                 "id": "historic-cert_12-58",
        #                 "isActive": false,
        #                 "createdIn": {
        #                   "block": {
        #                     "timestamp": "2017-03-08T15:32:07+00:00"
        #                   }
        #                 },
        #                 "updatedIn": {
        #                   "block": {
        #                     "timestamp": "2017-03-08T15:32:07+00:00"
        #                   }
        #                 },
        #                 "expireOn": -711267,
        #                 "issuer": {
        #                   "index": 12,
        #                   "name": "EstienneDunord",
        #                   "accountId": "g1PWTYFcwL8qB4NJsq8qf7v2DwHx5hgtwoLYT4Lvd1WcXNNed",
        #                   "status": "Member"
        #                 },
        #                 "receiver": {
        #                   "index": 58,
        #                   "name": "vit",
        #                   "accountId": "g1LLsVzyfd2JpLaNb9fnPHsk2sVjQWCrcU2KQmV5d87VPxfbb",
        #                   "status": "Member"
        #                 }
        #               }
        #             ]
        #           }
        #         },
        #         {
        #           "index": 61,
        #           "certIssued": {
        #             "nodes": [
        #               {
        #                 "id": "historic-cert_61-66",
        #                 "isActive": false,
        #                 "createdIn": {
        #                   "block": {
        #                     "timestamp": "2017-03-23T16:02:22+00:00"
        #                   }
        #                 },
        #                 "updatedIn": {
        #                   "block": {
        #                     "timestamp": "2017-03-23T16:02:22+00:00"
        #                   }
        #                 },
        #                 "expireOn": -707526,
        #                 "issuer": {
        #                   "index": 61,
        #                   "name": "poka",
        #                   "accountId": "g1MJuWgKQWbocGeHUKzMk1C49V6vwKR8quwEePRoYZBL5poka",
        #                   "status": "Member"
        #                 },
        #                 "receiver": {
        #                   "index": 66,
        #                   "name": "mrousseaux",
        #                   "accountId": "g1NRQ9aDFgAPZ6aA1TezLWsrhAaqbC6oPWzf4YYgb3LXeJrSS",
        #                   "status": "Revoked"
        #                 }
        #               }
        #             ]
        #           },
        #           "certReceived": {
        #             "nodes": [
        #               {
        #                 "id": "historic-cert_38-61",
        #                 "isActive": false,
        #                 "createdIn": {
        #                   "block": {
        #                     "timestamp": "2017-03-13T15:58:28+00:00"
        #                   }
        #                 },
        #                 "updatedIn": {
        #                   "block": {
        #                     "timestamp": "2017-03-13T15:58:28+00:00"
        #                   }
        #                 },
        #                 "expireOn": -709900,
        #                 "issuer": {
        #                   "index": 38,
        #                   "name": "fluidlog",
        #                   "accountId": "g1KeJwRLamPaU46P4Qq8ccSy1UpVMMxesGNk91fd8jNj1XBvU",
        #                   "status": "Member"
        #                 },
        #                 "receiver": {
        #                   "index": 61,
        #                   "name": "poka",
        #                   "accountId": "g1MJuWgKQWbocGeHUKzMk1C49V6vwKR8quwEePRoYZBL5poka",
        #                   "status": "Member"
        #                 }
        #               }
        #             ]
        #           }
        #         }
        #       ]
        #     }
        #   }
        # }

        # datetime are set in block since/before the block zero datetime of the blockchain
        first_two_blocks = result["blocks"]["nodes"]
        block_number_0 = first_two_blocks[0]["height"]
        assert block_number_0 == 0

        block_time_0: datetime = parser.parse(first_two_blocks[0]["timestamp"])
        block_time_1: datetime = parser.parse(first_two_blocks[1]["timestamp"])
        block_duration = block_time_1 - block_time_0
        avg_time_per_block: float = block_duration.total_seconds()

        certifications: Dict[int, List[Certification]] = {}
        for identity_node in result["identities"]["nodes"]:
            index = identity_node["index"]
            certifications[index] = []
            for certification_row in identity_node["certIssued"]["nodes"]:
                certifications[index].append(
                    self._get_certification_from_row(
                        block_time_0, avg_time_per_block, certification_row
                    )
                )
            for certification_row in identity_node["certReceived"]["nodes"]:
                certifications[index].append(
                    self._get_certification_from_row(
                        block_time_0, avg_time_per_block, certification_row
                    )
                )
        return certifications

    def _get_certification_from_row(
        self, block_time_0: datetime, avg_time_per_block: float, certification_row: dict
    ) -> Certification:
        """
        Convert row to Certification instance

        :param block_time_0: Genesis block datetime
        :param avg_time_per_block: Average time per block in seconds
        :param certification_row: Certification row data
        :return:
        """
        expire_on_block = certification_row["expireOn"]

        if expire_on_block > 0:
            expire_on_time = block_time_0 + timedelta(
                seconds=avg_time_per_block * abs(expire_on_block)
            )
        elif expire_on_block < 0:
            expire_on_time = block_time_0 - timedelta(
                seconds=avg_time_per_block * abs(expire_on_block)
            )
        elif expire_on_block == 0:
            expire_on_time = block_time_0

        return Certification(
            id=certification_row["id"],
            issuer_identity_index=certification_row["issuer"]["index"],
            issuer_identity_name=certification_row["issuer"]["name"],
            issuer_identity_status=self.identity_status_map[
                certification_row["issuer"]["status"]
            ],
            issuer_address=certification_row["issuer"]["accountId"],
            receiver_identity_index=certification_row["receiver"]["index"],
            receiver_identity_name=certification_row["receiver"]["name"],
            receiver_identity_status=self.identity_status_map[
                certification_row["receiver"]["status"]
            ],
            receiver_address=certification_row["receiver"]["accountId"],
            created_on=parser.parse(
                certification_row["createdIn"]["block"]["timestamp"]
            ),
            updated_on=parser.parse(
                certification_row["updatedIn"]["block"]["timestamp"]
            ),
            expire_on=expire_on_time,
        )
