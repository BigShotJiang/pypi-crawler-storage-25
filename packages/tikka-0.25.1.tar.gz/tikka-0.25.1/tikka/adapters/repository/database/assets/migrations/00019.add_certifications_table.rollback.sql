drop table if exists certifications;
