-- Step 1: Create the new table with ON DELETE CASCADE
create table if not exists `transfers_new` (
    account_address varchar(255),
    id varchar(255) not null,
    issuer_address varchar(255),
    issuer_identity_index integer,
    issuer_identity_name varchar(255),
    receiver_address varchar(255),
    receiver_identity_index varchar(255),
    receiver_identity_name varchar(255),
    amount TEXT,
    timestamp timestamp,
    comment varchar(65535) default null,
    comment_type varchar(255) default null,
    is_ud integer default 0,
    PRIMARY KEY(`account_address`, `id`)
);

-- Step 1.5: Delete duplicates from transfers table before migration
DELETE FROM transfers
WHERE rowid NOT IN (
    SELECT MIN(rowid)
    FROM transfers
    GROUP BY id, issuer_address, receiver_address, timestamp
);

-- Step 2: Copy data from the old table
INSERT INTO transfers_new (
    account_address, id, issuer_address, issuer_identity_index, issuer_identity_name, receiver_address, receiver_identity_index, receiver_identity_name,
    amount, timestamp, comment, comment_type
)
SELECT
    issuer_address, id, issuer_address, issuer_identity_index, issuer_identity_name, receiver_address, receiver_identity_index, receiver_identity_name,
    amount, timestamp, comment, comment_type
FROM transfers;

INSERT INTO transfers_new (
    account_address, id, issuer_address, issuer_identity_index, issuer_identity_name, receiver_address, receiver_identity_index, receiver_identity_name,
    amount, timestamp, comment, comment_type
)
SELECT
    receiver_address, id, issuer_address, issuer_identity_index, issuer_identity_name, receiver_address, receiver_identity_index, receiver_identity_name,
    amount, timestamp, comment, comment_type
FROM transfers;

-- Step 3: Drop the old table
DROP TABLE transfers;

-- Step 4: Rename the new table
ALTER TABLE transfers_new RENAME TO transfers;

-------------------------------------------------------
