create table if not exists universal_dividends(
    id varchar(255) unique primary key not null,
    address varchar(255),
    identity_index integer,
    identity_name varchar(255),
    amount integer,
    timestamp timestamp
);

