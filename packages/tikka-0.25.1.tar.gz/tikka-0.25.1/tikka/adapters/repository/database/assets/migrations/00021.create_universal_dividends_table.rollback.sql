drop table if exists universal_dividends;
