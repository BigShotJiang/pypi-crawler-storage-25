-- Step 1: Create the new table with ON DELETE CASCADE
create table if not exists `transfers_new` (
    id varchar(255) unique primary key not null,
    issuer_address varchar(255),
    issuer_identity_index integer,
    issuer_identity_name varchar(255),
    receiver_address varchar(255),
    receiver_identity_index varchar(255),
    receiver_identity_name varchar(255),
    amount TEXT,
    timestamp timestamp,
    comment varchar(65535) default null,
    comment_type varchar(255) default null
);

-- Step 1.5: Delete duplicates from transfers table before migration
DELETE FROM transfers WHERE is_ud == 1;

-- Step 2: Copy data from the old table
INSERT INTO transfers_new (
    id, issuer_address, issuer_identity_index, issuer_identity_name, receiver_address, receiver_identity_index, receiver_identity_name,
    amount, timestamp, comment, comment_type
)
SELECT
    id, issuer_address, issuer_identity_index, issuer_identity_name, receiver_address, receiver_identity_index, receiver_identity_name,
    amount, timestamp, comment, comment_type
FROM transfers;

-- Step 3: Drop the old table
DROP TABLE transfers;

-- Step 4: Rename the new table
ALTER TABLE transfers_new RENAME TO transfers;

-------------------------------------------------------
