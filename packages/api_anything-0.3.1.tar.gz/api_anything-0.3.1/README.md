# API-Anything

**Auto-generate Python APIs from any software. Beyond CLI.**

CLI-Anything generates CLIs. We generate Python APIs -- typed, tested, deterministic.

![Tests](https://img.shields.io/badge/tests-689%20passed-brightgreen)
![Python](https://img.shields.io/badge/python-3.10%2B-blue)
![License](https://img.shields.io/badge/license-Apache%202.0-blue)
![Tier System](https://img.shields.io/badge/tier%20system-7%20levels-purple)
![Built-in APIs](https://img.shields.io/badge/built--in%20APIs-27-orange)
![Methods](https://img.shields.io/badge/methods-295-blueviolet)
![Claude Code](https://img.shields.io/badge/Claude%20Code-plugin-black)
![MCP](https://img.shields.io/badge/MCP-server-ff69b4)

---

## What's New in 0.3.0

- **Vision generator** (`VisionGenerator` + `vlm_backends/`) — Set-of-Marks prompting over Claude Computer Use / Qwen2.5-VL / OS-Atlas. Generated methods bake the bbox in at generation time so runtime calls never hit an LLM.
- **Record & Replay** (`Recorder` + `Replayer`) — scoped to a target window handle, UIA `AutomationEventHandler` primary, mss screenshot secondary, pynput raw hook tertiary. Zero-LLM replay. `cli record <app>` + `generate --from-trace`.
- **Pattern-aware UIA dispatch** — 22 UIA patterns (Invoke/Value/Toggle/Scroll/…) with priority tie-breaking; previous releases emitted `NotImplementedError` stubs for UIA bodies.
- **Windows-first**. Mac/Linux deferred to v0.4+.
- **205 new tests** (484 → 689 passed + 2 skipped), multi-round red team audited.

Known limitation: Recorder's real-desktop UIA event subscription is wired but no-ops on the current `uiautomation==2.0.29` binding. v0.3.1 adds a `comtypes`-direct path to fix this — feature branch already merged-ready.

---

## Why API-Anything?

- **For AI agents**: A Python API call costs ~50 tokens. A CLI invocation costs ~200. Type hints eliminate hallucinated flags.
- **For developers**: `import ffmpeg_api` with autocomplete beats memorizing CLI flags and parsing stderr.
- **For unreachable software**: UIA mode controls software with NO source code and NO CLI. CLI-Anything cannot do this.

---

## CLI-Anything vs API-Anything

| Feature | CLI-Anything | API-Anything |
|---------|-------------|--------------|
| Output format | CLI commands | **Python API classes** |
| Token cost per call | ~200 tokens | **~50 tokens** |
| Type safety | None | **Full type hints + Pydantic** |
| IDE autocomplete | No | **Yes** |
| State management | Stateless (new process each call) | **Stateful (class instance)** |
| Error handling | Exit codes + stderr text | **Python exceptions with context** |
| Information sources | Source code only | **Source code + UIA + screenshots** |
| No-source-code software | Limited | **Full UIA support (Tier 3)** |
| Tier detection | No | **7-level system saves tokens** |
| Runtime AI needed | No | **No (deterministic generated code)** |

Both tools solve the same problem from different angles. CLI-Anything (31k stars) wraps software as CLI commands. API-Anything wraps software as importable Python modules. They are complementary -- CLI-Anything covers breadth, API-Anything covers depth and type safety.

---

## Tier Detection System

API-Anything classifies any software into 7 tiers before generating code, so it picks the right strategy and estimates cost upfront.

| Tier | Rating | Strategy | Confidence |
|------|--------|----------|------------|
| 1 | Stars: 5/5 | Python binding exists on PyPI -- wrap directly | 98% |
| 2A | Stars: 4/5 | Source code + CLI available -- subprocess mode | 90% |
| 2B | Stars: 3/5 | Source code available, no CLI | 75% |
| 3A | Stars: 3/5 | No source, UIA >=70% named controls | 70% |
| 3B | Stars: 2/5 | No source, UIA 30-70% named controls | 50% |
| 3C | Stars: 1/5 | No source, UIA <30% named controls | 30% |
| 4 | Stars: 1/5 | Canvas/game/custom-rendered -- vision required | 15% |

```
$ api-anything detect notepad

+------------------------------ api-anything ------------------------------+
|                                                                          |
|  [*] API-Anything Tier Detection                                         |
|     Software: notepad                                                    |
|     Tier: 1 *****                                                        |
|     Confidence: 98%                                                      |
|     Verdict: Direct binding -- wrap and ship!                            |
|                                                                          |
+--------------------------------------------------------------------------+
+----------------------------- Detection Checks ----------------------------+
|  [+] PyPI binding     python-notepad v0.1.2                              |
|  [--] Source code      no source path or URL provided                    |
|  [+] CLI binary       C:\Windows\System32\notepad.exe                    |
|  [--] UIA tree         uiautomation not installed -- skipped             |
+--------------------------------------------------------------------------+
```

---

## Quick Start

```bash
pip install api-anything            # core
pip install "api-anything[all]"     # + web + mcp + test + repl

# First-run interactive wizard (recommended)
api-anything init

# List 27 built-in APIs (FFmpeg, Blender, Ollama, Docker, Git, SQLite, ...)
api-anything list --detail

# Detect tier for any software
api-anything detect notepad
api-anything detect gimp --github https://github.com/GIMP/gimp

# Branded stateful REPL (banner + state prompt + accent color per API)
api-anything repl examples/ffmpeg_api.py
# ffmpeg[input.mp4]> trim(0.0, 10.0)

# One-shot execution (piping friendly)
api-anything run SQLite get_tables
echo '{"x": 42}' | api-anything run jq query ".x"

# MCP server -- expose all 27 APIs to any MCP client (Claude Desktop, etc.)
api-anything mcp-serve --transport stdio

# Shell completion (bash/zsh/fish)
eval "$(api-anything completions bash)"

# Iteratively expand, test, validate a generated API
api-anything refine path/to/api.py --max-iter 3
api-anything test path/to/api.py
api-anything validate path/to/api.py

# Gradio demo web UI (onboarding / sales pitch)
api-anything web --port 7860

# Direct Python import
python -c "from api_anything.apis import SQLite; print(SQLite(':memory:').get_tables())"
```

### Claude Code plugin

```
/plugin install api-anything
```

Provides `/api-anything:detect`, `/api-anything:skill`, `/api-anything:refine`, `/api-anything:test`, `/api-anything:validate`, `/api-anything:list`, `/api-anything:repl`, `/api-anything:generate` slash commands out of the box.

---

## POC Showcase

### LibreOffice Writer (Tier 2A -- subprocess mode)

```python
from examples.libreoffice_writer import LibreOfficeWriter

writer = LibreOfficeWriter()
writer.create_document("report.odt")
writer.add_heading("Q1 Report", level=1)
writer.add_paragraph("Revenue grew 15% year-over-year.")
writer.add_table(
    headers=["Month", "Revenue"],
    rows=[["Jan", "$1M"], ["Feb", "$1.2M"]],
)
writer.save()
writer.export_pdf("report.pdf")
```

### FFmpeg (Tier 2A -- subprocess mode)

FFmpeg has no Python binding on PyPI that wraps the full CLI. API-Anything generates one.

```python
from examples.ffmpeg_api import FFmpeg

ff = FFmpeg()
ff.convert("input.mp4", "output.webm")
ff.extract_audio("video.mp4", "audio.mp3")
ff.trim("input.mp4", "clip.mp4", start="00:01:00", duration="00:00:30")

info = ff.probe("input.mp4")
print(f"Duration: {info['duration']}s, Resolution: {info['width']}x{info['height']}")
```

### Windows Notepad (Tier 3A -- UIA mode)

This is what CLI-Anything cannot do. No source code, no CLI flags -- pure UI Automation.

```python
from examples.notepad_uia_api import NotepadAPI

notepad = NotepadAPI()
notepad.launch()
notepad.set_text("Hello from API-Anything!")
notepad.save_as("hello.txt")
text = notepad.get_text()
notepad.close()
```

---

## How It Works

API-Anything runs an 8-phase pipeline to turn any software into a Python package:

```
Phase 0: Tier Detection
   |  Classify software into 7 tiers (PyPI / source / UIA / vision)
   v
Phase 1: Three-Source Analysis
   |  Extract info from source code + UIA tree + screenshots
   v
Phase 2: API Surface Design
   |  LLM designs class/method structure with Instructor + Pydantic
   v
Phase 3: Code Generation
   |  Generate typed Python module with docstrings
   v
Phase 4: Validation
   |  Type-check + lint + smoke test generated code
   v
Phase 5: Test Generation
   |  Generate pytest suite for the API
   v
Phase 6: Packaging
   |  Create installable pip package
   v
Phase 7: Documentation
      Generate usage examples and API reference
```

Phases 0-1 are implemented. Phases 2-3 have core infrastructure (generator engine + Instructor integration). Phases 4-7 are on the roadmap.

---

## Three-Source Analysis

API-Anything gathers information from three independent sources to maximize coverage:

1. **Source code** -- Parse repos or local code for function signatures, docstrings, and architecture. Works for open-source software (Tier 2A/2B).

2. **UIA (UI Automation)** -- Walk the Windows accessibility tree to discover controls, their types, names, and automation IDs. Works for closed-source GUI software (Tier 3A/3B/3C).

3. **Screenshots** -- Capture the UI for vision-model analysis when UIA coverage is low. Fallback for Tier 3C and Tier 4.

Each source fills gaps the others miss. Source code gives intent; UIA gives structure; screenshots give layout.

---

## Architecture

```
API-Anything (open source, Apache-2.0)
  |
  +-- Tier Detector       classify software feasibility
  +-- Three-Source Analyzer   UIA + source + screenshots
  +-- Generator Engine     Instructor + Pydantic structured output
  +-- Generated Package    pure Python, no AI at runtime
       |
       +-- Typed API class    autocomplete + type hints
       +-- Python exceptions  not exit codes
       +-- pytest suite       generated tests
       +-- pip installable    any agent can import
```

The generated code is deterministic. No LLM runs at call time -- AI is used only during generation.

---

## Roadmap

- [x] Phase 0 -- Tier Detection (7-level system)
- [x] Core generator engine (Instructor + Pydantic)
- [x] POC: LibreOffice Writer (Tier 2A, subprocess)
- [x] POC: FFmpeg (Tier 2A, subprocess)
- [x] POC: Windows Notepad (Tier 3A, UIA)
- [x] Three-source analyzer (UIA + source + screenshots)
- [x] Gradio web demo (4 tabs: Dashboard / Tier / Explorer / Generate)
- [x] SKILL.md generator (`api-anything skill <module>`)
- [x] 27 built-in APIs (295 methods) -- FFmpeg, Blender, GIMP, Ollama, etc.
- [x] Branded stateful REPL (banner + state prompt + accent color + 50-level undo/redo)
- [x] Claude Code plugin (`/plugin install api-anything`)
- [x] MCP server (`api-anything mcp-serve`)
- [x] Shell completion generator (bash/zsh/fish)
- [x] Interactive setup wizard (`api-anything init`)
- [x] Refine / test / validate iterative pipeline
- [x] stdin/stdout pipe support
- [ ] tool_use schema output (for any LLM agent)
- [ ] PyPI package publish (awaiting release cut)
- [ ] AT-SPI (Linux) and AXUIElement (macOS) UIA backends

---

## Contributing

Contributions are welcome. The project is in alpha (v0.3.0).

```bash
git clone https://github.com/aiking931931/api-anything.git
cd api-anything
pip install -e ".[dev]"
pytest
```

Areas where help is needed:
- New POCs for popular software (Blender, Photoshop, Excel)
- UIA coverage improvements on Linux (AT-SPI) and macOS (AXUIElement)
- Phase 4-7 pipeline implementation

---

## License

Apache-2.0. See [LICENSE](LICENSE) for details.

---

## Credits

[CLI-Anything](https://github.com/HKUDS/CLI-Anything) (HKUDS, 31k stars) pioneered the idea of auto-generating agent-native interfaces for arbitrary software. API-Anything takes a complementary approach: generating importable, typed Python APIs instead of Click CLIs, with three-source analysis (UIA + screenshot + source code) so we reach the Tier 3 closed-source GUI software CLI-Anything cannot.

---

Generated with API-Anything v0.3.0
