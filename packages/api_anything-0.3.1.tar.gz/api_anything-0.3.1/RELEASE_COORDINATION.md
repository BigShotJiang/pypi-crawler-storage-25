# api-anything RELEASE_COORDINATION

> 所有升級此專案的 session/agent 先讀此文件。遵循 `~/.claude/rules/L1/release_coord.md`。

## 現況 snapshot（2026-04-17）

| 欄位 | 值 |
|---|---|
| Registry latest（PyPI） | 尚未 publish（v0.1.0 曾計劃公開，目前 repo private，PyPI 無 record） |
| Local version（pyproject.toml） | `0.3.0`（housekeeping 完成；ready-to-publish，未 publish） |
| CHANGELOG 最新 | `[Unreleased]`（空）+ `[0.3.0] - 2026-04-17` + `[0.2.1] - 2026-04-17` |
| main HEAD | `0d74510` `v0.3 post-merge fixes: FATAL+HIGH findings`（紅隊審後硬化，housekeeping commit 隨後） |
| 下一 publish 目標 | v0.3.0（**Pending Publish Queue 已排入**，等 user_authorization + M3 blocker 解除可選擇性 ship） |
| Repo 可見性 | **private**（`aiking931931/api-anything`）— README badge 先不改 |

## WIP 變更清單

- v0.2.1 三項已 land：cli_fallback schemas (audacity/kdenlive/krita) + repl DisplayRouter migration + UIA pattern dispatch (M0)。
- **v0.3 M1 Vision 已合併**：`vlm_backends/` (claude_cu/qwen25_vl/os_atlas) + `vision_generator.py` + `_append_vision_body` + `APIMethod.last_verified_at`。Claude CU 實測待用戶授權（MEMORY #50）、本地 VLM 待 GPU。
- **v0.3 M2 Record-Replay 已合併**：`recorder.py` (UIA event + mss + pynput) + `replay.py` (zero-LLM) + `cli record` + `--from-trace`。
- **紅隊硬化 (0d74510)**：FATAL privacy scope 修（window-handle scope UIA/mss/raw-hook）+ Value/Selection subscribe + posix trace path + last_verified_at 接線 + internal_mode 5-way + bbox validator + exec smoke。
- **M3 blocker：UIA binding**：`uiautomation` 2.0.29 (yinkaisheng) 不 expose `AddAutomationEventHandler` / `EventId` / `TreeScope` top-level。recorder 用 `getattr` fallback pattern，subscription code 寫對但 binding 上 no-op。**M3 前必須**：換 binding 或改 comtypes-direct。
- 待 **v0.3 M3**：百度網盤 Tier 4 testbed（需用戶在旁登入，且 UIA binding 先解鎖）。
- 待 **v0.3 M4**：version bump 0.2.1 → 0.3.0 + CHANGELOG 移 Unreleased → [0.3.0]。
- 全測試狀態：**689 passed + 2 skipped**（紅隊前 654，硬化後 +35）。

## ⛔ 鐵律（api-anything 專屬）

1. **Repo private 期間禁動 README badge URL** — shields.io 對 private repo 會回 404，動了等於故意壞 demo
2. **不改 dependencies 在 minor bump 內** — 0.1.x → 0.2.0 是 feature release，deps 維持與 0.1.0 相同
3. **v0.2 新模組（display_router / cli_fallback / llm_generator）視為公開 API** — 下次改 signature 必須 deprecate → 0.3 才能刪除
4. **Tier detection enrichment fields 一旦加入 `TierResult` 就不可移除** — consumer 可能已 assert 這些欄位存在
5. **hero GIF 路徑在 README hardcode** — 替換時同步更新 `README.md` + `assets/` 指針，不留 broken link
6. **發布 PyPI 前必須先把 repo 轉 public** — 否則 Homepage/Repository URL 在 PyPI 頁面會死連結
7. **本地 lint + test 全綠才能進 release checklist** — 未跑 = 未驗

## 升級前 checklist

- [ ] `pytest tests/` 全綠
- [ ] `ruff check src/ tests/` 零 warning
- [ ] CHANGELOG 目標版本 entry 存在且內容完整
- [ ] `pyproject.toml` version 對齊 CHANGELOG
- [ ] PyPI 該版號未被佔用（`pip index versions api-anything` 確認）
- [ ] Repo 已從 private 轉 public（如要 publish）
- [ ] Lock 已取（填 Session Registry / Active）
- [ ] `python -m build` 本地 build 成功
- [ ] `twine check dist/*` 全綠
- [ ] README badge URL 對得到公開 repo

## 升級步驟

1. 決定目標版本（semver）— minor=feature / patch=fix / major=break
2. 更新 `pyproject.toml` version + `CHANGELOG.md` 新 entry
3. `python -m build` 產生 sdist + wheel
4. `twine check dist/*`
5. Tag：`git tag -a vX.Y.Z -m "..."` + `git push --tags`（⛔ 不可逆點）
6. `twine upload dist/*`（⛔ 不可逆點）
7. `pip install api-anything==X.Y.Z` 在乾淨 venv 驗證
8. 更新 Session Registry / History

## Pending Publish Queue

```yaml
- version: "0.3.0"
  state: ready-to-publish
  queued_by:
    session: cc_2ded_2049
    host: AI-KING-DESKTOP
    queued_at: 2026-04-17T00:00:00+08:00
  artifacts:
    wheel: dist/api_anything-0.3.0-py3-none-any.whl
    sdist: dist/api_anything-0.3.0.tar.gz
    twine_check: PASSED
    built_from: <HEAD at housekeeping commit>
  verification:
    tests_full: "689 passed, 2 skipped"
    ruff: clean
    triple_source_aligned: true   # pyproject 0.3.0 / __version__ 0.3.0 / CHANGELOG [0.3.0]
    redteam_review: "Opus red team on M1+M2 merge → 2 FATAL + 4 HIGH + 3 MEDIUM + 1 LOW all fixed in 0d74510"
  blocking_on:
    - user_authorization
    - repo_visibility_private_to_public   # PyPI 頁面 Homepage/Repository URL 現在指向 private repo
  # uia_binding_upgrade removed 2026-04-17 — resolved on feature/uia-binding-comtypes-spike
  # via comtypes-direct access (_uia_events.py). Merge to main after 0.3.0 ships for 0.3.1.
  suggested_command: |
    # DO NOT auto-run. Next session with user authorization should:
    # 1. Confirm repo visibility policy
    # 2. git tag -a v0.3.0 -m "v0.3.0: vision + record-replay"
    # 3. git push origin v0.3.0
    # 4. twine upload dist/api_anything-0.3.0*
  expires_at: 2026-04-24T00:00:00+08:00
  notes: |
    v0.3.0 brings vision + record-replay ammo. M3 BaiduNetdisk testbed
    deferred to v0.3.1 (needs user-present login + UIA binding upgrade).
    Claude CU live smoke test also deferred (paid API, MEMORY #50).
```

## v0.3.1 merge-ready note

`feature/uia-binding-comtypes-spike` (HEAD `8d4a25b`, 2 commits ahead of
main) 已完成一輪完整紅藍隊 cycle：

- commit `364ff61`: real UIA event subscription via comtypes-direct
  (`_uia_events.py` 469 LOC + recorder rewrite + 38 tests)
- Red team Opus audit (COM threading / GC / VARIANT / non-Windows /
  CHANGELOG truth) → 1 FATAL + 2 HIGH + 2 MEDIUM + 1 LOW
- commit `8d4a25b`: fix FATAL (`_ensure_com_initialized` per-thread),
  HIGH (unsubscribe Remove-before-pop order), HIGH (`is_password_element`
  flip to fail-safe-toward-redaction), MEDIUM (CHANGELOG strike-through),
  plus 11 new tests

Tests: 691 → **740 passed + 3 skipped**. Ruff clean. Main thread import
sanity OK (`_ensure_com_initialized()` idempotent).

**Merge gate** (等 v0.3.0 ship 後做):

1. `git checkout main`
2. `git merge --no-ff feature/uia-binding-comtypes-spike -m "v0.3.1: UIA binding comtypes-direct"`
3. bump `pyproject.toml` + `__init__.py` 0.3.0 → 0.3.1
4. CHANGELOG `[Unreleased]` → `[0.3.1] - YYYY-MM-DD`
5. 重新 `python -m build` + `twine check --strict`
6. 進入 v0.3.1 Pending Publish Queue

## Session Registry

### Active
無

### History
- 2026-04-17 / housekeeping session / target `0.2.0` / **housekeeping only**（bump + CHANGELOG + 本文件）/ 未 tag / 未 push / 未 publish
- 2026-04-17 / session `cc_2ded_2049` / target `0.3.0` / **housekeeping only**（bump 0.2.1→0.3.0 + `__init__` re-exports + CHANGELOG [0.3.0] + 本文件 Pending Queue）/ 未 tag / 未 push / 未 publish
- 2026-04-17 / session `cc_02d4_2130` / target `0.3.1` (merge-ready on feature branch) / **UIA binding comtypes-direct + 紅藍隊 cycle**（POC + spike 364ff61 + red-team audit + fixes 8d4a25b）/ feature branch 未 merge main / 未 bump / 未 tag / 未 push / 未 publish

## 不可逆點

| 操作 | 為何不可逆 |
|---|---|
| `twine upload dist/*`（PyPI） | 撤不回。只能 yank，yank 後仍可 `pip install api-anything==版本` 裝到。版號被佔永遠 |
| `git push origin vX.Y.Z` tag | 本地可刪，但 clone 過的人保有。GitHub release 頁面留 trace |
| Repo 從 private 轉 public | 歷史 commit 全部公開。任何 private 時期殘留的 secret / 未發表 idea 一併曝光 |
| `gh release create` | 下載計數、討論串留 trace；刪 release 會留空紀錄 |
| README badge 改 public shields URL 後再把 repo 轉回 private | badge 404 公開可見，等於 NAK 給觀眾看 |

**Full 模式不豁免** 上述不可逆點 — 執行前必須 AskUser 確認。
