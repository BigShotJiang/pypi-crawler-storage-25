"""API-Anything: Auto-generate Python APIs from any software."""

from .recorder import Recorder, RecordEvent, RecordTrace, load_trace
from .replay import Replayer
from .vision_generator import VisionGenerator, VisionIntrospectionReport
from .vlm_backends import (
    ClaudeCUBackend,
    OSAtlasBackend,
    Qwen25VLBackend,
    VLMBackend,
)

__version__ = "0.3.1"

__all__ = [
    "ClaudeCUBackend",
    "OSAtlasBackend",
    "Qwen25VLBackend",
    "RecordEvent",
    "RecordTrace",
    "Recorder",
    "Replayer",
    "VLMBackend",
    "VisionGenerator",
    "VisionIntrospectionReport",
    "__version__",
    "load_trace",
]
