# ruff: noqa: RUF002, RUF003
"""Vision runtime helpers — execution-time support for vision-generated APIs.

RFC v0.3 §D.4 要求「生成期 vs 執行期分離」。本 module 是**執行期**面向：
生成的 API class 在 method body 裡會 `self._locate_control(...)` /
`self._click_at(x,y)` / `self._type_at(x,y,text)`，這些 helper 的實作由
`generator.py` 的 pattern renderer 在 class body 內注入**字串樣板**，最終
會直接呼叫本 module 提供的下列函式。

本 module 不打 LLM API（執行期純 replay）。VLM 只出現在 `_locate_control`
的 **vlm_client is not None** 路徑（RFC §D.5 retry：bbox 漂移時用 VLM 重校）。

功能：
    - `_locate_control(control_spec, *, screenshot_fn, vlm_client)`：
        - control_spec = dict(name=..., bbox=(x1,y1,x2,y2) | None, fallback_selector=...)
        - bbox 在 → 直接幾何中心 click；bbox 不在且給 vlm_client → SoM overlay → VLM 校。
    - `_click_at(x, y)`：用 pywinauto / ctypes fallback。
    - `_type_at(x, y, text)`：click 後 type。
    - SoM overlay 工具：`render_som_overlay(image_bytes, elements)` — 畫紅框+編號。

鐵律：
    - tests 全 mock（禁實際截圖 / 禁打 VLM / 禁真動滑鼠）
    - 任何 import 失敗降級為 NotImplementedError / RuntimeError，不 raise 到無關層
"""

from __future__ import annotations

import io
import logging
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, Protocol

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Types & dataclasses
# ---------------------------------------------------------------------------


@dataclass
class VisionElement:
    """單一 VLM 辨識出的 UI element（生成期產出，序列化到 method body 內）。"""

    label: str
    bbox: tuple[int, int, int, int]  # (x1, y1, x2, y2) 相對視窗座標
    element_id: int = 0
    confidence: float = 0.0
    notes: str = ""

    def __post_init__(self) -> None:
        """FIX 7: enforce bbox shape at construction.

        Dataclass ``bbox: tuple[int,int,int,int]`` is a type **hint** not a
        runtime check — silent corruption was possible when callers passed
        3-tuples or strings. This fail-fast check prevents downstream
        ``_bbox_center`` unpack errors and makes the contract explicit.
        """
        try:
            coords = tuple(int(x) for x in self.bbox)
        except (TypeError, ValueError) as exc:
            raise ValueError(
                f"VisionElement.bbox must be 4 ints, got {self.bbox!r}"
            ) from exc
        if len(coords) != 4:
            raise ValueError(
                f"VisionElement.bbox must have 4 elements, got {len(coords)}"
            )
        # Preserve tuple typing after coercion — callers may have passed a list.
        self.bbox = coords  # type: ignore[assignment]


@dataclass
class ControlSpec:
    """生成期嵌入 method body 的 control 定位描述子。

    執行期 `_locate_control` 會優先用 bbox 直接算 click point；
    bbox 為 None 才走 VLM re-grounding（若有 vlm_client）。
    """

    name: str
    bbox: tuple[int, int, int, int] | None = None
    fallback_selector: str = ""
    element_id: int = 0
    confidence: float = 0.0
    extra: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> ControlSpec:
        """容錯建構：從 LLM/generator 產出的 dict 轉回 dataclass.

        FIX 7: bbox shape is validated here. Anything not coercible to a
        4-tuple of ints (e.g. ``"1,2,3,4"``, ``[1,2,3]``, 3-tuple) becomes
        ``None`` so the caller falls through to the VLM re-grounding path
        (RFC §D.5) instead of silently mis-clicking via corrupted geometry.
        """
        bbox_raw = raw.get("bbox")
        bbox: tuple[int, int, int, int] | None = None
        if bbox_raw is not None:
            try:
                coords = tuple(int(x) for x in bbox_raw)
            except (TypeError, ValueError):
                coords = ()
            if len(coords) == 4:
                bbox = coords  # type: ignore[assignment]
        return cls(
            name=str(raw.get("name", "")),
            bbox=bbox,
            fallback_selector=str(raw.get("fallback_selector", "")),
            element_id=int(raw.get("element_id", 0)),
            confidence=float(raw.get("confidence", 0.0)),
            extra={k: v for k, v in raw.items()
                   if k not in {"name", "bbox", "fallback_selector", "element_id", "confidence"}},
        )


class _VLMClientProto(Protocol):
    """duck-typed VLM client interface — generator 生出的 API class 會接收此物件。"""

    def locate(self, screenshot: bytes, query: str) -> VisionElement | None: ...


# ---------------------------------------------------------------------------
# SoM overlay（Set-of-Marks prompting helper）
# ---------------------------------------------------------------------------


def _bbox_center(bbox: tuple[int, int, int, int]) -> tuple[int, int]:
    """bbox → 幾何中心 (cx, cy)。"""
    x1, y1, x2, y2 = bbox
    return ((x1 + x2) // 2, (y1 + y2) // 2)


def render_som_overlay(
    image_bytes: bytes,
    elements: list[VisionElement],
    *,
    box_color: tuple[int, int, int] = (255, 0, 0),
    label_color: tuple[int, int, int] = (255, 255, 255),
) -> bytes:
    """把 elements 以紅框 + 白字編號疊在 screenshot 上，回傳新的 PNG bytes。

    RFC §D.3 Set-of-Marks prompting：VLM 辨識編號比辨識座標準 4-8 個點。

    Args:
        image_bytes: 原截圖 PNG bytes。
        elements: 要標記的 element list。
        box_color: 外框顏色，預設紅 (255,0,0)。
        label_color: 編號文字顏色，預設白 (255,255,255)。

    Returns:
        新 PNG bytes（overlayed）。PIL 缺失 → 原樣返回 image_bytes。
    """
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError:  # pragma: no cover - runtime guard
        logger.warning("Pillow missing, SoM overlay skipped")
        return image_bytes

    try:
        img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
    except Exception as exc:
        logger.warning("render_som_overlay: image open failed %s", exc)
        return image_bytes

    draw = ImageDraw.Draw(img)
    # 嘗試用預設字體，失敗就 ImageFont default（小字但可讀）
    try:
        font = ImageFont.load_default()
    except Exception:
        font = None  # type: ignore[assignment]

    for idx, elem in enumerate(elements, start=1):
        x1, y1, x2, y2 = elem.bbox
        draw.rectangle([(x1, y1), (x2, y2)], outline=box_color, width=2)
        # 編號背景小框（避免字被底圖吃掉）
        label = str(idx)
        # 粗估文字寬（PIL 9+）
        try:
            tw, th = draw.textsize(label, font=font) if font else (10, 12)
        except AttributeError:
            # PIL 10+ textsize 改 textbbox
            try:
                if font is not None:
                    left, top, right, bottom = draw.textbbox(
                        (0, 0), label, font=font
                    )
                    tw, th = right - left, bottom - top
                else:
                    tw, th = 10, 12
            except Exception:
                tw, th = 10, 12
        draw.rectangle(
            [(x1, y1), (x1 + tw + 4, y1 + th + 2)],
            fill=box_color,
        )
        if font is not None:
            draw.text((x1 + 2, y1), label, fill=label_color, font=font)
        else:
            draw.text((x1 + 2, y1), label, fill=label_color)

    out = io.BytesIO()
    img.save(out, format="PNG")
    return out.getvalue()


# ---------------------------------------------------------------------------
# Click / type primitives（降級鏈）
# ---------------------------------------------------------------------------


def _click_at(x: int, y: int) -> None:
    """在視窗座標 (x, y) 點擊一次。

    優先 pywinauto.mouse.click（穩，有 hover+延遲處理）；缺則 ctypes.mouse_event。
    兩者皆缺 → RuntimeError（tests 必 mock 這函式，不會觸發）。
    """
    try:
        from pywinauto import mouse  # type: ignore[import-untyped]

        mouse.click(coords=(int(x), int(y)))
        return
    except ImportError:
        pass
    except Exception as exc:
        logger.warning("_click_at pywinauto failed: %s", exc)

    try:
        import ctypes

        # SendInput 會更穩，但保持簡單用 mouse_event
        user32 = ctypes.windll.user32  # type: ignore[attr-defined]
        user32.SetCursorPos(int(x), int(y))
        # MOUSEEVENTF_LEFTDOWN = 0x0002, LEFTUP = 0x0004
        user32.mouse_event(0x0002, 0, 0, 0, 0)
        user32.mouse_event(0x0004, 0, 0, 0, 0)
    except Exception as exc:  # pragma: no cover - runtime guard
        raise RuntimeError(
            f"_click_at requires pywinauto or Windows user32; got: {exc}"
        ) from exc


def _type_at(x: int, y: int, text: str) -> None:
    """點擊 (x, y) 後鍵入 text。"""
    _click_at(x, y)
    try:
        from pywinauto.keyboard import send_keys  # type: ignore[import-untyped]

        send_keys(str(text), with_spaces=True)
        return
    except ImportError:
        pass
    except Exception as exc:
        logger.warning("_type_at pywinauto failed: %s", exc)

    # ctypes fallback：單 char VK send（僅 ASCII，非 ASCII 走 pywinauto）
    try:
        import ctypes

        user32 = ctypes.windll.user32  # type: ignore[attr-defined]
        for ch in str(text):
            vk = user32.VkKeyScanW(ord(ch)) & 0xFF
            user32.keybd_event(vk, 0, 0, 0)
            user32.keybd_event(vk, 0, 2, 0)
    except Exception as exc:  # pragma: no cover - runtime guard
        raise RuntimeError(f"_type_at fallback failed: {exc}") from exc


# ---------------------------------------------------------------------------
# _locate_control — M0 留的 hook，M1 實作
# ---------------------------------------------------------------------------


def _locate_control(
    control_spec: dict[str, Any] | ControlSpec | str,
    *,
    screenshot_fn: Callable[[], bytes] | None = None,
    vlm_client: _VLMClientProto | Any | None = None,
) -> tuple[int, int]:
    """定位 UI 控制項並回傳 click point (x, y)。

    **優先序（RFC §D.5）**：
        1. control_spec 有 bbox → 直接算中心（執行期零 LLM call，RFC §D.2 承諾）
        2. bbox 缺 + vlm_client 存在 → 截圖 → SoM overlay → VLM 重校 → 回中心
        3. 其餘 → NotImplementedError（caller 應走 record-replay 或重 generate）

    Args:
        control_spec: dict 或 ControlSpec 或單純 name string（legacy 相容）。
            - dict 模式：至少含 `name`，可選 `bbox`/`fallback_selector`/`element_id`。
            - str 模式：只有 name → 必走 VLM 路（需 vlm_client）。
        screenshot_fn: 無參數 callable，回傳當前視窗 PNG bytes；None 時 bbox
            必須已在 spec 內。
        vlm_client: duck-typed，具 `.locate(screenshot_bytes, query) -> VisionElement|None`。

    Returns:
        tuple[int, int] — 視窗座標 click point。

    Raises:
        NotImplementedError: 無 bbox 且無 vlm_client，無法定位。
        LookupError: VLM 回 None（找不到 element）。
    """
    # 正規化成 ControlSpec
    if isinstance(control_spec, str):
        spec = ControlSpec(name=control_spec)
    elif isinstance(control_spec, dict):
        spec = ControlSpec.from_dict(control_spec)
    elif isinstance(control_spec, ControlSpec):
        spec = control_spec
    else:
        raise TypeError(
            f"control_spec must be str | dict | ControlSpec, got {type(control_spec).__name__}"
        )

    # Path 1：bbox 已在 → 直接算中心
    if spec.bbox is not None:
        return _bbox_center(spec.bbox)

    # Path 2：bbox 缺 → VLM re-grounding
    if vlm_client is None or screenshot_fn is None:
        raise NotImplementedError(
            f"_locate_control({spec.name!r}): no bbox in spec and no VLM client "
            "supplied; re-run api-anything regenerate or provide vlm_client."
        )

    try:
        screenshot = screenshot_fn()
    except Exception as exc:
        raise RuntimeError(f"_locate_control screenshot_fn failed: {exc}") from exc

    query = spec.fallback_selector or spec.name
    elem = vlm_client.locate(screenshot, query)
    if elem is None:
        raise LookupError(
            f"_locate_control({spec.name!r}): VLM returned no match for query {query!r}"
        )
    return _bbox_center(elem.bbox)


# ---------------------------------------------------------------------------
# Verify helpers（RFC §D.5 drift detection）
# ---------------------------------------------------------------------------


def verify_state_change(
    before_hash: str,
    screenshot_fn: Callable[[], bytes],
) -> bool:
    """方法尾端呼叫：比對 hash 是否變（變 = method 有作用）。

    用於偵測 bbox 過期：若點了 bbox 但畫面沒變，推測 bbox 已漂移。
    不打 LLM，純 hash compare。
    """
    import hashlib

    try:
        current = screenshot_fn()
    except Exception:
        return False
    current_hash = hashlib.sha256(current).hexdigest()
    return current_hash != before_hash


__all__ = [
    "ControlSpec",
    "VisionElement",
    "_bbox_center",
    "_click_at",
    "_locate_control",
    "_type_at",
    "render_som_overlay",
    "verify_state_change",
]
