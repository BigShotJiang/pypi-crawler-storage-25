"""Thin `comtypes` wrapper for Windows UIA event subscription (v0.3.1).

Background
----------
`uiautomation==2.0.29` (yinkaisheng) — the only maintained pure-Python UIA
binding on PyPI — does **not** expose an event API at all. No
``AddAutomationEventHandler``, no ``AddPropertyChangedEventHandler``, no
``EventId`` / ``PropertyId`` / ``TreeScope`` namespaces. The v0.3.0 recorder
wrote defensive ``getattr(uia, ..., None)`` calls so it shipped clean, but
at runtime the subscription silently no-ops.

This module bypasses the missing binding by loading ``UIAutomationCore.dll``
typelib via ``comtypes`` and talking directly to ``IUIAutomation``. Proven
in a main-agent POC: ``CUIAutomation`` CoClass instantiable, Invoke / Value /
SelectionItem event IDs resolve, ``COMObject`` subclasses implementing
``IUIAutomationEventHandler`` and ``IUIAutomationPropertyChangedEventHandler``
subscribe + clean up without errors.

Non-Windows behaviour
---------------------
Tests must import this module on Linux/macOS CI. ``comtypes`` itself can be
pip-installed on non-Windows but ``GetModule("UIAutomationCore.dll")`` will
fail. We catch import-time failure, stash ``_UIA = None``, and every public
function raises ``RuntimeError`` on use — never at import. Callers (the
recorder) keep their existing "graceful on non-Windows" path.

Threading
---------
COM event handlers are invoked on an RPC worker thread, not the thread that
called ``AddAutomationEventHandler``. User callbacks are wrapped in
``try/except`` so one bad callback does not crash the RPC thread; the
handler always returns ``S_OK`` (0).

Reference counting
------------------
We keep a hard Python reference to every handler in ``_tokens`` so
``comtypes`` doesn't GC the ``COMObject`` before COM does. ``unsubscribe``
calls the matching ``Remove*EventHandler`` BEFORE dropping the Python
reference — the pop runs in a ``finally`` block so a Remove* exception
still evicts the stale entry (no double-pop, no leak).

COM initialisation
------------------
COM requires every thread that calls a COM interface to first call
``CoInitializeEx`` (or its STA-only sibling ``CoInitialize``). Worker
threads spawned by the Recorder (``pynput``, ``mss``) or by the host
application (``asyncio.to_thread``, Celery worker, uvicorn worker) do
**not** inherit the import-time initialisation done by ``comtypes`` on
the main thread; their first UIA call raises
``OSError [WinError -2147221008] CoInitialize has not been called``
(``CO_E_NOTINITIALIZED``). Every public entry in this module therefore
calls :func:`_ensure_com_initialized` first — it is idempotent per
thread and a no-op on non-Windows.
"""

from __future__ import annotations

import itertools
import logging
import threading
from collections.abc import Callable
from typing import Any, ClassVar, Literal

logger = logging.getLogger(__name__)

UIAEventType = Literal["uia.Invoke", "uia.Value", "uia.Selection"]


# ---------------------------------------------------------------------------
# Lazy Windows-only import
# ---------------------------------------------------------------------------

_UIA: Any = None  # comtypes.gen.UIAutomationClient module (or None on non-win)
_COMTYPES: Any = None  # comtypes package (or None on non-win)
_IMPORT_ERROR: str | None = None  # cached human-readable import failure reason

try:
    import comtypes as _comtypes  # type: ignore[import-not-found]
    import comtypes.client as _comtypes_client  # type: ignore[import-not-found]

    _comtypes_client.GetModule("UIAutomationCore.dll")
    from comtypes.gen import (
        UIAutomationClient as _UIAutomationClient,  # type: ignore[import-not-found]
    )

    _COMTYPES = _comtypes
    _UIA = _UIAutomationClient
except (ImportError, OSError, AttributeError) as _exc:  # pragma: no cover - platform dep
    _IMPORT_ERROR = f"{type(_exc).__name__}: {_exc}"
    logger.debug("UIA events module load failed: %s", _IMPORT_ERROR)


def _require_uia() -> Any:
    """Return the loaded ``UIAutomationClient`` module or raise a helpful error."""
    if _UIA is None:
        raise RuntimeError(
            "UIA events require Windows + comtypes with UIAutomationCore.dll "
            "present. Install with `api-anything[windows]` on Windows, or skip "
            f"this code path on other platforms. Underlying error: {_IMPORT_ERROR}"
        )
    return _UIA


# ---------------------------------------------------------------------------
# Per-thread COM initialisation
# ---------------------------------------------------------------------------

_com_inited_threads: set[int] = set()
_com_inited_lock = threading.Lock()


def _ensure_com_initialized() -> None:
    """Idempotent per-thread ``CoInitialize`` call.

    COM requires each thread that uses COM interfaces to call
    ``CoInitializeEx`` before its first COM call and ``CoUninitialize``
    before exit. Worker threads spawned by Recorder / pynput / mss /
    user-code (``asyncio.to_thread``, celery, uvicorn) do NOT inherit
    the import-time initialisation done on the main thread, so UIA calls
    from them raise ``CO_E_NOTINITIALIZED``
    (``0x800401F0`` / ``WinError -2147221008``).

    We track initialised thread IDs in a set; ``comtypes.CoInitialize()``
    is documented idempotent (returns ``S_FALSE`` on second call) but
    tracking lets us pair each success with ``CoUninitialize`` on
    :func:`_teardown_com_for_testing`.

    On non-Windows (``_UIA is None``) this is a no-op; the public API
    will raise ``RuntimeError`` via :func:`_require_uia` before it ever
    needs COM anyway.
    """
    if _UIA is None:  # non-Windows path — public API raises later
        return
    tid = threading.get_ident()
    with _com_inited_lock:
        if tid in _com_inited_threads:
            return
        assert _COMTYPES is not None  # guarded by _UIA check above
        try:
            _COMTYPES.CoInitialize()
            _com_inited_threads.add(tid)
        except OSError as exc:
            # COM may already be initialised at a different apartment
            # (S_FALSE / RPC_E_CHANGED_MODE) — both survivable. comtypes
            # raises OSError(WinError) on CoInitialize failures; log and
            # treat as initialised so we do not retry every call.
            logger.debug("CoInitialize on tid=%s returned %s", tid, exc)
            _com_inited_threads.add(tid)


def _teardown_com_for_testing() -> None:
    """Best-effort ``CoUninitialize`` for every tracked thread. Test-only.

    Calls ``CoUninitialize`` once per thread id we remember initialising.
    Note that ``CoUninitialize`` is documented to run on the *same*
    thread that called ``CoInitialize``; calling it from the main
    thread is technically a no-op for the others, but ``comtypes``
    swallows the mismatch. On non-Windows this simply clears the set.
    """
    with _com_inited_lock:
        tids = list(_com_inited_threads)
        _com_inited_threads.clear()
    if _UIA is None or _COMTYPES is None:
        return
    for tid in tids:
        try:
            _COMTYPES.CoUninitialize()
        except Exception as exc:  # pragma: no cover - test-only helper
            logger.debug("CoUninitialize for tid=%s failed: %s", tid, exc)


# ---------------------------------------------------------------------------
# Singleton IUIAutomation
# ---------------------------------------------------------------------------

_uia_singleton: Any = None
_singleton_lock = threading.Lock()


def get_uia() -> Any:
    """Lazy-create and cache the process-wide ``IUIAutomation`` pointer.

    Returns the same COM pointer on every call. Raises ``RuntimeError`` on
    non-Windows or when the typelib failed to load.
    """
    global _uia_singleton
    mod = _require_uia()
    _ensure_com_initialized()
    with _singleton_lock:
        if _uia_singleton is None:
            assert _COMTYPES is not None  # guarded by _require_uia
            _uia_singleton = _COMTYPES.client.CreateObject(
                mod.CUIAutomation, interface=mod.IUIAutomation
            )
        return _uia_singleton


def control_from_handle(hwnd: int) -> Any:
    """Resolve an ``IUIAutomationElement`` from a Win32 HWND.

    Returns the element or raises ``RuntimeError`` on non-Windows. If the
    HWND is invalid, the underlying COM call may return a null pointer —
    callers should treat a falsy return value as "not found".
    """
    if not hwnd:
        raise ValueError("hwnd must be a non-zero Win32 window handle")
    _ensure_com_initialized()
    uia = get_uia()
    return uia.ElementFromHandle(int(hwnd))


# ---------------------------------------------------------------------------
# Token registry
# ---------------------------------------------------------------------------


class UIAEventToken:
    """Sentinel handle returned by ``subscribe_*``. Pass to ``unsubscribe``.

    Wraps an integer ID allocated by ``_alloc_token``. The constructor is
    technically callable from outside — Python enforces no privacy — but
    forged tokens are harmless: ``unsubscribe`` looks up ``_tokens`` and
    is a no-op for unknown IDs. Treat this as a sentinel, not an opaque
    capability.
    """

    __slots__ = ("_id",)

    def __init__(self, token_id: int) -> None:
        self._id = token_id

    def __repr__(self) -> str:  # pragma: no cover - debug aid
        return f"<UIAEventToken id={self._id}>"


class _TokenEntry:
    """Internal record of one live subscription."""

    __slots__ = ("element", "event_or_prop_id", "handler", "kind")

    def __init__(
        self,
        *,
        kind: str,
        element: Any,
        event_or_prop_id: Any,
        handler: Any,
    ) -> None:
        self.kind = kind  # "automation" | "property"
        self.element = element
        self.event_or_prop_id = event_or_prop_id
        self.handler = handler  # hold strong reference so COM keeps the object


_tokens: dict[int, _TokenEntry] = {}
_tokens_lock = threading.Lock()
_token_counter = itertools.count(1)


def _alloc_token(entry: _TokenEntry) -> UIAEventToken:
    with _tokens_lock:
        tid = next(_token_counter)
        _tokens[tid] = entry
    return UIAEventToken(tid)


def _pop_token(token: UIAEventToken) -> _TokenEntry | None:
    with _tokens_lock:
        return _tokens.pop(token._id, None)


# ---------------------------------------------------------------------------
# COM handler proxies
# ---------------------------------------------------------------------------


def _make_automation_handler(
    callback: Callable[[str, int], None],
    kind_label: str,
) -> Any:
    """Build a ``COMObject`` implementing ``IUIAutomationEventHandler``."""
    mod = _require_uia()
    assert _COMTYPES is not None

    class _AutomationHandler(_COMTYPES.COMObject):  # type: ignore[misc, name-defined]
        # comtypes reads this at class-creation to register the vtable;
        # it is never mutated at runtime, but ruff flags it as a mutable
        # default. Pin as ClassVar so the intent is explicit.
        _com_interfaces_: ClassVar[list[Any]] = [mod.IUIAutomationEventHandler]

        # Signature per UIAutomationClient IDL:
        #   HRESULT HandleAutomationEvent(IUIAutomationElement *sender, EVENTID eventId)
        # Method + param names MUST match the IDL verbatim — ``comtypes``
        # looks them up by name to wire the vtable slot, so ``lower_case``
        # breaks the COM binding. N802/N803 suppressed on these two.
        def IUIAutomationEventHandler_HandleAutomationEvent(  # noqa: N802
            self, sender: Any, eventId: int  # noqa: N803
        ) -> int:
            try:
                control_path = _safe_control_path(sender)
                callback(control_path, int(eventId))
            except Exception as exc:  # swallow on COM thread
                logger.warning(
                    "UIA %s callback raised: %s", kind_label, exc, exc_info=True
                )
            return 0  # S_OK

    return _AutomationHandler()


def _make_property_handler(
    callback: Callable[[str, str], None],
) -> Any:
    """Build a ``COMObject`` implementing ``IUIAutomationPropertyChangedEventHandler``."""
    mod = _require_uia()
    assert _COMTYPES is not None

    class _PropertyHandler(_COMTYPES.COMObject):  # type: ignore[misc, name-defined]
        _com_interfaces_: ClassVar[list[Any]] = [
            mod.IUIAutomationPropertyChangedEventHandler
        ]

        # Signature per UIAutomationClient IDL:
        #   HRESULT HandlePropertyChangedEvent(
        #       IUIAutomationElement *sender, PROPERTYID propertyId, VARIANT newValue)
        # IDL method/param names required for comtypes vtable match.
        def IUIAutomationPropertyChangedEventHandler_HandlePropertyChangedEvent(  # noqa: N802
            self, sender: Any, propertyId: int, newValue: Any  # noqa: N803
        ) -> int:
            try:
                control_path = _safe_control_path(sender)
                # newValue is a VARIANT wrapper; str() falls back to repr which
                # is usually the value directly for BSTR payloads.
                value_str = _variant_to_str(newValue)
                callback(control_path, value_str)
            except Exception as exc:  # swallow on COM thread
                logger.warning(
                    "UIA property callback raised: %s", exc, exc_info=True
                )
            return 0  # S_OK

    return _PropertyHandler()


def _safe_control_path(element: Any) -> str:
    """Best-effort build ``Window[Name] > Pane > ...`` string from a UIA element.

    Fail-safe: any COM error → return a placeholder rather than raising on the
    RPC thread.
    """
    if element is None:
        return "<null>"
    try:
        # Walk Current* property getters. comtypes IDL-generated element has
        # CurrentControlType (int) + CurrentName (str). We coerce via
        # UIAutomationCore's ControlTypeId lookup is avoided — the int is
        # fine for debugging and the caller's callback can enrich via a
        # proper control walk.
        name = getattr(element, "CurrentName", "") or ""
        ctype = getattr(element, "CurrentLocalizedControlType", "") or "Control"
        return f"{ctype}[{name}]" if name else str(ctype)
    except Exception as exc:
        logger.debug("_safe_control_path failed: %s", exc)
        return "<unknown>"


def _variant_to_str(variant: Any) -> str:
    """Normalise a UIA VARIANT payload to a Python ``str``.

    comtypes usually returns the unwrapped Python value (str / int / float).
    If a raw VARIANT object shows up we try ``.value`` then ``str()``.
    """
    if variant is None:
        return ""
    if isinstance(variant, (str, int, float, bool)):
        return str(variant)
    try:
        unwrapped = getattr(variant, "value", variant)
        return str(unwrapped) if unwrapped is not None else ""
    except Exception:
        return ""


# ---------------------------------------------------------------------------
# Public subscribe / unsubscribe API
# ---------------------------------------------------------------------------


def subscribe_invoke(
    element: Any,
    callback: Callable[[str, int], None],
    *,
    tree_scope: int | None = None,
) -> UIAEventToken:
    """Subscribe to ``UIA_Invoke_InvokedEventId`` on ``element``.

    ``callback(control_path, event_id)`` fires on a COM RPC thread whenever
    an Invokable control is clicked. Scope defaults to
    ``TreeScope_Subtree`` (descendants included).
    """
    mod = _require_uia()
    _ensure_com_initialized()
    uia = get_uia()
    event_id = mod.UIA_Invoke_InvokedEventId
    scope = tree_scope if tree_scope is not None else mod.TreeScope_Subtree
    handler = _make_automation_handler(callback, "Invoke")
    uia.AddAutomationEventHandler(event_id, element, scope, None, handler)
    return _alloc_token(
        _TokenEntry(
            kind="automation",
            element=element,
            event_or_prop_id=event_id,
            handler=handler,
        )
    )


def subscribe_value_changed(
    element: Any,
    callback: Callable[[str, str], None],
    *,
    tree_scope: int | None = None,
) -> UIAEventToken:
    """Subscribe to ``UIA_ValueValuePropertyId`` property-changed events.

    ``callback(control_path, new_value_str)`` fires whenever a Value-pattern
    control updates. Scope defaults to ``TreeScope_Subtree``.
    """
    mod = _require_uia()
    _ensure_com_initialized()
    uia = get_uia()
    prop_id = mod.UIA_ValueValuePropertyId
    scope = tree_scope if tree_scope is not None else mod.TreeScope_Subtree
    handler = _make_property_handler(callback)
    uia.AddPropertyChangedEventHandler(element, scope, None, handler, [prop_id])
    return _alloc_token(
        _TokenEntry(
            kind="property",
            element=element,
            event_or_prop_id=[prop_id],
            handler=handler,
        )
    )


def subscribe_selection(
    element: Any,
    callback: Callable[[str, int], None],
    *,
    tree_scope: int | None = None,
) -> UIAEventToken:
    """Subscribe to ``UIA_SelectionItem_ElementSelectedEventId`` events.

    ``callback(control_path, event_id)`` fires whenever a selection item is
    picked. Scope defaults to ``TreeScope_Subtree``.
    """
    mod = _require_uia()
    _ensure_com_initialized()
    uia = get_uia()
    event_id = mod.UIA_SelectionItem_ElementSelectedEventId
    scope = tree_scope if tree_scope is not None else mod.TreeScope_Subtree
    handler = _make_automation_handler(callback, "Selection")
    uia.AddAutomationEventHandler(event_id, element, scope, None, handler)
    return _alloc_token(
        _TokenEntry(
            kind="automation",
            element=element,
            event_or_prop_id=event_id,
            handler=handler,
        )
    )


def unsubscribe(token: UIAEventToken) -> None:
    """Remove the subscription matching ``token``. Idempotent.

    Per the module docstring invariant: ``Remove*EventHandler`` runs
    BEFORE the token is popped from ``_tokens`` so the handler
    ``COMObject`` retains its strong Python reference for the full RPC
    roundtrip (COM still holds its own refcount, but a race with GC
    elsewhere would be observable as ``E_UNEXPECTED``). The pop runs in
    a ``finally`` clause so a Remove* exception still evicts the stale
    entry — no leak, no double-pop.

    Unknown or already-removed tokens are no-ops. COM removal errors are
    logged and swallowed; the caller is cleaning up.
    """
    _ensure_com_initialized()
    # Peek the entry WITHOUT popping — the docstring invariant says
    # Remove* runs while the strong ref is still in _tokens.
    with _tokens_lock:
        entry = _tokens.get(token._id)
    if entry is None:
        return
    try:
        uia = get_uia()
        if entry.kind == "automation":
            uia.RemoveAutomationEventHandler(
                entry.event_or_prop_id, entry.element, entry.handler
            )
        elif entry.kind == "property":
            uia.RemovePropertyChangedEventHandler(entry.element, entry.handler)
    except Exception as exc:
        logger.debug("unsubscribe(kind=%s) non-fatal: %s", entry.kind, exc)
    finally:
        # Pop AFTER Remove* — whether it raised or succeeded, the entry
        # is consumed. Use .pop(..., None) so a concurrent
        # unsubscribe_all() that already cleared the dict is a no-op.
        with _tokens_lock:
            _tokens.pop(token._id, None)


def unsubscribe_all() -> None:
    """Bulk cleanup. Calls ``IUIAutomation.RemoveAllEventHandlers`` and clears
    the internal token dict. Safe on non-Windows: no-op that logs a warning.
    """
    if _UIA is None:
        logger.debug("unsubscribe_all: UIA not loaded, nothing to do")
        return
    _ensure_com_initialized()
    try:
        uia = get_uia()
        uia.RemoveAllEventHandlers()
    except Exception as exc:
        logger.debug("RemoveAllEventHandlers non-fatal: %s", exc)
    finally:
        with _tokens_lock:
            _tokens.clear()


# ---------------------------------------------------------------------------
# Helpers exposed to the recorder
# ---------------------------------------------------------------------------


def is_password_element(element: Any) -> bool:
    """Return ``True`` iff the element reports ``IsPassword == True``.

    Fail-safe-toward-redaction: any comtypes / attribute error returns
    ``True`` — i.e. when we cannot determine whether a field is a
    password input, the caller treats it as one and redacts. The one
    documented exception is ``element is None``: a missing element is
    not a password field, so the recorder's "no element available"
    path does not end up stamping every unparsed event as redacted.

    The recorder already masks on the server-emit path; this is a helper
    for places that want the decision early (e.g. the property-changed
    callback that doesn't get ``is_password`` for free).
    """
    if element is None:
        return False
    _ensure_com_initialized()
    # Prefer the IDL-generated ``CurrentIsPassword`` scalar. Fall back to
    # GetCurrentPropertyValue(UIA_IsPasswordPropertyId) if the pointer type
    # exposes only the generic COM path.
    try:
        val = getattr(element, "CurrentIsPassword", None)
        if val is not None:
            return bool(val)
    except Exception as exc:
        logger.debug("is_password_element CurrentIsPassword: %s", exc)

    try:
        mod = _require_uia()
        prop_id = mod.UIA_IsPasswordPropertyId
        val = element.GetCurrentPropertyValue(prop_id)
        return bool(val)
    except Exception as exc:
        logger.debug(
            "is_password_element GetCurrentPropertyValue failed, "
            "assuming password (fail-safe): %s",
            exc,
        )
        return True


__all__ = [
    "UIAEventToken",
    "UIAEventType",
    "control_from_handle",
    "get_uia",
    "is_password_element",
    "subscribe_invoke",
    "subscribe_selection",
    "subscribe_value_changed",
    "unsubscribe",
    "unsubscribe_all",
]
