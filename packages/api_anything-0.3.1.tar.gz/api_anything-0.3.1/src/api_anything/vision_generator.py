"""Vision-driven API generator (RFC v0.3 §D.4, generation-time only).

Pipeline (run **once** per target software):

    screenshots ──► backend.introspect_window ──► VisionElement[]
                                                    │
            ──► render_som_overlay ──► VLM Q&A ──► verified element
                                                    │
                                                    ▼
                                            APIMethod[] (operation_mode="vision",
                                                         bbox baked into body)

At runtime the generated method body calls
``vision_runtime._locate_control(spec, ...)`` — and because the ``bbox``
was baked in at generation time, **no VLM call happens at runtime** (RFC
§D.2 zero-LLM guarantee). The VLM only re-activates if the bbox is
``None`` (drift recovery).

This module is a **generation-time** tool. ``generator.generate_api``
dispatches to :func:`_generate_with_vision_methods` when the caller
passes ``vision_candidates=[...]``.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .models import APIMethod, UIControl
from .vision_runtime import VisionElement, render_som_overlay

logger = logging.getLogger(__name__)


@dataclass
class VisionIntrospectionReport:
    """Structured output of :meth:`VisionGenerator.introspect`.

    Tests use this to assert the pipeline's phase counts without poking
    logging.
    """

    elements: list[VisionElement]
    screenshots_used: int
    som_overlays_rendered: int

    def __len__(self) -> int:  # pragma: no cover - trivial
        return len(self.elements)


class VisionGenerator:
    """Generation-time wrapper around a :class:`VLMBackend`.

    Args:
        backend: any :class:`api_anything.vlm_backends.base.VLMBackend`.
            Tests inject a fake backend that returns fixed elements.
        software_name: used purely for logging observability.

    Example::

        from api_anything.vlm_backends import ClaudeCUBackend
        from api_anything.vision_generator import VisionGenerator

        gen = VisionGenerator(ClaudeCUBackend())
        elements = gen.introspect(screenshot_paths=[Path("vscode.png")])
        methods = gen.generate_methods(elements, software_name="VSCode")
    """

    def __init__(self, backend: Any, *, software_name: str = "") -> None:
        self._backend = backend
        self._software_name = software_name

    # ---- introspection --------------------------------------------------

    def introspect(
        self,
        window_handle: int | None = None,
        *,
        screenshot_paths: list[Path] | None = None,
        screenshots_to_capture: int = 5,
    ) -> list[VisionElement]:
        """Run the VLM across ``screenshot_paths`` (or captured shots).

        Args:
            window_handle: optional Win32 HWND; if ``screenshot_paths`` is
                None and the env supports live capture, caller may grab
                frames here (M1 ships without live capture — paths path
                only). Passed to the logger for traceability.
            screenshot_paths: list of PNG paths to introspect. When None
                and no live capture, returns an empty list.
            screenshots_to_capture: upper bound for live-capture mode
                (reserved for a future live-capture helper; M1 treats it
                only as a logging hint).

        Returns:
            Deduplicated list of :class:`VisionElement`.
        """
        logger.info(
            "VisionGenerator.introspect phase=start "
            "software=%r window=%s paths=%d cap=%d",
            self._software_name,
            window_handle,
            len(screenshot_paths or []),
            screenshots_to_capture,
        )
        collected: list[VisionElement] = []
        screenshots_used = 0
        overlays_rendered = 0
        paths = list(screenshot_paths or [])
        for path in paths:
            if not path.exists():
                logger.warning(
                    "VisionGenerator.introspect: screenshot missing %s", path
                )
                continue
            shot = path.read_bytes()
            screenshots_used += 1
            try:
                elements = self._backend.introspect_window(shot)
            except ImportError:
                raise
            except Exception as exc:
                logger.warning(
                    "VisionGenerator: backend introspect failed on %s: %s",
                    path,
                    exc,
                )
                continue
            if elements:
                # Render SoM overlay for traceability even when caller does
                # not consume it — cost is a single PIL draw per screenshot.
                _ = render_som_overlay(shot, elements)
                overlays_rendered += 1
            collected.extend(elements)
        merged = _dedupe_elements(collected)
        logger.info(
            "VisionGenerator.introspect phase=end elements=%d screenshots=%d",
            len(merged),
            screenshots_used,
        )
        self._last_report = VisionIntrospectionReport(
            elements=merged,
            screenshots_used=screenshots_used,
            som_overlays_rendered=overlays_rendered,
        )
        return merged

    @property
    def last_report(self) -> VisionIntrospectionReport | None:
        """Return the last introspection report (None before first run)."""
        return getattr(self, "_last_report", None)

    def verify_element(
        self, elem: VisionElement, screenshot: bytes
    ) -> bool:
        """Ask the backend to confirm ``elem`` still matches ``screenshot``.

        Used by the generator's "verify" phase: after SoM overlay selection
        the generator calls :meth:`verify_element` once more to catch the
        case where the VLM picked a misaligned mark. Pure generation-time.

        Returns:
            True iff backend ``locate(screenshot, elem.label)`` returns a
            VisionElement whose bbox overlaps ``elem.bbox`` (IoU > 0.3).
        """
        try:
            match = self._backend.locate(screenshot, elem.label)
        except Exception as exc:
            logger.info("verify_element: backend raised %s, treating as miss", exc)
            return False
        if match is None:
            return False
        return _iou(elem.bbox, match.bbox) > 0.3

    # ---- method generation ---------------------------------------------

    def generate_methods(
        self,
        elements: list[VisionElement],
        *,
        software_name: str,
        existing_controls: list[UIControl] | None = None,
    ) -> list[APIMethod]:
        """Turn a list of :class:`VisionElement` into vision-mode APIMethods.

        Each element becomes one :class:`APIMethod` with
        ``operation_mode="vision"`` and ``uia_pattern=None``. The
        ``implementation_hint`` carries the baked-in bbox so the renderer
        can embed it in a ``ControlSpec`` literal.

        Args:
            elements: output of :meth:`introspect`.
            software_name: forwarded to method docstrings.
            existing_controls: if the UIA path already produced controls
                with the same label, we skip the vision method to avoid
                duplicates.

        Returns:
            list[APIMethod] in iteration order of ``elements``.
        """
        existing_names = {
            c.name.strip().lower() for c in (existing_controls or [])
        }
        # FIX 5: vision methods were verified at generation time (VLM bbox
        # baking). Stamp a single ISO-8601 UTC timestamp shared across the
        # batch so downstream drift tracking knows when these bboxes were
        # last confirmed.
        verified_ts = datetime.now(tz=timezone.utc).isoformat()

        methods: list[APIMethod] = []
        seen_method_names: set[str] = set()
        for idx, elem in enumerate(elements):
            label = (elem.label or f"element_{idx}").strip()
            if label.lower() in existing_names:
                logger.info(
                    "VisionGenerator: skip %r, already covered by UIA", label
                )
                continue
            method_name = _element_to_method_name(label, idx)
            if method_name in seen_method_names:
                method_name = f"{method_name}_{idx}"
            seen_method_names.add(method_name)
            methods.append(
                APIMethod(
                    name=method_name,
                    docstring=(
                        f"Click the {label!r} element in {software_name} "
                        "(vision-generated, bbox baked in)."
                    ),
                    params=[],
                    return_type="None",
                    operation_mode="vision",
                    implementation_hint=_vision_hint(elem),
                    uia_pattern=None,
                    internal_mode="vision",
                    generation_confidence=_confidence_to_int(elem.confidence),
                    last_verified_at=verified_ts,
                )
            )
        logger.info(
            "VisionGenerator.generate_methods produced=%d skipped_existing=%d",
            len(methods),
            len(elements) - len(methods),
        )
        return methods


# ---------------------------------------------------------------------------
# Adapter used by generator.py — convert VisionElement → pseudo-UIControl
# ---------------------------------------------------------------------------


def _vision_to_pseudo_controls(
    vision_elements: list[VisionElement],
) -> list[UIControl]:
    """Adapter: VisionElement → UIControl with bbox encoded in parent_path.

    The renderer uses ``control.name`` for locator lookup. We stash the
    bbox in ``parent_path`` using a stable prefix so ``_render_method``
    can recover it when emitting a :class:`ControlSpec` literal.

    The prefix ``vision-bbox:`` is recognized by the generator render
    path to route through the vision body renderer.
    """
    out: list[UIControl] = []
    for idx, elem in enumerate(vision_elements):
        x1, y1, x2, y2 = elem.bbox
        pseudo = UIControl(
            name=elem.label or f"element_{idx}",
            control_type="VisionElement",
            automation_id="",
            parent_path=f"vision-bbox:{x1},{y1},{x2},{y2}",
            patterns=[],  # signal: probed, no UIA patterns
        )
        out.append(pseudo)
    return out


# ---------------------------------------------------------------------------
# Pure helpers
# ---------------------------------------------------------------------------


def _element_to_method_name(label: str, idx: int) -> str:
    """``"Save As..."`` + idx 2 → ``click_save_as``."""
    cleaned = "".join(c if c.isalnum() or c == " " else " " for c in label)
    slug = "_".join(w.lower() for w in cleaned.split() if w)
    if not slug:
        slug = f"element_{idx}"
    return f"click_{slug}"


def _confidence_to_int(c: float) -> int:
    """Map 0-1 confidence to the 0-100 APIMethod.generation_confidence."""
    try:
        scaled = round(float(c) * 100)
    except (TypeError, ValueError):
        return 70
    return max(0, min(100, scaled))


def _vision_hint(elem: VisionElement) -> str:
    """Serialize the bbox so ``_render_method`` can embed it verbatim."""
    x1, y1, x2, y2 = elem.bbox
    label = elem.label or "element"
    return (
        f"vision_click label={label!r} bbox=({x1},{y1},{x2},{y2}) "
        f"confidence={elem.confidence:.2f}"
    )


def _iou(a: tuple[int, int, int, int], b: tuple[int, int, int, int]) -> float:
    """Intersection-over-union of two (x1,y1,x2,y2) boxes."""
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    ix1, iy1 = max(ax1, bx1), max(ay1, by1)
    ix2, iy2 = min(ax2, bx2), min(ay2, by2)
    iw, ih = max(0, ix2 - ix1), max(0, iy2 - iy1)
    inter = iw * ih
    area_a = max(0, ax2 - ax1) * max(0, ay2 - ay1)
    area_b = max(0, bx2 - bx1) * max(0, by2 - by1)
    union = area_a + area_b - inter
    if union <= 0:
        return 0.0
    return inter / union


def _dedupe_elements(elements: list[VisionElement]) -> list[VisionElement]:
    """Remove elements whose bbox IoU > 0.7 with an earlier element."""
    kept: list[VisionElement] = []
    for elem in elements:
        if any(_iou(elem.bbox, k.bbox) > 0.7 for k in kept):
            continue
        kept.append(elem)
    return kept


__all__ = [
    "VisionGenerator",
    "VisionIntrospectionReport",
    "_dedupe_elements",
    "_element_to_method_name",
    "_iou",
    "_vision_to_pseudo_controls",
]
