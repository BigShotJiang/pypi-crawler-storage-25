"""Qwen2.5-VL local VLM backend (generation-time only).

Optional local backend for Tier 4 introspection when no API budget / egress.
Hard dependencies (``torch``, ``transformers``, ``PIL``) are lazy-imported;
importing this module without them MUST succeed. Only
:meth:`Qwen25VLBackend.locate` / :meth:`Qwen25VLBackend.introspect_window`
raise :class:`ImportError` with an install hint.

Install via::

    pip install api-anything[vision-local]

Model name pinned to ``Qwen/Qwen2.5-VL-7B-Instruct`` (RFC §M recommendation);
override via ``model_name`` kwarg for ablation.

**Tests MUST NOT load the real model**. Use ``client`` / ``model`` /
``processor`` constructor injection to wire a :class:`MagicMock`.
"""

from __future__ import annotations

import json
import logging
from typing import Any

from ..vision_runtime import VisionElement
from .base import VLMBackend

logger = logging.getLogger(__name__)

QWEN_VL_DEFAULT_MODEL: str = "Qwen/Qwen2.5-VL-7B-Instruct"


def _missing_local_hint() -> ImportError:
    """Uniform hint for missing torch / transformers."""
    return ImportError(
        "Qwen2.5-VL backend requires torch + transformers + Pillow. "
        "Install with `pip install api-anything[vision-local]`."
    )


class Qwen25VLBackend(VLMBackend):
    """Local Qwen2.5-VL-7B-Instruct backend.

    Args:
        model_name: HF hub id, default ``Qwen/Qwen2.5-VL-7B-Instruct``.
        device: torch device string. Default ``"cuda"``; tests inject
            ``"cpu"`` or bypass entirely via ``model``/``processor``.
        model: pre-built HF model object (tests). When provided, no load.
        processor: pre-built HF ``AutoProcessor``. When provided, no load.
        max_new_tokens: generation budget for each query.
    """

    name = "qwen25-vl"

    def __init__(
        self,
        *,
        model_name: str = QWEN_VL_DEFAULT_MODEL,
        device: str = "cuda",
        model: Any | None = None,
        processor: Any | None = None,
        max_new_tokens: int = 256,
    ) -> None:
        self._model_name = model_name
        self._device = device
        self._model = model
        self._processor = processor
        self._max_new_tokens = int(max_new_tokens)

    # ---- lazy load -----------------------------------------------------

    def check_credentials(self) -> bool:
        """Always True — local backend only needs the model files present.

        Actual presence is checked at first load in :meth:`_ensure_loaded`.
        """
        return True

    def _ensure_loaded(self) -> tuple[Any, Any]:
        """Lazy-load model + processor on first real call."""
        if self._model is not None and self._processor is not None:
            return self._model, self._processor
        try:
            from transformers import (  # type: ignore[import-not-found]
                AutoProcessor,
                Qwen2_5_VLForConditionalGeneration,
            )
        except ImportError as exc:
            raise _missing_local_hint() from exc

        logger.info(
            "Qwen25VLBackend: loading %s onto %s (first use)",
            self._model_name,
            self._device,
        )
        if self._model is None:
            self._model = Qwen2_5_VLForConditionalGeneration.from_pretrained(
                self._model_name,
                torch_dtype="auto",
                device_map=self._device,
            )
        if self._processor is None:
            self._processor = AutoProcessor.from_pretrained(self._model_name)
        return self._model, self._processor

    # ---- public VLM surface --------------------------------------------

    def locate(self, screenshot: bytes, query: str) -> VisionElement | None:
        text = self._run_generate(
            screenshot,
            (
                f"Locate the element matching: {query}. Reply with JSON "
                '{"label": ..., "bbox": [x1,y1,x2,y2], "confidence": 0-1} '
                "or an empty object {} if absent."
            ),
        )
        elements = _parse_single(text)
        if not elements:
            logger.info("Qwen25VLBackend.locate no match for %r", query)
            return None
        return elements[0]

    def introspect_window(
        self,
        screenshot: bytes,
        *,
        max_elements: int = 40,
    ) -> list[VisionElement]:
        text = self._run_generate(
            screenshot,
            (
                f"List up to {max_elements} salient UI controls in this screenshot. "
                "Reply as a JSON array of "
                '{"label": ..., "bbox": [x1,y1,x2,y2], "confidence": 0-1}.'
            ),
        )
        return _parse_list(text)[:max_elements]

    # ---- internals ------------------------------------------------------

    def _run_generate(self, screenshot: bytes, query: str) -> str:
        """Run a single vision-conditioned generation and return raw text."""
        model, processor = self._ensure_loaded()
        try:
            from io import BytesIO

            from PIL import Image  # type: ignore[import-not-found]
        except ImportError as exc:
            raise _missing_local_hint() from exc

        image = Image.open(BytesIO(screenshot)).convert("RGB")
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "image", "image": image},
                    {"type": "text", "text": query},
                ],
            }
        ]
        # HF processors accept the messages list directly in recent versions
        # via apply_chat_template; we call that if present, else fall back
        # to a raw processor call (tests mock either path).
        if hasattr(processor, "apply_chat_template"):
            prompt = processor.apply_chat_template(
                messages, add_generation_prompt=True
            )
        else:
            prompt = query
        inputs = processor(text=prompt, images=[image], return_tensors="pt")
        outputs = model.generate(
            **inputs, max_new_tokens=self._max_new_tokens
        )
        text = processor.batch_decode(outputs, skip_special_tokens=True)
        if isinstance(text, list):
            return str(text[0]) if text else ""
        return str(text)


# ---------------------------------------------------------------------------
# Pure text→element parsing (easy to mock)
# ---------------------------------------------------------------------------


def _parse_single(text: str) -> list[VisionElement]:
    """Parse a single-object JSON reply. Returns [] for empty / malformed."""
    stripped = (text or "").strip()
    if not stripped:
        return []
    # Pull the first {...} substring — models may wrap in prose
    start = stripped.find("{")
    end = stripped.rfind("}")
    if start == -1 or end == -1 or end <= start:
        return []
    chunk = stripped[start : end + 1]
    try:
        obj = json.loads(chunk)
    except (TypeError, ValueError):
        return []
    if not isinstance(obj, dict) or not obj:
        return []
    bbox = obj.get("bbox") or obj.get("box")
    if not bbox:
        return []
    try:
        x1, y1, x2, y2 = (int(v) for v in bbox)
    except (TypeError, ValueError):
        return []
    return [
        VisionElement(
            label=str(obj.get("label") or "element"),
            bbox=(x1, y1, x2, y2),
            confidence=float(obj.get("confidence", 0.0)),
        )
    ]


def _parse_list(text: str) -> list[VisionElement]:
    """Parse a JSON-array reply. Returns [] for malformed responses."""
    stripped = (text or "").strip()
    if not stripped:
        return []
    start = stripped.find("[")
    end = stripped.rfind("]")
    if start == -1 or end == -1 or end <= start:
        return []
    chunk = stripped[start : end + 1]
    try:
        raw = json.loads(chunk)
    except (TypeError, ValueError):
        return []
    if not isinstance(raw, list):
        return []
    out: list[VisionElement] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        bbox = item.get("bbox") or item.get("box")
        if not bbox:
            continue
        try:
            x1, y1, x2, y2 = (int(v) for v in bbox)
        except (TypeError, ValueError):
            continue
        out.append(
            VisionElement(
                label=str(item.get("label") or "element"),
                bbox=(x1, y1, x2, y2),
                confidence=float(item.get("confidence", 0.0)),
            )
        )
    return out


__all__ = [
    "QWEN_VL_DEFAULT_MODEL",
    "Qwen25VLBackend",
]
