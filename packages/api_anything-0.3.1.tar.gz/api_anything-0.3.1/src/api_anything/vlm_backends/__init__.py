"""VLM backend adapters for Vision-driven API generation (RFC v0.3 §D).

Three backend families ship with api-anything v0.3:

* :class:`ClaudeCUBackend` — Anthropic Claude Computer Use (default, remote).
* :class:`Qwen25VLBackend` — local Qwen2.5-VL-7B-Instruct (``[vision-local]``).
* :class:`OSAtlasBackend` — local OS-Atlas-7B grounding primitive.

All three are duck-typed compatible with
``api_anything.vision_runtime._VLMClientProto`` (``locate(bytes, str) ->
VisionElement | None``) and fully mockable for unit tests. Heavy SDK imports
(``anthropic`` / ``torch`` / ``transformers``) are deferred to first real
call — so merely importing this package is safe on any machine.
"""

from __future__ import annotations

from .base import VLMBackend
from .claude_cu import ClaudeCUBackend
from .os_atlas import OSAtlasBackend
from .qwen25_vl import Qwen25VLBackend

__all__ = [
    "ClaudeCUBackend",
    "OSAtlasBackend",
    "Qwen25VLBackend",
    "VLMBackend",
]
