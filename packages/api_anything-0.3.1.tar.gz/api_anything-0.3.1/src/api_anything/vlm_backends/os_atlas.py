"""OS-Atlas-7B grounding primitive backend (generation-time only).

OS-Atlas is a Qwen2-VL derivative fine-tuned purely for
description-to-bbox grounding (no chat, no intent). The API is
``model.chat("click the Save button", screenshot)`` → returns normalized
``(x, y)`` in 0-1000 space.

We wrap it as a full :class:`VLMBackend` so
:class:`api_anything.vision_generator.VisionGenerator` can use it
interchangeably with Claude CU / Qwen2.5-VL. ``introspect_window``
iterates over a small library of synthetic queries; OS-Atlas is
single-shot by design, so callers primarily use :meth:`locate`.

Heavy deps (``torch`` / ``transformers``) are lazy — import of this
module never raises. Install extra via ``api-anything[vision-local]``.
"""

from __future__ import annotations

import logging
from typing import Any

from ..vision_runtime import VisionElement
from .base import VLMBackend

logger = logging.getLogger(__name__)

OS_ATLAS_DEFAULT_MODEL: str = "OS-Copilot/OS-Atlas-Base-7B"
# Queries used when caller asks for a batch introspection but OS-Atlas
# only does 1-shot grounding. Each query returns at most one element.
_INTROSPECT_PROBE_QUERIES: tuple[str, ...] = (
    "the main action button",
    "the primary input field",
    "the save button",
    "the cancel button",
    "the menu bar",
    "the toolbar",
    "the close button",
    "the settings icon",
)

# Default bbox half-width in window pixels when OS-Atlas returns a point
# only; synthesize a small click box around the coordinate.
_POINT_TO_BBOX_HALFWIDTH: int = 6


def _missing_local_hint() -> ImportError:
    """Uniform hint for missing torch / transformers."""
    return ImportError(
        "OS-Atlas backend requires torch + transformers. "
        "Install with `pip install api-anything[vision-local]`."
    )


class OSAtlasBackend(VLMBackend):
    """OS-Atlas grounding primitive backend.

    Args:
        model_name: HF hub id (default OS-Atlas-Base-7B).
        device: torch device string.
        model: pre-built HF model (tests).
        tokenizer: pre-built HF tokenizer (tests).
        window_size: (width, height) of the window whose screenshot is
            being analyzed; needed to map OS-Atlas 0-1000 normalized
            output back to pixel coordinates. Defaults to 1920x1080.
    """

    name = "os-atlas"

    def __init__(
        self,
        *,
        model_name: str = OS_ATLAS_DEFAULT_MODEL,
        device: str = "cuda",
        model: Any | None = None,
        tokenizer: Any | None = None,
        window_size: tuple[int, int] = (1920, 1080),
    ) -> None:
        self._model_name = model_name
        self._device = device
        self._model = model
        self._tokenizer = tokenizer
        self._window_size = (int(window_size[0]), int(window_size[1]))

    # ---- lazy load -----------------------------------------------------

    def check_credentials(self) -> bool:
        """Always True — checked at load time instead."""
        return True

    def _ensure_loaded(self) -> tuple[Any, Any]:
        """Lazy-load OS-Atlas model + tokenizer."""
        if self._model is not None and self._tokenizer is not None:
            return self._model, self._tokenizer
        try:
            from transformers import (  # type: ignore[import-not-found]
                AutoModelForCausalLM,
                AutoTokenizer,
            )
        except ImportError as exc:
            raise _missing_local_hint() from exc
        logger.info(
            "OSAtlasBackend: loading %s onto %s (first use)",
            self._model_name,
            self._device,
        )
        if self._model is None:
            self._model = AutoModelForCausalLM.from_pretrained(
                self._model_name,
                torch_dtype="auto",
                device_map=self._device,
                trust_remote_code=True,
            )
        if self._tokenizer is None:
            self._tokenizer = AutoTokenizer.from_pretrained(
                self._model_name, trust_remote_code=True
            )
        return self._model, self._tokenizer

    # ---- public VLM surface --------------------------------------------

    def locate(self, screenshot: bytes, query: str) -> VisionElement | None:
        """Call OS-Atlas ``.chat`` and map its (x, y) 0-1000 output to a
        window-pixel bbox."""
        model, tokenizer = self._ensure_loaded()
        prompt = f"click {query}"
        try:
            response, _history = model.chat(
                tokenizer=tokenizer,
                query=prompt,
                image=screenshot,
                history=None,
            )
        except Exception as exc:
            logger.warning("OSAtlasBackend chat failed: %s", exc)
            return None
        xy = _parse_normalized_point(response)
        if xy is None:
            return None
        return _point_to_element(
            xy,
            label=query,
            window_size=self._window_size,
            confidence=0.8,  # OS-Atlas is single-shot and high-precision
        )

    def introspect_window(
        self,
        screenshot: bytes,
        *,
        max_elements: int = 40,
    ) -> list[VisionElement]:
        """Fan-out over canned queries. Each hit becomes one element."""
        out: list[VisionElement] = []
        for query in _INTROSPECT_PROBE_QUERIES[:max_elements]:
            element = self.locate(screenshot, query)
            if element is not None:
                out.append(element)
            if len(out) >= max_elements:
                break
        return out


# ---------------------------------------------------------------------------
# Pure helpers
# ---------------------------------------------------------------------------


def _parse_normalized_point(response: str) -> tuple[int, int] | None:
    """Extract the first ``(x, y)`` or ``[x, y]`` pair from OS-Atlas text.

    OS-Atlas outputs values in 0-1000 normalized space. This helper is
    permissive about bracket style so unit tests can inject simple strings.
    """
    if not response or not isinstance(response, str):
        return None
    text = response.strip()
    # Accept forms: "(123, 456)", "[123, 456]", "123 456"
    for lch, rch in (("(", ")"), ("[", "]")):
        if lch in text and rch in text:
            inside = text[text.find(lch) + 1 : text.rfind(rch)]
            parts = [p.strip() for p in inside.split(",") if p.strip()]
            if len(parts) == 2:
                try:
                    return int(float(parts[0])), int(float(parts[1]))
                except (TypeError, ValueError):
                    return None
    parts = text.replace(",", " ").split()
    if len(parts) >= 2:
        try:
            return int(float(parts[0])), int(float(parts[1]))
        except (TypeError, ValueError):
            return None
    return None


def _point_to_element(
    xy_norm: tuple[int, int],
    *,
    label: str,
    window_size: tuple[int, int],
    confidence: float,
) -> VisionElement:
    """Denormalize a 0-1000 point and synthesize a small bbox around it."""
    nx, ny = xy_norm
    w, h = window_size
    px = int(nx * w / 1000)
    py = int(ny * h / 1000)
    hw = _POINT_TO_BBOX_HALFWIDTH
    return VisionElement(
        label=label,
        bbox=(px - hw, py - hw, px + hw, py + hw),
        confidence=float(confidence),
    )


__all__ = [
    "OS_ATLAS_DEFAULT_MODEL",
    "OSAtlasBackend",
]
