"""Claude Computer Use (CU) VLM backend — **generation-time** adapter.

RFC v0.3 §D (Vision) default backend. Uses Anthropic's Messages API with the
``computer_20251124`` tool to ground UI elements from screenshots. The
``anthropic`` SDK import is fully lazy — importing this module with the SDK
absent MUST NOT raise. Only :meth:`locate` / :meth:`introspect_window`
surface :class:`ImportError` with an install hint.

Rules:
    * No real API call in tests — every test must pass an ``anthropic``
      client mock via the ``client`` constructor kwarg.
    * ``check_credentials`` reads ``ANTHROPIC_API_KEY`` from env, never
      from a config file (MEMORY #50 paid-API authorization rule).
    * Beta header is **pinned** to a single string; upgrades bump
      intentionally via a code change (RELEASE_COORDINATION rule).
"""

from __future__ import annotations

import json
import logging
import os
from typing import TYPE_CHECKING, Any

from ..vision_runtime import VisionElement
from .base import VLMBackend

if TYPE_CHECKING:  # pragma: no cover - typing only, no runtime import
    pass

logger = logging.getLogger(__name__)


# Pinned beta header — see RELEASE_COORDINATION.md "升級前 checklist" before
# bumping. Changing this string == contract change; review implications.
CLAUDE_CU_BETA_HEADER: str = "computer-use-2025-11-24"
CLAUDE_CU_TOOL_TYPE: str = "computer_20251124"
CLAUDE_CU_DEFAULT_MODEL: str = "claude-opus-4-5"


def _missing_anthropic_hint() -> ImportError:
    """Construct a uniform ImportError for the missing anthropic SDK."""
    return ImportError(
        "anthropic SDK not installed. Install with "
        "`pip install api-anything[vision-remote]` or `pip install anthropic`."
    )


class ClaudeCUBackend(VLMBackend):
    """Anthropic Claude Computer Use backend (remote, generation-time).

    Args:
        client: optional pre-built ``anthropic.Anthropic`` instance (or any
            duck-typed object with ``.messages.create(...)``). Tests inject
            a :class:`~unittest.mock.MagicMock`. If ``None`` and env var
            ``ANTHROPIC_API_KEY`` is set, a real client is lazily built on
            first call.
        model: Anthropic model ID. Default "claude-opus-4-5".
        beta_header: override pinned beta header (not recommended).
        display_width / display_height: values forwarded to the CU tool;
            **generation-time** constants the backend claims the screenshot
            represents. Defaults cover 1080p.
    """

    name = "claude-cu"

    def __init__(
        self,
        *,
        client: Any | None = None,
        model: str = CLAUDE_CU_DEFAULT_MODEL,
        beta_header: str = CLAUDE_CU_BETA_HEADER,
        display_width: int = 1920,
        display_height: int = 1080,
    ) -> None:
        self._client = client
        self._model = model
        self._beta_header = beta_header
        self._display_width = int(display_width)
        self._display_height = int(display_height)

    # ---- credential / lazy client plumbing ------------------------------

    def check_credentials(self) -> bool:
        """Return True iff ``ANTHROPIC_API_KEY`` is present or a client
        was injected."""
        if self._client is not None:
            return True
        return bool(os.environ.get("ANTHROPIC_API_KEY", "").strip())

    def _ensure_client(self) -> Any:
        """Lazy-construct the anthropic client on first real call."""
        if self._client is not None:
            return self._client
        try:
            import anthropic  # type: ignore[import-not-found]
        except ImportError as exc:  # pragma: no cover - triggered w/o SDK
            raise _missing_anthropic_hint() from exc
        self._client = anthropic.Anthropic()
        return self._client

    # ---- public VLM surface --------------------------------------------

    def locate(self, screenshot: bytes, query: str) -> VisionElement | None:
        """Call Claude CU with the screenshot + query and return the
        single best-matched element, or ``None`` when CU gives no box."""
        response = self._call_cu(screenshot, query, mode="locate")
        element = _first_element_from_response(response)
        if element is None:
            logger.info("ClaudeCU.locate returned no element for %r", query)
        return element

    def introspect_window(
        self,
        screenshot: bytes,
        *,
        max_elements: int = 40,
    ) -> list[VisionElement]:
        """Ask Claude CU to enumerate all major controls in the screenshot."""
        prompt = (
            f"List up to {max_elements} salient UI elements (buttons, inputs, menus) "
            "visible in this screenshot. For each, return a JSON object "
            "with fields: label (human-readable name), bbox (x1,y1,x2,y2 "
            "pixels), confidence (0-1)."
        )
        response = self._call_cu(screenshot, prompt, mode="introspect")
        elements = _elements_from_response(response)
        return elements[:max_elements]

    # ---- internals ------------------------------------------------------

    def _call_cu(self, screenshot: bytes, query: str, *, mode: str) -> Any:
        """Dispatch a single CU request. ``mode`` is logged / observability
        but does not change the wire call structure."""
        client = self._ensure_client()

        # Build the tool definition. Claude CU's ``computer_20251124``
        # expects display dimensions up front. We keep this minimal — the
        # backend is a *single-shot vision query*, not an agent loop.
        tools = [
            {
                "type": CLAUDE_CU_TOOL_TYPE,
                "name": "computer",
                "display_width_px": self._display_width,
                "display_height_px": self._display_height,
            }
        ]

        import base64 as _b64

        b64 = _b64.b64encode(screenshot).decode("ascii")
        messages = [
            {
                "role": "user",
                "content": [
                    {
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": "image/png",
                            "data": b64,
                        },
                    },
                    {"type": "text", "text": query},
                ],
            }
        ]
        logger.info(
            "ClaudeCU %s: model=%s beta=%s query_len=%d",
            mode,
            self._model,
            self._beta_header,
            len(query),
        )
        # ``extra_headers`` is the standard escape hatch for beta flags.
        return client.messages.create(
            model=self._model,
            max_tokens=1024,
            tools=tools,
            messages=messages,
            extra_headers={"anthropic-beta": self._beta_header},
        )


# ---------------------------------------------------------------------------
# Response parsing helpers (pure functions, easy to unit-test)
# ---------------------------------------------------------------------------


def _first_element_from_response(response: Any) -> VisionElement | None:
    """Extract the first :class:`VisionElement` from a CU response.

    Tolerant of mock shapes: the response is expected to carry ``.content``
    which is a list of blocks; each block may be a tool-use (with
    ``.input`` holding a ``{"box": [...]}`` or JSON text) or a plain text
    JSON. Any parse failure → ``None``.
    """
    elements = _elements_from_response(response)
    return elements[0] if elements else None


def _elements_from_response(response: Any) -> list[VisionElement]:
    """Parse as many :class:`VisionElement` as the response contains."""
    content = getattr(response, "content", None)
    if not content:
        return []
    elements: list[VisionElement] = []
    for block in content:
        el = _element_from_block(block)
        if el is not None:
            elements.append(el)
        else:
            # Block might carry a JSON list of candidates
            elements.extend(_element_list_from_text(block))
    return elements


def _element_from_block(block: Any) -> VisionElement | None:
    """Parse a single tool-use block into one element (or None)."""
    bbox_raw: Any = None
    label: str = ""
    confidence: float = 0.0

    block_type = getattr(block, "type", None)
    if block_type == "tool_use":
        # Claude CU returns tool_use with input={"action": "click", "coordinate": [x,y]}
        raw_input = getattr(block, "input", None) or {}
        if isinstance(raw_input, dict):
            if "box" in raw_input:
                bbox_raw = raw_input["box"]
            elif "coordinate" in raw_input:
                x, y = raw_input["coordinate"]
                # Synthesize a tiny box around the click point
                bbox_raw = [int(x) - 4, int(y) - 4, int(x) + 4, int(y) + 4]
            label = str(raw_input.get("label") or raw_input.get("action", ""))
            confidence = float(raw_input.get("confidence", 0.0))
    if bbox_raw is None:
        return None
    try:
        x1, y1, x2, y2 = (int(v) for v in bbox_raw)
    except (TypeError, ValueError):
        return None
    return VisionElement(label=label or "element", bbox=(x1, y1, x2, y2),
                         confidence=confidence)


def _element_list_from_text(block: Any) -> list[VisionElement]:
    """Attempt to parse a JSON array of elements from a text block."""
    text = getattr(block, "text", None)
    if not text or not isinstance(text, str):
        return []
    stripped = text.strip()
    if not stripped.startswith("["):
        return []
    try:
        raw_list = json.loads(stripped)
    except (TypeError, ValueError, json.JSONDecodeError):
        return []
    if not isinstance(raw_list, list):
        return []
    out: list[VisionElement] = []
    for item in raw_list:
        if not isinstance(item, dict):
            continue
        bbox = item.get("bbox") or item.get("box")
        if not bbox:
            continue
        try:
            x1, y1, x2, y2 = (int(v) for v in bbox)
        except (TypeError, ValueError):
            continue
        out.append(
            VisionElement(
                label=str(item.get("label") or "element"),
                bbox=(x1, y1, x2, y2),
                confidence=float(item.get("confidence", 0.0)),
            )
        )
    return out


__all__ = [
    "CLAUDE_CU_BETA_HEADER",
    "CLAUDE_CU_DEFAULT_MODEL",
    "CLAUDE_CU_TOOL_TYPE",
    "ClaudeCUBackend",
]
