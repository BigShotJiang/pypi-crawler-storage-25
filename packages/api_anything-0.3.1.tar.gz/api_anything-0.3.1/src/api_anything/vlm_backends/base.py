"""Abstract base for Vision-Language-Model backends (RFC v0.3 M1).

Every backend must be:

* **Duck-typed compatible** with ``api_anything.vision_runtime._VLMClientProto``
  (``locate(screenshot: bytes, query: str) -> VisionElement | None``). Runtime
  code only relies on ``locate`` — richer methods below are **generation-time
  only** and MUST NOT be called from a generated API class body.
* **Lazy-importing**: never import ``anthropic`` / ``torch`` /
  ``transformers`` at module top level. Importing the adapter file with the
  underlying SDK absent MUST NOT raise — only constructing / calling the
  backend should raise :class:`ImportError` with an install hint.
* **Fully mockable**: concrete adapters accept an optional ``client`` /
  ``model`` injection parameter so unit tests can replace the external SDK
  with :class:`unittest.mock.MagicMock` and never hit the network / GPU.

Introspection helper ``introspect_window`` is a richer analogue of
``locate`` meant for the M1 ``VisionGenerator``: given a screenshot, return
all candidate UI elements so the generator can render Set-of-Marks overlays
and pick the right one per user query.
"""

from __future__ import annotations

import abc
import logging

from ..vision_runtime import VisionElement

logger = logging.getLogger(__name__)


class VLMBackend(abc.ABC):
    """Abstract base for all Vision-Language-Model backends.

    Subclasses MUST implement both :meth:`locate` and
    :meth:`introspect_window`. ``locate`` is the runtime-shaped primitive
    (keeps :class:`api_anything.vision_runtime._VLMClientProto` happy);
    ``introspect_window`` is the generation-time batch counterpart the
    :class:`api_anything.vision_generator.VisionGenerator` uses to seed
    Set-of-Marks prompting.

    Notes:
        * ``name`` is used by logger / Observable checks — subclasses should
          set a short unique token.
        * Calling :meth:`check_credentials` before :meth:`locate` is
          recommended for remote backends that need env vars.
    """

    name: str = "base"

    @abc.abstractmethod
    def locate(self, screenshot: bytes, query: str) -> VisionElement | None:
        """Return the element matching ``query`` in ``screenshot``.

        Args:
            screenshot: PNG bytes of the target window.
            query: natural-language description of the desired element
                (e.g. ``"the Save button in the toolbar"``).

        Returns:
            :class:`VisionElement` or ``None`` if the backend is not
            confident enough (caller promotes ``None`` to
            ``LookupError`` via ``_locate_control``).
        """

    @abc.abstractmethod
    def introspect_window(
        self,
        screenshot: bytes,
        *,
        max_elements: int = 40,
    ) -> list[VisionElement]:
        """Return all salient UI elements in ``screenshot``.

        Used by :class:`api_anything.vision_generator.VisionGenerator` to
        seed Set-of-Marks prompts (RFC §D.3). Backends that only do
        single-point grounding should iterate internally and return the
        top-N candidates.

        Args:
            screenshot: PNG bytes of the target window.
            max_elements: cap on returned list length (helps bound
                prompt / GPU cost).
        """

    def check_credentials(self) -> bool:
        """Return ``True`` if the backend can run (env vars / model present).

        Default: ``True`` — local/mock backends do not need credentials.
        Remote adapters override this to check ``ANTHROPIC_API_KEY`` etc.
        """
        return True

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__} name={self.name!r}>"


__all__ = ["VLMBackend"]
