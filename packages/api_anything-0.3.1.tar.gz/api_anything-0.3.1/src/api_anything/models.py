# ruff: noqa: RUF003
"""Pydantic models for the API-Anything generation pipeline.

Defines the data structures flowing through: analysis -> design -> codegen.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


class UIControl(BaseModel):
    """A single UI control discovered from UIA or screenshot analysis."""

    name: str
    control_type: str  # Button, Menu, TextBox, Slider, CheckBox, etc.
    automation_id: str = ""
    parent_path: str = ""  # e.g. "File > Export"
    value_range: tuple[float, float] | None = None
    current_value: str = ""
    children: list[UIControl] = Field(default_factory=list)
    # RFC v0.3 M0：UIA supported patterns（例如 ["InvokePattern", "ValuePattern"]）。
    # None 代表分析器未探測（v0.2 向下相容路徑）；空 list 代表探測過但無 pattern。
    patterns: list[str] | None = None


class APIParam(BaseModel):
    """A single parameter for a generated API method."""

    name: str
    type_hint: str
    default: str | None = None
    description: str = ""


class APIMethod(BaseModel):
    """A single method to be generated in the API class."""

    name: str  # snake_case method name
    docstring: str
    params: list[APIParam] = Field(default_factory=list)
    return_type: str = "None"
    operation_mode: Literal["subprocess", "uia", "vision", "replay"] = "subprocess"
    implementation_hint: str = ""  # LLM-generated implementation plan
    # RFC v0.3 M0：pattern-based dispatch 補充欄位（None = v0.2 legacy path）。
    uia_pattern: str | None = None  # e.g. "InvokePattern"
    # internal_mode values: "uia_pattern" | "uia_legacy" | "subprocess" | "replay" | "vision"
    internal_mode: str | None = None
    generation_confidence: int = 70  # 0-100, higher means more confident
    # RFC v0.3 M1：last regeneration / verification time in ISO 8601 UTC
    # (e.g. "2026-04-17T10:30:00Z"). None = never verified. Consumed by
    # H.3 docstring rendering + drift detection.
    last_verified_at: str | None = None
    # RFC v0.3 M2：record-replay 補充欄位（operation_mode == "replay" 時填）。
    # record_trace_id 指向 RecordTrace.trace_id；record_trace_path 指向實體
    # JSONL 檔，讓 render 階段把 `Replayer.from_file(path)` 字串嵌入 method body。
    record_trace_id: str | None = None
    record_trace_path: str | None = None


class APIClass(BaseModel):
    """Complete specification for a generated API class."""

    class_name: str  # PascalCase
    module_name: str  # snake_case
    docstring: str
    software_name: str
    software_version: str = ""
    tier: str = "2A"
    methods: list[APIMethod] = Field(default_factory=list)
    imports: list[str] = Field(default_factory=list)
    setup_code: str = ""  # __init__ body


class GenerationResult(BaseModel):
    """Output of the full generation pipeline."""

    api_class: APIClass
    source_code: str  # generated .py file content
    test_code: str  # generated test file content
    tier_result: Any = None  # TierResult from tier_detect (Any to avoid circular import)
    tokens_used: int = 0
    generation_time_seconds: float = 0.0
    # RFC v0.2 D 項：標示走哪條路徑生成
    # - "mock": no client, used _mock_generate
    # - "schema": Instructor + Pydantic 填欄位 (_instructor_generate)
    # - "llm_driven": LLM 直接吐整段原始碼 (llm_driven_generate)
    # - "llm_driven_fallback_to_schema": LLM 走了但驗證失敗，回退到 schema
    generation_mode: str = "mock"
    # 三關驗證結果（僅 llm_driven 走時填），dict 形式避免 Pydantic 需 import
    validation: dict[str, Any] | None = None
    # RFC v0.3 M0：主要使用的 UIA pattern（若 multiple，取 priority 最高的）。
    # None 代表此次生成沒走 pattern-based dispatch（全 subprocess 或 legacy UIA）。
    pattern_used: str | None = None
