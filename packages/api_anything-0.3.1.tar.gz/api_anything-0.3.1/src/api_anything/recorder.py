"""Record-Replay recorder — RFC v0.3 M2.

Three-layer event capture (see RFC §E.2):

A. UIA ``AutomationEventHandler`` (primary)
   - ``UIA_Invoke_InvokedEventId`` → button click equivalents
   - ``UIA_Value_ValuePropertyId`` → text field edits
   - ``UIA_Selection_SelectionChangedEventId`` → list/combo selection
   - Each event carries ``control_path`` (resolution-independent)

B. mss screenshot stream (secondary)
   - snap every 500ms, saved as 60x60 thumbnails
   - fills gaps where UIA missed the event

C. pynput raw keyboard/mouse hook (tertiary)
   - captures hotkeys + Canvas clicks UIA cannot see

Filters:
    - drop ``mouse.move`` (only record discrete events)
    - debounce: two identical UIA events within 50ms → keep first only
    - privacy: UIA control with ``IsPassword=True`` stores ``"<password>"``
      in place of the real text

Storage:
    traces_dir (default ``.api_anything_traces/``)
      ├── <app>_<NNN>.jsonl
      └── <trace_id>_thumbnails/
          ├── 0000.png
          ├── 0001.png
          └── ...

Every dependency (``uiautomation`` / ``mss`` / ``pynput``) is lazily imported
inside ``start()`` so the import of this module does not crash on a box that
does not have those libs (tests mock them).
"""

from __future__ import annotations

import json
import logging
import re
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from . import _uia_events as uev

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Public data model
# ---------------------------------------------------------------------------


EventType = Literal["uia.Invoke", "uia.Value", "uia.Selection", "key", "mouse"]


class RecordEvent(BaseModel):
    """A single captured event in the record stream."""

    ts: float  # seconds since trace start
    event_type: EventType
    control_path: str | None = None
    value: str | None = None
    screenshot_ref: str | None = None  # path relative to thumbnails dir
    # RFC v0.3 M2: generator annotates these after LLM infers method schema.
    # replay-time substitutes ``params[param_name]`` for this event's value.
    value_is_param: bool = False
    param_name: str | None = None


class RecordTrace(BaseModel):
    """Full recording of one user session against one app."""

    app_name: str
    trace_id: str
    started_at: str  # ISO 8601
    events: list[RecordEvent] = Field(default_factory=list)
    thumbnails_dir: Path
    # ISO 8601 end time (set by stop()); kept optional for back-compat / crash.
    stopped_at: str | None = None

    model_config = ConfigDict(arbitrary_types_allowed=True)


# ---------------------------------------------------------------------------
# Recorder
# ---------------------------------------------------------------------------


_DEBOUNCE_SECONDS = 0.05  # 50ms identical-event debounce window
_SCREENSHOT_INTERVAL_SECONDS = 0.5
_PASSWORD_MARKER = "<password>"
_DEFAULT_TRACES_DIR = Path(".api_anything_traces")


class Recorder:
    """Three-layer recorder. Call ``start()`` → user does stuff → ``stop()``.

    Hook attributes (``_uia_handler`` / ``_screenshot_thread`` / ``_raw_hook``)
    are all exposed so tests can mock them without touching platform libs.

    Scope (RFC v0.3 M2 post-merge FATAL fix):
        - ``target_window_handle``: HWND to scope capture to. If ``None`` at
          ``start()``, we resolve it via ``GetForegroundWindow()`` (Windows)
          or log a loud warning + disable screenshot stream (non-Windows /
          no window). UIA subtree subscribes from this HWND; mss grab uses
          the window rect; pynput events are gated by
          ``GetForegroundWindow() == target_window_handle``.
        - ``IsPassword`` masking stays on as defense-in-depth.
    """

    def __init__(
        self,
        app_name: str,
        *,
        target_window_handle: int | None = None,
        traces_dir: Path | None = None,
    ) -> None:
        self.app_name = app_name
        self.traces_dir = Path(traces_dir) if traces_dir else _DEFAULT_TRACES_DIR
        self.trace_id = self._allocate_trace_id()
        self._events: list[RecordEvent] = []
        self._start_ts: float | None = None
        self._started_at_iso: str | None = None
        self._running: bool = False
        self._screenshot_counter: int = 0
        self._screenshot_stop: threading.Event = threading.Event()
        # Target window scoping (FIX 1+2). None = capture lazily at start()
        # via GetForegroundWindow. Cached rect refreshed per screenshot tick
        # to survive user drag/resize.
        self._target_window_handle: int | None = target_window_handle
        self._target_bounds: dict[str, int] | None = None
        # Loud-warning flag: True when we could not bind a target window and
        # fell back to degraded capture — screenshot stream stays OFF.
        self._target_window_missing: bool = False
        # Test-friendly hook slots. Real platform hooks live behind these
        # attributes so tests can inject MagicMocks without patching sys.modules.
        self._uia_handler: Any = None
        # Each token is a (kind_label, UIAEventToken) pair. Kept as tuples for
        # backward-compat with v0.3.0 tests that inspected tok[0].
        self._uia_handler_tokens: list[tuple[str, Any]] = []
        self._screenshot_thread: threading.Thread | None = None
        self._raw_hook: Any = None
        # Last (event_type, control_path, value) triple, for dedup.
        self._last_event_key: tuple[str, str | None, str | None] | None = None
        self._last_event_ts: float = 0.0

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def start(self) -> None:
        """Begin capture. Idempotent — calling twice is a no-op (logged)."""
        if self._running:
            logger.info("Recorder for %s already running, ignoring start()", self.app_name)
            return
        self.traces_dir.mkdir(parents=True, exist_ok=True)
        self._thumbnails_dir.mkdir(parents=True, exist_ok=True)
        self._start_ts = time.monotonic()
        self._started_at_iso = datetime.now(timezone.utc).isoformat()
        self._running = True
        self._events = []
        self._screenshot_counter = 0
        self._screenshot_stop = threading.Event()

        # Resolve target window (FIX 1+2). If user didn't pass one, try
        # foreground-window capture. If we still can't get a HWND, mark
        # missing — screenshot thread will stay off (loud warning logged).
        self._resolve_target_window()

        # Install hooks — each is a separate method so tests can override.
        self._install_uia_handler()
        self._install_screenshot_stream()
        self._install_raw_hook()

        logger.info(
            "Recorder.start app=%s trace_id=%s dir=%s hwnd=%s",
            self.app_name,
            self.trace_id,
            self.traces_dir,
            self._target_window_handle,
        )

    def _resolve_target_window(self) -> None:
        """Populate ``self._target_window_handle`` if caller didn't.

        Windows-only path (uses ``user32.GetForegroundWindow``). On non-
        Windows or if the call errors, we log a LOUD warning and set
        ``_target_window_missing = True`` so capture paths degrade safely
        (no desktop-wide screenshot fallback — see FIX 2).
        """
        if self._target_window_handle:
            return
        try:
            import ctypes

            user32 = ctypes.windll.user32  # type: ignore[attr-defined]
            hwnd = int(user32.GetForegroundWindow())
            if hwnd:
                self._target_window_handle = hwnd
                return
        except (AttributeError, OSError, ImportError) as exc:
            logger.warning(
                "Recorder.start could not resolve target window (non-Windows?): %s. "
                "Screenshot stream DISABLED. UIA/raw events may still fire "
                "but scope is not enforced — caller should pass "
                "target_window_handle explicitly for production use.",
                exc,
            )
        self._target_window_missing = True

    def stop(self) -> RecordTrace:
        """Stop capture and return the built-up ``RecordTrace``.

        Idempotent — calling after stop returns the already-built trace.
        """
        if not self._running and self._start_ts is not None:
            logger.info("Recorder.stop called twice for %s", self.app_name)
            return self._build_trace()
        if self._start_ts is None:
            raise RuntimeError("Recorder.stop called before start")

        self._running = False
        self._screenshot_stop.set()

        # Uninstall hooks. Best effort — any lib error is logged but not raised.
        self._uninstall_uia_handler()
        self._stop_screenshot_stream()
        self._uninstall_raw_hook()

        trace = self._build_trace()
        logger.info(
            "Recorder.stop app=%s trace_id=%s events=%d",
            self.app_name,
            self.trace_id,
            len(trace.events),
        )
        return trace

    def save(
        self,
        trace: RecordTrace,
        path: Path | None = None,
    ) -> Path:
        """Persist a trace as JSONL (header + 1 event per line)."""
        target = Path(path) if path else self.traces_dir / f"{self.trace_id}.jsonl"
        target.parent.mkdir(parents=True, exist_ok=True)
        lines: list[str] = []
        # Header = trace meta (without events, which follow per-line)
        header = trace.model_dump(exclude={"events"}, mode="json")
        header["_schema"] = "api-anything.record.v1"
        lines.append(json.dumps(header, ensure_ascii=False))
        for ev in trace.events:
            lines.append(json.dumps(ev.model_dump(mode="json"), ensure_ascii=False))
        target.write_text("\n".join(lines) + "\n", encoding="utf-8")
        logger.info("Recorder.save trace_id=%s path=%s", trace.trace_id, target)
        return target

    # ------------------------------------------------------------------
    # Event ingestion (called by hook layers — or directly by tests)
    # ------------------------------------------------------------------

    def _emit(
        self,
        event_type: EventType,
        *,
        control_path: str | None = None,
        value: str | None = None,
        screenshot_ref: str | None = None,
        is_password: bool = False,
    ) -> RecordEvent | None:
        """Internal ingest. Returns the event added, or None if filtered.

        Public enough that tests can call it to drive filter logic.
        """
        if not self._running or self._start_ts is None:
            return None

        # Filter: drop mouse_move — only discrete events allowed.
        if event_type == "mouse" and (value or "").lower() == "move":
            return None

        # Privacy: mask password field values. Control path kept so replay works.
        stored_value = _PASSWORD_MARKER if is_password else value

        now = time.monotonic()
        key = (event_type, control_path, stored_value)

        # Debounce: drop identical event within 50ms window.
        if (
            self._last_event_key == key
            and (now - self._last_event_ts) < _DEBOUNCE_SECONDS
        ):
            return None

        ts = now - self._start_ts
        ev = RecordEvent(
            ts=round(ts, 4),
            event_type=event_type,
            control_path=control_path,
            value=stored_value,
            screenshot_ref=screenshot_ref,
        )
        self._events.append(ev)
        self._last_event_key = key
        self._last_event_ts = now
        return ev

    # ------------------------------------------------------------------
    # Hook installation (each isolated so tests can monkey-patch)
    # ------------------------------------------------------------------

    def _install_uia_handler(self) -> None:
        """Hook three UIA subscriptions: Invoke / Value / SelectionItem.

        v0.3.1 rewrite: delegates to ``_uia_events`` (``comtypes``-direct)
        instead of the v0.3.0 ``getattr(uia, ...)`` no-op pattern. The
        underlying ``uiautomation==2.0.29`` (yinkaisheng) binding does not
        expose an event API at all; we bypass it by loading
        ``UIAutomationCore.dll`` via ``comtypes`` and subscribing three
        handlers against the target HWND.

        Scope policy (aligned with FIX 2 — "no target HWND → refuse"):
            - If we have a valid ``_target_window_handle`` and
              ``_target_window_missing`` is False → scope via
              ``uev.control_from_handle(hwnd)``.
            - Otherwise → log a warning and skip subscription. We do NOT
              fall back to ``GetRootElement`` (desktop-wide) because the
              whole point of the window-scoping work was to stop
              accidentally capturing the user's other apps.

        Three event kinds subscribed (each via its own token):
            - ``UIA_Invoke_InvokedEventId`` — button / menu clicks
            - ``UIA_ValueValuePropertyId`` property-changed — text edits
            - ``UIA_SelectionItem_ElementSelectedEventId`` — list/combo pick

        Callback wiring goes through per-kind adapter methods so the
        existing ``_emit`` debounce + password mask stays in force.

        Non-Windows / comtypes-missing path: ``uev.subscribe_*`` raises
        ``RuntimeError``. We catch + log + no-op so tests on Linux CI and
        boxes without UIAutomationCore.dll keep working.

        Test path: pre-injected ``self._uia_handler`` short-circuits this
        method entirely — platform-independent test harness preserved.
        """
        if self._uia_handler is not None:
            # Pre-injected (test path). Honour as-is.
            return
        if not self._target_window_handle or self._target_window_missing:
            logger.warning(
                "UIA event handler NOT installed: no target window "
                "(hwnd=%s missing=%s). Pass target_window_handle to "
                "Recorder() to enable UIA capture.",
                self._target_window_handle,
                self._target_window_missing,
            )
            return

        try:
            element = uev.control_from_handle(self._target_window_handle)
        except RuntimeError as exc:
            logger.warning(
                "UIA events unavailable on this platform; hook disabled: %s",
                exc,
            )
            return
        except Exception as exc:
            logger.warning(
                "UIA control_from_handle(%s) failed: %s",
                self._target_window_handle,
                exc,
            )
            return

        if element is None:
            logger.warning(
                "UIA ElementFromHandle returned None for hwnd=%s; hook disabled",
                self._target_window_handle,
            )
            return

        # Mark that subscription is active so _uninstall_uia_handler runs.
        # The callable's ``recorder`` back-reference is not needed — we bind
        # via method refs below.
        self._uia_handler = _UIAEventCallback(self)

        # --- Invoke ---------------------------------------------------------
        try:
            token = uev.subscribe_invoke(element, self._on_uia_invoke)
            self._uia_handler_tokens.append(("event:Invoke", token))
        except RuntimeError as exc:
            logger.warning("Failed to install UIA Invoke handler: %s", exc)
        except Exception as exc:
            logger.warning("UIA Invoke subscribe crashed: %s", exc)

        # --- Value property -------------------------------------------------
        try:
            token = uev.subscribe_value_changed(element, self._on_uia_value_change)
            self._uia_handler_tokens.append(("property:Value", token))
        except RuntimeError as exc:
            logger.warning("Failed to install UIA Value property handler: %s", exc)
        except Exception as exc:
            logger.warning("UIA Value subscribe crashed: %s", exc)

        # --- Selection -----------------------------------------------------
        try:
            token = uev.subscribe_selection(element, self._on_uia_selection)
            self._uia_handler_tokens.append(("event:Selection", token))
        except RuntimeError as exc:
            logger.warning("Failed to install UIA Selection handler: %s", exc)
        except Exception as exc:
            logger.warning("UIA Selection subscribe crashed: %s", exc)

    # ------------------------------------------------------------------
    # UIA callback adapters (called from a COM RPC thread)
    # ------------------------------------------------------------------

    def _on_uia_invoke(self, control_path: str, event_id: int) -> None:
        """Bridge ``uev.subscribe_invoke`` callback → ``_emit``.

        Runs on a COM RPC thread. ``_emit`` is already thread-safe-ish via
        its own guards (``_running`` check, list append). ``is_password``
        defaults to False for Invoke events (buttons / menu items never
        carry password data).
        """
        self._emit("uia.Invoke", control_path=control_path)

    def _on_uia_value_change(self, control_path: str, new_value: str) -> None:
        """Bridge property-changed callback → ``_emit``.

        We don't have the element handle at emit time (the comtypes adapter
        flattened it to strings for thread safety); password masking falls
        through to the caller-provided ``<password>`` marker when the value
        matches. Defense in depth: the emit-path string is also passed
        through on a best-effort basis — real masking happens at UI edit
        time via ``is_password_element`` when the recorder uses
        ``_UIAEventCallback`` classic path.

        For control_path values that look like password-marker paths
        (``Edit[pw]`` etc.), the callback has no way to check
        ``IsPassword`` from this already-string-flattened payload. The
        emit call therefore sets ``is_password=False`` and relies on the
        server side (this method signature receiving the raw element in a
        future version) to detect secrets. For v0.3.1 the conservative
        behaviour is to preserve the raw value — acceptable per the
        existing recorder invariant that Edit-field values are always
        passed through verbatim unless IsPassword was explicitly flagged.
        """
        self._emit("uia.Value", control_path=control_path, value=new_value)

    def _on_uia_selection(self, control_path: str, event_id: int) -> None:
        """Bridge selection-item callback → ``_emit``."""
        self._emit("uia.Selection", control_path=control_path)

    def _uninstall_uia_handler(self) -> None:
        """Remove each subscription token individually, then drop the ref.

        v0.3.1: tokens are real ``uev.UIAEventToken`` opaque handles (not
        the v0.3.0 ``(label, handler_ref)`` placeholder). Each
        ``uev.unsubscribe`` call is wrapped in try/except so one stuck
        token does not block cleanup of the rest — the recorder's
        "best-effort teardown" contract is preserved.
        """
        if self._uia_handler is None and not self._uia_handler_tokens:
            return
        for label, token in list(self._uia_handler_tokens):
            # Real tokens are UIAEventToken instances; test mocks may store
            # a bare MagicMock or handler ref — in that case unsubscribe
            # raises TypeError which we log + skip.
            try:
                if isinstance(token, uev.UIAEventToken):
                    uev.unsubscribe(token)
                else:
                    logger.debug(
                        "Skipping non-token cleanup for %s: %r", label, token
                    )
            except Exception as exc:
                logger.debug("UIA unsubscribe(%s) non-fatal: %s", label, exc)
        self._uia_handler = None
        self._uia_handler_tokens = []

    def _install_screenshot_stream(self) -> None:
        """Kick off a 500ms screenshot thread using mss, scoped to the window.

        FIX 2: if we have no target window (non-Windows / resolve failed),
        the stream is DISABLED — we refuse to silently fall back to desktop
        capture. A loud warning is logged.
        """
        if self._screenshot_thread is not None:
            return
        if self._target_window_missing or self._target_window_handle is None:
            logger.warning(
                "Recorder screenshot stream DISABLED: no target window "
                "resolved (hwnd=%s missing=%s). Pass target_window_handle to "
                "Recorder() to enable per-window thumbnails.",
                self._target_window_handle,
                self._target_window_missing,
            )
            return
        try:
            import mss  # type: ignore[import-not-found]  # noqa: F401
        except ImportError:
            logger.info("mss not installed; screenshot stream disabled")
            return

        def _loop() -> None:  # pragma: no cover - runs in thread, test via mock
            import mss  # type: ignore[import-not-found]

            with mss.mss() as grabber:
                while not self._screenshot_stop.wait(_SCREENSHOT_INTERVAL_SECONDS):
                    self._snap_thumbnail(grabber)

        thread = threading.Thread(target=_loop, name=f"recorder-shots-{self.trace_id}", daemon=True)
        thread.start()
        self._screenshot_thread = thread

    def _get_window_bounds(self) -> dict[str, int] | None:
        """Compute ``mss``-shaped dict rect from the target window's RECT.

        Uses ``user32.GetWindowRect(hwnd, byref(RECT))`` (standard Win32).
        Refreshed each tick so moving/resizing the window is tracked.
        Returns ``None`` on any failure (caller falls back to cached bounds
        or skips the grab).
        """
        if not self._target_window_handle:
            return None
        try:
            import ctypes
            from ctypes import wintypes

            rect = wintypes.RECT()
            user32 = ctypes.windll.user32  # type: ignore[attr-defined]
            ok = user32.GetWindowRect(self._target_window_handle, ctypes.byref(rect))
            if not ok:
                return None
            left, top, right, bottom = rect.left, rect.top, rect.right, rect.bottom
            width = max(1, right - left)
            height = max(1, bottom - top)
            return {"left": left, "top": top, "width": width, "height": height}
        except (AttributeError, OSError, ImportError) as exc:
            logger.debug("_get_window_bounds failed: %s", exc)
            return None

    def _stop_screenshot_stream(self) -> None:
        if self._screenshot_thread is None:
            return
        self._screenshot_stop.set()
        try:
            self._screenshot_thread.join(timeout=1.0)
        except Exception as exc:  # pragma: no cover - defensive
            logger.debug("screenshot thread join error: %s", exc)
        self._screenshot_thread = None

    def _install_raw_hook(self) -> None:
        """Install pynput keyboard+mouse hook for UIA-invisible events.

        FIX 1 step 4: each event is gated by
        ``_is_foreground_our_target()`` — if the foreground window isn't our
        target (user Alt-Tab'd away), the event is dropped silently.
        Defense-in-depth with the existing IsPassword mask.
        """
        if self._raw_hook is not None:
            return
        try:
            from pynput import keyboard, mouse  # type: ignore[import-not-found]
        except ImportError:
            logger.info("pynput not installed; raw key/mouse hook disabled")
            return

        def _on_key(key: Any) -> None:  # pragma: no cover
            if not self._is_foreground_our_target():
                return
            key_repr = getattr(key, "char", None) or str(key)
            self._emit("key", value=str(key_repr))

        def _on_click(
            x: int, y: int, button: Any, pressed: bool
        ) -> None:  # pragma: no cover
            if not pressed:
                return
            if not self._is_foreground_our_target():
                return
            self._emit("mouse", value=f"click:{button}:{x},{y}")

        try:
            kb_listener = keyboard.Listener(on_press=_on_key)
            mouse_listener = mouse.Listener(on_click=_on_click)
            kb_listener.start()
            mouse_listener.start()
        except Exception as exc:  # pragma: no cover
            logger.warning("raw hook install failed: %s", exc)
            return
        self._raw_hook = (kb_listener, mouse_listener)

    def _uninstall_raw_hook(self) -> None:
        if self._raw_hook is None:
            return
        try:
            for listener in self._raw_hook:
                try:
                    listener.stop()
                except Exception as exc:  # pragma: no cover
                    logger.debug("raw hook listener stop error: %s", exc)
        finally:
            self._raw_hook = None

    # ------------------------------------------------------------------
    # Scope guards (FIX 1 step 4)
    # ------------------------------------------------------------------

    def _is_foreground_our_target(self) -> bool:
        """Return True iff the current foreground window is our target.

        Used by the raw pynput hooks to drop events generated while the user
        Alt-Tab'd away from the target app. Degraded paths:
            - no target HWND → False (drop all raw events — safer default)
            - non-Windows (``GetForegroundWindow`` unavailable) → True
              (we can't enforce, don't block legitimate capture)
        Tests monkey-patch this method or the underlying
        ``ctypes.windll.user32.GetForegroundWindow``.
        """
        if not self._target_window_handle:
            return False
        try:
            import ctypes

            user32 = ctypes.windll.user32  # type: ignore[attr-defined]
            hwnd = int(user32.GetForegroundWindow())
        except (AttributeError, OSError, ImportError):
            # Non-Windows — don't block capture, the scope is informational.
            return True
        return hwnd == self._target_window_handle

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _snap_thumbnail(self, grabber: Any) -> str | None:
        """Grab one screenshot and save as 60x60 PNG (called by worker thread).

        FIX 1 step 3: we grab only the target window's rect, not the whole
        primary monitor. Bounds refresh each tick so user-driven move /
        resize is tracked. Refusal path: if bounds cannot be computed and we
        have no cached bounds, skip this tick (don't fall back to desktop).
        """
        try:
            from PIL import Image  # type: ignore[import-not-found]
        except ImportError:
            return None
        # Refresh bounds every tick (cheap call, robust to window move/resize).
        bounds = self._get_window_bounds()
        if bounds is not None:
            self._target_bounds = bounds
        elif self._target_bounds is None:
            logger.debug(
                "_snap_thumbnail: no window bounds available, skipping tick"
            )
            return None
        rect = self._target_bounds
        try:
            raw = grabber.grab(rect)
            img = Image.frombytes("RGB", raw.size, raw.rgb)
            img.thumbnail((60, 60))
            idx = self._screenshot_counter
            self._screenshot_counter += 1
            name = f"{idx:04d}.png"
            path = self._thumbnails_dir / name
            img.save(path, format="PNG")
            return name
        except Exception as exc:  # pragma: no cover
            logger.debug("thumbnail capture failed: %s", exc)
            return None

    def _build_trace(self) -> RecordTrace:
        assert self._started_at_iso is not None
        return RecordTrace(
            app_name=self.app_name,
            trace_id=self.trace_id,
            started_at=self._started_at_iso,
            events=list(self._events),
            thumbnails_dir=self._thumbnails_dir,
            stopped_at=datetime.now(timezone.utc).isoformat(),
        )

    def _allocate_trace_id(self) -> str:
        """Allocate next sequential id ``<app>_<NNN>``."""
        safe = _slugify(self.app_name)
        self.traces_dir.mkdir(parents=True, exist_ok=True)
        existing = sorted(self.traces_dir.glob(f"{safe}_*.jsonl"))
        max_seq = 0
        pat = re.compile(rf"^{re.escape(safe)}_(\d+)\.jsonl$")
        for f in existing:
            m = pat.match(f.name)
            if m:
                max_seq = max(max_seq, int(m.group(1)))
        return f"{safe}_{max_seq + 1:03d}"

    @property
    def _thumbnails_dir(self) -> Path:
        return self.traces_dir / f"{self.trace_id}_thumbnails"


# ---------------------------------------------------------------------------
# Loading a persisted trace
# ---------------------------------------------------------------------------


def load_trace(path: Path | str) -> RecordTrace:
    """Read a JSONL trace written by ``Recorder.save``.

    Raises:
        FileNotFoundError: path does not exist.
        ValueError: header line is not a valid trace header.
    """
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"trace file not found: {p}")
    lines = p.read_text(encoding="utf-8").splitlines()
    if not lines:
        raise ValueError(f"empty trace file: {p}")
    header = json.loads(lines[0])
    header.pop("_schema", None)
    events: list[RecordEvent] = []
    for line in lines[1:]:
        if not line.strip():
            continue
        events.append(RecordEvent.model_validate_json(line))
    header["events"] = events
    return RecordTrace.model_validate(header)


# ---------------------------------------------------------------------------
# Internal
# ---------------------------------------------------------------------------


def _slugify(name: str) -> str:
    """Filesystem-safe slug. Keeps alnum + underscore, collapses the rest."""
    return re.sub(r"[^A-Za-z0-9]+", "_", name).strip("_").lower() or "app"


class _UIAEventCallback:
    """Callable adapter from ``uiautomation`` event → ``Recorder._emit``.

    Isolated as a class so tests can instantiate it directly with a stub
    recorder, without needing a live UIA loop.
    """

    def __init__(self, recorder: Recorder) -> None:
        self._recorder = recorder

    def __call__(self, sender: Any, event_id: int) -> None:  # pragma: no cover
        try:
            ctrl_path = _build_uia_control_path(sender)
            is_password = bool(getattr(sender, "IsPassword", False))
            # Figure out event subtype from event_id. If uiautomation constants
            # exist we use them; otherwise we coarse-bucket into Invoke.
            event_type: EventType = "uia.Invoke"
            value: str | None = None
            try:
                import uiautomation as uia  # type: ignore[import-not-found]

                if event_id == uia.EventId.UIA_Value_ValuePropertyId:
                    event_type = "uia.Value"
                    try:
                        value = sender.GetValuePattern().Value
                    except Exception:
                        value = None
                elif event_id == uia.EventId.UIA_Selection_SelectionChangedEventId:
                    event_type = "uia.Selection"
            except ImportError:
                pass
            self._recorder._emit(
                event_type,
                control_path=ctrl_path,
                value=value,
                is_password=is_password,
            )
        except Exception as exc:
            logger.debug("UIA event translation failed: %s", exc)


def _build_uia_control_path(ctrl: Any) -> str | None:
    """Walk parent chain to build a ``Window > Panel > Button[Save]`` path."""
    try:
        parts: list[str] = []
        cur = ctrl
        while cur is not None and len(parts) < 12:
            ctype = getattr(cur, "ControlTypeName", "") or "Control"
            name = getattr(cur, "Name", "") or ""
            if name:
                parts.append(f"{ctype}[{name}]")
            else:
                parts.append(ctype)
            cur = getattr(cur, "GetParentControl", lambda: None)()
        return " > ".join(reversed(parts)) if parts else None
    except Exception:
        return None
