"""Record-Replay replayer — RFC v0.3 M2 execution layer. ZERO LLM.

Given a ``RecordTrace`` (produced by :mod:`api_anything.recorder` and
annotated by :func:`api_anything.generator._generate_from_record` with
``value_is_param`` / ``param_name``), :class:`Replayer` walks the event
stream and replays each UIA / key / mouse event, substituting runtime
kwargs for events flagged as parameters.

Design tenets:
    * **No LLM at runtime.** Param substitution is pure dict lookup, not
      heuristic string matching.
    * **All UIA primitives hidden behind mockable methods.** Tests patch
      ``_invoke`` / ``_set_value`` / ``_send_key`` directly — they do not
      need a real ``uiautomation`` install.
    * **Missing platform libs raise :class:`RuntimeError` with an
      install hint.** Caller catches and falls back however it likes.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from .recorder import RecordEvent, RecordTrace, load_trace

logger = logging.getLogger(__name__)


_INSTALL_HINT = (
    "uiautomation is required for record-replay. "
    "pip install uiautomation"
)


class Replayer:
    """Replay a ``RecordTrace`` with runtime kwargs substituted into params.

    Example
    -------
    >>> trace = load_trace("trace.jsonl")
    >>> Replayer(trace).replay(path="/tmp/a.txt")

    Every UIA primitive is routed through ``self._invoke(...)`` /
    ``self._set_value(...)`` / ``self._send_key(...)`` which tests mock.
    Real implementations lazy-import ``uiautomation``.
    """

    def __init__(self, trace: RecordTrace) -> None:
        self.trace = trace

    # ------------------------------------------------------------------
    # Factory
    # ------------------------------------------------------------------

    @classmethod
    def from_file(cls, path: Path | str) -> Replayer:
        """Load a persisted JSONL trace and build a Replayer."""
        return cls(load_trace(path))

    # ------------------------------------------------------------------
    # Public replay entry
    # ------------------------------------------------------------------

    def replay(self, **params: Any) -> None:
        """Step through events, substituting ``params`` where annotated.

        Raises:
            KeyError: an event with ``value_is_param=True`` references a
                ``param_name`` not supplied in ``**params``.
        """
        missing = [
            ev.param_name
            for ev in self.trace.events
            if ev.value_is_param and ev.param_name and ev.param_name not in params
        ]
        if missing:
            raise KeyError(f"missing param(s) for replay: {sorted(set(missing))}")

        for ev in self.trace.events:
            try:
                self._dispatch(ev, params)
            except NotImplementedError:
                raise
            except Exception as exc:
                logger.warning(
                    "replay event failed: %s control=%s err=%s",
                    ev.event_type,
                    ev.control_path,
                    exc,
                )
                raise

    # ------------------------------------------------------------------
    # Dispatch
    # ------------------------------------------------------------------

    def _dispatch(self, ev: RecordEvent, params: dict[str, Any]) -> None:
        """Route one event to the right primitive."""
        logger.debug(
            "replay event ts=%.4f type=%s ctrl=%s",
            ev.ts,
            ev.event_type,
            ev.control_path,
        )
        if ev.event_type == "uia.Invoke":
            if not ev.control_path:
                return
            self._invoke(ev.control_path)
            return

        if ev.event_type == "uia.Value":
            if not ev.control_path:
                return
            value = self._resolve_value(ev, params)
            self._set_value(ev.control_path, value)
            return

        if ev.event_type == "uia.Selection":
            # Select events encode selection target in ``value``; treat as
            # SetValue for simple single-select drop-downs.
            if ev.control_path:
                value = self._resolve_value(ev, params)
                self._set_value(ev.control_path, value)
            return

        if ev.event_type == "key":
            if ev.value:
                self._send_key(ev.value)
            return

        if ev.event_type == "mouse":
            # Mouse events only carry a string descriptor (e.g. click:left:12,34).
            # Real click-by-coord is not a core method surface; log and skip.
            logger.debug("skipping raw mouse event: %s", ev.value)
            return

        logger.warning("unknown replay event type: %s", ev.event_type)

    @staticmethod
    def _resolve_value(ev: RecordEvent, params: dict[str, Any]) -> str:
        """Return runtime value for a ``uia.Value`` event, honoring params."""
        if ev.value_is_param and ev.param_name:
            return str(params[ev.param_name])
        return ev.value or ""

    # ------------------------------------------------------------------
    # UIA primitives — mockable; real impl lazy-imports uiautomation
    # ------------------------------------------------------------------

    def _invoke(self, control_path: str) -> None:
        """Invoke the control at ``control_path``."""
        ctrl = self._resolve_control(control_path)
        try:
            ctrl.GetInvokePattern().Invoke()
        except AttributeError:
            # Some controls only expose LegacyIAccessible → use default action.
            legacy = getattr(ctrl, "GetLegacyIAccessiblePattern", None)
            if legacy is not None:
                legacy().DoDefaultAction()
            else:
                raise

    def _set_value(self, control_path: str, value: str) -> None:
        """Set the value of the control at ``control_path``."""
        ctrl = self._resolve_control(control_path)
        ctrl.GetValuePattern().SetValue(value)

    def _send_key(self, key: str) -> None:
        """Send a raw keystroke (e.g. 'enter', 'a', 'Key.ctrl')."""
        try:
            import uiautomation as uia  # type: ignore[import-not-found]
        except ImportError as exc:
            raise RuntimeError(_INSTALL_HINT) from exc
        # uiautomation.SendKeys supports single char / literal string
        uia.SendKeys(key)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _resolve_control(self, control_path: str) -> Any:
        """Walk a ``Window[X] > Panel > Button[Save]`` path to the UIA control.

        Real implementation uses ``uiautomation``. Tests will typically patch
        this method or ``_invoke`` / ``_set_value`` directly.
        """
        try:
            import uiautomation as uia  # type: ignore[import-not-found]
        except ImportError as exc:
            raise RuntimeError(_INSTALL_HINT) from exc
        parts = [p.strip() for p in control_path.split(">")]
        cur: Any = uia.GetRootControl()
        for part in parts:
            ctrl_type, name = _parse_path_segment(part)
            finder = getattr(cur, f"{ctrl_type}Control", None)
            if finder is None:
                # Fallback: generic Control search by name.
                cur = cur.Control(searchDepth=2, Name=name or "")
            else:
                cur = finder(Name=name) if name else finder()
        return cur


def _parse_path_segment(segment: str) -> tuple[str, str]:
    """Split ``Button[Save]`` → (``"Button"``, ``"Save"``). Missing name → empty."""
    segment = segment.strip()
    if "[" in segment and segment.endswith("]"):
        ctype, _, rest = segment.partition("[")
        return ctype.strip(), rest[:-1]
    return segment, ""
