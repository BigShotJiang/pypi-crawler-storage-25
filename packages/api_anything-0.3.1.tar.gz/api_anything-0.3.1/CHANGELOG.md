# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.3.1] - 2026-04-17

### Added

- **Real UIA event subscription via `comtypes`-direct** (`src/api_anything/_uia_events.py`): bypasses `uiautomation==2.0.29`'s missing event API by talking to `UIAutomationCore.dll` directly. Exposes `subscribe_invoke` / `subscribe_value_changed` / `subscribe_selection` + token-based `unsubscribe`. Non-Windows graceful (raises on use, not on import).
- `_ensure_com_initialized()` per-thread CoInitializeEx so worker threads (asyncio `to_thread`, pynput hook, mss screenshot, Celery, uvicorn) can call UIA without hitting `CO_E_NOTINITIALIZED`.
- Integration test `tests/test_uia_events_smoke.py` launching real Notepad to prove Invoke + Value events fire (Windows-only, opt-in via `RUN_UIA_SMOKE=1`). Title regex now tolerant of nine locales (en / zh-TW / zh-CN / ko / es / fr / de / it / ja).
- PyPI metadata: `Operating System :: Microsoft :: Windows` classifier; `Issues` + `Changelog` URLs; expanded keywords (`windows`, `vision`, `record-replay`, `vlm`).

### Changed

- `recorder.py` `_install_uia_handler` now delegates to `_uia_events` instead of the previous `getattr(uia, …, None)` no-op fallback.
- `recorder.py` `_uninstall_uia_handler` iterates real `UIAEventToken` handles and calls `unsubscribe` per token; one stuck token no longer blocks cleanup of siblings.
- `recorder.py` without a target HWND now **refuses** to install UIA hooks (was: silently fell back to `GetRootControl`). Aligns with the v0.3.0 FIX 2 screenshot-scope policy.
- `unsubscribe()` now calls `Remove*EventHandler` BEFORE popping the token (matches module docstring invariant); pop runs in `finally` so stale entries don't leak on Remove errors.
- `is_password_element()` exception path flipped to `return True` (fail-safe-toward-redaction); only `element is None` returns `False`. Docstring + tests updated to match.

### Fixed

- Electron target path (M3 unblocker): Value property-change + SelectionItem events now actually reach `Recorder` callbacks instead of being silently dropped by the binding.
- `pyproject.toml` author email typo (`aiking9319319319` → `aiking931931`).
- README: stale v0.1-era hero section replaced with `## What's New in 0.3.0` (Vision + Record-Replay + UIA pattern dispatch + Windows-first disclosure); tests badge 204 → 689; wrong clone URL (`anthropics/api-anything`) fixed to `aiking931931/api-anything`; footer version stamp and alpha label updated.

### Removed

- `RFC_v0.2.md` + `RFC_v0.3_api_generation.md` from tracked repo (strategy documents live in `_AI_BRAIN/05_Planning/` instead — out of public-framework scope).

### Security / disclosure

- Worker-thread COM initialisation gap fixed BEFORE first public release to avoid shipping a footgun labelled "feature".
- Password-field fail-safe direction fixed to protect the user (redact on ambiguity) rather than the trace.

### Tests

- **725 passed + 3 skipped** (v0.2.1 baseline 484 → +241 net across M1 vision, M2 record-replay, post-merge hardening, comtypes spike, and red-team audit follow-ups).

## [0.3.0-prerelease] - withdrawn 2026-04-17

The `[0.3.0]` section below documented a snapshot that existed in the Pending
Publish Queue for ~4 hours before the pre-ship red team audit uncovered two
merge-blocker issues (strategy codename leak in tracked RFC files, author
email typo baked into PyPI metadata). The snapshot was never published to
PyPI. The 0.3.1 release above supersedes it. The entry is retained for
historical traceability.

## [0.3.0] - 2026-04-17

## [0.3.0] - 2026-04-17

### Added

- **v0.3 M0 — UIA pattern dispatch** (already landed in 0.2.1 preview): 22 pattern body templates in `uia_patterns.py` + pattern-aware `generator._render_method` branch (Value > Toggle > Invoke > ExpandCollapse > Selection > rest).
- **v0.3 M1 — Vision generator**: `vision_generator.py` (`VisionGenerator` + `VisionIntrospectionReport` + `_vision_to_pseudo_controls`) + `vlm_backends/` package (`ClaudeCUBackend` / `Qwen25VLBackend` / `OSAtlasBackend` + `VLMBackend` ABC) + Set-of-Marks prompting per RFC §D.3. Runtime zero-LLM guarantee upheld (bbox baked into `ControlSpec`).
- **v0.3 M2 — Record-Replay**: `recorder.py` (`Recorder` / `RecordEvent` / `RecordTrace` / `load_trace` — UIA `AutomationEventHandler` + `mss` screenshot stream + `pynput` raw hook, 50ms debounce, `IsPassword` masking, window-handle scoping) + `replay.py` (`Replayer` zero-LLM, `value_is_param` / `param_name` runtime substitution) + `cli record <app>` subcommand + `generate --from-trace <path>` flag.
- **v0.2.1 carryovers** (shipped inside 0.3.0 window): `cli_fallback` schemas for `audacity` / `kdenlive` / `krita`; `repl.py` migrated to `DisplayRouter`.
- **Top-level re-exports** in `src/api_anything/__init__.py`: `VisionGenerator`, `VisionIntrospectionReport`, `Recorder`, `RecordEvent`, `RecordTrace`, `load_trace`, `Replayer`, `ClaudeCUBackend`, `Qwen25VLBackend`, `OSAtlasBackend`, `VLMBackend`.
- `APIMethod.last_verified_at: str | None` — ISO-8601 UTC drift-detection hook (vision stamps per batch, replay inherits `trace.started_at`).
- `APIMethod.operation_mode` extended to `"vision" | "replay"` alongside the existing `"uia"` / `"uia_legacy"` / `"subprocess"` values.
- `APIMethod.record_trace_id` / `record_trace_path` fields.
- **+205 new tests** (M1 + M2 +170; red-team follow-up +35). Totals **654 → 689 passed + 2 skipped**.

### Changed

- `generate_api` signature: `record_trace` + `vision_candidates` added as keyword-only parameters; all existing consumers unaffected (defaults `None`).
- `generator._render_method` body dispatch order (RFC §B.3): **record_trace → vision → UIA** (record priority first; legacy UIA try/except fallback preserved).
- `GenerationResult` gains `record_trace_id` / `record_trace_path` / `last_verified_at`.

### Fixed (post-merge red-team pass — commit `0d74510`)

- **Recorder privacy scope (FATAL ×2)**: `Recorder(app_name, *, target_window_handle=None)` now scopes UIA subscription to `ControlFromHandle(hwnd)`, `mss.grab()` to `GetWindowRect(hwnd)`, and pynput raw hook drops events when `GetForegroundWindow() != target_hwnd`. Screenshot thread refuses to start without a target HWND.
- **UIA Value + Selection subscription (HIGH)**: `AddAutomationPropertyChangedEventHandler([ValueValueProperty])` + `UIA_SelectionItem_ElementSelectedEventId` subscribed in addition to `UIA_Invoke_InvokedEventId`; handlers tracked in `_uia_handler_tokens` and removed symmetrically on stop.
- **`record_trace_path` posix-safe + existence check (HIGH)**: generated API class emits `trace_path.as_posix()`; missing trace file → `FileNotFoundError` stub body pointing to `Recorder.save`.
- **`last_verified_at` wired end-to-end (HIGH)**: `_render_method` emits a `last_verified_at: <value or 'never'>` docstring line alongside `internal_mode` / `pattern_used` / `generation_confidence`.
- **`internal_mode` fallback per operation_mode (HIGH)**: 5-way dict mapping replaces the binary `subprocess`-or-`uia_legacy` fallback (vision methods no longer mislabelled UIA).
- **`ControlSpec.from_dict` / `VisionElement` bbox validation (MEDIUM)**: malformed bboxes silently degrade to `None` in `ControlSpec` (→ VLM re-grounding) and fail-fast in `VisionElement.__post_init__`.
- **End-to-end `exec()` smoke (LOW)**: `tests/test_generated_code_exec.py` `exec(compile(...))`s a generated module, monkey-patches runtime primitives, and asserts dispatch fires.

### Deferred to v0.3.1

- **M3 BaiduNetdisk Tier-4 testbed** — blocked on UIA binding upgrade and requires a user-present login; not shippable in 0.3.0.
- **Claude CU live smoke test** — paid Anthropic API call, requires explicit user authorization (MEMORY #50).
- **Local VLM (Qwen2.5-VL / OS-Atlas) live smoke test** — requires GPU.
- ~~**Recorder real-desktop `AutomationEventHandler` smoke test**~~ — resolved in v0.3.1 via comtypes-direct subscription (see [Unreleased]).

## [0.2.1] - 2026-04-17

### Added (v0.3 M1 — Vision)

- **`src/api_anything/vlm_backends/`** (new package, 893 LOC) — three adapters behind a `VLMBackend` ABC:
  - `claude_cu.py` — Anthropic Claude CU `computer_20251124` tool, beta header pinned, lazy `anthropic` import, zero live call in tests.
  - `qwen25_vl.py` — local Qwen2.5-VL-7B via HF transformers, lazy imports with `[vision-local]` install hint.
  - `os_atlas.py` — OS-Atlas-7B grounding primitive.
- **`src/api_anything/vision_generator.py`** (340 LOC) — generation-time `VisionGenerator` + `_vision_to_pseudo_controls` adapter. Set-of-Marks prompting per RFC §D.3.
- **`generator.py` vision pipeline** — `_VISION_BBOX_PREFIX` + `_parse_vision_bbox_from_control` + `_parse_vision_bbox_from_hint` + `_append_vision_body`. `_render_method` gains an `operation_mode == "vision"` branch that emits a `ControlSpec` literal with the bbox baked in. Runtime zero-LLM guarantee upheld (RFC §D.2 / §D.4).
- `APIMethod.last_verified_at: str | None` — ISO-8601 UTC drift-detection hook.
- 90 new tests (test_vlm_backends / test_vision_generator / test_generator_vision_dispatch).

### Added (v0.3 M2 — Record-Replay)

- **`src/api_anything/recorder.py`** (528 LOC) — three-layer event capture: UIA `AutomationEventHandler` primary, `mss` screenshot stream every 500ms secondary, `pynput` raw hook tertiary. 50ms debounce, `mouse.move` drop, `IsPassword` masking, JSONL persistence with sibling `<trace_id>_thumbnails/` dir.
- **`src/api_anything/replay.py`** (211 LOC) — zero-LLM `Replayer.from_file()` + `replay(**params)` with `value_is_param` / `param_name` annotations for runtime substitution.
- **`generator.py` record pipeline** — `_generate_from_record` + `_build_record_api_class` + `_infer_record_method_schema` + `_render_record_api_code`. Dispatch priority FIRST per RFC §B.3 (record > vision > UIA).
- `APIMethod.operation_mode` Literal extended to `"vision" | "replay"`; `record_trace_id` and `record_trace_path` fields added.
- `cli.py` — `record <app>` subcommand + `generate --from-trace <path>` flag.
- 80 new tests (test_recorder / test_replay / test_generator_record / test_cli_record).

### Changed

- `generate_api` signature: `record_trace` and `vision_candidates` added as keyword-only parameters; all existing consumers unaffected (defaults `None`).
- `_render_method` body dispatch: new `vision` + `replay` branches before the legacy `uia` branch.

### Post-merge hardening (commit `0d74510` — Opus red team review follow-up)

Red team Opus audit on the M1+M2 merge flagged 2 FATAL + 4 HIGH + 3 MEDIUM + 1 LOW findings. The following fixed in a single follow-up pass:

- **Recorder scoping (FATAL ×2)** — `recorder.py` reworked: `Recorder(app_name, *, target_window_handle=None)` new keyword; at `start()` the handle is captured via `GetForegroundWindow` (Windows only, gracefully degraded elsewhere). UIA subscription now rooted at `ControlFromHandle(hwnd)` instead of `GetRootControl()`; `mss.grab()` scoped to `GetWindowRect(hwnd)` not `monitors[0]`; pynput raw hook drops events when the foreground HWND ≠ target. Screenshot thread refuses to start without a target HWND (loud warning). Password mask retained as defense-in-depth.
- **UIA Value + Selection subscription (HIGH)** — `recorder.py` now subscribes `AddAutomationPropertyChangedEventHandler([ValueValueProperty])` + `UIA_SelectionItem_ElementSelectedEventId` in addition to `UIA_Invoke_InvokedEventId`. Handlers tracked in `_uia_handler_tokens` and removed symmetrically on stop.
- **`record_trace_path` posix-safe + existence check (HIGH)** — `_build_record_api_class` embeds `trace_path.as_posix()`; `_render_record_api_code` emits `FileNotFoundError` stub body pointing to `Recorder.save` when the trace file does not yet exist on disk.
- **`last_verified_at` wired (HIGH)** — replay methods inherit `trace.started_at`; vision methods stamp `datetime.now(UTC).isoformat()` per batch. `_render_method` emits a `last_verified_at: <value or 'never'>` docstring line alongside `internal_mode` / `pattern_used` / `generation_confidence`.
- **`internal_mode` fallback per operation_mode (HIGH)** — previous binary `subprocess`-or-`uia_legacy` fallback wrongly labeled vision methods as UIA. New dict mapping covers all four operation modes.
- **`ControlSpec.from_dict` / `VisionElement` bbox validation (MEDIUM)** — malformed bboxes (string / wrong length / non-iterable) silently become `None` in `ControlSpec` → caller falls through to VLM re-grounding instead of raising opaque `ValueError` at `_bbox_center` time. `VisionElement.__post_init__` fails fast at construction.
- **End-to-end `exec()` smoke (LOW)** — new `tests/test_generated_code_exec.py` actually `exec(compile(...))`s a generated module, instantiates the API class, monkey-patches the runtime primitives, and asserts the dispatch fires. First test confirming vision + replay paths work out of the box.

### Known limitation after hardening

- ~~**UIA binding completeness**~~ — resolved in v0.3.1 by talking to `UIAutomationCore.dll` directly via `comtypes`, bypassing `uiautomation==2.0.29`'s missing event API entirely. See [Unreleased] § Added.

### Test totals

- 484 → **689 passed** + 2 skipped (+205 tests: M1+M2 +170, red-team fixes +35).

## [0.2.1] - 2026-04-17

### Added

- **CLI fallback schemas** — `audacity` / `kdenlive` / `krita` YAML schemas land (previously Notepad-only). Each app gains three decorator-wired methods. (Commit `4228e8c` — v0.2.1 A)
- **REPL via DisplayRouter** — `repl.py` migrated off direct `rich.print` onto `DisplayRouter`, matching `cli` / `web` channel behaviour. (Commit `4228e8c` — v0.2.1 B)
- **UIA pattern dispatch (M0 of v0.3)** — `src/api_anything/uia_patterns.py` (665 LOC): 22 pattern body templates + dispatch. `generator._render_method` gains pattern-aware branch; legacy try/except fallback preserved so v0.2 A `@with_cli_fallback` decorators still decay safely. Priority: Value > Toggle > Invoke > ExpandCollapse > Selection > rest. First-line 9 patterns have real bodies; mid-tier 8 intermediate; 5 `NotImplementedError` stubs. (Commit `4228e8c` — v0.3 M0)
- **Vision runtime skeleton (prep for M1)** — `src/api_anything/vision_runtime.py`: execution-time helpers (`_locate_control` / `_click_at` / `_type_at` / `render_som_overlay` / `verify_state_change`). RFC §D.4 guarantee upheld — **zero LLM call at runtime** when bbox is present in the `ControlSpec`; VLM re-grounding only on bbox drift.
- `readme = "README.md"` field in `pyproject.toml` so the PyPI description renders properly when publish is eventually authorised.

### Changed

- `__version__` and `pyproject.toml` version bumped to `0.2.1`.

### Deferred to v0.3

- Vision generator (generation-time) module `vision_generator.py` + VLM backends (Claude CU / Qwen2.5-VL / OS-Atlas).
- Recorder / Replay modules + `cli record` subcommand.
- BaiduNetdisk Tier 4 testbed.

## [0.2.0] - 2026-04-17

### Added
- **CLI fallback support** — when UIA methods fail (Electron / blocked / timeout), decorated methods fall back to `cli_anything` invocation. Adds `src/api_anything/cli_fallback.py`, extends `generator.py` with fallback decorator (+170 LOC total), wires Notepad example decorators. (Commit `c33db45` — v0.2 A)
- **Tier detection extensions** — Electron fingerprinting (executable name blacklist / `.asar` probe / CEF dll probe), install-path detection (Windows `LOCALAPPDATA` scan / Unix `shutil.which`), enrichment fields on `TierResult`: `host_os`, `electron_suspected`, `runtime_probed`, `fallback_hint` (+329 LOC `tier_detect.py`). (Commit `849ef27` — v0.2 B)
- **DisplayRouter** — unified output dispatch across `cli` / `json` / `repl` / `web` channels with type-dispatch for `TierResult`, `CheckResult`, `APIClass`, `APIMethod`, `GenerationResult` (+582 LOC `display_router.py`). (Commit `69fc05e` — v0.2 C)
- **LLM-driven generate pipeline** — three-gate validation (syntax AST parse / structure check / safety blacklist), fallback-to-schema on validation failure, triggered by explicit flag / Tier ≥3A / confidence < 60 (+390 LOC `llm_generator.py`). (Commit `69fc05e` — v0.2 D)
- `GenerationResult.generation_mode` field plus validation metadata (`validation_passed`, `validation_errors`, `llm_confidence`). (v0.2 D)
- **Hero demo v2** — split-screen Notepad automation GIF replaces the Gradio UI tour as the top-of-README hero asset. (v0.2 A)

### Changed
- `cli._cmd_generate` now routes output through `DisplayRouter` instead of direct `rich.print` calls.
- `web._format_tier_report` now routes output through `DisplayRouter` for channel-consistent rendering.

### Deferred to v0.2.1
- `cli_fallback` YAML schemas for `audacity` / `kdenlive` / `krita` (Notepad-only shipped in v0.2.0).
- `repl.py` migration to `DisplayRouter` (CLI + web migrated; REPL pending).
- LLM vision bytes input (`vision_image: bytes | None`) — structural hook present, wiring deferred.

## [0.1.0] - 2026-04-15

### Added
- Initial public release. Auto-generate Python APIs from any software via UIA inspection + LLM-driven method synthesis.
- Tier detection (native UIA / WinRT / Electron / Web / CLI-only).
- Gradio web UI, REPL, CLI frontends.
- Notepad example end-to-end working.

[0.3.0]: https://github.com/aiking931931/api-anything/compare/v0.2.1...v0.3.0
[0.2.1]: https://github.com/aiking931931/api-anything/compare/v0.2.0...v0.2.1
[0.2.0]: https://github.com/aiking931931/api-anything/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/aiking931931/api-anything/releases/tag/v0.1.0
