"""Tests for api_anything.vision_generator (RFC v0.3 M1).

All tests use a fake backend — no real VLM call happens. The fake backend
follows the duck-type contract of
:class:`api_anything.vlm_backends.base.VLMBackend` without subclassing it,
to keep the test independent of the ABC layout.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock

import pytest

from api_anything.models import APIMethod, UIControl
from api_anything.vision_generator import (
    VisionGenerator,
    VisionIntrospectionReport,
    _dedupe_elements,
    _element_to_method_name,
    _iou,
    _vision_to_pseudo_controls,
)
from api_anything.vision_runtime import VisionElement


class _FakeBackend:
    """Duck-typed VLMBackend fake for unit tests."""

    def __init__(
        self,
        *,
        introspect_return: list[VisionElement] | None = None,
        locate_return: VisionElement | None = None,
        raise_on_introspect: Exception | None = None,
    ) -> None:
        self._introspect_return = introspect_return or []
        self._locate_return = locate_return
        self._raise_on_introspect = raise_on_introspect
        self.introspect_calls = 0
        self.locate_calls: list[tuple[bytes, str]] = []

    def introspect_window(
        self, screenshot: bytes, *, max_elements: int = 40
    ) -> list[VisionElement]:
        self.introspect_calls += 1
        if self._raise_on_introspect is not None:
            raise self._raise_on_introspect
        return list(self._introspect_return)

    def locate(self, screenshot: bytes, query: str) -> VisionElement | None:
        self.locate_calls.append((screenshot, query))
        return self._locate_return


@pytest.fixture
def png_bytes() -> bytes:
    # Minimal valid PNG — no need for real content, backend is mocked.
    return b"\x89PNG\r\n\x1a\n" + b"\x00" * 32


@pytest.fixture
def tmp_screenshots(tmp_path: Path, png_bytes: bytes) -> list[Path]:
    shots: list[Path] = []
    for i in range(3):
        p = tmp_path / f"shot_{i}.png"
        p.write_bytes(png_bytes)
        shots.append(p)
    return shots


# ---------------------------------------------------------------------------
# introspect
# ---------------------------------------------------------------------------


class TestIntrospect:
    def test_introspect_empty_returns_empty(self) -> None:
        backend = _FakeBackend()
        gen = VisionGenerator(backend)
        out = gen.introspect(screenshot_paths=[])
        assert out == []

    def test_introspect_none_paths(self) -> None:
        backend = _FakeBackend()
        gen = VisionGenerator(backend)
        out = gen.introspect(screenshot_paths=None)
        assert out == []

    def test_introspect_uses_each_path(self, tmp_screenshots) -> None:
        backend = _FakeBackend(
            introspect_return=[
                VisionElement(label="Save", bbox=(10, 10, 50, 30), confidence=0.9),
            ],
        )
        gen = VisionGenerator(backend)
        out = gen.introspect(screenshot_paths=tmp_screenshots)
        # 3 paths * 1 element each, but dedupe collapses identical bboxes
        assert len(out) == 1
        assert backend.introspect_calls == 3

    def test_introspect_report_captured(self, tmp_screenshots) -> None:
        backend = _FakeBackend(
            introspect_return=[VisionElement(label="a", bbox=(0, 0, 10, 10))],
        )
        gen = VisionGenerator(backend)
        gen.introspect(screenshot_paths=tmp_screenshots)
        assert isinstance(gen.last_report, VisionIntrospectionReport)
        assert gen.last_report.screenshots_used == 3
        assert gen.last_report.som_overlays_rendered == 3

    def test_introspect_skips_missing_paths(self, tmp_path, png_bytes) -> None:
        good = tmp_path / "good.png"
        good.write_bytes(png_bytes)
        bad = tmp_path / "nope.png"
        backend = _FakeBackend(
            introspect_return=[VisionElement(label="a", bbox=(0, 0, 5, 5))],
        )
        gen = VisionGenerator(backend)
        out = gen.introspect(screenshot_paths=[bad, good])
        assert len(out) == 1
        assert backend.introspect_calls == 1  # bad path skipped

    def test_introspect_swallows_backend_errors(self, tmp_screenshots) -> None:
        backend = _FakeBackend(raise_on_introspect=RuntimeError("VLM flaky"))
        gen = VisionGenerator(backend)
        out = gen.introspect(screenshot_paths=tmp_screenshots)
        assert out == []

    def test_introspect_propagates_import_error(
        self, tmp_screenshots
    ) -> None:
        """ImportError from backend must propagate (not swallowed) so the
        user learns to install extras."""
        backend = _FakeBackend(
            raise_on_introspect=ImportError("install [vision-local]"),
        )
        gen = VisionGenerator(backend)
        with pytest.raises(ImportError):
            gen.introspect(screenshot_paths=tmp_screenshots)

    def test_last_report_none_before_run(self) -> None:
        backend = _FakeBackend()
        gen = VisionGenerator(backend)
        assert gen.last_report is None


# ---------------------------------------------------------------------------
# verify_element
# ---------------------------------------------------------------------------


class TestVerifyElement:
    def test_verify_returns_true_when_iou_high(self) -> None:
        match = VisionElement(label="Save", bbox=(10, 10, 50, 30))
        backend = _FakeBackend(locate_return=match)
        gen = VisionGenerator(backend)
        target = VisionElement(label="Save", bbox=(10, 10, 50, 30))
        assert gen.verify_element(target, b"png") is True

    def test_verify_returns_false_when_backend_miss(self) -> None:
        backend = _FakeBackend(locate_return=None)
        gen = VisionGenerator(backend)
        target = VisionElement(label="X", bbox=(0, 0, 10, 10))
        assert gen.verify_element(target, b"png") is False

    def test_verify_returns_false_on_low_iou(self) -> None:
        backend = _FakeBackend(
            locate_return=VisionElement(label="Save", bbox=(100, 100, 110, 110))
        )
        gen = VisionGenerator(backend)
        target = VisionElement(label="Save", bbox=(0, 0, 10, 10))
        assert gen.verify_element(target, b"png") is False

    def test_verify_returns_false_on_exception(self) -> None:
        backend = MagicMock()
        backend.locate.side_effect = RuntimeError("boom")
        gen = VisionGenerator(backend)
        target = VisionElement(label="X", bbox=(0, 0, 10, 10))
        assert gen.verify_element(target, b"png") is False


# ---------------------------------------------------------------------------
# generate_methods
# ---------------------------------------------------------------------------


class TestGenerateMethods:
    def test_one_element_one_method(self) -> None:
        backend = _FakeBackend()
        gen = VisionGenerator(backend)
        elements = [VisionElement(label="Save", bbox=(10, 20, 30, 40), confidence=0.9)]
        methods = gen.generate_methods(elements, software_name="VSCode")
        assert len(methods) == 1
        m = methods[0]
        assert isinstance(m, APIMethod)
        assert m.name == "click_save"
        assert m.operation_mode == "vision"
        assert m.internal_mode == "vision"
        assert m.generation_confidence == 90

    def test_method_name_slugify(self) -> None:
        backend = _FakeBackend()
        gen = VisionGenerator(backend)
        elements = [VisionElement(label="Save As...", bbox=(0, 0, 10, 10))]
        methods = gen.generate_methods(elements, software_name="Notepad")
        assert methods[0].name == "click_save_as"

    def test_skip_duplicate_with_existing_uia(self) -> None:
        backend = _FakeBackend()
        gen = VisionGenerator(backend)
        elements = [
            VisionElement(label="Save", bbox=(0, 0, 10, 10)),
            VisionElement(label="Open", bbox=(20, 20, 30, 30)),
        ]
        existing = [UIControl(name="Save", control_type="Button")]
        methods = gen.generate_methods(
            elements, software_name="App", existing_controls=existing
        )
        assert len(methods) == 1
        assert methods[0].name == "click_open"

    def test_empty_label_fallback(self) -> None:
        backend = _FakeBackend()
        gen = VisionGenerator(backend)
        elements = [VisionElement(label="", bbox=(0, 0, 10, 10))]
        methods = gen.generate_methods(elements, software_name="App")
        assert methods[0].name.startswith("click_element")

    def test_confidence_clamped(self) -> None:
        backend = _FakeBackend()
        gen = VisionGenerator(backend)
        elements = [VisionElement(label="Save", bbox=(0, 0, 5, 5), confidence=1.5)]
        methods = gen.generate_methods(elements, software_name="App")
        assert methods[0].generation_confidence == 100

    def test_confidence_negative_clamped(self) -> None:
        backend = _FakeBackend()
        gen = VisionGenerator(backend)
        elements = [VisionElement(label="Save", bbox=(0, 0, 5, 5), confidence=-0.5)]
        methods = gen.generate_methods(elements, software_name="App")
        assert methods[0].generation_confidence == 0

    def test_duplicate_labels_disambiguated(self) -> None:
        backend = _FakeBackend()
        gen = VisionGenerator(backend)
        elements = [
            VisionElement(label="Save", bbox=(0, 0, 5, 5)),
            VisionElement(label="Save", bbox=(100, 100, 150, 150)),
        ]
        methods = gen.generate_methods(elements, software_name="App")
        names = [m.name for m in methods]
        assert len(set(names)) == 2

    def test_implementation_hint_has_bbox(self) -> None:
        backend = _FakeBackend()
        gen = VisionGenerator(backend)
        elements = [VisionElement(label="X", bbox=(1, 2, 3, 4), confidence=0.5)]
        methods = gen.generate_methods(elements, software_name="App")
        assert "bbox=(1,2,3,4)" in methods[0].implementation_hint


# ---------------------------------------------------------------------------
# _vision_to_pseudo_controls adapter
# ---------------------------------------------------------------------------


class TestVisionToPseudoControls:
    def test_one_element_one_control(self) -> None:
        elements = [VisionElement(label="Save", bbox=(10, 20, 30, 40))]
        controls = _vision_to_pseudo_controls(elements)
        assert len(controls) == 1
        c = controls[0]
        assert c.name == "Save"
        assert c.control_type == "VisionElement"
        assert c.parent_path == "vision-bbox:10,20,30,40"
        assert c.patterns == []

    def test_empty_list(self) -> None:
        assert _vision_to_pseudo_controls([]) == []

    def test_empty_label_fallback(self) -> None:
        elements = [VisionElement(label="", bbox=(0, 0, 5, 5))]
        controls = _vision_to_pseudo_controls(elements)
        assert controls[0].name.startswith("element_")


# ---------------------------------------------------------------------------
# Pure helpers
# ---------------------------------------------------------------------------


class TestPureHelpers:
    def test_element_to_method_name(self) -> None:
        assert _element_to_method_name("Save", 0) == "click_save"
        assert _element_to_method_name("Save As...", 0) == "click_save_as"
        assert _element_to_method_name("", 3) == "click_element_3"

    def test_iou_identical(self) -> None:
        a = (0, 0, 10, 10)
        assert _iou(a, a) == pytest.approx(1.0)

    def test_iou_disjoint(self) -> None:
        assert _iou((0, 0, 10, 10), (100, 100, 110, 110)) == 0.0

    def test_iou_partial(self) -> None:
        iou = _iou((0, 0, 10, 10), (5, 5, 15, 15))
        assert 0.1 < iou < 0.2

    def test_iou_zero_area(self) -> None:
        """Degenerate boxes must not divide by zero."""
        assert _iou((5, 5, 5, 5), (0, 0, 0, 0)) == 0.0

    def test_dedupe_removes_near_duplicates(self) -> None:
        a = VisionElement(label="a", bbox=(0, 0, 100, 100))
        b = VisionElement(label="b", bbox=(1, 1, 101, 101))  # near-identical
        c = VisionElement(label="c", bbox=(500, 500, 600, 600))
        kept = _dedupe_elements([a, b, c])
        assert len(kept) == 2

    def test_dedupe_preserves_order(self) -> None:
        a = VisionElement(label="a", bbox=(0, 0, 10, 10))
        b = VisionElement(label="b", bbox=(100, 0, 110, 10))
        kept = _dedupe_elements([a, b])
        assert [e.label for e in kept] == ["a", "b"]


# ---------------------------------------------------------------------------
# End-to-end VisionGenerator run through
# ---------------------------------------------------------------------------


class TestEndToEnd:
    def test_introspect_then_generate_methods(
        self, tmp_screenshots
    ) -> None:
        backend = _FakeBackend(
            introspect_return=[
                VisionElement(label="Save", bbox=(10, 10, 50, 30), confidence=0.9),
                VisionElement(label="Open", bbox=(60, 10, 100, 30), confidence=0.7),
            ],
        )
        gen = VisionGenerator(backend, software_name="App")
        elements = gen.introspect(screenshot_paths=tmp_screenshots[:1])
        methods = gen.generate_methods(elements, software_name="App")
        assert [m.name for m in methods] == ["click_save", "click_open"]
        assert all(m.operation_mode == "vision" for m in methods)
