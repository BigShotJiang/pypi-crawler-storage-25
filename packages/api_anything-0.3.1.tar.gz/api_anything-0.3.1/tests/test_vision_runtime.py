"""Tests for api_anything.vision_runtime — execution-time vision helpers.

All tests mock VLM / click / screenshot / PIL so no real I/O happens.
RFC v0.3 §D.6 compliance: vision runtime tests must be 100% mocked.
"""

from __future__ import annotations

import hashlib
from unittest.mock import MagicMock, patch

import pytest

from api_anything.vision_runtime import (
    ControlSpec,
    VisionElement,
    _bbox_center,
    _click_at,
    _locate_control,
    _type_at,
    render_som_overlay,
    verify_state_change,
)


class TestBboxCenter:
    def test_center_of_square(self) -> None:
        assert _bbox_center((0, 0, 10, 10)) == (5, 5)

    def test_center_of_rect(self) -> None:
        assert _bbox_center((10, 20, 30, 60)) == (20, 40)

    def test_degenerate_point(self) -> None:
        assert _bbox_center((5, 5, 5, 5)) == (5, 5)


class TestControlSpec:
    def test_from_dict_tuple_bbox(self) -> None:
        spec = ControlSpec.from_dict({"name": "Save", "bbox": (10, 20, 30, 40)})
        assert spec.name == "Save"
        assert spec.bbox == (10, 20, 30, 40)

    def test_from_dict_list_bbox_converted(self) -> None:
        spec = ControlSpec.from_dict({"name": "Open", "bbox": [1, 2, 3, 4]})
        assert spec.bbox == (1, 2, 3, 4)

    def test_from_dict_no_bbox(self) -> None:
        spec = ControlSpec.from_dict({"name": "File"})
        assert spec.bbox is None
        assert spec.fallback_selector == ""

    def test_from_dict_extra_fields_captured(self) -> None:
        spec = ControlSpec.from_dict(
            {"name": "X", "bbox": None, "control_type": "Button", "custom": "val"}
        )
        assert spec.extra == {"control_type": "Button", "custom": "val"}

    def test_from_dict_coerces_types(self) -> None:
        spec = ControlSpec.from_dict(
            {"name": 42, "element_id": "7", "confidence": "0.8"}
        )
        assert spec.name == "42"
        assert spec.element_id == 7
        assert spec.confidence == pytest.approx(0.8)

    # ------------------------------------------------------------------
    # FIX 7: bbox shape validation (Red-team MEDIUM)
    # ------------------------------------------------------------------

    def test_from_dict_rejects_string_bbox(self) -> None:
        """FIX 7: bbox as string → None (caller falls through to VLM path)."""
        spec = ControlSpec.from_dict({"name": "X", "bbox": "1,2,3,4"})
        assert spec.bbox is None

    def test_from_dict_rejects_short_bbox(self) -> None:
        """3-tuple bbox → None (not silently unpacked incorrectly)."""
        spec = ControlSpec.from_dict({"name": "X", "bbox": [1, 2, 3]})
        assert spec.bbox is None

    def test_from_dict_accepts_valid_four_tuple(self) -> None:
        """Normal path: 4-elem list → tuple of ints."""
        spec = ControlSpec.from_dict({"name": "X", "bbox": [1, 2, 3, 4]})
        assert spec.bbox == (1, 2, 3, 4)
        assert isinstance(spec.bbox, tuple)

    def test_from_dict_rejects_non_iterable_bbox(self) -> None:
        """bbox as int → None (caught by the TypeError branch)."""
        spec = ControlSpec.from_dict({"name": "X", "bbox": 42})
        assert spec.bbox is None

    def test_vision_element_validates_bbox_length(self) -> None:
        """FIX 7: VisionElement raises on short bbox at construction."""
        with pytest.raises(ValueError, match="4 elements"):
            VisionElement(label="x", bbox=(1, 2, 3))  # type: ignore[arg-type]

    def test_vision_element_validates_bbox_types(self) -> None:
        """Non-int coords caught at construction."""
        with pytest.raises(ValueError, match="4 ints"):
            VisionElement(label="x", bbox=("a", "b", "c", "d"))  # type: ignore[arg-type]


class TestLocateControl:
    def test_bbox_path_returns_center_zero_llm(self) -> None:
        """Path 1: bbox present → no VLM / screenshot call at all (RFC §D.2)."""
        spec = ControlSpec(name="Save", bbox=(100, 200, 300, 400))
        vlm = MagicMock()
        shot = MagicMock()
        result = _locate_control(spec, screenshot_fn=shot, vlm_client=vlm)
        assert result == (200, 300)
        vlm.locate.assert_not_called()
        shot.assert_not_called()

    def test_dict_spec_with_bbox(self) -> None:
        result = _locate_control({"name": "X", "bbox": (0, 0, 20, 20)})
        assert result == (10, 10)

    def test_dict_spec_with_list_bbox(self) -> None:
        result = _locate_control({"name": "X", "bbox": [10, 20, 30, 60]})
        assert result == (20, 40)

    def test_str_spec_without_vlm_raises(self) -> None:
        with pytest.raises(NotImplementedError, match="no bbox"):
            _locate_control("Save")

    def test_missing_bbox_no_vlm_raises(self) -> None:
        spec = ControlSpec(name="File")
        with pytest.raises(NotImplementedError):
            _locate_control(spec)

    def test_vlm_relocates_when_bbox_missing(self) -> None:
        """Path 2: bbox absent + VLM present → VLM re-grounds."""
        spec = ControlSpec(name="Save", fallback_selector="the Save button")
        screenshot = b"\x89PNG\r\n\x1a\n" + b"\x00" * 16
        vlm = MagicMock()
        vlm.locate.return_value = VisionElement(
            label="Save", bbox=(50, 60, 70, 80)
        )
        result = _locate_control(
            spec,
            screenshot_fn=lambda: screenshot,
            vlm_client=vlm,
        )
        assert result == (60, 70)
        vlm.locate.assert_called_once()
        args, _ = vlm.locate.call_args
        assert args[0] == screenshot
        assert args[1] == "the Save button"

    def test_vlm_falls_back_to_name_when_no_selector(self) -> None:
        spec = ControlSpec(name="Open")
        vlm = MagicMock()
        vlm.locate.return_value = VisionElement(label="Open", bbox=(0, 0, 4, 4))
        _locate_control(spec, screenshot_fn=lambda: b"x", vlm_client=vlm)
        args, _ = vlm.locate.call_args
        assert args[1] == "Open"

    def test_vlm_returns_none_raises_lookup(self) -> None:
        spec = ControlSpec(name="Ghost")
        vlm = MagicMock()
        vlm.locate.return_value = None
        with pytest.raises(LookupError, match="Ghost"):
            _locate_control(spec, screenshot_fn=lambda: b"x", vlm_client=vlm)

    def test_screenshot_fn_error_wrapped(self) -> None:
        spec = ControlSpec(name="Save")
        vlm = MagicMock()

        def bad_shot() -> bytes:
            raise OSError("screen grab failed")

        with pytest.raises(RuntimeError, match="screen grab failed"):
            _locate_control(spec, screenshot_fn=bad_shot, vlm_client=vlm)

    def test_rejects_invalid_spec_type(self) -> None:
        with pytest.raises(TypeError, match="control_spec"):
            _locate_control(42)  # type: ignore[arg-type]


class TestClickAt:
    def test_prefers_pywinauto(self) -> None:
        fake_mouse = MagicMock()
        fake_module = MagicMock(mouse=fake_mouse)
        with patch.dict(
            "sys.modules",
            {"pywinauto": fake_module, "pywinauto.mouse": fake_mouse},
        ):
            _click_at(100, 200)
        fake_mouse.click.assert_called_once_with(coords=(100, 200))

    def test_fallback_to_ctypes(self) -> None:
        """If pywinauto absent, user32 mouse_event gets called."""
        user32 = MagicMock()
        with (
            patch.dict("sys.modules", {"pywinauto": None}),
            patch("ctypes.windll") as windll,
        ):
            windll.user32 = user32
            _click_at(5, 7)
        user32.SetCursorPos.assert_called_once_with(5, 7)
        # Down + Up → two mouse_event calls
        assert user32.mouse_event.call_count == 2


class TestTypeAt:
    def test_click_then_send_keys(self) -> None:
        fake_mouse = MagicMock()
        fake_kb = MagicMock()
        with patch.dict(
            "sys.modules",
            {
                "pywinauto": MagicMock(mouse=fake_mouse, keyboard=MagicMock(send_keys=fake_kb)),
                "pywinauto.mouse": fake_mouse,
                "pywinauto.keyboard": MagicMock(send_keys=fake_kb),
            },
        ):
            _type_at(10, 20, "hello")
        fake_mouse.click.assert_called_once_with(coords=(10, 20))
        fake_kb.assert_called_once_with("hello", with_spaces=True)


class TestRenderSomOverlay:
    def test_missing_pillow_returns_input(self) -> None:
        """Pillow absent → returns image_bytes untouched (logger warns)."""
        with patch.dict("sys.modules", {"PIL": None}):
            out = render_som_overlay(b"original", [])
        assert out == b"original"

    def test_bad_image_returns_input(self) -> None:
        """Unparseable bytes → return original."""
        out = render_som_overlay(b"not-an-image", [])
        assert out == b"not-an-image"

    def test_round_trip_with_real_pil(self) -> None:
        """If Pillow is installed, overlay produces a valid PNG of >= orig size."""
        pytest.importorskip("PIL")
        from io import BytesIO

        from PIL import Image

        img = Image.new("RGB", (100, 80), color=(255, 255, 255))
        buf = BytesIO()
        img.save(buf, format="PNG")
        original = buf.getvalue()

        elements = [
            VisionElement(label="a", bbox=(10, 10, 30, 30), element_id=1),
            VisionElement(label="b", bbox=(40, 40, 60, 60), element_id=2),
        ]
        out = render_som_overlay(original, elements)
        # Output should still parse as PNG
        out_img = Image.open(BytesIO(out))
        assert out_img.size == (100, 80)
        assert out_img.mode in {"RGB", "RGBA"}
        # Pixel at element centre should no longer be pure white (red frame painted)
        cx, cy = 20, 10  # top-left corner of first box
        px = out_img.getpixel((cx, cy))
        # Either pure red frame or filled label bg — not white
        assert px != (255, 255, 255)


class TestVerifyStateChange:
    def test_detects_change(self) -> None:
        before = hashlib.sha256(b"before").hexdigest()
        assert verify_state_change(before, lambda: b"after") is True

    def test_detects_no_change(self) -> None:
        same = b"same-screen"
        hash_ = hashlib.sha256(same).hexdigest()
        assert verify_state_change(hash_, lambda: same) is False

    def test_screenshot_error_returns_false(self) -> None:
        def bad() -> bytes:
            raise RuntimeError("boom")

        assert verify_state_change("abc", bad) is False


class TestVisionElement:
    def test_default_fields(self) -> None:
        elem = VisionElement(label="Save", bbox=(0, 0, 10, 10))
        assert elem.element_id == 0
        assert elem.confidence == 0.0
        assert elem.notes == ""

    def test_all_fields(self) -> None:
        elem = VisionElement(
            label="Save", bbox=(0, 0, 10, 10),
            element_id=7, confidence=0.9, notes="top bar",
        )
        assert elem.element_id == 7
        assert elem.confidence == pytest.approx(0.9)
        assert elem.notes == "top bar"


def test_public_api() -> None:
    """__all__ explicitly lists the public surface — guard against drift."""
    import api_anything.vision_runtime as vr

    expected = {
        "ControlSpec", "VisionElement",
        "_bbox_center", "_click_at", "_locate_control", "_type_at",
        "render_som_overlay", "verify_state_change",
    }
    assert set(vr.__all__) == expected


def test_module_exports_expected_types() -> None:
    """Smoke check that M1 generator-side code can rely on these symbols."""
    import api_anything.vision_runtime as vr

    for sym in ("_locate_control", "_click_at", "_type_at", "ControlSpec", "VisionElement"):
        assert hasattr(vr, sym), f"missing {sym}"


