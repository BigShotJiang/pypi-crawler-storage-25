"""Tests for CLI record subcommand and generate --from-trace (RFC v0.3 M2).

All Recorder / Replayer interaction mocked; no real UI hook.
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

from api_anything.cli import _build_parser, main
from api_anything.recorder import RecordEvent, RecordTrace


def _sample_trace_file(tmp_path: Path) -> Path:
    """Write a minimal JSONL trace and return its path."""
    from api_anything.recorder import Recorder

    r = Recorder("notepad", traces_dir=tmp_path)
    r._uia_handler = MagicMock()
    r.start()
    r._emit("uia.Invoke", control_path="Win > B[OK]")
    trace = r.stop()
    return r.save(trace)


class TestParserRecord:
    def test_record_subparser_registered(self) -> None:
        parser = _build_parser()
        args = parser.parse_args(["record", "notepad"])
        assert args.command == "record"
        assert args.app_name == "notepad"

    def test_record_traces_dir_flag(self) -> None:
        parser = _build_parser()
        args = parser.parse_args(["record", "app", "--traces-dir", "/tmp/t"])
        assert args.traces_dir == "/tmp/t"

    def test_record_timeout_flag(self) -> None:
        parser = _build_parser()
        args = parser.parse_args(["record", "app", "--timeout", "5"])
        assert args.timeout == 5.0

    def test_generate_from_trace_flag(self) -> None:
        parser = _build_parser()
        args = parser.parse_args(["generate", "notepad", "--from-trace", "x.jsonl"])
        assert args.from_trace == "x.jsonl"


class TestRecordCommandExecution:
    def test_record_invokes_recorder_with_timeout(self, tmp_path: Path) -> None:
        """--timeout path: Recorder.start → sleep → Recorder.stop → save."""
        fake_recorder = MagicMock()
        fake_recorder.save.return_value = tmp_path / "out.jsonl"
        with (
            patch("api_anything.cli.Recorder", return_value=fake_recorder),
            patch("api_anything.cli._sleep"),
        ):
            rc = main(["record", "notepad", "--traces-dir", str(tmp_path),
                       "--timeout", "0.1"])
        assert rc == 0
        fake_recorder.start.assert_called_once()
        fake_recorder.stop.assert_called_once()
        fake_recorder.save.assert_called_once()

    def test_record_without_timeout_waits_for_hotkey(self, tmp_path: Path) -> None:
        fake_recorder = MagicMock()
        fake_recorder.save.return_value = tmp_path / "out.jsonl"
        with (
            patch("api_anything.cli.Recorder", return_value=fake_recorder),
            patch("api_anything.cli._wait_for_stop_hotkey") as mock_wait,
        ):
            rc = main(["record", "notepad"])
        assert rc == 0
        mock_wait.assert_called_once()

    def test_record_passes_traces_dir_to_recorder(self, tmp_path: Path) -> None:
        fake_recorder = MagicMock()
        fake_recorder.save.return_value = tmp_path / "o.jsonl"
        with (
            patch("api_anything.cli.Recorder") as mock_cls,
            patch("api_anything.cli._sleep"),
        ):
            mock_cls.return_value = fake_recorder
            main(["record", "mycoolapp", "--traces-dir", str(tmp_path),
                  "--timeout", "0.01"])
        _, kwargs = mock_cls.call_args
        assert kwargs["traces_dir"] == tmp_path


class TestGenerateFromTrace:
    def test_from_trace_dispatches_to_record_branch(self, tmp_path: Path) -> None:
        trace_path = _sample_trace_file(tmp_path)
        rc = main(["generate", "notepad", "--from-trace", str(trace_path)])
        assert rc == 0

    def test_from_trace_missing_file_returns_error(self, tmp_path: Path) -> None:
        rc = main(["generate", "notepad", "--from-trace", str(tmp_path / "nope.jsonl")])
        assert rc == 1

    def test_from_trace_json_output(self, tmp_path: Path, capsys) -> None:
        trace_path = _sample_trace_file(tmp_path)
        rc = main(["generate", "notepad", "--from-trace", str(trace_path), "--json"])
        captured = capsys.readouterr()
        assert rc == 0
        payload = json.loads(captured.out)
        assert payload["generation_mode"] == "record_replay"

    def test_from_trace_uses_generate_api(self, tmp_path: Path) -> None:
        """Verify generate_api is called with record_trace populated."""
        trace_path = _sample_trace_file(tmp_path)
        with patch("api_anything.cli.generate_api") as mock_gen:
            mock_gen.return_value = MagicMock(
                api_class=MagicMock(class_name="N", methods=[]),
                generation_mode="record_replay",
                model_dump_json=lambda **_: "{}",
            )
            rc = main(["generate", "notepad", "--from-trace", str(trace_path)])
        assert rc == 0
        _, kwargs = mock_gen.call_args
        assert kwargs["software_name"] == "notepad"
        assert isinstance(kwargs["record_trace"], RecordTrace)
        assert kwargs["record_trace"].events[0].control_path == "Win > B[OK]"


class TestGenerateLegacy:
    def test_generate_without_trace_still_works(self) -> None:
        rc = main(["generate", "notepad"])
        assert rc == 0

    def test_generate_without_trace_shows_stub(self, capsys) -> None:
        rc = main(["generate", "notepad", "--json"])
        assert rc == 0
        out = capsys.readouterr().out
        # v0.2 stub payload
        assert "not_implemented" in out or "Generate (stub)" in out


class TestSampleEventFixture:
    def test_sample_trace_round_trips(self, tmp_path: Path) -> None:
        p = _sample_trace_file(tmp_path)
        assert p.exists()

    def test_sample_trace_contains_one_event(self, tmp_path: Path) -> None:
        from api_anything.recorder import load_trace

        p = _sample_trace_file(tmp_path)
        trace = load_trace(p)
        assert len(trace.events) == 1
        assert isinstance(trace.events[0], RecordEvent)
