"""Tests for api_anything.vlm_backends (RFC v0.3 M1).

All tests are 100% mocked:
    * anthropic / transformers / torch / PIL are either patched via
      ``sys.modules`` or supplied through the backend's ``client`` /
      ``model`` / ``processor`` / ``tokenizer`` constructor kwargs.
    * No real network / GPU call happens.
"""

from __future__ import annotations

import os
from unittest.mock import MagicMock, patch

import pytest

from api_anything.vision_runtime import VisionElement
from api_anything.vlm_backends import (
    ClaudeCUBackend,
    OSAtlasBackend,
    Qwen25VLBackend,
    VLMBackend,
)
from api_anything.vlm_backends.base import VLMBackend as _VLMBackendImport
from api_anything.vlm_backends.claude_cu import (
    CLAUDE_CU_BETA_HEADER,
    CLAUDE_CU_TOOL_TYPE,
    _element_from_block,
    _elements_from_response,
)
from api_anything.vlm_backends.os_atlas import (
    _parse_normalized_point,
    _point_to_element,
)
from api_anything.vlm_backends.qwen25_vl import _parse_list, _parse_single

# ---------------------------------------------------------------------------
# Abstract base surface
# ---------------------------------------------------------------------------


class TestVLMBackendABC:
    def test_cannot_instantiate_abstract(self) -> None:
        with pytest.raises(TypeError):
            VLMBackend()  # type: ignore[abstract]

    def test_subclass_must_implement_locate(self) -> None:
        class Bad(VLMBackend):
            def introspect_window(self, screenshot, *, max_elements=40):  # type: ignore[override]
                return []
        with pytest.raises(TypeError):
            Bad()  # type: ignore[abstract]

    def test_minimal_subclass_works(self) -> None:
        class Good(VLMBackend):
            name = "good"

            def locate(self, screenshot, query):  # type: ignore[override]
                return VisionElement(label=query, bbox=(0, 0, 1, 1))

            def introspect_window(self, screenshot, *, max_elements=40):  # type: ignore[override]
                return []

        b = Good()
        assert b.check_credentials() is True
        assert b.locate(b"", "q").label == "q"
        assert b.introspect_window(b"") == []
        assert "Good" in repr(b)

    def test_symbol_reimport(self) -> None:
        """Guards against package re-export regressions."""
        assert VLMBackend is _VLMBackendImport


# ---------------------------------------------------------------------------
# Claude CU backend
# ---------------------------------------------------------------------------


class TestClaudeCUBackend:
    def test_pinned_constants(self) -> None:
        """Beta header / tool type pin must be visible at package level."""
        assert CLAUDE_CU_BETA_HEADER == "computer-use-2025-11-24"
        assert CLAUDE_CU_TOOL_TYPE == "computer_20251124"

    def test_check_credentials_with_env(self) -> None:
        with patch.dict(os.environ, {"ANTHROPIC_API_KEY": "sk-x"}):
            b = ClaudeCUBackend()
            assert b.check_credentials() is True

    def test_check_credentials_no_env_no_client(self) -> None:
        with patch.dict(os.environ, {"ANTHROPIC_API_KEY": ""}, clear=False):
            b = ClaudeCUBackend()
            assert b.check_credentials() is False

    def test_check_credentials_client_injected(self) -> None:
        with patch.dict(os.environ, {"ANTHROPIC_API_KEY": ""}, clear=False):
            b = ClaudeCUBackend(client=MagicMock())
            assert b.check_credentials() is True

    def test_locate_calls_mock_client(self) -> None:
        client = MagicMock()
        response = MagicMock()
        tool_block = MagicMock()
        tool_block.type = "tool_use"
        tool_block.input = {"box": [10, 20, 30, 40], "label": "Save"}
        response.content = [tool_block]
        client.messages.create.return_value = response

        b = ClaudeCUBackend(client=client)
        elem = b.locate(b"fake-png", "the save button")
        assert elem is not None
        assert elem.label == "Save"
        assert elem.bbox == (10, 20, 30, 40)
        client.messages.create.assert_called_once()
        kwargs = client.messages.create.call_args.kwargs
        assert kwargs["extra_headers"]["anthropic-beta"] == CLAUDE_CU_BETA_HEADER
        assert kwargs["tools"][0]["type"] == CLAUDE_CU_TOOL_TYPE

    def test_locate_with_coordinate_only_response(self) -> None:
        """CU ``coordinate`` action is mapped to a tiny click box."""
        client = MagicMock()
        response = MagicMock()
        block = MagicMock(type="tool_use", input={"action": "click", "coordinate": [100, 200]})
        response.content = [block]
        client.messages.create.return_value = response

        b = ClaudeCUBackend(client=client)
        elem = b.locate(b"png", "click Save")
        assert elem is not None
        assert elem.bbox[0] < 100 < elem.bbox[2]
        assert elem.bbox[1] < 200 < elem.bbox[3]

    def test_locate_returns_none_on_empty_content(self) -> None:
        client = MagicMock()
        resp = MagicMock(content=[])
        client.messages.create.return_value = resp
        b = ClaudeCUBackend(client=client)
        assert b.locate(b"png", "Save") is None

    def test_introspect_window_parses_list(self) -> None:
        client = MagicMock()
        text_block = MagicMock()
        text_block.type = "text"
        text_block.text = (
            '[{"label":"Save","bbox":[10,20,30,40],"confidence":0.9},'
            '{"label":"Open","bbox":[5,5,20,20],"confidence":0.8}]'
        )
        response = MagicMock(content=[text_block])
        client.messages.create.return_value = response

        b = ClaudeCUBackend(client=client)
        elements = b.introspect_window(b"png", max_elements=10)
        assert len(elements) == 2
        assert elements[0].label == "Save"
        assert elements[1].bbox == (5, 5, 20, 20)

    def test_introspect_window_respects_max_elements(self) -> None:
        client = MagicMock()
        text_block = MagicMock()
        text_block.type = "text"
        text_block.text = "[" + ",".join(
            f'{{"label":"e{i}","bbox":[{i},{i},{i+5},{i+5}]}}' for i in range(10)
        ) + "]"
        client.messages.create.return_value = MagicMock(content=[text_block])
        b = ClaudeCUBackend(client=client)
        elements = b.introspect_window(b"png", max_elements=3)
        assert len(elements) == 3

    def test_ensure_client_raises_when_sdk_missing(self) -> None:
        """Absent anthropic SDK → ImportError with install hint."""
        b = ClaudeCUBackend(client=None)
        with (
            patch.dict("sys.modules", {"anthropic": None}),
            pytest.raises(ImportError, match="api-anything"),
        ):
            b._ensure_client()

    def test_parse_tool_use_with_list_bbox(self) -> None:
        block = MagicMock(type="tool_use", input={"box": [1, 2, 3, 4]})
        elem = _element_from_block(block)
        assert elem is not None
        assert elem.bbox == (1, 2, 3, 4)

    def test_parse_block_without_box_returns_none(self) -> None:
        block = MagicMock(type="tool_use", input={"action": "wait"})
        assert _element_from_block(block) is None

    def test_parse_malformed_bbox_returns_none(self) -> None:
        block = MagicMock(type="tool_use", input={"box": ["a", "b", "c", "d"]})
        assert _element_from_block(block) is None

    def test_elements_from_empty_response(self) -> None:
        assert _elements_from_response(MagicMock(content=None)) == []


# ---------------------------------------------------------------------------
# Qwen25VLBackend (local)
# ---------------------------------------------------------------------------


class TestQwen25VLBackend:
    def test_import_does_not_require_torch(self) -> None:
        """Importing must not trigger torch / transformers loads."""
        # Module already imported at test top; confirm subclass construction
        # does not either.
        backend = Qwen25VLBackend(model=MagicMock(), processor=MagicMock())
        assert backend.name == "qwen25-vl"

    def test_check_credentials_always_true(self) -> None:
        assert Qwen25VLBackend(model=MagicMock(), processor=MagicMock()).check_credentials()

    def test_ensure_loaded_raises_when_transformers_missing(self) -> None:
        b = Qwen25VLBackend()
        with (
            patch.dict("sys.modules", {"transformers": None}),
            pytest.raises(ImportError, match="vision-local"),
        ):
            b._ensure_loaded()

    def test_locate_parses_model_output(self) -> None:
        mock_model = MagicMock()
        mock_proc = MagicMock()
        mock_proc.apply_chat_template.return_value = "prompt"
        mock_proc.return_value = {"input_ids": MagicMock()}
        mock_proc.batch_decode.return_value = [
            '{"label":"Save","bbox":[10,20,30,40],"confidence":0.7}'
        ]
        mock_model.generate.return_value = MagicMock()
        with patch.dict(
            "sys.modules",
            {
                "PIL": MagicMock(Image=MagicMock(
                    open=MagicMock(return_value=MagicMock(
                        convert=MagicMock(return_value="img"),
                    )),
                )),
                "PIL.Image": MagicMock(),
            },
        ):
            b = Qwen25VLBackend(model=mock_model, processor=mock_proc)
            elem = b.locate(b"png", "Save button")
        assert elem is not None
        assert elem.label == "Save"
        assert elem.bbox == (10, 20, 30, 40)

    def test_locate_returns_none_on_empty_json(self) -> None:
        mock_model = MagicMock()
        mock_proc = MagicMock()
        mock_proc.apply_chat_template.return_value = "prompt"
        mock_proc.batch_decode.return_value = ["{}"]
        with patch.dict(
            "sys.modules",
            {
                "PIL": MagicMock(Image=MagicMock(
                    open=MagicMock(return_value=MagicMock(
                        convert=MagicMock(return_value="img"),
                    )),
                )),
                "PIL.Image": MagicMock(),
            },
        ):
            b = Qwen25VLBackend(model=mock_model, processor=mock_proc)
            assert b.locate(b"png", "Save") is None

    def test_introspect_window_parses_list(self) -> None:
        mock_model = MagicMock()
        mock_proc = MagicMock()
        mock_proc.apply_chat_template.return_value = "prompt"
        mock_proc.batch_decode.return_value = [
            '[{"label":"Save","bbox":[1,2,3,4]},{"label":"Open","bbox":[5,6,7,8]}]'
        ]
        with patch.dict(
            "sys.modules",
            {
                "PIL": MagicMock(Image=MagicMock(
                    open=MagicMock(return_value=MagicMock(
                        convert=MagicMock(return_value="img"),
                    )),
                )),
                "PIL.Image": MagicMock(),
            },
        ):
            b = Qwen25VLBackend(model=mock_model, processor=mock_proc)
            elements = b.introspect_window(b"png", max_elements=5)
        assert len(elements) == 2


class TestQwenParsers:
    def test_parse_single_valid(self) -> None:
        r = _parse_single('{"label":"a","bbox":[1,2,3,4]}')
        assert r[0].label == "a"
        assert r[0].bbox == (1, 2, 3, 4)

    def test_parse_single_with_prose(self) -> None:
        r = _parse_single('here is the answer: {"label":"a","bbox":[1,2,3,4]} done.')
        assert r[0].bbox == (1, 2, 3, 4)

    def test_parse_single_empty(self) -> None:
        assert _parse_single("") == []
        assert _parse_single("no json") == []
        assert _parse_single("{}") == []

    def test_parse_list_valid(self) -> None:
        r = _parse_list('[{"label":"a","bbox":[1,2,3,4]}]')
        assert len(r) == 1

    def test_parse_list_malformed(self) -> None:
        assert _parse_list("not a list") == []
        assert _parse_list("[[[invalid]]]") == []

    def test_parse_list_skips_non_dict(self) -> None:
        r = _parse_list('["string", {"label":"x","bbox":[0,0,1,1]}]')
        assert len(r) == 1


# ---------------------------------------------------------------------------
# OSAtlasBackend
# ---------------------------------------------------------------------------


class TestOSAtlasBackend:
    def test_import_safe_without_torch(self) -> None:
        b = OSAtlasBackend(model=MagicMock(), tokenizer=MagicMock())
        assert b.name == "os-atlas"

    def test_ensure_loaded_raises_when_transformers_missing(self) -> None:
        b = OSAtlasBackend()
        with (
            patch.dict("sys.modules", {"transformers": None}),
            pytest.raises(ImportError, match="vision-local"),
        ):
            b._ensure_loaded()

    def test_locate_denormalizes_point(self) -> None:
        model = MagicMock()
        model.chat.return_value = ("(500, 500)", None)
        tok = MagicMock()
        b = OSAtlasBackend(
            model=model,
            tokenizer=tok,
            window_size=(1000, 1000),
        )
        elem = b.locate(b"png", "Save")
        assert elem is not None
        # 500/1000 * 1000 = 500 pixel center
        cx = (elem.bbox[0] + elem.bbox[2]) // 2
        cy = (elem.bbox[1] + elem.bbox[3]) // 2
        assert cx == 500
        assert cy == 500

    def test_locate_returns_none_on_unparseable(self) -> None:
        model = MagicMock()
        model.chat.return_value = ("no coordinates here", None)
        b = OSAtlasBackend(model=model, tokenizer=MagicMock())
        assert b.locate(b"png", "Save") is None

    def test_locate_handles_chat_exception(self) -> None:
        model = MagicMock()
        model.chat.side_effect = RuntimeError("GPU OOM")
        b = OSAtlasBackend(model=model, tokenizer=MagicMock())
        assert b.locate(b"png", "Save") is None

    def test_introspect_window_fans_out(self) -> None:
        model = MagicMock()
        # Return a point for every canned query
        model.chat.return_value = ("(100, 200)", None)
        b = OSAtlasBackend(
            model=model, tokenizer=MagicMock(), window_size=(1000, 1000)
        )
        elements = b.introspect_window(b"png", max_elements=3)
        assert len(elements) == 3

    def test_parse_point_parens(self) -> None:
        assert _parse_normalized_point("(100, 200)") == (100, 200)

    def test_parse_point_brackets(self) -> None:
        assert _parse_normalized_point("[100, 200]") == (100, 200)

    def test_parse_point_plain(self) -> None:
        assert _parse_normalized_point("100 200") == (100, 200)

    def test_parse_point_invalid(self) -> None:
        assert _parse_normalized_point("") is None
        assert _parse_normalized_point("nonsense") is None
        assert _parse_normalized_point("(abc, xyz)") is None

    def test_point_to_element(self) -> None:
        e = _point_to_element(
            (500, 500), label="Save", window_size=(1000, 1000), confidence=0.9
        )
        assert e.label == "Save"
        assert e.confidence == pytest.approx(0.9)
        cx = (e.bbox[0] + e.bbox[2]) // 2
        assert cx == 500
