"""Tests for api_anything._uia_events — comtypes-direct UIA event subscription.

All tests mock the underlying ``comtypes`` + ``UIAutomationClient`` module
so the suite runs identically on Windows and non-Windows CI.

The tests are split into three groups:

1. ``TestNonWindowsPath`` — ``_UIA = None``: every public call must
   ``raise RuntimeError``. Verifies the "import-safe, use-unsafe" policy.
2. ``TestSubscribe*`` — ``_UIA`` + ``_COMTYPES`` mocked; ``get_uia`` returns a
   stub. Exercises the COM call shape for each subscribe / unsubscribe path.
3. ``TestCallbackWrapping`` / ``TestTokenRegistry`` / ``TestHelpers`` — pure
   logic (handler factories, token allocation, variant unwrap, is_password).
"""

from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

from api_anything import _uia_events as uev

# ---------------------------------------------------------------------------
# Shared fakes
# ---------------------------------------------------------------------------


def _fake_uia_module() -> MagicMock:
    """Build a stand-in for ``comtypes.gen.UIAutomationClient`` with the
    constants and interface classes the wrapper expects.
    """
    fake = MagicMock(name="UIAutomationClient_fake")
    fake.UIA_Invoke_InvokedEventId = 20009
    fake.UIA_ValueValuePropertyId = 30045
    fake.UIA_SelectionItem_ElementSelectedEventId = 20012
    fake.UIA_IsPasswordPropertyId = 30019
    fake.TreeScope_Subtree = 7
    fake.CUIAutomation = MagicMock(name="CUIAutomation")
    fake.IUIAutomation = MagicMock(name="IUIAutomation")
    fake.IUIAutomationEventHandler = MagicMock(name="IUIAutomationEventHandler")
    fake.IUIAutomationPropertyChangedEventHandler = MagicMock(
        name="IUIAutomationPropertyChangedEventHandler"
    )
    return fake


@pytest.fixture
def mocked_uia(monkeypatch: pytest.MonkeyPatch) -> SimpleNamespace:
    """Install a fake UIA typelib module + comtypes into the wrapper.

    Also resets the singleton so each test gets a pristine IUIAutomation stub.
    """
    fake_mod = _fake_uia_module()

    fake_uia_instance = MagicMock(name="IUIAutomation_instance")

    fake_comtypes = MagicMock(name="comtypes")
    # Wrapper uses _COMTYPES.client.CreateObject and _COMTYPES.COMObject.
    fake_comtypes.client.CreateObject.return_value = fake_uia_instance

    class _StubCOMObject:
        """Stand-in for comtypes.COMObject so handler factories construct."""

        def __init__(self) -> None:
            pass

    fake_comtypes.COMObject = _StubCOMObject

    monkeypatch.setattr(uev, "_UIA", fake_mod)
    monkeypatch.setattr(uev, "_COMTYPES", fake_comtypes)
    monkeypatch.setattr(uev, "_IMPORT_ERROR", None)
    # Reset the singleton so get_uia() rebuilds against our fake_comtypes.
    monkeypatch.setattr(uev, "_uia_singleton", None)
    # Clear the token dict to avoid cross-test pollution.
    monkeypatch.setattr(uev, "_tokens", {})

    return SimpleNamespace(
        mod=fake_mod,
        comtypes=fake_comtypes,
        uia_instance=fake_uia_instance,
    )


# ---------------------------------------------------------------------------
# Non-Windows / missing-comtypes path
# ---------------------------------------------------------------------------


class TestNonWindowsPath:
    """With ``_UIA = None``, every public function must raise RuntimeError."""

    def test_get_uia_raises(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setattr(uev, "_UIA", None)
        monkeypatch.setattr(uev, "_COMTYPES", None)
        monkeypatch.setattr(uev, "_IMPORT_ERROR", "ImportError: not Windows")
        monkeypatch.setattr(uev, "_uia_singleton", None)
        with pytest.raises(RuntimeError, match="UIA events require Windows"):
            uev.get_uia()

    def test_error_message_mentions_extras_hint(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(uev, "_UIA", None)
        monkeypatch.setattr(uev, "_IMPORT_ERROR", "ImportError: foo")
        monkeypatch.setattr(uev, "_uia_singleton", None)
        with pytest.raises(RuntimeError) as ei:
            uev.get_uia()
        assert "api-anything[windows]" in str(ei.value)
        assert "ImportError: foo" in str(ei.value)

    def test_subscribe_raises(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setattr(uev, "_UIA", None)
        monkeypatch.setattr(uev, "_uia_singleton", None)
        with pytest.raises(RuntimeError):
            uev.subscribe_invoke(object(), lambda *_: None)
        with pytest.raises(RuntimeError):
            uev.subscribe_value_changed(object(), lambda *_: None)
        with pytest.raises(RuntimeError):
            uev.subscribe_selection(object(), lambda *_: None)

    def test_control_from_handle_raises(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(uev, "_UIA", None)
        monkeypatch.setattr(uev, "_uia_singleton", None)
        with pytest.raises(RuntimeError):
            uev.control_from_handle(0x1234)

    def test_control_from_handle_rejects_zero(
        self, monkeypatch: pytest.MonkeyPatch, mocked_uia: SimpleNamespace
    ) -> None:
        """Even on Windows, hwnd=0 is invalid → ValueError pre-check."""
        with pytest.raises(ValueError, match="non-zero"):
            uev.control_from_handle(0)

    def test_unsubscribe_all_safe_when_no_uia(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Bulk cleanup on non-Windows must NOT raise (caller may be in
        finally-clause wanting best-effort teardown)."""
        monkeypatch.setattr(uev, "_UIA", None)
        monkeypatch.setattr(uev, "_uia_singleton", None)
        uev.unsubscribe_all()  # no raise

    def test_is_password_element_fails_toward_redaction_on_none_uia(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Helper is called defensively from the recorder; must be no-raise.

        Fail-safe-toward-redaction (v0.3.1): with ``_UIA = None`` the second
        branch hits ``RuntimeError`` from ``_require_uia()`` → caller cannot
        determine password-ness → return ``True`` so the recorder redacts.
        The ``element is None`` short-circuit still returns ``False`` (tested
        separately) so the recorder's "no element available" path does not
        stamp every unparsed event as redacted.
        """
        monkeypatch.setattr(uev, "_UIA", None)
        monkeypatch.setattr(uev, "_uia_singleton", None)
        # Element with no CurrentIsPassword attr → second branch hits RuntimeError.
        element = MagicMock(spec=[])  # no attributes
        assert uev.is_password_element(element) is True


# ---------------------------------------------------------------------------
# Subscribe / unsubscribe happy path
# ---------------------------------------------------------------------------


class TestSubscribeInvoke:
    def test_happy_path_calls_addautomationeventhandler(
        self, mocked_uia: SimpleNamespace
    ) -> None:
        element = MagicMock(name="element")
        cb = MagicMock()
        token = uev.subscribe_invoke(element, cb)

        # AddAutomationEventHandler(event_id, element, scope, cache_req, handler)
        mocked_uia.uia_instance.AddAutomationEventHandler.assert_called_once()
        args, _kw = mocked_uia.uia_instance.AddAutomationEventHandler.call_args
        assert args[0] == 20009  # UIA_Invoke_InvokedEventId
        assert args[1] is element
        assert args[2] == 7  # TreeScope_Subtree
        assert args[3] is None  # cacheRequest
        # args[4] is the handler COMObject — can't identity-compare easily.
        assert isinstance(token, uev.UIAEventToken)

    def test_custom_tree_scope_honoured(self, mocked_uia: SimpleNamespace) -> None:
        element = MagicMock()
        uev.subscribe_invoke(element, lambda *_: None, tree_scope=4)
        args, _ = mocked_uia.uia_instance.AddAutomationEventHandler.call_args
        assert args[2] == 4

    def test_round_trip_subscribe_unsubscribe(
        self, mocked_uia: SimpleNamespace
    ) -> None:
        element = MagicMock()
        cb = MagicMock()
        token = uev.subscribe_invoke(element, cb)
        assert token._id in uev._tokens

        uev.unsubscribe(token)
        mocked_uia.uia_instance.RemoveAutomationEventHandler.assert_called_once()
        # Token evicted from registry.
        assert token._id not in uev._tokens

        # Unsubscribing the same token again is a no-op (idempotent).
        uev.unsubscribe(token)
        assert (
            mocked_uia.uia_instance.RemoveAutomationEventHandler.call_count == 1
        )


class TestSubscribeValue:
    def test_happy_path_calls_addpropertychangedeventhandler(
        self, mocked_uia: SimpleNamespace
    ) -> None:
        element = MagicMock()
        cb = MagicMock()
        token = uev.subscribe_value_changed(element, cb)

        mocked_uia.uia_instance.AddPropertyChangedEventHandler.assert_called_once()
        args, _ = mocked_uia.uia_instance.AddPropertyChangedEventHandler.call_args
        # Signature: (element, scope, cacheRequest, handler, propertyIds[])
        assert args[0] is element
        assert args[1] == 7  # TreeScope_Subtree
        assert args[2] is None  # cacheRequest
        # args[3] handler, args[4] property id list
        assert args[4] == [30045]
        assert isinstance(token, uev.UIAEventToken)

    def test_unsubscribe_removes_property_handler(
        self, mocked_uia: SimpleNamespace
    ) -> None:
        element = MagicMock()
        token = uev.subscribe_value_changed(element, lambda *_: None)
        uev.unsubscribe(token)
        remove = mocked_uia.uia_instance.RemovePropertyChangedEventHandler
        remove.assert_called_once()
        assert remove.call_args.args[0] is element
        # Second arg is the handler COMObject captured at subscribe time.
        assert remove.call_args.args[1] is not None


class TestSubscribeSelection:
    def test_happy_path_calls_add_automation_event_handler(
        self, mocked_uia: SimpleNamespace
    ) -> None:
        element = MagicMock()
        cb = MagicMock()
        token = uev.subscribe_selection(element, cb)
        mocked_uia.uia_instance.AddAutomationEventHandler.assert_called_once()
        args, _ = mocked_uia.uia_instance.AddAutomationEventHandler.call_args
        assert args[0] == 20012  # UIA_SelectionItem_ElementSelectedEventId
        assert args[1] is element
        assert isinstance(token, uev.UIAEventToken)


# ---------------------------------------------------------------------------
# Handler factory wrap (callbacks must not crash the COM thread)
# ---------------------------------------------------------------------------


class TestCallbackWrapping:
    def test_raising_callback_returns_s_ok_not_propagates(
        self, mocked_uia: SimpleNamespace
    ) -> None:
        def bad_callback(path: str, event_id: int) -> None:
            raise RuntimeError("boom")

        handler = uev._make_automation_handler(bad_callback, "Invoke")
        sender = SimpleNamespace(CurrentName="X", CurrentLocalizedControlType="Button")
        ret = handler.IUIAutomationEventHandler_HandleAutomationEvent(sender, 20009)
        assert ret == 0  # S_OK even though callback raised

    def test_property_callback_raising_returns_s_ok(
        self, mocked_uia: SimpleNamespace
    ) -> None:
        def bad(path: str, value: str) -> None:
            raise RuntimeError("boom")

        handler = uev._make_property_handler(bad)
        sender = SimpleNamespace(CurrentName="X", CurrentLocalizedControlType="Edit")
        ret = handler.IUIAutomationPropertyChangedEventHandler_HandlePropertyChangedEvent(
            sender, 30045, "hello"
        )
        assert ret == 0

    def test_good_callback_receives_control_path_and_event_id(
        self, mocked_uia: SimpleNamespace
    ) -> None:
        received: list[tuple[str, int]] = []
        handler = uev._make_automation_handler(
            lambda path, eid: received.append((path, eid)), "Invoke"
        )
        sender = SimpleNamespace(CurrentName="Save", CurrentLocalizedControlType="Button")
        ret = handler.IUIAutomationEventHandler_HandleAutomationEvent(sender, 20009)
        assert ret == 0
        assert received == [("Button[Save]", 20009)]

    def test_good_property_callback_receives_value_str(
        self, mocked_uia: SimpleNamespace
    ) -> None:
        received: list[tuple[str, str]] = []
        handler = uev._make_property_handler(
            lambda path, val: received.append((path, val))
        )
        sender = SimpleNamespace(CurrentName="Edit1", CurrentLocalizedControlType="Edit")
        handler.IUIAutomationPropertyChangedEventHandler_HandlePropertyChangedEvent(
            sender, 30045, "new text"
        )
        assert received == [("Edit[Edit1]", "new text")]


# ---------------------------------------------------------------------------
# Bulk cleanup
# ---------------------------------------------------------------------------


class TestUnsubscribeAll:
    def test_clears_token_dict(self, mocked_uia: SimpleNamespace) -> None:
        uev.subscribe_invoke(MagicMock(), lambda *_: None)
        uev.subscribe_selection(MagicMock(), lambda *_: None)
        assert len(uev._tokens) == 2

        uev.unsubscribe_all()
        assert uev._tokens == {}
        mocked_uia.uia_instance.RemoveAllEventHandlers.assert_called_once()

    def test_swallows_com_error(self, mocked_uia: SimpleNamespace) -> None:
        mocked_uia.uia_instance.RemoveAllEventHandlers.side_effect = RuntimeError(
            "COM died"
        )
        uev.subscribe_invoke(MagicMock(), lambda *_: None)
        uev.unsubscribe_all()  # must not raise
        assert uev._tokens == {}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class TestControlPathBuilder:
    def test_with_name(self) -> None:
        el = SimpleNamespace(CurrentName="Save", CurrentLocalizedControlType="Button")
        assert uev._safe_control_path(el) == "Button[Save]"

    def test_without_name(self) -> None:
        el = SimpleNamespace(CurrentName="", CurrentLocalizedControlType="Pane")
        assert uev._safe_control_path(el) == "Pane"

    def test_none_element(self) -> None:
        assert uev._safe_control_path(None) == "<null>"

    def test_attribute_error_returns_placeholder(self) -> None:
        bad = MagicMock()
        bad.CurrentName = property(  # trigger exception on access
            lambda self: (_ for _ in ()).throw(RuntimeError("fail"))
        )
        # MagicMock defaults to permissive — force a raise via PropertyMock.
        del bad.CurrentName
        type(bad).CurrentName = property(
            lambda self: (_ for _ in ()).throw(RuntimeError("fail"))
        )
        result = uev._safe_control_path(bad)
        assert result in ("<unknown>", "Control", "Control[]")


class TestVariantToStr:
    def test_none(self) -> None:
        assert uev._variant_to_str(None) == ""

    def test_str_passthrough(self) -> None:
        assert uev._variant_to_str("hello") == "hello"

    def test_int_coerced(self) -> None:
        assert uev._variant_to_str(42) == "42"

    def test_object_with_value(self) -> None:
        class Fake:
            value = "wrapped"

        assert uev._variant_to_str(Fake()) == "wrapped"


class TestIsPasswordElement:
    def test_true_on_direct_attr(self, mocked_uia: SimpleNamespace) -> None:
        element = SimpleNamespace(CurrentIsPassword=True)
        assert uev.is_password_element(element) is True

    def test_false_on_direct_attr(self, mocked_uia: SimpleNamespace) -> None:
        element = SimpleNamespace(CurrentIsPassword=False)
        assert uev.is_password_element(element) is False

    def test_none_element(self, mocked_uia: SimpleNamespace) -> None:
        assert uev.is_password_element(None) is False

    def test_is_password_element_fails_toward_redaction(
        self, mocked_uia: SimpleNamespace
    ) -> None:
        """Fail-safe-toward-redaction per module docstring (v0.3.1).

        Any comtypes / attribute error on the fallback branch means we
        cannot determine password-ness — return ``True`` so the caller
        redacts. Previous behaviour (``False``) leaked passwords into
        traces whenever COM hiccuped.
        """
        element = MagicMock(spec=["GetCurrentPropertyValue"])
        # No CurrentIsPassword → first branch skips; GetCurrentPropertyValue raises.
        element.GetCurrentPropertyValue.side_effect = RuntimeError("COM error")
        assert uev.is_password_element(element) is True

    def test_is_password_element_com_error_returns_true(
        self, mocked_uia: SimpleNamespace
    ) -> None:
        """Simulate the real COMError path — comtypes raises ``OSError``
        / ``COMError`` (``OSError`` subclass) on a genuine COM HRESULT.
        """

        class _COMLikeError(OSError):
            pass

        element = MagicMock(spec=["GetCurrentPropertyValue"])
        element.GetCurrentPropertyValue.side_effect = _COMLikeError(
            -2147467259, "Unspecified error"
        )
        assert uev.is_password_element(element) is True

    def test_is_password_element_none_returns_false(
        self, mocked_uia: SimpleNamespace
    ) -> None:
        """``element is None`` is the single documented exception to
        fail-safe-toward-redaction: a missing element cannot be a
        password field; returning ``True`` here would make the recorder
        redact every unparsed event.
        """
        assert uev.is_password_element(None) is False

    def test_falls_back_to_getcurrentpropertyvalue(
        self, mocked_uia: SimpleNamespace
    ) -> None:
        element = MagicMock(spec=["GetCurrentPropertyValue"])
        element.GetCurrentPropertyValue.return_value = True
        assert uev.is_password_element(element) is True
        element.GetCurrentPropertyValue.assert_called_once_with(30019)


class TestTokenRegistry:
    def test_alloc_unique_ids(self, mocked_uia: SimpleNamespace) -> None:
        # Ensure each token has a distinct id.
        element = MagicMock()
        t1 = uev.subscribe_invoke(element, lambda *_: None)
        t2 = uev.subscribe_invoke(element, lambda *_: None)
        assert t1._id != t2._id

    def test_singleton_caches(self, mocked_uia: SimpleNamespace) -> None:
        a = uev.get_uia()
        b = uev.get_uia()
        assert a is b
        # CreateObject called exactly once despite two get_uia() calls.
        assert mocked_uia.comtypes.client.CreateObject.call_count == 1

    def test_unsubscribe_unknown_token_noop(
        self, mocked_uia: SimpleNamespace
    ) -> None:
        # Token with id never registered → must not raise.
        uev.unsubscribe(uev.UIAEventToken(999999))


# ---------------------------------------------------------------------------
# Reference-counting order (v0.3.1 red-team FIX 2)
# ---------------------------------------------------------------------------


class TestUnsubscribeOrdering:
    """The docstring invariant: ``Remove*EventHandler`` runs BEFORE the
    token is popped from ``_tokens`` so the handler ``COMObject``
    retains its strong Python reference for the full RPC roundtrip.
    Pop runs in ``finally`` so Remove* exceptions still evict the entry.
    """

    def test_unsubscribe_pops_after_remove(
        self, mocked_uia: SimpleNamespace
    ) -> None:
        """During the Remove* call the entry MUST still be in ``_tokens``."""
        element = MagicMock(name="element")
        token = uev.subscribe_invoke(element, lambda *_: None)
        token_id = token._id
        assert token_id in uev._tokens  # precondition

        observed_during_remove: dict[str, bool] = {}

        def _spy_remove(*_args: object, **_kw: object) -> None:
            observed_during_remove["still_present"] = token_id in uev._tokens

        mocked_uia.uia_instance.RemoveAutomationEventHandler.side_effect = (
            _spy_remove
        )
        uev.unsubscribe(token)

        # During the Remove* call the entry was still present.
        assert observed_during_remove["still_present"] is True
        # After the call it has been evicted.
        assert token_id not in uev._tokens

    def test_unsubscribe_pops_even_if_remove_raises(
        self, mocked_uia: SimpleNamespace
    ) -> None:
        """Remove* error MUST NOT leak the token — pop runs in ``finally``."""
        element = MagicMock()
        token = uev.subscribe_invoke(element, lambda *_: None)
        assert token._id in uev._tokens

        mocked_uia.uia_instance.RemoveAutomationEventHandler.side_effect = (
            RuntimeError("COM said no")
        )
        uev.unsubscribe(token)  # must not raise (error is logged + swallowed)
        assert token._id not in uev._tokens

    def test_unsubscribe_property_pops_after_remove(
        self, mocked_uia: SimpleNamespace
    ) -> None:
        """Same invariant on the property-changed branch."""
        element = MagicMock()
        token = uev.subscribe_value_changed(element, lambda *_: None)
        token_id = token._id
        observed: dict[str, bool] = {}

        def _spy(*_args: object, **_kw: object) -> None:
            observed["still_present"] = token_id in uev._tokens

        mocked_uia.uia_instance.RemovePropertyChangedEventHandler.side_effect = _spy
        uev.unsubscribe(token)
        assert observed["still_present"] is True
        assert token_id not in uev._tokens


# ---------------------------------------------------------------------------
# Per-thread CoInitialize (v0.3.1 red-team FIX 1)
# ---------------------------------------------------------------------------


class TestCoInitialize:
    """Worker threads spawned by the Recorder / pynput / mss / user-code
    (``asyncio.to_thread``, celery, uvicorn) do NOT inherit the import-time
    ``CoInitialize`` and must not hit ``CO_E_NOTINITIALIZED``
    (``WinError -2147221008``) on their first UIA call.
    """

    @pytest.fixture(autouse=True)
    def _reset_com_state(self, monkeypatch: pytest.MonkeyPatch) -> None:
        # Ensure each test starts with no "already initialised" thread ids.
        monkeypatch.setattr(uev, "_com_inited_threads", set())

    def test_get_uia_from_worker_thread_does_not_raise(
        self, mocked_uia: SimpleNamespace
    ) -> None:
        import threading

        errors: list[BaseException] = []

        def _worker() -> None:
            try:
                uev.get_uia()
            except BaseException as exc:
                errors.append(exc)

        t = threading.Thread(target=_worker)
        t.start()
        t.join(timeout=5)
        assert not t.is_alive()
        assert errors == []

    def test_subscribe_from_worker_thread(
        self, mocked_uia: SimpleNamespace
    ) -> None:
        import threading

        errors: list[BaseException] = []

        def _worker() -> None:
            try:
                uev.subscribe_invoke(MagicMock(), lambda *_: None)
            except BaseException as exc:
                errors.append(exc)

        t = threading.Thread(target=_worker)
        t.start()
        t.join(timeout=5)
        assert not t.is_alive()
        assert errors == []

    def test_coinitialize_idempotent_same_thread(
        self, mocked_uia: SimpleNamespace
    ) -> None:
        """Calling ``_ensure_com_initialized`` 3x on the same thread must
        invoke the real ``CoInitialize`` exactly once.
        """
        uev._ensure_com_initialized()
        uev._ensure_com_initialized()
        uev._ensure_com_initialized()
        assert mocked_uia.comtypes.CoInitialize.call_count == 1

    def test_non_windows_skips_coinitialize(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """With ``_UIA = None`` the helper is a no-op — comtypes is not
        available on non-Windows and the public API raises RuntimeError
        before any COM work anyway.
        """
        monkeypatch.setattr(uev, "_UIA", None)
        # _COMTYPES may or may not be None; the guard is on _UIA.
        stub_comtypes = MagicMock(name="comtypes_stub")
        monkeypatch.setattr(uev, "_COMTYPES", stub_comtypes)
        uev._ensure_com_initialized()  # must not raise
        stub_comtypes.CoInitialize.assert_not_called()

    def test_ensure_tracks_thread_id_across_threads(
        self, mocked_uia: SimpleNamespace
    ) -> None:
        """Two different threads both initialise once each — the set
        grows to size 2, not 1.
        """
        import threading

        def _worker() -> None:
            uev._ensure_com_initialized()

        uev._ensure_com_initialized()  # main thread
        t = threading.Thread(target=_worker)
        t.start()
        t.join(timeout=5)
        # main thread + worker thread both registered.
        assert len(uev._com_inited_threads) == 2
        # CoInitialize called exactly twice (once per thread).
        assert mocked_uia.comtypes.CoInitialize.call_count == 2

    def test_ensure_swallows_coinitialize_oserror(
        self, mocked_uia: SimpleNamespace
    ) -> None:
        """``RPC_E_CHANGED_MODE`` or ``S_FALSE`` manifest as ``OSError``
        from ``comtypes.CoInitialize``. Both are survivable — we mark the
        thread as initialised and move on.
        """
        mocked_uia.comtypes.CoInitialize.side_effect = OSError(
            -2147417850, "RPC_E_CHANGED_MODE"
        )
        uev._ensure_com_initialized()  # must not raise
        import threading as _t

        assert _t.get_ident() in uev._com_inited_threads


# ---------------------------------------------------------------------------
# Recorder integration smoke (non-Windows safe)
# ---------------------------------------------------------------------------


class TestRecorderIntegrationSmoke:
    """Verify the recorder import is still OK + uses the module-level alias."""

    def test_recorder_imports_uev(self) -> None:
        from api_anything import recorder as rec

        assert hasattr(rec, "uev")
        # And the public API points at the same object.
        assert rec.uev is uev

    def test_no_subscribe_when_uia_raises(self) -> None:
        """If subscribe_* raises RuntimeError, recorder logs + moves on."""
        from api_anything.recorder import Recorder

        r = Recorder("test", target_window_handle=0xAAAA)
        with (
            patch("api_anything.recorder.uev.control_from_handle",
                  side_effect=RuntimeError("no windows")),
        ):
            r._install_uia_handler()
        assert r._uia_handler is None
        assert r._uia_handler_tokens == []
