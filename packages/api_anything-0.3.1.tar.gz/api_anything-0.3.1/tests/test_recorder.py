"""Tests for api_anything.recorder — record-replay capture layer (RFC v0.3 M2).

All platform hooks (uiautomation / mss / pynput / PIL) are mocked; no real
UIA subscription, screen grab, or keystroke hook is installed.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from api_anything.recorder import (
    Recorder,
    RecordEvent,
    RecordTrace,
    _build_uia_control_path,
    _slugify,
    _UIAEventCallback,
    load_trace,
)


class TestRecordEventModel:
    def test_valid_event_ok(self) -> None:
        ev = RecordEvent(
            ts=0.1,
            event_type="uia.Invoke",
            control_path="Window[Notepad] > Button[Save]",
        )
        assert ev.event_type == "uia.Invoke"
        assert ev.value_is_param is False

    def test_invalid_event_type_rejected(self) -> None:
        from pydantic import ValidationError

        with pytest.raises(ValidationError):
            RecordEvent(ts=0.0, event_type="uia.Bogus")  # type: ignore[arg-type]

    def test_param_annotation_fields_default_false(self) -> None:
        ev = RecordEvent(ts=0.0, event_type="uia.Value", value="x")
        assert ev.value_is_param is False
        assert ev.param_name is None


class TestSlugify:
    def test_spaces_to_underscore(self) -> None:
        assert _slugify("My Cool App") == "my_cool_app"

    def test_empty_fallback(self) -> None:
        assert _slugify("!!!") == "app"

    def test_cjk_stripped(self) -> None:
        # CJK chars fail [A-Za-z0-9] class → fallback
        assert _slugify("百度網盤") == "app"


class TestRecorderStartStop:
    def test_start_then_stop(self, tmp_path: Path) -> None:
        r = Recorder("notepad", traces_dir=tmp_path)
        # Pre-inject hook stubs so _install_* methods become no-ops.
        r._uia_handler = MagicMock()
        r.start()
        assert r._running is True
        trace = r.stop()
        assert isinstance(trace, RecordTrace)
        assert trace.app_name == "notepad"
        assert trace.events == []

    def test_start_idempotent(self, tmp_path: Path) -> None:
        r = Recorder("x", traces_dir=tmp_path)
        r._uia_handler = MagicMock()
        r.start()
        # Second start should be no-op (not raise).
        r.start()
        assert r._running is True
        r.stop()

    def test_stop_before_start_raises(self, tmp_path: Path) -> None:
        r = Recorder("x", traces_dir=tmp_path)
        with pytest.raises(RuntimeError, match="before start"):
            r.stop()

    def test_stop_twice_returns_trace(self, tmp_path: Path) -> None:
        r = Recorder("x", traces_dir=tmp_path)
        r._uia_handler = MagicMock()
        r.start()
        trace_a = r.stop()
        trace_b = r.stop()
        assert trace_a.trace_id == trace_b.trace_id

    def test_traces_dir_created(self, tmp_path: Path) -> None:
        target = tmp_path / "sub" / "traces"
        r = Recorder("app", traces_dir=target)
        r._uia_handler = MagicMock()
        r.start()
        assert target.exists()
        r.stop()

    def test_trace_id_increments(self, tmp_path: Path) -> None:
        r1 = Recorder("notepad", traces_dir=tmp_path)
        r1._uia_handler = MagicMock()
        r1.start()
        trace = r1.stop()
        r1.save(trace)
        r2 = Recorder("notepad", traces_dir=tmp_path)
        assert r2.trace_id == "notepad_002"


class TestEmitFilters:
    def _running(self, tmp_path: Path) -> Recorder:
        r = Recorder("app", traces_dir=tmp_path)
        r._uia_handler = MagicMock()
        r.start()
        return r

    def test_emit_ok_when_running(self, tmp_path: Path) -> None:
        r = self._running(tmp_path)
        ev = r._emit("uia.Invoke", control_path="X > Button[Save]")
        assert ev is not None
        assert ev.control_path == "X > Button[Save]"
        r.stop()

    def test_emit_dropped_when_not_running(self, tmp_path: Path) -> None:
        r = Recorder("app", traces_dir=tmp_path)
        # Never started
        assert r._emit("uia.Invoke", control_path="X") is None

    def test_debounce_within_50ms(self, tmp_path: Path) -> None:
        r = self._running(tmp_path)
        a = r._emit("uia.Invoke", control_path="P > B[x]")
        b = r._emit("uia.Invoke", control_path="P > B[x]")
        assert a is not None
        assert b is None  # debounced
        r.stop()

    def test_debounce_different_path_kept(self, tmp_path: Path) -> None:
        r = self._running(tmp_path)
        a = r._emit("uia.Invoke", control_path="P > B[x]")
        b = r._emit("uia.Invoke", control_path="P > B[y]")
        assert a is not None
        assert b is not None
        r.stop()

    def test_debounce_expires_after_window(self, tmp_path: Path) -> None:
        r = self._running(tmp_path)
        r._emit("uia.Invoke", control_path="P > B[x]")
        time.sleep(0.06)  # just over 50ms window
        ev2 = r._emit("uia.Invoke", control_path="P > B[x]")
        assert ev2 is not None
        r.stop()

    def test_password_masked(self, tmp_path: Path) -> None:
        r = self._running(tmp_path)
        ev = r._emit(
            "uia.Value", control_path="Dialog > Edit[pw]",
            value="hunter2", is_password=True,
        )
        assert ev is not None
        assert ev.value == "<password>"
        r.stop()

    def test_password_false_keeps_value(self, tmp_path: Path) -> None:
        r = self._running(tmp_path)
        ev = r._emit(
            "uia.Value", control_path="D > Edit[f]", value="plain", is_password=False,
        )
        assert ev is not None
        assert ev.value == "plain"
        r.stop()

    def test_mouse_move_dropped(self, tmp_path: Path) -> None:
        r = self._running(tmp_path)
        result = r._emit("mouse", value="move")
        assert result is None
        # MOVE (upper) also dropped (case insensitive).
        result2 = r._emit("mouse", value="MOVE")
        assert result2 is None
        r.stop()

    def test_mouse_click_kept(self, tmp_path: Path) -> None:
        r = self._running(tmp_path)
        ev = r._emit("mouse", value="click:left:10,20")
        assert ev is not None
        r.stop()


class TestSaveAndLoad:
    def test_save_round_trip(self, tmp_path: Path) -> None:
        r = Recorder("app", traces_dir=tmp_path)
        r._uia_handler = MagicMock()
        r.start()
        r._emit("uia.Invoke", control_path="X > Button[Save]")
        r._emit("uia.Value", control_path="X > Edit", value="file.txt")
        trace = r.stop()

        saved = r.save(trace)
        assert saved.exists()
        loaded = load_trace(saved)
        assert loaded.app_name == "app"
        assert len(loaded.events) == 2
        assert loaded.events[0].event_type == "uia.Invoke"

    def test_save_jsonl_structure(self, tmp_path: Path) -> None:
        r = Recorder("app", traces_dir=tmp_path)
        r._uia_handler = MagicMock()
        r.start()
        r._emit("uia.Invoke", control_path="X > B[a]")
        trace = r.stop()
        saved = r.save(trace)
        lines = saved.read_text(encoding="utf-8").strip().splitlines()
        header = json.loads(lines[0])
        assert header["_schema"] == "api-anything.record.v1"
        assert header["app_name"] == "app"
        # subsequent lines are events
        ev_data = json.loads(lines[1])
        assert ev_data["event_type"] == "uia.Invoke"

    def test_load_missing_raises(self, tmp_path: Path) -> None:
        with pytest.raises(FileNotFoundError):
            load_trace(tmp_path / "nonexistent.jsonl")

    def test_load_empty_raises(self, tmp_path: Path) -> None:
        p = tmp_path / "empty.jsonl"
        p.write_text("", encoding="utf-8")
        with pytest.raises(ValueError, match="empty"):
            load_trace(p)


class TestUIAEventCallback:
    def test_builds_control_path_from_stub(self) -> None:
        """Build a chain stub with parent references to drive path builder."""
        # Simulate 2-level UIA control hierarchy
        root = MagicMock()
        root.ControlTypeName = "Window"
        root.Name = "Notepad"
        root.GetParentControl.return_value = None

        child = MagicMock()
        child.ControlTypeName = "Button"
        child.Name = "Save"
        child.GetParentControl.return_value = root

        path = _build_uia_control_path(child)
        assert path == "Window[Notepad] > Button[Save]"

    def test_callback_calls_emit(self, tmp_path: Path) -> None:
        r = Recorder("app", traces_dir=tmp_path)
        r._uia_handler = MagicMock()
        r.start()

        cb = _UIAEventCallback(r)
        sender = MagicMock()
        sender.ControlTypeName = "Button"
        sender.Name = "OK"
        sender.GetParentControl.return_value = None
        sender.IsPassword = False

        # Callback is wrapped in try/except → even if uiautomation module
        # is missing in test env it will coarse-bucket to uia.Invoke.
        cb(sender, 0)  # eventId=0 is unknown → default uia.Invoke
        # After callback, event list should have 1 element (or 0 if UIA
        # import failed silently — both are acceptable as long as no raise).
        assert r._running
        r.stop()


class TestTraceFilesystemLayout:
    def test_thumbnails_dir_sibling_of_jsonl(self, tmp_path: Path) -> None:
        r = Recorder("notepad", traces_dir=tmp_path)
        r._uia_handler = MagicMock()
        r.start()
        trace = r.stop()
        assert trace.thumbnails_dir.parent == tmp_path
        assert trace.thumbnails_dir.name.endswith("_thumbnails")

    def test_trace_id_slug_consistent(self, tmp_path: Path) -> None:
        r = Recorder("My App!", traces_dir=tmp_path)
        assert r.trace_id.startswith("my_app_")


# ---------------------------------------------------------------------------
# Scope-to-window tests (FIX 1 + FIX 2 — Red-team FATAL mitigations)
# ---------------------------------------------------------------------------


class TestTargetWindowScoping:
    """FIX 1: Recorder must scope UIA + raw hooks + screenshot to one window."""

    def test_explicit_target_window_stored(self, tmp_path: Path) -> None:
        r = Recorder(
            "notepad", target_window_handle=0xDEADBEEF, traces_dir=tmp_path
        )
        assert r._target_window_handle == 0xDEADBEEF

    def test_default_target_is_none_until_start(self, tmp_path: Path) -> None:
        r = Recorder("notepad", traces_dir=tmp_path)
        assert r._target_window_handle is None

    def test_raw_hook_drops_events_when_not_foreground(self, tmp_path: Path) -> None:
        """Events with different foreground HWND must be dropped silently."""
        r = Recorder(
            "notepad", target_window_handle=0xAAAA, traces_dir=tmp_path
        )
        r._uia_handler = MagicMock()
        r.start()
        # Simulate Alt-Tab'd away: foreground = different HWND
        r._is_foreground_our_target = lambda: False  # type: ignore[method-assign]
        # Raw events should be filtered — directly test the underlying emit
        # does nothing because gate returns False.
        # (Raw hook handlers themselves aren't installed without pynput;
        # we test the gate function directly.)
        assert r._is_foreground_our_target() is False
        r.stop()

    def test_raw_hook_accepts_events_when_foreground(self, tmp_path: Path) -> None:
        r = Recorder(
            "notepad", target_window_handle=0xAAAA, traces_dir=tmp_path
        )
        r._uia_handler = MagicMock()
        r.start()
        # Monkey-patch gate to return True
        r._is_foreground_our_target = lambda: True  # type: ignore[method-assign]
        assert r._is_foreground_our_target() is True
        r.stop()

    def test_foreground_gate_matches_via_ctypes(self, tmp_path: Path) -> None:
        """Integration: GetForegroundWindow returning our HWND → True."""
        r = Recorder(
            "notepad", target_window_handle=0xBEEF, traces_dir=tmp_path
        )
        with patch("ctypes.windll") as windll:
            windll.user32.GetForegroundWindow.return_value = 0xBEEF
            assert r._is_foreground_our_target() is True
            windll.user32.GetForegroundWindow.return_value = 0xCAFE
            assert r._is_foreground_our_target() is False

    def test_foreground_gate_no_target_returns_false(self, tmp_path: Path) -> None:
        """No target HWND = drop raw events (safer default)."""
        r = Recorder("notepad", traces_dir=tmp_path)
        # _target_window_missing set by _resolve_target_window if ctypes fails
        assert r._is_foreground_our_target() is False

    def test_get_window_bounds_returns_rect_dict(self, tmp_path: Path) -> None:
        """FIX 1 step 3: bounds dict has mss-friendly left/top/width/height."""
        r = Recorder(
            "notepad", target_window_handle=0xBEEF, traces_dir=tmp_path
        )
        with patch("ctypes.windll") as windll:
            def fake_get_window_rect(hwnd, rect_ref):
                # rect_ref is ctypes.byref(RECT) — modify via _obj
                rect_ref._obj.left = 10
                rect_ref._obj.top = 20
                rect_ref._obj.right = 110
                rect_ref._obj.bottom = 80
                return 1
            windll.user32.GetWindowRect.side_effect = fake_get_window_rect
            bounds = r._get_window_bounds()
            assert bounds is not None
            assert set(bounds.keys()) == {"left", "top", "width", "height"}
            assert bounds["left"] == 10
            assert bounds["top"] == 20
            assert bounds["width"] == 100
            assert bounds["height"] == 60

    def test_get_window_bounds_no_hwnd_returns_none(self, tmp_path: Path) -> None:
        r = Recorder("notepad", traces_dir=tmp_path)
        assert r._get_window_bounds() is None

    def test_screenshot_disabled_when_no_target(self, tmp_path: Path) -> None:
        """FIX 2: no target window → screenshot thread must NOT start."""
        r = Recorder("notepad", traces_dir=tmp_path)
        # Simulate non-Windows / resolve failed state
        r._target_window_missing = True
        r._uia_handler = MagicMock()
        r._install_screenshot_stream()
        assert r._screenshot_thread is None

    def test_snap_thumbnail_uses_window_rect_not_monitor(
        self, tmp_path: Path
    ) -> None:
        """FIX 1 step 3: grabber.grab called with dict rect, never monitors[0]."""
        pytest.importorskip("PIL")
        r = Recorder(
            "notepad", target_window_handle=0xBEEF, traces_dir=tmp_path
        )
        r._uia_handler = MagicMock()
        r.start()
        # Pretend bounds already cached so _get_window_bounds failing is OK.
        r._target_bounds = {"left": 0, "top": 0, "width": 10, "height": 10}

        fake_raw = MagicMock()
        fake_raw.size = (10, 10)
        fake_raw.rgb = b"\x00" * (10 * 10 * 3)
        grabber = MagicMock()
        grabber.grab.return_value = fake_raw
        grabber.monitors = [
            {"left": 0, "top": 0, "width": 1920, "height": 1080}
        ]

        name = r._snap_thumbnail(grabber)
        # Assert called with the *dict* rect, not with monitors[0] directly.
        assert grabber.grab.call_count == 1
        passed = grabber.grab.call_args.args[0]
        assert isinstance(passed, dict)
        assert set(passed.keys()) == {"left", "top", "width", "height"}
        assert name == "0000.png"
        r.stop()

    def test_snap_thumbnail_skips_when_no_bounds(self, tmp_path: Path) -> None:
        """FIX 2 safety: no bounds + no cache → skip, don't fall back."""
        pytest.importorskip("PIL")
        r = Recorder("notepad", traces_dir=tmp_path)
        r._uia_handler = MagicMock()
        r.start()
        # Post-start: simulate no-target-window state (e.g. window closed).
        r._target_window_handle = None
        r._target_window_missing = True
        r._target_bounds = None
        grabber = MagicMock()
        grabber.monitors = [
            {"left": 0, "top": 0, "width": 1920, "height": 1080}
        ]
        # No bounds set, _get_window_bounds will return None.
        name = r._snap_thumbnail(grabber)
        assert name is None
        grabber.grab.assert_not_called()
        r.stop()

    def test_non_windows_degrades_without_crash(self, tmp_path: Path) -> None:
        """Graceful path: on Linux (no ctypes.windll), Recorder still constructs."""
        r = Recorder("x", traces_dir=tmp_path)
        # Simulate resolve failure: GetForegroundWindow raises OSError
        with patch("ctypes.windll") as windll:
            windll.user32.GetForegroundWindow.side_effect = OSError("no windll")
            r._resolve_target_window()
        # After resolve failure, recorder flag set for safe degradation.
        assert r._target_window_missing is True
        r._uia_handler = MagicMock()
        r.start()
        trace = r.stop()
        assert isinstance(trace, RecordTrace)

    def test_resolve_uses_foreground_when_no_explicit(
        self, tmp_path: Path
    ) -> None:
        """FIX 1 step 1: lazy resolve via GetForegroundWindow()."""
        r = Recorder("notepad", traces_dir=tmp_path)
        with patch("ctypes.windll") as windll:
            windll.user32.GetForegroundWindow.return_value = 0x1234
            r._resolve_target_window()
        assert r._target_window_handle == 0x1234
        assert r._target_window_missing is False


# ---------------------------------------------------------------------------
# UIA Value / Selection handler tests (FIX 3 — Red-team HIGH)
# ---------------------------------------------------------------------------


class TestUIAValueAndSelectionHandlers:
    """FIX 3: _UIAEventCallback must dispatch Value + Selection kinds."""

    def test_callback_value_event_masks_password(self, tmp_path: Path) -> None:
        """Password-bearing Value event keeps <password> marker."""
        r = Recorder(
            "app", target_window_handle=0xAAAA, traces_dir=tmp_path
        )
        r._uia_handler = MagicMock()
        r.start()
        # Simulate a Value-property callback: use _emit with is_password flag
        # (the callback branch triggers emit via the same path).
        ev = r._emit(
            "uia.Value",
            control_path="Dialog > Edit[pw]",
            value="secret",
            is_password=True,
        )
        assert ev is not None
        assert ev.value == "<password>"
        assert ev.event_type == "uia.Value"
        r.stop()

    def test_callback_selection_event_captured(self, tmp_path: Path) -> None:
        """Selection event produces a uia.Selection RecordEvent."""
        r = Recorder(
            "app", target_window_handle=0xAAAA, traces_dir=tmp_path
        )
        r._uia_handler = MagicMock()
        r.start()
        ev = r._emit("uia.Selection", control_path="Combo > Item[Option A]")
        assert ev is not None
        assert ev.event_type == "uia.Selection"
        r.stop()

    def test_install_tokens_tracked_for_each_kind(self, tmp_path: Path) -> None:
        """Real subscriptions via ``_uia_events``: all three kinds recorded.

        v0.3.1 rewrite — no longer patches ``sys.modules["uiautomation"]``;
        instead mocks the ``_uia_events`` wrapper functions that recorder
        imports at module top. Same behaviour coverage, new plumbing.
        """
        r = Recorder(
            "app", target_window_handle=0xAAAA, traces_dir=tmp_path
        )
        fake_element = MagicMock(name="uia_element")
        invoke_tok = MagicMock(name="invoke_token", spec=[])
        value_tok = MagicMock(name="value_token", spec=[])
        selection_tok = MagicMock(name="selection_token", spec=[])

        with (
            patch("api_anything.recorder.uev.control_from_handle",
                  return_value=fake_element) as cfh,
            patch("api_anything.recorder.uev.subscribe_invoke",
                  return_value=invoke_tok) as sub_inv,
            patch("api_anything.recorder.uev.subscribe_value_changed",
                  return_value=value_tok) as sub_val,
            patch("api_anything.recorder.uev.subscribe_selection",
                  return_value=selection_tok) as sub_sel,
        ):
            r._install_uia_handler()

        kinds = {tok[0] for tok in r._uia_handler_tokens}
        assert "event:Invoke" in kinds
        assert "event:Selection" in kinds
        assert "property:Value" in kinds
        # control_from_handle called with our HWND exactly once.
        cfh.assert_called_once_with(0xAAAA)
        sub_inv.assert_called_once()
        sub_val.assert_called_once()
        sub_sel.assert_called_once()

    def test_install_skips_when_no_hwnd(self, tmp_path: Path) -> None:
        """Missing target window → NO subscription (aligns with FIX 2 policy).

        v0.3.1: the v0.3.0 "fall back to GetRootControl" path is removed
        because it contradicted the FIX 2 no-HWND-no-capture invariant.
        Recorder now refuses to subscribe without a target window — same
        safety stance as the mss screenshot thread.
        """
        r = Recorder("app", traces_dir=tmp_path)
        r._target_window_missing = True

        with (
            patch("api_anything.recorder.uev.control_from_handle") as cfh,
            patch("api_anything.recorder.uev.subscribe_invoke") as sub_inv,
            patch("api_anything.recorder.uev.subscribe_value_changed") as sub_val,
            patch("api_anything.recorder.uev.subscribe_selection") as sub_sel,
        ):
            r._install_uia_handler()

        cfh.assert_not_called()
        sub_inv.assert_not_called()
        sub_val.assert_not_called()
        sub_sel.assert_not_called()
        assert r._uia_handler is None
        assert r._uia_handler_tokens == []

    def test_install_skips_when_hwnd_none_no_missing_flag(
        self, tmp_path: Path
    ) -> None:
        """Defense-in-depth: hwnd=None + missing=False still refuses subscribe."""
        r = Recorder("app", traces_dir=tmp_path)
        # Caller cleared the "missing" flag but did not supply a handle.
        r._target_window_handle = None
        r._target_window_missing = False

        with (
            patch("api_anything.recorder.uev.subscribe_invoke") as sub_inv,
            patch("api_anything.recorder.uev.subscribe_value_changed") as sub_val,
            patch("api_anything.recorder.uev.subscribe_selection") as sub_sel,
        ):
            r._install_uia_handler()

        sub_inv.assert_not_called()
        sub_val.assert_not_called()
        sub_sel.assert_not_called()

    def test_start_without_hwnd_does_not_subscribe(self, tmp_path: Path) -> None:
        """End-to-end: Recorder.start() with no target HWND → no uev calls."""
        r = Recorder("app", traces_dir=tmp_path)

        def fake_resolve() -> None:
            # Simulate non-Windows resolve failure path.
            r._target_window_missing = True

        with (
            patch.object(r, "_resolve_target_window", side_effect=fake_resolve),
            patch("api_anything.recorder.uev.subscribe_invoke") as sub_inv,
            patch("api_anything.recorder.uev.subscribe_value_changed") as sub_val,
            patch("api_anything.recorder.uev.subscribe_selection") as sub_sel,
        ):
            r.start()
            r.stop()

        sub_inv.assert_not_called()
        sub_val.assert_not_called()
        sub_sel.assert_not_called()

    def test_uninstall_clears_tokens(self, tmp_path: Path) -> None:
        """Unsubscribe is called per token; handler ref cleared."""
        from api_anything._uia_events import UIAEventToken

        r = Recorder(
            "app", target_window_handle=0xAAAA, traces_dir=tmp_path
        )
        r._uia_handler = MagicMock()
        real_tok_a = UIAEventToken(999001)
        real_tok_b = UIAEventToken(999002)
        r._uia_handler_tokens = [
            ("event:Invoke", real_tok_a),
            ("property:Value", real_tok_b),
        ]
        with patch("api_anything.recorder.uev.unsubscribe") as unsub:
            r._uninstall_uia_handler()
            # Called once per real token.
            assert unsub.call_count == 2
            assert {call.args[0] for call in unsub.call_args_list} == {
                real_tok_a, real_tok_b
            }
        assert r._uia_handler_tokens == []
        assert r._uia_handler is None

    def test_uninstall_tolerates_token_exception(self, tmp_path: Path) -> None:
        """One stuck unsubscribe must NOT prevent cleanup of siblings."""
        from api_anything._uia_events import UIAEventToken

        r = Recorder(
            "app", target_window_handle=0xAAAA, traces_dir=tmp_path
        )
        r._uia_handler = MagicMock()
        tok1, tok2 = UIAEventToken(111), UIAEventToken(222)
        r._uia_handler_tokens = [("event:Invoke", tok1), ("event:Selection", tok2)]

        def flaky(token: UIAEventToken) -> None:
            if token is tok1:
                raise RuntimeError("COM died")

        with patch("api_anything.recorder.uev.unsubscribe", side_effect=flaky) as unsub:
            r._uninstall_uia_handler()
            # Both attempted even though first raised.
            assert unsub.call_count == 2
        assert r._uia_handler_tokens == []
