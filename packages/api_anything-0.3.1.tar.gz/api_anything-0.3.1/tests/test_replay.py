"""Tests for api_anything.replay — zero-LLM replay layer (RFC v0.3 M2).

All UIA primitives are patched via unittest.mock so no real platform call
happens. Covers dispatch, param substitution, file round-trip, and install
hint paths.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from api_anything.recorder import Recorder, RecordEvent, RecordTrace
from api_anything.replay import Replayer, _parse_path_segment


def _make_trace(events: list[RecordEvent], tmp_path: Path) -> RecordTrace:
    return RecordTrace(
        app_name="app",
        trace_id="app_001",
        started_at="2026-04-17T00:00:00+00:00",
        events=events,
        thumbnails_dir=tmp_path / "app_001_thumbnails",
    )


class TestParsePathSegment:
    def test_with_name(self) -> None:
        assert _parse_path_segment("Button[Save]") == ("Button", "Save")

    def test_without_name(self) -> None:
        assert _parse_path_segment("Pane") == ("Pane", "")

    def test_empty_segment(self) -> None:
        assert _parse_path_segment("  ") == ("", "")


class TestReplayDispatch:
    def test_invoke_event_calls_invoke(self, tmp_path: Path) -> None:
        trace = _make_trace(
            [RecordEvent(ts=0.0, event_type="uia.Invoke", control_path="Win > Button[OK]")],
            tmp_path,
        )
        r = Replayer(trace)
        with patch.object(r, "_invoke") as mock_invoke:
            r.replay()
        mock_invoke.assert_called_once_with("Win > Button[OK]")

    def test_value_event_calls_set_value(self, tmp_path: Path) -> None:
        trace = _make_trace(
            [RecordEvent(
                ts=0.0, event_type="uia.Value",
                control_path="Win > Edit", value="hello",
            )],
            tmp_path,
        )
        r = Replayer(trace)
        with patch.object(r, "_set_value") as mock_set:
            r.replay()
        mock_set.assert_called_once_with("Win > Edit", "hello")

    def test_key_event_calls_send_key(self, tmp_path: Path) -> None:
        trace = _make_trace(
            [RecordEvent(ts=0.0, event_type="key", value="enter")],
            tmp_path,
        )
        r = Replayer(trace)
        with patch.object(r, "_send_key") as mock_key:
            r.replay()
        mock_key.assert_called_once_with("enter")

    def test_selection_event_routes_to_set_value(self, tmp_path: Path) -> None:
        trace = _make_trace(
            [RecordEvent(
                ts=0.0, event_type="uia.Selection",
                control_path="Win > Combo[x]", value="Option1",
            )],
            tmp_path,
        )
        r = Replayer(trace)
        with patch.object(r, "_set_value") as mock_set:
            r.replay()
        mock_set.assert_called_once_with("Win > Combo[x]", "Option1")

    def test_invoke_without_control_path_skipped(self, tmp_path: Path) -> None:
        trace = _make_trace(
            [RecordEvent(ts=0.0, event_type="uia.Invoke", control_path=None)],
            tmp_path,
        )
        r = Replayer(trace)
        with patch.object(r, "_invoke") as mock_invoke:
            r.replay()
        mock_invoke.assert_not_called()

    def test_mouse_event_skipped_but_no_error(self, tmp_path: Path) -> None:
        trace = _make_trace(
            [RecordEvent(ts=0.0, event_type="mouse", value="click:left:10,20")],
            tmp_path,
        )
        r = Replayer(trace)
        r.replay()  # should not raise

    def test_multiple_events_in_order(self, tmp_path: Path) -> None:
        trace = _make_trace(
            [
                RecordEvent(ts=0.0, event_type="uia.Invoke", control_path="Win > B[File]"),
                RecordEvent(ts=0.1, event_type="uia.Value",
                            control_path="Win > E[name]", value="a.txt"),
                RecordEvent(ts=0.2, event_type="uia.Invoke", control_path="Win > B[Save]"),
            ],
            tmp_path,
        )
        r = Replayer(trace)
        with (
            patch.object(r, "_invoke") as mock_inv,
            patch.object(r, "_set_value") as mock_set,
        ):
            r.replay()
        assert mock_inv.call_count == 2
        mock_set.assert_called_once_with("Win > E[name]", "a.txt")


class TestParamSubstitution:
    def test_param_substitutes_into_value_event(self, tmp_path: Path) -> None:
        trace = _make_trace(
            [RecordEvent(
                ts=0.0, event_type="uia.Value", control_path="E",
                value="original.txt", value_is_param=True, param_name="path",
            )],
            tmp_path,
        )
        r = Replayer(trace)
        with patch.object(r, "_set_value") as mock_set:
            r.replay(path="new.txt")
        mock_set.assert_called_once_with("E", "new.txt")

    def test_non_param_event_uses_original_value(self, tmp_path: Path) -> None:
        trace = _make_trace(
            [RecordEvent(ts=0.0, event_type="uia.Value", control_path="E", value="static")],
            tmp_path,
        )
        r = Replayer(trace)
        with patch.object(r, "_set_value") as mock_set:
            r.replay(unused="ignored")
        mock_set.assert_called_once_with("E", "static")

    def test_missing_param_raises_keyerror(self, tmp_path: Path) -> None:
        trace = _make_trace(
            [RecordEvent(
                ts=0.0, event_type="uia.Value", control_path="E",
                value="x", value_is_param=True, param_name="path",
            )],
            tmp_path,
        )
        r = Replayer(trace)
        with pytest.raises(KeyError, match="path"):
            r.replay()

    def test_param_value_coerced_to_str(self, tmp_path: Path) -> None:
        trace = _make_trace(
            [RecordEvent(
                ts=0.0, event_type="uia.Value", control_path="E",
                value="0", value_is_param=True, param_name="n",
            )],
            tmp_path,
        )
        r = Replayer(trace)
        with patch.object(r, "_set_value") as mock_set:
            r.replay(n=42)
        mock_set.assert_called_once_with("E", "42")


class TestFromFile:
    def test_round_trip(self, tmp_path: Path) -> None:
        recorder = Recorder("notepad", traces_dir=tmp_path)
        recorder._uia_handler = MagicMock()
        recorder.start()
        recorder._emit("uia.Invoke", control_path="Win > B[OK]")
        trace = recorder.stop()
        saved = recorder.save(trace)

        r = Replayer.from_file(saved)
        assert len(r.trace.events) == 1
        assert r.trace.events[0].control_path == "Win > B[OK]"

    def test_from_file_bad_path_raises(self, tmp_path: Path) -> None:
        with pytest.raises(FileNotFoundError):
            Replayer.from_file(tmp_path / "missing.jsonl")


class TestMissingUiautomationHint:
    def test_send_key_without_uia_raises_runtime_error(self, tmp_path: Path) -> None:
        trace = _make_trace([], tmp_path)
        r = Replayer(trace)
        with (
            patch.dict("sys.modules", {"uiautomation": None}),
            pytest.raises(RuntimeError, match="uiautomation"),
        ):
            r._send_key("enter")

    def test_resolve_control_without_uia_raises_runtime_error(
        self, tmp_path: Path,
    ) -> None:
        trace = _make_trace([], tmp_path)
        r = Replayer(trace)
        with (
            patch.dict("sys.modules", {"uiautomation": None}),
            pytest.raises(RuntimeError, match="uiautomation"),
        ):
            r._resolve_control("Win > B[OK]")

    def test_invoke_uses_invoke_pattern(self, tmp_path: Path) -> None:
        trace = _make_trace([], tmp_path)
        r = Replayer(trace)
        ctrl = MagicMock()
        with patch.object(r, "_resolve_control", return_value=ctrl):
            r._invoke("Win > B[OK]")
        ctrl.GetInvokePattern.assert_called_once()

    def test_set_value_uses_value_pattern(self, tmp_path: Path) -> None:
        trace = _make_trace([], tmp_path)
        r = Replayer(trace)
        ctrl = MagicMock()
        with patch.object(r, "_resolve_control", return_value=ctrl):
            r._set_value("Win > E[x]", "hello")
        ctrl.GetValuePattern.assert_called_once()
        ctrl.GetValuePattern.return_value.SetValue.assert_called_once_with("hello")
