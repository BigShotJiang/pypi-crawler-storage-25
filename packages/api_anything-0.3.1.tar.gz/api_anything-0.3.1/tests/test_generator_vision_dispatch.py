"""Tests for generator.generate_api vision dispatch (RFC v0.3 M1 wiring).

Confirms:
    * ``vision_candidates=[...]`` dispatches to the vision branch.
    * ``record_trace`` parameter accepts a value without breaking M1.
    * Rendered method bodies use ``_locate_control`` + ``_click_at`` and
      carry a baked-in bbox literal (zero runtime LLM guarantee).
    * Generated code ``compile()`` s via ``ast.parse``.
"""

from __future__ import annotations

import ast
from pathlib import Path

from api_anything.generator import (
    _append_vision_body,
    _parse_vision_bbox_from_control,
    _parse_vision_bbox_from_hint,
    generate_api,
)
from api_anything.models import APIMethod, UIControl
from api_anything.vision_runtime import VisionElement


def _elements() -> list[VisionElement]:
    return [
        VisionElement(label="Save", bbox=(100, 200, 150, 230), confidence=0.9),
        VisionElement(label="Open File", bbox=(10, 10, 60, 40), confidence=0.8),
    ]


class TestVisionDispatch:
    def test_vision_candidates_route_to_vision_mode(self) -> None:
        result = generate_api(
            "VSCode", controls=[], tier="4", vision_candidates=_elements()
        )
        assert result.generation_mode == "vision"

    def test_method_names_emitted(self) -> None:
        result = generate_api(
            "VSCode", controls=[], tier="4", vision_candidates=_elements()
        )
        names = [m.name for m in result.api_class.methods]
        assert "click_save" in names
        assert "click_open_file" in names

    def test_vision_methods_have_mode(self) -> None:
        result = generate_api(
            "VSCode", controls=[], tier="4", vision_candidates=_elements()
        )
        vision_methods = [
            m for m in result.api_class.methods if m.operation_mode == "vision"
        ]
        assert len(vision_methods) == 2

    def test_body_uses_locate_control(self) -> None:
        result = generate_api(
            "VSCode", controls=[], tier="4", vision_candidates=_elements()
        )
        assert "_locate_control" in result.source_code
        assert "_click_at" in result.source_code

    def test_body_has_baked_bbox(self) -> None:
        result = generate_api(
            "VSCode", controls=[], tier="4", vision_candidates=_elements()
        )
        # The bbox literal from our first element should appear verbatim.
        assert "bbox=(100, 200, 150, 230)" in result.source_code

    def test_generated_source_compiles(self) -> None:
        result = generate_api(
            "VSCode", controls=[], tier="4", vision_candidates=_elements()
        )
        ast.parse(result.source_code)

    def test_record_trace_has_priority_over_vision(self) -> None:
        """RFC v0.3 §B.3 dispatch priority: record > vision > UIA.

        Both `record_trace` and `vision_candidates` supplied — record
        path fires first and returns before vision dispatch runs.
        """
        from api_anything.recorder import RecordEvent, RecordTrace

        trace = RecordTrace(
            app_name="notepad",
            started_at="2026-04-17T00:00:00Z",
            events=[
                RecordEvent(
                    ts=0.0, event_type="uia.Invoke",
                    control_path="Window[Notepad]>File", value=None,
                    screenshot_ref=None,
                ),
            ],
            thumbnails_dir=Path("/tmp/nonexistent"),
            trace_id="priority_test",
        )
        result = generate_api(
            "Notepad",
            controls=[],
            tier="4",
            vision_candidates=_elements(),
            record_trace=trace,
        )
        assert result.generation_mode == "record_replay"

    def test_empty_vision_candidates_do_not_dispatch_to_vision(self) -> None:
        """Falsy value → routes through existing mock path."""
        result = generate_api(
            "VSCode", controls=[], tier="2A", vision_candidates=[]
        )
        assert result.generation_mode != "vision"

    def test_no_llm_call_at_runtime(self) -> None:
        """Body imports _locate_control with vlm_client=None path (drift
        recovery only)."""
        result = generate_api(
            "VSCode", controls=[], tier="4", vision_candidates=_elements()
        )
        # Confirm the baked ControlSpec carries the bbox, so
        # _locate_control returns before touching the VLM.
        assert "ControlSpec(name='Save', bbox=(100, 200, 150, 230))" in result.source_code

    def test_vision_coexists_with_uia_controls(self) -> None:
        """Caller may supply both: resulting class has UIA + vision methods."""
        uia_controls = [UIControl(name="File", control_type="Menu")]
        result = generate_api(
            "App",
            controls=uia_controls,
            tier="3B",
            vision_candidates=_elements(),
        )
        names = [m.name for m in result.api_class.methods]
        assert any(n.startswith("open_file") or n == "open_file" for n in names)
        assert "click_save" in names

    def test_existing_uia_label_skips_vision_duplicate(self) -> None:
        """Vision element whose label matches an existing UIA control
        should not produce a duplicate method."""
        uia_controls = [UIControl(name="Save", control_type="Button")]
        result = generate_api(
            "App",
            controls=uia_controls,
            tier="3B",
            vision_candidates=_elements(),  # includes label="Save"
        )
        save_methods = [
            m for m in result.api_class.methods
            if "save" in m.name.lower() and m.operation_mode == "vision"
        ]
        assert save_methods == []


# ---------------------------------------------------------------------------
# Unit tests for the body-emitter helpers
# ---------------------------------------------------------------------------


class TestVisionBodyHelpers:
    def test_parse_bbox_from_control(self) -> None:
        ctrl = UIControl(
            name="Save",
            control_type="VisionElement",
            parent_path="vision-bbox:10,20,30,40",
        )
        assert _parse_vision_bbox_from_control(ctrl) == (10, 20, 30, 40)

    def test_parse_bbox_returns_none_on_non_vision_control(self) -> None:
        ctrl = UIControl(name="X", control_type="Button", parent_path="File > Save")
        assert _parse_vision_bbox_from_control(ctrl) is None

    def test_parse_bbox_from_hint(self) -> None:
        hint = "vision_click label='X' bbox=(1,2,3,4) confidence=0.90"
        assert _parse_vision_bbox_from_hint(hint) == (1, 2, 3, 4)

    def test_parse_bbox_from_hint_missing(self) -> None:
        assert _parse_vision_bbox_from_hint("no bbox here") is None

    def test_append_vision_body_emits_click(self) -> None:
        lines: list[str] = []
        method = APIMethod(
            name="click_save",
            docstring="click",
            params=[],
            return_type="None",
            operation_mode="vision",
            implementation_hint="vision_click label='Save' bbox=(1,2,3,4) confidence=0.9",
        )
        ctrl = UIControl(
            name="Save",
            control_type="VisionElement",
            parent_path="vision-bbox:1,2,3,4",
        )
        _append_vision_body(lines, method, ctrl)
        body = "\n".join(lines)
        assert "ControlSpec" in body
        assert "_locate_control" in body
        assert "_click_at" in body
        assert "bbox=(1, 2, 3, 4)" in body

    def test_append_vision_body_handles_missing_bbox(self) -> None:
        """When both control bbox and hint bbox are absent, body still
        compiles but carries bbox=None (runtime VLM fallback)."""
        lines: list[str] = []
        method = APIMethod(
            name="click_mystery",
            docstring="mystery",
            params=[],
            return_type="None",
            operation_mode="vision",
            implementation_hint="no bbox",
        )
        _append_vision_body(lines, method, None)
        body = "\n".join(lines)
        assert "bbox=None" in body
        assert "fallback_selector" in body


# ---------------------------------------------------------------------------
# Isolation check — vision_generator MUST be dispatched, not orphaned
# (MEMORY #13b enforcement)
# ---------------------------------------------------------------------------


class TestIsolationGuard:
    def test_vision_generator_is_imported_by_generator(self) -> None:
        """Grep-equivalent: confirm the dispatch actually wires the module."""
        import api_anything.generator as g
        src = __import__("inspect").getsource(g)
        assert "from .vision_generator import" in src
        assert "_generate_with_vision_methods" in src
