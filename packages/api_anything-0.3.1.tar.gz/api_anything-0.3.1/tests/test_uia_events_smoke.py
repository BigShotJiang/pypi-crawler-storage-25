"""Windows-only integration smoke test for api_anything._uia_events.

Launches a real Notepad process, subscribes to Invoke + Value events, drives
the UI via ``pywinauto``, and asserts the callbacks fired within a 5s budget.

Skipped entirely on non-Windows and when ``pywinauto`` is missing.

This test has a real side effect — a Notepad window pops up — so it is NOT
part of the quiet default suite. Run it manually with:

    pytest tests/test_uia_events_smoke.py -v

The smoke test is designed for GitHub Actions Windows runners where
``pywinauto`` is available via the dev extras.
"""

# ruff: noqa: E402, I001
# Imports below ``pytest.importorskip`` are intentionally late so the whole
# module skips cleanly when pywinauto or the non-Windows guard bites.
from __future__ import annotations

import contextlib
import os
import subprocess
import sys
import threading
import time

import pytest

pytestmark = [
    pytest.mark.skipif(
        sys.platform != "win32",
        reason="UIA events require Windows",
    ),
    # Off by default — this test launches real Notepad and poisons CI
    # screenshots for any concurrent job. Opt in with:
    #     RUN_UIA_SMOKE=1 pytest tests/test_uia_events_smoke.py
    pytest.mark.skipif(
        os.environ.get("RUN_UIA_SMOKE") != "1",
        reason="UIA smoke test opt-in only; set RUN_UIA_SMOKE=1 to run",
    ),
]

pywinauto = pytest.importorskip("pywinauto", reason="pywinauto needed to drive Notepad")

from api_anything import _uia_events as uev


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _wait_for_hwnd(app_spec: str, timeout: float = 5.0) -> int:
    """Block until a window matching ``app_spec`` appears, return its HWND."""
    from pywinauto import Application, timings

    end = time.monotonic() + timeout
    while time.monotonic() < end:
        try:
            app = Application(backend="uia").connect(
                title_re=app_spec, timeout=0.5
            )
            win = app.top_window()
            hwnd = int(win.handle)
            if hwnd:
                return hwnd
        except (timings.TimeoutError, RuntimeError, OSError):
            time.sleep(0.1)
    raise TimeoutError(f"no window matching {app_spec!r} after {timeout}s")


# ---------------------------------------------------------------------------
# Integration test
# ---------------------------------------------------------------------------


def test_notepad_invoke_and_value_events_fire() -> None:
    """Subscribe to the real Notepad window and confirm events are delivered.

    Success criteria (any ONE of Invoke / Value firing within 5s):
        - Invoke: File menu / Save button click triggers the handler
        - Value: typing text into the edit area triggers property changed

    We don't insist both fire — different Notepad builds (classic Win32 vs
    Win11 UWP shell) expose different UIA trees. The smoke test is about
    proving the comtypes plumbing works end-to-end, not Notepad itself.
    """
    proc = subprocess.Popen(["notepad.exe"])
    notepad_hwnd: int | None = None
    invoke_token = None
    value_token = None
    invoke_hits: list[tuple[str, int]] = []
    value_hits: list[tuple[str, str]] = []
    lock = threading.Lock()

    def on_invoke(path: str, event_id: int) -> None:
        with lock:
            invoke_hits.append((path, event_id))

    def on_value(path: str, value: str) -> None:
        with lock:
            value_hits.append((path, value))

    try:
        # Give Notepad a moment to finish initialising UIA tree.
        # Locale-tolerant title regex — "Untitled" (en) / "新增" (zh-TW) /
        # "无标题" (zh-CN) / "제목 없음" (ko) / "Sin título" (es) /
        # "Sans titre" (fr) / "Ohne Titel" (de) / "Senza nome" (it) /
        # "無題" (ja). Classic Win32 Notepad suffix is "Notepad" + locale
        # word; Win11 UWP Notepad uses same tree but with extra chrome.
        notepad_hwnd = _wait_for_hwnd(
            r"(Untitled|新增|无标题|제목\s*없음|Sin título|Sans titre"
            r"|Ohne Titel|Senza nome|無題).*(Notepad|記事本|메모장|메모)",
            timeout=10.0,
        )

        element = uev.control_from_handle(notepad_hwnd)
        assert element is not None, "ElementFromHandle returned null"

        invoke_token = uev.subscribe_invoke(element, on_invoke)
        value_token = uev.subscribe_value_changed(element, on_value)

        # Drive the UI: type text → Value event; open File menu → Invoke.
        from pywinauto import Application

        app = Application(backend="uia").connect(handle=notepad_hwnd)
        win = app.top_window()

        # Type some text → should fire value-changed on the edit area.
        win.type_keys("Hello UIA events", with_spaces=True)
        time.sleep(0.3)

        # Click the File menu to induce an Invoke.
        try:
            file_menu = win.child_window(title="File", control_type="MenuItem")
            file_menu.invoke()
        except Exception:
            # Fallback: alt-F to open File menu (keyboard drives invoke too).
            win.type_keys("%f")
        time.sleep(0.3)

        # Wait up to 5s for any event to arrive.
        deadline = time.monotonic() + 5.0
        while time.monotonic() < deadline:
            with lock:
                if invoke_hits or value_hits:
                    break
            time.sleep(0.1)

        with lock:
            total = len(invoke_hits) + len(value_hits)
        assert total > 0, (
            "no UIA events delivered within 5s — "
            f"invoke={len(invoke_hits)} value={len(value_hits)}"
        )

    finally:
        for tok in (invoke_token, value_token):
            if tok is not None:
                with contextlib.suppress(Exception):
                    uev.unsubscribe(tok)
        try:
            proc.terminate()
            proc.wait(timeout=3.0)
        except Exception:
            proc.kill()
