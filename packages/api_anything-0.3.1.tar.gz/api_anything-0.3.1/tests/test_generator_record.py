"""Tests for generator.generate_api record-replay dispatch (RFC v0.3 M2).

Mock LLM client (Anthropic-compatible) is injected to drive the schema
inference path. All tests verify without a network call.
"""

from __future__ import annotations

import ast
import json
from pathlib import Path
from unittest.mock import MagicMock

from api_anything.generator import (
    _build_record_api_class,
    _generate_from_record,
    _infer_record_method_schema,
    generate_api,
)
from api_anything.recorder import RecordEvent, RecordTrace


def _sample_trace(tmp_path: Path) -> RecordTrace:
    return RecordTrace(
        app_name="notepad",
        trace_id="notepad_001",
        started_at="2026-04-17T00:00:00+00:00",
        events=[
            RecordEvent(ts=0.0, event_type="uia.Invoke", control_path="Win > B[File]"),
            RecordEvent(
                ts=0.1, event_type="uia.Value",
                control_path="Dialog > Edit[name]", value="hello.txt",
            ),
            RecordEvent(ts=0.2, event_type="uia.Invoke", control_path="Dialog > B[Open]"),
        ],
        thumbnails_dir=tmp_path / "notepad_001_thumbnails",
    )


def _persist_stub_trace(trace: RecordTrace) -> Path:
    """Write a minimal JSONL file next to the thumbnails dir.

    FIX 4: the record-replay generator now refuses to emit ``Replayer.from_file``
    calls unless the trace path exists on disk. Tests that want the
    happy-path body rendered must call this helper first.
    """
    target = trace.thumbnails_dir.parent / f"{trace.trace_id}.jsonl"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps({"_schema": "api-anything.record.v1", "stub": True}) + "\n",
        encoding="utf-8",
    )
    return target


def _mock_llm_client(method_specs: list[dict]) -> MagicMock:
    """Build a mock Anthropic-compatible client that returns the given specs."""
    client = MagicMock()
    response = MagicMock()
    response.content = [MagicMock(text=json.dumps(method_specs))]
    client.messages.create.return_value = response
    return client


class TestGenerateApiRecordBranch:
    def test_record_trace_dispatches_to_record_branch(self, tmp_path: Path) -> None:
        trace = _sample_trace(tmp_path)
        result = generate_api(software_name="notepad", record_trace=trace)
        assert result.generation_mode == "record_replay"
        assert result.api_class.class_name == "NotepadAPI"

    def test_record_branch_takes_priority_over_vision(self, tmp_path: Path) -> None:
        """When both record_trace AND vision_candidates are given, record wins."""
        trace = _sample_trace(tmp_path)
        result = generate_api(
            software_name="notepad",
            record_trace=trace,
            vision_candidates=[{"label": "Save", "bbox": (1, 2, 3, 4)}],
        )
        assert result.generation_mode == "record_replay"

    def test_record_no_client_emits_single_run_method(self, tmp_path: Path) -> None:
        trace = _sample_trace(tmp_path)
        result = generate_api(software_name="notepad", record_trace=trace)
        names = [m.name for m in result.api_class.methods]
        assert names == ["run"]

    def test_record_with_llm_client_uses_inferred_schema(self, tmp_path: Path) -> None:
        trace = _sample_trace(tmp_path)
        client = _mock_llm_client([
            {
                "name": "open_file",
                "docstring": "Open a file in Notepad.",
                "params": [{"name": "path", "type_hint": "str"}],
                "confidence": 78,
            }
        ])
        result = generate_api(
            software_name="notepad",
            record_trace=trace,
            llm_client=client,
        )
        names = [m.name for m in result.api_class.methods]
        assert "open_file" in names
        method = result.api_class.methods[0]
        assert method.operation_mode == "replay"
        assert method.internal_mode == "replay"
        assert method.generation_confidence == 78
        assert method.record_trace_id == "notepad_001"

    def test_record_method_body_contains_replayer_call(self, tmp_path: Path) -> None:
        trace = _sample_trace(tmp_path)
        # FIX 4: generator now checks trace file exists before emitting
        # Replayer.from_file — persist a stub JSONL so the "happy path" body
        # is rendered (not the FileNotFoundError stub).
        _persist_stub_trace(trace)
        client = _mock_llm_client([
            {
                "name": "open_file",
                "docstring": "Open.",
                "params": [{"name": "path", "type_hint": "str"}],
                "confidence": 75,
            }
        ])
        result = generate_api(
            software_name="notepad",
            record_trace=trace,
            llm_client=client,
        )
        assert "Replayer.from_file" in result.source_code
        assert "replayer.replay(path=path)" in result.source_code

    def test_generated_source_is_valid_python(self, tmp_path: Path) -> None:
        trace = _sample_trace(tmp_path)
        result = generate_api(software_name="notepad", record_trace=trace)
        # ast.parse raises SyntaxError on bad code — we want pass.
        ast.parse(result.source_code)

    def test_generated_result_has_generation_time(self, tmp_path: Path) -> None:
        trace = _sample_trace(tmp_path)
        result = generate_api(software_name="notepad", record_trace=trace)
        assert result.generation_time_seconds >= 0


class TestInferRecordMethodSchema:
    def test_no_client_returns_run_default(self, tmp_path: Path) -> None:
        trace = _sample_trace(tmp_path)
        specs = _infer_record_method_schema(trace, "notepad", client=None)
        assert len(specs) == 1
        assert specs[0]["name"] == "run"

    def test_llm_error_falls_back_to_run(self, tmp_path: Path) -> None:
        trace = _sample_trace(tmp_path)
        bad_client = MagicMock()
        bad_client.messages.create.side_effect = RuntimeError("boom")
        specs = _infer_record_method_schema(trace, "notepad", client=bad_client)
        assert specs[0]["name"] == "run"

    def test_llm_empty_list_falls_back(self, tmp_path: Path) -> None:
        trace = _sample_trace(tmp_path)
        client = _mock_llm_client([])
        specs = _infer_record_method_schema(trace, "notepad", client=client)
        assert specs[0]["name"] == "run"

    def test_llm_malformed_entries_filtered(self, tmp_path: Path) -> None:
        trace = _sample_trace(tmp_path)
        client = _mock_llm_client([
            {"name": "good"},
            {"no_name": "bad"},  # dropped
            "not_a_dict",        # dropped
        ])
        specs = _infer_record_method_schema(trace, "notepad", client=client)
        assert len(specs) == 1
        assert specs[0]["name"] == "good"

    def test_event_summary_cap_at_60(self, tmp_path: Path) -> None:
        """LLM prompt should cap events at 60 to bound token spend."""
        many_events = [
            RecordEvent(ts=i * 0.01, event_type="uia.Invoke", control_path=f"B{i}")
            for i in range(100)
        ]
        trace = RecordTrace(
            app_name="a",
            trace_id="a_001",
            started_at="2026-04-17T00:00:00+00:00",
            events=many_events,
            thumbnails_dir=tmp_path / "a_001_thumbnails",
        )
        client = _mock_llm_client([{"name": "run"}])
        _infer_record_method_schema(trace, "a", client=client)
        # Inspect the prompt sent to the LLM
        sent = client.messages.create.call_args
        user_msg = sent.kwargs["messages"][0]["content"]
        # Line "59." should be present; "60." should not (capped at 60 events).
        assert "\n59." in user_msg
        assert "\n60." not in user_msg


class TestBuildRecordAPIClass:
    def test_trace_id_set_on_methods(self, tmp_path: Path) -> None:
        trace = _sample_trace(tmp_path)
        cls = _build_record_api_class(
            trace=trace, software_name="notepad", tier="4", client=None,
        )
        assert cls.methods[0].record_trace_id == "notepad_001"

    def test_tier_preserved(self, tmp_path: Path) -> None:
        trace = _sample_trace(tmp_path)
        cls = _build_record_api_class(
            trace=trace, software_name="notepad", tier="3C", client=None,
        )
        assert cls.tier == "3C"


class TestDirectGenerateFromRecord:
    def test_direct_call_returns_generation_result(self, tmp_path: Path) -> None:
        trace = _sample_trace(tmp_path)
        result = _generate_from_record(
            trace,
            software_name="notepad",
            tier="4",
            client=None,
            t0=0.0,
        )
        assert result.generation_mode == "record_replay"
        assert result.api_class.tier == "4"

    def test_generation_time_non_negative(self, tmp_path: Path) -> None:
        trace = _sample_trace(tmp_path)
        result = _generate_from_record(
            trace,
            software_name="x",
            tier="4",
            client=None,
            t0=0.0,
        )
        assert result.generation_time_seconds >= 0


# ---------------------------------------------------------------------------
# FIX 4: POSIX-safe record_trace_path + existence check
# ---------------------------------------------------------------------------


class TestRecordTracePathSafety:
    def test_path_uses_forward_slashes(self, tmp_path: Path) -> None:
        """FIX 4: generated source must contain forward-slash paths."""
        trace = _sample_trace(tmp_path)
        _persist_stub_trace(trace)
        result = generate_api(software_name="notepad", record_trace=trace)
        # Windows backslash-in-string-literal is a correctness bug.
        assert "\\\\" not in result.source_code
        # Path in the method body should use /, not \ between segments.
        # Pick up the trace id reference specifically to avoid docstrings.
        assert "notepad_001.jsonl" in result.source_code

    def test_stub_path_is_posix_on_method(self, tmp_path: Path) -> None:
        """record_trace_path on APIMethod is posix-separated."""
        trace = _sample_trace(tmp_path)
        cls = _build_record_api_class(
            trace=trace, software_name="notepad", tier="4", client=None,
        )
        # Forward slash between grandparent and filename — never backslash.
        path_attr = cls.methods[0].record_trace_path
        assert path_attr is not None
        assert "\\" not in path_attr

    def test_missing_trace_raises_file_not_found_in_body(
        self, tmp_path: Path
    ) -> None:
        """FIX 4: trace not persisted → body raises FileNotFoundError stub."""
        trace = _sample_trace(tmp_path)  # No _persist_stub_trace call.
        result = generate_api(software_name="notepad", record_trace=trace)
        # Helpful message that points at Recorder.save.
        assert "FileNotFoundError" in result.source_code
        assert "Recorder.save" in result.source_code
        # Crucially: no Replayer.from_file call when trace is missing.
        assert "Replayer.from_file" not in result.source_code


# ---------------------------------------------------------------------------
# FIX 5: last_verified_at wired into replay docstring
# ---------------------------------------------------------------------------


class TestLastVerifiedAtReplay:
    def test_replay_docstring_includes_last_verified(
        self, tmp_path: Path
    ) -> None:
        trace = _sample_trace(tmp_path)
        _persist_stub_trace(trace)
        result = generate_api(software_name="notepad", record_trace=trace)
        # last_verified_at should be populated from trace.started_at.
        assert "last_verified_at: 2026-04-17T00:00:00+00:00" in result.source_code

    def test_replay_last_verified_matches_trace_started_at(
        self, tmp_path: Path
    ) -> None:
        trace = _sample_trace(tmp_path)
        cls = _build_record_api_class(
            trace=trace, software_name="notepad", tier="4", client=None,
        )
        assert cls.methods[0].last_verified_at == trace.started_at
