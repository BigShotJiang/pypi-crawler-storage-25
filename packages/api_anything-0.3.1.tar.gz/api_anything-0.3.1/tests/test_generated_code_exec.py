"""End-to-end exec() smoke tests for generated API modules.

FIX 8 (Red-team LOW → high-value): existing tests only ran ``ast.parse`` on
generated source. This file actually ``exec()``s the generated module into
a namespace, instantiates the API class, monkey-patches the runtime helpers
(``_locate_control`` / ``_click_at`` / ``Replayer.from_file``), and drives
the generated method. This is the only assertion path that would have
caught a missing ``Replayer.from_file`` call or a backslash-in-path literal.

Tests stay hermetic: no real VLM, no real mouse click, no real trace read.
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from api_anything.generator import generate_api
from api_anything.recorder import RecordEvent, RecordTrace
from api_anything.vision_runtime import VisionElement


def _exec_source(source: str) -> dict:
    """Compile + exec generated source into a fresh namespace."""
    ns: dict = {}
    exec(compile(source, "<generated>", "exec"), ns)
    return ns


class TestVisionEndToEndExec:
    """Vision-mode method compiles, exec()s, and invokes runtime helpers."""

    def test_vision_click_method_drives_runtime(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        elements = [
            VisionElement(label="Save", bbox=(100, 200, 150, 230), confidence=0.9),
        ]
        result = generate_api(
            "VSCode", controls=[], tier="4", vision_candidates=elements
        )
        # Patch the module-level helpers that the generated source imports
        # from api_anything.vision_runtime — the exec'd module will pick
        # these up when its `from api_anything.vision_runtime import ...`
        # line runs.
        locate_mock = MagicMock(return_value=(125, 215))
        click_mock = MagicMock()
        monkeypatch.setattr(
            "api_anything.vision_runtime._locate_control", locate_mock
        )
        monkeypatch.setattr(
            "api_anything.vision_runtime._click_at", click_mock
        )

        ns = _exec_source(result.source_code)
        # Class name derives from _to_class_name(software_name); "VSCode"
        # happens to normalise to "VscodeAPI" under the current rules.
        api_cls = ns[result.api_class.class_name]
        inst = api_cls()
        assert hasattr(inst, "click_save")
        inst.click_save()

        assert locate_mock.call_count == 1
        assert click_mock.call_count == 1
        click_mock.assert_called_with(125, 215)


class TestReplayEndToEndExec:
    """Replay-mode method compiles, exec()s, calls Replayer.from_file + replay."""

    def _trace_with_file(self, tmp_path: Path) -> RecordTrace:
        trace = RecordTrace(
            app_name="notepad",
            trace_id="notepad_001",
            started_at="2026-04-17T00:00:00+00:00",
            events=[
                RecordEvent(
                    ts=0.0, event_type="uia.Invoke", control_path="Win > B[File]"
                ),
            ],
            thumbnails_dir=tmp_path / "notepad_001_thumbnails",
        )
        # Persist a stub JSONL so the render emits the replay body.
        target = tmp_path / "notepad_001.jsonl"
        target.write_text(
            json.dumps({"_schema": "api-anything.record.v1", "stub": True}) + "\n",
            encoding="utf-8",
        )
        return trace

    def test_replay_method_drives_replayer(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        trace = self._trace_with_file(tmp_path)
        result = generate_api(software_name="notepad", record_trace=trace)

        replayer_stub = MagicMock()
        from_file_mock = MagicMock(return_value=replayer_stub)
        # The generated source does `from api_anything.replay import Replayer`,
        # so patch at that module.
        monkeypatch.setattr(
            "api_anything.replay.Replayer.from_file",
            from_file_mock,
        )

        ns = _exec_source(result.source_code)
        api_cls = ns["NotepadAPI"]
        inst = api_cls()
        assert hasattr(inst, "run")
        inst.run()

        # from_file called with a Path that points at the trace we wrote.
        assert from_file_mock.call_count == 1
        arg = from_file_mock.call_args.args[0]
        # Path() constructor accepts posix separators on Windows — the
        # generated literal should resolve to our on-disk file.
        assert Path(str(arg)).name == "notepad_001.jsonl"
        replayer_stub.replay.assert_called_once_with()
