import asyncio
from typing import Any
from unittest.mock import AsyncMock, Mock

import pytest
import pytest_asyncio

from moleculerpy.broker import Broker
from moleculerpy.decorators import action, event
from moleculerpy.errors import GracefulStopTimeoutError, ServiceNotFoundError
from moleculerpy.lifecycle import Lifecycle
from moleculerpy.node import NodeCatalog
from moleculerpy.registry import Registry
from moleculerpy.service import Service
from moleculerpy.settings import Settings
from moleculerpy.transit import Transit


class TestService(Service):
    __test__ = False

    def __init__(self):
        super().__init__(name="test")

    @action()
    async def hello(self, _):
        return "Hello!"

    @event()
    async def test_event(self, _):
        return "Event received"

    @event(name="custom.event")
    async def another_event(self, _):
        return "Custom event received"


@pytest.fixture(scope="function")
def mock_transit():
    transit = AsyncMock(spec=Transit)
    transit.connect = AsyncMock()
    transit.disconnect = AsyncMock()
    transit.transporter = Mock(name="mock_nats")
    return transit


@pytest.fixture
def mock_registry():
    registry = Mock(spec=Registry)
    registry.__services__ = {}
    registry.__actions__ = []  # Required for _wrap_service_handlers
    registry.__events__ = []  # Required for _wrap_service_handlers
    return registry


@pytest.fixture
def mock_node_catalog():
    catalog = Mock(spec=NodeCatalog)
    catalog.nodes = Mock()
    catalog.local_node = Mock()
    catalog.local_node.seq = 0
    return catalog


@pytest.fixture
def mock_lifecycle():
    return Mock(spec=Lifecycle)


@pytest_asyncio.fixture
async def broker(mock_transit, mock_registry, mock_node_catalog, mock_lifecycle):
    """Create a broker instance for testing."""
    settings = Settings(transporter="mock://localhost:4222")
    broker = Broker(
        "test-node",
        settings=settings,
        transit=mock_transit,
        registry=mock_registry,
        node_catalog=mock_node_catalog,
        lifecycle=mock_lifecycle,
    )
    yield broker
    # Clean up the broker when the test is done
    await broker.stop()


@pytest.mark.asyncio
async def test_broker_initialization(broker):
    assert broker.nodeID == "test-node"
    assert broker.version == "0.14.1"
    assert broker.namespace == "default"
    assert broker.registry is not None
    assert broker.transit is not None


@pytest.mark.asyncio
async def test_broker_start(broker, mock_transit):
    await broker.start()


@pytest.mark.asyncio
async def test_broker_stop(broker, mock_transit):
    await broker.stop()
    mock_transit.disconnect.assert_called_once()


@pytest.mark.asyncio
async def test_broker_stop_timeout_raises_graceful_stop_error(broker, mock_registry, mock_transit):
    """Broker stop should enforce optional graceful_stop_timeout."""
    service = Mock()
    service.name = "slow-service"

    async def slow_lifecycle(_hook: str) -> None:
        await asyncio.sleep(0.1)

    service._call_lifecycle_hook = AsyncMock(side_effect=slow_lifecycle)
    mock_registry.__services__ = {service.name: service}
    broker.settings.graceful_stop_timeout = 0.01

    with pytest.raises(GracefulStopTimeoutError):
        await broker.stop()

    # Reset test state for fixture teardown.
    broker.settings.graceful_stop_timeout = None
    mock_registry.__services__ = {}
    mock_transit.disconnect.assert_not_called()


@pytest.mark.asyncio
async def test_broker_register_service(broker, mock_registry, mock_node_catalog):
    service = TestService()
    await broker.register(service)
    mock_registry.register.assert_called_once_with(service)
    mock_node_catalog.ensure_local_node.assert_called_once()


@pytest.mark.asyncio
async def test_broker_call_local_action(broker, mock_registry, mock_lifecycle):
    endpoint = Mock(is_local=True)
    endpoint.handler = AsyncMock(return_value="result")
    endpoint.wrapped_handler = endpoint.handler  # New architecture uses wrapped_handler
    # Use get_action_endpoint for load-balanced endpoint selection
    mock_registry.get_action_endpoint.return_value = endpoint

    context = Mock()
    mock_lifecycle.create_context.return_value = context

    result = await broker.call("test.hello", {"param": "value"})

    assert result == "result"
    mock_registry.get_action_endpoint.assert_called_once_with("test.hello", context)
    endpoint.handler.assert_called_once_with(context)


@pytest.mark.asyncio
async def test_broker_call_passes_context_to_endpoint_selection(
    broker, mock_registry, mock_lifecycle
):
    """Endpoint selection should receive context (required by Shard strategy)."""
    endpoint = Mock(is_local=True)
    endpoint.handler = AsyncMock(return_value="result")
    endpoint.wrapped_handler = endpoint.handler

    context = Mock()
    mock_lifecycle.create_context.return_value = context
    mock_registry.get_action_endpoint.return_value = endpoint

    await broker.call("test.hello", {"id": "user-123"})

    mock_registry.get_action_endpoint.assert_called_once_with("test.hello", context)


@pytest.mark.asyncio
async def test_broker_call_remote_action(broker, mock_registry, mock_transit, mock_lifecycle):
    endpoint = Mock(is_local=False, node_id="remote-node")
    # Use get_action_endpoint for load-balanced endpoint selection
    mock_registry.get_action_endpoint.return_value = endpoint
    mock_transit.request.return_value = "remote result"

    context = Mock()
    mock_lifecycle.create_context.return_value = context

    result = await broker.call("remote.action")

    assert result == "remote result"
    mock_transit.request.assert_called_once_with(endpoint, context)


@pytest.mark.asyncio
async def test_broker_call_nonexistent_action(broker, mock_registry):
    # Use get_action_endpoint for load-balanced endpoint selection
    mock_registry.get_action_endpoint.return_value = None
    with pytest.raises(ServiceNotFoundError) as exc_info:
        await broker.call("nonexistent.action")
    assert exc_info.value.action_name == "nonexistent.action"
    assert exc_info.value.code == 404


@pytest.mark.asyncio
async def test_broker_emit_local_event(broker, mock_registry, mock_lifecycle):
    endpoint = Mock(is_local=True)
    endpoint.handler = AsyncMock()
    endpoint.wrapped_handler = endpoint.handler  # New architecture uses wrapped_handler
    mock_registry.get_event.return_value = endpoint

    context = Mock()
    mock_lifecycle.create_context.return_value = context

    await broker.emit("test_event", {"param": "value"})

    endpoint.handler.assert_called_once_with(context)


@pytest.mark.asyncio
async def test_broker_emit_remote_event(broker, mock_registry, mock_transit, mock_lifecycle):
    endpoint = Mock(is_local=False)
    mock_registry.get_event.return_value = endpoint

    context = Mock()
    mock_lifecycle.create_context.return_value = context

    await broker.emit("event_name")  # Using unprefixed event name

    mock_transit.send_event.assert_called_once_with(endpoint, context, broadcast=False)


@pytest.mark.asyncio
async def test_broker_broadcast_event(broker, mock_registry, mock_transit, mock_lifecycle):
    local_endpoint = Mock(is_local=True)
    local_endpoint.handler = AsyncMock()
    local_endpoint.wrapped_handler = local_endpoint.handler  # New architecture uses wrapped_handler
    remote_endpoint = Mock(is_local=False)

    mock_registry.get_all_events.return_value = [local_endpoint, remote_endpoint]

    context = Mock()
    marshalled = {"event": "test_event", "params": {}}
    context.marshall.return_value = marshalled
    mock_lifecycle.create_context.return_value = context

    await broker.broadcast("test_event")

    local_endpoint.handler.assert_called_once_with(context)
    mock_transit.send_event.assert_called_once_with(
        remote_endpoint,
        context,
        marshalled_context=marshalled,
        broadcast=True,
    )


@pytest.mark.asyncio
async def test_broker_broadcast_marshalls_once_for_multiple_remotes(
    broker, mock_registry, mock_transit, mock_lifecycle
):
    """Broadcast should serialize context once and reuse payload for fan-out."""
    remote_1 = Mock(is_local=False)
    remote_2 = Mock(is_local=False)
    mock_registry.get_all_events.return_value = [remote_1, remote_2]

    context = Mock()
    marshalled = {"event": "test_event", "params": {"x": 1}}
    context.marshall.return_value = marshalled
    mock_lifecycle.create_context.return_value = context

    await broker.broadcast("test_event", {"x": 1})

    context.marshall.assert_called_once_with()
    assert mock_transit.send_event.await_count == 2
    mock_transit.send_event.assert_any_await(
        remote_1,
        context,
        marshalled_context=marshalled,
        broadcast=True,
    )
    mock_transit.send_event.assert_any_await(
        remote_2,
        context,
        marshalled_context=marshalled,
        broadcast=True,
    )


@pytest.mark.asyncio
async def test_broker_broadcast_raises_when_handler_fails(broker, mock_registry, mock_lifecycle):
    """Broadcast should reject on handler failures (Moleculer.js Promise.all parity)."""
    failing_endpoint = Mock(is_local=True)
    failing_endpoint.handler = AsyncMock(side_effect=RuntimeError("handler boom"))
    failing_endpoint.wrapped_handler = failing_endpoint.handler
    mock_registry.get_all_events.return_value = [failing_endpoint]
    mock_lifecycle.create_context.return_value = Mock()

    with pytest.raises(RuntimeError, match="handler boom"):
        await broker.broadcast("test_event")


@pytest.mark.asyncio
async def test_wait_for_services_found_locally(broker, mock_registry):
    mock_registry.get_service.return_value = Mock()
    await broker.wait_for_services(["test"])
    mock_registry.get_service.assert_called_once_with("test")


@pytest.mark.asyncio
async def test_wait_for_services_found_remotely(broker, mock_registry, mock_node_catalog):
    mock_registry.get_service.return_value = None
    remote_node = Mock()
    remote_node.id = "remote-node"
    remote_node.services = [{"name": "test"}]
    mock_node_catalog.nodes.values.return_value = [remote_node]
    await broker.wait_for_services(["test"])


@pytest.mark.asyncio
async def test_find_missing_services_ignores_malformed_remote_entries(
    broker, mock_registry, mock_node_catalog
):
    """Remote service scan should ignore malformed entries instead of crashing."""
    mock_registry.get_service.return_value = None
    remote_node = Mock()
    remote_node.id = "remote-node"
    remote_node.services = [
        "not-a-dict",
        {"name": "users"},
        {"wrong": "shape"},
    ]
    mock_node_catalog.nodes.values.return_value = [remote_node]

    missing = broker._find_missing_services(["users", "orders"])

    assert missing == ["orders"]


@pytest.mark.asyncio
async def test_broker_call_local_action_with_error(broker, mock_registry, mock_lifecycle):
    # Set up a mock endpoint that raises an exception
    endpoint = Mock(is_local=True)
    endpoint.handler = AsyncMock(side_effect=ValueError("Test error"))
    endpoint.wrapped_handler = endpoint.handler  # New architecture uses wrapped_handler
    # Use get_action_endpoint for load-balanced endpoint selection
    mock_registry.get_action_endpoint.return_value = endpoint

    context = Mock()
    mock_lifecycle.create_context.return_value = context

    # Verify that the error is propagated
    with pytest.raises(ValueError, match="Test error"):
        await broker.call("test.error")

    mock_registry.get_action_endpoint.assert_called_once_with("test.error", context)
    endpoint.handler.assert_called_once_with(context)


@pytest.mark.asyncio
async def test_broker_call_remote_action_with_error(
    broker, mock_registry, mock_transit, mock_lifecycle
):
    endpoint = Mock(is_local=False, node_id="remote-node", name="remote.action")
    # Use get_action_endpoint for load-balanced endpoint selection
    mock_registry.get_action_endpoint.return_value = endpoint
    mock_transit.request.side_effect = Exception("RemoteError: Test error")

    context = Mock()
    mock_lifecycle.create_context.return_value = context

    # Verify that the remote error is propagated
    with pytest.raises(Exception, match="RemoteError: Test error"):
        await broker.call("remote.error")

    mock_transit.request.assert_called_once_with(endpoint, context)


def test_tracking_disabled_no_middleware():
    """Default settings — ContextTrackerMiddleware is NOT auto-registered."""
    from moleculerpy.middleware.context_tracker import ContextTrackerMiddleware

    broker = Broker(id="test-no-tracking")
    assert not any(isinstance(mw, ContextTrackerMiddleware) for mw in broker.middlewares)


def test_tracking_enabled_registers_middleware():
    """settings.tracking.enabled=True auto-registers ContextTrackerMiddleware."""
    from moleculerpy.middleware.context_tracker import ContextTrackerMiddleware
    from moleculerpy.settings import TrackingConfig

    settings = Settings(tracking=TrackingConfig(enabled=True, shutdown_timeout=2.5))
    broker = Broker(id="test-tracking", settings=settings)

    trackers = [mw for mw in broker.middlewares if isinstance(mw, ContextTrackerMiddleware)]
    assert len(trackers) == 1
    # Seconds (no conversion)
    assert trackers[0]._default_timeout == 2.5


# ---------------------------------------------------------------------------
# stopped alias: signature introspection (Node.js parity + legacy cleanup)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_stopped_alias_with_broker_arg():
    """Middleware with Node.js-style `stopped(broker)` receives broker arg."""
    from moleculerpy.middleware.base import Middleware

    captured: list[Any] = []

    class NodeStyleMW(Middleware):
        async def stopped(self, broker):  # type: ignore[override]
            captured.append(broker)

    broker = Broker(id="t-stopped-nodestyle")
    broker.middlewares.append(NodeStyleMW())
    await broker._execute_middleware_hooks("broker_stopped", broker)

    assert captured == [broker]


@pytest.mark.asyncio
async def test_stopped_alias_legacy_no_args():
    """Legacy middleware with `stopped(self)` is still called without broker."""
    from moleculerpy.middleware.base import Middleware

    calls: list[str] = []

    class LegacyMW(Middleware):
        async def stopped(self) -> None:  # 0-arg cleanup, legacy signature
            calls.append("cleanup")

    broker = Broker(id="t-stopped-legacy")
    broker.middlewares.append(LegacyMW())
    await broker._execute_middleware_hooks("broker_stopped", broker)

    assert calls == ["cleanup"]


@pytest.mark.asyncio
async def test_stopped_alias_skipped_when_no_override():
    """Default base Middleware.stopped() is NOT invoked via alias path."""
    from moleculerpy.middleware.base import Middleware

    mw = Middleware()  # no override
    broker = Broker(id="t-stopped-base")
    broker.middlewares.append(mw)
    # Should not raise; base no-op stopped() not invoked via alias path.
    await broker._execute_middleware_hooks("broker_stopped", broker)


@pytest.mark.asyncio
async def test_alias_signature_cached(monkeypatch):
    """inspect.signature must be called only once per (middleware, method)."""
    from moleculerpy import broker as broker_mod
    from moleculerpy.middleware.base import Middleware

    class MW(Middleware):
        async def stopped(self, broker: Any) -> None:
            pass

    broker = Broker(id="t-sig-cache")
    broker.middlewares.append(MW())

    real_signature = broker_mod.inspect.signature
    calls = {"n": 0}

    def counting_signature(obj: Any) -> Any:
        calls["n"] += 1
        return real_signature(obj)

    monkeypatch.setattr(broker_mod.inspect, "signature", counting_signature)

    await broker._execute_middleware_hooks("broker_stopped", broker)
    await broker._execute_middleware_hooks("broker_stopped", broker)
    await broker._execute_middleware_hooks("broker_stopped", broker)

    assert calls["n"] == 1


@pytest.mark.asyncio
async def test_register_increments_local_seq(broker, mock_transit, mock_node_catalog):
    """register() must bump local_node.seq so remote nodes notice the change."""
    local_node = Mock()
    local_node.seq = 1
    mock_node_catalog.local_node = local_node
    mock_transit.is_connected = False

    await broker.register(TestService())

    assert local_node.seq == 2


@pytest.mark.asyncio
async def test_register_broadcasts_info_when_connected(broker, mock_transit, mock_node_catalog):
    """When transit is already connected, register() must broadcast INFO."""
    local_node = Mock()
    local_node.seq = 5
    mock_node_catalog.local_node = local_node
    mock_transit.is_connected = True
    mock_transit.send_node_info = AsyncMock()

    await broker.register(TestService())

    assert local_node.seq == 6
    mock_transit.send_node_info.assert_awaited_once()


@pytest.mark.asyncio
async def test_register_no_broadcast_when_not_connected(broker, mock_transit, mock_node_catalog):
    """During broker.start(), transit isn't connected yet — no INFO broadcast."""
    local_node = Mock()
    local_node.seq = 0
    mock_node_catalog.local_node = local_node
    mock_transit.is_connected = False
    mock_transit.send_node_info = AsyncMock()

    await broker.register(TestService())

    assert local_node.seq == 1
    mock_transit.send_node_info.assert_not_called()


@pytest.mark.asyncio
async def test_register_idempotent(broker, mock_registry, mock_transit, mock_node_catalog):
    """Re-registering the same service must not bump seq or re-broadcast INFO.

    Hot reload and test teardown+reregister flows previously caused duplicate
    INFO storms because register() unconditionally incremented seq.
    """
    local_node = Mock()
    local_node.seq = 10
    mock_node_catalog.local_node = local_node
    mock_transit.is_connected = True
    mock_transit.send_node_info = AsyncMock()

    service = TestService()

    # First registration: seq bumps, INFO broadcast fires.
    await broker.register(service)
    assert local_node.seq == 11
    mock_transit.send_node_info.assert_awaited_once()

    # Simulate that the registry now knows about this service
    # (real Registry.register() populates __services__; mock doesn't).
    mock_registry.__services__[service.name] = service

    # Second registration of the same service must be a no-op for seq/INFO.
    await broker.register(service)
    assert local_node.seq == 11
    mock_transit.send_node_info.assert_awaited_once()
