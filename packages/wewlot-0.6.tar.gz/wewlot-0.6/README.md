# Tanıtım 
    wewlot sistemkar uydu protokolini 
    uygulayan basitleştirilmiş bir veriPyo olmakla birlikte dosya tabanlı veri 
    saklama kütüphanesi
    
## Kullanım ve fonksiyonlar

-  wewlot_database \=\ veri dosyasını oluşturma 

wewlot_database(
"wew_deneme",
control=deneme \=\ onay True/False
)
    
- wew_data_give \=\ kullanıcı veri başlığı ekleme

wew_data_give("wew_deneme", \=\ dosya adı
{"name": "kullanıcı", \=\ başlık adı 
"data": "Ali bulut", \=\ veri başlığı adı 
"data_id": "alikaya1234f5"}, \=\ benzersiz veri ID'si 
control=deneme \=\ onay True/False
)

- wew_data_add \=\ veri başlığına veri ekleme

wew_data_add("wew_deneme", \=\ dosya adı 
"alikaya1234f5", \=\ veri başlığı ID'si 
{"name": "yön", "data": "→"} \=\ veri ekleme başlık/veri
,control=deneme \=\ onay True/False
) 

- wew_data_get \=\ veri başlığından veri çekme

dene = wew_data_get("wew_deneme", \=\ verinin geleceği değişken/dosya adı 
"alikaya1234f5", \=\ benzersiz veri başlığı ID'si 
{"name": "yön"}, \=\ çekilecek veri başlığı 
control=deneme \=\ onay True/False
)

- wew_data_update \=\ veri güncelleme 

wew_data_update("wew_deneme", \=\ dosya adı 
"alikaya1234f5", \=\ benzersiz veri başlığı ID'si 
{"name": "yön", "data": "↓"}, \=\ güncellenecek veri başlığı/veri
control=deneme \=\ onay True/False
)

wewlot_server("True") \=\ server açma

DEVAM EDECEK...