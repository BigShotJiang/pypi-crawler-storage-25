# coding=utf-8
#
# my_llmkit 包的日志配置
# 遵循库的标准做法：只添加 NullHandler，让调用方决定日志输出目标
#

import logging

logging.getLogger("my_llmkit").addHandler(logging.NullHandler())
