# coding=utf-8
#
# db.py
# SQLite 数据库初始化与连接管理
#

import sqlite3
import logging
from contextlib import contextmanager
from typing import Generator

from .top import gede_db_path

logger = logging.getLogger(__name__)

_DDL = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS chats (
    chat_id                  TEXT PRIMARY KEY,
    title                    TEXT NOT NULL DEFAULT 'New Chat',
    model_path               TEXT NOT NULL DEFAULT '',
    is_private               INTEGER NOT NULL DEFAULT 0,
    instruction              TEXT,
    model_settings           TEXT NOT NULL DEFAULT '{}',
    message_num_in_context   INTEGER NOT NULL DEFAULT 6,
    forked_from_message_id   TEXT,
    created_at               TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at               TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS messages (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    message_id  TEXT UNIQUE,
    chat_id     TEXT NOT NULL,
    role        TEXT NOT NULL,
    text        TEXT,
    attachments TEXT,
    position    INTEGER NOT NULL,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (chat_id) REFERENCES chats(chat_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_messages_chat_id ON messages(chat_id);
CREATE INDEX IF NOT EXISTS idx_chats_updated_at ON chats(updated_at);
CREATE INDEX IF NOT EXISTS idx_messages_text    ON messages(text);
"""


_MIGRATE_INSTRUCTION_NULLABLE = """
BEGIN;
CREATE TABLE IF NOT EXISTS chats_v2 (
    chat_id                TEXT PRIMARY KEY,
    title                  TEXT NOT NULL DEFAULT 'New Chat',
    model_path             TEXT NOT NULL DEFAULT '',
    is_private             INTEGER NOT NULL DEFAULT 0,
    instruction            TEXT,
    model_settings         TEXT NOT NULL DEFAULT '{}',
    message_num_in_context INTEGER NOT NULL DEFAULT 6,
    created_at             TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at             TEXT NOT NULL DEFAULT (datetime('now'))
);
INSERT OR IGNORE INTO chats_v2
    SELECT chat_id, title, model_path, is_private, NULL,
           model_settings, message_num_in_context, created_at, updated_at
    FROM chats;
DROP TABLE chats;
ALTER TABLE chats_v2 RENAME TO chats;
COMMIT;
"""


def _needs_fork_migration(conn: sqlite3.Connection) -> bool:
    """检查 chats 表是否缺少 forked_from_message_id 列"""
    rows = conn.execute("PRAGMA table_info(chats)").fetchall()
    return not any(row[1] == "forked_from_message_id" for row in rows)


def _migrate_fork_message_id(conn: sqlite3.Connection) -> None:
    """为 chats 表添加 forked_from_message_id 列"""
    conn.execute("ALTER TABLE chats ADD COLUMN forked_from_message_id TEXT")
    conn.commit()


def _needs_instruction_migration(conn: sqlite3.Connection) -> bool:
    """检查 chats.instruction 列是否仍有 NOT NULL 约束"""
    rows = conn.execute("PRAGMA table_info(chats)").fetchall()
    for row in rows:
        if row[1] == "instruction" and row[3] == 1:  # row[3]=notnull
            return True
    return False


def _needs_message_id_migration(conn: sqlite3.Connection) -> bool:
    """检查 messages 表是否缺少 message_id 列"""
    rows = conn.execute("PRAGMA table_info(messages)").fetchall()
    return not any(row[1] == "message_id" for row in rows)


def _migrate_message_id(conn: sqlite3.Connection) -> None:
    """为 messages 表添加 message_id 列，并为旧行生成 UUID"""
    import uuid
    conn.execute("ALTER TABLE messages ADD COLUMN message_id TEXT")
    rows = conn.execute("SELECT id FROM messages WHERE message_id IS NULL").fetchall()
    for row in rows:
        conn.execute(
            "UPDATE messages SET message_id = ? WHERE id = ?",
            ("msg-" + str(uuid.uuid4()), row[0]),
        )
    conn.execute(
        "CREATE UNIQUE INDEX IF NOT EXISTS idx_messages_message_id ON messages(message_id)"
    )
    conn.commit()


def init_db() -> None:
    """初始化数据库：创建表和索引（幂等操作）"""
    db_path = gede_db_path()
    try:
        conn = sqlite3.connect(db_path)
        conn.executescript(_DDL)
        # 迁移旧数据库：将 instruction 列改为可 NULL（消除明文隐私风险）
        if _needs_instruction_migration(conn):
            logger.info("Migrating chats.instruction to nullable...")
            conn.executescript(_MIGRATE_INSTRUCTION_NULLABLE)
        # 迁移旧数据库：为 messages 表添加 message_id 列
        if _needs_message_id_migration(conn):
            logger.info("Migrating messages: adding message_id column...")
            _migrate_message_id(conn)
        # 迁移旧数据库：为 chats 表添加 forked_from_message_id 列
        if _needs_fork_migration(conn):
            logger.info("Migrating chats: adding forked_from_message_id column...")
            _migrate_fork_message_id(conn)
        conn.close()
        logger.debug("Database initialized at %s", db_path)
    except Exception as e:
        logger.error("Failed to initialize database: %s", e)
        raise


def get_connection() -> sqlite3.Connection:
    """返回一个已启用 WAL 模式和外键约束的 SQLite 连接"""
    conn = sqlite3.connect(gede_db_path())
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA foreign_keys=ON;")
    conn.row_factory = sqlite3.Row
    return conn


@contextmanager
def db_conn() -> Generator[sqlite3.Connection, None, None]:
    """上下文管理器：自动提交或回滚，关闭连接"""
    conn = get_connection()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
