# coding=utf-8
#
# gede.py
# main 入口文件
#

import os
import sys
import json
import logging
import asyncio
import unicodedata
import argparse
import tty
import termios
from typing import Optional

from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory, InMemoryHistory
from prompt_toolkit.completion import WordCompleter
from prompt_toolkit.styles import Style
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit.patch_stdout import patch_stdout
from prompt_toolkit.application import run_in_terminal
from prompt_toolkit.key_binding import KeyBindings

from . import config
from my_llmkit.chat.tools import ToolFunctions
from my_llmkit.mcp.mcp_config import get_mcp_servers

from .clipboard import (
    InputState,
    get_clipboard_image,
    get_clipboard_text,
    fmt_to_media_type,
    image_to_base64,
)
from my_llmkit.chat.types import ImageContent
from typing import Literal, cast as type_cast

from .top import (
    console,
    gede_cache_dir,
    gede_logs_dir,
    gede_mcp_config_path,
)
from .version import get_app_version
from .commands import do_command, get_command_hints

from .chatcore import ChatModel
from .profiles import get_profile
from .context import Context
from .llm.providers import get_provider_from_model_path, prepare_models
from .display import MessageRenderer, NotificationRenderer, render_startup_logo
from .llm.tools.tools import get_tools

logger = logging.getLogger(__name__)


def setup_logging(level: str | None = None):
    """统一配置日志：将所有日志写入文件，不输出到终端，避免污染 TUI 显示。

    日志文件位于 ~/.gede/cache/gede.log。
    level 为 None 时默认使用 INFO 级别。
    """
    from logging.handlers import RotatingFileHandler

    log_file = os.path.join(gede_logs_dir(), "gede.log")
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )
    # 单文件最大 5MB，保留最近 3 个备份（gede.log.1 / .2 / .3）
    file_handler = RotatingFileHandler(
        log_file, maxBytes=5 * 1024 * 1024, backupCount=3, encoding="utf-8"
    )
    file_handler.setFormatter(formatter)

    log_level = (level or "INFO").upper()

    for name in ("gede", "my_llmkit"):
        lgr = logging.getLogger(name)
        lgr.setLevel(log_level)
        lgr.propagate = False
        # 清除旧 handler（可能有 StreamHandler），替换为文件 handler
        lgr.handlers.clear()
        lgr.addHandler(file_handler)

    # 仅在明确指定 level 时才配置 SDK 日志（默认这些库不主动输出）
    if level:
        for name in ("openai", "anthropic", "httpx", "httpcore"):
            lgr = logging.getLogger(name)
            lgr.setLevel(log_level)
            lgr.propagate = False
            if not lgr.handlers:
                lgr.addHandler(file_handler)


def clean_unicode_text(text):
    """Clean problematic Unicode characters from text"""
    # Remove surrogate pair characters
    text = "".join(char for char in text if not (0xD800 <= ord(char) <= 0xDFFF))
    # Normalize Unicode characters
    text = unicodedata.normalize("NFC", text)
    return text


def input_history():
    filename = os.path.join(gede_cache_dir(), "input_history.txt")
    history = FileHistory(filename)
    return history


def create_prompt_style():
    """Create prompt style"""
    return Style.from_dict(
        {
            "username": "#87d7ff bold",
            "private": "#ffa500 bold",
            "symbol": "#00aaaa",
        }
    )


def make_key_bindings(state: InputState) -> KeyBindings:
    """
    创建按键绑定：
      Ctrl+Y → 读取剪贴板
               - 图片：暂存到 state，并用 run_in_terminal 提示信息
               - 文本：插入到当前输入框
    """
    kb = KeyBindings()

    @kb.add("c-y")
    def paste_from_clipboard(event):
        image_result = get_clipboard_image()
        if image_result:
            data, fmt = image_result
            state.add_image(data, fmt)
            count = len(state.images)
            size_kb = len(data) / 1024
            msg = f"📷 Image pasted #{count} | Format: {fmt} | Size: {size_kb:.1f} KB"
            run_in_terminal(lambda m=msg: print(m))
            return

        text = get_clipboard_text()
        if text:
            event.current_buffer.insert_text(text)
        else:
            run_in_terminal(
                lambda: print("(Clipboard is empty or content cannot be read)")
            )

    return kb


async def watch_for_escape(cancel_event: asyncio.Event):
    """监听 ESC 按键。检测到后设置 cancel_event。

    流式输出期间 prompt_toolkit 未激活，需临时将 stdin 切换到 cbreak 模式
    （逐字符、无回显），通过 asyncio add_reader 异步监听。
    finally 块确保终端设置在任意情况下都被恢复。
    """
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    loop = asyncio.get_event_loop()

    def on_key():
        try:
            ch = os.read(fd, 1)
            if ch == b"\x1b":  # ESC
                cancel_event.set()
        except OSError:
            pass

    try:
        tty.setcbreak(fd)
        loop.add_reader(fd, on_key)
        await cancel_event.wait()
    finally:
        loop.remove_reader(fd)
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)


async def get_input_message(
    completer: WordCompleter,
    session: PromptSession,
    style: Style,
    is_private: bool = False,
) -> tuple[str, InputState]:
    prompt_text_public = HTML("<username>You</username><symbol>: </symbol>")
    prompt_text_private = HTML("<private>You (Private)</private><symbol>: </symbol>")
    continuation_prompt = "... "

    state = InputState()
    kb = make_key_bindings(state)
    lines = []
    is_first_line = True

    while True:
        # 根据是否是第一行选择提示符
        if is_first_line:
            prompt = prompt_text_private if is_private else prompt_text_public
        else:
            prompt = continuation_prompt

        # 获取一行输入
        with patch_stdout():
            line = await session.prompt_async(
                prompt,
                completer=completer if is_first_line else None,  # 只在第一行启用补全
                style=style,
                multiline=False,
                key_bindings=kb if is_first_line else None,
            )

        # 如果第一行单独输入 \，切换到真正的多行编辑器（用于粘贴多行文本）
        if is_first_line and line.strip() == "\\":
            console.print("[dim]Multi-line mode. Press Esc+Enter to submit.[/dim]")
            with patch_stdout():
                message = await session.prompt_async(
                    "... ",
                    style=style,
                    multiline=True,
                    prompt_continuation="... ",
                    key_bindings=kb,
                )
            return clean_unicode_text(message.strip()), state

        # 检查是否以 \ 结尾（续行）
        if line.rstrip().endswith("\\"):
            # 去掉行尾的 \，保存该行
            lines.append(line.rstrip()[:-1].rstrip())
            is_first_line = False
            continue
        else:
            # 不以 \ 结尾，添加该行并结束输入
            lines.append(line)
            break

    # 合并所有行
    message = "\n".join(lines).strip()
    message = clean_unicode_text(message)
    return message, state


async def chat(context: Context):
    input_message = context.current_chat.get_messages_to_talk()
    model_path = context.current_chat.model_path
    model_info = await context.current_chat.model

    # 根据 model_path 自动选择合适的 Provider
    provider = get_provider_from_model_path(model_path)
    if not provider:
        logger.error(f"Provider not found for model_path: {model_path}")
        context.notification_display.error(
            f"找不到模型路径对应的 Provider: {model_path}"
        )
        return

    # 创建消息渲染器
    renderer = MessageRenderer(console)
    renderer.show_loading("Assistant is thinking")

    chat_client = provider.get_chat_client(
        model_info.model_id, context.current_chat.model_settings
    )

    tools: Optional[ToolFunctions] = None
    if context.tools:
        tools = get_tools(*context.tools)

    runner = chat_client.run_stream(
        messages=input_message,
        tools=tools,
        mcp_servers=context.mcp_servers if context.mcp_servers else None,
    )

    # 用 dict 收集缓冲（避免 nonlocal）
    buffers = {"answer": "", "reasoning": ""}

    async def _stream_loop():
        async for event in runner.stream_event():
            renderer.render_event(event)
            if event.type == "reasoning_content":
                buffers["reasoning"] += event.content
            elif event.type == "content":
                buffers["answer"] += event.content

    cancel_event = asyncio.Event()
    stream_task = asyncio.create_task(_stream_loop())
    escape_task = asyncio.create_task(watch_for_escape(cancel_event))
    # 用一个等待 cancel_event 的 task 和 stream_task 赛跑
    cancel_waiter = asyncio.create_task(cancel_event.wait())

    try:
        done, _ = await asyncio.wait(
            [stream_task, cancel_waiter],
            return_when=asyncio.FIRST_COMPLETED,
        )

        if cancel_event.is_set():
            # ESC 被按下：取消流式 Task，CancelledError 会沿调用链关闭 HTTP stream
            stream_task.cancel()
            try:
                await stream_task
            except (asyncio.CancelledError, Exception):
                pass
            renderer.stop_loading()
            renderer.finish_message()
            context.notification_display.warning("⊘ Interrupted")
            # 不保存不完整的助手消息
        else:
            # 正常完成
            cancel_waiter.cancel()
            try:
                await stream_task
            except Exception as e:
                logger.error(f"Error during chat streaming: {e}")
                context.notification_display.error(f"Error during chat: {e}")
                renderer.finish_message()
                return
            context.current_chat.append_assistant_message(buffers["answer"])
            renderer.finish_message()
    finally:
        # 确保 escape watcher 被清理，终端设置得到恢复
        escape_task.cancel()
        try:
            await escape_task
        except (asyncio.CancelledError, Exception):
            pass
        cancel_waiter.cancel()


async def run_main():
    """
    cli
    """
    parser = argparse.ArgumentParser(description="Chat with an LLM.")
    # Parameter --log-level
    parser.add_argument(
        "--log-level",
        type=str,
        default=None,
        choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
        help="Set log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)",
    )
    # Parameter --model
    parser.add_argument(
        "--model",
        type=str,
        help="Specify default model (format: provider_id:model_id, e.g.: openai:gpt-4o)",
    )
    # Parameter --instruction
    parser.add_argument(
        "--instruction",
        type=str,
        help="Set system prompt (equivalent to executing /set-instruction command)",
    )
    # Parameter --private
    parser.add_argument(
        "--private",
        action="store_true",
        help="Start private session (equivalent to executing /new-private command)",
    )
    # Parameter --tools
    parser.add_argument(
        "--tools",
        type=str,
        help="Set enabled tools list (multiple tools separated by commas, e.g.: --tools web_search,now,read_page)",
    )
    # Parameter --prompts
    parser.add_argument(
        "--prompts",
        type=str,
        default=None,
        help="Send a prompt directly and exit (use --prompts=- to read from stdin via pipe)",
    )
    # Parameter --mcp-servers
    parser.add_argument(
        "--mcp-servers",
        type=str,
        help="Set enabled MCP servers list (multiple servers separated by commas, e.g.: --mcp-servers filesystem,context7)",
    )
    # Parameter --profile
    parser.add_argument(
        "--profile",
        type=str,
        default=None,
        help="Specify a profile name to load preset CLI parameters from profiles.json",
    )
    args = parser.parse_args()

    # Load profile and use as defaults (CLI args take precedence)
    if args.profile is not None:
        profile = get_profile(args.profile)
        if args.model is None and profile.model is not None:
            args.model = profile.model
        if args.instruction is None and profile.instruction is not None:
            args.instruction = profile.instruction
        if args.log_level is None and profile.log_level is not None:
            args.log_level = profile.log_level
        if args.tools is None and profile.tools is not None:
            args.tools = ",".join(profile.tools)
        if args.mcp_servers is None and profile.mcp_servers is not None:
            args.mcp_servers = ",".join(profile.mcp_servers)
        if not args.private and profile.private:
            args.private = True

    pipe_prompt = None
    if args.prompts is not None:
        if args.prompts == "-":
            pipe_prompt = sys.stdin.read()
        else:
            pipe_prompt = args.prompts

    # 尽早初始化日志，确保后续所有模块的日志都写入文件而不是终端
    setup_logging(args.log_level)

    render_startup_logo(console=console, app_name="Gede", version=get_app_version())

    # 初始化 SQLite 数据库
    from .db import init_db

    init_db()

    history = InMemoryHistory()
    completer = WordCompleter(get_command_hints(), ignore_case=True, sentence=True)
    style = create_prompt_style()
    session = PromptSession()

    await prepare_models()
    current_chat = ChatModel(is_private=args.private)

    # args
    if args.model:
        current_chat.model_path = args.model
    if args.instruction:
        current_chat.instruction = args.instruction

    # 尝试加载 MCP 服务器配置
    # mcp.json 的 enable 字段是前提条件（必须为 true 才允许启动）
    # CLI/profile 中的 mcp_servers 列表是触发条件（必须指定才会实际启动）
    # 两者同时满足，对应服务器才会启动
    mcp_config_path = gede_mcp_config_path()
    stack = None
    mcp_servers = {}

    if args.mcp_servers and os.path.exists(mcp_config_path):
        notification = NotificationRenderer(console)
        allowed = {s.strip() for s in args.mcp_servers.split(",")}
        try:
            logger.debug(f"正在加载 MCP 配置: {mcp_config_path}")
            # 只启动同时满足 enable=true 且在 allowed 列表中的服务器
            mcp_servers, stack = await get_mcp_servers(
                mcp_config_path, allowed_names=allowed
            )
            logger.debug(f"成功加载 {len(mcp_servers)} 个 MCP 服务器")
            notification.info(f"成功加载 {len(mcp_servers)} 个 MCP 服务器")

            # 显式初始化所有服务器，确保所有输出都在用户输入前完成
            for name, server in mcp_servers.items():
                try:
                    tools = await server.list_tools()
                    logger.debug(f"服务器 {name} 提供 {len(tools)} 个工具")
                except Exception as e:
                    logger.warning(f"初始化服务器 {name} 的工具列表失败: {e}")

            # 短暂延迟，确保所有子进程的 stderr 输出完成
            # await asyncio.sleep(0.3)
        except Exception as e:
            logger.warning(f"加载 MCP 配置失败: {e}")
            notification.warning(f"MCP 配置加载失败: {e}")
            notification.dim("继续运行但无 MCP 工具支持")
    elif not args.mcp_servers:
        logger.debug("未指定 mcp_servers，跳过 MCP 服务器加载")
    else:
        logger.debug(f"MCP 配置文件不存在: {mcp_config_path}")

    context = Context(
        current_chat=current_chat,
        console=console,
        prompt_session=session,
        mcp_servers=mcp_servers,
    )

    if args.tools:
        tools = [t.strip() for t in args.tools.split(",")] if args.tools else []
        context.tools = tools

    await context.print_chat_info()

    if pipe_prompt:
        pipe_prompt = pipe_prompt.strip()
        if pipe_prompt:
            context.current_chat.append_user_message(pipe_prompt)
            await chat(context)
            console.print()
        if stack:
            await stack.aclose()
        return

    context.notification_display.dim(
        "Tip: Type \\ for multi-line input, or end a line with \\ to continue input on the next line."
    )

    try:
        while True:
            message, input_state = await get_input_message(
                completer=completer,
                session=session,
                style=style,
                is_private=context.current_chat.is_private,
            )

            if (
                not message
                and not input_state.has_images
                and not context.pending_images
            ):
                context.notification_display.warning("Input cannot be empty.")
                continue

            console.print()
            context.message = message
            should_continue = await do_command(context)
            # After command execution, do not continue
            if not should_continue:
                console.print()
                continue

            # 将剪贴板图片 (bytes, fmt) 转为 ImageContent，与 pending_images 合并
            clipboard_image_contents: list[ImageContent] = []
            for data, fmt in input_state.images:
                b64 = image_to_base64(data)
                media_type = fmt_to_media_type(fmt)
                clipboard_image_contents.append(
                    ImageContent.from_base64(
                        base64_data=b64,
                        media_type=type_cast(
                            Literal[
                                "image/jpeg", "image/png", "image/gif", "image/webp"
                            ],
                            media_type,
                        ),
                    )
                )
            all_images = context.pending_images + clipboard_image_contents
            context.pending_images = []
            context.current_chat.append_user_message(message, images=all_images)
            # console.print(f"You entered: {message}")
            await chat(context)

            console.print()
    finally:
        # 清理 MCP 服务器连接
        if stack:
            await stack.aclose()


def main():
    asyncio.run(run_main())


if __name__ == "__main__":
    main()
