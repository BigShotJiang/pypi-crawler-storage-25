# coding=utf-8
#
# image_commands.py
# Image-related commands
#

from typing import Optional

from prompt_toolkit.application import run_in_terminal

from .base import CommandBase
from my_llmkit.chat.types import ImageContent


class AddImageCommand(CommandBase):
    """
    /add-image <路径或URL>

    将图片附加到下一条消息。支持：
    - 本地文件路径（jpg/jpeg/png/gif/webp）
    - HTTP/HTTPS 图片 URL

    可多次执行以附加多张图片。
    """

    async def do_command_async(self) -> bool:
        cmd = "/add-image"
        if not self.context.message or not self.context.message.strip().lower().startswith(cmd):
            return True

        # 取出参数（保留原始大小写，路径/URL 区分大小写）
        raw = self.context.message.strip()
        arg = raw[len(cmd):].strip()

        if not arg:
            self.context.notification_display.warning(
                "Usage: /add-image <local path or image URL>"
            )
            return False

        try:
            if arg.startswith("http://") or arg.startswith("https://"):
                img = ImageContent.from_url(arg)
                label = f"URL: {arg}"
            else:
                from pathlib import Path
                path = Path(arg).expanduser()
                img = ImageContent.from_file(path)
                size_kb = path.stat().st_size / 1024
                label = f"{path.name} | {img.media_type} | {size_kb:.1f} KB"

            self.context.pending_images.append(img)
            count = len(self.context.pending_images)
            msg = f"🖼  Image added #{count} | {label}"
            run_in_terminal(lambda m=msg: print(m))

        except FileNotFoundError as e:
            self.context.notification_display.error(str(e))
        except ValueError as e:
            self.context.notification_display.error(str(e))
        except Exception as e:
            self.context.notification_display.error(f"Failed to add image: {e}")

        return False

    @property
    def doc_title(self) -> str:
        return "/add-image <PATH|URL>\nAttach an image to the next message"

    @property
    def doc_description(self) -> str:
        return (
            "Attach an image to the next message. Accepts a local file path "
            "(jpg/jpeg/png/gif/webp) or an HTTP/HTTPS URL. "
            "Run the command multiple times to attach multiple images. "
            "A confirmation is printed after each addition."
        )

    @property
    def command_hint(self) -> Optional[str | tuple[str, ...]]:
        return "/add-image"
