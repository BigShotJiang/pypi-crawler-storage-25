# coding=utf-8
#
# chat_commands.py
# Chat-related commands
#

import sys
from typing import Optional

from .base import CommandBase
from .common import cleanup_screen


class NewPublicChatCommand(CommandBase):
    async def do_command_async(self) -> bool:
        if self.message == "/new":
            from ..chatcore import ChatModel

            self.context.current_chat = ChatModel(is_private=False)
            self.context.print_rule("NEW CHAT")
            await self.context.print_chat_info()
            self.context.print_instruction()
            self.context.info_display.new_line()
            return False
        return True

    @property
    def doc_title(self) -> str:
        return "/new\nStart a new public chat"

    @property
    def doc_description(self) -> str:
        return "Messages are saved in plain text. Use /save to persist the chat; after the first save, new messages are automatically saved."

    @property
    def command_hint(self) -> Optional[str | tuple[str, ...]]:
        return "/new"


class NewPrivateChatCommand(CommandBase):
    async def do_command_async(self) -> bool:
        if self.message == "/new-private":
            from ..chatcore import ChatModel

            self.context.current_chat = ChatModel(is_private=True)
            self.context.info_display.rule("NEW CHAT (Private)")
            await self.context.print_chat_info()
            self.context.print_instruction()
            self.context.info_display.new_line()
            return False
        return True

    @property
    def doc_title(self) -> str:
        return "/new-private\nStart a new private chat"

    @property
    def doc_description(self) -> str:
        return "Messages are encrypted with a password you set when saving. Private chats must be manually saved using the /save command."

    @property
    def command_hint(self) -> Optional[str | tuple[str, ...]]:
        return "/new-private"


class QuitCommand(CommandBase):
    async def do_command_async(self) -> bool:
        if self.message == "/quit":
            self.context.notification_display.info("Goodbye!")
            if self.context.current_chat.is_private:
                cleanup_screen()
            sys.exit(0)
            # return False
        return True

    @property
    def doc_title(self) -> str:
        return "/quit\nExit the chat application"

    @property
    def doc_description(self) -> str:
        return "Safely exit the chat application. Unsaved private chats will remain in memory but not persist after exit."

    @property
    def command_hint(self) -> Optional[str | tuple[str, ...]]:
        return "/quit"


class ChatInfoCommand(CommandBase):
    async def do_command_async(self) -> bool:
        if self.message == "/chat-info":
            await self.context.print_chat_info()
            return False
        return True

    @property
    def doc_title(self) -> str:
        return "/chat-info\nDisplay current chat details"

    @property
    def doc_description(self) -> str:
        return "Display comprehensive information about the current chat session, including chat ID, title, privacy status, model, instruction, number of messages in context, and total messages. Also shows enabled tools and MCP servers."

    @property
    def command_hint(self) -> Optional[str | tuple[str, ...]]:
        return "/chat-info"


class CloneChatCommand(CommandBase):
    async def do_command_async(self) -> bool:
        from copy import deepcopy

        command = "/clone-chat"
        if self.message == command:
            old_chat = self.context.current_chat
            from ..chatcore import ChatModel

            clone_chat = ChatModel(is_private=old_chat.is_private)
            clone_chat.set_instruction(old_chat.instruction)
            clone_chat.model_path = old_chat.model_path
            clone_chat.message_num_in_context = old_chat.message_num_in_context
            clone_chat.user_model_settings = deepcopy(old_chat.user_model_settings)
            self.context.current_chat = clone_chat
            self.context.print_rule(
                f"NEW CHAT{' (Private)' if clone_chat.is_private else ''}"
            )
            await self.context.print_chat_info()
            self.context.print_instruction()
            self.context.info_display.new_line()
            return False
        return True

    @property
    def command_hint(self) -> Optional[str | tuple[str, ...]]:
        return "/clone-chat"

    @property
    def doc_title(self) -> str:
        return "/clone-chat \nClone the current chat to a new chat session"

    @property
    def doc_description(self) -> str:
        return "Create a new chat session that inherits all settings from the current chat (instruction, model, message context size, and model parameters). Useful for starting a fresh conversation with the same configuration."


class ForkChatCommand(CommandBase):
    async def do_command_async(self) -> bool:
        command = "/fork-chat"
        if self.message == command:
            old_chat = self.context.current_chat
            fork = old_chat.fork_from_last_assistant()
            if fork is None:
                self.context.notification_display.warning(
                    "No assistant message found. Cannot fork chat."
                )
                return False
            self.context.current_chat = fork
            self.context.print_rule(
                f"FORK CHAT{' (Private)' if fork.is_private else ''}"
            )
            await self.context.print_chat_info()
            self.context.print_instruction()
            self.context.notification_display.info(
                f"Forked from message: {fork.forked_from_message_id}. "
                "Use /save to persist this chat."
            )
            self.context.info_display.new_line()
            return False
        return True

    @property
    def command_hint(self) -> Optional[str | tuple[str, ...]]:
        return "/fork-chat"

    @property
    def doc_title(self) -> str:
        return "/fork-chat\nFork the current chat from the last assistant message"

    @property
    def doc_description(self) -> str:
        return (
            "Create a new chat session by copying all messages up to and including "
            "the last assistant message. Inherits settings (model, instruction, etc.) "
            "and copies attachments. The fork is not saved automatically — use /save to persist it."
        )
