# coding=utf-8
#
# base.py
# Base command class and context
#

from __future__ import annotations  # 启用延迟注解解析

from typing import List, Optional, TYPE_CHECKING


from ..context import Context as CommandContext

# 仅用于类型检查时导入，避免循环导入
if TYPE_CHECKING:
    from ..chatcore import ChatModel


class CommandBase:
    def __init__(self, context: CommandContext):
        self.context = context
        self.console = context.console
        self.message = context.message.strip().lower() if context.message else ""

    def do_command(self) -> bool:
        """
        Execute command
        Returns: whether to continue subsequent execution
        """
        raise NotImplementedError("Subclasses must implement do_command method")

    async def do_command_async(self) -> bool:
        return True

    @property
    def doc_title(self) -> str:
        return ""

    @property
    def doc_description(self) -> str:
        return ""

    @property
    def command_hint(self) -> Optional[str | tuple[str, ...]]:
        return None
