# coding=utf-8
#
# file_commands.py
# File-related commands
#

import os
import re
import json
import asyncio
import logging
from dataclasses import dataclass
from typing import Optional, Union
from pathlib import Path


from prompt_toolkit.application import Application
from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.layout import Layout
from prompt_toolkit.layout.containers import HSplit, Window
from prompt_toolkit.layout.controls import FormattedTextControl, BufferControl
from prompt_toolkit.buffer import Buffer
from prompt_toolkit.patch_stdout import patch_stdout
from rich.prompt import Prompt

from ..top import gede_dir
from .base import CommandBase
from ..chatcore import (
    ExportChat,
    ChatModel,
    load_public_chats,
    load_private_chats,
)
from my_llmkit.chat import ContentBlock
from my_llmkit.chat.types import TextContent, ImageContent

logger = logging.getLogger(__name__)

# Characters invalid in XML 1.0 (except \t \n \r)
_XML_INVALID_RE = re.compile(
    r"[^\x09\x0A\x0D\x20-\uD7FF\uE000-\uFFFD\U00010000-\U0010FFFF]"
)

# ---------------------------------------------------------------------------
# Chat search index (SQLite-based)
# ---------------------------------------------------------------------------


@dataclass
class ChatIndexEntry:
    chat_id: str
    title: str
    text: str  # merged text of all messages (for searching)
    preview: str  # first user message snippet (for display)
    updated_at: str = ""


def _build_chat_search_index() -> list[ChatIndexEntry]:
    """从 SQLite 构建公开对话的内存搜索索引"""
    from ..db import db_conn

    entries: list[ChatIndexEntry] = []
    try:
        with db_conn() as conn:
            rows = conn.execute(
                """
                SELECT c.chat_id, c.title, c.updated_at,
                       GROUP_CONCAT(CASE WHEN m.role != 'system' THEN m.text END, ' ') AS all_text,
                       (SELECT m2.text FROM messages m2
                        WHERE m2.chat_id = c.chat_id AND m2.role = 'user' AND m2.text IS NOT NULL
                        ORDER BY m2.position LIMIT 1) AS first_user_text
                FROM chats c
                LEFT JOIN messages m ON m.chat_id = c.chat_id
                WHERE c.is_private = 0
                GROUP BY c.chat_id
                ORDER BY c.updated_at DESC
                """
            ).fetchall()

        for row in rows:
            title = (
                (row["title"] or "")
                .replace("\r\n", " ")
                .replace("\r", " ")
                .replace("\n", " ")
            )
            if title in ("New Chat", "Untitled"):
                title = ""
            first_user_text = (
                (row["first_user_text"] or "")
                .replace("\r\n", " ")
                .replace("\r", " ")
                .replace("\n", " ")
            )
            if not title and first_user_text:
                title = first_user_text[:40]
            all_text = row["all_text"] or ""
            preview = first_user_text[:80]
            entries.append(
                ChatIndexEntry(
                    chat_id=row["chat_id"],
                    title=title,
                    text=(title + " " + all_text).strip(),
                    preview=preview,
                    updated_at=row["updated_at"] or "",
                )
            )
    except Exception as e:
        logger.warning("Failed to build chat search index from DB: %s", e)

    logger.debug("Built chat search index with %d entries", len(entries))
    return entries


# Module-level cache — valid for the entire process session
_chat_search_index: Optional[list[ChatIndexEntry]] = None


def _get_chat_search_index() -> list[ChatIndexEntry]:
    """Return the cached index, building it on first call."""
    global _chat_search_index
    if _chat_search_index is None:
        _chat_search_index = _build_chat_search_index()
    return _chat_search_index


def _search_chats(query: str, index: list[ChatIndexEntry]) -> list[ChatIndexEntry]:
    """Case-insensitive substring search across title + message text."""
    if not query.strip():
        return list(index)
    q = query.lower()
    return [e for e in index if q in e.title.lower() or q in e.text.lower()]


# ---------------------------------------------------------------------------
# fzf-like interactive UI
# ---------------------------------------------------------------------------


async def _run_search_ui(index: list[ChatIndexEntry]) -> Optional[str]:
    """
    Show an interactive fzf-like full-screen selector.
    Returns the selected chat_id, or None if cancelled.
    """
    results: list[ChatIndexEntry] = list(index)
    selected_index = [0]
    selected_chat_id: list[Optional[str]] = [None]
    done = [False]

    def _esc(s: str) -> str:
        """Escape HTML special chars and strip XML-invalid control characters."""
        s = _XML_INVALID_RE.sub("", s)
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    def get_results_text() -> HTML:
        count = len(results)
        html_parts = [
            f"<style bg='#1e1e2e' fg='#cdd6f4'>"
            f"  {count} result(s)  "
            f"[↑↓ navigate · Enter select · Esc cancel]"
            f"</style>\n"
        ]
        visible_start = max(0, selected_index[0] - 8)
        visible_end = min(len(results), visible_start + 18)
        for i in range(visible_start, visible_end):
            entry = results[i]
            name_part = _esc(_short_chat_id(entry.chat_id))
            time_part = (
                _esc(_fmt_chat_time(entry.updated_at)) if entry.updated_at else ""
            )
            title_part = _esc((entry.title or entry.preview or "(no title)")[:50])
            if i == selected_index[0]:
                html_parts.append(
                    f"<style bg='#313244' fg='#89b4fa'>"
                    f" ▶ [{time_part}] {name_part}  {title_part}"
                    f"</style>\n"
                )
            else:
                html_parts.append(
                    f"<style fg='#a6adc8'>"
                    f"   [{time_part}] {name_part}  {title_part}"
                    f"</style>\n"
                )
        return HTML("".join(html_parts))

    def on_text_changed(buf):
        query = buf.text
        new_results = _search_chats(query, index)
        results.clear()
        results.extend(new_results)
        selected_index[0] = 0
        app.invalidate()

    search_buffer = Buffer(name="search", on_text_changed=on_text_changed)

    kb = KeyBindings()

    @kb.add("up")
    def move_up(event):
        if selected_index[0] > 0:
            selected_index[0] -= 1
        app.invalidate()

    @kb.add("down")
    def move_down(event):
        if selected_index[0] < len(results) - 1:
            selected_index[0] += 1
        app.invalidate()

    @kb.add("enter")
    def confirm(event):
        if results:
            selected_chat_id[0] = results[selected_index[0]].chat_id
        done[0] = True
        app.exit()

    @kb.add("escape")
    @kb.add("c-c")
    def cancel(event):
        done[0] = True
        app.exit()

    layout = Layout(
        HSplit(
            [
                Window(
                    content=FormattedTextControl(
                        text=get_results_text, focusable=False
                    ),
                    height=20,
                ),
                Window(height=1, char="─"),
                Window(
                    content=BufferControl(buffer=search_buffer, focusable=True),
                    height=1,
                    get_line_prefix=lambda lineno, wrap_count: HTML(
                        "<style fg='#89b4fa'>  Search: </style>"
                    ),
                ),
            ]
        )
    )

    app = Application(
        layout=layout, key_bindings=kb, full_screen=False, mouse_support=False
    )
    await app.run_async()
    return selected_chat_id[0]


def format_message_content(content: Union[str, list]) -> str:
    """将消息内容转换为可安全显示的字符串，图片显示为占位符。"""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, TextContent):
                parts.append(block.text)
            elif isinstance(block, ImageContent):
                parts.append("[🖼 图片]")
            else:
                parts.append(f"[{type(block).__name__}]")
        return "\n".join(parts)
    return str(content)


def _fmt_chat_time(updated_at: str) -> str:
    """将 ISO 8601 UTC 时间字符串转为本地时间，格式化为 'MM-DD HH:mm'"""
    try:
        from datetime import datetime, timezone

        dt = (
            datetime.fromisoformat(updated_at).replace(tzinfo=timezone.utc).astimezone()
        )
        return dt.strftime("%m-%d %H:%M")
    except Exception:
        return updated_at[:16] if updated_at else ""


def _short_chat_id(chat_id: str) -> str:
    """只保留 'cht-' 前缀 + 后续8个字符，共12字符"""
    if chat_id.startswith("cht-") and len(chat_id) > 12:
        return chat_id[:12]
    return chat_id[:12]


# ----------------------------------------------------
# chat commands
# ----------------------------------------------------


class PublicChatFileCompleter(Completer):
    def get_completions(self, document, complete_event):
        chats = load_public_chats()
        text = document.text.lower()
        for title, chat_id, updated_at in chats:
            time_str = _fmt_chat_time(updated_at)
            short_id = _short_chat_id(chat_id)
            label = f"[{time_str}] {short_id}  {title}"
            if text in label.lower() or text in chat_id.lower():
                yield Completion(
                    text=chat_id, start_position=-len(document.text), display=label
                )


class PrivateChatFileCompleter(Completer):
    def get_completions(self, document, complete_event):
        chats = load_private_chats()
        text = document.text.lower()
        for chat_id, updated_at in chats:
            time_str = _fmt_chat_time(updated_at)
            short_id = _short_chat_id(chat_id)
            label = f"[{time_str}] {short_id}  [private]"
            if text in label.lower() or text in chat_id.lower():
                yield Completion(
                    text=chat_id, start_position=-len(document.text), display=label
                )


class SaveCommand(CommandBase):
    async def do_command_async(self) -> bool:
        if self.message == "/save":
            if (
                self.context.current_chat.is_private
                and not self.context.current_chat.private_password
            ):
                password = Prompt.ask(
                    "[bold dim]Input password for private chat[/bold dim]",
                    password=True,
                )
                password = password.strip()
                if not password:
                    self.context.notification_display.warning(
                        "Password cannot be empty."
                    )
                    return False
                self.context.current_chat.private_password = password

            await self.context.current_chat.geneate_title()

            self.context.current_chat.auto_persist = True  # 先开启，save_to_db() 才会执行
            ok = self.context.current_chat.save()
            if ok:
                self.context.notification_display.success(
                    f"Chat saved. ID: {self.context.current_chat.chat_id}. Title: {self.context.current_chat.title}"
                )
            else:
                self.context.current_chat.auto_persist = False  # 保存失败则回滚
                self.context.notification_display.warning("Not saved")
            return False
        return True

    @property
    def doc_title(self) -> str:
        return "/save\nPersist current chat to database"

    @property
    def doc_description(self) -> str:
        return "Save the current chat to the SQLite database. Public chats auto-save with generated titles. Private chats require a password for encryption and must be manually saved."

    @property
    def command_hint(self) -> Optional[str | tuple[str, ...]]:
        return "/save"


class LoadChatCommand(CommandBase):
    async def pick_file(self) -> Optional[str]:
        completion = PublicChatFileCompleter()
        self.context.notification_display.info(
            "Type to search for chat files, use arrow keys to select."
        )

        session = self.context.prompt_session

        def _show_completions() -> None:
            session.app.current_buffer.start_completion(select_first=False)  # type: ignore[union-attr]

        try:
            with patch_stdout():
                filename: str = await session.prompt_async(
                    "Select Chat: ",
                    completer=completion,
                    complete_while_typing=True,
                    complete_in_thread=False,
                    pre_run=_show_completions,
                )
                return filename
        except KeyboardInterrupt:
            return None

    async def do_command_async(self) -> bool:
        cmd = "/load-chat"
        if self.message.startswith(cmd):
            chat_id = await self.pick_file()
            if not chat_id:
                self.context.notification_display.warning("No chat selected.")
                return False
            chat = ChatModel.load_from_db(chat_id)
            if not chat:
                self.context.notification_display.error(f"Load chat failed: {chat_id}")
            else:
                self.context.current_chat = chat
                self.context.print_rule(f"LOAD CHAT: {chat.chat_id}")
                self.context.print_instruction()
                for message in chat.messages:
                    role = message.role
                    content = message.content
                    if role and content:
                        if role == "system":
                            continue
                        else:
                            if role == "user":
                                role_label = (
                                    "[bold light_sky_blue1]You: [/bold light_sky_blue1]"
                                )
                            else:
                                role_label = "[bold deep_sky_blue1]Assistant: [/bold deep_sky_blue1]"
                            self.console.print(
                                f"{role_label}{format_message_content(content)}"
                            )
                            self.console.print()
            return False
        return True

    @property
    def doc_title(self) -> str:
        return "/load-chat \nLoad a public chat from database"

    @property
    def doc_description(self) -> str:
        return """Load a public chat from the SQLite database. Type to search, use arrow keys to select."""

    @property
    def command_hint(self) -> Optional[str | tuple[str, ...]]:
        return "/load-chat"


class LoadPrivateChatCommand(CommandBase):
    async def pick_file(self) -> Optional[str]:
        completion = PrivateChatFileCompleter()
        self.context.notification_display.info(
            "Type to search for chat files, use arrow keys to select."
        )

        session = self.context.prompt_session

        def _show_completions() -> None:
            session.app.current_buffer.start_completion(select_first=False)  # type: ignore[union-attr]

        try:
            with patch_stdout():
                filename = await session.prompt_async(
                    "Select Private Chat: ",
                    completer=completion,
                    complete_while_typing=True,
                    complete_in_thread=False,
                    pre_run=_show_completions,
                )
                return filename
        except KeyboardInterrupt:
            return None

    async def do_command_async(self) -> bool:
        cmd = "/load-private-chat"
        if self.message.startswith(cmd):
            chat_id = await self.pick_file()
            if not chat_id:
                self.context.notification_display.warning("No chat selected.")
                return False
            password = Prompt.ask(
                "[bold dim]Input password for private chat[/bold dim]", password=True
            )
            password = password.strip()
            if not password:
                self.context.notification_display.warning("Password cannot be empty.")
                return False
            chat = ChatModel.load_from_db(
                chat_id, is_private=True, private_password=password
            )
            if not chat:
                self.context.notification_display.error(f"Load chat failed: {chat_id}")
            else:
                self.context.current_chat = chat
                self.context.print_rule(f"LOAD CHAT: {chat.chat_id}")
                self.context.print_instruction()
                for message in chat.messages:
                    role = message.role
                    content = message.content
                    if role and content:
                        if role == "system":
                            continue
                        else:
                            if role == "user":
                                role_label = (
                                    "[bold yellow3]You (Private): [/bold yellow3]"
                                )
                            else:
                                role_label = "[bold deep_sky_blue1]Assistant: [/bold deep_sky_blue1]"
                            self.console.print(
                                f"{role_label}{format_message_content(content)}\n"
                            )
            return False
        return True

    @property
    def doc_title(self) -> str:
        return "/load-private-chat \nLoad a private chat from database"

    @property
    def doc_description(self) -> str:
        return """Load a private chat from the SQLite database. You will be prompted to enter the password used to encrypt the chat messages."""

    @property
    def command_hint(self) -> Optional[str | tuple[str, ...]]:
        return "/load-private-chat"


class ExportCommand(CommandBase):
    async def do_command_async(self) -> bool:
        cmd = "/export"
        if self.message.startswith(cmd):
            filepath = self.message[len(cmd) :].strip()
            if not filepath:
                self.context.notification_display.warning(
                    "Please input a valid file path."
                )
                return False
            path = Path(filepath).expanduser()
            if path.is_absolute():
                if not path.parent.exists():
                    self.context.notification_display.warning(
                        "Parent folder not exists."
                    )
                    return False
            else:
                export_dir = Path(gede_dir()) / "chats" / "exports"
                export_dir.mkdir(parents=True, exist_ok=True)
                path = export_dir / path
                path.parent.mkdir(parents=True, exist_ok=True)
            exporter = ExportChat(self.context.current_chat)  # type: ignore[arg-type]
            await exporter.export_txt(path)
            self.context.notification_display.success(f"Exported chat to {str(path)}")
            return False
        return True

    @property
    def command_hint(self) -> Optional[str | tuple[str, ...]]:
        return "/export"

    @property
    def doc_title(self) -> str:
        return "/export <FILEPATH> \nExport the current chat to a specified file"

    @property
    def doc_description(self) -> str:
        return """Export the current chat to a specified file in TXT format. Provide the FILEPATH where you want to save the exported chat. If a relative path is provided, the chat will be saved in the 'chats/exports' directory (default: ~/.gede/chats/exports)."""


class SearchChatsCommand(CommandBase):
    async def do_command_async(self) -> bool:
        if not self.message.startswith("/search-chats"):
            return True

        self.context.notification_display.info("Loading chat index...")
        loop = asyncio.get_event_loop()
        index = await loop.run_in_executor(None, _get_chat_search_index)

        if not index:
            self.context.notification_display.warning(
                "No public chats found in the database."
            )
            return False

        chat_id = await _run_search_ui(index)

        if not chat_id:
            self.context.notification_display.info("Search cancelled.")
            return False

        chat = ChatModel.load_from_db(chat_id)
        if not chat:
            self.context.notification_display.error(f"Load chat failed: {chat_id}")
        else:
            self.context.current_chat = chat
            self.context.print_rule(f"LOAD CHAT: {chat.chat_id}")
            self.context.print_instruction()
            for message in chat.messages:
                role = message.role
                content = message.content
                if role and content:
                    if role == "system":
                        continue
                    if role == "user":
                        role_label = (
                            "[bold light_sky_blue1]You: [/bold light_sky_blue1]"
                        )
                    else:
                        role_label = (
                            "[bold deep_sky_blue1]Assistant: [/bold deep_sky_blue1]"
                        )
                    self.console.print(f"{role_label}{format_message_content(content)}")
                    self.console.print()
        return False

    @property
    def doc_title(self) -> str:
        return "/search-chats\nSearch public chat history interactively"

    @property
    def doc_description(self) -> str:
        return (
            "Search through all saved public chats in the SQLite database using an "
            "interactive fzf-like interface. Type a keyword to filter results in real time. "
            "Use ↑↓ to navigate, Enter to load the selected chat, Esc to cancel."
        )

    @property
    def command_hint(self) -> Optional[str | tuple[str, ...]]:
        return "/search-chats"
