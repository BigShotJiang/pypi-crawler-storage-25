# coding=utf-8
#
# chatcore.py
# SQLite 版对话存储层
#
# 提供 ChatModel 数据结构，IO 操作读写 SQLite 数据库。
# 附件（图片/文件）存储在 ~/.gede/data/attachments/{chat_id}/ 目录下，
# 以文件内容的 SHA256 哈希值命名。
#

import os
import json
import hashlib
import base64
import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Optional, Literal, cast
from dataclasses import dataclass, field

from my_llmkit.chat.model_settings import ModelSettings
from my_llmkit.chat import UnifiedMessage, ContentBlock
from my_llmkit.chat.types import TextContent, ImageContent

from .top import gede_attachments_dir, DEFAULT_MODEL_PATH
from .db import db_conn
from .encrypt import encrypt_aes, decrypt_aes
from .llm.providers.reasoning import ReasoningEffortType

logger = logging.getLogger(__name__)

_FILE_REF_RE = re.compile(r"^[a-f0-9]{64}$")


def _generate_message_id() -> str:
    """生成消息预分配 ID，格式 msg-<UUID>"""
    from uuid import uuid4

    return "msg-" + str(uuid4())


# ---------------------------------------------------------------------------
# 附件辅助函数
# ---------------------------------------------------------------------------


def _save_attachment(chat_id: str, data: bytes) -> str:
    """将二进制数据保存为附件文件，返回 SHA256 哈希（作为 file_ref）"""
    sha256 = hashlib.sha256(data).hexdigest()
    attachments_dir = gede_attachments_dir(chat_id)
    filepath = os.path.join(attachments_dir, sha256)
    if not os.path.exists(filepath):
        with open(filepath, "wb") as f:
            f.write(data)
    return sha256


def save_attachment_file(chat_id: str, data: bytes) -> str:
    """保存会话附件文件，返回可用于后续引用的 file_ref。"""
    return _save_attachment(chat_id, data)


def get_attachment_path(chat_id: str, file_ref: str) -> Optional[str]:
    """返回附件文件路径；file_ref 非法或文件不存在时返回 None。"""
    if not _FILE_REF_RE.fullmatch(file_ref):
        return None

    attachments_dir = gede_attachments_dir(chat_id)
    filepath = os.path.join(attachments_dir, file_ref)
    if not os.path.isfile(filepath):
        return None
    return filepath


def _load_attachment(chat_id: str, file_ref: str) -> Optional[bytes]:
    """根据 file_ref（SHA256）读取附件文件内容"""
    filepath = get_attachment_path(chat_id, file_ref)
    if filepath is None:
        logger.warning("Attachment not found: %s/%s", chat_id, file_ref)
        return None
    with open(filepath, "rb") as f:
        return f.read()


# ---------------------------------------------------------------------------
# 消息序列化：UnifiedMessage → DB 行（text + attachments JSON）
# ---------------------------------------------------------------------------


def _serialize_message(
    message: UnifiedMessage,
    chat_id: str,
    is_private: bool,
    private_password: Optional[str],
) -> tuple[Optional[str], Optional[str]]:
    """
    将 UnifiedMessage 序列化为 (text, attachments_json)。
    - text: 纯文本内容；私密对话时为 AES 密文
    - attachments_json: 附件引用的 JSON 字符串，无附件时为 None
    """
    content = message.content

    if isinstance(content, str):
        plain_text = content
        attachments = None
    elif isinstance(content, list):
        text_parts: list[str] = []
        attachment_list: list[dict] = []

        for block in content:
            if isinstance(block, TextContent):
                text_parts.append(block.text)
            elif isinstance(block, ImageContent):
                attachment = _serialize_image_block(block, chat_id)
                attachment_list.append(attachment)
            else:
                # 其他类型序列化为 JSON
                try:
                    d = block.to_dict()
                    attachment_list.append({"type": "other", "data": json.dumps(d)})
                except Exception:
                    pass

        plain_text = "\n".join(text_parts) if text_parts else None
        attachments = (
            json.dumps(attachment_list, ensure_ascii=False) if attachment_list else None
        )
    else:
        plain_text = str(content) if content is not None else None
        attachments = None

    # 私密对话：加密文本
    if is_private and private_password and plain_text is not None:
        text_out = encrypt_aes(plain_text, private_password)
    else:
        text_out = plain_text

    return text_out, attachments


def _serialize_image_block(block: ImageContent, chat_id: str) -> dict:
    """将 ImageContent 序列化为附件 dict（使用文件引用替代 base64）"""
    image_url = block.image_url
    media_type = block.media_type
    detail = block.detail

    # 判断是否为 base64 数据（无 http:// 前缀）
    if (
        image_url
        and not image_url.startswith("http://")
        and not image_url.startswith("https://")
    ):
        # base64 数据 → 保存为文件
        try:
            raw_bytes = base64.b64decode(image_url)
            file_ref = _save_attachment(chat_id, raw_bytes)
            return {
                "type": "image",
                "file_ref": file_ref,
                "media_type": media_type or "image/jpeg",
                "detail": detail,
            }
        except Exception as e:
            logger.warning("Failed to decode base64 image, storing as URL: %s", e)
            return {
                "type": "image",
                "image_url": image_url,
                "media_type": media_type,
                "detail": detail,
            }
    else:
        # HTTP URL
        return {
            "type": "image",
            "image_url": image_url,
            "media_type": media_type,
            "detail": detail,
        }


# ---------------------------------------------------------------------------
# 消息反序列化：DB 行 → UnifiedMessage
# ---------------------------------------------------------------------------


def _deserialize_message(
    role: str,
    text: Optional[str],
    attachments_json: Optional[str],
    chat_id: str,
    is_private: bool,
    private_password: Optional[str],
    message_id: Optional[str] = None,
) -> Optional[UnifiedMessage]:
    """将 DB 行还原为 UnifiedMessage"""
    valid_roles = ("system", "user", "assistant", "tool")
    typed_role = cast(
        Literal["system", "user", "assistant", "tool"],
        role if role in valid_roles else "user",
    )
    # 私密对话：解密文本
    if is_private and private_password and text is not None:
        try:
            text = decrypt_aes(text, private_password)
        except Exception as e:
            logger.error("Failed to decrypt message: %s", e)
            return None

    attachments: list[dict] = []
    if attachments_json:
        try:
            attachments = json.loads(attachments_json)
        except Exception as e:
            logger.warning("Failed to parse attachments JSON: %s", e)

    if not attachments:
        # 纯文本消息
        return UnifiedMessage(
            role=typed_role, content=text or "", message_id=message_id
        )

    # 多模态消息：重建 ContentBlock 列表
    content_blocks: list[ContentBlock] = []
    if text:
        content_blocks.append(TextContent(text=text))

    for att in attachments:
        att_type = att.get("type", "")
        if att_type == "image":
            file_ref = att.get("file_ref")
            image_url = att.get("image_url")
            media_type = att.get("media_type", "image/jpeg")
            detail = att.get("detail")

            if file_ref:
                raw_bytes = _load_attachment(chat_id, file_ref)
                if raw_bytes is not None:
                    b64 = base64.b64encode(raw_bytes).decode("ascii")
                    img = ImageContent.from_base64(
                        base64_data=b64,
                        media_type=media_type,
                        detail=detail,
                    )
                    content_blocks.append(img)
                else:
                    logger.warning("Missing attachment file: %s/%s", chat_id, file_ref)
            elif image_url:
                img = ImageContent.from_url(url=image_url, detail=detail)
                content_blocks.append(img)
        elif att_type == "file":
            # 未来扩展：PDF 等文件类型
            logger.debug("Skipping unsupported attachment type 'file' for now")
        elif att_type == "other":
            # 其他序列化内容
            try:
                d = json.loads(att.get("data", "{}"))
                block = ContentBlock.from_dict(d)
                content_blocks.append(block)
            except Exception as e:
                logger.warning("Failed to deserialize 'other' attachment: %s", e)

    if len(content_blocks) == 1 and isinstance(content_blocks[0], TextContent):
        return UnifiedMessage(
            role=typed_role, content=content_blocks[0].text, message_id=message_id
        )

    return UnifiedMessage(
        role=typed_role, content=content_blocks, message_id=message_id
    )


# ---------------------------------------------------------------------------
# ChatModel
# ---------------------------------------------------------------------------


@dataclass(init=False)
class ChatModel:
    """
    SQLite 版对话模型，持久化操作读写 SQLite 数据库。
    """

    chat_id: str
    filename: Optional[str]  # 兼容 ChatModel 接口，SQLite 模式固定为 None
    instruction: str
    model_path: str
    title: str
    is_private: bool = False
    private_password: Optional[str] = None
    message_num_in_context: int = 6
    forked_from_message_id: Optional[str] = None
    user_model_settings: ModelSettings = field(default_factory=ModelSettings)
    messages: list[UnifiedMessage] = field(default_factory=list)
    _db_saved_count: int = field(default=0, repr=False, compare=False)
    # 是否自动持久化：新会话默认 False，执行 /save 后或从数据库加载后置为 True
    auto_persist: bool = field(default=False, repr=False, compare=False)

    def __init__(self, is_private: bool = False):
        from uuid import uuid4

        self.chat_id = "cht-" + str(uuid4())
        self.filename = None  # SQLite 存储不使用文件名
        self.instruction = "You are a helpful assistant."
        self.title = "New Chat"
        self.is_private = is_private
        self.model_path = DEFAULT_MODEL_PATH
        self.forked_from_message_id = None
        self.user_model_settings = ModelSettings()
        self.messages = [
            UnifiedMessage(
                role="system",
                content=self.instruction,
                message_id=_generate_message_id(),
            )
        ]
        self._db_saved_count = 0
        self.auto_persist = False

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def model_settings(self) -> ModelSettings:
        from gede.llm.providers.providers import get_provider_by_id

        (provider_id, model_id) = self.model_path.split(":", maxsplit=1)
        provider = get_provider_by_id(provider_id)
        if provider:
            default_settings = provider.default_model_settings(model_id)
            return default_settings.resolve(self.user_model_settings)
        return ModelSettings()

    @property
    async def model(self):
        from my_llmkit.models import get_model_info

        info = await get_model_info(self.model_path)
        if not info:
            raise ValueError(f"Cannot get model info for path: {self.model_path}")
        return info

    @property
    async def info(self) -> str:
        m = await self.model
        return (
            f"[bold]chat_id[/bold]: {self.chat_id}\n"
            f"[bold]title[/bold]: {self.title or ''}\n"
            f"[bold]private[/bold]: {self.is_private}\n"
            f"[bold]private_password[/bold]: {'Set' if self.private_password else 'Not Set'}\n"
            f"[bold]model[/bold]: {m.provider_name or ''}:{m.model_name}\n"
            f"[bold]instruction[/bold]: {self.instruction}\n"
            f"[bold]message_num_in_context[/bold]: {self.message_num_in_context}\n"
            f"[bold]message count[/bold]: {len(self.messages)}\n"
            f"[bold]model_supports[/bold]: {m.supports_description}\n"
            f"[bold]model_settings[/bold]:\n\t{json.dumps(self.model_settings.to_json_dict(), ensure_ascii=False)}\n"
        )

    # ------------------------------------------------------------------
    # Messages
    # ------------------------------------------------------------------

    def set_instruction(self, instruction: str):
        self.instruction = instruction
        system_pos = -1
        for i, m in enumerate(self.messages):
            if m.role == "system":
                system_pos = i
        if system_pos >= 0:
            del self.messages[system_pos]
        self.messages.insert(
            0,
            UnifiedMessage(
                role="system", content=instruction, message_id=_generate_message_id()
            ),
        )

    def append_user_message(self, new_message: str, images: list[ImageContent] = []):
        if images:
            content_blocks: list[ContentBlock] = []
            if new_message:
                content_blocks.append(TextContent(text=new_message))
            for img in images:
                content_blocks.append(img)
            self.messages.append(
                UnifiedMessage(
                    role="user",
                    content=content_blocks,
                    message_id=_generate_message_id(),
                )
            )
        else:
            self.messages.append(
                UnifiedMessage(
                    role="user", content=new_message, message_id=_generate_message_id()
                )
            )
        self.save_to_db()

    def append_assistant_message(self, new_message: str):
        self.messages.append(
            UnifiedMessage(
                role="assistant", content=new_message, message_id=_generate_message_id()
            )
        )
        self.save_to_db()

    def get_messages_to_talk(self) -> list[UnifiedMessage]:
        if (
            self.message_num_in_context <= 0
            or len(self.messages) <= self.message_num_in_context
        ):
            return self.messages.copy()
        result = [self.messages[0]]
        result.extend(self.messages[-self.message_num_in_context :])
        return result

    def set_model_reasoning(self, effort: Optional[ReasoningEffortType] = None):
        from gede.llm.providers.providers import get_provider_by_id

        (provider_id, model_id) = self.model_path.split(":", maxsplit=1)
        provider = get_provider_by_id(provider_id)
        if not provider:
            return
        reasoning_settings = provider.make_reasoning_setting(
            model_id=model_id, reasoning_effort=effort
        )
        self.user_model_settings = self.user_model_settings.resolve(reasoning_settings)

    async def geneate_title(self):
        """生成对话标题（与 ChatModel 保持同名方法）"""
        if self.is_private:
            logger.warning("Private chat cannot generate title automatically.")
            return
        if self.title not in ("", "New Chat", "Untitled"):
            return
        try:
            from .llm.generate_title import generate_title

            title = await generate_title(self.messages) or "New Chat"
            if title:
                self.title = title
            return title
        except Exception as e:
            logger.error("Failed to generate chat title: %s", e)

    def fork_from_last_assistant(self) -> Optional["ChatModel"]:
        """
        从当前对话的最后一条 assistant 消息截止，分叉出一个新会话。

        新会话：
        - 继承 is_private / model_path / instruction / message_num_in_context / user_model_settings
        - 包含 system 消息 + 截至最后一条 assistant 消息（含）的全部消息
        - 每条消息重新生成 message_id（避免 DB UNIQUE 冲突）
        - 附件文件物理复制到新 chat_id 目录
        - forked_from_message_id 记录原最后一条 assistant 消息的 message_id
        - _db_saved_count=0，不自动保存，需用户手动 /save

        返回新 ChatModel，若当前对话没有 assistant 消息则返回 None。
        """
        from copy import deepcopy
        import shutil

        # 找到最后一条 assistant 消息的索引
        last_assistant_idx = -1
        last_assistant_message_id: Optional[str] = None
        for i, msg in enumerate(self.messages):
            if msg.role == "assistant":
                last_assistant_idx = i
                last_assistant_message_id = msg.message_id

        if last_assistant_idx < 0:
            return None

        # 创建新会话，继承设置
        fork = ChatModel(is_private=self.is_private)
        fork.title = self.title
        fork.model_path = self.model_path
        fork.instruction = self.instruction
        fork.message_num_in_context = self.message_num_in_context
        fork.user_model_settings = deepcopy(self.user_model_settings)
        fork.forked_from_message_id = last_assistant_message_id

        # 复制消息（截至最后一条 assistant），重新生成 message_id
        forked_messages: list[UnifiedMessage] = []
        for msg in self.messages[: last_assistant_idx + 1]:
            new_msg = deepcopy(msg)
            new_msg.message_id = _generate_message_id()
            forked_messages.append(new_msg)
        fork.messages = forked_messages
        fork._db_saved_count = 0

        # 物理复制附件文件
        try:
            from .top import gede_attachments_dir as _get_att_dir

            old_dir = _get_att_dir(self.chat_id)
            new_dir = _get_att_dir(fork.chat_id)
            if os.path.isdir(old_dir):
                for filename in os.listdir(old_dir):
                    src = os.path.join(old_dir, filename)
                    dst = os.path.join(new_dir, filename)
                    if os.path.isfile(src) and not os.path.exists(dst):
                        shutil.copy2(src, dst)
        except Exception as e:
            logger.warning("Failed to copy attachments during fork: %s", e)

        return fork

    # ------------------------------------------------------------------
    # Save to DB
    # ------------------------------------------------------------------

    def save_to_db(self) -> bool:
        """将对话元数据写入 SQLite，并增量追加新消息（只写入未持久化的部分）"""
        if not self.auto_persist:
            return False
        if self.is_private and not self.private_password:
            return False
        try:
            new_messages = self.messages[self._db_saved_count :]
            with db_conn() as conn:
                # Upsert chat metadata（instruction 不写入 chats 表，私密对话的 system 消息已加密存在 messages 中）
                conn.execute(
                    """
                    INSERT INTO chats
                        (chat_id, title, model_path, is_private,
                         model_settings, message_num_in_context, forked_from_message_id, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
                    ON CONFLICT(chat_id) DO UPDATE SET
                        title                    = excluded.title,
                        model_path               = excluded.model_path,
                        is_private               = excluded.is_private,
                        model_settings           = excluded.model_settings,
                        message_num_in_context   = excluded.message_num_in_context,
                        forked_from_message_id   = excluded.forked_from_message_id,
                        updated_at               = excluded.updated_at
                    """,
                    (
                        self.chat_id,
                        self.title,
                        self.model_path,
                        1 if self.is_private else 0,
                        json.dumps(
                            self.model_settings.to_json_dict(), ensure_ascii=False
                        ),
                        self.message_num_in_context,
                        self.forked_from_message_id,
                    ),
                )

                # 只追加新增消息，保留已有消息的 created_at
                for position, message in enumerate(
                    new_messages, start=self._db_saved_count
                ):
                    if not message.role:
                        continue
                    text, attachments = _serialize_message(
                        message,
                        self.chat_id,
                        self.is_private,
                        self.private_password,
                    )
                    conn.execute(
                        """
                        INSERT INTO messages (message_id, chat_id, role, text, attachments, position)
                        VALUES (?, ?, ?, ?, ?, ?)
                        """,
                        (
                            message.message_id or _generate_message_id(),
                            self.chat_id,
                            message.role,
                            text,
                            attachments,
                            position,
                        ),
                    )

            self._db_saved_count = len(self.messages)
            logger.debug("Saved chat %s to DB", self.chat_id)
            return True
        except Exception as e:
            logger.error("Failed to save chat %s to DB: %s", self.chat_id, e)
            return False

    # 与旧接口兼容的别名
    def save(self) -> bool:
        return self.save_to_db()

    # ------------------------------------------------------------------
    # Load from DB
    # ------------------------------------------------------------------

    @classmethod
    def load_from_db(
        cls,
        chat_id: str,
        is_private: bool = False,
        private_password: Optional[str] = None,
    ) -> Optional["ChatModel"]:
        """从 SQLite 加载对话"""
        try:
            with db_conn() as conn:
                row = conn.execute(
                    "SELECT * FROM chats WHERE chat_id = ?", (chat_id,)
                ).fetchone()
                if not row:
                    logger.error("Chat not found in DB: %s", chat_id)
                    return None

                if bool(row["is_private"]) != is_private:
                    logger.error("Chat privacy mode does not match: %s", chat_id)
                    return None

                if is_private and not private_password:
                    logger.error("Private chat requires a password: %s", chat_id)
                    return None

                chat = cls(is_private=is_private)
                chat.chat_id = row["chat_id"]
                chat.title = row["title"]
                chat.model_path = row["model_path"] or DEFAULT_MODEL_PATH
                # instruction 不从 chats 表读取，由下方 messages 中 role=system 的记录填充
                chat.private_password = private_password
                chat.message_num_in_context = row["message_num_in_context"]
                chat.forked_from_message_id = (
                    row["forked_from_message_id"]
                    if "forked_from_message_id" in row.keys()
                    else None
                )

                model_settings_data = json.loads(row["model_settings"] or "{}")
                if model_settings_data:
                    from dataclasses import fields as dataclass_fields

                    valid_fields = {f.name for f in dataclass_fields(ModelSettings)}
                    filtered = {
                        k: v
                        for k, v in model_settings_data.items()
                        if k in valid_fields and v is not None
                    }
                    chat.user_model_settings = ModelSettings(**filtered)

                msg_rows = conn.execute(
                    "SELECT role, text, attachments, message_id FROM messages WHERE chat_id = ? ORDER BY position",
                    (chat_id,),
                ).fetchall()

                messages: list[UnifiedMessage] = []
                decrypt_failed = 0
                for msg_row in msg_rows:
                    m = _deserialize_message(
                        role=msg_row["role"],
                        text=msg_row["text"],
                        attachments_json=msg_row["attachments"],
                        chat_id=chat_id,
                        is_private=is_private,
                        private_password=private_password,
                        message_id=msg_row["message_id"],
                    )
                    if m:
                        messages.append(m)
                        if m.role == "system" and isinstance(m.content, str):
                            chat.instruction = m.content
                    elif is_private:
                        decrypt_failed += 1

                if is_private and decrypt_failed > 0:
                    logger.error(
                        "Incorrect password: %d message(s) failed to decrypt for chat %s",
                        decrypt_failed,
                        chat_id,
                    )
                    return None

                chat.messages = messages
                chat._db_saved_count = len(messages)
                chat.auto_persist = True  # 历史对话加载后继续自动保存
                logger.info("Loaded chat %s from DB", chat_id)
                return chat

        except Exception as e:
            logger.error("Failed to load chat %s from DB: %s", chat_id, e)
            return None


# ---------------------------------------------------------------------------
# 列表查询
# ---------------------------------------------------------------------------


def load_public_chats() -> list[tuple[str, str, str]]:
    """返回公开对话列表 [(display_label, chat_id, updated_at)]，按更新时间降序"""
    try:
        with db_conn() as conn:
            rows = conn.execute(
                """
                SELECT c.chat_id, c.title, c.updated_at,
                       (SELECT text FROM messages
                        WHERE chat_id = c.chat_id AND role = 'user'
                        ORDER BY position LIMIT 1) AS first_user_text
                FROM chats c
                WHERE c.is_private = 0
                ORDER BY c.updated_at DESC
                """
            ).fetchall()

        result: list[tuple[str, str, str]] = []
        for row in rows:
            title = row["title"] or ""
            if title in ("", "New Chat", "Untitled"):
                title = (row["first_user_text"] or "")[:30]
            result.append((title[:40], row["chat_id"], row["updated_at"] or ""))
        return result
    except Exception as e:
        logger.error("Failed to load public chats: %s", e)
        return []


def load_private_chats() -> list[tuple[str, str]]:
    """返回私密对话列表 [(chat_id, updated_at)]，按更新时间降序"""
    try:
        with db_conn() as conn:
            rows = conn.execute(
                "SELECT chat_id, updated_at FROM chats WHERE is_private = 1 ORDER BY updated_at DESC"
            ).fetchall()
        return [(row["chat_id"], row["updated_at"] or "") for row in rows]
    except Exception as e:
        logger.error("Failed to load private chats: %s", e)
        return []


class ExportChat:
    def __init__(self, chat: ChatModel):
        self.chat = chat

    async def export_txt(self, filepath: Path) -> bool:
        """Export chat record as TXT file"""
        try:
            txt_dir = os.path.dirname(filepath)
            if txt_dir and not os.path.exists(txt_dir):
                os.makedirs(txt_dir)

            with open(filepath, "w", encoding="utf-8") as f:
                f.write(f"{self.chat.title}\n")
                f.write("=" * 80 + "\n\n")

                model_info = await self.chat.model

                meta_text = (
                    f"Model: {model_info.provider_name}:{model_info.model_name}\n"
                )
                meta_text += (
                    f"Export Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
                )
                f.write(meta_text)
                f.write("-" * 80 + "\n\n")

                for message in self.chat.messages:
                    role = message.role
                    content = ""
                    if isinstance(message.content, list):
                        for one_content in message.content:
                            content += (
                                json.dumps(one_content.to_dict(), ensure_ascii=False)
                                + "\n"
                            )
                    elif isinstance(message.content, str):
                        content = message.content

                    if role == "system":
                        continue

                    role_label = {"user": "USER", "assistant": "ASSISTANT"}.get(
                        role, role.upper()
                    )

                    f.write(f"【{role_label}】\n")
                    content_str = str(content)
                    f.write(content_str)
                    f.write("\n\n")
                    f.write("-" * 80 + "\n\n")

            logger.info(f"Successfully exported chat to {filepath}")
            return True

        except Exception as e:
            logger.error(f"Failed to export chat to TXT: {str(e)}")
            return False
