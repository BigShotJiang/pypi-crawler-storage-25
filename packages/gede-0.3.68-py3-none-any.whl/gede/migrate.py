# coding=utf-8
#
# migrate.py
# 将旧版 JSON 文件格式的对话迁移到 SQLite 数据库
#
# 用法：
#   python -m gede.migrate
#   python -m gede.migrate --dry-run    # 仅统计，不写入
#   python -m gede.migrate --backup     # 迁移后将旧文件移动到 backup 目录
#

import os
import json
import base64
import hashlib
import logging
import argparse
import uuid
from pathlib import Path
from typing import Optional

from .top import gede_dir, gede_data_dir
from .db import init_db, db_conn
from .encrypt import decrypt_aes

logger = logging.getLogger(__name__)


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _save_attachment_file(chat_id: str, data: bytes) -> str:
    """保存附件文件到 data/attachments/{chat_id}/，返回 sha256 哈希"""
    from .top import gede_attachments_dir

    sha256 = _sha256_bytes(data)
    attachments_dir = gede_attachments_dir(chat_id)
    filepath = os.path.join(attachments_dir, sha256)
    if not os.path.exists(filepath):
        with open(filepath, "wb") as f:
            f.write(data)
    return sha256


def _serialize_content(content, chat_id: str) -> tuple[Optional[str], Optional[str]]:
    """
    将旧版 JSON 消息内容转换为 (text, attachments_json)。
    content 为字符串时直接返回；为 list[dict] 时提取文本和附件。
    """
    if isinstance(content, str):
        return content, None

    if isinstance(content, list):
        text_parts: list[str] = []
        attachment_list: list[dict] = []

        for block in content:
            if not isinstance(block, dict):
                continue
            block_type = block.get("content_block_type") or block.get("type", "")

            if block_type == "text":
                text = block.get("text", "")
                if text:
                    text_parts.append(text)
            elif block_type == "image":
                image_url = block.get("image_url", "")
                media_type = block.get("media_type", "image/jpeg")
                detail = block.get("detail")

                if image_url.startswith("http://") or image_url.startswith("https://"):
                    attachment_list.append(
                        {
                            "type": "image",
                            "image_url": image_url,
                            "media_type": media_type,
                            "detail": detail,
                        }
                    )
                else:
                    # base64 数据 → 提取为文件
                    try:
                        raw_bytes = base64.b64decode(image_url)
                        file_ref = _save_attachment_file(chat_id, raw_bytes)
                        attachment_list.append(
                            {
                                "type": "image",
                                "file_ref": file_ref,
                                "media_type": media_type,
                                "detail": detail,
                            }
                        )
                    except Exception as e:
                        logger.warning("Failed to decode base64 image: %s", e)
                        attachment_list.append(
                            {
                                "type": "image",
                                "image_url": image_url,
                                "media_type": media_type,
                                "detail": detail,
                            }
                        )

        plain_text = "\n".join(text_parts) if text_parts else None
        attachments = (
            json.dumps(attachment_list, ensure_ascii=False) if attachment_list else None
        )
        return plain_text, attachments

    return str(content) if content else None, None


def migrate_file(
    filepath: str,
    is_private: bool,
    dry_run: bool = False,
) -> bool:
    """迁移单个 JSON 文件到 SQLite，返回是否成功（跳过=True）"""
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        logger.error("Failed to read %s: %s", filepath, e)
        return False

    chat_id = data.get("chat_id")
    if not chat_id:
        logger.warning("Skipping %s: no chat_id", filepath)
        return False

    title = data.get("title", "New Chat")
    model_path = data.get("model_path", "")
    model_settings = data.get("model_settings", {})
    file_is_private = bool(data.get("is_private", False))

    if file_is_private != is_private:
        logger.warning("Skipping %s: privacy mismatch", filepath)
        return False

    messages_raw = data.get("messages", [])

    if dry_run:
        print(
            f"  [DRY RUN] Would migrate: {chat_id} - {title} ({len(messages_raw)} messages)"
        )
        return True

    try:
        with db_conn() as conn:
            # 检查是否已存在
            existing = conn.execute(
                "SELECT chat_id FROM chats WHERE chat_id = ?", (chat_id,)
            ).fetchone()
            if existing:
                logger.info("Skipping %s: already in DB", chat_id)
                return True

            # chats
            conn.execute(
                """
                INSERT INTO chats
                    (chat_id, title, model_path, is_private,
                     model_settings, message_num_in_context)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    chat_id,
                    title,
                    model_path,
                    1 if is_private else 0,
                    json.dumps(model_settings, ensure_ascii=False),
                    6,
                ),
            )

            # messages
            for position, msg in enumerate(messages_raw):
                role = msg.get("role")
                content = msg.get("content")
                if not role or content is None:
                    continue

                if is_private:
                    # 私密对话：content 为加密字符串，直接存储（保留加密）
                    conn.execute(
                        """
                        INSERT INTO messages (message_id, chat_id, role, text, attachments, position)
                        VALUES (?, ?, ?, ?, NULL, ?)
                        """,
                        (
                            "msg-" + str(uuid.uuid4()),
                            chat_id,
                            role,
                            content
                            if isinstance(content, str)
                            else json.dumps(content),
                            position,
                        ),
                    )
                else:
                    text, attachments = _serialize_content(content, chat_id)
                    conn.execute(
                        """
                        INSERT INTO messages (message_id, chat_id, role, text, attachments, position)
                        VALUES (?, ?, ?, ?, ?, ?)
                        """,
                        ("msg-" + str(uuid.uuid4()), chat_id, role, text, attachments, position),
                    )

        logger.info("Migrated %s (%s)", chat_id, title)
        return True

    except Exception as e:
        logger.error("Failed to migrate %s: %s", filepath, e)
        return False


def migrate_all(dry_run: bool = False, backup: bool = False) -> dict:
    """迁移所有 JSON 文件，返回统计结果"""
    stats = {"public": 0, "private": 0, "failed": 0, "skipped": 0}

    public_dir = os.path.join(gede_dir(), "chats", "public")
    private_dir = os.path.join(gede_dir(), "chats", "private")

    # 公开对话
    if os.path.exists(public_dir):
        for filename in sorted(os.listdir(public_dir)):
            if not filename.endswith(".json"):
                continue
            filepath = os.path.join(public_dir, filename)
            ok = migrate_file(filepath, is_private=False, dry_run=dry_run)
            if ok:
                stats["public"] += 1
                if backup and not dry_run:
                    _move_to_backup(filepath)
            else:
                stats["failed"] += 1

    # 私密对话
    if os.path.exists(private_dir):
        for filename in sorted(os.listdir(private_dir)):
            if not filename.endswith(".json"):
                continue
            filepath = os.path.join(private_dir, filename)
            ok = migrate_file(filepath, is_private=True, dry_run=dry_run)
            if ok:
                stats["private"] += 1
                if backup and not dry_run:
                    _move_to_backup(filepath)
            else:
                stats["failed"] += 1

    return stats


def _move_to_backup(filepath: str):
    """将文件移动到 backup 目录"""
    backup_dir = os.path.join(gede_dir(), "chats", "backup")
    os.makedirs(backup_dir, exist_ok=True)
    dest = os.path.join(backup_dir, os.path.basename(filepath))
    try:
        os.rename(filepath, dest)
        logger.info("Backed up %s → %s", filepath, dest)
    except Exception as e:
        logger.warning("Failed to back up %s: %s", filepath, e)


def main():
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
    parser = argparse.ArgumentParser(
        description="Migrate gede chat JSON files to SQLite"
    )
    parser.add_argument(
        "--dry-run", action="store_true", help="Only count, do not write to DB"
    )
    parser.add_argument(
        "--backup", action="store_true", help="Move migrated JSON files to backup dir"
    )
    args = parser.parse_args()

    if not args.dry_run:
        print("Initializing database...")
        init_db()

    print("Starting migration...")
    stats = migrate_all(dry_run=args.dry_run, backup=args.backup)

    print(f"\nMigration {'(dry run) ' if args.dry_run else ''}complete:")
    print(f"  Public chats:  {stats['public']}")
    print(f"  Private chats: {stats['private']}")
    print(f"  Failed:        {stats['failed']}")


if __name__ == "__main__":
    main()
