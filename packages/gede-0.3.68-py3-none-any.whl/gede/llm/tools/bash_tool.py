# coding=utf-8
#
# bash_tool.py - 内置 Bash 命令执行工具
#
import asyncio
import logging
import os
import re
import subprocess
from typing import Optional

logger = logging.getLogger(__name__)

# 跟踪当前工作目录（跨调用持久化）
_current_cwd: str = os.getcwd()

# 危险命令模式（正则，忽略大小写）
_DANGEROUS_PATTERNS: list[re.Pattern] = [
    # 递归删除根目录或 home 目录
    re.compile(r"rm\s+.*-[a-zA-Z]*r[a-zA-Z]*f[a-zA-Z]*\s+/\s*$", re.IGNORECASE),
    re.compile(r"rm\s+.*-[a-zA-Z]*r[a-zA-Z]*f[a-zA-Z]*\s+/[^a-zA-Z0-9._~-]", re.IGNORECASE),
    re.compile(r"rm\s+.*-[a-zA-Z]*r[a-zA-Z]*f[a-zA-Z]*\s+(~|/root|/home)\s*$", re.IGNORECASE),
    re.compile(r"rm\s+.*-[a-zA-Z]*r[a-zA-Z]*f[a-zA-Z]*\s+\*", re.IGNORECASE),
    # 格式化磁盘
    re.compile(r"\bmkfs\b", re.IGNORECASE),
    re.compile(r"\bformat\s+[a-zA-Z]:", re.IGNORECASE),  # Windows 风格
    # 覆盖整块磁盘
    re.compile(r"\bdd\b.*\bif=/dev/(zero|urandom|null)\b.*\bof=/dev/(sd|hd|nvme|vd)[a-zA-Z]", re.IGNORECASE),
    re.compile(r"\bdd\b.*\bof=/dev/(sd|hd|nvme|vd)[a-zA-Z]\b", re.IGNORECASE),
    # Fork bomb
    re.compile(r":\(\)\{.*:\|:.*\}", re.IGNORECASE),
    re.compile(r":\s*\(\s*\)\s*\{", re.IGNORECASE),
    # 覆盖关键系统设备
    re.compile(r">\s*/dev/(sda|hda|nvme0)", re.IGNORECASE),
    # 递归修改根目录权限/所有者
    re.compile(r"chmod\s+.*-[a-zA-Z]*R[a-zA-Z]*\s+777\s+/\s*$", re.IGNORECASE),
    re.compile(r"chown\s+.*-[a-zA-Z]*R[a-zA-Z]*\s+\S+\s+/\s*$", re.IGNORECASE),
    # 关机/重启（防止意外中断）
    re.compile(r"\b(shutdown|reboot|halt|poweroff)\b", re.IGNORECASE),
]

# ANSI 转义序列正则
_ANSI_ESCAPE = re.compile(r"\x1b(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")


def _is_dangerous(command: str) -> Optional[str]:
    """检查命令是否匹配危险模式，返回匹配的模式描述（如不危险则返回 None）"""
    cmd = command.strip()
    for pattern in _DANGEROUS_PATTERNS:
        if pattern.search(cmd):
            return pattern.pattern
    return None


def _strip_ansi(text: str) -> str:
    """清除 ANSI 颜色与控制代码"""
    return _ANSI_ESCAPE.sub("", text)


def _truncate_output(text: str, max_lines: int = 100) -> str:
    """截断超大量输出，最多保留 max_lines 行"""
    lines = text.splitlines()
    if len(lines) <= max_lines:
        return text
    kept = lines[:max_lines]
    omitted = len(lines) - max_lines
    kept.append(f"... (省略了 {omitted} 行输出)")
    return "\n".join(kept)


def _ask_confirmation(command: str) -> bool:
    """同步询问用户是否执行命令（在 executor 中运行）"""
    print(f"\n🔧 bash 即将执行命令：\n  {command}")
    try:
        answer = input("允许执行? [y/N] ").strip().lower()
        return answer in ("y", "yes")
    except (EOFError, KeyboardInterrupt):
        return False


async def bash(command: str) -> str:
    """
    Execute a bash shell command on the local system.
    Use this tool when you need to run terminal commands, scripts, or check system state.
    Args:
        command: The bash command to execute
    Returns:
        The combined stdout and stderr output of the command, or an error message
    """
    global _current_cwd

    command = command.strip()
    if not command:
        return "bash: CLI: 命令不能为空"

    # 1. 安全检查
    danger = _is_dangerous(command)
    if danger:
        logger.warning("Dangerous command blocked: %s", command)
        return f"bash: CLI: 安全限制 - 该命令被拒绝执行（匹配危险模式）：{command}"

    # 2. 用户确认（异步安全地在 executor 中运行 input()）
    loop = asyncio.get_running_loop()
    confirmed = await loop.run_in_executor(None, _ask_confirmation, command)
    if not confirmed:
        return "bash: CLI: 用户取消了命令执行"

    # 3. 特殊处理 cd 命令（subprocess 无法改变父进程目录）
    cd_match = re.match(r"^\s*cd\s*(.*?)\s*$", command)
    if cd_match:
        target = cd_match.group(1).strip() or os.path.expanduser("~")
        target = os.path.expanduser(target)
        if not os.path.isabs(target):
            target = os.path.join(_current_cwd, target)
        target = os.path.normpath(target)
        if os.path.isdir(target):
            _current_cwd = target
            return f"已切换工作目录到: {_current_cwd}"
        else:
            return f"bash: CLI: cd: {target}: 目录不存在"

    # 4. 执行命令
    env = os.environ.copy()
    env.update({
        "TERM": "dumb",
        "CI": "true",
        "DEBIAN_FRONTEND": "noninteractive",
        "NO_COLOR": "1",
    })

    try:
        result = await loop.run_in_executor(
            None,
            lambda: subprocess.run(
                command,
                shell=True,
                cwd=_current_cwd,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,  # 合并 stderr 到 stdout
                timeout=30,
                env=env,
            ),
        )
        output = result.stdout.decode("utf-8", errors="replace")
        output = _strip_ansi(output)
        output = _truncate_output(output)

        if result.returncode != 0:
            if output.strip():
                return f"bash: CLI: (exit {result.returncode})\n{output}"
            return f"bash: CLI: 命令以非零退出码 {result.returncode} 结束"

        return output if output.strip() else f"(命令执行成功，无输出，退出码 {result.returncode})"

    except subprocess.TimeoutExpired:
        return "bash: CLI: 命令执行超时（超过 30 秒）"
    except Exception as e:
        logger.error("bash_tool error: %s", e)
        return f"bash: CLI: {e}"
