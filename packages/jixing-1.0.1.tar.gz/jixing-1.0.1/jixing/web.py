import requests

from flask import Flask, jsonify, render_template, request

from .api import (
    delete_session,
    get_session,
    get_stats,
    merge_sessions,
    query_sessions,
    run_moxing,
    run_ollama,
    search_messages,
)


def create_app() -> Flask:
    app = Flask(__name__, template_folder="templates", static_folder="static")
    app.config["JSON_AS_ASCII"] = False

    @app.route("/")
    def index():
        return render_template("index.html")

    @app.route("/api/sessions", methods=["GET"])
    def api_sessions_list():
        provider = request.args.get("provider")
        model = request.args.get("model")
        limit = int(request.args.get("limit", 100))

        result = query_sessions(
            model_provider=provider,
            model_name=model,
            limit=limit,
        )
        return jsonify(result.to_dict())

    @app.route("/api/sessions/<session_id>", methods=["GET"])
    def api_session_get(session_id: str):
        result = get_session(session_id=session_id)
        return jsonify(result.to_dict())

    @app.route("/api/sessions/<session_id>/messages", methods=["GET"])
    def api_session_messages(session_id: str):
        result = get_session(session_id=session_id)
        if not result.success:
            return jsonify(result.to_dict()), 404
        messages = result.data.get("messages", [])
        return jsonify({"success": True, "data": {"session_id": session_id, "messages": messages}})

    @app.route("/api/sessions/<session_id>", methods=["DELETE"])
    def api_session_delete(session_id: str):
        result = delete_session(session_id=session_id)
        return jsonify(result.to_dict())

    @app.route("/api/search", methods=["GET"])
    def api_search():
        query = request.args.get("q", "")
        session_id = request.args.get("session")
        provider = request.args.get("provider")
        limit = int(request.args.get("limit", 100))

        if not query:
            return jsonify({"success": False, "error": "Query required"}), 400

        result = search_messages(
            query=query,
            session_id=session_id,
            model_provider=provider,
            limit=limit,
        )
        return jsonify(result.to_dict())

    @app.route("/api/stats", methods=["GET"])
    def api_stats():
        result = get_stats()
        return jsonify(result.to_dict())

    @app.route("/api/ollama/models", methods=["GET"])
    def api_ollama_models():
        base_url = request.args.get("base_url", "http://localhost:11434")
        try:
            response = requests.get(f"{base_url}/api/tags", timeout=10)
            response.raise_for_status()
            data = response.json()
            models = [m.get("name", "") for m in data.get("models", [])]
            return jsonify({"success": True, "data": {"models": models}})
        except requests.exceptions.ConnectionError:
            return jsonify(
                {"success": False, "error": "Cannot connect to Ollama", "data": {"models": []}}
            ), 503
        except Exception as e:
            return jsonify({"success": False, "error": str(e), "data": {"models": []}}), 500

    @app.route("/api/ollama/run", methods=["POST"])
    def api_ollama_run():
        data = request.get_json()
        if not data:
            return jsonify({"success": False, "error": "JSON body required"}), 400

        model = data.get("model")
        prompt = data.get("prompt")
        session_id = data.get("session_id")

        if not model or not prompt:
            return jsonify({"success": False, "error": "model and prompt required"}), 400

        result = run_ollama(model=model, prompt=prompt, session_id=session_id)
        return jsonify(result.to_dict())

    @app.route("/api/moxing/run", methods=["POST"])
    def api_moxing_run():
        data = request.get_json()
        if not data:
            return jsonify({"success": False, "error": "JSON body required"}), 400

        model = data.get("model")
        prompt = data.get("prompt")
        session_id = data.get("session_id")

        if not model or not prompt:
            return jsonify({"success": False, "error": "model and prompt required"}), 400

        result = run_moxing(model=model, prompt=prompt, session_id=session_id)
        return jsonify(result.to_dict())

    @app.route("/api/sessions/merge", methods=["POST"])
    def api_sessions_merge():
        data = request.get_json()
        if not data:
            return jsonify({"success": False, "error": "JSON body required"}), 400

        session_ids = data.get("session_ids", [])
        merge_mode = data.get("merge_mode", "timeline")
        model_provider = data.get("model_provider")
        model_name = data.get("model_name")

        if not session_ids or len(session_ids) < 2:
            return jsonify({"success": False, "error": "At least 2 session_ids required"}), 400

        result = merge_sessions(
            session_ids=session_ids,
            merge_mode=merge_mode,
            model_provider=model_provider,
            model_name=model_name,
        )
        return jsonify(result.to_dict())

    return app


def create_template_files():
    from pathlib import Path

    templates_dir = Path(__file__).parent / "templates"
    templates_dir.mkdir(exist_ok=True)

    static_dir = Path(__file__).parent / "static"
    static_dir.mkdir(exist_ok=True)

    index_html = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JiXing - 本地大语言模型对话的持久记忆与回溯系统</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #1a1a2e; color: #eee; min-height: 100vh; }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        header { background: #16213e; padding: 20px; border-radius: 10px; margin-bottom: 20px; }
        h1 { color: #00d9ff; }
        .tabs { display: flex; gap: 10px; margin-bottom: 20px; }
        .tab { padding: 10px 20px; background: #16213e; border: none; color: #eee; cursor: pointer; border-radius: 5px; }
        .tab.active { background: #0f3460; color: #00d9ff; }
        .panel { display: none; background: #16213e; padding: 20px; border-radius: 10px; }
        .panel.active { display: block; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; color: #aaa; }
        input, select, textarea { width: 100%; padding: 10px; background: #1a1a2e; border: 1px solid #333; color: #eee; border-radius: 5px; }
        textarea { min-height: 100px; resize: vertical; }
        button { padding: 10px 20px; background: #00d9ff; border: none; color: #1a1a2e; cursor: pointer; border-radius: 5px; font-weight: bold; }
        button:hover { background: #00b8d9; }
        .message { background: #1a1a2e; padding: 15px; border-radius: 5px; margin: 10px 0; border-left: 3px solid #00d9ff; }
        .message.user { border-left-color: #ff6b6b; }
        .message.assistant { border-left-color: #4ecdc4; }
        .meta { font-size: 12px; color: #666; margin-top: 5px; }
        .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; }
        .stat-card { background: #1a1a2e; padding: 20px; border-radius: 5px; text-align: center; }
        .stat-value { font-size: 32px; color: #00d9ff; }
        .stat-label { color: #aaa; margin-top: 5px; }
        .session-list { max-height: 400px; overflow-y: auto; }
        .session-item { padding: 10px; background: #1a1a2e; margin: 5px 0; border-radius: 5px; cursor: pointer; }
        .session-item:hover { background: #0f3460; }
        #chat-container { max-height: 500px; overflow-y: auto; margin-bottom: 20px; }
        .session-history { background: #0f3460; padding: 10px; border-radius: 5px; margin-bottom: 10px; }
        .session-history h3 { color: #00d9ff; margin-bottom: 10px; }
        .model-loading { color: #aaa; font-style: italic; }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>JiXing - 本地大语言模型对话的持久记忆与回溯系统</h1>
            <p>Persistent Memory and Retrieval System for Local LLM Conversations</p>
        </header>

        <div class="tabs">
            <button class="tab active" data-tab="chat">Chat</button>
            <button class="tab" data-tab="sessions">Sessions</button>
            <button class="tab" data-tab="search">Search</button>
            <button class="tab" data-tab="stats">Statistics</button>
        </div>

        <div id="chat" class="panel active">
            <div class="form-group">
                <label>Provider</label>
                <select id="chat-provider">
                    <option value="ollama">Ollama</option>
                    <option value="moxing">Moxing</option>
                </select>
            </div>
            <div class="form-group">
                <label>Model</label>
                <div style="display:flex; gap:10px;">
                    <select id="chat-model" style="flex:1;">
                        <option value="">-- Click Test to Load Models --</option>
                    </select>
                    <button onclick="testOllamaConnection()" style="white-space:nowrap; padding:10px 15px;">Test Connection</button>
                </div>
                <input type="text" id="chat-model-custom" placeholder="Or type custom model name" style="display:none; margin-top:5px;">
                <small id="model-status" style="color:#aaa;"></small>
            </div>
            <div class="form-group">
                <label>Continue Session (optional)</label>
                <select id="chat-session-select">
                    <option value="">-- New Session --</option>
                </select>
            </div>
            <div id="session-history" class="session-history" style="display:none;"></div>
            <div id="chat-container"></div>
            <div class="form-group">
                <textarea id="chat-prompt" placeholder="Enter your prompt..."></textarea>
            </div>
            <button onclick="sendChat()">Send</button>
            <input type="hidden" id="chat-session-id">
        </div>

        <div id="sessions" class="panel">
            <h2>Sessions</h2>
            <div class="form-group">
                <label>Filter by Provider</label>
                <select id="filter-provider">
                    <option value="">All</option>
                    <option value="ollama">Ollama</option>
                    <option value="moxing">Moxing</option>
                </select>
            </div>
            <div class="session-list" id="session-list"></div>
            <button onclick="loadSessions()">Refresh</button>
        </div>

        <div id="search" class="panel">
            <h2>Search Messages</h2>
            <div class="form-group">
                <input type="text" id="search-query" placeholder="Search query...">
            </div>
            <button onclick="doSearch()">Search</button>
            <div id="search-results"></div>
        </div>

        <div id="stats" class="panel">
            <h2>Statistics</h2>
            <div class="stats" id="stats-grid"></div>
            <button onclick="loadStats()">Refresh</button>
        </div>
    </div>

    <script>
        const API_BASE = '/api';

        document.querySelectorAll('.tab').forEach(tab => {
            tab.addEventListener('click', () => {
                document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
                document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
                tab.classList.add('active');
                document.getElementById(tab.dataset.tab).classList.add('active');

                if (tab.dataset.tab === 'sessions') loadSessions();
                if (tab.dataset.tab === 'stats') loadStats();
            });
        });

        document.getElementById('chat-provider').addEventListener('change', function() {
            if (this.value === 'ollama') {
                testOllamaConnection();
            } else {
                document.getElementById('chat-model').innerHTML = '<option value="">-- Enter model manually --</option>';
                document.getElementById('model-status').textContent = '';
            }
        });

        async function testOllamaConnection() {
            const select = document.getElementById('chat-model');
            const status = document.getElementById('model-status');
            select.innerHTML = '<option value="">Testing...</option>';
            status.textContent = 'Connecting to Ollama at localhost:11434...';
            status.style.color = '#aaa';

            try {
                const res = await fetch(API_BASE + '/ollama/models');
                const result = await res.json();

                if (result.success && result.data.models.length > 0) {
                    select.innerHTML = '<option value="">-- Select Model --</option>' + 
                        result.data.models.map(m => `<option value="${m}">${m}</option>`).join('');
                    status.textContent = `Connected! ${result.data.models.length} models available`;
                    status.style.color = '#4ecdc4';
                } else {
                    select.innerHTML = '<option value="">No models found</option>';
                    status.textContent = 'Connected but no models found. Run: ollama pull <model>';
                    status.style.color = '#ffa500';
                }
            } catch (err) {
                select.innerHTML = '<option value="">Connection failed</option>';
                status.textContent = 'Cannot connect to Ollama. Make sure it is running on localhost:11434';
                status.style.color = '#ff6b6b';
            }
        }

        document.getElementById('chat-session-select').addEventListener('change', function() {
            const sessionId = this.value;
            if (sessionId) {
                loadSessionHistory(sessionId);
            } else {
                document.getElementById('session-history').style.display = 'none';
                document.getElementById('chat-container').innerHTML = '';
                document.getElementById('chat-session-id').value = '';
            }
        });

        async function loadSessionList() {
            const select = document.getElementById('chat-session-select');
            const res = await fetch(API_BASE + '/sessions?limit=50');
            const result = await res.json();

            if (result.success) {
                select.innerHTML = '<option value="">-- New Session --</option>' +
                    result.data.map(s => `<option value="${s.id}">${s.model_name} | ${s.created_at.substring(0,19)} | ${s.messages?.length || 0} msgs</option>`).join('');
            }
        }

        async function loadSessionHistory(sessionId) {
            const res = await fetch(API_BASE + '/sessions/' + sessionId + '/messages');
            const result = await res.json();

            const historyDiv = document.getElementById('session-history');
            const chatContainer = document.getElementById('chat-container');

            if (result.success) {
                const messages = result.data.messages;
                document.getElementById('chat-session-id').value = sessionId;

                let historyHtml = `<h3>Session History (${messages.length} messages)</h3>`;
                chatContainer.innerHTML = '';

                messages.forEach(msg => {
                    const roleClass = msg.role === 'user' ? 'user' : 'assistant';
                    const roleLabel = msg.role === 'user' ? 'You' : 'Assistant';
                    const metrics = msg.metrics ? ` | Tokens: ${msg.metrics.eval_count || msg.metrics.tokens || 'N/A'}` : '';
                    chatContainer.innerHTML += `<div class="message ${roleClass}"><strong>${roleLabel}:</strong> ${msg.content}${metrics ? `<div class="meta">${metrics}</div>` : ''}</div>`;
                });

                historyDiv.style.display = 'block';
                chatContainer.scrollTop = chatContainer.scrollHeight;
            } else {
                historyDiv.style.display = 'none';
            }
        }

        async function sendChat() {
            const provider = document.getElementById('chat-provider').value;
            const modelSelect = document.getElementById('chat-model');
            const modelCustom = document.getElementById('chat-model-custom');
            const model = modelSelect.value || modelCustom.value;
            const prompt = document.getElementById('chat-prompt').value;
            const sessionId = document.getElementById('chat-session-id').value;

            if (!model || !prompt) { alert('Model and prompt required'); return; }

            const container = document.getElementById('chat-container');
            container.innerHTML += `<div class="message user"><strong>You:</strong> ${prompt}</div>`;

            const endpoint = provider === 'ollama' ? '/api/ollama/run' : '/api/moxing/run';
            const body = { model, prompt };
            if (sessionId) body.session_id = sessionId;

            const res = await fetch(API_BASE + endpoint, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body)
            });
            const result = await res.json();

            if (result.success) {
                document.getElementById('chat-session-id').value = result.data.session_id;
                const metrics = result.data.metrics;
                container.innerHTML += `<div class="message assistant"><strong>Assistant:</strong> ${result.data.response}<div class="meta">Tokens: ${metrics.eval_count || metrics.tokens || 'N/A'} | Time: ${metrics.wall_time_ms || 'N/A'}ms</div></div>`;
                loadSessionList();
            } else {
                container.innerHTML += `<div class="message assistant"><strong>Error:</strong> ${result.error}</div>`;
            }

            document.getElementById('chat-prompt').value = '';
            container.scrollTop = container.scrollHeight;
        }

        async function loadSessions() {
            const provider = document.getElementById('filter-provider').value;
            let url = API_BASE + '/sessions?limit=100';
            if (provider) url += '&provider=' + provider;

            const res = await fetch(url);
            const result = await res.json();

            const list = document.getElementById('session-list');
            if (result.success) {
                list.innerHTML = result.data.map(s => `<div class="session-item" onclick="loadSession('${s.id}')">${s.id.substring(0,8)}... | ${s.model_provider}/${s.model_name} | ${s.created_at.substring(0,10)}</div>`).join('');
            } else {
                list.innerHTML = '<p>Error loading sessions</p>';
            }
        }

        async function loadSession(sessionId) {
            const res = await fetch(API_BASE + '/sessions/' + sessionId);
            const result = await res.json();
            if (result.success) {
                const s = result.data;
                alert(`Session: ${s.id}\\nProvider: ${s.model_provider}\\nModel: ${s.model_name}\\nMessages: ${s.messages.length}`);
            }
        }

        async function doSearch() {
            const query = document.getElementById('search-query').value;
            if (!query) return;

            const res = await fetch(API_BASE + '/search?q=' + encodeURIComponent(query));
            const result = await res.json();

            const container = document.getElementById('search-results');
            if (result.success) {
                container.innerHTML = result.data.map(m => `<div class="message"><strong>${m.role}</strong> (${m.model_provider}/${m.model_name}): ${m.content.substring(0,200)}...<div class="meta">${m.timestamp}</div></div>`).join('');
            } else {
                container.innerHTML = '<p>Error searching</p>';
            }
        }

        async function loadStats() {
            const res = await fetch(API_BASE + '/stats');
            const result = await res.json();

            const grid = document.getElementById('stats-grid');
            if (result.success) {
                const s = result.data;
                grid.innerHTML = `
                    <div class="stat-card"><div class="stat-value">${s.total_sessions}</div><div class="stat-label">Sessions</div></div>
                    <div class="stat-card"><div class="stat-value">${s.total_messages}</div><div class="stat-label">Messages</div></div>
                    <div class="stat-card"><div class="stat-value">${s.total_tokens}</div><div class="stat-label">Tokens</div></div>
                    <div class="stat-card"><div class="stat-value">${(s.total_duration_ms/1000).toFixed(1)}s</div><div class="stat-label">Duration</div></div>
                `;
            }
        }

        // Initialize on page load
        window.addEventListener('DOMContentLoaded', () => {
            loadSessionList();
            document.getElementById('model-status').textContent = 'Click "Test Connection" to load Ollama models';
        });
    </script>
</body>
</html>
"""
    (templates_dir / "index.html").write_text(index_html)


if __name__ == "__main__":
    create_template_files()
    app = create_app()
    app.run(host="127.0.0.1", port=5000)
