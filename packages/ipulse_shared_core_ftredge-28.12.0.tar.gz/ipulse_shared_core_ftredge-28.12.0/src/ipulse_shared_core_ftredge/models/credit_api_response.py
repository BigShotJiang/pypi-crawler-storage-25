"""Credit-related API response models."""
from typing import Generic, TypeVar, Optional
from pydantic import BaseModel, model_validator
from .base_api_response import BaseAPIResponse

T = TypeVar('T')

CREDIT_DECIMAL_PRECISION = 2


class UserCreditBalance(BaseModel):
    """User's current credit balance."""
    sbscrptn_based_insight_credits: float
    extra_insight_credits: float

    @model_validator(mode='after')
    def round_credit_values(self) -> 'UserCreditBalance':
        self.sbscrptn_based_insight_credits = round(self.sbscrptn_based_insight_credits, CREDIT_DECIMAL_PRECISION)
        self.extra_insight_credits = round(self.extra_insight_credits, CREDIT_DECIMAL_PRECISION)
        return self


class UpdatedUserCreditInfo(BaseModel):
    """Information about credit charging attempt and results."""
    charge_attempted: bool
    charge_successful: bool
    cost_incurred: float
    items_processed_for_charge: int
    user_balance: UserCreditBalance

    @model_validator(mode='after')
    def round_cost_value(self) -> 'UpdatedUserCreditInfo':
        self.cost_incurred = round(self.cost_incurred, CREDIT_DECIMAL_PRECISION)
        return self


class CreditChargeableAPIResponse(BaseAPIResponse[T], Generic[T]):
    """API response for endpoints that may charge credits."""
    updated_user_credit_info: Optional[UpdatedUserCreditInfo] = None
