"""
WebhookIdempotencyRecord model -- prevents duplicate webhook processing.

Simple key-value stored in Firestore collection 'papp_core_billing_webhook_idempotency'.
Document ID = Stripe event ID or Checkout Session ID.
Both verify-session and webhook handlers share this collection for idempotency.
"""

from datetime import datetime, timezone
from typing import Optional, ClassVar
from pydantic import Field, ConfigDict
from ..base_nosql_model import BaseNoSQLModel


class WebhookIdempotencyRecord(BaseNoSQLModel):
    """
    Idempotency record to prevent duplicate processing of Stripe events.

    Both the verify-session endpoint (primary activation) and webhook handler
    (backup activation) write to the same collection. Whichever processes
    first writes the record; the second path sees it and becomes a no-op.
    """

    model_config = ConfigDict(frozen=True, extra="ignore")

    SCHEMA_ID: ClassVar[str] = ""
    SCHEMA_NAME: ClassVar[str] = ""
    VERSION: ClassVar[int] = 1
    DOMAIN: ClassVar[str] = "papp_core_billing"
    OBJ_REF: ClassVar[str] = "webhook_idempotency"
    COLLECTION_NAME: ClassVar[str] = "papp_core_billing_webhook_idempotency"

    user_uid: Optional[str] = Field(
        default=None,
        description="Firebase Auth UID of the user associated with this event"
    )

    id: Optional[str] = Field(
        default=None,
        description="Document ID = Stripe event ID (evt_xxx) or Checkout Session ID (cs_xxx)"
    )

    processed_timestamp_utc: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        description="When this event/session was processed"
    )

    event_type: Optional[str] = Field(
        default=None,
        description="Stripe event type (e.g., 'invoice.paid') or 'checkout_verify_session'"
    )

    result: str = Field(
        ...,
        description="Processing result: 'success', 'failed', or 'skipped_duplicate'"
    )

    source: Optional[str] = Field(
        default=None,
        description="Which path processed this: 'verify_session' or 'stripe_webhook'"
    )
