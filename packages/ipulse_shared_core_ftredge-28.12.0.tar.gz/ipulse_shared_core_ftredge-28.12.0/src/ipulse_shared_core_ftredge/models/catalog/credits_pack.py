"""
CreditsPack model -- catalog definition for purchasable credits packs.

Stored in Firestore collection 'papp_core_catalog_credit_packs'.
Each document represents a purchasable credits pack with Stripe Price linkage.

Follows the same structural conventions as SubscriptionPlan:
- pack_name + pack_version -> auto-generated id
- pulse_status (ObjectOverallStatus) for lifecycle management
- Stripe product/price linkage
- purchasable flag
"""

from typing import Optional, ClassVar, List, Any
from pydantic import Field, ConfigDict, model_validator
from ipulse_shared_base_ftredge import (
    Layer, Module, list_enums_as_lower_strings, SystemSubject,
    ObjectOverallStatus, SubscriptionPlanName,
)
from ..base_nosql_model import BaseNoSQLModel


############################################ !!!!! ALWAYS UPDATE SCHEMA VERSION IF SCHEMA IS BEING MODIFIED !!! ############################################
class CreditsPack(BaseNoSQLModel):
    """
    Configuration template for purchasable credits packs stored in Firestore.

    Each credits pack defines a one-time purchasable bundle of insight credits
    with pricing, Stripe linkage, and plan eligibility rules.

    Follows the same catalog conventions as SubscriptionPlan:
    - Versioned (pack_name + pack_version)
    - pulse_status lifecycle
    - Stripe integration fields
    """

    # extra="ignore" inherited from BaseNoSQLModel — NoSQL docs may contain fields not yet in the model

    SCHEMA_ID: ClassVar[str] = ""
    SCHEMA_NAME: ClassVar[str] = ""
    VERSION: ClassVar[int] = 2  # v2: Aligned with catalog conventions (pulse_status, pack_version, naming)
    DOMAIN: ClassVar[str] = "_".join(list_enums_as_lower_strings(Layer.PULSE_APP, Module.CORE, SystemSubject.CATALOG))
    OBJ_REF: ClassVar[str] = "creditspack"
    COLLECTION_NAME: ClassVar[str] = "papp_core_catalog_credit_packs"

    # ---------- Identity ----------

    id: Optional[str] = Field(
        default=None,
        description="Unique credits pack ID (auto-generated: {pack_name}_{pack_version})",
        frozen=True
    )

    pack_name: str = Field(
        ...,
        min_length=1,
        description="Stable identifier for this credits pack (e.g., 'credits_1000')",
        frozen=True
    )

    pack_version: int = Field(
        ...,
        ge=1,
        description="Version of this credit pack template",
        frozen=True
    )

    pulse_status: ObjectOverallStatus = Field(
        default=ObjectOverallStatus.ACTIVE,
        description="Overall status of this credits pack configuration"
    )

    # ---------- Display ----------

    display_name: str = Field(
        ...,
        min_length=1,
        description="Human-readable name (e.g., '1,000 Extra Credits')",
        frozen=True
    )

    description: str = Field(
        ...,
        min_length=1,
        description="Description of what this credits pack provides",
        frozen=True
    )

    # ---------- Credit configuration ----------

    credits_amount: int = Field(
        ...,
        gt=0,
        description="Number of insight credits granted by this credits pack",
        frozen=True
    )

    # ---------- Pricing ----------

    price_usd: float = Field(
        ...,
        gt=0,
        description="Price of this credits pack in USD",
        frozen=True
    )

    # ---------- Stripe payment fields ----------

    stripe_product_id: Optional[str] = Field(
        default=None,
        description="Stripe Product ID for this credits pack"
    )

    stripe_price_id: Optional[str] = Field(
        default=None,
        description="Stripe Price ID for one-time credits pack payment"
    )

    purchasable: bool = Field(
        default=True,
        description="Whether this credits pack can be purchased via Stripe checkout"
    )

    # ---------- Purchase limits ----------

    max_purchases_per_day: int = Field(
        default=1,
        ge=1,
        description="Maximum purchases of this specific credits pack per user per UTC day",
        frozen=True
    )

    # ---------- Plan eligibility ----------

    available_for_plans: List[SubscriptionPlanName] = Field(
        default_factory=list,
        description=(
            "Subscription plan names eligible to purchase this credits pack. "
            "Empty list means available to all plans."
        ),
        frozen=True
    )

    # ---------- Validators ----------

    @model_validator(mode='before')
    @classmethod
    def set_id_if_not_provided(cls, data: Any) -> Any:
        """Generate an ID from pack_name and pack_version if not provided."""
        if isinstance(data, dict):
            pack_name = data.get('pack_name')
            pack_version = data.get('pack_version')
            provided_id = data.get('id')

            if pack_name and pack_version is not None:
                expected_id = f"{pack_name}_{pack_version}"

                if provided_id is None:
                    data['id'] = expected_id
                else:
                    if provided_id != expected_id:
                        raise ValueError(
                            f"Invalid ID format. Expected '{expected_id}' based on "
                            f"pack_name='{pack_name}' and pack_version={pack_version}, "
                            f"but got '{provided_id}'. ID must follow format: {{pack_name}}_{{pack_version}}"
                        )
        return data
