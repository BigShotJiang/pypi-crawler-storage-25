"""
Centralised secret retrieval for all Pulse Application microservices.

Provides ``SecretManager`` -- a pure utility class that fetches secrets from
Google Secret Manager.  It takes all configuration as constructor parameters
and performs NO environment variable reads or side effects of its own.

Usage (in any microservice's firebase_init.py)::

    from ipulse_shared_core_ftredge.utils.secrets import SecretManager

    # Caller owns env, project_id, logger, and the local-fallback env name.
    secrets = SecretManager(
        env=ENV,
        project_id=PROJECT_ID,
        logger=logger,
        local_sm_fallback_env="staging",   # default -- see docstring
    )

    # Simple string secret
    stripe_key = secrets.get("stripe-secret-key")

    # With a caller-resolved fallback value (e.g. from an env var the caller read)
    stripe_key = secrets.get("stripe-secret-key",
                             fallback_value=os.getenv("STRIPE_SECRET_KEY", ""))

    # JSON-parsed secret (e.g. service-account key)
    sa_key = secrets.get("firebase-service-account-key", parse_json=True,
                         fallback_value=os.getenv("FIREBASE_SERVICE_ACCOUNT_KEY_JSON", ""))

Resolution order
================

+---------------------+----------------------------------------------------------+
| Environment         | Resolution                                               |
+=====================+==========================================================+
| staging / production| Google Secret Manager only                               |
|                     | ``projects/{project_id}/secrets/{name}-{env}/latest``    |
+---------------------+----------------------------------------------------------+
| local / localdocker | 1. ``fallback_value`` (if non-empty) -- caller supplies  |
|                     | 2. Secret Manager using ``local_sm_fallback_env`` suffix |
|                     |    (defaults to ``"staging"``)                           |
+---------------------+----------------------------------------------------------+

**Why default ``local_sm_fallback_env`` to "staging"?**
Local development should mirror the staging environment as closely as possible.
By pulling real staging secrets from Secret Manager, we validate the full
integration path locally -- so when we deploy to staging, we are almost certain
everything works as expected.  Pass ``local_sm_fallback_env=""`` to disable
this fallback entirely (e.g. for fully offline development).
"""

from __future__ import annotations

import json
import logging
from typing import Optional

from google.cloud import secretmanager


class SecretManager:
    """
    Pure utility for fetching secrets from Google Secret Manager.

    All configuration is supplied by the caller -- this class never reads
    environment variables, creates loggers, or performs any implicit side effects.

    Args:
        env:                    Current environment (local / localdocker / staging / production).
        project_id:             GCP project ID that hosts the secrets.
        logger:                 Logger instance from the calling microservice.
        local_sm_fallback_env:  When running locally and no ``fallback_value`` is provided,
                                use this environment suffix to fetch from Secret Manager.
                                Defaults to ``"staging"`` so local dev mirrors staging.
                                Pass ``""`` to disable Secret Manager fallback entirely.
    """

    # Process-wide Secret Manager gRPC client (shared across all instances)
    _sm_client: Optional[secretmanager.SecretManagerServiceClient] = None

    def __init__(
        self,
        env: str,
        project_id: str,
        logger: logging.Logger,
        local_sm_fallback_env: str = "staging",
    ):
        self.env = env
        self.project_id = project_id
        self.logger = logger
        self.local_sm_fallback_env = local_sm_fallback_env

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get(
        self,
        secret_name: str,
        fallback_value: str = "",
        parse_json: bool = False,
    ) -> str | dict:
        """
        Retrieve a secret value.

        Args:
            secret_name:    Base name in Secret Manager (env suffix auto-appended,
                            e.g. ``stripe-secret-key`` -> ``stripe-secret-key-staging``).
            fallback_value: An already-resolved value (e.g. from an env var the caller read).
                            Used only in local/localdocker as first-priority override.
                            Ignored in staging/production.
            parse_json:     JSON-decode the payload (e.g. service-account key files).

        Returns:
            ``str`` or ``dict`` (when *parse_json* is True).
            ``""`` / ``{}`` when the secret cannot be resolved.
        """
        empty: str | dict = {} if parse_json else ""

        # ---- Deployed environments: Secret Manager only ----
        if self.env in ("staging", "production"):
            return self._fetch(secret_name, self.env, parse_json, empty)

        # ---- Local / localdocker ----

        # 1. Caller-supplied fallback (highest priority)
        if fallback_value:
            return json.loads(fallback_value) if parse_json else fallback_value

        # 2. Secret Manager using the configured local fallback env
        if self.local_sm_fallback_env:
            self.logger.info(
                "No fallback_value for '%s'; trying Secret Manager (%s)...",
                secret_name,
                self.local_sm_fallback_env,
            )
            return self._fetch(secret_name, self.local_sm_fallback_env, parse_json, empty)

        return empty

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    @classmethod
    def _get_sm_client(cls) -> secretmanager.SecretManagerServiceClient:
        """Return (or create) a process-wide Secret Manager gRPC client."""
        if cls._sm_client is None:
            cls._sm_client = secretmanager.SecretManagerServiceClient()
        return cls._sm_client

    def _fetch(
        self,
        secret_name: str,
        env_suffix: str,
        parse_json: bool,
        empty: str | dict,
    ) -> str | dict:
        """Fetch a single secret from Google Secret Manager."""
        try:
            client = self._get_sm_client()
            resource_name = (
                f"projects/{self.project_id}/secrets/"
                f"{secret_name}-{env_suffix}/versions/latest"
            )
            payload = (
                client.access_secret_version(request={"name": resource_name})
                .payload.data.decode("UTF-8")
            )
            self.logger.info(
                "Secret '%s' loaded from Secret Manager (%s).",
                secret_name,
                env_suffix,
            )
            return json.loads(payload) if parse_json else payload
        except Exception as e:
            self.logger.warning(
                "Failed to load secret '%s' from Secret Manager (%s): %s",
                secret_name,
                env_suffix,
                e,
            )
            return empty
