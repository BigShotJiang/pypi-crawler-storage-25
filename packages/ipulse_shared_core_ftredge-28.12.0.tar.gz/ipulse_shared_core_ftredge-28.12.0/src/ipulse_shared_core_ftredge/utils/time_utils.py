"""
Time and period arithmetic utilities for subscription billing.

Uses dateutil.relativedelta for calendar-correct arithmetic:
  - 1 month from Jan 31  -> Feb 28 (or Feb 29 in a leap year)
  - 1 month from Mar 31  -> Apr 30
  - 1 year  from Feb 29  -> Feb 28 (non-leap year)

This is the industry-standard approach used by Stripe and all major billing
platforms.
"""

from datetime import datetime, timezone
from typing import Union

from dateutil.relativedelta import relativedelta
from ipulse_shared_base_ftredge import TimeUnit


# ──────────────────────────────────────────────────────────────────────────────
# Calendar-correct period arithmetic (for billing)
# ──────────────────────────────────────────────────────────────────────────────

# Map TimeUnit to relativedelta constructor.
_RELATIVEDELTA_MAP = {
    TimeUnit.MINUTE: lambda n: relativedelta(minutes=n),
    TimeUnit.HOUR:   lambda n: relativedelta(hours=n),
    TimeUnit.DAY:    lambda n: relativedelta(days=n),
    TimeUnit.WEEK:   lambda n: relativedelta(weeks=n),
    TimeUnit.MONTH:  lambda n: relativedelta(months=n),
    TimeUnit.YEAR:   lambda n: relativedelta(years=n),
}


def add_time_unit_period(base: datetime, length: int, unit: Union[TimeUnit, str]) -> datetime:
    """
    Add a time period to a base datetime using calendar-correct arithmetic.

    Args:
        base: Starting datetime (should be timezone-aware UTC).
        length: Number of units to add (must be > 0).
        unit: TimeUnit enum value **or** its lowercase string representation
              (e.g., "month", "day"). Accepted for backward compatibility
              with Firestore data that may arrive as plain strings.

    Returns:
        New datetime after adding the period.

    Raises:
        ValueError: If length <= 0 or unit is unsupported.
    """
    if length <= 0:
        raise ValueError(f"Period length must be positive, got {length}")

    resolved_unit = _resolve_time_unit(unit)

    builder = _RELATIVEDELTA_MAP.get(resolved_unit)
    if builder is None:
        raise ValueError(
            f"Unsupported TimeUnit for billing period: {resolved_unit}. "
            f"Supported: {list(_RELATIVEDELTA_MAP.keys())}"
        )

    return base + builder(length)


# ──────────────────────────────────────────────────────────────────────────────
# Expiration / remaining-time helpers
# ──────────────────────────────────────────────────────────────────────────────

def is_expiring_soon(expiration: datetime, threshold_days: int = 7) -> bool:
    """
    Check whether an expiration datetime is within *threshold_days* from now
    and has NOT already expired.

    Args:
        expiration: The expiration datetime (timezone-aware UTC).
        threshold_days: Days before expiration to consider "soon". Default 7.

    Returns:
        True if expiration is within the threshold window and in the future.
    """
    now = datetime.now(timezone.utc)
    if expiration <= now:
        return False  # Already expired
    remaining = (expiration - now).total_seconds()
    threshold_seconds = threshold_days * 86400.0
    return remaining <= threshold_seconds


def remaining_seconds(expiration: datetime) -> float:
    """
    Seconds remaining until *expiration*. Returns 0.0 if already expired.

    Args:
        expiration: The expiration datetime (timezone-aware UTC).

    Returns:
        Non-negative float of seconds remaining.
    """
    now = datetime.now(timezone.utc)
    return max(0.0, (expiration - now).total_seconds())


def time_remaining_delta(expiration: datetime) -> relativedelta:
    """
    Calendar-correct remaining time from now until *expiration*.

    Returns a ``relativedelta`` with actual months, days, hours, etc. --
    no fixed 30-day or 365-day approximations.

    If *expiration* is in the past, returns a zero-valued relativedelta.

    Example:
        >>> exp = datetime(2026, 5, 15, 12, 0, tzinfo=timezone.utc)
        >>> delta = time_remaining_delta(exp)
        >>> delta.months   # actual calendar months
        2
        >>> delta.days     # remaining days after full months
        9

    Args:
        expiration: The expiration datetime (timezone-aware UTC).

    Returns:
        A relativedelta representing the calendar distance. Access
        ``.years``, ``.months``, ``.days``, ``.hours``, ``.minutes``,
        ``.seconds`` for individual components.
    """
    now = datetime.now(timezone.utc)
    if expiration <= now:
        return relativedelta()  # all zeros
    return relativedelta(expiration, now)


# ──────────────────────────────────────────────────────────────────────────────
# Internal helpers
# ──────────────────────────────────────────────────────────────────────────────

def _resolve_time_unit(unit: Union[TimeUnit, str]) -> TimeUnit:
    """
    Normalize a TimeUnit or its string representation to a TimeUnit enum.

    Accepts both TimeUnit.MONTH and "month" (case-insensitive).

    Args:
        unit: TimeUnit enum value or string.

    Returns:
        Resolved TimeUnit enum value.

    Raises:
        ValueError: If the string does not match any TimeUnit member.
    """
    if isinstance(unit, TimeUnit):
        return unit

    # Accept string values (case-insensitive)
    unit_lower = str(unit).lower().strip()
    try:
        return TimeUnit(unit_lower)
    except ValueError:
        raise ValueError(
            f"Cannot resolve '{unit}' to a TimeUnit. "
            f"Valid values: {[u.value for u in TimeUnit]}"
        ) from None
