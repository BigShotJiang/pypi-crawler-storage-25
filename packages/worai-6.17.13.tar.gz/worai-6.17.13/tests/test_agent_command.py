from __future__ import annotations

import io
import json
import os
import time
import tempfile
from pathlib import Path
from types import SimpleNamespace

import pytest
from typer.testing import CliRunner

from worai import cli as root_cli
from worai.agent.skills import build_skill_text
from worai.agent import mcp_server as mcp_server_mod
from worai.agent.mcp_server import McpTransport, SessionDefaults, WoraiMcpServer
from worai.commands import agent as agent_cmd


def test_root_cli_includes_agent_command() -> None:
    result = CliRunner().invoke(root_cli.app, ["--help"])
    assert result.exit_code == 0
    assert "agent" in result.output
    assert "Launch external agent CLIs with worai MCP" in result.output
    assert "skill guidance" in result.output
    assert "pass agent flags after" in result.output


def test_agent_dry_run_codex_wires_assets(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setattr(agent_cmd, "shutil_which", lambda _name: "/usr/bin/fake")
    (tmp_path / "tmp").mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr(agent_cmd, "_create_session_dir", lambda: tmp_path / "tmp")
    monkeypatch.setattr(
        agent_cmd.subprocess,
        "run",
        lambda *_args, **_kwargs: SimpleNamespace(returncode=0, stdout="[]", stderr=""),
    )

    result = CliRunner().invoke(
        root_cli.app,
        ["agent", "--agent-cli", "codex", "--dry-run", "--profile", "acme", "--config", "worai.toml"],
    )
    assert result.exit_code == 0
    assert "skills:" in result.output
    assert "mcp_config:" in result.output
    assert "launch:" in result.output
    assert 'model="gpt-5.2-codex-graph-sync"' in result.output
    assert 'model_provider="wordlift"' in result.output
    assert "model_providers.wordlift=" in result.output
    assert '"X-API-Key"="***REDACTED***"' in result.output
    assert '"X-API-Key"="acme"' not in result.output

    mcp_file = tmp_path / "tmp" / "mcp.json"
    payload = json.loads(mcp_file.read_text(encoding="utf-8"))
    assert payload["mcpServers"]["worai"]["type"] == "http"
    assert payload["mcpServers"]["worai"]["url"].startswith("http://127.0.0.1:")
    assert payload["mcpServers"]["wordlift"]["url"].startswith("https://")


def test_agent_run_invokes_subprocess_and_exits(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setattr(agent_cmd, "shutil_which", lambda _name: "/usr/bin/fake")
    (tmp_path / "tmp").mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr(agent_cmd, "_create_session_dir", lambda: tmp_path / "tmp")
    seen: dict[str, object] = {}

    def _stub_run(command, env=None, check=False, stdout=None, stderr=None):
        seen["command"] = command
        seen["env"] = env
        return SimpleNamespace(returncode=0)

    monkeypatch.setattr(agent_cmd.subprocess, "run", _stub_run)
    result = CliRunner().invoke(root_cli.app, ["agent", "--agent-cli", "claude"])
    assert result.exit_code == 0
    assert seen["command"][0] == "claude"
    assert "--mcp-config" in seen["command"]


def test_agent_dry_run_claude_wires_mcp_config(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setattr(agent_cmd, "shutil_which", lambda _name: "/usr/bin/fake")
    (tmp_path / "tmp").mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr(agent_cmd, "_create_session_dir", lambda: tmp_path / "tmp")

    result = CliRunner().invoke(
        root_cli.app,
        ["agent", "--agent-cli", "claude", "--dry-run", "--profile", "acme", "--config", "worai.toml"],
    )
    assert result.exit_code == 0
    assert "mcp_config:" in result.output
    assert "--mcp-config" in result.output

    mcp_file = tmp_path / "tmp" / "mcp.json"
    payload = json.loads(mcp_file.read_text(encoding="utf-8"))
    assert payload["mcpServers"]["worai"]["type"] == "http"
    assert payload["mcpServers"]["worai"]["url"].startswith("http://127.0.0.1:")
    assert payload["mcpServers"]["wordlift"]["type"] in {"http", "sse"}
    assert payload["mcpServers"]["wordlift"]["url"].startswith("https://")


def test_agent_dry_run_forwards_passthrough_args_after_double_dash(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setattr(agent_cmd, "shutil_which", lambda _name: "/usr/bin/fake")
    (tmp_path / "tmp").mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr(agent_cmd, "_create_session_dir", lambda: tmp_path / "tmp")
    monkeypatch.setattr(
        agent_cmd.subprocess,
        "run",
        lambda *_args, **_kwargs: SimpleNamespace(returncode=0, stdout="[]", stderr=""),
    )
    monkeypatch.setenv("WORAI_PROFILE", "acme")

    result = CliRunner().invoke(
        root_cli.app,
        ["agent", "--agent-cli", "codex", "--dry-run", "--", "--yolo", "--search"],
    )

    assert result.exit_code == 0
    assert "--yolo" in result.output
    assert "--search" in result.output
    assert "launch:" in result.output


def test_agent_codex_uses_real_home_and_skips_configured_mcp_servers(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setattr(agent_cmd, "shutil_which", lambda _name: "/usr/bin/fake")
    (tmp_path / "tmp").mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr(agent_cmd, "_create_session_dir", lambda: tmp_path / "tmp")
    seen: dict[str, object] = {}

    def _stub_run(command, env=None, check=False, stdout=None, stderr=None, capture_output=False, text=False):
        del check, stdout, stderr, capture_output, text
        if command[:4] == ["codex", "mcp", "list", "--json"]:
            return SimpleNamespace(
                returncode=0,
                stdout=json.dumps([{"name": "worai"}, {"name": "wordlift"}]),
                stderr="",
            )
        seen["command"] = command
        seen["env"] = env
        return SimpleNamespace(returncode=0)

    monkeypatch.setattr(agent_cmd.subprocess, "run", _stub_run)
    result = CliRunner().invoke(root_cli.app, ["agent", "--agent-cli", "codex", "--profile", "acme"])
    assert result.exit_code == 0
    assert seen["command"][0] == "codex"
    assert 'model="gpt-5.2-codex-graph-sync"' in seen["command"]
    assert 'model_provider="wordlift"' in seen["command"]
    assert not any("mcp_servers.worai=" in item for item in seen["command"])
    assert not any("mcp_servers.wordlift=" in item for item in seen["command"])
    assert seen["env"]["HOME"] == os.environ["HOME"]


def test_agent_codex_warns_on_default_fallback_when_profile_unspecified(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setattr(agent_cmd, "shutil_which", lambda _name: "/usr/bin/fake")
    (tmp_path / "tmp").mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr(agent_cmd, "_create_session_dir", lambda: tmp_path / "tmp")
    monkeypatch.setattr(
        agent_cmd.subprocess,
        "run",
        lambda *_args, **_kwargs: SimpleNamespace(returncode=0, stdout="[]", stderr=""),
    )
    config_path = tmp_path / "worai.toml"
    config_path.write_text("[profiles.default]\napi_key = 'unused'\n", encoding="utf-8")
    monkeypatch.delenv("WORAI_PROFILE", raising=False)

    result = CliRunner().invoke(
        root_cli.app,
        ["agent", "--agent-cli", "codex", "--dry-run", "--config", str(config_path)],
    )

    assert result.exit_code == 0
    assert "Warning: no profile provided; falling back to default profile." in result.output


def test_agent_codex_errors_when_default_profile_missing(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setattr(agent_cmd, "shutil_which", lambda _name: "/usr/bin/fake")
    (tmp_path / "tmp").mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr(agent_cmd, "_create_session_dir", lambda: tmp_path / "tmp")
    config_path = tmp_path / "worai.toml"
    config_path.write_text("[profiles.acme]\napi_key = 'unused'\n", encoding="utf-8")
    monkeypatch.delenv("WORAI_PROFILE", raising=False)

    result = CliRunner().invoke(
        root_cli.app,
        ["agent", "--agent-cli", "codex", "--dry-run", "--config", str(config_path)],
    )

    assert result.exit_code == 1
    assert result.exception is not None
    assert "Profile 'default' was not found" in str(result.exception)


def test_agent_dry_run_codex_user_config_skips_wordlift_provider_injection(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setattr(agent_cmd, "shutil_which", lambda _name: "/usr/bin/fake")
    (tmp_path / "tmp").mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr(agent_cmd, "_create_session_dir", lambda: tmp_path / "tmp")
    monkeypatch.setattr(
        agent_cmd.subprocess,
        "run",
        lambda *_args, **_kwargs: SimpleNamespace(returncode=0, stdout="[]", stderr=""),
    )

    result = CliRunner().invoke(
        root_cli.app,
        ["agent", "--agent-cli", "codex", "--codex-use-user-config", "--dry-run"],
    )
    assert result.exit_code == 0
    assert 'model="gpt-5.2-codex-graph-sync"' not in result.output
    assert 'model_provider="wordlift"' not in result.output
    assert "model_providers.wordlift=" not in result.output
    assert "X-API-Key" not in result.output
    assert "mcp_servers.worai=" in result.output
    assert "Warning: no profile provided; falling back to default profile." not in result.output


def test_agent_codex_stdio_dry_run_injects_stdio_mcp_server(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setattr(agent_cmd, "shutil_which", lambda _name: "/usr/bin/fake")
    (tmp_path / "tmp").mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr(agent_cmd, "_create_session_dir", lambda: tmp_path / "tmp")
    monkeypatch.setattr(
        agent_cmd.subprocess,
        "run",
        lambda *_args, **_kwargs: SimpleNamespace(returncode=0, stdout="[]", stderr=""),
    )

    result = CliRunner().invoke(
        root_cli.app,
        ["agent", "--agent-cli", "codex", "--mcp-transport", "stdio", "--dry-run", "--profile", "acme"],
    )

    assert result.exit_code == 0
    assert "mcp_servers.worai=" in result.output
    assert "worai.agent.mcp_server" in result.output


def test_resolve_agent_profile_precedence_matrix() -> None:
    assert agent_cmd._resolve_agent_profile(cli_profile="cli", root_profile="root", env={}) == ("cli", False)
    assert agent_cmd._resolve_agent_profile(cli_profile=None, root_profile="root", env={}) == ("root", False)
    assert agent_cmd._resolve_agent_profile(
        cli_profile=None, root_profile=None, env={"WORAI_PROFILE": "env"}
    ) == ("env", False)
    assert agent_cmd._resolve_agent_profile(cli_profile=None, root_profile=None, env={}) == ("default", True)


def test_profile_exists_success_absent_and_invalid_toml(tmp_path: Path) -> None:
    valid = tmp_path / "valid.toml"
    valid.write_text("[profiles.default]\napi_key='x'\n", encoding="utf-8")
    assert agent_cmd._profile_exists(str(valid), "default") is True
    assert agent_cmd._profile_exists(str(valid), "acme") is False
    assert agent_cmd._profile_exists(str(tmp_path / "missing.toml"), "default") is False

    invalid = tmp_path / "invalid.toml"
    invalid.write_text("[profiles.default\n", encoding="utf-8")
    with pytest.raises(agent_cmd.UsageError):
        agent_cmd._profile_exists(str(invalid), "default")


def test_redact_launch_command_masks_api_key_value() -> None:
    redacted = agent_cmd._redact_launch_command(
        ['model_providers.wordlift={http_headers={"X-API-Key"="acme"}}']
    )
    assert redacted[0] == 'model_providers.wordlift={http_headers={"X-API-Key"="***REDACTED***"}}'


def test_mcp_serve_resolves_config_and_invokes_stdio(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    seen: dict[str, str | None] = {}

    def _stub_run_stdio_server(*, config_path: str | None, profile: str | None) -> int:
        seen["config_path"] = config_path
        seen["profile"] = profile
        return 0

    config_path = tmp_path / "worai.toml"
    config_path.write_text("", encoding="utf-8")
    monkeypatch.setattr(agent_cmd, "run_stdio_server", _stub_run_stdio_server)

    result = CliRunner().invoke(
        root_cli.app,
        ["agent", "mcp", "serve", "--config", str(config_path), "--profile", "acme"],
    )
    assert result.exit_code == 0
    assert seen["config_path"] == str(config_path.resolve())
    assert seen["profile"] == "acme"


def test_resolve_executable_prefers_override() -> None:
    assert agent_cmd._resolve_executable(agent_cmd.AgentCli.codex, " /custom/codex ") == "/custom/codex"


def test_require_executable_allows_existing_absolute_path(tmp_path: Path) -> None:
    binary = tmp_path / "codex"
    binary.write_text("", encoding="utf-8")
    agent_cmd._require_executable(str(binary.resolve()))


def test_build_launch_command_codex_requires_customer_key(tmp_path: Path) -> None:
    prompt = tmp_path / "WORDLIFT.md"
    prompt.write_text("prompt", encoding="utf-8")
    assets = agent_cmd.AgentLaunchAssets(
        temp_dir=tmp_path,
        skills_path=tmp_path / "skill.md",
        wordlift_md_path=prompt,
        mcp_config_path=tmp_path / "mcp.json",
        gemini_home=tmp_path / "gemini-home",
    )

    with pytest.MonkeyPatch.context() as monkeypatch:
        monkeypatch.setattr(agent_cmd, "_configured_codex_mcp_servers", lambda _exec: set())
        with pytest.raises(agent_cmd.UsageError):
            agent_cmd._build_launch_command(
                agent_cli=agent_cmd.AgentCli.codex,
                agent_exec="codex",
                assets=assets,
                config=None,
                profile="acme",
                transport=agent_cmd.McpTransport.http,
                mcp_url="http://127.0.0.1:1111/mcp",
                codex_customer_key=None,
                codex_use_user_config=False,
                passthrough=[],
            )


def test_build_launch_command_codex_user_config_allows_missing_customer_key(tmp_path: Path) -> None:
    prompt = tmp_path / "WORDLIFT.md"
    prompt.write_text("prompt", encoding="utf-8")
    assets = agent_cmd.AgentLaunchAssets(
        temp_dir=tmp_path,
        skills_path=tmp_path / "skill.md",
        wordlift_md_path=prompt,
        mcp_config_path=tmp_path / "mcp.json",
        gemini_home=tmp_path / "gemini-home",
    )

    with pytest.MonkeyPatch.context() as monkeypatch:
        monkeypatch.setattr(agent_cmd, "_configured_codex_mcp_servers", lambda _exec: set())
        cmd, _ = agent_cmd._build_launch_command(
            agent_cli=agent_cmd.AgentCli.codex,
            agent_exec="codex",
            assets=assets,
            config=None,
            profile=None,
            transport=agent_cmd.McpTransport.http,
            mcp_url="http://127.0.0.1:1111/mcp",
            codex_customer_key=None,
            codex_use_user_config=True,
            passthrough=[],
        )
    joined = " ".join(cmd)
    assert "model_provider" not in joined
    assert "model_providers.wordlift" not in joined


def test_configured_codex_mcp_servers_missing_binary_returns_empty() -> None:
    with pytest.MonkeyPatch.context() as monkeypatch:
        monkeypatch.setattr(
            agent_cmd.subprocess,
            "run",
            lambda *_a, **_kw: (_ for _ in ()).throw(FileNotFoundError("codex not found")),
        )
        assert agent_cmd._configured_codex_mcp_servers("codex") == set()


def test_agent_gemini_launches_directly(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Gemini is launched directly — no gemini mcp add/remove bootstrap calls."""
    monkeypatch.setattr(agent_cmd, "shutil_which", lambda _name: "/usr/bin/fake")
    (tmp_path / "tmp").mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr(agent_cmd, "_create_session_dir", lambda: tmp_path / "tmp")
    monkeypatch.setattr(agent_cmd, "_setup_gemini_home", lambda temp_dir: temp_dir / "gemini-home")
    calls: list[list[str]] = []

    def _stub_run(command, **_kwargs):
        calls.append(command)
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    monkeypatch.setattr(agent_cmd.subprocess, "run", _stub_run)
    result = CliRunner().invoke(root_cli.app, ["agent", "--agent-cli", "gemini"])
    assert result.exit_code == 0
    # Only one subprocess call: the gemini launch itself
    assert len(calls) == 1
    assert calls[0] == ["gemini"]


def test_agent_gemini_settings_written_with_mcp_servers_stdio(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """settings.json is written with mcpServers (stdio) and mcp.allowed — no bootstrap needed."""
    monkeypatch.setattr(agent_cmd, "shutil_which", lambda _name: "/usr/bin/fake")
    (tmp_path / "tmp").mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr(agent_cmd, "_create_session_dir", lambda: tmp_path / "tmp")
    gemini_home = tmp_path / "tmp" / "gemini-home"
    monkeypatch.setattr(agent_cmd, "_setup_gemini_home", lambda _td: gemini_home)
    monkeypatch.setattr(
        agent_cmd.subprocess, "run", lambda *_a, **_kw: SimpleNamespace(returncode=0)
    )

    result = CliRunner().invoke(
        root_cli.app,
        ["agent", "--agent-cli", "gemini", "--mcp-transport", "stdio", "--profile", "acme", "--keep-temp"],
    )
    assert result.exit_code == 0

    settings = json.loads((gemini_home / ".gemini" / "settings.json").read_text())
    assert settings["mcp"]["allowed"] == ["worai", "wordlift"]
    assert "worai" in settings["mcpServers"]
    assert "wordlift" in settings["mcpServers"]
    worai_entry = settings["mcpServers"]["worai"]
    assert "command" in worai_entry
    assert "worai.agent.mcp_server" in " ".join(worai_entry.get("args", []))
    assert "--profile" in worai_entry.get("args", [])
    assert "acme" in worai_entry.get("args", [])
    assert settings["contextFileName"] == "WORDLIFT.md"


def test_agent_gemini_settings_written_with_mcp_servers_http(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """settings.json uses HTTP URL entry when mcp-transport=http."""
    monkeypatch.setattr(agent_cmd, "shutil_which", lambda _name: "/usr/bin/fake")
    (tmp_path / "tmp").mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr(agent_cmd, "_create_session_dir", lambda: tmp_path / "tmp")
    gemini_home = tmp_path / "tmp" / "gemini-home"
    monkeypatch.setattr(agent_cmd, "_setup_gemini_home", lambda _td: gemini_home)

    class _RunningHttp:
        url = "http://127.0.0.1:45123/mcp"

        def stop(self) -> None:
            pass

    monkeypatch.setattr(agent_cmd, "start_http_server", lambda **_kw: _RunningHttp())
    monkeypatch.setattr(
        agent_cmd.subprocess, "run", lambda *_a, **_kw: SimpleNamespace(returncode=0)
    )

    result = CliRunner().invoke(
        root_cli.app, ["agent", "--agent-cli", "gemini", "--mcp-transport", "http", "--keep-temp"]
    )
    assert result.exit_code == 0

    settings = json.loads((gemini_home / ".gemini" / "settings.json").read_text())
    # Gemini forces stdio even when --mcp-transport http is passed
    worai_entry = settings["mcpServers"]["worai"]
    assert "command" in worai_entry


def test_agent_gemini_env_sets_gemini_cli_home(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """GEMINI_CLI_HOME is set to the isolated home dir in the subprocess env."""
    monkeypatch.setattr(agent_cmd, "shutil_which", lambda _name: "/usr/bin/fake")
    (tmp_path / "tmp").mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr(agent_cmd, "_create_session_dir", lambda: tmp_path / "tmp")
    gemini_home = tmp_path / "tmp" / "gemini-home"
    monkeypatch.setattr(agent_cmd, "_setup_gemini_home", lambda _td: gemini_home)
    captured_env: dict[str, str] = {}

    def _stub_run(command, env=None, **_kw):
        if command == ["gemini"]:
            captured_env.update(env or {})
        return SimpleNamespace(returncode=0)

    monkeypatch.setattr(agent_cmd.subprocess, "run", _stub_run)
    result = CliRunner().invoke(root_cli.app, ["agent", "--agent-cli", "gemini"])
    assert result.exit_code == 0
    assert captured_env.get("GEMINI_CLI_HOME") == str(gemini_home)


def test_build_skill_text_loads_repo_skill_templates() -> None:
    with tempfile.TemporaryDirectory(prefix="worai-skills-") as raw_dir:
        root = Path(raw_dir)
        skills_dir = root / "skills"
        (skills_dir / "worai-base").mkdir(parents=True)
        (skills_dir / "zzz-extra").mkdir(parents=True)
        (skills_dir / "worai-base" / "SKILL.md").write_text("base", encoding="utf-8")
        (skills_dir / "zzz-extra" / "SKILL.md").write_text("extra", encoding="utf-8")

        text = build_skill_text(project_root=root)
        assert text == "base\n\n---\n\nextra"


def test_agent_missing_binary_returns_usage_error(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(agent_cmd, "shutil_which", lambda _name: None)
    result = CliRunner().invoke(root_cli.app, ["agent", "--agent-cli", "codex", "--dry-run"])
    assert result.exit_code == 1
    assert result.exception is not None
    assert "Executable not found" in str(result.exception)


def test_mcp_transport_reads_line_delimited_json(monkeypatch: pytest.MonkeyPatch) -> None:
    stdin = SimpleNamespace(buffer=io.BytesIO(b'{"jsonrpc":"2.0","id":1,"method":"ping"}\n'))
    monkeypatch.setattr(mcp_server_mod.sys, "stdin", stdin)
    McpTransport._line_delimited_mode = None
    message = McpTransport.read_message()
    assert message is not None
    assert message["method"] == "ping"
    assert McpTransport._line_delimited_mode is True


def test_mcp_transport_writes_line_delimited_json_after_line_mode(monkeypatch: pytest.MonkeyPatch) -> None:
    stdin = SimpleNamespace(buffer=io.BytesIO(b'{"jsonrpc":"2.0","id":1,"method":"ping"}\n'))
    stdout_buffer = io.BytesIO()
    stdout = SimpleNamespace(buffer=stdout_buffer)
    monkeypatch.setattr(mcp_server_mod.sys, "stdin", stdin)
    monkeypatch.setattr(mcp_server_mod.sys, "stdout", stdout)
    McpTransport._line_delimited_mode = None

    _ = McpTransport.read_message()
    McpTransport.write_message({"jsonrpc": "2.0", "id": 1, "result": {}})
    payload = stdout_buffer.getvalue()
    assert payload.endswith(b"\n")
    assert b"Content-Length" not in payload


def test_mcp_server_help_and_exec_tools(monkeypatch: pytest.MonkeyPatch) -> None:
    server = WoraiMcpServer(SessionDefaults(config_path=None, profile=None))

    seen = {"argv": None}

    def _stub_invoke_sync(*, argv, config_path, profile, max_output_chars):
        del config_path, profile, max_output_chars
        seen["argv"] = argv
        return {"ok": True, "command": ["worai", *argv], "output": "ok", "exit_code": 0}

    monkeypatch.setattr(server._executor, "invoke_sync", _stub_invoke_sync)

    help_payload = server._tool_worai_help({"command_path": ["graph", "validate"]})
    assert help_payload["ok"] is True
    assert seen["argv"][-1] == "--help"

    exec_payload = server._tool_worai_cli_exec({"argv": ["graph", "validate", "a.ttl"]})
    assert exec_payload["ok"] is True
    assert exec_payload["command"][-3:] == ["graph", "validate", "a.ttl"]


def test_mcp_server_exposes_typed_tools() -> None:
    server = WoraiMcpServer(SessionDefaults(config_path=None, profile=None))
    tools = {tool["name"] for tool in server._tools()}
    assert "worai_version" in tools
    assert "worai_graph_audit" in tools
    assert "worai_graph_reset" in tools
    assert "worai_graph_validate" in tools
    assert "worai_graph_export" in tools
    assert "worai_graph_sync_run_start" in tools
    assert "worai_structured_data_validate_page" in tools
    assert "worai_structured_data_inventory_start" in tools
    assert "worai_web_pages_classify_types" in tools
    assert "worai_job_status" in tools
    assert "worai_job_output" in tools
    assert "worai_job_events" in tools
    assert "worai_job_cancel" in tools
    assert "worai_cli_exec" in tools


def test_mcp_server_typed_graph_audit_builds_expected_argv(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    server = WoraiMcpServer(SessionDefaults(config_path=None, profile=None))
    seen: dict = {}

    def _stub_invoke_sync(*, argv, config_path, profile, max_output_chars):
        del config_path, profile, max_output_chars
        seen["argv"] = argv
        return {"ok": True, "command": ["worai", *argv], "output": "ok", "exit_code": 0}

    monkeypatch.setattr(server._executor, "invoke_sync", _stub_invoke_sync)

    payload = server._call_tool(
        "worai_graph_audit",
        {
            "file": "./graph.ttl",
            "depth": 2,
            "list_isolated_iris": True,
            "show_url_violations": True,
            "rich_snippets_granularity": "entities",
            "workers": 4,
            "builtin_shapes": ["google-article.ttl"],
            "shapes": ["./custom.ttl"],
            "issue_level": "error",
            "format": "json",
        },
    )

    assert payload["ok"] is True
    argv = seen["argv"]
    assert argv[:3] == ["graph", "audit", "./graph.ttl"]
    assert "--depth" in argv and argv[argv.index("--depth") + 1] == "2"
    assert "--list-isolated-iris" in argv
    assert "--show-url-violations" in argv
    assert "--rich-snippets-granularity" in argv
    assert argv[argv.index("--rich-snippets-granularity") + 1] == "entities"
    assert "--workers" in argv and argv[argv.index("--workers") + 1] == "4"
    assert "--builtin-shape" in argv and argv[argv.index("--builtin-shape") + 1] == "google-article.ttl"
    assert "--shape" in argv and argv[argv.index("--shape") + 1] == "./custom.ttl"
    assert "--issue-level" in argv and argv[argv.index("--issue-level") + 1] == "error"
    assert argv[-2:] == ["--format", "json"]


def test_mcp_server_typed_graph_audit_minimal_argv(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    server = WoraiMcpServer(SessionDefaults(config_path=None, profile=None))
    seen: dict = {}

    def _stub_invoke_sync(*, argv, config_path, profile, max_output_chars):
        del config_path, profile, max_output_chars
        seen["argv"] = argv
        return {"ok": True, "command": ["worai", *argv], "output": "ok", "exit_code": 0}

    monkeypatch.setattr(server._executor, "invoke_sync", _stub_invoke_sync)

    payload = server._call_tool("worai_graph_audit", {"file": "graph.ttl"})

    assert payload["ok"] is True
    assert seen["argv"] == ["graph", "audit", "graph.ttl"]


def test_mcp_server_typed_graph_reset_builds_expected_argv(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    server = WoraiMcpServer(SessionDefaults(config_path=None, profile=None))
    seen: dict = {}

    def _stub_invoke_sync(*, argv, config_path, profile, max_output_chars):
        del config_path, profile, max_output_chars
        seen["argv"] = argv
        return {"ok": True, "command": ["worai", *argv], "output": "ok", "exit_code": 0}

    monkeypatch.setattr(server._executor, "invoke_sync", _stub_invoke_sync)

    payload = server._call_tool(
        "worai_graph_reset",
        {"keep_country": True, "keep_language": True, "keep_url": True},
    )

    assert payload["ok"] is True
    argv = seen["argv"]
    assert argv[:3] == ["graph", "reset", "--yes"]
    assert "--keep-country" in argv
    assert "--keep-language" in argv
    assert "--keep-url" in argv


def test_mcp_server_typed_graph_reset_minimal_argv(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    server = WoraiMcpServer(SessionDefaults(config_path=None, profile=None))
    seen: dict = {}

    def _stub_invoke_sync(*, argv, config_path, profile, max_output_chars):
        del config_path, profile, max_output_chars
        seen["argv"] = argv
        return {"ok": True, "command": ["worai", *argv], "output": "ok", "exit_code": 0}

    monkeypatch.setattr(server._executor, "invoke_sync", _stub_invoke_sync)

    payload = server._call_tool("worai_graph_reset", {})

    assert payload["ok"] is True
    assert seen["argv"] == ["graph", "reset", "--yes"]


def test_mcp_server_typed_graph_validate_builds_expected_argv(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    server = WoraiMcpServer(SessionDefaults(config_path=None, profile=None))
    seen = {"argv": None}

    def _stub_invoke_sync(*, argv, config_path, profile, max_output_chars):
        del config_path, profile, max_output_chars
        seen["argv"] = argv
        return {"ok": True, "command": ["worai", *argv], "output": "ok", "exit_code": 0}

    monkeypatch.setattr(server._executor, "invoke_sync", _stub_invoke_sync)
    payload = server._call_tool(
        "worai_graph_validate",
        {"inputs": ["./a.ttl"], "builtin_shapes": ["google-required"], "format": "json"},
    )
    assert payload["ok"] is True
    assert seen["argv"][:4] == ["graph", "validate", "./a.ttl", "--builtin-shape"]
    assert seen["argv"][-2:] == ["--format", "json"]


def test_mcp_server_typed_web_pages_classify_types_builds_expected_argv(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    server = WoraiMcpServer(SessionDefaults(config_path=None, profile=None))
    seen: dict[str, object] = {}

    def _stub_invoke_sync(*, argv, config_path, profile, max_output_chars):
        del config_path, profile, max_output_chars
        seen["argv"] = argv
        return {"ok": True, "command": ["worai", *argv], "output": "ok", "exit_code": 0}

    monkeypatch.setattr(server._executor, "invoke_sync", _stub_invoke_sync)
    payload = server._call_tool(
        "worai_web_pages_classify_types",
        {
            "source": "https://example.com/sitemap.xml",
            "output_csv": "./types.csv",
            "ingest_source": "sitemap",
            "ingest_loader": "playwright",
            "agent_cli": "codex",
            "agent_timeout_sec": 90,
            "max_markdown_chars": 9000,
            "no_resume": True,
        },
    )

    assert payload["ok"] is True
    argv = seen["argv"]
    assert argv[:4] == ["web-pages", "classify-types", "https://example.com/sitemap.xml", "--yes"]
    assert "--output" in argv and argv[argv.index("--output") + 1] == "./types.csv"
    assert "--ingest-source" in argv and argv[argv.index("--ingest-source") + 1] == "sitemap"
    assert "--ingest-loader" in argv and argv[argv.index("--ingest-loader") + 1] == "playwright"
    assert "--agent-cli" in argv and argv[argv.index("--agent-cli") + 1] == "codex"
    assert "--agent-timeout-sec" in argv and argv[argv.index("--agent-timeout-sec") + 1] == "90.0"
    assert "--max-markdown-chars" in argv and argv[argv.index("--max-markdown-chars") + 1] == "9000"
    assert "--no-resume" in argv


def test_skill_describes_mcp_tools() -> None:
    text = build_skill_text()
    assert "worai_graph_validate" in text
    assert "worai_graph_export" in text
    assert "worai_graph_sync_run_start" in text
    assert "worai_structured_data_validate_page" in text
    assert "worai_structured_data_inventory_start" in text
    assert "worai_web_pages_classify_types" in text
    assert "worai_job_status" in text
    assert "worai_job_output" in text
    assert "worai_job_events" in text
    assert "worai_job_cancel" in text
    assert "worai_cli_exec" in text


def test_mcp_server_typed_structured_data_inventory_start_builds_expected_argv(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    server = WoraiMcpServer(SessionDefaults(config_path=None, profile=None))
    seen = {"command": None}

    def _stub_build_subprocess_command(*, argv, config_path, profile):
        seen["command"] = argv
        return (["python", "-m", "worai.cli", *argv], "/tmp/worai.toml", profile or "default")

    def _stub_start(*, command, effective_config_path, effective_profile):
        return {
            "job_id": "job-1",
            "state": "queued",
            "command": command,
            "effective_config_path": effective_config_path,
            "effective_profile": effective_profile,
        }

    monkeypatch.setattr(server._executor, "build_subprocess_command", _stub_build_subprocess_command)
    monkeypatch.setattr(server._jobs, "start", _stub_start)
    payload = server._call_tool(
        "worai_structured_data_inventory_start",
        {
            "source": "https://example.com/sitemap.xml",
            "output": "./inventory.csv",
            "ingest_source": "sitemap",
            "ingest_loader": "playwright",
            "ingest_passthrough_when_html": False,
            "concurrency": "4",
        },
    )
    assert payload["state"] == "queued"
    assert seen["command"][:3] == ["structured-data", "inventory", "https://example.com/sitemap.xml"]
    assert "--output" in seen["command"]
    assert "--ingest-source" in seen["command"]
    assert "--ingest-loader" in seen["command"]
    assert "--no-ingest-passthrough-when-html" in seen["command"]


def test_mcp_server_blocks_recursive_agent_mcp() -> None:
    server = WoraiMcpServer(SessionDefaults(config_path=None, profile=None))
    with pytest.raises(ValueError, match="blocked"):
        server._tool_worai_cli_exec({"argv": ["agent", "mcp", "serve"]})


def test_job_events_and_progress_from_inventory_event_line() -> None:
    server = WoraiMcpServer(SessionDefaults(config_path=None, profile=None))
    payload = server._jobs.start(
        command=["/bin/sh", "-lc", "printf 'WORAI_MCP_EVENT {\"event\":\"inventory.progress.updated\",\"meta\":{\"completed\":2,\"total\":5}}\\n'"],
        effective_config_path="/tmp/worai.toml",
        effective_profile="default",
    )
    job_id = payload["job_id"]

    for _ in range(100):
        status = server._jobs.status(job_id)
        if status["state"] in {"done", "failed"}:
            break
        time.sleep(0.01)

    status = server._jobs.status(job_id)
    assert status["state"] == "done"
    assert status["progress"]["completed"] == 2
    assert status["progress"]["total"] == 5
    assert status["progress"]["percent"] == 40.0
    assert status["event_cursor"] >= 2

    events = server._jobs.events(job_id, cursor=0, limit=10)
    assert events["events"]
    assert any(event["event"] == "inventory.progress.updated" for event in events["events"])


def test_job_status_progress_from_graph_sync_event_lines() -> None:
    server = WoraiMcpServer(SessionDefaults(config_path=None, profile=None))
    payload = server._jobs.start(
        command=[
            "/bin/sh",
            "-lc",
            (
                "printf 'WORAI_MCP_EVENT "
                "{\"event\":\"graph.progress\",\"meta\":{\"kind\":\"graph\",\"profile\":\"default\","
                "\"url\":\"https://example.com/a\",\"graph\":{\"entities\":2,\"type_assertions\":3,"
                "\"property_assertions\":4},\"validation\":null}}\\n'; "
                "printf 'WORAI_MCP_EVENT "
                "{\"event\":\"graph.kpi\",\"meta\":{\"profile\":\"default\",\"run_id\":\"r1\","
                "\"totals\":{\"total_entities\":5,\"type_assertions_total\":6,"
                "\"property_assertions_total\":7},\"validation\":null}}\\n'"
            ),
        ],
        effective_config_path="/tmp/worai.toml",
        effective_profile="default",
    )
    job_id = payload["job_id"]

    for _ in range(100):
        status = server._jobs.status(job_id)
        if status["state"] in {"done", "failed"}:
            break
        time.sleep(0.01)

    status = server._jobs.status(job_id)
    assert status["state"] == "done"
    assert status["progress"]["phase"] == "completed"
    assert status["progress"]["profile"] == "default"
    assert status["progress"]["run_id"] == "r1"
    assert status["progress"]["total_entities"] == 5
    assert status["progress"]["type_assertions_total"] == 6
    assert status["progress"]["property_assertions_total"] == 7
    assert status["progress"]["last_event"] == "job.finished"
    assert status["progress"]["last_progress_event"] == "graph.kpi"

    events = server._jobs.events(job_id, cursor=0, limit=10)
    names = [event["event"] for event in events["events"]]
    assert "graph.progress" in names
    assert "graph.kpi" in names


def test_mcp_jsonrpc_inventory_async_flow_exposes_events_and_output(monkeypatch: pytest.MonkeyPatch) -> None:
    server = WoraiMcpServer(SessionDefaults(config_path=None, profile=None))

    def _stub_build_subprocess_command(*, argv, config_path, profile):
        del argv, config_path, profile
        cmd = [
            "/bin/sh",
            "-lc",
            "printf 'WORAI_MCP_EVENT {\"event\":\"inventory.progress.started\",\"meta\":{\"total\":2}}\\n'; "
            "printf 'WORAI_MCP_EVENT {\"event\":\"inventory.progress.updated\",\"meta\":{\"completed\":1,\"total\":2}}\\n'; "
            "printf '{\"total\":2,\"output\":\"/tmp/out.csv\"}\\n'",
        ]
        return cmd, "/tmp/worai.toml", "default"

    monkeypatch.setattr(server._executor, "build_subprocess_command", _stub_build_subprocess_command)

    start_resp = server.handle_message(
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {
                "name": "worai_structured_data_inventory_start",
                "arguments": {"source": "https://example.com/sitemap_index.xml", "ingest_loader": "playwright"},
            },
        }
    )
    assert start_resp is not None
    job_id = start_resp["result"]["structuredContent"]["job_id"]

    for _ in range(100):
        status_resp = server.handle_message(
            {
                "jsonrpc": "2.0",
                "id": 2,
                "method": "tools/call",
                "params": {"name": "worai_job_status", "arguments": {"job_id": job_id}},
            }
        )
        assert status_resp is not None
        state = status_resp["result"]["structuredContent"]["state"]
        if state in {"done", "failed"}:
            break
        time.sleep(0.01)

    status_payload = status_resp["result"]["structuredContent"]
    assert status_payload["state"] == "done"
    assert status_payload["progress"]["completed"] == 1
    assert status_payload["progress"]["total"] == 2
    assert status_payload["event_cursor"] >= 2

    events_resp = server.handle_message(
        {
            "jsonrpc": "2.0",
            "id": 3,
            "method": "tools/call",
            "params": {"name": "worai_job_events", "arguments": {"job_id": job_id, "cursor": 0, "limit": 10}},
        }
    )
    assert events_resp is not None
    events_payload = events_resp["result"]["structuredContent"]
    names = [event["event"] for event in events_payload["events"]]
    assert "inventory.progress.started" in names
    assert "inventory.progress.updated" in names

    output_resp = server.handle_message(
        {
            "jsonrpc": "2.0",
            "id": 4,
            "method": "tools/call",
            "params": {"name": "worai_job_output", "arguments": {"job_id": job_id}},
        }
    )
    assert output_resp is not None
    output_payload = output_resp["result"]["structuredContent"]
    assert "\"total\":2" in output_payload["text"]


def test_mcp_jsonrpc_graph_sync_async_flow_exposes_progress(monkeypatch: pytest.MonkeyPatch) -> None:
    server = WoraiMcpServer(SessionDefaults(config_path=None, profile=None))

    def _stub_build_subprocess_command(*, argv, config_path, profile):
        del argv, config_path, profile
        cmd = [
            "/bin/sh",
            "-lc",
            "printf 'WORAI_MCP_EVENT {\"event\":\"graph.progress\",\"meta\":{\"kind\":\"graph\",\"profile\":\"default\",\"url\":\"https://example.com/a\",\"graph\":{\"entities\":1,\"type_assertions\":2,\"property_assertions\":3},\"validation\":null}}\\n'; "
            "printf 'WORAI_MCP_EVENT {\"event\":\"graph.kpi\",\"meta\":{\"profile\":\"default\",\"run_id\":\"2026-03-12T18:00:00Z\",\"totals\":{\"total_entities\":1,\"type_assertions_total\":2,\"property_assertions_total\":3},\"validation\":null}}\\n'",
        ]
        return cmd, "/tmp/worai.toml", "default"

    monkeypatch.setattr(server._executor, "build_subprocess_command", _stub_build_subprocess_command)

    start_resp = server.handle_message(
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {
                "name": "worai_graph_sync_run_start",
                "arguments": {},
            },
        }
    )
    assert start_resp is not None
    job_id = start_resp["result"]["structuredContent"]["job_id"]

    for _ in range(100):
        status_resp = server.handle_message(
            {
                "jsonrpc": "2.0",
                "id": 2,
                "method": "tools/call",
                "params": {"name": "worai_job_status", "arguments": {"job_id": job_id}},
            }
        )
        assert status_resp is not None
        state = status_resp["result"]["structuredContent"]["state"]
        if state in {"done", "failed"}:
            break
        time.sleep(0.01)

    status_payload = status_resp["result"]["structuredContent"]
    assert status_payload["state"] == "done"
    assert status_payload["progress"]["phase"] == "completed"
    assert status_payload["progress"]["profile"] == "default"
    assert status_payload["progress"]["run_id"] == "2026-03-12T18:00:00Z"
    assert status_payload["progress"]["total_entities"] == 1
    assert status_payload["progress"]["type_assertions_total"] == 2
    assert status_payload["progress"]["property_assertions_total"] == 3
    assert status_payload["event_cursor"] >= 2
