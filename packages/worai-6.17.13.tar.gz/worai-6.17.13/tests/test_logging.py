from __future__ import annotations

import logging

from worai.logging import setup_logging


def test_warning_level_does_not_filter_info_when_dependency_logger_is_info(capsys) -> None:
    setup_logging(level="warning", fmt="text")
    noisy_logger = logging.getLogger("wordlift_sdk.noisy")
    noisy_logger.setLevel(logging.INFO)

    noisy_logger.info("should be shown")
    shown_info = capsys.readouterr()
    assert "INFO wordlift_sdk.noisy: should be shown" in shown_info.err

    noisy_logger.warning("should be shown")
    shown = capsys.readouterr()
    assert "WARNING wordlift_sdk.noisy: should be shown" in shown.err


def test_quiet_forces_warning_level(capsys) -> None:
    setup_logging(level="debug", fmt="text", quiet=True)
    logger = logging.getLogger("worai.quiet")

    logger.info("info hidden")
    hidden = capsys.readouterr()
    assert "info hidden" not in hidden.err

    logger.warning("warning shown")
    shown = capsys.readouterr()
    assert "WARNING worai.quiet: warning shown" in shown.err


def test_setup_logging_suppresses_graphql_transport_info_by_default(capsys) -> None:
    setup_logging(level="debug", fmt="text")
    gql_logger = logging.getLogger("gql.transport.aiohttp")

    gql_logger.info("huge graphql payload")
    hidden = capsys.readouterr()
    assert "huge graphql payload" not in hidden.err

    gql_logger.warning("graphql warning shown")
    shown = capsys.readouterr()
    assert "graphql warning shown" in shown.err


def test_setup_logging_allows_graphql_transport_info_with_explicit_debug_env(
    capsys,
    monkeypatch,
) -> None:
    monkeypatch.setenv("WORAI_DEBUG_GRAPHQL_PAYLOADS", "1")
    setup_logging(level="debug", fmt="text")
    gql_logger = logging.getLogger("gql.transport.aiohttp")

    gql_logger.info("graphql payload debug enabled")
    shown = capsys.readouterr()
    assert "graphql payload debug enabled" in shown.err
