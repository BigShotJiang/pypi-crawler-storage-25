# worai MCP Skill

Use MCP tools directly. Prefer typed tools over fallback command execution.

## Tools
- `worai_version`: show installed worai version.
- `worai_help`: show help for root or subcommand path.
- `worai_graph_validate`: validate RDF files/URLs with SHACL.
- `worai_graph_export`: export graph data (optional validation).
- `worai_graph_sync_run_start`: start graph sync as an async job.
- `worai_structured_data_validate_page`: validate JSON-LD extracted from a webpage.
- `worai_structured_data_inventory_start`: start structured-data inventory as an async job.
- `worai_web_pages_classify_types`: classify pages into schema.org types.
- `worai_job_status`: check async job status.
- `worai_job_output`: read incremental async job logs/output.
- `worai_job_events`: read structured async progress events (cursor-based).
- `worai_job_cancel`: cancel async jobs.
- `worai_cli_exec`: fallback executor for commands not covered above.

## Configuration resolution
- Per-call `config_path` / `profile` overrides are highest precedence.
- Otherwise session defaults from `worai agent` are used.
- If neither is set, worai uses normal env/discovery (`WORAI_CONFIG`, nearest `worai.toml`, etc.).

## Usage policy
1. Prefer typed tools first.
2. Use `worai_help` before unfamiliar operations.
3. Use `worai_cli_exec` only when no typed tool matches.
4. For `*_start` tools, poll with `worai_job_status` and `worai_job_events`; use `worai_job_output` for log details.
5. Include explicit `profile` for profile-specific tasks.
