"""SEO check utilities."""
