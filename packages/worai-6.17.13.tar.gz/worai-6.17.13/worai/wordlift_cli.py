"""wordlift-cli entry point — thin wrapper for `worai agent --agent-cli gemini`."""

from __future__ import annotations

import sys


def run() -> None:
    """Launch `worai agent --agent-cli gemini -- <extra-args>`."""
    extra = sys.argv[1:]
    sys.argv = [sys.argv[0], "agent", "--agent-cli", "gemini", "--", *extra]
    from worai.cli import run as _run

    _run()
