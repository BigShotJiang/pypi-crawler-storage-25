# win12-i18n

Windows 12 网页版 i18n 管理 CLI 工具。

用于统一管理 `.properties` 格式的多语言资源文件，支持解析、校验、同步等操作。

## 安装

```bash
# 使用 uv（推荐）
uv pip install win12-i18n

# 或使用 pip
pip install win12-i18n
```

## 使用

```bash
# 查看帮助
win12-i18n --help

# 初始化 i18n 目录
win12-i18n init

# 添加翻译键值
win12-i18n add setting.psnl.color "深色模式" -l zh

# 检查各语言文件一致性
win12-i18n check

# 同步键值到所有语言文件
win12-i18n sync -b zh

# 查看某个键在各语言中的值
win12-i18n show setting.psnl.color
```

## 开发

```bash
# 克隆仓库
git clone https://github.com/win12-online/win12-i18n.git
cd win12-i18n

# 安装开发依赖
uv venv
uv pip install -e ".[dev]"

# 运行测试
uv run pytest
```

## 依赖

- Python >= 3.10
- Click >= 8.0
