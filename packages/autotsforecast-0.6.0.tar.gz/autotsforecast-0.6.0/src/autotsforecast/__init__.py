"""AutoTSForecast: Automated Multivariate Time Series Forecasting Toolkit

A comprehensive package for multivariate time series forecasting with:
- Automatic model selection and comparison
- Backtesting and cross-validation
- Hierarchical forecast reconciliation
- Interpretability and driver analysis
- Prediction intervals and uncertainty quantification
- Calendar feature engineering
- Interactive visualization
- Parallel processing for speed
"""

try:
    from importlib.metadata import version as _pkg_version, PackageNotFoundError as _PNF
    __version__ = _pkg_version("autotsforecast")
except _PNF:
    __version__ = "0.0.0"

# Core models
from autotsforecast.models.base import BaseForecaster, VARForecaster, LinearForecaster, MovingAverageForecaster
from autotsforecast.models.selection import ModelSelector
from autotsforecast.models.external import (
    Chronos2Forecaster,
    RandomForestForecaster,
    XGBoostForecaster,
    ProphetForecaster,
    ARIMAForecaster,
    ETSForecaster,
    LSTMForecaster,
    # v0.6.0 new models
    LightGBMForecaster,
    CatBoostForecaster,
    ElasticNetForecaster,
    ThetaForecaster,
    CrostonForecaster,
    NBEATSForecaster,
    NHiTSForecaster,
    TFTForecaster,
)

# Core components
from autotsforecast.backtesting.validator import BacktestValidator
from autotsforecast.hierarchical.reconciliation import HierarchicalReconciler
from autotsforecast.interpretability.drivers import DriverAnalyzer
from autotsforecast.forecaster import AutoForecaster, get_default_candidate_models, PRESETS, get_preset_models, quick_forecast

# New features: Calendar & Feature Engineering
from autotsforecast.features.calendar import CalendarFeatures, add_calendar_features
from autotsforecast.features.engine import FeatureEngine

# New features: Prediction Intervals
from autotsforecast.uncertainty.intervals import PredictionIntervals, ConformalPredictor

# New features: Visualization & Progress
from autotsforecast.visualization.plots import (
    plot_forecast,
    plot_forecast_interactive,
    plot_model_comparison,
    plot_feature_importance,
    plot_residuals,
    plot_components,
    ForecastPlotter
)
from autotsforecast.visualization.progress import ProgressTracker, progress_bar

# New features: Parallel Processing
from autotsforecast.utils.parallel import ParallelForecaster, parallel_map, batch_forecast

# v0.6.0: Dataset profiler
from autotsforecast.utils.profiler import DatasetProfiler, ProfileResult

# ── Agentic AI extensions (v0.5.0) ──────────────────────────────────────────

# Anomaly detection
try:
    from autotsforecast.anomaly.detector import AnomalyDetector
except Exception:
    AnomalyDetector = None  # type: ignore[assignment,misc]

# Natural-language insight engine
try:
    from autotsforecast.nlp.insights import InsightEngine
except Exception:
    InsightEngine = None  # type: ignore[assignment,misc]

# Local model registry
try:
    from autotsforecast.registry.store import ModelRegistry
except Exception:
    ModelRegistry = None  # type: ignore[assignment,misc]

# OpenAI / Anthropic function-calling schemas
try:
    from autotsforecast.integrations.openai_schemas import (
        get_openai_tools,
        get_anthropic_tools,
        handle_tool_call,
    )
except Exception:
    get_openai_tools = None  # type: ignore[assignment]
    get_anthropic_tools = None  # type: ignore[assignment]
    handle_tool_call = None  # type: ignore[assignment]

# LangChain tools
try:
    from autotsforecast.integrations.langchain_tools import get_autotsforecast_tools
except Exception:
    get_autotsforecast_tools = None  # type: ignore[assignment]

__all__ = [
    # Core Models
    "BaseForecaster",
    "VARForecaster",
    "LinearForecaster",
    "MovingAverageForecaster",
    "RandomForestForecaster",
    "XGBoostForecaster",
    "ProphetForecaster",
    "ARIMAForecaster",
    "ETSForecaster",
    "LSTMForecaster",
    "Chronos2Forecaster",
    # v0.6.0 new models
    "LightGBMForecaster",
    "CatBoostForecaster",
    "ElasticNetForecaster",
    "ThetaForecaster",
    "CrostonForecaster",
    "NBEATSForecaster",
    "NHiTSForecaster",
    "TFTForecaster",
    # Core Components
    "ModelSelector",
    "BacktestValidator",
    "HierarchicalReconciler",
    "AutoForecaster",
    "get_default_candidate_models",
    "PRESETS",
    "get_preset_models",
    "DriverAnalyzer",
    # Feature Engineering
    "CalendarFeatures",
    "add_calendar_features",
    "FeatureEngine",
    # Uncertainty Quantification
    "PredictionIntervals",
    "ConformalPredictor",
    # Visualization
    "plot_forecast",
    "plot_forecast_interactive",
    "plot_model_comparison",
    "plot_feature_importance",
    "plot_residuals",
    "plot_components",
    "ForecastPlotter",
    "ProgressTracker",
    "progress_bar",
    # Parallel Processing
    "ParallelForecaster",
    "parallel_map",
    "batch_forecast",
    # v0.6.0: Dataset profiling
    "DatasetProfiler",
    "ProfileResult",
    # Agentic AI (v0.5.0)
    "AnomalyDetector",
    "InsightEngine",
    "ModelRegistry",
    "get_openai_tools",
    "get_anthropic_tools",
    "handle_tool_call",
    "get_autotsforecast_tools",
]