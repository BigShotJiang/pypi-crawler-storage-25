"""Model registry for AutoTSForecast."""
