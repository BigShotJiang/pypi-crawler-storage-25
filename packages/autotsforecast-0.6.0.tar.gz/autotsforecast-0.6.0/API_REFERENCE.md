# API Reference

Complete parameter documentation for all models and classes in AutoTSForecast v0.6.0.

## Table of Contents
- [AutoForecaster](#autoforecaster)
  - [Per-Series Covariates](#per-series-covariates)
  - [Presets and Budget Search](#presets-and-budget-search)
  - [get_report()](#get_report)
  - [profile_data()](#profile_data)
- [Backtesting (Standalone Feature)](#backtesting)
- [Forecasting Models](#forecasting-models)
  - [New in v0.6.0](#new-in-v060)
- [Hierarchical Reconciliation](#hierarchical-reconciliation)
- [Interpretability Tools](#interpretability-tools)
- [Preprocessing](#preprocessing)
- [Calendar Features](#calendar-features)
- [Prediction Intervals](#prediction-intervals)
- [Visualization](#visualization)
- [Parallel Processing](#parallel-processing)

---

## AutoForecaster

Automatic model selection with cross-validation.

### Parameters

| Parameter | Type | Default | Allowed Values | Description |
|-----------|------|---------|----------------|-------------|
| `candidate_models` | list | `None` | List of forecaster objects | Models to evaluate. Required unless `preset` is set |
| `metric` | str | `'rmse'` | `'rmse'`, `'mae'`, `'mape'`, `'mse'` | Metric for model selection |
| `n_splits` | int | `5` | 2-10 | Number of cross-validation folds |
| `test_size` | int | `20` | 1 to dataset_size/2 | Size of each validation window |
| `window_type` | str | `'expanding'` | `'expanding'`, `'rolling'` | CV window type |
| `verbose` | bool | `True` | `True`, `False` | Print progress messages |
| `per_series_models` | bool | `False` | `True`, `False` | Select different model per series |
| `n_jobs` | int | `1` | 1 to CPU_count, -1 | Parallel jobs for candidate search and per-series fitting |
| `preset` | str | `None` | `'fast'`, `'balanced'`, `'accuracy'`, `'zero_shot'`, `'intermittent'`, `'hierarchical'` | Auto-populate candidates from a named preset |
| `horizon` | int | `None` | positive int | Required when `preset` is set |
| `time_limit` | float | `None` | positive float | Stop model search after this many seconds |
| `max_models` | int | `None` | positive int | Evaluate at most this many candidates |
| `backtest_mode` | str | `'full'` | `'full'`, `'fast'`, `'last_fold'` | `'full'` = n_splits folds; `'fast'` = min(2, n_splits); `'last_fold'` = 1 fold |

### Methods

```python
fit(y: pd.DataFrame, X: Optional[Union[pd.DataFrame, Dict[str, pd.DataFrame]]] = None)
```
- `y`: Target time series (DatetimeIndex, multiple columns)
- `X`: Optional covariates. Can be:
  - `pd.DataFrame`: Same covariates used for all series
  - `Dict[str, pd.DataFrame]`: **Per-series covariates** — different features for each series (keys = series names, values = covariate DataFrames)

```python
forecast(X: Optional[Union[pd.DataFrame, Dict[str, pd.DataFrame]]] = None) -> pd.DataFrame
```
- `X`: Future covariates for forecast period. Format must match training:
  - If trained with `pd.DataFrame`, provide `pd.DataFrame`
  - If trained with `Dict[str, pd.DataFrame]`, provide `Dict[str, pd.DataFrame]`
- Returns: pd.DataFrame with point forecasts

---

### Per-Series Covariates

**Use Case:** When different time series are driven by different external factors.

Instead of forcing all series to use the same features, you can specify different covariates for each series:

```python
# Define different covariates for each series
X_train_dict = {
    'product_a': pd.DataFrame({  # Weather-sensitive product
        'temperature': [...],
        'advertising_spend': [...]
    }, index=dates),
    'product_b': pd.DataFrame({  # Price-sensitive product
        'competitor_price': [...],
        'promotion_active': [...]
    }, index=dates)
}

X_test_dict = {
    'product_a': X_product_a_test,
    'product_b': X_product_b_test
}

# Fit with per-series covariates
auto = AutoForecaster(
    candidate_models=[...],
    per_series_models=True,
    metric='rmse'
)
auto.fit(y_train, X=X_train_dict)
forecasts = auto.forecast(X=X_test_dict)
```

---

### Presets and Budget Search

**New in v0.6.0** — Use a preset to skip building candidate lists manually.

| Preset | Models | When to use |
|--------|--------|-------------|
| `fast` | Linear, MA, ElasticNet, LightGBM | < 60 s budget |
| `balanced` | + RF, XGBoost, ARIMA, ETS, Theta | Default recommendation |
| `accuracy` | All ML + NBEATS, NHiTS, TFT | Overnight runs |
| `zero_shot` | Chronos-2 only | Cold-start / no training data |
| `intermittent` | Croston, ElasticNet, LightGBM | Sparse demand |
| `hierarchical` | VAR, RF, XGBoost, LightGBM | Multi-level hierarchies |

```python
# Preset usage
auto = AutoForecaster(preset="balanced", horizon=14)

# Budget-aware search
auto = AutoForecaster(
    preset="accuracy",
    horizon=30,
    n_jobs=-1,          # parallel candidates
    time_limit=120,     # stop after 2 minutes
    max_models=8,       # evaluate at most 8 models
    backtest_mode="fast",  # 2 folds instead of 5
)
```

---

### get_report()

```python
auto.get_report() -> dict
```

Returns a structured model-selection report after `fit()`.

**Keys:**

| Key | Type | Description |
|-----|------|-------------|
| `version` | str | Package version |
| `preset` | str or None | Preset used |
| `best_model` | str | Name of selected model |
| `metric` | str | Selection metric |
| `n_candidates_evaluated` | int | Number of models evaluated |
| `backtest_config` | dict | n_splits, mode, test_size, etc. |
| `model_ranking` | list | Ranked list with scores for all metrics |
| `selection_rationale` | str | Human-readable explanation |
| `forecast_horizon` | int | Horizon from winning model |

```python
# Pretty-print the report
auto.print_report()
```

---

### profile_data()

```python
AutoForecaster.profile_data(y: pd.DataFrame) -> ProfileResult
```

Static method. Profiles your dataset and recommends a preset before you call `fit()`.

**ProfileResult attributes:**

| Attribute | Type | Description |
|-----------|------|-------------|
| `n_series` | int | Number of series |
| `n_obs` | int | Number of observations |
| `freq` | str | Detected frequency |
| `missing_rate` | float | Fraction of NaN values |
| `zero_rate` | float | Fraction of zero values |
| `mean_lag1_autocorr` | float | Average lag-1 autocorrelation |
| `seasonality_detected` | bool | Whether seasonal pattern was found |
| `is_intermittent` | bool | Whether zero_rate > 30% |
| `is_short` | bool | Whether n_obs < 50 |
| `recommended_preset` | str | Suggested preset |
| `recommended_models` | list | Suggested model names |
| `notes` | list | Human-readable rationale |

```python
result = AutoForecaster.profile_data(y_train)
result.print_summary()
# → recommended_preset: 'balanced'

auto = AutoForecaster(preset=result.recommended_preset, horizon=14)
```

---

## Backtesting (Standalone Feature)

### BacktestValidator

**Standalone time series cross-validation tool that works with ANY forecasting model.**

BacktestValidator is an independent feature that can be used separately from AutoForecaster. While AutoForecaster uses backtesting internally for model selection, BacktestValidator allows you to:
- Validate any single model's performance
- Get detailed fold-by-fold metrics and statistics
- Visualize backtesting results automatically
- Extract predictions and actuals for custom analysis
- Compare models manually with full transparency

**Key Advantages:**
- ✅ Works independently with ANY forecaster
- ✅ Detailed fold-level insights (not just averages)
- ✅ Automated visualization of performance
- ✅ Access to raw predictions for custom analysis
- ✅ Comprehensive metrics: RMSE, MAE, MAPE, SMAPE, R²

**Parameters:**

| Parameter | Type | Default | Allowed Values | Description |
|-----------|------|---------|----------------|-------------|
| `model` | BaseForecaster | required | Any forecaster | Model to validate |
| `n_splits` | int | `5` | 2-10 | Number of CV splits |
| `test_size` | int | `20` | 1 to dataset_size/2 | Validation window size |
| `window_type` | str | `'expanding'` | `'expanding'`, `'rolling'` | CV window type (expanding recommended) |

**Methods:**

```python
run(y: pd.DataFrame, X: pd.DataFrame = None) -> dict
```
Run backtesting and return overall metrics.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `y` | pd.DataFrame | required | Target time series |
| `X` | pd.DataFrame | `None` | Optional covariates |
| **Returns** | dict | - | Overall metrics: `{'rmse': float, 'mae': float, 'mape': float, 'smape': float, 'r2': float}` |

```python
get_fold_results() -> pd.DataFrame
```
Get detailed results for each fold (train/test sizes, metrics per fold).

```python
get_summary() -> pd.DataFrame
```
Get summary statistics (mean, std, min, max) across all folds for each metric.

```python
plot_results(figsize: Tuple[int, int] = (15, 10))
```
Automatically visualize backtesting results:
- Metrics by fold (line charts)
- R² by fold
- Actual vs Predicted for last fold

```python
get_predictions() -> Tuple[pd.DataFrame, pd.DataFrame]
```
Extract all actuals and predictions from all folds for custom analysis.
- **Returns**: `(actuals_df, predictions_df)` - concatenated DataFrames from all folds

**Complete Example:**
```python
from autotsforecast.backtesting import BacktestValidator
from autotsforecast import RandomForestForecaster

# Create any forecasting model
model = RandomForestForecaster(horizon=14, n_lags=7)

# Create validator
validator = BacktestValidator(
    model=model,
    n_splits=5,           # 5 CV folds
    test_size=14,         # 14-day test windows
    window_type='expanding'  # Expanding window (recommended)
)

# Run backtesting
overall_metrics = validator.run(y_train, X_train)
print(f"Overall RMSE: {overall_metrics['rmse']:.2f}")
print(f"Overall MAPE: {overall_metrics['mape']:.2f}%")

# Get fold-by-fold results
fold_results = validator.get_fold_results()
print(fold_results[['fold', 'train_size', 'test_size', 'rmse', 'mape']])

# Get summary statistics
summary = validator.get_summary()
print(summary)  # Shows mean, std, min, max for each metric

# Visualize results
validator.plot_results()

# Extract predictions for custom analysis
actuals, predictions = validator.get_predictions()
errors = actuals - predictions
print(f"Mean error: {errors.mean()}")
```

**Use Cases:**
1. **Validate a single model**: Understand performance across different time periods
2. **Manual model comparison**: Compare multiple models with full fold-level transparency
3. **Performance analysis**: Identify periods where model performs well/poorly
4. **Custom metrics**: Extract predictions and compute your own metrics
5. **Reporting**: Generate detailed performance reports with visualizations

---

## Forecasting Models

### New in v0.6.0

Eight new models were added in v0.6.0. See full parameter docs below.

| Model | Type | Covariates | Extra install |
|-------|------|-----------|---------------|
| `LightGBMForecaster` | ML (gradient boosting) | ✅ | `pip install "autotsforecast[lightgbm]"` |
| `CatBoostForecaster` | ML (gradient boosting) | ✅ | `pip install "autotsforecast[catboost]"` |
| `ElasticNetForecaster` | ML (regularised regression) | ✅ | included in base |
| `ThetaForecaster` | Statistical | ❌ | included in base |
| `CrostonForecaster` | Statistical (intermittent) | ❌ | included in base |
| `NBEATSForecaster` | Deep learning | ❌ | `pip install "autotsforecast[neural]"` |
| `NHiTSForecaster` | Deep learning | ❌ | `pip install "autotsforecast[neural]"` |
| `TFTForecaster` | Deep learning | ❌ | `pip install "autotsforecast[neural]"` |

---

### LightGBMForecaster

LightGBM gradient boosting with direct multi-step forecasting.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `horizon` | int | required | Forecast horizon |
| `n_lags` | int | `14` | Number of lag features |
| `n_estimators` | int | `300` | Number of trees |
| `learning_rate` | float | `0.05` | Shrinkage rate |
| `num_leaves` | int | `31` | Max leaves per tree |

**Covariate Support:** Yes

```python
LightGBMForecaster(horizon=14, n_lags=14, n_estimators=300)
```

---

### CatBoostForecaster

CatBoost gradient boosting with direct multi-step forecasting.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `horizon` | int | required | Forecast horizon |
| `n_lags` | int | `14` | Number of lag features |
| `iterations` | int | `300` | Number of trees |
| `learning_rate` | float | `0.05` | Shrinkage rate |
| `depth` | int | `6` | Tree depth |

**Covariate Support:** Yes

```python
CatBoostForecaster(horizon=14, n_lags=14, iterations=300)
```

---

### ElasticNetForecaster

Elastic-Net regularised regression with lag features. Fast and robust baseline.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `horizon` | int | required | Forecast horizon |
| `n_lags` | int | `14` | Number of lag features |
| `alpha` | float | `1.0` | Regularisation strength |
| `l1_ratio` | float | `0.5` | Lasso vs. Ridge mix (0 = Ridge, 1 = Lasso) |

**Covariate Support:** Yes

```python
ElasticNetForecaster(horizon=14, n_lags=14, alpha=0.5)
```

---

### ThetaForecaster

Theta method (statsmodels). Strong on seasonal data.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `horizon` | int | required | Forecast horizon |
| `period` | int or None | `None` | Seasonal period. Auto-detected from freq if None |
| `deseasonalize` | bool | `True` | Whether to deseasonalise before fitting |

**Covariate Support:** No

```python
ThetaForecaster(horizon=12, period=12)  # monthly with yearly seasonality
```

---

### CrostonForecaster

Croston / SBA method for intermittent (sparse) demand forecasting.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `horizon` | int | required | Forecast horizon |
| `alpha` | float | `0.1` | Smoothing parameter (0 < alpha < 1) |
| `variant` | str | `'sba'` | `'sba'` (Syntetos–Boylan adjustment) or `'classic'` |

**Covariate Support:** No

```python
CrostonForecaster(horizon=14, alpha=0.1, variant='sba')
```

---

### NBEATSForecaster

Neural Basis Expansion Analysis (N-BEATS) via Darts.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `horizon` | int | required | Forecast horizon |
| `input_chunk_length` | int | `2 × horizon` | Look-back window |
| `n_epochs` | int | `50` | Training epochs |

**Covariate Support:** No

**Requires:** `pip install "autotsforecast[neural]"`

```python
NBEATSForecaster(horizon=14, n_epochs=100)
```

---

### NHiTSForecaster

Neural Hierarchical Interpolation for Time Series (N-HiTS) via Darts.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `horizon` | int | required | Forecast horizon |
| `input_chunk_length` | int | `2 × horizon` | Look-back window |
| `n_epochs` | int | `50` | Training epochs |

**Covariate Support:** No

**Requires:** `pip install "autotsforecast[neural]"`

```python
NHiTSForecaster(horizon=14, n_epochs=100)
```

---

### TFTForecaster

Temporal Fusion Transformer via Darts.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `horizon` | int | required | Forecast horizon |
| `input_chunk_length` | int | `2 × horizon` | Look-back window |
| `hidden_size` | int | `64` | Hidden layer size |
| `n_epochs` | int | `50` | Training epochs |

**Covariate Support:** No

**Requires:** `pip install "autotsforecast[neural]"`

```python
TFTForecaster(horizon=14, hidden_size=128, n_epochs=100)
```

---

### VARForecaster

Vector Autoregression for multivariate time series.

**Parameters:**

| Parameter | Type | Default | Allowed Values | Description |
|-----------|------|---------|----------------|-------------|
| `horizon` | int | required | ≥ 1 | Number of steps to forecast |
| `lags` | int | `1` | 1-21 | Number of lag terms |
| `trend` | str | `'c'` | `'c'`, `'ct'`, `'ctt'`, `'n'` | Trend type: constant, constant+trend, constant+trend+trend², none |

**Covariate Support:** No (VAR models its own lags internally; does not accept `X`)

> **Note:** `VARForecaster` requires at least 2 series in `y`. Passing a single-column DataFrame raises a `ValueError`.

**Example:**
```python
VARForecaster(horizon=14, lags=7, trend='c')
```

---

### LinearForecaster

Linear regression forecaster.

> **Note:** `LinearForecaster` **requires** covariates `X` — both at `fit()` and `predict()` time. If you call `AutoForecaster.fit(y)` without providing `X`, this model is automatically skipped. It is not included in `get_default_candidate_models()`.

**Parameters:**

| Parameter | Type | Default | Allowed Values | Description |
|-----------|------|---------|----------------|-------------|
| `horizon` | int | required | ≥ 1 | Number of steps to forecast |

**Covariate Support:** Yes (automatically included as features when X is provided)

**Requires X:** Yes — raises `ValueError` if X is not passed to `fit()` or `predict()`.

**Example:**
```python
LinearForecaster(horizon=14)
```

---

### MovingAverageForecaster

Simple moving average forecaster.

**Parameters:**

| Parameter | Type | Default | Allowed Values | Description |
|-----------|------|---------|----------------|-------------|
| `horizon` | int | required | ≥ 1 | Number of steps to forecast |
| `window` | int | `7` | 1-100 | Window size for averaging |

**Covariate Support:** No

**Example:**
```python
MovingAverageForecaster(horizon=14, window=7)
```

---

### RandomForestForecaster

Random Forest with automatic lag and covariate handling.

**Parameters:**

| Parameter | Type | Default | Allowed Values | Description |
|-----------|------|---------|----------------|-------------|
| `horizon` | int | required | ≥ 1 | Number of steps to forecast |
| `n_lags` | int | `7` | 1-60 | Number of lag features |
| `n_estimators` | int | `100` | 10-1000 | Number of trees |
| `max_depth` | int | `None` | None, 2-50 | Maximum tree depth (None = unlimited) |
| `random_state` | int | `42` | Any integer | Random seed for reproducibility |
| `preprocess_covariates` | bool | `True` | `True`, `False` | Auto-encode categorical features |
| `**rf_params` | dict | `{}` | sklearn params | Additional RandomForestRegressor parameters |

**Covariate Support:** Yes (with automatic categorical encoding)

**Categorical Encoding:** Automatic (one-hot or label encoding)

**Example:**
```python
RandomForestForecaster(
    horizon=14, 
    n_lags=14, 
    n_estimators=400, 
    max_depth=10,
    random_state=42
)
```

---

### XGBoostForecaster

XGBoost with automatic lag and covariate handling.

**Parameters:**

| Parameter | Type | Default | Allowed Values | Description |
|-----------|------|---------|----------------|-------------|
| `horizon` | int | required | ≥ 1 | Number of steps to forecast |
| `n_lags` | int | `7` | 1-60 | Number of lag features |
| `n_estimators` | int | `100` | 10-1000 | Number of boosting rounds |
| `max_depth` | int | `6` | 2-20 | Maximum tree depth |
| `learning_rate` | float | `0.1` | 0.001-0.5 | Learning rate (lower = slower, more accurate) |
| `random_state` | int | `42` | Any integer | Random seed |
| `preprocess_covariates` | bool | `True` | `True`, `False` | Auto-encode categorical features |
| `**xgb_params` | dict | `{}` | XGBoost params | Additional XGBRegressor parameters |

**Covariate Support:** Yes (with automatic categorical encoding)

**Categorical Encoding:** Automatic (one-hot or label encoding)

**Example:**
```python
XGBoostForecaster(
    horizon=14,
    n_lags=14,
    n_estimators=400,
    max_depth=6,
    learning_rate=0.05,
    random_state=42
)
```

---

### ProphetForecaster

Facebook Prophet with automatic seasonality detection.

**Parameters:**

| Parameter | Type | Default | Allowed Values | Description |
|-----------|------|---------|----------------|-------------|
| `horizon` | int | required | ≥ 1 | Number of steps to forecast |
| `**prophet_params` | dict | `{}` | Prophet params | Additional Prophet parameters |

**Covariate Support:** Yes (as regressors)

**Example:**
```python
ProphetForecaster(horizon=14)
```

---

### ARIMAForecaster

ARIMA/SARIMA forecasting.

**Parameters:**

| Parameter | Type | Default | Allowed Values | Description |
|-----------|------|---------|----------------|-------------|
| `horizon` | int | required | ≥ 1 | Number of steps to forecast |
| `order` | tuple | `(1,1,1)` | (p, d, q) where p,q: 0-5, d: 0-2 | ARIMA order |
| `seasonal_order` | tuple | `(0,0,0,0)` | (P, D, Q, s) where s = seasonal period | Seasonal ARIMA order |
| `**arima_params` | dict | `{}` | statsmodels params | Additional SARIMAX parameters |

**Covariate Support:** Yes (as exogenous variables)

**Example:**
```python
ARIMAForecaster(
    horizon=14,
    order=(1, 1, 1),
    seasonal_order=(1, 0, 1, 7)
)
```

---

### ETSForecaster

Exponential Smoothing State Space Model.

**Parameters:**

| Parameter | Type | Default | Allowed Values | Description |
|-----------|------|---------|----------------|-------------|
| `horizon` | int | required | ≥ 1 | Number of steps to forecast |
| `seasonal_periods` | int | `None` | None, 2-365 | Seasonal period (7=weekly, 12=monthly) |
| `trend` | str | `None` | None, `'add'`, `'mul'` | Trend component |
| `seasonal` | str | `None` | None, `'add'`, `'mul'` | Seasonal component |
| `**ets_params` | dict | `{}` | statsmodels params | Additional ETSModel parameters |

**Covariate Support:** No

**Example:**
```python
ETSForecaster(
    horizon=14,
    seasonal_periods=7,
    trend=None,
    seasonal='add'
)
```

---

### LSTMForecaster

Long Short-Term Memory neural network.

**Parameters:**

| Parameter | Type | Default | Allowed Values | Description |
|-----------|------|---------|----------------|-------------|
| `horizon` | int | required | ≥ 1 | Number of steps to forecast |
| `n_lags` | int | `21` | 10-100 | Number of lag features |
| `hidden_size` | int | `32` | 8-256 | LSTM hidden layer size |
| `num_layers` | int | `1` | 1-5 | Number of LSTM layers |
| `dropout` | float | `0.0` | 0.0-0.5 | Dropout rate (0.0 = no dropout) |
| `epochs` | int | `20` | 5-200 | Training epochs |
| `batch_size` | int | `32` | 8-256 | Batch size for training |
| `learning_rate` | float | `0.001` | 0.0001-0.1 | Learning rate |
| `random_state` | int | `42` | Any integer | Random seed |

**Covariate Support:** Yes

**Example:**
```python
LSTMForecaster(
    horizon=14,
    n_lags=21,
    hidden_size=32,
    num_layers=1,
    dropout=0.0,
    epochs=20,
    batch_size=64,
    learning_rate=0.001,
    random_state=42
)
```

---

### Chronos2Forecaster

**State-of-the-art pretrained foundation model** from Amazon Science for zero-shot time series forecasting.

**Key Features:**
- Zero-shot forecasting (no training required)
- Multiple model sizes (9M to 710M parameters)
- Bolt variants: up to 250x faster than original
- State-of-the-art performance on fev-bench and GIFT-Eval
- Supports probabilistic forecasting with quantiles

**Parameters:**

| Parameter | Type | Default | Allowed Values | Description |
|-----------|------|---------|----------------|-------------|
| `horizon` | int | required | ≥ 1 | Number of steps to forecast |
| `model_name` | str | `"amazon/chronos-2"` | See model sizes below | Pretrained model to use |
| `device_map` | str | `"auto"` | `"auto"`, `"cuda"`, `"cpu"` | Device mapping (auto uses GPU if available) |
| `torch_dtype` | str | `"auto"` | `"auto"`, `"float32"`, `"float16"` | PyTorch dtype for model weights |
| `quantile_levels` | list[float] | `None` | [0.0-1.0] | Quantile levels for prediction intervals |

**Available Model Sizes:**

| Model Name | Parameters | Speed | Best For |
|------------|-----------|-------|----------|
| `"amazon/chronos-2"` | 120M | ⭐⭐ | Best accuracy (default) |
| `"autogluon/chronos-2-small"` | 28M | ⭐⭐⭐ | Good balance |
| `"amazon/chronos-bolt-tiny"` | 9M | ⭐⭐⭐⭐ | Ultra fast, resource-constrained |
| `"amazon/chronos-bolt-mini"` | 21M | ⭐⭐⭐⭐ | Fast inference |
| `"amazon/chronos-bolt-small"` | 48M | ⭐⭐⭐ | Balanced speed/accuracy |
| `"amazon/chronos-bolt-base"` | 205M | ⭐⭐ | High accuracy + fast |

**Covariate Support:** Not in current wrapper (univariate only)

**Methods:**

```python
predict(X=None) -> pd.DataFrame
```
Returns median forecasts (quantile 0.5).

```python
predict_quantiles(quantile_levels=[0.1, 0.5, 0.9]) -> pd.DataFrame
```
Returns probabilistic forecasts with multiple quantiles for uncertainty quantification.

**Example:**

```python
from autotsforecast.models.external import Chronos2Forecaster

# Default: Best accuracy
model = Chronos2Forecaster(horizon=24, model_name="amazon/chronos-2")
model.fit(y_train)  # Just stores context, no training!
forecasts = model.predict()

# Fast variant for production
model_fast = Chronos2Forecaster(
    horizon=24, 
    model_name="amazon/chronos-bolt-small",
    device_map="cuda"  # Use GPU
)
model_fast.fit(y_train)
forecasts = model_fast.predict()

# Probabilistic forecasts
quantile_forecasts = model.predict_quantiles(quantile_levels=[0.1, 0.5, 0.9])
# Returns columns: series_q10, series_q50, series_q90
```

**Installation:**
```bash
pip install "autotsforecast[chronos]"
```

---

## Hierarchical Reconciliation

### HierarchicalReconciler

Ensures hierarchical forecast coherence.

**Parameters:**

| Parameter | Type | Default | Allowed Values | Description |
|-----------|------|---------|----------------|-------------|
| `forecasts` | pd.DataFrame | required | DataFrame | Base forecasts to reconcile |
| `hierarchy` | dict | required | Dict[str, List[str]] | Hierarchy structure (parent: [children]) |

**Methods:**

```python
reconcile(method: str = 'bottom_up') -> HierarchicalReconciler
```

| Parameter | Type | Default | Allowed Values | Description |
|-----------|------|---------|----------------|-------------|
| `method` | str | `'bottom_up'` | `'bottom_up'`, `'top_down'`, `'middle_out'`, `'ols'` | Reconciliation method |

**Methods Explained:**
- `'bottom_up'`: Aggregate from bottom level (keeps bottom forecasts unchanged)
- `'top_down'`: Disaggregate from top using historical proportions
- `'middle_out'`: Start from middle level (simplified to bottom_up)
- `'ols'`: OLS optimal reconciliation (minimizes total squared error)

**Example:**
```python
from autotsforecast.hierarchical import HierarchicalReconciler

hierarchy = {'Total': ['North', 'South', 'East']}
reconciler = HierarchicalReconciler(forecasts, hierarchy)
reconciler.reconcile(method='ols')
reconciled_forecasts = reconciler.reconciled_forecasts
```

---

## Interpretability Tools

### DriverAnalyzer

Analyze covariate impact on forecasts.

**Parameters:**

| Parameter | Type | Default | Allowed Values | Description |
|-----------|------|---------|----------------|-------------|
| `model` | BaseForecaster | required | Any fitted forecaster | Model to analyze |
| `feature_names` | list | `None` | List of strings | Feature names for interpretability |

**Methods:**

```python
calculate_feature_importance(X: pd.DataFrame, y: pd.DataFrame, method: str = 'coefficients')
```

| Parameter | Type | Default | Allowed Values | Description |
|-----------|------|---------|----------------|-------------|
| `X` | pd.DataFrame | required | DataFrame | Covariate data |
| `y` | pd.DataFrame | required | DataFrame | Target data |
| `method` | str | `'coefficients'` | `'coefficients'`, `'permutation'`, `'shap'` | Importance method |

**Methods Explained:**
- `'coefficients'`: Linear model coefficients (LinearForecaster only)
- `'permutation'`: Permutation importance (any model)
- `'shap'`: SHAP values (tree-based models)

```python
calculate_shap_values(X: pd.DataFrame, y: pd.DataFrame, background_samples: pd.DataFrame = None, max_samples: int = 100)
```

| Parameter | Type | Default | Allowed Values | Description |
|-----------|------|---------|----------------|--------------|
| `X` | pd.DataFrame | required | DataFrame | Covariate data (external features) |
| `y` | pd.DataFrame | required | DataFrame | Historical target data (needed to create lag features) |
| `background_samples` | pd.DataFrame | `None` | DataFrame or None | Background for SHAP (None = auto-sample from X) |
| `max_samples` | int | `100` | 50-500 | Maximum samples for SHAP calculation |

**Example:**
```python
from autotsforecast.interpretability import DriverAnalyzer

analyzer = DriverAnalyzer(model, feature_names=['temp', 'promo'])

# Sensitivity analysis (works for all models)
importance = analyzer.calculate_feature_importance(X_train, y_train, method='sensitivity')

# SHAP values (tree-based models)
shap_values = analyzer.calculate_shap_values(X_train, y_train)
shap_importance = analyzer.get_shap_feature_importance(shap_values)
```

---

## Preprocessing

### CovariatePreprocessor

Automatic preprocessing for categorical and numerical features.

**Parameters:**

| Parameter | Type | Default | Allowed Values | Description |
|-----------|------|---------|----------------|-------------|
| `categorical_features` | list | `None` | List of strings or None | Categorical column names (None = auto-detect) |
| `numerical_features` | list | `None` | List of strings or None | Numerical column names (None = auto-detect) |
| `encoding` | str | `'onehot'` | `'onehot'`, `'label'` | Categorical encoding method |
| `scale_numerical` | bool | `False` | `True`, `False` | Standardize numerical features |
| `handle_missing` | str | `'forward_fill'` | `'forward_fill'`, `'backward_fill'`, `'mean'`, `'drop'` | Missing value strategy |
| `max_categories` | int | `50` | 10-1000 | Max categories for one-hot (use label encoding beyond) |

**Methods:**

```python
fit(X: pd.DataFrame) -> CovariatePreprocessor
transform(X: pd.DataFrame) -> pd.DataFrame
fit_transform(X: pd.DataFrame) -> pd.DataFrame
```

**Example:**
```python
from autotsforecast.utils.preprocessing import CovariatePreprocessor

preprocessor = CovariatePreprocessor(
    encoding='onehot',
    scale_numerical=False,
    handle_missing='forward_fill',
    max_categories=50
)
X_processed = preprocessor.fit_transform(X_train)
X_test_processed = preprocessor.transform(X_test)
```

---

## Common Patterns

### Basic Forecasting
```python
model = RandomForestForecaster(horizon=14, n_lags=7)
model.fit(y_train, X_train)
forecasts = model.predict(X_test)
```

### Automatic Model Selection
```python
auto = AutoForecaster(
    candidate_models=[model1, model2, model3],
    n_splits=3,
    per_series_models=True
)
auto.fit(y_train, X_train)
forecasts = auto.forecast(X_test)
```

### Per-Series Covariates (Different Features per Series)
```python
# Different features for each series
X_train_dict = {
    'product_a': pd.DataFrame({'temperature': [...], 'ads': [...]}, index=dates),
    'product_b': pd.DataFrame({'price': [...], 'promo': [...]}, index=dates)
}
X_test_dict = {
    'product_a': X_a_test,
    'product_b': X_b_test
}

auto = AutoForecaster(
    candidate_models=[model1, model2],
    per_series_models=True
)
auto.fit(y_train, X=X_train_dict)
forecasts = auto.forecast(X=X_test_dict)
```

### With Hierarchical Reconciliation
```python
auto.fit(y_train, X_train)
base_forecasts = auto.forecast(X_test)

hierarchy = {'Total': ['Region_A', 'Region_B']}
reconciler = HierarchicalReconciler(base_forecasts, hierarchy)
reconciler.reconcile(method='ols')
reconciled = reconciler.reconciled_forecasts
```

### With Feature Importance
```python
model.fit(y_train, X_train)
analyzer = DriverAnalyzer(model, feature_names=list(X_train.columns))
importance = analyzer.calculate_feature_importance(X_train, y_train, method='shap')
```

---

## Tips and Best Practices

### Choosing Parameters

**Horizon:**
- Start small (7-14 days) for better accuracy
- Longer horizons (30+ days) are less accurate but more useful for planning

**Lags (n_lags):**
- Weekly data: 7-14 lags
- Monthly data: 12-24 lags
- Daily data: 14-30 lags
- LSTMs benefit from longer lags (30-60)

**CV Splits (n_splits):**
- More splits (5+) = more robust selection but slower
- Fewer splits (2-3) = faster but less reliable
- Ensure sufficient data: need at least `(n_splits + 1) × test_size` points

**Tree-Based Model Parameters:**
- More trees (`n_estimators=500`) = better but slower
- Deeper trees (`max_depth=10+`) = risk overfitting on small data
- Lower learning rate (`learning_rate=0.01-0.05`) = slower but more accurate for XGBoost

**Categorical Encoding:**
- Use `'onehot'` (default) for low-cardinality features (< 10 categories)
- Use `'label'` for high-cardinality features (50+ categories)
- Automatic detection works well in most cases

---

## See Also

- **[README.md](README.md)**: Package overview and quick start
- **[Tutorial](examples/autotsforecast_tutorial.ipynb)**: Comprehensive hands-on guide
- **[QUICKSTART.md](QUICKSTART.md)**: 5-minute getting started guide
- **[GitHub Issues](https://github.com/weibinxu86/autotsforecast/issues)**: Bug reports and feature requests

---

## Calendar Features

### CalendarFeatures

Automatic extraction of time-based features from datetime indices.

**Parameters:**

| Parameter | Type | Default | Allowed Values | Description |
|-----------|------|---------|----------------|-------------|
| `features` | list | `'auto'` | `'auto'` or list of strings | Features to extract (auto-detect or specify) |
| `cyclical_encoding` | bool | `True` | `True`, `False` | Use sin/cos encoding for cyclical features |
| `fourier_terms` | dict | `None` | Dict[str, Tuple[float, int]] | Fourier terms: `{'name': (period, n_terms)}` |
| `holidays` | str/list | `None` | Country code or list | Holiday detection (e.g., 'US', 'UK') |

**Available Features:**
- `'dayofweek'` — Day of week (0-6)
- `'month'` — Month (1-12)
- `'day'` — Day of month (1-31)
- `'quarter'` — Quarter (1-4)
- `'week'` — Week of year (1-52)
- `'is_weekend'` — Weekend flag (0/1)
- `'is_month_start'` — Month start flag
- `'is_month_end'` — Month end flag

**Methods:**

```python
fit(data: pd.DataFrame) -> CalendarFeatures
```
Fit to data to determine feature set (if `features='auto'`).

```python
transform(data: pd.DataFrame) -> pd.DataFrame
```
Extract calendar features from the data's datetime index.

```python
fit_transform(data: pd.DataFrame) -> pd.DataFrame
```
Fit and transform in one step.

```python
transform_future(horizon: int, freq: str = 'D') -> pd.DataFrame
```
Generate calendar features for future dates.

**Example:**
```python
from autotsforecast.features.calendar import CalendarFeatures

# Auto-detect features with cyclical encoding
cal = CalendarFeatures(cyclical_encoding=True)
features = cal.fit_transform(y_train)

# Custom features with Fourier terms
cal = CalendarFeatures(
    features=['dayofweek', 'month', 'is_weekend'],
    fourier_terms={'weekly': (7, 2), 'yearly': (365.25, 3)},
    cyclical_encoding=True
)
features = cal.fit_transform(y_train)

# Generate future calendar features
future_features = cal.transform_future(horizon=30)
```

### add_calendar_features (Convenience Function)

```python
add_calendar_features(
    data: pd.DataFrame,
    features: list = 'auto',
    cyclical_encoding: bool = True
) -> pd.DataFrame
```

One-step function to add calendar features to a DataFrame.

---

## Prediction Intervals

### PredictionIntervals

Generate prediction intervals using conformal prediction, residual-based, or empirical methods.

**Parameters:**

| Parameter | Type | Default | Allowed Values | Description |
|-----------|------|---------|----------------|-------------|
| `method` | str | `'conformal'` | `'conformal'`, `'residual'`, `'empirical'` | Interval estimation method |
| `coverage` | list | `[0.95]` | List of floats 0-1 | Coverage levels (e.g., `[0.80, 0.95]`) |

**Methods:**

```python
fit(model: BaseForecaster, y_train: pd.DataFrame, X_train: pd.DataFrame = None)
```
Fit the interval estimator by computing residuals from the fitted model.

```python
predict(point_forecast: pd.DataFrame) -> dict
```
Generate prediction intervals around point forecasts.
- Returns: `{'point': df, 'lower_80': df, 'upper_80': df, 'lower_95': df, 'upper_95': df}`

**Methods Explained:**
- `'conformal'`: Uses conformal prediction with calibration residuals. Provides distribution-free coverage guarantees.
- `'residual'`: Uses standard deviation of residuals × z-score for Gaussian intervals.
- `'empirical'`: Uses empirical quantiles of residuals for non-parametric intervals.

**Example:**
```python
from autotsforecast.uncertainty.intervals import PredictionIntervals

# Fit model first
model = RandomForestForecaster(horizon=14)
model.fit(y_train, X=X_train)
forecasts = model.predict(X=X_test)

# Create prediction intervals
pi = PredictionIntervals(method='conformal', coverage=[0.80, 0.95])
pi.fit(model, y_train)
intervals = pi.predict(forecasts)

# Access intervals
lower_95 = intervals['lower_95']
upper_95 = intervals['upper_95']
print(f"95% interval: [{lower_95.iloc[0, 0]:.1f}, {upper_95.iloc[0, 0]:.1f}]")
```

### ConformalPredictor

Online conformal predictor for streaming updates.

**Parameters:**

| Parameter | Type | Default | Allowed Values | Description |
|-----------|------|---------|----------------|-------------|
| `coverage` | float | `0.95` | 0.0-1.0 | Target coverage level |

**Methods:**

```python
fit(residuals: np.ndarray)
```
Initialize with calibration residuals.

```python
update(new_residual: float)
```
Update with new observation for online learning.

```python
get_interval(point_forecast: float) -> Tuple[float, float]
```
Get prediction interval for a single point forecast.

---

## Visualization

### plot_forecast

Create static forecast visualization with matplotlib.

```python
plot_forecast(
    y_train: pd.Series,
    y_test: pd.Series = None,
    forecast: pd.Series = None,
    lower: pd.Series = None,
    upper: pd.Series = None,
    title: str = 'Forecast',
    figsize: tuple = (12, 6)
) -> matplotlib.figure.Figure
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `y_train` | pd.Series | required | Historical training data |
| `y_test` | pd.Series | `None` | Actual test values (optional) |
| `forecast` | pd.Series | `None` | Point forecasts |
| `lower` | pd.Series | `None` | Lower bound of prediction interval |
| `upper` | pd.Series | `None` | Upper bound of prediction interval |
| `title` | str | `'Forecast'` | Plot title |
| `figsize` | tuple | `(12, 6)` | Figure size |

**Example:**
```python
from autotsforecast.visualization.plots import plot_forecast

fig = plot_forecast(
    y_train=y_train['series_a'],
    y_test=y_test['series_a'],
    forecast=forecasts['series_a'],
    lower=intervals['lower_95']['series_a'],
    upper=intervals['upper_95']['series_a'],
    title='Sales Forecast with 95% PI'
)
plt.show()
```

### plot_forecast_interactive

Create interactive forecast visualization with Plotly.

```python
plot_forecast_interactive(
    y_train: pd.Series,
    y_test: pd.Series = None,
    forecast: pd.Series = None,
    lower: pd.Series = None,
    upper: pd.Series = None,
    title: str = 'Forecast'
) -> plotly.graph_objects.Figure
```

Same parameters as `plot_forecast`, but returns a Plotly figure for interactive exploration.

**Requires:** `pip install plotly`

### plot_model_comparison

Compare model performance with horizontal bar chart.

```python
plot_model_comparison(
    results: Dict[str, float],
    metric: str = 'RMSE',
    title: str = 'Model Comparison'
) -> matplotlib.figure.Figure
```

**Example:**
```python
from autotsforecast.visualization.plots import plot_model_comparison

results = {'ARIMA': 12.5, 'XGBoost': 10.2, 'Prophet': 11.8}
fig = plot_model_comparison(results, metric='RMSE')
plt.show()
```

### plot_residuals

Create residual diagnostic plots.

```python
plot_residuals(
    actual: pd.Series,
    predicted: pd.Series,
    title: str = 'Residual Analysis'
) -> matplotlib.figure.Figure
```

Returns a figure with:
- Residual time series
- Histogram
- Q-Q plot

---

## Parallel Processing

### ParallelForecaster

Wrapper for parallel forecasting operations.

**Parameters:**

| Parameter | Type | Default | Allowed Values | Description |
|-----------|------|---------|----------------|-------------|
| `n_jobs` | int | `-1` | 1 to CPU count, -1 | Number of parallel jobs (-1 = all cores) |
| `backend` | str | `'auto'` | `'auto'`, `'joblib'`, `'threads'` | Parallelization backend |
| `verbose` | bool | `False` | `True`, `False` | Show progress information |

**Methods:**

```python
parallel_series_fit(
    model_factory: callable,
    y: pd.DataFrame,
    X: pd.DataFrame = None
) -> Dict[str, Any]
```
Fit models for each series in parallel using a model factory.

```python
parallel_fit(models: list, y: pd.DataFrame, X: pd.DataFrame = None) -> list
```
Fit multiple different models in parallel.

```python
parallel_predict(models: list, X: pd.DataFrame = None) -> list
```
Generate predictions from multiple fitted models in parallel.

**Example:**
```python
from autotsforecast.utils.parallel import ParallelForecaster
from autotsforecast.models.external import RandomForestForecaster

# Create parallel forecaster with 4 workers
pf = ParallelForecaster(n_jobs=4, verbose=True)

# Fit each series in parallel using model factory
fitted_models = pf.parallel_series_fit(
    model_factory=lambda: RandomForestForecaster(horizon=14, n_lags=7),
    y=y_train,
    X=X_train
)
```

### parallel_map

Generic parallel map function.

```python
parallel_map(
    func: callable,
    items: list,
    n_jobs: int = -1,
    verbose: bool = False
) -> list
```

**Example:**
```python
from autotsforecast.utils.parallel import parallel_map

def process_series(series_data):
    model = RandomForestForecaster(horizon=14)
    model.fit(series_data)
    return model.predict()

results = parallel_map(process_series, [y[col] for col in y.columns], n_jobs=4)
```

### get_optimal_n_jobs

Determine optimal number of parallel jobs.

```python
get_optimal_n_jobs(n_items: int, requested_jobs: int = -1) -> int
```

Returns the optimal number of jobs based on available CPUs and workload.

---

## Progress Tracking

### ProgressTracker

Unified progress tracking with rich/tqdm fallback.

**Parameters:**

| Parameter | Type | Default | Allowed Values | Description |
|-----------|------|---------|----------------|-------------|
| `total` | int | required | ≥ 1 | Total number of items |
| `description` | str | `''` | Any string | Progress bar description |
| `disable` | bool | `False` | `True`, `False` | Disable progress display |

**Usage as Context Manager:**
```python
from autotsforecast.visualization.progress import ProgressTracker

with ProgressTracker(total=100, description="Processing") as pbar:
    for i in range(100):
        # Do work
        pbar.update(1)
```

**Usage as Iterator:**
```python
for item in ProgressTracker.track(items, description="Processing"):
    # Do work with item
    pass
```

---

## 🤖 Agentic AI — v0.5.0

---

## Anomaly Detection

### AnomalyDetector

Detect anomalies in time series data using statistical and ML methods.

**Location:** `autotsforecast.anomaly.detector`

**Parameters:**

| Parameter | Type | Default | Allowed Values | Description |
|-----------|------|---------|----------------|-------------|
| `method` | str | `'zscore'` | `'zscore'`, `'iqr'`, `'isolation_forest'`, `'forecast_residual'` | Detection algorithm |
| `contamination` | float | `0.05` | 0.0–0.5 | Expected proportion of anomalies |
| `threshold` | float | `3.0` | > 0 | Z-score / IQR multiplier (ignored for isolation_forest) |

**Methods:**

| Method | Signature | Returns | Description |
|--------|-----------|---------|-------------|
| `fit(y)` | `fit(y: pd.DataFrame)` | `self` | Fit detector to data |
| `predict(y)` | `predict(y: pd.DataFrame)` | `pd.DataFrame[bool]` | Predict anomalies (True = anomaly) |
| `fit_predict(y)` | `fit_predict(y: pd.DataFrame)` | `pd.DataFrame[bool]` | Fit and predict in one call |
| `get_summary()` | `get_summary()` | `AnomalyResult` | Pydantic summary of detection results |

**Detection Methods:**

| Method | Description | Extra Dep |
|--------|-------------|-----------|
| `zscore` | Points > `threshold` standard deviations from mean | — |
| `iqr` | Points outside `threshold × IQR` from Q1/Q3 | — |
| `isolation_forest` | sklearn IsolationForest (unsupervised) | scikit-learn |
| `forecast_residual` | Moving-average residual thresholding | — |

**Example:**
```python
from autotsforecast.anomaly.detector import AnomalyDetector

detector = AnomalyDetector(method='zscore', contamination=0.05, threshold=3.0)
anomalies = detector.fit_predict(y_train)   # pd.DataFrame of bool
summary = detector.get_summary()

print(f"Total anomalies: {summary.total_anomalies}")
print(f"Per series: {summary.per_series}")
```

---

## NLP / Insight Engine

### InsightEngine

Generate natural-language summaries and risk flags for forecasts.

**Location:** `autotsforecast.nlp.insights`

**Parameters:**

| Parameter | Type | Default | Allowed Values | Description |
|-----------|------|---------|----------------|-------------|
| `mode` | str | `'rule_based'` | `'rule_based'`, `'llm'` | Insight generation mode |
| `llm_client` | object | `None` | Any OpenAI-compatible client | LLM client (required when `mode='llm'`) |
| `model` | str | `'gpt-4o'` | Any model name | LLM model to use |

**Methods:**

| Method | Signature | Returns | Description |
|--------|-----------|---------|-------------|
| `summarize_forecast_dataframes` | `(y_train, forecasts, y_test=None)` | `str` | Plain-English forecast summary |
| `flag_risks_from_dataframes` | `(y_train, forecasts)` | `list[str]` | List of risk warnings |
| `generate_report` | `(result, y_train, y_test=None)` | `str` | Full narrative report |

**Example:**
```python
from autotsforecast.nlp.insights import InsightEngine

# Rule-based (no LLM needed)
engine = InsightEngine(mode='rule_based')
summary = engine.summarize_forecast_dataframes(y_train, forecasts, y_test)
risks = engine.flag_risks_from_dataframes(y_train, forecasts)
report = engine.generate_report(result, y_train, y_test)

# LLM-powered
import openai
engine = InsightEngine(mode='llm', llm_client=openai.OpenAI(), model='gpt-4o')
narrative = engine.summarize_forecast_dataframes(y_train, forecasts, y_test)
```

---

## Model Registry

### ModelRegistry

Save, load, list, and delete fitted models locally.

**Location:** `autotsforecast.registry.store`

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `registry_dir` | str or Path | `~/.autotsforecast/registry/` | Directory where models are stored |

**Methods:**

| Method | Signature | Returns | Description |
|--------|-----------|---------|-------------|
| `save` | `save(model, name, tags=None)` | `str` (path) | Pickle model + write JSON index entry |
| `load` | `load(name)` | fitted model | Unpickle and return model |
| `list` | `list()` | `pd.DataFrame` | Table of all saved models |
| `get_entry` | `get_entry(name)` | `RegistryEntry` | Pydantic metadata for a model |
| `delete` | `delete(name)` | None | Remove model file and index entry |
| `clear` | `clear()` | None | Delete all models in registry |

**Example:**
```python
from autotsforecast.registry.store import ModelRegistry

registry = ModelRegistry()          # Default: ~/.autotsforecast/registry/
registry.save(auto, name='v1', tags={'env': 'production'})

df = registry.list()
print(df[['name', 'model_class', 'saved_at']])

auto2 = registry.load('v1')
forecasts = auto2.forecast()
registry.delete('v1')
```

---

## Structured Outputs

### AutoForecaster.to_structured()

Convert forecasting results to a Pydantic model for agent-friendly JSON output.

**Signature:**
```python
to_structured(forecasts: pd.DataFrame = None) -> ForecastResult
```

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `forecasts` | pd.DataFrame | `None` | Override forecasts; defaults to `self.forecasts_` |

**Returns:** `ForecastResult` with fields:

| Field | Type | Description |
|-------|------|-------------|
| `best_model` | str | Name of best model |
| `metric` | str | Optimisation metric used |
| `series_count` | int | Number of forecasted series |
| `horizon` | int | Forecast horizon |
| `per_series_models` | dict or None | Best model per series (if `per_series_models=True`) |
| `forecast_values` | dict | Series → list of forecast values |

**Example:**
```python
auto.fit(y_train)
auto.forecast()
result = auto.to_structured()
print(result.best_model)
print(result.model_dump_json())
```

---

## OpenAI / Anthropic Integration

### get_openai_tools()

Return OpenAI function-calling tool definitions.

**Location:** `autotsforecast.integrations.openai_schemas`

```python
get_openai_tools() -> list[dict]
```

Returns a list of tool dicts in OpenAI `tools` format. Pass directly to `openai.chat.completions.create(tools=...)`.

### get_anthropic_tools()

Return Anthropic tool definitions.

```python
get_anthropic_tools() -> list[dict]
```

Returns a list of tool dicts in Anthropic `tools` format. Pass directly to `anthropic.messages.create(tools=...)`.

### handle_tool_call()

Dispatch a tool call and return a string result.

```python
handle_tool_call(tool_name: str, arguments: Union[str, dict]) -> str
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `tool_name` | str | Name of the tool to invoke |
| `arguments` | str or dict | JSON string or dict of arguments |

**Available tool names:** `fit_and_forecast`, `run_backtest`, `prediction_intervals`, `anomaly_detection`, `calendar_features`, `reconcile_hierarchy`, `model_catalog`

**Example:**
```python
from autotsforecast.integrations.openai_schemas import get_openai_tools, handle_tool_call

tools = get_openai_tools()
# ... LLM call ...
result = handle_tool_call("fit_and_forecast", {"csv_data": "...", "horizon": 14})
print(result)
```

---

## LangChain Integration

### get_autotsforecast_tools()

Return LangChain `BaseTool` instances for all forecasting operations.

**Location:** `autotsforecast.integrations.langchain_tools`

```python
get_autotsforecast_tools() -> list[BaseTool]
```

Returns a list of `BaseTool` subclasses — one per forecasting operation. Pass to any LangChain agent.

**Example:**
```python
from autotsforecast.integrations.langchain_tools import get_autotsforecast_tools

tools = get_autotsforecast_tools()
# agent = create_react_agent(llm, tools, prompt)
```

---

## MCP Server

### create_server()

Create the MCP server instance.

**Location:** `autotsforecast.mcp.server`

```python
create_server() -> mcp.Server
```

Returns a configured `mcp.Server` with 7 registered tools.

### main()

CLI entry point. Runs the MCP server over stdio.

```python
main() -> None
```

Invoked by `autotsforecast-mcp` CLI command.

**MCP Tool Reference:**

| Tool Name | Input | Output | Description |
|-----------|-------|--------|-------------|
| `fit_and_forecast` | `csv_data`, `horizon`, `metric`, `n_splits`, `per_series` | JSON with `best_model`, `forecasts` | AutoForecaster fit + forecast |
| `run_backtest` | `csv_data`, `model_name`, `horizon`, `n_splits`, `test_size` | JSON with `mean_rmse`, `fold_results` | Cross-validation |
| `prediction_intervals` | `csv_data`, `horizon`, `coverage` | JSON with `lower_80`, `upper_80`, `lower_95`, `upper_95` | Conformal prediction |
| `anomaly_detection` | `csv_data`, `method`, `contamination` | JSON with `anomaly_mask`, `summary` | Outlier detection |
| `calendar_features` | `csv_data` | JSON with feature DataFrame | Time-based features |
| `reconcile_hierarchy` | `forecast_csv`, `hierarchy` | JSON with reconciled forecasts | Hierarchical reconciliation |
| `model_catalog` | — | JSON list of models | All available models |

---

## FastAPI REST Service

### app

**Location:** `autotsforecast.api.app`

FastAPI application instance. Start with `autotsforecast-api` CLI.

**REST API Reference:**

| Method | Endpoint | Request Body | Response |
|--------|----------|-------------|---------|
| `GET` | `/health` | — | `{"status": "ok"}` |
| `GET` | `/models` | — | `{"models": [...]}` |
| `POST` | `/forecast` | `{"csv_data": str, "horizon": int, "metric": str}` | `ForecastResult` JSON |
| `POST` | `/forecast/upload` | multipart CSV file | `ForecastResult` JSON |
| `POST` | `/backtest` | `{"csv_data": str, "model_name": str, "horizon": int, "n_splits": int}` | backtest JSON |
| `POST` | `/intervals` | `{"csv_data": str, "horizon": int, "coverage": list}` | intervals JSON |
| `POST` | `/reconcile` | `{"forecast_csv": str, "hierarchy": dict}` | reconciled JSON |
| `POST` | `/calendar-features` | `{"csv_data": str}` | features JSON |
| `POST` | `/anomalies` | `{"csv_data": str, "method": str, "contamination": float}` | anomaly JSON |
| `POST` | `/insights` | `{"csv_data": str, "horizon": int}` | insights text |

---

## Schemas (Pydantic)

**Location:** `autotsforecast.schemas`

All result models inherit from Pydantic `BaseModel` (or a stub when pydantic is not installed).

| Class | Fields | Description |
|-------|--------|-------------|
| `ForecastResult` | `best_model`, `metric`, `series_count`, `horizon`, `per_series_models`, `forecast_values` | AutoForecaster output |
| `BacktestResult` | `model_name`, `n_splits`, `test_size`, `mean_rmse`, `fold_results` | BacktestValidator output |
| `IntervalResult` | `method`, `coverage`, `lower_80`, `upper_80`, `lower_95`, `upper_95` | PredictionIntervals output |
| `ImportanceResult` | `method`, `feature_names`, `importance_scores` | DriverAnalyzer output |
| `AnomalyResult` | `method`, `total_anomalies`, `per_series`, `contamination` | AnomalyDetector output |
| `InsightResult` | `summary`, `risks`, `report` | InsightEngine output |
| `ModelInfo` | `name`, `description`, `requires_covariates`, `extra` | Catalog entry |
| `ModelCatalog` | `models` | List of ModelInfo |
| `RegistryEntry` | `name`, `model_class`, `saved_at`, `tags`, `file_path` | Registry index entry |
