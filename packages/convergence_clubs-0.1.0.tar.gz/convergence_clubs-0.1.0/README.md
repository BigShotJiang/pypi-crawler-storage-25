# convergence-clubs

A Python implementation of the Phillips and Sul (2007, 2009) convergence club clustering methodology.

This is a port of the R [`ConvergenceClubs`](https://CRAN.R-project.org/package=ConvergenceClubs) package by Roberto Sichera and Pietro Pizzuto.

## Installation

```bash
pip install -e .
```

Or install dependencies manually:

```bash
pip install numpy pandas scipy statsmodels matplotlib
```

## Quick Start

```python
from convergence_clubs import load_filtered_gdp, find_clubs, merge_clubs

# Load the bundled HP-filtered GDP dataset (152 countries, 1970–2003)
df = load_filtered_gdp()

# Find convergence clubs
clubs = find_clubs(
    df,
    data_cols=list(range(1, 35)),  # columns with time-series data (0-indexed)
    unit_names=0,                   # column with country names
    ref_col=34,                     # reference column for sorting (last year)
    time_trim=1/3,                  # discard first 1/3 of periods
    hac_method="FQSB",             # Fixed Quadratic Spectral Bandwidth
    cstar=0,                        # sieve threshold
)

# View results
clubs.summary()
```

**Output:**

```
Number of convergence clubs: 7
Number of divergent units: 0

       n_units   beta  std_err  tvalue  cstar
club1       50  0.382    0.041   9.282      0
club2       30  0.240    0.035   6.904      0
club3       21  0.110    0.032   3.402      0
club4       24  0.131    0.064   2.055      0
club5       14  0.190    0.111   1.701      0
club6       11  1.003    0.166   6.024      0
club7        2 -0.470    0.842  -0.559      0
```

## Merging Clubs

After initial clustering, adjacent clubs can be merged to correct for over-determination:

```python
# Phillips & Sul (2009) method
merged_ps = merge_clubs(clubs, merge_method="PS")
merged_ps.summary()

# von Lyncker & Thoennessen (2017) method
merged_vlt = merge_clubs(clubs, merge_method="vLT")

# Also reclassify divergent units
merged = merge_clubs(clubs, merge_method="PS", merge_divergent_flag=True)
```

## Visualisation

```python
from convergence_clubs import plot_clubs

# Plot all clubs with average transition paths
fig = plot_clubs(clubs, legend=True)

# Plot specific clubs
fig = plot_clubs(clubs, club_indices=[1, 3, 5], avg_tp=True, legend=True)

# Save to file
fig = plot_clubs(clubs, savefig="convergence_clubs.png")

# The returned Figure can be customised further with matplotlib
fig.axes[0].set_title("My custom title")
```

## Transition Paths

```python
from convergence_clubs import transition_paths

# As a dict of DataFrames (one per club)
tp = transition_paths(clubs, output_type="list")

# As a single DataFrame
tp_df = transition_paths(clubs, output_type="data.frame")
```

## Working With Your Own Data

### Preprocessing with the HP filter

Phillips and Sul recommend using HP-filtered log data. The package includes a
built-in Hodrick-Prescott filter:

```python
from convergence_clubs import load_gdp, hp_filter_panel, find_clubs

# Load raw GDP
gdp = load_gdp()

# Apply log + HP filter (lambda=400) — same as the R package preprocessing
filtered = hp_filter_panel(gdp, data_cols=range(1, 35), lamb=400, log_transform=True)

# Now cluster
clubs = find_clubs(filtered, data_cols=list(range(1, 35)), unit_names=0, ref_col=34)
```

You can also use the HP filter on individual series:

```python
from convergence_clubs import hp_filter
import numpy as np

y = np.array([1.0, 2.1, 3.0, 3.8, 5.1, 6.0, 6.9, 8.2])
trend, cycle = hp_filter(y, lamb=1600)
```

### Data format

Your data should be a `pandas.DataFrame` where:
- Each **row** is a unit (country, region, etc.)
- Each **column** is a time period
- Optionally, one column contains unit names/identifiers

```
| Countries  | Y1990 | Y1991 | Y1992 | ... | Y2020 |
|------------|-------|-------|-------|-----|-------|
| Country A  |  5.2  |  5.4  |  5.5  | ... |  7.1  |
| Country B  |  3.1  |  3.3  |  3.4  | ... |  4.8  |
```

## API Reference

| Function | Description |
|---|---|
| `find_clubs(X, data_cols, ...)` | Find convergence clubs (main algorithm) |
| `merge_clubs(clubs, ...)` | Merge adjacent clubs (PS or vLT method) |
| `merge_divergent(clubs, ...)` | Reclassify divergent units into clubs |
| `estimate_mod(H, ...)` | Run the log-t regression test |
| `compute_h(X, ...)` | Compute transition paths h(it) and variance H(t) |
| `transition_paths(clubs, ...)` | Extract transition paths from results |
| `plot_clubs(clubs, ...)` | Visualise transition paths |
| `hp_filter(y, lamb)` | Hodrick-Prescott filter (single series) |
| `hp_filter_panel(X, data_cols, ...)` | HP filter for panel data |
| `load_gdp()` | Load bundled raw GDP data |
| `load_filtered_gdp()` | Load bundled HP-filtered GDP data |

## Algorithm

The Phillips and Sul (2007, 2009) procedure:

1. **Order** units by the last observation (descending)
2. **Core group formation** — find the largest initial group k where the log-t regression t-statistic > -1.65
3. **Sieve** — add remaining units one-by-one if their individual t-statistic > c*
4. **Recurse** — repeat on leftover units until all are classified or declared divergent

The **log-t regression** tests:

$$\log\frac{H_1}{H_t} - 2\log(\log t) = \alpha + \beta \log t + u_t$$

where H(t) is the cross-sectional variance. If t-stat > -1.65, the null of convergence is not rejected.

## References

- Phillips, P.C.B. and Sul, D. (2007). Transition modeling and econometric convergence tests. *Econometrica*, 75(6), 1771–1855.
- Phillips, P.C.B. and Sul, D. (2009). Economic transition and growth. *Journal of Applied Econometrics*, 24(7), 1153–1185.
- von Lyncker, K. and Thoennessen, R. (2017). Regional club convergence in the EU: evidence from a panel data analysis. *Empirical Economics*, 52(2), 525–553.
- Sichera, R. and Pizzuto, P. (2019). ConvergenceClubs: A Package for Performing the Phillips and Sul's Club Convergence Clustering Procedure. *The R Journal*, 11(2), 142–151.
