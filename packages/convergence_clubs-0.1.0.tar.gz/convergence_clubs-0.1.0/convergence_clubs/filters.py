"""Time-series filters for preprocessing panel data."""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import sparse
from scipy.sparse.linalg import spsolve


def hp_filter(
    y: np.ndarray | pd.Series,
    lamb: float = 400,
) -> tuple[np.ndarray, np.ndarray]:
    """Hodrick-Prescott filter.

    Decomposes a time series *y* into a trend and cyclical component by
    solving:

    .. math::

        \\min_{\\tau} \\sum_t (y_t - \\tau_t)^2
        + \\lambda \\sum_t [(\\tau_{t+1} - \\tau_t) - (\\tau_t - \\tau_{t-1})]^2

    Parameters
    ----------
    y : array-like
        1-D time series (length *T*).
    lamb : float
        Smoothing parameter (default 400, suitable for annual data following
        Phillips and Sul 2007).  Common values: 6.25 (annual, Ravn & Uhlig),
        1600 (quarterly), 129600 (monthly).

    Returns
    -------
    trend : np.ndarray
        Trend component.
    cycle : np.ndarray
        Cyclical component (``y - trend``).

    Examples
    --------
    >>> import numpy as np
    >>> y = np.array([1.0, 2.1, 3.0, 3.8, 5.1, 6.0, 6.9, 8.2])
    >>> trend, cycle = hp_filter(y, lamb=400)
    >>> trend.shape
    (8,)
    """
    y = np.asarray(y, dtype=float)
    T = len(y)
    if T < 3:
        raise ValueError("Need at least 3 observations for the HP filter")

    # Second-difference matrix K of shape (T-2, T)
    # K[i,:] has [1, -2, 1] at positions [i, i+1, i+2]
    e = np.ones(T)
    K = sparse.spdiags(
        [e, -2.0 * e, e],
        [0, 1, 2],
        T - 2,
        T,
    )

    # Solve (I + lambda * K'K) * trend = y
    I = sparse.eye(T, format="csc")
    A = I + lamb * K.T.dot(K)
    trend = spsolve(A.tocsc(), y)

    cycle = y - trend
    return trend, cycle


def hp_filter_panel(
    X: pd.DataFrame,
    data_cols: list[int] | range,
    lamb: float = 400,
    log_transform: bool = True,
) -> pd.DataFrame:
    """Apply the HP filter to each row (unit) of a panel DataFrame.

    This replicates the preprocessing used by Phillips and Sul (2007, 2009):
    ``log(GDP) → HP filter (lambda=400) → trend component``.

    Parameters
    ----------
    X : pd.DataFrame
        Panel data with units as rows, time periods as columns.
    data_cols : list[int] or range
        Column indices of the numeric time-series data.
    lamb : float
        HP smoothing parameter (default 400).
    log_transform : bool
        If *True* (default), apply ``log()`` before filtering, matching the
        standard Phillips & Sul preprocessing.

    Returns
    -------
    pd.DataFrame
        Same structure as *X*, with data columns replaced by trend values.
    """
    data_cols = list(data_cols)
    result = X.copy()
    values = X.iloc[:, data_cols].values.astype(float)

    if log_transform:
        values = np.log(values)

    for i in range(values.shape[0]):
        trend, _ = hp_filter(values[i], lamb=lamb)
        values[i] = trend

    result.iloc[:, data_cols] = values
    return result
