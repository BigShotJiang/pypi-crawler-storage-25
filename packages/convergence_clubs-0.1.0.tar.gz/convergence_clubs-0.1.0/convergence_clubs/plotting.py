"""Plotting utilities for convergence club transition paths."""

from __future__ import annotations

import math

import numpy as np

from .core import ConvergenceClubs
from .compute_h import compute_h


def plot_clubs(
    clubs: ConvergenceClubs,
    club_indices: list[int] | None = None,
    avg_tp: bool = True,
    avg_tp_clubs: list[int] | None = None,
    y_fixed: bool = False,
    legend: bool = False,
    nrows: int | None = None,
    ncols: int | None = None,
    figsize: tuple[float, float] = (20, 15),
    savefig: str | None = None,
    x_labels: list[str] | None = None,
):
    """Plot transition paths for convergence clubs.

    Parameters
    ----------
    clubs : ConvergenceClubs
        Result object.
    club_indices : list[int], optional
        1-based club numbers to plot.  *None* plots all clubs.
    avg_tp : bool
        If *True* (default), add a panel with average transition paths.
    avg_tp_clubs : list[int], optional
        1-based club numbers for the average panel.  Defaults to all.
    y_fixed : bool
        Use the same y-axis range for all panels.
    legend : bool
        Show legend with unit names / ids.
    nrows, ncols : int, optional
        Grid layout dimensions.
    figsize : tuple[float, float]
        Figure size in inches ``(width, height)``.
    savefig : str, optional
        If given, save figure to this path.  Format is inferred from the
        file extension (e.g. ``"plot.pdf"``, ``"plot.png"``).
    x_labels : list[str], optional
        Custom x-axis tick labels (one per time period).

    Returns
    -------
    matplotlib.figure.Figure
        The figure object, for further customisation.
    """
    import matplotlib.pyplot as plt

    num_clubs = clubs.n_clubs
    data = clubs.data.iloc[:, clubs.data_cols].values
    h = compute_h(data, quantity="h")

    if club_indices is None:
        club_indices = list(range(1, num_clubs + 1))
    if avg_tp_clubs is None:
        avg_tp_clubs = list(range(1, num_clubs + 1))

    nplots = len(club_indices) + int(avg_tp)
    if nplots == 0:
        raise ValueError("Nothing to plot")

    # Grid layout
    if nrows is not None and ncols is not None:
        pass
    elif nrows is not None:
        ncols = math.ceil(nplots / nrows)
    elif ncols is not None:
        nrows = math.ceil(nplots / ncols)
    else:
        ncols = math.ceil(math.sqrt(nplots))
        nrows = math.ceil(nplots / ncols)

    fig, axes = plt.subplots(nrows, ncols, figsize=figsize, squeeze=False)
    axes_flat = axes.flatten()

    has_names = clubs.unit_names_col is not None
    time_axis = np.arange(1, data.shape[1] + 1)
    if x_labels is None:
        x_labels = [str(c) for c in clubs.data.columns[clubs.data_cols]]

    ylim = (h.min() - 0.1, h.max() + 0.1) if y_fixed else None

    # Tick spacing
    n_ticks = min(10, len(time_axis))
    tick_step = max(1, len(time_axis) // n_ticks)
    tick_pos = time_axis[::tick_step]
    tick_labs = [x_labels[i] for i in range(0, len(x_labels), tick_step)]

    def _setup_ax(ax: plt.Axes, title: str) -> None:
        ax.axhline(y=1, color="black", linewidth=1)
        ax.set_title(title)
        ax.set_xlabel("Time")
        ax.set_ylabel("Relative transition path")
        if ylim:
            ax.set_ylim(ylim)
        ax.set_xticks(tick_pos)
        ax.set_xticklabels(tick_labs, rotation=45, ha="right", fontsize=8)

    plot_idx = 0

    # Individual club panels
    for ci in club_indices:
        if plot_idx >= len(axes_flat):
            break
        ax = axes_flat[plot_idx]
        club = clubs.clubs[ci - 1]
        club_h = h[club.id]

        for row_idx in range(club_h.shape[0]):
            label = None
            if legend:
                if has_names and club.unit_names:
                    label = club.unit_names[row_idx][:15]
                else:
                    label = str(club.id[row_idx])
            ax.plot(time_axis, club_h[row_idx], label=label)

        _setup_ax(ax, f"Club {ci}")
        if legend:
            ax.legend(fontsize=7, loc="best", ncol=max(1, len(club.id) // 20))
        plot_idx += 1

    # Average transition paths panel
    if avg_tp and plot_idx < len(axes_flat):
        ax = axes_flat[plot_idx]
        for ci in avg_tp_clubs:
            club = clubs.clubs[ci - 1]
            ax.plot(time_axis, h[club.id].mean(axis=0), label=f"Club {ci}")

        _setup_ax(ax, "Average transition paths — All clubs")
        if legend:
            ax.legend(fontsize=8, loc="best")
        plot_idx += 1

    # Hide unused panels
    for idx in range(plot_idx, len(axes_flat)):
        axes_flat[idx].set_visible(False)

    fig.tight_layout()

    if savefig:
        fig.savefig(savefig, dpi=300, bbox_inches="tight")

    return fig
