"""Compute cross-sectional variance H(t) and transition paths h(it)."""

from __future__ import annotations

import numpy as np


def compute_h(
    X: np.ndarray,
    quantity: str = "H",
    id: np.ndarray | list[int] | None = None,
) -> np.ndarray | dict[str, np.ndarray]:
    """Compute H values (cross-sectional variance) and/or transition paths.

    Parameters
    ----------
    X : np.ndarray
        2-D array of shape ``(N, T)`` with numeric panel data.
    quantity : str
        ``"H"`` returns the cross-sectional variance vector (length *T*),
        ``"h"`` returns the transition-path matrix (*N* x *T*),
        ``"both"`` returns a dict ``{"h": ..., "H": ...}``.
    id : array-like, optional
        Row indices to select.  If *None*, all rows are used.

    Returns
    -------
    np.ndarray or dict
    """
    if quantity not in ("h", "H", "both"):
        raise ValueError("quantity must be one of 'h', 'H', 'both'")

    xx = X if id is None else X[id]

    # h(it) = x(it) / mean_i(x(it))  — column-wise
    h = xx / xx.mean(axis=0)

    if quantity == "h":
        return h

    H = np.mean((h - 1) ** 2, axis=0)

    if quantity == "H":
        return H

    return {"h": h, "H": H}
