"""Main clustering procedure: find convergence clubs."""

from __future__ import annotations

import numpy as np
import pandas as pd

from .core import Club, ConvergenceClubs
from .compute_h import compute_h
from .estimate import estimate_mod
from ._club import core_group, sieve_club


def find_clubs(
    X: pd.DataFrame,
    data_cols: list[int] | range,
    unit_names: int | None = None,
    ref_col: int | None = None,
    time_trim: float = 1 / 3,
    hac_method: str = "FQSB",
    cstar: float = 0,
    cstar_method: str = "fixed",
    cstar_increment: float = 0.1,
    cstar_cap: float = 3.0,
) -> ConvergenceClubs:
    """Find convergence clubs using the Phillips and Sul (2007, 2009) procedure.

    Parameters
    ----------
    X : pd.DataFrame
        Panel data — rows are units, columns include time periods and
        optionally a unit-name column.
    data_cols : list[int] or range
        Column indices (0-based) containing the numeric time-series data.
    unit_names : int, optional
        Column index of a column with unit identifiers.
    ref_col : int, optional
        Column index used for ordering (typically the last data column).
        If *None*, defaults to the last element of *data_cols*.
    time_trim : float
        Fraction of initial periods to discard (default 1/3).
    hac_method : str
        ``"FQSB"`` or ``"AQSB"``.
    cstar : float
        Sieve threshold c* (default 0).
    cstar_method : str
        ``"fixed"`` or ``"incremental"``.
    cstar_increment : float
        Step size when incrementing c* (default 0.1).
    cstar_cap : float
        Maximum c* value (default 3).

    Returns
    -------
    ConvergenceClubs
    """
    # --- Input validation -----------------------------------------------------
    data_cols = list(data_cols)
    if not isinstance(X, pd.DataFrame):
        raise TypeError("X must be a pandas DataFrame")

    t = len(data_cols)
    if t < 2:
        raise ValueError("At least two time periods are needed")

    if not all(np.issubdtype(X.iloc[:, c].dtype, np.number) for c in data_cols):
        raise ValueError("Some of the data columns are non-numeric")

    if not 0 < time_trim < 1:
        raise ValueError("time_trim must be between 0 and 1 (exclusive)")
    if (t - round(t * time_trim)) < 2:
        raise ValueError(
            "Either the number of time periods is too small or time_trim is too high"
        )

    if ref_col is None:
        ref_col = data_cols[-1]

    if hac_method not in ("FQSB", "AQSB"):
        raise ValueError("hac_method must be 'FQSB' or 'AQSB'")
    if cstar_method not in ("fixed", "incremental"):
        raise ValueError("cstar_method must be 'fixed' or 'incremental'")

    N = len(X)
    threshold = -1.65
    return_names = unit_names is not None

    # --- Sort by reference column (descending) --------------------------------
    sorted_idx = X.iloc[:, ref_col].values.argsort()[::-1]
    data_sorted = X.iloc[:, data_cols].values[sorted_idx]  # (N, t)
    orig_ids = np.arange(N)[sorted_idx]  # maps sorted-row → original-row

    if return_names:
        all_unit_names = X.iloc[:, unit_names].astype(str).values

    # --- Clustering loop ------------------------------------------------------
    clubs: list[Club] = []
    divergent: dict | None = None
    remaining_mask = np.ones(data_sorted.shape[0], dtype=bool)

    while True:
        current_rows = np.where(remaining_mask)[0]
        n_remaining = len(current_rows)

        if n_remaining == 0:
            break
        if n_remaining == 1:
            divergent = {"id": orig_ids[current_rows].tolist()}
            if return_names:
                divergent["unit_names"] = all_unit_names[
                    orig_ids[current_rows]
                ].tolist()
            break

        cur_data = data_sorted[current_rows]
        cur_orig_ids = orig_ids[current_rows]

        # Test whether ALL remaining units converge
        H_all = compute_h(cur_data, quantity="H")
        mod_all = estimate_mod(H_all, time_trim, hac_method)
        if mod_all["tvalue"] > threshold:
            club = Club(
                id=cur_orig_ids.tolist(),
                model=mod_all,
                cstar=cstar,
            )
            if return_names:
                club.unit_names = all_unit_names[cur_orig_ids].tolist()
            clubs.append(club)
            break

        # Step 2: core group
        cg = core_group(cur_data, time_trim, threshold, hac_method, type_="max")
        if cg is None:
            divergent = {"id": cur_orig_ids.tolist()}
            if return_names:
                divergent["unit_names"] = all_unit_names[cur_orig_ids].tolist()
            break

        # Step 3: sieve
        result = sieve_club(
            cur_data, cur_orig_ids, cg, time_trim, hac_method,
            cstar, cstar_method, cstar_increment, cstar_cap,
        )

        club = Club(
            id=result["id"],
            model=result["model"],
            cstar=result["cstar"],
        )
        if return_names:
            club.unit_names = all_unit_names[np.array(result["id"])].tolist()
        clubs.append(club)

        # Remove club members from remaining pool
        for row in result["rows"]:
            remaining_mask[current_rows[row]] = False

    # --- Build result ---------------------------------------------------------
    return ConvergenceClubs(
        clubs=clubs,
        divergent=divergent,
        data=X,
        data_cols=data_cols,
        unit_names_col=unit_names,
        ref_col=ref_col,
        time_trim=time_trim,
        hac_method=hac_method,
        cstar=cstar,
        cstar_method=cstar_method,
        cstar_increment=cstar_increment,
    )
