"""Reclassify divergent units into clubs (von Lyncker & Thoennessen 2017)."""

from __future__ import annotations

import copy

import numpy as np

from .core import ConvergenceClubs
from .compute_h import compute_h
from .estimate import estimate_mod


def merge_divergent(
    clubs: ConvergenceClubs,
    time_trim: float | None = None,
    estar: float = -1.65,
) -> ConvergenceClubs:
    """Attempt to reclassify divergent units into existing clubs.

    For each divergent unit, the log-t test is run against each club.
    The unit is merged into the club yielding the highest t-value above
    *estar*.  The process repeats until no unit can be reclassified.

    Parameters
    ----------
    clubs : ConvergenceClubs
        Result from :func:`find_clubs` or :func:`merge_clubs`.
    time_trim : float, optional
        Override for time trimming; defaults to the value stored in *clubs*.
    estar : float
        Threshold for inclusion (default -1.65).

    Returns
    -------
    ConvergenceClubs
    """
    result = copy.deepcopy(clubs)

    if result.divergent is None or not result.divergent.get("id"):
        return result

    data = result.data
    data_cols = result.data_cols
    hac_method = result.hac_method
    if time_trim is None:
        time_trim = result.time_trim

    X = data.iloc[:, data_cols].values
    return_names = result.unit_names_col is not None

    cn = len(result.clubs)
    dunits = list(result.divergent["id"])
    dnames = list(result.divergent.get("unit_names", [])) if return_names else []

    while len(dunits) > 0:
        # Build t-value matrix: (n_clubs x n_divergent)
        tmatrix = np.zeros((cn, len(dunits)))
        for i in range(cn):
            for j, dunit in enumerate(dunits):
                ids = result.clubs[i].id + [dunit]
                H = compute_h(X[ids], quantity="H")
                tmatrix[i, j] = estimate_mod(H, time_trim, hac_method)["tvalue"]

        if tmatrix.max() > estar:
            max_idx = np.unravel_index(tmatrix.argmax(), tmatrix.shape)
            club_idx = max_idx[0]
            div_idx = max_idx[1]

            # Merge the divergent unit into the club
            merged_ids = result.clubs[club_idx].id + [dunits[div_idx]]
            H = compute_h(X[merged_ids], quantity="H")
            mod = estimate_mod(H, time_trim, hac_method)

            result.clubs[club_idx].id = merged_ids
            result.clubs[club_idx].model = mod

            if return_names and dnames:
                if result.clubs[club_idx].unit_names is None:
                    result.clubs[club_idx].unit_names = []
                result.clubs[club_idx].unit_names.append(dnames[div_idx])

                if result.clubs[club_idx].message is None:
                    result.clubs[club_idx].message = []
                result.clubs[club_idx].message.append(
                    f"merged with divergent region {dnames[div_idx]} "
                    f"(id={dunits[div_idx]})"
                )
                dnames.pop(div_idx)
            else:
                if result.clubs[club_idx].message is None:
                    result.clubs[club_idx].message = []
                result.clubs[club_idx].message.append(
                    f"merged with divergent region id={dunits[div_idx]}"
                )

            dunits.pop(div_idx)
            result.divergent["id"] = dunits
            if return_names:
                result.divergent["unit_names"] = dnames
        else:
            break

    return result
