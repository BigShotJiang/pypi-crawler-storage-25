"""Internal helpers for club detection (Steps 2 and 3 of the algorithm)."""

from __future__ import annotations

import numpy as np

from .compute_h import compute_h
from .estimate import estimate_mod


# ---------------------------------------------------------------------------
# Step 2 — Core (primary) group formation
# ---------------------------------------------------------------------------

def core_group(
    X: np.ndarray,
    time_trim: float,
    threshold: float = -1.65,
    hac_method: str = "FQSB",
    type_: str = "max",
) -> list[int] | None:
    """Find the core (primary) group.

    Parameters
    ----------
    X : np.ndarray
        2-D data array ``(N, T)`` already sorted by reference column.
    time_trim : float
        Fraction of initial time periods to trim.
    threshold : float
        Convergence threshold (default -1.65).
    hac_method : str
        HAC method for the log-t regression.
    type_ : str
        ``"max"`` returns the group whose |t-value| is maximal (default);
        ``"all"`` returns the largest group that still passes.

    Returns
    -------
    list[int] | None
        Row indices (into *X*) of units in the core group, or *None* if
        no core group can be formed.
    """
    nr = X.shape[0]

    # --- Find first valid pair ------------------------------------------------
    first_pair_start = None
    first_pair_tvalue = None

    i = 1
    while i < nr:
        H = compute_h(X[[i - 1, i]], quantity="H")
        tv = estimate_mod(H, time_trim, hac_method)["tvalue"]
        if tv > threshold:
            first_pair_start = i - 1
            first_pair_tvalue = tv
            if i == nr - 1:
                # last possible pair — return immediately
                return [i - 1, i]
            break
        i += 1
    else:
        return None  # no valid pair found

    # --- Extend core group sequentially --------------------------------------
    units = [first_pair_start, first_pair_start + 1]
    groups: list[list[int]] = [list(units)]
    tvalues: list[float] = [first_pair_tvalue]

    k = first_pair_start + 2
    while k < nr:
        units_candidate = units + [k]
        H = compute_h(X[units_candidate], quantity="H")
        tv = estimate_mod(H, time_trim, hac_method)["tvalue"]
        if tv > threshold:
            units = units_candidate
            groups.append(list(units))
            tvalues.append(tv)
            k += 1
        else:
            break

    # --- Return ---------------------------------------------------------------
    if type_ == "max":
        best = int(np.argmax(np.abs(tvalues)))
        return groups[best]
    elif type_ == "all":
        return groups[-1]
    else:
        raise ValueError("type_ must be 'max' or 'all'")


# ---------------------------------------------------------------------------
# Step 3 — Sieve: enlarge core with additional members
# ---------------------------------------------------------------------------

def sieve_club(
    X: np.ndarray,
    orig_ids: np.ndarray,
    core: list[int],
    time_trim: float,
    hac_method: str = "FQSB",
    cstar: float = 0,
    cstar_method: str = "fixed",
    cstar_increment: float = 0.1,
    cstar_cap: float = 3,
) -> dict:
    """Enlarge the core group by sieving remaining units.

    Parameters
    ----------
    X : np.ndarray
        2-D data array ``(N, T)``.
    orig_ids : np.ndarray
        Original row indices (into the full dataset) for each row of *X*.
    core : list[int]
        Row indices (into *X*) of the core group.
    time_trim, hac_method, cstar, cstar_method, cstar_increment, cstar_cap
        Algorithm parameters (see ``find_clubs``).

    Returns
    -------
    dict
        ``id`` — original row indices of club members,
        ``rows`` — row indices in *X*,
        ``model`` — regression results dict,
        ``cstar`` — final c* used.
    """
    non_core = [r for r in range(X.shape[0]) if r not in core]

    if cstar_increment <= 0:
        cstar_method = "fixed"

    while True:
        # Test each non-core unit individually with the core group
        tvalues = np.empty(len(non_core))
        for k, row in enumerate(non_core):
            rows = core + [row]
            H = compute_h(X[rows], quantity="H")
            tvalues[k] = estimate_mod(H, time_trim, hac_method)["tvalue"]

        # Units passing the sieve
        passing = [non_core[k] for k in range(len(non_core)) if tvalues[k] > cstar]

        club_rows = core + passing
        club_ids = orig_ids[club_rows].tolist()

        # Validate the full enlarged club
        H = compute_h(X[club_rows], quantity="H")
        mod = estimate_mod(H, time_trim, hac_method)

        if mod["tvalue"] > -1.65 or cstar_method == "fixed":
            break
        else:
            if cstar <= cstar_cap:
                cstar += cstar_increment
            else:
                # fallback: return only core
                club_rows = list(core)
                club_ids = orig_ids[club_rows].tolist()
                H = compute_h(X[club_rows], quantity="H")
                mod = estimate_mod(H, time_trim, hac_method)
                break

    return {
        "id": club_ids,
        "rows": club_rows,
        "model": mod,
        "cstar": cstar,
    }
