"""Core data structures for convergence club results."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import pandas as pd


@dataclass
class Club:
    """A single convergence club."""

    id: list[int] = field(default_factory=list)
    model: dict[str, float] = field(default_factory=dict)
    cstar: float | None = None
    unit_names: list[str] | None = None
    clubs: list[str] | None = None  # names of merged clubs (after merging)
    message: list[str] | None = None  # merge messages


class ConvergenceClubs:
    """Container for convergence club analysis results.

    Replaces R's S3 ``convergence.clubs`` object.  Stores the list of detected
    clubs, any divergent units, and all metadata needed by downstream functions
    (``merge_clubs``, ``merge_divergent``, ``transition_paths``, ``plot``).
    """

    def __init__(
        self,
        clubs: list[Club] | None = None,
        divergent: dict[str, Any] | None = None,
        *,
        data: pd.DataFrame | None = None,
        data_cols: list[int] | None = None,
        unit_names_col: int | None = None,
        ref_col: int | None = None,
        time_trim: float = 1 / 3,
        hac_method: str = "FQSB",
        cstar: float = 0,
        cstar_method: str = "fixed",
        cstar_increment: float = 0.1,
    ):
        self.clubs: list[Club] = clubs or []
        self.divergent: dict[str, Any] | None = divergent
        # metadata
        self.data = data
        self.data_cols = data_cols
        self.unit_names_col = unit_names_col
        self.ref_col = ref_col
        self.time_trim = time_trim
        self.hac_method = hac_method
        self.cstar = cstar
        self.cstar_method = cstar_method
        self.cstar_increment = cstar_increment

    # ------------------------------------------------------------------
    # Access helpers
    # ------------------------------------------------------------------

    @property
    def n_clubs(self) -> int:
        return len(self.clubs)

    @property
    def n_divergent(self) -> int:
        if self.divergent is None:
            return 0
        return len(self.divergent.get("id", []))

    @property
    def dim(self) -> tuple[int, int]:
        """Return ``(n_clubs, n_divergent)``."""
        return (self.n_clubs, self.n_divergent)

    def __len__(self) -> int:
        return self.n_clubs

    # ------------------------------------------------------------------
    # Display
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return (
            f"ConvergenceClubs(n_clubs={self.n_clubs}, "
            f"n_divergent={self.n_divergent})"
        )

    def summary(self) -> pd.DataFrame:
        """Print and return a summary table (like R's ``summary.convergence.clubs``)."""
        rows = []
        merged = self.clubs and self.clubs[0].clubs is not None
        for i, club in enumerate(self.clubs):
            row: dict[str, Any] = {}
            if merged and club.clubs is not None:
                row["merged_clubs"] = " + ".join(club.clubs)
            row["n_units"] = len(club.id)
            row["beta"] = round(club.model.get("beta", float("nan")), 3)
            row["std_err"] = round(club.model.get("std_err", float("nan")), 3)
            row["tvalue"] = round(club.model.get("tvalue", float("nan")), 3)
            if not merged:
                row["cstar"] = round(club.cstar, 3) if club.cstar is not None else None
            rows.append(row)

        idx = [f"club{i + 1}" for i in range(len(self.clubs))]
        df = pd.DataFrame(rows, index=idx)

        print(f"Number of convergence clubs: {self.n_clubs}")
        print(f"Number of divergent units: {self.n_divergent}")
        print()
        print(df.to_string())
        return df

    def print_detail(self) -> None:
        """Verbose output (like R's ``print.convergence.clubs``)."""
        has_names = self.unit_names_col is not None
        width = 72

        for i, club in enumerate(self.clubs):
            print("=" * width)
            print(f"club {i + 1}")
            print("-" * width)
            labels = club.unit_names if has_names and club.unit_names else [str(x) for x in club.id]
            print(", ".join(labels))
            print()
            m = club.model
            print(f"beta:     {m.get('beta', float('nan')): .4f}")
            print(f"std.err:  {m.get('std_err', float('nan')): .4f}")
            print(f"tvalue:   {m.get('tvalue', float('nan')): .4f}")
            print(f"pvalue:   {m.get('pvalue', float('nan')): .4f}")
            if club.cstar is not None:
                print(f"cstar:    {club.cstar: .4f}")
            print()

        if self.divergent and self.divergent.get("id"):
            print("=" * width)
            print("divergent")
            print("-" * width)
            if has_names and self.divergent.get("unit_names"):
                print(", ".join(self.divergent["unit_names"]))
            else:
                print(", ".join(str(x) for x in self.divergent["id"]))
