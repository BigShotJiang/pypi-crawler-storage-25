"""Extract transition paths from convergence club results."""

from __future__ import annotations

import pandas as pd

from .core import ConvergenceClubs
from .compute_h import compute_h


def transition_paths(
    clubs: ConvergenceClubs,
    include_unit_names: bool = True,
    output_type: str = "list",
) -> list[pd.DataFrame] | pd.DataFrame:
    """Extract transition paths (relative *h* values) for each club.

    Parameters
    ----------
    clubs : ConvergenceClubs
        Result from :func:`find_clubs` or :func:`merge_clubs`.
    include_unit_names : bool
        If *True* (default) and unit names are available, add a
        ``unit_name`` column.
    output_type : str
        ``"list"`` returns a list of DataFrames (one per club),
        ``"data.frame"`` returns a single concatenated DataFrame with a
        ``club`` column.

    Returns
    -------
    list[pd.DataFrame] or pd.DataFrame
    """
    if output_type not in ("list", "data.frame"):
        raise ValueError("output_type must be 'list' or 'data.frame'")

    data = clubs.data.iloc[:, clubs.data_cols].values
    h = compute_h(data, quantity="h")

    col_names = [str(c) for c in clubs.data.columns[clubs.data_cols]]
    has_names = include_unit_names and clubs.unit_names_col is not None
    if has_names:
        all_names = clubs.data.iloc[:, clubs.unit_names_col].astype(str).values

    frames: list[pd.DataFrame] = []
    labels: list[str] = []

    items = list(enumerate(clubs.clubs))
    if clubs.divergent and clubs.divergent.get("id"):
        items.append((-1, None))  # sentinel for divergent

    for idx, club_obj in items:
        if idx == -1:
            ids = clubs.divergent["id"]
            name = "divergent"
        else:
            ids = club_obj.id
            name = f"club{idx + 1}"

        df = pd.DataFrame(h[ids], columns=col_names)
        if has_names:
            df.insert(0, "unit_name", all_names[ids])
        if output_type == "data.frame":
            df.insert(0, "club", name)

        frames.append(df)
        labels.append(name)

    if output_type == "list":
        return dict(zip(labels, frames))
    else:
        return pd.concat(frames, ignore_index=True)
