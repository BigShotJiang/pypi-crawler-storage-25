"""Club merging algorithms (Phillips & Sul 2009; von Lyncker & Thoennessen 2017)."""

from __future__ import annotations

import copy

from .core import Club, ConvergenceClubs
from .compute_h import compute_h
from .estimate import estimate_mod
from .merge_divergent import merge_divergent


def merge_clubs(
    clubs: ConvergenceClubs,
    time_trim: float | None = None,
    merge_method: str = "PS",
    threshold: float = -1.65,
    merge_divergent_flag: bool = False,
    estar: float = -1.65,
) -> ConvergenceClubs:
    """Merge adjacent convergence clubs.

    Parameters
    ----------
    clubs : ConvergenceClubs
        Result from :func:`find_clubs`.
    time_trim : float, optional
        Override for time trimming; defaults to the value stored in *clubs*.
    merge_method : str
        ``"PS"`` (Phillips & Sul 2009) or ``"vLT"`` (von Lyncker & Thoennessen 2017).
    threshold : float
        t-statistic threshold (default -1.65).
    merge_divergent_flag : bool
        If *True*, also attempt to reclassify divergent units after merging.
    estar : float
        Threshold for divergent-unit reclassification.

    Returns
    -------
    ConvergenceClubs
    """
    if merge_method not in ("PS", "vLT"):
        raise ValueError("merge_method must be 'PS' or 'vLT'")

    if clubs.n_clubs < 2:
        return clubs

    data = clubs.data
    data_cols = clubs.data_cols
    hac_method = clubs.hac_method
    if time_trim is None:
        time_trim = clubs.time_trim

    X = data.iloc[:, data_cols].values  # full numeric panel
    return_names = clubs.unit_names_col is not None

    ll = clubs.n_clubs
    src = clubs.clubs  # source club list
    club_names = [f"club{i + 1}" for i in range(ll)]

    merged: list[Club] = []

    # Use 1-based indexing internally to match R logic exactly
    # R: i starts at 1, for(k in (i+1):ll), while(i<ll)
    i = 1  # 1-based
    while i < ll:
        units = list(src[i - 1].id)
        cnm = [club_names[i - 1]]
        unit_names_acc = list(src[i - 1].unit_names) if return_names and src[i - 1].unit_names else []
        append_last = False

        for k in range(i + 1, ll + 1):  # k from i+1 to ll inclusive (1-based)
            add_units = src[k - 1].id
            add_names = src[k - 1].unit_names if return_names and src[k - 1].unit_names else []

            H = compute_h(X[units + list(add_units)], quantity="H")
            mod = estimate_mod(H, time_trim, hac_method)
            tv = mod["tvalue"]

            if tv > threshold:
                if merge_method == "vLT" and k <= ll - 1:
                    # von Lyncker & Thoennessen: also check next pair
                    next_pair = list(src[k - 1].id) + list(src[k].id)
                    H2 = compute_h(X[next_pair], quantity="H")
                    mod2 = estimate_mod(H2, time_trim, hac_method)
                    tv2 = mod2["tvalue"]
                    if tv > tv2:
                        units = units + list(add_units)
                        if return_names:
                            unit_names_acc = unit_names_acc + list(add_names)
                        cnm.append(club_names[k - 1])
                    else:
                        break
                else:
                    # PS method (or last pair for vLT)
                    units = units + list(add_units)
                    if return_names:
                        unit_names_acc = unit_names_acc + list(add_names)
                    cnm.append(club_names[k - 1])
            else:
                if k == ll:
                    append_last = True
                break

        # Store merged club
        H = compute_h(X[units], quantity="H")
        mod = estimate_mod(H, time_trim, hac_method)
        new_club = Club(id=units, model=mod, clubs=cnm)
        if return_names:
            new_club.unit_names = unit_names_acc
        merged.append(new_club)

        if append_last:
            last = src[ll - 1]
            lc = Club(
                id=list(last.id),
                model=dict(last.model),
                clubs=[club_names[ll - 1]],
            )
            if return_names and last.unit_names:
                lc.unit_names = list(last.unit_names)
            merged.append(lc)

        i = k  # k is 1-based, so i<ll check works correctly

    # Build result
    result = ConvergenceClubs(
        clubs=merged,
        divergent=copy.deepcopy(clubs.divergent),
        data=data,
        data_cols=data_cols,
        unit_names_col=clubs.unit_names_col,
        ref_col=clubs.ref_col,
        time_trim=time_trim,
        hac_method=hac_method,
        cstar=clubs.cstar,
        cstar_method=clubs.cstar_method,
        cstar_increment=clubs.cstar_increment,
    )

    if merge_divergent_flag:
        return merge_divergent(result, time_trim, estar)
    return result
