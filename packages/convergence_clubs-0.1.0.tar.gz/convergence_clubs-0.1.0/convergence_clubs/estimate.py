"""Log-t regression and HAC variance estimation."""

from __future__ import annotations

import numpy as np
from scipy.stats import norm


# ---------------------------------------------------------------------------
# Fixed-bandwidth Andrews HAC  (Quadratic Spectral kernel)
# ---------------------------------------------------------------------------

def ps_andrews_hac(x: np.ndarray) -> float:
    """Long-run variance via Andrews' method with QS kernel and fixed bandwidth.

    Adapted from Phillips and Sul (2007) GAUSS code.

    Parameters
    ----------
    x : np.ndarray
        1-D vector of OLS residuals.

    Returns
    -------
    float
        Scalar HAC variance estimate.
    """
    t = len(x)
    x1 = x[: t - 1]
    x2 = x[1: t]

    b1 = np.sum(x1 * x2) / np.sum(x1 ** 2)

    # alpha parameter
    a = (4.0 * b1 ** 2) / (1.0 - b1) ** 4

    # fixed bandwidth
    B = 1.3221 * (a * t) ** 0.2

    lags = np.arange(1, t)
    z = 1.2 * np.pi * lags / B

    # Quadratic Spectral kernel weights
    k = (np.sin(z) / z - np.cos(z)) * (3.0 / z ** 2)

    # HAC covariance estimate
    t2 = t - 1
    out = 0.0
    for i in range(1, t2):
        val = float(x[: t2 - i] @ x[i: t2]) * k[i - 1] / t2
        out += val + val  # symmetric: o + o'

    # R: s <- t(x) %*% x / t2  — uses all of x (length t), divides by t2=t-1
    s = float(x @ x) / t2
    out = out + s

    return out


# ---------------------------------------------------------------------------
# Log-t regression
# ---------------------------------------------------------------------------

def estimate_mod(
    H: np.ndarray,
    time_trim: float = 1 / 3,
    hac_method: str = "FQSB",
) -> dict[str, float]:
    """Estimate the log-t regression model (Phillips and Sul 2007, 2009).

    .. math::

        \\log\\frac{H_1}{H_t} - 2\\log(\\log t) = \\alpha + \\beta \\log t + u_t

    Parameters
    ----------
    H : np.ndarray
        1-D vector of cross-sectional variance values.
    time_trim : float
        Fraction of initial time periods to discard (default 1/3).
    hac_method : str
        ``"FQSB"`` for fixed QS bandwidth (default), ``"AQSB"`` for adaptive.

    Returns
    -------
    dict
        Keys: ``beta``, ``std_err``, ``tvalue``, ``pvalue``.
    """
    if hac_method not in ("FQSB", "AQSB"):
        raise ValueError("hac_method must be 'FQSB' or 'AQSB'")

    nT = len(H)
    # rT are 1-based time indices after trimming (matching R's seq(...))
    rT = np.arange(round(nT * time_trim) + 1, nT + 1, dtype=float)
    logt = np.log(rT)

    # Dependent variable
    # H is 0-indexed; rT is 1-based, so H[rT-1] maps to H[rT] in R (1-based)
    rT_idx = (rT - 1).astype(int)
    rH = np.log(H[0] / H[rT_idx]) - 2.0 * np.log(logt)

    if hac_method == "FQSB":
        # OLS: rH = alpha + beta * logt + u
        n = len(logt)
        X_mat = np.column_stack([np.ones(n), logt])
        coeffs = np.linalg.lstsq(X_mat, rH, rcond=None)[0]
        beta = coeffs[1]

        residuals = rH - X_mat @ coeffs

        hac = ps_andrews_hac(residuals)

        # SE = sqrt( diag(inv(X'X)) * hac )[1]  (index 1 = slope)
        XtX_inv_diag = np.diag(np.linalg.inv(X_mat.T @ X_mat))
        se = np.sqrt(XtX_inv_diag[1] * hac)

        tv = beta / se
        pv = float(norm.cdf(tv))

        return {"beta": float(beta), "std_err": float(se),
                "tvalue": float(tv), "pvalue": pv}

    else:  # AQSB
        import statsmodels.api as sm
        from statsmodels.stats.sandwich_covariance import cov_hac

        X_mat = sm.add_constant(logt)
        ols_result = sm.OLS(rH, X_mat).fit()

        hac_cov = cov_hac(ols_result)
        beta = ols_result.params[1]
        se = np.sqrt(hac_cov[1, 1])
        tv = beta / se
        pv = float(norm.cdf(tv))

        return {"beta": float(beta), "std_err": float(se),
                "tvalue": float(tv), "pvalue": pv}
