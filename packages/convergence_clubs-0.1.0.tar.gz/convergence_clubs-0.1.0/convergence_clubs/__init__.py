"""ConvergenceClubs — Phillips and Sul (2007, 2009) convergence club clustering.

A Python implementation of the R ``ConvergenceClubs`` package by
Roberto Sichera and Pietro Pizzuto.
"""

from .core import Club, ConvergenceClubs
from .find_clubs import find_clubs
from .merge_clubs import merge_clubs
from .merge_divergent import merge_divergent
from .estimate import estimate_mod, ps_andrews_hac
from .compute_h import compute_h
from .transition_paths import transition_paths
from .plotting import plot_clubs
from .filters import hp_filter, hp_filter_panel
from .data import load_gdp, load_filtered_gdp

__all__ = [
    "Club",
    "ConvergenceClubs",
    "find_clubs",
    "merge_clubs",
    "merge_divergent",
    "estimate_mod",
    "ps_andrews_hac",
    "compute_h",
    "transition_paths",
    "plot_clubs",
    "hp_filter",
    "hp_filter_panel",
    "load_gdp",
    "load_filtered_gdp",
]
