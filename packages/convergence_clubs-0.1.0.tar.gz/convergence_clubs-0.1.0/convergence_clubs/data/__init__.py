"""Bundled sample datasets."""

from __future__ import annotations

from pathlib import Path

import pandas as pd

_DATA_DIR = Path(__file__).parent


def load_gdp() -> pd.DataFrame:
    """Load the raw per-capita GDP dataset (152 countries, 1970-2003).

    Source: Phillips and Sul (2009).
    """
    return pd.read_csv(_DATA_DIR / "GDP.csv")


def load_filtered_gdp() -> pd.DataFrame:
    """Load the HP-filtered (log) GDP dataset (152 countries, 1970-2003).

    The data have been filtered with the Hodrick-Prescott filter
    (lambda = 400) to remove business-cycle fluctuations, as recommended
    by Phillips and Sul (2007, 2009).
    """
    return pd.read_csv(_DATA_DIR / "filteredGDP.csv")
