"""Tests for the convergence_clubs package."""

import numpy as np
import pandas as pd
import pytest

import sys
from pathlib import Path

# Ensure the package is importable
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from convergence_clubs import (
    compute_h,
    estimate_mod,
    ps_andrews_hac,
    find_clubs,
    merge_clubs,
    merge_divergent,
    transition_paths,
    hp_filter,
    hp_filter_panel,
    load_filtered_gdp,
    load_gdp,
)
from convergence_clubs.core import Club, ConvergenceClubs


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

class TestDataLoading:
    def test_load_gdp(self):
        df = load_gdp()
        assert isinstance(df, pd.DataFrame)
        assert df.shape == (152, 35)
        assert df.columns[0] == "Countries"

    def test_load_filtered_gdp(self):
        df = load_filtered_gdp()
        assert isinstance(df, pd.DataFrame)
        assert df.shape == (152, 35)
        assert df.columns[0] == "Countries"


# ---------------------------------------------------------------------------
# compute_h
# ---------------------------------------------------------------------------

class TestComputeH:
    def test_h_shape(self):
        X = np.array([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0], [7.0, 8.0, 9.0]])
        h = compute_h(X, quantity="h")
        assert h.shape == (3, 3)

    def test_h_values(self):
        X = np.array([[2.0, 4.0], [4.0, 8.0]])
        h = compute_h(X, quantity="h")
        # Column means: [3, 6]; h = [[2/3, 4/6], [4/3, 8/6]]
        np.testing.assert_allclose(h[0], [2 / 3, 2 / 3])
        np.testing.assert_allclose(h[1], [4 / 3, 4 / 3])

    def test_H_converges_to_zero(self):
        # All identical rows → H = 0
        X = np.ones((5, 10))
        H = compute_h(X, quantity="H")
        np.testing.assert_allclose(H, 0.0)

    def test_both(self):
        X = np.random.rand(4, 6)
        result = compute_h(X, quantity="both")
        assert "h" in result and "H" in result
        assert result["h"].shape == (4, 6)
        assert result["H"].shape == (6,)

    def test_id_subset(self):
        X = np.arange(20).reshape(5, 4).astype(float)
        h = compute_h(X, quantity="h", id=[0, 2])
        assert h.shape == (2, 4)


# ---------------------------------------------------------------------------
# ps_andrews_hac
# ---------------------------------------------------------------------------

class TestAndrewsHAC:
    def test_positive(self):
        np.random.seed(42)
        x = np.random.randn(50)
        result = ps_andrews_hac(x)
        assert result > 0

    def test_deterministic(self):
        x = np.array([0.5, -0.3, 0.2, -0.1, 0.4, -0.2, 0.1, 0.3, -0.15, 0.25])
        r1 = ps_andrews_hac(x)
        r2 = ps_andrews_hac(x)
        assert r1 == r2


# ---------------------------------------------------------------------------
# estimate_mod
# ---------------------------------------------------------------------------

class TestEstimateMod:
    def test_returns_dict(self):
        # Use filtered GDP data for a realistic test
        df = load_filtered_gdp()
        X = df.iloc[:5, 1:].values
        H = compute_h(X, quantity="H")
        result = estimate_mod(H, time_trim=1 / 3, hac_method="FQSB")
        assert "beta" in result
        assert "std_err" in result
        assert "tvalue" in result
        assert "pvalue" in result

    def test_converging_series_positive_t(self):
        # Create clearly converging data (all rows converge to same value)
        np.random.seed(123)
        n, t = 10, 50
        base = np.linspace(1, 2, t)
        X = np.array([base + np.random.randn(t) * 0.01 * (1 / (i + 1))
                       for i in range(n)])
        H = compute_h(X, quantity="H")
        result = estimate_mod(H, time_trim=1 / 3)
        # For converging series, beta should be positive (or at least t > -1.65)
        assert result["tvalue"] > -1.65


# ---------------------------------------------------------------------------
# find_clubs — integration test
# ---------------------------------------------------------------------------

class TestFindClubs:
    @pytest.fixture
    def filtered_gdp(self):
        return load_filtered_gdp()

    def test_basic_clustering(self, filtered_gdp):
        clubs = find_clubs(
            filtered_gdp,
            data_cols=list(range(1, 35)),
            unit_names=0,
            ref_col=34,
            time_trim=1 / 3,
            hac_method="FQSB",
            cstar=0,
            cstar_method="fixed",
        )
        assert isinstance(clubs, ConvergenceClubs)
        assert clubs.n_clubs >= 1
        # All original units should be accounted for
        all_ids = []
        for c in clubs.clubs:
            all_ids.extend(c.id)
        if clubs.divergent:
            all_ids.extend(clubs.divergent["id"])
        assert sorted(all_ids) == list(range(152))

    def test_incremental_cstar(self, filtered_gdp):
        clubs = find_clubs(
            filtered_gdp,
            data_cols=list(range(1, 35)),
            unit_names=0,
            ref_col=34,
            time_trim=1 / 3,
            hac_method="FQSB",
            cstar=0,
            cstar_method="incremental",
            cstar_increment=0.1,
        )
        assert clubs.n_clubs >= 1

    def test_unit_names_preserved(self, filtered_gdp):
        clubs = find_clubs(
            filtered_gdp,
            data_cols=list(range(1, 35)),
            unit_names=0,
            ref_col=34,
            time_trim=1 / 3,
        )
        for c in clubs.clubs:
            assert c.unit_names is not None
            assert len(c.unit_names) == len(c.id)


# ---------------------------------------------------------------------------
# merge_clubs
# ---------------------------------------------------------------------------

class TestMergeClubs:
    @pytest.fixture
    def base_clubs(self):
        df = load_filtered_gdp()
        return find_clubs(
            df,
            data_cols=list(range(1, 35)),
            unit_names=0,
            ref_col=34,
            time_trim=1 / 3,
            cstar=0,
        )

    def test_merge_ps(self, base_clubs):
        merged = merge_clubs(base_clubs, merge_method="PS")
        assert isinstance(merged, ConvergenceClubs)
        assert merged.n_clubs <= base_clubs.n_clubs

    def test_merge_vlt(self, base_clubs):
        merged = merge_clubs(base_clubs, merge_method="vLT")
        assert isinstance(merged, ConvergenceClubs)
        assert merged.n_clubs <= base_clubs.n_clubs

    def test_merge_divergent(self, base_clubs):
        merged = merge_clubs(
            base_clubs, merge_method="PS", merge_divergent_flag=True
        )
        assert merged.n_divergent <= base_clubs.n_divergent


# ---------------------------------------------------------------------------
# transition_paths
# ---------------------------------------------------------------------------

class TestTransitionPaths:
    @pytest.fixture
    def clubs_result(self):
        df = load_filtered_gdp()
        return find_clubs(
            df,
            data_cols=list(range(1, 35)),
            unit_names=0,
            ref_col=34,
            time_trim=1 / 3,
            cstar=0,
        )

    def test_list_output(self, clubs_result):
        tp = transition_paths(clubs_result, output_type="list")
        assert isinstance(tp, dict)
        assert len(tp) >= clubs_result.n_clubs

    def test_dataframe_output(self, clubs_result):
        tp = transition_paths(clubs_result, output_type="data.frame")
        assert isinstance(tp, pd.DataFrame)
        assert "club" in tp.columns


# ---------------------------------------------------------------------------
# ConvergenceClubs methods
# ---------------------------------------------------------------------------

class TestConvergenceClubsMethods:
    @pytest.fixture
    def clubs_result(self):
        df = load_filtered_gdp()
        return find_clubs(
            df,
            data_cols=list(range(1, 35)),
            unit_names=0,
            ref_col=34,
            time_trim=1 / 3,
            cstar=0,
        )

    def test_dim(self, clubs_result):
        n_clubs, n_div = clubs_result.dim
        assert n_clubs >= 1
        assert n_div >= 0

    def test_repr(self, clubs_result):
        r = repr(clubs_result)
        assert "ConvergenceClubs" in r

    def test_summary(self, clubs_result, capsys):
        df = clubs_result.summary()
        assert isinstance(df, pd.DataFrame)
        captured = capsys.readouterr()
        assert "Number of convergence clubs" in captured.out


# ---------------------------------------------------------------------------
# Input validation
# ---------------------------------------------------------------------------

class TestInputValidation:
    def test_non_dataframe_raises(self):
        with pytest.raises(TypeError):
            find_clubs(np.array([[1, 2]]), data_cols=[0, 1])

    def test_bad_time_trim(self):
        df = load_filtered_gdp()
        with pytest.raises(ValueError):
            find_clubs(df, data_cols=list(range(1, 35)), time_trim=1.5)

    def test_too_few_periods(self):
        df = load_filtered_gdp()
        with pytest.raises(ValueError):
            find_clubs(df, data_cols=[1], time_trim=1 / 3)


# ---------------------------------------------------------------------------
# HP filter
# ---------------------------------------------------------------------------

class TestHPFilter:
    def test_trend_plus_cycle_equals_original(self):
        np.random.seed(0)
        y = np.cumsum(np.random.randn(50)) + 100
        trend, cycle = hp_filter(y, lamb=1600)
        np.testing.assert_allclose(trend + cycle, y, atol=1e-10)

    def test_trend_is_smooth(self):
        np.random.seed(1)
        y = np.cumsum(np.random.randn(100))
        trend, _ = hp_filter(y, lamb=1600)
        # Second differences of trend should be small
        dd = np.diff(trend, n=2)
        assert np.std(dd) < np.std(np.diff(y, n=2))

    def test_constant_series(self):
        y = np.full(20, 5.0)
        trend, cycle = hp_filter(y, lamb=400)
        np.testing.assert_allclose(trend, 5.0, atol=1e-10)
        np.testing.assert_allclose(cycle, 0.0, atol=1e-10)

    def test_too_short_raises(self):
        with pytest.raises(ValueError):
            hp_filter(np.array([1.0, 2.0]), lamb=400)

    def test_panel_shape_preserved(self):
        df = load_gdp()
        filtered = hp_filter_panel(df, data_cols=range(1, 35), lamb=400)
        assert filtered.shape == df.shape
        # Country names unchanged
        assert list(filtered.iloc[:, 0]) == list(df.iloc[:, 0])

    def test_panel_matches_bundled_data(self):
        """Verify our HP filter reproduces the bundled filteredGDP."""
        gdp = load_gdp()
        filtered_ours = hp_filter_panel(gdp, data_cols=range(1, 35), lamb=400, log_transform=True)
        filtered_ref = load_filtered_gdp()
        diff = np.abs(filtered_ours.iloc[:, 1:].values - filtered_ref.iloc[:, 1:].values)
        # Allow small numerical differences between R and Python implementations
        assert diff.max() < 1e-4, f"Max diff: {diff.max()}"
