from processor_tools.config.init_config import ConfigInit as ConfigInit
