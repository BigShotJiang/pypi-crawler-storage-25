K8sRunner workspace example
===========================

Demonstrates the workspace file-sync API by running a CSV-to-JSON
summarizer inside a Kubernetes pod. Files travel host -> pod -> host
across each call, with the second call showing the hash-guarded
"nothing to do" steady state.

What it shows
-------------

- **Directional sync.** ``./inputs`` is declared ``dir="up"`` (host
  -> pod only) and ``./outputs`` is ``dir="down"`` (pod -> host only).
  Yonder does the right thing in each phase.
- **Hash-guarded steady state.** The second call sees an unchanged
  host workspace and logs ``upload[inputs] nothing to do`` instead of
  re-uploading.
- **Reference-mode dispatch with sources.** ``mode="reference"`` and
  ``source_path="auto"`` ship ``tasks.py`` into the pod so the pod
  imports its own copy of ``summarize_csvs``. No cloudpickle needed
  in the image.

Prerequisites
-------------

- A reachable Kubernetes cluster. ``kubectl get nodes`` must work.
  Anything is fine — a remote cluster, ``kind create cluster``, or
  ``minikube start``.
- ``pip install 'run-yonder[k8s]'``.
- The image (default ``python:3.12-slim``) must be pullable inside
  the cluster. ``kind`` and ``minikube`` pull from the public docker
  hub by default; air-gapped clusters need to host the image
  themselves.

Run
---

.. code:: shell

    python main.py                       # INFO logging (the default)
    python main.py --log-level DEBUG     # see every sync timing
    python main.py --namespace yonder    # use a non-default namespace

Sample output (annotated)
-------------------------

.. code::

    === Call 1: cold workspace (uploads + downloads happen) ===
    [yonder-k8s-abc12345]   scan host /…/inputs in 0.5 ms
    [yonder-k8s-abc12345]   scan runner /work/in in 320.2 ms
    [yonder-k8s-abc12345] upload[inputs] 2 to transfer, 0 to delete
    [yonder-k8s-abc12345]   pack 2 files in 0.4 ms
    [yonder-k8s-abc12345]   push to runner in 285.1 ms (10752 bytes)
    [yonder-k8s-abc12345] upload[inputs] in 606.8 ms
    [yonder-k8s-abc12345]   scan runner /work/out in 305.6 ms
    [yonder-k8s-abc12345] download[outputs] 2 to transfer, 0 to delete
    [yonder-k8s-abc12345]   pull from runner (2 files) in 318.7 ms
    [yonder-k8s-abc12345]   extract 10248 bytes in 1.0 ms
    [yonder-k8s-abc12345] download[outputs] in 626.6 ms

    === Call 2: warm workspace (sync logs say 'nothing to do') ===
    [yonder-k8s-abc12345] upload[inputs] nothing to do (2 files unchanged)
    [yonder-k8s-abc12345] upload[inputs] in 322.4 ms
    [yonder-k8s-abc12345] download[outputs] nothing to do (2 files unchanged)
    [yonder-k8s-abc12345] download[outputs] in 333.5 ms

The per-call overhead in the warm case is dominated by the kubernetes
exec WebSocket handshake — see the per-runner overhead notes in
:doc:`/pages/workspace`.

Cleanup
-------

The pod is created with ``image=`` mode, so yonder deletes it on
``closeAll()`` (which the script runs in a ``finally`` block). If the
script is killed before that runs, delete the pod manually:

.. code:: shell

    kubectl get pods -l app.kubernetes.io/managed-by=yonder
    kubectl delete pod <pod-name>
