rdkit yonder example
====================

Demonstrates yonder's **reference mode**: a transport that ships the
function as ``(module, qualname, args, kwargs)`` instead of cloudpickled
bytecode, so host and container Python minor versions can differ.

rdkit is the perfect case study. Its pip wheels stop at CPython 3.13, so
a 3.14 host can't ship cloudpickled functions to a 3.13 rdkit container
— the in-container unpickler errors with::

    TypeError: code() takes at most 16 arguments (18 given)

Reference mode just imports the module under the container's own Python;
no bytecode crosses the wire.

Layout
------

::

    examples/rdkit/
    ├── Dockerfile        python:3.13-slim + rdkit (+ cloudpickle, for the --try-cloudpickle path)
    ├── main.py           script: configures the runner, calls the function
    ├── tasks.py          module: defines molecule_properties at module scope
    └── README.rst

The function lives in `tasks.py <tasks.py>`_ (not `main.py <main.py>`_)
because reference mode requires the function to be importable — it can't
live inside ``main()`` and it can't live in ``__main__``.

Run
---

From the repo root:

.. code:: bash

    pip install -e ".[docker]"

    # reference mode (default): works regardless of host Python version
    python examples/rdkit/main.py
    python examples/rdkit/main.py --smiles "CCO"        # ethanol
    python examples/rdkit/main.py --smiles "c1ccccc1"   # benzene

    # cloudpickle mode: demonstrates the version-mismatch failure
    python examples/rdkit/main.py --try-cloudpickle

    # crank up logging to watch the build + start + exec steps
    python examples/rdkit/main.py --log-level DEBUG

``--try-cloudpickle`` builds the same image and runs the same function —
the only difference is the runner's ``mode=``. On a host whose Python
minor version doesn't match the container's (3.13), the cloudpickle path
fails with a clear ``RuntimeError`` from yonder's pre-flight version
check::

    RuntimeError: Python minor version mismatch: container ... runs Python
    3.13, host runs Python 3.14. cloudpickle pickles function bytecode,
    which is not portable across CPython minor versions. Fix by running
    yonder from a Python 3.13 venv on the host, or use/build an image whose
    Python is 3.14.

The reference-mode run succeeds on the same host with the same image.

How reference mode works here
-----------------------------

1. `main.py <main.py>`_ configures the runner with ``mode="reference"``
   and ``source_path="auto"``. The ``"auto"`` sentinel resolves to the
   directory of the file that constructed the runner (here, the example
   directory). That directory is mounted into the container at
   ``/workspace/rdkit`` and prepended to ``PYTHONPATH``, so the
   container can ``import tasks``.
2. The host calls ``molecule_properties("CCO")``. The decorator sees the
   runner is in reference mode, validates the function is at module
   scope (it is — ``tasks.molecule_properties``), and sends a
   stdlib-pickle payload of ``{"module": "tasks", "qualname":
   "molecule_properties", "args": ..., "kwargs": ...}``.
3. The container's bootstrap (still Python 3.13) installs a no-op
   ``yonder`` shim (since yonder isn't pip-installed inside the rdkit
   image), imports ``tasks``, resolves ``molecule_properties``, and
   calls it. rdkit runs against the container's own Python 3.13 — no
   cross-version bytecode anywhere.
4. The result is ``pickle.dumps``-ed back over stdout and unpacked on
   the host.

When to use which mode
----------------------

.. list-table::
    :header-rows: 1
    :widths: 50 50

    * - Use cloudpickle (default)
      - Use reference
    * - Host and container Python versions match
      - Versions can or must differ
    * - You want to decorate inline functions inside ``main()``
      - You can put the function at module scope
    * - The function is a lambda, closure, or anything not importable
      - The function is in an importable module
    * - You want unsaved editor-buffer changes to ship
      - OK with the container reading from disk
