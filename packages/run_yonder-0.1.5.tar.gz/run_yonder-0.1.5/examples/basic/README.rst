basic yonder example
====================

Builds a minimal image (``python:3.x-slim`` + ``cloudpickle``) and runs a
single function either locally or inside the container.

Run
---

From the repo root:

.. code:: bash

    pip install -e ".[docker]"

    # local execution (runner.when() returns False, function runs in this process)
    python examples/basic/main.py

    # remote execution (function runs inside the freshly built container)
    python examples/basic/main.py --remote

    # crank up logging to see the build + start + exec steps
    python examples/basic/main.py --remote --log-level DEBUG

Compare the ``hostname`` / ``python`` lines between local and remote
output to confirm the function actually ran in the container.
