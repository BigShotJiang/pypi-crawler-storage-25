"""Wire framing for ApiRunner ⇄ yonder-server.

A ``POST /run`` response is a sequence of length-prefixed frames so the
server can stream stderr to the client as the subprocess produces it,
then deliver the final pickled envelope when the subprocess exits:

    +--------+------------+--------------+
    | tag(1) | length(4)  | data         |
    +--------+------------+--------------+

* ``tag`` — ``b"E"`` for a stderr chunk, ``b"R"`` for the terminal
  envelope. Future tags can carry progress events without breaking
  existing clients (they'd just skip unknown tags).
* ``length`` — big-endian unsigned 32-bit, in bytes.
* ``data`` — the frame payload.

The response ends after exactly one ``R`` frame. A response that ends
without one indicates the server died mid-call and the client should
treat it as an error.

The chunked HTTP transfer-encoding handles delivery; this framing sits
inside the body so a single response can carry both intermixed stderr
and the final envelope without any out-of-band channels. Keeping the
format dead-simple (no varints, no protobuf) means the parser fits in
~20 lines on each side and is easy to reason about under partial reads.
"""
from __future__ import annotations

import struct
from typing import Iterator

TAG_STDERR = b"E"
TAG_RESULT = b"R"
HEADER_STRUCT = struct.Struct(">cI")  # 1-byte tag + 4-byte big-endian length
HEADER_SIZE = HEADER_STRUCT.size


def encode_frame(tag: bytes, data: bytes) -> bytes:
    """Encode one frame for transmission."""
    if tag not in (TAG_STDERR, TAG_RESULT):
        raise ValueError(f"invalid frame tag {tag!r}")
    return HEADER_STRUCT.pack(tag, len(data)) + data


def iter_frames(read_exactly) -> Iterator[tuple]:
    """Yield ``(tag, data)`` tuples from a stream.

    ``read_exactly(n)`` must return exactly ``n`` bytes or raise (return
    of fewer than ``n`` bytes signals an unexpected EOF). The iterator
    ends after yielding an ``R`` frame.
    """
    while True:
        header = read_exactly(HEADER_SIZE)
        tag, length = HEADER_STRUCT.unpack(header)
        data = read_exactly(length) if length else b""
        yield tag, data
        if tag == TAG_RESULT:
            return
