"""Top-level ``yonder`` CLI dispatcher.

Currently only ``yonder serve`` is wired up; the dispatcher is in place
so future subcommands can be added without changing the entry point.
"""
from __future__ import annotations

import sys
from typing import Optional


def main(argv: Optional[list] = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv or argv[0] in ("-h", "--help"):
        print("usage: yonder <command> [args...]")
        print("")
        print("commands:")
        print("  serve    Run the yonder-server HTTP service (see `yonder serve --help`)")
        return 0
    cmd, *rest = argv
    if cmd == "serve":
        from .server.cli import main as serve_main

        return serve_main(rest)
    print(f"yonder: unknown command {cmd!r}", file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main())
