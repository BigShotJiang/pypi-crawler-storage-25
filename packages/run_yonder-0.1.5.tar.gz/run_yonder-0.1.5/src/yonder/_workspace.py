"""Workspace file sync between host and runner.

A *workspace* declares one or more host directories that should be
shuttled across the wire around each remote call. Each entry has a
direction (``up`` = upload only, ``down`` = download only,
``both`` = bidirectional) and optional include/exclude glob filters
that bound what's considered part of the workspace.

Sync uses a **hash-guarded stat diff** (option 2 in the proposal):

1. Walk the workspace and build a manifest of
   ``{relpath: (size, mtime_ns, sha256)}``.
2. When a previous manifest exists, skip the sha256 for any file whose
   ``(size, mtime_ns)`` is unchanged — the cached hash is still valid.
3. Diff host vs. runner manifests by sha256: files with different (or
   missing) hashes go into the upload/download set.

This module is **transport-agnostic**: it produces the byte-level work
(manifests, tar payloads, file-rename plans) and asks the runner to do
the actual moving via three hooks on the runner object:

- ``scan_workspace(runner_path, include, exclude, hint) -> manifest``
- ``upload_workspace(runner_path, tar_bytes, deletes) -> None``
- ``download_workspace(runner_path, paths) -> tar_bytes``

The decorator calls :func:`run_upload_phase` before a call and
:func:`run_download_phase` after, both no-ops if the runner has no
workspace.
"""
from __future__ import annotations

import hashlib
import io
import json
import logging
import os
import re
import shutil
import tarfile
import tempfile
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Dict, List, Mapping, Optional, Tuple, Union

_log = logging.getLogger("yonder.workspace")

# Per-file fingerprint stored in a manifest. Tuple instead of a class
# so JSON round-trips cleanly through the runner-side scan script.
# (size_bytes, mtime_nanoseconds, sha256_hexdigest)
Fingerprint = Tuple[int, int, str]
Manifest = Dict[str, Fingerprint]

# Reserved staging directory name yonder uses while extracting tars.
# Always under the workspace root; cleaned up in a finally block.
_STAGING_PREFIX = ".yonder-staging-"

# Stream read size for sha256. 64 KiB keeps CPU cache happy on big files
# without paying many extra syscalls on small ones.
_HASH_CHUNK = 64 * 1024


# ---------------------------------------------------------------------------
# Glob matching
# ---------------------------------------------------------------------------

def _glob_to_regex(pattern: str) -> str:
    """Translate a unix-shell-style glob into an anchored regex.

    Supports:
    - ``*`` — any run of characters except ``/``.
    - ``?`` — a single character except ``/``.
    - ``**`` — any number of path segments (matches ``foo/bar/baz``).
    - ``**/`` — zero or more directory levels before the rest.

    Everything else is escaped literally. Matches are against POSIX-style
    relative paths (separators are ``/`` on both Linux and Windows).
    """
    parts: List[str] = []
    i = 0
    while i < len(pattern):
        c = pattern[i]
        if c == "*":
            if i + 1 < len(pattern) and pattern[i + 1] == "*":
                # `**/` -> zero or more directory levels
                if i + 2 < len(pattern) and pattern[i + 2] == "/":
                    parts.append("(?:.*/)?")
                    i += 3
                    continue
                # bare `**` -> anything including slashes
                parts.append(".*")
                i += 2
                continue
            parts.append("[^/]*")
            i += 1
        elif c == "?":
            parts.append("[^/]")
            i += 1
        else:
            parts.append(re.escape(c))
            i += 1
    return "^(?:" + "".join(parts) + ")$"


def _compile_patterns(patterns: Optional[List[str]]) -> Optional[re.Pattern]:
    """Compile a list of globs into a single alternation regex.

    Returns ``None`` if ``patterns`` is empty / ``None`` so callers can
    short-circuit instead of compiling an empty pattern.
    """
    if not patterns:
        return None
    alt = "|".join(f"(?:{_glob_to_regex(p)[4:-2]})" for p in patterns)
    return re.compile("^(?:" + alt + ")$")


def _passes_filters(
    relpath: str,
    include: Optional[re.Pattern],
    exclude: Optional[re.Pattern],
) -> bool:
    """A file is in the workspace if it matches ``include`` (or include is
    empty) and does not match ``exclude``. Paths are POSIX-style."""
    if include is not None and not include.match(relpath):
        return False
    if exclude is not None and exclude.match(relpath):
        return False
    return True


# ---------------------------------------------------------------------------
# Workspace declarations
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class WorkspaceEntry:
    """One ``host_path <-> runner_path`` mapping in a workspace.

    - ``direction`` — one of:

      - ``"up"`` — host -> runner before each call.
      - ``"down"`` — runner -> host after each call.
      - ``"both"`` — uploaded before, downloaded after.
      - ``"translate"`` — no sync at all. The mapping exists purely
        for :class:`yonder.HostPath` translation: yonder rewrites
        host paths to runner-side paths but never copies bytes.
        Use this when the runner side already has the files (a
        shared NFS mount, a path baked into the image, etc.).

    - ``include`` / ``exclude`` — fnmatch-style globs against the POSIX
      relative path inside this entry's root. ``**`` matches across
      directory levels. ``None`` / ``[]`` for include means "everything";
      same for exclude means "nothing excluded". Filters are ignored on
      ``translate`` entries (no scan happens).
    - ``name`` — short identifier used in log lines.
    """

    host_path: str
    runner_path: str
    direction: str
    include: Optional[List[str]] = None
    exclude: Optional[List[str]] = None
    name: str = ""

    def __post_init__(self) -> None:
        if self.direction not in ("up", "down", "both", "translate"):
            raise ValueError(
                f"workspace entry {self.name or self.host_path!r}: "
                f"direction must be 'up', 'down', 'both', or 'translate' "
                f"(got {self.direction!r})"
            )

    @property
    def uploads(self) -> bool:
        return self.direction in ("up", "both")

    @property
    def downloads(self) -> bool:
        return self.direction in ("down", "both")


@dataclass
class Workspace:
    """A collection of :class:`WorkspaceEntry` plus runner-wide flags."""

    entries: List[WorkspaceEntry] = field(default_factory=list)
    sync_deletes: bool = False
    # Per-entry host-side manifest cache, keyed by entry name. Populated
    # at the end of each successful upload (and download) phase; reused
    # on the next call to skip rehashing unchanged files.
    _host_manifests: Dict[str, Manifest] = field(default_factory=dict)

    def __bool__(self) -> bool:
        return bool(self.entries)


def normalize_workspace(
    spec: Union[None, "Workspace", Mapping[str, object]],
    *,
    sync_deletes: bool = False,
) -> Optional[Workspace]:
    """Turn a user-supplied workspace argument into a :class:`Workspace`.

    Accepted shapes for ``spec``:

    - ``None`` — no workspace; sync is a no-op.
    - A :class:`Workspace` — returned unchanged.
    - A ``dict`` keyed by host path with either of:

      - A plain string value — interpreted as ``runner_path``,
        direction defaults to ``"both"``.
      - A ``dict`` value with keys ``to`` (required, runner path),
        ``dir`` (optional direction; default ``"both"``),
        ``include`` (optional list of globs), ``exclude`` (optional
        list of globs), ``name`` (optional label).

    Host paths are run through ``os.path.expanduser`` +
    ``os.path.abspath`` so relative paths resolve against ``os.getcwd()``
    at runner construction time, not at first-call time.
    """
    if spec is None:
        return None
    if isinstance(spec, Workspace):
        return spec
    if not isinstance(spec, Mapping):
        raise TypeError(
            f"workspace= must be a mapping or Workspace, got {type(spec).__name__}"
        )

    entries: List[WorkspaceEntry] = []
    for host_path, opts in spec.items():
        abs_host = os.path.abspath(os.path.expanduser(str(host_path)))
        if isinstance(opts, str):
            entry = WorkspaceEntry(
                host_path=abs_host,
                runner_path=opts,
                direction="both",
                name=os.path.basename(abs_host.rstrip("/")) or abs_host,
            )
        elif isinstance(opts, Mapping):
            if "to" not in opts:
                raise ValueError(
                    f"workspace entry {host_path!r}: missing required key 'to' "
                    f"(the runner-side path)"
                )
            entry = WorkspaceEntry(
                host_path=abs_host,
                runner_path=str(opts["to"]),
                direction=str(opts.get("dir", "both")),
                include=list(opts["include"]) if opts.get("include") else None,
                exclude=list(opts["exclude"]) if opts.get("exclude") else None,
                name=str(
                    opts.get("name")
                    or os.path.basename(abs_host.rstrip("/"))
                    or abs_host
                ),
            )
        else:
            raise TypeError(
                f"workspace entry {host_path!r}: value must be a string "
                f"or dict, got {type(opts).__name__}"
            )
        entries.append(entry)

    return Workspace(entries=entries, sync_deletes=sync_deletes)


# ---------------------------------------------------------------------------
# Host-side scan (hash-guarded stat)
# ---------------------------------------------------------------------------

def _sha256_of_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(_HASH_CHUNK), b""):
            h.update(chunk)
    return h.hexdigest()


def scan_host(
    entry: WorkspaceEntry,
    prev: Optional[Manifest] = None,
) -> Manifest:
    """Walk ``entry.host_path`` and build a manifest.

    For each file:
    - Take ``(size, mtime_ns)`` from ``os.stat``.
    - If ``prev`` has the same path *and* its ``(size, mtime_ns)``
      matches, reuse the cached sha256 (the file is unchanged).
    - Otherwise compute a fresh sha256.

    This is the hash-guarded stat diff: ``stat`` is cheap and decides
    most files; the hash only runs for files that actually look
    different. The "best case: nothing changed" path is one
    ``os.stat`` per file plus zero bytes read.

    Missing or unreadable files (e.g. broken symlinks, files deleted
    between ``os.walk`` and ``os.stat``) are silently skipped.
    """
    root = entry.host_path
    if not os.path.isdir(root):
        # An "up" workspace can legitimately be empty/missing — treat
        # it as empty rather than raising. A "down" workspace that
        # doesn't exist yet on the host gets created lazily on
        # download.
        return {}

    include = _compile_patterns(entry.include)
    exclude = _compile_patterns(entry.exclude)
    prev = prev or {}

    manifest: Manifest = {}
    hashed = 0
    reused = 0
    for dpath, dirs, files in os.walk(root):
        # Iterate deterministically so log output is stable.
        dirs.sort()
        for fname in sorted(files):
            full = os.path.join(dpath, fname)
            rel = os.path.relpath(full, root).replace(os.sep, "/")
            if not _passes_filters(rel, include, exclude):
                continue
            try:
                st = os.stat(full)
            except OSError:
                continue
            size, mtime_ns = st.st_size, st.st_mtime_ns
            cached = prev.get(rel)
            if cached is not None and cached[0] == size and cached[1] == mtime_ns:
                manifest[rel] = cached
                reused += 1
                continue
            try:
                digest = _sha256_of_file(full)
            except OSError:
                continue
            manifest[rel] = (size, mtime_ns, digest)
            hashed += 1

    _log.debug(
        "host scan %s: %d files (%d hashed, %d cache hits)",
        entry.name, len(manifest), hashed, reused,
    )
    return manifest


# ---------------------------------------------------------------------------
# Runner-side scan script
# ---------------------------------------------------------------------------

# A small stdlib-only Python program that runs *inside the runner* and
# emits the same kind of manifest scan_host() produces. Invoked as:
#
#     python -c <RUNNER_SCAN_SCRIPT> <root> <include_json> <exclude_json> <prev_json>
#
# The "prev" manifest lets the runner-side scan skip rehashing files
# whose (size, mtime_ns) match the prior scan, just like the host side.
# Output is a single JSON dict to stdout.
RUNNER_SCAN_SCRIPT = r'''
import hashlib, json, os, re, sys

def _glob_to_regex(pat):
    parts, i = [], 0
    while i < len(pat):
        c = pat[i]
        if c == "*":
            if i + 1 < len(pat) and pat[i+1] == "*":
                if i + 2 < len(pat) and pat[i+2] == "/":
                    parts.append("(?:.*/)?"); i += 3; continue
                parts.append(".*"); i += 2; continue
            parts.append("[^/]*"); i += 1
        elif c == "?":
            parts.append("[^/]"); i += 1
        else:
            parts.append(re.escape(c)); i += 1
    return "".join(parts)

def _compile(pats):
    if not pats: return None
    alt = "|".join("(?:" + _glob_to_regex(p) + ")" for p in pats)
    return re.compile("^(?:" + alt + ")$")

root = sys.argv[1]
inc = _compile(json.loads(sys.argv[2]))
exc = _compile(json.loads(sys.argv[3]))
prev = json.loads(sys.argv[4]) if len(sys.argv) > 4 else {}

out = {}
if os.path.isdir(root):
    for dpath, dirs, files in os.walk(root):
        dirs.sort()
        for f in sorted(files):
            full = os.path.join(dpath, f)
            rel = os.path.relpath(full, root).replace(os.sep, "/")
            if inc and not inc.match(rel): continue
            if exc and exc.match(rel): continue
            try:
                st = os.stat(full)
            except OSError:
                continue
            cached = prev.get(rel)
            if cached and cached[0] == st.st_size and cached[1] == st.st_mtime_ns:
                out[rel] = cached
                continue
            h = hashlib.sha256()
            try:
                with open(full, "rb") as fh:
                    for chunk in iter(lambda: fh.read(65536), b""):
                        h.update(chunk)
            except OSError:
                continue
            out[rel] = [st.st_size, st.st_mtime_ns, h.hexdigest()]
sys.stdout.write(json.dumps(out))
'''


def parse_runner_manifest(raw: bytes) -> Manifest:
    """Parse the JSON output of :data:`RUNNER_SCAN_SCRIPT` back into a
    :data:`Manifest`. JSON arrays come back as lists; convert to tuples
    so the manifest type is hashable-comparable with the host side."""
    try:
        loaded = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RuntimeError(
            f"runner scan returned invalid JSON: {exc}\n"
            f"raw output (truncated): {raw[:200]!r}"
        ) from exc
    return {k: (int(v[0]), int(v[1]), str(v[2])) for k, v in loaded.items()}


def runner_scan_args(
    runner_path: str,
    include: Optional[List[str]],
    exclude: Optional[List[str]],
    prev: Optional[Manifest],
) -> List[str]:
    """Build the positional argv that :data:`RUNNER_SCAN_SCRIPT` expects.

    Returned as ``[runner_path, include_json, exclude_json, prev_json]``;
    runner-specific code prefixes ``python -c <script>`` and whatever
    exec wrapper it needs.
    """
    return [
        runner_path,
        json.dumps(include or []),
        json.dumps(exclude or []),
        json.dumps(
            {k: [v[0], v[1], v[2]] for k, v in (prev or {}).items()}
        ),
    ]


# ---------------------------------------------------------------------------
# Manifest diff
# ---------------------------------------------------------------------------

@dataclass
class SyncPlan:
    """The byte-level work needed to make the destination match the source.

    ``transfer`` is the list of POSIX relpaths whose content must be
    copied from source to destination (file is new or its sha256 differs).
    ``delete`` is the list of paths that exist only on the destination
    and should be removed (populated only when sync_deletes is enabled).
    """

    transfer: List[str] = field(default_factory=list)
    delete: List[str] = field(default_factory=list)

    @property
    def empty(self) -> bool:
        return not self.transfer and not self.delete


def plan_diff(
    source: Manifest,
    destination: Manifest,
    *,
    sync_deletes: bool,
) -> SyncPlan:
    """Compare ``source`` (authoritative side) against ``destination``.

    A file goes into ``transfer`` if it is in ``source`` and either
    missing from ``destination`` or differs by sha256. A file goes into
    ``delete`` if it is *only* in ``destination`` — but only when
    ``sync_deletes`` is true.
    """
    transfer: List[str] = []
    for rel, fp in source.items():
        dest_fp = destination.get(rel)
        if dest_fp is None or dest_fp[2] != fp[2]:
            transfer.append(rel)
    transfer.sort()
    delete: List[str] = []
    if sync_deletes:
        delete = sorted(set(destination) - set(source))
    return SyncPlan(transfer=transfer, delete=delete)


# ---------------------------------------------------------------------------
# Tar packing and atomic extraction
# ---------------------------------------------------------------------------

def pack_files(root: str, relpaths: List[str]) -> bytes:
    """Tar exactly the listed files under ``root`` into a flat archive.

    Entries are stored with their relative paths (no top-level basename
    wrap, unlike :func:`yonder._shipping.tar_directory`), so the
    receiving side can extract straight into ``runner_path`` / the
    host's workspace root.

    Empty ``relpaths`` produces an empty (but valid) tar.
    """
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w", format=tarfile.PAX_FORMAT) as tf:
        for rel in relpaths:
            full = os.path.join(root, rel)
            try:
                ti = tf.gettarinfo(full, arcname=rel)
            except FileNotFoundError:
                # Raced — the file was deleted between scan and pack.
                # Skip it; the next sync will pick up the deletion.
                continue
            with open(full, "rb") as fh:
                tf.addfile(ti, fh)
    return buf.getvalue()


def extract_tar_atomic(target_root: str, tar_bytes: bytes) -> None:
    """Extract ``tar_bytes`` into ``target_root`` with per-file atomicity.

    The tar is first extracted into a sibling staging directory under
    ``target_root``; each file is then ``os.replace``'d into its final
    location. The staging directory is cleaned up unconditionally.

    If the process dies mid-extract, each individual file is either the
    old version or the new version — never a half-written intermediate.
    Cross-file atomicity is *not* offered (the workspace as a whole
    can be in a mixed state if we crash between renames).
    """
    if not tar_bytes:
        return
    os.makedirs(target_root, exist_ok=True)
    staging = tempfile.mkdtemp(prefix=_STAGING_PREFIX, dir=target_root)
    try:
        with tarfile.open(fileobj=io.BytesIO(tar_bytes), mode="r") as tf:
            for member in tf.getmembers():
                if member.name.startswith("/") or ".." in member.name.split("/"):
                    raise RuntimeError(
                        f"refusing tar entry with unsafe path {member.name!r}"
                    )
            # filter="data" rejects absolute paths, ".." segments,
            # special files, and out-of-archive symlinks — it's the
            # safety filter Python 3.14 makes mandatory.
            tf.extractall(staging, filter="data")
        for dpath, dirs, files in os.walk(staging):
            rel_root = os.path.relpath(dpath, staging)
            target_dir = (
                target_root if rel_root == "." else os.path.join(target_root, rel_root)
            )
            os.makedirs(target_dir, exist_ok=True)
            for fname in files:
                src = os.path.join(dpath, fname)
                dst = os.path.join(target_dir, fname)
                os.replace(src, dst)
    finally:
        shutil.rmtree(staging, ignore_errors=True)


def delete_paths(root: str, relpaths: List[str]) -> None:
    """Best-effort delete of each path in ``relpaths`` under ``root``.

    Empty directories left behind by the deletion are pruned upward
    until a non-empty directory or the root is reached. Errors are
    swallowed — sync_deletes is opt-in and a failed cleanup shouldn't
    abort the whole sync.
    """
    for rel in relpaths:
        full = os.path.join(root, rel)
        try:
            os.remove(full)
        except OSError:
            continue
        parent = os.path.dirname(full)
        while parent and os.path.abspath(parent) != os.path.abspath(root):
            try:
                os.rmdir(parent)
            except OSError:
                break
            parent = os.path.dirname(parent)


# ---------------------------------------------------------------------------
# Timing helper
# ---------------------------------------------------------------------------

@contextmanager
def _timed(runner_name: str, label: str, extra: str = ""):
    """Log start and end of a sync phase with elapsed milliseconds."""
    start = time.perf_counter()
    suffix = f" ({extra})" if extra else ""
    _log.debug("[%s] %s starting%s", runner_name, label, suffix)
    try:
        yield
    finally:
        elapsed_ms = (time.perf_counter() - start) * 1000
        _log.debug("[%s] %s in %.1f ms%s", runner_name, label, elapsed_ms, suffix)


# ---------------------------------------------------------------------------
# Phase drivers — called by the decorator
# ---------------------------------------------------------------------------

def run_upload_phase(runner, workspace: Workspace) -> None:
    """Sync every ``up``/``both`` entry from host -> runner.

    For each entry:
    1. Scan host (hash-guarded against the previous call's manifest).
    2. Ask the runner to scan its side (hash-guarded against the
       runner-side manifest we sent at the end of the last upload).
    3. Diff and compute a SyncPlan.
    4. If non-empty, pack the transfer set into a tar and call
       ``runner.upload_workspace()``.
    5. Cache the host manifest so the next call's scan can skip
       rehashing unchanged files.

    Phase timings are logged at DEBUG level.
    """
    for entry in workspace.entries:
        if not entry.uploads:
            continue
        runner_name = getattr(runner, "name", type(runner).__name__)
        with _timed(runner_name, f"upload[{entry.name}]"):
            prev_host = workspace._host_manifests.get(entry.name)
            with _timed(runner_name, f"  scan host {entry.host_path}"):
                host_manifest = scan_host(entry, prev_host)

            with _timed(runner_name, f"  scan runner {entry.runner_path}"):
                runner_manifest = runner.scan_workspace(
                    runner_path=entry.runner_path,
                    include=entry.include,
                    exclude=entry.exclude,
                    hint=prev_host,
                )

            plan = plan_diff(
                host_manifest, runner_manifest, sync_deletes=workspace.sync_deletes,
            )
            if plan.empty:
                _log.debug(
                    "[%s] upload[%s] nothing to do (%d files unchanged)",
                    runner_name, entry.name, len(host_manifest),
                )
                workspace._host_manifests[entry.name] = host_manifest
                continue

            _log.debug(
                "[%s] upload[%s] %d to transfer, %d to delete",
                runner_name, entry.name, len(plan.transfer), len(plan.delete),
            )
            with _timed(
                runner_name,
                f"  pack {len(plan.transfer)} files",
            ):
                tar_bytes = pack_files(entry.host_path, plan.transfer)

            with _timed(
                runner_name,
                f"  push to runner",
                extra=f"{len(tar_bytes)} bytes",
            ):
                runner.upload_workspace(
                    runner_path=entry.runner_path,
                    tar_bytes=tar_bytes,
                    deletes=plan.delete,
                )

            workspace._host_manifests[entry.name] = host_manifest


def run_download_phase(runner, workspace: Workspace) -> None:
    """Sync every ``down``/``both`` entry from runner -> host.

    The mirror image of :func:`run_upload_phase`:
    1. Scan host (so we know what to overwrite/delete).
    2. Scan runner.
    3. Diff with runner as the authoritative side.
    4. If non-empty, ask the runner to pack the transfer set and
       atomically extract it on the host.
    5. Update the cached host manifest to reflect the new state.
    """
    for entry in workspace.entries:
        if not entry.downloads:
            continue
        runner_name = getattr(runner, "name", type(runner).__name__)
        with _timed(runner_name, f"download[{entry.name}]"):
            prev_host = workspace._host_manifests.get(entry.name)
            with _timed(runner_name, f"  scan host {entry.host_path}"):
                host_manifest = scan_host(entry, prev_host)

            with _timed(runner_name, f"  scan runner {entry.runner_path}"):
                runner_manifest = runner.scan_workspace(
                    runner_path=entry.runner_path,
                    include=entry.include,
                    exclude=entry.exclude,
                    hint=host_manifest,
                )

            plan = plan_diff(
                runner_manifest, host_manifest, sync_deletes=workspace.sync_deletes,
            )
            if plan.empty:
                _log.debug(
                    "[%s] download[%s] nothing to do (%d files unchanged)",
                    runner_name, entry.name, len(runner_manifest),
                )
                workspace._host_manifests[entry.name] = host_manifest
                continue

            _log.debug(
                "[%s] download[%s] %d to transfer, %d to delete locally",
                runner_name, entry.name, len(plan.transfer), len(plan.delete),
            )
            with _timed(
                runner_name,
                f"  pull from runner ({len(plan.transfer)} files)",
            ):
                tar_bytes = runner.download_workspace(
                    runner_path=entry.runner_path,
                    paths=plan.transfer,
                )
            with _timed(
                runner_name,
                f"  extract {len(tar_bytes)} bytes",
            ):
                extract_tar_atomic(entry.host_path, tar_bytes)

            if plan.delete:
                with _timed(
                    runner_name, f"  delete {len(plan.delete)} host files",
                ):
                    delete_paths(entry.host_path, plan.delete)

            # Re-scan to capture the post-download state. Cheap because
            # everything we just wrote is hot in cache.
            workspace._host_manifests[entry.name] = scan_host(entry, host_manifest)


# ---------------------------------------------------------------------------
# HostPath translation against workspaces
# ---------------------------------------------------------------------------

def translate_via_workspace(
    workspace: Optional[Workspace], path: str
) -> Optional[str]:
    """Map a host filesystem path to its runner-side equivalent.

    Walks the workspace entries and rewrites ``path`` relative to the
    first entry whose ``host_path`` is a prefix. Returns ``None`` if no
    entry covers the path — callers can then fall back to other
    translation tables (e.g. ``mounts=``).
    """
    if workspace is None or not workspace.entries:
        return None
    abs_path = os.path.abspath(path)
    for entry in workspace.entries:
        host_abs = os.path.abspath(entry.host_path)
        if abs_path == host_abs:
            return entry.runner_path
        if abs_path.startswith(host_abs + os.sep):
            rel = os.path.relpath(abs_path, host_abs)
            return os.path.join(entry.runner_path, rel).replace(os.sep, "/")
    return None
